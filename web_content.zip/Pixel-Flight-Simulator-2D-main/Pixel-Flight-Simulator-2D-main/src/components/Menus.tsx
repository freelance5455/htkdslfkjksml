import React, { useState } from 'react';
import {
  ArrowLeft,
  CheckCircle2,
  Compass,
  Fuel,
  Lock,
  Map as MapIcon,
  Play,
  Radio,
  RotateCcw,
  Settings,
  ShieldAlert,
  SlidersHorizontal,
  TrendingUp,
  Wind,
  Wrench,
} from 'lucide-react';
import { AIRCRAFT_FLEET, getAircraftById, LICENSES_INFO } from '../data/aircraft';
import {
  AIRPORTS,
  computeWorldBearingAndDistance,
  getAirportById,
  selectBestRunwayForWind,
} from '../data/airports';
import { generateDailyAtcAssignment } from '../physics/atcSystem';
import { decomposeWindOnTrack } from '../physics/weatherSystem';
import { calculateMaintenanceCost } from '../storage/careerStorage';
import {
  AtcRadioMessage,
  CareerAtcAssignment,
  CareerSaveData,
  ControlMode,
  EmergencyType,
  FlightResultSummary,
  FlightSetupConfig,
  GameSettings,
  LicenseId,
  ScreenId,
  TimeOfDay,
  WeatherType,
} from '../types/game';
import { AircraftPixelPreview } from './AircraftPixelPreview';
import { InteractiveWorldMap } from './InteractiveWorldMap';

const M_TO_FT = 3.28084;
const M_TO_NM = 1 / 1852;

export const WEATHER_LABELS: Record<WeatherType, string> = {
  [WeatherType.CLEAR]: 'Cielo Sereno',
  [WeatherType.CLOUDY]: 'Nuvoloso',
  [WeatherType.RAIN]: 'Pioggia',
  [WeatherType.STORM]: 'Temporale',
  [WeatherType.SNOW]: 'Neve',
  [WeatherType.FOG]: 'Nebbia',
};

export const TIME_LABELS: Record<TimeOfDay, string> = {
  [TimeOfDay.DAWN]: 'Alba',
  [TimeOfDay.DAY]: 'Giorno',
  [TimeOfDay.SUNSET]: 'Tramonto',
  [TimeOfDay.NIGHT]: 'Notte',
};

export const EMERGENCY_LABELS: Record<EmergencyType, string> = {
  [EmergencyType.NONE]: 'Nessuna (Volo Regolare)',
  [EmergencyType.ENGINE_FAILURE]: 'Guasto Totale al Motore',
  [EmergencyType.POWER_LOSS]: 'Perdita Parziale di Potenza',
  [EmergencyType.FUEL_LEAK]: 'Perdita Carburante Rapida',
  [EmergencyType.GEAR_JAM]: 'Blocco Carrello Retrattile',
  [EmergencyType.ENGINE_OVERHEAT]: 'Surriscaldamento Motore',
};

function bearingCardinalIt(deg: number): string {
  const dirs = ['N', 'NE', 'E', 'SE', 'S', 'SO', 'O', 'NO'];
  const idx = Math.round((((deg % 360) + 360) % 360) / 45) % 8;
  return dirs[idx];
}

// ---------------------------------------------------------------------------
// 1. MAIN MENU OVER LIVE PIXEL WORLD
// ---------------------------------------------------------------------------
interface MainMenuProps {
  hasSave: boolean;
  career: CareerSaveData;
  onQuickContinue: () => void;
  onNewCareer: () => void;
  onNavigate: (screen: ScreenId) => void;
  onOpenFreeFlight: () => void;
}

export const MainMenuScreen: React.FC<MainMenuProps> = ({
  hasSave,
  career,
  onQuickContinue,
  onNewCareer,
  onNavigate,
  onOpenFreeFlight,
}) => {
  const [confirmNew, setConfirmNew] = useState(false);

  return (
    <div className="fixed inset-0 z-20 flex flex-col justify-between p-4 sm:p-8 pointer-events-none">
      {/* Top negative space + Bespoke Pixel Wing SVG Title Lockup */}
      <div className="pt-3 sm:pt-6 flex flex-col items-center text-center">
        <div className="bg-slate-950/82 border border-slate-700/80 rounded-2xl px-5 py-4 sm:px-8 sm:py-5 avionics-panel max-w-xl w-full pointer-events-auto">
          <div className="flex items-center justify-center mb-2">
            <svg
              viewBox="0 0 220 34"
              className="w-44 sm:w-52 h-8"
              aria-hidden="true"
            >
              <path d="M 12 12 L 88 12 L 95 16 L 26 16 Z" fill="#e2e8f0" />
              <path d="M 28 19 L 92 19 L 96 22 L 42 22 Z" fill="#94a3b8" />
              <path d="M 46 25 L 94 25 L 96 27.5 L 58 27.5 Z" fill="#64748b" />
              <path d="M 208 12 L 132 12 L 125 16 L 194 16 Z" fill="#e2e8f0" />
              <path d="M 192 19 L 128 19 L 124 22 L 178 22 Z" fill="#94a3b8" />
              <path d="M 174 25 L 126 25 L 124 27.5 L 162 27.5 Z" fill="#64748b" />
              <circle cx="110" cy="17" r="11" fill="#0f172a" stroke="#f59e0b" strokeWidth="2" />
              <polygon points="110,8 113.5,17 110,26 106.5,17" fill="#fbbf24" />
              <circle cx="110" cy="17" r="2" fill="#fef08a" />
            </svg>
          </div>
          <h1 className="text-2xl sm:text-4xl font-bold tracking-tight text-white">
            Pixel Flight Simulator
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-1">
            Simulatore Aeronautico 2D HD · Navigazione & Torre ATC · {AIRCRAFT_FLEET.length} Aeromobili · {AIRPORTS.length} Aeroporti
          </p>
        </div>
      </div>

      {/* Bottom/Center Ergonomic Menu Cluster */}
      <div className="flex flex-col items-center gap-3 pb-1">
        {confirmNew ? (
          <div className="pointer-events-auto bg-slate-950/95 border border-amber-500/70 rounded-2xl p-5 max-w-md w-full avionics-panel">
            <h2 className="text-base font-bold text-white">Avviare una Nuova Partita?</h2>
            <p className="text-xs text-slate-300 mt-1.5">
              I progressi attuali della carriera verranno sostituiti con un nuovo profilo pilota da Milano-Bresso su Cessna 172.
            </p>
            <div className="grid grid-cols-2 gap-2.5 mt-4">
              <button
                type="button"
                onClick={() => setConfirmNew(false)}
                className="min-h-[44px] px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-sm font-medium whitespace-nowrap"
              >
                Annulla
              </button>
              <button
                type="button"
                onClick={() => {
                  setConfirmNew(false);
                  onNewCareer();
                }}
                className="min-h-[44px] px-4 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 text-sm font-bold whitespace-nowrap"
              >
                Conferma Nuova
              </button>
            </div>
          </div>
        ) : (
          <div className="pointer-events-auto bg-slate-950/90 border border-slate-700/90 rounded-2xl p-3.5 sm:p-4 max-w-md w-full avionics-panel space-y-2.5">
            <button
              type="button"
              onClick={onQuickContinue}
              className="w-full min-h-[48px] px-5 py-3 rounded-lg bg-amber-500 hover:bg-amber-400 active:scale-[0.99] transition-transform text-slate-950 font-bold text-sm sm:text-base flex items-center justify-between"
            >
              <span className="flex items-center gap-2 whitespace-nowrap">
                <Play className="w-4 h-4 fill-current" />
                {hasSave ? 'Continua Carriera' : 'Inizia a Volare'}
              </span>
              <span className="text-xs font-mono opacity-80 tabular-nums">
                {getAirportById(career.currentAirportId).icao} · €{career.moneyEur.toLocaleString('it-IT')}
              </span>
            </button>

            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={onOpenFreeFlight}
                className="min-h-[44px] px-3 py-2 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-100 text-xs sm:text-sm font-semibold whitespace-nowrap"
              >
                Volo Libero
              </button>

              <button
                type="button"
                onClick={() => onNavigate(ScreenId.CAREER_HUB)}
                className="min-h-[44px] px-3 py-2 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-100 text-xs sm:text-sm font-semibold whitespace-nowrap"
              >
                Modalità Carriera
              </button>

              <button
                type="button"
                onClick={() => onNavigate(ScreenId.HANGAR)}
                className="min-h-[44px] px-3 py-2 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-100 text-xs sm:text-sm font-semibold whitespace-nowrap"
              >
                Hangar ({career.ownedAircraft.length}/{AIRCRAFT_FLEET.length})
              </button>

              <button
                type="button"
                onClick={() => onNavigate(ScreenId.WORLD_MAP)}
                className="min-h-[44px] px-3 py-2 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-700 text-sky-200 text-xs sm:text-sm font-semibold flex items-center justify-center gap-1.5 whitespace-nowrap"
              >
                <MapIcon className="w-3.5 h-3.5 text-sky-400" />
                Mappa Interattiva
              </button>

              <button
                type="button"
                onClick={() => (hasSave ? setConfirmNew(true) : onNewCareer())}
                className="min-h-[44px] px-3 py-2 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 text-xs font-medium whitespace-nowrap"
              >
                Nuova Partita
              </button>

              <button
                type="button"
                onClick={() => onNavigate(ScreenId.SETTINGS)}
                className="min-h-[44px] px-3 py-2 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 text-xs font-medium flex items-center justify-center gap-1.5 whitespace-nowrap"
              >
                <Settings className="w-3.5 h-3.5" />
                Impostazioni
              </button>
            </div>
          </div>
        )}

        {/* Single flat control-hint line */}
        <div className="bg-slate-950/80 border border-slate-800 rounded px-3 py-1 text-[11px] font-mono text-slate-300 text-center">
          W/S Cabra/Picchia · ↑/↓ Potenza · V/F Flap · G Carrello · P Autopilot · M Mappa Aeronautica · Esc Pausa
        </div>
      </div>
    </div>
  );
};

// ---------------------------------------------------------------------------
// SHARED TOP HEADER FOR FULL-SCREEN MANAGEMENT / SETUP VIEWS
// ---------------------------------------------------------------------------
const SubScreenShell: React.FC<{
  title: string;
  subtitle?: string;
  career: CareerSaveData;
  onBack: () => void;
  rightAction?: React.ReactNode;
  fullBleed?: boolean;
  children: React.ReactNode;
}> = ({ title, subtitle, career, onBack, rightAction, fullBleed = false, children }) => (
  <div className="fixed inset-0 z-30 bg-slate-950/94 flex flex-col">
    <header className="flex items-center justify-between gap-4 px-4 sm:px-6 h-14 border-b border-slate-800 bg-slate-950 shrink-0">
      <div className="flex items-center gap-3 min-w-0">
        <button
          type="button"
          onClick={onBack}
          className="min-h-[40px] min-w-[40px] px-2.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-200 flex items-center justify-center gap-1.5 text-xs font-medium shrink-0"
        >
          <ArrowLeft className="w-4 h-4" />
          <span className="hidden sm:inline">Indietro</span>
        </button>
        <div className="min-w-0">
          <h1 className="text-base sm:text-lg font-bold text-white truncate">{title}</h1>
          {subtitle && <p className="text-[11px] text-slate-400 truncate hidden sm:block">{subtitle}</p>}
        </div>
      </div>

      <div className="flex items-center gap-3 shrink-0">
        <div className="text-right font-mono text-xs tabular-nums">
          <div className="text-amber-400 font-bold">€{career.moneyEur.toLocaleString('it-IT')}</div>
          <div className="text-[10px] text-slate-400">
            Rep {career.reputation}/100 · {getAirportById(career.currentAirportId).icao}
          </div>
        </div>
        {rightAction}
      </div>
    </header>

    {fullBleed ? (
      <main className="flex-1 min-h-0 flex flex-col p-2 sm:p-4 overflow-hidden">
        {children}
      </main>
    ) : (
      <main className="flex-1 overflow-y-auto custom-scroll p-4 sm:p-6">
        <div className="max-w-6xl mx-auto">{children}</div>
      </main>
    )}
  </div>
);

// ---------------------------------------------------------------------------
// 2. CAREER HUB – TORRE DI CONTROLLO (LOCKED DAILY MISSION DISPATCH)
// ---------------------------------------------------------------------------
interface CareerHubProps {
  career: CareerSaveData;
  onBack: () => void;
  onOpenEconomy: () => void;
  onOpenHangar: () => void;
  onAcceptAtcMission: (assignment: CareerAtcAssignment) => void;
}

export const CareerHubScreen: React.FC<CareerHubProps> = ({
  career,
  onBack,
  onOpenEconomy,
  onOpenHangar,
  onAcceptAtcMission,
}) => {
  const [careerMapOpen, setCareerMapOpen] = useState(false);
  const currentAirport = getAirportById(career.currentAirportId);
  const activeOwned =
    career.ownedAircraft.find((a) => a.aircraftId === career.selectedAircraftId) ||
    career.ownedAircraft[0];
  const activeSpec = getAircraftById(activeOwned.aircraftId);
  const avgHealth = Math.round(
    (activeOwned.airframeHealth + activeOwned.engineHealth + activeOwned.gearHealth) / 3
  );

  const assignment =
    career.dailyAtcAssignment && career.dailyAtcAssignment.departureId === career.currentAirportId
      ? career.dailyAtcAssignment
      : generateDailyAtcAssignment(career);

  const depAirport = getAirportById(assignment.departureId);
  const destAirport = getAirportById(assignment.destinationId);
  const routeGeo = computeWorldBearingAndDistance(
    depAirport.worldXM,
    depAirport.worldYM,
    destAirport.worldXM,
    destAirport.worldYM
  );
  const distKm = routeGeo.directDistanceKm;
  const distNm = routeGeo.directDistanceNm;

  const wx = assignment.contract.weather;
  const windDir = wx.windDirectionDeg ?? destAirport.typicalWindDirDeg;
  const windSpd = wx.windSpeedKt ?? Math.round(Math.hypot(wx.headwindKt, wx.crosswindKt));

  const minFuelNeededKg = Math.max(15, Math.round(activeSpec.maxFuelKg * 0.14));
  const lowFuel = activeOwned.fuelKg < minFuelNeededKg;
  const runwayOk =
    depAirport.runwayLengthM >= activeSpec.minRunwayM &&
    destAirport.runwayLengthM >= activeSpec.minRunwayM;

  const routeSpanBadge =
    distNm < 18 ? 'TRATTA BREVE' : distNm < 38 ? 'TRATTA MEDIA' : 'TRATTA LUNGA';

  return (
    <SubScreenShell
      title="Modalità Carriera · Torre di Controllo"
      subtitle={`${career.pilotName} · Giorno Operativo #${assignment.dayNumber} · Base attuale: ${currentAirport.name}`}
      career={career}
      onBack={onBack}
      rightAction={
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setCareerMapOpen(true)}
            className="min-h-[40px] px-3 py-2 rounded-lg bg-fuchsia-500/20 hover:bg-fuchsia-500/30 border border-fuchsia-400/70 text-xs font-bold text-fuchsia-200 flex items-center gap-1.5 whitespace-nowrap cursor-pointer"
          >
            <MapIcon className="w-3.5 h-3.5 text-fuchsia-300" />
            <span className="hidden sm:inline">Carta Rotta ATC</span>
            <span className="sm:hidden">Carta</span>
          </button>
          <button
            type="button"
            onClick={onOpenEconomy}
            className="min-h-[40px] px-3.5 py-2 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-700 text-xs font-semibold text-amber-300 whitespace-nowrap"
          >
            Gestione Economica
          </button>
        </div>
      }
    >
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Active Aircraft & Pilot Status */}
        <div className="lg:col-span-4 space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-xs text-slate-400">Aeromobile Assegnato</div>
                <h2 className="text-base font-bold text-white">{activeSpec.name}</h2>
              </div>
              <button
                type="button"
                onClick={onOpenHangar}
                className="min-h-[36px] px-3 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-200 whitespace-nowrap"
              >
                Cambia in Hangar
              </button>
            </div>

            <AircraftPixelPreview aircraft={activeSpec} />

            <div className="grid grid-cols-2 gap-2 text-xs font-mono tabular-nums pt-1">
              <div className="text-slate-300">
                Carburante:{' '}
                <span className={lowFuel ? 'text-red-400 font-bold' : 'text-white font-semibold'}>
                  {activeOwned.fuelKg}/{activeSpec.maxFuelKg} kg
                </span>
              </div>
              <div className="text-slate-300">
                Efficienza:{' '}
                <span
                  className={
                    avgHealth < 70 ? 'text-amber-400 font-semibold' : 'text-emerald-400 font-semibold'
                  }
                >
                  {avgHealth}%
                </span>
              </div>
              <div className="text-slate-300">
                Pista min: <span className="text-white">{activeSpec.minRunwayM} m</span>
              </div>
              <div className="text-slate-300">
                Ore volo: <span className="text-white">{activeOwned.flightHours} h</span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={onOpenEconomy}
                className="min-h-[42px] px-3 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-amber-300 flex items-center justify-center gap-1.5 whitespace-nowrap"
              >
                <Fuel className="w-3.5 h-3.5" />
                Rifornisci / Ripara
              </button>
              <button
                type="button"
                onClick={onOpenHangar}
                className="min-h-[42px] px-3 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 flex items-center justify-center gap-1.5 whitespace-nowrap"
              >
                <Compass className="w-3.5 h-3.5 text-sky-400" />
                Flotta Hangar
              </button>
            </div>
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-2 text-xs">
            <h3 className="text-sm font-bold text-white">Statistiche & Licenze</h3>
            <div className="text-slate-300 font-mono tabular-nums">
              Atterraggi sicuri: {career.safeLandings} · Voli totali: {career.totalFlights} · Tempo:{' '}
              {career.totalFlightMinutes} min
            </div>
            <div className="text-slate-400 pt-1">
              Licenze conseguite:{' '}
              <span className="text-slate-100 font-medium">
                {career.unlockedLicenses.map((l) => LICENSES_INFO[l].name).join(' · ')}
              </span>
            </div>
          </div>
        </div>

        {/* Right Column: Official Control Tower Daily Flight Plan (Destination Locked) */}
        <div className="lg:col-span-8 space-y-4">
          <div className="bg-slate-900 border border-amber-500/50 rounded-2xl p-5 space-y-4 avionics-panel">
            {/* Dispatch Header */}
            <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-lg bg-amber-500/15 border border-amber-400/60 flex items-center justify-center text-amber-300 shrink-0">
                  <Radio className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex flex-wrap items-center gap-2 text-[11px] font-mono">
                    <span className="text-amber-300 font-bold">
                      TORRE DI CONTROLLO {depAirport.icao}
                    </span>
                    <span className="text-slate-400">·</span>
                    <span className="text-sky-300 font-semibold">
                      FREQ {assignment.towerFrequencyMhz} MHz
                    </span>
                    <span className="text-slate-400">·</span>
                    <span className="text-slate-200">NOMINATIVO {assignment.callsign}</span>
                  </div>
                  <h2 className="text-lg sm:text-xl font-bold text-white mt-0.5">
                    Piano di Volo Giornaliero · Giorno #{assignment.dayNumber}
                  </h2>
                </div>
              </div>

              <div className="flex items-center gap-2 font-mono text-[10.5px]">
                <span className="px-2 py-1 rounded bg-sky-950/90 border border-sky-500/60 text-sky-200 font-bold">
                  {routeSpanBadge}
                </span>
                <span className="px-2 py-1 rounded bg-amber-950/90 border border-amber-500/70 text-amber-200 font-bold flex items-center gap-1">
                  <Lock className="w-3 h-3" />
                  DESTINAZIONE BLOCCATA
                </span>
              </div>
            </div>

            {/* Mission Title & Operational Summary */}
            <div className="bg-slate-950/90 border border-slate-800 rounded-xl p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="space-y-1">
                <div className="text-xs font-mono text-slate-400">
                  ORDINE OPERATIVO · {LICENSES_INFO[assignment.contract.requiredLicense].name} ·
                  DIFFICOLTÀ {assignment.contract.difficulty}/5
                </div>
                <div className="text-base font-bold text-white">{assignment.contract.title}</div>
                <p className="text-xs text-slate-300">{assignment.contract.description}</p>
              </div>
              <div className="text-left sm:text-right font-mono tabular-nums shrink-0">
                <div className="text-xl font-bold text-emerald-400">
                  +€{assignment.contract.rewardEur.toLocaleString('it-IT')}
                </div>
                <div className="text-xs text-slate-400">
                  +{assignment.contract.reputationGain} Reputazione
                </div>
              </div>
            </div>

            {/* 6-Cell Official Flight Plan Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 font-mono text-xs tabular-nums">
              <div className="bg-slate-950 border border-slate-800 rounded-xl p-3 space-y-1">
                <span className="text-[10px] text-slate-400 block">1. AEROPORTO DI PARTENZA</span>
                <div className="text-sm font-bold text-amber-300">
                  {depAirport.icao} · {depAirport.city}
                </div>
                <div className="text-[11px] text-slate-300">
                  Pista Decollo:{' '}
                  <strong className="text-white">RWY {assignment.departureRunwayId}</strong> (
                  {String(assignment.departureRunwayHeadingDeg).padStart(3, '0')}°)
                </div>
                <div className="text-[10.5px] text-slate-400">
                  Elev. {Math.round(depAirport.elevationM * M_TO_FT)} FT · {depAirport.runwayLengthM} m
                </div>
              </div>

              <div className="bg-slate-950 border border-emerald-500/40 rounded-xl p-3 space-y-1">
                <span className="text-[10px] text-emerald-300 block">
                  2. AEROPORTO DI DESTINAZIONE
                </span>
                <div className="text-sm font-bold text-emerald-300">
                  {destAirport.icao} · {destAirport.city}
                </div>
                <div className="text-[11px] text-slate-200">
                  Pista di Arrivo:{' '}
                  <strong className="text-emerald-200">RWY {assignment.destinationRunwayId}</strong> (
                  {String(assignment.destinationRunwayHeadingDeg).padStart(3, '0')}°)
                </div>
                <div className="text-[10.5px] text-slate-400">
                  Elev. {Math.round(destAirport.elevationM * M_TO_FT)} FT · {destAirport.runwayLengthM} m
                </div>
              </div>

              <div className="bg-slate-950 border border-slate-800 rounded-xl p-3 space-y-1">
                <span className="text-[10px] text-slate-400 block">3. ROTTA ASSEGNATA</span>
                <div className="text-sm font-bold text-sky-300">{assignment.routeCode}</div>
                <div className="text-[11px] text-slate-200">
                  Distanza: <strong>{distNm.toFixed(1)} NM</strong> ({Math.round(distKm)} km)
                </div>
                <div className="text-[10.5px] text-slate-400">
                  Direzione: {String(Math.round(routeGeo.bearingDeg)).padStart(3, '0')}° (
                  {bearingCardinalIt(routeGeo.bearingDeg)})
                </div>
              </div>

              <div className="bg-slate-950 border border-slate-800 rounded-xl p-3 space-y-1">
                <span className="text-[10px] text-slate-400 block">
                  4. QUOTA DI CROCIERA CONSIGLIATA
                </span>
                <div className="text-base font-extrabold text-cyan-300">
                  {assignment.recommendedCruiseAltFt.toLocaleString('it-IT')} FT
                </div>
                <div className="text-[10.5px] text-slate-300">
                  Compatibile con AUTOPILOT ON in crociera
                </div>
              </div>

              <div className="bg-slate-950 border border-slate-800 rounded-xl p-3 space-y-1">
                <span className="text-[10px] text-slate-400 block">5. METEO & VENTO PREVISTO</span>
                <div className="text-xs font-bold text-white">
                  {WEATHER_LABELS[wx.type]} · {TIME_LABELS[wx.timeOfDay]}
                </div>
                <div className="text-[11px] text-sky-200 flex items-center gap-1">
                  <Wind className="w-3.5 h-3.5 text-sky-400" />
                  {String(Math.round(windDir)).padStart(3, '0')}° / {Math.round(windSpd)} kt
                  {wx.gustIntensityKt >= 5 ? ` (Raff. +${Math.round(wx.gustIntensityKt)}kt)` : ''}
                </div>
                <div className="text-[10.5px] text-slate-400">
                  Visibilità {wx.visibilityKm} km · Turb. {Math.round(wx.turbulence * 100)}%
                </div>
              </div>

              <div className="bg-slate-950 border border-slate-800 rounded-xl p-3 space-y-1">
                <span className="text-[10px] text-slate-400 block">6. CARICO ASSEGNATO</span>
                <div className="text-xs font-bold text-white">
                  {assignment.contract.passengers > 0
                    ? `${assignment.contract.passengers} Passeggeri`
                    : 'Volo Cargo Tecnico'}
                </div>
                <div className="text-[11px] text-slate-300">
                  Merci / Bagagli: {assignment.contract.cargoKg} kg
                </div>
                <div className="text-[10.5px] text-slate-400">
                  Adattato a {activeSpec.name}
                </div>
              </div>
            </div>

            {/* Special Tower Instructions */}
            <div className="bg-amber-950/30 border border-amber-500/45 rounded-xl p-3.5 space-y-1">
              <div className="text-[10.5px] font-mono font-bold text-amber-300 tracking-wide">
                ISTRUZIONI PARTICOLARI DELLA TORRE DI CONTROLLO
              </div>
              <p className="text-xs text-slate-100 leading-relaxed">
                {assignment.specialInstructions}
              </p>
              <p className="text-[11px] text-slate-400 font-mono pt-0.5">
                {assignment.routeSummary} · La destinazione non è modificabile dal pilota in Modalità Carriera.
              </p>
            </div>

            {lowFuel && (
              <div className="bg-red-950/60 border border-red-500/70 rounded-lg px-3.5 py-2.5 text-xs text-red-200 flex items-center justify-between gap-3">
                <span>
                  Carburante insufficiente a bordo ({activeOwned.fuelKg} kg). Effettua rifornimento prima del decollo.
                </span>
                <button
                  type="button"
                  onClick={onOpenEconomy}
                  className="px-3 py-1.5 rounded bg-amber-500 text-slate-950 font-bold text-xs whitespace-nowrap"
                >
                  Rifornisci Ora
                </button>
              </div>
            )}

            {!runwayOk && (
              <div className="bg-red-950/60 border border-red-500/70 rounded-lg px-3.5 py-2.5 text-xs text-red-200">
                L&apos;aeromobile selezionato ({activeSpec.name}) richiede almeno {activeSpec.minRunwayM} m di pista. Seleziona un velivolo adatto in Hangar.
              </div>
            )}

            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-1">
              <button
                type="button"
                onClick={() => setCareerMapOpen(true)}
                className="min-h-[44px] px-4 py-2 rounded-xl bg-slate-950 hover:bg-slate-800 border border-fuchsia-500/50 text-xs font-bold text-fuchsia-200 flex items-center justify-center gap-2 whitespace-nowrap cursor-pointer"
              >
                <MapIcon className="w-4 h-4 text-fuchsia-300" />
                Ispeziona Rotta ATC su Mappa Aeronautica
              </button>

              <button
                type="button"
                disabled={lowFuel || !runwayOk}
                onClick={() => onAcceptAtcMission(assignment)}
                className={`min-h-[48px] px-6 py-3 rounded-xl text-sm font-bold flex items-center justify-center gap-2 whitespace-nowrap ${
                  !lowFuel && runwayOk
                    ? 'bg-amber-500 hover:bg-amber-400 text-slate-950 cursor-pointer'
                    : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                }`}
              >
                <Play className="w-4 h-4 fill-current" />
                Ricevi Piano di Volo & Prepara Decollo
              </button>
            </div>
          </div>
        </div>
      </div>

      {careerMapOpen && (
        <InteractiveWorldMap
          airports={AIRPORTS}
          currentWorldXM={depAirport.worldXM}
          currentWorldYM={depAirport.worldYM}
          headingDeg={routeGeo.bearingDeg}
          departureAirportId={depAirport.id}
          activeDestinationId={destAirport.id}
          aircraft={activeSpec}
          isInFlight={false}
          isCareerMode={true}
          destinationLocked={true}
          atcAssignment={assignment}
          allowChangeDeparture={false}
          onConfirmDestination={() => setCareerMapOpen(false)}
          onClose={() => setCareerMapOpen(false)}
        />
      )}
    </SubScreenShell>
  );
};

// ---------------------------------------------------------------------------
// 2B. CONTROL TOWER BRIEFING & VHF RADIO LOG MODAL (PRE-TAKEOFF & IN-FLIGHT)
// ---------------------------------------------------------------------------
export interface AtcTowerBriefingModalProps {
  assignment: CareerAtcAssignment;
  aircraftName: string;
  hasTakenOff: boolean;
  atcHistory: AtcRadioMessage[];
  onAcknowledge: () => void;
}

export const AtcTowerBriefingModal: React.FC<AtcTowerBriefingModalProps> = ({
  assignment,
  aircraftName,
  hasTakenOff,
  atcHistory,
  onAcknowledge,
}) => {
  const dep = getAirportById(assignment.departureId);
  const dest = getAirportById(assignment.destinationId);
  const routeGeo = computeWorldBearingAndDistance(
    dep.worldXM,
    dep.worldYM,
    dest.worldXM,
    dest.worldYM
  );
  const distNm = routeGeo.directDistanceNm;
  const distKm = routeGeo.directDistanceKm;
  const wx = assignment.contract.weather;
  const windDir = wx.windDirectionDeg ?? dep.typicalWindDirDeg;
  const windSpd = wx.windSpeedKt ?? Math.round(Math.hypot(wx.headwindKt, wx.crosswindKt));

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/88 flex items-center justify-center p-3 sm:p-5 overflow-y-auto">
      <div className="bg-slate-900 border-2 border-amber-500/70 rounded-2xl p-4 sm:p-6 max-w-2xl w-full avionics-panel space-y-4">
        {/* Header */}
        <div className="flex flex-wrap items-start justify-between gap-3 border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-400 flex items-center justify-center text-amber-300 shrink-0">
              <Radio className="w-5 h-5" />
            </div>
            <div>
              <div className="text-[11px] font-mono text-amber-300 font-bold">
                COMUNICAZIONE UFFICIALE TORRE DI CONTROLLO · VHF {assignment.towerFrequencyMhz} MHz
              </div>
              <h2 className="text-lg sm:text-xl font-bold text-white">
                {hasTakenOff
                  ? `Dispaccio & Radio Torre ATC · ${assignment.callsign}`
                  : `Autorizzazione Piano di Volo · Giorno #${assignment.dayNumber}`}
              </h2>
            </div>
          </div>

          <span className="px-2.5 py-1 rounded bg-slate-950 border border-amber-500/60 text-[10.5px] font-mono font-bold text-amber-200 flex items-center gap-1">
            <Lock className="w-3 h-3" />
            ROTTA ASSEGNATA ATC
          </span>
        </div>

        {/* Flight Plan Core Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 font-mono text-xs tabular-nums">
          <div className="bg-slate-950 border border-slate-800 rounded-lg p-2.5">
            <span className="text-[9.5px] text-slate-400 block">PARTENZA</span>
            <span className="text-sm font-bold text-amber-300">{dep.icao}</span>
            <span className="text-[10.5px] text-slate-300 block truncate">{dep.city}</span>
            <span className="text-[10px] text-slate-400 block">
              RWY {assignment.departureRunwayId} ({String(assignment.departureRunwayHeadingDeg).padStart(3, '0')}°)
            </span>
          </div>

          <div className="bg-slate-950 border border-emerald-500/50 rounded-lg p-2.5">
            <span className="text-[9.5px] text-emerald-300 block">DESTINAZIONE</span>
            <span className="text-sm font-bold text-emerald-300">{dest.icao}</span>
            <span className="text-[10.5px] text-slate-200 block truncate">{dest.city}</span>
            <span className="text-[10px] text-emerald-200/90 block">
              RWY {assignment.destinationRunwayId} ({String(assignment.destinationRunwayHeadingDeg).padStart(3, '0')}°)
            </span>
          </div>

          <div className="bg-slate-950 border border-slate-800 rounded-lg p-2.5">
            <span className="text-[9.5px] text-slate-400 block">ROTTA & DISTANZA</span>
            <span className="text-xs font-bold text-sky-300 block truncate">{assignment.routeCode}</span>
            <span className="text-[11px] text-white font-semibold">
              {distNm.toFixed(1)} NM ({Math.round(distKm)} km)
            </span>
            <span className="text-[10px] text-slate-400 block">
              PRUA {String(Math.round(routeGeo.bearingDeg)).padStart(3, '0')}°
            </span>
          </div>

          <div className="bg-slate-950 border border-slate-800 rounded-lg p-2.5">
            <span className="text-[9.5px] text-slate-400 block">QUOTA CROCIERA</span>
            <span className="text-sm font-extrabold text-cyan-300">
              {assignment.recommendedCruiseAltFt.toLocaleString('it-IT')} FT
            </span>
            <span className="text-[10.5px] text-slate-300 block truncate">{aircraftName}</span>
            <span className="text-[10px] text-slate-400 block">
              Vento {String(Math.round(windDir)).padStart(3, '0')}°/{Math.round(windSpd)}kt
            </span>
          </div>
        </div>

        {/* Special Instructions */}
        <div className="bg-amber-950/35 border border-amber-500/50 rounded-xl p-3 space-y-1">
          <div className="text-[10px] font-mono font-bold text-amber-300">
            ISTRUZIONI PARTICOLARI TORRE DI CONTROLLO
          </div>
          <p className="text-xs text-slate-100 leading-relaxed">{assignment.specialInstructions}</p>
        </div>

        {/* Live VHF Radio Transcript */}
        <div className="bg-slate-950 border border-slate-800 rounded-xl p-3 space-y-2">
          <div className="flex items-center justify-between text-[10.5px] font-mono">
            <span className="text-sky-300 font-bold">TRASMISSIONI RADIO TORRE / CONTROLLO</span>
            <span className="text-slate-400">{WEATHER_LABELS[wx.type]} · Vis. {wx.visibilityKm} km</span>
          </div>

          <div className="max-h-36 overflow-y-auto custom-scroll space-y-1.5 pr-1">
            {atcHistory.length > 0 ? (
              atcHistory.map((msg) => (
                <div
                  key={msg.id}
                  className="bg-slate-900/90 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs"
                >
                  <div className="flex items-center justify-between text-[10px] font-mono text-amber-300">
                    <span>
                      {msg.sender} ({msg.frequencyMhz} MHz)
                    </span>
                    <span className="text-slate-500">
                      T+{Math.floor(msg.timestampSec / 60)}m{String(Math.round(msg.timestampSec % 60)).padStart(2, '0')}s
                    </span>
                  </div>
                  <p className="text-slate-100 mt-0.5 leading-snug">&ldquo;{msg.text}&rdquo;</p>
                </div>
              ))
            ) : (
              <div className="bg-slate-900/90 border border-slate-800 rounded-lg px-2.5 py-2 text-xs text-slate-200 leading-snug">
                &ldquo;{assignment.callsign}, qui {dep.city} Torre su {assignment.towerFrequencyMhz}. Piano di volo approvato verso {dest.name} ({dest.icao}) via rotta {assignment.routeCode}. Pista in uso RWY {assignment.departureRunwayId}, vento {String(Math.round(windDir)).padStart(3, '0')} gradi {Math.round(windSpd)} nodi, salita iniziale a {assignment.recommendedCruiseAltFt} piedi. Autorizzato al decollo.&rdquo;
              </div>
            )}
          </div>
        </div>

        <button
          type="button"
          onClick={onAcknowledge}
          className="w-full min-h-[46px] px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-sm flex items-center justify-center gap-2 cursor-pointer"
        >
          <CheckCircle2 className="w-4 h-4" />
          {hasTakenOff
            ? 'Torna ai Comandi di Volo'
            : `Ricevuto Torre · Allinea RWY ${assignment.departureRunwayId} e Decolla`}
        </button>
      </div>
    </div>
  );
};

// ---------------------------------------------------------------------------
// 3. ECONOMIC MANAGEMENT (FUEL, MAINTENANCE, LICENSES, LEDGER)
// ---------------------------------------------------------------------------
interface EconomyScreenProps {
  career: CareerSaveData;
  onBack: () => void;
  onRefuel: (aircraftId: string, targetFuelKg: number) => void;
  onRepair: (aircraftId: string) => void;
  onBuyLicense: (licenseId: LicenseId) => void;
}

export const EconomyScreen: React.FC<EconomyScreenProps> = ({
  career,
  onBack,
  onRefuel,
  onRepair,
  onBuyLicense,
}) => {
  const airport = getAirportById(career.currentAirportId);
  const owned =
    career.ownedAircraft.find((a) => a.aircraftId === career.selectedAircraftId) ||
    career.ownedAircraft[0];
  const spec = getAircraftById(owned.aircraftId);

  const [fuelTarget, setFuelTarget] = useState<number>(spec.maxFuelKg);
  const addedFuel = Math.max(0, fuelTarget - owned.fuelKg);
  const fuelCost = Math.round(addedFuel * airport.fuelPricePerKg);
  const repairCost = calculateMaintenanceCost(owned);

  return (
    <SubScreenShell
      title="Gestione Economica & Licenze"
      subtitle="Rifornimento carburante, manutenzione flotta, brevetti di volo e bilancio"
      career={career}
      onBack={onBack}
    >
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-6 space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <Fuel className="w-4 h-4 text-amber-400" />
                Rifornimento ({spec.name})
              </h2>
              <span className="text-xs font-mono text-slate-400 tabular-nums">
                €{airport.fuelPricePerKg.toFixed(2)}/kg @ {airport.icao}
              </span>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between text-xs font-mono tabular-nums text-slate-300">
                <span>Attuale: {owned.fuelKg} kg</span>
                <span>Obiettivo: {Math.max(owned.fuelKg, fuelTarget)} kg / {spec.maxFuelKg} kg</span>
              </div>
              <input
                type="range"
                min={owned.fuelKg}
                max={spec.maxFuelKg}
                value={Math.max(owned.fuelKg, fuelTarget)}
                onChange={(e) => setFuelTarget(Number(e.target.value))}
                className="w-full accent-amber-500 h-2 bg-slate-800 rounded-lg"
              />
            </div>

            <div className="flex items-center justify-between pt-2">
              <span className="text-xs font-mono text-slate-300 tabular-nums">
                +{addedFuel} kg · Costo: <strong className="text-amber-300">€{fuelCost.toLocaleString('it-IT')}</strong>
              </span>
              <button
                type="button"
                disabled={addedFuel <= 0 || career.moneyEur < fuelCost}
                onClick={() => onRefuel(spec.id, fuelTarget)}
                className={`min-h-[42px] px-4 py-2 rounded-lg text-xs font-bold whitespace-nowrap ${
                  addedFuel > 0 && career.moneyEur >= fuelCost
                    ? 'bg-amber-500 hover:bg-amber-400 text-slate-950'
                    : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                }`}
              >
                Acquista Carburante
              </button>
            </div>
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <Wrench className="w-4 h-4 text-sky-400" />
              Stato Tecnico & Manutenzione
            </h2>

            <div className="space-y-2 text-xs font-mono tabular-nums">
              <div className="flex justify-between text-slate-300">
                <span>Cellula & Ali</span>
                <span className={owned.airframeHealth < 75 ? 'text-amber-400' : 'text-emerald-400'}>
                  {owned.airframeHealth}%
                </span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>Propulsore & Impianto</span>
                <span className={owned.engineHealth < 75 ? 'text-amber-400' : 'text-emerald-400'}>
                  {owned.engineHealth}%
                </span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>Carrello & Freni</span>
                <span className={owned.gearHealth < 75 ? 'text-amber-400' : 'text-emerald-400'}>
                  {owned.gearHealth}%
                </span>
              </div>
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-slate-800">
              <span className="text-xs font-mono text-slate-300 tabular-nums">
                Revisione completa: <strong className="text-white">€{repairCost.toLocaleString('it-IT')}</strong>
              </span>
              <button
                type="button"
                disabled={repairCost <= 0 || career.moneyEur < repairCost}
                onClick={() => onRepair(spec.id)}
                className={`min-h-[42px] px-4 py-2 rounded-lg text-xs font-bold whitespace-nowrap ${
                  repairCost > 0 && career.moneyEur >= repairCost
                    ? 'bg-sky-500 hover:bg-sky-400 text-slate-950'
                    : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                }`}
              >
                {repairCost <= 0 ? 'Efficienza 100%' : 'Paga Manutenzione'}
              </button>
            </div>
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-3">
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-emerald-400" />
              Movimenti Finanziari Recenti
            </h2>
            <div className="space-y-2 max-h-56 overflow-y-auto custom-scroll divide-y divide-slate-800/80">
              {career.ledger.map((entry) => (
                <div key={entry.id} className="pt-2 first:pt-0 flex items-center justify-between gap-3 text-xs">
                  <span className="text-slate-300 truncate">{entry.label}</span>
                  <span
                    className={`font-mono font-semibold tabular-nums shrink-0 ${
                      entry.amountEur >= 0 ? 'text-emerald-400' : 'text-red-400'
                    }`}
                  >
                    {entry.amountEur >= 0 ? '+' : ''}€{entry.amountEur.toLocaleString('it-IT')}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="lg:col-span-6 space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
            <h2 className="text-base font-bold text-white">Accademia Aeronautica · Brevetti</h2>
            <div className="space-y-3">
              {(Object.keys(LICENSES_INFO) as LicenseId[]).map((licId) => {
                const info = LICENSES_INFO[licId];
                const unlocked = career.unlockedLicenses.includes(licId);
                const canAfford =
                  career.moneyEur >= info.priceEur &&
                  career.reputation >= info.minReputation &&
                  career.safeLandings >= info.minFlights;

                return (
                  <div
                    key={licId}
                    className="p-3.5 rounded-lg bg-slate-950/70 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                  >
                    <div className="space-y-1">
                      <div className="text-sm font-bold text-white">
                        {info.name} <span className="text-xs font-normal text-slate-400">· {info.fullName}</span>
                      </div>
                      <p className="text-xs text-slate-300">{info.description}</p>
                      <div className="text-[11px] font-mono text-slate-400 tabular-nums">
                        Requisiti: Rep {info.minReputation}/100 · {info.minFlights} atterraggi sicuri
                      </div>
                    </div>

                    <div className="shrink-0">
                      {unlocked ? (
                        <span className="text-xs font-mono text-emerald-400 font-semibold">
                          CONSEGUITA
                        </span>
                      ) : (
                        <button
                          type="button"
                          disabled={!canAfford}
                          onClick={() => onBuyLicense(licId)}
                          className={`min-h-[40px] px-3.5 py-2 rounded-lg text-xs font-bold font-mono tabular-nums whitespace-nowrap ${
                            canAfford
                              ? 'bg-amber-500 hover:bg-amber-400 text-slate-950'
                              : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                          }`}
                        >
                          €{info.priceEur.toLocaleString('it-IT')}
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </SubScreenShell>
  );
};

// ---------------------------------------------------------------------------
// 4. HANGAR & AIRCRAFT SELECTION (ALL 7 AIRCRAFT)
// ---------------------------------------------------------------------------
interface HangarScreenProps {
  career: CareerSaveData;
  onBack: () => void;
  onSelectCareerAircraft: (aircraftId: string) => void;
  onBuyAircraft: (aircraftId: string) => void;
  onLaunchFreeFlightWith: (aircraftId: string) => void;
}

export const HangarScreen: React.FC<HangarScreenProps> = ({
  career,
  onBack,
  onSelectCareerAircraft,
  onBuyAircraft,
  onLaunchFreeFlightWith,
}) => {
  return (
    <SubScreenShell
      title="Hangar & Flotta Aeromobili"
      subtitle="Tutti i 7 velivoli disponibili per Volo Libero o acquistabili in Modalità Carriera"
      career={career}
      onBack={onBack}
    >
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {AIRCRAFT_FLEET.map((ac) => {
          const owned = career.ownedAircraft.find((o) => o.aircraftId === ac.id);
          const isSelected = career.selectedAircraftId === ac.id;
          const hasLic = career.unlockedLicenses.includes(ac.requiredLicense);
          const canBuy = !owned && hasLic && career.moneyEur >= ac.priceEur;

          return (
            <div
              key={ac.id}
              className={`bg-slate-900 rounded-xl p-4 border space-y-3 flex flex-col justify-between ${
                isSelected ? 'border-amber-500/80' : 'border-slate-800'
              }`}
            >
              <div className="space-y-3">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <div className="text-xs text-slate-400">
                      {ac.category} · {LICENSES_INFO[ac.requiredLicense].name}
                    </div>
                    <h2 className="text-lg font-bold text-white">{ac.name}</h2>
                  </div>
                  <div className="text-right font-mono text-xs tabular-nums">
                    {owned ? (
                      <span className="text-emerald-400 font-semibold">IN FLOTTA</span>
                    ) : (
                      <span className="text-amber-300 font-bold">
                        €{ac.priceEur.toLocaleString('it-IT')}
                      </span>
                    )}
                  </div>
                </div>

                <AircraftPixelPreview aircraft={ac} />

                <p className="text-xs text-slate-300">{ac.description}</p>

                <div className="grid grid-cols-3 gap-2 pt-1 text-xs font-mono tabular-nums text-slate-300 border-t border-slate-800">
                  <div>
                    <span className="text-slate-500 block text-[10px]">CROCIERA / MAX</span>
                    {ac.vCruiseKt} / {ac.vMaxKt} kt
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[10px]">STALLO</span>
                    {ac.vStallKt} kt
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[10px]">PISTA MIN</span>
                    {ac.minRunwayM} m
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[10px]">MTOW MAX</span>
                    {(ac.mtowKg / 1000).toFixed(1)} t
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[10px]">SERBATOIO</span>
                    {ac.maxFuelKg.toLocaleString('it-IT')} kg
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[10px]">CAPACITÀ</span>
                    {ac.passengerCapacity} PAX
                  </div>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2 pt-3 border-t border-slate-800">
                {owned ? (
                  <button
                    type="button"
                    onClick={() => onSelectCareerAircraft(ac.id)}
                    className={`flex-1 min-h-[42px] px-3 py-2 rounded-lg text-xs font-bold whitespace-nowrap ${
                      isSelected
                        ? 'bg-emerald-500/20 border border-emerald-500/60 text-emerald-300'
                        : 'bg-amber-500 hover:bg-amber-400 text-slate-950'
                    }`}
                  >
                    {isSelected ? 'Attivo in Carriera' : 'Usa in Carriera'}
                  </button>
                ) : (
                  <button
                    type="button"
                    disabled={!canBuy}
                    onClick={() => onBuyAircraft(ac.id)}
                    className={`flex-1 min-h-[42px] px-3 py-2 rounded-lg text-xs font-bold whitespace-nowrap ${
                      canBuy
                        ? 'bg-amber-500 hover:bg-amber-400 text-slate-950'
                        : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                    }`}
                  >
                    {!hasLic ? `Richiede ${LICENSES_INFO[ac.requiredLicense].name}` : 'Acquista Aereo'}
                  </button>
                )}

                <button
                  type="button"
                  onClick={() => onLaunchFreeFlightWith(ac.id)}
                  className="min-h-[42px] px-3.5 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-100 text-xs font-semibold whitespace-nowrap"
                >
                  Prova in Volo Libero
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </SubScreenShell>
  );
};

// ---------------------------------------------------------------------------
// 5. INTERACTIVE AERONAUTICAL WORLD MAP SCREEN (FREE FLIGHT ROUTE PLANNING)
// ---------------------------------------------------------------------------
interface WorldMapScreenProps {
  career: CareerSaveData;
  initialDepartureId: string;
  initialDestinationId: string;
  onBack: () => void;
  onConfirmRoute: (departureId: string, destinationId: string) => void;
}

export const WorldMapScreen: React.FC<WorldMapScreenProps> = ({
  career,
  initialDepartureId,
  initialDestinationId,
  onBack,
  onConfirmRoute,
}) => {
  const dep = getAirportById(initialDepartureId);
  const destId = initialDestinationId === initialDepartureId ? 'lsza' : initialDestinationId;
  const dest = getAirportById(destId);
  const routeGeo = computeWorldBearingAndDistance(
    dep.worldXM,
    dep.worldYM,
    dest.worldXM,
    dest.worldYM
  );
  const activeAircraft = getAircraftById(career.selectedAircraftId);

  return (
    <SubScreenShell
      title="Mappa Interattiva · Volo Libero"
      subtitle="Trascina per esplorare, usa lo zoom, ispeziona piste e meteo e conferma la destinazione"
      career={career}
      onBack={onBack}
      fullBleed={true}
    >
      <div className="flex-1 min-h-0 flex flex-col">
        <InteractiveWorldMap
          airports={AIRPORTS}
          currentWorldXM={dep.worldXM}
          currentWorldYM={dep.worldYM}
          headingDeg={routeGeo.bearingDeg}
          departureAirportId={dep.id}
          activeDestinationId={dest.id}
          aircraft={activeAircraft}
          isInFlight={false}
          allowChangeDeparture={true}
          embedded={true}
          onConfirmDestination={(chosenDestId, chosenDepId) => {
            const finalDep = chosenDepId || dep.id;
            const finalDest =
              chosenDestId === finalDep
                ? AIRPORTS.find((a) => a.id !== finalDep)!.id
                : chosenDestId;
            onConfirmRoute(finalDep, finalDest);
          }}
        />
      </div>
    </SubScreenShell>
  );
};

// ---------------------------------------------------------------------------
// 6. FLIGHT PREPARATION & FREE FLIGHT DISPATCH SCREEN
// ---------------------------------------------------------------------------
interface FlightPrepScreenProps {
  career: CareerSaveData;
  initialSetup: FlightSetupConfig;
  onBack: () => void;
  onStartFlight: (finalSetup: FlightSetupConfig) => void;
}

export const FlightPrepScreen: React.FC<FlightPrepScreenProps> = ({
  career,
  initialSetup,
  onBack,
  onStartFlight,
}) => {
  const [setup, setSetup] = useState<FlightSetupConfig>(initialSetup);
  const [mapModalOpen, setMapModalOpen] = useState<boolean>(false);
  const isCareer = setup.mode === 'career';

  const aircraft = getAircraftById(setup.aircraftId);
  const dep = getAirportById(setup.departureId);
  const dest = getAirportById(setup.destinationId);

  const routeGeo = computeWorldBearingAndDistance(
    dep.worldXM,
    dep.worldYM,
    dest.worldXM,
    dest.worldYM
  );
  const distKm = Math.round(routeGeo.directDistanceKm);
  const distNm = routeGeo.directDistanceNm;

  const windDirDeg =
    setup.weather.windDirectionDeg ?? dest.typicalWindDirDeg;
  const windSpeedKt =
    setup.weather.windSpeedKt ??
    Math.round(Math.hypot(setup.weather.headwindKt, setup.weather.crosswindKt));
  const cloudCoverPct = Math.round((setup.weather.cloudCover ?? 0.25) * 100);

  const activeDestRunway = selectBestRunwayForWind(
    dest,
    windDirDeg,
    windSpeedKt,
    isCareer ? setup.atcAssignment?.destinationRunwayId : undefined
  );

  const totalMass = aircraft.emptyMassKg + setup.fuelKg + setup.payloadKg;
  const overMtow = totalMass > aircraft.mtowKg;
  const shortRunway =
    dep.runwayLengthM < aircraft.minRunwayM || dest.runwayLengthM < aircraft.minRunwayM;
  const enduranceMin = Math.round((setup.fuelKg / aircraft.fuelBurnKgPerHourCruise) * 60);

  const applyRouteAndRecomputeWind = (nextDepId: string, nextDestId: string) => {
    const nextDep = getAirportById(nextDepId);
    const safeDestId =
      nextDestId === nextDepId ? AIRPORTS.find((a) => a.id !== nextDepId)!.id : nextDestId;
    const nextDest = getAirportById(safeDestId);
    const nextGeo = computeWorldBearingAndDistance(
      nextDep.worldXM,
      nextDep.worldYM,
      nextDest.worldXM,
      nextDest.worldYM
    );
    const comp = decomposeWindOnTrack(windDirDeg, windSpeedKt, nextGeo.bearingDeg);
    setSetup((prev) => ({
      ...prev,
      departureId: nextDepId,
      destinationId: safeDestId,
      weather: {
        ...prev.weather,
        windDirectionDeg: windDirDeg,
        windSpeedKt,
        headwindKt: comp.headwindKt,
        crosswindKt: comp.crosswindKt,
      },
    }));
  };

  const handleWindChange = (nextDirDeg: number, nextSpdKt: number) => {
    const cleanDir = ((Math.round(nextDirDeg) % 360) + 360) % 360;
    const cleanSpd = Math.max(0, Math.round(nextSpdKt));
    const comp = decomposeWindOnTrack(cleanDir, cleanSpd, routeGeo.bearingDeg);
    setSetup((prev) => ({
      ...prev,
      weather: {
        ...prev.weather,
        windDirectionDeg: cleanDir,
        windSpeedKt: cleanSpd,
        headwindKt: comp.headwindKt,
        crosswindKt: comp.crosswindKt,
      },
    }));
  };

  const handleAircraftChange = (newId: string) => {
    const nextSpec = getAircraftById(newId);
    setSetup((prev) => ({
      ...prev,
      aircraftId: newId,
      fuelKg: Math.round(nextSpec.maxFuelKg * 0.65),
      passengers: Math.min(prev.passengers, nextSpec.passengerCapacity),
      payloadKg: Math.round(nextSpec.maxPayloadKg * 0.5),
    }));
  };

  return (
    <SubScreenShell
      title={isCareer ? 'Preparazione Volo Carriera · Torre ATC' : 'Configurazione Volo Libero'}
      subtitle={
        isCareer
          ? 'Piano di volo assegnato dalla Torre di Controllo · Verifica pesi e allineati in pista'
          : 'Scegli velivolo, apri la Mappa Interattiva per la rotta e regola vento e condizioni meteo'
      }
      career={career}
      onBack={onBack}
      rightAction={
        <button
          type="button"
          onClick={() => setMapModalOpen(true)}
          className={`min-h-[40px] px-3.5 py-2 rounded-lg border text-xs font-bold flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
            isCareer
              ? 'bg-fuchsia-500/20 hover:bg-fuchsia-500/30 border-fuchsia-400/70 text-fuchsia-200'
              : 'bg-sky-500/20 hover:bg-sky-500/30 border-sky-400/70 text-sky-200'
          }`}
        >
          <MapIcon className={`w-3.5 h-3.5 ${isCareer ? 'text-fuchsia-300' : 'text-sky-300'}`} />
          <span>{isCareer ? 'Carta Rotta ATC' : 'Mappa Aeronautica'}</span>
        </button>
      }
    >
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Aircraft, Route & Weight/Fuel */}
        <div className="lg:col-span-7 space-y-5">
          {isCareer && setup.atcAssignment && (
            <div className="bg-amber-950/35 border border-amber-500/60 rounded-xl p-4 space-y-2">
              <div className="flex flex-wrap items-center justify-between gap-2 font-mono text-xs">
                <span className="text-amber-300 font-bold flex items-center gap-1.5">
                  <Radio className="w-4 h-4" />
                  TORRE ATC · {setup.atcAssignment.callsign} ({setup.atcAssignment.towerFrequencyMhz} MHz)
                </span>
                <span className="px-2 py-0.5 rounded bg-slate-950 border border-amber-500/60 text-[10px] text-amber-200 font-bold flex items-center gap-1">
                  <Lock className="w-3 h-3" />
                  DESTINAZIONE BLOCCATA
                </span>
              </div>
              <div className="text-xs font-mono text-slate-200">
                Rotta: <strong className="text-sky-300">{setup.atcAssignment.routeCode}</strong> · Quota Crociera:{' '}
                <strong className="text-cyan-300">
                  {setup.atcAssignment.recommendedCruiseAltFt.toLocaleString('it-IT')} FT
                </strong>{' '}
                · Arrivo: <strong className="text-emerald-300">{dest.icao} RWY {setup.atcAssignment.destinationRunwayId}</strong>
              </div>
              <p className="text-xs text-slate-300">{setup.atcAssignment.specialInstructions}</p>
            </div>
          )}

          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <h2 className="text-base font-bold text-white">1. Velivolo & Pianificazione Rotta</h2>
              {!isCareer && (
                <button
                  type="button"
                  onClick={() => setMapModalOpen(true)}
                  className="min-h-[38px] px-3 py-1.5 rounded-lg bg-sky-500 hover:bg-sky-400 text-slate-950 text-xs font-bold flex items-center gap-1.5 whitespace-nowrap cursor-pointer"
                >
                  <MapIcon className="w-3.5 h-3.5" />
                  Scegli su Mappa Interattiva
                </button>
              )}
            </div>

            {!isCareer && (
              <div>
                <label className="block text-xs text-slate-400 mb-1">Seleziona Aeromobile</label>
                <select
                  value={setup.aircraftId}
                  onChange={(e) => handleAircraftChange(e.target.value)}
                  className="w-full min-h-[44px] bg-slate-950 border border-slate-700 rounded-lg px-3 text-sm text-white"
                >
                  {AIRCRAFT_FLEET.map((ac) => (
                    <option key={ac.id} value={ac.id}>
                      {ac.name} ({ac.category} · Pista min {ac.minRunwayM}m)
                    </option>
                  ))}
                </select>
              </div>
            )}

            <AircraftPixelPreview
              aircraft={aircraft}
              nightPreview={setup.weather.timeOfDay === TimeOfDay.NIGHT}
            />

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs text-slate-400 mb-1">Aeroporto di Partenza</label>
                <select
                  disabled={isCareer}
                  value={setup.departureId}
                  onChange={(e) => applyRouteAndRecomputeWind(e.target.value, setup.destinationId)}
                  className="w-full min-h-[44px] bg-slate-950 border border-slate-700 rounded-lg px-3 text-sm text-white disabled:opacity-70"
                >
                  {AIRPORTS.map((ap) => (
                    <option key={ap.id} value={ap.id}>
                      {ap.icao} · {ap.city} ({ap.runwayLengthM}m)
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs text-slate-400 mb-1">
                  Aeroporto di Destinazione {isCareer ? '(Assegnato Torre ATC)' : ''}
                </label>
                <select
                  disabled={isCareer}
                  value={setup.destinationId}
                  onChange={(e) => applyRouteAndRecomputeWind(setup.departureId, e.target.value)}
                  className="w-full min-h-[44px] bg-slate-950 border border-slate-700 rounded-lg px-3 text-sm text-white disabled:opacity-70"
                >
                  {AIRPORTS.filter((ap) => ap.id !== setup.departureId).map((ap) => (
                    <option key={ap.id} value={ap.id}>
                      {ap.icao} · {ap.city} ({ap.runwayLengthM}m)
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Active Runway & Bearing Strip */}
            <div className="grid grid-cols-3 gap-2 p-3 rounded-lg bg-slate-950 border border-slate-800 text-xs font-mono tabular-nums">
              <div>
                <span className="text-[10px] text-slate-500 block">PRUA ROTTA</span>
                <span className="text-sky-300 font-bold">
                  {String(Math.round(routeGeo.bearingDeg)).padStart(3, '0')}° ({bearingCardinalIt(routeGeo.bearingDeg)})
                </span>
              </div>
              <div>
                <span className="text-[10px] text-slate-500 block">DISTANZA</span>
                <span className="text-white font-bold">
                  {distNm.toFixed(1)} NM ({distKm} km)
                </span>
              </div>
              <div>
                <span className="text-[10px] text-slate-500 block">PISTA IN USO ARRIVO</span>
                <span className="text-emerald-300 font-bold">
                  RWY {activeDestRunway.runwayId} ({String(activeDestRunway.headingDeg).padStart(3, '0')}°)
                </span>
              </div>
            </div>

            {/* Fuel & Payload Sliders */}
            <div className="space-y-3 pt-2 border-t border-slate-800">
              <div>
                <div className="flex justify-between text-xs font-mono tabular-nums text-slate-300 mb-1">
                  <span>Carburante Imbarcato: {setup.fuelKg} kg</span>
                  <span>Autonomia stimata: ~{enduranceMin} min</span>
                </div>
                <input
                  type="range"
                  disabled={isCareer}
                  min={Math.max(18, Math.round(aircraft.maxFuelKg * 0.12))}
                  max={aircraft.maxFuelKg}
                  value={setup.fuelKg}
                  onChange={(e) => setSetup((p) => ({ ...p, fuelKg: Number(e.target.value) }))}
                  className="w-full accent-amber-500"
                />
                {isCareer && (
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    In Modalità Carriera gestisci il rifornimento nella schermata Gestione Economica.
                  </p>
                )}
              </div>

              {!isCareer && (
                <div>
                  <div className="flex justify-between text-xs font-mono tabular-nums text-slate-300 mb-1">
                    <span>Carico Pagante (Passeggeri + Merci): {setup.payloadKg} kg</span>
                    <span>Max: {aircraft.maxPayloadKg} kg</span>
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={aircraft.maxPayloadKg}
                    value={setup.payloadKg}
                    onChange={(e) => setSetup((p) => ({ ...p, payloadKg: Number(e.target.value) }))}
                    className="w-full accent-sky-500"
                  />
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Right: Weather, Directional Wind, Emergencies & Launch */}
        <div className="lg:col-span-5 space-y-5">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
            <h2 className="text-base font-bold text-white">2. Meteo, Vento & Atmosfera</h2>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs text-slate-400 mb-1">Condizioni Meteo</label>
                <select
                  disabled={isCareer}
                  value={setup.weather.type}
                  onChange={(e) => {
                    const wt = e.target.value as WeatherType;
                    const defaultCloud =
                      wt === WeatherType.STORM
                        ? 1.0
                        : wt === WeatherType.RAIN || wt === WeatherType.SNOW
                          ? 0.88
                          : wt === WeatherType.CLOUDY || wt === WeatherType.FOG
                            ? 0.72
                            : 0.18;
                    setSetup((p) => ({
                      ...p,
                      weather: {
                        ...p.weather,
                        type: wt,
                        cloudCover: defaultCloud,
                        turbulence:
                          wt === WeatherType.STORM ? 0.78 : wt === WeatherType.RAIN ? 0.35 : 0.1,
                        gustIntensityKt: wt === WeatherType.STORM ? 18 : 4,
                        visibilityKm:
                          wt === WeatherType.FOG ? 1.3 : wt === WeatherType.STORM ? 3.8 : 20,
                      },
                    }));
                  }}
                  className="w-full min-h-[42px] bg-slate-950 border border-slate-700 rounded-lg px-2.5 text-xs text-white disabled:opacity-70"
                >
                  {(Object.keys(WEATHER_LABELS) as WeatherType[]).map((wt) => (
                    <option key={wt} value={wt}>
                      {WEATHER_LABELS[wt]}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs text-slate-400 mb-1">Orario / Luce</label>
                <select
                  disabled={isCareer}
                  value={setup.weather.timeOfDay}
                  onChange={(e) =>
                    setSetup((p) => ({
                      ...p,
                      weather: { ...p.weather, timeOfDay: e.target.value as TimeOfDay },
                    }))
                  }
                  className="w-full min-h-[42px] bg-slate-950 border border-slate-700 rounded-lg px-2.5 text-xs text-white disabled:opacity-70"
                >
                  {(Object.keys(TIME_LABELS) as TimeOfDay[]).map((tod) => (
                    <option key={tod} value={tod}>
                      {TIME_LABELS[tod]}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs text-slate-400 mb-1">
                Evoluzione Atmosferica in Volo
              </label>
              <select
                disabled={isCareer}
                value={setup.weather.dynamicsMode || 'dynamic'}
                onChange={(e) =>
                  setSetup((p) => ({
                    ...p,
                    weather: {
                      ...p.weather,
                      dynamicsMode: e.target.value as 'static' | 'dynamic' | 'extreme',
                    },
                  }))
                }
                className="w-full min-h-[42px] bg-slate-950 border border-slate-700 rounded-lg px-2.5 text-xs text-white disabled:opacity-70"
              >
                <option value="dynamic">
                  Meteo Dinamico Reale (Fronti variabili, vento, visibilità e ghiaccio)
                </option>
                <option value="extreme">
                  Fronti Rapidi & Instabili (Cambiamenti frequenti e forti raffiche)
                </option>
                <option value="static">Meteo Statico (Condizioni costanti per tutto il volo)</option>
              </select>
            </div>

            {!isCareer && (
              <div className="space-y-3 pt-1 border-t border-slate-800/80">
                <div>
                  <div className="flex justify-between text-xs font-mono tabular-nums text-slate-300">
                    <span>Direzione Vento (Provenienza)</span>
                    <span className="text-sky-300 font-semibold">
                      {String(Math.round(windDirDeg)).padStart(3, '0')}° ({bearingCardinalIt(windDirDeg)})
                    </span>
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={355}
                    step={5}
                    value={Math.round(windDirDeg)}
                    onChange={(e) => handleWindChange(Number(e.target.value), windSpeedKt)}
                    className="w-full accent-sky-500"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-xs font-mono tabular-nums text-slate-300">
                    <span>Intensità Vento</span>
                    <span className="text-amber-300 font-semibold">
                      {Math.round(windSpeedKt)} kt (
                      {setup.weather.headwindKt >= 0
                        ? `Frontale ${Math.round(setup.weather.headwindKt)}kt`
                        : `Coda ${Math.abs(Math.round(setup.weather.headwindKt))}kt`}
                      )
                    </span>
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={32}
                    value={Math.round(windSpeedKt)}
                    onChange={(e) => handleWindChange(windDirDeg, Number(e.target.value))}
                    className="w-full accent-amber-500"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-xs font-mono tabular-nums text-slate-300">
                    <span>Copertura Nuvolosa</span>
                    <span>{cloudCoverPct}%</span>
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={100}
                    step={5}
                    value={cloudCoverPct}
                    onChange={(e) =>
                      setSetup((p) => ({
                        ...p,
                        weather: { ...p.weather, cloudCover: Number(e.target.value) / 100 },
                      }))
                    }
                    className="w-full accent-slate-400"
                  />
                </div>

                <div>
                  <label className="block text-xs text-slate-400 mb-1 flex items-center gap-1.5">
                    <ShieldAlert className="w-3.5 h-3.5 text-amber-400" />
                    Addestramento Emergenze
                  </label>
                  <select
                    value={setup.plannedEmergency}
                    onChange={(e) =>
                      setSetup((p) => ({
                        ...p,
                        plannedEmergency: e.target.value as EmergencyType,
                      }))
                    }
                    className="w-full min-h-[42px] bg-slate-950 border border-slate-700 rounded-lg px-2.5 text-xs text-white"
                  >
                    {(Object.keys(EMERGENCY_LABELS) as EmergencyType[]).map((em) => (
                      <option key={em} value={em}>
                        {EMERGENCY_LABELS[em]}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            )}

            {/* Pre-flight Dispatch Summary */}
            <div className="p-3.5 rounded-lg bg-slate-950 border border-slate-800 space-y-1.5 text-xs font-mono tabular-nums">
              <div className="flex justify-between text-slate-300">
                <span>Distanza Rotta:</span>
                <span>
                  {distNm.toFixed(1)} NM ({distKm} km)
                </span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>Massa al Decollo:</span>
                <span className={overMtow ? 'text-red-400 font-bold' : 'text-emerald-400'}>
                  {Math.round(totalMass).toLocaleString('it-IT')} /{' '}
                  {aircraft.mtowKg.toLocaleString('it-IT')} kg
                </span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>Velocità Rotazione (Vr):</span>
                <span className="text-amber-300">~{Math.round(aircraft.vStallKt * 1.15)} kt</span>
              </div>
              {shortRunway && (
                <div className="text-amber-400 pt-1 font-sans">
                  Attenzione: una delle piste scelte è più corta della distanza raccomandata (
                  {aircraft.minRunwayM} m). Usa Flap 20° e massima frenata!
                </div>
              )}
              {overMtow && (
                <div className="text-red-400 pt-1 font-sans">
                  Sovrappeso MTOW: riduci carburante o carico per evitare una corsa di decollo eccessiva.
                </div>
              )}
            </div>

            <button
              type="button"
              onClick={() => onStartFlight(setup)}
              className="w-full min-h-[48px] px-5 py-3 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-sm flex items-center justify-center gap-2 cursor-pointer"
            >
              <Play className="w-4 h-4 fill-current" />
              {isCareer
                ? 'Entra in Cabina & Contatta Torre ATC'
                : 'Allinea in Pista e Decolla'}
            </button>
          </div>
        </div>
      </div>

      {/* Interactive Aeronautical Map Modal inside Flight Setup (Editable in Free Flight, Locked ATC in Career) */}
      {mapModalOpen && (
        <InteractiveWorldMap
          airports={AIRPORTS}
          currentWorldXM={dep.worldXM}
          currentWorldYM={dep.worldYM}
          headingDeg={routeGeo.bearingDeg}
          departureAirportId={setup.departureId}
          activeDestinationId={setup.destinationId}
          aircraft={aircraft}
          isInFlight={false}
          isCareerMode={isCareer}
          destinationLocked={isCareer}
          atcAssignment={setup.atcAssignment}
          allowChangeDeparture={!isCareer}
          onConfirmDestination={(chosenDestId, chosenDepId) => {
            if (!isCareer) {
              applyRouteAndRecomputeWind(chosenDepId || setup.departureId, chosenDestId);
            }
            setMapModalOpen(false);
          }}
          onClose={() => setMapModalOpen(false)}
        />
      )}
    </SubScreenShell>
  );
};

// ---------------------------------------------------------------------------
// 7. SETTINGS SCREEN
// ---------------------------------------------------------------------------
interface SettingsScreenProps {
  career: CareerSaveData;
  settings: GameSettings;
  onUpdateSettings: (next: GameSettings) => void;
  onResetCareer: () => void;
  onBack: () => void;
}

export const SettingsScreen: React.FC<SettingsScreenProps> = ({
  career,
  settings,
  onUpdateSettings,
  onResetCareer,
  onBack,
}) => {
  const [confirmReset, setConfirmReset] = useState(false);

  return (
    <SubScreenShell
      title="Impostazioni Simulatore"
      subtitle="Modalità di controllo, qualità rendering HD, audio procedurale e salvataggi"
      career={career}
      onBack={onBack}
    >
      <div className="max-w-xl mx-auto bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-5">
        <div className="space-y-2.5 pb-4 border-b border-slate-800">
          <div className="flex items-center justify-between gap-2">
            <label className="text-sm font-bold tracking-wide text-white flex items-center gap-2">
              <SlidersHorizontal className="w-4 h-4 text-amber-400" />
              MODALITÀ DI CONTROLLO
            </label>
            <span className="text-[11px] font-mono text-amber-300 font-semibold">
              {settings.controlMode === 'sliders' ? 'CURSORI ATTIVI' : 'PULSANTI ATTIVI'}
            </span>
          </div>
          <p className="text-xs text-slate-400">
            Scegli come controllare cabrata/picchiata e potenza del motore su PC e smartphone.
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            <button
              type="button"
              onClick={() => onUpdateSettings({ ...settings, controlMode: 'sliders' })}
              className={`min-h-[68px] p-3 rounded-xl text-left border-2 transition-all cursor-pointer ${
                settings.controlMode === 'sliders'
                  ? 'bg-amber-500/15 border-amber-400 text-white'
                  : 'bg-slate-950 border-slate-800 text-slate-300 hover:bg-slate-800/80'
              }`}
            >
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs sm:text-sm font-extrabold font-mono tracking-wide text-white">
                  CURSORI
                </span>
                <span
                  className={`px-1.5 py-0.5 rounded text-[9.5px] font-mono font-bold ${
                    settings.controlMode === 'sliders'
                      ? 'bg-amber-400 text-slate-950'
                      : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  Predefinito
                </span>
              </div>
              <p className="text-[11px] text-slate-300 mt-1 leading-snug">
                Cursore assetto con ritorno fluido al centro (0%) e cursore potenza stabile.
              </p>
            </button>

            <button
              type="button"
              onClick={() => onUpdateSettings({ ...settings, controlMode: 'buttons' })}
              className={`min-h-[68px] p-3 rounded-xl text-left border-2 transition-all cursor-pointer ${
                settings.controlMode === 'buttons'
                  ? 'bg-amber-500/15 border-amber-400 text-white'
                  : 'bg-slate-950 border-slate-800 text-slate-300 hover:bg-slate-800/80'
              }`}
            >
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs sm:text-sm font-extrabold font-mono tracking-wide text-white">
                  PULSANTI
                </span>
                {settings.controlMode === 'buttons' && (
                  <span className="px-1.5 py-0.5 rounded text-[9.5px] font-mono font-bold bg-amber-400 text-slate-950">
                    Attivo
                  </span>
                )}
              </div>
              <p className="text-[11px] text-slate-300 mt-1 leading-snug">
                Pulsanti grandi CABRA / PICCHIA e ACCELERA / RIDUCI a pressione continua.
              </p>
            </button>
          </div>
        </div>

        <div className="space-y-2">
          <label className="block text-sm font-semibold text-white">Qualità Rendering Grafico HD</label>
          <div className="grid grid-cols-3 gap-2">
            {([2, 3, 4] as const).map((sc) => (
              <button
                key={sc}
                type="button"
                onClick={() => onUpdateSettings({ ...settings, pixelScale: sc })}
                className={`min-h-[42px] rounded-lg text-xs font-semibold border ${
                  settings.pixelScale === sc
                    ? 'bg-amber-500 text-slate-950 border-amber-400 font-bold'
                    : 'bg-slate-950 text-slate-300 border-slate-800 hover:bg-slate-800'
                }`}
              >
                {sc === 2 ? 'Ultra Retina' : sc === 3 ? 'Alta HD' : 'Bilanciata'}
              </button>
            ))}
          </div>
        </div>

        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-sm font-semibold text-white">Audio Motore & Avvisi Cabina</span>
            <button
              type="button"
              onClick={() =>
                onUpdateSettings({ ...settings, soundEnabled: !settings.soundEnabled })
              }
              className={`min-h-[38px] px-4 rounded-lg text-xs font-bold ${
                settings.soundEnabled
                  ? 'bg-emerald-500 text-slate-950'
                  : 'bg-slate-800 text-slate-400'
              }`}
            >
              {settings.soundEnabled ? 'Attivo' : 'Disattivato'}
            </button>
          </div>
          <input
            type="range"
            min={0.1}
            max={1}
            step={0.05}
            value={settings.soundVolume}
            onChange={(e) =>
              onUpdateSettings({ ...settings, soundVolume: Number(e.target.value) })
            }
            className="w-full accent-amber-500"
          />
        </div>

        <div className="flex items-center justify-between pt-2 border-t border-slate-800">
          <span className="text-sm font-semibold text-white">Vibrazioni Turbolenza Telecamera</span>
          <button
            type="button"
            onClick={() =>
              onUpdateSettings({ ...settings, cameraShake: !settings.cameraShake })
            }
            className={`min-h-[38px] px-4 rounded-lg text-xs font-bold ${
              settings.cameraShake
                ? 'bg-emerald-500 text-slate-950'
                : 'bg-slate-800 text-slate-400'
            }`}
          >
            {settings.cameraShake ? 'Attive' : 'Disattivate'}
          </button>
        </div>

        <div className="pt-4 border-t border-slate-800">
          {confirmReset ? (
            <div className="flex items-center justify-between gap-2">
              <span className="text-xs text-red-300">Confermi azzeramento salvataggio?</span>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setConfirmReset(false)}
                  className="min-h-[38px] px-3 rounded bg-slate-800 text-xs text-slate-200"
                >
                  Annulla
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setConfirmReset(false);
                    onResetCareer();
                  }}
                  className="min-h-[38px] px-3 rounded bg-red-600 text-xs font-bold text-white"
                >
                  Azzera Tutto
                </button>
              </div>
            </div>
          ) : (
            <button
              type="button"
              onClick={() => setConfirmReset(true)}
              className="min-h-[40px] px-4 rounded-lg bg-slate-950 hover:bg-red-950/60 border border-slate-800 text-xs text-red-400 font-medium"
            >
              Ripristina Dati Salvataggio Carriera
            </button>
          )}
        </div>
      </div>
    </SubScreenShell>
  );
};

// ---------------------------------------------------------------------------
// 8. PAUSE OVERLAY & POST-FLIGHT RESULTS MODAL
// ---------------------------------------------------------------------------
export const PauseModal: React.FC<{
  controlMode: ControlMode;
  isFreeFlight?: boolean;
  onChangeControlMode: (mode: ControlMode) => void;
  onOpenInteractiveMap?: () => void;
  onResume: () => void;
  onRestart: () => void;
  onAbortToMenu: () => void;
}> = ({
  controlMode,
  isFreeFlight = false,
  onChangeControlMode,
  onOpenInteractiveMap,
  onResume,
  onRestart,
  onAbortToMenu,
}) => (
  <div className="fixed inset-0 z-40 bg-slate-950/85 flex items-center justify-center p-4">
    <div className="bg-slate-900 border border-slate-700 rounded-2xl p-5 sm:p-6 max-w-md w-full avionics-panel space-y-4">
      <h2 className="text-xl font-bold text-white text-center">Simulazione in Pausa</h2>

      <div className="bg-slate-950 border border-slate-800 rounded-xl p-3 space-y-2">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold tracking-wide text-white flex items-center gap-1.5">
            <SlidersHorizontal className="w-3.5 h-3.5 text-amber-400" />
            MODALITÀ DI CONTROLLO
          </span>
          <span className="text-[10px] font-mono text-slate-400">
            Mantiene potenza e assetto
          </span>
        </div>
        <div className="grid grid-cols-2 gap-2 font-mono">
          <button
            type="button"
            onClick={() => onChangeControlMode('sliders')}
            className={`min-h-[42px] px-2.5 py-1.5 rounded-lg border text-xs font-bold transition-all cursor-pointer ${
              controlMode === 'sliders'
                ? 'bg-amber-500 text-slate-950 border-amber-300'
                : 'bg-slate-900 hover:bg-slate-800 text-slate-200 border-slate-700'
            }`}
          >
            CURSORI
            <span className="block text-[9px] font-normal opacity-80">Predefinito</span>
          </button>
          <button
            type="button"
            onClick={() => onChangeControlMode('buttons')}
            className={`min-h-[42px] px-2.5 py-1.5 rounded-lg border text-xs font-bold transition-all cursor-pointer ${
              controlMode === 'buttons'
                ? 'bg-amber-500 text-slate-950 border-amber-300'
                : 'bg-slate-900 hover:bg-slate-800 text-slate-200 border-slate-700'
            }`}
          >
            PULSANTI
            <span className="block text-[9px] font-normal opacity-80">Pressione continua</span>
          </button>
        </div>
      </div>

      <div className="text-xs text-slate-300 space-y-1 font-mono bg-slate-950 p-3 rounded-lg border border-slate-800">
        <div>W / S : Cabrata / Picchiata</div>
        <div>↑ / ↓ : Accelera / Riduci Potenza</div>
        <div>P : Autopilot ON / OFF (Mantenimento Quota)</div>
        <div>V / F : Flap − / + · G : Carrello · B : Freni</div>
        <div>M : Mappa Aeronautica · C : Vista · Esc : Pausa</div>
      </div>

      <div className="space-y-2">
        <button
          type="button"
          onClick={onResume}
          className="w-full min-h-[44px] rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-sm"
        >
          Riprendi Volo
        </button>
        {onOpenInteractiveMap && (
          <button
            type="button"
            onClick={onOpenInteractiveMap}
            className={`w-full min-h-[44px] rounded-lg border font-bold text-sm flex items-center justify-center gap-2 ${
              isFreeFlight
                ? 'bg-sky-500/20 hover:bg-sky-500/30 border-sky-400/70 text-sky-200'
                : 'bg-fuchsia-500/20 hover:bg-fuchsia-500/30 border-fuchsia-400/70 text-fuchsia-200'
            }`}
          >
            <MapIcon className={`w-4 h-4 ${isFreeFlight ? 'text-sky-300' : 'text-fuchsia-300'}`} />
            {isFreeFlight ? 'Apri Mappa Aeronautica' : 'Consulta Carta Rotta ATC'}
          </button>
        )}
        <button
          type="button"
          onClick={onRestart}
          className="w-full min-h-[44px] rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-100 font-semibold text-sm"
        >
          Ricomincia Decollo
        </button>
        <button
          type="button"
          onClick={onAbortToMenu}
          className="w-full min-h-[44px] rounded-lg bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-300 font-medium text-xs"
        >
          Termina e Torna al Menu
        </button>
      </div>
    </div>
  </div>
);

export const FlightResultsScreen: React.FC<{
  result: FlightResultSummary;
  onFlyAgain: () => void;
  onContinue: () => void;
}> = ({ result, onFlyAgain, onContinue }) => {
  const isSuccess = result.outcome === 'SUCCESS' || result.outcome === 'DIVERTED';

  return (
    <div className="fixed inset-0 z-40 bg-slate-950/92 flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl p-5 sm:p-6 max-w-lg w-full avionics-panel space-y-4">
        <div className="flex items-start justify-between gap-4 border-b border-slate-800 pb-3">
          <div>
            <div className="text-xs font-mono text-slate-400">
              {result.departureAirport.icao} → {result.destinationAirport.icao} · {result.aircraftName}
            </div>
            <h2
              className={`text-xl sm:text-2xl font-bold mt-0.5 ${
                result.outcome === 'SUCCESS'
                  ? 'text-emerald-400'
                  : result.outcome === 'DIVERTED'
                    ? 'text-amber-300'
                    : 'text-red-400'
              }`}
            >
              {result.outcome === 'SUCCESS'
                ? 'Atterraggio Completato'
                : result.outcome === 'DIVERTED'
                  ? 'Atterraggio Alternato Sicuro'
                  : result.outcome === 'DAMAGED'
                    ? 'Atterraggio con Danni'
                    : 'Incidente di Volo'}
            </h2>
            <p className="text-xs text-slate-300 mt-1">{result.reason}</p>
          </div>

          <div className="w-12 h-12 rounded-lg bg-slate-950 border border-slate-700 flex flex-col items-center justify-center shrink-0 font-mono">
            <span className="text-[9px] text-slate-400">GRADO</span>
            <span className="text-lg font-bold text-amber-400">{result.landingGrade}</span>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3 text-xs font-mono tabular-nums bg-slate-950 p-3.5 rounded-lg border border-slate-800">
          <div>
            <span className="text-slate-500 block text-[10px]">TOCCO VERTICALE</span>
            <span className="text-white font-semibold">{Math.round(result.touchdownFpm)} ft/min</span>
          </div>
          <div>
            <span className="text-slate-500 block text-[10px]">SCOSTAMENTO ASSE</span>
            <span className="text-white font-semibold">{result.centerlineErrorM.toFixed(1)} m</span>
          </div>
          <div>
            <span className="text-slate-500 block text-[10px]">CARBURANTE USATO</span>
            <span className="text-white font-semibold">{result.fuelUsedKg.toFixed(1)} kg</span>
          </div>
          <div>
            <span className="text-slate-500 block text-[10px]">DURATA VOLO</span>
            <span className="text-white font-semibold">
              {Math.floor(result.elapsedSec / 60)}m {Math.round(result.elapsedSec % 60)}s
            </span>
          </div>
        </div>

        {result.mode === 'career' && (
          <div className="space-y-1.5 text-xs font-mono tabular-nums border-t border-slate-800 pt-3">
            <div className="flex justify-between text-slate-300">
              <span>Compenso Operativo:</span>
              <span className="text-emerald-400">+€{result.contractRewardEur.toLocaleString('it-IT')}</span>
            </div>
            {result.landingBonusEur > 0 && (
              <div className="flex justify-between text-slate-300">
                <span>Bonus Atterraggio Morbido:</span>
                <span className="text-emerald-400">+€{result.landingBonusEur.toLocaleString('it-IT')}</span>
              </div>
            )}
            {result.maintenanceCostEur > 0 && (
              <div className="flex justify-between text-slate-300">
                <span>Penali / Riparazioni Emergenza:</span>
                <span className="text-red-400">-€{result.maintenanceCostEur.toLocaleString('it-IT')}</span>
              </div>
            )}
            <div className="flex justify-between text-sm font-bold pt-1.5 border-t border-slate-800">
              <span className="text-white">Bilancio Netto:</span>
              <span className={result.netProfitEur >= 0 ? 'text-amber-300' : 'text-red-400'}>
                {result.netProfitEur >= 0 ? '+' : ''}€{result.netProfitEur.toLocaleString('it-IT')} (
                {result.reputationDelta >= 0 ? `+${result.reputationDelta}` : result.reputationDelta} Rep)
              </span>
            </div>
          </div>
        )}

        <div className="grid grid-cols-2 gap-3 pt-2">
          <button
            type="button"
            onClick={onFlyAgain}
            className="min-h-[44px] px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-100 text-xs sm:text-sm font-semibold flex items-center justify-center gap-1.5 whitespace-nowrap"
          >
            <RotateCcw className="w-4 h-4" />
            Riprova Volo
          </button>

          <button
            type="button"
            onClick={onContinue}
            className="min-h-[44px] px-4 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs sm:text-sm font-bold whitespace-nowrap"
          >
            {isSuccess && result.mode === 'career' ? 'Nuovo Giorno Carriera' : 'Continua'}
          </button>
        </div>
      </div>
    </div>
  );
};
