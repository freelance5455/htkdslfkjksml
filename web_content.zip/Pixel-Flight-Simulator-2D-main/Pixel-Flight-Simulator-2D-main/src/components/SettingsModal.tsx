import React, { useState } from 'react';
import { soundEngine } from '../audio/soundEngine';
import { useI18n } from '../i18n/I18nContext';
import { SUPPORTED_LANGUAGES } from '../i18n/translations';
import { CloudQuality, ControlButtonSize, GameSettings, LanguageCode } from '../types/game';

export interface SettingsModalProps {
  isOpen: boolean;
  isInFlight: boolean;
  settings: GameSettings;
  onUpdateSettings: (next: GameSettings) => void;
  onClose: () => void;
  onResetCareer?: () => void;
}

type SettingsTabId = 'all' | 'language' | 'general' | 'graphics' | 'controls';

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  isInFlight,
  settings,
  onUpdateSettings,
  onClose,
  onResetCareer,
}) => {
  const { lang, t } = useI18n();
  const [activeTab, setActiveTab] = useState<SettingsTabId>('all');
  const [confirmReset, setConfirmReset] = useState(false);

  if (!isOpen) return null;

  const handleSelectLanguage = (code: LanguageCode) => {
    soundEngine.playBeep(720, 0.06, 'triangle', 0.14, 'comm');
    onUpdateSettings({ ...settings, language: code });
  };

  const handleToggleSound = () => {
    const nextEnabled = !settings.soundEnabled;
    const next = { ...settings, soundEnabled: nextEnabled };
    onUpdateSettings(next);
    if (nextEnabled) {
      soundEngine.configure(
        true,
        next.soundVolume,
        next.sfxVolume,
        next.commVolume
      );
      soundEngine.playBeep(660, 0.07, 'triangle', 0.15, 'comm');
    }
  };

  const showSection = (sec: Exclude<SettingsTabId, 'all'>) =>
    activeTab === 'all' || activeTab === sec;

  return (
    <div
      className="fixed inset-0 z-[60] flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-2.5 sm:p-4 select-none"
      role="dialog"
      aria-modal="true"
      aria-label={t('settings.title')}
    >
      <div className="w-full max-w-2xl max-h-[88vh] flex flex-col rounded-2xl bg-slate-900/98 border border-slate-700/90 shadow-2xl overflow-hidden text-slate-100">
        {/* Avionics Header */}
        <div className="shrink-0 px-4 sm:px-5 py-3.5 bg-slate-950/90 border-b border-slate-800 flex items-center justify-between gap-3">
          <div className="min-w-0">
            <div className="flex items-center gap-2 text-[10px] font-mono uppercase tracking-[0.2em] text-sky-400">
              <span aria-hidden="true">⚙️</span>
              <span className="truncate">{t('settings.headerBadge')}</span>
            </div>
            <h2 className="text-base sm:text-lg font-black tracking-tight text-white truncate">
              {t('settings.title')}
            </h2>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label={t('common.close')}
            className="min-h-[38px] min-w-[38px] px-3 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-bold text-slate-200 transition flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <span>✕</span>
            <span className="hidden sm:inline">{t('common.close')}</span>
          </button>
        </div>

        {/* In-Flight Safe Pause Banner */}
        {isInFlight && (
          <div className="shrink-0 px-4 sm:px-5 py-2 bg-sky-950/60 border-b border-sky-800/50 flex items-center gap-2 text-[11px] font-medium text-sky-200">
            <span className="w-2 h-2 rounded-full bg-emerald-400 shrink-0" />
            <span>{t('settings.inFlightNotice')}</span>
          </div>
        )}

        {/* Quick Section Navigation Bar */}
        <div className="shrink-0 px-4 sm:px-5 py-2 bg-slate-950/50 border-b border-slate-800/80 flex items-center gap-1.5 overflow-x-auto">
          {(
            [
              { id: 'all', icon: '⚙️', label: '∞' },
              { id: 'language', icon: '🌐', label: t('settings.secLanguage') },
              { id: 'general', icon: '🔊', label: t('settings.secGeneral') },
              { id: 'graphics', icon: '🖥', label: t('settings.secGraphics') },
              { id: 'controls', icon: '🕹', label: t('settings.secControls') },
            ] as { id: SettingsTabId; icon: string; label: string }[]
          ).map((tab) => {
            const active = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveTab(tab.id)}
                className={`min-h-[34px] px-3 py-1 rounded-lg text-xs font-bold whitespace-nowrap transition flex items-center gap-1.5 cursor-pointer border ${
                  active
                    ? 'bg-sky-600/25 border-sky-400 text-sky-200 shadow-sm'
                    : 'bg-slate-900/80 border-slate-800 text-slate-400 hover:text-slate-200 hover:border-slate-700'
                }`}
              >
                <span aria-hidden="true">{tab.icon}</span>
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Scrollable Content Sections */}
        <div className="flex-1 overflow-y-auto px-4 sm:px-5 py-4 space-y-4">
          {/* 1. SEZIONE LINGUA */}
          {showSection('language') && (
            <section className="rounded-xl bg-slate-950/75 border border-slate-800 p-3.5 sm:p-4">
              <div className="flex flex-wrap items-center justify-between gap-2 mb-1.5">
                <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-sky-300 flex items-center gap-2">
                  <span aria-hidden="true">🌐</span>
                  <span>{t('settings.secLanguage')}</span>
                </h3>
                <span className="text-[10px] font-mono text-emerald-400/90">
                  ✓ {t('settings.langSavedAuto')}
                </span>
              </div>
              <p className="text-xs text-slate-400 mb-3">{t('settings.secLanguageDesc')}</p>

              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                {SUPPORTED_LANGUAGES.map((opt) => {
                  const selected = lang === opt.code;
                  return (
                    <button
                      key={opt.code}
                      type="button"
                      onClick={() => handleSelectLanguage(opt.code)}
                      aria-pressed={selected}
                      className={`min-h-[48px] px-2.5 py-2 rounded-xl border text-left sm:text-center flex sm:flex-col items-center justify-between sm:justify-center gap-1.5 transition cursor-pointer ${
                        selected
                          ? 'bg-sky-600/25 border-sky-400 text-white shadow-md ring-1 ring-sky-400/40'
                          : 'bg-slate-900/90 border-slate-700/80 text-slate-300 hover:border-slate-500 hover:bg-slate-800/80'
                      }`}
                    >
                      <div className="flex items-center gap-1.5 sm:gap-1">
                        <span className="text-base leading-none" aria-hidden="true">
                          {opt.flag}
                        </span>
                        <span className="text-xs font-bold tracking-tight">{opt.label}</span>
                      </div>
                      <span
                        className={`text-[9px] font-mono font-bold px-1.5 py-0.5 rounded ${
                          selected
                            ? 'bg-sky-500 text-slate-950'
                            : 'bg-slate-800 text-slate-400'
                        }`}
                      >
                        {opt.shortCode}
                      </span>
                    </button>
                  );
                })}
              </div>
            </section>
          )}

          {/* 2. SEZIONE GENERALI E AUDIO */}
          {showSection('general') && (
            <section className="rounded-xl bg-slate-950/75 border border-slate-800 p-3.5 sm:p-4 space-y-3.5">
              <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-emerald-300 flex items-center gap-2">
                <span aria-hidden="true">🔊</span>
                <span>{t('settings.secGeneral')}</span>
              </h3>

              {/* Master Audio Switch */}
              <div className="flex items-center justify-between gap-3 pb-2.5 border-b border-slate-800/80">
                <div>
                  <div className="text-sm font-bold text-white">{t('settings.masterAudio')}</div>
                  <div className="text-[11px] text-slate-400">{t('settings.masterAudioDesc')}</div>
                </div>
                <button
                  type="button"
                  onClick={handleToggleSound}
                  className={`min-h-[40px] min-w-[88px] px-3.5 py-1.5 rounded-xl text-xs font-mono font-bold border transition cursor-pointer ${
                    settings.soundEnabled
                      ? 'bg-emerald-600/25 border-emerald-400 text-emerald-200'
                      : 'bg-slate-900 border-slate-700 text-slate-400'
                  }`}
                >
                  {settings.soundEnabled ? t('common.on') : t('common.off')}
                </button>
              </div>

              {/* Master Volume */}
              <div className={settings.soundEnabled ? '' : 'opacity-45 pointer-events-none'}>
                <div className="flex justify-between text-xs mb-1">
                  <span className="font-semibold text-slate-200">
                    {t('settings.masterVolume')}
                  </span>
                  <span className="font-mono font-bold text-sky-300 tabular-nums">
                    {Math.round(settings.soundVolume * 100)}%
                  </span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={100}
                  value={Math.round(settings.soundVolume * 100)}
                  onChange={(e) =>
                    onUpdateSettings({
                      ...settings,
                      soundVolume: Number(e.target.value) / 100,
                    })
                  }
                  className="w-full h-2 accent-sky-500 cursor-pointer"
                />
              </div>

              {/* Engine & Environment SFX Volume */}
              <div className={settings.soundEnabled ? '' : 'opacity-45 pointer-events-none'}>
                <div className="flex justify-between text-xs mb-1">
                  <span className="font-semibold text-slate-200">{t('settings.sfxVolume')}</span>
                  <span className="font-mono font-bold text-emerald-300 tabular-nums">
                    {Math.round(settings.sfxVolume * 100)}%
                  </span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={100}
                  value={Math.round(settings.sfxVolume * 100)}
                  onChange={(e) =>
                    onUpdateSettings({
                      ...settings,
                      sfxVolume: Number(e.target.value) / 100,
                    })
                  }
                  className="w-full h-2 accent-emerald-500 cursor-pointer"
                />
              </div>

              {/* Radio ATC & GPWS Cockpit Alerts Volume */}
              <div className={settings.soundEnabled ? '' : 'opacity-45 pointer-events-none'}>
                <div className="flex justify-between text-xs mb-1">
                  <span className="font-semibold text-slate-200">{t('settings.commVolume')}</span>
                  <span className="font-mono font-bold text-amber-300 tabular-nums">
                    {Math.round(settings.commVolume * 100)}%
                  </span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={100}
                  value={Math.round(settings.commVolume * 100)}
                  onChange={(e) =>
                    onUpdateSettings({
                      ...settings,
                      commVolume: Number(e.target.value) / 100,
                    })
                  }
                  className="w-full h-2 accent-amber-500 cursor-pointer"
                />
              </div>
            </section>
          )}

          {/* 3. SEZIONE GRAFICA */}
          {showSection('graphics') && (
            <section className="rounded-xl bg-slate-950/75 border border-slate-800 p-3.5 sm:p-4 space-y-3.5">
              <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-amber-300 flex items-center gap-2">
                <span aria-hidden="true">🖥</span>
                <span>{t('settings.secGraphics')}</span>
              </h3>

              {/* Render Supersampling Quality */}
              <div>
                <div className="text-xs font-semibold text-slate-200 mb-2">
                  {t('settings.renderQuality')}
                </div>
                <div className="grid grid-cols-3 gap-2">
                  {(
                    [
                      { val: 2 as const, label: t('settings.renderHigh') },
                      { val: 3 as const, label: t('settings.renderBalanced') },
                      { val: 4 as const, label: t('settings.renderPerf') },
                    ]
                  ).map((opt) => {
                    const active = settings.pixelScale === opt.val;
                    return (
                      <button
                        key={opt.val}
                        type="button"
                        onClick={() => onUpdateSettings({ ...settings, pixelScale: opt.val })}
                        className={`min-h-[42px] px-2 py-2 rounded-xl text-[11px] sm:text-xs font-bold border transition cursor-pointer ${
                          active
                            ? 'bg-sky-600/25 border-sky-400 text-white'
                            : 'bg-slate-900 border-slate-700 text-slate-300 hover:border-slate-500'
                        }`}
                      >
                        {opt.label}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Volumetric Cloud Density */}
              <div>
                <div className="text-xs font-semibold text-slate-200 mb-2">
                  {t('settings.cloudQuality')}
                </div>
                <div className="grid grid-cols-3 gap-2">
                  {(
                    [
                      { val: 'high' as CloudQuality, label: t('settings.cloudHigh') },
                      { val: 'medium' as CloudQuality, label: t('settings.cloudMedium') },
                      { val: 'low' as CloudQuality, label: t('settings.cloudLow') },
                    ]
                  ).map((opt) => {
                    const active = settings.cloudQuality === opt.val;
                    return (
                      <button
                        key={opt.val}
                        type="button"
                        onClick={() => onUpdateSettings({ ...settings, cloudQuality: opt.val })}
                        className={`min-h-[40px] px-2 py-1.5 rounded-xl text-xs font-bold border transition cursor-pointer ${
                          active
                            ? 'bg-sky-600/25 border-sky-400 text-white'
                            : 'bg-slate-900 border-slate-700 text-slate-300 hover:border-slate-500'
                        }`}
                      >
                        {opt.label}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Camera Shake */}
              <div className="flex items-center justify-between gap-3 pt-2 border-t border-slate-800/80">
                <div>
                  <div className="text-sm font-bold text-white">{t('settings.cameraShake')}</div>
                  <div className="text-[11px] text-slate-400">
                    {t('settings.cameraShakeDesc')}
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() =>
                    onUpdateSettings({ ...settings, cameraShake: !settings.cameraShake })
                  }
                  className={`min-h-[40px] min-w-[88px] px-3.5 py-1.5 rounded-xl text-xs font-mono font-bold border transition cursor-pointer ${
                    settings.cameraShake
                      ? 'bg-emerald-600/25 border-emerald-400 text-emerald-200'
                      : 'bg-slate-900 border-slate-700 text-slate-400'
                  }`}
                >
                  {settings.cameraShake ? t('common.on') : t('common.off')}
                </button>
              </div>
            </section>
          )}

          {/* 4. SEZIONE CONTROLLI */}
          {showSection('controls') && (
            <section className="rounded-xl bg-slate-950/75 border border-slate-800 p-3.5 sm:p-4 space-y-3.5">
              <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-indigo-300 flex items-center gap-2">
                <span aria-hidden="true">🕹</span>
                <span>{t('settings.secControls')}</span>
              </h3>

              {/* Control Mode: Sliders vs Buttons */}
              <div>
                <div className="text-xs font-semibold text-slate-200 mb-2">
                  {t('settings.controlMode')}
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => onUpdateSettings({ ...settings, controlMode: 'sliders' })}
                    className={`min-h-[54px] p-3 rounded-xl border text-left transition cursor-pointer ${
                      settings.controlMode === 'sliders'
                        ? 'bg-sky-600/25 border-sky-400 text-white'
                        : 'bg-slate-900 border-slate-700 text-slate-300 hover:border-slate-500'
                    }`}
                  >
                    <div className="text-xs font-bold">🎚 {t('settings.modeSliders')}</div>
                    <div className="text-[10px] text-slate-400 mt-0.5">
                      {t('settings.modeSlidersDesc')}
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => onUpdateSettings({ ...settings, controlMode: 'buttons' })}
                    className={`min-h-[54px] p-3 rounded-xl border text-left transition cursor-pointer ${
                      settings.controlMode === 'buttons'
                        ? 'bg-amber-600/25 border-amber-400 text-white'
                        : 'bg-slate-900 border-slate-700 text-slate-300 hover:border-slate-500'
                    }`}
                  >
                    <div className="text-xs font-bold">🔘 {t('settings.modeButtons')}</div>
                    <div className="text-[10px] text-slate-400 mt-0.5">
                      {t('settings.modeButtonsDesc')}
                    </div>
                  </button>
                </div>
              </div>

              {/* Cockpit Button Size */}
              <div>
                <div className="text-xs font-semibold text-slate-200 mb-2">
                  {t('settings.buttonSize')}
                </div>
                <div className="grid grid-cols-2 gap-2">
                  {(
                    [
                      { val: 'normal' as ControlButtonSize, label: t('settings.buttonSizeNormal') },
                      { val: 'large' as ControlButtonSize, label: t('settings.buttonSizeLarge') },
                    ]
                  ).map((opt) => {
                    const active = settings.buttonSize === opt.val;
                    return (
                      <button
                        key={opt.val}
                        type="button"
                        onClick={() => onUpdateSettings({ ...settings, buttonSize: opt.val })}
                        className={`min-h-[40px] px-3 py-1.5 rounded-xl text-xs font-bold border transition cursor-pointer ${
                          active
                            ? 'bg-sky-600/25 border-sky-400 text-white'
                            : 'bg-slate-900 border-slate-700 text-slate-300 hover:border-slate-500'
                        }`}
                      >
                        {opt.label}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Career Save Data Reset — only outside active flight */}
              {!isInFlight && onResetCareer && (
                <div className="pt-3 border-t border-slate-800/80">
                  <div className="text-xs font-semibold text-slate-300 mb-2">
                    {t('settings.careerData')}
                  </div>
                  {!confirmReset ? (
                    <button
                      type="button"
                      onClick={() => setConfirmReset(true)}
                      className="min-h-[40px] px-3.5 py-2 rounded-xl bg-rose-950/60 hover:bg-rose-900/70 border border-rose-700/70 text-rose-200 text-xs font-bold transition cursor-pointer"
                    >
                      🗑 {t('settings.resetCareer')}
                    </button>
                  ) : (
                    <div className="p-3 rounded-xl bg-rose-950/70 border border-rose-500/80 space-y-2">
                      <div className="text-xs font-bold text-rose-100">
                        {t('settings.resetConfirmPrompt')}
                      </div>
                      <div className="flex flex-wrap gap-2">
                        <button
                          type="button"
                          onClick={() => {
                            onResetCareer();
                            setConfirmReset(false);
                          }}
                          className="min-h-[38px] px-3.5 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-xs font-bold text-white cursor-pointer"
                        >
                          {t('settings.resetConfirmYes')}
                        </button>
                        <button
                          type="button"
                          onClick={() => setConfirmReset(false)}
                          className="min-h-[38px] px-3.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-bold text-slate-200 cursor-pointer"
                        >
                          {t('common.cancel')}
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </section>
          )}
        </div>

        {/* Sticky Footer */}
        <div className="shrink-0 px-4 sm:px-5 py-3 bg-slate-950/90 border-t border-slate-800 flex items-center justify-end">
          <button
            type="button"
            onClick={onClose}
            className="w-full sm:w-auto min-h-[42px] px-6 py-2 rounded-xl bg-sky-600 hover:bg-sky-500 text-xs sm:text-sm font-black uppercase tracking-wide text-white shadow-lg shadow-sky-900/40 transition cursor-pointer"
          >
            {isInFlight ? `▶ ${t('settings.doneContinue')}` : t('settings.doneClose')}
          </button>
        </div>
      </div>
    </div>
  );
};
