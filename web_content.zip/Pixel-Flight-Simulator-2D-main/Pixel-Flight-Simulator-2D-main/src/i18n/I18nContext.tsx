import React, { createContext, useContext, useMemo } from 'react';
import { LanguageCode } from '../types/game';
import { SUPPORTED_LANGUAGES, translateKey } from './translations';

export interface I18nContextValue {
  lang: LanguageCode;
  setLanguage: (lang: LanguageCode) => void;
  t: (key: string, params?: Record<string, string | number>) => string;
}

const I18nContext = createContext<I18nContextValue>({
  lang: 'it',
  setLanguage: () => {},
  t: (key, params) => translateKey('it', key, params),
});

export const I18nProvider: React.FC<{
  language: LanguageCode;
  onChangeLanguage: (lang: LanguageCode) => void;
  children: React.ReactNode;
}> = ({ language, onChangeLanguage, children }) => {
  const safeLang: LanguageCode = SUPPORTED_LANGUAGES.some((l) => l.code === language)
    ? language
    : 'it';

  const value = useMemo<I18nContextValue>(
    () => ({
      lang: safeLang,
      setLanguage: onChangeLanguage,
      t: (key, params) => translateKey(safeLang, key, params),
    }),
    [safeLang, onChangeLanguage]
  );

  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>;
};

export function useI18n(): I18nContextValue {
  return useContext(I18nContext);
}
