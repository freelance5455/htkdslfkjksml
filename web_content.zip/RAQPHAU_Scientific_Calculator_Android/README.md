# RAQPHAU Scientific Calculator

Android project for the existing calculator HTML.

App name: RAQPHAU Scientific Calculator
Application ID: com.babidan.raqphaucalculator
Version: 1.0

The supplied RAQPHAU icon is installed as the launcher icon.
The calculator HTML is in app/src/main/assets/index.html.

Open this project in Android Studio, sync Gradle, then build an APK.
Currency conversion requires internet access.
