Atta Hisab App (offline-capable HTML app)
1. Extract the ZIP.
2. Open index.html in Chrome.
3. On Android Chrome, menu > Add to Home screen (if available).
Data is stored in this browser/device. Use Settings > Export Backup regularly.
This is an HTML app, not an APK. Keep backups before clearing browser data.
