if (typeof COURSES !== "undefined") {
  COURSES.push({
    id: "cyber-1",
    category: "Cybersécurité",
    level: "Universitaire L2/L3",
    title: "Cybersécurité & Protection des Systèmes",
    duration: "1h 30",
    description: "Manuel complet : triade CIA, cryptographie (AES, RSA, hachage), failles Web OWASP (SQLi, XSS) et défense en profondeur.",
    chapters: [
      {
        id: "cyber-c1",
        title: "Chapitre 1 : Triade CIA, Risques & Menaces",
        html: `
          <h3>1.1 Vulnérabilité, Menace et Risque</h3>
          <p>En sécurité des systèmes d'information (SSI), il faut bien distinguer trois notions :</p>
          <ul>
            <li><strong>Vulnérabilité :</strong> Une faiblesse dans un logiciel, un réseau ou une habitude humaine (ex: un système non mis à jour).</li>
            <li><strong>Menace :</strong> Un danger potentiel (pirate, logiciel malveillant, panne) capable d'exploiter une faille.</li>
            <li><strong>Risque :</strong> La probabilité qu'une menace exploite une vulnérabilité et cause un dommage réel.</li>
          </ul>

          <h3>1.2 Les piliers de la sécurité (Triade CIA + Traçabilité)</h3>
          <table>
            <tr><th>Pilier</th><th>Objectif</th><th>Exemple de protection</th></tr>
            <tr><td><strong>Confidentialité</strong></td><td>Empêcher les personnes non autorisées de lire les données.</td><td>Chiffrement, mots de passe, droits d'accès</td></tr>
            <tr><td><strong>Intégrité</strong></td><td>Garantir que les données n'ont pas été modifiées en chemin.</td><td>Empreinte SHA-256, signature numérique</td></tr>
            <tr><td><strong>Disponibilité</strong></td><td>Assurer que le service reste accessible à tout moment.</td><td>Protection anti-DDoS, sauvegardes</td></tr>
            <tr><td><strong>Traçabilité</strong></td><td>Savoir qui a effectué quelle action et à quelle heure.</td><td>Journaux (Logs) sécurisés, audit</td></tr>
          </table>

          <h3>1.3 Ingénierie sociale et Malwares</h3>
          <p>Souvent, le pirate n'attaque pas la machine mais <strong>l'humain</strong> : c'est l'<em>ingénierie sociale</em>.</p>
          <ul>
            <li><strong>Phishing (Hameçonnage) :</strong> Faux e-mail ou faux site imitant une banque ou université pour voler vos identifiants.</li>
            <li><strong>Ransomware (Rançongiciel) :</strong> Malware qui chiffre tous vos fichiers et exige une rançon pour donner la clé.</li>
            <li><strong>Cheval de Troie (Trojan) :</strong> Programme d'apparence utile (ex: logiciel piraté) cachant une porte dérobée (<em>Backdoor</em>).</li>
          </ul>
        `
      },
      {
        id: "cyber-c2",
        title: "Chapitre 2 : Cryptographie Appliquée & HTTPS",
        html: `
          <h3>2.1 Les 3 familles de la cryptographie</h3>
          <table>
            <tr><th>Technique</th><th>Fonctionnement</th><th>Algorithmes</th><th>Usage principal</th></tr>
            <tr><td><strong>Symétrique</strong></td><td>Une <strong>seule clé secrète</strong> chiffre et déchiffre. Très rapide.</td><td>AES-256, ChaCha20</td><td>Chiffrer un disque dur ou gros fichiers</td></tr>
            <tr><td><strong>Asymétrique</strong></td><td>Paire de clés : <strong>Publique</strong> + <strong>Privée</strong>. Plus lent.</td><td>RSA, ECC</td><td>Échanger une clé secrète, signer</td></tr>
            <tr><td><strong>Hachage</strong></td><td>Empreinte mathématique <strong>irréversible</strong> (sens unique).</td><td>SHA-256, Argon2, bcrypt</td><td>Vérifier l'intégrité, mots de passe</td></tr>
          </table>

          <h3>2.2 Rôle de la Clé Publique et de la Clé Privée</h3>
          <ul>
            <li><strong>Pour la Confidentialité :</strong> Vous chiffrez avec la <em>clé publique</em> du destinataire ; seul lui peut lire avec sa <em>clé privée</em>.</li>
            <li><strong>Pour la Signature :</strong> Vous signez avec votre <em>clé privée</em> ; chacun vérifie avec votre <em>clé publique</em> que le document vient bien de vous.</li>
          </ul>

          <div class="warn-box">
            <strong>⚠️ Stockage des mots de passe :</strong> Ne stockez jamais un mot de passe en clair ni en simple MD5/SHA-256 sans sel ! Utilisez <strong>bcrypt</strong> ou <strong>Argon2</strong> avec un <strong>sel (Salt)</strong> aléatoire unique par utilisateur pour bloquer les tables précalculées (<em>Rainbow Tables</em>).
          </div>

          <h3>2.3 Comment fonctionne HTTPS (TLS) ?</h3>
          <p><strong>HTTPS</strong> combine les deux méthodes : au début, il utilise la cryptographie <em>asymétrique</em> et le certificat du serveur pour vérifier son identité et échanger une clé de session secrète, puis il utilise le chiffrement <em>symétrique</em> (AES) rapide pour toute la suite.</p>
        `
      },
      {
        id: "cyber-c3",
        title: "Chapitre 3 : Sécurité Web (Top 10 OWASP)",
        html: `
          <h3>3.1 L'Injection SQL (SQLi)</h3>
          <p>Elle survient quand le serveur colle directement la saisie d'un utilisateur dans une requête SQL. L'attaquant modifie la requête pour lire toute la base ou se connecter sans mot de passe.</p>

          <h3>3.2 La faille XSS (Cross-Site Scripting)</h3>
          <p>Un pirate injecte du code <strong>JavaScript malveillant</strong> dans une page (ex: un commentaire). Le navigateur des autres visiteurs exécute ce script et peut envoyer leurs cookies de session au pirate.</p>
          <div class="code-box">
            <div class="code-header"><span>Comparatif — Code Vulnérable vs Sécurisé</span><button class="copy-btn" onclick="copyCode(this)">Copier</button></div>
<pre><span class="cmt">// 1. SQLi : VULNÉRABLE</span>
sql = <span class="str">"SELECT * FROM users WHERE nom = '"</span> + saisie + <span class="str">"'"</span>;
<span class="cmt">// SQLi : SÉCURISÉ (Requête préparée)</span>
stmt = db.<span class="fn">prepare</span>(<span class="str">"SELECT * FROM users WHERE nom = ?"</span>);
stmt.<span class="fn">execute</span>([saisie]);

<span class="cmt">// 2. XSS : SÉCURISÉ (textContent neutralise les balises &lt;script&gt;)</span>
element.textContent = commentaireUtilisateur;</pre>
          </div>

          <h3>3.3 Autres failles critiques</h3>
          <ul>
            <li><strong>Broken Access Control :</strong> Un utilisateur accède aux pages d'administration en modifiant l'URL sans vérification côté serveur.</li>
            <li><strong>CSRF :</strong> Un site externe piégé force votre navigateur (déjà connecté) à envoyer une action à votre insu. Parade : utiliser un <em>jeton CSRF</em> secret.</li>
          </ul>
        `
      },
      {
        id: "cyber-c4",
        title: "Chapitre 4 : Défense en Profondeur & Sauvegardes",
        html: `
          <h3>4.1 La Défense en Profondeur</h3>
          <p>On superpose plusieurs barrières de sécurité afin que si une protection tombe, la suivante bloque l'attaquant :</p>
          <ul>
            <li><strong>Pare-feu (Firewall) :</strong> Filtre les connexions entrantes et sortantes selon les IP et ports autorisés.</li>
            <li><strong>DMZ (Zone Démilitarisée) :</strong> Zone isolée hébergeant les serveurs publics (Web, Mail) loin du réseau interne privé.</li>
            <li><strong>VPN :</strong> Crée un tunnel chiffré pour travailler à distance en sécurité.</li>
            <li><strong>IDS / IPS :</strong> Systèmes détectant et bloquant les comportements suspects sur le réseau.</li>
          </ul>

          <h3>4.2 Règles d'or d'administration</h3>
          <ul>
            <li><strong>Moindre Privilège :</strong> Donner uniquement les droits strictement nécessaires à chaque utilisateur (ne pas travailler en <em>Admin/root</em> au quotidien).</li>
            <li><strong>MFA / 2FA :</strong> Exiger au moins deux preuves d'identité (mot de passe + code téléphone ou clé matérielle).</li>
          </ul>
          <div class="note-box">
            <strong>📌 Règle de sauvegarde 3-2-1 (Anti-Ransomware) :</strong><br/>
            Gardez toujours <strong>3</strong> copies de vos données, sur <strong>2</strong> supports différents (ex: SSD + disque externe), dont <strong>1</strong> copie hors-site ou totalement <strong>déconnectée</strong> du réseau.
          </div>
        `
      }
    ],
    exercises: [
      {
        title: "Audit de code : Trouver 2 failles graves",
        prompt: "Un développeur code une page de connexion :<br/>1) Il stocke les mots de passe via un simple <code>md5(mot_de_passe)</code>.<br/>2) Il vérifie via : <code>SELECT id FROM users WHERE email='$email' AND pass='$hash'</code>.<br/>Citez les 2 failles et leurs corrections.",
        solution: "<strong>1) Hachage faible :</strong> MD5 est obsolète et rapide à casser via des tables précalculées. <strong>Correction :</strong> Utiliser <code>Argon2</code> ou <code>bcrypt</code> avec un sel.<br/><br/><strong>2) Injection SQL :</strong> La variable <code>$email</code> est concaténée dans la requête. <strong>Correction :</strong> Utiliser une <strong>requête préparée</strong> avec paramètres liés (<code>?</code>)."
      },
      {
        title: "Échange confidentiel et signé (Alice → Bob)",
        prompt: "Alice envoie un contrat à Bob. Elle veut que <strong>seul Bob puisse le lire</strong> et que Bob soit certain qu'il <strong>vient bien d'Alice</strong>. Quelles clés Alice utilise-t-elle ?",
        solution: "1) <strong>Signer :</strong> Alice signe avec <strong>SA propre clé privée</strong> (Bob vérifiera avec la clé publique d'Alice).<br/>2) <strong>Chiffrer :</strong> Alice chiffre le message avec la <strong>clé publique DE BOB</strong> (seul Bob pourra lire avec sa clé privée)."
      },
      {
        title: "Réagir face à un Ransomware",
        prompt: "Un employé ouvre une pièce jointe piégée : son poste et le partage réseau sont chiffrés par un rançongiciel. Comment le <strong>moindre privilège</strong> et la règle <strong>3-2-1</strong> sauvent l'entreprise ?",
        solution: "• Le <strong>moindre privilège</strong> limite les dégâts aux seuls dossiers de cet employé (les autres serveurs restent intacts).<br/>• La règle <strong>3-2-1</strong> fournit une sauvegarde déconnectée saine pour tout restaurer sans payer la rançon."
      }
    ],
    quiz: [
      {
        q: "Quel pilier de la triade CIA garantit qu'un fichier n'a pas été modifié en chemin par un attaquant ?",
        options: ["Confidentialité", "Intégrité", "Disponibilité", "Ergonomie"],
        answer: 1,
        explanation: "L'intégrité assure que les données restent exactes et intactes (vérifiée via SHA-256 ou signature)."
      },
      {
        q: "Quelle méthode cryptographique est IRRÉVERSIBLE (à sens unique) ?",
        options: ["Le chiffrement symétrique AES", "Le chiffrement asymétrique RSA", "Le hachage (bcrypt, SHA-256)", "Le tunnel VPN"],
        answer: 2,
        explanation: "On ne peut pas inverser un hash pour retrouver le texte d'origine."
      },
      {
        q: "Quelle parade principale bloque l'attaque par Injection SQL (SQLi) ?",
        options: [
          "Mettre le site en mode sombre",
          "Utiliser des requêtes préparées (paramétrées)",
          "Renommer la base de données",
          "Désactiver le Wi-Fi"
        ],
        answer: 1,
        explanation: "Les requêtes préparées séparent strictement le code SQL des données saisies par l'utilisateur."
      },
      {
        q: "Que signifie la faille XSS (Cross-Site Scripting) ?",
        options: [
          "Une panne de câble réseau",
          "L'injection de code JavaScript malveillant exécuté dans le navigateur des victimes",
          "Un disque dur plein",
          "Un mot de passe trop long"
        ],
        answer: 1,
        explanation: "Le XSS permet d'exécuter un script piégé chez les visiteurs pour voler leurs sessions ou modifier la page."
      },
      {
        q: "Dans la règle de sauvegarde 3-2-1, à quoi correspond le '1' ?",
        options: [
          "1 seul mot de passe pour tout",
          "1 copie stockée hors-site ou déconnectée du réseau",
          "1 heure de sauvegarde par an",
          "1 seul administrateur"
        ],
        answer: 1,
        explanation: "Garder au moins 1 copie hors-site / déconnectée empêche un ransomware ou un incendie de détruire toutes les sauvegardes."
      }
    ]
  });
}