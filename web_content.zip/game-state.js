/* ==========================================================
   抽屉① 状态层：变量池 / 数值增减 / 阶段换算 / 存档
   不碰 DOM，不认剧情
   ========================================================== */
const TOTAL = 60;
const SAVE_KEY = 'sakura60_final_v3_doc';

/* ===== 剧情数据手册 v3.0 · 全局常量（表2-4 / 表3-5） ===== */
const EXCHANGE_DAYS       = 60;   // 交换期总天数
const WEEK_COUNT          = 8;    // 八个剧情周
const EXP_MAX_CAP         = 35;   // P1 共通期 fav_shen 上限
const FAV_SPLIT           = 25;   // P1 分线阈值（BP-1）
const DUAL_AFFINITY       = 15;   // 双高提醒 / 摇摆事件阈值
const LU_AFFINITY_VISIBLE = 20;   // 陆鸣意向可见阈值（文档 40 不可达，按 C-9 下调）
const COURAGE_SPLIT       = 30;   // D29 共伞阈值（BP-2）
const COURAGE_LETTER      = 40;   // D46“交”选项可见阈值（文档 50 不可达，按 C-3 下调）
const CONFESS_MIN         = 60;   // 告白成立门槛
const END_A_MIN           = 80;   // END_A 锁定门槛
const MAX_FAV             = 100;
const SAKURA_WARN_DAY     = 50;   // 樱花凋零预警日
const SAKURA_LEFT_DAYS    = 10;
const SICK_PENALTY        = -1;   // 淋雨感冒学习值变化

const clamp = (v,a,b) => Math.max(a,Math.min(b,v));
const pick = a => a[Math.floor(Math.random()*a.length)];

const WEEK = ['周一','周二','周三','周四','周五','周六','周日'];
const PHASE = {morning:'早晨',class:'上午 · 上课',noon:'午后',after:'放学后',night:'夜晚'};

const weekdayOf = d => WEEK[(d-1)%7];
const isWeekend = d => ((d-1)%7) >= 5;
const weekIdx   = d => Math.floor((d-1)/7);

const CONFLICTS = [
  {pair:'shen_lu',a:'shen',b:'lu',topic:'规则主义 vs 热血自由'},
  {pair:'su_lin', a:'su',  b:'lin',topic:'理想文艺 vs 现实生存'},
  {pair:'shen_su',a:'shen',b:'su', topic:'责任枷锁 vs 自我追寻'},
  {pair:'lu_lin', a:'lu',  b:'lin',topic:'粗线条直球 vs 傲娇敏感'}
];

let G = null;

function newGame(){
  G = {
    day:0, phase:'morning', weather:'晴',
    stats:{charm:10,study:10,sport:10,social:10,courage:10},
    fav:{shen:0,lu:0,su:0,lin:0},
    tense:{shen:0,lu:0,su:0,lin:0},
    rival:{shen_lu:0,su_lin:0,shen_su:0,lu_lin:0},
    memory:{shen:[],lu:[],su:[],lin:[]},
    secret:{shen:false,lu:false,su:false,lin:false},
    snub:{shen:0,lu:0,su:0,lin:0},
    lastVisit:{shen:-99,lu:-99,su:-99,lin:-99},
    selfCount:0,club:null,flags:{},leave:{},
    achievements:[],ended:false,inviteCount:0,
    lastPlaceNpc:{},apologyUsed:false,
    /* ===== 文档 v3.0 三路线剧情层（表3-1）===== */
    story:{
      phase:'P1',              // P1–P6 阶段码
      route:'',                // '' / A 心动 / B 遗憾 / C 隔阂
      intent:'UNSET',          // SHEN / LU / UNSET
      tense:0,                 // 隔阂度（C 线钳制 62）
      courage:10,              // 勇气值（沿用属性起点，阈值见附录C C-3）
      secretShen:false,        // 退会申请书是否被看见
      study:0,                 // 学习值，允许负值
      flags:{},                // shen_* / f_* 文档 flag
      lastEnding:''            // END_A / END_B / END_C
    }
  };
}

/* ---- 文档 v3.0 剧情层工具（三路线专用） ---- */
function S(){ return G.story; }

/* 写好感：P1 共通期对沈逸舟封顶 EXP_MAX_CAP（表2-4） */
function storyFav(who,v){
  if(!G.story || !v) return 0;
  const before = G.fav[who] || 0;
  let nv = before + v;
  if(G.story.phase === 'P1' && who === 'shen') nv = Math.min(nv, EXP_MAX_CAP);
  G.fav[who] = clamp(nv, 0, MAX_FAV);
  const real = G.fav[who] - before;
  if(real && typeof floatText === 'function') floatText(who, real, '♥');
  return real;
}
/* 写隔阂度（单值，区别于沙盒的 G.tense.xxx） */
function storyTense(v){
  if(!G.story || !v) return;
  G.story.tense = clamp(G.story.tense + v, 0, MAX_FAV);
}
/* 写勇气值，同时同步属性面板 */
function storyCourage(v){
  if(!G.story || !v) return;
  G.story.courage = clamp(G.story.courage + v, 0, MAX_FAV);
  G.stats.courage = clamp(G.stats.courage + v, 0, 100);
}
function storyFlag(k,v){ if(G.story && k) G.story.flags[k] = (v === undefined ? true : v); }
function storyStudy(v){
  if(!G.story || !v) return;
  G.story.study = clamp(G.story.study + v, -10, 10);
}
/* 统一结算一个剧情选项的 effects（表4-1 / 表3-8） */
function storyEffect(e){
  if(!e) return;
  if(e.favShen) storyFav('shen', e.favShen);
  if(e.favLu)   storyFav('lu',   e.favLu);
  if(e.tense)   storyTense(e.tense);
  if(e.courage) storyCourage(e.courage);
  if(e.study)   storyStudy(e.study);
  if(e.secret)  G.story.secretShen = true;
  if(e.flags)   e.flags.forEach(f=> storyFlag(f));
}

/* ---- 五个判定点（表3-2） ---- */
/* BP-1：D14 分线，wrote = 'SHEN' | 'LU' */
function bp1(wrote){
  const s = G.story;
  if(wrote === 'SHEN' && G.fav.shen >= FAV_SPLIT){
    s.phase = 'P2'; s.route = '';
    storyFlag('f_route_lock');
    return 'HB';
  }
  s.phase = 'P6'; s.route = 'C';
  G.fav.shen = 22;          // 原文基线钳制
  s.tense = 62;
  s.secretShen = false;
  storyFlag('f_route_lock');
  return 'C';
}
/* BP-1.5：D28 意向，pick = 'SHEN' | 'LU' | 'UNSET' */
function bp15(pick){
  const s = G.story;
  if(pick === 'LU' && G.fav.lu >= LU_AFFINITY_VISIBLE){
    s.intent = 'LU'; s.route = 'B'; s.phase = 'P5';
    storyFlag('f_intent_lock');
    return 'B';
  }
  s.intent = (pick === 'SHEN' ? 'SHEN' : 'UNSET');
  storyFlag('f_intent_lock');
  return 'P2';
}
/* BP-2：D29 勇气分支 */
function bp2(){
  const s = G.story;
  if(s.courage >= COURAGE_SPLIT){ s.route = 'A'; s.phase = 'P4'; return 'A'; }
  s.route = 'B'; s.phase = 'P5'; return 'B';
}
/* BP-3：D46 交信 */
function bp3(isJiao){
  storyFlag('shen_against_family', !!isJiao);
  return isJiao ? 'END_A' : 'END_B';
}
/* flag 查询：文档 flag 写在 story.flags，老事件写在 G.flags，两处都要看 */
function hasFlag(k){
  return !!(G.story && G.story.flags[k]) || !!(G.flags && G.flags[k]);
}
/* 结局判定：表3-6，优先级 1→3，命中即停 */
function judgeEnding(){
  const s = G.story, f = G.fav.shen;
  if(s.route === 'A' && f >= END_A_MIN && hasFlag('f_honest_love') && hasFlag('shen_against_family'))
    return 'END_A';
  if((s.route === 'A' || s.route === 'B') && f >= 55 && !hasFlag('shen_against_family'))
    return 'END_B';
  if(s.route === 'C' && f <= 22 && s.secretShen === false)
    return 'END_C';
  /* 兜底：表3-6 未覆盖的低数值情况，按路线落到遗憾/隔阂 */
  return s.route === 'C' ? 'END_C' : 'END_B';
}

/* ---- 数值增减 ---- */
function addFav(obj){
  if(!obj) return;
  Object.keys(obj).forEach(k=>{
    if(!NPC[k]) return;
    const v = obj[k];
    G.fav[k] = clamp(G.fav[k]+v,0,100);
    /* P1 共通期对沈逸舟封顶 35（表2-4 EXP_MAX_CAP） */
    if(G.story && G.story.phase==='P1' && k==='shen') G.fav[k]=Math.min(G.fav[k],EXP_MAX_CAP);
    if(v && typeof floatText === 'function') floatText(k,v,'♥');
  });
}
function addTense(obj){
  if(!obj) return;
  Object.keys(obj).forEach(k=>{
    if(!NPC[k]) return;
    const v = obj[k];
    G.tense[k] = clamp(G.tense[k]+v,0,100);
    if(v && typeof floatText === 'function') floatText(k,v,'⚡',true);
  });
}
function addStat(obj){
  if(!obj) return;
  Object.keys(obj).forEach(k=>{
    if(G.stats[k]===undefined) return;
    G.stats[k] = clamp(G.stats[k]+obj[k],0,100);
    /* 勇气是剧情变量：属性面板与 story.courage 同步（表3-1 courage） */
    if(G.story && k==='courage') G.story.courage = clamp(G.story.courage+obj[k],0,MAX_FAV);
  });
}
function addRival(pairKey, amount){
  if(G.rival[pairKey] === undefined) return;
  G.rival[pairKey] = clamp(G.rival[pairKey]+amount, 0, 100);
}
function remember(k,text){
  if(!NPC[k]||!text) return;
  if(!G.memory[k].includes(text)) G.memory[k].push(text);
}

/* ---- 阶段换算 ---- */
function favStage(v){
  if(v<=19) return {name:'陌生人',color:'#b0a3ab',idx:0};
  if(v<=39) return {name:'认识',  color:'#7fa8c9',idx:1};
  if(v<=59) return {name:'友好',  color:'#54b18a',idx:2};
  if(v<=79) return {name:'暧昧',  color:'#e8618f',idx:3};
  return           {name:'心动',  color:'#e5344f',idx:4};
}
function tenseStage(t){
  if(t<=19) return {name:'如常',color:'#7fb0a0'};
  if(t<=39) return {name:'带刺',color:'#e0b03c'};
  if(t<=59) return {name:'隔阂',color:'#e08c3c'};
  if(t<=79) return {name:'疏远',color:'#d9534f'};
  return           {name:'决裂',color:'#a52a2a'};
}

/* ---- 关系工具 ---- */
function topFav(){
  return Object.keys(G.fav).reduce((a,b)=> G.fav[a]>=G.fav[b]?a:b);
}
function pairOf(a,b){
  for(const c of CONFLICTS){
    if((c.a===a&&c.b===b)||(c.a===b&&c.b===a)) return c.pair;
  }
  return null;
}
function bonusOf(npcId){
  return (typeof NPC!=='undefined' && G.stats[NPC[npcId].bonus] >= 40) ? 2 : 0;
}
function favWithBonus(npcId,base){
  const bonus = bonusOf(npcId);
  addFav({[npcId]:base+bonus});
  return {total:base+bonus,bonus};
}
function checkJealous(currentNpc, gain){
  if(!currentNpc || gain < 5) return null;
  const present = G.flags['_present_npcs'] || [];
  for(const other of present){
    if(other === currentNpc) continue;
    if(G.fav[other] >= 60){
      const pk = pairOf(other, currentNpc);
      if(pk){
        addRival(pk, 12);
        return (typeof JEALOUS!=='undefined') ? JEALOUS[other] : null;
      }
    }
  }
  return null;
}
function snubCheck(npcId){
  const lastDay = G.lastVisit[npcId];
  if(G.fav[npcId] >= 60 && G.day - lastDay >= 2 && G.snub[npcId] < 2){
    G.snub[npcId]++;
    remember(npcId, `第${G.day}天，${NPC[npcId].name}开始注意到你不在。`);
    return true;
  }
  return false;
}

/* ---- 成就 ---- */
function unlockAch(id,name,icon='🏆'){
  if(!G||G.achievements.includes(id)) return;
  G.achievements.push(id);
  if(typeof toast === 'function') toast('成就解锁：'+name,icon);
}
function checkAch(){
  if(G.stats.study>=60) unlockAch('study60','优等生','📚');
  if(G.stats.courage>=40) unlockAch('courage40','敢开口的人','🔥');
  const seen = Object.values(G.secret).filter(Boolean).length;
  if(seen>=2) unlockAch('see2','看见两个人','👁');
  if(seen>=4) unlockAch('see4','全部都看见了','👁');
  const high = Object.keys(G.fav).filter(k=> G.fav[k]>=75);
  if(high.length>=2) unlockAch('two80','左右为难','💔');
  if(G.selfCount>=8) unlockAch('alone','一个人的六十天','🌙');
  if(G.flags['f_peacemaker']) unlockAch('peace','和平主义者','🕊');
}

/* ---- 存档 / 读档 ---- */
function saveGame(){
  if(!G){ if(typeof toast === 'function') toast('还没有开始游戏','💾'); return; }
  try{
    localStorage.setItem(SAVE_KEY, JSON.stringify(G));
    if(typeof toast === 'function') toast('已存档','💾');
  }catch(e){
    if(typeof toast === 'function') toast('存档失败','⚠️');
  }
}
function loadGame(){
  try{
    const raw = localStorage.getItem(SAVE_KEY);
    if(!raw){ if(typeof toast === 'function') toast('没有找到存档','📂'); return; }
    G = JSON.parse(raw);
    /* 旧存档兼容：补上 v3 剧情层字段 */
    if(!G.story) G.story = {
      phase:'P1', route:'', intent:'UNSET', tense:0, courage:G.stats ? (G.stats.courage||10) : 10,
      secretShen:!!(G.secret && G.secret.shen), study:0, flags:{}, lastEnding:''
    };
    if(typeof renderHUD === 'function') renderHUD();
    if(typeof toast === 'function') toast('读档成功','📂');
    if(G.phase==='night') nightPhase();
    else if(G.phase==='morning') morningPhase();
    else gotoPhase(G.phase||'morning');
  }catch(e){
    if(typeof toast === 'function') toast('读档失败','⚠️');
  }
}
//（注：内容由AI生成）