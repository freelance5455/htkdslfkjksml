ISMA3IL MHBOUL - AndroidIDE project

1. Open this folder in AndroidIDE.
2. Wait for Gradle sync.
3. Build > Assemble Debug (or the Build APK option).
4. Install the generated app-debug.apk.

The game is bundled locally in app/src/main/assets/index.html, so no internet is required to play.
