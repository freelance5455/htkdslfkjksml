package com.carxx.sensi

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Build
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient

class MainActivity : Activity() {
    private lateinit var appWebView: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        appWebView = WebView(this)
        appWebView.settings.javaScriptEnabled = true
        appWebView.settings.domStorageEnabled = true
        appWebView.isFocusable = true
        appWebView.isFocusableInTouchMode = true
        appWebView.requestFocus()
        appWebView.settings.allowFileAccess = true
        appWebView.settings.allowContentAccess = false
        appWebView.webViewClient = WebViewClient()
        appWebView.webChromeClient = WebChromeClient()
        appWebView.addJavascriptInterface(DeviceInfoBridge(), "AndroidDeviceInfo")
        setContentView(appWebView)
        appWebView.loadUrl("file:///android_asset/index.html")
    }

    // Re-check the permission after the user returns from Android Settings.
    override fun onResume() {
        super.onResume()
        if (::appWebView.isInitialized) {
            appWebView.post {
                appWebView.evaluateJavascript(
                    "if (typeof refreshOverlay === 'function') refreshOverlay();",
                    null
                )
            }
        }
    }

    inner class DeviceInfoBridge {
        @JavascriptInterface
        fun hasOverlayPermission(): Boolean = Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this@MainActivity)

        @JavascriptInterface
        fun requestOverlayPermission() {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M ||
                Settings.canDrawOverlays(this@MainActivity)) return

            runOnUiThread {
                // Open this app's "Display over other apps" page first.
                val appPermissionIntent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                try {
                    startActivity(appPermissionIntent)
                } catch (_: Exception) {
                    // Some Android builds do not accept the package-specific URI.
                    try {
                        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION))
                    } catch (_: Exception) {
                        // Keep the app usable if the device has no matching Settings screen.
                    }
                }
            }
        }

        @JavascriptInterface
        private fun launchOverlayService(action: String, locked: Boolean? = null) {
            val intent = Intent(this@MainActivity, CrosshairService::class.java).setAction(action)
            if (locked != null) intent.putExtra(CrosshairService.EXTRA_LOCKED, locked)
            // Android 8+ requires foreground-service startup for a service that
            // immediately calls startForeground(). A normal startService() can fail.
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                this@MainActivity.startForegroundService(intent)
            } else {
                this@MainActivity.startService(intent)
            }
        }

        @JavascriptInterface
        fun showCrosshair() {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this@MainActivity)) {
                throw IllegalStateException("Overlay permission is not enabled")
            }
            launchOverlayService(CrosshairService.ACTION_SHOW)
        }

        @JavascriptInterface
        fun hideCrosshair() {
            launchOverlayService(CrosshairService.ACTION_HIDE)
        }

        @JavascriptInterface
        fun setCrosshairLocked(locked: Boolean) {
            launchOverlayService(CrosshairService.ACTION_LOCK, locked)
        }

        @JavascriptInterface
        fun getDeviceModel(): String {
            val manufacturer = Build.MANUFACTURER.orEmpty().trim()
            val model = Build.MODEL.orEmpty().trim()
            return listOf(manufacturer, model).filter { it.isNotBlank() }
                .distinct().joinToString(" ").ifBlank { "Unknown Android device" }
        }

        @JavascriptInterface
        fun getModel(): String = getDeviceModel()

        @JavascriptInterface
        fun getDeviceDetails(): String {
            return "brand=${Build.BRAND};manufacturer=${Build.MANUFACTURER};model=${Build.MODEL};device=${Build.DEVICE};product=${Build.PRODUCT};android=${Build.VERSION.RELEASE}"
        }
    }

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        if (::appWebView.isInitialized && appWebView.canGoBack()) {
            appWebView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
