HESHAN TRADING - HTML APP PACKAGE

Files:
- index.html : Main app file

HOW TO USE:
1. Extract this ZIP file on your phone or computer.
2. Open index.html in a browser (such as Chrome).

IMPORTANT:
- This is an HTML web app package, not an installable Android APK.
- App data is stored in the browser on the device. Export/backup data regularly before clearing browser data or changing devices.
- To turn this into an APK, use an Android WebView wrapper/builder and load the included index.html as a local asset.
