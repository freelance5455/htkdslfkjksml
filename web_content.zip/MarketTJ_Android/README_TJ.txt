MARKET TJ — ANDROID WEBVIEW PROJECT

Ин лоиҳаи Android Studio дорои WebView-и танзимшуда мебошад.

Функсияҳо:
- HTML дар дохили APK аз app/src/main/assets/index.html кушода мешавад.
- Барои input type=file, WebChromeClient.onShowFileChooser() интихобгари расмро мекушояд ва натиҷаро ба WebView бармегардонад.
- Барои истиноди tel:, WebViewClient онро ба ACTION_DIAL мефиристад; рақам дар барномаи телефон нишон дода мешавад, зангро худи истифодабаранда тасдиқ мекунад.
- JavaScript, DOM storage ва интернет фаъоланд, то Supabase кор карда тавонад.

СОХТАНИ APK:
1. Лоиҳаи MarketTJ_Android-ро дар Android Studio кушоед.
2. Gradle Sync-ро анҷом диҳед.
3. Build > Build Bundle(s) / APK(s) > Build APK(s)-ро интихоб кунед.
4. APK-и ҳосилшударо дар телефон насб кунед.

ЭЗОҲ:
Ин ZIP APK-и тайёр нест; он манбаи лоиҳа аст. Барои сохтани APK Android Studio ва Android SDK лозиманд.
Ин муҳит APK-ро компайл ва дар телефони воқеӣ санҷида наметавонад. Иҷрои боркунии расм ба Supabase ҳамчунин ба танзими дурусти Storage bucket ва сиёсати иҷозатҳо вобаста аст.
