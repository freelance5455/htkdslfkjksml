ScoreDeck — Sample Papers / Pen-and-Paper Mode

This package is an incremental modification of the existing ScoreDeck HTML project.

Added:
- Dedicated Sample Papers main section.
- Five supplied CBSE 2026–27 sample papers: Accountancy 055, Business Studies 054, Economics 030, Applied Mathematics 241, English Core 301.
- Complete paper viewer rendered from the supplied PDFs, with page navigation and zoom.
- Print / Save PDF opens the supplied original PDF without rewriting its questions.
- Separate sample-paper session storage under scoredeck_samplepaper_v1_ (not mixed with the legacy practice storage).
- Timestamp-based 3-hour physical-test timer that resumes after reload/backgrounding.
- Manual question tracker: Not Attempted / Attempted / Review.
- Finish Test -> self-entered result workflow.
- Question-wise marks, mistake reasons and improvement notes.
- Result/history views and retry without overwriting previous attempts.
- Link from result analysis back to the existing Question Practice system.
- Clear distinction between automatically known information and student-entered checking.

Source rule:
The five supplied CBSE 2026–27 sample-paper PDFs are the authoritative paper sources in this package. No questions were invented or rewritten. No official CBSE answer key/model answer was supplied with these uploads, so the app does not fabricate one. The review area is labelled as practice review and not official CBSE evaluation.

Preserved:
- Existing question bank and subject data.
- Existing blueprints.
- Existing navigation and subject IDs.
- Existing localStorage key boardboost_v3_ for legacy user data compatibility.
- Existing Question Practice and home-page functionality, with a minimal fix to the existing practice-result calculation so its result screen no longer references undefined variables.

Files:
- CBSE_12_Commerce_Practice_Dashboard.html — main app.
- papers/*.pdf — original supplied sample papers.
- paper_images/<paper-id>/*.jpg — page renders used by the in-app paper viewer.
