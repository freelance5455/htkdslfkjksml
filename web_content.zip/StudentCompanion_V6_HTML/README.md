# Student Companion V6 — HTML Edition

A responsive, browser-based version of the Student Companion app.

## Run
1. Extract the ZIP.
2. Open `index.html` in a modern browser.
3. For the best installable/PWA experience, serve the folder from a local web server (for example VS Code Live Server).

## Included
- Dashboard
- One-tap attendance: Present / Absent / Undo
- Attendance percentage
- Safe bunks while staying at 75%
- Recovery classes needed to reach 75%
- Tasks and assignments
- Study-session logging
- Exam planner
- Weekly timetable
- Analytics with charts
- Smart progress insights
- Local persistent storage with `localStorage`
- JSON backup export/import
- Reset data
- 11 themes:
  Dark, Light, AMOLED, Ocean Blue, Forest Green, Sunset, Sakura Pink,
  Midnight Purple, Cyber Teal, Royal Gold, Custom Accent
- Responsive mobile/desktop layout
- PWA manifest

## Data
All data stays in the browser on the current device/profile. Use Export Backup before moving devices or clearing browser storage.

## Notes
This version is deliberately dependency-free: charts are drawn with the Canvas API, so the project works without a CDN or internet connection.
