package com.touchline.manager;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

/**
 * Touchline: a thin Android shell around the web game in assets/.
 * The game itself lives in index.html + the .js/.css files next to it.
 */
public class MainActivity extends Activity {
  private static final int BG = Color.parseColor("#10291E");
  private static final int REQ_SAVE_FILE = 41;
  private static final int REQ_PICK_FILE = 42;

  private WebView webView;
  private String pendingExport;
  private ValueCallback<Uri[]> filePathCallback;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);

    // Draw behind the system bars (forced on Android 15) and pad the game ourselves.
    if (Build.VERSION.SDK_INT >= 30) {
      getWindow().setDecorFitsSystemWindows(false);
    }
    getWindow().setStatusBarColor(BG);
    getWindow().setNavigationBarColor(BG);

    FrameLayout root = new FrameLayout(this);
    root.setBackgroundColor(BG);
    root.setOnApplyWindowInsetsListener((v, insets) -> {
      int left, top, right, bottom;
      if (Build.VERSION.SDK_INT >= 30) {
        android.graphics.Insets i = insets.getInsets(
            WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout() | WindowInsets.Type.ime());
        left = i.left; top = i.top; right = i.right; bottom = i.bottom;
      } else {
        left = insets.getSystemWindowInsetLeft();
        top = insets.getSystemWindowInsetTop();
        right = insets.getSystemWindowInsetRight();
        bottom = insets.getSystemWindowInsetBottom();
      }
      v.setPadding(left, top, right, bottom);
      return Build.VERSION.SDK_INT >= 30 ? WindowInsets.CONSUMED : insets.consumeSystemWindowInsets();
    });

    webView = new WebView(this);
    webView.setBackgroundColor(BG);
    root.addView(webView, new FrameLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    setContentView(root);

    WebSettings s = webView.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);           // career saves live in localStorage
    s.setAllowFileAccess(false);            // assets still load; arbitrary files do not
    s.setAllowContentAccess(false);
    s.setBuiltInZoomControls(false);
    s.setSupportZoom(false);
    s.setMediaPlaybackRequiresUserGesture(true);

    webView.addJavascriptInterface(new Bridge(), "TouchlineAndroid");

    webView.setWebViewClient(new WebViewClient() {
      @Override
      public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
        Uri uri = request.getUrl();
        String scheme = uri.getScheme();
        if ("file".equals(scheme)) return false;      // our own pages stay in the app
        if ("http".equals(scheme) || "https".equals(scheme) || "mailto".equals(scheme)) {
          try {
            startActivity(new Intent(Intent.ACTION_VIEW, uri));   // links open in the browser
          } catch (Exception ignored) { }
        }
        return true;
      }
    });

    // Lets the game's "Import save" button open the Android file picker.
    webView.setWebChromeClient(new WebChromeClient() {
      @Override
      public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
        if (filePathCallback != null) filePathCallback.onReceiveValue(null);
        filePathCallback = callback;
        try {
          startActivityForResult(params.createIntent(), REQ_PICK_FILE);
        } catch (Exception e) {
          filePathCallback = null;
          return false;
        }
        return true;
      }
    });

    webView.loadUrl("file:///android_asset/index.html");
  }

  /** Called from the game (window.TouchlineAndroid.saveFile) to export a save file. */
  private class Bridge {
    @JavascriptInterface
    public void saveFile(String fileName, String json) {
      pendingExport = json;
      runOnUiThread(() -> {
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/json");
        intent.putExtra(Intent.EXTRA_TITLE, fileName);
        try {
          startActivityForResult(intent, REQ_SAVE_FILE);
        } catch (Exception e) {
          Toast.makeText(MainActivity.this, "No file manager available to save the file.", Toast.LENGTH_LONG).show();
        }
      });
    }
  }

  @Override
  protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode, resultCode, data);
    if (requestCode == REQ_PICK_FILE && filePathCallback != null) {
      filePathCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data));
      filePathCallback = null;
    } else if (requestCode == REQ_SAVE_FILE) {
      if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingExport != null) {
        try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
          if (out != null) out.write(pendingExport.getBytes(StandardCharsets.UTF_8));
          Toast.makeText(this, "Save file exported.", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
          Toast.makeText(this, "Could not write the file.", Toast.LENGTH_LONG).show();
        }
      }
      pendingExport = null;
    }
  }

  /** Back closes pop-ups and goes to the Overview first; it only exits from the Overview. */
  @Override
  public void onBackPressed() {
    webView.evaluateJavascript(
        "(function(){return !!(window.touchlineBack && window.touchlineBack());})()",
        value -> {
          if (!"true".equals(value)) finish();
        });
  }

  @Override
  protected void onPause() {
    // Make sure the career is written to storage whenever the app leaves the screen.
    webView.evaluateJavascript("try{persist()}catch(e){}", null);
    webView.onPause();
    super.onPause();
  }

  @Override
  protected void onResume() {
    super.onResume();
    webView.onResume();
  }

  @Override
  protected void onDestroy() {
    if (webView != null) {
      ((ViewGroup) webView.getParent()).removeView(webView);
      webView.destroy();
    }
    super.onDestroy();
  }
}
