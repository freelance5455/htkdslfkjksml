/* =====================================================================
   TOUCHLINE · PAGES
   New career, matchweek flow, match report, and the main pages:
   Overview, Team (tactics + lineup), Squad, League table, Fixtures,
   Stats and Settings. Uses globals from data.js, engine.js, realism.js.
   ===================================================================== */

const enc = (id) => encodeURIComponent(id).replace(/'/g, '%27');
const ordinal = (n) => n + (['th', 'st', 'nd', 'rd'][n % 100 > 10 && n % 100 < 14 ? 0 : n % 10 < 4 ? n % 10 : 0] || 'th');
const blankTable = () => Array.from({ length: 20 }, () => ({ p: 0, w: 0, d: 0, l: 0, gf: 0, ga: 0, pts: 0 }));
const POS_LABEL = { GK: 'Goalkeepers', DEF: 'Defenders', MID: 'Midfielders', ATT: 'Forwards' };

/* ---------- small building blocks ---------- */
const ICONS = {
  home: 'M3 11l9-8 9 8v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z',
  squad: 'M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM22 21v-2a4 4 0 0 0-3-3.9M16 3.1a4 4 0 0 1 0 7.8',
  tactics: 'M3 5h18v14H3zM12 5v14M12 9.5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5zM3 9h3v6H3M21 9h-3v6h3',
  fixtures: 'M4 5h16v16H4zM4 10h16M8 3v4M16 3v4',
  table: 'M4 6h16M4 12h16M4 18h10',
  stats: 'M4 20V11M10 20V4M16 20v-7M22 20H2',
  market: 'M7 7h13l-3-3M20 7l-3 3M17 17H4l3 3M4 17l3-3',
  shortlist: 'M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z',
  youth: 'M2 9l10-5 10 5-10 5zM6 11v5c0 1.5 3 3 6 3s6-1.5 6-3v-5',
  messages: 'M3 6h18v12H3zM3 7l9 6 9-6',
  inbox: 'M5 4h12v16H5zM17 8h3v10a2 2 0 0 1-2 2M8 8h6M8 12h6M8 16h4',
  players: 'M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM4 21a8 8 0 0 1 16 0',
  europe: 'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zM3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18',
  trophies: 'M8 4h8v5a4 4 0 0 1-8 0zM8 6H4a3 3 0 0 0 4 4M16 6h4a3 3 0 0 1-4 4M12 13v4M8 20h8M10 17h4',
  settings: 'M4 6h8M16 6h4M4 12h2M10 12h10M4 18h12M20 18h0M14 4v4M8 10v4M18 16v4',
  more: 'M5 12h.01M12 12h.01M19 12h.01',
  plus: 'M12 5v14M5 12h14',
  close: 'M6 6l12 12M18 6L6 18',
};
const icon = (n) =>
  '<svg class="ic" viewBox="0 0 24 24" aria-hidden="true"><path d="' + (ICONS[n] || ICONS.more) + '"/></svg>';

/* Original crest-style badges drawn in code (not the official club crests).
   To use real images instead, drop files named crests/ARS.png, crests/AVL.png ... next to index.html. */
const USE_CREST_IMAGES = false; /* set to true after adding a crests/ folder with your own images */
const CREST_MISSING = new Set();
const CREST_PATTERNS = [
  (a, b) => '<rect x="17" y="0" width="6" height="48" fill="' + b + '"/>',
  (a, b) => '<rect x="0" y="0" width="10" height="48" fill="' + b + '"/><rect x="20" y="0" width="10" height="48" fill="' + b + '"/><rect x="30" y="0" width="10" height="48" fill="' + a + '"/>',
  (a, b) => '<rect x="0" y="12" width="40" height="8" fill="' + b + '"/><rect x="0" y="28" width="40" height="8" fill="' + b + '"/>',
  (a, b) => '<rect x="20" y="0" width="20" height="48" fill="' + b + '"/>',
  (a, b) => '<path d="M0 14 L20 28 L40 14 L40 24 L20 38 L0 24Z" fill="' + b + '"/>',
  (a, b) => '<path d="M0 8 L8 0 L40 34 L40 44 Z" fill="' + b + '"/>',
  (a, b) => '<rect x="0" y="19" width="40" height="8" fill="' + b + '"/><rect x="16" y="0" width="8" height="48" fill="' + b + '"/>',
];
function lumOf(hex) {
  let h = hex.replace('#', '');
  return (0.299 * parseInt(h.slice(0, 2), 16) + 0.587 * parseInt(h.slice(2, 4), 16) + 0.114 * parseInt(h.slice(4, 6), 16)) / 255;
}
function crestSvg(ci, big) {
  let c = clubs[ci],
    a = c.color,
    light = lumOf(a) > 0.62,
    b = light ? '#17231c' : '#ffffff',
    ink = light ? '#17231c' : '#ffffff',
    halo = light ? '#ffffff' : '#10291e',
    id = 'cr' + ci,
    txt = big ? c.code : c.code[0],
    fs = big ? 12 : 22;
  return (
    '<svg viewBox="0 0 40 48" aria-hidden="true"><defs><clipPath id="' + id + '"><path d="M3 3 H37 V24 C37 35 29 42 20 46 C11 42 3 35 3 24 Z"/></clipPath></defs>' +
    '<g clip-path="url(#' + id + ')"><rect width="40" height="48" fill="' + a + '"/>' + CREST_PATTERNS[ci % CREST_PATTERNS.length](a, b).replace(/fill="/g, 'opacity=".55" fill="') + '</g>' +
    '<path d="M3 3 H37 V24 C37 35 29 42 20 46 C11 42 3 35 3 24 Z" fill="none" stroke="' + b + '" stroke-width="2.4" stroke-linejoin="round" opacity=".9"/>' +
    '<text x="20" y="' + (big ? 29 : 31) + '" text-anchor="middle" font-family="Manrope,DM Sans,system-ui,sans-serif" font-weight="800" font-size="' + fs + '" fill="' + ink + '" stroke="' + halo + '" stroke-width="2.6" paint-order="stroke" stroke-linejoin="round">' + safe(txt) + '</text></svg>'
  );
}
function clubBadge(ci, cls = '') {
  let c = clubs[ci],
    img = !USE_CREST_IMAGES || CREST_MISSING.has(c.code) ? '' : '<img alt="" src="crests/' + c.code + '.png" onload="this.parentNode.classList.add(\'hasimg\')" onerror="CREST_MISSING.add(\'' + c.code + '\');this.remove()">';
  return '<span class="cbadge ' + cls + '" title="' + safe(c.name) + '">' + crestSvg(ci, cls.includes('lg')) + img + '</span>';
}
function formOf(ci, n = 5) {
  let out = [];
  for (let w = (S.week || 1) - 1; w >= 1 && out.length < n; w--) {
    let r = (S.results?.[w] || []).find((x) => x[0] === ci || x[1] === ci);
    if (!r) continue;
    let gf = r[0] === ci ? r[2] : r[3],
      ga = r[0] === ci ? r[3] : r[2];
    out.push(gf > ga ? 'W' : gf === ga ? 'D' : 'L');
  }
  return out.reverse();
}
function formDots(list) {
  return (
    '<span class="form">' +
    (list.length ? list.map((x) => '<i class="f' + x + '">' + x + '</i>').join('') : '<em class="muted">No games yet</em>') +
    '</span>'
  );
}
function bar(label, a, b, fmt = (x) => Math.round(x)) {
  let tot = Math.max(1, a + b),
    pa = Math.round((a / tot) * 100);
  return (
    '<div class="cmp"><span class="cmp-n">' + fmt(a) + '</span><div class="cmp-mid"><small>' + label +
    '</small><div class="cmp-bar"><i style="width:' + pa + '%"></i></div></div><span class="cmp-n">' + fmt(b) + '</span></div>'
  );
}
function fitBar(v) {
  v = Math.round(v ?? 100);
  return '<span class="fit ' + (v < 60 ? 'bad' : v < 80 ? 'mid' : '') + '" title="Fitness ' + v + '%"><i style="width:' + v + '%"></i></span>';
}
function avgRating(p) {
  return p.st && p.st.rn ? p.st.rt / p.st.rn : 0;
}
function statusOf(p) {
  return p.injuryWeeks
    ? '<span class="tag bad">Injured · ' + p.injuryWeeks + 'w</span>'
    : p.ban
      ? '<span class="tag bad">Banned · ' + p.ban + '</span>'
      : p.loanWeeks
        ? '<span class="tag">On loan · ' + p.loanWeeks + 'w</span>'
        : p.transferListed
          ? '<span class="tag">Listed</span>'
          : '<span class="tag ok">Fit</span>';
}

/* ---------- new career ---------- */
function buildPlayers() {
  return clubs.map((c, ci) => {
    let base = c.players.filter((p) => !p.young && !legacyBlacklist[c.name]?.includes(p.name)).map((p) => ({ ...p })),
      have = new Set(base.map((p) => p.name));
    for (let [n, pos, r, pot, age] of realismExtras[ci])
      if (!have.has(n)) base.push({ id: ci + '-real-' + n, name: n, pos, r, pot, age: age || 23, club: c.name });
    return Array.from(
      new Map(
        base.map((p) => [
          p.name,
          { ...p, value: valueFor(p), wage: wageFor(p), morale: 70, fitness: 100, ban: 0, lastRating: null, injuryWeeks: 0, yellowCards: 0, transferListed: false, loanWeeks: 0 },
        ]),
      ).values(),
    );
  });
}

function begin(i, name) {
  S = {
    club: i,
    budget: clubs[i].budget,
    week: 1,
    season: 1,
    version: 4,
    pricingVersion: 3,
    manager: String(name || '').trim().slice(0, 28) || 'Alex Morgan',
    formation: '4-3-3',
    tactics: { formation: '4-3-3', attack: 'Balanced', line: 'Balanced', focus: 'Cohesion' },
    autoRotate: true,
    stats: blankTable(),
    matches: [],
    results: {},
    players: buildPlayers(),
    boardApproval: 70,
    boardWarnings: 0,
    news: [],
    chats: [],
    lineupIds: [],
  };
  S.lineupIds = autoEleven(i).map((p) => p.id);
  ensureCareerSystems();
  ensureYouth();
  addNews('Welcome to ' + clubs[i].name + '. The board expects a ' + boardTarget() + ' this season.', 'board');
  tab = 'home';
  persist();
  draw();
  window.scrollTo(0, 0);
}
function boardTarget() {
  let b = my().budget;
  return b >= 85 ? 'top-four finish' : b >= 65 ? 'top-eight finish' : b >= 48 ? 'mid-table finish' : 'season of survival';
}
function boardExpectedRank() {
  let b = my().budget;
  return b >= 85 ? 5 : b >= 65 ? 8 : b >= 48 ? 12 : 16;
}

/* Keep older saves working: fill in anything the new features need. */
function migrateSave() {
  if (!S) return;
  ensureCareerSystems();
  S.version = 4;
  S.results ??= {};
  S.autoRotate ??= true;
  S.manager ??= 'Alex Morgan';
  S.formation ??= S.tactics?.formation || '4-3-3';
  S.tactics = { attack: 'Balanced', line: 'Balanced', focus: 'Cohesion', ...(S.tactics || {}), formation: S.formation };
  if (!FORMATIONS[S.formation]) S.formation = S.tactics.formation = '4-3-3';
  if (!Array.isArray(S.players) || S.players.length !== 20) S.players = buildPlayers();
  S.players.forEach((team, ci) =>
    team.forEach((p) => {
      p.club = clubs[ci].name;
      p.morale ??= 65;
      p.fitness ??= 100;
      p.injuryWeeks ??= 0;
      p.ban ??= 0;
      p.value ??= valueFor(p);
      p.wage ??= wageFor(p);
    }),
  );
  if (!Array.isArray(S.stats) || S.stats.length !== 20) S.stats = blankTable();
  S.matches ??= [];
  S.news ??= [];
  S.chats ??= [];
  S.lineupIds ??= [];
  S.budget ??= clubs[S.club].budget;
  ensureYouth();
  try {
    getEleven();
  } catch (e) {
    S.lineupIds = autoEleven().map((p) => p.id);
  }
}

/* ---------- matchweek flow ---------- */
function play(button, mode = 'quick') {
  if (window.__touchlineMatchLock || !S || S.sacked || S.seasonEnded || S.week > 38) return;
  S.matchPresentation = mode;
  window.__touchlineMatchLock = true;
  window.__touchlineMatchSnapshot = JSON.stringify(S);
  if (button) button.disabled = true;
  try {
    playMatchweek();
  } catch (e) {
    console.error(e);
    if (window.__touchlineMatchSnapshot) S = JSON.parse(window.__touchlineMatchSnapshot);
    window.__touchlineMatchSnapshot = null;
    window.__touchlineMatchLock = false;
    persist();
    draw();
    toast('Match could not be processed: ' + (e?.message || 'please try again'));
  }
}

function playMatchweek() {
  ensureCareerSystems();
  ensureYouth();
  let week = S.week,
    mine = null;
  applyTeamTalk();
  for (let [h, a] of weekPairs(week)) {
    let m = simulateMatch(h, a);
    applyMatch(m, week);
    if (h === S.club || a === S.club) mine = m;
  }
  processWeek();
  mine.events.sort((a, b) => a.min - b.min);
  let home = mine.home === S.club,
    k = home ? 0 : 1,
    ours = mine.goals[k],
    theirs = mine.goals[1 - k],
    opp = home ? mine.away : mine.home,
    result = ours > theirs ? 'W' : ours === theirs ? 'D' : 'L',
    byId = new Map(S.players[S.club].map((p) => [p.id, p])),
    mom = mine.mom && (byId.get(mine.mom) || S.players[opp].find((p) => p.id === mine.mom));
  let rec = {
    week,
    club: S.club,
    opponent: clubs[opp].name,
    oppidx: opp,
    home,
    ours,
    theirs,
    result,
    score: (home ? ours : theirs) + ' – ' + (home ? theirs : ours),
    events: mine.events,
    stats: { mine: mine.stats[k], opp: mine.stats[1 - k] },
    mom: mom ? { id: mom.id, name: mom.name, mine: byId.has(mom.id), rating: mine.ratings[mom.id] } : null,
    myApps: mine.apps[k]
      .filter((a) => a.to - a.from > 0)
      .map((a) => ({ id: a.p.id, n: a.p.name, pos: a.role, rt: mine.ratings[a.p.id] || null, g: a.g, a: a.a, from: a.from, to: a.to, y: a.y, red: a.red, hurt: a.hurt })),
  };
  S.matches.push(rec);
  S.last = { week, oppidx: opp, home, ours, theirs };
  S.week++;
  updateBoardAfterMatch(result);
  addNews(
    'Full time: ' + my().name + ' ' + ours + '–' + theirs + ' ' + clubs[opp].name + ' (' + result + ').',
    'match',
  );
  afterMatchweek(rec);
  window.__touchlineMatchSnapshot = null;
  simulateRumour();
  persist();
  draw();
  showMatch();
}

function afterMatchweek(rec) {
  addEuropeanRound();
  if (S.week % 3 === 1) {
    let candidates = roster().filter((p) => !S.chats.some((c) => c.id === p.id && c.incoming));
    if (candidates.length) {
      let p = pick(candidates);
      S.chats.unshift({
        id: p.id,
        name: p.name,
        week: S.week,
        kind: 'player',
        text: p.morale < 55 ? 'I’m unhappy with my place in the squad. Can we talk?' : 'I feel ready for the next match and would like to start.',
        incoming: true,
      });
    }
  }
  if (S.week % 5 === 0) {
    let targets = roster().filter((p) => p.transferListed && !p.loanWeeks);
    if (targets.length) {
      let p = pick(targets),
        buyer = pick(clubs.filter((x, i) => i !== S.club)),
        market = p.value || valueFor(p),
        fee = Math.round(market * (0.78 + Math.random() * 0.18) * 10) / 10;
      S.chats.unshift({
        id: 'club-offer-' + S.week + '-' + p.id,
        name: buyer.name + ' recruitment team',
        club: buyer.name,
        week: S.week,
        kind: 'club',
        playerId: p.id,
        offer: fee,
        valueLow: Math.round(market * 0.9 * 10) / 10,
        valueHigh: Math.round(market * 1.15 * 10) / 10,
        text: buyer.name + ' have approached ' + my().name + ' to discuss a transfer for ' + p.name + '. Their opening offer is ' + formatM(fee) + '.',
        incoming: true,
      });
    } else {
      let youth = roster().filter((p) => p.age < 24 && !p.loanWeeks);
      if (youth.length && Math.random() < 0.5) {
        let p = pick(youth),
          buyer = pick(clubs.filter((x, i) => i !== S.club));
        S.chats.unshift({
          id: 'loan-offer-' + S.week + '-' + p.id,
          name: buyer.name + ' recruitment team',
          club: buyer.name,
          week: S.week,
          kind: 'loan',
          playerId: p.id,
          loanWeeks: 6,
          offer: 0,
          valueLow: 0,
          valueHigh: 0,
          text: buyer.name + ' request a six-month loan for ' + p.name + '. You can accept, counter the loan length, or decline.',
          incoming: true,
        });
      }
    }
  }
  S.chats = S.chats.slice(0, 40);
  S.careerStats ??= { matches: 0, wins: 0, draws: 0, losses: 0 };
  S.careerStats.matches++;
  if (rec.result === 'W') S.careerStats.wins++;
  else if (rec.result === 'D') S.careerStats.draws++;
  else S.careerStats.losses++;
  if (S.sacked) {
    let st = S.stats[S.club];
    S.dismissalReport = {
      club: my().name,
      week: S.week,
      position: rankOf(S.club),
      approval: Math.round(S.boardApproval || 0),
      record: { ...st },
      reasons: [
        ...(S.budget < 0 ? ['Transfer budget went into deficit.'] : []),
        ...(weeklyWages() > my().budget * 34 ? ['Wage spending exceeded the board wage limit.'] : []),
        ...(st.l >= 4 ? ['A sustained run of defeats damaged confidence.'] : []),
        ...(st.p > 8 && st.pts < 18 ? ['League results fell well below expectations.'] : []),
      ],
    };
    if (!S.dismissalReport.reasons.length) S.dismissalReport.reasons.push('Board confidence fell below the required level after repeated warnings.');
  }
  generateLeagueNews();
  processLoanNegotiations();
  advanceYouthDay();
  if (S.week > 38) seasonEnd();
}

/* ---------- match report (quick or live) ---------- */
const EVENT_TAG = { goal: 'GOAL', yellow: 'YELLOW', red: 'RED', injury: 'INJURY', sub: 'SUB', chance: 'CHANCE', suspension: 'BAN' };
function eventRow(e, m) {
  let mineTeam = e.team === S.club,
    text = String(e.text).replace(/^[A-Z ]+ · /, '');
  return (
    '<div class="event ev-' + e.type + (mineTeam ? ' mine' : '') + '"><b>' + e.min + '′</b><span class="evtag">' +
    (EVENT_TAG[e.type] || e.type.toUpperCase()) + '</span><span class="evtext">' + safe(text) + '</span><span class="evclub">' +
    clubBadge(e.team) + '</span></div>'
  );
}
function matchHeader(m, live) {
  let hi = m.home ? S.club : m.oppidx,
    ai = m.home ? m.oppidx : S.club;
  return (
    '<div class="eyebrow">' + (live ? 'LIVE' : 'FULL TIME') + ' · PREMIER LEAGUE · WEEK ' + m.week +
    '</div><div class="scoreboard"><div class="steam">' + clubBadge(hi, 'lg') + '<span>' + safe(clubs[hi].name) +
    (m.home ? '' : '') + '</span>' + (clubs[hi].manager && hi !== S.club ? '<small class="mgr">' + safe(clubs[hi].manager) + '</small>' : '') + '</div><strong id="live-score">' + (live ? '0 – 0' : (m.home ? m.ours : m.theirs) + ' – ' + (m.home ? m.theirs : m.ours)) +
    '</strong><div class="steam">' + clubBadge(ai, 'lg') + '<span>' + safe(clubs[ai].name) + '</span></div></div>'
  );
}
function matchStatsHTML(m) {
  let a = m.stats.mine,
    b = m.stats.opp,
    cards = (side) => m.events.filter((e) => (e.type === 'yellow' || e.type === 'red') && (e.team === S.club) === side).length;
  return (
    '<div class="cmp-head"><b>' + safe(my().name) + '</b><b>' + safe(m.opponent) + '</b></div>' +
    bar('Possession %', a.poss, b.poss) +
    bar('Shots', a.shots, b.shots) +
    bar('On target', a.onTarget, b.onTarget) +
    bar('Expected goals', a.xg, b.xg, (x) => x.toFixed(2)) +
    bar('Cards', cards(true), cards(false))
  );
}
function matchRatingsHTML(m) {
  let rows = (m.myApps || []).slice().sort((x, y) => (y.rt || 0) - (x.rt || 0));
  return (
    (m.mom ? '<div class="banner">⭐ Man of the match: <b>' + safe(m.mom.name) + '</b> (' + (m.mom.rating || 0).toFixed(1) + ')</div>' : '') +
    rows
      .map(
        (x) =>
          '<div class="row"><span><b>' + safe(x.n) + '</b> <span class="badge">' + x.pos + '</span>' +
          (x.g ? ' ⚽×' + x.g : '') + (x.a ? ' 🅰×' + x.a : '') + (x.y ? ' 🟨' : '') + (x.red ? ' 🟥' : '') + (x.hurt ? ' 🩹' : '') +
          (x.from > 0 ? ' <small class="muted">on ' + x.from + '′</small>' : '') + (x.to < 90 && !x.red ? ' <small class="muted">off ' + x.to + '′</small>' : '') +
          '</span><span class="rating ' + (x.rt >= 7.5 ? 'hi' : x.rt && x.rt < 6 ? 'lo' : '') + '">' + (x.rt ? x.rt.toFixed(1) : '—') + '</span></div>',
      )
      .join('')
  );
}
function matchRoundHTML(m) {
  let res = S.results?.[m.week] || [];
  return res
    .map(
      (r) =>
        '<div class="row' + (r[0] === S.club || r[1] === S.club ? ' me' : '') + '"><span class="rt">' + safe(clubs[r[0]].name) +
        '</span><b class="rs">' + r[2] + ' – ' + r[3] + '</b><span class="rt right">' + safe(clubs[r[1]].name) + '</span></div>',
    )
    .join('');
}
function matchModalHTML(m, live) {
  let last = m.result === 'W' ? 'Three points secured.' : m.result === 'D' ? 'A point apiece.' : 'A tough result. Bounce back next week.';
  return (
    '<div class="overlay" id="modal"><div class="box match-box">' + matchHeader(m, live) +
    '<div class="live-clock" id="live-clock">' + (live ? '0′' : last) + '</div>' +
    '<div class="tabs" id="mtabs"' + (live ? ' hidden' : '') + '><button class="on" data-t="events">Timeline</button><button data-t="stats">Stats</button><button data-t="ratings">Ratings</button><button data-t="round">Round</button></div>' +
    '<div class="mpane events" id="mp-events">' +
    (live
      ? '<div class="sub" id="live-wait">The teams are out. Kick-off is moments away…</div>'
      : m.events.map((e) => eventRow(e, m)).join('') || '<div class="sub">A quiet match with no major incidents.</div>') +
    '</div><div class="mpane" id="mp-stats" hidden>' + (live ? '' : matchStatsHTML(m)) + '</div><div class="mpane" id="mp-ratings" hidden>' +
    (live ? '' : matchRatingsHTML(m)) + '</div><div class="mpane" id="mp-round" hidden>' + (live ? '' : matchRoundHTML(m)) +
    '</div><p class="sub" id="mfoot">' + (live ? '' : matchFootHTML()) + '</p><div class="actions">' +
    (live ? '<button class="btn light" id="skip-live" onclick="finishLiveMatch()">Skip to full time</button>' : '') +
    '<button class="btn" id="mcontinue" onclick="closeMatch()"' + (live ? ' hidden' : '') + '>Continue →</button></div></div></div>'
  );
}
function matchFootHTML() {
  return 'You are now <b>' + ordinal(rankOf(S.club)) + '</b> with ' + S.stats[S.club].pts + ' points. Morale, fitness and availability updated.';
}
function bindMatchTabs() {
  document.querySelectorAll('#mtabs button').forEach((b) => {
    b.onclick = () => {
      document.querySelectorAll('#mtabs button').forEach((x) => x.classList.toggle('on', x === b));
      document.querySelectorAll('#modal .mpane').forEach((p) => (p.hidden = p.id !== 'mp-' + b.dataset.t));
    };
  });
}
function showMatch() {
  if (S?.autoManager) {
    window.__touchlineMatchLock = false;
    return;
  }
  let m = S.matches[S.matches.length - 1];
  if (!m) return;
  document.querySelector('#modal')?.remove();
  if (S.matchPresentation !== 'watch') {
    document.body.insertAdjacentHTML('beforeend', matchModalHTML(m, false));
    bindMatchTabs();
    return;
  }
  document.body.insertAdjacentHTML('beforeend', matchModalHTML(m, true));
  let events = m.events.slice(),
    idx = 0,
    minute = 0,
    step = { slow: 520, normal: 300, fast: 140 }[settings().speed] || 300;
  window.__liveMatchTimer = setInterval(() => {
    if (!document.querySelector('#modal')) {
      clearInterval(window.__liveMatchTimer);
      window.__liveMatchTimer = null;
      return;
    }
    minute += 2;
    document.querySelector('#live-clock').textContent = Math.min(90, minute) + '′';
    let box = document.querySelector('#mp-events');
    while (idx < events.length && events[idx].min <= minute) {
      if (document.querySelector('#live-wait')) box.innerHTML = '';
      box.insertAdjacentHTML('afterbegin', eventRow(events[idx++], m));
    }
    let hi = m.home ? S.club : m.oppidx,
      shown = events.slice(0, idx).filter((e) => e.type === 'goal'),
      h = shown.filter((e) => e.team === hi).length,
      a = shown.length - h;
    document.querySelector('#live-score').textContent = h + ' – ' + a;
    if (minute >= 90) finishLiveMatch();
  }, step);
}
function finishLiveMatch() {
  if (window.__liveMatchTimer) clearInterval(window.__liveMatchTimer);
  window.__liveMatchTimer = null;
  let m = S?.matches?.[S.matches.length - 1];
  if (!m || !document.querySelector('#modal')) return;
  document.querySelector('#modal')?.remove();
  document.body.insertAdjacentHTML('beforeend', matchModalHTML(m, false));
  bindMatchTabs();
}
function closeMatch() {
  if (window.__liveMatchTimer) clearInterval(window.__liveMatchTimer);
  window.__liveMatchTimer = null;
  document.querySelector('#modal')?.remove();
  window.__touchlineMatchLock = false;
  S.matchPresentation = 'quick';
  go(S.seasonEnded ? 'home' : 'home');
}

/* ---------- Overview ---------- */
function home() {
  let st = S.stats[S.club],
    place = rankOf(S.club),
    approval = Math.round(S.boardApproval ?? 70),
    over = S.week > 38,
    fx = over ? null : fixtureFor(S.club, S.week),
    opp = fx ? clubs[fx.opp] : null,
    wageLimit = S.wageLimit || my().budget * 34,
    hurt = roster().filter((p) => p.injuryWeeks).length,
    banned = roster().filter((p) => p.ban).length,
    alerts = [];
  if (S.boardApproval < 45)
    alerts.push('<b>Board warning:</b> confidence is ' + approval + '%. ' + (S.boardApproval < 22 ? 'Your position is at immediate risk.' : 'Results and finances need to improve.'));
  if (weeklyWages() > wageLimit) alerts.push('<b>Finance warning:</b> weekly wages are above the board limit.');
  if (S.budget < 0) alerts.push('<b>Finance warning:</b> your transfer budget is overdrawn.');
  if (hurt || banned) alerts.push((hurt ? hurt + ' injured' : '') + (hurt && banned ? ' · ' : '') + (banned ? banned + ' suspended' : '') + ' in your squad.');
  if (unreadCount()) alerts.push('<b>' + unreadCount() + ' unread message' + (unreadCount() > 1 ? 's' : '') + '</b> <button class="link" onclick="go(\'messages\')">Open inbox →</button>');
  let tired = getEleven().filter((p) => (p.fitness ?? 100) < 65).length;
  if (tired && !S.autoRotate) alerts.push(tired + ' starter' + (tired > 1 ? 's are' : ' is') + ' tired. Rotate the XI or switch on Smart rotation.');
  let scout = fx ? scoutReport(fx.opp) : null,
    mid = Math.max(0, Math.min(13, place - 4)),
    snap = leagueOrder().slice(mid, mid + 7),
    mine = roster()
      .filter((p) => p.st?.app)
      .sort((a, b) => b.st.g * 3 + b.st.a * 2 + avgRating(b) - (a.st.g * 3 + a.st.a * 2 + avgRating(a)))
      .slice(0, 5),
    last = S.matches.slice(-5).reverse(),
    news = (S.news || []).slice(0, 5);
  return (
    head(my().name + ' · manager desk', 'Welcome back, ' + safe(S.manager.split(' ')[0] || 'boss') + '.', 'Season ' + (S.season || 1) + ' · 2026/27 Premier League', '<button class="btn light" onclick="saveNotice(this)">Save game</button>') +
    alerts.map((a) => '<div class="banner warning">' + a + '</div>').join('') +
    (over
      ? '<div class="hero"><div><div class="eyebrow">SEASON COMPLETE</div><h2>The campaign is over.</h2><p>All 38 matches are played. Review your season and start the next one.</p><button class="btn lime" onclick="go(\'home\')">Season review</button></div></div>'
      : '<div class="hero"><div class="hero-main"><div class="eyebrow">MATCHWEEK ' + S.week + ' · PREMIER LEAGUE</div><h2>' + (fx.home ? 'Home to ' : 'Away at ') + safe(opp.name) +
        '</h2><p>' + safe(scout.tips[0]) + '</p><div class="hero-btns"><button class="btn lime" onclick="play(this)">Play match</button><button class="btn ghost" onclick="play(this,\'watch\')">Watch live</button><button class="btn ghost" onclick="toggleAutoManager()">' +
        (S.autoManager ? 'Stop co-manager' : 'Co-manager: auto-play') + '</button></div></div><div class="next"><span class="kick">NEXT · ' + (fx.home ? 'HOME' : 'AWAY') +
        '</span><div class="versus"><div>' + clubBadge(S.club, 'lg') + '<span>' + safe(my().name) + '</span><small>' + ordinal(place) + '</small></div><b>VS</b><div>' + clubBadge(fx.opp, 'lg') +
        '<span>' + safe(opp.name) + '</span><small>' + ordinal(rankOf(fx.opp)) + (opp.manager ? ' · ' + safe(opp.manager) : '') + '</small></div></div><div class="formrow"><span>You</span>' + formDots(formOf(S.club)) + '</div><div class="formrow"><span>Them</span>' + formDots(formOf(fx.opp)) + '</div></div></div>') +
    '<div class="cards"><div class="stat"><small>LEAGUE POSITION</small><strong>' + ordinal(place) + '<span class="of"> / 20</span></strong><span>' + st.pts + ' pts · board expects top ' + boardExpectedRank() +
    '</span></div><div class="stat"><small>FIRST-TEAM RATING</small><strong>' + strength() + '<span class="of"> / 100</span></strong><span>Current XI, after fitness</span></div><div class="stat"><small>TRANSFER BUDGET</small><strong>' + formatM(S.budget) +
    '</strong><span>Wages ' + formatM(weeklyWages() / 1000) + ' / week</span></div><div class="stat"><small>BOARD APPROVAL</small><strong>' + approval + '%</strong><div class="approval-track"><i style="width:' + approval +
    '%"></i></div><span>' + (approval >= 70 ? 'Secure' : approval >= 45 ? 'Stable' : 'Under pressure') + '</span></div></div>' +
    '<div class="cols"><div class="stack"><div class="panel"><div class="panelhead"><h3>Recent results</h3>' + formDots(formOf(S.club)) + '</div>' +
    (last.map((m) => '<div class="row"><span>' + clubBadge(m.oppidx) + ' <b>' + safe(m.opponent) + '</b> <small class="muted">' + (m.home ? 'H' : 'A') + '</small></span><span>' + safe(m.score) + ' <i class="res r' + m.result + '">' + m.result + '</i></span></div>').join('') || '<div class="empty">Your first match is waiting.</div>') +
    '</div><div class="panel"><div class="panelhead"><h3>Club news</h3><button class="link" onclick="go(\'inbox\')">All news →</button></div>' +
    (news.length ? news.map((n) => '<div class="row"><span>' + safe(n.text) + '</span><small class="muted">W' + n.week + '</small></div>').join('') : '<div class="empty">No news yet. Match results, signings and player updates will appear here.</div>') +
    '</div></div><div class="stack"><div class="panel"><div class="panelhead"><h3>League snapshot</h3><button class="link" onclick="go(\'table\')">Full table →</button></div>' +
    snap.map((x) => '<div class="row ' + (x.i === S.club ? 'me' : '') + '"><span><b class="pos">' + (leagueOrder().findIndex((o) => o.i === x.i) + 1) + '</b> ' + clubBadge(x.i) + ' ' + safe(clubs[x.i].name) + '</span><b>' + x.pts + '</b></div>').join('') +
    '</div><div class="panel"><div class="panelhead"><h3>Top performers</h3><button class="link" onclick="go(\'stats\')">League stats →</button></div>' +
    (mine.map((p) => '<div class="row"><span><b>' + safe(p.name) + '</b> <span class="badge">' + p.pos + '</span></span><span class="muted">' + p.st.g + 'G ' + p.st.a + 'A · <b class="rating">' + avgRating(p).toFixed(1) + '</b></span></div>').join('') || '<div class="empty">Stats appear after your first match.</div>') +
    '</div></div></div>'
  );
}

/* ---------- Team: formation, XI, tactics, scouting ---------- */
let lineupSel = null;
function setTactic(k, v) {
  S.tactics = { formation: S.formation || '4-3-3', attack: 'Balanced', line: 'Balanced', focus: 'Cohesion', ...(S.tactics || {}) };
  S.tactics[k] = v;
  if (k === 'formation') {
    S.formation = v;
    S.lineupIds = autoEleven().map((p) => p.id);
    lineupSel = null;
  }
  persist();
  draw();
}
function toggleRotate() {
  S.autoRotate = !S.autoRotate;
  persist();
  draw();
  toast(S.autoRotate ? 'Smart rotation on: tired starters are swapped for fresh players.' : 'Smart rotation off: your XI plays as chosen.');
}
function autoPick() {
  S.lineupIds = autoEleven().map((p) => p.id);
  lineupSel = null;
  persist();
  draw();
}
function pickSlot(i) {
  getEleven();
  if (!lineupSel) lineupSel = { t: 'xi', i };
  else if (lineupSel.t === 'xi') {
    if (lineupSel.i !== i) [S.lineupIds[lineupSel.i], S.lineupIds[i]] = [S.lineupIds[i], S.lineupIds[lineupSel.i]];
    lineupSel = null;
    persist();
  } else {
    let p = roster().find((x) => x.id === lineupSel.id);
    if (p && isAvailable(p)) S.lineupIds[i] = p.id;
    lineupSel = null;
    persist();
  }
  draw();
}
/* ---------- drag & drop for the lineup (mouse, pen and touch; touch needs a short press-and-hold) ---------- */
(function () {
  let drag = null;
  const target = (x, y) => document.elementsFromPoint(x, y).map((e) => e.closest?.('[data-drag]')).find((e) => e && e !== drag?.el);
  const clear = () => document.querySelectorAll('.droptarget').forEach((e) => e.classList.remove('droptarget'));
  function begin(ev) {
    let el = ev.target.closest?.('[data-drag]');
    if (!el || (ev.pointerType === 'mouse' && ev.button !== 0)) return;
    drag = { el, id: el.dataset.drag, x: ev.clientX, y: ev.clientY, on: false, touch: ev.pointerType === 'touch', timer: null, ghost: null };
    if (drag.touch) drag.timer = setTimeout(() => start(), 280);
  }
  function start() {
    if (!drag || drag.on) return;
    drag.on = true;
    drag.el.classList.add('dragging');
    let g = drag.el.cloneNode(true);
    g.removeAttribute('onclick');
    g.removeAttribute('data-drag');
    g.className += ' dragghost';
    g.style.width = drag.el.offsetWidth + 'px';
    document.body.appendChild(g);
    drag.ghost = g;
    if (navigator.vibrate) navigator.vibrate(12);
    move(drag.last || { clientX: drag.x, clientY: drag.y });
  }
  function move(ev) {
    if (!drag) return;
    drag.last = ev;
    if (!drag.on) {
      if (Math.hypot(ev.clientX - drag.x, ev.clientY - drag.y) > 6) {
        if (drag.touch) {
          clearTimeout(drag.timer);
          drag = null; /* the user is scrolling */
          return;
        }
        start();
      } else return;
    }
    drag.ghost.style.left = ev.clientX - drag.ghost.offsetWidth / 2 + 'px';
    drag.ghost.style.top = ev.clientY - 24 + 'px';
    clear();
    target(ev.clientX, ev.clientY)?.classList.add('droptarget');
  }
  function end(ev, cancel) {
    if (!drag) return;
    clearTimeout(drag.timer);
    let d = drag;
    drag = null;
    if (!d.on) return;
    d.ghost.remove();
    d.el.classList.remove('dragging');
    clear();
    window.__dragJustEnded = Date.now(); /* swallow the click that follows a drag */
    if (cancel) return;
    let t = target(ev.clientX, ev.clientY);
    if (t) dropLineup(d.id, t.dataset.drag);
  }
  document.addEventListener('pointerdown', begin);
  document.addEventListener('pointermove', move);
  document.addEventListener('pointerup', (e) => end(e, false));
  document.addEventListener('pointercancel', (e) => end(e, true));
  document.addEventListener('touchmove', (e) => { if (drag?.on) e.preventDefault(); }, { passive: false });
  document.addEventListener('click', (e) => { if (Date.now() - (window.__dragJustEnded || 0) < 400) { e.stopPropagation(); e.preventDefault(); } }, true);
  document.addEventListener('contextmenu', (e) => { if (drag?.on && drag.touch) e.preventDefault(); });
})();
function dropLineup(from, to) {
  if (from === to) return;
  getEleven();
  let [ft, fv] = from.split(':'),
    [tt, tv] = to.split(':');
  lineupSel = null;
  if (ft === 'xi' && tt === 'xi') {
    [S.lineupIds[+fv], S.lineupIds[+tv]] = [S.lineupIds[+tv], S.lineupIds[+fv]];
  } else if (ft === 'b' && tt === 'xi') {
    let p = roster().find((x) => x.id === idFromAction(fv));
    if (!p || !isAvailable(p)) return toast('That player is not available.');
    S.lineupIds[+tv] = p.id;
  } else if (ft === 'xi' && tt === 'b') {
    let p = roster().find((x) => x.id === idFromAction(tv));
    if (!p || !isAvailable(p)) return toast('That player is not available.');
    S.lineupIds[+fv] = p.id;
  } else return;
  persist();
  draw();
}
function pickBench(encoded) {
  let id = idFromAction(encoded),
    p = roster().find((x) => x.id === id);
  if (!p) return;
  if (!isAvailable(p)) {
    toast(p.name + ' is not available.');
    return;
  }
  getEleven();
  if (lineupSel?.t === 'xi') {
    S.lineupIds[lineupSel.i] = id;
    lineupSel = null;
    persist();
  } else lineupSel = lineupSel?.id === id ? null : { t: 'bench', id };
  draw();
}
const TEAM_TALKS = {
  none: 'No team talk',
  motivate: 'Motivate · +morale for the XI',
  relax: 'Stay calm · lifts low morale',
  demand: 'Demand more · risky, big boost if they are fresh',
};
function applyTeamTalk() {
  let t = S.teamTalk;
  S.teamTalk = 'none';
  if (!t || t === 'none') return;
  for (let p of getEleven()) {
    let m = p.morale ?? 65;
    if (t === 'motivate') m += 3;
    else if (t === 'relax') m += m < 60 ? 5 : 1;
    else if (t === 'demand') m += (p.fitness ?? 100) >= 85 ? 6 : -4;
    p.morale = Math.max(25, Math.min(95, m));
  }
}
function setTeamTalk(v) {
  S.teamTalk = v;
  persist();
}
function lineupEditor() {
  let xi = getEleven(),
    roles = slotRoles(S.formation),
    ids = new Set(xi.map((p) => p.id)),
    rows = { GK: [], DEF: [], MID: [], ATT: [] };
  xi.forEach((p, i) => rows[roles[i]].push({ p, i }));
  let slot = ({ p, i }) =>
      '<button class="slot ' + (lineupSel?.t === 'xi' && lineupSel.i === i ? 'sel ' : '') + (fitPenalty(p, roles[i]) >= 8 ? 'oop' : '') + '" onclick="pickSlot(' + i + ')" data-drag="xi:' + i + '"><b>' + Math.round(effRating(p, roles[i])) + '</b><span>' +
      safe(p.name.split(' ').slice(-1)[0]) + '</span><small>' + roles[i] + (fitPenalty(p, roles[i]) >= 8 ? ' ⚠' : '') + '</small>' + fitBar(p.fitness) + '</button>',
    pitch = ['ATT', 'MID', 'DEF', 'GK'].map((r) => '<div class="line">' + rows[r].map(slot).join('') + '</div>').join(''),
    bench = roster()
      .filter((p) => !ids.has(p.id))
      .sort((a, b) => (isAvailable(b) ? 1 : 0) - (isAvailable(a) ? 1 : 0) || b.r - a.r);
  return (
    '<div class="pitch">' + pitch + '</div><div class="panelhead" style="margin-top:14px"><h3>Substitutes · ' + bench.length +
    '</h3><button class="tiny" onclick="autoPick()">Auto-pick best XI</button></div><div class="bench">' +
    bench
      .map(
        (p) =>
          '<button class="chip ' + (lineupSel?.t === 'bench' && lineupSel.id === p.id ? 'sel ' : '') + (isAvailable(p) ? '' : 'unavailable') + '" onclick="pickBench(\'' + enc(p.id) + '\')" data-drag="b:' + enc(p.id) + '"><span>' + safe(p.name) +
          '</span><small>' + p.pos + ' · ' + p.r + '</small>' + (isAvailable(p) ? fitBar(p.fitness) : '<em>' + (p.injuryWeeks ? '🩹 ' + p.injuryWeeks + 'w' : p.ban ? '⛔ ' + p.ban : '↗ loan') + '</em>') + '</button>',
      )
      .join('') +
    '</div><p class="muted">Drag a player onto another to swap them (or tap one, then tap another). ⚠ means playing out of position (−8 rating).</p>'
  );
}
const STYLE_HELP = {
  Balanced: 'No big risks either way.',
  Positive: 'Slightly more adventurous.',
  Attacking: 'More goals for, more goals against.',
  'Counter-attacking': 'Compact, then break fast. Best as the underdog.',
  'Route One': 'Direct and physical. Little possession.',
  Possession: 'Control the ball, concede less.',
};
function tactics() {
  let t = S.tactics || {},
    fx = S.week <= 38 ? fixtureFor(S.club, S.week) : null,
    sc = fx ? scoutReport(fx.opp) : null;
  return (
    head('Match preparation', 'Team & tactics', 'Pick your shape, choose your XI and read the scouting report.') +
    '<div class="cols"><div class="panel"><div class="panelhead"><h3>' + safe(my().name) + ' · Starting XI</h3><select onchange="setTactic(\'formation\',this.value)">' +
    Object.keys(FORMATIONS).map((x) => '<option ' + (S.formation === x ? 'selected' : '') + '>' + x + '</option>').join('') + '</select></div>' + lineupEditor() +
    '</div><div class="stack"><div class="panel"><h3>Game plan</h3>' +
    [
      ['attack', 'Attacking style', ATTACK_STYLES],
      ['line', 'Defensive line', DEF_LINES],
      ['focus', 'Team focus', TEAM_FOCUS],
    ]
      .map(([k, label, opts]) => '<div class="row"><b>' + label + '</b><select onchange="setTactic(\'' + k + '\',this.value)">' + opts.map((x) => '<option ' + (t[k] === x ? 'selected' : '') + '>' + x + '</option>').join('') + '</select></div>')
      .join('') +
    '<p class="sub">' + (STYLE_HELP[t.attack] || '') + ' A high line and a high press win the ball earlier but tire your players and leave space behind.</p>' +
    '<label class="switch"><input type="checkbox" ' + (S.autoRotate ? 'checked' : '') + ' onchange="toggleRotate()"><span>Smart rotation</span><small>Swap in a fresh player when a starter drops below 62% fitness.</small></label></div>' +
    (sc
      ? '<div class="panel"><div class="panelhead"><h3>Scouting · ' + safe(clubs[fx.opp].name) + '</h3><span class="muted">' + (fx.home ? 'Home' : 'Away') + '</span></div><div class="cmp-head"><b>You</b><b>' + safe(clubs[fx.opp].name) + '</b></div>' +
        bar('Attack', sc.me.A, sc.them.A) + bar('Midfield', sc.me.mid, sc.them.mid) + bar('Defence', sc.me.def, sc.them.def) + bar('Goalkeeper', sc.me.gk, sc.them.gk) + bar('Fitness %', sc.me.fitness, sc.them.fitness) +
        '<ul class="tips">' + sc.tips.map((x) => '<li>' + safe(x) + '</li>').join('') + '</ul><div class="row"><b>Team talk</b><select onchange="setTeamTalk(this.value)">' + Object.entries(TEAM_TALKS).map(([k, l]) => '<option value="' + k + '" ' + ((S.teamTalk || 'none') === k ? 'selected' : '') + '>' + l + '</option>').join('') + '</select></div><button class="btn" onclick="play(this)">Play match →</button></div>'
      : '') +
    '</div></div>'
  );
}

/* ---------- Squad ---------- */
let squadFilter = 'All';
function squadView() {
  let players = roster()
    .filter((p) => squadFilter === 'All' || p.pos === squadFilter)
    .sort((a, b) => ['GK', 'DEF', 'MID', 'ATT'].indexOf(a.pos) - ['GK', 'DEF', 'MID', 'ATT'].indexOf(b.pos) * (squadFilter === 'All' ? 0 : 1) || b.r - a.r);
  if (squadFilter === 'All') players.sort((a, b) => b.r - a.r);
  let xi = new Set(getEleven().map((p) => p.id));
  return (
    head('First team', 'Your squad', roster().length + ' players · availability, form and contracts.') +
    '<div class="filters chips">' + ['All', 'GK', 'DEF', 'MID', 'ATT'].map((x) => '<button class="pill ' + (squadFilter === x ? 'on' : '') + '" onclick="squadFilter=\'' + x + '\';draw()">' + x + '</button>').join('') + '</div>' +
    '<div class="panel tablewrap"><table class="tbl"><thead><tr><th>Player</th><th>Age</th><th>OVR</th><th class="hide-sm">POT</th><th>Fit</th><th class="hide-sm">Mood</th><th>Apps</th><th>G</th><th>A</th><th class="hide-sm">Avg</th><th>Status</th><th></th></tr></thead><tbody>' +
    players
      .map((p) => {
        let st = p.st || {};
        return (
          '<tr><td><b>' + safe(p.name) + '</b>' + (xi.has(p.id) ? ' <span class="badge xi">XI</span>' : '') + '<br><small class="muted">' + safe(playerPositions(p).join(' / ')) + '</small></td><td>' + (p.age || '—') + '</td><td class="rating">' + p.r +
          '</td><td class="pot hide-sm">' + p.pot + '</td><td>' + fitBar(p.fitness) + '</td><td class="hide-sm">' + moraleTag(p.morale || 65) + '</td><td>' + (st.app || 0) + '</td><td>' + (st.g || 0) + '</td><td>' + (st.a || 0) +
          '</td><td class="hide-sm">' + (st.rn ? (st.rt / st.rn).toFixed(1) : '—') + '</td><td>' + statusOf(p) + '</td><td class="acts"><button class="tiny" onclick="toggleListed(\'' + enc(p.id) + '\')">' + (p.transferListed ? 'Unlist' : 'List') +
          '</button><button class="tiny" onclick="sendOnLoan(\'' + enc(p.id) + '\')">Loan</button><button class="tiny" onclick="releasePlayer(\'' + enc(p.id) + '\')">Release</button></td></tr>'
        );
      })
      .join('') +
    '</tbody></table></div>'
  );
}

/* ---------- League table ---------- */
function tableView() {
  let order = leagueOrder(),
    played = Math.max(0, S.week - 1);
  return (
    head('2026 / 27 · Premier League', 'League table', 'After matchweek ' + Math.min(38, played) + ' · top four qualify for Europe, bottom three are in the drop zone.') +
    '<div class="panel tablewrap"><table class="tbl league"><thead><tr><th>#</th><th>Club</th><th>P</th><th>W</th><th>D</th><th>L</th><th class="hide-sm">GF</th><th class="hide-sm">GA</th><th>GD</th><th>Pts</th><th class="hide-sm">Form</th></tr></thead><tbody>' +
    order
      .map((x, n) => {
        let gd = x.gf - x.ga;
        return (
          '<tr class="' + (x.i === S.club ? 'me ' : '') + (n < 4 ? 'zone-eu' : n >= 17 ? 'zone-rel' : '') + '"><td>' + (n + 1) + '</td><td>' + clubBadge(x.i) + ' ' + safe(clubs[x.i].name) + (x.i === S.club ? ' <span class="badge xi">YOU</span>' : '') +
          '</td><td>' + x.p + '</td><td>' + x.w + '</td><td>' + x.d + '</td><td>' + x.l + '</td><td class="hide-sm">' + x.gf + '</td><td class="hide-sm">' + x.ga + '</td><td>' + (gd > 0 ? '+' : '') + gd + '</td><td class="rating">' + x.pts +
          '</td><td class="hide-sm">' + formDots(formOf(x.i)) + '</td></tr>'
        );
      })
      .join('') +
    '</tbody></table></div>'
  );
}

/* ---------- Fixtures & results ---------- */
let fixtureWeek = 0;
function fixturesPage() {
  let rows = [];
  for (let w = 1; w <= 38; w++) {
    let fx = fixtureFor(S.club, w),
      m = S.matches.find((x) => x.week === w);
    rows.push(
      '<div class="row ' + (w === S.week ? 'me' : '') + '"><span><b class="pos">' + w + '</b> <span class="badge">' + (fx.home ? 'H' : 'A') + '</span> ' + clubBadge(fx.opp) + ' ' + safe(clubs[fx.opp].name) +
        '</span><span>' + (m ? safe(m.score) + ' <i class="res r' + m.result + '">' + m.result + '</i>' : w === S.week ? '<span class="tag ok">Next</span>' : '<span class="muted">—</span>') + '</span></div>',
    );
  }
  let rw = fixtureWeek || Math.max(1, S.week - 1),
    res = S.results?.[rw] || [];
  return (
    head('Season ' + (S.season || 1), 'Fixtures & results', 'Your 38-match schedule and every result from around the league.') +
    '<div class="cols"><div class="panel"><div class="panelhead"><h3>' + safe(my().name) + ' schedule</h3></div>' + rows.join('') + '</div><div class="panel"><div class="panelhead"><h3>Round results</h3><select onchange="fixtureWeek=+this.value;draw()">' +
    Array.from({ length: Math.max(1, S.week - 1) }, (_, i) => i + 1).map((w) => '<option value="' + w + '" ' + (w === rw ? 'selected' : '') + '>Matchweek ' + w + '</option>').join('') + '</select></div>' +
    (res.map((r) => '<div class="row ' + (r[0] === S.club || r[1] === S.club ? 'me' : '') + '"><span class="rt">' + safe(clubs[r[0]].name) + '</span><b class="rs">' + r[2] + ' – ' + r[3] + '</b><span class="rt right">' + safe(clubs[r[1]].name) + '</span></div>').join('') || '<div class="empty">Results appear after the first matchweek.</div>') +
    '</div></div>'
  );
}

/* ---------- League stats ---------- */
let statsTab = 'goals';
function leaderTable(list, valFn, label, n = 10) {
  return (
    '<table class="tbl"><thead><tr><th>#</th><th>Player</th><th>Club</th><th>' + label + '</th></tr></thead><tbody>' +
    list
      .slice(0, n)
      .map((p, i) => '<tr class="' + (p.club === my().name ? 'me' : '') + '"><td>' + (i + 1) + '</td><td><b>' + safe(p.name) + '</b></td><td>' + safe(p.club) + '</td><td class="rating">' + valFn(p) + '</td></tr>')
      .join('') +
    '</tbody></table>' || ''
  );
}
function honoursPanel() {
  let h = S.champions || [];
  return '<div class="panel"><div class="panelhead"><h3>League history</h3></div>' + (h.length
    ? h.slice().reverse().map((x) => '<div class="row"><span><b class="pos">S' + x.season + '</b> ' + safe(x.champion) + ' · ' + x.pts + ' pts' + (x.boot ? '<br><small class="muted">Golden Boot: ' + safe(x.boot) + (x.best ? ' · Player of the season: ' + safe(x.best) : '') + '</small>' : '') + '</span><b>You: ' + ordinal(x.mine) + '</b></div>').join('')
    : '<div class="empty">Champions and award winners appear here after each season.</div>') + '</div>';
}
function dealsPanel() {
  let d = (S.aiDeals || []).slice(0, 10);
  return '<div class="panel"><div class="panelhead"><h3>Latest league transfers</h3></div>' + (d.length
    ? d.map((x) => '<div class="row"><span>' + safe(x.name) + ' <small class="muted">' + x.r + ' · ' + safe(x.from) + ' → ' + safe(x.to) + '</small></span><b>' + formatM(x.fee) + '</b></div>').join('')
    : '<div class="empty">Transfer windows open in the summer and in January.</div>') + '</div>';
}
function statsPage() {
  let all = S.players.flat().filter((p) => p.st && p.st.app),
    goals = all.filter((p) => p.st.g).sort((a, b) => b.st.g - a.st.g || b.st.a - a.st.a),
    assists = all.filter((p) => p.st.a).sort((a, b) => b.st.a - a.st.a || b.st.g - a.st.g),
    rating = all.filter((p) => p.st.rn >= Math.min(5, Math.max(1, S.week - 3))).sort((a, b) => avgRating(b) - avgRating(a)),
    sheets = all.filter((p) => p.pos === 'GK' && p.st.app >= 3).sort((a, b) => b.st.cs - a.st.cs),
    cards = all.filter((p) => p.st.y || p.st.r).sort((a, b) => b.st.y + b.st.r * 2 - (a.st.y + a.st.r * 2)),
    block = (title, list, fn, label) => '<div class="panel tablewrap"><div class="panelhead"><h3>' + title + '</h3></div>' + (list.length ? leaderTable(list, fn, label) : '<div class="empty">No data yet.</div>') + '</div>';
  return (
    head('Season ' + (S.season || 1), 'League stats', 'Top performers across the Premier League this season.') +
    '<div class="cols">' + block('Golden Boot', goals, (p) => p.st.g, 'Goals') + block('Top assists', assists, (p) => p.st.a, 'Assists') + block('Highest average rating', rating, (p) => avgRating(p).toFixed(2), 'Avg') +
    block('Golden Glove (clean sheets)', sheets, (p) => p.st.cs, 'CS') + block('Discipline', cards, (p) => p.st.y + '🟨 ' + p.st.r + '🟥', 'Cards') + honoursPanel() + dealsPanel() + '</div>'
  );
}

/* ---------- Settings & save management ---------- */
function settings() {
  try {
    return { theme: 'auto', speed: 'normal', ...(JSON.parse(localStorage.getItem('touchline-settings') || '{}') || {}) };
  } catch (e) {
    return { theme: 'auto', speed: 'normal' };
  }
}
function setSetting(k, v) {
  let s = settings();
  s[k] = v;
  try {
    localStorage.setItem('touchline-settings', JSON.stringify(s));
  } catch (e) {}
  applyTheme();
  if (S) draw();
}
function applyTheme() {
  let t = settings().theme;
  if (t === 'light' || t === 'dark') document.documentElement.dataset.theme = t;
  else delete document.documentElement.dataset.theme;
}
function exportSave() {
  if (!S) return toast('Nothing to export yet.');
  let fileName = 'touchline-' + clubs[S.club].name.replace(/\W+/g, '-').toLowerCase() + '-s' + (S.season || 1) + '-week' + S.week + '.json';
  if (window.TouchlineAndroid) {
    /* Inside the Android app: use the system "save file" dialog. */
    window.TouchlineAndroid.saveFile(fileName, JSON.stringify(S));
    return;
  }
  let blob = new Blob([JSON.stringify(S)], { type: 'application/json' }),
    a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = fileName;
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 2000);
  toast('Save file downloaded.');
}
function importSave(input) {
  let f = input.files && input.files[0];
  if (!f) return;
  let r = new FileReader();
  r.onload = () => {
    try {
      let data = JSON.parse(r.result);
      if (!data || typeof data.club !== 'number' || !Array.isArray(data.players)) throw new Error('not a Touchline save');
      S = data;
      migrateSave();
      persist();
      tab = 'home';
      draw();
      toast('Career loaded.');
    } catch (e) {
      toast('That file is not a valid Touchline save.');
    }
  };
  r.readAsText(f);
}
function saveNotice(button) {
  if (!S) return toast('Choose a club to start a career first.');
  try {
    persist();
    toast('Career saved on this device.');
  } catch (e) {
    toast('Save failed: ' + (e?.name === 'QuotaExceededError' ? 'device storage is full.' : 'storage is unavailable.'));
  }
}
function startNewCareer() {
  if (S && !confirm('Start a new career? This will replace your current saved career.')) return;
  document.querySelectorAll('#modal,#negmodal,#chatmodal').forEach((e) => e.remove());
  stopAutoManager();
  try {
    localStorage.removeItem('touchline');
  } catch (e) {}
  S = null;
  window.__touchlineMatchLock = false;
  window.__touchlineMatchSnapshot = null;
  tab = 'home';
  draw();
}
function setDifficulty(v) {
  S.difficulty = v;
  persist();
  draw();
  toast('Difficulty: ' + v + '.');
}
function settingsPage() {
  let s = settings(),
    seg = (k, opts) => '<div class="seg">' + opts.map(([v, l]) => '<button class="' + (s[k] === v ? 'on' : '') + '" onclick="setSetting(\'' + k + '\',\'' + v + '\')">' + l + '</button>').join('') + '</div>';
  return (
    head('Touchline', 'Settings', 'Appearance, match speed and your save file.') +
    '<div class="cols"><div class="panel"><h3>Appearance</h3><div class="row"><b>Theme</b>' + seg('theme', [['auto', 'Auto'], ['light', 'Light'], ['dark', 'Dark']]) + '</div><div class="row"><b>Live match speed</b>' +
    seg('speed', [['slow', 'Slow'], ['normal', 'Normal'], ['fast', 'Fast']]) + '</div>' + (S ? '<div class="row"><b>Difficulty</b><div class="seg">' + [['easy', 'Easy'], ['normal', 'Normal'], ['hard', 'Hard']].map(([v, l]) => '<button class="' + ((S.difficulty || 'normal') === v ? 'on' : '') + '" onclick="setDifficulty(\''+v+'\')">' + l + '</button>').join('') + '</div></div>' : '') + '</div><div class="panel"><h3>Your save</h3><p class="sub">Your career saves automatically on this device after every action. Export a backup file to move it to another device or browser.</p><div class="hero-btns"><button class="btn" onclick="exportSave()">Export save</button><label class="btn light filebtn">Import save<input type="file" accept="application/json,.json" onchange="importSave(this)" hidden></label><button class="btn light" onclick="startNewCareer()">New career</button></div></div></div>' +
    '<p class="muted">Touchline is a fan-made football management game. Ratings, potentials, values and wages are simplified game estimates, not official data.</p>'
  );
}

/* A player asked to start: put him in the XI in place of the weakest starter in his position. */
function selectForNextMatch(id) {
  let p = roster().find((x) => x.id === id);
  if (!p) return;
  if (!isAvailable(p)) {
    toast(p.name + ' is not available to play.');
    return;
  }
  let xi = getEleven(),
    roles = slotRoles(S.formation),
    cands = xi.map((x, i) => ({ x, i })).filter((o) => roles[o.i] === p.pos && o.x.id !== p.id);
  if (!cands.length) cands = xi.map((x, i) => ({ x, i })).filter((o) => o.x.pos === p.pos && o.x.id !== p.id);
  if (!cands.length) {
    toast(p.name + ' has no natural slot in this formation.');
    return;
  }
  cands.sort((a, b) => a.x.r - b.x.r);
  S.lineupIds[cands[0].i] = p.id;
  persist();
  toast(p.name + ' added to the starting XI.');
}
