/* =====================================================================
   TOUCHLINE · MATCH ENGINE
   One model for every match in the league (yours and the AI's).
   Lineups, fitness, morale, formation, tactics, subs, cards and injuries
   all feed into the result, so squad quality and your decisions matter.
   Needs the globals from realism.js: S (save), clubs, and data.js.
   ===================================================================== */

const FORMATIONS = {
  '4-3-3': { GK: 1, DEF: 4, MID: 3, ATT: 3 },
  '4-4-2': { GK: 1, DEF: 4, MID: 4, ATT: 2 },
  '3-5-2': { GK: 1, DEF: 3, MID: 5, ATT: 2 },
  '4-2-3-1': { GK: 1, DEF: 4, MID: 5, ATT: 1 },
  '4-1-4-1': { GK: 1, DEF: 4, MID: 5, ATT: 1 },
  '4-3-2-1': { GK: 1, DEF: 4, MID: 3, ATT: 3 },
  '5-3-2': { GK: 1, DEF: 5, MID: 3, ATT: 2 },
  '3-4-3': { GK: 1, DEF: 3, MID: 4, ATT: 3 },
};
const ATTACK_STYLES = ['Balanced', 'Positive', 'Attacking', 'Counter-attacking', 'Route One', 'Possession'];
const DEF_LINES = ['Low', 'Balanced', 'High', 'High press'];
const TEAM_FOCUS = ['Cohesion', 'Fitness', 'Attacking', 'Defending', 'Morale', 'Youth development'];

/* Each tweak: [goals you score x, goals you concede x, possession points]. */
const STYLE_FX = {
  Balanced: [1, 1, 0],
  Positive: [1.05, 1.03, 1],
  Attacking: [1.13, 1.11, 2],
  'Counter-attacking': [1.0, 0.96, -3],
  'Route One': [1.03, 1.02, -6],
  Possession: [0.99, 0.94, 5],
};
const LINE_FX = {
  Low: [0.95, 0.93, -2],
  Balanced: [1, 1, 0],
  High: [1.03, 1.05, 2],
  'High press': [1.06, 1.08, 3],
};
const FOCUS_FX = {
  Cohesion: [1, 1],
  Fitness: [0.99, 1],
  Attacking: [1.04, 1.03],
  Defending: [0.96, 0.94],
  Morale: [1, 1],
  'Youth development': [0.99, 1.01],
};

/* Tuning knobs (calibrated by simulating whole seasons). */
const ENGINE = { base: 1.24, homeBoost: 1.11, awayDrag: 0.93, k: 0.085, minL: 0.18, maxL: 3.6 };

const rnd = (a, b) => a + Math.random() * (b - a);
const rint = (a, b) => Math.floor(rnd(a, b + 1));
const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];
function gauss() {
  return Math.sqrt(-2 * Math.log(1 - Math.random())) * Math.cos(2 * Math.PI * Math.random());
}
function poisson(lambda) {
  let mean = Math.max(0.05, Math.min(5, Number(lambda) || 0.05)),
    L = Math.exp(-mean),
    k = 0,
    p = 1;
  do {
    k++;
    p *= Math.random();
  } while (p > L && k < 14);
  return k - 1;
}
function weighted(items, weightFn) {
  let total = 0,
    w = items.map((x) => {
      let v = Math.max(0, weightFn(x));
      total += v;
      return v;
    });
  if (!total) return items[0];
  let t = Math.random() * total;
  for (let i = 0; i < items.length; i++) {
    t -= w[i];
    if (t <= 0) return items[i];
  }
  return items[items.length - 1];
}

function formationNeeds(f) {
  return FORMATIONS[f] || FORMATIONS['4-3-3'];
}
function slotRoles(f) {
  let n = formationNeeds(f),
    roles = [];
  for (let pos of ['GK', 'DEF', 'MID', 'ATT']) for (let i = 0; i < n[pos]; i++) roles.push(pos);
  return roles;
}

/* AI clubs get their own shape and style (deterministic per club). */
const AI_FORMS = ['4-3-3', '4-2-3-1', '4-4-2', '3-5-2', '4-1-4-1', '5-3-2', '4-3-3', '4-2-3-1'];
function clubFormation(ci) {
  return ci === S.club ? S.formation || '4-3-3' : AI_FORMS[(ci * 5 + 3) % AI_FORMS.length];
}
function tacticsFor(ci) {
  if (ci === S.club) return S.tactics || { attack: 'Balanced', line: 'Balanced', focus: 'Cohesion' };
  return {
    attack: ['Balanced', 'Positive', 'Counter-attacking', 'Possession', 'Balanced', 'Attacking'][ci % 6],
    line: ['Balanced', 'High', 'Low', 'Balanced', 'High press'][(ci * 3) % 5],
    focus: 'Cohesion',
  };
}

function isAvailable(p) {
  return !(p.ban || 0) && !(p.injuryWeeks || 0) && !(p.loanWeeks || 0);
}

/* Detailed roles (from playerPositions) -> the four lines used by the engine. */
const POS_GROUP = { GK: 'GK', CB: 'DEF', LB: 'DEF', RB: 'DEF', LWB: 'DEF', RWB: 'DEF', SW: 'DEF', DM: 'MID', CM: 'MID', AM: 'MID', LM: 'MID', RM: 'MID', RW: 'ATT', LW: 'ATT', ST: 'ATT', CF: 'ATT', SS: 'ATT' };
/* Penalty for playing a player in a slot: 0 natural, 2 if it is a listed secondary role, 8 otherwise. */
function fitPenalty(p, role) {
  if (!role || p.pos === role) return 0;
  let alt = typeof playerPositions === 'function' && playerPositions(p).some((x) => POS_GROUP[x] === role);
  return alt ? 2 : 8;
}

/* How well a player performs right now: rating, fitness, morale, position fit. */
function effRating(p, role) {
  let fit = p.fitness ?? 100,
    mor = p.morale ?? 65;
  return (p.r || 60) - fitPenalty(p, role) - (100 - fit) * 0.1 + Math.max(-1.2, Math.min(1.2, (mor - 65) * 0.03));
}

function autoEleven(team = S.club) {
  let pool = S.players[team].filter(isAvailable),
    roles = slotRoles(clubFormation(team)),
    chosen = new Array(roles.length).fill(null),
    used = new Set();
  /* pass 1: natural players first, best first */
  roles.forEach((role, i) => {
    let p = pool.filter((x) => x.pos === role && !used.has(x.id)).sort((a, b) => effRating(b, role) - effRating(a, role))[0];
    if (p) {
      chosen[i] = p;
      used.add(p.id);
    }
  });
  /* pass 2: gaps (injuries, thin squad) filled by the best fit, preferring listed secondary roles */
  roles.forEach((role, i) => {
    if (chosen[i]) return;
    let p = pool.filter((x) => !used.has(x.id) && (role === 'GK' ? x.pos === 'GK' : x.pos !== 'GK')).sort((a, b) => effRating(b, role) - effRating(a, role))[0] || pool.filter((x) => !used.has(x.id)).sort((a, b) => b.r - a.r)[0];
    if (p) {
      chosen[i] = p;
      used.add(p.id);
    }
  });
  return chosen.filter(Boolean);
}

/* Your lineup, with optional smart rotation for tired / unavailable starters. */
function getEleven(team = S.club) {
  if (team !== S.club) return autoEleven(team);
  let avail = S.players[team].filter(isAvailable),
    roles = slotRoles(S.formation),
    ids = Array.isArray(S.lineupIds) ? S.lineupIds : [],
    chosen = [],
    seen = new Set();
  /* keep every valid starter in his slot; only fill the gaps */
  for (let i = 0; i < 11; i++) {
    let p = avail.find((x) => x.id === ids[i]);
    if (p && !seen.has(p.id)) {
      chosen[i] = p;
      seen.add(p.id);
    }
  }
  if (chosen.filter(Boolean).length < 11) {
    if (chosen.filter(Boolean).length === 0) {
      let auto = autoEleven(team);
      S.lineupIds = auto.map((p) => p.id);
      return auto;
    }
    for (let i = 0; i < 11; i++) {
      if (chosen[i]) continue;
      let fit = avail
        .filter((x) => !seen.has(x.id))
        .sort((a, b) => effRating(b, roles[i]) - effRating(a, roles[i]));
      let p = fit.find((x) => x.pos === roles[i]) || fit[0];
      if (!p) break;
      chosen[i] = p;
      seen.add(p.id);
    }
    if (chosen.filter(Boolean).length === 11) S.lineupIds = chosen.map((p) => p.id);
    else {
      let auto = autoEleven(team);
      S.lineupIds = auto.map((p) => p.id);
      return auto;
    }
  }
  if (S.autoRotate) {
    let used = new Set(chosen.map((p) => p.id));
    chosen = chosen.map((p, i) => {
      if ((p.fitness ?? 100) >= 62) return p;
      let sub = avail
        .filter((x) => !used.has(x.id) && x.pos === roles[i] && (x.fitness ?? 100) > (p.fitness ?? 100) + 15 && x.r >= p.r - 7)
        .sort((a, b) => effRating(b, roles[i]) - effRating(a, roles[i]))[0];
      if (!sub) return p;
      used.add(sub.id);
      return sub;
    });
  }
  return chosen;
}

/* A club's line strengths for a given XI, tactics and formation. */
function teamProfile(ci, xi, t) {
  xi = xi || getEleven(ci);
  t = t || tacticsFor(ci);
  let f = clubFormation(ci),
    roles = slotRoles(f),
    g = { GK: [], DEF: [], MID: [], ATT: [] };
  xi.forEach((p, i) => g[roles[i] || p.pos].push(effRating(p, roles[i] || p.pos)));
  let avg = (a) => (a.length ? a.reduce((s, x) => s + x, 0) / a.length : 60),
    gk = avg(g.GK),
    def = avg(g.DEF),
    mid = avg(g.MID),
    att = avg(g.ATT),
    nd = g.DEF.length,
    nm = g.MID.length,
    na = g.ATT.length,
    A = (3 * att * na + 1.2 * mid * nm) / Math.max(1, 3 * na + 1.2 * nm),
    D = (2 * def * nd + 0.7 * mid * nm + 3 * gk) / Math.max(1, 2 * nd + 0.7 * nm + 3),
    overall = xi.reduce((s, p, i) => s + effRating(p, roles[i] || p.pos), 0) / Math.max(1, xi.length),
    fitness = xi.reduce((s, p) => s + (p.fitness ?? 100), 0) / Math.max(1, xi.length),
    morale = xi.reduce((s, p) => s + (p.morale ?? 65), 0) / Math.max(1, xi.length);
  return { ci, xi, f, t, gk, def, mid, att, nd, nm, na, A, D, M: mid + (nm - 3) * 1.1, overall, fitness, morale };
}

/* Expected goals for team P attacking team Q. */
function expectedGoals(P, Q, home) {
  let s = (P.A - Q.D) * 0.55 + (P.M - Q.M) * 0.2 + (P.overall - Q.overall) * 0.25,
    lam = ENGINE.base * (home ? ENGINE.homeBoost : ENGINE.awayDrag) * Math.exp(ENGINE.k * s),
    ps = STYLE_FX[P.t.attack] || STYLE_FX.Balanced,
    qs = STYLE_FX[Q.t.attack] || STYLE_FX.Balanced,
    pl = LINE_FX[P.t.line] || LINE_FX.Balanced,
    ql = LINE_FX[Q.t.line] || LINE_FX.Balanced,
    pf = FOCUS_FX[P.t.focus] || FOCUS_FX.Cohesion,
    qf = FOCUS_FX[Q.t.focus] || FOCUS_FX.Cohesion;
  lam *= ps[0] * pl[0] * pf[0] * qs[1] * ql[1] * qf[1];
  if (P.t.attack === 'Counter-attacking') lam *= P.overall < Q.overall ? 1.07 : 0.98;
  if (Q.t.attack === 'Counter-attacking' && P.overall > Q.overall) lam *= 1.02;
  /* shape: more forwards = more goals but a looser back line */
  lam *= 1 + (P.na - 2.5) * 0.022 - (Q.nd - 4) * 0.012;
  /* tired legs hurt, a high press hurts more */
  if (P.fitness < 80) lam *= 1 - (80 - P.fitness) * 0.004 * (P.t.line === 'High press' ? 1.5 : 1);
  lam *= Math.exp(gauss() * 0.07); /* day-to-day form */
  return Math.max(ENGINE.minL, Math.min(ENGINE.maxL, lam));
}

const POS_SCORE_W = { ATT: 7, MID: 3, DEF: 0.9, GK: 0.01 };
const POS_ASSIST_W = { ATT: 3.2, MID: 4, DEF: 1.3, GK: 0.1 };

/* Simulate one match. Does NOT touch the save: see applyMatch(). */
function simulateMatch(hi, ai) {
  let xis = [getEleven(hi), getEleven(ai)],
    teams = [hi, ai],
    prof = [teamProfile(hi, xis[0]), teamProfile(ai, xis[1])],
    lam = [expectedGoals(prof[0], prof[1], true), expectedGoals(prof[1], prof[0], false)],
    goals = (() => {
      let f = { easy: 1.07, hard: 0.93 }[S.difficulty] || 1;
      if (f !== 1) {
        if (hi === S.club) { lam[0] *= f; lam[1] /= f; }
        else if (ai === S.club) { lam[1] *= f; lam[0] /= f; }
      }
      return [poisson(lam[0]), poisson(lam[1])];
    })(),
    events = [],
    usedMinutes = new Set();
  const uniqueMinute = (lo, hi2) => {
    for (let t = 0; t < 12; t++) {
      let m = rint(lo, hi2);
      if (!usedMinutes.has(m)) {
        usedMinutes.add(m);
        return m;
      }
    }
    return rint(lo, hi2);
  };
  /* appearances: who was on the pitch, from which minute to which */
  let apps = [0, 1].map((k) => {
    let roles = slotRoles(prof[k].f);
    return xis[k].map((p, i) => ({ p, role: roles[i] || p.pos, from: 0, to: 90, g: 0, a: 0, y: 0, red: false, hurt: 0 }));
  });
  let benches = [0, 1].map((k) => {
    let on = new Set(xis[k].map((p) => p.id));
    return S.players[teams[k]].filter((p) => isAvailable(p) && !on.has(p.id)).sort((a, b) => b.r - a.r);
  });
  let subsLeft = [3, 3];
  const makeSub = (k, out, min, reason) => {
    if (subsLeft[k] <= 0) return null;
    let bench = benches[k],
      pool = bench.filter((b) => (out.role === 'GK' ? b.pos === 'GK' : b.pos === out.role)),
      cand = (out.role === 'GK' ? pool : pool.length ? pool : bench.filter((b) => b.pos !== 'GK'))[0];
    if (!cand) return null;
    bench.splice(bench.indexOf(cand), 1);
    subsLeft[k]--;
    out.to = min;
    let entry = { p: cand, role: out.role, from: min, to: 90, g: 0, a: 0, y: 0, red: false, hurt: 0 };
    apps[k].push(entry);
    events.push({
      min,
      type: 'sub',
      team: teams[k],
      pid: cand.id,
      text: 'SUB · ' + cand.name + ' replaces ' + out.p.name + (reason ? ' (' + reason + ')' : '') + '.',
    });
    return entry;
  };
  const onPitch = (k, min) => apps[k].filter((x) => x.from <= min && x.to >= min && !x.red);

  /* injuries and cards */
  for (let k = 0; k < 2; k++) {
    for (let a of apps[k].slice()) {
      let fit = a.p.fitness ?? 100,
        press = prof[k].t.line === 'High press' ? 1.25 : 1,
        pHurt = (0.009 + (100 - fit) * 0.00035) * press;
      if (Math.random() < pHurt) {
        let min = uniqueMinute(8, 85),
          r = Math.random(),
          wk = r < 0.42 ? 1 : r < 0.67 ? 2 : r < 0.82 ? 3 : r < 0.95 ? rint(4, 7) : rint(8, 14);
        a.hurt = wk;
        a.to = min;
        events.push({ min, type: 'injury', team: teams[k], pid: a.p.id, text: 'INJURY · ' + a.p.name + ' goes down injured (' + wk + (wk === 1 ? ' week' : ' weeks') + ').' });
        makeSub(k, a, min, 'injury');
        continue;
      }
      let pY = ({ GK: 0.02, DEF: 0.11, MID: 0.1, ATT: 0.065 }[a.p.pos] || 0.08) * (prof[k].t.line === 'High press' ? 1.2 : 1);
      if (Math.random() < pY) {
        let min = uniqueMinute(10, 88);
        a.y = 1;
        events.push({ min, type: 'yellow', team: teams[k], pid: a.p.id, text: 'YELLOW CARD · ' + a.p.name + ' is booked.' });
        if (Math.random() < 0.06) {
          a.y = 2;
          a.red = true;
          let rm = Math.min(90, min + rint(3, 25));
          a.to = rm;
          events.push({ min: rm, type: 'red', team: teams[k], pid: a.p.id, text: 'RED CARD · ' + a.p.name + ' is sent off for a second booking.' });
        }
      } else if (Math.random() < 0.005) {
        let min = uniqueMinute(12, 88);
        a.red = true;
        a.to = min;
        events.push({ min, type: 'red', team: teams[k], pid: a.p.id, text: 'RED CARD · ' + a.p.name + ' is sent off.' });
      }
    }
  }
  /* tactical substitutions (up to 3) */
  for (let k = 0; k < 2; k++) {
    let wants = subsLeft[k],
      mins = Array.from({ length: wants }, () => rint(56, 82)).sort((a, b) => a - b);
    for (let min of mins) {
      let cur = onPitch(k, min).filter((x) => x.role !== 'GK' && x.from === 0);
      if (!cur.length || subsLeft[k] <= 0) break;
      let out = cur.sort((a, b) => (a.p.fitness ?? 100) - (b.p.fitness ?? 100) + (Math.random() - 0.5) * 12)[0];
      makeSub(k, out, min, '');
    }
  }
  /* goals */
  for (let k = 0; k < 2; k++) {
    for (let n = 0; n < goals[k]; n++) {
      let min = uniqueMinute(1, 90),
        on = onPitch(k, min);
      if (!on.length) on = apps[k].filter((x) => !x.red);
      let scorer = weighted(on, (x) => (POS_SCORE_W[x.role] || 1) * Math.pow(Math.max(40, x.p.r) / 80, 4)),
        assister =
          Math.random() < 0.74
            ? weighted(on.filter((x) => x !== scorer), (x) => (POS_ASSIST_W[x.role] || 1) * Math.pow(Math.max(40, x.p.r) / 80, 3))
            : null;
      scorer.g++;
      if (assister) assister.a++;
      events.push({
        min,
        type: 'goal',
        team: teams[k],
        pid: scorer.p.id,
        aid: assister ? assister.p.id : null,
        text: 'GOAL · ' + scorer.p.name + ' scores' + (assister ? ' — assisted by ' + assister.p.name + '.' : '.'),
      });
    }
  }
  /* shots, possession, atmosphere */
  let stats = [0, 1].map((k) => {
    let shots = Math.max(goals[k], Math.round(lam[k] * 7.4 + gauss() * 2.2)),
      onTarget = goals[k];
    for (let i = 0; i < shots - goals[k]; i++) if (Math.random() < 0.3) onTarget++;
    return { shots, onTarget, xg: Math.max(0.1, Math.round(lam[k] * rnd(0.92, 1.08) * 100) / 100) };
  });
  let poss =
    50 +
    (prof[0].M - prof[1].M) * 0.9 +
    ((STYLE_FX[prof[0].t.attack] || [0, 0, 0])[2] + (LINE_FX[prof[0].t.line] || [0, 0, 0])[2]) -
    ((STYLE_FX[prof[1].t.attack] || [0, 0, 0])[2] + (LINE_FX[prof[1].t.line] || [0, 0, 0])[2]) +
    gauss() * 2;
  poss = Math.round(Math.max(32, Math.min(68, poss)));
  stats[0].poss = poss;
  stats[1].poss = 100 - poss;
  for (let k = 0; k < 2; k++) {
    let misses = Math.min(3, Math.max(0, stats[k].shots - goals[k]));
    for (let i = 0; i < Math.min(2, misses); i++) {
      let min = uniqueMinute(4, 88),
        on = onPitch(k, min).filter((x) => x.role !== 'GK');
      if (!on.length) continue;
      let shooter = weighted(on, (x) => POS_SCORE_W[x.role] || 1);
      events.push({
        min,
        type: 'chance',
        team: teams[k],
        pid: shooter.p.id,
        text: pick([
          'CHANCE · ' + shooter.p.name + ' fires just wide.',
          'SAVE · The keeper denies ' + shooter.p.name + ' at his near post.',
          'CHANCE · ' + shooter.p.name + ' hits the post!',
          'CHANCE · ' + shooter.p.name + ' blazes over from close range.',
        ]),
      });
    }
  }
  events.sort((a, b) => a.min - b.min || (a.type === 'goal' ? -1 : 1));

  /* player ratings */
  let ratings = {},
    best = { id: null, r: 0 };
  for (let k = 0; k < 2; k++) {
    let gf = goals[k],
      ga = goals[1 - k],
      res = gf > ga ? 0.35 : gf < ga ? -0.3 : 0;
    for (let a of apps[k]) {
      let mins = a.to - a.from;
      if (mins < 1) continue;
      let r =
        6.2 + gauss() * 0.45 + res + a.g * 1 + a.a * 0.55 - (a.y ? 0.15 : 0) - (a.red ? 1.4 : 0) - (a.hurt ? 0.2 : 0);
      if (ga === 0 && (a.role === 'GK' || a.role === 'DEF') && mins >= 60) r += 0.55;
      if (ga >= 3 && (a.role === 'GK' || a.role === 'DEF')) r -= 0.4;
      if (mins < 25) r = 6 + (r - 6) * 0.5;
      r = Math.round(Math.max(4.2, Math.min(10, r)) * 10) / 10;
      ratings[a.p.id] = r;
      let score = r + (gf > ga ? 0.25 : 0);
      if (score > best.r) best = { id: a.p.id, r: score };
    }
  }
  return { home: hi, away: ai, goals, lam, stats, events, apps, ratings, mom: best.id, prof };
}

/* Write a simulated match into the save: table, player stats, fitness, cards, injuries. */
function applyMatch(m, week) {
  let [hg, ag] = m.goals;
  record(m.home, hg, ag);
  record(m.away, ag, hg);
  S.results ??= {};
  (S.results[week] ??= []).push([m.home, m.away, hg, ag]);
  [m.home, m.away].forEach((ci, k) => {
    let gf = m.goals[k],
      ga = m.goals[1 - k],
      mood = gf > ga ? 3 : gf < ga ? -3 : 0,
      focus = ci === S.club ? S.tactics?.focus : '',
      press = tacticsFor(ci).line === 'High press' ? 3 : 0;
    for (let a of m.apps[k]) {
      let p = a.p,
        mins = Math.max(0, a.to - a.from);
      if (mins < 1) continue;
      let st = (p.st ??= { app: 0, g: 0, a: 0, cs: 0, y: 0, r: 0, rt: 0, rn: 0, mom: 0, min: 0 });
      st.app++;
      st.min += mins;
      st.g += a.g;
      st.a += a.a;
      st.y += a.y ? 1 : 0;
      st.r += a.red ? 1 : 0;
      if (ga === 0 && mins >= 60 && (a.role === 'GK' || a.role === 'DEF' || a.role === 'MID')) st.cs += a.role === 'MID' ? 0 : 1;
      let rt = m.ratings[p.id];
      if (rt) {
        st.rt += rt;
        st.rn++;
        p.lastRating = rt;
      }
      if (m.mom === p.id) st.mom++;
      p.fitness = Math.max(35, (p.fitness ?? 100) - Math.round(9 * (mins / 90) + press - (focus === 'Fitness' ? 2 : 0)));
      p.morale = Math.max(25, Math.min(99, (p.morale ?? 65) + mood + (rt >= 8 ? 2 : rt && rt < 5.5 ? -2 : 0) + (focus === 'Morale' ? 1 : 0)));
      p.played = true;
      if (a.y === 1) {
        p.yellowCards = (p.yellowCards || 0) + 1;
        if (p.yellowCards >= 5) {
          p.yellowCards = 0;
          p.ban = Math.max(p.ban || 0, 1);
          p.fresh = true;
          m.events.push({ min: 90, type: 'suspension', team: ci, pid: p.id, text: 'SUSPENSION · ' + p.name + ' reaches five bookings and misses the next match.' });
        }
      }
      if (a.red) {
        p.ban = Math.max(p.ban || 0, a.y === 2 ? 1 : 2);
        p.fresh = true;
      }
      if (a.hurt) {
        p.injuryWeeks = a.hurt;
        p.fresh = true;
      }
    }
  });
}

/* End-of-matchweek bookkeeping for every club: recovery, bans, injuries, loans. */
function processWeek() {
  if (S.week >= 20 && S.janWindow !== S.season) {
    S.janWindow = S.season;
    aiTransfers('winter', 1);
  }
  for (let ci = 0; ci < S.players.length; ci++) {
    for (let p of S.players[ci]) {
      let focus = ci === S.club ? S.tactics?.focus : '';
      if (p.played) p.fitness = Math.min(100, (p.fitness ?? 100) + 6 + (focus === 'Fitness' ? 3 : 0));
      else p.fitness = Math.min(100, (p.fitness ?? 100) + (isAvailable(p) ? 14 : 8));
      if (!p.fresh) {
        if (p.ban > 0) p.ban--;
        if (p.injuryWeeks > 0) p.injuryWeeks--;
      }
      /* unused squad players drift unhappy, everyone drifts back to normal */
      let m = p.morale ?? 65;
      if (!p.played && isAvailable(p) && p.r >= 78 && ci === S.club) m -= 1;
      p.morale = Math.round(Math.max(25, Math.min(95, 65 + (m - 65) * 0.85)));
      p.played = false;
      delete p.fresh;
      if (p.loanWeeks > 0) {
        if (ci === S.club) S.budget += Math.max(0.01, (p.wage || 0) * 0.00025);
        p.loanWeeks--;
        if (!p.loanWeeks) {
          p.loanTo = '';
          p.morale = Math.min(95, (p.morale || 70) + 3);
          if (ci === S.club) addNews(p.name + ' returned from loan.', 'transfer');
        }
      }
    }
  }
}

/* Fixtures: double round-robin. Same pairing rule for every club, including you. */
function weekPairs(week) {
  let rest = Array.from({ length: 19 }, (_, i) => i + 1),
    rot = (week - 1) % 19;
  rest = rest.slice(19 - rot).concat(rest.slice(0, 19 - rot));
  let ix = [0, ...rest],
    pairs = [];
  for (let j = 0; j < 10; j++) {
    let x = ix[j],
      y = ix[19 - j];
    if (week % 2 === 0) [x, y] = [y, x];
    pairs.push([x, y]); /* [home, away] */
  }
  return pairs;
}
function fixtureFor(team, week) {
  let pr = weekPairs(week).find((p) => p[0] === team || p[1] === team);
  return pr ? { opp: pr[0] === team ? pr[1] : pr[0], home: pr[0] === team } : { opp: (team + 1) % 20, home: true };
}
function fixtureOpp(team, week) {
  return fixtureFor(team, week).opp;
}

/* League table helpers */
function leagueOrder() {
  return S.stats
    .map((x, i) => ({ i, ...x }))
    .sort((a, b) => b.pts - a.pts || b.gf - b.ga - (a.gf - a.ga) || b.gf - a.gf || a.i - b.i);
}
function rankOf(ci) {
  return leagueOrder().findIndex((x) => x.i === ci) + 1;
}
function strength(i = S.club) {
  return Math.round(teamProfile(i).overall);
}
/* Quick goals for side games (European nights): uses the same ratings. */
function matchGoals(i, j) {
  let a = teamProfile(i),
    b = teamProfile(j);
  return poisson(expectedGoals(a, b, true));
}

/* Plain-English advice for the next opponent (shown on the Team page). */
function scoutReport(opp) {
  let me = teamProfile(S.club),
    them = teamProfile(opp),
    tips = [],
    d = (x, y) => Math.round(x - y);
  if (d(me.att, them.def) >= 4) tips.push('Your forwards should have the edge over their back line. Attack with intent.');
  else if (d(me.att, them.def) <= -4) tips.push('Their defence is stronger than your attack. Be patient and look for set-piece or counter chances.');
  if (d(me.mid, them.mid) <= -4) tips.push('They will probably dominate midfield. Consider an extra midfielder (4-2-3-1, 3-5-2) or a counter-attacking approach.');
  else if (d(me.mid, them.mid) >= 4) tips.push('You are stronger in midfield. A Possession style should let you control the game.');
  if (them.gk >= me.att + 2) tips.push('Their keeper is among their best players, so shots from distance may not be enough.');
  if (them.fitness < 80) tips.push('Their players look tired. A high press could pay off.');
  if (me.fitness < 78) tips.push('Your starters are tired. Rotate the squad or turn on Smart rotation.');
  if (them.overall - me.overall >= 4) tips.push('They are the stronger side on paper. A Low line with Counter-attacking keeps you compact.');
  if (me.overall - them.overall >= 4) tips.push('You are the stronger side on paper. Take the game to them.');
  if (!tips.length) tips.push('An evenly matched game. Pick your best XI and trust your shape.');
  return { me, them, tips: tips.slice(0, 3) };
}

/* ---------- Between seasons: ageing, growth, decline and retirement ---------- */
function developPlayers() {
  let report = { risers: [], fallers: [], retired: [] };
  for (let ci = 0; ci < S.players.length; ci++) {
    let keep = [];
    for (let p of S.players[ci]) {
      let age = p.age || 24,
        eff = p.pos === 'GK' ? age - 3 : age,
        pot = Math.max(p.pot || p.r, p.r),
        before = p.r,
        d;
      if (eff <= 21) d = (pot - p.r) * rnd(0.25, 0.5) + rnd(0, 1.3);
      else if (eff <= 24) d = (pot - p.r) * rnd(0.2, 0.4) + rnd(-0.4, 1);
      else if (eff <= 28) d = rnd(-1, 1.3);
      else if (eff <= 31) d = rnd(-2, 0.4);
      else if (eff <= 34) d = rnd(-3, -0.4);
      else d = rnd(-4.2, -1);
      if (ci === S.club && S.tactics?.focus === 'Youth development' && age <= 23) d += 1;
      d = Math.round(d);
      p.r = Math.max(45, Math.min(Math.max(pot, before), before + d));
      p.pot = Math.max(p.r, p.pot || p.r);
      if (age >= 33 || p.r >= pot) p.pot = p.r;
      p.age = age + 1;
      p.value = valueFor(p);
      if (Math.abs(p.r - before) >= 2) p.wage = wageFor(p);
      p.fitness = 100;
      p.injuryWeeks = 0;
      p.ban = 0;
      p.yellowCards = 0;
      p.morale = Math.max(50, Math.min(75, p.morale ?? 62));
      p.st = null;
      p.lastRating = null;
      let squad = S.players[ci].length - (report.retired.filter((x) => x.ci === ci).length);
      if (p.age >= 34 && squad > 21 && Math.random() < (p.age >= 38 ? 0.9 : p.age >= 36 ? 0.55 : p.age >= 35 ? 0.3 : 0.12)) {
        report.retired.push({ ci, name: p.name, age: p.age, r: p.r });
        continue;
      }
      keep.push(p);
      if (ci === S.club) {
        if (p.r - before >= 2) report.risers.push({ name: p.name, from: before, to: p.r });
        if (before - p.r >= 2) report.fallers.push({ name: p.name, from: before, to: p.r });
      }
    }
    S.players[ci] = keep;
  }
  S.retirements ??= [];
  for (let x of report.retired) if (x.ci === S.club) S.retirements.unshift({ name: x.name, season: S.season, ovr: x.r });
  S.lineupIds = (S.lineupIds || []).filter((id) => S.players[S.club].some((p) => p.id === id));
  report.risers.sort((a, b) => b.to - b.from - (a.to - a.from));
  report.fallers.sort((a, b) => b.from - b.to - (a.from - a.to));
  return report;
}


/* ---------- AI club transfers ----------
   Clubs buy to fix their weakest position and sell surplus players. Rich clubs can pay more, so stars
   drift towards the big spenders, but fees recycle to sellers and squads stay balanced. The user's club
   is never touched here: you deal with AI clubs through the normal transfer market. */
function aiGroup(p) {
  return POS_GROUP[p.pos] || p.pos;
}
function aiWeakness(squad) {
  let need = { GK: 1, DEF: 4, MID: 3, ATT: 3 },
    worst = null;
  for (let g in need) {
    let rs = squad.filter((p) => aiGroup(p) === g && !(p.loanWeeks > 0)).map((p) => p.r).sort((a, b) => b - a),
      gap = (rs[need[g] - 1] ?? 50) - (g === 'GK' ? 2 : 0);
    if (rs.length < need[g] + (g === 'GK' ? 1 : 0)) gap -= 6; /* too few bodies in this area */
    if (!worst || gap < worst.gap) worst = { g, gap };
  }
  return worst;
}
function aiTransfers(window, maxPerClub) {
  S.aiCash ??= clubs.map((c) => c.budget * 0.5);
  S.aiDeals ??= [];
  let summer = window === 'summer',
    done = [],
    order = clubs.map((c, i) => i).filter((i) => i !== S.club).sort(() => Math.random() - 0.5);
  S.aiBoost ??= clubs.map(() => 0);
  for (let ci of order) {
    let b = clubs[ci].budget * (1 + S.aiBoost[ci]);
    S.aiCash[ci] = Math.min(b * 1.2, S.aiCash[ci] + b * (summer ? 0.4 : 0.1));
  }
  for (let round = 0; round < maxPerClub; round++) {
    for (let ci of order) {
      let squad = S.players[ci];
      if (!squad || squad.length > 27) continue;
      let weak = aiWeakness(squad);
      if (!weak) continue;
      let options = [];
      for (let si of order) {
        if (si === ci) continue;
        let seller = S.players[si];
        if (seller.length <= 21) continue;
        let top = [...seller].sort((a, b) => b.r - a.r).slice(0, 3).map((p) => p.id);
        for (let p of seller) {
          if (aiGroup(p) !== weak.g || p.loanWeeks > 0 || p.r < weak.gap + 2 || p.r > weak.gap + 7 || p.academy) continue;
          if (top.includes(p.id) && p.age < 31) continue; /* key men are not for sale */
          if (weak.g !== 'GK' && seller.filter((x) => aiGroup(x) === weak.g).length <= (weak.g === 'DEF' ? 5 : 4)) continue;
          if (weak.g === 'GK' && seller.filter((x) => x.pos === 'GK').length <= 2) continue;
          let fee = Math.max(0.5, (p.value || valueFor(p)) * 1.05 * (0.9 + Math.random() * 0.25));
          if (fee > S.aiCash[ci]) continue;
          /* clubs rarely sell to a bigger rival's squad if the player is a key man, unless the price is high */
          let score = p.r - fee * 0.08 + (p.pot > p.r && p.age < 24 ? 1 : 0) - Math.max(0, p.age - 30) * 0.8 + Math.random() * 1.5;
          options.push({ p, si, fee, score });
        }
      }
      if (!options.length) continue;
      options.sort((a, b) => b.score - a.score);
      let { p, si, fee } = options[0];
      S.players[si] = S.players[si].filter((x) => x.id !== p.id);
      S.aiCash[si] += fee;
      S.aiCash[ci] -= fee;
      let from = clubs[si].name;
      p.club = clubs[ci].name;
      p.value = Math.round(fee * 10) / 10;
      p.wage = wageFor(p);
      p.morale = 68;
      p.lineupSpot = undefined;
      squad.push(p);
      S.movedPlayers ??= {};
      S.movedPlayers[p.name] = clubs[ci].name;
      done.push({ name: p.name, r: p.r, from, to: clubs[ci].name, fee });
    }
  }
  /* bigger clubs release their weakest surplus players back to the free pool */
  for (let ci of order) {
    let t = S.players[ci];
    while (t.length > 26) {
      let gks = t.filter((p) => p.pos === 'GK').length,
        worth = (p) => p.r + (p.pot - p.r) * 0.4 - Math.max(0, p.age - 29) * 0.6,
        out = t.filter((p) => p.pos !== 'GK' || gks > 3).sort((x, y) => worth(x) - worth(y))[0];
      if (!out) break;
      t.splice(t.indexOf(out), 1);
    }
  }
  done.sort((a, b) => b.fee - a.fee);
  for (let d of done.slice(0, 5)) {
    addNews(d.to + ' signed ' + d.name + ' (' + d.r + ') from ' + d.from + ' for ' + formatM(d.fee) + '.', 'transfer');
  }
  S.aiDeals = done.concat(S.aiDeals).slice(0, 40);
  return done;
}

/* Club ambition: clubs that finish high attract investment, clubs that struggle lose it. Called once per season. */
function updateClubFortunes() {
  S.aiBoost ??= clubs.map(() => 0);
  leagueOrder().forEach((o, rank) => {
    let delta = rank < 4 ? 0.06 : rank < 8 ? 0.02 : rank >= 17 ? -0.07 : rank >= 12 ? -0.02 : 0;
    S.aiBoost[o.i] = Math.max(-0.4, Math.min(0.5, (S.aiBoost[o.i] || 0) * 0.9 + delta));
  });
}
