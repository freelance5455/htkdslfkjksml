const $ = (s) => document.querySelector(s),
  safe = (s) =>
    String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]),
  clubs = raw.map((r, i) => ({
    name: r[0],
    badge: r[1],
    code: CREST_CODE[r[0]] || r[0].slice(0, 3).toUpperCase(),
    manager: MANAGERS[r[0]] || '',
    color: r[2],
    budget: r[3],
    players: r[4]
      .split(',')
      .map((v, n) => {
        let [name, pos, rating, pot] = v.split('|');
        return {
          id: i + '-' + n,
          name,
          pos,
          r: +rating,
          pot: +pot,
          age: 20 + ((i + n * 3) % 12),
          value: Math.max(2, Math.round((+rating - 56) ** 2 * 0.007 + 2)),
          club: r[0],
        };
      })
      .concat(
        ['Elliot Ward', 'Luca Moretti', 'Noah Bennett', 'Max Jensen', 'Leo Santos', 'Kai Morgan'].map(
          (name, n) => ({
            id: i + '-y' + n,
            name,
            pos: ['GK', 'DEF', 'DEF', 'MID', 'MID', 'ATT'][n],
            r: 67 + ((i * 3 + n * 2) % 9),
            pot: 82 + ((i + n * 3) % 14),
            age: 18 + (n % 4),
            value: 3 + (n % 3),
            club: r[0],
            young: true,
          }),
        ),
      ),
  }));

let S = loadSaved(),
  tab = 'home',
  filter = 'All';

function loadSaved() {
  try {
    let d = JSON.parse(localStorage.getItem('touchline') || 'null');
    return d && typeof d.club === 'number' ? d : null;
  } catch (e) {
    return null;
  }
}

function persist() {
  try {
    localStorage.setItem('touchline', JSON.stringify(S));
  } catch (e) {
    console.warn('Could not save', e);
  }
}

function my() {
  return clubs[S.club];
}

function head(k, t, s, act = '') {
  return (
    '<div class="head"><div><div class="eyebrow">' +
    k +
    '</div><h1>' +
    t +
    '</h1><div class="sub">' +
    s +
    '</div></div>' +
    act +
    '</div>'
  );
}

function record(i, gf, ga) {
  let r = S.stats[i];
  r.p++;
  r.gf += gf;
  r.ga += ga;
  if (gf > ga) {
    r.w++;
    r.pts += 3;
  } else if (gf === ga) {
    r.d++;
    r.pts++;
  } else r.l++;
}

function toast(t) {
  let e = document.createElement('div');
  e.className = 'toast';
  e.textContent = t;
  document.body.append(e);
  setTimeout(() => e.remove(), 2400);
}

function wageFor(p) {
  if (knownWage[p.name]) return knownWage[p.name];
  let r = p.r || 68;
  return Math.max(0.6, Math.round(6.5 * Math.pow(1.145, Math.max(0, r - 65)) * 10) / 10);
}

function moraleTag(v) {
  return (
    '<span class="badge" style="color:' +
    (v >= 75 ? '#15734d' : v < 50 ? '#bb493e' : '#92751a') +
    '">' +
    (v >= 75 ? 'Good' : v < 50 ? 'Poor' : 'Okay') +
    ' · ' +
    Math.round(v) +
    '</span>'
  );
}

function boardDecision(fee, wage, p, bonus = 0) {
  let payroll = weeklyWages(),
    limit = S.wageLimit || my().budget * 34;
  let rating = p.r,
    strategic = rating >= strength(S.club) - 4 || S.players[S.club].length < 18;
  let excess = payroll + wage > limit;
  let cash = fee + bonus / 1000 <= S.budget;
  let accepted = cash && !excess && strategic;
  return {
    accepted,
    payroll,
    limit,
    reason: !cash
      ? 'The fee exceeds the transfer budget.'
      : excess
        ? 'The weekly wage would exceed the board’s wage budget.'
        : !strategic
          ? 'The board does not consider this signing a priority.'
          : 'The deal fits the board’s plans.',
  };
}

function marketRefresh() {
  let q = document.querySelector('#marketSearch'),
    v = q.value,
    pos = q.selectionStart;
  draw();
  q = document.querySelector('#marketSearch');
  q.focus();
  q.setSelectionRange(pos, pos);
}

function startNegotiation(id) {
  let p = S.players.flat().find((x) => x.id === id);
  if (!p) return;
  S.neg = {
    id,
    step: 'fee',
    bid: Math.round((p.value || valueFor(p)) * 0.9 * 10) / 10,
    counter: Math.round((p.value || valueFor(p)) * 1.2 * 10) / 10,
    wage: Math.round((p.wage || wageFor(p)) * 1.15 * 10) / 10,
    bonus: Math.round((p.wage || wageFor(p)) * 4),
  };
  persist();
  showNegotiation();
}

function showNegotiation(message = '') {
  let n = S.neg,
    p = S.players.flat().find((x) => x.id === n.id);
  if (!p) return;
  let body =
    n.step === 'fee'
      ? '<p>' +
        safe(p.club) +
        ' value ' +
        safe(p.name) +
        ' at <b>£' +
        p.value +
        'm</b>. Their opening asking price is <b>£' +
        n.counter +
        'm</b>.</p><label>Transfer bid <input id="feeOffer" type="number" min="0.1" step="0.1" value="' +
        n.bid +
        '"> £m</label><p class="sub">The selling club can accept, reject or counter your offer.</p><button class="btn" onclick="sendFee()">Make transfer bid</button>'
      : n.step === 'contract'
        ? '<p>The clubs have agreed a fee of <b>£' +
          n.agreed +
          'm</b>. ' +
          safe(p.name) +
          ' wants £' +
          n.demand +
          'k per week and a signing bonus.</p><label>Weekly wage (£k) <input id="wageOffer" type="number" min="0.1" step="0.1" value="' +
          n.wage +
          '"></label>　<label>Signing bonus (£k) <input id="bonusOffer" type="number" min="0" step="10" value="' +
          n.bonus +
          '"></label><p class="sub">Player wage demands use public reported wage estimates as the starting point; negotiable contract offers are game choices.</p><button class="btn" onclick="sendContract()">Submit contract offer</button>'
        : n.step === 'board'
          ? '<p>' +
            safe(n.outcome) +
            '</p><p class="sub">Board response: ' +
            safe(n.boardReason) +
            '</p>' +
            (n.board.accepted
              ? '<button class="btn" onclick="finalizeSigning()">Confirm transfer</button>'
              : '<button class="tiny" onclick="closeNegotiation()">Close</button>')
          : '<p>' +
            safe(n.outcome || 'Talks have ended.') +
            '</p><button class="btn" onclick="closeNegotiation()">Close</button>';
  document.body.insertAdjacentHTML(
    'beforeend',
    '<div class="overlay" id="negmodal"><div class="box"><div class="eyebrow">Transfer negotiation · ' +
      safe(p.name) +
      '</div><h2 style="font:800 22px Manrope">' +
      (n.step === 'fee'
        ? 'Agree a transfer fee'
        : n.step === 'contract'
          ? 'Negotiate personal terms'
          : n.step === 'board'
            ? 'Board review'
            : 'Negotiation update') +
      '</h2>' +
      message +
      body +
      '<p><button class="tiny" onclick="closeNegotiation()">Cancel</button></p></div></div>',
  );
}

function sendFee() {
  let n = S.neg,
    p = S.players.flat().find((x) => x.id === n.id),
    offer = +document.querySelector('#feeOffer').value;
  if (!(offer > 0)) {
    toast('Enter a valid transfer bid.');
    return;
  }
  n.bid = offer;
  let ask = n.counter;
  if (offer >= ask || (p.transferListed && offer >= p.value * 1.03)) {
    n.agreed = offer;
    n.step = 'contract';
    n.demand = Math.max(0.6, Math.round((p.wage || wageFor(p)) * 1.18 * 10) / 10);
    n.wage = n.demand;
    n.bonus = Math.round(n.demand * 4);
    document.querySelector('#negmodal').remove();
    showNegotiation('The selling club accepts your offer. Now agree personal terms.');
  } else if (offer >= p.value * 0.72 && n.round < 1) {
    n.round = 1;
    n.counter = Math.round(Math.max(ask, offer * 1.18) * 10) / 10;
    n.bid = n.counter;
    document.querySelector('#negmodal').remove();
    showNegotiation(
      'The club rejects your bid but counters at £' +
        n.counter +
        'm. You can accept, counter again with your offer, or walk away.',
    );
  } else {
    n.step = 'ended';
    n.outcome = 'The selling club rejects your offer. The negotiation has ended.';
    document.querySelector('#negmodal').remove();
    showNegotiation();
  }
}

function sendContract() {
  let n = S.neg,
    p = S.players.flat().find((x) => x.id === n.id);
  n.wage = +document.querySelector('#wageOffer').value;
  n.bonus = +document.querySelector('#bonusOffer').value;
  if (!(n.wage > 0) || n.bonus < 0) {
    toast('Enter valid contract terms.');
    return;
  }
  if (n.wage < n.demand * 0.78) {
    n.step = 'ended';
    n.outcome = p.name + ' rejects the contract. The wage offer is too far below expectations.';
    document.querySelector('#negmodal').remove();
    showNegotiation();
    return;
  }
  n.board = boardDecision(n.agreed, n.wage, p, n.bonus);
  n.step = 'board';
  n.outcome =
    n.wage < n.demand ? 'The player accepts a lower wage.' : 'The player accepts your contract terms.';
  n.boardReason = n.board.reason;
  n.outcome +=
    ' ' + (n.board.accepted ? 'The board approves the transfer.' : 'The board refuses to approve the deal.');
  document.querySelector('#negmodal').remove();
  showNegotiation();
}

function closeNegotiation() {
  S.neg = null;
  persist();
  document.querySelector('#negmodal')?.remove();
  draw();
}

function formatM(n) {
  return '£' + (Math.round((Number(n) || 0) * 10) / 10).toFixed(1).replace(/\.0$/, '') + 'm';
}

function playersPage() {
  return (
    head(
      'Clubhouse',
      'Players',
      'Check morale, form and availability. Talk with a player to keep the squad settled.',
    ) +
    '<div class="panel tablewrap"><table class="tbl"><thead><tr><th>Player</th><th>Pos</th><th>Status</th><th>Morale</th><th>Form</th><th></th></tr></thead><tbody>' +
    roster()
      .slice()
      .sort((a, b) => b.r - a.r)
      .map(
        (p) =>
          '<tr><td><b>' +
          safe(p.name) +
          '</b></td><td>' +
          p.pos +
          '</td><td>' +
          (p.injuryWeeks
            ? '🩹 Injured · ' + p.injuryWeeks + ' wk'
            : p.ban
              ? 'Suspended'
              : p.loanWeeks
                ? 'On loan · ' + p.loanWeeks + ' wk'
                : S.lineupIds?.includes(p.id)
                  ? 'Selected XI'
                  : 'Available') +
          '</td><td>' +
          moraleTag(p.morale || 70) +
          '</td><td>' +
          (p.lastRating ? p.lastRating.toFixed(1) : '—') +
          '</td><td><button class="tiny" onclick="playerChat(\'' +
          encodeURIComponent(p.id) +
          '\')">Talk</button></td></tr>',
      )
      .join('') +
    '</tbody></table></div>'
  );
}

function playerChat(encoded) {
  let id = decodeURIComponent(encoded),
    p = roster().find((x) => x.id === id);
  if (!p) return;
  let xi = getEleven(),
    selected = xi.some((x) => x.id === id),
    line = p.injuryWeeks
      ? 'I’m injured at the moment. I’m working hard to get back.'
      : p.lastRating >= 7.7
        ? 'I’m feeling sharp in training and I want to keep my place in the team.'
        : selected
          ? 'I’m feeling good and ready to help the team.'
          : 'I feel I’m in good form and would like a chance in the starting eleven.';
  document.body.insertAdjacentHTML(
    'beforeend',
    '<div class="overlay" id="chatmodal"><div class="box"><div class="eyebrow">Player conversation</div><h2 style="font:800 22px Manrope">' +
      safe(p.name) +
      '</h2><div class="banner">' +
      safe(line) +
      '</div><button class="tiny" onclick="respondPlayer(\'' +
      encodeURIComponent(id) +
      '\',\'encourage\')">Encourage</button> <button class="tiny" onclick="respondPlayer(\'' +
      encodeURIComponent(id) +
      '\',\'promise\')">Promise a chance</button> <button class="tiny" onclick="respondPlayer(\'' +
      encodeURIComponent(id) +
      '\',\'warn\')">Set expectations</button><p><button class="tiny" onclick="document.querySelector(\'#chatmodal\').remove()">Close</button></p></div></div>',
  );
}

function money(n) {
  return formatM(n);
}

function market() {
  let q = (document.querySelector('#marketSearch')?.value || '').toLowerCase(),
    pos = filter || 'All',
    pool = S.players
      .flat()
      .filter(
        (p) =>
          p.club !== my().name &&
          (pos === 'All' || p.pos === pos) &&
          (!q || p.name.toLowerCase().includes(q) || p.club.toLowerCase().includes(q)),
      )
      .sort((a, b) => b.r - a.r);
  return (
    head(
      'Recruitment',
      'Transfer market',
      'Make a bid, negotiate the contract and seek board approval.',
      '<button class="btn light">Budget　' + formatM(S.budget) + '</button>',
    ) +
    '<div class="banner">Board confidence: <b>' +
    Math.round(S.boardApproval ?? 70) +
    '%</b> · Market value is a reference, not the transfer fee. Weekly wage figures are gross estimates. See <a href="https://www.transfermarkt.co.uk/premier-league/startseite/wettbewerb/GB1/saison_id/2026" target="_blank">Transfermarkt</a> and <a href="https://www.capology.com/uk/premier-league/salaries" target="_blank">Capology</a>.</div><div class="filters"><input id="marketSearch" placeholder="Search players or clubs…" value="' +
    safe(document.querySelector('#marketSearch')?.value || '') +
    '" oninput="marketRefresh()"><select onchange="filter=this.value;draw()">' +
    ['All', 'GK', 'DEF', 'MID', 'ATT']
      .map((x) => '<option ' + (x === pos ? 'selected' : '') + '>' + x + '</option>')
      .join('') +
    '</select><span class="badge">Wage limit ' +
    formatM((S.wageLimit || my().budget * 34) / 1000) +
    ' / week</span></div><div class="panel tablewrap"><table class="tbl"><thead><tr><th>Player</th><th>Club</th><th>Pos</th><th>Age</th><th>OVR</th><th>POT</th><th>Market value</th><th>Wage estimate</th><th></th></tr></thead><tbody>' +
    pool
      .map(
        (p) =>
          '<tr><td><b>' +
          safe(p.name) +
          '</b><div>' +
          moraleTag(p.morale || 70) +
          '</div></td><td>' +
          safe(p.club) +
          '</td><td>' +
          p.pos +
          '</td><td>' +
          p.age +
          '</td><td class="rating">' +
          p.r +
          '</td><td class="pot">' +
          p.pot +
          '</td><td>£' +
          (p.value || valueFor(p)) +
          'm</td><td>£' +
          (p.wage || wageFor(p)).toFixed(1) +
          'k/w</td><td><button class="tiny" onclick="startNegotiation(\'' +
          p.id +
          '\')">Negotiate</button></td></tr>',
      )
      .join('') +
    '</tbody></table></div>'
  );
}

function idFromAction(v) {
  try {
    return decodeURIComponent(v);
  } catch {
    return v;
  }
}

function toggleListed(encoded) {
  let id = idFromAction(encoded),
    p = roster().find((x) => x.id === id);
  if (!p) {
    toast('Could not find that player in your squad.');
    return;
  }
  p.transferListed = !p.transferListed;
  addNews(
    p.name +
      (p.transferListed
        ? ' is available for transfer, Touchline understands.'
        : ' has been removed from the transfer list.'),
    'transfer',
  );
  persist();
  draw();
  toast(p.name + (p.transferListed ? ' listed for transfer.' : ' removed from the list.'));
}

function releasePlayer(encoded) {
  let id = idFromAction(encoded),
    p = roster().find((x) => x.id === id);
  if (!p) return;
  if (!confirm('Release ' + p.name + ' from the club? This cannot be undone.')) return;
  S.players[S.club] = roster().filter((x) => x.id !== id);
  S.lineupIds = (S.lineupIds || []).filter((x) => x !== id);
  S.boardApproval = Math.max(5, (S.boardApproval ?? 70) - 0.5);
  addNews('Club confirms ' + p.name + ' has left after his contract was terminated.', 'transfer');
  persist();
  draw();
  toast(p.name + ' released.');
}

function sendOnLoan(encoded) {
  let id = idFromAction(encoded),
    p = roster().find((x) => x.id === id);
  if (!p || p.loanWeeks) return;
  if (p.injuryWeeks || p.ban) {
    toast('Unavailable players cannot be sent out on loan.');
    return;
  }
  p.loanWeeks = 8;
  p.loanTo = clubs[(S.club + S.week + 3) % 20].name;
  S.lineupIds = (S.lineupIds || []).filter((x) => x !== id);
  addNews(
    p.name + ' is set to join ' + p.loanTo + ' on an eight-week loan, with regular minutes expected.',
    'transfer',
  );
  persist();
  draw();
  toast(p.name + ' loan arranged.');
}

function addNews(text, type = 'club') {
  S.news = S.news || [];
  let headline = '',
    body = String(text),
    tag =
      type === 'match'
        ? 'MATCH REPORT'
        : type === 'transfer'
          ? 'TRANSFER DESK'
          : type === 'rumour'
            ? 'TRANSFER WATCH'
            : type === 'board'
              ? 'BOARDROOM'
              : type === 'player'
                ? 'DRESSING ROOM'
                : 'CLUB UPDATE';
  if (type === 'match') {
    let m = String(text).match(/^Full time: (.+) (\d+)–(\d+) (.+) \(([WDL])\)\.$/);
    if (m) {
      let [, clubName, a, b, opp, res] = m;
      headline =
        res === 'W'
          ? clubName + ' deliver when it matters'
          : res === 'D'
            ? clubName + ' forced to settle for a point'
            : clubName + ' left frustrated after defeat';
      body =
        clubName +
        ' ' +
        a +
        '–' +
        b +
        ' ' +
        opp +
        '. ' +
        (res === 'W'
          ? 'A disciplined display brings a welcome three points and lifts the mood around the club.'
          : res === 'D'
            ? 'The sides share the points after a closely fought contest.'
            : clubName + ' must regroup quickly after a difficult afternoon.') +
        ' The result keeps the season’s ambitions in focus.';
    }
  } else if (type === 'rumour') {
    headline = 'Names begin to circulate ahead of the next window';
  } else if (type === 'transfer') headline = String(text).split(/[,.]/)[0];
  else if (type === 'board') headline = 'Boardroom update';
  else if (type === 'player') headline = 'A message from the dressing room';
  else headline = String(text).split(/[.!?]/)[0];
  S.news.unshift({ week: S.week || 1, text: body, headline, tag, type });
  S.news = S.news.slice(0, 35);
  persist();
}

function simulateRumour() {
  if (Math.random() > 0.28) return;
  let targets = S.players.flat().filter((p) => p.club !== my().name && p.r >= 82);
  if (!targets.length) return;
  let p = targets[Math.floor(Math.random() * targets.length)],
    phrases = ['are understood to be monitoring', 'have been linked with', 'are weighing up a move for'];
  addNews(
    'Transfer talk: ' +
      p.name +
      ' (' +
      p.club +
      ') ' +
      phrases[Math.floor(Math.random() * phrases.length)] +
      ' a switch, though no formal approach has been made.',
    'rumour',
  );
}

function playerPositions(p) {
  if (knownPositionRoles && knownPositionRoles[p.name]) return knownPositionRoles[p.name].slice();
  if (Array.isArray(p.positions) && p.positions.length) return p.positions;
  let name = p.name || '',
    hash = 0;
  for (let i = 0; i < name.length; i++) hash = (hash + name.charCodeAt(i) * (i + 3)) % 997;
  let group = p.pos || 'MID';
  if (group === 'GK') return ['GK'];
  let pool =
    group === 'DEF'
      ? ['CB', 'LB', 'RB', 'LWB', 'RWB']
      : group === 'ATT'
        ? ['ST', 'LW', 'RW', 'CF']
        : ['DM', 'CM', 'AM', 'LM', 'RM'];
  let primary = pool[hash % pool.length],
    pairs = {
      CB: ['CB', 'LB'],
      LB: ['LB', 'LWB'],
      RB: ['RB', 'RWB'],
      LWB: ['LWB', 'LB'],
      RWB: ['RWB', 'RB'],
      DM: ['DM', 'CM'],
      CM: ['CM', 'AM'],
      AM: ['AM', 'CM'],
      LM: ['LM', 'LW'],
      RM: ['RM', 'RW'],
      ST: ['ST', 'CF'],
      LW: ['LW', 'ST'],
      RW: ['RW', 'ST'],
      CF: ['CF', 'ST'],
    };
  return pairs[primary] || [primary];
}

function ensureCareerSystems() {
  S.calendar ??= { day: 1, year: 2026 };
  S.trophies ??= [];
  S.retirements ??= [];
  S.shortlist ??= [];
  S.transferApproaches ??= [];
  S.pendingDeals ??= [];
  S.europe ??= { played: 0, points: 0 };
  S.season ??= 1;
  S.negotiations ??= {};
  S.conversationCooldown ??= {};
  S.sacked ??= false;
}

function shortlistToggle(id) {
  ensureCareerSystems();
  let p = S.players.flat().find((x) => x.id === id);
  if (!p) return;
  let has = S.shortlist.some((x) => x.id === id);
  S.shortlist = has
    ? S.shortlist.filter((x) => x.id !== id)
    : [...S.shortlist, { id, name: p.name, club: p.club }];
  persist();
  toast(has ? 'Removed from shortlist.' : 'Added to shortlist.');
  draw();
}

function addEuropeanRound() {
  ensureCareerSystems();
  if (S.week % 4 !== 0 || S.europe.played >= 8) return;
  let opponents = clubs
    .map((c, i) => i)
    .filter((i) => i !== S.club)
    .sort((a, b) => strength(b) - strength(a));
  let opp = opponents[(S.europe.played * 3 + S.club) % opponents.length],
    gf = matchGoals(S.club, opp),
    ga = matchGoals(opp, S.club);
  S.europe.played++;
  if (gf > ga) S.europe.points += 3;
  else if (gf === ga) S.europe.points++;
  S.europe.last = { opp, gf, ga };
  addNews('European night: ' + my().name + ' ' + gf + '–' + ga + ' ' + clubs[opp].name + '.', 'match');
}

function europePage() {
  let e = S.europe || { played: 0, points: 0 };
  return (
    head(
      'Continental football',
      'European competition',
      'European fixtures are scheduled throughout the campaign.',
    ) +
    '<div class="panel"><h3>League phase</h3><p>' +
    e.played +
    ' / 8 played · ' +
    e.points +
    ' points</p><p class="sub">' +
    (e.last
      ? my().name + ' ' + e.last.gf + '–' + e.last.ga + ' ' + clubs[e.last.opp].name
      : 'Your European campaign will begin if you qualify.') +
    '</p></div>'
  );
}

function trophyPage() {
  return (
    head('Club history', 'Trophy cabinet', 'Honours and notable departures from your club.') +
    '<div class="trophy-grid">' +
    ((S.trophies || [])
      .map(
        (t) =>
          '<div class="trophy"><div class="cup">🏆</div><b>' +
          safe(t.name) +
          '</b><span>Season ' +
          t.season +
          ' · ' +
          t.year +
          '</span></div>',
      )
      .join('') || '<div class="empty">Your first trophy is waiting.</div>') +
    '</div><div class="panel" style="margin-top:14px"><h3>Retired legends</h3>' +
    ((S.retirements || [])
      .map(
        (p) =>
          '<div class="row"><b>' +
          safe(p.name) +
          '</b><span>OVR ' +
          p.ovr +
          ' · retired after Season ' +
          p.season +
          '</span></div>',
      )
      .join('') || '<p class="sub">Retired players will be remembered here.</p>') +
    '</div>'
  );
}

function shortlistPage() {
  return (
    head('Recruitment', 'Shortlist', 'Players you are tracking before opening negotiations.') +
    '<div class="panel tablewrap"><table class="tbl"><thead><tr><th>Player</th><th>Club</th><th>Pos</th><th>Rating</th><th></th></tr></thead><tbody>' +
    S.shortlist
      .map((x) => {
        let p = S.players.flat().find((y) => y.id === x.id);
        return p
          ? '<tr><td>' +
              safe(p.name) +
              '</td><td>' +
              safe(p.club) +
              '</td><td>' +
              safe(playerPositions(p).join(' / ')) +
              '</td><td class="rating">' +
              p.r +
              '</td><td><button class="tiny" onclick="startNegotiation(\'' +
              p.id +
              '\')">Negotiate</button> <button class="tiny" onclick="shortlistToggle(\'' +
              p.id +
              '\')">Remove</button></td></tr>'
          : '';
      })
      .join('') +
    '</tbody></table></div>'
  );
}

function unreadCount() {
  return (S?.chats || []).filter((c) => c.incoming && !c.read).length;
}

function inboxPage() {
  return (
    head('Touchline desk', 'Club news', 'Match reports, transfer rumours, results and board updates.') +
    '<div class="news-feed">' +
    ((S.news || []).length
      ? S.news
          .map(
            (n) =>
              '<article class="news-card"><div class="eyebrow">' +
              safe(n.tag || 'CLUB UPDATE') +
              ' · WEEK ' +
              n.week +
              '</div><h3>' +
              safe(n.headline || n.text) +
              '</h3><p>' +
              safe(n.text) +
              '</p><small>Touchline correspondent</small></article>',
          )
          .join('')
      : '<div class="empty">The press room is quiet. News will break as the season unfolds.</div>') +
    '</div>'
  );
}

function finalizeSigning() {
  let n = S.neg,
    p = S.players.flat().find((x) => x.id === S.neg?.id);
  if (!p || !n?.board?.accepted) {
    closeNegotiation();
    toast('The transfer was not approved.');
    return;
  }
  let from = clubs.findIndex((c) => c.name === p.club);
  if (from < 0 || from === S.club) return;
  S.budget -= n.agreed + n.bonus / 1000;
  S.players[from] = S.players[from].filter((x) => x.id !== p.id);
  p.club = my().name;
  p.wage = n.wage;
  p.value = n.agreed;
  p.morale = Math.min(85, (p.morale || 60) + 2);
  S.players[S.club].push(p);
  S.movedPlayers ??= {};
  S.movedPlayers[p.name] = my().name;
  addNews(
    my().name +
      ' completed the signing of ' +
      p.name +
      ' from ' +
      clubs[from].name +
      ' for ' +
      formatM(n.agreed) +
      '.',
    'transfer',
  );
  S.neg = null;
  persist();
  document.querySelector('#negmodal')?.remove();
  draw();
  toast(p.name + ' joins ' + my().name + '.');
}

function submitClubCounter(id) {
  let c = S.chats?.find((x) => x.id === id && x.incoming && (x.kind === 'club' || x.kind === 'loan'));
  if (!c) return;
  let v = +(document.querySelector('#counter-' + CSS.escape(id))?.value || 0);
  if (v <= 0) {
    toast('Enter a valid counteroffer.');
    return;
  }
  c.counter = v;
  c.counterMode = false;
  c.incoming = false;
  c.reply = 'Counteroffer sent to ' + c.club + '. They will respond after reviewing the terms.';
  setTimeout(() => {
    let p = roster().find((x) => x.id === c.playerId);
    if (!p) return;
    if (Math.random() < 0.68) {
      c.reply =
        c.club + ' accepted your counteroffer for ' + p.name + '. Return to Messages to confirm the deal.';
      c.incoming = true;
      c.offer = v;
    } else c.reply = c.club + ' declined your counteroffer for ' + p.name + '.';
    persist();
    if (tab === 'messages') draw();
  }, 1800);
  persist();
  draw();
}

function valueFor(p) {
  let age = p.age || 24,
    r = p.r || 65,
    base = 2.1 * Math.pow(1.18, Math.max(0, r - 65));
  if (p.pot > r && age < 24) base *= 1 + Math.min(0.7, (p.pot - r) * 0.025 + (23 - age) * 0.02);
  if (age > 29) base *= Math.max(0.38, 1 - (age - 29) * 0.075);
  if (p.transferListed) base *= 0.92;
  if (p.lastRating >= 8.2) base *= 1.05;
  return Math.max(0.3, Math.round(base * 10) / 10);
}

function replyToChatBase(id, choice) {
  let c = S.chats?.find((x) => x.id === id && x.incoming);
  if (!c) return;
  let p = roster().find((x) => x.id === (c.kind === 'club' || c.kind === 'loan' ? c.playerId : id));
  if (!p) return;
  if (c.kind === 'club' || c.kind === 'loan') {
    if (choice === 'counter') {
      c.counterMode = true;
      c.text =
        c.club +
        ' offer ' +
        formatM(c.offer) +
        ' for ' +
        p.name +
        '. Estimated value range: ' +
        formatM(c.valueLow) +
        '–' +
        formatM(c.valueHigh) +
        '. Enter your counter price.';
    } else if (choice === 'accept') {
      if (c.kind === 'club') {
        S.players[S.club] = roster().filter((x) => x.id !== p.id);
        let dest = clubs.findIndex((x) => x.name === c.club);
        if (dest >= 0) {
          p.club = c.club;
          S.players[dest].push(p);
          S.movedPlayers ??= {};
          S.movedPlayers[p.name] = c.club;
        }
        S.budget += c.offer;
        addNews(c.club + ' signed ' + p.name + ' for ' + formatM(c.offer) + '.', 'transfer');
      } else {
        p.loanWeeks = (c.loanWeeks || 6) * 4;
        p.loanTo = c.club;
        addNews(c.club + ' agreed a loan for ' + p.name + '.', 'transfer');
      }
      c.incoming = false;
      c.reply =
        'Accepted: ' +
        c.club +
        ' completed the ' +
        (c.kind === 'loan' ? 'loan' : 'transfer') +
        ' for ' +
        p.name +
        '.';
    } else {
      c.incoming = false;
      c.reply = 'Declined: ' + c.club + '’s approach for ' + p.name + ' was turned down.';
    }
  } else {
    if (choice === 'select') {
      selectForNextMatch(id);
      c.reply = 'Added to next match’s starting XI.';
    } else {
      let m = { support: 4, challenge: -3, promise: 1 }[choice] || 0;
      p.morale = Math.max(30, Math.min(85, (p.morale || 55) + m));
      c.reply =
        choice === 'support'
          ? 'You reassured the player.'
          : choice === 'challenge'
            ? 'You challenged the player to earn his place.'
            : 'You promised a fair chance.';
    }
    c.incoming = false;
  }
  persist();
  draw();
}

function roster() {
  return Array.isArray(S?.players?.[Number(S?.club)]) ? S.players[Number(S.club)] : [];
}

function repairApproachClubs() {
  for (let c of S.chats || [])
    if ((c.kind === 'club' || c.kind === 'loan') && !c.club) {
      let choices = clubs.filter((x, i) => i !== S.club);
      c.club = choices[Math.floor(Math.random() * choices.length)]?.name || 'A Premier League club';
      c.name = c.club + ' recruitment team';
      c.text =
        c.kind === 'loan'
          ? c.club +
            ' are interested in taking ' +
            (roster().find((p) => p.id === c.playerId)?.name || 'your player') +
            ' on loan.'
          : c.club +
            ' are interested in signing ' +
            (roster().find((p) => p.id === c.playerId)?.name || 'your player') +
            '. Their opening offer is ' +
            formatM(c.offer || 0) +
            '.';
    }
}

function settleMorale() {
  if (!S?.players) return;
  S.moraleTalkWeek ??= {};
  for (let p of roster()) {
    let m = Number(p.morale ?? 60);
    p.morale = Math.round(Math.max(35, Math.min(80, 60 + (m - 60) * 0.65)));
  }
}

function respondPlayer(encoded, choice) {
  let p = roster().find((x) => x.id === decodeURIComponent(encoded));
  if (!p) return;
  S.moraleTalkWeek ??= {};
  if (S.week - (S.moraleTalkWeek[p.id] || 0) < 3) {
    toast('You have already spoken with ' + p.name + ' recently.');
    document.querySelector('#chatmodal')?.remove();
    return;
  }
  S.moraleTalkWeek[p.id] = S.week;
  p.morale = Math.max(
    35,
    Math.min(78, (p.morale || 58) + (choice === 'encourage' ? 2 : choice === 'promise' ? 1 : -2)),
  );
  S.chats.unshift({
    id: p.id,
    name: p.name,
    week: S.week,
    text:
      'Conversation: ' +
      (choice === 'encourage'
        ? 'You offered support.'
        : choice === 'promise'
          ? 'You promised a fair chance.'
          : 'You asked the player to be patient.'),
    reply: 'Morale adjusted slightly.',
  });
  persist();
  document.querySelector('#chatmodal')?.remove();
  draw();
}

function generateLeagueNews() {
  if (!S || Math.random() > 0.78) return;
  let choices = clubs.map((c, i) => i).filter((i) => i !== S.club);
  if (!choices.length) return;
  let i = choices[Math.floor(Math.random() * choices.length)],
    club = clubs[i],
    st = S.stats?.[i] || { p: 0, w: 0, d: 0, l: 0, pts: 0 },
    types = [];
  if (S.matches?.length) {
    let last = S.matches[S.matches.length - 1];
    types.push({
      headline: club.name + ' keep an eye on the top four',
      text:
        club.name +
        ' are monitoring the European places after ' +
        st.w +
        ' wins from ' +
        st.p +
        ' league matches. Recruitment staff are expected to review the squad before the next window.',
      tag: 'AROUND THE LEAGUE',
    });
    types.push({
      headline: 'Transfer watch: ' + club.name + ' weigh up January options',
      text:
        'Sources close to ' +
        club.name +
        ' say the club is assessing several positions, with no formal bids submitted so far.',
      tag: 'TRANSFER WATCH',
    });
    types.push({
      headline: club.name + ' board expects a response',
      text:
        'The board at ' +
        club.name +
        ' wants to see stronger results after a difficult run. The manager retains the club’s backing for now.',
      tag: 'BOARDROOM',
    });
    types.push({
      headline: club.name + ' secure another league result',
      text:
        club.name +
        ' added to their points tally this week. Attention now turns to the next fixture and squad availability.',
      tag: 'MATCHDAY DESK',
    });
  }
  let n = types[Math.floor(Math.random() * types.length)];
  S.news.unshift({
    week: S.week,
    headline: n.headline,
    text: n.text,
    tag: n.tag,
    type: 'league',
    club: club.name,
  });
  S.news = S.news.slice(0, 40);
}

function messagesPage() {
  repairApproachClubs();
  let chats = S.chats || [];
  chats.forEach((c) => {
    if (c.incoming) c.read = true;
  });
  persist();
  let incoming = chats
    .filter((c) => c.incoming)
    .map((c) => {
      let id = encodeURIComponent(c.id),
        player = roster().find((p) => p.id === c.id),
        asksStart = player && /\b(start|starting|next match|play me|in the team)\b/i.test(c.text || '');
      let controls = '';
      if (c.kind === 'club') {
        controls = c.counterMode
          ? '<label>Counter fee (£m) <input id="counter-' +
            safe(c.id) +
            '" type="number" min="0.1" step="0.1" value="' +
            (c.valueHigh || c.offer) +
            '"></label> <button class="tiny" onclick="submitClubCounter(\'' +
            id +
            '\')">Send counter</button>'
          : '<button class="tiny" onclick="replyToChat(\'' +
            id +
            '\',\'accept\')">Accept</button> <button class="tiny" onclick="replyToChat(\'' +
            id +
            '\',\'counter\')">Counter</button> <button class="tiny" onclick="replyToChat(\'' +
            id +
            "','decline')\">Decline</button>";
      } else if (c.kind === 'loan') {
        controls = c.counterMode
          ? '<label>Loan length (months) <input id="loan-months-' +
            safe(c.id) +
            '" type="number" min="1" max="24" step="1" value="' +
            (c.counterMonths || 6) +
            '"></label> <label>Wage paid by us (%) <input id="loan-wage-' +
            safe(c.id) +
            '" type="number" min="0" max="100" step="5" value="' +
            (c.counterWageShare ?? 50) +
            '"></label> <button class="tiny" onclick="submitLoanCounter(\'' +
            id +
            '\')">Send loan terms</button>'
          : '<button class="tiny" onclick="replyToChat(\'' +
            id +
            '\',\'accept\')">Accept loan</button> <button class="tiny" onclick="replyToChat(\'' +
            id +
            '\',\'counter\')">Counter terms</button> <button class="tiny" onclick="replyToChat(\'' +
            id +
            "','decline')\">Decline</button>";
      } else if (c.kind === 'loan-response') {
        controls =
          '<button class="tiny" onclick="replyToChat(\'' +
          id +
          '\',\'accept\')">Accept terms</button> <button class="tiny" onclick="replyToChat(\'' +
          id +
          '\',\'counter\')">Counter again</button> <button class="tiny" onclick="replyToChat(\'' +
          id +
          "','decline')\">Decline</button>";
      } else {
        controls =
          '<button class="tiny" onclick="replyToChat(\'' +
          id +
          '\',\'support\')">Support</button> <button class="tiny" onclick="replyToChat(\'' +
          id +
          '\',\'challenge\')">Challenge</button> <button class="tiny" onclick="replyToChat(\'' +
          id +
          "','promise')\">Promise a chance</button>" +
          (asksStart
            ? '<button class="tiny" onclick="replyToChat(\'' + id + "','select')\">Add to next XI</button>"
            : '');
      }
      return (
        '<div class="row"><span><b>' +
        safe(c.club || c.name || 'Message') +
        '</b><br>' +
        safe(c.text) +
        (c.kind === 'club' && c.counterMode
          ? '<br>Estimated value: ' + formatM(c.valueLow) + '–' + formatM(c.valueHigh)
          : '') +
        (c.kind === 'loan' && c.counterMode
          ? '<br>Set the loan duration and how much of the wage your club will cover.'
          : '') +
        '</span><span>' +
        controls +
        '</span></div>'
      );
    })
    .join('');
  return (
    head('Clubhouse', 'Messages', 'Player conversations, transfer approaches and club correspondence.') +
    '<div class="panel"><div class="eyebrow">NEEDS YOUR REPLY</div>' +
    (incoming || '<p class="sub">No messages need a reply.</p>') +
    '</div><div class="panel" style="margin-top:14px"><div class="eyebrow">RECENT CONVERSATIONS</div>' +
    (chats
      .filter((c) => !c.incoming)
      .map(
        (c) =>
          '<div class="row"><span><b>' +
          safe(c.club || c.name) +
          '</b><br>' +
          safe(c.reply || c.text) +
          '</span><small>Week ' +
          c.week +
          '</small></div>',
      )
      .join('') || '<p class="sub">New messages will appear here.</p>') +
    '</div>'
  );
}

function replyToChat(id, choice) {
  id = decodeURIComponent(id);
  let c = S.chats?.find((x) => x.id === id && x.incoming);
  if (!c) return;
  if (c.kind === 'loan') {
    let p = roster().find((x) => x.id === c.playerId);
    if (!p) return;
    if (choice === 'counter') {
      c.counterMode = true;
      c.counterMonths = c.loanMonths || 6;
      c.counterWageShare = c.wageShare ?? 50;
      c.text =
        c.club +
        ' request a loan for ' +
        p.name +
        '. Set the length and wage contribution you are prepared to offer.';
    } else if (choice === 'accept') {
      p.loanWeeks = (c.loanMonths || 6) * 4;
      p.loanTo = c.club;
      p.loanWageShare = c.wageShare ?? 50;
      c.incoming = false;
      c.reply =
        'Accepted: ' +
        c.club +
        ' will take ' +
        p.name +
        ' on loan for ' +
        (c.loanMonths || 6) +
        ' months. Your club covers ' +
        (c.wageShare ?? 50) +
        '% of the wage.';
      addNews(c.reply, 'transfer');
    } else {
      c.incoming = false;
      c.reply = 'Declined: ' + c.club + '’s loan approach for ' + p.name + ' was turned down.';
    }
    persist();
    draw();
    return;
  }
  if (c.kind === 'loan-response') {
    let p = roster().find((x) => x.id === c.playerId);
    if (choice === 'accept' && p) {
      p.loanWeeks = (c.loanMonths || 6) * 4;
      p.loanTo = c.club;
      p.loanWageShare = c.wageShare ?? 50;
      c.reply = 'Accepted: ' + c.club + ' will take ' + p.name + ' on loan for ' + c.loanMonths + ' months.';
      addNews(c.reply, 'transfer');
    } else c.reply = 'Declined: the loan terms with ' + c.club + ' were not agreed.';
    c.incoming = false;
    persist();
    draw();
    return;
  }
  if (c.kind === 'player' || (!c.kind && roster().some((p) => p.id === id))) {
    let p = roster().find((x) => x.id === id);
    if (!p) return;
    S.moraleTalkWeek ??= {};
    if (S.week - (S.moraleTalkWeek[id] || 0) < 3) {
      toast('You have already spoken with ' + p.name + ' recently. Give them time to respond.');
      return;
    }
    S.moraleTalkWeek[id] = S.week;
    if (choice === 'select') {
      selectForNextMatch(id);
      c.reply = 'You added ' + p.name + ' to the starting XI for the next match.';
    } else {
      let delta = { support: 2, challenge: -2, promise: 1 }[choice] || 0;
      p.morale = Math.max(35, Math.min(78, (p.morale || 58) + delta));
      c.reply =
        choice === 'support'
          ? 'You offered support and a training plan.'
          : choice === 'challenge'
            ? 'You challenged the player to earn his place.'
            : 'You promised a fair chance, without guaranteeing selection.';
    }
    c.incoming = false;
    persist();
    draw();
    return;
  }
  replyToChatBase(id, choice);
}

function submitLoanCounter(encoded) {
  let id = decodeURIComponent(encoded),
    c = S.chats?.find((x) => x.id === id && x.incoming && x.kind === 'loan');
  if (!c) return;
  let months = Math.max(1, Math.min(24, Number(document.getElementById('loan-months-' + id)?.value) || 6)),
    share = Math.max(0, Math.min(100, Number(document.getElementById('loan-wage-' + id)?.value) || 0));
  c.loanMonths = months;
  c.wageShare = share;
  c.counterMode = false;
  c.incoming = false;
  c.reply =
    'Loan proposal sent to ' +
    c.club +
    ': ' +
    months +
    ' months, with your club covering ' +
    share +
    '% of the wage. They will respond after the next matchday.';
  S.pendingLoanNegotiations ??= [];
  S.pendingLoanNegotiations.push({
    id: c.id,
    club: c.club,
    playerId: c.playerId,
    loanMonths: months,
    wageShare: share,
    resolveWeek: S.week + 1,
  });
  persist();
  draw();
}

function processLoanNegotiations() {
  if (!S?.pendingLoanNegotiations?.length) return;
  let due = S.pendingLoanNegotiations.filter((n) => n.resolveWeek <= S.week);
  S.pendingLoanNegotiations = S.pendingLoanNegotiations.filter((n) => n.resolveWeek > S.week);
  for (let n of due) {
    let original = S.chats.find((c) => c.id === n.id),
      p = roster().find((x) => x.id === n.playerId);
    if (!p || !original) continue;
    let accepts = n.loanMonths <= 12 && n.wageShare >= 25 ? Math.random() < 0.82 : Math.random() < 0.42;
    if (accepts) {
      p.loanWeeks = n.loanMonths * 4;
      p.loanTo = n.club;
      p.loanWageShare = n.wageShare;
      original.reply =
        n.club +
        ' accepted your loan terms for ' +
        p.name +
        ': ' +
        n.loanMonths +
        ' months, with your club covering ' +
        n.wageShare +
        '% of the wage.';
      addNews(original.reply, 'transfer');
    } else {
      original.reply =
        n.club + ' declined your proposed loan terms for ' + p.name + '. No deal was completed.';
    }
    persist();
  }
}

function weeklyWages(i = S.club) {
  return (S.players[i] || []).reduce(
    (sum, p) => sum + (p.wage || wageFor(p)) * (p.loanWeeks > 0 ? (p.loanWageShare ?? 50) / 100 : 1),
    0,
  );
}

function youthNames() {
  return [
    'Noah',
    'Ethan',
    'Mason',
    'Leo',
    'Oscar',
    'Theo',
    'Kai',
    'Luca',
    'Felix',
    'Aiden',
    'Milan',
    'Ruben',
    'Adam',
    'Gabriel',
    'Jude',
    'Ibrahim',
    'Santiago',
    'Mateo',
    'Yusuf',
    'Elias',
    'Rafael',
    'Jonas',
    'Mikkel',
    'Oliver',
    'Finn',
    'Arda',
    'Dario',
    'Amir',
    'Hugo',
    'Nico',
  ];
}

function youthSurnames() {
  return [
    'Bennett',
    'Carter',
    'Mills',
    'Reed',
    'Khan',
    'Silva',
    'Costa',
    'Nielsen',
    'Berg',
    'Hansen',
    'Rossi',
    'Marin',
    'Santos',
    'Okafor',
    'Petrov',
    'Novak',
    'Diallo',
    'Meyer',
    'Walsh',
    'Fischer',
    'Moreau',
    'Ibrahim',
    'Svensson',
    'Lopez',
    'Kovac',
    'Tanaka',
    'Murphy',
    'Clark',
    'Osei',
    'Demir',
  ];
}

function scoutRegions() {
  return [
    'England',
    'Scotland',
    'Wales',
    'Ireland',
    'Spain',
    'Portugal',
    'France',
    'Germany',
    'Netherlands',
    'Belgium',
    'Italy',
    'Brazil',
    'Argentina',
    'West Africa',
    'East Africa',
    'Japan',
    'South Korea',
    'United States',
    'Scandinavia',
  ];
}

function youthRoles() {
  return ['GK', 'CB', 'LB', 'RB', 'DM', 'CM', 'AM', 'LW', 'RW', 'ST'];
}

function randomYouth(team, age = 14) {
  let role = youthRoles()[Math.floor(Math.random() * youthRoles().length)],
    names = clubs[team].name.split(' ')[0],
    id = 'academy-' + team + '-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 7),
    r = 34 + Math.floor(Math.random() * 23),
    pot = Math.max(r + 3, 53 + Math.floor(Math.random() * 39));
  return {
    id,
    name:
      youthNames()[Math.floor(Math.random() * youthNames().length)] +
      ' ' +
      youthSurnames()[Math.floor(Math.random() * youthSurnames().length)],
    age,
    r,
    pot,
    hiddenPot: pot,
    pos: role,
    positions: [role],
    club: names,
    academy: true,
    morale: 62,
    fitness: 100,
    value: 0,
    wage: 0,
    personality: ['Driven', 'Determined', 'Professional', 'Quiet', 'Ambitious'][
      Math.floor(Math.random() * 5)
    ],
  };
}

function ensureYouth() {
  if (!S || !Array.isArray(S.players)) return;
  S.youth ??= clubs.map((_, i) =>
    Array.from({ length: 7 }, () => randomYouth(i, 11 + Math.floor(Math.random() * 8))),
  );
  S.youthScouts ??= [
    { name: 'Alex Harper', rating: 48, wage: 2, hired: false },
    { name: 'Mateo Silva', rating: 68, wage: 5, hired: false },
    { name: 'Erik Lund', rating: 86, wage: 11, hired: false },
  ];
  S.youthTrips ??= [];
  S.scoutCandidates ??= [];
  S.youth.forEach((team, i) => {
    if (!Array.isArray(team)) S.youth[i] = [];
    for (let p of S.youth[i]) {
      p.academy = true;
      p.hiddenPot ??= p.pot || 65;
      p.pot = p.hiddenPot;
      p.positions ??= [p.pos || 'CM'];
      p.pos ??= p.positions[0];
      p.r ??= 38;
      p.age ??= 15;
      p.morale ??= 60;
    }
  });
}

function youthPotentialLabel(p) {
  if (p.age >= 21) return String(p.hiddenPot || p.pot);
  let gap = (p.hiddenPot || p.pot) - p.r;
  return (
    'Est. ' + Math.max(p.r + 2, (p.r + gap * 0.55 - 7) | 0) + '–' + Math.min(99, (p.r + gap * 0.55 + 8) | 0)
  );
}

function academyPage() {
  ensureYouth();
  let team = S.youth[S.club] || [],
    scouts = S.youthScouts || [],
    trips = S.youthTrips || [],
    candidates = S.scoutCandidates || [];
  return (
    head(
      'Clubhouse',
      'Youth academy',
      'Develop prospects, send scouts abroad and decide who earns a first-team contract.',
    ) +
    '<div class="cols"><div class="panel"><div class="panelhead"><h3>Academy players · ' +
    team.length +
    '</h3><span class="muted">Potential becomes clearer after age 20</span></div><div class="tablewrap"><table class="tbl"><thead><tr><th>Player</th><th>Pos</th><th>Age</th><th>OVR</th><th>Potential</th><th>Action</th></tr></thead><tbody>' +
    (team
      .map(
        (p) =>
          '<tr><td><b>' +
          safe(p.name) +
          '</b></td><td>' +
          safe((p.positions || [p.pos]).join(' / ')) +
          '</td><td>' +
          p.age +
          '</td><td>' +
          p.r +
          '</td><td>' +
          youthPotentialLabel(p) +
          '</td><td>' +
          (p.age >= 16
            ? '<button class="tiny" onclick="promoteYouth(\'' +
              encodeURIComponent(p.id) +
              '\')">Offer senior contract</button> '
            : '<span class="muted">Available at 16</span> ') +
          '<button class="tiny" onclick="releaseYouth(\'' +
          encodeURIComponent(p.id) +
          '\')">Release</button></td></tr>',
      )
      .join('') || '<tr><td colspan="6">No academy players right now.</td></tr>') +
    '</tbody></table></div></div><div><div class="panel"><div class="panelhead"><h3>Youth scouting</h3></div><p class="sub">Scouting costs the scout’s weekly wage while they are on assignment. Prospects arrive over the length of the mission.</p><div class="filters"><select id="scout-pick">' +
    scouts
      .map(
        (x, i) =>
          '<option value="' +
          i +
          '">' +
          safe(x.name) +
          ' · ' +
          x.rating +
          '/100 · £' +
          x.wage +
          'k/wk</option>',
      )
      .join('') +
    '</select><select id="scout-region">' +
    scoutRegions()
      .map((x) => '<option>' + x + '</option>')
      .join('') +
    '</select><select id="scout-position"><option>Any position</option>' +
    youthRoles()
      .map((x) => '<option>' + x + '</option>')
      .join('') +
    '</select><select id="scout-duration"><option value="4">4 matchdays</option><option value="8" selected>8 matchdays</option><option value="12">12 matchdays</option></select></div><button class="btn" onclick="startYouthScout()">Assign scout</button><div style="margin-top:12px">' +
    (trips
      .map(
        (t) =>
          '<div class="row"><span>' +
          safe(t.region) +
          ' · ' +
          safe(t.position) +
          ' · ' +
          Math.max(0, t.endWeek - S.week) +
          ' matchdays left</span><b>' +
          t.found +
          '/' +
          t.target +
          '</b></div>',
      )
      .join('') || '<p class="muted">No active scouting missions.</p>') +
    '</div></div><div class="panel" style="margin-top:14px"><div class="panelhead"><h3>Scouts</h3></div>' +
    scouts
      .map(
        (x, i) =>
          '<div class="row"><span><b>' +
          safe(x.name) +
          '</b><br><small>' +
          x.rating +
          '/100 judgement · £' +
          x.wage +
          'k per week</small></span><button class="tiny" onclick="hireYouthScout(' +
          i +
          ')">' +
          (x.hired ? 'Hired' : 'Hire') +
          '</button></div>',
      )
      .join('') +
    '</div></div></div>' +
    (candidates.length
      ? '<div class="panel" style="margin-top:14px"><h3>Scouting reports</h3>' +
        candidates
          .map(
            (p, i) =>
              '<div class="row"><span><b>' +
              safe(p.name) +
              '</b> · ' +
              safe(p.region) +
              ' · ' +
              safe(p.pos) +
              ' · age ' +
              p.age +
              ' · OVR ' +
              p.r +
              ' · ' +
              youthPotentialLabel(p) +
              '</span><button class="tiny" onclick="signYouthCandidate(' +
              i +
              ')">Sign to academy</button></div>',
          )
          .join('') +
        '</div>'
      : '')
  );
}

function hireYouthScout(i) {
  ensureYouth();
  let s = S.youthScouts[i];
  if (!s) return;
  s.hired = true;
  persist();
  draw();
}

function startYouthScout() {
  ensureYouth();
  let i = Number(document.getElementById('scout-pick').value),
    scout = S.youthScouts[i];
  if (!scout?.hired) {
    toast('Hire this scout before assigning a mission.');
    return;
  }
  let duration = Number(document.getElementById('scout-duration').value),
    region = document.getElementById('scout-region').value,
    position = document.getElementById('scout-position').value;
  S.youthTrips.push({
    id: 'trip-' + Date.now(),
    scout: i,
    region,
    position,
    duration,
    startWeek: S.week,
    endWeek: S.week + duration,
    found: 0,
    target: 2 + Math.floor(Math.random() * 3),
    nextReport: S.week + Math.max(1, Math.floor(duration / 3)),
  });
  addNews(
    scout.name + ' has started a ' + duration + '-matchday scouting mission in ' + region + '.',
    'academy',
  );
  persist();
  draw();
}

function promoteYouth(encoded) {
  ensureYouth();
  let id = decodeURIComponent(encoded),
    i = S.youth[S.club].findIndex((p) => p.id === id),
    p = S.youth[S.club][i];
  if (!p || p.age < 16) return toast('Players can sign a senior contract from age 16.');
  p.academy = false;
  p.club = my().name;
  p.value = valueFor(p);
  p.wage = wageFor(p);
  p.morale = 65;
  S.players[S.club].push(p);
  S.youth[S.club].splice(i, 1);
  addNews(p.name + ' has signed a first-team contract with ' + my().name + '.', 'academy');
  persist();
  draw();
}

function releaseYouth(encoded) {
  ensureYouth();
  let id = decodeURIComponent(encoded),
    p = S.youth[S.club].find((x) => x.id === id);
  if (!p) return;
  S.youth[S.club] = S.youth[S.club].filter((x) => x.id !== id);
  addNews(p.name + ' has been released from the academy.', 'academy');
  persist();
  draw();
}

function signYouthCandidate(i) {
  ensureYouth();
  let p = S.scoutCandidates[i];
  if (!p) return;
  S.scoutCandidates.splice(i, 1);
  p.academy = true;
  p.club = my().name;
  S.youth[S.club].push(p);
  addNews(
    'Academy recruitment: ' + p.name + ' has joined ' + my().name + ' after a scouting mission.',
    'academy',
  );
  persist();
  draw();
}

function advanceYouthDay() {
  ensureYouth();
  for (let ci = 0; ci < 20; ci++)
    for (let p of S.youth[ci]) {
      let gain = (0.08 + Math.random() * 0.15) * (p.personality === 'Driven' ? 1.2 : 1);
      p.r = Math.min(p.hiddenPot, p.r + gain);
      p.r = Math.round(p.r * 10) / 10;
    }
  for (let t of [...S.youthTrips]) {
    let scout = S.youthScouts[t.scout];
    if (!scout) continue;
    let progress = (S.week - t.startWeek) / Math.max(1, t.duration);
    while (t.found < t.target && (S.week >= t.nextReport || S.week >= t.endWeek)) {
      let quality = Math.random() < scout.rating / 100,
        age = 14 + Math.floor(Math.random() * 4),
        p = randomYouth(S.club, age),
        wanted = t.position === 'Any position' || p.pos === t.position;
      p.region = t.region;
      p.pos = wanted ? p.pos : t.position;
      p.positions = [p.pos];
      p.r = quality ? 42 + Math.floor(Math.random() * 24) : 34 + Math.floor(Math.random() * 18);
      p.hiddenPot = Math.min(
        99,
        p.r + (quality ? 18 + Math.floor(Math.random() * 28) : 4 + Math.floor(Math.random() * 23)),
      );
      p.pot = p.hiddenPot;
      p.name =
        youthNames()[Math.floor(Math.random() * youthNames().length)] +
        ' ' +
        youthSurnames()[Math.floor(Math.random() * youthSurnames().length)];
      S.scoutCandidates.push(p);
      t.found++;
      addNews(
        'Scout report from ' +
          t.region +
          ': ' +
          p.name +
          ' (' +
          p.pos +
          ') has been identified as a prospect.',
        'academy',
      );
      t.nextReport += Math.max(1, Math.floor(t.duration / Math.max(1, t.target)));
    }
    if (S.week >= t.endWeek) {
      addNews(scout.name + ' has completed scouting in ' + t.region + '.', 'academy');
      S.youthTrips = S.youthTrips.filter((x) => x !== t);
    }
  }
  for (let ci = 0; ci < 20; ci++)
    if (ci !== S.club)
      for (let p of [...S.youth[ci]])
        if (p.age >= 16 && p.r >= 58 && Math.random() < 0.012) {
          p.academy = false;
          p.club = clubs[ci].name;
          p.value = valueFor(p);
          p.wage = wageFor(p);
          S.players[ci].push(p);
          S.youth[ci].splice(S.youth[ci].indexOf(p), 1);
        }
  if (S.club >= 0)
    S.budget -= S.youthScouts.filter((x) => x.hired).reduce((sum, x) => sum + x.wage / 1000, 0);
}

function stopAutoManager() {
  S && (S.autoManager = false);
  if (window.__autoManagerTimer) {
    clearInterval(window.__autoManagerTimer);
    window.__autoManagerTimer = null;
  }
  if (document.querySelector('#modal')) {
    document.querySelector('#modal')?.remove();
    window.__touchlineMatchLock = false;
  }
}



function autoHandlePlayerMessages() {
  if (!S?.autoManager) return;
  for (let c of (S.chats || []).filter((x) => x.incoming && (x.kind === 'player' || !x.kind))) {
    let p = roster().find((x) => x.id === c.id);
    if (!p) continue;
    let asksStart = /\b(start|starting|next match|play me|ready for the next match)\b/i.test(c.text || '');
    if (asksStart) {
      S.lineupIds = autoEleven(S.club).map((x) => x.id);
      c.reply = 'Co-manager response: You are in the starting XI for the next match.';
      p.morale = Math.min(78, (p.morale || 58) + 1);
    } else {
      c.reply = 'Co-manager response: The manager has listened and offered support.';
      p.morale = Math.min(78, (p.morale || 58) + 1);
    }
    c.incoming = false;
    c.read = true;
  }
  persist();
}

function toggleAutoManager() {
  if (!S) return;
  S.autoManager = !S.autoManager;
  if (S.autoManager) {
    autoHandlePlayerMessages();
    toast(
      'Co-manager is handling the team and player conversations. Click Stop co-manager to take control back.',
    );
    if (window.__autoManagerTimer) clearInterval(window.__autoManagerTimer);
    window.__autoManagerTimer = setInterval(() => {
      if (!S || !S.autoManager || S.seasonEnded || S.sacked) {
        stopAutoManager();
        return;
      }
      autoHandlePlayerMessages();
      if (window.__touchlineMatchLock || document.querySelector('#modal')) return;
      S.lineupIds = autoEleven(S.club).map((p) => p.id);
      persist();
      play(null, 'quick');
    }, 1400);
  } else stopAutoManager();
  draw();
}

function getCurrentManager(club) {
  return (
    {
      Arsenal: 'Mikel Arteta',
      'Aston Villa': 'Unai Emery',
      Bournemouth: 'Marco Rose',
      Brentford: 'Keith Andrews',
      Brighton: 'Fabian Hürzeler',
      Chelsea: 'Xabi Alonso',
      'Crystal Palace': 'Pierre Sage',
      Everton: 'David Moyes',
      Fulham: 'Álvaro Arbeloa',
      'Hull City': 'Sergej Jakirović',
      'Ipswich Town': 'Gary O’Neil',
      'Leeds United': 'Daniel Farke',
      Liverpool: 'Andoni Iraola',
      'Manchester City': 'Enzo Maresca',
      'Manchester United': 'Michael Carrick',
      'Newcastle United': 'Matthias Jaissle',
      'Nottingham Forest': 'Oliver Glasner',
      Sunderland: 'Régis Le Bris',
      'Tottenham Hotspur': 'Roberto De Zerbi',
      'West Ham United': 'Nuno Espírito Santo',
    }[club] || 'Manager'
  );
}

function seasonEnd() {
  if (!S || S.week <= 38 || S.seasonEnded) return;
  ensureYouth();
  let stats = S.stats[S.club],
    rank =
      1 +
      S.stats.filter(
        (x, i) =>
          x.pts > stats.pts ||
          (x.pts === stats.pts &&
            (x.gf - x.ga > stats.gf - stats.ga || (x.gf - x.ga === stats.gf - stats.ga && x.gf > stats.gf))),
      ).length,
    reward = Math.max(5, 60 - (rank - 1) * 2) + (S.europe?.points || 0) * 1.2;
  S.budget += reward;
  S.boardApproval = Math.max(
    35,
    Math.min(
      100,
      (S.boardApproval || 60) + (rank <= 4 ? 18 : rank <= 6 ? 13 : rank <= 10 ? 6 : rank >= 18 ? -8 : 0),
    ),
  );
  updateClubFortunes();
  S.champions ??= [];
  {
    let order = leagueOrder(),
      all = S.players.flat().filter((p) => p.st?.app),
      gb = [...all].sort((a, b) => b.st.g - a.st.g)[0],
      pots = all.filter((p) => p.st.rn >= 20).sort((a, b) => avgRating(b) - avgRating(a))[0],
      yng = all.filter((p) => p.age <= 21 && p.st.rn >= 15).sort((a, b) => avgRating(b) - avgRating(a))[0];
    S.champions.push({
      season: S.season || 1,
      champion: clubs[order[0].i].name,
      pts: order[0].pts,
      mine: rank,
      boot: gb ? gb.name + ' (' + gb.st.g + ')' : '',
      best: pots ? pots.name : '',
      young: yng ? yng.name : '',
    });
  }
  S.seasonHistory ??= [];
  S.seasonHistory.push({ season: S.season || 1, rank, record: { ...stats }, approval: S.boardApproval });
  let award =
    rank === 1
      ? 'Premier League champions'
      : rank <= 4
        ? 'European qualification secured'
        : rank >= 18
          ? 'Relegated'
          : 'Season complete';
  if (rank === 1)
    S.trophies.unshift({ name: 'Premier League', season: S.season || 1, year: S.calendar?.year || 2026 });
  if (S.europe?.played >= 8 && S.europe.points >= 15)
    S.trophies.unshift({ name: 'European Cup', season: S.season || 1, year: S.calendar?.year || 2026 });
  S.news.unshift({
    week: 38,
    headline: award,
    text:
      'The season is over. ' +
      my().name +
      ' finished ' +
      rank +
      (rank === 1 ? 'st' : rank === 2 ? 'nd' : rank === 3 ? 'rd' : 'th') +
      ' and received ' +
      formatM(reward) +
      ' in prize and board funds.',
    tag: 'SEASON REVIEW',
    type: 'board',
  });
  S.seasonEnded = true;
  S.lastSeasonRank = rank;
  for (let p of S.youth[S.club]) {
    p.age = Math.min(21, p.age + 1);
    p.r = Math.min(p.hiddenPot, Math.round((p.r + 0.8) * 10) / 10);
  }
  for (let ci = 0; ci < 20; ci++)
    if (ci !== S.club) for (let p of S.youth[ci]) p.age = Math.min(21, p.age + 1);
  persist();
}

function updateBoardAfterMatch(result) {
  let st = S.stats[S.club],
    rank =
      1 +
      S.stats.filter(
        (x, i) =>
          x.pts > st.pts ||
          (x.pts === st.pts &&
            (x.gf - x.ga > st.gf - st.ga || (x.gf - x.ga === st.gf - st.ga && x.gf > st.gf))),
      ).length,
    expected = my().budget >= 85 ? 5 : my().budget >= 65 ? 8 : my().budget >= 48 ? 12 : 16;
  let delta = result === 'W' ? 2.6 : result === 'D' ? 0.35 : -1.45;
  if (S.week >= 6) {
    if (rank <= 3) delta += 0.45;
    else if (rank <= 6) delta += 0.2;
    else if (rank > expected) delta -= Math.min(0.65, 0.08 + (rank - expected) * 0.045);
    if (rank >= 17) delta -= 0.2;
  }
  if (weeklyWages() > my().budget * 34) delta -= 0.35;
  if (S.budget < 0) delta -= 0.3;
  S.boardApproval = Math.max(0, Math.min(100, (S.boardApproval ?? 68) + delta));
  if (S.boardApproval < 45 && S.boardApproval >= 20)
    addNews(
      'Board confidence is under pressure. The chair expects an improved run over the coming weeks.',
      'board',
    );
  if (S.boardApproval < 20 && S.week > 10) {
    S.boardWarnings = (S.boardWarnings || 0) + 1;
    if (S.boardWarnings >= 4) {
      S.sacked = true;
      addNews(
        'The board has dismissed the manager after repeated warnings and a prolonged run of poor results.',
        'board',
      );
    }
  } else if (S.boardApproval >= 20) S.boardWarnings = 0;
}

function startNextSeason() {
  if (!S?.seasonEnded) return;
  S.season = (S.season || 1) + 1;
  S.week = 1;
  S.stats = Array.from({ length: 20 }, () => ({ p: 0, w: 0, d: 0, l: 0, gf: 0, ga: 0, pts: 0 }));
  S.matches = [];
  S.results = {};
  S.seasonEnded = false;
  S.last = null;
  fixtureWeek = 0;
  let report = developPlayers();
  S.devReport = report;
  for (let ci = 0; ci < 20; ci++) {
    let team = S.youth[ci];
    for (let p of [...team])
      if (ci !== S.club && p.age >= 16 && p.r >= 50 && Math.random() < 0.5) {
        p.academy = false;
        p.club = clubs[ci].name;
        p.value = valueFor(p);
        p.wage = wageFor(p);
        S.players[ci].push(p);
        team.splice(team.indexOf(p), 1);
      }
    while (team.length < 6) team.push(randomYouth(ci, 11 + Math.floor(Math.random() * 8)));
  }
  /* every AI club keeps at least three goalkeepers */
  for (let ci = 0; ci < 20; ci++) {
    if (ci === S.club) continue;
    for (let tries = 0; tries < 60 && S.players[ci].filter((p) => p.pos === 'GK').length < 3; tries++) {
      let y = randomYouth(ci, 19);
      if (y.pos !== 'GK') continue;
      y.academy = false;
      y.r = 60 + Math.floor(Math.random() * 8);
      y.pot = y.r + 6;
      y.club = clubs[ci].name;
      y.value = valueFor(y);
      y.wage = wageFor(y);
      S.players[ci].push(y);
    }
  }
  /* AI clubs keep a sensible squad size: the weakest, oldest surplus players leave. */
  for (let ci = 0; ci < 20; ci++) {
    if (ci === S.club) continue;
    let t = S.players[ci];
    while (t.length > 26) {
      let gks = t.filter((p) => p.pos === 'GK').length,
        worth = (p) => p.r + (p.pot - p.r) * 0.4 - Math.max(0, p.age - 29) * 0.6,
        out = t.filter((p) => p.pos !== 'GK' || gks > 3).sort((x, y) => worth(x) - worth(y))[0];
      if (!out) break;
      t.splice(t.indexOf(out), 1);
    }
  }
  aiTransfers('summer', 3);
  S.europe = { played: 0, points: 0 };
  S.lineupIds = autoEleven().map((p) => p.id);
  let bits = [];
  if (report.risers.length) bits.push('Rising: ' + report.risers.slice(0, 3).map((x) => x.name + ' ' + x.from + '→' + x.to).join(', '));
  if (report.fallers.length) bits.push('Declining: ' + report.fallers.slice(0, 3).map((x) => x.name + ' ' + x.from + '→' + x.to).join(', '));
  addNews('Pre-season begins. The board expects a ' + boardTarget() + ' this season.', 'board');
  if (bits.length) addNews('Summer development. ' + bits.join(' · ') + '.', 'club');
  persist();
  tab = 'home';
  draw();
  window.scrollTo(0, 0);
}
