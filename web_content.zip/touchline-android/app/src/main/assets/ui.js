/* =====================================================================
   TOUCHLINE · APP SHELL
   Navigation (sidebar on desktop, bottom tabs on phones), page routing,
   start screen, season review, error safety net and boot.
   ===================================================================== */

const TAB_TITLES = {
  home: 'Overview', squad: 'Squad', tactics: 'Team & tactics', fixtures: 'Fixtures', table: 'League table', stats: 'League stats',
  market: 'Transfers', shortlist: 'Shortlist', youth: 'Youth academy', messages: 'Messages', inbox: 'News', players: 'Players',
  europe: 'Europe', trophies: 'Trophy cabinet', settings: 'Settings',
};
const NAV_LABEL = { tactics: 'Team', table: 'Table', market: 'Transfers', youth: 'Academy', trophies: 'Trophies', inbox: 'News' };
const NAV_GROUPS = [
  ['Club', ['home', 'squad', 'tactics', 'fixtures', 'table', 'stats']],
  ['Recruitment', ['market', 'shortlist', 'youth']],
  ['Clubhouse', ['messages', 'inbox', 'players', 'europe', 'trophies']],
];
const BOTTOM_TABS = ['home', 'squad', 'tactics', 'table'];
const PAGES = {
  home: () => home(),
  squad: () => squadView(),
  tactics: () => tactics(),
  fixtures: () => fixturesPage(),
  table: () => tableView(),
  stats: () => statsPage(),
  market: () => market(),
  shortlist: () => shortlistPage(),
  youth: () => academyPage(),
  messages: () => messagesPage(),
  inbox: () => inboxPage(),
  players: () => playersPage(),
  europe: () => europePage(),
  trophies: () => trophyPage(),
  settings: () => settingsPage(),
};
let moreOpen = false,
  lastTab = null;

function navBtn(id, cls = 'navbtn') {
  let badge = id === 'messages' && S && unreadCount() ? '<em class="dot">' + unreadCount() + '</em>' : '';
  return (
    '<button class="' + cls + (tab === id ? ' on' : '') + '" onclick="go(\'' + id + '\')">' + icon(id) + '<span>' + (NAV_LABEL[id] || TAB_TITLES[id]) + '</span>' + badge + '</button>'
  );
}
function go(t) {
  if (!S) return;
  tab = t;
  moreOpen = false;
  lineupSel = null;
  draw();
  window.scrollTo(0, 0);
}
function toggleMore() {
  moreOpen = !moreOpen;
  draw();
}

function shell(body) {
  let place = rankOf(S.club),
    approval = Math.round(S.boardApproval ?? 70),
    inMore = !BOTTOM_TABS.includes(tab);
  return (
    '<div class="app"><aside class="side"><div class="brand"><span class="mark">T</span>TOUCHLINE</div>' +
    NAV_GROUPS.map(([label, ids]) => '<div class="grp"><div class="label">' + label + '</div><nav class="nav">' + ids.map((i) => navBtn(i)).join('') + '</nav></div>').join('') +
    '<div class="club"><div class="club-top">' + clubBadge(S.club, 'lg') + '<div><b>' + safe(my().name) + '</b><small>' + ordinal(place) + ' · ' + S.stats[S.club].pts + ' pts</small></div></div>' +
    '<div class="cash"><span>Transfer budget</span><b>' + formatM(S.budget) + '</b></div><div class="cash"><span>Board approval</span><b>' + approval + '%</b></div></div>' +
    '<div class="side-foot">' + navBtn('settings') + '</div></aside>' +
    '<main class="main"><header class="top"><div class="top-l"><span class="mark sm">T</span><b>' + TAB_TITLES[tab] + '</b></div><div class="top-r"><span class="chip-i">Season ' + (S.season || 1) +
    ' · Week ' + Math.min(38, S.week) + '</span><span class="chip-i hide-sm">' + icon('players') + safe(S.manager || 'Manager') + '</span><button class="iconbtn" onclick="go(\'messages\')" aria-label="Messages">' + icon('messages') +
    (unreadCount() ? '<em class="dot">' + unreadCount() + '</em>' : '') + '</button></div></header><div class="content" id="content">' + body + '</div></main>' +
    '<nav class="bottom">' + BOTTOM_TABS.map((i) => navBtn(i, 'tab')).join('') + '<button class="tab' + (inMore || moreOpen ? ' on' : '') + '" onclick="toggleMore()">' + icon('more') + '<span>More</span></button></nav>' +
    (moreOpen
      ? '<div class="sheet-bg" onclick="toggleMore()"></div><div class="sheet"><div class="sheet-grid">' +
        ['fixtures', 'stats', 'market', 'shortlist', 'youth', 'messages', 'inbox', 'players', 'europe', 'trophies', 'settings'].map((i) => navBtn(i, 'gridbtn')).join('') +
        '</div></div>'
      : '') +
    '</div>'
  );
}

function draw() {
  let root = document.querySelector('#root');
  if (!S) {
    root.innerHTML = start();
    return;
  }
  ensureCareerSystems();
  let y = window.scrollY,
    same = lastTab === tab,
    body;
  try {
    body = S.sacked ? sackedPage() : S.seasonEnded && tab === 'home' ? seasonEndPage() : (PAGES[tab] || PAGES.home)();
    root.innerHTML = shell(body);
  } catch (e) {
    console.error(e);
    root.innerHTML = shell(
      '<div class="panel"><h3>Something went wrong on this page</h3><p class="sub">' + safe(e?.message || e) + '</p><button class="btn" onclick="go(\'home\')">Back to overview</button></div>',
    );
  }
  lastTab = tab;
  if (same) window.scrollTo(0, y);
}

/* ---------- start screen ---------- */
function startRating(i) {
  let list = clubs[i].players.filter((p) => !p.young).concat((realismExtras[i] || []).map((x) => ({ r: x[2] })));
  list.sort((a, b) => b.r - a.r);
  return Math.round(list.slice(0, 11).reduce((s, p) => s + p.r, 0) / 11);
}
function start() {
  let hasSave = false;
  return (
    '<div class="startwrap"><div class="startbox"><div class="brand big"><span class="mark">T</span>TOUCHLINE</div><h1>Build your football story.</h1><p class="sub">Choose a Premier League club. Pick your XI, set your tactics, buy and sell, and chase the title across seasons.</p>' +
    '<label class="field"><span>Your name</span><input id="mgr" maxlength="28" placeholder="Alex Morgan" autocomplete="off"></label><div class="label">CHOOSE YOUR CLUB</div><div class="clubs">' +
    clubs
      .map((c, i) => {
        let r = startRating(i),
          tier = c.budget >= 95 ? 'Title contenders' : c.budget >= 75 ? 'European hopefuls' : c.budget >= 55 ? 'Mid-table' : 'Fighting for survival';
        return (
          '<button class="pick" onclick="begin(' + i + ',document.getElementById(\'mgr\').value)">' + clubBadge(i, 'lg') + '<span class="pk"><b>' + safe(c.name) + '</b><small>' + tier + ' · ' + formatM(c.budget) + (c.manager ? ' · now ' + safe(c.manager) : '') +
          '</small></span><span class="pr" title="First-team rating">' + r + '</span></button>'
        );
      })
      .join('') +
    '</div><p class="muted">2026/27 · Ratings and values are game estimates. <label class="link filebtn">Load a save file<input type="file" accept="application/json,.json" hidden onchange="importSave(this)"></label></p></div></div>'
  );
}

/* ---------- season review & dismissal ---------- */
function seasonEndPage() {
  let rank = S.lastSeasonRank || rankOf(S.club),
    st = S.stats[S.club],
    order = leagueOrder(),
    champ = order[0],
    scorer = S.players.flat().filter((p) => p.st?.g).sort((a, b) => b.st.g - a.st.g)[0],
    mine = roster().filter((p) => p.st?.app).sort((a, b) => b.st.g - a.st.g)[0],
    title = rank === 1 ? 'Champions!' : rank <= 4 ? 'Europe secured' : rank >= 18 ? 'A season to forget' : 'Season complete',
    dev = S.devReport,
    lastAw = (S.champions || []).slice(-1)[0];
  return (
    head('Season ' + (S.season || 1) + ' review', title, 'Final position: ' + ordinal(rank) + ' · prize money and board funds awarded.') +
    '<div class="cards"><div class="stat"><small>FINISHED</small><strong>' + ordinal(rank) + '</strong><span>' + st.pts + ' points</span></div><div class="stat"><small>RECORD</small><strong>' + st.w + '-' + st.d + '-' + st.l +
    '</strong><span>' + st.gf + ' for · ' + st.ga + ' against</span></div><div class="stat"><small>CHAMPIONS</small><strong style="font-size:17px">' + safe(clubs[champ.i].name) + '</strong><span>' + champ.pts +
    ' points</span></div><div class="stat"><small>BOARD APPROVAL</small><strong>' + Math.round(S.boardApproval) + '%</strong><span>After the season</span></div></div><div class="cols"><div class="panel"><h3>Season awards</h3>' +
    (scorer ? '<div class="row"><span>👟 Golden Boot</span><b>' + safe(scorer.name) + ' · ' + scorer.st.g + '</b></div>' : '') + (lastAw?.best ? '<div class="row"><span>⭐ Player of the season</span><b>' + safe(lastAw.best) + '</b></div>' : '') + (lastAw?.young ? '<div class="row"><span>🌱 Young player of the season</span><b>' + safe(lastAw.young) + '</b></div>' : '') + (mine ? '<div class="row"><span>⚽ Your top scorer</span><b>' + safe(mine.name) + ' · ' + mine.st.g + '</b></div>' : '') +
    '</div><div class="panel"><h3>Next season</h3><p class="sub">Players age and develop over the summer. Young talents grow towards their potential, veterans decline, and some retire. Fitness resets for everyone.</p><button class="btn" onclick="startNextSeason()">Start season ' +
    ((S.season || 1) + 1) + ' →</button></div></div>'
  );
}
function sackedPage() {
  let d = S.dismissalReport || {},
    r = d.record || S.stats[S.club] || { w: 0, d: 0, l: 0 },
    c = S.careerStats || { matches: S.matches?.length || 0, wins: 0, draws: 0, losses: 0 },
    reasons = d.reasons?.length ? d.reasons : ['A prolonged loss of board confidence led to your dismissal.'];
  return (
    '<div class="panel" style="max-width:820px;margin:auto"><div class="eyebrow">CAREER REVIEW · DISMISSED</div><h1>Managerial spell ended</h1><p>The board at ' + safe(d.club || my().name) + ' dismissed you in week ' + (d.week || S.week) +
    '. Final confidence: ' + (d.approval ?? Math.round(S.boardApproval || 0)) + '%.</p><h3>Reasons</h3>' + reasons.map((x) => '<div class="row">• ' + safe(x) + '</div>').join('') +
    '<h3 style="margin-top:20px">Career statistics</h3><div class="cards"><div class="stat"><small>MATCHES</small><strong>' + c.matches + '</strong></div><div class="stat"><small>WINS</small><strong>' + c.wins + '</strong></div><div class="stat"><small>DRAWS</small><strong>' + c.draws +
    '</strong></div><div class="stat"><small>LOSSES</small><strong>' + c.losses + '</strong></div></div><p>League record: ' + r.w + ' wins, ' + r.d + ' draws, ' + r.l + ' losses' + (d.position ? ' · ' + ordinal(d.position) : '') +
    '.</p><button class="btn" onclick="startNewCareer()">Start a new career</button></div>'
  );
}

/* ---------- Android back button / escape key ---------- */
window.touchlineBack = function () {
  let neg = document.querySelector('#negmodal,#chatmodal');
  if (neg) {
    neg.remove();
    return true;
  }
  if (document.querySelector('#modal')) {
    if (window.__liveMatchTimer) finishLiveMatch();
    else closeMatch();
    return true;
  }
  if (moreOpen) {
    toggleMore();
    return true;
  }
  if (S && tab !== 'home') {
    go('home');
    return true;
  }
  return false;
};
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') window.touchlineBack();
});

/* ---------- boot ---------- */
function boot() {
  applyTheme();
  try {
    migrateSave();
  } catch (e) {
    console.error('Save could not be migrated', e);
  }
  draw();
  if (S) persist();
}
boot();
