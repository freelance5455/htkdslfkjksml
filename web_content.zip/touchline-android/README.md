# Touchline — Android project

The Android app is a thin shell (`MainActivity.java`) that shows the web game stored in `app/src/main/assets/`.
**To change the game, edit the files in `assets/`** (they are identical to the `touchline-web` folder).

## Build
1. Open this folder in Android Studio and let Gradle sync.
2. Run on a phone/emulator, or use *Build → Generate Signed Bundle / APK* for a release build.
(This project keeps your original Gradle versions: AGP 8.6.1, compileSdk/targetSdk 35, minSdk 23.)

## What's new in the app shell (version 2.0)
- Fits Android 15's edge-to-edge screens (the game no longer sits under the status bar or gesture bar).
- Back button closes pop-ups and returns to the Overview; only exits from the Overview.
- Rotating the phone no longer restarts the game (a live match keeps going).
- Career is saved whenever the app leaves the screen.
- Export / import save files through the normal Android file picker.
- Links open in the browser; the app no longer asks for the INTERNET permission (fully offline).
- Launcher icon added.

Your original signing key (`touchline-release.jks`) is not included here — keep using your own copy to sign updates so they install over the old version.
