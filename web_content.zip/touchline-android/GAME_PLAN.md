# Touchline — what changed and what's next

## What I changed
**Web version (new structure)**
- The old `realism.js` was a pile of patches layered on top of each other (the last definition silently won). I flattened it into one clean set of files and removed the dead code.
- Split into `data.js`, `engine.js`, `realism.js`, `pages.js`, `ui.js`, `style.css`, so each thing lives in one place.
- New phone-first design: bottom tab bar on phones, sidebar on desktop, light/dark/auto theme, club-coloured badges, readable on 360px screens.

**Game improvements**
- One match engine for every game (all 380 league matches per season), based on each team's goalkeeper/defence/midfield/attack ratings, fitness, morale, formation, style and focus. Goals are random but fair; stronger squads win more over a season.
- AI clubs now use their own formations (before, they copied yours).
- Players out of position are penalised; players who can play two positions are handled properly.
- Smart rotation: tired or injured starters are swapped automatically (can be switched off).
- Tap-to-swap lineup editing (the old drag-and-drop didn't work on phones).
- Player development: young players grow, older players decline and retire each season; AI clubs refill from their academies and keep at least 3 goalkeepers.
- Match report: possession, shots, xG, ratings, man of the match, cards, injuries, 3 substitutions.
- Settings: theme, export / import save, new career.

**Android app**
- Fits edge-to-edge screens, proper back button, rotation no longer restarts the game, auto-save when you leave, save export/import through the Android file picker, no INTERNET permission, launcher icon.

## Update 2 — managers, crests, AI transfers
- **Real managers:** every club shows its current head coach (2026/27, from Sky Sports and Wikipedia lists) on the club-pick screen, the next-match card and the match scoreboard.
- **Crests:** each club has its own original shield badge (club colours, pattern, 3-letter code). These are *not* the official crests: those are trademarked and I can't download them here. To use real images you have the rights to, put `ARS.png`, `AVL.png` ... in a `crests/` folder next to `index.html` and set `USE_CREST_IMAGES = true` at the top of the badge code in `pages.js`.
- **AI transfers:** a summer window (up to 3 deals per club) and a January window (1 per club). Clubs buy to fix their weakest position, pay fees (richer clubs can pay more), key players aren't sold, squads stay 21–27. The biggest deals appear in the News feed. League balance is unchanged by this (champion still ~85 pts on average).

## Update 3 — dragging and more game depth
- **Drag & drop lineup:** drag a player onto another to swap; drag a substitute onto a starter to bring him on. Mouse works instantly; on a phone press and hold a player for a moment, then drag (so scrolling still works). Tapping to swap still works too.
- **Team talk:** choose Motivate / Stay calm / Demand more before a match; it changes morale (Demand more backfires on tired players).
- **Difficulty:** Easy / Normal / Hard in Settings (small edge for or against your club in every match).
- **Club fortunes:** clubs that finish high gain transfer money over the years, struggling clubs lose it, so the transfer market changes over a long career.
- **League history & awards:** each season records the champion, Golden Boot, Player of the Season and Young Player; shown on the Stats page and the season review.
- **League transfers feed:** the Stats page lists the latest AI-club deals.

## How the match engine works (plain English)
1. Each team gets four scores (GK, defence, midfield, attack) from its starting XI, reduced for tiredness and playing out of position.
2. Attack vs the other side's defence (mostly), plus midfield and overall strength, gives an "expected goals" number. Home sides get a boost.
3. Tactics nudge that number up or down (attacking style, high line, etc.).
4. Goals are drawn randomly from that number; scorers and assists are picked by position and rating.
5. Tuning knobs are in `ENGINE` at the top of `engine.js` (`base` = goals per game, `k` = how much quality matters).

Test results: a top-rated squad finishes around 65 points on average, the champion about 73; 8-season runs were stable.

## Known limits
- The Android app could not be compiled here (no Android SDK). Please build in Android Studio; the Java is untested.
- The same few big clubs tend to win (AI clubs don't trade players).
- European competition is simple; there is no promotion/relegation or other leagues.
- The squad table's sort buttons are cosmetic.

## Roadmap (best value first)
1. **Changing fortunes** — AI transfers are in; next, club finances/ambition so small clubs can rise over many seasons and Man City/Arsenal don't keep winning.
2. **Promotion & relegation** with a second division, so staying up matters.
3. **Cups** (FA Cup / League Cup) for variety and rotation decisions.
4. **Set pieces & player roles** (e.g. target man, playmaker) in tactics.
5. **Staff & training** (coaches improve specific players; scouts reveal potential).
6. **Match highlights** with a minute-by-minute commentary feed.
7. **Multiple save slots** and difficulty levels.
8. **Real names/licences** — keep ratings as estimates; check licensing before publishing publicly.
