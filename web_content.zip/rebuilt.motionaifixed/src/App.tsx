import React, { useState, useEffect } from 'react';
import { AppTab, EditorClip, TimelineTrack } from './types';
import { Header } from './components/Header';
import { CreateStudio } from './components/CreateStudio';
import { CapCutEditor } from './components/editor/CapCutEditor';
import { VideoGenStudio } from './components/VideoGenStudio';
import { ImageGenerationStudio } from './components/ImageGenerationStudio';
import { ImageToVideoStudio } from './components/ImageToVideoStudio';
import { AutoDescribeStudio } from './components/AutoDescribeStudio';
import { BatchProcessingStudio } from './components/BatchProcessingStudio';
import { LibraryStudio } from './components/LibraryStudio';
import { BusinessStudio } from './components/BusinessStudio';
import { CompetitorComparisonStudio } from './components/CompetitorComparisonStudio';
import { AndroidExportStudio } from './components/AndroidExportStudio';
import { ProfileStudio } from './components/ProfileStudio';
import { BottomNavBar } from './components/BottomNavBar';
import { MetaTagsModal } from './components/MetaTagsModal';
import { INITIAL_TRACKS, INITIAL_CLIPS } from './data/sampleClips';
import { checkBackendHealth } from './services/api';
import confetti from 'canvas-confetti';
import { 
  CheckCircle2, 
  Download, 
  X, 
  Wrench, 
  FileArchive, 
  CheckSquare, 
  Square, 
  RefreshCw,
  Share2,
  Copy,
  Check,
  HardDrive,
  ExternalLink,
  Cloud,
  Clock,
  Film
} from 'lucide-react';
import JSZip from 'jszip';

export const App: React.FC = () => {
  // Default to 'create' matching the screenshot
  const [currentTab, setCurrentTab] = useState<AppTab>('create');
  const [tracks, setTracks] = useState<TimelineTrack[]>(INITIAL_TRACKS);
  const [clips, setClips] = useState<EditorClip[]>(INITIAL_CLIPS);
  const [backendStatus, setBackendStatus] = useState<{ status: string; hasKey: boolean }>({
    status: 'checking',
    hasKey: false,
  });
  const [showExportModal, setShowExportModal] = useState<boolean>(false);
  const [showMetaModal, setShowMetaModal] = useState<boolean>(false);
  const [showQuickMenu, setShowQuickMenu] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Archive Export Checkbox Options
  const [includeProjectMetadata, setIncludeProjectMetadata] = useState<boolean>(true);
  const [includeSourceAssets, setIncludeSourceAssets] = useState<boolean>(true);
  const [isGeneratingZip, setIsGeneratingZip] = useState<boolean>(false);

  // Simulated Cloud Storage Share Link states
  const [shareableLink, setShareableLink] = useState<string | null>(null);
  const [isGeneratingShareLink, setIsGeneratingShareLink] = useState<boolean>(false);
  const [copiedShareLink, setCopiedShareLink] = useState<boolean>(false);

  // Generate simulated cloud storage link
  const handleGenerateShareLink = async () => {
    setIsGeneratingShareLink(true);
    setCopiedShareLink(false);
    await new Promise((resolve) => setTimeout(resolve, 800));
    const randomId = Math.random().toString(36).substring(2, 10);
    const link = `https://cloud.motionai.studio/share/archive-${randomId}?exp=24h`;
    setShareableLink(link);
    setIsGeneratingShareLink(false);
    confetti({ particleCount: 35, spread: 60 });
    triggerToast('Generated simulated cloud archive share link!');
  };

  const handleCopyShareLink = async () => {
    if (!shareableLink) return;
    try {
      await navigator.clipboard.writeText(shareableLink);
      setCopiedShareLink(true);
      triggerToast('Share link copied to clipboard!');
      setTimeout(() => setCopiedShareLink(false), 2500);
    } catch {
      triggerToast('Link ready: ' + shareableLink);
    }
  };

  const handleNativeShare = async () => {
    if (!shareableLink) return;
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Motionai Project Archive',
          text: 'Check out this exported Motionai cinema project archive.',
          url: shareableLink,
        });
      } catch {
        // User cancelled share dialog
      }
    } else {
      handleCopyShareLink();
    }
  };

  // Master timeline calculations
  const totalDurationSec = Math.max(1, ...clips.map((c) => c.startTime + c.duration));
  const midPointTime = totalDurationSec / 2;
  const midPointClip =
    clips.find(
      (c) =>
        c.type === 'video' &&
        midPointTime >= c.startTime &&
        midPointTime <= c.startTime + c.duration
    ) ||
    clips.find((c) => c.type === 'video') ||
    clips[0];

  // Storage size calculation for export archive
  const calculateArchiveSize = () => {
    const videoMasterMB = 36.4;
    const metadataMB = includeProjectMetadata ? 0.05 : 0;
    let sourceAssetsMB = 0;
    if (includeSourceAssets) {
      const videoClips = clips.filter((c) => c.type === 'video');
      const audioClips = clips.filter((c) => c.type === 'audio' || c.type === 'voiceover');
      const textClips = clips.filter((c) => c.type === 'text');
      sourceAssetsMB = videoClips.length * 12.8 + audioClips.length * 2.4 + textClips.length * 0.02 + 0.35;
    }
    const totalMB = videoMasterMB + metadataMB + sourceAssetsMB;
    return {
      videoMasterMB,
      metadataMB,
      sourceAssetsMB,
      totalMB,
      percentage: Math.min(100, Math.round((totalMB / 100) * 100)),
    };
  };

  // Download Zip Archive with Project Metadata & Source Assets
  const handleDownloadZipArchive = async () => {
    setIsGeneratingZip(true);
    try {
      const zip = new JSZip();
      const totalDurationSec = Math.max(0, ...clips.map((c) => c.startTime + c.duration));

      // 1. Root Readme
      zip.file(
        'README.txt',
        `====================================================\n` +
        `MOTIONAI PRO STUDIO - MASTER EXPORT ARCHIVE\n` +
        `====================================================\n\n` +
        `Export Timestamp: ${new Date().toISOString()}\n` +
        `Master Sequence Duration: ${totalDurationSec.toFixed(2)} seconds\n` +
        `Total Timeline Layers: ${clips.length}\n` +
        `Active Resolution: 1080p Full HD\n` +
        `Master Video Bitrate: 32 Mbps H.264 / AAC\n` +
        `Author Account: farhanrajpoot34@gmail.com\n\n` +
        `Included Components:\n` +
        `- Project Metadata: ${includeProjectMetadata ? 'INCLUDED' : 'OMITTED'}\n` +
        `- Source Assets & Subtitles: ${includeSourceAssets ? 'INCLUDED' : 'OMITTED'}\n\n` +
        `Thank you for creating with Motionai Studio.`
      );

      // 2. Project Metadata (if checked)
      if (includeProjectMetadata) {
        const metadataPayload = {
          projectTitle: 'Motionai Master Cut',
          version: '2.0.0',
          generator: 'Motionai Pro Cinema NLE',
          exportedAt: new Date().toISOString(),
          settings: {
            durationSeconds: totalDurationSec,
            resolution: '1080p',
            frameRate: 30,
            colorSpace: 'Rec.709 Dark Gold LUT',
            audioDuckingEnabled: true,
            hardwareAcceleration: 'WebGL GPU Enabled',
          },
          tracks: tracks.map((t) => ({
            id: t.id,
            name: t.name,
            type: t.type,
            muted: t.muted,
            locked: t.locked,
            height: t.height,
          })),
          clips: clips.map((c) => ({
            id: c.id,
            trackId: c.trackId,
            title: c.title,
            type: c.type,
            mediaUrl: c.mediaUrl,
            thumbnail: c.thumbnail,
            startTime: c.startTime,
            duration: c.duration,
            sourceDuration: c.sourceDuration,
            trimStart: c.trimStart,
            trimEnd: c.trimEnd,
            volume: c.volume,
            muted: c.muted,
            fadeIn: c.fadeIn,
            fadeOut: c.fadeOut,
            speed: c.speed,
            transition: c.transition,
            filter: c.filter,
            colorGrade: c.colorGrade,
            transform: c.transform,
            textOverlay: c.textOverlay,
          })),
        };

        zip.file('project_metadata.json', JSON.stringify(metadataPayload, null, 2));
      }

      // 3. Source Assets (if checked)
      if (includeSourceAssets) {
        const sourceFolder = zip.folder('source_assets');

        // Asset Manifest
        const assetManifest = {
          exportTimestamp: new Date().toISOString(),
          assetCount: clips.length,
          assets: clips.map((c, idx) => ({
            index: idx + 1,
            id: c.id,
            title: c.title,
            track: c.trackId,
            mediaType: c.type,
            sourceUrl: c.mediaUrl,
            timelineIn: c.startTime,
            timelineOut: c.startTime + c.duration,
            sourceDuration: c.sourceDuration,
          })),
        };
        sourceFolder?.file('asset_manifest.json', JSON.stringify(assetManifest, null, 2));

        // Subtitles SRT file
        const srtContent = clips
          .filter((c) => c.type === 'text' || c.textOverlay)
          .map((c, idx) => {
            const formatSrtTime = (sec: number) => {
              const hrs = Math.floor(sec / 3600);
              const mins = Math.floor((sec % 3600) / 60);
              const s = Math.floor(sec % 60);
              const ms = Math.floor((sec % 1) * 1000);
              return `${String(hrs).padStart(2, '0')}:${String(mins).padStart(2, '0')}:${String(s).padStart(2, '0')},${String(ms).padStart(3, '0')}`;
            };
            const text = c.textOverlay?.text || c.title;
            return `${idx + 1}\n${formatSrtTime(c.startTime)} --> ${formatSrtTime(c.startTime + c.duration)}\n${text}`;
          })
          .join('\n\n') || `1\n00:00:00,500 --> 00:00:03,500\nMotionai Master Cinema Cut\n\n2\n00:00:04,000 --> 00:00:07,500\nPowered by Motionai Neural NLE`;

        sourceFolder?.file('captions.srt', srtContent);
        sourceFolder?.file(
          'media_sources.txt',
          clips.map((c, i) => `${i + 1}. [${c.type.toUpperCase()}] "${c.title}" -> ${c.mediaUrl}`).join('\n')
        );
      }

      // Master Video reference placeholder
      zip.file(
        'master_video_source.txt',
        `Direct MP4 Stream URL:\nhttps://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4\n\n` +
        `Sequence Composited with 30fps Rec.709 Dark Gold LUT.`
      );

      const zipBlob = await zip.generateAsync({
        type: 'blob',
        compression: 'DEFLATE',
        compressionOptions: { level: 6 },
      });

      const blobUrl = URL.createObjectURL(zipBlob);
      const downloadAnchor = document.createElement('a');
      downloadAnchor.href = blobUrl;
      downloadAnchor.download = 'motionai_project_archive.zip';
      downloadAnchor.click();
      URL.revokeObjectURL(blobUrl);

      confetti({ particleCount: 60, spread: 75 });
      triggerToast('Downloaded motionai_project_archive.zip successfully!');
    } catch {
      triggerToast('Error packaging project zip archive.');
    } finally {
      setIsGeneratingZip(false);
    }
  };

  // Check backend server status
  useEffect(() => {
    checkBackendHealth().then(setBackendStatus);
  }, []);

  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Reset project timeline to default sequence
  const handleResetProject = () => {
    if (window.confirm('Reset video editor timeline to default sequence?')) {
      setTracks(INITIAL_TRACKS);
      setClips(INITIAL_CLIPS);
      triggerToast('Timeline reset to default project sequence');
    }
  };

  // Quick Export Modal Trigger
  const handleQuickExport = () => {
    setShowExportModal(true);
    confetti({
      particleCount: 70,
      spread: 80,
      origin: { y: 0.6 },
    });
  };

  // Insert generated clip from AI Studios onto the timeline
  const handleInsertGeneratedClip = (title: string, videoUrl: string, durationSec = 30) => {
    const totalDuration = Math.max(0, ...clips.map((c) => c.startTime + c.duration));
    const newClip: EditorClip = {
      id: 'clip-' + Date.now(),
      trackId: 'track-v1',
      title: title || 'AI Generated Shot',
      type: 'video',
      mediaUrl: videoUrl,
      thumbnail: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=400&q=80',
      startTime: totalDuration,
      duration: durationSec,
      sourceDuration: durationSec,
      trimStart: 0,
      trimEnd: durationSec,
      volume: 1,
      muted: false,
      fadeIn: 0.4,
      fadeOut: 0.4,
      speed: 1,
      transition: { type: 'dissolve', duration: 0.5 },
      filter: { preset: 'cinematic-gold', intensity: 80 },
    };

    setClips([...clips, newClip]);
    setCurrentTab('studio');
    const durLabel = durationSec >= 60 ? `${Math.floor(durationSec / 60)}m ${durationSec % 60 ? `${durationSec % 60}s` : ''}` : `${durationSec}s`;
    triggerToast(`Added "${newClip.title}" (${durLabel}) to CapCut timeline!`);
  };

  // Insert generated image onto timeline as PiP
  const handleInsertImageToEditor = (title: string, imageUrl: string) => {
    const totalDuration = Math.max(0, ...clips.map((c) => c.startTime + c.duration));
    const newClip: EditorClip = {
      id: 'clip-' + Date.now(),
      trackId: 'track-v2',
      title: title || 'Graphic Overlay',
      type: 'image',
      mediaUrl: imageUrl,
      thumbnail: imageUrl,
      startTime: totalDuration > 0 ? totalDuration - 3 : 0,
      duration: 4,
      sourceDuration: 4,
      trimStart: 0,
      trimEnd: 4,
      volume: 0,
      muted: true,
      fadeIn: 0.3,
      fadeOut: 0.3,
      speed: 1,
      transform: {
        scale: 0.5,
        rotation: 0,
        x: 20,
        y: -15,
        opacity: 0.95,
        flippedHorizontal: false,
      },
    };

    setClips([...clips, newClip]);
    setCurrentTab('studio');
    triggerToast(`Added "${newClip.title}" as PiP overlay!`);
  };

  // Insert asset from Library
  const handleInsertAsset = (name: string, url: string, type: 'video' | 'audio' | 'image') => {
    const totalDuration = Math.max(0, ...clips.map((c) => c.startTime + c.duration));
    const targetTrackId = type === 'audio' ? 'track-a1' : type === 'image' ? 'track-v2' : 'track-v1';

    const newClip: EditorClip = {
      id: 'clip-' + Date.now(),
      trackId: targetTrackId,
      title: name,
      type: type,
      mediaUrl: url,
      thumbnail: type === 'image' ? url : undefined,
      startTime: totalDuration,
      duration: type === 'audio' ? 8 : 5,
      sourceDuration: 15,
      trimStart: 0,
      trimEnd: type === 'audio' ? 8 : 5,
      volume: 1,
      muted: false,
      fadeIn: 0.3,
      fadeOut: 0.3,
      speed: 1,
    };

    setClips([...clips, newClip]);
    setCurrentTab('studio');
    triggerToast(`Added "${name}" to CapCut editor!`);
  };

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 flex flex-col font-sans selection:bg-amber-500/30 selection:text-amber-200">
      {/* Universal Top Header matching Screenshot 1 */}
      <Header
        currentTab={currentTab}
        onTabChange={setCurrentTab}
        onResetProject={handleResetProject}
        onQuickExport={handleQuickExport}
        onOpenMetaModal={() => setShowMetaModal(true)}
        backendStatus={backendStatus}
      />

      {/* Main Screen Content */}
      <main className="flex-1 pb-20 md:pb-8">
        {/* CREATE TAB: Matches Screenshots 1 & 2 */}
        {currentTab === 'create' && (
          <CreateStudio
            onInsertGeneratedClip={handleInsertGeneratedClip}
            onNavigateTab={setCurrentTab}
            onOpenMetaModal={() => setShowMetaModal(true)}
          />
        )}

        {/* STUDIO TAB: The CapCut-grade advanced multi-track video editor */}
        {(currentTab === 'studio' || currentTab === 'editor') && (
          <CapCutEditor
            tracks={tracks}
            clips={clips}
            onClipsChange={setClips}
            onTracksChange={setTracks}
            onQuickExport={handleQuickExport}
          />
        )}

        {/* BUSINESS TAB: The AI Marketing Generator from Screenshots 3 & 4 */}
        {currentTab === 'business' && (
          <BusinessStudio
            onInsertAssetToEditor={handleInsertAsset}
            onNavigateTab={setCurrentTab}
          />
        )}

        {/* LIBRARY TAB */}
        {currentTab === 'library' && (
          <LibraryStudio
            onInsertAssetToEditor={handleInsertAsset}
            onNavigateToEditor={() => setCurrentTab('studio')}
          />
        )}

        {/* PROFILE TAB */}
        {currentTab === 'profile' && (
          <ProfileStudio
            userEmail="farhanrajpoot34@gmail.com"
            hasKey={backendStatus.hasKey}
          />
        )}

        {/* ADDITIONAL SPECIALIZED STUDIOS (Preserved and fully accessible) */}
        {currentTab === 'generate' && (
          <VideoGenStudio
            onInsertGeneratedClip={handleInsertGeneratedClip}
            onNavigateToEditor={() => setCurrentTab('studio')}
          />
        )}

        {currentTab === 'image-gen' && (
          <ImageGenerationStudio
            onInsertImageToEditor={handleInsertImageToEditor}
            onSendToImage2Video={() => setCurrentTab('image2video')}
            onNavigateToEditor={() => setCurrentTab('studio')}
          />
        )}

        {currentTab === 'image2video' && (
          <ImageToVideoStudio
            onInsertGeneratedClip={handleInsertGeneratedClip}
            onNavigateToEditor={() => setCurrentTab('studio')}
          />
        )}

        {currentTab === 'describe' && (
          <AutoDescribeStudio
            onUsePrompt={(promptText) => {
              setCurrentTab('create');
              triggerToast('Prompt loaded into Create Studio!');
            }}
          />
        )}

        {currentTab === 'batch' && (
          <BatchProcessingStudio
            onInsertClip={handleInsertGeneratedClip}
            onNavigateToEditor={() => setCurrentTab('studio')}
          />
        )}

        {currentTab === 'comparison' && <CompetitorComparisonStudio />}

        {currentTab === 'android' && <AndroidExportStudio />}
      </main>

      {/* Floating Action Tool Button (matching the wrench icon in Screenshots 1, 2, 3, 4) */}
      <div className="fixed right-4 top-24 z-40">
        <button
          onClick={() => setShowQuickMenu(!showQuickMenu)}
          title="Studio Toolkit"
          className="w-12 h-12 rounded-full bg-gradient-to-tr from-amber-500 to-yellow-500 text-zinc-950 font-bold flex items-center justify-center shadow-xl shadow-amber-500/30 hover:scale-105 active:scale-95 transition-all"
        >
          <Wrench className="w-5 h-5 fill-zinc-950" />
        </button>

        {showQuickMenu && (
          <div className="absolute right-0 top-14 w-52 bg-zinc-950 border border-amber-500/40 rounded-2xl p-2 shadow-2xl space-y-1 animate-in fade-in slide-in-from-top-2">
            <button
              onClick={() => {
                setCurrentTab('studio');
                setShowQuickMenu(false);
              }}
              className="w-full text-left px-3 py-2 rounded-xl text-xs font-bold text-zinc-200 hover:bg-zinc-900 hover:text-amber-400 flex items-center gap-2"
            >
              <span>🎬</span> CapCut Video Editor
            </button>
            <button
              onClick={() => {
                setCurrentTab('business');
                setShowQuickMenu(false);
              }}
              className="w-full text-left px-3 py-2 rounded-xl text-xs font-bold text-zinc-200 hover:bg-zinc-900 hover:text-amber-400 flex items-center gap-2"
            >
              <span>💼</span> AI Marketing Generator
            </button>
            <button
              onClick={() => {
                setCurrentTab('comparison');
                setShowQuickMenu(false);
              }}
              className="w-full text-left px-3 py-2 rounded-xl text-xs font-bold text-zinc-200 hover:bg-zinc-900 hover:text-amber-400 flex items-center gap-2"
            >
              <span>⚖️</span> Market Gap Matrix
            </button>
            <button
              onClick={() => {
                setCurrentTab('android');
                setShowQuickMenu(false);
              }}
              className="w-full text-left px-3 py-2 rounded-xl text-xs font-bold text-zinc-200 hover:bg-zinc-900 hover:text-amber-400 flex items-center gap-2"
            >
              <span>📱</span> Mobile & APK Hub
            </button>
            <button
              onClick={() => {
                setShowMetaModal(true);
                setShowQuickMenu(false);
              }}
              className="w-full text-left px-3 py-2 rounded-xl text-xs font-bold text-zinc-200 hover:bg-zinc-900 hover:text-amber-400 flex items-center gap-2"
            >
              <span>🌐</span> SEO Meta Tags
            </button>
          </div>
        )}
      </div>

      {/* Mobile Bottom Navigation Bar matching Screenshot 1-4 (Create, Studio, Business, Library, Profile) */}
      <BottomNavBar currentTab={currentTab} onTabChange={setCurrentTab} />

      {/* Floating Notification Toast */}
      {toastMessage && (
        <div className="fixed bottom-16 md:bottom-6 right-6 z-50 flex items-center gap-2.5 px-4 py-2.5 rounded-xl bg-zinc-900 border border-amber-500/40 text-amber-300 text-xs font-bold shadow-2xl shadow-black animate-in fade-in slide-in-from-bottom-3 duration-200">
          <CheckCircle2 className="w-4 h-4 text-amber-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Export Completed Dialog Modal */}
      {showExportModal && (() => {
        const archiveSize = calculateArchiveSize();

        return (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-150">
            <div className="relative w-full max-w-lg max-h-[92vh] overflow-y-auto bg-zinc-950 border border-amber-500/40 rounded-2xl p-5 sm:p-6 shadow-2xl space-y-3.5 scrollbar-thin">
              <button
                onClick={() => setShowExportModal(false)}
                className="absolute top-4 right-4 p-1.5 rounded-lg text-zinc-400 hover:text-zinc-100 hover:bg-zinc-900 transition-colors z-20"
              >
                <X className="w-4 h-4" />
              </button>

              {/* Modal Header */}
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-amber-400 to-yellow-600 flex items-center justify-center text-zinc-950 font-black shadow-lg shadow-amber-500/30 shrink-0">
                  <Download className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-extrabold text-zinc-100">Video Master Package Ready</h3>
                  <p className="text-xs text-amber-400">All tracks, filters & transitions composited</p>
                </div>
              </div>

              {/* Video Thumbnail Preview: Static frame captured from timeline mid-point */}
              <div className="relative w-full aspect-video rounded-xl overflow-hidden border border-amber-500/35 bg-black shadow-lg group">
                <img
                  src={
                    midPointClip?.thumbnail ||
                    'https://images.unsplash.com/photo-1536240478700-b869070f9279?auto=format&fit=crop&w=640&q=80'
                  }
                  alt="Mid-Point Frame Preview"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/20 to-black/50 pointer-events-none" />

                {/* Top Badge: Timeline Midpoint indicator */}
                <div className="absolute top-2.5 left-2.5 flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-black/80 border border-amber-500/50 text-amber-300 text-[10px] font-mono font-bold backdrop-blur-md shadow-md">
                  <Film className="w-3 h-3 text-amber-400" />
                  <span>Mid-Point Frame: {midPointTime.toFixed(1)}s (50% Timeline)</span>
                </div>

                <div className="absolute top-2.5 right-2.5 px-2 py-1 rounded-md bg-black/80 border border-zinc-700 text-zinc-300 text-[10px] font-mono font-bold backdrop-blur-md">
                  1080p Full HD
                </div>

                {/* Bottom Details Overlay */}
                <div className="absolute bottom-2.5 left-3 right-3 flex items-center justify-between text-[11px] text-zinc-200">
                  <div className="flex items-center gap-1.5 truncate max-w-[240px]">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 inline-block animate-ping" />
                    <span className="font-bold truncate text-zinc-100">
                      {midPointClip?.title || 'Master Sequence'}
                    </span>
                  </div>
                  <span className="text-amber-400 font-mono text-[10px] font-bold bg-zinc-950/80 px-2 py-0.5 rounded border border-amber-500/30">
                    Rec.709 Gold LUT
                  </span>
                </div>
              </div>

              {/* Timeline Composition Stats */}
              <div className="p-3 rounded-xl bg-zinc-900/80 border border-zinc-800 space-y-1.5 text-xs">
                <div className="flex justify-between">
                  <span className="text-zinc-400">Timeline Layers:</span>
                  <span className="font-bold text-zinc-200">{clips.length} composited clips</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-zinc-400">Master Duration:</span>
                  <span className="font-bold text-amber-400 font-mono">
                    {totalDurationSec.toFixed(1)}s ({Math.floor(totalDurationSec / 60)}m {Math.floor(totalDurationSec % 60)}s)
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-zinc-400">Color Grade & LUTs:</span>
                  <span className="font-bold text-emerald-400">Applied (30fps Pro Engine)</span>
                </div>
              </div>

              {/* Checkbox Options for Project Metadata & Source Assets */}
              <div className="p-3.5 rounded-xl bg-zinc-900/90 border border-amber-500/30 space-y-2.5">
                <span className="text-[11px] font-extrabold text-zinc-300 uppercase tracking-wider block">
                  Archive Package Options (.zip)
                </span>

                {/* Checkbox 1: Project Metadata */}
                <label className="flex items-start gap-2.5 cursor-pointer select-none group">
                  <input
                    type="checkbox"
                    checked={includeProjectMetadata}
                    onChange={(e) => setIncludeProjectMetadata(e.target.checked)}
                    className="hidden"
                  />
                  <div
                    className={`w-4 h-4 rounded mt-0.5 flex items-center justify-center border transition-all ${
                      includeProjectMetadata
                        ? 'bg-amber-500 border-amber-400 text-zinc-950'
                        : 'border-zinc-700 bg-zinc-950 group-hover:border-zinc-500'
                    }`}
                  >
                    {includeProjectMetadata && <CheckCircle2 className="w-3.5 h-3.5 stroke-[3]" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-xs font-bold text-zinc-200 group-hover:text-amber-300 transition-colors">
                      Include 'Project Metadata'
                    </div>
                    <div className="text-[11px] text-zinc-400 leading-snug">
                      Saves timeline layers, clip keyframes, color grades, text overlays, and sequence timing (project_metadata.json).
                    </div>
                  </div>
                </label>

                {/* Checkbox 2: Source Assets */}
                <label className="flex items-start gap-2.5 cursor-pointer select-none group">
                  <input
                    type="checkbox"
                    checked={includeSourceAssets}
                    onChange={(e) => setIncludeSourceAssets(e.target.checked)}
                    className="hidden"
                  />
                  <div
                    className={`w-4 h-4 rounded mt-0.5 flex items-center justify-center border transition-all ${
                      includeSourceAssets
                        ? 'bg-amber-500 border-amber-400 text-zinc-950'
                        : 'border-zinc-700 bg-zinc-950 group-hover:border-zinc-500'
                    }`}
                  >
                    {includeSourceAssets && <CheckCircle2 className="w-3.5 h-3.5 stroke-[3]" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-xs font-bold text-zinc-200 group-hover:text-amber-300 transition-colors">
                      Include 'Source Assets'
                    </div>
                    <div className="text-[11px] text-zinc-400 leading-snug">
                      Packages source media references, asset manifest, and SRT subtitle file (source_assets/ + subtitles.srt).
                    </div>
                  </div>
                </label>
              </div>

              {/* Storage Usage Indicator */}
              <div className="p-3.5 rounded-xl bg-zinc-900/95 border border-zinc-800 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-1.5 font-bold text-zinc-200">
                    <HardDrive className="w-3.5 h-3.5 text-amber-400" />
                    <span>Estimated Archive Storage Usage:</span>
                  </div>
                  <span className="font-mono font-extrabold text-amber-400 text-xs">
                    ~{archiveSize.totalMB.toFixed(1)} MB
                  </span>
                </div>

                {/* Capacity Progress Bar */}
                <div className="w-full h-2 bg-zinc-950 rounded-full overflow-hidden border border-zinc-800/80">
                  <div
                    className="h-full bg-gradient-to-r from-amber-500 to-yellow-400 rounded-full transition-all duration-300 shadow-[0_0_8px_rgba(245,158,11,0.5)]"
                    style={{ width: `${Math.min(100, Math.max(12, archiveSize.percentage))}%` }}
                  />
                </div>

                {/* Storage Breakdown Chips */}
                <div className="flex flex-wrap items-center justify-between gap-1.5 text-[10px] text-zinc-400 pt-0.5">
                  <span className="flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-amber-400 inline-block" />
                    Video Master: ~{archiveSize.videoMasterMB.toFixed(1)} MB
                  </span>
                  <span className="flex items-center gap-1">
                    <span className={`w-1.5 h-1.5 rounded-full inline-block ${includeSourceAssets ? 'bg-yellow-400' : 'bg-zinc-600'}`} />
                    Assets: {includeSourceAssets ? `~${archiveSize.sourceAssetsMB.toFixed(1)} MB` : 'Omitted'}
                  </span>
                  <span className="flex items-center gap-1">
                    <span className={`w-1.5 h-1.5 rounded-full inline-block ${includeProjectMetadata ? 'bg-emerald-400' : 'bg-zinc-600'}`} />
                    Metadata: {includeProjectMetadata ? '~50 KB' : 'Omitted'}
                  </span>
                </div>
              </div>

              {/* Simulated Cloud Share Link Panel (Revealed when user shares) */}
              {shareableLink && (
                <div className="p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/40 space-y-2.5 animate-in fade-in duration-200">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5 text-xs font-bold text-amber-300">
                      <Cloud className="w-4 h-4 text-amber-400" />
                      <span>Simulated Cloud Storage Link</span>
                    </div>
                    <span className="flex items-center gap-1 text-[10px] font-mono text-zinc-400">
                      <Clock className="w-3 h-3 text-amber-400" />
                      <span>Expires in 24h</span>
                    </span>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <input
                      type="text"
                      readOnly
                      value={shareableLink}
                      className="flex-1 bg-zinc-950 border border-zinc-750 rounded-lg px-2.5 py-1.5 text-[11px] font-mono text-zinc-300 focus:outline-none select-all"
                    />
                    <button
                      onClick={handleCopyShareLink}
                      className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold text-xs transition-colors shrink-0 shadow-sm"
                    >
                      {copiedShareLink ? (
                        <>
                          <Check className="w-3.5 h-3.5" />
                          <span>Copied!</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" />
                          <span>Copy</span>
                        </>
                      )}
                    </button>

                    <button
                      onClick={handleNativeShare}
                      title="Share link"
                      className="p-1.5 rounded-lg bg-zinc-900 hover:bg-zinc-850 text-amber-300 border border-zinc-700 shrink-0 transition-colors"
                    >
                      <Share2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                  <p className="text-[10px] text-zinc-400">
                    Anyone with this link can stream the master cut or download the packaged zip archive from the simulated cloud CDN.
                  </p>
                </div>
              )}

              {/* Action Buttons: ZIP Download, Share Button, Single MP4 Download */}
              <div className="space-y-2 pt-1">
                {/* Primary ZIP Archive Download Button */}
                <button
                  onClick={handleDownloadZipArchive}
                  disabled={isGeneratingZip}
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 via-yellow-500 to-amber-600 hover:from-amber-400 hover:to-yellow-400 text-zinc-950 font-black text-xs shadow-lg shadow-amber-500/25 flex items-center justify-center gap-2 transition-all hover:scale-[1.01] active:scale-[0.99] disabled:opacity-50"
                >
                  {isGeneratingZip ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>Packaging Project ZIP Archive...</span>
                    </>
                  ) : (
                    <>
                      <FileArchive className="w-4 h-4" />
                      <span>Download Project Archive (.zip)</span>
                    </>
                  )}
                </button>

                {/* Secondary Row: Share Cloud Link & Download MP4 Master */}
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={handleGenerateShareLink}
                    disabled={isGeneratingShareLink}
                    className="py-2.5 rounded-xl bg-zinc-900 hover:bg-zinc-850 text-amber-300 border border-amber-500/35 hover:border-amber-400 text-xs font-bold flex items-center justify-center gap-1.5 transition-colors"
                  >
                    {isGeneratingShareLink ? (
                      <>
                        <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                        <span>Generating...</span>
                      </>
                    ) : (
                      <>
                        <Share2 className="w-3.5 h-3.5 text-amber-400" />
                        <span>Share Project</span>
                      </>
                    )}
                  </button>

                  <a
                    href="https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4"
                    download="motionai_master_export.mp4"
                    className="py-2.5 rounded-xl bg-zinc-900 hover:bg-zinc-850 text-amber-300 border border-zinc-800 hover:border-zinc-700 text-xs font-bold flex items-center justify-center gap-1.5 transition-colors"
                  >
                    <Download className="w-3.5 h-3.5 text-amber-400" />
                    <span>MP4 Master</span>
                  </a>
                </div>

                {/* Quick Installers */}
                <div className="grid grid-cols-2 gap-2 pt-1">
                  <a
                    href="/install.html"
                    download="install.html"
                    className="p-2 rounded-lg bg-zinc-900 hover:bg-zinc-850 text-amber-400 border border-zinc-800 font-semibold text-xs text-center transition-colors"
                  >
                    📦 Installer HTML
                  </a>
                  <a
                    href="/motionai-android.html"
                    download="motionai-android.html"
                    className="p-2 rounded-lg bg-zinc-900 hover:bg-zinc-850 text-amber-400 border border-zinc-800 font-semibold text-xs text-center transition-colors"
                  >
                    🤖 Android APK File
                  </a>
                </div>
              </div>
            </div>
          </div>
        );
      })()}

      {/* SEO & Meta Tags Modal */}
      <MetaTagsModal
        isOpen={showMetaModal}
        onClose={() => setShowMetaModal(false)}
      />
    </div>
  );
};

export default App;
