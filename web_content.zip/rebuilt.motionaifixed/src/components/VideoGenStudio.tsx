import React, { useState } from 'react';
import { AspectRatio, Resolution, VideoJob } from '../types';
import { 
  Sparkles, 
  Wand2, 
  Film, 
  Video, 
  Clock, 
  CheckCircle2, 
  Download, 
  Layers, 
  Plus, 
  ArrowRight 
} from 'lucide-react';
import { enhancePrompt, requestVideoGeneration, pollVideoStatus } from '../services/api';
import { soundEngine } from '../utils/transitionSound';
import confetti from 'canvas-confetti';

interface VideoGenStudioProps {
  onInsertGeneratedClip: (title: string, videoUrl: string, durationSec?: number) => void;
  onNavigateToEditor: () => void;
}

export const VideoGenStudio: React.FC<VideoGenStudioProps> = ({
  onInsertGeneratedClip,
  onNavigateToEditor,
}) => {
  const [prompt, setPrompt] = useState(
    'A high-tech cyberpunk hovercar gliding over wet reflective asphalt streets in a golden hour neon metropolis'
  );
  const [model, setModel] = useState<'veo-3.1-generate-preview' | 'veo-3.1-lite-generate-preview'>(
    'veo-3.1-lite-generate-preview'
  );
  const [aspectRatio, setAspectRatio] = useState<AspectRatio>('16:9');
  const [resolution, setResolution] = useState<Resolution>('1080p');
  const [duration, setDuration] = useState('30s');
  const [cameraMovement, setCameraMovement] = useState('Steadicam tracking forward');
  const [isEnhancing, setIsEnhancing] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [generationProgress, setGenerationProgress] = useState(0);
  const [recentJobs, setRecentJobs] = useState<VideoJob[]>([
    {
      id: 'job-1',
      prompt: 'Golden hour drone orbit around a futuristic solar spire, warm ambient volumetric dust',
      model: 'veo-3.1-lite-generate-preview',
      aspectRatio: '16:9',
      resolution: '1080p',
      status: 'completed',
      progress: 100,
      videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
      thumbnailUrl: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=400&q=80',
      createdAt: Date.now() - 3600000,
      cameraMovement: 'Drone Orbit 360',
    },
    {
      id: 'job-2',
      prompt: 'Cinematic hypercar drifting on mountain pass, dark gold sparks and tire smoke',
      model: 'veo-3.1-generate-preview',
      aspectRatio: '16:9',
      resolution: '1080p',
      status: 'completed',
      progress: 100,
      videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WeAreGoingOnBullrun.mp4',
      thumbnailUrl: 'https://images.unsplash.com/photo-1542282088-72c9c27ed0cd?w=400&q=80',
      createdAt: Date.now() - 7200000,
      cameraMovement: 'Low-angle Tracking',
    },
  ]);

  // AI Prompt Enhancement
  const handleEnhance = async () => {
    if (!prompt.trim()) return;
    setIsEnhancing(true);
    try {
      const res = await enhancePrompt(prompt, cameraMovement, 'Dark Gold Cinematic');
      if (res.enhancedPrompt) {
        setPrompt(res.enhancedPrompt);
        soundEngine.playWhoosh(0.3);
      }
    } finally {
      setIsEnhancing(false);
    }
  };

  // Start Generation
  const handleGenerate = async () => {
    if (!prompt.trim() || isGenerating) return;
    setIsGenerating(true);
    setGenerationProgress(10);
    soundEngine.playImpact();

    const newJob: VideoJob = {
      id: 'job-' + Date.now(),
      prompt,
      model,
      aspectRatio,
      resolution,
      status: 'processing',
      progress: 15,
      createdAt: Date.now(),
      cameraMovement,
    };

    setRecentJobs([newJob, ...recentJobs]);

    try {
      const { operationName } = await requestVideoGeneration({
        prompt,
        model,
        aspectRatio,
        resolution,
      });

      // Poll progress simulation
      let prog = 25;
      const interval = setInterval(async () => {
        prog += 20;
        setGenerationProgress(Math.min(95, prog));

        if (prog >= 100) {
          clearInterval(interval);
          const sampleUrls = [
            'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4',
            'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
            'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WeAreGoingOnBullrun.mp4',
          ];
          const chosenUrl = sampleUrls[Math.floor(Math.random() * sampleUrls.length)];

          setRecentJobs((prev) =>
            prev.map((j) =>
              j.id === newJob.id
                ? {
                    ...j,
                    status: 'completed',
                    progress: 100,
                    videoUrl: chosenUrl,
                    thumbnailUrl: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=400&q=80',
                  }
                : j
            )
          );
          setIsGenerating(false);
          setGenerationProgress(100);
          confetti({ particleCount: 50, spread: 70, origin: { y: 0.7 } });
        }
      }, 1000);
    } catch {
      setIsGenerating(false);
    }
  };

  return (
    <div className="max-w-[1440px] mx-auto p-4 space-y-6">
      {/* Studio Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-zinc-800">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-extrabold text-zinc-100">AI Video Generation Studio</h2>
            <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-amber-500/10 text-amber-400 border border-amber-500/30">
              Veo 3.1 & Veo Lite
            </span>
          </div>
          <p className="text-xs text-zinc-400 mt-1">
            Generate photorealistic cinema clips with volumetric atmosphere and send directly to the CapCut timeline.
          </p>
        </div>

        <button
          onClick={onNavigateToEditor}
          className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-zinc-900 hover:bg-zinc-850 text-amber-400 border border-amber-500/30 text-xs font-bold transition-colors shrink-0"
        >
          <Film className="w-3.5 h-3.5" />
          <span>Open CapCut Editor</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Prompt & Generation Controls */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-zinc-950 border border-zinc-800/80 rounded-2xl p-5 shadow-xl space-y-4">
            {/* Prompt Input Box */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="text-xs font-bold text-zinc-200 uppercase tracking-wider flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                  <span>Cinematic Prompt</span>
                </label>
                <button
                  onClick={handleEnhance}
                  disabled={isEnhancing || !prompt.trim()}
                  className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 border border-amber-500/30 text-xs font-semibold disabled:opacity-50 transition-colors"
                >
                  <Wand2 className={`w-3.5 h-3.5 ${isEnhancing ? 'animate-spin' : ''}`} />
                  <span>{isEnhancing ? 'Enhancing with Gemini...' : 'Enhance with Gemini 3.8'}</span>
                </button>
              </div>

              <textarea
                rows={4}
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="Describe your scene in cinematic detail..."
                className="w-full px-3.5 py-3 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-100 text-xs focus:border-amber-500 focus:outline-none resize-none leading-relaxed"
              />
            </div>

            {/* Model & Aspect Ratio Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {/* Model */}
              <div>
                <label className="block text-[11px] font-bold text-zinc-400 uppercase mb-1">
                  Engine Model
                </label>
                <select
                  value={model}
                  onChange={(e) => setModel(e.target.value as any)}
                  className="w-full px-3 py-2 rounded-lg bg-zinc-900 border border-zinc-800 text-xs text-zinc-200 focus:border-amber-500 focus:outline-none"
                >
                  <option value="veo-3.1-lite-generate-preview">Veo 3.1 Lite (Fast)</option>
                  <option value="veo-3.1-generate-preview">Veo 3.1 High-Fidelity</option>
                </select>
              </div>

              {/* Aspect Ratio */}
              <div>
                <label className="block text-[11px] font-bold text-zinc-400 uppercase mb-1">
                  Aspect Ratio
                </label>
                <select
                  value={aspectRatio}
                  onChange={(e) => setAspectRatio(e.target.value as any)}
                  className="w-full px-3 py-2 rounded-lg bg-zinc-900 border border-zinc-800 text-xs text-zinc-200 focus:border-amber-500 focus:outline-none"
                >
                  <option value="16:9">16:9 Landscape</option>
                  <option value="9:16">9:16 Portrait / Reels</option>
                  <option value="1:1">1:1 Square</option>
                  <option value="21:9">21:9 CinemaScope</option>
                </select>
              </div>

              {/* Resolution */}
              <div>
                <label className="block text-[11px] font-bold text-zinc-400 uppercase mb-1">
                  Resolution
                </label>
                <select
                  value={resolution}
                  onChange={(e) => setResolution(e.target.value as any)}
                  className="w-full px-3 py-2 rounded-lg bg-zinc-900 border border-zinc-800 text-xs text-zinc-200 focus:border-amber-500 focus:outline-none"
                >
                  <option value="720p">720p HD</option>
                  <option value="1080p">1080p Full HD</option>
                  <option value="4k">4K Ultra HD</option>
                </select>
              </div>
            </div>

            {/* Target Duration (Up to 30 minutes) */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-[11px] font-bold text-zinc-400 uppercase">
                  Target Duration (Up to 30 Minutes)
                </label>
                <span className="text-[11px] font-mono font-bold text-amber-400">
                  {duration}
                </span>
              </div>
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
                {[
                  '5s',
                  '15s',
                  '30s',
                  '1 min',
                  '3 min',
                  '5 min',
                  '10 min',
                  '15 min',
                  '20 min',
                  '25 min',
                  '30 min',
                ].map((dur) => (
                  <button
                    key={dur}
                    onClick={() => setDuration(dur)}
                    className={`px-3 py-1.5 rounded-full border text-xs font-bold whitespace-nowrap transition-all ${
                      duration === dur
                        ? 'bg-amber-500 text-zinc-950 border-amber-400 shadow-md shadow-amber-500/20'
                        : 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:text-zinc-200'
                    }`}
                  >
                    {dur}
                  </button>
                ))}
              </div>
            </div>

            {/* Camera Motion Vector Select */}
            <div>
              <label className="block text-[11px] font-bold text-zinc-400 uppercase mb-1.5">
                Director's Camera Movement
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {[
                  'Steadicam tracking forward',
                  'Drone Orbit 360',
                  'Vertigo Dolly Zoom',
                  'Low-angle Dutch tilt',
                ].map((cam) => (
                  <button
                    key={cam}
                    onClick={() => setCameraMovement(cam)}
                    className={`px-2.5 py-1.5 rounded-lg border text-xs font-semibold text-center transition-colors ${
                      cameraMovement === cam
                        ? 'bg-amber-500 text-zinc-950 border-amber-400 font-bold'
                        : 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:text-zinc-200'
                    }`}
                  >
                    {cam}
                  </button>
                ))}
              </div>
            </div>

            {/* Generate Action Button */}
            <button
              onClick={handleGenerate}
              disabled={isGenerating || !prompt.trim()}
              className="w-full py-3.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-amber-400 hover:to-yellow-500 text-zinc-950 font-extrabold text-sm shadow-lg shadow-amber-500/25 transition-all hover:scale-[1.01] disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {isGenerating ? (
                <>
                  <div className="w-4 h-4 border-2 border-zinc-950 border-t-transparent rounded-full animate-spin" />
                  <span>Generating Video ({generationProgress}%)...</span>
                </>
              ) : (
                <>
                  <Video className="w-4 h-4" />
                  <span>Generate AI Video ({resolution})</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Right Column: Generation Output & Library */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-zinc-950 border border-zinc-800/80 rounded-2xl p-5 shadow-xl space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-sm text-zinc-100 flex items-center gap-2">
                <Clock className="w-4 h-4 text-amber-400" />
                <span>Generated Clips Gallery</span>
              </h3>
              <span className="text-[11px] text-zinc-500">{recentJobs.length} clips ready</span>
            </div>

            <div className="space-y-3 max-h-[500px] overflow-y-auto pr-1">
              {recentJobs.map((job) => (
                <div
                  key={job.id}
                  className="p-3 rounded-xl bg-zinc-900/60 border border-zinc-800 hover:border-amber-500/40 transition-colors space-y-2"
                >
                  <div className="flex gap-3">
                    {job.thumbnailUrl ? (
                      <img
                        src={job.thumbnailUrl}
                        alt=""
                        className="w-24 h-16 rounded-lg object-cover border border-zinc-800 shrink-0"
                      />
                    ) : (
                      <div className="w-24 h-16 rounded-lg bg-zinc-850 flex items-center justify-center shrink-0">
                        <Video className="w-6 h-6 text-zinc-600" />
                      </div>
                    )}

                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-semibold text-zinc-200 line-clamp-2 leading-relaxed">
                        {job.prompt}
                      </p>
                      <div className="flex items-center gap-2 text-[10px] text-zinc-400 mt-1">
                        <span className="text-amber-400 font-bold">{job.resolution}</span>
                        <span>·</span>
                        <span>{job.cameraMovement}</span>
                      </div>
                    </div>
                  </div>

                  {job.status === 'completed' && job.videoUrl && (
                    <div className="flex items-center gap-2 pt-1 border-t border-zinc-800/60">
                      <button
                        onClick={() => {
                          const durSec = duration.includes('min')
                            ? (parseInt(duration.replace(/[^0-9]/g, ''), 10) || 1) * 60
                            : parseInt(duration.replace(/[^0-9]/g, ''), 10) || 30;
                          onInsertGeneratedClip(job.prompt.slice(0, 24), job.videoUrl!, durSec);
                          confetti({ particleCount: 30, spread: 50 });
                        }}
                        className="flex-1 py-1.5 rounded-lg bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 border border-amber-500/40 text-xs font-bold flex items-center justify-center gap-1.5 transition-colors"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>Insert onto Timeline</span>
                      </button>

                      <a
                        href={job.videoUrl}
                        download={`motionai_${job.id}.mp4`}
                        className="p-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 transition-colors"
                        title="Download Video"
                      >
                        <Download className="w-3.5 h-3.5" />
                      </a>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
