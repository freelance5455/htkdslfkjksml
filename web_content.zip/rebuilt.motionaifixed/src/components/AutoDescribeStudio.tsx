import React, { useState } from 'react';
import { Wand2, Sparkles, Copy, Check, ArrowRight, Film } from 'lucide-react';
import { enhancePrompt } from '../services/api';
import confetti from 'canvas-confetti';

interface AutoDescribeStudioProps {
  onUsePrompt: (prompt: string) => void;
}

export const AutoDescribeStudio: React.FC<AutoDescribeStudioProps> = ({ onUsePrompt }) => {
  const [inputIdea, setInputIdea] = useState('A lone samurai standing on a neon rain rooftop in Neo Tokyo');
  const [stylePreset, setStylePreset] = useState('Dark Gold Blade Runner');
  const [cameraType, setCameraType] = useState('35mm Anamorphic Dolly In');
  const [result, setResult] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isCopied, setIsCopied] = useState(false);

  const handleExpand = async () => {
    if (!inputIdea.trim()) return;
    setIsLoading(true);
    try {
      const data = await enhancePrompt(inputIdea, cameraType, stylePreset);
      setResult(data);
      confetti({ particleCount: 35, spread: 55 });
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopy = () => {
    if (!result?.enhancedPrompt) return;
    navigator.clipboard.writeText(result.enhancedPrompt);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  return (
    <div className="max-w-[1200px] mx-auto p-4 space-y-6">
      <div className="pb-4 border-b border-zinc-800">
        <div className="flex items-center gap-2">
          <h2 className="text-xl font-extrabold text-zinc-100">Director's Prompt Studio</h2>
          <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-amber-500/10 text-amber-400 border border-amber-500/30">
            Gemini 3.8 Flash
          </span>
        </div>
        <p className="text-xs text-zinc-400 mt-1">
          Turn simple concepts into Hollywood-grade cinematography scripts with volumetric lighting, camera rigs, and color science.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Input Parameters */}
        <div className="bg-zinc-950 border border-zinc-800/80 rounded-2xl p-5 shadow-xl space-y-4">
          <div>
            <label className="block text-xs font-bold text-zinc-200 uppercase mb-1.5">
              Core Creative Concept
            </label>
            <textarea
              rows={4}
              value={inputIdea}
              onChange={(e) => setInputIdea(e.target.value)}
              className="w-full px-3.5 py-3 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-100 text-xs focus:border-amber-500 focus:outline-none resize-none leading-relaxed"
              placeholder="E.g. A cybernetic tiger running through a bamboo forest..."
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-[11px] font-bold text-zinc-400 uppercase mb-1">
                Visual Style
              </label>
              <select
                value={stylePreset}
                onChange={(e) => setStylePreset(e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-zinc-900 border border-zinc-800 text-xs text-zinc-200 focus:border-amber-500 focus:outline-none"
              >
                <option value="Dark Gold Blade Runner">Dark Gold Blade Runner</option>
                <option value="IMAX 70mm Documentary">IMAX 70mm Documentary</option>
                <option value="Cyberpunk Noir">Cyberpunk Noir</option>
                <option value="Fantasy Golden Hour">Fantasy Golden Hour</option>
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-zinc-400 uppercase mb-1">
                Camera Rig
              </label>
              <select
                value={cameraType}
                onChange={(e) => setCameraType(e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-zinc-900 border border-zinc-800 text-xs text-zinc-200 focus:border-amber-500 focus:outline-none"
              >
                <option value="35mm Anamorphic Dolly In">35mm Anamorphic Dolly In</option>
                <option value="Drone 360 Orbit">Drone 360 Orbit</option>
                <option value="FPV High-Speed Chase">FPV High-Speed Chase</option>
                <option value="Vertigo Dolly Zoom">Vertigo Dolly Zoom</option>
              </select>
            </div>
          </div>

          <button
            onClick={handleExpand}
            disabled={isLoading || !inputIdea.trim()}
            className="w-full py-3.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-amber-400 hover:to-yellow-500 text-zinc-950 font-extrabold text-sm shadow-lg shadow-amber-500/20 disabled:opacity-50 transition-all flex items-center justify-center gap-2"
          >
            {isLoading ? (
              <>
                <div className="w-4 h-4 border-2 border-zinc-950 border-t-transparent rounded-full animate-spin" />
                <span>Crafting Cinematic Prompt...</span>
              </>
            ) : (
              <>
                <Wand2 className="w-4 h-4" />
                <span>Generate Master Prompt</span>
              </>
            )}
          </button>
        </div>

        {/* Output Presentation */}
        <div className="bg-zinc-950 border border-zinc-800/80 rounded-2xl p-5 shadow-xl flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-bold text-sm text-zinc-100 flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-amber-400" />
                <span>Expanded Cinematography Script</span>
              </h3>
              {result && (
                <button
                  onClick={handleCopy}
                  className="flex items-center gap-1 text-xs text-amber-400 hover:text-amber-300 font-semibold"
                >
                  {isCopied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{isCopied ? 'Copied' : 'Copy'}</span>
                </button>
              )}
            </div>

            {result ? (
              <div className="space-y-4">
                <div className="p-4 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-200 text-xs leading-relaxed font-mono">
                  {result.enhancedPrompt}
                </div>

                {result.tags && (
                  <div>
                    <div className="text-[11px] font-bold text-zinc-400 uppercase mb-1.5">
                      Cinematic Tags
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      {result.tags.map((t: string, i: number) => (
                        <span
                          key={i}
                          className="px-2 py-0.5 rounded text-[11px] bg-amber-500/10 text-amber-300 border border-amber-500/30 font-medium"
                        >
                          #{t}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="py-16 text-center text-zinc-500 space-y-2">
                <Sparkles className="w-8 h-8 mx-auto text-zinc-700" />
                <p className="text-xs">Click "Generate Master Prompt" to let Gemini 3.8 Flash formulate camera lenses, lighting rigs, and volumetric atmosphere.</p>
              </div>
            )}
          </div>

          {result && (
            <button
              onClick={() => onUsePrompt(result.enhancedPrompt)}
              className="mt-6 w-full py-2.5 rounded-xl bg-zinc-900 hover:bg-zinc-850 text-amber-400 border border-amber-500/30 text-xs font-bold flex items-center justify-center gap-2 transition-colors"
            >
              <span>Use in AI Video Gen Studio</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
