import React, { useState } from 'react';
import { COMPETITOR_ANALYSIS } from '../data/competitors';
import { CompetitorComparison } from '../types';
import { 
  Check, 
  X, 
  Sparkles, 
  Trophy, 
  ShieldCheck, 
  AlertCircle, 
  Layers, 
  Smartphone, 
  Zap 
} from 'lucide-react';

export const CompetitorComparisonStudio: React.FC = () => {
  const [selectedPlatform, setSelectedPlatform] = useState<string>('Motionai (This App)');

  const activeItem =
    COMPETITOR_ANALYSIS.find((c) => c.platform === selectedPlatform) ||
    COMPETITOR_ANALYSIS[COMPETITOR_ANALYSIS.length - 1];

  return (
    <div className="max-w-[1440px] mx-auto p-4 space-y-6">
      {/* Header */}
      <div className="pb-4 border-b border-zinc-800">
        <div className="flex items-center gap-2">
          <Trophy className="w-5 h-5 text-amber-400" />
          <h2 className="text-xl font-extrabold text-zinc-100">
            Market Competitive Analysis & Industry Gap Matrix
          </h2>
        </div>
        <p className="text-xs text-zinc-400 mt-1">
          Direct comparative teardown of RunwayML, Pika Labs, Synthesys, Luma Dream Machine, and Kling AI against Motionai's integrated CapCut-grade NLE.
        </p>
      </div>

      {/* Feature Matrix Table */}
      <div className="bg-zinc-950 border border-zinc-800/80 rounded-2xl overflow-hidden shadow-xl">
        <div className="p-4 border-b border-zinc-800 bg-zinc-900/60 flex items-center justify-between">
          <span className="text-xs font-bold text-zinc-200 uppercase tracking-wider">
            Capabilities Matrix
          </span>
          <span className="text-[11px] text-amber-400 font-semibold">
            Motionai closes 100% of identified post-production gaps
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-zinc-800 bg-zinc-900/40 text-zinc-400">
                <th className="p-3.5 font-bold">Platform</th>
                <th className="p-3.5 font-bold">Multi-Track NLE Editor</th>
                <th className="p-3.5 font-bold">Camera Motion Rigs</th>
                <th className="p-3.5 font-bold">Offline / Standalone App</th>
                <th className="p-3.5 font-bold">Watermark Free</th>
                <th className="p-3.5 font-bold">Max Resolution</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-850">
              {COMPETITOR_ANALYSIS.map((c) => {
                const isMotionai = c.platform.includes('Motionai');
                return (
                  <tr
                    key={c.platform}
                    onClick={() => setSelectedPlatform(c.platform)}
                    className={`cursor-pointer transition-colors ${
                      isMotionai
                        ? 'bg-amber-500/10 font-semibold'
                        : selectedPlatform === c.platform
                        ? 'bg-zinc-900/80'
                        : 'hover:bg-zinc-900/40'
                    }`}
                  >
                    <td className="p-3.5 flex items-center gap-2">
                      {isMotionai && <Trophy className="w-4 h-4 text-amber-400 shrink-0" />}
                      <span className={isMotionai ? 'text-amber-300 font-extrabold' : 'text-zinc-200'}>
                        {c.platform}
                      </span>
                    </td>
                    <td className="p-3.5">
                      {c.multiTrackEditor ? (
                        <span className="flex items-center gap-1 text-emerald-400 font-bold">
                          <Check className="w-4 h-4" /> Yes (CapCut-grade)
                        </span>
                      ) : (
                        <span className="flex items-center gap-1 text-zinc-500">
                          <X className="w-4 h-4 text-zinc-600" /> No (Raw clip only)
                        </span>
                      )}
                    </td>
                    <td className="p-3.5">
                      {c.cameraMotionControls ? (
                        <span className="flex items-center gap-1 text-emerald-400">
                          <Check className="w-4 h-4" /> Yes
                        </span>
                      ) : (
                        <span className="flex items-center gap-1 text-zinc-500">
                          <X className="w-4 h-4 text-zinc-600" /> No
                        </span>
                      )}
                    </td>
                    <td className="p-3.5">
                      {c.offlineStandaloneApp ? (
                        <span className="flex items-center gap-1 text-emerald-400 font-bold">
                          <Check className="w-4 h-4" /> Dual iOS & Android HTML
                        </span>
                      ) : (
                        <span className="flex items-center gap-1 text-zinc-500">
                          <X className="w-4 h-4 text-zinc-600" /> Cloud Only
                        </span>
                      )}
                    </td>
                    <td className="p-3.5">
                      {c.watermarkFree ? (
                        <span className="flex items-center gap-1 text-emerald-400">
                          <Check className="w-4 h-4" /> Yes
                        </span>
                      ) : (
                        <span className="flex items-center gap-1 text-zinc-500">
                          <X className="w-4 h-4 text-zinc-600" /> Free tier watermarked
                        </span>
                      )}
                    </td>
                    <td className="p-3.5 font-mono text-zinc-300">
                      {c.resolution}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Selected Platform Deep-Dive Analysis */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Strengths & Weaknesses */}
        <div className="lg:col-span-6 bg-zinc-950 border border-zinc-800/80 rounded-2xl p-5 shadow-xl space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
            <div>
              <h3 className="font-extrabold text-base text-zinc-100">{activeItem.platform}</h3>
              <p className="text-xs text-amber-400 mt-0.5">{activeItem.category}</p>
            </div>
            <span className="px-2.5 py-1 rounded-lg bg-zinc-900 border border-zinc-800 text-[11px] text-zinc-400">
              {activeItem.creditModel}
            </span>
          </div>

          <div className="space-y-3">
            <div>
              <div className="text-xs font-bold text-emerald-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <Check className="w-3.5 h-3.5" />
                <span>Identified Strengths</span>
              </div>
              <ul className="space-y-1.5">
                {activeItem.strengths.map((str, idx) => (
                  <li key={idx} className="text-xs text-zinc-300 flex items-start gap-2">
                    <span className="text-emerald-400 font-bold shrink-0">·</span>
                    <span>{str}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="pt-2 border-t border-zinc-850">
              <div className="text-xs font-bold text-red-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <AlertCircle className="w-3.5 h-3.5" />
                <span>Identified Weaknesses & User Complaints</span>
              </div>
              <ul className="space-y-1.5">
                {activeItem.weaknesses.map((wk, idx) => (
                  <li key={idx} className="text-xs text-zinc-300 flex items-start gap-2">
                    <span className="text-red-400 font-bold shrink-0">·</span>
                    <span>{wk}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>

        {/* Right: Missing Gaps & Motionai Competitive Solution */}
        <div className="lg:col-span-6 bg-zinc-950 border border-zinc-800/80 rounded-2xl p-5 shadow-xl space-y-4 flex flex-col justify-between">
          <div className="space-y-4">
            <div>
              <div className="text-xs font-bold text-amber-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <Zap className="w-3.5 h-3.5" />
                <span>User Desired Missing Gaps</span>
              </div>
              <ul className="space-y-2">
                {activeItem.missingGaps.map((gap, idx) => (
                  <li key={idx} className="p-2.5 rounded-xl bg-zinc-900/60 border border-zinc-800 text-xs text-zinc-200">
                    {gap}
                  </li>
                ))}
              </ul>
            </div>

            <div className="p-4 rounded-xl bg-gradient-to-br from-amber-500/15 via-yellow-600/10 to-transparent border border-amber-500/40 space-y-2">
              <div className="flex items-center gap-2 font-extrabold text-sm text-amber-300">
                <Trophy className="w-4 h-4 text-amber-400" />
                <span>How Motionai Solves This</span>
              </div>
              <p className="text-xs text-zinc-200 leading-relaxed">
                {activeItem.motionaiAdvantage}
              </p>
            </div>
          </div>

          <div className="text-[11px] text-zinc-500 border-t border-zinc-850 pt-3">
            Source: Cross-platform workflow analysis of runwayml.com, pika.art, synthesys.io, lumaai.com, and user community pain points.
          </div>
        </div>
      </div>
    </div>
  );
};
