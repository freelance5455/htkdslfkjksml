import React, { useRef, useEffect } from 'react';
import { EditorClip, AspectRatio, CaptionItem, CaptionStyleConfig, AudioDuckingConfig } from '../../types';
import { 
  Play, 
  Pause, 
  RotateCcw, 
  Volume2, 
  VolumeX, 
  Maximize2, 
  SkipBack, 
  SkipForward,
  Scissors,
  Mic
} from 'lucide-react';

interface VideoViewportProps {
  currentTime: number;
  duration: number;
  isPlaying: boolean;
  onTogglePlay: () => void;
  onSeek: (time: number) => void;
  aspectRatio: AspectRatio;
  onAspectRatioChange: (ratio: AspectRatio) => void;
  clips: EditorClip[];
  selectedClipId: string | null;
  captions?: CaptionItem[];
  captionStyle?: CaptionStyleConfig;
  onSplitClip?: () => void;
  audioDucking?: AudioDuckingConfig;
}

export const VideoViewport: React.FC<VideoViewportProps> = ({
  currentTime,
  duration,
  isPlaying,
  onTogglePlay,
  onSeek,
  aspectRatio,
  onAspectRatioChange,
  clips,
  selectedClipId,
  captions = [],
  captionStyle = {
    preset: 'dark-gold',
    fontSize: 22,
    positionY: 82,
    color: '#FCD34D',
    enabled: true,
  },
  onSplitClip,
  audioDucking,
}) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const pipVideoRef = useRef<HTMLVideoElement | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [isMuted, setIsMuted] = React.useState(false);

  // Identify active primary video clip at currentTime
  const activeMainClip = clips.find(
    (c) => c.trackId === 'track-v1' && currentTime >= c.startTime && currentTime <= c.startTime + c.duration
  );

  // Identify active PiP / secondary video clip at currentTime
  const activePipClip = clips.find(
    (c) => c.trackId === 'track-v2' && currentTime >= c.startTime && currentTime <= c.startTime + c.duration
  );

  // Identify active text overlay clip at currentTime
  const activeTextClips = clips.filter(
    (c) => c.trackId === 'track-txt' && currentTime >= c.startTime && currentTime <= c.startTime + c.duration
  );

  // Identify active audio clip at currentTime
  const activeAudioClip = clips.find(
    (c) => c.trackId === 'track-a1' && currentTime >= c.startTime && currentTime <= c.startTime + c.duration
  );

  // Identify active auto-generated SRT caption at currentTime
  const activeCaption = captionStyle?.enabled
    ? captions.find((cap) => currentTime >= cap.startTime && currentTime <= cap.endTime)
    : null;

  // Detect if any voiceover clip is active at currentTime (for AI Audio Ducking)
  const activeVoiceover = clips.find(
    (c) =>
      (c.trackId === (audioDucking?.targetVoiceTrackId || 'track-a3') ||
        c.type === 'voiceover' ||
        c.title.toLowerCase().includes('voice')) &&
      currentTime >= c.startTime &&
      currentTime <= c.startTime + c.duration
  );
  const isDuckingActive = Boolean(audioDucking?.enabled && activeVoiceover);

  // Sync main video playback with timeline currentTime
  useEffect(() => {
    if (!videoRef.current || !activeMainClip) return;

    const clipOffset = (currentTime - activeMainClip.startTime) + activeMainClip.trimStart;
    const clampedOffset = Math.max(0, Math.min(clipOffset, activeMainClip.sourceDuration));

    if (Math.abs(videoRef.current.currentTime - clampedOffset) > 0.3) {
      videoRef.current.currentTime = clampedOffset;
    }

    if (isPlaying) {
      videoRef.current.play().catch(() => {});
    } else {
      videoRef.current.pause();
    }
  }, [currentTime, isPlaying, activeMainClip]);

  // Sync PiP video playback
  useEffect(() => {
    if (!pipVideoRef.current || !activePipClip) return;

    const clipOffset = (currentTime - activePipClip.startTime) + activePipClip.trimStart;
    const clampedOffset = Math.max(0, Math.min(clipOffset, activePipClip.sourceDuration));

    if (Math.abs(pipVideoRef.current.currentTime - clampedOffset) > 0.3) {
      pipVideoRef.current.currentTime = clampedOffset;
    }

    if (isPlaying) {
      pipVideoRef.current.play().catch(() => {});
    } else {
      pipVideoRef.current.pause();
    }
  }, [currentTime, isPlaying, activePipClip]);

  // Sync audio soundtrack playback
  useEffect(() => {
    if (!audioRef.current || !activeAudioClip || !activeAudioClip.mediaUrl.startsWith('http')) return;

    const audioOffset = (currentTime - activeAudioClip.startTime) + activeAudioClip.trimStart;
    if (Math.abs(audioRef.current.currentTime - audioOffset) > 0.3) {
      audioRef.current.currentTime = Math.max(0, audioOffset);
    }

    if (isPlaying && !activeAudioClip.muted && !isMuted) {
      let finalVolume = Math.min(1, Math.max(0, activeAudioClip.volume));
      if (isDuckingActive && audioDucking) {
        finalVolume = finalVolume * (audioDucking.duckingAmount / 100);
      }
      audioRef.current.volume = Math.max(0, Math.min(1, finalVolume));
      audioRef.current.play().catch(() => {});
    } else {
      audioRef.current.pause();
    }
  }, [currentTime, isPlaying, activeAudioClip, isMuted, isDuckingActive, audioDucking]);

  // Compute CSS filter string for active main clip
  const getFilterStyle = (clip?: EditorClip): string => {
    if (!clip) return 'none';
    const filters: string[] = [];

    // Filter preset
    if (clip.filter) {
      const intensity = clip.filter.intensity / 100;
      switch (clip.filter.preset) {
        case 'cinematic-gold':
          filters.push(`sepia(${0.35 * intensity}) saturate(${1 + 0.4 * intensity}) contrast(${1 + 0.15 * intensity})`);
          break;
        case 'golden-hour':
          filters.push(`sepia(${0.5 * intensity}) saturate(${1 + 0.5 * intensity}) brightness(${1 + 0.1 * intensity})`);
          break;
        case 'cyberpunk':
          filters.push(`hue-rotate(${260 * intensity}deg) saturate(${1 + 0.6 * intensity}) contrast(${1 + 0.25 * intensity})`);
          break;
        case 'vintage-film':
          filters.push(`sepia(${0.45 * intensity}) contrast(${1 + 0.2 * intensity}) brightness(0.95)`);
          break;
        case 'noir':
          filters.push(`grayscale(${1 * intensity}) contrast(${1 + 0.4 * intensity})`);
          break;
        case 'vhs':
          filters.push(`contrast(${1 + 0.3 * intensity}) saturate(${1 + 0.5 * intensity}) hue-rotate(15deg)`);
          break;
        case 'dreamy':
          filters.push(`brightness(${1 + 0.15 * intensity}) contrast(${0.9 + 0.1 * intensity}) saturate(${1 + 0.2 * intensity})`);
          break;
        case 'chromatic':
          filters.push(`contrast(1.2) saturate(1.4)`);
          break;
      }
    }

    // Custom 3D LUT (.cube)
    if (clip.customLutCssFilter) {
      filters.push(clip.customLutCssFilter);
    }

    // Color grading adjustments
    if (clip.colorGrade) {
      const { exposure, brightness, contrast, saturation, temperature, tint } = clip.colorGrade;
      const bVal = 1 + (brightness + exposure) / 100;
      const cVal = 1 + contrast / 100;
      const sVal = saturation / 100;
      filters.push(`brightness(${bVal}) contrast(${cVal}) saturate(${sVal})`);
      if (temperature > 0) {
        filters.push(`sepia(${temperature / 250})`);
      } else if (temperature < 0) {
        filters.push(`hue-rotate(${temperature / 4}deg)`);
      }
      if (tint !== 0) {
        filters.push(`hue-rotate(${tint / 5}deg)`);
      }
    }

    return filters.length > 0 ? filters.join(' ') : 'none';
  };

  // Format time to 00:00:00:00 (Hours:Minutes:Seconds:Frames)
  const formatTimecode = (sec: number) => {
    const totalSecs = Math.max(0, sec);
    const hrs = Math.floor(totalSecs / 3600);
    const mins = Math.floor((totalSecs % 3600) / 60);
    const secs = Math.floor(totalSecs % 60);
    const frames = Math.floor((totalSecs % 1) * 30);
    return `${String(hrs).padStart(2, '0')}:${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}:${String(frames).padStart(2, '0')}`;
  };

  // Aspect Ratio CSS classes
  const aspectClassMap: Record<AspectRatio, string> = {
    '16:9': 'aspect-video max-w-[800px]',
    '9:16': 'aspect-[9/16] max-h-[460px]',
    '1:1': 'aspect-square max-h-[460px]',
    '4:5': 'aspect-[4/5] max-h-[460px]',
    '21:9': 'aspect-[21/9] max-w-[860px]',
    '3:4': 'aspect-[3/4] max-h-[460px]',
    '4:3': 'aspect-[4/3] max-h-[460px]',
  };

  return (
    <div className="flex flex-col bg-zinc-950 border border-zinc-800/80 rounded-2xl overflow-hidden shadow-xl">
      {/* Top Viewport Header Toolbar */}
      <div className="flex items-center justify-between px-4 py-2 border-b border-zinc-800/80 bg-zinc-900/60 text-xs">
        <div className="flex items-center gap-2">
          <span className="font-semibold text-zinc-300">Composite Preview</span>
          {activeMainClip && (
            <span className="text-[11px] text-amber-400/90 font-mono truncate max-w-[180px]">
              [{activeMainClip.title}]
            </span>
          )}
          {activeMainClip?.customLutName && (
            <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40 truncate max-w-[170px]">
              LUT: {activeMainClip.customLutName}
            </span>
          )}
        </div>

        {/* Aspect Ratio Switcher */}
        <div className="flex items-center gap-1 bg-zinc-950/70 p-0.5 rounded-lg border border-zinc-800">
          {(['16:9', '9:16', '1:1', '4:5', '21:9'] as AspectRatio[]).map((ratio) => (
            <button
              key={ratio}
              onClick={() => onAspectRatioChange(ratio)}
              className={`px-2 py-0.5 rounded text-[11px] font-medium transition-all ${
                aspectRatio === ratio
                  ? 'bg-amber-500 text-zinc-950 font-bold shadow-sm'
                  : 'text-zinc-400 hover:text-amber-300 hover:bg-zinc-800/60'
              }`}
            >
              {ratio}
            </button>
          ))}
        </div>
      </div>

      {/* Video Canvas Stage */}
      <div className="relative flex items-center justify-center p-4 bg-zinc-950/80 min-h-[340px] max-h-[460px] overflow-hidden">
        <div className={`relative w-full ${aspectClassMap[aspectRatio]} bg-black rounded-xl overflow-hidden border border-zinc-800/90 shadow-2xl flex items-center justify-center`}>
          {activeMainClip ? (
            <video
              ref={videoRef}
              src={activeMainClip.mediaUrl}
              className="w-full h-full object-cover transition-all duration-150"
              style={{
                filter: getFilterStyle(activeMainClip),
                transform: `scale(${activeMainClip.transform?.scale || 1}) rotate(${activeMainClip.transform?.rotation || 0}deg) translate(${activeMainClip.transform?.x || 0}%, ${activeMainClip.transform?.y || 0}%) ${activeMainClip.transform?.flippedHorizontal ? 'scaleX(-1)' : ''}`,
                opacity: activeMainClip.transform?.opacity ?? 1,
              }}
              playsInline
              muted={isMuted || activeMainClip.muted}
              loop
            />
          ) : (
            <div className="flex flex-col items-center justify-center text-zinc-500 gap-2 p-6 text-center">
              <span className="text-amber-500/80 text-2xl font-mono">00:00:00</span>
              <p className="text-xs text-zinc-400">Playhead is outside active video clips.</p>
              <p className="text-[11px] text-zinc-600">Scrub playhead or insert a video clip below.</p>
            </div>
          )}

          {/* Picture-in-Picture (PiP / Video Track 2) Overlay */}
          {activePipClip && (
            <div
              className="absolute pointer-events-none rounded-lg overflow-hidden border border-amber-500/40 shadow-xl transition-all duration-150"
              style={{
                width: '35%',
                aspectRatio: '16/9',
                right: '5%',
                top: '5%',
                transform: `scale(${activePipClip.transform?.scale || 1}) rotate(${activePipClip.transform?.rotation || 0}deg) translate(${activePipClip.transform?.x || 0}%, ${activePipClip.transform?.y || 0}%)`,
                opacity: activePipClip.transform?.opacity ?? 0.9,
                filter: getFilterStyle(activePipClip),
              }}
            >
              <video
                ref={pipVideoRef}
                src={activePipClip.mediaUrl}
                className="w-full h-full object-cover"
                playsInline
                muted
                loop
              />
            </div>
          )}

          {/* Active Text & Caption Overlays */}
          {activeTextClips.map((textClip) => {
            const overlay = textClip.textOverlay;
            if (!overlay) return null;

            return (
              <div
                key={textClip.id}
                className="absolute pointer-events-none text-center px-4 py-1.5 rounded-lg transition-all duration-200"
                style={{
                  left: `${overlay.x}%`,
                  top: `${overlay.y}%`,
                  transform: 'translate(-50%, -50%)',
                  color: overlay.color || '#d4af37',
                  backgroundColor: overlay.backgroundColor || 'transparent',
                  fontFamily: overlay.fontFamily || 'Inter',
                  fontSize: `${overlay.fontSize || 24}px`,
                  fontWeight: 800,
                  letterSpacing: '0.04em',
                  textShadow: '0 2px 10px rgba(0,0,0,0.85), 0 0 16px rgba(212,175,55,0.4)',
                }}
              >
                {overlay.text}
              </div>
            );
          })}

          {/* Active Auto-Generated SRT Caption Overlay */}
          {activeCaption && (
            <div
              className="absolute pointer-events-none w-full px-6 flex justify-center text-center transition-all duration-150 z-30"
              style={{
                top: `${captionStyle?.positionY || 82}%`,
                transform: 'translateY(-50%)',
              }}
            >
              <div
                className={`max-w-[85%] inline-block rounded-xl transition-all duration-150 ${
                  captionStyle?.preset === 'boxed'
                    ? 'bg-black/85 px-4 py-2 border border-amber-500/40 shadow-2xl'
                    : captionStyle?.preset === 'karaoke'
                    ? 'px-3 py-1 bg-amber-950/70 border border-amber-400/50 shadow-lg'
                    : captionStyle?.preset === 'neon'
                    ? 'px-3 py-1 bg-black/50 shadow-[0_0_20px_rgba(245,158,11,0.6)]'
                    : 'px-2 py-0.5'
                }`}
                style={{
                  fontSize: `${captionStyle?.fontSize || 22}px`,
                  fontFamily: 'Inter, sans-serif',
                  fontWeight: 800,
                  letterSpacing: '0.02em',
                  color: captionStyle?.color || (captionStyle?.preset === 'minimal-white' ? '#FFFFFF' : '#FCD34D'),
                  textShadow:
                    captionStyle?.preset === 'dark-gold'
                      ? '0 2px 8px rgba(0,0,0,0.95), 0 0 14px rgba(212,175,55,0.85), 0 0 28px rgba(245,158,11,0.5)'
                      : captionStyle?.preset === 'neon'
                      ? '0 0 10px #F59E0B, 0 0 20px #D97706, 0 2px 6px #000000'
                      : captionStyle?.preset === 'minimal-white'
                      ? '0 2px 4px rgba(0,0,0,0.95), -1px -1px 0 #000, 1px -1px 0 #000, -1px 1px 0 #000, 1px 1px 0 #000'
                      : '0 2px 6px rgba(0,0,0,0.9)',
                }}
              >
                {activeCaption.text}
              </div>
            </div>
          )}

          {/* AI Audio Ducking Live Active Indicator Badge */}
          {isDuckingActive && (
            <div className="absolute top-3 left-3 z-30 flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-black/80 border border-amber-500/60 text-amber-300 font-mono text-[11px] font-bold shadow-xl backdrop-blur-md animate-pulse pointer-events-none">
              <Mic className="w-3.5 h-3.5 text-amber-400 animate-bounce" />
              <span>AI Ducking: -{Math.round(Math.abs(20 * Math.log10((audioDucking?.duckingAmount || 20) / 100)))}dB (Voice Active)</span>
            </div>
          )}

          {/* AI Smooth Motion Live Active Indicator Badge */}
          {activeMainClip?.smoothMotion?.enabled && (
            <div className="absolute top-3 right-3 z-30 flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-black/80 border border-emerald-500/60 text-emerald-300 font-mono text-[11px] font-bold shadow-xl backdrop-blur-md pointer-events-none">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping inline-block" />
              <span>{activeMainClip.smoothMotion.targetFps} FPS Optical Flow ({activeMainClip.speed}x)</span>
            </div>
          )}

          {/* Hidden Soundtrack audio element for timeline playback */}
          {activeAudioClip && activeAudioClip.mediaUrl.startsWith('http') && (
            <audio ref={audioRef} src={activeAudioClip.mediaUrl} loop />
          )}

          {/* Vignette Overlay if enabled */}
          {activeMainClip?.colorGrade?.vignette ? (
            <div
              className="absolute inset-0 pointer-events-none"
              style={{
                boxShadow: `inset 0 0 ${activeMainClip.colorGrade.vignette * 1.5}px rgba(0,0,0,0.85)`,
              }}
            />
          ) : null}
        </div>
      </div>

      {/* Bottom Transport Controls Bar */}
      <div className="flex items-center justify-between px-4 py-3 bg-zinc-900/90 border-t border-zinc-800/80">
        {/* Left: Timecode */}
        <div className="flex items-center gap-3">
          <div className="font-mono text-sm font-bold text-amber-400 bg-zinc-950 px-2.5 py-1 rounded-lg border border-amber-500/20 shadow-inner">
            {formatTimecode(currentTime)}
          </div>
          <span className="text-zinc-600 text-xs">/</span>
          <div className="font-mono text-xs text-zinc-400">
            {formatTimecode(duration)}
          </div>
        </div>

        {/* Center: Playback Buttons */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => onSeek(Math.max(0, currentTime - 1))}
            title="Step Back 1s"
            className="p-1.5 rounded-lg text-zinc-400 hover:text-amber-400 hover:bg-zinc-800 transition-colors"
          >
            <SkipBack className="w-4 h-4" />
          </button>

          <button
            onClick={onTogglePlay}
            className="w-10 h-10 rounded-full bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-amber-400 hover:to-yellow-500 flex items-center justify-center text-zinc-950 font-black shadow-lg shadow-amber-500/25 transition-transform hover:scale-105"
            title={isPlaying ? 'Pause (Space)' : 'Play (Space)'}
          >
            {isPlaying ? (
              <Pause className="w-4 h-4 fill-zinc-950" />
            ) : (
              <Play className="w-4 h-4 fill-zinc-950 translate-x-0.5" />
            )}
          </button>

          <button
            onClick={() => onSeek(Math.min(duration, currentTime + 1))}
            title="Step Forward 1s"
            className="p-1.5 rounded-lg text-zinc-400 hover:text-amber-400 hover:bg-zinc-800 transition-colors"
          >
            <SkipForward className="w-4 h-4" />
          </button>
        </div>

        {/* Right: Split Tool, Audio Volume & Fullscreen */}
        <div className="flex items-center gap-2">
          {onSplitClip && (
            <button
              onClick={onSplitClip}
              title="Split selected clip at current playhead position (S)"
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-zinc-950 hover:bg-zinc-800 text-amber-400 border border-amber-500/40 hover:border-amber-400 text-xs font-bold transition-all shadow-sm active:scale-95 group"
            >
              <Scissors className="w-3.5 h-3.5 group-hover:rotate-12 transition-transform" />
              <span>Split</span>
            </button>
          )}

          <button
            onClick={() => setIsMuted(!isMuted)}
            className={`p-1.5 rounded-lg border transition-colors ${
              isMuted
                ? 'text-red-400 border-red-500/30 bg-red-500/10'
                : 'text-zinc-400 hover:text-amber-400 border-zinc-800 bg-zinc-950'
            }`}
            title={isMuted ? 'Unmute' : 'Mute'}
          >
            {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
          </button>

          <button
            onClick={() => {
              if (document.fullscreenElement) {
                document.exitFullscreen().catch(() => {});
              } else {
                document.documentElement.requestFullscreen().catch(() => {});
              }
            }}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-amber-400 hover:bg-zinc-800 border border-zinc-800 transition-colors"
            title="Toggle Fullscreen"
          >
            <Maximize2 className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
