import React, { useState } from 'react';
import { 
  EditorClip, 
  TransitionType, 
  FilterPreset, 
  ColorGradeSettings, 
  TextOverlaySettings, 
  TransformSettings 
} from '../../types';
import { 
  Sparkles, 
  Palette, 
  Sliders, 
  Type, 
  Volume2, 
  Mic, 
  Move, 
  Download, 
  Play, 
  Plus, 
  RotateCcw,
  Check,
  Wand2,
  RefreshCw,
  Zap,
  Gauge,
  Film,
  FastForward,
  Activity,
  Layers
} from 'lucide-react';
import { soundEngine } from '../../utils/transitionSound';
import { SOUND_EFFECTS } from '../../data/sampleClips';
import { generateAIVoiceover } from '../../services/api';
import { CustomLutManager } from './CustomLutManager';
import confetti from 'canvas-confetti';

interface EditorInspectorProps {
  selectedClip: EditorClip | null;
  onUpdateClip: (clipId: string, updates: Partial<EditorClip>) => void;
  onAddSFXClip: (sfxName: string, sfxUrl: string) => void;
  onAddVoiceoverClip: (text: string, voiceUrl: string) => void;
  onExportProject: () => void;
}

export const EditorInspector: React.FC<EditorInspectorProps> = ({
  selectedClip,
  onUpdateClip,
  onAddSFXClip,
  onAddVoiceoverClip,
  onExportProject,
}) => {
  const [activeTab, setActiveTab] = useState<
    'transitions' | 'filters' | 'color' | 'luts' | 'text' | 'audio' | 'voiceover' | 'motion' | 'export'
  >('transitions');

  // AI Voiceover generator state
  const [voiceText, setVoiceText] = useState('In a world shaped by intelligence, motion defines cinema.');
  const [voiceName, setVoiceName] = useState('Kore');
  const [isGeneratingVoice, setIsGeneratingVoice] = useState(false);

  // Auto-Grade & Smooth Motion states
  const [isAnalyzingAutoGrade, setIsAnalyzingAutoGrade] = useState<boolean>(false);
  const [isInterpolatingMotion, setIsInterpolatingMotion] = useState<boolean>(false);
  const [autoGradeNotification, setAutoGradeNotification] = useState<string | null>(null);

  // Auto-Grade Handler: analyzes frame histograms & dynamic range, applies cinematic Rec.709 LUT & contrast
  const handleAutoGrade = async () => {
    if (!selectedClip) return;
    setIsAnalyzingAutoGrade(true);
    soundEngine.playWhoosh(0.2);
    await new Promise((resolve) => setTimeout(resolve, 700));

    onUpdateClip(selectedClip.id, {
      colorGrade: {
        exposure: 4,
        brightness: 2,
        contrast: 18,
        saturation: 118,
        temperature: 15, // dark gold warmth
        tint: -4,        // teal/orange contrast
        vignette: 22,
        sharpness: 10,
      },
      filter: {
        preset: 'cinematic-gold',
        intensity: 85,
      },
    });

    setIsAnalyzingAutoGrade(false);
    setAutoGradeNotification('Auto-Grade applied: Cinematic Dark Gold Rec.709 LUT');
    setTimeout(() => setAutoGradeNotification(null), 3000);
    soundEngine.playImpact();
    confetti({ particleCount: 35, spread: 60 });
  };

  // AI Smooth Motion Handler: uses optical flow frame interpolation to synthesize frames and increase fluid framerates
  const handleApplySmoothMotion = async (targetFps: 60 | 120, targetSpeed: number) => {
    if (!selectedClip) return;
    setIsInterpolatingMotion(true);
    soundEngine.playWhoosh(0.25);
    await new Promise((resolve) => setTimeout(resolve, 800));

    const sourceDuration = selectedClip.sourceDuration || selectedClip.duration;
    const newDuration = Math.round((sourceDuration / targetSpeed) * 10) / 10;

    onUpdateClip(selectedClip.id, {
      speed: targetSpeed,
      duration: newDuration,
      smoothMotion: {
        enabled: true,
        targetFps: targetFps,
        mode: 'optical-flow',
        opticalFlowIntensity: 92,
      },
    });

    setIsInterpolatingMotion(false);
    soundEngine.playImpact();
    confetti({ particleCount: 40, spread: 70 });
  };

  // Transitions list
  const transitionOptions: { id: TransitionType; label: string; desc: string }[] = [
    { id: 'none', label: 'None', desc: 'Direct hard cut' },
    { id: 'dissolve', label: 'Cross Dissolve', desc: 'Smooth cinematic blend' },
    { id: 'whip-left', label: 'Whip Pan Left', desc: 'Fast directional swish' },
    { id: 'whip-right', label: 'Whip Pan Right', desc: 'Fast directional swish' },
    { id: 'zoom-in', label: 'Zoom Push', desc: 'Dynamic scale burst' },
    { id: 'zoom-out', label: 'Zoom Pull', desc: 'Dramatic focal release' },
    { id: 'flash', label: 'White Flash', desc: 'High-energy optical flare' },
    { id: 'glitch', label: 'Digital Glitch', desc: 'Sci-fi cyberpunk distortion' },
    { id: 'burn', label: 'Film Burn', desc: 'Vintage warm flare wash' },
    { id: 'slide-up', label: 'Slide Up', desc: 'Modern vertical transition' },
  ];

  // Filters list
  const filterOptions: { id: FilterPreset; label: string; desc: string; previewColor: string }[] = [
    { id: 'none', label: 'Natural / Raw', desc: 'Clean uncolored footage', previewColor: 'from-zinc-700 to-zinc-800' },
    { id: 'cinematic-gold', label: 'Cinematic Dark Gold', desc: 'Hollywood gold rim lighting & deep amber shadow', previewColor: 'from-amber-600 to-yellow-600' },
    { id: 'golden-hour', label: 'Golden Hour Sunset', desc: 'Radiant warm honey radiance', previewColor: 'from-amber-500 to-orange-600' },
    { id: 'cyberpunk', label: 'Cyberpunk Neon', desc: 'High-voltage purple & magenta neon', previewColor: 'from-fuchsia-600 to-purple-800' },
    { id: 'vintage-film', label: 'Vintage 1970s Film', desc: 'Sepia warmth and film emulation', previewColor: 'from-yellow-700 to-amber-900' },
    { id: 'noir', label: 'Film Noir B&W', desc: 'High contrast black and white shadows', previewColor: 'from-zinc-900 to-zinc-600' },
    { id: 'vhs', label: 'VHS Retro Tape', desc: 'Analog saturation and CRT warmth', previewColor: 'from-red-600 to-amber-700' },
    { id: 'dreamy', label: 'Dreamy Soft Glow', desc: 'Diffused highlights and pastel radiance', previewColor: 'from-amber-300 to-rose-400' },
    { id: 'chromatic', label: 'Chromatic Flare', desc: 'Prismatic edge contrast', previewColor: 'from-amber-500 to-emerald-600' },
  ];

  // Helper to handle color grade change
  const handleColorChange = (key: keyof ColorGradeSettings, val: number) => {
    if (!selectedClip) return;
    const currentGrade = selectedClip.colorGrade || {
      exposure: 0,
      brightness: 0,
      contrast: 0,
      saturation: 100,
      temperature: 0,
      tint: 0,
      vignette: 0,
      sharpness: 0,
    };
    onUpdateClip(selectedClip.id, {
      colorGrade: { ...currentGrade, [key]: val },
    });
  };

  // Helper to reset color grading
  const resetColorGrade = () => {
    if (!selectedClip) return;
    onUpdateClip(selectedClip.id, {
      colorGrade: {
        exposure: 0,
        brightness: 0,
        contrast: 0,
        saturation: 100,
        temperature: 0,
        tint: 0,
        vignette: 0,
        sharpness: 0,
      },
    });
  };

  // Handle Voiceover Generation
  const handleGenerateVoiceover = async () => {
    if (!voiceText.trim()) return;
    setIsGeneratingVoice(true);
    try {
      const audioUrl = await generateAIVoiceover(voiceText, voiceName);
      if (audioUrl) {
        onAddVoiceoverClip(`AI Voice: "${voiceText.slice(0, 20)}..."`, audioUrl);
        confetti({ particleCount: 40, spread: 60, origin: { y: 0.8 } });
      } else {
        // Fallback simulation audio cue
        soundEngine.playWhoosh(0.5);
        onAddVoiceoverClip(`Voice (${voiceName}): "${voiceText.slice(0, 24)}..."`, 'voice://synthesized');
      }
    } catch {
      onAddVoiceoverClip(`Voice: "${voiceText.slice(0, 24)}..."`, 'voice://fallback');
    } finally {
      setIsGeneratingVoice(false);
    }
  };

  const navTabs = [
    { id: 'transitions', label: 'Transitions', icon: Sparkles },
    { id: 'filters', label: 'Effects', icon: Palette },
    { id: 'color', label: 'Color Grade', icon: Sliders },
    { id: 'luts', label: 'Custom LUTs', icon: Layers },
    { id: 'text', label: 'Text Overlay', icon: Type },
    { id: 'audio', label: 'Audio & SFX', icon: Volume2 },
    { id: 'voiceover', label: 'AI Voice', icon: Mic },
    { id: 'motion', label: 'Motion & Speed', icon: FastForward },
    { id: 'export', label: 'Export', icon: Download },
  ];

  return (
    <div className="flex flex-col bg-zinc-950 border border-zinc-800/80 rounded-2xl overflow-hidden shadow-xl h-full">
      {/* Tab Header Navigation */}
      <div className="flex items-center gap-1 p-2 bg-zinc-900/80 border-b border-zinc-800 overflow-x-auto scrollbar-none">
        {navTabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
                isActive
                  ? 'bg-amber-500 text-zinc-950 shadow-md shadow-amber-500/20'
                  : 'text-zinc-400 hover:text-amber-300 hover:bg-zinc-800/60'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Inspector Body Content */}
      <div className="flex-1 p-4 overflow-y-auto space-y-4 text-xs">
        {/* TRANSITIONS PANEL */}
        {activeTab === 'transitions' && (
          <div className="space-y-4">
            <div>
              <h3 className="font-bold text-sm text-zinc-100 flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-amber-400" />
                <span>Cinematic Clip Transitions</span>
              </h3>
              <p className="text-zinc-400 mt-1">
                Select a transition for {selectedClip ? `"${selectedClip.title}"` : 'selected clip'}. Includes synchronized WebAudio sound cues!
              </p>
            </div>

            {selectedClip ? (
              <>
                <div className="grid grid-cols-2 gap-2">
                  {transitionOptions.map((opt) => {
                    const isSelected = (selectedClip.transition?.type || 'none') === opt.id;
                    return (
                      <button
                        key={opt.id}
                        onClick={() => {
                          onUpdateClip(selectedClip.id, {
                            transition: {
                              type: opt.id,
                              duration: selectedClip.transition?.duration || 0.6,
                            },
                          });
                          soundEngine.playForTransition(opt.id);
                        }}
                        className={`flex flex-col items-start p-2.5 rounded-xl border text-left transition-all ${
                          isSelected
                            ? 'bg-amber-500/15 border-amber-400 text-amber-300 shadow-sm'
                            : 'bg-zinc-900/60 border-zinc-800 text-zinc-300 hover:border-zinc-700 hover:bg-zinc-900'
                        }`}
                      >
                        <div className="flex items-center justify-between w-full font-bold">
                          <span>{opt.label}</span>
                          {isSelected && <Check className="w-3.5 h-3.5 text-amber-400" />}
                        </div>
                        <span className="text-[11px] text-zinc-400 mt-1">{opt.desc}</span>
                      </button>
                    );
                  })}
                </div>

                {selectedClip.transition && selectedClip.transition.type !== 'none' && (
                  <div className="bg-zinc-900/70 p-3 rounded-xl border border-zinc-800 space-y-2 mt-2">
                    <div className="flex items-center justify-between font-semibold">
                      <span className="text-zinc-300">Transition Duration</span>
                      <span className="text-amber-400 font-mono">
                        {selectedClip.transition.duration.toFixed(1)}s
                      </span>
                    </div>
                    <input
                      type="range"
                      min="0.2"
                      max="2.0"
                      step="0.1"
                      value={selectedClip.transition.duration}
                      onChange={(e) =>
                        onUpdateClip(selectedClip.id, {
                          transition: {
                            ...selectedClip.transition!,
                            duration: parseFloat(e.target.value),
                          },
                        })
                      }
                      className="w-full accent-amber-500"
                    />
                    <button
                      onClick={() => soundEngine.playForTransition(selectedClip.transition!.type)}
                      className="w-full py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-750 text-amber-400 font-semibold border border-zinc-700 flex items-center justify-center gap-1.5 transition-colors"
                    >
                      <Play className="w-3 h-3 fill-amber-400" />
                      <span>Test Transition Sound Cue</span>
                    </button>
                  </div>
                )}
              </>
            ) : (
              <div className="p-6 text-center text-zinc-500 bg-zinc-900/30 rounded-xl border border-zinc-850">
                Please select a clip on the timeline to apply transitions.
              </div>
            )}
          </div>
        )}

        {/* EFFECTS & FILTERS PANEL */}
        {activeTab === 'filters' && (
          <div className="space-y-4">
            <div>
              <h3 className="font-bold text-sm text-zinc-100 flex items-center gap-2">
                <Palette className="w-4 h-4 text-amber-400" />
                <span>Visual Effects & LUT Presets</span>
              </h3>
              <p className="text-zinc-400 mt-1">
                Apply master cinema color grades and effects directly on the composite preview.
              </p>
            </div>

            {selectedClip ? (
              <>
                {/* Custom .cube LUT Manager quick entry */}
                <div className="flex items-center justify-between p-2.5 rounded-xl bg-gradient-to-r from-amber-500/15 via-yellow-500/10 to-transparent border border-amber-500/35">
                  <div className="flex items-center gap-2">
                    <Layers className="w-4 h-4 text-amber-400" />
                    <div>
                      <div className="text-xs font-bold text-zinc-100">
                        {selectedClip.customLutName ? `Custom LUT: ${selectedClip.customLutName}` : 'Custom .cube 3D LUTs'}
                      </div>
                      <div className="text-[10px] text-zinc-400">
                        Upload & manage .cube files from local gallery
                      </div>
                    </div>
                  </div>
                  <button
                    onClick={() => setActiveTab('luts')}
                    className="px-2.5 py-1 rounded-lg bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold text-xs shadow-sm transition-colors shrink-0"
                  >
                    Open LUT Manager
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {filterOptions.map((opt) => {
                    const isSelected = (selectedClip.filter?.preset || 'none') === opt.id;
                    return (
                      <button
                        key={opt.id}
                        onClick={() =>
                          onUpdateClip(selectedClip.id, {
                            filter: {
                              preset: opt.id,
                              intensity: selectedClip.filter?.intensity || 85,
                            },
                          })
                        }
                        className={`flex items-center gap-3 p-2.5 rounded-xl border text-left transition-all ${
                          isSelected
                            ? 'bg-amber-500/15 border-amber-400 shadow-sm'
                            : 'bg-zinc-900/60 border-zinc-800 hover:border-zinc-700'
                        }`}
                      >
                        <div className={`w-8 h-8 rounded-lg bg-gradient-to-br ${opt.previewColor} shrink-0 border border-white/20`} />
                        <div className="truncate">
                          <div className={`font-bold truncate ${isSelected ? 'text-amber-300' : 'text-zinc-200'}`}>
                            {opt.label}
                          </div>
                          <div className="text-[10px] text-zinc-400 truncate">{opt.desc}</div>
                        </div>
                      </button>
                    );
                  })}
                </div>

                {selectedClip.filter && selectedClip.filter.preset !== 'none' && (
                  <div className="bg-zinc-900/70 p-3 rounded-xl border border-zinc-800 space-y-2 mt-2">
                    <div className="flex items-center justify-between font-semibold">
                      <span className="text-zinc-300">Effect Intensity</span>
                      <span className="text-amber-400 font-mono">
                        {selectedClip.filter.intensity}%
                      </span>
                    </div>
                    <input
                      type="range"
                      min="10"
                      max="100"
                      step="5"
                      value={selectedClip.filter.intensity}
                      onChange={(e) =>
                        onUpdateClip(selectedClip.id, {
                          filter: {
                            ...selectedClip.filter!,
                            intensity: parseInt(e.target.value),
                          },
                        })
                      }
                      className="w-full accent-amber-500"
                    />
                  </div>
                )}
              </>
            ) : (
              <div className="p-6 text-center text-zinc-500 bg-zinc-900/30 rounded-xl border border-zinc-850">
                Please select a clip on the timeline to apply effects.
              </div>
            )}
          </div>
        )}

        {/* COLOR CORRECTION PANEL */}
        {activeTab === 'color' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-bold text-sm text-zinc-100 flex items-center gap-2">
                  <Sliders className="w-4 h-4 text-amber-400" />
                  <span>Color Correction & Grading</span>
                </h3>
                <p className="text-zinc-400 mt-1">
                  Tune exposure, temperature, and contrast with real-time feedback.
                </p>
              </div>
              {selectedClip && (
                <button
                  onClick={resetColorGrade}
                  className="flex items-center gap-1 px-2.5 py-1 rounded bg-zinc-900 hover:bg-zinc-850 text-amber-400 border border-zinc-800 text-[11px] font-semibold transition-colors"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span>Reset</span>
                </button>
              )}
            </div>

            {selectedClip ? (
              <div className="space-y-3 bg-zinc-900/60 p-3.5 rounded-xl border border-zinc-800">
                {/* AI Auto-Grade Button & Banner */}
                <div className="p-3 rounded-xl bg-gradient-to-r from-amber-500/15 via-yellow-500/10 to-transparent border border-amber-500/40 space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5 font-bold text-amber-300 text-xs">
                      <Wand2 className="w-4 h-4 text-amber-400" />
                      <span>Neural Auto-Grade (Rec.709 Cinema)</span>
                    </div>
                    <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-400 border border-amber-500/40">
                      AI Vision
                    </span>
                  </div>
                  <p className="text-[11px] text-zinc-300 leading-snug">
                    Analyzes frame luminance, dynamic range, and skin tones to automatically apply Hollywood color correction, LUT presets, and contrast adjustments.
                  </p>
                  <button
                    onClick={handleAutoGrade}
                    disabled={isAnalyzingAutoGrade}
                    className="w-full py-2.5 px-3 rounded-lg bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-amber-400 hover:to-yellow-500 text-zinc-950 font-bold text-xs shadow-md shadow-amber-500/25 flex items-center justify-center gap-2 transition-all active:scale-95 disabled:opacity-50"
                  >
                    {isAnalyzingAutoGrade ? (
                      <>
                        <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                        <span>Analyzing Dynamic Range & Skin Tones...</span>
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-3.5 h-3.5 fill-zinc-950" />
                        <span>Auto-Grade Selected Clip</span>
                      </>
                    )}
                  </button>
                  {autoGradeNotification && (
                    <div className="text-[11px] font-bold text-emerald-400 text-center animate-pulse pt-0.5">
                      ✓ {autoGradeNotification}
                    </div>
                  )}
                </div>

                {/* Exposure */}
                <div>
                  <div className="flex justify-between font-medium mb-1">
                    <span className="text-zinc-300">Exposure</span>
                    <span className="font-mono text-amber-400">
                      {selectedClip.colorGrade?.exposure || 0}
                    </span>
                  </div>
                  <input
                    type="range"
                    min="-50"
                    max="50"
                    value={selectedClip.colorGrade?.exposure || 0}
                    onChange={(e) => handleColorChange('exposure', parseInt(e.target.value))}
                    className="w-full"
                  />
                </div>

                {/* Contrast */}
                <div>
                  <div className="flex justify-between font-medium mb-1">
                    <span className="text-zinc-300">Contrast</span>
                    <span className="font-mono text-amber-400">
                      {selectedClip.colorGrade?.contrast || 0}
                    </span>
                  </div>
                  <input
                    type="range"
                    min="-50"
                    max="50"
                    value={selectedClip.colorGrade?.contrast || 0}
                    onChange={(e) => handleColorChange('contrast', parseInt(e.target.value))}
                    className="w-full"
                  />
                </div>

                {/* Temperature (Cool to Dark Gold Warmth) */}
                <div>
                  <div className="flex justify-between font-medium mb-1">
                    <span className="text-zinc-300">Temperature (Dark Gold Warmth)</span>
                    <span className="font-mono text-amber-400">
                      {selectedClip.colorGrade?.temperature || 0}
                    </span>
                  </div>
                  <input
                    type="range"
                    min="-50"
                    max="70"
                    value={selectedClip.colorGrade?.temperature || 0}
                    onChange={(e) => handleColorChange('temperature', parseInt(e.target.value))}
                    className="w-full"
                  />
                </div>

                {/* Saturation */}
                <div>
                  <div className="flex justify-between font-medium mb-1">
                    <span className="text-zinc-300">Saturation</span>
                    <span className="font-mono text-amber-400">
                      {selectedClip.colorGrade?.saturation ?? 100}%
                    </span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="200"
                    value={selectedClip.colorGrade?.saturation ?? 100}
                    onChange={(e) => handleColorChange('saturation', parseInt(e.target.value))}
                    className="w-full"
                  />
                </div>

                {/* Vignette */}
                <div>
                  <div className="flex justify-between font-medium mb-1">
                    <span className="text-zinc-300">Vignette</span>
                    <span className="font-mono text-amber-400">
                      {selectedClip.colorGrade?.vignette || 0}%
                    </span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="80"
                    value={selectedClip.colorGrade?.vignette || 0}
                    onChange={(e) => handleColorChange('vignette', parseInt(e.target.value))}
                    className="w-full"
                  />
                </div>
              </div>
            ) : (
              <div className="p-6 text-center text-zinc-500 bg-zinc-900/30 rounded-xl border border-zinc-850">
                Please select a clip on the timeline to adjust color grading.
              </div>
            )}
          </div>
        )}

        {/* CUSTOM 3D LUT MANAGER PANEL */}
        {activeTab === 'luts' && (
          <CustomLutManager
            selectedClip={selectedClip}
            onUpdateClip={onUpdateClip}
          />
        )}

        {/* TEXT OVERLAY & CAPTIONS */}
        {activeTab === 'text' && (
          <div className="space-y-4">
            <div>
              <h3 className="font-bold text-sm text-zinc-100 flex items-center gap-2">
                <Type className="w-4 h-4 text-amber-400" />
                <span>Text Overlays & Kinetic Captions</span>
              </h3>
              <p className="text-zinc-400 mt-1">
                Customize titles, lower-thirds, and typography in dark gold and custom styling.
              </p>
            </div>

            {selectedClip && selectedClip.textOverlay ? (
              <div className="space-y-3 bg-zinc-900/60 p-3.5 rounded-xl border border-zinc-800">
                {/* Text String Input */}
                <div>
                  <label className="block text-zinc-300 font-semibold mb-1">Caption Text</label>
                  <input
                    type="text"
                    value={selectedClip.textOverlay.text}
                    onChange={(e) =>
                      onUpdateClip(selectedClip.id, {
                        textOverlay: {
                          ...selectedClip.textOverlay!,
                          text: e.target.value,
                        },
                      })
                    }
                    className="w-full px-3 py-2 rounded-lg bg-zinc-950 border border-zinc-800 text-zinc-100 focus:border-amber-500 focus:outline-none"
                    placeholder="Enter title text..."
                  />
                </div>

                {/* Font Size & Color */}
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <div className="flex justify-between font-medium mb-1">
                      <span className="text-zinc-300">Font Size</span>
                      <span className="font-mono text-amber-400">
                        {selectedClip.textOverlay.fontSize}px
                      </span>
                    </div>
                    <input
                      type="range"
                      min="16"
                      max="64"
                      value={selectedClip.textOverlay.fontSize}
                      onChange={(e) =>
                        onUpdateClip(selectedClip.id, {
                          textOverlay: {
                            ...selectedClip.textOverlay!,
                            fontSize: parseInt(e.target.value),
                          },
                        })
                      }
                      className="w-full"
                    />
                  </div>

                  <div>
                    <label className="block text-zinc-300 font-semibold mb-1">Color Palette</label>
                    <div className="flex items-center gap-1.5 mt-2">
                      {['#d4af37', '#fef08a', '#ffffff', '#f59e0b', '#10b981', '#ef4444'].map(
                        (col) => (
                          <button
                            key={col}
                            onClick={() =>
                              onUpdateClip(selectedClip.id, {
                                textOverlay: {
                                  ...selectedClip.textOverlay!,
                                  color: col,
                                },
                              })
                            }
                            style={{ backgroundColor: col }}
                            className={`w-6 h-6 rounded-full border-2 transition-transform ${
                              selectedClip.textOverlay?.color === col
                                ? 'border-white scale-110'
                                : 'border-transparent'
                            }`}
                          />
                        )
                      )}
                    </div>
                  </div>
                </div>

                {/* Vertical Position */}
                <div>
                  <div className="flex justify-between font-medium mb-1">
                    <span className="text-zinc-300">Vertical Position (Y)</span>
                    <span className="font-mono text-amber-400">
                      {selectedClip.textOverlay.y}%
                    </span>
                  </div>
                  <input
                    type="range"
                    min="10"
                    max="90"
                    value={selectedClip.textOverlay.y}
                    onChange={(e) =>
                      onUpdateClip(selectedClip.id, {
                        textOverlay: {
                          ...selectedClip.textOverlay!,
                          y: parseInt(e.target.value),
                        },
                      })
                    }
                    className="w-full"
                  />
                </div>
              </div>
            ) : (
              <div className="p-6 text-center text-zinc-500 bg-zinc-900/30 rounded-xl border border-zinc-850">
                Please select a Text clip from the timeline or click "Add Title" on the toolbar.
              </div>
            )}
          </div>
        )}

        {/* AUDIO & SFX PANEL */}
        {activeTab === 'audio' && (
          <div className="space-y-4">
            <div>
              <h3 className="font-bold text-sm text-zinc-100 flex items-center gap-2">
                <Volume2 className="w-4 h-4 text-emerald-400" />
                <span>Audio Manipulation & SFX Library</span>
              </h3>
              <p className="text-zinc-400 mt-1">
                Volume levels, audio speed, background music ducking, and transition sound library.
              </p>
            </div>

            {selectedClip && (
              <div className="bg-zinc-900/60 p-3.5 rounded-xl border border-zinc-800 space-y-3">
                <div className="font-bold text-zinc-200">Clip Volume & Speed: "{selectedClip.title}"</div>
                
                <div>
                  <div className="flex justify-between font-medium mb-1">
                    <span className="text-zinc-300">Volume Level</span>
                    <span className="font-mono text-emerald-400">
                      {Math.round(selectedClip.volume * 100)}%
                    </span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="2"
                    step="0.05"
                    value={selectedClip.volume}
                    onChange={(e) =>
                      onUpdateClip(selectedClip.id, { volume: parseFloat(e.target.value) })
                    }
                    className="w-full accent-emerald-500"
                  />
                </div>

                <div className="flex items-center gap-2 pt-1">
                  <span className="text-zinc-300 font-semibold">Speed:</span>
                  {[0.5, 0.75, 1, 1.25, 1.5, 2].map((spd) => (
                    <button
                      key={spd}
                      onClick={() => onUpdateClip(selectedClip.id, { speed: spd })}
                      className={`px-2 py-1 rounded text-[11px] font-semibold transition-colors ${
                        selectedClip.speed === spd
                          ? 'bg-emerald-500 text-zinc-950 font-bold'
                          : 'bg-zinc-800 text-zinc-400 hover:text-zinc-200'
                      }`}
                    >
                      {spd}x
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Sound FX Library */}
            <div className="space-y-2">
              <span className="text-xs font-bold text-zinc-300 uppercase tracking-wider">
                Instant Soundboard SFX
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {SOUND_EFFECTS.map((sfx) => (
                  <div
                    key={sfx.id}
                    className="flex items-center justify-between p-2.5 rounded-xl bg-zinc-900/70 border border-zinc-800 hover:border-emerald-500/40 transition-colors"
                  >
                    <div>
                      <div className="font-bold text-zinc-200">{sfx.name}</div>
                      <div className="text-[10px] text-zinc-400">{sfx.category} · {sfx.duration}s</div>
                    </div>
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => soundEngine.playForTransition(sfx.id.replace('sfx-', ''))}
                        className="p-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-emerald-400 transition-colors"
                        title="Preview Audio"
                      >
                        <Play className="w-3 h-3 fill-emerald-400" />
                      </button>
                      <button
                        onClick={() => onAddSFXClip(sfx.name, sfx.url)}
                        className="flex items-center gap-1 px-2 py-1 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 text-[11px] font-semibold transition-colors"
                      >
                        <Plus className="w-3 h-3" />
                        <span>Add</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* AI VOICEOVER PANEL */}
        {activeTab === 'voiceover' && (
          <div className="space-y-4">
            <div>
              <h3 className="font-bold text-sm text-zinc-100 flex items-center gap-2">
                <Mic className="w-4 h-4 text-violet-400" />
                <span>AI Voiceover Synthesis (Gemini 3.8 TTS)</span>
              </h3>
              <p className="text-zinc-400 mt-1">
                Type narration text to automatically generate studio speech onto Audio Track 3.
              </p>
            </div>

            <div className="space-y-3 bg-zinc-900/60 p-3.5 rounded-xl border border-zinc-800">
              <div>
                <label className="block text-zinc-300 font-semibold mb-1">Narration Script</label>
                <textarea
                  rows={3}
                  value={voiceText}
                  onChange={(e) => setVoiceText(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-zinc-950 border border-zinc-800 text-zinc-100 focus:border-amber-500 focus:outline-none resize-none"
                  placeholder="Enter narration text for the voiceover..."
                />
              </div>

              <div>
                <label className="block text-zinc-300 font-semibold mb-1">Voice Character</label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {['Kore', 'Fenrir', 'Puck', 'Zephyr'].map((v) => (
                    <button
                      key={v}
                      onClick={() => setVoiceName(v)}
                      className={`p-2 rounded-lg border text-center font-bold text-xs transition-colors ${
                        voiceName === v
                          ? 'bg-amber-500 text-zinc-950 border-amber-400'
                          : 'bg-zinc-800/80 border-zinc-700 text-zinc-300 hover:border-zinc-600'
                      }`}
                    >
                      {v}
                    </button>
                  ))}
                </div>
              </div>

              <button
                onClick={handleGenerateVoiceover}
                disabled={isGeneratingVoice || !voiceText.trim()}
                className="w-full py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-amber-400 hover:to-yellow-500 text-zinc-950 font-bold shadow-md shadow-amber-500/20 disabled:opacity-50 transition-all flex items-center justify-center gap-2"
              >
                {isGeneratingVoice ? (
                  <>
                    <div className="w-3.5 h-3.5 border-2 border-zinc-950 border-t-transparent rounded-full animate-spin" />
                    <span>Synthesizing Voiceover...</span>
                  </>
                ) : (
                  <>
                    <Mic className="w-3.5 h-3.5" />
                    <span>Generate & Add to Timeline</span>
                  </>
                )}
              </button>
            </div>
          </div>
        )}

        {/* MOTION & SPEED PANEL */}
        {activeTab === 'motion' && (
          <div className="space-y-4">
            <div>
              <h3 className="font-bold text-sm text-zinc-100 flex items-center gap-2">
                <FastForward className="w-4 h-4 text-amber-400" />
                <span>AI Smooth Motion & Speed Suite</span>
              </h3>
              <p className="text-zinc-400 mt-1">
                Deep neural frame interpolation generates intermediate frames for silky-smooth slow motion (60fps/120fps).
              </p>
            </div>

            {selectedClip ? (
              <div className="space-y-3.5">
                {/* AI Smooth Motion Neural Card */}
                <div className="p-3.5 rounded-xl bg-gradient-to-r from-amber-500/15 via-yellow-500/10 to-transparent border border-amber-500/40 space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5 font-bold text-amber-300 text-xs">
                      <Sparkles className="w-4 h-4 text-amber-400" />
                      <span>Optical Flow Frame Interpolation</span>
                    </div>
                    <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-400 border border-amber-500/40 font-mono">
                      {selectedClip.smoothMotion?.enabled ? `${selectedClip.smoothMotion.targetFps} FPS ACTIVE` : 'READY'}
                    </span>
                  </div>

                  <p className="text-[11px] text-zinc-300 leading-snug">
                    Synthesizes intermediate frames using bidirectional motion vectors to prevent stutter and create fluid, slow-motion sequences.
                  </p>

                  {/* Target Interpolation Speed Presets */}
                  <div className="space-y-1.5">
                    <span className="text-[11px] font-bold text-zinc-300 block">
                      Select Smooth Motion Speed Preset:
                    </span>
                    <div className="grid grid-cols-3 gap-1.5">
                      <button
                        onClick={() => handleApplySmoothMotion(120, 0.25)}
                        className={`p-2 rounded-lg border text-center transition-all ${
                          selectedClip.speed === 0.25 && selectedClip.smoothMotion?.enabled
                            ? 'bg-amber-500 text-zinc-950 border-amber-400 font-extrabold shadow-sm'
                            : 'bg-zinc-900/80 border-zinc-800 text-zinc-300 hover:border-amber-500/40'
                        }`}
                      >
                        <div className="text-xs font-bold">0.25x</div>
                        <div className="text-[9px] opacity-75">120 FPS Slo-Mo</div>
                      </button>

                      <button
                        onClick={() => handleApplySmoothMotion(60, 0.5)}
                        className={`p-2 rounded-lg border text-center transition-all ${
                          selectedClip.speed === 0.5 && selectedClip.smoothMotion?.enabled
                            ? 'bg-amber-500 text-zinc-950 border-amber-400 font-extrabold shadow-sm'
                            : 'bg-zinc-900/80 border-zinc-800 text-zinc-300 hover:border-amber-500/40'
                        }`}
                      >
                        <div className="text-xs font-bold">0.5x</div>
                        <div className="text-[9px] opacity-75">60 FPS Fluid</div>
                      </button>

                      <button
                        onClick={() => handleApplySmoothMotion(60, 0.75)}
                        className={`p-2 rounded-lg border text-center transition-all ${
                          selectedClip.speed === 0.75 && selectedClip.smoothMotion?.enabled
                            ? 'bg-amber-500 text-zinc-950 border-amber-400 font-extrabold shadow-sm'
                            : 'bg-zinc-900/80 border-zinc-800 text-zinc-300 hover:border-amber-500/40'
                        }`}
                      >
                        <div className="text-xs font-bold">0.75x</div>
                        <div className="text-[9px] opacity-75">60 FPS Cinema</div>
                      </button>

                      <button
                        onClick={() => handleApplySmoothMotion(60, 1.0)}
                        className={`p-2 rounded-lg border text-center transition-all ${
                          selectedClip.speed === 1.0 && selectedClip.smoothMotion?.enabled
                            ? 'bg-amber-500 text-zinc-950 border-amber-400 font-extrabold shadow-sm'
                            : 'bg-zinc-900/80 border-zinc-800 text-zinc-300 hover:border-amber-500/40'
                        }`}
                      >
                        <div className="text-xs font-bold">1.0x</div>
                        <div className="text-[9px] opacity-75">Enhanced 60fps</div>
                      </button>

                      <button
                        onClick={() => {
                          const currentDuration = selectedClip.duration;
                          const sourceDuration = selectedClip.sourceDuration || currentDuration;
                          onUpdateClip(selectedClip.id, {
                            speed: 1.5,
                            duration: Math.round((sourceDuration / 1.5) * 10) / 10,
                            smoothMotion: undefined,
                          });
                        }}
                        className={`p-2 rounded-lg border text-center transition-all ${
                          selectedClip.speed === 1.5
                            ? 'bg-amber-500 text-zinc-950 border-amber-400 font-extrabold shadow-sm'
                            : 'bg-zinc-900/80 border-zinc-800 text-zinc-300 hover:border-amber-500/40'
                        }`}
                      >
                        <div className="text-xs font-bold">1.5x</div>
                        <div className="text-[9px] opacity-75">Fast Motion</div>
                      </button>

                      <button
                        onClick={() => {
                          const currentDuration = selectedClip.duration;
                          const sourceDuration = selectedClip.sourceDuration || currentDuration;
                          onUpdateClip(selectedClip.id, {
                            speed: 2.0,
                            duration: Math.round((sourceDuration / 2.0) * 10) / 10,
                            smoothMotion: undefined,
                          });
                        }}
                        className={`p-2 rounded-lg border text-center transition-all ${
                          selectedClip.speed === 2.0
                            ? 'bg-amber-500 text-zinc-950 border-amber-400 font-extrabold shadow-sm'
                            : 'bg-zinc-900/80 border-zinc-800 text-zinc-300 hover:border-amber-500/40'
                        }`}
                      >
                        <div className="text-xs font-bold">2.0x</div>
                        <div className="text-[9px] opacity-75">Hyperlapse</div>
                      </button>
                    </div>
                  </div>

                  {/* Processing Button */}
                  <button
                    onClick={() => handleApplySmoothMotion(60, 0.5)}
                    disabled={isInterpolatingMotion}
                    className="w-full py-2.5 px-3 rounded-lg bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-amber-400 hover:to-yellow-500 text-zinc-950 font-bold text-xs shadow-md shadow-amber-500/20 flex items-center justify-center gap-2 transition-all active:scale-95 disabled:opacity-50"
                  >
                    {isInterpolatingMotion ? (
                      <>
                        <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                        <span>Interpolating Optical Flow Vectors...</span>
                      </>
                    ) : (
                      <>
                        <Zap className="w-3.5 h-3.5 fill-zinc-950" />
                        <span>Synthesize Fluid Slow-Mo (0.5x @ 60 FPS)</span>
                      </>
                    )}
                  </button>

                  {selectedClip.smoothMotion?.enabled && (
                    <div className="flex items-center gap-1.5 p-2 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-[11px] font-semibold">
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span>
                        AI Smooth Motion Active: {selectedClip.smoothMotion.targetFps} FPS Optical Flow ({selectedClip.speed}x speed)
                      </span>
                    </div>
                  )}
                </div>

                {/* Scale, Crop & Geometry (Transform Controls) */}
                <div className="space-y-3 bg-zinc-900/60 p-3.5 rounded-xl border border-zinc-800">
                  <div className="font-bold text-zinc-200 text-xs flex items-center gap-1.5 pb-1 border-b border-zinc-800">
                    <Move className="w-3.5 h-3.5 text-amber-400" />
                    <span>Geometry & Framing</span>
                  </div>

                  {/* Scale */}
                  <div>
                    <div className="flex justify-between font-medium mb-1">
                      <span className="text-zinc-300">Scale</span>
                      <span className="font-mono text-amber-400">
                        {(selectedClip.transform?.scale || 1).toFixed(2)}x
                      </span>
                    </div>
                    <input
                      type="range"
                      min="0.5"
                      max="2.5"
                      step="0.05"
                      value={selectedClip.transform?.scale || 1}
                      onChange={(e) =>
                        onUpdateClip(selectedClip.id, {
                          transform: {
                            ...(selectedClip.transform || {
                              scale: 1,
                              rotation: 0,
                              x: 0,
                              y: 0,
                              opacity: 1,
                              flippedHorizontal: false,
                            }),
                            scale: parseFloat(e.target.value),
                          },
                        })
                      }
                      className="w-full"
                    />
                  </div>

                  {/* Rotation */}
                  <div>
                    <div className="flex justify-between font-medium mb-1">
                      <span className="text-zinc-300">Rotation</span>
                      <span className="font-mono text-amber-400">
                        {selectedClip.transform?.rotation || 0}°
                      </span>
                    </div>
                    <input
                      type="range"
                      min="-180"
                      max="180"
                      value={selectedClip.transform?.rotation || 0}
                      onChange={(e) =>
                        onUpdateClip(selectedClip.id, {
                          transform: {
                            ...(selectedClip.transform || {
                              scale: 1,
                              rotation: 0,
                              x: 0,
                              y: 0,
                              opacity: 1,
                              flippedHorizontal: false,
                            }),
                            rotation: parseInt(e.target.value),
                          },
                        })
                      }
                      className="w-full"
                    />
                  </div>

                  {/* Flip Horizontal */}
                  <div className="flex items-center justify-between pt-2 border-t border-zinc-800">
                    <span className="text-zinc-300 font-semibold">Mirror Flip Horizontal</span>
                    <button
                      onClick={() =>
                        onUpdateClip(selectedClip.id, {
                          transform: {
                            ...(selectedClip.transform || {
                              scale: 1,
                              rotation: 0,
                              x: 0,
                              y: 0,
                              opacity: 1,
                              flippedHorizontal: false,
                            }),
                            flippedHorizontal: !selectedClip.transform?.flippedHorizontal,
                          },
                        })
                      }
                      className={`px-3 py-1 rounded-lg text-xs font-semibold border transition-colors ${
                        selectedClip.transform?.flippedHorizontal
                          ? 'bg-amber-500 text-zinc-950 border-amber-400'
                          : 'bg-zinc-800 text-zinc-300 border-zinc-700'
                      }`}
                    >
                      {selectedClip.transform?.flippedHorizontal ? 'Flipped' : 'Normal'}
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              <div className="p-6 text-center text-zinc-500 bg-zinc-900/30 rounded-xl border border-zinc-850">
                Please select a clip on the timeline to configure smooth motion & geometry.
              </div>
            )}
          </div>
        )}

        {/* EXPORT PANEL */}
        {activeTab === 'export' && (
          <div className="space-y-4">
            <div>
              <h3 className="font-bold text-sm text-zinc-100 flex items-center gap-2">
                <Download className="w-4 h-4 text-amber-400" />
                <span>Render & Export Suite</span>
              </h3>
              <p className="text-zinc-400 mt-1">
                Produce ready-to-publish video masters, project packages, or standalone web apps.
              </p>
            </div>

            <div className="space-y-3 bg-zinc-900/60 p-4 rounded-xl border border-zinc-800">
              <button
                onClick={onExportProject}
                className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-amber-400 hover:to-yellow-500 text-zinc-950 font-bold shadow-lg shadow-amber-500/25 transition-all hover:scale-[1.01] flex items-center justify-center gap-2"
              >
                <Download className="w-4 h-4" />
                <span>Export Master Video (.mp4 / .webm)</span>
              </button>

              <div className="grid grid-cols-2 gap-2 pt-2">
                <a
                  href="/install.html"
                  download="install.html"
                  className="p-2.5 rounded-lg bg-zinc-850 hover:bg-zinc-800 text-amber-400 border border-zinc-750 font-semibold text-center transition-colors"
                >
                  📦 Installer HTML
                </a>
                <a
                  href="/motionai-android.html"
                  download="motionai-android.html"
                  className="p-2.5 rounded-lg bg-zinc-850 hover:bg-zinc-800 text-amber-400 border border-zinc-750 font-semibold text-center transition-colors"
                >
                  🤖 Android APK File
                </a>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
