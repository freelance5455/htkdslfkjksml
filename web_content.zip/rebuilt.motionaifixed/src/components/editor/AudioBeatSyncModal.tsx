import React, { useState, useEffect } from 'react';
import { BeatSyncConfig, EditorClip, TimelineTrack } from '../../types';
import { 
  analyzeMusicWaveformAndDetectBeats, 
  generateBeatMarkers, 
  alignClipsToBeats 
} from '../../utils/beatSyncEngine';
import { 
  Music, 
  Activity, 
  Sparkles, 
  X, 
  Play, 
  Sliders, 
  Check, 
  RefreshCw, 
  Magnet, 
  Clock, 
  Scissors, 
  Volume2 
} from 'lucide-react';
import { soundEngine } from '../../utils/transitionSound';
import confetti from 'canvas-confetti';

interface AudioBeatSyncModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: BeatSyncConfig;
  onConfigChange: (newConfig: BeatSyncConfig) => void;
  clips: EditorClip[];
  onClipsChange: (clips: EditorClip[]) => void;
  tracks: TimelineTrack[];
  totalDuration: number;
}

export const AudioBeatSyncModal: React.FC<AudioBeatSyncModalProps> = ({
  isOpen,
  onClose,
  config,
  onConfigChange,
  clips,
  onClipsChange,
  tracks,
  totalDuration,
}) => {
  const [bpm, setBpm] = useState<number>(config.bpm || 120);
  const [snappingEnabled, setSnappingEnabled] = useState<boolean>(config.snappingEnabled ?? true);
  const [snapThreshold, setSnapThreshold] = useState<number>(config.snapThreshold || 0.15);
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [waveformData, setWaveformData] = useState<number[]>([]);
  const [detectedBpm, setDetectedBpm] = useState<number | null>(null);
  const [pulseActive, setPulseActive] = useState<boolean>(false);
  const [selectedMusicTrackId, setSelectedMusicTrackId] = useState<string>(config.sourceTrackId || 'track-a1');
  const [toast, setToast] = useState<string | null>(null);

  // Tap tempo state
  const [tapTimes, setTapTimes] = useState<number[]>([]);

  // Find the primary music clip
  const musicClip = clips.find((c) => c.trackId === selectedMusicTrackId || c.type === 'audio');

  // Trigger pulse animation matching BPM
  useEffect(() => {
    if (!isOpen) return;
    const intervalMs = (60 / bpm) * 1000;
    const interval = setInterval(() => {
      setPulseActive(true);
      setTimeout(() => setPulseActive(false), 120);
    }, intervalMs);
    return () => clearInterval(interval);
  }, [bpm, isOpen]);

  // Initial synthetic waveform on open
  useEffect(() => {
    if (isOpen && waveformData.length === 0) {
      handleAnalyzeWaveform(false);
    }
  }, [isOpen]);

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 3500);
  };

  // Run intelligent audio waveform analysis
  const handleAnalyzeWaveform = async (playEffects = true) => {
    setIsAnalyzing(true);
    if (playEffects) soundEngine.playWhoosh(0.2);

    try {
      const res = await analyzeMusicWaveformAndDetectBeats(musicClip, totalDuration);
      setWaveformData(res.waveformData);
      setDetectedBpm(res.bpm);
      setBpm(res.bpm);

      const newMarkers = res.markers;
      onConfigChange({
        ...config,
        enabled: true,
        bpm: res.bpm,
        markers: newMarkers,
        snappingEnabled,
        snapThreshold,
        sourceTrackId: selectedMusicTrackId,
      });

      if (playEffects) {
        soundEngine.playImpact();
        confetti({ particleCount: 40, spread: 60 });
        showToast(`✓ Analyzed "${musicClip?.title || 'Music Track'}": Detected ${res.bpm} BPM with ${newMarkers.length} beat snap points`);
      }
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Handle Tap Tempo
  const handleTapTempo = () => {
    const now = Date.now();
    const updatedTaps = [...tapTimes.slice(-4), now];
    setTapTimes(updatedTaps);

    if (updatedTaps.length >= 2) {
      const intervals = [];
      for (let i = 1; i < updatedTaps.length; i++) {
        intervals.push(updatedTaps[i] - updatedTaps[i - 1]);
      }
      const avgInterval = intervals.reduce((a, b) => a + b, 0) / intervals.length;
      const calculatedBpm = Math.round(60000 / avgInterval);
      if (calculatedBpm >= 40 && calculatedBpm <= 220) {
        setBpm(calculatedBpm);
        const markers = generateBeatMarkers(calculatedBpm, Math.max(15, totalDuration));
        onConfigChange({
          ...config,
          bpm: calculatedBpm,
          markers,
        });
      }
    }
  };

  // Update manual BPM
  const handleBpmChange = (newVal: number) => {
    setBpm(newVal);
    const markers = generateBeatMarkers(newVal, Math.max(15, totalDuration));
    onConfigChange({
      ...config,
      bpm: newVal,
      markers,
    });
  };

  // Auto-align video cuts to beats
  const handleAutoAlignCuts = () => {
    const markers = config.markers.length > 0 ? config.markers : generateBeatMarkers(bpm, Math.max(15, totalDuration));
    const alignedClips = alignClipsToBeats(clips, markers);
    onClipsChange(alignedClips);
    soundEngine.playImpact();
    confetti({ particleCount: 50, spread: 70 });
    showToast(`✓ Aligned video cuts to ${bpm} BPM downbeats for rhythmic pacing`);
  };

  // Toggle magnetic snapping
  const handleToggleSnapping = () => {
    const nextVal = !snappingEnabled;
    setSnappingEnabled(nextVal);
    onConfigChange({
      ...config,
      snappingEnabled: nextVal,
    });
  };

  if (!isOpen) return null;

  const beatSec = (60 / bpm).toFixed(3);
  const framesPerBeat = Math.round((60 / bpm) * 30);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="relative w-full max-w-xl max-h-[92vh] overflow-y-auto bg-zinc-950 border border-amber-500/40 rounded-2xl p-5 sm:p-6 shadow-2xl space-y-4">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-lg text-zinc-400 hover:text-zinc-100 hover:bg-zinc-900 transition-colors"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-amber-400 to-yellow-600 flex items-center justify-center text-zinc-950 font-black shadow-lg shadow-amber-500/25 shrink-0">
            <Activity className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-extrabold text-zinc-100">Audio Beat Sync & Magnetic Cuts</h3>
            <p className="text-xs text-amber-400">
              Waveform transient detection & rhythmic beat markers for frame-perfect cut alignment
            </p>
          </div>
        </div>

        {/* Toast Alert */}
        {toast && (
          <div className="p-2.5 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-300 font-bold text-xs flex items-center justify-between">
            <span>{toast}</span>
            <button onClick={() => setToast(null)}>
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* Waveform Visualization Canvas with Transient Beat Markers */}
        <div className="p-3.5 rounded-xl bg-zinc-900/90 border border-amber-500/30 space-y-2">
          <div className="flex items-center justify-between text-xs">
            <div className="flex items-center gap-2">
              <span className="font-bold text-zinc-200">Waveform Transients:</span>
              <span className="text-[11px] text-zinc-400 font-mono">
                {musicClip?.title || 'Audio Track 1'}
              </span>
            </div>

            {/* Pulse Indicator */}
            <div className="flex items-center gap-1.5 font-mono text-[11px] font-bold text-amber-400">
              <span
                className={`w-2.5 h-2.5 rounded-full bg-amber-400 transition-all duration-100 ${
                  pulseActive ? 'scale-150 shadow-[0_0_8px_rgba(245,158,11,1)]' : 'scale-90 opacity-60'
                }`}
              />
              <span>{bpm} BPM</span>
            </div>
          </div>

          {/* Graphical Waveform Bars with Beat Pins */}
          <div className="relative h-20 bg-zinc-950 rounded-lg border border-zinc-800 p-2 flex items-center gap-[2px] overflow-hidden">
            {waveformData.map((energy, idx) => {
              const isBeatTransient = idx % 4 === 0;
              const isDownbeat = idx % 16 === 0;

              return (
                <div key={idx} className="flex-1 h-full flex flex-col justify-center items-center group relative">
                  {/* Vertical bar */}
                  <div
                    style={{ height: `${Math.max(12, energy * 100)}%` }}
                    className={`w-full rounded-full transition-all duration-150 ${
                      isDownbeat
                        ? 'bg-amber-400 shadow-[0_0_6px_rgba(245,158,11,0.8)]'
                        : isBeatTransient
                        ? 'bg-yellow-500/80'
                        : 'bg-zinc-700/60'
                    }`}
                  />

                  {/* Marker Pin at top for beat */}
                  {isBeatTransient && (
                    <div
                      className={`absolute top-0.5 w-1 h-1 rounded-full ${
                        isDownbeat ? 'bg-amber-300 w-1.5 h-1.5' : 'bg-yellow-500'
                      }`}
                    />
                  )}
                </div>
              );
            })}
          </div>

          <div className="flex items-center justify-between text-[10px] text-zinc-400 pt-0.5">
            <span className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-amber-400 inline-block" />
              <span>Downbeats (Bar Start)</span>
            </span>
            <span className="flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-yellow-500 inline-block" />
              <span>Quarter Beats ({beatSec}s / {framesPerBeat} frames)</span>
            </span>
            <span className="font-mono text-amber-300">
              {config.markers.length} Snap Points Created
            </span>
          </div>
        </div>

        {/* Tempo & BPM Controls */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {/* Slider and Tap Tempo */}
          <div className="p-3.5 rounded-xl bg-zinc-900/90 border border-zinc-800 space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-zinc-200">Playback Tempo (BPM)</span>
              <span className="text-xs font-mono font-extrabold text-amber-400 bg-zinc-950 px-2 py-0.5 rounded border border-amber-500/30">
                {bpm} BPM
              </span>
            </div>

            <input
              type="range"
              min="50"
              max="200"
              step="1"
              value={bpm}
              onChange={(e) => handleBpmChange(parseInt(e.target.value, 10))}
              className="w-full accent-amber-500"
            />

            <div className="flex items-center gap-2 pt-1">
              <button
                onClick={handleTapTempo}
                className="flex-1 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-200 font-bold text-xs border border-zinc-700 active:scale-95 transition-all text-center"
              >
                🥁 Tap Tempo
              </button>
              <button
                onClick={() => handleAnalyzeWaveform(true)}
                disabled={isAnalyzing}
                className="flex-1 py-1.5 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 font-bold text-xs border border-amber-500/40 flex items-center justify-center gap-1.5 active:scale-95 transition-all"
              >
                {isAnalyzing ? (
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <Sparkles className="w-3.5 h-3.5" />
                )}
                <span>Auto-Detect</span>
              </button>
            </div>
          </div>

          {/* Snapping Configuration */}
          <div className="p-3.5 rounded-xl bg-zinc-900/90 border border-zinc-800 space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-zinc-200 flex items-center gap-1.5">
                <Magnet className="w-3.5 h-3.5 text-amber-400" />
                <span>Magnetic Beat Snapping</span>
              </span>
              <button
                onClick={handleToggleSnapping}
                className={`px-2 py-0.5 rounded text-[11px] font-bold transition-all ${
                  snappingEnabled
                    ? 'bg-amber-500 text-zinc-950'
                    : 'bg-zinc-800 text-zinc-400 border border-zinc-700'
                }`}
              >
                {snappingEnabled ? 'ENABLED' : 'DISABLED'}
              </button>
            </div>

            <div>
              <div className="flex justify-between text-[11px] mb-1 text-zinc-400">
                <span>Magnet Snap Window:</span>
                <span className="font-mono text-amber-300 font-bold">±{(snapThreshold * 1000).toFixed(0)} ms</span>
              </div>
              <input
                type="range"
                min="0.05"
                max="0.35"
                step="0.02"
                value={snapThreshold}
                onChange={(e) => {
                  const val = parseFloat(e.target.value);
                  setSnapThreshold(val);
                  onConfigChange({ ...config, snapThreshold: val });
                }}
                className="w-full accent-amber-500"
              />
            </div>

            <p className="text-[10px] text-zinc-400 leading-snug">
              When dragging clips or splitting at the playhead, cuts automatically snap to the nearest rhythmic beat point.
            </p>
          </div>
        </div>

        {/* Action Buttons: Auto-Align Video Cuts to Beats & Apply */}
        <div className="space-y-2 pt-1">
          <button
            onClick={handleAutoAlignCuts}
            className="w-full py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-amber-400 hover:to-yellow-500 text-zinc-950 font-bold text-xs shadow-md shadow-amber-500/20 flex items-center justify-center gap-2 active:scale-[0.99] transition-all"
          >
            <Scissors className="w-3.5 h-3.5" />
            <span>Auto-Align All Video Cuts to Downbeats</span>
          </button>

          <button
            onClick={() => {
              onConfigChange({
                ...config,
                enabled: true,
                bpm,
                snappingEnabled,
                snapThreshold,
                markers: generateBeatMarkers(bpm, Math.max(15, totalDuration)),
              });
              onClose();
            }}
            className="w-full py-2 rounded-xl bg-zinc-900 hover:bg-zinc-850 text-zinc-200 border border-zinc-750 font-bold text-xs transition-colors flex items-center justify-center gap-1.5"
          >
            <Check className="w-3.5 h-3.5 text-amber-400" />
            <span>Save & Apply Beat Grid to Timeline</span>
          </button>
        </div>
      </div>
    </div>
  );
};
