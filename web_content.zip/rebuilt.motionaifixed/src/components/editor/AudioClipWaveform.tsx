import React, { useMemo } from 'react';
import { EditorClip } from '../../types';

interface AudioClipWaveformProps {
  clip: EditorClip;
  width: number;
  height: number;
  isMuted?: boolean;
  isDucked?: boolean;
  duckingAmount?: number;
}

export const AudioClipWaveform: React.FC<AudioClipWaveformProps> = ({
  clip,
  width,
  height,
  isMuted = false,
  isDucked = false,
  duckingAmount = 20,
}) => {
  // Generate waveform bars based on clip duration, volume, and simulated audio energy profile
  const waveformBars = useMemo(() => {
    // Number of vertical bars based on width (e.g., 1 bar every 3-4px)
    const barSpacing = 3;
    const totalBars = Math.max(12, Math.floor(width / barSpacing));
    const bars: { heightPct: number; isTransient: boolean; opacity: number }[] = [];

    // Derive deterministic seed from clip ID and title
    let seed = 0;
    const str = clip.id + clip.title;
    for (let i = 0; i < str.length; i++) {
      seed = (seed * 31 + str.charCodeAt(i)) % 10000;
    }

    const volumeScale = isMuted ? 0.05 : Math.max(0.1, Math.min(1.8, clip.volume));
    const duckScale = isDucked ? duckingAmount / 100 : 1;

    for (let i = 0; i < totalBars; i++) {
      const progress = i / totalBars; // 0 to 1 along clip
      const timeInClip = progress * clip.duration;

      // Apply Fade In envelope
      let fadeMultiplier = 1;
      if (clip.fadeIn && clip.fadeIn > 0 && timeInClip < clip.fadeIn) {
        fadeMultiplier = timeInClip / clip.fadeIn;
      }
      // Apply Fade Out envelope
      if (clip.fadeOut && clip.fadeOut > 0 && timeInClip > clip.duration - clip.fadeOut) {
        fadeMultiplier = Math.max(0, (clip.duration - timeInClip) / clip.fadeOut);
      }

      // Pseudo-random audio frequency rhythm with periodic transient peaks (sync points)
      const pseudoNoise = Math.sin(i * 0.45 + seed) * 0.35 + Math.cos(i * 1.1 + seed * 2) * 0.25;
      const isTransient = i % 8 === 0 || i % 14 === 0;
      const transientBoost = isTransient ? 0.35 : 0;

      const rawHeight = Math.abs(0.3 + pseudoNoise * 0.4 + transientBoost);
      const effectiveHeight = Math.min(
        0.95,
        Math.max(0.08, rawHeight * volumeScale * duckScale * fadeMultiplier)
      );

      bars.push({
        heightPct: effectiveHeight,
        isTransient,
        opacity: isMuted ? 0.2 : isDucked ? 0.5 : isTransient ? 1 : 0.75,
      });
    }

    return bars;
  }, [clip.id, clip.title, clip.duration, clip.volume, clip.fadeIn, clip.fadeOut, width, isMuted, isDucked, duckingAmount]);

  if (width < 20) return null;

  return (
    <div
      style={{ width: `${width}px`, height: `${height}px` }}
      className="absolute inset-0 pointer-events-none flex items-center justify-between overflow-hidden px-1 z-0 select-none opacity-85"
    >
      {waveformBars.map((bar, idx) => {
        const barHeightPx = Math.max(2, Math.round(bar.heightPct * (height - 8)));

        return (
          <div
            key={idx}
            style={{
              height: `${barHeightPx}px`,
              opacity: bar.opacity,
            }}
            className={`w-[2px] rounded-full transition-all duration-100 ${
              bar.isTransient
                ? 'bg-gradient-to-t from-emerald-400 via-amber-300 to-yellow-300 shadow-[0_0_2px_rgba(245,158,11,0.6)]'
                : 'bg-emerald-400/80'
            }`}
          />
        );
      })}
    </div>
  );
};
