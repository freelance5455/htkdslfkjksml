import React, { useRef, useState } from 'react';
import { EditorClip, TimelineTrack, TransitionType, AudioDuckingConfig, BeatSyncConfig } from '../../types';
import { 
  Scissors, 
  Trash2, 
  Copy, 
  ZoomIn, 
  ZoomOut, 
  Volume2, 
  VolumeX, 
  Lock, 
  Unlock, 
  Plus, 
  Sparkles,
  Layers,
  Music,
  Type,
  Video,
  Subtitles,
  RotateCcw,
  RotateCw,
  Mic,
  Sliders,
  Activity,
  Magnet,
  Keyboard
} from 'lucide-react';
import { soundEngine } from '../../utils/transitionSound';
import { findNearestBeatMarker } from '../../utils/beatSyncEngine';
import { AudioClipWaveform } from './AudioClipWaveform';

interface MultiTrackTimelineProps {
  tracks: TimelineTrack[];
  clips: EditorClip[];
  currentTime: number;
  totalDuration: number;
  selectedClipId: string | null;
  onSelectClip: (clipId: string | null) => void;
  onSeek: (time: number) => void;
  onSplitClip: (clipId: string) => void;
  onDeleteClip: (clipId: string) => void;
  onDuplicateClip: (clipId: string) => void;
  onUpdateClip: (clipId: string, updates: Partial<EditorClip>) => void;
  onToggleMuteTrack: (trackId: string) => void;
  onToggleLockTrack: (trackId: string) => void;
  onAddStockClip: (type: 'video' | 'audio' | 'text') => void;
  onOpenCaptionsModal?: () => void;
  zoomLevel?: number;
  onZoomLevelChange?: (zoom: number) => void;
  undoCount?: number;
  redoCount?: number;
  onUndo?: () => void;
  onRedo?: () => void;
  audioDucking?: AudioDuckingConfig;
  onToggleAudioDucking?: () => void;
  onOpenDuckingSettings?: () => void;
  beatSync?: BeatSyncConfig;
  onOpenBeatSyncModal?: () => void;
  onToggleBeatSnapping?: () => void;
  onOpenTransitionsLibrary?: () => void;
  onOpenKeyboardShortcuts?: () => void;
}

export const MultiTrackTimeline: React.FC<MultiTrackTimelineProps> = ({
  tracks,
  clips,
  currentTime,
  totalDuration,
  selectedClipId,
  onSelectClip,
  onSeek,
  onSplitClip,
  onDeleteClip,
  onDuplicateClip,
  onUpdateClip,
  onToggleMuteTrack,
  onToggleLockTrack,
  onAddStockClip,
  onOpenCaptionsModal,
  zoomLevel,
  onZoomLevelChange,
  undoCount = 0,
  redoCount = 0,
  onUndo,
  onRedo,
  audioDucking,
  onToggleAudioDucking,
  onOpenDuckingSettings,
  beatSync,
  onOpenBeatSyncModal,
  onToggleBeatSnapping,
  onOpenTransitionsLibrary,
  onOpenKeyboardShortcuts,
}) => {
  const [internalZoom, setInternalZoom] = useState<number>(30); // pixels per second
  const [snapEnabled, setSnapEnabled] = useState<boolean>(true);
  const [snappedMarkerAlert, setSnappedMarkerAlert] = useState<string | null>(null);
  const [dragOverClipId, setDragOverClipId] = useState<string | null>(null);
  const timelineRef = useRef<HTMLDivElement | null>(null);

  const activeZoom = zoomLevel !== undefined ? zoomLevel : internalZoom;
  const updateZoom = (val: number | ((prev: number) => number)) => {
    const nextZoom = typeof val === 'function' ? val(activeZoom) : val;
    const clamped = Math.max(1, Math.min(150, Math.round(nextZoom)));
    if (onZoomLevelChange) {
      onZoomLevelChange(clamped);
    } else {
      setInternalZoom(clamped);
    }
  };

  const selectedClip = clips.find((c) => c.id === selectedClipId);

  // Dynamic ruler interval based on activeZoom and totalDuration (up to 30 min / 1800s)
  let tickInterval = 1; // seconds
  const pxPerSec = activeZoom;
  if (pxPerSec * 1 < 25) {
    if (pxPerSec * 5 >= 25) tickInterval = 5;
    else if (pxPerSec * 15 >= 25) tickInterval = 15;
    else if (pxPerSec * 30 >= 25) tickInterval = 30;
    else if (pxPerSec * 60 >= 25) tickInterval = 60; // 1 min
    else if (pxPerSec * 120 >= 25) tickInterval = 120; // 2 min
    else if (pxPerSec * 300 >= 25) tickInterval = 300; // 5 min
    else tickInterval = 600; // 10 min
  }

  const maxRulerTime = Math.max(30, Math.ceil(totalDuration) + tickInterval * 2);
  const rulerTicks: number[] = [];
  for (let s = 0; s <= maxRulerTime; s += tickInterval) {
    rulerTicks.push(s);
  }

  const formatRulerLabel = (sec: number) => {
    if (sec === 0) return '0s';
    const hrs = Math.floor(sec / 3600);
    const mins = Math.floor((sec % 3600) / 60);
    const s = sec % 60;
    if (hrs > 0) return `${hrs}h${mins > 0 ? ` ${mins}m` : ''}`;
    if (mins > 0) return `${mins}m${s > 0 ? ` ${s}s` : ''}`;
    return `${s}s`;
  };

  // Fit timeline to container width
  const handleFitTimeline = () => {
    if (!timelineRef.current) return;
    const containerWidth = timelineRef.current.clientWidth - 40;
    const fitZoom = Math.max(1, Math.min(150, Math.floor(containerWidth / Math.max(15, totalDuration))));
    updateZoom(fitZoom);
  };

  // Handle timeline scrubber drag & click with Magnetic Beat Snapping
  const handleTimelineClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!timelineRef.current) return;
    const rect = timelineRef.current.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    let seekTime = Math.max(0, clickX / activeZoom);

    // Magnetic Beat Snapping: Align cuts and scrub point to nearest musical beat
    if (snapEnabled && beatSync?.enabled && beatSync.snappingEnabled && beatSync.markers?.length) {
      const snapResult = findNearestBeatMarker(seekTime, beatSync.markers, beatSync.snapThreshold);
      if (snapResult.didSnap && snapResult.marker) {
        seekTime = snapResult.snappedTime;
        soundEngine.playWhoosh(0.1);
        setSnappedMarkerAlert(`Snapped to Beat ${snapResult.marker.label || ''} (${snapResult.snappedTime.toFixed(2)}s)`);
        setTimeout(() => setSnappedMarkerAlert(null), 1200);
      }
    }

    onSeek(seekTime);
  };

  // Zoom on Ctrl + Wheel
  const handleWheel = (e: React.WheelEvent<HTMLDivElement>) => {
    if (e.ctrlKey || e.metaKey) {
      e.preventDefault();
      const delta = e.deltaY < 0 ? 6 : -6;
      updateZoom((prev) => Math.max(1, Math.min(150, prev + delta)));
    }
  };

  const getTrackIcon = (type: string) => {
    switch (type) {
      case 'video':
      case 'pip':
        return <Video className="w-3.5 h-3.5 text-amber-400" />;
      case 'text':
        return <Type className="w-3.5 h-3.5 text-yellow-300" />;
      case 'audio':
      case 'sfx':
      case 'voiceover':
        return <Music className="w-3.5 h-3.5 text-emerald-400" />;
      default:
        return <Layers className="w-3.5 h-3.5 text-amber-400" />;
    }
  };

  const getClipBgColor = (type: string, isSelected: boolean) => {
    if (isSelected) {
      return 'bg-gradient-to-r from-amber-600/90 to-yellow-600/90 border-amber-300 text-zinc-950 shadow-lg shadow-amber-500/30';
    }
    switch (type) {
      case 'video':
        return 'bg-gradient-to-r from-zinc-800 to-zinc-700/80 border-amber-500/40 text-zinc-100 hover:border-amber-400';
      case 'pip':
        return 'bg-gradient-to-r from-zinc-800/90 to-amber-950/40 border-amber-500/50 text-amber-100 hover:border-amber-400';
      case 'text':
        return 'bg-gradient-to-r from-amber-950/80 to-yellow-950/70 border-yellow-500/50 text-yellow-200 hover:border-yellow-400';
      case 'audio':
        return 'bg-gradient-to-r from-zinc-800 to-emerald-950/40 border-emerald-500/40 text-emerald-200 hover:border-emerald-400';
      case 'sfx':
        return 'bg-gradient-to-r from-zinc-800 to-teal-950/40 border-teal-500/40 text-teal-200 hover:border-teal-400';
      case 'voiceover':
        return 'bg-gradient-to-r from-zinc-800 to-violet-950/40 border-violet-500/40 text-violet-200 hover:border-violet-400';
      default:
        return 'bg-zinc-800 border-zinc-700 text-zinc-200';
    }
  };

  return (
    <div className="flex flex-col bg-zinc-950 border border-zinc-800/80 rounded-2xl overflow-hidden shadow-xl">
      {/* Timeline Controls & Action Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-2 px-3 sm:px-4 py-2 bg-zinc-900/80 border-b border-zinc-800 text-xs">
        {/* Left: Editing Tools & History & Audio Ducking */}
        <div className="flex flex-wrap items-center gap-1.5">
          {/* Global Undo & Redo System */}
          <div className="flex items-center gap-1 bg-zinc-950 p-0.5 rounded-lg border border-zinc-800 mr-1">
            <button
              onClick={onUndo}
              disabled={!onUndo || undoCount === 0}
              title="Undo Last Action (Ctrl+Z)"
              className="flex items-center gap-1 px-2 py-1 rounded text-xs font-semibold text-zinc-300 hover:text-amber-400 hover:bg-zinc-850 disabled:opacity-30 disabled:pointer-events-none transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5 text-amber-400" />
              <span>Undo</span>
              {undoCount > 0 && (
                <span className="text-[10px] font-mono opacity-60">({undoCount})</span>
              )}
            </button>

            <button
              onClick={onRedo}
              disabled={!onRedo || redoCount === 0}
              title="Redo Action (Ctrl+Y / Cmd+Shift+Z)"
              className="flex items-center gap-1 px-2 py-1 rounded text-xs font-semibold text-zinc-300 hover:text-amber-400 hover:bg-zinc-850 disabled:opacity-30 disabled:pointer-events-none transition-colors"
            >
              <RotateCw className="w-3.5 h-3.5 text-amber-400" />
              <span>Redo</span>
              {redoCount > 0 && (
                <span className="text-[10px] font-mono opacity-60">({redoCount})</span>
              )}
            </button>
          </div>

          <button
            onClick={() => selectedClipId && onSplitClip(selectedClipId)}
            disabled={!selectedClipId}
            title="Split Clip at Playhead (S)"
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-zinc-800/80 hover:bg-zinc-750 disabled:opacity-40 text-zinc-200 hover:text-amber-400 border border-zinc-700 transition-colors"
          >
            <Scissors className="w-3.5 h-3.5 text-amber-400" />
            <span className="font-medium">Split</span>
          </button>

          <button
            onClick={() => selectedClipId && onDeleteClip(selectedClipId)}
            disabled={!selectedClipId}
            title="Delete Selected Clip (Del)"
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-zinc-800/80 hover:bg-red-950/40 disabled:opacity-40 text-zinc-200 hover:text-red-400 border border-zinc-700 hover:border-red-500/40 transition-colors"
          >
            <Trash2 className="w-3.5 h-3.5 text-red-400" />
            <span className="font-medium">Delete</span>
          </button>

          <button
            onClick={() => selectedClipId && onDuplicateClip(selectedClipId)}
            disabled={!selectedClipId}
            title="Duplicate Clip"
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-zinc-800/80 hover:bg-zinc-750 disabled:opacity-40 text-zinc-200 hover:text-amber-400 border border-zinc-700 transition-colors"
          >
            <Copy className="w-3.5 h-3.5 text-amber-400" />
            <span className="font-medium">Duplicate</span>
          </button>

          <div className="h-4 w-px bg-zinc-750 mx-1 hidden sm:block"></div>

          {/* Quick Insert Buttons */}
          <button
            onClick={() => onAddStockClip('video')}
            className="flex items-center gap-1 px-2 py-1 rounded bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 border border-amber-500/30 font-medium transition-colors"
          >
            <Plus className="w-3 h-3" />
            <span>Add Video</span>
          </button>
          <button
            onClick={() => onAddStockClip('text')}
            className="flex items-center gap-1 px-2 py-1 rounded bg-yellow-500/10 hover:bg-yellow-500/20 text-yellow-400 border border-yellow-500/30 font-medium transition-colors"
          >
            <Plus className="w-3 h-3" />
            <span>Add Title</span>
          </button>
          <button
            onClick={() => onAddStockClip('audio')}
            className="flex items-center gap-1 px-2 py-1 rounded bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 font-medium transition-colors"
          >
            <Plus className="w-3 h-3" />
            <span>Add Audio</span>
          </button>

          {onOpenCaptionsModal && (
            <button
              onClick={onOpenCaptionsModal}
              title="Auto-Generate SRT Captions from Audio Tracks"
              className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 text-xs font-bold transition-all shadow-sm"
            >
              <Subtitles className="w-3.5 h-3.5 text-amber-400" />
              <span>AI Captions</span>
            </button>
          )}

          {/* AI-Powered Audio Ducking Quick Toggle & Settings */}
          {audioDucking && (
            <div className="flex items-center gap-1 bg-zinc-950 p-0.5 rounded-lg border border-amber-500/30">
              <button
                onClick={onToggleAudioDucking}
                title={
                  audioDucking.enabled
                    ? `AI Audio Ducking ON: Lowers background music to ${audioDucking.duckingAmount}% during voice-over`
                    : 'Click to Enable AI Audio Ducking'
                }
                className={`flex items-center gap-1 px-2 py-1 rounded text-xs font-bold transition-all ${
                  audioDucking.enabled
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                    : 'text-zinc-500 hover:text-zinc-300'
                }`}
              >
                <Mic className="w-3.5 h-3.5 text-amber-400" />
                <span>AI Ducking: {audioDucking.enabled ? `${audioDucking.duckingAmount}%` : 'OFF'}</span>
              </button>

              {onOpenDuckingSettings && (
                <button
                  onClick={onOpenDuckingSettings}
                  title="Configure Audio Ducking Parameters"
                  className="p-1 rounded text-zinc-400 hover:text-amber-400 hover:bg-zinc-850 transition-colors"
                >
                  <Sliders className="w-3 h-3" />
                </button>
              )}
            </div>
          )}

          {/* Audio Beat Sync Quick Control & Snapping */}
          {beatSync && (
            <div className="flex items-center gap-1 bg-zinc-950 p-0.5 rounded-lg border border-amber-500/35">
              <button
                onClick={onToggleBeatSnapping}
                title={
                  beatSync.enabled
                    ? `Audio Beat Sync Active (${beatSync.bpm} BPM) - Magnetic Snap is ${beatSync.snappingEnabled ? 'ON' : 'OFF'}`
                    : 'Click to Enable Audio Beat Sync'
                }
                className={`flex items-center gap-1.5 px-2 py-1 rounded text-xs font-bold transition-all ${
                  beatSync.enabled && beatSync.snappingEnabled
                    ? 'bg-amber-500/25 text-amber-300 border border-amber-500/40 shadow-sm'
                    : 'text-zinc-500 hover:text-zinc-300'
                }`}
              >
                <Activity className="w-3.5 h-3.5 text-amber-400" />
                <span>Beat Sync: {beatSync.bpm} BPM</span>
                {beatSync.snappingEnabled && (
                  <span className="text-[9px] px-1 rounded bg-amber-500 text-zinc-950 font-black">
                    SNAP
                  </span>
                )}
              </button>

              {onOpenBeatSyncModal && (
                <button
                  onClick={onOpenBeatSyncModal}
                  title="Audio Beat Sync & Waveform Transient Settings"
                  className="p-1 rounded text-zinc-400 hover:text-amber-400 hover:bg-zinc-850 transition-colors"
                >
                  <Sliders className="w-3 h-3" />
                </button>
              )}
            </div>
          )}

          {/* Draggable Transitions Library Button */}
          {onOpenTransitionsLibrary && (
            <button
              onClick={onOpenTransitionsLibrary}
              title="Open Draggable Transitions Library"
              className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 border border-amber-500/40 text-xs font-bold transition-all shadow-sm"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>Transitions</span>
            </button>
          )}

          {/* Global Keyboard Shortcuts Cheatsheet Button */}
          {onOpenKeyboardShortcuts && (
            <button
              onClick={onOpenKeyboardShortcuts}
              title="Global Keyboard Shortcut Manager (Space, Ctrl+Z, B Razor, etc.)"
              className="flex items-center gap-1 px-2 py-1 rounded-lg bg-zinc-950 hover:bg-zinc-850 text-zinc-300 hover:text-amber-300 border border-zinc-800 transition-colors text-xs font-semibold"
            >
              <Keyboard className="w-3.5 h-3.5 text-amber-400" />
              <span className="hidden sm:inline">Shortcuts</span>
            </button>
          )}
        </div>

        {/* Right: Timeline Zoom Slider & Snap Controls */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setSnapEnabled(!snapEnabled)}
            className={`px-2 py-1 rounded text-[11px] font-semibold transition-colors ${
              snapEnabled
                ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40'
                : 'text-zinc-500 border border-zinc-800 hover:text-zinc-300'
            }`}
          >
            Snap {snapEnabled ? 'ON' : 'OFF'}
          </button>

          {/* Timeline Zoom Slider (1px/s - 150px/s) for Frame-Perfect Precision */}
          <div className="flex items-center gap-2 bg-zinc-950 px-2.5 py-1 rounded-xl border border-zinc-800">
            <button
              onClick={() => updateZoom((z) => Math.max(1, z <= 15 ? z - 2 : z - 15))}
              className="p-1 rounded text-zinc-400 hover:text-amber-400 transition-colors"
              title="Zoom Out (-)"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>

            {/* Slider */}
            <input
              type="range"
              min="1"
              max="150"
              step="1"
              value={activeZoom}
              onChange={(e) => updateZoom(parseInt(e.target.value, 10))}
              className="w-20 sm:w-28 accent-amber-500 cursor-ew-resize h-1.5 bg-zinc-800 rounded-lg"
              title="Timeline Zoom Slider: Frame-perfect horizontal time scaling"
            />

            <button
              onClick={() => updateZoom((z) => Math.min(150, z < 15 ? z + 2 : z + 15))}
              className="p-1 rounded text-zinc-400 hover:text-amber-400 transition-colors"
              title="Zoom In (+)"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>

            <span className="text-[11px] font-mono text-amber-400 font-bold w-14 text-center">
              {activeZoom}px/s
            </span>

            {/* Preset: Fit Entire Timeline */}
            <button
              onClick={handleFitTimeline}
              title="Fit Entire Timeline to Screen"
              className="px-2 py-0.5 rounded text-[10px] font-bold bg-zinc-900 hover:bg-zinc-800 text-zinc-300 hover:text-amber-300 border border-zinc-800 transition-colors"
            >
              Fit
            </button>

            {/* Preset: Frame Precision (150px/s) */}
            <button
              onClick={() => updateZoom(150)}
              title="Frame-Perfect Precision Mode (150px/s)"
              className={`px-2 py-0.5 rounded text-[10px] font-bold border transition-colors ${
                activeZoom >= 140
                  ? 'bg-amber-500 text-zinc-950 border-amber-400 font-black shadow-sm'
                  : 'bg-zinc-900 text-zinc-400 hover:text-amber-300 border-zinc-800'
              }`}
            >
              1F
            </button>
          </div>
        </div>
      </div>

      {/* Main Timeline Workspace */}
      <div className="flex overflow-hidden relative min-h-[300px] select-none">
        {/* Track Headers Column */}
        <div className="w-56 shrink-0 bg-zinc-950/90 border-r border-zinc-800/80 z-20 flex flex-col pt-7">
          {tracks.map((track) => (
            <div
              key={track.id}
              style={{ height: `${track.height}px` }}
              className="flex items-center justify-between px-3 border-b border-zinc-850 hover:bg-zinc-900/40 transition-colors"
            >
              <div className="flex items-center gap-2 truncate">
                {getTrackIcon(track.type)}
                <span className="text-xs font-semibold text-zinc-200 truncate">
                  {track.name}
                </span>
              </div>

              <div className="flex items-center gap-1 shrink-0">
                <button
                  onClick={() => onToggleMuteTrack(track.id)}
                  title={track.muted ? 'Unmute Track' : 'Mute Track'}
                  className={`p-1 rounded hover:bg-zinc-800 transition-colors ${
                    track.muted ? 'text-red-400' : 'text-zinc-500 hover:text-zinc-300'
                  }`}
                >
                  {track.muted ? <VolumeX className="w-3 h-3" /> : <Volume2 className="w-3 h-3" />}
                </button>
                <button
                  onClick={() => onToggleLockTrack(track.id)}
                  title={track.locked ? 'Unlock Track' : 'Lock Track'}
                  className={`p-1 rounded hover:bg-zinc-800 transition-colors ${
                    track.locked ? 'text-amber-400' : 'text-zinc-500 hover:text-zinc-300'
                  }`}
                >
                  {track.locked ? <Lock className="w-3 h-3" /> : <Unlock className="w-3 h-3" />}
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Scrollable Tracks & Timeline Ruler Canvas */}
        <div 
          className="flex-1 overflow-x-auto overflow-y-hidden relative bg-zinc-950" 
          ref={timelineRef}
          onWheel={handleWheel}
        >
          {/* Top Ruler Bar */}
          <div
            className="h-7 border-b border-zinc-800 bg-zinc-900/70 relative cursor-pointer"
            onClick={handleTimelineClick}
          >
            {rulerTicks.map((sec) => (
              <div
                key={sec}
                style={{ left: `${sec * activeZoom}px` }}
                className="absolute top-0 bottom-0 flex flex-col justify-end pb-0.5 border-l border-zinc-700/60 pl-1 text-[10px] font-mono text-zinc-400 select-none whitespace-nowrap"
              >
                {formatRulerLabel(sec)}
              </div>
            ))}

            {/* Audio Beat Sync Ruler Pins */}
            {beatSync?.enabled && beatSync.markers?.map((marker) => {
              const isDownbeat = marker.strength === 'downbeat';
              const markerX = marker.time * activeZoom;

              return (
                <div
                  key={marker.id}
                  onClick={(e) => {
                    e.stopPropagation();
                    onSeek(marker.time);
                    soundEngine.playWhoosh(0.1);
                    setSnappedMarkerAlert(`Snapped to Beat ${marker.label || ''} (${marker.time.toFixed(2)}s)`);
                    setTimeout(() => setSnappedMarkerAlert(null), 1200);
                  }}
                  style={{ left: `${markerX}px` }}
                  title={`Beat ${marker.label || ''} (${marker.time.toFixed(2)}s) - Click to Snap`}
                  className="absolute top-0 bottom-0 z-10 flex flex-col items-center cursor-pointer group"
                >
                  <div
                    className={`transition-all ${
                      isDownbeat
                        ? 'w-2 h-2 bg-amber-400 rotate-45 mt-0.5 shadow-[0_0_6px_rgba(245,158,11,0.9)] group-hover:scale-125'
                        : 'w-1.5 h-1.5 bg-yellow-500/80 rounded-full mt-1.5 group-hover:scale-125'
                    }`}
                  />
                </div>
              );
            })}
          </div>

          {/* Floating Magnetic Snap Alert */}
          {snappedMarkerAlert && (
            <div className="absolute top-8 left-1/2 -translate-x-1/2 z-40 px-3.5 py-1.5 rounded-full bg-zinc-950/95 border border-amber-400 text-amber-300 text-xs font-mono font-bold shadow-2xl animate-in fade-in zoom-in-95 flex items-center gap-2 pointer-events-none">
              <Magnet className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
              <span>{snappedMarkerAlert}</span>
            </div>
          )}

          {/* Track Lanes */}
          <div className="relative min-w-full" onClick={handleTimelineClick}>
            {/* Vertical Beat Guide Lines across tracks */}
            {beatSync?.enabled && (
              <div className="absolute inset-0 pointer-events-none z-0">
                {beatSync.markers?.map((marker) => {
                  const isDownbeat = marker.strength === 'downbeat';
                  return (
                    <div
                      key={'grid-' + marker.id}
                      style={{ left: `${marker.time * activeZoom}px` }}
                      className={`absolute top-0 bottom-0 pointer-events-none ${
                        isDownbeat
                          ? 'border-l border-amber-500/30 shadow-[0_0_6px_rgba(245,158,11,0.2)]'
                          : 'border-l border-amber-500/10'
                      }`}
                    />
                  );
                })}
              </div>
            )}
            {tracks.map((track) => {
              const trackClips = clips.filter((c) => c.trackId === track.id);

              return (
                <div
                  key={track.id}
                  style={{ height: `${track.height}px` }}
                  className="relative border-b border-zinc-850/80 bg-zinc-950/40 hover:bg-zinc-900/20 transition-colors"
                >
                  {trackClips.map((clip) => {
                    const isSelected = clip.id === selectedClipId;
                    const clipWidth = Math.max(24, clip.duration * activeZoom);
                    const clipLeft = clip.startTime * activeZoom;

                    // Detect if this background music clip has active AI Audio Ducking
                    const isDuckedByVoice =
                      clip.trackId === (audioDucking?.backgroundMusicTrackId || 'track-a1') &&
                      Boolean(audioDucking?.enabled) &&
                      clips.some(
                        (vc) =>
                          (vc.trackId === (audioDucking?.targetVoiceTrackId || 'track-a3') ||
                            vc.type === 'voiceover' ||
                            vc.title.toLowerCase().includes('voice')) &&
                          Math.max(clip.startTime, vc.startTime) <
                            Math.min(clip.startTime + clip.duration, vc.startTime + vc.duration)
                      );

                    const isAudioClip =
                      clip.type === 'audio' ||
                      clip.type === 'voiceover' ||
                      track.type === 'audio' ||
                      track.type === 'sfx' ||
                      track.type === 'voiceover';
                    const isVideoClip =
                      clip.type === 'video' || clip.type === 'pip' || track.type === 'video' || track.type === 'pip';
                    const isDragOverTarget = dragOverClipId === clip.id;

                    return (
                      <div
                        key={clip.id}
                        onClick={(e) => {
                          e.stopPropagation();
                          onSelectClip(clip.id);
                        }}
                        onDragOver={(e) => {
                          if (isVideoClip) {
                            e.preventDefault();
                            e.dataTransfer.dropEffect = 'copy';
                            if (dragOverClipId !== clip.id) {
                              setDragOverClipId(clip.id);
                            }
                          }
                        }}
                        onDragLeave={() => {
                          if (dragOverClipId === clip.id) {
                            setDragOverClipId(null);
                          }
                        }}
                        onDrop={(e) => {
                          if (!isVideoClip) return;
                          e.preventDefault();
                          setDragOverClipId(null);
                          try {
                            const raw = e.dataTransfer.getData('application/json');
                            if (raw) {
                              const data = JSON.parse(raw);
                              if (data.transitionType) {
                                onUpdateClip(clip.id, {
                                  transition: {
                                    type: data.transitionType,
                                    duration: data.duration || 0.6,
                                  },
                                });
                                soundEngine.playForTransition(data.transitionType);
                                setSnappedMarkerAlert(`Applied ${data.transitionType} transition`);
                                setTimeout(() => setSnappedMarkerAlert(null), 1400);
                              }
                            }
                          } catch (err) {
                            console.error('Failed to parse dropped transition:', err);
                          }
                        }}
                        style={{
                          left: `${clipLeft}px`,
                          width: `${clipWidth}px`,
                        }}
                        className={`absolute top-1 bottom-1 rounded-lg border px-2 py-1 flex items-center justify-between cursor-pointer transition-all overflow-hidden ${
                          isDragOverTarget
                            ? 'ring-2 ring-amber-400 border-amber-300 shadow-[0_0_15px_rgba(245,158,11,0.7)] bg-amber-950/60'
                            : getClipBgColor(clip.type, isSelected)
                        }`}
                      >
                        {/* Audio Waveform Visualization on Audio Track Clips */}
                        {isAudioClip && (
                          <AudioClipWaveform
                            clip={clip}
                            width={clipWidth}
                            height={track.height - 8}
                            isMuted={clip.muted || track.muted}
                            isDucked={isDuckedByVoice}
                            duckingAmount={audioDucking?.duckingAmount}
                          />
                        )}

                        {/* Drag and Drop Highlight Badge */}
                        {isDragOverTarget && (
                          <div className="absolute inset-0 bg-amber-500/20 backdrop-blur-[1px] flex items-center justify-center pointer-events-none z-20">
                            <span className="px-2 py-0.5 rounded-md bg-amber-500 text-zinc-950 font-bold text-[10px] shadow-md flex items-center gap-1 animate-pulse">
                              <Sparkles className="w-3 h-3" />
                              Drop Transition Here
                            </span>
                          </div>
                        )}

                        {/* Clip Content Preview */}
                        <div className="flex items-center gap-1.5 truncate relative z-10">
                          {clip.thumbnail && (
                            <img
                              src={clip.thumbnail}
                              alt=""
                              className="w-5 h-5 rounded object-cover shrink-0 border border-black/30"
                            />
                          )}
                          <span className={`text-[11px] font-bold truncate ${isSelected ? 'text-zinc-950' : 'text-zinc-100'}`}>
                            {clip.textOverlay?.text || clip.title}
                          </span>
                        </div>

                        {/* Ducking Active Badge on Music Clip */}
                        {isDuckedByVoice && (
                          <div
                            title={`AI Audio Ducking active: Volume drops to ${audioDucking?.duckingAmount}% (-14dB) during speech`}
                            className="shrink-0 flex items-center gap-1 px-1.5 py-0.5 rounded text-[9px] font-extrabold bg-amber-500/25 text-amber-300 border border-amber-500/50 shadow-sm"
                          >
                            <Mic className="w-2.5 h-2.5 text-amber-400" />
                            <span>Ducked {audioDucking?.duckingAmount}%</span>
                          </div>
                        )}

                        {/* Transition Badge if attached */}
                        {clip.transition && clip.transition.type !== 'none' && (
                          <div
                            onClick={(e) => {
                              e.stopPropagation();
                              soundEngine.playForTransition(clip.transition!.type);
                            }}
                            title={`Transition: ${clip.transition.type} (${clip.transition.duration}s)`}
                            className={`shrink-0 flex items-center gap-0.5 px-1 py-0.5 rounded text-[9px] font-bold uppercase ${
                              isSelected
                                ? 'bg-zinc-950/80 text-amber-300'
                                : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                            }`}
                          >
                            <Sparkles className="w-2.5 h-2.5" />
                            <span>{clip.transition.type}</span>
                          </div>
                        )}

                        {/* Trim Handles */}
                        {isSelected && (
                          <>
                            <div className="absolute left-0 top-0 bottom-0 w-2 bg-amber-300 hover:w-3 cursor-ew-resize opacity-80" />
                            <div className="absolute right-0 top-0 bottom-0 w-2 bg-amber-300 hover:w-3 cursor-ew-resize opacity-80" />
                          </>
                        )}
                      </div>
                    );
                  })}
                </div>
              );
            })}

            {/* Draggable Red/Gold Playhead Indicator */}
            <div
              style={{ left: `${currentTime * activeZoom}px` }}
              className="absolute top-0 bottom-0 w-px bg-amber-400 z-30 pointer-events-none shadow-[0_0_8px_rgba(212,175,55,0.8)]"
            >
              <div className="w-3.5 h-4 bg-gradient-to-b from-amber-400 to-yellow-600 rounded-b -translate-x-[6px] shadow-md flex items-center justify-center">
                <div className="w-1 h-1 rounded-full bg-zinc-950" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
