import React, { useState } from 'react';
import { CaptionItem, CaptionStyleConfig, EditorClip } from '../../types';
import { 
  Subtitles, 
  Sparkles, 
  Download, 
  Plus, 
  Trash2, 
  Play, 
  Eye, 
  EyeOff, 
  FileText, 
  Check, 
  Sliders, 
  Upload,
  RefreshCw,
  X,
  Type
} from 'lucide-react';
import { generateSRTCaptions } from '../../services/api';
import { parseSRT, formatToSRT, generateProceduralCaptions, secondsToSrtTime } from '../../utils/srtParser';
import confetti from 'canvas-confetti';

interface CaptionsModalProps {
  isOpen: boolean;
  onClose: () => void;
  clips: EditorClip[];
  totalDuration: number;
  captions: CaptionItem[];
  onCaptionsChange: (captions: CaptionItem[]) => void;
  captionStyle: CaptionStyleConfig;
  onCaptionStyleChange: (style: CaptionStyleConfig) => void;
  onSeek: (time: number) => void;
  onApplyToTimeline: (captions: CaptionItem[]) => void;
}

export const CaptionsModal: React.FC<CaptionsModalProps> = ({
  isOpen,
  onClose,
  clips,
  totalDuration,
  captions,
  onCaptionsChange,
  captionStyle,
  onCaptionStyleChange,
  onSeek,
  onApplyToTimeline,
}) => {
  const [isGenerating, setIsGenerating] = useState(false);
  const [activeTab, setActiveTab] = useState<'editor' | 'style' | 'raw'>('editor');
  const [rawSrtText, setRawSrtText] = useState('');
  const [newText, setNewText] = useState('');
  const [newStart, setNewStart] = useState('0');
  const [newEnd, setNewEnd] = useState('3');
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  // Filter audio and video clips present in the editor
  const audioTracksInfo = clips
    .filter((c) => c.type === 'audio' || c.type === 'video' || c.trackId.startsWith('track-a'))
    .map((c) => ({
      title: c.title,
      type: c.type,
      startTime: c.startTime,
      duration: c.duration,
    }));

  // Auto-generate SRT captions using backend Gemini 3.8 Flash
  const handleAutoGenerate = async () => {
    setIsGenerating(true);
    try {
      const generatedSRT = await generateSRTCaptions(
        audioTracksInfo,
        totalDuration,
        clips[0]?.title || 'Cinematic Cut'
      );

      let parsed: CaptionItem[] = [];
      if (generatedSRT) {
        parsed = parseSRT(generatedSRT);
      }

      if (parsed.length === 0) {
        // Fallback procedural generator tailored to audio tracks
        parsed = generateProceduralCaptions(audioTracksInfo, totalDuration);
      }

      onCaptionsChange(parsed);
      setRawSrtText(formatToSRT(parsed));
      confetti({ particleCount: 50, spread: 70 });
    } catch {
      const procedural = generateProceduralCaptions(audioTracksInfo, totalDuration);
      onCaptionsChange(procedural);
      setRawSrtText(formatToSRT(procedural));
    } finally {
      setIsGenerating(false);
    }
  };

  // Add individual caption line
  const handleAddCaption = () => {
    if (!newText.trim()) return;
    const start = parseFloat(newStart) || 0;
    const end = parseFloat(newEnd) || start + 3;

    const newItem: CaptionItem = {
      id: 'cap-' + Date.now(),
      startTime: start,
      endTime: Math.max(start + 0.5, end),
      text: newText.trim(),
    };

    const updated = [...captions, newItem].sort((a, b) => a.startTime - b.startTime);
    onCaptionsChange(updated);
    setNewText('');
    setNewStart(String(newItem.endTime + 0.5));
    setNewEnd(String(newItem.endTime + 3.5));
  };

  // Delete caption line
  const handleDeleteCaption = (id: string) => {
    onCaptionsChange(captions.filter((c) => c.id !== id));
  };

  // Update caption text
  const handleUpdateCaptionText = (id: string, text: string) => {
    onCaptionsChange(captions.map((c) => (c.id === id ? { ...c, text } : c)));
  };

  // Download SRT file
  const handleDownloadSRT = () => {
    const srtData = formatToSRT(captions);
    const blob = new Blob([srtData], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'motionai_captions.srt';
    link.click();
    URL.revokeObjectURL(url);
    confetti({ particleCount: 30, spread: 60 });
  };

  // Parse raw text into captions
  const handleApplyRawSRT = () => {
    const parsed = parseSRT(rawSrtText);
    if (parsed.length > 0) {
      onCaptionsChange(parsed);
      setActiveTab('editor');
      confetti({ particleCount: 30 });
    } else {
      alert('Could not parse valid SRT. Ensure timestamp format is 00:00:00,000 --> 00:00:03,000');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="relative w-full max-w-2xl bg-zinc-950 border border-amber-500/40 rounded-2xl p-5 shadow-2xl space-y-4 max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-zinc-800 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <Subtitles className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-extrabold text-base text-zinc-100">
                  AI Auto SRT Captions & Subtitles
                </h3>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40">
                  Gemini 3.8
                </span>
              </div>
              <p className="text-xs text-zinc-400 mt-0.5">
                Automatically transcribe and synchronize subtitles from audio tracks directly onto the video preview.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-zinc-100 hover:bg-zinc-900 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Auto Generate Action Bar */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 p-3.5 rounded-xl bg-zinc-900/80 border border-amber-500/30 shrink-0">
          <div className="flex items-center gap-2 text-xs">
            <span className="text-zinc-400">Timeline Audio:</span>
            <span className="font-bold text-amber-300">{audioTracksInfo.length} audio/dialog tracks</span>
            <span className="text-zinc-600">·</span>
            <span className="font-mono text-zinc-400">{totalDuration.toFixed(1)}s duration</span>
          </div>

          <button
            onClick={handleAutoGenerate}
            disabled={isGenerating}
            className="w-full sm:w-auto px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-amber-400 hover:to-yellow-500 text-zinc-950 font-extrabold text-xs shadow-md shadow-amber-500/25 flex items-center justify-center gap-2 transition-all hover:scale-[1.02] disabled:opacity-50"
          >
            {isGenerating ? (
              <>
                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                <span>Transcribing & Aligning SRT...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-3.5 h-3.5 fill-zinc-950" />
                <span>Auto Generate SRT Captions</span>
              </>
            )}
          </button>
        </div>

        {/* Navigation Tabs & Live Overlay Toggle */}
        <div className="flex items-center justify-between border-b border-zinc-800 pb-2 shrink-0">
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setActiveTab('editor')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                activeTab === 'editor'
                  ? 'bg-amber-500 text-zinc-950 shadow-sm'
                  : 'text-zinc-400 hover:text-amber-300'
              }`}
            >
              Captions ({captions.length})
            </button>
            <button
              onClick={() => setActiveTab('style')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                activeTab === 'style'
                  ? 'bg-amber-500 text-zinc-950 shadow-sm'
                  : 'text-zinc-400 hover:text-amber-300'
              }`}
            >
              Overlay Style
            </button>
            <button
              onClick={() => {
                setRawSrtText(formatToSRT(captions));
                setActiveTab('raw');
              }}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                activeTab === 'raw'
                  ? 'bg-amber-500 text-zinc-950 shadow-sm'
                  : 'text-zinc-400 hover:text-amber-300'
              }`}
            >
              Raw .SRT File
            </button>
          </div>

          {/* Toggle Live Preview Overlay */}
          <button
            onClick={() =>
              onCaptionStyleChange({
                ...captionStyle,
                enabled: !captionStyle.enabled,
              })
            }
            className={`flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-bold transition-all border ${
              captionStyle.enabled
                ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/40 shadow-sm'
                : 'bg-zinc-900 text-zinc-500 border-zinc-800'
            }`}
          >
            {captionStyle.enabled ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
            <span>Preview Overlay: {captionStyle.enabled ? 'ON' : 'OFF'}</span>
          </button>
        </div>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto space-y-3 pr-1">
          {/* TAB 1: Caption Items List */}
          {activeTab === 'editor' && (
            <div className="space-y-3">
              {/* Add New Line Bar */}
              <div className="p-3 rounded-xl bg-zinc-900/60 border border-zinc-800 space-y-2">
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={newText}
                    onChange={(e) => setNewText(e.target.value)}
                    placeholder="Enter new caption phrase..."
                    className="flex-1 px-3 py-1.5 rounded-lg bg-zinc-900 border border-zinc-800 text-zinc-100 text-xs focus:border-amber-500 focus:outline-none"
                    onKeyDown={(e) => e.key === 'Enter' && handleAddCaption()}
                  />
                  <div className="flex items-center gap-1 shrink-0">
                    <input
                      type="number"
                      step="0.5"
                      value={newStart}
                      onChange={(e) => setNewStart(e.target.value)}
                      placeholder="Start s"
                      className="w-16 px-2 py-1.5 rounded-lg bg-zinc-900 border border-zinc-800 text-zinc-200 text-xs font-mono"
                      title="Start timestamp in seconds"
                    />
                    <span className="text-zinc-600">→</span>
                    <input
                      type="number"
                      step="0.5"
                      value={newEnd}
                      onChange={(e) => setNewEnd(e.target.value)}
                      placeholder="End s"
                      className="w-16 px-2 py-1.5 rounded-lg bg-zinc-900 border border-zinc-800 text-zinc-200 text-xs font-mono"
                      title="End timestamp in seconds"
                    />
                  </div>
                  <button
                    onClick={handleAddCaption}
                    className="px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold text-xs shrink-0 flex items-center gap-1 transition-colors"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add</span>
                  </button>
                </div>
              </div>

              {/* Captions Table */}
              {captions.length === 0 ? (
                <div className="text-center py-10 bg-zinc-900/30 rounded-xl border border-zinc-850 p-6 space-y-2">
                  <Subtitles className="w-8 h-8 text-zinc-600 mx-auto" />
                  <p className="text-xs text-zinc-400 font-semibold">No captions generated yet.</p>
                  <p className="text-[11px] text-zinc-500">
                    Click "Auto Generate SRT Captions" above to transcribe timeline audio tracks automatically.
                  </p>
                </div>
              ) : (
                <div className="space-y-2">
                  {captions.map((cap, idx) => (
                    <div
                      key={cap.id}
                      className="flex items-center gap-2 p-2.5 rounded-xl bg-zinc-900/50 border border-zinc-850 hover:border-amber-500/30 transition-all group"
                    >
                      <button
                        onClick={() => onSeek(cap.startTime)}
                        className="w-7 h-7 rounded-lg bg-zinc-800 hover:bg-amber-500 hover:text-zinc-950 text-zinc-400 flex items-center justify-center text-xs font-mono font-bold shrink-0 transition-colors"
                        title="Seek playhead to this caption"
                      >
                        <Play className="w-3 h-3 fill-current translate-x-0.5" />
                      </button>

                      <div className="text-[11px] font-mono text-amber-400/90 shrink-0 w-24">
                        {secondsToSrtTime(cap.startTime).slice(3, 8)} → {secondsToSrtTime(cap.endTime).slice(3, 8)}
                      </div>

                      <input
                        type="text"
                        value={cap.text}
                        onChange={(e) => handleUpdateCaptionText(cap.id, e.target.value)}
                        className="flex-1 px-2.5 py-1 rounded bg-zinc-900 border border-transparent hover:border-zinc-700 focus:border-amber-500 text-zinc-100 text-xs font-medium focus:outline-none"
                      />

                      <button
                        onClick={() => handleDeleteCaption(cap.id)}
                        className="p-1 rounded text-zinc-600 hover:text-red-400 hover:bg-zinc-850 transition-colors shrink-0"
                        title="Delete caption line"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 2: Overlay Styling */}
          {activeTab === 'style' && (
            <div className="space-y-4 p-2">
              <div>
                <label className="block text-xs font-bold text-zinc-300 uppercase tracking-wider mb-2">
                  Subtitle Style Preset
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {[
                    { id: 'dark-gold', name: 'Cinematic Dark Gold', desc: 'Warm amber glow & gold text' },
                    { id: 'minimal-white', name: 'Minimal White', desc: 'Crisp white with black outline' },
                    { id: 'boxed', name: 'Boxed Cinema', desc: 'Translucent dark container' },
                    { id: 'karaoke', name: 'Karaoke Pop', desc: 'Bright yellow with amber borders' },
                    { id: 'neon', name: 'Cyberpunk Neon', desc: 'High-intensity electric amber' },
                  ].map((preset) => (
                    <button
                      key={preset.id}
                      onClick={() =>
                        onCaptionStyleChange({
                          ...captionStyle,
                          preset: preset.id as any,
                          color: preset.id === 'minimal-white' ? '#FFFFFF' : '#FCD34D',
                        })
                      }
                      className={`p-3 rounded-xl border text-left transition-all ${
                        captionStyle.preset === preset.id
                          ? 'bg-amber-500/15 border-amber-400 text-amber-300 shadow-sm ring-1 ring-amber-400'
                          : 'bg-zinc-900 border-zinc-800 text-zinc-300 hover:border-zinc-700'
                      }`}
                    >
                      <div className="font-extrabold text-xs">{preset.name}</div>
                      <div className="text-[10px] text-zinc-500 mt-0.5">{preset.desc}</div>
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Font Size */}
                <div className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="font-bold text-zinc-400">Font Size:</span>
                    <span className="font-mono text-amber-400">{captionStyle.fontSize}px</span>
                  </div>
                  <input
                    type="range"
                    min="14"
                    max="40"
                    step="1"
                    value={captionStyle.fontSize}
                    onChange={(e) =>
                      onCaptionStyleChange({
                        ...captionStyle,
                        fontSize: parseInt(e.target.value, 10),
                      })
                    }
                    className="w-full accent-amber-500 cursor-pointer"
                  />
                </div>

                {/* Vertical Position */}
                <div className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="font-bold text-zinc-400">Vertical Position:</span>
                    <span className="font-mono text-amber-400">
                      {captionStyle.positionY <= 30
                        ? 'Top'
                        : captionStyle.positionY <= 65
                        ? 'Middle'
                        : 'Bottom'}{' '}
                      ({captionStyle.positionY}%)
                    </span>
                  </div>
                  <input
                    type="range"
                    min="15"
                    max="90"
                    step="1"
                    value={captionStyle.positionY}
                    onChange={(e) =>
                      onCaptionStyleChange({
                        ...captionStyle,
                        positionY: parseInt(e.target.value, 10),
                      })
                    }
                    className="w-full accent-amber-500 cursor-pointer"
                  />
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: Raw SRT File */}
          {activeTab === 'raw' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs text-zinc-400">
                <span>Direct .SRT Content:</span>
                <span className="text-zinc-500 font-mono">UTF-8 Standard SubRip Format</span>
              </div>
              <textarea
                rows={10}
                value={rawSrtText}
                onChange={(e) => setRawSrtText(e.target.value)}
                className="w-full p-3 rounded-xl bg-zinc-900 border border-zinc-800 font-mono text-xs text-amber-200/90 focus:border-amber-500 focus:outline-none resize-none leading-relaxed"
              />
              <button
                onClick={handleApplyRawSRT}
                className="w-full py-2 rounded-xl bg-zinc-900 hover:bg-zinc-850 text-amber-300 border border-amber-500/30 text-xs font-bold transition-colors"
              >
                Parse & Update Captions from Raw SRT
              </button>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-2 pt-3 border-t border-zinc-800 shrink-0">
          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              onClick={() => {
                onApplyToTimeline(captions);
                onClose();
              }}
              disabled={captions.length === 0}
              className="flex-1 sm:flex-initial flex items-center justify-center gap-1.5 px-3.5 py-2 rounded-xl bg-zinc-900 hover:bg-zinc-850 text-amber-400 border border-amber-500/40 text-xs font-bold disabled:opacity-40 transition-colors"
            >
              <Type className="w-3.5 h-3.5" />
              <span>Convert to Timeline Clips</span>
            </button>

            <button
              onClick={handleDownloadSRT}
              disabled={captions.length === 0}
              className="flex-1 sm:flex-initial flex items-center justify-center gap-1.5 px-3.5 py-2 rounded-xl bg-zinc-900 hover:bg-zinc-850 text-zinc-200 border border-zinc-800 text-xs font-bold disabled:opacity-40 transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download .SRT</span>
            </button>
          </div>

          <button
            onClick={onClose}
            className="w-full sm:w-auto px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-amber-400 hover:to-yellow-500 text-zinc-950 font-bold text-xs shadow-md shadow-amber-500/20"
          >
            Apply & Close
          </button>
        </div>
      </div>
    </div>
  );
};
