import React, { useState, useEffect } from 'react';
import { 
  EditorClip, 
  TimelineTrack, 
  AspectRatio, 
  CaptionItem, 
  CaptionStyleConfig,
  AudioDuckingConfig,
  BeatSyncConfig
} from '../../types';
import { VideoViewport } from './VideoViewport';
import { MultiTrackTimeline } from './MultiTrackTimeline';
import { EditorInspector } from './EditorInspector';
import { CaptionsModal } from './CaptionsModal';
import { AudioDuckingModal } from './AudioDuckingModal';
import { AudioBeatSyncModal } from './AudioBeatSyncModal';
import { TransitionsLibrary } from './TransitionsLibrary';
import { KeyboardShortcutsModal } from './KeyboardShortcutsModal';
import { STOCK_LIBRARY } from '../../data/sampleClips';
import { soundEngine } from '../../utils/transitionSound';
import { generateBeatMarkers, findNearestBeatMarker } from '../../utils/beatSyncEngine';
import confetti from 'canvas-confetti';

interface CapCutEditorProps {
  tracks: TimelineTrack[];
  clips: EditorClip[];
  onClipsChange: (clips: EditorClip[]) => void;
  onTracksChange: (tracks: TimelineTrack[]) => void;
  onQuickExport: () => void;
}

interface HistoryEntry {
  clips: EditorClip[];
  tracks: TimelineTrack[];
  action: string;
}

export const CapCutEditor: React.FC<CapCutEditorProps> = ({
  tracks,
  clips,
  onClipsChange,
  onTracksChange,
  onQuickExport,
}) => {
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [aspectRatio, setAspectRatio] = useState<AspectRatio>('16:9');
  const [selectedClipId, setSelectedClipId] = useState<string | null>('clip-1');

  // Timeline Zoom Slider State (1px/s to 150px/s for frame-perfect precision)
  const [zoomLevel, setZoomLevel] = useState<number>(35);

  // Global Undo / Redo History Stack
  const [history, setHistory] = useState<HistoryEntry[]>([]);
  const [future, setFuture] = useState<HistoryEntry[]>([]);

  // Push history snapshot before any timeline mutation
  const pushHistory = (action = 'Edit') => {
    setHistory((prev) => [
      ...prev.slice(-40),
      {
        clips: JSON.parse(JSON.stringify(clips)),
        tracks: JSON.parse(JSON.stringify(tracks)),
        action,
      },
    ]);
    setFuture([]);
  };

  // Undo last action
  const handleUndo = () => {
    if (history.length === 0) return;
    const prevEntry = history[history.length - 1];
    const newHistory = history.slice(0, history.length - 1);

    setFuture((f) => [
      {
        clips: JSON.parse(JSON.stringify(clips)),
        tracks: JSON.parse(JSON.stringify(tracks)),
        action: 'Current State',
      },
      ...f,
    ]);
    setHistory(newHistory);
    onClipsChange(prevEntry.clips);
    onTracksChange(prevEntry.tracks);
    soundEngine.playWhoosh(0.15);
  };

  // Redo reverted action
  const handleRedo = () => {
    if (future.length === 0) return;
    const nextEntry = future[0];
    const newFuture = future.slice(1);

    setHistory((h) => [
      ...h,
      {
        clips: JSON.parse(JSON.stringify(clips)),
        tracks: JSON.parse(JSON.stringify(tracks)),
        action: 'Reverted State',
      },
    ]);
    setFuture(newFuture);
    onClipsChange(nextEntry.clips);
    onTracksChange(nextEntry.tracks);
    soundEngine.playWhoosh(0.15);
  };

  // AI-Powered Audio Ducking Configuration State
  const [audioDucking, setAudioDucking] = useState<AudioDuckingConfig>({
    enabled: true,
    duckingAmount: 20, // 20% volume (-14 dB)
    attackTime: 0.25,
    releaseTime: 0.35,
    targetVoiceTrackId: 'track-a3',
    backgroundMusicTrackId: 'track-a1',
  });
  const [isDuckingModalOpen, setIsDuckingModalOpen] = useState<boolean>(false);

  // Audio Beat Sync Configuration State (Rhythmic Transients & Magnetic Cuts)
  const [beatSync, setBeatSync] = useState<BeatSyncConfig>({
    enabled: true,
    bpm: 120,
    snappingEnabled: true,
    snapThreshold: 0.15,
    markers: generateBeatMarkers(120, 30),
    isAnalyzing: false,
    autoAlignCuts: true,
    sourceTrackId: 'track-a1',
  });
  const [isBeatSyncModalOpen, setIsBeatSyncModalOpen] = useState<boolean>(false);

  // Draggable Transitions Library State
  const [isTransitionsSidebarOpen, setIsTransitionsSidebarOpen] = useState<boolean>(false);

  // Global Keyboard Shortcuts Manager Modal State
  const [isKeyboardModalOpen, setIsKeyboardModalOpen] = useState<boolean>(false);

  // Auto SRT Captions State
  const [captions, setCaptions] = useState<CaptionItem[]>([
    {
      id: 'cap-1',
      startTime: 0.6,
      endTime: 3.4,
      text: 'Motionai neural video engine initialized.',
    },
    {
      id: 'cap-2',
      startTime: 3.8,
      endTime: 6.8,
      text: 'Synchronizing multi-track cinema audio frequencies.',
    },
    {
      id: 'cap-3',
      startTime: 7.2,
      endTime: 10.4,
      text: 'Real-time color grade and volumetric amber lighting.',
    },
  ]);

  const [captionStyle, setCaptionStyle] = useState<CaptionStyleConfig>({
    preset: 'dark-gold',
    fontSize: 22,
    positionY: 82,
    color: '#FCD34D',
    enabled: true,
  });

  const [isCaptionsModalOpen, setIsCaptionsModalOpen] = useState<boolean>(false);

  // Compute total timeline duration from furthest clip
  const totalDuration = Math.max(
    10,
    ...clips.map((c) => c.startTime + c.duration)
  );

  // Playback timer ticker
  useEffect(() => {
    let animFrame: number;
    let lastTimestamp = performance.now();

    const loop = (now: number) => {
      if (isPlaying) {
        const delta = (now - lastTimestamp) / 1000;
        setCurrentTime((prev) => {
          const next = prev + delta;
          if (next >= totalDuration) {
            setIsPlaying(false);
            return 0;
          }
          return next;
        });
      }
      lastTimestamp = now;
      animFrame = requestAnimationFrame(loop);
    };

    animFrame = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animFrame);
  }, [isPlaying, totalDuration]);

  // Global Keyboard Shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't intercept when user is typing in inputs or textareas
      if (['INPUT', 'TEXTAREA'].includes((e.target as HTMLElement).tagName)) {
        return;
      }

      if (e.code === 'Space') {
        e.preventDefault();
        setIsPlaying((prev) => !prev);
      } else if (e.key === 'b' || e.key === 'B') {
        // 'B' key: Razor tool - split clip under playhead or selected clip
        e.preventDefault();
        handleSplitTool();
      } else if (e.key === 's' || e.key === 'S') {
        e.preventDefault();
        handleSplitTool();
      } else if (e.key === 'Delete' || e.key === 'Backspace') {
        if (selectedClipId) {
          handleDeleteClip(selectedClipId);
        }
      } else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z' && !e.shiftKey) {
        e.preventDefault();
        handleUndo();
      } else if (
        (e.ctrlKey || e.metaKey) &&
        (e.key.toLowerCase() === 'y' || (e.shiftKey && e.key.toLowerCase() === 'z'))
      ) {
        e.preventDefault();
        handleRedo();
      } else if (e.key === '?') {
        setIsKeyboardModalOpen((prev) => !prev);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedClipId, currentTime, clips, history, future]);

  // Split clip at current playhead position
  const handleSplitClip = (clipId: string) => {
    const clip = clips.find((c) => c.id === clipId);
    if (!clip) return;

    if (currentTime <= clip.startTime || currentTime >= clip.startTime + clip.duration) {
      return;
    }

    pushHistory('Split Clip');

    // Magnetic Beat Snapping: Align cuts to nearest beat marker
    let cutPoint = currentTime;
    if (beatSync.enabled && beatSync.snappingEnabled && beatSync.markers?.length) {
      const snap = findNearestBeatMarker(currentTime, beatSync.markers, beatSync.snapThreshold);
      if (snap.didSnap && snap.snappedTime > clip.startTime + 0.1 && snap.snappedTime < clip.startTime + clip.duration - 0.1) {
        cutPoint = snap.snappedTime;
      }
    }

    const firstDuration = cutPoint - clip.startTime;
    const secondDuration = clip.duration - firstDuration;

    const firstClip: EditorClip = {
      ...clip,
      duration: firstDuration,
      trimEnd: clip.trimStart + firstDuration,
    };

    const secondClip: EditorClip = {
      ...clip,
      id: 'clip-' + Date.now(),
      startTime: cutPoint,
      duration: secondDuration,
      trimStart: clip.trimStart + firstDuration,
      trimEnd: clip.trimEnd,
      transition: undefined, // split point transition resets
    };

    onClipsChange(clips.map((c) => (c.id === clipId ? firstClip : c)).concat(secondClip));
    setSelectedClipId(secondClip.id);
    soundEngine.playWhoosh(0.2);
  };

  // Split tool handler: cuts selected clip, or clip under the playhead into two distinct segments
  const handleSplitTool = () => {
    let targetClipId = selectedClipId;
    if (!targetClipId) {
      const clipUnderPlayhead =
        clips.find((c) => c.trackId.startsWith('track-v') && currentTime > c.startTime && currentTime < c.startTime + c.duration) ||
        clips.find((c) => currentTime > c.startTime && currentTime < c.startTime + c.duration);
      if (clipUnderPlayhead) {
        targetClipId = clipUnderPlayhead.id;
      }
    }

    if (targetClipId) {
      handleSplitClip(targetClipId);
    }
  };

  // Delete clip
  const handleDeleteClip = (clipId: string) => {
    pushHistory('Delete Clip');
    onClipsChange(clips.filter((c) => c.id !== clipId));
    if (selectedClipId === clipId) {
      setSelectedClipId(null);
    }
  };

  // Duplicate clip
  const handleDuplicateClip = (clipId: string) => {
    const clip = clips.find((c) => c.id === clipId);
    if (!clip) return;

    pushHistory('Duplicate Clip');

    const duplicated: EditorClip = {
      ...clip,
      id: 'clip-' + Date.now(),
      startTime: clip.startTime + clip.duration + 0.2,
      title: `${clip.title} (Copy)`,
    };

    onClipsChange([...clips, duplicated]);
    setSelectedClipId(duplicated.id);
    soundEngine.playImpact();
  };

  // Update clip properties
  const handleUpdateClip = (clipId: string, updates: Partial<EditorClip>) => {
    pushHistory('Update Clip');
    onClipsChange(clips.map((c) => (c.id === clipId ? { ...c, ...updates } : c)));
  };

  // Add stock clip
  const handleAddStockClip = (type: 'video' | 'audio' | 'text') => {
    pushHistory('Add Stock Clip');
    if (type === 'video') {
      const stock = STOCK_LIBRARY[Math.floor(Math.random() * STOCK_LIBRARY.length)];
      const newClip: EditorClip = {
        id: 'clip-' + Date.now(),
        trackId: 'track-v1',
        title: stock.title,
        type: 'video',
        mediaUrl: stock.url,
        thumbnail: stock.thumbnail,
        startTime: totalDuration,
        duration: 5,
        sourceDuration: stock.duration,
        trimStart: 0,
        trimEnd: 5,
        volume: 1,
        muted: false,
        fadeIn: 0.3,
        fadeOut: 0.3,
        speed: 1,
        transition: { type: 'dissolve', duration: 0.5 },
      };
      onClipsChange([...clips, newClip]);
      setSelectedClipId(newClip.id);
      soundEngine.playImpact();
    } else if (type === 'text') {
      const newClip: EditorClip = {
        id: 'clip-' + Date.now(),
        trackId: 'track-txt',
        title: 'New Dynamic Title',
        type: 'text',
        mediaUrl: '',
        startTime: currentTime,
        duration: 3.5,
        sourceDuration: 3.5,
        trimStart: 0,
        trimEnd: 3.5,
        volume: 0,
        muted: true,
        fadeIn: 0.3,
        fadeOut: 0.3,
        speed: 1,
        textOverlay: {
          text: 'CINEMATIC MOMENT',
          style: 'gold-glow',
          fontSize: 32,
          fontFamily: 'Montserrat',
          color: '#d4af37',
          backgroundColor: 'rgba(0,0,0,0.5)',
          x: 50,
          y: 75,
          animation: 'slide-up',
        },
      };
      onClipsChange([...clips, newClip]);
      setSelectedClipId(newClip.id);
    } else if (type === 'audio') {
      const newClip: EditorClip = {
        id: 'clip-' + Date.now(),
        trackId: 'track-a1',
        title: 'Soundtrack Ambient Bed',
        type: 'audio',
        mediaUrl: 'https://cdn.freesound.org/previews/467/467882_9875087-lq.mp3',
        startTime: currentTime,
        duration: 6,
        sourceDuration: 20,
        trimStart: 0,
        trimEnd: 6,
        volume: 0.75,
        muted: false,
        fadeIn: 0.5,
        fadeOut: 0.5,
        speed: 1,
      };
      onClipsChange([...clips, newClip]);
      setSelectedClipId(newClip.id);
    }
  };

  // Add SFX to timeline
  const handleAddSFXClip = (sfxName: string, sfxUrl: string) => {
    pushHistory('Add SFX');
    const newClip: EditorClip = {
      id: 'clip-' + Date.now(),
      trackId: 'track-a2',
      title: sfxName,
      type: 'audio',
      mediaUrl: sfxUrl,
      startTime: currentTime,
      duration: 1.0,
      sourceDuration: 1.0,
      trimStart: 0,
      trimEnd: 1.0,
      volume: 0.9,
      muted: false,
      fadeIn: 0,
      fadeOut: 0,
      speed: 1,
    };
    onClipsChange([...clips, newClip]);
    setSelectedClipId(newClip.id);
    soundEngine.playWhoosh(0.3);
  };

  // Add Voiceover clip
  const handleAddVoiceoverClip = (title: string, voiceUrl: string) => {
    pushHistory('Add Voiceover');
    const newClip: EditorClip = {
      id: 'clip-' + Date.now(),
      trackId: 'track-vo',
      title: title,
      type: 'audio',
      mediaUrl: voiceUrl,
      startTime: currentTime,
      duration: 4.0,
      sourceDuration: 4.0,
      trimStart: 0,
      trimEnd: 4.0,
      volume: 1.0,
      muted: false,
      fadeIn: 0.2,
      fadeOut: 0.2,
      speed: 1,
    };
    onClipsChange([...clips, newClip]);
    setSelectedClipId(newClip.id);
  };

  const handleApplyCaptionsToTimeline = (newCaptions: CaptionItem[]) => {
    pushHistory('Apply Captions');
    const nonCaptionClips = clips.filter((c) => c.trackId !== 'track-txt');
    const newTextClips: EditorClip[] = newCaptions.map((cap, idx) => ({
      id: `text-cap-${idx}-${Date.now()}`,
      trackId: 'track-txt',
      title: cap.text.slice(0, 20),
      type: 'text',
      mediaUrl: '',
      startTime: cap.startTime,
      duration: Math.max(0.5, cap.endTime - cap.startTime),
      sourceDuration: cap.endTime - cap.startTime,
      trimStart: 0,
      trimEnd: cap.endTime - cap.startTime,
      volume: 0,
      muted: true,
      fadeIn: 0.1,
      fadeOut: 0.1,
      speed: 1,
      textOverlay: {
        text: cap.text,
        style: 'gold-glow',
        fontFamily: 'Inter',
        backgroundColor: 'transparent',
        fontSize: captionStyle.fontSize,
        color: captionStyle.color,
        x: 50,
        y: captionStyle.positionY,
        animation: 'fade',
      },
    }));

    onClipsChange([...nonCaptionClips, ...newTextClips]);
  };

  // Bake AI Audio Ducking envelopes into timeline clips
  const handleApplyDuckingKeyframes = () => {
    pushHistory('Bake AI Audio Ducking');
    const voiceClips = clips.filter(
      (c) =>
        c.trackId === audioDucking.targetVoiceTrackId ||
        c.type === 'voiceover' ||
        c.title.toLowerCase().includes('voice')
    );

    if (voiceClips.length === 0) return;

    const updatedClips = clips.map((c) => {
      if (c.trackId === audioDucking.backgroundMusicTrackId || c.type === 'audio') {
        const hasOverlap = voiceClips.some(
          (vc) =>
            Math.max(c.startTime, vc.startTime) <
            Math.min(c.startTime + c.duration, vc.startTime + vc.duration)
        );
        if (hasOverlap) {
          return {
            ...c,
            volume: Math.min(c.volume, audioDucking.duckingAmount / 100),
            fadeIn: Math.max(c.fadeIn, audioDucking.attackTime),
            fadeOut: Math.max(c.fadeOut, audioDucking.releaseTime),
          };
        }
      }
      return c;
    });

    onClipsChange(updatedClips);
  };

  const selectedClip = clips.find((c) => c.id === selectedClipId) || null;

  return (
    <div className="flex flex-col gap-4 max-w-[1720px] mx-auto p-2 sm:p-4">
      {/* Top Split: Composite Viewport & Inspector Side Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left Column: Viewport & Monitor with Caption Overlay */}
        <div className="lg:col-span-7 flex flex-col justify-start">
          <VideoViewport
            currentTime={currentTime}
            duration={totalDuration}
            isPlaying={isPlaying}
            onTogglePlay={() => setIsPlaying(!isPlaying)}
            onSeek={(t) => setCurrentTime(t)}
            aspectRatio={aspectRatio}
            onAspectRatioChange={setAspectRatio}
            clips={clips}
            selectedClipId={selectedClipId}
            captions={captions}
            captionStyle={captionStyle}
            onSplitClip={handleSplitTool}
            audioDucking={audioDucking}
          />
        </div>

        {/* Right Column: Tabbed Inspector */}
        <div className="lg:col-span-5 flex flex-col">
          <EditorInspector
            selectedClip={selectedClip}
            onUpdateClip={handleUpdateClip}
            onAddSFXClip={handleAddSFXClip}
            onAddVoiceoverClip={handleAddVoiceoverClip}
            onExportProject={onQuickExport}
          />
        </div>
      </div>

      {/* Bottom Full-Width Multi-Track Timeline */}
      <div className="w-full">
        <MultiTrackTimeline
          tracks={tracks}
          clips={clips}
          currentTime={currentTime}
          totalDuration={totalDuration}
          selectedClipId={selectedClipId}
          onSelectClip={(id) => setSelectedClipId(id)}
          onSeek={(t) => setCurrentTime(t)}
          onSplitClip={handleSplitClip}
          onDeleteClip={handleDeleteClip}
          onDuplicateClip={handleDuplicateClip}
          onUpdateClip={handleUpdateClip}
          onToggleMuteTrack={(tId) =>
            onTracksChange(
              tracks.map((t) => (t.id === tId ? { ...t, muted: !t.muted } : t))
            )
          }
          onToggleLockTrack={(tId) =>
            onTracksChange(
              tracks.map((t) => (t.id === tId ? { ...t, locked: !t.locked } : t))
            )
          }
          onAddStockClip={handleAddStockClip}
          onOpenCaptionsModal={() => setIsCaptionsModalOpen(true)}
          zoomLevel={zoomLevel}
          onZoomLevelChange={setZoomLevel}
          undoCount={history.length}
          redoCount={future.length}
          onUndo={handleUndo}
          onRedo={handleRedo}
          audioDucking={audioDucking}
          onToggleAudioDucking={() =>
            setAudioDucking((prev) => ({ ...prev, enabled: !prev.enabled }))
          }
          onOpenDuckingSettings={() => setIsDuckingModalOpen(true)}
          beatSync={beatSync}
          onOpenBeatSyncModal={() => setIsBeatSyncModalOpen(true)}
          onToggleBeatSnapping={() =>
            setBeatSync((prev) => ({
              ...prev,
              snappingEnabled: !prev.snappingEnabled,
            }))
          }
        />
      </div>

      {/* Auto SRT Captions Generator & Editor Modal */}
      <CaptionsModal
        isOpen={isCaptionsModalOpen}
        onClose={() => setIsCaptionsModalOpen(false)}
        clips={clips}
        totalDuration={totalDuration}
        captions={captions}
        onCaptionsChange={setCaptions}
        captionStyle={captionStyle}
        onCaptionStyleChange={setCaptionStyle}
        onSeek={(t) => setCurrentTime(t)}
        onApplyToTimeline={handleApplyCaptionsToTimeline}
      />

      {/* AI Audio Ducking Configuration Modal */}
      <AudioDuckingModal
        isOpen={isDuckingModalOpen}
        onClose={() => setIsDuckingModalOpen(false)}
        config={audioDucking}
        onConfigChange={setAudioDucking}
        tracks={tracks}
        clips={clips}
        onApplyDuckingKeyframes={handleApplyDuckingKeyframes}
      />

      {/* Audio Beat Sync & Transient Snapping Modal */}
      <AudioBeatSyncModal
        isOpen={isBeatSyncModalOpen}
        onClose={() => setIsBeatSyncModalOpen(false)}
        config={beatSync}
        onConfigChange={setBeatSync}
        clips={clips}
        onClipsChange={onClipsChange}
        tracks={tracks}
        totalDuration={totalDuration}
      />
    </div>
  );
};
