import React, { useState, useEffect } from 'react';
import { Keyboard, X, Command, Scissors, Play, RotateCcw, RotateCw, Trash2, ZoomIn, Volume2, Sparkles, Check } from 'lucide-react';

interface KeyboardShortcutsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onTriggerAction?: (action: 'play' | 'split' | 'undo' | 'redo' | 'delete') => void;
}

interface ShortcutItem {
  id: string;
  keys: string[];
  title: string;
  description: string;
  category: 'Playback' | 'Editing Tools' | 'History & Timeline';
  icon: any;
}

const SHORTCUTS: ShortcutItem[] = [
  {
    id: 'play-pause',
    keys: ['Space'],
    title: 'Play / Pause Scrubber',
    description: 'Toggles real-time timeline playback and composite monitor',
    category: 'Playback',
    icon: Play,
  },
  {
    id: 'razor-tool',
    keys: ['B'],
    title: 'Razor Tool (Split Clip)',
    description: 'Cuts active clip cleanly at the playhead position into two segments',
    category: 'Editing Tools',
    icon: Scissors,
  },
  {
    id: 'split-clip',
    keys: ['S'],
    title: 'Split Selected Clip',
    description: 'Splits the selected clip at current playhead timecode',
    category: 'Editing Tools',
    icon: Scissors,
  },
  {
    id: 'undo',
    keys: ['Ctrl', 'Z'],
    title: 'Undo Action',
    description: 'Reverts the previous clip, track, or effect modification',
    category: 'History & Timeline',
    icon: RotateCcw,
  },
  {
    id: 'redo',
    keys: ['Ctrl', 'Shift', 'Z'],
    title: 'Redo Action',
    description: 'Re-applies the most recently reverted timeline action',
    category: 'History & Timeline',
    icon: RotateCw,
  },
  {
    id: 'delete-clip',
    keys: ['Del', 'Backspace'],
    title: 'Delete Selected Clip',
    description: 'Removes the currently highlighted clip from the timeline',
    category: 'Editing Tools',
    icon: Trash2,
  },
  {
    id: 'zoom-wheel',
    keys: ['Ctrl', 'Wheel'],
    title: 'Zoom Timeline',
    description: 'Scales timeline horizontal time view for frame precision',
    category: 'History & Timeline',
    icon: ZoomIn,
  },
  {
    id: 'duplicate-clip',
    keys: ['Ctrl', 'D'],
    title: 'Duplicate Clip',
    description: 'Creates a replica of the active clip immediately after it',
    category: 'Editing Tools',
    icon: Sparkles,
  },
];

export const KeyboardShortcutsModal: React.FC<KeyboardShortcutsModalProps> = ({
  isOpen,
  onClose,
  onTriggerAction,
}) => {
  const [pressedKey, setPressedKey] = useState<string | null>(null);

  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      let keyDisplay = e.key;
      if (e.code === 'Space') keyDisplay = 'Space';
      if (e.key === 'Control') keyDisplay = 'Ctrl';
      if (e.key === 'Meta') keyDisplay = 'Cmd';
      setPressedKey(keyDisplay.toUpperCase());

      // Clear after short duration
      setTimeout(() => setPressedKey(null), 800);
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="relative w-full max-w-xl max-h-[92vh] overflow-y-auto bg-zinc-950 border border-amber-500/40 rounded-2xl p-5 sm:p-6 shadow-2xl space-y-4">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-lg text-zinc-400 hover:text-zinc-100 hover:bg-zinc-900 transition-colors"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-amber-400 to-yellow-600 flex items-center justify-center text-zinc-950 font-black shadow-lg shadow-amber-500/25 shrink-0">
            <Keyboard className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-extrabold text-zinc-100">Keyboard Shortcut Manager</h3>
            <p className="text-xs text-amber-400">
              High-efficiency hotkeys for rapid video editing and transport control
            </p>
          </div>
        </div>

        {/* Live Key Detection Banner */}
        <div className="p-3 rounded-xl bg-zinc-900/80 border border-zinc-800 flex items-center justify-between">
          <span className="text-xs text-zinc-400">Live Key Press Detector:</span>
          {pressedKey ? (
            <span className="px-3 py-1 rounded-lg bg-amber-500 text-zinc-950 font-mono font-black text-xs shadow-md shadow-amber-500/30 animate-pulse">
              {pressedKey}
            </span>
          ) : (
            <span className="text-[11px] font-mono text-zinc-500">Press any key to test...</span>
          )}
        </div>

        {/* Shortcuts List by Categories */}
        <div className="space-y-3.5 max-h-[420px] overflow-y-auto pr-1 scrollbar-thin">
          {['Editing Tools', 'Playback', 'History & Timeline'].map((cat) => {
            const catShortcuts = SHORTCUTS.filter((s) => s.category === cat);

            return (
              <div key={cat} className="space-y-2">
                <div className="text-[11px] font-extrabold uppercase tracking-wider text-amber-400/90 flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
                  <span>{cat}</span>
                </div>

                <div className="grid grid-cols-1 gap-2">
                  {catShortcuts.map((s) => {
                    const Icon = s.icon;
                    return (
                      <div
                        key={s.id}
                        className="flex items-center justify-between p-2.5 rounded-xl bg-zinc-900/60 border border-zinc-850 hover:border-amber-500/40 transition-colors"
                      >
                        <div className="flex items-center gap-2.5 min-w-0">
                          <div className="p-1.5 rounded-lg bg-zinc-800 text-amber-400 shrink-0">
                            <Icon className="w-3.5 h-3.5" />
                          </div>
                          <div className="min-w-0">
                            <div className="text-xs font-bold text-zinc-200 truncate">{s.title}</div>
                            <div className="text-[10px] text-zinc-400 truncate">{s.description}</div>
                          </div>
                        </div>

                        {/* Keys Badge */}
                        <div className="flex items-center gap-1 shrink-0 ml-2">
                          {s.keys.map((k, idx) => (
                            <React.Fragment key={k}>
                              <kbd className="px-2 py-1 rounded-md bg-zinc-950 border border-zinc-700 text-zinc-200 font-mono text-[11px] font-bold shadow-inner min-w-[24px] text-center">
                                {k}
                              </kbd>
                              {idx < s.keys.length - 1 && (
                                <span className="text-zinc-500 text-xs font-bold">+</span>
                              )}
                            </React.Fragment>
                          ))}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer */}
        <div className="pt-2 border-t border-zinc-850 flex items-center justify-between text-[11px] text-zinc-400">
          <span>Pro tip: Press <kbd className="px-1.5 py-0.5 rounded bg-zinc-900 border border-zinc-700 text-amber-300 font-mono font-bold">B</kbd> anywhere on timeline for razor split</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold text-xs transition-colors"
          >
            Got it
          </button>
        </div>
      </div>
    </div>
  );
};
