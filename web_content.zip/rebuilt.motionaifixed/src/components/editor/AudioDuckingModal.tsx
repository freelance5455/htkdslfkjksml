import React from 'react';
import { AudioDuckingConfig, TimelineTrack, EditorClip } from '../../types';
import { 
  Mic, 
  Volume2, 
  VolumeX, 
  Sliders, 
  Sparkles, 
  Check, 
  X, 
  Activity,
  Layers
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface AudioDuckingModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: AudioDuckingConfig;
  onConfigChange: (newConfig: AudioDuckingConfig) => void;
  tracks: TimelineTrack[];
  clips: EditorClip[];
  onApplyDuckingKeyframes: () => void;
}

export const AudioDuckingModal: React.FC<AudioDuckingModalProps> = ({
  isOpen,
  onClose,
  config,
  onConfigChange,
  tracks,
  clips,
  onApplyDuckingKeyframes,
}) => {
  if (!isOpen) return null;

  const voiceClips = clips.filter(
    (c) =>
      c.trackId === config.targetVoiceTrackId ||
      c.type === 'voiceover' ||
      c.title.toLowerCase().includes('voice')
  );

  const musicClips = clips.filter(
    (c) => c.trackId === config.backgroundMusicTrackId || c.type === 'audio'
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="relative w-full max-w-lg bg-zinc-950 border border-amber-500/40 rounded-2xl p-5 shadow-2xl space-y-4">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <Mic className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-extrabold text-base text-zinc-100">
                  AI-Powered Audio Ducking
                </h3>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40">
                  DSP Smart Volume
                </span>
              </div>
              <p className="text-xs text-zinc-400 mt-0.5">
                Automatically suppresses background music levels when voice-over clips are detected on the timeline.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-zinc-100 hover:bg-zinc-900 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Master Toggle */}
        <div className="flex items-center justify-between p-3.5 rounded-xl bg-zinc-900/80 border border-amber-500/30">
          <div className="space-y-0.5">
            <span className="text-xs font-bold text-zinc-200">
              Enable Real-Time Audio Ducking
            </span>
            <p className="text-[11px] text-zinc-400">
              Dynamically attenuates background tracks whenever speech or voice narration is playing.
            </p>
          </div>

          <button
            onClick={() =>
              onConfigChange({
                ...config,
                enabled: !config.enabled,
              })
            }
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all border ${
              config.enabled
                ? 'bg-amber-500 text-zinc-950 border-amber-400 shadow-md shadow-amber-500/20'
                : 'bg-zinc-950 text-zinc-500 border-zinc-800'
            }`}
          >
            {config.enabled ? 'ENABLED' : 'DISABLED'}
          </button>
        </div>

        {/* Timeline Detection Summary */}
        <div className="grid grid-cols-2 gap-2 text-xs">
          <div className="p-2.5 rounded-xl bg-zinc-900/60 border border-zinc-800">
            <span className="text-zinc-400 text-[10px] block uppercase font-bold">
              Detected Voice Clips:
            </span>
            <span className="text-sm font-extrabold text-amber-400 font-mono">
              {voiceClips.length} dialogue segments
            </span>
          </div>
          <div className="p-2.5 rounded-xl bg-zinc-900/60 border border-zinc-800">
            <span className="text-zinc-400 text-[10px] block uppercase font-bold">
              Target Music Tracks:
            </span>
            <span className="text-sm font-extrabold text-emerald-400 font-mono">
              {musicClips.length} background clips
            </span>
          </div>
        </div>

        {/* Ducking Parameters */}
        <div className="space-y-3.5 p-3.5 rounded-xl bg-zinc-900/50 border border-zinc-800 text-xs">
          {/* Ducking Amount Slider */}
          <div className="space-y-1.5">
            <div className="flex justify-between">
              <span className="font-bold text-zinc-300">
                Music Ducking Level:
              </span>
              <span className="font-mono text-amber-400 font-bold">
                {config.duckingAmount}% (
                {config.duckingAmount <= 15
                  ? '-18 dB (Heavy)'
                  : config.duckingAmount <= 25
                  ? '-14 dB (Standard Cinema)'
                  : '-10 dB (Subtle)'}
                )
              </span>
            </div>
            <input
              type="range"
              min="5"
              max="50"
              step="5"
              value={config.duckingAmount}
              onChange={(e) =>
                onConfigChange({
                  ...config,
                  duckingAmount: parseInt(e.target.value, 10),
                })
              }
              className="w-full accent-amber-500 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-zinc-500 font-mono">
              <span>5% (-24dB Extreme)</span>
              <span>20% (-14dB Default)</span>
              <span>50% (-6dB Soft)</span>
            </div>
          </div>

          {/* Attack & Release Envelope Times */}
          <div className="grid grid-cols-2 gap-3 pt-1">
            <div className="space-y-1">
              <div className="flex justify-between">
                <span className="text-zinc-400">Attack Time:</span>
                <span className="font-mono text-amber-400">
                  {config.attackTime}s
                </span>
              </div>
              <input
                type="range"
                min="0.1"
                max="0.8"
                step="0.05"
                value={config.attackTime}
                onChange={(e) =>
                  onConfigChange({
                    ...config,
                    attackTime: parseFloat(e.target.value),
                  })
                }
                className="w-full accent-amber-500 cursor-pointer"
              />
            </div>

            <div className="space-y-1">
              <div className="flex justify-between">
                <span className="text-zinc-400">Release Time:</span>
                <span className="font-mono text-amber-400">
                  {config.releaseTime}s
                </span>
              </div>
              <input
                type="range"
                min="0.1"
                max="1.2"
                step="0.05"
                value={config.releaseTime}
                onChange={(e) =>
                  onConfigChange({
                    ...config,
                    releaseTime: parseFloat(e.target.value),
                  })
                }
                className="w-full accent-amber-500 cursor-pointer"
              />
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="flex items-center justify-between gap-2 pt-2 border-t border-zinc-800">
          <button
            onClick={() => {
              onApplyDuckingKeyframes();
              confetti({ particleCount: 30, spread: 60 });
              onClose();
            }}
            className="flex-1 py-2.5 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 border border-amber-500/40 text-xs font-bold flex items-center justify-center gap-1.5 transition-colors"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Bake AI Ducking to Timeline Clips</span>
          </button>

          <button
            onClick={onClose}
            className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-amber-400 hover:to-yellow-500 text-zinc-950 font-bold text-xs shadow-md shadow-amber-500/20"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
