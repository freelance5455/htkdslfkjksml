import React, { useState } from 'react';
import { TransitionType, EditorClip } from '../../types';
import { 
  Sparkles, 
  X, 
  GripVertical, 
  Layers, 
  Zap, 
  Move, 
  ArrowRight, 
  Maximize2, 
  Check, 
  Film, 
  SlidersHorizontal,
  Flame,
  Radio
} from 'lucide-react';
import { soundEngine } from '../../utils/transitionSound';
import confetti from 'canvas-confetti';

export interface TransitionItem {
  id: TransitionType;
  name: string;
  category: 'Dissolves' | 'Wipes & Slides' | 'Zooms & 3D' | 'Cinematic & Stylized';
  description: string;
  defaultDuration: number;
  previewClass: string;
  icon: any;
}

export const TRANSITION_LIBRARY_DATA: TransitionItem[] = [
  {
    id: 'dissolve',
    name: 'Cross Dissolve',
    category: 'Dissolves',
    description: 'Smooth optical alpha blend between adjacent frames',
    defaultDuration: 0.6,
    previewClass: 'from-amber-500/30 to-yellow-500/10',
    icon: Sparkles,
  },
  {
    id: 'whip-left',
    name: 'Whip Pan Left',
    category: 'Wipes & Slides',
    description: 'High-speed directional camera swish to the left',
    defaultDuration: 0.5,
    previewClass: 'from-blue-600/30 to-indigo-600/10',
    icon: Move,
  },
  {
    id: 'whip-right',
    name: 'Whip Pan Right',
    category: 'Wipes & Slides',
    description: 'High-speed directional camera swish to the right',
    defaultDuration: 0.5,
    previewClass: 'from-blue-600/30 to-indigo-600/10',
    icon: Move,
  },
  {
    id: 'slide-up',
    name: 'Slide Up Push',
    category: 'Wipes & Slides',
    description: 'Modern vertical push transition with motion blur',
    defaultDuration: 0.5,
    previewClass: 'from-emerald-500/30 to-teal-500/10',
    icon: ArrowRight,
  },
  {
    id: 'zoom-in',
    name: 'Zoom Push In',
    category: 'Zooms & 3D',
    description: 'Dramatic focal scale acceleration into next scene',
    defaultDuration: 0.6,
    previewClass: 'from-amber-600/30 to-orange-600/10',
    icon: Maximize2,
  },
  {
    id: 'zoom-out',
    name: 'Zoom Pull Out',
    category: 'Zooms & 3D',
    description: 'Focal release expanding outward to next sequence',
    defaultDuration: 0.6,
    previewClass: 'from-orange-600/30 to-yellow-600/10',
    icon: Maximize2,
  },
  {
    id: 'flash',
    name: 'White Flash Bloom',
    category: 'Cinematic & Stylized',
    description: 'High-energy optical flare overexposure burst',
    defaultDuration: 0.4,
    previewClass: 'from-yellow-200/40 to-amber-400/20',
    icon: Zap,
  },
  {
    id: 'glitch',
    name: 'Digital Cyber Glitch',
    category: 'Cinematic & Stylized',
    description: 'Sci-fi RGB displacement and VHS scanline distortion',
    defaultDuration: 0.5,
    previewClass: 'from-fuchsia-600/30 to-purple-600/10',
    icon: Radio,
  },
  {
    id: 'burn',
    name: '35mm Film Burn',
    category: 'Cinematic & Stylized',
    description: 'Organic warm vintage film perforation burn & flare',
    defaultDuration: 0.7,
    previewClass: 'from-red-600/30 to-amber-600/10',
    icon: Flame,
  },
];

interface TransitionsLibraryProps {
  isOpen: boolean;
  onClose: () => void;
  selectedClip: EditorClip | null;
  onApplyTransition: (clipId: string, transitionType: TransitionType, duration?: number) => void;
  isSidebarMode?: boolean;
}

export const TransitionsLibrary: React.FC<TransitionsLibraryProps> = ({
  isOpen,
  onClose,
  selectedClip,
  onApplyTransition,
  isSidebarMode = false,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [transitionDuration, setTransitionDuration] = useState<number>(0.6);
  const [activePreviewId, setActivePreviewId] = useState<TransitionType | null>(null);

  if (!isOpen) return null;

  const categories = ['All', 'Dissolves', 'Wipes & Slides', 'Zooms & 3D', 'Cinematic & Stylized'];

  const filteredTransitions = selectedCategory === 'All'
    ? TRANSITION_LIBRARY_DATA
    : TRANSITION_LIBRARY_DATA.filter((t) => t.category === selectedCategory);

  const handleDragStart = (e: React.DragEvent, item: TransitionItem) => {
    e.dataTransfer.setData(
      'application/json',
      JSON.stringify({
        transitionType: item.id,
        duration: transitionDuration,
      })
    );
    e.dataTransfer.effectAllowed = 'copy';
    soundEngine.playWhoosh(0.1);
  };

  const handleApplyClick = (item: TransitionItem) => {
    if (!selectedClip) return;
    onApplyTransition(selectedClip.id, item.id, transitionDuration);
    soundEngine.playForTransition(item.id);
    confetti({ particleCount: 30, spread: 50, origin: { y: 0.7 } });
  };

  const content = (
    <div className="flex flex-col h-full space-y-3.5 text-xs select-none">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/30 shadow-sm">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <h3 className="font-bold text-zinc-100 text-sm">Draggable Transitions Library</h3>
            <p className="text-[11px] text-zinc-400">Drag & drop between adjacent clips on the timeline</p>
          </div>
        </div>

        <button
          onClick={onClose}
          className="p-1 rounded-lg text-zinc-400 hover:text-zinc-100 hover:bg-zinc-850 transition-colors"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Target Clip Status & Default Duration */}
      <div className="p-3 rounded-xl bg-zinc-900/90 border border-zinc-800 space-y-2.5">
        <div className="flex items-center justify-between">
          <span className="text-zinc-300 font-semibold">Active Selection:</span>
          {selectedClip ? (
            <span className="text-[11px] font-bold text-amber-300 font-mono truncate max-w-[180px]">
              [{selectedClip.title}]
            </span>
          ) : (
            <span className="text-[11px] text-zinc-500 font-mono">None selected</span>
          )}
        </div>

        <div>
          <div className="flex justify-between font-medium mb-1 text-[11px] text-zinc-300">
            <span>Transition Duration:</span>
            <span className="font-mono text-amber-400 font-bold">{transitionDuration.toFixed(1)}s</span>
          </div>
          <input
            type="range"
            min="0.2"
            max="1.5"
            step="0.1"
            value={transitionDuration}
            onChange={(e) => setTransitionDuration(parseFloat(e.target.value))}
            className="w-full accent-amber-500"
          />
        </div>
      </div>

      {/* Categories Filter Pills */}
      <div className="flex items-center gap-1 overflow-x-auto pb-1 scrollbar-none">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold whitespace-nowrap transition-colors ${
              selectedCategory === cat
                ? 'bg-amber-500 text-zinc-950 font-bold shadow-sm'
                : 'bg-zinc-900 text-zinc-400 hover:text-amber-300 hover:bg-zinc-850 border border-zinc-800'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Draggable Transition Cards Grid */}
      <div className="flex-1 overflow-y-auto pr-1 space-y-2 max-h-[460px] scrollbar-thin">
        {filteredTransitions.map((item) => {
          const Icon = item.icon;
          const isAttached = selectedClip?.transition?.type === item.id;

          return (
            <div
              key={item.id}
              draggable={true}
              onDragStart={(e) => handleDragStart(e, item)}
              onClick={() => handleApplyClick(item)}
              onMouseEnter={() => {
                setActivePreviewId(item.id);
                soundEngine.playWhoosh(0.08);
              }}
              onMouseLeave={() => setActivePreviewId(null)}
              className={`group relative p-3 rounded-xl border cursor-grab active:cursor-grabbing transition-all hover:scale-[1.01] ${
                isAttached
                  ? 'bg-amber-500/15 border-amber-400 shadow-md shadow-amber-500/15'
                  : 'bg-zinc-900/70 border-zinc-800 hover:border-amber-500/40 hover:bg-zinc-900'
              }`}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5 min-w-0">
                  <div className="p-1.5 rounded-lg bg-zinc-800/80 text-amber-400 shrink-0 group-hover:scale-110 transition-transform">
                    <Icon className="w-4 h-4" />
                  </div>
                  <div className="min-w-0">
                    <div className="font-bold text-zinc-200 group-hover:text-amber-300 transition-colors truncate">
                      {item.name}
                    </div>
                    <div className="text-[10px] text-zinc-400 truncate">{item.description}</div>
                  </div>
                </div>

                <div className="flex items-center gap-1.5 shrink-0 ml-2">
                  {isAttached && (
                    <span className="flex items-center gap-1 px-1.5 py-0.5 rounded bg-amber-500 text-zinc-950 font-bold text-[9px] shadow-sm">
                      <Check className="w-3 h-3 stroke-[3]" />
                      <span>Active</span>
                    </span>
                  )}
                  <div className="flex items-center gap-0.5 text-zinc-500 group-hover:text-amber-400" title="Drag onto timeline cut">
                    <GripVertical className="w-4 h-4" />
                  </div>
                </div>
              </div>

              {/* Animated preview bar */}
              <div className={`mt-2 h-1.5 rounded-full overflow-hidden bg-zinc-950 border border-zinc-800/60`}>
                <div
                  className={`h-full bg-gradient-to-r from-amber-500 to-yellow-400 transition-all duration-300 ${
                    activePreviewId === item.id ? 'w-full animate-pulse' : 'w-1/4'
                  }`}
                />
              </div>
            </div>
          );
        })}
      </div>

      <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-[10px] text-zinc-400 flex items-center gap-2">
        <Sparkles className="w-3.5 h-3.5 text-amber-400 shrink-0" />
        <span>Drag any transition directly onto clip cut handles or click to apply to selected clip.</span>
      </div>
    </div>
  );

  if (isSidebarMode) {
    return (
      <div className="w-80 shrink-0 bg-zinc-950 border border-zinc-800/90 rounded-2xl p-4 shadow-2xl flex flex-col h-full animate-in slide-in-from-right-3 duration-200">
        {content}
      </div>
    );
  }

  // Modal mode
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="relative w-full max-w-lg max-h-[92vh] overflow-y-auto bg-zinc-950 border border-amber-500/40 rounded-2xl p-5 shadow-2xl space-y-4">
        {content}
      </div>
    </div>
  );
};
