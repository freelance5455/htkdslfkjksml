import React, { useState, useEffect, useRef } from 'react';
import { CustomLut, EditorClip } from '../../types';
import { 
  loadCustomLutsFromStorage, 
  saveCustomLutsToStorage, 
  parseCubeFileContent, 
  downloadLutFile 
} from '../../utils/lutParser';
import { 
  Upload, 
  FileCode, 
  Check, 
  Trash2, 
  Download, 
  Sparkles, 
  Sliders, 
  Layers, 
  X, 
  FolderPlus,
  RefreshCw,
  Eye,
  EyeOff
} from 'lucide-react';
import { soundEngine } from '../../utils/transitionSound';
import confetti from 'canvas-confetti';

interface CustomLutManagerProps {
  selectedClip: EditorClip | null;
  onUpdateClip: (clipId: string, updates: Partial<EditorClip>) => void;
}

export const CustomLutManager: React.FC<CustomLutManagerProps> = ({
  selectedClip,
  onUpdateClip,
}) => {
  const [luts, setLuts] = useState<CustomLut[]>([]);
  const [isUploading, setIsUploading] = useState<boolean>(false);
  const [isDragOver, setIsDragOver] = useState<boolean>(false);
  const [statusNotification, setStatusNotification] = useState<string | null>(null);
  const [previewMode, setPreviewMode] = useState<boolean>(true);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Load LUTs from internal storage on mount
  useEffect(() => {
    const loaded = loadCustomLutsFromStorage();
    setLuts(loaded);
  }, []);

  // Show temporary status badge
  const showToast = (msg: string) => {
    setStatusNotification(msg);
    setTimeout(() => setStatusNotification(null), 3500);
  };

  // Process a selected or dropped .cube file
  const handleProcessFile = async (file: File) => {
    if (!file.name.toLowerCase().endsWith('.cube') && !file.name.toLowerCase().endsWith('.txt')) {
      showToast('⚠️ Please upload a valid .cube file format');
      return;
    }

    setIsUploading(true);
    soundEngine.playWhoosh(0.2);

    try {
      const content = await file.text();
      const parsedLut = parseCubeFileContent(content, file.name);

      // Check if LUT with same name already exists, update or append
      const existingIdx = luts.findIndex((l) => l.name.toLowerCase() === parsedLut.name.toLowerCase());
      let updatedList: CustomLut[];

      if (existingIdx >= 0) {
        updatedList = [...luts];
        updatedList[existingIdx] = parsedLut;
      } else {
        updatedList = [parsedLut, ...luts];
      }

      setLuts(updatedList);
      saveCustomLutsToStorage(updatedList);
      setIsUploading(false);

      soundEngine.playImpact();
      confetti({ particleCount: 45, spread: 70, origin: { y: 0.7 } });
      showToast(`✓ "${parsedLut.name}" stored in internal library`);

      // If a clip is selected, automatically apply the uploaded LUT
      if (selectedClip) {
        handleApplyLut(parsedLut);
      }
    } catch (err) {
      console.error('Failed to parse .cube file:', err);
      setIsUploading(false);
      showToast('⚠️ Error parsing .cube file content');
    }
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      handleProcessFile(file);
      e.target.value = '';
    }
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragOver(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      handleProcessFile(file);
    }
  };

  // Apply LUT to the selected clip
  const handleApplyLut = (lut: CustomLut) => {
    if (!selectedClip) {
      showToast('Select a video or image clip on the timeline first');
      return;
    }

    const intensity = selectedClip.customLutIntensity ?? 100;

    onUpdateClip(selectedClip.id, {
      customLutId: lut.id,
      customLutName: lut.name,
      customLutIntensity: intensity,
      customLutCssFilter: lut.cssFilter,
      // If the LUT provides recommended color grade values, sync them
      colorGrade: selectedClip.colorGrade
        ? {
            ...selectedClip.colorGrade,
            ...(lut.colorGradePreset || {}),
          }
        : (lut.colorGradePreset as any),
    });

    soundEngine.playImpact();
    showToast(`✓ Applied 3D LUT "${lut.name}" to clip`);
  };

  // Remove LUT from selected clip
  const handleRemoveLutFromClip = () => {
    if (!selectedClip) return;
    onUpdateClip(selectedClip.id, {
      customLutId: undefined,
      customLutName: undefined,
      customLutIntensity: 100,
      customLutCssFilter: undefined,
    });
    soundEngine.playWhoosh(0.15);
    showToast('✓ Custom LUT removed from clip');
  };

  // Update LUT intensity on selected clip
  const handleIntensityChange = (val: number) => {
    if (!selectedClip || !selectedClip.customLutId) return;
    onUpdateClip(selectedClip.id, {
      customLutIntensity: val,
    });
  };

  // Delete LUT from internal library
  const handleDeleteLut = (lutId: string, lutName: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const updated = luts.filter((l) => l.id !== lutId);
    setLuts(updated);
    saveCustomLutsToStorage(updated);

    if (selectedClip && selectedClip.customLutId === lutId) {
      handleRemoveLutFromClip();
    }
    showToast(`Deleted "${lutName}" from library`);
  };

  const activeLut = luts.find((l) => l.id === selectedClip?.customLutId);

  return (
    <div className="space-y-4 text-xs">
      {/* Header and Sync Badge */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="font-bold text-sm text-zinc-100 flex items-center gap-2">
            <Layers className="w-4 h-4 text-amber-400" />
            <span>Custom 3D LUT Manager (.cube)</span>
          </h3>
          <p className="text-zinc-400 mt-0.5">
            Upload .cube files from local gallery to internal storage for persistent color grading.
          </p>
        </div>
        <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-amber-500/10 border border-amber-500/30 text-[10px] text-amber-300 font-mono font-bold">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
          <span>Internal Storage Synced</span>
        </div>
      </div>

      {/* Toast Notification */}
      {statusNotification && (
        <div className="p-2.5 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-300 font-bold text-xs flex items-center justify-between animate-in fade-in">
          <span>{statusNotification}</span>
          <button onClick={() => setStatusNotification(null)}>
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Active LUT Status on Selected Clip */}
      {selectedClip ? (
        <div className="p-3.5 rounded-xl bg-zinc-900/90 border border-zinc-800 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-zinc-300 font-semibold">Active LUT on Clip:</span>
            {activeLut ? (
              <button
                onClick={handleRemoveLutFromClip}
                className="text-[11px] text-red-400 hover:text-red-300 hover:underline flex items-center gap-1"
              >
                <X className="w-3 h-3" />
                <span>Remove LUT</span>
              </button>
            ) : (
              <span className="text-zinc-500 font-mono text-[11px]">None Applied</span>
            )}
          </div>

          {activeLut ? (
            <div className="space-y-2.5">
              <div className="flex items-center gap-2.5 p-2 rounded-lg bg-zinc-950 border border-amber-500/40">
                <div
                  className="w-8 h-8 rounded-md shrink-0 shadow-sm border border-black/40"
                  style={{ background: activeLut.previewGradient }}
                />
                <div className="flex-1 min-w-0">
                  <div className="font-bold text-amber-300 truncate">{activeLut.name}</div>
                  <div className="text-[10px] text-zinc-400 truncate font-mono">
                    {activeLut.size3D}x{activeLut.size3D}x{activeLut.size3D} • {activeLut.fileName}
                  </div>
                </div>
              </div>

              {/* Intensity Slider */}
              <div>
                <div className="flex justify-between font-medium mb-1">
                  <span className="text-zinc-300">LUT Blend Intensity</span>
                  <span className="font-mono text-amber-400 font-bold">
                    {selectedClip.customLutIntensity ?? 100}%
                  </span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={selectedClip.customLutIntensity ?? 100}
                  onChange={(e) => handleIntensityChange(parseInt(e.target.value, 10))}
                  className="w-full accent-amber-500"
                />
              </div>
            </div>
          ) : (
            <p className="text-[11px] text-zinc-400 leading-snug">
              Select any .cube LUT from your library below or upload a new file from your device.
            </p>
          )}
        </div>
      ) : (
        <div className="p-3 rounded-xl bg-zinc-900/40 border border-zinc-850 text-center text-zinc-400 text-xs">
          Select a clip on the timeline to preview and apply custom LUTs.
        </div>
      )}

      {/* Drag & Drop File Upload Area */}
      <div
        onDragOver={(e) => {
          e.preventDefault();
          setIsDragOver(true);
        }}
        onDragLeave={() => setIsDragOver(false)}
        onDrop={handleDrop}
        onClick={() => fileInputRef.current?.click()}
        className={`relative p-5 rounded-2xl border-2 border-dashed cursor-pointer transition-all flex flex-col items-center justify-center gap-2 text-center group ${
          isDragOver
            ? 'border-amber-400 bg-amber-500/10 scale-[1.01]'
            : 'border-zinc-750 bg-zinc-900/60 hover:border-amber-500/50 hover:bg-zinc-900/90'
        }`}
      >
        <input
          ref={fileInputRef}
          type="file"
          accept=".cube,.txt"
          onChange={handleFileInputChange}
          className="hidden"
        />

        <div className="w-10 h-10 rounded-xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-amber-400 group-hover:scale-110 transition-transform">
          {isUploading ? (
            <RefreshCw className="w-5 h-5 animate-spin" />
          ) : (
            <Upload className="w-5 h-5" />
          )}
        </div>

        <div>
          <div className="text-xs font-bold text-zinc-200 group-hover:text-amber-300 transition-colors">
            {isUploading ? 'Parsing .cube 3D Lattice...' : 'Click or Drag & Drop .cube File'}
          </div>
          <div className="text-[10px] text-zinc-400 mt-0.5">
            Supports 17x17x17, 33x33x33, and 65x65x65 Adobe .cube 3D LUT standards
          </div>
        </div>

        <button
          type="button"
          className="mt-1 px-3 py-1 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-[11px] font-bold border border-zinc-700 transition-colors flex items-center gap-1.5"
        >
          <FolderPlus className="w-3.5 h-3.5 text-amber-400" />
          <span>Browse Local Gallery</span>
        </button>
      </div>

      {/* Stored LUTs Library Grid */}
      <div className="space-y-2 pt-1">
        <div className="flex items-center justify-between text-xs font-bold text-zinc-300">
          <span>Stored Custom LUTs ({luts.length})</span>
          <span className="text-[10px] text-zinc-500 font-normal">Stored in App Cache</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 max-h-[380px] overflow-y-auto pr-1 scrollbar-thin">
          {luts.map((lut) => {
            const isApplied = selectedClip?.customLutId === lut.id;

            return (
              <div
                key={lut.id}
                onClick={() => handleApplyLut(lut)}
                className={`group relative rounded-xl border p-2.5 cursor-pointer transition-all hover:scale-[1.01] ${
                  isApplied
                    ? 'bg-amber-500/15 border-amber-400 shadow-md shadow-amber-500/15'
                    : 'bg-zinc-900/70 border-zinc-800 hover:border-amber-500/40 hover:bg-zinc-900'
                }`}
              >
                {/* Visual Swatch Strip */}
                <div
                  className="w-full h-11 rounded-lg mb-2 relative overflow-hidden border border-black/40 shadow-inner flex items-end justify-between p-1.5"
                  style={{ background: lut.previewGradient }}
                >
                  <span className="px-1.5 py-0.5 rounded bg-black/75 text-[9px] font-mono text-zinc-200 backdrop-blur-sm">
                    {lut.size3D}³ 3D LUT
                  </span>
                  {isApplied && (
                    <span className="flex items-center gap-1 px-1.5 py-0.5 rounded bg-amber-500 text-zinc-950 font-bold text-[9px] shadow-sm">
                      <Check className="w-3 h-3 stroke-[3]" />
                      <span>Active</span>
                    </span>
                  )}
                </div>

                {/* LUT Title & File Name */}
                <div className="font-bold text-xs text-zinc-100 group-hover:text-amber-300 transition-colors truncate">
                  {lut.name}
                </div>
                <div className="text-[10px] text-zinc-400 font-mono truncate mt-0.5">
                  {lut.fileName}
                </div>

                {/* Action Controls: Download .cube & Delete */}
                <div className="flex items-center justify-between pt-2 mt-1 border-t border-zinc-800/80 text-[10px]">
                  <span className="text-zinc-500 font-mono">
                    {(lut.fileSize / 1024).toFixed(1)} KB
                  </span>

                  <div className="flex items-center gap-1">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        downloadLutFile(lut);
                      }}
                      title="Export .cube file"
                      className="p-1 rounded text-zinc-400 hover:text-amber-300 hover:bg-zinc-800 transition-colors"
                    >
                      <Download className="w-3 h-3" />
                    </button>
                    <button
                      onClick={(e) => handleDeleteLut(lut.id, lut.name, e)}
                      title="Delete from internal storage"
                      className="p-1 rounded text-zinc-400 hover:text-red-400 hover:bg-zinc-800 transition-colors"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
