import React from 'react';
import { AppTab } from '../types';
import { 
  Sparkles, 
  Clapperboard, 
  Briefcase, 
  PlaySquare, 
  User, 
  SlidersHorizontal, 
  Zap, 
  Download, 
  RotateCcw,
  Smartphone,
  BarChart3,
  Share2
} from 'lucide-react';

interface HeaderProps {
  currentTab: AppTab;
  onTabChange: (tab: AppTab) => void;
  onResetProject: () => void;
  onQuickExport: () => void;
  onOpenMetaModal: () => void;
  backendStatus: { status: string; hasKey: boolean };
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  onTabChange,
  onResetProject,
  onQuickExport,
  onOpenMetaModal,
  backendStatus,
}) => {
  return (
    <header className="sticky top-0 z-50 bg-zinc-950/95 backdrop-blur-md border-b border-zinc-850 px-4 py-2.5">
      <div className="max-w-[1440px] mx-auto flex items-center justify-between gap-3">
        {/* Left: Motionai Brand & Tagline from Screenshot 1 & 2 */}
        <div className="flex flex-col cursor-pointer" onClick={() => onTabChange('create')}>
          <h1 className="text-xl sm:text-2xl font-black tracking-tight text-white flex items-center gap-1.5">
            <span>Motionai</span>
          </h1>
          <p className="text-[11px] text-zinc-400 font-medium tracking-wide">
            Create · Generate · Dominate
          </p>
        </div>

        {/* Center: Desktop Navigation Bar */}
        <nav className="hidden md:flex items-center gap-1 bg-zinc-900/90 p-1 rounded-2xl border border-zinc-800 text-xs">
          {[
            { id: 'create' as AppTab, label: 'Create', icon: Sparkles },
            { id: 'studio' as AppTab, label: 'Studio (Editor)', icon: Clapperboard },
            { id: 'business' as AppTab, label: 'Business', icon: Briefcase },
            { id: 'library' as AppTab, label: 'Library', icon: PlaySquare },
            { id: 'comparison' as AppTab, label: 'Market Matrix', icon: BarChart3 },
            { id: 'android' as AppTab, label: 'Mobile APK', icon: Smartphone },
            { id: 'profile' as AppTab, label: 'Profile', icon: User },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive =
              currentTab === tab.id ||
              (tab.id === 'studio' && (currentTab === 'editor' || currentTab === 'studio')) ||
              (tab.id === 'create' && currentTab === 'create');

            return (
              <button
                key={tab.id}
                onClick={() => onTabChange(tab.id)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-bold transition-all whitespace-nowrap ${
                  isActive
                    ? 'bg-amber-500 text-zinc-950 shadow-md shadow-amber-500/20'
                    : 'text-zinc-400 hover:text-amber-300'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Right: Unlimited Badge (⚡ ∞) and Settings Icon (from Screenshot 1 & 2) */}
        <div className="flex items-center gap-2">
          {/* Lightning Infinity Badge from Screenshot 1 */}
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-gradient-to-r from-amber-500/15 via-yellow-500/20 to-amber-500/15 border border-amber-500/40 text-amber-300 font-extrabold text-xs shadow-sm">
            <Zap className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
            <span className="text-sm font-mono leading-none">∞</span>
          </div>

          {/* Quick Settings / Sliders Icon Button from Screenshot 1 */}
          <button
            onClick={() => onTabChange('profile')}
            title="Studio Settings"
            className="w-9 h-9 rounded-xl bg-zinc-900 hover:bg-zinc-850 border border-zinc-800 text-zinc-300 hover:text-amber-400 flex items-center justify-center transition-colors"
          >
            <SlidersHorizontal className="w-4 h-4" />
          </button>

          {/* Quick Export Button */}
          <button
            onClick={onQuickExport}
            className="hidden sm:flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-amber-400 hover:to-yellow-500 text-zinc-950 font-bold text-xs shadow-md shadow-amber-500/20 transition-all hover:scale-[1.02]"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export</span>
          </button>
        </div>
      </div>
    </header>
  );
};
