import React, { useState } from 'react';
import { 
  User, 
  Settings, 
  Shield, 
  HardDrive, 
  Sparkles, 
  Bell, 
  Save, 
  Check, 
  Smartphone 
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface ProfileStudioProps {
  userEmail?: string;
  hasKey?: boolean;
}

export const ProfileStudio: React.FC<ProfileStudioProps> = ({
  userEmail = 'farhanrajpoot34@gmail.com',
  hasKey = true,
}) => {
  const [displayName, setDisplayName] = useState('Farhan Rajpoot');
  const [defaultResolution, setDefaultResolution] = useState('1080p');
  const [defaultTransition, setDefaultTransition] = useState('dissolve');
  const [autoDucking, setAutoDucking] = useState(true);
  const [hardwareAcceleration, setHardwareAcceleration] = useState(true);
  const [isSaved, setIsSaved] = useState(false);

  const handleSave = () => {
    setIsSaved(true);
    confetti({ particleCount: 30, spread: 60 });
    setTimeout(() => setIsSaved(false), 2000);
  };

  return (
    <div className="max-w-[1200px] mx-auto p-4 space-y-6">
      {/* Header */}
      <div className="pb-4 border-b border-zinc-800">
        <div className="flex items-center gap-2">
          <User className="w-5 h-5 text-amber-400" />
          <h2 className="text-xl font-extrabold text-zinc-100">
            Profile & Studio Preferences
          </h2>
        </div>
        <p className="text-xs text-zinc-400 mt-1">
          Configure production defaults, audio ducking thresholds, hardware acceleration, and credentials.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Account Profile */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-zinc-950 border border-zinc-800/80 rounded-2xl p-5 shadow-xl space-y-4">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-amber-400 to-yellow-600 flex items-center justify-center font-black text-zinc-950 text-2xl shadow-lg shadow-amber-500/25">
                FR
              </div>
              <div>
                <h3 className="font-extrabold text-base text-zinc-100">{displayName}</h3>
                <p className="text-xs text-amber-400 font-mono">{userEmail}</p>
                <div className="mt-1 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                  <span className="text-[11px] text-zinc-400">Pro Studio Lifetime License</span>
                </div>
              </div>
            </div>

            <div className="p-3.5 rounded-xl bg-zinc-900/70 border border-zinc-800 space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-zinc-400">API Connection:</span>
                <span className="font-bold text-emerald-400 font-mono">
                  {hasKey ? 'Gemini 3.8 & Veo 3.1 Active' : 'Connected'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-zinc-400">Studio Theme:</span>
                <span className="font-bold text-amber-300">Dark Gold Master</span>
              </div>
              <div className="flex justify-between">
                <span className="text-zinc-400">Cloud Storage:</span>
                <span className="font-bold text-zinc-300">4.8 GB / 50 GB</span>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Studio Preferences */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-zinc-950 border border-zinc-800/80 rounded-2xl p-5 shadow-xl space-y-4">
            <div className="flex items-center gap-2 pb-2 border-b border-zinc-800">
              <Settings className="w-4 h-4 text-amber-400" />
              <h3 className="font-bold text-sm text-zinc-100">Video Editor Defaults</h3>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-zinc-300 mb-1">
                  Default Export Resolution
                </label>
                <select
                  value={defaultResolution}
                  onChange={(e) => setDefaultResolution(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-zinc-900 border border-zinc-800 text-xs text-zinc-200 focus:border-amber-500 focus:outline-none"
                >
                  <option value="1080p">1080p Full HD (Recommended)</option>
                  <option value="4k">4K Ultra HD Cinema</option>
                  <option value="720p">720p High Speed</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-zinc-300 mb-1">
                  Default Transition
                </label>
                <select
                  value={defaultTransition}
                  onChange={(e) => setDefaultTransition(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-zinc-900 border border-zinc-800 text-xs text-zinc-200 focus:border-amber-500 focus:outline-none"
                >
                  <option value="dissolve">Cross Dissolve</option>
                  <option value="whip-left">Whip Pan Left</option>
                  <option value="zoom-in">Zoom In Burst</option>
                  <option value="flash">Optical Flash</option>
                </select>
              </div>
            </div>

            <div className="space-y-3 pt-2">
              <label className="flex items-center justify-between p-3 rounded-xl bg-zinc-900/60 border border-zinc-800 cursor-pointer">
                <div>
                  <div className="text-xs font-bold text-zinc-200">Intelligent Audio Ducking</div>
                  <div className="text-[11px] text-zinc-400">
                    Automatically lower background music soundtrack by -6dB when voiceover speaks.
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={autoDucking}
                  onChange={(e) => setAutoDucking(e.target.checked)}
                  className="w-4 h-4 accent-amber-500"
                />
              </label>

              <label className="flex items-center justify-between p-3 rounded-xl bg-zinc-900/60 border border-zinc-800 cursor-pointer">
                <div>
                  <div className="text-xs font-bold text-zinc-200">Hardware WebGL Acceleration</div>
                  <div className="text-[11px] text-zinc-400">
                    Use GPU shaders for real-time color grading and transition playback.
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={hardwareAcceleration}
                  onChange={(e) => setHardwareAcceleration(e.target.checked)}
                  className="w-4 h-4 accent-amber-500"
                />
              </label>
            </div>

            <button
              onClick={handleSave}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-amber-400 hover:to-yellow-500 text-zinc-950 font-bold text-xs shadow-md shadow-amber-500/20 flex items-center justify-center gap-2 transition-all"
            >
              {isSaved ? <Check className="w-4 h-4" /> : <Save className="w-4 h-4" />}
              <span>{isSaved ? 'Preferences Saved!' : 'Save Studio Preferences'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
