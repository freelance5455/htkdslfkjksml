import React, { useState } from 'react';
import { 
  Image as ImageIcon, 
  Sparkles, 
  ArrowUp, 
  ArrowDown, 
  ArrowLeft, 
  ArrowRight, 
  RotateCw, 
  ZoomIn, 
  Film, 
  Plus, 
  Upload, 
  Wand2 
} from 'lucide-react';
import { describeImageForVideo } from '../services/api';
import confetti from 'canvas-confetti';

interface ImageToVideoStudioProps {
  onInsertGeneratedClip: (title: string, videoUrl: string) => void;
  onNavigateToEditor: () => void;
}

export const ImageToVideoStudio: React.FC<ImageToVideoStudioProps> = ({
  onInsertGeneratedClip,
  onNavigateToEditor,
}) => {
  const [startImage, setStartImage] = useState<string>(
    'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=600&q=80'
  );
  const [endImage, setEndImage] = useState<string | null>(
    'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=600&q=80'
  );
  const [motionPrompt, setMotionPrompt] = useState(
    'Atmospheric golden embers swirl upward as camera tracks smoothly in a dramatic push-in shot'
  );
  const [cameraDirection, setCameraDirection] = useState<'forward' | 'up' | 'down' | 'left' | 'right' | 'orbit'>('forward');
  const [motionVelocity, setMotionVelocity] = useState<number>(65); // 0-100%
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);

  // Handle Gemini auto-describe
  const handleAutoDescribe = async () => {
    setIsAnalyzing(true);
    try {
      const desc = await describeImageForVideo(startImage);
      if (desc) {
        setMotionPrompt(desc);
      }
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleGenerate = () => {
    setIsGenerating(true);
    setTimeout(() => {
      setIsGenerating(false);
      onInsertGeneratedClip(
        'Image Motion Morph',
        'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4'
      );
      confetti({ particleCount: 45, spread: 65 });
    }, 1500);
  };

  return (
    <div className="max-w-[1440px] mx-auto p-4 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-zinc-800">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-extrabold text-zinc-100">Image-to-Video Motion Engine</h2>
            <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-amber-500/10 text-amber-400 border border-amber-500/30">
              Dual Keyframe Morph
            </span>
          </div>
          <p className="text-xs text-zinc-400 mt-1">
            Animate still imagery into fluid cinematic footage with vector velocity vectors and camera directionals.
          </p>
        </div>

        <button
          onClick={onNavigateToEditor}
          className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-zinc-900 hover:bg-zinc-850 text-amber-400 border border-amber-500/30 text-xs font-bold transition-colors"
        >
          <Film className="w-3.5 h-3.5" />
          <span>Timeline View</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Frame Selection */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-zinc-950 border border-zinc-800/80 rounded-2xl p-5 shadow-xl space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* First Frame */}
              <div className="space-y-2">
                <div className="flex justify-between items-center text-xs font-bold text-zinc-300">
                  <span>Start Frame (Keyframe 1)</span>
                  <button
                    onClick={handleAutoDescribe}
                    disabled={isAnalyzing}
                    className="text-amber-400 hover:text-amber-300 flex items-center gap-1 font-semibold"
                  >
                    <Wand2 className="w-3 h-3" />
                    <span>{isAnalyzing ? 'Analyzing...' : 'AI Describe'}</span>
                  </button>
                </div>
                <div className="relative aspect-video rounded-xl overflow-hidden border border-amber-500/40 bg-zinc-900 group">
                  <img src={startImage} alt="Start frame" className="w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <span className="text-xs font-bold text-amber-300 bg-zinc-900/90 px-3 py-1.5 rounded-lg border border-amber-500/40">
                      Active Start Frame
                    </span>
                  </div>
                </div>
              </div>

              {/* Last Frame (Optional) */}
              <div className="space-y-2">
                <div className="flex justify-between items-center text-xs font-bold text-zinc-300">
                  <span>End Frame (Morph Target)</span>
                  {endImage && (
                    <button
                      onClick={() => setEndImage(null)}
                      className="text-red-400 hover:text-red-300 text-[11px]"
                    >
                      Clear
                    </button>
                  )}
                </div>
                <div className="relative aspect-video rounded-xl overflow-hidden border border-zinc-800 bg-zinc-900 flex items-center justify-center">
                  {endImage ? (
                    <img src={endImage} alt="End frame" className="w-full h-full object-cover" />
                  ) : (
                    <div className="text-center p-4">
                      <ImageIcon className="w-6 h-6 text-zinc-600 mx-auto mb-1" />
                      <span className="text-[11px] text-zinc-500">Optional End Keyframe</span>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Motion Prompt */}
            <div>
              <label className="block text-xs font-bold text-zinc-300 mb-1.5 uppercase">
                Motion Description & Physics
              </label>
              <textarea
                rows={3}
                value={motionPrompt}
                onChange={(e) => setMotionPrompt(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-100 text-xs focus:border-amber-500 focus:outline-none resize-none leading-relaxed"
              />
            </div>

            {/* Directional Motion Vectors */}
            <div>
              <label className="block text-xs font-bold text-zinc-300 mb-2 uppercase">
                Camera Vector Direction
              </label>
              <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
                {[
                  { id: 'forward', label: 'Push In', icon: ZoomIn },
                  { id: 'left', label: 'Pan Left', icon: ArrowLeft },
                  { id: 'right', label: 'Pan Right', icon: ArrowRight },
                  { id: 'up', label: 'Crane Up', icon: ArrowUp },
                  { id: 'down', label: 'Tilt Down', icon: ArrowDown },
                  { id: 'orbit', label: 'Orbit 360', icon: RotateCw },
                ].map((item) => {
                  const Icon = item.icon;
                  const isSelected = cameraDirection === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => setCameraDirection(item.id as any)}
                      className={`flex flex-col items-center justify-center p-2.5 rounded-xl border transition-all ${
                        isSelected
                          ? 'bg-amber-500 text-zinc-950 border-amber-400 font-bold shadow-md shadow-amber-500/20'
                          : 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:text-zinc-200 hover:border-zinc-700'
                      }`}
                    >
                      <Icon className="w-4 h-4 mb-1" />
                      <span className="text-[11px]">{item.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Velocity Slider */}
            <div>
              <div className="flex justify-between text-xs font-medium mb-1">
                <span className="text-zinc-300">Movement Velocity</span>
                <span className="font-mono text-amber-400">{motionVelocity}%</span>
              </div>
              <input
                type="range"
                min="10"
                max="100"
                value={motionVelocity}
                onChange={(e) => setMotionVelocity(parseInt(e.target.value))}
                className="w-full accent-amber-500"
              />
            </div>

            {/* Render Button */}
            <button
              onClick={handleGenerate}
              disabled={isGenerating}
              className="w-full py-3.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-amber-400 hover:to-yellow-500 text-zinc-950 font-bold text-sm shadow-lg shadow-amber-500/20 disabled:opacity-50 transition-all flex items-center justify-center gap-2"
            >
              {isGenerating ? (
                <>
                  <div className="w-4 h-4 border-2 border-zinc-950 border-t-transparent rounded-full animate-spin" />
                  <span>Synthesizing Video Motion...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>Generate Motion & Add to Editor</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Preset Reference Stock */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-zinc-950 border border-zinc-800/80 rounded-2xl p-5 shadow-xl space-y-3">
            <h3 className="font-bold text-sm text-zinc-100">Preset High-Resolution Starters</h3>
            <p className="text-xs text-zinc-400">
              Click any image below to use as the base starting frame:
            </p>

            <div className="grid grid-cols-2 gap-3 pt-2">
              {[
                {
                  title: 'Cyberpunk Alley',
                  url: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=500&q=80',
                },
                {
                  title: 'Gold Dunes Sunset',
                  url: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=500&q=80',
                },
                {
                  title: 'Deep Cosmic Nebula',
                  url: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=500&q=80',
                },
                {
                  title: 'Supercar Velocity',
                  url: 'https://images.unsplash.com/photo-1542282088-72c9c27ed0cd?w=500&q=80',
                },
              ].map((p, idx) => (
                <div
                  key={idx}
                  onClick={() => setStartImage(p.url)}
                  className={`cursor-pointer rounded-xl overflow-hidden border transition-all ${
                    startImage === p.url
                      ? 'border-amber-400 ring-2 ring-amber-500/30 scale-102'
                      : 'border-zinc-800 hover:border-zinc-700'
                  }`}
                >
                  <img src={p.url} alt={p.title} className="w-full aspect-video object-cover" />
                  <div className="p-2 bg-zinc-900 text-[11px] font-semibold text-zinc-300 truncate">
                    {p.title}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
