import React, { useState } from 'react';
import { 
  Briefcase, 
  Search, 
  Check, 
  Sparkles, 
  ExternalLink, 
  Download, 
  Plus, 
  Edit3, 
  Globe, 
  Award,
  Layers
} from 'lucide-react';
import { MarketingFormat, MarketingAsset, AppTab } from '../types';
import confetti from 'canvas-confetti';

interface BusinessStudioProps {
  onInsertAssetToEditor?: (name: string, url: string, type: 'video' | 'image' | 'audio') => void;
  onNavigateTab?: (tab: AppTab) => void;
}

export const BusinessStudio: React.FC<BusinessStudioProps> = ({
  onInsertAssetToEditor,
  onNavigateTab,
}) => {
  const [inputMode, setInputMode] = useState<'url' | 'manual'>('url');
  const [websiteUrl, setWebsiteUrl] = useState('https://lumina-fashion.com');
  const [businessName, setBusinessName] = useState('Lumina Luxe Apparel');
  const [businessDescription, setBusinessDescription] = useState('Sustainable luxury streetwear crafted with organic bamboo silk and dark gold accents');
  const [selectedCategory, setSelectedCategory] = useState('Retail & Fashion');

  // Marketing Formats with Dimensions matching Screenshot 4
  const [formats, setFormats] = useState<MarketingFormat[]>([
    { id: 'social-post', name: 'Social Post', dimensions: '1080×1080', selected: true },
    { id: 'story-reel', name: 'Story/Reel', dimensions: '1080×1920', selected: true },
    { id: 'banner-ad', name: 'Banner Ad', dimensions: '1200×628', selected: true },
    { id: 'logo-concept', name: 'Logo Concept', dimensions: '800×800', selected: false },
    { id: 'email-header', name: 'Email Header', dimensions: '600×200', selected: false },
    { id: 'yt-thumbnail', name: 'YT Thumbnail', dimensions: '1280×720', selected: false },
  ]);

  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedAssets, setGeneratedAssets] = useState<MarketingAsset[]>([]);

  // Categories matching Screenshot 3 & 4
  const categories = [
    { id: 'Restaurant & Food', label: 'Restaurant & Food', icon: '🍴' },
    { id: 'Retail & Fashion', label: 'Retail & Fashion', icon: '🛍️' },
    { id: 'Beauty & Wellness', label: 'Beauty & Wellness', icon: '🌿' },
    { id: 'Tech & Startup', label: 'Tech & Startup', icon: '💻' },
    { id: 'Real Estate', label: 'Real Estate', icon: '🏠' },
    { id: 'Fitness & Sports', label: 'Fitness & Sports', icon: '🏋️' },
    { id: 'Education', label: 'Education', icon: '🎓' },
    { id: 'Healthcare', label: 'Healthcare', icon: '➕' },
    { id: 'Finance', label: 'Finance', icon: '🏛️' },
    { id: 'Travel & Tourism', label: 'Travel & Tourism', icon: '✈️' },
  ];

  // Toggle Format Selection
  const toggleFormat = (id: string) => {
    setFormats(
      formats.map((f) => (f.id === id ? { ...f, selected: !f.selected } : f))
    );
  };

  const selectedCount = formats.filter((f) => f.selected).length;

  // Generate Assets
  const handleGenerateAssets = () => {
    if (selectedCount === 0 || isGenerating) return;
    setIsGenerating(true);

    setTimeout(() => {
      const selectedFormatsList = formats.filter((f) => f.selected);
      const stockImages = [
        'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=800&q=80',
        'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&q=80',
        'https://images.unsplash.com/photo-1542282088-72c9c27ed0cd?w=800&q=80',
        'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=800&q=80',
      ];

      const newAssets: MarketingAsset[] = selectedFormatsList.map((f, idx) => ({
        id: 'asset-' + Date.now() + '-' + idx,
        format: f.name,
        dimensions: f.dimensions,
        title: `${businessName} · ${f.name}`,
        copy: `Elevate your lifestyle with ${businessName}. Crafted for distinction. Available worldwide now.`,
        imageUrl: stockImages[idx % stockImages.length],
        videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4',
      }));

      setGeneratedAssets(newAssets);
      setIsGenerating(false);
      confetti({ particleCount: 50, spread: 70 });
    }, 1500);
  };

  return (
    <div className="max-w-[720px] mx-auto px-4 py-4 space-y-6">
      {/* Top Header with PRO Badge (from Screenshot 3 & 4) */}
      <div className="flex items-center justify-between pb-2 border-b border-zinc-800">
        <h2 className="text-xl font-extrabold text-zinc-100">Business Studio</h2>
        <span className="px-2.5 py-0.5 rounded text-xs font-black uppercase tracking-wider bg-amber-500/20 text-amber-300 border border-amber-500/40">
          PRO
        </span>
      </div>

      {/* Hero Card: AI Marketing Generator (from Screenshot 3) */}
      <div className="rounded-2xl border border-amber-500/30 bg-zinc-950 p-4 shadow-xl flex items-center gap-3.5">
        <div className="w-12 h-12 rounded-2xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center shrink-0">
          <Briefcase className="w-6 h-6 text-amber-400" />
        </div>
        <div>
          <h3 className="text-base font-extrabold text-zinc-100">AI Marketing Generator</h3>
          <p className="text-xs text-zinc-400 mt-0.5 leading-relaxed">
            Enter your URL or describe your business to generate a complete marketing asset pack
          </p>
        </div>
      </div>

      {/* Input Mode Switcher (from Screenshot 3) */}
      <div className="grid grid-cols-2 gap-2 bg-zinc-900/80 p-1.5 rounded-2xl border border-zinc-800">
        <button
          onClick={() => setInputMode('url')}
          className={`py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${
            inputMode === 'url'
              ? 'bg-amber-500 text-zinc-950 shadow-md shadow-amber-500/20'
              : 'text-zinc-400 hover:text-zinc-200'
          }`}
        >
          <span>🔗</span>
          <span>Business URL</span>
        </button>

        <button
          onClick={() => setInputMode('manual')}
          className={`py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${
            inputMode === 'manual'
              ? 'bg-amber-500 text-zinc-950 shadow-md shadow-amber-500/20'
              : 'text-zinc-400 hover:text-zinc-200'
          }`}
        >
          <span>✏️</span>
          <span>Manual Input</span>
        </button>
      </div>

      {/* Website URL or Manual Input Field (from Screenshot 3) */}
      <div className="rounded-2xl border border-zinc-800 bg-zinc-950 p-4 space-y-2">
        {inputMode === 'url' ? (
          <div>
            <label className="block text-[11px] font-extrabold text-zinc-400 uppercase tracking-wider mb-2">
              WEBSITE URL
            </label>
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={websiteUrl}
                onChange={(e) => setWebsiteUrl(e.target.value)}
                placeholder="https://yourbusiness.com"
                className="flex-1 px-4 py-3 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-100 text-xs focus:border-amber-500 focus:outline-none"
              />
              <button
                onClick={() => {
                  setBusinessName('Lumina Luxury Wear');
                  confetti({ particleCount: 20 });
                }}
                title="Scan & Analyze Business"
                className="w-11 h-11 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-amber-400 hover:to-yellow-500 text-zinc-950 flex items-center justify-center shrink-0 transition-transform active:scale-95"
              >
                <Search className="w-5 h-5" />
              </button>
            </div>
          </div>
        ) : (
          <div className="space-y-3">
            <div>
              <label className="block text-[11px] font-extrabold text-zinc-400 uppercase tracking-wider mb-1">
                BUSINESS NAME
              </label>
              <input
                type="text"
                value={businessName}
                onChange={(e) => setBusinessName(e.target.value)}
                placeholder="E.g. Acme Studio"
                className="w-full px-4 py-2.5 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-100 text-xs focus:border-amber-500 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-[11px] font-extrabold text-zinc-400 uppercase tracking-wider mb-1">
                BUSINESS DESCRIPTION
              </label>
              <textarea
                rows={2}
                value={businessDescription}
                onChange={(e) => setBusinessDescription(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-100 text-xs focus:border-amber-500 focus:outline-none resize-none"
              />
            </div>
          </div>
        )}
      </div>

      {/* BUSINESS CATEGORY Section (from Screenshot 3 & 4) */}
      <div className="space-y-2">
        <label className="text-xs font-extrabold text-zinc-400 uppercase tracking-wider">
          BUSINESS CATEGORY
        </label>
        <div className="flex flex-wrap gap-2">
          {categories.map((cat) => {
            const isSelected = selectedCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-full border text-xs font-bold transition-all ${
                  isSelected
                    ? 'bg-amber-500 text-zinc-950 border-amber-400 shadow-md shadow-amber-500/20'
                    : 'bg-zinc-900/80 border-zinc-800 text-zinc-300 hover:border-zinc-700'
                }`}
              >
                <span>{cat.icon}</span>
                <span>{cat.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* MARKETING FORMATS Section (from Screenshot 4) */}
      <div className="space-y-2">
        <label className="text-xs font-extrabold text-zinc-400 uppercase tracking-wider">
          MARKETING FORMATS
        </label>
        <div className="grid grid-cols-2 gap-2.5">
          {formats.map((fmt) => {
            return (
              <div
                key={fmt.id}
                onClick={() => toggleFormat(fmt.id)}
                className={`cursor-pointer flex items-center gap-3 p-3.5 rounded-2xl border transition-all select-none ${
                  fmt.selected
                    ? 'bg-amber-500/15 border-amber-400 text-amber-300 shadow-sm ring-1 ring-amber-400'
                    : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:border-zinc-700'
                }`}
              >
                {/* Checkbox indicator */}
                <div
                  className={`w-5 h-5 rounded-full flex items-center justify-center shrink-0 border transition-all ${
                    fmt.selected
                      ? 'bg-amber-500 border-amber-400 text-zinc-950'
                      : 'border-zinc-700 bg-zinc-900'
                  }`}
                >
                  {fmt.selected && <Check className="w-3 h-3 stroke-[3]" />}
                </div>

                <div className="truncate">
                  <div className="font-extrabold text-xs text-zinc-100 truncate">{fmt.name}</div>
                  <div className="text-[11px] font-mono text-zinc-500">{fmt.dimensions}</div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Big CTA Button (from Screenshot 4: "Generate 3 Assets") */}
      <div className="pt-2">
        <button
          onClick={handleGenerateAssets}
          disabled={selectedCount === 0 || isGenerating}
          className="w-full py-4 rounded-2xl bg-gradient-to-r from-amber-500 via-yellow-500 to-amber-600 hover:from-amber-400 hover:to-yellow-400 text-zinc-950 font-black text-sm shadow-xl shadow-amber-500/25 transition-all hover:scale-[1.01] active:scale-[0.99] disabled:opacity-40 flex items-center justify-center gap-2"
        >
          {isGenerating ? (
            <>
              <div className="w-4 h-4 border-2 border-zinc-950 border-t-transparent rounded-full animate-spin" />
              <span>Generating {selectedCount} Marketing Assets...</span>
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4 fill-zinc-950" />
              <span>Generate {selectedCount} Assets</span>
            </>
          )}
        </button>
      </div>

      {/* Generated Assets Display Strip */}
      {generatedAssets.length > 0 && (
        <div className="space-y-3 pt-3 border-t border-zinc-800">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-zinc-300 uppercase tracking-wider">
              Generated Marketing Package ({generatedAssets.length})
            </span>
          </div>

          <div className="space-y-3">
            {generatedAssets.map((asset) => (
              <div
                key={asset.id}
                className="bg-zinc-950 border border-zinc-800 rounded-2xl p-4 space-y-3 shadow-xl"
              >
                <div className="flex gap-3">
                  <img
                    src={asset.imageUrl}
                    alt=""
                    className="w-24 h-24 rounded-xl object-cover border border-zinc-800 shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <span className="font-extrabold text-xs text-zinc-100">{asset.format}</span>
                      <span className="text-[10px] font-mono text-amber-400">{asset.dimensions}</span>
                    </div>
                    <p className="text-[11px] text-zinc-400 mt-1 line-clamp-3 leading-relaxed">
                      {asset.copy}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 pt-2 border-t border-zinc-850">
                  {onInsertAssetToEditor && (
                    <button
                      onClick={() => {
                        onInsertAssetToEditor(asset.title, asset.imageUrl, 'image');
                        if (onNavigateTab) onNavigateTab('studio');
                      }}
                      className="flex-1 py-1.5 rounded-lg bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 border border-amber-500/40 text-xs font-bold flex items-center justify-center gap-1.5 transition-colors"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                      <span>Edit in Video Studio</span>
                    </button>
                  )}

                  <a
                    href={asset.imageUrl}
                    download={`marketing_${asset.format}.png`}
                    className="p-1.5 rounded-lg bg-zinc-900 hover:bg-zinc-850 text-zinc-300 border border-zinc-800 transition-colors"
                    title="Download Asset"
                  >
                    <Download className="w-4 h-4" />
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
