import React, { useState } from 'react';
import { Share2, Copy, Check, X, Globe, Smartphone } from 'lucide-react';

interface MetaTagsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const MetaTagsModal: React.FC<MetaTagsModalProps> = ({ isOpen, onClose }) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const metaHtml = `<!-- Motionai OpenGraph & Social SEO Tags -->
<title>Motionai - Professional Video Editor & AI Cinema Studio</title>
<meta name="description" content="Next-generation AI video & image generation studio and professional Video Editor with cinematic transition effects (dissolve, slide, zoom, whip pan), multi-task batch queue processing, 4K resolution, Image-to-Video, prompt enhancement, and native Android APK export." />
<meta property="og:title" content="Motionai - AI Video & CapCut-Grade Editor" />
<meta property="og:description" content="Professional multi-track timeline, transitions, color grading, audio ducking, and dual standalone iOS/Android installations." />
<meta property="og:image" content="https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=1200&q=80" />
<meta property="og:type" content="website" />
<meta name="twitter:card" content="summary_large_image" />
<meta name="theme-color" content="#09090b" />
<meta name="apple-mobile-web-app-capable" content="yes" />
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />`;

  const handleCopy = () => {
    navigator.clipboard.writeText(metaHtml);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="relative w-full max-w-xl bg-zinc-950 border border-amber-500/40 rounded-2xl p-6 shadow-2xl space-y-4">
        <div className="flex justify-between items-center pb-2 border-b border-zinc-800">
          <div className="flex items-center gap-2">
            <Share2 className="w-5 h-5 text-amber-400" />
            <h3 className="font-extrabold text-base text-zinc-100">
              SEO, OpenGraph & PWA Meta Configuration
            </h3>
          </div>
          <button
            onClick={onClose}
            className="text-zinc-400 hover:text-zinc-100 p-1 rounded-lg"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <p className="text-xs text-zinc-400">
          These verified meta tags ensure rich previews on Twitter/X, Discord, Slack, LinkedIn, and enable full iOS/Android home screen installability.
        </p>

        {/* Live Card Preview */}
        <div className="rounded-xl overflow-hidden border border-zinc-800 bg-zinc-900/60 p-3 space-y-2">
          <div className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider">
            Social Card Preview
          </div>
          <div className="rounded-lg overflow-hidden border border-zinc-800 bg-black">
            <img
              src="https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=800&q=80"
              alt=""
              className="w-full aspect-video object-cover"
            />
            <div className="p-3 bg-zinc-900">
              <div className="font-bold text-xs text-zinc-100">Motionai - AI Video & CapCut-Grade Editor</div>
              <div className="text-[11px] text-zinc-400 mt-1 line-clamp-1">
                Professional multi-track timeline, transitions, color grading, audio ducking, and dual standalone iOS/Android installations.
              </div>
              <div className="text-[10px] text-amber-400/80 font-mono mt-1">motionai.studio</div>
            </div>
          </div>
        </div>

        {/* Code Block */}
        <div>
          <pre className="p-3 rounded-xl bg-zinc-900 font-mono text-[11px] text-amber-200/90 overflow-x-auto max-h-[140px] leading-relaxed border border-zinc-800">
            <code>{metaHtml}</code>
          </pre>
        </div>

        <div className="flex justify-end gap-2 pt-2 border-t border-zinc-800">
          <button
            onClick={onClose}
            className="px-3.5 py-2 rounded-xl bg-zinc-900 hover:bg-zinc-850 text-zinc-300 text-xs font-semibold"
          >
            Close
          </button>
          <button
            onClick={handleCopy}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-amber-400 hover:to-yellow-500 text-zinc-950 font-bold text-xs shadow-md shadow-amber-500/20 transition-all"
          >
            {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copied to Clipboard' : 'Copy All Meta Tags'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
