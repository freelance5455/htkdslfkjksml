import React, { useState } from 'react';
import { 
  Download, 
  Smartphone, 
  Apple, 
  Copy, 
  Check, 
  FileCode, 
  ExternalLink, 
  Layers, 
  PackageCheck 
} from 'lucide-react';
import { 
  ANDROID_MAIN_ACTIVITY_KOTLIN, 
  ANDROID_MANIFEST_XML, 
  ANDROID_BUILD_GRADLE 
} from '../data/androidProjectCode';
import confetti from 'canvas-confetti';

export const AndroidExportStudio: React.FC = () => {
  const [activeCodeTab, setActiveCodeTab] = useState<'kotlin' | 'manifest' | 'gradle'>('kotlin');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const handleCopy = (key: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const getActiveCode = () => {
    switch (activeCodeTab) {
      case 'kotlin':
        return ANDROID_MAIN_ACTIVITY_KOTLIN;
      case 'manifest':
        return ANDROID_MANIFEST_XML;
      case 'gradle':
        return ANDROID_BUILD_GRADLE;
    }
  };

  return (
    <div className="max-w-[1440px] mx-auto p-4 space-y-6">
      {/* Header */}
      <div className="pb-4 border-b border-zinc-800">
        <div className="flex items-center gap-2">
          <Smartphone className="w-5 h-5 text-amber-400" />
          <h2 className="text-xl font-extrabold text-zinc-100">
            Universal Mobile Deployment & Standalone Export Suite
          </h2>
        </div>
        <p className="text-xs text-zinc-400 mt-1">
          Download single-file offline installers, dedicated iOS WebKit HTML, dedicated Android WebView HTML, or integrate native Kotlin Android Studio code.
        </p>
      </div>

      {/* 3 Prominent Download Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Card 1: One File HTML for Installation */}
        <div className="bg-zinc-950 border border-amber-500/40 rounded-2xl p-5 shadow-xl flex flex-col justify-between relative overflow-hidden group">
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 text-lg">
                📦
              </span>
              <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40">
                Single Installer
              </span>
            </div>

            <div>
              <h3 className="text-base font-extrabold text-zinc-100">Universal Installer</h3>
              <p className="text-xs text-zinc-400 mt-1 leading-relaxed">
                One complete standalone HTML file with PWA self-install wizard, offline service cache, and CapCut studio launcher.
              </p>
            </div>
          </div>

          <div className="pt-4 mt-2 border-t border-zinc-850 flex items-center gap-2">
            <a
              href="/install.html"
              download="install.html"
              onClick={() => confetti({ particleCount: 30 })}
              className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-amber-400 hover:to-yellow-500 text-zinc-950 font-bold text-xs shadow-md shadow-amber-500/20 flex items-center justify-center gap-1.5 transition-all"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download (.html)</span>
            </a>
            <a
              href="/install.html"
              target="_blank"
              rel="noreferrer"
              className="p-2.5 rounded-xl bg-zinc-900 hover:bg-zinc-850 text-amber-400 border border-zinc-800 transition-colors"
              title="Open Live Preview"
            >
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>
        </div>

        {/* Card 2: Dedicated iOS File */}
        <div className="bg-zinc-950 border border-zinc-800/80 hover:border-amber-500/40 rounded-2xl p-5 shadow-xl flex flex-col justify-between transition-colors">
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="w-10 h-10 rounded-xl bg-zinc-900 border border-zinc-800 flex items-center justify-center text-zinc-100 text-lg">
                🍎
              </span>
              <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-zinc-900 text-zinc-300 border border-zinc-800">
                iOS Native WebApp
              </span>
            </div>

            <div>
              <h3 className="text-base font-extrabold text-zinc-100">iOS Standalone File</h3>
              <p className="text-xs text-zinc-400 mt-1 leading-relaxed">
                Optimized for Safari WebKit with Dynamic Island & safe-area insets, dark gold theme, touch timeline, and PWA manifest.
              </p>
            </div>
          </div>

          <div className="pt-4 mt-2 border-t border-zinc-850 flex items-center gap-2">
            <a
              href="/motionai-ios.html"
              download="motionai-ios.html"
              onClick={() => confetti({ particleCount: 30 })}
              className="flex-1 py-2.5 rounded-xl bg-zinc-900 hover:bg-zinc-850 text-amber-400 hover:text-amber-300 border border-amber-500/40 font-bold text-xs flex items-center justify-center gap-1.5 transition-all"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download for iOS</span>
            </a>
            <a
              href="/motionai-ios.html"
              target="_blank"
              rel="noreferrer"
              className="p-2.5 rounded-xl bg-zinc-900 hover:bg-zinc-850 text-amber-400 border border-zinc-800 transition-colors"
              title="Open Live Preview"
            >
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>
        </div>

        {/* Card 3: Dedicated Android File */}
        <div className="bg-zinc-950 border border-zinc-800/80 hover:border-amber-500/40 rounded-2xl p-5 shadow-xl flex flex-col justify-between transition-colors">
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="w-10 h-10 rounded-xl bg-zinc-900 border border-zinc-800 flex items-center justify-center text-zinc-100 text-lg">
                🤖
              </span>
              <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-zinc-900 text-zinc-300 border border-zinc-800">
                Android APK Runtime
              </span>
            </div>

            <div>
              <h3 className="text-base font-extrabold text-zinc-100">Android Standalone File</h3>
              <p className="text-xs text-zinc-400 mt-1 leading-relaxed">
                Tuned for Chrome WebView hardware acceleration, Android immersive mode, back button navigation, and timeline editing.
              </p>
            </div>
          </div>

          <div className="pt-4 mt-2 border-t border-zinc-850 flex items-center gap-2">
            <a
              href="/motionai-android.html"
              download="motionai-android.html"
              onClick={() => confetti({ particleCount: 30 })}
              className="flex-1 py-2.5 rounded-xl bg-zinc-900 hover:bg-zinc-850 text-amber-400 hover:text-amber-300 border border-amber-500/40 font-bold text-xs flex items-center justify-center gap-1.5 transition-all"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download for Android</span>
            </a>
            <a
              href="/motionai-android.html"
              target="_blank"
              rel="noreferrer"
              className="p-2.5 rounded-xl bg-zinc-900 hover:bg-zinc-850 text-amber-400 border border-zinc-800 transition-colors"
              title="Open Live Preview"
            >
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>
        </div>
      </div>

      {/* Native Android Studio Kotlin Project Wrapper */}
      <div className="bg-zinc-950 border border-zinc-800/80 rounded-2xl overflow-hidden shadow-xl">
        <div className="p-4 border-b border-zinc-800 bg-zinc-900/60 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <FileCode className="w-4 h-4 text-amber-400" />
            <span className="text-xs font-bold text-zinc-200 uppercase tracking-wider">
              Native Android Studio Project Source (Kotlin & Gradle)
            </span>
          </div>

          <div className="flex items-center gap-2">
            {/* Code Tabs */}
            <div className="flex items-center gap-1 bg-zinc-950 p-1 rounded-lg border border-zinc-800">
              <button
                onClick={() => setActiveCodeTab('kotlin')}
                className={`px-2.5 py-1 rounded text-[11px] font-semibold transition-colors ${
                  activeCodeTab === 'kotlin'
                    ? 'bg-amber-500 text-zinc-950 font-bold'
                    : 'text-zinc-400 hover:text-zinc-200'
                }`}
              >
                MainActivity.kt
              </button>
              <button
                onClick={() => setActiveCodeTab('manifest')}
                className={`px-2.5 py-1 rounded text-[11px] font-semibold transition-colors ${
                  activeCodeTab === 'manifest'
                    ? 'bg-amber-500 text-zinc-950 font-bold'
                    : 'text-zinc-400 hover:text-zinc-200'
                }`}
              >
                AndroidManifest.xml
              </button>
              <button
                onClick={() => setActiveCodeTab('gradle')}
                className={`px-2.5 py-1 rounded text-[11px] font-semibold transition-colors ${
                  activeCodeTab === 'gradle'
                    ? 'bg-amber-500 text-zinc-950 font-bold'
                    : 'text-zinc-400 hover:text-zinc-200'
                }`}
              >
                build.gradle.kts
              </button>
            </div>

            <button
              onClick={() => handleCopy(activeCodeTab, getActiveCode())}
              className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-zinc-900 hover:bg-zinc-800 text-amber-400 border border-amber-500/30 text-xs font-bold transition-colors"
            >
              {copiedKey === activeCodeTab ? (
                <>
                  <Check className="w-3.5 h-3.5" />
                  <span>Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copy Code</span>
                </>
              )}
            </button>
          </div>
        </div>

        <div className="p-4 bg-zinc-950">
          <pre className="p-4 rounded-xl bg-zinc-900/80 border border-zinc-850 text-amber-200/90 font-mono text-xs overflow-x-auto max-h-[380px] leading-relaxed">
            <code>{getActiveCode()}</code>
          </pre>
        </div>
      </div>
    </div>
  );
};
