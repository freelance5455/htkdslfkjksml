import React, { useState } from 'react';
import { 
  Sparkles, 
  Wand2, 
  Download, 
  Film, 
  Layers, 
  Plus, 
  Image as ImageIcon, 
  Maximize2 
} from 'lucide-react';
import { IMAGE_STYLES, LIGHTING_PRESETS } from '../data/imagePresets';
import { ImageItem, AspectRatio } from '../types';
import { generateImage, enhancePrompt } from '../services/api';
import confetti from 'canvas-confetti';

interface ImageGenerationStudioProps {
  onInsertImageToEditor: (title: string, imageUrl: string) => void;
  onSendToImage2Video: (imageUrl: string) => void;
  onNavigateToEditor: () => void;
}

export const ImageGenerationStudio: React.FC<ImageGenerationStudioProps> = ({
  onInsertImageToEditor,
  onSendToImage2Video,
  onNavigateToEditor,
}) => {
  const [prompt, setPrompt] = useState(
    'A high-tech cybernetic lotus flower floating on obsidian water, volumetric dark gold rim lighting'
  );
  const [selectedStyle, setSelectedStyle] = useState(IMAGE_STYLES[0].id);
  const [selectedLighting, setSelectedLighting] = useState(LIGHTING_PRESETS[0]);
  const [aspectRatio, setAspectRatio] = useState<AspectRatio>('16:9');
  const [isGenerating, setIsGenerating] = useState(false);
  const [isEnhancing, setIsEnhancing] = useState(false);
  const [images, setImages] = useState<ImageItem[]>([
    {
      id: 'img-1',
      url: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=800&q=80',
      prompt: 'Cyberpunk Tokyo rain reflections with neon gold lighting',
      style: 'Cinematic Dark Gold',
      aspectRatio: '16:9',
      createdAt: Date.now() - 3600000,
    },
    {
      id: 'img-2',
      url: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&q=80',
      prompt: 'Golden hour drone orbit over desert dunes',
      style: 'Hyper-Photorealistic',
      aspectRatio: '16:9',
      createdAt: Date.now() - 7200000,
    },
    {
      id: 'img-3',
      url: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=800&q=80',
      prompt: 'Deep interstellar nebula pulsar with golden cosmic dust',
      style: 'Octane 3D Render',
      aspectRatio: '16:9',
      createdAt: Date.now() - 10800000,
    },
    {
      id: 'img-4',
      url: 'https://images.unsplash.com/photo-1542282088-72c9c27ed0cd?w=800&q=80',
      prompt: 'Futuristic hypercar drifting at sunset with amber flares',
      style: 'Cinematic Dark Gold',
      aspectRatio: '16:9',
      createdAt: Date.now() - 14400000,
    },
  ]);
  const [selectedImage, setSelectedImage] = useState<ImageItem | null>(images[0]);

  // Enhance prompt with Gemini
  const handleEnhance = async () => {
    if (!prompt.trim()) return;
    setIsEnhancing(true);
    try {
      const res = await enhancePrompt(prompt, '35mm Lens', 'Photorealistic Dark Gold');
      if (res.enhancedPrompt) {
        setPrompt(res.enhancedPrompt);
      }
    } finally {
      setIsEnhancing(false);
    }
  };

  // Generate Image
  const handleGenerate = async () => {
    if (!prompt.trim() || isGenerating) return;
    setIsGenerating(true);

    const activeStyleObj = IMAGE_STYLES.find((s) => s.id === selectedStyle);
    const fullPrompt = `${prompt}, ${activeStyleObj?.promptSuffix || ''}, ${selectedLighting}`;

    try {
      const imageUrl = await generateImage(fullPrompt, aspectRatio);
      const newImg: ImageItem = {
        id: 'img-' + Date.now(),
        url: imageUrl,
        prompt,
        style: activeStyleObj?.name || 'Custom',
        aspectRatio,
        createdAt: Date.now(),
      };

      setImages([newImg, ...images]);
      setSelectedImage(newImg);
      confetti({ particleCount: 40, spread: 60 });
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="max-w-[1440px] mx-auto p-4 space-y-6">
      {/* Studio Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-zinc-800">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-extrabold text-zinc-100">AI Image Generation Studio</h2>
            <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-amber-500/10 text-amber-400 border border-amber-500/30">
              Gemini 3.1 Flash Image
            </span>
          </div>
          <p className="text-xs text-zinc-400 mt-1">
            Synthesize high-fidelity concept art, keyframes, and textures. Send directly to Image-to-Video or the CapCut Timeline.
          </p>
        </div>

        <button
          onClick={onNavigateToEditor}
          className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-zinc-900 hover:bg-zinc-850 text-amber-400 border border-amber-500/30 text-xs font-bold transition-colors shrink-0"
        >
          <Film className="w-3.5 h-3.5" />
          <span>CapCut Timeline</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Generation Controls */}
        <div className="lg:col-span-6 space-y-4">
          <div className="bg-zinc-950 border border-zinc-800/80 rounded-2xl p-5 shadow-xl space-y-4">
            {/* Prompt Textarea */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="text-xs font-bold text-zinc-200 uppercase tracking-wider flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                  <span>Image Prompt</span>
                </label>
                <button
                  onClick={handleEnhance}
                  disabled={isEnhancing || !prompt.trim()}
                  className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 border border-amber-500/30 text-xs font-semibold disabled:opacity-50 transition-colors"
                >
                  <Wand2 className={`w-3.5 h-3.5 ${isEnhancing ? 'animate-spin' : ''}`} />
                  <span>{isEnhancing ? 'Enhancing...' : 'AI Enhance'}</span>
                </button>
              </div>

              <textarea
                rows={3}
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="Describe your visual concept in vivid detail..."
                className="w-full px-3.5 py-3 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-100 text-xs focus:border-amber-500 focus:outline-none resize-none leading-relaxed"
              />
            </div>

            {/* Visual Style Carousel */}
            <div>
              <label className="block text-[11px] font-bold text-zinc-400 uppercase mb-2">
                Artistic Style Preset
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {IMAGE_STYLES.map((st) => (
                  <button
                    key={st.id}
                    onClick={() => setSelectedStyle(st.id)}
                    className={`flex items-center gap-2 p-2 rounded-xl border text-left transition-all ${
                      selectedStyle === st.id
                        ? 'bg-amber-500/15 border-amber-400 text-amber-300 shadow-sm'
                        : 'bg-zinc-900 border-zinc-800 text-zinc-300 hover:border-zinc-700'
                    }`}
                  >
                    <img src={st.previewUrl} alt="" className="w-8 h-8 rounded-lg object-cover shrink-0" />
                    <span className="text-[11px] font-bold truncate">{st.name}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Lighting & Aspect Ratio */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-bold text-zinc-400 uppercase mb-1">
                  Lighting Atmosphere
                </label>
                <select
                  value={selectedLighting}
                  onChange={(e) => setSelectedLighting(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-zinc-900 border border-zinc-800 text-xs text-zinc-200 focus:border-amber-500 focus:outline-none"
                >
                  {LIGHTING_PRESETS.map((l) => (
                    <option key={l} value={l}>
                      {l}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-zinc-400 uppercase mb-1">
                  Aspect Ratio
                </label>
                <select
                  value={aspectRatio}
                  onChange={(e) => setAspectRatio(e.target.value as any)}
                  className="w-full px-3 py-2 rounded-lg bg-zinc-900 border border-zinc-800 text-xs text-zinc-200 focus:border-amber-500 focus:outline-none"
                >
                  <option value="16:9">16:9 Widescreen</option>
                  <option value="1:1">1:1 Square</option>
                  <option value="9:16">9:16 Story / Reel</option>
                  <option value="4:3">4:3 Standard</option>
                  <option value="3:4">3:4 Portrait</option>
                </select>
              </div>
            </div>

            {/* Generate Button */}
            <button
              onClick={handleGenerate}
              disabled={isGenerating || !prompt.trim()}
              className="w-full py-3.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-amber-400 hover:to-yellow-500 text-zinc-950 font-extrabold text-sm shadow-lg shadow-amber-500/25 transition-all hover:scale-[1.01] disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {isGenerating ? (
                <>
                  <div className="w-4 h-4 border-2 border-zinc-950 border-t-transparent rounded-full animate-spin" />
                  <span>Synthesizing Image...</span>
                </>
              ) : (
                <>
                  <ImageIcon className="w-4 h-4" />
                  <span>Generate Image ({aspectRatio})</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Right Column: Preview & Gallery */}
        <div className="lg:col-span-6 space-y-4">
          <div className="bg-zinc-950 border border-zinc-800/80 rounded-2xl p-5 shadow-xl space-y-4">
            {/* Active Image Preview Box */}
            {selectedImage ? (
              <div className="space-y-3">
                <div className="relative aspect-video rounded-xl overflow-hidden border border-zinc-800 bg-black flex items-center justify-center group shadow-2xl">
                  <img
                    src={selectedImage.url}
                    alt={selectedImage.prompt}
                    className="w-full h-full object-contain"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity p-4 flex flex-col justify-end">
                    <p className="text-xs text-zinc-200 line-clamp-2 font-medium">
                      {selectedImage.prompt}
                    </p>
                  </div>
                </div>

                {/* Action Pipeline Buttons */}
                <div className="grid grid-cols-3 gap-2">
                  <button
                    onClick={() => onInsertImageToEditor(selectedImage.prompt.slice(0, 20), selectedImage.url)}
                    className="py-2 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 text-xs font-bold flex items-center justify-center gap-1.5 transition-colors"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Send to Timeline</span>
                  </button>

                  <button
                    onClick={() => onSendToImage2Video(selectedImage.url)}
                    className="py-2 rounded-lg bg-zinc-900 hover:bg-zinc-850 text-zinc-200 border border-zinc-800 text-xs font-bold flex items-center justify-center gap-1.5 transition-colors"
                  >
                    <Film className="w-3.5 h-3.5 text-amber-400" />
                    <span>Animate Video</span>
                  </button>

                  <a
                    href={selectedImage.url}
                    download="motionai_generated_image.png"
                    className="py-2 rounded-lg bg-zinc-900 hover:bg-zinc-850 text-zinc-200 border border-zinc-800 text-xs font-bold flex items-center justify-center gap-1.5 transition-colors"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download</span>
                  </a>
                </div>
              </div>
            ) : null}

            {/* Generated Gallery Strip */}
            <div>
              <div className="text-[11px] font-bold text-zinc-400 uppercase mb-2">
                Recent Creations ({images.length})
              </div>
              <div className="grid grid-cols-4 gap-2">
                {images.map((img) => (
                  <div
                    key={img.id}
                    onClick={() => setSelectedImage(img)}
                    className={`cursor-pointer aspect-video rounded-lg overflow-hidden border transition-all ${
                      selectedImage?.id === img.id
                        ? 'border-amber-400 ring-2 ring-amber-500/40'
                        : 'border-zinc-800 hover:border-zinc-700'
                    }`}
                  >
                    <img src={img.url} alt="" className="w-full h-full object-cover" />
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
