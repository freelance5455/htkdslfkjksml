import React from 'react';
import { AppTab } from '../types';
import { 
  Sparkles, 
  Clapperboard, 
  Briefcase, 
  PlaySquare, 
  User 
} from 'lucide-react';

interface BottomNavBarProps {
  currentTab: AppTab;
  onTabChange: (tab: AppTab) => void;
}

export const BottomNavBar: React.FC<BottomNavBarProps> = ({ currentTab, onTabChange }) => {
  // 5 exact tabs from user screenshot
  const navItems = [
    {
      id: 'create' as AppTab,
      label: 'Create',
      icon: Sparkles,
      activeMatches: ['create', 'generate', 'image-gen', 'image2video', 'describe', 'batch'],
    },
    {
      id: 'studio' as AppTab,
      label: 'Studio',
      icon: Clapperboard,
      activeMatches: ['studio', 'editor'],
    },
    {
      id: 'business' as AppTab,
      label: 'Business',
      icon: Briefcase,
      activeMatches: ['business'],
    },
    {
      id: 'library' as AppTab,
      label: 'Library',
      icon: PlaySquare,
      activeMatches: ['library'],
    },
    {
      id: 'profile' as AppTab,
      label: 'Profile',
      icon: User,
      activeMatches: ['profile', 'android', 'comparison'],
    },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-zinc-950/95 backdrop-blur-md border-t border-zinc-850 px-4 py-2 flex items-center justify-around">
      {navItems.map((item) => {
        const Icon = item.icon;
        const isActive = item.activeMatches.includes(currentTab);

        return (
          <button
            key={item.id}
            onClick={() => onTabChange(item.id)}
            className={`flex flex-col items-center justify-center p-1.5 transition-colors select-none ${
              isActive ? 'text-amber-400 font-extrabold' : 'text-zinc-500 hover:text-zinc-300'
            }`}
          >
            <Icon
              className={`w-5 h-5 mb-0.5 transition-transform ${
                isActive ? 'scale-110 text-amber-400 stroke-[2.5]' : 'text-zinc-500'
              }`}
            />
            <span className="text-[10px] tracking-tight">{item.label}</span>
          </button>
        );
      })}
    </nav>
  );
};
