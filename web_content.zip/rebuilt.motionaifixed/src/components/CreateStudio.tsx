import React, { useState } from 'react';
import { 
  Type, 
  Film, 
  Image as ImageIcon, 
  Layers, 
  Mic, 
  MicOff, 
  Dices, 
  Sparkles, 
  FileText, 
  Tag, 
  Edit3, 
  Briefcase, 
  Lock, 
  Zap, 
  Smartphone, 
  Tv, 
  Square,
  Check,
  Camera,
  ListOrdered,
  PlayCircle,
  Trash2,
  Plus,
  RefreshCw,
  X,
  ChevronDown,
  ChevronUp,
  Layers3,
  CheckCircle2,
  Clock,
  ArrowRight
} from 'lucide-react';
import { AspectRatio, Resolution, AppTab, BatchGenerationTask } from '../types';
import { enhancePrompt, requestVideoGeneration, generateImage } from '../services/api';
import confetti from 'canvas-confetti';

interface CreateStudioProps {
  onInsertGeneratedClip: (title: string, videoUrl: string, durationSec?: number) => void;
  onNavigateTab: (tab: AppTab) => void;
  onOpenMetaModal: () => void;
}

export const CreateStudio: React.FC<CreateStudioProps> = ({
  onInsertGeneratedClip,
  onNavigateTab,
  onOpenMetaModal,
}) => {
  // Mode selection: 'text-video' | 'image-video' | 'text-image' | 'multi-gen'
  const [activeMode, setActiveMode] = useState<'text-video' | 'image-video' | 'text-image' | 'multi-gen'>('text-video');
  const [prompt, setPrompt] = useState('');
  const [aiEnhance, setAiEnhance] = useState(true);
  const [isListening, setIsListening] = useState(false);
  const [selectedStyle, setSelectedStyle] = useState('Cinematic');
  const [outputQuality, setOutputQuality] = useState<Resolution>('1080p');
  const [duration, setDuration] = useState('30s');
  const [aspectRatio, setAspectRatio] = useState<AspectRatio>('16:9');
  const [isGenerating, setIsGenerating] = useState(false);
  const [imageFile, setImageFile] = useState<string | null>(null);

  // Camera Motion & Multi-Task Batch Queue Manager State
  const cameraOptions = [
    'Drone Zoom-In',
    'Pan Right',
    'Orbit Arc 360°',
    'FPV Flythrough',
    'Static Cinema',
    'Dolly Zoom / Vertigo',
  ];
  const [cameraMovement, setCameraMovement] = useState<string>('Drone Zoom-In');

  const [batchQueue, setBatchQueue] = useState<BatchGenerationTask[]>([
    {
      id: 'task-demo-1',
      prompt: 'Cybernetic samurai under cherry blossoms in Neo Tokyo at sunset, volumetric fog',
      resolution: '1080p',
      aspectRatio: '16:9',
      style: 'Cinematic',
      camera: 'Drone Zoom-In',
      duration: '15s',
      status: 'completed',
      progress: 100,
      resultVideoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4',
      createdAt: Date.now() - 360000,
    },
    {
      id: 'task-demo-2',
      prompt: 'Hypercar accelerating through misty mountain pass with glowing amber taillight trails',
      resolution: '4k',
      aspectRatio: '16:9',
      style: 'Hyper-Realistic',
      camera: 'Pan Right',
      duration: '10s',
      status: 'pending',
      progress: 0,
      createdAt: Date.now() - 120000,
    },
  ]);
  const [isBatchProcessing, setIsBatchProcessing] = useState(false);
  const [activeBatchTaskId, setActiveBatchTaskId] = useState<string | null>(null);
  const [showBatchDrawer, setShowBatchDrawer] = useState(true);

  // Add current settings as task into Batch Queue
  const handleAddToBatchQueue = () => {
    if (!prompt.trim()) return;
    const newTask: BatchGenerationTask = {
      id: 'task-' + Date.now(),
      prompt: prompt.trim(),
      resolution: outputQuality,
      aspectRatio: aspectRatio,
      style: selectedStyle,
      camera: cameraMovement,
      duration: duration,
      status: 'pending',
      progress: 0,
      createdAt: Date.now(),
    };
    setBatchQueue((prev) => [...prev, newTask]);
    setShowBatchDrawer(true);
    confetti({ particleCount: 35, spread: 60 });
  };

  // Run sequential batch processing
  const handleStartBatchProcessing = async () => {
    if (isBatchProcessing) return;
    setIsBatchProcessing(true);

    const pendingIds = batchQueue.filter((t) => t.status === 'pending').map((t) => t.id);

    for (const taskId of pendingIds) {
      setActiveBatchTaskId(taskId);

      // Phase 1: Initialize
      setBatchQueue((prev) =>
        prev.map((t) => (t.id === taskId ? { ...t, status: 'processing', progress: 20 } : t))
      );
      await new Promise((r) => setTimeout(r, 700));

      // Phase 2: Generating frames
      setBatchQueue((prev) =>
        prev.map((t) => (t.id === taskId ? { ...t, progress: 55 } : t))
      );
      await new Promise((r) => setTimeout(r, 800));

      // Phase 3: Neural Compositing
      setBatchQueue((prev) =>
        prev.map((t) => (t.id === taskId ? { ...t, progress: 88 } : t))
      );
      await new Promise((r) => setTimeout(r, 650));

      // Phase 4: Completed
      setBatchQueue((prev) =>
        prev.map((t) =>
          t.id === taskId
            ? {
                ...t,
                status: 'completed',
                progress: 100,
                resultVideoUrl:
                  'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4',
              }
            : t
        )
      );
    }

    setActiveBatchTaskId(null);
    setIsBatchProcessing(false);
    confetti({ particleCount: 65, spread: 80 });
  };

  const handleSendTaskToTimeline = (task: BatchGenerationTask) => {
    onInsertGeneratedClip(
      task.prompt.slice(0, 24) || 'Batch Shot',
      task.resultVideoUrl ||
        'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4',
      parseDurationToSeconds(task.duration)
    );
    confetti({ particleCount: 40, spread: 60 });
  };

  const handleSendAllCompletedToTimeline = () => {
    const completedTasks = batchQueue.filter((t) => t.status === 'completed');
    completedTasks.forEach((task) => {
      onInsertGeneratedClip(
        task.prompt.slice(0, 24) || 'Batch Shot',
        task.resultVideoUrl ||
          'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4',
        parseDurationToSeconds(task.duration)
      );
    });
    confetti({ particleCount: 80, spread: 90 });
  };

  // Sample prompt pool for the Dice button 🎲
  const promptSuggestions = [
    'A futuristic city at night with neon lights reflecting in wet rain puddles, cinematic lighting',
    'Ocean waves crashing against golden cliffs at sunset with volumetric sea spray',
    'Hypercar accelerating through misty mountain pass with glowing amber taillight trails',
    'Cybernetic samurai standing beneath blooming cherry blossoms in Neo Tokyo',
    'Deep space nebula swirling with dark gold cosmic dust and pulsar flares',
    'Cozy coffee shop interior with soft rain trickling on large glass window, warm vintage film glow',
  ];

  // Random prompt picker
  const handleRandomPrompt = () => {
    const random = promptSuggestions[Math.floor(Math.random() * promptSuggestions.length)];
    setPrompt(random);
  };

  // Speech to Text dictation
  const handleToggleMic = () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert('Speech recognition is not supported in this browser. Please type your prompt.');
      return;
    }

    if (isListening) {
      setIsListening(false);
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.lang = 'en-US';
      recognition.continuous = false;
      recognition.interimResults = false;

      recognition.onstart = () => setIsListening(true);
      recognition.onend = () => setIsListening(false);
      recognition.onerror = () => setIsListening(false);

      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setPrompt((prev) => (prev ? `${prev} ${transcript}` : transcript));
        setIsListening(false);
      };

      recognition.start();
    } catch {
      setIsListening(false);
    }
  };

  const parseDurationToSeconds = (dur: string): number => {
    if (dur.includes('min')) {
      const mins = parseInt(dur.replace(/[^0-9]/g, ''), 10) || 1;
      return mins * 60;
    }
    return parseInt(dur.replace(/[^0-9]/g, ''), 10) || 30;
  };

  // Generate Video or Image based on active mode
  const handleGenerate = async () => {
    if (!prompt.trim() || isGenerating) return;
    setIsGenerating(true);

    try {
      let finalPrompt = prompt;
      if (aiEnhance) {
        const enhanced = await enhancePrompt(prompt, 'Cinematic Tracking', selectedStyle);
        if (enhanced.enhancedPrompt) finalPrompt = enhanced.enhancedPrompt;
      }

      if (activeMode === 'text-image') {
        // Generate Image
        await generateImage(finalPrompt, aspectRatio);
        onNavigateTab('image-gen');
        confetti({ particleCount: 50, spread: 70 });
      } else {
        // Generate Video
        await requestVideoGeneration({
          prompt: finalPrompt,
          model: 'veo-3.1-lite-generate-preview',
          aspectRatio,
          resolution: outputQuality,
        });

        const durationSec = parseDurationToSeconds(duration);

        // Insert clip onto timeline & navigate
        setTimeout(() => {
          onInsertGeneratedClip(
            prompt.slice(0, 24) || 'Generated Master Shot',
            'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4',
            durationSec
          );
          setIsGenerating(false);
          confetti({ particleCount: 60, spread: 80 });
        }, 1200);
      }
    } catch {
      setIsGenerating(false);
    }
  };

  return (
    <div className="max-w-[720px] mx-auto px-4 py-4 space-y-6">
      {/* Top Mode Selector Carousel Cards (from Screenshot 1) */}
      <div className="grid grid-cols-4 gap-2 sm:gap-3">
        {/* Card 1: Text 'n Video */}
        <button
          onClick={() => setActiveMode('text-video')}
          className={`flex flex-col items-center justify-center p-3 rounded-2xl border transition-all text-center ${
            activeMode === 'text-video'
              ? 'bg-amber-500/15 border-amber-400 text-amber-300 shadow-lg shadow-amber-500/10 ring-1 ring-amber-400'
              : 'bg-zinc-900/70 border-zinc-800/80 text-zinc-400 hover:border-zinc-700 hover:text-zinc-200'
          }`}
        >
          <div
            className={`w-10 h-10 rounded-full flex items-center justify-center mb-1.5 ${
              activeMode === 'text-video' ? 'bg-amber-500 text-zinc-950 font-black' : 'bg-zinc-800 text-zinc-400'
            }`}
          >
            <span className="font-extrabold text-sm tracking-tight">Tᴛ</span>
          </div>
          <span className="text-[11px] font-bold leading-tight">Text 'n<br />Video</span>
        </button>

        {/* Card 2: Image 'n Video */}
        <button
          onClick={() => {
            setActiveMode('image-video');
            onNavigateTab('image2video');
          }}
          className={`flex flex-col items-center justify-center p-3 rounded-2xl border transition-all text-center ${
            activeMode === 'image-video'
              ? 'bg-amber-500/15 border-amber-400 text-amber-300 shadow-lg shadow-amber-500/10'
              : 'bg-zinc-900/70 border-zinc-800/80 text-zinc-400 hover:border-zinc-700 hover:text-zinc-200'
          }`}
        >
          <div className="w-10 h-10 rounded-full bg-zinc-800 flex items-center justify-center mb-1.5 text-zinc-400">
            <Film className="w-4 h-4" />
          </div>
          <span className="text-[11px] font-bold leading-tight">Image 'n<br />Video</span>
        </button>

        {/* Card 3: Text 'n Image */}
        <button
          onClick={() => setActiveMode('text-image')}
          className={`flex flex-col items-center justify-center p-3 rounded-2xl border transition-all text-center ${
            activeMode === 'text-image'
              ? 'bg-amber-500/15 border-amber-400 text-amber-300 shadow-lg shadow-amber-500/10 ring-1 ring-amber-400'
              : 'bg-zinc-900/70 border-zinc-800/80 text-zinc-400 hover:border-zinc-700 hover:text-zinc-200'
          }`}
        >
          <div
            className={`w-10 h-10 rounded-full flex items-center justify-center mb-1.5 ${
              activeMode === 'text-image' ? 'bg-amber-500 text-zinc-950 font-black' : 'bg-zinc-800 text-zinc-400'
            }`}
          >
            <ImageIcon className="w-4 h-4" />
          </div>
          <span className="text-[11px] font-bold leading-tight">Text 'n<br />Image</span>
        </button>

        {/* Card 4: Multi-Gen */}
        <button
          onClick={() => {
            setActiveMode('multi-gen');
            onNavigateTab('batch');
          }}
          className={`flex flex-col items-center justify-center p-3 rounded-2xl border transition-all text-center ${
            activeMode === 'multi-gen'
              ? 'bg-amber-500/15 border-amber-400 text-amber-300 shadow-lg shadow-amber-500/10'
              : 'bg-zinc-900/70 border-zinc-800/80 text-zinc-400 hover:border-zinc-700 hover:text-zinc-200'
          }`}
        >
          <div className="w-10 h-10 rounded-full bg-zinc-800 flex items-center justify-center mb-1.5 text-zinc-400">
            <Layers className="w-4 h-4" />
          </div>
          <span className="text-[11px] font-bold leading-tight">Multi-Gen<br />Batch</span>
        </button>
      </div>

      {/* YOUR PROMPT Section (from Screenshot 1) */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <label className="text-xs font-extrabold text-zinc-400 uppercase tracking-wider">
            YOUR PROMPT
          </label>
          <div className="flex items-center gap-2">
            <span className="text-xs text-zinc-400 font-medium">AI Enhance</span>
            <button
              onClick={() => setAiEnhance(!aiEnhance)}
              className={`w-11 h-6 flex items-center rounded-full p-1 transition-colors ${
                aiEnhance ? 'bg-amber-500' : 'bg-zinc-800'
              }`}
            >
              <div
                className={`bg-zinc-950 w-4 h-4 rounded-full shadow-md transform transition-transform ${
                  aiEnhance ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>
        </div>

        {/* Prompt Input Area with Mic & Dice Buttons */}
        <div className="relative rounded-2xl border border-amber-500/35 bg-zinc-950 p-4 shadow-xl focus-within:border-amber-400 focus-within:ring-1 focus-within:ring-amber-400 transition-all">
          <textarea
            rows={4}
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="Describe your video in detail..."
            className="w-full bg-transparent text-zinc-100 text-sm focus:outline-none resize-none placeholder:text-zinc-600 leading-relaxed pr-20"
          />

          {/* Bottom Right Floating Icons inside text box */}
          <div className="absolute right-3 bottom-3 flex items-center gap-2">
            {/* Mic Dictation */}
            <button
              onClick={handleToggleMic}
              title="Voice Dictation"
              className={`w-9 h-9 rounded-xl flex items-center justify-center border transition-all ${
                isListening
                  ? 'bg-red-500/20 border-red-500 text-red-400 animate-pulse'
                  : 'bg-zinc-900 border-zinc-800 text-amber-400 hover:text-amber-300 hover:bg-zinc-850'
              }`}
            >
              {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
            </button>

            {/* Random Dice */}
            <button
              onClick={handleRandomPrompt}
              title="Surprise Me (Random Prompt)"
              className="w-9 h-9 rounded-xl bg-zinc-900 hover:bg-zinc-850 border border-zinc-800 text-amber-400 hover:text-amber-300 flex items-center justify-center transition-colors"
            >
              <Dices className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* "Try:" Suggestion Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pt-1 scrollbar-none text-xs">
          <span className="text-zinc-500 font-semibold shrink-0">Try:</span>
          {promptSuggestions.slice(0, 3).map((item, idx) => (
            <button
              key={idx}
              onClick={() => setPrompt(item)}
              className="px-3 py-1.5 rounded-full bg-zinc-900/90 hover:bg-zinc-850 text-zinc-300 hover:text-amber-300 border border-zinc-800 whitespace-nowrap text-xs transition-colors shrink-0 max-w-[200px] truncate"
            >
              {item}
            </button>
          ))}
        </div>
      </div>

      {/* Visual Style Section (from Screenshot 1) */}
      <div className="space-y-2">
        <label className="text-xs font-extrabold text-zinc-400 uppercase tracking-wider">
          Visual Style
        </label>
        <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
          {[
            { id: 'Cinematic', icon: '🎬' },
            { id: 'Anime', icon: '✨' },
            { id: 'Realistic', icon: '🏞️' },
            { id: '3D Render', icon: '🎮' },
            { id: 'Cyberpunk', icon: '🌆' },
            { id: 'Vintage', icon: '📼' },
          ].map((st) => {
            const isSelected = selectedStyle === st.id;
            return (
              <button
                key={st.id}
                onClick={() => setSelectedStyle(st.id)}
                className={`flex items-center gap-1.5 px-4 py-2 rounded-full border text-xs font-bold whitespace-nowrap transition-all ${
                  isSelected
                    ? 'bg-amber-500 text-zinc-950 border-amber-400 shadow-md shadow-amber-500/20'
                    : 'bg-zinc-900/80 border-zinc-800 text-zinc-300 hover:border-zinc-700 hover:text-white'
                }`}
              >
                <span>{st.icon}</span>
                <span>{st.id}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* OUTPUT QUALITY Section (from Screenshot 1 & 2) */}
      <div className="space-y-2">
        <label className="text-xs font-extrabold text-zinc-400 uppercase tracking-wider">
          OUTPUT QUALITY
        </label>
        <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
          {[
            { id: '480p' as Resolution, label: '480p' },
            { id: '720p' as Resolution, label: '720p HD' },
            { id: '1080p' as Resolution, label: '1080p FHD' },
            { id: '2k' as Resolution, label: '2K QHD' },
            { id: '4k' as Resolution, label: '4K UHD' },
          ].map((res) => {
            const isSelected = outputQuality === res.id;
            return (
              <button
                key={res.id}
                onClick={() => setOutputQuality(res.id)}
                className={`px-3.5 py-2 rounded-full border text-xs font-bold whitespace-nowrap transition-all ${
                  isSelected
                    ? 'bg-amber-500/20 border-amber-400 text-amber-300 shadow-sm'
                    : 'bg-zinc-900/80 border-zinc-800 text-zinc-400 hover:text-zinc-200'
                }`}
              >
                {res.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* DURATION Section (Up to 30 minutes) */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <label className="text-xs font-extrabold text-zinc-400 uppercase tracking-wider">
            DURATION (UP TO 30 MIN)
          </label>
          <span className="text-xs font-mono font-bold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/30">
            Selected: {duration}
          </span>
        </div>
        <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
          {[
            '5s',
            '15s',
            '30s',
            '1 min',
            '3 min',
            '5 min',
            '10 min',
            '15 min',
            '20 min',
            '25 min',
            '30 min',
          ].map((dur) => {
            const isSelected = duration === dur;
            return (
              <button
                key={dur}
                onClick={() => setDuration(dur)}
                className={`px-4 py-2 rounded-full border text-xs font-bold whitespace-nowrap transition-all ${
                  isSelected
                    ? 'bg-amber-500 text-zinc-950 border-amber-400 shadow-md shadow-amber-500/20'
                    : 'bg-zinc-900/80 border-zinc-800 text-zinc-400 hover:text-zinc-200'
                }`}
              >
                {dur}
              </button>
            );
          })}
        </div>
      </div>

      {/* ASPECT RATIO Section (from Screenshot 2) */}
      <div className="space-y-2">
        <label className="text-xs font-extrabold text-zinc-400 uppercase tracking-wider">
          ASPECT RATIO
        </label>
        <div className="grid grid-cols-3 gap-2.5">
          {/* 9:16 Shorts/Reels */}
          <button
            onClick={() => setAspectRatio('9:16')}
            className={`flex items-center gap-2.5 p-3 rounded-2xl border text-left transition-all ${
              aspectRatio === '9:16'
                ? 'bg-amber-500/15 border-amber-400 text-amber-300 shadow-md shadow-amber-500/15 ring-1 ring-amber-400'
                : 'bg-zinc-900/70 border-zinc-800 text-zinc-400 hover:border-zinc-700'
            }`}
          >
            <Smartphone className="w-5 h-5 shrink-0" />
            <div className="truncate">
              <div className="font-extrabold text-xs">9:16</div>
              <div className="text-[10px] text-zinc-500 truncate">Shorts/Reels</div>
            </div>
          </button>

          {/* 16:9 YouTube/Film */}
          <button
            onClick={() => setAspectRatio('16:9')}
            className={`flex items-center gap-2.5 p-3 rounded-2xl border text-left transition-all ${
              aspectRatio === '16:9'
                ? 'bg-amber-500/15 border-amber-400 text-amber-300 shadow-md shadow-amber-500/15 ring-1 ring-amber-400'
                : 'bg-zinc-900/70 border-zinc-800 text-zinc-400 hover:border-zinc-700'
            }`}
          >
            <Tv className="w-5 h-5 shrink-0" />
            <div className="truncate">
              <div className="font-extrabold text-xs">16:9</div>
              <div className="text-[10px] text-zinc-500 truncate">YouTube/Film</div>
            </div>
          </button>

          {/* 1:1 Instagram */}
          <button
            onClick={() => setAspectRatio('1:1')}
            className={`flex items-center gap-2.5 p-3 rounded-2xl border text-left transition-all ${
              aspectRatio === '1:1'
                ? 'bg-amber-500/15 border-amber-400 text-amber-300 shadow-md shadow-amber-500/15 ring-1 ring-amber-400'
                : 'bg-zinc-900/70 border-zinc-800 text-zinc-400 hover:border-zinc-700'
            }`}
          >
            <Square className="w-5 h-5 shrink-0" />
            <div className="truncate">
              <div className="font-extrabold text-xs">1:1</div>
              <div className="text-[10px] text-zinc-500 truncate">Instagram</div>
            </div>
          </button>
        </div>
      </div>

      {/* Main Primary CTA Button (from Screenshot 2) */}
      <div className="space-y-2 pt-2">
        <button
          onClick={handleGenerate}
          disabled={isGenerating || !prompt.trim()}
          className="w-full py-4 rounded-2xl bg-gradient-to-r from-amber-500 via-yellow-500 to-amber-600 hover:from-amber-400 hover:to-yellow-400 text-zinc-950 font-black text-base shadow-xl shadow-amber-500/25 transition-all hover:scale-[1.01] active:scale-[0.99] disabled:opacity-50 flex items-center justify-center gap-2"
        >
          {isGenerating ? (
            <>
              <div className="w-5 h-5 border-2 border-zinc-950 border-t-transparent rounded-full animate-spin" />
              <span>Generating Cinematic Output...</span>
            </>
          ) : (
            <>
              <Sparkles className="w-5 h-5 fill-zinc-950" />
              <span>{activeMode === 'text-image' ? 'Generate Image' : 'Generate Video'}</span>
            </>
          )}
        </button>

        <div className="flex items-center justify-center gap-3 text-xs text-zinc-500">
          <span className="flex items-center gap-1 text-amber-400 font-semibold">
            <Zap className="w-3.5 h-3.5 fill-amber-400" /> Unlimited Credits
          </span>
          <span>·</span>
          <span className="flex items-center gap-1 text-emerald-400 font-semibold">
            <Lock className="w-3.5 h-3.5" /> Private Generation
          </span>
        </div>
      </div>

      {/* QUICK TOOLS Section (from Screenshot 2) */}
      <div className="space-y-2.5 pt-2">
        <label className="text-xs font-extrabold text-zinc-400 uppercase tracking-wider">
          QUICK TOOLS
        </label>
        <div className="grid grid-cols-4 gap-2 sm:gap-3">
          {/* Quick Tool 1: Auto Description */}
          <button
            onClick={() => onNavigateTab('describe')}
            className="flex flex-col items-center justify-center p-3 rounded-2xl bg-zinc-900/60 border border-zinc-800 hover:border-amber-500/40 text-center transition-colors group"
          >
            <div className="w-11 h-11 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 mb-1.5 group-hover:scale-105 transition-transform">
              <FileText className="w-5 h-5" />
            </div>
            <span className="text-[11px] font-bold text-zinc-300 leading-tight">
              Auto<br />Description
            </span>
          </button>

          {/* Quick Tool 2: Meta Tags */}
          <button
            onClick={onOpenMetaModal}
            className="flex flex-col items-center justify-center p-3 rounded-2xl bg-zinc-900/60 border border-zinc-800 hover:border-amber-500/40 text-center transition-colors group"
          >
            <div className="w-11 h-11 rounded-2xl bg-purple-500/10 border border-purple-500/30 flex items-center justify-center text-purple-400 mb-1.5 group-hover:scale-105 transition-transform">
              <Tag className="w-5 h-5" />
            </div>
            <span className="text-[11px] font-bold text-zinc-300 leading-tight">
              Meta<br />Tags
            </span>
          </button>

          {/* Quick Tool 3: Video Editor (CapCut) */}
          <button
            onClick={() => onNavigateTab('studio')}
            className="flex flex-col items-center justify-center p-3 rounded-2xl bg-zinc-900/60 border border-zinc-800 hover:border-amber-500/40 text-center transition-colors group"
          >
            <div className="w-11 h-11 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 mb-1.5 group-hover:scale-105 transition-transform">
              <Edit3 className="w-5 h-5" />
            </div>
            <span className="text-[11px] font-bold text-zinc-300 leading-tight">
              Video<br />Editor
            </span>
          </button>

          {/* Quick Tool 4: Marketing Generator */}
          <button
            onClick={() => onNavigateTab('business')}
            className="flex flex-col items-center justify-center p-3 rounded-2xl bg-zinc-900/60 border border-zinc-800 hover:border-amber-500/40 text-center transition-colors group"
          >
            <div className="w-11 h-11 rounded-2xl bg-orange-500/10 border border-orange-500/30 flex items-center justify-center text-orange-400 mb-1.5 group-hover:scale-105 transition-transform">
              <Briefcase className="w-5 h-5" />
            </div>
            <span className="text-[11px] font-bold text-zinc-300 leading-tight">
              Marketing
            </span>
          </button>
        </div>
      </div>
    </div>
  );
};
