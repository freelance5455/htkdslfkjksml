import React, { useState } from 'react';
import { LibraryAsset } from '../types';
import { 
  FolderOpen, 
  Film, 
  Image as ImageIcon, 
  Music, 
  Layers, 
  Download, 
  Plus, 
  Trash2, 
  Search, 
  Play, 
  ExternalLink 
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface LibraryStudioProps {
  onInsertAssetToEditor: (name: string, url: string, type: 'video' | 'audio' | 'image') => void;
  onNavigateToEditor: () => void;
}

export const LibraryStudio: React.FC<LibraryStudioProps> = ({
  onInsertAssetToEditor,
  onNavigateToEditor,
}) => {
  const [activeFilter, setActiveFilter] = useState<'all' | 'video' | 'image' | 'audio' | 'project'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [previewAsset, setPreviewAsset] = useState<LibraryAsset | null>(null);

  const [assets, setAssets] = useState<LibraryAsset[]>([
    {
      id: 'lib-1',
      name: 'Cyberpunk Metropolis 4K Master',
      type: 'video',
      url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4',
      thumbnail: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=300&q=80',
      duration: 12,
      size: '24.5 MB',
      createdAt: Date.now() - 3600000,
      tags: ['4K', 'Cyberpunk', 'Veo 3.1'],
    },
    {
      id: 'lib-2',
      name: 'Desert Dunes Drone Orbit',
      type: 'video',
      url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
      thumbnail: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=300&q=80',
      duration: 15,
      size: '18.2 MB',
      createdAt: Date.now() - 7200000,
      tags: ['Drone', 'Golden Hour', '1080p'],
    },
    {
      id: 'lib-3',
      name: 'Hypercar Mountain Drift',
      type: 'video',
      url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WeAreGoingOnBullrun.mp4',
      thumbnail: 'https://images.unsplash.com/photo-1542282088-72c9c27ed0cd?w=300&q=80',
      duration: 10,
      size: '14.8 MB',
      createdAt: Date.now() - 14400000,
      tags: ['Action', 'Vehicle', 'Tracking'],
    },
    {
      id: 'lib-4',
      name: 'Lotus Blossom Obsidian Keyframe',
      type: 'image',
      url: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=800&q=80',
      thumbnail: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=300&q=80',
      size: '3.4 MB',
      createdAt: Date.now() - 18000000,
      tags: ['Keyframe', 'Gemini 3.1', '16:9'],
    },
    {
      id: 'lib-5',
      name: 'Deep Space Nebula Cluster',
      type: 'image',
      url: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=800&q=80',
      thumbnail: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=300&q=80',
      size: '4.1 MB',
      createdAt: Date.now() - 21600000,
      tags: ['Space', 'Sci-Fi'],
    },
    {
      id: 'lib-6',
      name: 'Epic Orchestral Bed Score',
      type: 'audio',
      url: 'https://cdn.freesound.org/previews/467/467882_9875087-lq.mp3',
      duration: 30,
      size: '5.2 MB',
      createdAt: Date.now() - 28800000,
      tags: ['Cinematic', 'Soundtrack', 'Master'],
    },
  ]);

  const filteredAssets = assets.filter((a) => {
    const matchesFilter = activeFilter === 'all' || a.type === activeFilter;
    const matchesSearch =
      a.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      a.tags.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesFilter && matchesSearch;
  });

  const handleDelete = (id: string) => {
    setAssets(assets.filter((a) => a.id !== id));
  };

  return (
    <div className="max-w-[1440px] mx-auto p-4 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-zinc-800">
        <div>
          <div className="flex items-center gap-2">
            <FolderOpen className="w-5 h-5 text-amber-400" />
            <h2 className="text-xl font-extrabold text-zinc-100">Asset & Media Library</h2>
          </div>
          <p className="text-xs text-zinc-400 mt-1">
            Central repository for generated videos, synthesized images, audio tracks, and saved edit reels.
          </p>
        </div>

        <button
          onClick={onNavigateToEditor}
          className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-zinc-900 hover:bg-zinc-850 text-amber-400 border border-amber-500/30 text-xs font-bold transition-colors"
        >
          <Film className="w-3.5 h-3.5" />
          <span>Open CapCut Editor</span>
        </button>
      </div>

      {/* Filter Tabs & Search Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
        {/* Category Filters */}
        <div className="flex items-center gap-1 bg-zinc-900/80 p-1 rounded-xl border border-zinc-800 w-full sm:w-auto overflow-x-auto">
          {[
            { id: 'all', label: 'All Media' },
            { id: 'video', label: 'Videos' },
            { id: 'image', label: 'Images' },
            { id: 'audio', label: 'Audio Tracks' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveFilter(tab.id as any)}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all whitespace-nowrap ${
                activeFilter === tab.id
                  ? 'bg-amber-500 text-zinc-950 shadow-sm'
                  : 'text-zinc-400 hover:text-amber-300'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Search Bar */}
        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-zinc-500 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search assets by tag or name..."
            className="w-full pl-9 pr-3.5 py-2 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-200 text-xs focus:border-amber-500 focus:outline-none"
          />
        </div>
      </div>

      {/* Assets Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredAssets.map((asset) => (
          <div
            key={asset.id}
            className="bg-zinc-950 border border-zinc-800/80 hover:border-amber-500/40 rounded-2xl p-4 shadow-xl flex flex-col justify-between transition-colors space-y-3 group"
          >
            {/* Asset Preview Thumbnail */}
            <div
              onClick={() => setPreviewAsset(asset)}
              className="relative aspect-video rounded-xl overflow-hidden bg-black border border-zinc-800 cursor-pointer flex items-center justify-center"
            >
              {asset.thumbnail ? (
                <img src={asset.thumbnail} alt="" className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
              ) : asset.type === 'audio' ? (
                <div className="w-full h-full bg-gradient-to-br from-emerald-950/60 to-zinc-900 flex flex-col items-center justify-center gap-2">
                  <Music className="w-8 h-8 text-emerald-400" />
                  <span className="text-[11px] font-mono text-emerald-300">{asset.duration}s</span>
                </div>
              ) : null}

              {asset.type === 'video' && (
                <div className="absolute inset-0 bg-black/30 flex items-center justify-center opacity-80 group-hover:opacity-100 transition-opacity">
                  <div className="w-9 h-9 rounded-full bg-amber-500 text-zinc-950 flex items-center justify-center font-bold shadow-lg shadow-amber-500/30">
                    <Play className="w-4 h-4 fill-zinc-950 translate-x-0.5" />
                  </div>
                </div>
              )}

              {asset.duration && (
                <span className="absolute bottom-2 right-2 px-1.5 py-0.5 rounded bg-black/80 font-mono text-[10px] text-zinc-300">
                  {asset.duration}s
                </span>
              )}
            </div>

            {/* Details */}
            <div>
              <div className="flex items-center justify-between">
                <span className="font-bold text-xs text-zinc-200 truncate">{asset.name}</span>
                <span className="text-[10px] font-mono text-zinc-500">{asset.size}</span>
              </div>

              <div className="flex flex-wrap gap-1 mt-2">
                {asset.tags.map((t, idx) => (
                  <span
                    key={idx}
                    className="px-1.5 py-0.5 rounded bg-zinc-900 text-zinc-400 border border-zinc-800 text-[10px]"
                  >
                    {t}
                  </span>
                ))}
              </div>
            </div>

            {/* Actions */}
            <div className="flex items-center gap-2 pt-2 border-t border-zinc-850">
              <button
                onClick={() => {
                  onInsertAssetToEditor(asset.name, asset.url, asset.type as any);
                  confetti({ particleCount: 30, spread: 50 });
                }}
                className="flex-1 py-1.5 rounded-lg bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 border border-amber-500/40 text-xs font-bold flex items-center justify-center gap-1.5 transition-colors"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Send to Timeline</span>
              </button>

              <a
                href={asset.url}
                download={asset.name}
                className="p-1.5 rounded-lg bg-zinc-900 hover:bg-zinc-850 text-zinc-400 hover:text-zinc-200 border border-zinc-800 transition-colors"
                title="Download File"
              >
                <Download className="w-3.5 h-3.5" />
              </a>

              <button
                onClick={() => handleDelete(asset.id)}
                className="p-1.5 rounded-lg bg-zinc-900 hover:bg-red-950/40 text-zinc-500 hover:text-red-400 border border-zinc-800 hover:border-red-500/30 transition-colors"
                title="Delete Asset"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Asset Preview Modal */}
      {previewAsset && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in duration-150">
          <div className="relative w-full max-w-2xl bg-zinc-950 border border-amber-500/40 rounded-2xl p-6 shadow-2xl space-y-4">
            <div className="flex justify-between items-center pb-2 border-b border-zinc-800">
              <h3 className="font-extrabold text-sm text-zinc-100">{previewAsset.name}</h3>
              <button
                onClick={() => setPreviewAsset(null)}
                className="text-zinc-400 hover:text-zinc-200 font-bold text-xs"
              >
                ✕ Close
              </button>
            </div>

            <div className="aspect-video bg-black rounded-xl overflow-hidden border border-zinc-850 flex items-center justify-center">
              {previewAsset.type === 'video' ? (
                <video src={previewAsset.url} controls autoPlay className="w-full h-full object-contain" />
              ) : previewAsset.type === 'image' ? (
                <img src={previewAsset.url} alt="" className="w-full h-full object-contain" />
              ) : (
                <audio src={previewAsset.url} controls autoPlay className="w-4/5" />
              )}
            </div>

            <button
              onClick={() => {
                onInsertAssetToEditor(previewAsset.name, previewAsset.url, previewAsset.type as any);
                setPreviewAsset(null);
                onNavigateToEditor();
              }}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-amber-400 hover:to-yellow-500 text-zinc-950 font-bold text-xs shadow-md shadow-amber-500/20 transition-all"
            >
              Insert into CapCut Timeline
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
