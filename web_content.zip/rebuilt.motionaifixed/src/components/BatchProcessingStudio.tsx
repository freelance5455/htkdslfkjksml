import React, { useState } from 'react';
import { Layers, Plus, Trash2, Play, CheckCircle2, Film } from 'lucide-react';
import confetti from 'canvas-confetti';

interface BatchItem {
  id: string;
  prompt: string;
  resolution: string;
  status: 'pending' | 'rendering' | 'ready';
  progress: number;
}

interface BatchProcessingStudioProps {
  onInsertClip: (title: string, url: string) => void;
  onNavigateToEditor: () => void;
}

export const BatchProcessingStudio: React.FC<BatchProcessingStudioProps> = ({
  onInsertClip,
  onNavigateToEditor,
}) => {
  const [items, setItems] = useState<BatchItem[]>([
    {
      id: 'batch-1',
      prompt: 'Cyberpunk rainy rooftop neon tracking shot with amber light reflections',
      resolution: '1080p',
      status: 'ready',
      progress: 100,
    },
    {
      id: 'batch-2',
      prompt: 'Golden hour drone orbit over ancient desert sandstone ruins',
      resolution: '1080p',
      status: 'pending',
      progress: 0,
    },
    {
      id: 'batch-3',
      prompt: 'Futuristic hypercar interior POV with glowing holographic speedometer',
      resolution: '4k',
      status: 'pending',
      progress: 0,
    },
  ]);
  const [newPrompt, setNewPrompt] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);

  const handleAddItem = () => {
    if (!newPrompt.trim()) return;
    setItems([
      ...items,
      {
        id: 'batch-' + Date.now(),
        prompt: newPrompt,
        resolution: '1080p',
        status: 'pending',
        progress: 0,
      },
    ]);
    setNewPrompt('');
  };

  const handleRunAll = () => {
    setIsProcessing(true);
    let currentIdx = 0;
    const interval = setInterval(() => {
      setItems((prev) => {
        const next = [...prev];
        const pendingItem = next.find((i) => i.status === 'pending');
        if (pendingItem) {
          pendingItem.status = 'rendering';
          pendingItem.progress = 50;
        } else {
          const renderingItem = next.find((i) => i.status === 'rendering');
          if (renderingItem) {
            renderingItem.status = 'ready';
            renderingItem.progress = 100;
          } else {
            clearInterval(interval);
            setIsProcessing(false);
            confetti({ particleCount: 50, spread: 70 });
          }
        }
        return next;
      });
    }, 1200);
  };

  return (
    <div className="max-w-[1200px] mx-auto p-4 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-zinc-800">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-extrabold text-zinc-100">Multi-Task Batch Queue Studio</h2>
            <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-amber-500/10 text-amber-400 border border-amber-500/30">
              Parallel Pipelines
            </span>
          </div>
          <p className="text-xs text-zinc-400 mt-1">
            Queue multiple video shots and render them concurrently for long-form sequence generation.
          </p>
        </div>

        <button
          onClick={onNavigateToEditor}
          className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-zinc-900 hover:bg-zinc-850 text-amber-400 border border-amber-500/30 text-xs font-bold transition-colors"
        >
          <Film className="w-3.5 h-3.5" />
          <span>Timeline View</span>
        </button>
      </div>

      {/* Add New Batch Task */}
      <div className="bg-zinc-950 border border-zinc-800/80 rounded-2xl p-4 shadow-xl flex gap-3">
        <input
          type="text"
          value={newPrompt}
          onChange={(e) => setNewPrompt(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleAddItem()}
          placeholder="Type shot prompt to add to the batch render queue..."
          className="flex-1 px-3.5 py-2.5 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-100 text-xs focus:border-amber-500 focus:outline-none"
        />
        <button
          onClick={handleAddItem}
          className="px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold text-xs flex items-center gap-1.5 shrink-0 transition-colors"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Add to Queue</span>
        </button>
      </div>

      {/* Queue Table */}
      <div className="bg-zinc-950 border border-zinc-800/80 rounded-2xl overflow-hidden shadow-xl">
        <div className="flex items-center justify-between p-4 border-b border-zinc-800 bg-zinc-900/60">
          <span className="text-xs font-bold text-zinc-200 uppercase tracking-wider">
            Queue Items ({items.length})
          </span>
          <button
            onClick={handleRunAll}
            disabled={isProcessing}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-amber-400 hover:to-yellow-500 text-zinc-950 font-bold text-xs disabled:opacity-50 transition-all shadow-md shadow-amber-500/20"
          >
            <Play className="w-3 h-3 fill-zinc-950" />
            <span>{isProcessing ? 'Processing Queue...' : 'Render All Batches'}</span>
          </button>
        </div>

        <div className="divide-y divide-zinc-850">
          {items.map((item, idx) => (
            <div key={item.id} className="p-4 flex items-center justify-between gap-4 text-xs">
              <div className="flex items-center gap-3 flex-1 min-w-0">
                <span className="font-mono text-zinc-500 text-xs font-bold">#{idx + 1}</span>
                <div className="truncate">
                  <div className="font-bold text-zinc-200 truncate">{item.prompt}</div>
                  <div className="text-[11px] text-zinc-400 mt-0.5">
                    Target: <span className="text-amber-400">{item.resolution}</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-3 shrink-0">
                <span
                  className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                    item.status === 'ready'
                      ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                      : item.status === 'rendering'
                      ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30 animate-pulse'
                      : 'bg-zinc-800 text-zinc-400'
                  }`}
                >
                  {item.status.toUpperCase()}
                </span>

                {item.status === 'ready' && (
                  <button
                    onClick={() =>
                      onInsertClip(
                        item.prompt.slice(0, 20),
                        'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4'
                      )
                    }
                    className="flex items-center gap-1 px-2.5 py-1 rounded bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 font-bold"
                  >
                    <Plus className="w-3 h-3" />
                    <span>Send to Timeline</span>
                  </button>
                )}

                <button
                  onClick={() => setItems(items.filter((i) => i.id !== item.id))}
                  className="p-1 rounded text-zinc-500 hover:text-red-400 transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
