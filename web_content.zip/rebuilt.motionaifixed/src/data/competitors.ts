import { CompetitorComparison } from '../types';

export const COMPETITOR_ANALYSIS: CompetitorComparison[] = [
  {
    platform: 'RunwayML (Gen-3 Alpha)',
    category: 'Hollywood VFX & GenAI',
    tagline: 'High cinematic realism with custom motion brush and camera control',
    strengths: [
      'Very high visual fidelity and photorealism in Gen-3 Alpha',
      'Motion Brush for regional velocity control',
      'Advanced text-to-video prompt adherence',
      'Director mode with zoom, pan, tilt vectors'
    ],
    weaknesses: [
      'Exorbitant credit consumption (~10 credits/second)',
      'No multi-track timeline video editor inside the web app',
      'No simultaneous audio manipulation, waveforms, or transition SFX',
      'Requires separate NLE software (Premiere/CapCut) for final delivery',
      'Watermarked on standard tiers, restrictive paywalls'
    ],
    missingGaps: [
      'Built-in post-production NLE (transitions, multi-track audio, color grading)',
      'Native offline/PWA mobile app capabilities for field editors',
      'Precise split-second trimming and clip snapping on a visual ruler',
      'Integrated AI voiceover synthesis alongside background music ducking'
    ],
    motionaiAdvantage: 'Motionai integrates a full CapCut-grade multi-track video editor directly in the browser with transitions, color grading, audio ducking, and standalone iOS/Android installations.',
    maxDuration: '10 seconds / generation',
    resolution: 'Up to 1080p (Gen-3)',
    promptLimits: 'Strict safety filters, 500 chars',
    creditModel: 'High-cost subscription ($15–$95/mo)',
    multiTrackEditor: false,
    cameraMotionControls: true,
    offlineStandaloneApp: false,
    watermarkFree: false
  },
  {
    platform: 'Pika Labs (Pika 2.0)',
    category: 'Creative Effects & Physics',
    tagline: 'Pikaffects (Melt, Inflate, Crush) and lip sync for viral social clips',
    strengths: [
      'Fun physics-based effects (Pikaffects: explode, squish, melt)',
      'Lip-sync audio synchronization for generated avatars',
      'Easy 16:9 / 9:16 aspect ratio switching',
      'Active Discord and web community'
    ],
    weaknesses: [
      'Lacks multi-layer video tracks (no PiP or secondary B-roll)',
      'No color grading or LUT adjustments (temperature, tint, vignette)',
      'Cannot trim or split multiple clips on a chronological playhead',
      'Frequent motion blur artifacts on complex humanoid movement'
    ],
    missingGaps: [
      'Kinetic text overlay engine with custom typography and shadow boxes',
      'Multi-track audio lanes with sound effect cue syncing',
      'Export directly to standalone mobile applications without app store constraints'
    ],
    motionaiAdvantage: 'Motionai provides comprehensive color grading sliders, kinetic text overlays, customizable transition whooshes, and picture-in-picture video lanes.',
    maxDuration: '4 seconds (extendable to 12s)',
    resolution: '720p / 1080p',
    promptLimits: 'Short prompts favored',
    creditModel: 'Monthly quota system ($10–$60/mo)',
    multiTrackEditor: false,
    cameraMotionControls: true,
    offlineStandaloneApp: false,
    watermarkFree: false
  },
  {
    platform: 'Synthesys',
    category: 'Corporate Avatar & Voiceover',
    tagline: 'AI presenters and synthetic voiceover for corporate training and marketing',
    strengths: [
      'Extensive library of human AI avatars and presenters',
      'High-quality multi-language text-to-speech voiceovers',
      'Straightforward slide-deck video creation workflow'
    ],
    weaknesses: [
      'Rigid avatar presentations without dynamic cinematic camera motion',
      'No cinematic lighting, volumetric haze, or film grain controls',
      'Primitive single-track editor with no clip splitting or keyframe transforms',
      'Slow render times for 1080p presentations'
    ],
    missingGaps: [
      'Cinematic text-to-video / image-to-video generation engines',
      'Real-time timeline scrubbing with live transition preview',
      'Dark gold luxury aesthetic and pro film grading'
    ],
    motionaiAdvantage: 'Motionai brings cinematic Hollywood camera angles, dynamic transitions with synchronized audio cues, and instant timeline scrubbing.',
    maxDuration: 'Varies by slide count',
    resolution: '1080p',
    promptLimits: 'Script-based (voice text)',
    creditModel: 'Enterprise pricing ($29–$299/mo)',
    multiTrackEditor: false,
    cameraMotionControls: false,
    offlineStandaloneApp: false,
    watermarkFree: true
  },
  {
    platform: 'Luma Dream Machine',
    category: '3D World Simulation & Camera Rig',
    tagline: 'High-speed cinematic camera pans and 3D environment consistency',
    strengths: [
      'Fast 120-second generation queues',
      'Strong 3D spatial awareness and camera motion',
      'Keyframe end-frame morphing between two images'
    ],
    weaknesses: [
      'Zero in-app audio editing (generates purely silent videos)',
      'No subtitle or text overlay editing',
      'No ability to assemble multiple clips into a continuous film reel',
      'Limited resolution settings without enterprise tier'
    ],
    missingGaps: [
      'All post-production capabilities (audio, transitions, titles, filters)',
      'Batch processing and queue prioritization'
    ],
    motionaiAdvantage: 'Motionai solves the silent video limitation with multi-track audio mixing, background soundtrack support, sound FX library, and AI voiceover narration.',
    maxDuration: '5 seconds',
    resolution: '720p',
    promptLimits: 'Text prompt only',
    creditModel: 'Credits per generation',
    multiTrackEditor: false,
    cameraMotionControls: true,
    offlineStandaloneApp: false,
    watermarkFree: false
  },
  {
    platform: 'Kling AI',
    category: 'Realistic Physical Simulation',
    tagline: 'Up to 2-minute video generation with realistic human anatomy movement',
    strengths: [
      'Extended video duration (up to 2 minutes with extensions)',
      'Superior physics simulation for fluid and cloth simulation',
      'High-definition 1080p generation'
    ],
    weaknesses: [
      'Long rendering queues (often 10–30 minutes per clip)',
      'No in-browser timeline editing or transition controls',
      'Complicated international sign-up flow and payment gates'
    ],
    missingGaps: [
      'Instant editing response, real-time scrubbing, and audio layering'
    ],
    motionaiAdvantage: 'Motionai combines rapid generation with immediate multi-track timeline assembly, letting you cut, trim, grade, and overlay captions in seconds.',
    maxDuration: 'Up to 2 minutes',
    resolution: '1080p',
    promptLimits: 'Standard prompt box',
    creditModel: 'Subscription credits',
    multiTrackEditor: false,
    cameraMotionControls: true,
    offlineStandaloneApp: false,
    watermarkFree: false
  },
  {
    platform: 'Motionai (This App)',
    category: 'All-in-One Studio + CapCut Pro NLE',
    tagline: 'Hollywood Veo generation combined with a professional CapCut-grade multi-track editor and mobile export',
    strengths: [
      'Complete CapCut-grade multi-track video editor (Main Video, PiP, Audio, SFX, Voiceover, Text, Filters)',
      'Cinematic transitions (Cross Dissolve, Whip Pan, Zoom, Flash, Glitch, Burn) with auto WebAudio sound cues',
      'Full Color Grading engine (Exposure, Contrast, Warmth, Tint, Saturation, Vignette, Sharpness)',
      'Text overlay and dynamic animated lower-thirds with dark gold styling',
      'Multi-track audio manipulation with volume, fading, ducking, and AI voiceover',
      'Dual standalone mobile downloads: Dedicated iOS file + Dedicated Android file + Single install file',
      'Real-time prompt enhancer with Gemini 3.8 Flash and Image-to-Video camera vectors'
    ],
    weaknesses: [
      'GPU rendering in browser depends on client hardware for 4K video composite export'
    ],
    missingGaps: [
      'None — addresses every gap identified across Runway, Pika, Synthesys, Luma, and Kling!'
    ],
    motionaiAdvantage: 'The unified creative hub: eliminates the fragmented workflow between AI generation tools and desktop video editing suites.',
    maxDuration: 'Unlimited sequence duration on timeline',
    resolution: '720p / 1080p / 4K',
    promptLimits: 'Intelligent Gemini 3.8 Flash expansion',
    creditModel: 'Integrated Studio with offline and local export capabilities',
    multiTrackEditor: true,
    cameraMotionControls: true,
    offlineStandaloneApp: true,
    watermarkFree: true
  }
];
