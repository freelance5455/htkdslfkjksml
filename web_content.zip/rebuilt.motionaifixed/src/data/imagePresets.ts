export interface ImageStylePreset {
  id: string;
  name: string;
  description: string;
  promptSuffix: string;
  previewUrl: string;
}

export const IMAGE_STYLES: ImageStylePreset[] = [
  {
    id: 'cinematic-gold',
    name: 'Cinematic Dark Gold',
    description: '35mm anamorphic prime lens with volumetric golden amber lighting',
    promptSuffix: 'cinematic lighting, warm dark gold rim lights, 35mm anamorphic, volumetric haze, 8k resolution, photorealistic masterpiece',
    previewUrl: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=300&q=80',
  },
  {
    id: 'photorealistic',
    name: 'Hyper-Photorealistic 8K',
    description: 'National Geographic level detail with crisp depth of field',
    promptSuffix: 'ultra-detailed photorealistic, shot on Hasselblad H6D-100c, 100mm f/2.8 lens, natural golden hour lighting, 8k uhd',
    previewUrl: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=300&q=80',
  },
  {
    id: 'cyberpunk',
    name: 'Cyberpunk Neon',
    description: 'Futuristic high-tech cityscape with vivid magenta and amber reflections',
    promptSuffix: 'cyberpunk aesthetic, high-tech metropolis, neon holographic signage, wet reflective streets, ray-traced shadows',
    previewUrl: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=300&q=80',
  },
  {
    id: 'anime-concept',
    name: 'Anime Concept Art',
    description: 'Makoto Shinkai style animated atmosphere with dramatic clouds and lighting',
    promptSuffix: 'Makoto Shinkai anime style, breathtaking sky, detailed background painting, vibrant color palette, ethereal golden light',
    previewUrl: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?w=300&q=80',
  },
  {
    id: '3d-render',
    name: 'Octane 3D Render',
    description: 'Unreal Engine 5 architectural and spatial render with subsurface scattering',
    promptSuffix: 'Unreal Engine 5, Octane render, physical materials, ray-tracing, photorealistic architectural composition, clean minimalism',
    previewUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=300&q=80',
  },
  {
    id: 'vintage-film',
    name: 'Vintage 1970s Kodachrome',
    description: 'Retro analog film grain with warm color nostalgia',
    promptSuffix: 'shot on 35mm Kodachrome 64, analog film grain, vintage color bleed, 1970s cinema aesthetic, authentic patina',
    previewUrl: 'https://images.unsplash.com/photo-1514565131-fce0801e5785?w=300&q=80',
  },
];

export const LIGHTING_PRESETS = [
  'Volumetric Dark Gold Rays',
  'Golden Hour Sunset Radiance',
  'Cyberpunk Neon Rim Lights',
  'Moody Dramatic Chiaroscuro',
  'Soft Diffused Studio Softbox',
  'Ethereal Bioluminescence',
];
