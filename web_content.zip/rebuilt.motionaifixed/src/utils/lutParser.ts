import { CustomLut, ColorGradeSettings } from '../types';

const STORAGE_KEY = 'motionai_custom_luts';

// Pre-seeded Hollywood .cube profiles stored initially in the internal storage
const DEFAULT_PRESET_LUTS: CustomLut[] = [
  {
    id: 'lut-kodak-5219',
    name: 'Kodak Vision3 5219 Film',
    fileName: 'Kodak_Vision3_5219_35mm.cube',
    fileSize: 42100,
    uploadedAt: Date.now() - 86400000 * 3,
    title: 'Kodak Vision3 5219 35mm Cinema Stock',
    size3D: 33,
    description: 'Iconic warm 35mm Hollywood film stock with rich golden halation and deep emerald shadows.',
    previewGradient: 'linear-gradient(135deg, #1e293b 0%, #b45309 50%, #fef08a 100%)',
    cssFilter: 'contrast(1.18) saturate(1.15) sepia(0.22) hue-rotate(-6deg) brightness(1.02)',
    colorGradePreset: {
      exposure: 2,
      contrast: 16,
      saturation: 115,
      temperature: 22,
      tint: -4,
      vignette: 18,
      sharpness: 12,
    },
    cubeRawData: `# Kodak Vision3 5219 35mm Print Emulation
TITLE "Kodak Vision3 5219"
LUT_3D_SIZE 33
DOMAIN_MIN 0.0 0.0 0.0
DOMAIN_MAX 1.0 1.0 1.0
# [Sample 3D Lattice Data]
`,
  },
  {
    id: 'lut-teal-orange',
    name: 'Teal & Orange Blockbuster V2',
    fileName: 'Teal_Orange_Blockbuster_V2.cube',
    fileSize: 38400,
    uploadedAt: Date.now() - 86400000 * 2,
    title: 'Teal & Orange Blockbuster Grade',
    size3D: 33,
    description: 'High-contrast commercial look with cyan-teal shadows and warm amber skin tones.',
    previewGradient: 'linear-gradient(135deg, #0f766e 0%, #0369a1 40%, #ea580c 100%)',
    cssFilter: 'contrast(1.25) saturate(1.22) hue-rotate(-12deg) sepia(0.18)',
    colorGradePreset: {
      exposure: 0,
      contrast: 24,
      saturation: 122,
      temperature: 15,
      tint: -12,
      vignette: 24,
      sharpness: 15,
    },
    cubeRawData: `# Teal and Orange Blockbuster Commercial
TITLE "Teal & Orange Blockbuster V2"
LUT_3D_SIZE 33
DOMAIN_MIN 0.0 0.0 0.0
DOMAIN_MAX 1.0 1.0 1.0
`,
  },
  {
    id: 'lut-alexa-logc',
    name: 'ARRI Alexa LogC to Rec.709',
    fileName: 'ARRI_LogC_Rec709_Gold.cube',
    fileSize: 45000,
    uploadedAt: Date.now() - 86400000 * 1,
    title: 'ARRI Alexa Wide Dynamic Rec.709',
    size3D: 33,
    description: 'Industry-standard organic filmic tone curve with smooth highlight rolloff and neutral blacks.',
    previewGradient: 'linear-gradient(135deg, #18181b 0%, #71717a 50%, #f59e0b 100%)',
    cssFilter: 'contrast(1.12) saturate(1.08) brightness(1.01)',
    colorGradePreset: {
      exposure: 4,
      contrast: 12,
      saturation: 108,
      temperature: 8,
      tint: 0,
      vignette: 10,
      sharpness: 8,
    },
    cubeRawData: `# ARRI Alexa LogC Rec.709 Standard
TITLE "ARRI Alexa LogC to Rec.709"
LUT_3D_SIZE 33
DOMAIN_MIN 0.0 0.0 0.0
DOMAIN_MAX 1.0 1.0 1.0
`,
  },
  {
    id: 'lut-dark-gold',
    name: 'Dark Gold Commercial Luxury',
    fileName: 'Dark_Gold_Commercial_33.cube',
    fileSize: 41200,
    uploadedAt: Date.now() - 3600000 * 5,
    title: 'Dark Gold Signature Luxury Aesthetic',
    size3D: 33,
    description: 'Deep obsidian blacks with radiant warm gold specular highlights for high-end luxury showcases.',
    previewGradient: 'linear-gradient(135deg, #09090b 0%, #78350f 45%, #fbbf24 100%)',
    cssFilter: 'contrast(1.22) saturate(1.18) sepia(0.28) hue-rotate(-8deg) brightness(0.98)',
    colorGradePreset: {
      exposure: -2,
      contrast: 22,
      saturation: 118,
      temperature: 28,
      tint: -2,
      vignette: 30,
      sharpness: 20,
    },
    cubeRawData: `# Dark Gold Commercial Luxury Edition
TITLE "Dark Gold Commercial Luxury"
LUT_3D_SIZE 33
DOMAIN_MIN 0.0 0.0 0.0
DOMAIN_MAX 1.0 1.0 1.0
`,
  },
  {
    id: 'lut-fuji-eterna',
    name: 'Fujifilm Eterna 250D',
    fileName: 'Fuji_Eterna_250D_Filmic.cube',
    fileSize: 39500,
    uploadedAt: Date.now() - 3600000 * 2,
    title: 'Fujifilm Eterna 250D Soft Film',
    size3D: 33,
    description: 'Subtle desaturated pastels, soft shadow rolloff, and cinematic indie drama aesthetic.',
    previewGradient: 'linear-gradient(135deg, #1e293b 0%, #475569 50%, #cbd5e1 100%)',
    cssFilter: 'contrast(1.06) saturate(0.92) brightness(1.02) sepia(0.08)',
    colorGradePreset: {
      exposure: 2,
      contrast: 8,
      saturation: 92,
      temperature: 4,
      tint: 2,
      vignette: 14,
      sharpness: 6,
    },
    cubeRawData: `# Fujifilm Eterna 250D Soft Print
TITLE "Fujifilm Eterna 250D"
LUT_3D_SIZE 33
DOMAIN_MIN 0.0 0.0 0.0
DOMAIN_MAX 1.0 1.0 1.0
`,
  }
];

/**
 * Load all custom LUTs from internal storage (localStorage), seeding with defaults if empty.
 */
export function loadCustomLutsFromStorage(): CustomLut[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(DEFAULT_PRESET_LUTS));
      return DEFAULT_PRESET_LUTS;
    }
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed) && parsed.length > 0) {
      return parsed;
    }
    return DEFAULT_PRESET_LUTS;
  } catch (err) {
    console.warn('Failed to load custom LUTs from storage, falling back to defaults:', err);
    return DEFAULT_PRESET_LUTS;
  }
}

/**
 * Save array of custom LUTs to internal storage.
 */
export function saveCustomLutsToStorage(luts: CustomLut[]): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(luts));
  } catch (err) {
    console.error('Failed to save custom LUTs to storage:', err);
  }
}

/**
 * Parse an uploaded .cube file string into structured metadata and synthesized CSS filter.
 */
export function parseCubeFileContent(content: string, fileName: string): CustomLut {
  const lines = content.split(/\r?\n/);
  let title = fileName.replace(/\.[^/.]+$/, '').replace(/[-_]/g, ' ');
  let size3D = 33;
  const rgbSamples: [number, number, number][] = [];

  for (const rawLine of lines) {
    const line = rawLine.trim();
    if (!line || line.startsWith('#')) {
      continue;
    }

    if (line.startsWith('TITLE')) {
      const match = line.match(/TITLE\s+"?([^"]+)"?/i);
      if (match && match[1]) {
        title = match[1].trim();
      }
    } else if (line.startsWith('LUT_3D_SIZE')) {
      const parts = line.split(/\s+/);
      const parsedSize = parseInt(parts[1], 10);
      if (!isNaN(parsedSize)) {
        size3D = parsedSize;
      }
    } else if (line.startsWith('LUT_1D_SIZE')) {
      const parts = line.split(/\s+/);
      const parsedSize = parseInt(parts[1], 10);
      if (!isNaN(parsedSize)) {
        size3D = parsedSize;
      }
    } else {
      // Data line: "R G B"
      const parts = line.split(/\s+/).map((v) => parseFloat(v));
      if (parts.length >= 3 && !isNaN(parts[0]) && !isNaN(parts[1]) && !isNaN(parts[2])) {
        if (rgbSamples.length < 500) {
          rgbSamples.push([parts[0], parts[1], parts[2]]);
        }
      }
    }
  }

  // Analyze RGB distribution to synthesize contrast, temperature, and saturation
  let avgR = 0;
  let avgG = 0;
  let avgB = 0;
  let sampleCount = rgbSamples.length;

  if (sampleCount > 0) {
    for (const [r, g, b] of rgbSamples) {
      avgR += r;
      avgG += g;
      avgB += b;
    }
    avgR /= sampleCount;
    avgG /= sampleCount;
    avgB /= sampleCount;
  } else {
    avgR = 0.5;
    avgG = 0.5;
    avgB = 0.5;
  }

  // Calculate warm vs cool balance
  const warmDiff = (avgR - avgB) * 100;
  const tintDiff = (avgG - (avgR + avgB) / 2) * 100;

  const tempEstimate = Math.max(-50, Math.min(60, Math.round(warmDiff * 2.2)));
  const tintEstimate = Math.max(-40, Math.min(40, Math.round(-tintDiff * 2.0)));
  const contrastEstimate = 15;
  const saturationEstimate = Math.round(100 + (Math.abs(avgR - avgG) + Math.abs(avgG - avgB)) * 120);

  // Compute CSS filter representation
  const cssFilters: string[] = [];
  cssFilters.push(`contrast(1.${Math.abs(contrastEstimate)})`);
  cssFilters.push(`saturate(${Math.max(0.7, Math.min(1.6, saturationEstimate / 100)).toFixed(2)})`);

  if (tempEstimate > 5) {
    cssFilters.push(`sepia(${(tempEstimate / 150).toFixed(2)})`);
  } else if (tempEstimate < -5) {
    cssFilters.push(`hue-rotate(${Math.round(tempEstimate / 3)}deg)`);
  }

  if (Math.abs(tintEstimate) > 5) {
    cssFilters.push(`hue-rotate(${Math.round(tintEstimate / 4)}deg)`);
  }

  const cssFilter = cssFilters.join(' ');

  // Generate color gradient preview swatch
  const rHex = Math.max(20, Math.min(240, Math.round(avgR * 255))).toString(16).padStart(2, '0');
  const gHex = Math.max(20, Math.min(240, Math.round(avgG * 255))).toString(16).padStart(2, '0');
  const bHex = Math.max(20, Math.min(240, Math.round(avgB * 255))).toString(16).padStart(2, '0');
  const previewGradient = `linear-gradient(135deg, #09090b 0%, #${rHex}${gHex}${bHex} 50%, #f59e0b 100%)`;

  const newLut: CustomLut = {
    id: 'lut-' + Date.now() + '-' + Math.random().toString(36).substring(2, 7),
    name: title,
    fileName: fileName,
    fileSize: content.length,
    uploadedAt: Date.now(),
    title: title,
    size3D: size3D,
    description: `User-imported ${size3D}x${size3D}x${size3D} 3D LUT profile from ${fileName}`,
    previewGradient: previewGradient,
    cssFilter: cssFilter,
    colorGradePreset: {
      exposure: 0,
      contrast: contrastEstimate,
      saturation: Math.min(160, Math.max(80, saturationEstimate)),
      temperature: tempEstimate,
      tint: tintEstimate,
      vignette: 15,
      sharpness: 10,
    },
    cubeRawData: content,
  };

  return newLut;
}

/**
 * Trigger browser file download of a .cube file
 */
export function downloadLutFile(lut: CustomLut): void {
  const content = lut.cubeRawData || `# ${lut.title}\nTITLE "${lut.name}"\nLUT_3D_SIZE ${lut.size3D || 33}\nDOMAIN_MIN 0.0 0.0 0.0\nDOMAIN_MAX 1.0 1.0 1.0\n`;
  const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = lut.fileName.endsWith('.cube') ? lut.fileName : `${lut.fileName}.cube`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
