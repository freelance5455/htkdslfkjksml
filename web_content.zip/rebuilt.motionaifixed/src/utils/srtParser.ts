import { CaptionItem } from '../types';

/**
 * Parses timestamp string like "00:01:23,456" or "00:01:23.456" into float seconds
 */
export function srtTimeToSeconds(timeStr: string): number {
  if (!timeStr) return 0;
  const parts = timeStr.trim().split(':');
  if (parts.length < 3) return 0;
  const hours = parseFloat(parts[0]) || 0;
  const minutes = parseFloat(parts[1]) || 0;
  const secondsParts = parts[2].replace(',', '.').split('.');
  const seconds = parseFloat(secondsParts[0]) || 0;
  const millis = parseFloat(secondsParts[1] || '0') / 1000;
  return hours * 3600 + minutes * 60 + seconds + millis;
}

/**
 * Formats seconds into standard SRT timestamp format: "00:01:23,456"
 */
export function secondsToSrtTime(totalSec: number): string {
  const safeSec = Math.max(0, totalSec);
  const hours = Math.floor(safeSec / 3600);
  const minutes = Math.floor((safeSec % 3600) / 60);
  const seconds = Math.floor(safeSec % 60);
  const millis = Math.floor((safeSec % 1) * 1000);
  return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')},${String(millis).padStart(3, '0')}`;
}

/**
 * Parses raw SRT string content into an array of CaptionItems
 */
export function parseSRT(srtContent: string): CaptionItem[] {
  if (!srtContent || !srtContent.trim()) return [];

  // Normalize line endings
  const normalized = srtContent.replace(/\r\n/g, '\n').replace(/\r/g, '\n');
  const blocks = normalized.trim().split(/\n\s*\n/);
  const captions: CaptionItem[] = [];

  for (let i = 0; i < blocks.length; i++) {
    const lines = blocks[i].trim().split('\n');
    if (lines.length < 2) continue;

    // Check if line 0 is index or timestamp
    let timeLineIdx = 0;
    if (/^\d+$/.test(lines[0].trim())) {
      timeLineIdx = 1;
    }

    const timeLine = lines[timeLineIdx];
    if (!timeLine || !timeLine.includes('-->')) continue;

    const [startStr, endStr] = timeLine.split('-->');
    const startTime = srtTimeToSeconds(startStr);
    const endTime = srtTimeToSeconds(endStr);

    const textLines = lines.slice(timeLineIdx + 1);
    const text = textLines.join(' ').replace(/<[^>]*>/g, '').trim();

    if (text && endTime > startTime) {
      captions.push({
        id: `cap-${i + 1}-${Math.random().toString(36).substring(2, 7)}`,
        startTime,
        endTime,
        text,
      });
    }
  }

  return captions.sort((a, b) => a.startTime - b.startTime);
}

/**
 * Serializes CaptionItem array back to valid SRT text format
 */
export function formatToSRT(captions: CaptionItem[]): string {
  return captions
    .sort((a, b) => a.startTime - b.startTime)
    .map((c, idx) => {
      const start = secondsToSrtTime(c.startTime);
      const end = secondsToSrtTime(c.endTime);
      return `${idx + 1}\n${start} --> ${end}\n${c.text.trim()}`;
    })
    .join('\n\n');
}

/**
 * Generates realistic procedural SRT captions tailored to the audio tracks in the editor
 */
export function generateProceduralCaptions(
  audioTracksInfo: { title: string; type: string; startTime: number; duration: number }[],
  totalDuration: number
): CaptionItem[] {
  const duration = Math.max(8, totalDuration || 15);
  
  // High-impact cinematic lines
  const cinematicLines = [
    "In a world reshaped by synthetic intelligence,",
    "Every frame tells a story beyond imagination.",
    "Behold the horizon of dark gold and neon light.",
    "Dynamic motion vector tracking engaged.",
    "Seamless transitions bridge reality and dreams.",
    "Audio frequencies synchronize with visual harmony.",
    "Mastering the digital cinema workflow in real-time.",
    "Exporting the final cut with uncompromising fidelity."
  ];

  const captions: CaptionItem[] = [];
  let currentTime = 0.8;
  let idx = 0;

  while (currentTime < duration - 1.2 && idx < cinematicLines.length) {
    const start = currentTime;
    const dur = Math.min(3.8, Math.max(2.0, (duration - start) / (cinematicLines.length - idx + 1)));
    const end = Math.min(duration - 0.5, start + dur);

    captions.push({
      id: `cap-${idx + 1}-${Date.now()}`,
      startTime: Number(start.toFixed(2)),
      endTime: Number(end.toFixed(2)),
      text: cinematicLines[idx % cinematicLines.length],
    });

    currentTime = end + 0.4;
    idx++;
  }

  return captions;
}
