export type AppTab =
  | 'create'
  | 'studio'
  | 'editor'
  | 'generate'
  | 'image-gen'
  | 'image2video'
  | 'describe'
  | 'batch'
  | 'library'
  | 'business'
  | 'comparison'
  | 'android'
  | 'profile';

export type AspectRatio = '16:9' | '9:16' | '1:1' | '4:5' | '21:9' | '3:4' | '4:3';
export type Resolution = '480p' | '720p' | '1080p' | '2k' | '4k';

export interface CaptionItem {
  id: string;
  startTime: number;
  endTime: number;
  text: string;
}

export type CaptionPresetStyle = 'dark-gold' | 'minimal-white' | 'karaoke' | 'boxed' | 'neon';

export interface CaptionStyleConfig {
  preset: CaptionPresetStyle;
  fontSize: number;
  positionY: number; // percentage from top (e.g. 82 for bottom)
  color: string;
  enabled: boolean;
}

export interface AudioDuckingConfig {
  enabled: boolean;
  duckingAmount: number; // percentage volume to drop to (e.g., 20 = 20% of normal, approx -14dB)
  attackTime: number; // ramp-down time in seconds (e.g. 0.25s)
  releaseTime: number; // recovery ramp-up time in seconds (e.g. 0.35s)
  targetVoiceTrackId: string; // 'track-a3' (AI Voiceover)
  backgroundMusicTrackId: string; // 'track-a1' (Music)
}

export interface MarketingFormat {
  id: string;
  name: string;
  dimensions: string;
  selected: boolean;
}

export interface MarketingAsset {
  id: string;
  format: string;
  dimensions: string;
  title: string;
  copy: string;
  imageUrl: string;
  videoUrl?: string;
}

export interface ImageItem {
  id: string;
  url: string;
  prompt: string;
  style: string;
  aspectRatio: string;
  createdAt: number;
}

export interface LibraryAsset {
  id: string;
  name: string;
  type: 'video' | 'image' | 'audio' | 'project';
  url: string;
  thumbnail?: string;
  duration?: number;
  size: string;
  createdAt: number;
  tags: string[];
}

export type TransitionType =
  | 'none'
  | 'dissolve'
  | 'whip-left'
  | 'whip-right'
  | 'zoom-in'
  | 'zoom-out'
  | 'flash'
  | 'glitch'
  | 'burn'
  | 'slide-up';

export type FilterPreset =
  | 'none'
  | 'cinematic-gold'
  | 'golden-hour'
  | 'cyberpunk'
  | 'vintage-film'
  | 'noir'
  | 'vhs'
  | 'dreamy'
  | 'chromatic';

export interface ColorGradeSettings {
  exposure: number;    // -100 to 100
  brightness: number;  // -100 to 100
  contrast: number;    // -100 to 100
  saturation: number;  // 0 to 200 (100 = normal)
  temperature: number; // -100 (cool) to 100 (warm dark gold)
  tint: number;        // -100 (green) to 100 (magenta)
  vignette: number;    // 0 to 100
  sharpness: number;   // 0 to 100
}

export interface TextOverlaySettings {
  text: string;
  style: 'headline' | 'subtitle' | 'gold-glow' | 'lower-third' | 'kinetic' | 'typewriter' | 'minimal';
  fontSize: number;
  fontFamily: string;
  color: string;
  backgroundColor: string;
  x: number; // 0 to 100 percentage
  y: number; // 0 to 100 percentage
  animation: 'none' | 'fade' | 'slide-up' | 'typewriter' | 'bounce';
}

export interface TransformSettings {
  scale: number;      // 0.5 to 3.0
  rotation: number;   // -180 to 180 deg
  x: number;          // -100 to 100
  y: number;          // -100 to 100
  opacity: number;    // 0 to 1
  flippedHorizontal: boolean;
}

export interface SmoothMotionConfig {
  enabled: boolean;
  targetFps: 60 | 120 | 240;
  mode: 'optical-flow' | 'frame-blend';
  opticalFlowIntensity: number; // 0 to 100
}

export interface BatchGenerationTask {
  id: string;
  prompt: string;
  resolution: Resolution;
  aspectRatio: AspectRatio;
  style: string;
  camera: string;
  duration: string;
  status: 'pending' | 'processing' | 'completed' | 'failed';
  progress: number; // 0 to 100
  resultVideoUrl?: string;
  createdAt: number;
}

export interface CustomLut {
  id: string;
  name: string;
  fileName: string;
  fileSize: number;
  uploadedAt: number;
  title?: string;
  size3D?: number;
  previewGradient: string;
  cssFilter: string;
  colorGradePreset?: Partial<ColorGradeSettings>;
  cubeRawData?: string;
  description?: string;
}

export interface BeatMarker {
  id: string;
  time: number; // in seconds
  strength: 'downbeat' | 'beat' | 'subbeat';
  label?: string; // e.g. "1.1", "1.2"
}

export interface BeatSyncConfig {
  enabled: boolean;
  bpm: number;
  snappingEnabled: boolean;
  snapThreshold: number; // in seconds
  markers: BeatMarker[];
  isAnalyzing: boolean;
  autoAlignCuts: boolean;
  sourceTrackId: string;
}

export interface EditorClip {
  id: string;
  trackId: string;
  title: string;
  type: 'video' | 'image' | 'audio' | 'voiceover' | 'text' | 'effect';
  mediaUrl: string;
  thumbnail?: string;
  startTime: number;    // position on timeline in seconds
  duration: number;     // duration in seconds
  sourceDuration: number;
  trimStart: number;
  trimEnd: number;
  volume: number;       // 0 to 2 (1 = 100%)
  muted: boolean;
  fadeIn: number;       // seconds
  fadeOut: number;      // seconds
  speed: number;        // 0.5, 0.75, 1, 1.25, 1.5, 2
  smoothMotion?: SmoothMotionConfig;
  transition?: {
    type: TransitionType;
    duration: number;
  };
  filter?: {
    preset: FilterPreset;
    intensity: number;
  };
  customLutId?: string;
  customLutName?: string;
  customLutIntensity?: number; // 0 to 100
  customLutCssFilter?: string;
  colorGrade?: ColorGradeSettings;
  textOverlay?: TextOverlaySettings;
  transform?: TransformSettings;
}

export interface TimelineTrack {
  id: string;
  name: string;
  type: 'video' | 'pip' | 'audio' | 'sfx' | 'voiceover' | 'text' | 'effects';
  muted: boolean;
  locked: boolean;
  volume: number;
  height: number;
}

export interface SoundEffectItem {
  id: string;
  name: string;
  category: 'Cinematic' | 'Transitions' | 'Ambience' | 'UI & Hits';
  duration: number;
  url: string;
  waveform: number[];
}

export interface VideoJob {
  id: string;
  prompt: string;
  model: 'veo-3.1-generate-preview' | 'veo-3.1-lite-generate-preview';
  aspectRatio: AspectRatio;
  resolution: Resolution;
  status: 'queued' | 'processing' | 'completed' | 'failed';
  progress: number;
  videoUrl?: string;
  thumbnailUrl?: string;
  createdAt: number;
  error?: string;
  cameraMovement?: string;
  operationName?: string;
}

export interface CompetitorComparison {
  platform: string;
  category: string;
  tagline: string;
  strengths: string[];
  weaknesses: string[];
  missingGaps: string[];
  motionaiAdvantage: string;
  maxDuration: string;
  resolution: string;
  promptLimits: string;
  creditModel: string;
  multiTrackEditor: boolean;
  cameraMotionControls: boolean;
  offlineStandaloneApp: boolean;
  watermarkFree: boolean;
}
