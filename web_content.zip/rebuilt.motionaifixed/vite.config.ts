import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';
import dotenv from 'dotenv';
import { GoogleGenAI, GenerateVideosOperation } from '@google/genai';

dotenv.config();

function getGenAI() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return null;
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// Vite plugin to provide server-side Gemini API endpoints directly in dev server
function apiPlugin() {
  return {
    name: 'motionai-api-plugin',
    configureServer(server: any) {
      server.middlewares.use(async (req: any, res: any, next: any) => {
        const url = req.url?.split('?')[0];

        if (url === '/api/health' && req.method === 'GET') {
          res.setHeader('Content-Type', 'application/json');
          return res.end(
            JSON.stringify({
              status: 'ok',
              hasKey: !!process.env.GEMINI_API_KEY,
              appName: 'Motionai',
              version: '2.0.0'
            })
          );
        }

        if (url === '/api/gemini/enhance-prompt' && req.method === 'POST') {
          let body = '';
          req.on('data', (chunk: any) => (body += chunk));
          req.on('end', async () => {
            try {
              const { prompt = '', camera = 'Cinematic Dolly', style = 'Cyberpunk Gold' } = JSON.parse(body || '{}');
              const ai = getGenAI();

              if (!ai) {
                const enhancedPrompt = `${prompt}, shot with 35mm anamorphic prime lens, volumetric golden amber rim light, subtle atmospheric dust particles, 8k hyper-realistic texture, steady ${camera} motion, cinematic grading.`;
                res.setHeader('Content-Type', 'application/json');
                return res.end(
                  JSON.stringify({
                    enhancedPrompt,
                    cameraPreset: camera,
                    tags: ['cinematic', 'anamorphic', 'dark-gold-light', 'photorealistic'],
                    suggestedTransitions: ['dissolve', 'whip-left', 'flash']
                  })
                );
              }

              const response = await ai.models.generateContent({
                model: 'gemini-3.8-flash',
                contents: `Enhance this AI video prompt into a Hollywood-grade prompt: "${prompt}". Camera: ${camera}. Style: ${style}. Emphasize dynamic camera movement, physical atmosphere, volumetric lighting, dark gold amber accents, and crisp 8k composition. Keep concise.`,
              });

              res.setHeader('Content-Type', 'application/json');
              res.end(
                JSON.stringify({
                  enhancedPrompt: response.text?.trim() || prompt,
                  cameraPreset: camera,
                  tags: ['veo-3.1', 'cinematic', 'high-motion'],
                  suggestedTransitions: ['dissolve', 'whip-right', 'zoom-in']
                })
              );
            } catch (err: any) {
              res.statusCode = 500;
              res.end(JSON.stringify({ error: err.message }));
            }
          });
          return;
        }

        if (url === '/api/gemini/describe-image' && req.method === 'POST') {
          let body = '';
          req.on('data', (chunk: any) => (body += chunk));
          req.on('end', async () => {
            try {
              const { imageBase64, mimeType = 'image/jpeg' } = JSON.parse(body || '{}');
              const ai = getGenAI();

              if (!ai || !imageBase64) {
                res.setHeader('Content-Type', 'application/json');
                return res.end(
                  JSON.stringify({
                    description: 'Dramatic push-in shot with drifting golden embers, gentle wind physics, high-detail foreground parallax, cinematic lighting.'
                  })
                );
              }

              const cleanBase64 = imageBase64.replace(/^data:image\/\w+;base64,/, '');
              const response = await ai.models.generateContent({
                model: 'gemini-3.8-flash',
                contents: {
                  parts: [
                    { inlineData: { data: cleanBase64, mimeType } },
                    { text: 'Describe the next 5 seconds of cinematic video motion for this scene. Focus on subject movement, camera dynamics, and fluid physics.' }
                  ]
                }
              });

              res.setHeader('Content-Type', 'application/json');
              res.end(JSON.stringify({ description: response.text?.trim() || 'Dynamic cinematic motion.' }));
            } catch (err: any) {
              res.statusCode = 500;
              res.end(JSON.stringify({ error: err.message }));
            }
          });
          return;
        }

        if (url === '/api/generate-image' && req.method === 'POST') {
          let body = '';
          req.on('data', (chunk: any) => (body += chunk));
          req.on('end', async () => {
            try {
              const { prompt = '', aspectRatio = '16:9' } = JSON.parse(body || '{}');
              const ai = getGenAI();

              if (!ai) {
                res.setHeader('Content-Type', 'application/json');
                return res.end(
                  JSON.stringify({
                    imageUrl: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=800&q=80',
                    isSimulated: true
                  })
                );
              }

              const response = await ai.models.generateContent({
                model: 'gemini-3.1-flash-lite-image',
                contents: {
                  parts: [{ text: prompt }]
                },
                config: {
                  imageConfig: {
                    aspectRatio: (['1:1', '3:4', '4:3', '9:16', '16:9'].includes(aspectRatio) ? aspectRatio : '16:9') as any
                  }
                }
              });

              for (const part of response.candidates?.[0]?.content?.parts || []) {
                if (part.inlineData) {
                  res.setHeader('Content-Type', 'application/json');
                  return res.end(
                    JSON.stringify({
                      imageUrl: `data:${part.inlineData.mimeType || 'image/png'};base64,${part.inlineData.data}`,
                      available: true
                    })
                  );
                }
              }

              res.setHeader('Content-Type', 'application/json');
              res.end(
                JSON.stringify({
                  imageUrl: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=800&q=80',
                  isSimulated: true
                })
              );
            } catch (err: any) {
              res.statusCode = 500;
              res.end(JSON.stringify({ error: err.message }));
            }
          });
          return;
        }

        if (url === '/api/gemini/generate-captions' && req.method === 'POST') {
          let body = '';
          req.on('data', (chunk: any) => (body += chunk));
          req.on('end', async () => {
            try {
              const { audioClips = [], totalDuration = 15, videoTitle = 'Cinematic Master' } = JSON.parse(body || '{}');
              const ai = getGenAI();

              const fallbackSRT = `1
00:00:00,600 --> 00:00:03,400
In a world shaped by intelligent motion,

2
00:00:03,800 --> 00:00:07,100
Every frame speaks with cinematic power.

3
00:00:07,500 --> 00:00:10,900
Synchronized audio frequencies surge into light.

4
00:00:11,300 --> 00:00:14,600
Crafting stories beyond the boundary of reality.`;

              if (!ai) {
                res.setHeader('Content-Type', 'application/json');
                return res.end(JSON.stringify({ srt: fallbackSRT, isSimulated: true }));
              }

              const contextStr = audioClips.map((c: any) => `${c.title} (${c.type}, start: ${c.startTime}s, dur: ${c.duration}s)`).join('; ');

              const prompt = `You are a professional cinema subtitler. Generate valid, perfectly timed SRT subtitle file format for a video titled "${videoTitle}" with total duration ${totalDuration} seconds.
Audio Context: ${contextStr || 'Atmospheric orchestral music and voice narration'}.
Format strictly as:
1
00:00:00,500 --> 00:00:03,500
[Subtitle Text]

2
00:00:03,900 --> 00:00:07,000
[Subtitle Text]

Keep captions concise, punchy (3-8 words per line), and aligned with dramatic pacing.
Total time must not exceed ${totalDuration} seconds. Output raw SRT only with no markdown backticks.`;

              const response = await ai.models.generateContent({
                model: 'gemini-3.8-flash',
                contents: { parts: [{ text: prompt }] }
              });

              const srt = response.text?.replace(/```srt/g, '').replace(/```/g, '').trim() || fallbackSRT;
              res.setHeader('Content-Type', 'application/json');
              res.end(JSON.stringify({ srt, available: true }));
            } catch (err: any) {
              res.statusCode = 500;
              res.end(JSON.stringify({ error: err.message }));
            }
          });
          return;
        }

        if (url === '/api/generate-video' && req.method === 'POST') {
          let body = '';
          req.on('data', (chunk: any) => (body += chunk));
          req.on('end', async () => {
            try {
              const { prompt, model = 'veo-3.1-lite-generate-preview', aspectRatio = '16:9', resolution = '720p', imageBase64 } = JSON.parse(body || '{}');
              const ai = getGenAI();

              if (!ai) {
                res.setHeader('Content-Type', 'application/json');
                return res.end(
                  JSON.stringify({
                    operationName: 'simulated_' + Date.now(),
                    isSimulated: true,
                    message: 'Running in high-speed simulation mode'
                  })
                );
              }

              const payload: any = {
                model,
                prompt,
                config: {
                  numberOfVideos: 1,
                  resolution: resolution === '4k' ? '1080p' : resolution,
                  aspectRatio: (aspectRatio === '9:16' ? '9:16' : '16:9')
                }
              };

              if (imageBase64) {
                const cleanBase64 = imageBase64.replace(/^data:image\/\w+;base64,/, '');
                payload.image = {
                  imageBytes: cleanBase64,
                  mimeType: 'image/png'
                };
              }

              const op = await ai.models.generateVideos(payload);
              res.setHeader('Content-Type', 'application/json');
              res.end(JSON.stringify({ operationName: op.name }));
            } catch (err: any) {
              res.statusCode = 500;
              res.end(JSON.stringify({ error: err.message }));
            }
          });
          return;
        }

        if (url === '/api/video-status' && req.method === 'POST') {
          let body = '';
          req.on('data', (chunk: any) => (body += chunk));
          req.on('end', async () => {
            try {
              const { operationName } = JSON.parse(body || '{}');
              const ai = getGenAI();

              if (!ai || operationName?.startsWith('simulated_')) {
                res.setHeader('Content-Type', 'application/json');
                return res.end(JSON.stringify({ done: true, progress: 100, isSimulated: true }));
              }

              const op = new GenerateVideosOperation();
              op.name = operationName;
              const updated = await ai.operations.getVideosOperation({ operation: op });

              res.setHeader('Content-Type', 'application/json');
              res.end(JSON.stringify({ done: updated.done || false, error: updated.error }));
            } catch (err: any) {
              res.statusCode = 500;
              res.end(JSON.stringify({ error: err.message }));
            }
          });
          return;
        }

        next();
      });
    }
  };
}

export default defineConfig({
  plugins: [react(), tailwindcss(), apiPlugin()],
  server: {
    port: 3000,
    host: '0.0.0.0',
  }
});
