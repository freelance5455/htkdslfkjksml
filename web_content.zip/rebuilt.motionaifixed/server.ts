import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI, GenerateVideosOperation } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Initialize GoogleGenAI server-side with telemetry header
const getGenAI = () => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return null;
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
};

// Health Check
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    hasKey: !!process.env.GEMINI_API_KEY,
    appName: 'Motionai',
    version: '2.0.0',
    mode: process.env.NODE_ENV || 'development'
  });
});

// Prompt Enhancement via Gemini 3.8 Flash
app.post('/api/gemini/enhance-prompt', async (req, res) => {
  try {
    const { prompt, style = 'Cinematic', camera = 'Steadicam tracking', aspect = '16:9' } = req.body;
    const ai = getGenAI();

    if (!ai) {
      // Smart offline enhancement fallback
      const cinematicPrompt = `${prompt}, shot on ARRI Alexa 65, 35mm anamorphic lens, cinematic lighting with warm dark gold amber rim lights, photorealistic volumetric haze, photorealistic motion blur, 8k resolution, ultra-detailed depth of field, steady ${camera.toLowerCase()} dynamic movement.`;
      return res.json({
        enhancedPrompt: cinematicPrompt,
        cameraPreset: camera,
        tags: ['cinematic', 'anamorphic', 'dark gold rim light', 'photorealistic', '8k-uhd'],
        suggestedTransitions: ['whip-left', 'dissolve', 'zoom-in']
      });
    }

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: `You are an elite Hollywood director and AI video prompting maestro for Veo 3.1. 
Enhance this user idea into a masterwork cinematic video prompt: "${prompt}".
Style: ${style}. Preferred Camera Movement: ${camera}. Aspect Ratio: ${aspect}.
Incorporate dramatic cinematic lighting, focal length, color grading with subtle dark gold/amber highlights, volumetric atmosphere, and realistic physical motion vector cues.
Provide output as clean text of the enhanced prompt only.`,
    });

    const enhanced = response.text?.trim() || prompt;
    res.json({
      enhancedPrompt: enhanced,
      cameraPreset: camera,
      tags: ['veo-optimized', 'hollywood-lighting', '8k-uhd', 'cinematic-motion'],
      suggestedTransitions: ['dissolve', 'whip-right', 'zoom-in']
    });
  } catch (error: any) {
    console.error('Enhance prompt error:', error);
    res.status(500).json({ error: error.message || 'Failed to enhance prompt' });
  }
});

// Auto-Describe Image for Image-to-Video
app.post('/api/gemini/describe-image', async (req, res) => {
  try {
    const { imageBase64, mimeType = 'image/jpeg' } = req.body;
    const ai = getGenAI();

    if (!ai || !imageBase64) {
      return res.json({
        description: 'Cinematic slow-motion shot with dynamic particle embers drifting, soft amber gold lighting, gentle wind rustling, smooth camera push-in dolly zoom.'
      });
    }

    const cleanBase64 = imageBase64.replace(/^data:image\/\w+;base64,/, '');
    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: {
        parts: [
          {
            inlineData: {
              data: cleanBase64,
              mimeType
            }
          },
          {
            text: 'Analyze this image and describe the ideal next 5 seconds of cinematic video motion. Detail what subjects should move, atmospheric physics, wind, fluid dynamics, camera orbit or dolly zoom, and color accents. Keep it under 60 words.'
          }
        ]
      }
    });

    res.json({ description: response.text?.trim() || 'Dynamic cinematic motion with camera push-in.' });
  } catch (error: any) {
    console.error('Describe image error:', error);
    res.status(500).json({ error: error.message || 'Failed to analyze image' });
  }
});

// Text-to-Speech generation for Voiceover Track
app.post('/api/gemini/tts', async (req, res) => {
  try {
    const { text, voice = 'Kore' } = req.body;
    const ai = getGenAI();

    if (!ai) {
      return res.json({
        available: false,
        message: 'Using local synthetic audio engine',
      });
    }

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash-lite-tts',
      contents: text,
      config: {
        responseModalities: ['AUDIO'],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: voice }
          }
        }
      }
    });

    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (base64Audio) {
      res.json({
        audioBase64: base64Audio,
        mimeType: 'audio/wav',
        available: true
      });
    } else {
      res.json({ available: false });
    }
  } catch (error: any) {
    console.error('TTS error:', error);
    res.status(500).json({ error: error.message || 'TTS generation failed' });
  }
});

// AI Image Generation Endpoint (Gemini 3.1 Flash Image)
app.post('/api/generate-image', async (req, res) => {
  try {
    const { prompt, aspectRatio = '16:9' } = req.body;
    const ai = getGenAI();

    if (!ai) {
      return res.json({
        isSimulated: true,
        imageUrl: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=800&q=80',
        message: 'High-res sample returned'
      });
    }

    const response = await ai.models.generateContent({
      model: 'gemini-3.1-flash-lite-image',
      contents: {
        parts: [{ text: prompt }]
      },
      config: {
        imageConfig: {
          aspectRatio: (['1:1', '3:4', '4:3', '9:16', '16:9'].includes(aspectRatio) ? aspectRatio : '16:9') as any
        }
      }
    });

    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        return res.json({
          imageUrl: `data:${part.inlineData.mimeType || 'image/png'};base64,${part.inlineData.data}`,
          available: true
        });
      }
    }

    res.json({
      imageUrl: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=800&q=80',
      isSimulated: true
    });
  } catch (error: any) {
    console.error('Generate image error:', error);
    res.status(500).json({ error: error.message || 'Image generation failed' });
  }
});

// Auto-generate SRT captions from audio tracks using Gemini 3.8 Flash
app.post('/api/gemini/generate-captions', async (req, res) => {
  try {
    const { audioClips = [], totalDuration = 15, videoTitle = 'Cinematic Master' } = req.body;
    const ai = getGenAI();

    const fallbackSRT = `1
00:00:00,600 --> 00:00:03,400
In a world shaped by intelligent motion,

2
00:00:03,800 --> 00:00:07,100
Every frame speaks with cinematic power.

3
00:00:07,500 --> 00:00:10,900
Synchronized audio frequencies surge into light.

4
00:00:11,300 --> 00:00:14,600
Crafting stories beyond the boundary of reality.`;

    if (!ai) {
      return res.json({ srt: fallbackSRT, isSimulated: true });
    }

    const contextStr = audioClips.map((c: any) => `${c.title} (${c.type}, start: ${c.startTime}s, dur: ${c.duration}s)`).join('; ');

    const prompt = `You are a professional cinema subtitler. Generate valid, perfectly timed SRT subtitle file format for a video titled "${videoTitle}" with total duration ${totalDuration} seconds.
Audio Context: ${contextStr || 'Atmospheric orchestral music and voice narration'}.
Format strictly as:
1
00:00:00,500 --> 00:00:03,500
[Subtitle Text]

2
00:00:03,900 --> 00:00:07,000
[Subtitle Text]

Keep captions concise, punchy (3-8 words per line), and aligned with dramatic pacing.
Total time must not exceed ${totalDuration} seconds. Output raw SRT only with no markdown backticks.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: {
        parts: [{ text: prompt }]
      }
    });

    const srt = response.text?.replace(/```srt/g, '').replace(/```/g, '').trim() || fallbackSRT;
    res.json({ srt, available: true });
  } catch (error: any) {
    console.error('Caption generation error:', error);
    res.status(500).json({ error: error.message || 'Failed to generate captions' });
  }
});

// Start Video Generation (Veo 3.1 / Veo Lite)
app.post('/api/generate-video', async (req, res) => {
  try {
    const { prompt, model = 'veo-3.1-lite-generate-preview', aspectRatio = '16:9', resolution = '720p', imageBase64 } = req.body;
    const ai = getGenAI();

    if (!ai) {
      // Return a simulated job operation for demonstration without API key
      const mockOpId = 'simulated_' + Date.now();
      return res.json({
        operationName: mockOpId,
        isSimulated: true,
        message: 'Generation started in simulated production mode'
      });
    }

    const payload: any = {
      model,
      prompt,
      config: {
        numberOfVideos: 1,
        resolution: resolution === '4k' ? '1080p' : resolution,
        aspectRatio: (aspectRatio === '9:16' ? '9:16' : '16:9')
      }
    };

    if (imageBase64) {
      const cleanBase64 = imageBase64.replace(/^data:image\/\w+;base64,/, '');
      payload.image = {
        imageBytes: cleanBase64,
        mimeType: 'image/png'
      };
    }

    const operation = await ai.models.generateVideos(payload);
    res.json({ operationName: operation.name });
  } catch (error: any) {
    console.error('Generate video error:', error);
    res.status(500).json({ error: error.message || 'Failed to start video generation' });
  }
});

// Poll Video Operation Status
app.post('/api/video-status', async (req, res) => {
  try {
    const { operationName } = req.body;
    const ai = getGenAI();

    if (!ai || operationName?.startsWith('simulated_')) {
      return res.json({
        done: true,
        progress: 100,
        isSimulated: true
      });
    }

    const op = new GenerateVideosOperation();
    op.name = operationName;
    const updated = await ai.operations.getVideosOperation({ operation: op });

    res.json({
      done: updated.done || false,
      hasError: !!updated.error,
      error: updated.error
    });
  } catch (error: any) {
    console.error('Video status error:', error);
    res.status(500).json({ error: error.message || 'Failed to check status' });
  }
});

// Download Completed Video
app.post('/api/video-download', async (req, res) => {
  try {
    const { operationName } = req.body;
    const apiKey = process.env.GEMINI_API_KEY;
    const ai = getGenAI();

    if (!ai || !apiKey || operationName?.startsWith('simulated_')) {
      return res.status(404).json({ error: 'Video not ready or simulated operation' });
    }

    const op = new GenerateVideosOperation();
    op.name = operationName;
    const updated = await ai.operations.getVideosOperation({ operation: op });
    const uri = updated.response?.generatedVideos?.[0]?.video?.uri;

    if (!uri) {
      return res.status(404).json({ error: 'Video URI not found' });
    }

    const videoRes = await fetch(uri, {
      headers: { 'x-goog-api-key': apiKey },
    });

    res.setHeader('Content-Type', 'video/mp4');
    videoRes.body!.pipeTo(
      new WritableStream({
        write(chunk) {
          res.write(chunk);
        },
        close() {
          res.end();
        },
      })
    );
  } catch (error: any) {
    console.error('Video download error:', error);
    res.status(500).json({ error: error.message || 'Failed to download video' });
  }
});

// Serve static build in production
app.use(express.static(path.join(__dirname, 'dist')));
app.use(express.static(path.join(__dirname, 'public')));

app.get('*', (req, res) => {
  const indexPath = path.join(__dirname, 'dist', 'index.html');
  res.sendFile(indexPath, (err) => {
    if (err) {
      res.sendFile(path.join(__dirname, 'index.html'));
    }
  });
});

app.listen(PORT, () => {
  console.log(`Motionai server running on port ${PORT}`);
});
