# Roll & Chaos - Android APK Package

Package ID: `com.rollandchaos.game`
Version: `1.0.0` (Code: 1)

## How to Build the APK:

### 🌟 Easiest: 1-Click Cloud APK Build via GitHub Actions (Zero Software Required)
1. Push this extracted folder to a new repository on GitHub.
2. Go to the **Actions** tab on your GitHub repository.
3. The build runs automatically and compiles your APK.
4. Click on the completed workflow run, scroll down to **Artifacts**, and download your **.apk** file!
5. Install on your Android phone!

### 💻 Local Build with Android Studio:
1. Open Android Studio and choose **Open**.
2. Select this extracted directory.
3. Once Gradle finishes syncing, go to:
   **Build** -> **Build Bundle(s) / APK(s)** -> **Build APK(s)**.
4. Android Studio will notify you with a link to locate `app-debug.apk`.

### ⚡ Command Line (Gradle):
```bash
# Linux / macOS:
./gradlew assembleDebug

# Windows:
gradlew.bat assembleDebug
```
Output APK path: `app/build/outputs/apk/debug/app-debug.apk`
