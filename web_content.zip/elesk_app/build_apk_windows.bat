﻿@echo off
chcp 65001 >nul
setlocal
echo ================================================
echo   الإسكان مع محمود جاد - بناء APK
echo ================================================
where flutter >nul 2>nul
if errorlevel 1 (
  echo ERROR: Flutter is not installed or not added to PATH.
  echo Install Flutter: https://docs.flutter.dev/get-started/install/windows
  pause
  exit /b 1
)
if not exist pubspec.yaml (
  echo ERROR: Open this script from the extracted eleskan_app folder.
  pause
  exit /b 1
)
if not exist android (
  echo Creating Android platform files...
  flutter create --org com.mahmoudgad --project-name eleskan_mahmoud_gad .
  if errorlevel 1 goto fail
)
echo Getting Flutter packages...
flutter pub get
if errorlevel 1 goto fail
echo.
echo NOTE: Firebase Android setup is required for live Firebase features.
echo Put google-services.json in android\app after registering the Android app in Firebase.
echo The APK may build without Firebase config only if the project code and plugins permit it.
echo.
echo Building release APK...
flutter build apk --release
if errorlevel 1 goto fail
echo.
echo SUCCESS. APK output:
echo build\app\outputs\flutter-apk\app-release.apk
pause
exit /b 0
:fail
echo.
echo BUILD FAILED. Copy the error text and send it for help.
pause
exit /b 1
