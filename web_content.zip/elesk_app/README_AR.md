# الإسكان مع محمود جاد للخدمات الإلكترونية — مشروع Flutter

## بناء ملف APK (على جهازك)
1. ثبّت Flutter و Android Studio (أو Android SDK).
2. داخل هذا المجلد نفّذ: `flutter create --org com.mahmoudgad --project-name eleskan_mahmoud_gad .`
   (ينشئ مجلد android بدون أن يمسّ lib أو pubspec.yaml؛ وإن سألك عن الاستبدال فاحتفظ بملفاتنا.)
3. أضف محتوى `android_snippets/AndroidManifest_additions.xml` إلى AndroidManifest.xml، وغيّر android:label إلى «الإسكان مع محمود جاد».
4. `flutter pub get` ثم `flutter build apk --release` ← الناتج: build/app/outputs/flutter-apk/app-release.apk
5. للنشر على Google Play: `flutter build appbundle --release` (يلزم توقيع بمفتاح keystore خاص بك).
6. الأيقونة: أضف حزمة flutter_launcher_icons بصورة الشعار.

## تعديل الأرقام والروابط
كلها في `lib/config.dart`.

## ما لم يُنفَّذ بعد (يحتاج مرحلة ثانية)
Firebase، لوحة التحكم، الإشعارات، الأخبار/الصور/الفيديو، والتحقق من الدخول.

---
# المرحلة الثانية: Firebase + لوحة التحكم + الإشعارات

## 1) إنشاء مشروع Firebase
1. من console.firebase.google.com أنشئ مشروعًا.
2. أضف تطبيق Android باسم الحزمة `com.mahmoudgad.eleskan_mahmoud_gad`، ونزّل `google-services.json` وضعه في `android/app/`.
3. فعّل: Authentication (Email/Password) و Firestore Database و Storage.
4. في ملفات Gradle الخاصة بأندرويد أضف مكوّن `com.google.gms.google-services` (الإصدار 4.4.2) واجعل `minSdk = 23`.
   (يمكنك بدلًا من ذلك تشغيل `flutterfire configure` فيتولّى الإعداد.)

## 2) حساب المدير
1. من Authentication أضف مستخدمًا (بريدك وكلمة مرور قوية) وانسخ UID الخاص به.
2. من Firestore أنشئ مجموعة `admins` ومستندًا رقمه = ذلك UID (يمكن أن يكون فارغًا).
   هذه الخطوة يدوية عن قصد؛ لا يستطيع أي مستخدم في التطبيق أن يجعل نفسه مديرًا.

## 3) القواعد والنشر
```
npm i -g firebase-tools && firebase login && firebase use --add
firebase deploy --only firestore:rules,storage
```

## 4) لوحة التحكم (مجلد admin)
- افتح `admin/index.html` وضع إعدادات الويب في `firebaseConfig` (من Project settings > Your apps > Web).
- انشرها: `firebase deploy --only hosting` فيصير لها رابط على الإنترنت.
- من اللوحة: انشر الأخبار (مع صورة ورابط فيديو)، حدّد «عاجل»، عدّل تفاصيل كل خدمة، واحذف أو عدّل أي خبر.

## 5) الإشعارات
- التطبيق يشترك تلقائيًا في الموضوع `all` ويطلب إذن الإشعارات.
- إرسال الإشعار يتم من Cloud Function في مجلد `functions` عند نشر خبر جديد مع تفعيل «إرسال إشعار».
- تتطلب Cloud Functions خطة Blaze (الدفع حسب الاستخدام؛ للاستخدام الصغير غالبًا ضمن الحصة المجانية).
- النشر: `cd functions && npm install && cd .. && firebase deploy --only functions`
- لا يُرسَل أي إشعار تجريبي من النظام، فكل إشعار يخرج من خبر تنشره أنت.

## ما زال غير منفّذ
مواعيد الطرح والأسعار تُدخَل يدويًا من لوحة التحكم بعد التحقق منها؛ لم أضف أي أرقام أو شروط من عندي. أيقونة التطبيق والشعار والصورة الشخصية تحتاج ملفات منك.
