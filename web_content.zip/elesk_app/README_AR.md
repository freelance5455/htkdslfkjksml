# مشروع الإسكان مع محمود جاد للخدمات الإلكترونية

هذه ملفات مصدر مشروع Flutter، وليست ملف APK جاهزًا. يجب بناء APK على جهاز عليه Flutter وAndroid SDK.

## محتويات المشروع
- `lib/`: شاشات التطبيق وأرقام الهواتف وروابط التواصل.
- `admin/`: ملفات واجهة لوحة التحكم.
- `firestore.rules` و`storage.rules`: قواعد أمان مقترحة لـ Firebase.
- `functions/`: ملفات Cloud Functions.
- `firebase.json`: إعدادات Firebase.
- `android_snippets/`: إضافات Manifest المقترحة.
- `build_apk_windows.bat`: سكربت مساعد لإنشاء ملفات Android إن كانت ناقصة ثم بناء APK.

## بناء APK على ويندوز
1. ثبّت Flutter وAndroid Studio، ثم أكمل إعداد Android SDK:
   https://docs.flutter.dev/get-started/install/windows
   https://developer.android.com/studio
2. فك ضغط هذا الملف.
3. افتح مجلد `elesk_app`.
4. انقر مرتين على `build_apk_windows.bat` أو افتح Terminal داخل المجلد وشغّل:
   `flutter doctor`
   `flutter pub get`
   `flutter build apk --release`
5. بعد نجاح البناء ستجد الملف:
   `build\app\outputs\flutter-apk\app-release.apk`

## إعداد Firebase قبل الاعتماد على الأخبار ولوحة التحكم
المشروع المرفوع لا يحتوي على `android/app/google-services.json`، لذلك يجب تنزيله من إعدادات مشروع Firebase الخاص بك ووضعه في هذا المسار بعد إضافة تطبيق Android بالـ package name الصحيح. لا تشارك ملف مفاتيح خاصة أو كلمات مرور في المحادثات العامة.

تحقق أيضًا من إعداد Gradle لإضافة Google Services plugin، ومن تهيئة Firebase المناسبة لإصدار Flutter المستخدم. إن فشل البناء، انسخ رسالة الخطأ كاملة وأرسلها للمساعدة.

## لوحة التحكم
ملفات `admin/` موجودة، لكن يجب إعداد `firebaseConfig` لمشروعك، ونشر الاستضافة، وإنشاء حساب مدير في Firebase Authentication وإضافة UID الخاص به إلى `admins` في Firestore. لا تعتبر لوحة التحكم جاهزة للنشر قبل اختبار تسجيل الدخول وقواعد الأمان.

## تنبيه
- إنشاء APK لا يعني تلقائيًا أن Firebase أو الإشعارات أو لوحة التحكم تعمل.
- لا تضع كلمة مرور ثابتة أو أسرارًا داخل كود التطبيق.
- اختبر التطبيق على جهاز فعلي قبل توزيعه.
