import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'config.dart';
import 'news.dart';

const navy = Color(0xFF0B2545);
const gold = Color(0xFFC9A227);

bool firebaseOk = false;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    await Firebase.initializeApp(); // يعتمد على android/app/google-services.json
    firebaseOk = true;
    final m = FirebaseMessaging.instance;
    await m.requestPermission();
    await m.subscribeToTopic('all');
  } catch (_) {
    // التطبيق يعمل بدون Firebase إلى أن يتم إعداده
  }
  runApp(const App());
}

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'الإسكان مع محمود جاد',
        debugShowCheckedModeBanner: false,
        locale: const Locale('ar', 'EG'),
        supportedLocales: const [Locale('ar', 'EG')],
        localizationsDelegates: const [
          GlobalMaterialLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
          GlobalCupertinoLocalizations.delegate,
        ],
        theme: ThemeData(
          useMaterial3: true,
          colorScheme: ColorScheme.fromSeed(seedColor: navy, secondary: gold),
          scaffoldBackgroundColor: const Color(0xFFF6F7FA),
        ),
        builder: (c, child) =>
            Directionality(textDirection: TextDirection.rtl, child: child!),
        home: const Splash(),
      );
}

Future<void> openUri(BuildContext context, Uri uri) async {
  var ok = false;
  try {
    ok = await launchUrl(uri, mode: LaunchMode.externalApplication);
  } catch (_) {}
  if (!ok && context.mounted) {
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('تعذّر الفتح. تأكد من وجود التطبيق المطلوب أو من الاتصال بالإنترنت.')));
  }
}

class Splash extends StatelessWidget {
  const Splash({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        body: Container(
          width: double.infinity,
          decoration: const BoxDecoration(
            gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [navy, Color(0xFF13315C)]),
          ),
          padding: const EdgeInsets.all(28),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            const Icon(Icons.apartment_rounded, size: 110, color: gold),
            const SizedBox(height: 16),
            const Text('الإسكان مع محمود جاد',
                style: TextStyle(color: gold, fontSize: 26, fontWeight: FontWeight.bold)),
            const SizedBox(height: 40),
            const Text(
                'مرحبًا بكم في تطبيق الإسكان مع محمود جاد للخدمات الإلكترونية',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.white, fontSize: 22, height: 1.6)),
            const SizedBox(height: 40),
            SizedBox(
              width: 240,
              height: 54,
              child: FilledButton(
                style: FilledButton.styleFrom(
                    backgroundColor: gold, foregroundColor: navy),
                onPressed: () => Navigator.pushReplacement(
                    context,
                    PageRouteBuilder(
                        pageBuilder: (_, __, ___) => const Shell(),
                        transitionsBuilder: (_, a, __, w) =>
                            FadeTransition(opacity: a, child: w))),
                child: const Text('ابدأ الآن',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              ),
            ),
          ]),
        ),
      );
}

class Service {
  final String name;
  final IconData icon;
  const Service(this.name, this.icon);
}

const services = [
  Service('تقديم شقق الإسكان الاجتماعي', Icons.home_work),
  Service('تقديم شقق الإسكان الفاخر', Icons.villa),
  Service('تقديم شقق الإسكان المتوسط', Icons.apartment),
  Service('تقديم أراضي بيت الوطن للعاملين بالخارج', Icons.landscape),
  Service('تقديم شقق مبادرة «بيتك في مصر» للعاملين بالخارج', Icons.flight_land),
  Service('تقديم الأراضي السكنية', Icons.terrain),
  Service('تخصيص الوحدات بالأسبقية', Icons.format_list_numbered),
  Service('تقديم جميع الخدمات الإلكترونية', Icons.devices),
];

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int i = 0;
  @override
  Widget build(BuildContext context) {
    final pages = [
      ServicesPage(title: 'خدمات الإسكان الإلكتروني', home: true, goTo: (n) => setState(() => i = n)),
      const ServicesPage(title: 'خدمات الإسكان'),
      const AboutPage(),
      const ContactPage(),
    ];
    return Scaffold(
      body: AnimatedSwitcher(duration: const Duration(milliseconds: 250), child: KeyedSubtree(key: ValueKey(i), child: pages[i])),
      bottomNavigationBar: NavigationBar(
        selectedIndex: i,
        indicatorColor: gold.withOpacity(.35),
        onDestinationSelected: (n) => setState(() => i = n),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'الرئيسية'),
          NavigationDestination(icon: Icon(Icons.apartment_outlined), selectedIcon: Icon(Icons.apartment), label: 'خدمات الإسكان'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'من نحن'),
          NavigationDestination(icon: Icon(Icons.call_outlined), selectedIcon: Icon(Icons.call), label: 'التواصل'),
        ],
      ),
    );
  }
}

class ServicesPage extends StatelessWidget {
  final String title;
  final bool home;
  final void Function(int)? goTo;
  const ServicesPage({super.key, required this.title, this.home = false, this.goTo});
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(title), backgroundColor: navy, foregroundColor: Colors.white, centerTitle: true),
        body: ListView.separated(
          padding: const EdgeInsets.all(16),
          itemCount: services.length + (home ? 1 : 0),
          separatorBuilder: (_, __) => const SizedBox(height: 12),
          itemBuilder: (c, n) {
            if (home) {
              if (n == 0) return const NewsSection();
              n -= 1;
            }
            final s = services[n];
            return Card(
              elevation: 2,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              child: ListTile(
                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                leading: CircleAvatar(radius: 26, backgroundColor: navy, child: Icon(s.icon, color: gold)),
                title: Text(s.name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                trailing: const Icon(Icons.chevron_left),
                onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => ServiceDetails(s, n))),
              ),
            );
          },
        ),
      );
}

class ServiceDetails extends StatelessWidget {
  final Service s;
  final int id;
  const ServiceDetails(this.s, this.id, {super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('تفاصيل الخدمة'), backgroundColor: navy, foregroundColor: Colors.white),
        body: ListView(padding: const EdgeInsets.all(20), children: [
          Center(child: CircleAvatar(radius: 40, backgroundColor: navy, child: Icon(s.icon, color: gold, size: 40))),
          const SizedBox(height: 16),
          Text(s.name, textAlign: TextAlign.center, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          const SizedBox(height: 20),
          ServiceInfo(id: id),
          const SizedBox(height: 20),
          SizedBox(
            height: 52,
            child: FilledButton.icon(
              style: FilledButton.styleFrom(backgroundColor: gold, foregroundColor: navy),
              icon: const Icon(Icons.support_agent),
              label: const Text('تواصل للاستفسار', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              onPressed: () => openUri(context, Uri.parse('https://wa.me/${AppConfig.intl(AppConfig.phones[0])}')),
            ),
          ),
        ]),
      );
}

class AboutPage extends StatelessWidget {
  const AboutPage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('من نحن'), backgroundColor: navy, foregroundColor: Colors.white, centerTitle: true),
        body: ListView(padding: const EdgeInsets.all(24), children: const [
          // مكان الصورة الشخصية/الشعار: استبدل الأيقونة بـ Image.asset عند توفر الصورة
          Center(child: CircleAvatar(radius: 60, backgroundColor: navy, child: Icon(Icons.person, size: 70, color: gold))),
          SizedBox(height: 20),
          Text('المهندس محمود جاد', textAlign: TextAlign.center, style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold, color: navy)),
          SizedBox(height: 16),
          Text('مهندس محمود جاد متخصص في خدمات التقديم على شقق الإسكان والأراضي السكنية وأراضي المغتربين.',
              textAlign: TextAlign.center, style: TextStyle(fontSize: 18, height: 1.8)),
          SizedBox(height: 12),
          Text('خبرة في مجال الإسكان منذ 10 سنوات.', textAlign: TextAlign.center, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        ]),
      );
}

class ContactPage extends StatelessWidget {
  const ContactPage({super.key});

  Widget phoneCard(BuildContext c, String p) => Card(
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('للتواصل مباشر مع م/ محمود جاد', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 4),
            Directionality(textDirection: TextDirection.ltr, child: Text(p, style: const TextStyle(fontSize: 22, color: navy))),
            const SizedBox(height: 10),
            Row(children: [
              Expanded(child: FilledButton.icon(onPressed: () => openUri(c, Uri(scheme: 'tel', path: p)), icon: const Icon(Icons.call), label: const Text('اتصال'))),
              const SizedBox(width: 10),
              Expanded(child: FilledButton.icon(
                  style: FilledButton.styleFrom(backgroundColor: const Color(0xFF25D366)),
                  onPressed: () => openUri(c, Uri.parse('https://wa.me/${AppConfig.intl(p)}')),
                  icon: const Icon(Icons.chat), label: const Text('واتساب'))),
            ]),
          ]),
        ),
      );

  Widget socialBtn(BuildContext c, IconData ic, String label, String url, Color col) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: SizedBox(
          height: 54,
          child: FilledButton.icon(
              style: FilledButton.styleFrom(backgroundColor: col),
              onPressed: () => openUri(c, Uri.parse(url)),
              icon: Icon(ic),
              label: Text(label, style: const TextStyle(fontSize: 17))),
        ),
      );

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('التواصل المباشر'), backgroundColor: navy, foregroundColor: Colors.white, centerTitle: true),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          for (final p in AppConfig.phones) phoneCard(context, p),
          const SizedBox(height: 16),
          const Text('تابعنا على السوشيال ميديا', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: navy)),
          const SizedBox(height: 10),
          socialBtn(context, Icons.facebook, 'تابعنا على فيسبوك', AppConfig.facebook, const Color(0xFF1877F2)),
          socialBtn(context, Icons.send, 'انضم إلى قناة تليجرام', AppConfig.telegram, const Color(0xFF229ED9)),
          socialBtn(context, Icons.campaign, 'تابع قناة واتساب', AppConfig.whatsappChannel, const Color(0xFF25D366)),
        ]),
      );
}
