// كل الأرقام والروابط هنا في مكان واحد لسهولة التعديل.
class AppConfig {
  static const phones = ['01069235307', '01205759749'];
  static const facebook = 'https://www.facebook.com/MahmoudGad2036/';
  static const telegram = 'https://t.me/Trohateleskan';
  static const whatsappChannel =
      'https://whatsapp.com/channel/0029Vb8g5Jc2v1Isn7m8xR1h';

  // رقم مصري محلي -> صيغة دولية لواتساب (01xxxxxxxxx -> 201xxxxxxxxx)
  static String intl(String local) => '20${local.substring(1)}';
}
