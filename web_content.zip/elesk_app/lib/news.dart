import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'main.dart' show firebaseOk, navy, openUri;

class NewsSection extends StatelessWidget {
  const NewsSection({super.key});

  @override
  Widget build(BuildContext context) {
    if (!firebaseOk) return const SizedBox.shrink();
    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance
          .collection('news')
          .orderBy('createdAt', descending: true)
          .limit(20)
          .snapshots(),
      builder: (c, snap) {
        if (snap.hasError) {
          return const Padding(
              padding: EdgeInsets.all(8),
              child: Text('تعذّر تحميل الأخبار. تحقق من الاتصال بالإنترنت.'));
        }
        if (!snap.hasData) {
          return const Padding(
              padding: EdgeInsets.all(16),
              child: Center(child: CircularProgressIndicator()));
        }
        final items = snap.data!.docs.map((d) => d.data()).toList();
        if (items.isEmpty) return const SizedBox.shrink();
        final sorted = [
          ...items.where((m) => m['urgent'] == true),
          ...items.where((m) => m['urgent'] != true),
        ];
        return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('آخر الأخبار والتحديثات',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: navy)),
          const SizedBox(height: 8),
          for (final m in sorted) _tile(c, m),
          const SizedBox(height: 12),
          const Text('الخدمات',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: navy)),
        ]);
      },
    );
  }

  Widget _tile(BuildContext c, Map<String, dynamic> m) {
    final urgent = m['urgent'] == true;
    final img = '${m['imageUrl'] ?? ''}';
    final vid = '${m['videoUrl'] ?? ''}';
    return Card(
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
          side: BorderSide(color: urgent ? Colors.red : Colors.transparent, width: 2)),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          if (urgent)
            const Chip(
                label: Text('عاجل', style: TextStyle(color: Colors.white)),
                backgroundColor: Colors.red),
          Text('${m['title'] ?? ''}',
              style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
          if (img.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: ClipRRect(
                  borderRadius: BorderRadius.circular(10),
                  child: Image.network(img,
                      errorBuilder: (_, __, ___) => const SizedBox.shrink())),
            ),
          const SizedBox(height: 6),
          Text('${m['body'] ?? ''}', style: const TextStyle(height: 1.6)),
          if (vid.isNotEmpty)
            TextButton.icon(
                onPressed: () => openUri(c, Uri.parse(vid)),
                icon: const Icon(Icons.play_circle),
                label: const Text('مشاهدة الفيديو')),
        ]),
      ),
    );
  }
}

/// تفاصيل الخدمة من Firestore: services/{id}
class ServiceInfo extends StatelessWidget {
  final int id;
  const ServiceInfo({super.key, required this.id});

  static const _fields = {
    'description': 'نبذة عن الخدمة',
    'requirements': 'الشروط والأوراق المطلوبة',
    'dates': 'مواعيد التقديم',
    'updates': 'آخر التحديثات',
  };

  Widget _box(Widget child) => Card(child: Padding(padding: const EdgeInsets.all(16), child: child));

  @override
  Widget build(BuildContext context) {
    const placeholder = Text(
        'سيتم إضافة تفاصيل هذه الخدمة (الشروط والأوراق المطلوبة ومواعيد التقديم) عند توفرها.',
        style: TextStyle(fontSize: 16, height: 1.7));
    if (!firebaseOk) return _box(placeholder);
    return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance.collection('services').doc('$id').snapshots(),
      builder: (c, snap) {
        if (snap.hasError) return _box(const Text('تعذّر تحميل التفاصيل. تحقق من الاتصال بالإنترنت.'));
        if (!snap.hasData) return const Center(child: CircularProgressIndicator());
        final m = snap.data!.data() ?? {};
        final rows = _fields.entries.where((e) => '${m[e.key] ?? ''}'.trim().isNotEmpty).toList();
        if (rows.isEmpty) return _box(placeholder);
        return Column(children: [
          for (final e in rows)
            _box(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(e.value, style: const TextStyle(fontWeight: FontWeight.bold, color: navy, fontSize: 16)),
              const SizedBox(height: 6),
              Text('${m[e.key]}', style: const TextStyle(fontSize: 16, height: 1.7)),
            ])),
        ]);
      },
    );
  }
}
