// يرسل إشعارًا لكل المشتركين في الموضوع "all" عند نشر خبر جديد وتفعيل خيار "إرسال إشعار"
const { onDocumentCreated } = require('firebase-functions/v2/firestore');
const admin = require('firebase-admin');
admin.initializeApp();

exports.notifyOnNews = onDocumentCreated('news/{id}', async (event) => {
  const d = event.data && event.data.data();
  if (!d || d.notify !== true) return;
  await admin.messaging().send({
    topic: 'all',
    notification: { title: d.urgent ? `عاجل: ${d.title}` : d.title, body: (d.body || '').slice(0, 120) },
    android: { priority: 'high' },
  });
});
