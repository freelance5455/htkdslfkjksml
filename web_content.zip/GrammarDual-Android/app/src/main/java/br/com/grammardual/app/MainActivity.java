package br.com.grammardual.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import java.util.ArrayList;
import java.util.Locale;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private WebView web;
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private SpeechRecognizer recognizer;
    private String currentRequestId = "";
    private static final int MIC_PERMISSION = 41;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new TTSBridge(), "AndroidTTS");
        web.addJavascriptInterface(new STTBridge(), "AndroidSTT");
        tts = new TextToSpeech(this, status -> {
            ttsReady = status == TextToSpeech.SUCCESS;
            if (ttsReady) tts.setSpeechRate(1.0f);
        });
        web.loadUrl("file:///android_asset/index.html");
    }

    private class TTSBridge {
        @JavascriptInterface public boolean available() { return ttsReady; }
        @JavascriptInterface public void stop() { runOnUiThread(() -> { if (tts != null) tts.stop(); }); }
        @JavascriptInterface public void speak(String text, String lang, float rate) {
            runOnUiThread(() -> {
                if (!ttsReady || tts == null) return;
                Locale locale = "it".equals(lang) ? Locale.ITALIAN : ("en".equals(lang) ? Locale.UK : new Locale("pt", "BR"));
                int result = tts.setLanguage(locale);
                tts.setSpeechRate(Math.max(0.5f, Math.min(1.5f, rate)));
                if (result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED)
                    tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "grammar-dual-tts");
                else Toast.makeText(MainActivity.this, "Instale a voz desse idioma nas configurações do Android.", Toast.LENGTH_LONG).show();
            });
        }
    }

    private class STTBridge {
        @JavascriptInterface public boolean available() { return SpeechRecognizer.isRecognitionAvailable(MainActivity.this); }
        @JavascriptInterface public void start(String lang, String id) {
            currentRequestId = id;
            runOnUiThread(() -> {
                if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.RECORD_AUDIO}, MIC_PERMISSION);
                    sendSTT(false, "", "Autorize o microfone e toque novamente.");
                    return;
                }
                if (!SpeechRecognizer.isRecognitionAvailable(MainActivity.this)) { sendSTT(false, "", "Reconhecimento de voz não disponível neste aparelho."); return; }
                try {
                    if (recognizer != null) recognizer.destroy();
                    recognizer = SpeechRecognizer.createSpeechRecognizer(MainActivity.this);
                    recognizer.setRecognitionListener(new RecognitionListener() {
                        public void onReadyForSpeech(Bundle p) {} public void onBeginningOfSpeech() {} public void onRmsChanged(float r) {} public void onBufferReceived(byte[] b) {} public void onEndOfSpeech() {}
                        public void onError(int e) { sendSTT(false, "", "Não consegui reconhecer a fala. Tente novamente."); }
                        public void onResults(Bundle b) { ArrayList<String> a = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION); sendSTT(a != null && !a.isEmpty(), a != null && !a.isEmpty() ? a.get(0) : "", ""); }
                        public void onPartialResults(Bundle b) {} public void onEvent(int t, Bundle p) {}
                    });
                    Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                    i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                    i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "it".equals(lang) ? "it-IT" : "en-US");
                    i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
                    recognizer.startListening(i);
                } catch (Exception ex) { sendSTT(false, "", "Falha ao iniciar o microfone."); }
            });
        }
        @JavascriptInterface public void stop() { runOnUiThread(() -> { if (recognizer != null) recognizer.cancel(); }); }
    }

    private void sendSTT(boolean ok, String words, String error) {
        String js = "window.onNativeSTT && window.onNativeSTT(" + JSONObject.quote(currentRequestId) + "," + ok + "," + JSONObject.quote(words) + "," + JSONObject.quote(error) + ");";
        runOnUiThread(() -> web.evaluateJavascript(js, null));
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == MIC_PERMISSION) {
            boolean granted = results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED;
            web.evaluateJavascript("window.onMicPermission && window.onMicPermission(" + granted + ");", null);
        }
    }
    @Override public void onBackPressed() { if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed(); }
    @Override protected void onDestroy() {
        if (recognizer != null) recognizer.destroy();
        if (tts != null) { tts.stop(); tts.shutdown(); }
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
