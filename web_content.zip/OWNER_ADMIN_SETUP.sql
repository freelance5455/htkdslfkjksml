-- GH MARKETPLACE OWNER ADMIN SETUP
-- Run in Supabase SQL Editor as project owner.
-- This grants owner access to the single UUID below, leaves RLS enabled,
-- and creates an RPC the website uses to check the signed-in user's owner status.

CREATE SCHEMA IF NOT EXISTS private;
REVOKE ALL ON SCHEMA private FROM PUBLIC, anon, authenticated;

CREATE TABLE IF NOT EXISTS private.gh_marketplace_owners (
  user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE private.gh_marketplace_owners ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON private.gh_marketplace_owners FROM PUBLIC, anon, authenticated;

CREATE OR REPLACE FUNCTION public.gh_is_marketplace_owner()
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER
SET search_path = ''
AS $$
  SELECT EXISTS (
    SELECT 1 FROM private.gh_marketplace_owners o
    WHERE o.user_id = (SELECT auth.uid())
  );
$$;
REVOKE ALL ON FUNCTION public.gh_is_marketplace_owner() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.gh_is_marketplace_owner() TO authenticated;

INSERT INTO private.gh_marketplace_owners (user_id)
VALUES ('45f200e4-5aea-4fe0-8854-465b0ab0ea00'::uuid)
ON CONFLICT (user_id) DO NOTHING;

-- Required columns used by the website; these additions preserve existing rows.
ALTER TABLE public.listings ADD COLUMN IF NOT EXISTS image_url text;
ALTER TABLE public.listings ADD COLUMN IF NOT EXISTS latitude double precision;
ALTER TABLE public.listings ADD COLUMN IF NOT EXISTS longitude double precision;
ALTER TABLE public.listings ADD COLUMN IF NOT EXISTS location text;
ALTER TABLE public.listings ADD COLUMN IF NOT EXISTS description text;
ALTER TABLE public.listings ADD COLUMN IF NOT EXISTS category text;
ALTER TABLE public.listings ADD COLUMN IF NOT EXISTS price numeric;
ALTER TABLE public.listings ADD COLUMN IF NOT EXISTS title text;
ALTER TABLE public.listings ADD COLUMN IF NOT EXISTS user_id uuid;
ALTER TABLE public.listings ADD COLUMN IF NOT EXISTS created_at timestamptz DEFAULT now();

-- Owner can read all listings and delete listings. Existing user policies remain.
DROP POLICY IF EXISTS "GH owner can read all listings" ON public.listings;
CREATE POLICY "GH owner can read all listings" ON public.listings
FOR SELECT TO authenticated USING ((SELECT public.gh_is_marketplace_owner()));
DROP POLICY IF EXISTS "GH owner can delete listings" ON public.listings;
CREATE POLICY "GH owner can delete listings" ON public.listings
FOR DELETE TO authenticated USING ((SELECT public.gh_is_marketplace_owner()));

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "GH owner can read all profiles" ON public.profiles;
CREATE POLICY "GH owner can read all profiles" ON public.profiles
FOR SELECT TO authenticated USING ((SELECT public.gh_is_marketplace_owner()));


-- Allow a signed-in user to delete only their own listings (RLS remains enabled).
ALTER TABLE public.listings ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Users can delete own listings" ON public.listings;
CREATE POLICY "Users can delete own listings" ON public.listings
FOR DELETE TO authenticated USING (auth.uid() = user_id);

NOTIFY pgrst, 'reload schema';

-- After running, verify the owner row with:
-- SELECT user_id FROM private.gh_marketplace_owners;
-- Sign in through the website and verify RPC returns true for that session.

-- Multi-photo listing support (up to 20 public image URLs per listing)
ALTER TABLE public.listings ADD COLUMN IF NOT EXISTS image_urls text[] NOT NULL DEFAULT '{}';

-- WhatsApp contact number per listing, stored in international format.
ALTER TABLE public.listings ADD COLUMN IF NOT EXISTS whatsapp_number text;

NOTIFY pgrst, 'reload schema';
