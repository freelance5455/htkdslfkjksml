/* =========================================================
   MUEEN - EXPORT.JS
   تصدير سجل الدرجات - متوافق مع Android / Spck WebView
========================================================= */

"use strict";

/* =========================================================
   STORAGE
========================================================= */

const STORAGE_KEY = "mueen_grades_export_context";

let exportData = null;
let activeObjectUrls = [];


/* =========================================================
   BASIC HELPERS
========================================================= */

function $(id) {
    return document.getElementById(id);
}


function log(...args) {
    console.log("MUEEN EXPORT:", ...args);
}


function showMessage(message, type = "info") {

    const box = $("messageBox");

    if (!box) {
        alert(message);
        return;
    }

    box.textContent = message;
    box.className = "message-box " + type;
    box.style.display = "block";

    clearTimeout(showMessage.timer);

    showMessage.timer = setTimeout(() => {

        box.style.display = "none";

    }, 4000);
}


/* =========================================================
   LOAD EXPORT DATA
========================================================= */

function loadExportData() {

    try {

        const raw =
            localStorage.getItem(
                STORAGE_KEY
            );

        if (!raw) {

            log(
                "No export data found"
            );

            return null;
        }

        const data =
            JSON.parse(raw);

        log(
            "EXPORT DATA:",
            data
        );

        return normalizeExportData(data);

    } catch (error) {

        console.error(
            "MUEEN EXPORT: Failed to load data",
            error
        );

        showMessage(
            "تعذر قراءة بيانات سجل الدرجات.",
            "error"
        );

        return null;
    }
}


/* =========================================================
   NORMALIZE DATA
========================================================= */

function normalizeExportData(data) {

    if (
        !data ||
        typeof data !== "object"
    ) {
        return null;
    }


    const normalized = {

        version:
            data.version || 1,

        createdAt:
            data.createdAt || Date.now(),

        weekName:
            data.weekName || "—",

        weekDates:
            data.weekDates || "—",

        subjectName:
            data.subjectName || "—",

        className:
            data.className || "—",

        evaluations:
            Array.isArray(data.evaluations)
                ? data.evaluations
                : [],

        rows:
            Array.isArray(data.rows)
                ? data.rows
                : [],

        attendanceMax:
            Number.isFinite(
                Number(data.attendanceMax)
            )
                ? Number(data.attendanceMax)
                : 10

    };


    if (
        normalized.attendanceMax < 0
    ) {

        normalized.attendanceMax = 10;

    }


    normalized.evaluations =
        normalized.evaluations.map(
            (item, index) => {

                return {

                    id:
                        item.id ??
                        ("evaluation_" + index),

                    name:
                        item.name ||
                        ("التقييم " + (index + 1)),

                    max:
                        Number(item.max) || 0

                };

            }
        );


    normalized.rows =
        normalized.rows.map(
            (row, index) => {

                const grades =
                    Array.isArray(row.grades)
                        ? row.grades
                        : [];


                const attendanceGrade =
                    row.attendanceGrade !== null &&
                    row.attendanceGrade !== undefined &&
                    row.attendanceGrade !== ""
                        ? Number(row.attendanceGrade)
                        : "";


                const absenceCount =
                    Number.isFinite(
                        Number(row.absenceCount)
                    )
                        ? Number(row.absenceCount)
                        : 0;


                const normalizedGrades =
                    normalized.evaluations.map(
                        evaluation => {

                            const found =
                                grades.find(
                                    grade =>
                                        String(
                                            grade.id
                                        ) ===
                                        String(
                                            evaluation.id
                                        )
                                );


                            return {

                                id:
                                    evaluation.id,

                                name:
                                    evaluation.name,

                                max:
                                    evaluation.max,

                                value:
                                    found &&
                                    found.value !== null &&
                                    found.value !== undefined
                                        ? found.value
                                        : ""

                            };

                        }
                    );


                /*
                 * المجموع:
                 *
                 * جميع التقييمات العادية
                 * +
                 * درجة الحضور.
                 *
                 * لا نعتمد على total القادم
                 * حتى لا يتأثر التصدير بالفلترة.
                 */

                const normalGradesTotal =
                    calculateRowTotal(
                        normalizedGrades
                    );


                const attendanceValue =
                    Number.isFinite(
                        attendanceGrade
                    )
                        ? attendanceGrade
                        : 0;


                const total =
                    normalGradesTotal +
                    attendanceValue;


                const maxTotal =
                    normalized.evaluations.reduce(
                        (sum, evaluation) =>
                            sum +
                            (
                                Number(
                                    evaluation.max
                                ) || 0
                            ),
                        0
                    ) +
                    normalized.attendanceMax;


                return {

                    number:
                        row.number ??
                        (index + 1),

                    name:
                        row.name ||
                        "—",

                    absenceCount,

                    attendanceGrade,

                    grades:
                        normalizedGrades,

                    total,

                    maxTotal

                };

            }
        );


    return normalized;
}


/* =========================================================
   CALCULATE TOTAL
========================================================= */

function calculateRowTotal(grades) {

    if (!Array.isArray(grades)) {
        return 0;
    }


    return grades.reduce(
        (sum, grade) => {

            const value =
                parseFloat(
                    grade.value
                );

            if (
                Number.isFinite(value)
            ) {

                return sum + value;

            }

            return sum;

        },
        0
    );
}


/* =========================================================
   PAGE RENDER
========================================================= */

function renderExportPage() {

    if (!exportData) {
        return;
    }


    setText(
        "exportTitle",
        "سجل الدرجات"
    );


    setText(
        "className",
        exportData.className
    );


    setText(
        "subjectName",
        exportData.subjectName
    );


    setText(
        "weekName",
        exportData.weekName
    );


    setText(
        "weekDates",
        exportData.weekDates
    );


    setText(
        "studentsCount",
        exportData.rows.length
    );


    setText(
        "evaluationsCount",
        exportData.evaluations.length
    );


    const maxTotal =
        exportData.evaluations.reduce(
            (sum, evaluation) =>
                sum +
                Number(
                    evaluation.max || 0
                ),
            0
        ) +
        Number(
            exportData.attendanceMax || 0
        );


    setText(
        "maxTotal",
        formatDisplayNumber(maxTotal)
    );


    setText(
        "previewCount",
        exportData.rows.length
    );


    renderPreviewTable();
}


function setText(id, value) {

    const element =
        $(id);

    if (element) {

        element.textContent =
            value === undefined ||
            value === null
                ? "—"
                : String(value);
    }
}


/* =========================================================
   PREVIEW TABLE
========================================================= */

function renderPreviewTable() {

    const head =
        $("previewTableHead");

    const body =
        $("previewTableBody");


    if (
        !head ||
        !body ||
        !exportData
    ) {
        return;
    }


    head.innerHTML = "";
    body.innerHTML = "";


    const headerRow =
        document.createElement("tr");


    /* -----------------------------------------------------
       م
    ----------------------------------------------------- */

    addCell(
        headerRow,
        "م",
        "th",
        "number-header"
    );


    /* -----------------------------------------------------
       اسم الطالب
    ----------------------------------------------------- */

    addCell(
        headerRow,
        "اسم الطالب",
        "th",
        "student-header"
    );


    /* -----------------------------------------------------
       أيام الغياب
    ----------------------------------------------------- */

    addCell(
        headerRow,
        "أيام الغياب",
        "th",
        "absence-header"
    );


    /* -----------------------------------------------------
       الحضور
       عنوان + الحد الأقصى في سطرين
    ----------------------------------------------------- */

    addAttendanceHeader(
        headerRow
    );


    /* -----------------------------------------------------
       التقييمات العادية
    ----------------------------------------------------- */

    exportData.evaluations.forEach(
        evaluation => {

            const th =
                document.createElement("th");


            const title =
                document.createElement("span");

            title.className =
                "evaluation-header-name";

            title.textContent =
                evaluation.name;


            const max =
                document.createElement("span");

            max.className =
                "evaluation-header-max";

            max.textContent =
                formatDisplayNumber(
                    evaluation.max
                );


            th.appendChild(title);
            th.appendChild(max);


            headerRow.appendChild(th);

        }
    );


    /* -----------------------------------------------------
       المجموع
    ----------------------------------------------------- */

    addCell(
        headerRow,
        "المجموع",
        "th",
        "total-header"
    );


    head.appendChild(
        headerRow
    );


    /* =====================================================
       STUDENTS
    ===================================================== */

    exportData.rows.forEach(
        (student, index) => {

            const row =
                document.createElement("tr");


            /* م */

            addCell(
                row,
                student.number ??
                (index + 1),
                "td",
                "number-cell"
            );


            /* اسم الطالب */

            addCell(
                row,
                student.name || "—",
                "td",
                "student-name"
            );


            /* أيام الغياب */

            addCell(
                row,
                formatDisplayNumber(
                    student.absenceCount
                ),
                "td",
                "absence-cell"
            );


            /* درجة الحضور */

            addCell(
                row,

                student.attendanceGrade === "" ||
                student.attendanceGrade === null ||
                student.attendanceGrade === undefined
                    ? "—"
                    : formatDisplayNumber(
                        student.attendanceGrade
                    ),

                "td",
                "attendance-cell"
            );


            /* التقييمات العادية */

            student.grades.forEach(
                grade => {

                    addCell(
                        row,

                        grade.value === "" ||
                        grade.value === null ||
                        grade.value === undefined
                            ? "—"
                            : grade.value,

                        "td",
                        "grade-cell"
                    );

                }
            );


            /* المجموع */

            addCell(
                row,

                formatDisplayNumber(
                    student.total
                ),

                "td",
                "total-cell"
            );


            body.appendChild(
                row
            );

        }
    );
}


/* =========================================================
   ATTENDANCE HEADER
========================================================= */

function addAttendanceHeader(row) {

    const th =
        document.createElement("th");


    th.className =
        "attendance-header";


    const title =
        document.createElement("span");

    title.className =
        "attendance-header-title";

    title.textContent =
        "الحضور";


    const max =
        document.createElement("span");

    max.className =
        "attendance-header-max";

    max.textContent =
        formatDisplayNumber(
            exportData.attendanceMax
        );


    th.appendChild(
        title
    );

    th.appendChild(
        max
    );


    row.appendChild(
        th
    );
}


/* =========================================================
   DISPLAY NUMBER
========================================================= */

function formatDisplayNumber(value) {

    if (
        value === null ||
        value === undefined ||
        value === ""
    ) {

        return "—";
    }


    const number =
        Number(value);


    if (
        !Number.isFinite(number)
    ) {

        return String(value);
    }


    if (
        Number.isInteger(number)
    ) {

        return String(number);
    }


    return String(
        Math.round(
            number * 100
        ) / 100
    );
}


/* =========================================================
   ADD CELL
========================================================= */

function addCell(
    row,
    value,
    type = "td",
    className = ""
) {

    const cell =
        document.createElement(type);


    if (className) {

        cell.className =
            className;
    }


    cell.textContent =
        value === undefined ||
        value === null
            ? "—"
            : String(value);


    row.appendChild(
        cell
    );
}


/* =========================================================
   FILE NAME
========================================================= */

function cleanFileName(name) {

    return String(name || "")
        .replace(
            /[\\/:*?"<>|]/g,
            "-"
        )
        .replace(
            /\s+/g,
            " "
        )
        .trim();
}


function getBaseFileName() {

    const parts = [

        "سجل الدرجات",

        exportData?.className ||
        "الصف",

        exportData?.subjectName ||
        "المادة",

        exportData?.weekName ||
        "الأسبوع"

    ];


    return cleanFileName(
        parts.join(" - ")
    );
}


/* =========================================================
   OBJECT URL MANAGEMENT
========================================================= */

function createFileUrl(blob) {

    try {

        const url =
            URL.createObjectURL(
                blob
            );


        activeObjectUrls.push(
            url
        );


        log(
            "Object URL created:",
            url
        );


        return url;

    } catch (error) {

        console.error(
            "MUEEN: createObjectURL failed",
            error
        );

        return null;
    }
}


/* =========================================================
   DIRECT DOWNLOAD
========================================================= */

async function directDownload(
    blob,
    filename
) {

    if (window.MueenNative?.available && typeof window.MueenNative.saveFileBase64 === "function") {
        try {
            const result = await new Promise((resolve, reject) => {
                const reader = new FileReader();
                reader.onerror = () => reject(new Error("تعذر قراءة الملف قبل الحفظ."));
                reader.onload = () => {
                    const data = String(reader.result || "");
                    const comma = data.indexOf(",");
                    const base64 = comma >= 0 ? data.slice(comma + 1) : data;
                    window.MueenNative.saveFileBase64(
                        base64,
                        filename,
                        blob.type || "application/octet-stream"
                    ).then(resolve).catch(reject);
                };
                reader.readAsDataURL(blob);
            });

            showMessage(
                result || "تم حفظ الملف في مجلد التنزيلات.",
                "success"
            );
            return true;
        } catch (error) {
            console.warn("MUEEN native file save failed:", error);
        }
    }

    // Web Share هو المسار الأكثر توافقًا مع APK المبني من WebView.
    try {
        if (
            typeof File === "function" &&
            navigator.share &&
            navigator.canShare
        ) {
            const file = new File(
                [blob],
                filename,
                { type: blob.type || "application/octet-stream" }
            );

            if (navigator.canShare({ files: [file] })) {
                await navigator.share({
                    title: "ملف من مُعين",
                    text: filename,
                    files: [file]
                });
                showMessage("تم إرسال الملف إلى خيارات المشاركة في الهاتف.", "success");
                return true;
            }
        }
    } catch (error) {
        if (error?.name !== "AbortError") {
            console.warn("MUEEN share failed:", error);
        } else {
            return true;
        }
    }

    // لا نستخدم <a download> مع blob داخل ToApp؛ هذا هو سبب رسالة
    // Can only download HTTP/HTTPS URLs في النسخ التي ترفض blob:.
    const opened = openFile(blob);
    if (opened) {
        showMessage(
            "تم فتح الملف. إذا لم يفتح تلقائيًا، استخدم خيار الطباعة أو المشاركة من الهاتف.",
            "success"
        );
        return true;
    }

    return false;
}

/* =========================================================
   OPEN FILE
========================================================= */

function openFile(blob) {

    log(
        "OPEN FILE:",
        blob.size,
        blob.type
    );


    const url =
        createFileUrl(
            blob
        );


    if (!url) {
        return false;
    }


    try {

        const newWindow =
            window.open(
                url,
                "_blank"
            );


        if (newWindow) {

            log(
                "OPEN FILE: window.open succeeded"
            );

            return true;
        }

    } catch (error) {

        console.warn(
            "MUEEN: window.open failed",
            error
        );
    }


    try {

        const link =
            document.createElement(
                "a"
            );


        link.href =
            url;

        link.target =
            "_blank";

        link.rel =
            "noopener";

        link.style.display =
            "none";


        document.body.appendChild(
            link
        );


        link.click();


        setTimeout(
            () => {

                try {
                    link.remove();
                } catch (_) {}

            },
            3000
        );


        return true;

    } catch (error) {

        console.error(
            "MUEEN: open link failed",
            error
        );

        return false;
    }
}


/* =========================================================
   ANDROID FALLBACK PANEL
========================================================= */

function showFileFallback(
    blob,
    filename
) {

    log(
        "SHOWING FILE FALLBACK"
    );


    const old =
        document.getElementById(
            "mueenFileFallback"
        );


    if (old) {
        old.remove();
    }


    const url =
        createFileUrl(
            blob
        );


    if (!url) {
        return;
    }


    const overlay =
        document.createElement(
            "div"
        );


    overlay.id =
        "mueenFileFallback";


    overlay.style.cssText = `
        position:fixed;
        inset:0;
        z-index:999999;
        background:rgba(0,0,0,.65);
        display:flex;
        align-items:center;
        justify-content:center;
        padding:20px;
        box-sizing:border-box;
        direction:rtl;
        font-family:system-ui,-apple-system,"Segoe UI",Tahoma,Arial,sans-serif;
    `;


    const box =
        document.createElement(
            "div"
        );


    box.style.cssText = `
        width:min(420px,100%);
        background:#fff;
        border-radius:24px;
        padding:25px;
        box-sizing:border-box;
        text-align:center;
        box-shadow:0 20px 60px rgba(0,0,0,.3);
    `;


    const title =
        document.createElement(
            "div"
        );


    title.textContent =
        "تم إنشاء الملف بنجاح";


    title.style.cssText = `
        font-size:22px;
        font-weight:800;
        color:#073B46;
        margin-bottom:10px;
    `;


    const text =
        document.createElement(
            "div"
        );


    text.textContent =
        filename;


    text.style.cssText = `
        font-size:15px;
        color:#687B80;
        line-height:1.7;
        margin-bottom:20px;
        word-break:break-word;
    `;


    const buttons =
        document.createElement(
            "div"
        );


    buttons.style.cssText = `
        display:flex;
        flex-direction:column;
        gap:10px;
    `;


    const download =
        document.createElement(
            "button"
        );


    download.textContent =
        "⬇️ تنزيل الملف";


    styleFallbackButton(
        download,
        true
    );


    download.onclick = () => {

        directDownload(
            blob,
            filename
        );

    };


    const share =
        document.createElement(
            "button"
        );

    share.textContent =
        "📤 مشاركة / حفظ في الهاتف";

    styleFallbackButton(
        share,
        true
    );

    share.onclick = async () => {
        try {
            const file = new File(
                [blob],
                filename,
                {
                    type:
                        blob.type ||
                        "application/octet-stream"
                }
            );

            if (
                navigator.share &&
                navigator.canShare &&
                navigator.canShare({ files: [file] })
            ) {
                await navigator.share({
                    title: "ملف من مُعين",
                    text: filename,
                    files: [file]
                });
                return;
            }

            directDownload(
                blob,
                filename
            );
        } catch (error) {
            console.warn(
                "MUEEN share failed:",
                error
            );
            directDownload(
                blob,
                filename
            );
        }
    };


    const open =
        document.createElement(
            "button"
        );


    open.textContent =
        "📂 فتح الملف";


    styleFallbackButton(
        open,
        false
    );


    open.onclick = () => {

        openFile(
            blob
        );

    };


    const close =
        document.createElement(
            "button"
        );


    close.textContent =
        "إغلاق";


    styleFallbackButton(
        close,
        false
    );


    close.onclick = () => {

        overlay.remove();

    };


    buttons.appendChild(
        download
    );

    buttons.appendChild(
        share
    );

    buttons.appendChild(
        open
    );

    buttons.appendChild(
        close
    );


    box.appendChild(
        title
    );

    box.appendChild(
        text
    );

    box.appendChild(
        buttons
    );


    overlay.appendChild(
        box
    );


    document.body.appendChild(
        overlay
    );


    log(
        "FALLBACK PANEL READY"
    );
}


function styleFallbackButton(
    button,
    primary
) {

    button.style.cssText = `

        width:100%;
        min-height:52px;
        border-radius:15px;
        border:1px solid #E3E9E7;
        padding:12px 16px;
        font-size:17px;
        font-weight:700;
        cursor:pointer;

        ${
            primary
                ? `
                    background:#073B46;
                    color:#fff;
                  `
                : `
                    background:#F5F7F6;
                    color:#073B46;
                  `
        }

    `;
}


/* =========================================================
   SAVE FILE
========================================================= */

async function saveFileToDevice(
    blob,
    filename
) {

    log(
        "SAVE:",
        filename,
        blob.size,
        blob.type
    );


    let file = null;


    try {

        if (
            typeof File ===
            "function"
        ) {

            file =
                new File(
                    [blob],
                    filename,
                    {
                        type:
                            blob.type ||
                            "application/octet-stream"
                    }
                );


            log(
                "SAVE: File object created"
            );
        }

    } catch (error) {

        console.warn(
            "MUEEN: File creation failed",
            error
        );
    }


    const downloaded =
        await directDownload(
            blob,
            filename
        );


    if (downloaded) {

        log(
            "SAVE: direct download requested"
        );


        setTimeout(
            () => {

                showFileFallback(
                    blob,
                    filename
                );

            },
            900
        );


        return true;
    }


    const opened =
        openFile(
            blob
        );


    if (opened) {

        log(
            "SAVE: open fallback succeeded"
        );

        return true;
    }


    // في ToApp قد يمنع WebView تنزيل blob: نهائيًا.
    // لملفات PDF نستخدم صفحة التصدير نفسها كمسار طباعة/حفظ PDF.
    if (String(filename).toLowerCase().endsWith(".pdf")) {
        try {
            if (window.MueenNative?.available && typeof window.MueenNative.printHtml === "function") {
                window.MueenNative.printHtml(document.documentElement.outerHTML, "سجل الدرجات - مُعين");
                showMessage("تم فتح الطباعة لحفظ السجل بصيغة PDF.", "success");
                return true;
            }

            if (typeof window.print === "function") {
                showMessage("تم تجهيز السجل. اختر حفظ بصيغة PDF من نافذة الطباعة.", "success");
                window.setTimeout(() => window.print(), 120);
                return true;
            }
        } catch (error) {
            console.warn("MUEEN print fallback failed:", error);
        }
    }

    showFileFallback(
        blob,
        filename
    );


    return false;
}


/* =========================================================
   PDF
========================================================= */

async function createPdfBlob() {

    log(
        "Creating PDF..."
    );


    if (
        !window.jspdf ||
        !window.jspdf.jsPDF
    ) {

        throw new Error(
            "jsPDF غير متاح."
        );
    }


    if (
        typeof window.html2canvas !==
        "function"
    ) {

        throw new Error(
            "html2canvas غير متاح."
        );
    }


    const jsPDF =
        window.jspdf.jsPDF;


    const table =
        $("previewTable");


    if (!table) {

        throw new Error(
            "جدول المعاينة غير موجود."
        );
    }


    const pdfArea =
        document.createElement(
            "div"
        );


    pdfArea.style.cssText = `
        position:fixed;
        left:-100000px;
        top:0;
        width:1100px;
        background:#ffffff;
        padding:40px;
        box-sizing:border-box;
        direction:rtl;
        font-family:Arial,Tahoma,sans-serif;
        color:#18343A;
    `;


    const title =
        document.createElement(
            "h1"
        );


    title.textContent =
        "سجل الدرجات";


    title.style.cssText = `
        text-align:center;
        margin:0 0 20px;
        font-size:30px;
        color:#073B46;
    `;


    const info =
        document.createElement(
            "div"
        );


    info.style.cssText = `
        text-align:center;
        margin-bottom:25px;
        font-size:18px;
        line-height:2;
    `;


    info.innerHTML = `
        <div>
            <strong>الصف:</strong>
            ${escapeHtml(exportData.className)}
        </div>

        <div>
            <strong>المادة:</strong>
            ${escapeHtml(exportData.subjectName)}
        </div>

        <div>
            <strong>الأسبوع:</strong>
            ${escapeHtml(exportData.weekName)}
        </div>

        <div>
            <strong>التاريخ:</strong>
            ${escapeHtml(exportData.weekDates)}
        </div>
    `;


    const clonedTable =
        table.cloneNode(true);


    clonedTable.style.cssText = `
        width:100%;
        border-collapse:collapse;
        direction:rtl;
        font-size:16px;
    `;


    const cells =
        clonedTable.querySelectorAll(
            "th,td"
        );


    cells.forEach(
        cell => {

            cell.style.border =
                "1px solid #9AA9AC";

            cell.style.padding =
                "10px";

            cell.style.textAlign =
                "center";

            cell.style.verticalAlign =
                "middle";

        }
    );


    pdfArea.appendChild(
        title
    );

    pdfArea.appendChild(
        info
    );

    pdfArea.appendChild(
        clonedTable
    );


    document.body.appendChild(
        pdfArea
    );


    try {

        const canvas =
            await html2canvas(
                pdfArea,
                {
                    scale:2,
                    useCORS:true,
                    backgroundColor:"#ffffff"
                }
            );


        const imgData =
            canvas.toDataURL(
                "image/jpeg",
                0.95
            );


        const pdf =
            new jsPDF(
                "p",
                "mm",
                "a4"
            );


        const pageWidth =
            pdf.internal.pageSize.getWidth();


        const pageHeight =
            pdf.internal.pageSize.getHeight();


        const margin =
            8;


        const usableWidth =
            pageWidth -
            margin * 2;


        const imageHeight =
            canvas.height *
            usableWidth /
            canvas.width;


        let remaining =
            imageHeight;


        let position =
            margin;


        pdf.addImage(
            imgData,
            "JPEG",
            margin,
            position,
            usableWidth,
            imageHeight
        );


        remaining -=
            pageHeight -
            margin * 2;


        while (
            remaining > 0
        ) {

            position =
                position -
                (
                    pageHeight -
                    margin * 2
                );


            pdf.addPage();


            pdf.addImage(
                imgData,
                "JPEG",
                margin,
                position,
                usableWidth,
                imageHeight
            );


            remaining -=
                pageHeight -
                margin * 2;
        }


        return pdf.output(
            "blob"
        );

    } finally {

        try {
            pdfArea.remove();
        } catch (_) {}

    }
}


/* =========================================================
   ESCAPE HTML
========================================================= */

function escapeHtml(value) {

    return String(
        value ?? ""
    )
        .replace(
            /&/g,
            "&amp;"
        )
        .replace(
            /</g,
            "&lt;"
        )
        .replace(
            />/g,
            "&gt;"
        )
        .replace(
            /"/g,
            "&quot;"
        )
        .replace(
            /'/g,
            "&#039;"
        );
}


/* =========================================================
   EXPORT PDF
========================================================= */

async function exportPdf() {

    if (!exportData) {

        showMessage(
            "لا توجد بيانات للتصدير.",
            "error"
        );

        return;
    }


    try {

        showMessage(
            "جارٍ تجهيز ملف PDF...",
            "info"
        );


        const blob =
            await createPdfBlob();


        const filename =
            getBaseFileName() +
            ".pdf";


        log(
            "PDF:",
            blob.size,
            filename
        );


        await saveFileToDevice(
            blob,
            filename
        );

    } catch (error) {

        console.error(
            "MUEEN PDF ERROR:",
            error
        );


        showMessage(
            "حدث خطأ أثناء إنشاء ملف PDF.",
            "error"
        );
    }
}


/* =========================================================
   XLSX
========================================================= */

function xmlEscape(value) {

    return String(
        value ?? ""
    )
        .replace(
            /&/g,
            "&amp;"
        )
        .replace(
            /</g,
            "&lt;"
        )
        .replace(
            />/g,
            "&gt;"
        )
        .replace(
            /"/g,
            "&quot;"
        )
        .replace(
            /'/g,
            "&apos;"
        );
}


/* =========================================================
   CRC32
========================================================= */

function crc32(bytes) {

    let table =
        crc32.table;


    if (!table) {

        table =
            new Uint32Array(
                256
            );


        for (
            let n = 0;
            n < 256;
            n++
        ) {

            let c =
                n;


            for (
                let k = 0;
                k < 8;
                k++
            ) {

                c =
                    (c & 1)
                        ? (
                            0xEDB88320 ^
                            (c >>> 1)
                          )
                        : c >>> 1;
            }


            table[n] =
                c >>> 0;
        }


        crc32.table =
            table;
    }


    let crc =
        0xFFFFFFFF;


    for (
        let i = 0;
        i < bytes.length;
        i++
    ) {

        crc =
            table[
                (crc ^ bytes[i]) &
                0xFF
            ] ^
            (crc >>> 8);
    }


    return (
        crc ^
        0xFFFFFFFF
    ) >>> 0;
}


/* =========================================================
   UTF-8
========================================================= */

function utf8(text) {

    return new TextEncoder()
        .encode(text);
}


/* =========================================================
   ZIP STORE
========================================================= */

function makeZip(files) {

    const localParts = [];
    const centralParts = [];

    let offset = 0;


    files.forEach(
        file => {

            const nameBytes =
                utf8(
                    file.name
                );


            const dataBytes =
                typeof file.data ===
                "string"
                    ? utf8(
                        file.data
                    )
                    : file.data;


            const crc =
                crc32(
                    dataBytes
                );


            const local =
                new Uint8Array(
                    30 +
                    nameBytes.length +
                    dataBytes.length
                );


            const view =
                new DataView(
                    local.buffer
                );


            view.setUint32(
                0,
                0x04034b50,
                true
            );

            view.setUint16(
                4,
                20,
                true
            );

            view.setUint16(
                6,
                0,
                true
            );

            view.setUint16(
                8,
                0,
                true
            );

            view.setUint16(
                10,
                0,
                true
            );

            view.setUint16(
                12,
                0,
                true
            );

            view.setUint32(
                14,
                crc,
                true
            );

            view.setUint32(
                18,
                dataBytes.length,
                true
            );

            view.setUint32(
                22,
                dataBytes.length,
                true
            );

            view.setUint16(
                26,
                nameBytes.length,
                true
            );

            view.setUint16(
                28,
                0,
                true
            );


            local.set(
                nameBytes,
                30
            );


            local.set(
                dataBytes,
                30 +
                nameBytes.length
            );


            localParts.push(
                local
            );


            const central =
                new Uint8Array(
                    46 +
                    nameBytes.length
                );


            const cv =
                new DataView(
                    central.buffer
                );


            cv.setUint32(
                0,
                0x02014b50,
                true
            );

            cv.setUint16(
                4,
                20,
                true
            );

            cv.setUint16(
                6,
                20,
                true
            );

            cv.setUint16(
                8,
                0,
                true
            );

            cv.setUint16(
                10,
                0,
                true
            );

            cv.setUint16(
                12,
                0,
                true
            );

            cv.setUint16(
                14,
                0,
                true
            );

            cv.setUint32(
                16,
                crc,
                true
            );

            cv.setUint32(
                20,
                dataBytes.length,
                true
            );

            cv.setUint32(
                24,
                dataBytes.length,
                true
            );

            cv.setUint16(
                28,
                nameBytes.length,
                true
            );

            cv.setUint16(
                30,
                0,
                true
            );

            cv.setUint16(
                32,
                0,
                true
            );

            cv.setUint16(
                34,
                0,
                true
            );

            cv.setUint16(
                36,
                0,
                true
            );

            cv.setUint16(
                38,
                0,
                true
            );

            cv.setUint32(
                42,
                offset,
                true
            );


            central.set(
                nameBytes,
                46
            );


            centralParts.push(
                central
            );


            offset +=
                local.length;

        }
    );


    const centralOffset =
        offset;


    const centralSize =
        centralParts.reduce(
            (sum, part) =>
                sum +
                part.length,
            0
        );


    const end =
        new Uint8Array(
            22
        );


    const ev =
        new DataView(
            end.buffer
        );


    ev.setUint32(
        0,
        0x06054b50,
        true
    );

    ev.setUint16(
        4,
        0,
        true
    );

    ev.setUint16(
        6,
        0,
        true
    );

    ev.setUint16(
        8,
        files.length,
        true
    );

    ev.setUint16(
        10,
        files.length,
        true
    );

    ev.setUint32(
        12,
        centralSize,
        true
    );

    ev.setUint32(
        16,
        centralOffset,
        true
    );

    ev.setUint16(
        20,
        0,
        true
    );


    return new Blob(
        [
            ...localParts,
            ...centralParts,
            end
        ],
        {
            type:
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        }
    );
}


/* =========================================================
   XLSX XML
========================================================= */

function createXlsxBlob() {

    const rows = [];


    rows.push([
        "سجل الدرجات"
    ]);


    rows.push([
        "الصف",
        exportData.className
    ]);


    rows.push([
        "المادة",
        exportData.subjectName
    ]);


    rows.push([
        "الأسبوع",
        exportData.weekName
    ]);


    rows.push([
        "التاريخ",
        exportData.weekDates
    ]);


    rows.push([]);


    rows.push([

        "م",

        "اسم الطالب",

        "أيام الغياب",

        "الحضور (" +
        formatDisplayNumber(
            exportData.attendanceMax
        ) +
        ")",

        ...exportData.evaluations.map(
            evaluation =>
                evaluation.name +
                " (" +
                formatDisplayNumber(
                    evaluation.max
                ) +
                ")"
        ),

        "المجموع"

    ]);


    exportData.rows.forEach(
        (student, index) => {

            rows.push([

                student.number ??
                (index + 1),

                student.name,

                student.absenceCount,

                student.attendanceGrade === ""
                    ? ""
                    : student.attendanceGrade,

                ...student.grades.map(
                    grade =>
                        grade.value === ""
                            ? ""
                            : grade.value
                ),

                student.total

            ]);

        }
    );


    const sheetRows =
        rows.map(
            (row, rowIndex) => {

                const cells =
                    row.map(
                        (
                            value,
                            colIndex
                        ) => {

                            const cellRef =
                                columnName(
                                    colIndex + 1
                                ) +
                                (
                                    rowIndex + 1
                                );


                            const numeric =
                                typeof value ===
                                "number";


                            if (numeric) {

                                return `
                                    <c
                                        r="${cellRef}"
                                        t="n"
                                    >
                                        <v>${value}</v>
                                    </c>
                                `;

                            }


                            return `
                                <c
                                    r="${cellRef}"
                                    t="inlineStr"
                                >
                                    <is>
                                        <t>
                                            ${xmlEscape(value)}
                                        </t>
                                    </is>
                                </c>
                            `;

                        }
                    ).join("");


                return `
                    <row r="${rowIndex + 1}">
                        ${cells}
                    </row>
                `;

            }
        ).join("");


    const sheet =
        `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
        <worksheet
            xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"
            xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"
        >
            <sheetData>
                ${sheetRows}
            </sheetData>
        </worksheet>`;


    const workbook =
        `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
        <workbook
            xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"
            xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"
        >
            <sheets>
                <sheet
                    name="سجل الدرجات"
                    sheetId="1"
                    r:id="rId1"
                />
            </sheets>
        </workbook>`;


    const rels =
        `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
        <Relationships
            xmlns="http://schemas.openxmlformats.org/package/2006/relationships"
        >
            <Relationship
                Id="rId1"
                Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument"
                Target="xl/workbook.xml"
            />
        </Relationships>`;


    const workbookRels =
        `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
        <Relationships
            xmlns="http://schemas.openxmlformats.org/package/2006/relationships"
        >
            <Relationship
                Id="rId1"
                Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet"
                Target="worksheets/sheet1.xml"
            />
        </Relationships>`;


    const contentTypes =
        `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
        <Types
            xmlns="http://schemas.openxmlformats.org/package/2006/content-types"
        >
            <Default
                Extension="rels"
                ContentType="application/vnd.openxmlformats-package.relationships+xml"
            />

            <Default
                Extension="xml"
                ContentType="application/xml"
            />

            <Override
                PartName="/xl/workbook.xml"
                ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"
            />

            <Override
                PartName="/xl/worksheets/sheet1.xml"
                ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"
            />
        </Types>`;


    return makeZip([

        {
            name:
                "[Content_Types].xml",

            data:
                contentTypes
        },

        {
            name:
                "_rels/.rels",

            data:
                rels
        },

        {
            name:
                "xl/workbook.xml",

            data:
                workbook
        },

        {
            name:
                "xl/_rels/workbook.xml.rels",

            data:
                workbookRels
        },

        {
            name:
                "xl/worksheets/sheet1.xml",

            data:
                sheet
        }

    ]);
}


/* =========================================================
   EXCEL COLUMN NAME
========================================================= */

function columnName(number) {

    let result = "";


    while (
        number > 0
    ) {

        const remainder =
            (
                number - 1
            ) % 26;


        result =
            String.fromCharCode(
                65 +
                remainder
            ) +
            result;


        number =
            Math.floor(
                (
                    number - 1
                ) / 26
            );
    }


    return result;
}


/* =========================================================
   EXPORT EXCEL
========================================================= */

async function exportExcel() {

    if (!exportData) {

        showMessage(
            "لا توجد بيانات للتصدير.",
            "error"
        );

        return;
    }


    try {

        showMessage(
            "جارٍ تجهيز ملف Excel...",
            "info"
        );


        const blob =
            createXlsxBlob();


        const filename =
            getBaseFileName() +
            ".xlsx";


        log(
            "XLSX:",
            blob.size,
            filename
        );


        await saveFileToDevice(
            blob,
            filename
        );

    } catch (error) {

        console.error(
            "MUEEN XLSX ERROR:",
            error
        );


        showMessage(
            "حدث خطأ أثناء إنشاء ملف Excel.",
            "error"
        );
    }
}


/* =========================================================
   PRINT
========================================================= */

function printPage() {

    window.print();
}


/* =========================================================
   MAIN NAVIGATION
========================================================= */

function goMain(page) {

    const currentPage =
        window.location.pathname
            .split("/")
            .pop()
            .toLowerCase();


    if (
        currentPage ===
            "home.html" ||
        currentPage === ""
    ) {

        window.location.href =
            page;

        return;
    }


    window.location.replace(
        page
    );
}


/* =========================================================
   BACK
========================================================= */

function goBack() {

    window.location.replace(
        "grades.html"
    );
}


/* =========================================================
   EMPTY STATE
========================================================= */

function showEmptyState() {

    const empty =
        $("emptyState");


    const preview =
        $("previewTable");


    if (empty) {

        empty.style.display =
            "block";
    }


    if (preview) {

        preview.style.display =
            "none";
    }
}


/* =========================================================
   MAIN NAVIGATION EVENTS
========================================================= */

function bindMainNavigation() {

    const homeNavigation =
        $("homeNavigation");

    const attendanceNavigation =
        $("attendanceNavigation");

    const studentsNavigation =
        $("studentsNavigation");

    const scheduleNavigation =
        $("scheduleNavigation");

    const gradesNavigation =
        $("gradesNavigation");

    const reportsNavigation =
        $("reportsNavigation");


    if (homeNavigation) {

        homeNavigation.addEventListener(
            "click",
            () => {

                goMain(
                    "home.html"
                );

            }
        );

    }


    if (attendanceNavigation) {

        attendanceNavigation.addEventListener(
            "click",
            () => {

                goMain(
                    "attendance.html"
                );

            }
        );

    }


    if (studentsNavigation) {

        studentsNavigation.addEventListener(
            "click",
            () => {

                goMain(
                    "students.html"
                );

            }
        );

    }


    if (scheduleNavigation) {

        scheduleNavigation.addEventListener(
            "click",
            () => {

                goMain(
                    "schedule.html"
                );

            }
        );

    }


    if (gradesNavigation) {

        gradesNavigation.addEventListener(
            "click",
            () => {

                goMain(
                    "grades.html"
                );

            }
        );

    }


    if (reportsNavigation) {

        reportsNavigation.addEventListener(
            "click",
            () => {

                goMain(
                    "reports.html"
                );

            }
        );

    }
}


/* =========================================================
   SCREENSHOT PREVIEW
   عرض التقرير فقط لالتقاط لقطة شاشة
========================================================= */

function openScreenshotPreview() {

    if (!exportData) {
        showMessage(
            "لا توجد بيانات جاهزة لعرض التقرير.",
            "error"
        );
        return;
    }

    const source = document.querySelector(".page-container");

    if (!source) {
        showMessage(
            "تعذر تجهيز عرض التقرير حاليًا.",
            "error"
        );
        return;
    }

    const overlay = document.createElement("div");
    overlay.className = "screenshot-preview-overlay";
    overlay.setAttribute("role", "dialog");
    overlay.setAttribute("aria-modal", "true");
    overlay.innerHTML = `
        <div class="screenshot-preview-shell">
            <div class="screenshot-preview-toolbar">
                <div>
                    <strong>معاينة التقرير</strong>
                    <span>يمكنك الآن التقاط لقطة شاشة للتقرير</span>
                </div>
                <button type="button" class="screenshot-close" aria-label="إغلاق">×</button>
            </div>
            <div class="screenshot-preview-content"></div>
            <div class="screenshot-preview-hint">
                📱 بعد التقاط الشاشة اضغط «إغلاق» للعودة إلى مُعين.
            </div>
        </div>
    `;

    const content = overlay.querySelector(".screenshot-preview-content");
    const clone = source.cloneNode(true);

    clone.querySelectorAll(".actions-section, .bottom-navigation, .page-footer, #messageBox")
        .forEach(el => el.remove());

    content.appendChild(clone);
    document.body.appendChild(overlay);
    document.body.classList.add("screenshot-preview-open");

    const close = () => {
        overlay.remove();
        document.body.classList.remove("screenshot-preview-open");
    };

    overlay.querySelector(".screenshot-close")?.addEventListener("click", close);

    overlay.addEventListener("click", event => {
        if (event.target === overlay) close();
    });

    document.addEventListener("keydown", function esc(event) {
        if (event.key === "Escape") {
            close();
            document.removeEventListener("keydown", esc);
        }
    });

    requestAnimationFrame(() => {
        overlay.querySelector(".screenshot-close")?.focus();
    });
}


/* =========================================================
   PHONE PRINT
========================================================= */
function printReport(mode = "pdf") {
    document.body.classList.remove("print-excel-mode", "print-pdf-mode");
    document.body.classList.add(mode === "excel" ? "print-excel-mode" : "print-pdf-mode");
    if (window.MueenNative?.available && typeof window.MueenNative.printHtml === "function") {
        try { window.MueenNative.printHtml(document.documentElement.outerHTML, mode === "excel" ? "سجل الدرجات - مُعين" : "سجل الدرجات PDF - مُعين"); return; } catch (_) {}
    }
    setTimeout(() => { try { window.print(); } finally { setTimeout(() => document.body.classList.remove("print-excel-mode", "print-pdf-mode"), 500); } }, 120);
}

/* =========================================================
   BUTTON EVENTS
========================================================= */

function bindEvents() {

    const previewButton = $("exportPreviewButton");
    const printPdfButton = $("printPdfButton");
    const printExcelButton = $("printExcelButton");

    const backButton =
        $("backButton");

    const emptyBackButton =
        $("emptyBackButton");


    if (previewButton) previewButton.addEventListener("click", openScreenshotPreview);
    if (printPdfButton) printPdfButton.addEventListener("click", () => printReport("pdf"));
    if (printExcelButton) printExcelButton.addEventListener("click", () => printReport("excel"));


    if (backButton) {

        backButton.addEventListener(
            "click",
            goBack
        );

    }


    if (emptyBackButton) {

        emptyBackButton.addEventListener(
            "click",
            goBack
        );

    }


    bindMainNavigation();
}


/* =========================================================
   CLEANUP
========================================================= */

window.addEventListener(
    "beforeunload",
    () => {

        activeObjectUrls.forEach(
            url => {

                try {

                    URL.revokeObjectURL(
                        url
                    );

                } catch (_) {}

            }
        );


        activeObjectUrls = [];
    }
);


/* =========================================================
   INIT
========================================================= */

function initExportPage() {

    log(
        "initializing..."
    );


    log(
        "jsPDF =",
        typeof window.jspdf
    );


    log(
        "html2canvas =",
        typeof window.html2canvas
    );


    exportData =
        loadExportData();


    if (!exportData) {

        showEmptyState();

        bindEvents();

        return;
    }


    renderExportPage();

    bindEvents();


    log(
        "ready."
    );
}


/* =========================================================
   START
========================================================= */

if (
    document.readyState ===
    "loading"
) {

    document.addEventListener(
        "DOMContentLoaded",
        initExportPage
    );

} else {

    initExportPage();

}


/* =========================================================
   DEBUG HELPERS
========================================================= */

window.MueenExport = {

    getData() {

        return exportData;

    },

    exportPdf,

    exportExcel,

    directDownload,

    openFile

};