window.COURSES.js.modules.push({title:'Module 4 : Projet final',
lessons:[{id:'js-4-1',title:'',text:'',start:'',checks:[]}],
quiz:[
{q:'Quelle instruction répète du code pour chaque indice d\'un tableau ?',o:['if','for','return'],a:1,e:'La boucle for répète un bloc de code.'},
{q:'Quelle propriété lit le contenu d\'un champ de saisie ?',o:['textContent','href','value'],a:2,e:'value contient ce que l\'utilisateur a écrit.'},
{q:'Quel opérateur signifie « différent de » ?',o:['!==','===','=>'],a:0,e:'!== signifie différent de (valeur et type).'},
{q:'Pourquoi place-t-on le script après les éléments HTML ?',o:['Pour agrandir le texte','Pour que les éléments existent quand le script s\'exécute','Pour ralentir la page'],a:1,e:'Le script a besoin que les éléments existent déjà.'}
]});
