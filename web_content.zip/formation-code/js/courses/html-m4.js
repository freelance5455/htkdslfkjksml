window.COURSES.html.modules.push({
title:'Module 4 : Aller plus loin',
lessons:[{id:'html-4-1',title:'',text:'',start:'',checks:[]},{id:'html-4-2',title:'',text:'',start:'',checks:[]},{id:'html-4-3',title:'',text:'',start:'',checks:[]}],
quiz:[
{q:'Quelle balise contient le contenu principal de la page ?',o:['&lt;main&gt;','&lt;nav&gt;','&lt;footer&gt;'],a:0,e:'&lt;main&gt; contient le contenu principal, une seule fois par page.'},
{q:'Que doivent avoir en commun des boutons radio du même groupe ?',o:['Le même id','Le même name','Le même texte'],a:1,e:'Le même name permet de ne choisir qu\'une seule option.'},
{q:'Quel attribut rend un champ obligatoire ?',o:['required','mandatory','needed'],a:0,e:'required empêche l\'envoi tant que le champ est vide.'},
{q:'Quel attribut affiche les boutons lecture d\'un &lt;audio&gt; ?',o:['play','controls','buttons'],a:1,e:'controls affiche les commandes du lecteur.'}
]});
