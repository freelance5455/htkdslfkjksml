window.COURSES.css.modules.push({title:'Module 3 : Projet final',
lessons:[{id:'css-3-1',title:'',text:'',start:'',checks:[]}],
quiz:[
{q:'Où place-t-on le CSS pour commencer ?',o:['Dans une balise &lt;p&gt;','Dans une balise &lt;a&gt;','Dans une balise &lt;style&gt;'],a:2,e:'On utilise la balise &lt;style&gt; dans le head.'},
{q:'Quel sélecteur cible la classe menu ?',o:['.menu','#menu','menu.'],a:0,e:'Une classe se cible avec un point : .menu.'},
{q:'Quelle propriété arrondit les angles ?',o:['text-align','border-radius','font-weight'],a:1,e:'border-radius arrondit les angles.'},
{q:'Quelle propriété change la couleur de fond ?',o:['color','font-size','background-color'],a:2,e:'background-color change la couleur de fond.'}
]});
