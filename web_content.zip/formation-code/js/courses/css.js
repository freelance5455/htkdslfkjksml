window.COURSES.css={id:'css',name:'CSS',
desc:'Donne des couleurs et une mise en forme à tes pages HTML, avec grille et design adaptatif.',
modules:[{title:'Module 1 : Les bases du CSS',
lessons:[{id:'css-1-1',title:'',text:'',start:'',checks:[]},{id:'css-1-2',title:'',text:'',start:'',checks:[]}],
quiz:[
{q:'Que signifie CSS ?',o:['Computer Style System','Cascading Style Sheets','Creative Site Syntax'],a:1,e:'CSS signifie Cascading Style Sheets.'},
{q:'Quelle propriété change la couleur du texte ?',o:['color','text-style','font-color'],a:0,e:'La propriété color règle la couleur du texte.'},
{q:'Quel symbole désigne une classe en CSS ?',o:['*','$','.'],a:2,e:'Une classe se cible avec un point, par exemple .carte.'},
{q:'Quel caractère termine chaque déclaration ?',o:[':',';',','],a:1,e:'Chaque déclaration se termine par un point-virgule.'}
]}]};
