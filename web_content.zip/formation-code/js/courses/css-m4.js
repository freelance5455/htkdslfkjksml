window.COURSES.css.modules.push({title:'Module 4 : Aller plus loin',
lessons:[{id:'css-4-1',title:'',text:'',start:'',checks:[]},{id:'css-4-2',title:'',text:'',start:'',checks:[]},{id:'css-4-3',title:'',text:'',start:'',checks:[]}],
quiz:[
{q:'Quelle propriété crée une grille ?',o:['display: grid','grid: on','layout: grid'],a:0,e:'display: grid crée une grille sur le conteneur.'},
{q:'Que signifie l\'unité fr dans une grille ?',o:['Une taille fixe en pixels','Une part de l\'espace disponible','Une police'],a:1,e:'fr est une part de l\'espace disponible.'},
{q:'Quelle règle s\'applique aux écrans de 600 pixels ou moins ?',o:['@media (max-width: 600px)','@media (min-width: 600px)','@screen (600px)'],a:0,e:'max-width cible les écrans jusqu\'à cette largeur.'},
{q:'Comment lit-on une variable CSS nommée --couleur ?',o:['$couleur','var(--couleur)','get(--couleur)'],a:1,e:'On lit une variable avec var(--couleur).'}
]});
