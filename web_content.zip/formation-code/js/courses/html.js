window.COURSES=window.COURSES||{};
window.COURSES.html={
id:'html',name:'HTML',
desc:'Construis des pages web de zéro : structure, textes, liens, images, formulaires et médias.',
modules:[{
title:'Module 1 : Découvrir HTML',
lessons:[
{id:'html-1-1',title:'La structure d\'une page',
text:`<p>HTML décrit le <b>contenu</b> d'une page web. Il s'écrit avec des <b>balises</b> : une balise ouvrante <code>&lt;p&gt;</code>, du contenu, puis une balise fermante <code>&lt;/p&gt;</code>.</p>
<p>Toute page suit le même squelette : <code>&lt;head&gt;</code> contient les informations techniques (comme le titre de l'onglet), et <code>&lt;body&gt;</code> contient ce qui s'affiche à l'écran.</p>
<p class="task"><b>Exercice :</b> dans le <code>body</code>, ajoute un paragraphe <code>&lt;p&gt;</code> avec une phrase de ton choix.</p>`,
start:`<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <title>Ma première page</title>
</head>
<body>
  <!-- Écris ton paragraphe ici -->
</body>
</html>`,
checks:[[/<body>[\s\S]*<p>\s*[^<\s][\s\S]*<\/p>[\s\S]*<\/body>/i,'Ajoute un paragraphe <p>ta phrase</p> à l\'intérieur du body.']]},
{id:'html-1-2',title:'Titres et paragraphes',
text:`<p>Les titres vont de <code>&lt;h1&gt;</code> (le plus important) à <code>&lt;h6&gt;</code>. Une page a en général un seul <code>h1</code>, puis des <code>h2</code> pour ses grandes parties.</p>
<pre>&lt;h1&gt;Mon blog&lt;/h1&gt;
&lt;h2&gt;Mes lectures&lt;/h2&gt;
&lt;p&gt;Un texte...&lt;/p&gt;</pre>
<p class="task"><b>Exercice :</b> ajoute un <code>h1</code>, un <code>h2</code> et deux paragraphes <code>p</code>.</p>`,
start:`<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <title>Mon blog</title>
</head>
<body>

</body>
</html>`,
checks:[[/<h1>\s*[^<\s][^<]*<\/h1>/i,'Il manque un titre <h1>…</h1> avec du texte.'],[/<h2>\s*[^<\s][^<]*<\/h2>/i,'Il manque un sous-titre <h2>…</h2> avec du texte.'],[/(<p>\s*[^<\s][\s\S]*?<\/p>[\s\S]*){2}/i,'Ajoute deux paragraphes <p>…</p>.']]},
{id:'html-1-3',title:'Liens et images',
text:`<p>Un lien s'écrit avec <code>&lt;a&gt;</code> et son attribut <code>href</code>, qui contient l'adresse de destination :</p>
<pre>&lt;a href="https://exemple.com"&gt;Visiter&lt;/a&gt;</pre>
<p>Une image s'ajoute avec <code>&lt;img&gt;</code>, qui n'a pas de balise fermante. Elle a besoin de <code>src</code> (le fichier) et de <code>alt</code> (une description, utile si l'image ne s'affiche pas) :</p>
<pre>&lt;img src="photo.jpg" alt="Un chat endormi"&gt;</pre>
<p class="task"><b>Exercice :</b> ajoute un lien avec un texte cliquable, puis une image avec <code>src</code> et <code>alt</code>.</p>`,
start:`<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <title>Liens et images</title>
</head>
<body>

</body>
</html>`,
checks:[[/<a\s[^>]*href=["'][^"']+["'][^>]*>\s*[^<\s][^<]*<\/a>/i,'Ajoute un lien : <a href="https://…">texte</a>.'],[/<img\s[^>]*src=["'][^"']+["']/i,'Ajoute une image avec un attribut src.'],[/<img\s[^>]*alt=["'][^"']+["']/i,'Ajoute un attribut alt qui décrit l\'image.']]}
],
quiz:[
{q:'Que signifie HTML ?',o:['High Tech Machine Language','HyperText Markup Language','Home Tool Making Language'],a:1,e:'HTML signifie HyperText Markup Language : un langage de balises.'},
{q:'Quelle balise contient ce qui s\'affiche dans la page ?',o:['&lt;head&gt;','&lt;html&gt;','&lt;body&gt;'],a:2,e:'Le contenu visible se place dans &lt;body&gt;.'},
{q:'Quelle balise crée le titre principal ?',o:['&lt;h1&gt;','&lt;p&gt;','&lt;title&gt;'],a:0,e:'&lt;h1&gt; est le titre principal de la page.'},
{q:'Quel attribut donne l\'adresse d\'un lien ?',o:['src','href','alt'],a:1,e:'Le lien utilise href ; src sert aux images.'}
]}]};
