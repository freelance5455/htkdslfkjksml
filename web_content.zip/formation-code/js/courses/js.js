window.COURSES.js={id:'js',name:'JavaScript',
desc:'Rends tes pages interactives : variables, fonctions, DOM, tableaux, projet final et module avancé.',
modules:[{title:'Module 1 : Les bases de JavaScript',
lessons:[{id:'js-1-1',title:'',text:'',start:'',checks:[]},{id:'js-1-2',title:'',text:'',start:'',checks:[]}],
quiz:[
{q:'Quel mot-clé crée une variable modifiable ?',o:['const','let','fix'],a:1,e:'let crée une variable modifiable ; const une valeur fixe.'},
{q:'Que fait console.log() ?',o:['Affiche un message','Crée une variable','Supprime une page'],a:0,e:'console.log() affiche un message.'},
{q:'Quel opérateur compare deux valeurs et leur type ?',o:['=','==','==='],a:2,e:'=== compare la valeur et le type ; = donne une valeur.'},
{q:'Quel mot-clé renvoie le résultat d\'une fonction ?',o:['print','return','output'],a:1,e:'return renvoie le résultat de la fonction.'}
]},
{title:'Module 2 : Interagir avec la page',
lessons:[{id:'js-2-1',title:'',text:'',start:'',checks:[]}],
quiz:[
{q:'Quelle méthode récupère un élément par son id ?',o:['document.getElementById()','document.getId()','window.id()'],a:0,e:'document.getElementById() récupère un élément par son id.'},
{q:'Quelle propriété change le texte d\'un élément ?',o:['className','href','textContent'],a:2,e:'textContent lit ou modifie le texte.'},
{q:'Quel événement correspond à un clic ?',o:['hover','click','press'],a:1,e:'L\'événement s\'appelle click.'},
{q:'Où place-t-on le code JavaScript dans la page ?',o:['Dans une balise &lt;script&gt;','Dans une balise &lt;style&gt;','Dans une balise &lt;title&gt;'],a:0,e:'Le code va dans une balise &lt;script&gt;.'}
]}]};
