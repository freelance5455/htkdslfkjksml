window.COURSES.css.modules.push({title:'Module 2 : La boîte et la mise en page',
lessons:[{id:'css-2-1',title:'',text:'',start:'',checks:[]},{id:'css-2-2',title:'',text:'',start:'',checks:[]}],
quiz:[
{q:'Quelle propriété ajoute de l\'espace à l\'intérieur d\'un élément ?',o:['margin','padding','border'],a:1,e:'padding agit à l\'intérieur de la bordure.'},
{q:'Quelle propriété ajoute de l\'espace autour d\'un élément ?',o:['margin','padding','gap'],a:0,e:'margin agit à l\'extérieur de la bordure.'},
{q:'Quelle valeur de display active Flexbox ?',o:['block','inline','flex'],a:2,e:'display: flex active Flexbox sur le conteneur.'},
{q:'Quelle propriété espace les éléments d\'un conteneur flex ?',o:['padding','gap','border-radius'],a:1,e:'gap crée un espace entre les éléments.'}
]});
