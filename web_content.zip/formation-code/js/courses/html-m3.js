window.COURSES.html.modules.push({
title:'Module 3 : Tableaux et projet final',
lessons:[{id:'html-3-1',title:'',text:'',start:'',checks:[]},{id:'html-3-2',title:'',text:'',start:'',checks:[]}],
quiz:[
{q:'Quelle balise crée une ligne dans un tableau ?',o:['&lt;td&gt;','&lt;tr&gt;','&lt;th&gt;'],a:1,e:'&lt;tr&gt; crée une ligne ; &lt;td&gt; et &lt;th&gt; créent des cellules.'},
{q:'Quelle balise crée une cellule d\'en-tête ?',o:['&lt;td&gt;','&lt;tr&gt;','&lt;th&gt;'],a:2,e:'&lt;th&gt; est la cellule d\'en-tête.'},
{q:'Combien de titres &lt;h1&gt; une page a-t-elle en général ?',o:['Un seul','Un par paragraphe','Autant qu\'on veut'],a:0,e:'Une page a en général un seul titre principal.'},
{q:'Quels attributs relient un label à son champ ?',o:['href et src','for et id','alt et title'],a:1,e:'La valeur de for doit être identique à celle de id.'}
]});
