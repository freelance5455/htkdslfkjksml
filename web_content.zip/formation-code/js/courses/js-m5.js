window.COURSES.js.modules.push({title:'Module 5 : Aller plus loin',
lessons:[{id:'js-5-1',title:'',text:'',start:'',checks:[]},{id:'js-5-2',title:'',text:'',start:'',checks:[]},{id:'js-5-3',title:'',text:'',start:'',checks:[]}],
quiz:[
{q:'Que se passe-t-il si on oublie de modifier la variable dans une boucle while ?',o:['La boucle ne tourne jamais','La boucle ne s\'arrête jamais','JavaScript corrige l\'oubli'],a:1,e:'Sans changement, la condition reste vraie : c\'est une boucle infinie.'},
{q:'Quelle méthode renvoie un nouveau tableau avec seulement certains éléments ?',o:['forEach','filter','join'],a:1,e:'filter garde les éléments qui passent le test.'},
{q:'Que fait map sur un tableau ?',o:['Transforme chaque élément en un nouveau tableau','Supprime le tableau','Affiche une carte'],a:0,e:'map renvoie un nouveau tableau avec chaque élément transformé.'},
{q:'Quelle instruction transforme un texte JSON en objet ?',o:['JSON.stringify','JSON.parse','JSON.log'],a:1,e:'JSON.parse convertit un texte JSON en objet ; JSON.stringify fait l\'inverse.'}
]});
