window.COURSES.html.modules.push({
title:'Module 2 : Liens, images et formulaires',
lessons:[{id:'html-2-1',title:'',text:'',start:'',checks:[]},{id:'html-2-2',title:'',text:'',start:'',checks:[]}],
quiz:[
{q:'Quel attribut contient la destination d\'un lien ?',o:['href','src','alt'],a:0,e:'href contient la destination du lien.'},
{q:'Quel attribut décrit une image pour ceux qui ne la voient pas ?',o:['src','href','alt'],a:2,e:'alt est le texte alternatif de l\'image.'},
{q:'Quelle balise regroupe les champs d\'un formulaire ?',o:['&lt;div&gt;','&lt;form&gt;','&lt;table&gt;'],a:1,e:'&lt;form&gt; englobe les champs et le bouton.'},
{q:'À quoi sert la balise &lt;label&gt; ?',o:['Envoyer le formulaire','Dessiner une bordure','Décrire un champ'],a:2,e:'&lt;label&gt; indique à l\'utilisateur ce qu\'il doit saisir.'}
]});
