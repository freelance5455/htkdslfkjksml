window.COURSES.js.modules.push({title:'Module 3 : Tableaux, boucles et objets',
lessons:[{id:'js-3-1',title:'',text:'',start:'',checks:[]},{id:'js-3-2',title:'',text:'',start:'',checks:[]}],
quiz:[
{q:'Quelle propriété donne le nombre d\'éléments d\'un tableau ?',o:['size','count','length'],a:2,e:'length donne le nombre d\'éléments.'},
{q:'Quelle méthode ajoute un élément à la fin d\'un tableau ?',o:['push','add','append'],a:0,e:'push() ajoute à la fin du tableau.'},
{q:'À quel indice se trouve le premier élément d\'un tableau ?',o:['1','0','-1'],a:1,e:'La numérotation commence à 0.'},
{q:'Comment lit-on la propriété nom de l\'objet eleve ?',o:['eleve.nom','eleve(nom)','nom.eleve'],a:0,e:'On lit une propriété avec un point : eleve.nom.'}
]});
