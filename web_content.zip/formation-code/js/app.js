(function(){
var C=window.COURSES,app=document.getElementById('app'),back=document.getElementById('back'),ttl=document.getElementById('title');
var LIST=[['html','HTML'],['css','CSS'],['js','JavaScript'],['ts','TypeScript'],['react','React'],['sql','SQL']];
var S={done:{},quiz:{}};
var IC=window.IC,HL=window.HL;
back.innerHTML=IC.ui.back+'<span>Retour</span>';
try{var r=JSON.parse(localStorage.getItem('formation'));if(r)S=r}catch(e){}
function save(){try{localStorage.setItem('formation',JSON.stringify(S))}catch(e){}}
function esc(s){return s.replace(/&/g,'&amp;').replace(/</g,'&lt;')}
function $(i){return document.getElementById(i)}
function head(t,b){ttl.textContent=t;back.hidden=!b;back.onclick=b||null;window.scrollTo(0,0)}
function prog(d){var n=0,t=0;d.modules.forEach(function(m,mi){t+=m.lessons.length+1;m.lessons.forEach(function(l){if(S.done[l.id])n++});if(S.quiz[d.id+mi])n++});return Math.round(n/t*100)}
function home(){head('Formation Code');
var h='<p class="lead">Apprends un langage de A à Z, puis crée ton premier projet.</p>';
LIST.forEach(function(c){var d=C[c[0]];
if(d){var p=prog(d);h+='<button class="card lang" data-c="'+c[0]+'">'+IC.lang(c[0])+'<span class="bd"><b>'+d.name+'</b><span class="ds">'+d.desc+'</span><i class="bar"><u style="width:'+p+'%"></u></i><small>'+p+' % terminé</small></span></button>'}
else h+='<div class="card lang off">'+IC.lang(c[0])+'<span class="bd"><b>'+c[1]+'</b><span class="ds">Bientôt disponible</span></span></div>'});
h+=badges();
app.innerHTML=h;
app.querySelectorAll('[data-c]').forEach(function(b){b.onclick=function(){course(b.dataset.c)}})}
function course(id){var d=C[id];head(d.name,home);var h=IC.hero(id)+'<p class="lead">'+d.desc+'</p>';
d.modules.forEach(function(m,mi){var all=m.lessons.every(function(l){return S.done[l.id]});
h+='<h2>'+m.title+'</h2>';
m.lessons.forEach(function(l,li){h+='<button class="item" data-l="'+mi+','+li+'"><span class="it '+(S.done[l.id]?'ok':'')+'">'+(S.done[l.id]?IC.ui.done:IC.ui.todo)+l.title+'</span><em>'+(S.done[l.id]?'Terminé':'À faire')+'</em></button>'});
h+='<button class="item" data-q="'+mi+'"'+(all?'':' disabled')+'><span class="it '+(S.quiz[id+mi]?'ok':'')+'">'+(S.quiz[id+mi]?IC.ui.done:all?IC.ui.quiz:IC.ui.lock)+'Quiz du module</span><em>'+(S.quiz[id+mi]?'Réussi':all?'À faire':'Termine les leçons')+'</em></button>'});
if(prog(d)===100&&!d.partial)h+='<button class="card lang" id="cert">'+IC.ui.seal+'<span class="bd"><b>Certificat de réussite</b><span class="ds">Formation terminée, bravo !</span></span></button>';
h+='<p class="note">Les autres langages arrivent prochainement.</p>';
app.innerHTML=h;
app.querySelectorAll('[data-l]').forEach(function(b){b.onclick=function(){var a=b.dataset.l.split(',');lesson(id,+a[0],+a[1])}});
app.querySelectorAll('[data-q]').forEach(function(b){b.onclick=function(){quiz(id,+b.dataset.q)}});var ce=$('cert');if(ce)ce.onclick=function(){cert(id)}}
function lesson(id,mi,li){var d=C[id],m=d.modules[mi],l=m.lessons[li];
head(l.title,function(){course(id)});
app.innerHTML='<div class="txt">'+l.text+'</div><label class="t" for="ed">Ton code</label><div class="ed"><pre id="hl" aria-hidden="true"></pre><textarea id="ed" wrap="off" spellcheck="false" autocapitalize="off" autocorrect="off">'+esc(l.start)+'</textarea></div><button id="run" class="btn">Vérifier</button><div id="fb" role="status"></div><label class="t">Aperçu</label><iframe id="pv" sandbox="'+(l.js?'allow-scripts':'')+'" title="Aperçu"></iframe><div id="nx"></div><div class="txt">'+(l.after||'')+'</div>';
var ed=$('ed'),pv=$('pv'),fb=$('fb'),hl=$('hl');
app.querySelectorAll('.txt').forEach(function(x){HL.enhance(x,id)});
function paint(){hl.innerHTML=HL.html(ed.value,'html')+'\n';hl.scrollTop=ed.scrollTop;hl.scrollLeft=ed.scrollLeft}
ed.addEventListener('scroll',function(){hl.scrollTop=ed.scrollTop;hl.scrollLeft=ed.scrollLeft});
var HLP='<script>(function(){var o=document.createElement("pre");o.style.cssText="background:#e3e5e8;padding:8px;margin:8px 0;white-space:pre-wrap";document.body.appendChild(o);console.log=function(){o.textContent+=[].slice.call(arguments).join(" ")+"\\n"};window.onerror=function(m){o.textContent+="Erreur : "+m+"\\n"}})()<\/script>';
function show(){paint();pv.srcdoc=l.js?ed.value.replace('<body>','<body>'+HLP):ed.value}
ed.oninput=show;show();
$('run').onclick=function(){var v=ed.value,miss=l.checks.filter(function(c){return !c[0].test(v)});
if(miss.length){fb.className='bad';fb.textContent=miss[0][1];return}
S.done[l.id]=1;save();fb.className='good';fb.textContent='Bravo, exercice réussi.';
var last=li+1>=m.lessons.length;
$('nx').innerHTML='<button class="btn" id="go">'+(last?'Passer au quiz':'Leçon suivante')+'</button>';
$('go').onclick=function(){last?quiz(id,mi):lesson(id,mi,li+1)}}}
function quiz(id,mi){var m=C[id].modules[mi];head('Quiz',function(){course(id)});
var h='<p class="lead">'+m.title+'</p>';
m.quiz.forEach(function(q,i){h+='<fieldset><legend>'+q.q+'</legend>';q.o.forEach(function(o,j){h+='<label class="opt"><input type="radio" name="q'+i+'" value="'+j+'"> '+o+'</label>'});h+='</fieldset>'});
h+='<button id="ok" class="btn">Valider mes réponses</button><div id="fb" role="status"></div>';
app.innerHTML=h;
$('ok').onclick=function(){var n=0,bad=[],fb=$('fb');
m.quiz.forEach(function(q,i){var c=app.querySelector('input[name=q'+i+']:checked');if(c&&+c.value===q.a)n++;else bad.push(q.e)});
var need=m.quiz.length-1;
if(n>=need){S.quiz[id+mi]=1;save()}
fb.className=n>=need?'good':'bad';
fb.innerHTML=n+' / '+m.quiz.length+(n>=need?' : module validé, bravo !':' : il en faut au moins '+need+'. Relis les leçons et réessaie.')+(bad.length?'<br><span style="font-weight:400;color:#22272c">'+bad.join('<br>')+'</span>':'')}}
function badges(){var B=[['Première leçon terminée',Object.keys(S.done).length>0]];
Object.keys(C).forEach(function(k){var d=C[k];d.modules.forEach(function(m,mi){B.push([d.name+' : module '+(mi+1)+' validé',!!S.quiz[k+mi]])});B.push([d.name+' : formation terminée',prog(d)===100&&!d.partial])});
var h='<h2>Mes badges</h2><div class="badges">';
B.forEach(function(b){h+='<span class="bdg'+(b[1]?' on':'')+'">'+(b[1]?IC.ui.tick:'')+b[0]+'</span>'});return h+'</div>'}
function cert(id){var d=C[id];head('Certificat',function(){course(id)});
var dt=new Date().toLocaleDateString('fr-FR',{day:'numeric',month:'long',year:'numeric'});
app.innerHTML='<label class="t" for="nm">Ton nom</label><input id="nm" class="fld" placeholder="Prénom Nom"><div class="cert">'+IC.ui.seal+'<p>Certificat de réussite</p><h2 id="cn"></h2><p>a terminé avec succès la formation</p><h3>'+d.name+'</h3><p>'+d.modules.length+' modules, projet final inclus</p><p>Délivré le '+dt+'</p></div><button class="btn" id="pr">Imprimer ou enregistrer en PDF</button>';
var nm=$('nm');nm.value=S.name||'';function up(){$('cn').textContent=nm.value||'Ton nom';S.name=nm.value;save()}nm.oninput=up;up();$('pr').onclick=function(){window.print()}}
home();
})();
