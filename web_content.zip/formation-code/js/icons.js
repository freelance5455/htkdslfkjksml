(function(){
var SW='stroke-linecap="round" stroke-linejoin="round"';
var BODY={
html:'<rect width="64" height="64" rx="14" fill="#e8601c"/><rect x="9" y="12" width="46" height="40" rx="6" fill="#fff"/><path d="M9 18a6 6 0 0 1 6-6h34a6 6 0 0 1 6 6v3H9z" fill="#7a2f0b"/><circle cx="15" cy="16.5" r="1.7" fill="#f4a373"/><circle cx="20.5" cy="16.5" r="1.7" fill="#f4a373"/><path d="M26 31l-6 6 6 6M38 31l6 6-6 6M35 29l-6 16" fill="none" stroke="#e8601c" stroke-width="3.4" '+SW+'/>',
css:'<rect width="64" height="64" rx="14" fill="#2a6fdb"/><rect x="9" y="12" width="46" height="40" rx="6" fill="#fff"/><circle cx="21" cy="23" r="4.4" fill="#f2543d"/><circle cx="32" cy="23" r="4.4" fill="#f2c200"/><circle cx="43" cy="23" r="4.4" fill="#2fb57a"/><path d="M27 31c-3 0-4 1-4 4v2c0 2-1 3-3 3 2 0 3 1 3 3v2c0 3 1 4 4 4M37 31c3 0 4 1 4 4v2c0 2 1 3 3 3-2 0-3 1-3 3v2c0 3-1 4-4 4" fill="none" stroke="#2a6fdb" stroke-width="3" '+SW+'/><circle cx="32" cy="40" r="2.3" fill="#2a6fdb"/>',
js:'<rect width="64" height="64" rx="14" fill="#f2c200"/><path d="M14 12v22l6-5.5 4.2 9.5 4-1.8-4.2-9.3 8.3-.4z" fill="#2b2400"/><path d="M40 14l3 6M46 10l-1 6M51 16l-6 2" fill="none" stroke="#2b2400" stroke-width="2.2" '+SW+'/><text x="50" y="55" text-anchor="end" font-family="system-ui,Arial,sans-serif" font-weight="800" font-size="24" fill="#2b2400">JS</text>',
ts:'<rect width="64" height="64" rx="14" fill="#3178c6"/><path d="M22 11l9 3v7c0 6-4 9-9 11-5-2-9-5-9-11v-7z" fill="#fff"/><path d="M18 21.5l3 3 6-6" fill="none" stroke="#3178c6" stroke-width="2.6" '+SW+'/><text x="50" y="55" text-anchor="end" font-family="system-ui,Arial,sans-serif" font-weight="800" font-size="24" fill="#fff">TS</text>',
react:'<rect width="64" height="64" rx="14" fill="#1f2630"/><g fill="none" stroke="#61dafb" stroke-width="2.6"><ellipse cx="32" cy="32" rx="21" ry="8"/><ellipse cx="32" cy="32" rx="21" ry="8" transform="rotate(60 32 32)"/><ellipse cx="32" cy="32" rx="21" ry="8" transform="rotate(120 32 32)"/></g><circle cx="32" cy="32" r="3.8" fill="#61dafb"/>',
sql:'<rect width="64" height="64" rx="14" fill="#2f8f83"/><path d="M16 18v28c0 4 7 7 16 7s16-3 16-7V18z" fill="#fff"/><ellipse cx="32" cy="18" rx="16" ry="7" fill="#d6f5f0"/><path d="M16 29.5c0 4 7 7 16 7s16-3 16-7M16 41c0 4 7 7 16 7s16-3 16-7" fill="none" stroke="#2f8f83" stroke-width="2.4"/>'
};
var DARK={html:'#7a2f0b',css:'#123a7a',js:'#5c4a00',ts:'#173d6b',react:'#1f2630',sql:'#144a44'};
var NAME={html:'HTML',css:'CSS',js:'JavaScript',ts:'TypeScript',react:'React',sql:'SQL'};
function T(c,t){return [c,t]}
var SNIP={
html:[[T('t','<h1'),T('a',' class'),T('d','='),T('s','"titre"'),T('t','>')],[T('d','  Bonjour !')],[T('t','</h1>')]],
css:[[T('t','h1'),T('d',' {')],[T('d','  '),T('a','color'),T('d',': '),T('n','#e8601c'),T('d',';')],[T('d','  '),T('a','font-size'),T('d',': '),T('n','32px'),T('d',';')],[T('d','}')]],
js:[[T('k','const'),T('d',' nom = '),T('s','"Léa"'),T('d',';')],[T('k','let'),T('d',' age = '),T('n','20'),T('d',';')],[T('d','console.'),T('f','log'),T('d','(nom);')]],
ts:[[T('k','let'),T('d',' age: '),T('k','number'),T('d',' = '),T('n','20'),T('d',';')],[T('d','age = '),T('s','"vingt"'),T('d',';')],[T('c','// erreur de type')]],
react:[[T('k','function'),T('d',' '),T('f','Salut'),T('d','() {')],[T('d','  '),T('k','return'),T('d',' '),T('t','<h1>'),T('d','Bonjour'),T('t','</h1>'),T('d',';')],[T('d','}')]],
sql:[[T('k','SELECT'),T('d',' nom')],[T('k','FROM'),T('d',' eleves')],[T('k','WHERE'),T('d',' age > '),T('n','15'),T('d',';')]]
};
function esc(s){return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}
function lang(k,cls){return '<svg class="'+(cls||'ico')+'" viewBox="0 0 64 64" aria-hidden="true" focusable="false">'+BODY[k]+'</svg>'}
function hero(k){
var lines=SNIP[k],h='<svg class="hero" viewBox="0 0 360 132" role="img" aria-label="Illustration du parcours '+NAME[k]+'"><rect width="360" height="132" rx="14" fill="'+DARK[k]+'"/><circle cx="338" cy="-4" r="64" fill="#fff" opacity=".07"/><circle cx="10" cy="140" r="52" fill="#fff" opacity=".06"/>';
h+='<svg x="18" y="34" width="64" height="64" viewBox="0 0 64 64">'+BODY[k]+'</svg>';
h+='<rect x="100" y="16" width="244" height="100" rx="9" fill="#1d242b"/><circle cx="113" cy="28" r="3" fill="#ff7b6b"/><circle cx="124" cy="28" r="3" fill="#f2c200"/><circle cx="135" cy="28" r="3" fill="#4fc58f"/>';
lines.forEach(function(ln,i){
h+='<text x="114" y="'+(54+i*17)+'" xml:space="preserve" style="white-space:pre">';
ln.forEach(function(t){h+=t[0]==='d'?'<tspan>'+esc(t[1])+'</tspan>':'<tspan class="h-'+t[0]+'">'+esc(t[1])+'</tspan>'});
h+='</text>'});
return h+'</svg>'}
function ui(body,cls){return '<svg class="'+(cls||'ui')+'" viewBox="0 0 24 24" aria-hidden="true" focusable="false">'+body+'</svg>'}
var UI={
back:ui('<path d="M15 5l-7 7 7 7" fill="none" stroke="currentColor" stroke-width="2.4" '+SW+'/>'),
done:ui('<circle cx="12" cy="12" r="10" fill="currentColor"/><path d="M7 12.5l3.2 3.2L17 9" fill="none" stroke="#fff" stroke-width="2.4" '+SW+'/>'),
todo:ui('<circle cx="12" cy="12" r="9.2" fill="none" stroke="currentColor" stroke-width="2"/><path d="M10 8.6l5.4 3.4-5.4 3.4z" fill="currentColor"/>'),
lock:ui('<rect x="5" y="10.5" width="14" height="10" rx="2.4" fill="currentColor"/><path d="M8.5 10.5V8a3.5 3.5 0 0 1 7 0v2.5" fill="none" stroke="currentColor" stroke-width="2.2" '+SW+'/>'),
quiz:ui('<rect x="3" y="3" width="18" height="18" rx="5" fill="none" stroke="currentColor" stroke-width="2"/><path d="M9.4 9.6a2.7 2.7 0 1 1 4.1 2.3c-.9.5-1.5 1-1.5 2" fill="none" stroke="currentColor" stroke-width="2" '+SW+'/><circle cx="12" cy="16.6" r="1.2" fill="currentColor"/>'),
tick:ui('<path d="M5 12.5l4.5 4.5L19 7.5" fill="none" stroke="currentColor" stroke-width="3" '+SW+'/>','ui tick'),
seal:'<svg class="seal" viewBox="0 0 64 64" aria-hidden="true" focusable="false"><path d="M20 38l-6 20 10-4 6 8 6-20z" fill="#8f3f36"/><path d="M44 38l6 20-10-4-6 8-6-20z" fill="#b25246"/><circle cx="32" cy="26" r="20" fill="#d9a520"/><circle cx="32" cy="26" r="15" fill="#f2c94c"/><path d="M32 15.5l3.2 6.6 7.2 1-5.2 5.1 1.3 7.2-6.5-3.4-6.5 3.4 1.3-7.2-5.2-5.1 7.2-1z" fill="#fff8dc"/></svg>'
};
window.IC={lang:lang,hero:hero,ui:UI,names:NAME};
})();
