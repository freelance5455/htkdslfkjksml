(function(){
function mk(a){var o={};a.split(' ').forEach(function(w){o[w]=1});return o}
var KW={
js:mk('const let var function return if else for while do break continue switch case default new this typeof in of true false null undefined class try catch throw async await'),
ts:mk('const let var function return if else for while do break continue switch case default new this typeof in of true false null undefined class try catch throw async await interface type enum number string boolean any void readonly public private implements extends'),
sql:mk('select from where insert into values update set delete create table and or not null order by group having join inner left right on as limit distinct like in primary key foreign references count sum avg min max asc desc')
};
function esc(s){return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}
function push(o,c,t){if(!t)return;var l=o[o.length-1];if(l&&l[0]===c)l[1]+=t;else o.push([c,t])}

function codeT(src,lang){
var kw=KW[lang]||KW.js,sql=lang==='sql',o=[];
var re=new RegExp('('+(sql?'--[^\\n]*|':'//[^\\n]*|')+'/\\*[\\s\\S]*?(?:\\*/|$))|("(?:\\\\.|[^"\\\\\\n])*"?|\'(?:\\\\.|[^\'\\\\\\n])*\'?|`(?:\\\\.|[^`\\\\])*`?)|(\\b\\d+(?:\\.\\d+)?\\b)|([A-Za-z_$][\\w$]*)(\\s*\\()?|([\\s\\S])','g');
var m;
while((m=re.exec(src))){
if(m[1])push(o,'c',m[1]);
else if(m[2])push(o,'s',m[2]);
else if(m[3])push(o,'n',m[3]);
else if(m[4]){var w=sql?m[4].toLowerCase():m[4];
if(kw[w])push(o,'k',m[4]);else if(m[5])push(o,'f',m[4]);else push(o,'d',m[4]);
if(m[5])push(o,'d',m[5])}
else push(o,'d',m[6])}
return o}

function cssT(src,inline){
var o=[],stack=inline?['decl']:[],inVal=false,pre='';
function ctx(){return stack.length?stack[stack.length-1]:'sel'}
var re=/(\/\*[\s\S]*?(?:\*\/|$))|("(?:\\.|[^"\\\n])*"?|'(?:\\.|[^'\\\n])*'?)|([{};:])|(@[\w-]+)|(#[0-9a-fA-F]{3,8}\b)|(-?\d*\.?\d+(?:%|[a-zA-Z]+)?)|(!important)|(\.[A-Za-z_-][\w-]*)|([A-Za-z_-][\w-]*)(\s*\()?|([\s\S])/g;
var m;
while((m=re.exec(src))){
if(m[1])push(o,'c',m[1]);
else if(m[2])push(o,'s',m[2]);
else if(m[3]){var ch=m[3];
if(ch==='{'){stack.push(/^\s*@(media|supports|keyframes|layer|container)/.test(pre)?'sel':'decl');inVal=false;pre=''}
else if(ch==='}'){stack.pop();inVal=false;pre=''}
else if(ch===';'){inVal=false;pre=''}
else{if(ctx()==='decl'&&!inVal)inVal=true;pre+=ch}
push(o,'d',ch)}
else if(m[4]){pre+=m[4];push(o,'k',m[4])}
else if(m[5]){pre+=m[5];push(o,ctx()==='decl'&&inVal?'n':'t',m[5])}
else if(m[6]){pre+=m[6];push(o,ctx()==='decl'&&inVal?'n':'d',m[6])}
else if(m[7])push(o,'k',m[7]);
else if(m[8]){pre+=m[8];push(o,ctx()==='sel'?'t':'d',m[8])}
else if(m[9]){pre+=m[9];var c=ctx();
if(c==='sel')push(o,'t',m[9]);
else if(inVal)push(o,m[10]?'f':'d',m[9]);
else push(o,'a',m[9]);
if(m[10]){pre+=m[10];push(o,'d',m[10])}}
else{pre+=m[11];push(o,'d',m[11])}}
return o}

function htmlT(src){
var o=[],i=0,n=src.length,m,j;
var tag=/<\/?([A-Za-z][\w:-]*)/y,ws=/\s+/y,attr=/[^\s=>\/"']+/y,qv=/"[^"]*"?|'[^']*'?/y,uv=/[^\s>]+/y,txt=/[^<]+/y;
while(i<n){
if(src.startsWith('<!--',i)){j=src.indexOf('-->',i);j=j<0?n:j+3;push(o,'c',src.slice(i,j));i=j;continue}
if(src.charAt(i)==='<'&&src.charAt(i+1)==='!'){j=src.indexOf('>',i);j=j<0?n:j+1;push(o,'k',src.slice(i,j));i=j;continue}
tag.lastIndex=i;m=tag.exec(src);
if(m&&m.index===i){
push(o,'t',m[0]);i+=m[0].length;var name=m[1].toLowerCase(),isClose=m[0].charAt(1)==='/',selfClose=false,closed=false;
while(i<n){
ws.lastIndex=i;var w=ws.exec(src);if(w&&w.index===i){push(o,'d',w[0]);i+=w[0].length;continue}
var c=src.charAt(i);
if(c==='>'){push(o,'t','>');i++;closed=true;break}
if(c==='/'&&src.charAt(i+1)==='>'){push(o,'t','/>');i+=2;selfClose=true;closed=true;break}
if(c==='='){push(o,'d','=');i++;
qv.lastIndex=i;var q=qv.exec(src);
if(q&&q.index===i){push(o,'s',q[0]);i+=q[0].length}
else{uv.lastIndex=i;var u=uv.exec(src);if(u&&u.index===i){push(o,'s',u[0]);i+=u[0].length}}
continue}
attr.lastIndex=i;var a=attr.exec(src);
if(a&&a.index===i){push(o,'a',a[0]);i+=a[0].length;continue}
push(o,'d',c);i++}
if(closed&&!selfClose&&!isClose&&(name==='style'||name==='script')){
var low=src.toLowerCase();j=low.indexOf('</'+name,i);if(j<0)j=n;
var inner=src.slice(i,j);
(name==='style'?cssT(inner):codeT(inner,'js')).forEach(function(t){push(o,t[0],t[1])});
i=j}
continue}
txt.lastIndex=i;m=txt.exec(src);
if(m&&m.index===i){push(o,'d',m[0]);i+=m[0].length}
else{push(o,'d',src.charAt(i));i++}}
return o}

function tokens(src,lang,inline){
if(lang==='css'){
if(inline&&src.indexOf('{')<0){
if(src.indexOf(':')>=0)return cssT(src,true);
if(/^#[0-9a-fA-F]{3,8}$|^-?\d*\.?\d+(px|em|rem|%|vh|vw|s)?$/.test(src))return [['n',src]];
if(/^[.#]/.test(src))return [['t',src]];
return [['d',src]]}
return cssT(src,false)}
if(lang==='html'||lang==='react')return htmlT(src);
return codeT(src,lang)}

function guess(src,dflt){
if(/<[A-Za-z!\/]/.test(src))return 'html';
return dflt||'html'}

function html(src,lang,inline){
return tokens(src,lang,inline).map(function(t){
return t[0]==='d'?esc(t[1]):'<span class="h-'+t[0]+'">'+esc(t[1])+'</span>'}).join('')}

function enhance(root,dflt){
root.querySelectorAll('pre').forEach(function(p){var s=p.textContent;p.innerHTML=html(s,guess(s,dflt),false)});
root.querySelectorAll('code').forEach(function(p){var s=p.textContent;p.innerHTML=html(s,guess(s,dflt),true)})}

window.HL={tokens:tokens,html:html,guess:guess,enhance:enhance};
})();
