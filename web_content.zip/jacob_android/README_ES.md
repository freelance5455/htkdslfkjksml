# El juego de Jacob — proyecto Android y multijugador

Este paquete contiene el juego HTML dentro de una app Android (WebView) y un servidor WebSocket para que varios jugadores vean el movimiento de los demás en el mismo pueblo.

## 1) Generar el APK

1. Instala Android Studio en una computadora.
2. Descomprime `El_juego_de_Jacob_APK_y_multijugador.zip`.
3. En Android Studio, elige **Open** y selecciona la carpeta `jacob_android` (la carpeta que contiene `settings.gradle`).
4. Espera a que Gradle sincronice y descargue el Android Gradle Plugin/SDK si los solicita.
5. En el menú **Build > Build APK(s)**.
6. Android Studio mostrará el enlace a `app-debug.apk`. Para distribuirlo fuera de Google Play, usa **Build > Generate Signed Bundle / APK** y crea una clave de firma privada; guárdala en un lugar seguro.

El proyecto se abre en horizontal y usa almacenamiento local del WebView para guardar la partida en ese dispositivo.

## 2) Activar multijugador

El servidor debe estar publicado en internet para que los celulares de tus amigos puedan conectarse. Una forma sencilla es usar Render:

1. Sube la carpeta `server` a un repositorio Git.
2. Crea un servicio Web en Render desde ese repositorio, con `server` como Root Directory, `npm install` como Build Command y `npm start` como Start Command. También puedes usar el archivo `server/render.yaml` como referencia.
3. Copia el dominio HTTPS que Render te asigne, por ejemplo `https://TU-SERVICIO.onrender.com`.
4. En la app, abre **Opciones multijugador** en el menú e introduce la URL WebSocket correspondiente: `wss://TU-SERVICIO.onrender.com/ws`.
5. Comparte el mismo enlace `wss://.../ws` con tus amigos. Todos deben usar el mismo servidor.

No pegues una URL de ejemplo sin reemplazar el dominio. El servidor transmite posiciones/nombres de jugadores; las monedas y el progreso de cada partida siguen siendo locales por dispositivo (no hay sincronización de inventario/monedas ni protección contra trampas).

## Limitaciones importantes

- Este paquete es el proyecto fuente listo para compilar, no un APK ya compilado. El entorno de creación no dispone del Android SDK/Gradle instalado para compilar y verificar el APK aquí.
- El juego carga Three.js desde CDN; la primera ejecución requiere conexión a internet.
- El servidor debe permanecer desplegado para jugar online. El multijugador no funcionará hasta que publiques el servidor y configures la URL `wss://`.
