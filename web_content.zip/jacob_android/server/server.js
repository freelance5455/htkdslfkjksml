'use strict';
const http = require('http');
const { randomUUID } = require('crypto');
const WebSocket = require('ws');
const PORT = Number(process.env.PORT || 8080);
const MAX_PLAYERS = Number(process.env.MAX_PLAYERS || 32);
const server = http.createServer((req, res) => {
  if (req.url === '/health' || req.url === '/') {
    res.writeHead(200, { 'content-type': 'application/json; charset=utf-8' });
    return res.end(JSON.stringify({ ok: true, game: 'El juego de Jacob', players: players.size }));
  }
  res.writeHead(404); res.end('Not found');
});
const wss = new WebSocket.Server({ server, path: '/ws', maxPayload: 4096 });
const players = new Map();
function safeSend(ws, data) { if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(data)); }
function publicPlayer(p) { return { id:p.id, name:p.name, color:p.color, x:p.x, y:p.y, z:p.z, rot:p.rot }; }
function broadcast(data, except) { const msg = JSON.stringify(data); for (const client of wss.clients) if (client !== except && client.readyState === WebSocket.OPEN) client.send(msg); }
wss.on('connection', (ws) => {
  if (players.size >= MAX_PLAYERS) { safeSend(ws, { type:'error', message:'El pueblo está lleno. Intenta más tarde.' }); return ws.close(1013, 'Server full'); }
  const p = { id:randomUUID(), name:'Jugador', color:['#4f8eb8','#cf5362','#58a878','#a17bd0'][Math.floor(Math.random()*4)], x:0, y:0, z:0, rot:0, joined:false, lastMove:0 };
  ws.isAlive = true;
  ws.on('pong', () => { ws.isAlive = true; });
  ws.on('message', (raw) => {
    let msg; try { msg = JSON.parse(raw.toString()); } catch { return; }
    if (!msg || typeof msg.type !== 'string') return;
    if (msg.type === 'join') {
      p.name = String(msg.name || 'Jugador').replace(/[<>\u0000-\u001f]/g, '').trim().slice(0,18) || 'Jugador';
      p.joined = true; players.set(p.id, p);
      safeSend(ws, { type:'welcome', id:p.id, players:[...players.values()].filter(q=>q.id!==p.id).map(publicPlayer) });
      broadcast({ type:'player-joined', player:publicPlayer(p) }, ws);
      broadcast({ type:'state', players:[...players.values()].map(publicPlayer) });
      return;
    }
    if (msg.type === 'move' && p.joined) {
      const now = Date.now(); if (now - p.lastMove < 35) return; p.lastMove = now;
      const num = v => Number.isFinite(Number(v)) ? Math.max(-1000, Math.min(1000, Number(v))) : 0;
      p.x=num(msg.x); p.y=num(msg.y); p.z=num(msg.z); p.rot=num(msg.rot);
      broadcast({ type:'move', player:publicPlayer(p) }, ws);
    }
  });
  ws.on('close', () => { if (players.delete(p.id)) { broadcast({ type:'player-left', id:p.id }); broadcast({ type:'state', players:[...players.values()].map(publicPlayer) }); } });
  ws.on('error', () => {});
});
const heartbeat = setInterval(() => { for (const ws of wss.clients) { if (!ws.isAlive) { ws.terminate(); continue; } ws.isAlive=false; ws.ping(); } }, 30000);
wss.on('close', () => clearInterval(heartbeat));
server.listen(PORT, '0.0.0.0', () => console.log(`El juego de Jacob WebSocket server on ${PORT}`));
