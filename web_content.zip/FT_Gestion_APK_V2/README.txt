FT GESTION V2

Cambios:
- Stock: papelera arriba a la derecha.
- Modo de eliminación: permite seleccionar uno o varios repuestos y eliminarlos.
- Venta: el selector de productos se reconstruye cada vez que se entra a Ventas.
- Se asegura que los 18 productos iniciales existan aunque el almacenamiento local haya quedado vacío.
- El precio se carga automáticamente al seleccionar un producto.

Para recompilar el APK, subí este ZIP al mismo conversor que usaste antes.
