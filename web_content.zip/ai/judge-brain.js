class EasukoJudgeBrain {
  constructor(localAI,memory=null){this.ai=localAI;this.memory=memory}
  evaluate(theme,prompt){
    const r=this.ai.evaluate(theme,prompt);
    this.memory?.learn(theme,prompt,r);
    r.ai_engine='えーすこAI Judge Brain v4.0';r.judge_personality='やさしい審査員';r.learning=this.memory?.stats()||{};r.review=this.makeReview(r);return r;
  }
  makeReview(r){const total=Number(r.total_score||0),good=(r.matched||[]).slice(0,3),missing=(r.missing||[]).slice(0,3),conflicts=(r.conflicts||[]).slice(0,2);let opening=total>=900?'すごいよっ！🌸 ほぼ完璧にお題を伝えられてるね！':total>=800?'とっても上手！✨ テーマの情景がかなりしっかり伝わってるよ♪':total>=650?'いい感じだよ！🌷 大事なところはしっかり拾えてるね。':total>=500?'ちゃんと土台ができてるよ♪ ここから少しずつ具体化していこう！':'大丈夫だよ🌱 最初は「どこで・誰が・何をしているか」から書けばOK！';const goodText=good.length?`特によかったのは「${good.join('」「')}」だよ。`:'まず挑戦して最後まで書けたことがえらいよ！';const missText=missing.length?`あと「${missing.join('」「')}」を入れると、もっとお題に近づくよ。`:'必須要素はかなり拾えているよ！';const conflictText=conflicts.length?`「${conflicts.join('」「')}」はお題とぶつかるので、そこだけ見直してみよう♪`:'';return {opening,goodText,missText,conflictText}}
}
window.EasukoJudgeBrain=EasukoJudgeBrain;
