class EasukoGameBrain {
  constructor(){this.round=1;this.streak=0;this.best=0;this.timeLimit=90;this.timerId=null;this.timeLeft=90}
  start(){this.round=1;this.streak=0;this.best=0;return this.snapshot()}
  nextRound(){this.round++;return this.snapshot()}
  startTimer(onTick,onTimeUp){this.stopTimer();this.timeLeft=this.timeLimit;onTick?.(this.timeLeft);this.timerId=setInterval(()=>{this.timeLeft--;onTick?.(this.timeLeft);if(this.timeLeft<=0){this.stopTimer();onTimeUp?.()}},1000)}
  stopTimer(){if(this.timerId){clearInterval(this.timerId);this.timerId=null}}
  record(score){this.best=Math.max(this.best,score);this.streak=score>=800?this.streak+1:0;return this.snapshot()}
  snapshot(){return {round:this.round,streak:this.streak,best:this.best,timeLeft:this.timeLeft}}
}
window.EasukoGameBrain=EasukoGameBrain;
