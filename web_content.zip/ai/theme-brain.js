class EasukoThemeBrain {
  constructor(concepts){
    this.concepts=concepts||{};
    this.moods=[
      ['cinematic','映画のワンシーンのような'],
      ['scale','大きさの対比が印象的な'],
      ['quiet','静かで幻想的な'],
      ['dynamic','動きが伝わる'],
      ['surreal','少し不思議な'],
      ['cute','かわいさのある']
    ];
  }
  pick(arr){return arr[Math.floor(Math.random()*arr.length)]}
  item(group){const a=this.concepts[group]||[];return this.pick(a)}
  clean(a){return [...new Set(a.filter(Boolean))]}
  generate(){
    const t=this.item('times'), pl=this.item('places'), su=this.item('subjects'), ac=this.item('actions'), rel=this.item('relations'), de=this.item('details');
    const extraSubject=this.item('subjects');
    const mood=this.pick(this.moods);
    const mode=Math.floor(Math.random()*7);
    let theme,must,important,optional;
    if(mode===0){
      theme=`${t[0]}の${pl[0]}で、${su[0]}が${ac[0]}。${rel[0]}。`;
      must=[t[0],pl[0],su[0],ac[0],rel[0]]; important=[de[0],de[1]]; optional=[mood[1]];
    } else if(mode===1){
      theme=`${t[0]}、${pl[0]}にて、${su[0]}と${extraSubject[0]}が向かい合っている。${rel[0]}、${de[0]}。`;
      must=[t[0],pl[0],su[0],extraSubject[0],rel[0]]; important=[de[0],de[1]]; optional=[ac[0]];
    } else if(mode===2){
      theme=`${pl[0]}の${t[0]}。${su[0]}が${ac[0]}し、${rel[0]}。${de[0]}。`;
      must=[pl[0],t[0],su[0],ac[0],rel[0],de[0]]; important=[de[1]]; optional=[mood[1]];
    } else if(mode===3){
      theme=`${t[0]}の${pl[0]}で、${su[0]}が${ac[0]}。${rel[0]}、さらに${de[0]}。`;
      must=[t[0],pl[0],su[0],ac[0],rel[0],de[0]]; important=[de[1]]; optional=[mood[1]];
    } else if(mode===4){
      theme=`${mood[1]}${t[0]}の${pl[0]}。${su[0]}が${ac[0]}し、${rel[0]}。`;
      must=[t[0],pl[0],su[0],ac[0],rel[0]]; important=[de[0]]; optional=[de[1],mood[1]];
    } else if(mode===5){
      theme=`${t[0]}の${pl[0]}で、${su[0]}が${ac[0]}。${de[0]}が見える中、${rel[0]}。`;
      must=[t[0],pl[0],su[0],ac[0],de[0],rel[0]]; important=[de[1]]; optional=[mood[1]];
    } else {
      theme=`${t[0]}、${pl[0]}。${su[0]}が${ac[0]}、${rel[0]}。${de[0]}。`;
      must=[t[0],pl[0],su[0],ac[0],rel[0],de[0]]; important=[de[1]]; optional=[mood[1]];
    }
    must=this.clean(must); important=this.clean(important).filter(x=>!must.includes(x)); optional=this.clean(optional).filter(x=>!must.includes(x)&&!important.includes(x));
    const bad=[];
    if(t[0].includes('夜')) bad.push('昼');
    if(t[0].includes('昼')) bad.push('夜');
    if(pl[0].includes('砂浜')) bad.push('砂漠');
    if(pl[0].includes('雪山')) bad.push('海辺');
    if(pl[0].includes('森')) bad.push('砂漠');
    return {theme,must_have:must,important,optional,forbidden_or_conflicting:this.clean(bad),generated:true,theme_engine:'えーすこAI Theme Brain v3.0'};
  }
}
window.EasukoThemeBrain=EasukoThemeBrain;
