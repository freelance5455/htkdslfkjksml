/* Easuko Memory Brain v4.0
 * Learns player-language associations locally. This is incremental memory,
 * not a hidden cloud model retraining service.
 */
class EasukoMemoryBrain {
  constructor(key='easuko-v4-memory') { this.key=key; this.data=this.load(); }
  load(){ try { return JSON.parse(localStorage.getItem(this.key)||'{"plays":0,"wins":0,"concepts":{},"examples":[]}'); } catch { return {plays:0,wins:0,concepts:{},examples:[]}; } }
  save(){ try{localStorage.setItem(this.key,JSON.stringify(this.data));}catch{} }
  tokens(text){ return String(text||'').toLowerCase().replace(/[^\p{L}\p{N}a-z0-9]+/giu,' ').split(/\s+/).filter(x=>x.length>=2).slice(0,500); }
  learn(theme,prompt,result){
    this.data.plays++;
    const score=Number(result?.total_score||0); if(score>=800)this.data.wins++;
    const all=[...(result?.matched||[])];
    const toks=this.tokens(prompt);
    for(const concept of all){
      const c=this.data.concepts[concept] ||= {hits:0,phrases:{}}; c.hits++;
      for(const t of toks){ c.phrases[t]=(c.phrases[t]||0)+1; }
    }
    this.data.examples.unshift({time:new Date().toISOString(),theme:theme?.theme||'',prompt:String(prompt||''),score,matched:result?.matched||[],missing:result?.missing||[],conflicts:result?.conflicts||[]});
    this.data.examples=this.data.examples.slice(0,300);
    this.save();
  }
  boost(item,prompt){
    const c=this.data.concepts[item]; if(!c)return 0;
    const toks=this.tokens(prompt); let hits=0,total=0;
    for(const t of toks){ if(c.phrases[t]){hits+=Math.min(3,c.phrases[t]);total+=3;} }
    return total?Math.min(.24,hits/total*.24):0;
  }
  stats(){return {plays:this.data.plays,wins:this.data.wins,concepts:Object.keys(this.data.concepts).length,examples:this.data.examples.length};}
  exportJSON(){return JSON.stringify({version:'4.0',exported_at:new Date().toISOString(),...this.data},null,2)}
  importJSON(text){const x=JSON.parse(text);if(!x||!Array.isArray(x.examples)||typeof x.concepts!=='object')throw new Error('えーすこAIの学習データではありません');this.data={plays:Number(x.plays||0),wins:Number(x.wins||0),concepts:x.concepts||{},examples:x.examples||[]};this.save();return this.stats();}
  reset(){this.data={plays:0,wins:0,concepts:{},examples:[]};this.save();}
}
window.EasukoMemoryBrain=EasukoMemoryBrain;
