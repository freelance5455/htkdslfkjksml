class EasukoLocalAI {
  constructor(memory=null){this.model=null;this.concepts=null;this.loaded=false;this.loading=null;this.memory=memory}
  async load(){
    if(this.loaded)return this;
    if(this.loading)return this.loading;
    this.loading=(async()=>{
      // APK/WebView互換: JSON fetchを使わず、埋め込みデータを最優先
      if(window.EASUKO_MODEL){
        this.model=window.EASUKO_MODEL;
        this.concepts=window.EASUKO_CONCEPTS||{};
        this.offline=false;
        this.loaded=true;
        return this;
      }
      // 通常ブラウザ用フォールバック
      try{
        const [mr,cr]=await Promise.all([fetch('ai/model.json?v=4.2'),fetch('ai/concepts.json?v=4.2')]);
        if(!mr.ok||!cr.ok)throw new Error('ローカルAIモデルを読み込めませんでした');
        this.model=await mr.json();
        this.concepts=await cr.json();
      }catch(e){
        this.model=null;
        this.concepts=window.EASUKO_CONCEPTS||{};
        this.offline=true;
      }
      this.loaded=true; return this;
    })(); return this.loading;
  }

  vectorize(text){
    if(!this.model)return new Map();
    const m=this.model,s=String(text||'').toLowerCase(),counts=new Map();
    for(let i=0;i<s.length;i++)for(let n=m.ngram_min;n<=m.ngram_max&&i+n<=s.length;n++){const gram=s.slice(i,i+n),idx=m.vocabulary[gram];if(idx!==undefined)counts.set(idx,(counts.get(idx)||0)+1)}
    const v=new Map();let norm=0;for(const [idx,c] of counts){const x=c*m.idf[idx];v.set(idx,x);norm+=x*x}norm=Math.sqrt(norm)||1;for(const [idx,x] of v)v.set(idx,x/norm);return v;
  }
  predict(text,label){if(!this.model)return 0; const v=this.vectorize(text),c=this.model.concepts[label];if(!c)return 0;let z=c.intercept;for(const [idx,x] of v)if(c.coef[idx]!==undefined)z+=c.coef[idx]*x;return this.sigmoid(z)}
  lexicalSignal(prompt,item){
    const p=String(prompt||'').toLowerCase();
    const aliases=this.concepts?.[item]||[item];
    let hits=0; for(const a of aliases){const x=String(a).toLowerCase();if(x&&p.includes(x))hits++}
    return aliases.length?Math.min(1,hits/Math.max(1,Math.min(3,aliases.length))):0;
  }
  conceptProb(prompt,item){
    const ml=this.predict(prompt,item); const lex=this.lexicalSignal(prompt,item);
    const learned=this.memory?.boost(item,prompt)||0;
    return Math.min(1,Math.max(ml,lex*.92)+learned);
  }
  evaluate(theme,prompt){
    const p=String(prompt||'').trim();
    const must=theme.must_have||[], important=theme.important||[], optional=theme.optional||[];
    const probs={}; for(const item of [...must,...important,...optional])probs[item]=this.conceptProb(p,item);
    const matched=[],missing=[];
    for(const item of must){if(probs[item]>=0.56)matched.push(item);else missing.push(item)}
    const importantMatched=important.filter(x=>probs[x]>=0.56);
    const relation=this.relationScore(theme,p,probs);
    const themeMatch=Math.round(500*((matched.length/(must.length||1))*0.82+Math.min(1,importantMatched.length/Math.max(1,important.length))*0.18));
    const lexical=this.lexicalSignals(p);
    const stateRelation=Math.round(200*relation);
    const composition=Math.min(150,Math.round(45+lexical.composition*70+Math.min(1,p.length/220)*35));
    const specificity=Math.min(100,Math.round(20+Math.min(1,p.length/320)*45+lexical.detail*35));
    const conflicts=(theme.forbidden_or_conflicting||[]).filter(x=>this.conflictHit(x,p));
    const conflict_control=Math.max(0,50-conflicts.length*18);
    const total=Math.max(0,Math.min(1000,themeMatch+stateRelation+composition+specificity+conflict_control));
    const advice=[];
    if(missing.length)advice.push(`「${missing.slice(0,2).join('」「')}」を、単語だけでなく位置や動作まで具体的に書いてみよう✨`);
    if(relation<0.65)advice.push('「誰が・何をしている・何とどう関係している」を1文でつなぐと、状態・関係の点数が伸びやすいよ♪');
    if(lexical.composition<0.5)advice.push('前景・背景・画角・構図・光の方向などを1〜2個足すと、画像生成AIにも伝わりやすくなるよ📐');
    if(conflicts.length)advice.push(`「${conflicts[0]}」はお題とぶつかりやすい表現。別の言い方に変えてみよう！`);
    if(!advice.length)advice.push('かなり具体的！テーマの要素だけでなく、関係性まで伝わっているよ🌸');
    let reason=total>=850?'すごい！お題の主要要素がかなり明確で、AIが情景を組み立てやすいプロンプトになってるよ🌸':total>=700?'かなりいい感じ♪ 主要な要素は伝わっているよ。あと少しだけ「関係性」や「画面内の位置」を足すと、さらに強くなる！':total>=500?'土台はできてるよ！いくつかの重要要素が見つかっているので、足りない部分を具体的に補えば一気に伸びそう✨':'大丈夫！まずはお題の必須要素を全部拾って、「誰が・どこで・何をしているか」を書くところから始めよう🌱';
    return {theme_match:themeMatch,state_relation:stateRelation,composition,specificity,conflict_control,total_score:total,matched,missing,conflicts,reason,advice,local:true,ai_engine:'えーすこAI v2.0'};
  }
  relationScore(theme,p,probs){
    const joined=[...(theme.must_have||[]),...(theme.important||[])];
    const detected=joined.filter(x=>(probs[x]??0)>=0.56).length/Math.max(1,joined.length);
    const hasVerb=/(している|してる|する|飲む|見る|掲げる|座る|持つ|差す|見守|立つ|浸す|入れる|歩く|浮く|飛ぶ|抱く|乗る|握る|standing|drinking|watching|holding|sitting|walking|looking|wearing|drinks|stands|sits)/i.test(p);
    const hasRelation=/(が|を|に|で|の|と|から|前景|背景|左|右|中央|遠く|手前|奥|behind|front|near|far|left|right|center)/i.test(p);
    return Math.min(1,detected*.55+(hasVerb?.28:0)+(hasRelation?.17:0));
  }
  lexicalSignals(p){
    const compositionWords=['構図','画角','ローアングル','俯瞰','正面','横顔','前景','背景','中央','左側','右側','手前','奥','遠景','クローズアップ','wide shot','close-up','low angle','high angle','foreground','background','center','left','right'];
    const detailWords=['高精細','細部','質感','光','照明','陰影','反射','被写界深度','レンズ','色','彩度','コントラスト','8k','high detail','lighting','texture','reflection','depth of field','cinematic'];
    const c=compositionWords.filter(x=>p.toLowerCase().includes(x.toLowerCase())).length,d=detailWords.filter(x=>p.toLowerCase().includes(x.toLowerCase())).length;
    return {composition:Math.min(1,c/3),detail:Math.min(1,d/4)};
  }
  conflictHit(x,p){
    const groups={'夜':['夜','深夜','night'],'昼':['昼','昼間','day','daytime'],'森の中':['森','森林','forest'],'砂漠':['砂漠','desert'],'真夏':['真夏','夏','summer'],'海辺':['海辺','海岸','海','seaside'],'猫が巨大':['巨大な猫','猫が巨大','giant cat'],'鹿が普通の動物':['普通の鹿','普通の動物','real deer','normal deer']};
    const a=groups[x]||[x];return a.some(k=>p.toLowerCase().includes(k.toLowerCase()));
  }
}
window.EasukoLocalAI=EasukoLocalAI;
