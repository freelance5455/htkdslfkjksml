const {onCall, HttpsError} = require('firebase-functions/v2/https');
const {defineSecret} = require('firebase-functions/params');
const admin = require('firebase-admin');
const nodemailer = require('nodemailer');
admin.initializeApp();
const db=admin.firestore();
const SMTP_HOST=defineSecret('SMTP_HOST'), SMTP_PORT=defineSecret('SMTP_PORT'), SMTP_USER=defineSecret('SMTP_USER'), SMTP_PASS=defineSecret('SMTP_PASS'), SMTP_FROM=defineSecret('SMTP_FROM');
const rateLimit=async(email,action)=>{const ref=db.collection('otpRateLimits').doc(`${action}_${Buffer.from(email).toString('base64url')}`);await db.runTransaction(async tx=>{const s=await tx.get(ref);const now=Date.now();const d=s.exists?s.data():{count:0,last:0};if(now-d.last<60000)throw new HttpsError('resource-exhausted','انتظر دقيقة قبل طلب رمز جديد.');tx.set(ref,{count:d.count+1,last:now},{merge:true});});};
function transporter(){return nodemailer.createTransport({host:SMTP_HOST.value(),port:Number(SMTP_PORT.value()||465),secure:Number(SMTP_PORT.value()||465)===465,auth:{user:SMTP_USER.value(),pass:SMTP_PASS.value()}});}
exports.sendSignupOtp=onCall({secrets:[SMTP_HOST,SMTP_PORT,SMTP_USER,SMTP_PASS,SMTP_FROM],enforceAppCheck:false},async req=>{
 const email=String(req.data?.email||'').trim().toLowerCase(),fullName=String(req.data?.fullName||'').trim();if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)||!fullName)throw new HttpsError('invalid-argument','أدخل اسمًا وبريدًا صحيحًا.');
 const existing=await admin.auth().getUserByEmail(email).catch(e=>e.code==='auth/user-not-found'?null:Promise.reject(e));if(existing)throw new HttpsError('already-exists','هذا البريد مسجل مسبقًا.');await rateLimit(email,'signup');
 const code=String(require('crypto').randomInt(100000,1000000));const hash=require('crypto').createHash('sha256').update(code).digest('hex');await db.collection('emailOtps').doc(`signup_${Buffer.from(email).toString('base64url')}`).set({email,fullName,hash,expiresAt:Date.now()+10*60*1000,attempts:0,createdAt:admin.firestore.FieldValue.serverTimestamp()});
 try{await transporter().sendMail({from:SMTP_FROM.value(),to:email,subject:'رمز التحقق — BRISK',text:`مرحبًا ${fullName}\nرمز التحقق الخاص بك هو: ${code}\nالرمز صالح لمدة 10 دقائق. لا تشاركه مع أي شخص.`,html:`<div dir="rtl" style="font-family:Arial,sans-serif;color:#201b31"><h2 style="color:#382977">BRISK</h2><p>مرحبًا ${escapeHtml(fullName)}،</p><p>رمز التحقق الخاص بك:</p><div style="font-size:30px;font-weight:bold;letter-spacing:8px;color:#382977">${code}</div><p>الرمز صالح لمدة 10 دقائق. لا تشاركه مع أي شخص.</p></div>`});return {ok:true};}catch(e){await db.collection('emailOtps').doc(`signup_${Buffer.from(email).toString('base64url')}`).delete();console.error(e);throw new HttpsError('internal','تعذر إرسال البريد. تحقق من إعدادات البريد الإلكتروني.');}
});
exports.verifySignupOtp=onCall({secrets:[SMTP_HOST,SMTP_PORT,SMTP_USER,SMTP_PASS,SMTP_FROM]},async req=>{
 const d=req.data||{},email=String(d.email||'').trim().toLowerCase(),code=String(d.code||''),fullName=String(d.fullName||'').trim();if(!/^\d{6}$/.test(code)||!email)throw new HttpsError('invalid-argument','رمز التحقق غير صالح.');
 const key=`signup_${Buffer.from(email).toString('base64url')}`,ref=db.collection('emailOtps').doc(key);let outcome='ok';
 await db.runTransaction(async tx=>{const s=await tx.get(ref);if(!s.exists){outcome='missing';return;}const otp=s.data();if(otp.expiresAt<Date.now()){tx.delete(ref);outcome='expired';return;}if(otp.attempts>=5){outcome='locked';return;}const hash=require('crypto').createHash('sha256').update(code).digest('hex');if(hash!==otp.hash){tx.update(ref,{attempts:otp.attempts+1});outcome='wrong';return;}tx.delete(ref);});
 if(outcome==='missing')throw new HttpsError('not-found','لا يوجد رمز فعال. اطلب رمزًا جديدًا.');
 if(outcome==='expired')throw new HttpsError('deadline-exceeded','انتهت صلاحية الرمز. اطلب رمزًا جديدًا.');
 if(outcome==='locked')throw new HttpsError('resource-exhausted','تجاوزت عدد المحاولات المسموح. اطلب رمزًا جديدًا.');
 if(outcome==='wrong')throw new HttpsError('permission-denied','رمز التحقق غير صحيح.');
 const exists=await admin.auth().getUserByEmail(email).catch(e=>e.code==='auth/user-not-found'?null:Promise.reject(e));if(exists)throw new HttpsError('already-exists','هذا البريد مسجل مسبقًا.');
 const user=await admin.auth().createUser({email,password:String(d.password||''),displayName:fullName,emailVerified:true});
 const serial=await db.runTransaction(async tx=>{const ref=db.collection('sequences').doc('userSerial');const s=await tx.get(ref);const n=(s.exists?s.data().value:0)+1;tx.set(ref,{value:n});return n;});
 const profile={uid:user.uid,fullName,email,whatsapp:String(d.whatsapp||''),university:String(d.university||''),faculty:String(d.faculty||''),major:String(d.major||''),level:String(d.level||''),area:String(d.area||''),dob:String(d.dob||''),username:`${String(d.gender||'').toLowerCase()==='female'?'226':'126'}${String(serial).padStart(5,'0')}`,role:'student',status:'active',createdAt:admin.firestore.FieldValue.serverTimestamp()};await db.collection('users').doc(user.uid).set(profile);return {ok:true,username:profile.username};
});
exports.adminDashboardStats=onCall(async req=>{if(!req.auth)throw new HttpsError('unauthenticated','سجّل الدخول أولًا.');const u=await admin.auth().getUser(req.auth.uid);if(u.customClaims?.role!=='admin'&&u.customClaims?.admin!==true)throw new HttpsError('permission-denied','هذه الوظيفة للمدير فقط.');const counts=await Promise.all(['users','courses','certificates'].map(async c=>(await db.collection(c).count().get()).data().count));return {users:counts[0],courses:counts[1],certificates:counts[2]};});
function escapeHtml(s){return s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
