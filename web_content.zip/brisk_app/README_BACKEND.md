# BRISK Academy — تطبيق مستقل (نسخة بداية قابلة للربط)

واجهة عربية مستقلة بخلفية بيضاء وهوية BRISK (#382977 و #e6b036) وخط Tajawal. مبني بـ HTML/CSS/JavaScript العادي وليس React.

## ما الموجود؟
- شاشة ترحيب، تسجيل دخول، إنشاء حساب ببيانات الطالب، شاشة OTP بستة أرقام، استعادة كلمة المرور، وصفحة رئيسية.
- إرسال OTP من خادم Firebase Cloud Functions عبر SMTP، وتخزين hash للرمز فقط، وصلاحية 10 دقائق، وحد للمحاولات، ومعدل إرسال.
- إنشاء الحساب في Firebase Authentication وملف المستخدم في Firestore بعد نجاح OTP.
- لوحة مدير لا تظهر إلا لمن لديه custom claim باسم role=admin أو admin=true.
- قواعد Firestore مبدئية تقفل بيانات OTP والتسلسلات وتمنع التعديل الإداري لغير المدير.

## مهم قبل التشغيل
لا يمكن اعتبار الربط حيًا حتى توضع إعدادات Firebase الحقيقية وبيانات SMTP ويُنشر الخادم. الملف المرفق PDF يحتوي على قيم تجريبية مثل YOUR_FIREBASE_API_KEY و service_xxxxxxx؛ لذلك لم أخترع مفاتيح أو أدّعِ أن الإرسال يعمل الآن.

### 1) إعداد Firebase
1. افتح Firebase Console للمشروع `brisk-62baa` ثم Project settings > Your apps.
2. انسخ إعدادات تطبيق الويب إلى `firebaseConfig` في `app.js`، مع مراجعة `storageBucket` و`appId` من القيم الرسمية.
3. فعّل Email/Password في Authentication.
4. أنشئ Firestore Database، ثم انشر `firestore.rules`.
5. ثبّت Firebase CLI وسجّل الدخول، ثم من مجلد المشروع نفّذ `firebase use brisk-62baa`.

### 2) إعداد إرسال OTP
من داخل مجلد المشروع، اضبط أسرار SMTP في Firebase Functions (مثال باستخدام بريد يتيح SMTP أو Gmail App Password):
```bash
firebase functions:secrets:set SMTP_HOST
firebase functions:secrets:set SMTP_PORT
firebase functions:secrets:set SMTP_USER
firebase functions:secrets:set SMTP_PASS
firebase functions:secrets:set SMTP_FROM
```
أدخل القيمة المطلوبة عند الطلب. لا تضع كلمة مرور البريد أو مفاتيح خاصة داخل ملفات الواجهة.

ثم:
```bash
cd functions && npm install && cd ..
firebase deploy --only functions,firestore:rules,hosting
```

### 3) تعيين حساب المدير
لا يوجد مدير افتراضي، منعًا لفتح لوحة التحكم لأي شخص. بعد إنشاء حسابك والتحقق منه، شغّل سكربت إداري موثوق خارج الواجهة (باستخدام Firebase Admin SDK ومفتاح خدمة محفوظ بأمان) لتعيين custom claim:
```js
await admin.auth().setCustomUserClaims('FIREBASE_UID_HERE', { role: 'admin' });
```
ثم سجّل الخروج والدخول مجددًا. لا تضع service-account key في هذا المشروع أو في المتصفح.

## حدود هذه النسخة
هذه حزمة بداية عملية للواجهة ومسار OTP وخدمات أساسية، وليست نسخة إنتاج مكتملة من كل مواصفات ملف PDF. لوحة الإدارة تعرض مؤشرات أولية وأزرارًا إرشادية؛ ما زالت جداول الإدارة التفصيلية وإصدار PDF للشهادات مع QR والتحقق العام وإدارة الكورسات/المشاريع/الإعلانات والموظفين والرسوم والشكاوى بحاجة إلى بناء واختبار. كذلك التسجيل الحالي لا يحتوي اختيار الجنس رغم أن مواصفات PDF تذكره؛ يجب إضافته قبل اعتماد صيغة أرقام المستخدمين النهائية. لا ترفعها لمستخدمين حقيقيين قبل اختبار الأمان وقواعد البيانات والبريد على مشروع تجريبي.
