MEETING SCHEDULER — ANDROID STUDIO PROJECT
Designed by Thejus

This package contains the Android Studio source project and the current website app embedded as an offline Android WebView app.

BUILD APK
1. Install Android Studio (current stable version) on your computer.
2. Extract this ZIP file.
3. In Android Studio choose Open, then select the extracted MeetingScheduler folder.
4. Allow Gradle sync and install the Android SDK Platform 35 if Android Studio asks.
5. To create an installable APK: Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Android Studio will show a notification with the APK location. Usually:
   app/build/outputs/apk/debug/app-debug.apk
7. Transfer that APK to your Android phone and install it. If prompted, allow installation from that source.

APP DETAILS
- App ID: com.thejus.meetingscheduler
- Minimum Android: 6.0 (API 23)
- Offline app; meeting records are stored locally on the device in WebView storage.
- Daily schedule image sharing opens the Android share sheet (WhatsApp can be selected).
- Report generation uses Android's print service; choose Save as PDF.

IMPORTANT DATA NOTE
The app stores meeting data locally. Do not clear the app's storage or uninstall it unless you have exported/backed up your data. The app does not sync to a cloud account.

This is an Android Studio source package, not a precompiled APK. An APK must be built using Android Studio / Android SDK.
