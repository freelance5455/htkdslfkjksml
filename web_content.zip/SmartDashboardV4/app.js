/*
  SMART DASHBOARD V4
  Real services only.
  No fake data.
*/

"use strict";

/* =========================================================
   CONFIGURATION
========================================================= */

const CONFIG = {
  termuxServer: "http://192.168.0.252:8787",

  ntfy: {
    dinner: "dinner",
    shopping: "jacob-home-shopping7f42k9",
    jacob: "request-jacob-only6655223",
    bothKids: "request-both-kids-button290713201017"
  },

  footballUrl:
    "https://site.api.espn.com/apis/site/v2/sports/soccer/eng.1/scoreboard",

  weatherUrl:
    "https://api.open-meteo.com/v1/forecast"
};

/* =========================================================
   STATE
========================================================= */

const state = {
  currentPerson: null,
  presence: {},
  weather: null,
  services: {},
  nightMode: false,
  ambientMode: false,
  guestMode: false,
  bootComplete: false
};

/* =========================================================
   HELPERS
========================================================= */

function $(id) {
  return document.getElementById(id);
}

function showToast(message) {
  const toast = $("toast");

  if (!toast) return;

  toast.textContent = message;
  toast.classList.add("show");

  clearTimeout(showToast.timer);

  showToast.timer = setTimeout(() => {
    toast.classList.remove("show");
  }, 3000);
}

function setText(id, text) {
  const element = $(id);
  if (element) element.textContent = text;
}

function isAndroidBridgeAvailable() {
  return !!(
    window.Android &&
    typeof window.Android === "object"
  );
}

async function fetchWithTimeout(url, options = {}, timeout = 8000) {
  const controller = new AbortController();

  const timer = setTimeout(() => {
    controller.abort();
  }, timeout);

  try {
    return await fetch(url, {
      ...options,
      signal: controller.signal,
      cache: "no-store"
    });
  } finally {
    clearTimeout(timer);
  }
}

/* =========================================================
   PAGE NAVIGATION
========================================================= */

function openPage(pageId) {
  document.querySelectorAll(".page").forEach(page => {
    page.classList.remove("active");
  });

  const page = $(pageId);

  if (!page) {
    showToast("That page is unavailable.");
    return;
  }

  page.classList.add("active");

  document.querySelectorAll(".nav-button").forEach(button => {
    button.classList.toggle(
      "active",
      button.dataset.page === pageId
    );
  });

  window.scrollTo({
    top: 0,
    behavior: "smooth"
  });
}

function goHome() {
  openPage("homePage");
}

function openMusic() {
  openPage("musicPage");
}

function openShopping() {
  openPage("shoppingPage");
}

function openShortcuts() {
  openPage("shortcutsPage");
}

function openAirPlay() {
  openPage("airplayPage");

  if (isAndroidBridgeAvailable()) {
    setText(
      "airplayMessage",
      "Native Android bridge detected. Tap Find AirPlay Devices to begin."
    );
  } else {
    setText(
      "airplayMessage",
      "AirPlay requires the native Android V4 build. The control page is available in preview."
    );
  }
}

function openSystemStatus() {
  openPage("statusPage");
  runServiceChecks();
}

/* =========================================================
   CLOCK
========================================================= */

function updateClock() {
  const now = new Date();

  const time = now.toLocaleTimeString("en-GB", {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit"
  });

  const shortTime = now.toLocaleTimeString("en-GB", {
    hour: "2-digit",
    minute: "2-digit"
  });

  const date = now.toLocaleDateString("en-GB", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric"
  });

  const shortDate = now.toLocaleDateString("en-GB", {
    weekday: "long",
    day: "numeric",
    month: "long"
  });

  setText("clock", shortTime);
  setText("bigClock", shortTime);
  setText("seconds", time.split(":")[2] + " seconds");
  setText("dateLong", date);
  setText("dateText", shortDate);

  let greeting = "GOOD DAY";

  const hour = now.getHours();

  if (hour < 5) greeting = "GOOD NIGHT";
  else if (hour < 12) greeting = "GOOD MORNING";
  else if (hour < 18) greeting = "GOOD AFTERNOON";
  else greeting = "GOOD EVENING";

  setText("greeting", greeting);
}

/* =========================================================
   PRESENCE
========================================================= */

async function refreshPresence() {
  try {
    const response = await fetchWithTimeout(
      `${CONFIG.termuxServer}/api/presence`
    );

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }

    const data = await response.json();

    state.presence = data;

    ["Jacob", "Mum", "Dad"].forEach(name => {
      const person = data[name];

      if (!person) {
        setPresenceUI(name, "unknown", "No data");
        return;
      }

      const status = person.status || "unknown";

      let label = "Unknown";

      if (status === "home") label = "Home";
      if (status === "away") label = "Away";

      setPresenceUI(name, status, label);
    });

    setText(
      "presenceConnection",
      "● Tracking server online"
    );

    state.services.presence = true;

  } catch (error) {

    state.services.presence = false;

    ["Jacob", "Mum", "Dad"].forEach(name => {
      setPresenceUI(name, "unknown", "Unavailable");
    });

    setText(
      "presenceConnection",
      "● Tracking server unavailable"
    );
  }
}

function setPresenceUI(name, status, label) {
  setText(`presence-${name}`, label);

  const dot = $(`dot-${name}`);

  if (!dot) return;

  dot.className = `presence-dot ${status}`;
}

function openPerson(name) {
  state.currentPerson = name;

  const data = state.presence[name];

  setText("personPageName", name);

  if (!data) {
    setText("personStatusLarge", "Unknown");
    setText("personLastUpdate", "No data received.");
    setText("personDistance", "Distance unavailable.");
  } else {

    const status =
      data.status === "home"
        ? "Home"
        : data.status === "away"
          ? "Away"
          : "Unknown";

    setText("personStatusLarge", status);

    if (data.last_update) {
      const date = new Date(data.last_update);

      setText(
        "personLastUpdate",
        `Last update: ${date.toLocaleString("en-GB")}`
      );
    } else {
      setText("personLastUpdate", "No update received.");
    }

    if (
      typeof data.distance_meters === "number"
    ) {
      setText(
        "personDistance",
        `Distance from home: ${Math.round(data.distance_meters)} m`
      );
    } else {
      setText(
        "personDistance",
        "Distance is calculated by the Termux server."
      );
    }
  }

  const icons = {
    Jacob: "👤",
    Mum: "👩",
    Dad: "👨"
  };

  setText(
    "personLargeIcon",
    icons[name] || "👤"
  );

  openPage("personPage");
}

/* =========================================================
   WEATHER
========================================================= */

async function getWeatherCoordinates() {

  if (!navigator.geolocation) {
    throw new Error("Geolocation is unavailable");
  }

  return new Promise((resolve, reject) => {

    navigator.geolocation.getCurrentPosition(
      position => {
        resolve({
          latitude: position.coords.latitude,
          longitude: position.coords.longitude
        });
      },
      error => {
        reject(error);
      },
      {
        enableHighAccuracy: false,
        timeout: 10000,
        maximumAge: 600000
      }
    );

  });
}

function weatherCodeToText(code) {

  const map = {
    0: ["Clear sky", "☀️"],
    1: ["Mainly clear", "🌤️"],
    2: ["Partly cloudy", "⛅"],
    3: ["Overcast", "☁️"],
    45: ["Fog", "🌫️"],
    48: ["Rime fog", "🌫️"],
    51: ["Light drizzle", "🌦️"],
    53: ["Drizzle", "🌦️"],
    55: ["Heavy drizzle", "🌧️"],
    61: ["Light rain", "🌧️"],
    63: ["Rain", "🌧️"],
    65: ["Heavy rain", "🌧️"],
    71: ["Light snow", "🌨️"],
    73: ["Snow", "🌨️"],
    75: ["Heavy snow", "❄️"],
    80: ["Rain showers", "🌦️"],
    81: ["Rain showers", "🌧️"],
    82: ["Heavy showers", "⛈️"],
    95: ["Thunderstorm", "⛈️"],
    96: ["Thunderstorm", "⛈️"],
    99: ["Thunderstorm", "⛈️"]
  };

  return map[code] || ["Unknown", "🌤️"];
}

async function refreshWeather() {

  setText("weatherStatus", "Loading");

  try {

    const coords = await getWeatherCoordinates();

    const url =
      `${CONFIG.weatherUrl}` +
      `?latitude=${encodeURIComponent(coords.latitude)}` +
      `&longitude=${encodeURIComponent(coords.longitude)}` +
      `&current=temperature_2m,relative_humidity_2m,wind_speed_10m,weather_code` +
      `&timezone=auto`;

    const response = await fetchWithTimeout(url);

    if (!response.ok) {
      throw new Error(`Weather HTTP ${response.status}`);
    }

    const data = await response.json();

    state.weather = data.current;

    const [description, icon] =
      weatherCodeToText(data.current.weather_code);

    setText(
      "temperature",
      `${Math.round(data.current.temperature_2m)}°`
    );

    setText("weatherDescription", description);
    setText("weatherIcon", icon);

    setText(
      "humidity",
      `${Math.round(data.current.relative_humidity_2m)}%`
    );

    setText(
      "wind",
      `${Math.round(data.current.wind_speed_10m)} km/h`
    );

    setText("weatherStatus", "Live");

    state.services.weather = true;

  } catch (error) {

    state.services.weather = false;

    setText("weatherStatus", "Unavailable");
    setText("weatherDescription", "Real weather could not be loaded.");
    setText("temperature", "--°");
    setText("humidity", "--%");
    setText("wind", "-- km/h");

    showToast(
      "Weather needs location permission in the browser preview."
    );
  }
}

/* =========================================================
   NTFY
========================================================= */

async function sendNtfy(
  topic,
  title,
  message,
  options = {}
) {

  if (!topic) {
    throw new Error("No ntfy topic configured");
  }

  const priority =
    options.priority || "high";

  const tags =
    options.tags || "house";

  const url =
    `https://ntfy.sh/${encodeURIComponent(topic)}` +
    `?title=${encodeURIComponent(title)}` +
    `&priority=${encodeURIComponent(priority)}` +
    `&tags=${encodeURIComponent(tags)}`;

  const response = await fetchWithTimeout(
    url,
    {
      method: "POST",
      headers: {
        "Content-Type":
          "text/plain;charset=UTF-8"
      },
      body: String(message)
    },
    10000
  );

  if (!response.ok) {
    throw new Error(
      `ntfy HTTP ${response.status}`
    );
  }

  return true;
}

/* =========================================================
   SHOPPING
========================================================= */

async function sendShopping() {

  const input = $("shoppingInput");

  if (!input) return;

  const item = input.value.trim();

  if (!item) {
    showToast("Enter something for the shopping list.");
    input.focus();
    return;
  }

  setText(
    "shoppingResult",
    "Sending shopping request…"
  );

  try {

    await sendNtfy(
      CONFIG.ntfy.shopping,
      "Smart Dashboard Shopping",
      item,
      {
        priority: "high",
        tags: "shopping"
      }
    );

    setText(
      "shoppingResult",
      `✓ Sent "${item}" to the shopping system.`
    );

    input.value = "";

    showToast("Shopping item sent.");

  } catch (error) {

    setText(
      "shoppingResult",
      `✕ Shopping notification failed: ${error.message}`
    );

    showToast("Shopping notification failed.");
  }
}

/* =========================================================
   DINNER
========================================================= */

async function sendDinner() {

  try {

    await sendNtfy(
      CONFIG.ntfy.dinner,
      "Dinner",
      "Dinner is ready! 🍽️",
      {
        priority: "high",
        tags: "food"
      }
    );

    showToast("Dinner notification sent.");

  } catch (error) {

    showToast(
      `Dinner notification failed: ${error.message}`
    );
  }
}

/* =========================================================
   SHORTCUT NOTIFICATIONS
========================================================= */

async function notifyTopic(
  topic,
  title,
  message
) {

  const result = $("shortcutResult");

  if (result) {
    result.textContent = "Sending notification…";
  }

  try {

    await sendNtfy(
      topic,
      title,
      message,
      {
        priority: "high",
        tags: "house"
      }
    );

    if (result) {
      result.textContent =
        "✓ Notification sent successfully.";
    }

    showToast("Notification sent.");

  } catch (error) {

    if (result) {
      result.textContent =
        `✕ Notification failed: ${error.message}`;
    }

    showToast("Notification failed.");
  }
}

function sendJacob() {

  return notifyTopic(
    CONFIG.ntfy.jacob,
    "Smart Dashboard",
    "Hello Jacob 👋"
  );
}

function sendMum() {

  showToast(
    "Mum notification requires Mum's configured ntfy topic."
  );

  setText(
    "shortcutResult",
    "Mum's notification topic has not been configured in V4."
  );
}

function sendDad() {

  showToast(
    "Dad notification requires Dad's configured ntfy topic."
  );

  setText(
    "shortcutResult",
    "Dad's notification topic has not been configured in V4."
  );
}

function sendBothKids() {

  return notifyTopic(
    CONFIG.ntfy.bothKids,
    "Smart Dashboard",
    "Hello kids 👋"
  );
}

/* =========================================================
   SPOTIFY / MEDIA
========================================================= */

function openSpotify() {

  window.open(
    "https://open.spotify.com/",
    "_blank",
    "noopener,noreferrer"
  );

  showToast("Opening Spotify.");
}

function musicAction(action) {

  if (
    isAndroidBridgeAvailable() &&
    typeof window.Android.mediaAction === "function"
  ) {

    try {

      window.Android.mediaAction(action);

      showToast(
        `Media action: ${action}`
      );

      return;

    } catch (error) {
      showToast(
        "Android media control failed."
      );
      return;
    }
  }

  showToast(
    "Native media controls are available in the Android V4 build."
  );
}

function updateMediaInfo(data) {

  if (!data) return;

  const title =
    data.title || "No media detected";

  const artist =
    data.artist ||
    "Android media session will appear here";

  setText("trackTitle", title);
  setText("trackArtist", artist);

  setText("musicPageTitle", title);
  setText("musicPageArtist", artist);

  if (data.artwork) {

    const art =
      `url("${data.artwork}")`;

    const album = $("albumArt");
    const pageAlbum = $("musicPageArt");

    if (album) {
      album.style.backgroundImage = art;
      album.textContent = "";
    }

    if (pageAlbum) {
      pageAlbum.style.backgroundImage = art;
      pageAlbum.textContent = "";
    }
  }
}

/* =========================================================
   AIRPLAY
========================================================= */

function startAirPlay() {

  if (
    isAndroidBridgeAvailable() &&
    typeof window.Android.startAirPlay === "function"
  ) {

    try {

      window.Android.startAirPlay();

      setText(
        "airplayMessage",
        "AirPlay discovery started."
      );

      showToast("Searching for AirPlay devices.");

      return;

    } catch (error) {

      setText(
        "airplayMessage",
        "Native AirPlay discovery failed."
      );

      return;
    }
  }

  setText(
    "airplayMessage",
    "AirPlay requires the native Android V4 implementation. This preview cannot access Android network/media discovery."
  );

  showToast(
    "AirPlay is a native Android feature."
  );
}

/* =========================================================
   SETTINGS
========================================================= */

function toggleNightMode() {

  state.nightMode =
    !state.nightMode;

  document.body.classList.toggle(
    "night-mode",
    state.nightMode
  );

  setText(
    "nightModeText",
    state.nightMode ? "On" : "Off"
  );

  showToast(
    `Night Mode ${state.nightMode ? "enabled" : "disabled"}.`
  );
}

function toggleAmbient() {

  state.ambientMode =
    !state.ambientMode;

  document.body.classList.toggle(
    "ambient-mode",
    state.ambientMode
  );

  setText(
    "ambientText",
    state.ambientMode ? "On" : "Off"
  );

  showToast(
    `Ambient Mode ${state.ambientMode ? "enabled" : "disabled"}.`
  );
}

function toggleGuestMode() {

  state.guestMode =
    !state.guestMode;

  setText(
    "guestText",
    state.guestMode ? "On" : "Off"
  );

  showToast(
    `Guest Mode ${state.guestMode ? "enabled" : "disabled"}.`
  );
}

/* =========================================================
   SERVICE CHECKS
========================================================= */

async function checkInternet() {

  try {

    const response =
      await fetchWithTimeout(
        "https://ntfy.sh",
        {
          method: "GET"
        },
        7000
      );

    return response.ok;

  } catch {
    return false;
  }
}

async function checkNtfy() {

  try {

    const response =
      await fetchWithTimeout(
        "https://ntfy.sh",
        {
          method: "GET"
        },
        7000
      );

    return response.ok;

  } catch {
    return false;
  }
}

async function checkFootball() {

  try {

    const response =
      await fetchWithTimeout(
        CONFIG.footballUrl,
        {},
        8000
      );

    if (!response.ok) return false;

    const data =
      await response.json();

    return Array.isArray(data.events);

  } catch {
    return false;
  }
}

async function checkShopping() {

  try {

    const response =
      await fetchWithTimeout(
        `https://ntfy.sh/${encodeURIComponent(
          CONFIG.ntfy.shopping
        )}/json?poll=1`,
        {},
        7000
      );

    return response.ok;

  } catch {
    return false;
  }
}

async function checkPresence() {

  try {

    const response =
      await fetchWithTimeout(
        `${CONFIG.termuxServer}/api/health`,
        {},
        5000
      );

    if (!response.ok) return false;

    const data =
      await response.json();

    return data.status === "online";

  } catch {
    return false;
  }
}

async function checkSpotify() {

  if (
    isAndroidBridgeAvailable() &&
    typeof window.Android.checkSpotify === "function"
  ) {

    try {
      return !!window.Android.checkSpotify();
    } catch {
      return false;
    }
  }

  /*
    Browser preview cannot access Android Spotify state.
    We deliberately report this as unavailable rather than
    pretending Spotify is connected.
  */
  return false;
}

async function runServiceChecks() {

  const statusList = $("statusList");

  if (!statusList) return;

  statusList.innerHTML =
    `<div class="status-row">
      <span>Running checks…</span>
      <span class="status-warning">…</span>
    </div>`;

  const checks = [
    ["Internet", checkInternet],
    ["ntfy", checkNtfy],
    ["Shopping", checkShopping],
    ["Football", checkFootball],
    ["Presence / Termux", checkPresence],
    ["Spotify / Android", checkSpotify]
  ];

  const results = [];

  for (const [name, fn] of checks) {

    const ok = await fn();

    state.services[name] = ok;

    results.push({
      name,
      ok
    });
  }

  statusList.innerHTML = "";

  results.forEach(result => {

    const row =
      document.createElement("div");

    row.className = "status-row";

    row.innerHTML = `
      <div>
        <strong>${escapeHtml(result.name)}</strong>
        <br>
        <small>
          ${result.ok ? "Service available" : "Service unavailable"}
        </small>
      </div>

      <strong class="${
        result.ok
          ? "status-success"
          : "status-error"
      }">
        ${result.ok ? "ONLINE" : "OFFLINE"}
      </strong>
    `;

    statusList.appendChild(row);
  });
}

function escapeHtml(value) {

  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

/* =========================================================
   BOOT
========================================================= */

function renderBootCheck(
  name,
  stateName,
  message
) {

  const container = $("bootChecks");

  if (!container) return;

  let row =
    document.querySelector(
      `[data-boot-check="${CSS.escape(name)}"]`
    );

  if (!row) {

    row =
      document.createElement("div");

    row.className = "boot-check";
    row.dataset.bootCheck = name;

    row.innerHTML = `
      <div class="check-left">
        <span class="check-icon">○</span>
        <strong>${escapeHtml(name)}</strong>
      </div>

      <span class="check-status"></span>
    `;

    container.appendChild(row);
  }

  const icon =
    row.querySelector(".check-icon");

  const status =
    row.querySelector(".check-status");

  if (stateName === "checking") {

    icon.textContent = "◌";
    icon.className =
      "check-icon check-wait";

    status.textContent =
      message || "Checking…";

  } else if (stateName === "ok") {

    icon.textContent = "✓";
    icon.className =
      "check-icon check-ok";

    status.textContent =
      message || "OK";

  } else {

    icon.textContent = "×";
    icon.className =
      "check-icon check-fail";

    status.textContent =
      message || "Failed";
  }
}

async function runBootChecks() {

  const bootError =
    $("bootError");

  const retry =
    $("bootRetry");

  if (bootError) {
    bootError.classList.add("hidden");
    bootError.textContent = "";
  }

  if (retry) {
    retry.classList.add("hidden");
  }

  $("bootChecks").innerHTML = "";

  const services = [
    ["Internet", checkInternet],
    ["ntfy", checkNtfy],
    ["Shopping", checkShopping],
    ["Football", checkFootball],
    ["Presence / Termux", checkPresence],
    ["Spotify / Android", checkSpotify]
  ];

  /*
    Android-only Spotify is not treated as a fatal browser
    preview failure. This lets the complete UI open in SPCK
    while still refusing to fake the Spotify state.
  */

  let requiredFailed = [];

  for (const [name, checker] of services) {

    renderBootCheck(
      name,
      "checking",
      "Checking…"
    );

    const ok = await checker();

    state.services[name] = ok;

    const optionalNative =
      name === "Spotify / Android" &&
      !isAndroidBridgeAvailable();

    if (ok) {

      renderBootCheck(
        name,
        "ok",
        "Online"
      );

    } else if (optionalNative) {

      renderBootCheck(
        name,
        "fail",
        "Native feature — preview"
      );

    } else {

      renderBootCheck(
        name,
        "fail",
        "Unavailable"
      );

      requiredFailed.push(name);
    }
  }

  /*
    The dashboard itself is allowed to open if a live network
    service is temporarily unavailable. We don't lock the user
    out of their dashboard because of a temporary API failure.
  */

  if (requiredFailed.length > 0) {

    if (bootError) {

      bootError.classList.remove("hidden");

      bootError.textContent =
        `Some live services are unavailable: ${
          requiredFailed.join(", ")
        }. The dashboard will still open, but those features will report their real unavailable state.`;
    }
  }

  finishBoot();
}

function finishBoot() {

  state.bootComplete = true;

  const boot =
    $("bootScreen");

  const app =
    $("app");

  if (boot) {
    boot.classList.add("hidden");
  }

  if (app) {
    app.classList.remove("hidden");
  }

  refreshPresence();
  refreshWeather();
}

/* =========================================================
   REFRESH EVERYTHING
========================================================= */

async function refreshAll() {

  showToast("Refreshing dashboard…");

  await Promise.allSettled([
    refreshPresence(),
    refreshWeather(),
    runServiceChecks()
  ]);

  showToast("Dashboard refreshed.");
}

/* =========================================================
   NATIVE ANDROID CALLBACKS
========================================================= */

/*
  The Android V4 app can call these functions from its WebView.

  Example:
  window.updateMediaInfo({
    title: "Song",
    artist: "Artist",
    artwork: "https://..."
  });
*/

window.updateMediaInfo = updateMediaInfo;

window.setPresenceFromAndroid = function (
  name,
  status,
  lastUpdate
) {

  state.presence[name] = {
    status,
    last_update: lastUpdate
  };

  setPresenceUI(
    name,
    status,
    status === "home"
      ? "Home"
      : status === "away"
        ? "Away"
        : "Unknown"
  );
};

window.welcomeHome = function(name) {

  const message =
    `Welcome home ${name}`;

  showToast(message);

  if (
    isAndroidBridgeAvailable() &&
    typeof window.Android.speak === "function"
  ) {

    try {
      window.Android.speak(message);
      return;
    } catch {
      // Native TTS failed; the visible message remains.
    }
  }

  /*
    We do not use browser speech synthesis here because the
    Android build is intended to provide real native TTS.
  */
};

/* =========================================================
   AUTOMATIC REFRESH
========================================================= */

setInterval(
  updateClock,
  1000
);

setInterval(
  refreshPresence,
  10000
);

setInterval(
  refreshWeather,
  15 * 60 * 1000
);

/* =========================================================
   STARTUP
========================================================= */

document.addEventListener(
  "DOMContentLoaded",
  () => {

    updateClock();

    runBootChecks();
  }
);