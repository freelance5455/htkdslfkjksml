# CPLS V2 — Stage 1124

## Futures chart interaction and stability
- Continued from Stage 1123.
- Added candle selection on tap/click with OHLC + timestamp tooltip.
- Added a missing `fLoadChart()` handler so timeframe buttons rebuild the local candle set instead of calling an undefined function.
- Removed a duplicate native `startFuturesFeed()` call during page boot.
- Kept Futures REST/native feed as the data source; no undocumented WebSocket subscription message was invented.
- This stage is source-only and was not live-tested against LBank from this build environment.
