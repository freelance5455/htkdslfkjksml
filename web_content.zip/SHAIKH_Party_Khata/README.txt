SHAIKH PARTY KHATA — Android Web App Package
Version: 2.0

Version 2 adds local 4-digit PIN lock, edit/delete party and cash entries, WhatsApp/share party ledger, prefilled payment reminders, monthly debit/credit/cash summaries, and a configurable cloud backup connector for your own HTTPS API.

Test by opening index.html in Chrome, creating parties and transactions, then testing PIN, edit/delete, sharing and monthly reports.

Android APK: Use your HTML-to-APK converter. App name: SHAIKH Party Khata. Start page: index.html. Enable JavaScript, DOM storage/local storage, downloads, file chooser and external links.

Accounting: Debit increases amount receivable. Credit reduces receivable / increases payable. Opening balance can be Debit or Credit. Cash IN/OUT is separate and does not automatically post to party ledger.

Limitations: Local records are stored in WebView/browser storage; export JSON backups regularly. PIN is a basic local app lock, not encrypted storage. Fingerprint integration requires native Android bridge support from the converter and is not included. Cloud backup is not pre-connected: configure an HTTPS server endpoint and bearer token; API must accept PUT JSON and return JSON on GET. No cloud server/account is supplied. WhatsApp reminders are prefilled for user review; not sent automatically. Test APK and backup/restore before live business use.
