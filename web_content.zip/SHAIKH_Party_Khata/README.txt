SHAIKH PARTY KHATA — Android Web App Package
Version: 1.0

CONTENTS
- index.html: complete responsive offline-first app.

HOW TO TEST
1. Extract the ZIP.
2. Open index.html in Chrome on Android or a desktop browser.
3. Add a party, record debit/credit entries, and add cash-in/cash-out entries.
4. Data is saved in this browser/app's local storage.

ANDROID APK
Use your HTML-to-APK converter:
- Select index.html as the start page (or select the extracted project folder/ZIP if supported).
- Set app name: SHAIKH Party Khata
- Set start URL/page: index.html
- Enable JavaScript and DOM storage/local storage.
- Enable file chooser/download support if your converter offers these options.
- Build and install the APK, then test data persistence.

IMPORTANT DATA / BACKUP NOTES
- This first build stores data locally on the device/browser profile.
- Use Backup & Settings > Download Full Backup regularly.
- Restore uses a previously exported JSON backup.
- Online/cloud backup is not active yet. It requires a configured cloud backend and credentials; this package does not pretend to upload data.
- Clearing app storage, uninstalling the APK, or using a different WebView profile may remove local data. Export a backup before reinstalling or clearing storage.

ACCOUNTING LOGIC
- Debit increases the amount receivable from a party.
- Credit decreases receivable / increases payable.
- Opening balance can be Debit (to receive) or Credit (to pay).
- Cash Book IN and OUT are independent cash movements; they do not automatically post to a party ledger.
