# 📱 TUS 50 Elite Tracker - Android APK Dönüştürme ve Kurulum Rehberi

Bu paket, **Dr. Ali Ege** için geliştirilen **TUS 50 Elite Tracker** (Göz Doktorluğu & Plastik Cerrahi Arayüzleri) uygulamasını Android cihazlarda tam ekran, çevrimdışı (offline) ve yerel bir APK uygulaması olarak çalıştırmak için optimize edilmiştir.

---

## 📦 Paket İçeriği
* `index.html` — Mobil uyumlu (viewport-fit=cover, notch ve status bar uyumlu) ana sayfa.
* `styles.css` — Android dokunmatik optimizasyonlu (-webkit-tap-highlight-color kaldırılmış) tasarım.
* `app.js` — Offline Canvas Chart fallback ve yerel veri saklama motoru.
* `manifest.json` — Android Web App Manifesti (ikona, standalone görünüm, tema rengi).
* `config.xml` — Cordova, Capacitor ve Website 2 APK Builder uyumlu yapılandırma dosyası.
* `sw.js` — Çevrimdışı (uçak modunda bile) çalışmayı sağlayan Service Worker.
* `icon-192.png` & `icon-512.png` — Android uygulama başlatıcı ikonları.
* `TUS50_Android_APK_Package.zip` — Doğrudan APK dönüştürücülere yüklenebilecek hazır arşiv.

---

## 🚀 APK'ya Dönüştürme Yöntemleri (En Kolaydan İleriye)

### YÖNTEM 1: Ücretsiz Online Dönüştürücü (1 Dakika, Program Gerektirmez)
1. **[AppsGeyser](https://www.appsgeyser.com/)** veya **[Web2Apk](https://www.web2apk.com/)** sitesine gidin.
2. **"Create App"** -> **"HTML5 / ZIP Archive"** seçeneğini seçin.
3. Klasörde sizin için hazırlanan **`TUS50_Android_APK_Package.zip`** dosyasını yükleyin.
4. Uygulama Adı: `TUS 50 Elite`
5. İkon olarak paketteki `icon-512.png` dosyasını seçin.
6. **"Build / Download APK"** butonuna basarak doğrudan Android telefonunuza `.apk` dosyasını indirin ve kurun!

---

### YÖNTEM 2: Website 2 APK Builder (Windows İçin En Popüler Araç)
Eğer bilgisayarınızda **Website 2 APK Builder** kuruluysa:
1. Programı açın.
2. Mode kısmından **"Local HTML Website"** seçeneğini işaretleyin.
3. **Directory** olarak bu klasörü (`YENİ ACİL`) seçin.
4. App Title: `TUS 50 Elite Tracker`
5. Package Name: `com.aliege.tus50elitetracker`
6. App Icon kısmına `icon-512.png` dosyasını yükleyin.
7. **"Generate APK"** butonuna tıklayın. Birkaç saniye içinde masaüstünüze hazır `.apk` dosyası çıkacaktır.

---

### YÖNTEM 3: Doğrudan Android'e Yükleme (APK'sız 5 Saniye - PWA Metodu)
APK derlemekle vakit kaybetmek istemiyorsanız en temiz ve hızlı yöntem:
1. Bu klasörü telefonunuza atın veya yerel ağınızda/Google Drive'ınızda açın.
2. Android telefonunuzdaki **Google Chrome** tarayıcısında `index.html` dosyasını açın.
3. Sağ üstteki üç noktaya (⋮) tıklayın.
4. **"Ana Ekrana Ekle"** veya **"Uygulamayı Yükle"** (Install App) seçeneğine basın.
5. Uygulama tıpkı bir APK gibi ana ekranınıza logosuyla gelir, tıkladığınızda tarayıcı çubukları olmadan **tam ekran native uygulama** gibi çalışır!

---

### YÖNTEM 4: Capacitor / Cordova CLI (Geliştiriciler İçin)
Terminalden derlemek isterseniz:
```bash
npm install -g @capacitor/cli @capacitor/core
npx cap init "TUS 50 Elite" "com.aliege.tus50elitetracker" --web-dir "."
npx cap add android
npx cap open android
```
Android Studio açılarak doğrudan Release APK veya AAB çıktısı alabilirsiniz.

---

## ⚡ Notlar & İpuçları
* **Çevrimdışı Çalışma:** Tüm veriler telefonunuzun dahili hafızasında (`localStorage`) saklanır. İnternetiniz kapalıyken bile deneme netlerinizi girebilir, çalışma sayacını çalıştırabilirsiniz.
* **Yedek Alma:** Düzenli aralıklarla uygulamanın sağ üstündeki **İndir (Export)** butonuna basarak JSON yedeğinizi telefonunuza indirebilirsiniz.
