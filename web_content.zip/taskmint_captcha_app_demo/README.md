# TaskMint — CAPTCHA/Earnings App UI Prototype

## Included
- `index.html`: responsive single-file prototype with demo sign-in/register, sample CAPTCHA task, simulated interstitial, demo balance/history, withdrawal request UI, admin dashboard, and ad integration settings.
- Admin email configured in the UI: `shloknishad222@gmail.com`.

## Run
1. Extract the ZIP.
2. Open `index.html` in a modern browser on Android or desktop.
3. Use a demo email to test the user flow. To test the admin view, use `shloknishad222@gmail.com`.

## Important limitations
This is a front-end prototype only. It does not implement secure authentication, Google OAuth, a server/database, real ad serving, real ad revenue measurement, or real payments. All data is local to the browser and can be changed by the user. The admin email check is not a security boundary.

For production:
- Implement authentication with a trusted identity provider and validate sessions server-side.
- Enforce admin roles and all balance/withdrawal operations on a backend; never trust client-side balances.
- Integrate AppLovin MAX using its official Android SDK and configured ad units. An ad link alone cannot serve an ad.
- Use test ads during development and review current AppLovin policies before combining ads with rewards, CAPTCHA work, or cash payouts.
- Add fraud prevention, consent/privacy handling, audit logs, and a secure payment provider only after compliance review.
