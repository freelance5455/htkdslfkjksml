NewChat — deploy

Upload the contents of this folder to the same Netlify site that currently hosts NewChat. Keep index.html, manifest.webmanifest, sw.js, and the icons folder together at the site root. Do not change the Supabase URL or publishable key in index.html.

Install on Android:
1. Open the deployed HTTPS website in Chrome.
2. Sign in, then use Chrome's menu > Install app (or Add to Home screen).
3. Open the installed NewChat app.

Notifications:
1. In NewChat open Settings > Notifications.
2. Turn on Push-style notifications and allow the Android/Chrome permission prompt.
3. Use Send test notification to verify permission.

Important notification limitation:
This update uses the existing Supabase Realtime message stream and the service worker to show notifications while NewChat/the browser is running in the background. Notifications after the app/browser has been fully closed are not enabled by this static-site update alone. That requires a Web Push server (VAPID keys), saving each device's push subscription in Supabase, and a trusted server/Edge Function to send pushes when messages arrive. Do not put a VAPID private key or service-role key in index.html.

The existing Supabase project, accounts, database tables, and chat data are unchanged.
