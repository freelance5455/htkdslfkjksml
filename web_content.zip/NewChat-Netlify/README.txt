NewChat private-server update for Netlify

1. Upload this ZIP to https://app.netlify.com/drop
2. The homepage is index.html.
3. Existing Supabase project URL and publishable key are retained.
4. This frontend still requires the matching NewChat Supabase schema, RPC functions, RLS policies and Realtime configuration.
5. Keep RLS enabled. Never place a service_role or secret key in frontend code.
6. New servers are created as private/invite-only. Use Server menu > Invite people to create invite links or invite friends.
