# KamarCast 0.3.0 – Build

## Android Studio
1. Open this folder as a Gradle project.
2. Install Android SDK 36, NDK 28.2.13676358 and CMake 3.22.1.
3. Sync Gradle.
4. Build > Build APK(s).

## CI
The GitHub Actions workflow installs the same SDK/NDK/CMake versions and runs `gradle assembleDebug`.

## What the native transport actually does
- Uses an existing `awdl0` interface when the OS exposes one and opens an IPv6/mDNS/TCP path on it.
- On rooted research devices, opens an `AF_PACKET` raw socket if the Wi-Fi driver allows it.
- The raw socket alone is not an AWDL implementation: the device must already support the required monitor/frame-injection operations.

The project deliberately does not claim stock-Android AWDL support when the kernel/firmware does not expose it.
