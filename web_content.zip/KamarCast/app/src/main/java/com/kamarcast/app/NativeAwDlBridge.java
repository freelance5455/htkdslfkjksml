package com.kamarcast.app;

/** JNI boundary for the root-only raw 802.11 experiment. */
public final class NativeAwDlBridge {
    private static volatile boolean loaded;

    static {
        try {
            System.loadLibrary("kamarcast_awdl");
            loaded = true;
        } catch (UnsatisfiedLinkError ignored) {
            loaded = false;
        }
    }

    private NativeAwDlBridge() { }

    public static boolean isLoaded() { return loaded; }

    public static native int nativeOpenRaw80211(String iface);
    public static native int nativeSendRaw(int handle, byte[] frame);
    public static native void nativeCloseRaw(int handle);
}
