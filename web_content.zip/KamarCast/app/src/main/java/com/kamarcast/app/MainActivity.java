package com.kamarcast.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private static final int REQUEST_PERMISSIONS = 100;
    private static final int REQUEST_MEDIA_PROJECTION = 101;

    private TextView status;
    private AppleTvScanner scanner;
    private Button scanButton;
    private final List<AppleTvScanner.Device> devices = new ArrayList<>();
    private AppleTvScanner.Device selectedDevice;
    private AirPlayConnectionManager connectionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        connectionManager = new AirPlayConnectionManager(this);
        buildUi();
        requestNeededPermissions();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(40, 56, 40, 36);

        TextView title = new TextView(this);
        title.setText("KamarCast");
        title.setTextSize(32);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER_HORIZONTAL);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView subtitle = new TextView(this);
        subtitle.setText("Android → Apple TV Bildschirmspiegelung");
        subtitle.setTextSize(16);
        subtitle.setGravity(Gravity.CENTER_HORIZONTAL);
        root.addView(subtitle, new LinearLayout.LayoutParams(-1, -2));

        status = new TextView(this);
        status.setTextSize(15);
        status.setPadding(0, 30, 0, 30);
        status.setText("Status: bereit");
        root.addView(status, new LinearLayout.LayoutParams(-1, -2));

        scanButton = new Button(this);
        scanButton.setText("Apple TVs suchen");
        scanButton.setOnClickListener(v -> scan());
        root.addView(scanButton, new LinearLayout.LayoutParams(-1, -2));

        Button connect = new Button(this);
        connect.setText("Ausgewähltes Apple TV verbinden");
        connect.setOnClickListener(v -> connectSelected());
        root.addView(connect, new LinearLayout.LayoutParams(-1, -2));

        Button capture = new Button(this);
        capture.setText("Bildschirmfreigabe starten");
        capture.setOnClickListener(v -> requestMediaProjection());
        root.addView(capture, new LinearLayout.LayoutParams(-1, -2));

        TextView info = new TextView(this);
        info.setText("\nTransportstatus:\n" + connectionManager.transportDiagnostics()
                + "\n\nApple TV Auswahl:\nNoch kein Gerät gewählt."
                + "\n\nCode:\nWenn das Apple TV einen AirPlay-Code verlangt, fragt KamarCast ihn vor dem Verbindungsaufbau ab."
                + "\n\nDirektmodus:\nKamarCast versucht zuerst ein vorhandenes awdl0-Interface. Auf gerooteten Forschungsgeräten kann zusätzlich ein Raw-802.11-Pfad geöffnet werden. Stock-Android blockiert Apples AWDL nicht per App, deshalb wird kein normaler WLAN-Pfad als Direktverbindung ausgegeben.");
        info.setTextSize(14);
        root.addView(info, new LinearLayout.LayoutParams(-1, -2));

        ScrollView scroll = new ScrollView(this);
        scroll.addView(root);
        setContentView(scroll);
    }

    private void requestNeededPermissions() {
        ArrayList<String> permissions = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= 31) {
            permissions.add(Manifest.permission.BLUETOOTH_SCAN);
            permissions.add(Manifest.permission.BLUETOOTH_CONNECT);
        } else if (Build.VERSION.SDK_INT >= 23) {
            permissions.add(Manifest.permission.ACCESS_FINE_LOCATION);
        }
        if (Build.VERSION.SDK_INT >= 33) {
            permissions.add(Manifest.permission.POST_NOTIFICATIONS);
        }
        if (!permissions.isEmpty()) {
            requestPermissions(permissions.toArray(new String[0]), REQUEST_PERMISSIONS);
        }
    }

    private boolean bluetoothPermissionsGranted() {
        if (Build.VERSION.SDK_INT >= 31) {
            return checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)
                    == PackageManager.PERMISSION_GRANTED
                    && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)
                    == PackageManager.PERMISSION_GRANTED;
        }
        return Build.VERSION.SDK_INT < 23
                || checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED;
    }

    private void scan() {
        if (!bluetoothPermissionsGranted()) {
            status.setText("Bitte die Bluetooth-Berechtigung erlauben und erneut suchen.");
            requestNeededPermissions();
            return;
        }

        devices.clear();
        selectedDevice = null;
        scanner = new AppleTvScanner(this, new AppleTvScanner.Listener() {
            @Override
            public void onAppleTvFound(AppleTvScanner.Device device) {
                runOnUiThread(() -> {
                    devices.add(device);
                    selectedDevice = device;
                    status.setText("Apple TV gefunden: " + device.name
                            + "\nP2P/AWDL beworben: " + (device.awdl ? "JA" : "NEIN")
                            + "\nIPv4: " + (device.ipv4 == null ? "nicht angegeben" : device.ipv4)
                            + "\nAirPlay-Port: " + device.port
                            + "\n\nDieses Gerät ist aktuell ausgewählt.");
                });
            }

            @Override
            public void onFinished() {
                runOnUiThread(() -> scanButton.setEnabled(true));
            }

            @Override
            public void onError(String message) {
                runOnUiThread(() -> {
                    scanButton.setEnabled(true);
                    status.setText("Fehler: " + message);
                });
            }
        });
        scanButton.setEnabled(false);
        status.setText("Suche nach Apple-TV-AirPlay-Anzeigen …");
        scanner.start();
        status.postDelayed(() -> {
            if (scanner != null) scanner.stop();
        }, 12000);
    }

    private void connectSelected() {
        if (selectedDevice == null) {
            status.setText("Bitte zuerst ein Apple TV suchen und auswählen.");
            return;
        }
        showPairingCodeDialog();
    }

    private void showPairingCodeDialog() {
        EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_NUMBER);
        input.setHint("4-stelliger Code");

        LinearLayout box = new LinearLayout(this);
        box.setPadding(50, 10, 50, 0);
        box.addView(input, new LinearLayout.LayoutParams(-1, -2));

        new android.app.AlertDialog.Builder(this)
                .setTitle("AirPlay-Code")
                .setMessage("Gib den Code ein, der auf dem Apple TV angezeigt wird.")
                .setView(box)
                .setNegativeButton("Abbrechen", null)
                .setPositiveButton("Verbinden", (dialog, which) -> {
                    String code = input.getText().toString().trim();
                    if (code.length() != 4) {
                        status.setText("Ungültiger Code. Erwartet werden 4 Ziffern.");
                        return;
                    }
                    startConnection(code);
                })
                .show();
    }

    private void startConnection(String code) {
        status.setText("Verbindung mit " + selectedDevice.name + " wird aufgebaut …");
        connectionManager.connect(selectedDevice, code, new AirPlayConnectionManager.Listener() {
            @Override
            public void onState(String text) {
                runOnUiThread(() -> status.setText(text));
            }

            @Override
            public void onPairingRequired() {
                runOnUiThread(MainActivity.this::showPairingCodeDialog);
            }

            @Override
            public void onConnected() {
                runOnUiThread(() -> status.setText("AirPlay-Endpunkt erreichbar. Für eine echte Bildschirmübertragung muss anschließend der native AirPlay-Video-Transport gestartet werden."));
            }

            @Override
            public void onFailed(String reason) {
                runOnUiThread(() -> status.setText("Verbindung nicht möglich: " + reason));
            }
        });
    }

    private void requestMediaProjection() {
        MediaProjectionManager manager =
                (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        if (manager == null) {
            status.setText("MediaProjection ist auf diesem Gerät nicht verfügbar.");
            return;
        }
        startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_MEDIA_PROJECTION);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_MEDIA_PROJECTION) return;
        if (resultCode != RESULT_OK || data == null) {
            status.setText("Bildschirmfreigabe abgebrochen.");
            return;
        }

        Intent intent = new Intent(this, ScreenCaptureService.class);
        intent.putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, resultCode);
        intent.putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, data);
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                startForegroundService(intent);
            } else {
                startService(intent);
            }
            status.setText("Bildschirmfreigabe läuft im Hintergrund. Die permanente KamarCast-Benachrichtigung bleibt zum Stoppen sichtbar.");
        } catch (Exception e) {
            status.setText("Start der Bildschirmaufnahme fehlgeschlagen: " + e.getMessage());
        }
    }

    @Override
    protected void onDestroy() {
        if (connectionManager != null) connectionManager.stop();
        super.onDestroy();
    }
}
