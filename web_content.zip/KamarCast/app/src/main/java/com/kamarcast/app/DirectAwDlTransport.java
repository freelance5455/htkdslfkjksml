package com.kamarcast.app;

import android.os.Build;

import java.io.Closeable;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.Inet6Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.MulticastSocket;
import java.net.NetworkInterface;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

/**
 * Experimental direct Apple-Wireless-Direct-Link transport layer.
 *
 * There are two distinct layers here:
 *  1) If an Android vendor/rooted environment already exposes awdl0, use its
 *     link-local IPv6 interface like a normal IP network interface.
 *  2) Otherwise expose a raw 802.11 socket through JNI. That path needs a
 *     monitor/injection-capable driver and root; it does NOT magically create
 *     AWDL on stock Android.
 *
 * AirPlay session/authentication sits above this class.
 */
public final class DirectAwDlTransport implements Closeable {
    public enum Mode { NONE, AWDL_IPV6, RAW_80211 }

    public static final int AIRPLAY_PORT = 7000;
    public static final int MDNS_PORT = 5353;
    private static final String AWDL_IFACE = "awdl0";
    private static final String MDNS_V6 = "ff02::fb";

    private Mode mode = Mode.NONE;
    private NetworkInterface awdlInterface;
    private Socket controlSocket;
    private MulticastSocket mdnsSocket;
    private int rawHandle = -1;

    public Mode getMode() { return mode; }

    /**
     * Finds a real awdl0 interface already provided by the operating system.
     */
    public boolean attachExistingAwdl() {
        try {
            awdlInterface = NetworkInterface.getByName(AWDL_IFACE);
            if (awdlInterface == null || !awdlInterface.isUp()) return false;
            mode = Mode.AWDL_IPV6;
            return true;
        } catch (Exception ignored) {
            return false;
        }
    }

    /**
     * Opens the lowest-level 802.11 path. This is only available when the
     * device/kernel permits raw frame sockets. No frames are injected by this
     * method until the caller supplies protocol frames.
     */
    public boolean attachRaw80211(String iface) {
        if (Build.VERSION.SDK_INT < 26) return false;
        int handle = NativeAwDlBridge.nativeOpenRaw80211(iface);
        if (handle < 0) return false;
        rawHandle = handle;
        mode = Mode.RAW_80211;
        return true;
    }

    /**
     * Direct IPv6 AirPlay endpoint test through awdl0. IPv4 is intentionally
     * not used here because the requested path is off-network/P2P.
     */
    public Socket connectIpv6(Inet6Address address, int port) throws IOException {
        if (mode != Mode.AWDL_IPV6 || awdlInterface == null) {
            throw new IOException("Kein awdl0-Datenpfad aktiv.");
        }
        Socket socket = new Socket();
        socket.setTcpNoDelay(true);
        socket.setKeepAlive(true);
        socket.setSoTimeout(3500);
        socket.bind(new InetSocketAddress(findLinkLocal(awdlInterface), 0));
        socket.connect(new InetSocketAddress(address, port), 2500);
        controlSocket = socket;
        return socket;
    }

    private static Inet6Address findLinkLocal(NetworkInterface iface) {
        try {
            Enumeration<InetAddress> addresses = iface.getInetAddresses();
            while (addresses.hasMoreElements()) {
                InetAddress address = addresses.nextElement();
                if (address instanceof Inet6Address && address.isLinkLocalAddress()) {
                    Inet6Address a = (Inet6Address) address;
                    // The scope is required for link-local Java sockets.
                    a = (Inet6Address) Inet6Address.getByAddress(
                            a.getHostName(), a.getAddress(), iface);
                    return a;
                }
            }
        } catch (Exception ignored) { }
        return null;
    }

    /**
     * Sends one mDNS query on awdl0. Useful for discovering the AirPlay SRV/TXT
     * endpoint without relying on a normal LAN interface.
     */
    public List<byte[]> queryAirPlayMdns(int timeoutMs) throws IOException {
        if (mode != Mode.AWDL_IPV6 || awdlInterface == null) {
            throw new IOException("mDNS benötigt awdl0.");
        }
        if (!awdlInterface.isUp()) throw new IOException("awdl0 ist nicht aktiv.");

        byte[] query = DnsWire.buildPtrQuery("_airplay._tcp.local");
        Inet6Address group = (Inet6Address) InetAddress.getByName(MDNS_V6);
        group = (Inet6Address) Inet6Address.getByAddress(group.getHostName(), group.getAddress(), awdlInterface);

        ArrayList<byte[]> packets = new ArrayList<>();
        try (MulticastSocket socket = new MulticastSocket()) {
            socket.setNetworkInterface(awdlInterface);
            socket.setSoTimeout(timeoutMs);
            socket.joinGroup(new InetSocketAddress(group, MDNS_PORT), awdlInterface);
            DatagramPacket packet = new DatagramPacket(query, query.length, group, MDNS_PORT);
            socket.send(packet);
            byte[] buffer = new byte[9000];
            long end = System.currentTimeMillis() + timeoutMs;
            while (System.currentTimeMillis() < end) {
                try {
                    DatagramPacket response = new DatagramPacket(buffer, buffer.length);
                    socket.receive(response);
                    byte[] copy = new byte[response.getLength()];
                    System.arraycopy(response.getData(), response.getOffset(), copy, 0, copy.length);
                    packets.add(copy);
                } catch (SocketTimeoutException e) {
                    break;
                }
            }
            try { socket.leaveGroup(new InetSocketAddress(group, MDNS_PORT), awdlInterface); } catch (Exception ignored) { }
        }
        return packets;
    }

    public boolean sendRaw(byte[] frame) {
        if (rawHandle < 0 || frame == null || frame.length == 0) return false;
        return NativeAwDlBridge.nativeSendRaw(rawHandle, frame) == frame.length;
    }

    @Override
    public void close() {
        if (mdnsSocket != null) {
            try { mdnsSocket.close(); } catch (Exception ignored) { }
        }
        if (controlSocket != null) {
            try { controlSocket.close(); } catch (Exception ignored) { }
        }
        if (rawHandle >= 0) {
            NativeAwDlBridge.nativeCloseRaw(rawHandle);
            rawHandle = -1;
        }
        mode = Mode.NONE;
    }

    public static String describeInterface(NetworkInterface iface) {
        if (iface == null) return "nicht vorhanden";
        StringBuilder b = new StringBuilder(iface.getName());
        b.append(" up=").append(safeUp(iface));
        Enumeration<InetAddress> addresses = iface.getInetAddresses();
        while (addresses.hasMoreElements()) {
            b.append(' ').append(addresses.nextElement().getHostAddress());
        }
        return b.toString();
    }

    private static boolean safeUp(NetworkInterface i) {
        try { return i.isUp(); } catch (Exception e) { return false; }
    }

    static final class DnsWire {
        private DnsWire() { }
        static byte[] buildPtrQuery(String name) {
            ByteBuffer b = ByteBuffer.allocate(512);
            b.putShort((short) 0x4b43); // KC
            b.putShort((short) 0x0000);
            b.putShort((short) 0x0001);
            b.putShort((short) 0x0000);
            b.putShort((short) 0x0000);
            b.putShort((short) 0x0000);
            putName(b, name);
            b.putShort((short) 12); // PTR
            b.putShort((short) 1);  // IN
            byte[] out = new byte[b.position()];
            b.flip(); b.get(out);
            return out;
        }
        private static void putName(ByteBuffer b, String name) {
            for (String label : name.split("\\.")) {
                byte[] bytes = label.getBytes(java.nio.charset.StandardCharsets.US_ASCII);
                b.put((byte) bytes.length);
                b.put(bytes);
            }
            b.put((byte) 0);
        }
    }
}
