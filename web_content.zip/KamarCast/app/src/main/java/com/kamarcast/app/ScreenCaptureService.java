package com.kamarcast.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.MediaCodec;
import android.media.MediaFormat;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.IBinder;
import android.util.DisplayMetrics;
import android.view.Surface;

/** Efficient background H.264 screen capture. Transport attaches above the encoder output. */
public class ScreenCaptureService extends Service {
    public static final String EXTRA_RESULT_CODE = "resultCode";
    public static final String EXTRA_RESULT_DATA = "resultData";
    private static final String ACTION_STOP = "com.kamarcast.app.STOP_CAPTURE";
    private static final int NOTIFICATION_ID = 7;
    private static final int MAX_WIDTH = 1280;
    private static final int MAX_HEIGHT = 720;

    private MediaProjection projection;
    private VirtualDisplay virtualDisplay;
    private MediaCodec encoder;
    private Surface inputSurface;
    private Thread drainThread;
    private volatile boolean running;

    private final MediaProjection.Callback projectionCallback = new MediaProjection.Callback() {
        @Override public void onStop() { stopSelf(); }
    };

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (running) return START_NOT_STICKY;

        createChannel();
        startForegroundCompat(buildNotification());
        if (intent == null) { stopSelf(); return START_NOT_STICKY; }

        int resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0);
        Intent data = Build.VERSION.SDK_INT >= 33
                ? intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent.class)
                : intent.getParcelableExtra(EXTRA_RESULT_DATA);
        MediaProjectionManager manager = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        if (manager == null || data == null) { stopSelf(); return START_NOT_STICKY; }
        try {
            projection = manager.getMediaProjection(resultCode, data);
            if (projection == null) { stopSelf(); return START_NOT_STICKY; }
            projection.registerCallback(projectionCallback, null);
            startEncoder();
        } catch (SecurityException | IllegalStateException e) {
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    private void startForegroundCompat(Notification notification) {
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
    }

    private Notification buildNotification() {
        PendingIntent stop = PendingIntent.getService(
                this, 100,
                new Intent(this, ScreenCaptureService.class).setAction(ACTION_STOP),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, "kamarcast_capture")
                : new Notification.Builder(this);
        return b.setContentTitle("KamarCast")
                .setContentText("Bildschirmspiegelung aktiv")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setOngoing(true)
                .addAction(new Notification.Action.Builder(null, "Spiegelung stoppen", stop).build())
                .build();
    }

    private void startEncoder() {
        DisplayMetrics m = getResources().getDisplayMetrics();
        int srcW = Math.max(2, m.widthPixels);
        int srcH = Math.max(2, m.heightPixels);
        float scale = Math.min(1f, Math.min(MAX_WIDTH / (float) srcW, MAX_HEIGHT / (float) srcH));
        int width = even(Math.max(2, Math.round(srcW * scale)));
        int height = even(Math.max(2, Math.round(srcH * scale)));
        int pixels = width * height;
        int bitrate = Math.max(2_500_000, Math.min(6_000_000, pixels * 4));

        try {
            MediaFormat f = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height);
            f.setInteger(MediaFormat.KEY_COLOR_FORMAT, 0x7F000789);
            f.setInteger(MediaFormat.KEY_BIT_RATE, bitrate);
            f.setInteger(MediaFormat.KEY_FRAME_RATE, 30);
            f.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2);
            if (Build.VERSION.SDK_INT >= 21) f.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 0);
            if (Build.VERSION.SDK_INT >= 29) f.setInteger(MediaFormat.KEY_PRIORITY, 0);

            encoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC);
            encoder.configure(f, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
            inputSurface = encoder.createInputSurface();
            encoder.start();
            virtualDisplay = projection.createVirtualDisplay(
                    "KamarCast", width, height, m.densityDpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    inputSurface, null, null);

            running = true;
            drainThread = new Thread(this::drainEncoder, "KamarCast-H264");
            drainThread.start();
        } catch (Exception e) {
            stopSelf();
        }
    }

    private static int even(int v) { return (v & 1) == 0 ? v : v - 1; }

    private void drainEncoder() {
        if (encoder == null) return;
        MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
        while (running && !Thread.currentThread().isInterrupted()) {
            try {
                int idx = encoder.dequeueOutputBuffer(info, 500);
                if (idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    // Format is now available to the AirPlay sender above this layer.
                    continue;
                }
                if (idx < 0) continue;
                // The transport integration point is deliberately zero-copy friendly:
                // obtain the encoded buffer, advance exactly over offset/size, and release.
                java.nio.ByteBuffer out = encoder.getOutputBuffer(idx);
                if (out != null && info.size > 0) {
                    out.position(info.offset);
                    out.limit(info.offset + info.size);
                    // TODO: pass this read-only window to the encrypted AirPlay sender.
                }
                encoder.releaseOutputBuffer(idx, false);
            } catch (IllegalStateException e) {
                break;
            }
        }
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(
                    "kamarcast_capture", "KamarCast Bildschirm", NotificationManager.IMPORTANCE_LOW);
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    @Override public void onDestroy() {
        running = false;
        if (drainThread != null) drainThread.interrupt();
        if (virtualDisplay != null) virtualDisplay.release();
        if (projection != null) {
            try { projection.unregisterCallback(projectionCallback); } catch (Exception ignored) { }
            try { projection.stop(); } catch (Exception ignored) { }
        }
        if (encoder != null) {
            try { encoder.stop(); } catch (Exception ignored) { }
            try { encoder.release(); } catch (Exception ignored) { }
        }
        if (inputSurface != null) inputSurface.release();
        stopForeground(true);
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
