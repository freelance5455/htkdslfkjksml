package com.kamarcast.app;

import java.net.Inet6Address;
import java.net.InetAddress;
import java.net.Socket;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Coordinates the direct transport and reports exactly which layer is ready. */
public final class AirPlayConnectionManager {
    public interface Listener {
        void onState(String text);
        void onPairingRequired();
        void onConnected();
        void onFailed(String reason);
    }

    private final ExecutorService executor = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "KamarCast-AirPlay");
        t.setDaemon(true);
        return t;
    });
    private final DirectAwDlTransport directTransport = new DirectAwDlTransport();
    private volatile boolean closed;

    public void connect(AppleTvScanner.Device device, String pairingCode, Listener listener) {
        closed = false;
        if (device == null) {
            listener.onFailed("Kein Apple TV ausgewählt.");
            return;
        }
        if (pairingCode == null || !pairingCode.matches("\\d{4}")) {
            listener.onPairingRequired();
            return;
        }

        executor.execute(() -> {
            try {
                listener.onState("Direkten Apple-P2P-Pfad wird geprüft …");
                if (!directTransport.attachExistingAwdl()) {
                    DirectAwDlProbe.Result probe = DirectAwDlProbe.inspect();
                    if (probe.rootAvailable && NativeAwDlBridge.isLoaded()) {
                        listener.onState("Kein awdl0 gefunden. Raw-802.11-Fähigkeit wird geprüft …");
                        String iface = DirectAwDlProbe.findLikelyWifiInterface();
                        if (iface != null && directTransport.attachRaw80211(iface)) {
                            listener.onFailed("Raw-802.11-Transport ist geöffnet. Für die tatsächliche AWDL-Kanal-/Synchronisationsschicht fehlen auf diesem Gerät noch die passenden Treiber-Fähigkeiten; es wird deshalb keine falsche AirPlay-Verbindung gemeldet.");
                            return;
                        }
                    }
                    listener.onFailed("Kein direkt nutzbarer AWDL-Datenpfad auf diesem Android-Gerät. Stock-Android stellt Apples AWDL nicht als öffentliche API bereit.");
                    return;
                }

                listener.onState("awdl0 ist aktiv. Suche AirPlay-Dienst direkt über IPv6-mDNS …");
                List<byte[]> responses = directTransport.queryAirPlayMdns(1800);
                if (responses.isEmpty()) {
                    listener.onFailed("awdl0 ist vorhanden, aber kein AirPlay-mDNS-Dienst wurde gefunden.");
                    return;
                }

                Inet6Address endpoint = MdnsAirPlayFinder.findFirstIpv6(responses);
                if (endpoint == null) {
                    listener.onFailed("AirPlay-Dienst gefunden, aber keine IPv6-Adresse des Apple TV im mDNS-Antwortsatz.");
                    return;
                }

                listener.onState("Direkter AirPlay-Endpunkt gefunden. Pairing wird vorbereitet …");
                try (Socket ignored = directTransport.connectIpv6(endpoint, DirectAwDlTransport.AIRPLAY_PORT)) {
                    // This proves the direct link can carry an IP/TCP flow. Full AirPlay
                    // session/authentication is intentionally kept above this transport.
                    listener.onConnected();
                }
            } catch (Exception e) {
                listener.onFailed("Direkter P2P-Transport fehlgeschlagen: " + safeMessage(e));
            }
        });
    }

    private static String safeMessage(Exception e) {
        String m = e.getMessage();
        return m == null || m.trim().isEmpty() ? e.getClass().getSimpleName() : m;
    }

    public String transportDiagnostics() {
        return "awdl0=" + (directTransport.attachExistingAwdl() ? "aktiv" : "nicht vorhanden")
                + ", Raw-JNI=" + (NativeAwDlBridge.isLoaded() ? "verfügbar" : "nicht eingebaut")
                + ", Hinweis: Raw-802.11 benötigt Root + passenden Treiber.";
    }

    public void stop() {
        closed = true;
        directTransport.close();
        executor.shutdownNow();
    }
}
