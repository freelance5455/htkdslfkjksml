package com.kamarcast.app;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.util.concurrent.TimeUnit;

/** Root/driver capability probe for the experimental direct AWDL path. */
public final class DirectAwDlProbe {
    public static final class Result {
        public final boolean rootAvailable;
        public final String interfaces;
        public final String message;

        Result(boolean rootAvailable, String interfaces, String message) {
            this.rootAvailable = rootAvailable;
            this.interfaces = interfaces;
            this.message = message;
        }
    }

    private DirectAwDlProbe() { }

    public static Result inspect() {
        boolean root = commandSucceeds(new String[]{"su", "-c", "id"});
        if (!root) {
            return new Result(false, "", "Kein privilegierter WLAN-Zugriff.");
        }
        String interfaces = run(new String[]{"su", "-c", "ip -br link"});
        if (interfaces == null || interfaces.trim().isEmpty()) {
            return new Result(true, "", "Root-Shell vorhanden, aber keine Interfaces konnten abgefragt werden.");
        }
        return new Result(true, interfaces, "Privilegierter Netzwerkzugriff erkannt; AWDL bleibt treiberabhängig.");
    }

    /** Best-effort selection of a WLAN interface on rooted Android. */
    public static String findLikelyWifiInterface() {
        String output = run(new String[]{"su", "-c", "ip -br link"});
        if (output == null) return null;
        for (String line : output.split("\\R")) {
            String trimmed = line.trim();
            if (trimmed.isEmpty()) continue;
            String name = trimmed.split("\\s+")[0];
            if (name.equals("awdl0") || name.equals("lo")) continue;
            if (name.startsWith("wlan") || name.startsWith("wifi") || name.startsWith("wl")) {
                return name;
            }
        }
        return null;
    }

    private static boolean commandSucceeds(String[] command) {
        String result = run(command);
        return result != null && !result.trim().isEmpty();
    }

    private static String run(String[] command) {
        Process process = null;
        try {
            process = new ProcessBuilder(command).redirectErrorStream(true).start();
            if (!process.waitFor(1500, TimeUnit.MILLISECONDS)) {
                process.destroyForcibly();
                return null;
            }
            StringBuilder out = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
                String line;
                while ((line = reader.readLine()) != null) out.append(line).append('\\n');
            }
            return process.exitValue() == 0 ? out.toString() : null;
        } catch (Exception ignored) {
            if (process != null) process.destroyForcibly();
            return null;
        }
    }
}
