package com.kamarcast.app;

import java.net.Inet6Address;
import java.net.InetAddress;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Minimal safe mDNS parser sufficient to extract IPv6 answers from AirPlay discovery. */
public final class MdnsAirPlayFinder {
    private MdnsAirPlayFinder() { }

    public static Inet6Address findFirstIpv6(List<byte[]> packets) {
        for (byte[] packet : packets) {
            Inet6Address value = parsePacket(packet);
            if (value != null) return value;
        }
        return null;
    }

    private static Inet6Address parsePacket(byte[] data) {
        if (data == null || data.length < 12) return null;
        int qd = u16(data, 4);
        int an = u16(data, 6);
        int ns = u16(data, 8);
        int ar = u16(data, 10);
        int pos = 12;
        try {
            for (int i = 0; i < qd; i++) {
                pos = skipName(data, pos);
                pos += 4;
            }
            int records = an + ns + ar;
            for (int i = 0; i < records; i++) {
                pos = skipName(data, pos);
                int type = u16(data, pos); int cls = u16(data, pos + 2);
                int rdlen = u16(data, pos + 8);
                int rdata = pos + 10;
                if (rdata + rdlen > data.length) return null;
                if (type == 28 && cls == 1 && rdlen == 16) {
                    byte[] raw = new byte[16];
                    System.arraycopy(data, rdata, raw, 0, 16);
                    return (Inet6Address) Inet6Address.getByAddress(null, raw, 0);
                }
                pos = rdata + rdlen;
            }
        } catch (Exception ignored) { }
        return null;
    }

    private static int u16(byte[] d, int p) { return ((d[p] & 0xff) << 8) | (d[p + 1] & 0xff); }

    private static int skipName(byte[] d, int p) {
        int steps = 0;
        while (p < d.length && steps++ < 128) {
            int len = d[p] & 0xff;
            if (len == 0) return p + 1;
            if ((len & 0xc0) == 0xc0) return p + 2;
            p += len + 1;
        }
        throw new IllegalArgumentException("bad dns name");
    }
}
