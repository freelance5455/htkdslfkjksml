package com.kamarcast.app;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;

import java.net.InetAddress;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

/**
 * Discovers Apple TV AirPlay service advertisements over BLE.
 *
 * The Apple manufacturer specific data uses company id 0x004c and Continuity
 * record types 0x09 (AirPlay service discovery) and 0x16 (AWDL peer-to-peer
 * information). The 0x16 record is an indicator that the Apple TV advertises
 * Apple's peer-to-peer path; Android does not expose a public API for joining
 * that proprietary AWDL link, so this class deliberately stops at discovery.
 */
public final class AppleTvScanner {
    public interface Listener {
        void onAppleTvFound(Device device);
        void onFinished();
        void onError(String message);
    }

    public static final int APPLE_COMPANY_ID = 0x004C;
    private static final int AIRPLAY_CONTINUITY_TYPE = 0x09;
    private static final int AWDL_CONTINUITY_TYPE = 0x16;

    private final Context context;
    private final Listener listener;
    private BluetoothLeScanner scanner;
    private boolean scanning;
    private final Map<String, Device> devices = new HashMap<>();

    public AppleTvScanner(Context context, Listener listener) {
        this.context = context.getApplicationContext();
        this.listener = listener;
    }

    public boolean hasPermission() {
        if (Build.VERSION.SDK_INT >= 31) {
            return context.checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)
                    == PackageManager.PERMISSION_GRANTED;
        }
        return context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED;
    }

    public void start() {
        if (scanning) return;
        BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
        if (adapter == null) {
            listener.onError("Dieses Gerät unterstützt Bluetooth nicht.");
            return;
        }
        if (!adapter.isEnabled()) {
            listener.onError("Bluetooth ist deaktiviert.");
            return;
        }
        if (!hasPermission()) {
            listener.onError("Bluetooth-Berechtigung fehlt.");
            return;
        }
        scanner = adapter.getBluetoothLeScanner();
        if (scanner == null) {
            listener.onError("BLE-Scanner nicht verfügbar.");
            return;
        }

        devices.clear();
        scanning = true;
        try {
            ScanSettings settings = new ScanSettings.Builder()
                    .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
                    .build();
            scanner.startScan(null, settings, callback);
        } catch (SecurityException e) {
            scanning = false;
            listener.onError("Bluetooth-Scan wurde vom System blockiert.");
        }
    }

    public void stop() {
        if (!scanning || scanner == null) return;
        try {
            if (hasPermission()) scanner.stopScan(callback);
        } catch (SecurityException ignored) {
            // Permission could have been revoked while scanning.
        }
        scanning = false;
        listener.onFinished();
    }

    private final ScanCallback callback = new ScanCallback() {
        @Override
        public void onScanResult(int callbackType, ScanResult result) {
            if (result.getScanRecord() == null) return;

            byte[] manufacturer;
            try {
                manufacturer = result.getScanRecord()
                        .getManufacturerSpecificData(APPLE_COMPANY_ID);
            } catch (SecurityException e) {
                return;
            }
            if (manufacturer == null || manufacturer.length < 2) return;

            Parsed parsed = parseContinuity(manufacturer);
            if (!parsed.isAirPlay) return;

            String name = "Apple TV";
            try {
                if (result.getDevice() != null && result.getDevice().getName() != null) {
                    String candidate = result.getDevice().getName();
                    if (!candidate.isEmpty()) name = candidate;
                }
            } catch (SecurityException ignored) {
                // Name access can be gated by BLUETOOTH_CONNECT on Android 12+.
            }

            String bleAddress = null;
            try {
                if (result.getDevice() != null) bleAddress = result.getDevice().getAddress();
            } catch (SecurityException ignored) {
                // Not fatal; use a stable fallback key below.
            }
            if (bleAddress == null) {
                bleAddress = "unknown-" + Arrays.hashCode(manufacturer);
            }

            String ipv4 = null;
            if (parsed.ipBytes != null && parsed.ipBytes.length == 4) {
                try {
                    ipv4 = InetAddress.getByAddress(parsed.ipBytes).getHostAddress();
                } catch (Exception ignored) {
                    // Ignore malformed advertisement bytes.
                }
            }

            Device device = new Device(
                    name,
                    bleAddress,
                    ipv4,
                    parsed.port > 0 ? parsed.port : 7000,
                    parsed.awdl,
                    parsed.awdl ? "Peer-to-Peer AirPlay angekündigt" : "Nur klassisches AirPlay-Advertisement"
            );

            // Apple rotates BLE advertising addresses, so the address is only a short-lived
            // de-duplication key. A later advertisement is allowed to replace the device entry.
            Device old = devices.put(bleAddress, device);
            if (old == null || !old.sameConnectionInfo(device)) {
                listener.onAppleTvFound(device);
            }
        }

        @Override
        public void onScanFailed(int errorCode) {
            scanning = false;
            listener.onError("BLE-Scan fehlgeschlagen (Code " + errorCode + ").");
        }
    };

    /**
     * Parses one or more Apple Continuity records from manufacturer specific data.
     * The Android BLE API has already removed the 0x004c company id.
     */
    static Parsed parseContinuity(byte[] data) {
        Parsed out = new Parsed();
        int i = 0;
        while (i + 1 < data.length) {
            int type = data[i] & 0xFF;
            int len = data[i + 1] & 0xFF;
            int start = i + 2;
            int end = start + len;
            if (len < 0 || end > data.length) break;

            if (type == AIRPLAY_CONTINUITY_TYPE) {
                out.isAirPlay = true;
                int payloadLen = end - start;
                if (payloadLen >= 6) {
                    // Observed structure: flags (1), seed (1), IPv4 (4), optional port (2).
                    int flags = data[start] & 0xFF;
                    out.ipBytes = Arrays.copyOfRange(data, start + 2, start + 6);
                    if ((flags & 0x10) != 0 && payloadLen >= 8) {
                        out.port = ((data[start + 6] & 0xFF) << 8)
                                | (data[start + 7] & 0xFF);
                    } else {
                        out.port = 7000;
                    }
                }
            } else if (type == AWDL_CONTINUITY_TYPE) {
                // Undocumented Apple peer-to-peer / AWDL advertisement.
                out.awdl = true;
            }
            i = end;
        }
        return out;
    }

    public static final class Device {
        public final String name;
        public final String bleAddress;
        public final String ipv4;
        public final int port;
        public final boolean awdl;
        public final String capability;

        public Device(String name, String bleAddress, String ipv4, int port,
                      boolean awdl, String capability) {
            this.name = name;
            this.bleAddress = bleAddress;
            this.ipv4 = ipv4;
            this.port = port;
            this.awdl = awdl;
            this.capability = capability;
        }

        boolean sameConnectionInfo(Device other) {
            return awdl == other.awdl
                    && port == other.port
                    && safeEquals(ipv4, other.ipv4)
                    && safeEquals(name, other.name);
        }

        private static boolean safeEquals(String a, String b) {
            return a == null ? b == null : a.equals(b);
        }
    }

    static final class Parsed {
        boolean isAirPlay;
        boolean awdl;
        byte[] ipBytes;
        int port;
    }
}
