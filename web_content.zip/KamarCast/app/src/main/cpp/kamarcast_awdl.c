#include <jni.h>
#include <errno.h>
#include <fcntl.h>
#include <net/if.h>
#include <netpacket/packet.h>
#include <linux/if_ether.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <string.h>

/*
 * Minimal raw 802.11 transport primitive for rooted Android builds.
 * The socket is deliberately not put into monitor mode here because doing so
 * is device/driver-specific and must not be guessed. The caller can only send
 * frames once the kernel/driver has been configured for raw 802.11 injection.
 */
JNIEXPORT jint JNICALL
Java_com_kamarcast_app_NativeAwDlBridge_nativeOpenRaw80211(JNIEnv* env, jclass clazz, jstring ifaceName) {
    (void)clazz;
    if (!ifaceName) return -1;
    const char* name = (*env)->GetStringUTFChars(env, ifaceName, NULL);
    if (!name) return -1;
    unsigned int ifindex = if_nametoindex(name);
    (*env)->ReleaseStringUTFChars(env, ifaceName, name);
    if (ifindex == 0) return -1;

    int fd = socket(AF_PACKET, SOCK_RAW | SOCK_CLOEXEC, htons(ETH_P_ALL));
    if (fd < 0) return -1;

    struct sockaddr_ll addr;
    memset(&addr, 0, sizeof(addr));
    addr.sll_family = AF_PACKET;
    addr.sll_ifindex = (int)ifindex;
    addr.sll_halen = 6;
    if (bind(fd, (struct sockaddr*)&addr, sizeof(addr)) < 0) {
        close(fd);
        return -1;
    }
    int one = 1;
    setsockopt(fd, SOL_PACKET, PACKET_QDISC_BYPASS, &one, sizeof(one));
    return fd;
}

JNIEXPORT jint JNICALL
Java_com_kamarcast_app_NativeAwDlBridge_nativeSendRaw(JNIEnv* env, jclass clazz, jint handle, jbyteArray frame) {
    (void)clazz;
    if (handle < 0 || !frame) return -1;
    jsize len = (*env)->GetArrayLength(env, frame);
    if (len <= 0) return 0;
    jbyte* bytes = (*env)->GetByteArrayElements(env, frame, NULL);
    if (!bytes) return -1;
    ssize_t sent = send(handle, bytes, (size_t)len, MSG_DONTWAIT);
    (*env)->ReleaseByteArrayElements(env, frame, bytes, JNI_ABORT);
    return sent < 0 ? -errno : (jint)sent;
}

JNIEXPORT void JNICALL
Java_com_kamarcast_app_NativeAwDlBridge_nativeCloseRaw(JNIEnv* env, jclass clazz, jint handle) {
    (void)env; (void)clazz;
    if (handle >= 0) close(handle);
}
