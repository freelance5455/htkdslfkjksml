"""Protocol-level regression tests based on published Apple-TV BLE examples."""

def parse(data):
    is_airplay = False
    awdl = False
    ip = None
    port = 0
    i = 0
    while i + 1 < len(data):
        typ = data[i]
        length = data[i + 1]
        start = i + 2
        end = start + length
        if end > len(data):
            break
        if typ == 0x09:
            is_airplay = True
            payload = data[start:end]
            if len(payload) >= 6:
                flags = payload[0]
                ip = tuple(payload[2:6])
                if flags & 0x10 and len(payload) >= 8:
                    port = (payload[6] << 8) | payload[7]
                else:
                    port = 7000
        elif typ == 0x16:
            awdl = True
        i = end
    return is_airplay, awdl, ip, port


def test_apple_tv_3_airplay():
    r = parse(bytes.fromhex("09060330c0a801fd"))
    assert r == (True, False, (192, 168, 1, 253), 7000), r


def test_apple_tv_4k_awdl():
    r = parse(bytes.fromhex("09081330c0a801fd1b581608002c5eedb811afec"))
    assert r == (True, True, (192, 168, 1, 253), 7000), r


def test_truncated_record():
    r = parse(bytes.fromhex("0908"))
    assert r == (False, False, None, 0), r
