# KamarCast 0.3.0

Android prototype for direct Apple-TV mirroring research.

## Implemented

- BLE discovery of Apple TV AirPlay / Continuity advertisements.
- Detection of the Continuity/AWDL advertisement type.
- Four-digit AirPlay pairing-code dialog.
- MediaProjection capture in a foreground service.
- Hardware H.264 encoding with a low-power 1280x720/30 fps profile.
- Direct transport layer for an already-present `awdl0` IPv6 interface.
- Experimental rooted raw-802.11 transport primitive via NDK `AF_PACKET`.
- Explicit transport-state reporting; no Wi-Fi/Hotspot connection is mislabeled as AWDL.

## Important technical boundary

Apple's off-network AirPlay path uses AWDL. Public Android APIs do not provide an API to create Apple's AWDL interface. The open OWL implementation documents active monitor mode and frame injection as hardware/driver requirements and runs on Linux/macOS.

KamarCast therefore implements the Android-side transport primitive that is possible to test: use an existing `awdl0` interface when the OS exposes one, or open a raw 802.11 socket on a rooted/device-specific driver path. The missing parts for a fully stock-compatible Apple-TV mirror are the device-specific AWDL radio/driver integration and the full AirPlay sender/session stack above the transport (SRP/FairPlay, RTSP/HTTP session, encrypted H.264 RTP).

A current open-source Android mirroring project uses `doubletake` as its AirPlay sender over normal IP and documents the same limitation: Android hardware cannot use Apple's AWDL path for the off-network case.

## Performance

The capture path is intentionally bounded to 1280x720 at 30 fps with a 2.5-6 Mbps adaptive bitrate. Encoded buffers are handled without unnecessary copies inside the capture loop; stale frames should be dropped at the transport boundary instead of blocking the encoder.

## Build

Requires Android Studio/SDK, NDK and CMake 3.22.1. The project uses AGP 9.3.0, compile/target SDK 36.

This project is independent and not affiliated with Apple.

## Web start page

The project root contains `index.html` as a lightweight project landing page. It does not implement the Android transport itself; the Android app remains under `app/`.
