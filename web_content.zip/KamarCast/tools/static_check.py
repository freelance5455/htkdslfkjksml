from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
JAVA = list((ROOT / 'app/src/main/java').rglob('*.java'))
assert JAVA, 'No Java sources found'

# Strip strings and comments before simple delimiter checks. This avoids false
# positives from prose such as "foo(bar)" in comments or string literals.
def code_only(text: str) -> str:
    out=[]; i=0; state='code'
    while i < len(text):
        c=text[i]; n=text[i+1] if i+1 < len(text) else ''
        if state=='code':
            if c=='"': out.append(' '); state='string'; i+=1; continue
            if c=="'": out.append(' '); state='char'; i+=1; continue
            if c=='/' and n=='/': out.extend('  '); state='line'; i+=2; continue
            if c=='/' and n=='*': out.extend('  '); state='block'; i+=2; continue
            out.append(c); i+=1; continue
        if state=='string':
            if c=='\\': out.extend('  '); i+=2; continue
            if c=='"': out.append(' '); state='code'; i+=1; continue
            out.append(' '); i+=1; continue
        if state=='char':
            if c=='\\': out.extend('  '); i+=2; continue
            if c=="'": out.append(' '); state='code'; i+=1; continue
            out.append(' '); i+=1; continue
        if state=='line':
            if c=='\n': out.append('\n'); state='code'
            else: out.append(' ')
            i+=1; continue
        if state=='block':
            if c=='*' and n=='/': out.extend('  '); state='code'; i+=2; continue
            out.append('\n' if c=='\n' else ' '); i+=1
    return ''.join(out)

for path in JAVA:
    stripped = code_only(path.read_text(encoding='utf-8'))
    assert stripped.count('{') == stripped.count('}'), f'Unbalanced braces: {path}'
    assert stripped.count('(') == stripped.count(')'), f'Unbalanced parentheses: {path}'
    assert stripped.count('[') == stripped.count(']'), f'Unbalanced brackets: {path}'

manifest = (ROOT / 'app/src/main/AndroidManifest.xml').read_text(encoding='utf-8')
for needle in (
    'FOREGROUND_SERVICE_MEDIA_PROJECTION',
    'foregroundServiceType="mediaProjection"',
    'BLUETOOTH_SCAN',
):
    assert needle in manifest, f'Missing manifest entry: {needle}'

cmake = (ROOT / 'app/src/main/cpp/CMakeLists.txt').read_text(encoding='utf-8')
assert 'add_library(kamarcast_awdl SHARED kamarcast_awdl.c)' in cmake
print(f'Static checks OK: {len(JAVA)} Java files + native CMake target')
