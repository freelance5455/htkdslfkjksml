# 📱 Generar el APK de Carta Vedic para Android

Sigue estos pasos en tu ordenador (Windows, Mac o Linux).

## Requisitos previos

1. **Node.js** 18 o superior → https://nodejs.org
2. **Android Studio** (incluye el SDK) → https://developer.android.com/studio
   - Al instalar, marca "Android SDK", "Android SDK Platform" y "Android Virtual Device"
3. En Android Studio → Settings → Android SDK → instala:
   - Android 14 (API 34) o Android 13 (API 33)
   - Android SDK Build-Tools
   - Android SDK Platform-Tools

## Pasos para generar el APK

### 1. Abrir terminal en esta carpeta
```bash
cd CartaVedicAPK
```

### 2. Instalar dependencias
```bash
npm install
```

### 3. Añadir la plataforma Android
```bash
npx cap add android
```

### 4. Sincronizar el proyecto web con Android
```bash
npx cap sync android
```

### 5. Abrir en Android Studio
```bash
npx cap open android
```

### 6. Generar el APK desde Android Studio

**Opción A – APK de prueba (rápido):**
1. En Android Studio: menú **Build → Build Bundle(s) / APK(s) → Build APK(s)**
2. Cuando termine, pulsa **locate** → el archivo estará en:
   `android/app/build/outputs/apk/debug/app-debug.apk`
3. Copia ese `.apk` a tu teléfono e instálalo (activa "Orígenes desconocidos" si es necesario).

**Opción B – APK de liberación firmado (recomendado para distribuir):**
1. **Build → Generate Signed Bundle / APK**
2. Elige **APK**
3. Crea un nuevo keystore (guarda bien la contraseña y el alias)
4. Elige **release**
5. El APK firmado estará en `android/app/release/`

## Instalar en el teléfono

1. Transfiere el `.apk` al Android (USB, Drive, WhatsApp a ti mismo, etc.)
2. Abre el archivo → "Instalar"
3. Si sale aviso de seguridad → Ajustes → permitir instalar apps de esa fuente

## Actualizar la app más adelante

Si cambias el HTML o los datos:
1. Edita los archivos dentro de `www/`
2. Ejecuta de nuevo:
```bash
npx cap sync android
npx cap open android
```
3. Vuelve a generar el APK

## Atajos útiles

```bash
# Solo sincronizar cambios
npx cap sync android

# Abrir Android Studio
npx cap open android

# Ver logs en vivo del dispositivo
npx cap run android
```

## Solución de problemas comunes

| Problema | Solución |
|----------|----------|
| "SDK not found" | Abre Android Studio → SDK Manager y descarga Platform 34 |
| Gradle sync falla | File → Invalidate Caches / Restart |
| No se instala el APK | Activa "Instalar apps desconocidas" para el explorador de archivos |
| App en blanco | Ejecuta `npx cap sync` otra vez |

¡Listo! Con estos pasos tendrás un APK real instalable en cualquier Android.
