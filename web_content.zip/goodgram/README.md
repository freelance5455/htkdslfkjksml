# 🟦 GoodGram — Telegram Clone

A full-stack messaging app built with HTML, CSS, JavaScript, Python Flask & Firebase.

---

## 📁 Project Structure

```
goodgram/
├── templates/
│   └── index.html          ← Frontend HTML
├── static/
│   ├── css/
│   │   └── style.css       ← All styles
│   └── js/
│       ├── firebase-config.js  ← Firebase setup
│       ├── auth.js             ← Login/register/logout
│       ├── chat.js             ← Messaging logic
│       └── ui.js               ← Modals, emoji, toasts
├── backend/
│   └── app.py              ← Python Flask REST API
├── firestore.rules         ← Firestore security rules
├── storage.rules           ← Storage security rules
├── requirements.txt        ← Python dependencies
└── .env.example            ← Environment variable template
```

---

## 🔥 Step 1 — Set Up Firebase

1. Go to **https://console.firebase.google.com**
2. Click **Add Project** → name it "goodgram" → Create
3. Enable these services:
   - **Authentication** → Sign-in method → Enable **Email/Password** and **Anonymous**
   - **Firestore Database** → Create database → Start in **test mode** for now
   - **Storage** → Get started → Start in **test mode** for now

4. Register a **Web App**:
   - Project Settings (⚙️) → Your Apps → Add App → Web (</> icon)
   - Copy the `firebaseConfig` object

5. Edit `static/js/firebase-config.js` and paste your config:
```js
const firebaseConfig = {
  apiKey:            "your-actual-key",
  authDomain:        "your-project.firebaseapp.com",
  projectId:         "your-project-id",
  storageBucket:     "your-project.appspot.com",
  messagingSenderId: "123456789",
  appId:             "1:123:web:abc123"
};
```

---

## 🔒 Step 2 — Apply Security Rules

### Firestore Rules:
1. Firebase Console → Firestore → **Rules** tab
2. Replace all content with contents of `firestore.rules`
3. Click **Publish**

### Storage Rules:
1. Firebase Console → Storage → **Rules** tab
2. Replace all content with contents of `storage.rules`
3. Click **Publish**

---

## 🐍 Step 3 — Run the Python Backend

### Install Python 3.10+ first, then:

```bash
# 1. Go into the goodgram folder
cd goodgram

# 2. Create virtual environment
python -m venv venv

# 3. Activate it
# Windows:
venv\Scripts\activate
# Mac/Linux:
source venv/bin/activate

# 4. Install packages
pip install -r requirements.txt

# 5. Copy environment file
cp .env.example .env
```

### Download Firebase Service Account Key:
1. Firebase Console → Project Settings → **Service accounts** tab
2. Click **Generate new private key**
3. Save the JSON file as `serviceAccountKey.json` in the goodgram folder
4. **NEVER share or commit this file!** Add it to `.gitignore`

### Start the server:
```bash
cd backend
python app.py
```

Open **http://localhost:5000** in your browser 🎉

---

## ✨ Features

| Feature | Status |
|---------|--------|
| Email/Password Auth | ✅ |
| Anonymous (Guest) Login | ✅ |
| Real-time Messaging | ✅ |
| Direct Messages | ✅ |
| Group Chats | ✅ |
| File & Image Uploads | ✅ |
| Emoji Picker | ✅ |
| Message Search | ✅ |
| Offline Support | ✅ |
| Mobile Responsive | ✅ |
| Dark Theme | ✅ |
| Read Receipts (UI) | ✅ |
| Typing Indicator | 🔧 Coming soon |
| Push Notifications | 🔧 Coming soon |
| Voice Messages | 🔧 Coming soon |

---

## 🚀 Deploying to the Web (Free)

### Option A — Firebase Hosting (easiest):
```bash
npm install -g firebase-tools
firebase login
firebase init hosting
firebase deploy
```

### Option B — Railway.app:
1. Push code to GitHub
2. Go to railway.app → New Project → Deploy from GitHub
3. Set environment variables in Railway dashboard
4. It auto-detects Python and deploys!

---

## 🛠 API Endpoints (Python Flask)

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/` | Serve the app |
| GET | `/health` | Health check |
| GET | `/api/users/me` | Get your profile |
| PUT | `/api/users/me` | Update your profile |
| GET | `/api/users/search?q=email` | Search users |
| GET | `/api/chats` | Get your chats |
| POST | `/api/chats` | Create a chat |
| GET | `/api/chats/{id}/messages` | Get messages |
| POST | `/api/chats/{id}/messages` | Send a message |

All `/api/*` endpoints require: `Authorization: Bearer <firebase-id-token>`

---

## 📚 Learning Resources

- Firebase Docs: https://firebase.google.com/docs
- Flask Docs: https://flask.palletsprojects.com
- Firestore Realtime: https://firebase.google.com/docs/firestore/query-data/listen

---

Built with ❤️ — Happy coding!
