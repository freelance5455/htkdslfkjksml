# ─── GOODGRAM BACKEND — app.py ──────────────────────────────
# Python Flask backend for GoodGram
#
# Install dependencies:
#   pip install flask firebase-admin flask-cors python-dotenv
#
# Run:
#   python app.py

import os
import json
from datetime import datetime
from functools import wraps

from flask import Flask, jsonify, request, render_template, abort
from flask_cors import CORS
from dotenv import load_dotenv

# Firebase Admin SDK
import firebase_admin
from firebase_admin import credentials, auth, firestore

load_dotenv()

app = Flask(__name__, template_folder='templates', static_folder='static')
CORS(app, origins=["*"])

# ─── FIREBASE ADMIN INIT ─────────────────────────────────────
# Download your serviceAccountKey.json from Firebase Console:
# Project Settings → Service accounts → Generate new private key

SERVICE_ACCOUNT_PATH = os.getenv('FIREBASE_SERVICE_ACCOUNT', 'serviceAccountKey.json')

if os.path.exists(SERVICE_ACCOUNT_PATH):
    cred = credentials.Certificate(SERVICE_ACCOUNT_PATH)
    firebase_admin.initialize_app(cred)
    db = firestore.client()
    print("✅ Firebase Admin connected")
else:
    print("⚠️  serviceAccountKey.json not found.")
    print("   Download it from Firebase Console → Project Settings → Service accounts")
    print("   Running in demo mode (auth endpoints disabled).")
    db = None

# ─── AUTH MIDDLEWARE ──────────────────────────────────────────
def require_auth(f):
    """Decorator: verifies Firebase ID token in Authorization header."""
    @wraps(f)
    def decorated(*args, **kwargs):
        token = request.headers.get('Authorization', '').replace('Bearer ', '')
        if not token:
            return jsonify({'error': 'Missing authorization token'}), 401
        try:
            decoded = auth.verify_id_token(token)
            request.uid = decoded['uid']
            return f(*args, **kwargs)
        except Exception as e:
            return jsonify({'error': 'Invalid token', 'detail': str(e)}), 401
    return decorated

# ─── ROUTES ──────────────────────────────────────────────────

@app.route('/')
def index():
    """Serve the main GoodGram frontend."""
    return render_template('index.html')

@app.route('/health')
def health():
    """Health check endpoint."""
    return jsonify({
        'status': 'ok',
        'app':    'GoodGram',
        'time':   datetime.utcnow().isoformat()
    })

# ─── USER ENDPOINTS ──────────────────────────────────────────

@app.route('/api/users/me', methods=['GET'])
@require_auth
def get_me():
    """Get current user's profile."""
    if not db:
        return jsonify({'error': 'Database not initialized'}), 503
    doc = db.collection('users').document(request.uid).get()
    if not doc.exists:
        return jsonify({'error': 'User not found'}), 404
    return jsonify(doc.to_dict())

@app.route('/api/users/me', methods=['PUT'])
@require_auth
def update_me():
    """Update current user's profile."""
    if not db:
        return jsonify({'error': 'Database not initialized'}), 503

    data = request.get_json()
    allowed = ['name', 'bio', 'avatar']
    update = {k: v for k, v in data.items() if k in allowed}

    if not update:
        return jsonify({'error': 'No valid fields to update'}), 400

    update['updatedAt'] = firestore.SERVER_TIMESTAMP
    db.collection('users').document(request.uid).update(update)
    return jsonify({'success': True, 'updated': list(update.keys())})

@app.route('/api/users/search', methods=['GET'])
@require_auth
def search_users():
    """Search users by email prefix."""
    if not db:
        return jsonify({'error': 'Database not initialized'}), 503

    query = request.args.get('q', '').strip().lower()
    if len(query) < 2:
        return jsonify({'users': []})

    results = []
    docs = (db.collection('users')
              .where('email', '>=', query)
              .where('email', '<=', query + '\uf8ff')
              .limit(10)
              .stream())

    for doc in docs:
        u = doc.to_dict()
        if u.get('uid') != request.uid:
            results.append({
                'uid':    u.get('uid'),
                'name':   u.get('name'),
                'email':  u.get('email'),
                'avatar': u.get('avatar')
            })

    return jsonify({'users': results})

# ─── CHAT ENDPOINTS ──────────────────────────────────────────

@app.route('/api/chats', methods=['GET'])
@require_auth
def get_chats():
    """Get all chats for the current user."""
    if not db:
        return jsonify({'error': 'Database not initialized'}), 503

    chats = []
    docs = (db.collection('chats')
              .where('members', 'array_contains', request.uid)
              .order_by('lastTime', direction=firestore.Query.DESCENDING)
              .limit(50)
              .stream())

    for doc in docs:
        c = doc.to_dict()
        c['id'] = doc.id
        # Convert Firestore timestamps
        if c.get('lastTime'):
            c['lastTime'] = c['lastTime'].isoformat() if hasattr(c['lastTime'], 'isoformat') else str(c['lastTime'])
        chats.append(c)

    return jsonify({'chats': chats})

@app.route('/api/chats', methods=['POST'])
@require_auth
def create_chat():
    """Create a new chat (direct or group)."""
    if not db:
        return jsonify({'error': 'Database not initialized'}), 503

    data = request.get_json()
    chat_type = data.get('type', 'direct')

    if chat_type not in ['direct', 'group']:
        return jsonify({'error': 'Invalid chat type'}), 400

    chat_data = {
        'type':        chat_type,
        'members':     data.get('members', [request.uid]),
        'createdBy':   request.uid,
        'createdAt':   firestore.SERVER_TIMESTAMP,
        'lastMessage': '',
        'lastTime':    firestore.SERVER_TIMESTAMP
    }

    if chat_type == 'group':
        chat_data['name'] = data.get('name', 'New Group')

    # For direct chat, ensure requester is in members
    if request.uid not in chat_data['members']:
        chat_data['members'].append(request.uid)

    doc_ref = db.collection('chats').add(chat_data)
    return jsonify({'success': True, 'chatId': doc_ref[1].id}), 201

@app.route('/api/chats/<chat_id>/messages', methods=['GET'])
@require_auth
def get_messages(chat_id):
    """Get messages for a chat (paginated)."""
    if not db:
        return jsonify({'error': 'Database not initialized'}), 503

    # Verify user is in chat
    chat = db.collection('chats').document(chat_id).get()
    if not chat.exists or request.uid not in chat.to_dict().get('members', []):
        return jsonify({'error': 'Access denied'}), 403

    limit  = int(request.args.get('limit', 50))
    msgs   = []
    docs   = (db.collection('chats').document(chat_id)
                .collection('messages')
                .order_by('timestamp', direction=firestore.Query.DESCENDING)
                .limit(limit)
                .stream())

    for doc in docs:
        m = doc.to_dict()
        m['id'] = doc.id
        if m.get('timestamp'):
            m['timestamp'] = m['timestamp'].isoformat() if hasattr(m['timestamp'], 'isoformat') else str(m['timestamp'])
        msgs.append(m)

    msgs.reverse()  # Chronological order
    return jsonify({'messages': msgs})

@app.route('/api/chats/<chat_id>/messages', methods=['POST'])
@require_auth
def send_message(chat_id):
    """Send a message to a chat."""
    if not db:
        return jsonify({'error': 'Database not initialized'}), 503

    # Verify user is in chat
    chat = db.collection('chats').document(chat_id).get()
    if not chat.exists or request.uid not in chat.to_dict().get('members', []):
        return jsonify({'error': 'Access denied'}), 403

    data = request.get_json()
    text = data.get('text', '').strip()

    if not text:
        return jsonify({'error': 'Message cannot be empty'}), 400

    # Get sender info
    user_doc = db.collection('users').document(request.uid).get()
    sender_name = user_doc.to_dict().get('name', 'Unknown') if user_doc.exists else 'Unknown'

    msg = {
        'text':       text,
        'senderId':   request.uid,
        'senderName': sender_name,
        'timestamp':  firestore.SERVER_TIMESTAMP,
        'type':       'text'
    }

    doc_ref = db.collection('chats').document(chat_id).collection('messages').add(msg)

    # Update chat last message
    preview = text[:50] + '…' if len(text) > 50 else text
    db.collection('chats').document(chat_id).update({
        'lastMessage': preview,
        'lastTime':    firestore.SERVER_TIMESTAMP
    })

    return jsonify({'success': True, 'messageId': doc_ref[1].id}), 201

# ─── STATS ENDPOINT ──────────────────────────────────────────

@app.route('/api/stats', methods=['GET'])
@require_auth
def get_stats():
    """Get app stats for admin."""
    if not db:
        return jsonify({'error': 'Database not initialized'}), 503
    try:
        users = sum(1 for _ in db.collection('users').stream())
        chats = sum(1 for _ in db.collection('chats').stream())
        return jsonify({'users': users, 'chats': chats, 'status': 'healthy'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ─── ERROR HANDLERS ───────────────────────────────────────────

@app.errorhandler(404)
def not_found(e):
    return jsonify({'error': 'Not found'}), 404

@app.errorhandler(500)
def server_error(e):
    return jsonify({'error': 'Internal server error'}), 500

# ─── RUN ─────────────────────────────────────────────────────
if __name__ == '__main__':
    port = int(os.getenv('PORT', 5000))
    debug = os.getenv('DEBUG', 'true').lower() == 'true'
    print(f"🚀 GoodGram running on http://localhost:{port}")
    app.run(host='0.0.0.0', port=port, debug=debug)
