// ─── FIREBASE CONFIG ─────────────────────────────────────────
// 🔧 REPLACE THESE VALUES WITH YOUR OWN FIREBASE PROJECT CONFIG
// Go to: https://console.firebase.google.com
// → Your Project → Project Settings → Your Apps → Web App

const firebaseConfig = {
  apiKey:            "YOUR_API_KEY",
  authDomain:        "YOUR_PROJECT_ID.firebaseapp.com",
  projectId:         "YOUR_PROJECT_ID",
  storageBucket:     "YOUR_PROJECT_ID.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId:             "YOUR_APP_ID"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);

// ─── SERVICES ─────────────────────────────────────────────────
const auth     = firebase.auth();
const db       = firebase.firestore();
const storage  = firebase.storage();

// Enable offline persistence (messages work even offline)
db.enablePersistence({ synchronizeTabs: true })
  .catch(err => {
    if (err.code === 'failed-precondition') {
      console.warn('GoodGram: Multiple tabs open, persistence disabled.');
    } else if (err.code === 'unimplemented') {
      console.warn('GoodGram: Browser does not support offline persistence.');
    }
  });

// ─── FIRESTORE COLLECTIONS ───────────────────────────────────
// users/{uid}          → { uid, name, email, avatar, createdAt, lastSeen }
// chats/{chatId}       → { id, type, members, name, lastMessage, lastTime, createdAt }
// chats/{chatId}/messages/{msgId} → { text, senderId, senderName, timestamp, type, fileUrl? }

console.log("✅ GoodGram Firebase initialized");
