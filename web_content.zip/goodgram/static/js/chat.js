// ─── GOODGRAM CHAT.JS ─────────────────────────────────────────

let currentChatId = null;
let currentChatData = null;
let messagesListener = null;
let chatsListener = null;
let allChats = [];

// ─── LOAD CHATS (SIDEBAR) ─────────────────────────────────────
function loadChats() {
  if (chatsListener) chatsListener(); // Unsubscribe old listener

  chatsListener = db.collection('chats')
    .where('members', 'array-contains', currentUser.uid)
    .orderBy('lastTime', 'desc')
    .onSnapshot(snapshot => {
      allChats = [];
      snapshot.forEach(doc => {
        allChats.push({ id: doc.id, ...doc.data() });
      });
      renderChatList(allChats);
    }, err => {
      console.error('Chats listener error:', err);
      showToast('Could not load chats. Check Firestore rules.');
    });
}

// ─── RENDER CHAT LIST ─────────────────────────────────────────
function renderChatList(chats) {
  const list = document.getElementById('chat-list');

  if (chats.length === 0) {
    list.innerHTML = `
      <div class="empty-chats">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
          <path d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"/>
        </svg>
        <p>No chats yet</p>
        <small>Start a new conversation!</small>
      </div>`;
    return;
  }

  list.innerHTML = '';
  chats.forEach(chat => {
    const item = document.createElement('div');
    item.className = 'chat-item' + (chat.id === currentChatId ? ' active' : '');
    item.onclick = () => openChat(chat.id);

    const displayName = getChatDisplayName(chat);
    const avatar      = displayName.charAt(0).toUpperCase();
    const isGroup     = chat.type === 'group';
    const lastMsg     = chat.lastMessage || 'No messages yet';
    const lastTime    = chat.lastTime ? formatTime(chat.lastTime.toDate()) : '';

    item.innerHTML = `
      <div class="chat-item-avatar ${isGroup ? 'group' : ''}">${isGroup ? '👥' : avatar}</div>
      <div class="chat-item-body">
        <div class="chat-item-top">
          <span class="chat-item-name">${escapeHtml(displayName)}</span>
          <span class="chat-item-time">${lastTime}</span>
        </div>
        <div class="chat-item-bottom">
          <span class="chat-item-preview">${escapeHtml(lastMsg)}</span>
        </div>
      </div>`;
    list.appendChild(item);
  });
}

// ─── OPEN CHAT ────────────────────────────────────────────────
async function openChat(chatId) {
  // Cleanup previous listener
  if (messagesListener) messagesListener();

  currentChatId = chatId;

  // Highlight active chat
  document.querySelectorAll('.chat-item').forEach(i => i.classList.remove('active'));
  document.querySelectorAll('.chat-item').forEach(i => {
    if (i.onclick.toString().includes(chatId)) i.classList.add('active');
  });

  const chatDoc = await db.collection('chats').doc(chatId).get();
  currentChatData = { id: chatId, ...chatDoc.data() };

  const displayName = getChatDisplayName(currentChatData);
  const isGroup     = currentChatData.type === 'group';

  // Update chat header
  document.getElementById('chat-name').textContent    = displayName;
  document.getElementById('chat-subtitle').textContent = isGroup ? `${currentChatData.members?.length || 0} members` : 'Click for info';
  document.getElementById('chat-avatar').textContent  = isGroup ? '👥' : displayName.charAt(0).toUpperCase();

  // Show chat view
  document.getElementById('welcome-screen').classList.add('hidden');
  document.getElementById('chat-view').classList.remove('hidden');

  // Mobile: hide sidebar
  if (window.innerWidth <= 768) {
    document.getElementById('sidebar').classList.add('hidden-mobile');
  }

  // Clear & load messages
  const area = document.getElementById('messages-area');
  area.innerHTML = '<div class="day-divider"><span>Today</span></div>';

  listenToMessages(chatId);
}

// ─── REAL-TIME MESSAGES ───────────────────────────────────────
function listenToMessages(chatId) {
  messagesListener = db.collection('chats').doc(chatId)
    .collection('messages')
    .orderBy('timestamp', 'asc')
    .onSnapshot(snapshot => {
      snapshot.docChanges().forEach(change => {
        if (change.type === 'added') {
          renderMessage(change.doc.data(), change.doc.id);
        }
      });
      scrollToBottom();
    }, err => {
      console.error('Messages listener error:', err);
    });
}

// ─── RENDER MESSAGE ───────────────────────────────────────────
function renderMessage(msg, docId) {
  const area     = document.getElementById('messages-area');
  const isMe     = msg.senderId === currentUser.uid;
  const bubble   = document.createElement('div');
  bubble.className = `message-bubble ${isMe ? 'outgoing' : 'incoming'}`;
  bubble.dataset.msgId = docId;

  const timeStr = msg.timestamp ? formatTime(msg.timestamp.toDate()) : 'now';

  let contentHtml = '';

  if (msg.type === 'image') {
    contentHtml = `
      <div class="bubble-image">
        <img src="${msg.fileUrl}" alt="Image" loading="lazy" onclick="openImageViewer('${msg.fileUrl}')"/>
      </div>`;
  } else if (msg.type === 'file') {
    contentHtml = `
      <div class="bubble-file" onclick="window.open('${msg.fileUrl}')">
        <span class="file-icon">📎</span>
        <div class="file-info">
          <div class="file-name">${escapeHtml(msg.fileName || 'File')}</div>
          <div class="file-size">${msg.fileSize || ''}</div>
        </div>
      </div>`;
  } else {
    contentHtml = `<div class="bubble-content">${formatMessageText(msg.text || '')}</div>`;
  }

  bubble.innerHTML = `
    ${!isMe && currentChatData?.type === 'group' ? `<div class="bubble-sender">${escapeHtml(msg.senderName || 'Unknown')}</div>` : ''}
    ${contentHtml}
    <div class="bubble-meta">
      <span class="bubble-time">${timeStr}</span>
      ${isMe ? `<span class="bubble-ticks read">✓✓</span>` : ''}
    </div>`;

  area.appendChild(bubble);
}

// ─── SEND MESSAGE ─────────────────────────────────────────────
async function sendMessage() {
  if (!currentChatId || !currentUser) return;

  const input = document.getElementById('message-input');
  const text  = input.value.trim();
  if (!text) return;

  input.value = '';
  autoResize(input);

  const msg = {
    text:       text,
    senderId:   currentUser.uid,
    senderName: currentUserData?.name || 'Unknown',
    timestamp:  firebase.firestore.FieldValue.serverTimestamp(),
    type:       'text'
  };

  try {
    // Add message
    await db.collection('chats').doc(currentChatId)
      .collection('messages').add(msg);

    // Update chat metadata
    await db.collection('chats').doc(currentChatId).update({
      lastMessage: text.length > 50 ? text.substring(0, 47) + '…' : text,
      lastTime:    firebase.firestore.FieldValue.serverTimestamp()
    });
  } catch (err) {
    console.error('Send error:', err);
    showToast('Failed to send message. Try again.');
  }
}

// ─── FILE UPLOAD ──────────────────────────────────────────────
function triggerFileUpload() {
  document.getElementById('file-input').click();
}

async function handleFileUpload(event) {
  const file = event.target.files[0];
  if (!file || !currentChatId) return;

  const maxSize = 10 * 1024 * 1024; // 10MB
  if (file.size > maxSize) {
    showToast('File too large. Max size is 10MB.');
    return;
  }

  showToast('Uploading file…');

  try {
    const filePath = `chats/${currentChatId}/${Date.now()}_${file.name}`;
    const ref      = storage.ref(filePath);
    const snap     = await ref.put(file);
    const url      = await snap.ref.getDownloadURL();
    const isImage  = file.type.startsWith('image/');

    const msg = {
      senderId:   currentUser.uid,
      senderName: currentUserData?.name || 'Unknown',
      timestamp:  firebase.firestore.FieldValue.serverTimestamp(),
      type:       isImage ? 'image' : 'file',
      fileUrl:    url,
      fileName:   file.name,
      fileSize:   formatFileSize(file.size)
    };

    await db.collection('chats').doc(currentChatId)
      .collection('messages').add(msg);

    await db.collection('chats').doc(currentChatId).update({
      lastMessage: isImage ? '📷 Image' : `📎 ${file.name}`,
      lastTime:    firebase.firestore.FieldValue.serverTimestamp()
    });

    showToast('File sent! ✅');
  } catch (err) {
    console.error('Upload error:', err);
    showToast('Upload failed. Try again.');
  }

  event.target.value = '';
}

// ─── NEW DIRECT CHAT ──────────────────────────────────────────
async function startDirectChat(otherUser) {
  closeModal('new-chat-modal');

  // Check if chat already exists
  const existing = allChats.find(c =>
    c.type === 'direct' &&
    c.members.includes(otherUser.uid) &&
    c.members.includes(currentUser.uid)
  );

  if (existing) {
    openChat(existing.id);
    return;
  }

  // Create new direct chat
  const chatData = {
    type:        'direct',
    members:     [currentUser.uid, otherUser.uid],
    memberNames: { [currentUser.uid]: currentUserData.name, [otherUser.uid]: otherUser.name },
    createdAt:   firebase.firestore.FieldValue.serverTimestamp(),
    lastMessage: '',
    lastTime:    firebase.firestore.FieldValue.serverTimestamp()
  };

  const docRef = await db.collection('chats').add(chatData);
  openChat(docRef.id);
  showToast(`Chat with ${otherUser.name} started! 💬`);
}

// ─── NEW GROUP CHAT ───────────────────────────────────────────
async function createGroupChat() {
  const name    = document.getElementById('group-name-input').value.trim();
  const members = document.getElementById('group-members-input').value.trim();

  if (!name) { showToast('Please enter a group name.'); return; }

  const chatData = {
    type:        'group',
    name:        name,
    members:     [currentUser.uid],
    createdBy:   currentUser.uid,
    createdAt:   firebase.firestore.FieldValue.serverTimestamp(),
    lastMessage: 'Group created',
    lastTime:    firebase.firestore.FieldValue.serverTimestamp()
  };

  const docRef = await db.collection('chats').add(chatData);
  closeModal('new-chat-modal');
  openChat(docRef.id);
  showToast(`Group "${name}" created! 🎉`);
}

// ─── SEARCH USERS ─────────────────────────────────────────────
let searchTimeout;
async function searchUsers() {
  clearTimeout(searchTimeout);
  const query = document.getElementById('search-user-input').value.trim().toLowerCase();
  const results = document.getElementById('user-results');

  if (!query || query.length < 2) { results.innerHTML = ''; return; }

  searchTimeout = setTimeout(async () => {
    try {
      const snap = await db.collection('users')
        .where('email', '>=', query)
        .where('email', '<=', query + '\uf8ff')
        .limit(10)
        .get();

      results.innerHTML = '';

      if (snap.empty) {
        results.innerHTML = '<div style="padding:.75rem;color:#7d8c9a;font-size:.85rem;text-align:center">No users found</div>';
        return;
      }

      snap.forEach(doc => {
        const u = doc.data();
        if (u.uid === currentUser.uid) return; // Skip self

        const item = document.createElement('div');
        item.className = 'user-result-item';
        item.innerHTML = `
          <div class="user-result-avatar">${(u.name || 'U').charAt(0).toUpperCase()}</div>
          <div class="user-result-info">
            <div class="name">${escapeHtml(u.name || 'Unknown')}</div>
            <div class="email">${escapeHtml(u.email || '')}</div>
          </div>`;
        item.onclick = () => startDirectChat(u);
        results.appendChild(item);
      });
    } catch (err) {
      console.error('Search error:', err);
    }
  }, 400);
}

// ─── SEARCH CHATS ─────────────────────────────────────────────
function searchChats() {
  const q = document.getElementById('search-input').value.trim().toLowerCase();
  if (!q) { renderChatList(allChats); return; }
  const filtered = allChats.filter(c => getChatDisplayName(c).toLowerCase().includes(q));
  renderChatList(filtered);
}

// ─── FILTER CHATS ─────────────────────────────────────────────
function filterChats(type, btn) {
  document.querySelectorAll('.stab').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');

  if (type === 'all')    return renderChatList(allChats);
  if (type === 'groups') return renderChatList(allChats.filter(c => c.type === 'group'));
  if (type === 'unread') return renderChatList(allChats.filter(c => c.unreadCount > 0));
}

// ─── HELPERS ─────────────────────────────────────────────────
function getChatDisplayName(chat) {
  if (chat.type === 'group') return chat.name || 'Group';
  if (chat.type === 'direct' && chat.memberNames) {
    const otherUid = chat.members.find(m => m !== currentUser?.uid);
    return chat.memberNames[otherUid] || 'Direct Chat';
  }
  return 'Chat';
}

function formatTime(date) {
  if (!date) return '';
  const now  = new Date();
  const diff = now - date;
  if (diff < 60000)     return 'now';
  if (diff < 3600000)   return Math.floor(diff / 60000) + 'm';
  if (diff < 86400000)  return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  if (diff < 604800000) return ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'][date.getDay()];
  return date.toLocaleDateString([], { day:'2-digit', month:'short' });
}

function formatFileSize(bytes) {
  if (bytes < 1024)     return bytes + ' B';
  if (bytes < 1048576)  return (bytes / 1024).toFixed(1) + ' KB';
  return (bytes / 1048576).toFixed(1) + ' MB';
}

function formatMessageText(text) {
  return escapeHtml(text)
    .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
    .replace(/\*(.*?)\*/g, '<em>$1</em>')
    .replace(/`(.*?)`/g, '<code style="background:rgba(255,255,255,0.1);padding:1px 4px;border-radius:3px">$1</code>')
    .replace(/\n/g, '<br>');
}

function escapeHtml(text) {
  const d = document.createElement('div');
  d.textContent = text;
  return d.innerHTML;
}

function scrollToBottom() {
  const area = document.getElementById('messages-area');
  setTimeout(() => { area.scrollTop = area.scrollHeight; }, 50);
}

function backToList() {
  document.getElementById('sidebar').classList.remove('hidden-mobile');
  document.getElementById('chat-view').classList.add('hidden');
  document.getElementById('welcome-screen').classList.remove('hidden');
  currentChatId = null;
  if (messagesListener) messagesListener();
}

function handleMsgKey(e) {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    sendMessage();
  }
}

function autoResize(el) {
  el.style.height = 'auto';
  el.style.height = Math.min(el.scrollHeight, 120) + 'px';
}

function openImageViewer(url) {
  window.open(url, '_blank');
}
