// ─── GOODGRAM AUTH.JS ─────────────────────────────────────────

let currentUser = null;
let currentUserData = null;

// ─── TAB SWITCHING ────────────────────────────────────────────
function switchTab(tab) {
  document.querySelectorAll('.auth-tabs .tab-btn').forEach(b => b.classList.remove('active'));
  event.target.classList.add('active');
  document.getElementById('login-form').classList.toggle('hidden', tab !== 'login');
  document.getElementById('register-form').classList.toggle('hidden', tab !== 'register');
  clearAuthError();
}

function clearAuthError() {
  document.getElementById('auth-error').textContent = '';
}

function showAuthError(msg) {
  document.getElementById('auth-error').textContent = msg;
}

// ─── REGISTER ────────────────────────────────────────────────
async function registerUser() {
  const name     = document.getElementById('reg-name').value.trim();
  const email    = document.getElementById('reg-email').value.trim();
  const password = document.getElementById('reg-password').value;

  if (!name || !email || !password) return showAuthError('Please fill all fields.');
  if (password.length < 6) return showAuthError('Password must be at least 6 characters.');

  try {
    const cred = await auth.createUserWithEmailAndPassword(email, password);
    await saveUserToFirestore(cred.user, name, email);
    showToast('Account created! Welcome to GoodGram 🎉');
  } catch (err) {
    showAuthError(friendlyError(err.code));
  }
}

// ─── LOGIN ────────────────────────────────────────────────────
async function loginUser() {
  const email    = document.getElementById('login-email').value.trim();
  const password = document.getElementById('login-password').value;

  if (!email || !password) return showAuthError('Please enter your email and password.');

  try {
    await auth.signInWithEmailAndPassword(email, password);
    showToast('Welcome back! 👋');
  } catch (err) {
    showAuthError(friendlyError(err.code));
  }
}

// ─── GUEST LOGIN ─────────────────────────────────────────────
async function loginGuest() {
  try {
    const cred = await auth.signInAnonymously();
    const guestName = 'Guest_' + Math.random().toString(36).substr(2, 5).toUpperCase();
    await saveUserToFirestore(cred.user, guestName, 'guest@goodgram.app');
    showToast('Joined as guest. Have fun! 🚀');
  } catch (err) {
    showAuthError('Guest login failed. Check Firebase settings.');
  }
}

// ─── LOGOUT ──────────────────────────────────────────────────
async function logoutUser() {
  if (!confirm('Sign out of GoodGram?')) return;
  // Update last seen
  if (currentUser) {
    await db.collection('users').doc(currentUser.uid).update({
      lastSeen: firebase.firestore.FieldValue.serverTimestamp()
    }).catch(() => {});
  }
  await auth.signOut();
  currentUser = null;
  currentUserData = null;
  currentChatId = null;
  showScreen('auth-screen');
  showToast('Signed out. See you soon! 👋');
}

// ─── SAVE USER TO FIRESTORE ───────────────────────────────────
async function saveUserToFirestore(user, name, email) {
  const userData = {
    uid:       user.uid,
    name:      name,
    email:     email,
    avatar:    name.charAt(0).toUpperCase(),
    createdAt: firebase.firestore.FieldValue.serverTimestamp(),
    lastSeen:  firebase.firestore.FieldValue.serverTimestamp(),
    isOnline:  true
  };

  await db.collection('users').doc(user.uid).set(userData, { merge: true });
  return userData;
}

// ─── AUTH STATE OBSERVER ─────────────────────────────────────
auth.onAuthStateChanged(async user => {
  if (user) {
    currentUser = user;

    // Fetch or create user doc
    const userRef = db.collection('users').doc(user.uid);
    let snap = await userRef.get();

    if (!snap.exists) {
      const name = user.displayName || user.email?.split('@')[0] || 'User';
      currentUserData = await saveUserToFirestore(user, name, user.email || '');
    } else {
      currentUserData = snap.data();
      // Update online status
      await userRef.update({ isOnline: true, lastSeen: firebase.firestore.FieldValue.serverTimestamp() });
    }

    // Update sidebar UI
    document.getElementById('my-name').textContent    = currentUserData.name || 'You';
    document.getElementById('my-avatar').textContent  = (currentUserData.name || 'G').charAt(0).toUpperCase();

    showScreen('app-screen');
    loadChats();  // from chat.js
  } else {
    showScreen('auth-screen');
  }
});

// ─── HELPERS ─────────────────────────────────────────────────
function friendlyError(code) {
  const map = {
    'auth/user-not-found':        'No account with this email.',
    'auth/wrong-password':        'Incorrect password.',
    'auth/email-already-in-use': 'Email already registered.',
    'auth/invalid-email':         'Invalid email format.',
    'auth/weak-password':         'Password is too weak.',
    'auth/network-request-failed':'Network error. Check your connection.',
    'auth/too-many-requests':     'Too many attempts. Try again later.',
  };
  return map[code] || 'Something went wrong. Please try again.';
}

function showScreen(id) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  document.getElementById(id).classList.add('active');
}
