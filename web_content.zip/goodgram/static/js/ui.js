// ─── GOODGRAM UI.JS ───────────────────────────────────────────

// ─── TOAST ───────────────────────────────────────────────────
let toastTimeout;
function showToast(msg) {
  const toast = document.getElementById('toast');
  toast.textContent = msg;
  toast.classList.remove('hidden');
  clearTimeout(toastTimeout);
  toastTimeout = setTimeout(() => toast.classList.add('hidden'), 3000);
}

// ─── MODALS ──────────────────────────────────────────────────
function showNewChatModal() {
  document.getElementById('new-chat-modal').classList.remove('hidden');
  document.getElementById('search-user-input').focus();
}

function closeModal(id) {
  document.getElementById(id).classList.add('hidden');
  // Clear inputs
  document.getElementById('search-user-input').value = '';
  document.getElementById('user-results').innerHTML = '';
  document.getElementById('group-name-input').value = '';
  document.getElementById('group-members-input').value = '';
}

// Close modal on overlay click
document.getElementById('new-chat-modal').addEventListener('click', e => {
  if (e.target === e.currentTarget) closeModal('new-chat-modal');
});

// ─── MODAL TABS ───────────────────────────────────────────────
function switchModalTab(tab) {
  document.querySelectorAll('#new-chat-modal .tab-btn').forEach(b => b.classList.remove('active'));
  event.target.classList.add('active');
  document.getElementById('direct-tab').classList.toggle('hidden', tab !== 'direct');
  document.getElementById('group-tab').classList.toggle('hidden', tab !== 'group');
}

// ─── SEARCH TOGGLE ────────────────────────────────────────────
function toggleSearch() {
  const bar = document.getElementById('search-bar');
  bar.classList.toggle('hidden');
  if (!bar.classList.contains('hidden')) {
    document.getElementById('search-input').focus();
  }
}

function toggleChatSearch() {
  showToast('Search in chat — coming soon!');
}

function openChatInfo() {
  if (!currentChatData) return;
  const info = currentChatData.type === 'group'
    ? `Group: ${currentChatData.name}\nMembers: ${currentChatData.members?.length || 0}`
    : `Direct message chat`;
  showToast(info);
}

// ─── EMOJI PICKER ─────────────────────────────────────────────
const EMOJIS = [
  '😀','😂','🥰','😍','🤩','😎','🥳','😭','😤','🤔',
  '👍','👎','❤️','🔥','✨','🎉','🙌','💪','🤝','✅',
  '🚀','💡','⭐','🎯','🏆','💎','🌟','💫','⚡','🎊',
  '😊','😉','🤗','😏','🙃','😅','😬','🤭','🤫','🤐',
  '👋','🤚','🖐','✋','🖖','👌','🤌','🤏','✌️','🤞',
  '🐶','🐱','🐭','🐹','🐰','🦊','🐻','🐼','🐨','🐯',
  '🍎','🍊','🍋','🍇','🍓','🍕','🍔','🌮','🍜','🍰',
  '⚽','🏀','🏈','⚾','🎾','🏓','🎮','🎲','♟️','🎭'
];

let emojiPickerOpen = false;

function toggleEmojiPicker() {
  const picker = document.getElementById('emoji-picker');
  emojiPickerOpen = !emojiPickerOpen;

  if (emojiPickerOpen) {
    picker.classList.remove('hidden');

    // Build emoji grid if not yet built
    const grid = document.getElementById('emoji-grid');
    if (!grid.children.length) {
      EMOJIS.forEach(emoji => {
        const btn = document.createElement('button');
        btn.className = 'emoji-btn-item';
        btn.textContent = emoji;
        btn.onclick = () => insertEmoji(emoji);
        grid.appendChild(btn);
      });
    }
  } else {
    picker.classList.add('hidden');
  }
}

function insertEmoji(emoji) {
  const input = document.getElementById('message-input');
  const start = input.selectionStart;
  const end   = input.selectionEnd;
  input.value = input.value.slice(0, start) + emoji + input.value.slice(end);
  input.selectionStart = input.selectionEnd = start + emoji.length;
  input.focus();
  autoResize(input);
}

// Close emoji picker when clicking outside
document.addEventListener('click', e => {
  if (emojiPickerOpen &&
      !e.target.closest('#emoji-picker') &&
      !e.target.closest('.emoji-btn')) {
    document.getElementById('emoji-picker').classList.add('hidden');
    emojiPickerOpen = false;
  }
});

// ─── KEYBOARD SHORTCUTS ───────────────────────────────────────
document.addEventListener('keydown', e => {
  // Escape closes modals/picker
  if (e.key === 'Escape') {
    closeModal('new-chat-modal');
    document.getElementById('emoji-picker').classList.add('hidden');
    emojiPickerOpen = false;
  }
  // Ctrl+K opens search
  if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
    e.preventDefault();
    toggleSearch();
  }
});

// ─── RESPONSIVE ───────────────────────────────────────────────
window.addEventListener('resize', () => {
  if (window.innerWidth > 768) {
    document.getElementById('sidebar').classList.remove('hidden-mobile');
  }
});

console.log('✅ GoodGram UI ready');
