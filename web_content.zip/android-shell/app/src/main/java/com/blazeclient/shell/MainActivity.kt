package com.blazeclient.shell

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(2, 8, 23)
        window.navigationBarColor = Color.rgb(2, 8, 23)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 32, 24, 24)
            setBackgroundColor(Color.rgb(2, 8, 23))
        }
        val title = TextView(this).apply {
            text = "♨  BLAZE\\n       CLIENT"
            textSize = 34f
            setTextColor(Color.rgb(0, 186, 255))
            typeface = Typeface.create("sans-serif", Typeface.BOLD_ITALIC)
            gravity = Gravity.CENTER
        }
        root.addView(title, LinearLayout.LayoutParams(-1, 150))
        val info = TextView(this).apply {
            text = "MINECRAFT JAVA EDITION\\n\\nAndroid needs a compatible Java runtime, renderer, input system and game files. This shell does not include the game engine yet."
            textSize = 16f
            setTextColor(Color.rgb(210, 235, 255))
            gravity = Gravity.CENTER
            setPadding(8, 16, 8, 24)
        }
        root.addView(info)
        val btn = Button(this).apply {
            text = "VIEW ANDROID JAVA LAUNCHER PROJECT"
            setOnClickListener {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/AngelAuraMC/Amethyst-Android")))
            }
        }
        root.addView(btn, LinearLayout.LayoutParams(-1, 60))
        val note = TextView(this).apply {
            text = "BLAZE CLIENT shell v0.3.0 • not a complete game launcher"
            textSize = 12f
            setTextColor(Color.rgb(120, 180, 225))
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 0)
        }
        root.addView(note)
        setContentView(root)
    }
}
