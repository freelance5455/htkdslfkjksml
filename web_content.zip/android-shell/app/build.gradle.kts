plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.blazeclient.shell"
    compileSdk = 35
    defaultConfig { applicationId = "com.blazeclient.shell"; minSdk = 26; targetSdk = 35; versionCode = 3; versionName = "0.3.0" }
}
