BOLIX starter prototype
======================

Open index.html in a browser on your phone or computer.

Included:
- Responsive dark/neon BOLIX interface
- Sample chat list and local demo chat screen
- Calls, People and Settings screens
- Language selector preview

Important:
This is a front-end prototype only. It does NOT send messages between users, create accounts, make real calls, or provide end-to-end encryption. Those require a backend, authentication, a database, real-time messaging/calling services, and security testing. It is not yet ready to publish as a production Play Store app.
