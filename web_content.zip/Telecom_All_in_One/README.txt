TELECOM ALL-IN-ONE — हिंदी वेब ऐप
====================================

फाइलें:
- index.html : मुख्य सॉफ्टवेयर
- plan-catalog.json : शुरुआती प्लान कैटलॉग / डेटा संरचना
- README.txt : उपयोग और सीमाएँ

चलाने का तरीका:
1. ZIP को मोबाइल या कंप्यूटर में Extract करें।
2. index.html को Chrome/किसी आधुनिक ब्राउज़र में खोलें।
3. सर्च/फिल्टर से कंपनी और प्लान खोजें।
4. ग्राहक हिसाब में रिकॉर्ड सेव करें।
5. नियमित रूप से CSV डाउनलोड करके बैकअप रखें।

ध्यान दें:
- यह एक offline web-app prototype है; वास्तविक recharge transaction नहीं करता।
- इसमें दिए प्लान संदर्भ/उदाहरण हैं, हर circle की संपूर्ण या गारंटीड वर्तमान सूची नहीं।
- आधिकारिक कीमत, validity, 5G eligibility, FUP, OTT, GST, broadband availability को operator website पर verify करें।
- live auto-update और real recharge के लिए authorized operator/distributor API/credentials और backend की जरूरत होगी।
- किसी भी ग्राहक का OTP, UPI PIN या password सेव न करें।
- ग्राहक रिकॉर्ड उसी ब्राउज़र में local storage में सेव होते हैं; browser data साफ करने से रिकॉर्ड मिट सकते हैं।
- यह अभी Play Store APK/AAB नहीं है।
आधिकारिक लिंक:
Airtel prepaid: https://www.airtel.in/recharge/prepaid
Airtel broadband: https://www.airtel.in/plans/broadband
Jio mobile: https://www.jio.com/selfcare/recharge/mobility/
JioFiber: https://www.jio.com/selfcare/plans/fiber/
JioAirFiber: https://www.jio.com/airfiber
Vi: https://www.myvi.in/
BSNL: https://www.bsnl.co.in/
BSNL portal: https://portal.bsnl.in/
