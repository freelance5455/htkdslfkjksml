#!/usr/bin/env python3
"""Extract audio and request a timestamped transcript from Gemini.
Requires: ffmpeg on PATH, Python requests, GEMINI_API_KEY environment variable.
"""
import base64, json, os, subprocess, sys
from pathlib import Path
import requests

ROOT = Path(__file__).resolve().parents[1]
VIDEO = ROOT / "assets" / "original_video.mp4"
OUT_AUDIO = ROOT / "captions" / "source_audio.mp3"
OUT_JSON = ROOT / "captions" / "gemini_transcript.json"

key = os.environ.get("GEMINI_API_KEY")
if not key:
    sys.exit("Missing GEMINI_API_KEY. Set it as an environment variable; do not put it in this script.")
if not VIDEO.exists():
    sys.exit(f"Video not found: {VIDEO}")

OUT_AUDIO.parent.mkdir(parents=True, exist_ok=True)
subprocess.run([
    "ffmpeg", "-y", "-i", str(VIDEO), "-vn", "-ac", "1", "-ar", "16000",
    "-b:a", "64k", str(OUT_AUDIO)
], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

# Inline audio is suitable for short clips. For larger files, use Gemini Files API.
audio_b64 = base64.b64encode(OUT_AUDIO.read_bytes()).decode("ascii")
prompt = """Transcribe the attached audio exactly as spoken. Do not translate or paraphrase.
Return ONLY valid JSON with this schema:
{"language":"...","captions":[{"start":0.00,"end":1.20,"text":"exact spoken words"}]}
Use seconds for start/end, make short readable caption chunks, and align each chunk to the speech as accurately as possible. If a word is unclear, mark it [unclear] instead of guessing. Do not add words that are not audible."""
body = {
  "contents": [{"parts": [
    {"text": prompt},
    {"inline_data": {"mime_type": "audio/mpeg", "data": audio_b64}}
  ]}],
  "generationConfig": {"responseMimeType": "application/json", "temperature": 0.1}
}
url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent"
response = requests.post(url, headers={"x-goog-api-key": key, "Content-Type": "application/json"}, json=body, timeout=180)
if not response.ok:
    sys.exit(f"Gemini API error {response.status_code}: {response.text[:1500]}")
data = response.json()
try:
    text = data["candidates"][0]["content"]["parts"][0]["text"]
    parsed = json.loads(text)
except Exception as exc:
    (OUT_JSON.with_suffix(".raw.json")).write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    sys.exit(f"Could not parse Gemini transcript ({exc}). Raw API response saved next to output.")
OUT_JSON.write_text(json.dumps(parsed, ensure_ascii=False, indent=2), encoding="utf-8")
print(f"Saved transcript draft: {OUT_JSON}")
print("Review every word and timestamp before rendering; generated transcripts may contain errors.")
