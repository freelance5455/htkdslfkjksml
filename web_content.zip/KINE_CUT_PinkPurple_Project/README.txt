KINE CUT AI — Pink/Purple Caption Project + Gemini API setup

WHAT THIS ZIP DOES
- Includes your original video in assets/original_video.mp4.
- Includes a Gemini API helper script to transcribe the audio into timestamped captions (when supported by the model/API and audio quality).
- Includes the FFmpeg render starter for pink/purple captions.

IMPORTANT
- No API key is included. Never share your key in chat or commit it to source control.
- The API helper sends the extracted audio to Google's Gemini API. Review the generated words/timestamps before publishing; AI can make mistakes.
- This is a video-caption project with scripts, not a complete Android APK.

STEP 1 — Create a Gemini API key
1. Open https://aistudio.google.com/apikey
2. Sign in and create/view a key for your Google AI Studio project.
3. Keep the key private. Use a restricted key where available.

STEP 2 — Install tools
- Install Python 3 and FFmpeg.
- Install the Python dependency: python -m pip install requests

STEP 3 — Set the key (do not put it in this ZIP)
Linux/macOS/Termux:
  export GEMINI_API_KEY='YOUR_KEY_HERE'
Windows PowerShell:
  $env:GEMINI_API_KEY='YOUR_KEY_HERE'

STEP 4 — Generate captions from your actual audio
From this project folder run:
  python scripts/gemini_transcribe.py
It extracts audio from assets/original_video.mp4 and calls Gemini. The output is captions/gemini_transcript.json.
Check and correct the words and timestamps before using them. This script does not assume or invent what was spoken.

STEP 5 — Render the styled captions
Edit captions/captions_template.srt with the verified words/times, then run:
  bash render.sh
The render script outputs pink_purple_caption_video.mp4.

API SECURITY
For a public Android app, do not embed a Gemini API key in the APK. Use a secured backend or Firebase AI Logic with App Check. This local helper uses an environment variable only for development. Check current Google documentation for model and quota availability:
https://ai.google.dev/gemini-api/docs/api-key

ZIP SIZE NOTE
The original video is not bundled in this small ZIP. Copy your video to
assets/original_video.mp4 before running the scripts. This keeps the project
ZIP under 4 MB while preserving the setup files and scripts.
