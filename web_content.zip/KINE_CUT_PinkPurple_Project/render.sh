#!/usr/bin/env bash
# Requires ffmpeg. Edit captions/captions_template.srt with the exact spoken words first.
set -e
INPUT="assets/original_video.mp4"
CAPTIONS="captions/captions_template.srt"
OUTPUT="pink_purple_caption_video.mp4"
if grep -q '\[Add the' "$CAPTIONS"; then
  echo "Please replace the placeholder lines in $CAPTIONS with the exact spoken words and timings."
  exit 1
fi
ffmpeg -y -i "$INPUT" -vf "subtitles=$CAPTIONS:force_style='FontName=Lato,FontSize=18,Bold=1,PrimaryColour=&H00FFFFFF,OutlineColour=&H00C000FF,BackColour=&H80200030,BorderStyle=1,Outline=3,Shadow=1,Alignment=2,MarginV=130'" -c:v libx264 -crf 18 -preset medium -c:a copy "$OUTPUT"
echo "Created $OUTPUT"
