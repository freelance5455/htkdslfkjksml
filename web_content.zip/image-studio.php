<?php
require_once __DIR__ . '/app/bootstrap.php';
workspace_legacy_redirect('image/');
$pageTitle='Image Studio'; require __DIR__.'/app/platform_header.php'; require_once __DIR__.'/app/credits.php'; $imageCreditPrice=billing_price('image')??20; ?>
<section class="workspace-intro"><div><div class="eyebrow"><span class="eyebrow-line"></span> IMAGE-TO-IMAGE EDITING</div><h1>Image <em>Studio.</em></h1><p class="intro-copy">Edit an existing image with Lucy Image 2. Your original stays untouched.</p></div><span class="studio-tag">LUCY IMAGE 2</span></section>
<div class="workspace-note"><strong>Image editing requires a source image.</strong> Upload an image to begin. This workspace does not claim text-to-image generation. Estimated charge: <strong><?=number_format($imageCreditPrice)?> credits per generation.</strong></div>
<form id="imageForm" class="creative-form" enctype="multipart/form-data">
<section class="panel media-panel"><div class="section-heading"><div><span class="section-index">01</span><h2>Source media</h2></div><span class="section-hint">Tall preview · side by side</span></div>
<div class="media-pair">
<label class="media-card"><span class="media-label"><b>A</b> SOURCE IMAGE</span><div class="media-preview portrait-preview"><img id="imageSourcePreview" alt="Source image preview" hidden><span class="preview-empty" id="imageSourceEmpty"><i>▧</i><strong>Choose source image</strong><small>JPG · PNG · WebP</small></span></div><span class="media-action">＋ Upload source</span><input id="imageSource" name="data" type="file" accept="image/jpeg,image/png,image/webp" required></label>
<label class="media-card"><span class="media-label"><b>B</b> REFERENCE IMAGE <small>OPTIONAL</small></span><div class="media-preview portrait-preview"><img id="imageReferencePreview" alt="Reference image preview" hidden><span class="preview-empty" id="imageReferenceEmpty"><i>＋</i><strong>Add reference</strong><small>Optional visual guidance</small></span></div><span class="media-action">＋ Upload reference</span><input id="imageReference" name="reference_image" type="file" accept="image/jpeg,image/png,image/webp"></label>
</div></section>
<section class="panel prompt-library-panel" data-prompt-library="image" data-target="imagePrompt">
  <div class="section-heading"><div><span class="section-index">PROMPTS</span><h2>Prompt library</h2></div><span class="section-hint">Tap a card to insert</span></div>
  <div class="prompt-library-tools">
    <label class="prompt-search-wrap"><span class="sr-only">Search prompts</span><input class="prompt-search" type="search" placeholder="Search prompts…" autocomplete="off"></label>
    <div class="prompt-category-list" role="group" aria-label="Filter prompt categories"></div>
  </div>
  <div class="prompt-library-row" role="list" aria-label="Ready-to-use editing prompts">
    <div class="prompt-library-loading">Loading prompt collection…</div>
  </div>
  <p class="prompt-library-footnote">Prompts are starting points, not separate model features. Use only source and reference media you own or have permission to edit. Identity changes and virtual try-on are intended for consenting adults.</p>
  <div class="prompt-library-feedback" aria-live="polite"></div>
</section>
<section class="panel compact-setup"><div class="section-heading"><div><span class="section-index">02</span><h2>Quick setup</h2></div><span class="section-hint">Compact controls</span></div>
<label class="field-label" for="imagePrompt">EDITING PROMPT</label><textarea id="imagePrompt" name="prompt" rows="3" maxlength="2000" required placeholder="Describe the changes you want while preserving the important details..."></textarea>
<div class="setup-grid"><label><span class="field-label">OUTPUT RESOLUTION</span><select name="resolution"><option value="720p">720p</option><option value="480p">480p</option></select></label><label><span class="field-label">RANDOM SEED <small>OPTIONAL</small></span><input name="seed" type="number" min="0" max="4294967295" placeholder="Random"></label></div>
<label class="switch-row"><input type="checkbox" name="enhance_prompt" value="true" checked><span>Enhance prompt</span></label>
<button class="primary-button generate-button" id="imageGenerate" type="submit">Generate image <span>↗</span></button><div class="form-status" id="imageStatus" role="status" aria-live="polite">Ready when your source image and prompt are set.</div>
</section></form>
<section class="panel result-panel"><div class="section-heading"><div><span class="section-index">03</span><h2>Generated result</h2></div><span class="section-hint" id="imageResultMeta">Full-resolution output</span></div>
<div class="result-stage" id="imageResultStage"><div class="result-empty"><span>✳</span><strong>Your result appears here</strong><small>The generated image will display below setup, at its returned dimensions.</small></div><img id="imageResult" alt="Generated image result" hidden></div>
<div class="result-actions" id="imageResultActions" hidden><a class="outline-button" id="imageDownload" href="#" download>Download full resolution</a><button class="outline-button" id="imageOpenFull" type="button">Open original size</button></div></section>
<?php require __DIR__.'/app/platform_footer.php'; ?>
