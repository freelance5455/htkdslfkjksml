Contractor Pro 6.0.0 — Final Web/App Package
All-in-One Construction Business Manager

Package structure
- web/index.html       Main application
- web/manifest.json    Lightweight PWA metadata

Included in this release
- 7 languages: Persian, English, Arabic, Turkish, Russian, French, German.
- RTL/LTR layout switching.
- Locale-aware numbers, currency and calendar display.
- Automatic language-based time zone plus manual time-zone selection.
- Creation date/time and last-updated date/time for records.
- Projects, clients, estimates, contracts, team/workers, finance, materials, inventory, tools/equipment, schedule, documents and reports.
- Separate client account view with contracts, received payments, balance and projects.
- Inventory entry/exit with date/time, SKU, shelf/location, minimum stock and shelf-style visual stock view.
- Project tools/equipment with category/type, quantity and status.
- Add (+), edit, delete, search, copy and share actions across operational sections.
- Web Share API with clipboard fallback for Android WebView/offline packaging.
- JSON backup and restore.
- Lightweight localStorage storage with no external JavaScript libraries or network dependency.
- Backward-compatible import from the previous Contractor Pro storage key.
- Business profile: company/business name and user role.

Quality checks performed
1. JavaScript syntax validation with Node.js.
2. HTML/package structure inspection.
3. Required modules, languages, inventory fields, equipment fields, client account, timestamps and copy/share actions checked by automated static checks.
4. No external script/library dependency detected.
5. ZIP archive rebuilt from the final web directory and re-opened for integrity verification.

Important production note
This package is the final functional web/app layer. Commercial Android release features such as account authentication, Google Play/App Store billing, subscription/license entitlement, server-side verification, secure backend storage/sync, crash analytics and Play Integrity should be implemented in the native/production service layer before public paid distribution. A client-only HTML app cannot provide reliable server-side licensing or make its source impossible to extract.
