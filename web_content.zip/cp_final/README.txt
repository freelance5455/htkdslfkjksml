Contractor Pro V7.0 — Global Edition
All-in-One Construction Business Manager

Build target:
- Use the contents under web/ as the WebView/PWA payload.
- The entry page is web/index.html.

V7.0 Global Edition highlights:
- 7 UI languages: Persian, English, Arabic, Turkish, Russian, French, German.
- Country/region-aware profile with automatic currency, timezone, calendar and measurement-system defaults.
- Currency can be manually overridden without changing the selected country.
- Supported currencies include IRR, USD, EUR, AED, QAR, TRY, RUB, GBP, SAR and AZN.
- Connected Construction dashboard and Project Command Center.
- Project-centered connections among finance, materials, inventory, tools, workers and schedule.
- Client accounts plus a shareable Client Portal preview. A live multi-user portal requires a backend/authentication service.
- Global Search across the app.
- Quick Capture for common worker-hours and stock-entry phrases.
- Contractor Pro Copilot for local business questions using stored app data.
- Inventory: IN/OUT, date/time, SKU, shelf/location, minimum stock and shelf view.
- Tools/equipment by project with type/category, quantity and status.
- Add/edit/delete, timestamps, copy/share, backup/restore and local storage.
- Lightweight architecture with no external JavaScript libraries.

Important production note:
This is the V7 Web/PWA product layer. For commercial store release, add a secure backend for accounts, cloud sync, subscription/license entitlement, server-side purchase validation, client portal authentication and other online services. Do not place private API keys or licensing secrets in the APK/WebView bundle.
