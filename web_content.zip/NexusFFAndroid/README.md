# NEXUS FF — Android floating panel (HTML + Java)

Projeto de exemplo de um APK Android com interface HTML/JavaScript exibida dentro de uma sobreposição Android. A sobreposição pode ser arrastada, minimizada para uma bolha e reaberta. As opções da página são demonstrações locais e ficam salvas no armazenamento do WebView.

**Este projeto não contém cheats**: não lê a tela do Free Fire, não injeta código, não controla a mira do jogo e não revela jogadores. A permissão de sobreposição só permite mostrar o painel por cima de outros aplicativos.

## Abrir e compilar

1. Instale o Android Studio atual e um JDK compatível com a versão do Android Gradle Plugin.
2. Descompacte o projeto.
3. No Android Studio, escolha **Open** e selecione a pasta `NexusFFAndroid`.
4. Aguarde o Gradle sincronizar. Se necessário, instale Android SDK Platform 35 pelo SDK Manager.
5. Conecte um celular Android ou crie um emulador.
6. Pressione **Run** para instalar a versão de teste.
7. No app, toque em **ATIVAR PAINEL FLUTUANTE**.
8. Nas configurações do Android, permita **Exibir sobre outros apps** para NEXUS FF e volte ao app. Em Android 13+, permita notificações quando solicitado.
9. O painel aparece sobre outros aplicativos. Arraste pela barra superior, use `−` para minimizar ou `×` para encerrar o serviço.

## Gerar APK

No Android Studio, use **Build > Build Bundle(s) / APK(s) > Build APK(s)**. O APK de depuração costuma ficar em:

`app/build/outputs/apk/debug/app-debug.apk`

O caminho só existirá depois de uma compilação bem-sucedida.

## Notas técnicas

- `MainActivity.java`: solicita a permissão de sobreposição e inicia o serviço.
- `FloatingPanelService.java`: cria a janela `TYPE_APPLICATION_OVERLAY`, o cabeçalho arrastável, a bolha e o WebView.
- `app/src/main/assets/index.html`: UI e lógica HTML/JavaScript.
- A permissão `SYSTEM_ALERT_WINDOW` precisa ser concedida manualmente nas configurações do Android.
- O serviço usa uma notificação persistente enquanto a sobreposição está ativa.
- O Android pode variar as regras de notificações e serviços de primeiro plano entre fabricantes/versões; teste no dispositivo alvo.


## Build APK online with GitHub Actions

This project includes `.github/workflows/build-apk.yml`. To use it:
1. Create a GitHub repository and upload the contents of this folder.
2. Open the repository's **Actions** tab.
3. Select **Build NEXUS FF APK** and click **Run workflow** (or push to `main`).
4. When the run finishes, open the workflow run and download the artifact named `nexus-ff-debug-apk`.
5. Extract the artifact to get `app-debug.apk`.

This cloud workflow is provided as a build route; the APK is not prebuilt in this ZIP. The workflow must complete successfully before an installable APK exists.
