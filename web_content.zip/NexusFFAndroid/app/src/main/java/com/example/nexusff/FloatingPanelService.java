package com.example.nexusff;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class FloatingPanelService extends Service {
    private static final String CHANNEL_ID = "nexus_panel";
    private WindowManager windowManager;
    private LinearLayout root;
    private LinearLayout header;
    private WebView webView;
    private TextView bubble;
    private WindowManager.LayoutParams panelParams;
    private WindowManager.LayoutParams bubbleParams;
    private boolean minimized = false;

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        startForeground(1, buildNotification());
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        showPanel();
    }

    private int overlayType() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
    }

    private WindowManager.LayoutParams newParams(int width, int height, int gravity) {
        return new WindowManager.LayoutParams(width, height, overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
    }

    private void showPanel() {
        if (!Settings.canDrawOverlays(this)) {
            stopSelf();
            return;
        }

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(11, 17, 30));
        root.setElevation(12);

        header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(12, 8, 8, 8);
        header.setBackgroundColor(Color.rgb(16, 30, 48));

        TextView title = new TextView(this);
        title.setText("⚡ NEXUS FF");
        title.setTextColor(Color.rgb(0, 234, 255));
        title.setTextSize(16);
        title.setTypeface(null, 1);
        header.addView(title, new LinearLayout.LayoutParams(0, -2, 1));

        Button minimize = new Button(this);
        minimize.setText("−");
        minimize.setMinWidth(0);
        minimize.setMinimumWidth(0);
        header.addView(minimize, new LinearLayout.LayoutParams(48, 44));
        minimize.setOnClickListener(v -> minimizePanel());

        Button close = new Button(this);
        close.setText("×");
        close.setMinWidth(0);
        close.setMinimumWidth(0);
        header.addView(close, new LinearLayout.LayoutParams(48, 44));
        close.setOnClickListener(v -> stopSelf());

        root.addView(header, new LinearLayout.LayoutParams(-1, 54));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(11, 17, 30));
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        webView.setWebChromeClient(new WebChromeClient());
        webView.loadUrl("file:///android_asset/index.html");
        root.addView(webView, new LinearLayout.LayoutParams(300, 390));

        panelParams = newParams(300, -2, Gravity.TOP | Gravity.START);
        panelParams.x = 20;
        panelParams.y = 100;
        windowManager.addView(root, panelParams);
        enableDragging(header, root, panelParams);

        createBubble();
    }

    private void createBubble() {
        bubble = new TextView(this);
        bubble.setText("N");
        bubble.setTextSize(23);
        bubble.setTypeface(null, 1);
        bubble.setTextColor(Color.rgb(0, 234, 255));
        bubble.setGravity(Gravity.CENTER);
        bubble.setBackgroundColor(Color.rgb(7, 18, 30));
        bubble.setElevation(14);
        bubble.setVisibility(View.GONE);
        bubbleParams = newParams(58, 58, Gravity.TOP | Gravity.START);
        bubbleParams.x = 20;
        bubbleParams.y = 100;
        windowManager.addView(bubble, bubbleParams);
        bubble.setOnClickListener(v -> restorePanel());
        enableDragging(bubble, bubble, bubbleParams);
    }

    private void enableDragging(View handle, View movingView, WindowManager.LayoutParams params) {
        handle.setOnTouchListener(new View.OnTouchListener() {
            int startX, startY;
            float downX, downY;
            boolean moved;
            @Override public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = params.x;
                        startY = params.y;
                        downX = event.getRawX();
                        downY = event.getRawY();
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        int dx = (int)(event.getRawX() - downX);
                        int dy = (int)(event.getRawY() - downY);
                        if (Math.abs(dx) > 5 || Math.abs(dy) > 5) moved = true;
                        params.x = startX + dx;
                        params.y = startY + dy;
                        try { windowManager.updateViewLayout(movingView, params); } catch (Exception ignored) {}
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved && movingView == bubble) restorePanel();
                        return true;
                }
                return false;
            }
        });
    }

    private void minimizePanel() {
        if (root != null) root.setVisibility(View.GONE);
        if (bubble != null) bubble.setVisibility(View.VISIBLE);
        minimized = true;
    }

    private void restorePanel() {
        if (root != null) root.setVisibility(View.VISIBLE);
        if (bubble != null) bubble.setVisibility(View.GONE);
        minimized = false;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "NEXUS floating panel", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Notification for the user-started floating panel");
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(channel);
        }
    }

    private Notification buildNotification() {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            return new Notification.Builder(this, CHANNEL_ID)
                    .setContentTitle("NEXUS FF")
                    .setContentText("Painel flutuante ativo — toque para abrir o app")
                    .setSmallIcon(android.R.drawable.ic_menu_view)
                    .setContentIntent(pi).setOngoing(true).build();
        }
        return new Notification.Builder(this)
                .setContentTitle("NEXUS FF").setContentText("Painel flutuante ativo")
                .setSmallIcon(android.R.drawable.ic_menu_view).setContentIntent(pi).build();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        return START_NOT_STICKY;
    }

    @Override public void onDestroy() {
        try { if (root != null) windowManager.removeView(root); } catch (Exception ignored) {}
        try { if (bubble != null) windowManager.removeView(bubble); } catch (Exception ignored) {}
        if (webView != null) webView.destroy();
        stopForeground(true);
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
