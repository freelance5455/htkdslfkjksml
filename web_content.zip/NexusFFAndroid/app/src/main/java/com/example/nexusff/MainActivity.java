package com.example.nexusff;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.content.pm.PackageManager;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;
import android.view.ViewGroup;

public class MainActivity extends Activity {
    private static final int OVERLAY_REQUEST = 1001;
    private static final int NOTIFICATION_REQUEST = 1002;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(28, 28, 28, 28);
        root.setBackgroundColor(Color.rgb(8, 13, 23));

        TextView title = new TextView(this);
        title.setText("NEXUS FF");
        title.setTextSize(30);
        title.setTextColor(Color.rgb(0, 234, 255));
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView description = new TextView(this);
        description.setText("Painel flutuante de demonstração\\nMira de treino e opções visuais locais.");
        description.setTextSize(16);
        description.setTextColor(Color.WHITE);
        description.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        dp.topMargin = 18;
        root.addView(description, dp);

        Button start = new Button(this);
        start.setText("ATIVAR PAINEL FLUTUANTE");
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        bp.topMargin = 28;
        root.addView(start, bp);
        start.setOnClickListener(v -> requestOverlayPermission());

        TextView note = new TextView(this);
        note.setText("Este aplicativo não controla nem modifica o Free Fire.\\nA sobreposição só mostra os controles do próprio painel.");
        note.setTextColor(Color.LTGRAY);
        note.setTextSize(13);
        note.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        np.topMargin = 22;
        root.addView(note, np);

        setContentView(root);
    }

    private void requestOverlayPermission() {
        if (!Settings.canDrawOverlays(this)) {
            new AlertDialog.Builder(this)
                    .setTitle("Permissão de sobreposição")
                    .setMessage("Para mostrar o painel por cima de outros aplicativos, permita 'Exibir sobre outros apps' na próxima tela.")
                    .setNegativeButton("Cancelar", null)
                    .setPositiveButton("Abrir configurações", (d, w) -> {
                        Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:" + getPackageName()));
                        startActivityForResult(intent, OVERLAY_REQUEST);
                    }).show();
            return;
        }
        startPanelService();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == OVERLAY_REQUEST && Settings.canDrawOverlays(this)) {
            requestNotificationPermissionThenStart();
        }
    }

    private void requestNotificationPermissionThenStart() {
        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_REQUEST);
        } else {
            startPanelService();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == NOTIFICATION_REQUEST) {
            // The overlay can still be started; Android may restrict notification visibility if denied.
            startPanelService();
        }
    }

    private void startPanelService() {
        Intent intent = new Intent(this, FloatingPanelService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent);
        else startService(intent);
        finish();
    }
}
