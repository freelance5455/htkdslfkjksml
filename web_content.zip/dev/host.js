/*
 * AgentBase local host — a stand-in for AgentDBAppViewer.vue.
 *
 * Loads apps/<id>/src/<entry_file>, injects runtime/ the way serve_app_file()
 * does, runs it in a sandboxed iframe and answers the Bridge SDK's
 * postMessage requests from an in-browser Postgres (PGlite).
 *
 * Platform-owned: replaced on upload, do not edit.
 *
 * Message contract (keep in step with backend/agentdb/bridge_sdk.py and
 * frontend-nuxt/components/agentdb/AgentDBAppViewer.vue; a backend contract
 * test parses this file):
 *   app -> host  agentdb:bridgeReady, agentdb:request, agentdb:legacyRawSql,
 *                agentdb:commandResponse, agentdb:appJsError
 *   host -> app  agentdb:response, agentdb:command, agentdb:progress,
 *                agentdb:bridgeNotice
 */
(function () {
  'use strict';

  var ROOT = '../';
  var MAX_QUERY_ROWS = 10000; // service._MAX_QUERY_ROWS
  var RAW_SQL_DISABLED =
    'agentdb.query(rawSql) is disabled. Register a named query with ' +
    'agentdb_upsert_app_query and call ' +
    'agentdb.executeQuery(name, params) instead.';
  // Postgres compiled to WebAssembly: the apps' SQL runs as written.
  var PGLITE_URL = 'https://cdn.jsdelivr.net/npm/@electric-sql/pglite@0.2.17/dist/index.js';
  var NO_ROWS_HINT = 'Sample rows are only a slice of the workspace; a query can fail ' +
    'or return nothing locally when the rows it needs were not exported.';
  // Same markers the serve-time injectors key on.
  var KIT_MARKER = 'B-Suite Dashboard Design System';
  var EXPORT_MARKER = 'B-Suite dashboard export bar';
  var GUARD_MARKER = 'data-gs-export-guard';
  var THEME_MARKER = 'data-agentdb-theme';

  var state = {
    manifest: null,
    schema: null,
    runtime: {},
    db: null,
    // Settles when the database has loaded (or failed to). The app list is
    // clickable before that, so every query waits on it.
    dbReady: null,
    dbSettle: null,
    app: null,
    queries: {},
    iframe: null,
    cmdId: 0,
    cmdPending: {}
  };

  // ── Small helpers ───────────────────────────────────────────

  function $(id) { return document.getElementById(id); }

  function fetchText(path) {
    return fetch(ROOT + path, { cache: 'no-store' }).then(function (r) {
      if (!r.ok) throw new Error(path + ': HTTP ' + r.status);
      return r.text();
    });
  }

  function fetchJson(path, optional) {
    return fetch(ROOT + path, { cache: 'no-store' }).then(function (r) {
      if (!r.ok) {
        if (optional && r.status === 404) return null;
        throw new Error(path + ': HTTP ' + r.status);
      }
      return r.json();
    });
  }

  function report(kind, text, hint) {
    var row = document.createElement('div');
    row.className = 'row' + (kind === 'error' ? ' error' : '');
    row.textContent = text;
    if (hint) {
      var h = document.createElement('span');
      h.className = 'hint';
      h.textContent = hint;
      row.appendChild(h);
    }
    var panel = $('panel');
    panel.insertBefore(row, panel.firstChild);
    if (kind === 'error') panel.classList.add('open');
  }

  // ── Runtime injection (mirrors serve_app_file) ──────────────

  // Same three-level placement as the Python injectors: before </head>,
  // after <head>, else prepend.
  function injectHead(html, block) {
    if (html.indexOf('</head>') >= 0) return html.replace('</head>', function () { return block + '\n</head>'; });
    if (html.indexOf('<head>') >= 0) return html.replace('<head>', function () { return '<head>\n' + block; });
    return block + '\n' + html;
  }

  // html_tags.find_html_open_tag: the first <html…> tag.
  function htmlOpenTag(html) {
    var m = /<html\b[^>]*>/i.exec(html);
    return m ? { text: m[0], start: m.index, end: m.index + m[0].length } : null;
  }

  function injectBridge(html) {
    var js = state.runtime.bridge + '\n' + state.runtime.printBridge + '\n' + state.runtime.fileBridge;
    return injectHead(html, '<script>' + js + '</script>');
  }

  function injectExportGuard(html) {
    if (html.indexOf(GUARD_MARKER) >= 0) return html;
    return injectHead(html, '<script ' + GUARD_MARKER + '>' + state.runtime.exportGuard + '</script>');
  }

  // bridge_sdk.inject_dashboard_theme_into_html
  function injectTheme(html) {
    if (html.indexOf(THEME_MARKER) >= 0) return html;
    var tag = htmlOpenTag(html);
    if (tag && /\b(data-theme|data-palette)\s*=/i.test(tag.text)) return html;
    if (!/class\s*=\s*["'][^"']*\bdashboard\b/i.test(html)) return html;
    return injectHead(html, '<style ' + THEME_MARKER + '>' + state.runtime.theme + '</style>');
  }

  // dashboard_kit.inject_dashboard_kit_into_html
  function injectKit(html) {
    if (html.indexOf(KIT_MARKER) >= 0) return html;
    var tag = htmlOpenTag(html);
    if (!tag || !/\bdata-palette\s*=/i.test(tag.text)) return html;
    var r = state.runtime;
    var block = '<style data-gs-kit>\n' + r.tokens + '\n' + r.palettes + '\n' + r.kitCss + '\n</style>\n' +
      '<script data-gs-kit>\n' + r.kitJs + '\n</script>';
    return injectHead(html, block);
  }

  // dashboard_kit.inject_dashboard_export_into_html
  function injectExport(html) {
    if (html.indexOf(EXPORT_MARKER) >= 0) return html;
    var tag = htmlOpenTag(html);
    if (!tag || !/\bdata-palette\s*=/i.test(tag.text)) return html;
    var r = state.runtime;
    return injectHead(html, '<style data-gs-export>\n' + r.exportCss + '\n</style>\n' +
      '<script data-gs-export>\n' + r.exportJs + '\n</script>');
  }

  // bridge_sdk.inject_palette_into_html
  function injectPalette(html) {
    var palette = state.manifest.workspace && state.manifest.workspace.palette;
    var tag = htmlOpenTag(html);
    if (!palette || !tag || !/\bdata-palette\s*=/i.test(tag.text)) return html;
    var newTag = tag.text.replace(/(\bdata-palette\s*=\s*)(["']).*?\2/i, function (_m, attr) {
      return attr + '"' + palette + '"';
    });
    return html.slice(0, tag.start) + newTag + html.slice(tag.end);
  }

  // bridge_sdk.retrofit_responsive_charts_into_html
  function retrofitCharts(html) {
    var fixes = state.runtime.chartFixes || [];
    for (var i = 0; i < fixes.length; i++) {
      if (html.indexOf(fixes[i][0]) >= 0) html = html.split(fixes[i][0]).join(fixes[i][1]);
    }
    return html;
  }

  // ── App assets ──────────────────────────────────────────────

  // A file path in the app, not a URL elsewhere — and not an expression
  // from app code the scan happened to match (`src="${row.thumb}"` inside
  // a template literal, `src="' + url + '"` in a concatenation).
  function isRelative(url) {
    return url && !/^(?:[a-z][a-z0-9+.-]*:|\/\/|\/|#)/i.test(url) && !/[${}+<>`\s]/.test(url);
  }

  function resolveIn(base, rel) {
    var parts = (base ? base.split('/').slice(0, -1) : []).concat(rel.split('?')[0].split('#')[0].split('/'));
    var out = [];
    for (var i = 0; i < parts.length; i++) {
      if (parts[i] === '..') out.pop();
      else if (parts[i] && parts[i] !== '.') out.push(parts[i]);
    }
    return out.join('/');
  }

  function blobToDataUrl(blob) {
    return new Promise(function (resolve, reject) {
      var fr = new FileReader();
      fr.onload = function () { resolve(fr.result); };
      fr.onerror = function () { reject(fr.error); };
      fr.readAsDataURL(blob);
    });
  }

  // The frame runs at an opaque origin and cannot fetch the app's own
  // files, so fold them into the document: relative <script src> and
  // <link rel=stylesheet> become inline, relative <img src> a data: URL
  // (the platform's serve-time inliner does the first two).
  function inlineAssets(html, appId, entry) {
    var srcBase = 'apps/' + appId + '/src/';
    var jobs = [];
    var scriptRe = /<script\b([^>]*?)\bsrc\s*=\s*(["'])([^"']+)\2([^>]*)>\s*<\/script>/gi;
    var linkRe = /<link\b[^>]*>/gi;
    var imgRe = /(<img\b[^>]*?\bsrc\s*=\s*)(["'])([^"']+)\2/gi;
    var m;
    while ((m = scriptRe.exec(html))) {
      if (isRelative(m[3])) jobs.push({ kind: 'script', match: m[0], attrs: (m[1] + ' ' + m[4]).trim(), path: resolveIn(entry, m[3]) });
    }
    while ((m = linkRe.exec(html))) {
      var href = /\bhref\s*=\s*(["'])([^"']+)\1/i.exec(m[0]);
      if (/\brel\s*=\s*(["'])stylesheet\1/i.test(m[0]) && href && isRelative(href[2])) {
        jobs.push({ kind: 'style', match: m[0], path: resolveIn(entry, href[2]) });
      }
    }
    while ((m = imgRe.exec(html))) {
      if (isRelative(m[3])) jobs.push({ kind: 'img', match: m[0], prefix: m[1], quote: m[2], path: resolveIn(entry, m[3]) });
    }
    return Promise.all(jobs.map(function (job) {
      var url = ROOT + srcBase + job.path;
      if (job.kind === 'img') {
        return fetch(url).then(function (r) {
          if (!r.ok) throw new Error('HTTP ' + r.status);
          return r.blob();
        }).then(blobToDataUrl).then(function (data) {
          job.replacement = job.prefix + job.quote + data + job.quote;
        }, function () { report('error', '[resource] missing ' + job.path); });
      }
      return fetch(url).then(function (r) {
        if (!r.ok) throw new Error('HTTP ' + r.status);
        return r.text();
      }).then(function (text) {
        // A literal </script> or </style> inside the file would end the block.
        if (job.kind === 'script') {
          var attrs = job.attrs.replace(/\b(defer|async)\b/gi, '').trim();
          job.replacement = '<script' + (attrs ? ' ' + attrs : '') + ' data-src="' + job.path + '">' +
            text.replace(/<\/script/gi, '<\\/script') + '</script>';
        } else {
          job.replacement = '<style data-src="' + job.path + '">' + text.replace(/<\/style/gi, '<\\/style') + '</style>';
        }
      }, function () { report('error', '[resource] missing ' + job.path); });
    })).then(function () {
      jobs.forEach(function (job) {
        if (job.replacement !== undefined) {
          html = html.replace(job.match, function () { return job.replacement; });
        }
      });
      return html;
    });
  }

  // ── Local database ──────────────────────────────────────────

  function quoteIdent(name) { return '"' + String(name).replace(/"/g, '""') + '"'; }

  // Values as the production endpoint sends them (asyncpg rows through
  // FastAPI's JSON encoder): dates and timestamps as ISO-8601 strings,
  // numeric as a float, json/jsonb as the raw string (no codec is set).
  function isoTimestamp(v) {
    return v.replace(' ', 'T').replace(/([+-]\d\d)$/, '$1:00');
  }
  var PARSERS = {
    1082: function (v) { return v; },            // date
    1083: function (v) { return v; },            // time
    1114: isoTimestamp,                          // timestamp
    1184: isoTimestamp,                          // timestamptz
    1700: function (v) { return parseFloat(v); },  // numeric
    114: function (v) { return v; },             // json
    3802: function (v) { return v; }             // jsonb
  };

  function loadDatabase(PGlite, schemaSql, schema, sample) {
    var db = new PGlite({ parsers: PARSERS });
    var rows = 0;
    return db.exec(schemaSql).then(function () {
      if (!sample || !sample.tables) return null;
      // Sample rows are a slice: a child row may reference a parent that
      // was not exported. Load them with FK triggers off, as pg_restore does.
      return db.exec('SET session_replication_role = replica').then(function () {
        return schema.tables.reduce(function (chain, t) {
          var data = sample.tables[t.table_name];
          if (!data || !data.rows.length) return chain;
          var sql = 'INSERT INTO ' + quoteIdent(t.table_name) + ' (' + data.columns.map(quoteIdent).join(', ') +
            ') VALUES (' + data.columns.map(function (_c, i) { return '$' + (i + 1); }).join(', ') + ')';
          return data.rows.reduce(function (c2, row) {
            return c2.then(function () {
              return db.query(sql, row).then(function () { rows++; }, function (e) {
                report('error', 'Sample row rejected in ' + t.table_name + ': ' + e.message);
              });
            });
          }, chain).then(function () {
            // Explicit ids were inserted: move each serial past them, or
            // the app's first INSERT collides with a sample row.
            return t.columns.filter(function (c) { return c.is_serial; }).reduce(function (c3, c) {
              return c3.then(function () {
                return db.query('SELECT setval(pg_get_serial_sequence($1, $2), COALESCE(MAX(' + quoteIdent(c.name) +
                  '), 1)) FROM ' + quoteIdent(t.table_name), [quoteIdent(t.table_name), c.name]);
              });
            }, Promise.resolve());
          });
        }, Promise.resolve());
      }).then(function () { return db.exec('SET session_replication_role = origin'); });
    }).then(function () {
      state.db = db;
      $('db-status').textContent = 'Database: ' + schema.tables.length + ' tables, ' + rows + ' sample rows' +
        (sample ? '' : ' (exported without sample rows)');
    });
  }

  // service._validate_named_query_params.
  function bindParams(def, params) {
    var out = [];
    (def.params || []).forEach(function (p) {
      if (!(p.name in params)) {
        if (p.nullable) { out.push(null); return; }
        throw new Error("Missing required parameter: '" + p.name + "'");
      }
      var v = params[p.name];
      if (v === null || v === undefined) {
        if (!p.nullable) throw new Error("Parameter '" + p.name + "' cannot be null");
        out.push(null);
        return;
      }
      if (p.type === 'integer') {
        var n = typeof v === 'number' ? Math.trunc(v) : parseInt(String(v).trim(), 10);
        if (isNaN(n) || (typeof v === 'string' && !/^\s*[-+]?\d+\s*$/.test(v))) throw new Error("Parameter '" + p.name + "' must be integer, got " + typeof v);
        out.push(n);
      } else if (p.type === 'float') {
        var f = Number(v);
        if (isNaN(f)) throw new Error("Parameter '" + p.name + "' must be float, got " + typeof v);
        out.push(f);
      } else if (p.type === 'boolean') {
        out.push(typeof v === 'string' ? ['true', '1', 'yes'].indexOf(v.toLowerCase()) >= 0 : !!v);
      } else if (p.type === 'text') {
        out.push(String(v));
      } else {
        out.push(typeof v === 'object' ? JSON.stringify(v) : v);
      }
    });
    return out;
  }

  // Same envelope as service.execute_named_query.
  function executeNamedQuery(name, params) {
    var def = state.queries[name];
    if (!def) return Promise.reject(new Error("Query '" + name + "' is not registered for this app"));
    var positional;
    try { positional = bindParams(def, params || {}); } catch (e) { return Promise.reject(e); }
    return state.dbReady.then(function () {
      return state.db.query(def.sql, positional, { rowMode: 'array' });
    }).then(function (res) {
      var result = { columns: [], rows: [], row_count: 0, statements: [] };
      if (res.fields && res.fields.length) {
        var truncated = res.rows.length > MAX_QUERY_ROWS;
        var rows = truncated ? res.rows.slice(0, MAX_QUERY_ROWS) : res.rows;
        result.columns = res.fields.map(function (f) { return f.name; });
        result.rows = rows;
        result.row_count = rows.length;
        result.truncated = truncated;
        result.statements.push({ type: 'query', row_count: rows.length, truncated: truncated });
      } else {
        result.affected_rows = res.affectedRows || 0;
        result.statements.push({ type: 'execute', result: '', affected_rows: result.affected_rows });
      }
      result.is_mutation = !!def.is_mutation;
      return result;
    }, function (e) {
      report('error', 'Query ' + name + ' failed: ' + e.message + '\n' + def.sql, NO_ROWS_HINT);
      throw e;
    });
  }

  // ── Bridge (mirrors AgentDBAppViewer.handleBridgeMessage) ───

  // '*' is the only target an opaque-origin frame accepts: the app runs
  // sandboxed without allow-same-origin (as in production), so its origin
  // is "null" and cannot be named. The recipient is pinned by the window
  // reference instead — this frame's own contentWindow, nothing else.
  function post(msg) {
    // nosemgrep: javascript.browser.security.wildcard-postmessage-configuration.wildcard-postmessage-configuration
    if (state.iframe && state.iframe.contentWindow) state.iframe.contentWindow.postMessage(msg, '*');
  }

  function handleRequest(data) {
    var id = data.id;
    var params = data.params || {};
    function respond(result, error) {
      post({ type: 'agentdb:response', id: id, result: result, error: error });
    }
    switch (data.method) {
      case 'query':
        report('error', 'App called agentdb.query(rawSql), which is disabled.');
        respond(null, RAW_SQL_DISABLED);
        break;
      case 'executeQuery':
        if (!params.name) { respond(null, 'Missing params.name'); break; }
        executeNamedQuery(params.name, params.params || {}).then(function (r) { respond(r); }, function (e) {
          respond(null, e && e.message ? e.message : String(e));
        });
        break;
      case 'getSchema':
        respond({
          tables: state.schema.tables.map(function (t) {
            return { table_name: t.table_name, columns: t.columns.map(function (c) { return { name: c.name, type: c.type }; }) };
          })
        });
        break;
      case 'getAppInfo':
        respond({ id: state.app.id, name: state.app.name, scope: state.app.scope, table_name: state.app.table_name });
        break;
      case 'openAgent':
        // The agent panel lives beside the dashboard on the platform; an
        // exported copy has nothing to open.
        respond({ opened: false });
        break;
      case 'callService':
        // Services (Team Brain) live on the platform; an exported copy has none to call.
        respond({
          answer: '(Platform services are only available on the platform.)',
          citations: [], no_access: true, write: null
        });
        break;
      default:
        // print / downloadPdf land here: the print bridge falls back to its
        // in-app PDF on an "Unknown method" reply.
        respond(null, 'Unknown method: ' + data.method);
    }
  }

  window.addEventListener('message', function (e) {
    if (!state.iframe || e.source !== state.iframe.contentWindow || !e.data) return;
    var d = e.data;
    if (d.type === 'agentdb:request') {
      handleRequest(d);
    } else if (d.type === 'agentdb:bridgeReady') {
      $('app-status').textContent = 'bridge ready';
    } else if (d.type === 'agentdb:legacyRawSql') {
      console.warn('[agentdb] legacy raw-SQL call from app');
    } else if (d.type === 'agentdb:appJsError') {
      // The platform counts these; an exported app only logs them.
      console.warn('[agentdb] app error:', d.message);
    } else if (d.type === 'agentdb:commandResponse') {
      var p = state.cmdPending[d.id];
      if (!p) return;
      delete state.cmdPending[d.id];
      if (d.error) p.reject(new Error(d.error)); else p.resolve(d.result);
    }
  });

  // Host -> app commands (getConsoleLogs, executeJs, takeScreenshot).
  function command(method, params) {
    return new Promise(function (resolve, reject) {
      var id = ++state.cmdId;
      state.cmdPending[id] = { resolve: resolve, reject: reject };
      setTimeout(function () {
        if (state.cmdPending[id]) { delete state.cmdPending[id]; reject(new Error('command timeout: ' + method)); }
      }, 10000);
      post({ type: 'agentdb:command', id: id, method: method, params: params || {} });
    });
  }
  window.agentdbHost = { command: command };

  // ── App loading ─────────────────────────────────────────────

  function loadApp(appId) {
    var entry = state.manifest.apps.filter(function (a) { return a.id === appId; })[0];
    if (!entry) { report('error', 'No app ' + appId + ' in manifest.json'); return; }
    $('app-title').textContent = entry.name;
    $('app-status').textContent = 'loading…';
    Array.prototype.forEach.call(document.querySelectorAll('#apps a'), function (a) {
      a.classList.toggle('active', a.getAttribute('data-id') === appId);
    });
    Promise.all([
      fetchJson('apps/' + appId + '/app.json'),
      fetchJson('apps/' + appId + '/queries.json'),
      fetchText('apps/' + appId + '/src/' + entry.entry_file)
    ]).then(function (res) {
      state.app = res[0];
      state.queries = res[1] || {};
      return inlineAssets(res[2], appId, entry.entry_file);
    }).then(function (html) {
      // serve_app_file order.
      html = injectBridge(html);
      html = injectExportGuard(html);
      html = injectTheme(html);
      html = injectKit(html);
      html = injectExport(html);
      html = injectPalette(html);
      html = retrofitCharts(html);
      var wrap = $('frame-wrap');
      wrap.innerHTML = '';
      var iframe = document.createElement('iframe');
      // allow-downloads: agentdb.download and the in-app PDF save from the frame.
      iframe.setAttribute('sandbox', 'allow-scripts allow-popups allow-forms allow-downloads');
      iframe.setAttribute('title', entry.name);
      state.iframe = iframe;
      iframe.srcdoc = html;
      wrap.appendChild(iframe);
    }).catch(function (e) {
      $('app-status').textContent = 'failed';
      report('error', 'Could not load app ' + appId + ': ' + e.message);
    });
  }

  function renderAppList() {
    var ul = $('apps');
    state.manifest.apps.forEach(function (a) {
      var li = document.createElement('li');
      var link = document.createElement('a');
      link.href = '#app=' + encodeURIComponent(a.id);
      link.setAttribute('data-id', a.id);
      link.textContent = a.name;
      var small = document.createElement('small');
      small.textContent = a.scope === 'table' && a.table_name ? 'table · ' + a.table_name : a.scope;
      link.appendChild(small);
      link.addEventListener('click', function (ev) {
        ev.preventDefault();
        history.replaceState(null, '', '#app=' + encodeURIComponent(a.id));
        loadApp(a.id);
      });
      li.appendChild(link);
      ul.appendChild(li);
    });
    (state.manifest.skipped || []).forEach(function (s) {
      report('error', 'Skipped at export: ' + s.kind + ' ' + s.id + ' (' + s.reason + ')');
    });
  }

  function init() {
    state.dbReady = new Promise(function (resolve, reject) {
      state.dbSettle = { resolve: resolve, reject: reject };
    });
    // Observed here so a failed load is not also an unhandled rejection;
    // the failure itself is reported by the catch at the end of init.
    state.dbReady.catch(function () {});
    $('btn-panel').addEventListener('click', function () { $('panel').classList.toggle('open'); });
    $('btn-reload').addEventListener('click', function () { if (state.app) loadApp(state.app.id); });
    $('btn-console').addEventListener('click', function () {
      command('getConsoleLogs').then(function (r) {
        (r.logs || []).forEach(function (l) { report(l.type === 'error' ? 'error' : 'log', '[' + l.type + '] ' + l.data); });
        $('panel').classList.add('open');
      }, function (e) { report('error', e.message); });
    });

    Promise.all([
      fetchJson('manifest.json'),
      fetchJson('schema.json'),
      fetchJson('sample-data.json', true),
      fetchText('runtime/bridge.js'),
      fetchText('runtime/print_bridge.js'),
      fetchText('runtime/export_guard.js'),
      fetchText('runtime/theme.css'),
      fetchText('runtime/tokens.css'),
      fetchText('runtime/palettes.css'),
      fetchText('runtime/kit.css'),
      fetchText('runtime/kit.js'),
      fetchJson('runtime/chart_fixes.json'),
      fetchText('schema.sql'),
      fetchText('runtime/file_bridge.js'),
      fetchText('runtime/export.css'),
      fetchText('runtime/export.js')
    ]).then(function (r) {
      state.manifest = r[0];
      state.schema = r[1];
      state.runtime = {
        bridge: r[3], printBridge: r[4], exportGuard: r[5], theme: r[6],
        tokens: r[7], palettes: r[8], kitCss: r[9], kitJs: r[10], chartFixes: r[11],
        fileBridge: r[13], exportCss: r[14], exportJs: r[15]
      };
      $('ws-name').textContent = state.manifest.workspace.name;
      renderAppList();
      $('db-status').textContent = 'Database: starting Postgres…';
      var loaded = import(PGLITE_URL).then(function (mod) {
        return loadDatabase(mod.PGlite, r[12], state.schema, r[2]);
      }, function () {
        throw new Error('Could not load PGlite from ' + PGLITE_URL + ' (offline?)');
      });
      loaded.then(function () { state.dbSettle.resolve(); }, function (e) { state.dbSettle.reject(e); });
      return loaded.then(function () {
        // The fragment, not the query: `npx serve` redirects host.html to
        // host and drops the query string on the way; a fragment survives.
        var want = new URLSearchParams(location.hash.slice(1)).get('app') ||
          new URLSearchParams(location.search).get('app');
        var first = state.manifest.apps[0];
        if (want || first) loadApp(want || first.id);
      });
    }).catch(function (e) {
      $('ws-name').textContent = 'Failed to load';
      report('error', e.message, 'Serve the export folder (npx serve .) and open dev/host.html from it.');
    });
  }

  init();
})();
