AspendosRecord 2.0 — Android ZIP package

CONTENTS
- index.html: the offline shift and payment tracker.

IMPORTANT
This is a lightweight offline web app package, not an APK. It stores records in this browser on this phone using local storage. Do not clear the browser/app data unless you have separately recorded your figures.

OPENING
1. Extract the ZIP on your Android phone.
2. Open index.html with Chrome or another modern browser.
3. Use the app; no account or internet connection is required after the file is on your phone.

FEATURES
- Record shifts with date, Day/Night type, and amount earned.
- Search active shift records; newest first.
- Select and delete active records.
- Record lump-sum M-Pesa payments.
- Automatically allocate payments to oldest unpaid shifts first.
- Keep partially paid shifts active; move fully paid shifts to Paid Records.
- Search and delete paid records.
- Summary totals for earned, paid, outstanding, and shifts attended.

DATA
All records are stored locally in the browser on the phone. This package does not upload data to a server.
