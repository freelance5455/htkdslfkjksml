# CGD — Étape 6.10 : écran 10, Terrain 2D (disposition FM27)

Refonte de l'écran « Arène / Matchs » d'après la maquette validée :
- en-tête du match : compétition et rencontre, pièces restantes (rouge – bleu), chronomètre global, choix de l'arène et bouton 3D ;
- panneau gauche (ton club) : style, tour en cours, temps de réflexion, accès aux tactiques ;
- zone centrale : damier 10×10 « Damier galactique » (zone de jeu délimitée par l'utilisateur) ;
- panneau droit (adversaire) : style de l'IA, messages du match, règle de l'arène, tactiques verrouillées ;
- barre du bas : Simuler (à venir), Coup d'envoi (relance la partie), Tactique (à venir).

Règles techniques : tous les identifiants utilisés par `src/match-ui.js` sont conservés ; en paysage bas (≤ 560 px) l'en-tête CGD est masqué pendant le match et l'écran ne défile pas (vérifié en 895 × 393 et 844 × 390).
Non encore branché : forme des clubs (V/N/D), damiste sélectionné, Simuler, Tactique.
