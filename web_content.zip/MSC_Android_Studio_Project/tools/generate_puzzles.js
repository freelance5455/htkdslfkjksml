// Génère app/src/main/assets/puzzles.js à partir de tools/bank.json
// Usage : node tools/generate_puzzles.js   (nécessite Node.js)
const fs=require('fs'),path=require('path');
const bank=JSON.parse(fs.readFileSync(path.join(__dirname,'bank.json'),'utf8'));
const N=50,MAXW=9,MAXH=11;
let seed=20261106;
const rnd=()=>{seed|=0;seed=seed+0x6D2B79F5|0;let t=Math.imul(seed^seed>>>15,1|seed);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};
const shuffle=a=>{for(let i=a.length-1;i>0;i--){const j=Math.floor(rnd()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a;};
const K=(r,c)=>r+','+c, used={}, seen=new Set();
function attempt(pool,target){
  const cells=new Map(),placed=[];let r0=0,c0=0,r1=0,c1=0;
  const check=(w,r,c,d)=>{const dr=d==='D'?1:0,dc=d==='A'?1:0;
    if(cells.has(K(r-dr,c-dc))||cells.has(K(r+dr*w.length,c+dc*w.length)))return -1;
    let x=0;for(let i=0;i<w.length;i++){const rr=r+dr*i,cc=c+dc*i,e=cells.get(K(rr,cc));
      if(e){if(e.ch!==w[i]||e.dirs.has(d))return -1;x++;}
      else if(cells.has(K(rr+dc,cc+dr))||cells.has(K(rr-dc,cc-dr)))return -1;}
    return x;};
  const put=(w,r,c,d)=>{const dr=d==='D'?1:0,dc=d==='A'?1:0;
    for(let i=0;i<w.w.length;i++){const k=K(r+dr*i,c+dc*i);if(!cells.has(k))cells.set(k,{ch:w.w[i],dirs:new Set()});cells.get(k).dirs.add(d);}
    r0=Math.min(r0,r);c0=Math.min(c0,c);r1=Math.max(r1,r+dr*(w.w.length-1));c1=Math.max(c1,c+dc*(w.w.length-1));
    placed.push({word:w.w,r,c,dir:d,clue:w.c});};
  const starters=pool.filter(x=>x.w.length>=5&&x.w.length<=8).sort((a,b)=>(used[a.w]||0)-(used[b.w]||0));
  if(!starters.length)return null;
  const s=starters[Math.floor(rnd()*Math.min(4,starters.length))];put(s,0,0,rnd()<.5?'A':'D');
  while(placed.length<target){const opts=[];
    for(const w of pool){if(placed.some(p=>p.word===w.w))continue;
      for(const[k,e]of cells){const[r,c]=k.split(',').map(Number);
        for(let i=0;i<w.w.length;i++)if(w.w[i]===e.ch)for(const d of['A','D']){if(e.dirs.has(d))continue;
          const rr=d==='D'?r-i:r,cc=d==='A'?c-i:c,x=check(w.w,rr,cc,d);if(x<0)continue;
          const nr0=Math.min(r0,rr),nc0=Math.min(c0,cc),nr1=Math.max(r1,d==='D'?rr+w.w.length-1:rr),nc1=Math.max(c1,d==='A'?cc+w.w.length-1:cc);
          if(nr1-nr0+1>MAXH||nc1-nc0+1>MAXW)continue;
          opts.push({w,rr,cc,d,x,area:(nr1-nr0+1)*(nc1-nc0+1),u:used[w.w]||0});}}}
    if(!opts.length)break;
    opts.sort((a,b)=>a.u-b.u||b.x-a.x||a.area-b.area);
    const top=opts.slice(0,Math.min(6,opts.length)),o=top[Math.floor(rnd()*top.length)];put(o.w,o.rr,o.cc,o.d);}
  const cross=placed.reduce((n,p)=>n+p.word.length,0)-cells.size;
  return{words:placed.map(p=>({...p,r:p.r-r0,c:p.c-c0})),h:r1-r0+1,w:c1-c0+1,cross};}
const out=[];
for(let idx=0;idx<N;idx++){
  const cat=bank[idx%bank.length],tier=idx<17?1:idx<34?2:3,target=tier===1?5:6;
  const ok=w=>tier===1?w.t===1:tier===2?w.t<=2:w.t>=2;
  let best=null;
  for(const pool of[cat.words.filter(ok),cat.words]){for(let a=0;a<120;a++){
    const r=attempt(pool,target);if(!r||r.words.length<4)continue;
    const sig=r.words.map(w=>w.word).sort().join();if(seen.has(sig))continue;
    const sc=r.words.length*1000+r.cross*10-r.w*r.h/100;if(!best||sc>best.sc)best={...r,sc,sig};}
  if(best&&best.words.length>=5)break;} // le filtre de difficulté n'est relâché que si rien de valable n'a été trouvé
  if(!best)throw new Error('Aucune grille pour '+idx);
  seen.add(best.sig);best.words.forEach(w=>used[w.word]=(used[w.word]||0)+1);
  out.push({category:cat.eyebrow,title:cat.title,board:{words:best.words,h:best.h,w:best.w},level:idx+1});}
fs.writeFileSync(path.join(__dirname,'..','app/src/main/assets/puzzles.js'),'// Généré par tools/generate_puzzles.js — ne pas modifier à la main\nconst PUZZLES = '+JSON.stringify(out)+';\n');
console.log(out.length+' grilles écrites');
