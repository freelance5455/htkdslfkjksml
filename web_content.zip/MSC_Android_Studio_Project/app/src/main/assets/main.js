// Makani Slam Challenge — logique de jeu (les grilles sont dans puzzles.js)
const $=s=>document.querySelector(s);
const MODES={
  "Découverte":{sec:90,mult:1,hints:99,info:"90 s · XP ×1 · indices illimités (-5 XP chacun)"},
  "Expert":{sec:60,mult:1.5,hints:3,info:"60 s · XP ×1,5 · 3 indices maximum (-5 XP chacun)"},
  "Légende":{sec:40,mult:2,hints:0,info:"40 s · XP ×2 · aucun indice"}
};
const store={
  get(k,d){try{const v=localStorage.getItem(k);return v===null?d:JSON.parse(v)}catch(e){return d}},
  set(k,v){try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}}
};
const N=PUZZLES.length;
let mode="Découverte",idx=0,sel=null,cur=0,letters={},bad=new Set(),hints=0,endAt=0,timer=null,over=true,cm={};
let xp=Number(store.get("mscXp",0))||0,wins=Number(store.get("mscWins",0))||0,completed=store.get("mscDone",[]),best=store.get("mscBest",{});
if(store.get("mscVer",0)<3){completed=[];best={};store.set("mscVer",3);} // nouvelles grilles : la progression repart de zéro, l'XP est conservé
if(!Array.isArray(completed))completed=[];
if(!best||typeof best!=="object")best={};

const P=()=>PUZZLES[idx], W=()=>P().board.words, ck=(r,c)=>r+","+c;
const cell=(w,i)=>w.dir==="A"?ck(w.r,w.c+i):ck(w.r+i,w.c);
const left=()=>Math.max(0,Math.ceil((endAt-Date.now())/1000));
const gainNow=()=>Math.max(5,Math.round((20+Math.floor(left()/2))*MODES[mode].mult)-5*hints);

function save(){
  store.set("mscXp",xp);store.set("mscWins",wins);store.set("mscDone",completed);store.set("mscBest",best);
  $("#xp").textContent=xp;$("#wins").textContent=wins;
  $("#progressText").textContent=completed.length+" / "+N;$("#progressBar").style.width=(completed.length/N*100)+"%";
}
function show(id){["home","game","result"].forEach(x=>$("#"+x).classList.toggle("hidden",x!==id));}
function stop(){clearInterval(timer);timer=null;}
function goHome(){stop();over=true;save();show("home");}
window.msBack=()=>{if(!$("#home").classList.contains("hidden"))return false;goHome();return true;}; // appelé par le bouton Retour Android

// numérotation façon mots croisés : un seul numéro par case de départ, lecture ligne par ligne
function numbering(){
  const ws=W(),starts=[...new Set(ws.map(w=>ck(w.r,w.c)))].sort((a,b)=>{const[x,y]=a.split(",").map(Number),[u,v]=b.split(",").map(Number);return x-u||y-v;});
  ws.forEach(w=>w.n=starts.indexOf(ck(w.r,w.c))+1);
}
function cmap(){const m={};W().forEach((w,wi)=>[...w.word].forEach((_,i)=>(m[cell(w,i)]=m[cell(w,i)]||[]).push(wi)));return m;}
const order=()=>W().map((_,i)=>i).sort((a,b)=>(W()[a].dir===W()[b].dir?0:W()[a].dir==="A"?-1:1)||W()[a].n-W()[b].n);

function renderGrid(){
  const b=P().board,g=$("#grid"),w0=sel===null?null:W()[sel],curKey=w0?cell(w0,cur):null;
  const inSel=new Set(w0?[...w0.word].map((_,i)=>cell(w0,i)):[]);
  g.style.gridTemplateColumns=`repeat(${b.w},minmax(0,1fr))`;g.style.width=`min(100%,${b.w*46}px)`;g.innerHTML="";
  for(let r=0;r<b.h;r++)for(let c=0;c<b.w;c++){
    const k=ck(r,c),ids=cm[k],el=document.createElement("button");
    el.className="cell"+(ids?"":" block")+(inSel.has(k)?" selected":"")+(k===curKey?" cur":"")+(bad.has(k)?" bad":"");
    el.disabled=!ids;el.textContent=letters[k]||"";
    if(ids){
      const n=ids.map(i=>W()[i]).filter(w=>w.r===r&&w.c===c).map(w=>w.n)[0];
      if(n){const s=document.createElement("span");s.className="num";s.textContent=n;el.append(s);}
      el.onclick=()=>tap(k,ids);
    }
    g.append(el);
  }
}
function renderClues(){
  const ws=W();
  for(const[d,id]of[["A","across"],["D","down"]]){
    const box=$("#"+id);box.innerHTML="";
    ws.map((w,i)=>({w,i})).filter(o=>o.w.dir===d).sort((a,b)=>a.w.n-b.w.n).forEach(({w,i})=>{
      const e=document.createElement("div");e.className="clue";e.innerHTML=`<b>${w.n}.</b>${w.clue}`;e.dataset.word=i;
      e.onclick=()=>{selectWord(i);window.scrollTo({top:0,behavior:"smooth"});};box.append(e);
    });
  }
}
function selectWord(i,c){
  sel=i;const w=W()[i];
  cur=c!==undefined?c:Math.max(0,[...w.word].findIndex((_,j)=>!letters[cell(w,j)]));
  $("#selectedClue").innerHTML=`<b>${w.n}</b> ${w.dir==="A"?"Horizontal":"Vertical"} · ${w.clue} <small>(${w.word.length} lettres)</small>`;
  document.querySelectorAll(".clue").forEach(x=>x.classList.toggle("active",Number(x.dataset.word)===i));
  renderGrid();
}
// toucher une case : sélectionne son mot ; retoucher la case d'une intersection change de sens
function tap(k,ids){
  let wi;
  if(sel!==null&&ids.includes(sel)){
    wi=(cell(W()[sel],cur)===k&&ids.length>1)?ids.find(x=>x!==sel):sel;
  }else wi=ids[0];
  const w=W()[wi];selectWord(wi,[...w.word].findIndex((_,i)=>cell(w,i)===k));
}
function nextWord(){const o=order(),p=o.indexOf(sel);selectWord(o[(p+1)%o.length]);}
function enter(ch){
  if(over||$("#game").classList.contains("hidden"))return;
  if(sel===null)selectWord(order()[0]);
  if(ch==="↵"){nextWord();return;}
  const w=W()[sel],len=w.word.length;bad.clear();
  if(ch==="⌫"){
    const k=cell(w,cur);
    if(letters[k])delete letters[k];else if(cur>0){cur--;delete letters[cell(w,cur)];}
  }else{letters[cell(w,cur)]=ch;if(cur<len-1)cur++;}
  renderGrid();
}
function updHint(){
  const m=MODES[mode],h=$("#hint"),rest=m.hints-hints;
  h.disabled=over||rest<=0;
  h.textContent=m.hints===0?"💡 Aucun indice":"💡 Indice (-5 XP)"+(m.hints<99?` · ${Math.max(0,rest)}`:"");
}
function tick(){const l=left();$("#clock").textContent=l;$("#roundXp").textContent=gainNow();if(l<=0&&!over)finish(false);}
function loadPuzzle(i){
  stop();idx=i;sel=null;cur=0;letters={};bad=new Set();hints=0;over=false;
  numbering();cm=cmap();const p=P();
  $("#levelLabel").textContent=`GRILLE ${String(i+1).padStart(2,"0")} · ${mode.toUpperCase()}`;
  $("#category").textContent=p.category.toUpperCase();$("#puzzleTitle").textContent=p.title;
  $("#feedback").textContent="";$("#selectedClue").textContent="Choisis une définition pour commencer.";
  renderClues();renderGrid();updHint();show("game");window.scrollTo(0,0);
  endAt=Date.now()+MODES[mode].sec*1000;tick();timer=setInterval(tick,250);
}
function verify(){
  if(over)return;
  const miss=new Set(),wrong=new Set();
  W().forEach(w=>[...w.word].forEach((ch,i)=>{const k=cell(w,i),v=letters[k];if(!v)miss.add(k);else if(v!==ch)wrong.add(k);}));
  if(wrong.size){bad=wrong;renderGrid();$("#feedback").textContent=`${wrong.size} lettre(s) incorrecte(s) : repère les cases rouges.`;return;}
  if(miss.size){$("#feedback").textContent=`${miss.size} case(s) à compléter.`;return;}
  finish(true);
}
function finish(win){
  const l=left();stop();over=true;updHint();let nextT=(idx+1)%N,againT=idx;
  if(win){
    const gain=gainNow(),prev=best[idx]||0,add=Math.max(0,gain-prev),first=!completed.includes(idx+1);
    xp+=add;if(first){completed.push(idx+1);wins++;}best[idx]=Math.max(prev,gain);save();
    $("#resultTitle").textContent="Excellent travail !";
    $("#resultText").textContent=add>0?`Grille réussie en mode ${mode} : +${add} XP`+(first?". Ton savoir progresse !":" (nouveau record sur cette grille).")
      :"Grille déjà validée : pas d'XP supplémentaire. Bats ton record ou passe à la suite !";
    $("#next").textContent=idx===N-1?"RECOMMENCER →":"GRILLE SUIVANTE →";$("#again").textContent="Rejouer cette grille";
  }else{
    $("#resultTitle").textContent="Temps écoulé !";
    $("#resultText").textContent="Tu n'as pas terminé à temps. Réessaie : la grille est la même.";
    $("#next").textContent="RÉESSAYER →";$("#again").textContent="Passer à la grille suivante";nextT=idx;againT=(idx+1)%N;
  }
  $("#next").onclick=()=>loadPuzzle(nextT);$("#again").onclick=()=>loadPuzzle(againT);show("result");
}
function setMode(m){
  mode=m;document.querySelectorAll(".mode").forEach(x=>x.classList.toggle("active",x.dataset.mode===m));
  $("#modeInfo").textContent=MODES[m].info;
}

document.querySelectorAll("[data-key]").forEach(b=>b.onclick=()=>enter(b.dataset.key));
document.querySelectorAll(".mode").forEach(b=>b.onclick=()=>setMode(b.dataset.mode));
document.addEventListener("keydown",e=>{
  if(e.ctrlKey||e.metaKey||e.altKey)return;
  if(e.key==="Backspace")enter("⌫");else if(e.key==="Enter")enter("↵");else if(/^[a-z]$/i.test(e.key))enter(e.key.toUpperCase());
});
$("#start").onclick=()=>{const i=[...Array(N).keys()].find(k=>!completed.includes(k+1));loadPuzzle(i===undefined?0:i);};
$("#back").onclick=goHome;
$("#check").onclick=verify;
$("#hint").onclick=()=>{
  if(over||hints>=MODES[mode].hints)return;
  if(sel===null)selectWord(order()[0]);
  const w=W()[sel],i=[...w.word].findIndex((ch,j)=>letters[cell(w,j)]!==ch);
  if(i<0){$("#feedback").textContent="Ce mot est déjà correct, aucun indice utilisé.";return;}
  const k=cell(w,i);letters[k]=w.word[i];bad.delete(k);cur=i;hints++;updHint();
  $("#feedback").textContent="Une lettre a été révélée (-5 XP).";renderGrid();
};
setMode(mode);save();
