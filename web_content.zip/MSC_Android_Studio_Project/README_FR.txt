MAKANI SLAM CHALLENGE — PROJET ANDROID v2

Ce dossier est un projet Android Studio prêt à compiler, mais ce n'est PAS encore un APK.
Le poste de compilation doit disposer d'Android Studio, du JDK 17 et du SDK Android API 35.

Compilation :
1. Décompresser le dossier.
2. Ouvrir le dossier Makani_Android_Studio_Project dans Android Studio.
3. Laisser Gradle synchroniser les dépendances.
4. Menu Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio produira app/build/outputs/apk/debug/app-debug.apk.
6. Transférer ce fichier APK sur le téléphone Android et l'ouvrir pour l'installer.
   Android peut demander d'autoriser l'installation depuis cette source.

L'application embarque les fichiers HTML/CSS/JS en local dans une WebView.
Les scores et la progression sont conservés sur l'appareil via localStorage.

Limite : aucun APK ne peut être compilé dans l'environnement actuel, car Android SDK,
Gradle et adb ne sont pas installés. Ne pas présenter ce projet source comme un APK.
