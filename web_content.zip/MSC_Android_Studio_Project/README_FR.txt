MAKANI SLAM CHALLENGE — PROJET ANDROID v2.2

Projet Android Studio prêt à compiler. Ce n'est PAS un APK : il faut le compiler.
Prérequis : Android Studio (récent), JDK 17, SDK Android API 35.

Compilation
1. Décompresser l'archive.
2. Ouvrir le dossier MSC_Android_Studio_Project dans Android Studio.
3. Laisser Gradle synchroniser (il télécharge Gradle 8.9 via gradle/wrapper/gradle-wrapper.properties).
4. Menu Build > Build Bundle(s) / APK(s) > Build APK(s).
5. L'APK est produit dans app/build/outputs/apk/debug/app-debug.apk.
6. Le transférer sur le téléphone et l'ouvrir (autoriser l'installation depuis cette source si demandé).

Les fichiers HTML/CSS/JS sont embarqués dans une WebView (app/src/main/assets).
Scores et progression sont sauvegardés sur l'appareil (localStorage).

Nouveautés v2.2
- 50 grilles toutes différentes (10 thèmes, ~160 mots), vrais mots croisés (pas de lettres collées),
  difficulté croissante : grilles 1-17 faciles, 18-34 moyennes, 35-50 plus difficiles.
- Modes réels : à 0 s la manche est perdue. Découverte 90 s ×1 ; Expert 60 s ×1,5 (3 indices) ; Légende 40 s ×2 (sans indice).
- XP : (20 + secondes restantes/2) × multiplicateur, -5 XP par indice. Rejouer ne donne de l'XP que si tu bats ton record.
- Bouton Retour Android : grille -> accueil, accueil -> quitte l'application.
- Affichage correct sous Android 15 (barres système), icône d'application, Gradle 8.9 déclaré.
- Interface : clavier juste sous la grille, définitions en dessous ; toucher une intersection change de sens ;
  OK passe au mot suivant ; cases fausses en rouge après VÉRIFIER ; numéros standards.
- La progression des anciennes grilles est remise à zéro (les grilles ont changé) ; l'XP et les victoires sont conservés.

Ajouter ou modifier des grilles
- Éditer tools/bank.json (mot, difficulté 1-3, définition), puis lancer : node tools/generate_puzzles.js
  (écrit app/src/main/assets/puzzles.js).

Limites
- Non compilé ni testé sur un téléphone dans l'environnement de préparation (pas de SDK Android).
- gradlew / gradle-wrapper.jar ne sont pas fournis : Android Studio s'en passe ; en ligne de commande,
  lancer "gradle wrapper" une fois (Gradle 8.9 installé) pour les générer.
