#!/usr/bin/env node
const fs   = require('fs');
const path = require('path');
const http = require('http');
const ROOT = process.cwd();

// ============================================================
//  RUNTIME
// ============================================================
const FRAMEWORK_RUNTIME = `(function (global) {

  // ---------- ERROR OVERLAY ----------
  function showError(title, detail) {
    let box = document.getElementById('__err');
    if (!box) {
      box = document.createElement('div');
      box.id = '__err';
      box.style.cssText = [
        'position:fixed','top:0','left:0','right:0','z-index:99999',
        'background:#dc2626','color:#fff','padding:12px 16px',
        'font-family:ui-monospace,Menlo,Consolas,monospace','font-size:13px',
        'line-height:1.4','max-height:60vh','overflow:auto',
        'box-shadow:0 2px 12px rgba(0,0,0,.4)','white-space:pre-wrap'
      ].join(';');
      document.body.appendChild(box);
    }
    box.textContent = '❌ ' + title + '\\n\\n' + (detail || '');
  }

  global.addEventListener('error', (e) => {
    showError('JavaScript error', (e.message || '') + '\\n' +
      (e.filename || '') + ':' + (e.lineno || '') + ':' + (e.colno || ''));
  });
  global.addEventListener('unhandledrejection', (e) => {
    showError('Unhandled promise rejection', String(e.reason));
  });

  // ---------- STYLES ----------
  const _tagDefaults = {};
  const _namedStyles = {};

  function defaults(tag, classes) {
    if (classes === undefined) return _tagDefaults[tag] || '';
    _tagDefaults[tag] = classes;
    return classes;
  }
  function styles(obj) {
    if (obj === undefined) return _namedStyles;
    for (const [k, v] of Object.entries(obj)) _namedStyles[k] = v;
    return _namedStyles;
  }

  // ---------- ICONS ----------
  const ICONS = {
    home: '<path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>',
    menu: '<line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="18" x2="21" y2="18"/>',
    arrowLeft: '<line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/>',
    arrowRight: '<line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/>',
    chevronLeft: '<polyline points="15 18 9 12 15 6"/>',
    chevronRight: '<polyline points="9 18 15 12 9 6"/>',
    chevronDown: '<polyline points="6 9 12 15 18 9"/>',
    search: '<circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>',
    plus: '<line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>',
    minus: '<line x1="5" y1="12" x2="19" y2="12"/>',
    check: '<polyline points="20 6 9 17 4 12"/>',
    x: '<line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>',
    edit: '<path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>',
    trash: '<polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>',
    heart: '<path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>',
    star: '<polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>',
    cart: '<circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/>',
    bag: '<path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 0 1-8 0"/>',
    user: '<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
    bell: '<path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/>',
    calendar: '<rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/>',
    location: '<path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/>',
    mail: '<path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/>',
    eye: '<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>',
    lock: '<rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
    settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/>',
    clock:     '<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>',
    timer:     '<line x1="10" y1="2" x2="14" y2="2"/><line x1="12" y1="14" x2="15" y2="11"/><circle cx="12" cy="14" r="8"/>',
    alarm:     '<circle cx="12" cy="13" r="8"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="13" x2="15" y2="15"/><line x1="5" y1="3" x2="7" y2="5"/><line x1="19" y1="3" x2="17" y2="5"/>',
    hourglass: '<path d="M6 2h12M6 22h12M6 2v6a6 6 0 0 0 6 6 6 6 0 0 0 6-6V2M6 22v-6a6 6 0 0 1 6-6 6 6 0 0 1 6 6v6"/>',
  };

  class Node {
    constructor(tag, text) {
      this.el = document.createElement(tag);
      if (text != null) this.el.textContent = text;
      const d = _tagDefaults[tag];
      if (d) this.el.className = d;
    }

    set style(c) { this.el.className = c; }
    get style()  { return this.el.className; }

    addClass(...cs) {
      for (const c of cs)
        for (const t of String(c).split(/\\s+/))
          if (t) this.el.classList.add(t);
      return this;
    }
    removeClass(...cs) {
      for (const c of cs)
        for (const t of String(c).split(/\\s+/))
          if (t) this.el.classList.remove(t);
      return this;
    }
    toggleClass(...cs) {
      for (const c of cs)
        for (const t of String(c).split(/\\s+/))
          if (t) this.el.classList.toggle(t);
      return this;
    }
    hasClass(...cs) {
      for (const c of cs)
        for (const t of String(c).split(/\\s+/))
          if (!this.el.classList.contains(t)) return false;
      return true;
    }

    use(...names) {
      for (const n of names) {
        const s = _namedStyles[n];
        if (s) this.addClass(s);
      }
      return this;
    }

    set text(v) { this.el.textContent = v; }
    get text()  { return this.el.textContent; }

    set value(v) { this.el.value = v; }
    get value()  { return this.el.value; }

    set id(v)          { this.el.id = v; }
    get id()           { return this.el.id; }
    set src(v)         { this.el.src = v; }
    get src()          { return this.el.src; }
    set alt(v)         { this.el.alt = v; }
    get alt()          { return this.el.alt; }
    set placeholder(v) { this.el.placeholder = v; }
    get placeholder()  { return this.el.placeholder; }
    set href(v)        { this.el.href = v; }
    get href()         { return this.el.href; }

    set onClick(fn) { this.el.addEventListener('click', fn); }
    on(ev, fn) { this.el.addEventListener(ev, fn); return this; }

    onHover(fn) { this.el.addEventListener('mouseenter', fn); return this; }
    onLeave(fn) { this.el.addEventListener('mouseleave', fn); return this; }

    push(...kids) {
      for (const c of kids) this.el.append(c instanceof Node ? c.el : c);
      return this;
    }
  }

  function create(tag, text) { return new Node(tag, text); }
  function app(id) {
    const root = new Node('div');
    (document.getElementById(id || 'root') || document.body).append(root.el);
    return root;
  }

  // ---------- layout ----------
  function row(...kids) { const n = create('div'); n.style = 'flex flex-row items-center'; if (kids.length) n.push(...kids); return n; }
  function col(...kids) { const n = create('div'); n.style = 'flex flex-col'; if (kids.length) n.push(...kids); return n; }
  function spacer()     { const n = create('div'); n.style = 'flex-1'; return n; }
  function screen(...kids) {
    const n = create('div');
    n.style = 'min-h-screen p-4 flex flex-col gap-4';
    if (kids.length) n.push(...kids);
    return n;
  }
  function bottomBar(...kids) {
    const n = create('div');
    n.style = 'fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 p-4';
    if (kids.length) n.push(...kids);
    return n;
  }

  // ---------- widgets ----------
  function badge(count, ...extra) {
    const n = create('span', String(count));
    n.style = ('absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center font-bold ' + extra.join(' ')).trim();
    return n;
  }
  function rating(value, reviews, max) {
    max = max || 5;
    const n = create('div');
    n.style = 'flex items-center gap-1 text-sm';
    const full = Math.floor(value);
    for (let i = 0; i < full; i++) n.push(svg('star', 'w-4 h-4 text-yellow-400'));
    if (value - full >= 0.5) n.push(svg('star', 'w-4 h-4 text-yellow-400'));
    const t = create('span', value + (reviews != null ? '  (' + reviews + ')' : ''));
    t.style = 'text-gray-600 ml-1';
    n.push(t);
    return n;
  }
  function iconBtn(name, ...extra) {
    const btn = create('button');
    btn.style = ('relative p-2 rounded-full hover:bg-gray-100 flex items-center justify-center ' + extra.join(' ')).trim();
    btn.push(svg(name, 'w-6 h-6'));
    return btn;
  }

  // ---------- scroll ----------
  function scrollX(...kids) {
    const n = create('div');
    n.style = 'flex flex-row gap-2 overflow-x-auto no-scrollbar';
    if (kids.length) n.push(...kids);
    return n;
  }
  function scrollY(...kids) {
    const n = create('div');
    n.style = 'flex flex-col gap-2 overflow-y-auto no-scrollbar';
    if (kids.length) n.push(...kids);
    return n;
  }
  function hideScroll(node) { node.addClass('no-scrollbar'); return node; }

  // ---------- images ----------
  function img(src, alt, ...extra) {
    const n = create('img');
    n.src = src;
    n.alt = alt || '';
    n.style = extra.join(' ');
    return n;
  }
  function swatch(color, ...extra) {
    const n = create('button');
    n.style = ('w-10 h-10 rounded-xl border-2 border-gray-200 flex items-center justify-center ' + extra.join(' ')).trim();
    const dot = create('div');
    dot.style = 'w-5 h-5 rounded-full';
    dot.el.style.background = color;
    n.push(dot);
    return n;
  }
  function avatar(src, ...extra) {
    return img(src, 'avatar', 'w-12 h-12 rounded-full object-cover ' + extra.join(' '));
  }

  // ---------- svg ----------
  function svg(name, ...classes) {
    const cs = classes.filter(Boolean).join(' ');
    const hasW = /\\bw-/.test(cs);
    const hasH = /\\bh-/.test(cs);
    const cls = (hasW ? '' : 'w-6 ') + (hasH ? '' : 'h-6 ') + cs;
    const wrap = new Node('span');
    wrap.style = cls.trim();
    wrap.el.style.display = 'inline-block';
    const el = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    el.setAttribute('viewBox', '0 0 24 24');
    el.setAttribute('fill', 'none');
    el.setAttribute('stroke', 'currentColor');
    el.setAttribute('stroke-width', '2');
    el.setAttribute('stroke-linecap', 'round');
    el.setAttribute('stroke-linejoin', 'round');
    el.setAttribute('width', '100%');
    el.setAttribute('height', '100%');
    el.innerHTML = ICONS[name] || '';
    wrap.el.append(el);
    return wrap;
  }
  function iconList() { return Object.keys(ICONS); }

  // ---------- dict ----------
  function dic(key, value, obj) {
    obj = obj || {};
    obj[key] = value;
    return obj;
  }
  function findDK(obj, value) {
    if (!obj) return undefined;
    for (const k of Object.keys(obj)) if (obj[k] === value) return k;
    return undefined;
  }
  function findDV(obj, key) {
    if (!obj) return undefined;
    return obj[key];
  }

  // ---------- route ----------
  function route(id) {
    const target = document.getElementById(id);
    if (!target) {
      showError('route() could not find an element with id "' + id + '"',
                'Check that you set someEl.id = "' + id + '" and that it was pushed to root.');
      return;
    }
    const parent = target.parentElement || document.body;
    for (const child of parent.children) {
      if (child.id) child.style.display = (child === target) ? '' : 'none';
    }
    return target;
  }

  global.Node      = Node;
  global.create    = create;
  global.app       = app;
  global.text      = (t) => create('span', t);
  global.button    = (t) => create('button', t);
  global.view      = ()  => create('div');
  global.row       = row;
  global.col       = col;
  global.spacer    = spacer;
  global.screen    = screen;
  global.bottomBar = bottomBar;
  global.badge     = badge;
  global.rating    = rating;
  global.iconBtn   = iconBtn;
  global.scrollX   = scrollX;
  global.scrollY   = scrollY;
  global.hideScroll= hideScroll;
  global.img       = img;
  global.swatch    = swatch;
  global.avatar    = avatar;
  global.svg       = svg;
  global.icons     = iconList;
  global.dic       = dic;
  global.findDK    = findDK;
  global.findDV    = findDV;
  global.route     = route;
  global.defaults  = defaults;
  global.styles    = styles;
})(window);
`;

// ============================================================
//  INDEX.HTML
// ============================================================
const INDEX_HTML = `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport"
        content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    .no-scrollbar::-webkit-scrollbar { display: none; }
    .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
  </style>
</head>
<body class="bg-gray-50">
  <div id="root"></div>
  <script src="framework/framework.js"></script>
  <script src="js/app.js"></script>
</body>
</html>
`;

// ============================================================
//  APP.JS  (routing test)
// ============================================================
const APP_JS = `// js/app.js

const root = app();
root.style = 'bg-gray-50';

// ---------- HOME ----------
const home = create('div');
home.id = 'home';
home.style = 'p-6 flex flex-col gap-4';

const homeTitle = create('h1', 'Home');
homeTitle.style = 'text-2xl font-bold';

const goSettings = create('button', 'Go to settings');
goSettings.style = 'bg-blue-500 text-white p-4 rounded';
goSettings.onClick = () => route('settings');

home.push(homeTitle, goSettings);

// ---------- SETTINGS ----------
const settings = create('div');
settings.id = 'settings';
settings.style = 'p-6 flex flex-col gap-4';

const settingsTitle = create('h1', 'Settings');
settingsTitle.style = 'text-2xl font-bold';

const back = create('button', 'Back');
back.style = 'bg-gray-500 text-white p-4 rounded';
back.onClick = () => route('home');

settings.push(settingsTitle, back);

// ---------- MOUNT ----------
root.push(home, settings);
route('home');
`;

// ============================================================
//  FILE OPS
// ============================================================
const rel = p => path.relative(ROOT, p) || p;

const OWN = ['framework/framework.js', 'js/app.js', 'index.html'];

function clean() {
  for (const f of OWN) {
    const full = path.join(ROOT, f);
    if (fs.existsSync(full)) {
      fs.rmSync(full, { force: true });
      console.log('- del  ' + f);
    }
  }
}
function ensureDir(p) {
  if (!fs.existsSync(p)) { fs.mkdirSync(p, { recursive: true }); console.log('+ dir  ' + rel(p)); }
}
function writeFile(p, content) {
  fs.writeFileSync(p, content);
  console.log('+ file ' + rel(p));
}

// ============================================================
//  BUILD
// ============================================================
console.log('\n— cleaning —');
clean();

console.log('\n— building —');
ensureDir(path.join(ROOT, 'framework'));
ensureDir(path.join(ROOT, 'js'));
writeFile(path.join(ROOT, 'framework', 'framework.js'), FRAMEWORK_RUNTIME);
writeFile(path.join(ROOT, 'js', 'app.js'), APP_JS);
writeFile(path.join(ROOT, 'index.html'), INDEX_HTML);

// ============================================================
//  SERVE
// ============================================================
const PORT = 3000;
const TYPES = {
  '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css',
  '.json': 'application/json', '.png': 'image/png', '.jpg': 'image/jpeg', '.svg': 'image/svg+xml',
};

http.createServer((req, res) => {
  let f = req.url === '/' ? '/index.html' : req.url.split('?')[0];
  f = path.join(ROOT, f);
  fs.readFile(f, (err, data) => {
    if (err) { res.writeHead(404); return res.end('404'); }
    res.writeHead(200, { 'Content-Type': TYPES[path.extname(f)] || 'text/plain' });
    res.end(data);
  });
}).listen(PORT, () => {
  console.log('\nServing at:\n');
  console.log('  http://localhost:' + PORT + '\n');
  console.log('Press Ctrl+C to stop.\n');
});