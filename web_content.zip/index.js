// Tagklar Cloud-Backup-Worker
// ----------------------------
// Nimmt bereits VERSCHLÜSSELTE Backups entgegen (PUT) und liefert sie zurück (GET).
// Der Worker selbst sieht nie das Backup-Passwort und kann die Daten nicht entschlüsseln -
// er speichert nur den Ciphertext, den die Web-App vorher lokal erzeugt hat.
//
// Zugriff ist nur mit dem korrekten Header "X-Worker-Secret" möglich (Wert wird beim
// Deployment als Secret gesetzt, siehe README/Anleitung). Ohne diesen Header -> 401.

const ID_PATTERN = /^[A-Za-z0-9_-]{8,128}$/;
const MAX_BODY_BYTES = 2 * 1024 * 1024; // 2 MB reichen für ein Tagklar-Backup bei weitem

function corsHeaders(env) {
  return {
    'Access-Control-Allow-Origin': env.ALLOWED_ORIGIN || '*',
    'Access-Control-Allow-Methods': 'GET,PUT,OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, X-Worker-Secret',
    'Access-Control-Max-Age': '86400',
  };
}

function json(body, status, env) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { 'Content-Type': 'application/json', ...corsHeaders(env) },
  });
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const cors = corsHeaders(env);

    if (request.method === 'OPTIONS') {
      return new Response(null, { status: 204, headers: cors });
    }

    const match = url.pathname.match(/^\/backup\/([^/]+)$/);
    if (!match) return json({ error: 'not-found' }, 404, env);
    const id = decodeURIComponent(match[1]);
    if (!ID_PATTERN.test(id)) return json({ error: 'invalid-id' }, 400, env);

    if (!env.WORKER_SECRET) return json({ error: 'server-not-configured' }, 500, env);
    const providedSecret = request.headers.get('X-Worker-Secret') || '';
    if (providedSecret !== env.WORKER_SECRET) return json({ error: 'unauthorized' }, 401, env);

    if (request.method === 'GET') {
      const stored = await env.BACKUPS.get(id);
      if (!stored) return json({ error: 'not-found' }, 404, env);
      return new Response(stored, { status: 200, headers: { 'Content-Type': 'application/json', ...cors } });
    }

    if (request.method === 'PUT') {
      const contentLength = Number(request.headers.get('Content-Length') || '0');
      if (contentLength > MAX_BODY_BYTES) return json({ error: 'payload-too-large' }, 413, env);
      let payload;
      try { payload = await request.json(); } catch (error) { return json({ error: 'invalid-json' }, 400, env); }
      if (!payload || typeof payload !== 'object' || !payload.salt || !payload.iv || !payload.ciphertext) {
        return json({ error: 'invalid-payload' }, 400, env);
      }
      const record = { ...payload, updatedAt: new Date().toISOString() };
      await env.BACKUPS.put(id, JSON.stringify(record));
      return json({ ok: true, updatedAt: record.updatedAt }, 200, env);
    }

    return json({ error: 'method-not-allowed' }, 405, env);
  },
};
