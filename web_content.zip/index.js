/* ==================================================
   MUEEN | مُعين
   INDEX.JS
   شاشة البداية
================================================== */

document.addEventListener("DOMContentLoaded", function() {
    
    /*
     * الانتظار قليلًا حتى تظهر الهوية
     * بشكل أنيق قبل الانتقال إلى الرئيسية.
     */
    
    setTimeout(function() {
        
        window.location.href = "home.html";
        
    }, 2200);
    
});