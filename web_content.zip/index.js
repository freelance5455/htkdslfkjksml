import express from "express";
import cors from "cors";
import crypto from "node:crypto";
import Database from "better-sqlite3";
import * as cheerio from "cheerio";

const app = express();
app.use(cors());
app.use(express.json());

const ADMIN_PHONE = process.env.ADMIN_PHONE || "09120000000";
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "CHANGE-ME-NOW";
const SESSION_TTL_MS = 1000 * 60 * 60 * 24 * 7;
const sessions = new Map();

function authToken(){
  return crypto.randomBytes(32).toString("hex");
}
function requireAuth(req,res,next){
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : "";
  const session = sessions.get(token);
  if(!session || session.expiresAt < Date.now()){
    sessions.delete(token);
    return res.status(401).json({error:"unauthorized"});
  }
  req.user = session.user;
  next();
}



app.post("/api/auth/login",(req,res)=>{
  const {phone,password} = req.body || {};
  if(phone !== ADMIN_PHONE || password !== ADMIN_PASSWORD){
    return res.status(401).json({error:"شماره موبایل یا رمز عبور نادرست است."});
  }
  const token=authToken();
  sessions.set(token,{user:{phone,role:"admin"},expiresAt:Date.now()+SESSION_TTL_MS});
  res.json({token,expiresAt:Date.now()+SESSION_TTL_MS});
});
app.get("/api/auth/me",requireAuth,(req,res)=>res.json({user:req.user}));

const db = new Database("avaye-velayat.sqlite");
db.pragma("journal_mode = WAL");

db.exec(`
CREATE TABLE IF NOT EXISTS products(
 id TEXT PRIMARY KEY,
 name TEXT NOT NULL,
 brand TEXT,
 category TEXT,
 image TEXT,
 featured INTEGER DEFAULT 0,
 current_daily_rental_price_toman INTEGER,
 price_status TEXT DEFAULT 'inquiry',
 price_source TEXT,
 price_updated_at TEXT
);
CREATE TABLE IF NOT EXISTS price_sources(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL,
 url TEXT NOT NULL,
 enabled INTEGER DEFAULT 1,
 last_success TEXT,
 last_error TEXT
);
CREATE TABLE IF NOT EXISTS price_history(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 product_id TEXT,
 source_id INTEGER,
 price_toman INTEGER,
 fetched_at TEXT,
 status TEXT,
 raw_reference TEXT
);
CREATE TABLE IF NOT EXISTS sync_runs(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 started_at TEXT,
 finished_at TEXT,
 status TEXT,
 message TEXT
);
`);

const seed = [
 ["p1","سیستم کامل JBL PRX برای هیئت","JBL","سیستم کامل","speaker",1,null,"inquiry",null,null],
 ["p2","باند JBL PRX 715","JBL","باند و بلندگو","speaker",1,null,"inquiry",null,null],
 ["p3","میکسر Yamaha MG16","Yamaha","میکسر","mixer",1,null,"inquiry",null,null],
 ["p4","میکروفون بی‌سیم Shure QLX-D","Shure","میکروفون","mic",1,null,"inquiry",null,null],
 ["p5","آمپلی‌فایر Crown XLS","Crown","آمپلی‌فایر","amp",0,null,"inquiry",null,null],
 ["p6","آمپلی‌فایر / میکسر Dynacord","Dynacord","آمپلی‌فایر","amp",0,null,"inquiry",null,null],
 ["p7","باند RCF","RCF","باند و بلندگو","speaker",0,null,"inquiry",null,null],
 ["p8","باند Electro-Voice","EV","باند و بلندگو","speaker",1,1400000,"verified-reference","HomeServize",new Date().toISOString()]
];
const insert = db.prepare(`INSERT OR IGNORE INTO products VALUES (?,?,?,?,?,?,?,?,?,?)`);
for(const p of seed) insert.run(...p);

const sources = [
 ["HomeServize","https://homeservize.com/sound-system-rental"],
 ["اجاره باند تهران","https://ejarebandtehran.com/"],
 ["Iran Renter","https://iranrenter.com/page_id-859/"]
];
const srcInsert=db.prepare("INSERT OR IGNORE INTO price_sources(name,url) VALUES (?,?)");
for(const s of sources) srcInsert.run(...s);

function faToEn(s=""){
 return s.replace(/[۰-۹]/g,d=>"۰۱۲۳۴۵۶۷۸۹".indexOf(d)).replace(/[٬,]/g,"").replace(/تومان|ت\/?ومان/g,"").trim();
}
function parseMoney(s){
 const m=faToEn(s).match(/\\d{4,12}/);
 return m ? Number(m[0]) : null;
}

async function fetchHomeServize(){
 const url="https://homeservize.com/sound-system-rental";
 const html=await (await fetch(url,{headers:{"user-agent":"Mozilla/5.0"}})).text();
 const $=cheerio.load(html);
 const text=$("body").text().replace(/\\s+/g," ");
 const out=[];
 const patterns=[
  [/اجاره باند EV TX1152.*?(\\d[\\d٬,]*) تومان/i,"p8"],
  [/اجاره میکسر دیجیتال.*?(\\d[\\d٬,]*) تومان/i,null],
  [/کرایه آمپلی فایر.*?(\\d[\\d٬,]*) تومان/i,null],
  [/کرایه میکروفن بی سیم.*?(\\d[\\d٬,]*) تومان/i,null]
 ];
 for(const [re,pid] of patterns){
   const m=text.match(re); if(m && pid) out.push({productId:pid,price:parseMoney(m[1]),raw:m[0]});
 }
 return out;
}

async function syncPrices(){
 const run=db.prepare("INSERT INTO sync_runs(started_at,status) VALUES (?,?)").run(new Date().toISOString(),"running");
 try{
   const found=await fetchHomeServize();
   const update=db.prepare(`UPDATE products SET current_daily_rental_price_toman=?,price_status='verified-reference',price_source='HomeServize',price_updated_at=? WHERE id=?`);
   const hist=db.prepare(`INSERT INTO price_history(product_id,source_id,price_toman,fetched_at,status,raw_reference) VALUES (?,?,?,?,?,?)`);
   const source=db.prepare("SELECT id FROM price_sources WHERE name='HomeServize'").get();
   for(const x of found){
     if(x.price){ update.run(x.price,new Date().toISOString(),x.productId); hist.run(x.productId,source?.id,x.price,new Date().toISOString(),"ok",x.raw); }
   }
   db.prepare("UPDATE sync_runs SET finished_at=?,status='ok',message=? WHERE id=?").run(new Date().toISOString(),`updated ${found.length} mapped prices`,run.lastInsertRowid);
 }catch(e){
   db.prepare("UPDATE sync_runs SET finished_at=?,status='error',message=? WHERE id=?").run(new Date().toISOString(),String(e.message).slice(0,500),run.lastInsertRowid);
 }
}

app.get("/api/products",requireAuth,(req,res)=>{
 const products=db.prepare("SELECT * FROM products ORDER BY featured DESC, name").all();
 res.json({products});
});
app.get("/api/sources",requireAuth,(req,res)=>res.json({sources:db.prepare("SELECT * FROM price_sources").all()}));
app.post("/api/sync",requireAuth,async(req,res)=>{ await syncPrices(); res.json({ok:true}); });
app.get("/api/health",requireAuth,(req,res)=>res.json({ok:true,time:new Date().toISOString()}));

syncPrices();
setInterval(syncPrices,60_000);

app.listen(4000,()=>console.log("Avaye Velayat API running on http://localhost:4000"));
