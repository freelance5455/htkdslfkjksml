
"use strict";

const $ = id => document.getElementById(id);
const board = $("board");
const boardWrap = document.querySelector(".board-wrap");
const chainSvg = $("chainSvg");

const SIZE = 5;
const TOTAL = SIZE * SIZE;

const MERGE_TIME = 300;
const CHAIN_TIME = 300;
const SPAWN_STEP = 35;
const DESTROY_COOLDOWN = 30;
const MAGNET_COOLDOWN = 15;
let magnetCooldown = 0;
let magnetTimer = null;

const DIRECTIONS = [
  [-1,-1], [-1,0], [-1,1],
  [0,-1],          [0,1],
  [1,-1],  [1,0],  [1,1]
];

let cells = [];
let rareCells = new Set();
let frozenCells = new Set();

let abilityMode = null;
let destroyCooldown = 0;
let destroyTimer = null;

let score = 0;
let best = Number(localStorage.getItem("nm_best") || 0);
let soundOn = true;
let busy = false;
let drag = null;
let toastTimer = null;
let gameOver = false;

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

$("best").textContent = best.toLocaleString("id-ID");

/* =========================
   ANGKA DAN BLOK SPESIAL
========================= */

function randomValue() {
  const r = Math.random();

  if (r < 0.48) return 2;
  if (r < 0.78) return 4;
  if (r < 0.92) return 8;
  if (r < 0.975) return 16;
  if (r < 0.995) return 32;
  return 64;
}

function pickRandomIndex(excluded = new Set()) {
  const available = [];

  for (let i = 0; i < TOTAL; i++) {
    if (!excluded.has(i)) available.push(i);
  }

  if (!available.length) return -1;

  return available[Math.floor(Math.random() * available.length)];
}

function fillBoard() {
  cells = Array.from({ length: TOTAL }, randomValue);

  rareCells.clear();
  frozenCells.clear();

  // Satu blok emas dan dua blok es pada awal permainan.
  const rare = pickRandomIndex();
  if (rare >= 0) rareCells.add(rare);

  for (let i = 0; i < 2; i++) {
    const frozen = pickRandomIndex(rareCells);

    if (frozen >= 0) frozenCells.add(frozen);
  }
}

function addRandomSpecial(index) {
  if (index < 0 || index >= TOTAL) return;

  // Batasi jumlah blok spesial agar papan tidak terlalu sulit.
  if (rareCells.size < 3 && Math.random() < 0.035) {
    rareCells.add(index);
    frozenCells.delete(index);
    return;
  }

  if (frozenCells.size < 4 && Math.random() < 0.055) {
    frozenCells.add(index);
    rareCells.delete(index);
  }
}

function randomCells() {
  if (busy) return;

  gameOver = false;
  drag = null;
  abilityMode = null;

  fillBoard();
  score = 0;

  updateScore();
  renderBoard(true);

  $("chainBadge").textContent = "CHAIN ×1";
  updateStatus("Pilih angka yang sama, lalu tarik!");

  hideGameOver();
  updateAbilityButtons();
}



function valueClass(value) {
  return "v" + Math.min(value, 2048);
}

function evolutionClass(value) {
  if (value >= 8192) return " evo evo-8192";
  if (value >= 4096) return " evo evo-4096";
  if (value >= 2048) return " evo evo-2048";
  if (value >= 1024) return " evo evo-1024";
  if (value >= 256) return " evo evo-256";
  if (value >= 64) return " evo evo-64";

  return "";
}

/* =========================
   RENDER PAPAN
========================= */

function renderBoard(animate = false, spawnIndices = []) {
  const spawnSet = new Set(spawnIndices);

  for (let i = 0; i < TOTAL; i++) {
    if (cells[i] == null) {
      cells[i] = randomValue();
      addRandomSpecial(i);
    }
  }

  const spawnOrder = new Map();

  spawnIndices.forEach((index, order) => {
    spawnOrder.set(index, order);
  });

  board.innerHTML = cells.map((value, index) => {
    const shouldSpawn = animate || spawnSet.has(index);
    const spawnClass = shouldSpawn ? " spawn" : "";

    let delay = 0;

    if (animate) {
      delay = index * 24;
    } else if (spawnSet.has(index)) {
      delay = (spawnOrder.get(index) || 0) * SPAWN_STEP;
    }

    const delayStyle = shouldSpawn
      ? `style="animation-delay:${delay}ms"`
      : "";

    const specialClass =
      (rareCells.has(index) ? " rare" : "") +
      (frozenCells.has(index) ? " frozen" : "") +
      evolutionClass(value);

    const icons =
      (rareCells.has(index) ? '<span class="special-mark">✦</span>' : "") +
      (frozenCells.has(index) ? '<span class="special-mark">❄</span>' : "");

    return `
      <div class="tile ${valueClass(value)}${specialClass}${spawnClass}"
           data-index="${index}" ${delayStyle}>
        ${icons}
        <span class="tile-number">${value.toLocaleString("id-ID")}</span>
      </div>
    `;
  }).join("");

  drawChain();
}

function updateScore() {
  $("score").textContent = score.toLocaleString("id-ID");
  $("best").textContent = best.toLocaleString("id-ID");
}

function addScore(amount) {
  if (gameOver || amount <= 0) return;

  score += amount;

  if (score > best) {
    best = score;
    localStorage.setItem("nm_best", String(best));
  }

  updateScore();

  const pop = $("scorePop");

  if (pop) {
    pop.textContent = "+" + amount.toLocaleString("id-ID");
    pop.classList.remove("show");
    void pop.offsetWidth;
    pop.classList.add("show");
  }

  const card = $("score").closest(".score-card");

  if (card) {
    card.classList.remove("bump");
    void card.offsetWidth;
    card.classList.add("bump");
  }

  playSound("score");
}

function updateStatus(message) {
  $("status").textContent = message;
}

/* =========================
   AUDIO
========================= */

const soundFiles = {
  merge: "sounds/merge.mp3",
  chain: "sounds/chain.mp3",
  score: "sounds/score.mp3",
  over: "sounds/gameover.mp3",
  connect: "sounds/merge.mp3"
};

function playSound(type) {
  if (!soundOn) return;

  try {
    const sound = new Audio(soundFiles[type]);
    sound.volume = type === "chain" ? 0.7 : 0.45;
    sound.play().catch(() => {});
  } catch (_) {}
}

/* =========================
   TETANGGA DAN JALUR
========================= */

function neighbors(index) {
  const row = Math.floor(index / SIZE);
  const col = index % SIZE;

  return DIRECTIONS.map(([dr, dc]) => {
    const r = row + dr;
    const c = col + dc;

    if (r < 0 || r >= SIZE || c < 0 || c >= SIZE) {
      return -1;
    }

    return r * SIZE + c;
  }).filter(i => i >= 0);
}

function adjacent(a, b) {
  return neighbors(a).includes(b);
}

function getTileCenter(index) {
  const tile = board.querySelector(`[data-index="${index}"]`);
  if (!tile || !boardWrap) return null;

  const tr = tile.getBoundingClientRect();
  const wr = boardWrap.getBoundingClientRect();

  return {
    x: tr.left + tr.width / 2 - wr.left,
    y: tr.top + tr.height / 2 - wr.top
  };
}

function drawChain() {
  if (!chainSvg) return;

  chainSvg.innerHTML = "";

  if (!drag || !drag.path.length) return;

  const points = drag.path.map(getTileCenter).filter(Boolean);

  if (drag.pointer && boardWrap) {
    const rect = boardWrap.getBoundingClientRect();

    points.push({
      x: drag.pointer.x - rect.left,
      y: drag.pointer.y - rect.top
    });
  }

  if (!points.length) return;

  const d = points.map((p, i) =>
    `${i ? "L" : "M"} ${p.x} ${p.y}`
  ).join(" ");

  chainSvg.innerHTML = `
    <path class="chain-glow" d="${d}"></path>
    <path class="chain-line" d="${d}"></path>
  `;
}

function paintPath() {
  board.querySelectorAll(".tile").forEach(tile => {
    tile.classList.remove("path", "path-start", "last-path");
  });

  if (drag) {
    drag.path.forEach((index, order) => {
      const tile = board.querySelector(`[data-index="${index}"]`);
      if (!tile) return;

      tile.classList.add("path");

      if (order === 0) tile.classList.add("path-start");

      if (order === drag.path.length - 1) {
        tile.classList.add("last-path");
      }
    });
  }

  drawChain();
}

function getIndexAtPoint(x, y) {
  const element = document.elementFromPoint(x, y);
  const tile = element?.closest(".tile");

  return tile && board.contains(tile)
    ? Number(tile.dataset.index)
    : -1;
}

/* =========================
   MAGNET DAN HANCURKAN
========================= */

function updateAbilityButtons() {
  const magnetBtn = $("magnetBtn");
  const destroyBtn = $("destroyBtn");
  const cooldownLabel = $("destroyCooldown");

  if (magnetBtn) {
  magnetBtn.disabled = magnetCooldown > 0 || busy || gameOver;
}

const magnetLabel = $("magnetCooldown");

if (magnetLabel) {
  magnetLabel.textContent = magnetCooldown > 0
    ? `Cooldown ${magnetCooldown}s`
    : "Siap digunakan";
}

  if (destroyBtn) {
    destroyBtn.classList.toggle("active", abilityMode === "destroy");
    destroyBtn.disabled = destroyCooldown > 0 || busy || gameOver;
  }

  if (cooldownLabel) {
    cooldownLabel.textContent = destroyCooldown > 0
      ? `Cooldown ${destroyCooldown}s`
      : "Siap digunakan";
  }
}

function startMagnetCooldown() {
  magnetCooldown = MAGNET_COOLDOWN;
  updateAbilityButtons();

  if (magnetTimer) clearInterval(magnetTimer);

  magnetTimer = setInterval(() => {
    magnetCooldown = Math.max(0, magnetCooldown - 1);
    updateAbilityButtons();

    if (magnetCooldown <= 0) {
      clearInterval(magnetTimer);
      magnetTimer = null;
      showToast("Magnet siap digunakan!");
    }
  }, 1000);
}

function cancelAbility(message) {
  abilityMode = null;
  updateAbilityButtons();

  if (message) showToast(message);
}

function toggleMagnet() {
  if (busy || gameOver) return;

  if (abilityMode === "magnet") {
    cancelAbility("Magnet dibatalkan");
    return;
  }

  abilityMode = "magnet";
  updateAbilityButtons();

  updateStatus("MAGNET aktif — sentuh angka yang ingin digabungkan");
  showToast("Pilih angka untuk Magnet");
}

function toggleDestroy() {
  if (busy || gameOver) return;

  if (destroyCooldown > 0) {
    showToast(`Tunggu ${destroyCooldown} detik lagi`);
    return;
  }

  if (abilityMode === "destroy") {
    cancelAbility("Mode hancurkan dibatalkan");
    return;
  }

  abilityMode = "destroy";
  updateAbilityButtons();

  updateStatus("HANCURKAN aktif — sentuh satu blok");
  showToast("Pilih blok yang ingin dihancurkan");
}

function startDestroyCooldown() {
  destroyCooldown = DESTROY_COOLDOWN;
  updateAbilityButtons();

  if (destroyTimer) clearInterval(destroyTimer);

  destroyTimer = setInterval(() => {
    if (destroyCooldown > 0) destroyCooldown--;

    updateAbilityButtons();

    if (destroyCooldown <= 0) {
      clearInterval(destroyTimer);
      destroyTimer = null;
      showToast("Kemampuan Hancurkan siap!");
    }
  }, 1000);
}

async function destroyTileAt(index) {
  if (busy || gameOver || cells[index] == null) return;

  busy = true;
  abilityMode = null;
  updateAbilityButtons();

  const tile = board.querySelector(`[data-index="${index}"]`);

  if (tile) {
    tile.classList.add("destroying");
  }

  playSound("merge");
  updateStatus("Menghancurkan blok...");

  await sleep(350);

  cells[index] = null;
  rareCells.delete(index);
  frozenCells.delete(index);

  thawNearby([index]);

  cells[index] = randomValue();
  addRandomSpecial(index);

  renderBoard(false, [index]);

  startDestroyCooldown();

  busy = false;

  updateStatus("Blok dihancurkan — lanjutkan permainan");
  showToast("Blok berhasil dihancurkan!");

  checkGameOver();
}

function magnetAt(index) {
  if (busy || gameOver) return;

  if (cells[index] == null || frozenCells.has(index)) {
    showToast("Pilih blok biasa, bukan blok es");
    return;
  }

  const value = cells[index];
  const connected = findConnected(index, value);

  abilityMode = null;
  updateAbilityButtons();

  if (!connected.length) {
    updateStatus("Tidak ada angka sama yang terhubung");
    showToast("Magnet tidak menemukan pasangan");
    return;
  }

  showToast(`Magnet menemukan ${connected.length + 1} blok!`);

startMagnetCooldown();
resolveMerge([index, ...connected]);
}

/* =========================
   DRAG INPUT
========================= */

function startDrag(index, event) {
  if (busy || gameOver || cells[index] == null) return;

  if (abilityMode === "destroy") {
    destroyTileAt(index);
    return;
  }

  if (abilityMode === "magnet") {
    magnetAt(index);
    return;
  }

  if (frozenCells.has(index)) {
    showToast("Blok es! Gabungkan blok di dekatnya untuk membebaskannya");
    updateStatus("Blok es belum bisa ditarik");
    return;
  }

  drag = {
    pointerId: event.pointerId,
    base: cells[index],
    path: [index],
    pointer: { x: event.clientX, y: event.clientY }
  };

  paintPath();
  updateStatus("Sambungkan angka " + drag.base);
  $("chainBadge").textContent = "CHAIN ×1";
}

function moveDrag(event) {
  if (!drag || event.pointerId !== drag.pointerId || busy || gameOver) {
    return;
  }

  drag.pointer = { x: event.clientX, y: event.clientY };

  const index = getIndexAtPoint(event.clientX, event.clientY);
  const path = drag.path;
  const last = path[path.length - 1];

  if (index >= 0) {
    if (path.length >= 2 && index === path[path.length - 2]) {
      path.pop();
    } else if (
      index !== last &&
      !path.includes(index) &&
      adjacent(last, index) &&
      cells[index] === drag.base &&
      !frozenCells.has(index)
    ) {
      path.push(index);
      playSound("connect");
    }
  }

  $("chainBadge").textContent = "CHAIN ×" + path.length;
  paintPath();
}

function findConnected(index, value) {
  const found = [];
  const seen = new Set([index]);
  const queue = neighbors(index).filter(i =>
    cells[i] === value && !frozenCells.has(i)
  );

  while (queue.length) {
    const current = queue.shift();

    if (
      seen.has(current) ||
      cells[current] !== value ||
      frozenCells.has(current)
    ) {
      continue;
    }

    seen.add(current);
    found.push(current);

    for (const next of neighbors(current)) {
      if (
        !seen.has(next) &&
        cells[next] === value &&
        !frozenCells.has(next)
      ) {
        queue.push(next);
      }
    }
  }

  return found;
}

/* =========================
   ANIMASI DAN CHAIN
========================= */

function animateTiles(indices, cls) {
  indices.forEach(index => {
    const tile = board.querySelector(`[data-index="${index}"]`);
    if (!tile) return;

    tile.classList.remove(cls);
    void tile.offsetWidth;
    tile.classList.add(cls);
  });
}

function triggerChainBurst(indices) {
  animateTiles(indices, "chain-hit");

  if (!boardWrap || !indices.length) return;

  const points = indices.map(getTileCenter).filter(Boolean);
  if (!points.length) return;

  const x = points.reduce((sum, p) => sum + p.x, 0) / points.length;
  const y = points.reduce((sum, p) => sum + p.y, 0) / points.length;

  const burst = document.createElement("div");
  burst.className = "chain-burst";
  burst.style.left = `${x}px`;
  burst.style.top = `${y}px`;

  const colors = [
    "#ffca58", "#ff6b6b", "#67e8f9",
    "#a78bfa", "#7cf2b0"
  ];

  burst.innerHTML = `
    <div class="chain-ring"></div>
    <div class="chain-ring ring-second"></div>
    ${Array.from({ length: 12 }, (_, i) => {
      const angle = i * 30;
      const distance = 28 + (i % 3) * 12;
      const color = colors[i % colors.length];

      return `
        <i class="chain-particle"
          style="
            --angle:${angle}deg;
            --distance:${distance}px;
            --particle-color:${color};
          "></i>
      `;
    }).join("")}
  `;

  boardWrap.appendChild(burst);

  burst.addEventListener("animationend", () => burst.remove());
  setTimeout(() => burst.remove(), 650);
}

/* =========================
   BLOK ES DAN ISI ULANG
========================= */

// Blok es di dekat blok yang baru dihancurkan akan mencair.
function thawNearby(clearedIndices) {
  const thawed = [];

  for (const clearedIndex of clearedIndices) {
    for (const neighbor of neighbors(clearedIndex)) {
      if (frozenCells.has(neighbor) && cells[neighbor] != null) {
        frozenCells.delete(neighbor);
        thawed.push(neighbor);
      }
    }
  }

  if (thawed.length) {
    showToast("❄ Blok es di dekatnya telah mencair!");
  }

  return thawed;
}

function refillEmptyCells() {
  const spawned = [];

  for (let i = 0; i < TOTAL; i++) {
    if (cells[i] == null) {
      cells[i] = randomValue();
      rareCells.delete(i);
      frozenCells.delete(i);
      addRandomSpecial(i);
      spawned.push(i);
    }
  }

  return spawned;
}

function flashBoard() {
  const flash = $("boardFlash");
  if (!flash) return;

  flash.classList.remove("active");
  void flash.offsetWidth;
  flash.classList.add("active");
}

/* =========================
   MERGE UTAMA
========================= */

async function resolveMerge(path) {
  if (path.length < 2 || busy || gameOver) return;

  // Pastikan seluruh blok pada jalur masih sama dan tidak membeku.
  const base = cells[path[0]];

  if (
    base == null ||
    path.some(index =>
      cells[index] !== base || frozenCells.has(index)
    )
  ) {
    return;
  }

  busy = true;
  drag = null;
  drawChain();

  try {
    const anchor = path[path.length - 1];
    const pairs = Math.max(1, path.length - 1);
    let result = base * Math.pow(2, pairs);

    // Rare block memberi bonus jika ikut bergabung.
    const rareBonus = path.some(index => rareCells.has(index));

    animateTiles(path, "merging");
    playSound("merge");
    updateStatus("BLOCK MENYATU...");

    await sleep(MERGE_TIME);

    path.forEach(index => {
      cells[index] = null;
      rareCells.delete(index);
      frozenCells.delete(index);
    });

    // Blok es yang berdekatan dengan blok yang di-merge akan mencair.
    thawNearby(path);

    cells[anchor] = result;

    let earned = result + Math.max(0, path.length - 2) * base;

    if (rareBonus) {
      earned += result * 2;
      showToast("✦ RARE BONUS! Skor tambahan!");
    }

    addScore(earned);

    let chainCount = 1;

    for (let count = 0; count < 15; count++) {
      const connected = findConnected(anchor, result);

      if (!connected.length) break;

      chainCount++;

      $("chainBadge").textContent = "CHAIN ×" + chainCount;
      updateStatus("CHAIN REACTION ×" + chainCount);

      triggerChainBurst([anchor, ...connected]);
      playSound("chain");

      await sleep(CHAIN_TIME);

      const chainRare = connected.some(index => rareCells.has(index));

      connected.forEach(index => {
        cells[index] = null;
        rareCells.delete(index);
        frozenCells.delete(index);
      });

      thawNearby(connected);

      result *= 2;
      cells[anchor] = result;

      let chainPoints = result * chainCount;

      if (chainRare) {
        chainPoints += result * 2;
        showToast("✦ RARE CHAIN BONUS!");
      }

      addScore(chainPoints);
    }

    const spawned = refillEmptyCells();

    renderBoard(false, spawned);
    flashBoard();

    const resultTile = board.querySelector(
      `[data-index="${anchor}"]`
    );

    if (resultTile) resultTile.classList.add("result-tile");

    $("chainBadge").textContent = "CHAIN ×" + chainCount;

    updateStatus(
      chainCount > 1
        ? "CHAIN BONUS!"
        : "Cari kombinasi berikutnya!"
    );

  } catch (error) {
    console.error("Merge error:", error);

    refillEmptyCells();
    renderBoard();

    updateStatus("Merge error — coba lagi.");
  } finally {
    busy = false;
    updateAbilityButtons();
  }

  checkGameOver();
}

/* =========================
   GAME OVER
========================= */

function hasValidMove() {
  return cells.some((value, index) => {
    if (value == null || frozenCells.has(index)) return false;

    return neighbors(index).some(i =>
      cells[i] === value && !frozenCells.has(i)
    );
  });
}

function createGameOverUI() {
  if ($("gameOverScreen")) return;

  const overlay = document.createElement("div");

  overlay.id = "gameOverScreen";
  overlay.className = "nm-gameover hidden";

  overlay.innerHTML = `
    <div class="nm-over-card">
      <div class="nm-over-icon">✦</div>
      <div class="nm-over-kicker">SESSION COMPLETE</div>
      <h2>GAME OVER</h2>
      <p class="nm-over-sub">Tidak ada kombinasi yang tersedia.</p>

      <div class="nm-over-stats">
        <div>
          <span>YOUR SCORE</span>
          <strong id="overScore">0</strong>
        </div>
        <div>
          <span>BEST SCORE</span>
          <strong id="overBest">0</strong>
        </div>
      </div>

      <button id="overRetry" class="nm-over-primary">
        ↻ &nbsp; MAIN LAGI
      </button>
    </div>
  `;

  document.body.appendChild(overlay);

  $("overRetry").addEventListener("click", () => {
    if (busy) return;

    randomCells();
    showToast("Game baru dimulai!");
  });
}

function checkGameOver() {
  if (busy || gameOver || hasValidMove()) return;

  gameOver = true;
  drag = null;
  abilityMode = null;

  paintPath();
  updateAbilityButtons();

  playSound("over");
  createGameOverUI();

  $("overScore").textContent = score.toLocaleString("id-ID");
  $("overBest").textContent = best.toLocaleString("id-ID");

  $("gameOverScreen").classList.remove("hidden");

  updateStatus("Game over — tekan Main Lagi untuk mengulang.");
}

function hideGameOver() {
  const overlay = $("gameOverScreen");

  if (overlay) overlay.classList.add("hidden");
}

function showToast(message) {
  const toast = $("toast");
  if (!toast) return;

  toast.textContent = message;
  toast.classList.add("show");

  clearTimeout(toastTimer);

  toastTimer = setTimeout(() => {
    toast.classList.remove("show");
  }, 2200);
}

/* =========================
   EVENT PAPAN
========================= */

board.addEventListener("pointerdown", event => {
  const tile = event.target.closest(".tile");

  if (!tile || gameOver || busy) return;

  event.preventDefault();

  startDrag(Number(tile.dataset.index), event);
});

document.addEventListener("pointermove", event => {
  if (!drag) return;

  event.preventDefault();
  moveDrag(event);
}, { passive: false });

document.addEventListener("pointerup", event => {
  if (!drag || event.pointerId !== drag.pointerId) return;

  const path = [...drag.path];

  drag = null;
  paintPath();

  if (gameOver) return;

  if (path.length >= 2) {
    resolveMerge(path);
  } else {
    updateStatus("Sambungkan minimal dua angka sama");
    $("chainBadge").textContent = "CHAIN ×1";
  }
});

document.addEventListener("pointercancel", event => {
  if (!drag || event.pointerId !== drag.pointerId) return;

  drag = null;
  paintPath();

  updateStatus("Tarikan dibatalkan");
});

/* =========================
   TOMBOL SUARA
========================= */

$("soundBtn").addEventListener("click", () => {
  soundOn = !soundOn;

  $("soundBtn").textContent = soundOn ? "♫" : "♩";
  $("soundBtn").style.opacity = soundOn ? "1" : ".5";

  if (soundOn) playSound("connect");

  showToast(soundOn ? "Suara aktif" : "Suara dimatikan");
});

/* =========================
   TOMBOL KEMAMPUAN
========================= */

const magnetBtn = $("magnetBtn");
const destroyBtn = $("destroyBtn");

if (magnetBtn) {
  magnetBtn.addEventListener("click", toggleMagnet);
} else {
  console.warn("Tombol magnetBtn belum ada di HTML.");
}

if (destroyBtn) {
  destroyBtn.addEventListener("click", toggleDestroy);
} else {
  console.warn("Tombol destroyBtn belum ada di HTML.");
}

/* =========================
   MENU
========================= */

$("menuBtn").addEventListener("click", () => {
  $("menuOverlay").classList.remove("hidden");
});

$("closeMenu").addEventListener("click", () => {
  $("menuOverlay").classList.add("hidden");
});

$("continueBtn").addEventListener("click", () => {
  $("menuOverlay").classList.add("hidden");

  if (gameOver) {
    showToast("Game over — tekan Main Lagi");
  }
});

$("newGameBtn").addEventListener("click", () => {
  if (busy) {
    showToast("Tunggu merge selesai dulu");
    return;
  }

  $("menuOverlay").classList.add("hidden");
  randomCells();
  showToast("Game baru dimulai");
});

$("restartBtn").addEventListener("click", () => {
  if (busy) {
    showToast("Tunggu merge selesai dulu");
    return;
  }
  
    $("menuOverlay").classList.add("hidden");
  randomCells();
  showToast("Game baru dimulai");
});

/* =========================
   MULAI GAME
========================= */

createGameOverUI();
randomCells();
updateAbilityButtons();

// ===== BACKSOUND MP3 =====
const bgm = new Audio("sounds/bgm.mp3");
bgm.loop = true;
bgm.volume = 0.95;

let bgmOn = false;

const bgmBtn = document.getElementById("bgmBtn");

if (bgmBtn) {
  bgmBtn.textContent = "🎵";

  bgmBtn.addEventListener("click", async () => {
    if (bgmOn) {
      bgm.pause();
      bgmOn = false;
      bgmBtn.textContent = "🔇";
    } else {
      try {
        await bgm.play();
        bgmOn = true;
        bgmBtn.textContent = "🎵";
      } catch (error) {
        console.log("Backsound gagal diputar:", error);
      }
    }
  });
}

// Saat musik dinyalakan:
bgmBtn.classList.add("music-playing");

// Saat musik dimatikan:
bgmBtn.classList.remove("music-playing");