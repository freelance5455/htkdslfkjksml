import { eventBus } from '@/core/EventBus';
import { settings } from '@/core/SettingsManager';

export type SfxName =
  | 'hover'
  | 'click'
  | 'back'
  | 'toggle'
  | 'sun'
  | 'shoot'
  | 'splat'
  | 'hit'
  | 'armor'
  | 'metal'
  | 'error'
  | 'whoosh'
  | 'plant'
  | 'dig'
  | 'chomp'
  | 'gulp'
  | 'groan'
  | 'explode'
  | 'fuse'
  | 'mower'
  | 'siren'
  | 'pop'
  | 'ready'
  | 'go'
  | 'victory'
  | 'lose';

export type MusicTrack = 'menu' | 'battle';

interface ToneOptions {
  freq: number;
  to?: number;
  dur: number;
  type?: OscillatorType;
  vol: number;
  delay?: number;
}

interface TrackDef {
  melody: (number | null)[];
  bass: number[];
  bpm: number;
  lead: OscillatorType;
  leadVol: number;
}

const midiToFreq = (m: number) => 440 * Math.pow(2, (m - 69) / 12);

// Оригинальные мелодии-заглушки: 4 такта по 8 восьмых.
const _ = null;
const TRACKS: Record<MusicTrack, TrackDef> = {
  // C – Am – F – G
  menu: {
    melody: [
      72, _, 76, 79, 77, 76, 74, _,
      72, _, 69, 72, 76, _, 74, 72,
      69, _, 72, 77, 76, 74, 72, _,
      71, 74, 79, _, 77, 74, 71, _,
    ],
    bass: [48, 45, 41, 43],
    bpm: 112,
    lead: 'triangle',
    leadVol: 0.22,
  },
  // Am – F – C – E: тревожнее и быстрее
  battle: {
    melody: [
      69, _, 72, _, 76, 74, 72, _,
      69, _, 65, _, 69, 72, 74, _,
      72, _, 76, _, 79, 77, 76, 74,
      71, _, 68, _, 71, 74, 76, _,
    ],
    bass: [45, 41, 48, 40],
    bpm: 128,
    lead: 'square',
    leadVol: 0.09,
  },
};

const LOOKAHEAD_SEC = 0.12;

/** Минимальный интервал между одинаковыми звуками, чтобы толпа зомби не превращалась в шум. */
const THROTTLE: Partial<Record<SfxName, number>> = {
  hover: 0.03,
  shoot: 0.05,
  hit: 0.035,
  armor: 0.05,
  metal: 0.06,
  chomp: 0.09,
  groan: 2.2,
  sun: 0.05,
};

/**
 * Процедурный звук на Web Audio: эффекты и музыка синтезируются на лету,
 * поэтому пока не нужны аудиофайлы. Позже сюда добавится воспроизведение ассетов.
 */
class AudioManager {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private musicBus: GainNode | null = null;
  private sfxBus: GainNode | null = null;
  private noise: AudioBuffer | null = null;
  private readonly lastPlayed = new Map<SfxName, number>();

  private track: MusicTrack = 'menu';
  private tempo = 1;
  private musicWanted = false;
  private schedulerId: number | null = null;
  private nextStepTime = 0;
  private step = 0;

  constructor() {
    eventBus.on('settings:changed', () => this.applyVolumes());
  }

  /** Браузеры разрешают звук только после жеста пользователя — вызывается на первый клик/клавишу. */
  unlock(): void {
    if (!this.ctx) {
      const Ctor =
        window.AudioContext ?? (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!Ctor) return;
      this.ctx = new Ctor();
      this.master = this.ctx.createGain();
      this.master.connect(this.ctx.destination);
      this.musicBus = this.ctx.createGain();
      this.musicBus.connect(this.master);
      this.sfxBus = this.ctx.createGain();
      this.sfxBus.connect(this.master);
      this.noise = this.createNoiseBuffer(this.ctx);
      this.applyVolumes();
    }
    if (this.ctx.state === 'suspended') void this.ctx.resume();
    if (this.musicWanted) this.startScheduler();
  }

  playMusic(track: MusicTrack = 'menu'): void {
    if (this.track !== track) {
      this.track = track;
      this.step = 0;
    }
    this.musicWanted = true;
    if (this.ctx) this.startScheduler();
  }

  stopMusic(): void {
    this.musicWanted = false;
    if (this.schedulerId !== null) window.clearInterval(this.schedulerId);
    this.schedulerId = null;
  }

  /** Ускорение музыки, например на финальной волне. */
  setTempo(multiplier: number): void {
    this.tempo = multiplier;
  }

  sfx(name: SfxName): void {
    if (!this.ctx || !this.sfxBus) return;
    const now = this.ctx.currentTime;
    const gap = THROTTLE[name];
    if (gap !== undefined) {
      const last = this.lastPlayed.get(name) ?? -Infinity;
      if (now - last < gap) return;
      this.lastPlayed.set(name, now);
    }
    switch (name) {
      case 'hover':
        this.tone({ freq: 1100, to: 1400, dur: 0.045, vol: 0.05 });
        break;
      case 'click':
        this.tone({ freq: 620, to: 310, dur: 0.1, type: 'triangle', vol: 0.28 });
        this.tone({ freq: 1240, dur: 0.04, vol: 0.08 });
        break;
      case 'back':
        this.tone({ freq: 480, to: 240, dur: 0.12, type: 'triangle', vol: 0.24 });
        break;
      case 'toggle':
        this.tone({ freq: 820, dur: 0.05, type: 'square', vol: 0.06 });
        this.tone({ freq: 1230, dur: 0.05, type: 'square', vol: 0.05, delay: 0.05 });
        break;
      case 'sun':
        this.tone({ freq: 880, dur: 0.14, vol: 0.2 });
        this.tone({ freq: 1320, dur: 0.18, vol: 0.17, delay: 0.07 });
        this.tone({ freq: 1760, dur: 0.24, vol: 0.12, delay: 0.14 });
        break;
      case 'shoot':
        this.tone({ freq: 260, to: 140, dur: 0.07, type: 'square', vol: 0.045 });
        this.noiseBurst(0.04, 0.05, 1200, 'lowpass');
        break;
      case 'splat':
        this.noiseBurst(0.12, 0.18, 900, 'lowpass');
        this.tone({ freq: 180, to: 60, dur: 0.12, vol: 0.2 });
        break;
      case 'hit':
        this.noiseBurst(0.06, 0.1, 1400, 'lowpass');
        this.tone({ freq: 210, to: 110, dur: 0.06, vol: 0.12 });
        break;
      case 'armor':
        this.tone({ freq: 700, to: 500, dur: 0.05, type: 'square', vol: 0.05 });
        this.noiseBurst(0.04, 0.06, 2000, 'bandpass');
        break;
      case 'metal':
        this.tone({ freq: 1350, dur: 0.12, type: 'triangle', vol: 0.09 });
        this.tone({ freq: 2050, dur: 0.1, type: 'triangle', vol: 0.05 });
        break;
      case 'error':
        this.tone({ freq: 190, dur: 0.09, type: 'square', vol: 0.1 });
        this.tone({ freq: 140, dur: 0.14, type: 'square', vol: 0.1, delay: 0.1 });
        break;
      case 'whoosh':
        this.noiseBurst(0.28, 0.12, 1400, 'bandpass');
        break;
      case 'plant':
        this.noiseBurst(0.14, 0.22, 600, 'lowpass');
        this.tone({ freq: 160, to: 80, dur: 0.14, vol: 0.28 });
        break;
      case 'dig':
        this.noiseBurst(0.18, 0.22, 500, 'bandpass');
        this.tone({ freq: 220, to: 120, dur: 0.12, type: 'triangle', vol: 0.12 });
        break;
      case 'chomp':
        this.noiseBurst(0.06, 0.12, 1100, 'bandpass');
        this.tone({ freq: 320, to: 180, dur: 0.05, type: 'square', vol: 0.04 });
        break;
      case 'gulp':
        this.tone({ freq: 300, to: 90, dur: 0.25, vol: 0.25 });
        break;
      case 'groan':
        this.tone({ freq: 118, to: 86, dur: 0.9, type: 'sawtooth', vol: 0.035 });
        this.tone({ freq: 123, to: 92, dur: 0.85, type: 'sawtooth', vol: 0.03, delay: 0.04 });
        break;
      case 'explode':
        this.noiseBurst(0.9, 0.55, 520, 'lowpass');
        this.tone({ freq: 95, to: 30, dur: 0.8, vol: 0.5 });
        break;
      case 'fuse':
        this.tone({ freq: 400, to: 1200, dur: 0.9, type: 'square', vol: 0.04 });
        break;
      case 'mower':
        this.noiseBurst(0.7, 0.25, 320, 'lowpass');
        this.tone({ freq: 70, to: 95, dur: 0.7, type: 'sawtooth', vol: 0.08 });
        break;
      case 'siren':
        for (let i = 0; i < 2; i++) {
          this.tone({ freq: 560, to: 880, dur: 0.45, type: 'square', vol: 0.06, delay: i * 0.9 });
          this.tone({ freq: 880, to: 560, dur: 0.45, type: 'square', vol: 0.06, delay: i * 0.9 + 0.45 });
        }
        break;
      case 'pop':
        this.tone({ freq: 500, to: 950, dur: 0.09, vol: 0.15 });
        break;
      case 'ready':
        this.tone({ freq: 523, dur: 0.22, type: 'triangle', vol: 0.25 });
        break;
      case 'go':
        this.tone({ freq: 784, dur: 0.45, type: 'triangle', vol: 0.3 });
        this.tone({ freq: 1046, dur: 0.45, type: 'triangle', vol: 0.18 });
        break;
      case 'victory':
        [72, 76, 79, 84].forEach((m, i) => this.tone({ freq: midiToFreq(m), dur: 0.22, type: 'triangle', vol: 0.28, delay: i * 0.13 }));
        this.tone({ freq: midiToFreq(88), dur: 0.9, type: 'triangle', vol: 0.25, delay: 0.55 });
        this.tone({ freq: midiToFreq(84), dur: 0.9, type: 'sine', vol: 0.2, delay: 0.55 });
        break;
      case 'lose':
        [67, 63, 60, 55].forEach((m, i) => this.tone({ freq: midiToFreq(m), dur: 0.5, type: 'triangle', vol: 0.26, delay: i * 0.38 }));
        break;
    }
  }

  private applyVolumes(): void {
    if (!this.ctx || !this.master || !this.musicBus || !this.sfxBus) return;
    const s = settings.get();
    const now = this.ctx.currentTime;
    this.master.gain.setTargetAtTime(s.muted ? 0 : 1, now, 0.05);
    this.musicBus.gain.setTargetAtTime(s.musicVolume * 0.32, now, 0.05);
    this.sfxBus.gain.setTargetAtTime(s.sfxVolume, now, 0.05);
  }

  private tone({ freq, to, dur, type = 'sine', vol, delay = 0 }: ToneOptions): void {
    if (!this.ctx || !this.sfxBus) return;
    this.scheduleTone(this.ctx.currentTime + delay, freq, to, dur, type, vol, this.sfxBus);
  }

  private scheduleTone(
    time: number,
    freq: number,
    to: number | undefined,
    dur: number,
    type: OscillatorType,
    vol: number,
    bus: GainNode,
  ): void {
    const ctx = this.ctx!;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, time);
    if (to !== undefined) osc.frequency.exponentialRampToValueAtTime(to, time + dur);
    gain.gain.setValueAtTime(0.0001, time);
    gain.gain.exponentialRampToValueAtTime(vol, time + 0.008);
    gain.gain.exponentialRampToValueAtTime(0.0001, time + dur);
    osc.connect(gain).connect(bus);
    osc.start(time);
    osc.stop(time + dur + 0.02);
  }

  private noiseBurst(dur: number, vol: number, filterFreq: number, filterType: BiquadFilterType): void {
    if (!this.ctx || !this.sfxBus) return;
    this.scheduleNoise(this.ctx.currentTime, dur, vol, filterFreq, filterType, this.sfxBus);
  }

  private scheduleNoise(
    time: number,
    dur: number,
    vol: number,
    filterFreq: number,
    filterType: BiquadFilterType,
    bus: GainNode,
  ): void {
    const ctx = this.ctx!;
    if (!this.noise) return;
    const src = ctx.createBufferSource();
    src.buffer = this.noise;
    const filter = ctx.createBiquadFilter();
    filter.type = filterType;
    filter.frequency.value = filterFreq;
    const gain = ctx.createGain();
    gain.gain.setValueAtTime(vol, time);
    gain.gain.exponentialRampToValueAtTime(0.0001, time + dur);
    src.connect(filter).connect(gain).connect(bus);
    src.start(time);
    src.stop(time + dur + 0.02);
  }

  private createNoiseBuffer(ctx: AudioContext): AudioBuffer {
    const buffer = ctx.createBuffer(1, ctx.sampleRate, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < data.length; i++) data[i] = Math.random() * 2 - 1;
    return buffer;
  }

  private startScheduler(): void {
    if (!this.ctx || this.schedulerId !== null) return;
    this.nextStepTime = this.ctx.currentTime + 0.1;
    this.schedulerId = window.setInterval(() => this.scheduleMusic(), 25);
  }

  private scheduleMusic(): void {
    const ctx = this.ctx;
    const bus = this.musicBus;
    if (!ctx || !bus) return;
    // После сна вкладки не играем накопившиеся ноты пачкой.
    if (this.nextStepTime < ctx.currentTime - 0.2) this.nextStepTime = ctx.currentTime + 0.05;

    const track = TRACKS[this.track];
    const stepSec = 60 / (track.bpm * this.tempo) / 2;
    while (this.nextStepTime < ctx.currentTime + LOOKAHEAD_SEC) {
      const t = this.nextStepTime;
      const s = this.step % track.melody.length;
      const inBar = s % 8;
      const note = track.melody[s];
      if (note !== null) this.scheduleTone(t, midiToFreq(note), undefined, stepSec * 1.6, track.lead, track.leadVol, bus);
      if (inBar % 2 === 0) {
        const root = track.bass[Math.floor(s / 8)];
        const bassNote = inBar % 4 === 0 ? root : root + 7;
        this.scheduleTone(t, midiToFreq(bassNote), undefined, stepSec * 1.8, 'sine', 0.35, bus);
      }
      if (inBar === 0 || inBar === 4) this.scheduleTone(t, 120, 45, 0.12, 'sine', 0.3, bus);
      if (inBar === 2 || inBar === 6) this.scheduleNoise(t, 0.05, 0.05, 7000, 'highpass', bus);
      if (this.track === 'battle' && inBar % 2 === 1) this.scheduleNoise(t, 0.03, 0.025, 9000, 'highpass', bus);

      this.nextStepTime += stepSec;
      this.step = (this.step + 1) % track.melody.length;
    }
  }
}

export const audio = new AudioManager();
