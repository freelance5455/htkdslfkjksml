import Phaser from 'phaser';
import { GAME_HEIGHT } from '@/config/constants';
import { BOARD, BOARD_BOTTOM, BOARD_RIGHT, WORLD_WIDTH } from '@/game/Board';
import { mulberry32 } from '@/utils/random';
import { circle, doubleStroke, ellipse, linearGradient, makeCanvasTexture, radialGradient, roundRect } from '../canvas';
import { Tex } from '../TextureKeys';

const INK = '#3b2a18';
const WHITE = '#fff8e7';
const HOUSE_W = 178;

function bush(ctx: CanvasRenderingContext2D, x: number, y: number, r: number): void {
  ctx.fillStyle = '#2c6e1c';
  circle(ctx, x, y, r);
  ctx.fill();
  ctx.fillStyle = '#3d8a28';
  circle(ctx, x - r * 0.25, y - r * 0.25, r * 0.7);
  ctx.fill();
  ctx.fillStyle = 'rgba(190,240,140,0.22)';
  circle(ctx, x - r * 0.35, y - r * 0.45, r * 0.3);
  ctx.fill();
}

function drawHouse(ctx: CanvasRenderingContext2D, h: number): void {
  ctx.fillStyle = linearGradient(ctx, 0, 0, HOUSE_W, 0, ['#c7b999', '#eadfc6']);
  ctx.fillRect(0, 0, HOUSE_W, h);
  ctx.fillStyle = 'rgba(110,85,55,0.22)';
  for (let y = 10; y < h; y += 20) ctx.fillRect(0, y, HOUSE_W - 12, 2);

  // окно
  const wx = 40;
  const wy = 128;
  const ww = 92;
  const wh = 100;
  ctx.fillStyle = '#fffaf0';
  roundRect(ctx, wx - 7, wy - 7, ww + 14, wh + 14, 6);
  ctx.fill();
  ctx.fillStyle = linearGradient(ctx, 0, wy, 0, wy + wh, ['#c4e8ff', '#6db3e3']);
  ctx.fillRect(wx, wy, ww, wh);
  ctx.fillStyle = 'rgba(255,255,255,0.45)';
  ctx.beginPath();
  ctx.moveTo(wx + 8, wy + wh - 10);
  ctx.lineTo(wx + ww * 0.5, wy + 6);
  ctx.lineTo(wx + ww * 0.66, wy + 6);
  ctx.lineTo(wx + 22, wy + wh - 10);
  ctx.fill();
  ctx.fillStyle = '#fffaf0';
  ctx.fillRect(wx + ww / 2 - 3, wy, 6, wh);
  ctx.fillRect(wx, wy + wh / 2 - 3, ww, 6);
  ctx.strokeStyle = '#8a7a5a';
  ctx.lineWidth = 2;
  ctx.strokeRect(wx - 7, wy - 7, ww + 14, wh + 14);

  // дверь
  roundRect(ctx, 46, 300, 96, 178, 8);
  ctx.fillStyle = linearGradient(ctx, 0, 300, 0, 478, ['#a0602e', '#6e3a18']);
  ctx.fill();
  ctx.strokeStyle = '#3b2410';
  ctx.lineWidth = 3;
  ctx.stroke();
  ctx.strokeStyle = 'rgba(0,0,0,0.28)';
  ctx.lineWidth = 2;
  for (const [x, y] of [[58, 316], [98, 316], [58, 398], [98, 398]]) ctx.strokeRect(x, y, 32, 68);
  ctx.fillStyle = '#f2c14e';
  circle(ctx, 130, 394, 5);
  ctx.fill();

  // крыльцо и фундамент
  ctx.fillStyle = '#bdb5a4';
  ctx.fillRect(30, 478, 140, 16);
  ctx.fillStyle = '#a39a88';
  ctx.fillRect(22, 494, 156, 18);
  ctx.fillStyle = '#8f8676';
  ctx.fillRect(0, h - 42, HOUSE_W, 42);

  // угол дома
  ctx.fillStyle = '#fffaf0';
  ctx.fillRect(HOUSE_W - 14, 0, 14, h);
  ctx.fillStyle = 'rgba(0,0,0,0.18)';
  ctx.fillRect(HOUSE_W - 2, 0, 3, h);
}

function drawStreet(ctx: CanvasRenderingContext2D, w: number, h: number, rnd: () => number): void {
  const sx = BOARD_RIGHT;
  ctx.fillStyle = '#d3cdbf';
  ctx.fillRect(sx, 0, 84, h);
  ctx.strokeStyle = 'rgba(0,0,0,0.15)';
  ctx.lineWidth = 2;
  for (let y = 0; y < h; y += 58) {
    ctx.beginPath();
    ctx.moveTo(sx, y);
    ctx.lineTo(sx + 84, y);
    ctx.stroke();
  }
  ctx.fillStyle = '#4f9d30';
  for (let y = 0; y < h; y += 9) {
    ctx.beginPath();
    ctx.moveTo(sx, y);
    ctx.lineTo(sx + 7 + rnd() * 5, y + 4);
    ctx.lineTo(sx, y + 9);
    ctx.fill();
  }
  ctx.fillStyle = '#a49e91';
  ctx.fillRect(sx + 84, 0, 12, h);
  ctx.fillStyle = 'rgba(255,255,255,0.25)';
  ctx.fillRect(sx + 84, 0, 3, h);

  const ax = sx + 96;
  ctx.fillStyle = '#56595f';
  ctx.fillRect(ax, 0, w - ax, h);
  for (let i = 0; i < 3000; i++) {
    ctx.fillStyle = rnd() > 0.5 ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.12)';
    ctx.fillRect(ax + rnd() * (w - ax), rnd() * h, 2, 2);
  }
  const cx = ax + (w - ax) / 2;
  ctx.fillStyle = '#f2c84b';
  for (let y = 10; y < h; y += 96) ctx.fillRect(cx - 5, y, 10, 50);
}

function drawFlowerBed(ctx: CanvasRenderingContext2D, h: number, rnd: () => number): void {
  const y0 = BOARD_BOTTOM + 6;
  ctx.fillStyle = linearGradient(ctx, 0, y0, 0, h, ['#6d4a29', '#4b311b']);
  ctx.fillRect(HOUSE_W, y0, BOARD_RIGHT - HOUSE_W, h - y0);
  ctx.fillStyle = '#b9a68a';
  for (let x = HOUSE_W; x < BOARD_RIGHT; x += 30) {
    roundRect(ctx, x + 1, y0 - 5, 28, 10, 3);
    ctx.fill();
  }
  const colors = ['#ff6b8a', '#ffd23f', '#ffffff', '#b58cff', '#ff8a3d'];
  for (let x = HOUSE_W + 22; x < BOARD_RIGHT - 10; x += 24 + rnd() * 16) {
    const fy = y0 + 28 + rnd() * 44;
    ctx.strokeStyle = '#3d8a28';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(x, fy + 16);
    ctx.lineTo(x, fy);
    ctx.stroke();
    ctx.fillStyle = colors[Math.floor(rnd() * colors.length)];
    for (let i = 0; i < 5; i++) {
      const a = (i / 5) * Math.PI * 2;
      circle(ctx, x + Math.cos(a) * 5, fy + Math.sin(a) * 5, 4.5);
      ctx.fill();
    }
    ctx.fillStyle = '#f5b500';
    circle(ctx, x, fy, 3);
    ctx.fill();
  }
}

/** Фон уровня: дом, лужайка (неактивные линии — голая земля), клумба и улица. */
export function ensureGameBackground(tm: Phaser.Textures.TextureManager, rows: readonly number[]): string {
  const key = `game-bg-day-${rows.join('')}`;
  return makeCanvasTexture(tm, key, WORLD_WIDTH, GAME_HEIGHT, (ctx, w, h) => {
    const rnd = mulberry32(2024);
    ctx.fillStyle = '#4a9a2c';
    ctx.fillRect(0, 0, w, h);

    ctx.fillStyle = linearGradient(ctx, 0, 0, 0, BOARD.y, ['#356f1f', '#4a9a2c']);
    ctx.fillRect(0, 0, BOARD_RIGHT, BOARD.y);
    for (let x = 160; x < BOARD_RIGHT + 20; x += 34) bush(ctx, x, 60 + rnd() * 14, 24 + rnd() * 10);

    for (let r = 0; r < BOARD.rows; r++) {
      const active = rows.includes(r);
      for (let c = 0; c < BOARD.cols; c++) {
        const x0 = BOARD.x + c * BOARD.cellW;
        const y0 = BOARD.y + r * BOARD.cellH;
        if (active) {
          ctx.fillStyle = (r + c) % 2 === 0 ? '#74ca4b' : '#63ba3d';
          ctx.fillRect(x0, y0, BOARD.cellW, BOARD.cellH);
        } else {
          ctx.fillStyle = (r + c) % 2 === 0 ? '#93703f' : '#876638';
          ctx.fillRect(x0, y0, BOARD.cellW, BOARD.cellH);
          for (let i = 0; i < 6; i++) {
            ctx.fillStyle = 'rgba(60,40,20,0.22)';
            ellipse(ctx, x0 + rnd() * BOARD.cellW, y0 + rnd() * BOARD.cellH, 3 + rnd() * 6, 2 + rnd() * 3);
            ctx.fill();
          }
        }
      }
    }

    ctx.lineWidth = 2;
    for (let i = 0; i < 3000; i++) {
      const x = BOARD.x + rnd() * BOARD.cols * BOARD.cellW;
      const y = BOARD.y + 6 + rnd() * (BOARD.rows * BOARD.cellH - 6);
      if (!rows.includes(Math.floor((y - BOARD.y) / BOARD.cellH))) continue;
      ctx.strokeStyle = rnd() > 0.5 ? 'rgba(30,90,20,0.28)' : 'rgba(180,240,130,0.3)';
      ctx.beginPath();
      ctx.moveTo(x, y);
      ctx.lineTo(x + (rnd() - 0.5) * 6, y - 4 - rnd() * 6);
      ctx.stroke();
    }

    // полоса газонокосилок между домом и полем
    ctx.fillStyle = '#4f9d30';
    ctx.fillRect(HOUSE_W, BOARD.y, BOARD.x - HOUSE_W, BOARD_BOTTOM - BOARD.y);
    for (const r of rows) {
      ctx.fillStyle = '#b9b3a3';
      roundRect(ctx, 184, BOARD.y + (r + 1) * BOARD.cellH - 30, 58, 20, 8);
      ctx.fill();
    }

    ctx.fillStyle = linearGradient(ctx, 0, BOARD.y, 0, BOARD.y + 26, ['rgba(0,40,0,0.35)', 'rgba(0,40,0,0)']);
    ctx.fillRect(HOUSE_W, BOARD.y, BOARD_RIGHT - HOUSE_W, 26);

    drawFlowerBed(ctx, h, rnd);
    drawHouse(ctx, h);
    drawStreet(ctx, w, h, rnd);

    ctx.fillStyle = linearGradient(ctx, HOUSE_W, 0, HOUSE_W + 80, 0, ['rgba(0,0,0,0.28)', 'rgba(0,0,0,0)']);
    ctx.fillRect(HOUSE_W, 0, 80, h);
  });
}

function drawCherryBomb(ctx: CanvasRenderingContext2D): void {
  ctx.strokeStyle = '#2f6a17';
  ctx.lineWidth = 6;
  ctx.beginPath();
  ctx.moveTo(66, 16);
  ctx.quadraticCurveTo(44, 30, 42, 58);
  ctx.moveTo(66, 16);
  ctx.quadraticCurveTo(88, 28, 92, 52);
  ctx.stroke();
  ellipse(ctx, 80, 14, 16, 7, -0.4);
  ctx.fillStyle = '#5cb83a';
  ctx.fill();
  ctx.strokeStyle = '#1f5510';
  ctx.lineWidth = 2;
  ctx.stroke();

  for (const [cx, cy] of [[42, 86], [92, 80]]) {
    circle(ctx, cx, cy, 30);
    ctx.fillStyle = radialGradient(ctx, cx - 10, cy - 12, 3, cx, cy, 32, ['#ff8a7a', '#e3241f', '#8e0b0b']);
    ctx.fill();
    ctx.strokeStyle = '#4a0505';
    ctx.lineWidth = 3;
    ctx.stroke();
    ctx.fillStyle = 'rgba(255,255,255,0.55)';
    ellipse(ctx, cx - 12, cy - 14, 8, 5, -0.6);
    ctx.fill();
    // злая мордашка
    ctx.strokeStyle = '#2a0303';
    ctx.lineWidth = 3.5;
    ctx.beginPath();
    ctx.moveTo(cx - 16, cy - 8);
    ctx.lineTo(cx - 4, cy - 3);
    ctx.moveTo(cx + 16, cy - 8);
    ctx.lineTo(cx + 4, cy - 3);
    ctx.stroke();
    ctx.fillStyle = '#1a0202';
    circle(ctx, cx - 8, cy + 2, 3.5);
    ctx.fill();
    circle(ctx, cx + 8, cy + 2, 3.5);
    ctx.fill();
    ctx.beginPath();
    ctx.moveTo(cx - 9, cy + 15);
    ctx.quadraticCurveTo(cx, cy + 9, cx + 9, cy + 15);
    ctx.stroke();
  }
}

function drawCracks(ctx: CanvasRenderingContext2D, heavy: boolean): void {
  ctx.strokeStyle = '#4a2a0c';
  ctx.lineWidth = 3;
  const lines = [
    [[34, 18], [42, 34], [36, 44], [46, 58]],
    [[94, 70], [82, 76], [86, 88], [74, 98]],
  ];
  if (heavy) {
    lines.push([[16, 70], [28, 74], [24, 86], [34, 94]], [[70, 14], [64, 26], [72, 34]], [[50, 106], [58, 96], [54, 88]]);
  }
  for (const pts of lines) {
    ctx.beginPath();
    pts.forEach(([x, y], i) => (i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y)));
    ctx.stroke();
  }
  if (heavy) {
    ctx.fillStyle = 'rgba(90,50,20,0.35)';
    ellipse(ctx, 84, 30, 9, 6);
    ctx.fill();
  }
}

function generatePlantsAndArmor(tm: Phaser.Textures.TextureManager): void {
  makeCanvasTexture(tm, Tex.Plant.CherryBomb, 132, 122, drawCherryBomb);
  makeCanvasTexture(tm, Tex.Plant.WallnutCracks[0], 112, 124, (ctx) => drawCracks(ctx, false));
  makeCanvasTexture(tm, Tex.Plant.WallnutCracks[1], 112, 124, (ctx) => drawCracks(ctx, true));

  makeCanvasTexture(tm, Tex.Zombie.Cone, 66, 78, (ctx) => {
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(30, 4);
    ctx.quadraticCurveTo(33, 1, 36, 4);
    ctx.lineTo(56, 64);
    ctx.lineTo(10, 64);
    ctx.closePath();
    ctx.fillStyle = linearGradient(ctx, 10, 0, 56, 0, ['#ffc061', '#f5871c', '#d0610a']);
    ctx.fill();
    ctx.clip();
    ctx.fillStyle = 'rgba(255,255,255,0.9)';
    ctx.fillRect(0, 26, 66, 9);
    ctx.fillRect(0, 46, 66, 7);
    ctx.restore();
    ctx.strokeStyle = '#7a3a00';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(30, 4);
    ctx.lineTo(56, 64);
    ctx.lineTo(10, 64);
    ctx.closePath();
    ctx.stroke();
    ellipse(ctx, 33, 66, 31, 8);
    ctx.fillStyle = '#e8700e';
    ctx.fill();
    ctx.stroke();
  });

  makeCanvasTexture(tm, Tex.Zombie.Bucket, 80, 68, (ctx) => {
    ctx.beginPath();
    ctx.moveTo(20, 6);
    ctx.lineTo(60, 6);
    ctx.lineTo(70, 56);
    ctx.lineTo(10, 56);
    ctx.closePath();
    ctx.fillStyle = linearGradient(ctx, 10, 0, 70, 0, ['#8a939b', '#e6ebef', '#9ba4ac', '#6d767e']);
    ctx.fill();
    ctx.strokeStyle = '#33383d';
    ctx.lineWidth = 3;
    ctx.stroke();
    ellipse(ctx, 40, 57, 32, 7);
    ctx.fillStyle = '#c9cfd4';
    ctx.fill();
    ctx.stroke();
    ctx.strokeStyle = 'rgba(40,45,50,0.4)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(30, 30, 6, 0.5, 2.6);
    ctx.stroke();
    ctx.fillStyle = 'rgba(255,255,255,0.4)';
    ctx.fillRect(26, 10, 6, 40);
  });

  makeCanvasTexture(tm, Tex.Zombie.Flag, 84, 132, (ctx) => {
    ctx.fillStyle = '#6b4a2a';
    ctx.fillRect(7, 2, 6, 130);
    ctx.strokeStyle = '#3b2410';
    ctx.lineWidth = 2;
    ctx.strokeRect(7, 2, 6, 130);
    ctx.beginPath();
    ctx.moveTo(13, 8);
    ctx.bezierCurveTo(36, 0, 56, 18, 80, 10);
    ctx.lineTo(78, 58);
    ctx.bezierCurveTo(56, 66, 36, 48, 13, 56);
    ctx.closePath();
    ctx.fillStyle = linearGradient(ctx, 0, 6, 0, 60, ['#ef3b3f', '#b5161b']);
    ctx.fill();
    ctx.strokeStyle = '#5a0a0a';
    ctx.lineWidth = 3;
    ctx.stroke();
    ellipse(ctx, 46, 33, 16, 12);
    ctx.fillStyle = '#f6b3c3';
    ctx.fill();
    ctx.strokeStyle = '#a3485e';
    ctx.lineWidth = 2;
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(46, 22);
    ctx.lineTo(46, 44);
    ctx.moveTo(36, 30);
    ctx.quadraticCurveTo(40, 34, 36, 38);
    ctx.moveTo(56, 30);
    ctx.quadraticCurveTo(52, 34, 56, 38);
    ctx.stroke();
  });
}

function generateGameObjects(tm: Phaser.Textures.TextureManager): void {
  makeCanvasTexture(tm, Tex.Game.Mower, 100, 76, (ctx) => {
    ctx.strokeStyle = '#2b2b30';
    ctx.lineWidth = 5;
    ctx.beginPath();
    ctx.moveTo(26, 46);
    ctx.lineTo(8, 10);
    ctx.lineTo(2, 10);
    ctx.stroke();
    roundRect(ctx, 16, 36, 70, 24, 10);
    ctx.fillStyle = linearGradient(ctx, 0, 36, 0, 60, ['#ff5a45', '#b81f14']);
    ctx.fill();
    ctx.strokeStyle = '#4a0a05';
    ctx.lineWidth = 3;
    ctx.stroke();
    roundRect(ctx, 34, 18, 36, 22, 8);
    ctx.fillStyle = linearGradient(ctx, 0, 18, 0, 40, ['#5b5b66', '#2c2c33']);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = '#d6d6de';
    roundRect(ctx, 42, 14, 20, 7, 3);
    ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,0.35)';
    ctx.fillRect(22, 40, 56, 4);
    for (const x of [28, 74]) {
      circle(ctx, x, 62, 12);
      ctx.fillStyle = '#1e1e22';
      ctx.fill();
      circle(ctx, x, 62, 4.5);
      ctx.fillStyle = '#c9c9d0';
      ctx.fill();
    }
  });

  makeCanvasTexture(tm, Tex.Game.SeedPacket, 64, 86, (ctx) => {
    roundRect(ctx, 2, 2, 60, 82, 9);
    ctx.fillStyle = linearGradient(ctx, 0, 2, 0, 84, ['#fbefc6', '#e2c788']);
    ctx.fill();
    ctx.strokeStyle = '#5a4220';
    ctx.lineWidth = 3;
    ctx.stroke();
    roundRect(ctx, 7, 7, 50, 52, 6);
    ctx.fillStyle = linearGradient(ctx, 0, 7, 0, 59, ['#d3f0b0', '#9fd572']);
    ctx.fill();
    ctx.strokeStyle = 'rgba(60,90,30,0.45)';
    ctx.lineWidth = 2;
    ctx.stroke();
    roundRect(ctx, 9, 63, 46, 18, 6);
    ctx.fillStyle = '#fffbea';
    ctx.fill();
    ctx.strokeStyle = '#c9b07a';
    ctx.stroke();
  });

  makeCanvasTexture(tm, Tex.Game.ShovelSlot, 80, 80, (ctx) => {
    roundRect(ctx, 3, 3, 74, 74, 14);
    ctx.fillStyle = linearGradient(ctx, 0, 3, 0, 77, ['#5b3a1c', '#3e2611']);
    ctx.fill();
    ctx.strokeStyle = '#21140a';
    ctx.lineWidth = 3;
    ctx.stroke();
    ctx.strokeStyle = 'rgba(0,0,0,0.35)';
    ctx.lineWidth = 6;
    roundRect(ctx, 9, 9, 62, 62, 10);
    ctx.stroke();
  });
}

function generateGameIcons(tm: Phaser.Textures.TextureManager): void {
  makeCanvasTexture(tm, Tex.Icon.Pause, 44, 44, (ctx) => {
    for (const x of [11, 25]) {
      roundRect(ctx, x, 8, 9, 28, 3);
      ctx.fillStyle = WHITE;
      ctx.fill();
      ctx.strokeStyle = INK;
      ctx.lineWidth = 3;
      ctx.stroke();
    }
  });

  makeCanvasTexture(tm, Tex.Icon.Restart, 44, 44, (ctx) => {
    ctx.beginPath();
    ctx.arc(22, 23, 12, -0.3, Math.PI * 1.55);
    doubleStroke(ctx, INK, WHITE, 10);
    ctx.beginPath();
    ctx.moveTo(30, 6);
    ctx.lineTo(37, 15);
    ctx.lineTo(26, 17);
    ctx.closePath();
    ctx.fillStyle = WHITE;
    ctx.fill();
    ctx.strokeStyle = INK;
    ctx.lineWidth = 2.5;
    ctx.stroke();
  });

  makeCanvasTexture(tm, Tex.Icon.Shovel, 72, 72, (ctx) => {
    ctx.save();
    ctx.translate(36, 36);
    ctx.rotate(-Math.PI / 4);
    roundRect(ctx, -4, -34, 8, 40, 3);
    ctx.fillStyle = linearGradient(ctx, -4, 0, 4, 0, ['#c98a4b', '#8a5426']);
    ctx.fill();
    ctx.strokeStyle = INK;
    ctx.lineWidth = 2.5;
    ctx.stroke();
    roundRect(ctx, -11, -36, 22, 7, 3);
    ctx.fillStyle = '#8a5426';
    ctx.fill();
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(-13, 4);
    ctx.lineTo(13, 4);
    ctx.lineTo(12, 22);
    ctx.quadraticCurveTo(0, 36, -12, 22);
    ctx.closePath();
    ctx.fillStyle = linearGradient(ctx, -13, 0, 13, 0, ['#e6ebef', '#9aa3ab']);
    ctx.fill();
    ctx.stroke();
    ctx.restore();
  });

  makeCanvasTexture(tm, Tex.Ui.Flag, 28, 36, (ctx) => {
    ctx.fillStyle = '#6b4a2a';
    ctx.fillRect(3, 2, 4, 34);
    ctx.beginPath();
    ctx.moveTo(7, 3);
    ctx.lineTo(26, 7);
    ctx.lineTo(24, 20);
    ctx.lineTo(7, 18);
    ctx.closePath();
    ctx.fillStyle = '#e8303a';
    ctx.fill();
    ctx.strokeStyle = '#5a0a0a';
    ctx.lineWidth = 2;
    ctx.stroke();
  });
}

function generateGameFx(tm: Phaser.Textures.TextureManager): void {
  makeCanvasTexture(tm, Tex.Fx.Puff, 56, 56, (ctx) => {
    ctx.fillStyle = radialGradient(ctx, 28, 28, 4, 28, 28, 28, ['rgba(120,110,100,0.9)', 'rgba(90,80,70,0.5)', 'rgba(90,80,70,0)']);
    circle(ctx, 28, 28, 28);
    ctx.fill();
  });
  makeCanvasTexture(tm, Tex.Fx.Fire, 40, 40, (ctx) => {
    ctx.fillStyle = radialGradient(ctx, 20, 20, 0, 20, 20, 20, ['rgba(255,250,200,1)', 'rgba(255,170,40,0.85)', 'rgba(230,60,10,0)']);
    circle(ctx, 20, 20, 20);
    ctx.fill();
  });
  makeCanvasTexture(tm, Tex.Fx.Dirt, 12, 12, (ctx) => {
    circle(ctx, 6, 6, 5);
    ctx.fillStyle = '#7a5530';
    ctx.fill();
  });
  makeCanvasTexture(tm, Tex.Fx.Ash, 8, 8, (ctx) => {
    circle(ctx, 4, 4, 3.5);
    ctx.fillStyle = '#2a2622';
    ctx.fill();
  });
}

export function generateGameTextures(tm: Phaser.Textures.TextureManager): void {
  generatePlantsAndArmor(tm);
  generateGameObjects(tm);
  generateGameIcons(tm);
  generateGameFx(tm);
}
