import Phaser from 'phaser';
import { generateEnvironmentTextures } from './environment';
import { generateCharacterTextures } from './characters';
import { generateIconTextures } from './icons';
import { generateGameTextures } from './game';
import { generateZombieTextures } from './zombies';

export type TextureGenerator = (tm: Phaser.Textures.TextureManager) => void;

/** Шаги генерации, выполняются по одному за кадр, чтобы полоса загрузки двигалась. */
export const TEXTURE_GENERATORS: TextureGenerator[] = [
  generateEnvironmentTextures,
  generateCharacterTextures,
  generateZombieTextures,
  generateIconTextures,
  generateGameTextures,
];
