import Phaser from 'phaser';
import { circle, ellipse, linearGradient, makeCanvasTexture, radialGradient, roundRect } from '../canvas';
import { Tex } from '../TextureKeys';

/** Точки опоры (основание стебля) растений в долях текстуры — для покачивания вокруг корня. */
export const PLANT_ORIGIN = {
  peashooter: { x: 58 / 140, y: 156 / 160 },
  sunflower: { x: 75 / 150, y: 180 / 184 },
  wallnut: { x: 56 / 112, y: 120 / 124 },
  cherrybomb: { x: 66 / 132, y: 118 / 122 },
  potatomine: { x: 50 / 100, y: 74 / 80 },
  chomper: { x: 70 / 160, y: 170 / 176 },
} as const;

const PLANT_OUTLINE = '#1f5510';

function baseLeaf(ctx: CanvasRenderingContext2D, x: number, y: number, dir: 1 | -1, len: number): void {
  ctx.beginPath();
  ctx.moveTo(x, y);
  ctx.quadraticCurveTo(x + dir * len * 0.55, y - len * 0.45, x + dir * len, y - len * 0.12);
  ctx.quadraticCurveTo(x + dir * len * 0.5, y + len * 0.14, x, y);
  ctx.closePath();
  ctx.fillStyle = linearGradient(ctx, x, y - len * 0.4, x, y + 6, ['#72cc44', '#2f7d1c']);
  ctx.fill();
  ctx.strokeStyle = PLANT_OUTLINE;
  ctx.lineWidth = 2.5;
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(x + dir * 4, y - 2);
  ctx.quadraticCurveTo(x + dir * len * 0.5, y - len * 0.22, x + dir * len * 0.88, y - len * 0.13);
  ctx.strokeStyle = 'rgba(255,255,255,0.28)';
  ctx.lineWidth = 2;
  ctx.stroke();
}

function stem(ctx: CanvasRenderingContext2D, x0: number, y0: number, cx: number, cy: number, x1: number, y1: number, width: number): void {
  ctx.beginPath();
  ctx.moveTo(x0, y0);
  ctx.quadraticCurveTo(cx, cy, x1, y1);
  ctx.strokeStyle = PLANT_OUTLINE;
  ctx.lineWidth = width + 5;
  ctx.stroke();
  ctx.strokeStyle = '#5cb83a';
  ctx.lineWidth = width;
  ctx.stroke();
}

type ShooterKind = 'pea' | 'snow' | 'repeater';

interface ShooterPalette {
  head: string[];
  snout: string[];
  ring: string;
  inner: string;
  outline: string;
  tuft: string;
}

const SHOOTERS: Record<ShooterKind, ShooterPalette> = {
  pea: { head: ['#cdf78e', '#80d043', '#4c9e27'], snout: ['#a8ec68', '#4fa82a'], ring: '#8fdd52', inner: '#1e4a0c', outline: PLANT_OUTLINE, tuft: '#4fa82a' },
  snow: { head: ['#f2fdff', '#a6e4ff', '#4aa8dc'], snout: ['#d8f5ff', '#64bde9'], ring: '#b6ecff', inner: '#0b3b58', outline: '#14466a', tuft: '#e3f8ff' },
  repeater: { head: ['#b2ec72', '#5cb02e', '#2f7a17'], snout: ['#92da5a', '#3c8f1e'], ring: '#78c743', inner: '#123806', outline: '#143f08', tuft: '#3c8f1e' },
};

function leafTuft(ctx: CanvasRenderingContext2D, dx: number, dy: number, p: ShooterPalette): void {
  ctx.beginPath();
  ctx.moveTo(34 + dx, 38 + dy);
  ctx.quadraticCurveTo(6 + dx, 18 + dy, 4 + dx, 36 + dy);
  ctx.quadraticCurveTo(14 + dx, 46 + dy, 34 + dx, 48 + dy);
  ctx.closePath();
  ctx.fillStyle = p.tuft;
  ctx.fill();
  ctx.strokeStyle = p.outline;
  ctx.lineWidth = 2.5;
  ctx.stroke();
}

/** Семейство стрелков: горохострел, снежный горох и повторитель отличаются палитрой и хохолком. */
function drawShooter(ctx: CanvasRenderingContext2D, kind: ShooterKind): void {
  const p = SHOOTERS[kind];
  baseLeaf(ctx, 58, 152, -1, 52);
  baseLeaf(ctx, 58, 152, 1, 52);
  stem(ctx, 58, 150, 46, 112, 56, 78, 9);

  if (kind === 'snow') {
    for (const [x, y, a] of [[24, 30, -2.4], [20, 46, -2.9], [30, 20, -1.9]]) {
      ctx.save();
      ctx.translate(x, y);
      ctx.rotate(a);
      ctx.beginPath();
      ctx.moveTo(0, -7);
      ctx.lineTo(26, 0);
      ctx.lineTo(0, 7);
      ctx.closePath();
      ctx.fillStyle = p.tuft;
      ctx.fill();
      ctx.strokeStyle = p.outline;
      ctx.lineWidth = 2;
      ctx.stroke();
      ctx.restore();
    }
  } else {
    if (kind === 'repeater') leafTuft(ctx, -4, 14, p);
    leafTuft(ctx, 0, 0, p);
  }

  roundRect(ctx, 70, 40, 50, 34, 8);
  ctx.fillStyle = linearGradient(ctx, 0, 40, 0, 74, p.snout);
  ctx.fill();
  ctx.strokeStyle = p.outline;
  ctx.lineWidth = 3;
  ctx.stroke();
  ellipse(ctx, 120, 57, 10, 20);
  ctx.fillStyle = p.ring;
  ctx.fill();
  ctx.stroke();
  ellipse(ctx, 121, 57, 6, 14);
  ctx.fillStyle = p.inner;
  ctx.fill();

  circle(ctx, 58, 58, 34);
  ctx.fillStyle = radialGradient(ctx, 46, 42, 4, 58, 58, 38, p.head);
  ctx.fill();
  ctx.strokeStyle = p.outline;
  ctx.lineWidth = 3;
  ctx.stroke();
  ctx.fillStyle = 'rgba(255,255,255,0.25)';
  ellipse(ctx, 46, 40, 11, 6, -0.5);
  ctx.fill();

  ctx.fillStyle = '#111';
  ellipse(ctx, 70, 50, 7, 10);
  ctx.fill();
  ctx.fillStyle = '#fff';
  circle(ctx, 72, 46, 3);
  ctx.fill();
  if (kind === 'repeater') {
    ctx.strokeStyle = '#102a06';
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.moveTo(58, 36);
    ctx.lineTo(80, 42);
    ctx.stroke();
  }
}

function drawSunflower(ctx: CanvasRenderingContext2D): void {
  baseLeaf(ctx, 75, 176, -1, 56);
  baseLeaf(ctx, 75, 176, 1, 56);
  stem(ctx, 75, 176, 66, 130, 75, 90, 9);

  const cx = 75;
  const cy = 64;
  const petals = 14;
  for (let layer = 0; layer < 2; layer++) {
    for (let i = 0; i < petals; i++) {
      const a = ((i + layer * 0.5) / petals) * Math.PI * 2;
      const d = layer === 0 ? 38 : 34;
      ellipse(ctx, cx + Math.cos(a) * d, cy + Math.sin(a) * d, 12, 22, a + Math.PI / 2);
      ctx.fillStyle = layer === 0 ? '#f5a90a' : '#ffd23a';
      ctx.fill();
      ctx.strokeStyle = '#c77d00';
      ctx.lineWidth = 2;
      ctx.stroke();
    }
  }

  circle(ctx, cx, cy, 30);
  ctx.fillStyle = radialGradient(ctx, cx - 8, cy - 10, 4, cx, cy, 32, ['#e3a75a', '#b0753a', '#7f4f1d']);
  ctx.fill();
  ctx.strokeStyle = '#5e3a14';
  ctx.lineWidth = 3;
  ctx.stroke();
  ctx.fillStyle = 'rgba(0,0,0,0.1)';
  for (let i = 0; i < 18; i++) {
    const a = i * 2.4;
    const d = 6 + (i % 4) * 5;
    circle(ctx, cx + Math.cos(a) * d, cy + Math.sin(a) * d, 1.6);
    ctx.fill();
  }
  ctx.fillStyle = '#2b1a0a';
  ellipse(ctx, cx - 10, cy - 6, 5, 8);
  ctx.fill();
  ellipse(ctx, cx + 10, cy - 6, 5, 8);
  ctx.fill();
  ctx.fillStyle = '#fff';
  circle(ctx, cx - 8, cy - 9, 2);
  ctx.fill();
  circle(ctx, cx + 12, cy - 9, 2);
  ctx.fill();
  ctx.fillStyle = 'rgba(255,120,90,0.45)';
  circle(ctx, cx - 18, cy + 6, 5);
  ctx.fill();
  circle(ctx, cx + 18, cy + 6, 5);
  ctx.fill();
  ctx.strokeStyle = '#2b1a0a';
  ctx.lineWidth = 3.5;
  ctx.beginPath();
  ctx.arc(cx, cy + 3, 11, 0.15 * Math.PI, 0.85 * Math.PI);
  ctx.stroke();
}

function drawWallnut(ctx: CanvasRenderingContext2D): void {
  const cx = 56;
  const cy = 64;
  ellipse(ctx, cx, cy, 44, 54);
  ctx.fillStyle = radialGradient(ctx, cx - 14, cy - 20, 6, cx, cy, 60, ['#f6cd8a', '#d39445', '#a5642a']);
  ctx.fill();
  ctx.strokeStyle = '#5e3510';
  ctx.lineWidth = 3;
  ctx.stroke();
  ctx.strokeStyle = 'rgba(110,60,20,0.35)';
  ctx.lineWidth = 2.5;
  for (const [x, y, r, a0, a1] of [
    [30, 30, 14, 3.4, 4.6],
    [84, 92, 12, 0.2, 1.4],
    [26, 96, 10, 1.8, 2.8],
  ]) {
    ctx.beginPath();
    ctx.arc(x, y, r, a0, a1);
    ctx.stroke();
  }
  for (const [x, y] of [[40, 52], [70, 50]]) {
    ellipse(ctx, x, y, 10, 13);
    ctx.fillStyle = '#fff';
    ctx.fill();
    ctx.strokeStyle = '#3b2a18';
    ctx.lineWidth = 2;
    ctx.stroke();
    ctx.fillStyle = '#111';
    circle(ctx, x - 3, y + 3, 5);
    ctx.fill();
    ctx.fillStyle = '#fff';
    circle(ctx, x - 1, y + 1, 1.6);
    ctx.fill();
  }
  ctx.strokeStyle = '#4a2a0c';
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.moveTo(30, 34);
  ctx.lineTo(48, 38);
  ctx.moveTo(80, 34);
  ctx.lineTo(62, 38);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(46, 84);
  ctx.quadraticCurveTo(56, 80, 66, 84);
  ctx.stroke();
}

function dirtMound(ctx: CanvasRenderingContext2D, cx: number, cy: number, rx: number, ry: number): void {
  ellipse(ctx, cx, cy, rx, ry);
  ctx.fillStyle = linearGradient(ctx, 0, cy - ry, 0, cy + ry, ['#93683a', '#5e3f20']);
  ctx.fill();
  ctx.strokeStyle = '#3e2914';
  ctx.lineWidth = 2;
  ctx.stroke();
  ctx.fillStyle = 'rgba(40,25,10,0.35)';
  for (const [x, y] of [[-14, -2], [10, 2], [22, -3], [-24, 3]]) {
    circle(ctx, cx + x, cy + y, 2.5);
    ctx.fill();
  }
}

function drawPotatoMine(ctx: CanvasRenderingContext2D, armed: boolean): void {
  if (!armed) {
    dirtMound(ctx, 50, 68, 34, 11);
    ctx.strokeStyle = '#2f7d1c';
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.moveTo(50, 60);
    ctx.lineTo(50, 44);
    ctx.stroke();
    ellipse(ctx, 42, 44, 9, 4, -0.5);
    ctx.fillStyle = '#5cb83a';
    ctx.fill();
    ellipse(ctx, 58, 42, 9, 4, 0.5);
    ctx.fill();
    circle(ctx, 50, 40, 4);
    ctx.fillStyle = '#8a2a2a';
    ctx.fill();
    return;
  }
  ctx.strokeStyle = '#2f7d1c';
  ctx.lineWidth = 4;
  ctx.beginPath();
  ctx.moveTo(50, 32);
  ctx.quadraticCurveTo(46, 20, 50, 10);
  ctx.stroke();
  circle(ctx, 50, 8, 6);
  ctx.fillStyle = '#ff4040';
  ctx.fill();
  ctx.strokeStyle = '#5a0a0a';
  ctx.lineWidth = 2;
  ctx.stroke();

  ellipse(ctx, 50, 52, 34, 25);
  ctx.fillStyle = radialGradient(ctx, 40, 40, 4, 50, 52, 38, ['#f0c88a', '#c99050', '#93602c']);
  ctx.fill();
  ctx.strokeStyle = '#5e3a14';
  ctx.lineWidth = 3;
  ctx.stroke();
  ctx.fillStyle = 'rgba(94,58,20,0.35)';
  for (const [x, y, r] of [[26, 52, 3], [74, 46, 2.5], [66, 62, 3]]) {
    circle(ctx, x, y, r);
    ctx.fill();
  }
  for (const x of [40, 60]) {
    ellipse(ctx, x, 46, 7, 9);
    ctx.fillStyle = '#fff';
    ctx.fill();
    ctx.strokeStyle = '#3b2a18';
    ctx.lineWidth = 2;
    ctx.stroke();
    ctx.fillStyle = '#111';
    circle(ctx, x - 2, 48, 3.5);
    ctx.fill();
  }
  ctx.fillStyle = '#3b1a0a';
  ellipse(ctx, 50, 61, 5, 4);
  ctx.fill();
  dirtMound(ctx, 50, 72, 46, 8);
}

function drawChomper(ctx: CanvasRenderingContext2D, chewing: boolean): void {
  baseLeaf(ctx, 70, 168, -1, 58);
  baseLeaf(ctx, 70, 168, 1, 58);
  stem(ctx, 70, 168, 98, 128, 82, 96, 11);
  // пятна на стебле
  ctx.fillStyle = 'rgba(30,80,10,0.45)';
  for (const [x, y] of [[84, 140], [90, 122], [86, 108]]) {
    circle(ctx, x, y, 2.5);
    ctx.fill();
  }

  const cx = 74;
  const cy = 62;
  const headFill = radialGradient(ctx, cx - 10, cy - 18, 6, cx, cy, 52, ['#d79af0', '#9b4fc4', '#5e2380']);
  if (chewing) {
    ellipse(ctx, cx - 4, cy + 4, 50, 42);
    ctx.fillStyle = headFill;
    ctx.fill();
    ctx.strokeStyle = '#2a0a3a';
    ctx.lineWidth = 3;
    ctx.stroke();
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(26, 64);
    for (let i = 0; i <= 8; i++) ctx.lineTo(26 + i * 6, 64 + (i % 2 === 0 ? 0 : 6) - i);
    ctx.stroke();
    ctx.fillStyle = 'rgba(255,255,255,0.22)';
    ellipse(ctx, cx - 18, cy - 20, 16, 8, -0.4);
    ctx.fill();
  } else {
    circle(ctx, cx, cy, 44);
    ctx.fillStyle = headFill;
    ctx.fill();
    ctx.strokeStyle = '#2a0a3a';
    ctx.lineWidth = 3;
    ctx.stroke();
    // раскрытая пасть, обращённая влево
    ctx.beginPath();
    ctx.moveTo(86, 64);
    ctx.lineTo(28, 24);
    ctx.quadraticCurveTo(10, 62, 30, 102);
    ctx.closePath();
    ctx.fillStyle = '#5a0f22';
    ctx.fill();
    ctx.strokeStyle = '#2a0a3a';
    ctx.stroke();
    ctx.fillStyle = '#fffbe8';
    for (let i = 0; i < 5; i++) {
      const t = (i + 0.5) / 5;
      const ux = 28 + (86 - 28) * t;
      const uy = 24 + (64 - 24) * t;
      ctx.beginPath();
      ctx.moveTo(ux - 4, uy - 3);
      ctx.lineTo(ux + 4, uy + 3);
      ctx.lineTo(ux - 2, uy + 10);
      ctx.closePath();
      ctx.fill();
      const lx = 30 + (86 - 30) * t;
      const ly = 102 + (64 - 102) * t;
      ctx.beginPath();
      ctx.moveTo(lx - 4, ly + 3);
      ctx.lineTo(lx + 4, ly - 3);
      ctx.lineTo(lx - 2, ly - 10);
      ctx.closePath();
      ctx.fill();
    }
  }
  ctx.fillStyle = 'rgba(240,200,255,0.4)';
  for (const [x, y, r] of [[96, 34, 6], [108, 58, 5], [98, 82, 4]]) {
    circle(ctx, x, y, r);
    ctx.fill();
  }
}

export function generateCharacterTextures(tm: Phaser.Textures.TextureManager): void {
  makeCanvasTexture(tm, Tex.Plant.Peashooter, 140, 160, (ctx) => drawShooter(ctx, 'pea'));
  makeCanvasTexture(tm, Tex.Plant.SnowPea, 140, 160, (ctx) => drawShooter(ctx, 'snow'));
  makeCanvasTexture(tm, Tex.Plant.Repeater, 140, 160, (ctx) => drawShooter(ctx, 'repeater'));
  makeCanvasTexture(tm, Tex.Plant.Sunflower, 150, 184, drawSunflower);
  makeCanvasTexture(tm, Tex.Plant.Wallnut, 112, 124, drawWallnut);
  makeCanvasTexture(tm, Tex.Plant.PotatoMine, 100, 80, (ctx) => drawPotatoMine(ctx, true));
  makeCanvasTexture(tm, Tex.Plant.PotatoMineBuried, 100, 80, (ctx) => drawPotatoMine(ctx, false));
  makeCanvasTexture(tm, Tex.Plant.Chomper, 160, 176, (ctx) => drawChomper(ctx, false));
  makeCanvasTexture(tm, Tex.Plant.ChomperChew, 160, 176, (ctx) => drawChomper(ctx, true));
}
