import Phaser from 'phaser';
import type { SaveData } from '@/core/SaveManager';
import { countCompleted, countStars, MAX_STARS } from '@/core/progress';
import { LEVELS } from '@/data/levels';
import { Tex } from '@/graphics/TextureKeys';
import { PLANT_ORIGIN } from '@/graphics/textures/characters';
import { ensurePanelTexture } from '@/graphics/textures/ui';
import { t } from '@/i18n/ru';
import { Button, RoundButton } from '@/ui/Button';
import { inkStyle, textStyle } from '@/ui/theme';
import { formatDate, formatPlayTime } from '@/utils/format';

export const SLOT_CARD_W = 350;
export const SLOT_CARD_H = 440;

const AVATARS = [
  { key: Tex.Plant.Peashooter, origin: PLANT_ORIGIN.peashooter },
  { key: Tex.Plant.Sunflower, origin: PLANT_ORIGIN.sunflower },
  { key: Tex.Plant.Wallnut, origin: PLANT_ORIGIN.wallnut },
];

export interface SaveSlotHandlers {
  onPlay: () => void;
  onCreate: () => void;
  onDelete: () => void;
}

/** Карточка слота сохранения: статистика профиля или приглашение начать новую игру. */
export class SaveSlotCard extends Phaser.GameObjects.Container {
  constructor(
    scene: Phaser.Scene,
    x: number,
    y: number,
    slot: number,
    save: SaveData | null,
    active: boolean,
    handlers: SaveSlotHandlers,
  ) {
    super(scene, x, y);
    const top = -SLOT_CARD_H / 2;

    if (active) {
      const glow = scene.add.graphics();
      glow.lineStyle(8, 0xfff27e, 1).strokeRoundedRect(-SLOT_CARD_W / 2 - 10, top - 10, SLOT_CARD_W + 20, SLOT_CARD_H + 20, 30);
      this.add(glow);
      scene.tweens.add({ targets: glow, alpha: 0.35, yoyo: true, repeat: -1, duration: 700, ease: 'Sine.easeInOut' });
    }

    const tex = ensurePanelTexture(scene.textures, 'paper', SLOT_CARD_W, SLOT_CARD_H);
    this.add(scene.add.image(0, 0, tex.key).setOrigin(tex.originX, tex.originY));
    this.add(scene.add.text(0, top + 36, t.saves.slot(slot + 1), inkStyle(22, { color: '#8a6a42' })).setOrigin(0.5));

    if (save) this.buildFilled(scene, top, slot, save, active, handlers);
    else this.buildEmpty(scene, top, handlers);
    scene.add.existing(this);
  }

  private buildFilled(scene: Phaser.Scene, top: number, slot: number, save: SaveData, active: boolean, handlers: SaveSlotHandlers): void {
    const avatar = AVATARS[slot % AVATARS.length];
    const plant = scene.add
      .image(0, top + 158, avatar.key)
      .setOrigin(avatar.origin.x, avatar.origin.y)
      .setScale(0.62);
    scene.tweens.add({ targets: plant, angle: { from: -4, to: 4 }, yoyo: true, repeat: -1, duration: 1200, ease: 'Sine.easeInOut' });

    const name = scene.add.text(0, top + 184, save.name, textStyle(30)).setOrigin(0.5);
    const lines = [
      t.saves.completed(countCompleted(save), LEVELS.length),
      t.saves.stars(countStars(save), MAX_STARS),
      t.saves.plants(save.unlockedPlants.length),
      t.saves.playTime(formatPlayTime(save.playTimeSec)),
      t.saves.lastPlayed(formatDate(save.updatedAt)),
    ];
    const stats = scene.add
      .text(0, top + 214, lines.join('\n'), inkStyle(17, { align: 'center', lineSpacing: 5 }))
      .setOrigin(0.5, 0);

    const play = new Button(scene, -34, top + 390, {
      label: t.common.play,
      icon: Tex.Icon.Play,
      variant: 'green',
      width: 210,
      height: 60,
      fontSize: 24,
    }).onClick(handlers.onPlay);
    const del = new RoundButton(scene, 118, top + 390, Tex.Icon.Trash, { variant: 'red', size: 58 }).onClick(handlers.onDelete);
    this.add([plant, name, stats, play, del]);

    if (active) {
      const badge = scene.add.container(SLOT_CARD_W / 2 - 52, top + 24).setAngle(10);
      const g = scene.add.graphics();
      g.fillStyle(0x4aa52a, 1).fillRoundedRect(-56, -16, 112, 32, 10);
      g.lineStyle(3, 0x1d4a0c, 1).strokeRoundedRect(-56, -16, 112, 32, 10);
      badge.add([g, scene.add.text(0, -1, t.saves.active, textStyle(16)).setOrigin(0.5)]);
      this.add(badge);
    }
  }

  private buildEmpty(scene: Phaser.Scene, top: number, handlers: SaveSlotHandlers): void {
    const plus = scene.add.image(0, top + 170, Tex.Icon.Plus).setScale(2.4).setAlpha(0.3);
    scene.tweens.add({ targets: plus, scale: 2.6, yoyo: true, repeat: -1, duration: 900, ease: 'Sine.easeInOut' });
    const label = scene.add.text(0, top + 270, t.saves.empty, inkStyle(26, { color: '#8a6a42' })).setOrigin(0.5);
    const create = new Button(scene, 0, top + 390, {
      label: t.saves.newGame,
      icon: Tex.Icon.Plus,
      variant: 'green',
      width: 260,
      height: 60,
      fontSize: 24,
    }).onClick(handlers.onCreate);
    this.add([plus, label, create]);
  }
}
