import Phaser from 'phaser';
import { t } from '@/i18n/ru';
import { Colors, textStyle } from '@/ui/theme';

interface Letter {
  text: Phaser.GameObjects.Text;
  baseY: number;
  zombie: boolean;
  index: number;
}

/** Логотип игры: буквы падают с отскоком, затем растения «дышат», а зомби подёргиваются. */
export class GameTitle extends Phaser.GameObjects.Container {
  private readonly letters: Letter[] = [];
  private readonly ribbon: Phaser.GameObjects.Container;
  private ready = false;

  constructor(scene: Phaser.Scene, x: number, y: number) {
    super(scene, x, y);
    this.buildWord(t.title.top, 0, 86, ['#f0ffb0', '#9be84a', '#3f9a1e'], '#173d08', false);
    this.ribbon = this.buildRibbon(64);
    this.buildWord(t.title.bottom, 126, 86, ['#eef3e4', '#adbb9a', '#5e6e4c'], '#1f2817', true);
    scene.add.existing(this);
  }

  playIntro(): void {
    this.letters.forEach((letter, i) => {
      letter.text.y = letter.baseY - 280;
      letter.text.setAlpha(0);
      this.scene.tweens.add({
        targets: letter.text,
        y: letter.baseY,
        alpha: 1,
        delay: 70 * i,
        duration: 750,
        ease: 'Bounce.easeOut',
        onComplete: i === this.letters.length - 1 ? () => (this.ready = true) : undefined,
      });
    });
    this.ribbon.setScale(0, 1);
    this.scene.tweens.add({ targets: this.ribbon, scaleX: 1, delay: 600, duration: 500, ease: 'Back.easeOut' });
  }

  update(time: number): void {
    if (!this.ready) return;
    for (const { text, baseY, zombie, index } of this.letters) {
      if (zombie) {
        text.y = baseY + Math.sin(time / 260 + index * 1.7) * 2;
        text.angle = Math.sin(time / 170 + index * 2.3) * 3;
      } else {
        text.y = baseY + Math.sin(time / 420 + index * 0.55) * 4;
      }
    }
  }

  private buildWord(word: string, y: number, size: number, gradient: string[], stroke: string, zombie: boolean): void {
    const texts = [...word].map((ch) => {
      const text = this.scene.add
        .text(0, y, ch, textStyle(size, {
          stroke,
          strokeThickness: Math.round(size / 7),
          shadow: { offsetX: 0, offsetY: 7, color: 'rgba(0,0,0,0.4)', blur: 0, stroke: true, fill: true },
        }))
        .setOrigin(0.5);
      const g = text.context.createLinearGradient(0, 0, 0, text.height);
      gradient.forEach((c, i) => g.addColorStop(i / (gradient.length - 1), c));
      text.setFill(g);
      return text;
    });
    const spacing = -size * 0.06;
    const total = texts.reduce((sum, tx) => sum + tx.width, 0) + spacing * (texts.length - 1);
    let cursor = -total / 2;
    for (const text of texts) {
      text.x = cursor + text.width / 2;
      cursor += text.width + spacing;
      this.add(text);
      this.letters.push({ text, baseY: y, zombie, index: this.letters.length });
    }
  }

  private buildRibbon(y: number): Phaser.GameObjects.Container {
    const w = 190;
    const h = 40;
    const g = this.scene.add.graphics();
    const tail = (dir: 1 | -1) => {
      const x = dir * (w / 2 - 6);
      g.fillStyle(0xc98a00, 1);
      g.fillPoints(
        [
          new Phaser.Math.Vector2(x, -h / 2 + 8),
          new Phaser.Math.Vector2(x + dir * 40, -h / 2 + 8),
          new Phaser.Math.Vector2(x + dir * 28, 4 + 8),
          new Phaser.Math.Vector2(x + dir * 40, h / 2 + 8),
          new Phaser.Math.Vector2(x, h / 2 + 8),
        ],
        true,
      );
    };
    tail(-1);
    tail(1);
    g.fillStyle(0x000000, 0.25).fillRoundedRect(-w / 2, -h / 2 + 4, w, h, 8);
    g.fillStyle(0xffd23f, 1).fillRoundedRect(-w / 2, -h / 2, w, h, 8);
    g.fillStyle(0xffffff, 0.3).fillRoundedRect(-w / 2 + 6, -h / 2 + 4, w - 12, 10, 5);
    g.lineStyle(3, 0x6a3c00, 1).strokeRoundedRect(-w / 2, -h / 2, w, h, 8);
    const label = this.scene.add
      .text(0, -1, t.title.middle, textStyle(26, { color: Colors.ink, stroke: '#fff3b0', strokeThickness: 3, shadow: undefined }))
      .setOrigin(0.5);
    const ribbon = this.scene.add.container(0, y, [g, label]);
    this.add(ribbon);
    return ribbon;
  }
}
