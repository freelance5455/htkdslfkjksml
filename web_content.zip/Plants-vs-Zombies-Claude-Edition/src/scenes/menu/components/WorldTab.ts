import Phaser from 'phaser';
import type { WorldDef } from '@/data/worlds';
import { Tex } from '@/graphics/TextureKeys';
import { ensureButtonTexture } from '@/graphics/textures/ui';
import { Pressable } from '@/ui/Pressable';
import { textStyle } from '@/ui/theme';

const W = 200;
const H = 66;

/** Вкладка мира на экране выбора уровня. */
export class WorldTab extends Pressable {
  private readonly bg: Phaser.GameObjects.Image;
  private readonly icon: Phaser.GameObjects.Image;
  private readonly lock: Phaser.GameObjects.Image;

  constructor(scene: Phaser.Scene, x: number, y: number, readonly world: WorldDef) {
    super(scene, x, y, W, H);
    this.bg = scene.add.image(0, 0, '__DEFAULT');
    this.icon = scene.add.image(-W / 2 + 36, -3, Tex.World[world.id]).setDisplaySize(44, 44);
    const label = scene.add.text(18, -3, world.name, textStyle(24)).setOrigin(0.5);
    this.lock = scene.add.image(W / 2 - 14, -H / 2 + 6, Tex.Ui.Lock).setScale(0.55).setAngle(12);
    this.content.add([this.bg, this.icon, label, this.lock]);
  }

  setTabState(selected: boolean, locked: boolean): this {
    const tex = ensureButtonTexture(this.scene.textures, locked ? 'stone' : selected ? 'green' : 'wood', W, H);
    this.bg.setTexture(tex.key).setOrigin(tex.originX, tex.originY);
    this.lock.setVisible(locked);
    this.icon.setAlpha(locked ? 0.55 : 1);
    this.scene.tweens.add({ targets: this.content, y: selected ? -6 : 0, duration: 200, ease: 'Back.easeOut' });
    return this;
  }
}
