import Phaser from 'phaser';
import type { LevelDef } from '@/data/levels';
import { getLevelScript } from '@/data/levelScripts';
import { Tex } from '@/graphics/TextureKeys';
import { ensureCardTexture, type CardState } from '@/graphics/textures/ui';
import { t } from '@/i18n/ru';
import { Pressable } from '@/ui/Pressable';
import { textStyle } from '@/ui/theme';

export const LEVEL_CARD_W = 150;
export const LEVEL_CARD_H = 124;

/** Карточка уровня («пакетик семян»): номер, звёзды или замок, подсветка выбора. */
export class LevelCard extends Pressable {
  readonly locked: boolean;
  private readonly highlight: Phaser.GameObjects.Graphics;

  constructor(scene: Phaser.Scene, x: number, y: number, readonly level: LevelDef, state: CardState, stars: number) {
    super(scene, x, y, LEVEL_CARD_W, LEVEL_CARD_H);
    this.locked = state === 'locked';
    this.hoverScale = this.locked ? 1.02 : 1.08;

    this.highlight = scene.add.graphics().setAlpha(0);
    this.highlight.lineStyle(6, 0xfff27e, 1).strokeRoundedRect(-LEVEL_CARD_W / 2 - 8, -LEVEL_CARD_H / 2 - 8, LEVEL_CARD_W + 16, LEVEL_CARD_H + 16, 20);
    this.highlight.lineStyle(2, 0xffffff, 0.9).strokeRoundedRect(-LEVEL_CARD_W / 2 - 4, -LEVEL_CARD_H / 2 - 4, LEVEL_CARD_W + 8, LEVEL_CARD_H + 8, 17);

    const tex = ensureCardTexture(scene.textures, state, LEVEL_CARD_W, LEVEL_CARD_H);
    const card = scene.add.image(0, 0, tex.key).setOrigin(tex.originX, tex.originY);
    const top = -LEVEL_CARD_H / 2;
    const script = getLevelScript(level.id);
    const band = scene.add.text(0, top + 15, script ? t.levels.waves(script.waves.length) : t.levels.soon, textStyle(15)).setOrigin(0.5);
    const number = scene.add
      .text(0, top + 66, level.id, textStyle(40, { color: this.locked ? '#d8d2c6' : '#fff8e7' }))
      .setOrigin(0.5);
    this.content.add([this.highlight, card, band, number]);

    if (this.locked) {
      number.setAlpha(0.45);
      this.content.add(scene.add.image(0, top + 66, Tex.Ui.Lock).setScale(0.9));
    } else {
      for (let i = 0; i < 3; i++) {
        const star = scene.add
          .image((i - 1) * 30, top + 104 - (i === 1 ? 4 : 0), i < stars ? Tex.Ui.Star : Tex.Ui.StarEmpty)
          .setScale(0.55);
        this.content.add(star);
      }
    }
  }

  setSelected(selected: boolean): void {
    this.scene.tweens.killTweensOf(this.highlight);
    if (selected) {
      this.highlight.setAlpha(1);
      this.scene.tweens.add({ targets: this.highlight, alpha: 0.45, yoyo: true, repeat: -1, duration: 600, ease: 'Sine.easeInOut' });
    } else {
      this.highlight.setAlpha(0);
    }
  }
}
