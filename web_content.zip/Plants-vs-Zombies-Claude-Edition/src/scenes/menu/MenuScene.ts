import Phaser from 'phaser';
import { eventBus } from '@/core/EventBus';
import { RegistryKeys, SceneKeys } from '@/core/SceneKeys';
import { audio } from '@/audio/AudioManager';
import type { WorldId } from '@/data/worlds';
import { Modal } from '@/ui/Modal';
import { BaseScene } from '../BaseScene';

export interface GoToOptions {
  /** Затемнить весь экран (включая живой фон) — для перехода из меню в игру. */
  fadeToBlack?: boolean;
}

/**
 * База экранов меню. Они рисуются поверх постоянно работающей MenuBackgroundScene,
 * поэтому переходы анимируют только корневой контейнер интерфейса, а фон продолжает жить.
 */
export abstract class MenuScene extends BaseScene {
  protected root!: Phaser.GameObjects.Container;
  private leaving = false;

  /** Вызывается первой строкой в create() наследника. */
  protected initMenu(world: WorldId): void {
    this.leaving = false;
    this.input.enabled = true;
    this.cameras.main.resetFX();
    this.root = this.add.container(0, 0).setAlpha(0);
    this.root.y = 18;
    this.tweens.add({ targets: this.root, alpha: 1, y: 0, duration: 320, ease: 'Cubic.easeOut' });

    this.registry.set(RegistryKeys.MenuWorld, world);
    eventBus.emit('menu:world-preview', world);

    this.input.keyboard?.on('keydown-ESC', () => {
      if (!Modal.isOpen(this) && !this.leaving) this.onBack();
    });
  }

  /** Поведение по Esc и кнопке «назад». */
  protected onBack(): void {}

  protected back(): void {
    audio.sfx('back');
    this.goTo(SceneKeys.MainMenu);
  }

  protected goTo(key: string, data?: object, options: GoToOptions = {}): void {
    if (this.leaving) return;
    this.leaving = true;
    this.input.enabled = false;

    const duration = options.fadeToBlack ? 320 : 200;
    if (options.fadeToBlack) {
      const background = this.scene.get(SceneKeys.MenuBackground);
      if (this.scene.isActive(SceneKeys.MenuBackground)) background.cameras.main.fadeOut(duration, 0, 0, 0);
      this.cameras.main.fadeOut(duration, 0, 0, 0);
    }
    this.tweens.add({
      targets: this.root,
      alpha: 0,
      y: -18,
      duration,
      ease: 'Cubic.easeIn',
      onComplete: () => {
        this.input.enabled = true;
        this.scene.start(key, data);
      },
    });
  }
}
