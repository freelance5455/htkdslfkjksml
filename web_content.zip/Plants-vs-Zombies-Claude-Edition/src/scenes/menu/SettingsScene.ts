import Phaser from 'phaser';
import { CENTER_X } from '@/config/constants';
import { SceneKeys } from '@/core/SceneKeys';
import { settings, type Settings } from '@/core/SettingsManager';
import { audio } from '@/audio/AudioManager';
import { Tex } from '@/graphics/TextureKeys';
import { ensurePanelTexture } from '@/graphics/textures/ui';
import { t } from '@/i18n/ru';
import { Button, RoundButton } from '@/ui/Button';
import { Slider } from '@/ui/Slider';
import { Toggle } from '@/ui/Toggle';
import { showToast } from '@/ui/Toast';
import { textStyle } from '@/ui/theme';
import { MenuScene } from './MenuScene';

const PANEL_W = 720;
const PANEL_H = 560;
const PANEL_Y = 388;
const LABEL_X = CENTER_X - 300;
const CONTROL_X = CENTER_X + 150;
const ROW_Y0 = 222;
const ROW_DY = 60;

type BoolKey = { [K in keyof Settings]: Settings[K] extends boolean ? K : never }[keyof Settings];

export class SettingsScene extends MenuScene {
  private sliders: Partial<Record<'musicVolume' | 'sfxVolume', Slider>> = {};
  private toggles: Partial<Record<BoolKey, Toggle>> = {};
  private fullscreenToggle?: Toggle;

  constructor() {
    super(SceneKeys.Settings);
  }

  create(): void {
    this.sliders = {};
    this.toggles = {};
    this.initMenu('day');

    const back = new RoundButton(this, 60, 56, Tex.Icon.Back).onClick(() => this.back());
    const tex = ensurePanelTexture(this.textures, 'wood', PANEL_W, PANEL_H);
    const panel = this.add.image(CENTER_X, PANEL_Y, tex.key).setOrigin(tex.originX, tex.originY);
    const title = this.add.text(CENTER_X, PANEL_Y - PANEL_H / 2 + 52, t.settings.title, textStyle(44)).setOrigin(0.5);
    this.root.add([back, panel, title]);

    const s = settings.get();
    const rows: { label: string; control: Phaser.GameObjects.GameObject & Phaser.GameObjects.Components.Transform }[] = [];

    const slider = (key: 'musicVolume' | 'sfxVolume') => {
      const control = new Slider(this, CONTROL_X - 10, 0, {
        width: 240,
        value: s[key],
        onChange: (v) => settings.set(key, v),
        onRelease: () => audio.sfx(key === 'sfxVolume' ? 'sun' : 'click'),
      });
      this.sliders[key] = control;
      return control;
    };
    const toggle = (key: BoolKey) => {
      const control = new Toggle(this, CONTROL_X + 80, 0, s[key], (v) => settings.set(key, v));
      this.toggles[key] = control;
      return control;
    };

    rows.push({ label: t.settings.music, control: slider('musicVolume') });
    rows.push({ label: t.settings.sfx, control: slider('sfxVolume') });
    rows.push({ label: t.settings.mute, control: toggle('muted') });
    rows.push({ label: t.settings.particles, control: toggle('particles') });
    rows.push({ label: t.settings.fps, control: toggle('showFps') });

    this.fullscreenToggle = new Toggle(this, CONTROL_X + 80, 0, this.scale.isFullscreen, () => this.scale.toggleFullscreen());
    rows.push({ label: t.settings.fullscreen, control: this.fullscreenToggle });

    rows.forEach((row, i) => {
      const y = ROW_Y0 + i * ROW_DY;
      const label = this.add.text(LABEL_X, y, row.label, textStyle(26)).setOrigin(0, 0.5);
      row.control.y = y;
      this.root.add([label, row.control]);
      for (const obj of [label, row.control]) {
        const targetX = obj.x;
        obj.x = targetX - 40;
        (obj as unknown as Phaser.GameObjects.Components.Alpha).setAlpha(0);
        this.tweens.add({ targets: obj, x: targetX, alpha: 1, delay: 150 + i * 60, duration: 380, ease: 'Back.easeOut' });
      }
    });

    const buttonsY = PANEL_Y + PANEL_H / 2 - 62;
    const reset = new Button(this, CENTER_X - 130, buttonsY, { label: t.settings.reset, variant: 'stone', width: 220, height: 60, fontSize: 24 })
      .onClick(() => this.resetSettings());
    const done = new Button(this, CENTER_X + 130, buttonsY, { label: t.common.ok, icon: Tex.Icon.Check, variant: 'green', width: 220, height: 60, fontSize: 24 })
      .onClick(() => this.back());
    this.root.add([reset, done]);

    const syncFullscreen = () => this.fullscreenToggle?.setValue(this.scale.isFullscreen, true);
    this.scale.on(Phaser.Scale.Events.ENTER_FULLSCREEN, syncFullscreen);
    this.scale.on(Phaser.Scale.Events.LEAVE_FULLSCREEN, syncFullscreen);
    this.events.once(Phaser.Scenes.Events.SHUTDOWN, () => {
      this.scale.off(Phaser.Scale.Events.ENTER_FULLSCREEN, syncFullscreen);
      this.scale.off(Phaser.Scale.Events.LEAVE_FULLSCREEN, syncFullscreen);
    });
  }

  protected override onBack(): void {
    this.back();
  }

  private resetSettings(): void {
    settings.reset();
    const s = settings.get();
    this.sliders.musicVolume?.setValue(s.musicVolume);
    this.sliders.sfxVolume?.setValue(s.sfxVolume);
    for (const [key, control] of Object.entries(this.toggles) as [BoolKey, Toggle][]) control.setValue(s[key], true);
    showToast(this, t.settings.resetDone);
  }
}
