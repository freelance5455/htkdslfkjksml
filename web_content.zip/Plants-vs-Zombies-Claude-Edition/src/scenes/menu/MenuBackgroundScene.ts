import Phaser from 'phaser';
import { GAME_HEIGHT, GAME_WIDTH } from '@/config/constants';
import { RegistryKeys, SceneKeys } from '@/core/SceneKeys';
import { settings } from '@/core/SettingsManager';
import { audio } from '@/audio/AudioManager';
import { getWorld, type WorldId } from '@/data/worlds';
import { Tex } from '@/graphics/TextureKeys';
import { PLANT_ORIGIN } from '@/graphics/textures/characters';
import { LAWN_HEIGHT } from '@/graphics/textures/environment';
import { textStyle } from '@/ui/theme';
import { BaseScene } from '../BaseScene';
import { MenuZombie } from './components/MenuZombie';

const LAWN_TOP = GAME_HEIGHT - LAWN_HEIGHT;
const LANE_Y = 655;
const PEA_SPEED = 480;
const SHOOT_INTERVAL = 1.5;
const ZOMBIE_SPAWN_X = GAME_WIDTH + 90;
const SUN_BANK = { x: 30, y: GAME_HEIGHT - 42 };

const Depth = {
  Sky: 0,
  Sun: 2,
  Clouds: 3,
  Hills: 4,
  Lawn: 6,
  Actors: 10,
  Peas: 12,
  Overlay: 20,
  NightSky: 21,
  Leaves: 25,
  Suns: 30,
  Bank: 40,
} as const;

interface Cloud {
  image: Phaser.GameObjects.Image;
  speed: number;
}

/**
 * Живой фон всех экранов меню: небо, облака, лужайка, растения отстреливаются от зомби,
 * с неба падают солнышки, которые можно ловить. Работает постоянно, пока игрок в меню.
 */
export class MenuBackgroundScene extends BaseScene {
  private clouds: Cloud[] = [];
  private peas: Phaser.GameObjects.Image[] = [];
  private sun!: Phaser.GameObjects.Image;
  private sunRays!: Phaser.GameObjects.Image;
  private moon!: Phaser.GameObjects.Image;
  private stars!: Phaser.GameObjects.Graphics;
  private overlay!: Phaser.GameObjects.Rectangle;
  private peashooter!: Phaser.GameObjects.Image;
  private zombie!: MenuZombie;
  private splat!: Phaser.GameObjects.Particles.ParticleEmitter;
  private leaves!: Phaser.GameObjects.Particles.ParticleEmitter;
  private bank!: Phaser.GameObjects.Container;
  private bankText!: Phaser.GameObjects.Text;
  private sunCount = 0;
  private shootTimer = 0;
  private elapsed = 0;
  private world: WorldId = 'day';

  constructor() {
    super(SceneKeys.MenuBackground);
  }

  create(): void {
    this.clouds = [];
    this.peas = [];
    this.shootTimer = 1.2;
    this.elapsed = 0;
    this.cameras.main.resetFX();
    this.cameras.main.fadeIn(400, 0, 0, 0);

    this.createSky();
    this.createGround();
    this.createActors();
    this.createEffects();
    this.createSunBank();

    this.applyWorld((this.registry.get(RegistryKeys.MenuWorld) as WorldId | undefined) ?? 'day', false);
    this.listen('menu:world-preview', (world) => this.applyWorld(world, true));
    this.listen('settings:changed', (s) => this.setParticles(s.particles));
    this.setParticles(settings.get().particles);

    this.time.addEvent({ delay: 6500, loop: true, callback: () => this.spawnSunDrop() });
    this.time.delayedCall(2500, () => this.spawnSunDrop());
  }

  update(_time: number, deltaMs: number): void {
    const dt = deltaMs / 1000;
    this.elapsed += dt;

    this.sunRays.angle += dt * 7;
    this.sun.setScale(1 + Math.sin(this.elapsed * 1.8) * 0.03);
    for (const cloud of this.clouds) {
      cloud.image.x += cloud.speed * dt;
      if (cloud.image.x - cloud.image.displayWidth / 2 > GAME_WIDTH) cloud.image.x = -cloud.image.displayWidth / 2;
    }

    this.zombie.update(dt);
    if (this.zombie.alive && this.zombie.x < GAME_WIDTH + 10) {
      this.shootTimer -= dt;
      if (this.shootTimer <= 0) {
        this.shoot();
        this.shootTimer = SHOOT_INTERVAL;
      }
    }

    for (let i = this.peas.length - 1; i >= 0; i--) {
      const pea = this.peas[i];
      pea.x += PEA_SPEED * dt;
      const hitZombie = this.zombie.alive && pea.x >= this.zombie.hitX;
      if (hitZombie || pea.x > GAME_WIDTH + 40) {
        if (hitZombie) this.onPeaHit(pea);
        pea.destroy();
        this.peas.splice(i, 1);
      }
    }
  }

  private createSky(): void {
    this.add.image(0, 0, Tex.Env.Sky).setOrigin(0).setDepth(Depth.Sky);

    this.stars = this.add.graphics().setDepth(Depth.NightSky).setAlpha(0);
    const rnd = new Phaser.Math.RandomDataGenerator(['stars']);
    for (let i = 0; i < 90; i++) {
      this.stars.fillStyle(0xffffff, rnd.realInRange(0.5, 1));
      this.stars.fillCircle(rnd.between(0, GAME_WIDTH), rnd.between(0, 230), rnd.realInRange(0.8, 2.2));
    }

    const sunX = 1130;
    const sunY = 110;
    this.sunRays = this.add.image(sunX, sunY, Tex.Env.SunRays).setDepth(Depth.Sun);
    this.sun = this.add.image(sunX, sunY, Tex.Env.Sun).setDepth(Depth.Sun);
    this.moon = this.add.image(sunX, sunY, Tex.Env.Moon).setDepth(Depth.NightSky).setAlpha(0);

    const rndCloud = new Phaser.Math.RandomDataGenerator(['clouds']);
    const specs = Array.from({ length: 7 }, (_, i) => ({ i, scale: rndCloud.realInRange(0.45, 1.1) })).sort(
      (a, b) => a.scale - b.scale,
    );
    for (const { i, scale } of specs) {
      const image = this.add
        .image(rndCloud.between(-100, GAME_WIDTH + 100), rndCloud.between(30, 230), Tex.Env.Clouds[i % 3])
        .setScale(scale)
        .setAlpha(0.75 + scale * 0.2)
        .setDepth(Depth.Clouds);
      this.clouds.push({ image, speed: 5 + scale * 14 });
    }
  }

  private createGround(): void {
    this.add.image(0, 220, Tex.Env.HillsFar).setOrigin(0).setDepth(Depth.Hills);
    this.add.image(0, 290, Tex.Env.HillsNear).setOrigin(0).setDepth(Depth.Hills);
    this.add.image(0, LAWN_TOP - 98, Tex.Env.Fence).setOrigin(0).setDepth(Depth.Hills);
    this.add.image(0, LAWN_TOP, Tex.Env.Lawn).setOrigin(0).setDepth(Depth.Lawn);
    this.add.image(1215, 560, Tex.Env.Tombstone).setScale(0.75).setDepth(Depth.Lawn);
    this.add.image(1010, 520, Tex.Env.Tombstone).setScale(0.55).setAngle(-6).setDepth(Depth.Lawn);

    this.overlay = this.add
      .rectangle(0, 0, GAME_WIDTH, GAME_HEIGHT, 0x000000, 1)
      .setOrigin(0)
      .setAlpha(0)
      .setDepth(Depth.Overlay);
  }

  private createActors(): void {
    const sunflower = this.add
      .image(100, LANE_Y - 4, Tex.Plant.Sunflower)
      .setOrigin(PLANT_ORIGIN.sunflower.x, PLANT_ORIGIN.sunflower.y)
      .setDepth(Depth.Actors);
    this.peashooter = this.add
      .image(232, LANE_Y, Tex.Plant.Peashooter)
      .setOrigin(PLANT_ORIGIN.peashooter.x, PLANT_ORIGIN.peashooter.y)
      .setDepth(Depth.Actors);
    const wallnut = this.add
      .image(380, GAME_HEIGHT - 6, Tex.Plant.Wallnut)
      .setOrigin(PLANT_ORIGIN.wallnut.x, PLANT_ORIGIN.wallnut.y)
      .setScale(0.85)
      .setDepth(Depth.Actors + 1);

    const sway = (target: Phaser.GameObjects.Image, angle: number, duration: number, delay: number) =>
      this.tweens.add({ targets: target, angle: { from: -angle, to: angle }, yoyo: true, repeat: -1, duration, delay, ease: 'Sine.easeInOut' });
    sway(sunflower, 4, 1500, 0);
    sway(this.peashooter, 3, 1300, 300);
    this.tweens.add({ targets: wallnut, scaleY: 0.8, yoyo: true, repeat: -1, duration: 1100, ease: 'Sine.easeInOut' });

    this.zombie = new MenuZombie(this, ZOMBIE_SPAWN_X - 60, LANE_Y);
    this.zombie.setDepth(Depth.Actors);
  }

  private createEffects(): void {
    this.splat = this.add
      .particles(0, 0, Tex.Fx.Splat, {
        speed: { min: 60, max: 180 },
        angle: { min: 120, max: 240 },
        lifespan: 450,
        scale: { start: 1, end: 0.2 },
        gravityY: 400,
        emitting: false,
      })
      .setDepth(Depth.Peas);

    this.leaves = this.add
      .particles(0, 0, Tex.Fx.Leaf, {
        x: { min: -50, max: GAME_WIDTH },
        y: -20,
        lifespan: 16000,
        speedY: { min: 25, max: 55 },
        speedX: { min: -10, max: 40 },
        rotate: { start: 0, end: 540 },
        scale: { min: 0.6, max: 1.15 },
        alpha: { start: 0.95, end: 0.6 },
        frequency: 900,
      })
      .setDepth(Depth.Leaves);
  }

  private createSunBank(): void {
    const bg = this.add.graphics();
    bg.fillStyle(0x000000, 0.25).fillRoundedRect(0, 4, 150, 54, 18);
    bg.fillStyle(0x3b2a18, 0.85).fillRoundedRect(0, 0, 150, 54, 18);
    bg.lineStyle(3, 0xffd23f, 1).strokeRoundedRect(2, 2, 146, 50, 16);
    const icon = this.add.image(30, 27, Tex.Fx.SunDrop).setScale(0.55);
    this.bankText = this.add.text(62, 27, '0', textStyle(26)).setOrigin(0, 0.5);
    this.bank = this.add
      .container(SUN_BANK.x, SUN_BANK.y - 27, [bg, icon, this.bankText])
      .setDepth(Depth.Bank)
      .setAlpha(0);
    this.sunCount = 0;
  }

  private setParticles(enabled: boolean): void {
    if (enabled) this.leaves.start();
    else this.leaves.stop();
  }

  private applyWorld(id: WorldId, animate: boolean): void {
    const world = getWorld(id);
    const night = id === 'night';
    const duration = animate ? 600 : 0;
    const prev = getWorld(this.world);
    this.world = id;

    this.tweens.killTweensOf([this.overlay, this.stars, this.moon, this.sun, this.sunRays]);
    if (!animate) {
      this.overlay.setFillStyle(world.overlayColor, 1).setAlpha(world.overlayAlpha);
    } else if (prev.overlayColor !== world.overlayColor && this.overlay.alpha > 0.01) {
      this.tweens.chain({
        targets: this.overlay,
        tweens: [
          { alpha: 0, duration: 220 },
          {
            alpha: world.overlayAlpha,
            duration: 450,
            onStart: () => this.overlay.setFillStyle(world.overlayColor, 1),
          },
        ],
      });
    } else {
      this.overlay.setFillStyle(world.overlayColor, 1);
      this.tweens.add({ targets: this.overlay, alpha: world.overlayAlpha, duration });
    }

    const fadeTo = (target: Phaser.GameObjects.Image | Phaser.GameObjects.Graphics, alpha: number) => {
      if (duration === 0) target.setAlpha(alpha);
      else this.tweens.add({ targets: target, alpha, duration });
    };
    fadeTo(this.stars, night ? 1 : 0);
    fadeTo(this.moon, night ? 1 : 0);
    fadeTo(this.sun, night ? 0 : 1);
    fadeTo(this.sunRays, night ? 0 : 0.9);
  }

  private shoot(): void {
    const pea = this.add
      .image(this.peashooter.x + 66, this.peashooter.y - 100, Tex.Fx.Pea)
      .setDepth(Depth.Peas);
    this.peas.push(pea);
    this.tweens.add({
      targets: this.peashooter,
      scaleX: 0.9,
      scaleY: 1.08,
      duration: 80,
      yoyo: true,
      ease: 'Quad.easeOut',
    });
  }

  private onPeaHit(pea: Phaser.GameObjects.Image): void {
    if (settings.get().particles) this.splat.explode(8, pea.x, pea.y);
    const died = this.zombie.hit();
    if (died) this.time.delayedCall(3800, () => this.zombie.respawn(ZOMBIE_SPAWN_X));
  }

  private spawnSunDrop(): void {
    const x = Phaser.Math.Between(80, GAME_WIDTH - 80);
    const targetY = Phaser.Math.Between(LAWN_TOP + 30, GAME_HEIGHT - 40);
    const sun = this.add.image(x, -50, Tex.Fx.SunDrop).setDepth(Depth.Suns).setInteractive({ useHandCursor: true });
    this.tweens.add({ targets: sun, angle: 360, duration: 6000, repeat: -1 });
    this.tweens.add({
      targets: sun,
      y: targetY,
      duration: ((targetY + 50) / 55) * 1000,
      onComplete: () => {
        this.tweens.add({
          targets: sun,
          alpha: 0,
          delay: 7000,
          duration: 600,
          onComplete: () => sun.destroy(),
        });
      },
    });
    sun.once(Phaser.Input.Events.GAMEOBJECT_POINTER_DOWN, () => this.collectSun(sun));
  }

  private collectSun(sun: Phaser.GameObjects.Image): void {
    sun.disableInteractive();
    audio.sfx('sun');
    this.tweens.killTweensOf(sun);
    if (this.bank.alpha < 1) this.tweens.add({ targets: this.bank, alpha: 1, duration: 300 });
    this.tweens.add({
      targets: sun,
      x: SUN_BANK.x + 30,
      y: SUN_BANK.y,
      scale: 0.5,
      duration: 650,
      ease: 'Cubic.easeInOut',
      onComplete: () => {
        sun.destroy();
        this.sunCount += 25;
        this.bankText.setText(String(this.sunCount));
        this.tweens.add({ targets: this.bank, scale: { from: 1.15, to: 1 }, duration: 260, ease: 'Back.easeOut' });
      },
    });
  }
}
