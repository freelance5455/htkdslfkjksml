import Phaser from 'phaser';
import { CENTER_X } from '@/config/constants';
import { eventBus } from '@/core/EventBus';
import { SceneKeys } from '@/core/SceneKeys';
import { saves } from '@/core/SaveManager';
import { countStars, getNextLevel, getStars, isLevelCompleted, isLevelUnlocked, isWorldUnlocked, MAX_STARS } from '@/core/progress';
import { audio } from '@/audio/AudioManager';
import { getLevelsOfWorld, type LevelDef } from '@/data/levels';
import { getLevelScript, hasLevelScript } from '@/data/levelScripts';
import { PLANTS } from '@/data/plants';
import { WORLDS, type WorldId } from '@/data/worlds';
import { Tex } from '@/graphics/TextureKeys';
import { ensurePanelTexture } from '@/graphics/textures/ui';
import { t } from '@/i18n/ru';
import { Button, RoundButton } from '@/ui/Button';
import { openCreateProfileDialog } from '@/ui/dialogs';
import { showToast } from '@/ui/Toast';
import { textStyle } from '@/ui/theme';
import { MenuScene } from './MenuScene';
import { LevelCard } from './components/LevelCard';
import { WorldTab } from './components/WorldTab';

export interface LevelSelectData {
  world?: WorldId;
}

const GRID_COLS = 5;
const GRID_DX = 176;
const GRID_Y = [300, 448];

export class LevelSelectScene extends MenuScene {
  private worldIndex = 0;
  private selected: LevelDef | null = null;
  private tabs: WorldTab[] = [];
  private cards: LevelCard[] = [];
  private infoTitle!: Phaser.GameObjects.Text;
  private infoDetails!: Phaser.GameObjects.Text;
  private playButton!: Button;

  constructor() {
    super(SceneKeys.LevelSelect);
  }

  create(data: LevelSelectData = {}): void {
    const save = saves.active;
    const next = getNextLevel(save);
    const worldId = data.world ?? next.world;
    this.worldIndex = Math.max(0, WORLDS.findIndex((w) => w.id === worldId));
    this.selected = next.world === worldId && isLevelUnlocked(save, next.id) ? next : null;
    this.tabs = [];
    this.cards = [];

    this.initMenu(worldId);
    this.createHeader();
    this.createTabs();
    this.createInfoPanel();
    this.buildGrid(false);
    this.updateInfo();
  }

  protected override onBack(): void {
    this.back();
  }

  private createHeader(): void {
    const back = new RoundButton(this, 60, 56, Tex.Icon.Back).onClick(() => this.back());
    const title = this.add.text(CENTER_X, 56, t.levels.title, textStyle(46)).setOrigin(0.5);
    this.root.add([back, title]);

    const save = saves.active;
    if (save) {
      const star = this.add.image(1130, 56, Tex.Ui.Star).setScale(0.8);
      const total = this.add.text(1156, 56, `${countStars(save)} / ${MAX_STARS}`, textStyle(24)).setOrigin(0, 0.5);
      this.root.add([star, total]);
    }
  }

  private createTabs(): void {
    WORLDS.forEach((world, i) => {
      const tab = new WorldTab(this, CENTER_X + (i - 2) * 220, 150, world).onClick(() => this.selectWorld(i));
      this.tabs.push(tab);
      this.root.add(tab);
    });
    this.refreshTabs();
  }

  private refreshTabs(): void {
    const save = saves.active;
    this.tabs.forEach((tab, i) => tab.setTabState(i === this.worldIndex, !isWorldUnlocked(save, tab.world.id)));
  }

  private createInfoPanel(): void {
    const tex = ensurePanelTexture(this.textures, 'wood', 940, 116);
    const panel = this.add.image(CENTER_X, 616, tex.key).setOrigin(tex.originX, tex.originY);
    this.infoTitle = this.add.text(CENTER_X - 420, 596, '', textStyle(30)).setOrigin(0, 0.5);
    this.infoDetails = this.add.text(CENTER_X - 420, 638, '', textStyle(19)).setOrigin(0, 0.5);
    this.playButton = new Button(this, CENTER_X + 330, 614, {
      label: t.common.play,
      icon: Tex.Icon.Play,
      variant: 'green',
      width: 220,
      height: 70,
    }).onClick(() => this.play());
    this.root.add([panel, this.infoTitle, this.infoDetails, this.playButton]);
  }

  private selectWorld(index: number): void {
    if (index === this.worldIndex) return;
    const world = WORLDS[index];
    if (!isWorldUnlocked(saves.active, world.id)) {
      this.tabs[index].shake();
      audio.sfx('error');
      showToast(this, t.levels.lockedWorld(world.name));
      return;
    }
    this.worldIndex = index;
    this.selected = null;
    this.refreshTabs();
    eventBus.emit('menu:world-preview', world.id);
    this.buildGrid(true);
    this.updateInfo();
  }

  private buildGrid(animate: boolean): void {
    for (const old of this.cards) {
      old.disableInteractive();
      this.tweens.add({ targets: old, scale: 0, alpha: 0, duration: 160, ease: 'Back.easeIn', onComplete: () => old.destroy() });
    }

    const save = saves.active;
    const levels = getLevelsOfWorld(WORLDS[this.worldIndex].id);
    this.cards = levels.map((level, i) => {
      const col = i % GRID_COLS;
      const row = Math.floor(i / GRID_COLS);
      const state = !isLevelUnlocked(save, level.id) ? 'locked' : isLevelCompleted(save, level.id) ? 'done' : 'open';
      const card = new LevelCard(this, CENTER_X + (col - 2) * GRID_DX, GRID_Y[row], level, state, getStars(save, level.id));
      card.onClick(() => this.onCardClick(card));
      card.setSelected(level === this.selected);
      this.root.add(card);
      card.setScale(0).setAlpha(0);
      this.tweens.add({
        targets: card,
        scale: 1,
        alpha: 1,
        delay: (animate ? 160 : 250) + i * 40,
        duration: 380,
        ease: 'Back.easeOut',
      });
      return card;
    });
  }

  private onCardClick(card: LevelCard): void {
    if (card.locked) {
      card.shake();
      audio.sfx('error');
      showToast(this, t.levels.lockedLevel);
      return;
    }
    if (this.selected === card.level) {
      this.play();
      return;
    }
    this.selected = card.level;
    for (const c of this.cards) c.setSelected(c === card);
    this.updateInfo();
  }

  private updateInfo(): void {
    const level = this.selected;
    const script = level ? getLevelScript(level.id) : undefined;
    this.playButton.setEnabled(script !== undefined);
    if (!level) {
      this.infoTitle.setText(t.levels.pick);
      this.infoDetails.setText(t.levels.pickHint);
      return;
    }
    const world = WORLDS[level.worldIndex];
    this.infoTitle.setText(`${t.levels.level(level.id)} · ${world.name}`);
    if (!script) {
      this.infoDetails.setText(t.game.comingSoon);
      return;
    }
    const parts = [t.levels.waves(script.waves.length)];
    if (level.rewardPlant) parts.push(t.levels.reward(PLANTS[level.rewardPlant].name));
    const stars = getStars(saves.active, level.id);
    if (stars > 0) parts.push(`${t.levels.best}: ${'★'.repeat(stars)}${'☆'.repeat(3 - stars)}`);
    this.infoDetails.setText(parts.join('   ·   '));
    this.tweens.add({ targets: [this.infoTitle, this.infoDetails], alpha: { from: 0.3, to: 1 }, duration: 200 });
  }

  private play(): void {
    const level = this.selected;
    if (!level || !hasLevelScript(level.id)) return;
    if (saves.active) {
      this.goTo(SceneKeys.Game, { levelId: level.id }, { fadeToBlack: true });
      return;
    }
    const slot = saves.firstEmptySlot();
    if (slot === null) {
      showToast(this, t.saves.noFreeSlots);
      this.goTo(SceneKeys.Saves);
      return;
    }
    openCreateProfileDialog(this, slot, () => {
      this.time.delayedCall(250, () => this.goTo(SceneKeys.Game, { levelId: level.id }, { fadeToBlack: true }));
    });
  }
}
