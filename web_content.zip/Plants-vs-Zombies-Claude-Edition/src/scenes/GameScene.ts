import Phaser from 'phaser';
import { GAME_HEIGHT, GAME_WIDTH } from '@/config/constants';
import { SceneKeys } from '@/core/SceneKeys';
import { saves } from '@/core/SaveManager';
import { audio } from '@/audio/AudioManager';
import { getLevel, LEVELS, type LevelDef } from '@/data/levels';
import { getLevelScript, hasLevelScript, scriptZombieTypes } from '@/data/levelScripts';
import { ZOMBIES } from '@/data/zombies';
import { Tex } from '@/graphics/TextureKeys';
import { ensureGameBackground } from '@/graphics/textures/game';
import { isPlayable, MAX_SEED_SLOTS, ZOMBIE_SCALE, type PlayablePlant } from '@/game/balance';
import { BOARD, BOARD_RIGHT, DEPTH_TOP, rowGroundY, WORLD_WIDTH } from '@/game/Board';
import type { Zombie } from '@/game/entities/Zombie';
import { LevelSession, type GameSpeed, type SessionRequest } from '@/game/LevelSession';
import { PlacementController } from '@/game/systems/PlacementController';
import { SunSpawner } from '@/game/systems/SunSpawner';
import { WaveDirector } from '@/game/systems/WaveDirector';
import { startTutorial } from '@/game/Tutorial';
import { createPacketView } from '@/game/view/plantVisuals';
import { rigOptionsFor, ZombieRig } from '@/game/view/ZombieRig';
import { World } from '@/game/World';
import { t } from '@/i18n/ru';
import { BaseScene } from './BaseScene';

export interface GameSceneData {
  levelId?: string;
}

/**
 * Игровая сцена: поле и всё, что на нём происходит. Интерфейс (панель семян,
 * скорость, шкала волн, пауза, итоги) живёт в GameHudScene поверх неё
 * и общается через LevelSession.
 */
export class GameScene extends BaseScene {
  private level!: LevelDef;
  private session!: LevelSession;
  private world!: World;
  private waves!: WaveDirector;
  private sunSpawner!: SunSpawner;
  private previews: ZombieRig[] = [];
  private leaving = false;
  private startedAt = 0;

  constructor() {
    super(SceneKeys.Game);
  }

  create(data: GameSceneData = {}): void {
    const level = getLevel(data.levelId ?? '') ?? LEVELS[0];
    const script = getLevelScript(level.id);
    if (!script) {
      this.leaving = true;
      this.scene.launch(SceneKeys.MenuBackground);
      this.scene.start(SceneKeys.LevelSelect, { world: level.world });
      return;
    }
    this.level = level;
    this.leaving = false;
    this.previews = [];
    this.startedAt = Date.now();
    this.scene.stop(SceneKeys.MenuBackground);

    this.session = new LevelSession(level, script, this.availablePlants());
    const cam = this.cameras.main;
    cam.resetFX();
    cam.setZoom(1).setScroll(0, 0).setBounds(0, 0, WORLD_WIDTH, GAME_HEIGHT);
    cam.fadeIn(450, 0, 0, 0);
    this.input.mouse?.disableContextMenu();

    this.add.image(0, 0, ensureGameBackground(this.textures, script.rows)).setOrigin(0);
    this.world = new World(this, this.session);
    this.waves = new WaveDirector(this.world, this.session);
    this.sunSpawner = new SunSpawner(this.world, this.session);
    new PlacementController(this, this.world, this.session);

    this.world.onHouseReached = (z) => this.defeat(z);
    this.waves.onVictory = () => this.victory();
    this.session.on('speed-changed', (s) => this.applySpeed(s));
    this.session.on('request', (action) => this.handleRequest(action));
    this.applySpeed(1);

    this.events.once(Phaser.Scenes.Events.SHUTDOWN, () => this.cleanup());
    audio.setTempo(1);
    audio.playMusic('battle');
    this.scene.launch(SceneKeys.GameHud, { session: this.session });
    this.playIntro();
  }

  update(_time: number, deltaMs: number): void {
    if (this.leaving) return;
    const realDt = Math.min(deltaMs, 50) / 1000;
    const phase = this.session.phase;
    if (phase === 'intro') {
      for (const rig of this.previews) rig.animate(realDt, 'idle');
      return;
    }
    if (phase !== 'playing' && phase !== 'victory') return;
    const dt = realDt * this.session.speed;
    this.session.update(dt);
    this.world.update(dt);
    if (this.session.phase === 'playing') {
      this.waves.update(dt);
      this.sunSpawner.update(dt);
    }
  }

  private availablePlants(): PlayablePlant[] {
    const unlocked = saves.active?.unlockedPlants ?? ['peashooter'];
    return unlocked.filter(isPlayable).slice(0, MAX_SEED_SLOTS);
  }

  private applySpeed(speed: GameSpeed): void {
    this.tweens.timeScale = speed;
    this.time.timeScale = speed;
    this.world.setTimeScale(speed);
  }

  /** Камера показывает улицу с зомби этого уровня, возвращается — и «Приготовься… САЖАЙ!». */
  private playIntro(): void {
    const types = scriptZombieTypes(this.session.script);
    const slots = 7;
    for (let i = 0; i < slots; i++) {
      const def = ZOMBIES[types[i % types.length]];
      const x = BOARD_RIGHT + 260 + (i % 3) * 90 + Phaser.Math.Between(-20, 20);
      const row = i % BOARD.rows;
      const rig = new ZombieRig(this, x, rowGroundY(row), { ...rigOptionsFor(def), flag: def.flag && i === 0 })
        .setScale(ZOMBIE_SCALE)
        .setDepth(100 + row * 100 + 50);
      this.previews.push(rig);
    }

    const cam = this.cameras.main;
    this.time.delayedCall(700, () => cam.pan(WORLD_WIDTH - GAME_WIDTH / 2, GAME_HEIGHT / 2, 1400, 'Sine.easeInOut'));
    this.time.delayedCall(3900, () => cam.pan(GAME_WIDTH / 2, GAME_HEIGHT / 2, 1200, 'Sine.easeInOut'));
    this.time.delayedCall(5150, () => {
      for (const rig of this.previews) rig.destroy();
      this.previews = [];
      this.session.emit('banner', 'ready');
    });
    this.time.delayedCall(7000, () => this.startPlaying());
  }

  private startPlaying(): void {
    this.session.setPhase('playing');
    startTutorial(this.session, (sec) => this.time.delayedCall(sec * 1000, () => this.session.hint(null)));
  }

  private victory(): void {
    this.session.setPhase('victory');
    this.session.setSpeed(1);
    this.session.hint(t.game.collectReward);
    audio.stopMusic();
    audio.sfx('victory');

    const save = saves.active;
    const reward = this.level.rewardPlant;
    const newPlant = reward && save && !save.unlockedPlants.includes(reward) ? reward : undefined;
    const { x, y } = this.world.lastKill;
    const px = Phaser.Math.Clamp(x, BOARD.x + 60, BOARD_RIGHT - 60);

    const item = newPlant ? createPacketView(this, newPlant) : this.add.container(0, 0, [this.add.image(0, 0, Tex.Ui.Star).setScale(1.4)]);
    const glow = this.add.image(0, 0, Tex.Fx.Spark).setScale(6).setBlendMode(Phaser.BlendModes.ADD).setAlpha(0.7);
    item.addAt(glow, 0);
    item.setPosition(px, y - 40).setDepth(DEPTH_TOP + 20).setScale(0);
    this.tweens.add({ targets: item, scale: 1, y: y - 60, duration: 500, ease: 'Back.easeOut' });
    this.tweens.add({ targets: glow, scale: 8, alpha: 0.35, yoyo: true, repeat: -1, duration: 700 });
    this.tweens.add({ targets: item, angle: { from: -6, to: 6 }, yoyo: true, repeat: -1, duration: 900, ease: 'Sine.easeInOut' });

    item.setSize(80, 100).setInteractive({ useHandCursor: true });
    item.once(Phaser.Input.Events.GAMEOBJECT_POINTER_DOWN, () => {
      item.disableInteractive();
      this.session.hint(null);
      this.world.clearSuns();
      audio.sfx('sun');
      this.tweens.killTweensOf(item);
      this.tweens.add({
        targets: item,
        x: GAME_WIDTH / 2,
        y: GAME_HEIGHT / 2 - 40,
        scale: 2.2,
        angle: 0,
        duration: 900,
        ease: 'Cubic.easeInOut',
        onComplete: () => {
          this.cameras.main.flash(500, 255, 255, 240);
          item.destroy();
          this.finishVictory(newPlant);
        },
      });
    });
  }

  private finishVictory(newPlant: LevelDef['rewardPlant']): void {
    const stars = Phaser.Math.Clamp(3 - this.session.mowersUsed, 1, 3);
    saves.completeLevel(this.level.id, stars);
    const next = LEVELS[this.level.order + 1];
    this.session.emit('result', {
      victory: true,
      stars,
      mowersUsed: this.session.mowersUsed,
      newPlant,
      nextLevelId: next && hasLevelScript(next.id) ? next.id : undefined,
    });
  }

  private defeat(zombie: Zombie): void {
    if (this.session.phase !== 'playing') return;
    this.session.setPhase('defeat');
    this.session.setSpeed(1);
    this.world.frozen = true;
    audio.stopMusic();
    audio.sfx('lose');

    const rig = zombie.rig;
    rig.setDepth(DEPTH_TOP);
    this.tweens.addCounter({
      from: 0,
      to: 1,
      duration: 2200,
      onUpdate: () => rig.animate(1 / 60, 'walk'),
    });
    this.tweens.add({ targets: rig, x: 70, duration: 2200 });
    const cam = this.cameras.main;
    cam.pan(330, rig.y - 60, 1600, 'Sine.easeInOut');
    cam.zoomTo(1.6, 1600, 'Sine.easeInOut');
    this.time.delayedCall(1200, () => this.session.emit('banner', 'defeat'));
    this.time.delayedCall(3600, () => this.session.emit('result', { victory: false, stars: 0, mowersUsed: this.session.mowersUsed }));
  }

  private handleRequest(action: SessionRequest): void {
    switch (action) {
      case 'restart':
        this.transition(() => this.scene.restart({ levelId: this.level.id }));
        break;
      case 'next': {
        const next = LEVELS[this.level.order + 1];
        this.transition(() => this.scene.restart({ levelId: next?.id ?? this.level.id }));
        break;
      }
      case 'menu':
        this.exitTo(SceneKeys.MainMenu);
        break;
      case 'levels':
        this.exitTo(SceneKeys.LevelSelect, { world: this.level.world });
        break;
    }
  }

  private exitTo(target: string, data?: object): void {
    this.transition(() => {
      audio.setTempo(1);
      audio.playMusic('menu');
      this.scene.launch(SceneKeys.MenuBackground);
      this.scene.start(target, data);
    });
  }

  private transition(done: () => void): void {
    if (this.leaving) return;
    this.leaving = true;
    this.applySpeed(1);
    const cam = this.cameras.main;
    cam.fadeOut(320, 0, 0, 0);
    cam.once(Phaser.Cameras.Scene2D.Events.FADE_OUT_COMPLETE, done);
  }

  private cleanup(): void {
    const seconds = Math.round((Date.now() - this.startedAt) / 1000);
    saves.update((save) => {
      save.playTimeSec += seconds;
    });
    this.scene.stop(SceneKeys.GameHud);
    this.session.removeAll();
    this.tweens.timeScale = 1;
    this.time.timeScale = 1;
  }
}
