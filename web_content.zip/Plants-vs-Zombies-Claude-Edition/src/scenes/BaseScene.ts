import Phaser from 'phaser';
import { eventBus, type GameEvents } from '@/core/EventBus';

/** Общая база сцен: подписки на шину событий автоматически снимаются при остановке сцены. */
export abstract class BaseScene extends Phaser.Scene {
  protected listen<K extends keyof GameEvents>(event: K, fn: (...args: GameEvents[K]) => void): void {
    eventBus.on(event, fn, this);
    this.events.once(Phaser.Scenes.Events.SHUTDOWN, () => eventBus.off(event, fn, this));
  }
}
