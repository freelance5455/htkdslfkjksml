import Phaser from 'phaser';
import { SceneKeys } from '@/core/SceneKeys';
import { audio } from '@/audio/AudioManager';

const FONT_TIMEOUT_MS = 3000;

/** Первичная инициализация: разблокировка звука и ожидание шрифтов (их используют canvas-текстуры). */
export class BootScene extends Phaser.Scene {
  constructor() {
    super(SceneKeys.Boot);
  }

  create(): void {
    const unlock = () => audio.unlock();
    window.addEventListener('pointerdown', unlock);
    window.addEventListener('keydown', unlock);
    window.addEventListener('touchend', unlock);

    const fonts = Promise.all(['500', '700', '900'].map((w) => document.fonts.load(`${w} 32px Rubik`, 'АаZz')));
    const timeout = new Promise((resolve) => window.setTimeout(resolve, FONT_TIMEOUT_MS));
    void Promise.race([fonts, timeout])
      .catch(() => undefined)
      .then(() => this.scene.start(SceneKeys.Preload));
  }
}
