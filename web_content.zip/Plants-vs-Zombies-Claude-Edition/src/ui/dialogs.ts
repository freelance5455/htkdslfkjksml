import Phaser from 'phaser';
import { PROFILE_NAME_MAX, saves, type SaveData } from '@/core/SaveManager';
import { t } from '@/i18n/ru';
import { Modal } from './Modal';
import { showToast } from './Toast';

/** Диалог создания профиля в указанном слоте. Профиль сразу становится активным. */
export function openCreateProfileDialog(scene: Phaser.Scene, slot: number, onCreated?: (save: SaveData) => void): void {
  Modal.open(scene, {
    title: t.saves.createTitle,
    message: t.saves.createMessage,
    input: { value: `Игрок ${slot + 1}`, placeholder: t.saves.namePlaceholder, maxLength: PROFILE_NAME_MAX },
    buttons: [
      { label: t.common.cancel },
      {
        label: t.common.create,
        variant: 'green',
        onClick: (modal) => {
          const name = modal.inputValue.trim();
          if (!name) return false;
          const save = saves.create(slot, name);
          showToast(scene, t.saves.created(save.name));
          onCreated?.(save);
        },
      },
    ],
  });
}
