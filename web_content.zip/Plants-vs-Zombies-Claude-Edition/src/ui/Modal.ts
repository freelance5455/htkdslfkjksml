import Phaser from 'phaser';
import { CENTER_X, CENTER_Y, GAME_HEIGHT, GAME_WIDTH } from '@/config/constants';
import { audio } from '@/audio/AudioManager';
import { ensurePanelTexture, type ButtonVariant } from '@/graphics/textures/ui';
import { Button } from './Button';
import { textStyle } from './theme';

export interface ModalButton {
  label: string;
  variant?: ButtonVariant;
  /** Верните `false`, чтобы окно не закрылось (например, при ошибке ввода). */
  onClick?: (modal: Modal) => void | boolean;
}

export interface ModalConfig {
  title: string;
  message?: string;
  width?: number;
  input?: { value?: string; placeholder?: string; maxLength?: number };
  /** Последняя кнопка считается основной: срабатывает по Enter. */
  buttons: ModalButton[];
}

const openModals = new Set<Phaser.Scene>();

/** Модальное окно поверх сцены: затемнение, всплывающая панель, кнопки, опциональное поле ввода. */
export class Modal extends Phaser.GameObjects.Container {
  private readonly overlay: Phaser.GameObjects.Rectangle;
  private readonly box: Phaser.GameObjects.Container;
  private readonly inputEl?: HTMLInputElement;
  private readonly dom?: Phaser.GameObjects.DOMElement;
  private closing = false;

  static open(scene: Phaser.Scene, config: ModalConfig): Modal {
    return new Modal(scene, config);
  }

  static isOpen(scene: Phaser.Scene): boolean {
    return openModals.has(scene);
  }

  private constructor(scene: Phaser.Scene, private readonly config: ModalConfig) {
    super(scene, 0, 0);
    openModals.add(scene);
    this.setDepth(1000);

    this.overlay = scene.add.rectangle(0, 0, GAME_WIDTH, GAME_HEIGHT, 0x0a1405, 1).setOrigin(0).setAlpha(0);
    this.overlay.setInteractive();
    this.add(this.overlay);

    const width = config.width ?? 560;
    const title = scene.add.text(0, 0, config.title, textStyle(34)).setOrigin(0.5, 0);
    const message = config.message
      ? scene.add
          .text(0, 0, config.message, textStyle(22, { fontStyle: '700', strokeThickness: 4, align: 'center', wordWrap: { width: width - 90 } }))
          .setOrigin(0.5, 0)
      : null;

    let cursor = 44;
    const rows: { obj: Phaser.GameObjects.Text; y: number }[] = [{ obj: title, y: cursor }];
    cursor += title.height + 14;
    if (message) {
      rows.push({ obj: message, y: cursor });
      cursor += message.height + 18;
    }
    let inputY = 0;
    if (config.input) {
      inputY = cursor + 30;
      cursor += 80;
    }
    const buttonsY = cursor + 40;
    const height = buttonsY + 70;

    const tex = ensurePanelTexture(scene.textures, 'wood', width, height);
    const panel = scene.add.image(0, 0, tex.key).setOrigin(tex.originX, tex.originY);
    this.box = scene.add.container(CENTER_X, CENTER_Y);
    this.box.add(panel);
    const top = -height / 2;
    for (const row of rows) {
      row.obj.y = top + row.y;
      this.box.add(row.obj);
    }

    const count = config.buttons.length;
    const bw = Math.min(220, (width - 80 - (count - 1) * 20) / count);
    config.buttons.forEach((cfg, i) => {
      const bx = (i - (count - 1) / 2) * (bw + 20);
      const button = new Button(scene, bx, top + buttonsY, {
        label: cfg.label,
        variant: cfg.variant ?? 'wood',
        width: bw,
        height: 60,
        fontSize: 24,
      }).onClick(() => this.trigger(cfg));
      this.box.add(button);
    });
    this.add(this.box);

    if (config.input) {
      const el = document.createElement('input');
      el.className = 'pvz-input';
      el.type = 'text';
      el.maxLength = config.input.maxLength ?? 20;
      el.value = config.input.value ?? '';
      el.placeholder = config.input.placeholder ?? '';
      el.autocomplete = 'off';
      el.spellcheck = false;
      this.inputEl = el;
      this.dom = scene.add.dom(CENTER_X, CENTER_Y + top + inputY, el).setDepth(1001).setAlpha(0);
      scene.time.delayedCall(260, () => {
        el.focus();
        el.select();
      });
    }

    scene.input.keyboard?.on('keydown-ESC', this.handleEsc, this);
    scene.input.keyboard?.on('keydown-ENTER', this.handleEnter, this);
    this.once(Phaser.GameObjects.Events.DESTROY, () => {
      openModals.delete(scene);
      scene.input.keyboard?.off('keydown-ESC', this.handleEsc, this);
      scene.input.keyboard?.off('keydown-ENTER', this.handleEnter, this);
      this.dom?.destroy();
    });

    scene.add.existing(this);
    audio.sfx('whoosh');
    scene.tweens.add({ targets: this.overlay, alpha: 0.6, duration: 220 });
    this.box.setScale(0.6).setAlpha(0);
    scene.tweens.add({ targets: this.box, scale: 1, alpha: 1, duration: 320, ease: 'Back.easeOut' });
    if (this.dom) scene.tweens.add({ targets: this.dom, alpha: 1, duration: 200, delay: 160 });
  }

  get inputValue(): string {
    return this.inputEl?.value ?? '';
  }

  close(): void {
    if (this.closing) return;
    this.closing = true;
    this.inputEl?.blur();
    openModals.delete(this.scene);
    this.scene.tweens.add({ targets: this.overlay, alpha: 0, duration: 180 });
    if (this.dom) this.scene.tweens.add({ targets: this.dom, alpha: 0, duration: 120 });
    this.scene.tweens.add({
      targets: this.box,
      scale: 0.7,
      alpha: 0,
      duration: 180,
      ease: 'Back.easeIn',
      onComplete: () => this.destroy(),
    });
  }

  private trigger(button: ModalButton): void {
    if (this.closing) return;
    if (button.onClick?.(this) === false) {
      audio.sfx('error');
      return;
    }
    this.close();
  }

  private handleEsc(): void {
    if (this.closing) return;
    audio.sfx('back');
    this.close();
  }

  private handleEnter(): void {
    const primary = this.config.buttons[this.config.buttons.length - 1];
    if (primary) this.trigger(primary);
  }
}
