import Phaser from 'phaser';
import { FONT_FAMILY, TEXT_RESOLUTION } from '@/config/constants';

export const Colors = {
  cream: '#fff8e7',
  ink: '#3b2a18',
  inkSoft: '#6b5236',
  green: '#8fe03c',
  yellow: '#ffd23f',
  red: '#e0452f',
} as const;

type TextStyle = Phaser.Types.GameObjects.Text.TextStyle;

/** Светлый «мультяшный» текст с тёмной обводкой и тенью — для заголовков и кнопок. */
export function textStyle(size: number, overrides: TextStyle = {}): TextStyle {
  return {
    fontFamily: FONT_FAMILY,
    fontSize: `${size}px`,
    fontStyle: '900',
    color: Colors.cream,
    stroke: Colors.ink,
    strokeThickness: Math.max(3, Math.round(size / 6)),
    resolution: TEXT_RESOLUTION,
    shadow: {
      offsetX: 0,
      offsetY: Math.max(2, Math.round(size / 14)),
      color: 'rgba(0,0,0,0.35)',
      blur: 0,
      stroke: true,
      fill: true,
    },
    ...overrides,
  };
}

/** Тёмный текст без обводки — для светлых поверхностей (пергамент, карточки). */
export function inkStyle(size: number, overrides: TextStyle = {}): TextStyle {
  return {
    fontFamily: FONT_FAMILY,
    fontSize: `${size}px`,
    fontStyle: '700',
    color: Colors.ink,
    resolution: TEXT_RESOLUTION,
    ...overrides,
  };
}
