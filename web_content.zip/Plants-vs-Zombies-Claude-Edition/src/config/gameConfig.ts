import Phaser from 'phaser';
import { GAME_HEIGHT, GAME_WIDTH } from './constants';
import { BootScene } from '@/scenes/BootScene';
import { PreloadScene } from '@/scenes/PreloadScene';
import { MenuBackgroundScene } from '@/scenes/menu/MenuBackgroundScene';
import { MainMenuScene } from '@/scenes/menu/MainMenuScene';
import { LevelSelectScene } from '@/scenes/menu/LevelSelectScene';
import { SavesScene } from '@/scenes/menu/SavesScene';
import { SettingsScene } from '@/scenes/menu/SettingsScene';
import { GameScene } from '@/scenes/GameScene';
import { GameHudScene } from '@/scenes/GameHudScene';
import { HudOverlayScene } from '@/scenes/HudOverlayScene';

export function createGameConfig(): Phaser.Types.Core.GameConfig {
  return {
    type: Phaser.AUTO,
    parent: 'game',
    width: GAME_WIDTH,
    height: GAME_HEIGHT,
    backgroundColor: '#1b3310',
    scale: {
      mode: Phaser.Scale.FIT,
      autoCenter: Phaser.Scale.CENTER_BOTH,
    },
    dom: { createContainer: true },
    render: { antialias: true },
    // Порядок важен: сцены ниже по списку рисуются поверх предыдущих.
    scene: [
      BootScene,
      PreloadScene,
      MenuBackgroundScene,
      MainMenuScene,
      LevelSelectScene,
      SavesScene,
      SettingsScene,
      GameScene,
      GameHudScene,
      HudOverlayScene,
    ],
  };
}
