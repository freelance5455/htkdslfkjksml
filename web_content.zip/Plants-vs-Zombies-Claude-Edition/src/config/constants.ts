export const GAME_WIDTH = 1280;
export const GAME_HEIGHT = 720;
export const CENTER_X = GAME_WIDTH / 2;
export const CENTER_Y = GAME_HEIGHT / 2;

export const FONT_FAMILY = 'Rubik, "Arial Black", sans-serif';
/** Разрешение текстовых текстур: тексты остаются чёткими при масштабировании canvas. */
export const TEXT_RESOLUTION = 2;

export const GAME_VERSION = '0.2.0';
