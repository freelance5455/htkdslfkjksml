export type ZombieId = 'basic' | 'flag' | 'conehead' | 'polevaulter' | 'buckethead' | 'newspaper' | 'football';

export type ArmorKind = 'cone' | 'bucket';

export interface ZombieDef {
  id: ZombieId;
  name: string;
  hp: number;
  /** Скорость в клетках в секунду. */
  speed: number;
  armor?: ArmorKind;
  armorHp?: number;
  /** Несёт флаг — возглавляет огромную волну. */
  flag?: boolean;
  /** Внешний вид: спортивная форма вместо костюма. */
  outfit?: 'suit' | 'athlete';
  /** Бежит с шестом и перепрыгивает первое растение, затем идёт с этой скоростью. */
  vault?: { walkSpeed: number };
}

export const ZOMBIES: Record<ZombieId, ZombieDef> = {
  basic: { id: 'basic', name: 'Зомби', hp: 200, speed: 0.23 },
  flag: { id: 'flag', name: 'Знаменосец', hp: 200, speed: 0.32, flag: true },
  conehead: { id: 'conehead', name: 'Зомби с конусом', hp: 200, speed: 0.23, armor: 'cone', armorHp: 370 },
  polevaulter: {
    id: 'polevaulter',
    name: 'Прыгун с шестом',
    hp: 340,
    speed: 0.48,
    outfit: 'athlete',
    vault: { walkSpeed: 0.23 },
  },
  buckethead: { id: 'buckethead', name: 'Зомби с ведром', hp: 200, speed: 0.23, armor: 'bucket', armorHp: 1100 },
  newspaper: { id: 'newspaper', name: 'Зомби с газетой', hp: 200, speed: 0.23, armorHp: 150 },
  football: { id: 'football', name: 'Футболист', hp: 200, speed: 0.4, armorHp: 1400 },
};
