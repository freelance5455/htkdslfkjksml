import { WORLDS, type WorldId } from './worlds';
import type { PlantId } from './plants';

export const LEVELS_PER_WORLD = 10;

export interface LevelDef {
  /** Идентификатор вида «1-3». */
  id: string;
  world: WorldId;
  worldIndex: number;
  /** Номер уровня внутри мира, с 1. */
  number: number;
  /** Сквозной порядковый номер для разблокировки. */
  order: number;
  waves: number;
  rewardPlant?: PlantId;
}

const REWARDS: Record<WorldId, (PlantId | null)[]> = {
  day: ['sunflower', 'cherrybomb', 'wallnut', null, 'potatomine', 'snowpea', 'chomper', null, 'repeater', null],
  night: ['puffshroom', 'sunshroom', 'fumeshroom', 'gravebuster', null, 'hypnoshroom', 'scaredyshroom', 'iceshroom', 'doomshroom', null],
  pool: ['lilypad', 'squash', 'threepeater', 'tanglekelp', null, 'jalapeno', 'spikeweed', 'torchwood', 'tallnut', null],
  fog: [],
  roof: [],
};

export const LEVELS: LevelDef[] = WORLDS.flatMap((world, worldIndex) =>
  Array.from({ length: LEVELS_PER_WORLD }, (_, i) => ({
    id: `${worldIndex + 1}-${i + 1}`,
    world: world.id,
    worldIndex,
    number: i + 1,
    order: worldIndex * LEVELS_PER_WORLD + i,
    waves: 1 + Math.floor(i / 3) + worldIndex,
    rewardPlant: REWARDS[world.id][i] ?? undefined,
  })),
);

const byId = new Map(LEVELS.map((l) => [l.id, l]));

export function getLevel(id: string): LevelDef | undefined {
  return byId.get(id);
}

export function getLevelsOfWorld(world: WorldId): LevelDef[] {
  return LEVELS.filter((l) => l.world === world);
}
