import { eventBus } from './EventBus';
import { storage } from './storage';

export interface Settings {
  version: 1;
  musicVolume: number;
  sfxVolume: number;
  muted: boolean;
  particles: boolean;
  showFps: boolean;
}

const STORAGE_KEY = 'settings';

const DEFAULTS: Settings = {
  version: 1,
  musicVolume: 0.5,
  sfxVolume: 0.7,
  muted: false,
  particles: true,
  showFps: false,
};

const clamp01 = (v: unknown, fallback: number): number =>
  typeof v === 'number' && Number.isFinite(v) ? Math.min(1, Math.max(0, v)) : fallback;

const bool = (v: unknown, fallback: boolean): boolean => (typeof v === 'boolean' ? v : fallback);

function sanitize(raw: Partial<Settings> | null): Settings {
  const s = raw ?? {};
  return {
    version: 1,
    musicVolume: clamp01(s.musicVolume, DEFAULTS.musicVolume),
    sfxVolume: clamp01(s.sfxVolume, DEFAULTS.sfxVolume),
    muted: bool(s.muted, DEFAULTS.muted),
    particles: bool(s.particles, DEFAULTS.particles),
    showFps: bool(s.showFps, DEFAULTS.showFps),
  };
}

class SettingsManager {
  private data: Settings = sanitize(storage.get<Partial<Settings>>(STORAGE_KEY));

  get(): Readonly<Settings> {
    return this.data;
  }

  set<K extends keyof Settings>(key: K, value: Settings[K]): void {
    if (this.data[key] === value) return;
    this.data = { ...this.data, [key]: value };
    this.commit();
  }

  reset(): void {
    this.data = { ...DEFAULTS };
    this.commit();
  }

  private commit(): void {
    storage.set(STORAGE_KEY, this.data);
    eventBus.emit('settings:changed', this.data);
  }
}

export const settings = new SettingsManager();
