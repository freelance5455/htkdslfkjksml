import Phaser from 'phaser';
import { BOARD, colX, rowCenterY } from '../Board';
import type { LevelSession } from '../LevelSession';
import type { World } from '../World';

/** Дневное солнце, падающее с неба на активные линии. */
export class SunSpawner {
  private timer: number;

  constructor(
    private readonly world: World,
    private readonly session: LevelSession,
  ) {
    this.timer = session.script.skySun.first;
  }

  update(dt: number): void {
    this.timer -= dt;
    if (this.timer > 0) return;
    const { min, max } = this.session.script.skySun;
    this.timer = Phaser.Math.FloatBetween(min, max);
    const col = Phaser.Math.Between(0, BOARD.cols - 1);
    const row = Phaser.Utils.Array.GetRandom(this.session.script.rows);
    this.world.spawnSkySun(colX(col) + Phaser.Math.Between(-20, 20), rowCenterY(row) + 12);
  }
}
