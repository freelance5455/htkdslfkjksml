import Phaser from 'phaser';
import type { ArmorKind, ZombieDef } from '@/data/zombies';
import { Tex } from '@/graphics/TextureKeys';
import { ZOMBIE_ORIGIN } from '@/graphics/textures/zombies';

const BACK_TINT = 0xa9b29e;
const CHILL_TINT = 0x9fd6ff;
const CHILL_BACK_TINT = 0x7ea6c6;
const CHAR_TINT = 0x2a2622;

export type RigMode = 'walk' | 'run' | 'vault' | 'eat' | 'idle';

export interface RigOptions {
  armor?: ArmorKind;
  flag?: boolean;
  athlete?: boolean;
  pole?: boolean;
}

export function rigOptionsFor(def: ZombieDef): RigOptions {
  return { armor: def.armor, flag: def.flag, athlete: def.outfit === 'athlete', pole: Boolean(def.vault) };
}

/** Суставы в координатах куклы; ноги стоят в (0, 0), зомби смотрит влево. */
const POSE = {
  hipY: -80,
  frontLegX: -6,
  backLegX: 9,
  torsoY: -124,
  headX: -12,
  headY: -166,
  frontArmX: -20,
  backArmX: 16,
  armY: -154,
  flagX: 22,
  flagY: -112,
  poleX: -88,
  poleY: -128,
} as const;

/** Головные уборы крепятся к голове со смещением от шеи. */
const HATS = {
  cone: { key: Tex.Zombie.Cone, origin: { x: 0.5, y: 0.86 }, offset: { x: -2, y: -68 } },
  bucket: { key: Tex.Zombie.Bucket, origin: { x: 0.5, y: 0.84 }, offset: { x: -2, y: -46 } },
  headband: { key: Tex.Zombie.Headband, origin: { x: 0.5, y: 0.5 }, offset: { x: -4, y: -62 } },
} as const;

type Part = Phaser.GameObjects.Image;
type HatKind = keyof typeof HATS;

/**
 * Скелетная «кукла» зомби из частей: ходьба, бег, прыжок, поедание, вспышка урона,
 * заморозка, потеря руки и брони, разные смерти. Логики здесь нет — только внешний вид.
 */
export class ZombieRig extends Phaser.GameObjects.Container {
  protected readonly head: Part;
  protected readonly torso: Part;
  protected readonly frontArm: Part;
  protected readonly backArm: Part;
  protected readonly frontLeg: Part;
  protected readonly backLeg: Part;
  private armor: Part | null = null;
  private readonly armorKind?: ArmorKind;
  private headband: Part | null = null;
  private flag: Part | null = null;
  private pole: Part | null = null;
  private armorTint = 0xffffff;
  private chilled = false;
  private time = Math.random() * 10;

  constructor(scene: Phaser.Scene, x: number, y: number, options: RigOptions = {}) {
    super(scene, x, y);
    const part = (key: string, origin: { x: number; y: number }) => scene.add.image(0, 0, key).setOrigin(origin.x, origin.y);
    const athlete = Boolean(options.athlete);
    const armKey = athlete ? Tex.Zombie.ArmBare : Tex.Zombie.Arm;
    const legKey = athlete ? Tex.Zombie.LegAthlete : Tex.Zombie.Leg;
    this.backArm = part(armKey, ZOMBIE_ORIGIN.arm);
    this.backLeg = part(legKey, ZOMBIE_ORIGIN.leg);
    this.frontLeg = part(legKey, ZOMBIE_ORIGIN.leg);
    this.torso = part(athlete ? Tex.Zombie.TorsoAthlete : Tex.Zombie.Torso, ZOMBIE_ORIGIN.torso);
    this.head = part(Tex.Zombie.Head, ZOMBIE_ORIGIN.head);
    this.frontArm = part(armKey, ZOMBIE_ORIGIN.arm);

    const layers: Part[] = [this.backArm];
    if (options.flag) {
      this.flag = scene.add.image(0, 0, Tex.Zombie.Flag).setOrigin(0.12, 0.92);
      layers.push(this.flag);
    }
    layers.push(this.backLeg, this.frontLeg, this.torso, this.head);
    if (athlete) {
      this.headband = part(HATS.headband.key, HATS.headband.origin);
      layers.push(this.headband);
    }
    if (options.armor) {
      this.armorKind = options.armor;
      this.armor = part(HATS[options.armor].key, HATS[options.armor].origin);
      layers.push(this.armor);
    }
    if (options.pole) {
      this.pole = scene.add.image(0, 0, Tex.Zombie.Pole).setOrigin(0.62, 0.5);
      layers.push(this.pole);
    }
    layers.push(this.frontArm);
    this.add(layers);
    this.resetPose();
    scene.add.existing(this);
  }

  resetPose(): void {
    this.backLeg.setPosition(POSE.backLegX, POSE.hipY).setAngle(0);
    this.frontLeg.setPosition(POSE.frontLegX, POSE.hipY).setAngle(0);
    this.torso.setPosition(0, POSE.torsoY).setAngle(-4);
    this.head.setPosition(POSE.headX, POSE.headY).setAngle(-6).setVisible(true);
    this.backArm.setPosition(POSE.backArmX, POSE.armY).setAngle(76).setVisible(true);
    this.frontArm.setPosition(POSE.frontArmX, POSE.armY).setAngle(82).setVisible(true);
    this.flag?.setPosition(POSE.flagX, POSE.flagY).setAngle(-6);
    this.pole?.setPosition(POSE.poleX, POSE.poleY).setAngle(-6);
    this.restoreTint();
    this.followHats();
  }

  animate(dt: number, mode: RigMode, rate = 1): void {
    this.time += dt * rate;
    const t = this.time * 3.2;
    let bob = 0;
    switch (mode) {
      case 'walk': {
        const s = Math.sin(t);
        this.frontLeg.angle = s * 20;
        this.backLeg.angle = -s * 20;
        this.frontArm.angle = 82 + Math.sin(t + 0.6) * 6;
        this.backArm.angle = 76 - Math.sin(t + 0.6) * 6;
        bob = Math.abs(Math.cos(t)) * 3.5;
        this.torso.angle = -4;
        this.head.angle = -6 + Math.sin(t * 0.5) * 5;
        break;
      }
      case 'run': {
        const s = Math.sin(t);
        this.frontLeg.angle = s * 34;
        this.backLeg.angle = -s * 34;
        this.frontArm.angle = 66 + Math.sin(t) * 4;
        this.backArm.angle = 60 - Math.sin(t) * 4;
        bob = Math.abs(Math.cos(t)) * 6;
        this.torso.angle = -12;
        this.head.angle = -12;
        break;
      }
      case 'vault':
        this.frontLeg.angle = -34;
        this.backLeg.angle = 24;
        this.frontArm.angle = 140;
        this.backArm.angle = 130;
        this.torso.angle = -18;
        this.head.angle = -10;
        break;
      case 'eat': {
        const c = Math.sin(this.time * 10);
        this.frontLeg.angle = 6;
        this.backLeg.angle = -6;
        this.frontArm.angle = 62 + c * 18;
        this.backArm.angle = 56 - c * 18;
        bob = 2 + c * 2;
        this.torso.angle = -9;
        this.head.angle = -16 + c * 8;
        break;
      }
      case 'idle':
        this.frontLeg.angle = 0;
        this.backLeg.angle = 0;
        this.frontArm.angle = 80 + Math.sin(t * 0.4) * 4;
        this.backArm.angle = 74 - Math.sin(t * 0.4) * 4;
        bob = Math.sin(t * 0.6) * 2;
        this.torso.angle = -4;
        this.head.angle = -4 + Math.sin(t * 0.5) * 5;
        break;
    }
    this.torso.y = POSE.torsoY + bob;
    this.head.y = POSE.headY + bob;
    this.frontArm.y = this.backArm.y = POSE.armY + bob;
    if (this.flag) {
      this.flag.y = POSE.flagY + bob;
      this.flag.angle = -6 + Math.sin(t * 0.8) * 5;
    }
    if (this.pole) {
      this.pole.y = POSE.poleY + bob;
      this.pole.angle = mode === 'vault' ? 70 : -6 + Math.sin(t) * 2;
    }
    this.followHats();
  }

  flash(): void {
    for (const p of this.parts()) p.setTintFill(0xffffff);
    this.scene.time.delayedCall(60, () => this.active && this.restoreTint());
  }

  setChilled(on: boolean): void {
    this.chilled = on;
    this.restoreTint();
  }

  loseArm(): void {
    if (!this.frontArm.visible) return;
    this.frontArm.setVisible(false);
    this.debris(this.frontArm, -10, 150);
  }

  dropArmor(): void {
    if (!this.armor) return;
    this.debris(this.armor, 26, 120);
    this.armor.destroy();
    this.armor = null;
  }

  dropPole(): void {
    if (!this.pole) return;
    this.debris(this.pole, 30, 80);
    this.pole.destroy();
    this.pole = null;
  }

  /** Броня темнеет по мере износа (1 — целая). */
  setArmorWear(remaining: number): void {
    this.armorTint = remaining > 0.66 ? 0xffffff : remaining > 0.33 ? 0xd2d2d2 : 0xa4a4a4;
    this.restoreTint();
  }

  playDeath(onDone: () => void): void {
    this.debris(this.head, 34, -150);
    this.head.setVisible(false);
    this.headband?.setVisible(false);
    if (this.armor) this.dropArmor();
    if (this.pole) this.dropPole();
    this.scene.tweens.add({ targets: this, angle: 82, duration: 650, ease: 'Quad.easeIn' });
    this.scene.tweens.add({ targets: this, alpha: 0, delay: 1300, duration: 400, onComplete: onDone });
  }

  playChar(onDone: () => void): void {
    for (const p of this.parts()) p.setTint(CHAR_TINT);
    const baseX = this.x;
    this.scene.tweens.add({ targets: this, x: baseX + 3, duration: 40, yoyo: true, repeat: 5 });
    this.scene.tweens.add({
      targets: this,
      scaleY: this.scaleY * 0.05,
      scaleX: this.scaleX * 1.25,
      alpha: 0,
      delay: 450,
      duration: 650,
      ease: 'Quad.easeIn',
      onComplete: onDone,
    });
  }

  playSquash(onDone: () => void): void {
    this.scene.tweens.add({
      targets: this,
      scaleY: this.scaleY * 0.12,
      scaleX: this.scaleX * 1.35,
      alpha: 0,
      duration: 320,
      ease: 'Quad.easeOut',
      onComplete: onDone,
    });
  }

  /** Проглочен кусачкой: втягивается влево и исчезает. */
  playSwallow(onDone: () => void): void {
    this.scene.tweens.add({
      targets: this,
      x: this.x - 50,
      scaleX: 0.05,
      scaleY: this.scaleY * 0.4,
      alpha: 0,
      duration: 260,
      ease: 'Quad.easeIn',
      onComplete: onDone,
    });
  }

  private followHats(): void {
    if (this.armor && this.armorKind) this.attachToHead(this.armor, this.armorKind);
    if (this.headband) this.attachToHead(this.headband, 'headband');
  }

  private attachToHead(img: Part, kind: HatKind): void {
    const { offset } = HATS[kind];
    const a = Phaser.Math.DegToRad(this.head.angle);
    const cos = Math.cos(a);
    const sin = Math.sin(a);
    img.setPosition(this.head.x + offset.x * cos - offset.y * sin, this.head.y + offset.x * sin + offset.y * cos);
    img.angle = this.head.angle;
  }

  private restoreTint(): void {
    const base = this.chilled ? CHILL_TINT : 0xffffff;
    for (const p of this.parts()) p.setTint(base);
    this.backArm.setTint(this.chilled ? CHILL_BACK_TINT : BACK_TINT);
    this.backLeg.setTint(this.chilled ? CHILL_BACK_TINT : BACK_TINT);
    this.armor?.setTint(this.chilled ? CHILL_TINT : this.armorTint);
  }

  /** Отделяет копию части тела в мир: она отлетает, падает на землю и исчезает. */
  private debris(part: Part, dx: number, spin: number): void {
    const m = part.getWorldTransformMatrix();
    const s = this.scaleX;
    const groundY = this.y - 8 * s;
    const piece = this.scene.add
      .image(m.tx, m.ty, part.texture.key)
      .setOrigin(part.originX, part.originY)
      .setScale(s)
      .setAngle(this.angle + part.angle)
      .setDepth(this.depth + 1)
      .setTint(part.tintTopLeft);
    this.scene.tweens.chain({
      targets: piece,
      tweens: [
        { x: m.tx + dx * s, y: m.ty - 30 * s, duration: 200, ease: 'Quad.easeOut' },
        { y: groundY, angle: piece.angle + spin, duration: 420, ease: 'Bounce.easeOut' },
        { alpha: 0, delay: 1000, duration: 400 },
      ],
      onComplete: () => piece.destroy(),
    });
  }

  private parts(): Part[] {
    const list = [this.backArm, this.backLeg, this.frontLeg, this.torso, this.head, this.frontArm];
    for (const extra of [this.armor, this.headband, this.flag, this.pole]) if (extra) list.push(extra);
    return list;
  }
}
