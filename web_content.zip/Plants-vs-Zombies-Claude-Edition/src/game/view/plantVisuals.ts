import Phaser from 'phaser';
import { PLANTS, type PlantId } from '@/data/plants';
import { Tex } from '@/graphics/TextureKeys';
import { PLANT_ORIGIN } from '@/graphics/textures/characters';
import { inkStyle } from '@/ui/theme';

export interface PlantVisual {
  key: string;
  origin: { x: number; y: number };
  /** Масштаб на поле. */
  scale: number;
}

export const PLANT_VISUALS: Partial<Record<PlantId, PlantVisual>> = {
  peashooter: { key: Tex.Plant.Peashooter, origin: PLANT_ORIGIN.peashooter, scale: 0.62 },
  sunflower: { key: Tex.Plant.Sunflower, origin: PLANT_ORIGIN.sunflower, scale: 0.58 },
  cherrybomb: { key: Tex.Plant.CherryBomb, origin: PLANT_ORIGIN.cherrybomb, scale: 0.66 },
  wallnut: { key: Tex.Plant.Wallnut, origin: PLANT_ORIGIN.wallnut, scale: 0.68 },
  potatomine: { key: Tex.Plant.PotatoMine, origin: PLANT_ORIGIN.potatomine, scale: 0.72 },
  snowpea: { key: Tex.Plant.SnowPea, origin: PLANT_ORIGIN.peashooter, scale: 0.62 },
  chomper: { key: Tex.Plant.Chomper, origin: PLANT_ORIGIN.chomper, scale: 0.6 },
  repeater: { key: Tex.Plant.Repeater, origin: PLANT_ORIGIN.peashooter, scale: 0.62 },
};

/** Пакетик семян 64×86 с иконкой растения и ценой; центр — в (0, 0). */
export function createPacketView(scene: Phaser.Scene, plant: PlantId): Phaser.GameObjects.Container {
  const frame = scene.add.image(0, 0, Tex.Game.SeedPacket);
  const items: Phaser.GameObjects.GameObject[] = [frame];
  const visual = PLANT_VISUALS[plant];
  if (visual) {
    const icon = scene.add.image(0, -10, visual.key).setOrigin(0.5);
    icon.setScale(Math.min(46 / icon.width, 48 / icon.height));
    items.push(icon);
  }
  items.push(scene.add.text(0, 29, String(PLANTS[plant].cost), inkStyle(15, { fontStyle: '900' })).setOrigin(0.5));
  return scene.add.container(0, 0, items);
}
