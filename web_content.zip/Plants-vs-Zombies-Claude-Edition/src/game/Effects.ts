import Phaser from 'phaser';
import { settings } from '@/core/SettingsManager';
import { Tex } from '@/graphics/TextureKeys';
import { DEPTH_TOP } from './Board';

type Emitter = Phaser.GameObjects.Particles.ParticleEmitter;
type EmitterConfig = Phaser.Types.GameObjects.Particles.ParticleEmitterConfig;

/** Частицы и вспышки игрового поля. Учитывают настройку «частицы» и скорость игры. */
export class Effects {
  private readonly emitters: Emitter[] = [];
  private readonly splat: Emitter;
  private readonly dirt: Emitter;
  private readonly fire: Emitter;
  private readonly smoke: Emitter;
  private readonly ash: Emitter;
  private readonly sparks: Emitter;

  constructor(private readonly scene: Phaser.Scene) {
    this.splat = this.make(Tex.Fx.Splat, {
      speed: { min: 60, max: 170 },
      angle: { min: 110, max: 250 },
      lifespan: 380,
      scale: { start: 0.9, end: 0.1 },
      gravityY: 500,
    });
    this.dirt = this.make(Tex.Fx.Dirt, {
      speed: { min: 50, max: 150 },
      angle: { min: 200, max: 340 },
      lifespan: 520,
      scale: { start: 1, end: 0.3 },
      gravityY: 520,
    });
    this.fire = this.make(Tex.Fx.Fire, {
      speed: { min: 80, max: 340 },
      lifespan: { min: 300, max: 650 },
      scale: { start: 1.7, end: 0 },
      blendMode: 'ADD',
    });
    this.smoke = this.make(Tex.Fx.Puff, {
      speed: { min: 20, max: 100 },
      lifespan: 1200,
      scale: { start: 0.6, end: 2 },
      alpha: { start: 0.65, end: 0 },
      gravityY: -50,
    });
    this.ash = this.make(Tex.Fx.Ash, {
      speed: { min: 20, max: 90 },
      angle: { min: 200, max: 340 },
      lifespan: 800,
      gravityY: 220,
    });
    this.sparks = this.make(Tex.Fx.Spark, {
      speed: { min: 40, max: 130 },
      lifespan: 500,
      scale: { start: 0.6, end: 0 },
      blendMode: 'ADD',
    });
  }

  setTimeScale(scale: number): void {
    for (const e of this.emitters) e.timeScale = scale;
  }

  peaHit(x: number, y: number, frost = false): void {
    if (!this.enabled) return;
    if (frost) this.sparks.explode(8, x, y);
    else this.splat.explode(7, x, y);
  }

  /** Крупная надпись-звукоподражание над местом события. */
  popText(x: number, y: number, text: string, color: string): void {
    const label = this.scene.add
      .text(x, y, text, {
        fontFamily: 'Rubik, sans-serif',
        fontSize: '34px',
        fontStyle: '900',
        color,
        stroke: '#3b0a05',
        strokeThickness: 6,
        resolution: 2,
      })
      .setOrigin(0.5)
      .setDepth(DEPTH_TOP + 5)
      .setScale(0.3)
      .setAngle(-8);
    this.scene.tweens.add({ targets: label, scale: 1, duration: 220, ease: 'Back.easeOut' });
    this.scene.tweens.add({ targets: label, y: y - 40, alpha: 0, delay: 650, duration: 400, onComplete: () => label.destroy() });
  }

  plantDust(x: number, y: number): void {
    if (this.enabled) this.dirt.explode(12, x, y);
  }

  sparkle(x: number, y: number): void {
    if (this.enabled) this.sparks.explode(10, x, y);
  }

  ashes(x: number, y: number): void {
    if (this.enabled) this.ash.explode(18, x, y);
  }

  explosion(x: number, y: number, size = 1): void {
    const flash = this.scene.add.image(x, y, Tex.Fx.Spark).setBlendMode(Phaser.BlendModes.ADD).setDepth(DEPTH_TOP);
    this.scene.tweens.add({ targets: flash, scale: 14 * size, alpha: 0, duration: 380, ease: 'Quad.easeOut', onComplete: () => flash.destroy() });
    const ring = this.scene.add.circle(x, y, 20).setStrokeStyle(10, 0xffd27a, 0.9).setDepth(DEPTH_TOP);
    this.scene.tweens.add({ targets: ring, scale: 7 * size, alpha: 0, duration: 450, ease: 'Cubic.easeOut', onComplete: () => ring.destroy() });
    if (!this.enabled) return;
    this.fire.explode(Math.round(40 * size), x, y);
    this.smoke.explode(Math.round(16 * size), x, y);
  }

  private get enabled(): boolean {
    return settings.get().particles;
  }

  private make(texture: string, config: EmitterConfig): Emitter {
    const emitter = this.scene.add.particles(0, 0, texture, { ...config, emitting: false }).setDepth(DEPTH_TOP - 10);
    this.emitters.push(emitter);
    return emitter;
  }
}
