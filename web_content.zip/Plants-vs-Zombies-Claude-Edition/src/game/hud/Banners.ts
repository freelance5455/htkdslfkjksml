import Phaser from 'phaser';
import { CENTER_X, CENTER_Y } from '@/config/constants';
import { audio } from '@/audio/AudioManager';
import { t } from '@/i18n/ru';
import { textStyle } from '@/ui/theme';
import type { BannerKind } from '../LevelSession';

/** Крупные надписи по центру экрана; показываются по очереди. */
export class Banners {
  private readonly queue: BannerKind[] = [];
  private busy = false;

  constructor(private readonly scene: Phaser.Scene) {}

  show(kind: BannerKind): void {
    this.queue.push(kind);
    if (!this.busy) this.next();
  }

  private next(): void {
    const kind = this.queue.shift();
    if (!kind) {
      this.busy = false;
      return;
    }
    this.busy = true;
    const done = () => this.next();
    switch (kind) {
      case 'ready':
        this.readySetPlant(done);
        break;
      case 'huge':
        this.huge(done);
        break;
      case 'final':
        this.final(done);
        break;
      case 'defeat':
        this.defeat();
        break;
    }
  }

  private text(message: string, size: number, color: string, stroke = '#3b0a05'): Phaser.GameObjects.Text {
    return this.scene.add
      .text(CENTER_X, CENTER_Y - 40, message, textStyle(size, { color, stroke, strokeThickness: Math.round(size / 6), align: 'center' }))
      .setOrigin(0.5)
      .setDepth(500);
  }

  private readySetPlant(done: () => void): void {
    const words = t.game.ready;
    words.forEach((word, i) => {
      this.scene.time.delayedCall(i * 620, () => {
        const last = i === words.length - 1;
        audio.sfx(last ? 'go' : 'ready');
        const text = this.text(word, last ? 110 : 64, last ? '#ff4a3a' : '#fff8e7');
        text.setScale(last ? 2.4 : 0.4);
        this.scene.tweens.add({ targets: text, scale: 1, duration: last ? 260 : 300, ease: last ? 'Quad.easeIn' : 'Back.easeOut' });
        if (last) this.scene.cameras.main.shake(200, 0.006);
        this.scene.tweens.add({
          targets: text,
          alpha: 0,
          delay: last ? 700 : 380,
          duration: 200,
          onComplete: () => {
            text.destroy();
            if (last) done();
          },
        });
      });
    });
  }

  private huge(done: () => void): void {
    const text = this.text(t.game.hugeWave, 46, '#ff5a4a');
    text.setScale(0.3);
    this.scene.tweens.add({ targets: text, scale: 1, duration: 320, ease: 'Back.easeOut' });
    this.scene.tweens.add({ targets: text, angle: { from: -2, to: 2 }, duration: 90, yoyo: true, repeat: 14 });
    this.scene.tweens.add({ targets: text, alpha: 0, y: text.y - 30, delay: 2400, duration: 300, onComplete: () => (text.destroy(), done()) });
  }

  private final(done: () => void): void {
    const text = this.text(t.game.finalWave, 84, '#ff3b2f');
    text.setScale(3).setAlpha(0);
    this.scene.tweens.add({
      targets: text,
      scale: 1,
      alpha: 1,
      duration: 280,
      ease: 'Quad.easeIn',
      onComplete: () => this.scene.cameras.main.shake(260, 0.01),
    });
    this.scene.tweens.add({ targets: text, alpha: 0, delay: 1900, duration: 300, onComplete: () => (text.destroy(), done()) });
  }

  private defeat(): void {
    const text = this.text(t.game.defeat, 78, '#b6e36a', '#1f2817');
    text.setScale(0.2);
    this.scene.tweens.add({ targets: text, scale: 1, duration: 600, ease: 'Elastic.easeOut' });
    this.scene.tweens.add({ targets: text, angle: { from: -3, to: 3 }, duration: 120, yoyo: true, repeat: -1 });
    this.scene.time.delayedCall(2300, () => {
      text.destroy();
      this.busy = false;
    });
  }
}
