import Phaser from 'phaser';
import { audio } from '@/audio/AudioManager';
import { Tex } from '@/graphics/TextureKeys';
import { MOWER_SPEED } from '../balance';
import { depthOf, Layer, MOWER_X, rowGroundY, WORLD_WIDTH } from '../Board';
import type { World } from '../World';

/** Последний рубеж линии: срабатывает один раз и сметает всех зомби в ряду. */
export class LawnMower {
  state: 'idle' | 'running' | 'gone' = 'idle';
  private readonly image: Phaser.GameObjects.Image;
  private time = 0;

  constructor(
    private readonly world: World,
    readonly row: number,
  ) {
    this.image = world.scene.add
      .image(MOWER_X, rowGroundY(row) + 8, Tex.Game.Mower)
      .setOrigin(0.5, 0.92)
      .setScale(0.78)
      .setDepth(depthOf(row, Layer.Mower));
  }

  get x(): number {
    return this.image.x;
  }

  trigger(): void {
    if (this.state !== 'idle') return;
    this.state = 'running';
    this.world.session.mowersUsed++;
    audio.sfx('mower');
  }

  update(dt: number): void {
    if (this.state !== 'running') return;
    this.time += dt;
    this.image.x += MOWER_SPEED * dt;
    this.image.angle = Math.sin(this.time * 40) * 2;
    for (const z of this.world.zombies) {
      if (z.alive && z.row === this.row && Math.abs(z.x - this.image.x) < 50) z.mow();
    }
    if (this.image.x > WORLD_WIDTH + 80) {
      this.state = 'gone';
      this.image.destroy();
    }
  }
}
