import Phaser from 'phaser';
import { audio } from '@/audio/AudioManager';
import { Tex } from '@/graphics/TextureKeys';
import { CHILL, PEA } from '../balance';
import { depthOf, Layer, rowGroundY, WORLD_WIDTH } from '../Board';
import type { World } from '../World';

export type PeaKind = 'pea' | 'snow';

export class Pea {
  alive = true;
  private readonly image: Phaser.GameObjects.Image;
  private readonly shadow: Phaser.GameObjects.Ellipse;

  constructor(
    private readonly world: World,
    x: number,
    y: number,
    readonly row: number,
    private readonly kind: PeaKind = 'pea',
  ) {
    const depth = depthOf(row, Layer.Pea);
    this.shadow = world.scene.add.ellipse(x, rowGroundY(row) + 2, 18, 6, 0x000000, 0.2).setDepth(depth);
    this.image = world.scene.add.image(x, y, kind === 'snow' ? Tex.Fx.SnowPea : Tex.Fx.Pea).setDepth(depth);
  }

  update(dt: number): void {
    const x = this.image.x + PEA.speed * dt;
    this.image.x = x;
    this.shadow.x = x;
    if (this.kind === 'snow') this.image.angle += dt * 360;
    const target = this.world.zombieHitBy(this.row, x);
    if (target) {
      target.damage(PEA.damage, 'pea');
      if (this.kind === 'snow') target.chillFor(CHILL.duration);
      this.world.fx.peaHit(x, this.image.y, this.kind === 'snow');
      audio.sfx('hit');
      this.destroy();
    } else if (x > WORLD_WIDTH + 30) {
      this.destroy();
    }
  }

  destroy(): void {
    this.alive = false;
    this.image.destroy();
    this.shadow.destroy();
  }
}
