import Phaser from 'phaser';
import { audio } from '@/audio/AudioManager';
import { ZOMBIES, type ZombieDef, type ZombieId } from '@/data/zombies';
import { CHILL, EAT, ZOMBIE_SCALE } from '../balance';
import { BOARD, depthOf, Layer, rowGroundY, TARGETABLE_X } from '../Board';
import { rigOptionsFor, ZombieRig } from '../view/ZombieRig';
import type { World } from '../World';
import type { Plant } from './Plant';

export type DamageKind = 'pea' | 'explosion';
type Gait = 'walk' | 'run' | 'vault';
type DeathKind = 'normal' | 'char' | 'squash' | 'swallow';

const VAULT_TIME = 0.9;
const VAULT_HEIGHT = 80;

/**
 * Логика зомби: идёт по своей линии, ест растения, носит броню, замедляется от холода,
 * прыгун с шестом перепрыгивает первое растение на пути.
 */
export class Zombie {
  readonly rig: ZombieRig;
  readonly def: ZombieDef;
  hp: number;
  armorHp: number;
  alive = true;
  /** В прыжке: растения его не едят, мины под ним не срабатывают. */
  airborne = false;
  private gait: Gait;
  private speedCells: number;
  private readonly jitter = Phaser.Math.FloatBetween(0.9, 1.1);
  private chill = 0;
  private biteTimer = 0;
  private armLost = false;
  private groanTimer = Phaser.Math.FloatBetween(3, 14);

  constructor(
    private readonly world: World,
    type: ZombieId,
    readonly row: number,
    x: number,
  ) {
    this.def = ZOMBIES[type];
    this.hp = this.def.hp;
    this.armorHp = this.def.armorHp ?? 0;
    this.speedCells = this.def.speed;
    this.gait = this.def.vault ? 'run' : 'walk';
    this.rig = new ZombieRig(world.scene, x, rowGroundY(row) + 4, rigOptionsFor(this.def))
      .setScale(ZOMBIE_SCALE)
      .setDepth(depthOf(row, Layer.Zombie));
  }

  get x(): number {
    return this.rig.x;
  }

  get groundY(): number {
    return rowGroundY(this.row) + 4;
  }

  /** На лужайке — растения могут по нему стрелять. */
  get targetable(): boolean {
    return this.alive && this.x < TARGETABLE_X;
  }

  private get slow(): number {
    return this.chill > 0 ? CHILL.factor : 1;
  }

  private get speedPx(): number {
    return this.speedCells * BOARD.cellW * this.jitter * this.slow;
  }

  update(dt: number): void {
    if (!this.alive || this.airborne) return;
    this.groanTimer -= dt;
    if (this.groanTimer <= 0) {
      this.groanTimer = Phaser.Math.FloatBetween(8, 18);
      audio.sfx('groan');
    }
    if (this.chill > 0) {
      this.chill -= dt;
      if (this.chill <= 0) this.rig.setChilled(false);
    }

    if (this.gait === 'run') {
      const obstacle = this.world.vaultTarget(this.row, this.x);
      if (obstacle) {
        this.vaultOver(obstacle);
        return;
      }
      this.rig.x -= this.speedPx * dt;
      this.rig.animate(dt, 'run', this.speedPx / 30);
      return;
    }

    const plant: Plant | undefined = this.world.blockingPlant(this.row, this.x);
    if (plant) {
      this.biteTimer -= dt * this.slow;
      if (this.biteTimer <= 0) {
        this.biteTimer = EAT.biteInterval;
        plant.damage(EAT.dps * EAT.biteInterval);
        audio.sfx('chomp');
      }
      this.rig.animate(dt * this.slow, 'eat');
    } else {
      this.biteTimer = 0.25;
      this.rig.x -= this.speedPx * dt;
      this.rig.animate(dt, 'walk', this.speedPx / 21);
    }
  }

  chillFor(seconds: number): void {
    if (!this.alive) return;
    if (this.chill <= 0) this.rig.setChilled(true);
    this.chill = Math.max(this.chill, seconds);
  }

  damage(amount: number, kind: DamageKind): void {
    if (!this.alive) return;
    if (kind === 'explosion') {
      this.kill('char');
      return;
    }
    this.rig.flash();
    let rest = amount;
    if (this.armorHp > 0) {
      this.armorHp -= rest;
      audio.sfx(this.def.armor === 'bucket' ? 'metal' : 'armor');
      if (this.armorHp > 0) {
        this.rig.setArmorWear(this.armorHp / (this.def.armorHp ?? 1));
        return;
      }
      rest = -this.armorHp;
      this.armorHp = 0;
      this.rig.dropArmor();
    }
    this.hp -= rest;
    if (!this.armLost && this.hp <= this.def.hp / 2) {
      this.armLost = true;
      this.rig.loseArm();
    }
    if (this.hp <= 0) this.kill('normal');
  }

  /** Попал под газонокосилку. */
  mow(): void {
    this.kill('squash');
  }

  /** Проглочен кусачкой. */
  swallow(): void {
    this.kill('swallow');
  }

  private vaultOver(plant: Plant): void {
    this.airborne = true;
    this.gait = 'vault';
    const startX = this.x;
    const endX = plant.x - 70;
    const baseY = this.groundY;
    this.rig.animate(0, 'vault');
    audio.sfx('whoosh');
    this.world.scene.tweens.addCounter({
      from: 0,
      to: 1,
      duration: VAULT_TIME * 1000,
      ease: 'Sine.easeInOut',
      onUpdate: (tween) => {
        if (!this.alive) return;
        const t = tween.getValue() ?? 0;
        this.rig.x = Phaser.Math.Linear(startX, endX, t);
        this.rig.y = baseY - Math.sin(Math.PI * t) * VAULT_HEIGHT;
      },
      onComplete: () => {
        if (!this.alive) return;
        this.rig.y = baseY;
        this.airborne = false;
        this.gait = 'walk';
        this.speedCells = this.def.vault?.walkSpeed ?? this.def.speed;
        this.rig.dropPole();
        this.rig.resetPose();
      },
    });
  }

  private kill(kind: DeathKind): void {
    if (!this.alive) return;
    this.alive = false;
    this.world.onZombieKilled(this);
    const done = () => this.rig.destroy();
    switch (kind) {
      case 'char':
        this.world.fx.ashes(this.x, this.groundY - 40);
        this.rig.playChar(done);
        break;
      case 'squash':
        this.rig.playSquash(done);
        break;
      case 'swallow':
        this.rig.playSwallow(done);
        break;
      default:
        this.rig.playDeath(done);
    }
  }
}
