import { TypedEmitter } from '@/core/TypedEmitter';
import type { LevelDef } from '@/data/levels';
import type { LevelScript } from '@/data/levelScripts';
import { PLANTS, type PlantId } from '@/data/plants';
import { INITIAL_COOLDOWN, type PlayablePlant } from './balance';

export type Tool = { kind: 'plant'; plant: PlayablePlant } | { kind: 'shovel' } | null;
export type GameSpeed = 1 | 2 | 3;
export type Phase = 'intro' | 'playing' | 'victory' | 'defeat';
export type BannerKind = 'ready' | 'huge' | 'final' | 'defeat';
export type SessionRequest = 'restart' | 'next' | 'menu' | 'levels';

export interface WaveInfo {
  /** Сколько волн уже пришло. */
  spawned: number;
  total: number;
  /** Общий прогресс уровня 0..1. */
  progress: number;
  /** Секунд до следующей волны или null, если волн больше не будет. */
  nextIn: number | null;
  /** Номера (с 0) огромных волн — для флажков на шкале. */
  flags: number[];
  zombiesLeft: number;
}

export interface LevelResult {
  victory: boolean;
  stars: number;
  mowersUsed: number;
  newPlant?: PlantId;
  nextLevelId?: string;
}

type SessionEvents = {
  'sun-changed': [sun: number];
  'no-sun': [];
  'tool-changed': [tool: Tool];
  'speed-changed': [speed: GameSpeed];
  'phase-changed': [phase: Phase];
  banner: [kind: BannerKind];
  hint: [text: string | null];
  planted: [plant: PlayablePlant];
  result: [result: LevelResult];
  request: [action: SessionRequest];
};

interface Cooldown {
  left: number;
  total: number;
}

/**
 * Общее состояние уровня, которое делят игровая сцена и HUD:
 * солнце, выбранный инструмент, перезарядки, скорость, фаза и сведения о волнах.
 */
export class LevelSession extends TypedEmitter<SessionEvents> {
  sun: number;
  tool: Tool = null;
  speed: GameSpeed = 1;
  phase: Phase = 'intro';
  mowersUsed = 0;
  wave: WaveInfo;
  private readonly cooldowns = new Map<PlayablePlant, Cooldown>();

  constructor(
    readonly level: LevelDef,
    readonly script: LevelScript,
    readonly plants: PlayablePlant[],
  ) {
    super();
    this.sun = script.startSun;
    for (const id of plants) {
      const total = PLANTS[id].cooldownSec;
      this.cooldowns.set(id, { left: INITIAL_COOLDOWN[id] ?? 0, total: Math.max(total, INITIAL_COOLDOWN[id] ?? 0) });
    }
    const flags = script.waves.flatMap((w, i) => (w.flag ? [i] : []));
    this.wave = { spawned: 0, total: script.waves.length, progress: 0, nextIn: script.firstWaveDelay, flags, zombiesLeft: 0 };
  }

  get canInteract(): boolean {
    return this.phase === 'playing';
  }

  cost(id: PlayablePlant): number {
    return PLANTS[id].cost;
  }

  canAfford(id: PlayablePlant): boolean {
    return this.sun >= this.cost(id);
  }

  /** Доля оставшейся перезарядки 0..1. */
  cooldownFraction(id: PlayablePlant): number {
    const cd = this.cooldowns.get(id);
    return cd && cd.left > 0 ? cd.left / cd.total : 0;
  }

  isReady(id: PlayablePlant): boolean {
    return this.cooldownFraction(id) === 0;
  }

  selectTool(tool: Tool): void {
    if (tool && !this.canInteract) return;
    this.tool = tool;
    this.emit('tool-changed', tool);
  }

  addSun(amount: number): void {
    this.sun += amount;
    this.emit('sun-changed', this.sun);
  }

  /** Списывает солнце и запускает перезарядку после посадки. */
  commitPlant(id: PlayablePlant): void {
    this.sun -= this.cost(id);
    const total = PLANTS[id].cooldownSec;
    this.cooldowns.set(id, { left: total, total });
    this.emit('sun-changed', this.sun);
    this.emit('planted', id);
    this.selectTool(null);
  }

  setSpeed(speed: GameSpeed): void {
    if (this.speed === speed) return;
    this.speed = speed;
    this.emit('speed-changed', speed);
  }

  setPhase(phase: Phase): void {
    this.phase = phase;
    if (phase !== 'playing' && this.tool) this.selectTool(null);
    this.emit('phase-changed', phase);
  }

  hint(text: string | null): void {
    this.emit('hint', text);
  }

  update(dt: number): void {
    for (const cd of this.cooldowns.values()) {
      if (cd.left > 0) cd.left = Math.max(0, cd.left - dt);
    }
  }
}
