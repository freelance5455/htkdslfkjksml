const vm = require('vm'), fs = require('fs');
const path = require('path');
const ROOT = process.env.GAME_DIR || path.join(__dirname, '..');
const script = fs.readFileSync(path.join(ROOT,'levels-data.js'),'utf8') + '\n' + fs.readFileSync(path.join(ROOT,'app.js'),'utf8');

function mkClassList(){
  const set = new Set();
  return { add(c){set.add(c)}, remove(c){set.delete(c)}, contains(c){return set.has(c)},
           toggle(c,f){ if(f===undefined){ set.has(c)?set.delete(c):set.add(c); } else f?set.add(c):set.delete(c); } };
}
function mkEl(id=''){
  return { id, classList: mkClassList(), style: {}, dataset: {}, children: [], hidden: false,
    innerHTML: '', textContent: '', clientWidth: 400, clientHeight: 400, offsetWidth: 0,
    setAttribute(){}, getAttribute(){return null}, appendChild(c){ this.children.push(c); return c; },
    insertBefore(){}, addEventListener(){}, querySelector(){ return mkEl(); }, querySelectorAll(){ return []; },
    getBoundingClientRect(){ return {}; }, animate(){ return {}; }, remove(){}, focus(){}, onclick: null };
}
function makeContext(storage){
  const cache = {};
  const screens = ['home','levels','settings','game'].map(id => { const e = mkEl(id); e.classList.add('screen'); cache['#'+id]=e; return e; });
  const doc = {
    querySelector(sel){ if(!cache[sel]) cache[sel] = mkEl(sel.replace(/[#.]/g,'')); return cache[sel]; },
    querySelectorAll(sel){ return sel === '.screen' ? screens : []; },
    createElementNS(){ return mkEl(); }, createElement(){ return mkEl(); },
  };
  const ctx = {
    document: doc, innerWidth: 400, innerHeight: 800,
    localStorage: { getItem: k => storage.has(k) ? storage.get(k) : null, setItem: (k,v) => storage.set(k,String(v)) },
    window: {}, requestAnimationFrame: f => f(), console, setTimeout: (f) => 0, clearTimeout(){},
    Math, JSON, Date, Set, Map, Number, String, Array, Object, parseInt, isFinite, Promise,
  };
  ctx.window = ctx; ctx.addEventListener = () => {};
  vm.createContext(ctx);
  vm.runInContext(script, ctx);
  return { ctx, cache, run: code => vm.runInContext(code, ctx) };
}
module.exports = { makeContext };

if (require.main === module) {
  const results = [];
  const check = (name, cond, info='') => { results.push([name, !!cond, info]); };
  const storage = new Map();
  const H = makeContext(storage);
  const r = H.run;

  // A. fresh start: home visible, first level opens the tutorial
  check('A1 fresh save has unlocked=1', r('S.unlocked') === 1);
  r("launch('campaign', 1)");
  check('A2 tutorial opens on first level', r("$('#tut').hidden") === false);
  check('A3 game paused while tutorial shows', r('G.paused') === true);
  r("$('#tut-next').onclick()"); r("$('#tut-next').onclick()"); r("$('#tut-next').onclick()");
  check('A4 tutorial closes and is remembered', r('S.tut') === true && r("$('#tut').hidden") === true && r('G.paused') === false);

  // B. lock: a level above the frontier cannot be opened
  r("launch('campaign', 50)");
  check('B1 locked level 50 clamps to unlocked frontier', r('G.level') === 1, 'got ' + r('G.level'));

  // C. blocked tap costs exactly one life and flashes the blocker
  r("launch('campaign', 1)");
  const blockedIdx = r(`(function(){ for(const p of G.paths){ if(blockerOf(p)) return p.i; } return -1; })()`);
  check('C0 level 1 has a blocked arrow to test', blockedIdx >= 0);
  if (blockedIdx >= 0) {
    r(`tap(G.paths[${blockedIdx}], G.paths[${blockedIdx}].el)`);
    check('C1 blocked tap removes exactly one life', r('G.lives') === 2 && r('G.mistakes') === 1, `lives=${r('G.lives')} mistakes=${r('G.mistakes')}`);
    r(`tap(G.paths[${blockedIdx}], G.paths[${blockedIdx}].el)`);
    check('C2 repeat tap on same blocked arrow costs another life', r('G.lives') === 1);
    r(`tap(G.paths[${blockedIdx}], G.paths[${blockedIdx}].el)`);
    check('C3 third blocked tap ends the attempt', r('G.lives') === 0 && r('G.over') === true);
  }

  // D. hints: exactly 3 free per level, restart gives a fresh 3
  r("launch('campaign', 1)"); r("$('#tut').hidden = true");
  for (let i = 0; i < 5; i++) r('hint()');
  check('D1 hints capped at 3', r('G.hints') === 3, 'hints=' + r('G.hints'));
  r("restart()"); r("restart()");
  check('D2 restart resets hint count', r('G.hints') === 0);

  // E. every level 1..200 loads and is fully clearable in-game
  let loadFail = [];
  for (let L = 1; L <= 200; L++) {
    r(`S.unlocked = 200; launch('campaign', ${L}); $('#tut').hidden = true; if(G) G.paused = false;`);
    const ok = r(`(function(){
      let left = G.paths.filter(p => !p.gone).length, guard = 0;
      while(left > 0 && guard++ < 1000){
        const p = G.paths.find(q => !q.gone && !blockerOf(q));
        if(!p) return false;
        p.gone = true; left--;
      }
      return left === 0;
    })()`);
    const n = r('G.paths.length');
    if (!ok || n < 1) loadFail.push(L);
  }
  check('E1 all 200 levels load and clear', loadFail.length === 0, 'failed: ' + loadFail.join(','));

  // F. winning a level saves progress and unlocks the next one
  r("S.unlocked = 2; launch('campaign', 2); $('#tut').hidden = true;");
  r(`(function(){ for(const p of G.paths){ } })()`);
  r(`(function(){ let left=G.paths.length; while(left>0){ const p=G.paths.find(q=>!q.gone&&!blockerOf(q)); p.gone=true; G.left--; left--; } G.over=true; })()`);
  r('showDone()');
  check('F1 win unlocks next level', r('S.unlocked') === 3, 'unlocked=' + r('S.unlocked'));
  check('F2 win stores stars and best', r('S.stars[2] >= 1 && S.best[2] > 0'));
  check('F3 win overlay shows on game screen', r("$('#done').hidden") === false);

  // G. finishing after leaving the board: progress saved, no stale overlay
  r("$('#done').hidden = true; S.unlocked = 3; launch('campaign', 3); $('#tut').hidden = true;");
  r(`(function(){ let left=G.paths.length; while(left>0){ const p=G.paths.find(q=>!q.gone&&!blockerOf(q)); p.gone=true; G.left--; left--; } G.over=true; })()`);
  r("show('home')");
  r('showDone()');
  check('G1 result saved after leaving', r('S.unlocked') === 4, 'unlocked=' + r('S.unlocked'));
  check('G2 no win overlay on home', r("$('#done').hidden") === true);

  // H. daily: once per day, no duplicate reward
  r("launch('daily'); $('#tut').hidden = true;");
  r(`(function(){ let left=G.paths.length; while(left>0){ const p=G.paths.find(q=>!q.gone&&!blockerOf(q)); p.gone=true; G.left--; left--; } G.over=true; })()`);
  r('showDone()');
  r("launch('daily'); $('#tut').hidden = true;");
  r(`(function(){ let left=G.paths.length; while(left>0){ const p=G.paths.find(q=>!q.gone&&!blockerOf(q)); p.gone=true; G.left--; left--; } G.over=true; })()`);
  r('showDone()');
  check('H1 daily completion counted once per day', r('S.dailyDone.length') === 1, 'len=' + r('S.dailyDone.length'));

  // I. save validation: corrupted or stale data never crashes and falls back
  storage.set('arrowescape.v1', '{not json');
  const H2 = makeContext(storage);
  check('I1 corrupted save falls back to defaults', H2.run('S.unlocked') === 1 && H2.run('S.last') === null);
  storage.set('arrowescape.v1', JSON.stringify({v:1, unlocked: 9999, last: {mode:'campaign', level: 999}, stars: {'1': 'x', '2': 9}, best: {}}));
  const H3 = makeContext(storage);
  check('I2 out-of-range unlocked is clamped to 200', H3.run('S.unlocked') === 200);
  check('I3 invalid last-played entry is dropped', H3.run('S.last') === null);
  check('I4 bad star values are dropped', H3.run("S.stars['1'] === undefined && S.stars['2'] === undefined"));

  // J. continue after reload resumes the frontier, not a locked level
  storage.set('arrowescape.v1', JSON.stringify({v:1, unlocked: 5, last: {mode:'campaign', level: 12}}));
  const H4 = makeContext(storage);
  H4.run("launch('campaign', S.last.level)");
  check('J1 continue to a level above frontier is clamped', H4.run('G.level') === 5, 'level=' + H4.run('G.level'));

  // K. choosing an earlier unlocked level opens exactly that level
  r("S.unlocked = 9; launch('campaign', 4); $('#tut').hidden = true; if(G) G.paused = false;");
  check('K1 earlier unlocked level opens the chosen level', r('G.level') === 4, 'level=' + r('G.level'));
  check('K2 chosen level has its own board size (level 4 is 7x7)', r('G.n') === 7, 'n=' + r('G.n'));

  let fails = 0;
  for (const [name, ok, info] of results) { console.log((ok ? 'PASS ' : 'FAIL ') + name + (info ? '  [' + info + ']' : '')); if (!ok) fails++; }
  console.log(`\n${results.length - fails}/${results.length} passed`);
  process.exit(fails ? 1 : 0);
}
