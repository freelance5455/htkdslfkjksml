const $ = s => document.querySelector(s);
const KEY = 'arrowescape.v1';           // same key as v1 so progress carries over
const NS = 'http://www.w3.org/2000/svg';
const DIRS = [[-1,0],[0,1],[1,0],[0,-1]]; // up, right, down, left as [row, col]
const DIR_NAME = ['up','right','down','left'];
const LOCK = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></svg>';

/* ---------- Save data ---------- */
const DEF = {v:1, unlocked:1, stars:{}, best:{}, dailyDone:[], last:null, sound:true, tut:false};
let S = load();
function load(){
  try{
    const x = JSON.parse(localStorage.getItem(KEY));
    if(x && x.v === 1){
      const o = Object.assign({}, JSON.parse(JSON.stringify(DEF)), x);
      o.unlocked = Math.min(200, Math.max(1, Math.floor(+o.unlocked) || 1));
      o.stars = clean(o.stars, 3); o.best = clean(o.best, 1e9);
      if(!Array.isArray(o.dailyDone)) o.dailyDone = [];
      const L = o.last;
      if(!(L && (L.mode === 'daily' || (L.mode === 'campaign' && Number.isInteger(L.level) && L.level >= 1 && L.level <= 200))))
        o.last = null;
      o.tut = !!o.tut;
      return o;
    }
  }catch(e){}
  return JSON.parse(JSON.stringify(DEF));
}
function clean(obj, max){
  const out = {};
  if(obj && typeof obj === 'object') for(const k in obj){
    const v = Math.floor(+obj[k]);
    if(Number.isFinite(v) && v >= 0 && v <= max) out[k] = v;
  }
  return out;
}
function save(){ try{ localStorage.setItem(KEY, JSON.stringify(S)); }catch(e){} }

/* ---------- Helpers ---------- */
function tierOf(L){
  if(L <= 3) return {name:'Easy', base:100};
  if(L > 150) return {name:'Expert', base: 2000 + Math.floor((L-151)/5)*100};
  if(L % 5 === 0) return {name:'Boss', base: 1000 + Math.floor(L/5)*80};
  return {name:'Hard', base: 500 + Math.floor(L/5)*40};
}
function todayKey(){
  const d = new Date();
  return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');
}
function hash(s){ let h = 0; for(const ch of s) h = (h*31 + ch.charCodeAt(0)) | 0; return h >>> 0; }
function rng(a){ return function(){ let t = a += 0x6D2B79F5; t = Math.imul(t ^ t>>>15, t|1); t ^= t + Math.imul(t ^ t>>>7, t|61); return ((t ^ t>>>14)>>>0)/4294967296; }; }
function show(id){
  document.querySelectorAll('.screen').forEach(s => s.classList.toggle('on', s.id === id));
  if(id === 'home') renderHome();
  if(id === 'levels') renderLevels();
  if(id === 'settings') renderSettings();
}
function toast(msg){
  const t = $('#toast'); t.textContent = msg; t.classList.add('on');
  clearTimeout(toast.t); toast.t = setTimeout(() => t.classList.remove('on'), 1900);
}
let AC = null;
function beep(freq, dur){
  if(!S.sound) return;
  try{
    AC = AC || new (window.AudioContext || window.webkitAudioContext)();
    const o = AC.createOscillator(), g = AC.createGain();
    o.frequency.value = freq;
    g.gain.setValueAtTime(0.07, AC.currentTime);
    g.gain.exponentialRampToValueAtTime(0.0005, AC.currentTime + dur);
    o.connect(g).connect(AC.destination); o.start(); o.stop(AC.currentTime + dur);
  }catch(e){}
}

/* ---------- Level generation ----------
   Paths are built in reverse. A new winding path is accepted only if its head's
   straight exit is already clear of earlier paths. Removing paths in reverse
   placement order is therefore always a full solution, so every board is solvable. */
function rayClear(p, d, n, occ, mine){
  let r = p[0] + DIRS[d][0], c = p[1] + DIRS[d][1];
  while(r >= 0 && c >= 0 && r < n && c < n){
    const k = r+','+c;
    if(occ.has(k) || mine.has(k)) return false;
    r += DIRS[d][0]; c += DIRS[d][1];
  }
  return true;
}
function genPath(n, occ, rnd, P){
  for(let t = 0; t < 40; t++){
    const r0 = Math.floor(rnd()*n), c0 = Math.floor(rnd()*n), k0 = r0+','+c0;
    if(occ.has(k0) || !P.mask.has(k0)) continue;
    const cells = [[r0,c0]], mine = new Set([k0]);
    let dir = Math.floor(rnd()*4), ok = true;
    const segs = P.segMin + Math.floor(rnd()*(P.segMax - P.segMin + 1));
    for(let s = 0; s < segs && ok; s++){
      if(s > 0) dir = (dir + (rnd() < 0.5 ? 1 : 3)) % 4;
      const len = P.lenMin + Math.floor(rnd()*(P.lenMax - P.lenMin + 1));
      for(let j = 0; j < len; j++){
        const [r,c] = cells[cells.length-1];
        const nr = r + DIRS[dir][0], nc = c + DIRS[dir][1], kk = nr+','+nc;
        if(nr < 0 || nc < 0 || nr >= n || nc >= n || !P.mask.has(kk) || occ.has(kk) || mine.has(kk)){ ok = false; break; }
        cells.push([nr,nc]); mine.add(kk);
      }
    }
    if(!ok || cells.length < 2) continue;
    const last = cells[cells.length-1];
    const opts = [0,1,2,3].filter(d => rayClear(last, d, n, occ, mine));
    if(!opts.length) continue;
    const d = (opts.includes(dir) && rnd() < 0.6) ? dir : opts[Math.floor(rnd()*opts.length)];
    return {cells, d};
  }
  return null;
}
function build(seed, n, fill, P){
  if(P.dense) return buildSnake(seed, n, P.mask, Math.round(P.mask.size*0.95/3.5), 2, 4);   // dense packed snakes, all clearable
  const rnd = rng(seed), occ = new Set(), out = [];
  const target = Math.round(P.mask.size*fill);
  let cover = 0, guard = 0;
  while(cover < target && guard++ < 2500){
    const p = genPath(n, occ, rnd, P);
    if(!p) continue;
    p.cells.forEach(([r,c]) => occ.add(r+','+c));
    cover += p.cells.length; out.push(p);
  }
  return out;
}

// exit distance: steps from (r,c) in dir d until leaving the mask (or the board)
function exitSteps(n, mask, r, c, d){
  let k = 0, rr = r + DIRS[d][0], cc = c + DIRS[d][1];
  while(rr >= 0 && cc >= 0 && rr < n && cc < n && mask.has(rr+','+cc)){ k++; rr += DIRS[d][0]; cc += DIRS[d][1]; }
  return (rr >= 0 && cc >= 0 && rr < n && cc < n) ? k : k;   // steps still inside mask before the exit
}

// Long self-avoiding snakes packed into free space; the head exits to the nearest clear side.
function snakeWalk(n, mask, occ, rnd, len){
  const free = (r,c) => r>=0 && c>=0 && r<n && c<n && mask.has(r+','+c) && !occ.has(r+','+c);
  for(let t = 0; t < 30; t++){
    const cells = [], mine = new Set();
    let r0 = -1, c0 = -1;
    for(let k = 0; k < 80 && r0 < 0; k++){                  // sample a free start cell instead of scanning the board
      const r = Math.floor(rnd()*n), c = Math.floor(rnd()*n);
      if(free(r,c)){ r0 = r; c0 = c; }
    }
    if(r0 < 0) return null;
    cells.push([r0,c0]); mine.add(r0+','+c0);
    let dir = Math.floor(rnd()*4);
    while(cells.length < len){
      const [r,c] = cells[cells.length-1];
      const ok = [0,1,2,3].filter(d => { const nr=r+DIRS[d][0], nc=c+DIRS[d][1]; return free(nr,nc) && !mine.has(nr+','+nc); });
      if(!ok.length) break;
      // keep going straight half the time, otherwise turn; avoid cells that would trap the snake
      let pick;
      if(ok.includes(dir) && rnd() < 0.5) pick = dir;
      else {
        const score = d => { const nr=r+DIRS[d][0], nc=c+DIRS[d][1]; let f=0;
          for(const q of [0,1,2,3]){ const a=nr+DIRS[q][0], b=nc+DIRS[q][1]; if(free(a,b)&&!mine.has(a+','+b)) f++; } return f + rnd(); };
        pick = ok.sort((a,b) => score(b)-score(a))[0];
      }
      dir = pick;
      const nr=r+DIRS[pick][0], nc=c+DIRS[pick][1];
      cells.push([nr,nc]); mine.add(nr+','+nc);
    }
    if(cells.length < 3) continue;
    const last = cells[cells.length-1];
    const clear = [0,1,2,3].filter(q => rayClear(last, q, n, occ, mine));
    if(!clear.length) continue;
    clear.sort((a,b) => exitSteps(n,mask,last[0],last[1],a) - exitSteps(n,mask,last[0],last[1],b) || rnd()-0.5);
    return {cells, d: clear[0]};
  }
  return null;
}
function buildSnake(seed, n, mask, target, minLen, maxLen){
  const rnd = rng(seed), occ = new Set(), out = [];
  let fails = 0;
  while(out.length < target && fails < 4000){
    const len = minLen + Math.floor(rnd()*(maxLen - minLen + 1));
    const p = snakeWalk(n, mask, occ, rnd, len);
    if(!p){ fails++; continue; }
    p.cells.forEach(([r,c]) => occ.add(r+','+c));
    out.push(p);
  }
  return out;
}

const SHAPES = ['rect','circle','heart','ring','diamond','cross','star','triangle'];
function inShape(kind, x, y, n){          // x,y are cell centres in board units
  const h = n/2, u = (x-h)/h, v = (y-h)/h;
  switch(kind){
    case 'circle':  return u*u + v*v <= 0.96;
    case 'ring':    { const d = u*u + v*v; return d <= 0.96 && d >= 0.26; }
    case 'diamond': return Math.abs(u) + Math.abs(v) <= 1.02;
    case 'cross':   return Math.abs(u) <= 0.36 || Math.abs(v) <= 0.36;
    case 'heart':   { const X = u*1.25, Y = -v*1.25 + 0.15; return Math.pow(X*X + Y*Y - 1, 3) - X*X*Y*Y*Y <= 0; }
    case 'star':    { const th = Math.atan2(v, u), rad = Math.hypot(u, v); return rad <= 0.5 + 0.5*Math.abs(Math.cos(2.5*th)); }
    case 'triangle': return Math.abs(u) <= (v + 1)/2 && v <= 1;
    default:        return true;
  }
}
function makeMask(kind, n){
  const m = new Set();
  for(let r = 0; r < n; r++) for(let c = 0; c < n; c++)
    if(inShape(kind, c+.5, r+.5, n)) m.add(r+','+c);
  return m;
}
function paramsFor(L){
  if(L <= 3) return {n: L === 3 ? 6 : 5, fill:0.40, segMin:1, segMax:2, lenMin:3, lenMax:5, shape:'rect', dense: true};  // Easy warm-up
  const boss = L % 5 === 0;
  let shape = L < 6 ? 'rect' : SHAPES[L % SHAPES.length];
  if(boss) shape = L % 10 === 0 ? 'heart' : 'ring';
  let n = Math.min(16, 7 + Math.floor(L/6));                    // Hard: big from the start, keeps growing
  let fill = Math.min(0.93, 0.86 + L*0.0006);
  if(boss){ n = Math.min(16, n + 2); fill = Math.min(0.95, fill + 0.03); }
  if(boss) return Object.assign({n, fill, shape, dense: true}, {segMin:3, segMax:5, lenMin:1, lenMax:1});   // Boss: tightest, densest
  return Object.assign({n, fill, shape, dense: true}, L % 2 === 0
    ? {segMin:2, segMax:3, lenMin:1, lenMax:1}   // many short arrows
    : {segMin:2, segMax:4, lenMin:1, lenMax:2}); // mixed short arrows
}

/* ---------- Game state ---------- */
let G = null;
function start(mode, level){
  const daily = mode === 'daily';
  let P, placed;
  if(!daily && LEVELS[level]){
    const [n, shape, arrows] = LEVELS[level];
    P = {n, shape, mask: makeMask(shape, n)};
    placed = arrows.map(a => ({d: a[0], cells: a.slice(1).map(i => [Math.floor(i/n), i % n])}));
  } else {
    P = daily ? {n:7, fill:0.5, segMin:2, segMax:4, lenMin:1, lenMax:2} : paramsFor(level);
    P.mask = P.mask || makeMask(P.shape || 'rect', P.n);
    const seed = daily ? hash(todayKey()) : level*7919 + 17;
    placed = build(seed, P.n, P.fill, P);
  }
  G = {
    mode, level: daily ? 0 : level, n: P.n, mask: P.mask, left: placed.length,
    lives: 3, mistakes: 0, hints: 0, over: false, paused: false,
    tier: daily ? {name:'Daily', base:200} : tierOf(level),
    paths: placed.map((p, i) => ({cells:p.cells, d:p.d, i, gone:false}))
  };
  S.last = {mode, level: G.level}; save();
  renderBoard(); hud();
  $('#pause').hidden = true; $('#done').hidden = true; $('#over').hidden = true;
}
function launch(mode, level){
  if(mode === 'campaign'){
    level = Math.floor(+level) || 1;
    level = Math.max(1, Math.min(level, S.unlocked, 200));   // open the chosen level, never one above the frontier
  }
  show('game'); start(mode, level);
  if(mode === 'campaign' && level === 1 && !S.tut) openTut();
}

/* Returns the first remaining path that sits in this path's exit ray, or null. */
function blockerOf(p){
  const occ = new Map();
  for(const q of G.paths) if(!q.gone && q !== p) for(const [r,c] of q.cells) occ.set(r+','+c, q);
  const last = p.cells[p.cells.length-1];
  let r = last[0] + DIRS[p.d][0], c = last[1] + DIRS[p.d][1];
  while(r >= 0 && c >= 0 && r < G.n && c < G.n){
    const q = occ.get(r+','+c); if(q) return q;
    r += DIRS[p.d][0]; c += DIRS[p.d][1];
  }
  return null;
}

function el(tag, attrs){
  const e = document.createElementNS(NS, tag);
  for(const k in attrs) e.setAttribute(k, attrs[k]);
  return e;
}
function renderBoard(){
  const svg = $('#board');
  svg.setAttribute('viewBox', `0 0 ${G.n} ${G.n}`);
  svg.classList.remove('in');
  svg.innerHTML = '';
  for(let r = 0; r < G.n; r++) for(let c = 0; c < G.n; c++)
    if(G.mask.has(r+','+c)) svg.appendChild(el('circle', {cx: c+.5, cy: r+.5, r: .05, class: 'dot'}));
  G.paths.forEach(p => {
    const g = el('g', {class: 'p'});
    const pts = p.cells.map(([r,c]) => (c+.5)+','+(r+.5)).join(' ');
    const [hr, hc] = p.cells[p.cells.length-1];
    const tx = hc+.5, ty = hr+.5, [dr, dc] = DIRS[p.d];
    const vx = dc, vy = dr, px = -vy, py = vx;          // unit direction and perpendicular
    const tip = [tx + vx*.44, ty + vy*.44];
    const b1 = [tx + vx*.02 + px*.24, ty + vy*.02 + py*.24];
    const b2 = [tx + vx*.02 - px*.24, ty + vy*.02 - py*.24];
    g.appendChild(el('polyline', {class:'glow', points: pts}));
    g.appendChild(el('polyline', {class:'hit', points: pts}));
    const line = el('polyline', {class:'line', points: pts, pathLength: 1});
    line.style.transitionDelay = (p.i * 0.025) + 's';
    g.appendChild(line);
    const head = el('polygon', {class:'head', points: tip.join(' ')+' '+b1.join(' ')+' '+b2.join(' ')});
    head.style.transitionDelay = (p.i * 0.025 + 0.6) + 's';
    g.appendChild(head);
    g.addEventListener('click', () => { if(!moved) tap(p, g); });
    p.el = g; svg.appendChild(g);
  });
  G.snap = svg.innerHTML;
  layoutBoard();
  requestAnimationFrame(() => requestAnimationFrame(() => svg.classList.add('in')));
}
function hud(){
  $('#lvl').textContent = G.mode === 'daily' ? 'Daily' : 'Level ' + G.level;
  $('#tier').textContent = G.tier.name;
  $('#hearts').innerHTML = [0,1,2].map(i => '<span class="' + (i < G.lives ? '' : 'lost') + '">♥</span>').join('');
  $('#left').textContent = '➚ ' + G.left;
  $('#score').textContent = 'Score ' + scoreNow();
  const left = Math.max(0, 3 - G.hints);
  $('#hint-badge').textContent = left;
  $('#hint-badge').hidden = false;
}
function scoreNow(){ return G.tier.base + G.lives*50; }

function tap(p, g){
  if(!G || G.over || G.paused || p.gone) return;
  const b = blockerOf(p);
  if(b){
    G.mistakes++; G.lives--; beep(180, 0.14);
    g.classList.remove('shake'); void g.getBoundingClientRect(); g.classList.add('shake');
    b.el.classList.add('flash');
    setTimeout(() => b.el.classList.remove('flash'), 650);
    const hearts = document.querySelectorAll('#hearts span');
    const idx = Math.max(0, G.lives);
    if(hearts[idx]) hearts[idx].classList.add('beat');
    toast(G.lives > 0 ? 'Blocked by the red arrow. Lives left: ' + G.lives : 'No lives left');
    hud();
    if(G.lives <= 0){ G.over = true; setTimeout(showOver, 700); }
    return;
  }
  p.gone = true; G.left--; beep(660, 0.07);
  g.classList.remove('hint'); g.classList.add('pick');
  setTimeout(() => exitPath(p, g), 90);
  hud();
  if(G.left === 0){ G.over = true; setTimeout(celebrate, 650); }
}
function hint(){
  if(!G || G.over || G.paused) return;
  if(G.hints >= 3){ toast('No free hints left on this level. Look for the arrow with a clear exit.'); return; }
  const cand = G.paths.find(p => !p.gone && !blockerOf(p));
  if(!cand){ toast('No hint available right now.'); return; }
  G.hints++; hud();
  G.paths.forEach(p => p.el && p.el.classList.remove('hint'));
  cand.el.classList.add('hint');
  toast('The glowing arrow has a clear exit.');
}
let restartArmed = false;
function restart(){
  if(!G) return;
  if(!restartArmed){
    restartArmed = true; toast('Tap Restart again to start over');
    setTimeout(() => restartArmed = false, 2500); return;
  }
  restartArmed = false;
  start(G.mode, G.level);
}

function commitResult(){
  const m = G.mistakes, h = G.hints;
  const stars = (m === 0 && h === 0) ? 3 : (m <= 1 && h <= 1) ? 2 : 1;
  const score = scoreNow();
  if(G.mode === 'daily'){
    if(!S.dailyDone.includes(todayKey())) S.dailyDone.push(todayKey());
  } else {
    const L = G.level;
    S.stars[L] = Math.max(S.stars[L] || 0, stars);
    S.best[L] = Math.max(S.best[L] || 0, score);
    if(L === S.unlocked && L < 200) S.unlocked = L + 1;
  }
  save();
  return stars;
}
function showDone(){
  if(G.resultShown) return;
  G.resultShown = true;
  const stars = commitResult();
  if(!$('#game').classList.contains('on')) return;   // player already left: progress saved, no overlay
  const art = $('#d-art');
  art.setAttribute('viewBox', `0 0 ${G.n} ${G.n}`);
  art.innerHTML = G.snap || '';
  art.classList.add('in');
  const nb = $('#d-next');
  const last = G.mode !== 'daily' && G.level >= 200;
  $('#d-title').textContent = last ? 'All Levels Done!' : 'Level Completed!';
  nb.hidden = last;
  nb.textContent = G.mode === 'daily' ? 'DONE' : 'NEXT LEVEL';
  nb.onclick = () => G.mode === 'daily' ? show('home') : launch('campaign', G.level + 1);
  $('#done').hidden = false;
  beep(880, 0.2);
}
function showOver(){
  $('#o-retry').onclick = () => launch(G.mode, G.level);
  $('#over').hidden = false;
}

/* ---------- Board view: fixed cell size, fit to screen, pinch zoom, drag pan ---------- */
const CELL = 22;   // normal arrow scale: 22px per grid cell
let moved = false;
const V = {s:1, x:0, y:0, fit:1, min:1, max:3, px:0};
const stage = $('#stage'), boardSvg = $('#board');
const sw = () => stage.clientWidth, sh = () => stage.clientHeight;
function layoutBoard(){
  V.px = G.n * CELL;
  boardSvg.style.width = V.px + 'px'; boardSvg.style.height = V.px + 'px';
  // natural size (1 grid cell = CELL px) unless the board is too big for the stage; pinch can zoom in
  V.fit = Math.min(1, sw()/V.px, sh()/V.px) * 0.97;
  V.min = V.fit; V.max = Math.max(V.fit*3, 2.4);
  V.s = V.fit; centerView(); applyView();
}
function centerView(){ const B = V.px*V.s; V.x = (sw()-B)/2; V.y = (sh()-B)/2; }
function clampView(){
  const B = V.px*V.s;
  V.x = B <= sw() ? (sw()-B)/2 : Math.min(0, Math.max(sw()-B, V.x));
  V.y = B <= sh() ? (sh()-B)/2 : Math.min(0, Math.max(sh()-B, V.y));
}
function applyView(){ boardSvg.style.transform = `translate(${V.x}px, ${V.y}px) scale(${V.s})`; }
function setScale(ns){
  ns = Math.min(V.max, Math.max(V.min, ns));
  const cx = sw()/2, cy = sh()/2, bx = (cx - V.x)/V.s, by = (cy - V.y)/V.s;
  V.s = ns; V.x = cx - bx*ns; V.y = cy - by*ns; clampView(); applyView();
}
const ptr = new Map(); let pinch = null, pan = null;
stage.addEventListener('pointerdown', e => {
  ptr.set(e.pointerId, {x:e.clientX, y:e.clientY}); moved = false;
  if(ptr.size === 2){ const [a,b] = [...ptr.values()]; pinch = {d: Math.hypot(a.x-b.x, a.y-b.y), s: V.s}; pan = null; }
  else pan = {x:e.clientX, y:e.clientY, vx:V.x, vy:V.y};
});
stage.addEventListener('pointermove', e => {
  if(!ptr.has(e.pointerId)) return;
  ptr.set(e.pointerId, {x:e.clientX, y:e.clientY});
  if(ptr.size >= 2 && pinch){
    const [a,b] = [...ptr.values()];
    setScale(pinch.s * Math.hypot(a.x-b.x, a.y-b.y) / pinch.d); moved = true;
  } else if(ptr.size === 1 && pan){
    const dx = e.clientX - pan.x, dy = e.clientY - pan.y;
    if(Math.hypot(dx,dy) > 6) moved = true;
    if(V.s > V.fit + 0.001){ V.x = pan.vx + dx; V.y = pan.vy + dy; clampView(); applyView(); }
  }
});
const endPtr = e => {
  ptr.delete(e.pointerId);
  if(ptr.size < 2) pinch = null;
  if(ptr.size === 1){ const p = [...ptr.values()][0]; pan = {x:p.x, y:p.y, vx:V.x, vy:V.y}; }
  else if(ptr.size === 0) pan = null;
};
stage.addEventListener('pointerup', endPtr);
stage.addEventListener('pointercancel', endPtr);
stage.addEventListener('wheel', e => { e.preventDefault(); setScale(V.s * (e.deltaY < 0 ? 1.1 : 1/1.1)); }, {passive:false});
window.addEventListener('resize', () => { if(G && $('#game').classList.contains('on')) layoutBoard(); });

/* ---------- Snake exit: the whole arrow body slides out through its head ---------- */
function exitPath(p, g){
  const [dr, dc] = DIRS[p.d], E = G.n + 1, Lp = p.cells.length - 1;
  const [hr, hc] = p.cells[p.cells.length-1];
  const pts = p.cells.map(([r,c]) => (c+.5)+','+(r+.5));
  for(let k = 1; k <= E; k++) pts.push((hc+.5+dc*k)+','+(hr+.5+dr*k));
  const line = g.querySelector('.line'), head = g.querySelector('.head');
  line.style.display = 'none';
  const snake = el('polyline', {class:'snake', points: pts.join(' ')});
  snake.style.strokeDasharray = Lp + ' ' + (Lp + E + 5);
  snake.style.strokeDashoffset = '0';
  g.insertBefore(snake, head);
  head.style.transitionDelay = '0s';
  requestAnimationFrame(() => requestAnimationFrame(() => {
    const ease = 'cubic-bezier(.45,0,.9,.6)';
    snake.style.transition = 'stroke-dashoffset .6s ' + ease + ', stroke .2s';
    snake.style.strokeDashoffset = String(-E);
    head.style.transition = 'transform .6s ' + ease + ', fill .2s';
    head.style.transform = `translate(${dc*E}px, ${dr*E}px)`;
  }));
  setTimeout(() => g.remove(), 700);
}

/* ---------- Level clear: confetti from the top, then the win screen ---------- */
function celebrate(){
  const box = $('#burst'); box.innerHTML = '';
  const W = innerWidth, H = innerHeight;
  const cols = ['#ffd23f','#ff6b9a','#7bd389','#8ecbff','#c9a7ff','#ffffff'];
  for(let i = 0; i < 70; i++){
    const c = document.createElement('i');
    c.style.left = (Math.random()*W) + 'px'; c.style.top = '-24px';
    c.style.width = (6 + Math.random()*5) + 'px'; c.style.height = (9 + Math.random()*7) + 'px';
    c.style.background = cols[i % cols.length];
    box.appendChild(c);
    const dx = (Math.random()-0.5)*160, spin = Math.random()*720 - 360;
    c.animate([{transform:'translate(0,0) rotate(0deg)'},
               {transform:`translate(${dx}px, ${H+60}px) rotate(${spin}deg)`}],
              {duration: 1800 + Math.random()*1200, delay: Math.random()*500,
               easing: 'cubic-bezier(.25,.5,.6,1)', fill: 'forwards'});
  }
  setTimeout(showDone, 1100);
  setTimeout(() => { box.innerHTML = ''; }, 3800);
}

/* ---------- First-time tutorial (3 steps, shown once) ---------- */
const TUT = [
  {t:'Tap an arrow', b:'An arrow with nothing in front of it slides straight out of the board when you tap it.'},
  {t:'Blocked arrows', b:'If another arrow is in front, the tap fails: you lose one heart, and the arrow in the way flashes red.'},
  {t:'Clear the board', b:'Remove every arrow to finish the level. You have 3 free hints per level, plus Restart and Pause below.'}
];
let tutStep = 0;
function renderTut(){
  $('#tut-title').textContent = TUT[tutStep].t;
  $('#tut-body').textContent = TUT[tutStep].b;
  $('#tut-next').textContent = tutStep === TUT.length - 1 ? 'START' : 'NEXT';
  $('#tut-dots').textContent = TUT.map((_, i) => i === tutStep ? '●' : '○').join(' ');
}
function openTut(){ tutStep = 0; if(G) G.paused = true; renderTut(); $('#tut').hidden = false; }
function closeTut(){ S.tut = true; save(); $('#tut').hidden = true; if(G) G.paused = false; }
$('#tut-next').onclick = () => { if(tutStep < TUT.length - 1){ tutStep++; renderTut(); } else closeTut(); };
$('#tut-skip').onclick = closeTut;

/* ---------- Pause ---------- */
function pause(){ if(!G || G.over) return; G.paused = true; $('#pause').hidden = false; }
function resume(){ if(!G) return; G.paused = false; $('#pause').hidden = true; }

/* ---------- Screens ---------- */
function renderHome(){
  const stars = Object.values(S.stars).reduce((a,b) => a+b, 0);
  $('#st-done').textContent = Object.keys(S.stars).length;
  $('#st-best').textContent = Math.max(0, ...Object.values(S.best));
  $('#st-stars').textContent = stars;
  $('#play-sub').textContent = 'Level ' + S.unlocked;
  $('#btn-continue').hidden = !S.last;
  if(S.last) $('#cont-sub').textContent = S.last.mode === 'daily' ? 'Daily puzzle' : 'Continue Level ' + S.last.level;
  $('#daily-sub').textContent = S.dailyDone.includes(todayKey()) ? 'Done today ✓' : "Today's puzzle";
}
function renderLevels(){
  const box = $('#lvl-list'); box.innerHTML = '';
  for(let s = 0; s < 20; s++){
    const from = s*10 + 1, to = s*10 + 10;
    const head = document.createElement('div');
    head.className = 'tier';
    head.innerHTML = '<span>Levels ' + from + '–' + to + '</span><span>' + (s === 0 ? 'Easy · Hard' : s >= 15 ? 'Hard · Expert' : 'Hard') + '</span>';
    box.appendChild(head);
    const grid = document.createElement('div'); grid.className = 'lgrid';
    for(let i = from; i <= to; i++){
      const b = document.createElement('button'); b.className = 'lv';
      if(i > S.unlocked){ b.classList.add('locked'); b.disabled = true; b.innerHTML = LOCK; }
      else{
        const st = S.stars[i] || 0;
        b.innerHTML = '<b>' + i + '</b><small>' + (st ? '★'.repeat(st) : '&nbsp;') + '</small>';
        if(i === S.unlocked) b.classList.add('current');
        b.onclick = () => launch('campaign', i);
      }
      grid.appendChild(b);
    }
    box.appendChild(grid);
  }
}
let clearArmed = false;
function renderSettings(){
  $('#set-sound').textContent = S.sound ? 'On' : 'Off';
}

/* ---------- Wiring ---------- */
document.querySelectorAll('[data-go]').forEach(b => b.addEventListener('click', () => {
  beep(520, 0.05);
  if(b.dataset.go === 'home' && G) G.over = true;
  show(b.dataset.go);
}));
$('#btn-play').onclick = () => { beep(520, 0.05); launch('campaign', S.unlocked); };
$('#btn-continue').onclick = () => {
  if(!S.last) return;
  if(S.last.mode === 'daily') launch('daily'); else launch('campaign', S.last.level);
};
$('#btn-daily').onclick = () => { beep(520, 0.05); launch('daily'); };
$('#btn-home').onclick = () => { if(G) G.over = true; show('home'); };
$('#btn-hint').onclick = hint;
$('#btn-restart').onclick = restart;
$('#btn-pause').onclick = pause;
$('#p-resume').onclick = resume;
$('#p-restart').onclick = () => { $('#pause').hidden = true; start(G.mode, G.level); };
$('#set-sound').onclick = () => { S.sound = !S.sound; save(); renderSettings(); };
show('home');
