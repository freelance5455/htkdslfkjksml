ARROW ESCAPE - project (v19)

index.html            COMPLETE GAME in one file (open this one). Page structure: home, levels, settings, game (and overlays).
style.css             All styling, in sections (base, frame, home, levels, game, arrows, overlays).
app.js                Game logic: saves, campaign, board, taps, hints, tutorial, win/lose.
levels-data.js        200 pre-validated campaign levels (loaded before app.js).
arrow-escape-logo.svg App logo (also the browser icon).
tools/harness.js      Node test (23 checks). Run from this folder: node tools/harness.js

Open index.html in a browser to play. Full screen on phones; centred card on PC.
Save data lives only in this browser (localStorage key "arrowescape.v1").

IMPORTANT: index.html is self-contained (CSS, JavaScript and level data are inside it).
Open just index.html in a browser. The other files are the same code split up for editing;
if you edit them, rebuild index.html by putting style.css in a <style> tag and
levels-data.js + app.js in a <script> tag.
