/* agro.js — منطق کشاورزی هوای آشناخور (لوبیا چیتی)
   مراحل رشد با روز-درجه (GDD)، نیاز آبی با Kc، خاک، بیماری، هشدار، برداشت، اقلیم‌شناسی ۱۰ ساله.
   همه‌ی آستانه‌ها تقریبی و قابل‌تنظیم‌اند؛ مبنای آن‌ها راهنمای عمومی لوبیا است نه نسخه‌ی قطعی. */
(function (root) {
  "use strict";
  const C = root.AshnakhorCore;
  const num = C.num;
  const STORE = "ashnakhor-data";

  // ---------- تاریخ (همه UTC تا مشکل ساعت تابستانی/منطقه‌ای پیش نیاید) ----------
  const pad = n => String(n).padStart(2, "0");
  const parse = s => { const p = s.split("-").map(Number); return new Date(Date.UTC(p[0], p[1] - 1, p[2])); };
  const fmt = d => d.getUTCFullYear() + "-" + pad(d.getUTCMonth() + 1) + "-" + pad(d.getUTCDate());
  const addDays = (s, n) => { const d = parse(s); d.setUTCDate(d.getUTCDate() + n); return fmt(d); };
  const diffDays = (a, b) => Math.round((parse(a) - parse(b)) / 864e5);
  const mmdd = s => s.slice(5);
  function nowTehran() {
    // "YYYY-MM-DDTHH:MM" به وقت تهران
    try { return new Date().toLocaleString("sv-SE", { timeZone: "Asia/Tehran" }).replace(" ", "T").slice(0, 16); }
    catch (e) { return new Date().toISOString().slice(0, 16); }
  }
  const refDoy = md => Math.round((Date.UTC(2001, +md.slice(0, 2) - 1, +md.slice(3, 5)) - Date.UTC(2001, 0, 1)) / 864e5);
  const doyToMd = n => { const d = new Date(Date.UTC(2001, 0, 1 + Math.round(n))); return pad(d.getUTCMonth() + 1) + "-" + pad(d.getUTCDate()); };
  const median = a => { if (!a.length) return null; const s = a.slice().sort((x, y) => x - y), m = s.length >> 1; return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2; };

  // ---------- مشخصات گیاه: لوبیا چیتی ----------
  const TBASE = 10, TCAP = 30, GDD_REF = 1200;
  // نقاط Kc بر حسب روز-درجه‌ی مرجع (FAO-56 برای لوبیا خشک: ۰٫۴ / ۱٫۱۵ / ۰٫۳۵)
  const KC_POINTS = [[0, 0.40], [150, 0.40], [600, 1.10], [950, 1.15], [1200, 0.35]];
  const STAGES = [
    { id: "germ", name: "جوانه‌زنی تا سبزشدن", icon: "🌱", from: 0, to: 100,
      tasks: ["رطوبت بستر بذر را یکنواخت نگه دارید؛ آبیاری سبک و کم‌حجم، بدون غرقاب (غرقاب باعث پوسیدگی بذر و ریشه می‌شود).",
        "اگر سطح خاک سله بست، با آبیاری سبک نرمش کنید تا سبزشدن گیر نکند.",
        "سرمای نزدیک صفر یا زیر صفر به گیاهچه آسیب می‌زند؛ پیش‌بینی یخبندان را دنبال کنید."],
      watch: "پوسیدگی بذر و طوقه (خاک سرد و خیس)، آفات بذرخوار" },
    { id: "veg", name: "رشد رویشی", icon: "🌿", from: 100, to: 600,
      tasks: ["علف‌هرز در هفته‌های اول بعد از سبزشدن بیشترین ضرر را می‌زند؛ وجین یا کنترل را زود انجام دهید.",
        "آبیاری قطره‌ای منظم و سبک؛ هم از تنش آبی و هم از خیسی دائمی پرهیز کنید.",
        "کود ازته‌ی زیاد توصیه نمی‌شود (لوبیا خودش ازت تثبیت می‌کند و ازت زیاد گلدهی را عقب می‌اندازد)؛ فسفر و پتاسیم را طبق آزمون خاک تأمین کنید.",
        "شته، کنه و تریپس را هفته‌ای یک‌بار بازدید کنید."],
      watch: "شته، کنه‌ی تارتن، تریپس، علف‌هرز" },
    { id: "flower", name: "گلدهی", icon: "🌼", from: 600, to: 800, waterCritical: true,
      tasks: ["حساس‌ترین مرحله به تنش آبی است؛ رطوبت خاک را ثابت نگه دارید (نه تنش، نه غرقاب).",
        "گرمای بالای حدود ۳۲ درجه و شب‌های خیلی سرد می‌تواند باعث ریزش گل و کم‌شدن غلاف شود.",
        "در هوای مرطوب و خنک، کپک سفید و زنگ را بازدید کنید؛ پوشش متراکم و خیس پرخطر است.",
        "سمپاشی را صبح زود یا عصر انجام دهید."],
      watch: "کپک سفید، زنگ، بلایت باکتریایی" },
    { id: "pod", name: "غلاف‌بندی و پرشدن دانه", icon: "🫘", from: 800, to: 1050, waterCritical: true,
      tasks: ["آبیاری را یکنواخت ادامه دهید؛ تنش آبی تعداد و اندازه‌ی دانه را کم می‌کند.",
        "کنه‌ی تارتن (هوای گرم و خشک)، کرم غلاف‌خوار و زنگ را بازدید کنید.",
        "کود ازته را متوقف کنید؛ در صورت نیاز فقط پتاسیم یا ریزمغذی طبق آزمون."],
      watch: "کنه، کرم غلاف‌خوار، زنگ" },
    { id: "mature", name: "رسیدن (زردشدن غلاف‌ها)", icon: "🟡", from: 1050, to: 1200,
      tasks: ["وقتی بیشتر غلاف‌ها زرد شدند آبیاری را قطع کنید تا بوته خشک شود.",
        "ماشین‌آلات برداشت را آماده و تنظیم کنید.",
        "به پیش‌بینی باران دقت کنید؛ باران در این زمان کیفیت دانه را پایین می‌آورد."],
      watch: "باران و رطوبت زیاد هنگام رسیدن" },
    { id: "harvest", name: "خشک‌شدن و برداشت", icon: "🌾", from: 1200, to: Infinity,
      tasks: ["وقتی تقریباً همه‌ی غلاف‌ها خشک و بوته‌ها زرد/قهوه‌ای شدند برداشت کنید.",
        "برای کم‌شدن ریزش دانه، برداشت را صبح زود یا در هوای کمی مرطوب انجام دهید.",
        "رطوبت دانه هنگام کوبیدن حدود ۱۶ تا ۱۸ درصد و برای انبار حداکثر حدود ۱۴ درصد است؛ قبل از انبار خشک کنید.",
        "برای برداشت ۲ تا ۳ روز هوای بی‌باران انتخاب کنید."],
      watch: "باران (تغییر رنگ پوست دانه و افت کیفیت)، ریزش دانه" }
  ];
  const MILESTONES = [
    { id: "flower", name: "شروع گلدهی", ref: 600 },
    { id: "stop", name: "زمان قطع آبیاری", ref: 1050 },
    { id: "mat", name: "رسیدگی", ref: 1200 }
  ];

  function gddDay(tx, tn) {
    if (!num(tx) || !num(tn)) return 0;
    return Math.max(0, (Math.min(tx, TCAP) + Math.max(tn, TBASE)) / 2 - TBASE);
  }
  function kcAt(g) {
    const P = KC_POINTS;
    if (g <= P[0][0]) return P[0][1];
    for (let i = 1; i < P.length; i++) {
      if (g <= P[i][0]) { const a = P[i - 1], b = P[i]; return a[1] + (b[1] - a[1]) * (g - a[0]) / (b[0] - a[0]); }
    }
    return P[P.length - 1][1];
  }
  const stageIdx = g => { for (let i = STAGES.length - 1; i >= 0; i--) if (g >= STAGES[i].from) return i; return 0; };

  // ---------- دریافت داده ----------
  const D_VARS = "temperature_2m_max,temperature_2m_min,precipitation_sum,et0_fao_evapotranspiration";
  const H_VARS = "soil_temperature_6cm,soil_moisture_3_to_9cm,relative_humidity_2m,temperature_2m";
  const base = () => "latitude=" + C.LAT + "&longitude=" + C.LON + "&elevation=" + C.ELEV + "&timezone=Asia%2FTehran";
  function mapDaily(d) {
    return d.time.map((t, i) => ({ date: t, tmax: d.temperature_2m_max[i], tmin: d.temperature_2m_min[i],
      precip: d.precipitation_sum[i], et0: d.et0_fao_evapotranspiration ? d.et0_fao_evapotranspiration[i] : null }));
  }
  async function viaCache(key, fetcher) {
    try { const r = await fetcher(); r.stale = false; await C.putJson(STORE, key, r); return r; }
    catch (e) { const c = await C.getJsonStore(STORE, key); if (c) { c.stale = true; c.err = e.message; return c; } throw e; }
  }
  const loadCached = async key => { const c = await C.getJsonStore(STORE, key); if (c) c.stale = true; return c; };
  const fetchDaily = () => viaCache("agro-daily", async () => {
    const j = await C.getJson("https://api.open-meteo.com/v1/forecast?" + base() + "&daily=" + D_VARS + "&past_days=92&forecast_days=16");
    if (j.error) throw new Error(j.reason || "API error");
    return { t: Date.now(), days: mapDaily(j.daily) };
  });
  const fetchHourly = () => viaCache("agro-hourly", async () => {
    const j = await C.getJson("https://api.open-meteo.com/v1/forecast?" + base() + "&hourly=" + H_VARS + "&past_days=2&forecast_days=7");
    if (j.error) throw new Error(j.reason || "API error");
    return { t: Date.now(), h: j.hourly };
  });
  // فصل‌هایی که کاشتشان قدیمی‌تر از ۹۲ روز است: بخش قدیمی از آرشیو (ERA5) می‌آید
  async function fetchArchive(start, end) {
    const key = "arch-" + start;
    const c = await C.getJsonStore(STORE, key);
    if (c && c.end === end) return c;
    try {
      const j = await C.getJson("https://archive-api.open-meteo.com/v1/archive?" + base() + "&start_date=" + start + "&end_date=" + end + "&daily=" + D_VARS, 25000);
      if (j.error) throw new Error(j.reason || "API error");
      const r = { end, days: mapDaily(j.daily) };
      await C.putJson(STORE, key, r);
      return r;
    } catch (e) { if (c) return c; throw e; }
  }
  async function getDays(sow) {
    const daily = await fetchDaily().catch(async e => { const c = await loadCached("agro-daily"); if (c) { c.err = e.message; return c; } throw e; });
    let days = daily.days, archiveErr = null;
    const first = days[0].date;
    if (sow && sow < first) {
      try {
        const a = await fetchArchive(sow, addDays(first, -1));
        const have = {}; a.days.forEach(d => have[d.date] = d);
        days.forEach(d => have[d.date] = d);
        days = Object.keys(have).sort().map(k => have[k]);
      } catch (e) { archiveErr = e.message; }
    }
    return { days, stale: daily.stale, err: daily.err, archiveErr, t: daily.t };
  }
  const CLIM_YEARS = 20;
  async function getClim() {
    const Y = new Date().getFullYear();
    const c = await C.getJsonStore(STORE, "clim");
    if (c && c.y === Y && c.raw && c.raw.pr && c.v === 2) return c;
    try {
      const start = (Y - CLIM_YEARS) + "-01-01", end = (Y - 1) + "-12-31";
      const j = await C.getJson("https://archive-api.open-meteo.com/v1/archive?" + base() + "&start_date=" + start + "&end_date=" + end + "&daily=temperature_2m_max,temperature_2m_min,precipitation_sum", 40000);
      if (j.error) throw new Error(j.reason || "API error");
      const r1 = v => num(v) ? Math.round(v * 10) / 10 : null;
      const out = { y: Y, v: 2, raw: { start, tmax: j.daily.temperature_2m_max.map(r1), tmin: j.daily.temperature_2m_min.map(r1), pr: j.daily.precipitation_sum.map(r1) } };
      await C.putJson(STORE, "clim", out);
      return out;
    } catch (e) { if (c && c.raw) return c; throw e; }
  }
  // رگبار همرفتی: شاخص‌های ناپایداری (کل شبانه‌روز؛ رگبار شبانه هم دیده می‌شود)
  const fetchConv = () => viaCache("agro-conv", async () => {
    const j = await C.getJson("https://api.open-meteo.com/v1/forecast?latitude=" + C.LAT + "&longitude=" + C.LON + "&timezone=Asia%2FTehran&forecast_days=5&hourly=cape,lifted_index,convective_inhibition,cloud_cover,wind_speed_10m,precipitation,freezing_level_height&wind_speed_unit=kmh");
    if (j.error) throw new Error(j.reason || "API error");
    return { t: Date.now(), h: j.hourly };
  });

  // ---------- فصل رشد: روز-درجه، Kc، ETc ----------
  function calcSeason(days, sow, opts) {
    opts = opts || {};
    const raw = []; let cum = 0;
    for (const d of days) {
      if (d.date < sow) continue;
      const g = gddDay(d.tmax, d.tmin); cum += g;
      raw.push({ date: d.date, gdd: g, cum, tmax: d.tmax, tmin: d.tmin, precip: d.precip, et0: d.et0 });
    }
    let scale = (opts.gddMat || GDD_REF) / GDD_REF, calibrated = false;
    if (opts.flowerDate) {
      const r = raw.find(x => x.date >= opts.flowerDate);
      if (r && r.cum > 200) { scale = r.cum / 600; calibrated = true; }
    }
    const rows = raw.map(r => {
      const gn = r.cum / scale, kc = kcAt(gn);
      return Object.assign({}, r, { gn, kc, si: stageIdx(gn), etc: num(r.et0) ? r.et0 * kc : null });
    });
    return { rows, scale, calibrated, last: rows[rows.length - 1] || null };
  }
  function projectMilestones(season, climMean, todayStr) {
    const rows = season.rows, out = {};
    if (!rows.length) return out;
    const s = season.scale;
    const lastRow = rows[rows.length - 1];
    let cum = lastRow.cum, d = lastRow.date, steps = 0;
    const pending = MILESTONES.slice();
    MILESTONES.forEach(m => {
      const r = rows.find(x => x.cum >= m.ref * s);
      if (r) { out[m.id] = { date: r.date, est: r.date > todayStr }; pending.splice(pending.findIndex(p => p.id === m.id), 1); }
    });
    const limit = rows[0].date.slice(0, 4) + "-11-30"; // بعد از آبان در مزرعه‌ی ارتفاع ۲۰۰۰ متری فصل رشد تمام است
    while (pending.length && steps < 220 && d < limit) {
      d = addDays(d, 1); steps++;
      cum += climMean ? climMean(mmdd(d)) : 0;
      for (let i = pending.length - 1; i >= 0; i--) {
        if (cum >= pending[i].ref * s) { out[pending[i].id] = { date: d, est: true, climate: true }; pending.splice(i, 1); }
      }
      if (!climMean && steps > 5) break;
    }
    return out;
  }

  // ---------- اقلیم ۱۰ ساله: یخبندان و شبیه‌ساز تاریخ کاشت ----------
  function climIndex(raw) {
    const n = raw.tmax.length, years = {};
    let date = raw.start;
    for (let i = 0; i < n; i++, date = addDays(date, 1)) {
      const y = +date.slice(0, 4);
      (years[y] = years[y] || []).push({ date, md: mmdd(date), tx: raw.tmax[i], tn: raw.tmin[i], pr: raw.pr ? raw.pr[i] : null });
    }
    const list = Object.keys(years).map(Number).sort();
    const frost = list.map(y => {
      let last = null, first = null;
      years[y].forEach(r => {
        if (!num(r.tn) || r.tn > 0) return;
        const m = +r.md.slice(0, 2);
        if (m <= 7) last = r.md; else if (!first) first = r.md;
      });
      return { y, last, first };
    });
    const dl = frost.map(f => f.last).filter(Boolean).map(refDoy), df = frost.map(f => f.first).filter(Boolean).map(refDoy);
    const gsum = {}, gcnt = {};
    list.forEach(y => years[y].forEach(r => {
      if (!num(r.tx) || !num(r.tn)) return;
      gsum[r.md] = (gsum[r.md] || 0) + gddDay(r.tx, r.tn); gcnt[r.md] = (gcnt[r.md] || 0) + 1;
    }));
    const climMean = md => gcnt[md] ? gsum[md] / gcnt[md] : (md === "02-29" ? (gsum["02-28"] / gcnt["02-28"] || 0) : 0);
    return {
      years: list, byYear: years, frost, n: list.length, climMean,
      lastMed: dl.length ? doyToMd(median(dl)) : null, lastLatest: dl.length ? doyToMd(Math.max(...dl)) : null, lastEarliest: dl.length ? doyToMd(Math.min(...dl)) : null,
      firstMed: df.length ? doyToMd(median(df)) : null, firstEarliest: df.length ? doyToMd(Math.min(...df)) : null, firstLatest: df.length ? doyToMd(Math.max(...df)) : null,
      noFirst: frost.filter(f => !f.first).length
    };
  }
  function simulateSowing(ci, sowMd, target) {
    const rows = [];
    ci.years.forEach(y => {
      const arr = ci.byYear[y]; if (!arr) return;
      const i0 = arr.findIndex(r => r.md >= sowMd); if (i0 < 0) return;
      let cum = 0, mat = null;
      for (let i = i0; i < arr.length; i++) { cum += gddDay(arr[i].tx, arr[i].tn); if (cum >= target) { mat = arr[i].date; break; } }
      const f = ci.frost.find(x => x.y === y);
      const sowDate = arr[i0].date;
      const first = f && f.first ? y + "-" + f.first : null;
      const last = f && f.last ? y + "-" + f.last : null;
      rows.push({ y, sow: sowDate, mat, first,
        ok: !!mat && (!first || mat < first),
        hit: !!last && last > addDays(sowDate, 8) && last.slice(5, 7) !== "01" });
    });
    const days = rows.filter(r => r.mat).map(r => diffDays(r.mat, r.sow));
    return { rows, n: rows.length, okCount: rows.filter(r => r.ok).length, hitCount: rows.filter(r => r.hit).length,
      medDays: median(days), medMat: rows.filter(r => r.mat).length ? doyToMd(median(rows.filter(r => r.mat).map(r => refDoy(r.mat.slice(5))))) : null };
  }

  // ---------- ساعتی: خاک، رطوبت، بیماری ----------
  function hourIndex(h) {
    const k = nowTehran().slice(0, 13) + ":00";
    const i = h.time.findIndex(x => x >= k);
    return i < 0 ? 0 : i;
  }
  const avg = a => { const v = a.filter(num); return v.length ? v.reduce((x, y) => x + y, 0) / v.length : null; };
  function soilInfo(h) {
    const i = hourIndex(h), T = h.soil_temperature_6cm || [], M = h.soil_moisture_3_to_9cm || [];
    const past = T.slice(Math.max(0, i - 24), i + 1), next = T.slice(i, i + 72);
    const m = M[i];
    return { t6: T[i], t6mean24: avg(past), t6next: avg(next), t6min: next.filter(num).length ? Math.min(...next.filter(num)) : null,
      t6max: next.filter(num).length ? Math.max(...next.filter(num)) : null, moist: num(m) ? m * 100 : null };
  }
  function wetHours(h) {
    const by = {};
    h.time.forEach((t, i) => {
      const d = t.slice(0, 10), rh = h.relative_humidity_2m && h.relative_humidity_2m[i], tp = h.temperature_2m && h.temperature_2m[i];
      const o = by[d] = by[d] || { wet: 0, n: 0, tsum: 0, tn: 0 };
      if (!num(rh)) return;
      o.n++;
      if (rh >= 90) { o.wet++; if (num(tp)) { o.tsum += tp; o.tn++; } }
    });
    Object.keys(by).forEach(d => { by[d].tAvg = by[d].tn ? by[d].tsum / by[d].tn : null; });
    return by;
  }
  function diseaseRisk(o, si) {
    if (!o || o.n < 12) return null;
    const inWindow = si === null || (si >= 1 && si <= 3);
    const tOk = num(o.tAvg) && o.tAvg >= 12 && o.tAvg <= 27;
    if (inWindow && o.wet >= 10 && tOk) return "high";
    if (inWindow && o.wet >= 6 && tOk) return "mid";
    return "low";
  }

  // ---------- وضعیت کاشت ----------
  function plantingStatus(soil, fdays) {
    const reasons = [];
    const minNext = fdays.slice(0, 7).map(d => d.tmin).filter(num);
    const mn = minNext.length ? Math.min(...minNext) : null;
    const frostDays = fdays.slice(0, 7).filter(d => num(d.tmin) && d.tmin <= 2).length;
    const t = soil ? soil.t6mean24 : null;
    let level = "ok";
    if (num(t)) {
      if (t >= 15) reasons.push("دمای خاک (۶ سانتی‌متر) حدود " + t.toFixed(1) + "°؛ مناسب جوانه‌زنی (حداقل حدود ۱۵)");
      else if (t >= 12) { level = "warn"; reasons.push("دمای خاک حدود " + t.toFixed(1) + "°؛ هنوز کمی سرد است (حداقل حدود ۱۵)"); }
      else { level = "danger"; reasons.push("دمای خاک حدود " + t.toFixed(1) + "°؛ برای لوبیا خیلی سرد است"); }
    } else reasons.push("دمای خاک در دسترس نیست");
    if (mn !== null) {
      if (mn <= 0) { level = "danger"; reasons.push("یخبندان در ۷ روز آینده (کمینه " + mn.toFixed(1) + "°)"); }
      else if (frostDays) { if (level === "ok") level = "warn"; reasons.push("سرمای نزدیک صفر در " + frostDays + " روز از ۷ روز آینده (کمینه " + mn.toFixed(1) + "°)"); }
      else reasons.push("بدون سرمای خطرناک در ۷ روز آینده (کمینه " + mn.toFixed(1) + "°)");
    }
    const verdict = level === "ok" ? "مناسب کاشت" : level === "warn" ? "کمی زود است / با احتیاط" : "نامناسب؛ صبر کنید";
    return { level, verdict, reasons };
  }

  // ---------- آبیاری ----------
  const effRain = p => num(p) && p >= 3 ? p * 0.8 : 0;
  function irrigation(season, farm, todayStr) {
    const rows = season.rows;
    if (!rows.length) return null;
    const eff = 0.9, mad = +farm.mad || 25;
    const secArea = (+farm.areaM2 || 27000) / (+farm.sections || 15);
    const flow = +farm.flow > 0 ? +farm.flow : null;
    const logs = (farm.ops || []).filter(o => o.type === "irr" && num(+o.mm)).sort((a, b) => a.date < b.date ? -1 : 1);
    const toL = g => g * secArea;
    const table = rows.filter(r => r.date >= todayStr).slice(0, 7).map(r => {
      const er = effRain(r.precip), net = Math.max(0, (r.etc || 0) - er), gross = net / eff;
      return { date: r.date, kc: r.kc, et0: r.et0, etc: r.etc, rain: r.precip, effRain: er, net, gross, liters: toL(gross), hours: flow ? toL(gross) / 1000 / flow : null };
    });
    const todayRow = rows.find(r => r.date === todayStr) || rows[rows.length - 1];
    const stop = todayRow.gn >= 1050;
    const res = { eff, mad, secArea, flow, table, kc: todayRow.kc, etc: todayRow.etc, si: todayRow.si, stop, hasLogs: logs.length > 0, status: "unknown" };
    if (stop) { res.status = "stop"; return res; }
    if (!logs.length) return res;
    let Dd = 0;
    const start = logs[0].date;
    const idxToday = rows.findIndex(r => r.date === todayStr);
    for (const r of rows) {
      if (r.date < start) continue;
      if (r.date >= todayStr) break;
      if (r.date === start) Dd = 0; else Dd = Math.max(0, Dd + (r.etc || 0) - effRain(r.precip));
      logs.forEach(l => { if (l.date === r.date && r.date !== start) Dd = Math.max(0, Dd - l.mm * eff); });
    }
    res.lastIrr = logs[logs.length - 1].date;
    res.D = Dd;
    // پیش‌بینی: از امروز به بعد بدون آبیاری
    let hit = null, Dp = Dd, Dhit = null;
    for (let i = Math.max(idxToday, 0); i < rows.length; i++) {
      const r = rows[i];
      logs.forEach(l => { if (l.date === r.date && l.date >= todayStr) Dp = Math.max(0, Dp - l.mm * eff); });
      Dp = Dp + (r.etc || 0) - effRain(r.precip);
      if (Dp < 0) Dp = 0;
      if (Dp >= mad) { hit = r.date; Dhit = Dp; break; }
    }
    res.nextDate = hit;
    if (Dd >= mad) { res.status = "now"; res.depthNet = Dd; }
    else if (hit && diffDays(hit, todayStr) <= 1) { res.status = "soon"; res.depthNet = Dhit; }
    else { res.status = "ok"; res.depthNet = hit ? Dhit : null; }
    if (res.depthNet) { res.depthGross = res.depthNet / eff; res.litersSection = toL(res.depthGross); res.hours = flow ? res.litersSection / 1000 / flow : null; }
    return res;
  }

  // ---------- برداشت ----------
  function harvestDays(fdays) {
    const days = fdays.slice(0, 7).map(d => ({ date: d.date, tmax: d.tmax, precip: d.precip, dry: num(d.precip) && d.precip <= 0.3 }));
    let best = null, run = 0;
    days.forEach((d, i) => {
      run = d.dry ? run + 1 : 0;
      if (run && (!best || run > best.len)) best = { start: i - run + 1, len: run };
    });
    return { days, best };
  }

  // ---------- هشدارهای وابسته به مرحله ----------
  function agroAlerts(ctx) {
    const out = [], si = ctx.si;
    if (si === null || si === undefined) return out;
    const mk = (type, level, icon, title, body, d, idx) => out.push({ key: "ag-" + type + "-" + d + "-" + level, type, level, icon, title, body, date: d, idx });
    (ctx.fdays || []).slice(0, 7).forEach((d, i) => {
      if (si <= 4 && num(d.tmin)) {
        if (d.tmin <= 0) mk("frost", "danger", "🥶", "یخبندان برای لوبیا", "کمینه " + d.tmin.toFixed(1) + "° — لوبیا به یخ‌زدگی حساس است" + (si <= 1 ? " (گیاهچه/برگ جوان)" : "") + "؛ در صورت امکان آبیاری سبک عصر یا پوشش را در نظر بگیرید.", d.date, i);
        else if (d.tmin <= 2) mk("frost", "warn", "🌡", "سرمای نزدیک صفر", "کمینه " + d.tmin.toFixed(1) + "° — در شب‌های صاف و بی‌باد، سطح مزرعه ممکن است یخ بزند.", d.date, i);
      }
      if ((si === 2 || si === 3) && num(d.tmax)) {
        if (d.tmax >= 35) mk("heat", "danger", "🔥", "گرمای شدید در گلدهی/غلاف", "بیشینه " + d.tmax.toFixed(0) + "° — ریزش گل و غلاف محتمل است؛ رطوبت خاک را ثابت نگه دارید.", d.date, i);
        else if (d.tmax >= 32) mk("heat", "warn", "☀️", "گرمای بالا در گلدهی/غلاف", "بیشینه " + d.tmax.toFixed(0) + "° — مراقب تنش آبی و ریزش گل باشید.", d.date, i);
      }
      if (si === 2 && num(d.tmin) && d.tmin > 2 && d.tmin <= 8) mk("cold", "warn", "🌙", "شب سرد در گلدهی", "کمینه " + d.tmin.toFixed(1) + "° — شب‌های خیلی سرد ممکن است تشکیل غلاف را کم کند.", d.date, i);
      if (si >= 4 && i <= 3 && num(d.precip) && d.precip >= 2) mk("harvestrain", "warn", "🌧", "باران هنگام رسیدن/برداشت", "حدود " + d.precip.toFixed(1) + " mm — به رنگ و کیفیت دانه آسیب می‌زند؛ برداشت یا خشک‌کردن را با پنجره‌ی بی‌باران هماهنگ کنید.", d.date, i);
    });
    if (ctx.wet) {
      (ctx.fdays || []).slice(0, 4).forEach((d, i) => {
        const r = diseaseRisk(ctx.wet[d.date], si);
        const o = ctx.wet[d.date];
        if (r === "high") mk("disease", "warn", "🍄", "خطر بیماری‌های قارچی", "حدود " + o.wet + " ساعت رطوبت ≥ ۹۰٪ با دمای میانگین " + o.tAvg.toFixed(0) + "° — شرایط کپک سفید/زنگ؛ بازدید کنید.", d.date, i);
      });
    }
    const irr = ctx.irr;
    if (irr && irr.status === "now") mk("irr", "danger", "💧", "آبیاری لازم است", "کسری آب خاک به آستانه (" + irr.mad + " mm) رسیده است.", ctx.today, 0);
    else if (irr && irr.status === "soon") mk("irr", "warn", "💧", "آبیاری نزدیک است", (irr.nextDate && diffDays(irr.nextDate, ctx.today) <= 0 ? "امروز" : "تا فردا") + " کسری آب به آستانه‌ی " + irr.mad + " mm می‌رسد.", ctx.today, 0);
    return out;
  }


  // ---------- احتمال تاریخی بارش/یخبندان برای یک روز (پنجره‌ی ±half روز در همه‌ی سال‌ها) ----------
  function climateDay(ci, md, half) {
    half = half == null ? 7 : half;
    let n = 0, prN = 0, w1 = 0, w5 = 0, sum = 0, frost = 0, yN = 0, yAny = 0;
    ci.years.forEach(y => {
      const arr = ci.byYear[y], i = arr.findIndex(r => r.md >= md);
      if (i < 0) return;
      for (let k = i - half; k <= i + half; k++) {
        if (k < 0 || k >= arr.length) continue;
        const r = arr[k]; n++;
        if (num(r.tn) && r.tn <= 0) frost++;
        if (num(r.pr)) { prN++; sum += r.pr; if (r.pr >= 1) w1++; if (r.pr >= 5) w5++; }
      }
      let any = false, cnt = 0;
      for (let k = i; k < i + 7 && k < arr.length; k++) if (num(arr[k].pr)) { cnt++; if (arr[k].pr >= 1) any = true; }
      if (cnt) { yN++; if (any) yAny++; }
    });
    return { n, years: ci.years.length, hasRain: prN > 0, p1: prN ? w1 / prN : null, p5: prN ? w5 / prN : null, mean: prN ? sum / prN : null,
      pFrost: n ? frost / n : null, pWeek: yN ? yAny / yN : null };
  }
  function convRisk(h, today) {
    const out = [];
    for (let d = 0; d < 3; d++) {
      const date = addDays(today, d);
      let best = null, prec = 0;
      h.time.forEach((t, i) => {
        if (t.slice(0, 10) !== date) return;
        const hh = +t.slice(11, 13);
        const cape = num(h.cape[i]) ? h.cape[i] : 0, li = h.lifted_index ? h.lifted_index[i] : null;
        const cin = h.convective_inhibition && num(h.convective_inhibition[i]) ? Math.abs(h.convective_inhibition[i]) : 0;
        const pr = h.precipitation && num(h.precipitation[i]) ? h.precipitation[i] : 0;
        prec += pr;
        let s = cape >= 1000 ? 3 : cape >= 500 ? 2 : cape >= 200 ? 1 : 0;
        if (num(li)) s += li <= -4 ? 2 : li <= -2 ? 1 : 0;
        if (cape >= 200) s += cin <= 25 ? 1 : cin >= 150 ? -2 : 0;
        if (pr >= 0.1) s += 1;
        if (!best || s > best.score) best = { score: s, hour: hh, cape, li, cin };
      });
      if (!best) continue;
      out.push({ date, idx: d, score: best.score, level: best.score >= 5 ? "high" : best.score >= 3 ? "mid" : "low", hour: best.hour,
        cape: best.cape, li: best.li, prec, hail: best.cape >= 800 && num(best.li) && best.li <= -3 });
    }
    return out;
  }
  function frostRisk(nights, h) {
    return nights.map(n => {
      const v = (n.tminM || []).filter(num);
      if (!v.length) return null;
      const av = v.reduce((a, b) => a + b, 0) / v.length, mn = Math.min(...v), fr0 = v.filter(x => x <= 0).length / v.length;
      let cloud = null, wind = null;
      if (h) {
        const idx = [];
        h.time.forEach((t, k) => { if (t.slice(0, 10) === n.date && +t.slice(11, 13) <= 7) idx.push(k); });
        if (idx.length >= 4) { cloud = avg(idx.map(k => h.cloud_cover[k])); wind = avg(idx.map(k => h.wind_speed_10m[k])); }
      }
      const rad = cloud !== null && wind !== null && cloud < 35 && wind < 8;
      const adj = rad ? 2.5 : 0.8, ground = av - adj, groundMin = mn - adj;
      const level = (fr0 >= 0.5 || ground <= -1) ? "high" : (fr0 > 0 || ground <= 1) ? "mid" : "low";
      return { date: n.date, av, mn, ground, groundMin, models: v.length, frostModels: Math.round(fr0 * v.length), cloud, wind, rad, level };
    });
  }

  const API = { fetchConv, climateDay, convRisk, frostRisk, CLIM_YEARS, STAGES, MILESTONES, KC_POINTS, GDD_REF, TBASE, TCAP, gddDay, kcAt, stageIdx, effRain,
    parse, fmt, addDays, diffDays, mmdd, nowTehran, refDoy, doyToMd, hourIndex,
    fetchDaily, fetchHourly, getDays, getClim, calcSeason, projectMilestones, climIndex, simulateSowing,
    soilInfo, wetHours, diseaseRisk, plantingStatus, irrigation, harvestDays, agroAlerts };
  root.AshnakhorAgro = API;
  if (typeof module !== "undefined" && module.exports) module.exports = API;
})(typeof self !== "undefined" ? self : globalThis);
