package com.spidersystem.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.GeolocationPermissions
import android.view.View
import androidx.webkit.WebViewAssetLoader
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var webView: WebView
    private var pendingMediaRequest: PermissionRequest? = null
    private var pendingGeoOrigin: String? = null
    private var pendingGeoCallback: GeolocationPermissions.Callback? = null
    private var tts: TextToSpeech? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private var ttsReady = false
    private val mediaRequestCode = 601
    private val geoRequestCode = 602
    private val voiceRequestCode = 603

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(5, 11, 22)
        window.navigationBarColor = android.graphics.Color.rgb(5, 11, 22)
        tts = TextToSpeech(this, this)

        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.mediaPlaybackRequiresUserGesture = true
        webView.settings.setGeolocationEnabled(true)
        webView.addJavascriptInterface(NativeVoiceBridge(), "AndroidVoice")
        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: android.webkit.WebResourceRequest) =
                assetLoader.shouldInterceptRequest(request.url)
        }
        webView.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread {
                    val missing = mutableListOf<String>()
                    if (request.resources.contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE) && ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) missing.add(Manifest.permission.CAMERA)
                    if (request.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE) && ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) missing.add(Manifest.permission.RECORD_AUDIO)
                    if (missing.isEmpty()) request.grant(request.resources) else {
                        pendingMediaRequest = request
                        ActivityCompat.requestPermissions(this@MainActivity, missing.toTypedArray(), mediaRequestCode)
                    }
                }
            }
            override fun onGeolocationPermissionsShowPrompt(origin: String, callback: GeolocationPermissions.Callback) {
                val fine = ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                val coarse = ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
                if (fine || coarse) callback.invoke(origin, true, false) else {
                    pendingGeoOrigin = origin; pendingGeoCallback = callback
                    ActivityCompat.requestPermissions(this@MainActivity, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), geoRequestCode)
                }
            }
        }
        webView.setBackgroundColor(android.graphics.Color.rgb(5, 11, 22))
        webView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        setContentView(webView)
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("es", "PY")) ?: TextToSpeech.LANG_MISSING_DATA
            ttsReady = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED
            if (!ttsReady) ttsReady = (tts?.setLanguage(Locale("es", "ES")) ?: -1) >= 0
        }
    }

    private fun jsCallback(function: String, value: String) {
        runOnUiThread { if (::webView.isInitialized) webView.evaluateJavascript("window.$function(${JSONObject.quote(value)})", null) }
    }

    inner class NativeVoiceBridge {
        @JavascriptInterface fun speak(message: String) {
            runOnUiThread {
                if (ttsReady) tts?.speak(message.take(500), TextToSpeech.QUEUE_FLUSH, null, "spider-karen")
                else jsCallback("nativeSpeechStatus", "TTS_NO_DISPONIBLE")
            }
        }
        @JavascriptInterface fun listen() {
            runOnUiThread {
                if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(this@MainActivity, arrayOf(Manifest.permission.RECORD_AUDIO), voiceRequestCode)
                } else startNativeRecognition()
            }
        }
        @JavascriptInterface fun stopSpeaking() { runOnUiThread { tts?.stop() } }
        @JavascriptInterface fun stopListening() { runOnUiThread { speechRecognizer?.cancel(); speechRecognizer?.destroy(); speechRecognizer = null } }
    }

    private fun startNativeRecognition() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { jsCallback("nativeSpeechStatus", "RECONOCIMIENTO_NO_DISPONIBLE"); return }
        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).also { recognizer ->
            recognizer.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { jsCallback("nativeSpeechStatus", "ESCUCHANDO") }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { jsCallback("nativeSpeechStatus", "PROCESANDO") }
                override fun onError(error: Int) { jsCallback("nativeSpeechStatus", "ERROR_$error"); speechRecognizer?.destroy(); speechRecognizer = null }
                override fun onResults(results: Bundle?) {
                    val spoken = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    jsCallback("nativeSpeechResult", spoken)
                    speechRecognizer?.destroy(); speechRecognizer = null
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-PY")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "es-PY")
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            }
            recognizer.startListening(intent)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == voiceRequestCode) {
            if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) startNativeRecognition()
            else jsCallback("nativeSpeechStatus", "PERMISO_MICROFONO_DENEGADO")
        } else if (requestCode == mediaRequestCode) {
            val request = pendingMediaRequest
            if (request != null) {
                val resources = request.resources.filter { resource ->
                    (resource == PermissionRequest.RESOURCE_VIDEO_CAPTURE && ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) ||
                    (resource == PermissionRequest.RESOURCE_AUDIO_CAPTURE && ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
                }
                if (resources.isNotEmpty()) request.grant(resources.toTypedArray()) else request.deny()
                pendingMediaRequest = null
            }
        } else if (requestCode == geoRequestCode) {
            val allowed = grantResults.any { it == PackageManager.PERMISSION_GRANTED }
            pendingGeoCallback?.invoke(pendingGeoOrigin, allowed, false); pendingGeoCallback = null; pendingGeoOrigin = null
        }
    }

    @Deprecated("Deprecated in Java") override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
    override fun onDestroy() {
        speechRecognizer?.destroy(); tts?.stop(); tts?.shutdown()
        if (::webView.isInitialized) { webView.removeJavascriptInterface("AndroidVoice"); webView.destroy() }
        super.onDestroy()
    }
}
