# ODP Monitor Android (starter project)

Aplikasi Android native untuk pencatatan ODP FTTH dengan pendekatan offline-first:
- Room database menyimpan data lokal di HP.
- Firebase Authentication untuk akun teknisi.
- Cloud Firestore untuk berbagi data per tim.
- Peta OpenStreetMap menampilkan marker ODP; marker menampilkan ringkasan redaman terbaru.
- Tombol Google Maps membuka navigasi ke koordinat ODP.
- Setiap pengukuran menjadi catatan riwayat baru, tidak menimpa pengukuran lama.

## Penting: APK belum dibangun
Folder ini adalah **source project Android Studio**, bukan file APK siap instal. Lingkungan pembuat file ini tidak memiliki Android SDK/Gradle build environment dan belum memiliki konfigurasi Firebase milik tim. APK final baru dapat dibangun setelah konfigurasi Firebase ditambahkan dan project dibuka di Android Studio.

## Persiapan Firebase (wajib untuk multi-teknisi)
1. Buat project di https://console.firebase.google.com/.
2. Tambahkan Android app dengan package name `id.odpmonitor.app`.
3. Unduh `google-services.json`, lalu letakkan di `app/google-services.json`.
4. Di Firebase Authentication, aktifkan provider **Email/Password**.
5. Buat database Cloud Firestore.
6. Salin isi file `firestore.rules` ke tab Firestore Rules lalu publish.
7. Buka project ini di Android Studio dan tunggu Gradle sync.

## Build APK
Di Android Studio: **Build > Build Bundle(s) / APK(s) > Build APK(s)**. APK debug biasanya muncul di `app/build/outputs/apk/debug/app-debug.apk`.

Atau dari terminal yang memiliki Android SDK dan Gradle:

```bash
gradle assembleDebug
```

## Cara penggunaan
1. Setiap teknisi membuat akun menggunakan email masing-masing.
2. Satu teknisi memilih **Buat tim baru** dan menentukan kode tim.
3. Teknisi lain mendaftar/masuk lalu memilih **Gabung tim dengan kode** yang sama.
4. ODP dan pengukuran yang disimpan akan masuk ke database lokal dan antrean sinkronisasi.
5. Saat online, aplikasi mencoba mengirim antrean ke Firestore dan mengambil data terbaru tim.

## Catatan versi awal
- Sinkronisasi dipicu ketika aplikasi dibuka dan setelah data disimpan. Sinkronisasi latar belakang terjadwal, notifikasi konflik, manajemen peran admin/teknisi, dan penghapusan data cloud belum dibuat.
- Peta memakai tile OpenStreetMap dan membutuhkan internet untuk memuat peta. Koordinat ODP pada versi awal diisi manual melalui form.
- Jangan gunakan data pelanggan sungguhan sebelum aturan Firestore, akun tim, dan backup diuji. Data nama/alamat pelanggan adalah data pribadi; batasi akses hanya untuk anggota tim yang berwenang.
- Jika ada dua teknisi mengubah ODP yang sama bersamaan, versi awal menggunakan update terakhir yang tersinkron. Mekanisme audit konflik perlu ditambahkan sebelum pemakaian operasional skala besar.
