package id.odpmonitor.app.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface OdpDao {
    @Query("SELECT * FROM odps WHERE teamId = :teamId ORDER BY name") fun observeOdps(teamId: String): Flow<List<OdpEntity>>
    @Query("SELECT * FROM odps WHERE id = :id LIMIT 1") suspend fun getOdp(id: String): OdpEntity?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putOdp(odp: OdpEntity)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putOdps(items: List<OdpEntity>)
    @Query("SELECT * FROM odps WHERE syncPending = 1 AND teamId = :teamId") suspend fun pendingOdps(teamId: String): List<OdpEntity>
    @Query("UPDATE odps SET syncPending = 0 WHERE id = :id") suspend fun markOdpSynced(id: String)
    @Query("DELETE FROM odps WHERE id = :id") suspend fun deleteOdp(id: String)

    @Query("SELECT * FROM measurements WHERE teamId = :teamId ORDER BY measuredAt DESC") fun observeMeasurements(teamId: String): Flow<List<MeasurementEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putMeasurement(item: MeasurementEntity)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putMeasurements(items: List<MeasurementEntity>)
    @Query("SELECT * FROM measurements WHERE syncPending = 1 AND teamId = :teamId") suspend fun pendingMeasurements(teamId: String): List<MeasurementEntity>
    @Query("UPDATE measurements SET syncPending = 0 WHERE id = :id") suspend fun markMeasurementSynced(id: String)
}
