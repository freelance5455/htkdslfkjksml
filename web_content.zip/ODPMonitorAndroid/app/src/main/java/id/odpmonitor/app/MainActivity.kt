package id.odpmonitor.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.material3.ExperimentalMaterial3Api
import android.widget.Toast
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.room.Room
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import id.odpmonitor.app.data.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.util.UUID

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = AppDatabase.get(this)
        setContent { OdpMonitorApp(db.odpDao()) }
    }
}

@Composable
@OptIn(ExperimentalMaterial3Api::class)
private fun OdpMonitorApp(dao: OdpDao) {
    val context = LocalContext.current
    val auth = remember { FirebaseAuth.getInstance() }
    val cloud = remember { FirebaseFirestore.getInstance() }
    val sync = remember { CloudSync(dao) }
    val prefs = remember { context.getSharedPreferences("odp-session", 0) }
    var user by remember { mutableStateOf(auth.currentUser) }
    var teamId by remember { mutableStateOf(prefs.getString("teamId", "") ?: "") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var teamCode by remember { mutableStateOf("") }
    var odpName by remember { mutableStateOf("") }
    var area by remember { mutableStateOf("") }
    var lat by remember { mutableStateOf("") }
    var lng by remember { mutableStateOf("") }
    var inPower by remember { mutableStateOf("") }
    var ratio by remember { mutableStateOf("") }
    var splitter by remember { mutableStateOf("") }
    var custName by remember { mutableStateOf("") }
    var custAddress by remember { mutableStateOf("") }
    var custPort by remember { mutableStateOf("") }
    var custPower by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var selectedOdp by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Siap. Data lokal tersimpan di perangkat.") }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val odps by dao.observeOdps(teamId.ifBlank { "_none_" }).collectAsState(initial = emptyList())
    val measurements by dao.observeMeasurements(teamId.ifBlank { "_none_" }).collectAsState(initial = emptyList())

    MaterialTheme(colorScheme = darkColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF39C6A5), background = androidx.compose.ui.graphics.Color(0xFF0B1220), surface = androidx.compose.ui.graphics.Color(0xFF121D2E))) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            if (user == null) {
                AuthScreen(email, { email = it }, password, { password = it }, status, busy,
                    onLogin = { register -> scope.launch {
                        busy = true
                        try {
                            if (register) auth.createUserWithEmailAndPassword(email.trim(), password).await()
                            else auth.signInWithEmailAndPassword(email.trim(), password).await()
                            user = auth.currentUser; status = "Login berhasil"
                        } catch (e: Exception) { status = e.localizedMessage ?: "Login gagal" }
                        busy = false
                    } })
            } else if (teamId.isBlank()) {
                TeamScreen(teamCode, { teamCode = it }, status, busy,
                    onTeam = { create -> scope.launch {
                        busy = true
                        try {
                            val code = teamCode.trim().uppercase().replace(" ", "")
                            require(code.length >= 4) { "Kode tim minimal 4 karakter" }
                            val uid = user!!.uid
                            val teamRef = cloud.collection("teams").document(code)
                            if (create) {
                                teamRef.set(mapOf("name" to code, "createdBy" to uid, "createdAt" to System.currentTimeMillis())).await()
                            } else {
                                require(teamRef.get().await().exists()) { "Kode tim tidak ditemukan" }
                            }
                            teamRef.collection("members").document(uid).set(mapOf("email" to user!!.email, "joinedAt" to System.currentTimeMillis())).await()
                            teamId = code; prefs.edit().putString("teamId", code).apply()
                            status = "Berhasil masuk tim $code"
                            try { sync.pushPending(code); sync.pullLatest(code) } catch (_: Exception) { status = "Tim tersimpan. Sinkronisasi menunggu internet/aturan Firebase." }
                        } catch (e: Exception) { status = e.localizedMessage ?: "Gagal mengatur tim" }
                        busy = false
                    } })
            } else {
                LaunchedEffect(teamId) {
                    try { sync.pushPending(teamId); sync.pullLatest(teamId); status = "Tersinkron dengan tim $teamId" }
                    catch (_: Exception) { status = "Mode offline. Perubahan akan dicoba sinkron saat aplikasi dibuka dan tersambung internet." }
                }
                LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    item {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column { Text("ODP Monitor", style = MaterialTheme.typography.headlineSmall); Text("Tim $teamId • ${user?.email ?: ""}", style = MaterialTheme.typography.bodySmall) }
                            TextButton(onClick = { auth.signOut(); user = null; teamId = ""; prefs.edit().remove("teamId").apply() }) { Text("Keluar") }
                        }
                        Text(status, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            StatCard("ODP", odps.size.toString(), Modifier.weight(1f))
                            StatCard("Pelanggan", measurements.count { it.customerName.isNotBlank() }.toString(), Modifier.weight(1f))
                            StatCard("Catatan", measurements.size.toString(), Modifier.weight(1f))
                        }
                    }
                    item { OdpMapPanel(odps, measurements) }
                    item {
                        Card { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Tambah ODP", style = MaterialTheme.typography.titleMedium)
                            OutlinedTextField(odpName, { odpName = it }, label = { Text("Kode / nama ODP *") }, modifier = Modifier.fillMaxWidth())
                            OutlinedTextField(area, { area = it }, label = { Text("Area / alamat") }, modifier = Modifier.fillMaxWidth())
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(lat, { lat = it }, label = { Text("Latitude") }, modifier = Modifier.weight(1f), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                                OutlinedTextField(lng, { lng = it }, label = { Text("Longitude") }, modifier = Modifier.weight(1f), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                            }
                            Button(onClick = {
                                if (odpName.isBlank()) { status = "Nama ODP wajib diisi"; return@Button }
                                scope.launch {
                                    val item = OdpEntity(UUID.randomUUID().toString(), teamId, odpName.trim(), area.trim(), lat.toDoubleOrNull(), lng.toDoubleOrNull())
                                    dao.putOdp(item); odpName = ""; area = ""; lat = ""; lng = ""
                                    status = "ODP disimpan di HP. Sinkronisasi akan berjalan saat online."
                                    try { sync.pushPending(teamId); status = "ODP tersimpan dan tersinkron" } catch (_: Exception) {}
                                }
                            }, modifier = Modifier.fillMaxWidth()) { Text("Simpan ODP") }
                        } }
                    }
                    item {
                        Card { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Catat redaman & pelanggan", style = MaterialTheme.typography.titleMedium)
                            var expanded by remember { mutableStateOf(false) }
                            ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
                                OutlinedTextField(value = odps.find { it.id == selectedOdp }?.name ?: "Pilih ODP", onValueChange = {}, readOnly = true, label = { Text("ODP *") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) }, modifier = Modifier.menuAnchor().fillMaxWidth())
                                ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) { odps.forEach { o -> DropdownMenuItem(text = { Text(o.name) }, onClick = { selectedOdp = o.id; expanded = false }) } }
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                NumberField("IN ODP dBm", inPower, { inPower = it }, Modifier.weight(1f))
                                NumberField("OUT rasio dBm", ratio, { ratio = it }, Modifier.weight(1f))
                            }
                            NumberField("OUT splitter dBm", splitter, { splitter = it }, Modifier.fillMaxWidth())
                            HorizontalDivider()
                            OutlinedTextField(custName, { custName = it }, label = { Text("Nama pelanggan") }, modifier = Modifier.fillMaxWidth())
                            OutlinedTextField(custAddress, { custAddress = it }, label = { Text("Alamat rumah pelanggan") }, modifier = Modifier.fillMaxWidth())
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(custPort, { custPort = it }, label = { Text("Port / splitter") }, modifier = Modifier.weight(1f))
                                NumberField("Redaman pelanggan", custPower, { custPower = it }, Modifier.weight(1f))
                            }
                            OutlinedTextField(note, { note = it }, label = { Text("Catatan teknisi") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                            Button(onClick = {
                                if (selectedOdp.isBlank()) { status = "Pilih ODP terlebih dahulu"; return@Button }
                                scope.launch {
                                    val item = MeasurementEntity(UUID.randomUUID().toString(), teamId, selectedOdp, inPower.toDoubleOrNull(), ratio.toDoubleOrNull(), splitter.toDoubleOrNull(), custName.trim(), custAddress.trim(), custPort.trim(), custPower.toDoubleOrNull(), note.trim(), createdBy = user?.uid ?: "")
                                    dao.putMeasurement(item)
                                    inPower = ""; ratio = ""; splitter = ""; custName = ""; custAddress = ""; custPort = ""; custPower = ""; note = ""
                                    status = "Pengukuran tersimpan lokal. Menunggu sinkronisasi."
                                    try { sync.pushPending(teamId); status = "Pengukuran berhasil disinkronkan ke tim." } catch (_: Exception) {}
                                }
                            }, modifier = Modifier.fillMaxWidth()) { Text("Simpan pengukuran") }
                        } }
                    }
                    item { Text("Daftar titik ODP", style = MaterialTheme.typography.titleLarge) }
                    items(odps, key = { it.id }) { o ->
                        val last = measurements.filter { it.odpId == o.id }.maxByOrNull { it.measuredAt }
                        Card { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            Text(o.name, style = MaterialTheme.typography.titleMedium)
                            Text(o.area.ifBlank { "Lokasi belum diisi" }, style = MaterialTheme.typography.bodySmall)
                            Text("IN ${fmt(last?.inPower)} • Rasio ${fmt(last?.ratioPower)} • Splitter ${fmt(last?.splitterPower)}", style = MaterialTheme.typography.bodySmall)
                            Text("Pelanggan terakhir: ${last?.customerName?.ifBlank { "Belum ada" } ?: "Belum ada"} • ${fmt(last?.customerPower)}", style = MaterialTheme.typography.bodySmall)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                TextButton(onClick = {
                                    val uri = if (o.latitude != null && o.longitude != null) Uri.parse("https://www.google.com/maps/search/?api=1&query=${o.latitude},${o.longitude}") else Uri.parse("https://www.google.com/maps")
                                    context.startActivity(Intent(Intent.ACTION_VIEW, uri))
                                }) { Text("Buka Maps") }
                                TextButton(onClick = { selectedOdp = o.id }) { Text("Catat di ODP ini") }
                            }
                        } }
                    }
                    item { Text("Riwayat pengukuran", style = MaterialTheme.typography.titleLarge) }
                    items(measurements.take(30), key = { it.id }) { m ->
                        val name = odps.find { it.id == m.odpId }?.name ?: "ODP tidak ditemukan"
                        Card { Column(Modifier.padding(12.dp)) {
                            Text("$name • ${m.customerName.ifBlank { "Tanpa nama pelanggan" }}", style = MaterialTheme.typography.titleSmall)
                            Text("IN ${fmt(m.inPower)} | Rasio ${fmt(m.ratioPower)} | Splitter ${fmt(m.splitterPower)} | Pelanggan ${fmt(m.customerPower)}", style = MaterialTheme.typography.bodySmall)
                            Text(m.customerAddress, style = MaterialTheme.typography.bodySmall)
                        } }
                    }
                }
            }
        }
    }
}

@Composable private fun AuthScreen(email: String, onEmail: (String) -> Unit, password: String, onPassword: (String) -> Unit, status: String, busy: Boolean, onLogin: (Boolean) -> Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text("ODP Monitor", style = MaterialTheme.typography.headlineLarge)
        Text("Masuk untuk mengakses data tim teknisi", style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(18.dp))
        OutlinedTextField(email, onEmail, label = { Text("Email") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(password, onPassword, label = { Text("Password") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
        Text(status, style = MaterialTheme.typography.bodySmall)
        Button(onClick = { onLogin(false) }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("Masuk") }
        OutlinedButton(onClick = { onLogin(true) }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("Daftar akun baru") }
    }
}

@Composable private fun TeamScreen(code: String, onCode: (String) -> Unit, status: String, busy: Boolean, onTeam: (Boolean) -> Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text("Gabung ke tim", style = MaterialTheme.typography.headlineMedium)
        Text("Gunakan kode tim yang sama agar semua teknisi berbagi data ODP.", style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(code, onCode, label = { Text("Kode tim") }, modifier = Modifier.fillMaxWidth())
        Text(status, style = MaterialTheme.typography.bodySmall)
        Button(onClick = { onTeam(false) }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("Gabung tim dengan kode") }
        OutlinedButton(onClick = { onTeam(true) }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("Buat tim baru") }
    }
}

@Composable private fun NumberField(label: String, value: String, onValue: (String) -> Unit, modifier: Modifier = Modifier) {
    OutlinedTextField(value, onValue, label = { Text(label) }, modifier = modifier, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
}
@Composable private fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier) { Column(Modifier.padding(12.dp)) { Text(label, style = MaterialTheme.typography.bodySmall); Text(value, style = MaterialTheme.typography.headlineSmall) } }
}
private fun fmt(value: Double?): String = value?.let { "%.2f dBm".format(it) } ?: "-"

@Composable private fun OdpMapPanel(odps: List<OdpEntity>, measurements: List<MeasurementEntity>) {
    val context = LocalContext.current
    Card {
        Column(Modifier.padding(12.dp)) {
            Text("Peta titik ODP", style = MaterialTheme.typography.titleMedium)
            Text("Ketuk marker untuk melihat redaman terakhir", style = MaterialTheme.typography.bodySmall)
            AndroidView(
                modifier = Modifier.fillMaxWidth().height(260.dp),
                factory = { ctx ->
                    Configuration.getInstance().userAgentValue = ctx.packageName
                    MapView(ctx).apply {
                        setTileSource(TileSourceFactory.MAPNIK)
                        setMultiTouchControls(true)
                        controller.setZoom(5.0)
                        controller.setCenter(GeoPoint(-2.5, 118.0))
                    }
                },
                update = { map ->
                    map.overlays.removeAll { it is Marker }
                    val located = odps.filter { it.latitude != null && it.longitude != null }
                    located.forEach { odp ->
                        val last = measurements.filter { it.odpId == odp.id }.maxByOrNull { it.measuredAt }
                        val marker = Marker(map).apply {
                            position = GeoPoint(odp.latitude!!, odp.longitude!!)
                            title = odp.name
                            snippet = "IN ${fmt(last?.inPower)} | Rasio ${fmt(last?.ratioPower)} | Splitter ${fmt(last?.splitterPower)}\nPelanggan: ${last?.customerName?.ifBlank { "-" } ?: "-"} | ${fmt(last?.customerPower)}"
                            setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
                            setOnMarkerClickListener { m, _ ->
                                m.showInfoWindow()
                                Toast.makeText(context, m.title + "\n" + (m.snippet ?: ""), Toast.LENGTH_LONG).show()
                                true
                            }
                        }
                        map.overlays.add(marker)
                    }
                    if (located.isNotEmpty() && map.tag != located.first().id) {
                        map.controller.setZoom(14.0)
                        map.controller.setCenter(GeoPoint(located.first().latitude!!, located.first().longitude!!))
                        map.tag = located.first().id
                    }
                    map.invalidate()
                }
            )
        }
    }
}
