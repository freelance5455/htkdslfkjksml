package id.odpmonitor.app.data

import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await

/** Offline-first sync. Room is the local source; Firestore is the shared team copy. */
class CloudSync(private val dao: OdpDao, private val cloud: FirebaseFirestore = FirebaseFirestore.getInstance()) {
    suspend fun pushPending(teamId: String) {
        dao.pendingOdps(teamId).forEach { item ->
            cloud.collection("teams").document(teamId).collection("odps").document(item.id)
                .set(item.copy(syncPending = false)).await()
            dao.markOdpSynced(item.id)
        }
        dao.pendingMeasurements(teamId).forEach { item ->
            cloud.collection("teams").document(teamId).collection("measurements").document(item.id)
                .set(item.copy(syncPending = false)).await()
            dao.markMeasurementSynced(item.id)
        }
    }

    suspend fun pullLatest(teamId: String) {
        val odpDocs = cloud.collection("teams").document(teamId).collection("odps").get().await()
        dao.putOdps(odpDocs.documents.mapNotNull { it.toObject(OdpEntity::class.java)?.copy(syncPending = false) })
        val measureDocs = cloud.collection("teams").document(teamId).collection("measurements").get().await()
        dao.putMeasurements(measureDocs.documents.mapNotNull { it.toObject(MeasurementEntity::class.java)?.copy(syncPending = false) })
    }
}
