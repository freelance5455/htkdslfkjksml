package id.odpmonitor.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "odps")
data class OdpEntity(
    @PrimaryKey val id: String = "",
    val teamId: String = "",
    val name: String = "",
    val area: String = "",
    val latitude: Double? = null,
    val longitude: Double? = null,
    val note: String = "",
    val updatedAt: Long = System.currentTimeMillis(),
    val syncPending: Boolean = true
)

@Entity(tableName = "measurements")
data class MeasurementEntity(
    @PrimaryKey val id: String = "",
    val teamId: String = "",
    val odpId: String = "",
    val inPower: Double? = null,
    val ratioPower: Double? = null,
    val splitterPower: Double? = null,
    val customerName: String = "",
    val customerAddress: String = "",
    val customerPort: String = "",
    val customerPower: Double? = null,
    val note: String = "",
    val measuredAt: Long = System.currentTimeMillis(),
    val createdBy: String = "",
    val syncPending: Boolean = true
)
