
(function () {
  if (window.__gsExportCaptureGuard) return;
  // Truthy install marker, and home of `rasterize` below.
  var guard = window.__gsExportCaptureGuard = {};

  // Stay under the ~16384px per-edge canvas limit (Chrome/Safari), with slack.
  var MAX_EDGE = 16000;
  // Right-side safety margin (CSS px, pre-scale). Measurements are integers
  // over fractional layout (scrollWidth truncates, text metrics differ by a
  // hair when the clone re-lays-out), and box-shadows extend past the border
  // box entirely — either can shave the last pixel(s) off the right edge,
  // which reads as a clipped border. A small slack strip absorbs the whole
  // class; downstream fit-to-page scaling renders it as an invisible margin.
  var EDGE_BLEED = 12;
  var ATTR = 'data-gs-expand';

  function isClippingX(el, cs) {
    var ox = cs.overflowX;
    if (ox !== 'auto' && ox !== 'scroll' && ox !== 'hidden' && ox !== 'clip') return false;
    return (el.scrollWidth || 0) > (el.clientWidth || 0) + 1;
  }

  // True horizontal extent of `target`: its own scrollWidth plus the hidden
  // inner width of any descendant scroll container. Those wrappers are marked
  // with ATTR (carrying their inner width) so onclone can expand the clones;
  // the attribute is removed after the capture settles.
  function measure(target) {
    var doc = target.ownerDocument || document;
    var view = doc.defaultView || window;
    var rect = target.getBoundingClientRect();
    var need = Math.ceil(Math.max(target.scrollWidth || 0, rect.width || 0));
    var marked = [];
    // The capture target ITSELF may be the overflow-x scroller (apps often
    // export the scroll wrapper directly): widening the canvas alone leaves
    // its own box clipping the columns, so it needs expansion like any
    // marked descendant.
    var nodes = [target].concat(Array.prototype.slice.call(target.querySelectorAll('*')));
    for (var i = 0; i < nodes.length; i++) {
      var el = nodes[i];
      var cs;
      try { cs = view.getComputedStyle(el); } catch (e) { continue; }
      if (!cs || !isClippingX(el, cs)) continue;
      var r = el.getBoundingClientRect();
      need = Math.max(need, Math.ceil((r.left - rect.left) + el.scrollWidth));
      try {
        el.setAttribute(ATTR, String(el.scrollWidth));
        marked.push(el);
      } catch (e) {}
    }
    return { need: need, marked: marked };
  }

  function expandClones(clonedDoc) {
    var list = clonedDoc.querySelectorAll('[' + ATTR + ']');
    for (var i = 0; i < list.length; i++) {
      var el = list[i];
      var w = parseInt(el.getAttribute(ATTR), 10);
      el.style.overflowX = 'visible';
      el.style.maxWidth = 'none';
      if (w > 0) el.style.minWidth = w + 'px';
    }
  }

  function cleanup(marked) {
    for (var i = 0; i < marked.length; i++) {
      try { marked[i].removeAttribute(ATTR); } catch (e) {}
    }
  }

  // html2canvas 1.4 parses only rgb() / hsl() colors and throws on any other
  // color function, failing the whole capture, while browsers keep oklch(),
  // lab() and friends in computed styles and compute color-mix() to
  // color(srgb ...). Pin each such computed color to rgba() in the clone it
  // draws. The FO path needs none of this: the browser paints those colors.
  // The parent's PDF download does the same (utils/agentdb/appPrintPdf.ts).
  var COLOR_PROPS = ['color', 'background-color', 'background-image',
    'border-top-color', 'border-right-color', 'border-bottom-color',
    'border-left-color', 'box-shadow', 'text-decoration-color', 'text-shadow',
    '-webkit-text-stroke-color'];
  var MODERN_COLOR = '(^|[^\\w-])(oklch|oklab|lab|lch|hwb|color)\\(';
  var TRANSPARENT = 'rgba(0, 0, 0, 0)';

  // Index just past the ')' closing a function whose arguments start at `from`.
  function closingParen(value, from) {
    var depth = 1, quote = '';
    for (var i = from; i < value.length; i++) {
      var ch = value.charAt(i);
      if (quote) {
        if (ch === '\\') i++;
        else if (ch === quote) quote = '';
      } else if (ch === '"' || ch === "'") quote = ch;
      else if (ch === '(') depth++;
      else if (ch === ')' && --depth === 0) return i + 1;
    }
    return value.length;
  }

  // `value` with each such color function replaced by toRgb of it; a url()
  // is copied as it is.
  function legacyColorValue(value, toRgb) {
    var re = new RegExp('url\\(|' + MODERN_COLOR, 'gi');
    var out = '', copied = 0, m, start, end, whole;
    while ((m = re.exec(value))) {
      // The lead-in character belongs to the text before the function.
      start = m.index + (m[1] ? m[1].length : 0);
      end = closingParen(value, re.lastIndex);
      whole = value.slice(start, end);
      out += value.slice(copied, start);
      out += /^url/i.test(whole) ? whole : toRgb(whole);
      copied = re.lastIndex = end;
    }
    return out + value.slice(copied);
  }

  // Any CSS color as rgba(), through a 1x1 canvas; one it cannot parse comes
  // out transparent, losing that color rather than the whole capture.
  function canvasColorConverter(doc) {
    var cv = doc.createElement('canvas');
    cv.width = 1;
    cv.height = 1;
    var cx = cv.getContext('2d', { willReadFrequently: true });
    var converted = {};
    return function (color) {
      if (Object.prototype.hasOwnProperty.call(converted, color)) return converted[color];
      var rgb = TRANSPARENT;
      try {
        cx.clearRect(0, 0, 1, 1);
        cx.fillStyle = TRANSPARENT;
        cx.fillStyle = color;
        cx.fillRect(0, 0, 1, 1);
        var d = cx.getImageData(0, 0, 1, 1).data;
        rgb = 'rgba(' + d[0] + ', ' + d[1] + ', ' + d[2] + ', ' + Math.round(d[3] / 255 * 1000) / 1000 + ')';
      } catch (e) {}
      converted[color] = rgb;
      return rgb;
    };
  }

  // All reads before any write, so the clone restyles once, not per element.
  // Transitions go off in the same write: a running color transition
  // outranks !important and would leave html2canvas its oklab() start value.
  function pinLegacyColors(clonedDoc) {
    var view = clonedDoc.defaultView;
    if (!view) return;
    var modern = new RegExp(MODERN_COLOR, 'i');
    var toRgb = canvasColorConverter(clonedDoc);
    var all = clonedDoc.querySelectorAll('*'), pinned = [];
    for (var i = 0; i < all.length; i++) {
      var cs;
      try { cs = view.getComputedStyle(all[i]); } catch (e) { continue; }
      if (!cs) continue;
      for (var k = 0; k < COLOR_PROPS.length; k++) {
        var v = cs.getPropertyValue(COLOR_PROPS[k]);
        if (v && modern.test(v)) pinned.push([all[i], COLOR_PROPS[k], legacyColorValue(v, toRgb)]);
      }
    }
    for (var j = 0; j < pinned.length; j++) {
      try {
        pinned[j][0].style.setProperty('transition', 'none', 'important');
        pinned[j][0].style.setProperty(pinned[j][1], pinned[j][2], 'important');
      } catch (e) {}
    }
  }

  // Opaque origin (CSP sandbox without allow-same-origin): html2canvas's
  // internal clone iframe would be cross-origin and throw SecurityError.
  function isOpaqueOrigin() {
    try { return String(window.origin) === 'null'; } catch (e) { return false; }
  }

  // ── FO rasterizer (opaque-origin replacement for html2canvas) ──

  // Copy every computed style onto the clone as inline style so the clone
  // renders identically inside the isolated SVG-image context (which sees no
  // stylesheets). Also reflects live form state, which cloneNode drops.
  function inlineStyles(srcEl, dstEl, view) {
    var cs;
    try { cs = view.getComputedStyle(srcEl); } catch (e) { return; }
    if (!cs) return;
    var buf = [];
    for (var i = 0; i < cs.length; i++) {
      var prop = cs[i];
      buf.push(prop + ':' + cs.getPropertyValue(prop) + ';');
    }
    // The SVG data URL loads as a fresh document, so copied animation /
    // transition values would restart entrance animations at their 0%
    // keyframes (often opacity:0) and export blank. Later declarations in
    // the same style attribute win, so pin them off here.
    buf.push('animation:none;transition:none;');
    dstEl.setAttribute('style', buf.join(''));
    var tag = srcEl.tagName;
    if (tag === 'INPUT') {
      try {
        dstEl.setAttribute('value', srcEl.value);
        if (srcEl.checked) dstEl.setAttribute('checked', 'checked');
        else dstEl.removeAttribute('checked');
      } catch (e) {}
    } else if (tag === 'TEXTAREA') {
      try { dstEl.textContent = srcEl.value; } catch (e) {}
    } else if (tag === 'SELECT') {
      try {
        var opts = srcEl.options, dopts = dstEl.options;
        for (var oi = 0; oi < opts.length; oi++) {
          if (dopts[oi]) {
            if (opts[oi].selected) dopts[oi].setAttribute('selected', 'selected');
            else dopts[oi].removeAttribute('selected');
          }
        }
      } catch (e) {}
    }
  }

  // HTML parsing tolerates attribute names XML forbids (a stray quote in
  // LLM-authored markup yields attributes literally named `"junk"`).
  // XMLSerializer emits them verbatim and the SVG then fails to PARSE, so
  // the whole FO rasterization rejects. Keep only valid-XML-Name attributes.
  var XML_ATTR_NAME = /^[A-Za-z_][A-Za-z0-9_.:\-]*$/;

  function stripInvalidXmlAttrs(root) {
    var all = [root].concat(Array.prototype.slice.call(root.querySelectorAll('*')));
    for (var i = 0; i < all.length; i++) {
      var attrs = all[i].attributes;
      if (!attrs) continue;
      for (var a = attrs.length - 1; a >= 0; a--) {
        if (!XML_ATTR_NAME.test(attrs[a].name)) {
          try { all[i].removeAttribute(attrs[a].name); } catch (e) {}
        }
      }
    }
  }

  // Build a fully inlined clone of `el`. Canvases become <img> data URLs;
  // script/embed-ish nodes are dropped (inert or blank inside an SVG image).
  function buildInlinedClone(el, view) {
    var clone = el.cloneNode(true);
    var srcAll = [el].concat(Array.prototype.slice.call(el.querySelectorAll('*')));
    var dstAll = [clone].concat(Array.prototype.slice.call(clone.querySelectorAll('*')));
    for (var i = 0; i < srcAll.length && i < dstAll.length; i++) {
      inlineStyles(srcAll[i], dstAll[i], view);
    }
    stripInvalidXmlAttrs(clone);
    // canvas → img (chart libraries paint onto canvas; SVG images cannot).
    var srcCanvases = el.querySelectorAll('canvas');
    var dstCanvases = clone.querySelectorAll('canvas');
    for (var c = 0; c < srcCanvases.length; c++) {
      var dc = dstCanvases[c];
      if (!dc || !dc.parentNode) continue;
      try {
        var im = document.createElement('img');
        im.src = srcCanvases[c].toDataURL('image/png');
        im.setAttribute('style', dc.getAttribute('style') || '');
        im.setAttribute('width', String(srcCanvases[c].width));
        im.setAttribute('height', String(srcCanvases[c].height));
        dc.parentNode.replaceChild(im, dc);
      } catch (e) { /* tainted canvas — leave the (blank) canvas */ }
    }
    var junk = clone.querySelectorAll('script,iframe,video,audio,embed,object,source,track');
    for (var j = junk.length - 1; j >= 0; j--) {
      if (junk[j].parentNode) junk[j].parentNode.removeChild(junk[j]);
    }
    stripComments(clone);
    return clone;
  }

  // HTML comments containing '--' are invalid XML and abort SVG parsing;
  // the FO screenshot pipeline strips comment nodes for the same reason.
  function stripComments(root) {
    var doc = root.ownerDocument || document;
    var walker = doc.createTreeWalker(root, 128 /* NodeFilter.SHOW_COMMENT */);
    var comments = [];
    while (walker.nextNode()) comments.push(walker.currentNode);
    for (var i = 0; i < comments.length; i++) {
      if (comments[i].parentNode) comments[i].parentNode.removeChild(comments[i]);
    }
  }

  function foRasterize(el, opts, needW) {
    var view = (el.ownerDocument || document).defaultView || window;
    var bg = opts.backgroundColor === null ? null : (opts.backgroundColor || '#ffffff');
    var width = Math.max(needW || 0, opts.width || 0,
      Math.ceil(el.getBoundingClientRect().width) || 0, el.scrollWidth || 0, 1);
    var height = Math.max(opts.height || 0, el.scrollHeight || 0,
      Math.ceil(el.getBoundingClientRect().height) || 0, 1);
    // The clone keeps `width`; the bitmap gets EDGE_BLEED of slack so
    // fractional re-layout drift and box-shadows cannot shave the right edge.
    var bmpW = width + EDGE_BLEED;
    var scale = opts.scale || window.devicePixelRatio || 1;
    if (Math.max(bmpW, height) * scale > MAX_EDGE) {
      scale = MAX_EDGE / Math.max(bmpW, height);
    }
    return new Promise(function (resolve, reject) {
      var settle;
      try {
        settle = Promise.race([
          (document.fonts && document.fonts.ready) || Promise.resolve(),
          new Promise(function (r) { setTimeout(r, 1500); })
        ]);
      } catch (e) { settle = Promise.resolve(); }
      settle.then(function () {
        try {
          var clone = buildInlinedClone(el, view);
          // Lay the clone out at the full capture width; kill margins so it
          // fills the foreignObject from (0,0) like html2canvas's own crop.
          clone.style.width = width + 'px';
          clone.style.maxWidth = 'none';
          clone.style.margin = '0';
          clone.style.boxSizing = 'border-box';
          // Expand marked scroll containers (measure() ran before us).
          // Horizontal-only, like expandClones: widening via min-width is
          // what reveals the columns; touching the overflow shorthand would
          // also unlock overflow-y and reflow vertically-scrolled panels
          // past the bitmap's fixed height. querySelectorAll misses the
          // clone root, which measure() may have marked too.
          var list = Array.prototype.slice.call(clone.querySelectorAll('[' + ATTR + ']'));
          if (clone.getAttribute && clone.getAttribute(ATTR)) list.unshift(clone);
          for (var i = 0; i < list.length; i++) {
            var w = parseInt(list[i].getAttribute(ATTR), 10);
            list[i].style.overflowX = 'visible';
            list[i].style.maxWidth = 'none';
            if (w > 0) list[i].style.minWidth = w + 'px';
          }
          clone.setAttribute('xmlns', 'http://www.w3.org/1999/xhtml');
          var xml = new XMLSerializer().serializeToString(clone);
          var svg =
            '<svg xmlns="http://www.w3.org/2000/svg" width="' + bmpW +
            '" height="' + height + '"><foreignObject width="' + bmpW +
            '" height="' + height + '">' + xml + '</foreignObject></svg>';
          var img = new Image();
          img.onload = function () {
            try {
              var cv = document.createElement('canvas');
              cv.width = Math.max(1, Math.round(bmpW * scale));
              cv.height = Math.max(1, Math.round(height * scale));
              var cx = cv.getContext('2d');
              if (bg) {
                cx.fillStyle = bg;
                cx.fillRect(0, 0, cv.width, cv.height);
              }
              cx.drawImage(img, 0, 0, cv.width, cv.height);
              resolve(cv);
            } catch (e) { reject(e); }
          };
          img.onerror = function () {
            reject(new Error('export guard: SVG rasterization failed'));
          };
          img.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
        } catch (e) { reject(e); }
      });
    });
  }

  function wrap(real) {
    if (typeof real !== 'function' || real.__gsExportGuard) return real;
    var wrapped = function (target, opts) {
      var marked = [];
      var el = null;
      var need = 0;
      var widened = false;
      try {
        opts = opts || {};
        if (target && (target.nodeType === 1 || target.nodeType === 9)) {
          el = target.nodeType === 9 ? target.documentElement : target;
          var m = measure(el);
          marked = m.marked;
          need = m.need;
          var baseW = Math.max(
            opts.width || 0,
            Math.ceil(el.getBoundingClientRect().width) || 0,
            opts.width ? 0 : (el.scrollWidth || 0)
          );
          if (need > baseW) {
            opts.width = need;
            opts.windowWidth = Math.max(need, opts.windowWidth || 0);
            widened = true;
          }
          var scale = opts.scale || window.devicePixelRatio || 1;
          var w = opts.width || baseW || 0;
          var h = opts.height || el.scrollHeight || 0;
          var edge = Math.max(w, h);
          if (edge > 0 && edge * scale > MAX_EDGE) {
            opts.scale = Math.min(scale, MAX_EDGE / edge);
          }
          var userOnclone = opts.onclone;
          opts.onclone = function (clonedDoc, elArg) {
            if (marked.length) {
              try { expandClones(clonedDoc); } catch (e) {}
            }
            var pin = function () {
              try { pinLegacyColors(clonedDoc); } catch (e) {}
            };
            // Colors last: the app's own onclone may restyle or add nodes.
            var r = typeof userOnclone === 'function' ? userOnclone(clonedDoc, elArg) : undefined;
            if (r && typeof r.then === 'function') return r.then(function (v) { pin(); return v; });
            pin();
            return r;
          };
        }
      } catch (e) { /* never break the caller's capture */ }

      // Opaque origin → html2canvas cannot work at all; rasterize via
      // foreignObject instead and hand back a real canvas.
      if (el && isOpaqueOrigin()) {
        var fp = foRasterize(el, opts, need);
        var fdone = function () { cleanup(marked); };
        fp.then(fdone, fdone);
        return fp;
      }

      // Only the REAL html2canvas call takes its slack here; the FO path
      // above adds its own from the clean `need`, so applying it earlier
      // would double-count (wider clone AND a 24px strip).
      if (widened) {
        opts.width += EDGE_BLEED;
        opts.windowWidth = Math.max(opts.width, opts.windowWidth || 0);
      }
      var p;
      try {
        p = real(target, opts);
      } catch (e) {
        cleanup(marked);
        throw e;
      }
      if (p && typeof p.then === 'function') {
        var done = function () { cleanup(marked); };
        p.then(done, done);
      } else {
        cleanup(marked);
      }
      return p;
    };
    wrapped.__gsExportGuard = true;
    for (var k in real) {
      try { wrapped[k] = real[k]; } catch (e) {}
    }
    return wrapped;
  }

  // Exposed for tests.
  guard.legacyColorValue = legacyColorValue;

  // agentdb.print's in-app PDF fallback (app_print/print_bridge.js).
  guard.rasterize = function (el, opts) {
    var m = measure(el);
    var p = foRasterize(el, opts || {}, m.need);
    var done = function () { cleanup(m.marked); };
    p.then(done, done);
    return p;
  };

  // Wrap a copy that loaded before this script, then trap later assignments
  // (CDN <script> tags typically execute after this inline head script).
  var current = wrap(window.html2canvas);
  try {
    Object.defineProperty(window, 'html2canvas', {
      configurable: true,
      enumerable: true,
      get: function () { return current; },
      set: function (v) { current = wrap(v); }
    });
  } catch (e) {
    if (current) {
      try { window.html2canvas = current; } catch (e2) {}
    }
  }
})();
