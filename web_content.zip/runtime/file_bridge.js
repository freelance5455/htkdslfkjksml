/* agentdb.download / agentdb.confirm / alert / prompt, see backend/agentdb/app_print. ES5.
   Serve splices markup around it: no closing script tag, HTML comment or
   html / head tag in this file. */
(function () {
var w = window, d = document;
var api = w.agentdb || (w.agentdb = {});
if (typeof api.download === 'function') return;
// The app owner's gk_agentbase_app_files, filled at serve time.
var ENABLED = false === true;
var ACK_MS = 3000;
// Bytes, as in the parent.
var MAX_BYTES = 100 * 1024 * 1024;
// Only the AgentBase page, which serves the app from its own origin, may
// receive the file or the question.
var HOST = (function () { try { return new URL(w.location.href).origin; } catch (e) { return ''; } })();
// Refused here and in the parent: a file the page would hand over under its
// own name must not be a program. Windows picks how to open a file from its
// extension, so this follows the browsers' dangerous-download types, not the
// MIME type. Kept identical to useAppFileBridge.ts (a test checks).
var BLOCKED = /\.(exe|com|scr|pif|bat|cmd|msi|msp|msix|msixbundle|appx|appxbundle|appref-ms|application|gadget|ps1|psm1|psd1|vbs|vbe|js|jse|wsf|wsh|ws|hta|cpl|msc|lnk|url|scf|inf|ins|isp|reg|dll|sys|drv|ocx|xll|chm|cab|iso|img|vhd|vhdx|mht|mhtml|xbap|settingcontent-ms|library-ms|jar|app|dmg|pkg|mpkg|sh|command|apk)$/i;
var TEXT = {
  en: ['OK', 'Cancel', 'Could not download the file.', 'This file type cannot be downloaded.', 'The file is too large to download.'],
  zh: ['确定', '取消', '文件下载失败。', '不能下载这种类型的文件。', '文件太大,无法下载。'],
  ko: ['확인', '취소', '파일을 내려받지 못했습니다.', '이 형식의 파일은 내려받을 수 없습니다.', '파일이 너무 커서 내려받을 수 없습니다.'],
  ja: ['OK', 'キャンセル', 'ファイルをダウンロードできませんでした。', 'この種類のファイルはダウンロードできません。', 'ファイルが大きすぎてダウンロードできません。']
};
var MESSAGE = { DOWNLOAD_FAILED: 2, FILE_TYPE_BLOCKED: 3, TOO_LARGE: 4 };
var seq = 0, pending = {}, toastEl = null, toastTimer = 0;

function text(i) {
  var lang = String(d.documentElement.lang || navigator.language || '').slice(0, 2).toLowerCase();
  return (TEXT[lang] || TEXT.en)[i];
}

function fail(code, message) {
  var e = new Error(message || (code in MESSAGE ? text(MESSAGE[code]) : code));
  e.code = code;
  return e;
}

function remove(n) {
  if (n && n.parentNode) n.parentNode.removeChild(n);
}

function toast(message) {
  try {
    var t = toastEl;
    if (!t || !t.parentNode) {
      t = toastEl = d.createElement('div');
      t.className = 'gs-no-print';
      t.setAttribute('data-gs-print-toast', '');
      t.setAttribute('role', 'status');
      t.style.cssText = 'position:fixed;left:50%;bottom:24px;transform:translateX(-50%);z-index:2147483647;max-width:90vw;padding:10px 16px;border-radius:8px;background:#1f2937;color:#fff;font:14px sans-serif';
      (d.body || d.documentElement).appendChild(t);
    }
    t.textContent = message;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { remove(t); }, 6000);
  } catch (e) {}
}

// Keeps the extension, unlike the print bridge's PDF names.
function fileName(v) {
  var s = String(v == null ? '' : v)
    .replace(/[\u0000-\u001f\u007f-\u009f\u200b-\u200f\u202a-\u202e\u2066-\u2069\ufeff]/g, '')
    .replace(/[\\/:*?"<>|]+/g, '_')
    .replace(/\.{2,}/g, '.')
    .replace(/^[\s.]+|[\s.]+$/g, '');
  s = Array.from(s).slice(-120).join('');
  return s || 'download';
}

function fromDataUrl(s) {
  var m = /^data:([^,]*?)(;base64)?,([\s\S]*)$/i.exec(s), bin, bytes, i;
  if (!m) throw fail('DOWNLOAD_FAILED', 'not a data: URL');
  if (!m[2]) return new Blob([decodeURIComponent(m[3])], { type: m[1] });
  bin = atob(m[3].replace(/\s+/g, ''));
  bytes = new Uint8Array(bin.length);
  for (i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return new Blob([bytes], { type: m[1] });
}

// A Blob, an ArrayBuffer or typed array, a data: URL, or text.
function toBlob(data, name, o) {
  if (typeof Blob !== 'undefined' && data instanceof Blob) return data;
  if (data instanceof ArrayBuffer || ArrayBuffer.isView(data)) return new Blob([data], { type: o.type || 'application/octet-stream' });
  if (typeof data === 'string') {
    if (/^data:/i.test(data)) return fromDataUrl(data);
    // Excel reads a CSV without a BOM as the system code page, so Korean,
    // Japanese and Chinese text comes out garbled.
    var bom = o.bom === true || (o.bom !== false && /\.(csv|tsv)$/i.test(name));
    return new Blob([bom ? '\ufeff' + data : data], { type: o.type || 'text/plain;charset=utf-8' });
  }
  throw fail('DOWNLOAD_FAILED', 'agentdb.download takes a Blob, an ArrayBuffer, a data: URL or a string');
}

function saveHere(blob, name) {
  var url = URL.createObjectURL(blob), a = d.createElement('a');
  a.href = url;
  a.download = name;
  a.style.display = 'none';
  (d.body || d.documentElement).appendChild(a);
  a.click();
  remove(a);
  setTimeout(function () { URL.revokeObjectURL(url); }, 10000);
}

function canAsk() {
  return ENABLED && w.parent !== w && /^https?:/.test(HOST);
}

function ours(id) {
  return typeof id === 'string' && id.indexOf('gsfile:') === 0 && pending.hasOwnProperty(id);
}

// Resolves with the parent's result, or rejects with {code}; a parent that
// does not know the method or never answers rejects with code FALLBACK.
function ask(method, params) {
  return new Promise(function (resolve, reject) {
    var id = 'gsfile:' + (++seq), entry = { acked: false };
    entry.settle = function (result, error) {
      clearTimeout(entry.timer);
      delete pending[id];
      if (error == null) return resolve(result || {});
      if (typeof error === 'string' && /unknown method/i.test(error)) return reject(fail('FALLBACK'));
      reject(fail(error.code || 'DOWNLOAD_FAILED', error.message || String(error)));
    };
    entry.timer = setTimeout(function () {
      if (ours(id) && !entry.acked) {
        delete pending[id];
        reject(fail('FALLBACK'));
      }
    }, ACK_MS);
    pending[id] = entry;
    w.parent.postMessage({ type: 'agentdb:request', id: id, method: method, params: params }, HOST);
  });
}

function download(data, filename, options) {
  var o = opts(options);
  var name = fileName(filename), blob;
  return new Promise(function (resolve) {
    if (BLOCKED.test(name)) throw fail('FILE_TYPE_BLOCKED');
    blob = toBlob(data, name, o);
    if (blob.size > MAX_BYTES) throw fail('TOO_LARGE');
    resolve();
  }).then(function () {
    if (!canAsk()) return Promise.reject(fail('FALLBACK'));
    return ask('download', { blob: blob, filename: name }).then(function () {
      return { ok: true, bytes: blob.size, filename: name };
    });
  }).then(null, function (e) {
    // The parent refused on purpose (wrong type, too large, too many):
    // saving it here instead would undo the refusal.
    if (e && e.code !== 'FALLBACK') throw e;
    saveHere(blob, name);
    return { ok: true, bytes: blob.size, filename: name, fallback: true };
  }).then(null, function (e) {
    if (!e || !e.code) e = fail('DOWNLOAD_FAILED', e && e.message);
    if (o.quiet !== true) toast(e.message);
    throw e;
  });
}

// The sandbox has no allow-modals, so window.confirm(), alert() and prompt()
// do nothing; this dialog stands in where the AgentBase page cannot ask.
// kind: 'confirm' resolves true / false, 'alert' resolves undefined, 'prompt'
// resolves the typed text or null.
function dialogHere(kind, message, o) {
  return new Promise(function (resolve) {
    var prev = d.activeElement, root = d.createElement('div'), box = d.createElement('div');
    var p = d.createElement('p'), row = d.createElement('div'), no = d.createElement('button'), yes = d.createElement('button');
    var input = null;
    function done(ok) {
      d.removeEventListener('keydown', key, true);
      remove(root);
      try { if (prev && prev.focus) prev.focus(); } catch (e) {}
      resolve(kind === 'alert' ? undefined : kind === 'prompt' ? (ok ? input.value : null) : ok);
    }
    function key(e) {
      // Enter that ends an IME composition commits the text, not the dialog.
      if (e.isComposing || e.keyCode === 229) return;
      if (e.key === 'Escape') { e.preventDefault(); done(false); }
      else if (e.key === 'Enter' && input && e.target === input) { e.preventDefault(); done(true); }
    }
    root.className = 'gs-no-print';
    root.setAttribute('data-gs-confirm', '');
    root.style.cssText = 'position:fixed;inset:0;z-index:2147483647;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,.4)';
    box.setAttribute('role', kind === 'prompt' ? 'dialog' : 'alertdialog');
    box.setAttribute('aria-modal', 'true');
    box.style.cssText = 'max-width:min(420px,90vw);min-width:min(320px,90vw);padding:20px;border-radius:12px;background:#fff;color:#111;font:14px/1.5 sans-serif;box-shadow:0 10px 30px rgba(0,0,0,.25)';
    if (o.title) {
      var h = d.createElement('div');
      h.style.cssText = 'font-weight:600;font-size:16px;margin-bottom:8px';
      h.textContent = String(o.title);
      box.appendChild(h);
    }
    p.style.cssText = 'margin:0 0 16px;white-space:pre-wrap;word-break:break-word';
    p.textContent = message;
    box.appendChild(p);
    if (kind === 'prompt') {
      input = d.createElement('input');
      input.type = 'text';
      input.value = o.defaultValue == null ? '' : String(o.defaultValue);
      if (o.placeholder) input.placeholder = String(o.placeholder);
      input.style.cssText = 'box-sizing:border-box;width:100%;margin:0 0 16px;padding:8px 10px;border:1px solid #d1d5db;border-radius:8px;font:inherit;color:#111;background:#fff';
      box.appendChild(input);
    }
    row.style.cssText = 'display:flex;justify-content:flex-end;gap:8px';
    no.type = yes.type = 'button';
    no.textContent = o.cancelLabel ? String(o.cancelLabel) : text(1);
    yes.textContent = o.confirmLabel ? String(o.confirmLabel) : text(0);
    no.style.cssText = 'padding:6px 14px;border:1px solid #d1d5db;border-radius:8px;background:#fff;color:#111;cursor:pointer';
    yes.style.cssText = 'padding:6px 14px;border:0;border-radius:8px;color:#fff;cursor:pointer;background:' + (o.danger === true ? '#dc2626' : '#111');
    no.addEventListener('click', function () { done(false); });
    yes.addEventListener('click', function () { done(true); });
    root.addEventListener('click', function (e) { if (e.target === root) done(false); });
    // An alert has one answer, so one button.
    if (kind !== 'alert') row.appendChild(no);
    row.appendChild(yes);
    box.appendChild(row);
    root.appendChild(box);
    (d.body || d.documentElement).appendChild(root);
    d.addEventListener('keydown', key, true);
    if (input) { input.focus(); input.select(); }
    // A destructive question starts on Cancel, so Enter never deletes.
    else (o.danger === true ? no : yes).focus();
  });
}

function short(v, n) {
  return v == null ? '' : Array.from(String(v)).slice(0, n).join('');
}

function opts(options) {
  return options && typeof options === 'object' ? options : {};
}

// confirm and alert ask the AgentBase page, whose dialog sits above the whole
// page; any refusal (no click just before, a hidden viewer, an older page)
// still gets an answer from the user, here.
function askUser(kind, message, o) {
  var msg = short(message, 2000);
  if (!canAsk()) return dialogHere(kind, msg, o);
  return ask(kind, {
    message: msg,
    title: short(o.title, 120),
    confirmLabel: short(o.confirmLabel, 40),
    cancelLabel: short(o.cancelLabel, 40),
    danger: o.danger === true
  }).then(function (r) {
    return kind === 'alert' ? undefined : r.confirmed === true;
  }, function () {
    return dialogHere(kind, msg, o);
  });
}

function confirm(message, options) {
  return askUser('confirm', message, opts(options));
}

function alert(message, options) {
  return askUser('alert', message, opts(options));
}

// The AgentBase page's dialog has no text field, so prompt always asks here.
function prompt(message, options) {
  var o = opts(options);
  if (typeof options === 'string') o = { defaultValue: options };
  return dialogHere('prompt', short(message, 2000), o);
}

w.addEventListener('message', function (e) {
  var m = e.data, i;
  if (!m || w.parent === w || e.source !== w.parent) return;
  if (m.type === 'agentdb:progress' && m.ids && m.ids.length) {
    for (i = 0; i < m.ids.length; i++) {
      if (ours(m.ids[i]) && !pending[m.ids[i]].acked) {
        pending[m.ids[i]].acked = true;
        clearTimeout(pending[m.ids[i]].timer);
      }
    }
  } else if (m.type === 'agentdb:response' && ours(m.id)) {
    pending[m.id].settle(m.result, m.error);
  }
});

api.download = download;
api.confirm = confirm;
api.alert = alert;
api.prompt = prompt;
// Read by the print bridge (downloadPdf split) and the kit's exportBar: both
// stay off until the owner has gk_agentbase_app_files.
Object.defineProperty(api, '_filesEnabled', { value: ENABLED });
})();
