/* ============================================================
   B-Suite dashboard kit — JS runtime (window.gsDash).
   Injected at serve time. Provides format helpers, pure-SVG chart
   builders, and HTML component builders so dashboards can be written
   as lean markup without inlining the design system. ES5-compatible.
   Also sets <html data-theme> from the OS color-scheme preference.
   ============================================================ */
(function () {
  // .chart, not gsDash itself: export.js may have created gsDash first.
  if (window.gsDash && window.gsDash.chart) return;

  // Every live gsDash.chart handle. A canvas bakes its colours in at draw
  // time, so the ONE matchMedia listener below has to rebuild them; declared
  // up here because applyTheme() runs before the chart section is reached.
  var _liveCharts = [];
  function rethemeAll() {
    // Backwards: dropping a dead handle splices the array under us.
    for (var i = _liveCharts.length - 1; i >= 0; i--) {
      var h = _liveCharts[i];
      try {
        // A section that re-rendered (loadSections replaces el.innerHTML, and
        // so does any hand-written refresh) leaves its canvas detached.
        // Redrawing one nobody can see keeps it — and its whole dataset —
        // alive for the life of the page, and the leak grows once per refresh.
        if (h.isDetached()) { h.destroy(); continue; }
        h.retheme();
      } catch (e) {}
    }
  }

  // Follow OS light/dark (palettes key on [data-theme]); data-palette is set
  // separately (baked default / per-workspace serve-time injection).
  function applyTheme() {
    try {
      var next = window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
      var changed = document.documentElement.dataset.theme !== next;
      document.documentElement.dataset.theme = next;
      // Only on a real flip: retheme() destroys and rebuilds every canvas, and
      // doing that on a no-op call would drop hover/animation state for free.
      if (changed) rethemeAll();
    } catch (e) {}
  }
  applyTheme();
  try { window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', applyTheme); } catch (e) {}

  var VIZ_FALLBACK = ['#3B5BDB', '#C2410C', '#1EA381', '#A44393', '#B79332', '#444B58'];
  var AV = ['#3B5BDB', '#7DA3C7', '#B5A98A', '#C2410C', '#0F8A5E', '#78716C'];

  function cvar(n) { return getComputedStyle(document.documentElement).getPropertyValue(n).trim(); }
  function vizColor(i) { return cvar('--viz-' + ((i % 6) + 1)) || VIZ_FALLBACK[i % 6]; }
  // Paint reference for SVG attributes. vizColor() resolves the var to a hex
  // at build time, which freezes the series colour into the markup: an OS
  // light/dark flip then re-themes the CSS around a chart whose own strokes
  // still carry the previous theme's palette. Emitting the var keeps the
  // paint live, so a chart re-themes with the page instead of going stale.
  function vizRef(i) { return 'var(--viz-' + ((i % 6) + 1) + ', ' + VIZ_FALLBACK[i % 6] + ')'; }
  // Text AND attribute safe: the kit puts esc() output inside "..." attributes
  // (title, data-*), and innerHTML serialisation leaves quotes unescaped.
  // Pro Edit (editor preview only): where the text of this field was written
  // in the page's source, for the element we are about to draw. Empty for
  // everyone else, so published pages are byte-identical.
  function lit(o, k) { return typeof __abL === 'function' ? __abL(o, k) : ''; }
  // A spec the kit copies keeps its source (select_in_place/provenance.py).
  function keep(from, to) { return typeof __abC === 'function' ? __abC(from, to) : to; }
  function esc(s) { var d = document.createElement('div'); d.textContent = (s == null ? '' : String(s)); return d.innerHTML.replace(/"/g, '&quot;').replace(/'/g, '&#39;'); }
  // Kept for the call sites that name it; esc() is already attribute-safe.
  function escAttr(s) { return esc(s); }
  function fmtInt(n) { return Number(n || 0).toLocaleString('en-US'); }
  function money(n) { return Number(n || 0).toLocaleString('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }); }
  function humanize(s) { return String(s == null ? '' : s).replace(/_/g, ' '); }
  function dateMD(s) { var d = new Date(s); if (isNaN(d.getTime())) return String(s || ''); return (d.getMonth() + 1) + '/' + d.getDate(); }
  function relTime(s) {
    if (!s) return ''; var d = new Date(s); if (isNaN(d.getTime())) return String(s);
    var f = (Date.now() - d.getTime()) / 1000;
    if (f < 60) return 'just now'; if (f < 3600) return Math.floor(f / 60) + 'm ago';
    if (f < 86400) return Math.floor(f / 3600) + 'h ago'; if (f < 86400 * 7) return Math.floor(f / 86400) + 'd ago';
    return (d.getMonth() + 1) + '/' + d.getDate();
  }
  var TONE = { active: 'success', open: 'success', completed: 'success', done: 'success', shipped: 'success', delivered: 'success', confirmed: 'success', won: 'success', hired: 'success', paid: 'success', resolved: 'success', published: 'success', approved: 'success', accepted: 'success',
    draft: 'warn', pending: 'warn', processing: 'warn', scheduled: 'warn', in_progress: 'warn', in_review: 'warn', upcoming: 'warn', review: 'warn', screening: 'warn', doing: 'warn', submitted: 'warn',
    expired: 'danger', cancelled: 'danger', canceled: 'danger', returned: 'danger', missed: 'danger', overdue: 'danger', rejected: 'danger', failed: 'danger', lost: 'danger', blocked: 'danger', declined: 'danger' };
  function statusTone(s) { return TONE[String(s == null ? '' : s).toLowerCase().replace(/[\s-]+/g, '_')] || 'neutral'; }
  function tag(text, tone) { return '<span class="gs-badge gs-b-' + (tone || 'neutral') + '"><span class="bd"></span>' + esc(text) + '</span>'; }

  function scale(min, max, oMin, oMax) { var d = (max - min) || 1; return function (v) { return oMin + ((v - min) / d) * (oMax - oMin); }; }
  function niceScale(min, max, c) {
    c = c || 4; var rs = (max - min) / c || 1; var mag = Math.pow(10, Math.floor(Math.log10(Math.abs(rs)))); var nm = rs / mag, st;
    if (nm < 1.5) st = 1 * mag; else if (nm < 3) st = 2 * mag; else if (nm < 7) st = 5 * mag; else st = 10 * mag;
    var a = Math.floor(min / st) * st, b = Math.ceil(max / st) * st, t = [];
    for (var i = 0; i <= Math.round((b - a) / st); i++) t.push(Math.round((a + i * st) / st) * st);
    return { ticks: t, nMin: a, nMax: b };
  }

  function sparkline(data, color, w, h) {
    w = w || 84; h = h || 26; var mn = Math.min.apply(null, data), mx = Math.max.apply(null, data);
    var x = scale(0, data.length - 1, 1, w - 1), y = scale(mn, mx, h - 2, 2);
    var p = data.map(function (v, i) { return (i ? 'L' : 'M') + x(i).toFixed(1) + ',' + y(v).toFixed(1); }).join(' ');
    return '<svg width="' + w + '" height="' + h + '" style="display:block"><path d="' + p + '" stroke="' + (color || vizRef(0)) + '" stroke-width="1.25" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  }
  function lineChart(o) {
    var ys = o.data || [], w = o.w || 460, h = o.h || 220, pad = { t: 16, r: 16, b: 28, l: 36 };
    var mx = Math.max.apply(null, ys.concat([1])) * 1.1, ns = niceScale(0, mx, 4);
    var x = scale(0, Math.max(ys.length - 1, 1), pad.l, w - pad.r), y = scale(ns.nMin, ns.nMax, h - pad.b, pad.t), color = o.color || vizRef(0), s = '';
    ns.ticks.forEach(function (t) {
      s += '<line x1="' + pad.l + '" x2="' + (w - pad.r) + '" y1="' + y(t).toFixed(1) + '" y2="' + y(t).toFixed(1) + '" stroke="var(--grid-line)" stroke-width="1"/>';
      s += '<text x="' + (pad.l - 8) + '" y="' + y(t).toFixed(1) + '" fill="var(--ink-400)" font-size="10.5" text-anchor="end" dominant-baseline="middle" style="font-variant-numeric:tabular-nums">' + esc(t) + '</text>';
    });
    var pts = ys.map(function (v, i) { return [x(i), y(v)]; });
    var path = pts.map(function (q, i) { return (i ? 'L' : 'M') + q[0].toFixed(1) + ',' + q[1].toFixed(1); }).join(' ');
    var gid = 'g' + Math.random().toString(36).slice(2, 7);
    if (pts.length) {
      var area = path + ' L' + pts[pts.length - 1][0].toFixed(1) + ',' + y(ns.nMin).toFixed(1) + ' L' + pts[0][0].toFixed(1) + ',' + y(ns.nMin).toFixed(1) + ' Z';
      s += '<defs><linearGradient id="' + gid + '" x1="0" x2="0" y1="0" y2="1"><stop offset="0%" stop-color="' + color + '" stop-opacity="0.14"/><stop offset="100%" stop-color="' + color + '" stop-opacity="0"/></linearGradient></defs>';
      s += '<path d="' + area + '" fill="url(#' + gid + ')"/><path d="' + path + '" stroke="' + color + '" stroke-width="1.5" fill="none" stroke-linecap="round" stroke-linejoin="round"/>';
      // Same rule as gsDash.chart (whenSparse): white-filled markers on a dense
      // series bead the line, so they are drawn only where they can be read.
      if (pts.length < 2 || (w - pad.l - pad.r) / (pts.length - 1) >= MARKER_MIN_GAP) {
        pts.forEach(function (q) { s += '<circle cx="' + q[0].toFixed(1) + '" cy="' + q[1].toFixed(1) + '" r="2.5" fill="var(--ink-0)" stroke="' + color + '" stroke-width="1.5"/>'; });
      }
    }
    (o.xl || []).forEach(function (l, i) { if (i % Math.ceil((ys.length || 1) / 8) === 0) s += '<text x="' + x(i).toFixed(1) + '" y="' + (h - pad.b + 16) + '" fill="var(--ink-400)" font-size="10.5" text-anchor="middle">' + esc(l) + '</text>'; });
    return '<svg class="gs-chart" width="' + w + '" height="' + h + '" viewBox="0 0 ' + w + ' ' + h + '" preserveAspectRatio="xMidYMid meet">' + s + '</svg>';
  }
  function barH(o) {
    var rows = o.rows || [], w = o.w || 460, h = o.h || (40 + rows.length * 34), pad = { t: 8, r: 16, b: 24, l: o.l || 110 };
    var mx = Math.max.apply(null, rows.map(function (r) { return Number(r.value); }).concat([1])) * 1.1, ns = niceScale(0, mx, 4);
    var x = scale(ns.nMin, ns.nMax, pad.l, w - pad.r), rowH = (h - pad.t - pad.b) / (rows.length || 1), bh = Math.min(16, rowH * 0.5), s = '', fmt = o.xFmt || fmtInt;
    ns.ticks.forEach(function (t) {
      s += '<line x1="' + x(t).toFixed(1) + '" x2="' + x(t).toFixed(1) + '" y1="' + pad.t + '" y2="' + (h - pad.b) + '" stroke="var(--grid-line)" stroke-width="1"/>';
      s += '<text x="' + x(t).toFixed(1) + '" y="' + (h - pad.b + 14) + '" fill="var(--ink-400)" font-size="10.5" text-anchor="middle" style="font-variant-numeric:tabular-nums">' + esc(fmt(t)) + '</text>';
    });
    rows.forEach(function (r, i) {
      var cy = pad.t + rowH * i + rowH / 2;
      s += '<text x="' + (pad.l - 8) + '" y="' + cy.toFixed(1) + '" fill="var(--ink-600)" font-size="11.5" text-anchor="end" dominant-baseline="middle">' + esc(humanize(r.label)) + '</text>';
      s += '<rect x="' + pad.l + '" y="' + (cy - bh / 2).toFixed(1) + '" width="' + Math.max(0, x(Number(r.value)) - pad.l).toFixed(1) + '" height="' + bh + '" fill="' + vizRef(0) + '" rx="2"/>';
    });
    return '<svg class="gs-chart" width="' + w + '" height="' + h + '" viewBox="0 0 ' + w + ' ' + h + '" preserveAspectRatio="xMidYMid meet">' + s + '</svg>';
  }
  function donut(o) {
    var rows = o.rows || [], size = 180, th = 22, total = rows.reduce(function (a, r) { return a + Number(r.value); }, 0) || 1, r = size / 2 - th / 2, cx = 90, cy = 90, acc = -Math.PI / 2, s = '';
    s += '<circle cx="90" cy="90" r="' + r + '" fill="none" stroke="var(--ink-100)" stroke-width="' + th + '"/>';
    rows.forEach(function (d, i) {
      var fr = Number(d.value) / total, st = acc, en = acc + fr * Math.PI * 2; acc = en; var e = en - 0.012;
      var x1 = cx + r * Math.cos(st), y1 = cy + r * Math.sin(st), x2 = cx + r * Math.cos(e), y2 = cy + r * Math.sin(e), lg = (e - st) > Math.PI ? 1 : 0;
      s += '<path d="M' + x1.toFixed(2) + ',' + y1.toFixed(2) + ' A' + r + ',' + r + ' 0 ' + lg + ' 1 ' + x2.toFixed(2) + ',' + y2.toFixed(2) + '" stroke="' + vizRef(i) + '" stroke-width="' + th + '" fill="none"/>';
    });
    s += '<text x="90" y="86" text-anchor="middle" fill="var(--ink-900)" font-size="20" font-weight="500" style="font-variant-numeric:tabular-nums;letter-spacing:-0.02em">' + esc(o.centerVal) + '</text>';
    s += '<text x="90" y="104" text-anchor="middle" fill="var(--ink-400)" font-size="10" style="letter-spacing:0.04em;text-transform:uppercase"' + lit(o, 'center') + '>' + esc(o.center || 'Total') + '</text>';
    return '<svg width="180" height="180">' + s + '</svg>';
  }

  // Canvas libraries (Chart.js, ECharts) cannot consume a CSS var — they need
  // resolved colours at draw time. Without a bridge, every generated app
  // hardcodes its own hexes and drifts from the design system, which is how
  // one dashboard ends up with three different greys for the same gridline.
  // This is the one place a canvas chart should get its palette. Snapshot
  // semantics: re-call it (and rebuild the chart) on a theme flip.
  // getPropertyValue hands back the SPECIFIED value, so a token defined as
  // color-mix(...) arrives as that literal string — which a canvas cannot
  // parse, and 2D context silently ignores an unparseable strokeStyle rather
  // than throwing. Round-trip through a computed `color` to get real rgb().
  var _swatch = null;
  function resolveColor(value, fallback) {
    if (!value) return fallback;
    if (/^(#|rgb|hsl)/i.test(value)) return value;
    try {
      if (!_swatch) {
        _swatch = document.createElement('span');
        _swatch.style.cssText = 'position:absolute;width:0;height:0;visibility:hidden';
        document.documentElement.appendChild(_swatch);
      }
      _swatch.style.color = '';
      _swatch.style.color = value;
      var out = getComputedStyle(_swatch).color;
      if (!out) return fallback;
      // A color-mix() of two hexes computes to CSS Color 4 `color(srgb r g b)`
      // in current engines. Chrome's canvas happens to accept that, but older
      // engines and some chart libraries do not — normalise to legacy rgb()
      // rather than depend on it.
      var m = out.match(/^color\(srgb\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)(?:\s*\/\s*([\d.]+))?\s*\)$/i);
      if (m) {
        var ch = [1, 2, 3].map(function (i) {
          return Math.max(0, Math.min(255, Math.round(parseFloat(m[i]) * 255)));
        });
        var a = m[4] === undefined ? 1 : parseFloat(m[4]);
        return a >= 1 ? 'rgb(' + ch.join(', ') + ')' : 'rgba(' + ch.join(', ') + ', ' + a + ')';
      }
      return out;
    } catch (e) { return fallback; }
  }

  function chartTheme() {
    var series = [];
    for (var i = 0; i < 6; i++) series.push(resolveColor(vizColor(i), VIZ_FALLBACK[i % 6]));
    return {
      grid: resolveColor(cvar('--grid-line'), 'rgba(120,113,108,0.35)'),
      text: resolveColor(cvar('--ink-800'), '#292724'),
      textMuted: resolveColor(cvar('--ink-400'), '#A8A29E'),
      surface: resolveColor(cvar('--ink-0'), '#FFFFFF'),
      accent: resolveColor(cvar('--brand-500'), '#3B5BDB'),
      series: series,
      isDark: document.documentElement.dataset.theme === 'dark',
    };
  }

  // ── gsDash.chart(el, config): themed Chart.js ───────────────────────────
  // The SVG builders above are single-series static markup: no second series,
  // no hover, no click. Real dashboards need all three, so an app that hits
  // that wall on its first chart hand-writes `new Chart(...)` — and then drops
  // the design system for the whole page. (Measured 2026-09-17 over 600 apps:
  // of the 51 that had the kit AND drew a chart, 2 called gsDash at all; 14
  // hardcoded hex series colours and exactly 1 redrew on a theme flip.)
  //
  // So this is deliberately NOT another builder. It is a merge: the app writes
  // whatever Chart.js config it wants — multi-series, stacked, dual-axis,
  // onClick drilldown — and the theme is merged UNDERNEATH it. Every key the
  // app sets wins. What the app leaves out (palette, grid, ticks, tooltip,
  // responsive) arrives from the design tokens by default, instead of
  // depending on the author remembering to call chartTheme().
  //
  //   gsDash.chart(elOrSelector, chartJsConfig)
  //     -> { instance, update(config?), retheme(), destroy() }
  //
  // Extras the wrapper understands, on top of plain Chart.js:
  //   dataset.gsTotal: true   — this series is a STATED TOTAL, not a part. It
  //                             is excluded from the stack sum and checked
  //                             against it (console.warn names the x values
  //                             that disagree).
  //   data.totals: number[]   — same check without a drawn series.
  //
  // Lifecycle: `instance` is the live Chart.js object and is REPLACED on a
  // theme flip (a canvas bakes its colours in, so a re-theme is a rebuild).
  // Mutate `h.instance.data` in place and call `h.instance.update()` as you
  // would with plain Chart.js; the rebuild reads the live data, not the
  // config you first passed. `h.update()` with no argument re-derives the
  // signed-axis bounds after such a change; `h.update(cfg)` swaps the config.
  //
  // First paint: the chart is drawn SYNCHRONOUSLY, with no intro animation,
  // unless the app sets `options.animation` itself. Chart.js defers an
  // animated draw to requestAnimationFrame, and a frame the browser is not
  // rendering never gets one: the agent's preview and the thumbnail capture
  // are off-screen cross-origin iframes, and a background tab is the same.
  // There the canvas stayed correctly sized and completely empty, and no
  // update()/render() could paint it, because every redraw queues behind the
  // animation that never starts (2026-10-01: ~100 agent turns on one
  // dashboard). Later updates animate as usual once a frame has run.

  var NO_CARTESIAN = { pie: 1, doughnut: 1, polarArea: 1, radar: 1 };
  var SLICE_COLOURED = { pie: 1, doughnut: 1, polarArea: 1 };

  function hasOwn(o, k) { return Object.prototype.hasOwnProperty.call(o, k); }
  function isPlain(v) {
    if (v == null || typeof v !== 'object') return false;
    if (Object.prototype.toString.call(v) === '[object Array]') return false;
    if (typeof Node !== 'undefined' && v instanceof Node) return false;
    return true;
  }
  // Theme defaults go in `base`, the app's config in `over`, and `over` wins on
  // every key it sets. Arrays, functions and class instances are taken whole
  // from `over` — merging an app's `data: [1,2,3]` element-wise with anything
  // would corrupt it, and half-merging an onClick is meaningless.
  function deepMerge(base, over) {
    if (over === undefined) return base;
    if (!isPlain(base) || !isPlain(over)) return over;
    var out = {}, k;
    for (k in base) if (hasOwn(base, k)) out[k] = base[k];
    for (k in over) if (hasOwn(over, k)) out[k] = hasOwn(base, k) ? deepMerge(base[k], over[k]) : over[k];
    return out;
  }

  // A token resolves to either a hex or an rgb() (see resolveColor), so a fill
  // cannot be built by concatenating '80' onto it.
  function withAlpha(color, a) {
    if (!color) return color;
    var s = String(color).trim(), m;
    if ((m = s.match(/^#([0-9a-f]{3})$/i))) {
      s = '#' + m[1].charAt(0) + m[1].charAt(0) + m[1].charAt(1) + m[1].charAt(1) + m[1].charAt(2) + m[1].charAt(2);
    }
    if ((m = s.match(/^#([0-9a-f]{6})$/i))) {
      var n = parseInt(m[1], 16);
      return 'rgba(' + ((n >> 16) & 255) + ', ' + ((n >> 8) & 255) + ', ' + (n & 255) + ', ' + a + ')';
    }
    if ((m = s.match(/^rgba?\(([^)]+)\)$/i))) {
      var p = m[1].split(/[\s,\/]+/).filter(function (x) { return x !== ''; });
      if (p.length >= 3) return 'rgba(' + p[0] + ', ' + p[1] + ', ' + p[2] + ', ' + a + ')';
    }
    return s; // unparseable — hand it back untouched rather than emit garbage
  }

  function isTotalSet(ds) { return !!(ds && (ds.gsTotal === true || ds.gsRole === 'total')); }
  // Chart.js accepts number[], {x,y}[] and {v}[]. `va` is the VALUE axis, so an
  // indexAxis:'y' chart reads x from an object point, not y.
  function numAt(ds, i, va) {
    var d = ds && ds.data;
    if (!d || i >= d.length) return null;
    var v = d[i];
    if (v == null) return null;
    if (typeof v === 'object') {
      v = v[va] != null ? v[va] : (v.y != null ? v.y : (v.x != null ? v.x : v.v));
      if (v == null) return null;
    }
    v = Number(v);
    return isNaN(v) ? null : v;
  }

  // Bounds for a value axis that carries negatives. The failure this exists to
  // stop (2026-09-16): an app forced every expense category negative so the
  // axis would look right, which silently flipped the sign of the three
  // categories that were genuinely positive in some months. The data is never
  // touched here — the BOUNDS are derived from the real signed totals instead.
  // Positives and negatives accumulate into separate running totals per x (per
  // Chart.js stack group), exactly as the renderer stacks them.
  function signedExtent(sets, cfgType, stacked, va) {
    var i, j, k, n = 0, any = false, hasNeg = false, lo = 0, hi = 0;
    for (i = 0; i < sets.length; i++) if (sets[i] && sets[i].data && sets[i].data.length > n) n = sets[i].data.length;
    for (j = 0; j < n; j++) {
      var stacks = {};
      for (i = 0; i < sets.length; i++) {
        var v = numAt(sets[i], j, va);
        if (v == null) continue;
        any = true;
        if (v < 0) hasNeg = true;
        // A stated total is drawn (so it must fit inside the bounds) but is not
        // a part, so it never joins a stack sum.
        if (!stacked || isTotalSet(sets[i])) {
          if (v > hi) hi = v;
          if (v < lo) lo = v;
          continue;
        }
        var key = sets[i].stack != null ? String(sets[i].stack) : String(sets[i].type || cfgType);
        var s = stacks[key] || (stacks[key] = { pos: 0, neg: 0 });
        if (v >= 0) s.pos += v; else s.neg += v;
      }
      for (k in stacks) if (hasOwn(stacks, k)) {
        if (stacks[k].pos > hi) hi = stacks[k].pos;
        if (stacks[k].neg < lo) lo = stacks[k].neg;
      }
    }
    // lo/hi start at 0, so zero is always inside the range and the baseline
    // below has somewhere to draw.
    return any ? { hasNegative: hasNeg, dataMin: lo, dataMax: hi } : null;
  }

  // "Net" / "Total" labels that disagree with the bars under them survived
  // weeks unnoticed on a real dashboard. Cheap to check, so check it.
  function warnTotals(data, cfgType, va) {
    var sets = (data && data.datasets) || [], labels = (data && data.labels) || [];
    var totals = null, totalIdx = -1, i, j;
    for (i = 0; i < sets.length; i++) if (isTotalSet(sets[i])) { totalIdx = i; break; }
    if (totalIdx >= 0) totals = sets[totalIdx].data || [];
    else if (data && Object.prototype.toString.call(data.totals) === '[object Array]') totals = data.totals;
    if (!totals || !totals.length) return;

    var bad = [];
    for (j = 0; j < totals.length; j++) {
      var t = totals[j];
      if (t != null && typeof t === 'object') t = t[va] != null ? t[va] : (t.y != null ? t.y : t.x);
      // Before coercion: Number(null) is 0, and a SQL NULL in a totals column
      // must read as "no stated total here", not "stated total of zero".
      if (t == null || t === '') continue;
      t = Number(t);
      if (isNaN(t)) continue;
      var sum = 0, seen = false;
      for (i = 0; i < sets.length; i++) {
        if (i === totalIdx) continue;
        var v = numAt(sets[i], j, va);
        if (v == null) continue;
        sum += v; seen = true;
      }
      if (!seen) continue;
      // Relative tolerance: float addition of a dozen currency values does not
      // land on the stated total to the bit.
      if (Math.abs(sum - t) > Math.max(1e-9, Math.abs(t) * 1e-6)) {
        bad.push((labels[j] != null ? labels[j] : j) + ' (parts ' + sum + ' vs stated ' + t + ')');
      }
    }
    if (bad.length) {
      try {
        console.warn('[gsDash.chart] stated total does not match the sum of its parts at '
          + bad.length + ' x value(s): ' + bad.join('; '));
      } catch (e) {}
    }
  }

  function sliceColours(ds, theme) {
    var out = [], n = (ds && ds.data && ds.data.length) || 0;
    for (var i = 0; i < n; i++) out.push(theme.series[i % theme.series.length]);
    return out;
  }
  // A line marker's halo (pointBorderColor: surface) overlaps its neighbours'
  // on a dense series and cuts the line into beads — a 30-day KPI trend read
  // as dashed (2026-10-07). So markers draw only while points sit
  // MARKER_MIN_GAP px apart (hover still shows them), re-decided per resize.
  // An isolated point keeps its marker: no line passes through it.
  var MARKER_MIN_GAP = 16;
  function whenSparse(value) {
    return function (ctx) {
      var ch = ctx && ctx.chart, a = ch && ch.chartArea, ds = ctx && ctx.dataset;
      if (!a || !ds) return value;
      var va = ch.options && ch.options.indexAxis === 'y' ? 'x' : 'y';
      var i = ctx.dataIndex;
      if (i != null && numAt(ds, i - 1, va) == null && numAt(ds, i + 1, va) == null) return value;
      var labels = (ch.data && ch.data.labels) || [];
      var n = Math.max(labels.length, (ds.data && ds.data.length) || 0);
      var span = va === 'x' ? a.bottom - a.top : a.right - a.left;
      return n < 2 || span / (n - 1) >= MARKER_MIN_GAP ? value : 0;
    };
  }
  function datasetDefaults(i, ds, cfgType, theme, stacked, indexAxis) {
    var t = (ds && ds.type) || cfgType;
    var c = theme.series[i % theme.series.length];
    if (SLICE_COLOURED[t]) {
      // One colour per SLICE, not per dataset — a pie has one dataset.
      return { backgroundColor: sliceColours(ds, theme), borderColor: theme.surface, borderWidth: 2 };
    }
    if (t === 'line') {
      return {
        borderColor: c, backgroundColor: withAlpha(c, 0.14), borderWidth: 2,
        pointBackgroundColor: c, pointBorderColor: theme.surface,
        pointRadius: whenSparse(2.5), pointBorderWidth: whenSparse(2), pointHoverRadius: 4,
      };
    }
    if (t === 'radar') {
      return {
        borderColor: c, backgroundColor: withAlpha(c, 0.14), borderWidth: 2,
        pointBackgroundColor: c, pointBorderColor: theme.surface,
        pointRadius: 2.5, pointHoverRadius: 4,
      };
    }
    // Stacked segments touch, so two neighbours of similar lightness read as
    // one block. A surface-coloured hairline between them (the donut does the
    // same with its slice gap) keeps each segment's edge visible. Only the
    // edges along the value axis: Chart.js draws a border inside the bar, and
    // side edges would shave 2px of colour off every bar of a dense series.
    // borderSkipped 'start' then drops the base edge, leaving the one away
    // from zero — for negative segments too.
    if (stacked && t === 'bar') {
      return {
        backgroundColor: c, borderColor: theme.surface, borderRadius: 4,
        borderWidth: indexAxis === 'y' ? { left: 1, right: 1 } : { top: 1, bottom: 1 },
      };
    }
    return { backgroundColor: c, borderColor: c, borderWidth: 0, borderRadius: 4 };
  }

  // Which scale a dataset's VALUES land on. Chart.js reads yAxisID for a
  // vertical chart and xAxisID for indexAxis:'y'; unset means the default axis.
  // Whether Chart.js sums this dataset onto its neighbours: its OWN value
  // axis decides (Chart.js isStacked), and an explicit `stacked: false` there
  // beats a `stack` key. A stacked y1 says nothing about bars on y.
  function stacksValues(ds, uScales, indexAxis) {
    var s = uScales[valueAxisOf(ds, indexAxis)];
    var flag = s ? s.stacked : undefined;
    return !!(flag || (flag === undefined && ds && ds.stack !== undefined));
  }

  function valueAxisOf(ds, indexAxis) {
    if (indexAxis === 'y') return (ds && ds.xAxisID) || 'x';
    return (ds && ds.yAxisID) || 'y';
  }

  function scaleDefaults(theme) {
    return { ticks: { color: theme.textMuted }, grid: { color: theme.grid }, border: { color: theme.grid } };
  }

  function themedConfig(cfg, theme) {
    var uOpts = cfg.options || {}, uData = cfg.data || {}, uSets = uData.datasets || [];
    var indexAxis = uOpts.indexAxis === 'y' ? 'y' : 'x';
    var valueKey = indexAxis === 'y' ? 'x' : 'y';   // key read off an {x,y} point
    var ca = indexAxis;                              // category axis id
    var uScales = uOpts.scales || {};
    var i, k;

    var base = {
      options: {
        responsive: true,
        maintainAspectRatio: false,
        // Unified hover: one tooltip listing every series at that x, which is
        // what a multi-series dashboard chart is read for.
        interaction: { mode: 'index', intersect: false },
        plugins: {
          legend: { labels: { color: theme.textMuted, usePointStyle: true, boxWidth: 10, boxHeight: 10 } },
          tooltip: {
            backgroundColor: theme.isDark ? 'rgba(16,15,14,0.94)' : 'rgba(41,39,36,0.94)',
            titleColor: '#FFFFFF', bodyColor: '#FFFFFF',
            borderColor: theme.grid, borderWidth: 1,
            padding: 10, cornerRadius: 6, displayColors: true,
          },
        },
      },
    };

    if (cfg.type === 'radar' || cfg.type === 'polarArea') {
      base.options.scales = { r: {
        ticks: { color: theme.textMuted, backdropColor: 'transparent' },
        grid: { color: theme.grid }, angleLines: { color: theme.grid },
        pointLabels: { color: theme.textMuted },
      } };
    } else if (!NO_CARTESIAN[cfg.type]) {
      // Every scale the chart will have: the two defaults, plus anything the
      // app declared (a right-hand y1, say). Theming only x and y left y1's
      // ticks in Chart.js' default #666 on a dark card.
      var byAxis = {};
      var ids = {};
      ids[ca] = 1; ids[valueKey] = 1;
      for (k in uScales) if (hasOwn(uScales, k)) ids[k] = 1;
      for (i = 0; i < uSets.length; i++) {
        var ax = valueAxisOf(uSets[i], indexAxis);
        ids[ax] = 1;
        (byAxis[ax] || (byAxis[ax] = [])).push(uSets[i]);
      }
      base.options.scales = {};
      for (k in ids) if (hasOwn(ids, k)) {
        if (k === ca) {
          base.options.scales[k] = { ticks: { color: theme.textMuted }, grid: { display: false, color: theme.grid }, border: { color: theme.grid } };
          continue;
        }
        var value = scaleDefaults(theme);
        // Bounds are derived PER AXIS from the datasets that land on it. A
        // percentage line on y1 dipping to -20 must not drag y (revenue in
        // the tens of thousands) down to -20000.
        var stacked = !!((uScales[k] && uScales[k].stacked) || (uScales[ca] && uScales[ca].stacked));
        var ext = signedExtent(byAxis[k] || [], cfg.type, stacked, valueKey);
        if (ext && ext.hasNegative) {
          var ns = niceScale(ext.dataMin, ext.dataMax, 4);
          // SUGGESTED, not hard. Chart.js only ever widens a suggested bound,
          // so an app that later mutates chart.data in place and calls
          // update() is never clipped at bounds computed from stale data —
          // and beginAtZero on signed data would pin one end at 0.
          value.beginAtZero = false;
          value.suggestedMin = ns.nMin;
          value.suggestedMax = ns.nMax;
          // Zero baseline. Scriptable so it stays one line of config rather
          // than an annotation plugin the app would have to load.
          value.grid.color = function (c) {
            return c && c.tick && Number(c.tick.value) === 0 ? theme.textMuted : theme.grid;
          };
          value.grid.lineWidth = function (c) {
            return c && c.tick && Number(c.tick.value) === 0 ? 1.5 : 1;
          };
        }
        base.options.scales[k] = value;
      }
    }

    var out = deepMerge(base, cfg);
    // Rebuild `data` rather than merging it: the datasets array needs per-index
    // theming, and the app's own config object must come back unmutated.
    var data = {};
    for (k in uData) if (hasOwn(uData, k)) data[k] = uData[k];
    data.datasets = [];
    for (i = 0; i < uSets.length; i++) {
      var defaults = datasetDefaults(i, uSets[i], cfg.type, theme, stacksValues(uSets[i], uScales, indexAxis), indexAxis);
      var merged = deepMerge(defaults, uSets[i] || {});
      // Remember which keys the THEME supplied, so a rebuild from the live
      // chart can strip them and re-theme, while keys the app set stay the
      // app's. Non-enumerable: invisible to Chart.js and to deepMerge.
      var injected = [];
      for (k in defaults) if (hasOwn(defaults, k) && !(uSets[i] && hasOwn(uSets[i], k))) injected.push(k);
      try { Object.defineProperty(merged, '__gsInjected', { value: injected, enumerable: false, configurable: true }); } catch (e) {}
      data.datasets.push(merged);
    }
    out.data = data;
    return out;
  }

  // The app-authored view of a LIVE dataset: everything the theme injected
  // stripped back off. A dataset the app added after mount carries no marker
  // and is taken whole.
  function stripInjected(ds) {
    if (!ds || typeof ds !== 'object') return ds;
    var injected = ds.__gsInjected;
    if (!injected) return ds;
    var out = {}, k, i, skip = {};
    for (i = 0; i < injected.length; i++) skip[injected[i]] = 1;
    for (k in ds) if (hasOwn(ds, k) && !skip[k]) out[k] = ds[k];
    return out;
  }

  // Sweep handles whose canvas left the document. A section that re-rendered
  // (loadSections replaces el.innerHTML on every refresh, and so does any
  // hand-written refresh) leaves its canvas detached; keeping the handle would
  // keep the Chart.js instance — and its whole dataset — alive for the life of
  // the page, growing once per refresh.
  function sweepDetached() {
    for (var i = _liveCharts.length - 1; i >= 0; i--) {
      try { if (_liveCharts[i].isDetached()) _liveCharts[i].destroy(); } catch (e) {}
    }
  }

  // Chart.js on demand. The kit is injected for every page, Chart.js is not:
  // a page that calls gsDash.chart without its own Chart.js <script> tag got
  // an empty card (the fast-lane page guide never told the agent to add one —
  // 2026-11-12 dev e2e). So when window.Chart is missing the kit loads one
  // pinned build itself, once per page, and every chart waiting on it draws
  // when it lands. A failed load is not remembered, so h.update() (or a later
  // chart) tries again.
  //
  // The page's own Chart.js wins: while the document is loading, a page tag
  // (async, defer, or after the inline script) is waited for until window
  // load, never raced by a second copy that would replace window.Chart and
  // drop the plugins and adapters the page registers on its own. The kit
  // fetches only when that tag is absent or gave no window.Chart.
  //
  // SRI pins the exact bytes, as loadXlsx does: the script runs next to the
  // app's data. `chart.umd.js` is the file npm publishes for 4.4.7 (already
  // minified); jsdelivr's `.min.js` is minified by jsdelivr and its bytes are
  // not guaranteed stable.
  var CHART_JS_URL = 'https://cdn.jsdelivr.net/npm/chart.js@4.4.7/dist/chart.umd.js';
  var CHART_JS_SRI = 'sha384-zYPBGXwO4633CABX/5Spf6emCKUJCfoOkhOMYyxMsatqQZPnDblmmOewfjsIVWCM';
  var _chartJsWaiting = null; // callbacks while a load is in flight, else null

  // A Chart.js <script> the page itself added, while the document is still
  // loading (it may not have run yet). Once the document is complete every
  // such tag has run, so there is nothing to wait for.
  function pendingPageChartJs() {
    if (document.readyState === 'complete') return null;
    var tags = document.getElementsByTagName('script');
    for (var i = 0; i < tags.length; i++) {
      var t = tags[i];
      if (t.hasAttribute('data-gs-chartjs')) continue;
      if (/chart\.(js|umd|min)\b/i.test(t.getAttribute('src') || '')) return t;
    }
    return null;
  }

  function loadChartJs(done) {
    if (typeof window.Chart === 'function') { done(true); return; }
    if (_chartJsWaiting) { _chartJsWaiting.push(done); return; }
    var waiting = _chartJsWaiting = [done];
    var settled = false;
    function settle() {
      if (settled) return;
      settled = true;
      _chartJsWaiting = null;
      var ok = typeof window.Chart === 'function';
      for (var i = 0; i < waiting.length; i++) {
        try {
          waiting[i](ok);
        } catch (e) {
          // Not swallowed: the other charts still draw, and the error
          // surfaces as an uncaught one, as it would have from a sync call.
          (function (err) { setTimeout(function () { throw err; }, 0); })(e);
        }
      }
    }
    function fetchOwn() {
      try {
        var s = document.createElement('script');
        s.src = CHART_JS_URL;
        s.integrity = CHART_JS_SRI;
        s.crossOrigin = 'anonymous';
        s.async = true;
        s.setAttribute('data-gs-chartjs', '');
        s.onload = settle;
        s.onerror = settle;
        (document.head || document.documentElement).appendChild(s);
      } catch (e) {
        settle();
      }
    }
    var pageTag = pendingPageChartJs();
    if (!pageTag) { fetchOwn(); return; }
    // The tag may have run already (and failed: a 404, or the ESM build that
    // defines no window.Chart), so its own events are not enough. The window
    // load event fires once every script in the document has run: then a
    // still-missing window.Chart means the page's copy is not coming.
    var waitingOnPage = true;
    function finish() {
      waitingOnPage = false;
      pageTag.removeEventListener('load', onTag);
      window.removeEventListener('load', onWindow);
      if (typeof window.Chart === 'function') settle(); else fetchOwn();
    }
    function onTag() { if (waitingOnPage && typeof window.Chart === 'function') finish(); }
    function onWindow() { if (waitingOnPage) finish(); }
    pageTag.addEventListener('load', onTag);
    window.addEventListener('load', onWindow);
  }

  // A Chart.js instance still registered on this canvas that we do not hold:
  // drawn by hand, or left behind by a `new Chart` that threw after
  // registering itself (an unknown `type`, say). Chart.js refuses the canvas
  // with "Canvas is already in use" until it is gone.
  function destroyStray(canvas) {
    try {
      if (window.Chart && typeof window.Chart.getChart === 'function') {
        var stray = window.Chart.getChart(canvas);
        if (stray && typeof stray.destroy === 'function') stray.destroy();
      }
    } catch (e) {}
  }

  function chart(el, config) {
    var target = typeof el === 'string' ? document.querySelector(el) : el;
    if (!target) throw new Error('gsDash.chart: container not found');
    var canvas = target;
    if (String(target.tagName || '').toLowerCase() !== 'canvas') {
      canvas = target.querySelector && target.querySelector('canvas');
      if (!canvas) {
        canvas = document.createElement('canvas');
        target.innerHTML = '';
        target.appendChild(canvas);
      }
    }
    sweepDetached();
    // Whatever already owns this canvas goes first: our own handle (reached
    // through the container OR the canvas), or a chart the app drew by hand —
    // Chart.js throws "Canvas is already in use" otherwise.
    var prev = canvas.__gsChart || target.__gsChart;
    if (prev) prev.destroy();
    destroyStray(canvas);

    var userConfig = config || {};
    var handle = {
      instance: null, config: null,
      update: update, retheme: retheme, destroy: destroy,
      // `isConnected === false` rather than `!isConnected`: an environment
      // that does not implement it must not have every chart swept away.
      isDetached: function () { return canvas.isConnected === false; },
    };
    var destroyed = false;
    var warnedNoChart = false; // once per chart, not once per rebuild
    var warnedUnsized = false;
    var loading = false; // waiting on loadChartJs

    function clearNote() {
      var parent = canvas.parentNode;
      if (parent && parent.__gsChartNote) {
        try { parent.removeChild(parent.__gsChartNote); } catch (e) {}
        parent.__gsChartNote = null;
      }
    }

    // One status line under the canvas: "Loading chart…" while Chart.js is in
    // flight, an error when it could not load. Never an empty card.
    function showNote(text, isError) {
      var parent = canvas.parentNode;
      if (!parent) return;
      try {
        var note = parent.__gsChartNote;
        if (!note) {
          note = document.createElement('div');
          note.className = 'gs-empty';
          parent.appendChild(note);
          parent.__gsChartNote = note;
        }
        note.textContent = text;
        if (isError) note.setAttribute('role', 'alert');
        else note.removeAttribute('role');
      } catch (e) {}
    }

    function noChartJs(loadFailed) {
      if (!loadFailed) {
        showNote('Loading chart…', false);
        if (loading) return;
        loading = true;
        loadChartJs(function () {
          loading = false;
          if (destroyed || handle.instance) return;
          // The section re-rendered while Chart.js was in flight: drop the
          // handle as sweepDetached would, never draw on the dead canvas.
          if (handle.isDetached()) { destroy(); return; }
          try {
            build(false, true);
          } catch (e) {
            // Chart.js rejected the config (an unknown type, say). A sync
            // call would have thrown at the app; here the card says so and
            // loadChartJs rethrows it uncaught.
            showNote('Chart failed to render — ' + (e && e.message ? e.message : String(e)), true);
            try { console.error('[gsDash.chart] Chart.js rejected the config:', e); } catch (e2) {}
            throw e;
          }
        });
        return;
      }
      if (!warnedNoChart) {
        warnedNoChart = true;
        try {
          console.error('[gsDash.chart] window.Chart is not loaded and Chart.js could not be fetched from '
            + CHART_JS_URL + ' — the chart cannot render.');
        } catch (e) {}
      }
      showNote('Chart unavailable — Chart.js could not load', true);
    }

    // Chart.js sizes the canvas to its container when the chart is created.
    // A container that is hidden (or not in the document yet) measures 0, the
    // canvas is locked at 0x0, and nothing is drawn. On a live page Chart.js
    // recovers when the container appears; where frames do not run it never
    // does. Say so, instead of leaving an empty card to be debugged.
    function warnUnsized() {
      var box = canvas.parentNode;
      if (warnedUnsized || !box || box.clientWidth > 0) return;
      warnedUnsized = true;
      try {
        console.warn('[gsDash.chart] ' + (canvas.id ? '#' + canvas.id : 'canvas')
          + ' has no size: its container is hidden or not in the document. Show the container'
          + ' (e.g. el.hidden = false) BEFORE calling gsDash.chart, or the chart stays 0x0.');
      } catch (e) {}
    }

    // `afterLoad`: called back by loadChartJs — a missing window.Chart now
    // means the load failed, so say so instead of loading again.
    function build(checkData, afterLoad) {
      var merged = themedConfig(userConfig, chartTheme());
      // Runs even without Chart.js: a total that disagrees with its parts is a
      // data defect, and it should be reported whether or not the canvas drew.
      if (checkData) warnTotals(merged.data, userConfig.type, (userConfig.options || {}).indexAxis === 'y' ? 'x' : 'y');
      handle.config = merged;
      if (typeof window.Chart !== 'function') {
        noChartJs(!!afterLoad);
        return;
      }
      clearNote();
      warnUnsized();
      // Draw the first frame without animation (see "First paint" above),
      // then hand animation back to Chart.js' defaults — but only from inside
      // a frame callback. Where frames never run the key stays, so resizes
      // and data updates keep drawing synchronously too.
      var opts = merged.options || (merged.options = {});
      var ownAnimation = hasOwn(userConfig.options || {}, 'animation');
      if (!ownAnimation) opts.animation = false;
      destroyStray(canvas); // a previous build that threw mid-construction
      var inst = handle.instance = new window.Chart(canvas, merged);
      if (!ownAnimation) {
        try {
          window.requestAnimationFrame(function () {
            if (handle.instance === inst && opts.animation === false) delete opts.animation;
          });
        } catch (e3) {}
      }
    }

    // The app's config as it stands NOW: the live chart's data (which the app
    // may have mutated in place — the idiomatic Chart.js update path) with the
    // theme's injected keys stripped, under the app's original options.
    function liveConfig() {
      var inst = handle.instance;
      var live = inst && inst.data;
      if (!live || typeof live !== 'object') return userConfig;
      var next = {}, k;
      for (k in userConfig) if (hasOwn(userConfig, k)) next[k] = userConfig[k];
      var data = {};
      for (k in live) if (hasOwn(live, k)) data[k] = live[k];
      data.datasets = (live.datasets || []).map(stripInjected);
      next.data = data;
      return next;
    }

    function teardown() {
      if (handle.instance && typeof handle.instance.destroy === 'function') {
        try { handle.instance.destroy(); } catch (e) {}
      }
      handle.instance = null;
    }

    // update(config) re-renders from a new config; update() re-renders from
    // whatever the live chart holds now (after in-place data changes).
    function update(next) {
      if (destroyed) return handle;
      userConfig = next || liveConfig();
      teardown();
      build(true);
      return handle;
    }
    // Called by the kit's single matchMedia listener — never by the app.
    // Rebuilds from the LIVE data, so a flip never reverts the chart to the
    // data it was created with.
    function retheme() {
      if (destroyed) return handle;
      userConfig = liveConfig();
      teardown();
      build(false);
      return handle;
    }
    function destroy() {
      if (destroyed) return;
      destroyed = true;
      teardown();
      clearNote();
      for (var i = 0; i < _liveCharts.length; i++) {
        if (_liveCharts[i] === handle) { _liveCharts.splice(i, 1); break; }
      }
      if (target.__gsChart === handle) target.__gsChart = null;
      if (canvas.__gsChart === handle) canvas.__gsChart = null;
    }

    _liveCharts.push(handle);
    target.__gsChart = handle;
    canvas.__gsChart = handle;
    build(true);
    return handle;
  }

  function phead(title, sub, badge, o) {
    return '<div class="gs-phead"><div><div class="t-h3"' + lit(o, 'title') + '>' + esc(title) + '</div>' + (sub ? '<div class="t-small"' + lit(o, 'sub') + '>' + esc(sub) + '</div>' : '') + '</div>' + (badge ? '<span class="t-small" style="color:var(--ink-400)">' + esc(badge) + '</span>' : '') + '</div>';
  }
  function kpiCard(s) {
    return '<div class="gs-card gs-kpi"><span class="t-small" style="color:var(--ink-500)"' + lit(s, 'label') + '>' + esc(s.label) + '</span>'
      + '<div class="t-h1 num ' + (s.accent || '') + '">' + esc(s.value) + '</div>'
      + (s.sub ? '<div class="t-small gs-kpi-sub"' + lit(s, 'sub') + '>' + esc(s.sub) + '</div>' : '') + '</div>';
  }
  function kpiRow(specs) {
    var n = Math.max(1, Math.min((specs || []).length, 5));
    return '<div class="gs-kpis" style="--gs-kpi-cols:' + n + '">' + (specs || []).map(kpiCard).join('') + '</div>';
  }
  function donutCard(o) {
    var rows = o.rows || [], fmt = o.fmt || fmtInt, total = rows.reduce(function (a, r) { return a + Number(r.value); }, 0) || 1;
    if (!rows.length) return '<div class="gs-card">' + phead(o.title, o.sub, o.badge, o) + '<div class="gs-empty">No data yet</div></div>';
    var leg = rows.map(function (r, i) { var pct = Math.round(100 * Number(r.value) / total); return '<div class="gs-leg"><span class="sw" style="background:' + vizRef(i) + '"></span><span class="nm">' + esc(humanize(r.label)) + '</span><span class="vv num">' + fmt(r.value) + '</span><span class="pp num t-small">' + pct + '%</span></div>'; }).join('');
    return '<div class="gs-card">' + phead(o.title, o.sub, o.badge, o) + '<div class="gs-donut-body">' + donut(keep(o, { rows: rows, center: o.center, centerVal: o.centerVal || fmt(total) })) + '<div class="gs-legend">' + leg + '</div></div></div>';
  }
  function barCard(o) {
    if (!(o.rows || []).length) return '<div class="gs-card">' + phead(o.title, o.sub, o.badge, o) + '<div class="gs-empty">No data yet</div></div>';
    return '<div class="gs-card">' + phead(o.title, o.sub, o.badge, o) + '<div>' + barH({ rows: o.rows, xFmt: o.xFmt, l: o.l }) + '</div></div>';
  }
  function feedCard(o) {
    var rows = o.rows || [];
    if (!rows.length) return '<div class="gs-card">' + phead(o.title, null, null, o) + '<div class="gs-empty"' + lit(o, 'empty') + '>' + esc(o.empty || 'No entries') + '</div></div>';
    var body = rows.map(function (r, i) {
      var col = r.color || AV[i % AV.length];
      return '<div class="row"><span class="gs-avatar" style="background:color-mix(in srgb,' + col + ' 14%,transparent);color:' + col + '">' + esc(r.initial || '\u2022') + '</span><div class="main"><div class="ttl">' + esc(r.main) + '</div>' + (r.sub ? '<div class="sub">' + esc(r.sub) + '</div>' : '') + '</div><span class="meta">' + (r.meta || '') + '</span></div>';
    }).join('');
    return '<div class="gs-card">' + phead(o.title, null, null, o) + '<div class="gs-feed">' + body + '</div></div>';
  }
  function panels(arr, cols) {
    return '<div class="gs-panels" style="--gs-panel-cols:' + (arr.length >= 2 ? (cols || '1.1fr .9fr') : '1fr') + '">' + arr.join('') + '</div>';
  }

  // Virtualized data table for large result sets. Renders only the rows in
  // (and near) the viewport and recycles them on scroll, so DOM residency is
  // bounded no matter how many rows stream in. Pages are pulled lazily via
  // opts.fetchPage(cursor) — an opaque keyset cursor passed back verbatim,
  // never an OFFSET the component computes — and in-memory rows are capped at
  // opts.maxResident: the earliest rows are dropped behind a visible
  // "earlier rows omitted" notice (silent truncation would misstate the data).
  //
  //   gsDash.virtualTable(container, {
  //     columns: [{ key, label?, width?, align?, render? }],
  //     fetchPage: function (cursor) ->
  //       Promise<{ rows: object[], nextCursor: any|null }>,
  //     pageSize?: 200, maxResident?: 1000, rowHeight?: 36, height?: '420px',
  //     empty?: 'No data yet',
  //   }) -> { refresh(), destroy() }
  //
  // render(row) returns an HTML string (escape data yourself or build it from
  // esc()/tag()); without render the cell shows esc(row[key]). fetchPage ends
  // the stream by returning nextCursor: null (or an empty rows page).
  function virtualTable(container, opts) {
    if (typeof container === 'string') container = document.querySelector(container);
    opts = opts || {};
    if (!container) throw new Error('gsDash.virtualTable: container not found');
    if (typeof opts.fetchPage !== 'function') throw new Error('gsDash.virtualTable: fetchPage(cursor) is required');
    var cols = opts.columns || [];
    if (!cols.length) throw new Error('gsDash.virtualTable: columns is required');
    var rowH = opts.rowHeight || 36;
    var pageSize = opts.pageSize || 200;
    var maxResident = Math.max(opts.maxResident || 1000, pageSize * 2);
    var overscan = 6;
    if (container.__gsVt) container.__gsVt.destroy();

    var rows = [], trimmed = 0, cursor = null;
    var done = false, loading = false, failed = false, destroyed = false, gen = 0;
    var grid = cols.map(function (c) { return c.width || 'minmax(80px,1fr)'; }).join(' ');

    var root = document.createElement('div'); root.className = 'gs-vtable';
    var head = document.createElement('div'); head.className = 'gs-vt-head'; head.style.gridTemplateColumns = grid;
    head.innerHTML = cols.map(function (c) {
      return '<div class="gs-vt-th"' + (c.align === 'right' ? ' style="text-align:right"' : '') + lit(c, 'label') + '>'
        + esc(c.label != null ? c.label : humanize(c.key)) + '</div>';
    }).join('');
    var notice = document.createElement('div'); notice.className = 'gs-vt-notice'; notice.style.display = 'none';
    var viewport = document.createElement('div'); viewport.className = 'gs-vt-viewport';
    viewport.style.height = typeof opts.height === 'number' ? opts.height + 'px' : (opts.height || '420px');
    var sizer = document.createElement('div'); sizer.className = 'gs-vt-sizer';
    var slice = document.createElement('div'); slice.className = 'gs-vt-slice';
    var status = document.createElement('div'); status.className = 'gs-vt-status'; status.style.display = 'none';
    sizer.appendChild(slice);
    viewport.appendChild(sizer);
    viewport.appendChild(status);
    root.appendChild(head);
    root.appendChild(notice);
    root.appendChild(viewport);
    container.innerHTML = '';
    container.appendChild(root);

    function cellHtml(r, c) {
      if (c.render) return String(c.render(r));
      var v = r == null ? null : r[c.key];
      return esc(v == null ? '' : v);
    }

    function render() {
      sizer.style.height = (rows.length * rowH) + 'px';
      var vh = viewport.clientHeight || 0;
      var start = Math.max(0, Math.floor(viewport.scrollTop / rowH) - overscan);
      var end = Math.min(rows.length, Math.ceil((viewport.scrollTop + vh) / rowH) + overscan);
      slice.style.top = (start * rowH) + 'px';
      var html = '';
      for (var i = start; i < end; i++) {
        html += '<div class="gs-vt-row" style="grid-template-columns:' + grid + ';height:' + rowH + 'px">';
        for (var j = 0; j < cols.length; j++) {
          html += '<div class="gs-vt-cell' + (cols[j].align === 'right' ? ' num ta-r' : '') + '">' + cellHtml(rows[i], cols[j]) + '</div>';
        }
        html += '</div>';
      }
      slice.innerHTML = html;
      if (trimmed > 0) {
        notice.textContent = fmtInt(trimmed) + ' earlier rows omitted to keep this view responsive — refine the query to browse them';
        notice.style.display = '';
      }
      if (!loading && !failed) {
        if (!rows.length && done) { status.textContent = opts.empty || 'No data yet'; status.style.display = ''; }
        else { status.style.display = 'none'; }
      }
      maybeFetch();
    }

    function maybeFetch() {
      if (done || loading || failed || destroyed) return;
      var vh = viewport.clientHeight || 0;
      var belowPx = rows.length * rowH - (viewport.scrollTop + vh);
      if (belowPx < rowH * Math.max(20, pageSize / 2)) fetchNext();
    }

    function fetchNext() {
      loading = true;
      var g = gen;
      status.textContent = 'Loading…';
      status.style.display = '';
      var p;
      try { p = Promise.resolve(opts.fetchPage(cursor)); } catch (e) { p = Promise.reject(e); }
      p.then(function (page) {
        if (destroyed || g !== gen) return;
        var isArr = Object.prototype.toString.call(page) === '[object Array]';
        var newRows = isArr ? page : ((page && page.rows) || []);
        var next = isArr || page == null ? null : page.nextCursor;
        rows = rows.concat(newRows);
        cursor = next;
        if (next == null || !newRows.length) done = true;
        if (rows.length > maxResident) {
          // Drop the earliest rows; shift scrollTop so the visible rows stay
          // put (indices moved up by `cut`).
          var cut = rows.length - maxResident;
          rows.splice(0, cut);
          trimmed += cut;
          viewport.scrollTop = Math.max(0, viewport.scrollTop - cut * rowH);
        }
        loading = false;
        render();
      }, function (err) {
        if (destroyed || g !== gen) return;
        loading = false;
        failed = true;
        status.innerHTML = '';
        var t = document.createElement('span');
        t.textContent = 'Error: ' + (err && err.message ? err.message : err);
        var b = document.createElement('button');
        b.className = 'gs-vt-retry';
        b.textContent = 'Retry';
        b.onclick = function () { failed = false; status.style.display = 'none'; fetchNext(); };
        status.appendChild(t);
        status.appendChild(b);
        status.style.display = '';
      });
    }

    function onScroll() { render(); }
    viewport.addEventListener('scroll', onScroll);
    var ro = typeof ResizeObserver === 'function' ? new ResizeObserver(function () { render(); }) : null;
    if (ro) ro.observe(viewport);

    function refresh() {
      gen++;
      rows = []; trimmed = 0; cursor = null;
      done = false; loading = false; failed = false;
      notice.style.display = 'none';
      viewport.scrollTop = 0;
      render();
    }
    function destroy() {
      destroyed = true;
      gen++;
      viewport.removeEventListener('scroll', onScroll);
      if (ro) ro.disconnect();
      if (follow) follow.off();
      if (container.__gsVt === handle) container.__gsVt = null;
    }
    var handle = { refresh: refresh, destroy: destroy };
    container.__gsVt = handle;
    // A grid or form write elsewhere reloads the list from the first page.
    var follow = followChanges(root, opts, refresh);
    render();
    return handle;
  }

  // Staged loader for multi-section dashboards. Collecting every query
  // result first and rendering the whole page in one pass freezes the
  // renderer — serial fetches don't help, because the single giant render
  // still blocks the main thread for the entire page. loadSections renders
  // the sections strictly in order — render one section, yield the main
  // thread (setTimeout 0, so the browser can paint it), then render the
  // next — with per-section retry + exponential backoff, and a failed
  // section renders an inline error + Retry without blocking the sections
  // after it. Queries are PREFETCHED a small window ahead of the section
  // being rendered (opts.prefetch, default 2), so staging costs little
  // wall-clock versus a parallel fetch while rendering stays one section
  // at a time.
  //
  //   gsDash.loadSections({
  //     sections: [{
  //       el,                  // element (or selector) the section renders into
  //       queryName?, params?, // window.agentdb.executeQuery(queryName, params);
  //                            // params may be a function (re-read every run).
  //                            // Omit queryName for mount-only sections — e.g.
  //                            // a virtualTable, which pages its own data.
  //       render,              // render(result, el) — must replace el's content;
  //                            // result is null for mount-only sections.
  //                            // el is un-hidden (el.hidden = false) just
  //                            // before the call, so a section the page
  //                            // ships as `hidden` has a real size for
  //                            // whatever render measures (a chart canvas)
  //     }],
  //     retries?: 2,           // per-section retries after the first failure
  //     backoffMs?: 500,       // first retry delay; doubles per retry
  //     prefetch?: 2,          // how many sections ahead queries may be
  //                            // started (0 = strictly one query in flight)
  //     onSectionError?: function (err, section, index) {},
  //     autoRefresh?: true,    // re-run the queryName sections after any
  //                            // kit write (gsdash:data-changed), skipping
  //                            // the section the write came from and
  //                            // mount-only sections (their blocks follow
  //                            // writes themselves)
  //   }) -> { refresh(), cancel() }
  //
  // refresh() restarts from the first section; sections that rendered before
  // keep their content on screen while their query re-runs (failed ones show
  // the loading placeholder again). cancel() drops all in-flight work; a
  // later refresh() starts the sequence again, and a failed section's Retry
  // button keeps working even while cancelled.
  var LOADERS = [];
  // The section objects and elements some loader runs. The seeded section
  // runner (backend/agentdb/app_scaffold.py) asks loadSections.owns() and
  // leaves exactly those to the kit, so a section the page passes here
  // renders once, while the page's other SECTIONS still run through it.
  var OWNED = new WeakSet();
  function loadSections(opts) {
    opts = opts || {};
    var sections = opts.sections || [];
    if (!sections.length) throw new Error('gsDash.loadSections: sections is required');
    for (var si = 0; si < sections.length; si++) {
      if (typeof sections[si].render !== 'function') {
        throw new Error('gsDash.loadSections: sections[' + si + '].render is required');
      }
    }
    var retries = opts.retries == null ? 2 : opts.retries;
    var backoffMs = opts.backoffMs == null ? 500 : opts.backoffMs;
    var prefetch = opts.prefetch == null ? 2 : Math.max(0, opts.prefetch);
    var gen = 0;
    var rendered = [];

    function elOf(s) { return typeof s.el === 'string' ? document.querySelector(s.el) : s.el; }
    function showLoading(el) { el.innerHTML = '<div class="gs-sec-loading">Loading…</div>'; }
    // A page may ship its sections `hidden` until they have content. Left to
    // render() to undo, the reveal lands after the chart call (the canvas has
    // already measured 0x0) or is forgotten and the section never shows.
    function reveal(el) { if (el && el.hidden) el.hidden = false; }
    function paramsOf(s) { return typeof s.params === 'function' ? s.params() : (s.params || {}); }
    function firstFetch(s) {
      try {
        if (!s.queryName) return Promise.resolve(null);
        // Point-and-select (editor preview only): this query is the kit's.
        if (typeof window.__abClaim === 'function') window.__abClaim(s.queryName);
        return Promise.resolve(window.agentdb.executeQuery(s.queryName, paramsOf(s)));
      } catch (e) { return Promise.reject(e); }
    }

    function fail(err, s, i, el, g) {
      rendered[i] = false;
      owed[i] = false;
      if (el) {
        reveal(el);
        el.innerHTML = '';
        var box = document.createElement('div');
        box.className = 'gs-sec-error';
        var t = document.createElement('span');
        t.textContent = 'Error: ' + (err && err.message ? err.message : err);
        var b = document.createElement('button');
        b.className = 'gs-sec-retry';
        b.textContent = 'Retry';
        b.onclick = function () {
          // Run under the CURRENT generation, not the one the failure
          // happened in: cancel() bumps the generation without touching the
          // DOM, and a still-visible Retry that silently no-ops is worse
          // than the rare duplicate fetch when a refresh walk is in flight.
          showLoading(el);
          runSection(s, i, gen, 0, null, function () {});
        };
        box.appendChild(t);
        box.appendChild(b);
        el.appendChild(box);
      }
      try { console.error('[error] gsDash.loadSections section ' + i + ':', err); } catch (e1) {}
      if (opts.onSectionError) {
        try { opts.onSectionError(err, s, i); } catch (e2) {}
      }
    }

    function runSection(s, i, g, attempt, prefetched, done) {
      var el = elOf(s);
      if (!el) {
        fail(new Error('loadSections: section ' + i + ' container not found'), s, i, null, g);
        done();
        return;
      }
      // First attempts may consume a prefetched query; retries (and manual
      // Retry clicks) always issue a fresh one.
      var p = attempt === 0 && prefetched ? prefetched : firstFetch(s);
      p.then(function (result) {
        if (g !== gen) return;
        var checkEdits = redraw[i];
        redraw[i] = false;
        // A query section that already shows a render: clear it now, just
        // before the new render (it stayed on screen while the query ran).
        // The first load replaced the page's markup with the loading
        // placeholder, so el holds only render output; without this, a
        // render that appends (gsDash.section) stacks a copy under the stale
        // one on every refresh. Mount-only sections are never cleared: their
        // blocks keep handles on their nodes (virtualTable's __gsVt).
        if (s.queryName && rendered[i]) {
          // The user started editing in it while the query ran: keep that.
          if (checkEdits && hasEdits(el)) { done(); return; }
          el.innerHTML = '';
        }
        try {
          reveal(el);
          // Point-and-select (editor preview only defines __abStamp): the
          // section's element names the query that fills it.
          if (s.queryName && typeof window.__abStamp === 'function') {
            window.__abStamp(el, s.queryName, paramsOf(s));
          }
          s.render(result, el);
          rendered[i] = true;
          owed[i] = false;
        } catch (renderErr) {
          // A render() throw is a code defect, not a transient failure —
          // retrying would re-issue the query just to crash the same way.
          fail(renderErr, s, i, el, g);
        }
        done();
      }, function (err) {
        if (g !== gen) return;
        if (attempt < retries) {
          setTimeout(function () {
            if (g !== gen) return;
            runSection(s, i, g, attempt + 1, null, done);
          }, backoffMs * Math.pow(2, attempt));
        } else {
          fail(err, s, i, el, g);
          done();
        }
      });
    }

    // only(section, index) limits a run to some sections (a data-change run).
    function run(only) {
      var g = ++gen;
      if (!only) for (var oi = 0; oi < sections.length; oi++) owed[oi] = true;
      var queued = [];
      function skip(j) { return only && !only(sections[j], j); }
      for (var i = 0; i < sections.length; i++) {
        var el = elOf(sections[i]);
        if (el && !rendered[i] && !skip(i)) showLoading(el);
      }
      function ensure(j) {
        while (j < sections.length && skip(j)) j++;
        if (j >= sections.length || queued[j]) return;
        var p = firstFetch(sections[j]);
        // A prefetched failure is handled when its section is consumed; this
        // no-op handler just keeps it from surfacing as unhandled meanwhile.
        p.then(null, function () {});
        queued[j] = p;
      }
      (function next(i) {
        while (i < sections.length && skip(i)) i++;
        if (g !== gen || i >= sections.length) return;
        // Keep up to `prefetch` queries in flight beyond the section being
        // rendered, so staging does not serialize query latency.
        for (var j = i; j <= i + prefetch; j++) ensure(j);
        var p = queued[i] || null;
        queued[i] = null;
        runSection(sections[i], i, g, 0, p, function () {
          if (g !== gen) return;
          // Yield the main thread between sections so the browser paints the
          // section that just rendered before the next one starts.
          setTimeout(function () { next(i + 1); }, 0);
        });
      })(0);
    }

    // owed[i]: a full walk (first load or refresh()) has not rendered
    // section i yet; a data-change run cancels the walk, so it takes those.
    // redraw[i]: a data-change run re-renders query section i; it re-checks
    // for edits made while its query ran.
    var following = true, changeTimer = null, owed = [], redraw = [];
    // A page that calls loadSections again on the same elements (its own
    // reload) replaces the older loader: only the newest one follows writes.
    var myEls = sections.map(elOf).filter(Boolean);
    for (var ok = 0; ok < sections.length; ok++) OWNED.add(sections[ok]);
    for (var oe = 0; oe < myEls.length; oe++) OWNED.add(myEls[oe]);
    LOADERS = LOADERS.filter(function (l) {
      for (var k = 0; k < myEls.length; k++) if (l.els.indexOf(myEls[k]) >= 0) { l.stop(); return false; }
      return true;
    });
    if (opts.autoRefresh !== false) {
      var offChange = onDataChanged(function () {
        if (!following) return;
        // Every section element gone (the page swapped this view out): stop.
        var live = !myEls.length;
        for (var k = 0; k < myEls.length && !live; k++) if (myEls[k].isConnected) live = true;
        if (!live) { following = false; offChange(); return; }
        if (changeTimer) return;
        changeTimer = setTimeout(function () {
          changeTimer = null;
          if (!following) return;
          // The query sections (cards, charts, summaries) plus whatever a
          // cancelled full walk still owed, except a rendered section that
          // holds unsaved edits (it catches up on the next write). Rendered
          // mount-only sections hold blocks that follow writes themselves.
          run(function (s, j) {
            if (!rendered[j]) return true;
            if (hasEdits(elOf(s))) return false;
            if (!s.queryName && !owed[j]) return false;
            if (s.queryName) redraw[j] = true;
            return true;
          });
        }, 0);
      });
      LOADERS.push({ els: myEls, stop: function () { following = false; offChange(); } });
    }

    run();
    return {
      // A full refresh supersedes a data-change run already scheduled.
      refresh: function () { following = true; if (changeTimer) { clearTimeout(changeTimer); changeTimer = null; } run(); },
      cancel: function () { following = false; gen++; },
    };
  }
  // Whether a loader runs this section object, or renders into el.
  loadSections.owns = function (section, el) {
    return (!!section && typeof section === 'object' && OWNED.has(section)) ||
      (!!el && typeof el === 'object' && OWNED.has(el));
  };

  // ── Data-entry blocks: schemaFields / form / editTable / detailDrawer /
  // cardList / filterBar ───────────────────────────────────────────────────
  // The four app shapes the 11-10 census found the agent hand-writing on
  // almost every non-dashboard app: record forms (28% of used apps), editable
  // tables (27%), detail drawers (25%) and filtered card lists with
  // approve/reject buttons (44%). Each was ~100–250 lines of output per build;
  // these make each a single call. Writes always go through registered named
  // queries (window.agentdb.executeQuery) — never SQL in the page.

  var _uid = 0;
  function elOf(el, who) {
    if (typeof el === 'string') el = document.querySelector(el);
    if (!el) throw new Error('gsDash.' + who + ': container not found');
    return el;
  }
  function isArr(v) { return Object.prototype.toString.call(v) === '[object Array]'; }
  function lc(v) { return String(v == null ? '' : v).toLowerCase(); }
  function assign(t) {
    for (var i = 1; i < arguments.length; i++) {
      var s = arguments[i];
      if (s) for (var k in s) if (hasOwn(s, k)) t[k] = s[k];
    }
    return t;
  }
  function errText(err) { return err && err.message ? err.message : String(err == null ? 'Unknown error' : err); }
  function logErr(who, err) { try { console.error('[error] gsDash.' + who + ':', err); } catch (e) {} }
  function mk(tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text != null) n.textContent = text;
    return n;
  }
  function button(label, kind, onClick) {
    var b = mk('button', 'btn btn-sm btn-' + (kind || 'secondary'), label);
    b.type = 'button';
    if (onClick) b.onclick = onClick;
    return b;
  }
  // `read` marks a load: the editor's point-and-select maps those to the
  // block that drew them (same claim loadSections makes). Writes are not
  // claimed.
  function runQuery(name, params, read) {
    try {
      if (read && typeof window.__abClaim === 'function') window.__abClaim(name);
      var b = window.agentdb;
      if (!b || typeof b.executeQuery !== 'function') throw new Error('window.agentdb.executeQuery is not available');
      return Promise.resolve(b.executeQuery(name, params || {}));
    } catch (e) { return Promise.reject(e); }
  }
  // A write's RETURNING row, when the query has one.
  function firstRow(res) { return res && isArr(res.rows) && res.rows.length ? res.rows[0] : null; }

  // ── Data-changed bus ─────────────────────────────────────────────────────
  // Every successful kit write (editTable add / edit / delete, form,
  // cardList query action, kanban move, importer) is announced on window as
  // `gsdash:data-changed`, detail { source, kind, row?, rows?, table?, el }
  // (kind: 'add' | 'edit' | 'delete' | 'mixed'; el = the writing block's
  // root). The kit's query-backed readers re-run on it — loadSections query
  // sections, table, editTable, cardList, calendar, kanban — so cards and
  // charts follow a grid edit or delete with no page wiring (the 11-12
  // benchmark's lunch trackers kept stale totals after a grid delete).
  // A reader opts out with autoRefresh: false. Hand-written code:
  // gsDash.dataChanged({ kind, row }) after its own write,
  // gsDash.onDataChanged(fn) -> unsubscribe to re-load its own data.
  var CHANGED_EVENT = 'gsdash:data-changed';
  function dataChanged(detail) {
    detail = assign({ source: 'page', kind: 'edit' }, detail);
    try {
      var ev;
      if (typeof CustomEvent === 'function') ev = new CustomEvent(CHANGED_EVENT, { detail: detail });
      else { ev = document.createEvent('CustomEvent'); ev.initCustomEvent(CHANGED_EVENT, false, false, detail); }
      window.dispatchEvent(ev);
    } catch (e) { logErr('dataChanged', e); }
    return detail;
  }
  function onDataChanged(fn) {
    function h(e) { try { fn(e.detail || {}); } catch (err) { logErr('onDataChanged', err); } }
    window.addEventListener(CHANGED_EVENT, h);
    return function () { window.removeEventListener(CHANGED_EVENT, h); };
  }
  // True while el holds input a re-render would throw away. editTable and
  // form report it themselves (root.__gsDirty: unsaved rows even when the
  // search, chips or page hide them; typed form values after focus left);
  // any other focused field counts too.
  function hasEdits(el) {
    if (!el || !el.querySelectorAll) return false;
    var blocks = el.querySelectorAll('.gs-et, .gs-form');
    for (var i = -1; i < blocks.length; i++) {
      var b = i < 0 ? el : blocks[i];
      if (typeof b.__gsDirty === 'function' && b.__gsDirty()) return true;
    }
    var a = document.activeElement;
    return !!(a && a !== el && el.contains(a) && /^(INPUT|TEXTAREA|SELECT)$/.test(a.tagName));
  }
  // A block re-loads after OTHER blocks' writes (never its own: it already
  // shows them). One reload per burst (a 5-row save, a form plus its own
  // onSaved refresh), and reloads never overlap: a change during one queues
  // exactly one more, so an older response cannot land after a newer one.
  // A change that arrives while skip() is true (unsaved edits) is kept, and
  // kick() — the block calls it after its save or discard — reloads then.
  // Stops listening once the block has left the page (or on off()), so a
  // section that re-mounts blocks does not pile up listeners.
  //   -> null | { off(), kick(), miss() }
  function followChanges(root, opts, reload, skip) {
    if (opts.autoRefresh === false || !(opts.query || typeof opts.fetchPage === 'function')) return null;
    var running = false, queued = false, missed = false, stopped = false, seen = !!root.isConnected;
    function after() { running = false; if (queued) { queued = false; go(); } }
    function go() {
      if (stopped || !root.isConnected) return;
      if (skip && skip()) { missed = true; return; }
      missed = false;
      running = true;
      var p;
      try { p = Promise.resolve(reload()); } catch (e) { logErr('followChanges', e); p = Promise.resolve(); }
      p.then(after, after);
    }
    var offEv = onDataChanged(function (d) {
      if (root.isConnected) seen = true;
      else { if (seen) off(); return; }
      if (d.el && (d.el === root || (d.el.nodeType && root.contains(d.el)))) return;
      if (queued) return;
      queued = true;
      if (!running) setTimeout(function () { queued = false; go(); }, 0);
    });
    function off() { stopped = true; offEv(); }
    return {
      off: off,
      kick: function () { if (missed && !running && !queued) go(); },
      miss: function () { missed = true; },
    };
  }
  function askConfirm(message) {
    var b = window.agentdb;
    if (b && typeof b.confirm === 'function') {
      try { return Promise.resolve(b.confirm(message, { danger: true })); } catch (e) {}
    }
    try { return Promise.resolve(window.confirm(message)); } catch (e2) { return Promise.resolve(true); }
  }
  function labelOf(f) {
    if (f.label != null) return String(f.label);
    var s = humanize(f.key);
    return s.charAt(0).toUpperCase() + s.slice(1);
  }
  function optValue(o) { return isPlain(o) ? o.value : o; }
  function optLabel(o) { return isPlain(o) ? (o.label != null ? o.label : o.value) : o; }

  // PostgreSQL column type → field type.
  function fieldTypeOf(pg) {
    var t = lc(pg).replace(/\(.*?\)/g, '').replace(/^\s+|\s+$/g, '');
    if (/\[\]$/.test(t) || t === 'array' || /^jsonb?$/.test(t)) return 'json';
    if (t === 'bool' || t === 'boolean') return 'checkbox';
    if (/^(int[248]?|integer|bigint|smallint|(big|small)?serial)$/.test(t)) return 'integer';
    if (/^(numeric|decimal|real|float[48]?|double precision|money)$/.test(t)) return 'number';
    if (t === 'date') return 'date';
    if (/^timestamp/.test(t)) return 'datetime';
    if (/^time/.test(t)) return 'time';
    return 'text';
  }
  var AUTO_COLS = { id: 1, created_at: 1, updated_at: 1 };
  var _schemaP = null;
  function getSchemaOnce() {
    if (!_schemaP) {
      _schemaP = Promise.resolve().then(function () {
        var b = window.agentdb;
        if (!b || typeof b.getSchema !== 'function') throw new Error('window.agentdb.getSchema is not available');
        return b.getSchema();
      });
      _schemaP.then(null, function () { _schemaP = null; });
    }
    return _schemaP;
  }
  // The host answers getSchema() with { tables: [{ table_name, columns:
  // [{ name, type, is_primary_key?, not_null?, column_default? }] }] }
  // (GET /workspace/{ws}/schema). The column details are absent on older
  // backends and on an exported copy, and shared dashboards refuse
  // getSchema outright — so nothing below may depend on them: without
  // not_null no field is marked required, and auto columns fall back to the
  // id / created_at / updated_at names.
  function tableNameOf(t) { return t ? (t.table_name != null ? t.table_name : t.name) : null; }
  function findTable(schema, table) {
    var tables = (schema && schema.tables) || [];
    for (var i = 0; i < tables.length; i++) if (tableNameOf(tables[i]) === table) return tables[i];
    return null;
  }
  function defaultOf(c) { var d = c.column_default != null ? c.column_default : c.default_value; return d == null ? '' : String(d); }
  function isAutoCol(c) { return !!(AUTO_COLS[c.name] || c.is_primary_key || c.is_identity || c.is_generated || /nextval\(|gen_random_uuid\(|uuid_generate/i.test(defaultOf(c))); }
  // A column default the form can show: 'todo'::text, 42, -1.5, true.
  // Anything else (now(), CURRENT_DATE, a function) is not a value we can
  // prefill, so returns undefined.
  function literalDefault(d, type) {
    var m = /^'((?:[^']|'')*)'(?:::([\w ]+)(\[\])?)?$/.exec(d);
    var v;
    if (m && m[3]) {
      // An array cast: '{}' / '{a, b}' / '{1,2}' becomes a JSON list (the
      // param binds a JSON list string). Postgres trims unquoted elements,
      // reads NULL as null, and a numeric element type gives numbers;
      // quoted or nested elements are not prefilled.
      var body = m[1].replace(/''/g, "'");
      if (!/^\{[^{}"\\]*\}$/.test(body)) return undefined;
      var inner = body.slice(1, -1).replace(/^\s+|\s+$/g, '');
      if (!inner) return [];
      var numeric = /^(int[248]?|integer|bigint|smallint|numeric|decimal|real|float[48]?|double precision)$/i.test(m[2].replace(/^\s+|\s+$/g, ''));
      var out = [], parts = inner.split(',');
      for (var i = 0; i < parts.length; i++) {
        var el = parts[i].replace(/^\s+|\s+$/g, '');
        if (!el) return undefined;
        if (/^null$/i.test(el)) { out.push(null); continue; }
        if (numeric) { var num = Number(el); if (!isFinite(num)) return undefined; out.push(num); }
        else out.push(el);
      }
      return out;
    }
    if (m) v = m[1].replace(/''/g, "'");
    else if (/^\(?-?\d+(?:\.\d+)?\)?(?:::[\w ]+)?$/.test(d)) v = d.replace(/[()]|::.*$/g, '');
    else if (/^(true|false)$/i.test(d)) v = d.toLowerCase();
    else return undefined;
    if (type === 'checkbox') return v === 'true' || v === 't';
    if (type === 'integer' || type === 'number') { var n = Number(v); return isFinite(n) ? n : undefined; }
    return v;
  }
  function colToField(c) {
    var f = { key: c.name, type: fieldTypeOf(c.type), pgType: c.type };
    var notNull = c.not_null === true || c.nullable === false;
    var d = defaultOf(c);
    var lit = d ? literalDefault(d, f.type) : undefined;
    if (lit !== undefined) f['default'] = lit;
    // DEFAULT '': a blank must submit '' (null would break NOT NULL).
    if (lit === '') f.blankAsEmpty = true;
    // A blank submits null, which overrides a column default: a NOT NULL
    // column whose default cannot be prefilled must be filled in.
    if (notNull && f.type !== 'checkbox' && lit === undefined) f.required = true;
    return f;
  }
  // gsDash.schemaFields('tasks', { skip?: ['owner'], all?: false })
  //   -> Promise<field[]> from agentdb.getSchema(). Skips the primary key,
  //   id / created_at / updated_at and serial or uuid-defaulted columns unless
  //   all: true; NOT NULL columns with no default come back required when the
  //   host reports not_null.
  function schemaFields(table, opts) {
    opts = opts || {};
    return getSchemaOnce().then(function (schema) {
      var t = findTable(schema, table);
      if (!t) throw new Error('gsDash.schemaFields: table "' + table + '" not found in getSchema()');
      var skip = {};
      (opts.skip || []).forEach(function (k) { skip[k] = 1; });
      return (t.columns || []).filter(function (c) {
        if (skip[c.name]) return false;
        return opts.all || !isAutoCol(c);
      }).map(colToField);
    });
  }
  // fields: undefined (every schema column), or a list of keys and/or field
  // objects; an object overrides the schema's guess for its key. When the
  // schema cannot be read (a shared dashboard refuses getSchema) and fields
  // are listed, they render with the types given (text by default) instead
  // of failing the whole block.
  function resolveFields(spec, table) {
    function merge(byKey) {
      if (!spec) {
        var all = [];
        for (var k in byKey) if (hasOwn(byKey, k)) all.push(byKey[k]);
        return all;
      }
      return spec.map(function (s) {
        var key = typeof s === 'string' ? s : s.key;
        var base = byKey[key] || { key: key, type: 'text' };
        return typeof s === 'string' ? assign({}, base) : assign({}, base, s);
      });
    }
    if (!table) return Promise.resolve(merge({}));
    return getSchemaOnce().then(function (schema) {
      var t = findTable(schema, table);
      if (!t) throw new Error('table "' + table + '" not found in getSchema()');
      var byKey = {};
      (t.columns || []).forEach(function (c) {
        if (!spec && isAutoCol(c)) return;
        byKey[c.name] = colToField(c);
      });
      return merge(byKey);
    }, function (err) {
      if (!spec) throw err;
      try { console.warn('[gsDash] getSchema unavailable (' + errText(err) + '); using the listed fields as given'); } catch (e) {}
      return merge({});
    });
  }

  function pad2(n) { return (n < 10 ? '0' : '') + n; }
  function toInputValue(f, v) {
    if (v == null) return '';
    var t = f.type;
    if (t === 'date') return String(v).slice(0, 10);
    if (t === 'datetime') {
      var s = String(v);
      // An offset-carrying instant shows in the viewer's local time; a naive
      // value is shown as stored.
      if (/(z|[+-]\d\d:?\d\d)$/i.test(s)) {
        var d = new Date(s);
        if (!isNaN(d.getTime())) {
          return d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate())
            + 'T' + pad2(d.getHours()) + ':' + pad2(d.getMinutes());
        }
      }
      return s.replace(' ', 'T').slice(0, 16);
    }
    if (t === 'json') return typeof v === 'string' ? v : JSON.stringify(v, null, 2);
    if (typeof v === 'object') return JSON.stringify(v);
    return String(v);
  }
  // Display types that hold numbers: edited and parsed as numbers everywhere
  // (form, editTable, importer), shown formatted by cellOf.
  var NUM_TYPES = { number: 1, integer: 1, money: 1, pct: 1, ratio: 1, delta: 1, bar: 1 };
  var FORMATTED = { money: 1, pct: 1, ratio: 1, delta: 1, bar: 1, relative: 1 };
  // Raw control value → { value, error }. Empty → null.
  function parseField(f, raw) {
    var t = f.type || 'text';
    if (t === 'checkbox') return { value: !!raw && raw !== 'false', error: null };
    var s = String(raw == null ? '' : raw);
    if (/^\s*$/.test(s)) return { value: f.blankAsEmpty ? '' : null, error: f.required ? 'Required' : null };
    var v = t === 'textarea' || t === 'json' ? s : s.replace(/^\s+|\s+$/g, ''), err = null;
    if (NUM_TYPES[t]) {
      var n = Number(v);
      if (!isFinite(n)) err = 'Enter a number';
      else if (t === 'integer' && Math.floor(n) !== n) err = 'Enter a whole number';
      else {
        v = n;
        if (f.min != null && n < Number(f.min)) err = 'Must be at least ' + f.min;
        else if (f.max != null && n > Number(f.max)) err = 'Must be at most ' + f.max;
      }
    } else if (t === 'json') {
      try { JSON.parse(v); } catch (e) { err = 'Invalid JSON'; }
    } else if (t === 'email' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)) {
      err = 'Enter a valid email';
    } else if (t === 'select' && f.options && f.strict !== false) {
      var ok = false;
      f.options.forEach(function (o) { if (String(optValue(o)) === v) ok = true; });
      if (!ok) err = 'Pick one of the options';
    }
    if (!err && f.pattern) {
      var re = f.pattern instanceof RegExp ? new RegExp(f.pattern.source, f.pattern.flags.replace('g', '')) : new RegExp('^(?:' + f.pattern + ')$');
      if (!re.test(String(v))) err = f.patternMessage || 'Invalid format';
    }
    if (!err && f.maxLength && String(v).length > f.maxLength) err = 'At most ' + f.maxLength + ' characters';
    return { value: v, error: err };
  }
  var INPUT_TYPE = { integer: 'number', number: 'number', money: 'number', pct: 'number', ratio: 'number', delta: 'number', bar: 'number', date: 'date', datetime: 'datetime-local', time: 'time', email: 'email', url: 'url', tel: 'tel' };
  function makeControl(f, id) {
    var t = f.type || 'text', c;
    if (t === 'select') {
      c = mk('select', 'input gs-f-ctl');
      var blank = mk('option', null, f.placeholder || '—');
      blank.value = '';
      c.appendChild(blank);
      (f.options || []).forEach(function (o) {
        var op = mk('option', null, String(optLabel(o)));
        op.value = String(optValue(o));
        c.appendChild(op);
      });
    } else if (t === 'textarea' || t === 'json') {
      c = mk('textarea', 'input gs-f-ctl gs-f-ta');
      c.rows = f.rows || (t === 'json' ? 4 : 3);
    } else if (t === 'checkbox') {
      c = mk('input', 'gs-f-check');
      c.type = 'checkbox';
    } else {
      c = mk('input', 'input gs-f-ctl');
      c.type = INPUT_TYPE[t] || 'text';
      if (t === 'integer') c.step = '1';
      if (NUM_TYPES[t] && t !== 'integer') c.step = f.step || 'any';
      if (f.min != null) c.min = String(f.min);
      if (f.max != null) c.max = String(f.max);
    }
    if (f.placeholder && t !== 'select') c.placeholder = f.placeholder;
    if (id) c.id = id;
    c.name = f.key;
    if (f.readOnly) c.disabled = true;
    return c;
  }
  function setControl(f, c, v) {
    if (f.type === 'checkbox') c.checked = !!v && v !== 'false';
    else c.value = toInputValue(f, v);
    // What the control started from: an untouched datetime must save the
    // stored value verbatim (the input shows it in local time, to the minute).
    c.__gsInit = { raw: c.value, value: v };
  }
  var TZ_SUFFIX = /(z|[+-]\d\d:?\d\d)$/i;
  function readControl(f, c) { return f.type === 'checkbox' ? c.checked : c.value; }
  // A number input sanitizes junk ("12abc") to '' — without this it would
  // save as an empty value instead of being rejected.
  function readField(f, c) {
    if (c.validity && c.validity.badInput) return { value: null, error: NUM_TYPES[f.type] ? 'Enter a number' : 'Invalid value' };
    var init = c.__gsInit;
    // Only a stored value: an empty one still goes through parseField's required check.
    if (f.type === 'datetime' && init && init.value != null && c.value === init.raw) return { value: init.value, error: null };
    var r = parseField(f, readControl(f, c));
    // A datetime-local value is the viewer's wall clock. For a column that
    // stores an instant (timestamptz, or a value that came back with an
    // offset) send it as an absolute ISO time, not as a naive string the
    // server would read as UTC.
    if (f.type === 'datetime' && !r.error && r.value != null) {
      var aware = /with time zone|timestamptz/i.test(String(f.pgType || '')) || (init && init.value != null && TZ_SUFFIX.test(String(init.value)));
      var d = new Date(r.value);
      if (aware && !isNaN(d.getTime())) r.value = d.toISOString();
    }
    return r;
  }
  // Read-only display text for a value of field f.
  function displayText(f, v) {
    if (v == null || v === '') return '—';
    if (f.type === 'checkbox' || typeof v === 'boolean') return v && v !== 'false' ? 'Yes' : 'No';
    if (f.type === 'select' && f.options) {
      for (var i = 0; i < f.options.length; i++) if (String(optValue(f.options[i])) === String(v)) return String(optLabel(f.options[i]));
    }
    if (typeof v === 'object') return JSON.stringify(v);
    return String(v);
  }
  function cellHtmlOf(f, row) {
    if (typeof f.render === 'function') return String(f.render(row));
    // money / pct / ratio / delta / bar / relative render the same in every block.
    if (FORMATTED[f.type] && typeof f.format !== 'function' && !f.badge) return cellOf(f, row);
    var v = row[f.key];
    if (typeof f.format === 'function') return esc(f.format(v, row));
    if (f.badge && v != null && v !== '') return tag(humanize(v), statusTone(v));
    return esc(displayText(f, v));
  }

  // gsDash.form(el, {
  //   table?: 'tasks',                 // field types / required from agentdb.getSchema()
  //   fields?: ['title', { key: 'status', type: 'select', options: ['open', 'done'] }, 'due'],
  //                                    // type: text|textarea|number|integer|date|datetime|time|
  //                                    //   select|checkbox|email|json; required, min, max,
  //                                    //   pattern, maxLength, placeholder, help, default,
  //                                    //   readOnly, hidden, full, validate(value, values) -> msg|null
  //   record?: row,                    // edit mode (prefilled); omit → add mode
  //   submit: 'save_task' | { add: 'insert_task', edit: 'update_task' }
  //           | function (values, mode, record) -> Promise,
  //   params?: function (values, mode, record) -> object,
  //                                    // default: edit → { ...record, ...values }, add → values
  //   onSaved?: function (result, values, mode) {}, cancel?: function () {},
  //   title?, submitLabel?, columns?: 1|2, resetOnAdd?: true,
  // }) -> { ready: Promise, values(), validate(), setRecord(row|null), reset(), submit(), destroy() }
  function form(el, opts) {
    el = elOf(el, 'form');
    opts = opts || {};
    if (!opts.submit) throw new Error('gsDash.form: submit is required (a named query or a function)');
    var record = opts.record || null;
    var fields = [], ctls = {}, wraps = {}, errs = {}, busy = false, destroyed = false, built = false;
    var idp = 'gsf' + (++_uid) + '-';
    var root = mk('form', 'gs-form' + (opts.columns === 2 ? ' gs-form-2' : ''));
    // Typed but not submitted: a data-change refresh must not re-render it.
    var touched = false;
    root.__gsDirty = function () { return touched || busy; };
    root.addEventListener('input', function () { touched = true; });
    root.addEventListener('change', function () { touched = true; });
    root.setAttribute('novalidate', '');
    root.id = idp + 'form';
    var grid, formErr, submitBtn;
    el.innerHTML = '';
    el.appendChild(root);

    function build() {
      root.innerHTML = '';
      if (opts.title) root.appendChild(mk('div', 't-h3 gs-form-title', opts.title));
      grid = mk('div', 'gs-form-grid');
      fields.forEach(function (f) {
        if (f.hidden) return;
        var cb = f.type === 'checkbox';
        var full = f.full || f.type === 'textarea' || f.type === 'json';
        var w = mk('div', 'gs-f' + (cb ? ' gs-f-cb' : '') + (full ? ' gs-f-full' : ''));
        w.setAttribute('data-field', f.key);
        var c = makeControl(f, idp + f.key);
        var lab = mk('label', 'gs-f-label', labelOf(f));
        lab.htmlFor = c.id;
        if (f.required) lab.appendChild(mk('span', 'gs-f-req', ' *'));
        var er = mk('div', 'gs-f-err');
        er.id = c.id + '-err';
        c.setAttribute('aria-describedby', er.id);
        if (cb) { var row = mk('div', 'gs-f-cbrow'); row.appendChild(c); row.appendChild(lab); w.appendChild(row); }
        else { w.appendChild(lab); w.appendChild(c); }
        if (f.help) w.appendChild(mk('div', 'gs-f-help', f.help));
        w.appendChild(er);
        c.addEventListener(cb || f.type === 'select' ? 'change' : 'input', function () { clearErr(f.key); });
        ctls[f.key] = c; wraps[f.key] = w; errs[f.key] = er;
        grid.appendChild(w);
      });
      root.appendChild(grid);
      formErr = mk('div', 'gs-f-formerr');
      formErr.setAttribute('role', 'alert');
      formErr.hidden = true;
      root.appendChild(formErr);
      var bar = mk('div', 'gs-form-actions');
      submitBtn = mk('button', 'btn btn-primary');
      submitBtn.type = 'submit';
      // formDialog moves this row outside <form>; the form attribute keeps it submitting.
      submitBtn.setAttribute('form', root.id);
      bar.appendChild(submitBtn);
      if (typeof opts.cancel === 'function') bar.appendChild(button(opts.cancelLabel || 'Cancel', 'secondary', function () { opts.cancel(); }));
      root.appendChild(bar);
      built = true;
      fill();
    }
    function mode() { return record ? 'edit' : 'add'; }
    function fill() {
      if (!built) return;
      touched = false;
      submitBtn.textContent = opts.submitLabel || (record ? 'Save changes' : 'Add');
      fields.forEach(function (f) {
        var c = ctls[f.key];
        if (!c) return;
        var v = record ? record[f.key] : f['default'];
        setControl(f, c, v);
        clearErr(f.key);
      });
      formErr.hidden = true;
    }
    function clearErr(k) {
      if (!errs[k]) return;
      errs[k].textContent = '';
      wraps[k].className = wraps[k].className.replace(/\s*gs-f-invalid/g, '');
      ctls[k].removeAttribute('aria-invalid');
    }
    function collect() {
      var out = {}, errors = {}, any = false;
      fields.forEach(function (f) {
        var c = ctls[f.key];
        if (!c || f.readOnly) {
          var pv = record && hasOwn(record, f.key) ? record[f.key] : f['default'];
          if (pv !== undefined) out[f.key] = pv;
          return;
        }
        var r = readField(f, c);
        out[f.key] = r.value;
        if (r.error) { errors[f.key] = r.error; any = true; }
      });
      fields.forEach(function (f) {
        if (errors[f.key] || !ctls[f.key] || f.readOnly || typeof f.validate !== 'function') return;
        var m = f.validate(out[f.key], out);
        if (m) { errors[f.key] = String(m); any = true; }
      });
      return { values: out, errors: any ? errors : null };
    }
    function showErrors(errors) {
      var first = null;
      fields.forEach(function (f) {
        if (!errors[f.key] || !errs[f.key]) return;
        errs[f.key].textContent = errors[f.key];
        wraps[f.key].className += ' gs-f-invalid';
        ctls[f.key].setAttribute('aria-invalid', 'true');
        if (!first) first = ctls[f.key];
      });
      if (first) try { first.focus(); } catch (e) {}
    }
    function clearAll() { for (var k in errs) if (hasOwn(errs, k)) clearErr(k); if (formErr) formErr.hidden = true; }
    function callSubmit(values, m) {
      var s = opts.submit;
      if (typeof s === 'function') return s(values, m, record);
      var name = typeof s === 'string' ? s : (s && s[m]);
      if (!name) throw new Error('gsDash.form: submit has no "' + m + '" query');
      var params = typeof opts.params === 'function'
        ? opts.params(values, m, record)
        : (m === 'edit' ? assign({}, record, values) : values);
      return runQuery(name, params);
    }
    function submit() {
      if (!built || busy || destroyed) return Promise.resolve(null);
      clearAll();
      var c = collect();
      if (c.errors) { showErrors(c.errors); return Promise.resolve(null); }
      var m = mode(), values = c.values, label = submitBtn.textContent;
      busy = true;
      submitBtn.disabled = true;
      submitBtn.textContent = 'Saving…';
      var p;
      try { p = Promise.resolve(callSubmit(values, m)); } catch (e) { p = Promise.reject(e); }
      return p.then(function (res) {
        busy = false;
        if (destroyed) return res;
        submitBtn.disabled = false;
        submitBtn.textContent = label;
        touched = false;
        var saved = assign({}, m === 'edit' ? record : null, values, firstRow(res));
        if (m === 'edit') record = saved;
        else if (opts.resetOnAdd !== false) fill();
        dataChanged({ source: 'form', kind: m === 'edit' ? 'edit' : 'add', row: saved, table: opts.table, el: root });
        if (typeof opts.onSaved === 'function') opts.onSaved(res, values, m);
        return res;
      }, function (err) {
        busy = false;
        logErr('form', err);
        if (destroyed) return null;
        submitBtn.disabled = false;
        submitBtn.textContent = label;
        formErr.textContent = 'Could not save: ' + errText(err);
        formErr.hidden = false;
        return null;
      });
    }
    root.addEventListener('submit', function (e) { e.preventDefault(); submit(); });

    var handle = {
      el: root,
      ready: null,
      values: function () { return built ? collect().values : {}; },
      validate: function () { if (!built) return false; clearAll(); var c = collect(); if (c.errors) showErrors(c.errors); return !c.errors; },
      setRecord: function (rec) { record = rec || null; fill(); },
      reset: function () { fill(); },
      isBusy: function () { return busy; },
      submit: submit,
      destroy: function () { destroyed = true; if (root.parentNode) root.parentNode.removeChild(root); },
    };
    if (opts.table) {
      root.innerHTML = '<div class="gs-sec-loading">Loading…</div>';
      handle.ready = resolveFields(opts.fields, opts.table).then(function (fs) {
        if (destroyed) return handle;
        fields = fs;
        build();
        return handle;
      }, function (err) {
        logErr('form', err);
        root.innerHTML = '';
        root.appendChild(mk('div', 'gs-sec-error', 'Could not load the form: ' + errText(err)));
        return handle;
      });
    } else {
      fields = (opts.fields || []).map(function (s) { return typeof s === 'string' ? { key: s, type: 'text' } : assign({}, s); });
      if (!fields.length) throw new Error('gsDash.form: fields (or table) is required');
      build();
      handle.ready = Promise.resolve(handle);
    }
    return handle;
  }

  // gsDash.filterBar(el, {
  //   search?: true | { placeholder },
  //   chips?: { options: ['open', { value: 'done', label: 'Done' }], all?: 'All', value? },
  //   dateRange?: true | { label },
  //   onChange: function (state) {},   // state = { q, chip, from, to } (chip null = all)
  // }) -> { el, value(), set(partial), setChips(options), destroy() }
  function filterBar(el, opts) {
    el = elOf(el, 'filterBar');
    opts = opts || {};
    var state = { q: '', chip: null, from: '', to: '' };
    var chipCfg = opts.chips || null, timer = null;
    if (chipCfg && chipCfg.value != null) state.chip = chipCfg.value;
    var root = mk('div', 'gs-fbar');
    var qIn = null, fromIn = null, toIn = null, chipBox = null;
    function emit() { if (typeof opts.onChange === 'function') opts.onChange(assign({}, state)); }
    if (opts.search) {
      qIn = mk('input', 'input gs-fbar-q');
      qIn.type = 'search';
      qIn.placeholder = (isPlain(opts.search) && opts.search.placeholder) || T('search');
      qIn.setAttribute('aria-label', T('search'));
      qIn.addEventListener('input', function () {
        state.q = qIn.value;
        if (timer) clearTimeout(timer);
        var wait = opts.debounce == null ? 150 : opts.debounce;
        if (!wait) { emit(); return; }
        timer = setTimeout(function () { timer = null; emit(); }, wait);
      });
      root.appendChild(qIn);
    }
    if (chipCfg) {
      chipBox = mk('div', 'gs-fbar-chips');
      chipBox.setAttribute('role', 'group');
      root.appendChild(chipBox);
    }
    function renderChips(options) {
      if (!chipBox) return;
      chipBox.innerHTML = '';
      var list = [{ value: null, label: chipCfg.all || T('all') }].concat(options || []);
      list.forEach(function (o) {
        var v = optValue(o), on = v == null ? state.chip == null : String(state.chip) === String(v);
        var b = mk('button', 'pill gs-chip' + (on ? ' pill-active' : ''), humanize(optLabel(o)));
        b.type = 'button';
        b.setAttribute('aria-pressed', on ? 'true' : 'false');
        b.setAttribute('data-value', v == null ? '' : String(v));
        b.onclick = function () { state.chip = v == null ? null : v; renderChips(options); emit(); };
        chipBox.appendChild(b);
      });
      chipCfg._options = options;
    }
    if (chipCfg) renderChips(chipCfg.options || []);
    if (opts.dateRange) {
      var dr = mk('div', 'gs-fbar-dates');
      if (isPlain(opts.dateRange) && opts.dateRange.label) dr.appendChild(mk('span', 't-small', opts.dateRange.label));
      fromIn = mk('input', 'input gs-fbar-date'); fromIn.type = 'date'; fromIn.setAttribute('aria-label', 'From');
      toIn = mk('input', 'input gs-fbar-date'); toIn.type = 'date'; toIn.setAttribute('aria-label', 'To');
      var preset = null, presets = isPlain(opts.dateRange) && isArr(opts.dateRange.presets) ? opts.dateRange.presets : null;
      if (presets) {
        // ['7d','30d','90d','mtd','qtd','ytd','all'] → a select that fills the two dates.
        preset = mk('select', 'input gs-fbar-preset');
        preset.setAttribute('aria-label', T('pcustom'));
        presets.concat(['custom']).forEach(function (p) {
          var op = mk('option', null, T('p' + p) !== 'p' + p ? T('p' + p) : String(p));
          op.value = p;
          preset.appendChild(op);
        });
        preset.value = opts.dateRange.preset || 'custom';
        preset.onchange = function () {
          if (preset.value === 'custom') return;
          var r = presetRange(preset.value);
          state.from = fromIn.value = r.from; state.to = toIn.value = r.to;
          emit();
        };
        dr.appendChild(preset);
      }
      fromIn.onchange = function () { state.from = fromIn.value; if (preset) preset.value = 'custom'; emit(); };
      toIn.onchange = function () { state.to = toIn.value; if (preset) preset.value = 'custom'; emit(); };
      dr.appendChild(fromIn); dr.appendChild(mk('span', 't-small', '–')); dr.appendChild(toIn);
      if (preset && preset.value !== 'custom') { var r0 = presetRange(preset.value); state.from = fromIn.value = r0.from; state.to = toIn.value = r0.to; }
      root.appendChild(dr);
    }
    el.appendChild(root);
    return {
      el: root,
      value: function () { return assign({}, state); },
      set: function (p) {
        assign(state, p || {});
        if (qIn) qIn.value = state.q || '';
        if (fromIn) fromIn.value = state.from || '';
        if (toIn) toIn.value = state.to || '';
        if (chipCfg) renderChips(chipCfg._options);
        emit();
      },
      setChips: function (options) {
        if (!chipCfg) return;
        var keep = false;
        (options || []).forEach(function (o) { if (String(optValue(o)) === String(state.chip)) keep = true; });
        if (state.chip != null && !keep) { state.chip = null; renderChips(options); emit(); return; }
        renderChips(options);
      },
      destroy: function () { if (timer) clearTimeout(timer); if (root.parentNode) root.parentNode.removeChild(root); },
    };
  }
  // state from filterBar; cfg = { searchKeys?, chipKey?, dateKey? }.
  function rowMatches(row, st, cfg) {
    var q = lc(st.q).replace(/^\s+|\s+$/g, '');
    if (q) {
      var keys = cfg.searchKeys || Object.keys(row), hit = false;
      for (var i = 0; i < keys.length && !hit; i++) {
        var v = row[keys[i]];
        if (v != null && typeof v !== 'object' && lc(v).indexOf(q) >= 0) hit = true;
      }
      if (!hit) return false;
    }
    if (st.chip != null && cfg.chipKey && String(row[cfg.chipKey]) !== String(st.chip)) return false;
    if ((st.from || st.to) && cfg.dateKey) {
      var d = String(row[cfg.dateKey] == null ? '' : row[cfg.dateKey]).slice(0, 10);
      if (!d) return false;
      if (st.from && d < st.from) return false;
      if (st.to && d > st.to) return false;
    }
    return true;
  }
  function distinctOptions(rows, key) {
    var seen = {}, out = [];
    rows.forEach(function (r) {
      var v = r[key];
      if (v == null || v === '' || seen['$' + v]) return;
      seen['$' + v] = 1;
      out.push(v);
    });
    return out.sort();
  }
  function sameValue(a, b) {
    var an = a == null || a === '', bn = b == null || b === '';
    if (an || bn) return an && bn;
    if (typeof a === 'object' || typeof b === 'object') return JSON.stringify(a) === JSON.stringify(b);
    return String(a) === String(b);
  }
  function cmpVals(a, b) {
    var an = a == null || a === '', bn = b == null || b === '';
    if (an || bn) return an && bn ? 0 : (an ? 1 : -1);
    if (typeof a === 'number' && typeof b === 'number') return a - b;
    if (typeof a === 'boolean' || typeof b === 'boolean') return (a ? 1 : 0) - (b ? 1 : 0);
    return String(a).localeCompare(String(b), undefined, { numeric: true, sensitivity: 'base' });
  }
  // Shared loader for rows | query | fetchPage. load(true) restarts,
  // load(false) pulls the next fetchPage page. Resolves { rows, more }.
  function rowSource(opts) {
    var cursor = null, more = false;
    return {
      hasMore: function () { return more; },
      load: function (restart) {
        if (restart) { cursor = null; more = false; }
        if (typeof opts.fetchPage === 'function') {
          var p;
          try { p = Promise.resolve(opts.fetchPage(cursor)); } catch (e) { p = Promise.reject(e); }
          return p.then(function (page) {
            var rows = isArr(page) ? page : ((page && page.rows) || []);
            cursor = isArr(page) || page == null ? null : page.nextCursor;
            more = cursor != null && rows.length > 0;
            return rows;
          });
        }
        if (opts.query) {
          var params = typeof opts.params === 'function' ? opts.params() : (opts.params || {});
          return runQuery(opts.query, params, true).then(function (r) { return (r && r.rows) || []; });
        }
        return Promise.resolve((opts.rows || []).slice());
      },
    };
  }
  function writeVia(spec, row, extra, who) {
    if (typeof spec === 'function') return Promise.resolve().then(function () { return spec(row, extra); });
    if (typeof spec === 'string') return runQuery(spec, row);
    return Promise.reject(new Error('gsDash.' + who + ': no write configured'));
  }

  // gsDash.editTable(el, {
  //   columns: ['name', { key: 'status', type: 'select', options: [...], badge: true }, ...],
  //                               // same field shape as gsDash.form, plus width, align,
  //                               // editable (default true), render(row) -> html, format(v,row)
  //   table?: 'tasks',            // column types from agentdb.getSchema()
  //   rows? | query?: 'load_tasks', params? | fetchPage?(cursor) -> Promise<{ rows, nextCursor }>,
  //   idKey?: 'id',
  //   onSave?: 'update_task' | function (row, changes) -> Promise,  // Save = every edited row
  //   onAdd?: 'insert_task' | function (row) -> Promise,            // enables "Add row"
  //   onDelete?: 'delete_task' | function (row) -> Promise,         // enables row delete
  //   search?: true, chips?: { key, options?, all? }, pageSize?: 50, maxHeight?: '560px',
  //   confirmDelete?: true, empty?, autoRefresh?: true,
  //   onSaved?: function ({ saved, failed, kind, row, changes }) {},
  //     // after every successful write: a Save (kind 'add' | 'edit' |
  //     // 'mixed') and a delete (kind 'delete', row = the deleted row);
  //     // changes = [{ kind, row }]. The same write is announced as
  //     // gsdash:data-changed, so kit cards / charts / tables re-run anyway.
  // }) -> { ready, rows(), dirty(), save(), discard(), refresh(), destroy() }
  // Named-query writes receive the whole row (original values + edits) as
  // params; the add/update query's RETURNING row is merged back (new ids).
  function editTable(el, opts) {
    el = elOf(el, 'editTable');
    opts = opts || {};
    if (!opts.columns || !opts.columns.length) throw new Error('gsDash.editTable: columns is required');
    var idKey = opts.idKey || 'id', pageSize = opts.pageSize || 50;
    var cols = [], items = [], seq = 0, shown = pageSize, sort = { key: null, dir: 1 };
    var filt = { q: '', chip: null, from: '', to: '' }, busy = false, destroyed = false, loading = false, msg = '';
    var src = rowSource(opts), editing = null;
    var chipKey = opts.chips && opts.chips.key;

    var root = mk('div', 'gs-et');
    root.__gsDirty = function () { return busy || !!editing || dirtyItems().length > 0; };
    var tools = mk('div', 'gs-et-tools');
    var scroller = mk('div', 'gs-et-scroll');
    if (opts.maxHeight) scroller.style.maxHeight = typeof opts.maxHeight === 'number' ? opts.maxHeight + 'px' : opts.maxHeight;
    var table = mk('table', 'gs-et-table');
    var thead = mk('thead'), tbody = mk('tbody');
    table.appendChild(thead); table.appendChild(tbody);
    scroller.appendChild(table);
    var foot = mk('div', 'gs-et-foot');
    var status = mk('span', 'gs-et-status t-small');
    status.setAttribute('aria-live', 'polite');
    var moreBtn = button('Show more', 'ghost', function () { showMore(); });
    var discardBtn = button('Discard', 'secondary', function () { discard(); });
    var saveBtn = button('Save', 'primary', function () { save(); });
    foot.appendChild(status); foot.appendChild(moreBtn);
    var spacer = mk('span', 'gs-et-spacer');
    foot.appendChild(spacer);
    if (opts.onSave || opts.onAdd) { foot.appendChild(discardBtn); foot.appendChild(saveBtn); }
    root.appendChild(tools); root.appendChild(scroller); root.appendChild(foot);
    el.innerHTML = '';
    el.appendChild(root);

    var bar = null;
    if (opts.search !== false || opts.chips) {
      var fb = mk('div', 'gs-et-fb');
      tools.appendChild(fb);
      bar = filterBar(fb, {
        search: opts.search !== false,
        chips: opts.chips ? { options: opts.chips.options || [], all: opts.chips.all } : null,
        debounce: opts.debounce,
        onChange: function (st) { filt = st; shown = pageSize; renderBody(); },
      });
    }
    if (opts.onAdd) tools.appendChild(button(opts.addLabel || '+ Add row', 'secondary', function () { addRow(); }));

    function wrap(row, isNew) { return { k: ++seq, row: assign({}, row), orig: isNew ? null : assign({}, row), changes: {}, isNew: !!isNew, error: null }; }
    function isDirty(it) { if (it.isNew) return true; for (var k in it.changes) if (hasOwn(it.changes, k)) return true; return false; }
    function dirtyItems() { return items.filter(isDirty); }
    function colOf(key) { for (var i = 0; i < cols.length; i++) if (cols[i].key === key) return cols[i]; return null; }
    function editable(c, it) { return c.editable !== false && c.key !== idKey && typeof c.render !== 'function' && !!(it && it.isNew ? opts.onAdd : opts.onSave); }
    function itemByK(k) { for (var i = 0; i < items.length; i++) if (items[i].k === k) return items[i]; return null; }

    function renderHead() {
      var tr = mk('tr');
      cols.forEach(function (c) {
        var th = mk('th', 'gs-et-th' + (c.align === 'right' ? ' ta-r' : ''));
        if (c.width) th.style.width = typeof c.width === 'number' ? c.width + 'px' : c.width;
        var b = mk('button', 'gs-et-sort', labelOf(c));
        b.type = 'button';
        var on = sort.key === c.key;
        th.setAttribute('aria-sort', on ? (sort.dir > 0 ? 'ascending' : 'descending') : 'none');
        if (on) b.appendChild(mk('span', 'gs-et-arrow', sort.dir > 0 ? ' ▲' : ' ▼'));
        b.onclick = function () {
          if (sort.key !== c.key) sort = { key: c.key, dir: 1 };
          else if (sort.dir > 0) sort.dir = -1;
          else sort = { key: null, dir: 1 };
          renderHead(); renderBody();
        };
        th.appendChild(b);
        tr.appendChild(th);
      });
      if (opts.onDelete) tr.appendChild(mk('th', 'gs-et-th gs-et-actcol'));
      thead.innerHTML = '';
      thead.appendChild(tr);
    }
    function visible() {
      var fresh = [], rest = [];
      items.forEach(function (it) {
        if (it.isNew) { fresh.push(it); return; }   // new rows stay on top, unfiltered
        if (rowMatches(it.row, filt, { searchKeys: cols.map(function (c) { return c.key; }), chipKey: chipKey })) rest.push(it);
      });
      if (sort.key) {
        var key = sort.key, dir = sort.dir;
        rest.sort(function (a, b) { return dir * cmpVals(a.row[key], b.row[key]); });
      }
      return fresh.concat(rest);
    }
    function tdClass(it, c) {
      var dirty = it.isNew ? it.row[c.key] != null : hasOwn(it.changes, c.key);
      return 'gs-et-td' + (c.align === 'right' ? ' num ta-r' : '') + (editable(c, it) ? ' gs-et-ed' : '') + (dirty ? ' gs-et-dirty' : '');
    }
    function renderBody() {
      if (destroyed) return;
      editing = null;
      var vis = visible(), n = Math.min(vis.length, shown), html = '';
      for (var i = 0; i < n; i++) {
        var it = vis[i];
        html += '<tr class="gs-et-row' + (it.isNew ? ' gs-et-new' : '') + (it.error ? ' gs-et-rowerr' : '') + '" data-k="' + it.k + '"'
          + (it.error ? ' title="' + escAttr(it.error) + '"' : '') + '>';
        for (var j = 0; j < cols.length; j++) {
          var c = cols[j], ed = editable(c, it);
          html += '<td class="' + tdClass(it, c) + '" data-c="' + escAttr(c.key) + '"' + (ed ? ' tabindex="0"' : '') + '>' + cellHtmlOf(c, it.row) + '</td>';
        }
        if (opts.onDelete) html += '<td class="gs-et-td gs-et-actcol"><button type="button" class="btn btn-ghost btn-sm gs-et-del" aria-label="Delete row">✕</button></td>';
        html += '</tr>';
      }
      if (!n) {
        html = '<tr><td class="gs-et-empty" colspan="' + (cols.length + (opts.onDelete ? 1 : 0)) + '">'
          + esc(loading ? 'Loading…' : (items.length ? 'No matching rows' : (opts.empty || 'No rows yet'))) + '</td></tr>';
      }
      tbody.innerHTML = html;
      renderFoot(vis, n);
    }
    function renderFoot(vis, n) {
      if (!vis) { vis = visible(); n = Math.min(vis.length, shown); }
      var dirtyN = dirtyItems().length;
      var txt = vis.length + (vis.length === 1 ? ' row' : ' rows') + (src.hasMore() ? ' loaded' : '');
      if (dirtyN) txt += ' · ' + dirtyN + ' unsaved';
      if (msg) txt += ' · ' + msg;
      status.textContent = txt;
      moreBtn.style.display = vis.length > n || src.hasMore() ? '' : 'none';
      saveBtn.disabled = busy || !dirtyN;
      discardBtn.disabled = busy || !dirtyN;
      saveBtn.textContent = busy ? 'Saving…' : (dirtyN ? 'Save ' + dirtyN : 'Save');
    }
    function showMore() {
      var vis = visible();
      if (vis.length > shown) { shown += pageSize; renderBody(); return; }
      if (!src.hasMore() || loading) return;
      loading = true;
      src.load(false).then(function (rows) {
        loading = false;
        if (destroyed) return;
        rows.forEach(function (r) { items.push(wrap(r)); });
        shown += pageSize;
        syncChips();
        renderBody();
      }, function (err) { loading = false; msg = 'Load failed: ' + errText(err); logErr('editTable', err); renderBody(); });
    }
    function startEdit(td) {
      var tr = td.parentNode, it = itemByK(Number(tr.getAttribute('data-k'))), c = colOf(td.getAttribute('data-c'));
      if (!it || !c || !editable(c, it) || busy) return;
      if (editing) commit(true);
      var ctl = makeControl(c, null);
      ctl.className += ' gs-et-input';
      setControl(c, ctl, it.row[c.key]);
      td.innerHTML = '';
      td.appendChild(ctl);
      editing = { it: it, c: c, ctl: ctl, td: td };
      var done = false;
      function finish(keep) { if (done) return; done = true; commit(keep); }
      ctl.addEventListener('keydown', function (e) {
        if (e.key === 'Enter' && c.type !== 'textarea' && c.type !== 'json') { e.preventDefault(); finish(true); }
        else if (e.key === 'Escape') { e.preventDefault(); finish(false); }
      });
      ctl.addEventListener('blur', function () { finish(true); });
      if (c.type === 'checkbox' || c.type === 'select') ctl.addEventListener('change', function () { finish(true); });
      try { ctl.focus(); } catch (e) {}
    }
    function commit(keep) {
      var ed = editing;
      if (!ed) return;
      editing = null;
      msg = '';
      if (keep) {
        var r = readField(ed.c, ed.ctl);
        if (!r.error && typeof ed.c.validate === 'function') {
          var m = ed.c.validate(r.value, assign({}, ed.it.row));
          if (m) r.error = String(m);
        }
        if (r.error) msg = labelOf(ed.c) + ': ' + r.error;
        else setCell(ed.it, ed.c.key, r.value);
      }
      // Only this cell: a full re-render would detach the cell the user is
      // clicking into (its mousedown blurred this input), eating the click.
      if (ed.td.parentNode) {
        ed.td.innerHTML = cellHtmlOf(ed.c, ed.it.row);
        ed.td.className = tdClass(ed.it, ed.c);
        var tr = ed.td.parentNode;
        tr.className = tr.className.replace(/\s*gs-et-rowerr/g, '');
        tr.removeAttribute('title');
      }
      renderFoot();
      if (typeof opts.onChange === 'function') opts.onChange(dirtyItems().map(function (it) { return it.row; }));
    }
    function setCell(it, key, v) {
      it.row[key] = v;
      it.error = null;
      if (it.isNew) return;
      // Exact, not cmpVals: that is the sort order (case-, accent- and
      // numeric-insensitive), so "acme" -> "Acme" would never save.
      if (sameValue(it.orig[key], v)) delete it.changes[key];
      else it.changes[key] = v;
    }
    function addRow() {
      if (busy) return;
      var row = {};
      cols.forEach(function (c) { if (c['default'] !== undefined) row[c.key] = c['default']; });
      items.unshift(wrap(row, true));
      renderBody();
      var first = tbody.querySelector('tr.gs-et-new td.gs-et-ed');
      if (first) startEdit(first);
    }
    function removeItem(it) { items = items.filter(function (x) { return x !== it; }); }
    // Auto chips follow the rows as they are now, not as last loaded: a
    // deleted row's value must not linger. Saved values only (orig): unsaved
    // edits never add or drop a chip, so Discard needs no refresh. setChips drops a selected chip
    // whose value is gone (and re-filters), so the grid is not left empty.
    function syncChips() {
      if (!bar || !chipKey || (opts.chips.options && opts.chips.options.length)) return;
      bar.setChips(distinctOptions(items.filter(function (it) { return !it.isNew; }).map(function (it) { return it.orig; }), chipKey));
    }
    function del(it) {
      if (busy) return;
      if (it.isNew) { removeItem(it); renderBody(); if (follow) follow.kick(); return; }
      var p = opts.confirmDelete === false ? Promise.resolve(true) : askConfirm(opts.deleteMessage || 'Delete this row?');
      p.then(function (ok) {
        if (!ok || destroyed) return;
        return writeVia(opts.onDelete, assign({}, it.orig), null, 'editTable').then(function () {
          removeItem(it);
          msg = 'Deleted';
          syncChips();
          renderBody();
          wrote([{ kind: 'delete', row: assign({}, it.orig) }], { saved: 1, failed: 0 });
          if (follow) follow.kick();
        });
      }).then(null, function (err) {
        logErr('editTable', err);
        msg = 'Delete failed: ' + errText(err);
        renderBody();
      });
    }
    // One successful write (a delete, or the rows a Save wrote): tell the
    // page (onSaved) and every other block (gsdash:data-changed).
    // onSaved runs after every Save, even one where every row failed.
    function wrote(changes, out) {
      var kind = changes.length ? changes[0].kind : undefined;
      for (var i = 1; i < changes.length; i++) if (changes[i].kind !== kind) kind = 'mixed';
      var row = changes.length === 1 ? changes[0].row : undefined;
      if (changes.length) dataChanged({ source: 'editTable', kind: kind, row: row, rows: changes.map(function (c) { return c.row; }), changes: changes, table: opts.table, el: root });
      if (typeof opts.onSaved === 'function') {
        try { opts.onSaved(assign({}, out, { kind: kind, row: row, changes: changes })); } catch (e) { logErr('editTable onSaved', e); }
      }
    }
    function validateItem(it) {
      for (var i = 0; i < cols.length; i++) {
        var c = cols[i];
        if (!editable(c, it) || !c.required) continue;
        var v = it.row[c.key];
        if (v == null || v === '') return labelOf(c) + ' is required';
      }
      return null;
    }
    function save() {
      if (editing) commit(true);
      if (busy) return Promise.resolve({ saved: 0, failed: 0 });
      var todo = dirtyItems(), saved = 0, failed = 0, changes = [];
      if (!todo.length) return Promise.resolve({ saved: 0, failed: 0 });
      busy = true;
      msg = '';
      renderBody();
      // Sequential: one failed row must not leave the next half-written, and
      // a burst of parallel writes is how a page trips the query rate limit.
      var chain = Promise.resolve();
      todo.forEach(function (it) {
        chain = chain.then(function () {
          if (destroyed) return;
          var bad = validateItem(it);
          if (bad) { it.error = bad; failed++; return; }
          var spec = it.isNew ? opts.onAdd : opts.onSave;
          var row = it.isNew ? assign({}, it.row) : assign({}, it.orig, it.row);
          var kind = it.isNew ? 'add' : 'edit';
          return writeVia(spec, row, it.isNew ? undefined : assign({}, it.changes), 'editTable').then(function (res) {
            assign(it.row, firstRow(res));
            changes.push({ kind: kind, row: assign({}, it.row) });
            it.orig = assign({}, it.row);
            it.changes = {};
            it.isNew = false;
            it.error = null;
            saved++;
          }, function (err) {
            logErr('editTable', err);
            it.error = errText(err);
            failed++;
          });
        });
      });
      return chain.then(function () {
        busy = false;
        msg = failed ? (failed + ' failed — hover the row for the reason') : ('Saved ' + saved);
        if (saved) syncChips();
        renderBody();
        var out = { saved: saved, failed: failed };
        wrote(changes, out);
        if (follow) follow.kick();
        return out;
      });
    }
    function discard() {
      if (busy) return;
      items = items.filter(function (it) { return !it.isNew; });
      items.forEach(function (it) { it.row = assign({}, it.orig); it.changes = {}; it.error = null; });
      msg = '';
      renderBody();
      if (follow) follow.kick();
    }
    // auto: a reload after another block's write. It must not land over
    // edits the user started while it was loading: keep them, retry later.
    function refresh(auto) {
      if (busy) return Promise.resolve(handle);
      loading = true;
      msg = '';
      renderBody();
      return src.load(true).then(function (rows) {
        loading = false;
        if (destroyed) return handle;
        if (auto === true && (busy || editing || dirtyItems().length)) { if (follow) follow.miss(); renderFoot(); return handle; }
        items = rows.map(function (r) { return wrap(r); });
        shown = pageSize;
        if (bar && chipKey && !(opts.chips.options && opts.chips.options.length)) bar.setChips(distinctOptions(rows, chipKey));
        renderBody();
        return handle;
      }, function (err) {
        loading = false;
        logErr('editTable', err);
        msg = 'Load failed: ' + errText(err);
        // Not over an open editor or unsaved rows: keep them, retry later.
        if (auto === true && (busy || editing || dirtyItems().length)) { if (follow) follow.miss(); renderFoot(); return handle; }
        renderBody();
        return handle;
      });
    }

    tbody.addEventListener('click', function (e) {
      var t = e.target;
      if (t && t.closest) {
        var delBtn = t.closest('.gs-et-del');
        if (delBtn) { var it = itemByK(Number(delBtn.closest('tr').getAttribute('data-k'))); if (it) del(it); return; }
        var td = t.closest('td.gs-et-ed');
        if (td && !(editing && editing.td === td)) startEdit(td);
      }
    });
    tbody.addEventListener('keydown', function (e) {
      var t = e.target;
      if (e.key === 'Enter' && t && t.classList && t.classList.contains('gs-et-ed') && !(editing && editing.td === t)) { e.preventDefault(); startEdit(t); }
    });

    var handle = {
      el: root,
      ready: null,
      rows: function () { return items.map(function (it) { return it.row; }); },
      dirty: function () { return dirtyItems().map(function (it) { return it.row; }); },
      save: save, discard: discard, refresh: function () { return refresh(); },
      destroy: function () { destroyed = true; if (follow) follow.off(); if (bar) bar.destroy(); if (root.parentNode) root.parentNode.removeChild(root); },
    };
    // Another block's write: reload, unless that would drop edits here.
    var follow = followChanges(root, opts, function () { return refresh(true); }, root.__gsDirty);
    loading = true;
    handle.ready = resolveFields(opts.columns, opts.table).then(function (fs) {
      cols = fs;
      renderHead();
      return refresh();
    }, function (err) {
      loading = false;
      logErr('editTable', err);
      root.innerHTML = '';
      root.appendChild(mk('div', 'gs-sec-error', 'Could not load the table: ' + errText(err)));
      return handle;
    });
    return handle;
  }

  // gsDash.detailDrawer({
  //   title: 'Order #12' | function (record) -> string,
  //   record: row,
  //   fields?: ['customer', { key: 'amount', label: 'Amount', format: gsDash.money }, ...],
  //                         // read-only list; default every key of record. Field shape as
  //                         // gsDash.form, plus format(v, row) -> text, render(row) -> html, badge
  //   render?: function (record, body) -> html | undefined,  // custom body instead of fields
  //   edit?: { table?, fields?, submit, params?, onSaved?(result, values) },  // adds Edit (gsDash.form)
  //   actions?: [{ label, kind?: 'primary'|'secondary'|'danger'|'ghost', onClick(record, drawer) }],
  //   modal?: false (centered dialog when true), width?: 440, onClose?: function () {},
  // }) -> { el, body, record(), setRecord(row), edit(), close() }
  var _openDrawer = null;
  function detailDrawer(opts) {
    opts = opts || {};
    if (_openDrawer) _openDrawer.close();
    var record = opts.record || {}, closed = false, formH = null;
    var prevFocus = document.activeElement;
    var overlay = mk('div', 'gs-drawer-overlay' + (opts.modal ? ' gs-modal' : ''));
    var panel = mk('div', 'gs-drawer');
    panel.setAttribute('role', 'dialog');
    panel.setAttribute('aria-modal', 'true');
    panel.tabIndex = -1;
    if (opts.width) panel.style.width = typeof opts.width === 'number' ? opts.width + 'px' : opts.width;
    var head = mk('div', 'gs-drawer-head');
    var ttl = mk('div', 't-h3 gs-drawer-title');
    ttl.id = 'gsd' + (++_uid);
    panel.setAttribute('aria-labelledby', ttl.id);
    var x = button('✕', 'ghost', function () { close(); });
    x.setAttribute('aria-label', 'Close');
    head.appendChild(ttl); head.appendChild(x);
    var body = mk('div', 'gs-drawer-body');
    var foot = mk('div', 'gs-drawer-foot');
    panel.appendChild(head); panel.appendChild(body); panel.appendChild(foot);
    overlay.appendChild(panel);

    function fieldList() {
      if (opts.fields) return opts.fields.map(function (s) { return typeof s === 'string' ? { key: s } : s; });
      return Object.keys(record).map(function (k) { return { key: k }; });
    }
    function view() {
      formH = null;
      ttl.textContent = typeof opts.title === 'function' ? opts.title(record) : (opts.title || 'Details');
      body.innerHTML = '';
      if (typeof opts.render === 'function') {
        var h = opts.render(record, body);
        if (typeof h === 'string') body.innerHTML = h;
      } else {
        var dl = mk('dl', 'gs-dl');
        fieldList().forEach(function (f) {
          dl.appendChild(mk('dt', null, labelOf(f)));
          var dd = mk('dd');
          dd.innerHTML = cellHtmlOf(f, record);
          dl.appendChild(dd);
        });
        body.appendChild(dl);
      }
      foot.innerHTML = '';
      (opts.actions || []).forEach(function (a) {
        foot.appendChild(button(a.label, a.kind, function () { if (typeof a.onClick === 'function') a.onClick(record, handle); }));
      });
      if (opts.edit) foot.appendChild(button(opts.edit.label || 'Edit', 'primary', function () { edit(); }));
      foot.style.display = foot.childNodes.length ? '' : 'none';
    }
    function edit() {
      if (!opts.edit || closed) return null;
      var e = opts.edit;
      body.innerHTML = '';
      foot.innerHTML = '';
      foot.style.display = 'none';
      var defaults = opts.fields
        ? opts.fields.filter(function (f) { return !(isPlain(f) && (f.render || f.format)); })
        : Object.keys(record).filter(function (k) { return !AUTO_COLS[k]; }).map(function (k) {
          // Without a schema (no edit.table), type the field from its value,
          // or a jsonb/array column would round-trip as "[object Object]" /
          // "a,b". With one, the schema's type wins, so pass the key alone.
          if (e.table) return k;
          var v = record[k];
          var t = v !== null && typeof v === 'object' ? 'json' : typeof v === 'boolean' ? 'checkbox' : typeof v === 'number' ? 'number' : 'text';
          return { key: k, type: t };
        });
      formH = form(body, {
        table: e.table,
        fields: e.fields || defaults,
        record: record,
        submit: e.submit,
        params: e.params,
        submitLabel: e.submitLabel,
        cancel: function () { view(); },
        onSaved: function (res, values) {
          record = assign({}, record, values, firstRow(res));
          if (typeof e.onSaved === 'function') e.onSaved(res, values, record);
          view();
        },
      });
      return formH;
    }
    var layer = {};
    function onKey(ev) {
      if (!isTopLayer(layer)) return;
      if (ev.key === 'Escape') { ev.preventDefault(); close(); return; }
      if (ev.key === 'Tab') {
        // Keep focus inside the dialog.
        var f = panel.querySelectorAll('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])');
        if (!f.length) return;
        var first = f[0], last = f[f.length - 1];
        if (ev.shiftKey && document.activeElement === first) { ev.preventDefault(); last.focus(); }
        else if (!ev.shiftKey && document.activeElement === last) { ev.preventDefault(); first.focus(); }
      }
    }
    function close() {
      if (closed) return;
      closed = true;
      layerClose(layer);
      document.removeEventListener('keydown', onKey, true);
      if (overlay.parentNode) overlay.parentNode.removeChild(overlay);
      if (_openDrawer === handle) _openDrawer = null;
      try { if (prevFocus && prevFocus.focus) prevFocus.focus(); } catch (e) {}
      if (typeof opts.onClose === 'function') opts.onClose(record);
    }
    overlay.addEventListener('mousedown', function (ev) { if (ev.target === overlay && _downTop === layer) close(); });
    layerOpen(layer);
    document.addEventListener('keydown', onKey, true);
    var handle = {
      el: panel, body: body,
      record: function () { return record; },
      setRecord: function (r) { record = r || {}; view(); },
      edit: edit, close: close,
    };
    view();
    document.body.appendChild(overlay);
    _openDrawer = handle;
    try { panel.focus(); } catch (e) {}
    return handle;
  }

  // gsDash.cardList(el, {
  //   rows? | query?: 'load_requests', params? | fetchPage?,
  //   title?: 'name', sub?: 'company', badge?: 'status', meta?: 'created_at' | function (row) -> text,
  //   render?: function (row) -> html,     // card body (escape data with gsDash.esc)
  //   search?: true | ['name', 'company'], chips?: { key: 'status', options?, all? },
  //   dateRange?: { key: 'created_at', label? },
  //   actions?: [{ label, kind?, show?(row), confirm?: 'Reject this request?',
  //               query?: 'approve_request', params?(row), onClick?(row, card) -> Promise,
  //               then?: 'remove' | 'refresh' }],
  //   onOpen?: function (row, card) {},   // card click / Enter, e.g. gsDash.detailDrawer
  //   idKey?: 'id', layout?: 'grid'|'list', minWidth?: 260, pageSize?: 60, empty?,
  // }) -> { ready, rows(), setRows(rows), refresh(), update(row), remove(row), destroy() }
  // card = { row, update(patch), remove(), refresh() }. A query action sends
  // the row as params; its RETURNING row is merged into the card.
  function cardList(el, opts) {
    el = elOf(el, 'cardList');
    opts = opts || {};
    var idKey = opts.idKey || 'id', pageSize = opts.pageSize || 60;
    var rows = [], shown = pageSize, filt = { q: '', chip: null, from: '', to: '' };
    var src = rowSource(opts), destroyed = false, loading = true, failMsg = '';
    var chipKey = opts.chips && opts.chips.key;
    var root = mk('div', 'gs-cl');
    var tools = mk('div', 'gs-cl-tools');
    var grid = mk('div', 'gs-cl-grid' + (opts.layout === 'list' ? ' gs-cl-list' : ''));
    if (opts.minWidth) grid.style.setProperty('--gs-cl-min', (typeof opts.minWidth === 'number' ? opts.minWidth + 'px' : opts.minWidth));
    var foot = mk('div', 'gs-cl-foot');
    var moreBtn = button('Show more', 'ghost', function () { showMore(); });
    foot.appendChild(moreBtn);
    root.appendChild(tools); root.appendChild(grid); root.appendChild(foot);
    el.innerHTML = '';
    el.appendChild(root);
    var bar = null;
    if (opts.search || opts.chips || opts.dateRange) {
      bar = filterBar(tools, {
        search: !!opts.search,
        chips: opts.chips ? { options: opts.chips.options || [], all: opts.chips.all } : null,
        dateRange: opts.dateRange ? { label: opts.dateRange.label, presets: opts.dateRange.presets, preset: opts.dateRange.preset } : null,
        debounce: opts.debounce,
        onChange: function (st) { filt = st; shown = pageSize; render(); },
      });
      filt = bar.value();  // a starting date preset already filled from/to
    } else {
      tools.style.display = 'none';
    }
    var cfg = {
      searchKeys: isArr(opts.search) ? opts.search : null,
      chipKey: chipKey,
      dateKey: opts.dateRange && opts.dateRange.key,
    };
    function textOf(spec, r) {
      if (spec == null) return '';
      var v = typeof spec === 'function' ? spec(r) : r[spec];
      return v == null ? '' : String(v);
    }
    function visible() { return rows.filter(function (r) { return rowMatches(r, filt, cfg); }); }
    function cardHtml(r, i) {
      var h = '<div class="gs-card gs-cl-card' + (opts.onOpen ? ' gs-cl-open' : '') + '" data-i="' + i + '"' + (opts.onOpen ? ' tabindex="0" role="button"' : '') + '>';
      var t = textOf(opts.title, r), b = opts.badge ? r[opts.badge] : null;
      if (t || (b != null && b !== '')) {
        h += '<div class="gs-cl-head"><div class="gs-cl-title">' + esc(t) + '</div>' + (b != null && b !== '' ? tag(humanize(b), statusTone(b)) : '') + '</div>';
      }
      var s = textOf(opts.sub, r);
      if (s) h += '<div class="gs-cl-sub">' + esc(s) + '</div>';
      if (typeof opts.render === 'function') h += '<div class="gs-cl-body">' + String(opts.render(r)) + '</div>';
      var m = textOf(opts.meta, r);
      if (m) h += '<div class="gs-cl-meta">' + esc(m) + '</div>';
      var acts = (opts.actions || []).map(function (a, ai) {
        if (typeof a.show === 'function' && !a.show(r)) return '';
        return '<button type="button" class="btn btn-sm btn-' + (a.kind || 'secondary') + ' gs-cl-act" data-a="' + ai + '">' + esc(a.label) + '</button>';
      }).join('');
      if (acts) h += '<div class="gs-cl-actions">' + acts + '</div>';
      return h + '</div>';
    }
    var view = [];
    function render() {
      if (destroyed) return;
      view = visible();
      var n = Math.min(view.length, shown), html = '';
      for (var i = 0; i < n; i++) html += cardHtml(view[i], i);
      if (!n) {
        html = '<div class="gs-empty gs-cl-empty">' + esc(failMsg || (loading ? 'Loading…' : (rows.length ? 'No matches' : (opts.empty || 'Nothing here yet')))) + '</div>';
      }
      grid.innerHTML = html;
      moreBtn.style.display = view.length > n || src.hasMore() ? '' : 'none';
    }
    var moreLoading = false;
    function showMore() {
      if (view.length > shown) { shown += pageSize; render(); return; }
      // One page in flight at a time: a second click would reuse the same
      // cursor and append the same page twice.
      if (!src.hasMore() || moreLoading) return;
      moreLoading = true;
      moreBtn.disabled = true;
      src.load(false).then(function (more) {
        moreLoading = false; moreBtn.disabled = false;
        if (destroyed) return;
        rows = rows.concat(more); shown += pageSize; render();
      }, function (err) { moreLoading = false; moreBtn.disabled = false; logErr('cardList', err); });
    }
    function sameRow(a, b) { return a === b || (a && b && a[idKey] != null && a[idKey] === b[idKey]); }
    function update(row) {
      for (var i = 0; i < rows.length; i++) if (sameRow(rows[i], row)) rows[i] = assign({}, rows[i], row);
      render();
    }
    function remove(row) { rows = rows.filter(function (r) { return !sameRow(r, row); }); render(); }
    function cardCtx(r) {
      return {
        row: r,
        update: function (patch) { update(assign({}, r, patch)); },
        remove: function () { remove(r); },
        refresh: function () { return refresh(); },
      };
    }
    function runAction(a, r, btnEl) {
      var card = btnEl.closest('.gs-cl-card'), btns = card ? card.querySelectorAll('button') : [btnEl], i;
      var pre = a.confirm ? askConfirm(a.confirm) : Promise.resolve(true);
      return pre.then(function (ok) {
        if (!ok) return;
        for (i = 0; i < btns.length; i++) btns[i].disabled = true;
        var p;
        if (typeof a.onClick === 'function') p = Promise.resolve().then(function () { return a.onClick(r, cardCtx(r)); });
        else if (a.query) p = runQuery(a.query, typeof a.params === 'function' ? a.params(r) : r);
        else p = Promise.resolve();
        return p.then(function (res) {
          if (a.query) dataChanged({ source: 'cardList', kind: a.then === 'remove' ? 'delete' : 'edit', row: assign({}, r, firstRow(res)), el: root });
          if (a.then === 'remove') remove(r);
          else if (a.then === 'refresh') refresh();
          else if (a.query && firstRow(res)) update(assign({}, r, firstRow(res)));
          else render();
        });
      }).then(null, function (err) {
        logErr('cardList', err);
        for (i = 0; i < btns.length; i++) btns[i].disabled = false;
        if (card) {
          var old = card.querySelector('.gs-cl-err');
          if (old) old.parentNode.removeChild(old);
          card.appendChild(mk('div', 'gs-cl-err', a.label + ' failed: ' + errText(err)));
        }
      });
    }
    grid.addEventListener('click', function (e) {
      var t = e.target;
      if (!t || !t.closest) return;
      var card = t.closest('.gs-cl-card');
      if (!card) return;
      var r = view[Number(card.getAttribute('data-i'))];
      if (!r) return;
      var ab = t.closest('.gs-cl-act');
      if (ab) { e.stopPropagation(); runAction(opts.actions[Number(ab.getAttribute('data-a'))], r, ab); return; }
      if (typeof opts.onOpen === 'function') opts.onOpen(r, cardCtx(r));
    });
    grid.addEventListener('keydown', function (e) {
      var t = e.target;
      if ((e.key === 'Enter' || e.key === ' ') && t && t.classList && t.classList.contains('gs-cl-open')) {
        e.preventDefault();
        var r = view[Number(t.getAttribute('data-i'))];
        if (r) opts.onOpen(r, cardCtx(r));
      }
    });
    function setRows(next) {
      rows = (next || []).slice();
      loading = false;
      failMsg = '';
      if (bar && chipKey && !(opts.chips.options && opts.chips.options.length)) bar.setChips(distinctOptions(rows, chipKey));
      render();
    }
    function refresh() {
      return src.load(true).then(function (r) { if (!destroyed) setRows(r); return handle; }, function (err) {
        logErr('cardList', err);
        loading = false;
        failMsg = 'Could not load: ' + errText(err);
        render();
        return handle;
      });
    }
    var handle = {
      el: root, ready: null,
      rows: function () { return rows.slice(); },
      setRows: setRows, refresh: refresh, update: update, remove: remove,
      destroy: function () { destroyed = true; if (bar) bar.destroy(); if (root.parentNode) root.parentNode.removeChild(root); },
    };
    // Rows the page sets itself are not replaced by an automatic reload.
    var follow = followChanges(root, opts, refresh);
    handle.setRows = function (r) { if (follow) follow.off(); setRows(r); };
    render();
    handle.ready = refresh();
    return handle;
  }

  // ============================================================
  // UI components: overlays (dialog, formDialog, menu, toast),
  // navigation (tabs, segmented, periodNav, steps), display (table,
  // kpiRow mount, bar, heatmap, funnel, timeline, descriptions, empty,
  // skeleton, banner, section) and app blocks (calendar, kanban,
  // importer). Same conventions as the data-entry blocks above:
  //   string builder  gsDash.x(spec)          -> html
  //   mounted block   gsDash.x(el, opts)      -> handle { el, destroy(), ... }
  //   overlay         gsDash.x(opts)          -> handle { el, close() }
  // Tokens only, light + dark, every value escaped, built-in strings
  // follow <html lang> (en / ja / zh / ko).
  // ============================================================

  var UI_TEXT = {
    en: { search: 'Search…', all: 'All', close: 'Close', cancel: 'Cancel', ok: 'OK', save: 'Save', loading: 'Loading…', noData: 'No data yet', noMatches: 'No matches',
      total: 'Total', today: 'Today', prev: 'Previous', next: 'Next', more: 'more', showMore: 'Show more', actions: 'Actions', failed: 'failed',
      p7d: 'Last 7 days', p30d: 'Last 30 days', p90d: 'Last 90 days', pmtd: 'Month to date', pqtd: 'Quarter to date', pytd: 'Year to date', pall: 'All time', pcustom: 'Custom',
      month: 'Month', week: 'Week', importTitle: 'Import a file', dropHint: 'Drop a CSV or Excel file here, or', choose: 'choose a file',
      column: 'Column in file', field: 'Field', skip: '— skip —', importN: 'Import {n} rows', importing: 'Importing… {done} / {n}', imported: '{ok} imported', importFailed: '{n} failed',
      again: 'Import another file', previewOf: '{n} rows', stUpload: 'Upload', stMap: 'Map columns', stImport: 'Import', required: 'Required', moveTo: 'Move to', conversion: 'conversion', of: 'of', vs: 'vs', step: 'Step', unreadable: 'Could not read this file',
      decMark: 'Decimal mark', decAsk: '"{v}" in {col} could be read either way. How does this file write numbers?',
      dateOrder: 'Date order', dateAsk: '"{v}" in {col} could be either date. Which comes first in this file?', mdFirst: 'Month / day', dmFirst: 'Day / month', badDate: 'Enter a date like 2026-11-10',
      encoding: 'Text encoding', encAsk: 'This file is not UTF-8. Which language is its text in? Check the preview.', encWestern: 'Western', encJa: 'Japanese', encZh: 'Chinese', encKo: 'Korean' },
    ja: { search: '検索…', all: 'すべて', close: '閉じる', cancel: 'キャンセル', ok: 'OK', save: '保存', loading: '読み込み中…', noData: 'データがありません', noMatches: '該当なし',
      total: '合計', today: '今日', prev: '前へ', next: '次へ', more: '件', showMore: 'さらに表示', actions: '操作', failed: '失敗',
      p7d: '過去7日', p30d: '過去30日', p90d: '過去90日', pmtd: '今月', pqtd: '今四半期', pytd: '今年', pall: '全期間', pcustom: 'カスタム',
      month: '月', week: '週', importTitle: 'ファイルを取り込む', dropHint: 'CSV / Excel ファイルをドロップ、または', choose: 'ファイルを選択',
      column: 'ファイルの列', field: '項目', skip: '— 取り込まない —', importN: '{n} 行を取り込む', importing: '取り込み中… {done} / {n}', imported: '{ok} 行を取り込みました', importFailed: '{n} 行が失敗',
      again: '別のファイルを取り込む', previewOf: '{n} 行', stUpload: 'アップロード', stMap: '列の対応付け', stImport: '取り込み', required: '必須', moveTo: '移動先', conversion: '転換率', of: '/', vs: '前期比', step: 'ステップ', unreadable: 'ファイルを読み込めませんでした',
      decMark: '小数点', decAsk: '「{v}」（{col}）は2通りに読めます。このファイルの数値の書き方を選んでください。',
      dateOrder: '日付の順序', dateAsk: '「{v}」（{col}）は2通りの日付に読めます。このファイルではどちらが先ですか？', mdFirst: '月 / 日', dmFirst: '日 / 月', badDate: '2026-11-10 のような日付を入力してください',
      encoding: '文字コード', encAsk: 'このファイルは UTF-8 ではありません。どの言語のテキストですか？プレビューで確認してください。', encWestern: '欧文', encJa: '日本語', encZh: '中国語', encKo: '韓国語' },
    zh: { search: '搜索…', all: '全部', close: '关闭', cancel: '取消', ok: '确定', save: '保存', loading: '加载中…', noData: '暂无数据', noMatches: '无匹配结果',
      total: '合计', today: '今天', prev: '上一个', next: '下一个', more: '条', showMore: '显示更多', actions: '操作', failed: '失败',
      p7d: '近 7 天', p30d: '近 30 天', p90d: '近 90 天', pmtd: '本月至今', pqtd: '本季度至今', pytd: '今年至今', pall: '全部', pcustom: '自定义',
      month: '月', week: '周', importTitle: '导入文件', dropHint: '将 CSV / Excel 文件拖到这里，或', choose: '选择文件',
      column: '文件中的列', field: '字段', skip: '— 不导入 —', importN: '导入 {n} 行', importing: '导入中… {done} / {n}', imported: '已导入 {ok} 行', importFailed: '{n} 行失败',
      again: '导入其他文件', previewOf: '{n} 行', stUpload: '上传', stMap: '匹配列', stImport: '导入', required: '必填', moveTo: '移动到', conversion: '转化率', of: '/', vs: '环比', step: '步骤', unreadable: '无法读取该文件',
      decMark: '小数点', decAsk: '“{v}”（{col}）有两种读法。这个文件的数字用哪种写法？',
      dateOrder: '日期顺序', dateAsk: '“{v}”（{col}）可以读成两个日期。这个文件里哪个在前？', mdFirst: '月/日', dmFirst: '日/月', badDate: '请输入类似 2026-11-10 的日期',
      encoding: '文字编码', encAsk: '此文件不是 UTF-8。文本是哪种语言？请查看预览。', encWestern: '西文', encJa: '日文', encZh: '中文', encKo: '韩文' },
    ko: { search: '검색…', all: '전체', close: '닫기', cancel: '취소', ok: '확인', save: '저장', loading: '불러오는 중…', noData: '데이터가 없습니다', noMatches: '일치 항목 없음',
      total: '합계', today: '오늘', prev: '이전', next: '다음', more: '개', showMore: '더 보기', actions: '작업', failed: '실패',
      p7d: '최근 7일', p30d: '최근 30일', p90d: '최근 90일', pmtd: '이번 달', pqtd: '이번 분기', pytd: '올해', pall: '전체', pcustom: '사용자 지정',
      month: '월', week: '주', importTitle: '파일 가져오기', dropHint: 'CSV / Excel 파일을 여기에 놓거나', choose: '파일 선택',
      column: '파일의 열', field: '필드', skip: '— 건너뛰기 —', importN: '{n}행 가져오기', importing: '가져오는 중… {done} / {n}', imported: '{ok}행 가져옴', importFailed: '{n}행 실패',
      again: '다른 파일 가져오기', previewOf: '{n}행', stUpload: '업로드', stMap: '열 매핑', stImport: '가져오기', required: '필수', moveTo: '이동', conversion: '전환율', of: '/', vs: '대비', step: '단계', unreadable: '파일을 읽을 수 없습니다',
      decMark: '소수점', decAsk: '"{v}"({col})은(는) 두 가지로 읽힐 수 있습니다. 이 파일의 숫자 표기를 선택하세요.',
      dateOrder: '날짜 순서', dateAsk: '"{v}"({col})은(는) 두 날짜로 읽힐 수 있습니다. 이 파일에서는 무엇이 먼저인가요?', mdFirst: '월 / 일', dmFirst: '일 / 월', badDate: '2026-11-10 형식의 날짜를 입력하세요',
      encoding: '문자 인코딩', encAsk: '이 파일은 UTF-8이 아닙니다. 어떤 언어의 텍스트인가요? 미리보기를 확인하세요.', encWestern: '서유럽어', encJa: '일본어', encZh: '중국어', encKo: '한국어' },
  };
  function uiLang() {
    var l = '';
    try { l = document.documentElement.lang || navigator.language || ''; } catch (e) {}
    return String(l).slice(0, 2).toLowerCase();
  }
  function T(key, vars) {
    var t = (UI_TEXT[uiLang()] || UI_TEXT.en)[key];
    if (t == null) t = UI_TEXT.en[key] != null ? UI_TEXT.en[key] : key;
    if (vars) t = t.replace(/\{(\w+)\}/g, function (m, k) { return vars[k] != null ? vars[k] : m; });
    return t;
  }
  // The page's language, not the browser's: everything else in the kit
  // (money(), fmtInt()) formats en-US, so one page never mixes styles.
  function locale() { var l = uiLang(); return l === 'ja' ? 'ja-JP' : l === 'zh' ? 'zh-CN' : l === 'ko' ? 'ko-KR' : 'en-US'; }

  var TONES = { success: 1, warn: 1, danger: 1, brand: 1, info: 1, neutral: 1 };
  function toneOf(t) { return TONES[t] ? t : 'neutral'; }
  // A tone's paint as a CSS value. Neutral has no --neutral-500 token; it is
  // the ink scale, as in .gs-tone-neutral.
  function toneVar(t) { t = toneOf(t); return t === 'neutral' ? 'var(--ink-400)' : 'var(--' + t + '-500)'; }
  // Small stroke icons (currentColor), shared by toast, banner, empty.
  var ICON = {
    success: '<path d="M4 8.5l2.5 2.5L12 5.5"/>',
    danger: '<path d="M5 5l6 6M11 5l-6 6"/>',
    warn: '<path d="M8 4.5v4.5M8 11.5v.01"/>',
    info: '<path d="M8 7.5v4M8 4.8v.01"/>',
    neutral: '<path d="M8 7.5v4M8 4.8v.01"/>',
    brand: '<path d="M8 7.5v4M8 4.8v.01"/>',
    inbox: '<path d="M2.5 9.5l1.6-5a1 1 0 0 1 1-.7h5.8a1 1 0 0 1 1 .7l1.6 5M2.5 9.5v3a1 1 0 0 0 1 1h9a1 1 0 0 0 1-1v-3M2.5 9.5h3l1 1.5h3l1-1.5h3"/>',
    search: '<circle cx="7" cy="7" r="4"/><path d="M10 10l3.5 3.5"/>',
    chart: '<path d="M3 13.5V3M3 13.5h10.5M6 11V8M9 11V5.5M12 11V7"/>',
    error: '<circle cx="8" cy="8" r="5.5"/><path d="M8 5.5v3M8 10.6v.01"/>',
    calendar: '<rect x="2.5" y="3.5" width="11" height="10" rx="1.5"/><path d="M2.5 6.5h11M5.5 2v3M10.5 2v3"/>',
    upload: '<path d="M8 10.5V3M5 6l3-3 3 3M3 10.5v2a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1v-2"/>',
    more: '<circle cx="3.5" cy="8" r=".9"/><circle cx="8" cy="8" r=".9"/><circle cx="12.5" cy="8" r=".9"/>',
    chevL: '<path d="M10 3.5L5.5 8l4.5 4.5"/>',
    chevR: '<path d="M6 3.5L10.5 8 6 12.5"/>',
    up: '<path d="M8 12.5V3.5M4.5 7L8 3.5 11.5 7"/>',
    down: '<path d="M8 3.5v9M4.5 9L8 12.5 11.5 9"/>',
  };
  function icon(name, size) {
    var s = size || 16;
    return '<svg class="gs-ico" width="' + s + '" height="' + s + '" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (ICON[name] || ICON.info) + '</svg>';
  }
  function px(v) { return typeof v === 'number' ? v + 'px' : v; }
  function num(v) { var n = Number(v); return isFinite(n) ? n : 0; }
  // Fraction digits fmtNum shows for a plain summary number: 1.23, 12.3, 123.
  function autoDigits(n) { var a = Math.abs(n); return a < 10 ? 2 : a < 100 ? 1 : 0; }
  function fmtNum(n, o) {
    o = o || {};
    if (n == null || n === '' || !isFinite(Number(n))) return '—';
    var opt = {};
    if (o.currency) { opt.style = 'currency'; opt.currency = o.currency; }
    if (o.compact) opt.notation = 'compact';
    if (o.digits != null) { opt.minimumFractionDigits = o.digits; opt.maximumFractionDigits = o.digits; }
    // exact (table cells): the stored value, not a summary. A whole amount
    // stays "$1,200"; 4.99 is "$4.99", not "$5"; 1234.56 keeps its decimals
    // (10 places at most, which drops float noise like 0.30000000000000004).
    else if (o.exact && o.compact) { /* compact rounds by design */ }
    else if (o.exact && o.currency) { if (Number(n) % 1 === 0) opt.maximumFractionDigits = 0; }
    else if (o.exact) opt.maximumFractionDigits = 10;
    else if (!o.currency) opt.maximumFractionDigits = autoDigits(n);
    else opt.maximumFractionDigits = 0;
    try { return Number(n).toLocaleString(o.locale || locale(), opt); } catch (e) { return String(n); }
  }
  function nodeOrHtml(target, content) {
    if (content == null) return;
    if (typeof content === 'string') target.innerHTML = content;
    else if (content.nodeType) target.appendChild(content);
  }

  // ── Feedback: banner / empty / skeleton / bar (string builders) ─────────

  // gsDash.banner('Saved 12 rows', { tone: 'success', title? }) -> html
  function banner(text, o) {
    o = o || {};
    var t = toneOf(o.tone || 'info');
    return '<div class="gs-banner gs-tone-' + t + '" role="' + (t === 'danger' ? 'alert' : 'status') + '">' + icon(t === 'neutral' ? 'info' : t) +
      '<div class="gs-banner-body">' + (o.title ? '<div class="gs-banner-title">' + esc(o.title) + '</div>' : '') + '<div>' + esc(text) + '</div></div></div>';
  }
  // gsDash.empty({ title?, text?, icon?: 'inbox'|'search'|'chart'|'calendar'|'error' }) -> html
  function empty(o) {
    if (typeof o === 'string') o = { title: o };
    o = o || {};
    return '<div class="gs-emptystate"><div class="gs-emptystate-ico">' + icon(o.icon || 'inbox', 20) + '</div>' +
      '<div class="gs-emptystate-title">' + esc(o.title || T('noData')) + '</div>' + (o.text ? '<div class="gs-emptystate-text">' + esc(o.text) + '</div>' : '') + '</div>';
  }
  // gsDash.skeleton({ kind: 'lines'|'kpis'|'table'|'cards', rows?: 3 }) -> html
  function skeleton(o) {
    o = o || {};
    var k = o.kind || 'lines', n = o.rows || (k === 'kpis' ? 4 : k === 'cards' ? 3 : 3), h = '', i;
    if (k === 'kpis') {
      for (i = 0; i < n; i++) h += '<div class="gs-card gs-sk-kpi"><span class="gs-sk" style="width:45%"></span><span class="gs-sk gs-sk-lg" style="width:65%"></span></div>';
      return '<div class="gs-kpis" style="--gs-kpi-cols:' + n + '" aria-busy="true">' + h + '</div>';
    }
    if (k === 'cards') {
      for (i = 0; i < n; i++) h += '<div class="gs-card gs-sk-card"><span class="gs-sk" style="width:60%"></span><span class="gs-sk" style="width:90%"></span><span class="gs-sk" style="width:40%"></span></div>';
      return '<div class="gs-cl-grid" aria-busy="true">' + h + '</div>';
    }
    if (k === 'table') {
      for (i = 0; i < n; i++) h += '<div class="gs-sk-row"><span class="gs-sk" style="width:30%"></span><span class="gs-sk" style="width:20%"></span><span class="gs-sk" style="width:15%"></span></div>';
      return '<div class="gs-sk-table" aria-busy="true">' + h + '</div>';
    }
    var w = [92, 78, 85, 64, 70];
    for (i = 0; i < n; i++) h += '<span class="gs-sk" style="width:' + w[i % w.length] + '%"></span>';
    return '<div class="gs-sk-lines" aria-busy="true">' + h + '</div>';
  }
  // gsDash.bar(62, { max?: 100, tone?, label?: true|false|'text', fmt?, target? }) -> html
  // gsDash.bar([{ value: 40, tone: 'success', label: 'On track' }, ...], { max? }) -> stacked bar + legend
  function bar(v, o) {
    o = o || {};
    if (isArr(v)) {
      var segs = v, total = o.max || segs.reduce(function (a, s) { return a + num(s.value); }, 0) || 1, fill = '', leg = '';
      segs.forEach(function (s, i) {
        var pct = Math.max(0, num(s.value) / total * 100), col = s.tone ? toneVar(s.tone) : vizRef(i);
        fill += '<span class="gs-bar-seg" style="width:' + pct.toFixed(2) + '%;background:' + col + '" title="' + esc((s.label || '') + ' ' + fmtNum(s.value)) + '"></span>';
        if (s.label != null) leg += '<span class="gs-bar-key"><span class="sw" style="background:' + col + '"></span>' + esc(s.label) + ' <b class="num">' + esc(o.fmt ? o.fmt(s.value) : fmtNum(s.value)) + '</b></span>';
      });
      return '<span class="gs-bar gs-bar-stack"><span class="gs-bar-track">' + fill + '</span>' + (leg && o.legend !== false ? '<span class="gs-bar-legend">' + leg + '</span>' : '') + '</span>';
    }
    var max = o.max == null ? 100 : num(o.max) || 1, val = num(v), pct = Math.max(0, Math.min(100, val / max * 100));
    var tone = o.tone || 'brand';
    var lbl = o.label === false ? '' : (typeof o.label === 'string' ? o.label : (o.fmt ? o.fmt(val) : (o.max == null ? fmtNum(val, { digits: val % 1 ? 1 : 0 }) + '%' : fmtNum(val))));
    var tgt = o.target != null ? '<span class="gs-bar-target" style="left:' + Math.max(0, Math.min(100, num(o.target) / max * 100)).toFixed(2) + '%"></span>' : '';
    return '<span class="gs-bar gs-tone-' + (tone === 'brand' ? 'brand' : toneOf(tone)) + '" role="meter" aria-valuemin="0" aria-valuemax="' + max + '" aria-valuenow="' + val + '">' +
      '<span class="gs-bar-track"><span class="gs-bar-fill" style="width:' + pct.toFixed(2) + '%"></span>' + tgt + '</span>' + (lbl ? '<span class="gs-bar-lbl num">' + esc(lbl) + '</span>' : '') + '</span>';
  }
  // Signed change, coloured by whether up is good: gsDash.delta(12.5) -> "▲ +12.5%",
  // gsDash.delta(-7) -> "▼ -7%", 0 -> "0%". The sign is in the text, not only the
  // arrow (the icon is aria-hidden), so screen readers and anything reading
  // textContent see the direction. ASCII "-" like every other negative number
  // the kit prints (toLocaleString), so the text still parses and compares.
  // Flat is decided on the shown precision: -0.04 is "0.0%", not "▼ -0.0%".
  function delta(v, o) {
    o = o || {};
    if (v == null || v === '' || !isFinite(Number(v))) return '<span class="gs-delta">—</span>';
    var n = Number(v), a = Math.abs(n), plain = o.unit === '';
    var digits = plain ? autoDigits(a) : a % 1 ? 1 : 0;
    // toFixed and toLocaleString both round the exact binary value half-up, so
    // they agree on what shows as zero. A caller's fmt owns its own rounding.
    var flat = o.fmt ? n === 0 : Number(a.toFixed(digits)) === 0;
    var up = n > 0 && !flat, good = o.goodWhen === 'down' ? !up : up;
    var sign = flat ? '' : up ? '+' : '-';
    var txt = o.fmt ? o.fmt(n) : sign + (plain ? fmtNum(a) : fmtNum(a, { digits: digits }) + (o.unit != null ? o.unit : '%'));
    return '<span class="gs-delta ' + (flat ? 'gs-delta-flat' : good ? 'gs-delta-good' : 'gs-delta-bad') + '">' + (flat ? '' : icon(up ? 'up' : 'down', 12)) + esc(txt) + (o.label ? '<span class="gs-delta-lbl">' + esc(o.label) + '</span>' : '') + '</span>';
  }

  // ── Toast ──────────────────────────────────────────────────────────────
  // gsDash.toast('Saved', { tone?: 'success'|'danger'|'warn'|'info', title?, ms?: 3500 (0 = stay),
  //                         action?: { label, onClick } }) -> { close() }
  var _toastBox = null;
  function toast(msg, o) {
    o = o || {};
    if (!_toastBox || !_toastBox.parentNode) {
      _toastBox = mk('div', 'gs-toasts');
      _toastBox.setAttribute('aria-live', 'polite');
      document.body.appendChild(_toastBox);
    }
    var t = toneOf(o.tone || 'success');
    var el = mk('div', 'gs-toast gs-tone-' + t);
    el.setAttribute('role', t === 'danger' ? 'alert' : 'status');
    el.innerHTML = '<span class="gs-toast-ico">' + icon(t === 'neutral' ? 'info' : t) + '</span><div class="gs-toast-body">' +
      (o.title ? '<div class="gs-toast-title">' + esc(o.title) + '</div>' : '') + '<div>' + esc(msg) + '</div></div>';
    if (o.action && o.action.label) {
      var a = button(o.action.label, 'ghost', function () { try { o.action.onClick(); } finally { close(); } });
      a.className += ' gs-toast-act';
      el.appendChild(a);
    }
    var x = mk('button', 'gs-toast-x');
    x.type = 'button';
    x.setAttribute('aria-label', T('close'));
    x.innerHTML = icon('danger', 14);
    x.onclick = function () { close(); };
    el.appendChild(x);
    _toastBox.appendChild(el);
    // Bounded: the oldest goes when a fifth arrives.
    while (_toastBox.children.length > 4) _toastBox.removeChild(_toastBox.firstChild);
    var ms = o.ms == null ? (t === 'danger' ? 6000 : 3500) : o.ms, timer = ms ? setTimeout(close, ms) : null;
    el.addEventListener('mouseenter', function () { if (timer) { clearTimeout(timer); timer = null; } });
    el.addEventListener('mouseleave', function () { if (ms && !timer) timer = setTimeout(close, 1500); });
    function close() { if (timer) clearTimeout(timer); timer = null; if (el.parentNode) el.parentNode.removeChild(el); }
    return { el: el, close: close };
  }

  // ── Overlay shell (dialog, formDialog) ──────────────────────────────────
  // Open overlays (drawer, dialog, menu), oldest first. Each one listens on
  // document in the capture phase, so without this one Escape would close
  // every layer at once, including a dialog behind a menu opened inside it.
  var _layers = [];
  function layerOpen(key) { _layers.push(key); }
  function layerClose(key) { var i = _layers.indexOf(key); if (i >= 0) _layers.splice(i, 1); }
  function isTopLayer(key) { return _layers[_layers.length - 1] === key; }
  // The layer that was on top when the current mousedown began. Registered
  // once, here, so it runs before any layer's own listener: a menu that
  // closes on an outside press must not let the same press then dismiss the
  // dialog under it (its backdrop sees the menu already gone).
  var _downTop = null;
  try { document.addEventListener('mousedown', function () { _downTop = _layers[_layers.length - 1] || null; }, true); } catch (e) {}
  var FOCUSABLE = 'button:not([disabled]), [href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])';
  function overlayShell(o) {
    var prevFocus = document.activeElement, closed = false;
    var overlay = mk('div', 'gs-overlay');
    var panel = mk('div', 'gs-dialog gs-dialog-' + (o.size || 'md'));
    panel.setAttribute('role', o.role || 'dialog');
    panel.setAttribute('aria-modal', 'true');
    panel.tabIndex = -1;
    if (o.width) panel.style.width = 'min(' + px(o.width) + ', 100%)';
    var head = mk('div', 'gs-dialog-head');
    var ttl = mk('div', 'gs-dialog-title');
    ttl.id = 'gsdlg' + (++_uid);
    panel.setAttribute('aria-labelledby', ttl.id);
    var x = mk('button', 'gs-icon-btn');
    x.type = 'button';
    x.setAttribute('aria-label', T('close'));
    x.innerHTML = icon('danger', 16);
    head.appendChild(ttl);
    head.appendChild(x);
    var body = mk('div', 'gs-dialog-body');
    var foot = mk('div', 'gs-dialog-foot');
    panel.appendChild(head); panel.appendChild(body); panel.appendChild(foot);
    overlay.appendChild(panel);
    var layer = {};
    function onKey(ev) {
      if (!isTopLayer(layer)) return;
      if (ev.key === 'Escape' && o.dismissible !== false) { ev.preventDefault(); userClose(); return; }
      if (ev.key === 'Tab') {
        var f = panel.querySelectorAll(FOCUSABLE);
        if (!f.length) return;
        var first = f[0], last = f[f.length - 1];
        if (ev.shiftKey && (document.activeElement === first || document.activeElement === panel)) { ev.preventDefault(); last.focus(); }
        else if (!ev.shiftKey && document.activeElement === last) { ev.preventDefault(); first.focus(); }
      }
    }
    var shell = {
      overlay: overlay, panel: panel, head: head, title: ttl, body: body, foot: foot, x: x,
      isClosed: function () { return closed; },
      close: function (result) {
        if (closed) return;
        closed = true;
        layerClose(layer);
        document.removeEventListener('keydown', onKey, true);
        if (overlay.parentNode) overlay.parentNode.removeChild(overlay);
        try { if (prevFocus && prevFocus.focus) prevFocus.focus(); } catch (e) {}
        if (typeof o.onClose === 'function') o.onClose(result);
      },
    };
    // While an action is saving, the user can't dismiss the dialog: the write
    // would still land (and onSaved still run) behind a dialog that looked
    // cancelled. A programmatic close() still works.
    function userClose() { if (typeof o.isBusy === 'function' && o.isBusy()) return; shell.close(); }
    x.onclick = userClose;
    if (o.dismissible === false) x.style.display = 'none';
    overlay.addEventListener('mousedown', function (ev) { if (ev.target === overlay && o.dismissible !== false && _downTop === layer) userClose(); });
    layerOpen(layer);
    document.addEventListener('keydown', onKey, true);
    document.body.appendChild(overlay);
    return shell;
  }
  function focusFirst(panel) {
    var f = panel.querySelector('.gs-dialog-body ' + FOCUSABLE.split(', ').join(', .gs-dialog-body ')) || panel;
    try { f.focus(); } catch (e) {}
  }

  // gsDash.dialog({
  //   title, body?: html | Node | function (bodyEl, dlg) -> html|undefined,
  //   actions?: [{ label, kind?, onClick?(dlg) -> Promise|false, close?: true }],   // default: one Close
  //   size?: 'sm'|'md'|'lg'|'xl', width?, dismissible?: true, onClose?(result),
  // }) -> { el, body, close(result?), setTitle(t), setBody(content), setError(msg|null), busy(on) }
  // An action whose onClick returns a Promise shows busy until it settles; a
  // rejection is shown inside the dialog and keeps it open; returning false
  // (or close: false) keeps it open too.
  function dialog(o) {
    o = o || {};
    var saving = false;
    var sh = overlayShell(assign({}, o, { isBusy: function () { return saving; } })), err = null;
    var handle = {
      el: sh.panel, body: sh.body,
      close: function (r) { sh.close(r); },
      setTitle: function (t) { sh.title.textContent = t == null ? '' : String(t); },
      setBody: function (c) { sh.body.innerHTML = ''; nodeOrHtml(sh.body, c); if (err) sh.body.insertBefore(err, sh.body.firstChild); },
      setError: function (msg) {
        if (err && err.parentNode) err.parentNode.removeChild(err);
        err = null;
        if (msg) { err = mk('div'); err.innerHTML = banner(msg, { tone: 'danger' }); err = err.firstChild; sh.body.insertBefore(err, sh.body.firstChild); }
      },
      busy: function (on) {
        saving = !!on;
        var b = sh.foot.querySelectorAll('button'), i;
        for (i = 0; i < b.length; i++) b[i].disabled = !!on;
        sh.panel.setAttribute('aria-busy', on ? 'true' : 'false');
      },
    };
    handle.setTitle(o.title || '');
    if (typeof o.body === 'function') { var h = o.body(sh.body, handle); if (typeof h === 'string') sh.body.innerHTML = h; }
    else nodeOrHtml(sh.body, o.body);
    var actions = o.actions || [{ label: T('close'), kind: 'secondary' }];
    actions.forEach(function (a) {
      var b = button(a.label, a.kind || 'secondary', function () {
        var r;
        handle.setError(null);
        try { r = typeof a.onClick === 'function' ? a.onClick(handle) : undefined; } catch (e) { handle.setError(errText(e)); return; }
        if (r && typeof r.then === 'function') {
          handle.busy(true);
          r.then(function (v) { handle.busy(false); if (v !== false && a.close !== false) sh.close(v); },
            function (e) { handle.busy(false); logErr('dialog', e); handle.setError(errText(e)); });
          return;
        }
        if (r !== false && a.close !== false) sh.close(r);
      });
      sh.foot.appendChild(b);
    });
    sh.foot.style.display = actions.length ? '' : 'none';
    focusFirst(sh.panel);
    return handle;
  }

  // gsDash.formDialog({ title, table?, fields?, record?, submit, params?, onSaved?(result, values, mode),
  //                     submitLabel?, columns?: 1|2, size? }) -> dialog handle (+ form)
  // A gsDash.form inside a dialog: Save / Cancel sit in the footer, a
  // successful save closes it, a failed one keeps it open with the error.
  function formDialog(o) {
    o = o || {};
    var f = null;
    var sh = overlayShell({ size: o.size || (o.columns === 2 ? 'lg' : 'md'), onClose: o.onClose, isBusy: function () { return !!(f && f.isBusy()); } });
    sh.title.textContent = o.title || '';
    sh.panel.className += ' gs-dialog-form';
    f = form(sh.body, {
      table: o.table, fields: o.fields, record: o.record, submit: o.submit, params: o.params,
      submitLabel: o.submitLabel || T('save'), columns: o.columns, resetOnAdd: false,
      cancel: function () { if (!(f && f.isBusy())) sh.close(); },  // not mid-save, as for Esc / ✕
      onSaved: function (res, values, mode) {
        if (typeof o.onSaved === 'function') o.onSaved(res, values, mode);
        sh.close(res);
      },
    });
    // The form's own action row moves into the dialog footer, with Save
    // moved last in the DOM (not just visually), so Tab order, the
    // accessibility tree and the screen all read Cancel, then Save.
    function hoist() {
      var acts = sh.body.querySelector('.gs-form-actions');
      if (acts && acts.parentNode !== sh.foot) {
        sh.foot.innerHTML = '';
        var save = acts.querySelector('button[type=submit]');
        if (save) acts.appendChild(save);
        sh.foot.appendChild(acts);
      }
    }
    hoist();
    if (f && f.ready && f.ready.then) f.ready.then(function () { hoist(); focusFirst(sh.panel); }, function () {});
    focusFirst(sh.panel);
    return { el: sh.panel, body: sh.body, form: f, close: function (r) { sh.close(r); } };
  }

  // ── Menu ───────────────────────────────────────────────────────────────
  // gsDash.menu(anchorEl, [{ label, onClick?(), kind?: 'danger', disabled?, divider? }], { align?: 'end' })
  //   -> { close() }   Opens under the anchor; Esc / outside click closes; arrow keys move.
  var _openMenu = null;
  function menu(anchor, items, o) {
    o = o || {};
    if (_openMenu) _openMenu.close();
    if (typeof anchor === 'string') anchor = document.querySelector(anchor);
    var box = mk('div', 'gs-menu');
    box.setAttribute('role', 'menu');
    (items || []).forEach(function (it) {
      if (it.divider) { box.appendChild(mk('div', 'gs-menu-div')); return; }
      var b = mk('button', 'gs-menu-item' + (it.kind === 'danger' ? ' gs-menu-danger' : ''), it.label);
      b.type = 'button';
      b.setAttribute('role', 'menuitem');
      if (it.disabled) b.disabled = true;
      b.onclick = function () { close(); if (typeof it.onClick === 'function') it.onClick(); };
      box.appendChild(b);
    });
    document.body.appendChild(box);
    var r = anchor ? anchor.getBoundingClientRect() : { left: 0, right: 0, bottom: 0, top: 0 };
    var w = box.offsetWidth || 180, h = box.offsetHeight || 0, vw = window.innerWidth || 1024, vh = window.innerHeight || 768;
    var left = o.align === 'start' ? r.left : r.right - w;
    left = Math.max(8, Math.min(left, vw - w - 8));
    var top = r.bottom + 4;
    if (top + h > vh - 8 && r.top - h - 4 > 8) top = r.top - h - 4;
    box.style.left = left + 'px';
    box.style.top = top + 'px';
    if (anchor) anchor.setAttribute('aria-expanded', 'true');
    function itemsEls() { return Array.prototype.slice.call(box.querySelectorAll('.gs-menu-item:not([disabled])')); }
    function onDoc(e) { if (_downTop === layer && !box.contains(e.target) && e.target !== anchor && !(anchor && anchor.contains(e.target))) close(); }
    var layer = {};
    function onKey(e) {
      if (!isTopLayer(layer)) return;
      var list = itemsEls(), i = list.indexOf(document.activeElement);
      if (e.key === 'Escape') { e.preventDefault(); close(); try { anchor.focus(); } catch (er) {} }
      else if (e.key === 'ArrowDown') { e.preventDefault(); (list[(i + 1) % list.length] || list[0]).focus(); }
      else if (e.key === 'ArrowUp') { e.preventDefault(); (list[(i - 1 + list.length) % list.length] || list[0]).focus(); }
      else if (e.key === 'Tab') close();
    }
    layerOpen(layer);
    document.addEventListener('mousedown', onDoc, true);
    document.addEventListener('keydown', onKey, true);
    window.addEventListener('scroll', close, true);
    var closed = false;
    function close() {
      if (closed) return;
      closed = true;
      layerClose(layer);
      document.removeEventListener('mousedown', onDoc, true);
      document.removeEventListener('keydown', onKey, true);
      window.removeEventListener('scroll', close, true);
      if (box.parentNode) box.parentNode.removeChild(box);
      if (anchor) anchor.setAttribute('aria-expanded', 'false');
      if (_openMenu === handle) _openMenu = null;
    }
    var handle = { el: box, close: close };
    _openMenu = handle;
    var first = itemsEls()[0];
    if (first && o.focus !== false) try { first.focus(); } catch (e) {}
    return handle;
  }
  function moreButton(label) {
    var b = mk('button', 'gs-icon-btn gs-more');
    b.type = 'button';
    b.setAttribute('aria-haspopup', 'menu');
    b.setAttribute('aria-label', label || T('actions'));
    b.innerHTML = icon('more', 16);
    return b;
  }

  // ── Navigation: segmented / tabs / periodNav / steps ────────────────────
  // gsDash.segmented(el, { options: ['day', { value: 'week', label: 'Week' }], value? (null: none picked yet), onChange(value), size?: 'sm' })
  //   -> { el, value(), set(v) }
  function segmented(el, o) {
    el = elOf(el, 'segmented');
    o = o || {};
    // value: null starts with nothing picked (a question, not a default);
    // leaving it out picks the first option.
    var opts = o.options || [], cur = o.value !== undefined ? o.value : (opts.length ? optValue(opts[0]) : null);
    var root = mk('div', 'gs-seg' + (o.size === 'sm' ? ' gs-seg-sm' : ''));
    root.setAttribute('role', 'radiogroup');
    if (o.label) root.setAttribute('aria-label', o.label);
    function render() {
      root.innerHTML = '';
      var none = cur == null;
      opts.forEach(function (op, j) {
        var v = optValue(op), on = !none && String(v) === String(cur);
        var b = mk('button', 'gs-seg-btn' + (on ? ' is-on' : ''), String(optLabel(op)));
        b.type = 'button';
        b.setAttribute('role', 'radio');
        b.setAttribute('aria-checked', on ? 'true' : 'false');
        b.tabIndex = on || (none && j === 0) ? 0 : -1;
        b.onclick = function () { set(v, true); };
        root.appendChild(b);
      });
    }
    function set(v, emit) {
      var changed = String(v) !== String(cur);
      cur = v;
      render();
      if (emit && changed && typeof o.onChange === 'function') o.onChange(v);
    }
    root.addEventListener('keydown', function (e) {
      if (e.key !== 'ArrowRight' && e.key !== 'ArrowLeft') return;
      e.preventDefault();
      var i = 0;
      opts.forEach(function (op, j) { if (String(optValue(op)) === String(cur)) i = j; });
      i = (i + (e.key === 'ArrowRight' ? 1 : opts.length - 1)) % opts.length;
      set(optValue(opts[i]), true);
      var btn = root.children[i];
      if (btn) btn.focus();
    });
    render();
    el.appendChild(root);
    return { el: root, value: function () { return cur; }, set: function (v) { set(v, false); }, destroy: function () { if (root.parentNode) root.parentNode.removeChild(root); } };
  }

  // Chart.js canvases drawn inside a hidden panel are 0×0; redraw on show.
  function resizeChartsIn(node) {
    try {
      var C = window.Chart;
      if (!C || typeof C.getChart !== 'function') return;
      var cs = node.querySelectorAll('canvas');
      for (var i = 0; i < cs.length; i++) { var ch = C.getChart(cs[i]); if (ch) ch.resize(); }
    } catch (e) {}
  }
  // gsDash.tabs(el, {
  //   tabs: [{ key, label, count?, panel?: '#sel' | Node, render?(panelEl) }],   // render runs on first show
  //   value?, hash?: true | 'tab',           // remember the tab in location.hash (#tab=key)
  //   variant?: 'line' | 'pill', onChange?(key),
  // }) -> { el, value(), set(key), setCount(key, n), panel(key), destroy() }
  function tabs(el, o) {
    el = elOf(el, 'tabs');
    o = o || {};
    var list = o.tabs || [], hashKey = o.hash ? (typeof o.hash === 'string' ? o.hash : 'tab') : null;
    var root = mk('div', 'gs-tabs' + (o.variant === 'pill' ? ' gs-tabs-pill' : ''));
    var bar = mk('div', 'gs-tabs-bar');
    bar.setAttribute('role', 'tablist');
    var panels = mk('div', 'gs-tabs-panels');
    root.appendChild(bar); root.appendChild(panels);
    var btns = {}, pans = {}, rendered = {}, cur = null, uid = 'gst' + (++_uid);
    function fromHash() {
      if (!hashKey) return null;
      var m = new RegExp('[#&]' + hashKey + '=([^&]+)').exec(location.hash || '');
      return m ? decodeURIComponent(m[1]) : null;
    }
    list.forEach(function (t, i) {
      var b = mk('button', 'gs-tab');
      b.type = 'button';
      b.id = uid + '-t' + i;
      b.setAttribute('role', 'tab');
      b.innerHTML = esc(t.label != null ? t.label : humanize(t.key)) + '<span class="gs-tab-count"' + (t.count == null ? ' hidden' : '') + '>' + esc(t.count == null ? '' : t.count) + '</span>';
      b.onclick = function () { set(t.key, true); };
      bar.appendChild(b);
      btns[t.key] = b;
      var p = t.panel ? (typeof t.panel === 'string' ? document.querySelector(t.panel) : t.panel) : null;
      if (!p) { p = mk('div', 'gs-tab-panel'); panels.appendChild(p); }
      else p.classList.add('gs-tab-panel');
      p.id = p.id || uid + '-p' + i;
      p.setAttribute('role', 'tabpanel');
      p.setAttribute('aria-labelledby', b.id);
      b.setAttribute('aria-controls', p.id);
      pans[t.key] = p;
    });
    function set(key, emit) {
      var t = null;
      list.forEach(function (x) { if (String(x.key) === String(key)) t = x; });
      if (!t) return;
      cur = t.key;
      list.forEach(function (x) {
        var on = x === t;
        btns[x.key].classList.toggle('is-on', on);
        btns[x.key].setAttribute('aria-selected', on ? 'true' : 'false');
        btns[x.key].tabIndex = on ? 0 : -1;
        pans[x.key].hidden = !on;
      });
      if (!rendered[t.key] && typeof t.render === 'function') {
        rendered[t.key] = true;
        try { var h = t.render(pans[t.key]); if (typeof h === 'string') pans[t.key].innerHTML = h; } catch (e) { logErr('tabs', e); pans[t.key].innerHTML = banner(errText(e), { tone: 'danger' }); }
      }
      resizeChartsIn(pans[t.key]);
      if (hashKey) {
        try {
          var h2 = (location.hash || '').replace(new RegExp('[#&]?' + hashKey + '=[^&]*'), '').replace(/^#&?/, '');
          history.replaceState(null, '', '#' + (h2 ? h2 + '&' : '') + hashKey + '=' + encodeURIComponent(t.key));
        } catch (e) {}
      }
      if (emit && typeof o.onChange === 'function') o.onChange(t.key);
    }
    bar.addEventListener('keydown', function (e) {
      if (e.key !== 'ArrowRight' && e.key !== 'ArrowLeft' && e.key !== 'Home' && e.key !== 'End') return;
      e.preventDefault();
      var i = 0;
      list.forEach(function (x, j) { if (x.key === cur) i = j; });
      i = e.key === 'Home' ? 0 : e.key === 'End' ? list.length - 1 : (i + (e.key === 'ArrowRight' ? 1 : list.length - 1)) % list.length;
      set(list[i].key, true);
      btns[list[i].key].focus();
    });
    el.appendChild(root);
    var start = fromHash();
    set(start != null && btns[start] ? start : (o.value != null ? o.value : (list[0] && list[0].key)), false);
    return {
      el: root,
      value: function () { return cur; },
      set: function (k) { set(k, true); },
      setCount: function (k, n) { var c = btns[k] && btns[k].querySelector('.gs-tab-count'); if (c) { c.textContent = n == null ? '' : String(n); c.hidden = n == null; } },
      panel: function (k) { return pans[k]; },
      destroy: function () { if (root.parentNode) root.parentNode.removeChild(root); },
    };
  }

  function ymd(d) { return d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate()); }
  // A calendar day (local midnight) from a date-ish value, or null when it is
  // not one. Data cells and calendar rows use this, so a bad value never
  // shows as today; parseDay is for navigation inputs, where today is right.
  function toDay(s) {
    if (s instanceof Date) return isNaN(s.getTime()) ? null : new Date(s.getFullYear(), s.getMonth(), s.getDate());
    if (s == null || s === '') return null;
    s = String(s);
    // A bare date or a zone-less timestamp names a calendar day: keep its
    // digits. One with a zone ("…T23:30:00+00:00", timestamptz) is an
    // instant, shown on the viewer's local day.
    var m = /^(\d{4})-(\d{2})-(\d{2})(?:[T ]\d{2}:\d{2}(?::\d{2}(?:\.\d+)?)?)?$/.exec(s);
    if (m) return new Date(+m[1], +m[2] - 1, +m[3]);
    var z = /^(\d{4}-\d{2}-\d{2})[T ](\d{2}:\d{2}(?::\d{2}(?:\.\d+)?)?)\s*(Z|[+-]\d{2}(?::?\d{2})?)$/i.exec(s);
    // Postgres writes "+09" and a space; Date wants "+09:00" and a "T".
    var d = new Date(z ? z[1] + 'T' + z[2] + (/^z$/i.test(z[3]) ? 'Z' : z[3].length === 3 ? z[3] + ':00' : z[3].replace(/^([+-]\d{2})(\d{2})$/, '$1:$2')) : s);
    if (isNaN(d.getTime())) {
      m = /^(\d{4})-(\d{2})-(\d{2})/.exec(s);
      return m ? new Date(+m[1], +m[2] - 1, +m[3]) : null;
    }
    return new Date(d.getFullYear(), d.getMonth(), d.getDate());
  }
  function parseDay(s) { return toDay(s) || toDay(new Date()); }
  function addDays(d, n) { var x = new Date(d.getTime()); x.setDate(x.getDate() + n); return x; }
  function startOfWeek(d, ws) { var x = parseDay(d); return addDays(x, -((x.getDay() - ws + 7) % 7)); }
  function weekStartDefault() { return uiLang() === 'en' || uiLang() === 'ja' || uiLang() === 'ko' ? 0 : 1; }
  function fmtDate(d, opt) { try { return d.toLocaleDateString(locale(), opt); } catch (e) { return ymd(d); } }
  // { from, to } (inclusive YYYY-MM-DD) for a period containing date d.
  function periodOf(unit, d, ws) {
    d = parseDay(d);
    if (unit === 'day') return { from: ymd(d), to: ymd(d), label: fmtDate(d, { year: 'numeric', month: 'short', day: 'numeric', weekday: 'short' }) };
    if (unit === 'week') {
      var s = startOfWeek(d, ws), e = addDays(s, 6);
      return { from: ymd(s), to: ymd(e), label: fmtDate(s, { month: 'short', day: 'numeric' }) + ' – ' + fmtDate(e, { month: s.getMonth() === e.getMonth() ? undefined : 'short', day: 'numeric', year: 'numeric' }) };
    }
    if (unit === 'quarter') {
      var q = Math.floor(d.getMonth() / 3), qs = new Date(d.getFullYear(), q * 3, 1), qe = new Date(d.getFullYear(), q * 3 + 3, 0);
      return { from: ymd(qs), to: ymd(qe), label: d.getFullYear() + ' Q' + (q + 1) };
    }
    if (unit === 'year') return { from: d.getFullYear() + '-01-01', to: d.getFullYear() + '-12-31', label: String(d.getFullYear()) };
    var ms = new Date(d.getFullYear(), d.getMonth(), 1), me = new Date(d.getFullYear(), d.getMonth() + 1, 0);
    return { from: ymd(ms), to: ymd(me), label: fmtDate(ms, { year: 'numeric', month: 'long' }) };
  }
  function shiftPeriod(unit, d, n) {
    d = parseDay(d);
    if (unit === 'day') return addDays(d, n);
    if (unit === 'week') return addDays(d, 7 * n);
    if (unit === 'quarter') return new Date(d.getFullYear(), d.getMonth() + 3 * n, 1);
    if (unit === 'year') return new Date(d.getFullYear() + n, 0, 1);
    return new Date(d.getFullYear(), d.getMonth() + n, 1);
  }
  // gsDash.periodNav(el, { unit?: 'day'|'week'|'month'|'quarter'|'year', value?: date, units?: ['week','month'],
  //                       weekStart?: 0|1, onChange({ from, to, label, unit, date }) })
  //   -> { el, value(), set(date), setUnit(unit) }      ‹  Nov 2026  ›  Today   [Week|Month]
  function periodNav(el, o) {
    el = elOf(el, 'periodNav');
    o = o || {};
    var unit = o.unit || 'month', date = parseDay(o.value || new Date()), ws = o.weekStart != null ? o.weekStart : weekStartDefault();
    var root = mk('div', 'gs-pnav');
    var prev = mk('button', 'gs-icon-btn'); prev.type = 'button'; prev.innerHTML = icon('chevL'); prev.setAttribute('aria-label', T('prev'));
    var next = mk('button', 'gs-icon-btn'); next.type = 'button'; next.innerHTML = icon('chevR'); next.setAttribute('aria-label', T('next'));
    var lbl = mk('div', 'gs-pnav-label');
    lbl.setAttribute('aria-live', 'polite');
    var today = button(T('today'), 'secondary', function () { go(new Date()); });
    root.appendChild(prev); root.appendChild(lbl); root.appendChild(next); root.appendChild(today);
    var seg = null;
    if (o.units && o.units.length > 1) {
      var sw = mk('div', 'gs-pnav-units');
      root.appendChild(sw);
      seg = segmented(sw, { size: 'sm', value: unit, options: o.units.map(function (u) { return { value: u, label: T(u) !== u ? T(u) : humanize(u) }; }), onChange: function (u) { unit = u; go(date); } });
    }
    function state() { return assign({ unit: unit, date: ymd(date) }, periodOf(unit, date, ws)); }
    function go(d) {
      date = parseDay(d);
      var st = state();
      lbl.textContent = st.label;
      if (typeof o.onChange === 'function') o.onChange(st);
    }
    prev.onclick = function () { go(shiftPeriod(unit, date, -1)); };
    next.onclick = function () { go(shiftPeriod(unit, date, 1)); };
    el.appendChild(root);
    lbl.textContent = state().label;
    return {
      el: root, value: state,
      set: function (d) { go(d); },
      setUnit: function (u) { unit = u; if (seg) seg.set(u); go(date); },
      destroy: function () { if (root.parentNode) root.parentNode.removeChild(root); },
    };
  }
  // Preset date range → { from, to } relative to today ('' = open).
  function presetRange(p) {
    var t = new Date(), today = ymd(t);
    if (p === '7d' || p === '30d' || p === '90d') return { from: ymd(addDays(t, -(parseInt(p, 10) - 1))), to: today };
    if (p === 'mtd') return { from: ymd(new Date(t.getFullYear(), t.getMonth(), 1)), to: today };
    if (p === 'qtd') return { from: ymd(new Date(t.getFullYear(), Math.floor(t.getMonth() / 3) * 3, 1)), to: today };
    if (p === 'ytd') return { from: t.getFullYear() + '-01-01', to: today };
    return { from: '', to: '' };
  }

  var STEP_STATUS = { done: 1, current: 1, todo: 1, error: 1 };
  // gsDash.steps(['Draft', 'Review', { label: 'Approved', sub: 'by finance' }], current, { vertical? }) -> html
  // current: index (0-based) or the label/key of the active step; past steps show done.
  function steps(list, current, o) {
    o = o || {};
    list = list || [];
    var ci = typeof current === 'number' ? current : -1;
    if (ci < 0) list.forEach(function (s, i) { var k = isPlain(s) ? (s.key != null ? s.key : s.label) : s; if (String(k) === String(current)) ci = i; });
    var h = '<ol class="gs-steps' + (o.vertical ? ' gs-steps-v' : '') + '">';
    list.forEach(function (s, i) {
      var label = isPlain(s) ? s.label : s, sub = isPlain(s) ? s.sub : null, st = i < ci ? 'done' : i === ci ? 'current' : 'todo';
      if (isPlain(s) && STEP_STATUS[s.status]) st = s.status;  // it lands in a class attribute
      h += '<li class="gs-step gs-step-' + st + '"' + (st === 'current' ? ' aria-current="step"' : '') + '><span class="gs-step-dot">' + (st === 'done' ? icon('success', 12) : st === 'error' ? icon('danger', 12) : (i + 1)) + '</span>' +
        '<span class="gs-step-txt"><span class="gs-step-label">' + esc(label) + '</span>' + (sub ? '<span class="gs-step-sub">' + esc(sub) + '</span>' : '') + '</span></li>';
    });
    return h + '</ol>';
  }

  // ── Display: descriptions / timeline / funnel / heatmap ─────────────────

  // gsDash.descriptions(record, fields?, { columns?: 1|2 }) -> html   (same field spec as detailDrawer)
  function descriptions(record, fields, o) {
    o = o || {};
    record = record || {};
    var list = (fields || Object.keys(record)).map(function (s) { return typeof s === 'string' ? { key: s } : s; });
    var h = '<dl class="gs-dl gs-desc' + (o.columns === 2 ? ' gs-desc-2' : '') + '">';
    list.forEach(function (f) { h += '<div class="gs-desc-item"><dt>' + esc(labelOf(f)) + '</dt><dd>' + cellOf(f, record) + '</dd></div>'; });
    return h + '</dl>';
  }
  // gsDash.timeline(rows, { time: 'created_at'|fn, title: 'event'|fn, sub?, tone?: key|fn, timeFmt?: fn, empty? }) -> html
  function timeline(rows, o) {
    o = o || {};
    rows = rows || [];
    if (!rows.length) return empty({ title: o.empty || T('noData'), icon: 'calendar' });
    function val(spec, r) { return spec == null ? '' : typeof spec === 'function' ? spec(r) : r[spec]; }
    var h = '<ol class="gs-tl">';
    rows.forEach(function (r) {
      var tv = val(o.time || 'time', r), tone = val(o.tone, r);
      var tt = o.timeFmt ? o.timeFmt(tv, r) : (tv ? (relTimeOk(tv) ? relTime(tv) : String(tv)) : '');
      tone = tone ? (TONES[tone] ? tone : statusTone(tone)) : 'brand';
      h += '<li class="gs-tl-item gs-tone-' + tone + '"><span class="gs-tl-dot"></span><div class="gs-tl-main"><div class="gs-tl-head"><span class="gs-tl-title">' + esc(val(o.title || 'title', r)) + '</span><span class="gs-tl-time num" title="' + esc(tv) + '">' + esc(tt) + '</span></div>' +
        (o.sub ? '<div class="gs-tl-sub">' + esc(val(o.sub, r)) + '</div>' : '') + (typeof o.render === 'function' ? '<div class="gs-tl-body">' + String(o.render(r)) + '</div>' : '') + '</div></li>';
    });
    return h + '</ol>';
  }
  function relTimeOk(v) { return !isNaN(new Date(v).getTime()) && /\d{4}-\d{2}-\d{2}/.test(String(v)); }
  // gsDash.funnel(rows, { label?: 'stage', value?: 'count', fmt?, title? }) -> html
  // Bars shrink with the value; between steps, the step conversion (and overall %) shows.
  function funnel(rows, o) {
    o = o || {};
    rows = rows || [];
    if (!rows.length) return empty({ icon: 'chart' });
    var lk = o.label || 'label', vk = o.value || 'value', top = num(rows[0][vk]) || 1, f = o.fmt || function (v) { return fmtNum(v); };
    var h = '<div class="gs-funnel">';
    rows.forEach(function (r, i) {
      var v = num(r[vk]), w = Math.max(2, v / top * 100);
      if (i) {
        var prev = num(rows[i - 1][vk]), conv = prev ? v / prev * 100 : 0;
        h += '<div class="gs-fn-conv">' + icon('down', 12) + '<span class="num">' + fmtNum(conv, { digits: 1 }) + '%</span><span class="gs-fn-conv-lbl">' + esc(T('conversion')) + '</span></div>';
      }
      h += '<div class="gs-fn-row"><div class="gs-fn-label">' + esc(humanize(r[lk])) + '</div><div class="gs-fn-track"><div class="gs-fn-bar" style="width:' + w.toFixed(2) + '%;background:' + vizRef(0) + '"><span class="num">' + esc(f(v)) + '</span></div></div>' +
        '<div class="gs-fn-pct num">' + fmtNum(v / top * 100, { digits: v / top * 100 < 10 ? 1 : 0 }) + '%</div></div>';
    });
    return h + '</div>';
  }
  // gsDash.heatmap({ rows, x: 'week', y: 'cohort', value: 'retention', fmt?, xOrder?, yOrder?,
  //                  tone?: 'brand'|'success'|'danger'|'warn', min?, max?, showValues?: true, xLabel?, yLabel? }) -> html
  // A CSS grid (no canvas): one cell per (y, x), shaded from the token colour.
  function heatmap(o) {
    o = o || {};
    var rows = o.rows || [], xk = o.x || 'x', yk = o.y || 'y', vk = o.value || 'value';
    if (!rows.length) return empty({ icon: 'chart' });
    var xs = o.xOrder || distinctOptions(rows, xk), ys = o.yOrder || [], seenY = {}, cells = {}, mn = Infinity, mx = -Infinity;
    if (!o.yOrder) rows.forEach(function (r) { var y = r[yk]; if (y != null && !seenY['$' + y]) { seenY['$' + y] = 1; ys.push(y); } });
    if (!o.xOrder && rows.length && typeof rows[0][xk] === 'number') xs.sort(function (a, b) { return a - b; });
    rows.forEach(function (r) {
      var v = r[vk];
      if (v == null || v === '' || !isFinite(Number(v))) return;
      v = Number(v);
      cells[r[yk] + '\u0000' + r[xk]] = v;
      if (v < mn) mn = v; if (v > mx) mx = v;
    });
    if (o.min != null) mn = o.min;
    if (o.max != null) mx = o.max;
    var span = (mx - mn) || 1, col = toneVar(o.tone || 'brand'), f = o.fmt || function (v) { return fmtNum(v); };
    var h = '<div class="gs-hm-wrap"><div class="gs-hm" style="grid-template-columns:minmax(64px,max-content) repeat(' + xs.length + ',minmax(34px,1fr))" role="table">';
    h += '<div class="gs-hm-corner">' + esc(o.yLabel || '') + '</div>';
    xs.forEach(function (x) { h += '<div class="gs-hm-xh" role="columnheader">' + esc(o.xFmt ? o.xFmt(x) : x) + '</div>'; });
    ys.forEach(function (y) {
      h += '<div class="gs-hm-yh" role="rowheader">' + esc(o.yFmt ? o.yFmt(y) : y) + '</div>';
      xs.forEach(function (x) {
        var v = cells[y + '\u0000' + x];
        if (v == null) { h += '<div class="gs-hm-c gs-hm-na" role="cell"></div>'; return; }
        var t = Math.max(0, Math.min(1, (v - mn) / span)), pct = Math.round(8 + t * 84);
        h += '<div class="gs-hm-c' + (t > 0.55 ? ' gs-hm-dark' : '') + '" role="cell" style="background:color-mix(in srgb,' + col + ' ' + pct + '%,var(--ink-0))" title="' + esc(y + ' · ' + x + ': ' + f(v)) + '">' + (o.showValues === false ? '' : esc(f(v))) + '</div>';
      });
    });
    h += '</div><div class="gs-hm-legend"><span class="num">' + esc(f(mn)) + '</span><span class="gs-hm-ramp" style="background:linear-gradient(90deg,color-mix(in srgb,' + col + ' 8%,var(--ink-0)),' + col + ')"></span><span class="num">' + esc(f(mx)) + '</span></div></div>';
    return h;
  }

  // ── KPI v2 ─────────────────────────────────────────────────────────────
  // kpiCard({ label, value, sub?, accent?, delta?: 12.5, deltaLabel?: 'vs last week', goodWhen?: 'up'|'down',
  //           deltaUnit?: '%', tone?: 'success'|'warn'|'danger', spark?: [n...], progress?: 0-100 | { value, max, label },
  //           key? (with kpiRow(el, ...) onClick) })
  function kpiCard2(s) {
    s = s || {};
    // Plain specs keep the original markup, so pages styled against it don't shift.
    if (s.delta == null && !s.spark && s.progress == null && !s.tone && s.key == null && !s.badge) return kpiCard(s);
    var tone = s.tone && TONES[s.tone] ? ' gs-kpi-' + s.tone : '';
    var h = '<div class="gs-card gs-kpi' + tone + (s.key != null ? ' gs-kpi-click" data-kpi="' + esc(s.key) + '" tabindex="0" role="button' : '') + '">' +
      '<div class="gs-kpi-top"><span class="t-small gs-kpi-label"' + lit(s, 'label') + '>' + esc(s.label) + '</span>' + (s.badge ? tag(s.badge, s.badgeTone || statusTone(s.badge)) : '') + '</div>' +
      '<div class="gs-kpi-mid"><div class="t-h1 num ' + (s.accent || '') + '">' + esc(s.value) + '</div>' +
      (s.spark && s.spark.length > 1 ? '<div class="gs-kpi-spark">' + sparkline(s.spark.map(num), s.tone && TONES[s.tone] ? toneVar(s.tone) : null, 84, 28) + '</div>' : '') + '</div>';
    if (s.progress != null) {
      var p = isPlain(s.progress) ? s.progress : { value: s.progress };
      h += '<div class="gs-kpi-prog">' + bar(p.value, { max: p.max, tone: s.tone || 'brand', label: p.label != null ? p.label : undefined, target: p.target }) + '</div>';
    }
    if (s.delta != null || s.sub) {
      h += '<div class="t-small gs-kpi-sub">' + (s.delta != null ? delta(s.delta, { goodWhen: s.goodWhen, unit: s.deltaUnit, label: s.deltaLabel }) : '') + (s.sub ? '<span' + lit(s, 'sub') + '>' + esc(s.sub) + '</span>' : '') + '</div>';
    }
    return h + '</div>';
  }
  // kpiRow(specs) -> html (as before), or kpiRow(el, specs, { onClick(key, spec) }) -> { el, set(specs) }
  function kpiRow2(a, b, c) {
    if (isArr(a) || a == null) {
      var specs = a || [], n = Math.max(1, Math.min(specs.length, 5));
      return '<div class="gs-kpis" style="--gs-kpi-cols:' + n + '">' + specs.map(kpiCard2).join('') + '</div>';
    }
    var el = elOf(a, 'kpiRow'), o = c || {}, cur = b || [];
    function render() { el.innerHTML = kpiRow2(cur); }
    function fire(t) {
      var card = t && t.closest ? t.closest('.gs-kpi-click') : null;
      if (!card || typeof o.onClick !== 'function') return;
      var k = card.getAttribute('data-kpi'), spec = null;
      cur.forEach(function (s) { if (String(s.key) === k) spec = s; });
      o.onClick(k, spec);
    }
    function onClickEv(e) { fire(e.target); }
    function onKeyEv(e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); fire(e.target); } }
    // Mounting again on the same element (a refresh) replaces the old row's
    // listeners instead of stacking a second onClick.
    if (el.__gsKpiRow) el.__gsKpiRow.destroy();
    el.addEventListener('click', onClickEv);
    el.addEventListener('keydown', onKeyEv);
    render();
    var handle = {
      el: el,
      set: function (s) { cur = s || []; render(); },
      destroy: function () {
        el.removeEventListener('click', onClickEv);
        el.removeEventListener('keydown', onKeyEv);
        if (el.__gsKpiRow === handle) el.__gsKpiRow = null;
      },
    };
    el.__gsKpiRow = handle;
    return handle;
  }

  // ── Section card with header actions ───────────────────────────────────
  // gsDash.section(el, { title, sub?, badge?, actions?: [{ label, kind?, onClick }] | Node, body?: html|Node })
  //   -> { el, head, body, tools }   (tools = right side of the header: mount segmented/periodNav there)
  function section(el, o) {
    el = elOf(el, 'section');
    o = o || {};
    var card = mk('div', 'gs-card gs-section');
    var head = mk('div', 'gs-phead gs-sec-head');
    var left = mk('div');
    left.innerHTML = '<div class="t-h3">' + esc(o.title || '') + '</div>' + (o.sub ? '<div class="t-small">' + esc(o.sub) + '</div>' : '');
    var tools = mk('div', 'gs-sec-tools');
    if (o.badge) tools.innerHTML = '<span class="t-small" style="color:var(--ink-400)">' + esc(o.badge) + '</span>';
    if (isArr(o.actions)) o.actions.forEach(function (a) { tools.appendChild(button(a.label, a.kind || 'secondary', function () { if (a.onClick) a.onClick(); })); });
    else if (o.actions && o.actions.nodeType) tools.appendChild(o.actions);
    head.appendChild(left); head.appendChild(tools);
    var body = mk('div', 'gs-sec-body');
    nodeOrHtml(body, o.body);
    card.appendChild(head); card.appendChild(body);
    el.appendChild(card);
    return { el: card, head: head, body: body, tools: tools };
  }

  // ── Read-only table ────────────────────────────────────────────────────
  // Cell types beyond the form's: money, pct (12.3 -> 12.3%), ratio (0.123 -> 12.3%),
  // delta (signed, coloured), bar (inline meter; max = column max unless given), badge.
  function cellOf(f, row, ctx) {
    if (typeof f.render === 'function') return String(f.render(row));
    var v = row[f.key], t = f.type;
    if (typeof f.format === 'function') return esc(f.format(v, row));
    if (f.badge || t === 'badge') return v == null || v === '' ? '<span class="gs-muted">—</span>' : tag(humanize(v), f.tone ? (typeof f.tone === 'function' ? f.tone(v, row) : f.tone) : statusTone(v));
    if (v == null || v === '') return '<span class="gs-muted">—</span>';
    // exact unless the column rounds on purpose (digits, compact) or the
    // value is an average (aggRow passes exact: false).
    var exact = f.exact !== false;
    if (t === 'money') return esc(fmtNum(v, { currency: f.currency || 'USD', digits: f.digits, compact: f.compact, exact: exact }));
    if (t === 'number' || t === 'integer') return esc(fmtNum(v, { digits: f.digits, compact: f.compact, exact: exact }));
    if (t === 'pct') return esc(fmtNum(v, { digits: f.digits != null ? f.digits : 1 }) + '%');
    if (t === 'ratio') return esc(fmtNum(Number(v) * 100, { digits: f.digits != null ? f.digits : 1 }) + '%');
    if (t === 'delta') return delta(v, { goodWhen: f.goodWhen, unit: f.unit });
    if (t === 'bar') return bar(v, { max: f.max != null ? f.max : (ctx && ctx.max && ctx.max[f.key]) || 100, tone: typeof f.tone === 'function' ? f.tone(v, row) : f.tone, fmt: f.fmt || (f.max == null && ctx && ctx.max && ctx.max[f.key] ? function (x) { return fmtNum(x); } : null) });
    if (t === 'date') { var dd = toDay(v); return esc(dd ? fmtDate(dd, { year: 'numeric', month: 'short', day: 'numeric' }) : String(v)); }
    if (t === 'datetime') { var d = new Date(v); return esc(isNaN(d.getTime()) ? String(v) : d.toLocaleString(locale(), { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })); }
    if (t === 'relative') return '<span title="' + esc(v) + '">' + esc(relTime(v)) + '</span>';
    return esc(displayText(f, v));
  }
  var NUMERIC = { number: 1, integer: 1, money: 1, pct: 1, ratio: 1, delta: 1 };
  // NULLs are skipped, as in SQL: Number(null) and Number('') are 0, which
  // would pull an average toward 0 and make 0 the minimum.
  function aggregate(how, vals) {
    var present = vals.filter(function (v) { return v != null && v !== ''; });
    var ns = present.map(Number).filter(function (n) { return isFinite(n); });
    if (how === 'count') return present.length;
    if (!ns.length) return null;
    if (how === 'avg') return ns.reduce(function (a, b) { return a + b; }, 0) / ns.length;
    if (how === 'min') return Math.min.apply(null, ns);
    if (how === 'max') return Math.max.apply(null, ns);
    return ns.reduce(function (a, b) { return a + b; }, 0);
  }
  // gsDash.table(el, {
  //   columns: ['name', { key: 'amount', type: 'money', label? }, { key: 'progress', type: 'bar' }, ...],
  //           // type: text|number|integer|money|pct|ratio|delta|bar|badge|date|datetime|relative
  //           // plus label, align, width, format(v,row), render(row) -> html, sortable (default true), tone
  //   rows? | query?, params? | fetchPage?,
  //   search?: true | ['name'], chips?: { key, options?, all? }, dateRange?: { key, presets? },
  //   onRowClick?(row), rowTone?(row) -> 'danger'|'warn'|'success'|null,
  //   totals?: true | ['amount'] | { amount: 'sum', price: 'avg' },   // footer row
  //   groupBy?: 'region' (group header rows with counts and subtotals),
  //   actions?: [{ label, kind?, onClick(row) }]                   // ≤2 inline, more → ⋯ menu
  //   sort?: { key, dir: 'asc'|'desc' }, pageSize?: 100, maxHeight?: '520px', dense?, empty?,
  // }) -> { el, ready, rows(), setRows(rows), refresh(), destroy() }
  function table(el, o) {
    el = elOf(el, 'table');
    o = o || {};
    if (!o.columns || !o.columns.length) throw new Error('gsDash.table: columns is required');
    var cols = o.columns.map(function (c) { return typeof c === 'string' ? { key: c } : keep(c, assign({}, c)); });
    cols.forEach(function (c) { if (!c.align && NUMERIC[c.type]) c.align = 'right'; });
    var src = rowSource(o), rows = [], view = [], loading = true, failMsg = '', destroyed = false;
    var pageSize = o.pageSize || 100, shown = pageSize;
    var sort = o.sort ? { key: o.sort.key, dir: o.sort.dir === 'desc' ? -1 : 1 } : { key: null, dir: 1 };
    var filt = { q: '', chip: null, from: '', to: '' };
    var root = mk('div', 'gs-tbl' + (o.dense ? ' gs-tbl-dense' : ''));
    var tools = mk('div', 'gs-tbl-tools');
    var scroll = mk('div', 'gs-tbl-scroll');
    if (o.maxHeight) scroll.style.maxHeight = px(o.maxHeight);
    var tbl = mk('table', 'gs-tbl-table');
    var thead = mk('thead'), tbody = mk('tbody'), tfoot = mk('tfoot');
    tbl.appendChild(thead); tbl.appendChild(tbody); tbl.appendChild(tfoot);
    scroll.appendChild(tbl);
    var foot = mk('div', 'gs-tbl-foot');
    var moreBtn = button(T('showMore'), 'ghost', function () { showMore(); });
    foot.appendChild(moreBtn);
    root.appendChild(tools); root.appendChild(scroll); root.appendChild(foot);
    el.innerHTML = '';
    el.appendChild(root);
    var bar_ = null;
    if (o.search || o.chips || o.dateRange) {
      bar_ = filterBar(tools, {
        search: !!o.search,
        chips: o.chips ? { options: o.chips.options || [], all: o.chips.all } : null,
        dateRange: o.dateRange ? { label: o.dateRange.label, presets: o.dateRange.presets, preset: o.dateRange.preset } : null,
        onChange: function (st) { filt = st; shown = pageSize; render(); },
      });
      filt = bar_.value();  // a starting date preset already filled from/to
    } else tools.style.display = 'none';
    var cfg = { searchKeys: isArr(o.search) ? o.search : null, chipKey: o.chips && o.chips.key, dateKey: o.dateRange && o.dateRange.key };
    var acts = o.actions || [];
    function headHtml() {
      var h = '<tr>';
      cols.forEach(function (c, i) {
        var lab = esc(labelOf(c)), on = sort.key === c.key;
        var arrow = on ? '<span class="gs-tbl-arrow">' + (sort.dir > 0 ? '▲' : '▼') + '</span>' : '';
        h += '<th class="gs-tbl-th' + (c.align === 'right' ? ' ta-r' : c.align === 'center' ? ' ta-c' : '') + '"' + (c.width ? ' style="width:' + esc(px(c.width)) + '"' : '') + (on ? ' aria-sort="' + (sort.dir > 0 ? 'ascending' : 'descending') + '"' : '') + '>' +
          (c.sortable === false ? '<span class="gs-tbl-hl"' + lit(c, 'label') + '>' + lab + '</span>' : '<button type="button" class="gs-tbl-sort" data-c="' + i + '"' + lit(c, 'label') + '>' + lab + arrow + '</button>') + '</th>';
      });
      if (acts.length) h += '<th class="gs-tbl-th gs-tbl-actcol"><span class="gs-sr">' + esc(T('actions')) + '</span></th>';
      return h + '</tr>';
    }
    var colMax = {};
    function computeMax() {
      colMax = {};
      cols.forEach(function (c) {
        if (c.type !== 'bar' || c.max != null) return;
        var m = 0;
        rows.forEach(function (r) { var v = Number(r[c.key]); if (isFinite(v) && v > m) m = v; });
        colMax[c.key] = m || 1;
      });
    }
    function totalsSpec() {
      if (!o.totals) return null;
      var spec = {};
      if (o.totals === true) cols.forEach(function (c) { if (NUMERIC[c.type] && c.type !== 'delta' && c.type !== 'pct' && c.type !== 'ratio') spec[c.key] = 'sum'; });
      else if (isArr(o.totals)) o.totals.forEach(function (k) { spec[k] = 'sum'; });
      else spec = o.totals;
      return spec;
    }
    function aggRow(list, spec, label) {
      var h = '';
      cols.forEach(function (c, i) {
        var how = spec[c.key], v = how ? aggregate(how, list.map(function (r) { return r[c.key]; })) : null;
        var inner = i === 0 && !how ? esc(label) : (v == null ? '' : cellOf(assign({}, c, { render: null, format: null, type: c.type === 'bar' ? 'number' : c.type, exact: how !== 'avg' }), (function () { var x = {}; x[c.key] = v; return x; })()));
        h += '<td class="gs-tbl-td' + (c.align === 'right' ? ' ta-r' : '') + '">' + inner + '</td>';
      });
      if (acts.length) h += '<td class="gs-tbl-td"></td>';
      return h;
    }
    function rowHtml(r, i) {
      var tone = typeof o.rowTone === 'function' ? o.rowTone(r) : null;
      var h = '<tr class="gs-tbl-tr' + (o.onRowClick ? ' gs-tbl-click' : '') + (tone ? ' gs-row-' + toneOf(tone) : '') + '" data-i="' + i + '"' + (o.onRowClick ? ' tabindex="0"' : '') + '>';
      cols.forEach(function (c) { h += '<td class="gs-tbl-td' + (c.align === 'right' ? ' ta-r' : c.align === 'center' ? ' ta-c' : '') + (c.type === 'bar' ? ' gs-tbl-barcell' : '') + '">' + cellOf(c, r, { max: colMax }) + '</td>'; });
      if (acts.length) {
        h += '<td class="gs-tbl-td gs-tbl-actcol">';
        if (acts.length <= 2) acts.forEach(function (a, ai) { if (typeof a.show === 'function' && !a.show(r)) return; h += '<button type="button" class="btn btn-sm btn-' + (a.kind || 'ghost') + ' gs-tbl-act" data-a="' + ai + '">' + esc(a.label) + '</button>'; });
        else h += '<button type="button" class="gs-icon-btn gs-tbl-more" aria-haspopup="menu" aria-label="' + esc(T('actions')) + '">' + icon('more', 16) + '</button>';
        h += '</td>';
      }
      return h + '</tr>';
    }
    function render() {
      if (destroyed) return;
      thead.innerHTML = headHtml();
      view = rows.filter(function (r) { return rowMatches(r, filt, cfg); });
      if (sort.key != null) {
        var k = sort.key, d = sort.dir;
        view = view.map(function (r, i) { return { r: r, i: i }; }).sort(function (a, b) { return cmpVals(a.r[k], b.r[k]) * d || a.i - b.i; }).map(function (x) { return x.r; });
      }
      var n = Math.min(view.length, shown), html = '', span = cols.length + (acts.length ? 1 : 0), spec = totalsSpec() || {};
      if (!n) {
        html = '<tr><td class="gs-tbl-msg" colspan="' + span + '">' + (failMsg ? banner(failMsg, { tone: 'danger' }) : loading ? skeleton({ kind: 'table', rows: 4 }) : empty(rows.length ? { title: T('noMatches'), icon: 'search' } : { title: o.empty || T('noData') })) + '</td></tr>';
      } else if (o.groupBy) {
        // Counts and subtotals cover every matching row, like the footer
        // total; paging limits only which rows are drawn under a header.
        var groups = [], byKey = {};
        for (var i = 0; i < view.length; i++) {
          var g = view[i][o.groupBy], gk = '$' + g;
          if (!byKey[gk]) { byKey[gk] = { key: g, items: [] }; groups.push(byKey[gk]); }
          byKey[gk].items.push(i);
        }
        groups.forEach(function (gr) {
          var drawn = gr.items.filter(function (ix) { return ix < n; });
          if (!drawn.length) return;  // appears with "Show more"
          var items = gr.items.map(function (ix) { return view[ix]; });
          html += '<tr class="gs-tbl-group">' + aggRow(items, spec, '') .replace(/^<td class="gs-tbl-td[^"]*">/, '<td class="gs-tbl-td"><span class="gs-tbl-gname">' + esc(gr.key == null || gr.key === '' ? '—' : humanize(gr.key)) + '</span><span class="gs-tbl-gcount">' + gr.items.length + '</span>') + '</tr>';
          drawn.forEach(function (ix) { html += rowHtml(view[ix], ix); });
        });
      } else {
        for (var j = 0; j < n; j++) html += rowHtml(view[j], j);
      }
      tbody.innerHTML = html;
      tfoot.innerHTML = o.totals && n ? '<tr class="gs-tbl-total">' + aggRow(view, spec, T('total')) + '</tr>' : '';
      moreBtn.style.display = view.length > n || src.hasMore() ? '' : 'none';
      foot.style.display = moreBtn.style.display;
    }
    function showMore() {
      if (view.length > shown) { shown += pageSize; render(); return; }
      if (!src.hasMore()) return;
      src.load(false).then(function (more) { rows = rows.concat(more); computeMax(); shown += pageSize; render(); }, function (err) { logErr('table', err); });
    }
    thead.addEventListener('click', function (e) {
      var b = e.target && e.target.closest ? e.target.closest('.gs-tbl-sort') : null;
      if (!b) return;
      var c = cols[Number(b.getAttribute('data-c'))];
      // Numbers start high-to-low, text A→Z; the next click flips, the third clears.
      var first = NUMERIC[c.type] || c.type === 'bar' ? -1 : 1;
      if (sort.key === c.key) { if (sort.dir === first) sort.dir = -first; else sort = { key: null, dir: 1 }; }
      else sort = { key: c.key, dir: first };
      render();
      var again = thead.querySelector('[data-c="' + b.getAttribute('data-c') + '"]');
      if (again) again.focus();
    });
    tbody.addEventListener('click', function (e) {
      var t = e.target;
      if (!t || !t.closest) return;
      var tr = t.closest('.gs-tbl-tr');
      if (!tr) return;
      var r = view[Number(tr.getAttribute('data-i'))];
      if (!r) return;
      var ab = t.closest('.gs-tbl-act');
      if (ab) { e.stopPropagation(); acts[Number(ab.getAttribute('data-a'))].onClick(r); return; }
      var mb = t.closest('.gs-tbl-more');
      if (mb) {
        e.stopPropagation();
        menu(mb, acts.filter(function (a) { return typeof a.show !== 'function' || a.show(r); }).map(function (a) { return { label: a.label, kind: a.kind, onClick: function () { a.onClick(r); } }; }));
        return;
      }
      if (typeof o.onRowClick === 'function') o.onRowClick(r);
    });
    tbody.addEventListener('keydown', function (e) {
      if (e.key !== 'Enter' || typeof o.onRowClick !== 'function') return;
      var tr = e.target && e.target.classList && e.target.classList.contains('gs-tbl-tr') ? e.target : null;
      if (tr) { e.preventDefault(); o.onRowClick(view[Number(tr.getAttribute('data-i'))]); }
    });
    function setRows(next) {
      rows = (next || []).slice();
      loading = false; failMsg = '';
      computeMax();
      if (bar_ && cfg.chipKey && !(o.chips.options && o.chips.options.length)) bar_.setChips(distinctOptions(rows, cfg.chipKey));
      render();
    }
    function refresh() {
      return src.load(true).then(function (r) { if (!destroyed) setRows(r); return handle; }, function (err) {
        logErr('table', err);
        loading = false; failMsg = errText(err);
        render();
        return handle;
      });
    }
    var handle = {
      el: root, ready: null,
      rows: function () { return rows.slice(); },
      visibleRows: function () { return view.slice(); },
      setRows: setRows, refresh: refresh,
      destroy: function () { destroyed = true; if (bar_) bar_.destroy(); if (root.parentNode) root.parentNode.removeChild(root); },
    };
    var follow = followChanges(root, o, refresh);
    handle.setRows = function (r) { if (follow) follow.off(); setRows(r); };
    render();
    handle.ready = refresh();
    return handle;
  }

  // ── Calendar ───────────────────────────────────────────────────────────
  // gsDash.calendar(el, {
  //   rows? | query?, params?,  dateKey: 'due_date', endKey?: 'end_date',
  //   title: 'name' | fn(row), tone?: 'status' | fn(row) -> tone|status,
  //   view?: 'month'|'week', views?: ['month','week'], value?: date, weekStart?: 0|1,
  //   onOpen?(row), onDayClick?(ymd), onRange?({ from, to }) (e.g. refetch with params), maxPerDay?: 3,
  // }) -> { el, ready, set(date), refresh(), rows(), setRows(rows), destroy() }
  function calendar(el, o) {
    el = elOf(el, 'calendar');
    o = o || {};
    var mode = o.view || 'month', ws = o.weekStart != null ? o.weekStart : weekStartDefault(), maxPer = o.maxPerDay || 3;
    var src = rowSource(o), rows = [], loading = true, failMsg = '', destroyed = false, range = null;
    var root = mk('div', 'gs-cal');
    var head = mk('div', 'gs-cal-head');
    var grid = mk('div', 'gs-cal-grid');
    root.appendChild(head); root.appendChild(grid);
    el.innerHTML = '';
    el.appendChild(root);
    var nav = periodNav(head, {
      unit: mode, value: o.value, weekStart: ws, units: o.views || ['month', 'week'],
      onChange: function (st) { mode = st.unit; range = st; if (typeof o.onRange === 'function') o.onRange({ from: st.from, to: st.to }); render(); },
    });
    range = nav.value();
    function val(spec, r) { return spec == null ? '' : typeof spec === 'function' ? spec(r) : r[spec]; }
    function toneFor(r) {
      var t = val(o.tone, r);
      return t ? (TONES[t] ? t : statusTone(t)) : 'brand';
    }
    function gridStart() { var st = nav.value(); return mode === 'week' ? parseDay(st.from) : startOfWeek(parseDay(st.from), ws); }
    // Rows by visible day. A span is clipped to the grid, so a quarter-long
    // event shows on every visible day it covers (no cap, at most 42 steps).
    function byDay() {
      var map = {}, g0 = gridStart(), g1 = addDays(g0, (mode === 'week' ? 7 : 42) - 1);
      rows.forEach(function (r, i) {
        var s = r[o.dateKey || 'date'];
        var d0 = toDay(s);
        if (!d0) return;
        var d1 = (o.endKey && toDay(r[o.endKey])) || d0;
        if (d1 < g0 || d0 > g1) return;
        if (d0 < g0) d0 = g0;
        if (d1 > g1) d1 = g1;
        for (var d = d0; d <= d1; d = addDays(d, 1)) {
          var k = ymd(d);
          (map[k] = map[k] || []).push(i);
        }
      });
      return map;
    }
    function render() {
      if (destroyed) return;
      var st = nav.value(), map = byDay(), today = ymd(new Date()), h = '';
      var start = gridStart();
      var days = mode === 'week' ? 7 : 42, month = parseDay(st.from).getMonth();
      h += '<div class="gs-cal-dow">';
      for (var w = 0; w < 7; w++) h += '<div>' + esc(fmtDate(addDays(start, w), { weekday: 'short' })) + '</div>';
      h += '</div><div class="gs-cal-days' + (mode === 'week' ? ' gs-cal-week' : '') + '">';
      for (var i = 0; i < days; i++) {
        var d = addDays(start, i), k = ymd(d), items = map[k] || [], out = mode === 'month' && d.getMonth() !== month;
        var lim = mode === 'week' ? 50 : maxPer;
        h += '<div class="gs-cal-day' + (out ? ' is-out' : '') + (k === today ? ' is-today' : '') + (d.getDay() === 0 || d.getDay() === 6 ? ' is-wkend' : '') + '" data-d="' + k + '"' + (o.onDayClick ? ' tabindex="0" role="button"' : '') + '>' +
          '<div class="gs-cal-num"><span>' + d.getDate() + '</span></div><div class="gs-cal-evs">';
        items.slice(0, lim).forEach(function (ix) {
          var r = rows[ix];
          h += '<button type="button" class="gs-cal-ev gs-tone-' + toneFor(r) + '" data-r="' + ix + '" title="' + esc(val(o.title || 'title', r)) + '">' + esc(val(o.title || 'title', r)) + '</button>';
        });
        if (items.length > lim) h += '<button type="button" class="gs-cal-more" data-d="' + k + '">+' + (items.length - lim) + ' ' + esc(T('more')) + '</button>';
        h += '</div></div>';
      }
      h += '</div>';
      if (failMsg) h = banner(failMsg, { tone: 'danger' }) + h;
      grid.innerHTML = h;
      grid.setAttribute('aria-busy', loading ? 'true' : 'false');
    }
    grid.addEventListener('click', function (e) {
      var t = e.target;
      if (!t || !t.closest) return;
      var ev = t.closest('.gs-cal-ev');
      if (ev) { e.stopPropagation(); if (typeof o.onOpen === 'function') o.onOpen(rows[Number(ev.getAttribute('data-r'))]); return; }
      var more = t.closest('.gs-cal-more');
      if (more) {
        e.stopPropagation();
        var k = more.getAttribute('data-d'), ids = byDay()[k] || [];
        var dlg = dialog({
          title: fmtDate(parseDay(k), { year: 'numeric', month: 'long', day: 'numeric', weekday: 'short' }), size: 'sm',
          body: '<div class="gs-cal-list">' + ids.map(function (ix) { var r = rows[ix]; return '<button type="button" class="gs-cal-ev gs-tone-' + toneFor(r) + '" data-r="' + ix + '">' + esc(val(o.title || 'title', r)) + '</button>'; }).join('') + '</div>',
        });
        dlg.body.addEventListener('click', function (e2) {
          var b = e2.target && e2.target.closest ? e2.target.closest('.gs-cal-ev') : null;
          if (b && typeof o.onOpen === 'function') { dlg.close(); o.onOpen(rows[Number(b.getAttribute('data-r'))]); }
        });
        return;
      }
      var day = t.closest('.gs-cal-day');
      if (day && typeof o.onDayClick === 'function') o.onDayClick(day.getAttribute('data-d'));
    });
    grid.addEventListener('keydown', function (e) {
      if ((e.key === 'Enter' || e.key === ' ') && e.target.classList && e.target.classList.contains('gs-cal-day') && typeof o.onDayClick === 'function') { e.preventDefault(); o.onDayClick(e.target.getAttribute('data-d')); }
    });
    function setRows(r) { rows = (r || []).slice(); loading = false; failMsg = ''; render(); }
    function refresh() {
      return src.load(true).then(function (r) { if (!destroyed) setRows(r); return handle; }, function (err) { logErr('calendar', err); loading = false; failMsg = errText(err); render(); return handle; });
    }
    var handle = {
      el: root, ready: null,
      set: function (d) { nav.set(d); },
      rows: function () { return rows.slice(); }, setRows: setRows, refresh: refresh,
      range: function () { return nav.value(); },
      destroy: function () { destroyed = true; if (root.parentNode) root.parentNode.removeChild(root); },
    };
    var follow = followChanges(root, o, refresh);
    handle.setRows = function (r) { if (follow) follow.off(); setRows(r); };
    render();
    handle.ready = refresh();
    return handle;
  }

  // ── Kanban ─────────────────────────────────────────────────────────────
  // gsDash.kanban(el, {
  //   rows? | query?, params?, groupKey: 'status',
  //   columns: ['todo', 'doing', { value: 'done', label: 'Done', tone: 'success' }],
  //   title: 'name' | fn, sub?, badge?, meta?: key | fn, render?: fn(row) -> html,
  //   onMove?: 'update_task' | function (row, to, from) -> Promise,   // row already carries the new groupKey
  //   onOpen?(row), idKey?: 'id', empty?,
  // }) -> { el, ready, rows(), setRows(rows), refresh(), destroy() }
  // Drag with mouse/touch (pointer events), or focus a card and press ← / →.
  function kanban(el, o) {
    el = elOf(el, 'kanban');
    o = o || {};
    if (!o.groupKey) throw new Error('gsDash.kanban: groupKey is required');
    var gk = o.groupKey, idKey = o.idKey || 'id', src = rowSource(o), rows = [], loading = true, failMsg = '', destroyed = false;
    var colsDef = (o.columns || []).map(function (c) { return isPlain(c) ? c : { value: c }; });
    var root = mk('div', 'gs-kb');
    el.innerHTML = '';
    el.appendChild(root);
    function val(spec, r) { return spec == null ? '' : typeof spec === 'function' ? spec(r) : r[spec]; }
    function columns() {
      if (colsDef.length) return colsDef;
      return distinctOptions(rows, gk).map(function (v) { return { value: v }; });
    }
    function cardHtml(r, i) {
      var t = val(o.title || 'title', r), s = o.sub ? val(o.sub, r) : '', b = o.badge ? r[o.badge] : null, m = o.meta ? val(o.meta, r) : '';
      return '<div class="gs-kb-card" data-r="' + i + '" tabindex="0" role="button" aria-roledescription="draggable">' +
        '<div class="gs-kb-title">' + esc(t) + '</div>' + (s ? '<div class="gs-kb-sub">' + esc(s) + '</div>' : '') +
        (typeof o.render === 'function' ? '<div class="gs-kb-body">' + String(o.render(r)) + '</div>' : '') +
        ((b != null && b !== '') || m ? '<div class="gs-kb-foot">' + (b != null && b !== '' ? tag(humanize(b), statusTone(b)) : '<span></span>') + (m ? '<span class="gs-kb-meta">' + esc(m) + '</span>' : '') + '</div>' : '') + '</div>';
    }
    function render() {
      if (destroyed) return;
      var cs = columns(), h = '';
      if (failMsg) h += '<div class="gs-kb-err">' + banner(failMsg, { tone: 'danger' }) + '</div>';
      cs.forEach(function (c) {
        var items = [];
        rows.forEach(function (r, i) { if (String(r[gk]) === String(c.value)) items.push(i); });
        var tone = c.tone || statusTone(c.value);
        h += '<section class="gs-kb-col" data-v="' + esc(c.value) + '"><header class="gs-kb-colhead"><span class="gs-kb-dot gs-tone-' + toneOf(tone) + '"></span><span class="gs-kb-colname">' + esc(c.label != null ? c.label : humanize(c.value)) + '</span><span class="gs-kb-count">' + items.length + '</span></header><div class="gs-kb-list">';
        if (loading && !rows.length) h += skeleton({ kind: 'lines', rows: 2 });
        items.forEach(function (i) { h += cardHtml(rows[i], i); });
        if (!items.length && !loading) h += '<div class="gs-kb-empty">' + esc(o.empty || '—') + '</div>';
        h += '</div></section>';
      });
      root.innerHTML = h;
    }
    // Where a card is now. A refresh can replace `rows` while a write is in
    // flight, so settle handlers look the card up again (by idKey, else by
    // the object itself) instead of trusting the index they started with.
    function indexOf(row) {
      for (var j = 0; j < rows.length; j++) {
        if (rows[j] === row || (row[idKey] != null && rows[j][idKey] === row[idKey])) return j;
      }
      return -1;
    }
    // A column's own value (number, boolean…) for the string a data-v holds.
    function columnValue(str) {
      var cs = columns();
      for (var j = 0; j < cs.length; j++) if (String(cs[j].value) === str) return cs[j].value;
      return str;
    }
    function move(i, to) {
      var r = rows[i], from = r[gk];
      if (String(from) === String(to)) return;
      var next = assign({}, r);
      next[gk] = to;
      rows[i] = next;
      render();
      var card = root.querySelector('.gs-kb-card[data-r="' + i + '"]');
      if (card) { card.classList.add('is-saving'); try { card.focus(); } catch (e) {} }
      if (!o.onMove) return;
      var p = typeof o.onMove === 'function' ? Promise.resolve().then(function () { return o.onMove(next, to, from); }) : writeVia(o.onMove, next, to, 'kanban');
      // render() rebuilds every card; put focus back on this one when the
      // user was still on the board, so ← / → moves can be chained.
      function settle() {
        var a = document.activeElement, keep = !a || a === document.body || root.contains(a);
        render();
        var at = indexOf(next), el = at >= 0 ? root.querySelector('.gs-kb-card[data-r="' + at + '"]') : null;
        if (keep && el) try { el.focus(); } catch (e) {}
      }
      p.then(function (res) {
        var at = indexOf(next), fr = firstRow(res);
        if (at >= 0 && fr) { rows[at] = assign({}, rows[at], fr); next = rows[at]; }
        dataChanged({ source: 'kanban', kind: 'edit', row: assign({}, next), el: root });
        settle();
      }, function (err) {
        logErr('kanban', err);
        var at = indexOf(next);
        if (at >= 0) { rows[at] = assign({}, rows[at]); rows[at][gk] = from; next = rows[at]; }
        settle();
        toast(humanize(String(val(o.title || 'title', r))) + ': ' + errText(err), { tone: 'danger' });
      });
    }
    // Pointer drag: a ghost follows the pointer; the column under it gets
    // the drop. A mouse drag starts after 5px. A touch (or pen) drag starts only after
    // a ~300 ms press without moving: a swipe before that is the board (or
    // page) scrolling, and the browser keeps it (touch-action: pan-x pan-y).
    // Opening a card is a click (below), so a touch tap's follow-up mouse
    // events land after the overlay is up, not on its backdrop.
    var drag = null, dragged = false, HOLD_MS = 300;
    root.addEventListener('pointerdown', function (e) {
      var card = e.target && e.target.closest ? e.target.closest('.gs-kb-card') : null;
      if (!card || e.button !== 0 || (e.target.closest && e.target.closest('a,button,input,select,textarea'))) return;
      drag = { card: card, row: rows[Number(card.getAttribute('data-r'))], x: e.clientX, y: e.clientY, ghost: null, over: null, touch: (e.pointerType || 'mouse') !== 'mouse', armed: (e.pointerType || 'mouse') === 'mouse' || root.classList.contains('gs-kb-pen') };
      if (drag.touch && !drag.armed) {
        var d0 = drag;
        d0.timer = setTimeout(function () { if (drag === d0) { d0.armed = true; card.classList.add('is-lifted'); } }, HOLD_MS);
      }
    });
    // A pen hovering the board turns card panning off (.gs-kb-pen), so a pen
    // press drags like a mouse: the browser picks touch-action before any
    // listener runs, and a Windows pen sends no touchmove to cancel.
    // iPad Pencil without hover still gets the hold path and touchmove.
    // Only a hovering pen (no button down): a pen without hover fires its
    // pointerover on contact, and must keep the hold-and-scroll path.
    function penHover(e) { if (e.pointerType === 'pen' && !e.buttons) root.classList.add('gs-kb-pen'); }
    root.addEventListener('pointerover', penHover);
    root.addEventListener('pointermove', penHover);
    root.addEventListener('pointerleave', function (e) { if (e.pointerType === 'pen') root.classList.remove('gs-kb-pen'); });
    // Once a touch drag is armed, its moves are the drag's, not a scroll.
    root.addEventListener('touchmove', function (e) { if (drag && drag.touch && drag.armed && e.cancelable) e.preventDefault(); }, { passive: false });
    root.addEventListener('contextmenu', function (e) { if (drag && drag.touch) e.preventDefault(); });
    root.addEventListener('click', function (e) {
      var card = e.target && e.target.closest ? e.target.closest('.gs-kb-card') : null;
      if (dragged) { dragged = false; return; }  // the click that ends a drag
      if (!card || (e.target.closest && e.target.closest('a,button,input,select,textarea'))) return;
      var at = indexOf(rows[Number(card.getAttribute('data-r'))]);
      if (at >= 0 && typeof o.onOpen === 'function') o.onOpen(rows[at]);
    });
    function colAt(x, y) {
      var n = document.elementFromPoint ? document.elementFromPoint(x, y) : null;
      return n && n.closest ? n.closest('.gs-kb-col') : null;
    }
    function onMoveEv(e) {
      if (!drag) return;
      // No button held: the release went somewhere we never heard about.
      if (e.buttons === 0) { cancelDrag(); return; }
      if (!drag.ghost) {
        var moved = Math.abs(e.clientX - drag.x) + Math.abs(e.clientY - drag.y);
        // A touch that moves before the hold is a scroll: let it go.
        if (!drag.armed) { if (moved > 8) cancelDrag(); return; }
        if (moved < 5) return;
        var r = drag.card.getBoundingClientRect();
        drag.ghost = drag.card.cloneNode(true);
        drag.ghost.className += ' gs-kb-ghost';
        drag.ghost.style.width = r.width + 'px';
        drag.dx = e.clientX - r.left; drag.dy = e.clientY - r.top;
        document.body.appendChild(drag.ghost);
        drag.card.classList.add('is-dragging');
      }
      drag.ghost.style.left = (e.clientX - drag.dx) + 'px';
      drag.ghost.style.top = (e.clientY - drag.dy) + 'px';
      var col = colAt(e.clientX, e.clientY);
      if (col !== drag.over) {
        if (drag.over) drag.over.classList.remove('is-over');
        drag.over = col;
        if (col) col.classList.add('is-over');
      }
    }
    // A cancelled pointer (touch scroll, focus loss, a native drag) ends the
    // drag with no move; the next click must not drop a stale card.
    function cancelDrag() {
      if (!drag) return;
      var d = drag;
      drag = null;
      clearTimeout(d.timer);
      if (d.ghost && d.ghost.parentNode) d.ghost.parentNode.removeChild(d.ghost);
      d.card.classList.remove('is-dragging', 'is-lifted');
      if (d.over) d.over.classList.remove('is-over');
    }
    function onUp(e) {
      if (!drag) return;
      var d = drag;
      drag = null;
      clearTimeout(d.timer);
      d.card.classList.remove('is-lifted');
      var at = d.row ? indexOf(d.row) : -1;
      if (!d.ghost) return;  // a press without a drag: the click opens it
      dragged = true;
      setTimeout(function () { dragged = false; }, 0);  // no click followed
      if (d.ghost.parentNode) d.ghost.parentNode.removeChild(d.ghost);
      d.card.classList.remove('is-dragging');
      if (d.over) d.over.classList.remove('is-over');
      var col = colAt(e.clientX, e.clientY);
      if (col && at >= 0) move(at, columnValue(col.getAttribute('data-v')));
    }
    document.addEventListener('pointermove', onMoveEv);
    document.addEventListener('pointerup', onUp);
    document.addEventListener('pointercancel', cancelDrag);
    // Images in render() bodies are natively draggable; that drag would
    // swallow the pointer events this one needs.
    root.addEventListener('dragstart', function (e) { if (e.target && e.target.closest && e.target.closest('.gs-kb-card')) e.preventDefault(); });
    root.addEventListener('keydown', function (e) {
      var card = e.target && e.target.classList && e.target.classList.contains('gs-kb-card') ? e.target : null;
      if (!card) return;
      var i = Number(card.getAttribute('data-r'));
      if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); if (typeof o.onOpen === 'function') o.onOpen(rows[i]); return; }
      if (e.key !== 'ArrowRight' && e.key !== 'ArrowLeft') return;
      e.preventDefault();
      var cs = columns(), ci = -1;
      cs.forEach(function (c, j) { if (String(c.value) === String(rows[i][gk])) ci = j; });
      var nj = ci + (e.key === 'ArrowRight' ? 1 : -1);
      if (nj >= 0 && nj < cs.length) move(i, cs[nj].value);
    });
    function setRows(r) { rows = (r || []).slice(); loading = false; failMsg = ''; render(); }
    function refresh() {
      return src.load(true).then(function (r) { if (!destroyed) setRows(r); return handle; }, function (err) { logErr('kanban', err); loading = false; failMsg = errText(err); render(); return handle; });
    }
    var handle = {
      el: root, ready: null,
      rows: function () { return rows.slice(); }, setRows: setRows, refresh: refresh,
      destroy: function () {
        destroyed = true;
        document.removeEventListener('pointermove', onMoveEv);
        document.removeEventListener('pointerup', onUp);
        document.removeEventListener('pointercancel', cancelDrag);
        if (root.parentNode) root.parentNode.removeChild(root);
      },
    };
    var follow = followChanges(root, o, refresh);
    handle.setRows = function (r) { if (follow) follow.off(); setRows(r); };
    render();
    handle.ready = refresh();
    return handle;
  }

  // ── Importer ───────────────────────────────────────────────────────────
  // RFC 4180 CSV → array of arrays. Delimiter: , ; or tab, whichever the
  // header line uses most. Strips a UTF-8 BOM.
  function parseCsv(text) { return csvRows(text).rows; }
  // { rows, lines }: lines[i] is the physical line rows[i] starts on, so
  // errors point at the right line after blank lines or multi-line cells.
  function csvRows(text) {
    text = String(text || '').replace(/^\uFEFF/, '');
    var first = text.split(/\r?\n/, 1)[0] || '', delim = ',';
    [';', '\t'].forEach(function (d) { if (first.split(d).length > first.split(delim).length) delim = d; });
    var out = [], lines = [], row = [], cell = '', q = false, i = 0, c, line = 1, rowLine = 1;
    function endRow() {
      row.push(cell); cell = '';
      if (row.length > 1 || row[0] !== '') { out.push(row); lines.push(rowLine); }
      row = [];
    }
    while (i < text.length) {
      c = text.charAt(i);
      if (q) {
        if (c === '"') { if (text.charAt(i + 1) === '"') { cell += '"'; i++; } else q = false; }
        else { if (c === '\n') line++; cell += c; }
      } else if (c === '"') q = true;
      else if (c === delim) { row.push(cell); cell = ''; }
      else if (c === '\n' || c === '\r') {
        if (c === '\r' && text.charAt(i + 1) === '\n') i++;
        endRow();
        line++;
        rowLine = line;
      } else cell += c;
      i++;
    }
    if (cell !== '' || row.length) endRow();
    // The delimiter hints at the exporting locale (see run()); the decimal
    // mark itself is read per column from the values.
    return { rows: out, lines: lines, delimiter: delim };
  }
  // Japanese Excel saves CSV as Shift_JIS: decode as UTF-8 first, fall back.
  // Western-European Excel saves "ANSI" (windows-1252) instead. Every byte
  // sequence decodes as cp1252, and Shift_JIS / GB18030 accept most cp1252
  // byte pairs ("é" + "n" is a kanji), so neither a strict decode nor the
  // byte layout can pick. The decoded text can: each candidate is scored on
  // how its non-ASCII characters sit.
  //  - cp1252: a Latin letter (é, œ, Š) next to a letter is good; one with
  //    no letter beside it ("“Œ‹ž", Shift_JIS 東京 read as cp1252) is bad, as
  //    are signs no data holds (ƒ † ‡ ˆ ˜, unassigned bytes).
  //  - CJK: kana, hanzi and hangul are good unless wedged between two ASCII
  //    letters ("M嶺ard", cp1252 "Ménard" read as Shift_JIS); other scripts,
  //    private-use and box-drawing characters are bad.
  // The best share of good characters wins; a tie keeps the page's order.
  var CP1252_HI = '€\u0081‚ƒ„…†‡ˆ‰Š‹Œ\u008dŽ\u008f\u0090‘’“”•–—˜™š›œ\u009džŸ';
  // cp1252's 0x80-0x9F by table: some TextDecoder builds (Node's small ICU)
  // read them as Latin-1 control characters.
  function decode1252(buf) {
    return new TextDecoder('windows-1252').decode(buf).replace(/[\u0080-\u009f]/g, function (c) { return CP1252_HI.charAt(c.charCodeAt(0) - 0x80); });
  }
  var LATIN_RE = /[A-Za-zÀ-ÖØ-öø-ÿŒœŠšŸŽž]/;
  var BAD_1252 = /[\u0080-\u009fƒ†‡ˆ˜¤¦¨¬¯´¸]/;
  // Signs Western data does hold (£10, 250°C, ±2, 5µm, m², don’t, “x”, €).
  var SIGN_1252 = /[ -¿×÷‘-„–—…•€™‰‹›]/;
  var HAN_RE = /[㐀-䶿一-鿿豈-﫿]/;
  var KANA_RE = /[぀-ヿ]/;
  var HANGUL_RE = /[가-힣]/;
  var HWKANA_RE = /[｡-ﾟ]/;
  // Neutral in a CJK decode: CJK punctuation and fullwidth forms, CP932 /
  // KS X 1001 symbol blocks (㈱ ㎡ ①), Latin-1 signs, Greek and Cyrillic.
  var CJK_OK = /[ -ÿͰ-ӿ -⯿　-〿㄰-㆏㈀-㏿！-｠￠-￯]/;
  var ASCII_WORD = /[A-Za-z0-9]/;
  // Score of one decoded text: weighted good minus bad, per scored
  // character (neutral ones don't count either way).
  //  - Hangul next to a Han character is the EUC-KR reading of Chinese:
  //    bad. Hangul from CP949's UHC extension (its own pair has a lead or
  //    trail byte below 0xA1; KS X 1001 is A1-FE for both, and Shift_JIS
  //    pairs land outside it) weighs half unless it
  //    sits next to KS X 1001 Hangul (a rare syllable in a Korean word). KS X 1001 Korean and GB2312
  //    Chinese use the same byte ranges and can't be told apart by score;
  //    the mapping step shows the choice for that (see importer).
  //  - Half-width katakana in a run (ﾔﾏﾀﾞ) is real; a lone one weighs
  //    little, since Shift_JIS turns cp1252's £ ° ± into it.
  function plausible(text, cjk, hangulW) {
    hangulW = hangulW || function () { return 1; };
    var good = 0, bad = 0, n = 0;
    for (var i = 0; i < text.length; i++) {
      var c = text.charAt(i);
      if (c < '\u0080') continue;
      var a = text.charAt(i - 1), z = text.charAt(i + 1);
      if (cjk) {
        if (HAN_RE.test(c) || KANA_RE.test(c) || HANGUL_RE.test(c) || HWKANA_RE.test(c)) {
          n++;
          if (/[A-Za-z]/.test(a) && /[A-Za-z]/.test(z)) bad++;
          else if (HANGUL_RE.test(c)) { if (HAN_RE.test(a) || HAN_RE.test(z)) bad++; else good += hangulW(i, a, z); }
          else if (HWKANA_RE.test(c)) good += HWKANA_RE.test(a) || HWKANA_RE.test(z) ? 1 : 0.2;
          else good++;
        } else if (!CJK_OK.test(c)) { n++; bad++; }
      } else if (BAD_1252.test(c)) { n++; bad++; }
      // An accented letter sits in a word, and rarely between two other
      // non-ASCII characters ("ação" yes, "ÔÏÀÞ" - Shift_JIS ﾔﾏﾀﾞ - no).
      else if (LATIN_RE.test(c)) { n++; if (a >= '\u0080' && z >= '\u0080') bad++; else if (LATIN_RE.test(a) || LATIN_RE.test(z)) good++; else bad++; }
      else if (SIGN_1252.test(c) && (ASCII_WORD.test(a) || ASCII_WORD.test(z) || a === ' ' || z === ' ')) { n++; good++; }
    }
    return n ? (good - bad) / n : 0;
  }
  // Every reading of a non-UTF-8 file, scored: [{ enc, text, score }],
  // best first (ties keep the page's order). One entry for UTF-8.
  function decodeCandidates(buf) {
    try { return [{ enc: 'utf-8', text: new TextDecoder('utf-8', { fatal: true }).decode(buf), score: 1 }]; } catch (e) {}
    var l = uiLang(), encs = ['shift_jis', 'gb18030', 'euc-kr'];
    if (l === 'zh') encs = ['gb18030', 'shift_jis', 'euc-kr'];
    if (l === 'ko') encs = ['euc-kr', 'shift_jis', 'gb18030'];
    // A ja/zh/ko page prefers its encodings on a tie, any other page cp1252.
    var order = l === 'ja' || l === 'zh' || l === 'ko' ? encs.concat(['windows-1252']) : ['windows-1252'].concat(encs);
    // Per decoded character of the euc-kr reading: is it a UHC pair? (A
    // strict decode maps each byte < 0x80 to one character and each pair
    // to one character.)
    var uhc = [];
    for (var k = 0; k < buf.length; k++) {
      if (buf[k] >= 0x81) { uhc.push(buf[k] < 0xa1 || buf[k + 1] < 0xa1); k++; } else uhc.push(false);
    }
    // A UHC syllable inside Korean text (next to KS X 1001 Hangul) is real;
    // a run of nothing but UHC syllables is how Shift_JIS reads in CP949.
    function hangulW(ci, a, z) {
      if (!uhc[ci]) return 1;
      return (HANGUL_RE.test(a) && !uhc[ci - 1]) || (HANGUL_RE.test(z) && !uhc[ci + 1]) ? 1 : 0.5;
    }
    var out = [];
    order.forEach(function (enc, oi) {
      var text;
      if (enc === 'windows-1252') text = decode1252(buf);
      else { try { text = new TextDecoder(enc, { fatal: true }).decode(buf); } catch (e2) { return; } }
      out.push({ enc: enc, text: text, score: plausible(text, enc !== 'windows-1252', enc === 'euc-kr' ? hangulW : null), oi: oi });
    });
    out.sort(function (x, y) { return y.score - x.score || x.oi - y.oi; });
    return out;
  }
  // SheetJS stopped publishing to npm at 0.18.5, which has CVE-2023-30533
  // (prototype pollution from a crafted file) and CVE-2024-22363 (ReDoS).
  // The patched build lives on SheetJS's own CDN; SRI pins the exact bytes.
  var XLSX_URL = 'https://cdn.sheetjs.com/xlsx-0.20.3/package/dist/xlsx.full.min.js';
  var XLSX_SRI = 'sha384-EnyY0/GSHQGSxSgMwaIPzSESbqoOLSexfnSMN2AP+39Ckmn92stwABZynq1JyzdT';
  function loadXlsx() {
    if (window.XLSX) return Promise.resolve(window.XLSX);
    return new Promise(function (res, rej) {
      var s = document.createElement('script');
      s.src = XLSX_URL;
      s.integrity = XLSX_SRI;
      s.crossOrigin = 'anonymous';
      s.onload = function () { window.XLSX ? res(window.XLSX) : rej(new Error('XLSX did not load')); };
      s.onerror = function () { rej(new Error('Could not load the Excel reader; save the sheet as CSV and try again')); };
      document.head.appendChild(s);
    });
  }
  function readFileRows(file) {
    var isX = /\.(xlsx|xlsm|xls)$/i.test(file.name || '');
    return new Promise(function (res, rej) {
      var fr = new FileReader();
      fr.onerror = function () { rej(new Error(T('unreadable'))); };
      fr.onload = function () {
        if (!isX) {
          try {
            var cands = decodeCandidates(new Uint8Array(fr.result)), out = csvRows(cands[0].text);
            out.encs = cands;
            res(out);
          } catch (e) { rej(e); }
          return;
        }
        loadXlsx().then(function (X) {
          var wb = X.read(new Uint8Array(fr.result), { type: 'array', cellNF: true });
          var sh = wb.Sheets[wb.SheetNames[0]];
          // Excel stores dates as serial numbers; the display text follows the
          // cell's format, and SheetJS renders the built-in date formats
          // (14 "m/d/yy", 22 "m/d/yy h:mm") US-ordered in every locale. Every
          // date-formatted cell becomes ISO from its serial instead, so only
          // dates typed as text can ever ask the month/day question.
          // Old Mac workbooks count from 1904; the serial means another day.
          var d1904 = !!(wb.Workbook && wb.Workbook.WBProps && wb.Workbook.WBProps.date1904);
          for (var ck in sh) {
            var cell = sh[ck];
            if (ck.charAt(0) === '!' || !cell || cell.t !== 'n' || !cell.z || !X.SSF.is_date(cell.z)) continue;
            // A time-only cell (serial < 1) or a duration ("[h]:mm") keeps its
            // text ("13:30"). A full datetime shown as "h:mm" becomes ISO like
            // any date: a date field keeps the day, a time field takes the time
            // part (importCell).
            var fmt = String(cell.z).replace(/"[^"]*"/g, '');
            if (cell.v < 1 || /\[[hms]+\]/i.test(fmt)) continue;
            var dc = X.SSF.parse_date_code(cell.v, { date1904: d1904 });
            if (!dc) continue;
            var iso = dc.y + '-' + pad2(dc.m) + '-' + pad2(dc.d);
            if (dc.H || dc.M || dc.S || !/[dy]/i.test(fmt.replace(/\[[^\]]*\]/g, ''))) iso += 'T' + pad2(dc.H) + ':' + pad2(dc.M) + ':' + pad2(dc.S);
            cell.w = iso;
          }
          var aoa = X.utils.sheet_to_json(sh, { header: 1, raw: false, dateNF: 'yyyy-mm-dd', defval: '', blankrows: true });
          var top = sh['!ref'] ? X.utils.decode_range(sh['!ref']).s.r : 0, out = [], lines = [];
          aoa.forEach(function (r, ri) {
            if (!r.some(function (c) { return String(c).replace(/\s/g, '') !== ''; })) return;
            out.push(r.map(function (c) { return c == null ? '' : String(c); }));
            lines.push(top + ri + 1);  // the sheet's own row number
          });
          res({ rows: out, lines: lines });
        }, rej);
      };
      fr.readAsArrayBuffer(file);
    });
  }
  function normKey(s) { return lc(s).replace(/[\s_\-.\/()（）]+/g, ''); }
  // A spreadsheet cell as the form parser expects it. parseField reads a
  // checkbox from a control (true / false), and numbers as bare digits; a
  // file has "FALSE", "0", "はい", "$1,200", "12%" or "(500)".
  var TRUTHY = { 'true': 1, yes: 1, y: 1, '1': 1, on: 1, '✓': 1, '○': 1, 'はい': 1, '是': 1, '예': 1 };
  var FALSY = { 'false': 1, no: 1, n: 1, '0': 1, off: 1, '✗': 1, '×': 1, 'いいえ': 1, '否': 1, '아니요': 1 };
  // Number text as a spreadsheet shows it → plain digits, or the text
  // unchanged so parseField rejects it. Only well-formed decorations are
  // removed: a known currency, thousands groups (first group not starting
  // with 0), a trailing %, and "(…)" for a negative. "1 2" or "SKU123" stay
  // errors instead of becoming other numbers.
  var CUR = '[$€£¥￥₩₹]|USD|EUR|JPY|CNY|RMB|KRW|GBP|INR|HKD|TWD|SGD|AUD|CAD';
  var CUR_PRE = new RegExp('^([-+]?)\\s*(?:' + CUR + ')\\s?(?=[\\d.])', 'i');
  var CUR_POST = new RegExp('(\\d)\\s?(?:' + CUR + '|[円元원])$', 'i');
  // { neg, pct, core }: the cell with "(…)", "%" and currency peeled off.
  function numParts(s) {
    var neg = /^\(.*\)$/.test(s), v = neg ? s.slice(1, -1).replace(/^\s+|\s+$/g, '') : s;
    var pct = /%$/.test(v);
    if (pct) v = v.slice(0, -1).replace(/\s+$/, '');
    v = v.replace(/\u00a0/g, ' ').replace(CUR_PRE, '$1').replace(CUR_POST, '$1');
    return { neg: neg, pct: pct, core: v };
  }
  // Which decimal mark one cell proves: '.', ',', 'none' (no separator) or
  // 'ambiguous'. Only "1,234" / "1.250" are ambiguous: one separator, three
  // digits after it, and a valid first thousands group before it. "0.125",
  // ".125" and "1234.567" cannot be groups, so their separator is decimal.
  function cellMark(v) {
    var d = v.lastIndexOf('.'), c = v.lastIndexOf(',');
    if (d < 0 && c < 0) return 'none';
    if (d >= 0 && c >= 0) return d > c ? '.' : ',';
    var sep = d >= 0 ? '.' : ',', parts = v.split(sep);
    if (parts.length > 2) return sep === '.' ? ',' : '.';  // repeated → it groups thousands
    return parts[1].length === 3 && /^[-+]?[1-9]\d{0,2}$/.test(parts[0]) ? 'ambiguous' : sep;
  }
  var NUMLIKE = /^[-+]?[\d\s.,]*\d[\d\s.,]*$/;
  // { '.': n, ',': n }: decimal-mark evidence in one column's cells. Only
  // cells shaped like numbers count, so "N.A." or "n.a" prove nothing.
  function markEvidence(cells) {
    var seen = {};
    cells.forEach(function (raw) {
      var s = String(raw == null ? '' : raw).replace(/^\s+|\s+$/g, '');
      if (!s) return;
      var core = numParts(s).core;
      if (!NUMLIKE.test(core)) return;
      var m = cellMark(core);
      if (m === '.' || m === ',') seen[m] = (seen[m] || 0) + 1;
    });
    return seen;
  }
  function markOf(seen) { return seen['.'] && !seen[','] ? '.' : seen[','] && !seen['.'] ? ',' : null; }
  function numText(v, mark) {
    var m = mark || cellMark(v);
    if (m === '.') {
      if (/^[-+]?[1-9]\d{0,2}([, ]\d{3})+(\.\d+)?$/.test(v)) return v.replace(/[, ]/g, '');
    } else if (m === ',') {
      if (/^[-+]?[1-9]\d{0,2}([. ]\d{3})+(,\d+)?$/.test(v) || /^[-+]?\d+(,\d+)?$/.test(v)) return v.replace(/[. ]/g, '').replace(',', '.');
    }
    // A space is never a decimal mark: "1 234" groups thousands in any locale.
    if (/^[-+]?[1-9]\d{0,2}( \d{3})+$/.test(v)) return v.replace(/ /g, '');
    return v;
  }
  // ── Importer dates ──
  // Excel saves CSV dates in the system's short format: "11/10/2026" (US),
  // "10/11/2026" or "10.11.2026" (Europe), "2026/11/10" or "2026年11月10日"
  // (Japan, China, Korea). The table wants ISO. Year-first and dotted
  // (German) forms are unambiguous; "03/04/2026" is March 4 or 3 April, so
  // the column's order comes from cells with a part over 12, or, failing
  // that, from the user (the mapping step asks, as for the decimal mark).
  var TIME_RE = '(?:[ T]+(\\d{1,2}):(\\d{2})(?::(\\d{2})(?:\\.\\d+)?)?\\s*([AaPp][Mm])?)?';
  var DATE_YMD = new RegExp('^(\\d{4})[-/.年]\\s*(\\d{1,2})[-/.月]\\s*(\\d{1,2})日?' + TIME_RE + '$');
  var DATE_XYY = new RegExp('^(\\d{1,2})([-/.])(\\d{1,2})\\2(\\d{4}|\\d{2})' + TIME_RE + '$');
  // { y, m, d, time, order } read from a cell; order is 'mdy' / 'dmy' when
  // the cell proves one, 'ambiguous' when either reads, null when year-first.
  function dateShape(s) {
    var m = DATE_YMD.exec(s);
    if (m) return { y: +m[1], a: +m[2], b: +m[3], t: m.slice(4, 8), order: null };
    m = DATE_XYY.exec(s);
    if (!m) return null;
    var a = +m[1], b = +m[3], y = +m[4];
    // Excel's two-digit window: 00-29 → 2000s, 30-99 → 1900s (a "3/4/75"
    // birthday is 1975, not 2075).
    if (m[4].length === 2) y += y < 30 ? 2000 : 1900;
    var order = m[2] === '.' ? 'dmy' : a > 12 && b <= 12 ? 'dmy' : b > 12 && a <= 12 ? 'mdy' : a === b || a > 12 ? null : 'ambiguous';
    if (a === b && a <= 12) order = 'same';  // "05/05": the same either way
    return { y: y, a: a, b: b, t: m.slice(5, 9), order: order, xyy: true };
  }
  // ISO text, or null when the cell isn't a real date (13th month, Feb 30).
  function dateIso(sh, order, withTime) {
    var mo = sh.a, d = sh.b;
    if (sh.xyy) { if (order === 'dmy') { mo = sh.b; d = sh.a; } else if (order !== 'mdy' && order !== 'same') return null; }
    var dt = new Date(sh.y, mo - 1, d);
    if (dt.getFullYear() !== sh.y || dt.getMonth() !== mo - 1 || dt.getDate() !== d) return null;
    var iso = sh.y + '-' + pad2(mo) + '-' + pad2(d);
    if (!withTime) return iso;
    var h = sh.t[0] != null ? +sh.t[0] : 0, mi = sh.t[1] != null ? +sh.t[1] : 0, se = sh.t[2] != null ? +sh.t[2] : 0, ap = (sh.t[3] || '').toLowerCase();
    if (ap) { if (h < 1 || h > 12) return null; h = h % 12 + (ap === 'pm' ? 12 : 0); }
    if (h > 23 || mi > 59 || se > 59) return null;
    return iso + 'T' + pad2(h) + ':' + pad2(mi) + ':' + pad2(se);
  }
  function dateOrderOf(cells) {
    var seen = {};
    cells.forEach(function (raw) {
      var sh = dateShape(String(raw == null ? '' : raw).replace(/^\s+|\s+$/g, ''));
      if (sh && (sh.order === 'mdy' || sh.order === 'dmy')) seen[sh.order] = 1;
    });
    return seen.mdy && !seen.dmy ? 'mdy' : seen.dmy && !seen.mdy ? 'dmy' : null;
  }
  var DATE_TYPES = { date: 1, datetime: 1 };
  // mark: the column's decimal mark, or null when undecided (then an
  // ambiguous cell fails instead of being guessed). order: the same for a
  // date column's month/day order.
  function importCell(f, raw, mark, order) {
    var s = String(raw == null ? '' : raw).replace(/^\s+|\s+$/g, ''), t = f.type;
    if (t === 'checkbox') {
      // Blank is "unchecked", as Excel flag columns leave it (and as the form
      // parser read it); a required checkbox still has to say so.
      if (s === '') return f.required ? { value: null, error: 'Required' } : { value: false, error: null };
      var k = lc(s);
      if (TRUTHY[k]) return { value: true, error: null };
      if (FALSY[k]) return { value: false, error: null };
      return { value: null, error: 'Enter yes or no' };
    }
    if (NUM_TYPES[t] && s !== '') {
      // "(12%)" is a negative percent: parts are peeled before the % test.
      var p = numParts(s), n = numText(p.core, mark);
      if (!mark && cellMark(p.core) === 'ambiguous') {
        // A whole-number field can't hold "1.5", so "1.500" / "1,500" there is
        // a group. "12,000" stays ambiguous: twelve and twelve thousand are both whole.
        if (t === 'integer' && !/[.,]000$/.test(p.core)) n = p.core.replace(/[.,]/g, '');
        else return { value: null, error: 'Ambiguous number "' + s + '": write it without a thousands separator', ambiguous: true };
      }
      if (p.neg && /^[\d.]/.test(n)) n = '-' + n;  // "(.5)" too
      // A % cell holds a fraction (Excel stores 12% as 0.12); only a 'pct'
      // field keeps the shown number.
      if (p.pct && t !== 'pct' && n !== '' && isFinite(Number(n))) n = String(Number(n) / 100);
      s = n;
    }
    if (DATE_TYPES[t] && s !== '') {
      var sh = dateShape(s);
      if (!sh) {
        // Already ISO (or ISO with a zone): the server reads it as is.
        if (/^\d{4}-\d{2}-\d{2}(?:[T ][\d:.]+(?:Z|[+-]\d{2}(?::?\d{2})?)?)?$/i.test(s)) return parseField(f, s);
        return { value: null, error: T('badDate') };
      }
      var ord = sh.order === 'ambiguous' ? order : sh.order === 'same' ? 'same' : sh.order || order;
      if (sh.xyy && sh.order === 'ambiguous' && !order) return { value: null, error: T('badDate'), ambiguous: true };
      var iso = dateIso(sh, sh.xyy ? (sh.order === 'mdy' || sh.order === 'dmy' ? sh.order : ord) : null, t === 'datetime');
      if (!iso) return { value: null, error: T('badDate') };
      // The file's time is the viewer's wall clock. A column that stores an
      // instant (timestamptz) gets it as an absolute time, as the form sends
      // it; a naive string would be read as UTC.
      if (t === 'datetime' && /with time zone|timestamptz/i.test(String(f.pgType || ''))) iso = new Date(iso).toISOString();
      s = iso;
    }
    // An xlsx datetime (ISO from its serial) into a time field: its time.
    var tm = t === 'time' ? /^\d{4}-\d{2}-\d{2}T(\d{2}:\d{2}:\d{2})$/.exec(s) : null;
    if (tm) s = tm[1];
    if (t === 'select' && f.options && s !== '') {
      // A sheet shows the label ("Won"); the table stores the value ("won").
      var hit = null, key = lc(s);
      f.options.forEach(function (op) {
        if (hit == null && (lc(optValue(op)) === key || lc(optLabel(op)) === key)) hit = String(optValue(op));
      });
      if (hit != null) s = hit;
    }
    return parseField(f, s);
  }
  // { key: '.' | ',' | null } for each mapped numeric column; null means
  // undecided, where an ambiguous cell needs the user's choice (see mapStep).
  function decideMarks(target, mapping, data, delimiter) {
    var marks = {}, evid = {}, file = {};
    // One decimal mark per numeric column, from that column's own values;
    // a column with none (whole numbers, say) takes the file's, and only
    // then the delimiter default (','/xlsx/tab → '.', ';' → undecided).
    target.forEach(function (f) {
      if (!NUM_TYPES[f.type] || mapping[f.key] == null) return;
      evid[f.key] = markEvidence(data.map(function (r) { return r[mapping[f.key]]; }));
      for (var m in evid[f.key]) if (hasOwn(evid[f.key], m)) file[m] = (file[m] || 0) + evid[f.key][m];
    });
    var fileMark = markOf(file);
    target.forEach(function (f) {
      if (!evid[f.key]) return;
      var e = evid[f.key];
      if (e['.'] || e[',']) { marks[f.key] = markOf(e); return; }
      //  ';' / tab  the exporting locale is unknown (and the browser's
      //       language says nothing about Excel's regional settings): take
      //       the mark the other columns prove, else leave it undecided so
      //       ambiguous cells ("1,250", "1.500") are asked about, not guessed.
      //  ','  (and xlsx) US '.'; a ',' proven elsewhere (one pasted "3,75")
      //       must not turn this column's "1,250" into 1.25, so on that
      //       disagreement the column stays undecided.
      if (delimiter === ';' || delimiter === '\t') marks[f.key] = fileMark;
      else marks[f.key] = fileMark && fileMark !== '.' ? null : '.';
    });
    return marks;
  }
  // gsDash.importer(el, {
  //   table?: 'contacts',               // target fields + types from getSchema()
  //   fields?: ['name', { key: 'email', label: 'Email', aliases: ['メール'] }, ...],
  //   insert: 'insert_contact' | function (row) -> Promise,     // called once per row
  //   batch?: function (rows) -> Promise,                       // or all at once instead
  //   onDone?({ ok, failed: [{ line, row, error }] }), accept?: '.csv,.xlsx,.xls', title?,
  // }) -> { el, reset(), destroy() }
  // Steps: drop / choose → map columns (auto-matched by name) with a preview →
  // import with progress → result, failed lines listed with the reason.
  function importer(el, o) {
    el = elOf(el, 'importer');
    o = o || {};
    if (!o.insert && !o.batch) throw new Error('gsDash.importer: insert (or batch) is required');
    var root = mk('div', 'gs-imp');
    el.innerHTML = '';
    el.appendChild(root);
    var fieldsP = resolveFields(o.fields, o.table), fields = [], destroyed = false, delimiter = ',';
    fieldsP.then(function (f) { fields = f; }, function (e) { logErr('importer', e); });
    function stepper(i) { return '<div class="gs-imp-steps">' + steps([T('stUpload'), T('stMap'), T('stImport')], i) + '</div>'; }
    function start() {
      root.innerHTML = (o.title ? '<div class="t-h3 gs-imp-title">' + esc(o.title) + '</div>' : '') + stepper(0) +
        '<label class="gs-drop" tabindex="0"><span class="gs-drop-ico">' + icon('upload', 22) + '</span><span>' + esc(T('dropHint')) + ' <u>' + esc(T('choose')) + '</u></span>' +
        '<span class="gs-drop-sub">' + esc((o.accept || '.csv,.xlsx,.xls').replace(/,/g, ' · ')) + '</span><input type="file" hidden accept="' + esc(o.accept || '.csv,.xlsx,.xls,.tsv,.txt') + '"></label><div class="gs-imp-msg"></div>';
      var drop = root.querySelector('.gs-drop'), inp = root.querySelector('input[type=file]');
      inp.onchange = function () { if (inp.files && inp.files[0]) take(inp.files[0]); };
      drop.addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); inp.click(); } });
      drop.addEventListener('dragover', function (e) { e.preventDefault(); drop.classList.add('is-over'); });
      drop.addEventListener('dragleave', function () { drop.classList.remove('is-over'); });
      drop.addEventListener('drop', function (e) { e.preventDefault(); drop.classList.remove('is-over'); var f = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0]; if (f) take(f); });
    }
    function take(file) {
      var msg = root.querySelector('.gs-imp-msg');
      msg.innerHTML = skeleton({ kind: 'lines', rows: 2 });
      Promise.all([readFileRows(file), fieldsP]).then(function (res) {
        var aoa = res[0].rows, lines = res[0].lines;
        delimiter = res[0].delimiter || ',';  // xlsx display text reads like a ',' file
        if (!aoa.length) throw new Error(T('noData'));
        var encs = res[0].encs || [];
        mapStep(file.name, aoa[0], aoa.slice(1), lines.slice(1), encs.length > 1 ? { encs: encs, at: 0, confirmed: false } : null);
      }).then(null, function (e) { logErr('importer', e); msg.innerHTML = banner(errText(e), { tone: 'danger' }); });
    }
    // enc: { encs: decodeCandidates(), at, confirmed } for a non-UTF-8 file
    // that more than one encoding reads; the mapping step shows the choice
    // (preselected by score, highlighted when the runner-up is close) and
    // re-reads the file on a change, so a wrong guess shows in the preview.
    var ENC_LABEL = { 'windows-1252': 'encWestern', shift_jis: 'encJa', gb18030: 'encZh', 'euc-kr': 'encKo' };
    function mapStep(name, header, data, lines, enc) {
      var target = fields.length ? fields : header.map(function (h) { return { key: h }; });
      var mapping = {};
      target.forEach(function (f) {
        var keys = [normKey(f.key), normKey(labelOf(f))].concat((f.aliases || []).map(normKey));
        header.forEach(function (h, ci) { if (mapping[f.key] == null && keys.indexOf(normKey(h)) >= 0) mapping[f.key] = ci; });
      });
      // Answers for columns the values leave undecided. The decimal mark
      // starts on the likeliest reading (the mark the rest of the file
      // proves, else ',' for a ';' file, else '.'), shown applied to the
      // asked value so a wrong guess is visible before Import. Date order
      // has no such signal (a US and a UK file look the same), so it starts
      // unanswered and Import waits for it.
      var chosenMark = null, chosenDate = null, markConfirmed = false;
      function guessMark() {
        var file = {};
        target.forEach(function (f) {
          if (!NUM_TYPES[f.type] || mapping[f.key] == null) return;
          var e = markEvidence(data.map(function (r) { return r[mapping[f.key]]; }));
          for (var m in e) if (hasOwn(e, m)) file[m] = (file[m] || 0) + e[m];
        });
        return markOf(file) || (delimiter === ';' ? ',' : '.');
      }
      // The first cell an undecided column can't read without an answer.
      function firstAmbiguous(undecided, test) {
        for (var i = 0; i < target.length; i++) {
          var f = target[i];
          if (undecided[f.key] !== null || mapping[f.key] == null) continue;
          for (var j = 0; j < data.length; j++) {
            var raw = data[j][mapping[f.key]];
            if (test(f, raw)) return { f: f, raw: String(raw).replace(/^\s+|\s+$/g, '') };
          }
        }
        return null;
      }
      function decideOrders() {
        var out = {};
        target.forEach(function (f) {
          if (DATE_TYPES[f.type] && mapping[f.key] != null) out[f.key] = dateOrderOf(data.map(function (r) { return r[mapping[f.key]]; }));
        });
        return out;
      }
      function refocus(sel) { var n = root.querySelector(sel); if (n) n.focus(); }
      function draw() {
        var marks = decideMarks(target, mapping, data, delimiter), orders = decideOrders();
        var amb = firstAmbiguous(marks, function (f, raw) { return NUM_TYPES[f.type] && importCell(f, raw, null).ambiguous; });
        var damb = firstAmbiguous(orders, function (f, raw) { return DATE_TYPES[f.type] && importCell(f, raw, null, null).ambiguous; });
        if (amb && !chosenMark) chosenMark = guessMark();
        var h = stepper(1) + '<div class="gs-imp-file">' + icon('inbox', 14) + '<b>' + esc(name) + '</b><span class="t-small">' + esc(T('previewOf', { n: fmtNum(data.length) })) + '</span></div>';
        h += '<div class="gs-imp-map"><div class="gs-imp-maphead"><span>' + esc(T('field')) + '</span><span>' + esc(T('column')) + '</span><span></span></div>';
        target.forEach(function (f, fi) {
          var sel = '<select class="input gs-imp-sel" data-f="' + fi + '"><option value="">' + esc(T('skip')) + '</option>';
          header.forEach(function (hd, ci) { sel += '<option value="' + ci + '"' + (mapping[f.key] === ci ? ' selected' : '') + '>' + esc(hd || '#' + (ci + 1)) + '</option>'; });
          sel += '</select>';
          var sample = mapping[f.key] != null && data[0] ? data[0][mapping[f.key]] : '';
          h += '<div class="gs-imp-row"><span class="gs-imp-fname">' + esc(labelOf(f)) + (f.required ? ' <span class="gs-f-req">*</span>' : '') + '</span>' + sel + '<span class="gs-imp-sample">' + esc(sample == null ? '' : sample) + '</span></div>';
        });
        h += '</div><div class="gs-imp-prev"><table class="gs-tbl-table"><thead><tr>';
        header.forEach(function (hd) { h += '<th class="gs-tbl-th"><span class="gs-tbl-hl">' + esc(hd) + '</span></th>'; });
        h += '</tr></thead><tbody>';
        data.slice(0, 5).forEach(function (r) { h += '<tr>' + header.map(function (x, ci) { return '<td class="gs-tbl-td">' + esc(r[ci] == null ? '' : r[ci]) + '</td>'; }).join('') + '</tr>'; });
        h += '</tbody></table></div>';
        function ask(cls, q, raw, shown) {
          return '<div class="gs-imp-mark ' + cls + (shown == null ? ' is-open' : '') + '"><div class="gs-imp-markq">' + icon('warn', 14) + '<span>' + esc(q) + '</span></div>' +
            '<div class="gs-imp-markrow"><span class="gs-imp-seg"></span>' + (shown != null ? '<span class="gs-imp-markread">"' + esc(raw) + '" → <b>' + esc(shown) + '</b></span>' : '') + '</div></div>';
        }
        if (amb) {
          var read = importCell(amb.f, amb.raw, chosenMark).value;
          h += ask('gs-imp-ask-num' + (markConfirmed ? '' : ' is-open'), T('decAsk', { v: amb.raw, col: labelOf(amb.f) }), amb.raw, read == null ? '—' : fmtNum(read, { exact: true }));
        }
        if (enc) {
          var close = enc.encs.length > 1 && enc.encs[1].score >= enc.encs[0].score - 0.25;
          h += '<div class="gs-imp-mark gs-imp-ask-enc' + (close && !enc.confirmed ? ' is-open' : '') + '"><div class="gs-imp-markq">' + icon(close && !enc.confirmed ? 'warn' : 'info', 14) + '<span>' + esc(T('encAsk')) + '</span></div><div class="gs-imp-markrow"><span class="gs-imp-seg"></span></div></div>';
        }
        if (damb) {
          var dread = chosenDate ? importCell(damb.f, damb.raw, null, chosenDate).value : null;
          h += ask('gs-imp-ask-date', T('dateAsk', { v: damb.raw, col: labelOf(damb.f) }), damb.raw, dread == null ? null : fmtDate(toDay(dread), { year: 'numeric', month: 'short', day: 'numeric' }));
        }
        h += '<div class="gs-imp-msg"></div><div class="gs-imp-actions"></div>';
        root.innerHTML = h;
        // draw() rebuilds the view: keep keyboard focus on the answer.
        if (enc) {
          segmented(root.querySelector('.gs-imp-ask-enc .gs-imp-seg'), {
            label: T('encoding'), size: 'sm', value: String(enc.at),
            options: enc.encs.map(function (c, ci) { return { value: String(ci), label: T(ENC_LABEL[c.enc] || 'encWestern') }; }),
            onChange: function (v) {
              var at = Number(v), r = csvRows(enc.encs[at].text);
              delimiter = r.delimiter || ',';
              if (!r.rows.length) return;
              mapStep(name, r.rows[0], r.rows.slice(1), r.lines.slice(1), { encs: enc.encs, at: at, confirmed: true });
              refocus('.gs-imp-ask-enc .gs-seg-btn.is-on');
            },
          });
          root.querySelector('.gs-imp-ask-enc .gs-imp-seg').addEventListener('click', function (e) {
            if (enc.confirmed || !(e.target && e.target.closest && e.target.closest('.gs-seg-btn.is-on'))) return;
            enc.confirmed = true;
            draw();
            refocus('.gs-imp-ask-enc .gs-seg-btn.is-on');
          });
        }
        if (amb) {
          segmented(root.querySelector('.gs-imp-ask-num .gs-imp-seg'), {
            label: T('decMark'), size: 'sm', value: chosenMark,
            options: [{ value: '.', label: '1,234.5' }, { value: ',', label: '1.234,5' }],
            onChange: function (v) { chosenMark = v; markConfirmed = true; draw(); refocus('.gs-imp-ask-num .gs-seg-btn.is-on'); },
          });
          // The guess stays highlighted until the user picks, or clicks the
          // preselected answer to confirm it: a ×1000 misread must be seen.
          root.querySelector('.gs-imp-ask-num .gs-imp-seg').addEventListener('click', function (e) {
            if (markConfirmed || !(e.target && e.target.closest && e.target.closest('.gs-seg-btn'))) return;
            markConfirmed = true;
            draw();
            refocus('.gs-imp-ask-num .gs-seg-btn.is-on');
          });
        }
        if (damb) {
          segmented(root.querySelector('.gs-imp-ask-date .gs-imp-seg'), {
            label: T('dateOrder'), size: 'sm', value: chosenDate,
            options: [{ value: 'mdy', label: T('mdFirst') }, { value: 'dmy', label: T('dmFirst') }],
            onChange: function (v) { chosenDate = v; draw(); refocus('.gs-imp-ask-date .gs-seg-btn.is-on'); },
          });
        }
        var acts = root.querySelector('.gs-imp-actions');
        acts.appendChild(button(T('cancel'), 'secondary', start));
        var go = button(T('importN', { n: fmtNum(data.length) }), 'primary', function () {
          if (damb && !chosenDate) return;
          // An answer fills only the undecided columns; a column whose own
          // values prove its mark or order keeps it.
          var k;
          for (k in marks) if (hasOwn(marks, k) && marks[k] === null && amb) marks[k] = chosenMark;
          for (k in orders) if (hasOwn(orders, k) && orders[k] === null && damb) orders[k] = chosenDate;
          run(target, mapping, data, lines, marks, orders);
        });
        if (damb && !chosenDate) go.disabled = true;
        acts.appendChild(go);
        Array.prototype.forEach.call(root.querySelectorAll('.gs-imp-sel'), function (s) {
          s.onchange = function () { var fi = s.getAttribute('data-f'), f = target[Number(fi)]; if (s.value === '') delete mapping[f.key]; else mapping[f.key] = Number(s.value); draw(); refocus('.gs-imp-sel[data-f="' + fi + '"]'); };
        });
      }
      draw();
    }
    function run(target, mapping, data, lines, marks, orders) {
      var missing = target.filter(function (f) { return f.required && mapping[f.key] == null; });
      if (missing.length) { root.querySelector('.gs-imp-msg').innerHTML = banner(T('required') + ': ' + missing.map(labelOf).join(', '), { tone: 'warn' }); return; }
      var parsed = [], failed = [];
      data.forEach(function (r, li) {
        var row = {}, bad = null;
        target.forEach(function (f) {
          if (mapping[f.key] == null) return;
          var p = importCell(f, r[mapping[f.key]], marks[f.key], orders && orders[f.key]);
          if (p.error && !bad) bad = labelOf(f) + ': ' + p.error;
          row[f.key] = p.value;
        });
        if (bad) failed.push({ line: (lines && lines[li]) || li + 2, row: row, error: bad });
        else parsed.push({ line: (lines && lines[li]) || li + 2, row: row });
      });
      var n = parsed.length, done = 0, ok = 0;
      function progress() {
        root.innerHTML = stepper(2) + '<div class="gs-imp-run"><div>' + esc(T('importing', { done: fmtNum(done), n: fmtNum(n) })) + '</div>' + bar(done, { max: n || 1, label: false }) + '</div>';
      }
      progress();
      var p;
      if (o.batch) {
        p = Promise.resolve().then(function () { return o.batch(parsed.map(function (x) { return x.row; })); }).then(function () { ok = n; done = n; }, function (e) { parsed.forEach(function (x) { failed.push({ line: x.line, row: x.row, error: errText(e) }); }); done = n; });
      } else {
        // Four writes in flight: fast, and gentle on the database.
        var next = 0;
        p = new Promise(function (resolve) {
          function pump() {
            if (destroyed) return resolve();
            if (next >= n) { if (done >= n) resolve(); return; }
            var item = parsed[next++];
            writeVia(o.insert, item.row, null, 'importer').then(function () { ok++; }, function (e) { failed.push({ line: item.line, row: item.row, error: errText(e) }); })
              .then(function () { done++; if (done % 5 === 0 || done === n) progress(); pump(); });
          }
          if (!n) resolve();
          for (var k = 0; k < 4; k++) pump();
        });
      }
      p.then(function () {
        if (destroyed) return;
        failed.sort(function (a, b) { return a.line - b.line; });
        var h = stepper(3) + '<div class="gs-imp-result">' + (ok ? banner(T('imported', { ok: fmtNum(ok) }), { tone: 'success' }) : '') + (failed.length ? banner(T('importFailed', { n: fmtNum(failed.length) }), { tone: 'danger' }) : '') + '</div>';
        if (failed.length) {
          h += '<div class="gs-imp-fails">';
          failed.slice(0, 50).forEach(function (f) { h += '<div class="gs-imp-fail"><span class="num">#' + f.line + '</span><span>' + esc(f.error) + '</span></div>'; });
          h += '</div>';
        }
        h += '<div class="gs-imp-actions"></div>';
        root.innerHTML = h;
        root.querySelector('.gs-imp-actions').appendChild(button(T('again'), 'secondary', start));
        if (ok) dataChanged({ source: 'importer', kind: 'add', table: o.table, el: root });
        if (typeof o.onDone === 'function') o.onDone({ ok: ok, failed: failed });
      });
    }
    start();
    return { el: root, reset: start, destroy: function () { destroyed = true; if (root.parentNode) root.parentNode.removeChild(root); } };
  }

  // gsDash.print / downloadPdf / download / confirm / alert / prompt are the agentdb calls of
  // the same name (the bridge's printing and file bridge) for dashboards that
  // hold `var g = window.gsDash`. They work detached, and reject with
  // PRINT_UNAVAILABLE on a page whose bridge lacks the call.
  function bridgeCall(name, args) {
    var bridge = window.agentdb;
    if (bridge && typeof bridge[name] === 'function') return bridge[name].apply(bridge, args);
    var err = new Error('agentdb.' + name + ' is not available on this page');
    err.code = 'PRINT_UNAVAILABLE';
    return Promise.reject(err);
  }

  function printAlias(name) {
    // Every argument: download takes three.
    return function () { return bridgeCall(name, arguments); };
  }

  window.gsDash = {
    cvar: cvar, vizColor: vizColor, vizRef: vizRef, chartTheme: chartTheme, esc: esc, fmtInt: fmtInt, money: money, humanize: humanize,
    dateMD: dateMD, relTime: relTime, statusTone: statusTone, tag: tag,
    sparkline: sparkline, lineChart: lineChart, barH: barH, donut: donut, chart: chart,
    kpiCard: kpiCard2, kpiRow: kpiRow2, donutCard: donutCard, barCard: barCard, feedCard: feedCard, panels: panels,
    virtualTable: virtualTable,
    loadSections: loadSections, dataChanged: dataChanged, onDataChanged: onDataChanged, hasEdits: hasEdits,
    schemaFields: schemaFields, form: form, editTable: editTable, detailDrawer: detailDrawer,
    cardList: cardList, filterBar: filterBar,
    dialog: dialog, formDialog: formDialog, menu: menu, toast: toast,
    tabs: tabs, segmented: segmented, periodNav: periodNav, steps: steps,
    table: table, section: section, descriptions: descriptions, timeline: timeline, funnel: funnel, heatmap: heatmap,
    bar: bar, delta: delta, banner: banner, empty: empty, skeleton: skeleton, icon: icon, fmtNum: fmtNum,
    calendar: calendar, kanban: kanban, importer: importer, parseCsv: parseCsv,
    print: printAlias('print'), downloadPdf: printAlias('downloadPdf'),
    download: printAlias('download'), confirm: printAlias('confirm'),
    alert: printAlias('alert'), prompt: printAlias('prompt'),
  };
  // The export bar, when export.js ran first.
  var ex = window.gsExport || {};
  for (var k in ex) window.gsDash[k] = ex[k];
})();
