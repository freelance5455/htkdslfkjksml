/* agentdb.print / agentdb.downloadPdf, see backend/agentdb/app_print. ES5.
   Serve splices markup around it: no closing script tag, HTML comment or
   html / head tag in this file. */
(function () {
var w = window, d = document;
var api = w.agentdb || (w.agentdb = {});
if (typeof api.print === 'function') return;
// The app owner's gk_agentbase_app_print, filled at serve time.
var ENABLED = false === true;
// Characters, as in the parent: one snapshot, and all of a split's parts.
var CAP = 30 * 1024 * 1024;
var PARTS_CAP = 100 * 1024 * 1024;
var MAX_PARTS = 200;
var ACK_MS = 3000;
// The AgentBase page serves the app from its own origin, so only it may get
// the snapshot; a site that frames the app receives nothing.
var HOST = (function () { try { return new URL(w.location.href).origin; } catch (e) { return ''; } })();
var JSPDF = 'https://cdn.jsdelivr.net/npm/jspdf@4.2.1/dist/jspdf.umd.min.js';
var JSPDF_SRI = 'sha384-qovJwSBbRDPP5cEjCp8S0UP66wrvnjaa60XMOGzTNanrThcrGfXfnZkvgY8N1KT3';
var MISSING_IMG = 'data:image/gif;base64,R0lGODlhAQABAIAAAO7u7gAAACwAAAAAAQABAAACAkQBADs=';
var SVG_NS = 'http://www.w3.org/2000/svg';
var PAPER = { a4: [210, 297], letter: [215.9, 279.4], a3: [297, 420] };
var OPTIONS = ['pageSize', 'orientation', 'margin', 'keepDarkMode', 'title', 'filename', 'pageNumbers'];
var DROP = 'script,noscript,iframe,frame,frameset,object,embed,applet,portal,video,audio,source,track,meta[http-equiv],base,[data-gs-print-toast],[data-ab-select-ui]';
var CODES = ['NOT_USER_ACTIVATED', 'BUSY', 'TOO_LARGE', 'RENDER_TIMEOUT', 'PRINT_UNAVAILABLE', 'PDF_FAILED', 'TARGET_NOT_FOUND'];
var TEXT = {
  en: ['Click the button again to print.', 'Another print is running. Try again shortly.', 'Too large to print. Try a smaller part.', 'Print timed out. Try again.', 'Printing is not available here.', 'Could not create the PDF. Reload the page and try again.', 'Nothing found to print.'],
  zh: ['请再点一次按钮打印。', '另一个打印还在进行,请稍后再试。', '内容太大,请只打印一部分。', '打印超时,请重试。', '这里不能打印。', 'PDF 生成失败,请刷新页面后再试。', '没有找到要打印的内容。'],
  ko: ['인쇄하려면 버튼을 다시 눌러 주세요.', '다른 인쇄가 진행 중입니다. 잠시 후 다시 시도해 주세요.', '너무 커서 인쇄할 수 없습니다.', '인쇄 시간이 초과되었습니다.', '여기에서는 인쇄할 수 없습니다.', 'PDF를 만들지 못했습니다. 페이지를 새로고침한 뒤 다시 시도해 주세요.', '인쇄할 내용이 없습니다.'],
  ja: ['もう一度ボタンを押して印刷してください。', '別の印刷を処理中です。少し待ってください。', '大きすぎて印刷できません。', '印刷がタイムアウトしました。', 'ここでは印刷できません。', 'PDF を作成できませんでした。ページを再読み込みしてからもう一度お試しください。', '印刷する内容が見つかりません。']
};
var WHY = {
  NO_PARENT: 'no AgentBase page around the app',
  PARENT_UNSUPPORTED: 'this AgentBase page cannot print yet',
  NO_ACK: 'no answer from the AgentBase page in 3 s',
  DISABLED: 'printing is not on for this app yet'
};
var seq = 0, pending = {}, building = false, toastEl = null, toastTimer = 0;
var cache = {}, cached = 0, jsPdf = null;

function text(code) {
  var i = CODES.indexOf(code);
  var lang = String(d.documentElement.lang || navigator.language || '').slice(0, 2).toLowerCase();
  return i < 0 ? '' : (TEXT[lang] || TEXT.en)[i];
}

function fail(code, message) {
  var e = new Error(message || text(code) || code);
  e.code = code;
  return e;
}

function activated() {
  var ua = navigator.userActivation;
  return !!(ua && ua.isActive);
}

// A print from inside an app's beforeprint listener must not recurse.
function fire(type) {
  building = true;
  try { w.dispatchEvent(new Event(type)); } catch (e) {} finally { building = false; }
}

function each(list, fn) {
  for (var i = list.length - 1; i >= 0; i--) fn(list[i], i);
}

function remove(n) {
  if (n && n.parentNode) n.parentNode.removeChild(n);
}

function abs(url, base) {
  try { return new URL(url, base || d.baseURI).href; } catch (e) { return ''; }
}

function toast(code, message) {
  try {
    var t = toastEl;
    if (!t || !t.parentNode) {
      t = toastEl = d.createElement('div');
      t.className = 'gs-no-print';
      t.setAttribute('data-gs-print-toast', '');
      t.setAttribute('role', 'status');
      t.style.cssText = 'position:fixed;left:50%;bottom:24px;transform:translateX(-50%);z-index:2147483647;max-width:90vw;padding:10px 16px;border-radius:8px;background:#1f2937;color:#fff;font:14px sans-serif';
      (d.body || d.documentElement).appendChild(t);
    }
    t.textContent = text(code) || message || code;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { remove(t); }, 6000);
  } catch (e) {}
}

function findTarget(t) {
  var root = d.documentElement;
  if (t == null || t === '' || t === d) return root;
  if (typeof t === 'string') {
    try { return d.querySelector(t); } catch (e) { return null; }
  }
  return t && t.nodeType === 1 && root.contains(t) ? t : null;
}

// Snapshot: the whole document, so a region keeps its ancestors' styles,
// with live state written into attributes.
function pairs(a, b, sel, fn) {
  var x = a.querySelectorAll(sel), y = b.querySelectorAll(sel);
  for (var i = 0; i < x.length && i < y.length; i++) fn(x[i], y[i], i);
}

function rules(sheet) {
  try {
    return Array.prototype.map.call(sheet.cssRules, function (r) { return r.cssText; }).join('\n');
  } catch (e) { return ''; }
}

function toggle(el, name, on) {
  if (on) el.setAttribute(name, ''); else el.removeAttribute(name);
}

function freeze(a, b) {
  var type = String(a.type || '').toLowerCase();
  if (a.nodeName === 'TEXTAREA') b.textContent = a.value;
  else if (a.nodeName === 'SELECT') pairs(a, b, 'option', function (o, c) { toggle(c, 'selected', o.selected); });
  else if (type === 'checkbox' || type === 'radio') toggle(b, 'checked', a.checked);
  else if (type === 'password' || type === 'file') b.removeAttribute('value');
  else if (type !== 'image') b.setAttribute('value', a.value);
}

function canvasImage(a, b, i, warnings) {
  var url, img, r, k;
  try { url = a.toDataURL('image/png'); } catch (e) {
    warnings.push({ code: 'CANVAS_TAINTED', target: a.id ? '#' + a.id : 'canvas ' + (i + 1) });
    return;
  }
  r = a.getBoundingClientRect();
  img = d.createElement('img');
  for (k = 0; k < b.attributes.length; k++) {
    if (!/^(width|height)$/i.test(b.attributes[k].name)) img.setAttribute(b.attributes[k].name, b.attributes[k].value);
  }
  img.setAttribute('src', url);
  img.setAttribute('width', String(Math.round(r.width) || a.width));
  img.setAttribute('height', String(Math.round(r.height) || a.height));
  img.setAttribute('data-gs-canvas', '');
  img.style.maxWidth = '100%';
  img.style.height = 'auto';
  b.parentNode.replaceChild(img, b);
}

// Off the target's ancestor chain: emptied and hidden (stubs keep sibling
// selectors matching).
function isolate(el) {
  el.setAttribute('data-gs-print-target', '');
  for (var node = el; node.parentNode && node.nodeName !== 'BODY'; node = node.parentNode) {
    each(node.parentNode.childNodes, function (k) {
      var tag = k.nodeName.toLowerCase(), stub;
      if (k === node) return;
      if (k.nodeType === 3) {
        if (/\S/.test(k.nodeValue)) remove(k);
        return;
      }
      if (k.nodeType !== 1 || tag === 'style' || tag === 'link' || tag === 'template') return;
      stub = tag === 'svg' ? k : k.cloneNode(false);
      stub.setAttribute('data-gs-print-hidden', '');
      if (stub !== k) k.parentNode.replaceChild(stub, k);
    });
  }
}

function scriptUrl(v) {
  var s = String(v).slice(0, 512).replace(/[\u0000-\u0020]+/g, '').toLowerCase();
  return /^(javascript|vbscript):|^data:text\/html/.test(s);
}

// Not a security boundary: the parent's frame runs no scripts and fetches
// nothing either way.
function sanitize(root) {
  each(root.querySelectorAll(DROP), remove);
  each(root.querySelectorAll('link'), function (l) {
    var rel = l.getAttribute('rel') || '';
    if (!/(^|\s)stylesheet(\s|$)/i.test(rel) || /alternate/i.test(rel)) remove(l);
  });
  each(root.querySelectorAll('*'), function (el) {
    for (var j = el.attributes.length - 1, name; j >= 0; j--) {
      name = el.attributes[j].name.toLowerCase();
      if (name.slice(0, 2) === 'on' || /^(srcset|sizes|loading|ping|srcdoc)$/.test(name) ||
          (/^(href|src|action|formaction|xlink:href|data|poster|background)$/.test(name) && scriptUrl(el.attributes[j].value))) {
        el.removeAttribute(el.attributes[j].name);
      }
    }
  });
}

function cloneDocument(el, warnings) {
  var root = d.documentElement, copy = root.cloneNode(true), mark = copy, path = [], n, i;
  for (n = el; n !== root; n = n.parentNode) path.unshift(Array.prototype.indexOf.call(n.parentNode.childNodes, n));
  for (i = 0; i < path.length; i++) mark = mark.childNodes[path[i]];
  // CSS-in-JS fills empty <style> tags via insertRule.
  pairs(root, copy, 'style', function (a, b) { if (!/\S/.test(a.textContent)) b.textContent = rules(a.sheet); });
  pairs(root, copy, 'link', function (a, b) { b.gsSource = a; });
  pairs(root, copy, 'input,textarea,select', freeze);
  pairs(root, copy, 'img', function (a, b) { if (a.currentSrc || a.src) b.setAttribute('src', a.currentSrc || a.src); });
  pairs(root, copy, 'canvas', function (a, b, k) { canvasImage(a, b, k, warnings); });
  if (el !== root && el !== d.body) isolate(mark);
  sanitize(copy);
  return copy;
}

// Every resource travels inside the snapshot as a data: URL.
function get(url, asText) {
  var ctl = w.AbortController && new AbortController();
  var timer = setTimeout(function () { if (ctl) ctl.abort(); }, 8000);
  return fetch(url, { credentials: 'omit', signal: ctl ? ctl.signal : undefined }).then(function (res) {
    if (!res.ok) throw new Error('HTTP ' + res.status);
    return asText ? res.text() : res.blob();
  }).then(function (v) {
    clearTimeout(timer);
    return v;
  }, function (e) {
    clearTimeout(timer);
    throw e;
  });
}

function dataUrl(url) {
  if (!cache[url]) {
    cache[url] = get(url).then(function (blob) {
      // Untyped images and fonts get sniffed; SVG never does.
      if (!blob.type && /\.svg([?#]|$)/i.test(url)) blob = new Blob([blob], { type: 'image/svg+xml' });
      return new Promise(function (resolve, reject) {
        var r = new FileReader();
        r.addEventListener('load', function () { resolve(String(r.result)); });
        r.addEventListener('error', reject);
        r.readAsDataURL(blob);
      });
    }).then(function (v) {
      cached += v.length;
      if (cached > 64 * 1024 * 1024) { cache = {}; cached = 0; }
      return v;
    }, function () {
      delete cache[url];
      return '';
    });
  }
  return cache[url];
}

function attr(el, name, warnings, placeholder) {
  var raw = el.getAttribute(name), url = raw && abs(raw);
  if (!raw) return el.removeAttribute(name);
  if (/^data:/i.test(url)) return;
  return (url ? dataUrl(url) : Promise.resolve('')).then(function (v) {
    if (!v) warnings.push({ code: 'RESOURCE_UNAVAILABLE', url: url || raw });
    if (v || placeholder) el.setAttribute(name, v || placeholder); else el.removeAttribute(name);
  });
}

function codepoints(root) {
  var s = root.textContent || '', seen = {}, list = [], i, c;
  each(root.querySelectorAll('[value],[placeholder]'), function (el) {
    s += (el.getAttribute('value') || '') + (el.getAttribute('placeholder') || '');
  });
  for (i = 0; i < s.length; i++) {
    c = s.codePointAt(i);
    if (c > 0xffff) i++;
    if (!seen[c]) { seen[c] = 1; list.push(c); }
  }
  return list.sort(function (a, b) { return a - b; });
}

// Inline only the unicode-range subsets (CJK fonts ship dozens) the page uses.
function hits(spec, used) {
  var parts = String(spec).split(','), any = false, k, m, lo, hi, a, b, mid;
  for (k = 0; k < parts.length; k++) {
    m = /u\+([0-9a-f?]+)(?:-([0-9a-f]+))?/i.exec(parts[k]);
    if (!m) continue;
    any = true;
    lo = parseInt(m[1].replace(/\?/g, '0'), 16);
    hi = m[2] ? parseInt(m[2], 16) : parseInt(m[1].replace(/\?/g, 'f'), 16);
    for (a = 0, b = used.length; a < b;) {
      mid = (a + b) >> 1;
      if (used[mid] < lo) a = mid + 1; else b = mid;
    }
    if (a < used.length && used[a] <= hi) return true;
  }
  return !any;
}

function urls(css, base, warnings) {
  var lower = css.toLowerCase(), out = [], jobs = [], last = 0, i = 0, j, q, end, raw;
  while ((i = lower.indexOf('url(', i)) !== -1) {
    for (j = i + 4; /\s/.test(css.charAt(j)); j++);
    q = css.charAt(j);
    if (q === '"' || q === "'") {
      end = css.indexOf(q, j + 1);
      raw = css.slice(j + 1, end);
      end = end < 0 ? -1 : css.indexOf(')', end);
    } else {
      end = css.indexOf(')', j);
      raw = css.slice(j, end).trim();
    }
    if (end < 0) break;
    out.push(css.slice(last, i));
    if (!raw || raw.charAt(0) === '#' || /^data:/i.test(raw)) {
      out.push(css.slice(i, end + 1));
    } else {
      out.push('');
      (function (slot, url) {
        jobs.push((url ? dataUrl(url) : Promise.resolve('')).then(function (v) {
          if (!v) warnings.push({ code: 'RESOURCE_UNAVAILABLE', url: url || raw });
          out[slot] = 'url("' + (v || 'data:,') + '")';
        }));
      })(out.length - 1, abs(raw, base));
    }
    last = i = end + 1;
  }
  out.push(css.slice(last));
  return Promise.all(jobs).then(function () { return out.join(''); });
}

function imports(css, base, used, warnings, depth) {
  var re = /@import\s+(?:url\(\s*)?(['"]?)([^'")\s;]+)\1\s*\)?([^;]*);?/gi, out = [], jobs = [], last = 0, m;
  while ((m = re.exec(css))) {
    out.push(css.slice(last, m.index), '');
    last = re.lastIndex;
    (function (slot, url, media) {
      jobs.push((url && depth < 4 ? get(url, true) : Promise.reject()).then(function (t) {
        return style(t, url, used, warnings, depth + 1);
      }).then(function (t) {
        out[slot] = media ? '@media ' + media + '{' + t + '}' : t;
      }, function () {
        warnings.push({ code: 'RESOURCE_UNAVAILABLE', url: url });
      }));
    })(out.length - 1, abs(m[2], base), m[3].trim());
  }
  out.push(css.slice(last));
  return Promise.all(jobs).then(function () { return out.join(''); });
}

function style(css, base, used, warnings, depth) {
  css = String(css || '').replace(/\/\*[\s\S]*?\*\//g, '');
  return imports(css, base, used, warnings, depth || 0).then(function (t) {
    if (used) {
      t = t.replace(/@font-face\s*\{[^}]*\}/gi, function (face) {
        var m = /unicode-range\s*:([^;}]*)/i.exec(face);
        return m && !hits(m[1], used()) ? '' : face;
      });
    }
    return urls(t, base, warnings);
  });
}

function sheet(link, used, warnings) {
  var url = abs(link.getAttribute('href') || ''), source = link.gsSource, st = d.createElement('style');
  if (link.getAttribute('media')) st.setAttribute('media', link.getAttribute('media'));
  link.parentNode.replaceChild(st, link);
  return (url ? get(url, true) : Promise.reject()).then(null, function () {
    // A sheet the fetch cannot read may still be readable in the page.
    var t = source && rules(source.sheet);
    if (t) return t;
    warnings.push({ code: 'RESOURCE_UNAVAILABLE', url: url });
    return '';
  }).then(function (t) {
    return style(t, url || d.baseURI, used, warnings, 1);
  }).then(function (t) { st.textContent = t; });
}

// chars: a split's codepoints, so every part keeps the same font subsets.
function inline(root, warnings, chars) {
  var jobs = [];
  function used() { return chars || (chars = codepoints(root)); }
  each(root.querySelectorAll('*'), function (el) {
    var tag = el.localName, css = el.getAttribute('style'), k, v, name;
    if (tag === 'style') {
      jobs.push(style(el.textContent, d.baseURI, used, warnings).then(function (t) { el.textContent = t; }));
      return;
    }
    if (tag === 'link') return jobs.push(sheet(el, used, warnings));
    if (css && /url\(/i.test(css)) jobs.push(style(css, d.baseURI, null, warnings).then(function (t) { el.setAttribute('style', t); }));
    if (el.hasAttribute('background')) jobs.push(attr(el, 'background', warnings, ''));
    if (tag === 'img' || tag === 'input') {
      if (el.hasAttribute('src')) jobs.push(attr(el, 'src', warnings, MISSING_IMG));
      return;
    }
    if (el.namespaceURI !== SVG_NS || tag === 'a') return;
    for (k = 0; k < 2; k++) {
      name = k ? 'xlink:href' : 'href';
      v = el.getAttribute(name);
      if (!v || v.charAt(0) === '#' || /^data:/i.test(v)) continue;
      if (tag === 'image' || tag === 'feImage') jobs.push(attr(el, name, warnings, MISSING_IMG));
      else {
        el.removeAttribute(name);
        warnings.push({ code: 'RESOURCE_UNAVAILABLE', url: abs(v) });
      }
    }
  });
  return Promise.all(jobs);
}

function snapshot(el, warnings, chars) {
  var copy;
  fire('beforeprint');
  try { copy = cloneDocument(el, warnings); } finally { fire('afterprint'); }
  return inline(copy, warnings, chars).then(function () {
    return '<!DOCTYPE html>\n' + copy.outerHTML;
  });
}

// Fallback: rasterise the page (export guard) and build the PDF here.
function loadJsPdf() {
  if (jsPdf) return jsPdf;
  jsPdf = new Promise(function (resolve, reject) {
    var s = d.createElement('script'), had = ['jspdf' in w, 'jsPDF' in w], old = [w.jspdf, w.jsPDF];
    // An app's own jsPDF (legacy exports) keeps its globals.
    function done(ok) {
      var ns = w.jspdf, C = (ns && ns.jsPDF) || w.jsPDF;
      ['jspdf', 'jsPDF'].forEach(function (k, i) {
        if (had[i]) w[k] = old[i];
        else try { delete w[k]; } catch (e) { w[k] = undefined; }
      });
      remove(s);
      if (ok && typeof C === 'function') resolve(C); else reject(new Error('jsPDF did not load'));
    }
    s.src = JSPDF;
    s.async = true;
    s.crossOrigin = 'anonymous';
    s.integrity = JSPDF_SRI;
    s.addEventListener('load', function () { done(true); });
    s.addEventListener('error', function () { done(false); });
    (d.head || d.documentElement).appendChild(s);
  });
  jsPdf.then(null, function () { jsPdf = null; });
  return jsPdf;
}

function raster(el) {
  var hooks = w.__gsPrintHooks, guard = w.__gsExportCaptureGuard;
  var fn = (hooks && hooks.rasterize) || (guard && guard.rasterize) || w.html2canvas;
  if (typeof fn !== 'function') return Promise.reject(new Error('no rasterizer on this page'));
  return Promise.resolve(fn(el === d.documentElement ? d.body : el, { scale: 2, backgroundColor: '#ffffff' }));
}

function mm(v) {
  var r = /^\s*(\d+(?:\.\d+)?)\s*(mm|cm|in|pt|px)?\s*$/i.exec(v == null ? '' : String(v));
  return r ? r[1] * ({ cm: 10, 'in': 25.4, pt: 25.4 / 72, px: 25.4 / 96 }[String(r[2]).toLowerCase()] || 1) : null;
}

function paper(o) {
  var s = PAPER[String(o.pageSize || 'a4').toLowerCase()] || PAPER.a4, land = /^landscape$/i.test(o.orientation), m = mm(o.margin);
  if (m == null || m > 60) m = 15;
  return { w: s[land ? 1 : 0], h: s[land ? 0 : 1], m: m };
}

function cleanName(v) {
  var s = String(v == null ? '' : v)
    .replace(/[\u0000-\u001f\u007f-\u009f\u200b-\u200f\u202a-\u202e\u2066-\u2069\ufeff]/g, '')
    .replace(/[\\/:*?"<>|]+/g, '_')
    .replace(/\.{2,}/g, '.')
    .replace(/^[\s.]+|[\s.]+$/g, '')
    .replace(/\.pdf$/i, '');
  return Array.from(s).slice(0, 80).join('');
}

function fileName(v) {
  return (cleanName(v) || cleanName(d.title) || 'document') + '.pdf';
}

function makePdf(C, canvas, o, kind) {
  var g = paper(o), cw = g.w - 2 * g.m, ch = g.h - 2 * g.m, turn = g.w > g.h ? 'l' : 'p';
  var doc = new C({ orientation: turn, unit: 'mm', format: [g.w, g.h], compress: true });
  var img = canvas.toDataURL('image/jpeg', 0.85);
  var tall = canvas.height * cw / Math.max(1, canvas.width);
  var n = Math.max(1, Math.ceil(tall / ch - 1e-6)), i;
  for (i = 0; i < n; i++) {
    if (i) doc.addPage([g.w, g.h], turn);
    // One image, shifted a page up each time, clipped to the content box.
    doc.saveGraphicsState();
    doc.rect(g.m, g.m, cw, ch, null);
    doc.clip();
    doc.discardPath();
    doc.addImage(img, 'JPEG', g.m, g.m - i * ch, cw, tall, 'gsprint', 'FAST');
    doc.restoreGraphicsState();
    if (o.pageNumbers === true) {
      doc.setFontSize(9);
      doc.setTextColor(110);
      doc.text(i + 1 + ' / ' + n, g.w / 2, g.h - g.m / 2, { align: 'center', baseline: 'middle' });
    }
  }
  doc.save(fileName(kind === 'print' ? o.title : o.filename));
  return n;
}

function fallback(kind, reason, el, o, active) {
  if (!active) return Promise.reject(fail('NOT_USER_ACTIVATED'));
  try {
    console.info('[agentdb.' + kind + '] ' + reason + ' (' + WHY[reason] + '): downloading a PDF made in the app; web fonts show as system fonts' +
      (splitting(kind, o) ? ', and the split parts come as one PDF.' : '.'));
  } catch (e) {}
  fire('beforeprint');
  return Promise.all([loadJsPdf(), raster(el)]).then(function (r) {
    fire('afterprint');
    // A target with no width or no height captures nothing to print.
    if (!r[1].width || !r[1].height) throw fail('TARGET_NOT_FOUND');
    return { ok: true, fallback: true, reason: reason, pages: makePdf(r[0], r[1], o, kind) };
  }, function (e) {
    fire('afterprint');
    throw fail('PDF_FAILED', e && e.message);
  });
}

function pick(o) {
  var out = {};
  OPTIONS.forEach(function (k) {
    if (o[k] != null && typeof o[k] !== 'object' && typeof o[k] !== 'function') out[k] = o[k];
  });
  return out;
}

function merge(result, warnings) {
  var out = {}, k;
  if (result && typeof result === 'object') for (k in result) out[k] = result[k];
  out.warnings = warnings.concat(Array.isArray(out.warnings) ? out.warnings : []);
  return out;
}

function ours(id) {
  return typeof id === 'string' && id.indexOf('gsprint:') === 0 && pending.hasOwnProperty(id);
}

function ask(method, snap, o, warnings, el, active, id) {
  return new Promise(function (resolve, reject) {
    var entry = { acked: false };
    id = id || 'gsprint:' + (++seq);
    entry.settle = function (result, error) {
      clearTimeout(entry.timer);
      delete pending[id];
      if (error == null) return resolve(merge(result, warnings));
      if (typeof error === 'string' && /unknown method/i.test(error)) return resolve(fallback(method, 'PARENT_UNSUPPORTED', el, o, active));
      reject(fail(error.code || 'PRINT_UNAVAILABLE', error.message || String(error)));
    };
    // No timeout after the ack (a print dialog blocks the parent); the grace
    // lets an ack queued behind a blocked page still win.
    entry.timer = setTimeout(function () {
      entry.timer = setTimeout(function () {
        if (ours(id) && !entry.acked) {
          delete pending[id];
          resolve(fallback(method, 'NO_ACK', el, o, active));
        }
      }, 60);
    }, ACK_MS);
    pending[id] = entry;
    w.parent.postMessage({
      type: 'agentdb:request',
      id: id,
      method: method,
      params: {
        reserve: snap.reserve,
        html: snap.html,
        parts: snap.parts,
        shared: snap.shared,
        zip: snap.parts ? cleanName(o.zip).replace(/\.zip$/i, '') : undefined,
        options: pick(o),
        layout: { width: d.documentElement.clientWidth || w.innerWidth, height: w.innerHeight }
      }
    }, HOST);
  });
}

// downloadPdf with `split`: one snapshot per matching element inside the
// target, each its own PDF, all saved by the page as one ZIP. A part's file
// name is its data-gs-filename, else the filename option (or the title) and
// its number.
// A large <style> every part repeats (inlined fonts: megabytes) goes once,
// as `shared`; each part keeps an empty stand-in.
function splitSnapshots(list, o, warnings, chars) {
  var parts = [], shared = [], seen = {}, total = 0, base = cleanName(o.filename) || cleanName(d.title) || 'document';
  return Array.prototype.reduce.call(list, function (chain, part, i) {
    return chain.then(function () {
      return snapshot(part, warnings, chars);
    }).then(function (html) {
      if (html.length > CAP) throw fail('TOO_LARGE');
      html = html.replace(/<style([^>]*)>([^<]*)<\/style>/g, function (m, attrs, css) {
        if (css.length < 4096) return m;
        if (!seen.hasOwnProperty(css)) total += css.length, seen[css] = shared.push(css) - 1;
        return '<style' + attrs + ' data-gs-shared="' + seen[css] + '"></style>';
      });
      total += html.length;
      if (total > PARTS_CAP) throw fail('TOO_LARGE');
      parts.push({ html: html, filename: cleanName(part.getAttribute('data-gs-filename')) || base + '-' + (i + 1) });
    });
  }, Promise.resolve()).then(function () {
    return { html: '', parts: parts, shared: shared };
  });
}

function splitting(method, o) {
  // Off with gk_agentbase_app_files (file_bridge.js): one PDF of the target.
  return method === 'downloadPdf' && typeof o.split === 'string' && !!o.split && api._filesEnabled === true;
}

function snapshotFor(method, el, o, warnings) {
  return snapshot(el, warnings).then(function (html) {
    if (html.length > CAP) throw fail('TOO_LARGE');
    return { html: html };
  });
}

// A split's parts can outlast the click, so the page checks the click on a
// reserve request first and takes the parts under the same id.
function splitRun(method, el, o, warnings, active) {
  var list, id = 'gsprint:' + (++seq);
  try { list = el.querySelectorAll(o.split); } catch (e) {}
  if (!list || !list.length) return Promise.reject(fail('TARGET_NOT_FOUND'));
  if (list.length > MAX_PARTS) return Promise.reject(fail('TOO_LARGE'));
  return ask(method, { reserve: true }, o, [], el, active, id).then(function (r) {
    return r.fallback ? r : splitSnapshots(list, o, warnings, codepoints(el)).then(function (snap) {
      return ask(method, snap, o, warnings, el, active, id);
    });
  }, function (e) {
    // An older page refuses reserve: one PDF of the target.
    if (e.code !== 'PRINT_UNAVAILABLE') throw e;
    return snapshotFor(method, el, o, warnings).then(function (snap) {
      return ask(method, snap, o, warnings, el, active);
    });
  });
}

function run(method, t, options) {
  var o = options && typeof options === 'object' ? options : {};
  var active = activated(), el = building ? null : findTarget(t), warnings = [], p;
  if (building) p = Promise.reject(fail('BUSY'));
  else if (!el) p = Promise.reject(fail('TARGET_NOT_FOUND'));
  else if (!ENABLED) p = fallback(method, 'DISABLED', el, o, active);
  else if (w.parent === w || !/^https?:/.test(HOST)) p = fallback(method, 'NO_PARENT', el, o, active);
  else {
    // The page refuses a call no click started: skip the costly snapshot
    // when this frame knows that, and still ask, as the page decides.
    p = splitting(method, o) ? splitRun(method, el, o, warnings, active) :
      (active || !navigator.userActivation ? snapshotFor(method, el, o, warnings) : Promise.resolve({ html: '' })).then(function (snap) {
        return ask(method, snap, o, warnings, el, active);
      });
  }
  return p.then(null, function (e) {
    if (!e || !e.code) e = fail(method === 'print' ? 'PRINT_UNAVAILABLE' : 'PDF_FAILED', e && e.message);
    // MEMBERSHIP_REQUIRED: the AgentBase page shows its upgrade wall instead.
    if (o.quiet !== true && e.code !== 'MEMBERSHIP_REQUIRED') toast(e.code, e.message);
    throw e;
  });
}

w.addEventListener('message', function (e) {
  var m = e.data, i;
  if (!m || w.parent === w || e.source !== w.parent) return;
  if (m.type === 'agentdb:progress' && m.ids && m.ids.length) {
    for (i = 0; i < m.ids.length; i++) {
      if (ours(m.ids[i]) && !pending[m.ids[i]].acked) {
        pending[m.ids[i]].acked = true;
        clearTimeout(pending[m.ids[i]].timer);
      }
    }
  } else if (m.type === 'agentdb:response' && ours(m.id)) {
    pending[m.id].settle(m.result, m.error);
  }
});

api.print = function (target, options) { return run('print', target, options); };
api.downloadPdf = function (target, options) { return run('downloadPdf', target, options); };
// The bridge's printSnapshot command.
Object.defineProperty(api, '_printSnapshot', {
  value: function (t) {
    var el = findTarget(t), warnings = [];
    if (!el) return Promise.reject(fail('TARGET_NOT_FOUND'));
    return snapshot(el, warnings).then(function (html) {
      if (html.length > CAP) throw fail('TOO_LARGE');
      return { html: html, warnings: warnings };
    });
  }
});
// Legacy window.print(), which the sandbox ignores.
if (ENABLED) {
  w.print = function () {
    api.print().then(null, function () {});
  };
}
})();
