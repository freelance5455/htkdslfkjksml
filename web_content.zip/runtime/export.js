/* ============================================================
   B-Suite dashboard export bar: gsExport (and gsDash) toCsv / downloadCsv / exportBar.
   Injected at serve time into every data-palette dashboard, after the kit
   when the kit is injected too. Kept out of kit.js because the shipped
   templates inline the design system, which skips the kit. ES5-compatible.
   ============================================================ */
(function () {
  // window.gsExport always; window.gsDash too when the kit ran first (kit.js
  // copies gsExport in when it runs later). A page without the kit gets no
  // window.gsDash, so `if (window.gsDash)` still means the kit is there.
  if (window.gsExport) return;
  var g = window.gsExport = {};

  // agentdb.X, or a PRINT_UNAVAILABLE rejection on a page without it.
  function bridgeCall(name, args) {
    var bridge = window.agentdb;
    if (bridge && typeof bridge[name] === 'function') return bridge[name].apply(bridge, args);
    var err = new Error('agentdb.' + name + ' is not available on this page');
    err.code = 'PRINT_UNAVAILABLE';
    return Promise.reject(err);
  }

  // A cell Excel would run as a formula (=, +, -, @, tab, CR at the start)
  // gets a leading apostrophe: exported rows are data from the table, and a
  // value someone typed must not become a formula on another machine. Plain
  // numbers (-5, "-12.50") stay numbers, so Excel can still sum them.
  function csvCell(v) {
    if (v == null) return '';
    var s = typeof v === 'object' ? JSON.stringify(v) : String(v);
    if (/^[=+\-@\t\r]/.test(s) && !/^-\d+(\.\d+)?$/.test(s)) s = "'" + s;
    return /[",\r\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
  }

  // gsDash.toCsv(rows, columns?): rows are objects (executeQuery's rows).
  // columns: keys, or {key, label}; default every key of the first row.
  function toCsv(rows, columns) {
    rows = rows || [];
    var cols = (columns && columns.length ? columns : Object.keys(rows[0] || {})).map(function (c) {
      return typeof c === 'string' ? { key: c, label: c } : { key: c.key, label: c.label == null ? c.key : c.label };
    });
    var out = [cols.map(function (c) { return csvCell(c.label); }).join(',')];
    rows.forEach(function (r) {
      out.push(cols.map(function (c) { return csvCell(r == null ? '' : r[c.key]); }).join(','));
    });
    return out.join('\r\n');
  }

  function downloadCsv(rows, filename, columns) {
    var name = String(filename || 'export');
    if (!/\.csv$/i.test(name)) name += '.csv';
    return bridgeCall('download', [toCsv(rows, columns), name]);
  }

  var EXPORT_TEXT = {
    en: ['Print', 'PDF', 'CSV'],
    zh: ['打印', 'PDF', 'CSV'],
    ko: ['인쇄', 'PDF', 'CSV'],
    ja: ['印刷', 'PDF', 'CSV']
  };

  function exportText(i) {
    var lang = String(document.documentElement.lang || navigator.language || '').slice(0, 2).toLowerCase();
    return (EXPORT_TEXT[lang] || EXPORT_TEXT.en)[i];
  }

  // gsDash.exportBar(container, options): Print / PDF / CSV buttons wired to
  // agentdb.print, downloadPdf and download. Never printed itself.
  //   target    what Print and PDF capture (selector or element; whole page)
  //   filename  the PDF's name and the CSV's, without extension
  //   pdf       extra downloadPdf options ({ split: '.card', zip: 'cards' })
  //   csv       function () -> rows, or { rows, columns }; no CSV button
  //             without it. It may return a Promise (query on click).
  //   only      a subset of ['print', 'pdf', 'csv']
  // Renders nothing until the owner has gk_agentbase_app_files (the file
  // bridge's _filesEnabled), so dashboards can call it during the rollout.
  function exportBar(container, options) {
    var o = options || {}, host = typeof container === 'string' ? document.querySelector(container) : container;
    var bridge = window.agentdb;
    if (!host || !bridge || bridge._filesEnabled !== true) return null;
    var bar = document.createElement('div');
    bar.className = 'gs-actions gs-no-print';
    // Read on click: a localized page may set its title after this runs.
    function nameNow() { return o.filename || document.title || 'export'; }
    var actions = [
      ['print', 0, function () { return bridgeCall('print', [o.target, { title: nameNow() }]); }],
      ['pdf', 1, function () {
        var opt = { filename: nameNow(), pageNumbers: true }, k;
        for (k in (o.pdf || {})) opt[k] = o.pdf[k];
        return bridgeCall('downloadPdf', [o.target, opt]);
      }],
      ['csv', 2, function () {
        return Promise.resolve(o.csv()).then(function (data) {
          var rows = Array.isArray(data) ? data : (data && data.rows) || [];
          return downloadCsv(rows, (data && data.filename) || nameNow(), data && data.columns);
        });
      }]
    ];
    actions.forEach(function (a) {
      if (o.only && o.only.indexOf(a[0]) < 0) return;
      if (a[0] === 'csv' && typeof o.csv !== 'function') return;
      var b = document.createElement('button');
      b.type = 'button';
      b.className = 'btn btn-secondary btn-sm gs-act';
      b.setAttribute('data-gs-export', a[0]);
      b.textContent = exportText(a[1]);
      b.addEventListener('click', function () {
        if (b.disabled) return;
        b.disabled = true;
        // The bridge shows its own message on a failure.
        Promise.resolve().then(a[2]).then(null, function () {}).then(function () { b.disabled = false; });
      });
      bar.appendChild(b);
    });
    host.appendChild(bar);
    return bar;
  }

  g.toCsv = toCsv;
  g.downloadCsv = downloadCsv;
  g.exportBar = exportBar;
  if (window.gsDash) for (var k in g) window.gsDash[k] = g[k];
})();
