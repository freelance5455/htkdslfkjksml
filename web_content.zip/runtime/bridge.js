
(function() {
  // ── Storage shim ────────────────────────────────────────────
  // The iframe sandbox omits allow-same-origin so localStorage /
  // sessionStorage throw SecurityError. Provide an in-memory
  // fallback so generated app code that uses storage for non-
  // critical purposes (theme, preferences) doesn't crash.
  try { localStorage.getItem('_probe'); } catch(e) {
    var _makeStore = function() {
      var d = {};
      return {
        getItem: function(k) { return d.hasOwnProperty(k) ? d[k] : null; },
        setItem: function(k, v) { d[k] = String(v); },
        removeItem: function(k) { delete d[k]; },
        clear: function() { d = {}; },
        get length() { return Object.keys(d).length; },
        key: function(i) { var ks = Object.keys(d); return i < ks.length ? ks[i] : null; }
      };
    };
    try { Object.defineProperty(window, 'localStorage', { value: _makeStore(), configurable: true }); } catch(e2) {}
    try { Object.defineProperty(window, 'sessionStorage', { value: _makeStore(), configurable: true }); } catch(e2) {}
  }

  if (window.agentdb) return;
  var _reqId = 0;
  var _pending = {};
  // Registered-query metadata (name -> is_mutation), embedded at serve time
  // and handed to the parent forwarder in the bridgeReady handshake so it
  // can dedup/retry reads while never touching mutations (agent_tasks#140).
  var _queryMeta = {};
  var REQUEST_TIMEOUT_MS = 60000;
  // Re-arm window after a parent heartbeat. Wider than the initial timeout
  // because hidden tabs coalesce timers to one wakeup per minute: a 15s
  // heartbeat can then arrive up to ~60s apart and must still beat the
  // timer, so once the parent has proven alive the grace is 75s.
  var REARM_GRACE_MS = 75000;

  // ── Console log capture ──────────────────────────────────────
  var _consoleLogs = [];
  var _maxLogs = 500;
  var _origConsole = {
    log: console.log,
    warn: console.warn,
    error: console.error,
    info: console.info
  };

  function _captureArgs(args) {
    var out = [];
    for (var i = 0; i < args.length; i++) {
      try {
        out.push(args[i] === null ? 'null' : typeof args[i] === 'object' ? JSON.stringify(args[i]) : String(args[i]));
      } catch (e) {
        out.push('[unserializable]');
      }
    }
    return out;
  }

  ['log', 'warn', 'error', 'info'].forEach(function(level) {
    console[level] = function() {
      _consoleLogs.push({ type: level, data: _captureArgs(arguments).join(' '), ts: Date.now() });
      if (_consoleLogs.length > _maxLogs) _consoleLogs.shift();
      _origConsole[level].apply(console, arguments);
    };
  });

  function _recordError(entry) {
    _consoleLogs.push({ type: 'error', data: entry, ts: Date.now() });
    if (_consoleLogs.length > _maxLogs) _consoleLogs.shift();
  }

  // Tell the host page about an uncaught error or unhandled rejection
  // (agentbase_app_js_error). At most 5 a minute; never throws. An error
  // whose top frame is a browser extension's script (MetaMask rejects
  // "Failed to connect" in every frame) is not the app's: it stays in the
  // console log but is not reported, so it cannot use up the budget.
  var _jsErrSent = [];
  // No backslashes in this template: frontend tests read it raw from the
  // Python source (Python would halve them, the raw read would not).
  var _EXT_FRAME = /[a-z-]*extension:[/][/]/i;
  var _FRAME_END = /:[0-9]+(:[0-9]+)?[)]?$/;
  function _isExtensionStack(stack) {
    var lines = String(stack || '').split(String.fromCharCode(10));
    for (var i = 0; i < lines.length; i++) {
      var line = lines[i].trim();
      if (_FRAME_END.test(line)) return _EXT_FRAME.test(line);
    }
    return false;
  }
  function _reportJsError(msg, stack) {
    try {
      if (_isExtensionStack(stack)) return;
      var now = Date.now();
      _jsErrSent = _jsErrSent.filter(function(t) { return now - t < 60000; });
      if (_jsErrSent.length >= 5) return;
      _jsErrSent.push(now);
      window.parent.postMessage({
        type: 'agentdb:appJsError',
        message: String(msg).slice(0, 200),
        stack: String(stack || '').slice(0, 500)
      }, '*');
    } catch (e) {}
  }

  // Capture uncaught errors too. Registered in the CAPTURE phase: a
  // resource-load failure (a <script src> or <link href> the server refused)
  // fires `error` on the element and does not bubble, so without `true` it
  // never reaches window and a view whose assets all failed logs nothing.
  window.addEventListener('error', function(ev) {
    var t = ev.target;
    if (t && t !== window && (t.src || t.href)) {
      _recordError('[resource] failed to load ' + (t.src || t.href) +
        ' (<' + String(t.tagName || '').toLowerCase() + '>)');
    } else {
      _recordError('[uncaught] ' + (ev.message || '') + ' at ' + (ev.filename || '') + ':' + (ev.lineno || ''));
      _reportJsError(ev.message || '', ev.error && ev.error.stack);
    }
  }, true);

  // A rejected promise nobody handled (an executeQuery without a catch) and
  // a CSP block never reach the error listener above.
  window.addEventListener('unhandledrejection', function(ev) {
    var reason = ev.reason;
    _recordError('[rejection] ' + (reason && reason.message ? reason.message : String(reason)));
    _reportJsError(reason && reason.message ? reason.message : String(reason), reason && reason.stack);
  });
  document.addEventListener('securitypolicyviolation', function(ev) {
    _recordError('[csp] ' + (ev.effectiveDirective || ev.violatedDirective || '') +
      ' ' + (ev.blockedURI || 'inline'));
  });

  // A submit nobody prevented navigates this frame to its own origin, which
  // the sandbox loads without the session cookie: the view turns into a raw
  // 401. Bubble phase on window runs after the app's own listeners, and only
  // submissions that would land on this origin are stopped.
  window.addEventListener('submit', function(ev) {
    var form = ev.target;
    if (ev.defaultPrevented || !form || String(form.tagName).toLowerCase() !== 'form') return;
    var submitter = ev.submitter;
    function attr(name, override) {
      return submitter && submitter.hasAttribute && submitter.hasAttribute(override)
        ? submitter.getAttribute(override) : form.getAttribute(name);
    }
    if (String(attr('method', 'formmethod') || '').toLowerCase() === 'dialog') return;
    var target = String(attr('target', 'formtarget') || '').toLowerCase();
    if (target && target !== '_self') return;
    try {
      if (new URL(attr('action', 'formaction') || '', location.href).origin !== location.origin) return;
    } catch (e) {
      return;
    }
    ev.preventDefault();
    _recordError('[submit] form' + (form.id ? ' #' + form.id : '') +
      ' submitted natively; its submit handler did not run');
  });

  // ── Parent-initiated command handler ─────────────────────────
  // Parent sends: { type: 'agentdb:command', id, method, params }
  // We respond: { type: 'agentdb:commandResponse', id, result?, error? }

  window.addEventListener('message', function(e) {
    if (!e.data || e.data.type !== 'agentdb:command') return;
    var id = e.data.id;
    var method = e.data.method;
    var params = e.data.params || {};

    function respond(result, error) {
      window.parent.postMessage({
        type: 'agentdb:commandResponse', id: id, result: result, error: error || undefined
      }, '*');
    }

    if (method === 'getConsoleLogs') {
      respond({ logs: _consoleLogs.slice() });
    } else if (method === 'executeJs') {
      // Agents often send a function body: a top-level "return x" or
      // "await y" (2 of 2 prod fast-lane builds on 11-12/13, 8 of 69 calls in
      // dev evals), which eval rejects as a SyntaxError and costs the agent
      // a retry turn. Such code runs once more as an async function body,
      // but only when it failed to parse: a marker set by the code's first
      // statement tells a parse error (nothing ran) from a SyntaxError the
      // code threw while running (JSON.parse, ...), which is reported as is.
      // The marker is wrapped in void so its own value (true) never becomes
      // the result of code that only declares things.
      var _evalAgentCode = function(code) {
        var nl = String.fromCharCode(10);
        var mark = '__gsAgentEvalRan';
        window[mark] = false;
        try {
          return (0, eval)('void (window.' + mark + ' = true);' + nl + code);
        } catch (err) {
          var ran = window[mark];
          if (ran || !(err instanceof SyntaxError) || !/return|await/i.test(String(err.message))) throw err;
          var p = (0, eval)('(async function () {' + nl + code + nl + '})()');
          if (code.indexOf('return') !== -1) return p;
          // A function body has no completion value: "const r = await q(); r"
          // would resolve to undefined. Say so instead of a bare undefined.
          return p.then(function(v) {
            return v === undefined
              ? 'undefined (top-level await ran as an async function body: write "return <value>" to get a result)'
              : v;
          });
        } finally {
          try { delete window[mark]; } catch (e) { window[mark] = undefined; }
        }
      };
      var _serialize = function(v) {
        if (v === null || v === undefined) return String(v);
        if (typeof v === 'object') { try { return JSON.stringify(v); } catch(e) { return '[unserializable]'; } }
        return String(v);
      };
      try {
        var result = _evalAgentCode(params.code);
        // Handle promises
        if (result && typeof result === 'object' && typeof result.then === 'function') {
          result.then(function(v) {
            respond({ value: _serialize(v) });
          }).catch(function(err) { respond(null, String(err)); });
        } else {
          respond({ value: _serialize(result) });
        }
      } catch (err) {
        respond(null, String(err));
      }
    } else if (method === 'takeScreenshot') {
      // Serialize DOM snapshot for parent-side rendering.
      // html2canvas cannot run inside this iframe because sandbox without
      // allow-same-origin gives an opaque origin, causing cross-origin errors
      // when html2canvas creates its internal temp iframe.
      try {
        var clone = document.documentElement.cloneNode(true);

        // Convert <canvas> elements to <img> (preserve chart visuals)
        var origCanvases = document.querySelectorAll('canvas');
        var cloneCanvases = clone.querySelectorAll('canvas');
        for (var ci = 0; ci < origCanvases.length; ci++) {
          try {
            var cImg = document.createElement('img');
            cImg.src = origCanvases[ci].toDataURL('image/png');
            cImg.setAttribute('width', String(origCanvases[ci].width));
            cImg.setAttribute('height', String(origCanvases[ci].height));
            if (cloneCanvases[ci] && cloneCanvases[ci].parentNode) {
              cloneCanvases[ci].parentNode.replaceChild(cImg, cloneCanvases[ci]);
            }
          } catch (ce) { /* tainted canvas — keep original tag */ }
        }

        // Strip <script> tags (security: parent will render in allow-same-origin iframe)
        var scripts = clone.querySelectorAll('script');
        for (var si = scripts.length - 1; si >= 0; si--) {
          scripts[si].parentNode.removeChild(scripts[si]);
        }

        // Strip elements that could trigger authenticated same-origin requests
        // (the srcdoc iframe inherits parent origin via allow-same-origin)
        var dangerousTags = clone.querySelectorAll('object,embed,form,iframe,video,audio,source,track');
        for (var di = dangerousTags.length - 1; di >= 0; di--) {
          dangerousTags[di].parentNode.removeChild(dangerousTags[di]);
        }

        // Strip event handler attributes (onerror, onload etc.)
        var allEls = clone.querySelectorAll('*');
        for (var ai = 0; ai < allEls.length; ai++) {
          var attrs = allEls[ai].attributes;
          for (var ri = attrs.length - 1; ri >= 0; ri--) {
            if (attrs[ri].name.substring(0, 2) === 'on') {
              allEls[ai].removeAttribute(attrs[ri].name);
            }
          }
        }

        // Inject CSP to block network resource loads that would carry parent cookies.
        // Only inline styles and data:/blob: images are allowed — external CSS loads
        // are blocked but inline <style> tags (where chart libraries inject styles)
        // are preserved.  Canvas elements were already converted to data: URI images.
        var cspMeta = document.createElement('meta');
        cspMeta.setAttribute('http-equiv', 'Content-Security-Policy');
        var cspPolicy = "default-src 'none'; style-src 'unsafe-inline';";
        cspPolicy += " img-src data: blob:; font-src data:;";
        cspMeta.setAttribute('content', cspPolicy);
        var cloneHead = clone.querySelector('head');
        if (cloneHead) {
          cloneHead.insertBefore(cspMeta, cloneHead.firstChild);
        }

        var html = '<!DOCTYPE html>' + clone.outerHTML;
        var docEl = document.documentElement;
        var w, h;
        if (params.viewport) {
          // Viewport capture (params.viewport): only the visible area —
          // clientWidth/clientHeight — so the output has the iframe's fixed
          // viewport aspect ratio (used for the fixed-size homepage thumbnail).
          // The parent renders the full serialized DOM but html2canvas crops to
          // width x height from (0,0), i.e. the top of the page.
          w = Math.max(docEl.clientWidth || 0, 1);
          h = Math.max(docEl.clientHeight || 0, 1);
        } else {
          // Full-page capture (default): the entire scrollable document.
          w = Math.max(docEl.scrollWidth || 0, docEl.offsetWidth || 0, 800);
          h = Math.max(docEl.scrollHeight || 0, docEl.offsetHeight || 0, 600);
        }

        respond({ _parentRender: true, html: html, width: w, height: h });
      } catch (err) {
        respond(null, 'Screenshot serialization failed: ' + String(err));
      }
    } else if (method === 'printSnapshot') {
      // The page as it would print, built by app_print/print_bridge.js.
      var snap = window.agentdb && window.agentdb._printSnapshot;
      if (typeof snap !== 'function') {
        respond(null, 'printSnapshot is not available in this app');
      } else {
        snap(params.target).then(function(r) { respond(r); }, function(err) {
          respond(null, String((err && err.message) || err));
        });
      }
    } else {
      respond(null, 'Unknown command: ' + method);
    }
  });

  // ── App-initiated RPC (existing) ─────────────────────────────
  window.addEventListener('message', function(e) {
    if (!e.data || e.data.type !== 'agentdb:response') return;
    var cb = _pending[e.data.id];
    if (!cb) return;
    delete _pending[e.data.id];
    if (e.data.error) cb.reject(new Error(e.data.error));
    else cb.resolve(e.data.result);
  });

  // ── Parent throttle notices + liveness heartbeats (#140) ─────
  window.addEventListener('message', function(e) {
    if (!e.data) return;
    if (e.data.type === 'agentdb:bridgeNotice' && e.data.message) {
      // The parent forwarder throttled / deduped / retried one of this
      // app's queries. console.warn is monkey-patched above, so the
      // notice lands in the captured buffer and is visible through
      // agentdb_app_console_logs for storm diagnosis.
      console.warn(String(e.data.message));
      return;
    }
    if (e.data.type === 'agentdb:progress' && e.data.ids && e.data.ids.length) {
      // The parent is alive and still working on these requests (queued
      // behind the concurrency cap, executing, or in retry backoff) —
      // re-arm their timers so queue wait never reads as a dead bridge.
      for (var i = 0; i < e.data.ids.length; i++) {
        var p = _pending[e.data.ids[i]];
        if (p && p.rearm) p.rearm();
      }
    }
  });

  function request(method, params) {
    return new Promise(function(resolve, reject) {
      var id = ++_reqId;
      function onTimeout() {
        delete _pending[id];
        reject(new Error('Bridge request timeout: ' + method));
      }
      var entry = {
        timer: setTimeout(onTimeout, REQUEST_TIMEOUT_MS),
        resolve: function(v) { clearTimeout(entry.timer); resolve(v); },
        reject: function(e) { clearTimeout(entry.timer); reject(e); },
        // Re-armed by agentdb:progress heartbeats: the timeout measures
        // parent SILENCE (dead viewer, unmounted pane), not total latency
        // of a queued/retrying request.
        rearm: function() {
          clearTimeout(entry.timer);
          entry.timer = setTimeout(onTimeout, REARM_GRACE_MS);
        }
      };
      _pending[id] = entry;
      window.parent.postMessage({
        type: 'agentdb:request', id: id, method: method, params: params
      }, '*');
    });
  }

  function toObjects(result) {
    if (result && result.columns && result.rows) {
      var cols = result.columns;
      result.rows = result.rows.map(function(row) {
        var obj = {};
        for (var i = 0; i < cols.length; i++) obj[cols[i]] = row[i];
        return obj;
      });
    }
    return result;
  }

  window.agentdb = {
    query: function(sql) {
      // Raw arbitrary-SQL execution is disabled (issue #34525). Register a
      // named query via agentdb_upsert_app_query and call executeQuery instead.
      // The parent frame also rejects this RPC, so a crafted postMessage that
      // bypasses this shim still cannot run raw SQL.
      // Notify the parent viewer so it can overlay a "regenerate this legacy
      // dashboard" card instead of leaving the app's own raw error on screen.
      // (Legacy dashboards predate the disable and call query() directly; the
      // shim rejects locally so this is the only signal the parent gets.)
      try { window.parent.postMessage({ type: 'agentdb:legacyRawSql' }, '*'); } catch (e) {}
      return Promise.reject(new Error(
        'agentdb.query(rawSql) is disabled. Register a named query with ' +
        'agentdb_upsert_app_query and call agentdb.executeQuery(name, params) instead.'
      ));
    },
    executeQuery: function(name, params) {
      return request('executeQuery', { name: name, params: params || {} }).then(toObjects);
    },
    // Call a platform service the owner registered on this dashboard, e.g. a
    // Team Brain: callService('faq', { question: q }) resolves to
    // { answer, citations, no_access, write }. The platform calls it as the
    // owner; options.writeQuery (a query with a 'service_result' param) saves
    // the result server-side with options.params.
    callService: function(name, input, options) {
      options = options || {};
      return request('callService', {
        service: name, input: input || {},
        writeQuery: options.writeQuery || '', params: options.params || {}
      }).then(function(r) {
        if (r && r.write) r.write = toObjects(r.write);
        return r;
      });
    },
    getSchema: function() { return request('getSchema', {}); },
    getAppInfo: function() { return request('getAppInfo', {}); },
    // Open the viewer's own GenTeam agent beside the dashboard with a
    // question prefilled (never sent): openAgent({ question, context })
    // resolves to { opened }. Pass keys and filters in context, not row data —
    // the agent reads the rows itself with the viewer's access.
    openAgent: function(options) {
      options = options || {};
      return request('openAgent', {
        question: options.question || '', context: options.context || null
      });
    }
  };

  // Notify parent that Bridge SDK is loaded and ready for commands.
  // queryMeta lets the forwarder classify reads vs mutations up front.
  window.parent.postMessage(
    { type: 'agentdb:bridgeReady', queryMeta: _queryMeta }, '*'
  );
})();
