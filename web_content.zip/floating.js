const agent=new URLSearchParams(location.search).get("agent")||"D.C. AI";$("title").textContent=agent+" · Live";
function $(id){return document.getElementById(id)}
let ws=new WebSocket("ws://127.0.0.1:5000/ws");ws.onmessage=e=>$("reply").textContent=JSON.parse(e.data).message||"";
$("send").onclick=()=>{if(ws.readyState===1)ws.send(JSON.stringify({agent,message:$("msg").value}))};$("close").onclick=()=>document.querySelector(".float").remove();
let box=document.querySelector(".float"),bar=$("drag"),drag=false,sx=0,sy=0,left=20,top=30;
bar.onpointerdown=e=>{drag=true;sx=e.clientX;sy=e.clientY;bar.setPointerCapture(e.pointerId)};
bar.onpointermove=e=>{if(drag){box.style.left=(left+e.clientX-sx)+"px";box.style.top=(top+e.clientY-sy)+"px"}};
bar.onpointerup=()=>{drag=false;let r=box.getBoundingClientRect();left=r.left;top=r.top};
