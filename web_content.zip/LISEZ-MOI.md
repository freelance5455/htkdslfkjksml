# CMC Moyennes – projet Android

Identifiant de l'application : `com.greg.ed.cmc`  
Nom affiché sur le téléphone : CMC Moyennes  
Android 7.0 ou plus récent. Aucune permission demandée, aucune connexion internet nécessaire.

## Obtenir l'APK sans rien installer (GitHub)

1. Créez un compte gratuit sur github.com, puis un nouveau dépôt **privé** (bouton « New »).
2. Dans le dépôt, « Add file » puis « Upload files » : glissez-y **tout le contenu** de ce dossier,
   y compris le dossier caché `.github` et le fichier `greg-cmc.jks`.
   Si `.github` n'est pas accepté, créez-le à la main : « Add file » → « Create new file »,
   tapez le nom `.github/workflows/build-apk.yml` et collez-y le contenu du fichier du même nom.
3. Onglet **Actions** → « Construire l'APK » → **Run workflow**. Attendez 4 à 6 minutes.
4. Ouvrez l'exécution terminée, section **Artifacts** : téléchargez `CMC-Moyennes-apk`.
   Décompressez-le : vous obtenez `CMC-Moyennes.apk`.

## Ou avec Android Studio (ordinateur)

Ouvrez ce dossier avec Android Studio, laissez la synchronisation Gradle se terminer, puis
**Build → Generate Signed App Bundle / APK → APK**, en choisissant la clé `greg-cmc.jks`
(alias `cmc`, mot de passe visible dans `app/build.gradle`).
Ou en ligne de commande : `gradle assembleRelease`.

## Installer l'APK sur le téléphone

Copiez `CMC-Moyennes.apk` sur le téléphone, ouvrez-le, et autorisez « Installer des applications
inconnues » pour l'application utilisée (Fichiers, Chrome…) quand Android le demande.

## À conserver absolument

- **`greg-cmc.jks`** est la clé de signature. Faites-en une copie en lieu sûr. Toutes les mises à jour
  doivent être signées avec la même clé, sinon il faudra désinstaller l'application, ce qui efface les notes.
- Gardez le dépôt GitHub **privé** : la clé et son mot de passe s'y trouvent.
- Dans l'application : Réglages → **Sauvegarder** crée un fichier de sauvegarde de toutes vos notes.

## Modifier l'application

Tout le contenu de l'application est dans `app/src/main/assets/www/index.html`.
Pour sortir une mise à jour, augmentez `versionCode` et `versionName` dans `app/build.gradle`.

## Si la compilation échoue

Dans l'onglet **Actions**, ouvrez l'exécution en échec : le résumé affiche les erreurs, et la section
**Artifacts** contient `journal-de-compilation` (fichier `build-log.txt`) à envoyer pour diagnostic.
