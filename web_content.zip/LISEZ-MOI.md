# NATINF Route – aide à la qualification des infractions routières

Application web installable (PWA) : s'utilise sur Android comme une application, **y compris sans réseau**.
Données : nomenclature NATINF officielle, édition octobre 2026 (17 239 infractions) + glossaire des codes.
Source : Ministère de la Justice, data.gouv.fr, Licence Ouverte 2.0.

## Installer sur Android
1. Mettre le dossier `app/` sur un hébergement HTTPS (GitHub Pages, Netlify, serveur interne…).
   Une PWA exige HTTPS (ou localhost) ; `data.json` pèse ~4,6 Mo (≈1 Mo compressé).
2. Ouvrir l'adresse dans Chrome sur le téléphone, attendre le chargement complet.
3. Menu ⋮ → « Installer l'application » (ou « Ajouter à l'écran d'accueil »).
4. Ensuite l'application fonctionne hors ligne.

Sans hébergement : ouvrir `NATINF-Route-fichier-unique.html` dans Chrome (tout est dedans, sans installation ni mode hors-ligne garanti).

## Mettre à jour les données (NATINF publié chaque trimestre)
1. Télécharger le nouveau CSV sur data.gouv.fr (« Liste des infractions en vigueur de la nomenclature NATINF »).
2. Le convertir en UTF-8 avec 5 colonnes dans `outils/data/natinf.csv` (colonnes : natinf, nature, libelle, definie, reprimee ; en-tête sur la 1re ligne).
3. `python3 outils/build/make_data.py` (nécessite pandas) → régénère `outils/web/data.json`; le copier dans `app/`.
4. Incrémenter `CACHE` dans `app/sw.js` (ex. `natinf-route-v2`) pour que les téléphones rechargent.

## Ce qui vient du fichier officiel / ce qui est ajouté
- Officiel : numéro, nature, libellé, articles « définie par » et « réprimée par ».
- Ajouté (marqué « Indicatif – à valider » dans l'appli) : points, rétention, suspension, dépistage, confiscation,
  immobilisation, peines des principaux délits, listes « à vérifier », scénarios de situation.
  Ces éléments sont dans `outils/build/rules.py` et `scenarios.py` : **à faire relire et valider par un juriste / référent
  avant tout usage opérationnel**, puis à corriger directement dans ces deux fichiers.

Outil non officiel, sans valeur juridique : toujours vérifier les textes en vigueur (Légifrance).
