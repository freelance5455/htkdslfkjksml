# MORIS BAZ — version Android native (comptage de pas en arrière-plan)

## Pourquoi
Une page web (htmltoapk) est mise en pause par Android quand l'écran est éteint.
Le téléphone possède pourtant un **compteur de pas matériel** qui compte en permanence,
même application fermée. Cette version native lit ce compteur ; `index.html` calcule
les pas faits depuis la dernière ouverture et les ajoute à Moris Steps.

## Étapes (Android Studio, sur ordinateur)
1. Publiez le nouveau `index.html` sur votre site (Netlify).
2. Android Studio → New Project → **Empty Views Activity** (Kotlin)
   - Name : MORIS BAZ — Package : `com.morisbaz.app` — Minimum SDK : API 24
3. Remplacez le contenu de `MainActivity.kt` par le fichier fourni
   (chemin : app/src/main/java/com/morisbaz/app/).
4. Remplacez `app/src/main/AndroidManifest.xml` par le fichier fourni.
5. Dans `MainActivity.kt`, changez `APP_URL` par l'adresse de votre site.
6. Build → Generate Signed Bundle / APK → APK. Installez-le sur un téléphone.

## Test
Ouvrez Menu → Moris Steps : le message vert « Comptage automatique en arrière-plan »
doit apparaître. Autorisez « Activité physique » à la demande. Fermez l'application,
marchez, rouvrez : le compteur a augmenté.

## ⚠️ À savoir avant de remplacer l'ancienne application
- Le nom de package est différent : c'est **une nouvelle application**. L'identité d'un client
  (et donc ses coins) est stockée dans le téléphone : un client qui change d'application
  repart d'un compte vide. Les vendeurs se reconnectent avec Juice + code.
- Pas de notifications web dans cette version simple (« Activer les notifications » ne marchera pas).
- Ce code n'a pas été compilé ni testé par moi : faites un essai sur un ou deux téléphones d'abord.
