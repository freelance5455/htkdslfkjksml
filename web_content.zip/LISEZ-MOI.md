# Inventaire Biomédicale — application Android

Application hors-ligne pour gérer le parc d'appareils biomédicaux de plusieurs hôpitaux :
inventaire, fiches appareils, échéances de maintenance / calibration, journal des pannes,
tableau de bord, notifications de rappel, import/export Excel.

Toutes les données restent **sur le téléphone** (aucun serveur, aucun compte).

## Ce que contient l'application

| Écran | Contenu |
|---|---|
| Tableau de bord | Indicateurs clés, « À traiter en priorité », répartition par hôpital et par statut |
| Inventaire | Recherche, filtres, tri, scan de code-barres/QR (si la caméra le permet), fiche appareil complète, boutons « Maintenance effectuée », « Calibration effectuée », « Déclarer une panne » |
| Maintenance | Journal des interventions (préventive, corrective, calibration…) lié aux appareils |
| Paramètres | Thème (auto/clair/sombre), couleur, taille du texte, langue (FR/EN), notifications, hôpitaux / services / types, champs personnalisés, seuils d'alerte, devise, format de date, import/export Excel, sauvegarde JSON, code PIN, mises à jour |

Les règles de calcul sont celles de votre classeur Excel (prochaine échéance = dernière date + fréquence en mois ;
« à planifier » = dans les 30 jours ; fin de vie = année de fabrication + durée de vie).
Le fichier Excel exporté reprend les mêmes colonnes que votre classeur : vous pouvez l'**importer** dans l'application
(les lignes « EXEMPLE » sont ignorées).

---

## 1. Obtenir l'APK (sans installer aucun outil) — GitHub

L'APK se construit automatiquement sur les serveurs gratuits de GitHub.

1. Créez un compte gratuit sur https://github.com.
2. Cliquez sur **New repository**, nommez-le (ex. `inventaire-biomedicale`), choisissez **Private**, puis **Create repository**.
3. Dans le dépôt, cliquez **uploading an existing file** et glissez **tout le contenu du dossier du projet** (décompressé),
   y compris le dossier caché `.github`. Cliquez **Commit changes**.
   - Astuce : si le dossier `.github` n'apparaît pas dans votre explorateur, activez « Afficher les éléments cachés ».
   - Ne pas importer le dossier `node_modules` s'il existe.
4. Onglet **Actions** → « Construire l'APK » → attendez ~5 à 8 minutes (coche verte).
   Si rien ne démarre : Actions → **Construire l'APK** → **Run workflow**.
5. Récupérez l'APK :
   - onglet **Releases** (colonne de droite) → `Inventaire-Biomedicale.apk` : lien direct, téléchargeable depuis le téléphone ;
   - ou dans l'exécution → **Artifacts** → `Inventaire-Biomedicale-APK`.

## 2. Installer sur le téléphone

1. Ouvrez le fichier `.apk` téléchargé.
2. Android demande d'autoriser l'installation depuis cette source (navigateur / gestionnaire de fichiers) : autorisez.
3. Installez. L'icône verte « Inventaire Biomédicale » apparaît.
4. Au premier lancement : choisissez la langue, saisissez vos hôpitaux, puis activez les notifications dans
   Paramètres → Notifications (Android demande l'autorisation).

## 3. Mettre à jour l'application (à tout moment)

1. Modifiez les fichiers du projet (voir §4) — ou remplacez-les par la nouvelle version reçue.
2. Remettez-les dans le dépôt GitHub (Add file → Upload files → Commit).
3. GitHub reconstruit un nouvel APK automatiquement. Téléchargez-le et **installez-le par-dessus l'ancien** :
   **vos données sont conservées** (le numéro de version augmente tout seul à chaque construction).
4. Astuce : dans Paramètres → Mises à jour, collez l'adresse de la page « Releases » de votre dépôt
   (ex. `https://github.com/VOTRE-COMPTE/inventaire-biomedicale/releases/latest`) ; le bouton
   « Rechercher une mise à jour » l'ouvrira.

> **Important — clé de signature.** `android/release-keystore.jks` signe l'application. Gardez ce fichier (sauvegarde) :
> si la clé change, Android refusera d'installer la mise à jour par-dessus l'ancienne version (il faudrait désinstaller,
> donc **faire d'abord une sauvegarde JSON**). Le mot de passe est dans `android/app/build.gradle`. Pour une publication
> sur le Play Store, créez votre propre clé secrète à la place.

## 4. Modifier l'application

Tout est du HTML / CSS / JavaScript simple dans le dossier `www/` — aucun outil de compilation web.

| Je veux… | Fichier |
|---|---|
| Changer les couleurs, tailles, espacements | `www/css/app.css` (variables en haut) |
| Modifier un texte / une traduction | `www/js/lang-fr.js`, `www/js/lang-en.js` |
| Ajouter une langue | copier `lang-en.js` en `lang-xx.js`, traduire, l'enregistrer dans `www/js/app.js` (`registerLang`) et `LANGS` dans `www/js/i18n.js` |
| Ajouter / retirer un champ de la fiche appareil | `www/js/schema.js` (`FIELDS`) + libellés `f.<clé>` dans les fichiers de langue |
| Ajouter un champ **sans coder** | dans l'application : Paramètres → Champs personnalisés |
| Changer une règle de calcul (échéances, fin de vie, indicateurs) | `www/js/logic.js` |
| Modifier le tableau de bord | `www/js/view-dashboard.js` |
| Modifier les listes de choix (statuts, types d'intervention…) | `www/js/schema.js` (`CODES`) + libellés `c.<liste>.<code>` |
| Modifier les notifications | `www/js/notify.js` |
| Changer l'icône | `resources/icon-foreground.svg` / `icon.svg`, puis `node resources/render.js` (nécessite Playwright) ou remplacer les PNG dans `android/app/src/main/res/mipmap-*` |
| Changer le nom affiché | `android/app/src/main/res/values/strings.xml` et `capacitor.config.json` |
| Changer le numéro de version affiché | `version.properties` (`VERSION_NAME`) |

Pour tester une modification **sans téléphone** : dans le dossier `www`, lancez `python3 -m http.server 8000`
puis ouvrez http://localhost:8000 dans Chrome (la version navigateur fonctionne aussi hors-ligne et s'installe
sur l'écran d'accueil de Chrome Android si vous la publiez sur un hébergement HTTPS).
Dans ce cas, si vous modifiez des fichiers, changez le nom du cache dans `www/sw.js` (`CACHE`).

## 5. Construire l'APK sur votre ordinateur (alternative)

Prérequis : Node.js 22, JDK 21, Android SDK (ou Android Studio).

```bash
npm ci
npx cap sync android
cd android
./gradlew assembleRelease        # Windows : gradlew.bat assembleRelease
# APK : android/app/build/outputs/apk/release/app-release.apk
```
Ou ouvrez le dossier `android/` dans Android Studio (`npx cap open android`). Augmentez `VERSION_CODE` dans
`version.properties` à chaque nouvelle version installée par-dessus la précédente.

## 6. Sauvegarde et sécurité des données

- Données stockées localement (base IndexedDB de l'application). Désinstaller l'application **efface** les données :
  faites régulièrement **Paramètres → Sauvegarde complète (JSON)** ou **Exporter vers Excel** (un rappel s'affiche
  si la dernière sauvegarde a plus de 30 jours). Le fichier est proposé via le menu de partage Android
  (Drive, e-mail, WhatsApp, stockage…).
- Code PIN optionnel (Paramètres → Sécurité). Il verrouille l'écran de l'application ; il ne chiffre pas le stockage.
  Ne mettez pas de données patient dans l'application.

## 7. Limites connues

- Le projet Android n'a **pas pu être compilé ni testé sur un téléphone** dans l'environnement où il a été créé
  (accès aux dépôts Android bloqué). L'application web a été testée dans un navigateur (parcours complet, import/export
  Excel, sauvegarde/restauration, PIN, thèmes, langues). Les fonctions propres à Android (notifications programmées,
  partage de fichiers, scan caméra, bouton retour) sont écrites selon la documentation Capacitor mais à valider sur
  votre appareil : si un problème apparaît, notez-le et il sera corrigé dans la version suivante.
- Notifications : programmées à chaque ouverture/modification (jusqu'à 12 mois). Certains constructeurs
  (Xiaomi, Huawei, Samsung…) limitent les alarmes en arrière-plan : désactivez l'optimisation de batterie pour l'application.
- Le scan de code-barres dépend du support de la caméra par le système (sinon saisie manuelle).
- Application non publiée sur le Play Store (installation directe de l'APK).
