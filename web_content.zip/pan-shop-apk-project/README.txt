पान दुकान हिसाब - Android-ready UI project

यह standalone mobile web app है और localStorage में ग्राहक/हिसाब रखता है।
इस environment में Android SDK/Gradle उपलब्ध नहीं है, इसलिए यहां सीधे signed APK compile नहीं हो सका।
index.html को WebView/Android wrapper में पैक करके APK बनाया जा सकता है।
