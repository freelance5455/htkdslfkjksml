# Kumar Bakery Android App v1

This is an Android Studio project wrapping the current Kumar Bakery Manager web app.

Features currently included:
- Dashboard
- Billing
- Products and stock
- Paid / Udhar
- Customer-wise udhar history
- Partial payments
- Invoice print/share
- WhatsApp statement opening
- Local browser storage

Build:
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build > Build APK(s).

Application ID: com.kumarbakery.manager
