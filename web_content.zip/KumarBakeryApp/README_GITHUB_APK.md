# Kumar Bakery — One-click APK build

1. Create a GitHub repository.
2. Upload this entire project folder to it.
3. Open the repository's **Actions** tab.
4. Select **Build Kumar Bakery APK**.
5. Press **Run workflow**.
6. When it finishes, open the workflow run and download the **Kumar-Bakery-debug-APK** artifact.
7. Extract the ZIP and install `app-debug.apk` on Android.

The workflow uses GitHub-hosted runners, JDK 17, Android SDK 35, and Gradle 9.6.
