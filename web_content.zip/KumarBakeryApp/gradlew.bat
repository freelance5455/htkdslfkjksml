@echo off
echo Use GitHub Actions workflow: .github\workflows\build-apk.yml
exit /b 1
