APK বানানোর ধাপ (একবারই করতে হবে)

আগে ইনস্টল করুন: Node.js (nodejs.org) এবং Android Studio (developer.android.com/studio)

1. এই ফোল্ডারে টার্মিনাল খুলুন
2. npm install
3. npm run android      (Android Studio খুলবে)
4. Android Studio-তে: Build > Build Bundle(s) / APK(s) > Build APK(s)
5. তৈরি APK: android/app/build/outputs/apk/debug/app-debug.apk
   এই ফাইলটি যে কাউকে পাঠালে ফোনে ইনস্টল করা যাবে।

Play Store-এর জন্য: Build > Generate Signed Bundle / APK
