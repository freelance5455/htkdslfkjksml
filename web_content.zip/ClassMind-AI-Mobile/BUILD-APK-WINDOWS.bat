@echo off
chcp 65001 >nul
echo ============================================
echo ClassMind AI - Android project preparation
echo ============================================
where node >nul 2>nul || (echo ERROR: Install Node.js LTS first.& pause & exit /b 1)
call npm install
if errorlevel 1 (echo npm install failed. Check internet and try again.& pause & exit /b 1)
call npm run build
if errorlevel 1 (echo Build failed.& pause & exit /b 1)
if not exist android call npx cap add android
if errorlevel 1 (echo Android platform setup failed.& pause & exit /b 1)
call npx cap sync android
if errorlevel 1 (echo Capacitor sync failed.& pause & exit /b 1)
echo Done. Open Android Studio with: npx cap open android
echo Then build APK from Build menu.
pause
