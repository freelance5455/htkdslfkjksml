HƯỚNG DẪN TẠO APK DEVBUG BY ROMINO

1. Triển khai backend FastAPI và frontend lên hosting có HTTPS.
2. Sửa app/src/main/res/values/strings.xml: thay URL mẫu bằng URL frontend HTTPS thật.
3. Cấu hình backend:
   DEVBUG_ENV=production
   DEVBUG_SESSION_SECRET=<chuỗi ngẫu nhiên >= 32 ký tự>
   DEVBUG_COOKIE_SECURE=true
   DEVBUG_FRONTEND_ORIGINS=<origin HTTPS chính xác>
   DEVBUG_ADMIN_ACTIVATION_KEY=Romino@#*_210
4. Mở thư mục android/ bằng Android Studio.
5. Chờ Gradle Sync, chọn Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK debug ở app/build/outputs/apk/debug/.

Đây là dự án Android Studio, chưa phải APK đã biên dịch.
Không nhúng KEY Admin, session secret hoặc mật khẩu vào APK.
