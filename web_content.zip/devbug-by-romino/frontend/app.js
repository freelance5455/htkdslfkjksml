const API = (window.DEVBUG_API_BASE || "").replace(/\/$/, "");
const $ = id => document.getElementById(id);
let csrf = "";

async function api(path, options = {}) {
  if (!API || API.includes("YOUR-BACKEND-DOMAIN")) throw new Error("Chưa cấu hình địa chỉ backend HTTPS trong config.js.");
  const method = (options.method || "GET").toUpperCase();
  const headers = new Headers(options.headers || {});
  if (csrf && !["GET", "HEAD", "OPTIONS"].includes(method)) headers.set("X-CSRF-Token", csrf);
  const response = await fetch(API + path, { ...options, method, headers, credentials: "include" });
  const data = await response.json().catch(() => ({ detail: "Phản hồi máy chủ không hợp lệ." }));
  if (!response.ok) throw new Error(data.detail || `Lỗi máy chủ (${response.status}).`);
  return data;
}
function showResult(id, html) { $(id).classList.remove("hidden"); $(id).innerHTML = html; }
function esc(s) { return String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }
function showPage(name) {
  document.querySelectorAll(".page").forEach(p => p.classList.add("hidden"));
  $("page-" + name).classList.remove("hidden");
  document.querySelectorAll(".nav").forEach(n => n.classList.toggle("active", n.dataset.page === name));
  const titles = {home:"Tổng quan",website:"Kiểm tra Website",dns:"Tra cứu DNS",code:"Phân tích mã nguồn",hash:"SHA-256 File",admin:"Quản trị"};
  $("pageTitle").textContent = titles[name] || "devbug";
}
function enter(data) {
  csrf = data.csrf || "";
  $("loginView").classList.add("hidden"); $("appView").classList.remove("hidden");
  $("userLabel").textContent = data.username + (data.role === "admin" ? " · Admin" : "");
  $("welcomeUser").textContent = data.username;
  document.querySelectorAll(".admin-only").forEach(x => x.classList.toggle("hidden", data.role !== "admin"));
  $("claimKeyPanel").classList.toggle("hidden", data.role === "admin");
  showPage("home");
}
async function checkSession() { try { enter(await api("/api/me")); } catch {} }

$("loginForm").addEventListener("submit", async e => {
  e.preventDefault(); $("loginMsg").textContent = "Đang xác thực…";
  try {
    const data = await api("/api/login", {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({username:$("username").value.trim(), password:$("password").value})});
    enter(data);
  } catch (err) { $("loginMsg").textContent = err.message; $("password").value = ""; }
});

$("showRegister").addEventListener("click", () => {
  $("loginForm").classList.add("hidden");
  $("loginSwitch").classList.add("hidden");
  $("registerForm").classList.remove("hidden");
});
$("hideRegister").addEventListener("click", () => {
  $("registerForm").classList.add("hidden");
  $("loginForm").classList.remove("hidden");
  $("loginSwitch").classList.remove("hidden");
});
$("registerForm").addEventListener("submit", async e => {
  e.preventDefault(); $("registerMsg").textContent = "Đang tạo tài khoản…";
  try {
    await api("/api/register", {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({username:$("regUsername").value.trim(), password:$("regPassword").value})});
    $("registerMsg").textContent = "Tạo tài khoản thành công. Hãy đăng nhập.";
    $("username").value = $("regUsername").value.trim();
    $("password").value = "";
    $("registerForm").classList.add("hidden");
    $("loginForm").classList.remove("hidden");
    $("loginSwitch").classList.remove("hidden");
  } catch (err) { $("registerMsg").textContent = err.message; }
});
$("claimKeyForm").addEventListener("submit", async e => {
  e.preventDefault(); $("keyMsg").textContent = "Đang xác minh KEY…";
  try {
    const d = await api("/api/admin/claim-key", {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({key:$("adminKey").value})});
    $("keyMsg").textContent = d.message;
    $("adminKey").value = "";
    setTimeout(() => location.reload(), 1200);
  } catch (err) { $("keyMsg").textContent = err.message; $("adminKey").value = ""; }
});
$("logoutBtn").addEventListener("click", async () => { try { await api("/api/logout", {method:"POST"}); } catch (e) { alert(e.message); } finally { location.reload(); } });
document.querySelectorAll("[data-page]").forEach(b => b.addEventListener("click", () => showPage(b.dataset.page)));
document.querySelectorAll("[data-go]").forEach(b => b.addEventListener("click", () => showPage(b.dataset.go)));

$("websiteForm").addEventListener("submit", async e => {
  e.preventDefault(); showResult("websiteResult", "Đang kiểm tra…");
  try {
    const d = await api("/api/tools/website-check", {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({url:$("websiteUrl").value.trim()})});
    const labels = {"content-security-policy":"Content-Security-Policy","strict-transport-security":"Strict-Transport-Security","x-content-type-options":"X-Content-Type-Options","x-frame-options":"X-Frame-Options","referrer-policy":"Referrer-Policy","permissions-policy":"Permissions-Policy"};
    const headers = Object.entries(d.headers || {}).map(([k,v]) => `<li><b>${esc(labels[k] || k)}</b>: ${v ? esc(v) : '<span class="bad">Chưa có</span>'}</li>`).join("");
    const findings = (d.findings || []).map(x => `<li>${esc(x)}</li>`).join("") || '<li class="good">Không thấy thiếu sót trong các mục cơ bản.</li>';
    showResult("websiteResult", `<h3>Kết quả kiểm tra</h3><p>Host: <b>${esc(d.host)}</b></p><p>IP: ${esc((d.ips || []).join(", "))}</p><p>HTTPS: ${d.https ? '<span class="good">Có</span>' : '<span class="bad">Không</span>'}</p><p>TLS: ${d.tls?.valid ? '<span class="good">Hợp lệ</span>' : '<span class="bad">Chưa xác minh</span>'}</p><h4>HTTP security headers</h4><ul>${headers}</ul><h4>Khuyến nghị</h4><ul>${findings}</ul><small class="muted">Đánh giá sơ bộ, không phải chứng nhận an toàn.</small>`);
  } catch (err) { showResult("websiteResult", `<span class="bad">${esc(err.message)}</span>`); }
});
$("dnsForm").addEventListener("submit", async e => {
  e.preventDefault(); showResult("dnsResult", "Đang tra cứu…");
  try { const d = await api("/api/tools/dns?domain=" + encodeURIComponent($("domain").value.trim())); showResult("dnsResult", `<h3>${esc(d.domain)}</h3><ul>${(d.ips || []).map(ip => `<li>${esc(ip)}</li>`).join("") || "<li>Không tìm thấy bản ghi địa chỉ.</li>"}</ul>`); }
  catch (err) { showResult("dnsResult", `<span class="bad">${esc(err.message)}</span>`); }
});
async function upload(formId, fileId, path, resultId) {
  $(formId).addEventListener("submit", async e => {
    e.preventDefault(); const f = $(fileId).files[0]; if (!f) return;
    if (f.size > 2 * 1024 * 1024) { showResult(resultId, '<span class="bad">File vượt quá 2 MB.</span>'); return; }
    const fd = new FormData(); fd.append("file", f); showResult(resultId, "Đang phân tích…");
    try {
      const d = await api(path, {method:"POST", body:fd});
      const extra = d.findings ? `<h4>Dấu hiệu cần rà soát</h4><ul>${d.findings.map(x => `<li>${esc(x)}</li>`).join("") || '<li class="good">Không khớp mẫu cảnh báo cơ bản.</li>'}</ul>` : "";
      showResult(resultId, `<h3>${esc(d.filename)}</h3><p>Kích thước: ${d.size} bytes</p><p>SHA-256: <code>${esc(d.sha256)}</code></p>${extra}<p class="muted">${esc(d.note || "")}</p>`);
    } catch (err) { showResult(resultId, `<span class="bad">${esc(err.message)}</span>`); }
  });
}
upload("codeForm", "codeFile", "/api/tools/code-check", "codeResult");
upload("hashForm", "hashFile", "/api/tools/hash", "hashResult");

$("refreshLocked").addEventListener("click", async () => {
  try {
    const d = await api("/api/admin/locked-users");
    $("lockedList").innerHTML = d.users.length ? d.users.map(u => `<div class="admin-item"><span><b>${esc(u.username)}</b><br><small>${u.failed_attempts} lần sai</small></span><button class="ghost" data-unlock="${esc(u.username)}">Mở khóa</button></div>`).join("") : "Không có tài khoản bị khóa.";
    document.querySelectorAll("[data-unlock]").forEach(b => b.addEventListener("click", async () => { try { await api("/api/admin/unlock/" + encodeURIComponent(b.dataset.unlock), {method:"POST"}); $("refreshLocked").click(); } catch (err) { alert(err.message); } }));
  } catch (err) { $("lockedList").textContent = err.message; }
});
$("refreshAudit").addEventListener("click", async () => {
  try { const d = await api("/api/admin/audit"); $("auditList").innerHTML = d.events.map(x => `<div class="admin-item"><span><b>${esc(x.username)}</b> · ${esc(x.event)}<br><small>${esc(x.ip)} · ${esc(x.created_at)}</small></span></div>`).join("") || "Chưa có nhật ký."; }
  catch (err) { $("auditList").textContent = err.message; }
});
checkSession();
