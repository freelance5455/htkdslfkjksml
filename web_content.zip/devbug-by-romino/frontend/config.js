// Thay bằng URL backend HTTPS của bạn.
window.DEVBUG_API_BASE = "https://YOUR-BACKEND-DOMAIN";
