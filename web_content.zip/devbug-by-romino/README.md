# devbug By RoMiNo

Bộ công cụ bảo mật theo hướng phòng thủ, giao diện tiếng Việt, ưu tiên dùng tốt trên điện thoại. Mã nguồn chia thành frontend tĩnh và backend API riêng:

- `frontend/`: HTML/CSS/JavaScript thuần, có thể đưa lên GitHub Pages.
- `backend/`: FastAPI, SQLite, Argon2id và session cookie ký số.
- `TEST_REPORT.md`: các kiểm tra đã chạy trên bản mã nguồn này.

## Chức năng hiện có

1. Đăng nhập bằng username/password.
2. Khóa tài khoản sau 10 lần nhập sai liên tiếp; Admin có thể mở khóa.
3. Giới hạn số lần gửi yêu cầu đăng nhập theo IP trong một tiến trình.
4. Nhật ký đăng nhập, đăng xuất, tra cứu và thao tác công cụ; Admin xem 100 sự kiện gần nhất.
5. Kiểm tra website công khai: HTTPS, TLS và một số HTTP security headers.
6. Tra cứu DNS A/AAAA qua bộ phân giải của máy chủ.
7. Phân tích tĩnh file HTML/JS/Python/CSS/TXT, không thực thi file tải lên.
8. Tạo SHA-256 cho file.

Các giới hạn có chủ ý: không dò mật khẩu, không khai thác lỗ hổng, không quét cổng diện rộng, không gây nhiễu Wi-Fi. Chỉ kiểm tra tài sản bạn sở hữu hoặc được cho phép kiểm thử. Kết quả là đánh giá cơ bản, không phải chứng nhận website an toàn.

## 1. Cấu hình backend

Yêu cầu Python 3.11+. Tạo môi trường ảo và cài thư viện:

```bash
cd backend
python -m venv .venv
# Linux/macOS
source .venv/bin/activate
# Windows PowerShell
# .venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

Tạo secret ngẫu nhiên dài tối thiểu 32 ký tự và đặt các biến môi trường. Không đưa secret, mật khẩu hoặc file database lên GitHub.

Ví dụ Linux/macOS:

```bash
export DEVBUG_ENV=production
export DEVBUG_SESSION_SECRET="CHUOI_NGAU_NHIEN_DAI_TU_48_KY_TU"
export DEVBUG_ADMIN_USERNAME="romino"
export DEVBUG_ADMIN_PASSWORD="MAT_KHAU_MOI_RIENG_DAI_IT_NHAT_12_KY_TU"
export DEVBUG_ADMIN_ACTIVATION_KEY="Romino@#*_210"
export DEVBUG_FRONTEND_ORIGINS="https://TEN-USER.github.io"
export DEVBUG_COOKIE_SECURE=true
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

Windows PowerShell:

```powershell
$env:DEVBUG_ENV = "production"
$env:DEVBUG_SESSION_SECRET = "CHUOI_NGAU_NHIEN_DAI_TU_48_KY_TU"
$env:DEVBUG_ADMIN_USERNAME = "romino"
$env:DEVBUG_ADMIN_PASSWORD = "MAT_KHAU_MOI_RIENG_DAI_IT_NHAT_12_KY_TU"
$env:DEVBUG_FRONTEND_ORIGINS = "https://TEN-USER.github.io"
$env:DEVBUG_COOKIE_SECURE = "true"
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

**Không dùng mật khẩu từng gửi trong các cuộc trò chuyện.** Hãy tự đặt một mật khẩu mới, riêng biệt và không chia sẻ cho người khác. Tài khoản Admin chỉ được tạo lần đầu khi database chưa có username đó. Đổi biến môi trường sau này không tự đổi mật khẩu đã lưu trong database.

Backend phải chạy sau reverse proxy có HTTPS (Caddy/Nginx hoặc nền tảng hosting có TLS), firewall chỉ mở cổng cần thiết. Khi `DEVBUG_ENV=production`, ứng dụng từ chối khởi động nếu secret không đủ dài, cookie không bật Secure hoặc origin frontend không phải HTTPS cụ thể.

## 2. Cấu hình frontend

Mở `frontend/config.js`, thay bằng URL backend HTTPS thực tế:

```js
window.DEVBUG_API_BASE = "https://api.ten-mien-cua-ban";
```

Đưa nội dung thư mục `frontend/` lên GitHub Pages. `DEVBUG_FRONTEND_ORIGINS` ở backend phải trùng origin chính xác, ví dụ `https://TEN-USER.github.io` (không thêm đường dẫn repository).

Lưu ý: GitHub Pages và API trên một domain khác là hai site khác nhau. Phiên đăng nhập cần cookie `SameSite=None; Secure`; một số trình duyệt hoặc cài đặt quyền riêng tư có thể chặn cookie bên thứ ba. Cách triển khai ổn định hơn là dùng domain riêng cùng site hoặc reverse proxy API dưới cùng domain với frontend.

## 3. Tài khoản và khóa đăng nhập

- Tạo Admin đầu tiên qua `DEVBUG_ADMIN_USERNAME` và `DEVBUG_ADMIN_PASSWORD`.
- Người dùng có thể tự đăng ký bằng username và mật khẩu tối thiểu 10 ký tự.
- Người dùng đăng nhập có thể nhập KEY Admin. KEY được đối chiếu ở backend qua biến môi trường `DEVBUG_ADMIN_ACTIVATION_KEY`; chỉ tài khoản đầu tiên kích hoạt thành công được nâng quyền Admin. KEY không được nhúng trong frontend hoặc APK.
- Sau 10 lần nhập sai liên tiếp, tài khoản bị khóa. Admin đăng nhập và vào **Quản trị → Tài khoản bị khóa → Mở khóa**.
- Bộ đếm sai được lưu trong SQLite. Giới hạn theo IP hiện nằm trong bộ nhớ của một tiến trình; nếu chạy nhiều worker/máy chủ, hãy chuyển rate limit sang Redis hoặc giải pháp dùng chung.

## 4. Các lớp bảo vệ trong bản này

- Mật khẩu băm Argon2id; không lưu mật khẩu gốc.
- Session cookie được ký, có thời hạn 4 giờ; production yêu cầu Secure.
- CSRF token bắt buộc với các yêu cầu POST sau đăng nhập; kiểm tra Origin khi trình duyệt gửi Origin.
- CORS chỉ cho phép origin đã cấu hình, không bật wildcard cùng credentials.
- Bộ đếm khóa tài khoản cập nhật trong transaction SQLite `BEGIN IMMEDIATE` để giảm nguy cơ đua khi đăng nhập đồng thời.
- Website checker chỉ cho HTTP/HTTPS, chặn địa chỉ không công khai, kết nối tới IP đã xác thực DNS (giảm nguy cơ DNS rebinding), và không tự đi theo redirect.
- Upload giới hạn 2 MB; code analyzer chỉ nhận phần mở rộng cho phép và không thực thi file.
- Có một số security headers cơ bản cho API.

## 5. Chạy local để thử

Trong môi trường local, có thể dùng:

```bash
export DEVBUG_SESSION_SECRET="LOCAL_SECRET_CHUOI_DAI_TREN_32_KY_TU"
export DEVBUG_ADMIN_USERNAME="romino"
export DEVBUG_ADMIN_PASSWORD="MAT_KHAU_TEST_DAI_IT_NHAT_12_KY_TU"
export DEVBUG_COOKIE_SECURE=false
export DEVBUG_FRONTEND_ORIGINS="http://127.0.0.1:5500,http://localhost:5500"
cd backend
uvicorn app.main:app --host 127.0.0.1 --port 8000
```

Phục vụ thư mục `frontend/` bằng local web server ở cổng 5500. Không dùng cấu hình local làm cấu hình production.

## 6. Trước khi mở cho người dùng thật

1. Đặt backend sau HTTPS, cấu hình firewall và domain allowlist ở tầng vận hành nếu cần giới hạn đối tượng được kiểm tra.
2. Dùng database có backup, quyền file chặt; SQLite phù hợp quy mô nhỏ/đơn máy. Cân nhắc PostgreSQL khi mở rộng.
3. Dùng Redis hoặc rate limiter chia sẻ nếu chạy nhiều worker.
4. Bổ sung quy trình tạo tài khoản, đổi/reset mật khẩu và MFA nếu có nhiều người dùng.
5. Kiểm thử trên hosting thực tế, đặc biệt cookie cross-site, CORS, reverse proxy và sao lưu/khôi phục.
6. Cập nhật dependency và rà soát bảo mật định kỳ.

Bản này đã qua các kiểm tra tự động được liệt kê trong `TEST_REPORT.md`, nhưng chưa được pentest độc lập và không nên coi là sản phẩm production đã được chứng nhận.


## 7. Android APK (online)

Thư mục `android/` là dự án Android Studio dạng WebView, mở frontend đã triển khai qua HTTPS. Sửa `android/app/src/main/res/values/strings.xml` để đặt URL frontend thực tế. Backend FastAPI vẫn phải được triển khai riêng, bật HTTPS và cấu hình biến môi trường production.

Mở thư mục `android/` bằng Android Studio, chờ Gradle Sync, sau đó chọn **Build > Build Bundle(s) / APK(s) > Build APK(s)**. Dự án hỗ trợ Android 7.0+ và tương thích Android 11. WebView hỗ trợ chọn file cho công cụ phân tích mã nguồn và SHA-256.

**Bảo mật:** KEY kích hoạt Admin được cấu hình trong biến môi trường backend, không nhúng vào APK. Chỉ tài khoản đầu tiên kích hoạt thành công được nâng quyền Admin trên database.
