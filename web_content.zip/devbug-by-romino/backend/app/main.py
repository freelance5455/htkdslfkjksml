import os
import re
import secrets
import socket
import ssl
import sqlite3
import ipaddress
import http.client
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlsplit

from fastapi import FastAPI, Request as FastRequest, HTTPException, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from starlette.middleware.sessions import SessionMiddleware
from pydantic import BaseModel, Field

from .security import hash_password, verify_password, ip_rate_limited, validate_public_url, sha256_bytes, DUMMY_HASH

BASE = Path(__file__).resolve().parent.parent
DB_PATH = Path(os.getenv("DEVBUG_DB_PATH", str(BASE / "devbug.db")))
MAX_UPLOAD = 2 * 1024 * 1024
MAX_LOGIN_FAILS = 10
ALLOWED_CODE_EXTENSIONS = {".html", ".htm", ".js", ".mjs", ".py", ".txt", ".css"}


def db():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(DB_PATH, timeout=10)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys=ON")
    con.execute("PRAGMA busy_timeout=10000")
    return con


def now():
    return datetime.now(timezone.utc).isoformat()


def init_db():
    with db() as con:
        con.execute("PRAGMA journal_mode=WAL")
        con.executescript("""
        CREATE TABLE IF NOT EXISTS users(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'user' CHECK(role IN ('user','admin')),
            failed_attempts INTEGER NOT NULL DEFAULT 0,
            locked INTEGER NOT NULL DEFAULT 0 CHECK(locked IN (0,1)),
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS audit(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT,
            event TEXT NOT NULL,
            ip TEXT,
            created_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_audit_created ON audit(id DESC);
        CREATE TABLE IF NOT EXISTS admin_key_claims(
            id INTEGER PRIMARY KEY CHECK(id=1),
            username TEXT NOT NULL,
            claimed_at TEXT NOT NULL
        );
        """)
        admin_name = os.getenv("DEVBUG_ADMIN_USERNAME", "").strip()
        admin_password = os.getenv("DEVBUG_ADMIN_PASSWORD", "")
        if admin_name and admin_password:
            if not re.fullmatch(r"[A-Za-z0-9_.-]{3,64}", admin_name):
                raise RuntimeError("DEVBUG_ADMIN_USERNAME không hợp lệ.")
            if len(admin_password) < 12:
                raise RuntimeError("DEVBUG_ADMIN_PASSWORD phải có ít nhất 12 ký tự.")
            existing = con.execute("SELECT id FROM users WHERE username=?", (admin_name,)).fetchone()
            if not existing:
                con.execute(
                    "INSERT INTO users(username,password_hash,role,created_at) VALUES(?,?,?,?)",
                    (admin_name, hash_password(admin_password), "admin", now())
                )


def audit(con, username, event, ip):
    con.execute("INSERT INTO audit(username,event,ip,created_at) VALUES(?,?,?,?)",
                (username, event, ip, now()))


def client_ip(request):
    # Chỉ tin request.client; reverse proxy phải cấu hình trusted proxy riêng.
    return request.client.host if request.client else "unknown"


app = FastAPI(title="devbug By RoMiNo API", docs_url=None, redoc_url=None)
secret = os.getenv("DEVBUG_SESSION_SECRET", "")
if len(secret) < 32:
    if os.getenv("DEVBUG_ENV", "development").lower() == "production":
        raise RuntimeError("Production yêu cầu DEVBUG_SESSION_SECRET cố định, tối thiểu 32 ký tự.")
    secret = "LOCAL-ONLY-" + secrets.token_urlsafe(48)

is_production = os.getenv("DEVBUG_ENV", "development").lower() == "production"
origin_setting = os.getenv("DEVBUG_FRONTEND_ORIGINS", "http://127.0.0.1:5500,http://localhost:5500")
origins = [x.strip().rstrip("/") for x in origin_setting.split(",") if x.strip()]
cookie_secure = os.getenv("DEVBUG_COOKIE_SECURE", "false").lower() == "true"
if is_production and (not cookie_secure or not origins or any(not x.startswith("https://") for x in origins)):
    raise RuntimeError("Production yêu cầu DEVBUG_COOKIE_SECURE=true và DEVBUG_FRONTEND_ORIGINS chỉ gồm HTTPS origin cụ thể.")
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["GET", "POST"],
    allow_headers=["Content-Type", "X-CSRF-Token"],
    max_age=600,
)
app.add_middleware(
    SessionMiddleware,
    secret_key=secret,
    session_cookie="devbug_session",
    max_age=60 * 60 * 4,
    same_site="none" if cookie_secure else "lax",
    https_only=cookie_secure,
)


@app.middleware("http")
async def security_headers(request, call_next):
    response = await call_next(request)
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("X-Frame-Options", "DENY")
    response.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
    response.headers.setdefault("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
    response.headers.setdefault("Cache-Control", "no-store")
    return response


@app.on_event("startup")
def startup():
    init_db()


class LoginBody(BaseModel):
    username: str = Field(min_length=3, max_length=64, pattern=r"^[a-zA-Z0-9_.-]+$")
    password: str = Field(min_length=1, max_length=256)


class RegisterBody(BaseModel):
    username: str = Field(min_length=3, max_length=64, pattern=r"^[a-zA-Z0-9_.-]+$")
    password: str = Field(min_length=10, max_length=256)


class AdminKeyBody(BaseModel):
    key: str = Field(min_length=1, max_length=256)


def current_user(request: FastRequest):
    uid = request.session.get("uid")
    if not uid:
        raise HTTPException(401, "Bạn cần đăng nhập.")
    with db() as con:
        user = con.execute("SELECT id,username,role,locked FROM users WHERE id=?", (uid,)).fetchone()
    if not user or user["locked"]:
        request.session.clear()
        raise HTTPException(401, "Phiên đăng nhập không hợp lệ.")
    return dict(user)


def require_csrf(request: FastRequest):
    expected = request.session.get("csrf", "")
    supplied = request.headers.get("X-CSRF-Token", "")
    if not expected or not supplied or not secrets.compare_digest(expected, supplied):
        raise HTTPException(403, "Yêu cầu không hợp lệ (CSRF). Hãy tải lại trang và đăng nhập lại.")
    origin = request.headers.get("origin")
    if origin and origin.rstrip("/") not in origins:
        raise HTTPException(403, "Nguồn yêu cầu không được phép.")


def require_admin(request: FastRequest):
    user = current_user(request)
    if user["role"] != "admin":
        raise HTTPException(403, "Chỉ Admin được sử dụng chức năng này.")
    return user


@app.get("/api/health")
def health():
    return {"ok": True, "service": "devbug-api"}


@app.post("/api/register")
def register(body: RegisterBody, request: FastRequest):
    ip = client_ip(request)
    if ip_rate_limited("register:" + ip, limit=8, window=3600):
        raise HTTPException(429, "Bạn đã tạo quá nhiều yêu cầu đăng ký. Thử lại sau.")
    with db() as con:
        try:
            con.execute(
                "INSERT INTO users(username,password_hash,role,created_at) VALUES(?,?,?,?)",
                (body.username, hash_password(body.password), "user", now())
            )
            audit(con, body.username, "register_success", ip)
        except sqlite3.IntegrityError:
            raise HTTPException(409, "Tên đăng nhập đã tồn tại.")
    return {"ok": True, "message": "Tạo tài khoản thành công. Hãy đăng nhập."}


@app.post("/api/admin/claim-key")
def claim_admin_key(body: AdminKeyBody, request: FastRequest):
    user = current_user(request)
    require_csrf(request)
    configured_key = os.getenv("DEVBUG_ADMIN_ACTIVATION_KEY", "")
    if not configured_key:
        raise HTTPException(503, "Máy chủ chưa cấu hình KEY kích hoạt Admin.")
    if not secrets.compare_digest(body.key, configured_key):
        with db() as con:
            audit(con, user["username"], "admin_key_rejected", client_ip(request))
        raise HTTPException(403, "KEY không chính xác.")
    with db() as con:
        con.execute("BEGIN IMMEDIATE")
        claimed = con.execute("SELECT username FROM admin_key_claims WHERE id=1").fetchone()
        if claimed:
            raise HTTPException(409, "KEY Admin đã được sử dụng và không thể kích hoạt lần nữa.")
        con.execute("UPDATE users SET role='admin' WHERE id=?", (user["id"],))
        con.execute(
            "INSERT INTO admin_key_claims(id,username,claimed_at) VALUES(1,?,?)",
            (user["username"], now())
        )
        audit(con, user["username"], "admin_key_claimed", client_ip(request))
    return {"ok": True, "message": "Đã kích hoạt quyền Admin. Vui lòng đăng nhập lại.", "role": "admin"}


@app.post("/api/login")
def login(body: LoginBody, request: FastRequest):
    ip = client_ip(request)
    if ip_rate_limited(ip):
        raise HTTPException(429, "Quá nhiều yêu cầu từ mạng này. Vui lòng thử lại sau.")

    outcome = None
    user_data = None
    # BEGIN IMMEDIATE serializes counter updates so concurrent failures cannot bypass lockout.
    with db() as con:
        con.execute("BEGIN IMMEDIATE")
        user = con.execute("SELECT * FROM users WHERE username=?", (body.username,)).fetchone()
        encoded = user["password_hash"] if user else DUMMY_HASH
        valid = verify_password(encoded, body.password)
        if not user:
            audit(con, body.username, "login_failed_unknown_user", ip)
            outcome = (401, "Thông tin đăng nhập không đúng.")
        elif user["locked"]:
            audit(con, body.username, "login_blocked_locked", ip)
            outcome = (401, "Thông tin đăng nhập không đúng hoặc tài khoản đang bị khóa.")
        elif not valid:
            attempts = user["failed_attempts"] + 1
            locked = 1 if attempts >= MAX_LOGIN_FAILS else 0
            con.execute("UPDATE users SET failed_attempts=?, locked=? WHERE id=?", (attempts, locked, user["id"]))
            audit(con, body.username, "login_failed_locked" if locked else "login_failed", ip)
            outcome = (401, "Thông tin đăng nhập không đúng hoặc tài khoản đang bị khóa.")
        else:
            con.execute("UPDATE users SET failed_attempts=0 WHERE id=?", (user["id"],))
            audit(con, body.username, "login_success", ip)
            user_data = {"id": user["id"], "username": user["username"], "role": user["role"]}
    # The transaction has committed before returning any authentication error.
    if outcome:
        raise HTTPException(outcome[0], outcome[1])
    request.session.clear()
    request.session["uid"] = user_data["id"]
    request.session["csrf"] = secrets.token_urlsafe(32)
    return {"ok": True, "username": user_data["username"], "role": user_data["role"], "csrf": request.session["csrf"]}


@app.post("/api/logout")
def logout(request: FastRequest):
    user = current_user(request)
    require_csrf(request)
    with db() as con:
        audit(con, user["username"], "logout", client_ip(request))
    request.session.clear()
    return {"ok": True}


@app.get("/api/me")
def me(request: FastRequest):
    user = current_user(request)
    return {"ok": True, "username": user["username"], "role": user["role"], "csrf": request.session.get("csrf", "")}


@app.get("/api/admin/locked-users")
def locked_users(request: FastRequest):
    require_admin(request)
    with db() as con:
        rows = con.execute("SELECT username,failed_attempts,created_at FROM users WHERE locked=1 ORDER BY username").fetchall()
    return {"users": [dict(x) for x in rows]}


@app.post("/api/admin/unlock/{username}")
def unlock(username: str, request: FastRequest):
    admin = require_admin(request)
    require_csrf(request)
    with db() as con:
        cur = con.execute("UPDATE users SET locked=0,failed_attempts=0 WHERE username=?", (username,))
        if cur.rowcount == 0:
            raise HTTPException(404, "Không tìm thấy tài khoản.")
        audit(con, admin["username"], f"unlock:{username}", client_ip(request))
    return {"ok": True, "message": "Đã mở khóa tài khoản."}


@app.get("/api/admin/audit")
def audit_log(request: FastRequest):
    require_admin(request)
    with db() as con:
        rows = con.execute("SELECT username,event,ip,created_at FROM audit ORDER BY id DESC LIMIT 100").fetchall()
    return {"events": [dict(x) for x in rows]}


class WebsiteBody(BaseModel):
    url: str = Field(min_length=8, max_length=2048)


class PinnedHTTPConnection(http.client.HTTPConnection):
    def __init__(self, connect_ip, host, port, timeout=7):
        super().__init__(host, port=port, timeout=timeout)
        self.connect_ip = connect_ip
        self.original_host = host
        host_header = f"[{host}]" if ":" in host else host
        self.authority = host_header if port == 80 else f"{host_header}:{port}"

    def connect(self):
        self.sock = socket.create_connection((self.connect_ip, self.port), self.timeout)

    def putrequest(self, method, url, skip_host=False, skip_accept_encoding=False):
        super().putrequest(method, url, skip_host=True, skip_accept_encoding=skip_accept_encoding)
        self.putheader("Host", self.authority)


class PinnedHTTPSConnection(http.client.HTTPSConnection):
    def __init__(self, connect_ip, host, port, timeout=7, context=None):
        super().__init__(host, port=port, timeout=timeout, context=context)
        self.connect_ip = connect_ip
        self.original_host = host
        host_header = f"[{host}]" if ":" in host else host
        self.authority = host_header if port == 443 else f"{host_header}:{port}"

    def connect(self):
        raw = socket.create_connection((self.connect_ip, self.port), self.timeout)
        self.sock = self._context.wrap_socket(raw, server_hostname=self.original_host)

    def putrequest(self, method, url, skip_host=False, skip_accept_encoding=False):
        super().putrequest(method, url, skip_host=True, skip_accept_encoding=skip_accept_encoding)
        self.putheader("Host", self.authority)


def fetch_headers_pinned(parsed, host, ips):
    port = parsed.port or (443 if parsed.scheme == "https" else 80)
    path = parsed.path or "/"
    if parsed.query:
        path += "?" + parsed.query
    last_error = None
    for ip in ips[:4]:
        try:
            if parsed.scheme == "https":
                conn = PinnedHTTPSConnection(ip, host, port, context=ssl.create_default_context())
            else:
                conn = PinnedHTTPConnection(ip, host, port)
            conn.request("GET", path, headers={"User-Agent": "devbug-security-check/1.0", "Connection": "close"})
            response = conn.getresponse()
            headers = {k.lower(): v for k, v in response.getheaders()}
            response.read(0)
            conn.close()
            return {k: headers.get(k) for k in [
                "content-security-policy", "strict-transport-security", "x-content-type-options",
                "x-frame-options", "referrer-policy", "permissions-policy"]}
        except Exception as exc:
            last_error = exc
    raise RuntimeError("Không lấy được HTTP headers.") from last_error


@app.post("/api/tools/website-check")
def website_check(payload: WebsiteBody, request: FastRequest):
    user = current_user(request)
    require_csrf(request)
    try:
        parsed, host, ips = validate_public_url(payload.url)
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    result = {"target": payload.url, "host": host, "ips": ips, "https": parsed.scheme == "https",
              "headers": {}, "findings": [], "tls": None}
    if parsed.scheme == "https":
        tls_ok = False
        for ip in ips[:4]:
            try:
                ctx = ssl.create_default_context()
                raw = socket.create_connection((ip, parsed.port or 443), timeout=5)
                with ctx.wrap_socket(raw, server_hostname=host) as sock:
                    cert = sock.getpeercert()
                    result["tls"] = {"valid": True, "expires": cert.get("notAfter", "Không rõ")}
                    tls_ok = True
                    break
            except Exception:
                continue
        if not tls_ok:
            result["tls"] = {"valid": False}
            result["findings"].append("Không xác minh được chứng thư TLS.")
    else:
        result["findings"].append("Website đang dùng HTTP thay vì HTTPS.")
    try:
        result["headers"] = fetch_headers_pinned(parsed, host, ips)
    except Exception:
        result["findings"].append("Không lấy được HTTP headers; máy chủ có thể từ chối kết nối.")
    for key, label in [
        ("content-security-policy", "Thiếu Content-Security-Policy."),
        ("x-content-type-options", "Thiếu X-Content-Type-Options."),
        ("referrer-policy", "Thiếu Referrer-Policy."),
    ]:
        if not result["headers"].get(key):
            result["findings"].append(label)
    if parsed.scheme == "https" and not result["headers"].get("strict-transport-security"):
        result["findings"].append("Thiếu Strict-Transport-Security.")
    with db() as con:
        audit(con, user["username"], "website_check", client_ip(request))
    return result


SUSPICIOUS_PATTERNS = [
    (r"\beval\s*\(", "Sử dụng eval() – cần rà soát nguồn dữ liệu."),
    (r"\binnerHTML\s*=", "Gán innerHTML – kiểm tra nguy cơ XSS."),
    (r"document\.write\s*\(", "Sử dụng document.write() – cần rà soát."),
    (r"-----BEGIN (RSA |EC |OPENSSH )?PRIVATE KEY-----", "Có thể chứa private key."),
    (r"(api[_-]?key|secret|password)\s*[:=]\s*['\"][^'\"]{8,}", "Có chuỗi giống secret/password hard-code."),
    (r"\bos\.system\s*\(|\bsubprocess\.(run|Popen|call)\s*\(", "Có lệnh hệ thống – kiểm tra cách dùng."),
]


async def read_upload(file: UploadFile):
    data = await file.read(MAX_UPLOAD + 1)
    if len(data) > MAX_UPLOAD:
        raise HTTPException(413, "File vượt quá giới hạn 2 MB.")
    return data


@app.post("/api/tools/code-check")
async def code_check(request: FastRequest, file: UploadFile = File(...)):
    user = current_user(request)
    require_csrf(request)
    filename = Path(file.filename or "upload").name
    if Path(filename).suffix.lower() not in ALLOWED_CODE_EXTENSIONS:
        raise HTTPException(400, "Định dạng không hỗ trợ. Chỉ nhận HTML, JS, Python, CSS hoặc TXT.")
    data = await read_upload(file)
    try:
        source = data.decode("utf-8")
    except UnicodeDecodeError:
        raise HTTPException(400, "Chỉ hỗ trợ file văn bản UTF-8.")
    findings = [message for pattern, message in SUSPICIOUS_PATTERNS if re.search(pattern, source, re.IGNORECASE)]
    with db() as con:
        audit(con, user["username"], "code_check", client_ip(request))
    return {"filename": filename, "size": len(data), "sha256": sha256_bytes(data), "findings": findings,
            "note": "Phân tích tĩnh cơ bản; không thực thi file và không thay thế kiểm thử chuyên sâu."}


@app.post("/api/tools/hash")
async def file_hash(request: FastRequest, file: UploadFile = File(...)):
    user = current_user(request)
    require_csrf(request)
    data = await read_upload(file)
    filename = Path(file.filename or "upload").name
    with db() as con:
        audit(con, user["username"], "file_hash", client_ip(request))
    return {"filename": filename, "size": len(data), "sha256": sha256_bytes(data)}


@app.get("/api/tools/dns")
def dns_lookup(domain: str, request: FastRequest):
    user = current_user(request)
    domain = domain.strip().rstrip(".")
    if len(domain) > 253 or not re.fullmatch(r"(?=.{1,253}$)([a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)(\.([a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?))*", domain):
        raise HTTPException(400, "Tên miền không hợp lệ.")
    try:
        infos = socket.getaddrinfo(domain, None)
        ips = sorted({x[4][0] for x in infos})
    except socket.gaierror:
        ips = []
    with db() as con:
        audit(con, user["username"], "dns_lookup", client_ip(request))
    return {"domain": domain, "ips": ips}
