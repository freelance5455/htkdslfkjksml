import hashlib
import ipaddress
import secrets
import socket
import time
from collections import defaultdict, deque
from urllib.parse import urlsplit

from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError, VerificationError

ph = PasswordHasher(time_cost=3, memory_cost=65536, parallelism=2, hash_len=32, salt_len=16)

# Giới hạn theo tiến trình; triển khai nhiều worker/máy chủ cần Redis hoặc bộ giới hạn dùng chung.
_ip_attempts = defaultdict(deque)
DUMMY_HASH = ph.hash(secrets.token_urlsafe(32))


def hash_password(password: str) -> str:
    return ph.hash(password)


def verify_password(encoded: str, password: str) -> bool:
    try:
        return ph.verify(encoded, password)
    except Exception:
        return False


def ip_rate_limited(ip: str, limit: int = 30, window: int = 900) -> bool:
    current = time.time()
    queue = _ip_attempts[ip]
    while queue and queue[0] < current - window:
        queue.popleft()
    if len(queue) >= limit:
        return True
    queue.append(current)
    return False


def validate_public_url(raw: str):
    if len(raw) > 2048:
        raise ValueError("URL quá dài.")
    try:
        parsed = urlsplit(raw.strip())
        port = parsed.port
        hostname = parsed.hostname
    except ValueError:
        raise ValueError("URL hoặc cổng không hợp lệ.")
    if parsed.scheme.lower() not in ("http", "https") or not hostname:
        raise ValueError("Chỉ chấp nhận URL http:// hoặc https:// hợp lệ.")
    if parsed.username is not None or parsed.password is not None:
        raise ValueError("Không chấp nhận URL có thông tin đăng nhập.")
    try:
        host = hostname.rstrip(".").encode("idna").decode("ascii").lower()
    except UnicodeError:
        raise ValueError("Tên miền không hợp lệ.")
    if not host or host == "localhost" or host.endswith(".localhost"):
        raise ValueError("Không cho phép địa chỉ nội bộ.")
    if port == 0:
        raise ValueError("Cổng kết nối không hợp lệ.")
    effective_port = port or (443 if parsed.scheme.lower() == "https" else 80)
    try:
        answers = socket.getaddrinfo(host, effective_port, type=socket.SOCK_STREAM)
    except (socket.gaierror, UnicodeError, OSError):
        raise ValueError("Không phân giải được DNS của tên miền.")
    ips = sorted({item[4][0].split("%", 1)[0] for item in answers})
    if not ips:
        raise ValueError("Tên miền không có địa chỉ IP.")
    for value in ips:
        try:
            ip = ipaddress.ip_address(value)
        except ValueError:
            raise ValueError("DNS trả về địa chỉ IP không hợp lệ.")
        if not ip.is_global:
            raise ValueError("Từ chối IP private, loopback, link-local hoặc IP không công khai.")
    return parsed, host, ips


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()
