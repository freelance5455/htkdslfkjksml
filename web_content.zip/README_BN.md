# Offline Hisab HTML ZIP

এটি HTML/CSS/JavaScript-ভিত্তিক অফলাইন হিসাব প্রজেক্ট। Android Studio লাগবে না।

## চালানোর নিয়ম
1. ZIP Extract করুন।
2. `index.html` Chrome বা অন্য আধুনিক browser-এ খুলুন।
3. প্রথমবার PIN তৈরি করুন।
4. ফোনে Home Screen-এ যোগ করতে চাইলে HTTPS-এ host করা বা localhost দিয়ে চালানো প্রয়োজন হতে পারে। সরাসরি `file://` থেকে খোলার সময় browser ভেদে কিছু সুবিধা সীমিত হতে পারে।

## অন্তর্ভুক্ত
- PIN lock (PBKDF2 hash, Web Crypto সমর্থন করলে; fallback-এ সীমিত local hash)
- Salary, Overtime, Holiday, TA/DA, Other income ও custom source
- overtime start/end datetime এবং hourly rate থেকে live calculation
- Expense head add/manage এবং expense record CRUD
- date-wise list, View popup, Edit/Delete
- date range ও month report
- JSON backup export/import
- PDF print/save: browser Print dialog-এ Save as PDF নির্বাচন করুন
- auto backup JSON download স্বয়ংক্রিয়ভাবে নয়; browser security-এর কারণে ওয়েব পেজ নীরবে ফোনের নির্দিষ্ট folder-এ ফাইল লিখতে পারে না। ডেটা localStorage-এ থাকে, এবং backup copy browser-supported File System Access API থাকলে নির্বাচিত ফাইলে লেখা যায়; নইলে JSON Export করতে হবে।

## গুরুত্বপূর্ণ সীমাবদ্ধতা
- এটি browser-based web app, native APK নয়।
- Browser storage/localStorage ব্রাউজারের নিজস্ব storage; সরাসরি `OfflineHisab` নামে ফোনের shared storage folder-এ নীরবে লিখতে HTML app-কে Android অনুমতি দেয় না।
- Browser data clear/uninstall করলে local data হারাতে পারে। নিয়মিত JSON Export করে অন্য জায়গায় রাখুন।
- PIN lock একই browser profile-এর local data-র জন্য basic protection; device lock ব্যবহার করুন। গোপন/অতি-সংবেদনশীল তথ্যের জন্য নয়।
- Offline-first, no server, no analytics, no external libraries. App কোনো internet request করে না।
