# My IMO Diamond — সেটআপ গাইড (বাংলা)

এই প্রজেক্টে Buyer registration/login, প্যাকেজ, বিকাশ/নগদ Transaction ID জমা, অর্ডার তালিকা এবং Admin review UI আছে। **এটি প্রাথমিক starter build**—লাইভ ব্যবসায় ব্যবহারের আগে নিচের নিরাপত্তা ও ব্যবসায়িক সেটআপ সম্পন্ন করুন।

## ১. আগে যা করতে হবে
1. Firebase Console-এ `my-imo-diamond` প্রজেক্ট খুলুন।
2. Authentication → Sign-in method থেকে **Email/Password** চালু করুন।
3. Cloud Firestore database তৈরি করুন।
4. Project settings → Your apps → Web app থেকে Firebase config নিন।
5. `.env.example` কপি করে `.env` বানান; config values বসান।
6. বিকাশ ও নগদের আসল merchant/personal payment number `.env`-এ বসান। এখানে demo placeholder আছে।
7. `npm install` তারপর `npm run dev` চালিয়ে পরীক্ষা করুন।

## ২. Admin UID ও Rules
1. Authentication থেকে নিজের Admin account তৈরি করুন এবং সেই অ্যাকাউন্টে লগইন করুন।
2. Firebase Authentication user list থেকে ওই account-এর **UID** কপি করুন।
3. `.env`-এর `VITE_ADMIN_UID`-এ UID বসান।
4. `firestore.rules`-এ `ADMIN_UID_HERE`-এর জায়গায় একই UID বসান।
5. Firebase Console → Firestore Database → Rules-এ সম্পূর্ণ rules ফাইলটি বসিয়ে Publish করুন।
6. Admin UID কখনো public chat-এ শেয়ার করার দরকার নেই। Admin UID কোনো পাসওয়ার্ড নয়, কিন্তু ভুল UID/Rules হলে অনুমতি কাজ করবে না।

## ৩. Build ও Hosting
- `npm run build`
- `dist` ফোল্ডার Firebase Hosting-এ deploy করুন।
- `.env` বদলানোর পর নতুন করে build করতে হবে।

## গুরুত্বপূর্ণ সতর্কতা
- প্যাকেজ ও দাম কোডে **demo values**। `src/App.jsx`-এর `packages` তালিকায় আপনার বাস্তব প্যাকেজ/দাম বসান।
- Transaction ID জমা পড়লেই টাকা সত্যি এসেছে—এমন নয়। Admin অবশ্যই বিকাশ/নগদের লেনদেন যাচাই করবেন।
- এই starter version-এ Admin approve করলে গ্রাহকের `balance`-এ **ডায়মন্ড সংখ্যা** যোগ হয়; এটি টাকার ব্যালেন্স নয়।
- **সতর্কতা:** Firestore client transaction-এ order approval ও balance update একই সঙ্গে করার চেষ্টা আছে, কিন্তু প্রদত্ত rules-এ order update Admin-only এবং user update Admin-only; production-এর জন্য আরও শক্ত server-side Cloud Function/HTTPS backend দিয়ে approval, idempotency, price validation ও audit log বাস্তবায়ন করুন। এই starter UI-কে production-ready payment processor হিসেবে বিবেচনা করবেন না।
- Firebase API key browser config-এর অংশ; security Rules-ই ডেটা সুরক্ষার প্রধান স্তর। `allow read, write: if true;` কখনো ব্যবহার করবেন না।
- PIN-কে plain text হিসেবে সংরক্ষণ করবেন না। এই starter build-এ ইমেইল/পাসওয়ার্ড ব্যবহার করা হয়েছে।
