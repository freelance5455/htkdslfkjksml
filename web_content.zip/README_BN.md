# WIN TO BD — Online Tournament App Starter (Bangla)

এই bundle-এ আছে:
- `index.html`: black/red responsive frontend; Firebase Email/Password Auth এবং Firestore integration-এর starter code
- `firestore.rules`: basic access-control rules
- UI panels: tournament modes, rules, WhatsApp support, Free Fire UID/profile fields, wallet placeholder and leaderboard starter
- `WIN_TO_BD_App_Icon_512.png`: app icon
- `WIN_TO_BD_Full_Logo.png`: full logo

## আগে জেনে নাও
এটি একটি **starter project**, এখনও deploy করা live app বা APK নয়। Firebase project/config না বসালে Login ও online data কাজ করবে না। Payments/withdrawals, automated result calculation, push notifications, match editing, dispute handling এবং production-grade security এখনও আলাদা কাজ।

## ধাপ ১ — Firebase project
1. Android ফোনের Chrome-এ https://console.firebase.google.com/ খোলো।
2. Google account দিয়ে sign in করে `WIN TO BD` নামে project তৈরি করো।
3. Build → Authentication → Get started → Sign-in method → Email/Password enable করো।
4. Build → Firestore Database → Create database করো। শুরুতে production mode বেছে নাও, তারপর `firestore.rules` প্রকাশ করো।
5. Project settings → Your apps → Web app (</>) যোগ করো। Firebase config object কপি করো।

## ধাপ ২ — config বসানো
`index.html`-এ `const firebaseConfig = { ... }` খুঁজে Firebase Console থেকে পাওয়া `apiKey`, `authDomain`, `projectId`, `storageBucket`, `messagingSenderId`, `appId` দিয়ে placeholder values বদলাও। Firebase web config নিজে secret password নয়, তবে Firestore rules অবশ্যই লাগবে।

## ধাপ ৩ — Admin নিরাপদে তৈরি
1. অ্যাপে Register করে নিজের প্রথম account তৈরি করো।
2. Firebase Console → Authentication → Users থেকে নিজের UID কপি করো।
3. Firestore → Data → Start collection `admins` তৈরি করো; document ID হিসেবে নিজের UID ব্যবহার করো।
4. document-এ একটি field যোগ করো, যেমন `role` (string) = `admin`।
5. `firestore.rules`-এ admin check `admins/{uid}` document exists কি না সেটি দেখে; তাই UID ঠিক হওয়া জরুরি।
6. Firestore Rules tab-এ `firestore.rules`-এর rules paste করে Publish করো।

**Admin UID কাউকে দিও না।** Client-side code-এ admin secret/password রাখা যাবে না।

## ধাপ ৪ — অনলাইনে প্রকাশ
সহজ উপায় Firebase Hosting:
1. সাধারণত Firebase CLI/Node.js লাগবে, যা ফোনে করা কঠিন। কম্পিউটার থাকলে Firebase Hosting docs অনুসরণ করো: https://firebase.google.com/docs/hosting
2. `index.html`-কে hosting public folder-এর `index.html` হিসেবে deploy করো।
3. Deploy করা HTTPS URL থেকে login/register ও match create/join পরীক্ষা করো।

## ধাপ ৫ — APK
Hosted website-টি WebView wrapper/PWA-to-APK tool দিয়ে APK বানানো যায়। HTTPS site আগে ঠিকভাবে কাজ করছে নিশ্চিত করো। APK signing key নিজের কাছে নিরাপদে রাখবে। APK wrapper নিজে backend তৈরি করে না।

## গুরুত্বপূর্ণ সীমাবদ্ধতা
- এই starter-এর join flow player subcollection-এ join document তৈরি করে, কিন্তু slot count atomicভাবে reserve করে না। Public release-এর আগে Cloud Function/transaction দিয়ে slot limit enforce করতে হবে।
- Room ID/password বর্তমান rules-এ signed-in users পড়তে পারে। শুধু joined players-কে room details দেখাতে আলাদা secure Cloud Function/ডেটা মডেল দরকার।
- Wallet/withdraw/payment বাস্তব টাকা দিয়ে চালু নয়। বাস্তব পেমেন্টে trusted provider, server-side verification, audit logs ও প্রযোজ্য আইন মানা দরকার।
- Admin panel-এর create/delete কাজ আছে; production-এ edit/result publishing/abuse protection আলাদাভাবে সম্পূর্ণ করতে হবে।
- Free Fire-এর নাম/লোগো ব্যবহার করলে trademark/game publisher-এর নীতিমালা যাচাই করো।

## Files
- `index.html`
- `firestore.rules`
- `WIN_TO_BD_App_Icon_512.png`
- `WIN_TO_BD_Full_Logo.png`
