import socket
import time

def check_ping():
    print("=== Netzwerk-Test gestartet ===")
    host = "8.8.8.8"
    start = time.time()
    try:
        socket.create_connection((host, 53), timeout=3)
        latency = (time.time() - start) * 1000
        print(f"[OK] Verbindung erfolgreich. Ping: {latency:.2f} ms")
    except Exception as e:
        print(f"[FEHLER] Keine Verbindung: {e}")

if __name__ == "__main__":
    check_ping()
