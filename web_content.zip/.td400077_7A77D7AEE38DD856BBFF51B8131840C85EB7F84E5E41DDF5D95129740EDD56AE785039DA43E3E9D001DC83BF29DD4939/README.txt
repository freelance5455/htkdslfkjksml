Netzwerk & System Optimierungspaket
===================================
1. check_network.py  - Python-Skript zur Analyse von Ping & Latenz
2. optimize_wifi.sh   - Shell-Skript zur Optimierung des DNS-Caches
3. network_stats.html - HTML-Dashboard für Netz-Analysen

HINWEIS:
Diese Skripte dienen der Systemanalyse und Latenzoptimierung.
Hardwaregrenzen (z. B. ein 4G-Modem im Router) können durch Software nicht verändert werden.
