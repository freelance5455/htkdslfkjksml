#!/bin/sh
echo "=== DNS Cache Optimierung ==="
if command -v systemd-resolve > /dev/null; then
    sudo systemd-resolve --flush-caches
    echo "DNS-Cache erfolgreich geleert!"
else
    echo "Info: systemd-resolve nicht vorhanden."
fi
