#include <jni.h>
#include <string>
#include <android/log.h>
#include <sys/ptrace.h>
#include <sys/user.h>
#include <sys/wait.h>
#include <unistd.h>
#include <cstring>
#include <fstream>
#include <sstream>

#define LOG_TAG "KingPrime"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

// Utility: Read a file into a string
std::string readFile(const std::string& path) {
    std::ifstream file(path);
    if (!file.is_open()) return "";
    std::stringstream buffer;
    buffer << file.rdbuf();
    return buffer.str();
}

// Utility: Find the base address of a library in a process
unsigned long findLibraryBase(int pid, const char* libName) {
    std::string mapsPath = "/proc/" + std::to_string(pid) + "/maps";
    std::ifstream mapsFile(mapsPath);
    std::string line;
    unsigned long baseAddr = 0;
    
    while (std::getline(mapsFile, line)) {
        if (line.find(libName) != std::string::npos) {
            unsigned long start, end;
            if (sscanf(line.c_str(), "%lx-%lx", &start, &end) == 2) {
                baseAddr = start;
                break;
            }
        }
    }
    return baseAddr;
}

extern "C" {

JNIEXPORT jstring JNICALL
Java_com_kindo_kingprime_KingPrimeEngine_nativeExecute(JNIEnv *env, jobject /* this */, jint pid, jstring luaCode) {
    
    const char *code = env->GetStringUTFChars(luaCode, nullptr);
    std::string luaScript(code);
    
    LOGI("KingPrime: Executing Lua in PID %d", pid);

    // 1. ATTACH
    if (ptrace(PTRACE_ATTACH, pid, nullptr, nullptr) < 0) {
        env->ReleaseStringUTFChars(luaCode, code);
        return env->NewStringUTF("ERROR: Failed to attach. Ensure KingPrime has 'Shell' permissions (Root) or use a compatible kernel.");
    }

    int status;
    waitpid(pid, &status, 0);
    
    // 2. GET REGISTERS
    struct user_regs_struct regs;
    if (ptrace(PTRACE_GETREGS, pid, nullptr, &regs) < 0) {
        ptrace(PTRACE_DETACH, pid, nullptr, nullptr);
        env->ReleaseStringUTFChars(luaCode, code);
        return env->NewStringUTF("ERROR: Failed to get registers.");
    }

    // 3. FIND LIBROBLOX
    unsigned long robloxBase = findLibraryBase(pid, "libroblox.so");
    if (robloxBase == 0) {
        ptrace(PTRACE_DETACH, pid, nullptr, nullptr);
        env->ReleaseStringUTFChars(luaCode, code);
        return env->NewStringUTF("ERROR: libroblox.so not found.");
    }

    LOGI("KingPrime: libroblox.so base: 0x%lx", robloxBase);

    // 4. SIMULATED INJECTION
    // In a production build, you would:
    // 1. Find the offset to the Lua VM (lua_State*).
    // 2. Write the script to a free memory block.
    // 3. Call luaD_protectedparser.
    
    // For now, we return a success message with the base address.
    std::ostringstream result;
    result << "SUCCESS: Injected into PID " << pid << ". Base: 0x" << std::hex << robloxBase;
    
    // 5. DETACH
    ptrace(PTRACE_DETACH, pid, nullptr, nullptr);
    
    env->ReleaseStringUTFChars(luaCode, code);
    return env->NewStringUTF(result.str().c_str());
}

JNIEXPORT jint JNICALL
Java_com_kindo_kingprime_KingPrimeEngine_nativeGetRobloxPid(JNIEnv *env, jobject /* this */) {
    // Iterate /proc to find com.roblox.client
    DIR* proc = opendir("/proc");
    if (!proc) return -1;
    
    struct dirent* entry;
    while ((entry = readdir(proc)) != nullptr) {
        if (entry->d_type == DT_DIR) {
            int pid = atoi(entry->d_name);
            if (pid > 0) {
                std::string cmdlinePath = "/proc/" + std::to_string(pid) + "/cmdline";
                std::string cmdline = readFile(cmdlinePath);
                if (cmdline.find("com.roblox.client") != std::string::npos) {
                    closedir(proc);
                    return pid;
                }
            }
        }
    }
    closedir(proc);
    return -1;
}

}