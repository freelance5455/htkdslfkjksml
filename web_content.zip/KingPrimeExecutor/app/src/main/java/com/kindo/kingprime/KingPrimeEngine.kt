package com.kindo.kingprime

import android.util.Log
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class KingPrimeEngine {
    private val logBuffer = StringBuilder()
    companion object {
        const val TAG = "KingPrime"
    }

    init {
        System.loadLibrary("kingprime")
    }

    external fun nativeExecute(pid: Int, code: String): String
    external fun nativeGetRobloxPid(): Int

    fun getRobloxPid(): Int {
        return nativeGetRobloxPid()
    }

    fun execute(pid: Int, code: String): String {
        appendLog("INFO: Executing in PID $pid...")
        return nativeExecute(pid, code)
    }

    fun getLog(): String = logBuffer.toString()
    
    fun clearLog() { logBuffer.setLength(0) }

    fun appendLog(msg: String) {
        val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        logBuffer.append("[$time] $msg\n")
        Log.d(TAG, msg)
    }
}