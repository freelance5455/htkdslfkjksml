package com.kindo.kingprime

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var webView: WebView
    private val engine = KingPrimeEngine()

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webView)
        webView.settings.javaScriptEnabled = true
        webView.webViewClient = WebViewClient()
        webView.addJavascriptInterface(this, "Android")
        webView.loadUrl("file:///android_asset/index.html")
    }

    @JavascriptInterface
    fun executeLua(code: String) {
        val pid = engine.getRobloxPid()
        if (pid == -1) {
            updateLog("ERROR: Roblox not running.")
            return
        }
        Thread {
            val result = engine.execute(pid, code)
            updateLog("RESULT: $result")
        }.start()
    }

    @JavascriptInterface
    fun getRobloxPid(): Int {
        return engine.getRobloxPid()
    }

    @JavascriptInterface
    fun getLog(): String {
        return engine.getLog()
    }

    @JavascriptInterface
    fun clearLog() {
        engine.clearLog()
    }

    private fun updateLog(msg: String) {
        engine.appendLog(msg)
    }
}