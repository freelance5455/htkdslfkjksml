Secure Login QR page

Open index.html in a browser. The QR library is loaded from the CDN specified in index.html, so an internet connection is required unless you replace it with a local copy.