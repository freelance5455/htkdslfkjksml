import { expect, test, type Page } from '@playwright/test';

const filterSelect = (page: Page, label: string) =>
  page.locator('.filters label').filter({ has: page.locator('span', { hasText: new RegExp(`^${label}$`) }) }).locator('select');

async function open(page: Page, hash = '#/') {
  await page.goto(`/${hash}`);
  await expect(page.locator('.page-title')).toBeVisible();
}

/** Navega usando la barra lateral (escritorio) o la barra inferior (móvil). */
async function go(page: Page, label: string) {
  const nav = page.locator('.sidebar nav, .bottom-nav').filter({ visible: true }).first();
  await nav.getByRole('link', { name: label }).click();
}

test.describe('Taskify Desk', () => {
  test('el panel muestra los datos de demostración desde el almacenamiento local', async ({ page }) => {
    await open(page);
    const kpi = (label: string) => page.locator('.kpi', { hasText: label }).locator('.kpi-value');
    await expect(kpi('Total de tareas')).toHaveText('8');
    await expect(kpi('Pendientes')).toHaveText('6');
    await expect(kpi('Completadas')).toHaveText('2');
    await expect(kpi('Próximas a vencer')).toHaveText('2');
    await expect(kpi('Atrasadas')).toHaveText('1');
  });

  test('crear, editar, completar y eliminar una tarea (y persiste al recargar)', async ({ page }) => {
    await open(page, '#/tareas');
    await page.getByRole('button', { name: 'Nueva tarea' }).click();
    await page.getByRole('button', { name: 'Crear tarea' }).click();
    await expect(page.getByText('El título debe tener al menos 3 caracteres.')).toBeVisible();
    await page.getByRole('dialog').getByLabel('Título *').fill('Preparar reunión semanal');
    await page.getByRole('dialog').getByLabel('Prioridad').selectOption('high');
    await page.getByRole('dialog').getByLabel('Fecha límite').fill('2030-01-15T10:30');
    await page.getByRole('dialog').getByLabel('Responsable').fill('Carmen');
    await page.getByRole('button', { name: 'Crear tarea' }).click();
    await expect(page.getByRole('button', { name: 'Preparar reunión semanal', exact: true })).toBeVisible();

    await page.reload();
    await expect(page.getByRole('button', { name: 'Preparar reunión semanal', exact: true })).toBeVisible();

    await page.getByRole('button', { name: 'Editar «Preparar reunión semanal»' }).click();
    await page.getByRole('dialog').getByLabel('Título *').fill('Preparar reunión mensual');
    await page.getByRole('button', { name: 'Guardar cambios' }).click();
    await expect(page.getByRole('button', { name: 'Preparar reunión mensual', exact: true })).toBeVisible();

    // En móvil el aviso flotante puede tapar la fila: se espera a que desaparezca.
    await expect(page.locator('.toast')).toHaveCount(0, { timeout: 8000 });
    await page.getByRole('checkbox', { name: 'Completar «Preparar reunión mensual»' }).click();
    await expect(page.getByRole('checkbox', { name: 'Reabrir «Preparar reunión mensual»' })).toBeChecked();

    await page.getByRole('button', { name: 'Eliminar «Preparar reunión mensual»' }).click();
    await page.getByRole('dialog').getByRole('button', { name: 'Eliminar' }).click();
    await expect(page.getByRole('button', { name: 'Preparar reunión mensual', exact: true })).toHaveCount(0);
  });

  test('buscar y filtrar tareas', async ({ page }) => {
    await open(page, '#/tareas');
    await page.getByPlaceholder('Buscar por título').fill('formulario');
    await expect(page.locator('.task-row')).toHaveCount(1);
    await page.getByPlaceholder('Buscar por título').fill('');
    await filterSelect(page, 'Estado').selectOption('overdue');
    await expect(page.locator('.task-row')).toHaveCount(1);
    await expect(page.locator('.task-row')).toContainText('Validar formulario de registro');
  });

  test('Kanban: cinco columnas y límites WIP de Desarrollo (2) y Pruebas/QA (1)', async ({ page }) => {
    await open(page, '#/tablero');
    for (const col of ['Por hacer', 'Análisis / Diseño', 'Desarrollo', 'Pruebas / QA', 'Hecho']) {
      await expect(page.locator('.column-head h3', { hasText: col })).toBeVisible();
    }
    // QA está lleno (1/1): mover otra tarjeta debe fallar con mensaje.
    await page.getByLabel('Mover «Corregir error de login en móviles» a').selectOption('qa');
    await expect(page.locator('.alert-warn')).toContainText('Pruebas / QA ha alcanzado su límite WIP (1)');

    // Desarrollo admite una segunda tarjeta y bloquea la tercera.
    await page.getByLabel('Mover «Modo oscuro» a').selectOption('development');
    await expect(page.getByRole('region', { name: /^Desarrollo,/ }).locator('.count')).toHaveText('2 / 2');
    await page.getByLabel('Mover «Exportar informes a PDF» a').selectOption('development');
    await expect(page.locator('.alert-warn')).toContainText('Desarrollo ha alcanzado su límite WIP (2)');

    // Crear tarjeta en una columna llena también se bloquea.
    await page.getByRole('button', { name: 'Nueva tarjeta en Pruebas / QA' }).click();
    await expect(page.getByRole('dialog')).toHaveCount(0);
    await expect(page.locator('.alert-warn')).toContainText('límite WIP (1)');
  });

  test('modo oscuro se guarda', async ({ page }) => {
    await open(page);
    await page.getByRole('button', { name: 'Cambiar a modo oscuro' }).click();
    await expect(page.locator('html')).toHaveAttribute('data-theme', 'dark');
    await page.reload();
    await expect(page.locator('.page-title')).toBeVisible();
    await expect(page.locator('html')).toHaveAttribute('data-theme', 'dark');
  });

  test('recordatorios: muestra avisos y permite marcarlos como leídos', async ({ page }) => {
    await open(page, '#/avisos');
    await expect(page.locator('.task-row.reminder').first()).toBeVisible();
    await expect(page.locator('.task-row.reminder', { hasText: 'Validar formulario de registro' })).toContainText('Atrasada');
    await page.getByRole('button', { name: 'Marcar todo como leído' }).click();
    await expect(page.getByRole('button', { name: 'Marcar como leído' })).toHaveCount(0);
  });

  test('exporta un PDF real', async ({ page }) => {
    await open(page);
    const downloadPromise = page.waitForEvent('download');
    await page.getByRole('button', { name: 'Informe PDF' }).click();
    const download = await downloadPromise;
    expect(download.suggestedFilename()).toMatch(/^informe-general-\d{4}-\d{2}-\d{2}\.pdf$/);
    const stream = await download.createReadStream();
    const chunks: Buffer[] = [];
    for await (const c of stream) chunks.push(c as Buffer);
    const pdf = Buffer.concat(chunks);
    expect(pdf.subarray(0, 5).toString()).toBe('%PDF-');
    expect(pdf.length).toBeGreaterThan(3000);
  });

  test('PWA: manifiesto e iconos válidos', async ({ page, request }) => {
    await open(page);
    const manifest = await (await request.get('/manifest.webmanifest')).json();
    expect(manifest.display).toBe('standalone');
    expect(manifest.icons.some((i: { sizes: string }) => i.sizes === '512x512')).toBe(true);
    for (const icon of manifest.icons) {
      const res = await request.get(`/${icon.src}`);
      expect(res.ok()).toBe(true);
    }
  });

  test('funciona sin conexión tras la primera visita', async ({ page, context }) => {
    await open(page);
    await page.evaluate(async () => {
      await navigator.serviceWorker.ready;
    });
    // Recarga para que el service worker controle la página.
    await page.reload();
    await expect.poll(() => page.evaluate(() => !!navigator.serviceWorker.controller)).toBe(true);

    await context.setOffline(true);
    await page.reload();
    await expect(page.locator('.offline-pill')).toBeVisible();
    await go(page, 'Mis tareas');
    await page.getByRole('button', { name: 'Nueva tarea' }).click();
    await page.getByRole('dialog').getByLabel('Título *').fill('Tarea creada sin conexión');
    await page.getByRole('button', { name: 'Crear tarea' }).click();
    await expect(page.getByRole('button', { name: 'Tarea creada sin conexión', exact: true })).toBeVisible();
    await page.reload();
    await expect(page.getByRole('button', { name: 'Tarea creada sin conexión', exact: true })).toBeVisible();
    // El PDF también se genera sin conexión.
    const downloadPromise = page.waitForEvent('download');
    await page.getByRole('button', { name: 'Exportar PDF' }).click();
    expect((await downloadPromise).suggestedFilename()).toMatch(/\.pdf$/);
    await context.setOffline(false);
  });

  test('diseño adaptable: sin desplazamiento horizontal en ninguna pantalla', async ({ page }) => {
    for (const hash of ['#/', '#/tareas', '#/listas', '#/tablero', '#/avisos', '#/ajustes']) {
      await open(page, hash);
      const overflow = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
      expect(overflow, `desbordamiento en ${hash}`).toBeLessThanOrEqual(0);
    }
    const isMobile = (page.viewportSize()?.width ?? 1000) < 900;
    if (isMobile) {
      // La barra inferior debe estar realmente dentro de la pantalla (no solo "visible" en el DOM).
      await open(page, '#/tablero');
      const navBottom = await page.evaluate(() => document.querySelector('.bottom-nav')!.getBoundingClientRect().bottom);
      expect(navBottom).toBeLessThanOrEqual((page.viewportSize()?.height ?? 0) + 1);
    }
    await expect(page.locator('.bottom-nav')).toBeVisible({ visible: isMobile });
    await expect(page.locator('.sidebar')).toBeVisible({ visible: !isMobile });
  });

  test('listas: crear una lista y abrir su tablero', async ({ page }) => {
    await open(page, '#/listas');
    await page.getByRole('button', { name: 'Nueva lista' }).click();
    await page.getByRole('dialog').getByLabel('Nombre *').fill('Clientes');
    await page.getByRole('button', { name: 'Crear lista' }).click();
    const card = page.locator('.list-card', { hasText: 'Clientes' });
    await expect(card).toContainText('0 tareas');
    await card.getByRole('link', { name: 'Tablero' }).click();
    await expect(page.locator('.filters select').first()).toHaveValue(/.+/);
    await expect(page.locator('.column-empty').first()).toHaveText('Sin tarjetas');
  });
});
