import { computeStats, isOverdue } from '../domain/queries';
import { PRIORITY_LABELS, STATUS_LABELS, type Settings, type Task, type TaskList } from '../domain/types';
import { formatDate, formatDateTime } from '../utils/format';
import { fileStamp, saveFile } from './files';

export interface ReportOptions {
  title: string;
  subtitle?: string;
  tasks: Task[];
  lists: TaskList[];
  settings: Settings;
  now: Date;
}

/** Genera un PDF real (jsPDF) con resumen y tabla de tareas. No necesita conexión. */
export async function buildTaskReport(opts: ReportOptions): Promise<Blob> {
  const [{ jsPDF }, { autoTable }] = await Promise.all([import('jspdf'), import('jspdf-autotable')]);
  const doc = new jsPDF({ unit: 'pt', format: 'a4' });
  const listName = new Map(opts.lists.map((l) => [l.id, l.name]));
  const stats = computeStats(opts.tasks, opts.now);
  const margin = 40;

  doc.setFillColor(47, 91, 211);
  doc.rect(0, 0, doc.internal.pageSize.getWidth(), 6, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(18);
  doc.setTextColor(28, 36, 51);
  doc.text(opts.title, margin, 48);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  doc.setTextColor(91, 101, 118);
  doc.text(`${opts.settings.workspaceName} · Generado el ${formatDateTime(opts.now.toISOString())} por ${opts.settings.userName}`, margin, 66);
  if (opts.subtitle) doc.text(opts.subtitle, margin, 80);

  autoTable(doc, {
    startY: opts.subtitle ? 94 : 82,
    margin: { left: margin, right: margin },
    head: [['Total', 'Pendientes', 'Completadas', 'Próximas (72 h)', 'Atrasadas']],
    body: [[stats.total, stats.pending, stats.done, stats.upcoming, stats.overdue]],
    theme: 'grid',
    styles: { halign: 'center', fontSize: 11 },
    headStyles: { fillColor: [233, 238, 251], textColor: [31, 63, 153] },
  });

  const rows = opts.tasks.map((t) => [
    t.title,
    listName.get(t.listId) ?? '—',
    STATUS_LABELS[t.status],
    PRIORITY_LABELS[t.priority],
    t.assignee || '—',
    t.dueDate ? formatDate(t.dueDate) + (isOverdue(t, opts.now) ? ' (atrasada)' : '') : '—',
  ]);

  const lastY = (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY;
  autoTable(doc, {
    startY: lastY + 20,
    margin: { left: margin, right: margin },
    head: [['Tarea', 'Lista', 'Estado', 'Prioridad', 'Responsable', 'Fecha límite']],
    body: rows.length ? rows : [['No hay tareas que mostrar', '', '', '', '', '']],
    styles: { fontSize: 9, cellPadding: 5, overflow: 'linebreak' },
    headStyles: { fillColor: [28, 36, 51], textColor: 255 },
    alternateRowStyles: { fillColor: [246, 247, 249] },
    columnStyles: { 0: { cellWidth: 160 } },
    didDrawPage: () => {
      const page = doc.getNumberOfPages();
      doc.setFontSize(8);
      doc.setTextColor(120);
      doc.text(`Taskify Desk · página ${page}`, margin, doc.internal.pageSize.getHeight() - 20);
    },
  });

  return doc.output('blob');
}

export async function exportTaskReport(opts: ReportOptions, fileBase = 'informe-tareas'): Promise<void> {
  const blob = await buildTaskReport(opts);
  await saveFile(`${fileBase}-${fileStamp(opts.now)}.pdf`, blob);
}
