import { Capacitor } from '@capacitor/core';

/** true dentro de la app Android (Capacitor); false en navegador / PWA. */
export const isNative = (): boolean => Capacitor.isNativePlatform();
