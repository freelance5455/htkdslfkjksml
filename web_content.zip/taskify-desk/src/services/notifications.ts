import { computeNotificationSchedule, notificationNumericId } from '../domain/reminders';
import type { Reminder, ReminderSettings, Task } from '../domain/types';
import { isNative } from './platform';

export type PermissionState = 'granted' | 'denied' | 'prompt' | 'unsupported';

export async function getNotificationPermission(): Promise<PermissionState> {
  if (isNative()) {
    const { LocalNotifications } = await import('@capacitor/local-notifications');
    const p = await LocalNotifications.checkPermissions();
    return p.display === 'granted' ? 'granted' : p.display === 'denied' ? 'denied' : 'prompt';
  }
  if (typeof Notification === 'undefined') return 'unsupported';
  return Notification.permission === 'default' ? 'prompt' : Notification.permission;
}

export async function requestNotificationPermission(): Promise<PermissionState> {
  if (isNative()) {
    const { LocalNotifications } = await import('@capacitor/local-notifications');
    const p = await LocalNotifications.requestPermissions();
    return p.display === 'granted' ? 'granted' : 'denied';
  }
  if (typeof Notification === 'undefined') return 'unsupported';
  const result = await Notification.requestPermission();
  return result === 'default' ? 'prompt' : result;
}

/**
 * Navegador / PWA: muestra una notificación del sistema por cada aviso nuevo.
 * Solo funciona mientras la aplicación está abierta (aunque esté en segundo plano).
 */
export async function showWebNotifications(created: Reminder[], tasks: Task[], settings: ReminderSettings): Promise<void> {
  if (isNative() || !settings.systemNotifications || created.length === 0) return;
  if (typeof Notification === 'undefined' || Notification.permission !== 'granted') return;
  const byId = new Map(tasks.map((t) => [t.id, t]));
  const registration = 'serviceWorker' in navigator ? await navigator.serviceWorker.getRegistration() : undefined;
  for (const r of created) {
    const task = byId.get(r.taskId);
    if (!task) continue;
    const title = r.type === 'overdue' ? 'Tarea atrasada' : 'Tarea próxima a vencer';
    const options: NotificationOptions = { body: task.title, icon: './icons/icon-192.png', tag: `${r.taskId}-${r.type}` };
    if (registration) await registration.showNotification(title, options);
    else new Notification(title, options);
  }
}

/**
 * Android: programa notificaciones locales reales que suenan aunque la app esté cerrada.
 * Se reprograman completas cada vez que cambian las tareas o los ajustes.
 */
export async function syncNativeNotifications(tasks: Task[], settings: ReminderSettings, now: Date): Promise<void> {
  if (!isNative()) return;
  const { LocalNotifications } = await import('@capacitor/local-notifications');
  const pending = await LocalNotifications.getPending();
  if (pending.notifications.length) {
    await LocalNotifications.cancel({ notifications: pending.notifications.map((n) => ({ id: n.id })) });
  }
  const perm = await LocalNotifications.checkPermissions();
  if (perm.display !== 'granted') return;
  const schedule = computeNotificationSchedule(tasks, settings, now).slice(0, 60);
  if (schedule.length === 0) return;
  await LocalNotifications.schedule({
    notifications: schedule.map((n) => ({
      id: notificationNumericId(n.taskId, n.type),
      title: n.title,
      body: n.body,
      schedule: { at: n.at, allowWhileIdle: true },
      extra: { taskId: n.taskId },
    })),
  });
}
