import type { Task } from '../domain/types';

let counter = 0;

export function makeTask(overrides: Partial<Task> = {}): Task {
  counter += 1;
  const ts = '2026-10-01T10:00:00.000Z';
  return {
    id: `t${counter}`,
    listId: 'L1',
    title: `Tarea ${counter}`,
    description: '',
    status: 'backlog',
    priority: 'medium',
    assignee: '',
    dueDate: null,
    completedAt: null,
    position: counter,
    createdAt: ts,
    updatedAt: ts,
    ...overrides,
  };
}
