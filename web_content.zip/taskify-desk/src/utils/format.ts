const dateFmt = new Intl.DateTimeFormat('es-ES', { day: 'numeric', month: 'short', year: 'numeric' });
const dateTimeFmt = new Intl.DateTimeFormat('es-ES', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
const longFmt = new Intl.DateTimeFormat('es-ES', { weekday: 'long', day: 'numeric', month: 'long' });
const relFmt = new Intl.RelativeTimeFormat('es-ES', { numeric: 'auto' });

export const formatDate = (iso: string) => dateFmt.format(new Date(iso));
export const formatDateTime = (iso: string) => dateTimeFmt.format(new Date(iso));
export const formatLongDate = (d: Date) => {
  const s = longFmt.format(d);
  return s.charAt(0).toUpperCase() + s.slice(1);
};

/** "hace 5 minutos", "mañana", "en 3 días"… */
export function formatRelative(iso: string, now: Date): string {
  const diffMs = Date.parse(iso) - now.getTime();
  const abs = Math.abs(diffMs);
  const min = 60_000;
  const hour = 60 * min;
  const day = 24 * hour;
  if (abs < hour) return relFmt.format(Math.round(diffMs / min), 'minute');
  if (abs < day) return relFmt.format(Math.round(diffMs / hour), 'hour');
  return relFmt.format(Math.round(diffMs / day), 'day');
}

const pad = (n: number) => String(n).padStart(2, '0');

/** ISO (UTC) → valor para <input type="datetime-local"> en hora local. */
export function toLocalInput(iso: string | null): string {
  if (!iso) return '';
  const d = new Date(iso);
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

/** Valor de <input type="datetime-local"> (hora local) → ISO UTC. */
export function fromLocalInput(value: string): string | null {
  if (!value) return null;
  const d = new Date(value);
  return Number.isNaN(d.getTime()) ? null : d.toISOString();
}

export function initials(name: string): string {
  return name
    .trim()
    .split(/\s+/)
    .slice(0, 2)
    .map((p) => p.charAt(0).toUpperCase())
    .join('') || '?';
}
