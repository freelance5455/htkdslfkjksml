import { DEFAULT_SETTINGS, type Activity, type Settings, type Task, type TaskList } from '../domain/types';

const DAY = 86_400_000;

/** Ids fijos: volver a cargar la demo sobrescribe en lugar de duplicar. */
export const DEMO_LIST_ID = 'demo-list-taskify';
export const DEMO_LIST_OFFICE_ID = 'demo-list-oficina';

interface DemoTaskSpec {
  id: string;
  title: string;
  description: string;
  status: Task['status'];
  priority: Task['priority'];
  assignee: string;
  dueInDays: number;
  listId?: string;
}

const DEMO_TASKS: DemoTaskSpec[] = [
  { id: 'demo-1', title: 'Modo oscuro', description: 'Añadir un tema oscuro respetando la preferencia del sistema.', status: 'backlog', priority: 'medium', assignee: 'Marta', dueInDays: 10 },
  { id: 'demo-2', title: 'Exportar informes a PDF', description: 'Informe con resumen y tabla de tareas.', status: 'backlog', priority: 'low', assignee: 'Luis', dueInDays: 14 },
  { id: 'demo-3', title: 'Investigar librería de notificaciones push', description: 'Comparar opciones gratuitas y sin servidor de pago.', status: 'analysis', priority: 'medium', assignee: 'Ana', dueInDays: 2 },
  { id: 'demo-4', title: 'Corregir error de login en móviles', description: 'El botón de entrar queda oculto en pantallas pequeñas.', status: 'development', priority: 'urgent', assignee: 'Luis', dueInDays: 1 },
  { id: 'demo-5', title: 'Validar formulario de registro', description: 'Probar mensajes de error y campos obligatorios.', status: 'qa', priority: 'high', assignee: 'Marta', dueInDays: -1 },
  { id: 'demo-6', title: 'Configurar servidor de despliegue', description: '', status: 'done', priority: 'high', assignee: 'Ana', dueInDays: -5 },
  { id: 'demo-7', title: 'Actualizar dependencias de seguridad', description: '', status: 'done', priority: 'urgent', assignee: 'Luis', dueInDays: -3 },
  { id: 'demo-8', title: 'Pedir material de oficina', description: 'Tóner, folios y carpetas.', status: 'backlog', priority: 'low', assignee: 'Ana', dueInDays: 6, listId: DEMO_LIST_OFFICE_ID },
];

/** Fecha límite a las 18:00 (hora local) del día indicado. */
function dueAt(now: Date, days: number): string {
  const d = new Date(now.getTime() + days * DAY);
  d.setHours(18, 0, 0, 0);
  return d.toISOString();
}

export interface DemoData {
  lists: TaskList[];
  tasks: Task[];
  activity: Activity[];
  settings: Settings;
}

export function buildDemoData(now: Date): DemoData {
  const created = new Date(now.getTime() - 7 * DAY).toISOString();
  const lists: TaskList[] = [
    { id: DEMO_LIST_ID, name: 'Proyecto Taskify', description: 'Desarrollo y mantenimiento de la aplicación.', createdAt: created },
    { id: DEMO_LIST_OFFICE_ID, name: 'Oficina', description: 'Tareas generales del día a día.', createdAt: new Date(Date.parse(created) + 60_000).toISOString() },
  ];
  const tasks: Task[] = DEMO_TASKS.map((spec, index) => {
    const due = dueAt(now, spec.dueInDays);
    return {
      id: spec.id,
      listId: spec.listId ?? DEMO_LIST_ID,
      title: spec.title,
      description: spec.description,
      status: spec.status,
      priority: spec.priority,
      assignee: spec.assignee,
      dueDate: due,
      completedAt: spec.status === 'done' ? due : null,
      position: index,
      createdAt: created,
      updatedAt: created,
    };
  });
  const activity: Activity[] = [
    { id: 'demo-act-1', action: 'list', detail: 'Se cargaron los datos de demostración', taskId: null, createdAt: now.toISOString() },
  ];
  const settings: Settings = { ...DEFAULT_SETTINGS, userName: 'Ana', workspaceName: 'Oficina Demo' };
  return { lists, tasks, activity, settings };
}
