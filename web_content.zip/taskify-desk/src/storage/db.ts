/**
 * Acceso a IndexedDB sin librerías. Los datos se guardan en el propio dispositivo
 * (navegador o WebView de Android) y se conservan al cerrar la aplicación.
 */
import type { Activity, Reminder, Task, TaskList } from '../domain/types';

export const DB_NAME = 'taskify-desk';
export const DB_VERSION = 1;

export interface EntityStores {
  lists: TaskList;
  tasks: Task;
  reminders: Reminder;
  activity: Activity;
}
export type EntityStore = keyof EntityStores;
export const ENTITY_STORES: EntityStore[] = ['lists', 'tasks', 'reminders', 'activity'];
const META_STORE = 'meta';

function promisify<T>(request: IDBRequest<T>): Promise<T> {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

function txDone(tx: IDBTransaction): Promise<void> {
  return new Promise((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
    tx.onabort = () => reject(tx.error ?? new Error('Transacción cancelada'));
  });
}

export class Database {
  private constructor(private readonly db: IDBDatabase) {}

  static async open(name = DB_NAME, factory: IDBFactory = indexedDB): Promise<Database> {
    const request = factory.open(name, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      for (const store of ENTITY_STORES) {
        if (!db.objectStoreNames.contains(store)) {
          const os = db.createObjectStore(store, { keyPath: 'id' });
          if (store === 'tasks') os.createIndex('listId', 'listId');
          if (store === 'reminders') os.createIndex('taskId', 'taskId');
        }
      }
      if (!db.objectStoreNames.contains(META_STORE)) db.createObjectStore(META_STORE);
    };
    return new Database(await promisify(request));
  }

  close(): void {
    this.db.close();
  }

  async getAll<S extends EntityStore>(store: S): Promise<EntityStores[S][]> {
    const tx = this.db.transaction(store, 'readonly');
    return promisify(tx.objectStore(store).getAll() as IDBRequest<EntityStores[S][]>);
  }

  async putMany<S extends EntityStore>(store: S, values: EntityStores[S][]): Promise<void> {
    if (values.length === 0) return;
    const tx = this.db.transaction(store, 'readwrite');
    const os = tx.objectStore(store);
    for (const v of values) os.put(v);
    await txDone(tx);
  }

  async put<S extends EntityStore>(store: S, value: EntityStores[S]): Promise<void> {
    await this.putMany(store, [value]);
  }

  async deleteMany(store: EntityStore, ids: string[]): Promise<void> {
    if (ids.length === 0) return;
    const tx = this.db.transaction(store, 'readwrite');
    const os = tx.objectStore(store);
    for (const id of ids) os.delete(id);
    await txDone(tx);
  }

  async getMeta<T>(key: string): Promise<T | undefined> {
    const tx = this.db.transaction(META_STORE, 'readonly');
    return promisify(tx.objectStore(META_STORE).get(key) as IDBRequest<T | undefined>);
  }

  async setMeta<T>(key: string, value: T): Promise<void> {
    const tx = this.db.transaction(META_STORE, 'readwrite');
    tx.objectStore(META_STORE).put(value, key);
    await txDone(tx);
  }

  /** Borra todos los datos (listas, tareas, avisos, actividad y ajustes). */
  async clearAll(): Promise<void> {
    const stores = [...ENTITY_STORES, META_STORE];
    const tx = this.db.transaction(stores, 'readwrite');
    for (const s of stores) tx.objectStore(s).clear();
    await txDone(tx);
  }
}
