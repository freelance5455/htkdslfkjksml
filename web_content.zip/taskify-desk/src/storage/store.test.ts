import 'fake-indexeddb/auto';
import { afterEach, describe, expect, it } from 'vitest';
import { Database } from './db';
import { DEMO_LIST_ID } from './seed';
import { TaskifyStore } from './store';

const fixedNow = () => new Date('2026-10-13T09:00:00.000Z');
let dbCounter = 0;
const opened: Database[] = [];

async function freshStore(name = `test-${++dbCounter}`) {
  const db = await Database.open(name);
  opened.push(db);
  return { store: await TaskifyStore.create(db, fixedNow), name };
}

afterEach(() => {
  opened.splice(0).forEach((db) => db.close());
});

describe('almacenamiento local', () => {
  it('carga la demo una sola vez (sin duplicar)', async () => {
    const { store, name } = await freshStore();
    expect(store.getSnapshot().tasks).toHaveLength(8);
    const db2 = await Database.open(name);
    opened.push(db2);
    const again = await TaskifyStore.create(db2, fixedNow);
    expect(again.getSnapshot().tasks).toHaveLength(8);
  });

  it('distribuye la demo en el Kanban según el enunciado', async () => {
    const { store } = await freshStore();
    const titlesIn = (status: string) =>
      store.getSnapshot().tasks.filter((t) => t.listId === DEMO_LIST_ID && t.status === status).map((t) => t.title);
    expect(titlesIn('backlog')).toEqual(['Modo oscuro', 'Exportar informes a PDF']);
    expect(titlesIn('analysis')).toEqual(['Investigar librería de notificaciones push']);
    expect(titlesIn('development')).toEqual(['Corregir error de login en móviles']);
    expect(titlesIn('qa')).toEqual(['Validar formulario de registro']);
    expect(titlesIn('done')).toHaveLength(2);
  });

  it('persiste los cambios entre aperturas', async () => {
    const { store, name } = await freshStore();
    const res = await store.createTask({ listId: DEMO_LIST_ID, title: 'Llamar al proveedor', priority: 'high' });
    expect(res.ok).toBe(true);
    const db2 = await Database.open(name);
    opened.push(db2);
    const reopened = await TaskifyStore.create(db2, fixedNow);
    expect(reopened.getSnapshot().tasks.some((t) => t.title === 'Llamar al proveedor')).toBe(true);
  });

  it('valida los datos de la tarea', async () => {
    const { store } = await freshStore();
    const res = await store.createTask({ listId: DEMO_LIST_ID, title: 'ab' });
    expect(res.ok).toBe(false);
    if (!res.ok) expect(res.fieldErrors?.title).toBeDefined();
  });

  it('aplica el límite WIP al mover y al crear', async () => {
    const { store } = await freshStore();
    // QA ya tiene 1 (límite 1)
    const dev = store.getSnapshot().tasks.find((t) => t.status === 'development')!;
    const move = await store.moveTask(dev.id, 'qa');
    expect(move.ok).toBe(false);
    const create = await store.createTask({ listId: DEMO_LIST_ID, title: 'Otra prueba', status: 'qa' });
    expect(create.ok).toBe(false);
    // Desarrollo tiene 1 (límite 2): entra una, la siguiente no
    const backlog = store.getSnapshot().tasks.filter((t) => t.listId === DEMO_LIST_ID && t.status === 'backlog');
    expect((await store.moveTask(backlog[0].id, 'development')).ok).toBe(true);
    expect((await store.moveTask(backlog[1].id, 'development')).ok).toBe(false);
  });

  it('completa y reabre tareas', async () => {
    const { store } = await freshStore();
    const t = store.getSnapshot().tasks.find((x) => x.status === 'backlog')!;
    await store.toggleComplete(t.id);
    const done = store.getSnapshot().tasks.find((x) => x.id === t.id)!;
    expect(done.status).toBe('done');
    expect(done.completedAt).not.toBeNull();
    await store.toggleComplete(t.id);
    expect(store.getSnapshot().tasks.find((x) => x.id === t.id)!.completedAt).toBeNull();
  });

  it('elimina tareas y listas en cascada, pero no la última lista', async () => {
    const { store } = await freshStore();
    const office = store.getSnapshot().lists.find((l) => l.id !== DEMO_LIST_ID)!;
    expect((await store.deleteList(office.id)).ok).toBe(true);
    expect(store.getSnapshot().tasks.every((t) => t.listId === DEMO_LIST_ID)).toBe(true);
    expect((await store.deleteList(DEMO_LIST_ID)).ok).toBe(false);
  });

  it('genera recordatorios sin duplicarlos y los marca como leídos', async () => {
    const { store } = await freshStore();
    const first = await store.checkReminders();
    expect(first.length).toBeGreaterThan(0);
    expect(await store.checkReminders()).toHaveLength(0);
    await store.markAllRemindersRead();
    expect(store.getSnapshot().reminders.every((r) => r.readAt)).toBe(true);
  });

  it('exporta e importa una copia de seguridad', async () => {
    const { store } = await freshStore();
    await store.createTask({ listId: DEMO_LIST_ID, title: 'Tarea de la copia' });
    const json = store.exportBackup();
    const { store: other } = await freshStore();
    expect((await other.importBackup('{"no":"válido"}')).ok).toBe(false);
    expect((await other.importBackup(json)).ok).toBe(true);
    expect(other.getSnapshot().tasks.some((t) => t.title === 'Tarea de la copia')).toBe(true);
  });
});
