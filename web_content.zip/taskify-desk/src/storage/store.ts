/**
 * Estado de la aplicación + operaciones de negocio.
 * Cada operación valida, aplica las reglas (WIP), guarda en IndexedDB y avisa a la interfaz.
 */
import { computeNewReminders } from '../domain/reminders';
import {
  DEFAULT_SETTINGS,
  PRIORITIES,
  STATUSES,
  STATUS_LABELS,
  type Activity,
  type ActivityAction,
  type AppData,
  type Reminder,
  type Settings,
  type Status,
  type Task,
  type TaskInput,
  type TaskList,
} from '../domain/types';
import { hasErrors, validateList, validateTask, type FieldErrors } from '../domain/validation';
import { checkWip } from '../domain/wip';
import { Database } from './db';
import { buildDemoData } from './seed';

export type Result = { ok: true; id?: string } | { ok: false; error: string; fieldErrors?: FieldErrors };

const MAX_ACTIVITY = 50;
const SEEDED_KEY = 'seeded';
const SETTINGS_KEY = 'settings';

export function createId(): string {
  if (typeof crypto !== 'undefined' && 'randomUUID' in crypto) return crypto.randomUUID();
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
}

type Listener = () => void;
type Clock = () => Date;

export class TaskifyStore {
  private data: AppData = { lists: [], tasks: [], reminders: [], activity: [], settings: DEFAULT_SETTINGS };
  private listeners = new Set<Listener>();
  private constructor(
    private readonly db: Database,
    private readonly now: Clock,
  ) {}

  /** Abre la base de datos y carga la demo solo la primera vez. */
  static async create(db: Database, now: Clock = () => new Date()): Promise<TaskifyStore> {
    const store = new TaskifyStore(db, now);
    const seeded = await db.getMeta<boolean>(SEEDED_KEY);
    if (!seeded) await store.writeDemo();
    await store.reload();
    return store;
  }

  // ---------- suscripción (useSyncExternalStore) ----------
  subscribe = (listener: Listener): (() => void) => {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  };

  getSnapshot = (): AppData => this.data;

  private emit(next: Partial<AppData>): void {
    this.data = { ...this.data, ...next };
    for (const l of this.listeners) l();
  }

  private async reload(): Promise<void> {
    const [lists, tasks, reminders, activity, settings] = await Promise.all([
      this.db.getAll('lists'),
      this.db.getAll('tasks'),
      this.db.getAll('reminders'),
      this.db.getAll('activity'),
      this.db.getMeta<Settings>(SETTINGS_KEY),
    ]);
    lists.sort((a, b) => a.createdAt.localeCompare(b.createdAt) || a.name.localeCompare(b.name, 'es'));
    tasks.sort((a, b) => a.position - b.position);
    activity.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    reminders.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    this.emit({
      lists,
      tasks,
      reminders,
      activity,
      settings: { ...DEFAULT_SETTINGS, ...settings, reminders: { ...DEFAULT_SETTINGS.reminders, ...settings?.reminders } },
    });
  }

  private async writeDemo(): Promise<void> {
    const demo = buildDemoData(this.now());
    await this.db.putMany('lists', demo.lists);
    await this.db.putMany('tasks', demo.tasks);
    await this.db.putMany('activity', demo.activity);
    await this.db.setMeta(SETTINGS_KEY, demo.settings);
    await this.db.setMeta(SEEDED_KEY, true);
  }

  private async log(action: ActivityAction, detail: string, taskId: string | null): Promise<void> {
    const entry: Activity = { id: createId(), action, detail, taskId, createdAt: this.now().toISOString() };
    const activity = [entry, ...this.data.activity];
    const removed = activity.slice(MAX_ACTIVITY).map((a) => a.id);
    await this.db.put('activity', entry);
    await this.db.deleteMany('activity', removed);
    this.emit({ activity: activity.slice(0, MAX_ACTIVITY) });
  }

  // ---------- tareas ----------
  async createTask(input: TaskInput): Promise<Result> {
    const values = {
      title: input.title,
      description: input.description ?? '',
      listId: input.listId,
      status: input.status ?? 'backlog',
      priority: input.priority ?? 'medium',
      assignee: input.assignee ?? '',
      dueDate: input.dueDate ?? null,
    };
    const fieldErrors = validateTask(values);
    if (!this.data.lists.some((l) => l.id === values.listId)) fieldErrors.listId = 'La lista no existe.';
    if (hasErrors(fieldErrors)) return { ok: false, error: 'Revisa los campos marcados.', fieldErrors };
    const wip = checkWip(this.data.tasks, values.listId, values.status);
    if (!wip.ok) return { ok: false, error: wip.message! };

    const ts = this.now().toISOString();
    const task: Task = {
      id: createId(),
      listId: values.listId,
      title: values.title.trim(),
      description: values.description.trim(),
      status: values.status,
      priority: values.priority,
      assignee: values.assignee.trim(),
      dueDate: values.dueDate,
      completedAt: values.status === 'done' ? ts : null,
      position: this.nextPosition(),
      createdAt: ts,
      updatedAt: ts,
    };
    await this.db.put('tasks', task);
    this.emit({ tasks: [...this.data.tasks, task] });
    await this.log('created', `Creó «${task.title}»`, task.id);
    return { ok: true, id: task.id };
  }

  async updateTask(id: string, patch: Partial<Omit<Task, 'id' | 'createdAt'>>): Promise<Result> {
    const current = this.data.tasks.find((t) => t.id === id);
    if (!current) return { ok: false, error: 'La tarea ya no existe.' };
    const merged: Task = { ...current, ...patch };
    const fieldErrors = validateTask({ ...merged, dueDate: merged.dueDate });
    if (!this.data.lists.some((l) => l.id === merged.listId)) fieldErrors.listId = 'La lista no existe.';
    if (hasErrors(fieldErrors)) return { ok: false, error: 'Revisa los campos marcados.', fieldErrors };
    if (merged.status !== current.status || merged.listId !== current.listId) {
      const wip = checkWip(this.data.tasks, merged.listId, merged.status, id);
      if (!wip.ok) return { ok: false, error: wip.message! };
    }
    const ts = this.now().toISOString();
    const updated: Task = {
      ...merged,
      title: merged.title.trim(),
      description: merged.description.trim(),
      assignee: merged.assignee.trim(),
      completedAt: merged.status === 'done' ? (current.completedAt ?? ts) : null,
      updatedAt: ts,
    };
    await this.db.put('tasks', updated);
    this.emit({ tasks: this.data.tasks.map((t) => (t.id === id ? updated : t)) });

    if (current.status !== updated.status) {
      if (updated.status === 'done') await this.log('completed', `Completó «${updated.title}»`, id);
      else if (current.status === 'done') await this.log('reopened', `Reabrió «${updated.title}»`, id);
      else await this.log('moved', `Movió «${updated.title}» a ${STATUS_LABELS[updated.status]}`, id);
    } else {
      await this.log('updated', `Editó «${updated.title}»`, id);
    }
    return { ok: true, id };
  }

  moveTask(id: string, status: Status): Promise<Result> {
    return this.updateTask(id, { status });
  }

  /** Completar = mover a «Hecho». Reabrir = volver a «Por hacer». */
  toggleComplete(id: string): Promise<Result> {
    const task = this.data.tasks.find((t) => t.id === id);
    if (!task) return Promise.resolve({ ok: false, error: 'La tarea ya no existe.' });
    return this.updateTask(id, { status: task.status === 'done' ? 'backlog' : 'done' });
  }

  async deleteTask(id: string): Promise<Result> {
    const task = this.data.tasks.find((t) => t.id === id);
    if (!task) return { ok: false, error: 'La tarea ya no existe.' };
    const reminderIds = this.data.reminders.filter((r) => r.taskId === id).map((r) => r.id);
    await this.db.deleteMany('tasks', [id]);
    await this.db.deleteMany('reminders', reminderIds);
    this.emit({
      tasks: this.data.tasks.filter((t) => t.id !== id),
      reminders: this.data.reminders.filter((r) => r.taskId !== id),
    });
    await this.log('deleted', `Eliminó «${task.title}»`, null);
    return { ok: true };
  }

  private nextPosition(): number {
    return this.data.tasks.reduce((max, t) => Math.max(max, t.position), -1) + 1;
  }

  // ---------- listas ----------
  async createList(name: string, description: string): Promise<Result> {
    const fieldErrors = validateList(name, description);
    if (this.data.lists.some((l) => l.name.trim().toLowerCase() === name.trim().toLowerCase())) {
      fieldErrors.name = 'Ya existe una lista con ese nombre.';
    }
    if (hasErrors(fieldErrors)) return { ok: false, error: 'Revisa los campos marcados.', fieldErrors };
    const list: TaskList = { id: createId(), name: name.trim(), description: description.trim(), createdAt: this.now().toISOString() };
    await this.db.put('lists', list);
    this.emit({ lists: [...this.data.lists, list] });
    await this.log('list', `Creó la lista «${list.name}»`, null);
    return { ok: true, id: list.id };
  }

  async updateList(id: string, name: string, description: string): Promise<Result> {
    const current = this.data.lists.find((l) => l.id === id);
    if (!current) return { ok: false, error: 'La lista ya no existe.' };
    const fieldErrors = validateList(name, description);
    if (this.data.lists.some((l) => l.id !== id && l.name.trim().toLowerCase() === name.trim().toLowerCase())) {
      fieldErrors.name = 'Ya existe una lista con ese nombre.';
    }
    if (hasErrors(fieldErrors)) return { ok: false, error: 'Revisa los campos marcados.', fieldErrors };
    const updated = { ...current, name: name.trim(), description: description.trim() };
    await this.db.put('lists', updated);
    this.emit({ lists: this.data.lists.map((l) => (l.id === id ? updated : l)) });
    await this.log('list', `Editó la lista «${updated.name}»`, null);
    return { ok: true, id };
  }

  /** Borra la lista y sus tareas. Siempre debe quedar al menos una lista. */
  async deleteList(id: string): Promise<Result> {
    const list = this.data.lists.find((l) => l.id === id);
    if (!list) return { ok: false, error: 'La lista ya no existe.' };
    if (this.data.lists.length === 1) return { ok: false, error: 'Debe existir al menos una lista.' };
    const taskIds = new Set(this.data.tasks.filter((t) => t.listId === id).map((t) => t.id));
    const reminderIds = this.data.reminders.filter((r) => taskIds.has(r.taskId)).map((r) => r.id);
    await this.db.deleteMany('tasks', [...taskIds]);
    await this.db.deleteMany('reminders', reminderIds);
    await this.db.deleteMany('lists', [id]);
    this.emit({
      lists: this.data.lists.filter((l) => l.id !== id),
      tasks: this.data.tasks.filter((t) => !taskIds.has(t.id)),
      reminders: this.data.reminders.filter((r) => !taskIds.has(r.taskId)),
    });
    await this.log('list', `Eliminó la lista «${list.name}» (${taskIds.size} tareas)`, null);
    return { ok: true };
  }

  // ---------- recordatorios ----------
  /** Genera los avisos que correspondan. Devuelve los nuevos (para notificar). */
  async checkReminders(): Promise<Reminder[]> {
    const created = computeNewReminders(this.data.tasks, this.data.reminders, this.data.settings.reminders, this.now(), createId);
    if (created.length === 0) return [];
    await this.db.putMany('reminders', created);
    this.emit({ reminders: [...created, ...this.data.reminders] });
    return created;
  }

  async markReminderRead(id: string): Promise<void> {
    const r = this.data.reminders.find((x) => x.id === id);
    if (!r || r.readAt) return;
    const updated = { ...r, readAt: this.now().toISOString() };
    await this.db.put('reminders', updated);
    this.emit({ reminders: this.data.reminders.map((x) => (x.id === id ? updated : x)) });
  }

  async markAllRemindersRead(): Promise<void> {
    const ts = this.now().toISOString();
    const changed = this.data.reminders.filter((r) => !r.readAt).map((r) => ({ ...r, readAt: ts }));
    await this.db.putMany('reminders', changed);
    const byId = new Map(changed.map((r) => [r.id, r]));
    this.emit({ reminders: this.data.reminders.map((r) => byId.get(r.id) ?? r) });
  }

  // ---------- ajustes ----------
  async updateSettings(patch: Partial<Settings>): Promise<Result> {
    const next: Settings = {
      ...this.data.settings,
      ...patch,
      reminders: { ...this.data.settings.reminders, ...patch.reminders },
    };
    if (next.userName.trim().length < 1 || next.userName.length > 40) return { ok: false, error: 'El nombre debe tener entre 1 y 40 caracteres.' };
    if (next.workspaceName.trim().length < 1 || next.workspaceName.length > 60) return { ok: false, error: 'El nombre del espacio debe tener entre 1 y 60 caracteres.' };
    next.userName = next.userName.trim();
    next.workspaceName = next.workspaceName.trim();
    await this.db.setMeta(SETTINGS_KEY, next);
    this.emit({ settings: next });
    return { ok: true };
  }

  // ---------- copia de seguridad ----------
  exportBackup(): string {
    const { lists, tasks, reminders, activity, settings } = this.data;
    return JSON.stringify({ app: 'taskify-desk', version: 1, exportedAt: this.now().toISOString(), lists, tasks, reminders, activity, settings }, null, 2);
  }

  /** Sustituye todos los datos por los de la copia. Valida la estructura antes de borrar nada. */
  async importBackup(json: string): Promise<Result> {
    let parsed: unknown;
    try {
      parsed = JSON.parse(json);
    } catch {
      return { ok: false, error: 'El archivo no es un JSON válido.' };
    }
    const backup = parsed as Partial<AppData> & { app?: string };
    if (backup?.app !== 'taskify-desk' || !Array.isArray(backup.lists) || !Array.isArray(backup.tasks)) {
      return { ok: false, error: 'El archivo no es una copia de Taskify Desk.' };
    }
    const listIds = new Set(backup.lists.map((l) => l?.id));
    const validTasks = backup.tasks.every(
      (t) =>
        typeof t?.id === 'string' &&
        typeof t.title === 'string' &&
        listIds.has(t.listId) &&
        STATUSES.includes(t.status) &&
        PRIORITIES.includes(t.priority),
    );
    if (backup.lists.length === 0 || !validTasks) return { ok: false, error: 'La copia contiene datos incompletos o no válidos.' };

    await this.db.clearAll();
    await this.db.putMany('lists', backup.lists);
    await this.db.putMany('tasks', backup.tasks);
    await this.db.putMany('reminders', Array.isArray(backup.reminders) ? backup.reminders : []);
    await this.db.putMany('activity', Array.isArray(backup.activity) ? backup.activity : []);
    await this.db.setMeta(SETTINGS_KEY, { ...DEFAULT_SETTINGS, ...backup.settings });
    await this.db.setMeta(SEEDED_KEY, true);
    await this.reload();
    await this.log('list', 'Restauró una copia de seguridad', null);
    return { ok: true };
  }

  /** Borra todo y vuelve a cargar los datos de demostración. */
  async resetToDemo(): Promise<void> {
    await this.db.clearAll();
    await this.writeDemo();
    await this.reload();
  }
}
