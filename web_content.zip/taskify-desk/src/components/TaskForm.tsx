import { useCallback, useState, type FormEvent, type ReactNode } from 'react';
import { assigneesOf } from '../domain/queries';
import { PRIORITIES, PRIORITY_LABELS, STATUSES, STATUS_LABELS, type Priority, type Status, type Task } from '../domain/types';
import type { FieldErrors } from '../domain/validation';
import { useApp } from '../hooks/AppContext';
import { fromLocalInput, toLocalInput } from '../utils/format';
import { ConfirmDialog, Field, Modal } from './ui';

interface TaskFormProps {
  task?: Task;
  defaults?: { listId?: string; status?: Status };
  onClose: () => void;
}

export function TaskFormModal({ task, defaults, onClose }: TaskFormProps) {
  const { store, data, notify } = useApp();
  const [title, setTitle] = useState(task?.title ?? '');
  const [description, setDescription] = useState(task?.description ?? '');
  const [listId, setListId] = useState(task?.listId ?? defaults?.listId ?? data.lists[0]?.id ?? '');
  const [status, setStatus] = useState<Status>(task?.status ?? defaults?.status ?? 'backlog');
  const [priority, setPriority] = useState<Priority>(task?.priority ?? 'medium');
  const [assignee, setAssignee] = useState(task?.assignee ?? '');
  const [due, setDue] = useState(toLocalInput(task?.dueDate ?? null));
  const [errors, setErrors] = useState<FieldErrors>({});
  const [formError, setFormError] = useState('');
  const [saving, setSaving] = useState(false);

  async function submit(e: FormEvent) {
    e.preventDefault();
    setSaving(true);
    setFormError('');
    const payload = { title, description, listId, status, priority, assignee, dueDate: fromLocalInput(due) };
    const result = task ? await store.updateTask(task.id, payload) : await store.createTask(payload);
    setSaving(false);
    if (!result.ok) {
      setErrors(result.fieldErrors ?? {});
      setFormError(result.error);
      return;
    }
    notify(task ? 'Tarea actualizada' : 'Tarea creada');
    onClose();
  }

  const people = assigneesOf(data.tasks);

  return (
    <Modal
      title={task ? 'Editar tarea' : 'Nueva tarea'}
      onClose={onClose}
      footer={
        <>
          <button type="button" className="btn" onClick={onClose}>
            Cancelar
          </button>
          <button type="submit" form="task-form" className="btn primary" disabled={saving}>
            {saving ? 'Guardando…' : task ? 'Guardar cambios' : 'Crear tarea'}
          </button>
        </>
      }
    >
      <form id="task-form" className="form-grid" onSubmit={submit} noValidate>
        {formError && (
          <div className="alert alert-error" role="alert">
            {formError}
          </div>
        )}
        <Field label="Título *" htmlFor="tf-title" error={errors.title}>
          <input
            id="tf-title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            maxLength={120}
            autoFocus
            required
            aria-invalid={!!errors.title}
            aria-describedby={errors.title ? 'tf-title-error' : undefined}
          />
        </Field>
        <Field label="Descripción" htmlFor="tf-desc" error={errors.description}>
          <textarea id="tf-desc" rows={3} value={description} onChange={(e) => setDescription(e.target.value)} maxLength={2000} />
        </Field>
        <div className="form-row">
          <Field label="Lista" htmlFor="tf-list" error={errors.listId}>
            <select id="tf-list" value={listId} onChange={(e) => setListId(e.target.value)}>
              {data.lists.map((l) => (
                <option key={l.id} value={l.id}>
                  {l.name}
                </option>
              ))}
            </select>
          </Field>
          <Field label="Estado (columna)" htmlFor="tf-status" error={errors.status}>
            <select id="tf-status" value={status} onChange={(e) => setStatus(e.target.value as Status)}>
              {STATUSES.map((s) => (
                <option key={s} value={s}>
                  {STATUS_LABELS[s]}
                </option>
              ))}
            </select>
          </Field>
        </div>
        <div className="form-row">
          <Field label="Prioridad" htmlFor="tf-priority" error={errors.priority}>
            <select id="tf-priority" value={priority} onChange={(e) => setPriority(e.target.value as Priority)}>
              {PRIORITIES.map((p) => (
                <option key={p} value={p}>
                  {PRIORITY_LABELS[p]}
                </option>
              ))}
            </select>
          </Field>
          <Field label="Fecha límite" htmlFor="tf-due" error={errors.dueDate}>
            <input id="tf-due" type="datetime-local" value={due} onChange={(e) => setDue(e.target.value)} />
          </Field>
        </div>
        <Field label="Responsable" htmlFor="tf-assignee" error={errors.assignee} hint="Escribe un nombre o elige uno usado antes.">
          <input id="tf-assignee" list="tf-people" value={assignee} onChange={(e) => setAssignee(e.target.value)} maxLength={60} />
          <datalist id="tf-people">
            {people.map((p) => (
              <option key={p} value={p} />
            ))}
          </datalist>
        </Field>
      </form>
    </Modal>
  );
}

/** Centraliza crear/editar/eliminar para reutilizarlo en todas las pantallas. */
export function useTaskEditor(): {
  openNew: (defaults?: { listId?: string; status?: Status }) => void;
  openEdit: (task: Task) => void;
  askDelete: (task: Task) => void;
  dialogs: ReactNode;
} {
  const { store, notify } = useApp();
  const [form, setForm] = useState<{ task?: Task; defaults?: { listId?: string; status?: Status } } | null>(null);
  const [deleting, setDeleting] = useState<Task | null>(null);

  const openNew = useCallback((defaults?: { listId?: string; status?: Status }) => setForm({ defaults }), []);
  const openEdit = useCallback((task: Task) => setForm({ task }), []);
  const askDelete = useCallback((task: Task) => setDeleting(task), []);
  const closeForm = useCallback(() => setForm(null), []);
  const closeDelete = useCallback(() => setDeleting(null), []);

  const dialogs = (
    <>
      {form && <TaskFormModal task={form.task} defaults={form.defaults} onClose={closeForm} />}
      {deleting && (
        <ConfirmDialog
          title="Eliminar tarea"
          message={`¿Seguro que quieres eliminar «${deleting.title}»? Esta acción no se puede deshacer.`}
          onCancel={closeDelete}
          onConfirm={async () => {
            const res = await store.deleteTask(deleting.id);
            setDeleting(null);
            notify(res.ok ? 'Tarea eliminada' : res.error, res.ok ? 'success' : 'error');
          }}
        />
      )}
    </>
  );
  return { openNew, openEdit, askDelete, dialogs };
}
