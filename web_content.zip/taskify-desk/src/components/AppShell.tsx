import type { ReactNode } from 'react';
import { useApp } from '../hooks/AppContext';
import { href } from '../hooks/router';
import { isDarkActive } from '../hooks/useTheme';
import { initials } from '../utils/format';
import { IconBell, IconBoard, IconDashboard, IconLists, IconMoon, IconOffline, IconSettings, IconSun, IconTasks } from './Icons';
import { Toasts } from './ui';

const NAV = [
  { path: '/', label: 'Panel', icon: IconDashboard },
  { path: '/tareas', label: 'Mis tareas', icon: IconTasks },
  { path: '/listas', label: 'Listas', icon: IconLists },
  { path: '/tablero', label: 'Tablero', icon: IconBoard },
  { path: '/avisos', label: 'Avisos', icon: IconBell },
  { path: '/ajustes', label: 'Ajustes', icon: IconSettings },
];

export function AppShell({ path, title, children }: { path: string; title: string; children: ReactNode }) {
  const { data, store, online } = useApp();
  const unread = data.reminders.filter((r) => !r.readAt).length;
  const dark = isDarkActive(data.settings.theme);

  return (
    <div className="shell">
      <a className="skip-link" href="#main">
        Saltar al contenido
      </a>
      <aside className="sidebar" aria-label="Navegación principal">
        <div className="brand">
          <img src="./icons/icon.svg" alt="" width={34} height={34} />
          <span>Taskify Desk</span>
        </div>
        <nav>
          {NAV.map(({ path: p, label, icon: Icon }) => (
            <a key={p} href={href(p)} className={`nav-link ${path === p ? 'active' : ''}`} aria-current={path === p ? 'page' : undefined}>
              <Icon />
              <span>{label}</span>
              {p === '/avisos' && unread > 0 && <span className="count-pill">{unread}</span>}
            </a>
          ))}
        </nav>
        <div className="sidebar-foot">
          Espacio: <strong>{data.settings.workspaceName}</strong>
        </div>
      </aside>

      <div className="main-col">
        <header className="topbar">
          <h1 className="page-title">{title}</h1>
          {!online && (
            <span className="offline-pill" title="Sin conexión. Los datos se guardan en este dispositivo.">
              <IconOffline size={16} /> Sin conexión
            </span>
          )}
          <div className="topbar-actions">
            <button
              type="button"
              className="icon-btn"
              aria-label={dark ? 'Cambiar a modo claro' : 'Cambiar a modo oscuro'}
              onClick={() => store.updateSettings({ theme: dark ? 'light' : 'dark' })}
            >
              {dark ? <IconSun /> : <IconMoon />}
            </button>
            <a href={href('/avisos')} className="icon-btn" aria-label={`Avisos, ${unread} sin leer`}>
              <IconBell />
              {unread > 0 && <span className="dot" aria-hidden="true" />}
            </a>
            <a href={href('/ajustes')} className="avatar-btn" aria-label={`Perfil de ${data.settings.userName}`}>
              <span className="avatar">{initials(data.settings.userName)}</span>
              <span className="avatar-name">{data.settings.userName}</span>
            </a>
          </div>
        </header>
        <main id="main" className="content" tabIndex={-1}>
          {children}
        </main>
      </div>

      <nav className="bottom-nav" aria-label="Navegación principal (móvil)">
        {NAV.map(({ path: p, label, icon: Icon }) => (
          <a key={p} href={href(p)} className={path === p ? 'active' : ''} aria-current={path === p ? 'page' : undefined}>
            <span className="bn-icon">
              <Icon size={22} />
              {p === '/avisos' && unread > 0 && <span className="dot" aria-hidden="true" />}
            </span>
            <span>{label}</span>
          </a>
        ))}
      </nav>
      <Toasts />
    </div>
  );
}
