import { useEffect, useId, useRef, type ReactNode } from 'react';
import { isOverdue, isUpcoming } from '../domain/queries';
import { PRIORITY_LABELS, type Priority, type Task } from '../domain/types';
import { useApp } from '../hooks/AppContext';
import { formatDate, formatRelative } from '../utils/format';
import { IconCalendar, IconClose } from './Icons';

export function Modal({
  title,
  onClose,
  children,
  footer,
  size = 'md',
}: {
  title: string;
  onClose: () => void;
  children: ReactNode;
  footer?: ReactNode;
  size?: 'sm' | 'md';
}) {
  const ref = useRef<HTMLDialogElement>(null);
  const titleId = useId();
  useEffect(() => {
    const dialog = ref.current;
    if (!dialog) return;
    if (!dialog.open) dialog.showModal();
    const onCancel = (e: Event) => {
      e.preventDefault();
      onClose();
    };
    dialog.addEventListener('cancel', onCancel);
    return () => dialog.removeEventListener('cancel', onCancel);
  }, [onClose]);
  return (
    <dialog ref={ref} className={`modal modal-${size}`} aria-labelledby={titleId}>
      <div className="modal-head">
        <h2 id={titleId}>{title}</h2>
        <button type="button" className="icon-btn ghost" onClick={onClose} aria-label="Cerrar">
          <IconClose />
        </button>
      </div>
      <div className="modal-body">{children}</div>
      {footer && <div className="modal-foot">{footer}</div>}
    </dialog>
  );
}

export function ConfirmDialog({
  title,
  message,
  confirmLabel = 'Eliminar',
  danger = true,
  onConfirm,
  onCancel,
}: {
  title: string;
  message: ReactNode;
  confirmLabel?: string;
  danger?: boolean;
  onConfirm: () => void;
  onCancel: () => void;
}) {
  return (
    <Modal
      title={title}
      onClose={onCancel}
      size="sm"
      footer={
        <>
          <button type="button" className="btn" onClick={onCancel}>
            Cancelar
          </button>
          <button type="button" className={`btn ${danger ? 'danger' : 'primary'}`} onClick={onConfirm}>
            {confirmLabel}
          </button>
        </>
      }
    >
      <p className="muted">{message}</p>
    </Modal>
  );
}

export function Toasts() {
  const { toasts, dismissToast } = useApp();
  return (
    <div className="toasts" role="status" aria-live="polite">
      {toasts.map((t) => (
        <div key={t.id} className={`toast toast-${t.kind}`}>
          <span>{t.message}</span>
          <button type="button" className="icon-btn ghost small" onClick={() => dismissToast(t.id)} aria-label="Cerrar aviso">
            <IconClose size={16} />
          </button>
        </div>
      ))}
    </div>
  );
}

export function PriorityBadge({ priority }: { priority: Priority }) {
  return <span className={`badge prio-${priority}`}>{PRIORITY_LABELS[priority]}</span>;
}

export function DueBadge({ task }: { task: Task }) {
  const { now } = useApp();
  if (!task.dueDate) return null;
  if (task.status === 'done') {
    return (
      <span className="due">
        <IconCalendar size={14} /> {formatDate(task.dueDate)}
      </span>
    );
  }
  if (isOverdue(task, now)) return <span className="badge due-overdue">Atrasada · {formatRelative(task.dueDate, now)}</span>;
  if (isUpcoming(task, now)) return <span className="badge due-soon">Vence {formatRelative(task.dueDate, now)}</span>;
  return (
    <span className="due">
      <IconCalendar size={14} /> {formatDate(task.dueDate)}
    </span>
  );
}

export function EmptyState({ title, children, action }: { title: string; children?: ReactNode; action?: ReactNode }) {
  return (
    <div className="empty">
      <p className="empty-title">{title}</p>
      {children && <p className="muted">{children}</p>}
      {action}
    </div>
  );
}

export function Field({
  label,
  error,
  hint,
  children,
  htmlFor,
}: {
  label: string;
  error?: string;
  hint?: string;
  htmlFor: string;
  children: ReactNode;
}) {
  return (
    <div className={`field ${error ? 'has-error' : ''}`}>
      <label htmlFor={htmlFor}>{label}</label>
      {children}
      {hint && !error && <small className="muted">{hint}</small>}
      {error && (
        <small className="error-text" id={`${htmlFor}-error`}>
          {error}
        </small>
      )}
    </div>
  );
}
