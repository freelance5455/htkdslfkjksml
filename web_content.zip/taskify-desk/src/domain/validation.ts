import { PRIORITIES, STATUSES, type Priority, type Status } from './types';

export type FieldErrors = Partial<Record<string, string>>;

export interface TaskFormValues {
  title: string;
  description: string;
  listId: string;
  status: string;
  priority: string;
  assignee: string;
  dueDate: string | null;
}

export function validateTask(values: TaskFormValues): FieldErrors {
  const errors: FieldErrors = {};
  const title = values.title.trim();
  if (title.length < 3) errors.title = 'El título debe tener al menos 3 caracteres.';
  else if (title.length > 120) errors.title = 'El título no puede superar los 120 caracteres.';
  if (values.description.length > 2000) errors.description = 'La descripción no puede superar los 2000 caracteres.';
  if (!values.listId) errors.listId = 'Elige una lista.';
  if (!STATUSES.includes(values.status as Status)) errors.status = 'Estado no válido.';
  if (!PRIORITIES.includes(values.priority as Priority)) errors.priority = 'Prioridad no válida.';
  if (values.assignee.trim().length > 60) errors.assignee = 'El responsable no puede superar los 60 caracteres.';
  if (values.dueDate && Number.isNaN(Date.parse(values.dueDate))) errors.dueDate = 'Fecha no válida.';
  return errors;
}

export function validateList(name: string, description: string): FieldErrors {
  const errors: FieldErrors = {};
  const n = name.trim();
  if (n.length < 2) errors.name = 'El nombre debe tener al menos 2 caracteres.';
  else if (n.length > 60) errors.name = 'El nombre no puede superar los 60 caracteres.';
  if (description.length > 300) errors.description = 'La descripción no puede superar los 300 caracteres.';
  return errors;
}

export function hasErrors(errors: FieldErrors): boolean {
  return Object.values(errors).some(Boolean);
}
