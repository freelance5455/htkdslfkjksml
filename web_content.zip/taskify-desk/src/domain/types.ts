export const STATUSES = ['backlog', 'analysis', 'development', 'qa', 'done'] as const;
export type Status = (typeof STATUSES)[number];

export const PRIORITIES = ['low', 'medium', 'high', 'urgent'] as const;
export type Priority = (typeof PRIORITIES)[number];

export const STATUS_LABELS: Record<Status, string> = {
  backlog: 'Por hacer',
  analysis: 'Análisis / Diseño',
  development: 'Desarrollo',
  qa: 'Pruebas / QA',
  done: 'Hecho',
};

export const PRIORITY_LABELS: Record<Priority, string> = {
  low: 'Baja',
  medium: 'Media',
  high: 'Alta',
  urgent: 'Urgente',
};

/** Peso para ordenar: mayor = más importante. */
export const PRIORITY_WEIGHT: Record<Priority, number> = { low: 1, medium: 2, high: 3, urgent: 4 };

/** Límites WIP por columna. Las columnas sin entrada no tienen límite. */
export const WIP_LIMITS: Partial<Record<Status, number>> = { development: 2, qa: 1 };

export interface TaskList {
  id: string;
  name: string;
  description: string;
  createdAt: string; // ISO UTC
}

export interface Task {
  id: string;
  listId: string;
  title: string;
  description: string;
  status: Status;
  priority: Priority;
  assignee: string;
  dueDate: string | null; // ISO UTC
  completedAt: string | null;
  position: number;
  createdAt: string;
  updatedAt: string;
}

export type ReminderType = 'due_soon' | 'overdue';

export interface Reminder {
  id: string;
  taskId: string;
  type: ReminderType;
  /** Fecha límite de la tarea cuando se generó el aviso: evita duplicados y permite volver a avisar si cambia. */
  dueDateSnapshot: string;
  createdAt: string;
  readAt: string | null;
}

export type ActivityAction = 'created' | 'updated' | 'moved' | 'completed' | 'reopened' | 'deleted' | 'list';

export interface Activity {
  id: string;
  action: ActivityAction;
  detail: string;
  taskId: string | null;
  createdAt: string;
}

export type Theme = 'light' | 'dark' | 'system';

export interface ReminderSettings {
  enabled: boolean;
  hoursBefore: number;
  notifyOverdue: boolean;
  systemNotifications: boolean;
}

export interface Settings {
  userName: string;
  theme: Theme;
  workspaceName: string;
  workspaceDescription: string;
  reminders: ReminderSettings;
}

export const DEFAULT_SETTINGS: Settings = {
  userName: 'Usuario',
  theme: 'system',
  workspaceName: 'Mi oficina',
  workspaceDescription: '',
  reminders: { enabled: true, hoursBefore: 24, notifyOverdue: true, systemNotifications: false },
};

export const REMINDER_HOUR_OPTIONS = [1, 4, 24, 48] as const;

/** Ventana (horas) para considerar una tarea "próxima a vencer" en el panel. */
export const UPCOMING_WINDOW_HOURS = 72;

export interface TaskInput {
  listId: string;
  title: string;
  description?: string;
  status?: Status;
  priority?: Priority;
  assignee?: string;
  dueDate?: string | null;
}

export interface AppData {
  lists: TaskList[];
  tasks: Task[];
  reminders: Reminder[];
  activity: Activity[];
  settings: Settings;
}
