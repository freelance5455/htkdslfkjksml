import { STATUS_LABELS, WIP_LIMITS, type Status, type Task } from './types';

export interface WipCheck {
  ok: boolean;
  message?: string;
}

/** Número de tarjetas de una lista en una columna, excluyendo opcionalmente una tarea. */
export function countInColumn(tasks: Task[], listId: string, status: Status, excludeTaskId?: string): number {
  return tasks.filter((t) => t.listId === listId && t.status === status && t.id !== excludeTaskId).length;
}

export function wipMessage(status: Status): string {
  const limit = WIP_LIMITS[status];
  return `${STATUS_LABELS[status]} ha alcanzado su límite WIP (${limit}). Termina o mueve una tarjeta antes de añadir otra.`;
}

/**
 * Comprueba si una tarea puede entrar en la columna `target` de su lista.
 * `taskId` es undefined al crear una tarea nueva.
 * Mover dentro de la misma columna siempre está permitido.
 */
export function checkWip(tasks: Task[], listId: string, target: Status, taskId?: string): WipCheck {
  const limit = WIP_LIMITS[target];
  if (limit === undefined) return { ok: true };
  if (taskId) {
    const current = tasks.find((t) => t.id === taskId);
    if (current && current.listId === listId && current.status === target) return { ok: true };
  }
  if (countInColumn(tasks, listId, target, taskId) >= limit) return { ok: false, message: wipMessage(target) };
  return { ok: true };
}
