import { isDone } from './queries';
import type { Reminder, ReminderSettings, ReminderType, Task } from './types';

const HOUR = 3_600_000;

export function reminderKey(taskId: string, type: ReminderType, dueDate: string): string {
  return `${taskId}|${type}|${dueDate}`;
}

/** Tipo de aviso que corresponde ahora a una tarea, o null si no corresponde ninguno. */
export function reminderTypeFor(task: Task, settings: ReminderSettings, now: Date): ReminderType | null {
  if (!settings.enabled || isDone(task) || !task.dueDate) return null;
  const due = Date.parse(task.dueDate);
  const t = now.getTime();
  if (due < t) return settings.notifyOverdue ? 'overdue' : null;
  if (due - t <= settings.hoursBefore * HOUR) return 'due_soon';
  return null;
}

/**
 * Devuelve SOLO los avisos nuevos que hay que crear.
 * Un aviso es único por (tarea, tipo, fecha límite): repetir la comprobación no duplica,
 * y si la fecha límite cambia se puede volver a avisar.
 */
export function computeNewReminders(
  tasks: Task[],
  existing: Reminder[],
  settings: ReminderSettings,
  now: Date,
  makeId: () => string,
): Reminder[] {
  const known = new Set(existing.map((r) => reminderKey(r.taskId, r.type, r.dueDateSnapshot)));
  const created: Reminder[] = [];
  for (const task of tasks) {
    const type = reminderTypeFor(task, settings, now);
    if (!type || !task.dueDate) continue;
    const key = reminderKey(task.id, type, task.dueDate);
    if (known.has(key)) continue;
    known.add(key);
    created.push({
      id: makeId(),
      taskId: task.id,
      type,
      dueDateSnapshot: task.dueDate,
      createdAt: now.toISOString(),
      readAt: null,
    });
  }
  return created;
}

export interface ScheduledNotification {
  taskId: string;
  type: ReminderType;
  at: Date;
  title: string;
  body: string;
}

/**
 * Notificaciones del sistema que se programan por adelantado (Android):
 * una "próxima a vencer" y, si procede, una "atrasada" justo al vencer.
 */
export function computeNotificationSchedule(tasks: Task[], settings: ReminderSettings, now: Date): ScheduledNotification[] {
  if (!settings.enabled || !settings.systemNotifications) return [];
  const out: ScheduledNotification[] = [];
  for (const task of tasks) {
    if (isDone(task) || !task.dueDate) continue;
    const due = Date.parse(task.dueDate);
    const soonAt = due - settings.hoursBefore * HOUR;
    if (soonAt > now.getTime()) {
      out.push({ taskId: task.id, type: 'due_soon', at: new Date(soonAt), title: 'Tarea próxima a vencer', body: task.title });
    }
    if (settings.notifyOverdue && due > now.getTime()) {
      out.push({ taskId: task.id, type: 'overdue', at: new Date(due), title: 'Tarea atrasada', body: task.title });
    }
  }
  return out.sort((a, b) => a.at.getTime() - b.at.getTime());
}

/** Id numérico estable (requerido por las notificaciones locales de Android). */
export function notificationNumericId(taskId: string, type: ReminderType): number {
  let hash = 0;
  const text = `${taskId}:${type}`;
  for (let i = 0; i < text.length; i++) hash = (Math.imul(31, hash) + text.charCodeAt(i)) | 0;
  return Math.abs(hash) % 2_000_000_000;
}
