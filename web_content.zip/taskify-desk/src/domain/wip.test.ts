import { describe, expect, it } from 'vitest';
import { makeTask } from '../test/factories';
import { checkWip, countInColumn } from './wip';

describe('límites WIP', () => {
  it('permite entrar en Desarrollo con 1 tarjeta y bloquea con 2', () => {
    const one = [makeTask({ status: 'development' })];
    expect(checkWip(one, 'L1', 'development').ok).toBe(true);
    const two = [...one, makeTask({ status: 'development' })];
    const result = checkWip(two, 'L1', 'development');
    expect(result.ok).toBe(false);
    expect(result.message).toContain('Desarrollo ha alcanzado su límite WIP (2)');
  });

  it('bloquea Pruebas / QA con 1 tarjeta', () => {
    const tasks = [makeTask({ status: 'qa' })];
    const result = checkWip(tasks, 'L1', 'qa');
    expect(result.ok).toBe(false);
    expect(result.message).toContain('Pruebas / QA ha alcanzado su límite WIP (1)');
  });

  it('no limita Por hacer, Análisis ni Hecho', () => {
    const tasks = Array.from({ length: 10 }, () => makeTask({ status: 'done' }));
    expect(checkWip(tasks, 'L1', 'done').ok).toBe(true);
    expect(checkWip(tasks, 'L1', 'backlog').ok).toBe(true);
    expect(checkWip(tasks, 'L1', 'analysis').ok).toBe(true);
  });

  it('permite mantener una tarjeta en su columna llena', () => {
    const a = makeTask({ status: 'qa' });
    expect(checkWip([a], 'L1', 'qa', a.id).ok).toBe(true);
  });

  it('cuenta los límites por lista', () => {
    const tasks = [makeTask({ status: 'qa', listId: 'L1' })];
    expect(checkWip(tasks, 'L2', 'qa').ok).toBe(true);
    expect(countInColumn(tasks, 'L1', 'qa')).toBe(1);
  });

  it('bloquea mover a QA otra tarjeta cuando ya está llena', () => {
    const inQa = makeTask({ status: 'qa' });
    const dev = makeTask({ status: 'development' });
    expect(checkWip([inQa, dev], 'L1', 'qa', dev.id).ok).toBe(false);
  });
});
