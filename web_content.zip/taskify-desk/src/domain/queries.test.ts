import { describe, expect, it } from 'vitest';
import { makeTask } from '../test/factories';
import { EMPTY_FILTER, computeStats, filterTasks, isOverdue, isUpcoming } from './queries';

const now = new Date('2026-10-13T12:00:00.000Z');
const inHours = (h: number) => new Date(now.getTime() + h * 3_600_000).toISOString();

describe('consultas de tareas', () => {
  it('detecta atrasadas y próximas, ignorando las hechas', () => {
    expect(isOverdue(makeTask({ dueDate: inHours(-1) }), now)).toBe(true);
    expect(isOverdue(makeTask({ dueDate: inHours(-1), status: 'done' }), now)).toBe(false);
    expect(isUpcoming(makeTask({ dueDate: inHours(10) }), now)).toBe(true);
    expect(isUpcoming(makeTask({ dueDate: inHours(100) }), now)).toBe(false);
    expect(isUpcoming(makeTask({ dueDate: null }), now)).toBe(false);
  });

  it('calcula el resumen del panel', () => {
    const tasks = [
      makeTask({ status: 'done' }),
      makeTask({ dueDate: inHours(-2) }),
      makeTask({ dueDate: inHours(5), status: 'development' }),
      makeTask(),
    ];
    const s = computeStats(tasks, now);
    expect(s).toMatchObject({ total: 4, pending: 3, done: 1, overdue: 1, upcoming: 1 });
    expect(s.byStatus.development).toBe(1);
  });

  it('busca sin distinguir mayúsculas ni tildes', () => {
    const tasks = [makeTask({ title: 'Revisión de diseño' }), makeTask({ title: 'Otra cosa' })];
    const result = filterTasks(tasks, { ...EMPTY_FILTER, query: 'REVISION' }, now);
    expect(result.map((t) => t.title)).toEqual(['Revisión de diseño']);
  });

  it('filtra por estado, prioridad y responsable', () => {
    const tasks = [
      makeTask({ priority: 'high', assignee: 'Ana' }),
      makeTask({ priority: 'high', assignee: 'Luis', status: 'done' }),
      makeTask({ priority: 'low', assignee: 'Ana' }),
    ];
    const result = filterTasks(tasks, { ...EMPTY_FILTER, state: 'pending', priority: 'high', assignee: 'Ana' }, now);
    expect(result).toHaveLength(1);
  });

  it('ordena por fecha (sin fecha al final) y por prioridad', () => {
    const a = makeTask({ title: 'A', dueDate: inHours(20), priority: 'low' });
    const b = makeTask({ title: 'B', dueDate: null, priority: 'urgent' });
    const c = makeTask({ title: 'C', dueDate: inHours(2), priority: 'medium' });
    expect(filterTasks([a, b, c], EMPTY_FILTER, now).map((t) => t.title)).toEqual(['C', 'A', 'B']);
    expect(filterTasks([a, b, c], { ...EMPTY_FILTER, sort: 'priority' }, now).map((t) => t.title)).toEqual(['B', 'C', 'A']);
  });
});
