import {
  PRIORITY_WEIGHT,
  STATUSES,
  UPCOMING_WINDOW_HOURS,
  type Priority,
  type Status,
  type Task,
} from './types';

const HOUR = 3_600_000;

export function isDone(task: Task): boolean {
  return task.status === 'done';
}

export function isOverdue(task: Task, now: Date): boolean {
  return !isDone(task) && task.dueDate !== null && Date.parse(task.dueDate) < now.getTime();
}

export function isUpcoming(task: Task, now: Date, windowHours = UPCOMING_WINDOW_HOURS): boolean {
  if (isDone(task) || task.dueDate === null) return false;
  const due = Date.parse(task.dueDate);
  return due >= now.getTime() && due <= now.getTime() + windowHours * HOUR;
}

export interface Stats {
  total: number;
  pending: number;
  done: number;
  upcoming: number;
  overdue: number;
  byStatus: Record<Status, number>;
}

export function computeStats(tasks: Task[], now: Date): Stats {
  const byStatus = Object.fromEntries(STATUSES.map((s) => [s, 0])) as Record<Status, number>;
  let upcoming = 0;
  let overdue = 0;
  for (const t of tasks) {
    byStatus[t.status] += 1;
    if (isUpcoming(t, now)) upcoming += 1;
    if (isOverdue(t, now)) overdue += 1;
  }
  return { total: tasks.length, pending: tasks.length - byStatus.done, done: byStatus.done, upcoming, overdue, byStatus };
}

export type StateFilter = 'all' | 'pending' | 'done' | 'overdue' | 'upcoming';
export type SortKey = 'dueDate' | 'priority' | 'status' | 'createdAt' | 'title';

export interface TaskFilter {
  query: string;
  listId: string; // '' = todas
  state: StateFilter;
  priority: Priority | '';
  assignee: string; // '' = todos
  sort: SortKey;
}

export const EMPTY_FILTER: TaskFilter = { query: '', listId: '', state: 'all', priority: '', assignee: '', sort: 'dueDate' };

function normalize(text: string): string {
  return text.toLocaleLowerCase('es').normalize('NFD').replace(/[̀-ͯ]/g, '');
}

export function compareTasks(a: Task, b: Task, sort: SortKey): number {
  switch (sort) {
    case 'dueDate': {
      // Sin fecha al final
      const da = a.dueDate ? Date.parse(a.dueDate) : Number.POSITIVE_INFINITY;
      const db = b.dueDate ? Date.parse(b.dueDate) : Number.POSITIVE_INFINITY;
      if (da !== db) return da - db;
      break;
    }
    case 'priority': {
      const diff = PRIORITY_WEIGHT[b.priority] - PRIORITY_WEIGHT[a.priority];
      if (diff !== 0) return diff;
      break;
    }
    case 'status': {
      const diff = STATUSES.indexOf(a.status) - STATUSES.indexOf(b.status);
      if (diff !== 0) return diff;
      break;
    }
    case 'createdAt': {
      const diff = Date.parse(b.createdAt) - Date.parse(a.createdAt);
      if (diff !== 0) return diff;
      break;
    }
    case 'title':
      return a.title.localeCompare(b.title, 'es');
  }
  return a.title.localeCompare(b.title, 'es');
}

export function filterTasks(tasks: Task[], filter: TaskFilter, now: Date): Task[] {
  const q = normalize(filter.query.trim());
  return tasks
    .filter((t) => {
      if (filter.listId && t.listId !== filter.listId) return false;
      if (filter.priority && t.priority !== filter.priority) return false;
      if (filter.assignee && t.assignee !== filter.assignee) return false;
      switch (filter.state) {
        case 'pending':
          if (isDone(t)) return false;
          break;
        case 'done':
          if (!isDone(t)) return false;
          break;
        case 'overdue':
          if (!isOverdue(t, now)) return false;
          break;
        case 'upcoming':
          if (!isUpcoming(t, now)) return false;
          break;
      }
      if (q && !normalize(`${t.title} ${t.description} ${t.assignee}`).includes(q)) return false;
      return true;
    })
    .sort((a, b) => compareTasks(a, b, filter.sort));
}

export function assigneesOf(tasks: Task[]): string[] {
  return [...new Set(tasks.map((t) => t.assignee.trim()).filter(Boolean))].sort((a, b) => a.localeCompare(b, 'es'));
}
