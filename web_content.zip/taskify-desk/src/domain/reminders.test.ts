import { describe, expect, it } from 'vitest';
import { makeTask } from '../test/factories';
import { computeNewReminders, computeNotificationSchedule, notificationNumericId } from './reminders';
import { DEFAULT_SETTINGS } from './types';

const now = new Date('2026-10-13T12:00:00.000Z');
const inHours = (h: number) => new Date(now.getTime() + h * 3_600_000).toISOString();
let n = 0;
const id = () => `r${++n}`;
const settings = DEFAULT_SETTINGS.reminders; // 24 h de antelación

describe('recordatorios', () => {
  it('crea avisos de próxima y atrasada', () => {
    const tasks = [makeTask({ dueDate: inHours(3) }), makeTask({ dueDate: inHours(-3) }), makeTask({ dueDate: inHours(48) })];
    const created = computeNewReminders(tasks, [], settings, now, id);
    expect(created.map((r) => r.type).sort()).toEqual(['due_soon', 'overdue']);
  });

  it('no duplica avisos al repetir la comprobación', () => {
    const tasks = [makeTask({ dueDate: inHours(3) })];
    const first = computeNewReminders(tasks, [], settings, now, id);
    const second = computeNewReminders(tasks, first, settings, now, id);
    expect(first).toHaveLength(1);
    expect(second).toHaveLength(0);
  });

  it('vuelve a avisar si cambia la fecha límite', () => {
    const task = makeTask({ dueDate: inHours(3) });
    const first = computeNewReminders([task], [], settings, now, id);
    const moved = { ...task, dueDate: inHours(5) };
    expect(computeNewReminders([moved], first, settings, now, id)).toHaveLength(1);
  });

  it('ignora tareas hechas, sin fecha o con avisos desactivados', () => {
    const tasks = [makeTask({ dueDate: inHours(-1), status: 'done' }), makeTask({ dueDate: null })];
    expect(computeNewReminders(tasks, [], settings, now, id)).toHaveLength(0);
    const off = { ...settings, enabled: false };
    expect(computeNewReminders([makeTask({ dueDate: inHours(1) })], [], off, now, id)).toHaveLength(0);
  });

  it('respeta la antelación configurada', () => {
    const task = makeTask({ dueDate: inHours(3) });
    expect(computeNewReminders([task], [], { ...settings, hoursBefore: 1 }, now, id)).toHaveLength(0);
  });

  it('programa notificaciones del sistema solo en el futuro', () => {
    const s = { ...settings, systemNotifications: true };
    const schedule = computeNotificationSchedule([makeTask({ dueDate: inHours(30) }), makeTask({ dueDate: inHours(-5) })], s, now);
    expect(schedule.map((x) => x.type)).toEqual(['due_soon', 'overdue']);
    expect(schedule[0].at.toISOString()).toBe(inHours(6));
    expect(computeNotificationSchedule([makeTask({ dueDate: inHours(30) })], settings, now)).toHaveLength(0);
  });

  it('genera ids numéricos estables', () => {
    expect(notificationNumericId('abc', 'overdue')).toBe(notificationNumericId('abc', 'overdue'));
    expect(notificationNumericId('abc', 'overdue')).not.toBe(notificationNumericId('abc', 'due_soon'));
  });
});
