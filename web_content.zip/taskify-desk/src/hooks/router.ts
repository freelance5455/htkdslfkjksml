import { useEffect, useState } from 'react';

/** Enrutado por hash (#/tareas). Funciona sin servidor, sin conexión y dentro de Android. */
export interface Route {
  path: string;
  params: URLSearchParams;
}

function parse(): Route {
  const raw = window.location.hash.replace(/^#/, '') || '/';
  const [path, query = ''] = raw.split('?');
  return { path: path || '/', params: new URLSearchParams(query) };
}

export function useRoute(): Route {
  const [route, setRoute] = useState(parse);
  useEffect(() => {
    const onChange = () => setRoute(parse());
    window.addEventListener('hashchange', onChange);
    return () => window.removeEventListener('hashchange', onChange);
  }, []);
  return route;
}

export function navigate(path: string, params?: Record<string, string>): void {
  const query = params ? new URLSearchParams(Object.entries(params).filter(([, v]) => v)).toString() : '';
  window.location.hash = query ? `${path}?${query}` : path;
}

export function href(path: string, params?: Record<string, string>): string {
  const query = params ? new URLSearchParams(Object.entries(params).filter(([, v]) => v)).toString() : '';
  return `#${query ? `${path}?${query}` : path}`;
}
