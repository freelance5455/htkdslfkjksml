import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, useSyncExternalStore, type ReactNode } from 'react';
import type { AppData } from '../domain/types';
import type { TaskifyStore } from '../storage/store';

export type ToastKind = 'success' | 'error' | 'info';
export interface Toast {
  id: number;
  kind: ToastKind;
  message: string;
}

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }>;
}

interface AppContextValue {
  store: TaskifyStore;
  data: AppData;
  now: Date;
  online: boolean;
  toasts: Toast[];
  notify: (message: string, kind?: ToastKind) => void;
  dismissToast: (id: number) => void;
  canInstall: boolean;
  install: () => Promise<void>;
}

const AppContext = createContext<AppContextValue | null>(null);

let deferredPrompt: BeforeInstallPromptEvent | null = null;
const installListeners = new Set<() => void>();
window.addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault();
  deferredPrompt = e as BeforeInstallPromptEvent;
  installListeners.forEach((l) => l());
});
window.addEventListener('appinstalled', () => {
  deferredPrompt = null;
  installListeners.forEach((l) => l());
});

export function AppProvider({ store, children }: { store: TaskifyStore; children: ReactNode }) {
  const data = useSyncExternalStore(store.subscribe, store.getSnapshot);
  const [now, setNow] = useState(() => new Date());
  const [online, setOnline] = useState(() => navigator.onLine);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [canInstall, setCanInstall] = useState(() => deferredPrompt !== null);
  const nextId = useRef(1);

  useEffect(() => {
    const timer = window.setInterval(() => setNow(new Date()), 60_000);
    const on = () => setOnline(true);
    const off = () => setOnline(false);
    const inst = () => setCanInstall(deferredPrompt !== null);
    window.addEventListener('online', on);
    window.addEventListener('offline', off);
    installListeners.add(inst);
    return () => {
      window.clearInterval(timer);
      window.removeEventListener('online', on);
      window.removeEventListener('offline', off);
      installListeners.delete(inst);
    };
  }, []);

  const dismissToast = useCallback((id: number) => setToasts((t) => t.filter((x) => x.id !== id)), []);
  const notify = useCallback(
    (message: string, kind: ToastKind = 'success') => {
      const id = nextId.current++;
      setToasts((t) => [...t.slice(-3), { id, kind, message }]);
      window.setTimeout(() => dismissToast(id), kind === 'error' ? 6500 : 3500);
    },
    [dismissToast],
  );

  const install = useCallback(async () => {
    if (!deferredPrompt) return;
    await deferredPrompt.prompt();
    await deferredPrompt.userChoice;
    deferredPrompt = null;
    setCanInstall(false);
  }, []);

  const value = useMemo(
    () => ({ store, data, now, online, toasts, notify, dismissToast, canInstall, install }),
    [store, data, now, online, toasts, notify, dismissToast, canInstall, install],
  );
  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp(): AppContextValue {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp debe usarse dentro de AppProvider');
  return ctx;
}
