import { useEffect } from 'react';
import { AppShell } from './components/AppShell';
import { useApp } from './hooks/AppContext';
import { useRoute } from './hooks/router';
import { useApplyTheme } from './hooks/useTheme';
import { BoardPage } from './pages/BoardPage';
import { DashboardPage } from './pages/DashboardPage';
import { ListsPage } from './pages/ListsPage';
import { RemindersPage } from './pages/RemindersPage';
import { SettingsPage } from './pages/SettingsPage';
import { TasksPage } from './pages/TasksPage';
import { showWebNotifications, syncNativeNotifications } from './services/notifications';

const TITLES: Record<string, string> = {
  '/': 'Panel',
  '/tareas': 'Mis tareas',
  '/listas': 'Listas',
  '/tablero': 'Tablero Kanban',
  '/avisos': 'Recordatorios',
  '/ajustes': 'Ajustes',
};

/** Comprueba recordatorios al abrir, al cambiar tareas/ajustes y cada minuto. */
function useReminderEngine() {
  const { store, data, now, notify } = useApp();
  const { tasks, settings } = data;
  useEffect(() => {
    let cancelled = false;
    store.checkReminders().then((created) => {
      if (cancelled || created.length === 0) return;
      notify(created.length === 1 ? 'Tienes 1 aviso nuevo' : `Tienes ${created.length} avisos nuevos`, 'info');
      void showWebNotifications(created, tasks, settings.reminders);
    });
    return () => {
      cancelled = true;
    };
  }, [store, tasks, settings.reminders, now, notify]);

  useEffect(() => {
    const id = window.setTimeout(() => {
      syncNativeNotifications(tasks, settings.reminders, new Date()).catch((err) => console.warn('Notificaciones locales:', err));
    }, 800);
    return () => window.clearTimeout(id);
  }, [tasks, settings.reminders]);
}

export function App() {
  const route = useRoute();
  const { data } = useApp();
  useApplyTheme(data.settings.theme);
  useReminderEngine();

  const path = route.path in TITLES ? route.path : '/';
  useEffect(() => {
    document.title = `${TITLES[path]} · Taskify Desk`;
    document.getElementById('main')?.scrollTo?.(0, 0);
  }, [path]);

  const key = `${path}?${route.params.toString()}`;
  let page;
  switch (path) {
    case '/tareas':
      page = <TasksPage key={key} params={route.params} />;
      break;
    case '/listas':
      page = <ListsPage />;
      break;
    case '/tablero':
      page = <BoardPage key={key} params={route.params} />;
      break;
    case '/avisos':
      page = <RemindersPage />;
      break;
    case '/ajustes':
      page = <SettingsPage />;
      break;
    default:
      page = <DashboardPage />;
  }

  return (
    <AppShell path={path} title={TITLES[path]}>
      {page}
    </AppShell>
  );
}
