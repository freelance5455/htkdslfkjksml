import { useTaskEditor } from '../components/TaskForm';
import { EmptyState } from '../components/ui';
import { useApp } from '../hooks/AppContext';
import { href } from '../hooks/router';
import { formatDateTime, formatRelative } from '../utils/format';

export function RemindersPage() {
  const { data, store, now } = useApp();
  const editor = useTaskEditor();
  const tasks = new Map(data.tasks.map((t) => [t.id, t]));
  const reminders = data.reminders.filter((r) => tasks.has(r.taskId));
  const unread = reminders.filter((r) => !r.readAt).length;
  const s = data.settings.reminders;

  return (
    <div className="stack">
      <section className="page-head">
        <p className="muted">
          {s.enabled
            ? `Avisos ${s.hoursBefore} h antes de la fecha límite${s.notifyOverdue ? ' y al quedar atrasadas' : ''}. Se comprueban cada minuto mientras la app está abierta.`
            : 'Los recordatorios están desactivados.'}{' '}
          <a href={href('/ajustes')}>Cambiar preferencias</a>
        </p>
        <div className="actions">
          <button type="button" className="btn" onClick={() => store.checkReminders()}>
            Comprobar ahora
          </button>
          <button type="button" className="btn primary" disabled={unread === 0} onClick={() => store.markAllRemindersRead()}>
            Marcar todo como leído
          </button>
        </div>
      </section>

      <section className="card no-pad" aria-label="Avisos">
        {reminders.length === 0 ? (
          <EmptyState title="No hay avisos">Cuando una tarea esté próxima a vencer o atrasada aparecerá aquí.</EmptyState>
        ) : (
          <ul className="task-list">
            {reminders.map((r) => {
              const task = tasks.get(r.taskId)!;
              return (
                <li key={r.id} className={`task-row reminder ${r.readAt ? 'is-read' : ''}`}>
                  <span className={`badge ${r.type === 'overdue' ? 'due-overdue' : 'due-soon'}`}>{r.type === 'overdue' ? 'Atrasada' : 'Próxima'}</span>
                  <div className="task-main">
                    <button type="button" className="task-title link-btn" onClick={() => editor.openEdit(task)}>
                      {task.title}
                    </button>
                    <div className="meta">
                      <span className="muted small">Fecha límite: {formatDateTime(r.dueDateSnapshot)}</span>
                      <span className="muted small">· aviso {formatRelative(r.createdAt, now)}</span>
                      {task.status === 'done' && <span className="badge neutral">Ya completada</span>}
                    </div>
                  </div>
                  {!r.readAt ? (
                    <button type="button" className="btn small" onClick={() => store.markReminderRead(r.id)}>
                      Marcar como leído
                    </button>
                  ) : (
                    <span className="muted small">Leído</span>
                  )}
                </li>
              );
            })}
          </ul>
        )}
      </section>
      {editor.dialogs}
    </div>
  );
}
