import { useEffect, useRef, useState, type FormEvent } from 'react';
import { IconDownload } from '../components/Icons';
import { ConfirmDialog, Field } from '../components/ui';
import { REMINDER_HOUR_OPTIONS, type Theme } from '../domain/types';
import { useApp } from '../hooks/AppContext';
import { fileStamp, saveFile } from '../services/files';
import { getNotificationPermission, requestNotificationPermission, type PermissionState } from '../services/notifications';
import { isNative } from '../services/platform';

const THEMES: { value: Theme; label: string }[] = [
  { value: 'light', label: 'Claro' },
  { value: 'dark', label: 'Oscuro' },
  { value: 'system', label: 'Según el sistema' },
];

const PERMISSION_TEXT: Record<PermissionState, string> = {
  granted: 'Permiso concedido',
  denied: 'Permiso denegado: actívalo en los ajustes del sistema/navegador',
  prompt: 'Se pedirá permiso al activarlas',
  unsupported: 'Este navegador no admite notificaciones',
};

export function SettingsPage() {
  const { data, store, notify, canInstall, install, online } = useApp();
  const { settings } = data;
  const [userName, setUserName] = useState(settings.userName);
  const [workspaceName, setWorkspaceName] = useState(settings.workspaceName);
  const [workspaceDescription, setWorkspaceDescription] = useState(settings.workspaceDescription);
  const [permission, setPermission] = useState<PermissionState>('prompt');
  const [confirmReset, setConfirmReset] = useState(false);
  const fileInput = useRef<HTMLInputElement>(null);
  const standalone = window.matchMedia('(display-mode: standalone)').matches;

  useEffect(() => {
    getNotificationPermission().then(setPermission).catch(() => setPermission('unsupported'));
  }, []);

  async function saveProfile(e: FormEvent) {
    e.preventDefault();
    const res = await store.updateSettings({ userName, workspaceName, workspaceDescription });
    notify(res.ok ? 'Ajustes guardados' : res.error, res.ok ? 'success' : 'error');
  }

  async function toggleSystemNotifications(enabled: boolean) {
    if (enabled) {
      const p = await requestNotificationPermission();
      setPermission(p);
      if (p !== 'granted') {
        notify('No se concedió el permiso de notificaciones. Los avisos seguirán apareciendo dentro de la app.', 'error');
        return;
      }
    }
    await store.updateSettings({ reminders: { ...settings.reminders, systemNotifications: enabled } });
  }

  async function exportJson() {
    const blob = new Blob([store.exportBackup()], { type: 'application/json' });
    await saveFile(`taskify-copia-${fileStamp()}.json`, blob);
    notify('Copia de seguridad exportada');
  }

  async function importJson(file: File | undefined) {
    if (!file) return;
    const res = await store.importBackup(await file.text());
    notify(res.ok ? 'Copia restaurada' : res.error, res.ok ? 'success' : 'error');
    if (fileInput.current) fileInput.current.value = '';
  }

  return (
    <div className="stack settings">
      <section className="card">
        <h3>Perfil y espacio de trabajo</h3>
        <form className="form-grid" onSubmit={saveProfile}>
          <Field label="Tu nombre" htmlFor="st-name">
            <input id="st-name" value={userName} onChange={(e) => setUserName(e.target.value)} maxLength={40} />
          </Field>
          <Field label="Nombre del espacio de trabajo" htmlFor="st-ws">
            <input id="st-ws" value={workspaceName} onChange={(e) => setWorkspaceName(e.target.value)} maxLength={60} />
          </Field>
          <Field label="Descripción del espacio" htmlFor="st-wsd">
            <textarea id="st-wsd" rows={2} value={workspaceDescription} onChange={(e) => setWorkspaceDescription(e.target.value)} maxLength={300} />
          </Field>
          <div>
            <button type="submit" className="btn primary">
              Guardar
            </button>
          </div>
        </form>
      </section>

      <section className="card">
        <h3>Apariencia</h3>
        <fieldset className="segmented">
          <legend className="sr-only">Tema</legend>
          {THEMES.map((t) => (
            <label key={t.value} className={settings.theme === t.value ? 'active' : ''}>
              <input type="radio" name="theme" value={t.value} checked={settings.theme === t.value} onChange={() => store.updateSettings({ theme: t.value })} />
              {t.label}
            </label>
          ))}
        </fieldset>
      </section>

      <section className="card">
        <h3>Recordatorios</h3>
        <div className="form-grid">
          <label className="switch">
            <input
              type="checkbox"
              checked={settings.reminders.enabled}
              onChange={(e) => store.updateSettings({ reminders: { ...settings.reminders, enabled: e.target.checked } })}
            />
            <span>Activar recordatorios</span>
          </label>
          <Field label="Avisar con antelación" htmlFor="st-hours">
            <select
              id="st-hours"
              value={settings.reminders.hoursBefore}
              disabled={!settings.reminders.enabled}
              onChange={(e) => store.updateSettings({ reminders: { ...settings.reminders, hoursBefore: Number(e.target.value) } })}
            >
              {REMINDER_HOUR_OPTIONS.map((h) => (
                <option key={h} value={h}>
                  {h === 1 ? '1 hora antes' : `${h} horas antes`}
                </option>
              ))}
            </select>
          </Field>
          <label className="switch">
            <input
              type="checkbox"
              checked={settings.reminders.notifyOverdue}
              disabled={!settings.reminders.enabled}
              onChange={(e) => store.updateSettings({ reminders: { ...settings.reminders, notifyOverdue: e.target.checked } })}
            />
            <span>Avisar también de tareas atrasadas</span>
          </label>
          <label className="switch">
            <input
              type="checkbox"
              checked={settings.reminders.systemNotifications}
              disabled={!settings.reminders.enabled || permission === 'unsupported'}
              onChange={(e) => toggleSystemNotifications(e.target.checked)}
            />
            <span>Notificaciones del sistema</span>
          </label>
          <p className="muted small">
            {PERMISSION_TEXT[permission]}.{' '}
            {isNative()
              ? 'En Android se programan en el teléfono y suenan aunque la app esté cerrada.'
              : 'En navegador/PWA solo se muestran mientras la app está abierta (aunque esté en segundo plano). No hay notificaciones push desde un servidor.'}
          </p>
        </div>
      </section>

      <section className="card">
        <h3>Datos y copia de seguridad</h3>
        <p className="muted">
          Todo se guarda en este dispositivo (IndexedDB). No hay sincronización entre dispositivos: usa la copia de seguridad para pasar tus datos a otro equipo.
        </p>
        <div className="actions wrap">
          <button type="button" className="btn" onClick={exportJson}>
            <IconDownload /> Exportar copia (JSON)
          </button>
          <label className="btn">
            Importar copia…
            <input ref={fileInput} type="file" accept="application/json,.json" className="sr-only" onChange={(e) => importJson(e.target.files?.[0])} />
          </label>
          <button type="button" className="btn danger-outline" onClick={() => setConfirmReset(true)}>
            Restaurar datos de demostración
          </button>
        </div>
      </section>

      <section className="card">
        <h3>Aplicación</h3>
        <ul className="plain-list info-list">
          <li>Versión 1.0.0 · {isNative() ? 'App Android' : standalone ? 'Instalada (PWA)' : 'Navegador'}</li>
          <li>Conexión: {online ? 'en línea' : 'sin conexión'} · la app funciona igual sin Internet</li>
        </ul>
        {canInstall && !isNative() && (
          <button type="button" className="btn primary" onClick={install}>
            <IconDownload /> Instalar Taskify Desk
          </button>
        )}
      </section>

      {confirmReset && (
        <ConfirmDialog
          title="Restaurar datos de demostración"
          message="Se borrarán todas tus listas, tareas y avisos y se cargarán los datos de ejemplo. Exporta una copia antes si quieres conservarlos."
          confirmLabel="Borrar y restaurar"
          onCancel={() => setConfirmReset(false)}
          onConfirm={async () => {
            await store.resetToDemo();
            setConfirmReset(false);
            notify('Datos de demostración restaurados');
          }}
        />
      )}
    </div>
  );
}
