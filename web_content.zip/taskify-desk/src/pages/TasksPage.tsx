import { useMemo, useState } from 'react';
import { IconEdit, IconPdf, IconPlus, IconSearch, IconTrash } from '../components/Icons';
import { useTaskEditor } from '../components/TaskForm';
import { DueBadge, EmptyState, PriorityBadge } from '../components/ui';
import { EMPTY_FILTER, assigneesOf, filterTasks, type SortKey, type StateFilter, type TaskFilter } from '../domain/queries';
import { PRIORITIES, PRIORITY_LABELS, STATUS_LABELS, type Priority } from '../domain/types';
import { useApp } from '../hooks/AppContext';
import { exportTaskReport } from '../services/pdf';

const STATE_OPTIONS: { value: StateFilter; label: string }[] = [
  { value: 'all', label: 'Todas' },
  { value: 'pending', label: 'Pendientes' },
  { value: 'upcoming', label: 'Próximas a vencer' },
  { value: 'overdue', label: 'Atrasadas' },
  { value: 'done', label: 'Completadas' },
];

const SORT_OPTIONS: { value: SortKey; label: string }[] = [
  { value: 'dueDate', label: 'Fecha límite' },
  { value: 'priority', label: 'Prioridad' },
  { value: 'status', label: 'Estado' },
  { value: 'createdAt', label: 'Más recientes' },
  { value: 'title', label: 'Título (A-Z)' },
];

export function TasksPage({ params }: { params: URLSearchParams }) {
  const { data, store, now, notify } = useApp();
  const editor = useTaskEditor();
  const initialState = (params.get('estado') as StateFilter) || 'all';
  const [filter, setFilter] = useState<TaskFilter>({
    ...EMPTY_FILTER,
    state: STATE_OPTIONS.some((o) => o.value === initialState) ? initialState : 'all',
    listId: params.get('lista') ?? '',
  });
  const [exporting, setExporting] = useState(false);
  const listName = useMemo(() => new Map(data.lists.map((l) => [l.id, l.name])), [data.lists]);
  const visible = filterTasks(data.tasks, filter, now);
  const people = assigneesOf(data.tasks);
  const set = <K extends keyof TaskFilter>(key: K, value: TaskFilter[K]) => setFilter((f) => ({ ...f, [key]: value }));
  const isFiltered = JSON.stringify({ ...filter, sort: 'dueDate' }) !== JSON.stringify(EMPTY_FILTER);

  async function toggle(id: string) {
    const res = await store.toggleComplete(id);
    if (!res.ok) notify(res.error, 'error');
  }

  async function exportPdf() {
    setExporting(true);
    try {
      const subtitle = isFiltered ? `Filtro: ${STATE_OPTIONS.find((o) => o.value === filter.state)?.label}${filter.query ? ` · búsqueda «${filter.query}»` : ''}` : undefined;
      await exportTaskReport({ title: 'Listado de tareas', subtitle, tasks: visible, lists: data.lists, settings: data.settings, now }, 'tareas');
      notify('PDF generado');
    } catch (err) {
      notify(`No se pudo generar el PDF: ${(err as Error).message}`, 'error');
    } finally {
      setExporting(false);
    }
  }

  return (
    <div className="stack">
      <section className="page-head">
        <p className="muted">
          {visible.length} de {data.tasks.length} tareas
        </p>
        <div className="actions">
          <button type="button" className="btn" onClick={exportPdf} disabled={exporting}>
            <IconPdf /> {exporting ? 'Generando…' : 'Exportar PDF'}
          </button>
          <button type="button" className="btn primary" onClick={() => editor.openNew({ listId: filter.listId || undefined })}>
            <IconPlus /> Nueva tarea
          </button>
        </div>
      </section>

      <section className="card toolbar" aria-label="Buscar y filtrar">
        <label className="search">
          <IconSearch size={18} />
          <span className="sr-only">Buscar tareas</span>
          <input type="search" placeholder="Buscar por título, descripción o responsable…" value={filter.query} onChange={(e) => set('query', e.target.value)} />
        </label>
        <div className="filters">
          <label>
            <span>Lista</span>
            <select value={filter.listId} onChange={(e) => set('listId', e.target.value)}>
              <option value="">Todas</option>
              {data.lists.map((l) => (
                <option key={l.id} value={l.id}>
                  {l.name}
                </option>
              ))}
            </select>
          </label>
          <label>
            <span>Estado</span>
            <select value={filter.state} onChange={(e) => set('state', e.target.value as StateFilter)}>
              {STATE_OPTIONS.map((o) => (
                <option key={o.value} value={o.value}>
                  {o.label}
                </option>
              ))}
            </select>
          </label>
          <label>
            <span>Prioridad</span>
            <select value={filter.priority} onChange={(e) => set('priority', e.target.value as Priority | '')}>
              <option value="">Todas</option>
              {PRIORITIES.map((p) => (
                <option key={p} value={p}>
                  {PRIORITY_LABELS[p]}
                </option>
              ))}
            </select>
          </label>
          <label>
            <span>Responsable</span>
            <select value={filter.assignee} onChange={(e) => set('assignee', e.target.value)}>
              <option value="">Todos</option>
              {people.map((p) => (
                <option key={p} value={p}>
                  {p}
                </option>
              ))}
            </select>
          </label>
          <label>
            <span>Ordenar por</span>
            <select value={filter.sort} onChange={(e) => set('sort', e.target.value as SortKey)}>
              {SORT_OPTIONS.map((o) => (
                <option key={o.value} value={o.value}>
                  {o.label}
                </option>
              ))}
            </select>
          </label>
          {isFiltered && (
            <button type="button" className="btn ghost" onClick={() => setFilter(EMPTY_FILTER)}>
              Limpiar filtros
            </button>
          )}
        </div>
      </section>

      <section className="card no-pad" aria-label="Tareas">
        {visible.length === 0 ? (
          <EmptyState
            title={data.tasks.length === 0 ? 'Todavía no hay tareas' : 'Ninguna tarea coincide'}
            action={
              data.tasks.length === 0 ? (
                <button type="button" className="btn primary" onClick={() => editor.openNew()}>
                  <IconPlus /> Crear la primera
                </button>
              ) : undefined
            }
          >
            {data.tasks.length === 0 ? 'Crea una tarea para empezar.' : 'Prueba a cambiar la búsqueda o los filtros.'}
          </EmptyState>
        ) : (
          <ul className="task-list">
            {visible.map((t) => (
              <li key={t.id} className={`task-row ${t.status === 'done' ? 'is-done' : ''}`}>
                <input
                  type="checkbox"
                  className="check"
                  checked={t.status === 'done'}
                  onChange={() => toggle(t.id)}
                  aria-label={t.status === 'done' ? `Reabrir «${t.title}»` : `Completar «${t.title}»`}
                />
                <div className="task-main">
                  <button type="button" className="task-title link-btn" onClick={() => editor.openEdit(t)}>
                    {t.title}
                  </button>
                  {t.description && <p className="task-desc">{t.description}</p>}
                  <div className="meta">
                    <PriorityBadge priority={t.priority} />
                    <span className="badge neutral">{STATUS_LABELS[t.status]}</span>
                    <DueBadge task={t} />
                    <span className="muted small">{listName.get(t.listId)}</span>
                    {t.assignee && <span className="muted small">· {t.assignee}</span>}
                  </div>
                </div>
                <div className="row-actions">
                  <button type="button" className="icon-btn ghost" onClick={() => editor.openEdit(t)} aria-label={`Editar «${t.title}»`}>
                    <IconEdit size={18} />
                  </button>
                  <button type="button" className="icon-btn ghost" onClick={() => editor.askDelete(t)} aria-label={`Eliminar «${t.title}»`}>
                    <IconTrash size={18} />
                  </button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </section>
      {editor.dialogs}
    </div>
  );
}
