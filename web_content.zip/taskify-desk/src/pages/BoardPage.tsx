import { useState, type DragEvent } from 'react';
import { IconEdit, IconPlus, IconTrash, IconUser, IconWarning } from '../components/Icons';
import { useTaskEditor } from '../components/TaskForm';
import { DueBadge, EmptyState, PriorityBadge } from '../components/ui';
import { assigneesOf } from '../domain/queries';
import { PRIORITIES, PRIORITY_LABELS, STATUSES, STATUS_LABELS, WIP_LIMITS, type Priority, type Status, type Task } from '../domain/types';
import { checkWip } from '../domain/wip';
import { useApp } from '../hooks/AppContext';
import { navigate } from '../hooks/router';

export function BoardPage({ params }: { params: URLSearchParams }) {
  const { data, store, notify } = useApp();
  const editor = useTaskEditor();
  const listId = data.lists.some((l) => l.id === params.get('lista')) ? params.get('lista')! : (data.lists[0]?.id ?? '');
  const [priority, setPriority] = useState<Priority | ''>('');
  const [assignee, setAssignee] = useState('');
  const [dragId, setDragId] = useState<string | null>(null);
  const [overCol, setOverCol] = useState<Status | null>(null);
  const [wipAlert, setWipAlert] = useState('');

  const listTasks = data.tasks.filter((t) => t.listId === listId);
  const people = assigneesOf(listTasks);
  const visible = listTasks.filter((t) => (!priority || t.priority === priority) && (!assignee || t.assignee === assignee));

  async function move(task: Task, target: Status) {
    if (task.status === target) return;
    const res = await store.moveTask(task.id, target);
    if (res.ok) {
      setWipAlert('');
      notify(`«${task.title}» movida a ${STATUS_LABELS[target]}`);
    } else {
      setWipAlert(res.error);
      notify(res.error, 'error');
    }
  }

  function addCard(status: Status) {
    const wip = checkWip(data.tasks, listId, status);
    if (!wip.ok) {
      setWipAlert(wip.message!);
      notify(wip.message!, 'error');
      return;
    }
    editor.openNew({ listId, status });
  }

  function onDrop(e: DragEvent, status: Status) {
    e.preventDefault();
    setOverCol(null);
    const id = e.dataTransfer.getData('text/plain') || dragId;
    setDragId(null);
    const task = data.tasks.find((t) => t.id === id);
    if (task) void move(task, status);
  }

  if (!listId) {
    return <EmptyState title="No hay listas">Crea una lista para usar el tablero.</EmptyState>;
  }

  return (
    <div className="stack">
      <section className="card toolbar" aria-label="Opciones del tablero">
        <div className="filters">
          <label>
            <span>Lista</span>
            <select value={listId} onChange={(e) => navigate('/tablero', { lista: e.target.value })}>
              {data.lists.map((l) => (
                <option key={l.id} value={l.id}>
                  {l.name}
                </option>
              ))}
            </select>
          </label>
          <label>
            <span>Prioridad</span>
            <select value={priority} onChange={(e) => setPriority(e.target.value as Priority | '')}>
              <option value="">Todas</option>
              {PRIORITIES.map((p) => (
                <option key={p} value={p}>
                  {PRIORITY_LABELS[p]}
                </option>
              ))}
            </select>
          </label>
          <label>
            <span>Responsable</span>
            <select value={assignee} onChange={(e) => setAssignee(e.target.value)}>
              <option value="">Todos</option>
              {people.map((p) => (
                <option key={p} value={p}>
                  {p}
                </option>
              ))}
            </select>
          </label>
          <p className="muted small wip-note">Límites WIP: Desarrollo 2 · Pruebas / QA 1</p>
        </div>
      </section>

      {wipAlert && (
        <div className="alert alert-warn" role="alert">
          <IconWarning size={18} />
          <span className="grow">{wipAlert}</span>
          <button type="button" className="btn ghost small" onClick={() => setWipAlert('')}>
            Entendido
          </button>
        </div>
      )}

      <div className="board" aria-label="Tablero Kanban">
        {STATUSES.map((status) => {
          const total = listTasks.filter((t) => t.status === status).length;
          const cards = visible.filter((t) => t.status === status);
          const limit = WIP_LIMITS[status];
          const full = limit !== undefined && total >= limit;
          return (
            <section
              key={status}
              className={`column ${overCol === status ? 'drag-over' : ''} ${full ? 'is-full' : ''}`}
              aria-label={`${STATUS_LABELS[status]}, ${total} tarjetas${limit !== undefined ? ` de ${limit}` : ''}`}
              onDragOver={(e) => {
                e.preventDefault();
                setOverCol(status);
              }}
              onDragLeave={() => setOverCol((c) => (c === status ? null : c))}
              onDrop={(e) => onDrop(e, status)}
            >
              <header className="column-head">
                <h3>{STATUS_LABELS[status]}</h3>
                <span className={`count ${full ? 'full' : ''}`}>
                  {total}
                  {limit !== undefined ? ` / ${limit}` : ''}
                </span>
              </header>
              {full && <p className="wip-flag">Límite WIP alcanzado</p>}
              <div className="cards">
                {cards.map((t) => (
                  <article
                    key={t.id}
                    className={`kcard ${dragId === t.id ? 'dragging' : ''}`}
                    draggable
                    onDragStart={(e) => {
                      e.dataTransfer.setData('text/plain', t.id);
                      e.dataTransfer.effectAllowed = 'move';
                      setDragId(t.id);
                    }}
                    onDragEnd={() => {
                      setDragId(null);
                      setOverCol(null);
                    }}
                  >
                    <div className="meta">
                      <PriorityBadge priority={t.priority} />
                      <DueBadge task={t} />
                    </div>
                    <h4>{t.title}</h4>
                    <div className="kcard-foot">
                      <span className="muted small assignee">
                        <IconUser size={14} /> {t.assignee || 'Sin responsable'}
                      </span>
                      <span className="badge neutral">{STATUS_LABELS[t.status]}</span>
                    </div>
                    <div className="kcard-actions">
                      <label className="move-select">
                        <span className="sr-only">Mover «{t.title}» a</span>
                        <select value={t.status} onChange={(e) => move(t, e.target.value as Status)}>
                          {STATUSES.map((s) => (
                            <option key={s} value={s}>
                              {s === t.status ? `Mover a… (${STATUS_LABELS[s]})` : STATUS_LABELS[s]}
                            </option>
                          ))}
                        </select>
                      </label>
                      <button type="button" className="icon-btn ghost" onClick={() => editor.openEdit(t)} aria-label={`Editar «${t.title}»`}>
                        <IconEdit size={18} />
                      </button>
                      <button type="button" className="icon-btn ghost" onClick={() => editor.askDelete(t)} aria-label={`Eliminar «${t.title}»`}>
                        <IconTrash size={18} />
                      </button>
                    </div>
                  </article>
                ))}
                {cards.length === 0 && <p className="column-empty">{total > 0 ? 'Oculto por los filtros' : 'Sin tarjetas'}</p>}
              </div>
              <button type="button" className="add-card" onClick={() => addCard(status)} aria-label={`Nueva tarjeta en ${STATUS_LABELS[status]}`}>
                <IconPlus size={18} /> Nueva tarjeta
              </button>
            </section>
          );
        })}
      </div>
      {editor.dialogs}
    </div>
  );
}
