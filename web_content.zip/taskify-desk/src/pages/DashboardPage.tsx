import { useState } from 'react';
import { IconPdf, IconPlus } from '../components/Icons';
import { useTaskEditor } from '../components/TaskForm';
import { DueBadge, EmptyState, PriorityBadge } from '../components/ui';
import { computeStats, isOverdue, isUpcoming } from '../domain/queries';
import { STATUSES, STATUS_LABELS, WIP_LIMITS } from '../domain/types';
import { useApp } from '../hooks/AppContext';
import { href } from '../hooks/router';
import { exportTaskReport } from '../services/pdf';
import { formatLongDate, formatRelative } from '../utils/format';

export function DashboardPage() {
  const { data, now, notify } = useApp();
  const editor = useTaskEditor();
  const [exporting, setExporting] = useState(false);
  const stats = computeStats(data.tasks, now);
  const firstList = data.lists[0];
  const boardTasks = firstList ? data.tasks.filter((t) => t.listId === firstList.id) : [];
  const attention = data.tasks
    .filter((t) => isOverdue(t, now) || isUpcoming(t, now))
    .sort((a, b) => Date.parse(a.dueDate!) - Date.parse(b.dueDate!))
    .slice(0, 6);

  async function exportReport() {
    setExporting(true);
    try {
      await exportTaskReport({ title: 'Informe general de tareas', tasks: data.tasks, lists: data.lists, settings: data.settings, now }, 'informe-general');
      notify('Informe PDF generado');
    } catch (err) {
      notify(`No se pudo generar el PDF: ${(err as Error).message}`, 'error');
    } finally {
      setExporting(false);
    }
  }

  const kpis = [
    { label: 'Total de tareas', value: stats.total, state: 'all', tone: '' },
    { label: 'Pendientes', value: stats.pending, state: 'pending', tone: '' },
    { label: 'Completadas', value: stats.done, state: 'done', tone: 'ok' },
    { label: 'Próximas a vencer (72 h)', value: stats.upcoming, state: 'upcoming', tone: 'warn' },
    { label: 'Atrasadas', value: stats.overdue, state: 'overdue', tone: 'bad' },
  ];

  return (
    <div className="stack">
      <section className="page-head">
        <div>
          <h2 className="h-lg">Hola, {data.settings.userName}</h2>
          <p className="muted">{formatLongDate(now)} · {data.settings.workspaceName}</p>
        </div>
        <div className="actions">
          <button type="button" className="btn" onClick={exportReport} disabled={exporting}>
            <IconPdf /> {exporting ? 'Generando…' : 'Informe PDF'}
          </button>
          <button type="button" className="btn primary" onClick={() => editor.openNew()}>
            <IconPlus /> Nueva tarea
          </button>
        </div>
      </section>

      <section className="kpis" aria-label="Resumen de tareas">
        {kpis.map((k) => (
          <a key={k.label} className={`kpi ${k.tone}`} href={href('/tareas', { estado: k.state })}>
            <span className="kpi-label">{k.label}</span>
            <span className="kpi-value">{k.value}</span>
          </a>
        ))}
      </section>

      {firstList && (
        <section className="card">
          <div className="card-head">
            <h3>Tablero · {firstList.name}</h3>
            <a href={href('/tablero', { lista: firstList.id })}>Abrir tablero</a>
          </div>
          <div className="mini-board">
            {STATUSES.map((s) => {
              const count = boardTasks.filter((t) => t.status === s).length;
              const limit = WIP_LIMITS[s];
              const full = limit !== undefined && count >= limit;
              return (
                <div key={s} className={`mini-col ${full ? 'full' : ''}`}>
                  <span className="muted small">{STATUS_LABELS[s]}</span>
                  <strong>
                    {count}
                    {limit !== undefined && <span className="small"> / {limit} WIP{full ? ' · lleno' : ''}</span>}
                  </strong>
                </div>
              );
            })}
          </div>
        </section>
      )}

      <div className="two-col">
        <section className="card">
          <div className="card-head">
            <h3>Próximas y atrasadas</h3>
            <a href={href('/tareas', { estado: 'pending' })}>Ver pendientes</a>
          </div>
          {attention.length === 0 ? (
            <EmptyState title="Nada urgente">No hay tareas atrasadas ni que venzan en las próximas 72 horas.</EmptyState>
          ) : (
            <ul className="plain-list">
              {attention.map((t) => (
                <li key={t.id} className="line">
                  <button type="button" className="link-btn grow" onClick={() => editor.openEdit(t)}>
                    {t.title}
                  </button>
                  <PriorityBadge priority={t.priority} />
                  <DueBadge task={t} />
                </li>
              ))}
            </ul>
          )}
        </section>
        <section className="card">
          <div className="card-head">
            <h3>Actividad reciente</h3>
          </div>
          {data.activity.length === 0 ? (
            <EmptyState title="Sin actividad todavía" />
          ) : (
            <ul className="plain-list">
              {data.activity.slice(0, 8).map((a) => (
                <li key={a.id} className="line">
                  <span className={`act-dot act-${a.action}`} aria-hidden="true" />
                  <span className="grow">{a.detail}</span>
                  <span className="muted small nowrap">{formatRelative(a.createdAt, now)}</span>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>
      {editor.dialogs}
    </div>
  );
}
