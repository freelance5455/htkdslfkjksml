import { useState, type FormEvent } from 'react';
import { IconBoard, IconEdit, IconPlus, IconTasks, IconTrash } from '../components/Icons';
import { ConfirmDialog, EmptyState, Field, Modal } from '../components/ui';
import type { TaskList } from '../domain/types';
import type { FieldErrors } from '../domain/validation';
import { useApp } from '../hooks/AppContext';
import { href } from '../hooks/router';
import { formatDate } from '../utils/format';

function ListForm({ list, onClose }: { list?: TaskList; onClose: () => void }) {
  const { store, notify } = useApp();
  const [name, setName] = useState(list?.name ?? '');
  const [description, setDescription] = useState(list?.description ?? '');
  const [errors, setErrors] = useState<FieldErrors>({});

  async function submit(e: FormEvent) {
    e.preventDefault();
    const res = list ? await store.updateList(list.id, name, description) : await store.createList(name, description);
    if (!res.ok) {
      setErrors(res.fieldErrors ?? { name: res.error });
      return;
    }
    notify(list ? 'Lista actualizada' : 'Lista creada');
    onClose();
  }

  return (
    <Modal
      title={list ? 'Editar lista' : 'Nueva lista'}
      onClose={onClose}
      size="sm"
      footer={
        <>
          <button type="button" className="btn" onClick={onClose}>
            Cancelar
          </button>
          <button type="submit" form="list-form" className="btn primary">
            {list ? 'Guardar' : 'Crear lista'}
          </button>
        </>
      }
    >
      <form id="list-form" className="form-grid" onSubmit={submit} noValidate>
        <Field label="Nombre *" htmlFor="lf-name" error={errors.name}>
          <input id="lf-name" value={name} onChange={(e) => setName(e.target.value)} maxLength={60} autoFocus aria-invalid={!!errors.name} />
        </Field>
        <Field label="Descripción (opcional)" htmlFor="lf-desc" error={errors.description}>
          <textarea id="lf-desc" rows={3} value={description} onChange={(e) => setDescription(e.target.value)} maxLength={300} />
        </Field>
      </form>
    </Modal>
  );
}

export function ListsPage() {
  const { data, store, notify } = useApp();
  const [editing, setEditing] = useState<TaskList | 'new' | null>(null);
  const [deleting, setDeleting] = useState<TaskList | null>(null);

  return (
    <div className="stack">
      <section className="page-head">
        <p className="muted">Organiza las tareas por proyecto o área. Cada lista tiene su propio tablero Kanban.</p>
        <button type="button" className="btn primary" onClick={() => setEditing('new')}>
          <IconPlus /> Nueva lista
        </button>
      </section>

      {data.lists.length === 0 ? (
        <EmptyState title="No hay listas" />
      ) : (
        <div className="list-grid">
          {data.lists.map((l) => {
            const tasks = data.tasks.filter((t) => t.listId === l.id);
            const pending = tasks.filter((t) => t.status !== 'done').length;
            const pct = tasks.length ? Math.round(((tasks.length - pending) / tasks.length) * 100) : 0;
            return (
              <article key={l.id} className="card list-card">
                <h3>{l.name}</h3>
                <p className="muted">{l.description || 'Sin descripción'}</p>
                <div className="progress" role="progressbar" aria-valuenow={pct} aria-valuemin={0} aria-valuemax={100} aria-label={`Progreso de ${l.name}`}>
                  <span style={{ width: `${pct}%` }} />
                </div>
                <p className="small muted">
                  {tasks.length} tareas · {pending} pendientes · {pct}% completado · creada el {formatDate(l.createdAt)}
                </p>
                <div className="list-actions">
                  <a className="btn small" href={href('/tareas', { lista: l.id })}>
                    <IconTasks size={18} /> Tareas
                  </a>
                  <a className="btn small" href={href('/tablero', { lista: l.id })}>
                    <IconBoard size={18} /> Tablero
                  </a>
                  <button type="button" className="icon-btn ghost" onClick={() => setEditing(l)} aria-label={`Editar lista ${l.name}`}>
                    <IconEdit size={18} />
                  </button>
                  <button type="button" className="icon-btn ghost" onClick={() => setDeleting(l)} aria-label={`Eliminar lista ${l.name}`}>
                    <IconTrash size={18} />
                  </button>
                </div>
              </article>
            );
          })}
        </div>
      )}

      {editing && <ListForm list={editing === 'new' ? undefined : editing} onClose={() => setEditing(null)} />}
      {deleting && (
        <ConfirmDialog
          title="Eliminar lista"
          message={`Se eliminará «${deleting.name}» y sus ${data.tasks.filter((t) => t.listId === deleting.id).length} tareas. Esta acción no se puede deshacer.`}
          onCancel={() => setDeleting(null)}
          onConfirm={async () => {
            const res = await store.deleteList(deleting.id);
            setDeleting(null);
            notify(res.ok ? 'Lista eliminada' : res.error, res.ok ? 'success' : 'error');
          }}
        />
      )}
    </div>
  );
}
