import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { App } from './App';
import { AppProvider } from './hooks/AppContext';
import { isNative } from './services/platform';
import { Database } from './storage/db';
import { TaskifyStore } from './storage/store';
import './styles/app.css';

const rootEl = document.getElementById('root')!;
const root = createRoot(rootEl);

function showFatal(message: string) {
  root.render(
    <div className="fatal" role="alert">
      <h1>No se pudo abrir Taskify Desk</h1>
      <p>{message}</p>
      <p>Si usas una ventana privada o de incógnito, ábrela en una ventana normal: el almacenamiento local está desactivado.</p>
      <button type="button" className="btn primary" onClick={() => window.location.reload()}>
        Reintentar
      </button>
    </div>,
  );
}

async function start() {
  try {
    if (!('indexedDB' in window)) throw new Error('Este navegador no permite guardar datos locales (IndexedDB).');
    const db = await Database.open();
    const store = await TaskifyStore.create(db);
    // Pide al navegador que no borre los datos automáticamente si falta espacio.
    void navigator.storage?.persist?.();
    root.render(
      <StrictMode>
        <AppProvider store={store}>
          <App />
        </AppProvider>
      </StrictMode>,
    );
  } catch (err) {
    console.error(err);
    showFatal((err as Error).message);
  }
}

void start();

// Service worker: solo en producción y fuera de la app Android (allí los archivos ya van dentro del APK).
if (import.meta.env.PROD && !isNative() && 'serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('./sw.js').catch((err) => console.warn('Service worker no registrado:', err));
  });
}
