/**
 * Genera los iconos PNG (PWA y Android) a partir de public/icons/icon.svg.
 * Uso opcional (los iconos ya vienen generados):  npm i -D sharp  &&  npm run icons
 */
import { mkdirSync, readFileSync, existsSync } from 'node:fs';
import { dirname, join } from 'node:path';
import sharp from 'sharp';

const root = join(dirname(new URL(import.meta.url).pathname.replace(/^\/([A-Za-z]:)/, '$1')), '..');
const svg = readFileSync(join(root, 'public/icons/icon.svg'));
const BLUE = '#2F5BD3';

// Versión sin esquinas redondeadas y con margen (zona segura) para iconos "maskable"/adaptativos.
const glyph = readFileSync(join(root, 'public/icons/icon.svg'), 'utf8').replace(/<rect width="512" height="512" rx="112" fill="#2F5BD3"\/>/, '');
const fullBleed = (scale) =>
  Buffer.from(
    `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><rect width="512" height="512" fill="${BLUE}"/><g transform="translate(${256 - 256 * scale} ${256 - 256 * scale}) scale(${scale})">${glyph.replace(/<\/?svg[^>]*>/g, '')}</g></svg>`,
  );
const foregroundOnly = (scale) =>
  Buffer.from(
    `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><g transform="translate(${256 - 256 * scale} ${256 - 256 * scale}) scale(${scale})">${glyph.replace(/<\/?svg[^>]*>/g, '')}</g></svg>`,
  );

async function png(input, size, out) {
  mkdirSync(dirname(out), { recursive: true });
  await sharp(input, { density: 384 }).resize(size, size).png().toFile(out);
  console.log('✓', out.replace(root, '.'));
}

await png(svg, 192, join(root, 'public/icons/icon-192.png'));
await png(svg, 512, join(root, 'public/icons/icon-512.png'));
await png(fullBleed(0.72), 512, join(root, 'public/icons/icon-maskable-512.png'));
await png(fullBleed(0.9), 180, join(root, 'public/icons/apple-touch-icon.png'));

const res = join(root, 'android/app/src/main/res');
if (existsSync(res)) {
  const densities = { mdpi: 1, hdpi: 1.5, xhdpi: 2, xxhdpi: 3, xxxhdpi: 4 };
  for (const [d, k] of Object.entries(densities)) {
    await png(svg, 48 * k, join(res, `mipmap-${d}/ic_launcher.png`));
    await png(svg, 48 * k, join(res, `mipmap-${d}/ic_launcher_round.png`));
    // Icono adaptativo: 108dp con el dibujo dentro de la zona segura de 66dp.
    await png(foregroundOnly(0.6), 108 * k, join(res, `mipmap-${d}/ic_launcher_foreground.png`));
  }
}
