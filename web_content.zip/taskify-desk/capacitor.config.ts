import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.taskifydesk.app',
  appName: 'Taskify Desk',
  webDir: 'dist',
  android: {
    backgroundColor: '#F4F5F7',
  },
  plugins: {
    LocalNotifications: {
      smallIcon: 'ic_stat_taskify',
      iconColor: '#2F5BD3',
    },
  },
};

export default config;
