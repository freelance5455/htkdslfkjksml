package com.taskifydesk.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
