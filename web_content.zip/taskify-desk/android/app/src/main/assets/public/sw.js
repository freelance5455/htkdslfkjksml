/* Service worker de Taskify Desk.
 * Guarda en caché todos los archivos de la aplicación durante la instalación
 * para que se pueda abrir y usar sin conexión. Los datos (tareas, listas…)
 * NO pasan por aquí: viven en IndexedDB, en el propio dispositivo.
 * La lista de archivos y la versión se rellenan automáticamente en `npm run build`.
 */
const VERSION = '52e4142fc997';
const CACHE = `taskify-desk-${VERSION}`;
const PRECACHE = ["./","assets/html2canvas.esm-DXEQVQnt.js","assets/index-BajkiCJ6.js","assets/index-BdfxD_sR.js","assets/index-BoEfQDuZ.js","assets/index-Bx-Fypj7.css","assets/index-CqzDj3tC.js","assets/index.es-Cgsd1O7W.js","assets/jspdf.es.min-BpUtZiBQ.js","assets/jspdf.plugin.autotable-B0IxatYY.js","assets/purify.es-18JuyMri.js","assets/web-BHR53x-r.js","assets/web-Co79b4Lv.js","assets/web-Dusg0Xon.js","icons/apple-touch-icon.png","icons/icon-192.png","icons/icon-512.png","icons/icon-maskable-512.png","icons/icon.svg","index.html","manifest.webmanifest"];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches
      .open(CACHE)
      .then((cache) => cache.addAll(PRECACHE.map((path) => new Request(path, { cache: 'reload' }))))
      .then(() => self.skipWaiting()),
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) => Promise.all(keys.filter((k) => k.startsWith('taskify-desk-') && k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim()),
  );
});

self.addEventListener('fetch', (event) => {
  const { request } = event;
  if (request.method !== 'GET' || new URL(request.url).origin !== self.location.origin) return;

  // Navegación (abrir la app): primero la red para obtener actualizaciones; si no hay conexión, la copia guardada.
  if (request.mode === 'navigate') {
    event.respondWith(
      fetch(request)
        .then((response) => {
          const copy = response.clone();
          caches.open(CACHE).then((cache) => cache.put('./', copy));
          return response;
        })
        .catch(() => caches.match('./', { ignoreSearch: true }).then((r) => r || caches.match('index.html'))),
    );
    return;
  }

  // Resto de archivos: caché primero (tienen nombre con hash), red como respaldo.
  event.respondWith(
    caches.match(request, { ignoreSearch: true }).then(
      (cached) =>
        cached ||
        fetch(request).then((response) => {
          if (response.ok) {
            const copy = response.clone();
            caches.open(CACHE).then((cache) => cache.put(request, copy));
          }
          return response;
        }),
    ),
  );
});

// Al pulsar una notificación, abre (o enfoca) la app en la pantalla de avisos.
self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clients) => {
      const target = new URL('./#/avisos', self.registration.scope).href;
      for (const client of clients) {
        if ('focus' in client) {
          client.navigate(target);
          return client.focus();
        }
      }
      return self.clients.openWindow(target);
    }),
  );
});
