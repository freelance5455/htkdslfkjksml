const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-BHR53x-r.js","./index-BdfxD_sR.js","./index-Bx-Fypj7.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-BdfxD_sR.js";const _=r("Share",{web:()=>t(()=>import("./web-BHR53x-r.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
