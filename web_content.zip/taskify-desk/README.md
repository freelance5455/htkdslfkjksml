# Taskify Desk

Aplicación de gestión de tareas para pequeñas oficinas: tareas, listas, tablero Kanban con límites WIP, recordatorios, modo oscuro y exportación a PDF. Funciona en **Windows** (navegador o app instalada), en **Android** (PWA instalable o APK con Capacitor) y **sin conexión**.

> **Importante – cómo guarda los datos:** todo se almacena **en el propio dispositivo** (IndexedDB). No hay servidor, cuentas de usuario ni sincronización entre dispositivos. Para pasar tus datos de un equipo a otro usa *Ajustes → Exportar copia (JSON)* e *Importar copia*.

## Tecnología

- React 19 + TypeScript + Vite (sin servidor)
- IndexedDB para el almacenamiento local, sin librerías
- Service worker propio + `manifest.webmanifest` (PWA)
- jsPDF para generar los PDF en el dispositivo
- Capacitor 7 para empaquetar la app como Android (APK)
- Vitest (pruebas unitarias) y Playwright (pruebas de interfaz, escritorio y móvil)

## Ejecutar en Windows

Requisitos: [Node.js 20 o superior](https://nodejs.org) (versión LTS). Necesitas Internet **solo** para instalar las dependencias.

**Opción rápida:** haz doble clic en `iniciar-taskify.bat`. Instala lo necesario la primera vez, compila la app y la abre en `http://localhost:4173`.

**Con la terminal (PowerShell), dentro de la carpeta del proyecto:**

```powershell
npm install
npm run build
npm run preview
```

Abre <http://localhost:4173>. Para detenerla, pulsa `Ctrl + C` en la terminal.

Para desarrollar con recarga automática: `npm run dev` y abre <http://localhost:5173> (en este modo no se registra el service worker).

### Instalarla como aplicación de Windows

Con la app abierta en **Edge** o **Chrome**: icono de instalar en la barra de direcciones (o menú ⋯ → *Aplicaciones → Instalar este sitio como aplicación*). Se abre en su propia ventana y aparece en el menú Inicio. También hay un botón *Instalar Taskify Desk* en *Ajustes* cuando el navegador lo permite.

> Si cierras la terminal, el servidor local se detiene y la dirección `localhost:4173` deja de responder. Una vez instalada la PWA y visitada con conexión, **sigue funcionando sin servidor** gracias al service worker (ver «Sin conexión»). Si prefieres no depender de tu portátil, sube la carpeta `dist` a cualquier alojamiento estático gratuito (GitHub Pages, Netlify…).

## Instalar en Android

Hay dos caminos. El **APK** no puede generarse en este entorno (ver más abajo), así que tienes que compilarlo tú o con GitHub.

### A) PWA (sin APK)

Chrome en Android **solo permite instalar una PWA desde una dirección HTTPS** (o `localhost`). Un `http://192.168.x.x` abre la app, pero no la instala. Tienes dos formas:

1. **Alojarla con HTTPS (lo más sencillo).** Ejecuta `npm run build` y sube el contenido de la carpeta `dist` a un alojamiento estático gratuito (por ejemplo, arrastrando `dist` a [Netlify Drop](https://app.netlify.com/drop) o con GitHub Pages). Abre la dirección HTTPS en Chrome del móvil → menú ⋮ → **Instalar aplicación**. Hace falta Internet **solo esa primera vez**.
2. **Por USB con tu portátil.** Activa *Depuración USB* en el móvil, conéctalo y ejecuta (con `adb` instalado) `adb reverse tcp:4173 tcp:4173`; con `npm run preview` en marcha, abre `http://localhost:4173` en Chrome del móvil e instálala.

### B) APK con Capacitor

Requisitos: Android Studio (incluye JDK 21 y el SDK de Android).

```powershell
npm install
npm run android:sync     # compila la web y la copia al proyecto Android
npm run android:open     # abre Android Studio
```

En Android Studio: espera a que termine *Gradle Sync* → menú **Build → Build Bundle(s) / APK(s) → Build APK(s)**. El archivo queda en `android\app\build\outputs\apk\debug\app-debug.apk`. Cópialo al móvil y ábrelo (permite «instalar apps de orígenes desconocidos» cuando lo pida).

Por línea de comandos (con JDK 21 y `ANDROID_HOME` configurado): `cd android` y `.\gradlew.bat assembleDebug`.

**Sin instalar nada: GitHub genera el APK.** Sube el proyecto a un repositorio de GitHub, entra en la pestaña **Actions → «Generar APK de Android» → Run workflow** y descarga `taskify-desk-apk` de la sección *Artifacts* cuando termine (unos 5 minutos). El flujo está en `.github/workflows/android-apk.yml`.

El APK generado es de **depuración** (se instala directamente, pero no sirve para publicar en Google Play; para eso hace falta firmarlo con tu propia clave).

## Sin conexión

- La **primera vez** necesita Internet: para instalar dependencias (Windows) o para cargar la PWA desde HTTPS (Android). El APK no necesita Internet nunca (la app va dentro).
- Tras esa primera visita, el service worker guarda todos los archivos de la app. Después puedes abrirla, consultar, crear, editar y completar tareas, usar el tablero, generar PDF y exportar copias **sin conexión**; los datos se guardan en el dispositivo.
- Verás la etiqueta «Sin conexión» arriba cuando no haya red.
- Si cambias a una versión nueva de la app, se actualiza en la siguiente visita con conexión. Tus datos no se tocan.
- **No borres los datos del sitio/navegador:** eliminarías tus tareas. Haz copias de seguridad desde Ajustes.

## Recordatorios

- Se comprueban al abrir la app y cada minuto mientras esté abierta, según *Ajustes* (antelación de 1, 4, 24 o 48 h; avisar de atrasadas). Aparecen en *Avisos*, con contador y botón «Marcar como leído». No se duplican: un aviso es único por tarea, tipo y fecha límite.
- **PWA / navegador:** si activas «Notificaciones del sistema» y concedes el permiso, se muestra una notificación del sistema **mientras la app esté abierta** (aunque esté en segundo plano). No hay notificaciones push desde servidor, así que **con la app cerrada no suena nada**.
- **App Android (APK):** se programan notificaciones locales en el teléfono que pueden sonar con la app cerrada. En Android 12+ puede hacer falta conceder «Alarmas y recordatorios» para que lleguen a la hora exacta; si no, Android puede retrasarlas unos minutos. *Esta parte no ha podido probarse en un dispositivo real* (ver «Estado»).

## Pruebas

```powershell
npm run typecheck   # comprobación de tipos
npm test            # pruebas unitarias (Vitest): WIP, filtros, recordatorios, almacenamiento
npx playwright install chromium   # solo la primera vez
npm run test:e2e    # pruebas de interfaz en escritorio y móvil, incluido modo sin conexión y PDF
```

## Estructura

```
src/
  domain/      reglas puras: tipos, validación, WIP, filtros, recordatorios (con pruebas)
  storage/     IndexedDB, store de la aplicación (operaciones + persistencia), datos demo
  services/    PDF, notificaciones, archivos (descarga / compartir en Android)
  components/  AppShell, formularios, iconos, diálogos
  pages/       Panel, Mis tareas, Listas, Tablero, Avisos, Ajustes
  hooks/       contexto de la app, enrutado por hash, tema
  styles/      CSS con tema claro/oscuro y diseño adaptable
public/        manifest.webmanifest, sw.js, iconos
android/       proyecto Android de Capacitor
tests/e2e/     pruebas de interfaz con Playwright
```

Los datos de demostración se cargan **una sola vez** en el primer arranque (siete tareas del proyecto «Proyecto Taskify» distribuidas en las cinco columnas, más una tarea en la lista «Oficina»). Para volver a ellos: *Ajustes → Restaurar datos de demostración* (borra tus datos actuales).

Los iconos PNG ya vienen generados desde `public/icons/icon.svg`. Si cambias el SVG: `npm i -D sharp` y `npm run icons`.

## Estado de las funciones

Implementadas y probadas (pruebas unitarias y de interfaz automatizadas): crear, editar, completar y eliminar tareas · listas · tablero Kanban de 5 columnas con arrastrar y soltar y botón «Mover a…» · límites WIP (Desarrollo 2, Pruebas/QA 1), también al crear tarjetas · prioridades y fechas límite · pendientes, próximas y atrasadas · buscador, filtros y ordenación · avisos internos sin duplicados · modo claro/oscuro/sistema · interfaz en español adaptable a móvil y escritorio · datos persistentes · copia de seguridad JSON · exportación a PDF (listado e informe) · PWA con manifest, service worker e iconos · funcionamiento sin conexión.

**No implementado / no verificado:**

- **Sin sincronización entre dispositivos ni cuentas de usuario**; no hay asignación a «compañeros» reales: el responsable es solo un nombre de texto.
- **No hay APK compilado** (no se pudo en el entorno de desarrollo). El proyecto Android está preparado y sincronizado, pero **no se ha ejecutado en un móvil ni en un emulador**: la compilación, las notificaciones locales de Android y el menú «Compartir» al exportar PDF/JSON en la app nativa no están probados.
- **La instalación de la PWA en Android y en Windows no se ha probado en dispositivos reales**; sí se ha comprobado el manifiesto, los iconos, el service worker y el uso sin conexión con un navegador automatizado (Chromium).
- No hay notificaciones push con la app cerrada en la versión PWA.
- No se ha probado en iPhone/Safari.
- La app no está pensada para varias personas editando a la vez.
