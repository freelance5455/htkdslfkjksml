@echo off
chcp 65001 >nul
title Taskify Desk
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo No se encontro Node.js. Instalalo desde https://nodejs.org ^(version LTS^) y vuelve a abrir este archivo.
  pause
  exit /b 1
)

if not exist node_modules (
  echo Instalando dependencias ^(solo la primera vez, necesita Internet^)...
  call npm install
  if errorlevel 1 ( echo Fallo la instalacion. & pause & exit /b 1 )
)

if not exist dist (
  echo Preparando la aplicacion...
  call npm run build
  if errorlevel 1 ( echo Fallo la compilacion. & pause & exit /b 1 )
)

echo.
echo Taskify Desk se abrira en http://localhost:4173
echo Para cerrar la aplicacion, cierra esta ventana o pulsa Ctrl+C.
echo.
start "" http://localhost:4173
call npm run preview
pause
