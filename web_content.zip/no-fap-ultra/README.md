# NO FAP ULTRA

Offline-first habit-recovery app: HTML/CSS/JS UI wrapped as an Android app with Capacitor. No backend, no accounts, no paid services; all data stays on the device.

## Run in a browser (fastest check)
    npm install
    npm run dev          # serves ./www  (ES modules need http://, not file://)

## Build the Android APK
Requirements: Node 18+, Android Studio (SDK 34), JDK 17.

    npm install
    npx cap add android
    npx cap sync android
    npx cap open android          # opens Android Studio

In Android Studio: Build > Build Bundle(s) / APK(s) > Build APK(s). Debug APK lands in
`android/app/build/outputs/apk/debug/`. For release: Build > Generate Signed Bundle/APK and create your own keystore (keep it private).

Notification permission: Android 13+ asks at runtime (handled in code). Add nothing else to the manifest; Capacitor's plugin declares what it needs. Scheduled notifications are queued 14 days ahead and refreshed each time the app opens.

## Structure
    www/index.html, css/style.css
    www/js/store.js     persistent state, real-timestamp streak/pause/setback logic, badge unlocking
    www/js/badges.js    12 badges + original generated SVG characters
    www/js/content.js   articles, stories, lessons, 365-day journey pools, messages, challenges  <- add content here
    www/js/notify.js    local notifications (Capacitor plugin; web fallback)
    www/js/i18n.js      English / Bengali UI strings
    www/js/app.js       all screens and interactions
    test/logic.test.mjs core logic tests   (npm test)

## Adding content
Push objects into ARTICLES / STORIES / LESSONS in content.js, or call `addPack({articles:[...]})` with JSON. Lists, search, bookmarks and read-tracking pick them up automatically.

## Dependencies
Capacitor core/android/local-notifications (free, MIT). No API keys. No admin backend is included: content ships inside the app, so no secrets exist to protect.
Storage is WebView localStorage (survives restarts; cleared if the user clears app data, so use the in-app Export backup).

## Notifications on Android (important)
- Must be built as the Android app (`npx cap sync android`). In a browser/PWA, notifications cannot arrive while the page is closed.
- In the app: Home > "চালু করুন" (or Menu > Notifications), accept the permission, and allow "Alarms & reminders" if Android asks.
- Phone settings: Apps > NO FAP ULTRA > Battery > Unrestricted (Xiaomi/Oppo/Vivo/Realme/Samsung also need "Autostart"/"Allow background activity").
- Use the 🔎 পরীক্ষা button in Notifications to see permission, exact-alarm status and how many are scheduled.
