const D = { mode: 'dark', tx: '#f3f7f7', mut: '#9fb4b3', gold: '#ffd24a' };
const Lt = { mode: 'light', tx: '#0b1f1e', mut: '#4b6361', gold: '#b45309' };
export const THEMES = [
  { id: 'amoled', name: 'AMOLED কালো', ...D, bg: '#000000', bg2: '#06201f', ac: '#14b8a6' },
  { id: 'ocean', name: 'মহাসাগর', ...D, bg: '#020b1a', bg2: '#06305a', ac: '#38bdf8' },
  { id: 'forest', name: 'বন', ...D, bg: '#020d06', bg2: '#0b3a1c', ac: '#4ade80' },
  { id: 'royal', name: 'রাজকীয়', ...D, bg: '#0a0414', bg2: '#2e1065', ac: '#a78bfa', gold: '#fcd34d' },
  { id: 'sunset', name: 'সূর্যাস্ত', ...D, bg: '#140603', bg2: '#5a1a0b', ac: '#fb923c', gold: '#fde047' },
  { id: 'rose', name: 'গোলাপ', ...D, bg: '#14040b', bg2: '#500724', ac: '#fb7185', gold: '#fcd34d' },
  { id: 'midnight', name: 'মধ্যরাত', ...D, bg: '#05070f', bg2: '#172554', ac: '#60a5fa', gold: '#fbbf24' },
  { id: 'goldlux', name: 'গোল্ড লাক্স', ...D, bg: '#0c0a03', bg2: '#3a2c05', ac: '#facc15', gold: '#fde68a' },
  { id: 'slate', name: 'স্লেট', ...D, bg: '#0f1115', bg2: '#1f2430', ac: '#94a3b8' },
  { id: 'mint', name: 'লাইট মিন্ট', ...Lt, bg: '#f2f7f6', bg2: '#dff1ee', ac: '#0d9488' },
  { id: 'sky', name: 'লাইট স্কাই', ...Lt, bg: '#f1f6fd', bg2: '#dbeafe', ac: '#2563eb' },
  { id: 'blush', name: 'লাইট রোজ', ...Lt, bg: '#fdf2f5', bg2: '#fce7f3', ac: '#e11d48' }
];
export function onAc(hex) {
  const n = parseInt(hex.slice(1), 16), r = n >> 16 & 255, g = n >> 8 & 255, b = n & 255;
  return (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255 > 0.55 ? '#00110f' : '#ffffff';
}
