// Local notifications. Android: @capacitor/local-notifications (works with the app closed). Browser: only while the page is open.
import { get, save } from './store.js';
import { MESSAGES } from './content.js';

const LN = () => window.Capacitor?.Plugins?.LocalNotifications;
export const isNative = () => !!(window.Capacitor?.isNativePlatform?.() && LN());
const BASE = 9000, DAYS = 30;
const CATS = ['morning', 'afternoon', 'evening', 'night'];

export async function ask() {
  const p = LN();
  if (p) {
    let r = await p.checkPermissions();
    if (r.display !== 'granted') r = await p.requestPermissions();
    if (r.display === 'granted') await ensureExact(p);
    return r.display === 'granted';
  }
  if (!('Notification' in window)) return false;
  return (await Notification.requestPermission()) === 'granted';
}
// Android 12+: exact alarms need user approval, otherwise delivery can be delayed.
async function ensureExact(p) {
  try {
    if (p.checkExactNotificationSetting) {
      const s = await p.checkExactNotificationSetting();
      if (s.exact_alarm !== 'granted' && p.changeExactNotificationSetting) await p.changeExactNotificationSetting();
    }
  } catch { /* older Android: not needed */ }
}
export function log(title, body) {
  const h = get().notif.history; h.unshift({ t: Date.now(), title, body }); h.length = Math.min(h.length, 100); save();
}
const pick = (arr, seed) => arr[seed % arr.length];

// Schedules the next 30 days (one per enabled category per day) so messages rotate. Runs on every app open and after any change.
export async function reschedule() {
  const n = get().notif, p = LN();
  if (!p) return 0;
  try {
    const pend = await p.getPending();
    const mine = pend.notifications.filter(x => x.id >= BASE && x.id < BASE + 5000);
    if (mine.length) await p.cancel({ notifications: mine });
  } catch { /* ignore */ }
  if (!n.enabled) return 0;
  const list = [], now = new Date();
  for (let d = 0; d < DAYS; d++) {
    CATS.forEach((c, ci) => {
      if (!n.on[c]) return;
      const [h, m] = n.times[c].split(':').map(Number);
      const at = new Date(now.getFullYear(), now.getMonth(), now.getDate() + d, h, m, 0);
      if (at <= now) return;
      let body = pick(MESSAGES[c], d + ci);
      if (n.custom && ci === 0 && d % 2 === 1) body = n.custom;
      list.push({ id: BASE + d * 10 + ci, title: 'NO FAP ULTRA', body, largeBody: body, schedule: { at, allowWhileIdle: true }, channelId: 'nfu' });
    });
  }
  try {
    if (p.createChannel) await p.createChannel({ id: 'nfu', name: 'Daily motivation', description: 'Daily motivational reminders', importance: 4, visibility: 1, vibration: !!n.sound });
    if (list.length) await p.schedule({ notifications: list });
  } catch (e) { console.warn('schedule failed', e); return -1; }
  return list.length;
}

export async function notifyNow(title, body) {
  log(title, body);
  const p = LN();
  if (p) {
    try { await p.schedule({ notifications: [{ id: 8000 + Math.floor(Math.random() * 900), title, body, channelId: 'nfu', schedule: { at: new Date(Date.now() + 1500), allowWhileIdle: true } }] }); } catch { /* ignore */ }
    return;
  }
  if ('Notification' in window && Notification.permission === 'granted') new Notification(title, { body });
}

export async function diagnose() {
  const p = LN(), n = get().notif, out = { native: isNative(), enabled: n.enabled, permission: 'n/a', exact: 'n/a', pending: 0 };
  if (p) {
    try { out.permission = (await p.checkPermissions()).display; } catch { out.permission = 'error'; }
    try { if (p.checkExactNotificationSetting) out.exact = (await p.checkExactNotificationSetting()).exact_alarm; } catch { /* */ }
    try { out.pending = (await p.getPending()).notifications.length; } catch { /* */ }
  } else if ('Notification' in window) out.permission = Notification.permission;
  return out;
}

// Browser fallback ticker (only while page is open; cannot work in background)
let last = '';
export function webTicker() {
  if (LN()) return;
  setInterval(() => {
    const n = get().notif; if (!n.enabled) return;
    const d = new Date(), hm = String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0'), key = d.toDateString() + hm;
    if (key === last) return;
    for (const c of CATS) if (n.on[c] && n.times[c] === hm) { last = key; notifyNow('NO FAP ULTRA', pick(MESSAGES[c], d.getDate())); }
  }, 20000);
}
