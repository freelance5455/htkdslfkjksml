// Local notifications. Uses @capacitor/local-notifications on Android; falls back to the Web Notification API while the page is open.
import { get, save } from './store.js';
import { MESSAGES } from './content.js';

const LN = () => window.Capacitor?.Plugins?.LocalNotifications;
const BASE = 9000;
const CATS = ['morning', 'afternoon', 'evening', 'night'];

export async function ask() {
  const p = LN();
  if (p) { const r = await p.requestPermissions(); return r.display === 'granted'; }
  if (!('Notification' in window)) return false;
  return (await Notification.requestPermission()) === 'granted';
}
export function log(title, body) {
  const h = get().notif.history; h.unshift({ t: Date.now(), title, body }); h.length = Math.min(h.length, 100); save();
}
const pick = (arr, seed) => arr[seed % arr.length];

// Schedules the next 14 days (one per enabled category per day) so messages rotate. Call on app open and after setting changes.
export async function reschedule() {
  const n = get().notif, p = LN();
  if (p) {
    try {
      const pend = await p.getPending();
      if (pend.notifications.length) await p.cancel({ notifications: pend.notifications.filter(x => x.id >= BASE && x.id < BASE + 1000) });
    } catch { /* ignore */ }
  }
  if (!n.enabled || !p) return;
  const list = [], now = new Date();
  for (let d = 0; d < 14; d++) {
    CATS.forEach((c, ci) => {
      if (!n.on[c]) return;
      const [h, m] = n.times[c].split(':').map(Number);
      const at = new Date(now.getFullYear(), now.getMonth(), now.getDate() + d, h, m, 0);
      if (at <= now) return;
      let body = pick(MESSAGES[c], d + ci);
      if (n.custom && ci === 0 && d % 2 === 1) body = n.custom;
      list.push({ id: BASE + d * 10 + ci, title: 'NO FAP ULTRA', body, schedule: { at, allowWhileIdle: true }, channelId: 'nfu', smallIcon: 'ic_stat_icon_config_sample' });
    });
  }
  try {
    if (p.createChannel) await p.createChannel({ id: 'nfu', name: 'Daily motivation', importance: 3, sound: n.sound ? 'default' : undefined, vibration: n.sound });
    if (list.length) await p.schedule({ notifications: list });
  } catch (e) { console.warn('schedule failed', e); }
}

export async function notifyNow(title, body) {
  log(title, body);
  const p = LN();
  if (p) { try { await p.schedule({ notifications: [{ id: Math.floor(Math.random() * 8000), title, body, schedule: { at: new Date(Date.now() + 500) } }] }); } catch { /* ignore */ } return; }
  if ('Notification' in window && Notification.permission === 'granted') new Notification(title, { body });
}

// Web fallback ticker (only runs while page open)
let last = '';
export function webTicker() {
  if (LN()) return;
  setInterval(() => {
    const n = get().notif; if (!n.enabled) return;
    const d = new Date(), hm = String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0'), key = d.toDateString() + hm;
    if (key === last) return;
    for (const c of CATS) if (n.on[c] && n.times[c] === hm) { last = key; notifyNow('NO FAP ULTRA', pick(MESSAGES[c], d.getDate())); }
  }, 20000);
}
