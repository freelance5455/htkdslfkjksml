// 12 badges with original SVG character art (generated, no third-party assets).
export const BADGES = [
  { id: 'clown', min: 0, en: 'Clown', bn: 'ক্লাউন', c: ['#ff5f6d', '#ffc371'],
    desc: 'Every journey starts here. Playful, honest, and ready to begin.' },
  { id: 'noob', min: 1, en: 'Noob', bn: 'নুব', c: ['#56ab2f', '#a8e063'],
    desc: 'Day one is done. The hardest step, taking it, is behind you.' },
  { id: 'novice', min: 3, en: 'Novice', bn: 'নবিস', c: ['#4facfe', '#00f2fe'],
    desc: 'Three days of choices made on purpose. A pattern is forming.' },
  { id: 'average', min: 7, en: 'Average', bn: 'অ্যাভারেজ', c: ['#f7971e', '#ffd200'],
    desc: 'A full week. You are building a baseline of consistency.' },
  { id: 'advanced', min: 15, en: 'Advanced', bn: 'অ্যাডভান্সড', c: ['#e65c00', '#f9d423'],
    desc: 'Two weeks and more. Your routines are starting to carry you.' },
  { id: 'sigma', min: 30, en: 'Sigma', bn: 'সিগমা', c: ['#485563', '#29323c'],
    desc: 'One month of steady discipline. Quiet, focused, independent.' },
  { id: 'chad', min: 45, en: 'Chad', bn: 'চ্যাড', c: ['#2193b0', '#6dd5ed'],
    desc: 'Forty-five days. Confidence built from kept promises.' },
  { id: 'absolute', min: 60, en: 'Absolute Chad', bn: 'অ্যাবসোলিউট চ্যাড', c: ['#8e2de2', '#4a00e0'],
    desc: 'Sixty days. Discipline has become part of who you are.' },
  { id: 'giga', min: 120, en: 'Giga Chad', bn: 'গিগা চ্যাড', c: ['#f12711', '#f5af19'],
    desc: 'Four months of sustained effort. Genuinely rare commitment.' },
  { id: 'legend', min: 180, en: 'Legend', bn: 'লিজেন্ড', c: ['#b79891', '#94716b'],
    desc: 'Half a year. People will be able to learn from your story.' },
  { id: 'master', min: 365, en: 'Master', bn: 'মাস্টার', c: ['#00c9ff', '#92fe9d'],
    desc: 'A full year of intention. Mastery of habits, not perfection.' },
  { id: 'immortal', min: 500, en: 'Immortal', bn: 'ইমরটাল', c: ['#fdc830', '#f37335'],
    desc: 'Five hundred days. Your discipline outlasts any single day.' }
];

const emblem = {
  clown: `<circle cx="35" cy="22" r="9" fill="#ff4d6d"/><circle cx="50" cy="17" r="10" fill="#4cc9f0"/><circle cx="65" cy="22" r="9" fill="#ffd60a"/><circle cx="50" cy="48" r="4" fill="#e63946"/>`,
  noob: `<path d="M50 28 V14" stroke="#2d6a2d" stroke-width="3"/><path d="M50 16 q-14 -8 -16 4 q10 4 16 -4z M50 16 q14 -8 16 4 q-10 4 -16 -4z" fill="#3ddc84"/>`,
  novice: `<path d="M50 70 l-12 -4 v-10 q12 2 12 12 q0 -10 12 -12 v10z" fill="#fff" opacity=".85"/>`,
  average: `<path d="M50 6 l4 9 10 1 -8 7 3 10 -9 -6 -9 6 3 -10 -8 -7 10 -1z" fill="#fff3b0"/>`,
  advanced: `<path d="M54 62 l-10 12 h8 l-4 12 14 -16 h-9z" fill="#fff59d"/>`,
  sigma: `<path d="M44 6 a12 12 0 1 0 12 18 a10 10 0 1 1 -12 -18z" fill="#e0e6ee"/><rect x="36" y="38" width="28" height="5" rx="2" fill="#111"/>`,
  chad: `<rect x="35" y="37" width="30" height="7" rx="3" fill="#0b1b2b"/><rect x="40" y="58" width="20" height="5" rx="2" fill="#c68d5e"/>`,
  absolute: `<path d="M34 24 l5 -14 6 9 5 -12 5 12 6 -9 5 14z" fill="#ffd60a"/><rect x="36" y="38" width="28" height="6" rx="3" fill="#0b0b1b"/>`,
  giga: `<path d="M50 4 q10 10 4 18 q10 -4 10 8 q-14 -4 -14 -26 q-14 22 -14 26 q-10 -12 4 -18 q-6 -8 10 -8z" fill="#ffb703"/><rect x="34" y="38" width="32" height="6" rx="3" fill="#2b0a00"/>`,
  legend: `<path d="M26 40 q-4 -24 18 -30 M74 40 q4 -24 -18 -30" stroke="#ffe08a" stroke-width="4" fill="none" stroke-linecap="round"/><path d="M50 10 l3 7 8 .6 -6 5 2 8 -7 -4 -7 4 2 -8 -6 -5 8 -.6z" fill="#fff"/>`,
  master: `<path d="M50 4 l12 12 -12 14 -12 -14z" fill="#b9f6ff" stroke="#fff" stroke-width="1.5"/><path d="M26 66 q24 22 48 0 v18 h-48z" fill="#0aa" opacity=".7"/>`,
  immortal: `<ellipse cx="50" cy="12" rx="20" ry="5" fill="none" stroke="#fff3b0" stroke-width="3"/><path d="M36 74 c-12 -10 6 -18 14 0 c8 -18 26 -10 14 0 c-8 8 -22 -2 -28 0z" fill="none" stroke="#fff" stroke-width="3"/>`
};

let uid = 0;
export function avatar(b, locked = false) {
  const id = 'g' + (++uid), ring = Math.min(5, 1 + Math.floor(BADGES.indexOf(b) / 2.5));
  const rings = Array.from({ length: ring }, (_, i) =>
    `<circle cx="50" cy="50" r="${48 - i * 2.2}" fill="none" stroke="#fff" stroke-opacity="${0.5 - i * 0.08}" stroke-width=".9"/>`).join('');
  return `<svg class="av ${locked ? 'locked' : ''}" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="${b.en}">
  <defs><linearGradient id="${id}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${b.c[0]}"/><stop offset="1" stop-color="${b.c[1]}"/></linearGradient>
  <clipPath id="c${id}"><circle cx="50" cy="50" r="48"/></clipPath></defs>
  <circle cx="50" cy="50" r="49" fill="url(#${id})"/>
  <g clip-path="url(#c${id})">
    <path d="M12 100 q4 -26 38 -26 q34 0 38 26z" fill="#1c2733"/>
    <rect x="44" y="58" width="12" height="14" fill="#e8b98f"/>
    <ellipse cx="50" cy="46" rx="19" ry="22" fill="#f1c9a0"/>
    <path d="M31 40 q2 -20 19 -20 q17 0 19 20 q-8 -10 -19 -10 q-11 0 -19 10z" fill="#3b2a1e"/>
    <circle cx="43" cy="46" r="2" fill="#222"/><circle cx="57" cy="46" r="2" fill="#222"/>
    <path d="M44 56 q6 4 12 0" stroke="#7a3b2a" stroke-width="2" fill="none" stroke-linecap="round"/>
    ${emblem[b.id]}
  </g>${rings}</svg>`;
}
