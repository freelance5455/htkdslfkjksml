// UI strings (en / bn). Fallback to English.
import { get } from './store.js';

const D = {
  home: ['Home', 'হোম'], history: ['History', 'ইতিহাস'], challenges: ['Challenges', 'চ্যালেঞ্জ'],
  library: ['লাইব্রেরি', 'লাইব্রেরি'], profile: ['Profile', 'প্রোফাইল'],
  currentBadge: ['Current Badge', 'বর্তমান ব্যাজ'], next: ['Next', 'পরবর্তী'], inDays: ['in {n} days', '{n} দিন বাকি'],
  days: ['Days', 'দিন'], start: ['Start Challenge', 'চ্যালেঞ্জ শুরু'], pause: ['Pause', 'বিরতি'], resume: ['Resume', 'চালু'],
  reset: ['Reset', 'রিসেট'], setback: ['Report setback', 'সেটব্যাক জানান'], sos: ['এখনই সাহায্য দরকার (I NEED HELP)', 'এখনই সাহায্য দরকার'],
  motivation: ['আজকের অনুপ্রেরণা (Daily motivation)', 'আজকের অনুপ্রেরণা'], emergency: ['Emergency', 'জরুরি'], daily: ['দৈনিক চ্যালেঞ্জ (Daily)', 'দৈনিক চ্যালেঞ্জ'],
  story: ['গল্প পড়ুন', 'গল্প পড়ুন'], focus: ['Get Focus', 'ফোকাস'], badges: ['All Badges', 'সব ব্যাজ'],
  submit: ['Submit', 'জমা দিন'], cancel: ['Cancel', 'বাতিল'], confirm: ['Confirm', 'নিশ্চিত'], save: ['Save', 'সংরক্ষণ'],
  delete: ['Delete', 'মুছুন'], edit: ['Edit', 'সম্পাদনা'], close: ['Close', 'বন্ধ'], search: ['Search…', 'খুঁজুন…'],
  sbTitle: ['আপনার যাত্রায় একটি setback এসেছে। কী ঘটেছিল বুঝে নিই। (Your journey had a setback.)', 'আপনার যাত্রায় একটি setback এসেছে। কী ঘটেছিল বুঝে নিই।'],
  sbWhat: ['কী ঘটেছিল? What happened? (আবশ্যক)', 'কী ঘটেছিল? (আবশ্যক)'], sbTrigger: ['কী ট্রিগার করেছিল? (What triggered you?)', 'কী ট্রিগার করেছিল?'],
  sbFeel: ['আপনার কেমন লাগছিল? (How were you feeling?)', 'আপনার কেমন লাগছিল?'], sbTime: ['কখন ঘটেছিল? (What time?)', 'কখন ঘটেছিল?'],
  sbNext: ['পরেরবার আলাদা কী করতে পারেন? (Next time?)', 'পরেরবার আলাদা কী করতে পারেন?'],
  sbConfirm: ['এটি বর্তমান streak শেষ করবে। আপনার ইতিহাস ও আনলক করা ব্যাজ থাকবে। এগিয়ে যাবেন? (This ends your current streak; history and badges stay safe.)', 'এটি বর্তমান streak শেষ করবে। আপনার ইতিহাস ও আনলক করা ব্যাজ থাকবে। এগিয়ে যাবেন?'],
  sbSupport: ['একটি setback মানেই সব শেষ নয়। আবার শুরু করুন। আপনার উন্নতির যাত্রা এখনো চলমান।', 'একটি setback মানেই সব শেষ নয়। আবার শুরু করুন। আপনার উন্নতির যাত্রা এখনো চলমান।'],
  current: ['Current streak', 'বর্তমান streak'], longest: ['Longest streak', 'সর্বোচ্চ streak'], total: ['Total days', 'মোট দিন'],
  attempts: ['Attempts', 'চেষ্টা'], setbacks: ['Setbacks', 'সেটব্যাক'], week: ['Week', 'সপ্তাহ'], month: ['Month', 'মাস'], year: ['Year', 'বছর'],
  xp: ['XP', 'XP'], level: ['Level', 'লেভেল'], weekly: ['Weekly', 'সাপ্তাহিক'], monthly: ['Monthly', 'মাসিক'], dailyT: ['Daily', 'দৈনিক'],
  done: ['Done', 'সম্পন্ন'], locked: ['{n} days to go', 'আরও {n} দিন'], unlockedOn: ['Unlocked {d}', 'আনলক {d}'],
  menu: ['Menu', 'মেনু'], stats: ['Statistics', 'পরিসংখ্যান'], diary: ['ডায়েরি (Diary)', 'ডায়েরি'], journey: ['৩৬৫ দিনের রূপান্তর', '৩৬৫ দিনের রূপান্তর'],
  notifs: ['Notifications', 'নোটিফিকেশন'], settings: ['Settings', 'সেটিংস'], about: ['About', 'সম্পর্কে'],
  newEntry: ['New entry', 'নতুন এন্ট্রি'], mood: ['Mood', 'মেজাজ'], theme: ['Theme', 'থিম'], language: ['Language', 'ভাষা'],
  dark: ['Dark', 'ডার্ক'], light: ['Light', 'লাইট'], accent: ['Accent', 'অ্যাকসেন্ট'], export: ['Export data', 'ডেটা এক্সপোর্ট'],
  restore: ['Restore backup', 'ব্যাকআপ রিস্টোর'], wipe: ['Reset all data', 'সব ডেটা মুছুন'], pin: ['App PIN lock', 'অ্যাপ PIN লক'],
  favorites: ['Favorites', 'পছন্দের'], read: ['Read', 'পঠিত'], mark: ['Mark as read', 'পঠিত করুন'], tagline: ['CONTROL YOUR HABITS. BUILD YOUR FUTURE.', 'অভ্যাস নিয়ন্ত্রণ করুন। ভবিষ্যৎ গড়ুন।'],
  noStreak: ['প্রস্তুত হলে শুরু চাপুন।', 'প্রস্তুত হলে শুরু চাপুন।'], none: ['Nothing here yet.', 'এখনো কিছু নেই।']
};
export function t(k, vars = {}) {
  const e = D[k]; if (!e) return k;
  let s = (get().lang === 'bn' ? e[1] : e[0]) || e[0];
  for (const x in vars) s = s.replace('{' + x + '}', vars[x]);
  return s;
}
export const tr = (en, bn) => (get().lang === 'bn' && bn ? bn : en);
