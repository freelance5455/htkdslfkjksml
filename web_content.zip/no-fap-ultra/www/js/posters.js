// প্রেরণার ছবি: canvas-এ আঁকা মৌলিক পোস্টার (কোনো বাইরের ছবি ব্যবহার হয়নি)।
export const QUOTES = [
  ['আজকের একটি সিদ্ধান্ত আগামীকালের তোমাকে গড়ে।', '🌅', ['#f7971e', '#b91c1c']], ['তাগিদ ওঠে আর নামে, তুমি অটল থাকো।', '🌊', ['#0ea5e9', '#1e3a8a']],
  ['যে নিজেকে জয় করে, সে-ই সবচেয়ে বড় বিজয়ী।', '🦁', ['#f59e0b', '#7c2d12']], ['ছোট ছোট জয় মিলেই বড় পরিবর্তন আসে।', '⛰️', ['#10b981', '#064e3b']],
  ['সুস্থ শরীর, শান্ত মন, স্পষ্ট লক্ষ্য।', '💪', ['#14b8a6', '#134e4a']], ['পিছলে গেলে থেমো না, আবার উঠে দাঁড়াও।', '🔥', ['#ef4444', '#7f1d1d']],
  ['ভালো ঘুম, ব্যায়াম আর মনোযোগ: এই তিনেই তোমার শক্তি।', '🌙', ['#6366f1', '#1e1b4b']], ['তুমি তোমার অভ্যাসের চেয়ে অনেক বড়।', '👑', ['#eab308', '#422006']],
  ['নিজের কাছে করা প্রতিজ্ঞা রাখো।', '🤝', ['#8b5cf6', '#3b0764']], ['শৃঙ্খলা মানে নিজেকে ভালোবাসা।', '❤️', ['#ec4899', '#831843']],
  ['ধৈর্য ধরো, ফল আসবেই।', '🌱', ['#84cc16', '#14532d']], ['নতুন দিন, নতুন শুরু, নতুন তুমি।', '⭐', ['#38bdf8', '#312e81']]
];
const FONT = "'Noto Sans Bengali','Hind Siliguri','Siyam Rupali',sans-serif";
export function drawPoster(i, w = 540, h = 720) {
  const [q, ico, c] = QUOTES[i % QUOTES.length], cv = document.createElement('canvas'); cv.width = w; cv.height = h;
  const x = cv.getContext('2d'), k = w / 540, g = x.createLinearGradient(0, 0, w, h);
  g.addColorStop(0, c[0]); g.addColorStop(1, c[1]); x.fillStyle = g; x.fillRect(0, 0, w, h);
  x.globalAlpha = .12; x.fillStyle = '#fff';
  [[.85, .12, .35], [.1, .85, .45], [.9, .7, .22]].forEach(([a, b, r]) => { x.beginPath(); x.arc(a * w, b * h, r * w, 0, 7); x.fill(); });
  x.globalAlpha = 1; x.textAlign = 'center'; x.font = `${150 * k}px ${FONT}`; x.fillText(ico, w / 2, h * .28);
  x.fillStyle = '#fff'; x.font = `800 ${40 * k}px ${FONT}`; x.shadowColor = 'rgba(0,0,0,.5)'; x.shadowBlur = 12 * k;
  const words = q.split(' '), lines = []; let cur = '';
  for (const wd of words) { const t = cur ? cur + ' ' + wd : wd; if (x.measureText(t).width > w * .82 && cur) { lines.push(cur); cur = wd; } else cur = t; }
  lines.push(cur); lines.forEach((l, n) => x.fillText(l, w / 2, h * .5 + n * 58 * k));
  x.shadowBlur = 0; x.fillStyle = '#ffd24a'; x.font = `700 ${22 * k}px sans-serif`; x.fillText('NO FAP ULTRA', w / 2, h * .94);
  return cv;
}
