import * as S from './store.js';
import { BADGES, avatar } from './badges.js';
import { t, tr } from './i18n.js';
import * as C from './content.js';
import * as N from './notify.js';

const st = S.get;
const $ = (q, r = document) => r.querySelector(q);
const esc = (x) => String(x ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const pad = (n) => String(n).padStart(2, '0');
const fmtDate = (ts) => new Date(ts).toLocaleDateString(st().lang === 'bn' ? 'bn-BD' : 'en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
const fmtDT = (ts) => new Date(ts).toLocaleString(st().lang === 'bn' ? 'bn-BD' : 'en-GB', { dateStyle: 'medium', timeStyle: 'short' });
const hms = (ms) => { const s = Math.floor(ms / 1000); return `${pad(Math.floor(s % 86400 / 3600))}:${pad(Math.floor(s % 3600 / 60))}:${pad(s % 60)}`; };
const durTxt = (ms) => { const d = Math.floor(ms / S.DAY), h = Math.floor(ms % S.DAY / 3600000); return `${d}d ${h}h`; };
const bName = (b) => tr(b.en, b.bn);

let route = 'home', arg = null, tab = {}, toastT;
const app = $('#app');

// ---------- UI helpers ----------
function toast(m) { const e = $('#toast'); e.textContent = m; e.classList.add('show'); clearTimeout(toastT); toastT = setTimeout(() => e.classList.remove('show'), 2600); }
function modal(html) { const m = $('#modal'); m.innerHTML = `<div class="mb">${html}</div>`; m.classList.remove('hidden'); }
function closeModal() { $('#modal').classList.add('hidden'); $('#modal').innerHTML = ''; }
function confirmBox(msg, ok, okLabel) {
  modal(`<p>${esc(msg)}</p><div class="row sp"><button class="btn ghost" data-act="closeModal">${t('cancel')}</button><button class="btn red" id="cfOk">${okLabel || t('confirm')}</button></div>`);
  $('#cfOk').onclick = () => { closeModal(); ok(); };
}
function applyTheme() {
  const r = document.documentElement; r.dataset.theme = st().theme; r.style.setProperty('--ac', st().accent);
  r.lang = st().lang; $('#focusLbl').textContent = t('focus');
}
function confetti() {
  const c = $('#fx'), x = c.getContext('2d'); c.width = innerWidth; c.height = innerHeight;
  const ps = Array.from({ length: 140 }, () => ({ x: innerWidth / 2, y: innerHeight / 3, vx: (Math.random() - .5) * 14, vy: Math.random() * -12 - 2, s: 4 + Math.random() * 5, col: `hsl(${Math.random() * 360},90%,60%)`, r: Math.random() * 6 }));
  let f = 0;
  (function loop() { x.clearRect(0, 0, c.width, c.height); ps.forEach(p => { p.x += p.vx; p.y += p.vy; p.vy += .35; p.r += .2; x.fillStyle = p.col; x.save(); x.translate(p.x, p.y); x.rotate(p.r); x.fillRect(-p.s / 2, -p.s / 2, p.s, p.s * .6); x.restore(); });
    if (++f < 130) requestAnimationFrame(loop); else x.clearRect(0, 0, c.width, c.height); })();
}
function celebrate(b) {
  confetti(); if (navigator.vibrate) navigator.vibrate([80, 50, 80]);
  modal(`<div class="c"><h2>🏆 ${t('badges')}!</h2>${avatar(b)}<h2>${esc(bName(b))}</h2><p>${esc(b.desc)}</p><button class="btn gold" data-act="closeModal">🎉</button></div>`);
  N.notifyNow('🏆 Achievement Unlocked', `${bName(b)} — ${b.min}+ ${t('days')}`);
}

// ---------- routing ----------
const NAV = [['home', '🏠'], ['history', '🕘'], ['challenges', '✅'], ['library', '📚'], ['profile', '👤']];
function go(r, a = null, push = true) {
  route = r; arg = a; if (push) history.pushState({ r, a }, '');
  closeDrawer(); closeModal(); render(); app.scrollTop = 0;
}
window.addEventListener('popstate', (e) => { if (e.state) go(e.state.r, e.state.a, false); else go('home', null, false); });
function render() {
  const V = { home: vHome, history: vHistory, challenges: vChallenges, library: vLibrary, profile: vProfile, item: vItem, badges: vBadges, stats: vStats, focus: vFocus, diary: vDiary, journey: vJourney, notifs: vNotifs, sos: vSOS, about: vAbout };
  app.innerHTML = (V[route] || vHome)();
  const main = ['home', 'history', 'challenges', 'library', 'profile'];
  $('#nav').innerHTML = NAV.map(([k, i]) => `<button class="${(route === k || (!main.includes(route) && k === 'home' && false)) ? 'on' : ''}" data-act="go" data-to="${k}"><span>${i}</span>${t(k)}</button>`).join('');
  if (route === 'home') tickUI();
}
function closeDrawer() { $('#drawer').classList.add('hidden'); }
function openDrawer() {
  const items = [['badges', '🏅', t('badges')], ['stats', '📊', t('stats')], ['sos', '🆘', t('emergency')], ['focus', '🎯', t('focus')], ['diary', '📔', t('diary')], ['journey', '🗓️', t('journey')], ['notifs', '🔔', t('notifs')], ['profile', '⚙️', t('settings')], ['about', 'ℹ️', t('about')]];
  $('#drawerIn').innerHTML = `<h2 style="color:var(--gold)">NO FAP ULTRA</h2><p class="mut">${t('tagline')}</p>` + items.map(([k, i, l]) => `<button data-act="go" data-to="${k}"><span>${i}</span>${l}</button>`).join('');
  $('#drawer').classList.remove('hidden');
}

// ---------- HOME ----------
function vHome() {
  const S0 = st(), d = S.currentDays(), b = S.badgeForDays(d), nx = S.nextBadge(d), run = !!S0.challenge.start;
  const idx = BADGES.indexOf(b), mot = C.DAILY_MOTIVATION[Math.floor(Date.now() / S.DAY) % C.DAILY_MOTIVATION.length];
  const ctrl = !run ? `<button class="btn" data-act="start">▶ ${t('start')}</button>` :
    `<button class="btn ghost" data-act="${S0.challenge.paused ? 'resume' : 'pause'}">${S0.challenge.paused ? '▶ ' + t('resume') : '⏸ ' + t('pause')}</button>
     <button class="btn ghost" data-act="reset">↺ ${t('reset')}</button><button class="btn red" data-act="setback">⚠ ${t('setback')}</button>`;
  return `<div class="badge-card">${avatar(b)}<h2>${esc(bName(b))}</h2><div class="mut" style="color:inherit;opacity:.7">${t('currentBadge')} · ${t('level')} ${idx + 1}/${BADGES.length}</div>
    <div class="bar"><i id="bp" style="width:0%"></i></div>
    <div class="mut" style="color:inherit;opacity:.7;margin-top:6px" id="bn">${nx ? `${t('next')}: ${esc(bName(nx))}` : '★'}</div></div>
    <div class="ring"><svg viewBox="0 0 100 100"><circle cx="50" cy="50" r="46" fill="none" stroke="rgba(255,255,255,.9)" stroke-width="2.5"/><circle id="rp" cx="50" cy="50" r="46" fill="none" stroke="var(--ac)" stroke-width="4" stroke-linecap="round" stroke-dasharray="289.03" stroke-dashoffset="289.03"/></svg>
    <div class="in"><div class="n" id="rd">0</div><div>${t('days')}</div><div class="hms" id="rh">00:00:00</div><div class="mut" id="rs"></div></div></div>
    <div class="row wrap" style="justify-content:center">${ctrl}</div>
    <div class="card" style="margin-top:16px"><div class="mut">${t('motivation')}</div><p style="margin:6px 0 0">${esc(tr(mot[0], mot[1]))}</p></div>
    ${S0.notif.enabled ? '' : `<div class="card row sp" style="border-color:var(--gold)"><span>🔔 দৈনিক অনুপ্রেরণার নোটিফিকেশন চালু করুন</span><button class="btn gold sm" data-act="notifOn">চালু করুন</button></div>`}
    <button class="sos" data-act="go" data-to="sos">🆘 ${t('sos')}</button>
    <div class="grid" style="margin-top:14px">
      ${[['sos', '🚨', t('emergency')], ['challenges', '✅', t('daily')], ['story', '📖', t('story')], ['focus', '🎯', t('focus')], ['badges', '🏅', t('badges')], ['history', '🕘', t('history')]].map(([k, i, l]) => `<button class="q" data-act="${k === 'story' ? 'randStory' : 'go'}" data-to="${k}"><i>${i}</i>${l}</button>`).join('')}</div>`;
}
function tickUI() {
  if (route === 'home' && $('#rd')) {
    const ms = S.elapsedMs(), d = Math.floor(ms / S.DAY), b = S.badgeForDays(d), nx = S.nextBadge(d);
    $('#rd').textContent = d; $('#rh').textContent = hms(ms);
    $('#rs').textContent = !st().challenge.start ? t('noStreak') : st().challenge.paused ? '⏸' : '';
    const p = nx ? Math.min(1, (ms / S.DAY - b.min) / (nx.min - b.min)) : 1;
    $('#rp').setAttribute('stroke-dashoffset', 289.03 * (1 - (nx ? p : 1)));
    $('#bp').style.width = (p * 100).toFixed(1) + '%';
    if (nx) $('#bn').textContent = `${t('next')}: ${bName(nx)} · ${t('inDays', { n: Math.max(0, Math.ceil(nx.min - ms / S.DAY)) })}`;
  }
  if (route === 'focus') focusTick(); if (route === 'sos') sosTick();
}
setInterval(() => {
  const fresh = S.checkBadges(); if (fresh.length) { const b = fresh[fresh.length - 1]; if (route === 'home') render(); celebrate(b); }
  tickUI();
}, 1000);

function startChallenge() { const fresh = S.start(); render(); if (fresh.length) celebrate(fresh[0]); N.reschedule(); }
function setbackModal() {
  const nowLocal = new Date(Date.now() - new Date().getTimezoneOffset() * 60000).toISOString().slice(0, 16);
  modal(`<h3 style="margin-top:0">${t('sbTitle')}</h3>
   <label>${t('sbWhat')}</label><textarea id="s1" placeholder="Required"></textarea>
   <label>${t('sbTrigger')}</label><input id="s2"><label>${t('sbFeel')}</label><input id="s3">
   <label>${t('sbTime')}</label><input id="s4" type="datetime-local" value="${nowLocal}"><label>${t('sbNext')}</label><textarea id="s5"></textarea>
   <div class="row sp"><button class="btn ghost" data-act="closeModal">${t('cancel')}</button><button class="btn gold" id="sbOk">${t('submit')}</button></div>`);
  $('#sbOk').onclick = () => {
    const reason = { what: $('#s1').value.trim(), trigger: $('#s2').value.trim(), feeling: $('#s3').value.trim(), when: $('#s4').value ? new Date($('#s4').value).getTime() : Date.now(), next: $('#s5').value.trim() };
    if (!reason.what) { toast('✍ ' + t('sbWhat')); return; }
    confirmBox(t('sbConfirm'), () => {
      S.endAttempt('setback', reason); render(); N.notifyNow('NO FAP ULTRA', C.MESSAGES.setback[0]);
      modal(`<div class="c"><div style="font-size:48px">❤️</div><p>${esc(t('sbSupport'))}</p><button class="btn" data-act="closeModal">OK</button></div>`);
    });
  };
}

// ---------- charts ----------
function bars(vals, labels, h = 120) {
  const mx = Math.max(1, ...vals), w = 300, bw = w / vals.length;
  return `<svg viewBox="0 0 ${w} ${h + 20}" style="width:100%">${vals.map((v, i) => { const bh = v / mx * h; return `<rect x="${i * bw + 2}" y="${h - bh}" width="${Math.max(2, bw - 4)}" height="${bh}" rx="3" fill="var(--ac)" opacity=".9"/>${labels[i] ? `<text x="${i * bw + bw / 2}" y="${h + 14}" font-size="9" text-anchor="middle" fill="var(--mut)">${labels[i]}</text>` : ''}`; }).join('')}</svg>`;
}
function ringSvg(p, label, sub) {
  const c = 2 * Math.PI * 38;
  return `<div class="stat"><svg viewBox="0 0 100 100" width="84"><circle cx="50" cy="50" r="38" fill="none" stroke="rgba(127,127,127,.25)" stroke-width="9"/><circle cx="50" cy="50" r="38" fill="none" stroke="var(--ac)" stroke-width="9" stroke-linecap="round" stroke-dasharray="${c}" stroke-dashoffset="${c * (1 - Math.min(1, p))}" transform="rotate(-90 50 50)"/><text x="50" y="56" font-size="18" font-weight="800" text-anchor="middle" fill="var(--tx)">${label}</text></svg><span>${sub}</span></div>`;
}
const startOfDay = (ts) => { const d = new Date(ts); d.setHours(0, 0, 0, 0); return d.getTime(); };
function series(kind) {
  const now = Date.now(), v = [], l = [];
  if (kind === 'week' || kind === 'month') {
    const n = kind === 'week' ? 7 : 30, today = startOfDay(now);
    for (let i = n - 1; i >= 0; i--) { const a = today - i * S.DAY; v.push(S.daysInRange(a, a + S.DAY)); l.push(kind === 'week' ? new Date(a).toLocaleDateString('en', { weekday: 'short' }).slice(0, 2) : (i % 5 === 0 ? new Date(a).getDate() : '')); }
  } else {
    const d = new Date(); for (let i = 11; i >= 0; i--) { const a = new Date(d.getFullYear(), d.getMonth() - i, 1).getTime(), b = new Date(d.getFullYear(), d.getMonth() - i + 1, 1).getTime(); v.push(S.daysInRange(a, b)); l.push(new Date(a).toLocaleDateString('en', { month: 'short' }).slice(0, 1)); }
  }
  return [v, l];
}

// ---------- HISTORY ----------
function vHistory() {
  const S0 = st(), k = tab.hist || 'week', [v, l] = series(k), now = Date.now();
  const list = [...S0.attempts].reverse(), cur = S0.challenge.start;
  return `<h2>${t('history')}</h2>
  <div class="grid2"><div class="stat"><b>${S.currentDays()}</b><span>${t('current')}</span></div><div class="stat"><b>${Math.floor(S.longestMs() / S.DAY)}</b><span>${t('longest')}</span></div>
  <div class="stat"><b>${S.totalDays()}</b><span>${t('total')}</span></div><div class="stat"><b>${S.totalAttempts()}</b><span>${t('attempts')}</span></div></div>
  <div class="card"><div class="tabs">${['week', 'month', 'year'].map(x => `<button class="${k === x ? 'on' : ''}" data-act="tab" data-k="hist" data-v="${x}">${t(x)}</button>`).join('')}</div>${bars(v, l)}<div class="mut c">${Math.round(v.reduce((a, b) => a + b, 0) * 10) / 10} ${t('days')}</div></div>
  <h3>${t('setbacks')}: ${S.setbackCount()}</h3>
  ${cur ? `<div class="li"><div><div class="t">▶ ${fmtDate(cur)} → …</div><div class="mut">${durTxt(S.elapsedMs())}</div></div></div>` : ''}
  ${list.map(a => `<button class="li" data-act="attempt" data-id="${a.id}"><div style="flex:1"><div class="t">${a.type === 'setback' ? '⚠' : '↺'} ${durTxt(a.ms)} — ${esc(BADGES[BADGES.indexOf(S.badgeForDays(Math.floor(a.ms / S.DAY)))].en)}</div><div class="mut">${fmtDate(a.start)} → ${fmtDate(a.end)}${a.reason ? ' · ' + esc(a.reason.what.slice(0, 40)) : ''}</div></div>›</button>`).join('') || (cur ? '' : `<p class="mut c">${t('none')}</p>`)}`;
}
function attemptModal(id) {
  const a = st().attempts.find(x => String(x.id) === String(id)); if (!a) return;
  const r = a.reason;
  modal(`<h3 style="margin-top:0">${fmtDate(a.start)} → ${fmtDate(a.end)}</h3><p>${durTxt(a.ms)} · ${a.type}</p>${r ? `<p><b>${t('sbWhat')}</b><br>${esc(r.what)}</p>${r.trigger ? `<p><b>${t('sbTrigger')}</b><br>${esc(r.trigger)}</p>` : ''}${r.feeling ? `<p><b>${t('sbFeel')}</b><br>${esc(r.feeling)}</p>` : ''}<p><b>${t('sbTime')}</b><br>${fmtDT(r.when)}</p>${r.next ? `<p><b>${t('sbNext')}</b><br>${esc(r.next)}</p>` : ''}` : ''}<button class="btn" data-act="closeModal">${t('close')}</button>`);
}

// ---------- BADGES ----------
function vBadges() {
  const S0 = st(), d = S.elapsedMs() / S.DAY;
  return `<h2>${t('badges')}</h2>` + BADGES.map(b => {
    const un = S0.unlocked[b.id], rem = Math.max(0, Math.ceil(b.min - d));
    return `<button class="li" data-act="badge" data-id="${b.id}">${avatar(b, !un).replace('class="av', 'class="av sm')}<div style="flex:1"><div class="t">${esc(bName(b))}</div><div class="mut">${b.min}+ ${t('days')}</div></div><div class="mut">${un ? '✅ ' + fmtDate(un) : '🔒 ' + t('locked', { n: rem })}</div></button>`;
  }).join('');
}
function badgeModal(id) {
  const b = BADGES.find(x => x.id === id), un = st().unlocked[id], rem = Math.max(0, Math.ceil(b.min - S.elapsedMs() / S.DAY));
  modal(`<div class="c">${avatar(b, !un).replace('class="av', 'class="av" style="width:150px;height:150px" data-x="')}<h2>${esc(bName(b))}</h2><p>${esc(b.desc)}</p><p class="mut">${t('badges')}: ${b.min}+ ${t('days')}</p><p>${un ? '✅ ' + t('unlockedOn', { d: fmtDate(un) }) : '🔒 ' + t('locked', { n: rem })}</p><button class="btn" data-act="closeModal">${t('close')}</button></div>`);
  if (un && b.min >= 30) confetti();
}

// ---------- CHALLENGES ----------
const periodKey = (k) => k === 'daily' ? 'd:' + S.dateKey() : k === 'weekly' ? 'w:' + S.weekKey() : 'm:' + S.monthKey();
function vChallenges() {
  const k = tab.ch || 'daily', S0 = st(), pk = periodKey(k), list = C.CHALLENGES[k];
  const doneN = list.filter(([id]) => S0.done[pk + ':' + id]).length;
  const hist = Object.keys(S0.done).filter(x => x.startsWith('d:')).sort().reverse().slice(0, 25);
  return `<h2>${t('challenges')}</h2><div class="row sp"><div class="stat" style="flex:1"><b>${S.level()}</b><span>${t('level')}</span></div><div class="stat" style="flex:1"><b>${S0.xp}</b><span>${t('xp')}</span></div><div class="stat" style="flex:1"><b>${doneN}/${list.length}</b><span>${t('done')}</span></div></div>
  <div class="tabs" style="margin-top:12px">${['daily', 'weekly', 'monthly', 'log'].map(x => `<button class="${k === x ? 'on' : ''}" data-act="tab" data-k="ch" data-v="${x}">${x === 'log' ? '🕘' : t(x === 'daily' ? 'dailyT' : x)}</button>`).join('')}</div>` +
  (k === 'log' ? (hist.map(h => { const [, date, id] = h.split(':'); const e = C.CHALLENGES.daily.find(x => x[0] === id); return `<div class="li"><span>✅</span><div><div class="t">${esc(e ? e[1] : id)}</div><div class="mut">${date}</div></div></div>`; }).join('') || `<p class="mut c">${t('none')}</p>`) :
    list.map(([id, label, xp]) => { const on = S0.done[pk + ':' + id]; return `<button class="li" data-act="toggleCh" data-id="${id}" data-k="${k}"><span class="chk ${on ? 'on' : ''}">${on ? '✓' : ''}</span><div style="flex:1" class="t">${esc(label)}</div><span class="tag">+${xp} XP</span></button>`; }).join(''));
}
function toggleCh(id, k) {
  const S0 = st(), key = periodKey(k) + ':' + id, e = C.CHALLENGES[k].find(x => x[0] === id);
  if (S0.done[key]) { delete S0.done[key]; S0.xp = Math.max(0, S0.xp - e[2]); } else { S0.done[key] = Date.now(); S0.xp += e[2]; toast(`+${e[2]} XP`); }
  S.save(); render();
}

// ---------- LIBRARY ----------
const itemsOf = (cat) => cat === 'E' ? C.LESSONS : cat === 'D' ? C.STORIES : C.ARTICLES.filter(a => a.cat === cat);
function vLibrary() {
  const k = tab.lib || 'A', q = (tab.q || '').toLowerCase(), S0 = st(), all = C.allItems();
  const readN = all.filter(i => S0.read[i.id]).length;
  let list = q ? all.filter(i => (i.title + ' ' + i.body.join(' ')).toLowerCase().includes(q)) : k === 'fav' ? all.filter(i => S0.bookmarks.includes(i.id)) : itemsOf(k);
  return `<h2>📚 নেশামুক্ত লাইব্রেরি</h2>
  <div class="row"><div class="bar" style="flex:1;margin:0"><i style="width:${all.length ? readN / all.length * 100 : 0}%"></i></div><span class="mut">${readN}/${all.length} পঠিত</span></div>
  <input id="libq" placeholder="🔍 খুঁজুন…" value="${esc(tab.q || '')}" style="margin-top:10px">
  <button class="li" data-act="go" data-to="journey"><span style="font-size:26px">🗓️</span><div class="t">৩৬৫ দিনের রূপান্তর যাত্রা</div></button>
  <div class="tabs">${Object.entries(C.CATS).map(([c, o]) => `<button class="${k === c && !q ? 'on' : ''}" data-act="tab" data-k="lib" data-v="${c}">${o.icon} ${o.bn}</button>`).join('')}<button class="${k === 'fav' ? 'on' : ''}" data-act="tab" data-k="lib" data-v="fav">⭐ পছন্দের</button></div>
  <div style="margin-top:8px">${list.map(i => `<button class="li" data-act="item" data-id="${i.id}">${i.cover ? `<div class="sw" style="width:46px;height:46px;border:0;border-radius:12px;background:linear-gradient(135deg,${i.cover[0]},${i.cover[1]})"></div>` : `<span style="font-size:26px">${C.CATS[i.cat].icon}</span>`}<div style="flex:1"><div class="t">${i.n ? 'দিন ' + i.n + ' · ' : ''}${esc(i.title)}</div><div class="mut">${i.min} মিনিট${S0.read[i.id] ? ' · ✅ পঠিত' : ''}</div></div>${S0.bookmarks.includes(i.id) ? '⭐' : ''}</button>`).join('') || `<p class="mut c">এখানে এখনো কিছু নেই।</p>`}</div>`;
}
function vItem() {
  const i = C.allItems().find(x => x.id === arg); if (!i) return vLibrary();
  const S0 = st(), fav = S0.bookmarks.includes(i.id);
  return `<div class="row sp"><button class="btn ghost sm" data-act="back">‹</button><div class="row"><button class="btn ghost sm" data-act="bm" data-id="${i.id}">${fav ? '⭐' : '☆'}</button></div></div>
  ${i.cover ? `<div class="cover" style="background:linear-gradient(135deg,${i.cover[0]},${i.cover[1]});margin-top:12px">${esc(i.title)}</div>` : `<h2>${i.n ? 'দিন ' + i.n + ': ' : ''}${esc(i.title)}</h2>`}
  <div class="body">${i.body.map(p => `<p>${esc(p)}</p>`).join('')}
  ${i.example ? `<div class="card"><b>উদাহরণ</b><p>${esc(i.example)}</p></div>` : ''}${i.exercise ? `<div class="card"><b>আজকের অনুশীলন</b><p>${esc(i.exercise)}</p></div>` : ''}
  ${i.lesson ? `<div class="card"><b>শিক্ষা</b><p>${esc(i.lesson)}</p></div>` : ''}<div class="card" style="border-color:var(--gold)"><b>মূল কথা</b><p>${esc(i.takeaway)}</p></div></div>
  <button class="btn" style="width:100%" data-act="markRead" data-id="${i.id}">${S0.read[i.id] ? '✅ পঠিত' : 'পঠিত হিসেবে চিহ্নিত করুন'}</button>
  ${i.cat === 'B' || i.cat === 'A' ? `<p class="mut c" style="margin-top:12px">এটি শুধু শিক্ষামূলক তথ্য, চিকিৎসা পরামর্শ নয়। কষ্ট হলে ডাক্তার বা লাইসেন্সপ্রাপ্ত থেরাপিস্টের সাথে কথা বলুন।</p>` : ''}`;
}

// ---------- JOURNEY ----------
function vJourney() {
  const S0 = st(), cur = S.currentDays() + 1, doneN = Object.keys(S0.journey).length;
  return `<h2>🗓️ ৩৬৫ দিনের রূপান্তর</h2><p class="mut">${doneN}/365 সম্পন্ন</p><div class="bar"><i style="width:${doneN / 365 * 100}%"></i></div>` +
    C.PHASES.map(p => `<h3>${tr(p.en, p.bn)} <span class="mut">(${p.from}–${p.to})</span></h3><div style="display:grid;grid-template-columns:repeat(8,1fr);gap:5px">${Array.from({ length: p.to - p.from + 1 }, (_, i) => p.from + i).map(n => `<button class="q" style="padding:8px 0;${S0.journey[n] ? 'background:var(--ac);color:#00110f;' : ''}${n === cur ? 'border-color:var(--gold);border-width:2px;' : ''}" data-act="jday" data-n="${n}">${n}</button>`).join('')}</div>`).join('');
}
function jdayModal(n) {
  const d = C.journeyDay(n), done = st().journey[n];
  modal(`<div class="mut">${tr(d.phase.en, d.phase.bn)}</div><h2 style="margin:4px 0">দিন ${n}</h2><p><b>📘 আজকের পাঠ</b><br>${esc(d.lesson)}</p><p><b>💬 অনুপ্রেরণামূলক উক্তি</b><br><i>${esc(d.quote)}</i></p><p><b>✅ ছোট কাজ</b><br>${esc(d.task)}</p><p><b>🏃 অনুশীলন</b><br>${esc(d.activity)}</p><p><b>🤔 ভাবনার প্রশ্ন</b><br>${esc(d.reflection)}</p>
   <div class="row sp"><button class="btn ghost" data-act="closeModal">বন্ধ করুন</button><button class="btn" data-act="jdone" data-n="${n}">${done ? '↩ বাতিল' : '✓ সম্পন্ন'}</button></div>`);
}

// ---------- STATS ----------
function vStats() {
  const S0 = st(), pk = periodKey('daily'), dn = C.CHALLENGES.daily.filter(([id]) => S0.done[pk + ':' + id]).length;
  const wk = Math.round(S.daysInRange(Date.now() - 7 * S.DAY, Date.now()) * 10) / 10, mo = Math.round(S.daysInRange(Date.now() - 30 * S.DAY, Date.now()) * 10) / 10;
  const [v, l] = series('week');
  return `<h2>${t('stats')}</h2><div class="grid2">
   ${ringSvg(S.currentDays() / Math.max(1, (S.nextBadge(S.currentDays())?.min) || 1), S.currentDays(), t('current'))}
   ${ringSvg(Math.floor(S.longestMs() / S.DAY) / 365, Math.floor(S.longestMs() / S.DAY), t('longest'))}
   ${ringSvg(dn / C.CHALLENGES.daily.length, dn + '/' + C.CHALLENGES.daily.length, t('daily'))}
   ${ringSvg(Object.keys(S0.unlocked).length / BADGES.length, Object.keys(S0.unlocked).length + '/12', t('badges'))}</div>
   <div class="grid2" style="margin-top:10px"><div class="stat"><b>${S.totalDays()}</b><span>${t('total')}</span></div><div class="stat"><b>${S.totalAttempts()}</b><span>${t('attempts')}</span></div><div class="stat"><b>${S.setbackCount()}</b><span>${t('setbacks')}</span></div><div class="stat"><b>${S0.xp}</b><span>${t('xp')} · ${t('level')} ${S.level()}</span></div><div class="stat"><b>${wk}</b><span>${t('week')}</span></div><div class="stat"><b>${mo}</b><span>${t('month')}</span></div></div>
   <div class="card">${bars(v, l)}</div>`;
}

// ---------- FOCUS ----------
let focus = null, ambient = null, fMode = { label: 'Pomodoro', min: 25 };
const MODES = [['Pomodoro', 25], ['Deep 50', 50], ['Study', 40], ['Work', 45], ['Reading', 30], ['Break', 5]];
function vFocus() {
  const S0 = st(), today = S0.focus.filter(f => startOfDay(f.t) === startOfDay(Date.now())), tot = S0.focus.reduce((a, f) => a + f.min, 0);
  return `<h2>🎯 ${t('focus')}</h2><div class="card c"><div class="ring" style="width:220px"><svg viewBox="0 0 100 100"><circle cx="50" cy="50" r="46" fill="none" stroke="rgba(127,127,127,.3)" stroke-width="3"/><circle id="fp" cx="50" cy="50" r="46" fill="none" stroke="var(--ac)" stroke-width="4" stroke-linecap="round" stroke-dasharray="289.03" stroke-dashoffset="${focus ? 289.03 : 0}"/></svg><div class="in"><div class="n" style="font-size:44px" id="ft">${pad(fMode.min)}:00</div><div class="mut">${esc(fMode.label)}</div></div></div>
  <div class="row wrap" style="justify-content:center">${focus ? `<button class="btn red" data-act="fstop">■ Stop</button>` : `<button class="btn" data-act="fstart">▶ Start</button>`}</div></div>
  <div class="tabs">${MODES.map(([n, m]) => `<button class="${fMode.label === n ? 'on' : ''}" data-act="fmode" data-n="${n}" data-m="${m}">${n} ${m}m</button>`).join('')}</div>
  <div class="row" style="margin-top:8px"><input id="fcustom" type="number" min="1" max="240" placeholder="Custom (min)"><button class="btn ghost" data-act="fcustom">OK</button></div>
  <label>Ambient</label><select id="famb"><option value="">Off</option><option value="rain">Rain / white noise</option><option value="brown">Deep brown noise</option></select>
  <div class="grid" style="margin-top:12px"><div class="stat"><b>${today.reduce((a, f) => a + f.min, 0)}</b><span>min today</span></div><div class="stat"><b>${S0.focus.length}</b><span>sessions</span></div><div class="stat"><b>${tot}</b><span>min total</span></div></div>`;
}
function ambientStart(kind) {
  ambientStop(); if (!kind) return;
  const ctx = new (window.AudioContext || window.webkitAudioContext)(), len = ctx.sampleRate * 2, buf = ctx.createBuffer(1, len, ctx.sampleRate), d = buf.getChannelData(0); let last = 0;
  for (let i = 0; i < len; i++) { const w = Math.random() * 2 - 1; if (kind === 'brown') { last = (last + .02 * w) / 1.02; d[i] = last * 3.5; } else d[i] = w * .5; }
  const src = ctx.createBufferSource(); src.buffer = buf; src.loop = true; const f = ctx.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = kind === 'brown' ? 400 : 3000;
  const g = ctx.createGain(); g.gain.value = .25; src.connect(f); f.connect(g); g.connect(ctx.destination); src.start(); ambient = { ctx, src };
}
function ambientStop() { if (ambient) { try { ambient.src.stop(); ambient.ctx.close(); } catch { /* */ } ambient = null; } }
function beep() { try { const c = new AudioContext(), o = c.createOscillator(); o.connect(c.destination); o.frequency.value = 880; o.start(); setTimeout(() => { o.stop(); c.close(); }, 600); } catch { /* */ } }
function focusTick() {
  if (!focus || !$('#ft')) return;
  const left = Math.max(0, focus.end - Date.now()), tot = focus.min * 60000;
  $('#ft').textContent = `${pad(Math.floor(left / 60000))}:${pad(Math.floor(left % 60000 / 1000))}`; $('#fp').setAttribute('stroke-dashoffset', 289.03 * (left / tot));
  if (left <= 0) finishFocus(true);
}
function finishFocus(ok) {
  if (!focus) return; const f = focus; focus = null; ambientStop();
  if (ok) { st().focus.push({ t: Date.now(), min: f.min, mode: f.label }); st().xp += Math.round(f.min / 5); S.save(); beep(); toast('🎯 ' + f.min + ' min ✓'); N.notifyNow('NO FAP ULTRA', `Focus session complete: ${f.min} min`); }
  if (route === 'focus') render();
}

// ---------- DIARY ----------
const MOODS = ['😄', '🙂', '😐', '😟', '😢', '😡'];
function vDiary() {
  const S0 = st(), q = (tab.dq || '').toLowerCase(), now = new Date(), y = now.getFullYear(), m = now.getMonth(), dim = new Date(y, m + 1, 0).getDate(), first = new Date(y, m, 1).getDay();
  const days = new Set(S0.diary.filter(e => { const d = new Date(e.t); return d.getFullYear() === y && d.getMonth() === m; }).map(e => new Date(e.t).getDate()));
  const list = [...S0.diary].sort((a, b) => b.t - a.t).filter(e => !q || e.text.toLowerCase().includes(q));
  return `<div class="row sp"><h2>📔 ${t('diary')}</h2><button class="btn sm" data-act="dnew">＋ ${t('newEntry')}</button></div><p class="mut">🔒 শুধু আপনার ফোনেই সংরক্ষিত থাকে।</p>
  <div class="card"><div class="mut c" style="margin-bottom:6px">${now.toLocaleDateString('en', { month: 'long', year: 'numeric' })}</div><div class="cal">${['S', 'M', 'T', 'W', 'T', 'F', 'S'].map(x => `<b>${x}</b>`).join('')}${'<span></span>'.repeat(first)}${Array.from({ length: dim }, (_, i) => `<div class="${days.has(i + 1) ? 'has' : ''}">${i + 1}</div>`).join('')}</div></div>
  <input id="dq" placeholder="${t('search')}" value="${esc(tab.dq || '')}">
  ${list.map(e => `<button class="li" data-act="dedit" data-id="${e.id}"><span style="font-size:28px">${e.mood}</span><div style="flex:1"><div class="mut">${fmtDT(e.t)}</div><div>${esc(e.text.slice(0, 120))}</div></div></button>`).join('') || `<p class="mut c">${t('none')}</p>`}`;
}
function diaryModal(id) {
  const e = id ? st().diary.find(x => String(x.id) === String(id)) : null;
  modal(`<h3 style="margin-top:0">${e ? t('edit') : t('newEntry')}</h3><label>${t('mood')}</label><div class="row wrap" id="moods">${MOODS.map(x => `<button class="btn ghost sm ${(e?.mood || '🙂') === x ? 'gold' : ''}" data-act="mood" data-m="${x}" style="font-size:22px">${x}</button>`).join('')}</div>
  <textarea id="dtext" style="min-height:160px;margin-top:10px" placeholder="…">${esc(e?.text || '')}</textarea><input type="hidden" id="dmood" value="${e?.mood || '🙂'}">
  <div class="row sp">${e ? `<button class="btn red sm" id="ddel">${t('delete')}</button>` : '<span></span>'}<div class="row"><button class="btn ghost" data-act="closeModal">${t('cancel')}</button><button class="btn" id="dsave">${t('save')}</button></div></div>`);
  $('#dsave').onclick = () => { const text = $('#dtext').value.trim(); if (!text) return; const S0 = st();
    if (e) { e.text = text; e.mood = $('#dmood').value; } else S0.diary.push({ id: Date.now(), t: Date.now(), mood: $('#dmood').value, text });
    S.save(); closeModal(); render(); };
  if (e) $('#ddel').onclick = () => confirmBox(t('delete') + '?', () => { st().diary = st().diary.filter(x => x !== e); S.save(); render(); });
}

// ---------- SOS ----------
let sos = { breath: null, dist: null };
const SOS_STEPS = ['থামুন এবং গভীর শ্বাস নিন।', 'যে পরিবেশ ট্রিগার করছে সেখান থেকে সরে যান।', 'ফোনটি দূরে রাখুন।', 'পানি পান করুন।', '৫ থেকে ১০ মিনিট হাঁটুন।', 'কোনো বিশ্বস্ত মানুষকে ফোন করুন।', 'অন্য কোনো কাজ শুরু করুন।', 'একটি অনুপ্রেরণার গল্প পড়ুন।'];
function vSOS() {
  const msg = C.SOS_MESSAGES[Math.floor(Math.random() * C.SOS_MESSAGES.length)];
  return `<h2 style="color:var(--red)">🆘 জরুরি সাহায্য</h2><div class="card" style="border-color:var(--red)"><b>💬</b> ${esc(msg)}</div>
  <div class="card c"><div class="breath" id="bz">প্রস্তুত</div><div class="mut" id="bt">5:00</div><button class="btn" data-act="breath">${sos.breath ? '■ থামুন' : '🫁 ৫ মিনিটের শ্বাসের অনুশীলন'}</button></div>
  <div class="card c"><div class="n" style="font-size:44px;font-weight:900" id="dt">10:00</div><button class="btn gold" data-act="dist">${sos.dist ? '■ থামুন' : '⏱ ১০ মিনিটের মনোযোগ ঘোরানো টাইমার'}</button></div>
  ${SOS_STEPS.map((s, i) => `<button class="li" data-act="sostep" data-i="${i}"><span class="chk" id="ss${i}"></span><div>${esc(s)}</div></button>`).join('')}
  <h3>করার মতো কাজ</h3><div class="card">• ২০টি পুশআপ বা স্কোয়াট<br>• মুখে ঠান্ডা পানি দিন<br>• বন্ধুকে ফোন করুন<br>• কিছু রান্না করুন<br>• একটি ঘর গোছান<br>• বাইরে যান</div>
  <button class="btn" style="width:100%" data-act="randStory">📖 ${t('story')}</button>`;
}
function sosTick() {
  if (sos.breath && $('#bz')) {
    const left = sos.breath - Date.now(); if (left <= 0) { sos.breath = null; render(); return; }
    const el = 300000 - left, ph = el % 14000, step = ph < 4000 ? 'in' : ph < 8000 ? 'hold' : 'out', bz = $('#bz');
    bz.textContent = step === 'in' ? 'শ্বাস নিন' : step === 'hold' ? 'ধরে রাখুন' : 'ধীরে ছাড়ুন'; bz.style.transform = step === 'out' ? 'scale(.7)' : 'scale(1.25)'; bz.style.transitionDuration = step === 'in' ? '4s' : step === 'out' ? '6s' : '0s';
    $('#bt').textContent = `${Math.floor(left / 60000)}:${pad(Math.floor(left % 60000 / 1000))}`;
  }
  if (sos.dist && $('#dt')) { const left = sos.dist - Date.now(); if (left <= 0) { sos.dist = null; beep(); toast('🎉 ১০ মিনিট শেষ, তাগিদ সম্ভবত কমে গেছে'); render(); return; } $('#dt').textContent = `${Math.floor(left / 60000)}:${pad(Math.floor(left % 60000 / 1000))}`; }
}

// ---------- NOTIFICATIONS ----------
function vNotifs() {
  const n = st().notif;
  return `<h2>🔔 ${t('notifs')}</h2><div class="card"><div class="row sp"><b>Enable notifications</b><input type="checkbox" id="nen" ${n.enabled ? 'checked' : ''} style="width:auto"></div><div class="row sp"><span>Sound / vibration</span><input type="checkbox" id="nsound" ${n.sound ? 'checked' : ''} style="width:auto"></div><p class="mut">Max 4 per day. Only the categories you enable are sent.</p></div>
  ${['morning', 'afternoon', 'evening', 'night'].map(c => `<div class="card row sp"><div class="row"><input type="checkbox" data-nc="${c}" ${n.on[c] ? 'checked' : ''} style="width:auto"><b style="text-transform:capitalize">${c}</b></div><input type="time" data-nt="${c}" value="${n.times[c]}" style="width:auto;margin:0"></div>`).join('')}
  <label>Custom reminder (replaces some morning messages)</label><textarea id="ncustom">${esc(n.custom)}</textarea>
  <div class="row"><button class="btn" data-act="ntest">টেস্ট পাঠান</button><button class="btn ghost" data-act="ndiag">🔎 পরীক্ষা</button><button class="btn ghost" data-act="nclear">Clear history</button></div>
  <h3>History</h3>${n.history.slice(0, 20).map(h => `<div class="li"><div><div class="mut">${fmtDT(h.t)}</div><div>${esc(h.body)}</div></div></div>`).join('') || `<p class="mut">${t('none')}</p>`}`;
}

// ---------- PROFILE ----------
const ACCENTS = ['#14b8a6', '#facc15', '#3b82f6', '#a855f7', '#f97316', '#ec4899'], AVATARS = ['🦁', '🐺', '🦅', '🐯', '🐉', '🦉', '🔥', '⚡'];
function vProfile() {
  const S0 = st(), P = S0.profile, all = C.allItems(), readN = all.filter(i => S0.read[i.id]).length, favs = all.filter(i => S0.bookmarks.includes(i.id));
  return `<h2>${t('profile')}</h2><div class="card c"><div style="font-size:56px">${P.avatar}</div><div class="row wrap" style="justify-content:center">${AVATARS.map(a => `<button class="btn ghost sm" data-act="avatar" data-v="${a}">${a}</button>`).join('')}</div>
  <input id="pname" placeholder="Username" value="${esc(P.name)}" style="margin-top:10px"><textarea id="pgoals" placeholder="Personal goals">${esc(P.goals)}</textarea>
  <p class="mut">Joined ${fmtDate(P.joined)} · ${t('level')} ${S.level()} · ${S0.xp} XP · 🏅 ${Object.keys(S0.unlocked).length}/12 · 📚 ${readN}/${all.length}</p><button class="btn sm" data-act="psave">${t('save')}</button></div>
  ${favs.length ? `<h3>⭐ ${t('favorites')}</h3>${favs.map(i => `<button class="li" data-act="item" data-id="${i.id}"><div class="t">${esc(i.title)}</div></button>`).join('')}` : ''}
  <div class="card"><label>${t('theme')}</label><div class="row"><button class="btn ${S0.theme === 'dark' ? '' : 'ghost'} sm" data-act="theme" data-v="dark">${t('dark')}</button><button class="btn ${S0.theme === 'light' ? '' : 'ghost'} sm" data-act="theme" data-v="light">${t('light')}</button></div>
  <label style="display:block;margin-top:10px">${t('accent')}</label><div class="row">${ACCENTS.map(a => `<button class="sw ${S0.accent === a ? 'on' : ''}" style="background:${a}" data-act="accent" data-v="${a}"></button>`).join('')}</div>
  <label style="display:block;margin-top:10px">${t('language')}</label><div class="row"><button class="btn ${S0.lang === 'en' ? '' : 'ghost'} sm" data-act="lang" data-v="en">English</button><button class="btn ${S0.lang === 'bn' ? '' : 'ghost'} sm" data-act="lang" data-v="bn">বাংলা</button></div></div>
  <div class="card"><div class="row wrap"><button class="btn ghost sm" data-act="go" data-to="notifs">🔔 ${t('notifs')}</button><button class="btn ghost sm" data-act="pin">🔒 ${t('pin')}${S0.pinHash ? ' ✓' : ''}</button><button class="btn ghost sm" data-act="export">⬇ ${t('export')}</button><button class="btn ghost sm" data-act="restore">⬆ ${t('restore')}</button><button class="btn red sm" data-act="wipe">🗑 ${t('wipe')}</button></div><input type="file" id="rfile" accept=".json" class="hidden"><p class="mut">All data stays on your device. No account, no cloud, no analytics.</p></div>`;
}
function vAbout() { return `<h2>NO FAP ULTRA</h2><p style="color:var(--gold);font-weight:700">${t('tagline')}</p><div class="card"><p>Version 1.0.0. A private habit-tracking and education app. Everything is stored on your device only.</p><p>Educational content is for general information and is not medical advice. If you feel unable to cope or have thoughts of self-harm, contact a doctor, therapist or your local emergency number.</p><p>Badge character names are playful gamification only — never a judgment of you.</p></div>`; }

// ---------- events ----------
document.addEventListener('click', async (e) => {
  const el = e.target.closest('[data-act]'); if (!el) return; const a = el.dataset.act, d = el.dataset, S0 = st();
  switch (a) {
    case 'drawer': $('#drawer').classList.contains('hidden') ? openDrawer() : closeDrawer(); break;
    case 'go': go(d.to); break; case 'back': history.back(); break;
    case 'closeModal': closeModal(); break;
    case 'start': startChallenge(); break; case 'pause': S.pause(); render(); break; case 'resume': S.resume(); render(); break;
    case 'reset': confirmBox(t('sbConfirm'), () => { S.endAttempt('reset'); render(); }); break;
    case 'setback': setbackModal(); break;
    case 'tab': tab[d.k] = d.v; if (d.k === 'lib') tab.q = ''; render(); break;
    case 'attempt': attemptModal(d.id); break; case 'badge': badgeModal(d.id); break;
    case 'toggleCh': toggleCh(d.id, d.k); break;
    case 'item': go('item', d.id); break;
    case 'randStory': { const s = C.STORIES[Math.floor(Math.random() * C.STORIES.length)]; go('item', s.id); break; }
    case 'bm': { const b = S0.bookmarks, i = b.indexOf(d.id); i >= 0 ? b.splice(i, 1) : b.push(d.id); S.save(); render(); break; }
    case 'markRead': S0.read[d.id] = Date.now(); S0.xp += 5; S.save(); toast('+5 XP'); render(); break;
    case 'jday': jdayModal(+d.n); break;
    case 'jdone': S0.journey[d.n] ? delete S0.journey[d.n] : S0.journey[d.n] = Date.now(); S.save(); closeModal(); render(); break;
    case 'fmode': if (!focus) { fMode = { label: d.n, min: +d.m }; render(); } break;
    case 'fcustom': { const v = +$('#fcustom').value; if (v > 0 && !focus) { fMode = { label: 'Custom', min: Math.min(240, v) }; render(); } break; }
    case 'fstart': focus = { end: Date.now() + fMode.min * 60000, min: fMode.min, label: fMode.label }; ambientStart($('#famb').value); render(); break;
    case 'fstop': finishFocus(false); break;
    case 'dnew': diaryModal(); break; case 'dedit': diaryModal(d.id); break;
    case 'mood': $('#dmood').value = d.m; document.querySelectorAll('#moods button').forEach(b => b.classList.toggle('gold', b.dataset.m === d.m)); break;
    case 'breath': sos.breath = sos.breath ? null : Date.now() + 300000; render(); break;
    case 'dist': sos.dist = sos.dist ? null : Date.now() + 600000; render(); break;
    case 'sostep': { const c = $('#ss' + d.i); c.classList.toggle('on'); c.textContent = c.classList.contains('on') ? '✓' : ''; break; }
    case 'ntest': if (await N.ask()) N.notifyNow('NO FAP ULTRA', C.MESSAGES.morning[1]); else toast('Permission denied'); render(); break;
    case 'notifOn': if (await N.ask()) { S0.notif.enabled = true; S.save(); const c = await N.reschedule(); toast(N.isNative() ? `🔔 চালু হয়েছে (${c}টি নির্ধারিত)` : '🔔 চালু। ব্রাউজারে অ্যাপ খোলা থাকলেই আসবে'); render(); } else toast('অনুমতি দেওয়া হয়নি। ফোনের সেটিংসে নোটিফিকেশন চালু করুন'); break;
    case 'ndiag': { const r = await N.diagnose(); modal(`<h3 style="margin-top:0">🔎 নোটিফিকেশন পরীক্ষা</h3><p>অ্যাপ ধরন: <b>${r.native ? 'Android অ্যাপ ✅' : 'ব্রাউজার ⚠️ (অ্যাপ বন্ধ থাকলে আসবে না)'}</b></p><p>অ্যাপে চালু: <b>${r.enabled ? 'হ্যাঁ ✅' : 'না ❌'}</b></p><p>অনুমতি: <b>${r.permission}</b></p><p>Exact alarm: <b>${r.exact}</b></p><p>নির্ধারিত নোটিফিকেশন: <b>${r.pending}</b></p><p class="mut">সব ঠিক থাকলে ফোনের Settings > Apps > NO FAP ULTRA > Battery থেকে "Unrestricted" দিন।</p><button class="btn" data-act="closeModal">বন্ধ করুন</button>`); break; }
    case 'nclear': S0.notif.history = []; S.save(); render(); break;
    case 'avatar': S0.profile.avatar = d.v; S.save(); render(); break;
    case 'psave': S0.profile.name = $('#pname').value.trim(); S0.profile.goals = $('#pgoals').value.trim(); S.save(); toast('✓'); break;
    case 'theme': S0.theme = d.v; S.save(); applyTheme(); render(); break;
    case 'accent': S0.accent = d.v; S.save(); applyTheme(); render(); break;
    case 'lang': S0.lang = d.v; S.save(); applyTheme(); render(); break;
    case 'pin': pinModal(); break;
    case 'export': { const blob = new Blob([JSON.stringify(S0, null, 2)], { type: 'application/json' }), u = URL.createObjectURL(blob), x = document.createElement('a'); x.href = u; x.download = `nofapultra-backup-${S.dateKey()}.json`; x.click(); setTimeout(() => URL.revokeObjectURL(u), 3000); break; }
    case 'restore': $('#rfile').click(); break;
    case 'wipe': confirmBox('Delete ALL data permanently? This cannot be undone.', () => { S.resetAll(); N.reschedule(); applyTheme(); go('home'); toast('Data erased'); }, t('delete')); break;
  }
});
document.addEventListener('input', (e) => {
  const id = e.target.id;
  if (id === 'libq') { tab.q = e.target.value; const p = e.target.selectionStart; render(); const n = $('#libq'); n.focus(); n.setSelectionRange(p, p); }
  if (id === 'dq') { tab.dq = e.target.value; const p = e.target.selectionStart; render(); const n = $('#dq'); n.focus(); n.setSelectionRange(p, p); }
});
document.addEventListener('change', async (e) => {
  const el = e.target, n = st().notif;
  if (el.id === 'nen') { if (el.checked && !(await N.ask())) { el.checked = false; toast('Permission needed'); return; } n.enabled = el.checked; S.save(); N.reschedule(); }
  else if (el.id === 'nsound') { n.sound = el.checked; S.save(); N.reschedule(); }
  else if (el.dataset.nc) { n.on[el.dataset.nc] = el.checked; S.save(); N.reschedule(); }
  else if (el.dataset.nt) { n.times[el.dataset.nt] = el.value; S.save(); N.reschedule(); }
  else if (el.id === 'ncustom') { n.custom = el.value.trim(); S.save(); N.reschedule(); }
  else if (el.id === 'rfile' && el.files[0]) {
    try { const obj = JSON.parse(await el.files[0].text()); if (!obj.profile || !obj.challenge) throw 0; confirmBox('Replace current data with this backup?', () => { S.replaceAll(obj); applyTheme(); go('home'); N.reschedule(); toast('Restored'); }); } catch { toast('Invalid backup file'); }
  }
});
function pinModal() {
  modal(`<h3 style="margin-top:0">${t('pin')}</h3><input id="pin" type="password" inputmode="numeric" maxlength="8" placeholder="4–8 digits"><div class="row sp">${st().pinHash ? `<button class="btn red sm" id="pinoff">Remove</button>` : '<span></span>'}<button class="btn" id="pinok">${t('save')}</button></div>`);
  $('#pinok').onclick = async () => { const v = $('#pin').value; if (!/^\d{4,8}$/.test(v)) return toast('4–8 digits'); st().pinHash = await S.sha(v); S.save(); closeModal(); render(); toast('🔒 ✓'); };
  if (st().pinHash) $('#pinoff').onclick = () => { st().pinHash = null; S.save(); closeModal(); render(); };
}
function lockScreen() {
  return new Promise(res => {
    modal(`<div class="c"><h2>🔒 NO FAP ULTRA</h2><input id="lpin" type="password" inputmode="numeric" maxlength="8" placeholder="PIN"><button class="btn" id="lok" style="width:100%">OK</button></div>`);
    const tryIt = async () => { if (await S.sha($('#lpin').value) === st().pinHash) { closeModal(); res(); } else { toast('Wrong PIN'); $('#lpin').value = ''; } };
    $('#lok').onclick = tryIt; $('#lpin').addEventListener('keydown', e => e.key === 'Enter' && tryIt());
  });
}

// ---------- boot ----------
(async function boot() {
  applyTheme(); history.replaceState({ r: 'home', a: null }, '');
  if (st().pinHash) await lockScreen();
  render(); S.checkBadges(); N.webTicker(); N.reschedule();
})();
