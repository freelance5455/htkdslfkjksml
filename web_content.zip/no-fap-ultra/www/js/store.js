// Persistent state + streak logic. All time maths uses real timestamps.
import { BADGES } from './badges.js';

const KEY = 'nofapultra.v1';
export const DAY = 86400000;

const defaults = () => ({
  v: 1,
  profile: { name: '', joined: Date.now(), avatar: '🦁', goals: '' },
  lang: 'en', theme: 'dark', accent: '#14b8a6',
  challenge: { start: null, paused: false, pausedAt: 0, pausedTotal: 0 },
  attempts: [],            // finished attempts: {start,end,ms,type,reason}
  unlocked: {},            // badgeId -> timestamp (never removed on setback)
  xp: 0, done: {}, diary: [], bookmarks: [], read: {}, journey: {}, focus: [],
  notif: {
    enabled: false, sound: true, custom: '',
    times: { morning: '08:00', afternoon: '14:00', evening: '19:00', night: '22:30' },
    on: { morning: true, afternoon: true, evening: true, night: true },
    history: []
  },
  pinHash: null
});

let s;
function load() {
  try { s = Object.assign(defaults(), JSON.parse(localStorage.getItem(KEY) || '{}')); }
  catch { s = defaults(); }
  s.notif = Object.assign(defaults().notif, s.notif);
}
load();

export const get = () => s;
export const save = () => localStorage.setItem(KEY, JSON.stringify(s));
export const replaceAll = (obj) => { s = Object.assign(defaults(), obj); save(); };
export const resetAll = () => { s = defaults(); save(); };

export function elapsedMs(now = Date.now()) {
  const c = s.challenge;
  if (!c.start) return 0;
  const end = c.paused ? c.pausedAt : now;
  return Math.max(0, end - c.start - c.pausedTotal);
}
export const currentDays = (now) => Math.floor(elapsedMs(now) / DAY);

export function badgeForDays(d) {
  let cur = BADGES[0];
  for (const b of BADGES) if (d >= b.min) cur = b;
  return cur;
}
export function nextBadge(d) { return BADGES.find(b => b.min > d) || null; }

// returns array of newly unlocked badges
export function checkBadges(now = Date.now()) {
  const d = currentDays(now), fresh = [];
  if (!s.challenge.start) return fresh;
  for (const b of BADGES) {
    if (d >= b.min && !s.unlocked[b.id]) { s.unlocked[b.id] = now; fresh.push(b); s.xp += 10 + b.min; }
  }
  if (fresh.length) save();
  return fresh;
}

export function start(now = Date.now()) {
  s.challenge = { start: now, paused: false, pausedAt: 0, pausedTotal: 0 };
  save(); return checkBadges(now);
}
export function pause(now = Date.now()) {
  if (s.challenge.start && !s.challenge.paused) { s.challenge.paused = true; s.challenge.pausedAt = now; save(); }
}
export function resume(now = Date.now()) {
  const c = s.challenge;
  if (c.start && c.paused) { c.pausedTotal += now - c.pausedAt; c.paused = false; c.pausedAt = 0; save(); }
}
// type: 'setback' | 'reset'. Old records & badges are kept.
export function endAttempt(type, reason = null, now = Date.now()) {
  const c = s.challenge;
  if (!c.start) return;
  const ms = elapsedMs(now);
  s.attempts.push({ start: c.start, end: now, ms, type, reason, id: now });
  s.challenge = { start: null, paused: false, pausedAt: 0, pausedTotal: 0 };
  save();
}
export function longestMs(now = Date.now()) {
  return Math.max(elapsedMs(now), ...s.attempts.map(a => a.ms), 0);
}
export function totalDays(now = Date.now()) {
  return Math.floor((s.attempts.reduce((t, a) => t + a.ms, 0) + elapsedMs(now)) / DAY);
}
export const setbackCount = () => s.attempts.filter(a => a.type === 'setback').length;
export const totalAttempts = () => s.attempts.length + (s.challenge.start ? 1 : 0);

// days of streak falling inside [from,to) — pauses ignored for period charts
export function daysInRange(from, to, now = Date.now()) {
  const iv = s.attempts.map(a => [a.start, a.end]);
  if (s.challenge.start) iv.push([s.challenge.start, s.challenge.paused ? s.challenge.pausedAt : now]);
  let ms = 0;
  for (const [a, b] of iv) { const lo = Math.max(a, from), hi = Math.min(b, to); if (hi > lo) ms += hi - lo; }
  return ms / DAY;
}

export const dateKey = (d = new Date()) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
export function weekKey(d = new Date()) {
  const t = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
  const n = t.getUTCDay() || 7; t.setUTCDate(t.getUTCDate() + 4 - n);
  const y0 = new Date(Date.UTC(t.getUTCFullYear(), 0, 1));
  return `${t.getUTCFullYear()}-W${String(Math.ceil(((t - y0) / DAY + 1) / 7)).padStart(2, '0')}`;
}
export const monthKey = (d = new Date()) => dateKey(d).slice(0, 7);
export const level = () => Math.floor(s.xp / 100) + 1;

export async function sha(text) {
  const b = await crypto.subtle.digest('SHA-256', new TextEncoder().encode('nfu:' + text));
  return [...new Uint8Array(b)].map(x => x.toString(16).padStart(2, '0')).join('');
}

// ফোন রিসেট বা পুনরায় ইনস্টলের পর আসল শুরুর তারিখ বসানো। আগের তারিখের ভিত্তিতে ব্যাজ নিজে আনলক হয়।
export function setStart(ts, now = Date.now()) {
  s.challenge = { start: ts, paused: false, pausedAt: 0, pausedTotal: 0 };
  const d = Math.floor((now - ts) / DAY);
  for (const b of BADGES) if (d >= b.min && !s.unlocked[b.id]) s.unlocked[b.id] = ts + b.min * DAY;
  save();
}
