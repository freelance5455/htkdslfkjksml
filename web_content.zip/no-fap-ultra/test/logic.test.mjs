// Logic tests for store.js (run: node test/logic.test.mjs)
import assert from 'node:assert/strict';
const mem = {}; globalThis.localStorage = { getItem: k => mem[k] ?? null, setItem: (k, v) => { mem[k] = v; } };
const S = await import('../www/js/store.js');
const { BADGES } = await import('../www/js/badges.js');
const D = S.DAY, T0 = 1_700_000_000_000;

assert.equal(S.elapsedMs(T0), 0);
S.start(T0);
assert.equal(S.currentDays(T0 + 25 * D + 7 * 3600e3), 25);
assert.equal(S.badgeForDays(25).id, 'advanced');
assert.equal(S.nextBadge(25).id, 'sigma');
// persistence: reload module state from storage
assert.ok(JSON.parse(mem['nofapultra.v1']).challenge.start === T0);
// badges unlock exactly at thresholds
let fresh = S.checkBadges(T0 + 3 * D).map(b => b.id);
assert.deepEqual(fresh, ['noob', 'novice']); // clown unlocked at start()
assert.ok(S.get().unlocked.clown);
assert.deepEqual(S.checkBadges(T0 + 3 * D), []); // no duplicates
assert.equal(S.checkBadges(T0 + 7 * D)[0].id, 'average');
// pause / resume excludes paused time
S.pause(T0 + 10 * D); assert.equal(S.currentDays(T0 + 50 * D), 10);
S.resume(T0 + 12 * D); assert.equal(S.currentDays(T0 + 14 * D), 12);
// setback preserves badges + history, resets streak
const unlockedBefore = Object.keys(S.get().unlocked).length;
S.endAttempt('setback', { what: 'x' }, T0 + 20 * D);
assert.equal(S.get().challenge.start, null);
assert.equal(S.get().attempts.length, 1);
assert.equal(Object.keys(S.get().unlocked).length, unlockedBefore);
assert.equal(S.setbackCount(), 1);
assert.equal(Math.floor(S.longestMs(T0 + 30 * D) / D), 18); // 20 days minus 2 paused
S.start(T0 + 21 * D);
assert.equal(S.totalAttempts(), 2);
assert.equal(S.totalDays(T0 + 26 * D), 23);
assert.ok(S.daysInRange(T0, T0 + 30 * D, T0 + 30 * D) > 0);
// badge table
assert.equal(BADGES.length, 12);
assert.deepEqual(BADGES.map(b => b.min), [0, 1, 3, 7, 15, 30, 45, 60, 120, 180, 365, 500]);
console.log('all logic tests passed');
