<?php
declare(strict_types=1);
require_once __DIR__ . '/platform.php';
require_once __DIR__ . '/voice.php';

function mh_setting(string $key, string $default=''): string {
    try { $q=db()->prepare('SELECT setting_value FROM platform_settings WHERE setting_key=?'); $q->execute(['magichour_'.$key]); $v=$q->fetchColumn(); return $v===false?$default:(string)$v; }
    catch(Throwable $e) { return $default; }
}
function mh_setting_set(string $key, string $value): void {
    $driver=db()->getAttribute(PDO::ATTR_DRIVER_NAME);
    if($driver==='sqlite') db()->prepare('INSERT INTO platform_settings(setting_key,setting_value,updated_at) VALUES(?,?,?) ON CONFLICT(setting_key) DO UPDATE SET setting_value=excluded.setting_value,updated_at=excluded.updated_at')->execute(['magichour_'.$key,$value,now_sql()]);
    else db()->prepare('INSERT INTO platform_settings(setting_key,setting_value,updated_at) VALUES(?,?,?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value),updated_at=VALUES(updated_at)')->execute(['magichour_'.$key,$value,now_sql()]);
}
function mh_api_key(): string {
    $cipher=mh_setting('key_cipher'); $nonce=mh_setting('key_nonce'); $tag=mh_setting('key_tag');
    if($cipher!==''&&$nonce!==''&&$tag!==''&&function_exists('openssl_decrypt')){
        $secret=trim((string)(app_config()['admin_api_encryption_key']??''));
        if(strlen($secret)>=32){try{$plain=openssl_decrypt($cipher,'aes-256-gcm',hash('sha256',$secret,true),0,base64_decode($nonce,true),base64_decode($tag,true));if(is_string($plain)&&$plain!=='')return $plain;}catch(Throwable $ignored){}}
    }
    $cfg=app_config();$legacy=trim((string)($cfg['magichour_api_key']??(getenv('MAGIC_HOUR_API_KEY')?:'')));
    return $legacy!==''&&!str_contains($legacy,'PASTE_')?$legacy:'';
}
function mh_ready(): bool { return mh_api_key()!=='' && mh_setting('enabled','0')==='1'; }
function mh_modes(): array {
    $raw=mh_setting('modes','lite'); $items=array_values(array_unique(array_filter(array_map(static fn($v)=>strtolower(trim($v)),explode(',',$raw)),static fn($v)=>preg_match('/^[a-z0-9_-]{1,40}$/',$v))));
    return $items ?: ['lite'];
}
function mh_api_request(string $method,string $path,?array $payload=null,int $timeout=45): array {
    if(!extension_loaded('curl')) throw new RuntimeException('PHP cURL is required for Magic Hour.');
    $key=mh_api_key(); if($key==='') throw new RuntimeException('Magic Hour API key is not configured.');
    $url='https://api.magichour.ai/v1'.(str_starts_with($path,'/')?$path:'/'. $path);
    $headers=['Accept: application/json','Authorization: Bearer '.$key];
    $opts=[CURLOPT_URL=>$url,CURLOPT_RETURNTRANSFER=>true,CURLOPT_CUSTOMREQUEST=>$method,CURLOPT_HTTPHEADER=>$headers,CURLOPT_CONNECTTIMEOUT=>15,CURLOPT_TIMEOUT=>$timeout,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2,CURLOPT_FOLLOWLOCATION=>false];
    if($payload!==null){$headers[]='Content-Type: application/json';$opts[CURLOPT_HTTPHEADER]=$headers;$opts[CURLOPT_POSTFIELDS]=json_encode($payload,JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR);}
    $ch=curl_init();curl_setopt_array($ch,$opts);$body=curl_exec($ch);
    if($body===false){$err=curl_error($ch);curl_close($ch);throw new RuntimeException('Magic Hour connection failed: '.$err);}
    $status=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);curl_close($ch);$json=json_decode((string)$body,true);
    return ['status'=>$status,'body'=>(string)$body,'json'=>is_array($json)?$json:[]];
}
function mh_error(array $r): string {
    $j=$r['json']??[];$msg=$j['message']??$j['detail']??$j['error']??'';
    return is_string($msg)&&$msg!==''?$msg:'Magic Hour returned HTTP '.(int)($r['status']??0).'.';
}
function mh_upload_signed(string $url,string $path,int $size): void {
    $parts=parse_url($url);$host=strtolower((string)($parts['host']??''));
    if(($parts['scheme']??'')!=='https'||$host===''||!(str_ends_with($host,'.magichour.ai')||$host==='magichour.ai'))throw new RuntimeException('Magic Hour returned an unexpected upload destination.');
    $fp=fopen($path,'rb');if(!$fp)throw new RuntimeException('Could not read uploaded media from private storage.');
    $ch=curl_init($url);curl_setopt_array($ch,[CURLOPT_PUT=>true,CURLOPT_INFILE=>$fp,CURLOPT_INFILESIZE=>$size,CURLOPT_RETURNTRANSFER=>true,CURLOPT_CONNECTTIMEOUT=>20,CURLOPT_TIMEOUT=>max(90,(int)ceil($size/250000)),CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2,CURLOPT_FOLLOWLOCATION=>false]);
    $body=curl_exec($ch);$status=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);$err=curl_error($ch);curl_close($ch);fclose($fp);
    if($body===false)throw new RuntimeException('Magic Hour media transfer failed: '.$err);
    if(!in_array($status,[200,201,204],true))throw new RuntimeException('Magic Hour media upload returned HTTP '.$status.'.');
}
function mh_charge(int $userId,int $amount,string $ref): int {
    if($amount<1)throw new InvalidArgumentException('Lip Sync credit price must be greater than zero.');
    voice_wallet_ensure($userId);$pdo=db();$sqlite=$pdo->getAttribute(PDO::ATTR_DRIVER_NAME)==='sqlite';
    try{
        if($sqlite)$pdo->exec('BEGIN IMMEDIATE');else $pdo->beginTransaction();
        $q=$pdo->prepare("SELECT id FROM credit_transactions WHERE user_id=? AND reference_id=? AND amount<0 LIMIT 1");$q->execute([$userId,$ref]);if($q->fetchColumn())throw new RuntimeException('This Lip Sync request has already been charged.');
        $u=$pdo->prepare('UPDATE user_wallets SET balance=balance-?,updated_at=? WHERE user_id=? AND balance>=?');$u->execute([$amount,now_sql(),$userId,$amount]);if($u->rowCount()!==1)throw new RuntimeException('Insufficient credits for this Lip Sync generation.');
        $b=$pdo->prepare('SELECT balance FROM user_wallets WHERE user_id=?');$b->execute([$userId]);$balance=(int)$b->fetchColumn();
        $pdo->prepare('INSERT INTO credit_transactions(user_id,amount,balance_after,reason,reference_id,created_at) VALUES(?,?,?,?,?,?)')->execute([$userId,-$amount,$balance,'Magic Hour Lip Sync',$ref,now_sql()]);
        if($sqlite)$pdo->exec('COMMIT');else$pdo->commit();return $balance;
    }catch(Throwable $e){if($sqlite){try{$pdo->exec('ROLLBACK');}catch(Throwable $ignored){}}elseif($pdo->inTransaction())$pdo->rollBack();throw $e;}
}
function mh_refund(int $userId,int $amount,string $ref): void {
    if($userId<1||$amount<1)return;$pdo=db();$sqlite=$pdo->getAttribute(PDO::ATTR_DRIVER_NAME)==='sqlite';
    try{
        if($sqlite)$pdo->exec('BEGIN IMMEDIATE');else$pdo->beginTransaction();
        $q=$pdo->prepare("SELECT id FROM credit_transactions WHERE user_id=? AND reference_id=? AND amount>0 AND reason='Magic Hour Lip Sync refund' LIMIT 1");$q->execute([$userId,$ref]);
        if(!$q->fetchColumn()){$d=$pdo->prepare("SELECT id FROM credit_transactions WHERE user_id=? AND reference_id=? AND amount<0 AND reason='Magic Hour Lip Sync' LIMIT 1");$d->execute([$userId,$ref]);if($d->fetchColumn()){$pdo->prepare('UPDATE user_wallets SET balance=balance+?,updated_at=? WHERE user_id=?')->execute([$amount,now_sql(),$userId]);$b=$pdo->prepare('SELECT balance FROM user_wallets WHERE user_id=?');$b->execute([$userId]);$balance=(int)$b->fetchColumn();$pdo->prepare('INSERT INTO credit_transactions(user_id,amount,balance_after,reason,reference_id,created_at) VALUES(?,?,?,?,?,?)')->execute([$userId,$amount,$balance,'Magic Hour Lip Sync refund',$ref,now_sql()]);}}
        if($sqlite)$pdo->exec('COMMIT');else$pdo->commit();
    }catch(Throwable $e){if($sqlite){try{$pdo->exec('ROLLBACK');}catch(Throwable $ignored){}}elseif($pdo->inTransaction())$pdo->rollBack();throw $e;}
}
function mh_store_job_status(string $id,string $status,?string $error=null,array $meta=[]): void {
    $q=db()->prepare('SELECT metadata FROM platform_jobs WHERE id=? AND owner_key=?');$q->execute([$id,owner_key()]);$old=json_decode((string)$q->fetchColumn(),true);if(!is_array($old))$old=[];
    $merged=array_merge($old,$meta);db()->prepare('UPDATE platform_jobs SET status=?,error_message=?,metadata=?,updated_at=? WHERE id=? AND owner_key=?')->execute([$status,$error,json_encode($merged,JSON_UNESCAPED_SLASHES),now_sql(),$id,owner_key()]);
}
function mh_ini_bytes(string $value): int {
    $value=trim($value);if($value==='')return 0;$unit=strtolower(substr($value,-1));$number=(float)$value;
    if($unit==='g')$number*=1024*1024*1024;elseif($unit==='m')$number*=1024*1024;elseif($unit==='k')$number*=1024;
    return (int)$number;
}
function mh_schema(): void {
    static $ready=false;if($ready)return;$driver=db()->getAttribute(PDO::ATTR_DRIVER_NAME);
    if($driver==='sqlite')db()->exec("CREATE TABLE IF NOT EXISTS magichour_idempotency (request_key TEXT PRIMARY KEY,user_id INTEGER NOT NULL,job_id TEXT NULL,status TEXT NOT NULL,created_at TEXT NOT NULL,updated_at TEXT NOT NULL)");
    else db()->exec("CREATE TABLE IF NOT EXISTS magichour_idempotency (request_key CHAR(32) PRIMARY KEY,user_id BIGINT NOT NULL,job_id VARCHAR(40) NULL,status VARCHAR(20) NOT NULL,created_at DATETIME NOT NULL,updated_at DATETIME NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $ready=true;
}
function mh_validate_upload(array $file,string $kind): array {
    if(($file['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_OK)throw new InvalidArgumentException('Upload failed. Check the file and shared-hosting upload limits.');
    $tmp=(string)($file['tmp_name']??'');if(!is_uploaded_file($tmp))throw new InvalidArgumentException('Upload validation failed.');
    $size=(int)($file['size']??0);$cfg=app_config();$max=(int)($cfg[$kind==='video'?'max_video_bytes':'max_audio_bytes']??($kind==='video'?100*1024*1024:30*1024*1024));$phpUpload=mh_ini_bytes((string)ini_get('upload_max_filesize'));if($phpUpload>0)$max=min($max,$phpUpload);
    if($size<1||$size>$max)throw new InvalidArgumentException('File exceeds the configured '.$kind.' upload limit of '.round($max/1048576).' MB.');
    $mime=(new finfo(FILEINFO_MIME_TYPE))->file($tmp)?:'';$ext=strtolower(pathinfo((string)($file['name']??''),PATHINFO_EXTENSION));
    $video=['mp4'=>['video/mp4','application/mp4'],'m4v'=>['video/mp4','video/x-m4v'],'mov'=>['video/quicktime'],'webm'=>['video/webm']];
    $audio=['mp3'=>['audio/mpeg','audio/mp3','application/octet-stream'],'wav'=>['audio/wav','audio/x-wav','audio/vnd.wave'],'aac'=>['audio/aac','audio/x-aac'],'flac'=>['audio/flac','audio/x-flac'],'m4a'=>['audio/mp4','audio/x-m4a'],'ogg'=>['audio/ogg','application/ogg'],'oga'=>['audio/ogg'],'opus'=>['audio/opus','audio/ogg'],'weba'=>['audio/webm'],'webm'=>['audio/webm'],'aiff'=>['audio/aiff','audio/x-aiff'],'amr'=>['audio/amr']];
    $map=$kind==='video'?$video:$audio;$allowed=$map[$ext]??null;if(!$allowed||!in_array($mime,$allowed,true))throw new InvalidArgumentException('The selected '.$kind.' extension and file signature do not match a supported format.');
    return ['tmp'=>$tmp,'size'=>$size,'mime'=>$mime,'ext'=>$ext,'name'=>secure_filename((string)($file['name']??($kind.'.'.$ext)))];
}
function mh_create_job(array $video,array $audio,array $settings,int $userId,string $requestKey): array {
    if(!mh_ready())throw new RuntimeException('Magic Hour Lip Sync is disabled or its API key is not configured. Contact the administrator.');
    if(!preg_match('/^[a-f0-9]{32}$/',$requestKey))throw new InvalidArgumentException('Refresh the page before submitting this Lip Sync request.');
    mh_schema();
    $existing=db()->prepare('SELECT user_id,job_id,status FROM magichour_idempotency WHERE request_key=?');$existing->execute([$requestKey]);$prior=$existing->fetch();
    if($prior){if((int)$prior['user_id']!==$userId)throw new InvalidArgumentException('Invalid Lip Sync request token.');if(!empty($prior['job_id']))return ['jobId'=>(string)$prior['job_id'],'providerJobId'=>null,'creditsCharged'=>max(1,(int)mh_setting('credit_price','30')),'duplicate'=>true];if(($prior['status']??'')==='failed')throw new RuntimeException('The previous attempt failed before a provider job was confirmed. Refresh the page to create a new request.');throw new RuntimeException('This Lip Sync submission is already being processed. Check shared history before trying again.');}
    $mode=(string)$settings['mode'];if(!in_array($mode,mh_modes(),true))throw new InvalidArgumentException('Select an enabled generation mode.');
    $start=(float)$settings['start'];$end=(float)$settings['end'];$fps=(float)$settings['fps'];
    if($start<0||$end<=$start||$end>3600)throw new InvalidArgumentException('Enter a valid clip range (end must be after start and no more than 60 minutes).');
    if($fps<1||$fps>60)throw new InvalidArgumentException('Maximum FPS must be between 1 and 60.');
    $dirs=platform_dirs();$vname=bin2hex(random_bytes(16)).'.'.$video['ext'];$aname=bin2hex(random_bytes(16)).'.'.$audio['ext'];
    $quota=max(1,(int)(app_config()['max_storage_per_user_bytes']??1073741824));if(platform_storage_used_bytes(owner_key(),$userId)+$video['size']+$audio['size']>$quota)throw new InvalidArgumentException('Your account storage quota would be exceeded.');
    try{db()->prepare('INSERT INTO magichour_idempotency(request_key,user_id,job_id,status,created_at,updated_at) VALUES(?,?,NULL,?,?,?)')->execute([$requestKey,$userId,'started',now_sql(),now_sql()]);}
    catch(Throwable $e){throw new RuntimeException('This Lip Sync submission is already being processed. Refresh shared history before trying again.');}
    if(!move_uploaded_file($video['tmp'],$dirs['inputs'].'/'.$vname)){db()->prepare('UPDATE magichour_idempotency SET status=?,updated_at=? WHERE request_key=?')->execute(['failed',now_sql(),$requestKey]);throw new RuntimeException('Could not store the source video.');}
    if(!move_uploaded_file($audio['tmp'],$dirs['references'].'/'.$aname)){@unlink($dirs['inputs'].'/'.$vname);db()->prepare('UPDATE magichour_idempotency SET status=?,updated_at=? WHERE request_key=?')->execute(['failed',now_sql(),$requestKey]);throw new RuntimeException('Could not store the source audio.');}
    $local=bin2hex(random_bytes(16));$ref=$local;$price=max(1,(int)mh_setting('credit_price','30'));$charged=false;$providerId=null;$uncertain=false;
    try{
        mh_charge($userId,$price,$ref);$charged=true;
        $urlRes=mh_api_request('POST','/files/upload-urls',['items'=>[['type'=>'video','extension'=>$video['ext']],['type'=>'audio','extension'=>$audio['ext']]]],45);
        if($urlRes['status']<200||$urlRes['status']>=300)throw new RuntimeException(mh_error($urlRes));
        $items=$urlRes['json']['items']??[];if(count($items)<2||empty($items[0]['upload_url'])||empty($items[0]['file_path'])||empty($items[1]['upload_url'])||empty($items[1]['file_path']))throw new RuntimeException('Magic Hour returned incomplete upload instructions.');
        mh_upload_signed((string)$items[0]['upload_url'],$dirs['inputs'].'/'.$vname,$video['size']);
        mh_upload_signed((string)$items[1]['upload_url'],$dirs['references'].'/'.$aname,$audio['size']);
        $name=trim((string)$settings['name']);if($name==='')$name='Lip Sync '.date('Y-m-d H:i');
        $payload=['name'=>substr($name,0,120),'start_seconds'=>$start,'end_seconds'=>$end,'max_fps_limit'=>$fps,'assets'=>['audio_file_path'=>$items[1]['file_path'],'video_source'=>'file','video_file_path'=>$items[0]['file_path']],'style'=>['generation_mode'=>$mode]];
        try{$gen=mh_api_request('POST','/lip-sync',$payload,60);}catch(Throwable $transport){$uncertain=true;throw $transport;}
        if($gen['status']>=500)$uncertain=true;
        if($gen['status']<200||$gen['status']>=300)throw new RuntimeException(mh_error($gen));
        $providerId=(string)($gen['json']['id']??'');if($providerId===''||strlen($providerId)>120)throw new RuntimeException('Magic Hour returned no valid project ID.');
        $meta=['provider'=>'magichour','provider_status'=>'queued','audio_disk'=>$aname,'audio_name'=>$audio['name'],'video_name'=>$video['name'],'mode'=>$mode,'user_id'=>$userId,'credit_cost'=>$price,'provider_credits_charged'=>$gen['json']['credits_charged']??null,'start_seconds'=>$start,'end_seconds'=>$end,'max_fps_limit'=>$fps];
        db()->prepare('INSERT INTO platform_jobs (id,owner_key,workspace,provider_job_id,model,prompt,status,input_disk,reference_disk,resolution,metadata,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)')
          ->execute([$local,owner_key(),'video',$providerId,'magic-hour-lip-sync',$name,'submitted',$vname,$aname,'source',json_encode($meta),now_sql(),now_sql()]);
        db()->prepare('UPDATE magichour_idempotency SET job_id=?,status=?,updated_at=? WHERE request_key=?')->execute([$local,'submitted',now_sql(),$requestKey]);
        return ['jobId'=>$local,'providerJobId'=>$providerId,'creditsCharged'=>$price,'duplicate'=>false];
    }catch(Throwable $e){
        if($providerId===null&&!$uncertain&&$charged){mh_refund($userId,$price,$ref);}
        if($providerId===null&&$uncertain){
            $meta=['provider'=>'magichour','provider_status'=>'submission_uncertain','audio_disk'=>$aname,'audio_name'=>$audio['name'],'video_name'=>$video['name'],'mode'=>$mode,'user_id'=>$userId,'credit_cost'=>$price,'manual_review'=>true];
            try{db()->prepare('INSERT INTO platform_jobs (id,owner_key,workspace,provider_job_id,model,prompt,status,input_disk,reference_disk,error_message,resolution,metadata,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)')->execute([$local,owner_key(),'video',null,'magic-hour-lip-sync',(string)$settings['name'],'failed',$vname,$aname,'Provider submission outcome is uncertain. Do not submit again until an administrator checks Magic Hour activity.','source',json_encode($meta),now_sql(),now_sql()]);}catch(Throwable $ignored){}
        }elseif($providerId!==null){
            $meta=['provider'=>'magichour','provider_status'=>'queued','audio_disk'=>$aname,'audio_name'=>$audio['name'],'video_name'=>$video['name'],'mode'=>$mode,'user_id'=>$userId,'credit_cost'=>$price,'manual_review'=>true];
            try{
                $exists=db()->prepare('SELECT id FROM platform_jobs WHERE id=? AND owner_key=?');$exists->execute([$local,owner_key()]);
                if(!$exists->fetchColumn())db()->prepare('INSERT INTO platform_jobs (id,owner_key,workspace,provider_job_id,model,prompt,status,input_disk,reference_disk,resolution,metadata,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)')->execute([$local,owner_key(),'video',$providerId,'magic-hour-lip-sync',(string)$settings['name'],'submitted',$vname,$aname,'source',json_encode($meta),now_sql(),now_sql()]);
            }catch(Throwable $ignored){}
        }else{@unlink($dirs['inputs'].'/'.$vname);@unlink($dirs['references'].'/'.$aname);}
        try{db()->prepare('UPDATE magichour_idempotency SET job_id=?,status=?,updated_at=? WHERE request_key=?')->execute([($providerId!==null||$uncertain)?$local:null,($providerId!==null)?'submitted':($uncertain?'uncertain':'failed'),now_sql(),$requestKey]);}catch(Throwable $ignored){}
        throw $e;
    }
}
function mh_download_output(string $url,string $localId): array {
    $parts=parse_url($url);$host=strtolower((string)($parts['host']??''));if(($parts['scheme']??'')!=='https'||$host===''||!(str_ends_with($host,'.magichour.ai')||$host==='magichour.ai'))throw new RuntimeException('Magic Hour returned an unexpected download host.');
    $dirs=platform_dirs();$tmp=$dirs['outputs'].'/'.$localId.'.part';$final=$dirs['outputs'].'/'.$localId.'.mp4';$fp=fopen($tmp,'wb');if(!$fp)throw new RuntimeException('Could not create output file.');
    $ch=curl_init($url);curl_setopt_array($ch,[CURLOPT_FILE=>$fp,CURLOPT_FOLLOWLOCATION=>false,CURLOPT_CONNECTTIMEOUT=>20,CURLOPT_TIMEOUT=>240,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2]);$ok=curl_exec($ch);$status=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);$mime=(string)curl_getinfo($ch,CURLINFO_CONTENT_TYPE);$err=curl_error($ch);curl_close($ch);fclose($fp);
    if($ok===false||$status<200||$status>=300){@unlink($tmp);throw new RuntimeException('Could not retrieve the completed Magic Hour output. '.($err?:'HTTP '.$status));}
    $bytes=(int)filesize($tmp);$quota=max(1,(int)(app_config()['max_storage_per_user_bytes']??1073741824));if(platform_storage_used_bytes(owner_key())+$bytes>$quota){@unlink($tmp);throw new RuntimeException('Output could not be retained because the account storage quota would be exceeded.');}
    $head=file_get_contents($tmp,false,null,0,16);if(!is_string($head)||strlen($head)<8||substr($head,4,4)!=='ftyp'){@unlink($tmp);throw new RuntimeException('Magic Hour output did not contain a valid MP4 file.');}
    if(!rename($tmp,$final)){@unlink($tmp);throw new RuntimeException('Could not save the completed output.');}
    return ['disk'=>$localId.'.mp4','bytes'=>$bytes,'mime'=>$mime!==''?$mime:'video/mp4'];
}
function mh_sync_job(string $localId): array {
    $job=platform_owned_job($localId);$meta=json_decode((string)$job['metadata'],true);if(!is_array($meta)||($meta['provider']??'')!=='magichour')throw new InvalidArgumentException('This is not a Magic Hour Lip Sync job.');
    if(in_array($job['status'],['completed','failed','expired'],true))return $job;
    if(empty($job['provider_job_id']))return $job;
    $r=mh_api_request('GET','/video-projects/'.rawurlencode((string)$job['provider_job_id']),null,45);
    if($r['status']<200||$r['status']>=300)throw new RuntimeException(mh_error($r));
    $p=$r['json'];$providerStatus=strtolower((string)($p['status']??''));$meta['provider_status']=$providerStatus;
    if(in_array($providerStatus,['queued','draft'],true))$localStatus='submitted';
    elseif($providerStatus==='rendering')$localStatus='processing';
    elseif($providerStatus==='complete'){
        $downloads=$p['downloads']??[];$url=(string)($downloads[0]['url']??'');
        if($url==='')throw new RuntimeException('Magic Hour reports completion but has not supplied a download URL.');
        $out=mh_download_output($url,$localId);
        db()->prepare('UPDATE platform_jobs SET status=?,output_disk=?,output_mime=?,output_bytes=?,error_message=NULL,metadata=?,updated_at=? WHERE id=? AND owner_key=?')->execute(['completed',$out['disk'],$out['mime'],$out['bytes'],json_encode($meta),now_sql(),$localId,owner_key()]);
        platform_save_asset($localId,$out['disk'],$out['mime'],'video',(string)($job['prompt']?:'Magic Hour Lip Sync output'));
        return platform_owned_job($localId);
    }elseif(in_array($providerStatus,['error','canceled'],true)){
        $localStatus='failed';$message=(string)($p['error']??'Magic Hour reported '.$providerStatus.'.');$uid=(int)($meta['user_id']??0);$cost=(int)($meta['credit_cost']??0);if($uid>0&&$cost>0)mh_refund($uid,$cost,$localId);mh_store_job_status($localId,'failed',$message,$meta);return platform_owned_job($localId);
    }else $localStatus=$job['status'];
    mh_store_job_status($localId,$localStatus,null,$meta);return platform_owned_job($localId);
}
