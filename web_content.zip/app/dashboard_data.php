<?php
declare(strict_types=1);
require_once __DIR__ . '/resources.php';
require_once __DIR__ . '/voice.php';

function dashboard_storage_report(string $ownerKey, int $userId): array {
    $pdo=db();$images=0;$videos=0;$audio=0;$refs=0;$items=0;
    $s=$pdo->prepare('SELECT disk_name,mime_type,kind FROM platform_assets WHERE owner_key=?');$s->execute([$ownerKey]);
    foreach($s->fetchAll() as $r){$path=APP_ROOT.'/storage/platform/outputs/'.basename((string)$r['disk_name']);if(!is_file($path)||is_link($path))continue;$size=(int)filesize($path);$items++;if(str_starts_with((string)$r['mime_type'],'image/'))$images+=$size;elseif(str_starts_with((string)$r['mime_type'],'video/'))$videos+=$size;}
    $s=$pdo->prepare('SELECT workspace,input_disk,reference_disk FROM platform_jobs WHERE owner_key=?');$s->execute([$ownerKey]);
    foreach($s->fetchAll() as $r){$input=(string)$r['input_disk'];$path=APP_ROOT.'/storage/platform/inputs/'.basename($input);if($input!==''&&is_file($path)&&!is_link($path)){$size=(int)filesize($path);$items++;if($r['workspace']==='video')$videos+=$size;else $images+=$size;} $ref=(string)($r['reference_disk']??'');$rpath=APP_ROOT.'/storage/platform/references/'.basename($ref);if($ref!==''&&is_file($rpath)&&!is_link($rpath)){$refs+=(int)filesize($rpath);$items++;}}
    $s=$pdo->prepare('SELECT disk_name,file_size FROM reference_uploads WHERE owner_key=?');$s->execute([$ownerKey]);
    foreach($s->fetchAll() as $r){$path=APP_ROOT.'/storage/references/'.basename((string)$r['disk_name']);if(is_file($path)&&!is_link($path)){$size=(int)filesize($path);$refs+=$size;$items++;}}
    $s=$pdo->prepare('SELECT audio_file FROM voice_generations WHERE user_id=?');$s->execute([$userId]);
    foreach($s->fetchAll(PDO::FETCH_COLUMN) as $file){$path=APP_ROOT.'/storage/voice-audio/'.basename((string)$file);if(is_file($path)&&!is_link($path)){$audio+=(int)filesize($path);$items++;}}
    $total=$images+$videos+$refs+$audio;
    $quota=max(1,(int)(app_config()['max_storage_per_user_bytes']??1073741824));
    return ['total'=>$total,'quota'=>$quota,'available'=>max(0,$quota-$total),'percent'=>min(100,round(($total/$quota)*100,1)),'images'=>$images,'videos'=>$videos,'references'=>$refs,'audio'=>$audio,'assets_count'=>$items];
}
function dashboard_recent_creations(int $userId, string $ownerKey, string $filter='all', int $limit=14): array {
    $pdo=db();$items=[];
    if(in_array($filter,['all','image','video'],true)){
        $sql="SELECT j.id,j.workspace,j.model,j.prompt,j.status,j.created_at,j.updated_at,j.error_message,a.mime_type AS output_mime FROM platform_jobs j LEFT JOIN platform_assets a ON a.job_id=j.id AND a.kind='output' WHERE j.owner_key=?";
        if($filter==='image')$sql.=" AND j.workspace='image'";elseif($filter==='video')$sql.=" AND j.workspace='video'";
        $sql.=' ORDER BY j.updated_at DESC LIMIT 24';$s=$pdo->prepare($sql);$s->execute([$ownerKey]);
        foreach($s->fetchAll() as $r){$items[]=['type'=>$r['workspace'],'title'=>ucfirst((string)$r['workspace']).' generation','model'=>$r['model'],'prompt'=>(string)$r['prompt'],'status'=>$r['status'],'created_at'=>$r['updated_at']?:$r['created_at'],'href'=>'api/media.php?id='.rawurlencode((string)$r['id']).'&kind=output','download_href'=>'api/media.php?id='.rawurlencode((string)$r['id']).'&kind=output&download=1','mime'=>$r['output_mime']??'','job_id'=>$r['id'],'error'=>$r['error_message']??''];}
    }
    if(in_array($filter,['all','voice'],true)){
        $s=$pdo->prepare('SELECT id,script,voice_id,model,created_at FROM voice_generations WHERE user_id=? ORDER BY created_at DESC LIMIT 12');$s->execute([$userId]);
        foreach($s->fetchAll() as $r){$items[]=['type'=>'voice','title'=>'Voice generation','model'=>$r['model'],'prompt'=>(string)$r['script'],'status'=>'completed','created_at'=>$r['created_at'],'href'=>'api/voice/audio.php?id='.rawurlencode((string)$r['id']),'download_href'=>'api/voice/audio.php?id='.rawurlencode((string)$r['id']).'&download=1','mime'=>'audio/mpeg','job_id'=>$r['id'],'error'=>''];}
    }
    if(in_array($filter,['all','realtime'],true)){
        $s=$pdo->prepare('SELECT remote_id,model,prompt,status,started_at,ended_at FROM realtime_sessions WHERE owner_key=? ORDER BY started_at DESC LIMIT 12');$s->execute([$ownerKey]);
        foreach($s->fetchAll() as $r){$items[]=['type'=>'realtime','title'=>'Realtime session','model'=>$r['model'],'prompt'=>(string)$r['prompt'],'status'=>$r['status'],'created_at'=>$r['started_at'],'href'=>'realtime/','download_href'=>'','mime'=>'','job_id'=>$r['remote_id'],'error'=>''];}
    }
    usort($items,static fn($a,$b)=>strcmp((string)$b['created_at'],(string)$a['created_at']));
    return array_slice($items,0,$limit);
}
function dashboard_load_data(array $user, string $filter='all'): array {
    resources_schema();
    $pdo=db();$userId=(int)$user['id'];$ownerKey=owner_key();
    $counts=['image'=>0,'video'=>0,'realtime'=>0,'voice'=>0,'active'=>0,'completed'=>0,'failed'=>0];
    $s=$pdo->prepare('SELECT workspace,status,COUNT(*) AS total FROM platform_jobs WHERE owner_key=? GROUP BY workspace,status');$s->execute([$ownerKey]);
    foreach($s->fetchAll() as $r){$ws=(string)$r['workspace'];$n=(int)$r['total'];if(isset($counts[$ws]))$counts[$ws]+=$n;if(in_array($r['status'],['submitted','processing'],true))$counts['active']+=$n;if($r['status']==='completed')$counts['completed']+=$n;if($r['status']==='failed')$counts['failed']+=$n;}
    $s=$pdo->prepare('SELECT COUNT(*) FROM realtime_sessions WHERE owner_key=?');$s->execute([$ownerKey]);$counts['realtime']=(int)$s->fetchColumn();
    $s=$pdo->prepare("SELECT COUNT(*) FROM realtime_sessions WHERE owner_key=? AND status IN ('starting','active')");$s->execute([$ownerKey]);$counts['active']+=(int)$s->fetchColumn();
    $s=$pdo->prepare('SELECT COUNT(*) FROM voice_generations WHERE user_id=?');$s->execute([$userId]);$counts['voice']=(int)$s->fetchColumn();
    $wallet=voice_wallet_balance($userId);
    $s=$pdo->prepare('SELECT COALESCE(SUM(CASE WHEN amount<0 THEN -amount ELSE 0 END),0) FROM credit_transactions WHERE user_id=?');$s->execute([$userId]);$creditsSpent=(int)$s->fetchColumn();
    $s=$pdo->prepare('SELECT id,amount,balance_after,reason,reference_id,created_at FROM credit_transactions WHERE user_id=? ORDER BY created_at DESC,id DESC LIMIT 8');$s->execute([$userId]);$transactions=$s->fetchAll();
    $storage=dashboard_storage_report($ownerKey,$userId);
    resources_sync_notifications($userId,$ownerKey,$storage['total'],$storage['quota'],$wallet);
    $s=$pdo->prepare('SELECT id,event_key,title,message,notification_type,link_url,read_at,created_at FROM notifications WHERE user_id=? ORDER BY created_at DESC,id DESC LIMIT 10');$s->execute([$userId]);$notifications=$s->fetchAll();
    $s=$pdo->prepare('SELECT workspace,title,target_url,accessed_at FROM dashboard_recent_access WHERE user_id=? AND workspace<>? ORDER BY accessed_at DESC,id DESC LIMIT 8');$s->execute([$userId,'dashboard']);$recentAccess=$s->fetchAll();
    $s=$pdo->prepare('SELECT id,title,description,prompt,category,updated_at FROM prompt_library WHERE owner_key=? AND is_custom=1 ORDER BY updated_at DESC LIMIT 5');$s->execute([$ownerKey]);$savedPrompts=$s->fetchAll();
    $activity=dashboard_recent_creations($userId,$ownerKey,$filter,14);
    $s=$pdo->prepare("SELECT j.id,j.workspace,j.model,j.prompt,j.status,j.updated_at FROM platform_jobs j WHERE j.owner_key=? ORDER BY j.updated_at DESC LIMIT 5");$s->execute([$ownerKey]);$recentProjects=$s->fetchAll();
    $s=$pdo->prepare('SELECT disk_name,original_name,mime_type,file_size,created_at FROM reference_uploads WHERE owner_key=? ORDER BY created_at DESC LIMIT 5');$s->execute([$ownerKey]);$recentReferences=$s->fetchAll();
    return compact('counts','wallet','creditsSpent','transactions','storage','notifications','recentAccess','savedPrompts','activity','recentProjects','recentReferences');
}
