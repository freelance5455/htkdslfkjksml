Put extra images/fonts for the app here.
