// آدرس عمومی فعلی Runflare که مالک پروژه ارائه کرده است.
// هشدار: تا زمان فعال‌شدن HTTPS، انتشار عمومی APK/WebView توصیه نمی‌شود.
window.AZARAKHSH_API_BASE = 'http://remote-fanhab.runflare.com:31177';
