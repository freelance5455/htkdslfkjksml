import {
  Baby,
  Briefcase,
  CarFront,
  Gamepad2,
  Gift,
  HeartPulse,
  Home,
  ShoppingBag,
  ShoppingBasket,
  Tag,
  TrendingUp,
  Utensils,
  Wrench,
  Zap,
  type LucideIcon,
} from "lucide-react";
import { format } from "date-fns";
import { ar } from "date-fns/locale";

export type { TransactionRow, CategoryRow, BudgetRow, SettingsRow } from "@/types/finance";

// ---------------------------------------------------------------------------
// Icons
// ---------------------------------------------------------------------------

const ICONS: Record<string, LucideIcon> = {
  "shopping-basket": ShoppingBasket,
  home: Home,
  zap: Zap,
  "car-front": CarFront,
  baby: Baby,
  "heart-pulse": HeartPulse,
  utensils: Utensils,
  "shopping-bag": ShoppingBag,
  "gamepad-2": Gamepad2,
  wrench: Wrench,
  briefcase: Briefcase,
  "trending-up": TrendingUp,
  gift: Gift,
  tag: Tag,
};

export function CategoryIcon({
  icon,
  color,
  size = 18,
}: {
  icon: string;
  color: string;
  size?: number;
}) {
  const Icon = ICONS[icon] ?? Tag;
  return (
    <span
      className="inline-flex shrink-0 items-center justify-center rounded-lg"
      style={{ backgroundColor: `${color}1f`, color, width: size + 20, height: size + 20 }}
    >
      <Icon size={size} strokeWidth={2.2} />
    </span>
  );
}

export const CATEGORY_ICON_KEYS = Object.keys(ICONS);

// ---------------------------------------------------------------------------
// Amounts (stored in minor units) & currency
// ---------------------------------------------------------------------------

export function formatAmount(minor: number, currency: string): string {
  const major = minor / 100;
  try {
    return new Intl.NumberFormat("ar-u-nu-latn", {
      style: "currency",
      currency,
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(major);
  } catch {
    return `${major.toFixed(2)} ${currency}`;
  }
}

/** Parse user text like "120.50" into minor units. Returns null when invalid. */
export function parseAmountToMinor(text: string): number | null {
  const normalized = text.replace(/[٠-٩]/g, (d) =>
    String("٠١٢٣٤٥٦٧٨٩".indexOf(d)),
  );
  const cleaned = normalized.replace(/[^\d.]/g, "");
  if (!cleaned) return null;
  const value = Number(cleaned);
  if (!Number.isFinite(value) || value < 0) return null;
  return Math.round(value * 100);
}

export const CURRENCIES = [
  { code: "SAR", label: "ريال سعودي" },
  { code: "AED", label: "درهم إماراتي" },
  { code: "EGP", label: "جنيه مصري" },
  { code: "JOD", label: "دينار أردني" },
  { code: "KWD", label: "دينار كويتي" },
  { code: "QAR", label: "ريال قطري" },
  { code: "BHD", label: "دينار بحريني" },
  { code: "OMR", label: "ريال عماني" },
  { code: "IQD", label: "دينار عراقي" },
  { code: "MAD", label: "درهم مغربي" },
  { code: "USD", label: "دولار أمريكي" },
  { code: "EUR", label: "يورو" },
];

// ---------------------------------------------------------------------------
// Months
// ---------------------------------------------------------------------------

export function currentMonthKey(): string {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
}

export function shiftMonth(monthKey: string, delta: number): string {
  const [y, m] = monthKey.split("-").map(Number);
  const d = new Date(y, m - 1 + delta, 1);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}

export function monthLabel(monthKey: string): string {
  const [y, m] = monthKey.split("-").map(Number);
  return format(new Date(y, m - 1, 1), "MMMM yyyy", { locale: ar });
}

export function dayLabel(dateStr: string): string {
  return format(new Date(dateStr + "T00:00:00"), "EEEE، d MMMM", { locale: ar });
}

export function todayStr(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(
    d.getDate(),
  ).padStart(2, "0")}`;
}
