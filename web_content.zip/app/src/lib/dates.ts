export function todayStr(d = new Date()): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

export function addDays(dateStr: string, days: number): string {
  const d = new Date(dateStr + "T00:00:00");
  d.setDate(d.getDate() + days);
  return todayStr(d);
}

export function diffDays(a: string, b: string): number {
  return Math.round((Date.parse(b + "T00:00:00Z") - Date.parse(a + "T00:00:00Z")) / 86400000);
}

const BULAN = [
  "Januari", "Februari", "Maret", "April", "Mei", "Juni",
  "Juli", "Agustus", "September", "Oktober", "November", "Desember",
];
const HARI = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"];

export function fmtDate(dateStr: string): string {
  const d = new Date(dateStr + "T00:00:00");
  return `${d.getDate()} ${BULAN[d.getMonth()]} ${d.getFullYear()}`;
}

export function fmtDateShort(dateStr: string): string {
  const d = new Date(dateStr + "T00:00:00");
  return `${d.getDate()} ${BULAN[d.getMonth()].slice(0, 3)}`;
}

export function fmtDay(dateStr: string): string {
  const d = new Date(dateStr + "T00:00:00");
  return HARI[d.getDay()];
}

export function fmtAgo(dateStr: string, today = todayStr()): string {
  const n = diffDays(dateStr, today);
  if (n === 0) return "hari ini";
  if (n === 1) return "kemarin";
  if (n < 7) return `${n} hari lalu`;
  if (n < 30) return `${Math.floor(n / 7)} minggu lalu`;
  if (n < 365) return `${Math.floor(n / 30)} bulan lalu`;
  return `${Math.floor(n / 365)} tahun lalu`;
}
