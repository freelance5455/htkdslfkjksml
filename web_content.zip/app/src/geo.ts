import {BackgroundGeolocation} from '@capgo/background-geolocation';
import {isNative} from './native';

// Ids acima deste valor pertencem à localização nativa em segundo plano
const NATIVE_ID_BASE = 1_000_000;
let nextNativeId = NATIVE_ID_BASE;
let activeNativeId: number | null = null;

type PosCb = (pos: GeolocationPosition) => void;
type ErrCb = (err: GeolocationPositionError) => void;

/**
 * No Android (APK) usa um serviço em primeiro plano com notificação permanente,
 * para a localização continuar a ser enviada com o ecrã bloqueado.
 * No browser usa o navigator.geolocation normal.
 */
export function watchPositionBg(
  success: PosCb,
  error: ErrCb,
  options?: PositionOptions
): number {
  if (!isNative) {
    return navigator.geolocation.watchPosition(success, error, options);
  }
  const id = nextNativeId++;
  activeNativeId = id;
  void BackgroundGeolocation.start(
    {
      backgroundTitle: 'PontoVivo: partilha de localização ativa',
      backgroundMessage:
        'A tua localização está a ser partilhada. Abre a app para parar.',
      requestPermissions: true,
      stale: false,
      distanceFilter: 5,
    },
    (location, err) => {
      if (activeNativeId !== id) return;
      if (err || !location) {
        const denied = err?.code === 'NOT_AUTHORIZED';
        error({
          code: denied ? 1 : 2,
          message: err?.message ?? 'Localização indisponível',
          PERMISSION_DENIED: 1,
          POSITION_UNAVAILABLE: 2,
          TIMEOUT: 3,
        } as GeolocationPositionError);
        return;
      }
      success({
        coords: {
          latitude: location.latitude,
          longitude: location.longitude,
          accuracy: location.accuracy,
          altitude: location.altitude,
          altitudeAccuracy: location.altitudeAccuracy,
          heading: location.bearing,
          speed: location.speed,
          toJSON() {
            return this;
          },
        },
        timestamp: location.time ?? Date.now(),
        toJSON() {
          return this;
        },
      } as GeolocationPosition);
    }
  ).catch((e: Error) => {
    if (activeNativeId !== id) return;
    error({
      code: 1,
      message: e?.message ?? 'Permissão negada',
      PERMISSION_DENIED: 1,
      POSITION_UNAVAILABLE: 2,
      TIMEOUT: 3,
    } as GeolocationPositionError);
  });
  return id;
}

export function clearWatchBg(id: number): void {
  if (id >= NATIVE_ID_BASE) {
    if (activeNativeId === id) {
      activeNativeId = null;
      void BackgroundGeolocation.stop().catch(() => {});
    }
    return;
  }
  navigator.geolocation?.clearWatch(id);
}
