import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/providers/trpc";
import {
  parseAmountToMinor,
  todayStr,
  type CategoryRow,
  type TransactionRow,
} from "@/lib/finance";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";

export function TransactionDialog({
  open,
  onOpenChange,
  categories,
  editing,
  preselectedKind,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  categories: CategoryRow[];
  editing: TransactionRow | null;
  preselectedKind?: "expense" | "income";
}) {
  const utils = trpc.useUtils();
  const [kind, setKind] = useState<"expense" | "income">("expense");
  const [categoryId, setCategoryId] = useState<string>("");
  const [amountText, setAmountText] = useState("");
  const [date, setDate] = useState(todayStr());
  const [note, setNote] = useState("");
  const [error, setError] = useState<string | null>(null);

  const filtered = useMemo(
    () => categories.filter(c => c.kind === kind),
    [categories, kind],
  );

  useEffect(() => {
    if (!open) return;
    setError(null);
    if (editing) {
      setKind(editing.categoryKind === "income" ? "income" : "expense");
      setCategoryId(String(editing.categoryId));
      setAmountText((editing.amount / 100).toFixed(2));
      setDate(editing.txDate);
      setNote(editing.note ?? "");
    } else {
      const initialKind = preselectedKind ?? "expense";
      setKind(initialKind);
      const match = categories.find(c => c.kind === initialKind);
      setCategoryId(match ? String(match.id) : "");
      setAmountText("");
      setDate(todayStr());
      setNote("");
    }
  }, [open, editing, categories, preselectedKind]);

  // Keep a valid category selected when kind or list changes.
  useEffect(() => {
    if (!open) return;
    if (!filtered.some(c => String(c.id) === categoryId)) {
      setCategoryId(filtered[0] ? String(filtered[0].id) : "");
    }
  }, [filtered, categoryId, open]);

  const invalidate = async () => {
    await utils.finance.transactions.list.invalidate();
    await utils.finance.budgets.list.invalidate();
  };

  const createMutation = trpc.finance.transactions.create.useMutation({
    onSuccess: async () => {
      await invalidate();
      toast.success("تمت إضافة المعاملة");
      onOpenChange(false);
    },
    onError: e => {
      setError(e.message);
      toast.error("تعذّر حفظ المعاملة");
    },
  });

  const updateMutation = trpc.finance.transactions.update.useMutation({
    onSuccess: async () => {
      await invalidate();
      toast.success("تم تحديث المعاملة");
      onOpenChange(false);
    },
    onError: e => {
      setError(e.message);
      toast.error("تعذّر تحديث المعاملة");
    },
  });

  const pending = createMutation.isPending || updateMutation.isPending;

  const handleSubmit = () => {
    const amount = parseAmountToMinor(amountText);
    if (!amount || amount <= 0) {
      setError("أدخل مبلغاً صحيحاً أكبر من صفر");
      return;
    }
    if (!categoryId) {
      setError("اختر الفئة");
      return;
    }
    if (!date) {
      setError("اختر التاريخ");
      return;
    }
    setError(null);
    if (editing) {
      updateMutation.mutate({
        id: editing.id,
        categoryId: Number(categoryId),
        amount,
        note: note.trim() || null,
        txDate: date,
      });
    } else {
      createMutation.mutate({
        categoryId: Number(categoryId),
        amount,
        note: note.trim() || undefined,
        txDate: date,
      });
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md" dir="rtl">
        <DialogHeader>
          <DialogTitle>{editing ? "تعديل معاملة" : "إضافة معاملة"}</DialogTitle>
          <DialogDescription>
            {editing
              ? "عدّل بيانات المعاملة ثم احفظ التغييرات."
              : "سجّل مصروفاً أو دخلاً جديداً لبيتك."}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-2">
          {/* kind toggle */}
          <div className="grid grid-cols-2 gap-2 rounded-xl bg-muted p-1">
            {(
              [
                { key: "expense", label: "مصروف" },
                { key: "income", label: "دخل" },
              ] as const
            ).map(k => (
              <button
                key={k.key}
                type="button"
                onClick={() => setKind(k.key)}
                className={`h-10 rounded-lg text-sm font-semibold transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ember ${
                  kind === k.key
                    ? k.key === "expense"
                      ? "bg-ember text-[#fdfcfa] shadow-sm"
                      : "bg-forest text-[#fdfcfa] shadow-sm"
                    : "text-muted-foreground hover:text-foreground"
                }`}
              >
                {k.label}
              </button>
            ))}
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label htmlFor="tx-amount">المبلغ</Label>
              <Input
                id="tx-amount"
                inputMode="decimal"
                placeholder="0.00"
                value={amountText}
                onChange={e => setAmountText(e.target.value)}
                className="tnum text-left"
                dir="ltr"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="tx-date">التاريخ</Label>
              <Input
                id="tx-date"
                type="date"
                value={date}
                onChange={e => setDate(e.target.value)}
                className="tnum"
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <Label>الفئة</Label>
            <Select value={categoryId} onValueChange={setCategoryId}>
              <SelectTrigger>
                <SelectValue placeholder="اختر الفئة" />
              </SelectTrigger>
              <SelectContent>
                {filtered.map(c => (
                  <SelectItem key={c.id} value={String(c.id)}>
                    {c.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="tx-note">ملاحظة (اختياري)</Label>
            <Textarea
              id="tx-note"
              rows={2}
              maxLength={255}
              placeholder="مثال: مشتريات الأسبوع من السوبرماركت"
              value={note}
              onChange={e => setNote(e.target.value)}
            />
          </div>

          {error && (
            <p className="rounded-lg bg-destructive/10 px-3 py-2 text-sm text-destructive">
              {error}
            </p>
          )}
        </div>

        <DialogFooter className="gap-2 sm:gap-0">
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            إلغاء
          </Button>
          <Button onClick={handleSubmit} disabled={pending}>
            {pending ? "جارٍ الحفظ…" : editing ? "حفظ التعديلات" : "إضافة"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
