import React, {useMemo, useState} from 'react';
import type {User} from 'firebase/auth';
import {
  BatteryCharging,
  BatteryFull,
  BatteryLow,
  BatteryMedium,
  Bell,
  Car,
  Check,
  Clock,
  Copy,
  Crosshair,
  Download,
  History,
  Loader2,
  LocateFixed,
  LogIn,
  LogOut,
  MapPin,
  Moon,
  Navigation,
  Package,
  PawPrint,
  Plus,
  Radio,
  Search,
  Share2,
  Shield,
  Siren,
  Sun,
  Trash2,
  User as UserIcon,
  UserPlus,
  X,
} from 'lucide-react';
import {useWeather} from '../hooks/useWeather';
import {
  type AppTheme,
  BLUEPRINT_LIMITS,
  CATEGORY_LABELS,
  type DeviceBatteryState,
  type Geofence,
  type GeofenceAlert,
  LOW_BATTERY_THRESHOLD,
  type NavTab,
  TRACKER_COLORS,
  type TrackPoint,
  type Tracker,
  type TrackerFilter,
  type UserPositionState,
  formatCoordinates,
  formatDateTimePt,
  formatDistance,
  formatRelativeTimePt,
  formatSpeedKmh,
  haversineDistanceMeters,
} from '../types/tracking';
import {getAccuracyDiagnostic} from '../utils/locationPrecision';
import type {MapPickMode} from './TrackingMap';
import {WeatherStrip} from './WeatherStrip';

interface SidebarPanelProps {
  isOpen: boolean;
  onClose: () => void;
  theme: AppTheme;
  onChangeTheme: (theme: AppTheme) => void;
  user: User | null;
  authReady: boolean;
  activeTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  trackers: Tracker[];
  selectedPoints: TrackPoint[];
  selectedHistoryPointId: string | null;
  onSelectHistoryPoint: (pointId: string | null) => void;
  onClearHistory: (tracker: Tracker) => Promise<void>;
  geofences: Geofence[];
  alerts: GeofenceAlert[];
  selectedTrackerId: string | null;
  activeBroadcastTrackerId: string | null;
  userPosition: UserPositionState | null;
  locatingUser: boolean;
  deviceBattery: DeviceBatteryState | null;
  pickMode: MapPickMode;
  pickedGeofenceCenter: {lat: number; lng: number} | null;
  joinMessage: {type: 'success' | 'error'; text: string} | null;
  onSignIn: () => void;
  onSignOut: () => void;
  onLocateMe: () => void;
  onSelectTracker: (trackerId: string) => void;
  onRequestBroadcast: (tracker: Tracker) => void;
  onStopBroadcast: (tracker: Tracker) => void;
  onStartPickTrackerLocation: (tracker: Tracker) => void;
  onRouteToTracker: (tracker: Tracker) => void;
  onShareTracker: (tracker: Tracker) => void;
  onDeleteTracker: (tracker: Tracker) => void;
  onLeaveSharedTracker: (tracker: Tracker) => void;
  onJoinByShareCode: (code: string) => Promise<void>;
  onOpenNewTrackerModal: () => void;
  onStartPickGeofenceCenter: () => void;
  onCreateGeofence: (data: {
    name: string;
    radiusMeters: number;
    color: string;
  }) => Promise<void>;
  onToggleGeofence: (geofence: Geofence) => void;
  onFocusCoords: (lat: number, lng: number, zoom?: number) => void;
  onDeleteGeofence: (geofence: Geofence) => void;
  onAcknowledgeAlert: (alert: GeofenceAlert) => void;
  onDeleteAlert: (alert: GeofenceAlert) => void;
  onOpenSos: () => void;
  hasActiveOwnSos: boolean;
}

function TrackerWeatherBadge({
  lat,
  lng,
  enabled,
}: {
  lat: number;
  lng: number;
  enabled: boolean;
}) {
  const {weather, isLoading} = useWeather({lat, lng}, enabled);
  if (!weather && !isLoading) return null;
  return (
    <div className="mt-2">
      <WeatherStrip weather={weather} isLoading={isLoading} compact />
    </div>
  );
}

function CategoryIcon({category}: {category: Tracker['category']}) {
  const cls = 'w-4 h-4';
  switch (category) {
    case 'vehicle':
      return <Car className={cls} />;
    case 'person':
      return <UserIcon className={cls} />;
    case 'pet':
      return <PawPrint className={cls} />;
    case 'asset':
    default:
      return <Package className={cls} />;
  }
}

function renderBatteryIcon(level: number, charging?: boolean) {
  if (charging) {
    return (
      <BatteryCharging className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400 shrink-0" />
    );
  }
  if (level < LOW_BATTERY_THRESHOLD) {
    return (
      <BatteryLow className="w-3.5 h-3.5 text-red-600 dark:text-red-400 shrink-0" />
    );
  }
  if (level < 60) {
    return (
      <BatteryMedium className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400 shrink-0" />
    );
  }
  return (
    <BatteryFull className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400 shrink-0" />
  );
}

function ThemeSwitcher({
  theme,
  onChangeTheme,
}: {
  theme: AppTheme;
  onChangeTheme: (theme: AppTheme) => void;
}) {
  return (
    <div className="flex items-center justify-between gap-3">
      <span className="text-xs font-medium text-slate-600 dark:text-slate-300 whitespace-nowrap">
        Tema
      </span>
      <div
        role="group"
        aria-label="Selecionar tema da interface e do mapa"
        className="inline-grid grid-cols-2 gap-1 p-0.5 bg-slate-200/80 dark:bg-slate-800 rounded-lg border border-slate-200 dark:border-slate-700"
      >
        <button
          type="button"
          onClick={() => onChangeTheme('light')}
          aria-pressed={theme === 'light'}
          className={`inline-flex items-center justify-center gap-1.5 px-2.5 py-1 text-xs font-medium rounded-md transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
            theme === 'light'
              ? 'bg-white text-slate-900 shadow-xs'
              : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          <Sun className="w-3.5 h-3.5" />
          Claro
        </button>
        <button
          type="button"
          onClick={() => onChangeTheme('dark')}
          aria-pressed={theme === 'dark'}
          className={`inline-flex items-center justify-center gap-1.5 px-2.5 py-1 text-xs font-medium rounded-md transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
            theme === 'dark'
              ? 'bg-slate-950 text-slate-100 shadow-xs'
              : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          <Moon className="w-3.5 h-3.5" />
          Escuro
        </button>
      </div>
    </div>
  );
}

export const SidebarPanel: React.FC<SidebarPanelProps> = ({
  isOpen,
  onClose,
  theme,
  onChangeTheme,
  user,
  authReady,
  activeTab,
  onSelectTab,
  trackers,
  selectedPoints,
  selectedHistoryPointId,
  onSelectHistoryPoint,
  onClearHistory,
  geofences,
  alerts,
  selectedTrackerId,
  activeBroadcastTrackerId,
  userPosition,
  locatingUser,
  deviceBattery,
  pickMode,
  pickedGeofenceCenter,
  joinMessage,
  onSignIn,
  onSignOut,
  onLocateMe,
  onSelectTracker,
  onRequestBroadcast,
  onStopBroadcast,
  onStartPickTrackerLocation,
  onRouteToTracker,
  onShareTracker,
  onDeleteTracker,
  onLeaveSharedTracker,
  onJoinByShareCode,
  onOpenNewTrackerModal,
  onStartPickGeofenceCenter,
  onCreateGeofence,
  onToggleGeofence,
  onFocusCoords,
  onDeleteGeofence,
  onAcknowledgeAlert,
  onDeleteAlert,
  onOpenSos,
  hasActiveOwnSos,
}) => {
  const [filter, setFilter] = useState<TrackerFilter>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [shareCodeInput, setShareCodeInput] = useState('');
  const [isJoining, setIsJoining] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Geofence form state
  const [fenceName, setFenceName] = useState('');
  const [fenceRadius, setFenceRadius] = useState(500);
  const [fenceColor, setFenceColor] = useState<string>(TRACKER_COLORS[1].value);
  const [isCreatingFence, setIsCreatingFence] = useState(false);

  // Clear history inline confirmation state
  const [confirmClearHistory, setConfirmClearHistory] = useState(false);
  const [isClearingHistory, setIsClearingHistory] = useState(false);

  const filteredTrackers = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return trackers.filter((t) => {
      if (filter === 'live' && !t.isBroadcasting) return false;
      if (filter === 'shared' && user && t.ownerId === user.uid) return false;
      if (
        q &&
        !t.name.toLowerCase().includes(q) &&
        !t.shareCode.toLowerCase().includes(q)
      ) {
        return false;
      }
      return true;
    });
  }, [trackers, filter, searchQuery, user]);

  const selectedTracker = useMemo(
    () => trackers.find((t) => t.id === selectedTrackerId) ?? null,
    [trackers, selectedTrackerId]
  );

  const reversedPoints = useMemo(
    () => [...selectedPoints].reverse(),
    [selectedPoints]
  );

  const historyStats = useMemo(() => {
    let totalDistance = 0;
    let maxSpeedMs = 0;
    let speedSumMs = 0;
    let speedCount = 0;
    let minAlt: number | null = null;
    let maxAlt: number | null = null;
    let sosCount = 0;

    for (let i = 0; i < selectedPoints.length; i++) {
      const pt = selectedPoints[i];
      if (i > 0) {
        totalDistance += haversineDistanceMeters(
          {lat: selectedPoints[i - 1].lat, lng: selectedPoints[i - 1].lng},
          {lat: pt.lat, lng: pt.lng}
        );
      }
      if (pt.speed > maxSpeedMs) maxSpeedMs = pt.speed;
      if (pt.speed > 0.1) {
        speedSumMs += pt.speed;
        speedCount += 1;
      }
      if (typeof pt.altitude === 'number') {
        minAlt = minAlt === null ? pt.altitude : Math.min(minAlt, pt.altitude);
        maxAlt = maxAlt === null ? pt.altitude : Math.max(maxAlt, pt.altitude);
      }
      if (pt.isSos || pt.source === 'sos') {
        sosCount += 1;
      }
    }

    const avgSpeedMs = speedCount > 0 ? speedSumMs / speedCount : 0;
    return {
      totalDistance,
      maxSpeedMs,
      avgSpeedMs,
      minAlt,
      maxAlt,
      sosCount,
    };
  }, [selectedPoints]);

  const resolvedTab: NavTab = activeTab === 'map' ? 'devices' : activeTab;
  const userWeatherInfo = useWeather(
    userPosition ? {lat: userPosition.lat, lng: userPosition.lng} : null,
    Boolean(isOpen && userPosition && resolvedTab === 'devices')
  );

  const handleExportHistory = (format: 'csv' | 'json') => {
    if (!selectedTracker || selectedPoints.length === 0) return;
    const safeSlug = selectedTracker.name
      .toLowerCase()
      .replace(/[^a-z0-9]+/gi, '-')
      .replace(/^-|-$/g, '') || 'rastreador';

    let content = '';
    let mime = 'application/json;charset=utf-8';
    if (format === 'json') {
      content = JSON.stringify(
        selectedPoints.map((pt) => ({
          id: pt.id,
          recordedAt: pt.recordedAt ? pt.recordedAt.toDate().toISOString() : null,
          lat: pt.lat,
          lng: pt.lng,
          accuracyMeters: pt.accuracy,
          speedKmh: Math.round(pt.speed * 3.6 * 10) / 10,
          headingDeg: pt.heading,
          altitudeMeters: pt.altitude ?? null,
          altitudeAccuracyMeters: pt.altitudeAccuracy ?? null,
          batteryLevel: pt.batteryLevel ?? null,
          batteryCharging: pt.batteryCharging ?? null,
          address: pt.address ?? null,
          weatherTempC: pt.weatherTempC ?? null,
          weatherCondition: pt.weatherCondition ?? null,
          weatherWindKmh: pt.weatherWindKmh ?? null,
          weatherHumidity: pt.weatherHumidity ?? null,
          distanceFromPrevMeters: pt.distanceFromPrevMeters ?? null,
          isSos: Boolean(pt.isSos || pt.source === 'sos'),
          source: pt.source,
        })),
        null,
        2
      );
    } else {
      mime = 'text/csv;charset=utf-8';
      const headers = [
        'data_hora',
        'latitude',
        'longitude',
        'precisao_m',
        'velocidade_kmh',
        'direcao_graus',
        'altitude_m',
        'bateria_pct',
        'carregando',
        'endereco',
        'clima_temp_c',
        'clima_condicao',
        'clima_vento_kmh',
        'clima_umidade_pct',
        'deslocamento_m',
        'sos',
        'origem',
      ];
      const escapeCsv = (val: unknown) => {
        const s = val === null || val === undefined ? '' : String(val);
        return `"${s.replace(/"/g, '""')}"`;
      };
      const rows = selectedPoints.map((pt) =>
        [
          pt.recordedAt ? pt.recordedAt.toDate().toISOString() : '',
          pt.lat.toFixed(6),
          pt.lng.toFixed(6),
          Math.round(pt.accuracy),
          (pt.speed * 3.6).toFixed(1),
          Math.round(pt.heading),
          typeof pt.altitude === 'number' ? Math.round(pt.altitude) : '',
          typeof pt.batteryLevel === 'number' ? Math.round(pt.batteryLevel) : '',
          typeof pt.batteryCharging === 'boolean' ? (pt.batteryCharging ? 'sim' : 'nao') : '',
          pt.address ?? '',
          typeof pt.weatherTempC === 'number' ? Math.round(pt.weatherTempC) : '',
          pt.weatherCondition ?? '',
          typeof pt.weatherWindKmh === 'number' ? Math.round(pt.weatherWindKmh) : '',
          typeof pt.weatherHumidity === 'number' ? Math.round(pt.weatherHumidity) : '',
          typeof pt.distanceFromPrevMeters === 'number'
            ? Math.round(pt.distanceFromPrevMeters)
            : '',
          pt.isSos || pt.source === 'sos' ? 'sim' : 'nao',
          pt.source,
        ]
          .map(escapeCsv)
          .join(',')
      );
      content = [headers.join(','), ...rows].join('\n');
    }

    const blob = new Blob([content], {type: mime});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `pontovivo-historico-${safeSlug}-${Date.now()}.${format}`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleCopyCode = (tracker: Tracker) => {
    void navigator.clipboard?.writeText(tracker.shareCode);
    setCopiedId(tracker.id);
    window.setTimeout(() => setCopiedId(null), 1800);
  };

  const handleCopyCoords = (key: string, lat: number, lng: number) => {
    void navigator.clipboard?.writeText(`${lat.toFixed(6)}, ${lng.toFixed(6)}`);
    setCopiedId(key);
    window.setTimeout(() => setCopiedId(null), 1600);
  };

  const handleJoinSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleaned = shareCodeInput.trim().toUpperCase();
    if (!cleaned) return;
    setIsJoining(true);
    try {
      await onJoinByShareCode(cleaned);
      setShareCodeInput('');
    } finally {
      setIsJoining(false);
    }
  };

  const handleCreateFenceSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = fenceName.trim();
    if (!trimmed) return;
    setIsCreatingFence(true);
    try {
      await onCreateGeofence({
        name: trimmed.slice(0, BLUEPRINT_LIMITS.NAME_MAX),
        radiusMeters: fenceRadius,
        color: fenceColor,
      });
      setFenceName('');
    } finally {
      setIsCreatingFence(false);
    }
  };

  const handleConfirmClearHistory = async () => {
    if (!selectedTracker) return;
    setIsClearingHistory(true);
    try {
      await onClearHistory(selectedTracker);
      setConfirmClearHistory(false);
    } finally {
      setIsClearingHistory(false);
    }
  };

  if (!isOpen) {
    return null;
  }

  const drawerHeader = (
    <div className="px-4 py-3 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3 shrink-0">
      <span className="text-sm font-semibold text-slate-900 dark:text-slate-100">
        Menu
      </span>
      <div className="flex items-center gap-2">
        {user && (
          <button
            type="button"
            onClick={() => {
              onClose();
              onOpenSos();
            }}
            className={`inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-bold rounded-md transition-colors cursor-pointer whitespace-nowrap ${
              hasActiveOwnSos
                ? 'bg-red-600 text-white animate-pulse'
                : 'bg-red-600 hover:bg-red-700 text-white'
            }`}
          >
            <Siren className="w-3.5 h-3.5" />
            SOS
          </button>
        )}
        <button
          type="button"
          onClick={onClose}
          aria-label="Fechar menu"
          className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 rounded-md transition-colors cursor-pointer whitespace-nowrap"
        >
          <X className="w-4 h-4" />
          Fechar
        </button>
      </div>
    </div>
  );

  if (!authReady) {
    return (
      <div
        className="fixed inset-0 z-40 flex"
        role="dialog"
        aria-modal="true"
        aria-label="Menu do PontoVivo"
      >
        <div
          className="fixed inset-0 bg-slate-950/40 backdrop-blur-[1px]"
          onClick={onClose}
          aria-hidden="true"
        />
        <aside className="relative z-10 w-full max-w-[380px] h-full bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 shadow-2xl flex flex-col justify-between">
          {drawerHeader}
          <div className="p-5 flex-1 flex flex-col gap-3">
            <div className="h-9 bg-slate-100 dark:bg-slate-800 rounded-lg animate-pulse" />
            <div className="h-24 bg-slate-100 dark:bg-slate-800 rounded-lg animate-pulse" />
            <div className="h-24 bg-slate-100 dark:bg-slate-800 rounded-lg animate-pulse" />
          </div>
          <div className="px-4 py-3 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/95">
            <ThemeSwitcher theme={theme} onChangeTheme={onChangeTheme} />
          </div>
        </aside>
      </div>
    );
  }

  if (!user) {
    return (
      <div
        className="fixed inset-0 z-40 flex"
        role="dialog"
        aria-modal="true"
        aria-label="Menu do PontoVivo"
      >
        <div
          className="fixed inset-0 bg-slate-950/40 backdrop-blur-[1px]"
          onClick={onClose}
          aria-hidden="true"
        />
        <aside className="relative z-10 w-full max-w-[380px] h-full bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 shadow-2xl flex flex-col justify-between">
          {drawerHeader}
          <div className="p-6 flex-1 flex flex-col justify-between overflow-y-auto">
            <div>
              <h2 className="text-lg font-semibold text-slate-900 dark:text-slate-100 mb-2">
                Rastreamento em tempo real sincronizado
              </h2>
              <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed mb-5">
                Conecte sua conta Google para criar rastreadores, transmitir sua
                posição GPS com consentimento, consultar o histórico de
                localização e monitorar cercas virtuais ao vivo.
              </p>

              <button
                type="button"
                onClick={onSignIn}
                className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium rounded-lg transition-colors cursor-pointer"
              >
                <LogIn className="w-4 h-4" />
                Entrar com Google
              </button>
            </div>

            <div className="mt-6 pt-5 border-t border-slate-100 dark:border-slate-800 space-y-2.5 text-xs text-slate-500 dark:text-slate-400">
              <p>· Atualizações em tempo real entre dispositivos</p>
              <p>· Histórico de localização com linha do tempo no mapa</p>
              <p>· Rotas e tempo estimado até qualquer dispositivo</p>
              <p>· Alertas automáticos de entrada e saída em cercas virtuais</p>
            </div>
          </div>

          <div className="px-4 py-3 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/95 shrink-0">
            <ThemeSwitcher theme={theme} onChangeTheme={onChangeTheme} />
          </div>
        </aside>
      </div>
    );
  }

  const unacknowledgedCount = alerts.filter((a) => !a.acknowledged).length;

  return (
    <div
      className="fixed inset-0 z-40 flex"
      role="dialog"
      aria-modal="true"
      aria-label="Menu do PontoVivo"
    >
      <div
        className="fixed inset-0 bg-slate-950/40 backdrop-blur-[1px]"
        onClick={onClose}
        aria-hidden="true"
      />

      <aside className="relative z-10 w-full max-w-[380px] h-full bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 shadow-2xl flex flex-col min-h-0">
        {drawerHeader}

        {/* Drawer internal section switcher (works on mobile & desktop) */}
        <div className="px-3 py-2 border-b border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-900/60 shrink-0">
          <div className="grid grid-cols-4 gap-1 p-1 bg-slate-200/70 dark:bg-slate-800 rounded-lg">
            <button
              type="button"
              onClick={() => onSelectTab('devices')}
              className={`py-1.5 px-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer whitespace-nowrap truncate ${
                resolvedTab === 'devices'
                  ? 'bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 shadow-xs'
                  : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              Dispositivos
            </button>
            <button
              type="button"
              onClick={() => onSelectTab('history')}
              className={`py-1.5 px-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer whitespace-nowrap truncate ${
                resolvedTab === 'history'
                  ? 'bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 shadow-xs'
                  : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              Histórico
            </button>
            <button
              type="button"
              onClick={() => onSelectTab('geofences')}
              className={`py-1.5 px-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer whitespace-nowrap truncate ${
                resolvedTab === 'geofences'
                  ? 'bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 shadow-xs'
                  : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              Cercas
            </button>
            <button
              type="button"
              onClick={() => onSelectTab('alerts')}
              className={`py-1.5 px-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer whitespace-nowrap truncate ${
                resolvedTab === 'alerts'
                  ? 'bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 shadow-xs'
                  : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              Alertas{unacknowledgedCount > 0 ? ` (${unacknowledgedCount})` : ''}
            </button>
          </div>
        </div>

        {/* Main scrollable body */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {resolvedTab === 'devices' && (
            <>
              {/* Local device GPS & battery telemetry strip */}
              <div className="border border-slate-200 dark:border-slate-800 rounded-xl p-3 bg-slate-50/70 dark:bg-slate-800/50 space-y-2">
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2 min-w-0">
                    <span
                      className={`w-2.5 h-2.5 rounded-full shrink-0 ${
                        userPosition
                          ? 'bg-blue-600 ring-2 ring-blue-200 dark:ring-blue-500/40'
                          : 'bg-slate-300 dark:bg-slate-600'
                      }`}
                    />
                    <span className="text-xs font-semibold text-slate-900 dark:text-slate-100 truncate">
                      Sua localização atual
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5 shrink-0">
                    {userPosition && (
                      <button
                        type="button"
                        onClick={() => {
                          onFocusCoords(userPosition.lat, userPosition.lng, 16);
                          onClose();
                        }}
                        className="text-xs font-medium text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 cursor-pointer whitespace-nowrap"
                      >
                        Ver no mapa
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={onLocateMe}
                      disabled={locatingUser}
                      className="inline-flex items-center gap-1 px-2 py-1 text-xs font-medium bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 disabled:opacity-60 rounded-md transition-colors cursor-pointer whitespace-nowrap"
                    >
                      {locatingUser ? (
                        <Loader2 className="w-3 h-3 animate-spin text-blue-600 dark:text-blue-400" />
                      ) : (
                        <LocateFixed className="w-3 h-3 text-blue-600 dark:text-blue-400" />
                      )}
                      {locatingUser
                        ? 'Calibrando...'
                        : userPosition
                          ? 'Calibrar'
                          : 'Ativar GPS'}
                    </button>
                  </div>
                </div>

                {userPosition ? (
                  <div className="space-y-1">
                    <div className="flex items-center justify-between gap-2 text-[11px]">
                      <span
                        className={`font-medium ${
                          getAccuracyDiagnostic(userPosition.accuracy).tier ===
                          'high'
                            ? 'text-emerald-700 dark:text-emerald-400'
                            : getAccuracyDiagnostic(userPosition.accuracy)
                                  .tier === 'moderate'
                              ? 'text-slate-700 dark:text-slate-300'
                              : 'text-amber-700 dark:text-amber-400'
                        }`}
                      >
                        {getAccuracyDiagnostic(userPosition.accuracy).label}
                      </span>
                      <span className="font-mono tabular-nums text-slate-600 dark:text-slate-300">
                        ±{formatDistance(userPosition.accuracy)}
                        {typeof userPosition.altitude === 'number'
                          ? ` · ${Math.round(userPosition.altitude)} m alt`
                          : ''}
                      </span>
                    </div>

                    <div className="flex items-center justify-between gap-2">
                      <span className="text-[11px] font-mono tabular-nums text-slate-500 dark:text-slate-400">
                        {formatCoordinates(userPosition.lat, userPosition.lng)}
                      </span>
                      <button
                        type="button"
                        onClick={() =>
                          handleCopyCoords(
                            'user-coords',
                            userPosition.lat,
                            userPosition.lng
                          )
                        }
                        className="inline-flex items-center gap-1 text-[11px] text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100 transition-colors cursor-pointer"
                      >
                        {copiedId === 'user-coords' ? (
                          <>
                            <Check className="w-3 h-3 text-emerald-600 dark:text-emerald-400" />
                            Copiado
                          </>
                        ) : (
                          <>
                            <Copy className="w-3 h-3" />
                            Copiar
                          </>
                        )}
                      </button>
                    </div>

                    <WeatherStrip
                      weather={userWeatherInfo.weather}
                      isLoading={userWeatherInfo.isLoading}
                      compact
                    />
                  </div>
                ) : (
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    Clique em &quot;Ativar GPS&quot; para calibração de alta precisão no mapa.
                  </p>
                )}

                {deviceBattery && (
                  <div className="pt-2 border-t border-slate-200/80 dark:border-slate-700/80 flex items-center justify-between gap-2 text-xs">
                    <span className="text-slate-600 dark:text-slate-300 inline-flex items-center gap-1.5">
                      {renderBatteryIcon(
                        deviceBattery.level,
                        deviceBattery.charging
                      )}
                      <span>Bateria do dispositivo</span>
                    </span>
                    <span
                      className={`font-mono tabular-nums ${
                        deviceBattery.level < LOW_BATTERY_THRESHOLD
                          ? 'text-red-700 dark:text-red-400 font-semibold'
                          : 'text-slate-900 dark:text-slate-100'
                      }`}
                    >
                      {deviceBattery.level}%
                      {deviceBattery.charging
                        ? ' · Carregando'
                        : deviceBattery.level < LOW_BATTERY_THRESHOLD
                          ? ' · Bateria baixa'
                          : ''}
                    </span>
                  </div>
                )}
              </div>

              {/* Search & Segmented Filter */}
              <div className="space-y-2.5">
                <div className="relative">
                  <Search className="w-4 h-4 text-slate-400 dark:text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Filtrar por nome ou código..."
                    aria-label="Filtrar rastreadores"
                    className="w-full pl-9 pr-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600 dark:focus:border-blue-500"
                  />
                </div>

                <div className="grid grid-cols-3 gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-lg">
                  <button
                    type="button"
                    onClick={() => setFilter('all')}
                    className={`py-1.5 px-2 text-xs font-medium rounded-md transition-colors cursor-pointer whitespace-nowrap ${
                      filter === 'all'
                        ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-xs'
                        : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
                    }`}
                  >
                    Todos ({trackers.length})
                  </button>
                  <button
                    type="button"
                    onClick={() => setFilter('live')}
                    className={`py-1.5 px-2 text-xs font-medium rounded-md transition-colors cursor-pointer whitespace-nowrap ${
                      filter === 'live'
                        ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-xs'
                        : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
                    }`}
                  >
                    Ao vivo ({trackers.filter((t) => t.isBroadcasting).length})
                  </button>
                  <button
                    type="button"
                    onClick={() => setFilter('shared')}
                    className={`py-1.5 px-2 text-xs font-medium rounded-md transition-colors cursor-pointer whitespace-nowrap ${
                      filter === 'shared'
                        ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-xs'
                        : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
                    }`}
                  >
                    Compartilhados
                  </button>
                </div>
              </div>

              {/* Join by share code */}
              <form
                onSubmit={(e) => void handleJoinSubmit(e)}
                className="space-y-1.5"
              >
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={shareCodeInput}
                    onChange={(e) =>
                      setShareCodeInput(e.target.value.toUpperCase())
                    }
                    placeholder="Código compartilhado (PV-...)"
                    aria-label="Código compartilhado"
                    className="flex-1 px-3 py-1.5 text-xs font-mono uppercase bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600 dark:focus:border-blue-500"
                  />
                  <button
                    type="submit"
                    disabled={isJoining || !shareCodeInput.trim()}
                    className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-medium bg-slate-900 dark:bg-blue-600 text-white rounded-lg hover:bg-slate-800 dark:hover:bg-blue-700 disabled:opacity-50 transition-colors cursor-pointer whitespace-nowrap shrink-0"
                  >
                    <UserPlus className="w-3.5 h-3.5" />
                    Acompanhar
                  </button>
                </div>
                {joinMessage && (
                  <p
                    className={`text-xs ${
                      joinMessage.type === 'error'
                        ? 'text-red-600 dark:text-red-400'
                        : 'text-emerald-700 dark:text-emerald-400'
                    }`}
                  >
                    {joinMessage.text}
                  </p>
                )}
              </form>

              {/* Tracker list */}
              {filteredTrackers.length === 0 ? (
                <div className="border border-dashed border-slate-200 dark:border-slate-700 rounded-xl p-6 text-center">
                  <MapPin className="w-6 h-6 text-slate-400 dark:text-slate-500 mx-auto mb-2" />
                  <p className="text-sm font-medium text-slate-900 dark:text-slate-100 mb-1">
                    Nenhum rastreador encontrado
                  </p>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">
                    Crie seu primeiro rastreador ou insira um código compartilhado para acompanhar ao vivo.
                  </p>
                  <button
                    type="button"
                    onClick={onOpenNewTrackerModal}
                    className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    Criar rastreador
                  </button>
                </div>
              ) : (
                <div className="divide-y divide-slate-100 dark:divide-slate-800 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden bg-white dark:bg-slate-900">
                  {filteredTrackers.map((tracker) => {
                    const isOwner = tracker.ownerId === user.uid;
                    const isSelected = tracker.id === selectedTrackerId;
                    const isThisBroadcasting =
                      activeBroadcastTrackerId === tracker.id ||
                      tracker.isBroadcasting;
                    const isPickingThis =
                      pickMode.type === 'move-tracker' &&
                      pickMode.trackerId === tracker.id;

                    return (
                      <div
                        key={tracker.id}
                        onClick={() => {
                          onSelectTracker(tracker.id);
                          onFocusCoords(tracker.lat, tracker.lng, 15);
                          onClose();
                        }}
                        className={`p-3.5 transition-colors cursor-pointer ${
                          isSelected
                            ? 'bg-blue-50/55 dark:bg-blue-950/40'
                            : 'hover:bg-slate-50 dark:hover:bg-slate-800/60'
                        }`}
                      >
                        <div className="flex items-start justify-between gap-2.5">
                          <div className="flex items-start gap-2.5 min-w-0">
                            <div
                              className="w-8 h-8 rounded-lg flex items-center justify-center text-white shrink-0 mt-0.5"
                              style={{backgroundColor: tracker.color}}
                            >
                              <CategoryIcon category={tracker.category} />
                            </div>
                            <div className="min-w-0">
                              <div className="flex items-center gap-2">
                                <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100 truncate">
                                  {tracker.name}
                                </h3>
                              </div>
                              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                                {CATEGORY_LABELS[tracker.category]} ·{' '}
                                {tracker.isBroadcasting ? (
                                  <span className="text-emerald-700 dark:text-emerald-400 font-medium inline-flex items-center gap-1">
                                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 dark:bg-emerald-400 inline-block" />
                                    Ao vivo
                                  </span>
                                ) : (
                                  'Inativo'
                                )}{' '}
                                · {formatRelativeTimePt(tracker.lastSeenAt)}
                              </p>
                            </div>
                          </div>

                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleCopyCode(tracker);
                            }}
                            title="Copiar código de compartilhamento"
                            className="inline-flex items-center gap-1 text-[11px] font-mono tabular-nums text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100 transition-colors cursor-pointer shrink-0"
                          >
                            {copiedId === tracker.id ? (
                              <>
                                <Check className="w-3 h-3 text-emerald-600 dark:text-emerald-400" />
                                Copiado
                              </>
                            ) : (
                              <>
                                <Copy className="w-3 h-3" />
                                {tracker.shareCode}
                              </>
                            )}
                          </button>
                        </div>

                        <div className="mt-2.5 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-600 dark:text-slate-300 font-mono tabular-nums">
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleCopyCoords(
                                `coords-${tracker.id}`,
                                tracker.lat,
                                tracker.lng
                              );
                            }}
                            title="Copiar coordenadas exatas"
                            className="inline-flex items-center gap-1 hover:text-blue-600 dark:hover:text-blue-400 transition-colors cursor-pointer"
                          >
                            <span>
                              {formatCoordinates(tracker.lat, tracker.lng)}
                            </span>
                            {copiedId === `coords-${tracker.id}` ? (
                              <Check className="w-3 h-3 text-emerald-600 dark:text-emerald-400" />
                            ) : (
                              <Copy className="w-3 h-3 opacity-60" />
                            )}
                          </button>
                          <div className="flex items-center gap-2.5">
                            <span
                              title={getAccuracyDiagnostic(tracker.accuracy).label}
                              className={
                                getAccuracyDiagnostic(tracker.accuracy).tier ===
                                'high'
                                  ? 'text-emerald-700 dark:text-emerald-400'
                                  : getAccuracyDiagnostic(tracker.accuracy)
                                        .tier === 'low'
                                    ? 'text-amber-700 dark:text-amber-400'
                                    : ''
                              }
                            >
                              ±{formatDistance(tracker.accuracy)}
                            </span>
                            {typeof tracker.batteryLevel === 'number' && (
                              <span
                                className={`inline-flex items-center gap-1 ${
                                  tracker.batteryLevel < LOW_BATTERY_THRESHOLD
                                    ? 'text-red-700 dark:text-red-400 font-semibold'
                                    : 'text-slate-600 dark:text-slate-300'
                                }`}
                              >
                                {renderBatteryIcon(
                                  tracker.batteryLevel,
                                  tracker.batteryCharging
                                )}
                                {Math.round(tracker.batteryLevel)}%
                                {tracker.batteryLevel < LOW_BATTERY_THRESHOLD && (
                                  <span className="font-sans">
                                    · Bateria baixa
                                  </span>
                                )}
                              </span>
                            )}
                            <span>{formatSpeedKmh(tracker.speed)}</span>
                          </div>
                        </div>

                        <TrackerWeatherBadge
                          lat={tracker.lat}
                          lng={tracker.lng}
                          enabled={isOpen && resolvedTab === 'devices'}
                        />

                        {/* Controls */}
                        <div
                          className="mt-3 pt-2.5 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center gap-1.5"
                          onClick={(e) => e.stopPropagation()}
                        >
                          {isOwner && (
                            <>
                              {isThisBroadcasting ? (
                                <button
                                  type="button"
                                  onClick={() => onStopBroadcast(tracker)}
                                  className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium bg-emerald-600 text-white rounded-md hover:bg-emerald-700 transition-colors cursor-pointer whitespace-nowrap"
                                >
                                  <Radio className="w-3.5 h-3.5" />
                                  Pausar GPS
                                </button>
                              ) : (
                                <button
                                  type="button"
                                  onClick={() => onRequestBroadcast(tracker)}
                                  className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors cursor-pointer whitespace-nowrap"
                                >
                                  <Radio className="w-3.5 h-3.5" />
                                  Transmitir GPS
                                </button>
                              )}

                              <button
                                type="button"
                                onClick={() => {
                                  onStartPickTrackerLocation(tracker);
                                  onClose();
                                }}
                                className={`inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded-md transition-colors cursor-pointer whitespace-nowrap ${
                                  isPickingThis
                                    ? 'bg-slate-900 dark:bg-blue-600 text-white'
                                    : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700'
                                }`}
                              >
                                <Crosshair className="w-3.5 h-3.5" />
                                Marcar no mapa
                              </button>
                            </>
                          )}

                          <button
                            type="button"
                            onClick={() => {
                              onSelectTracker(tracker.id);
                              onSelectTab('history');
                            }}
                            className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-md transition-colors cursor-pointer whitespace-nowrap"
                          >
                            <History className="w-3.5 h-3.5" />
                            Histórico
                          </button>

                          <button
                            type="button"
                            onClick={() => {
                              onRouteToTracker(tracker);
                              onClose();
                            }}
                            className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-md transition-colors cursor-pointer whitespace-nowrap"
                          >
                            <Navigation className="w-3.5 h-3.5" />
                            Rota
                          </button>

                          <button
                            type="button"
                            onClick={() => onShareTracker(tracker)}
                            className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-md transition-colors cursor-pointer whitespace-nowrap"
                          >
                            <Share2 className="w-3.5 h-3.5" />
                            Enviar código
                          </button>

                          {isOwner ? (
                            <button
                              type="button"
                              onClick={() => onDeleteTracker(tracker)}
                              title="Excluir rastreador"
                              aria-label={`Excluir ${tracker.name}`}
                              className="ml-auto p-1.5 text-slate-400 dark:text-slate-500 hover:text-red-600 dark:hover:text-red-400 transition-colors cursor-pointer"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          ) : (
                            <button
                              type="button"
                              onClick={() => onLeaveSharedTracker(tracker)}
                              className="ml-auto px-2 py-1 text-xs text-slate-500 dark:text-slate-400 hover:text-red-600 dark:hover:text-red-400 transition-colors cursor-pointer whitespace-nowrap"
                            >
                              Sair
                            </button>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </>
          )}

          {resolvedTab === 'history' && (
            <div className="space-y-4">
              <div className="space-y-2">
                <div className="flex items-center justify-between gap-2">
                  <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                    Histórico de localização
                  </h3>
                  {selectedTracker && (
                    <span className="text-xs font-mono tabular-nums text-slate-500 dark:text-slate-400">
                      {selectedPoints.length} ponto(s)
                    </span>
                  )}
                </div>

                {trackers.length > 0 && (
                  <select
                    value={selectedTracker?.id ?? ''}
                    onChange={(e) => {
                      setConfirmClearHistory(false);
                      onSelectTracker(e.target.value);
                    }}
                    aria-label="Selecionar rastreador para ver histórico"
                    className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600 dark:focus:border-blue-500"
                  >
                    {trackers.map((t) => (
                      <option key={t.id} value={t.id}>
                        {t.name} ({CATEGORY_LABELS[t.category]})
                      </option>
                    ))}
                  </select>
                )}
              </div>

              {!selectedTracker ? (
                <div className="border border-dashed border-slate-200 dark:border-slate-700 rounded-xl p-6 text-center">
                  <History className="w-6 h-6 text-slate-400 dark:text-slate-500 mx-auto mb-2" />
                  <p className="text-sm font-medium text-slate-900 dark:text-slate-100 mb-1">
                    Nenhum rastreador disponível
                  </p>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">
                    Crie um rastreador ou acompanhe um código compartilhado para consultar o histórico de trajetos.
                  </p>
                  <button
                    type="button"
                    onClick={onOpenNewTrackerModal}
                    className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    Criar rastreador
                  </button>
                </div>
              ) : (
                <>
                  {/* Rich History Summary Stats + Export & Clear Actions */}
                  <div className="space-y-2.5 pb-3 border-b border-slate-200 dark:border-slate-800">
                    <div className="grid grid-cols-3 gap-2 text-xs">
                      <div className="rounded-lg bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/70 px-2.5 py-2">
                        <span className="block text-[10px] text-slate-500 dark:text-slate-400">
                          Percurso
                        </span>
                        <strong className="font-mono tabular-nums text-slate-900 dark:text-slate-100">
                          {formatDistance(historyStats.totalDistance)}
                        </strong>
                      </div>
                      <div className="rounded-lg bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/70 px-2.5 py-2">
                        <span className="block text-[10px] text-slate-500 dark:text-slate-400">
                          Vel. máx
                        </span>
                        <strong className="font-mono tabular-nums text-slate-900 dark:text-slate-100">
                          {formatSpeedKmh(historyStats.maxSpeedMs)}
                        </strong>
                      </div>
                      <div className="rounded-lg bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/70 px-2.5 py-2">
                        <span className="block text-[10px] text-slate-500 dark:text-slate-400">
                          Vel. média
                        </span>
                        <strong className="font-mono tabular-nums text-slate-900 dark:text-slate-100">
                          {formatSpeedKmh(historyStats.avgSpeedMs)}
                        </strong>
                      </div>
                    </div>

                    <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-600 dark:text-slate-300 tabular-nums">
                      <div className="flex flex-wrap items-center gap-2">
                        {historyStats.minAlt !== null &&
                          historyStats.maxAlt !== null && (
                            <span>
                              Alt: {Math.round(historyStats.minAlt)}–
                              {Math.round(historyStats.maxAlt)} m
                            </span>
                          )}
                        {historyStats.sosCount > 0 && (
                          <span className="px-1.5 py-0.5 rounded bg-red-100 dark:bg-red-950/70 text-red-700 dark:text-red-300 font-semibold">
                            {historyStats.sosCount} SOS
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-2 ml-auto">
                        {selectedPoints.length > 0 && (
                          <>
                            <button
                              type="button"
                              onClick={() => handleExportHistory('csv')}
                              className="inline-flex items-center gap-1 text-xs font-medium text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 cursor-pointer"
                            >
                              <Download className="w-3 h-3" />
                              CSV
                            </button>
                            <button
                              type="button"
                              onClick={() => handleExportHistory('json')}
                              className="inline-flex items-center gap-1 text-xs font-medium text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 cursor-pointer"
                            >
                              <Download className="w-3 h-3" />
                              JSON
                            </button>
                          </>
                        )}

                        {selectedTracker.ownerId === user.uid &&
                          selectedPoints.length > 0 && (
                            <div className="flex items-center gap-1.5">
                              {confirmClearHistory ? (
                                <>
                                  <button
                                    type="button"
                                    disabled={isClearingHistory}
                                    onClick={() =>
                                      void handleConfirmClearHistory()
                                    }
                                    className="px-2 py-1 text-xs font-medium bg-red-600 hover:bg-red-700 text-white rounded-md transition-colors cursor-pointer disabled:opacity-50"
                                  >
                                    {isClearingHistory
                                      ? 'Limpando...'
                                      : 'Confirmar'}
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() =>
                                      setConfirmClearHistory(false)
                                    }
                                    className="px-2 py-1 text-xs font-medium bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-md transition-colors cursor-pointer"
                                  >
                                    Cancelar
                                  </button>
                                </>
                              ) : (
                                <button
                                  type="button"
                                  onClick={() => setConfirmClearHistory(true)}
                                  className="inline-flex items-center gap-1 text-xs text-slate-500 dark:text-slate-400 hover:text-red-600 dark:hover:text-red-400 transition-colors cursor-pointer"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                  Limpar
                                </button>
                              )}
                            </div>
                          )}
                      </div>
                    </div>
                  </div>

                  {reversedPoints.length === 0 ? (
                    <div className="border border-dashed border-slate-200 dark:border-slate-700 rounded-xl p-6 text-center">
                      <Clock className="w-6 h-6 text-slate-400 dark:text-slate-500 mx-auto mb-2" />
                      <p className="text-sm font-medium text-slate-900 dark:text-slate-100 mb-1">
                        Sem registros no histórico
                      </p>
                      <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">
                        Os pontos são salvos automaticamente ao transmitir o GPS ou ao marcar uma nova posição no mapa.
                      </p>
                      {selectedTracker.ownerId === user.uid && (
                        <div className="flex flex-wrap items-center justify-center gap-2">
                          <button
                            type="button"
                            onClick={() => onRequestBroadcast(selectedTracker)}
                            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors cursor-pointer"
                          >
                            <Radio className="w-3.5 h-3.5" />
                            Transmitir GPS
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              onStartPickTrackerLocation(selectedTracker);
                              onClose();
                            }}
                            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-colors cursor-pointer"
                          >
                            <Crosshair className="w-3.5 h-3.5" />
                            Marcar no mapa
                          </button>
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="divide-y divide-slate-100 dark:divide-slate-800 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden bg-white dark:bg-slate-900">
                      {reversedPoints.map((pt, idx) => {
                        const isPointSelected = pt.id === selectedHistoryPointId;
                        const isSosPoint = Boolean(
                          pt.isSos || pt.source === 'sos'
                        );
                        return (
                          <div
                            key={pt.id}
                            onClick={() => {
                              onSelectHistoryPoint(pt.id);
                              onFocusCoords(pt.lat, pt.lng, 17);
                            }}
                            className={`p-3 transition-colors cursor-pointer ${
                              isPointSelected
                                ? 'bg-blue-50/70 dark:bg-blue-950/45'
                                : isSosPoint
                                  ? 'bg-red-50/60 dark:bg-red-950/25 hover:bg-red-50 dark:hover:bg-red-950/40'
                                  : 'hover:bg-slate-50 dark:hover:bg-slate-800/60'
                            }`}
                          >
                            <div className="flex items-start justify-between gap-2">
                              <div className="min-w-0 space-y-1">
                                <div className="flex flex-wrap items-center gap-1.5 text-xs font-medium text-slate-900 dark:text-slate-100 tabular-nums">
                                  <span
                                    className="w-2 h-2 rounded-full shrink-0"
                                    style={{
                                      backgroundColor: isSosPoint
                                        ? '#DC2626'
                                        : selectedTracker.color,
                                    }}
                                  />
                                  <span>{formatDateTimePt(pt.recordedAt)}</span>
                                  {isSosPoint && (
                                    <span className="px-1.5 py-0.5 rounded bg-red-600 text-white text-[10px] font-bold">
                                      SOS
                                    </span>
                                  )}
                                  {idx === 0 && (
                                    <span className="text-blue-600 dark:text-blue-400 font-semibold">
                                      · Mais recente
                                    </span>
                                  )}
                                </div>

                                {pt.address && (
                                  <p className="text-[11px] text-slate-700 dark:text-slate-200 leading-snug">
                                    📍 {pt.address}
                                  </p>
                                )}

                                <p className="text-[11px] font-mono tabular-nums text-slate-500 dark:text-slate-400">
                                  {formatCoordinates(pt.lat, pt.lng)} ·{' '}
                                  {formatSpeedKmh(pt.speed)} · ±
                                  {formatDistance(pt.accuracy)}
                                  {typeof pt.heading === 'number' &&
                                  pt.heading > 0
                                    ? ` · ${Math.round(pt.heading)}°`
                                    : ''}
                                  {typeof pt.altitude === 'number'
                                    ? ` · Alt ${Math.round(pt.altitude)}m`
                                    : ''}
                                </p>

                                {(typeof pt.weatherTempC === 'number' ||
                                  typeof pt.batteryLevel === 'number' ||
                                  typeof pt.distanceFromPrevMeters ===
                                    'number') && (
                                  <div className="flex flex-wrap items-center gap-x-2.5 gap-y-0.5 text-[11px] text-slate-600 dark:text-slate-300 tabular-nums">
                                    {typeof pt.weatherTempC === 'number' && (
                                      <span>
                                        🌤️ {Math.round(pt.weatherTempC)}°C
                                        {pt.weatherCondition
                                          ? ` ${pt.weatherCondition}`
                                          : ''}
                                        {typeof pt.weatherWindKmh === 'number'
                                          ? ` · ${Math.round(pt.weatherWindKmh)} km/h`
                                          : ''}
                                        {typeof pt.weatherHumidity === 'number'
                                          ? ` · ${Math.round(pt.weatherHumidity)}%`
                                          : ''}
                                      </span>
                                    )}
                                    {typeof pt.batteryLevel === 'number' && (
                                      <span>
                                        🔋 {Math.round(pt.batteryLevel)}%
                                        {pt.batteryCharging ? '⚡' : ''}
                                      </span>
                                    )}
                                    {typeof pt.distanceFromPrevMeters ===
                                      'number' &&
                                      pt.distanceFromPrevMeters > 0 && (
                                        <span>
                                          +{formatDistance(pt.distanceFromPrevMeters)}
                                        </span>
                                      )}
                                  </div>
                                )}
                              </div>

                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  onSelectHistoryPoint(pt.id);
                                  onFocusCoords(pt.lat, pt.lng, 17);
                                  onClose();
                                }}
                                className="text-xs font-medium text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 cursor-pointer whitespace-nowrap shrink-0"
                              >
                                Ver no mapa
                              </button>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </>
              )}
            </div>
          )}

          {resolvedTab === 'geofences' && (
            <div className="space-y-4">
              <form
                onSubmit={(e) => void handleCreateFenceSubmit(e)}
                className="border border-slate-200 dark:border-slate-800 rounded-xl p-3.5 space-y-3 bg-slate-50/50 dark:bg-slate-800/40"
              >
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                    Nova cerca virtual
                  </h3>
                  <button
                    type="button"
                    onClick={() => {
                      onStartPickGeofenceCenter();
                      onClose();
                    }}
                    className={`inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded-md transition-colors cursor-pointer whitespace-nowrap ${
                      pickMode.type === 'create-geofence'
                        ? 'bg-slate-900 dark:bg-blue-600 text-white'
                        : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800'
                    }`}
                  >
                    <Crosshair className="w-3.5 h-3.5" />
                    {pickMode.type === 'create-geofence'
                      ? 'Clique no mapa...'
                      : 'Escolher no mapa'}
                  </button>
                </div>

                <input
                  type="text"
                  maxLength={BLUEPRINT_LIMITS.NAME_MAX}
                  value={fenceName}
                  onChange={(e) => setFenceName(e.target.value)}
                  placeholder="Nome (ex.: Casa, Escritório, Depósito)"
                  className="w-full px-3 py-2 text-sm bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600 dark:focus:border-blue-500"
                />

                <div>
                  <div className="flex items-center justify-between text-xs text-slate-600 dark:text-slate-300 mb-1">
                    <span>Raio de cobertura</span>
                    <span className="font-mono tabular-nums font-medium text-slate-900 dark:text-slate-100">
                      {formatDistance(fenceRadius)}
                    </span>
                  </div>
                  <input
                    type="range"
                    min={100}
                    max={5000}
                    step={50}
                    value={fenceRadius}
                    onChange={(e) => setFenceRadius(Number(e.target.value))}
                    className="w-full accent-blue-600 cursor-pointer"
                  />
                </div>

                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-1.5">
                    {TRACKER_COLORS.slice(0, 5).map((c) => (
                      <button
                        key={c.value}
                        type="button"
                        aria-label={c.label}
                        onClick={() => setFenceColor(c.value)}
                        className={`w-5 h-5 rounded-full cursor-pointer ${
                          fenceColor === c.value
                            ? 'ring-2 ring-offset-1 ring-slate-900 dark:ring-slate-100 dark:ring-offset-slate-900'
                            : ''
                        }`}
                        style={{backgroundColor: c.value}}
                      />
                    ))}
                  </div>

                  <button
                    type="submit"
                    disabled={isCreatingFence || !fenceName.trim()}
                    className="px-3.5 py-1.5 text-xs font-medium bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 transition-colors cursor-pointer whitespace-nowrap"
                  >
                    {isCreatingFence ? 'Salvando...' : 'Criar cerca'}
                  </button>
                </div>

                {pickedGeofenceCenter && (
                  <p className="text-[11px] font-mono tabular-nums text-slate-500 dark:text-slate-400">
                    Centro selecionado:{' '}
                    {formatCoordinates(
                      pickedGeofenceCenter.lat,
                      pickedGeofenceCenter.lng
                    )}
                  </p>
                )}
              </form>

              {geofences.length === 0 ? (
                <div className="border border-dashed border-slate-200 dark:border-slate-700 rounded-xl p-6 text-center">
                  <Shield className="w-6 h-6 text-slate-400 dark:text-slate-500 mx-auto mb-2" />
                  <p className="text-sm font-medium text-slate-900 dark:text-slate-100 mb-1">
                    Nenhuma cerca virtual ativa
                  </p>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Defina zonas no mapa para receber alertas quando um rastreador entrar ou sair.
                  </p>
                </div>
              ) : (
                <div className="divide-y divide-slate-100 dark:divide-slate-800 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden bg-white dark:bg-slate-900">
                  {geofences.map((fence) => (
                    <div
                      key={fence.id}
                      className="p-3.5 bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800/60 transition-colors"
                    >
                      <div className="flex items-start justify-between gap-2">
                        <button
                          type="button"
                          onClick={() => {
                            onFocusCoords(fence.lat, fence.lng, 15);
                            onClose();
                          }}
                          className="text-left min-w-0 cursor-pointer"
                        >
                          <div className="flex items-center gap-2">
                            <span
                              className="w-2.5 h-2.5 rounded-full shrink-0"
                              style={{backgroundColor: fence.color}}
                            />
                            <h4 className="text-sm font-semibold text-slate-900 dark:text-slate-100 truncate">
                              {fence.name}
                            </h4>
                          </div>
                          <p className="text-xs text-slate-500 dark:text-slate-400 font-mono tabular-nums mt-0.5">
                            Raio {formatDistance(fence.radiusMeters)} ·{' '}
                            {formatCoordinates(fence.lat, fence.lng)}
                          </p>
                        </button>

                        <div className="flex items-center gap-1.5 shrink-0">
                          <button
                            type="button"
                            onClick={() => onToggleGeofence(fence)}
                            className={`px-2 py-1 text-xs font-medium rounded-md transition-colors cursor-pointer ${
                              fence.active
                                ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 hover:bg-emerald-100 dark:hover:bg-emerald-900/60'
                                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                            }`}
                          >
                            {fence.active ? 'Ativa' : 'Pausada'}
                          </button>
                          <button
                            type="button"
                            onClick={() => onDeleteGeofence(fence)}
                            aria-label={`Excluir cerca ${fence.name}`}
                            className="p-1 text-slate-400 dark:text-slate-500 hover:text-red-600 dark:hover:text-red-400 transition-colors cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {resolvedTab === 'alerts' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                  Alertas de perímetro
                </h3>
                <span className="text-xs text-slate-500 dark:text-slate-400 tabular-nums">
                  {unacknowledgedCount} não lido(s)
                </span>
              </div>

              {alerts.length === 0 ? (
                <div className="border border-dashed border-slate-200 dark:border-slate-700 rounded-xl p-6 text-center">
                  <Bell className="w-6 h-6 text-slate-400 dark:text-slate-500 mx-auto mb-2" />
                  <p className="text-sm font-medium text-slate-900 dark:text-slate-100 mb-1">
                    Nenhum alerta registrado
                  </p>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Quando seus rastreadores entrarem ou saírem de uma cerca virtual ativa, os eventos aparecerão aqui.
                  </p>
                </div>
              ) : (
                <div className="divide-y divide-slate-100 dark:divide-slate-800 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
                  {alerts.map((alert) => (
                    <div
                      key={alert.id}
                      className={`p-3.5 transition-colors ${
                        alert.acknowledged
                          ? 'bg-white dark:bg-slate-900'
                          : 'bg-amber-50/60 dark:bg-amber-950/35'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="min-w-0">
                          <p className="text-sm font-medium text-slate-900 dark:text-slate-100">
                            {alert.trackerName}{' '}
                            <span
                              className={
                                alert.eventType === 'enter'
                                  ? 'text-emerald-700 dark:text-emerald-400'
                                  : 'text-amber-700 dark:text-amber-400'
                              }
                            >
                              {alert.eventType === 'enter'
                                ? 'entrou em'
                                : 'saiu de'}
                            </span>{' '}
                            {alert.geofenceName}
                          </p>
                          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 tabular-nums">
                            {formatRelativeTimePt(alert.createdAt)} · Distância{' '}
                            {formatDistance(alert.distanceMeters)}
                          </p>
                        </div>

                        <div className="flex items-center gap-1 shrink-0">
                          {!alert.acknowledged && (
                            <button
                              type="button"
                              onClick={() => onAcknowledgeAlert(alert)}
                              title="Marcar como lido"
                              aria-label="Marcar alerta como lido"
                              className="p-1.5 text-emerald-700 dark:text-emerald-400 hover:bg-emerald-100 dark:hover:bg-emerald-950/60 rounded-md transition-colors cursor-pointer"
                            >
                              <Check className="w-3.5 h-3.5" />
                            </button>
                          )}
                          <button
                            type="button"
                            onClick={() => onDeleteAlert(alert)}
                            title="Remover alerta"
                            aria-label="Remover alerta"
                            className="p-1.5 text-slate-400 dark:text-slate-500 hover:text-red-600 dark:hover:text-red-400 rounded-md transition-colors cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Bottom theme & account bar */}
        <div className="border-t border-slate-200 dark:border-slate-800 px-4 py-3 bg-slate-50 dark:bg-slate-900/95 space-y-2.5 shrink-0">
          <ThemeSwitcher theme={theme} onChangeTheme={onChangeTheme} />
          <div className="pt-2.5 border-t border-slate-200/80 dark:border-slate-800 flex items-center justify-between gap-3">
            <div className="min-w-0">
              <p className="text-xs font-medium text-slate-900 dark:text-slate-100 truncate">
                {user.displayName || 'Usuário conectado'}
              </p>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                {user.email}
              </p>
            </div>
            <button
              type="button"
              onClick={onSignOut}
              className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-200/70 dark:hover:bg-slate-800 rounded-md transition-colors cursor-pointer whitespace-nowrap shrink-0"
            >
              <LogOut className="w-3.5 h-3.5" />
              Sair
            </button>
          </div>
        </div>
      </aside>
    </div>
  );
};
