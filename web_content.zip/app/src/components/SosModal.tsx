import React, {useCallback, useEffect, useMemo, useRef, useState} from 'react';
import type {User} from 'firebase/auth';
import {
  BatteryLow,
  Camera,
  CameraOff,
  Check,
  Copy,
  Download,
  MapPin,
  Mic,
  MicOff,
  Radio,
  RefreshCw,
  Share2,
  ShieldCheck,
  Siren,
  SwitchCamera,
  Video,
  Volume2,
  X,
} from 'lucide-react';
import {useSosWebRtc} from '../hooks/useSosWebRtc';
import {canShare, shareContent} from '../share';
import {
  BLUEPRINT_LIMITS,
  type DeviceBatteryState,
  type SosEvent,
  type UserPositionState,
  type WeatherData,
  formatCoordinates,
  formatDistance,
  formatRelativeTimePt,
  formatSpeedKmh,
} from '../types/tracking';
import {WeatherStrip, formatWeatherSummary} from './WeatherStrip';

interface SosModalProps {
  user: User | null;
  activeSos: SosEvent | null;
  userPosition: UserPositionState | null;
  deviceBattery: DeviceBatteryState | null;
  currentAddress: string | null;
  currentWeather: WeatherData | null;
  onActivateSos: (options: {
    message: string;
    cameraEnabled: boolean;
    micEnabled: boolean;
  }) => Promise<void>;
  onUpdateSosMedia: (
    sos: SosEvent,
    patch: {cameraEnabled?: boolean; micEnabled?: boolean; message?: string}
  ) => Promise<void>;
  onResolveSos: (sos: SosEvent) => Promise<void>;
  onFocusLocation: (lat: number, lng: number, zoom?: number) => void;
  onClose: () => void;
}

const DEFAULT_SOS_MESSAGE =
  'PRECISO DE AJUDA! Minha localização ao vivo, câmera e áudio SOS foram ativados no PontoVivo.';

export const SosModal: React.FC<SosModalProps> = ({
  user,
  activeSos,
  userPosition,
  deviceBattery,
  currentAddress,
  currentWeather,
  onActivateSos,
  onUpdateSosMedia,
  onResolveSos,
  onFocusLocation,
  onClose,
}) => {
  const isOwner = Boolean(activeSos && user && activeSos.ownerId === user.uid);
  const isViewer = Boolean(activeSos && user && activeSos.ownerId !== user.uid);

  // Pre-activation countdown state
  const [countdown, setCountdown] = useState<number | null>(3);
  const [wantCamera, setWantCamera] = useState(true);
  const [wantMic, setWantMic] = useState(true);
  const [sosMessage, setSosMessage] = useState(DEFAULT_SOS_MESSAGE);
  const [isActivating, setIsActivating] = useState(false);

  // Live broadcaster media state
  const [localStream, setLocalStream] = useState<MediaStream | null>(null);
  const [facingMode, setFacingMode] = useState<'environment' | 'user'>(
    'environment'
  );
  const [cameraActive, setCameraActive] = useState(false);
  const [micActive, setMicActive] = useState(false);
  const [mediaStatus, setMediaStatus] = useState<string | null>(null);
  const [micLevel, setMicLevel] = useState(0);
  const [isRecording, setIsRecording] = useState(false);
  const [recordedUrl, setRecordedUrl] = useState<string | null>(null);

  // Resolve confirmation & sharing state
  const [confirmResolve, setConfirmResolve] = useState(false);
  const [isResolving, setIsResolving] = useState(false);
  const [copiedShare, setCopiedShare] = useState(false);

  const localVideoRef = useRef<HTMLVideoElement | null>(null);
  const remoteVideoRef = useRef<HTMLVideoElement | null>(null);
  const remoteAudioRef = useRef<HTMLAudioElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recordedChunksRef = useRef<Blob[]>([]);

  const {
    remoteStream,
    connectedPeersCount,
    connectionState,
    returnMicActive,
    toggleReturnMic,
    reconnectViewer,
  } = useSosWebRtc({
    role: isOwner ? 'broadcaster' : 'viewer',
    sosEvent: activeSos,
    user,
    localStream: isOwner ? localStream : null,
  });

  const handleTriggerSos = useCallback(async () => {
    if (isActivating) return;
    setCountdown(null);
    setIsActivating(true);
    try {
      await onActivateSos({
        message:
          sosMessage.trim().slice(0, BLUEPRINT_LIMITS.SOS_MESSAGE_MAX) ||
          DEFAULT_SOS_MESSAGE,
        cameraEnabled: wantCamera,
        micEnabled: wantMic,
      });
    } finally {
      setIsActivating(false);
    }
  }, [isActivating, onActivateSos, sosMessage, wantCamera, wantMic]);

  // 3-second cancelable auto-countdown when opened without an active SOS
  useEffect(() => {
    if (activeSos || countdown === null) return;
    if (countdown <= 0) {
      void handleTriggerSos();
      return;
    }
    const timer = window.setTimeout(() => {
      setCountdown((c) => (c !== null ? c - 1 : null));
    }, 1000);
    return () => window.clearTimeout(timer);
  }, [activeSos, countdown, handleTriggerSos]);

  const stopMediaStream = useCallback(() => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
    setLocalStream(null);
    setCameraActive(false);
    setMicActive(false);
    setMicLevel(0);
  }, []);

  // Acquire camera + microphone automatically when user is the active SOS broadcaster
  const acquireSosMedia = useCallback(
    async (
      reqCamera: boolean,
      reqMic: boolean,
      cameraFacing: 'environment' | 'user'
    ) => {
      if (!reqCamera && !reqMic) {
        stopMediaStream();
        setMediaStatus('Câmera e microfone pausados manualmente.');
        return;
      }
      if (!navigator.mediaDevices?.getUserMedia) {
        setMediaStatus(
          'Este navegador não permite acesso à câmera/microfone neste contexto.'
        );
        return;
      }

      if (streamRef.current) {
        streamRef.current.getTracks().forEach((t) => t.stop());
        streamRef.current = null;
      }

      const attempts: MediaStreamConstraints[] = [];
      if (reqCamera && reqMic) {
        attempts.push(
          {video: {facingMode: {ideal: cameraFacing}}, audio: true},
          {video: true, audio: true},
          {video: false, audio: true},
          {video: true, audio: false}
        );
      } else if (reqCamera) {
        attempts.push(
          {video: {facingMode: {ideal: cameraFacing}}, audio: false},
          {video: true, audio: false}
        );
      } else {
        attempts.push({video: false, audio: true});
      }

      let acquired: MediaStream | null = null;
      for (const constraints of attempts) {
        try {
          acquired = await navigator.mediaDevices.getUserMedia(constraints);
          break;
        } catch {
          // Try next fallback constraint
        }
      }

      if (!acquired) {
        setMediaStatus(
          'Permissão de câmera/microfone negada ou dispositivo sem hardware disponível.'
        );
        setCameraActive(false);
        setMicActive(false);
        return;
      }

      streamRef.current = acquired;
      setLocalStream(acquired);
      const hasVideo = acquired.getVideoTracks().length > 0;
      const hasAudio = acquired.getAudioTracks().length > 0;
      setCameraActive(hasVideo);
      setMicActive(hasAudio);

      if (reqCamera && !hasVideo && hasAudio) {
        setMediaStatus(
          'Câmera indisponível neste dispositivo — microfone SOS ativo.'
        );
      } else if (reqMic && !hasAudio && hasVideo) {
        setMediaStatus(
          'Microfone indisponível neste dispositivo — câmera SOS ativa.'
        );
      } else {
        setMediaStatus(null);
      }
    },
    [stopMediaStream]
  );

  useEffect(() => {
    if (!isOwner || !activeSos) {
      stopMediaStream();
      return;
    }
    void acquireSosMedia(
      activeSos.cameraEnabled,
      activeSos.micEnabled,
      facingMode
    );
    return () => {
      stopMediaStream();
    };
  }, [isOwner, activeSos?.id, facingMode]);

  // Attach local video preview
  useEffect(() => {
    if (localVideoRef.current) {
      localVideoRef.current.srcObject = localStream;
    }
  }, [localStream]);

  // Attach remote stream for viewer video or broadcaster incoming audio
  useEffect(() => {
    if (isViewer && remoteVideoRef.current) {
      remoteVideoRef.current.srcObject = remoteStream;
    }
    if (isOwner && remoteAudioRef.current) {
      remoteAudioRef.current.srcObject = remoteStream;
    }
  }, [isViewer, isOwner, remoteStream]);

  // Real-time microphone VU meter via AudioContext AnalyserNode
  useEffect(() => {
    if (!localStream || !micActive) {
      setMicLevel(0);
      return;
    }
    const audioTracks = localStream.getAudioTracks();
    if (audioTracks.length === 0) return;

    const AudioCtx =
      window.AudioContext ||
      (window as unknown as {webkitAudioContext?: typeof AudioContext})
        .webkitAudioContext;
    if (!AudioCtx) return;

    let rafId = 0;
    const ctx = new AudioCtx();
    const source = ctx.createMediaStreamSource(localStream);
    const analyser = ctx.createAnalyser();
    analyser.fftSize = 128;
    source.connect(analyser);
    const data = new Uint8Array(analyser.frequencyBinCount);

    const tick = () => {
      analyser.getByteFrequencyData(data);
      let sum = 0;
      for (let i = 0; i < data.length; i++) sum += data[i];
      const avg = sum / data.length;
      setMicLevel(Math.min(100, Math.round((avg / 128) * 100)));
      rafId = window.requestAnimationFrame(tick);
    };
    rafId = window.requestAnimationFrame(tick);

    return () => {
      window.cancelAnimationFrame(rafId);
      source.disconnect();
      void ctx.close().catch(() => {});
    };
  }, [localStream, micActive]);

  // Cleanup recorded blob URL on unmount
  useEffect(() => {
    return () => {
      if (recordedUrl) URL.revokeObjectURL(recordedUrl);
    };
  }, [recordedUrl]);

  const handleToggleCameraTrack = async () => {
    if (!activeSos || !isOwner) return;
    const next = !cameraActive;
    if (!localStream && next) {
      await acquireSosMedia(true, micActive, facingMode);
    } else if (localStream) {
      const videoTracks = localStream.getVideoTracks();
      if (videoTracks.length > 0) {
        videoTracks.forEach((t) => {
          t.enabled = next;
        });
        setCameraActive(next);
      } else if (next) {
        await acquireSosMedia(true, micActive, facingMode);
      }
    }
    await onUpdateSosMedia(activeSos, {cameraEnabled: next});
  };

  const handleToggleMicTrack = async () => {
    if (!activeSos || !isOwner) return;
    const next = !micActive;
    if (!localStream && next) {
      await acquireSosMedia(cameraActive, true, facingMode);
    } else if (localStream) {
      const audioTracks = localStream.getAudioTracks();
      if (audioTracks.length > 0) {
        audioTracks.forEach((t) => {
          t.enabled = next;
        });
        setMicActive(next);
      } else if (next) {
        await acquireSosMedia(cameraActive, true, facingMode);
      }
    }
    await onUpdateSosMedia(activeSos, {micEnabled: next});
  };

  const handleToggleRecording = () => {
    if (!localStream || typeof MediaRecorder === 'undefined') return;
    if (isRecording && mediaRecorderRef.current) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      return;
    }

    if (recordedUrl) {
      URL.revokeObjectURL(recordedUrl);
      setRecordedUrl(null);
    }
    recordedChunksRef.current = [];
    try {
      const mimeType = MediaRecorder.isTypeSupported('video/webm;codecs=vp8,opus')
        ? 'video/webm;codecs=vp8,opus'
        : MediaRecorder.isTypeSupported('video/webm')
          ? 'video/webm'
          : '';
      const recorder = mimeType
        ? new MediaRecorder(localStream, {mimeType})
        : new MediaRecorder(localStream);
      recorder.ondataavailable = (ev) => {
        if (ev.data.size > 0) recordedChunksRef.current.push(ev.data);
      };
      recorder.onstop = () => {
        if (recordedChunksRef.current.length > 0) {
          const blob = new Blob(recordedChunksRef.current, {
            type: recorder.mimeType || 'video/webm',
          });
          setRecordedUrl(URL.createObjectURL(blob));
        }
        setIsRecording(false);
      };
      recorder.start(1000);
      mediaRecorderRef.current = recorder;
      setIsRecording(true);
    } catch {
      setMediaStatus('Não foi possível iniciar a gravação local neste navegador.');
    }
  };

  const shareText = useMemo(() => {
    const lat = activeSos?.lat ?? userPosition?.lat;
    const lng = activeSos?.lng ?? userPosition?.lng;
    const mapsLink =
      typeof lat === 'number' && typeof lng === 'number'
        ? `https://maps.google.com/?q=${lat.toFixed(6)},${lng.toFixed(6)}`
        : '';
    const addr = activeSos?.address ?? currentAddress;
    const weatherText =
      activeSos?.weatherSummary ?? formatWeatherSummary(currentWeather);
    const batt =
      typeof activeSos?.batteryLevel === 'number'
        ? `${Math.round(activeSos.batteryLevel)}%`
        : deviceBattery
          ? `${deviceBattery.level}%`
          : null;

    return [
      `🚨 ALERTA SOS — PontoVivo`,
      activeSos?.message || sosMessage || DEFAULT_SOS_MESSAGE,
      typeof lat === 'number' && typeof lng === 'number'
        ? `📍 Coordenadas: ${lat.toFixed(6)}, ${lng.toFixed(6)}`
        : null,
      addr ? `🏠 Local: ${addr}` : null,
      weatherText ? `🌤️ Clima: ${weatherText}` : null,
      batt ? `🔋 Bateria: ${batt}` : null,
      mapsLink ? `🗺️ Abrir no mapa: ${mapsLink}` : null,
    ]
      .filter(Boolean)
      .join('\n');
  }, [activeSos, userPosition, currentAddress, currentWeather, deviceBattery, sosMessage]);

  const handleCopySos = () => {
    void navigator.clipboard?.writeText(shareText);
    setCopiedShare(true);
    window.setTimeout(() => setCopiedShare(false), 1800);
  };

  const handleNativeShare = async () => {
    if (canShare) {
      try {
        await shareContent({
          title: '🚨 ALERTA SOS — PontoVivo',
          text: shareText,
        });
        return;
      } catch {
        // Fallback to copy
      }
    }
    handleCopySos();
  };

  const handleResolveConfirm = async () => {
    if (!activeSos) return;
    setIsResolving(true);
    try {
      stopMediaStream();
      await onResolveSos(activeSos);
      setConfirmResolve(false);
    } finally {
      setIsResolving(false);
    }
  };

  const targetLat = activeSos?.lat ?? userPosition?.lat ?? null;
  const targetLng = activeSos?.lng ?? userPosition?.lng ?? null;

  return (
    <div
      className="fixed inset-0 z-50 bg-slate-950/65 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto"
      role="dialog"
      aria-modal="true"
      aria-label="Central de Emergência SOS"
    >
      <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-red-200 dark:border-red-900/70 max-w-lg w-full overflow-hidden my-auto">
        {/* Header */}
        <div className="px-5 py-3.5 bg-red-600 dark:bg-red-700 text-white flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-8 h-8 rounded-lg bg-white/15 flex items-center justify-center shrink-0">
              <Siren className="w-4.5 h-4.5 animate-pulse" />
            </div>
            <div className="min-w-0">
              <h2 className="text-sm sm:text-base font-bold leading-tight truncate">
                {!activeSos
                  ? 'Emergência SOS'
                  : isOwner
                    ? 'SOS ATIVO — Transmitindo ao vivo'
                    : `SOS DE ${activeSos.ownerName.toUpperCase()}`}
              </h2>
              <p className="text-[11px] text-red-100 truncate">
                {!activeSos
                  ? 'Localização ao vivo + Câmera + Microfone de socorro'
                  : isOwner
                    ? `Conectado a ${activeSos.viewerIds.length} contato(s) · ${connectedPeersCount} assistindo`
                    : `Atualizado ${formatRelativeTimePt(activeSos.updatedAt)}`}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="Fechar janela SOS"
            className="p-1.5 rounded-lg text-white/85 hover:text-white hover:bg-white/15 transition-colors cursor-pointer shrink-0"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="p-4 sm:p-5 space-y-4 max-h-[82vh] overflow-y-auto">
          {!activeSos ? (
            /* Pre-Activation Countdown & Options */
            <>
              {countdown !== null && (
                <div className="rounded-xl bg-red-50 dark:bg-red-950/60 border border-red-200 dark:border-red-900 p-4 text-center space-y-2">
                  <p className="text-xs font-semibold uppercase tracking-wide text-red-700 dark:text-red-300">
                    Disparo automático em
                  </p>
                  <div className="text-4xl font-extrabold font-mono tabular-nums text-red-600 dark:text-red-400">
                    {countdown}s
                  </div>
                  <p className="text-xs text-red-800 dark:text-red-200">
                    Enviará sua posição exata, endereço, clima, bateria e ligará câmera + microfone SOS.
                  </p>
                  <button
                    type="button"
                    onClick={() => setCountdown(null)}
                    className="mt-1 inline-flex items-center px-3 py-1.5 text-xs font-medium bg-white dark:bg-slate-900 border border-red-300 dark:border-red-800 text-red-700 dark:text-red-300 rounded-lg hover:bg-red-100 dark:hover:bg-red-900/50 transition-colors cursor-pointer"
                  >
                    Pausar contagem e editar
                  </button>
                </div>
              )}

              <div>
                <label
                  htmlFor="sos-msg-input"
                  className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1"
                >
                  Mensagem de socorro
                </label>
                <textarea
                  id="sos-msg-input"
                  rows={2}
                  maxLength={BLUEPRINT_LIMITS.SOS_MESSAGE_MAX}
                  value={sosMessage}
                  onChange={(e) => setSosMessage(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500/25 focus:border-red-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                <button
                  type="button"
                  onClick={() => setWantCamera((v) => !v)}
                  className={`flex items-center justify-center gap-2 px-3 py-2.5 rounded-xl border text-xs font-medium transition-colors cursor-pointer ${
                    wantCamera
                      ? 'bg-red-50 dark:bg-red-950/50 border-red-300 dark:border-red-800 text-red-800 dark:text-red-200'
                      : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'
                  }`}
                >
                  {wantCamera ? (
                    <Camera className="w-4 h-4" />
                  ) : (
                    <CameraOff className="w-4 h-4" />
                  )}
                  Câmera SOS: {wantCamera ? 'Ligada' : 'Desligada'}
                </button>

                <button
                  type="button"
                  onClick={() => setWantMic((v) => !v)}
                  className={`flex items-center justify-center gap-2 px-3 py-2.5 rounded-xl border text-xs font-medium transition-colors cursor-pointer ${
                    wantMic
                      ? 'bg-red-50 dark:bg-red-950/50 border-red-300 dark:border-red-800 text-red-800 dark:text-red-200'
                      : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'
                  }`}
                >
                  {wantMic ? (
                    <Mic className="w-4 h-4" />
                  ) : (
                    <MicOff className="w-4 h-4" />
                  )}
                  Microfone: {wantMic ? 'Ligado' : 'Desligado'}
                </button>
              </div>

              {userPosition && (
                <div className="rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 p-3 text-xs space-y-1.5">
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-medium text-slate-800 dark:text-slate-200 inline-flex items-center gap-1.5">
                      <MapPin className="w-3.5 h-3.5 text-red-600 dark:text-red-400" />
                      Posição que será enviada
                    </span>
                    <span className="font-mono tabular-nums text-slate-600 dark:text-slate-300">
                      {formatCoordinates(userPosition.lat, userPosition.lng)}
                    </span>
                  </div>
                  {currentAddress && (
                    <p className="text-slate-600 dark:text-slate-300 truncate">
                      {currentAddress}
                    </p>
                  )}
                  {currentWeather && (
                    <WeatherStrip weather={currentWeather} compact />
                  )}
                </div>
              )}

              <div className="flex items-center gap-2.5 pt-1">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2.5 text-xs font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-xl transition-colors cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="button"
                  disabled={isActivating}
                  onClick={() => void handleTriggerSos()}
                  className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-bold text-white bg-red-600 hover:bg-red-700 disabled:opacity-60 rounded-xl shadow-md transition-colors cursor-pointer"
                >
                  <Siren className="w-4 h-4" />
                  {isActivating ? 'Ativando SOS...' : 'ENVIAR SOS AGORA'}
                </button>
              </div>
            </>
          ) : (
            /* Active SOS Console (Broadcaster OR Viewer) */
            <>
              {/* Live Video Feed */}
              <div className="relative rounded-xl overflow-hidden bg-slate-950 aspect-video border border-slate-800 flex items-center justify-center">
                {isOwner ? (
                  cameraActive && localStream ? (
                    <video
                      ref={localVideoRef}
                      autoPlay
                      playsInline
                      muted
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="text-center p-4 text-slate-300 space-y-2">
                      <CameraOff className="w-8 h-8 mx-auto text-slate-500" />
                      <p className="text-xs">
                        {mediaStatus ||
                          'Câmera desligada ou aguardando permissão.'}
                      </p>
                    </div>
                  )
                ) : remoteStream && remoteStream.getVideoTracks().length > 0 ? (
                  <video
                    ref={remoteVideoRef}
                    autoPlay
                    playsInline
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="text-center p-4 text-slate-300 space-y-2">
                    <Video className="w-8 h-8 mx-auto text-red-400 animate-pulse" />
                    <p className="text-xs font-medium">
                      {connectionState === 'connected'
                        ? 'Conectado ao áudio/câmera SOS'
                        : 'Conectando à câmera e microfone SOS ao vivo...'}
                    </p>
                    <button
                      type="button"
                      onClick={reconnectViewer}
                      className="inline-flex items-center gap-1 px-2.5 py-1 text-xs bg-white/15 hover:bg-white/25 rounded-md cursor-pointer"
                    >
                      <RefreshCw className="w-3 h-3" />
                      Reconectar sinal
                    </button>
                  </div>
                )}

                {/* Hidden audio element for broadcaster to hear viewer talking back */}
                {isOwner && (
                  <audio ref={remoteAudioRef} autoPlay className="hidden" />
                )}

                {/* Top live badge overlay */}
                <div className="absolute top-2.5 left-2.5 right-2.5 flex items-center justify-between gap-2 pointer-events-none">
                  <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-red-600/90 text-white text-[11px] font-bold shadow">
                    <Radio className="w-3 h-3 animate-pulse" />
                    SOS AO VIVO
                  </span>

                  {isOwner && micActive && (
                    <div className="inline-flex items-center gap-1.5 px-2 py-1 rounded-md bg-slate-900/85 text-white text-[11px] font-mono tabular-nums">
                      <Mic className="w-3 h-3 text-emerald-400" />
                      <div className="w-12 h-1.5 bg-slate-700 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-emerald-400 transition-all duration-75"
                          style={{width: `${Math.max(8, micLevel)}%`}}
                        />
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {mediaStatus && isOwner && (
                <p className="text-xs text-amber-800 dark:text-amber-200 bg-amber-50 dark:bg-amber-950/60 border border-amber-200 dark:border-amber-900 rounded-lg px-3 py-2">
                  {mediaStatus}
                </p>
              )}

              {/* Camera & Microphone Interactive Controls */}
              {isOwner ? (
                <div className="flex flex-wrap items-center gap-2">
                  <button
                    type="button"
                    onClick={() => void handleToggleCameraTrack()}
                    className={`inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg border transition-colors cursor-pointer ${
                      cameraActive
                        ? 'bg-emerald-600 text-white border-emerald-600'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-700'
                    }`}
                  >
                    {cameraActive ? (
                      <Camera className="w-3.5 h-3.5" />
                    ) : (
                      <CameraOff className="w-3.5 h-3.5" />
                    )}
                    {cameraActive ? 'Câmera ativa' : 'Ligar câmera'}
                  </button>

                  <button
                    type="button"
                    onClick={() => void handleToggleMicTrack()}
                    className={`inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg border transition-colors cursor-pointer ${
                      micActive
                        ? 'bg-emerald-600 text-white border-emerald-600'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-700'
                    }`}
                  >
                    {micActive ? (
                      <Mic className="w-3.5 h-3.5" />
                    ) : (
                      <MicOff className="w-3.5 h-3.5" />
                    )}
                    {micActive ? 'Microfone ativo' : 'Ligar microfone'}
                  </button>

                  {cameraActive && (
                    <button
                      type="button"
                      onClick={() =>
                        setFacingMode((m) =>
                          m === 'environment' ? 'user' : 'environment'
                        )
                      }
                      className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors cursor-pointer"
                    >
                      <SwitchCamera className="w-3.5 h-3.5" />
                      Trocar câmera
                    </button>
                  )}

                  {localStream && (
                    <button
                      type="button"
                      onClick={handleToggleRecording}
                      className={`inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg border transition-colors cursor-pointer ${
                        isRecording
                          ? 'bg-red-600 text-white border-red-600 animate-pulse'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-700'
                      }`}
                    >
                      <Video className="w-3.5 h-3.5" />
                      {isRecording ? 'Parar gravação' : 'Gravar vídeo SOS'}
                    </button>
                  )}

                  {recordedUrl && (
                    <a
                      href={recordedUrl}
                      download={`pontovivo-sos-${Date.now()}.webm`}
                      className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg bg-blue-600 text-white hover:bg-blue-700 transition-colors"
                    >
                      <Download className="w-3.5 h-3.5" />
                      Baixar vídeo gravado
                    </a>
                  )}
                </div>
              ) : (
                <div className="flex flex-wrap items-center gap-2">
                  <button
                    type="button"
                    onClick={() => void toggleReturnMic()}
                    className={`flex-1 inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-lg border transition-colors cursor-pointer ${
                      returnMicActive
                        ? 'bg-emerald-600 text-white border-emerald-600'
                        : 'bg-blue-600 text-white border-blue-600 hover:bg-blue-700'
                    }`}
                  >
                    {returnMicActive ? (
                      <>
                        <Volume2 className="w-4 h-4 animate-pulse" />
                        Falando com {activeSos.ownerName} (clique p/ silenciar)
                      </>
                    ) : (
                      <>
                        <Mic className="w-4 h-4" />
                        Falar com quem pediu SOS
                      </>
                    )}
                  </button>

                  {targetLat !== null && targetLng !== null && (
                    <button
                      type="button"
                      onClick={() => {
                        onFocusLocation(targetLat, targetLng, 17);
                        onClose();
                      }}
                      className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg cursor-pointer"
                    >
                      <MapPin className="w-3.5 h-3.5" />
                      Ver no mapa
                    </button>
                  )}
                </div>
              )}

              {/* Live SOS Telemetry Snapshot */}
              <div className="rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 p-3 text-xs space-y-1.5">
                <p className="text-slate-800 dark:text-slate-100 font-medium">
                  {activeSos.message}
                </p>
                <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-slate-600 dark:text-slate-300 font-mono tabular-nums">
                  <span>
                    {formatCoordinates(activeSos.lat, activeSos.lng)}
                  </span>
                  <span>±{formatDistance(activeSos.accuracy)}</span>
                  {typeof activeSos.speed === 'number' && (
                    <span>{formatSpeedKmh(activeSos.speed)}</span>
                  )}
                  {typeof activeSos.altitude === 'number' && (
                    <span>Alt {Math.round(activeSos.altitude)} m</span>
                  )}
                  {typeof activeSos.batteryLevel === 'number' && (
                    <span className="inline-flex items-center gap-1">
                      <BatteryLow className="w-3.5 h-3.5 text-red-500" />
                      {Math.round(activeSos.batteryLevel)}%
                    </span>
                  )}
                </div>
                {activeSos.address && (
                  <p className="text-slate-600 dark:text-slate-300">
                    📍 {activeSos.address}
                  </p>
                )}
                {activeSos.weatherSummary && (
                  <p className="text-slate-600 dark:text-slate-300">
                    🌤️ {activeSos.weatherSummary}
                  </p>
                )}
              </div>

              {/* Quick Share Actions */}
              <div className="space-y-2">
                <p className="text-[11px] font-semibold uppercase tracking-wide text-slate-500 dark:text-slate-400">
                  Enviar pedido de socorro aos amigos
                </p>
                <div className="flex flex-wrap items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => void handleNativeShare()}
                    className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors cursor-pointer"
                  >
                    <Share2 className="w-3.5 h-3.5" />
                    Compartilhar
                  </button>
                  <a
                    href={`https://wa.me/?text=${encodeURIComponent(shareText)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition-colors"
                  >
                    WhatsApp
                  </a>
                  <a
                    href={`sms:?body=${encodeURIComponent(shareText)}`}
                    className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
                  >
                    SMS
                  </a>
                  <button
                    type="button"
                    onClick={handleCopySos}
                    className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors cursor-pointer"
                  >
                    {copiedShare ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-600" />
                        Copiado
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        Copiar alerta
                      </>
                    )}
                  </button>
                </div>
              </div>

              {/* Owner Resolve SOS */}
              {isOwner && (
                <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between gap-2">
                  {confirmResolve ? (
                    <>
                      <span className="text-xs text-slate-600 dark:text-slate-300">
                        Confirmar que você está seguro e encerrar SOS?
                      </span>
                      <div className="flex items-center gap-1.5 shrink-0">
                        <button
                          type="button"
                          onClick={() => setConfirmResolve(false)}
                          className="px-3 py-1.5 text-xs font-medium bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 rounded-lg cursor-pointer"
                        >
                          Voltar
                        </button>
                        <button
                          type="button"
                          disabled={isResolving}
                          onClick={() => void handleResolveConfirm()}
                          className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-semibold bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 cursor-pointer disabled:opacity-60"
                        >
                          <ShieldCheck className="w-3.5 h-3.5" />
                          {isResolving ? 'Encerrando...' : 'Confirmar encerramento'}
                        </button>
                      </div>
                    </>
                  ) : (
                    <>
                      <button
                        type="button"
                        onClick={onClose}
                        className="px-3 py-2 text-xs font-medium text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white cursor-pointer"
                      >
                        Minimizar para o mapa
                      </button>
                      <button
                        type="button"
                        onClick={() => setConfirmResolve(true)}
                        className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg transition-colors cursor-pointer"
                      >
                        <ShieldCheck className="w-4 h-4" />
                        Estou seguro · Encerrar SOS
                      </button>
                    </>
                  )}
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
};
