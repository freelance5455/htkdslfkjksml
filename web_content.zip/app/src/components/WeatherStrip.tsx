import React from 'react';
import {
  Cloud,
  CloudFog,
  CloudLightning,
  CloudRain,
  CloudSun,
  Droplets,
  Moon,
  Snowflake,
  Sun,
  Umbrella,
  Wind,
} from 'lucide-react';
import type {WeatherData} from '../types/tracking';

interface WeatherStripProps {
  weather: WeatherData | null;
  isLoading?: boolean;
  compact?: boolean;
}

export function renderWeatherIcon(
  code: WeatherData['conditionCode'],
  isDaytime: boolean,
  className = 'w-4 h-4'
) {
  switch (code) {
    case 'clear':
      return isDaytime ? (
        <Sun className={`${className} text-amber-500 dark:text-amber-400`} />
      ) : (
        <Moon className={`${className} text-indigo-400 dark:text-indigo-300`} />
      );
    case 'partly_cloudy':
      return (
        <CloudSun
          className={`${className} text-amber-500 dark:text-amber-400`}
        />
      );
    case 'cloudy':
      return (
        <Cloud className={`${className} text-slate-500 dark:text-slate-300`} />
      );
    case 'fog':
      return (
        <CloudFog
          className={`${className} text-slate-500 dark:text-slate-300`}
        />
      );
    case 'rain':
      return (
        <CloudRain
          className={`${className} text-blue-600 dark:text-blue-400`}
        />
      );
    case 'storm':
      return (
        <CloudLightning
          className={`${className} text-amber-600 dark:text-amber-400`}
        />
      );
    case 'snow':
      return (
        <Snowflake
          className={`${className} text-sky-500 dark:text-sky-300`}
        />
      );
  }
}

export function formatWeatherSummary(weather: WeatherData | null): string {
  if (!weather) return '';
  return `${Math.round(weather.temperatureC)}°C · ${weather.condition} · Vento ${Math.round(weather.windKmh)} km/h`;
}

export const WeatherStrip: React.FC<WeatherStripProps> = ({
  weather,
  isLoading = false,
  compact = false,
}) => {
  if (isLoading && !weather) {
    return (
      <div
        className={`flex items-center gap-2 text-[11px] text-slate-500 dark:text-slate-400 ${
          compact
            ? 'py-1'
            : 'mt-2 px-2.5 py-2 rounded-lg bg-slate-50 dark:bg-slate-800/70 border border-slate-100 dark:border-slate-800'
        }`}
      >
        <CloudSun className="w-3.5 h-3.5 text-slate-400 animate-pulse shrink-0" />
        <span>Consultando clima local...</span>
      </div>
    );
  }

  if (!weather) return null;

  if (compact) {
    return (
      <div className="flex flex-wrap items-center gap-x-2.5 gap-y-1 text-[11px] text-slate-700 dark:text-slate-200 bg-sky-50/70 dark:bg-sky-950/35 border border-sky-200/70 dark:border-sky-900/60 rounded-lg px-2.5 py-1.5">
        <span className="inline-flex items-center gap-1.5 font-semibold text-slate-900 dark:text-slate-100 tabular-nums">
          {renderWeatherIcon(
            weather.conditionCode,
            weather.isDaytime,
            'w-3.5 h-3.5 shrink-0'
          )}
          <span>{Math.round(weather.temperatureC)}°C</span>
        </span>
        <span className="text-slate-600 dark:text-slate-300 truncate max-w-[140px]">
          {weather.condition}
        </span>
        <span className="inline-flex items-center gap-1 font-mono tabular-nums text-slate-600 dark:text-slate-300">
          <Droplets className="w-3 h-3 text-sky-600 dark:text-sky-400 shrink-0" />
          {Math.round(weather.humidity)}%
        </span>
        <span className="inline-flex items-center gap-1 font-mono tabular-nums text-slate-600 dark:text-slate-300">
          <Wind className="w-3 h-3 text-slate-500 dark:text-slate-400 shrink-0" />
          {Math.round(weather.windKmh)} km/h
        </span>
      </div>
    );
  }

  return (
    <div className="mt-2 rounded-lg bg-sky-50/75 dark:bg-sky-950/40 border border-sky-200/80 dark:border-sky-900/70 px-2.5 py-2 text-xs">
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-2 min-w-0">
          {renderWeatherIcon(
            weather.conditionCode,
            weather.isDaytime,
            'w-5 h-5 shrink-0'
          )}
          <div className="min-w-0">
            <div className="flex items-baseline gap-1.5">
              <span className="text-sm font-bold font-mono tabular-nums text-slate-900 dark:text-slate-100">
                {Math.round(weather.temperatureC)}°C
              </span>
              <span className="text-[11px] text-slate-500 dark:text-slate-400 tabular-nums">
                Sensação {Math.round(weather.feelsLikeC)}°C
              </span>
            </div>
            <p className="text-[11px] text-slate-700 dark:text-slate-200 truncate">
              {weather.condition}
            </p>
          </div>
        </div>
      </div>

      <div className="mt-2 pt-1.5 border-t border-sky-200/60 dark:border-sky-900/60 grid grid-cols-3 gap-2 text-[11px] text-slate-600 dark:text-slate-300 tabular-nums">
        <span className="inline-flex items-center gap-1">
          <Droplets className="w-3 h-3 text-sky-600 dark:text-sky-400 shrink-0" />
          {Math.round(weather.humidity)}%
        </span>
        <span className="inline-flex items-center gap-1">
          <Wind className="w-3 h-3 text-slate-500 dark:text-slate-400 shrink-0" />
          {Math.round(weather.windKmh)} km/h
        </span>
        <span className="inline-flex items-center gap-1 justify-end">
          <Umbrella className="w-3 h-3 text-indigo-500 dark:text-indigo-400 shrink-0" />
          {Math.round(weather.precipProb)}%
        </span>
      </div>
    </div>
  );
};
