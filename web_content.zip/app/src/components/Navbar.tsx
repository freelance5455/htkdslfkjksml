import { Link } from "react-router";
import { useAuth } from "@/hooks/useAuth";
import { trpc } from "@/providers/trpc";
import { Coins, Wallet, Shield, LogOut, ScanFace } from "lucide-react";

export default function Navbar() {
  const { user, logout } = useAuth();
  const summary = trpc.wallet.summary.useQuery(undefined, { enabled: !!user });

  return (
    <header className="sticky top-0 z-40 border-b border-white/10 bg-[#0a0a1f]/90 backdrop-blur">
      <div className="mx-auto flex h-14 max-w-3xl items-center justify-between px-4 pt-[env(safe-area-inset-top)]">
        <Link to="/" className="flex items-center gap-2 font-extrabold tracking-tight text-white">
          <ScanFace className="h-5 w-5 text-[#74f7b2]" />
          CaptchaEarn
        </Link>
        <nav className="flex items-center gap-1 sm:gap-2">
          <div className="mr-1 flex items-center gap-1.5 rounded-full border border-[#74f7b2]/30 bg-[#74f7b2]/10 px-3 py-1.5 text-sm font-bold text-[#74f7b2] tabular-nums">
            <Coins className="h-4 w-4" />
            ${(summary.data?.balance ?? 0).toFixed(4)}
          </div>
          <Link to="/" className="hidden min-h-11 items-center px-2 text-sm text-[#7a8292] hover:text-white sm:flex">
            Earn
          </Link>
          <Link to="/wallet" className="flex min-h-11 items-center gap-1 px-2 text-sm text-[#7a8292] hover:text-white">
            <Wallet className="h-4 w-4" />
            <span className="hidden sm:inline">Wallet</span>
          </Link>
          {user?.role === "admin" && (
            <Link to="/admin" className="flex min-h-11 items-center gap-1 px-2 text-sm text-[#7a8292] hover:text-white">
              <Shield className="h-4 w-4" />
              <span className="hidden sm:inline">Admin</span>
            </Link>
          )}
          <button
            onClick={() => logout()}
            className="flex min-h-11 items-center px-2 text-[#7a8292] hover:text-white"
            aria-label="Log out"
          >
            <LogOut className="h-4 w-4" />
          </button>
        </nav>
      </div>
    </header>
  );
}
