import { Button } from "@/components/ui/button";
import { currentMonthKey, monthLabel, shiftMonth } from "@/lib/finance";
import { ChevronLeft, ChevronRight } from "lucide-react";

export function MonthSwitcher({
  value,
  onChange,
}: {
  value: string;
  onChange: (next: string) => void;
}) {
  const isCurrent = value === currentMonthKey();
  return (
    <div className="flex items-center gap-1">
      <Button
        variant="outline"
        size="icon"
        className="h-9 w-9"
        aria-label="الشهر السابق"
        onClick={() => onChange(shiftMonth(value, -1))}
      >
        <ChevronRight size={18} />
      </Button>
      <div className="min-w-[9.5rem] text-center">
        <span className="text-base font-semibold">{monthLabel(value)}</span>
        {isCurrent && (
          <span className="mr-2 rounded-full bg-forest/10 px-2 py-0.5 text-[11px] font-medium text-forest">
            الحالي
          </span>
        )}
      </div>
      <Button
        variant="outline"
        size="icon"
        className="h-9 w-9"
        aria-label="الشهر التالي"
        onClick={() => onChange(shiftMonth(value, 1))}
      >
        <ChevronLeft size={18} />
      </Button>
    </div>
  );
}
