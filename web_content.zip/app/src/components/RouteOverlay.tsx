import React, {useEffect, useRef} from 'react';
import {useMap, useMapsLibrary} from '@vis.gl/react-google-maps';
import type {RouteSummary} from '../types/tracking';

interface RouteOverlayProps {
  origin: google.maps.LatLngLiteral | null;
  destination: google.maps.LatLngLiteral | null;
  targetTrackerId: string;
  targetTrackerName: string;
  travelMode: 'DRIVING' | 'WALKING';
  onRouteComputed: (summary: RouteSummary | null) => void;
  onRouteError: (message: string | null) => void;
}

export const RouteOverlay: React.FC<RouteOverlayProps> = ({
  origin,
  destination,
  targetTrackerId,
  targetTrackerName,
  travelMode,
  onRouteComputed,
  onRouteError,
}) => {
  const map = useMap();
  const routesLib = useMapsLibrary('routes');
  const polylinesRef = useRef<google.maps.Polyline[]>([]);

  useEffect(() => {
    const clearPolylines = () => {
      polylinesRef.current.forEach((p) => p.setMap(null));
      polylinesRef.current = [];
    };

    if (!routesLib || !map || !origin || !destination) {
      clearPolylines();
      return;
    }

    let cancelled = false;
    clearPolylines();
    onRouteError(null);

    const request: google.maps.routes.ComputeRoutesRequest = {
      origin,
      destination,
      travelMode:
        travelMode === 'WALKING'
          ? routesLib.TravelMode.WALKING
          : routesLib.TravelMode.DRIVING,
      fields: ['path', 'distanceMeters', 'durationMillis', 'viewport'],
    };

    routesLib.Route.computeRoutes(request)
      .then((response) => {
        if (cancelled) return;
        const primaryRoute = response?.routes?.[0];
        if (!primaryRoute) {
          onRouteComputed(null);
          onRouteError('Nenhuma rota disponível entre os pontos selecionados.');
          return;
        }

        const newPolylines = primaryRoute.createPolylines();
        newPolylines.forEach((line) => {
          line.setOptions({
            strokeColor: '#2563EB',
            strokeWeight: 5,
            strokeOpacity: 0.9,
          });
          line.setMap(map);
        });
        polylinesRef.current = newPolylines;

        if (primaryRoute.viewport) {
          map.fitBounds(primaryRoute.viewport, 64);
        }

        onRouteComputed({
          targetTrackerId,
          targetTrackerName,
          distanceMeters: primaryRoute.distanceMeters ?? 0,
          durationMillis: primaryRoute.durationMillis ?? 0,
          travelMode,
        });
      })
      .catch((err: unknown) => {
        if (cancelled) return;
        const msg = err instanceof Error ? err.message : String(err);
        if (
          msg.includes('RESOURCE_EXHAUSTED') ||
          msg.includes('OVER_QUERY_LIMIT') ||
          msg.includes('429')
        ) {
          window.dispatchEvent(new CustomEvent('gmp-quota-exceeded'));
        }
        onRouteComputed(null);
        onRouteError('Não foi possível calcular a rota no momento.');
        console.error('Erro ao calcular rota:', err);
      });

    return () => {
      cancelled = true;
      clearPolylines();
    };
  }, [
    routesLib,
    map,
    origin?.lat,
    origin?.lng,
    destination?.lat,
    destination?.lng,
    targetTrackerId,
    targetTrackerName,
    travelMode,
  ]);

  return null;
};
