import { useAuth } from "@/hooks/useAuth";
import { LOGIN_PATH } from "@/const";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { AuthLayoutSkeleton } from "@/components/AuthLayoutSkeleton";
import {
  ArrowLeftRight,
  LayoutDashboard,
  LogOut,
  PieChart,
  Settings,
  Tags,
} from "lucide-react";
import type { ReactNode } from "react";
import { NavLink } from "react-router";

const NAV_ITEMS = [
  { icon: LayoutDashboard, label: "لوحة التحكم", path: "/" },
  { icon: ArrowLeftRight, label: "المعاملات", path: "/transactions" },
  { icon: PieChart, label: "الميزانيات", path: "/budgets" },
  { icon: Tags, label: "الفئات", path: "/categories" },
  { icon: Settings, label: "الإعدادات", path: "/settings" },
];

function HouseMark() {
  return (
    <svg width="30" height="30" viewBox="0 0 30 30" fill="none" aria-hidden>
      <rect width="30" height="30" rx="8" fill="#de5126" />
      <path
        d="M8 15.5 15 9l7 6.5"
        stroke="#fdfcfa"
        strokeWidth="2.2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M10 14.5V21h10v-6.5"
        stroke="#fdfcfa"
        strokeWidth="2.2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <circle cx="15" cy="17.5" r="1.4" fill="#fdfcfa" />
    </svg>
  );
}

export default function AppLayout({ children }: { children: ReactNode }) {
  const { isLoading, user } = useAuth();

  if (isLoading) {
    return <AuthLayoutSkeleton />;
  }

  if (!user) {
    return (
      <div className="flex min-h-[100dvh] items-center justify-center bg-background p-6">
        <div className="flex w-full max-w-sm flex-col items-center gap-6">
          <HouseMark />
          <div className="text-center">
            <h1 className="text-2xl font-semibold">بيتي — مدير مصاريف البيت</h1>
            <p className="mt-2 text-sm text-muted-foreground">
              سجّل الدخول لمتابعة مصاريف بيتك من أي جهاز.
            </p>
          </div>
          <Button
            size="lg"
            className="w-full"
            onClick={() => {
              window.location.href = LOGIN_PATH;
            }}
          >
            تسجيل الدخول بحساب Kimi
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-[100dvh] bg-background">
      {/* Desktop sidebar — right side in RTL */}
      <aside className="fixed inset-y-0 right-0 z-30 hidden w-60 flex-col bg-ink text-[#e8e2dc] lg:flex">
        <div className="flex h-16 items-center gap-3 px-5">
          <HouseMark />
          <div className="leading-tight">
            <div className="text-lg font-semibold">بيتي</div>
            <div className="text-[11px] text-[#9c948e]">مدير مصاريف البيت</div>
          </div>
        </div>

        <nav className="mt-4 flex-1 space-y-1 px-3">
          {NAV_ITEMS.map(item => (
            <NavLink
              key={item.path}
              to={item.path}
              end={item.path === "/"}
              className={({ isActive }) =>
                `flex h-11 items-center gap-3 rounded-lg px-3 text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ember ${
                  isActive
                    ? "bg-ember text-[#fdfcfa]"
                    : "text-[#c9c1ba] hover:bg-white/10 hover:text-white"
                }`
              }
            >
              <item.icon size={18} strokeWidth={2.2} />
              {item.label}
            </NavLink>
          ))}
        </nav>

        <div className="flex items-center gap-3 border-t border-white/10 p-4">
          <Avatar className="h-9 w-9 border border-white/20">
            <AvatarImage src={user.avatar ?? undefined} />
            <AvatarFallback className="bg-ember text-sm text-[#fdfcfa]">
              {(user.name ?? "ب").slice(0, 1)}
            </AvatarFallback>
          </Avatar>
          <div className="min-w-0 flex-1 leading-tight">
            <div className="truncate text-sm font-medium">{user.name ?? "مستخدم"}</div>
            <div className="truncate text-[11px] text-[#9c948e]">
              {user.email ?? ""}
            </div>
          </div>
          <LogoutButton />
        </div>
      </aside>

      {/* Mobile top bar */}
      <header className="sticky top-0 z-30 flex h-14 items-center justify-between border-b bg-background/90 px-4 backdrop-blur lg:hidden">
        <div className="flex items-center gap-2.5">
          <HouseMark />
          <span className="text-lg font-semibold">بيتي</span>
        </div>
        <Avatar className="h-8 w-8">
          <AvatarImage src={user.avatar ?? undefined} />
          <AvatarFallback className="bg-ember text-xs text-[#fdfcfa]">
            {(user.name ?? "ب").slice(0, 1)}
          </AvatarFallback>
        </Avatar>
      </header>

      {/* Content */}
      <main className="pb-24 lg:mr-60 lg:pb-10">{children}</main>

      {/* Mobile bottom nav */}
      <nav className="fixed inset-x-0 bottom-0 z-30 border-t bg-card/95 pb-[env(safe-area-inset-bottom)] backdrop-blur lg:hidden">
        <div className="grid grid-cols-5">
          {NAV_ITEMS.map(item => (
            <NavLink
              key={item.path}
              to={item.path}
              end={item.path === "/"}
              className={({ isActive }) =>
                `flex h-16 flex-col items-center justify-center gap-1 text-[10px] font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ember focus-visible:ring-inset ${
                  isActive ? "text-ember" : "text-muted-foreground"
                }`
              }
            >
              <item.icon size={20} strokeWidth={2.2} />
              {item.label}
            </NavLink>
          ))}
        </div>
      </nav>
    </div>
  );
}

function LogoutButton() {
  const { logout } = useAuth();
  return (
    <button
      onClick={logout}
      aria-label="تسجيل الخروج"
      className="flex h-9 w-9 items-center justify-center rounded-lg text-[#9c948e] transition-colors hover:bg-white/10 hover:text-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ember"
    >
      <LogOut size={17} />
    </button>
  );
}
