import type { ReactNode } from "react";
import { NavLink, useNavigate } from "react-router";
import {
  Flame,
  ListTodo,
  Trophy,
  BarChart3,
  User,
  Shield,
  LogOut,
} from "lucide-react";
import { trpc } from "@/providers/trpc";
import { Button } from "@/components/ui/button";

const navItems = [
  { to: "/", label: "Streak", icon: Flame },
  { to: "/statistik", label: "Statistik", icon: BarChart3 },
  { to: "/habit", label: "Habit", icon: ListTodo },
  { to: "/peringkat", label: "Peringkat", icon: Trophy },
];

export default function AppLayout({ children }: { children: ReactNode }) {
  const navigate = useNavigate();
  const { data: me } = trpc.auth.me.useQuery();
  const logout = trpc.auth.logout.useMutation({
    onSuccess: () => {
      navigate("/login", { replace: true });
      window.location.reload();
    },
  });

  const items = me?.role === "admin"
    ? [...navItems, { to: "/admin", label: "Admin", icon: Shield }]
    : navItems;

  return (
    <div className="min-h-[100dvh] flex flex-col">
      <header className="sticky top-0 z-40 bg-background/90 backdrop-blur border-b border-border">
        <div className="mx-auto max-w-5xl px-4 h-14 flex items-center gap-3">
          <Flame className="w-5 h-5 text-primary" />
          <span className="font-display font-bold tracking-tight hidden sm:block">
            No Nut Tracker
          </span>
          <span className="font-display font-bold tracking-tight sm:hidden">NNT</span>
          <div className="ml-auto flex items-center gap-1">
            <Button
              variant="ghost"
              size="sm"
              className="gap-2"
              onClick={() => navigate("/profil")}
              aria-label="Profil"
            >
              <User className="w-4 h-4" />
              <span className="hidden md:inline max-w-[140px] truncate">
                {me?.displayName}
              </span>
            </Button>
            <Button
              variant="ghost"
              size="icon"
              aria-label="Keluar"
              onClick={() => logout.mutate()}
            >
              <LogOut className="w-4 h-4" />
            </Button>
          </div>
        </div>
        <nav className="md:hidden border-t border-border">
          <div className={`grid h-14 ${items.length === 5 ? "grid-cols-5" : "grid-cols-4"}`}>
            {items.map(({ to, label, icon: Icon }) => (
              <NavLink
                key={to}
                to={to}
                end={to === "/"}
                className={({ isActive }) =>
                  `flex flex-col items-center justify-center gap-0.5 text-[11px] transition-colors ${
                    isActive
                      ? "text-primary"
                      : "text-muted-foreground active:text-foreground"
                  }`
                }
              >
                <Icon className="w-5 h-5" />
                {label}
              </NavLink>
            ))}
          </div>
        </nav>
      </header>

      <div className="flex flex-1 mx-auto w-full max-w-5xl">
        <aside className="hidden md:block w-52 shrink-0 border-r border-border py-6 px-3">
          <nav className="space-y-1 sticky top-24">
            {items.map(({ to, label, icon: Icon }) => (
              <NavLink
                key={to}
                to={to}
                end={to === "/"}
                className={({ isActive }) =>
                  `flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                    isActive
                      ? "bg-primary/10 text-primary"
                      : "text-muted-foreground hover:bg-accent hover:text-foreground"
                  }`
                }
              >
                <Icon className="w-4 h-4" />
                {label}
              </NavLink>
            ))}
          </nav>
        </aside>
        <main className="flex-1 px-4 py-6 pb-28 md:pb-10">{children}</main>
      </div>
    </div>
  );
}
