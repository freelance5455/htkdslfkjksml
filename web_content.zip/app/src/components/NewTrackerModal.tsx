import React, {useState} from 'react';
import {X} from 'lucide-react';
import {
  BLUEPRINT_LIMITS,
  CATEGORY_LABELS,
  TRACKER_COLORS,
  type TrackerCategory,
} from '../types/tracking';

interface NewTrackerModalProps {
  isSubmitting: boolean;
  onCreate: (data: {
    name: string;
    category: TrackerCategory;
    color: string;
  }) => Promise<void>;
  onClose: () => void;
}

export const NewTrackerModal: React.FC<NewTrackerModalProps> = ({
  isSubmitting,
  onCreate,
  onClose,
}) => {
  const [name, setName] = useState('');
  const [category, setCategory] = useState<TrackerCategory>('vehicle');
  const [color, setColor] = useState<string>(TRACKER_COLORS[0].value);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = name.trim();
    if (trimmed.length < BLUEPRINT_LIMITS.NAME_MIN) {
      setError('Informe um nome para o rastreador.');
      return;
    }
    setError(null);
    await onCreate({
      name: trimmed.slice(0, BLUEPRINT_LIMITS.NAME_MAX),
      category,
      color,
    });
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-slate-950/55 dark:bg-black/70 backdrop-blur-xs flex items-center justify-center p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="new-tracker-title"
    >
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl max-w-md w-full p-6 shadow-xl">
        <div className="flex items-center justify-between gap-3 mb-5">
          <h2
            id="new-tracker-title"
            className="text-base font-semibold text-slate-900 dark:text-slate-100"
          >
            Novo rastreador
          </h2>
          <button
            type="button"
            onClick={onClose}
            aria-label="Fechar"
            className="p-1 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={(e) => void handleSubmit(e)} className="space-y-4">
          <div>
            <label
              htmlFor="tracker-name"
              className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5"
            >
              Nome do dispositivo ou veículo
            </label>
            <input
              id="tracker-name"
              type="text"
              maxLength={BLUEPRINT_LIMITS.NAME_MAX}
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Ex.: Celular Pessoal, Frota 04, Mochila"
              className="w-full px-3 py-2 text-sm bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600/25 focus:border-blue-600"
              autoFocus
            />
          </div>

          <div>
            <span className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
              Categoria
            </span>
            <div className="grid grid-cols-4 gap-1.5 bg-slate-100 dark:bg-slate-800 p-1 rounded-lg">
              {(Object.keys(CATEGORY_LABELS) as TrackerCategory[]).map((cat) => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setCategory(cat)}
                  className={`py-1.5 px-2 text-xs font-medium rounded-md transition-colors cursor-pointer whitespace-nowrap ${
                    category === cat
                      ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-xs'
                      : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  {CATEGORY_LABELS[cat]}
                </button>
              ))}
            </div>
          </div>

          <div>
            <span className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-2">
              Cor no mapa
            </span>
            <div className="flex items-center gap-2.5">
              {TRACKER_COLORS.map((c) => (
                <button
                  key={c.value}
                  type="button"
                  aria-label={c.label}
                  onClick={() => setColor(c.value)}
                  className={`w-7 h-7 rounded-full transition-transform cursor-pointer ${
                    color === c.value
                      ? 'ring-2 ring-offset-2 ring-slate-900 dark:ring-slate-100 dark:ring-offset-slate-900 scale-110'
                      : 'hover:scale-105'
                  }`}
                  style={{backgroundColor: c.value}}
                />
              ))}
            </div>
          </div>

          {error && <p className="text-xs text-red-600 dark:text-red-400">{error}</p>}

          <div className="flex items-center justify-end gap-2.5 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-sm font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-4 py-2 text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 disabled:opacity-60 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
            >
              {isSubmitting ? 'Criando...' : 'Criar rastreador'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
