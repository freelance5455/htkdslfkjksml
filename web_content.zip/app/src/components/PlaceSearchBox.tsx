import React, {useCallback, useState} from 'react';
import {useMap, useMapsLibrary} from '@vis.gl/react-google-maps';
import {Loader2, MapPin, Search, X} from 'lucide-react';
import {useAutocompleteSuggestions} from '../hooks/useAutocompleteSuggestions';

interface PlaceSearchBoxProps {
  onLocationSelected?: (location: {
    lat: number;
    lng: number;
    label: string;
  }) => void;
}

export const PlaceSearchBox: React.FC<PlaceSearchBoxProps> = ({
  onLocationSelected,
}) => {
  const map = useMap();
  const placesLib = useMapsLibrary('places');
  const [query, setQuery] = useState('');
  const [isOpen, setIsOpen] = useState(false);
  const {suggestions, isLoading, error, resetSession} =
    useAutocompleteSuggestions(query, {
      language: 'pt-BR',
    });

  const handleSelect = useCallback(
    async (suggestion: google.maps.places.AutocompleteSuggestion) => {
      if (!placesLib || !suggestion.placePrediction) return;
      try {
        const place = suggestion.placePrediction.toPlace();
        await place.fetchFields({
          fields: ['displayName', 'formattedAddress', 'location', 'viewport'],
        });

        const loc = place.location;
        if (loc && map) {
          if (place.viewport) {
            map.fitBounds(place.viewport);
          } else {
            map.panTo({lat: loc.lat(), lng: loc.lng()});
            map.setZoom(16);
          }

          onLocationSelected?.({
            lat: loc.lat(),
            lng: loc.lng(),
            label:
              place.displayName ||
              place.formattedAddress ||
              suggestion.placePrediction.text.text,
          });
        }

        setQuery(suggestion.placePrediction.text.text);
        setIsOpen(false);
        resetSession();
      } catch (err: unknown) {
        const msg = err instanceof Error ? err.message : String(err);
        if (
          msg.includes('RESOURCE_EXHAUSTED') ||
          msg.includes('OVER_QUERY_LIMIT') ||
          msg.includes('429')
        ) {
          window.dispatchEvent(new CustomEvent('gmp-quota-exceeded'));
        }
        console.error('Erro ao carregar detalhes do local:', err);
      }
    },
    [placesLib, map, onLocationSelected, resetSession]
  );

  const handleClear = () => {
    setQuery('');
    setIsOpen(false);
    resetSession();
  };

  return (
    <div className="relative w-full max-w-sm">
      <div className="flex items-center bg-white/95 dark:bg-slate-900/95 backdrop-blur-sm border border-slate-200 dark:border-slate-700 rounded-lg shadow-sm focus-within:ring-2 focus-within:ring-blue-600/25 focus-within:border-blue-600 transition-colors">
        <Search className="w-4 h-4 text-slate-400 dark:text-slate-500 ml-3 shrink-0" />
        <input
          type="text"
          value={query}
          onChange={(e) => {
            setQuery(e.target.value);
            setIsOpen(true);
          }}
          onFocus={() => setIsOpen(true)}
          placeholder="Buscar endereço ou local no mapa..."
          aria-label="Buscar endereço ou local no mapa"
          className="w-full px-2.5 py-2.5 text-sm text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500 bg-transparent focus:outline-none"
        />
        {isLoading && (
          <Loader2 className="w-4 h-4 text-blue-600 dark:text-blue-400 animate-spin mr-2 shrink-0" />
        )}
        {query && !isLoading && (
          <button
            type="button"
            onClick={handleClear}
            aria-label="Limpar busca"
            className="p-2 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 transition-colors cursor-pointer shrink-0"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {isOpen && (suggestions.length > 0 || error) && (
        <div className="absolute left-0 right-0 mt-1.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg shadow-lg overflow-hidden z-30">
          {error ? (
            <div className="px-3 py-2.5 text-xs text-red-600 dark:text-red-400">{error}</div>
          ) : (
            <ul className="divide-y divide-slate-100 dark:divide-slate-800 max-h-64 overflow-y-auto">
              {suggestions.map((suggestion, idx) => {
                const text = suggestion.placePrediction?.text.text;
                if (!text) return null;
                return (
                  <li key={suggestion.placePrediction?.placeId ?? idx}>
                    <button
                      type="button"
                      onClick={() => void handleSelect(suggestion)}
                      className="w-full text-left px-3 py-2.5 text-sm text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 flex items-start gap-2.5 transition-colors cursor-pointer"
                    >
                      <MapPin className="w-4 h-4 text-slate-400 dark:text-slate-500 mt-0.5 shrink-0" />
                      <span className="line-clamp-2">{text}</span>
                    </button>
                  </li>
                );
              })}
            </ul>
          )}
        </div>
      )}
    </div>
  );
};
