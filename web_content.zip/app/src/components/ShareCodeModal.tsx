import React, {useMemo, useState} from 'react';
import {canShare, shareContent} from '../share';
import {isNative} from '../native';
import {
  Check,
  Code2,
  Copy,
  Link2,
  Mail,
  MessageCircle,
  MessageSquare,
  Send,
  Share2,
  X,
} from 'lucide-react';
import {CATEGORY_LABELS, type Tracker} from '../types/tracking';

interface ShareCodeModalProps {
  tracker: Tracker;
  onClose: () => void;
}

type CopiedTarget = 'code' | 'link' | 'message' | 'json' | null;

export const ShareCodeModal: React.FC<ShareCodeModalProps> = ({
  tracker,
  onClose,
}) => {
  const [copiedTarget, setCopiedTarget] = useState<CopiedTarget>(null);
  const [nativeShareStatus, setNativeShareStatus] = useState<string | null>(
    null
  );

  const shareUrl = useMemo(() => {
    if (typeof window === 'undefined') {
      return `?codigo=${encodeURIComponent(tracker.shareCode)}`;
    }
    // No APK o endereço do site é "https://localhost"; usa VITE_PUBLIC_URL se existir
    const base = isNative
      ? (import.meta.env.VITE_PUBLIC_URL as string | undefined) || ''
      : window.location.href;
    if (!base) return '';
    const url = new URL(base);
    url.search = '';
    url.hash = '';
    url.searchParams.set('codigo', tracker.shareCode);
    return url.toString();
  }, [tracker.shareCode]);

  const inviteMessage = useMemo(
    () =>
      `Acompanhe "${tracker.name}" em tempo real no PontoVivo.\nCódigo: ${tracker.shareCode}\nAbrir direto: ${shareUrl}`,
    [tracker.name, tracker.shareCode, shareUrl]
  );

  const integrationJson = useMemo(
    () =>
      JSON.stringify(
        {
          app: 'PontoVivo',
          trackerId: tracker.id,
          trackerName: tracker.name,
          category: tracker.category,
          shareCode: tracker.shareCode,
          joinUrl: shareUrl,
          lat: tracker.lat,
          lng: tracker.lng,
        },
        null,
        2
      ),
    [tracker, shareUrl]
  );

  const supportsNativeShare =
    canShare;

  const copyText = async (text: string, target: Exclude<CopiedTarget, null>) => {
    try {
      await navigator.clipboard?.writeText(text);
      setCopiedTarget(target);
      window.setTimeout(() => {
        setCopiedTarget((prev) => (prev === target ? null : prev));
      }, 2000);
    } catch {
      setNativeShareStatus(
        'Não foi possível copiar automaticamente. Selecione o texto manualmente.'
      );
    }
  };

  const handleNativeShare = async () => {
    if (!supportsNativeShare) return;
    setNativeShareStatus(null);
    try {
      await shareContent({
        title: `PontoVivo · ${tracker.name}`,
        text: `Acompanhe "${tracker.name}" em tempo real no PontoVivo. Código: ${tracker.shareCode}`,
        url: shareUrl,
      });
    } catch (err) {
      if (err instanceof Error && err.name === 'AbortError') return;
      setNativeShareStatus(
        'Use uma das opções abaixo para enviar o código para outro app.'
      );
    }
  };

  const whatsappHref = `https://wa.me/?text=${encodeURIComponent(inviteMessage)}`;
  const telegramHref = `https://t.me/share/url?url=${encodeURIComponent(shareUrl)}&text=${encodeURIComponent(`Acompanhe "${tracker.name}" no PontoVivo · Código: ${tracker.shareCode}`)}`;
  const emailHref = `mailto:?subject=${encodeURIComponent(`PontoVivo · Código ${tracker.shareCode} (${tracker.name})`)}&body=${encodeURIComponent(inviteMessage)}`;
  const smsHref = `sms:?body=${encodeURIComponent(inviteMessage)}`;

  return (
    <div
      className="fixed inset-0 z-50 bg-slate-950/55 dark:bg-black/70 backdrop-blur-xs flex items-center justify-center p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="share-code-modal-title"
      onClick={onClose}
    >
      <div
        className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl max-w-md w-full p-6 shadow-xl space-y-5 max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-3">
          <div>
            <h2
              id="share-code-modal-title"
              className="text-base font-semibold text-slate-900 dark:text-slate-100"
            >
              Enviar código para outro app
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              {tracker.name} · {CATEGORY_LABELS[tracker.category]}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Fechar"
            className="p-1 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Share code & direct link */}
        <div className="space-y-2.5">
          <div className="flex items-center justify-between gap-3 px-3.5 py-3 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800">
            <div>
              <span className="block text-[11px] text-slate-500 dark:text-slate-400">
                Código de acesso
              </span>
              <span className="text-lg font-bold font-mono tracking-wider tabular-nums text-slate-900 dark:text-slate-100">
                {tracker.shareCode}
              </span>
            </div>
            <button
              type="button"
              onClick={() => void copyText(tracker.shareCode, 'code')}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors cursor-pointer whitespace-nowrap shrink-0"
            >
              {copiedTarget === 'code' ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                  Copiado
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  Copiar código
                </>
              )}
            </button>
          </div>

          <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800">
            <Link2 className="w-3.5 h-3.5 text-slate-400 dark:text-slate-500 shrink-0" />
            <span className="text-xs font-mono text-slate-600 dark:text-slate-300 truncate flex-1">
              {shareUrl}
            </span>
            <button
              type="button"
              onClick={() => void copyText(shareUrl, 'link')}
              className="text-xs font-medium text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 cursor-pointer whitespace-nowrap shrink-0"
            >
              {copiedTarget === 'link' ? 'Link copiado' : 'Copiar link'}
            </button>
          </div>
        </div>

        {/* Native share + external app targets */}
        <div className="space-y-2.5">
          <p className="text-xs font-medium text-slate-700 dark:text-slate-300">
            Enviar diretamente via aplicativo
          </p>

          {supportsNativeShare && (
            <button
              type="button"
              onClick={() => void handleNativeShare()}
              className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium rounded-lg transition-colors cursor-pointer"
            >
              <Share2 className="w-4 h-4" />
              Compartilhar pelo dispositivo
            </button>
          )}

          <div className="grid grid-cols-2 gap-2">
            <a
              href={whatsappHref}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-2 px-3 py-2 text-xs font-medium bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg transition-colors whitespace-nowrap"
            >
              <MessageCircle className="w-4 h-4 shrink-0" />
              WhatsApp
            </a>
            <a
              href={telegramHref}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-2 px-3 py-2 text-xs font-medium bg-sky-600 hover:bg-sky-700 text-white rounded-lg transition-colors whitespace-nowrap"
            >
              <Send className="w-4 h-4 shrink-0" />
              Telegram
            </a>
            <a
              href={emailHref}
              className="inline-flex items-center justify-center gap-2 px-3 py-2 text-xs font-medium bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-100 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-colors whitespace-nowrap"
            >
              <Mail className="w-4 h-4 shrink-0" />
              E-mail
            </a>
            <a
              href={smsHref}
              className="inline-flex items-center justify-center gap-2 px-3 py-2 text-xs font-medium bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-100 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-colors whitespace-nowrap"
            >
              <MessageSquare className="w-4 h-4 shrink-0" />
              SMS
            </a>
          </div>

          {nativeShareStatus && (
            <p className="text-xs text-amber-700 dark:text-amber-300">
              {nativeShareStatus}
            </p>
          )}
        </div>

        {/* Invite text + JSON export */}
        <div className="space-y-2 pt-3 border-t border-slate-200 dark:border-slate-800">
          <div className="flex items-center justify-between gap-2">
            <span className="text-xs font-medium text-slate-700 dark:text-slate-300">
              Mensagem pronta
            </span>
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => void copyText(integrationJson, 'json')}
                className="inline-flex items-center gap-1 text-xs text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100 cursor-pointer whitespace-nowrap"
              >
                <Code2 className="w-3.5 h-3.5" />
                {copiedTarget === 'json' ? 'JSON copiado' : 'Copiar JSON'}
              </button>
              <button
                type="button"
                onClick={() => void copyText(inviteMessage, 'message')}
                className="inline-flex items-center gap-1 text-xs font-medium text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 cursor-pointer whitespace-nowrap"
              >
                {copiedTarget === 'message' ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                    Mensagem copiada
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    Copiar mensagem
                  </>
                )}
              </button>
            </div>
          </div>
          <pre className="text-[11px] font-mono whitespace-pre-wrap break-all bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg p-2.5 text-slate-600 dark:text-slate-300 select-all">
            {inviteMessage}
          </pre>
        </div>
      </div>
    </div>
  );
};
