import React, {useState} from 'react';
import {
  AdvancedMarker,
  InfoWindow,
  useAdvancedMarkerRef,
} from '@vis.gl/react-google-maps';
import {
  BatteryCharging,
  BatteryFull,
  BatteryLow,
  BatteryMedium,
  Car,
  Check,
  Compass,
  Copy,
  Crosshair,
  MapPin,
  Navigation,
  Package,
  PawPrint,
  Share2,
  User,
} from 'lucide-react';
import {useReverseGeocode} from '../hooks/useReverseGeocode';
import {useSmoothPosition} from '../hooks/useSmoothPosition';
import {useWeather} from '../hooks/useWeather';
import {
  CATEGORY_LABELS,
  LOW_BATTERY_THRESHOLD,
  type Tracker,
  formatCoordinates,
  formatDistance,
  formatRelativeTimePt,
  formatSpeedKmh,
} from '../types/tracking';
import {getAccuracyDiagnostic} from '../utils/locationPrecision';
import {WeatherStrip} from './WeatherStrip';

interface TrackerMarkerProps {
  tracker: Tracker;
  isSelected: boolean;
  isInfoOpen: boolean;
  onSelect: () => void;
  onCloseInfo: () => void;
  onCenterMap: () => void;
  onRouteTo: () => void;
  onShareCode: () => void;
}

function renderCategoryIcon(category: Tracker['category']) {
  const cls = 'w-4 h-4 text-white';
  switch (category) {
    case 'vehicle':
      return <Car className={cls} />;
    case 'person':
      return <User className={cls} />;
    case 'pet':
      return <PawPrint className={cls} />;
    case 'asset':
    default:
      return <Package className={cls} />;
  }
}

function renderBatteryIcon(level: number, charging?: boolean) {
  if (charging) {
    return (
      <BatteryCharging className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
    );
  }
  if (level < LOW_BATTERY_THRESHOLD) {
    return (
      <BatteryLow className="w-3.5 h-3.5 text-red-600 dark:text-red-400" />
    );
  }
  if (level < 60) {
    return (
      <BatteryMedium className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
    );
  }
  return (
    <BatteryFull className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
  );
}

export const TrackerMarker: React.FC<TrackerMarkerProps> = ({
  tracker,
  isSelected,
  isInfoOpen,
  onSelect,
  onCloseInfo,
  onCenterMap,
  onRouteTo,
  onShareCode,
}) => {
  const [markerRef, marker] = useAdvancedMarkerRef();
  const [copiedCoords, setCopiedCoords] = useState(false);

  const smoothPos = useSmoothPosition(tracker.lat, tracker.lng, 950);
  const hasBattery = typeof tracker.batteryLevel === 'number';
  const batteryLevel = hasBattery ? Math.round(tracker.batteryLevel!) : null;
  const isLowBattery =
    batteryLevel !== null && batteryLevel < LOW_BATTERY_THRESHOLD;
  const showHeadingArrow = tracker.heading > 0 && tracker.speed >= 0.4;
  const accuracyDiag = getAccuracyDiagnostic(tracker.accuracy);

  const {address, placeName, isLoading: loadingAddress} = useReverseGeocode(
    {lat: tracker.lat, lng: tracker.lng},
    isInfoOpen
  );

  const {weather, isLoading: loadingWeather} = useWeather(
    {lat: tracker.lat, lng: tracker.lng},
    isInfoOpen || isSelected
  );

  const handleCopyCoords = () => {
    void navigator.clipboard?.writeText(
      `${tracker.lat.toFixed(6)}, ${tracker.lng.toFixed(6)}`
    );
    setCopiedCoords(true);
    window.setTimeout(() => setCopiedCoords(false), 1600);
  };

  return (
    <>
      <AdvancedMarker
        ref={markerRef}
        position={smoothPos}
        onClick={onSelect}
        title={tracker.name}
        zIndex={isSelected ? 50 : tracker.isBroadcasting ? 30 : 10}
      >
        <div className="relative flex flex-col items-center cursor-pointer select-none">
          {tracker.isBroadcasting && (
            <span
              className="absolute -inset-2 rounded-full opacity-25 animate-ping pointer-events-none"
              style={{backgroundColor: tracker.color}}
            />
          )}

          <div className="relative flex items-center justify-center">
            {showHeadingArrow && (
              <div
                aria-hidden="true"
                className="absolute inset-0 flex items-start justify-center pointer-events-none"
                style={{transform: `rotate(${tracker.heading}deg)`}}
              >
                <span
                  className="-mt-2.5 w-0 h-0 border-l-[5px] border-l-transparent border-r-[5px] border-r-transparent border-b-[8px]"
                  style={{borderBottomColor: tracker.color}}
                />
              </div>
            )}

            <div
              className={`relative w-9 h-9 rounded-full flex items-center justify-center shadow-md border-2 border-white dark:border-slate-900 transition-transform duration-150 ${
                isSelected
                  ? 'scale-115 ring-4 ring-slate-900/15 dark:ring-white/25'
                  : 'hover:scale-105'
              }`}
              style={{backgroundColor: tracker.color}}
            >
              {renderCategoryIcon(tracker.category)}
              {isLowBattery && (
                <span
                  title={`Bateria baixa (${batteryLevel}%)`}
                  className="absolute -top-1.5 -right-1.5 w-4 h-4 rounded-full bg-red-600 border border-white dark:border-slate-900 flex items-center justify-center shadow-sm"
                >
                  <BatteryLow className="w-2.5 h-2.5 text-white" />
                </span>
              )}
            </div>
          </div>

          <div className="mt-1 px-2 py-0.5 rounded bg-slate-900/90 dark:bg-slate-950/95 text-white text-[11px] font-medium whitespace-nowrap shadow-sm flex items-center gap-1 border border-transparent dark:border-slate-700/70">
            <span>{tracker.name}</span>
            {tracker.isBroadcasting && tracker.speed >= 0.4 && (
              <span className="font-mono tabular-nums text-emerald-300">
                · {formatSpeedKmh(tracker.speed)}
              </span>
            )}
            {weather && (
              <span className="font-mono tabular-nums text-sky-300">
                · {Math.round(weather.temperatureC)}°C
              </span>
            )}
            {isLowBattery && (
              <span className="font-mono tabular-nums text-red-300">
                · {batteryLevel}%
              </span>
            )}
          </div>
        </div>
      </AdvancedMarker>

      {isInfoOpen && marker && (
        <InfoWindow
          anchor={marker}
          onCloseClick={onCloseInfo}
          maxWidth={320}
        >
          <div className="p-2 rounded-lg bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 min-w-[245px]">
            <div className="flex items-start justify-between gap-2 mb-1.5">
              <div>
                <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100 leading-tight">
                  {tracker.name}
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                  {CATEGORY_LABELS[tracker.category]} ·{' '}
                  {tracker.isBroadcasting ? 'Ao vivo' : 'Última posição'}
                </p>
              </div>
              <span className="text-[11px] font-mono text-slate-500 dark:text-slate-400 tabular-nums whitespace-nowrap">
                {tracker.shareCode}
              </span>
            </div>

            {(address || placeName || loadingAddress) && (
              <div className="mt-1.5 flex items-start gap-1.5 text-xs text-slate-600 dark:text-slate-300 bg-slate-50 dark:bg-slate-800/70 border border-slate-100 dark:border-slate-800 rounded-md px-2 py-1.5">
                <MapPin className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400 shrink-0 mt-0.5" />
                <span className="leading-snug">
                  {loadingAddress
                    ? 'Identificando endereço exato...'
                    : placeName && address
                      ? `${placeName} — ${address}`
                      : address || placeName}
                </span>
              </div>
            )}

            <WeatherStrip weather={weather} isLoading={loadingWeather} />

            {isLowBattery && (
              <div className="mt-2 mb-1 flex items-start gap-1.5 px-2 py-1.5 rounded-md bg-red-50 dark:bg-red-950/70 border border-red-200 dark:border-red-900/80 text-red-800 dark:text-red-200 text-xs">
                <BatteryLow className="w-3.5 h-3.5 text-red-600 dark:text-red-400 shrink-0 mt-0.5" />
                <span>
                  Bateria baixa ({batteryLevel}%). Conecte o carregador para não perder o rastreamento.
                </span>
              </div>
            )}

            <div className="border-t border-slate-100 dark:border-slate-800 pt-2 mt-2 space-y-1 text-xs text-slate-600 dark:text-slate-300">
              <div className="flex items-center justify-between gap-2">
                <span className="text-slate-500 dark:text-slate-400">
                  Coordenadas
                </span>
                <button
                  type="button"
                  onClick={handleCopyCoords}
                  title="Copiar coordenadas exatas"
                  className="inline-flex items-center gap-1 font-mono tabular-nums text-slate-900 dark:text-slate-100 hover:text-blue-600 dark:hover:text-blue-400 transition-colors cursor-pointer"
                >
                  <span>{formatCoordinates(tracker.lat, tracker.lng)}</span>
                  {copiedCoords ? (
                    <Check className="w-3 h-3 text-emerald-600 dark:text-emerald-400" />
                  ) : (
                    <Copy className="w-3 h-3 text-slate-400" />
                  )}
                </button>
              </div>
              <div className="flex items-center justify-between gap-3">
                <span className="text-slate-500 dark:text-slate-400">
                  Precisão
                </span>
                <span
                  className={`font-mono tabular-nums ${
                    accuracyDiag.tier === 'high'
                      ? 'text-emerald-700 dark:text-emerald-400 font-medium'
                      : accuracyDiag.tier === 'moderate'
                        ? 'text-slate-900 dark:text-slate-100'
                        : 'text-amber-700 dark:text-amber-400'
                  }`}
                >
                  ±{formatDistance(tracker.accuracy)} · {accuracyDiag.shortLabel}
                </span>
              </div>
              <div className="flex items-center justify-between gap-3">
                <span className="text-slate-500 dark:text-slate-400">
                  Velocidade
                </span>
                <span className="font-mono tabular-nums text-slate-900 dark:text-slate-100">
                  {formatSpeedKmh(tracker.speed)}
                </span>
              </div>
              {batteryLevel !== null && (
                <div className="flex items-center justify-between gap-3">
                  <span className="text-slate-500 dark:text-slate-400">
                    Bateria
                  </span>
                  <span
                    className={`inline-flex items-center gap-1 font-mono tabular-nums ${
                      isLowBattery
                        ? 'text-red-700 dark:text-red-400 font-semibold'
                        : 'text-slate-900 dark:text-slate-100'
                    }`}
                  >
                    {renderBatteryIcon(batteryLevel, tracker.batteryCharging)}
                    {batteryLevel}%
                    {tracker.batteryCharging && (
                      <span className="font-sans text-[11px] text-emerald-700 dark:text-emerald-400">
                        (Carregando)
                      </span>
                    )}
                  </span>
                </div>
              )}
              <div className="flex items-center justify-between gap-3">
                <span className="text-slate-500 dark:text-slate-400">
                  Atualizado
                </span>
                <span className="text-slate-900 dark:text-slate-100">
                  {formatRelativeTimePt(tracker.lastSeenAt)}
                </span>
              </div>
              {tracker.heading > 0 && (
                <div className="flex items-center justify-between gap-3">
                  <span className="text-slate-500 dark:text-slate-400 inline-flex items-center gap-1">
                    <Compass className="w-3 h-3" /> Direção
                  </span>
                  <span className="font-mono tabular-nums text-slate-900 dark:text-slate-100">
                    {Math.round(tracker.heading)}°
                  </span>
                </div>
              )}
            </div>

            <div className="flex items-center gap-1.5 mt-3 pt-2 border-t border-slate-100 dark:border-slate-800">
              <button
                type="button"
                onClick={onRouteTo}
                className="flex-1 inline-flex items-center justify-center gap-1.5 px-2.5 py-1.5 bg-blue-600 text-white text-xs font-medium rounded-md hover:bg-blue-700 transition-colors cursor-pointer whitespace-nowrap"
              >
                <Navigation className="w-3.5 h-3.5" />
                Rota
              </button>
              <button
                type="button"
                onClick={onShareCode}
                title="Enviar código para outro app"
                className="inline-flex items-center justify-center gap-1 px-2.5 py-1.5 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 text-xs font-medium rounded-md hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors cursor-pointer whitespace-nowrap"
              >
                <Share2 className="w-3.5 h-3.5" />
                Enviar
              </button>
              <button
                type="button"
                onClick={onCenterMap}
                className="inline-flex items-center justify-center gap-1 px-2.5 py-1.5 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 text-xs font-medium rounded-md hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors cursor-pointer whitespace-nowrap"
              >
                <Crosshair className="w-3.5 h-3.5" />
                Focar
              </button>
            </div>
          </div>
        </InfoWindow>
      )}
    </>
  );
};
