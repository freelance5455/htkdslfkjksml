import React from 'react';
import {ShieldCheck, X} from 'lucide-react';

interface ConsentModalProps {
  trackerName: string;
  viewerCount: number;
  onConfirm: () => void;
  onCancel: () => void;
}

export const ConsentModal: React.FC<ConsentModalProps> = ({
  trackerName,
  viewerCount,
  onConfirm,
  onCancel,
}) => {
  return (
    <div
      className="fixed inset-0 z-50 bg-slate-950/55 dark:bg-black/70 backdrop-blur-xs flex items-center justify-center p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="consent-title"
    >
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl max-w-md w-full p-6 shadow-xl">
        <div className="flex items-start justify-between gap-3 mb-4">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-lg bg-blue-50 dark:bg-blue-950/80 text-blue-600 dark:text-blue-400 flex items-center justify-center shrink-0">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h2
                id="consent-title"
                className="text-base font-semibold text-slate-900 dark:text-slate-100"
              >
                Consentimento de localização ao vivo
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Rastreador: {trackerName}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onCancel}
            aria-label="Fechar"
            className="p-1 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="space-y-3 text-sm text-slate-600 dark:text-slate-300 leading-relaxed mb-6">
          <p>
            Ao ativar a transmissão, este navegador solicitará acesso ao seu GPS
            e enviará em tempo real sua latitude, longitude, precisão, direção e
            velocidade para o rastreador{' '}
            <strong className="text-slate-900 dark:text-slate-100">{trackerName}</strong>.
          </p>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Visualizadores autorizados atualmente: {viewerCount} · Você pode
            pausar ou revogar o compartilhamento a qualquer momento com um
            clique em &quot;Pausar GPS&quot;.
          </p>
        </div>

        <div className="flex items-center justify-end gap-2.5">
          <button
            type="button"
            onClick={onCancel}
            className="px-4 py-2 text-sm font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
          >
            Cancelar
          </button>
          <button
            type="button"
            onClick={onConfirm}
            className="px-4 py-2 text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
          >
            Autorizar e transmitir
          </button>
        </div>
      </div>
    </div>
  );
};
