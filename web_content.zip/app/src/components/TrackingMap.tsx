import React, {useCallback, useEffect, useMemo, useRef, useState} from 'react';
import {
  APILoadingStatus,
  AdvancedMarker,
  Circle,
  ColorScheme,
  InfoWindow,
  Map as GoogleMap,
  Polyline,
  useAdvancedMarkerRef,
  useApiLoadingStatus,
  useMap,
} from '@vis.gl/react-google-maps';
import {
  BatteryCharging,
  BatteryFull,
  BatteryLow,
  BatteryMedium,
  Car,
  Check,
  Compass,
  Copy,
  Crosshair,
  Footprints,
  Layers,
  Loader2,
  LocateFixed,
  MapPin,
  Menu,
  Moon,
  Navigation,
  Satellite,
  Siren,
  Sun,
  X,
} from 'lucide-react';
import {useReverseGeocode} from '../hooks/useReverseGeocode';
import {useSmoothPosition} from '../hooks/useSmoothPosition';
import {useWeather} from '../hooks/useWeather';
import {
  type AppTheme,
  type DeviceBatteryState,
  type Geofence,
  LOW_BATTERY_THRESHOLD,
  type MapVisualStyle,
  type RouteSummary,
  type SosEvent,
  type TrackPoint,
  type Tracker,
  type UserPositionState,
  formatCoordinates,
  formatDateTimePt,
  formatDistance,
  formatDurationPt,
  formatSpeedKmh,
} from '../types/tracking';
import {getAccuracyDiagnostic} from '../utils/locationPrecision';
import {PlaceSearchBox} from './PlaceSearchBox';
import {RouteOverlay} from './RouteOverlay';
import {TrackerMarker} from './TrackerMarker';
import {WeatherStrip} from './WeatherStrip';

export type MapPickMode =
  | {type: 'none'}
  | {type: 'move-tracker'; trackerId: string; trackerName: string}
  | {type: 'create-geofence'};

interface TrackingMapProps {
  theme: AppTheme;
  mapStyle: MapVisualStyle;
  onChangeMapStyle: (style: MapVisualStyle) => void;
  isMenuOpen: boolean;
  onOpenMenu: () => void;
  trackers: Tracker[];
  selectedTrackerId: string | null;
  selectedPoints: TrackPoint[];
  selectedHistoryPointId: string | null;
  onSelectHistoryPoint: (pointId: string | null) => void;
  geofences: Geofence[];
  sosEvents: SosEvent[];
  hasActiveOwnSos: boolean;
  userPosition: UserPositionState | null;
  deviceBattery?: DeviceBatteryState | null;
  locatingUser?: boolean;
  pickMode: MapPickMode;
  routeTargetTracker: Tracker | null;
  routeTravelMode: 'DRIVING' | 'WALKING';
  followSelected: boolean;
  focusRequest: {lat: number; lng: number; zoom?: number; nonce: number} | null;
  onSelectTracker: (trackerId: string) => void;
  onMapPickLocation: (coords: {lat: number; lng: number}) => void;
  onCancelPickMode: () => void;
  onStartRouteToTracker: (tracker: Tracker) => void;
  onShareTracker: (tracker: Tracker) => void;
  onOpenSos: (sos?: SosEvent) => void;
  onClearRoute: () => void;
  onChangeTravelMode: (mode: 'DRIVING' | 'WALKING') => void;
  onToggleFollow: () => void;
  onLocateMe: () => void;
}

const DEFAULT_CENTER = {lat: -23.55052, lng: -46.633308}; // São Paulo

function TrafficLayerControl({enabled}: {enabled: boolean}) {
  const map = useMap();
  const layerRef = useRef<google.maps.TrafficLayer | null>(null);

  useEffect(() => {
    if (!map) return;
    if (enabled) {
      const layer = new google.maps.TrafficLayer();
      layer.setMap(map);
      layerRef.current = layer;
    } else if (layerRef.current) {
      layerRef.current.setMap(null);
      layerRef.current = null;
    }
    return () => {
      if (layerRef.current) {
        layerRef.current.setMap(null);
        layerRef.current = null;
      }
    };
  }, [map, enabled]);

  return null;
}

function CameraController({
  trackers,
  userPosition,
  selectedTracker,
  followSelected,
  focusRequest,
}: {
  trackers: Tracker[];
  userPosition: UserPositionState | null;
  selectedTracker: Tracker | null;
  followSelected: boolean;
  focusRequest: {lat: number; lng: number; zoom?: number; nonce: number} | null;
}) {
  const map = useMap();
  const hasAutoFittedRef = useRef(false);
  const hasAutoCenteredUserRef = useRef(false);
  const lastCameraRef = useRef<{
    center: google.maps.LatLngLiteral;
    zoom: number;
  } | null>(null);

  // Preserve camera center & zoom across ColorScheme remounts (light <-> night)
  useEffect(() => {
    if (!map) return;

    if (lastCameraRef.current) {
      map.moveCamera({
        center: lastCameraRef.current.center,
        zoom: lastCameraRef.current.zoom,
      });
    }

    const listener = map.addListener('idle', () => {
      const center = map.getCenter();
      const zoom = map.getZoom();
      if (center && typeof zoom === 'number') {
        lastCameraRef.current = {
          center: {lat: center.lat(), lng: center.lng()},
          zoom,
        };
      }
    });

    return () => {
      google.maps.event.removeListener(listener);
    };
  }, [map]);

  useEffect(() => {
    if (!map || hasAutoFittedRef.current || trackers.length === 0) return;
    hasAutoFittedRef.current = true;

    if (trackers.length === 1) {
      map.panTo({lat: trackers[0].lat, lng: trackers[0].lng});
      map.setZoom(15);
      return;
    }

    const bounds = new google.maps.LatLngBounds();
    trackers.forEach((t) => bounds.extend({lat: t.lat, lng: t.lng}));
    if (userPosition) {
      bounds.extend({lat: userPosition.lat, lng: userPosition.lng});
    }
    map.fitBounds(bounds, 80);
  }, [map, trackers, userPosition]);

  useEffect(() => {
    if (
      !map ||
      hasAutoCenteredUserRef.current ||
      hasAutoFittedRef.current ||
      trackers.length > 0 ||
      !userPosition
    ) {
      return;
    }
    hasAutoCenteredUserRef.current = true;
    map.panTo({lat: userPosition.lat, lng: userPosition.lng});
    map.setZoom(15);
  }, [map, trackers.length, userPosition]);

  useEffect(() => {
    if (!map || !followSelected || !selectedTracker) return;
    map.panTo({lat: selectedTracker.lat, lng: selectedTracker.lng});
  }, [map, followSelected, selectedTracker?.lat, selectedTracker?.lng]);

  useEffect(() => {
    if (!map || !focusRequest) return;
    map.panTo({lat: focusRequest.lat, lng: focusRequest.lng});
    if (focusRequest.zoom) {
      map.setZoom(focusRequest.zoom);
    }
  }, [map, focusRequest]);

  return null;
}

export const TrackingMap: React.FC<TrackingMapProps> = ({
  theme,
  mapStyle,
  onChangeMapStyle,
  isMenuOpen,
  onOpenMenu,
  trackers,
  selectedTrackerId,
  selectedPoints,
  selectedHistoryPointId,
  onSelectHistoryPoint,
  geofences,
  sosEvents,
  hasActiveOwnSos,
  userPosition,
  deviceBattery,
  locatingUser = false,
  pickMode,
  routeTargetTracker,
  routeTravelMode,
  followSelected,
  focusRequest,
  onSelectTracker,
  onMapPickLocation,
  onCancelPickMode,
  onStartRouteToTracker,
  onShareTracker,
  onOpenSos,
  onClearRoute,
  onChangeTravelMode,
  onToggleFollow,
  onLocateMe,
}) => {
  const apiStatus = useApiLoadingStatus();
  const [infoOpenTrackerId, setInfoOpenTrackerId] = useState<string | null>(null);
  const [userInfoOpen, setUserInfoOpen] = useState(false);
  const [userMarkerRef, userMarker] = useAdvancedMarkerRef();
  const [showTraffic, setShowTraffic] = useState(false);
  const [routeSummary, setRouteSummary] = useState<RouteSummary | null>(null);
  const [routeError, setRouteError] = useState<string | null>(null);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const smoothUserCoords = useSmoothPosition(
    userPosition?.lat ?? DEFAULT_CENTER.lat,
    userPosition?.lng ?? DEFAULT_CENTER.lng,
    750
  );

  const handleCopyCoords = useCallback((key: string, lat: number, lng: number) => {
    void navigator.clipboard?.writeText(`${lat.toFixed(6)}, ${lng.toFixed(6)}`);
    setCopiedKey(key);
    window.setTimeout(() => setCopiedKey(null), 1600);
  }, []);

  const selectedTracker = useMemo(
    () => trackers.find((t) => t.id === selectedTrackerId) ?? null,
    [trackers, selectedTrackerId]
  );

  const trailPath = useMemo(() => {
    const pts = selectedPoints.map((p) => ({lat: p.lat, lng: p.lng}));
    if (selectedTracker) {
      pts.push({lat: selectedTracker.lat, lng: selectedTracker.lng});
    }
    return pts;
  }, [selectedPoints, selectedTracker]);

  const historyMarkerPoints = useMemo(() => {
    const recent = selectedPoints.slice(-60);
    if (
      selectedHistoryPointId &&
      !recent.some((p) => p.id === selectedHistoryPointId)
    ) {
      const target = selectedPoints.find((p) => p.id === selectedHistoryPointId);
      if (target) return [target, ...recent];
    }
    return recent;
  }, [selectedPoints, selectedHistoryPointId]);

  const selectedHistoryPoint = useMemo(
    () =>
      selectedHistoryPointId
        ? selectedPoints.find((p) => p.id === selectedHistoryPointId) ?? null
        : null,
    [selectedPoints, selectedHistoryPointId]
  );

  const userAddressInfo = useReverseGeocode(
    userPosition ? {lat: userPosition.lat, lng: userPosition.lng} : null,
    Boolean(userPosition && userInfoOpen)
  );

  const userWeatherInfo = useWeather(
    userPosition ? {lat: userPosition.lat, lng: userPosition.lng} : null,
    Boolean(userPosition)
  );

  const historyAddressInfo = useReverseGeocode(
    selectedHistoryPoint
      ? {lat: selectedHistoryPoint.lat, lng: selectedHistoryPoint.lng}
      : null,
    Boolean(selectedHistoryPoint && !selectedHistoryPoint.address)
  );

  const historyWeatherInfo = useWeather(
    selectedHistoryPoint
      ? {lat: selectedHistoryPoint.lat, lng: selectedHistoryPoint.lng}
      : null,
    Boolean(selectedHistoryPoint)
  );

  const activeSosEvents = useMemo(
    () => sosEvents.filter((s) => s.status === 'active'),
    [sosEvents]
  );

  const routeOrigin = useMemo(() => {
    if (userPosition) return {lat: userPosition.lat, lng: userPosition.lng};
    if (selectedTracker && routeTargetTracker && selectedTracker.id !== routeTargetTracker.id) {
      return {lat: selectedTracker.lat, lng: selectedTracker.lng};
    }
    return null;
  }, [userPosition, selectedTracker, routeTargetTracker]);

  const handleMapClick = useCallback(
    (ev: {detail: {latLng: google.maps.LatLngLiteral | null}}) => {
      if (pickMode.type === 'none' || !ev.detail.latLng) return;
      onMapPickLocation(ev.detail.latLng);
    },
    [pickMode, onMapPickLocation]
  );

  useEffect(() => {
    if (!routeTargetTracker) {
      setRouteSummary(null);
      setRouteError(null);
    }
  }, [routeTargetTracker]);

  const mapTypeId = mapStyle === 'satellite' ? 'hybrid' : 'roadmap';
  const colorScheme =
    mapStyle === 'night' || (mapStyle === 'satellite' && theme === 'dark')
      ? ColorScheme.DARK
      : ColorScheme.LIGHT;

  if (
    apiStatus === APILoadingStatus.FAILED ||
    apiStatus === APILoadingStatus.AUTH_FAILURE
  ) {
    return (
      <div className="h-full w-full flex items-center justify-center bg-slate-100 dark:bg-slate-950 p-6">
        <div className="max-w-md bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 text-center shadow-sm">
          <MapPin className="w-8 h-8 text-red-600 dark:text-red-400 mx-auto mb-3" />
          <h3 className="text-base font-semibold text-slate-900 dark:text-slate-100 mb-1">
            Não foi possível carregar o Google Maps
          </h3>
          <p className="text-sm text-slate-600 dark:text-slate-300">
            Verifique a chave da API do Google Maps Platform ou o limite de cota da conta.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="relative w-full h-full min-h-[360px]">
      <GoogleMap
        mapId="DEMO_MAP_ID"
        defaultCenter={DEFAULT_CENTER}
        defaultZoom={13}
        gestureHandling="greedy"
        disableDefaultUI={false}
        streetViewControl={false}
        mapTypeControl={false}
        fullscreenControl={false}
        mapTypeId={mapTypeId}
        colorScheme={colorScheme}
        onClick={handleMapClick}
        internalUsageAttributionIds={['gmp_mcp_codeassist_v1_aistudio']}
        className="w-full h-full"
      >
        <CameraController
          trackers={trackers}
          userPosition={userPosition}
          selectedTracker={selectedTracker}
          followSelected={followSelected}
          focusRequest={focusRequest}
        />

        <TrafficLayerControl enabled={showTraffic} />

        {/* Geofences */}
        {geofences
          .filter((g) => g.active)
          .map((fence) => (
            <Circle
              key={fence.id}
              center={{lat: fence.lat, lng: fence.lng}}
              radius={fence.radiusMeters}
              strokeColor={fence.color}
              strokeOpacity={0.85}
              strokeWeight={2}
              fillColor={fence.color}
              fillOpacity={0.12}
              clickable={pickMode.type !== 'none'}
            />
          ))}

        {/* Accuracy circle for user's current position */}
        {userPosition && (
          <Circle
            center={smoothUserCoords}
            radius={Math.max(4, Math.min(userPosition.accuracy || 15, 2000))}
            strokeColor="#2563EB"
            strokeOpacity={0.5}
            strokeWeight={1.5}
            fillColor="#3B82F6"
            fillOpacity={0.12}
            clickable={false}
          />
        )}

        {/* Accuracy circle for selected tracker */}
        {selectedTracker && selectedTracker.accuracy > 0 && (
          <Circle
            center={{lat: selectedTracker.lat, lng: selectedTracker.lng}}
            radius={Math.max(4, Math.min(selectedTracker.accuracy, 2000))}
            strokeColor={selectedTracker.color}
            strokeOpacity={0.4}
            strokeWeight={1.25}
            fillColor={selectedTracker.color}
            fillOpacity={0.09}
            clickable={false}
          />
        )}

        {/* Trail polyline for selected tracker */}
        {selectedTracker && trailPath.length >= 2 && (
          <Polyline
            path={trailPath}
            strokeColor={selectedTracker.color}
            strokeOpacity={0.85}
            strokeWeight={3.5}
            geodesic
          />
        )}

        {/* Clickable location history points */}
        {selectedTracker &&
          historyMarkerPoints.map((pt) => {
            const isActivePoint = pt.id === selectedHistoryPointId;
            const isSosPoint = Boolean(pt.isSos || pt.source === 'sos');
            return (
              <AdvancedMarker
                key={pt.id}
                position={{lat: pt.lat, lng: pt.lng}}
                onClick={() => {
                  setInfoOpenTrackerId(null);
                  setUserInfoOpen(false);
                  onSelectHistoryPoint(isActivePoint ? null : pt.id);
                }}
                title={`${isSosPoint ? '🚨 SOS · ' : ''}${formatDateTimePt(pt.recordedAt)} · ${formatSpeedKmh(pt.speed)}`}
                zIndex={isActivePoint ? 55 : isSosPoint ? 40 : 25}
              >
                <div
                  className={`rounded-full border-2 border-white dark:border-slate-900 shadow-sm cursor-pointer transition-transform ${
                    isActivePoint
                      ? 'w-4 h-4 scale-125 ring-2 ring-blue-500'
                      : isSosPoint
                        ? 'w-3.5 h-3.5 ring-2 ring-red-500/60 hover:scale-125'
                        : 'w-2.5 h-2.5 hover:scale-125'
                  }`}
                  style={{
                    backgroundColor: isSosPoint ? '#DC2626' : selectedTracker.color,
                  }}
                />
              </AdvancedMarker>
            );
          })}

        {selectedTracker && selectedHistoryPoint && (
          <InfoWindow
            position={{
              lat: selectedHistoryPoint.lat,
              lng: selectedHistoryPoint.lng,
            }}
            onCloseClick={() => onSelectHistoryPoint(null)}
            maxWidth={310}
          >
            <div className="p-2 rounded-lg bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 min-w-[240px]">
              <div className="flex items-center justify-between gap-2">
                <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100 leading-tight">
                  {selectedTracker.name}
                </h3>
                {(selectedHistoryPoint.isSos ||
                  selectedHistoryPoint.source === 'sos') && (
                  <span className="px-1.5 py-0.5 rounded bg-red-600 text-white text-[10px] font-bold">
                    SOS
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 tabular-nums">
                {formatDateTimePt(selectedHistoryPoint.recordedAt)} ·{' '}
                {selectedHistoryPoint.source === 'sos'
                  ? 'SOS'
                  : selectedHistoryPoint.source === 'gps'
                    ? 'GPS'
                    : 'Manual'}
              </p>

              {(selectedHistoryPoint.address ||
                historyAddressInfo.address ||
                historyAddressInfo.placeName ||
                historyAddressInfo.isLoading) && (
                <div className="mt-2 flex items-start gap-1.5 text-xs text-slate-600 dark:text-slate-300 bg-slate-50 dark:bg-slate-800/70 border border-slate-100 dark:border-slate-800 rounded-md px-2 py-1.5">
                  <MapPin className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400 shrink-0 mt-0.5" />
                  <span className="leading-snug">
                    {selectedHistoryPoint.address
                      ? selectedHistoryPoint.address
                      : historyAddressInfo.isLoading
                        ? 'Identificando endereço exato...'
                        : historyAddressInfo.placeName &&
                            historyAddressInfo.address
                          ? `${historyAddressInfo.placeName} — ${historyAddressInfo.address}`
                          : historyAddressInfo.address ||
                            historyAddressInfo.placeName}
                  </span>
                </div>
              )}

              {typeof selectedHistoryPoint.weatherTempC === 'number' ? (
                <div className="mt-2 px-2.5 py-1.5 rounded-md bg-sky-50/75 dark:bg-sky-950/40 border border-sky-200/80 dark:border-sky-900/70 text-xs text-slate-700 dark:text-slate-200 tabular-nums">
                  <span className="font-semibold">
                    {Math.round(selectedHistoryPoint.weatherTempC)}°C
                  </span>
                  {selectedHistoryPoint.weatherCondition &&
                    ` · ${selectedHistoryPoint.weatherCondition}`}
                  {typeof selectedHistoryPoint.weatherHumidity === 'number' &&
                    ` · ${Math.round(selectedHistoryPoint.weatherHumidity)}% umid.`}
                  {typeof selectedHistoryPoint.weatherWindKmh === 'number' &&
                    ` · ${Math.round(selectedHistoryPoint.weatherWindKmh)} km/h`}
                </div>
              ) : (
                <WeatherStrip
                  weather={historyWeatherInfo.weather}
                  isLoading={historyWeatherInfo.isLoading}
                />
              )}

              <div className="border-t border-slate-100 dark:border-slate-800 pt-2 mt-2 space-y-1 text-xs text-slate-600 dark:text-slate-300">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-slate-500 dark:text-slate-400">
                    Coordenadas
                  </span>
                  <button
                    type="button"
                    onClick={() =>
                      handleCopyCoords(
                        `hist-${selectedHistoryPoint.id}`,
                        selectedHistoryPoint.lat,
                        selectedHistoryPoint.lng
                      )
                    }
                    className="inline-flex items-center gap-1 font-mono tabular-nums text-slate-900 dark:text-slate-100 hover:text-blue-600 dark:hover:text-blue-400 transition-colors cursor-pointer"
                  >
                    <span>
                      {formatCoordinates(
                        selectedHistoryPoint.lat,
                        selectedHistoryPoint.lng
                      )}
                    </span>
                    {copiedKey === `hist-${selectedHistoryPoint.id}` ? (
                      <Check className="w-3 h-3 text-emerald-600 dark:text-emerald-400" />
                    ) : (
                      <Copy className="w-3 h-3 text-slate-400" />
                    )}
                  </button>
                </div>
                <div className="flex items-center justify-between gap-3">
                  <span className="text-slate-500 dark:text-slate-400">
                    Velocidade
                  </span>
                  <span className="font-mono tabular-nums text-slate-900 dark:text-slate-100">
                    {formatSpeedKmh(selectedHistoryPoint.speed)}
                  </span>
                </div>
                <div className="flex items-center justify-between gap-3">
                  <span className="text-slate-500 dark:text-slate-400">
                    Precisão
                  </span>
                  <span className="font-mono tabular-nums text-slate-900 dark:text-slate-100">
                    ±{formatDistance(selectedHistoryPoint.accuracy)} ·{' '}
                    {getAccuracyDiagnostic(selectedHistoryPoint.accuracy).shortLabel}
                  </span>
                </div>
                {typeof selectedHistoryPoint.altitude === 'number' && (
                  <div className="flex items-center justify-between gap-3">
                    <span className="text-slate-500 dark:text-slate-400">
                      Altitude
                    </span>
                    <span className="font-mono tabular-nums text-slate-900 dark:text-slate-100">
                      {Math.round(selectedHistoryPoint.altitude)} m
                    </span>
                  </div>
                )}
                {typeof selectedHistoryPoint.batteryLevel === 'number' && (
                  <div className="flex items-center justify-between gap-3">
                    <span className="text-slate-500 dark:text-slate-400">
                      Bateria
                    </span>
                    <span className="font-mono tabular-nums text-slate-900 dark:text-slate-100">
                      {Math.round(selectedHistoryPoint.batteryLevel)}%
                      {selectedHistoryPoint.batteryCharging ? ' (Carregando)' : ''}
                    </span>
                  </div>
                )}
                {typeof selectedHistoryPoint.distanceFromPrevMeters === 'number' && (
                  <div className="flex items-center justify-between gap-3">
                    <span className="text-slate-500 dark:text-slate-400">
                      Deslocamento
                    </span>
                    <span className="font-mono tabular-nums text-slate-900 dark:text-slate-100">
                      +{formatDistance(selectedHistoryPoint.distanceFromPrevMeters)}
                    </span>
                  </div>
                )}
              </div>
            </div>
          </InfoWindow>
        )}

        {/* Active SOS Emergency Map Markers */}
        {activeSosEvents.map((sos) => (
          <AdvancedMarker
            key={sos.id}
            position={{lat: sos.lat, lng: sos.lng}}
            onClick={() => onOpenSos(sos)}
            title={`SOS ATIVO: ${sos.ownerName}`}
            zIndex={80}
          >
            <div className="relative flex flex-col items-center cursor-pointer select-none">
              <span className="absolute -inset-2.5 rounded-full bg-red-600/35 animate-ping pointer-events-none" />
              <div className="relative w-10 h-10 rounded-full bg-red-600 border-2 border-white shadow-lg flex items-center justify-center text-white">
                <Siren className="w-5 h-5" />
              </div>
              <div className="mt-1 px-2 py-0.5 rounded bg-red-700 text-white text-[11px] font-bold whitespace-nowrap shadow">
                SOS · {sos.ownerName.split(' ')[0]}
              </div>
            </div>
          </AdvancedMarker>
        ))}

        {/* User's own current location marker */}
        {userPosition && (
          <AdvancedMarker
            ref={userMarkerRef}
            position={smoothUserCoords}
            onClick={() => {
              setInfoOpenTrackerId(null);
              setUserInfoOpen((prev) => !prev);
            }}
            title="Sua localização atual"
            zIndex={60}
          >
            <div className="relative flex flex-col items-center cursor-pointer select-none">
              <div className="relative flex items-center justify-center w-7 h-7">
                <span className="absolute inset-0 rounded-full bg-blue-500/30 animate-ping pointer-events-none" />
                <span className="absolute inset-0.5 rounded-full bg-blue-500/20 pointer-events-none" />
                {typeof userPosition.heading === 'number' &&
                  userPosition.heading > 0 &&
                  (userPosition.speed ?? 0) >= 0.4 && (
                    <div
                      aria-hidden="true"
                      className="absolute inset-0 flex items-start justify-center pointer-events-none"
                      style={{transform: `rotate(${userPosition.heading}deg)`}}
                    >
                      <span className="-mt-1.5 w-0 h-0 border-l-[4px] border-l-transparent border-r-[4px] border-r-transparent border-b-[7px] border-b-blue-600" />
                    </div>
                  )}
                <span className="relative w-4 h-4 rounded-full bg-blue-600 border-2 border-white shadow-md" />
              </div>
              <div className="mt-1 px-2 py-0.5 rounded bg-blue-700 text-white text-[11px] font-medium whitespace-nowrap shadow-sm flex items-center gap-1">
                <span>Você</span>
                {userWeatherInfo.weather && (
                  <span className="font-mono tabular-nums text-sky-200">
                    · {Math.round(userWeatherInfo.weather.temperatureC)}°C
                  </span>
                )}
              </div>
            </div>
          </AdvancedMarker>
        )}

        {userPosition && userInfoOpen && userMarker && (
          <InfoWindow
            anchor={userMarker}
            onCloseClick={() => setUserInfoOpen(false)}
            maxWidth={310}
          >
            <div className="p-2 rounded-lg bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 min-w-[235px]">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100 leading-tight">
                    Sua localização atual
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                    {getAccuracyDiagnostic(userPosition.accuracy).label}
                  </p>
                </div>
              </div>

              {(userAddressInfo.address ||
                userAddressInfo.placeName ||
                userAddressInfo.isLoading) && (
                <div className="mt-2 flex items-start gap-1.5 text-xs text-slate-600 dark:text-slate-300 bg-slate-50 dark:bg-slate-800/70 border border-slate-100 dark:border-slate-800 rounded-md px-2 py-1.5">
                  <MapPin className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400 shrink-0 mt-0.5" />
                  <span className="leading-snug">
                    {userAddressInfo.isLoading
                      ? 'Identificando endereço exato...'
                      : userAddressInfo.placeName && userAddressInfo.address
                        ? `${userAddressInfo.placeName} — ${userAddressInfo.address}`
                        : userAddressInfo.address || userAddressInfo.placeName}
                  </span>
                </div>
              )}

              <WeatherStrip
                weather={userWeatherInfo.weather}
                isLoading={userWeatherInfo.isLoading}
              />

              <div className="border-t border-slate-100 dark:border-slate-800 pt-2 mt-2 space-y-1 text-xs text-slate-600 dark:text-slate-300">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-slate-500 dark:text-slate-400">
                    Coordenadas
                  </span>
                  <button
                    type="button"
                    onClick={() =>
                      handleCopyCoords(
                        'user-self',
                        userPosition.lat,
                        userPosition.lng
                      )
                    }
                    className="inline-flex items-center gap-1 font-mono tabular-nums text-slate-900 dark:text-slate-100 hover:text-blue-600 dark:hover:text-blue-400 transition-colors cursor-pointer"
                  >
                    <span>
                      {formatCoordinates(userPosition.lat, userPosition.lng)}
                    </span>
                    {copiedKey === 'user-self' ? (
                      <Check className="w-3 h-3 text-emerald-600 dark:text-emerald-400" />
                    ) : (
                      <Copy className="w-3 h-3 text-slate-400" />
                    )}
                  </button>
                </div>
                <div className="flex items-center justify-between gap-3">
                  <span className="text-slate-500 dark:text-slate-400">
                    Precisão
                  </span>
                  <span
                    className={`font-mono tabular-nums ${
                      getAccuracyDiagnostic(userPosition.accuracy).tier ===
                      'high'
                        ? 'text-emerald-700 dark:text-emerald-400 font-medium'
                        : getAccuracyDiagnostic(userPosition.accuracy).tier ===
                            'moderate'
                          ? 'text-slate-900 dark:text-slate-100'
                          : 'text-amber-700 dark:text-amber-400'
                    }`}
                  >
                    ±{formatDistance(userPosition.accuracy)}
                  </span>
                </div>
                {typeof userPosition.altitude === 'number' && (
                  <div className="flex items-center justify-between gap-3">
                    <span className="text-slate-500 dark:text-slate-400">
                      Altitude
                    </span>
                    <span className="font-mono tabular-nums text-slate-900 dark:text-slate-100">
                      {Math.round(userPosition.altitude)} m
                    </span>
                  </div>
                )}
                {deviceBattery && (
                  <div className="flex items-center justify-between gap-3">
                    <span className="text-slate-500 dark:text-slate-400">
                      Bateria
                    </span>
                    <span
                      className={`inline-flex items-center gap-1 font-mono tabular-nums ${
                        deviceBattery.level < LOW_BATTERY_THRESHOLD
                          ? 'text-red-700 dark:text-red-400 font-semibold'
                          : 'text-slate-900 dark:text-slate-100'
                      }`}
                    >
                      {deviceBattery.charging ? (
                        <BatteryCharging className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                      ) : deviceBattery.level < LOW_BATTERY_THRESHOLD ? (
                        <BatteryLow className="w-3.5 h-3.5 text-red-600 dark:text-red-400" />
                      ) : deviceBattery.level < 60 ? (
                        <BatteryMedium className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
                      ) : (
                        <BatteryFull className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                      )}
                      {deviceBattery.level}%
                    </span>
                  </div>
                )}
              </div>

              <div className="mt-3 pt-2 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={onLocateMe}
                  disabled={locatingUser}
                  className="w-full inline-flex items-center justify-center gap-1.5 px-2.5 py-1.5 bg-blue-600 hover:bg-blue-700 disabled:opacity-60 text-white text-xs font-medium rounded-md transition-colors cursor-pointer"
                >
                  <Crosshair className="w-3.5 h-3.5" />
                  {locatingUser ? 'Calibrando GPS...' : 'Calibrar precisão GPS'}
                </button>
              </div>
            </div>
          </InfoWindow>
        )}

        {/* Live Tracker Markers */}
        {trackers.map((tracker) => (
          <TrackerMarker
            key={tracker.id}
            tracker={tracker}
            isSelected={tracker.id === selectedTrackerId}
            isInfoOpen={infoOpenTrackerId === tracker.id}
            onSelect={() => {
              setUserInfoOpen(false);
              onSelectTracker(tracker.id);
              setInfoOpenTrackerId(tracker.id);
            }}
            onCloseInfo={() => setInfoOpenTrackerId(null)}
            onCenterMap={() => {
              onSelectTracker(tracker.id);
            }}
            onRouteTo={() => {
              setInfoOpenTrackerId(null);
              onStartRouteToTracker(tracker);
            }}
            onShareCode={() => {
              setInfoOpenTrackerId(null);
              onShareTracker(tracker);
            }}
          />
        ))}

        {/* Route Overlay (Routes API) */}
        {routeTargetTracker && routeOrigin && (
          <RouteOverlay
            origin={routeOrigin}
            destination={{
              lat: routeTargetTracker.lat,
              lng: routeTargetTracker.lng,
            }}
            targetTrackerId={routeTargetTracker.id}
            targetTrackerName={routeTargetTracker.name}
            travelMode={routeTravelMode}
            onRouteComputed={setRouteSummary}
            onRouteError={setRouteError}
          />
        )}
      </GoogleMap>

      {/* Top Left: Menu Toggle + Place Autocomplete Search + Pick Mode Banner */}
      <div className="absolute top-4 left-4 right-4 sm:right-auto z-20 flex flex-col gap-2.5 pointer-events-none">
        <div className="pointer-events-auto flex items-center gap-2">
          <button
            type="button"
            onClick={onOpenMenu}
            aria-expanded={isMenuOpen}
            aria-label="Abrir menu lateral"
            className="inline-flex items-center gap-2 h-[42px] px-3.5 bg-white/95 dark:bg-slate-900/95 backdrop-blur-sm border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 hover:bg-slate-50 dark:hover:bg-slate-800 rounded-lg shadow-sm text-sm font-medium transition-colors cursor-pointer whitespace-nowrap shrink-0"
          >
            <Menu className="w-4 h-4 text-blue-600 dark:text-blue-400" />
            <span>Menu</span>
          </button>

          <div className="flex-1 min-w-0 sm:w-64 md:w-72">
            <PlaceSearchBox />
          </div>
        </div>

        {pickMode.type !== 'none' && (
          <div className="pointer-events-auto bg-slate-900 dark:bg-slate-800 text-white px-3.5 py-2.5 rounded-lg shadow-lg border border-transparent dark:border-slate-700 flex items-center justify-between gap-3 max-w-sm">
            <div className="text-xs leading-snug">
              {pickMode.type === 'move-tracker' ? (
                <>
                  Clique no mapa para atualizar a posição de{' '}
                  <strong className="font-semibold">{pickMode.trackerName}</strong>
                </>
              ) : (
                <>Clique no mapa para definir o centro da nova cerca virtual</>
              )}
            </div>
            <button
              type="button"
              onClick={onCancelPickMode}
              className="px-2 py-1 text-xs font-medium bg-white/15 hover:bg-white/25 rounded transition-colors cursor-pointer whitespace-nowrap shrink-0"
            >
              Cancelar
            </button>
          </div>
        )}
      </div>

      {/* Top Right: Map Visual Style & Layers Toolbar */}
      <div className="absolute top-4 right-4 z-20 hidden sm:flex items-center gap-2">
        <div className="flex items-center bg-white/95 dark:bg-slate-900/95 backdrop-blur-sm border border-slate-200 dark:border-slate-700 rounded-lg p-1 shadow-sm">
          <button
            type="button"
            onClick={() => onChangeMapStyle('light')}
            className={`inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer whitespace-nowrap ${
              mapStyle === 'light'
                ? 'bg-slate-900 dark:bg-blue-600 text-white'
                : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <Sun className="w-3.5 h-3.5" />
            Claro
          </button>
          <button
            type="button"
            onClick={() => onChangeMapStyle('night')}
            className={`inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer whitespace-nowrap ${
              mapStyle === 'night'
                ? 'bg-slate-900 dark:bg-blue-600 text-white'
                : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <Moon className="w-3.5 h-3.5" />
            Noturno
          </button>
          <button
            type="button"
            onClick={() => onChangeMapStyle('satellite')}
            className={`inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer whitespace-nowrap ${
              mapStyle === 'satellite'
                ? 'bg-slate-900 dark:bg-blue-600 text-white'
                : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <Satellite className="w-3.5 h-3.5" />
            Satélite
          </button>
        </div>

        <button
          type="button"
          onClick={() => setShowTraffic((prev) => !prev)}
          className={`inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg border shadow-sm transition-colors cursor-pointer whitespace-nowrap ${
            showTraffic
              ? 'bg-blue-600 text-white border-blue-600'
              : 'bg-white/95 dark:bg-slate-900/95 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800'
          }`}
        >
          <Layers className="w-3.5 h-3.5" />
          Tráfego
        </button>
      </div>

      {/* Bottom Left: Route Summary Card */}
      {routeTargetTracker && (
        <div className="absolute bottom-5 left-4 z-20 bg-white/95 dark:bg-slate-900/95 backdrop-blur-sm border border-slate-200 dark:border-slate-700 rounded-xl p-3.5 shadow-lg max-w-xs w-[calc(100%-5rem)] sm:w-auto">
          <div className="flex items-start justify-between gap-3 mb-2">
            <div>
              <p className="text-xs text-slate-500 dark:text-slate-400">Rota até</p>
              <h4 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                {routeTargetTracker.name}
              </h4>
            </div>
            <button
              type="button"
              onClick={onClearRoute}
              aria-label="Fechar rota"
              className="p-1 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {!routeOrigin ? (
            <p className="text-xs text-amber-700 dark:text-amber-300 bg-amber-50 dark:bg-amber-950/60 border border-amber-200 dark:border-amber-900 rounded-md px-2.5 py-2">
              Ative sua localização GPS ou selecione outro rastreador como origem para traçar a rota.
            </p>
          ) : routeError ? (
            <p className="text-xs text-red-600 dark:text-red-400">{routeError}</p>
          ) : routeSummary ? (
            <div className="flex items-center justify-between gap-4 pt-1">
              <div className="flex items-baseline gap-2">
                <span className="text-base font-semibold font-mono tabular-nums text-slate-900 dark:text-slate-100">
                  {formatDurationPt(routeSummary.durationMillis)}
                </span>
                <span className="text-xs font-mono tabular-nums text-slate-500 dark:text-slate-400">
                  · {formatDistance(routeSummary.distanceMeters)}
                </span>
              </div>

              <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-0.5 rounded-md">
                <button
                  type="button"
                  onClick={() => onChangeTravelMode('DRIVING')}
                  aria-label="Modo carro"
                  className={`p-1.5 rounded transition-colors cursor-pointer ${
                    routeTravelMode === 'DRIVING'
                      ? 'bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 shadow-sm'
                      : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100'
                  }`}
                >
                  <Car className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() => onChangeTravelMode('WALKING')}
                  aria-label="Modo a pé"
                  className={`p-1.5 rounded transition-colors cursor-pointer ${
                    routeTravelMode === 'WALKING'
                      ? 'bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 shadow-sm'
                      : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100'
                  }`}
                >
                  <Footprints className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ) : (
            <p className="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
              <Navigation className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
              Calculando melhor trajeto...
            </p>
          )}
        </div>
      )}

      {/* Bottom Right: SOS Emergency + Follow & Locate Controls */}
      <div className="absolute bottom-5 right-4 z-20 flex flex-col items-end gap-2">
        <button
          type="button"
          onClick={() => onOpenSos()}
          title="Botão de Emergência SOS com localização ao vivo, câmera e microfone"
          className={`inline-flex items-center justify-center gap-1.5 px-3.5 py-2.5 text-xs font-bold rounded-xl border shadow-lg transition-colors cursor-pointer whitespace-nowrap ${
            hasActiveOwnSos
              ? 'bg-red-600 text-white border-red-400 animate-pulse'
              : 'bg-red-600 hover:bg-red-700 text-white border-red-700'
          }`}
        >
          <Siren className="w-4 h-4" />
          <span>{hasActiveOwnSos ? 'SOS AO VIVO' : 'SOS'}</span>
        </button>

        {selectedTracker && (
          <button
            type="button"
            onClick={onToggleFollow}
            title={
              followSelected
                ? 'Desativar acompanhamento automático'
                : 'Acompanhar rastreador selecionado'
            }
            className={`inline-flex items-center gap-1.5 px-3 py-2.5 text-xs font-medium rounded-lg border shadow-sm transition-colors cursor-pointer whitespace-nowrap ${
              followSelected
                ? 'bg-blue-600 text-white border-blue-600'
                : 'bg-white/95 dark:bg-slate-900/95 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800'
            }`}
          >
            <Compass className="w-4 h-4" />
            <span className="hidden sm:inline">
              {followSelected ? 'Seguindo' : 'Seguir'}
            </span>
          </button>
        )}

        <button
          type="button"
          onClick={onLocateMe}
          disabled={locatingUser}
          title="Centralizar na minha localização atual"
          className="inline-flex items-center justify-center gap-1.5 px-3 py-2.5 bg-white/95 dark:bg-slate-900/95 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 rounded-lg shadow-sm hover:bg-slate-50 dark:hover:bg-slate-800 disabled:opacity-70 transition-colors cursor-pointer text-xs font-medium whitespace-nowrap"
        >
          {locatingUser ? (
            <Loader2 className="w-4 h-4 text-blue-600 dark:text-blue-400 animate-spin" />
          ) : (
            <LocateFixed className="w-4 h-4 text-blue-600 dark:text-blue-400" />
          )}
          <span className="hidden sm:inline">
            {locatingUser ? 'Localizando...' : 'Minha posição'}
          </span>
        </button>
      </div>
    </div>
  );
};
