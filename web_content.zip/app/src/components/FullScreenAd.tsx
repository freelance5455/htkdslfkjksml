import { useEffect, useState } from "react";
import { X, Megaphone } from "lucide-react";

const CREATIVES = [
  {
    title: "Galaxy Raiders",
    sub: "Play the #1 space strategy game — free today",
    bg: "from-indigo-600 via-purple-600 to-fuchsia-500",
    cta: "Install Now",
  },
  {
    title: "ZenFit Pro",
    sub: "7-minute workouts. Lifetime results.",
    bg: "from-emerald-500 via-teal-600 to-cyan-600",
    cta: "Try Free",
  },
  {
    title: "CryptoTrack",
    sub: "All your portfolios. One clean dashboard.",
    bg: "from-amber-500 via-orange-600 to-rose-600",
    cta: "Download",
  },
  {
    title: "LingoLeap",
    sub: "Speak a new language in 30 days",
    bg: "from-sky-500 via-blue-600 to-violet-600",
    cta: "Start Lesson",
  },
];

type Props = {
  adUnitId: string;
  onClose: () => void;
};

export default function FullScreenAd({ adUnitId, onClose }: Props) {
  const DURATION = 5;
  const [left, setLeft] = useState(DURATION);
  const creative = CREATIVES[Math.floor(Math.random() * CREATIVES.length)];

  useEffect(() => {
    if (left <= 0) return;
    const t = setTimeout(() => setLeft((s) => s - 1), 1000);
    return () => clearTimeout(t);
  }, [left]);

  return (
    <div className="fixed inset-0 z-[100] flex flex-col bg-black">
      {/* top bar */}
      <div className="flex items-center justify-between px-4 py-3 pt-[max(0.75rem,env(safe-area-inset-top))]">
        <span className="rounded bg-white/15 px-2 py-0.5 text-[11px] font-medium tracking-wide text-white/80">
          Advertisement
        </span>
        <button
          onClick={onClose}
          disabled={left > 0}
          className="flex h-11 w-11 items-center justify-center rounded-full bg-white/15 text-white transition disabled:opacity-40"
          aria-label="Close ad"
        >
          {left > 0 ? <span className="text-sm font-bold tabular-nums">{left}</span> : <X className="h-5 w-5" />}
        </button>
      </div>

      {/* creative */}
      <div className={`m-4 flex flex-1 flex-col items-center justify-center gap-4 rounded-3xl bg-gradient-to-br ${creative.bg} p-8 text-center shadow-2xl`}>
        <div className="flex h-20 w-20 items-center justify-center rounded-2xl bg-white/20 backdrop-blur">
          <Megaphone className="h-10 w-10 text-white" />
        </div>
        <h2 className="text-3xl font-extrabold text-white drop-shadow">{creative.title}</h2>
        <p className="max-w-xs text-white/85">{creative.sub}</p>
        <button className="mt-2 min-h-11 rounded-full bg-white px-8 py-3 font-bold text-gray-900 shadow-lg active:scale-95">
          {creative.cta}
        </button>
      </div>

      <p className="px-4 pb-[max(0.75rem,env(safe-area-inset-bottom))] text-center text-[10px] text-white/40">
        Ad unit: {adUnitId} · Served via AppLovin MAX
      </p>
    </div>
  );
}
