import {Capacitor} from '@capacitor/core';

/** true quando a app corre dentro do APK Android (Capacitor) */
export const isNative = Capacitor.isNativePlatform();
