package com.mizoq.tiktoktoolkit

import com.mizoq.tiktoktoolkit.config.MizoBrandConfig
import com.mizoq.tiktoktoolkit.data.export.CsvExportManager
import com.mizoq.tiktoktoolkit.data.local.ActionHistoryEntity
import com.mizoq.tiktoktoolkit.data.local.QueueItemEntity
import com.mizoq.tiktoktoolkit.domain.engine.EligibilityEvaluator
import com.mizoq.tiktoktoolkit.domain.model.DiscoveredAccount
import com.mizoq.tiktoktoolkit.domain.model.MutualStatus
import com.mizoq.tiktoktoolkit.domain.model.RelationshipState
import com.mizoq.tiktoktoolkit.domain.model.SessionSettings
import com.mizoq.tiktoktoolkit.domain.model.WorkflowMode
import com.mizoq.tiktoktoolkit.service.accessibility.TikTokNodeScanner
import com.mizoq.tiktoktoolkit.service.accessibility.VirtualAccessibilityNode
import com.mizoq.tiktoktoolkit.service.overlay.OverlayPositionController
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * JUnit 4 unit test suite for Mizo_q TikTok Toolkit — Unfollow Manager V6.0.
 * Verifies central branding, mutual-friend protection, Accessibility tree scanning,
 * button ownership verification, CAPTCHA detection, overlay bounds clamping, and
 * 10,000-entry RFC 4180 UTF-8 BOM CSV generation.
 */
class MizoToolkitUnitTest {

    @Test
    fun testCentralBrandingConfig() {
        assertEquals("Mizo_q", MizoBrandConfig.BRAND_NAME)
        assertEquals("Mizo_q TikTok Toolkit", MizoBrandConfig.PRODUCT_TITLE)
        assertEquals("Unfollow Manager V6.0", MizoBrandConfig.PRODUCT_SUBTITLE)
        assertEquals(10_000, MizoBrandConfig.MAX_SESSION_LIMIT)
        assertTrue(MizoBrandConfig.OFFICIAL_TIKTOK_PACKAGES.contains("com.zhiliaoapp.musically"))
        assertTrue(MizoBrandConfig.OFFICIAL_TIKTOK_PACKAGES.contains("com.ss.android.ugc.trill"))
    }

    @Test
    fun testMutualProtectionAndDisplayNameRejection() {
        val mutualFriend = DiscoveredAccount(
            username = "luna.starlight",
            displayName = "Luna Starlight",
            mutualStatus = MutualStatus.MUTUAL,
            relationshipState = RelationshipState.FRIENDS,
            actionButtonText = "Friends"
        )
        val uncertainAccount = DiscoveredAccount(
            username = "mystery.user",
            displayName = "Mystery User",
            mutualStatus = MutualStatus.UNKNOWN,
            relationshipState = RelationshipState.UNKNOWN,
            actionButtonText = "..."
        )
        val displayNameOnly = DiscoveredAccount(
            username = "   ",
            displayName = "Display Name Without Handle",
            mutualStatus = MutualStatus.NON_MUTUAL,
            relationshipState = RelationshipState.FOLLOWING,
            actionButtonText = "Following"
        )
        val eligibleNonMutual = DiscoveredAccount(
            username = "studio.kawaii",
            displayName = "Kawaii Studio",
            mutualStatus = MutualStatus.NON_MUTUAL,
            relationshipState = RelationshipState.FOLLOWING,
            actionButtonText = "Following"
        )

        val evalMutual = EligibilityEvaluator.evaluate(mutualFriend, skipMutuals = true)
        assertFalse(evalMutual.eligible)
        assertEquals("mutual_protected", evalMutual.skipReason)

        val evalUncertain = EligibilityEvaluator.evaluate(uncertainAccount, skipMutuals = true)
        assertFalse(evalUncertain.eligible)
        assertEquals("mutual_status_uncertain", evalUncertain.skipReason)

        val evalNoHandle = EligibilityEvaluator.evaluate(displayNameOnly, skipMutuals = false)
        assertFalse(evalNoHandle.eligible)
        assertEquals("missing_username_display_name_only_rejected", evalNoHandle.skipReason)

        val evalEligible = EligibilityEvaluator.evaluate(eligibleNonMutual, skipMutuals = true)
        assertTrue(evalEligible.eligible)
    }

    @Test
    fun testTikTokAccessibilityTreeScannerAndCaptchaDetection() {
        val rootTree = VirtualAccessibilityNode(
            className = "android.widget.FrameLayout",
            packageName = "com.zhiliaoapp.musically",
            children = listOf(
                VirtualAccessibilityNode(
                    className = "android.view.ViewGroup",
                    children = listOf(
                        VirtualAccessibilityNode(text = "Kawaii Studio"),
                        VirtualAccessibilityNode(text = "@studio.kawaii"),
                        VirtualAccessibilityNode(className = "android.widget.Button", text = "Following", isClickable = true)
                    )
                ),
                VirtualAccessibilityNode(
                    className = "android.view.ViewGroup",
                    children = listOf(
                        VirtualAccessibilityNode(text = "Best Friend"),
                        VirtualAccessibilityNode(text = "@mina.bestie"),
                        VirtualAccessibilityNode(className = "android.widget.Button", text = "Friends", isClickable = true)
                    )
                )
            )
        )

        val accounts = TikTokNodeScanner.scanAccountRows(rootTree, WorkflowMode.FOLLOWING)
        assertEquals(2, accounts.size)
        assertEquals("studio.kawaii", accounts[0].username)
        assertEquals(MutualStatus.NON_MUTUAL, accounts[0].mutualStatus)
        assertEquals("mina.bestie", accounts[1].username)
        assertEquals(MutualStatus.MUTUAL, accounts[1].mutualStatus)

        val captchaTree = VirtualAccessibilityNode(
            className = "android.widget.FrameLayout",
            packageName = "com.zhiliaoapp.musically",
            children = listOf(
                VirtualAccessibilityNode(text = "Drag the puzzle piece to verify to continue")
            )
        )
        val challenge = TikTokNodeScanner.detectSecurityChallenge(captchaTree)
        assertTrue(challenge.detected)
        assertEquals("verification_required", challenge.challengeType)
    }

    @Test
    fun testOverlayPositionClampingAndTapDetection() {
        val clamped = OverlayPositionController.clampCoordinates(
            desiredX = -250,
            desiredY = 9999,
            overlayWidthPx = 180,
            overlayHeightPx = 120,
            screenWidthPx = 1080,
            screenHeightPx = 2400,
            topInsetPx = 72,
            bottomInsetPx = 120,
            horizontalMarginPx = 12
        )
        assertEquals(12, clamped.x)
        assertEquals(2160, clamped.y)
        assertTrue(OverlayPositionController.isTapGesture(100f, 200f, 108f, 205f))
        assertFalse(OverlayPositionController.isTapGesture(100f, 200f, 180f, 310f))
    }

    @Test
    fun testLargeScale10000RowCsvExportAndPendingPreservation() {
        val history = (1..10_000).map { idx ->
            ActionHistoryEntity(
                id = "id-$idx",
                dedupeKey = "sess-10k:unfollow:user.$idx:success",
                sessionId = "sess-10k",
                username = "user.$idx",
                displayName = "User $idx, PhD",
                requestedAction = "unfollow",
                result = "success",
                timestampIso = "2026-10-18T07:45:00.000Z"
            )
        }
        val remainingQueue = listOf(
            QueueItemEntity(
                sessionId = "sess-10k",
                username = "unprocessed.user",
                normalizedUsername = "unprocessed.user",
                displayName = "=SUM(A1:A2)",
                mutualStatus = "non_mutual",
                status = "pending"
            )
        )

        val (csv, rowCount) = CsvExportManager.buildSessionCsvString(
            sessionId = "sess-10k",
            requestedAction = "unfollow",
            historyItems = history,
            remainingQueueItems = remainingQueue
        )

        assertEquals(10_001, rowCount)
        assertTrue(csv.startsWith("\uFEFFUsername,Display Name,Requested Action,Result,Timestamp,Session ID,Skip Reason,Error Details"))
        assertTrue(csv.contains("\"'=SUM(A1:A2)\"") || csv.contains("'=SUM(A1:A2)"))
        assertTrue(csv.contains("@unprocessed.user"))
        assertTrue(csv.contains("unprocessed_at_session_end"))
    }

    @Test
    fun testSettingsValidationAndLimits() {
        val invalidSettings = SessionSettings(
            minDelayMs = 5000L,
            maxDelayMs = 1000L,
            maxActionsPerSession = 25000
        )
        val (sanitized, errors) = invalidSettings.validateAndSanitize()
        assertNotNull(sanitized)
        assertTrue(errors.isNotEmpty())
        assertEquals(10_000, sanitized.maxActionsPerSession)
        assertTrue(sanitized.maxDelayMs >= sanitized.minDelayMs)
    }
}
