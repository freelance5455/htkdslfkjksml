package com.example

import com.example.localization.AppLang
import com.example.localization.SjsStrings
import com.example.model.*
import com.google.firebase.Timestamp
import org.junit.Assert.*
import org.junit.Test
import java.util.Date

class MarketplaceBusinessLogicTest {

    @Test
    fun `commission model calculates exactly 5 percent and subscription charges 0 percent`() {
        assertEquals(25_000L, CommissionCalculator.calculateCommission(500_000L, RevenueModel.COMMISSION))
        assertEquals(0L, CommissionCalculator.calculateCommission(500_000L, RevenueModel.MONTHLY_SUBSCRIPTION))
        assertEquals(0L, CommissionCalculator.calculateCommission(0L, RevenueModel.COMMISSION))
    }

    @Test
    fun `provider subscription eligibility tracks expiration accurately`() {
        val now = 1_700_000_000_000L
        val activeProvider = SecurityProvider(
            revenueModel = RevenueModel.MONTHLY_SUBSCRIPTION.name,
            subscriptionStatus = SubscriptionStatus.ACTIVE.name,
            subscriptionExpiresAt = Timestamp(Date(now + 10L * 24L * 60L * 60L * 1000L))
        )
        assertTrue(activeProvider.isEligibleToReceiveOrders(now))
        assertEquals(11L, activeProvider.daysUntilSubscriptionExpiry(now))

        val expiredProvider = activeProvider.copy(
            subscriptionExpiresAt = Timestamp(Date(now - 1000L))
        )
        assertFalse(expiredProvider.isEligibleToReceiveOrders(now))
        assertEquals(0L, expiredProvider.daysUntilSubscriptionExpiry(now))

        val commissionProvider = SecurityProvider(
            revenueModel = RevenueModel.COMMISSION.name,
            subscriptionStatus = SubscriptionStatus.INACTIVE.name
        )
        assertTrue(commissionProvider.isEligibleToReceiveOrders(now))
    }

    @Test
    fun `all 10 service categories and 10 lifecycle steps are defined`() {
        assertEquals(10, ServiceCategory.entries.size)
        assertEquals(1, OrderStatus.REQUESTED.stepIndex)
        assertEquals(10, OrderStatus.CLOSED.stepIndex)
        assertEquals("0788016987", MarketplaceConstants.ADMIN_AIRTEL_NUMBER)
        assertEquals(20_000L, MarketplaceConstants.MONTHLY_SUBSCRIPTION_FEE_TZS)
    }

    @Test
    fun `bilingual strings return Swahili primary and English secondary`() {
        assertEquals("Walinzi wa Usalama", SjsStrings.categoryLabel(ServiceCategory.SECURITY_GUARDS, AppLang.SW))
        assertEquals("Security Guards", SjsStrings.categoryLabel(ServiceCategory.SECURITY_GUARDS, AppLang.EN))
        assertEquals("TZS 20,000", TzsFormatter.format(20_000L))
    }
}
