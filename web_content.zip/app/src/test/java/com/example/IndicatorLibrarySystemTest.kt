package com.example

import com.example.core.model.chart.Candle
import com.example.core.model.chart.IndicatorCalculator
import com.example.core.model.chart.IndicatorInstance
import com.example.core.model.chart.IndicatorType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class IndicatorLibrarySystemTest {

    private fun generateMockCandles(count: Int = 100): List<Candle> {
        val baseTime = 1700000000L
        var lastClose = 50000.0
        return (0 until count).map { i ->
            val change = if (i % 2 == 0) 150.0 else -100.0
            val open = lastClose
            val close = open + change
            val high = maxOf(open, close) + 50.0
            val low = minOf(open, close) - 50.0
            lastClose = close
            Candle(
                timestamp = (baseTime + i * 60) * 1000L,
                open = open,
                high = high,
                low = low,
                close = close,
                volume = 12.5 + i
            )
        }
    }

    @Test
    fun `verify all required indicators exist in catalog`() {
        val types = IndicatorType.entries.map { it.code }
        assertTrue("Catalog must include RSI", types.contains("RSI"))
        assertTrue("Catalog must include MACD", types.contains("MACD"))
        assertTrue("Catalog must include EMA (Moving Average)", types.contains("EMA"))
        assertTrue("Catalog must include SMA (Moving Average)", types.contains("SMA"))
        assertTrue("Catalog must include BOLL", types.contains("BOLL"))
        assertTrue("Catalog must include ATR", types.contains("ATR"))
        assertTrue("Catalog must include VWAP", types.contains("VWAP"))
    }

    @Test
    fun `verify moving averages categorization`() {
        assertEquals("Moving Average", IndicatorType.EMA.category)
        assertEquals("Moving Average", IndicatorType.SMA.category)
        assertEquals("Momentum", IndicatorType.RSI.category)
        assertEquals("Momentum", IndicatorType.MACD.category)
    }

    @Test
    fun `verify indicator instance toggle updates enabled state`() {
        val original = IndicatorInstance(
            type = IndicatorType.RSI,
            period = 14,
            isEnabled = true
        )
        assertTrue(original.isEnabled)

        val toggledOff = original.copy(isEnabled = false)
        assertFalse(toggledOff.isEnabled)

        val toggledOn = toggledOff.copy(isEnabled = true)
        assertTrue(toggledOn.isEnabled)
    }

    @Test
    fun `verify indicator calculation produces data points for RSI and Moving Averages`() {
        val candles = generateMockCandles(60)

        val rsi = IndicatorInstance(type = IndicatorType.RSI, period = 14)
        val rsiPoints = IndicatorCalculator.calculate(rsi, candles)
        assertTrue("RSI points must be non-empty", rsiPoints.isNotEmpty())
        assertTrue("RSI should be between 0 and 100", rsiPoints.all { it.value in 0.0..100.0 })

        val ema = IndicatorInstance(type = IndicatorType.EMA, period = 20)
        val emaPoints = IndicatorCalculator.calculate(ema, candles)
        assertTrue("EMA points must be non-empty", emaPoints.isNotEmpty())

        val sma = IndicatorInstance(type = IndicatorType.SMA, period = 20)
        val smaPoints = IndicatorCalculator.calculate(sma, candles)
        assertTrue("SMA points must be non-empty", smaPoints.isNotEmpty())

        val macd = IndicatorInstance(type = IndicatorType.MACD, period = 12)
        val macdPoints = IndicatorCalculator.calculate(macd, candles)
        assertTrue("MACD points must be non-empty", macdPoints.isNotEmpty())
    }

    @Test
    fun `verify indicator JSON serialization structure for chart engine bridge`() {
        val candles = generateMockCandles(30)
        val indicator = IndicatorInstance(
            type = IndicatorType.RSI,
            period = 14,
            color = "#E91E63",
            isEnabled = true
        )
        val points = IndicatorCalculator.calculate(indicator, candles)
        val json = indicator.toJson(points)

        assertEquals(indicator.id, json.getString("id"))
        assertEquals("RSI", json.getString("type"))
        assertEquals("#E91E63", json.getString("color"))
        assertTrue(json.getBoolean("isEnabled"))
        assertNotNull(json.getJSONArray("points"))
        assertTrue(json.getJSONArray("points").length() > 0)
    }
}
