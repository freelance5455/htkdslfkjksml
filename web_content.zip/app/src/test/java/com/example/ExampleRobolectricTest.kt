package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.alarm.AlarmScheduler
import com.example.data.database.AppDatabase
import com.example.data.model.AlarmEntity
import com.example.data.model.AppSettingsEntity
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read app name string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Chrono Alarm", appName)
    }

    @Test
    fun `alarm entity time calculation returns future timestamp`() {
        val alarm = AlarmEntity(
            hour = 7,
            minute = 30,
            label = "Morning Test",
            isEnabled = true,
            daysOfWeek = "1,2,3,4,5"
        )
        val triggerMillis = AlarmScheduler.calculateNextTriggerMillis(alarm)
        assertTrue(triggerMillis > System.currentTimeMillis())
    }

    @Test
    fun `database can insert and query alarm entity`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = AppDatabase.getInstance(context)
        val alarm = AlarmEntity(
            hour = 8,
            minute = 15,
            label = "Test Wake Up",
            isEnabled = true,
            daysOfWeek = "1,2,3,4,5",
            vibrate = true,
            soundTone = "Digital Pulse"
        )
        val id = db.alarmDao().insertAlarm(alarm)
        assertTrue(id > 0)

        val retrieved = db.alarmDao().getAlarmById(id)
        assertNotNull(retrieved)
        assertEquals("Test Wake Up", retrieved?.label)
        assertEquals(8, retrieved?.hour)
        assertEquals(15, retrieved?.minute)
    }

    @Test
    fun `database can persist and update app settings with default light mode and dark mode toggle`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = AppDatabase.getInstance(context)
        
        // Initial settings: Light mode by default
        val initialSettings = AppSettingsEntity(isDarkMode = false, themeId = "CYBER_NEON")
        db.settingsDao().insertOrUpdate(initialSettings)

        val loaded = db.settingsDao().getSettings().first()
        assertNotNull(loaded)
        assertFalse(loaded!!.isDarkMode)

        // Toggle to dark mode
        val updated = loaded.copy(isDarkMode = true)
        db.settingsDao().insertOrUpdate(updated)

        val reloaded = db.settingsDao().getSettings().first()
        assertNotNull(reloaded)
        assertTrue(reloaded!!.isDarkMode)
    }

    @Test
    fun `main activity launches successfully`() {
        val controller = org.robolectric.Robolectric.buildActivity(MainActivity::class.java).setup()
        assertNotNull(controller.get())
    }
}
