package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.model.AppLanguage
import com.example.model.Paksha
import com.example.panchang.VedicPanchangCalculator
import com.example.localization.PanchangStrings
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.util.Calendar

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Vedic Panchang Calendar", appName)
    }

    @Test
    fun `verify panchang calculation for calendar date`() {
        val cal = Calendar.getInstance().apply {
            set(2026, Calendar.OCTOBER, 18)
        }
        val panchang = VedicPanchangCalculator.calculatePanchang(cal)
        assertNotNull(panchang)
        assertTrue(panchang.tithiNumber in 1..30)
        assertNotNull(panchang.panchak)
        assertNotNull(panchang.bichhuda)
        assertTrue(panchang.sunrise.isNotBlank())
        assertTrue(panchang.sunset.isNotBlank())
        assertTrue(panchang.rahuKaal.isNotBlank())
    }

    @Test
    fun `verify vivah muhurats list is available`() {
        val muhurats = VedicPanchangCalculator.getAuspiciousMuhurats()
        assertTrue(muhurats.isNotEmpty())
    }

    @Test
    fun `verify multilingual strings return localized names`() {
        val hindiTitle = PanchangStrings.get(AppLanguage.HINDI, "app_title")
        val marathiTitle = PanchangStrings.get(AppLanguage.MARATHI, "app_title")
        val bengaliTitle = PanchangStrings.get(AppLanguage.BENGALI, "app_title")
        val tamilTitle = PanchangStrings.get(AppLanguage.TAMIL, "app_title")

        assertEquals("वैदिक पंचांग", hindiTitle)
        assertEquals("বৈদিক পঞ্জিকা", bengaliTitle)
        assertEquals("வேத பஞ்சாங்கம்", tamilTitle)
    }
}
