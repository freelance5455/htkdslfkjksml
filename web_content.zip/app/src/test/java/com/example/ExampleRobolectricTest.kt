package com.example

import android.content.Context
import androidx.compose.material3.MaterialTheme
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performClick
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.FileNode
import com.example.ui.components.FileList
import com.example.ui.viewmodel.FileManagerViewModel
import kotlinx.coroutines.Dispatchers
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    @get:Rule
    val tempFolder = TemporaryFolder()

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("My Files", appName)
    }

    @Test
    fun `FileList traverses directories and navigates up with FileManagerViewModel`() {
        val rootDir = tempFolder.newFolder("TestStorageRoot")
        val docsDir = File(rootDir, "Documents").apply { mkdirs() }
        val workDir = File(docsDir, "Projects").apply { mkdirs() }
        File(rootDir, "readme.txt").writeText("Root file")
        File(docsDir, "report.pdf").writeBytes("%PDF-1.7 sample".toByteArray())
        File(workDir, "notes.md").writeText("# Notes")

        val viewModel = FileManagerViewModel(
            rootPath = "file://${rootDir.absolutePath}",
            storageProvider = null,
            ioDispatcher = Dispatchers.Unconfined
        )

        var openedFile: FileNode? = null

        composeTestRule.setContent {
            MaterialTheme {
                FileList(
                    viewModel = viewModel,
                    onOpenFile = { openedFile = it }
                )
            }
        }
        composeTestRule.waitForIdle()

        // 1. Verify root folder displays Documents folder and readme.txt
        composeTestRule.onNodeWithTag("file_item_Documents").assertIsDisplayed()
        composeTestRule.onNodeWithTag("file_item_readme.txt").assertIsDisplayed()
        assertFalse(viewModel.uiState.value.canNavigateUp)

        // 2. Tap Documents folder to traverse into Documents
        composeTestRule.onNodeWithTag("file_item_Documents").performClick()
        composeTestRule.waitForIdle()

        assertTrue(viewModel.uiState.value.canNavigateUp)
        composeTestRule.onNodeWithTag("file_item_Projects").assertIsDisplayed()
        composeTestRule.onNodeWithTag("file_item_report.pdf").assertIsDisplayed()

        // 3. Tap report.pdf to trigger onOpenFile callback without changing directory
        composeTestRule.onNodeWithTag("file_item_report.pdf").performClick()
        composeTestRule.waitForIdle()
        assertEquals("report.pdf", openedFile?.name)

        // 4. Traverse deeper into Projects subfolder
        composeTestRule.onNodeWithTag("file_item_Projects").performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("file_item_notes.md").assertIsDisplayed()

        // 5. Navigate up via toolbar up button back to Documents
        composeTestRule.onNodeWithTag("navigate_up_button").performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("file_item_report.pdf").assertIsDisplayed()

        // 6. Jump directly back to root via Breadcrumb bar
        composeTestRule.onNodeWithTag("breadcrumb_TestStorageRoot").performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("file_item_Documents").assertIsDisplayed()
        assertFalse(viewModel.uiState.value.canNavigateUp)
    }
}
