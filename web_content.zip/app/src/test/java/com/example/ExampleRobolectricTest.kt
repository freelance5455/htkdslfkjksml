package com.example

import android.content.Context
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performTextClearance
import androidx.compose.ui.test.performTextInput
import androidx.compose.ui.test.performTextReplacement
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.AiEngineType
import com.example.data.model.AssistantPersona
import com.example.engine.NexusLocalNeuralEngine
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @get:Rule
    val composeRule = createAndroidComposeRule<MainActivity>()

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("NEXUS AI", appName)
    }

    @Test
    fun `omni ai persona and internet engine are configured`() {
        assertFalse(AiEngineType.CLOUD.isOffline)
        assertTrue(AssistantPersona.OMNI_AI.systemPrompt.contains("NEXUS"))
    }

    @Test
    fun `local neural engine evaluates math without network`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val engine = NexusLocalNeuralEngine(context)

        val result = engine.generateResponse(
            prompt = "Посчитай 125 * 4",
            history = emptyList(),
            persona = AssistantPersona.OMNI_AI,
            assistantName = "NEXUS"
        )

        assertTrue(result.isOffline)
        assertTrue(result.text.contains("500"))
    }

    @Test
    fun `chat input accepts multilingual text numbers punctuation and supports chat switching`() {
        composeRule.waitForIdle()

        // New ChatGPT/Claude layout: zero bottom tab bar, clean top model pill + floating composer
        composeRule.onNodeWithTag("main_navigation_bar").assertDoesNotExist()
        composeRule.onNodeWithTag("model_selector_pill").assertIsDisplayed()
        composeRule.onNodeWithTag("open_sidebar_button").assertIsDisplayed()
        composeRule.onNodeWithTag("chat_input_field").assertIsDisplayed()
        composeRule.onNodeWithTag("send_message_button").assertIsDisplayed()

        // Ensure clutter buttons are absent from chat input bar
        composeRule.onNodeWithTag("chat_attach_button").assertDoesNotExist()
        composeRule.onNodeWithTag("chat_mic_button").assertDoesNotExist()

        // Test typing Russian, English, Kyrgyz (ңөү), numbers, spaces & punctuation
        val multilingual = "Салам! Привет, NEXUS 2026: Өмүр, Көңүл, Үй-бүлө — test?"
        composeRule.onNodeWithTag("chat_input_field").performTextInput(multilingual)
        composeRule.waitForIdle()
        composeRule.onNodeWithText(multilingual).assertIsDisplayed()

        // Test clearing and replacing (simulates deletion + paste)
        composeRule.onNodeWithTag("chat_input_field").performTextClearance()
        composeRule.onNodeWithTag("chat_input_field").performTextReplacement("Повторный ввод: ABC abc 123 !@#")
        composeRule.waitForIdle()
        composeRule.onNodeWithText("Повторный ввод: ABC abc 123 !@#").assertIsDisplayed()

        // Create / switch to a new chat and confirm text entry still works cleanly
        composeRule.onNodeWithTag("new_chat_button").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("chat_input_field").performTextInput("Новый чат: ңөү hello 42")
        composeRule.waitForIdle()
        composeRule.onNodeWithText("Новый чат: ңөү hello 42").assertIsDisplayed()
    }

    @Test
    fun `sidebar routes to dedicated voice assistant settings and tools sections`() {
        composeRule.waitForIdle()

        // Open sidebar drawer -> navigate to Voice Assistant standalone section
        composeRule.onNodeWithTag("open_sidebar_button").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("sidebar_search_input").assertIsDisplayed()
        composeRule.onNodeWithTag("sidebar_voice_item").performClick()
        composeRule.waitForIdle()

        composeRule.onNodeWithTag("main_mic_button").assertIsDisplayed()
        composeRule.onNodeWithTag("voice_back_button").performClick()
        composeRule.waitForIdle()

        // Open sidebar drawer -> navigate to Settings standalone section
        composeRule.onNodeWithTag("open_sidebar_button").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("sidebar_settings_item").performClick()
        composeRule.waitForIdle()

        composeRule.onNodeWithTag("assistant_name_input").assertIsDisplayed()
        composeRule.onNodeWithTag("settings_back_button").performClick()
        composeRule.waitForIdle()

        // Open sidebar drawer -> navigate to Tools section & tool detail pages
        composeRule.onNodeWithTag("open_sidebar_button").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("sidebar_tools_item").performClick()
        composeRule.waitForIdle()

        composeRule.onNodeWithTag("tool_card_image").assertIsDisplayed()
        composeRule.onNodeWithTag("tool_card_documents").assertIsDisplayed()
        composeRule.onNodeWithTag("tool_card_voice").assertIsDisplayed()
        composeRule.onNodeWithTag("tool_card_textgen").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("tool_card_other").performScrollTo().assertIsDisplayed()

        // Open Image Analysis dedicated page & verify full text input works
        composeRule.onNodeWithTag("tool_card_image").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("tool_pick_image_button").assertIsDisplayed()
        composeRule.onNodeWithTag("tool_image_prompt").performTextInput("Опиши фото 123")
        composeRule.waitForIdle()
        composeRule.onNodeWithText("Опиши фото 123").assertIsDisplayed()

        composeRule.onNodeWithTag("tool_back_button").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("tools_back_to_chat_button").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("chat_input_field").assertIsDisplayed()
    }
}
