package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.core.data.local.entity.AppSettingsEntity
import com.example.core.data.local.entity.PaperAccountEntity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read app_name string from context matches IQTrade Pro`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("IQTrade Pro", appName)
  }

  @Test
  fun `verify mandatory safe default states are off`() {
    val defaultSettings = AppSettingsEntity()
    assertFalse("Smart Mode must default to OFF", defaultSettings.isSmartModeEnabled)
    assertFalse("Auto Trading must default to OFF", defaultSettings.isAutoTradingEnabled)
    assertFalse("Live Trading must default to OFF", defaultSettings.isLiveTradingEnabled)
    assertFalse("Indicators must default to OFF", defaultSettings.showIndicators)
    assertFalse("Volume must default to OFF", defaultSettings.showVolume)
    assertFalse("Signal Plotting must default to OFF", defaultSettings.showSignalPlotting)
  }

  @Test
  fun `verify paper account default balance is 10000`() {
    val defaultAccount = PaperAccountEntity()
    assertEquals(10000.0, defaultAccount.balance, 0.001)
    assertEquals(10000.0, defaultAccount.equity, 0.001)
  }
}
