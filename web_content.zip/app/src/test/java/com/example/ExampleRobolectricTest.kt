package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.SecurityPreferences
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("TecnoGuard", appName)
    }

    @Test
    fun `test pin establishment and verification`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val prefs = SecurityPreferences.getInstance(context)

        // Invalid lengths should be rejected
        assertFalse(prefs.setPin("12345"))
        assertFalse(prefs.setPin("1234567"))
        assertFalse(prefs.setPin("abcdef"))

        // Valid 6-digit PIN
        assertTrue(prefs.setPin("123456"))
        assertTrue(prefs.isPinSet)

        // Verify correct PIN
        assertTrue(prefs.verifyPin("123456"))

        // Verify incorrect PIN
        assertFalse(prefs.verifyPin("654321"))
        assertFalse(prefs.verifyPin("000000"))
    }

    @Test
    fun `test grace period and interception logging`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val prefs = SecurityPreferences.getInstance(context)

        assertFalse(prefs.isGracePeriodActive())
        prefs.grantTemporaryAccess(10)
        assertTrue(prefs.isGracePeriodActive())
        prefs.revokeTemporaryAccess()
        assertFalse(prefs.isGracePeriodActive())

        // Test interception log
        prefs.clearLogs()
        assertEquals(0, prefs.getInterceptionLogs().size)
        prefs.logInterception("Intento de apagado detectado", "com.android.systemui")
        val logs = prefs.getInterceptionLogs()
        assertEquals(1, logs.size)
        assertEquals("Intento de apagado detectado", logs[0].reason)
        assertEquals("com.android.systemui", logs[0].targetApp)
    }
}
