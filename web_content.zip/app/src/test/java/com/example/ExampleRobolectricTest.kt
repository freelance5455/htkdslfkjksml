package com.example

import com.example.data.model.EngineState
import com.example.data.model.TargetFieldType
import com.example.data.model.TypingConfig
import com.example.data.model.WordItem
import com.example.data.repository.WordRepository
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleRobolectricTest {

    @Test
    fun testWordItemCreation() {
        val word = WordItem(
            text = "الذكاء الاصطناعي",
            category = "تقنية",
            isEnabled = true
        )

        assertEquals("الذكاء الاصطناعي", word.text)
        assertEquals("تقنية", word.category)
        assertTrue(word.isEnabled)
        assertEquals(0, word.timesUsed)
    }

    @Test
    fun testTypingConfigDefaults() {
        val config = TypingConfig()

        assertTrue(config.charSpeedMs in 10L..500L)
        assertTrue(config.isRandomMode)
        assertEquals(6, config.randomWordCount)
        assertFalse(config.isAutoRepeat)
        assertEquals(TargetFieldType.SINGLE_LINE, config.targetField)
        assertTrue(config.isSoundEnabled)
        assertTrue(config.isHapticsEnabled)
    }

    @Test
    fun testNonRepeatingShuffleLogic() {
        val words = listOf(
            WordItem(text = "كلمة 1"),
            WordItem(text = "كلمة 2"),
            WordItem(text = "كلمة 3"),
            WordItem(text = "كلمة 4"),
            WordItem(text = "كلمة 5")
        )

        // When requesting 5 words with random mode, all 5 in the cycle must be unique!
        val shuffledCycle = words.shuffled().take(5)
        assertEquals(5, shuffledCycle.size)
        val uniqueTexts = shuffledCycle.map { it.text }.toSet()
        assertEquals(5, uniqueTexts.size)
    }

    @Test
    fun testEngineStates() {
        assertEquals("جاهز للبدء", EngineState.IDLE.labelAr)
        assertEquals("جارِ الكتابة...", EngineState.TYPING.labelAr)
        assertEquals("متوقف مؤقتاً", EngineState.PAUSED.labelAr)
        assertEquals("اكتملت الدورة", EngineState.COMPLETED.labelAr)
    }
}
