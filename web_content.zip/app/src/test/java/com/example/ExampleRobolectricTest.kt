package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.SufiContentRepository
import com.example.data.SufiLanguage
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("SUFI SOME SAYS...", appName)
    }

    @Test
    fun `test repository loads wisdom entries offline`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val repository = SufiContentRepository(context)
        val entries = repository.entries
        assertTrue(entries.isNotEmpty())

        val randomEntry = repository.getRandomEntry()
        assertNotNull(randomEntry)
        assertTrue(randomEntry.en.isNotBlank() || randomEntry.ml.isNotBlank())
    }

    @Test
    fun `test repository bookmarking and language`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val repository = SufiContentRepository(context)
        val entry = repository.getRandomEntry()

        repository.toggleSave(entry.id)
        assertTrue(repository.isSaved(entry.id))

        repository.setLanguage(SufiLanguage.MALAYALAM)
        assertEquals(SufiLanguage.MALAYALAM, repository.currentLanguage.value)
    }
}
