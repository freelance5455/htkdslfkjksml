package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.GenderFilter
import com.example.data.model.MediaItem
import com.example.data.model.MediaSource
import com.example.data.model.MediaType
import com.example.data.model.SyncDocuments
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read app name from context matches Yiffy`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Yiffy", appName)
    }

    @Test
    fun `verify GenderFilter values and labels`() {
        assertEquals("Any", GenderFilter.ANY.label)
        assertEquals("Female Only", GenderFilter.FEMALE_ONLY.label)
        assertEquals("Male Only", GenderFilter.MALE_ONLY.label)
        assertEquals("Trans / Herm", GenderFilter.TRANS_HERM.label)

        assertEquals(GenderFilter.FEMALE_ONLY, GenderFilter.fromString("FEMALE_ONLY"))
        assertEquals(GenderFilter.MALE_ONLY, GenderFilter.fromString("MALE_ONLY"))
        assertEquals(GenderFilter.TRANS_HERM, GenderFilter.fromString("TRANS_HERM"))
        assertEquals(GenderFilter.ANY, GenderFilter.fromString("UNKNOWN"))
    }

    @Test
    fun `verify Google Drive 4 sync documents generation`() {
        val sampleItems = listOf(
            MediaItem(
                id = "item_1",
                source = MediaSource.PORNHUB,
                type = MediaType.VIDEO,
                title = "Cyber Fox Loop",
                author = "NeonStudio",
                mediaUrl = "https://example.com/v1.mp4",
                previewUrl = "https://example.com/p1.jpg",
                tags = listOf("female", "fox", "synthwave"),
                likesCount = 100,
                commentsCount = 10
            ),
            MediaItem(
                id = "item_2",
                source = MediaSource.E621,
                type = MediaType.PICTURE,
                title = "Loona Night Glow",
                author = "Kemonono",
                mediaUrl = "https://example.com/v2.jpg",
                previewUrl = "https://example.com/p2.jpg",
                tags = listOf("loona", "wolf", "female"),
                likesCount = 250,
                commentsCount = 20
            )
        )

        // 1. History doc test
        val historyDoc = SyncDocuments.buildHistoryText(sampleItems)
        assertTrue(historyDoc.contains("YIFFY MEDIA VIEWING HISTORY (LAST 100 ITEMS)"))
        assertTrue(historyDoc.contains("Cyber Fox Loop"))

        // 2. Algorithm doc test
        val tagWeights = mapOf("fox" to 8.5f, "synthwave" to 5.0f)
        val sourceWeights = mapOf("Pornhub" to 1.2f, "e621" to 2.0f)
        val algoDoc = SyncDocuments.buildAlgorithmText(tagWeights, sourceWeights)
        assertTrue(algoDoc.contains("SCROLL RECOMMENDATION ALGORITHM PROFILE"))
        assertTrue(algoDoc.contains("fox"))

        // 3. Liked posts doc test
        val likedDoc = SyncDocuments.buildLikedPostsText(sampleItems)
        assertTrue(likedDoc.contains("LIKED POSTS CATALOG"))
        assertTrue(likedDoc.contains("NeonStudio"))

        // 4. Favorite posts segregated by platform test
        val favDoc = SyncDocuments.buildFavoritesText(sampleItems)
        assertTrue(favDoc.contains("FAVORITE POSTS (SEGREGATED BY PLATFORM)"))
        assertTrue(favDoc.contains("PLATFORM: PORNHUB"))
        assertTrue(favDoc.contains("PLATFORM: E621"))
    }
}
