package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.data.local.CommitteeEntity
import com.example.data.local.MemberEntity
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    private lateinit var db: AppDatabase

    @Before
    fun createDb() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
    }

    @After
    fun closeDb() {
        db.close()
    }

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Charghat BSL", appName)
    }

    @Test
    fun `room database stores and retrieves member and committee offline`() = runBlocking {
        val memberDao = db.memberDao()
        val committeeDao = db.committeeDao()

        // 1. Insert Member (Worker)
        val worker = MemberEntity(
            type = "worker",
            union = "সরদহ ইউনিয়ন ছাত্রলীগ",
            ward = "২নং ওয়ার্ড",
            workerName = "শাকিল আহমেদ",
            workerDesignation = "সদস্য",
            workerMobile = "01712345678",
            createdAt = "25/10/2026"
        )
        val workerId = memberDao.insert(worker)
        val memberList = memberDao.getAllMembers().first()
        assertEquals(1, memberList.size)
        assertEquals("শাকিল আহমেদ", memberList[0].workerName)

        // 2. Insert Committee
        val committee = CommitteeEntity(
            unit = "চারঘাট উপজেলা ছাত্রলীগ",
            sovapotiName = "আরিফুল ইসলাম",
            sovapotiMobile = "01711111111",
            secretaryName = "হাসিবুর রহমান",
            secretaryMobile = "01722222222",
            createdAt = "25/10/2026"
        )
        val committeeId = committeeDao.insert(committee)
        val committeeList = committeeDao.getAllCommittees().first()
        assertEquals(1, committeeList.size)
        assertEquals("আরিফুল ইসলাম", committeeList[0].sovapotiName)
        assertEquals("চারঘাট উপজেলা ছাত্রলীগ", committeeList[0].unit)
    }
}
