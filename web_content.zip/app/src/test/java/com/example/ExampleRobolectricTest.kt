package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.util.PaymentSecurityManager
import com.example.util.PaymentSecurityManager.VerificationResult
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    private lateinit var context: Context

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext<Context>()
        PaymentSecurityManager.setVipActive(context, false)
        PaymentSecurityManager.rejectPendingVerification(context)
    }

    @Test
    fun `read string from context`() {
        val appName = context.getString(R.string.app_name)
        assertEquals("Study Timer", appName)
    }

    @Test
    fun `random dummy 12 digit UTR is rejected with error`() {
        // Repeated dummy digits
        val result1 = PaymentSecurityManager.submitUtrForVerification(context, "000000000000")
        assertTrue(result1 is VerificationResult.Error)
        assertFalse(PaymentSecurityManager.isVipActive(context))

        // Sequential dummy digits
        val result2 = PaymentSecurityManager.submitUtrForVerification(context, "123456789012")
        assertTrue(result2 is VerificationResult.Error)
        assertFalse(PaymentSecurityManager.isVipActive(context))
    }

    @Test
    fun `valid format 12 digit UTR enters pending status and DOES NOT activate VIP`() {
        // Authentic format UTR (non-dummy)
        val validUtr = "428172918239"
        val result = PaymentSecurityManager.submitUtrForVerification(context, validUtr)

        // Must be UtrPending, NEVER direct success
        assertTrue(result is VerificationResult.UtrPending)
        assertEquals(validUtr, (result as VerificationResult.UtrPending).utr)

        // Critical test: VIP MUST REMAIN FALSE
        assertFalse("VIP must NOT be activated automatically by typing UTR", PaymentSecurityManager.isVipActive(context))

        // Verification info must be recorded for admin review
        val pendingInfo = PaymentSecurityManager.getPendingVerification(context)
        assertEquals(validUtr, pendingInfo?.utr)
    }

    @Test
    fun `random key does not activate VIP`() {
        val result = PaymentSecurityManager.verifyActivationKey(context, "RANDOM-123456")
        assertTrue(result is VerificationResult.Error)
        assertFalse(PaymentSecurityManager.isVipActive(context))
    }

    @Test
    fun `authentic VIP key activates VIP`() {
        val result = PaymentSecurityManager.verifyActivationKey(context, "VIP2026-PAID")
        assertTrue(result is VerificationResult.Success)
        assertTrue(PaymentSecurityManager.isVipActive(context))
    }

    @Test
    fun `generated customer cryptographic key activates VIP`() {
        val customerKey = PaymentSecurityManager.generateCustomerKey("PINK")
        val result = PaymentSecurityManager.verifyActivationKey(context, customerKey)
        assertTrue(result is VerificationResult.Success)
        assertTrue(PaymentSecurityManager.isVipActive(context))
    }

    @Test
    fun `admin approval activates VIP for pending UTR`() {
        val validUtr = "519283746192"
        PaymentSecurityManager.submitUtrForVerification(context, validUtr)
        assertFalse(PaymentSecurityManager.isVipActive(context))

        val approved = PaymentSecurityManager.approvePendingVerification(context)
        assertTrue(approved)
        assertTrue(PaymentSecurityManager.isVipActive(context))
    }
}
