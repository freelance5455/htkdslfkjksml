package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.DailyChallenges
import com.example.data.GAME_LEVELS
import com.example.data.QUIZ_ITEMS
import com.example.data.TaskCatalog
import com.example.model.QuizItem
import com.example.model.UserStats
import com.example.storage.GamePreferences
import com.example.ui.components.TileLetter
import com.example.viewmodel.GameViewModel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Guess The Image", appName)
    }

    @Test
    fun `verify quiz catalog integrity`() {
        assertTrue("Quiz catalog should have at least 40 items across 10 levels", QUIZ_ITEMS.size >= 40)
        QUIZ_ITEMS.forEach { item ->
            assertFalse("Clean answer cannot be empty for ${item.id}", item.cleanAnswer.isEmpty())
            assertTrue("Zoom coordinates must be valid for ${item.id}", item.zoom.x in 0f..100f && item.zoom.y in 0f..100f)
            assertNotNull("Hints must exist for ${item.id}", item.hints.clue1)
            assertTrue("Level must be between 1 and 10", item.level in 1..10)
        }
    }

    @Test
    fun `verify expanded 10 level progression configuration`() {
        assertEquals(10, GAME_LEVELS.size)
        assertEquals(1, GAME_LEVELS.first().levelNumber)
        assertEquals(10, GAME_LEVELS.last().levelNumber)
        assertTrue(GAME_LEVELS.last().requiredScore > GAME_LEVELS.first().requiredScore)
    }

    @Test
    fun `verify daily challenges and multipliers`() {
        val mult0 = DailyChallenges.getStreakMultiplier(0)
        assertEquals(1.0f, mult0)

        val mult1 = DailyChallenges.getStreakMultiplier(1)
        assertEquals(1.15f, mult1)

        val mult7 = DailyChallenges.getStreakMultiplier(7)
        assertTrue("7-day streak multiplier should be >= 2.0f", mult7 >= 2.0f)

        val mult30 = DailyChallenges.getStreakMultiplier(30)
        assertEquals(3.5f, mult30)
    }

    @Test
    fun `verify tasks and bounties catalog`() {
        val stats = UserStats(score = 5000, coins = 300, totalGuesses = 10, correctGuesses = 10, stage1Solves = 5)
        val daily = TaskCatalog.getDailyTasks(stats)
        val lifetime = TaskCatalog.getLifetimeAchievements(stats)

        assertTrue("Daily tasks should have at least 5 tasks", daily.size >= 5)
        assertTrue("Lifetime achievements should have at least 8 tasks", lifetime.size >= 8)

        val unclaimed = TaskCatalog.getUnclaimedCount(stats)
        assertTrue("Unclaimed count should be calculated accurately", unclaimed >= 0)
    }

    @Test
    fun `verify game preferences persistence`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val prefs = GamePreferences(context)
        val initialStats = prefs.loadStats()
        assertNotNull(initialStats)

        val updatedStats = initialStats.copy(
            score = 1200,
            coins = 350,
            currentLevel = 2,
            streak = 5,
            stage1Solves = 3,
            hintsUsed = 2,
            claimedTaskIds = setOf("daily_solve_1")
        )
        prefs.saveStats(updatedStats)

        val reloadedStats = prefs.loadStats()
        assertEquals(1200, reloadedStats.score)
        assertEquals(350, reloadedStats.coins)
        assertEquals(2, reloadedStats.currentLevel)
        assertEquals(5, reloadedStats.streak)
        assertEquals(3, reloadedStats.stage1Solves)
        assertEquals(2, reloadedStats.hintsUsed)
        assertTrue(reloadedStats.claimedTaskIds.contains("daily_solve_1"))
    }

    @Test
    fun `verify game viewmodel initialization and tile interaction`() {
        val app = ApplicationProvider.getApplicationContext<android.app.Application>()
        val vm = GameViewModel(app)
        val state = vm.uiState.value

        assertNotNull(state.currentItem)
        assertEquals(state.currentItem.cleanAnswer.length, state.placedLetters.size)
        assertEquals(14, state.keyboardTiles.size)

        // Simulate clicking an available tile
        val availableTile = state.keyboardTiles.first { !it.isUsed }
        vm.onTileClick(availableTile)

        val updatedState = vm.uiState.value
        assertEquals(availableTile.char, updatedState.placedLetters.first())
        assertTrue(updatedState.keyboardTiles.first { it.id == availableTile.id }.isUsed)

        // Backspace
        vm.onBackspace()
        assertEquals(null, vm.uiState.value.placedLetters.first())
        assertFalse(vm.uiState.value.keyboardTiles.first { it.id == availableTile.id }.isUsed)
    }

    @Test
    fun `verify 7-day streak progress and milestone tracking`() {
        val streak0 = 0
        val progress0 = (streak0.coerceAtMost(7) / 7f).coerceIn(0f, 1f)
        assertEquals(0f, progress0, 0.001f)

        val streak3 = 3
        val progress3 = (streak3.coerceAtMost(7) / 7f).coerceIn(0f, 1f)
        assertEquals(3f / 7f, progress3, 0.001f)
        assertEquals(4, (7 - streak3).coerceAtLeast(0))

        val streak7 = 7
        val progress7 = (streak7.coerceAtMost(7) / 7f).coerceIn(0f, 1f)
        assertEquals(1.0f, progress7, 0.001f)
        assertEquals(0, (7 - streak7).coerceAtLeast(0))

        val streak10 = 10
        val progress10 = (streak10.coerceAtMost(7) / 7f).coerceIn(0f, 1f)
        assertEquals(1.0f, progress10, 0.001f)
    }

    @Test
    fun `verify daily reminder scheduling and preferences`() {
        val app = ApplicationProvider.getApplicationContext<android.app.Application>()
        val prefs = GamePreferences(app)
        
        // Default is enabled
        assertTrue("Daily reminder should default to enabled", prefs.isDailyReminderEnabled())

        // Toggle to disabled
        prefs.setDailyReminderEnabled(false)
        assertFalse("Daily reminder should persist disabled state", prefs.isDailyReminderEnabled())

        // Re-enable
        prefs.setDailyReminderEnabled(true)
        assertTrue(prefs.isDailyReminderEnabled())

        // ViewModel integration
        val vm = GameViewModel(app)
        assertTrue(vm.uiState.value.isDailyReminderEnabled)
        vm.toggleDailyReminder(false)
        assertFalse(vm.uiState.value.isDailyReminderEnabled)
        assertFalse(prefs.isDailyReminderEnabled())

        vm.toggleDailyReminder(true)
        assertTrue(vm.uiState.value.isDailyReminderEnabled)
        assertTrue(prefs.isDailyReminderEnabled())

        // DailyReminderManager schedule invocation without exception
        com.example.notification.DailyReminderManager.scheduleDailyReminder(app)
        com.example.notification.DailyReminderManager.cancelDailyReminder(app)
    }
}
