package com.example

import android.content.Context
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertTextContains
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @get:Rule val composeTestRule = createAndroidComposeRule<MainActivity>()

  @Test
  fun `app name matches Calculator and opens directly on calculator in v1_2`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    assertEquals("Calculator", context.getString(R.string.app_name))
    assertEquals("1.2", BuildConfig.VERSION_NAME)
    assertEquals(3, BuildConfig.VERSION_CODE)

    // Opens straight into the Calculator screen with zero onboarding or welcome gates
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("calc_expression_display").assertIsDisplayed()
    composeTestRule.onNodeWithTag("key_0").assertIsDisplayed()
    composeTestRule.onNodeWithTag("key_equals").assertIsDisplayed()

    // About section reflects v1.2 (3)
    composeTestRule.onNodeWithTag("open_settings_button").performClick()
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithText("v1.2 (3)").performScrollTo().assertIsDisplayed()
  }

  @Test
  fun `standard calculation flow rapid input ordering and instant tab navigation`() {
    composeTestRule.waitForIdle()

    composeTestRule.onNodeWithTag("key_1").performClick()
    composeTestRule.onNodeWithTag("key_2").performClick()
    composeTestRule.onNodeWithTag("key_5").performClick()
    composeTestRule.onNodeWithTag("key_mul").performClick()
    composeTestRule.onNodeWithTag("key_8").performClick()
    composeTestRule.onNodeWithTag("key_equals").performClick()
    composeTestRule.waitForIdle()

    composeTestRule.onNodeWithTag("calc_result_display").assertTextContains("1,000")

    // Rapid repeated sequence preserves exact order
    composeTestRule.onNodeWithTag("key_ac").performClick()
    listOf("key_9", "key_8", "key_7", "key_add", "key_1", "key_3", "key_equals").forEach { tag ->
      composeTestRule.onNodeWithTag(tag).performClick()
    }
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("calc_result_display").assertTextContains("1,000")

    // Toggle scientific mode
    composeTestRule.onNodeWithTag("toggle_scientific_button").performClick()
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("sci_deg_rad").assertIsDisplayed()

    // Rapid tab switching across Convert, Tools, and back to Calculator
    composeTestRule.onNodeWithTag("nav_convert").performClick()
    composeTestRule.onNodeWithTag("nav_tools").performClick()
    composeTestRule.onNodeWithTag("nav_convert").performClick()
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("converter_swap_button").assertIsDisplayed()

    composeTestRule.onNodeWithTag("nav_tools").performClick()
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("tool_row_PERCENT_OF").assertIsDisplayed()
  }
}
