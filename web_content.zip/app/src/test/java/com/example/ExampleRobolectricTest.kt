package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.calc.CalculatorEvaluator
import com.example.data.calc.EvaluationResult
import com.example.data.model.UnitData
import com.example.data.model.UnitType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Smart Calculator & Tools", appName)
  }

  @Test
  fun `test calculator basic arithmetic`() {
    val result = CalculatorEvaluator.evaluate("15 + 25 × 2")
    assertTrue(result is EvaluationResult.Success)
    assertEquals("65", (result as EvaluationResult.Success).value)
  }

  @Test
  fun `test calculator scientific operations`() {
    val result = CalculatorEvaluator.evaluate("sqrt(16) + 2^3")
    assertTrue(result is EvaluationResult.Success)
    assertEquals("12", (result as EvaluationResult.Success).value)
  }

  @Test
  fun `test unit conversion length`() {
    val m = UnitData.lengthUnits.first { it.id == "m" }
    val km = UnitData.lengthUnits.first { it.id == "km" }
    val converted = UnitData.convert(1500.0, m, km, UnitType.LENGTH)
    assertEquals(1.5, converted, 0.0001)
  }
}
