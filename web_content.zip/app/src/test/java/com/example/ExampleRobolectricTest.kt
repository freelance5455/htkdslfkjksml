package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.db.ReviewQuality
import com.example.data.db.SpacedRepetitionAlgorithm
import com.example.data.pdf.PdfProcessor
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read app name string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("LéxicoFácil", appName)
    }

    @Test
    fun `test text sentence splitting and word extraction`() {
        val sample = "En aquella aldea remota, el anciano boticario guardaba una pócima inmutable. Los lugareños vivían en letargo."
        val sentences = PdfProcessor.splitIntoSentences(sample)
        assertEquals(2, sentences.size)

        val words = PdfProcessor.extractWords(sample, sentences, 1)
        assertTrue(words.isNotEmpty())
        assertTrue(words.any { it.displayWord == "boticario" })
        assertTrue(words.any { it.displayWord == "inmutable" })
    }

    @Test
    fun `test spaced repetition initial 15-minute review interval`() {
        val now = 1000000L
        val (interval, nextReview) = SpacedRepetitionAlgorithm.calculateInitial(now)
        assertEquals(15L, interval)
        assertEquals(now + 15 * 60 * 1000L, nextReview)
    }

    @Test
    fun `test spaced repetition review quality progression`() {
        val now = 1000000L

        // Review AGAIN resets to 15 minutes
        val againResult = SpacedRepetitionAlgorithm.processReview(
            quality = ReviewQuality.AGAIN,
            currentRepetitions = 3,
            currentIntervalMinutes = 1440L,
            currentEaseFactor = 2.5,
            currentForgotten = 1,
            currentRemembered = 5,
            now = now
        )
        assertEquals(15L, againResult.nextIntervalMinutes)
        assertEquals(0, againResult.newRepetitionCount)
        assertEquals(2, againResult.timesForgotten)

        // Review EASY expands interval
        val easyResult = SpacedRepetitionAlgorithm.processReview(
            quality = ReviewQuality.EASY,
            currentRepetitions = 0,
            currentIntervalMinutes = 15L,
            currentEaseFactor = 2.5,
            currentForgotten = 0,
            currentRemembered = 0,
            now = now
        )
        assertEquals(120L, easyResult.nextIntervalMinutes) // 2 hours
        assertEquals(1, easyResult.newRepetitionCount)
        assertEquals(1, easyResult.timesRemembered)
    }

    @Test
    fun `test rhythm bonus and bidirectional quiz rewards`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val repo = com.example.data.db.UserGamificationRepository(context)

        // Perfect rhythm (between 2s and 6s)
        val rhythm = repo.calculateRhythm(3500L)
        assertTrue(rhythm.isPerfectRhythm)
        assertTrue(rhythm.bonusPoints > 0)
        assertEquals(1.5f, rhythm.multiplier)

        // Answering in reverse mode earns points and updates stats
        val (points, rhythmRes) = repo.recordQuizAnswer(
            isCorrect = true,
            direction = com.example.data.model.QuizDirection.MEANING_TO_WORD,
            elapsedTimeMs = 3500L
        )
        assertTrue(points > 0)
        assertTrue(rhythmRes != null && rhythmRes.isPerfectRhythm)
        assertTrue(repo.gameStats.value.totalScore >= points)
    }
}
