package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.DeliveryAddress
import com.example.data.model.OrderStatus
import com.example.data.model.UserRole
import com.example.data.repository.IgnisRepository
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read app name string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Ignis", appName)
    }

    @Test
    fun `test complete marketplace order and delivery lifecycle`() {
        val repository = IgnisRepository.getInstance()

        // 1. Check initial products exist
        val initialProducts = repository.products.value
        assertTrue("Marketplace should have sample innovation products", initialProducts.isNotEmpty())
        val product = initialProducts.first()

        // 2. Add to Cart
        repository.addToCart(product, quantity = 2)
        assertTrue(repository.cart.value.isNotEmpty())

        // 3. Place Order
        val address = DeliveryAddress(
            fullName = "Alex Chen",
            phone = "+1 (555) 381-0192",
            street = "742 Innovation Way, Suite 400",
            city = "Tech City",
            state = "CA",
            postalCode = "94016",
            instructions = "Ring apartment 4B"
        )
        val order = repository.placeOrder(address, "Card Payment (•••• 4242)")
        assertNotNull(order)
        assertTrue("Cart should be cleared after order", repository.cart.value.isEmpty())
        assertEquals(OrderStatus.ORDER_PLACED, order.status)

        // 4. Seller Confirms Order
        repository.sellerConfirmOrder(order.id)
        var updatedOrder = repository.orders.value.find { it.id == order.id }!!
        assertEquals(OrderStatus.SELLER_CONFIRMED, updatedOrder.status)

        // 5. Advance through all delivery stages
        repository.advanceDeliveryWorkflow(order.id)
        updatedOrder = repository.orders.value.find { it.id == order.id }!!
        assertEquals(OrderStatus.DELIVERY_REQUESTED, updatedOrder.status)

        repository.advanceDeliveryWorkflow(order.id)
        updatedOrder = repository.orders.value.find { it.id == order.id }!!
        assertEquals(OrderStatus.DELIVERY_ASSIGNED, updatedOrder.status)

        repository.advanceDeliveryWorkflow(order.id)
        updatedOrder = repository.orders.value.find { it.id == order.id }!!
        assertEquals(OrderStatus.PICKED_UP, updatedOrder.status)

        repository.advanceDeliveryWorkflow(order.id)
        updatedOrder = repository.orders.value.find { it.id == order.id }!!
        assertEquals(OrderStatus.ON_THE_WAY, updatedOrder.status)

        repository.advanceDeliveryWorkflow(order.id)
        updatedOrder = repository.orders.value.find { it.id == order.id }!!
        assertEquals(OrderStatus.DELIVERED, updatedOrder.status)

        repository.advanceDeliveryWorkflow(order.id)
        updatedOrder = repository.orders.value.find { it.id == order.id }!!
        assertEquals(OrderStatus.COMPLETED, updatedOrder.status)
    }

    @Test
    fun `test role switching and chat message dispatch`() {
        val repository = IgnisRepository.getInstance()
        repository.setRole(UserRole.CONSUMER)
        assertEquals(UserRole.CONSUMER, repository.selectedRole.value)

        val chatId = repository.getOrCreateChat(
            orderId = null,
            otherPartyId = "seller-1",
            otherPartyName = "Aura Acoustics",
            otherPartyRole = UserRole.SELLER
        )
        assertNotNull(chatId)

        repository.sendChatMessage(chatId, "Hello! Is this product available locally?", UserRole.CONSUMER)
        val chat = repository.chats.value.find { it.id == chatId }!!
        assertEquals("Hello! Is this product available locally?", chat.lastMessage)
    }
}
