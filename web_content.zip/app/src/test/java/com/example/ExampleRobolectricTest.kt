package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.ArkFeedIds
import com.example.ui.theme.DarkArkColors
import com.example.ui.theme.LightArkColors
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("ARK", appName)
    }

    @Test
    fun `extract hashtags and mentions normalizes lowercase and deduplicates`() {
        val caption = "Weekend #Gaming with @Aarav_99 and #gaming #ARK_Squad @aarav_99!"
        val tags = ArkFeedIds.extractHashtags(caption)
        val mentions = ArkFeedIds.extractMentions(caption)

        assertEquals(listOf("gaming", "ark_squad"), tags)
        assertEquals(listOf("aarav_99"), mentions)
    }

    @Test
    fun `conversationIdFor is deterministic and symmetric`() {
        val id1 = ArkFeedIds.conversationIdFor("uid_alpha", "uid_zeta")
        val id2 = ArkFeedIds.conversationIdFor("uid_zeta", "uid_alpha")

        assertEquals("uid_alpha_uid_zeta", id1)
        assertEquals(id1, id2)
    }

    @Test
    fun `light and dark theme color tokens are distinct and properly flagged`() {
        assertFalse(LightArkColors.isDark)
        assertTrue(DarkArkColors.isDark)
        assertTrue(LightArkColors.background != DarkArkColors.background)
        assertTrue(LightArkColors.surface != DarkArkColors.surface)
    }

    @Test
    fun `bundled login html asset exists and exposes sign in hooks`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val html = context.assets.open("ark_login.html").bufferedReader().use { it.readText() }
        assertTrue(html.contains("Sign in with Google"))
        assertTrue(html.contains("window.Android.signInWithGoogle"))
        assertTrue(html.contains("window.ARKLogin = { pause, resume }"))
    }
}
