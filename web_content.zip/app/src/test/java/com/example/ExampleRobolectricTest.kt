package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.AiEngineType
import com.example.data.model.AssistantPersona
import com.example.engine.NexusLocalNeuralEngine
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("NEXUS AI", appName)
    }

    @Test
    fun `omni ai persona and internet engine are configured`() {
        assertFalse(AiEngineType.CLOUD.isOffline)
        assertTrue(AssistantPersona.OMNI_AI.systemPrompt.contains("NEXUS"))
    }

    @Test
    fun `local neural engine evaluates math without network`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val engine = NexusLocalNeuralEngine(context)

        val result = engine.generateResponse(
            prompt = "Посчитай 125 * 4",
            history = emptyList(),
            persona = AssistantPersona.OMNI_AI,
            assistantName = "NEXUS"
        )

        assertTrue(result.isOffline)
        assertTrue(result.text.contains("500"))
    }
}
