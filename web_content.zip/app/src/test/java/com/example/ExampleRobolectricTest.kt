package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.engine.ApkSignerEngine
import com.example.engine.ArchiveConverterEngine
import com.example.engine.OptimizationEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.ByteArrayInputStream

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("AppBundle Pro", appName)
    }

    @Test
    fun `test key generation and fingerprint`() {
        val keyInfo = ApkSignerEngine.generateKeyPair(alias = "test_alias")
        assertEquals("test_alias", keyInfo.alias)
        assertTrue(keyInfo.sha256Fingerprint.contains(":"))
        assertTrue(keyInfo.sha1Fingerprint.contains(":"))
    }

    @Test
    fun `test sample apk creation and analysis`() {
        val sampleApk = ArchiveConverterEngine.createSampleApk()
        assertTrue(sampleApk.isNotEmpty())

        val diag = OptimizationEngine.analyzeArchive(ByteArrayInputStream(sampleApk), sampleApk.size.toLong())
        assertTrue(diag.totalFiles > 0)
        assertTrue(diag.score >= 60)
    }
}
