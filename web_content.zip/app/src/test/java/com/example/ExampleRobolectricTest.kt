package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.tts.TextChunker
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("OmniVoice", appName)
  }

  @Test
  fun `text chunker splits long text naturally`() {
    val sampleText = """Welcome to OmniVoice. This is sentence number one.

This is a second paragraph that should be converted into separate chunks without dropping any sentences or duplicating words.

Here is the third paragraph testing long form narrations and audiobooks."""

    val chunks = TextChunker.chunkText(sampleText)
    assertTrue("Chunks should not be empty", chunks.isNotEmpty())
    val wordCount = TextChunker.countWords(sampleText)
    assertTrue("Word count should be > 20", wordCount > 20)
  }
}
