package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.database.AppDatabase
import com.example.data.model.Perfume
import com.example.data.repository.PerfumeRepository
import com.example.util.ValidadeNivel
import com.example.util.ValidadeUtil
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    private lateinit var db: AppDatabase
    private lateinit var repository: PerfumeRepository

    @Before
    fun setup() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        repository = PerfumeRepository(db.perfumeDao(), db.vendaDao())
    }

    @After
    fun tearDown() {
        db.close()
    }

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("PerfumeStock", appName)
    }

    @Test
    fun `test validade status calculation`() {
        val pastDate = "2020-01-01"
        val pastStatus = ValidadeUtil.calcularValidade(pastDate)
        assertEquals(ValidadeNivel.VENCIDO, pastStatus.nivel)

        val cal = java.util.Calendar.getInstance()
        cal.add(java.util.Calendar.DAY_OF_YEAR, 90)
        val sdf = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault())
        val threeMonthsDate = sdf.format(cal.time)
        val statusNear = ValidadeUtil.calcularValidade(threeMonthsDate)
        assertEquals(ValidadeNivel.A_VENCER_6_MESES, statusNear.nivel)

        val farFutureDate = "2030-01-01"
        val futureStatus = ValidadeUtil.calcularValidade(farFutureDate)
        assertEquals(ValidadeNivel.REGULAR, futureStatus.nivel)
    }

    @Test
    fun `test multi-batch inventory, sale deduction and sale editing`() = runBlocking {
        // Lote 1: vence antes (2026-11-01), 3 un.
        val lote1 = Perfume(
            codigo = "7891033300508",
            nome = "Floratta Red Desodorante Colônia 75ml",
            marca = "O Boticário",
            custo = 75.0,
            venda = 149.90,
            estoque = 3,
            validade = "2026-11-01",
            numeroLote = "LT-01"
        )
        // Lote 2: vence depois (2027-10-10), 5 un.
        val lote2 = Perfume(
            codigo = "7891033300508",
            nome = "Floratta Red Desodorante Colônia 75ml",
            marca = "O Boticário",
            custo = 75.0,
            venda = 149.90,
            estoque = 5,
            validade = "2027-10-10",
            numeroLote = "LT-02"
        )

        val id1 = repository.savePerfume(lote1)
        val id2 = repository.savePerfume(lote2)

        val lotes = repository.getLotesByCodigo("7891033300508")
        assertEquals(2, lotes.size)
        val totalSomado = lotes.sumOf { it.estoque }
        assertEquals(8, totalSomado)

        // Realizar venda de 2 unidades -> deve dar baixa no lote 1 (FEFO)
        val resultVenda = repository.realizarVenda("7891033300508", 2)
        assertTrue(resultVenda.isSuccess)
        val venda = resultVenda.getOrThrow()
        assertEquals(id1, venda.perfumeId)
        assertEquals("2026-11-01", venda.validadeVendida)

        val lote1Atualizado = repository.getPerfumeById(id1)
        assertEquals(1, lote1Atualizado?.estoque)

        // Editar venda: o operador errou e eram apenas 1 unidade
        val resultEdicao = repository.editarVenda(venda.id, 1, 149.90)
        assertTrue(resultEdicao.isSuccess)

        // 1 unidade foi devolvida ao lote 1
        val lote1AposEdicao = repository.getPerfumeById(id1)
        assertEquals(2, lote1AposEdicao?.estoque)

        // Cancelar a venda completamente
        val resultCancel = repository.cancelarVenda(venda.id)
        assertTrue(resultCancel.isSuccess)

        // Lote 1 voltou a ter as 3 unidades originais
        val lote1AposCancel = repository.getPerfumeById(id1)
        assertEquals(3, lote1AposCancel?.estoque)
    }
}
