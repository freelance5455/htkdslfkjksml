package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.repository.PlatformRepository
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("منصة القائد", appName)
  }

  @Test
  fun `verify only the three courses and placeholder lesson status`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val repository = PlatformRepository(context)

    val courses = repository.courses.value
    // Strictly ONLY 3 courses
    assertEquals(3, courses.size)
    val courseTitles = courses.map { it.title }
    assertTrue(courseTitles.contains("أولى ثانوي"))
    assertTrue(courseTitles.contains("بكالوريا"))
    assertTrue(courseTitles.contains("تالتة ثانوي"))

    // Each course initially shows exactly one placeholder lesson titled "المحاضرة الأولى" with status "لسه هتنزل"
    val lessons = repository.lessons.value
    assertEquals(3, lessons.size)
    lessons.forEach { lesson ->
      assertEquals("المحاضرة الأولى", lesson.title)
      assertEquals("لسه هتنزل", lesson.status)
    }
  }
}
