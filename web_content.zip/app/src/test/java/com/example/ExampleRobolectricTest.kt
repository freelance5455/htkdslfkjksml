package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.model.ChatMessage
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Faiz Saathi AI", appName)
  }

  @Test
  fun `chatMessage creation and properties`() {
    val message = ChatMessage(
      text = "नमस्ते Faiz Saathi",
      isUser = true
    )
    assertEquals("नमस्ते Faiz Saathi", message.text)
    assertTrue(message.isUser)
    assertFalse(message.isError)
  }
}
