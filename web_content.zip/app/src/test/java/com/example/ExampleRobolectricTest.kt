package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.AiModelOption
import com.example.data.model.AiProvider
import com.example.data.model.SandboxSpec
import com.example.data.model.SandboxWidget
import com.example.data.model.StudioProject
import com.example.data.model.WebsiteLayoutPreset
import com.example.data.model.WebsiteSectionSpec
import com.example.data.model.WebsiteSpec
import com.example.data.model.WebsiteThemePalette
import com.example.util.CodeComplianceAuditor
import com.example.util.ProjectArchiveExporter
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read app_name and empty state strings from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        assertEquals("OmniPrompt Studio", context.getString(R.string.app_name))
        assertEquals(
            "No prompts generated yet. Enter an idea below to begin.",
            context.getString(R.string.empty_projects_message)
        )
        assertEquals(
            "Continue as Guest",
            context.getString(R.string.continue_as_guest)
        )
    }

    @Test
    fun `multi model catalog covers OpenAI Anthropic and Gemini models`() {
        val openAiModels = AiModelOption.forProvider(AiProvider.OPENAI).map { it.displayName }
        assertTrue(openAiModels.contains("GPT-4o"))
        assertTrue(openAiModels.contains("GPT-4o-mini"))

        val anthropicModels = AiModelOption.forProvider(AiProvider.ANTHROPIC).map { it.displayName }
        assertTrue(anthropicModels.contains("Claude 3.5 Sonnet"))

        val geminiModels = AiModelOption.forProvider(AiProvider.GEMINI).map { it.displayName }
        assertTrue(geminiModels.contains("Gemini 4 Argon"))
        assertTrue(geminiModels.contains("Gemini 3.5 Flash"))
    }

    @Test
    fun `sandbox spec serialization code auditor and full gradle archive succeed`() {
        val spec = SandboxSpec(
            appTitle = "Latency Calculator",
            tagline = "Interactive API throughput estimator",
            themeAccentHex = "#38BDF8",
            primaryFormulaLabel = "Monthly Cost",
            primaryFormulaUnit = "USD",
            formulaMode = "MULTIPLY",
            widgets = listOf(
                SandboxWidget(
                    id = "daily_calls",
                    type = "SLIDER",
                    label = "Daily Calls",
                    defaultValue = "50",
                    minValue = 1f,
                    maxValue = 500f,
                    unit = "k"
                )
            )
        )
        val json = spec.toJsonString()
        val restored = SandboxSpec.fromJsonString(json)
        assertEquals("Latency Calculator", restored.appTitle)
        assertEquals(1, restored.widgets.size)

        val project = StudioProject(
            id = "proj_test_1",
            userId = "user_1",
            title = "Latency Calculator",
            prompt = "Calculate API latency and cost",
            provider = "GEMINI",
            modelId = "gemini-4-argon",
            summary = "API cost tool",
            sandboxSpecJson = json,
            kotlinCode = "package com.example\nimport androidx.compose.material3.Scaffold\n@Composable fun App() { Modifier.fillMaxWidth(); remember { mutableStateOf(1) } }",
            manifestXml = "<manifest><application/></manifest>",
            buildGradleKts = "plugins { id(\"com.android.application\"); compose = true }"
        )
        val entries = ProjectArchiveExporter.buildArchiveEntries(project, includeFullGradleScaffold = true)
        assertTrue(entries.containsKey("README.md"))
        assertTrue(entries.containsKey("settings.gradle.kts"))
        assertTrue(entries.containsKey("gradle.properties"))
        assertTrue(entries.containsKey("app/src/main/java/com/example/MainActivity.kt"))
        assertEquals("latency-calculator-studio-archive.zip", ProjectArchiveExporter.suggestedArchiveFileName(project))

        val audit = CodeComplianceAuditor.auditProject(project)
        assertEquals(100, audit.readinessScore)
    }

    @Test
    fun `website maker spec serialization seo auditor and static bundle export succeed`() {
        val webSpec = WebsiteSpec(
            siteTitle = "Cloud GPU Cost Portal",
            tagline = "Real-time GPU cluster cost estimator",
            layoutPresetId = WebsiteLayoutPreset.SAAS_LANDING.id,
            themePaletteId = WebsiteThemePalette.OBSIDIAN_CYAN.id,
            primaryColorHex = "#38BDF8",
            secondaryColorHex = "#818CF8",
            seoMetaDescription = "Calculate hourly and monthly Cloud GPU cluster costs.",
            navLinks = listOf("Overview", "Calculator", "SLA"),
            heroHeadline = "Cloud GPU Cost Portal",
            heroSubheadline = "Predictable infrastructure pricing",
            heroCtaLabel = "Estimate Cluster",
            calculatorLabel = "Monthly GPU Spend",
            calculatorUnit = "USD",
            calculatorMultiplier = 24f,
            sections = listOf(
                WebsiteSectionSpec(
                    id = "sec_features",
                    sectionType = "FEATURE_GRID",
                    heading = "Cluster Architecture",
                    subheading = "Low-latency interconnect",
                    badge = "CORE",
                    items = listOf("NVLink fabric", "Per-second billing")
                )
            )
        )
        val webJson = webSpec.toJsonString()
        val websiteProject = StudioProject(
            id = "web_1",
            userId = "user_1",
            title = "Cloud GPU Cost Portal",
            prompt = "Build a Cloud GPU pricing website",
            provider = "GEMINI",
            modelId = "gemini-4-argon",
            summary = "Responsive SaaS pricing site",
            sandboxSpecJson = webJson,
            kotlinCode = "<!DOCTYPE html><html><head><meta name=\"viewport\" content=\"width=device-width\"></head><body><header></header><main><section></section></main><footer></footer></body></html>",
            manifestXml = "* { box-sizing: border-box; max-width: 100%; }",
            buildGradleKts = "document.addEventListener('DOMContentLoaded', () => {});"
        )
        assertTrue(websiteProject.isWebsiteProject())

        val bundleEntries = ProjectArchiveExporter.buildArchiveEntries(websiteProject, includeFullGradleScaffold = true)
        assertTrue(bundleEntries.containsKey("index.html"))
        assertTrue(bundleEntries.containsKey("styles.css"))
        assertTrue(bundleEntries.containsKey("app.js"))
        assertTrue(bundleEntries.containsKey("netlify.toml"))
        assertTrue(bundleEntries.containsKey("vercel.json"))

        val webAudit = CodeComplianceAuditor.auditProject(websiteProject)
        assertEquals(100, webAudit.readinessScore)
    }
}
