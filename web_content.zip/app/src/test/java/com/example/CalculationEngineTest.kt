package com.example

import com.example.engine.AngleMode
import com.example.engine.CalcError
import com.example.engine.CalculationEngine
import com.example.engine.EvalResult
import com.example.engine.FormattingOptions
import com.example.engine.NumberGroupingStyle
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.math.BigDecimal
import java.math.MathContext
import java.math.RoundingMode
import kotlin.math.abs

class CalculationEngineTest {

  private fun evalSuccess(
    expr: String,
    angleMode: AngleMode = AngleMode.DEG,
    formatting: FormattingOptions = FormattingOptions(),
  ): EvalResult.Success {
    val res = CalculationEngine.evaluate(expr, angleMode, formatting)
    assertTrue("Expected Success for '$expr' ($angleMode), got $res", res is EvalResult.Success)
    return res as EvalResult.Success
  }

  private fun assertFormatted(
    expr: String,
    expectedFormatted: String,
    angleMode: AngleMode = AngleMode.DEG,
    formatting: FormattingOptions = FormattingOptions(),
  ) {
    assertEquals(expectedFormatted, evalSuccess(expr, angleMode, formatting).formatted)
  }

  private fun assertApprox(
    expr: String,
    expected: Double,
    tolerance: Double = 1e-9,
    angleMode: AngleMode = AngleMode.DEG,
  ) {
    val actual = evalSuccess(expr, angleMode).value.toDouble()
    assertEquals("Mismatch for '$expr' ($angleMode)", expected, actual, tolerance)
  }

  private fun assertError(
    expr: String,
    expectedError: CalcError,
    angleMode: AngleMode = AngleMode.DEG,
  ) {
    val res = CalculationEngine.evaluate(expr, angleMode)
    assertTrue("Expected Error($expectedError) for '$expr', got $res", res is EvalResult.Error)
    assertEquals("Wrong error type for '$expr'", expectedError, (res as EvalResult.Error).error)
  }

  // --- Section 2: Standard Arithmetic ---
  @Test
  fun `mandatory arithmetic and percentage cases`() {
    assertFormatted("1+1", "2")
    assertFormatted("9−5", "4")
    assertFormatted("7×8", "56")
    assertFormatted("144÷12", "12")
    assertFormatted("0÷5", "0")
    assertError("5÷0", CalcError.DIVISION_BY_ZERO)
    assertError("0÷0", CalcError.DIVISION_BY_ZERO)

    assertFormatted("0.1+0.2", "0.3")
    assertFormatted("0.7−0.2", "0.5")
    assertFormatted("1.25×4", "5")
    assertFormatted("10÷4", "2.5")

    assertFormatted("−5+8", "3")
    assertFormatted("−5×−5", "25")
    assertFormatted("−5×5", "−25")
    assertFormatted("5−9", "−4")

    assertFormatted("25%", "0.25")
    assertFormatted("200×10%", "20")
    assertFormatted("200+10%", "220")
    assertFormatted("200−10%", "180")
    assertFormatted("200+10%+10%", "242")
    assertFormatted("200+10%×2", "200.2")
  }

  // --- Section 3: Operator Precedence & Associativity ---
  @Test
  fun `operator precedence and associativity`() {
    assertFormatted("2+3×4", "14")
    assertFormatted("10−2×3", "4")
    assertFormatted("20÷5+3", "7")
    assertFormatted("2×3+4×5", "26")
    assertFormatted("100÷10÷2", "5")
    assertFormatted("8−3+2", "7")
    assertFormatted("8÷4×2", "4")
    assertFormatted("2+2×2+2", "8")
    assertFormatted("2^3^2", "512")
    assertFormatted("−5^2", "−25")
    assertFormatted("(−5)^2", "25")
  }

  // --- Section 4: Parentheses & Complex Expressions ---
  @Test
  fun `parentheses nested and malformed expressions`() {
    assertFormatted("(2+3)×4", "20")
    assertFormatted("2×(3+4)", "14")
    assertFormatted("(10−4)÷2", "3")
    assertFormatted("2×(3+4×2)", "22")
    assertFormatted("(5+5)×(2+3)", "50")
    assertFormatted("((2+3)×4)÷2", "10")
    assertFormatted("2(3+4)", "14")
    assertFormatted("(2+3)(4+1)", "25")

    // Auto-close unmatched left paren
    assertFormatted("sin(30", "0.5", AngleMode.DEG)

    // Malformed expressions never crash
    assertError("", CalcError.SYNTAX_ERROR)
    assertError("   ", CalcError.SYNTAX_ERROR)
    assertError("()", CalcError.SYNTAX_ERROR)
    assertError("((()))", CalcError.SYNTAX_ERROR)
    assertError("2+)3(", CalcError.SYNTAX_ERROR)
    assertError("+", CalcError.SYNTAX_ERROR)
    assertError("5+", CalcError.SYNTAX_ERROR)
    assertError("2++3", CalcError.SYNTAX_ERROR)
    assertError("1..2", CalcError.SYNTAX_ERROR)
    assertError("sin()", CalcError.SYNTAX_ERROR)
    assertError("foo(5)", CalcError.SYNTAX_ERROR)
  }

  // --- Section 5: Decimal Precision & Floating-Point Audit ---
  @Test
  fun `decimal precision repeating fractions and reuse fidelity`() {
    assertFormatted("0.1+0.2", "0.3")
    assertFormatted("0.3−0.1", "0.2")
    assertFormatted("0.1×0.1", "0.01")
    assertFormatted("99999999.99+0.01", "100,000,000")
    assertFormatted("1000000000×0.0000001", "100")

    assertApprox("1÷3", 1.0 / 3.0, 1e-12)
    assertApprox("2÷3", 2.0 / 3.0, 1e-12)
    assertApprox("10÷3", 10.0 / 3.0, 1e-12)
    assertApprox("1÷7", 1.0 / 7.0, 1e-12)

    // Verify no premature intermediate rounding: (1/3) * 3 == 1
    assertFormatted("(1÷3)×3", "1")
    assertFormatted("(1÷7)×7", "1")

    // Verify reuse rawNumericString keeps high precision
    val oneThird = evalSuccess("1÷3")
    val reused = evalSuccess("${oneThird.rawNumericString}×3")
    assertEquals("1", reused.formatted)

    // Formatting options
    assertFormatted(
      "1234567.89",
      "1 234 567.89",
      formatting = FormattingOptions(grouping = NumberGroupingStyle.SPACE),
    )
    assertFormatted(
      "1234567.89",
      "1234567.89",
      formatting = FormattingOptions(grouping = NumberGroupingStyle.NONE),
    )
    assertFormatted(
      "10÷3",
      "3.33",
      formatting = FormattingOptions(decimalPrecision = 2),
    )
  }

  // --- Section 6: Large Number & Extreme Stress ---
  @Test
  fun `large numbers 10 20 50 digits and extreme magnitudes`() {
    val r1 = evalSuccess("999999999×999999999")
    assertEquals(BigDecimal("999999998000000001"), r1.value)

    val r2 = evalSuccess("123456789012345×987654321098765")
    // Independently check BigDecimal product
    val expectedProd = BigDecimal("123456789012345").multiply(BigDecimal("987654321098765"))
    assertEquals(0, expectedProd.compareTo(r2.value))

    val r3 = evalSuccess("999999999999999999+1")
    assertEquals(BigDecimal("1000000000000000000"), r3.value)
    assertEquals("1×10^18", r3.formatted)

    val r4 = evalSuccess("1000000000000000000×1000000000")
    assertEquals("1×10^27", r4.formatted)

    // 50-digit integer arithmetic exactness
    val fiftyNines = "9".repeat(50)
    val fiftyPlusOne = evalSuccess("$fiftyNines+1")
    assertEquals(BigDecimal("1" + "0".repeat(50)), fiftyPlusOne.value)
    assertEquals("1×10^50", fiftyPlusOne.formatted)

    // Tiny magnitudes must NOT be clamped to 0!
    val tinyProd = evalSuccess("0.0000000001×0.0000000001")
    assertEquals(0, BigDecimal("1e-20").compareTo(tinyProd.value))
    assertEquals("1×10^−20", tinyProd.formatted)

    val tinyPow = evalSuccess("10^(−15)")
    assertEquals(0, BigDecimal("1e-15").compareTo(tinyPow.value))
    assertEquals("1×10^−15", tinyPow.formatted)

    val bigDiv = evalSuccess("999999999999999999÷3")
    assertEquals(0, BigDecimal("333333333333333333").compareTo(bigDiv.value))

    // Large integer power beyond Double.MAX_VALUE (2^2000)
    val bigPow = evalSuccess("2^2000")
    assertTrue(bigPow.value > BigDecimal("1e600"))

    // Guarded extreme exponent overflow (no hang/OOM)
    assertError("10^99999999", CalcError.OVERFLOW)
  }

  // --- Section 7: Scientific Calculator Audit ---
  @Test
  fun `scientific trigonometry deg and rad and inverse`() {
    assertFormatted("sin(0)", "0", AngleMode.DEG)
    assertFormatted("sin(30)", "0.5", AngleMode.DEG)
    assertApprox("sin(45)", 0.7071067811865476, 1e-10, AngleMode.DEG)
    assertFormatted("sin(90)", "1", AngleMode.DEG)
    assertFormatted("sin(180)", "0", AngleMode.DEG)

    assertFormatted("cos(0)", "1", AngleMode.DEG)
    assertFormatted("cos(60)", "0.5", AngleMode.DEG)
    assertFormatted("cos(90)", "0", AngleMode.DEG)

    assertFormatted("tan(0)", "0", AngleMode.DEG)
    assertFormatted("tan(45)", "1", AngleMode.DEG)
    assertError("tan(90)", CalcError.DOMAIN_ERROR, AngleMode.DEG)
    assertError("tan(270)", CalcError.DOMAIN_ERROR, AngleMode.DEG)

    // RAD mode
    assertFormatted("sin(π÷6)", "0.5", AngleMode.RAD)
    assertFormatted("cos(π)", "−1", AngleMode.RAD)
    assertFormatted("sin(π)", "0", AngleMode.RAD)
    assertError("tan(π÷2)", CalcError.DOMAIN_ERROR, AngleMode.RAD)

    // Inverse trig
    assertFormatted("asin(0.5)", "30", AngleMode.DEG)
    assertFormatted("acos(0.5)", "60", AngleMode.DEG)
    assertFormatted("atan(1)", "45", AngleMode.DEG)
    assertApprox("asin(0.5)", Math.PI / 6.0, 1e-10, AngleMode.RAD)
    assertError("asin(1.5)", CalcError.DOMAIN_ERROR, AngleMode.DEG)
    assertError("acos(−1.1)", CalcError.DOMAIN_ERROR, AngleMode.DEG)
  }

  @Test
  fun `scientific logs powers roots factorial hyperbolic and abs`() {
    assertFormatted("log(1)", "0")
    assertFormatted("log(10)", "1")
    assertFormatted("log(100)", "2")
    assertFormatted("ln(1)", "0")
    assertFormatted("ln(e)", "1")
    assertFormatted("ln(e^2)", "2")
    assertFormatted("logBase(2,8)", "3")
    assertFormatted("logBase(10,1000)", "3")
    assertError("log(0)", CalcError.DOMAIN_ERROR)
    assertError("log(−1)", CalcError.DOMAIN_ERROR)
    assertError("ln(0)", CalcError.DOMAIN_ERROR)
    assertError("ln(−5)", CalcError.DOMAIN_ERROR)
    assertError("logBase(1,10)", CalcError.DOMAIN_ERROR)
    assertError("logBase(−2,8)", CalcError.DOMAIN_ERROR)

    assertFormatted("2^2", "4")
    assertFormatted("3^3", "27")
    assertFormatted("10^6", "1,000,000")
    assertFormatted("2^0", "1")
    assertFormatted("2^(−3)", "0.125")
    assertFormatted("9^0.5", "3")
    assertError("0^(−2)", CalcError.DIVISION_BY_ZERO)
    assertError("(−4)^0.5", CalcError.DOMAIN_ERROR)

    assertFormatted("√(4)", "2")
    assertFormatted("√(9)", "3")
    assertApprox("√(2)", kotlin.math.sqrt(2.0), 1e-10)
    assertFormatted("∛(27)", "3")
    assertFormatted("∛(−8)", "−2")
    assertFormatted("nroot(4,16)", "2")
    assertFormatted("nroot(3,−27)", "−3")
    assertError("√(−1)", CalcError.DOMAIN_ERROR)
    assertError("nroot(2,−4)", CalcError.DOMAIN_ERROR)

    assertFormatted("0!", "1")
    assertFormatted("1!", "1")
    assertFormatted("5!", "120")
    assertFormatted("10!", "3,628,800")
    // 171! supported via BigDecimal without crashing or wrongly flagging domain error
    val fact171 = evalSuccess("171!")
    assertTrue(fact171.value > BigDecimal("1e308"))
    assertError("1001!", CalcError.OVERFLOW)
    assertError("(−1)!", CalcError.DOMAIN_ERROR)
    assertError("2.5!", CalcError.DOMAIN_ERROR)

    assertFormatted("abs(−42.5)", "42.5")
    assertFormatted("1÷(4)", "0.25")
    assertFormatted("sinh(0)", "0")
    assertFormatted("cosh(0)", "1")
    assertFormatted("tanh(0)", "0")
  }
}
