package com.example.security

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class PasswordHasherTest {

    @Test
    fun `password hashing produces valid hash and verifies correctly`() {
        val password = "SuperSecretPassword123"
        val salt = PasswordHasher.generateSalt()

        val hash = PasswordHasher.hash(password, salt)
        assertFalse(hash.isBlank())

        // Verify valid password matches
        val isValid = PasswordHasher.verify(password, salt, hash)
        assertTrue(isValid)

        // Verify wrong password fails
        val isInvalid = PasswordHasher.verify("WrongPassword!", salt, hash)
        assertFalse(isInvalid)
    }

    @Test
    fun `recovery code generation produces formatted string and normalizes correctly`() {
        val code = PasswordHasher.generateRecoveryCode()
        // Format should be XXXX-XXXX-XXXX-XXXX (19 chars total with hyphens)
        assertEquals(19, code.length)
        assertTrue(code.matches(Regex("[2-9A-Z]{4}-[2-9A-Z]{4}-[2-9A-Z]{4}-[2-9A-Z]{4}")))

        val normalized = PasswordHasher.normalizeRecoveryCode(code)
        assertEquals(16, normalized.length)

        // Verify normalization handles lowercase and whitespace
        val messy = "  abcd-efgh-1234-5678  "
        assertEquals("ABCDEFGH12345678", PasswordHasher.normalizeRecoveryCode(messy))
    }
}
