package com.example

import com.example.ai.IchimatsuAiRepository
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class IchimatsuAiRepositoryTest {

    private val repository = IchimatsuAiRepository()

    @Test
    fun `parseMessagesJson normalizes roles and skips leading assistant turns`() {
        val json = """
            [
              {"role": "assistant", "content": "ignored leading"},
              {"role": "user", "content": "Hello Ichimatsu"},
              {"role": "user", "content": "Dance for me"},
              {"role": "assistant", "content": "[moves: party] [face: happy]\nYay!"},
              {"role": "user", "content": "Lift your left arm"}
            ]
        """.trimIndent()

        val turns = repository.parseMessagesJson(json)
        assertEquals(3, turns.size)
        assertEquals("user", turns[0].role)
        assertEquals("Hello Ichimatsu\nDance for me", turns[0].text)
        assertEquals("model", turns[1].role)
        assertEquals("user", turns[2].role)
        assertEquals("Lift your left arm", turns[2].text)
    }
}
