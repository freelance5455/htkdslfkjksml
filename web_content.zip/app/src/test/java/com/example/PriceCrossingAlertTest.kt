package com.example

import com.example.core.chart.ChartWebBridge
import com.example.core.chart.IQTradeChartController
import com.example.core.model.chart.PriceAlertEvent
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class PriceCrossingAlertTest {

    @Test
    fun `verify PriceAlertEvent parsing from JSON for cross above`() {
        val json = """
            {
                "lineId": "line_alert_1",
                "title": "Resistance Alert",
                "targetPrice": 50000.0,
                "currentPrice": 50050.25,
                "previousPrice": 49980.0,
                "direction": "CROSS_ABOVE",
                "timestamp": 1690000000000
            }
        """.trimIndent()

        val event = PriceAlertEvent.fromJson(json)
        assertNotNull("Event should be parsed successfully", event)
        assertEquals("line_alert_1", event!!.lineId)
        assertEquals("Resistance Alert", event.title)
        assertEquals(50000.0, event.targetPrice, 0.001)
        assertEquals(50050.25, event.currentPrice, 0.001)
        assertEquals(49980.0, event.previousPrice, 0.001)
        assertEquals("CROSS_ABOVE", event.direction)
        assertTrue("isCrossAbove should be true", event.isCrossAbove)
        assertFalse("isCrossBelow should be false", event.isCrossBelow)
        assertEquals("50000.00", event.formattedTarget)
        assertEquals("50050.25", event.formattedCurrent)
    }

    @Test
    fun `verify PriceAlertEvent parsing from JSON for cross below`() {
        val json = """
            {
                "lineId": "line_alert_2",
                "title": "Support Level",
                "targetPrice": 48000.0,
                "currentPrice": 47950.0,
                "previousPrice": 48050.0,
                "direction": "CROSS_BELOW",
                "timestamp": 1690000050000
            }
        """.trimIndent()

        val event = PriceAlertEvent.fromJson(json)
        assertNotNull("Event should be parsed successfully", event)
        assertEquals("line_alert_2", event!!.lineId)
        assertEquals("Support Level", event.title)
        assertEquals(48000.0, event.targetPrice, 0.001)
        assertEquals(47950.0, event.currentPrice, 0.001)
        assertEquals(48050.0, event.previousPrice, 0.001)
        assertEquals("CROSS_BELOW", event.direction)
        assertFalse("isCrossAbove should be false", event.isCrossAbove)
        assertTrue("isCrossBelow should be true", event.isCrossBelow)
    }

    @Test
    fun `verify PriceAlertEvent parsing handles malformed json gracefully`() {
        val malformed = "not valid json {{"
        val event = PriceAlertEvent.fromJson(malformed)
        assertNull("Malformed JSON should return null without crashing", event)
    }

    @Test
    fun `verify ChartWebBridge triggers onPriceAlertCallback`() {
        var receivedAlert: PriceAlertEvent? = null

        val bridge = ChartWebBridge(
            onPriceAlertCallback = { event ->
                receivedAlert = event
            }
        )

        val sampleJson = """
            {
                "lineId": "test_line_101",
                "title": "Breakout Test",
                "targetPrice": 62500.0,
                "currentPrice": 62550.0,
                "previousPrice": 62450.0,
                "direction": "CROSS_ABOVE",
                "timestamp": 1690000100000
            }
        """.trimIndent()

        bridge.onPriceAlert(sampleJson)

        assertNotNull("Bridge should have dispatched the parsed event", receivedAlert)
        assertEquals("test_line_101", receivedAlert?.lineId)
        assertEquals(62500.0, receivedAlert?.targetPrice ?: 0.0, 0.001)
        assertEquals(62550.0, receivedAlert?.currentPrice ?: 0.0, 0.001)
        assertTrue(receivedAlert?.isCrossAbove == true)
    }

    @Test
    fun `verify IQTradeChartController dispatches price alert`() {
        val controller = IQTradeChartController()
        var receivedAlert: PriceAlertEvent? = null

        controller.onPriceAlert = { alert ->
            receivedAlert = alert
        }

        val testEvent = PriceAlertEvent(
            lineId = "ctrl_test_line",
            title = "Controller Test",
            targetPrice = 3000.0,
            currentPrice = 2995.0,
            previousPrice = 3005.0,
            direction = "CROSS_BELOW",
            timestamp = System.currentTimeMillis()
        )

        controller.onPriceAlert?.invoke(testEvent)

        assertNotNull("Controller callback should be invoked", receivedAlert)
        assertEquals("ctrl_test_line", receivedAlert?.lineId)
        assertEquals(3000.0, receivedAlert?.targetPrice ?: 0.0, 0.001)
        assertEquals("CROSS_BELOW", receivedAlert?.direction)
    }
}
