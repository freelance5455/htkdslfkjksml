package com.example

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import androidx.test.core.app.ApplicationProvider
import com.example.core.chart.ChartExportHelper
import com.example.core.chart.IQTradeChartController
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ChartCanvasExportTest {

    @Test
    fun `verify bitmap to base64 encoding and decoding roundtrip`() {
        val bitmap = Bitmap.createBitmap(100, 50, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val paint = Paint().apply { color = Color.CYAN }
        canvas.drawRect(0f, 0f, 100f, 50f, paint)

        val base64 = ChartExportHelper.bitmapToBase64(bitmap)
        assertTrue("Base64 string must start with data:image/png;base64,", base64.startsWith("data:image/png;base64,"))

        val decoded = ChartExportHelper.base64ToBitmap(base64)
        assertNotNull("Decoded bitmap must not be null", decoded)
        assertEquals(100, decoded!!.width)
        assertEquals(50, decoded.height)
    }

    @Test
    fun `verify saving base64 image to cache directory`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val bitmap = Bitmap.createBitmap(20, 20, Bitmap.Config.ARGB_8888)
        val base64 = ChartExportHelper.bitmapToBase64(bitmap)

        val savedFile: File? = ChartExportHelper.saveBase64ImageToCache(context, base64, "test_chart_export.png")
        assertNotNull("Saved file must not be null", savedFile)
        assertTrue("Saved file must exist on disk", savedFile!!.exists())
        assertTrue("File size must be greater than 0", savedFile.length() > 0)

        // Cleanup
        savedFile.delete()
    }

    @Test
    fun `verify IQTradeChartController returns base64 canvas string via fallback`() = runBlocking {
        val controller = IQTradeChartController()
        controller.fallbackExport = { cb ->
            cb("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==")
        }

        val result = controller.exportCanvasAsBase64()
        assertNotNull("Export result must not be null", result)
        assertTrue("Result must be base64 PNG data URL", result!!.startsWith("data:image/png;base64,"))
    }
}
