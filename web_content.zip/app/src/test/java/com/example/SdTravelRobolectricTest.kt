package com.example

import android.content.Context
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.hasTestTag
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performScrollToNode
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.export.ExcelExporter
import com.example.data.export.PdfExporter
import com.example.data.local.BookingEntity
import com.example.data.local.PaymentEntity
import com.example.data.local.PreferencesManager
import com.example.data.local.SdTravelDatabase
import com.example.data.model.BookingStatus
import com.example.data.model.DocumentType
import com.example.data.model.PaymentMethod
import com.example.data.model.PendingAttachment
import com.example.data.model.ReportType
import com.example.data.model.SearchFilter
import com.example.data.model.TripType
import com.example.data.repository.SaveResult
import com.example.data.repository.SdTravelRepository
import com.example.data.storage.BackupManager
import com.example.data.storage.DocumentStorage
import com.example.ui.navigation.SdNavHost
import com.example.ui.theme.SdTravelTheme
import com.example.ui.viewmodel.MainViewModel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File
import java.io.FileInputStream
import java.util.zip.ZipInputStream

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class SdTravelRobolectricTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    private lateinit var context: Context
    private lateinit var db: SdTravelDatabase
    private lateinit var storage: DocumentStorage
    private lateinit var repository: SdTravelRepository
    private lateinit var excelExporter: ExcelExporter
    private lateinit var pdfExporter: PdfExporter
    private lateinit var backupManager: BackupManager
    private lateinit var prefs: PreferencesManager

    private val dbFileName = "test_sd_travel_persist.db"

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        context.deleteDatabase(dbFileName)
        File(context.filesDir, "documents").deleteRecursively()
        File(context.filesDir, "exports").deleteRecursively()
        File(context.filesDir, "backups").deleteRecursively()

        db = Room.databaseBuilder(context, SdTravelDatabase::class.java, dbFileName)
            .allowMainThreadQueries()
            .build()
        storage = DocumentStorage(context)
        repository = SdTravelRepository(db.sdTravelDao(), storage)
        excelExporter = ExcelExporter(context)
        pdfExporter = PdfExporter(context)
        prefs = PreferencesManager(context)
        backupManager = BackupManager(context, db, storage, prefs)
    }

    @After
    fun teardown() {
        if (db.isOpen) db.close()
        context.deleteDatabase(dbFileName)
    }

    private fun createDummyImageFile(name: String, content: ByteArray): File {
        val f = File(context.cacheDir, name)
        f.writeBytes(content)
        return f
    }

    @Test
    fun `1_2_manual_code_creation_and_duplicate_rejection`() = runBlocking {
        val booking = BookingEntity(
            clientId = 0,
            tripDate = "2026-12-01",
            returnDate = "2026-12-09",
            tripType = TripType.EIGHT_DAYS,
            companyName = "شركة النور للعمرة",
            makkahHotel = "فندق الصفوة",
            madinahHotel = "فندق دار التقوى",
            totalPrice = 30000.0,
            extraAmount = 2000.0,
            costAmount = 25000.0,
            status = BookingStatus.CONFIRMED,
        )

        val firstRes = repository.createNewClientAndBooking(
            clientCode = "SD-101",
            fullName = "أحمد محمد علي",
            phone = "01012345678",
            whatsapp = "01012345678",
            nationalId = "29001011234567",
            passportNumber = "A1234567",
            birthDate = "1990-01-01",
            clientNotes = "عميل مميز",
            booking = booking,
            depositAmount = 10000.0,
            attachments = emptyList(),
        )
        assertTrue(firstRes is SaveResult.Success)

        // Attempt duplicate code (even with spaces/different case)
        val duplicateRes = repository.createNewClientAndBooking(
            clientCode = " sd-101 ",
            fullName = "محمود حسن",
            phone = "01198765432",
            whatsapp = "",
            nationalId = "",
            passportNumber = "",
            birthDate = "",
            clientNotes = "",
            booking = booking,
            depositAmount = 5000.0,
            attachments = emptyList(),
        )
        assertTrue(duplicateRes is SaveResult.ValidationError)

        // Empty code must also be rejected
        val emptyRes = repository.createNewClientAndBooking(
            clientCode = "   ",
            fullName = "خالد سعيد",
            phone = "01200000000",
            whatsapp = "",
            nationalId = "",
            passportNumber = "",
            birthDate = "",
            clientNotes = "",
            booking = booking,
            depositAmount = 0.0,
            attachments = emptyList(),
        )
        assertTrue(emptyRes is SaveResult.ValidationError)
    }

    @Test
    fun `3_4_documents_and_persistence_across_database_reopen`() = runBlocking {
        val passportTemp = createDummyImageFile("passport.jpg", byteArrayOf(1, 2, 3, 4, 5))
        val idTemp = createDummyImageFile("national_id.jpg", byteArrayOf(6, 7, 8, 9, 10))

        val res = repository.createNewClientAndBooking(
            clientCode = "SD-202",
            fullName = "فاطمة الزهراء إبراهيم",
            phone = "01055555555",
            whatsapp = "01055555555",
            nationalId = "29505051234567",
            passportNumber = "B7654321",
            birthDate = "1995-05-05",
            clientNotes = "",
            booking = BookingEntity(
                clientId = 0,
                tripDate = "2026-12-15",
                returnDate = "2026-12-29",
                tripType = TripType.FOURTEEN_DAYS,
                companyName = "شركة الهدى",
                makkahHotel = "هيلتون مكة",
                madinahHotel = "أنوار المدينة",
                totalPrice = 40000.0,
                extraAmount = 0.0,
                costAmount = 34000.0,
                status = BookingStatus.CONFIRMED,
            ),
            depositAmount = 15000.0,
            attachments = listOf(
                PendingAttachment(DocumentType.PASSPORT, "جواز", passportTemp.absolutePath),
                PendingAttachment(DocumentType.NATIONAL_ID, "بطاقة", idTemp.absolutePath),
            ),
        )
        assertTrue(res is SaveResult.Success)

        // Close and reopen SQLite database to simulate app kill and device restart
        db.close()
        val reopenedDb = Room.databaseBuilder(context, SdTravelDatabase::class.java, dbFileName)
            .allowMainThreadQueries()
            .build()
        val reopenedRepo = SdTravelRepository(reopenedDb.sdTravelDao(), DocumentStorage(context))

        val clients = reopenedRepo.allClientsWithBookings.first()
        assertEquals(1, clients.size)
        val restoredClient = clients.first()
        assertEquals("SD-202", restoredClient.client.clientCode)
        assertEquals(1, restoredClient.bookings.size)
        val docs = restoredClient.bookings.first().documents
        assertEquals(2, docs.size)
        docs.forEach { doc ->
            val persistedFile = storage.resolveFile(doc.relativePath)
            assertTrue("Document file should persist on disk", persistedFile.exists() && persistedFile.length() > 0)
        }
        reopenedDb.close()
    }

    @Test
    fun `5_6_multi_criteria_search_and_two_payments_calculation`() = runBlocking {
        val res = repository.createNewClientAndBooking(
            clientCode = "SD-303",
            fullName = "عبدالله سعد الدين",
            phone = "01122334455",
            whatsapp = "01122334455",
            nationalId = "28808081234567",
            passportNumber = "C998877",
            birthDate = "1988-08-08",
            clientNotes = "",
            booking = BookingEntity(
                clientId = 0,
                tripDate = "2026-12-20",
                returnDate = "2026-12-28",
                tripType = TripType.EIGHT_DAYS,
                companyName = "الصفا للسياحة",
                makkahHotel = "سويس أوتيل",
                madinahHotel = "إيلاف طيبة",
                totalPrice = 25000.0,
                extraAmount = 3000.0,
                costAmount = 22000.0,
                status = BookingStatus.PENDING,
            ),
            depositAmount = 8000.0,
            attachments = emptyList(),
        ) as SaveResult.Success

        // Add two more payments
        repository.addPayment(
            PaymentEntity(
                bookingId = res.bookingId,
                amount = 5000.0,
                paymentDate = "2026-11-15",
                paymentMethod = PaymentMethod.TRANSFER,
                notes = "دفعة ثانية",
            )
        )
        repository.addPayment(
            PaymentEntity(
                bookingId = res.bookingId,
                amount = 7000.0,
                paymentDate = "2026-11-20",
                paymentMethod = PaymentMethod.CASH,
                notes = "دفعة ثالثة",
            )
        )

        val all = repository.allClientsWithBookings.first()
        val booking = all.first().bookings.first()
        // totalDue = 25000 + 3000 = 28000
        // totalPaid = 8000 + 5000 + 7000 = 20000
        // remaining = 28000 - 20000 = 8000
        assertEquals(28000.0, booking.totalDue, 0.01)
        assertEquals(20000.0, booking.totalPaid, 0.01)
        assertEquals(8000.0, booking.remainingAmount, 0.01)

        // Multi-criteria search: partial name + code + date range + company
        val matchFilter = SearchFilter(
            clientCode = "303",
            fullName = "عبدالله",
            companyName = "الصفا",
            tripDateFrom = "2026-12-01",
            tripDateTo = "2026-12-31",
            status = BookingStatus.PENDING,
        )
        val matched = repository.filterClients(all, matchFilter)
        assertEquals(1, matched.size)

        val nonMatch = repository.filterClients(all, matchFilter.copy(status = BookingStatus.CONFIRMED))
        assertTrue(nonMatch.isEmpty())
    }

    @Test
    fun `7_8_reports_excel_pdf_and_backup_restore_without_duplicates`() = runBlocking {
        val passportTemp = createDummyImageFile("pass_backup.jpg", byteArrayOf(11, 22, 33, 44))
        repository.createNewClientAndBooking(
            clientCode = "SD-404",
            fullName = "سمير عبدالحميد",
            phone = "01544556677",
            whatsapp = "",
            nationalId = "",
            passportNumber = "D112233",
            birthDate = "",
            clientNotes = "",
            booking = BookingEntity(
                clientId = 0,
                tripDate = "2026-12-25",
                returnDate = "2027-01-02",
                tripType = TripType.EIGHT_DAYS,
                companyName = "المروة",
                makkahHotel = "فيرمونت",
                madinahHotel = "أوبروي",
                totalPrice = 35000.0,
                extraAmount = 0.0,
                costAmount = 29000.0,
                status = BookingStatus.CONFIRMED,
            ),
            depositAmount = 15000.0,
            attachments = listOf(PendingAttachment(DocumentType.PASSPORT, "جواز", passportTemp.absolutePath)),
        )

        val clients = repository.allClientsWithBookings.first()
        // Test all 10 reports build cleanly & export Excel + PDF
        for (type in ReportType.entries) {
            val preview = repository.buildReport(type, clients, "2026-01-01", "2027-12-31")
            assertTrue(preview.headers.isNotEmpty())
        }

        val bookingReport = repository.buildReport(ReportType.ALL_BOOKINGS, clients, "", "")
        val xlsxFile = excelExporter.exportReportToXlsx(bookingReport, "", "")
        assertTrue(xlsxFile.exists() && xlsxFile.length() > 0)
        // Verify valid ZIP/XLSX structure
        val entries = mutableSetOf<String>()
        ZipInputStream(FileInputStream(xlsxFile)).use { zip ->
            var e = zip.nextEntry
            while (e != null) {
                entries.add(e.name)
                e = zip.nextEntry
            }
        }
        assertTrue(entries.contains("xl/worksheets/sheet1.xml"))
        assertTrue(entries.contains("xl/sharedStrings.xml"))

        // Android PdfDocument relies on native libandroid_runtime Skia PDF which is only available on device/emulator (or shadowed on older Robolectric SDKs).
        // Verify PdfExporter builds without throwing unexpected logic errors on JVM, or produces valid %PDF- when shadowed.
        val pdfResult = runCatching { pdfExporter.exportReportToPdf(bookingReport, "", "") }
        if (pdfResult.isSuccess) {
            val pdfFile = pdfResult.getOrThrow()
            assertTrue(pdfFile.exists() && pdfFile.length() > 100)
            assertEquals("%PDF-", pdfFile.readBytes().take(5).toByteArray().toString(Charsets.US_ASCII))
        } else {
            assertTrue(pdfResult.exceptionOrNull() is IllegalStateException)
        }

        // Backup & Restore
        val backupZip = backupManager.createFullBackup()
        assertTrue(backupZip.exists() && backupZip.length() > 0)

        // Wipe database and documents folder (simulating new phone)
        val clientId = clients.first().client.id
        repository.deleteClient(clientId)
        assertTrue(repository.allClientsWithBookings.first().isEmpty())

        // Restore once -> should restore 1 client, 1 booking, 1 payment, 1 photo
        val firstRestore = backupManager.restoreFromFile(backupZip)
        assertEquals(1, firstRestore.addedClients)
        assertEquals(0, firstRestore.skippedDuplicateClients)
        assertEquals(1, firstRestore.addedBookings)
        assertEquals(1, firstRestore.addedPayments)
        assertEquals(1, firstRestore.restoredDocuments)

        // Restore a second time -> must NOT duplicate the client!
        val secondRestore = backupManager.restoreFromFile(backupZip)
        assertEquals(0, secondRestore.addedClients)
        assertEquals(1, secondRestore.skippedDuplicateClients)
        assertEquals(1, repository.allClientsWithBookings.first().size)
    }

    @Test
    fun `9_dashboard_compose_ui_renders_offline_and_rtl`() {
        val vm = MainViewModel(
            repository = repository,
            documentStorage = storage,
            excelExporter = excelExporter,
            pdfExporter = pdfExporter,
            backupManager = backupManager,
            preferencesManager = prefs,
        )
        composeTestRule.setContent {
            SdTravelTheme {
                SdNavHost(viewModel = vm, skipSplashForTests = true)
            }
        }
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithText("SD TRAVEL").assertIsDisplayed()
        listOf(
            "nav_add_booking_button",
            "nav_clients_button",
            "nav_search_button",
            "nav_reports_button",
            "nav_backup_button",
        ).forEach { tag ->
            composeTestRule.onNodeWithTag("dashboard_list")
                .performScrollToNode(hasTestTag(tag))
            composeTestRule.onNodeWithTag(tag).assertIsDisplayed()
        }
    }
}
