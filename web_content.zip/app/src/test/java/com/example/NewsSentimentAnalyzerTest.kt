package com.example

import com.example.core.model.MarketCategory
import com.example.features.news.analyzer.NewsSentimentAnalyzer
import com.example.features.news.model.NewsImpact
import com.example.features.news.model.NewsSentiment
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class NewsSentimentAnalyzerTest {

    @Test
    fun testBullishSentimentDetectionAndScore() {
        val now = System.currentTimeMillis()
        val article = NewsSentimentAnalyzer.analyze(
            id = "test_1",
            headline = "Bitcoin Surges Past Record High as Institutional Inflows Soar",
            source = "Bloomberg",
            publishedAt = now,
            url = "https://example.com/1",
            description = "Massive capital inflows and ETF approval optimism drive widespread crypto market expansion."
        )

        assertEquals(NewsSentiment.BULLISH, article.sentiment)
        assertTrue("Sentiment score should be > 60 for strong bullish headline, got ${article.sentimentScore}", article.sentimentScore >= 60)
        assertTrue("Sentiment confidence should be >= 65%, got ${article.sentimentConfidence}", article.sentimentConfidence >= 65)
        assertEquals(MarketCategory.CRYPTO, article.marketCategory)
        assertTrue(article.relevantSymbols.contains("BTC"))
        assertTrue(article.relevantSymbols.contains("BTCUSDT"))
    }

    @Test
    fun testBearishSentimentDetectionAndScore() {
        val now = System.currentTimeMillis()
        val article = NewsSentimentAnalyzer.analyze(
            id = "test_2",
            headline = "Crypto Exchange Faces SEC Lawsuit Following Major Security Exploit and Hack",
            source = "Reuters",
            publishedAt = now,
            url = "https://example.com/2",
            description = "Massive liquidations and panic selling trigger sharp market crash."
        )

        assertEquals(NewsSentiment.BEARISH, article.sentiment)
        assertTrue("Sentiment score should be <= 40 for bearish headline, got ${article.sentimentScore}", article.sentimentScore <= 40)
        assertTrue("Sentiment confidence should be >= 65%, got ${article.sentimentConfidence}", article.sentimentConfidence >= 65)
        assertEquals(MarketCategory.CRYPTO, article.marketCategory)
    }

    @Test
    fun testNeutralSentimentClassification() {
        val now = System.currentTimeMillis()
        val article = NewsSentimentAnalyzer.analyze(
            id = "test_3",
            headline = "Federal Reserve Schedule for Annual Economic Symposium Released",
            source = "Financial Wire",
            publishedAt = now,
            url = "https://example.com/3",
            description = "Central bank committee announces upcoming agenda for Jackson Hole gathering."
        )

        assertEquals(NewsSentiment.NEUTRAL, article.sentiment)
        assertEquals(50, article.sentimentScore)
        assertEquals(MarketCategory.FOREX, article.marketCategory)
    }

    @Test
    fun testGoldMarketAndSymbolDetection() {
        val now = System.currentTimeMillis()
        val article = NewsSentimentAnalyzer.analyze(
            id = "test_4",
            headline = "Gold Price Rebounds as Safe Haven Demand Expands Amid Geopolitical Uncertainty",
            source = "Kitco News",
            publishedAt = now,
            url = "https://example.com/4",
            description = "Bullion and precious metals see renewed accumulation as investors look to hedge risk."
        )

        assertEquals(MarketCategory.GOLD, article.marketCategory)
        assertTrue(article.relevantSymbols.contains("XAU/USD") || article.relevantSymbols.contains("GOLD"))
        assertEquals(NewsSentiment.BULLISH, article.sentiment)
    }

    @Test
    fun testForexMarketAndSymbolDetection() {
        val now = System.currentTimeMillis()
        val article = NewsSentimentAnalyzer.analyze(
            id = "test_5",
            headline = "EUR/USD Drops as US Dollar Strengthens Following Unexpected CPI Inflation Spike",
            source = "FXStreet",
            publishedAt = now,
            url = "https://example.com/5",
            description = "Euro currency weakens against dollar following federal reserve interest rate guidance."
        )

        assertEquals(MarketCategory.FOREX, article.marketCategory)
        assertTrue(article.relevantSymbols.contains("EUR/USD") || article.relevantSymbols.contains("EURUSD"))
        assertEquals(NewsSentiment.BEARISH, article.sentiment)
    }

    @Test
    fun testBreakingAndHighImpactClassification() {
        val now = System.currentTimeMillis()
        // Recent publishedAt (within 10 minutes) + high impact keyword
        val breakingArticle = NewsSentimentAnalyzer.analyze(
            id = "test_6",
            headline = "BREAKING: Federal Reserve Announces Emergency Interest Rate Cut",
            source = "CNBC",
            publishedAt = now - 600_000L,
            url = "https://example.com/6",
            description = "Central bank moves to support liquidity in emergency FOMC meeting."
        )

        assertEquals(NewsImpact.HIGH, breakingArticle.impact)
        assertTrue("Article published 10m ago with emergency FOMC rate cut must be breaking", breakingArticle.isBreaking)

        // Same headline but published 2 days ago: high impact, but NOT breaking
        val oldArticle = NewsSentimentAnalyzer.analyze(
            id = "test_7",
            headline = "Federal Reserve Emergency Rate Decision Followup",
            source = "CNBC",
            publishedAt = now - (48 * 3600_000L),
            url = "https://example.com/7",
            description = "Analysis of previous emergency rate action."
        )
        assertEquals(NewsImpact.HIGH, oldArticle.impact)
        assertFalse("Article published 2 days ago must NEVER be marked as breaking news", oldArticle.isBreaking)
    }
}
