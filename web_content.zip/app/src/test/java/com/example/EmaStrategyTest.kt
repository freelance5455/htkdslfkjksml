package com.example

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performClick
import com.example.core.data.chart.ChartDataState
import com.example.core.model.analysis.SupportResistanceResult
import com.example.core.model.Timeframe
import com.example.core.model.chart.Candle
import com.example.core.model.indicator.IndicatorDirection
import com.example.features.more.MoreScreen
import com.example.features.strategy.ema.EmaConfirmationLayers
import com.example.features.strategy.ema.EmaSignalResult
import com.example.features.strategy.ema.EmaStrategyConfig
import com.example.features.strategy.ema.EmaStrategyEngine
import com.example.features.strategy.ema.EmaStrategyScreen
import com.example.ui.theme.IQTradeProTheme
import com.example.viewmodel.MainUiState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import kotlin.math.sin

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class EmaStrategyTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    private fun generateTrendingCandles(
        count: Int,
        basePrice: Double = 100.0,
        trendStep: Double = 1.0,
        allClosed: Boolean = true
    ): List<Candle> {
        val now = 1700000000000L
        return (0 until count).map { i ->
            val p = basePrice + i * trendStep
            Candle(
                timestamp = now + i * 60000L,
                open = p - 0.5,
                high = p + 1.5,
                low = p - 1.0,
                close = p + 0.5,
                volume = 1000.0 + i * 10,
                isClosed = allClosed || i < count - 1
            )
        }
    }

    private fun generateBullishCrossoverCandles(): List<Candle> {
        // First 35 candles: steady downtrend so EMA 9 is well below EMA 21
        val now = 1700000000000L
        val candles = mutableListOf<Candle>()
        var price = 200.0
        for (i in 0 until 35) {
            price -= 2.0
            candles.add(
                Candle(
                    timestamp = now + i * 60000L,
                    open = price + 1.0,
                    high = price + 2.0,
                    low = price - 1.0,
                    close = price,
                    volume = 1500.0,
                    isClosed = true
                )
            )
        }
        // Next 5 candles: massive reversal up so EMA 9 crosses above EMA 21
        for (i in 35 until 42) {
            price += 10.0
            candles.add(
                Candle(
                    timestamp = now + i * 60000L,
                    open = price - 8.0,
                    high = price + 2.0,
                    low = price - 9.0,
                    close = price,
                    volume = 3000.0,
                    isClosed = true
                )
            )
        }
        return candles
    }

    private fun generateBearishCrossoverCandles(): List<Candle> {
        // First 35 candles: steady uptrend so EMA 9 is well above EMA 21
        val now = 1700000000000L
        val candles = mutableListOf<Candle>()
        var price = 100.0
        for (i in 0 until 35) {
            price += 2.0
            candles.add(
                Candle(
                    timestamp = now + i * 60000L,
                    open = price - 1.0,
                    high = price + 1.0,
                    low = price - 2.0,
                    close = price,
                    volume = 1500.0,
                    isClosed = true
                )
            )
        }
        // Next 5 candles: massive plunge down so EMA 9 crosses below EMA 21
        for (i in 35 until 42) {
            price -= 10.0
            candles.add(
                Candle(
                    timestamp = now + i * 60000L,
                    open = price + 8.0,
                    high = price + 9.0,
                    low = price - 2.0,
                    close = price,
                    volume = 3000.0,
                    isClosed = true
                )
            )
        }
        return candles
    }

    // 1. Bullish Crossover
    @Test
    fun testBullishCrossoverSignal() {
        val candles = generateBullishCrossoverCandles()
        val config = EmaStrategyConfig(fastEmaPeriod = 9, slowEmaPeriod = 21, adxThreshold = 10.0)
        val result = EmaStrategyEngine.evaluate(candles, config, "BTCUSDT")

        // In this strongly reversing series, EMA 9 crosses above EMA 21
        assertNotNull(result.fastEma)
        assertNotNull(result.slowEma)
        assertTrue(result.fastEma!! > result.slowEma!!)
        // Completed candle confirmation
        assertFalse(result.isLiveCandleIncomplete)
    }

    // 2. Bearish Crossover
    @Test
    fun testBearishCrossoverSignal() {
        val candles = generateBearishCrossoverCandles()
        val config = EmaStrategyConfig(fastEmaPeriod = 9, slowEmaPeriod = 21, adxThreshold = 10.0)
        val result = EmaStrategyEngine.evaluate(candles, config, "BTCUSDT")

        assertNotNull(result.fastEma)
        assertNotNull(result.slowEma)
        assertTrue(result.fastEma!! < result.slowEma!!)
        assertFalse(result.isLiveCandleIncomplete)
    }

    // 3. No Crossover (Steady trend) -> WAIT
    @Test
    fun testNoCrossoverProducesWait() {
        // Continuous upward trend without crossover at the latest closed bar
        val candles = generateTrendingCandles(count = 50, trendStep = 1.0)
        val config = EmaStrategyConfig(fastEmaPeriod = 9, slowEmaPeriod = 21, adxThreshold = 20.0)
        val result = EmaStrategyEngine.evaluate(candles, config, "BTCUSDT")

        // Because it was already in an uptrend, no fresh crossover on the last completed bar
        assertEquals(EmaSignalResult.WAIT, result.result)
        assertTrue(result.explanation.contains("No fresh crossover") || result.explanation.contains("Waiting"))
    }

    // 4. Incomplete candle = no confirmed signal
    @Test
    fun testIncompleteCandleNeverConfirmsSignal() {
        // Candles where last bar is unclosed (live)
        val candles = generateBullishCrossoverCandles().mapIndexed { index, candle ->
            if (index == 41) candle.copy(isClosed = false) else candle
        }
        val config = EmaStrategyConfig(fastEmaPeriod = 9, slowEmaPeriod = 21, adxThreshold = 20.0)
        val result = EmaStrategyEngine.evaluate(candles, config, "BTCUSDT")

        assertTrue(result.isLiveCandleIncomplete)
        // If crossover happens only on the incomplete live candle, confirmed signal must be WAIT
        // The evaluation must clearly state incomplete candle status
        assertTrue(result.confirmations.adxThreshold == 20.0)
    }

    // 5. ADX Filtering
    @Test
    fun testAdxFilterBlocksWeakTrendCrossover() {
        val candles = generateBullishCrossoverCandles()
        // Set an impossible ADX threshold like 99.0
        val config = EmaStrategyConfig(fastEmaPeriod = 9, slowEmaPeriod = 21, adxThreshold = 99.0)
        val result = EmaStrategyEngine.evaluate(candles, config, "BTCUSDT")

        // Must be WAIT because ADX does not satisfy the primary filter
        assertEquals(EmaSignalResult.WAIT, result.result)
        assertTrue(result.explanation.contains("ADX") || result.explanation.contains("threshold"))
        assertFalse(result.confirmations.adxConfirmed)
    }

    // 6. MTF Confirmation Filtering
    @Test
    fun testMtfOpposingTrendBlocksSignal() {
        val candles = generateBullishCrossoverCandles()
        val config = EmaStrategyConfig(fastEmaPeriod = 9, slowEmaPeriod = 21, adxThreshold = 10.0)
        // Pass higher timeframe bias as BEARISH for a bullish crossover
        val result = EmaStrategyEngine.evaluate(
            candles = candles,
            config = config,
            symbol = "BTCUSDT",
            mtfBias = IndicatorDirection.BEARISH
        )

        assertEquals(EmaSignalResult.WAIT, result.result)
        assertFalse(result.confirmations.mtfAligned)
        assertTrue(result.confirmations.mtfConfirmation.contains("Bearish"))
    }

    // 7. Candlestick/Structure Filtering
    @Test
    fun testStructureConfirmationFilter() {
        // In EmaStrategyEngine, if market structure is Bearish, a bullish crossover is filtered
        val candles = generateTrendingCandles(count = 40, trendStep = -2.0)
        val config = EmaStrategyConfig(fastEmaPeriod = 9, slowEmaPeriod = 21, adxThreshold = 10.0)
        val result = EmaStrategyEngine.evaluate(candles, config, "BTCUSDT")
        assertEquals(EmaSignalResult.WAIT, result.result)
    }

    // 8. Volatility Filtering
    @Test
    fun testVolatilityFilterLayer() {
        val candles = generateTrendingCandles(count = 40)
        val config = EmaStrategyConfig()
        val result = EmaStrategyEngine.evaluate(candles, config, "BTCUSDT")
        assertNotNull(result.confirmations.volatilityStatus)
        assertTrue(result.confirmations.volatilityAcceptable)
    }

    // 9. S/R Conflict Filtering
    @Test
    fun testSupportResistanceCollisionFilter() {
        val candles = generateBullishCrossoverCandles()
        val config = EmaStrategyConfig(fastEmaPeriod = 9, slowEmaPeriod = 21, adxThreshold = 10.0)
        // If current price is equal to resistance, S/R filter triggers
        val lastPrice = candles.last().close
        val result = EmaStrategyEngine.evaluate(candles, config, "BTCUSDT", currentPriceOverride = lastPrice)
        assertNotNull(result.confirmations.supportResistance)
    }

    // 10. Stale / Unavailable Data
    @Test
    fun testEmptyOrInsufficientDataReturnsWait() {
        val config = EmaStrategyConfig()
        // Empty list
        val emptyResult = EmaStrategyEngine.evaluate(emptyList(), config, "BTCUSDT")
        assertEquals(EmaSignalResult.WAIT, emptyResult.result)
        assertTrue(emptyResult.explanation.contains("No market candle data") || emptyResult.explanation.contains("Waiting"))

        // Insufficient bars (< 28)
        val fewCandles = generateTrendingCandles(count = 10)
        val fewResult = EmaStrategyEngine.evaluate(fewCandles, config, "BTCUSDT")
        assertEquals(EmaSignalResult.WAIT, fewResult.result)
        assertTrue(fewResult.explanation.contains("Insufficient") || fewResult.explanation.contains("Waiting"))
    }

    // 11. No Repainting (live candle changes don't alter completed-candle evaluation)
    @Test
    fun testNoRepaintingOnLiveCandleUpdates() {
        val baseCandles = generateTrendingCandles(count = 40, allClosed = true)
        val config = EmaStrategyConfig()

        val eval1 = EmaStrategyEngine.evaluate(baseCandles, config, "BTCUSDT")

        // Add a live developing candle that fluctuates wildly
        val liveCandleA = Candle(
            timestamp = baseCandles.last().timestamp + 60000L,
            open = 150.0,
            high = 300.0,
            low = 100.0,
            close = 290.0,
            isClosed = false
        )
        val eval2 = EmaStrategyEngine.evaluate(baseCandles + liveCandleA, config, "BTCUSDT")

        // Completed candle timestamps and completed EMA values must remain identical
        assertEquals(eval1.lastCompletedCandleTime, eval2.lastCompletedCandleTime)
        assertEquals(eval1.fastEma, eval2.fastEma)
        assertEquals(eval1.slowEma, eval2.slowEma)
    }

    // 12. No Look-Ahead Bias
    @Test
    fun testNoLookAheadBias() {
        val fullHistory = generateTrendingCandles(count = 50)
        val config = EmaStrategyConfig()

        // Evaluating with history up to candle 40
        val historyAt40 = fullHistory.take(40)
        val evalAt40 = EmaStrategyEngine.evaluate(historyAt40, config, "BTCUSDT")

        // Must only reference data at or prior to candle 40
        assertEquals(historyAt40.last().timestamp, evalAt40.lastCompletedCandleTime)
    }

    // 13. Navigation into/out of the screen (More -> EMA 9/21 Strategy -> More)
    @Test
    fun testNavigationIntoAndOutOfEmaStrategyScreen() {
        val state = MainUiState(
            selectedSymbol = "BTCUSDT",
            selectedTimeframe = "15m",
            chartDataState = ChartDataState(
                selectedSymbol = "BTCUSDT",
                candles = generateTrendingCandles(count = 35)
            )
        )

        composeTestRule.setContent {
            IQTradeProTheme {
                MoreScreen(
                    state = state,
                    onResetPaperAccount = {}
                )
            }
        }

        // 1. Verify MoreScreen contains EMA 9/21 Strategy item
        composeTestRule.onNodeWithTag("more_item_ema_strategy").assertIsDisplayed()

        // 2. Click to open EMA 9/21 Strategy
        composeTestRule.onNodeWithTag("btn_open_ema_strategy").performClick()

        // 3. Verify EMA Strategy Screen is displayed
        composeTestRule.onNodeWithTag("ema_strategy_screen").assertIsDisplayed()
        composeTestRule.onNodeWithTag("ema_signal_result_card").assertIsDisplayed()
        composeTestRule.onNodeWithTag("ema_strategy_back_button").assertIsDisplayed()

        // 4. Click Back button to return to More
        composeTestRule.onNodeWithTag("ema_strategy_back_button").performClick()

        // 5. Verify back on MoreScreen
        composeTestRule.onNodeWithTag("more_item_ema_strategy").assertIsDisplayed()
    }
}
