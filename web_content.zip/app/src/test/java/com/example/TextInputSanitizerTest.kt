package com.example

import com.example.util.TextInputSanitizer
import org.junit.Assert.assertEquals
import org.junit.Test

class TextInputSanitizerTest {

    @Test
    fun testNormalSingleCharacterTyping() {
        // Typing 'a'
        val res1 = TextInputSanitizer.sanitize(
            oldText = "",
            newText = "a",
            keyPressSeq = 1L,
            lastConsumedSeq = 0L,
            lastTime = 1000L,
            lastChar = null,
            currentTimeOverride = 1000L
        )
        assertEquals("a", res1.text)
        assertEquals(1L, res1.consumedSeq)
        assertEquals('a', res1.character)

        // Typing 'b'
        val res2 = TextInputSanitizer.sanitize(
            oldText = "a",
            newText = "ab",
            keyPressSeq = 2L,
            lastConsumedSeq = 1L,
            lastTime = 1000L,
            lastChar = 'a',
            currentTimeOverride = 1300L
        )
        assertEquals("ab", res2.text)
        assertEquals(2L, res2.consumedSeq)
        assertEquals('b', res2.character)
    }

    @Test
    fun testDuplicateEventRejectionSameKeyPressSeq() {
        // First event from keydown arrives at 1000ms
        val res1 = TextInputSanitizer.sanitize(
            oldText = "",
            newText = "a",
            keyPressSeq = 1L,
            lastConsumedSeq = 0L,
            lastTime = 0L,
            lastChar = null,
            currentTimeOverride = 1000L
        )
        assertEquals("a", res1.text)
        assertEquals(1L, res1.consumedSeq)

        // Duplicate event from IME arrives at 1120ms with same keyPressSeq (1L) and same char ('a')
        val res2 = TextInputSanitizer.sanitize(
            oldText = "a",
            newText = "aa",
            keyPressSeq = 1L,
            lastConsumedSeq = 1L,
            lastTime = 1000L,
            lastChar = 'a',
            currentTimeOverride = 1120L
        )
        // Should reject the duplicate and return "a"
        assertEquals("a", res2.text)
    }

    @Test
    fun testDuplicateEventRejectionByRapidTime() {
        // Duplicate arrives rapidly (< 280ms) even without keyPressSeq tracking
        val res = TextInputSanitizer.sanitize(
            oldText = "hello",
            newText = "helloo",
            keyPressSeq = 0L,
            lastConsumedSeq = 0L,
            lastTime = 1000L,
            lastChar = 'o',
            currentTimeOverride = 1100L // 100ms later
        )
        assertEquals("hello", res.text)
    }

    @Test
    fun testDeliberateDoubleCharacterWithNewKeyPress() {
        // Typing first 'l' in "hel"
        val res1 = TextInputSanitizer.sanitize(
            oldText = "he",
            newText = "hel",
            keyPressSeq = 3L,
            lastConsumedSeq = 2L,
            lastTime = 1000L,
            lastChar = 'e',
            currentTimeOverride = 1000L
        )
        assertEquals("hel", res1.text)
        assertEquals(3L, res1.consumedSeq)

        // Typing second 'l' deliberately on keyboard -> new keyPressSeq (4L)
        val res2 = TextInputSanitizer.sanitize(
            oldText = "hel",
            newText = "hell",
            keyPressSeq = 4L,
            lastConsumedSeq = 3L,
            lastTime = 1000L,
            lastChar = 'l',
            currentTimeOverride = 1350L
        )
        assertEquals("hell", res2.text)
        assertEquals(4L, res2.consumedSeq)
        assertEquals('l', res2.character)
    }

    @Test
    fun testAtomicDoublingCollapse() {
        // A single event doubles the character (e.g. "" -> "aa")
        val res = TextInputSanitizer.sanitize(
            oldText = "",
            newText = "aa",
            keyPressSeq = 1L,
            lastConsumedSeq = 0L,
            lastTime = 0L,
            lastChar = null,
            currentTimeOverride = 1000L
        )
        assertEquals("a", res.text)
    }

    @Test
    fun testDeletionAndBackspace() {
        // Backspace
        val res = TextInputSanitizer.sanitize(
            oldText = "abc",
            newText = "ab",
            keyPressSeq = 5L,
            lastConsumedSeq = 5L,
            lastTime = 1000L,
            lastChar = 'c',
            currentTimeOverride = 1100L
        )
        assertEquals("ab", res.text)
    }

    @Test
    fun testPastingMultiCharacterText() {
        // Pasting "user@gmail.com"
        val res = TextInputSanitizer.sanitize(
            oldText = "",
            newText = "user@gmail.com",
            keyPressSeq = 0L,
            lastConsumedSeq = 0L,
            lastTime = 0L,
            lastChar = null,
            currentTimeOverride = 1000L
        )
        assertEquals("user@gmail.com", res.text)
    }
}
