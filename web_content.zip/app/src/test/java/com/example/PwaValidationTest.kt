package com.example

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File
import javax.imageio.ImageIO

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class PwaValidationTest {

  private fun pwaDir(): File {
    val direct = File("pwa")
    if (direct.isDirectory) return direct
    val parent = File("../pwa")
    if (parent.isDirectory) return parent
    throw AssertionError("PWA directory not found from ${File(".").absolutePath}")
  }

  @Test
  fun manifest_isValid_and_allIconsExistWithExactDimensions() {
    val root = pwaDir()
    val manifestFile = File(root, "manifest.json")
    assertTrue("manifest.json must exist", manifestFile.isFile)

    val json = JSONObject(manifestFile.readText(Charsets.UTF_8))
    assertEquals("SD TRAVEL", json.getString("name"))
    assertEquals("SD TRAVEL", json.getString("short_name"))
    assertEquals("rtl", json.getString("dir"))
    assertEquals("ar", json.getString("lang"))
    assertEquals("standalone", json.getString("display"))
    assertEquals("./index.html", json.getString("start_url"))
    assertEquals("./", json.getString("scope"))
    assertEquals("#0B1F3A", json.getString("theme_color"))
    assertEquals("#0B1F3A", json.getString("background_color"))
    assertFalse(json.optBoolean("prefer_related_applications", true))

    val icons = json.getJSONArray("icons")
    assertTrue("At least 192 and 512 icons required", icons.length() >= 3)

    val purposes = mutableSetOf<String>()
    val sizesFound = mutableSetOf<String>()
    for (i in 0 until icons.length()) {
      val icon = icons.getJSONObject(i)
      val src = icon.getString("src").removePrefix("./")
      val size = icon.getString("sizes")
      val purpose = icon.getString("purpose")
      purposes.add(purpose)
      sizesFound.add(size)

      val file = File(root, src)
      assertTrue("Icon file missing: $src", file.isFile && file.length() > 0)

      val image = ImageIO.read(file)
      assertTrue("Failed to decode PNG icon: $src", image != null)
      val expectedDim = size.split("x")[0].toInt()
      assertEquals("Width mismatch for $src", expectedDim, image!!.width)
      assertEquals("Height mismatch for $src", expectedDim, image.height)
    }

    assertTrue("192x192 icon required for Android Chrome", sizesFound.contains("192x192"))
    assertTrue("512x512 icon required for Android Chrome", sizesFound.contains("512x512"))
    assertTrue("Maskable icon required for Android adaptive icon", purposes.contains("maskable"))
    assertTrue("Any-purpose icon required", purposes.contains("any"))
  }

  @Test
  fun serviceWorker_precachesAllCoreAssets_and_allReferencedFilesExist() {
    val root = pwaDir()
    val swFile = File(root, "service-worker.js")
    assertTrue("service-worker.js must exist", swFile.isFile)
    val swText = swFile.readText(Charsets.UTF_8)

    assertTrue(swText.contains("addEventListener('install'"))
    assertTrue(swText.contains("addEventListener('activate'"))
    assertTrue(swText.contains("addEventListener('fetch'"))
    assertTrue(swText.contains("skipWaiting()"))
    assertTrue(swText.contains("clients.claim()"))

    val arrayMatch = Regex("""CORE_ASSETS\s*=\s*\[(.*?)\]""", RegexOption.DOT_MATCHES_ALL)
      .find(swText)
      ?: throw AssertionError("CORE_ASSETS array missing in service-worker.js")

    val assetPaths = Regex("""'([^']+)'""")
      .findAll(arrayMatch.groupValues[1])
      .map { it.groupValues[1] }
      .toList()

    assertTrue("CORE_ASSETS should include index.html", assetPaths.contains("./index.html"))
    assertTrue("CORE_ASSETS should include manifest.json", assetPaths.contains("./manifest.json"))
    assertTrue("CORE_ASSETS should include service-worker.js", assetPaths.contains("./service-worker.js"))

    for (asset in assetPaths) {
      if (asset == "./") continue
      val rel = asset.removePrefix("./")
      assertTrue("Precached asset missing on disk: $rel", File(root, rel).isFile)
    }
  }

  @Test
  fun indexHtml_linksValidManifestScriptsIcons_and_rtlSettings() {
    val root = pwaDir()
    val indexFile = File(root, "index.html")
    assertTrue("index.html must exist", indexFile.isFile)
    val html = indexFile.readText(Charsets.UTF_8)

    assertTrue(html.contains("""lang="ar""""))
    assertTrue(html.contains("""dir="rtl""""))
    assertTrue(html.contains("""name="mobile-web-app-capable" content="yes""""))
    assertTrue(html.contains("""rel="manifest" href="./manifest.json""""))

    val hrefs = Regex("""(?:href|src)="(\./[^"]+)"""").findAll(html).map { it.groupValues[1] }.toList()
    assertTrue("Scripts must be referenced", hrefs.contains("./js/db.js") && hrefs.contains("./js/app.js"))
    for (ref in hrefs) {
      assertTrue("Referenced file missing: $ref", File(root, ref.removePrefix("./")).isFile)
    }
  }

  @Test
  fun pwaJsModules_implementIndexedDbBlobsInstallAndBackup() {
    val root = pwaDir()
    val dbJs = File(root, "js/db.js").readText(Charsets.UTF_8)
    val backupJs = File(root, "js/backup.js").readText(Charsets.UTF_8)
    val appJs = File(root, "js/app.js").readText(Charsets.UTF_8)
    val exportJs = File(root, "js/export.js").readText(Charsets.UTF_8)

    // IndexedDB object stores & persistent Blob storage
    assertTrue(dbJs.contains("indexedDB.open"))
    assertTrue(dbJs.contains("createObjectStore('clients'"))
    assertTrue(dbJs.contains("createObjectStore('bookings'"))
    assertTrue(dbJs.contains("createObjectStore('payments'"))
    assertTrue(dbJs.contains("createObjectStore('documents'"))
    assertTrue(dbJs.contains("clientCodeNormalized"))
    assertTrue(dbJs.contains("navigator.storage.persist"))
    assertTrue(dbJs.contains("att.blob instanceof Blob"))

    // Backup & Restore with Blob <-> Base64 and duplicate prevention
    assertTrue(backupJs.contains("blobToBase64"))
    assertTrue(backupJs.contains("base64ToBlob"))
    assertTrue(backupJs.contains("skippedDuplicateClients"))

    // Install prompt, Service Worker registration, and offline awareness
    assertTrue(appJs.contains("navigator.serviceWorker.register('./service-worker.js'"))
    assertTrue(appJs.contains("beforeinstallprompt"))
    assertTrue(appJs.contains("appinstalled"))
    assertTrue(appJs.contains("shareBackupBtn"))

    // Offline XLSX & PDF exports
    assertTrue(exportJs.contains("exportReportToXlsx"))
    assertTrue(exportJs.contains("exportReportPdf"))
    assertTrue(exportJs.contains("printClientPdf"))
  }
}
