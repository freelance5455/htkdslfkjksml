package com.example

import com.example.core.network.whatsapp.WhatsAppCloudApiService
import com.example.core.network.whatsapp.WhatsAppSendResult
import com.example.features.notifications.WhatsAppNotificationCategory
import com.example.features.notifications.WhatsAppNotificationDispatcher
import com.example.features.notifications.WhatsAppPreferences
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class WhatsAppIntegrationUnitTest {

    @Test
    fun whatsAppPreferences_defaults_areConfiguredProperly() {
        val prefs = WhatsAppPreferences()
        assertFalse(prefs.isServiceEnabled)
        assertTrue(prefs.notifyOnTradeSignal)
        assertTrue(prefs.notifyOnPriceAlert)
        assertTrue(prefs.notifyOnStopLossTakeProfit)
    }

    @Test
    fun whatsAppDispatcher_disabledPreferences_doesNotDispatch() {
        val testScope = CoroutineScope(SupervisorJob() + Dispatchers.Unconfined)
        val dispatcher = WhatsAppNotificationDispatcher(scope = testScope)
        val disabledPrefs = WhatsAppPreferences(isServiceEnabled = false)

        // Dispatching with service disabled should return immediately without errors
        dispatcher.dispatchNotification(
            category = WhatsAppNotificationCategory.TRADE_SIGNAL,
            eventKey = "test_signal_1",
            message = "Test signal message",
            preferences = disabledPrefs,
            recipientPhone = "+923001234567",
            apiKey = "dummy_token",
            phoneNumberId = "12345"
        )
    }

    @Test
    fun whatsAppDispatcher_deduplication_handlesRepeatedKeys() {
        val testScope = CoroutineScope(SupervisorJob() + Dispatchers.Unconfined)
        val dispatcher = WhatsAppNotificationDispatcher(scope = testScope)
        val prefs = WhatsAppPreferences(isServiceEnabled = true)

        // First dispatch sets key timestamp
        dispatcher.dispatchNotification(
            category = WhatsAppNotificationCategory.PRICE_ALERT,
            eventKey = "price_alert_btc_65000",
            message = "BTC price crossed 65000",
            preferences = prefs,
            recipientPhone = "+923001234567",
            apiKey = "dummy_token",
            phoneNumberId = "12345"
        )

        // Second immediate dispatch should be ignored by deduplication logic
        dispatcher.dispatchNotification(
            category = WhatsAppNotificationCategory.PRICE_ALERT,
            eventKey = "price_alert_btc_65000",
            message = "BTC price crossed 65000",
            preferences = prefs,
            recipientPhone = "+923001234567",
            apiKey = "dummy_token",
            phoneNumberId = "12345"
        )
    }

    @Test
    fun whatsAppCloudApiService_missingCredentials_failsGracefully() = runBlocking {
        val service = WhatsAppCloudApiService()
        val result = service.sendTextMessage(
            phoneNumberId = "123456",
            accessToken = "", // Missing token
            recipientPhone = "+923001234567",
            messageBody = "Hello world"
        )

        assertTrue(result is WhatsAppSendResult.Failure)
        val failure = result as WhatsAppSendResult.Failure
        assertTrue(failure.errorMessage.contains("Access Token is missing", ignoreCase = true))
    }

    @Test
    fun whatsAppCloudApiService_missingPhoneNumberId_failsGracefully() = runBlocking {
        val service = WhatsAppCloudApiService()
        val result = service.sendTextMessage(
            phoneNumberId = "", // Missing Phone Number ID
            accessToken = "valid_dummy_token",
            recipientPhone = "+923001234567",
            messageBody = "Hello world"
        )

        assertTrue(result is WhatsAppSendResult.Failure)
        val failure = result as WhatsAppSendResult.Failure
        assertTrue(failure.errorMessage.contains("Phone Number ID is missing", ignoreCase = true))
    }

    @Test
    fun whatsAppConnectionStatus_fromString_parsesCorrectly() {
        assertEquals(
            com.example.features.notifications.WhatsAppConnectionStatus.Connected,
            com.example.features.notifications.WhatsAppConnectionStatus.fromString("Connected")
        )
        assertEquals(
            com.example.features.notifications.WhatsAppConnectionStatus.Disconnected,
            com.example.features.notifications.WhatsAppConnectionStatus.fromString("Disconnected")
        )
        val authReq = com.example.features.notifications.WhatsAppConnectionStatus.fromString("auth_required", "Token expired")
        assertTrue(authReq is com.example.features.notifications.WhatsAppConnectionStatus.AuthenticationRequired)
        val unavail = com.example.features.notifications.WhatsAppConnectionStatus.fromString("unavailable", "Not supported")
        assertTrue(unavail is com.example.features.notifications.WhatsAppConnectionStatus.Unavailable)
    }

    @Test
    fun whatsAppConnectionMethod_qrAndMeta_distinguished() {
        val meta = com.example.features.notifications.WhatsAppConnectionMethod.META_CLOUD_API
        val qr = com.example.features.notifications.WhatsAppConnectionMethod.QR_CONNECTION
        assertTrue(meta.isSupported)
        assertFalse(qr.isSupported)
    }

    @Test
    fun whatsAppDispatcher_persistentDeduplication_preventsDuplicates() {
        val persistentEvents = mutableSetOf<String>()
        val testScope = CoroutineScope(SupervisorJob() + Dispatchers.Unconfined)
        val dispatcher = WhatsAppNotificationDispatcher(
            scope = testScope,
            isDeduplicatedChecker = { key, _, _ -> persistentEvents.contains(key) },
            recordEventSentAction = { key, _ -> persistentEvents.add(key) }
        )
        val prefs = WhatsAppPreferences(isServiceEnabled = true)
        val eventKey = "BTCUSDT_SIGNAL_BULLISH_1700000000"

        // First dispatch should record to persistent storage
        dispatcher.dispatchNotification(
            category = WhatsAppNotificationCategory.TRADE_SIGNAL,
            eventKey = eventKey,
            message = "IQTrade Pro\nSignal Alert\nMarket: Crypto",
            preferences = prefs,
            recipientPhone = "+923001234567",
            apiKey = "test_key",
            phoneNumberId = "123456"
        )
        assertTrue(persistentEvents.contains(eventKey))

        // Create new dispatcher instance simulating app restart
        var secondDispatchTriggered = false
        val newDispatcher = WhatsAppNotificationDispatcher(
            scope = testScope,
            isDeduplicatedChecker = { key, _, _ -> persistentEvents.contains(key) },
            recordEventSentAction = { _, _ -> secondDispatchTriggered = true }
        )
        newDispatcher.dispatchNotification(
            category = WhatsAppNotificationCategory.TRADE_SIGNAL,
            eventKey = eventKey,
            message = "IQTrade Pro\nSignal Alert\nMarket: Crypto",
            preferences = prefs,
            recipientPhone = "+923001234567",
            apiKey = "test_key",
            phoneNumberId = "123456"
        )
        // Should be rejected by persistent checker
        assertFalse(secondDispatchTriggered)
    }
}
