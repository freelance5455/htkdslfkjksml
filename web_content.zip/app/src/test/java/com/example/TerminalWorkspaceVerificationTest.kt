package com.example

import androidx.compose.ui.semantics.SemanticsActions
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performClick
import com.example.core.data.chart.ChartDataState
import com.example.core.model.Timeframe
import com.example.core.model.chart.ChartConnectionState
import com.example.features.terminal.TerminalScreen
import com.example.ui.theme.IQTradeProTheme
import com.example.viewmodel.MainUiState
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class TerminalWorkspaceVerificationTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    @Test
    fun testTerminalHasNoVerticalScrollAndChartTakesDominantSpace() {
        val testState = MainUiState(
            selectedSymbol = "BTCUSDT",
            selectedTimeframe = "15m",
            chartDataState = ChartDataState(
                selectedSymbol = "BTCUSDT",
                selectedTimeframe = Timeframe.M15,
                connectionState = ChartConnectionState.Connected
            )
        )

        composeTestRule.setContent {
            IQTradeProTheme {
                TerminalScreen(
                    state = testState,
                    onOpenSymbolPicker = {},
                    onCloseSymbolPicker = {},
                    onMarketSelected = {},
                    onSearchQueryChanged = {},
                    onQuoteFilterSelected = {},
                    onInstrumentSelected = {},
                    onRefreshSymbols = {},
                    onTimeframeSelected = {},
                    onToggleIndicators = {},
                    onToggleVolume = {},
                    onToggleSignals = {},
                    onSimulatePaperTrade = { _, _ -> }
                )
            }
        }

        // 1. Verify Terminal workspace column exists
        val workspaceNode = composeTestRule.onNodeWithTag("terminal_workspace_column")
        workspaceNode.assertExists()

        // 2. Verify that there is NO vertical scrollable parent on the Terminal workspace
        val semanticsNode = workspaceNode.fetchSemanticsNode()
        val hasVerticalScroll = semanticsNode.config.contains(SemanticsActions.ScrollBy)
        assertFalse("Terminal workspace column must NOT have vertical scrolling", hasVerticalScroll)

        // 3. Verify chart container exists and is dominant
        composeTestRule.onNodeWithTag("terminal_chart_container").assertExists()

        // 4. Verify compact top controls bar exists
        composeTestRule.onNodeWithTag("terminal_top_controls_bar").assertExists()

        // 5. Verify floating buy/sell controls exist
        composeTestRule.onNodeWithTag("chart_buy_button").assertExists()
        composeTestRule.onNodeWithTag("chart_sell_button").assertExists()

        // 6. Verify settings button exists and clicking it opens the settings bottom sheet
        composeTestRule.onNodeWithTag("btn_chart_settings").performClick()
        composeTestRule.waitForIdle()

        // Verify settings toggles are accessible in bottom sheet
        composeTestRule.onNodeWithTag("toggle_indicators").assertExists()
        composeTestRule.onNodeWithTag("toggle_volume").assertExists()
        composeTestRule.onNodeWithTag("toggle_signals").assertExists()
    }

    @Test
    fun testLightweightChartsConfigVerifications() {
        // Inspect index.html configuration directly
        val assetFile = File("src/main/assets/chart/index.html")
        assertTrue("chart index.html must exist in assets", assetFile.exists())
        val htmlContent = assetFile.readText()

        // 1. One-finger horizontal touch drag configuration
        assertTrue(
            "index.html must have horzTouchDrag: true for one-finger candle panning",
            htmlContent.contains("horzTouchDrag: true")
        )

        // 2. Scale configurations: axisPressedMouseMove enables price scale and time scale dragging
        assertTrue(
            "index.html must have axisPressedMouseMove: true for price/time scale dragging",
            htmlContent.contains("axisPressedMouseMove: true")
        )

        // 3. Pinch-to-zoom configuration
        assertTrue(
            "index.html must have pinch: true for two-finger zooming",
            htmlContent.contains("pinch: true")
        )

        // 4. History preservation: window.updateCandle updates series without resetting scroll
        val updateCandleIndex = htmlContent.indexOf("window.updateCandle = function")
        assertTrue("window.updateCandle function must exist", updateCandleIndex != -1)
        val updateCandleEnd = htmlContent.indexOf("window.setVolumeVisible", updateCandleIndex)
        val updateCandleBody = htmlContent.substring(updateCandleIndex, updateCandleEnd)

        assertFalse(
            "window.updateCandle must NOT call scrollToRealTime to prevent snapping back when viewing history",
            updateCandleBody.contains("scrollToRealTime")
        )
        assertFalse(
            "window.updateCandle must NOT call scrollToPosition",
            updateCandleBody.contains("scrollToPosition")
        )
        assertTrue(
            "window.updateCandle must update the series data with candleSeries.update",
            updateCandleBody.contains("candleSeries.update")
        )
    }
}
