package com.example

import com.example.core.analysis.candlestick.CandlestickPatternEngine
import com.example.core.analysis.fibonacci.FibonacciEngine
import com.example.core.analysis.levels.SupportResistanceEngine
import com.example.core.analysis.pipeline.CompleteAnalysisPipeline
import com.example.core.analysis.risk.RiskRewardEngine
import com.example.core.analysis.structure.MarketStructureEngine
import com.example.core.model.analysis.CandlestickPatternType
import com.example.core.model.analysis.MarketTrendType
import com.example.core.model.chart.Candle
import com.example.core.model.indicator.IndicatorDirection
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Unit Test Suite for Module #6 — Complete Analysis Engine.
 * Tests:
 * 1. Candlestick Pattern Engine (17 patterns suite)
 * 2. Market Structure & Trend Engine (HH, HL, LH, LL, Breakouts)
 * 3. Support & Resistance Level Detection
 * 4. Fibonacci Retracement & Golden Pocket (61.8%)
 * 5. Volatility & Risk/Reward Calculation
 * 6. Complete Analysis Pipeline Integration & Signal Generation
 */
class CompleteAnalysisEngineTest {

    private fun generateBullishCandles(count: Int = 30, basePrice: Double = 60000.0): List<Candle> {
        val candles = mutableListOf<Candle>()
        var price = basePrice
        val now = 1700000000000L
        for (i in 0 until count) {
            val step = i * 25.0
            val open = price + step
            val close = open + 20.0
            val high = close + 10.0
            val low = open - 10.0
            candles.add(
                Candle(
                    timestamp = now + (i * 60000L),
                    open = open,
                    high = high,
                    low = low,
                    close = close,
                    volume = 1500.0
                )
            )
            price = close
        }
        return candles
    }

    private fun generateBearishCandles(count: Int = 30, basePrice: Double = 60000.0): List<Candle> {
        val candles = mutableListOf<Candle>()
        var price = basePrice
        val now = 1700000000000L
        for (i in 0 until count) {
            val step = i * 25.0
            val open = price - step
            val close = open - 20.0
            val high = open + 10.0
            val low = close - 10.0
            candles.add(
                Candle(
                    timestamp = now + (i * 60000L),
                    open = open,
                    high = high,
                    low = low,
                    close = close,
                    volume = 1500.0
                )
            )
            price = close
        }
        return candles
    }

    @Test
    fun testCandlestickPatternDetection_bullishEngulfing() {
        val now = 1700000000000L
        val candles = listOf(
            Candle(now - 120000, 105.0, 106.0, 102.0, 103.0, 100.0), // prior context
            Candle(now - 60000, 103.0, 104.0, 98.0, 99.0, 100.0), // red candle
            Candle(now, 98.0, 110.0, 97.0, 108.0, 250.0) // green candle engulfing red
        )
        val result = CandlestickPatternEngine.detectPatterns(candles, "15m")
        val engulfing = result.detectedPatterns.firstOrNull { it.patternType == CandlestickPatternType.BULLISH_ENGULFING }
        assertNotNull("Bullish Engulfing should be detected", engulfing)
        assertEquals(IndicatorDirection.BULLISH, engulfing?.classification)
    }

    @Test
    fun testCandlestickPatternDetection_hammer() {
        val now = 1700000000000L
        // Hammer: small body near top, long lower shadow >= 2x body, in downtrend context
        val candles = listOf(
            Candle(now - 180000, 115.0, 116.0, 110.0, 111.0, 100.0),
            Candle(now - 120000, 111.0, 112.0, 105.0, 106.0, 100.0),
            Candle(now - 60000, 106.0, 107.0, 100.0, 101.0, 100.0),
            Candle(now, 100.0, 101.0, 90.0, 99.5, 100.0)
        )
        val result = CandlestickPatternEngine.detectPatterns(candles, "15m")
        val hammer = result.detectedPatterns.firstOrNull { it.patternType == CandlestickPatternType.HAMMER }
        assertNotNull("Hammer pattern should be detected", hammer)
        assertEquals(IndicatorDirection.BULLISH, hammer?.classification)
    }

    @Test
    fun testMarketStructure_uptrendDetection() {
        val candles = generateBullishCandles(40, 50000.0)
        val result = MarketStructureEngine.analyzeStructure(candles)
        assertEquals("Should detect Uptrend on rising prices", MarketTrendType.UPTREND, result.trend)
        assertEquals(IndicatorDirection.BULLISH, result.structuralBias)
        assertTrue("Key swing high must be greater than 0", result.keySwingHigh > 0)
        assertTrue("Key swing low must be greater than 0", result.keySwingLow > 0)
    }

    @Test
    fun testSupportResistanceCalculation() {
        val candles = generateBullishCandles(35, 50000.0)
        val sr = SupportResistanceEngine.calculateLevels(candles)
        assertNotNull(sr)
        assertTrue("Support or resistance levels should be detected", sr.supportLevels.isNotEmpty() || sr.resistanceLevels.isNotEmpty())
    }

    @Test
    fun testFibonacciRetracement_levelsAndGoldenPocket() {
        val candles = generateBullishCandles(35, 50000.0)
        val fib = FibonacciEngine.calculateFibonacci(candles)
        assertEquals(7, fib.levels.size)
        val golden = fib.levels.firstOrNull { it.isGoldenPocket }
        assertNotNull("Golden Pocket (61.8%) must be flagged", golden)
        assertTrue("Label should start with 61.8%", golden?.percentageLabel?.startsWith("61.8%") == true)
        assertEquals(0.618, golden?.ratio ?: 0.0, 0.001)
    }

    @Test
    fun testRiskRewardEngine_bullishSetup() {
        val candles = generateBullishCandles(30, 50000.0)
        val sr = SupportResistanceEngine.calculateLevels(candles)
        val vol = RiskRewardEngine.analyzeVolatility(candles)
        val rr = RiskRewardEngine.calculateRiskReward(candles, sr, vol, IndicatorDirection.BULLISH)
        assertNotNull(rr)
        assertTrue("Risk-to-reward ratio should be calculated or have text", rr.ratioText.isNotEmpty())
    }

    @Test
    fun testCompleteAnalysisPipeline_endToEndExecution() {
        val candles = generateBullishCandles(50, 50000.0)
        val result = CompleteAnalysisPipeline.executeAnalysis(
            symbol = "BTCUSDT",
            market = "Crypto",
            candles = candles,
            isNewsConnected = false,
            activeTimeframe = "15m"
        )
        assertNotNull("Analysis result must not be null", result)
        assertEquals("BTCUSDT", result.symbol)
        assertTrue("Current price must match last candle close", result.currentPrice > 0)
        assertTrue("Confidence score must be between 0 and 100", result.overallConfidencePct in 0..100)
        assertTrue("8 Core snapshot must have 8 indicators", result.coreSnapshot.coreScores.size == 8)
        assertTrue("MTF matrix must have 10 timeframes", result.coreSnapshot.timeframeScores.size == 10)
        assertTrue("Contributions must be non-empty", result.contributions.isNotEmpty())
        assertTrue("Non-execution safety invariant must hold", result.isOnlySignalSafe)
    }
}
