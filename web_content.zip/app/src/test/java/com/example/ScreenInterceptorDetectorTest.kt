package com.example

import com.example.model.ProtectedSection
import com.example.service.ScreenInterceptorDetector
import com.example.service.WindowSnapshot
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class ScreenInterceptorDetectorTest {

    private val ownPackage = "com.aistudio.escudopin.vrtxkm"

    @Test
    fun detectsPowerDialogInSystemUi() {
        val snapshot = WindowSnapshot(
            packageName = "com.android.systemui",
            className = "com.android.systemui.globalactions.GlobalActionsDialogLite",
            windowTitle = "",
            texts = listOf("Emergencia", "Apagar", "Reiniciar"),
        )
        val result = ScreenInterceptorDetector.detect(
            snapshot = snapshot,
            ownPackageName = ownPackage,
            isDeviceAdminActive = true,
            isAccessibilityActive = true,
        )
        assertEquals(ProtectedSection.POWER_AND_REBOOT, result)
    }

    @Test
    fun detectsTecnoMemFusionRebootSetting() {
        val snapshot = WindowSnapshot(
            packageName = "com.android.settings",
            className = "com.transsion.settings.MemFusionActivity",
            windowTitle = "Función de memoria",
            texts = listOf(
                "Función de memoria",
                "Establecer RAM virtual",
                "Reiniciar ahora para aplicar los cambios",
            ),
        )
        val result = ScreenInterceptorDetector.detect(
            snapshot = snapshot,
            ownPackageName = ownPackage,
            isDeviceAdminActive = true,
            isAccessibilityActive = true,
        )
        assertEquals(ProtectedSection.POWER_AND_REBOOT, result)
    }

    @Test
    fun detectsAccessibilitySettingsWhenServiceActive() {
        val snapshot = WindowSnapshot(
            packageName = "com.android.settings",
            className = "com.android.settings.SubSettings",
            windowTitle = "Accesibilidad",
            texts = listOf("Accesibilidad", "Servicios descargados", "EscudoPIN"),
        )
        val result = ScreenInterceptorDetector.detect(
            snapshot = snapshot,
            ownPackageName = ownPackage,
            isDeviceAdminActive = true,
            isAccessibilityActive = true,
        )
        assertEquals(ProtectedSection.ACCESSIBILITY_AND_ADMIN, result)
    }

    @Test
    fun detectsDeviceAdminSettingsWhenAdminActive() {
        val snapshot = WindowSnapshot(
            packageName = "com.android.settings",
            className = "com.android.settings.applications.specialaccess.deviceadmin.DeviceAdminAdd",
            windowTitle = "Aplicaciones de administración",
            texts = listOf("Desactivar esta aplicación de administración", "EscudoPIN"),
        )
        val result = ScreenInterceptorDetector.detect(
            snapshot = snapshot,
            ownPackageName = ownPackage,
            isDeviceAdminActive = true,
            isAccessibilityActive = true,
        )
        assertEquals(ProtectedSection.ACCESSIBILITY_AND_ADMIN, result)
    }

    @Test
    fun allowsInitialDeviceAdminActivationWhenNotActiveYet() {
        val snapshot = WindowSnapshot(
            packageName = "com.android.settings",
            className = "com.android.settings.applications.specialaccess.deviceadmin.DeviceAdminAdd",
            windowTitle = "Activar aplicación de administración",
            texts = listOf("EscudoPIN", "Activar esta aplicación de administración del dispositivo"),
        )
        val result = ScreenInterceptorDetector.detect(
            snapshot = snapshot,
            ownPackageName = ownPackage,
            isDeviceAdminActive = false,
            isAccessibilityActive = true,
        )
        assertNull(result)
    }

    @Test
    fun detectsHiOsDesktopSettings() {
        val snapshot = WindowSnapshot(
            packageName = "com.transsion.hilauncher",
            className = "com.transsion.hilauncher.settings.DesktopSettingsActivity",
            windowTitle = "Configuración de escritorio",
            texts = listOf("Configuración de escritorio", "Cuadrícula de escritorio", "Efecto de página"),
        )
        val result = ScreenInterceptorDetector.detect(
            snapshot = snapshot,
            ownPackageName = ownPackage,
            isDeviceAdminActive = true,
            isAccessibilityActive = true,
        )
        assertEquals(ProtectedSection.DESKTOP_SETTINGS, result)
    }

    @Test
    fun doesNotTriggerOnNormalHomeWorkspace() {
        val snapshot = WindowSnapshot(
            packageName = "com.transsion.hilauncher",
            className = "com.transsion.hilauncher.Launcher",
            windowTitle = "Inicio",
            texts = listOf("Teléfono", "Mensajes", "Cámara", "Chrome"),
        )
        val result = ScreenInterceptorDetector.detect(
            snapshot = snapshot,
            ownPackageName = ownPackage,
            isDeviceAdminActive = true,
            isAccessibilityActive = true,
        )
        assertNull(result)
    }
}
