package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.core.analysis.pipeline.CompleteAnalysisPipeline
import com.example.core.model.chart.Candle
import com.example.core.model.indicator.IndicatorDirection
import com.example.core.data.local.IQTradeDatabase
import com.example.core.data.repository.IQTradeRepository
import com.example.core.data.security.AndroidSecureCredentialStorage
import com.example.core.model.MarketCategory
import com.example.features.news.model.NewsArticle
import com.example.features.news.model.NewsImpact
import com.example.features.news.model.NewsSentiment
import com.example.features.news.network.NewsApiGateway
import com.example.features.news.network.NewsApiResult
import com.example.viewmodel.IQTradeViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class NewsIntegrationTest {

    private lateinit var context: Context
    private lateinit var database: IQTradeDatabase
    private lateinit var secureStorage: AndroidSecureCredentialStorage

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        database = IQTradeDatabase.getInstance(context)
        secureStorage = AndroidSecureCredentialStorage(context)
    }

    @Test
    fun testNewsApiKeySavedAndClearedInVault() {
        secureStorage.saveNewsApiKey("test_news_api_key_12345")
        assertEquals("test_news_api_key_12345", secureStorage.getNewsApiKey())

        secureStorage.clearNewsApiKey()
        assertTrue(secureStorage.getNewsApiKey().isNullOrBlank())
    }

    @Test
    fun testAnalysisPipelineConsumesNewsSentimentWhenConnected() {
        val candles = (1..30).map { i ->
            Candle(
                timestamp = 1700000000000L + (i * 900000L),
                open = 60000.0 + i,
                high = 60100.0 + i,
                low = 59900.0 + i,
                close = 60050.0 + i,
                volume = 100.0
            )
        }

        // When news is connected with bullish sentiment 85
        val resultConnected = CompleteAnalysisPipeline.executeAnalysis(
            symbol = "BTCUSDT",
            market = "Crypto",
            candles = candles,
            isNewsConnected = true,
            newsSentimentScore = 85,
            newsHeadline = "Bitcoin ETF Records Massive Net Inflows",
            newsSource = "CoinDesk"
        )

        assertTrue(resultConnected.newsResult.isConnected)
        assertEquals(85, resultConnected.newsResult.sentimentScore)
        assertEquals(IndicatorDirection.BULLISH, resultConnected.newsResult.direction)
        assertEquals("Bitcoin ETF Records Massive Net Inflows", resultConnected.newsResult.headlineSample)
        assertEquals("CoinDesk", resultConnected.newsResult.source)

        // When news is disconnected
        val resultDisconnected = CompleteAnalysisPipeline.executeAnalysis(
            symbol = "BTCUSDT",
            market = "Crypto",
            candles = candles,
            isNewsConnected = false
        )
        assertFalse(resultDisconnected.newsResult.isConnected)
        assertEquals(50, resultDisconnected.newsResult.sentimentScore)
    }

    @Test
    fun testOfflineCacheFallbackWhenGatewayFails() = runBlocking {
        // Setup mock gateway that simulates network failure
        val failingGateway = object : NewsApiGateway() {
            override suspend fun fetchNews(apiKey: String, query: String, pageSize: Int): NewsApiResult {
                return NewsApiResult.NetworkError("Network Unreachable: Unable to resolve host")
            }
        }

        val repository = IQTradeRepository(
            database = database,
            secureStorage = secureStorage,
            newsApiGateway = failingGateway
        )

        // Pre-populate Room cache
        val cachedArticle = NewsArticle(
            id = "cached_fallback_1",
            headline = "Pre-cached Macro Briefing",
            source = "Macro Wire",
            publishedAt = 1700000000000L,
            url = "https://example.com/cached",
            marketCategory = MarketCategory.CRYPTO,
            relevantSymbols = listOf("BTC"),
            sentiment = NewsSentiment.NEUTRAL,
            sentimentScore = 50,
            impact = NewsImpact.LOW,
            isBreaking = false
        )
        repository.saveCachedNews(listOf(cachedArticle))

        // Execute live fetch which fails
        val result = repository.fetchLiveNews("any_key")
        assertTrue(result is NewsApiResult.NetworkError)

        // Verify repository cache preserves articles
        val cached = repository.getCachedNews()
        assertEquals(1, cached.size)
        assertEquals("Pre-cached Macro Briefing", cached.first().headline)
    }
}
