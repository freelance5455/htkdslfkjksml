package com.example

import androidx.compose.ui.geometry.Offset
import com.example.data.KeyboardLanguage
import com.example.data.UnicodeOutputFont
import com.example.keyboard.EmojiCatalog
import com.example.keyboard.KeyboardLayouts
import com.example.keyboard.SwipeDecoder
import com.example.keyboard.UnicodeFontMapper
import com.example.keyboard.WordDictionary
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class KeyboardEngineTest {

    private fun qwertyPoint(ch: Char): Offset {
        val row1 = "qwertyuiop"
        val row2 = "asdfghjkl"
        val row3 = "zxcvbnm"
        return when {
            ch in row1 -> Offset(row1.indexOf(ch) + 0.5f, 0.5f)
            ch in row2 -> Offset(row2.indexOf(ch) + 1.0f, 1.5f)
            ch in row3 -> Offset(row3.indexOf(ch) + 1.8f, 2.5f)
            else -> Offset.Zero
        }
    }

    @Test
    fun `swipe decoder recognizes common swipe words`() {
        val helloPath = "hello".map { qwertyPoint(it) }
        val helloCandidates = SwipeDecoder.decode(helloPath, emptyMap())
        assertTrue("Expected 'hello' in $helloCandidates", helloCandidates.contains("hello"))

        val worldPath = "world".map { qwertyPoint(it) }
        val worldCandidates = SwipeDecoder.decode(worldPath, emptyMap())
        assertTrue("Expected 'world' in $worldCandidates", worldCandidates.contains("world"))
    }

    @Test
    fun `word dictionary predicts prefix and bigram next words`() {
        val prefix = WordDictionary.getPredictions("th", null)
        assertTrue(prefix.any { it.startsWith("th") })

        val nextAfterThank = WordDictionary.getPredictions("", "thank")
        assertTrue(nextAfterThank.contains("you"))
    }

    @Test
    fun `word dictionary adapts to learned user slang`() {
        val learned = mapOf("bestieeee" to 8, "lowkey" to 12)
        val predictions = WordDictionary.getPredictions("best", null, KeyboardLanguage.EN, learned)
        assertEquals("bestieeee", predictions.first())

        val swipePath = "lowkey".map { qwertyPoint(it) }
        val swipeCandidates = SwipeDecoder.decode(swipePath, emptyMap(), KeyboardLanguage.EN, learned)
        assertTrue("Expected 'lowkey' in $swipeCandidates", swipeCandidates.contains("lowkey"))
    }

    @Test
    fun `multi language layouts and dictionaries work accurately`() {
        val esLayout = KeyboardLayouts.layoutFor(KeyboardLanguage.ES)
        assertTrue(esLayout.row2.contains('ñ'))
        assertFalse(esLayout.isRtl)

        val frLayout = KeyboardLayouts.layoutFor(KeyboardLanguage.FR)
        assertEquals('a', frLayout.row1.first())

        val deLayout = KeyboardLayouts.layoutFor(KeyboardLanguage.DE)
        assertEquals('z', deLayout.row1[5])

        val arLayout = KeyboardLayouts.layoutFor(KeyboardLanguage.AR)
        assertTrue(arLayout.isRtl)
        assertTrue(arLayout.row3.contains('د'))

        val esPredictions = WordDictionary.getPredictions("gra", null, KeyboardLanguage.ES)
        assertTrue("Expected 'gracias' in $esPredictions", esPredictions.contains("gracias"))

        val frPredictions = WordDictionary.getPredictions("bon", null, KeyboardLanguage.FR)
        assertTrue("Expected 'bonjour' in $frPredictions", frPredictions.contains("bonjour"))
    }

    @Test
    fun `unicode font mapper transforms ascii into stylized fonts`() {
        assertEquals("Hello", UnicodeFontMapper.transform("Hello", UnicodeOutputFont.STANDARD))
        assertEquals("𝐇𝐞𝐥𝐥𝐨", UnicodeFontMapper.transform("Hello", UnicodeOutputFont.SERIF_BOLD))
        assertEquals("𝙷𝚎𝚕𝚕𝚘", UnicodeFontMapper.transform("Hello", UnicodeOutputFont.MONOSPACE))
    }

    @Test
    fun `emoji catalog search finds matching emojis`() {
        val results = EmojiCatalog.search("heart", emptyList())
        assertTrue(results.isNotEmpty())
    }
}
