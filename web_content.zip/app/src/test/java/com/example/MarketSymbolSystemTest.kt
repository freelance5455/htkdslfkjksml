package com.example

import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.core.data.local.IQTradeDatabase
import com.example.core.data.local.entity.AppSettingsEntity
import com.example.core.data.market.CryptoSymbolProvider
import com.example.core.data.market.ForexSymbolProvider
import com.example.core.data.market.GoldSymbolProvider
import com.example.core.data.market.MarketSymbolProvider
import com.example.core.data.market.MarketSymbolRepository
import com.example.core.model.Instrument
import com.example.core.model.MarketCategory
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class MarketSymbolSystemTest {

    private lateinit var database: IQTradeDatabase

    @Before
    fun setup() {
        database = Room.inMemoryDatabaseBuilder(
            ApplicationProvider.getApplicationContext(),
            IQTradeDatabase::class.java
        ).allowMainThreadQueries().build()
    }

    @After
    fun teardown() {
        database.close()
    }

    @Test
    fun `verify three supported primary market categories exist`() {
        val categories = MarketCategory.entries
        assertEquals(3, categories.size)
        assertTrue(categories.contains(MarketCategory.CRYPTO))
        assertTrue(categories.contains(MarketCategory.FOREX))
        assertTrue(categories.contains(MarketCategory.GOLD))

        assertEquals("CRYPTO", MarketCategory.CRYPTO.id)
        assertEquals("FOREX", MarketCategory.FOREX.id)
        assertEquals("GOLD", MarketCategory.GOLD.id)
    }

    @Test
    fun `verify market categories map correctly from strings`() {
        assertEquals(MarketCategory.CRYPTO, MarketCategory.fromId("CRYPTO"))
        assertEquals(MarketCategory.CRYPTO, MarketCategory.fromId("crypto"))
        assertEquals(MarketCategory.CRYPTO, MarketCategory.fromId("SPOT")) // legacy fallback
        assertEquals(MarketCategory.FOREX, MarketCategory.fromId("FOREX"))
        assertEquals(MarketCategory.GOLD, MarketCategory.fromId("GOLD"))
        assertEquals(MarketCategory.CRYPTO, MarketCategory.fromId("UNKNOWN"))
    }

    @Test
    fun `verify crypto provider supplies dynamic crypto universe`() = runBlocking {
        val provider = CryptoSymbolProvider()
        val result = provider.fetchSymbols()
        assertTrue(result.isSuccess)
        val symbols = result.getOrNull().orEmpty()
        assertTrue(symbols.isNotEmpty())

        val btc = symbols.firstOrNull { it.symbolId == "BTCUSDT" }
        assertNotNull(btc)
        assertEquals("BTC/USDT", btc?.displayName)
        assertEquals("BTC", btc?.baseAsset)
        assertEquals("USDT", btc?.quoteAsset)
        assertEquals(MarketCategory.CRYPTO, btc?.marketCategory)

        // Verify dynamic update extensibility for Module #4
        val customInstrument = Instrument(
            symbolId = "DOGEUSDT",
            displayName = "DOGE/USDT",
            marketCategory = MarketCategory.CRYPTO,
            baseAsset = "DOGE",
            quoteAsset = "USDT",
            providerId = "BINANCE_SPOT",
            providerName = "Binance Spot"
        )
        provider.updateAvailableInstruments(listOf(customInstrument))
        val updatedResult = provider.fetchSymbols()
        assertEquals(1, updatedResult.getOrNull()?.size)
        assertEquals("DOGEUSDT", updatedResult.getOrNull()?.first()?.symbolId)
    }

    @Test
    fun `verify forex provider supplies major and cross currency pairs`() = runBlocking {
        val provider = ForexSymbolProvider()
        val result = provider.fetchSymbols()
        assertTrue(result.isSuccess)
        val symbols = result.getOrNull().orEmpty()
        assertTrue(symbols.size >= 7)

        val eurusd = symbols.firstOrNull { it.symbolId == "EURUSD" }
        assertNotNull(eurusd)
        assertEquals("EUR/USD", eurusd?.displayName)
        assertEquals(5, eurusd?.pricePrecision)
        assertEquals(MarketCategory.FOREX, eurusd?.marketCategory)
    }

    @Test
    fun `verify gold provider supplies multi-currency gold and bullion instruments`() = runBlocking {
        val provider = GoldSymbolProvider()
        val result = provider.fetchSymbols()
        assertTrue(result.isSuccess)
        val symbols = result.getOrNull().orEmpty()
        assertTrue(symbols.size >= 5)

        val xauusd = symbols.firstOrNull { it.symbolId == "XAUUSD" }
        assertNotNull(xauusd)
        assertEquals("XAU/USD", xauusd?.displayName)
        assertEquals(MarketCategory.GOLD, xauusd?.marketCategory)

        // Verifies non-XAUUSD gold instruments exist
        val xaueur = symbols.firstOrNull { it.symbolId == "XAUEUR" }
        assertNotNull(xaueur)
        val xau100oz = symbols.firstOrNull { it.symbolId == "XAU100OZ" }
        assertNotNull(xau100oz)
    }

    @Test
    fun `verify instrument search matching is case-insensitive and matches symbol and assets`() {
        val btc = Instrument(
            symbolId = "BTCUSDT",
            displayName = "BTC/USD",
            marketCategory = MarketCategory.CRYPTO,
            baseAsset = "BTC",
            quoteAsset = "USDT",
            providerId = "BINANCE",
            providerName = "Binance Spot",
            description = "Bitcoin / TetherUS"
        )

        assertTrue(btc.matchesQuery("btc"))
        assertTrue(btc.matchesQuery("BTC"))
        assertTrue(btc.matchesQuery("usdt"))
        assertTrue(btc.matchesQuery("bitcoin"))
        assertTrue(btc.matchesQuery(""))
        assertFalse(btc.matchesQuery("sol"))
    }

    @Test
    fun `verify repository caching and separation across markets`() = runBlocking {
        val repository = MarketSymbolRepository(database.cachedSymbolDao())
        repository.initializeCacheIfNeeded()

        val cryptoSymbols = repository.refreshSymbols(MarketCategory.CRYPTO).getOrNull().orEmpty()
        val forexSymbols = repository.refreshSymbols(MarketCategory.FOREX).getOrNull().orEmpty()
        val goldSymbols = repository.refreshSymbols(MarketCategory.GOLD).getOrNull().orEmpty()

        assertTrue(cryptoSymbols.isNotEmpty())
        assertTrue(forexSymbols.isNotEmpty())
        assertTrue(goldSymbols.isNotEmpty())

        // Ensure strict market separation: Crypto symbols do NOT contain Forex or Gold
        assertTrue(cryptoSymbols.all { it.marketCategory == MarketCategory.CRYPTO })
        assertTrue(forexSymbols.all { it.marketCategory == MarketCategory.FOREX })
        assertTrue(goldSymbols.all { it.marketCategory == MarketCategory.GOLD })
    }

    @Test
    fun `verify repository gracefully falls back to local cache on provider failure`() = runBlocking {
        val failingProvider = object : MarketSymbolProvider {
            override val marketCategory = MarketCategory.CRYPTO
            override val providerId = "FAILING"
            override val providerName = "Failing Provider"
            override suspend fun fetchSymbols() = Result.failure<List<Instrument>>(Exception("Network Down"))
            override fun getInitialSymbols() = emptyList<Instrument>()
        }

        val repository = MarketSymbolRepository(database.cachedSymbolDao())
        // Initialize cache first with standard provider
        repository.initializeCacheIfNeeded()
        val initialCached = repository.refreshSymbols(MarketCategory.CRYPTO).getOrNull().orEmpty()
        assertTrue(initialCached.isNotEmpty())

        // Register failing provider to simulate network drop
        repository.registerProvider(failingProvider)

        // Attempt refresh with failing provider
        val fallbackResult = repository.refreshSymbols(MarketCategory.CRYPTO)
        assertTrue("Should return cached symbols on provider failure", fallbackResult.isSuccess)
        val fallbackSymbols = fallbackResult.getOrNull().orEmpty()
        assertEquals(initialCached.size, fallbackSymbols.size)

        // Verify sync status records failure state
        val syncStatus = database.cachedSymbolDao().getSyncStatus(MarketCategory.CRYPTO.id)
        assertEquals("STALE_CACHE", syncStatus?.status)
        assertEquals("Network Down", syncStatus?.errorMessage)
    }

    @Test
    fun `verify mandatory safe defaults remain OFF`() {
        val settings = AppSettingsEntity()
        assertFalse("Smart Mode must be OFF", settings.isSmartModeEnabled)
        assertFalse("Auto Trading must be OFF", settings.isAutoTradingEnabled)
        assertFalse("Live Trading must be OFF", settings.isLiveTradingEnabled)
        assertFalse("Indicators must be OFF", settings.showIndicators)
        assertFalse("Volume must be OFF", settings.showVolume)
        assertFalse("Signal Plotting must be OFF", settings.showSignalPlotting)
    }
}
