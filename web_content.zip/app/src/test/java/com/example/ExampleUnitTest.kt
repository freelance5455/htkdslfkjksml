package com.example

import com.example.data.model.ExamType
import com.example.data.model.Subject
import com.example.data.repository.DopingRepository
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

  @Test
  fun testInitialRepositoryData() {
    val repo = DopingRepository()
    assertTrue(repo.topics.value.isNotEmpty())
    assertTrue(repo.questions.value.isNotEmpty())
    assertTrue(repo.tasks.value.isNotEmpty())
    assertTrue(repo.testCategories.isNotEmpty())
    assertEquals(ExamType.YKS_TYT, repo.userProgress.value.selectedExam)
  }

  @Test
  fun testSmartCoachGeneratesTasks() {
    val repo = DopingRepository()
    repo.generateSmartCoachPlan(20, ExamType.YKS_TYT)
    val tasks = repo.tasks.value
    assertTrue(tasks.isNotEmpty())
    assertTrue(tasks.any { it.dayOfWeek == "Bugün" })
    assertTrue(tasks.any { it.subject == Subject.MATEMATIK })
  }

  @Test
  fun testTaskToggleProgress() {
    val repo = DopingRepository()
    val firstTask = repo.tasks.value.first()
    val initialStatus = firstTask.isCompleted

    repo.toggleTask(firstTask.id)
    val updatedTask = repo.tasks.value.first { it.id == firstTask.id }
    assertEquals(!initialStatus, updatedTask.isCompleted)
  }

  @Test
  fun testRecordQuestionAnswerAndSubjectProgress() {
    val repo = DopingRepository()
    val qId = "q_mat_1"
    val initialCorrect = repo.userProgress.value.totalCorrect

    repo.recordQuestionAnswer(qId, true)
    assertEquals(initialCorrect + 1, repo.userProgress.value.totalCorrect)
    assertFalse(repo.userProgress.value.errorNotebookQuestionIds.contains(qId))

    // Check subject progress updated
    val matSp = repo.subjectProgress.value[Subject.MATEMATIK]
    assertNotNull(matSp)
    assertTrue(matSp!!.totalSolved > 0)
  }

  @Test
  fun testCalendarTaskAndReminder() {
    val repo = DopingRepository()
    val testDate = "2026-11-15"
    repo.addTask(
      title = "Özel Geometri Tekrarı",
      subject = Subject.MATEMATIK,
      questions = 30,
      minutes = 45,
      priority = "Yüksek",
      scheduledDate = testDate,
      reminderTime = "20:30",
      hasReminder = true,
      notes = "Öklid kuralları"
    )

    val added = repo.tasks.value.find { it.scheduledDate == testDate }
    assertNotNull(added)
    assertTrue(added!!.hasReminder)
    assertEquals("20:30", added.reminderTime)

    // Toggle reminder
    repo.toggleReminder(added.id)
    val toggled = repo.tasks.value.find { it.id == added.id }
    assertFalse(toggled!!.hasReminder)
  }

  @Test
  fun testAchievementBadgesMilestones() {
    val repo = DopingRepository()
    val badges = repo.getAchievementBadges()
    assertTrue(badges.isNotEmpty())
    assertTrue(badges.any { it.id == "century" })
    assertTrue(badges.any { it.id == "streak7" })

    // Initial total questions is 412, so 100 questions badge should be unlocked
    val centuryBadge = badges.first { it.id == "century" }
    assertTrue(centuryBadge.isUnlocked)
  }

  @Test
  fun testDailyTrendPoints() {
    val repo = DopingRepository()
    val trend = repo.getDailySolvedTrend()
    assertEquals(7, trend.size)
    assertTrue(trend.all { it.solvedQuestions > 0 })
    assertEquals("12 Kas", trend.last().dayLabel)
  }
}
