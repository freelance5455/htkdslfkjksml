package com.example

import com.example.data.model.BusinessSettings
import com.example.data.model.ExpenseEntity
import com.example.data.model.TransactionEntity
import com.example.util.BackupManager
import com.example.util.FinancialMath
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleUnitTest {

    @Test
    fun testWithdrawalCalculation_RequiredTestCase() {
        // Commission received and transaction charge deducted are the profit to us.
        // Withdrawal Amount: ₹10,000
        // Platform Fee: 1.5% = ₹150 (deducted from customer payout)
        // Commission Received: 0.2% = ₹20
        // Transaction Charge: ₹20 (deducted from customer payout, retained by business)
        // Amount Payable to Customer = ₹10,000 − ₹150 − ₹20 = ₹9,830
        // Profit to Us = ₹20 Commission + ₹20 Transaction Charge = ₹40.00

        val result = FinancialMath.calculateWithdrawal(
            amount = 10000.0,
            platformFeePercent = 1.5,
            commissionPercent = 0.2,
            transactionCharge = 20.0,
            otherCosts = 0.0,
            retainChargeAsIncome = true
        )

        assertEquals(150.00, result.platformFeeAmount, 0.001)
        assertEquals(20.00, result.commissionAmount, 0.001)
        assertEquals(9830.00, result.customerPayout, 0.001)
        assertEquals(40.00, result.grossProfit, 0.001)
        assertEquals(40.00, result.netProfit, 0.001)
    }

    @Test
    fun testWithdrawalCalculation_ThirdPartyChargeTreatment() {
        // When transaction charge is paid to a third party rather than retained:
        // Gross Profit = Commission Received = ₹20.00
        val result = FinancialMath.calculateWithdrawal(
            amount = 10000.0,
            platformFeePercent = 1.5,
            commissionPercent = 0.2,
            transactionCharge = 20.0,
            otherCosts = 0.0,
            retainChargeAsIncome = false
        )

        assertEquals(9830.00, result.customerPayout, 0.001)
        assertEquals(20.00, result.grossProfit, 0.001)
    }

    @Test
    fun testWithdrawalCalculation_DecimalPrecision() {
        // Test decimal amount like ₹10,250.50 and decimal percentages like 1.25%
        val result = FinancialMath.calculateWithdrawal(
            amount = 10250.50,
            platformFeePercent = 1.25,
            commissionPercent = 0.18,
            transactionCharge = 25.50,
            otherCosts = 5.00,
            retainChargeAsIncome = true
        )

        // 10250.50 * 1.25% = 128.13
        assertEquals(128.13, result.platformFeeAmount, 0.01)
        // 10250.50 * 0.18% = 18.45
        assertEquals(18.45, result.commissionAmount, 0.01)
        // Payout = 10250.50 - 128.13 - 25.50 = 10096.87
        assertEquals(10096.87, result.customerPayout, 0.01)
        // Gross Profit = 18.45 (Commission) + 25.50 (Tx Charge) = 43.95
        assertEquals(43.95, result.grossProfit, 0.01)
        // Net Profit = 43.95 - 5.00 = 38.95
        assertEquals(38.95, result.netProfit, 0.01)
    }

    @Test
    fun testBillPaymentCalculation_RequiredTestCase() {
        // Test case from user brief:
        // Bill Amount: ₹1,00,000
        // Platform Fee: 1.5% = ₹1,500
        // Service Charge: 1.5% = ₹1,500
        // Total Customer Charge: ₹3,000 (3%)
        // Commission Received: 0.2% of bill amount = ₹200
        // Other Costs: ₹0
        // Expected Gross Profit = ₹1,500 + ₹200 = ₹1,700
        // Expected Net Profit before operating expenses and taxes = ₹1,700

        val result = FinancialMath.calculateBillPayment(
            billAmount = 100000.0,
            platformFeePercent = 1.5,
            isManualFee = false,
            manualPlatformFee = 0.0,
            serviceChargePercent = 1.5,
            commissionPercent = 0.2,
            otherCosts = 0.0
        )

        assertEquals(1500.00, result.platformFeeAmount, 0.001)
        assertEquals(1500.00, result.serviceChargeAmount, 0.001)
        assertEquals(3000.00, result.totalCustomerCharge, 0.001)
        assertEquals(3.00, result.totalCustomerChargePercent, 0.001)
        assertEquals(200.00, result.commissionAmount, 0.001)
        assertEquals(1700.00, result.grossProfit, 0.001)
        assertEquals(1700.00, result.netProfit, 0.001)
    }

    @Test
    fun testBillPaymentCalculation_ManualFeeMode() {
        // Manual Platform Fee entry mode
        val result = FinancialMath.calculateBillPayment(
            billAmount = 50000.0,
            platformFeePercent = 0.0,
            isManualFee = true,
            manualPlatformFee = 700.0,
            serviceChargePercent = 1.5,
            commissionPercent = 0.2,
            otherCosts = 50.0
        )

        assertEquals(700.00, result.platformFeeAmount, 0.001)
        // 50,000 * 1.5% = 750
        assertEquals(750.00, result.serviceChargeAmount, 0.001)
        assertEquals(1450.00, result.totalCustomerCharge, 0.001)
        // 50,000 * 0.2% = 100
        assertEquals(100.00, result.commissionAmount, 0.001)
        // Gross = 750 + 100 = 850
        assertEquals(850.00, result.grossProfit, 0.001)
        // Net = 850 - 50 = 800
        assertEquals(800.00, result.netProfit, 0.001)
    }

    @Test
    fun testInputValidationRules() {
        // Amount validation
        val emptyVal = FinancialMath.validateAmount("", "Amount")
        assertFalse(emptyVal.isValid)

        val negativeVal = FinancialMath.validateAmount("-500", "Amount")
        assertFalse(negativeVal.isValid)

        val zeroVal = FinancialMath.validateAmount("0", "Amount", allowZero = false)
        assertFalse(zeroVal.isValid)

        val zeroAllowed = FinancialMath.validateAmount("0", "Amount", allowZero = true)
        assertTrue(zeroAllowed.isValid)

        val validVal = FinancialMath.validateAmount("10250.50", "Amount")
        assertTrue(validVal.isValid)

        // Percentage validation
        val invalidPct = FinancialMath.validatePercentage("120", "Platform Fee", 0.0, 50.0)
        assertFalse(invalidPct.isValid)

        val validPct = FinancialMath.validatePercentage("1.25", "Platform Fee")
        assertTrue(validPct.isValid)

        // Charge validation
        val invalidChg = FinancialMath.validateCharge("-10", "Charge")
        assertFalse(invalidChg.isValid)

        val validChg = FinancialMath.validateCharge("20.50", "Charge")
        assertTrue(validChg.isValid)
    }

    @Test
    fun testBackupManager_ExportAndParse() {
        val settings = BusinessSettings(businessName = "Test Firm")
        val transactions = listOf(
            TransactionEntity(
                id = 1,
                txId = "TXN-001",
                type = "WITHDRAWAL",
                amount = 10000.0,
                platformFeePercent = 1.5,
                platformFeeAmount = 150.0,
                commissionPercent = 0.2,
                commissionAmount = 20.0,
                transactionCharge = 20.0,
                otherCosts = 0.0,
                customerPayoutOrCharge = 9830.0,
                grossProfit = -110.0,
                netProfit = -110.0
            )
        )
        val expenses = listOf(
            ExpenseEntity(
                id = 1,
                name = "POS Machine",
                category = "Bank charges",
                amount = 450.0
            )
        )

        val json = BackupManager.generateBackupJson(settings, transactions, expenses)
        assertTrue(json.contains("Test Firm"))
        assertTrue(json.contains("TXN-001"))

        val parsed = BackupManager.parseBackupJson(json)
        assertTrue(parsed.isSuccess)
        val data = parsed.getOrThrow()
        assertEquals("Test Firm", data.settings?.businessName)
        assertEquals(1, data.transactions.size)
        assertEquals("TXN-001", data.transactions[0].txId)
        assertEquals(1, data.expenses.size)
        assertEquals("POS Machine", data.expenses[0].name)
    }
}
