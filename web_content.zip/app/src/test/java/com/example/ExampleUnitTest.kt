package com.example

import org.junit.Assert.*
import org.junit.Test

/**
 * Unit tests verifying MTX models and dark user verification persistence logic.
 */
class ExampleUnitTest {
  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun videoItem_dataIntegrity() {
    val item = VideoItem(
      id = 1,
      title = "Test Video",
      category = "Action",
      duration = "05:00",
      views = "10",
      description = "Test description",
      videoUri = "/path/to/video.mp4",
      isLocalFile = true,
      isPublished = true,
      isDark = false
    )
    assertEquals(1, item.id)
    assertEquals("Test Video", item.title)
    assertTrue(item.isLocalFile)
    assertTrue(item.isPublished)
    assertFalse(item.isDark)
  }

  @Test
  fun darkVideoItem_dataIntegrity() {
    val darkItem = VideoItem(
      id = 301,
      title = "Dark Protocol",
      category = "Dark Thrillers",
      duration = "14:28",
      views = "340K",
      description = "Classified stream",
      videoUri = "https://example.com/dark.mp4",
      isLocalFile = false,
      isPublished = true,
      isDark = true
    )
    assertEquals(301, darkItem.id)
    assertTrue(darkItem.isDark)
    assertEquals("Dark Thrillers", darkItem.category)
  }

  @Test
  fun photoItem_dataIntegrity() {
    val photo = PhotoItem(
      id = 1,
      title = "Movie Poster",
      category = "Posters",
      imageUri = "/data/photo.jpg",
      isLocalFile = true,
      likes = 25,
      isPublished = true,
      isDark = false
    )
    assertEquals(1, photo.id)
    assertEquals("Movie Poster", photo.title)
    assertTrue(photo.isLocalFile)
    assertTrue(photo.isPublished)
    assertFalse(photo.isDark)
  }

  @Test
  fun darkUserAuth_approvalState() {
    val auth = DarkUserAuth(
      userId = "user_alpha_123",
      userName = "NightRider",
      facePhotoUri = "/data/face.jpg",
      isApproved = true,
      status = "approved"
    )
    assertEquals("user_alpha_123", auth.userId)
    assertEquals("NightRider", auth.userName)
    assertTrue(auth.isApproved)
    assertEquals("approved", auth.status)
  }
}
