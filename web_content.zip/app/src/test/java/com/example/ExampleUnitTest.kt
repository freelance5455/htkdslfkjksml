package com.example

import com.example.model.HapticFeedbackStyle
import com.example.model.QrCategory
import com.example.model.QrParser
import com.example.util.UrlMetadataFetcher
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun testParseUrl() {
        val parsed = QrParser.parse("https://google.com/search?q=qr")
        assertEquals(QrCategory.URL, parsed.category)
        assertEquals("google.com", parsed.title)
        assertTrue(parsed.isSecureWeb)
    }

    @Test
    fun testParseWifi() {
        val parsed = QrParser.parse("WIFI:S:MyWifiNetwork;T:WPA;P:Secret123;;")
        assertEquals(QrCategory.WIFI, parsed.category)
        assertEquals("MyWifiNetwork", parsed.title)
        assertEquals("Secret123", parsed.extraDetails["Password"])
    }

    @Test
    fun testParseContact() {
        val vcard = """
            BEGIN:VCARD
            VERSION:3.0
            FN:Jane Doe
            TEL:+123456789
            EMAIL:jane@example.com
            END:VCARD
        """.trimIndent()
        val parsed = QrParser.parse(vcard)
        assertEquals(QrCategory.CONTACT, parsed.category)
        assertEquals("Jane Doe", parsed.title)
        assertEquals("+123456789", parsed.extraDetails["Phone"])
    }

    @Test
    fun testParsePayment() {
        val upi = "upi://pay?pa=store@upi&pn=StoreName&am=25.00"
        val parsed = QrParser.parse(upi)
        assertEquals(QrCategory.PAYMENT, parsed.category)
        assertEquals("Pay StoreName", parsed.title)
        assertEquals("25.00", parsed.extraDetails["Amount"])
    }

    @Test
    fun testHapticFeedbackStyles() {
        val styles = HapticFeedbackStyle.values()
        assertEquals(4, styles.size)
        assertTrue(styles.contains(HapticFeedbackStyle.LIGHT_TICK))
        assertTrue(styles.contains(HapticFeedbackStyle.CRISP_CLICK))
        assertTrue(styles.contains(HapticFeedbackStyle.DOUBLE_TAP))
        assertTrue(styles.contains(HapticFeedbackStyle.HEAVY_CONFIRM))
    }

    @Test
    fun testUrlMetadataDefaultFaviconUrl() {
        val fav = UrlMetadataFetcher.getDefaultFaviconUrl("example.com")
        assertNotNull(fav)
        assertTrue(fav.contains("example.com"))
        assertTrue(fav.startsWith("https://"))
    }

    @Test
    fun testUrlMetadataHtmlParsing() {
        val html = """
            <!DOCTYPE html>
            <html>
            <head>
                <title>Scanova QR Scanner Official Portal</title>
                <meta property="og:description" content="Fast, private QR code scanning and generation.">
                <link rel="icon" href="/favicon.png">
            </head>
            <body></body>
            </html>
        """.trimIndent()

        val parsed = UrlMetadataFetcher.parseHtmlForTesting(html, "https://scanova.app")
        assertEquals("Scanova QR Scanner Official Portal", parsed.title)
        assertEquals("Fast, private QR code scanning and generation.", parsed.description)
        assertEquals("https://scanova.app/favicon.png", parsed.faviconUrl)
        assertEquals("scanova.app", parsed.host)
    }
}
