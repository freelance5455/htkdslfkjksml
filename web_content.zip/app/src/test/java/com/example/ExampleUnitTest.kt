package com.example

import com.example.model.EqualizerDefaults
import com.example.model.Song
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {
  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun test10BandEqualizerPresets() {
    val presets = EqualizerDefaults.BUILT_IN_PRESETS
    assertTrue(presets.isNotEmpty())
    val powerampPreset = presets.find { it.id == "poweramp_bass_treble" }
    assertNotNull(powerampPreset)
    assertEquals(10, powerampPreset!!.toBands().size)
    assertTrue(powerampPreset.bassTone > 0)
    assertTrue(powerampPreset.trebleTone > 0)
    assertTrue(powerampPreset.dvcEnabled)
  }

  @Test
  fun testSongWaveformGeneration() {
    val peaks = Song.generateWaveformPeaks(seed = 42, count = 80)
    assertEquals(80, peaks.size)
    assertTrue(peaks.all { it in 0.05f..1.0f })
  }
}

