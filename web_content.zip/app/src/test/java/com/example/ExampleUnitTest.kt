package com.example

import com.example.data.model.ActionType
import com.example.data.model.AssistantState
import com.example.data.model.AutomationRoutine
import com.example.data.model.MessageSender
import com.example.data.model.RoutineStep
import com.example.data.model.VoiceLanguage
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun assistantStates_containExpectedValues() {
        val states = AssistantState.values()
        assertTrue(states.contains(AssistantState.IDLE))
        assertTrue(states.contains(AssistantState.LISTENING))
        assertTrue(states.contains(AssistantState.THINKING))
        assertTrue(states.contains(AssistantState.SPEAKING))
        assertTrue(states.contains(AssistantState.EXECUTING))
    }

    @Test
    fun voiceLanguages_supported() {
        val languages = VoiceLanguage.values().map { it.code }
        assertTrue(languages.contains("en-US"))
        assertTrue(languages.contains("hi-IN"))
        assertTrue(languages.contains("en-IN"))
    }

    @Test
    fun automationRoutine_structureIsValid() {
        val routine = AutomationRoutine(
            id = "test_routine",
            name = "Test Night",
            description = "Turns off lights",
            voiceTrigger = "Good Night",
            iconName = "NightsStay",
            steps = listOf(
                RoutineStep("Turn off torch", ActionType.TOGGLE_TORCH, "off"),
                RoutineStep("Mute volume", ActionType.ADJUST_VOLUME, "0")
            )
        )
        assertEquals(2, routine.steps.size)
        assertEquals(ActionType.TOGGLE_TORCH, routine.steps[0].actionType)
        assertEquals("0", routine.steps[1].param)
    }
}
