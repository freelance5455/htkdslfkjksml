package com.example

import com.example.data.local.MessageEntity
import com.example.data.remote.GeminiClient
import com.example.ui.components.MarkdownBlock
import com.example.ui.components.parseMarkdownBlocks
import com.example.voice.VoiceAssistantManager
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun markdownParser_parsesHeadingsListsAndCodeBlocks() {
        val sample = """
            ## AI Overview
            Artificial intelligence enables computers to reason.
            
            - Natural Language
            - Computer Vision
            
            ```python
            print("Hello from Raynox AI")
            ```
        """.trimIndent()

        val blocks = parseMarkdownBlocks(sample)
        assertTrue(blocks.any { it is MarkdownBlock.Heading && it.text == "AI Overview" })
        assertTrue(blocks.any { it is MarkdownBlock.Paragraph && it.text.contains("Artificial intelligence") })
        assertTrue(blocks.any { it is MarkdownBlock.BulletItem && it.text == "Natural Language" })
        assertTrue(blocks.any { it is MarkdownBlock.CodeBlock && it.language == "python" && it.code.contains("Raynox AI") })
    }

    @Test
    fun markdownParser_parsesTables() {
        val tableSample = """
            | Feature | Status |
            | --- | --- |
            | Streaming | Active |
            | Multimodal | Ready |
        """.trimIndent()

        val blocks = parseMarkdownBlocks(tableSample)
        val tableBlock = blocks.filterIsInstance<MarkdownBlock.Table>().firstOrNull()
        assertTrue(tableBlock != null)
        assertEquals(listOf("Feature", "Status"), tableBlock?.headers)
        assertEquals(2, tableBlock?.rows?.size)
        assertEquals(listOf("Streaming", "Active"), tableBlock?.rows?.get(0))
    }

    @Test
    fun raynoxIdentity_systemInstructionConfigured() {
        val instruction = GeminiClient.buildSystemInstruction("Aryan", "Focus on clean architecture")
        val text = instruction.parts.first().text.orEmpty()
        assertTrue(text.contains("You are RAYNOX AI"))
        assertTrue(text.contains("Your identity is RAYNOX AI"))
        assertTrue(text.contains("Never unnecessarily mention internal model providers"))
        assertTrue(text.contains("Aryan"))
    }

    @Test
    fun modelBranding_displaysRaynoxNames() {
        assertEquals("Raynox Core", GeminiClient.getModelDisplayName(GeminiClient.MODEL_RAYNOX_CORE))
        assertEquals("Raynox Pro", GeminiClient.getModelDisplayName(GeminiClient.MODEL_RAYNOX_PRO))
    }

    @Test
    fun geminiConversationBuilder_preservesMultiTurnHistory() {
        val history = listOf(
            MessageEntity(id = 1, conversationId = "c1", role = "user", content = "Hi"),
            MessageEntity(id = 2, conversationId = "c1", role = "assistant", content = "Hi! I'm Raynox. How can I help you today?"),
            MessageEntity(id = 3, conversationId = "c1", role = "user", content = "What is artificial intelligence?")
        )

        val contents = GeminiClient.buildConversationContents(history)
        assertEquals(3, contents.size)
        assertEquals("user", contents[0].role)
        assertEquals("Hi", contents[0].parts.first().text)
        assertEquals("model", contents[1].role)
        assertEquals("Hi! I'm Raynox. How can I help you today?", contents[1].parts.first().text)
        assertEquals("user", contents[2].role)
        assertEquals("What is artificial intelligence?", contents[2].parts.first().text)
    }

    @Test
    fun ttsMarkdownStripper_cleansFormattingAndCodeBlocks() {
        val raw = "**Hello!** Here is `inlineCode` and:\n```kotlin\nval x = 1\n```"
        val spoken = VoiceAssistantManager.stripMarkdownForSpeech(raw)
        assertTrue(spoken.contains("Hello!"))
        assertTrue(spoken.contains("inlineCode"))
        assertTrue(!spoken.contains("```"))
    }

    @Test
    fun dateTimeHelper_generatesAccurateISTContext() {
        val ctx = com.example.util.DateTimeHelper.getLiveTemporalContext()
        assertTrue(ctx.istTime12h.isNotBlank())
        assertTrue(ctx.istDateFormatted.isNotBlank())
        assertTrue(ctx.todayDate.isNotBlank())
        assertTrue(ctx.tomorrowDate.isNotBlank())
        assertTrue(ctx.yesterdayDate.isNotBlank())
        assertTrue(ctx.dayAfterTomorrowDate.isNotBlank())
        assertTrue(ctx.daysInCurrentMonth in 28..31)
        assertTrue(ctx.daysRemainingInMonth >= 0)
        assertTrue(ctx.currentYear >= 2024)
        assertEquals("Asia/Kolkata", ctx.timeZoneId)

        val header = com.example.util.DateTimeHelper.formatSystemPromptTemporalHeader()
        assertTrue(header.contains("LIVE DEVICE TEMPORAL CONTEXT"))
        assertTrue(header.contains("Asia/Kolkata"))
        assertTrue(header.contains(ctx.todayDate))
    }
}
