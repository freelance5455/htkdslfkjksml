package com.example

import com.example.util.DateTimeUtils
import org.junit.Assert.assertEquals
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun timeParsingAndFormatting_isCorrect() {
        assertEquals("16:00", DateTimeUtils.parseTo24h("16:00"))
        assertEquals("4:00 م", DateTimeUtils.formatTime12h("16:00"))
        assertEquals("9:30 ص", DateTimeUtils.formatTime12h("09:30"))
        assertEquals("25:00", DateTimeUtils.formatCountdownTimer(1500))
        assertEquals("00:05", DateTimeUtils.formatCountdownTimer(5))
    }
}
