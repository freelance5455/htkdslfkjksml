package com.example

import com.example.data.local.MemberEntity
import com.example.ui.model.CharghatData
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun addition_isCorrect() {
        assertEquals(4, 2 + 2)
    }

    @Test
    fun defaultAdminPin_is1402() {
        assertEquals("1402", CharghatData.DEFAULT_ADMIN_PIN)
    }

    @Test
    fun charghatUnits_containsAllExpectedUnits() {
        assertTrue(CharghatData.units.contains("চারঘাট উপজেলা ছাত্রলীগ"))
        assertTrue(CharghatData.units.contains("চারঘাট পৌরসভা ছাত্রলীগ"))
        assertTrue(CharghatData.units.contains("ইউসুফপুর ইউনিয়ন ছাত্রলীগ"))
        assertTrue(CharghatData.units.contains("সরদহ ইউনিয়ন ছাত্রলীগ"))
    }

    @Test
    fun leaderEntity_storesFieldsCorrectly() {
        val leader = MemberEntity(
            type = "leader",
            union = "চারঘাট উপজেলা ছাত্রলীগ",
            ward = "১নং ওয়ার্ড",
            sovapotiName = "আরিফুল",
            sovapotiMobile = "01712345678",
            sovapotiFb = "https://facebook.com/ariful"
        )
        assertEquals("leader", leader.type)
        assertEquals("আরিফুল", leader.sovapotiName)
        assertEquals("https://facebook.com/ariful", leader.sovapotiFb)
    }
}
