package com.example

import com.example.engine.ProfileCatalog
import com.example.model.DeviceType
import com.example.model.SimulationStats
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun testProfileCatalog_generatesDistinctProfiles() {
        val profile1 = ProfileCatalog.createUniqueProfile(index = 1)
        val profile2 = ProfileCatalog.createUniqueProfile(index = 2)
        val profile35 = ProfileCatalog.createUniqueProfile(index = 35)

        assertNotNull(profile1.userAgent)
        assertNotNull(profile2.userAgent)
        assertNotNull(profile35.userAgent)

        // Ensure consecutive visits have different user agents and IP signatures
        assertNotEquals(profile1.userAgent, profile2.userAgent)
        assertNotEquals(profile1.simulatedIp, profile2.simulatedIp)
        assertNotEquals(profile1.id, profile2.id)

        // Verify index 35 creates a valid unique profile
        assertTrue(profile35.simulatedIp.isNotEmpty())
        assertTrue(profile35.acceptLanguage.isNotEmpty())
    }

    @Test
    fun testSimulationStats_progressCalculation() {
        val stats = SimulationStats(
            totalScheduled = 35,
            completedCount = 14
        )
        assertEquals(14f / 35f, stats.progress, 0.001f)
    }

    @Test
    fun testSimulationStats_requestsPerSecond() {
        val stats = SimulationStats(
            totalScheduled = 35,
            completedCount = 10,
            elapsedMs = 2000L // 2 seconds
        )
        assertEquals(5.0f, stats.requestsPerSecond, 0.1f)
    }
}
