package com.example

import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performScrollToIndex
import androidx.compose.ui.test.performTouchInput
import androidx.compose.ui.test.swipeDown
import androidx.compose.ui.test.swipeUp
import com.example.core.analysis.pipeline.CompleteAnalysisPipeline
import com.example.core.model.chart.Candle
import com.example.features.analysis.AnalysisScreen
import com.example.ui.theme.IQTradeProTheme
import com.example.viewmodel.MainUiState
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class AnalysisScreenComposeTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    @Test
    fun testAnalysisScreenRendersWithEmptyCandles() {
        composeTestRule.setContent {
            IQTradeProTheme {
                val state = MainUiState(
                    selectedSymbol = "BTCUSDT",
                    selectedTimeframe = "15m"
                )
                AnalysisScreen(state = state)
            }
        }
    }

    @Test
    fun testAnalysisScreenRendersWithCalculatedResult() {
        val now = System.currentTimeMillis()
        val candles = (1..30).map { i ->
            Candle(
                timestamp = now - (30 - i) * 60000L,
                open = 100.0 + i,
                high = 102.0 + i,
                low = 99.0 + i,
                close = 101.0 + i,
                volume = 500.0
            )
        }
        val result = CompleteAnalysisPipeline.executeAnalysis(
            symbol = "BTCUSDT",
            market = "CRYPTO",
            candles = candles,
            isNewsConnected = false,
            activeTimeframe = "15m"
        )
        composeTestRule.setContent {
            IQTradeProTheme {
                val state = MainUiState(
                    selectedSymbol = "BTCUSDT",
                    selectedTimeframe = "15m",
                    completeAnalysisResult = result
                )
                AnalysisScreen(state = state)
            }
        }
    }

    @Test
    fun testAnalysisScreenScrollingReachesAllSections() {
        val now = System.currentTimeMillis()
        val candles = (1..30).map { i ->
            Candle(
                timestamp = now - (30 - i) * 60000L,
                open = 100.0 + i,
                high = 102.0 + i,
                low = 99.0 + i,
                close = 101.0 + i,
                volume = 500.0
            )
        }
        val result = CompleteAnalysisPipeline.executeAnalysis(
            symbol = "BTCUSDT",
            market = "CRYPTO",
            candles = candles,
            isNewsConnected = false,
            activeTimeframe = "15m"
        )
        composeTestRule.setContent {
            IQTradeProTheme {
                val state = MainUiState(
                    selectedSymbol = "BTCUSDT",
                    selectedTimeframe = "15m",
                    completeAnalysisResult = result
                )
                AnalysisScreen(state = state)
            }
        }

        // Verify LazyColumn scroll container exists and handles swipe gestures smoothly
        val scrollContainer = composeTestRule.onNodeWithTag("analysis_screen_scroll")
        scrollContainer.assertExists()

        // Top section is present initially
        composeTestRule.onNodeWithTag("analysis_hero_card").assertExists()

        // Swipe UP to move screen down
        scrollContainer.performTouchInput {
            swipeUp()
        }

        // Swipe DOWN to move screen back up
        scrollContainer.performTouchInput {
            swipeDown()
        }

        // Verify all analytical sections are reachable via LazyColumn scrolling
        scrollContainer.performScrollToIndex(0)
        composeTestRule.onNodeWithTag("analysis_hero_card").assertExists()

        scrollContainer.performScrollToIndex(3)
        composeTestRule.onNodeWithTag("analysis_score_screen").assertExists()

        scrollContainer.performScrollToIndex(4)
        composeTestRule.onNodeWithTag("analysis_candlestick_card").assertExists()

        scrollContainer.performScrollToIndex(5)
        composeTestRule.onNodeWithTag("analysis_structure_card").assertExists()

        scrollContainer.performScrollToIndex(6)
        composeTestRule.onNodeWithTag("analysis_fibonacci_card").assertExists()

        scrollContainer.performScrollToIndex(7)
        composeTestRule.onNodeWithTag("analysis_risk_reward_card").assertExists()
    }
}
