package com.example

import com.example.localization.AppLocalization
import com.example.model.JobListing
import com.example.model.UserProfile
import com.example.ui.components.formatInr
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class JobyDomainUnitTest {

  @Test
  fun jobListing_toCreateMap_enforcesZeroFeeAndHazardousMinAge() {
    val job = JobListing(
      employerId = "emp_1",
      companyName = "MetroBuild",
      title = "Site Electrician",
      applicationFee = 500L, // should be forced to 0L
      minAge = 16L,
      isHazardousOrRestricted = true
    )
    val payload = job.toCreateMap()
    assertEquals(0L, payload["applicationFee"])
    assertEquals(18L, payload["minAge"])
    assertEquals("PENDING", payload["moderationStatus"])
  }

  @Test
  fun userProfile_completionPercent_calculatesAccurately() {
    val partial = UserProfile(
      userId = "u1",
      displayName = "Aarav",
      city = "Pune",
      pincode = "411001"
    )
    assertTrue(partial.profileCompletionPercent() in 30..60)

    val full = partial.copy(
      phone = "+919876543210",
      education = "B.Tech",
      skills = listOf("Kotlin"),
      resumeLabel = "aarav_cv.pdf",
      bio = "Android engineer"
    )
    assertEquals(100, full.profileCompletionPercent())
  }

  @Test
  fun localization_supportsEnglishHindiTamil() {
    assertEquals("Home", AppLocalization.forCode("EN").navHome)
    assertEquals("होम", AppLocalization.forCode("HI").navHome)
    assertEquals("முகப்பு", AppLocalization.forCode("TA").navHome)
  }

  @Test
  fun formatInr_usesIndianCommas() {
    assertEquals("₹1,00,000", formatInr(100000L))
    assertEquals("₹450", formatInr(450L))
  }
}
