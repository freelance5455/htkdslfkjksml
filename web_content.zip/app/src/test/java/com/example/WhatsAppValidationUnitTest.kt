package com.example

import com.example.features.notifications.isValidWhatsAppNumber
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class WhatsAppValidationUnitTest {

    @Test
    fun pakistaniWhatsAppNumber_standardFormat_isValid() {
        // Pakistan international format: +92 followed by 10 digits
        assertTrue(isValidWhatsAppNumber("+923001234567"))
        assertTrue(isValidWhatsAppNumber("+923211234567"))
        assertTrue(isValidWhatsAppNumber("+923451234567"))
        assertTrue(isValidWhatsAppNumber("+923331234567"))
    }

    @Test
    fun pakistaniWhatsAppNumber_withSpacesAndDashes_isValid() {
        assertTrue(isValidWhatsAppNumber("+92 300 1234567"))
        assertTrue(isValidWhatsAppNumber("+92-300-1234567"))
    }

    @Test
    fun otherInternationalNumbers_areValid() {
        assertTrue(isValidWhatsAppNumber("+15551234567")) // US
        assertTrue(isValidWhatsAppNumber("+447911123456")) // UK
        assertTrue(isValidWhatsAppNumber("+971501234567")) // UAE
    }

    @Test
    fun invalidWhatsAppNumbers_areRejected() {
        assertFalse(isValidWhatsAppNumber(""))
        assertFalse(isValidWhatsAppNumber("03001234567")) // Missing + country code
        assertFalse(isValidWhatsAppNumber("923001234567")) // Missing +
        assertFalse(isValidWhatsAppNumber("+92")) // Too short
        assertFalse(isValidWhatsAppNumber("+12345")) // Less than 7 digits
        assertFalse(isValidWhatsAppNumber("+92300123456789012345")) // Greater than 15 digits
        assertFalse(isValidWhatsAppNumber("+92300ABC4567")) // Contains non-digits
        assertFalse(isValidWhatsAppNumber("abc"))
    }
}
