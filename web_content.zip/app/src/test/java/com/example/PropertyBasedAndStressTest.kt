package com.example

import com.example.converter.ConverterCategory
import com.example.converter.UnitConverter
import com.example.engine.AngleMode
import com.example.engine.CalculationEngine
import com.example.engine.EvalResult
import com.example.engine.FormattingOptions
import com.example.engine.NumberGroupingStyle
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.math.BigDecimal
import kotlin.math.abs
import kotlin.random.Random

class PropertyBasedAndStressTest {

  private val noGroup = FormattingOptions(grouping = NumberGroupingStyle.NONE)

  private fun eval(expr: String): BigDecimal {
    val res = CalculationEngine.evaluate(expr, AngleMode.DEG, noGroup)
    assertTrue("Failed evaluating '$expr': $res", res is EvalResult.Success)
    return (res as EvalResult.Success).value
  }

  private fun fmtLiteral(v: BigDecimal): String {
    val s = v.toPlainString()
    return if (s.startsWith("-")) "(−${s.substring(1)})" else s
  }

  @Test
  fun `randomized arithmetic algebraic identities 500 seeds`() {
    val rng = Random(20261124L)
    repeat(500) { iter ->
      val a = BigDecimal.valueOf(rng.nextLong(-100_000_000L, 100_000_000L), rng.nextInt(0, 5))
      val b = BigDecimal.valueOf(rng.nextLong(-100_000_000L, 100_000_000L), rng.nextInt(0, 5))
      val sa = fmtLiteral(a)
      val sb = fmtLiteral(b)

      // Commutativity: a + b = b + a and a * b = b * a
      val addAB = eval("$sa+$sb")
      val addBA = eval("$sb+$sa")
      assertEquals("Add commutativity failed at iter=$iter", 0, addAB.compareTo(addBA))

      val mulAB = eval("$sa×$sb")
      val mulBA = eval("$sb×$sa")
      assertEquals("Mul commutativity failed at iter=$iter", 0, mulAB.compareTo(mulBA))

      // Identity & zero properties
      assertEquals("a-0 failed at iter=$iter", 0, eval("$sa−0").compareTo(a))
      assertEquals("a*1 failed at iter=$iter", 0, eval("$sa×1").compareTo(a))
      assertEquals("a/1 failed at iter=$iter", 0, eval("$sa÷1").compareTo(a))
      assertEquals("a+(-a)=0 failed at iter=$iter", 0, eval("$sa+(−$sa)").compareTo(BigDecimal.ZERO))
      assertEquals("a*0=0 failed at iter=$iter", 0, eval("$sa×0").compareTo(BigDecimal.ZERO))
    }
  }

  @Test
  fun `randomized unit converter round-trip consistency across all categories`() {
    val rng = Random(99887766L)
    val categories = ConverterCategory.entries.filter { it != ConverterCategory.CURRENCY }

    repeat(320) { iter ->
      val cat = categories[iter % categories.size]
      val units = UnitConverter.unitsFor(cat)
      val uA = units[rng.nextInt(units.size)]
      val uB = units[rng.nextInt(units.size)]

      val raw =
        when (cat) {
          ConverterCategory.TEMPERATURE -> rng.nextDouble(-200.0, 2000.0)
          ConverterCategory.FUEL_ECONOMY -> rng.nextDouble(1.0, 80.0)
          else -> rng.nextDouble(0.001, 100_000.0)
        }

      val forward = UnitConverter.convert(raw, uA, uB, cat)
      assertTrue("Null forward at $cat $uA->$uB val=$raw", forward != null)
      val back = UnitConverter.convert(forward!!, uB, uA, cat)
      assertTrue("Null back at $cat $uB->$uA val=$forward", back != null)

      val tol = maxOf(1e-7, abs(raw) * 1e-9)
      assertEquals("Round-trip mismatch $cat ($uA -> $uB) iter=$iter", raw, back!!, tol)
    }
  }

  @Test
  fun `long expression and rapid evaluation stress test`() {
    // 200-term chained expression
    val terms = (1..200).joinToString("+") { it.toString() }
    val res = CalculationEngine.evaluate(terms, AngleMode.DEG, noGroup)
    assertTrue(res is EvalResult.Success)
    assertEquals(0, BigDecimal("20100").compareTo((res as EvalResult.Success).value))

    // Deeply nested parentheses (50 levels)
    val nested = "(".repeat(50) + "42" + ")".repeat(50)
    val nestedRes = CalculationEngine.evaluate(nested)
    assertTrue(nestedRes is EvalResult.Success)
    assertEquals("42", (nestedRes as EvalResult.Success).formatted)

    // 1000 rapid consecutive evaluations
    val startMs = System.currentTimeMillis()
    repeat(1000) { k ->
      val r = CalculationEngine.evaluate("(${k}+12.5)×sin(30)+√(144)", AngleMode.DEG)
      assertTrue(r is EvalResult.Success)
    }
    val elapsedMs = System.currentTimeMillis() - startMs
    assertTrue("1000 evaluations took too long: ${elapsedMs}ms", elapsedMs < 5000L)
  }
}
