package com.example

import android.content.Context
import androidx.sqlite.db.SupportSQLiteDatabase
import androidx.sqlite.db.SupportSQLiteOpenHelper
import androidx.sqlite.db.framework.FrameworkSQLiteOpenHelperFactory
import androidx.test.core.app.ApplicationProvider
import com.example.core.data.local.IQTradeDatabase
import com.example.core.data.local.entity.CachedNewsEntity
import com.example.core.model.MarketCategory
import com.example.features.news.model.NewsArticle
import com.example.features.news.model.NewsImpact
import com.example.features.news.model.NewsSentiment
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class NewsDatabaseCacheTest {

    @Test
    fun testCachedNewsDaoPersistenceAndOrdering() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = IQTradeDatabase.getInstance(context)
        val dao = db.cachedNewsDao()

        dao.clearAll()
        assertEquals(0, dao.getCount())

        val article1 = NewsArticle(
            id = "news_101",
            headline = "Bitcoin ETF sees second day of net inflows",
            source = "CoinDesk",
            publishedAt = 1700000010000L,
            url = "https://example.com/101",
            marketCategory = MarketCategory.CRYPTO,
            relevantSymbols = listOf("BTC", "BTCUSDT"),
            sentiment = NewsSentiment.BULLISH,
            sentimentScore = 75,
            sentimentConfidence = 80,
            impact = NewsImpact.HIGH,
            isBreaking = true
        )

        val article2 = NewsArticle(
            id = "news_102",
            headline = "Central Bank meeting yields neutral rate stance",
            source = "Reuters",
            publishedAt = 1700000020000L,
            url = "https://example.com/102",
            marketCategory = MarketCategory.FOREX,
            relevantSymbols = listOf("EUR/USD"),
            sentiment = NewsSentiment.NEUTRAL,
            sentimentScore = 50,
            sentimentConfidence = 70,
            impact = NewsImpact.MEDIUM,
            isBreaking = false
        )

        dao.insertAll(listOf(
            CachedNewsEntity.fromNewsArticle(article1),
            CachedNewsEntity.fromNewsArticle(article2)
        ))

        assertEquals(2, dao.getCount())
        val all = dao.getAllCachedNews()
        // Should be ordered by publishedAt DESC: news_102 first, news_101 second
        assertEquals("news_102", all[0].id)
        assertEquals("news_101", all[1].id)

        val restoredArticle1 = all[1].toNewsArticle()
        assertEquals(article1.headline, restoredArticle1.headline)
        assertEquals(article1.marketCategory, restoredArticle1.marketCategory)
        assertEquals(article1.sentiment, restoredArticle1.sentiment)
        assertEquals(article1.sentimentScore, restoredArticle1.sentimentScore)
        assertTrue(restoredArticle1.isBreaking)

        dao.clearAll()
        assertEquals(0, dao.getCount())
    }

    @Test
    fun testMigrationFromVersion6ToVersion7CreatesCachedNewsTableNonDestructively() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val dbName = "test_migration_6_7.db"
        context.deleteDatabase(dbName)

        val config = SupportSQLiteOpenHelper.Configuration.builder(context)
            .name(dbName)
            .callback(object : SupportSQLiteOpenHelper.Callback(6) {
                override fun onCreate(db: SupportSQLiteDatabase) {
                    // Create Version 6 schema
                    db.execSQL("""
                        CREATE TABLE IF NOT EXISTS `trade_records` (
                            `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                            `symbol` TEXT NOT NULL,
                            `side` TEXT NOT NULL,
                            `orderType` TEXT NOT NULL,
                            `quantity` REAL NOT NULL,
                            `price` REAL NOT NULL,
                            `total` REAL NOT NULL,
                            `timestamp` INTEGER NOT NULL,
                            `isPaper` INTEGER NOT NULL,
                            `stopLoss` REAL,
                            `takeProfit` REAL,
                            `status` TEXT NOT NULL DEFAULT 'FILLED',
                            `isOpen` INTEGER NOT NULL DEFAULT 1,
                            `closePrice` REAL,
                            `realizedPnl` REAL,
                            `closeTimestamp` INTEGER
                        )
                    """.trimIndent())

                    db.execSQL("""
                        CREATE TABLE IF NOT EXISTS `paper_account` (
                            `id` INTEGER PRIMARY KEY NOT NULL,
                            `balance` REAL NOT NULL,
                            `equity` REAL NOT NULL,
                            `initialDeposit` REAL NOT NULL,
                            `lastResetTimestamp` INTEGER NOT NULL
                        )
                    """.trimIndent())
                }

                override fun onUpgrade(db: SupportSQLiteDatabase, oldVersion: Int, newVersion: Int) {}
            })
            .build()

        val helper = FrameworkSQLiteOpenHelperFactory().create(config)
        val db = helper.writableDatabase

        // Insert pre-migration data
        db.execSQL("INSERT INTO `paper_account` (`id`, `balance`, `equity`, `initialDeposit`, `lastResetTimestamp`) VALUES (1, 12500.0, 12500.0, 10000.0, 1700000000000)")
        db.execSQL("INSERT INTO `trade_records` (`id`, `symbol`, `side`, `orderType`, `quantity`, `price`, `total`, `timestamp`, `isPaper`, `status`, `isOpen`) VALUES (1, 'BTCUSDT', 'BUY', 'MARKET', 0.5, 60000.0, 30000.0, 1700000010000, 1, 'FILLED', 1)")

        // Execute MIGRATION_6_7
        IQTradeDatabase.MIGRATION_6_7.migrate(db)

        // Verify pre-existing data is preserved untouched
        val accountCursor = db.query("SELECT `balance` FROM `paper_account` WHERE `id` = 1")
        assertTrue(accountCursor.moveToFirst())
        assertEquals(12500.0, accountCursor.getDouble(0), 0.001)
        accountCursor.close()

        val tradeCursor = db.query("SELECT `symbol`, `price` FROM `trade_records` WHERE `id` = 1")
        assertTrue(tradeCursor.moveToFirst())
        assertEquals("BTCUSDT", tradeCursor.getString(0))
        assertEquals(60000.0, tradeCursor.getDouble(1), 0.001)
        tradeCursor.close()

        // Verify cached_news table exists and can be written to
        db.execSQL("""
            INSERT INTO `cached_news` (
                `id`, `headline`, `source`, `publishedAt`, `url`, `urlToImage`, `description`,
                `marketCategory`, `relevantSymbolsJson`, `sentiment`, `sentimentScore`, `sentimentConfidence`,
                `impact`, `isBreaking`, `cachedAt`
            ) VALUES (
                'test_migration_art_1', 'Bitcoin Breaking Rally', 'CryptoWire', 1700000050000,
                'https://example.com/mig', null, 'Description here', 'CRYPTO', 'BTC,BTCUSDT',
                'BULLISH', 80, 85, 'HIGH', 1, 1700000055000
            )
        """.trimIndent())

        val newsCursor = db.query("SELECT `headline`, `sentimentScore`, `isBreaking` FROM `cached_news` WHERE `id` = 'test_migration_art_1'")
        assertTrue(newsCursor.moveToFirst())
        assertEquals("Bitcoin Breaking Rally", newsCursor.getString(0))
        assertEquals(80, newsCursor.getInt(1))
        assertEquals(1, newsCursor.getInt(2))
        newsCursor.close()

        db.close()
        helper.close()
    }
}
