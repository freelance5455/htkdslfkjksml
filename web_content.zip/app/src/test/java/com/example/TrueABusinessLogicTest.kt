package com.example

import com.example.data.model.Auction
import com.example.data.model.AuctionStatus
import com.example.util.FEATURED_AUCTION_FEE_NAIRA
import com.example.util.calculateCommission
import com.example.util.formatCountdown
import com.example.util.formatNaira
import com.google.firebase.Timestamp
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Date

class TrueABusinessLogicTest {

    @Test
    fun commission_threePercent_on500kIs15k() {
        val gross = 500_000L
        val commission = calculateCommission(gross)
        assertEquals(15_000L, commission)
        assertEquals(485_000L, gross - commission)
    }

    @Test
    fun featuredAuctionFee_is2000Naira() {
        assertEquals(2_000L, FEATURED_AUCTION_FEE_NAIRA)
    }

    @Test
    fun formatNaira_formatsWithCommas() {
        assertEquals("₦500,000", formatNaira(500_000L))
        assertEquals("₦15,000", formatNaira(15_000L))
        assertEquals("₦2,000", formatNaira(2_000L))
    }

    @Test
    fun auction_minimumNextBid_usesStartingBidWhenNoBids() {
        val freshLot = Auction(
            startingBid = 100_000L,
            minIncrement = 5_000L,
            currentBid = 0L,
            bidCount = 0L
        )
        assertEquals(100_000L, freshLot.minimumNextBid())

        val activeLot = freshLot.copy(currentBid = 120_000L, bidCount = 3L)
        assertEquals(125_000L, activeLot.minimumNextBid())
    }

    @Test
    fun countdown_marksUrgentUnderFiveMinutesAndEndedPastDeadline() {
        val now = 1_700_000_000_000L
        val twoMinsLater = Timestamp(Date(now + 120_000L))
        val urgentParts = formatCountdown(twoMinsLater, now, "ACTIVE")
        assertTrue(urgentParts.urgent)
        assertFalse(urgentParts.ended)
        assertEquals("02m 00s", urgentParts.label)

        val past = Timestamp(Date(now - 5_000L))
        val endedParts = formatCountdown(past, now, "ACTIVE")
        assertTrue(endedParts.ended)
        assertEquals(AuctionStatus.ENDED, Auction(status = "ACTIVE", endsAt = past).effectiveStatus(now))
    }
}
