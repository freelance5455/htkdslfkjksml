package com.example

import com.example.core.model.TradingMode
import com.example.core.model.chart.StopLossMode
import com.example.core.model.chart.TradeProtectionState
import com.example.core.model.chart.TradeSide
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class TradingModesAndProtectionTest {

    @Test
    fun testAllTradingModesExist() {
        val modes = TradingMode.entries
        assertEquals(7, modes.size)

        // Verify the 7 locked modes
        val expectedModes = listOf(
            TradingMode.AUTO_TRADE,
            TradingMode.SCALPING_TRADE,
            TradingMode.MANUAL_TRADE,
            TradingMode.LIVE_TRADE,
            TradingMode.PAPER_TRADE,
            TradingMode.ONLY_SIGNAL,
            TradingMode.CUSTOM_MODE
        )
        assertEquals(expectedModes, modes)

        // Verify titles and string labels
        assertEquals("Auto Trade", TradingMode.AUTO_TRADE.title)
        assertEquals("Scalping Trade", TradingMode.SCALPING_TRADE.title)
        assertEquals("Manual Trade", TradingMode.MANUAL_TRADE.title)
        assertEquals("Live Trade", TradingMode.LIVE_TRADE.title)
        assertEquals("Paper Trade", TradingMode.PAPER_TRADE.title)
        assertEquals("Only Signal", TradingMode.ONLY_SIGNAL.title)
        assertEquals("Custom Mode", TradingMode.CUSTOM_MODE.title)

        // Verify default timeframes
        assertEquals("15m", TradingMode.AUTO_TRADE.defaultTimeframe)
        assertEquals("1m", TradingMode.SCALPING_TRADE.defaultTimeframe)
        assertEquals("1h", TradingMode.MANUAL_TRADE.defaultTimeframe)
        assertEquals("1h", TradingMode.LIVE_TRADE.defaultTimeframe)
        assertEquals("1h", TradingMode.PAPER_TRADE.defaultTimeframe)
        assertEquals("15m", TradingMode.ONLY_SIGNAL.defaultTimeframe)
        assertEquals("4h", TradingMode.CUSTOM_MODE.defaultTimeframe)

        // Verify fromString parsing and swing profile mapping to AUTO_TRADE
        assertEquals(TradingMode.SCALPING_TRADE, TradingMode.fromString("Scalping Trade"))
        assertEquals(TradingMode.AUTO_TRADE, TradingMode.fromString("Swing Trade"))
        assertEquals(TradingMode.AUTO_TRADE, TradingMode.fromString("SWING_TRADE"))
        assertEquals(TradingMode.AUTO_TRADE, TradingMode.fromId("SWING_TRADE"))
        assertEquals(TradingMode.AUTO_TRADE, TradingMode.fromString("Smart Auto Trade"))
        assertEquals(TradingMode.MANUAL_TRADE, TradingMode.fromString("MANUAL_TRADE"))
        assertEquals(TradingMode.PAPER_TRADE, TradingMode.fromString("Paper Trade"))
        assertEquals(TradingMode.ONLY_SIGNAL, TradingMode.fromString("Only Signal"))
        assertEquals(TradingMode.CUSTOM_MODE, TradingMode.fromString("Custom Mode"))
        assertEquals(TradingMode.AUTO_TRADE, TradingMode.fromString("UnknownString"))
    }

    @Test
    fun testFixedStopLossCalculation() {
        val protection = TradeProtectionState(
            stopLossMode = StopLossMode.FIXED,
            stopLossPercentage = 2.0,
            isTakeProfitEnabled = true,
            takeProfitPercentage = 4.0,
            entryPrice = 100.0,
            currentPrice = 100.0,
            quantity = 1.0,
            side = TradeSide.BUY
        )

        // BUY: SL should be 100 - 2% = 98.0
        val effSl = protection.effectiveStopLossPrice
        assertNotNull(effSl)
        assertEquals(98.0, effSl!!, 0.001)

        // BUY: TP should be 100 + 4% = 104.0
        val effTp = protection.effectiveTakeProfitPrice
        assertNotNull(effTp)
        assertEquals(104.0, effTp!!, 0.001)

        // Risk-to-Reward should be 4.0 / 2.0 = 2.0
        assertEquals(2.0, protection.riskRewardRatio, 0.01)
    }

    @Test
    fun testTrailingStopLossCalculation() {
        val protection = TradeProtectionState(
            stopLossMode = StopLossMode.TRAILING,
            trailingDistancePct = 1.5,
            entryPrice = 100.0,
            currentPrice = 110.0, // price moved up to 110
            quantity = 1.0,
            side = TradeSide.BUY
        )

        // Trailing stop follows current price 110: 110 * (1 - 0.015) = 108.35
        val effSl = protection.effectiveStopLossPrice
        assertNotNull(effSl)
        assertEquals(108.35, effSl!!, 0.01)
    }

    @Test
    fun testManualStopLossCalculation() {
        val protection = TradeProtectionState(
            stopLossMode = StopLossMode.MANUAL,
            stopLossPrice = 96.50,
            isTakeProfitEnabled = true,
            takeProfitPrice = 107.00,
            entryPrice = 100.0,
            currentPrice = 100.0,
            quantity = 1.0,
            side = TradeSide.BUY
        )

        assertEquals(96.50, protection.effectiveStopLossPrice!!, 0.001)
        assertEquals(107.00, protection.effectiveTakeProfitPrice!!, 0.001)
        // Risk = 3.5, Reward = 7.0 -> R:R = 2.0
        assertEquals(2.0, protection.riskRewardRatio, 0.01)
    }

    @Test
    fun testAutoStopLossDynamicSwingCalculation() {
        val protection = TradeProtectionState(
            stopLossMode = StopLossMode.AUTO,
            entryPrice = 1000.0,
            currentPrice = 1000.0,
            quantity = 1.0,
            side = TradeSide.BUY
        )

        // Auto mode applies dynamic swing buffer 1.2%
        val effSl = protection.effectiveStopLossPrice
        assertNotNull(effSl)
        assertEquals(988.0, effSl!!, 0.001)
    }

    @Test
    fun testBalanceRiskAutomaticStopLossCalculation() {
        // Account balance = 10,000 USDT, max risk = 2% (200 USDT)
        // Quantity = 2.0 units, Entry = 100.0
        // Max loss per unit = 200 / 2.0 = 100.0 -> SL = 100 - 100 = 0
        // If Quantity = 10.0 units, Max loss per unit = 200 / 10 = 20 -> SL = 80.0
        val protection = TradeProtectionState(
            stopLossMode = StopLossMode.BALANCE_RISK,
            accountBalance = 10000.0,
            maxRiskAccountPercentage = 2.0, // 200 USDT
            quantity = 10.0,
            entryPrice = 100.0,
            currentPrice = 100.0,
            side = TradeSide.BUY
        )

        val effSl = protection.effectiveStopLossPrice
        assertNotNull(effSl)
        assertEquals(80.0, effSl!!, 0.01)
    }

    @Test
    fun testStrictRiskRewardTakeProfitEnforcement() {
        val protection = TradeProtectionState(
            stopLossMode = StopLossMode.FIXED,
            stopLossPercentage = 1.0, // Risk = 1.0% (1.0 price unit at 100)
            isTakeProfitEnabled = true,
            strictRiskRewardEnabled = true,
            targetRiskRewardRatio = 3.0, // Strict 1:3 ratio
            entryPrice = 100.0,
            currentPrice = 100.0,
            quantity = 1.0,
            side = TradeSide.BUY
        )

        // With strict R:R = 3.0 and SL distance = 1.0, TP must be 100 + (1.0 * 3.0) = 103.0
        val effTp = protection.effectiveTakeProfitPrice
        assertNotNull(effTp)
        assertEquals(103.0, effTp!!, 0.01)
        assertEquals(3.0, protection.riskRewardRatio, 0.01)
    }

    @Test
    fun testOnlySignalModeProperties() {
        val signalMode = TradingMode.ONLY_SIGNAL
        assertEquals("Only Signal", signalMode.title)
        assertEquals("Only Signal", signalMode.shortLabel)
        assertFalse("Only signal mode must not execute automated orders", signalMode.isAutomated)
        assertFalse(signalMode.requiresApiCredentials)
    }

    @Test
    fun testCustomModeProperties() {
        val customMode = TradingMode.CUSTOM_MODE
        assertEquals("Custom Mode", customMode.title)
        assertEquals("Custom Mode", customMode.shortLabel)
        assertFalse(customMode.isAutomated)
        assertFalse(customMode.requiresApiCredentials)
    }

    @Test
    fun testModeSwitchingPreservesSymbolAndTimeframe() {
        // Verify that changing active trading mode preserves current symbol and timeframe
        var currentSymbol = "ETHUSDT"
        var currentTimeframe = "15m"

        val allModes = TradingMode.entries
        assertEquals(7, allModes.size)

        for (mode in allModes) {
            // Simulate mode change
            val activeMode = mode
            // Symbol and timeframe remain strictly preserved
            assertEquals("ETHUSDT", currentSymbol)
            assertEquals("15m", currentTimeframe)
            assertNotNull(activeMode.title)
            assertNotNull(activeMode.shortLabel)
        }
    }

    @Test
    fun testCustomModeExactlyThreeTimeframesValidation() {
        // Custom Mode requires selecting exactly 3 timeframes
        val validTimeframes = listOf("5m", "15m", "1h")
        val invalidTimeframesUnder = listOf("5m", "15m")
        val invalidTimeframesOver = listOf("1m", "5m", "15m", "1h")

        assertTrue(validTimeframes.size == 3)
        assertFalse(invalidTimeframesUnder.size == 3)
        assertFalse(invalidTimeframesOver.size == 3)

        // Indicator selection can be multiple
        val selectedIndicators = listOf("EMA", "RSI", "MACD", "SUPERTREND")
        assertTrue(selectedIndicators.isNotEmpty())
    }

    @Test
    fun testModule7TradingModeDefaultStatesAreStrictlyOff() {
        val defaultState = com.example.viewmodel.MainUiState()
        assertFalse("Smart Mode must default to OFF", defaultState.isSmartModeEnabled)
        assertFalse("Auto Trading must default to OFF", defaultState.isAutoTradingEnabled)
        assertFalse("Live Trading must default to OFF", defaultState.isLiveTradingEnabled)
        assertEquals("Default trading mode must be PAPER", "PAPER", defaultState.tradingMode)
    }

    @Test
    fun testModule7TradeFilteringAndWinRateCalculation() {
        val openTrade = com.example.core.data.local.entity.TradeRecordEntity(
            id = 1,
            symbol = "BTCUSDT",
            side = "BUY",
            orderType = "MARKET",
            quantity = 0.5,
            price = 60000.0,
            total = 30000.0,
            isPaper = true,
            isOpen = true,
            status = "OPEN"
        )
        val winningTrade = com.example.core.data.local.entity.TradeRecordEntity(
            id = 2,
            symbol = "BTCUSDT",
            side = "BUY",
            orderType = "MARKET",
            quantity = 0.5,
            price = 60000.0,
            total = 30000.0,
            closePrice = 62000.0,
            realizedPnl = 1000.0,
            isPaper = true,
            isOpen = false,
            status = "CLOSED"
        )
        val losingTrade = com.example.core.data.local.entity.TradeRecordEntity(
            id = 3,
            symbol = "ETHUSDT",
            side = "SELL",
            orderType = "MARKET",
            quantity = 2.0,
            price = 3000.0,
            total = 6000.0,
            closePrice = 3100.0,
            realizedPnl = -200.0,
            isPaper = true,
            isOpen = false,
            status = "CLOSED"
        )

        val state = com.example.viewmodel.MainUiState(
            trades = listOf(openTrade, winningTrade, losingTrade),
            paperBalance = 10800.0,
            realizedPnl = 800.0,
            unrealizedPnl = 500.0
        )

        assertEquals(1, state.openTrades.size)
        assertEquals(2, state.closedTrades.size)
        assertEquals(3, state.paperTrades.size)
        assertEquals(0, state.liveTrades.size)
        // 1 winning out of 2 closed = 50.0% win rate
        assertEquals(50.0, state.winRatePct, 0.01)
    }

    // ==========================================
    // MODULE #8: PAPER TRADING FUNCTIONALITY TESTS
    // ==========================================

    @Test
    fun testModule8PaperAccountBalanceAndSpreadSimulation() {
        val defaultAccount = com.example.core.data.local.entity.PaperAccountEntity(
            id = 1,
            balance = 10000.0,
            equity = 10000.0,
            unrealizedPnl = 0.0,
            realizedPnl = 0.0
        )
        // 1. Initial default balance is $10,000
        assertEquals(10000.0, defaultAccount.balance, 0.01)
        assertEquals(10000.0, defaultAccount.equity, 0.01)

        // 2. Realistic spread simulation: BUY executes at entryPrice * 1.0005 (+0.05%)
        val entryPrice = 60000.0
        val fillPrice = entryPrice * 1.0005
        assertEquals(60030.0, fillPrice, 0.01)

        val quantity = 0.1
        val totalCost = fillPrice * quantity
        assertEquals(6003.0, totalCost, 0.01)

        val newBalance = defaultAccount.balance - totalCost
        val updatedAccount = defaultAccount.copy(balance = newBalance, equity = newBalance)
        assertEquals(3997.0, updatedAccount.balance, 0.01)
    }

    @Test
    fun testModule8OrderValidationGuards() {
        fun validateOrder(
            symbol: String,
            price: Double,
            qty: Double,
            balance: Double,
            isStale: Boolean,
            mode: TradingMode,
            stopLoss: Double? = null,
            takeProfit: Double? = null
        ): String? {
            if (mode == TradingMode.ONLY_SIGNAL) return "Order rejected: Trading is completely disabled in Only Signal mode"
            if (symbol.isBlank() || symbol.length < 2) return "Order rejected: Invalid trading symbol"
            if (price <= 0.0 || price.isNaN() || price.isInfinite() || isStale) return "Order rejected: Invalid or stale market data"
            if (qty <= 0.0 || qty.isNaN() || qty.isInfinite()) return "Order rejected: Quantity must be greater than zero"
            if (stopLoss != null && stopLoss >= price) return "Order rejected: BUY Stop loss must be below entry price"
            if (takeProfit != null && takeProfit <= price) return "Order rejected: BUY Take profit must be above entry price"
            val totalCost = price * qty
            if (balance < totalCost) return "Insufficient paper balance"
            return null
        }

        // Only Signal guard
        assertEquals(
            "Order rejected: Trading is completely disabled in Only Signal mode",
            validateOrder("BTCUSDT", 60000.0, 0.1, 10000.0, false, TradingMode.ONLY_SIGNAL)
        )
        // Invalid symbol
        assertEquals(
            "Order rejected: Invalid trading symbol",
            validateOrder("", 60000.0, 0.1, 10000.0, false, TradingMode.PAPER_TRADE)
        )
        // Stale data
        assertEquals(
            "Order rejected: Invalid or stale market data",
            validateOrder("BTCUSDT", 60000.0, 0.1, 10000.0, true, TradingMode.PAPER_TRADE)
        )
        // Zero quantity
        assertEquals(
            "Order rejected: Quantity must be greater than zero",
            validateOrder("BTCUSDT", 60000.0, 0.0, 10000.0, false, TradingMode.PAPER_TRADE)
        )
        // Invalid Stop Loss
        assertEquals(
            "Order rejected: BUY Stop loss must be below entry price",
            validateOrder("BTCUSDT", 60000.0, 0.1, 10000.0, false, TradingMode.PAPER_TRADE, stopLoss = 61000.0)
        )
        // Invalid Take Profit
        assertEquals(
            "Order rejected: BUY Take profit must be above entry price",
            validateOrder("BTCUSDT", 60000.0, 0.1, 10000.0, false, TradingMode.PAPER_TRADE, takeProfit = 59000.0)
        )
        // Insufficient balance
        assertEquals(
            "Insufficient paper balance",
            validateOrder("BTCUSDT", 60000.0, 0.5, 10000.0, false, TradingMode.PAPER_TRADE)
        )
        // Valid order
        assertNull(
            validateOrder("BTCUSDT", 60000.0, 0.1, 10000.0, false, TradingMode.PAPER_TRADE, stopLoss = 58000.0, takeProfit = 65000.0)
        )
    }

    @Test
    fun testModule8PaperVsLiveIsolation() {
        val paperTrade = com.example.core.data.local.entity.TradeRecordEntity(
            id = 1,
            symbol = "BTCUSDT",
            side = "BUY",
            orderType = "MARKET",
            quantity = 0.1,
            price = 60000.0,
            total = 6000.0,
            isPaper = true,
            isOpen = true
        )
        val liveTrade = com.example.core.data.local.entity.TradeRecordEntity(
            id = 2,
            symbol = "ETHUSDT",
            side = "SELL",
            orderType = "MARKET",
            quantity = 1.0,
            price = 3000.0,
            total = 3000.0,
            isPaper = false,
            isOpen = true
        )

        val trades = listOf(paperTrade, liveTrade)
        val paperTrades = trades.filter { it.isPaper }
        val liveTrades = trades.filter { !it.isPaper }

        assertEquals(1, paperTrades.size)
        assertEquals("BTCUSDT", paperTrades.first().symbol)
        assertEquals(1, liveTrades.size)
        assertEquals("ETHUSDT", liveTrades.first().symbol)

        // Clear paper trades only
        val afterClear = trades.filter { !it.isPaper }
        assertEquals(1, afterClear.size)
        assertEquals("ETHUSDT", afterClear.first().symbol)
        assertFalse(afterClear.first().isPaper)
    }

    @Test
    fun testModule8PositionLifecycleAndRealizedPnl() {
        val entryPrice = 60000.0
        val qty = 0.1
        val total = entryPrice * qty // 6000.0
        val openTrade = com.example.core.data.local.entity.TradeRecordEntity(
            id = 50,
            symbol = "BTCUSDT",
            side = "BUY",
            orderType = "MARKET",
            quantity = qty,
            price = entryPrice,
            total = total,
            isPaper = true,
            isOpen = true,
            status = "FILLED"
        )
        assertTrue(openTrade.isOpen)
        assertEquals("FILLED", openTrade.status)

        // Close position at 66,000.0 (+10% gain)
        val closePrice = 66000.0
        val pnl = (closePrice - openTrade.price) * openTrade.quantity // +600.0
        val closeTime = System.currentTimeMillis()

        val closedTrade = openTrade.copy(
            isOpen = false,
            status = "CLOSED",
            closePrice = closePrice,
            closeTimestamp = closeTime,
            realizedPnl = pnl
        )

        assertFalse(closedTrade.isOpen)
        assertEquals("CLOSED", closedTrade.status)
        assertEquals(66000.0, closedTrade.closePrice!!, 0.01)
        assertEquals(600.0, closedTrade.realizedPnl!!, 0.01)
        assertEquals(closeTime, closedTrade.closeTimestamp!!)

        // Return balance update
        val initialBalance = 4000.0
        val returnBalance = closedTrade.total + pnl // 6000 + 600 = 6600.0
        val updatedBalance = initialBalance + returnBalance // 10600.0
        assertEquals(10600.0, updatedBalance, 0.01)
    }

    @Test
    fun testModule8TrailingStopRatchet() {
        val entryPrice = 100.0
        val trailingDistPct = 2.0
        var currentStop = 98.0 // 2% initial stop

        // Price rises favorably to 110.0 -> candidate stop = 110 * 0.98 = 107.8
        val priceUp = 110.0
        val candidateStopUp = priceUp * (1.0 - (trailingDistPct / 100.0))
        if (candidateStopUp > currentStop) {
            currentStop = candidateStopUp
        }
        assertEquals(107.8, currentStop, 0.01)

        // Price pulls back to 105.0 -> candidate stop = 105 * 0.98 = 102.9
        // Must NOT loosen or move down!
        val priceDown = 105.0
        val candidateStopDown = priceDown * (1.0 - (trailingDistPct / 100.0))
        if (candidateStopDown > currentStop) {
            currentStop = candidateStopDown
        }
        // Stop remains at high watermark: 107.8
        assertEquals(107.8, currentStop, 0.01)
    }

    @Test
    fun testModule8ReactiveEquityAndUnrealizedPnl() {
        val cashBalance = 4000.0
        val entryPrice = 60000.0
        val quantity = 0.1

        val openTrade = com.example.core.data.local.entity.TradeRecordEntity(
            id = 77,
            symbol = "BTCUSDT",
            side = "BUY",
            orderType = "MARKET",
            quantity = quantity,
            price = entryPrice,
            total = entryPrice * quantity,
            isPaper = true,
            isOpen = true
        )

        // Tick 1: Price at 65,000 -> Unrealized PnL = (65000 - 60000) * 0.1 = +500
        val currentPrice1 = 65000.0
        val unrealizedPnl1 = (currentPrice1 - openTrade.price) * openTrade.quantity
        val equity1 = cashBalance + unrealizedPnl1
        assertEquals(500.0, unrealizedPnl1, 0.01)
        assertEquals(4500.0, equity1, 0.01)

        // Tick 2: Price at 55,000 -> Unrealized PnL = (55000 - 60000) * 0.1 = -500
        val currentPrice2 = 55000.0
        val unrealizedPnl2 = (currentPrice2 - openTrade.price) * openTrade.quantity
        val equity2 = cashBalance + unrealizedPnl2
        assertEquals(-500.0, unrealizedPnl2, 0.01)
        assertEquals(3500.0, equity2, 0.01)
    }
}
