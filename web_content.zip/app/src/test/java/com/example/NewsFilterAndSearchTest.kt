package com.example

import com.example.core.model.MarketCategory
import com.example.features.news.model.NewsArticle
import com.example.features.news.model.NewsImpact
import com.example.features.news.model.NewsSentiment
import com.example.viewmodel.MainUiState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class NewsFilterAndSearchTest {

    private val sampleArticles = listOf(
        NewsArticle(
            id = "art_1",
            headline = "Bitcoin hits new local high with surging institutional volume",
            source = "CoinDesk",
            publishedAt = 1700000030000L,
            url = "https://example.com/1",
            marketCategory = MarketCategory.CRYPTO,
            relevantSymbols = listOf("BTC", "BTCUSDT"),
            sentiment = NewsSentiment.BULLISH,
            sentimentScore = 80,
            impact = NewsImpact.HIGH,
            isBreaking = true
        ),
        NewsArticle(
            id = "art_2",
            headline = "Ethereum network gas fees plunge to record lows",
            source = "Decrypt",
            publishedAt = 1700000020000L,
            url = "https://example.com/2",
            marketCategory = MarketCategory.CRYPTO,
            relevantSymbols = listOf("ETH", "ETHUSDT"),
            sentiment = NewsSentiment.NEUTRAL,
            sentimentScore = 50,
            impact = NewsImpact.MEDIUM,
            isBreaking = false
        ),
        NewsArticle(
            id = "art_3",
            headline = "EUR/USD slides as ECB signals extended rate pause",
            source = "Bloomberg",
            publishedAt = 1700000010000L,
            url = "https://example.com/3",
            marketCategory = MarketCategory.FOREX,
            relevantSymbols = listOf("EUR/USD", "EURUSD"),
            sentiment = NewsSentiment.BEARISH,
            sentimentScore = 30,
            impact = NewsImpact.MEDIUM,
            isBreaking = false
        ),
        NewsArticle(
            id = "art_4",
            headline = "Gold bullion safe-haven rally pauses near key resistance",
            source = "Reuters",
            publishedAt = 1700000000000L,
            url = "https://example.com/4",
            marketCategory = MarketCategory.GOLD,
            relevantSymbols = listOf("XAU/USD", "GOLD"),
            sentiment = NewsSentiment.BULLISH,
            sentimentScore = 65,
            impact = NewsImpact.LOW,
            isBreaking = false
        )
    )

    @Test
    fun testSearchQueryFiltering() {
        val state = MainUiState(
            newsArticles = sampleArticles,
            newsSearchQuery = "Ethereum"
        )
        val filtered = state.filteredNewsArticles
        assertEquals(1, filtered.size)
        assertEquals("art_2", filtered.first().id)

        val sourceSearchState = MainUiState(
            newsArticles = sampleArticles,
            newsSearchQuery = "Reuters"
        )
        assertEquals(1, sourceSearchState.filteredNewsArticles.size)
        assertEquals("art_4", sourceSearchState.filteredNewsArticles.first().id)
    }

    @Test
    fun testMarketCategoryFiltering() {
        val cryptoState = MainUiState(
            newsArticles = sampleArticles,
            selectedNewsMarket = MarketCategory.CRYPTO
        )
        assertEquals(2, cryptoState.filteredNewsArticles.size)
        assertTrue(cryptoState.filteredNewsArticles.all { it.marketCategory == MarketCategory.CRYPTO })

        val forexState = MainUiState(
            newsArticles = sampleArticles,
            selectedNewsMarket = MarketCategory.FOREX
        )
        assertEquals(1, forexState.filteredNewsArticles.size)
        assertEquals("art_3", forexState.filteredNewsArticles.first().id)

        val goldState = MainUiState(
            newsArticles = sampleArticles,
            selectedNewsMarket = MarketCategory.GOLD
        )
        assertEquals(1, goldState.filteredNewsArticles.size)
        assertEquals("art_4", goldState.filteredNewsArticles.first().id)
    }

    @Test
    fun testSentimentFiltering() {
        val bullishState = MainUiState(
            newsArticles = sampleArticles,
            selectedNewsSentiment = NewsSentiment.BULLISH
        )
        assertEquals(2, bullishState.filteredNewsArticles.size)
        assertTrue(bullishState.filteredNewsArticles.all { it.sentiment == NewsSentiment.BULLISH })

        val bearishState = MainUiState(
            newsArticles = sampleArticles,
            selectedNewsSentiment = NewsSentiment.BEARISH
        )
        assertEquals(1, bearishState.filteredNewsArticles.size)
        assertEquals("art_3", bearishState.filteredNewsArticles.first().id)
    }

    @Test
    fun testSelectedSymbolFiltering() {
        val btcOnlyState = MainUiState(
            newsArticles = sampleArticles,
            selectedSymbol = "BTCUSDT",
            filterOnlySelectedSymbol = true
        )
        assertEquals(1, btcOnlyState.filteredNewsArticles.size)
        assertEquals("art_1", btcOnlyState.filteredNewsArticles.first().id)

        val xauOnlyState = MainUiState(
            newsArticles = sampleArticles,
            selectedSymbol = "XAU/USD",
            filterOnlySelectedSymbol = true
        )
        assertEquals(1, xauOnlyState.filteredNewsArticles.size)
        assertEquals("art_4", xauOnlyState.filteredNewsArticles.first().id)
    }

    @Test
    fun testCurrentSymbolNewsSentimentComputation() {
        val btcState = MainUiState(
            newsArticles = sampleArticles,
            selectedSymbol = "BTCUSDT",
            selectedMarket = MarketCategory.CRYPTO
        )
        assertEquals(NewsSentiment.BULLISH, btcState.currentSymbolNewsSentiment)
        assertEquals(80, btcState.currentSymbolNewsScore)

        val eurState = MainUiState(
            newsArticles = sampleArticles,
            selectedSymbol = "EUR/USD",
            selectedMarket = MarketCategory.FOREX
        )
        assertEquals(NewsSentiment.BEARISH, eurState.currentSymbolNewsSentiment)
        assertEquals(30, eurState.currentSymbolNewsScore)
    }
}
