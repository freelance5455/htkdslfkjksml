package com.example

import androidx.test.core.app.ActivityScenario
import org.junit.Assert.assertNotNull
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class MainActivityStartupTest {

    @Test
    fun testMainActivityLaunchesWithoutCrashing() {
        ActivityScenario.launch(MainActivity::class.java).use { scenario ->
            scenario.onActivity { activity ->
                assertNotNull(activity)
            }
        }
    }

    @Test
    fun testNavigateToAnalysisScreenAndAutoTradeScreen() {
        ActivityScenario.launch(MainActivity::class.java).use { scenario ->
            scenario.onActivity { activity ->
                assertNotNull(activity)
                val vm = androidx.lifecycle.ViewModelProvider(activity)[com.example.viewmodel.IQTradeViewModel::class.java]
                assertNotNull(vm)

                // Navigate to Analysis
                vm.navigateTo(com.example.core.model.NavSection.ANALYSIS)
                org.robolectric.shadows.ShadowLooper.idleMainLooper()

                // Navigate to AutoTrade
                vm.navigateTo(com.example.core.model.NavSection.AUTO_TRADE)
                org.robolectric.shadows.ShadowLooper.idleMainLooper()

                // Navigate back to Terminal
                vm.navigateTo(com.example.core.model.NavSection.TERMINAL)
                org.robolectric.shadows.ShadowLooper.idleMainLooper()
            }
        }
    }
}
