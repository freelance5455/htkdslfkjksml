package com.example

import android.content.Context
import androidx.sqlite.db.SupportSQLiteDatabase
import androidx.sqlite.db.SupportSQLiteOpenHelper
import androidx.sqlite.db.framework.FrameworkSQLiteOpenHelperFactory
import androidx.test.core.app.ApplicationProvider
import com.example.core.data.local.IQTradeDatabase
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class DatabaseMigrationTest {

    @Test
    fun testMigrationFromVersion4ToVersion5PreservesExistingData() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val dbName = "test_iqtrade_migration.db"
        context.deleteDatabase(dbName)

        val config = SupportSQLiteOpenHelper.Configuration.builder(context)
            .name(dbName)
            .callback(object : SupportSQLiteOpenHelper.Callback(4) {
                override fun onCreate(db: SupportSQLiteDatabase) {
                    // Create Version 4 schema without Module 7 lifecycle fields
                    db.execSQL("""
                        CREATE TABLE IF NOT EXISTS `trade_records` (
                            `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                            `symbol` TEXT NOT NULL,
                            `side` TEXT NOT NULL,
                            `orderType` TEXT NOT NULL,
                            `quantity` REAL NOT NULL,
                            `price` REAL NOT NULL,
                            `total` REAL NOT NULL,
                            `timestamp` INTEGER NOT NULL,
                            `isPaper` INTEGER NOT NULL,
                            `stopLoss` REAL,
                            `takeProfit` REAL
                        )
                    """.trimIndent())

                    db.execSQL("""
                        CREATE TABLE IF NOT EXISTS `paper_account` (
                            `id` INTEGER PRIMARY KEY NOT NULL,
                            `balance` REAL NOT NULL,
                            `equity` REAL NOT NULL,
                            `initialDeposit` REAL NOT NULL,
                            `lastResetTimestamp` INTEGER NOT NULL
                        )
                    """.trimIndent())

                    db.execSQL("""
                        CREATE TABLE IF NOT EXISTS `app_settings` (
                            `id` INTEGER PRIMARY KEY NOT NULL,
                            `selectedSymbol` TEXT NOT NULL,
                            `selectedTimeframe` TEXT NOT NULL,
                            `tradingMode` TEXT NOT NULL,
                            `isSmartModeEnabled` INTEGER NOT NULL,
                            `isAutoTradingEnabled` INTEGER NOT NULL,
                            `isLiveTradingEnabled` INTEGER NOT NULL,
                            `showIndicators` INTEGER NOT NULL,
                            `showVolume` INTEGER NOT NULL,
                            `showSignalPlotting` INTEGER NOT NULL,
                            `chartType` TEXT NOT NULL
                        )
                    """.trimIndent())
                }

                override fun onUpgrade(db: SupportSQLiteDatabase, oldVersion: Int, newVersion: Int) {}
            })
            .build()

        val helper = FrameworkSQLiteOpenHelperFactory().create(config)
        val db = helper.writableDatabase

        // 1. Insert representative Version 4 data
        db.execSQL("""
            INSERT INTO `paper_account` (`id`, `balance`, `equity`, `initialDeposit`, `lastResetTimestamp`)
            VALUES (1, 10450.75, 10450.75, 10000.0, 1700000000000)
        """.trimIndent())

        db.execSQL("""
            INSERT INTO `app_settings` (`id`, `selectedSymbol`, `selectedTimeframe`, `tradingMode`, `isSmartModeEnabled`, `isAutoTradingEnabled`, `isLiveTradingEnabled`, `showIndicators`, `showVolume`, `showSignalPlotting`, `chartType`)
            VALUES (1, 'BTCUSDT', '15m', 'AUTO_TRADE', 0, 0, 0, 1, 1, 1, 'CANDLE')
        """.trimIndent())

        db.execSQL("""
            INSERT INTO `trade_records` (`id`, `symbol`, `side`, `orderType`, `quantity`, `price`, `total`, `timestamp`, `isPaper`, `stopLoss`, `takeProfit`)
            VALUES (1, 'BTCUSDT', 'BUY', 'MARKET', 0.25, 60000.0, 15000.0, 1700000010000, 1, 58000.0, 64000.0)
        """.trimIndent())

        db.execSQL("""
            INSERT INTO `trade_records` (`id`, `symbol`, `side`, `orderType`, `quantity`, `price`, `total`, `timestamp`, `isPaper`, `stopLoss`, `takeProfit`)
            VALUES (2, 'ETHUSDT', 'SELL', 'MARKET', 2.0, 3000.0, 6000.0, 1700000020000, 1, 3100.0, 2800.0)
        """.trimIndent())

        // Verify version 4 data is present before migration
        val preCountCursor = db.query("SELECT COUNT(*) FROM `trade_records`")
        preCountCursor.moveToFirst()
        assertEquals(2, preCountCursor.getInt(0))
        preCountCursor.close()

        // 2. Execute explicit MIGRATION_4_5
        IQTradeDatabase.MIGRATION_4_5.migrate(db)

        // 3. Verify paper_account data is completely preserved
        val accountCursor = db.query("SELECT `balance`, `equity`, `initialDeposit` FROM `paper_account` WHERE `id` = 1")
        assertTrue(accountCursor.moveToFirst())
        assertEquals(10450.75, accountCursor.getDouble(0), 0.001)
        assertEquals(10450.75, accountCursor.getDouble(1), 0.001)
        assertEquals(10000.0, accountCursor.getDouble(2), 0.001)
        accountCursor.close()

        // 4. Verify existing trade records survived with previous fields intact
        val trade1Cursor = db.query("SELECT `id`, `symbol`, `side`, `price`, `quantity`, `total`, `isOpen`, `status`, `closePrice`, `realizedPnl`, `closeTimestamp` FROM `trade_records` WHERE `id` = 1")
        assertTrue(trade1Cursor.moveToFirst())
        assertEquals("BTCUSDT", trade1Cursor.getString(1))
        assertEquals("BUY", trade1Cursor.getString(2))
        assertEquals(60000.0, trade1Cursor.getDouble(3), 0.001)
        assertEquals(0.25, trade1Cursor.getDouble(4), 0.001)
        assertEquals(15000.0, trade1Cursor.getDouble(5), 0.001)

        // 5. Verify Module 7 lifecycle fields were added with correct defaults
        // isOpen should default to 1 (true)
        assertEquals(1, trade1Cursor.getInt(6))
        // status should default to 'FILLED' (or 'OPEN')
        assertNotNull(trade1Cursor.getString(7))
        // closePrice, realizedPnl, closeTimestamp should be null for existing open trades
        assertTrue(trade1Cursor.isNull(8))
        assertTrue(trade1Cursor.isNull(9))
        assertTrue(trade1Cursor.isNull(10))
        trade1Cursor.close()

        // 6. Verify trade record 2 also survived
        val trade2Cursor = db.query("SELECT `symbol`, `isOpen`, `status` FROM `trade_records` WHERE `id` = 2")
        assertTrue(trade2Cursor.moveToFirst())
        assertEquals("ETHUSDT", trade2Cursor.getString(0))
        assertEquals(1, trade2Cursor.getInt(1))
        trade2Cursor.close()

        // 7. Verify new closed trade with v5 lifecycle fields can be inserted
        db.execSQL("""
            INSERT INTO `trade_records` (`symbol`, `side`, `orderType`, `quantity`, `price`, `total`, `timestamp`, `isPaper`, `status`, `stopLoss`, `takeProfit`, `isOpen`, `closePrice`, `realizedPnl`, `closeTimestamp`)
            VALUES ('SOLUSDT', 'BUY', 'MARKET', 10.0, 150.0, 1500.0, 1700000030000, 1, 'CLOSED', 140.0, 170.0, 0, 165.0, 150.0, 1700000040000)
        """.trimIndent())

        val trade3Cursor = db.query("SELECT `symbol`, `isOpen`, `status`, `closePrice`, `realizedPnl` FROM `trade_records` WHERE `symbol` = 'SOLUSDT'")
        assertTrue(trade3Cursor.moveToFirst())
        assertEquals(0, trade3Cursor.getInt(1))
        assertEquals("CLOSED", trade3Cursor.getString(2))
        assertEquals(165.0, trade3Cursor.getDouble(3), 0.001)
        assertEquals(150.0, trade3Cursor.getDouble(4), 0.001)
        trade3Cursor.close()

        db.close()
        helper.close()
    }
}
