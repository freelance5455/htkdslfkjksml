package com.example

import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onRoot
import com.example.data.SufiEntry
import com.example.data.SufiLanguage
import com.example.ui.WisdomCard
import com.example.ui.theme.SufiSomeSaysTheme
import com.github.takahirom.roborazzi.RobolectricDeviceQualifiers
import com.github.takahirom.roborazzi.captureRoboImage
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(qualifiers = RobolectricDeviceQualifiers.Pixel8, sdk = [34])
class GreetingScreenshotTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    @Test
    fun sufi_wisdom_card_screenshot() {
        val sampleEntry = SufiEntry(
            id = "q_rumi_test",
            type = "quote",
            author = "Rumi",
            en = "The wound is the place where the Light enters you.",
            ml = "മുറിവാണ് വെളിച്ചം നിന്നിലേക്ക് പ്രവേശിക്കുന്ന ഇടം.",
            theme = "Wisdom"
        )

        composeTestRule.setContent {
            SufiSomeSaysTheme {
                WisdomCard(
                    entry = sampleEntry,
                    language = SufiLanguage.ENGLISH,
                    isSaved = false,
                    onToggleSave = {},
                    onCopy = {},
                    onShare = {}
                )
            }
        }

        composeTestRule.onRoot().captureRoboImage(filePath = "src/test/screenshots/greeting.png")
    }
}
