package com.example

import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onRoot
import com.example.model.OperatingMode
import com.example.model.PedestrianState
import com.example.model.SignalPhase
import com.example.ui.components.TrafficLightDisplay
import com.example.ui.theme.MyApplicationTheme
import com.github.takahirom.roborazzi.RobolectricDeviceQualifiers
import com.github.takahirom.roborazzi.captureRoboImage
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(qualifiers = RobolectricDeviceQualifiers.Pixel8, sdk = [36])
class GreetingScreenshotTest {

  @get:Rule val composeTestRule = createComposeRule()

  @Test
  fun greeting_screenshot() {
    composeTestRule.setContent {
      MyApplicationTheme(darkTheme = true) {
        TrafficLightDisplay(
          currentPhase = SignalPhase.RED,
          secondsRemaining = 10,
          operatingMode = OperatingMode.AUTOMATIC,
          isNightFlashOn = true,
          pedestrianState = PedestrianState.WALK,
          isPedestrianRequested = false,
          pedestrianSecondsRemaining = 8,
          onLampClick = {},
          onPedestrianButtonClick = {}
        )
      }
    }

    composeTestRule.onRoot().captureRoboImage(filePath = "src/test/screenshots/greeting.png")
  }
}

