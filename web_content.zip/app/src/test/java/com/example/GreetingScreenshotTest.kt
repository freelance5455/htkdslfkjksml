package com.example

import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onRoot
import com.example.data.model.AlarmEntity
import com.example.ui.screens.AlarmsScreen
import com.example.ui.theme.AppColorTheme
import com.example.ui.theme.MyApplicationTheme
import com.github.takahirom.roborazzi.RobolectricDeviceQualifiers
import com.github.takahirom.roborazzi.captureRoboImage
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(qualifiers = RobolectricDeviceQualifiers.Pixel8, sdk = [34])
class GreetingScreenshotTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    private val sampleAlarms = listOf(
        AlarmEntity(
            id = 1L,
            hour = 7,
            minute = 0,
            label = "Morning Wake Up",
            isEnabled = true,
            daysOfWeek = "1,2,3,4,5"
        ),
        AlarmEntity(
            id = 2L,
            hour = 14,
            minute = 30,
            label = "Afternoon Reset",
            isEnabled = false,
            daysOfWeek = "1,2,3,4,5"
        )
    )

    @Test
    fun chrono_alarms_screen_light_theme_screenshot() {
        composeTestRule.setContent {
            MyApplicationTheme(appColorTheme = AppColorTheme.NEON_CYAN, isDarkMode = false) {
                AlarmsScreen(
                    alarms = sampleAlarms,
                    nextAlarm = sampleAlarms.first(),
                    is24Hour = false,
                    onToggleAlarm = {},
                    onDeleteAlarm = {},
                    onAddAlarm = { _, _, _, _, _, _, _, _, _ -> },
                    onUpdateAlarm = {},
                    onTestAlarm = {}
                )
            }
        }

        composeTestRule.onRoot().captureRoboImage(filePath = "src/test/screenshots/chrono_alarms_light.png")
    }

    @Test
    fun chrono_alarms_screen_dark_theme_screenshot() {
        composeTestRule.setContent {
            MyApplicationTheme(appColorTheme = AppColorTheme.NEON_CYAN, isDarkMode = true) {
                AlarmsScreen(
                    alarms = sampleAlarms,
                    nextAlarm = sampleAlarms.first(),
                    is24Hour = false,
                    onToggleAlarm = {},
                    onDeleteAlarm = {},
                    onAddAlarm = { _, _, _, _, _, _, _, _, _ -> },
                    onUpdateAlarm = {},
                    onTestAlarm = {}
                )
            }
        }

        composeTestRule.onRoot().captureRoboImage(filePath = "src/test/screenshots/chrono_alarms_dark.png")
    }
}
