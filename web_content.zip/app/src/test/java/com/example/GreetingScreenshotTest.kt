package com.example

import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onRoot
import com.example.data.model.PrayerTimeItemData
import com.example.data.model.PrayerType
import com.example.ui.components.NextPrayerCard
import com.example.ui.theme.MyApplicationTheme
import com.github.takahirom.roborazzi.RobolectricDeviceQualifiers
import com.github.takahirom.roborazzi.captureRoboImage
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(qualifiers = RobolectricDeviceQualifiers.Pixel8, sdk = [36])
class GreetingScreenshotTest {

  @get:Rule val composeTestRule = createComposeRule()

  @Test
  fun greeting_screenshot() {
    val samplePrayer = PrayerTimeItemData(
      type = PrayerType.MAGHRIB,
      formattedTime = "18:45",
      epochMillis = System.currentTimeMillis() + 3600000L,
      isNext = true
    )
    composeTestRule.setContent {
      MyApplicationTheme {
        NextPrayerCard(
          nextPrayer = samplePrayer,
          countdownFormatted = "01:14:22"
        )
      }
    }

    composeTestRule.onRoot().captureRoboImage(filePath = "src/test/screenshots/greeting.png")
  }
}

