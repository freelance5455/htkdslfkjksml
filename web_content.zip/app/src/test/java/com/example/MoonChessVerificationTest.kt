package com.example

import android.app.Application
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.chess.AVAILABLE_BOARD_THEMES
import com.example.chess.AnalysisEngines
import com.example.chess.ChessEngineCore
import com.example.chess.ChessTreeManager
import com.example.chess.EngineChoice
import com.example.chess.PieceColor
import com.example.chess.Square
import com.example.data.MoonChessDatabase
import com.example.data.MoonChessRepository
import com.example.data.NoteEntity
import com.example.data.PdfAnnotationStroke
import com.example.data.PrincipleEntity
import com.example.data.PrinciplePhase
import com.example.pdf.PdfDocumentController
import com.example.pdf.SampleChessPdfGenerator
import com.example.scanner.CropRect
import com.example.scanner.DiagramRecognitionPipeline
import com.example.scanner.PieceTemplate
import com.example.scanner.ScannerCrop
import com.example.scanner.ScannerNcc
import com.example.scanner.SquareShade
import com.example.ui.AppSection
import com.example.ui.DockedAnalysisSheet
import com.example.ui.MoonChessTopBar
import com.example.ui.MoonChessViewModel
import com.example.ui.NotesScreen
import com.example.ui.PrinciplesScreen
import com.example.ui.theme.MoonChessTheme
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import java.io.File

@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(sdk = [36], qualifiers = "w412dp-h915dp-xhdpi")
class MoonChessVerificationTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    @Test
    fun `1_small_and_large_pdf_generation_and_valid_structure`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()

        val smallPdf = SampleChessPdfGenerator.generateSamplePdfFile(
            context = context,
            filename = "test_small_12p.pdf",
            pageCount = 12
        )
        val largePdf = SampleChessPdfGenerator.generateSamplePdfFile(
            context = context,
            filename = "test_large_60p.pdf",
            pageCount = 60
        )

        assertTrue("Small PDF exists and non-empty", smallPdf.exists() && smallPdf.length() > 1_000L)
        assertTrue("Large PDF exists and larger than small PDF", largePdf.exists() && largePdf.length() >= smallPdf.length())

        val headerMagic = String(smallPdf.readBytes().take(5).toByteArray(), Charsets.US_ASCII)
        assertEquals("%PDF-", headerMagic)

        // Verify offline PDF text search finds moves & commentary in both small (12p) and large (60p) PDFs
        val smallMatches = PdfDocumentController.searchInPdf(smallPdf, "20...hxg5")
        assertTrue("Small PDF offline search finds 20...hxg5", smallMatches.isNotEmpty())

        val largeMatches = PdfDocumentController.searchInPdf(largePdf, "Capablanca")
        assertTrue("Large 60-page PDF offline search finds Capablanca across chapters", largeMatches.size >= 8)
        Unit
    }

    @Test
    fun `2_docked_board_drag_limits_and_toggle_behavior`() {
        val app = ApplicationProvider.getApplicationContext<Application>()
        val vm = MoonChessViewModel(app)

        // Default docked size matches screenshot (~48%)
        assertEquals(48f, vm.boardSizePercent.value, 0.01f)

        // Dragging above 75% clamps strictly at 75%
        vm.updateBoardDragPercent(89f, isLandscape = false)
        assertEquals(75f, vm.boardSizePercent.value, 0.01f)

        // Portrait drag below 6% snaps to 0% (hidden)
        vm.updateBoardDragPercent(4.5f, isLandscape = false)
        assertEquals(0f, vm.boardSizePercent.value, 0.01f)

        // Landscape drag below 10% snaps to 0%, above 10% stays proportional
        vm.updateBoardDragPercent(8.5f, isLandscape = true)
        assertEquals(0f, vm.boardSizePercent.value, 0.01f)
        vm.updateBoardDragPercent(42f, isLandscape = true)
        assertEquals(42f, vm.boardSizePercent.value, 0.01f)

        // King toggle hides and restores docked board
        vm.toggleKingDockedBoard()
        assertEquals(0f, vm.boardSizePercent.value, 0.01f)
        vm.toggleKingDockedBoard()
        assertTrue("Restored board size >= 45%", vm.boardSizePercent.value >= 45f)
    }

    @Test
    fun `3_play_undo_variations_move_comments_pgn_roundtrip_and_offline_engine`() = runBlocking {
        var state = ChessTreeManager.createInitialState()

        // Play 1. e4 e6 2. d4 d5
        state = ChessTreeManager.playMove(state, Square.fromAlgebraic("e2")!!, Square.fromAlgebraic("e4")!!)
        state = ChessTreeManager.playMove(state, Square.fromAlgebraic("e7")!!, Square.fromAlgebraic("e6")!!)
        state = ChessTreeManager.playMove(state, Square.fromAlgebraic("d2")!!, Square.fromAlgebraic("d4")!!)
        state = ChessTreeManager.playMove(state, Square.fromAlgebraic("d7")!!, Square.fromAlgebraic("d5")!!)

        assertEquals("d5", state.currentNode.san)
        assertTrue(state.canGoBack)

        // Undo 2 moves back to after 1...e6 and play sideline 2. Nc3! with comment
        state = ChessTreeManager.goToPrev(state)
        state = ChessTreeManager.goToPrev(state)
        assertEquals("e6", state.currentNode.san)

        state = ChessTreeManager.playMove(state, Square.fromAlgebraic("b1")!!, Square.fromAlgebraic("c3")!!)
        assertEquals("Nc3", state.currentNode.san)

        state = ChessTreeManager.toggleNodeNag(state, state.currentNodeId, "!")
        state = ChessTreeManager.setNodeComment(state, state.currentNodeId, "Classical French development")

        // Export PGN and re-import offline
        val exportedPgn = ChessTreeManager.exportPgn(state)
        assertTrue("Exported PGN has mainline d4", exportedPgn.contains("2. d4"))
        assertTrue("Exported PGN has sideline Nc3!", exportedPgn.contains("Nc3!"))
        assertTrue("Exported PGN has comment", exportedPgn.contains("Classical French development"))

        val reimported = ChessTreeManager.importPgn(exportedPgn)
        assertNotNull("Re-imported PGN state is non-null", reimported)
        val hasCommentNode = reimported!!.nodes.values.any {
            it.san == "Nc3" && it.comment.contains("Classical French development") && "!" in it.nags
        }
        assertTrue("Re-imported PGN preserves sideline, NAG, and move comment", hasCommentNode)

        // Verify offline VCH Engine evaluates position without network calls
        val eval = AnalysisEngines.evaluateVchLocal(reimported.fen, targetDepth = 2)
        assertTrue(eval.pvLines.isNotEmpty())
        assertTrue(eval.scoreText.isNotBlank())

        // Verify Stockfish 19 Lichess URL encodes exact FEN and orientation
        val lichessUrl = AnalysisEngines.buildLichessStockfish19Url(reimported.fen, PieceColor.BLACK)
        assertTrue(lichessUrl.startsWith("https://lichess.org/analysis/"))
        assertTrue(lichessUrl.endsWith("?color=black"))
    }

    @Test
    fun `4_four_phase_scanner_scans_multiple_diagrams_accurately_onto_board`() = runBlocking {
        // 1. Learn all 26 templates (12 pieces x 2 shades + 2 empty shades) in printed book style
        val (calBmp, calGrid) = SampleChessPdfGenerator.createPrintedBookCalibrationPair()
        val cells32 = ScannerCrop.extractBoardCells32x32(calBmp)
        val templateMap = HashMap<String, PieceTemplate>()
        for (r in 0..7) {
            for (c in 0..7) {
                val code = calGrid[r][c]
                val shade = if ((r + c) % 2 == 1) SquareShade.DARK else SquareShade.LIGHT
                val key = "${code}_${shade.raw}"
                templateMap[key] = ScannerNcc.mergeRunningAverage(
                    existing = templateMap[key],
                    newPixels = cells32[r][c],
                    pieceCode = code,
                    shade = shade
                )
            }
        }
        val coverage = ScannerNcc.calculateTemplateCoverage(templateMap)
        assertEquals("All 26 piece+shade templates learned", 26, coverage.totalLearned)

        // 2. Render 4 distinct full chess book pages (with page margins, double frames, coordinates, hatched squares, text)
        val testSpecs = SampleChessPdfGenerator.CLASSIC_DIAGRAM_SPECS.take(4)
        for ((index, spec) in testSpecs.withIndex()) {
            val pageW = 1224
            val pageH = 1684
            val pageBmp = Bitmap.createBitmap(pageW, pageH, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(pageBmp)
            canvas.drawColor(Color.WHITE)

            val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.BLACK
                textSize = 28f
                typeface = Typeface.SERIF
            }
            canvas.drawText(spec.chapterTitle, 96f, 110f, titlePaint)

            val boardLeft = 356f
            val boardTop = 184f
            val boardSize = 512f
            SampleChessPdfGenerator.drawPrintedChessDiagramOnCanvas(
                canvas = canvas,
                fen = spec.fen,
                boardLeft = boardLeft,
                boardTop = boardTop,
                boardSize = boardSize
            )
            canvas.drawText(spec.topCaption, 110f, boardTop + boardSize + 85f, titlePaint)

            // Auto-detect diagram candidate on page, or pass surrounding region
            val candidates = PdfDocumentController.detectDiagramCandidatesOnPage(pageBmp)
            val cropInput = candidates.firstOrNull() ?: CropRect(
                x = (boardLeft - 24).toInt(),
                y = (boardTop - 24).toInt(),
                width = (boardSize + 48).toInt(),
                height = (boardSize + 48).toInt()
            )

            // Run full 4-phase recognition pipeline completely offline
            val expectedTurn = spec.fen.split(" ")[1][0]
            val scanResult = DiagramRecognitionPipeline.recognize(
                sourceBitmap = pageBmp,
                manualCropRect = cropInput,
                templates = templateMap,
                preferredSideToMove = expectedTurn,
                allowOnlineGeminiFallback = false
            )

            val expectedPlacement = spec.fen.split(" ").first()
            val scannedPlacement = scanResult.fen.split(" ").first()

            assertEquals(
                "Diagram #${index + 1} (${spec.chapterTitle}) exact FEN piece placement match",
                expectedPlacement,
                scannedPlacement
            )
            assertTrue(
                "Diagram #${index + 1} confidence >= 0.85 (was ${scanResult.confidence})",
                scanResult.confidence >= 0.85f
            )
            assertEquals("offline_ncc", scanResult.sourceMethod)

            // Confirm loading scanned FEN onto chessboard produces valid playable state
            val loadedBoard = ChessTreeManager.loadFenPosition(scanResult.fen, title = spec.chapterTitle)
            assertEquals(expectedPlacement, loadedBoard.fen.split(" ").first())
        }
        Unit
    }

    @Test
    fun `5_offline_room_persistence_across_restart_and_empty_initial_notes_principles`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val dbFile = File(context.cacheDir, "moonchess_persist_test_${System.currentTimeMillis()}.db")

        // Session 1: Fresh app start
        val db1 = Room.databaseBuilder(context, MoonChessDatabase::class.java, dbFile.absolutePath)
            .allowMainThreadQueries()
            .build()
        val repo1 = MoonChessRepository(context, db1.dao())

        // Verify Notes and Principles start 100% empty (zero pre-made notes or principles)
        assertTrue("Initial notes must be empty", repo1.notesFlow.first().isEmpty())
        assertTrue("Initial principles must be empty", repo1.principlesFlow.first().isEmpty())

        // Create offline PDF book and update reading position to page 9, zoom 1.4x
        val pdfFile = SampleChessPdfGenerator.generateSamplePdfFile(context, "persist_book.pdf", 12)
        val savedBook = repo1.registerGeneratedPdfFile(pdfFile, "Persistent Chess Book")
        repo1.updateReadingProgress(savedBook.id, page = 9, zoom = 1.4f)
        repo1.setSetting("lastOpenedBookId", savedBook.id)
        repo1.savePageStrokes(
            savedBook.id,
            9,
            listOf(PdfAnnotationStroke("s1", "pen", 0xFFDC2626L, 3f, listOf(0.1f to 0.1f, 0.4f to 0.4f)))
        )

        // Save user note, Opening principle, and offline PGN game
        repo1.saveNote(
            NoteEntity(
                id = "n1",
                title = "My Botvinnik Note",
                content = "Watch f5 break",
                linkedFen = ChessEngineCore.STARTING_FEN
            )
        )
        repo1.savePrinciple(
            PrincipleEntity(
                id = "p1",
                phase = PrinciplePhase.OPENING.name,
                title = "Castle early",
                description = "Bring king to safety before central pawn storm"
            )
        )
        repo1.saveCustomPgnGame("""[White "Morphy"][Black "Duke"] 1. e4 e5 2. Nf3 d6 1-0""")

        // Close database completely to simulate app shutdown
        db1.close()

        // Session 2: Reopen database from disk
        val db2 = Room.databaseBuilder(context, MoonChessDatabase::class.java, dbFile.absolutePath)
            .allowMainThreadQueries()
            .build()
        val repo2 = MoonChessRepository(context, db2.dao())

        val reopenedBook = repo2.getBookById(savedBook.id)
        assertNotNull(reopenedBook)
        assertEquals(9, reopenedBook!!.lastReadPage)
        assertEquals(1.4f, reopenedBook.zoom, 0.01f)
        assertEquals(savedBook.id, repo2.getSetting("lastOpenedBookId"))
        assertTrue("PDF file remains accessible after restart", File(reopenedBook.localFilePath).exists())

        val reopenedNotes = repo2.notesFlow.first()
        assertEquals(1, reopenedNotes.size)
        assertEquals("My Botvinnik Note", reopenedNotes.first().title)

        val reopenedPrinciples = repo2.principlesFlow.first()
        assertEquals(1, reopenedPrinciples.size)
        assertEquals(PrinciplePhase.OPENING.name, reopenedPrinciples.first().phase)

        val reopenedGames = repo2.importedGamesFlow.first()
        assertEquals(1, reopenedGames.size)
        assertEquals("Morphy", reopenedGames.first().white)

        db2.close()
        dbFile.delete()
        Unit
    }

    @Test
    fun `6_compose_ui_renders_screenshot_topbar_docked_sheet_and_empty_notes_principles`() {
        val boardState = ChessTreeManager.createInitialState()

        composeTestRule.setContent {
            MoonChessTheme {
                androidx.compose.foundation.layout.Column {
                    MoonChessTopBar(
                        activeSection = AppSection.NOTES,
                        activeBook = null,
                        currentPage = 19,
                        isDockedBoardOpen = true,
                        onBackClick = {},
                        onSelectSection = {},
                        onCycleSplitBoard = {},
                        onJumpToPage = {},
                        onToggleSearch = {},
                        onZoomOut = {},
                        onZoomIn = {}
                    )
                    NotesScreen(
                        notes = emptyList(),
                        currentBoardFen = boardState.fen,
                        onSaveNote = { _, _, _, _, _, _, _ -> },
                        onTogglePin = {},
                        onDeleteNote = {},
                        onLoadFenOnBoard = { _, _ -> },
                        onBack = {},
                        modifier = androidx.compose.ui.Modifier.weight(1f)
                    )
                    DockedAnalysisSheet(
                        boardState = boardState,
                        boardTheme = AVAILABLE_BOARD_THEMES.first(),
                        isEngineEnabled = true,
                        engineChoice = EngineChoice.VCH_LOCAL,
                        engineDepth = 3,
                        engineEval = null,
                        isCollapsed = false,
                        onDragDeltaPx = { _, _ -> },
                        onToggleKingCollapse = {},
                        onOpenPmsStudyModal = {},
                        onOpenBoardMenuSheet = {},
                        onMove = { _, _, _ -> },
                        onPlayPvFirstMove = {},
                        onSetEngineEnabled = {},
                        onSelectEngine = {},
                        onIncrementDepth = {},
                        onUpdateMoveComment = {},
                        onGoStart = {},
                        onGoPrev = {},
                        onGoNext = {},
                        onGoEnd = {},
                        onFlipBoard = {},
                        modifier = androidx.compose.ui.Modifier.weight(1f)
                    )
                }
            }
        }

        composeTestRule.waitForIdle()

        composeTestRule.onNodeWithTag("moonchess_top_bar").assertIsDisplayed()
        composeTestRule.onNodeWithTag("upper_heading_section_menu_button").assertIsDisplayed()
        composeTestRule.onNodeWithTag("empty_notes_placeholder").assertIsDisplayed()
        composeTestRule.onNodeWithText("No notes yet").assertIsDisplayed()
        composeTestRule.onNodeWithTag("docked_analysis_sheet").assertIsDisplayed()
        composeTestRule.onNodeWithTag("king_board_toggle").assertIsDisplayed()
        composeTestRule.onNodeWithTag("pms_graduation_cap_button").assertIsDisplayed()
        composeTestRule.onNodeWithTag("chessboard_canvas").assertIsDisplayed()
        composeTestRule.onNodeWithTag("btn_flip_board").assertIsDisplayed()
        composeTestRule.onNodeWithTag("btn_board_menu").assertIsDisplayed()

        // Open upper heading dropdown menu and verify section options appear
        composeTestRule.onNodeWithTag("upper_heading_section_menu_button").performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("section_menu_item_principles").assertIsDisplayed()
        composeTestRule.onNodeWithTag("section_menu_item_games").assertIsDisplayed()
    }

    @Test
    fun `7_compose_principles_screen_has_opening_middlegame_endgame_empty_by_default`() {
        composeTestRule.setContent {
            MoonChessTheme {
                PrinciplesScreen(
                    principles = emptyList(),
                    currentBoardFen = ChessEngineCore.STARTING_FEN,
                    onSavePrinciple = { _, _, _, _, _, _ -> },
                    onDeletePrinciple = {},
                    onLoadFenOnBoard = { _, _ -> },
                    onBack = {}
                )
            }
        }
        composeTestRule.waitForIdle()

        composeTestRule.onNodeWithTag("principle_tab_opening").assertIsDisplayed()
        composeTestRule.onNodeWithTag("principle_tab_middlegame").assertIsDisplayed()
        composeTestRule.onNodeWithTag("principle_tab_endgame").assertIsDisplayed()
        composeTestRule.onNodeWithText("Opening (0)").assertIsDisplayed()
        composeTestRule.onNodeWithText("Middlegame (0)").assertIsDisplayed()
        composeTestRule.onNodeWithText("Endgame (0)").assertIsDisplayed()
        composeTestRule.onNodeWithTag("empty_principles_placeholder").assertIsDisplayed()
    }
}
