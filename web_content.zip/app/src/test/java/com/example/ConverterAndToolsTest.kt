package com.example

import com.example.converter.ConverterCategory
import com.example.converter.UnitConverter
import com.example.engine.NumberFormatter
import com.example.engine.future.DeterministicMathSolver
import com.example.engine.future.GraphSampler
import com.example.engine.future.FunctionPlotSpec
import com.example.engine.future.GraphViewport
import com.example.engine.future.SolverResult
import com.example.tools.CompoundingFrequency
import com.example.tools.FractionOp
import com.example.tools.MotionTarget
import com.example.tools.SimpleDate
import com.example.tools.ToolsEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs

class ConverterAndToolsTest {

  @Test
  fun `all 16 converter categories basic reverse same-unit and zero`() {
    for (category in ConverterCategory.entries) {
      val units = UnitConverter.unitsFor(category)
      assertTrue("Category ${category.name} should have >=2 units", units.size >= 2)
      val u0 = units[0]
      val u1 = units[1]

      // Same-unit preserves exact value
      assertEquals(42.5, UnitConverter.convert(42.5, u0, u0, category)!!, 1e-9)

      // Positive value round-trip A -> B -> A
      val testVal = 123.456
      val forward = UnitConverter.convert(testVal, u0, u1, category)!!
      val back = UnitConverter.convert(forward, u1, u0, category)!!
      assertEquals("Round-trip failed for ${category.name}", testVal, back, 1e-6)

      // Zero handling (Fuel economy L/100km <-> 0 is undefined)
      if (category != ConverterCategory.FUEL_ECONOMY) {
        val zeroFwd = UnitConverter.convert(0.0, u0, u1, category)!!
        val zeroBack = UnitConverter.convert(zeroFwd, u1, u0, category)!!
        assertEquals("Zero round-trip failed for ${category.name}", 0.0, zeroBack, 1e-9)
      }
    }
  }

  @Test
  fun `temperature exact formulas and negative values`() {
    val units = UnitConverter.unitsFor(ConverterCategory.TEMPERATURE)
    val c = units.first { it.id == "c" }
    val f = units.first { it.id == "f" }
    val k = units.first { it.id == "k" }

    assertEquals(32.0, UnitConverter.convert(0.0, c, f, ConverterCategory.TEMPERATURE)!!, 1e-9)
    assertEquals(212.0, UnitConverter.convert(100.0, c, f, ConverterCategory.TEMPERATURE)!!, 1e-9)
    assertEquals(-40.0, UnitConverter.convert(-40.0, c, f, ConverterCategory.TEMPERATURE)!!, 1e-9)
    assertEquals(273.15, UnitConverter.convert(0.0, c, k, ConverterCategory.TEMPERATURE)!!, 1e-9)
    assertEquals(-273.15, UnitConverter.convert(0.0, k, c, ConverterCategory.TEMPERATURE)!!, 1e-9)
    assertEquals(-459.67, UnitConverter.convert(0.0, k, f, ConverterCategory.TEMPERATURE)!!, 1e-9)
  }

  @Test
  fun `data storage decimal vs binary and energy eV precision`() {
    val data = UnitConverter.unitsFor(ConverterCategory.DATA_STORAGE)
    val bit = data.first { it.id == "bit" }
    val byte = data.first { it.id == "b" }
    val kb = data.first { it.id == "kb" }
    val kib = data.first { it.id == "kib" }
    val gb = data.first { it.id == "gb" }
    val gib = data.first { it.id == "gib" }

    assertEquals(8.0, UnitConverter.convert(1.0, byte, bit, ConverterCategory.DATA_STORAGE)!!, 1e-9)
    assertEquals(1000.0, UnitConverter.convert(1.0, kb, byte, ConverterCategory.DATA_STORAGE)!!, 1e-9)
    assertEquals(1024.0, UnitConverter.convert(1.0, kib, byte, ConverterCategory.DATA_STORAGE)!!, 1e-9)
    assertEquals(1_000_000_000.0, UnitConverter.convert(1.0, gb, byte, ConverterCategory.DATA_STORAGE)!!, 1e-3)
    assertEquals(1_073_741_824.0, UnitConverter.convert(1.0, gib, byte, ConverterCategory.DATA_STORAGE)!!, 1e-3)

    // Regression: tiny eV -> J must NOT clamp to 0!
    val energy = UnitConverter.unitsFor(ConverterCategory.ENERGY)
    val ev = energy.first { it.id == "ev" }
    val j = energy.first { it.id == "j" }
    val joules = UnitConverter.convert(1.0, ev, j, ConverterCategory.ENERGY)!!
    assertEquals(1.602176634e-19, joules, 1e-28)
    assertEquals("1.602176634×10^−19", NumberFormatter.formatDouble(joules))
  }

  @Test
  fun `fuel economy reciprocal and zero handling and custom currency rate`() {
    val fuel = UnitConverter.unitsFor(ConverterCategory.FUEL_ECONOMY)
    val kml = fuel.first { it.id == "kml" }
    val l100 = fuel.first { it.id == "l100km" }
    val mpgUs = fuel.first { it.id == "mpg_us" }

    assertEquals(5.0, UnitConverter.convert(20.0, kml, l100, ConverterCategory.FUEL_ECONOMY)!!, 1e-9)
    assertEquals(20.0, UnitConverter.convert(5.0, l100, kml, ConverterCategory.FUEL_ECONOMY)!!, 1e-9)
    // Regression: 0 km/L <-> L/100km must be null (undefined), not 0.0
    assertNull(UnitConverter.convert(0.0, kml, l100, ConverterCategory.FUEL_ECONOMY))
    assertNull(UnitConverter.convert(0.0, l100, kml, ConverterCategory.FUEL_ECONOMY))
    assertEquals(0.0, UnitConverter.convert(0.0, kml, mpgUs, ConverterCategory.FUEL_ECONOMY)!!, 1e-9)

    val curr = UnitConverter.unitsFor(ConverterCategory.CURRENCY)
    val usd = curr.first { it.id == "usd" }
    val eur = curr.first { it.id == "eur" }
    assertEquals(92.0, UnitConverter.convert(100.0, usd, eur, ConverterCategory.CURRENCY, customCurrencyRate = 0.92)!!, 1e-9)
    assertNull(UnitConverter.convert(100.0, usd, eur, ConverterCategory.CURRENCY, customCurrencyRate = -1.0))
  }

  @Test
  fun `tools engine all 21 calculators and edge cases`() {
    // 1-4: Percentage tools
    assertEquals(30.0, ToolsEngine.percentOf(15.0, 200.0), 1e-9)
    assertEquals(25.0, ToolsEngine.percentChange(80.0, 100.0)!!.first, 1e-9)
    assertNull(ToolsEngine.percentChange(0.0, 100.0))
    assertEquals(115.0, ToolsEngine.increaseByPercent(100.0, 15.0).first, 1e-9)
    assertEquals(85.0, ToolsEngine.decreaseByPercent(100.0, 15.0).first, 1e-9)
    assertEquals(22.222222222, ToolsEngine.percentDifference(80.0, 100.0), 1e-6)
    assertEquals(0.0, ToolsEngine.percentDifference(0.0, 0.0), 1e-9)

    // 5-7: Finance
    val (siInt, siTot) = ToolsEngine.simpleInterest(10000.0, 6.5, 3.0)
    assertEquals(1950.0, siInt, 1e-9)
    assertEquals(11950.0, siTot, 1e-9)

    val (ciInt, ciTot) = ToolsEngine.compoundInterest(10000.0, 12.0, 1.0, CompoundingFrequency.MONTHLY)
    assertEquals(11268.250301319697, ciTot, 1e-6)
    assertEquals(1268.250301319697, ciInt, 1e-6)
    assertEquals(10000.0, ToolsEngine.compoundInterest(10000.0, 0.0, 5.0, CompoundingFrequency.QUARTERLY).second, 1e-9)

    // EMI standard: 100,000 at 12% annual (1%/mo) for 12 months -> EMI = 8884.878868
    val emiStd = ToolsEngine.calculateEmi(100000.0, 12.0, 12)!!
    assertEquals(8884.878868, emiStd.first, 1e-4)
    assertEquals(emiStd.first * 12.0, emiStd.third, 1e-4)
    assertEquals(emiStd.third - 100000.0, emiStd.second, 1e-4)
    // EMI zero interest
    val emiZero = ToolsEngine.calculateEmi(120000.0, 0.0, 12)!!
    assertEquals(10000.0, emiZero.first, 1e-9)
    assertEquals(0.0, emiZero.second, 1e-9)
    // EMI invalid & extreme overflow safety (regression: never NaN)
    assertNull(ToolsEngine.calculateEmi(100000.0, 12.0, 0))
    val emiExtreme = ToolsEngine.calculateEmi(100000.0, 120.0, 10000)
    assertNotNull(emiExtreme)
    assertTrue(!emiExtreme!!.first.isNaN())

    // 8-12: Discount, Sale Price, Tax/GST, Tip, Split Bill
    assertEquals(90.0, ToolsEngine.discount(120.0, 25.0).second, 1e-9)
    val (saved, taxAmt, checkout) = ToolsEngine.salePrice(150.0, 20.0, 8.0)
    assertEquals(30.0, saved, 1e-9)
    assertEquals(9.6, taxAmt, 1e-9)
    assertEquals(129.6, checkout, 1e-9)

    val (exclBase, exclTax, exclTot) = ToolsEngine.taxGst(1000.0, 18.0, inclusive = false)
    assertEquals(1000.0, exclBase, 1e-9)
    assertEquals(180.0, exclTax, 1e-9)
    assertEquals(1180.0, exclTot, 1e-9)

    val (inclBase, inclTax, inclTot) = ToolsEngine.taxGst(1180.0, 18.0, inclusive = true)
    assertEquals(1000.0, inclBase, 1e-9)
    assertEquals(180.0, inclTax, 1e-9)
    assertEquals(1180.0, inclTot, 1e-9)

    val (tipAmt, billTot, perPerson) = ToolsEngine.tipAndSplit(120.0, 15.0, 4)!!
    assertEquals(18.0, tipAmt, 1e-9)
    assertEquals(138.0, billTot, 1e-9)
    assertEquals(34.5, perPerson, 1e-9)
    assertNull(ToolsEngine.tipAndSplit(100.0, 15.0, 0))

    // 13-15: Ratio, Average, Fraction
    val ratioRes = ToolsEngine.ratio(1920, 1080, 1280.0)!!
    assertEquals(16L to 9L, ratioRes.first)
    assertEquals(720.0, ratioRes.second!!, 1e-9)

    val avg = ToolsEngine.average(listOf(10.0, 20.0, 30.0, 40.0))!!
    assertEquals(4, avg.count)
    assertEquals(100.0, avg.sum, 1e-9)
    assertEquals(25.0, avg.mean, 1e-9)
    assertEquals(25.0, avg.median, 1e-9)
    assertEquals(10.0, avg.min, 1e-9)
    assertEquals(40.0, avg.max, 1e-9)

    val fAdd = ToolsEngine.fraction(3, 4, 2, 5, FractionOp.ADD)!!
    assertEquals(23L, fAdd.numerator)
    assertEquals(20L, fAdd.denominator)
    assertEquals(1L, fAdd.mixedWhole)
    assertEquals(3L, fAdd.mixedRemNum)
    val fDiv = ToolsEngine.fraction(1, 2, 3, 4, FractionOp.DIV)!!
    assertEquals(2L, fDiv.numerator)
    assertEquals(3L, fDiv.denominator)
    assertNull(ToolsEngine.fraction(1, 2, 0, 4, FractionOp.DIV))
    // Large fraction overflow safety via BigInteger intermediate
    val fLarge = ToolsEngine.fraction(1_000_000_000_000L, 2_000_000_000_000L, 1, 2, FractionOp.ADD)!!
    assertEquals(1L, fLarge.numerator)
    assertEquals(1L, fLarge.denominator)

    // 16-18: Time Duration, Date Difference, Age
    val dur = ToolsEngine.timeDuration(22, 30, 6, 15)!!
    assertEquals(7, dur.first)
    assertEquals(45, dur.second)
    assertEquals(465, dur.third)
    assertNull(ToolsEngine.timeDuration(25, 0, 10, 0))

    val dateDiff = ToolsEngine.dateDifference(SimpleDate(2024, 1, 1), SimpleDate(2024, 3, 1))
    assertEquals(60L, dateDiff.totalDays) // 2024 is leap year: Jan(31) + Feb(29) = 60 days

    // Regression: end-of-month Jan 31 -> Mar 1 must NEVER produce negative days
    val eomLeap = ToolsEngine.dateDifference(SimpleDate(2024, 1, 31), SimpleDate(2024, 3, 1))
    assertEquals(30L, eomLeap.totalDays)
    assertTrue("Days must be non-negative, got ${eomLeap.days}", eomLeap.days >= 0)
    assertEquals(1, eomLeap.months)
    assertEquals(1, eomLeap.days)

    val eomNonLeap = ToolsEngine.dateDifference(SimpleDate(2023, 1, 31), SimpleDate(2023, 3, 1))
    assertEquals(29L, eomNonLeap.totalDays)
    assertEquals(1, eomNonLeap.months)
    assertEquals(1, eomNonLeap.days)

    val age = ToolsEngine.calculateAge(SimpleDate(2000, 2, 29), SimpleDate(2026, 3, 1))!!
    assertEquals(26, age.years)
    assertEquals(0, age.months)
    assertEquals(1, age.days)
    assertNull(ToolsEngine.calculateAge(SimpleDate(2030, 1, 1), SimpleDate(2026, 1, 1)))

    // 19-21: Motion, Fuel Cost, Unit Price
    assertEquals(60.0, ToolsEngine.solveMotion(MotionTarget.SPEED, 150.0, 2.5)!!, 1e-9)
    assertEquals(150.0, ToolsEngine.solveMotion(MotionTarget.DISTANCE, 60.0, 2.5)!!, 1e-9)
    assertEquals(2.5, ToolsEngine.solveMotion(MotionTarget.TIME, 150.0, 60.0)!!, 1e-9)
    assertNull(ToolsEngine.solveMotion(MotionTarget.SPEED, 100.0, 0.0))

    val (fuelNeeded, fuelCost) = ToolsEngine.fuelCost(320.0, 16.0, 1.65)!!
    assertEquals(20.0, fuelNeeded, 1e-9)
    assertEquals(33.0, fuelCost, 1e-9)

    val (uA, uB, savingsPct) = ToolsEngine.unitPriceCompare(4.99, 500.0, 7.49, 1000.0)!!
    assertTrue(uB < uA)
    assertTrue(abs(savingsPct - ((uA - uB) / uA * 100.0)) < 1e-9)
  }

  @Test
  fun `future graphing sampler and deterministic solver`() {
    val points =
      GraphSampler.sampleFunction(
        FunctionPlotSpec("f1", "x^2", "x²"),
        GraphViewport(-2.0, 2.0, 0.0, 4.0),
        sampleCount = 5,
      )
    assertEquals(5, points.size)
    assertEquals(4.0, points[0].y!!, 1e-6)
    assertEquals(0.0, points[2].y!!, 1e-6)
    assertEquals(4.0, points[4].y!!, 1e-6)

    val lin = DeterministicMathSolver.solveLinear(2.0, 4.0, 10.0) as SolverResult.Solved
    assertEquals("x = 3", lin.summary)

    val quad = DeterministicMathSolver.solveQuadratic(1.0, -5.0, 6.0) as SolverResult.Solved
    assertTrue(quad.summary.contains("3") && quad.summary.contains("2"))
  }
}
