package com.example

import com.example.data.local.CalculationHistoryEntity
import com.example.data.preferences.PreferencesDataSource
import com.example.data.preferences.UserPreferences
import com.example.data.repository.HistoryDataSource
import com.example.engine.AngleMode
import com.example.engine.NumberGroupingStyle
import com.example.ui.calculator.CalculatorViewModel
import com.example.ui.converter.ConverterViewModel
import com.example.ui.theme.AppThemeMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import java.math.BigDecimal

@OptIn(ExperimentalCoroutinesApi::class)
class CalculatorViewModelIntegrationTest {

  private val testDispatcher = StandardTestDispatcher()

  private class FakeHistoryDataSource : HistoryDataSource {
    private val items = MutableStateFlow<List<CalculationHistoryEntity>>(emptyList())
    private var nextId = 1L

    override val history: Flow<List<CalculationHistoryEntity>> = items

    override suspend fun saveCalculation(
      expression: String,
      resultFormatted: String,
      resultRaw: String,
      angleMode: String,
      isScientific: Boolean,
    ) {
      val entry =
        CalculationHistoryEntity(
          id = nextId++,
          expression = expression,
          resultFormatted = resultFormatted,
          resultRaw = resultRaw,
          angleMode = angleMode,
          isScientific = isScientific,
          timestamp = System.currentTimeMillis() + nextId,
        )
      items.value = listOf(entry) + items.value
    }

    override suspend fun deleteById(id: Long) {
      items.value = items.value.filterNot { it.id == id }
    }

    override suspend fun clearAll() {
      items.value = emptyList()
    }
  }

  private class FakePreferencesDataSource : PreferencesDataSource {
    val state = MutableStateFlow(UserPreferences())
    override val preferences: Flow<UserPreferences> = state

    override suspend fun setThemeMode(mode: AppThemeMode) {
      state.value = state.value.copy(themeMode = mode)
    }

    override suspend fun setHapticEnabled(enabled: Boolean) {
      state.value = state.value.copy(hapticEnabled = enabled)
    }

    override suspend fun setGroupingStyle(style: NumberGroupingStyle) {
      state.value = state.value.copy(groupingStyle = style)
    }

    override suspend fun setDecimalPrecision(precision: Int) {
      state.value = state.value.copy(decimalPrecision = precision)
    }

    override suspend fun setAngleMode(mode: AngleMode) {
      state.value = state.value.copy(angleMode = mode)
    }

    override suspend fun setMemoryValue(value: BigDecimal?) {
      state.value = state.value.copy(memoryValue = value)
    }
  }

  @Before
  fun setup() {
    Dispatchers.setMain(testDispatcher)
  }

  @After
  fun tearDown() {
    Dispatchers.resetMain()
  }

  @Test
  fun `memory sequence rapid M+ M- MR MC and negative decimals`() = runTest {
    val history = FakeHistoryDataSource()
    val prefs = FakePreferencesDataSource()
    val vm = CalculatorViewModel(history, prefs)
    val job = backgroundScope.launch(UnconfinedTestDispatcher(testScheduler)) {
      vm.uiState.collect()
    }
    advanceUntilIdle()

    // 1. Clear memory
    vm.onMemoryClear()
    advanceUntilIdle()
    assertFalse(vm.uiState.value.hasMemory)

    // 2. Store 10.5 via M+ twice rapidly (regression test for race condition)
    vm.onDigit("1")
    vm.onDigit("0")
    vm.onDecimal()
    vm.onDigit("5")
    vm.onMemoryAdd()
    vm.onMemoryAdd() // rapid second tap!
    advanceUntilIdle()
    assertTrue(vm.uiState.value.hasMemory)
    assertEquals("21", vm.uiState.value.memoryFormatted)

    // 3. Subtract 30.25 -> negative memory -9.25
    vm.onClearAll()
    vm.onDigit("3")
    vm.onDigit("0")
    vm.onDecimal()
    vm.onDigit("2")
    vm.onDigit("5")
    vm.onMemorySubtract()
    advanceUntilIdle()
    assertEquals("−9.25", vm.uiState.value.memoryFormatted)

    // 4. Recall memory into fresh expression
    vm.onClearAll()
    vm.onMemoryRecall()
    advanceUntilIdle()
    assertEquals("−9.25", vm.uiState.value.expression)

    // 5. Clear memory and ensure MR does nothing
    vm.onClearAll()
    vm.onMemoryClear()
    advanceUntilIdle()
    assertFalse(vm.uiState.value.hasMemory)
    vm.onMemoryRecall()
    advanceUntilIdle()
    assertEquals("", vm.uiState.value.expression)

    job.cancel()
  }

  @Test
  fun `history lifecycle save reverse order reuse delete clear and 300-entry stress`() = runTest {
    val history = FakeHistoryDataSource()
    val prefs = FakePreferencesDataSource()
    val vm = CalculatorViewModel(history, prefs)
    val job1 = backgroundScope.launch(UnconfinedTestDispatcher(testScheduler)) { vm.uiState.collect() }
    val job2 = backgroundScope.launch(UnconfinedTestDispatcher(testScheduler)) { vm.history.collect() }
    advanceUntilIdle()

    // 1 + 2 = 3
    vm.onDigit("1")
    vm.onOperator('+')
    vm.onDigit("2")
    vm.onEquals()
    advanceUntilIdle()
    assertEquals("3", vm.uiState.value.resultText)

    // Repeated '=': 3 + 2 = 5, = 7
    vm.onEquals()
    advanceUntilIdle()
    assertEquals("5", vm.uiState.value.resultText)
    vm.onEquals()
    advanceUntilIdle()
    assertEquals("7", vm.uiState.value.resultText)

    // Reverse chronological order: latest ("5+2" -> "7") is index 0
    assertEquals(3, vm.history.value.size)
    assertEquals("7", vm.history.value[0].resultFormatted)
    assertEquals("3", vm.history.value[2].resultFormatted)

    // Reuse first calculation
    vm.reuseHistoryItem(vm.history.value[2])
    advanceUntilIdle()
    assertEquals("1+2", vm.uiState.value.expression)
    assertEquals("3", vm.uiState.value.resultText)

    // Delete middle item
    val midId = vm.history.value[1].id
    vm.deleteHistoryItem(midId)
    advanceUntilIdle()
    assertEquals(2, vm.history.value.size)

    // Clear all
    vm.clearAllHistory()
    advanceUntilIdle()
    assertTrue(vm.history.value.isEmpty())

    // Stress: 300 rapid calculations
    for (i in 1..300) {
      vm.onClearAll()
      i.toString().forEach { ch -> vm.onDigit(ch.toString()) }
      vm.onOperator('×')
      vm.onDigit("2")
      vm.onEquals()
    }
    advanceUntilIdle()
    assertEquals(300, vm.history.value.size)
    assertEquals("600", vm.history.value.first().resultFormatted)

    job1.cancel()
    job2.cancel()
  }

  @Test
  fun `error recovery sign toggle and scientific mode flow`() = runTest {
    val history = FakeHistoryDataSource()
    val prefs = FakePreferencesDataSource()
    val vm = CalculatorViewModel(history, prefs)
    val job = backgroundScope.launch(UnconfinedTestDispatcher(testScheduler)) { vm.uiState.collect() }
    advanceUntilIdle()

    // Division by zero then recover
    vm.onDigit("5")
    vm.onOperator('÷')
    vm.onDigit("0")
    vm.onEquals()
    advanceUntilIdle()
    assertEquals("Can't divide by zero", vm.uiState.value.errorMessage)

    // Continue calculating normally after error
    vm.onDigit("8")
    vm.onOperator('+')
    vm.onDigit("2")
    vm.onEquals()
    advanceUntilIdle()
    assertNull(vm.uiState.value.errorMessage)
    assertEquals("10", vm.uiState.value.resultText)

    // Decimal validation prevents 1.2.3
    vm.onClearAll()
    vm.onDigit("1")
    vm.onDecimal()
    vm.onDigit("2")
    vm.onDecimal()
    vm.onDigit("3")
    advanceUntilIdle()
    assertEquals("1.23", vm.uiState.value.expression)

    // Toggle sign on chained expression & scientific notation result
    vm.onOperator('×')
    vm.onDigit("5")
    vm.onToggleSign()
    advanceUntilIdle()
    assertEquals("1.23×(−5)", vm.uiState.value.expression)
    vm.onToggleSign()
    advanceUntilIdle()
    assertEquals("1.23×5", vm.uiState.value.expression)

    // Scientific DEG/RAD toggle
    vm.setScientificMode(true)
    vm.onClearAll()
    vm.onScientificFunction("sin(")
    vm.onDigit("3")
    vm.onDigit("0")
    vm.onParen(")")
    vm.onEquals()
    advanceUntilIdle()
    assertEquals("0.5", vm.uiState.value.resultText)

    vm.toggleAngleMode()
    advanceUntilIdle()
    assertEquals(AngleMode.RAD, vm.uiState.value.angleMode)

    job.cancel()
  }

  @Test
  fun `converter viewmodel swap clear and keyboard-free digits`() {
    val cvm = ConverterViewModel()
    cvm.onClear()
    cvm.onDigit("1")
    cvm.onDigit("0")
    cvm.onDecimal()
    cvm.onDigit("5")
    assertEquals("10.5", cvm.state.value.inputText)

    val originalFrom = cvm.state.value.fromUnit
    val originalTo = cvm.state.value.toUnit
    cvm.swapUnits()
    assertEquals(originalTo, cvm.state.value.fromUnit)
    assertEquals(originalFrom, cvm.state.value.toUnit)

    cvm.onBackspace()
    assertEquals("10.", cvm.state.value.inputText)
    cvm.onClear()
    assertEquals("0", cvm.state.value.inputText)
  }
}
