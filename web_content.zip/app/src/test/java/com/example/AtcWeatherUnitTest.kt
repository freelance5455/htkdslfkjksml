package com.example

import com.example.data.parser.MetarParser
import com.example.data.parser.SnowtamParser
import com.example.data.parser.TafParser
import com.example.data.repository.AirportRepository
import org.junit.Assert.*
import org.junit.Test

class AtcWeatherUnitTest {

  @Test
  fun testAirportListContainsIranianAndInternationalHubs() {
    val airports = AirportRepository.INITIAL_AIRPORTS
    assertTrue(airports.any { it.icao == "OIIE" && it.iata == "IKA" })
    assertTrue(airports.any { it.icao == "OIII" && it.iata == "THR" })
    assertTrue(airports.any { it.icao == "OIMM" && it.cityFa == "مشهد" })
    assertTrue(airports.any { it.icao == "OMDB" && it.countryEn == "United Arab Emirates" })
    assertTrue(airports.any { it.icao == "EGLL" && it.iata == "LHR" })
  }

  @Test
  fun testMetarParsingStandardTehran() {
    val raw = "METAR OIIE 111530Z 30004KT 9999 FEW040 24/M07 Q1020 A3012"
    val parsed = MetarParser.parse(raw, "OIIE")

    assertEquals("OIIE", parsed.icao)
    assertFalse(parsed.isSpeci)
    assertEquals("111530Z", parsed.obsTimeUtc)
    assertEquals(300, parsed.windDirDeg)
    assertEquals(4, parsed.windSpeedKt)
    assertEquals(9999, parsed.visibilityMeters)
    assertEquals(24.0, parsed.tempC!!, 0.1)
    assertEquals(-7.0, parsed.dewPointC!!, 0.1)
    assertEquals(1020.0, parsed.altimeterHpa!!, 0.1)
    assertEquals("VFR", parsed.flightCategory)
    assertFalse(parsed.parsingFailed)
  }

  @Test
  fun testSpeciIdentificationAndGusts() {
    val raw = "SPECI OIII 111600Z 28020G35KT 4000 TSRA BKN020CB 18/14 Q1015"
    val parsed = MetarParser.parse(raw, "OIII")

    assertTrue(parsed.isSpeci)
    assertEquals(280, parsed.windDirDeg)
    assertEquals(20, parsed.windSpeedKt)
    assertEquals(35, parsed.windGustKt)
    assertEquals(4000, parsed.visibilityMeters)
    assertEquals(18.0, parsed.tempC!!, 0.1)
    assertEquals(14.0, parsed.dewPointC!!, 0.1)
    assertEquals(1015.0, parsed.altimeterHpa!!, 0.1)
    assertEquals("IFR", parsed.flightCategory)
  }

  @Test
  fun testCavokAndCalmWind() {
    val raw = "METAR OISS 111200Z 00000KT CAVOK 22/05 Q1018"
    val parsed = MetarParser.parse(raw, "OISS")

    assertTrue(parsed.isWindCalm)
    assertTrue(parsed.isCavok)
    assertEquals(9999, parsed.visibilityMeters)
    assertEquals("VFR", parsed.flightCategory)
  }

  @Test
  fun testTafParsingTimeline() {
    val raw = "TAF OIIE 111110Z 1112/1218 32012KT 8000 FEW035 TEMPO 1112/1116 30022KT BECMG 1205/1207 16008KT"
    val parsed = TafParser.parse(raw, "OIIE")

    assertEquals("OIIE", parsed.icao)
    assertEquals("111110Z", parsed.issueTimeUtc)
    assertEquals("1112", parsed.validFromUtc)
    assertEquals("1218", parsed.validToUtc)
    assertTrue(parsed.forecastsSummary.contains("TEMPO"))
    assertTrue(parsed.forecastsSummary.contains("BECMG"))
  }

  @Test
  fun testSnowtamParsingRwyccThirds() {
    val raw = """
      SWIR0001 OIIE 12050020
      (SNOWTAM 0001
      OIIE
      12050020 29R 5/5/5 100/100/100 03/03/03 WET SNOW/WET SNOW/WET SNOW
      RWY 29R FICON 5/5/5 100/100/100 03/03/03 WET SNOW/WET SNOW/WET SNOW)
    """.trimIndent()

    val parsed = SnowtamParser.parse(raw, "OIIE")

    assertEquals("OIIE", parsed.icao)
    assertEquals("0001", parsed.serialNumber)
    assertEquals("29R", parsed.runwayDesignator)
    assertEquals(5, parsed.rwyccPart1)
    assertEquals(5, parsed.rwyccPart2)
    assertEquals(5, parsed.rwyccPart3)
    assertEquals(5, parsed.lowestRwycc)
    assertEquals("WET SNOW", parsed.contaminantType)
    assertEquals(100, parsed.coveragePercentPart1)
    assertEquals(3, parsed.depthMmPart1)
  }

  @Test
  fun testSnowtamVariableConditionLowestRwycc() {
    val raw = "SNOWTAM 0045 ESSA 110200 08 3/2/1 100/100/100 05/10/15 SLUSH"
    val parsed = SnowtamParser.parse(raw, "ESSA")

    assertEquals("ESSA", parsed.icao)
    assertEquals("08", parsed.runwayDesignator)
    assertEquals(3, parsed.rwyccPart1)
    assertEquals(2, parsed.rwyccPart2)
    assertEquals(1, parsed.rwyccPart3)
    assertEquals(1, parsed.lowestRwycc) // Lowest RWYCC is 1 (Poor)
    assertEquals("SLUSH", parsed.contaminantType)
  }

  @Test
  fun testMalformedMetarPreservesRaw() {
    val malformed = "THIS IS NOT A VALID METAR STRING CORRUPTED DATA"
    val parsed = MetarParser.parse(malformed, "OIIE")

    assertEquals(malformed, parsed.rawMetar)
    // Application must not crash and preserve original string
    assertNotNull(parsed.rawMetar)
  }
}
