package com.example

import com.example.core.data.local.entity.TradeRecordEntity
import com.example.core.model.LiveTradingState
import com.example.core.model.MarketCategory
import com.example.core.model.TradingMode
import com.example.core.model.chart.OrderType
import com.example.core.model.chart.StopLossMode
import com.example.core.model.chart.TradeProtectionState
import com.example.core.model.chart.TradeSide
import com.example.core.network.binance.LiveAccountBalance
import com.example.core.network.binance.LiveOrderResult
import com.example.core.network.binance.LiveTradingGateway
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Locale

class LiveTradingEngineIntegrationTest {

    // Mock implementation of LiveTradingGateway to test gateway behavior & isolation
    class MockLiveTradingGateway : LiveTradingGateway {
        var submitCallsCount = 0
        var cancelCallsCount = 0
        var queryCallsCount = 0
        var balanceCallsCount = 0

        var lastSubmittedSymbol: String? = null
        var lastSubmittedSide: TradeSide? = null
        var lastSubmittedType: OrderType? = null
        var lastSubmittedQty: Double? = null
        var lastSubmittedClientOrderId: String? = null

        var nextSubmitResult: LiveOrderResult = LiveOrderResult.Success(
            exchangeOrderId = "987654321",
            clientOrderId = "MOCK_CLIENT_1",
            symbol = "BTCUSDT",
            side = "BUY",
            orderType = "MARKET",
            status = "FILLED",
            executedQty = 0.05,
            origQty = 0.05,
            avgFillPrice = 64200.0,
            commission = 0.0000375,
            commissionAsset = "BNB",
            transactTime = System.currentTimeMillis()
        )

        var balances: List<LiveAccountBalance> = listOf(
            LiveAccountBalance("USDT", 2500.0, 100.0),
            LiveAccountBalance("BTC", 0.75, 0.05),
            LiveAccountBalance("ETH", 5.0, 0.0)
        )

        override suspend fun submitLiveOrder(
            apiKey: String,
            apiSecret: String,
            symbol: String,
            side: TradeSide,
            orderType: OrderType,
            quantity: Double,
            price: Double?,
            stopPrice: Double?,
            clientOrderId: String
        ): LiveOrderResult {
            submitCallsCount++
            lastSubmittedSymbol = symbol
            lastSubmittedSide = side
            lastSubmittedType = orderType
            lastSubmittedQty = quantity
            lastSubmittedClientOrderId = clientOrderId
            return nextSubmitResult
        }

        override suspend fun cancelLiveOrder(
            apiKey: String,
            apiSecret: String,
            symbol: String,
            exchangeOrderId: String?,
            clientOrderId: String?
        ): LiveOrderResult {
            cancelCallsCount++
            return LiveOrderResult.Success(
                exchangeOrderId = exchangeOrderId ?: "123",
                clientOrderId = clientOrderId ?: "CANCELED_1",
                symbol = symbol,
                side = "SELL",
                orderType = "MARKET",
                status = "CANCELED",
                executedQty = 0.0,
                origQty = 0.0,
                avgFillPrice = 0.0,
                transactTime = System.currentTimeMillis()
            )
        }

        override suspend fun queryOrder(
            apiKey: String,
            apiSecret: String,
            symbol: String,
            exchangeOrderId: String?,
            clientOrderId: String?
        ): LiveOrderResult {
            queryCallsCount++
            return nextSubmitResult
        }

        override suspend fun queryOpenOrders(
            apiKey: String,
            apiSecret: String,
            symbol: String?
        ): Result<List<LiveOrderResult.Success>> {
            return Result.success(emptyList())
        }

        override suspend fun queryAccountBalances(
            apiKey: String,
            apiSecret: String
        ): Result<List<LiveAccountBalance>> {
            balanceCallsCount++
            return Result.success(balances)
        }
    }

    // 1. LIVE TRADING STATE: Default must be LIVE_TRADING_OFF
    @Test
    fun testLiveTradingStateDefaultIsOff() {
        val defaultState = LiveTradingState.LIVE_TRADING_OFF
        assertFalse(defaultState.isEnabled)
        assertEquals("LIVE_TRADING_OFF", defaultState.name)

        val enabledState = LiveTradingState.LIVE_TRADING_ENABLED
        assertTrue(enabledState.isEnabled)
        assertEquals("LIVE_TRADING_ENABLED", enabledState.name)
    }

    // 2. LIVE TRADING STATE: Mode selection and disarming invariants
    @Test
    fun testLiveTradingMustBeDisarmedWhenModeIsNotLiveTrade() {
        var liveState = LiveTradingState.LIVE_TRADING_ENABLED
        var isLiveTradingEnabled = true

        val newMode = TradingMode.PAPER_TRADE
        if (newMode != TradingMode.LIVE_TRADE) {
            liveState = LiveTradingState.LIVE_TRADING_OFF
            isLiveTradingEnabled = false
        }

        assertEquals(LiveTradingState.LIVE_TRADING_OFF, liveState)
        assertFalse(isLiveTradingEnabled)
    }

    // 3. MARKET ISOLATION: Binance Live Trading is strictly restricted to Crypto
    @Test
    fun testMarketCategoryLiveCompatibility() {
        val cryptoMarket = MarketCategory.CRYPTO
        val forexMarket = MarketCategory.FOREX
        val goldMarket = MarketCategory.GOLD

        // Crypto is compatible with Binance
        assertTrue(cryptoMarket == MarketCategory.CRYPTO)

        // Forex and Gold must reject Binance live execution
        assertFalse(forexMarket == MarketCategory.CRYPTO)
        assertFalse(goldMarket == MarketCategory.CRYPTO)
    }

    // 4. API CONNECTION IS NOT AUTHORIZATION: Connection alone != Live Trading Permission
    @Test
    fun testBinanceApiConnectionAloneDoesNotAuthorizeLiveTrading() {
        val isBinanceConnected = true
        val hasCredentials = true
        val liveState = LiveTradingState.LIVE_TRADING_OFF
        val isLiveTradingExplicitlyAuthorized = false

        val canExecuteLiveOrder = isBinanceConnected && hasCredentials &&
                liveState == LiveTradingState.LIVE_TRADING_ENABLED && isLiveTradingExplicitlyAuthorized

        assertFalse("API connection alone must NEVER authorize live order execution", canExecuteLiveOrder)
    }

    // 5. LIVE TRADING AUTHORIZATION: Explicit confirmation required
    @Test
    fun testExplicitConfirmationEnablesLiveTrading() {
        var liveState = LiveTradingState.LIVE_TRADING_OFF
        var isAuthorized = false

        // User confirms safety prompt
        val userConfirmedPrompt = true
        if (userConfirmedPrompt) {
            liveState = LiveTradingState.LIVE_TRADING_ENABLED
            isAuthorized = true
        }

        assertEquals(LiveTradingState.LIVE_TRADING_ENABLED, liveState)
        assertTrue(isAuthorized)

        // User locks/disables live trading
        liveState = LiveTradingState.LIVE_TRADING_OFF
        isAuthorized = false
        assertEquals(LiveTradingState.LIVE_TRADING_OFF, liveState)
        assertFalse(isAuthorized)
    }

    // 6. LIVE TRADING GATEWAY: Only Live orders invoke gateway, Paper orders never do
    @Test
    fun testGatewayIsolationBetweenPaperAndLive() = runBlocking {
        val gateway = MockLiveTradingGateway()

        // Paper execution path
        val isPaperOrder = true
        if (!isPaperOrder) {
            gateway.submitLiveOrder("key", "secret", "BTCUSDT", TradeSide.BUY, OrderType.MARKET, 0.05, 64000.0, null, "P_1")
        }
        assertEquals(0, gateway.submitCallsCount)

        // Live execution path
        val isLiveOrder = true
        if (isLiveOrder) {
            gateway.submitLiveOrder("key", "secret", "BTCUSDT", TradeSide.BUY, OrderType.MARKET, 0.05, 64000.0, null, "L_1")
        }
        assertEquals(1, gateway.submitCallsCount)
        assertEquals("BTCUSDT", gateway.lastSubmittedSymbol)
        assertEquals(TradeSide.BUY, gateway.lastSubmittedSide)
        assertEquals(0.05, gateway.lastSubmittedQty ?: 0.0, 0.0001)
    }

    // 7. ORDER VALIDATION: Invalid or stale price rejected
    @Test
    fun testStaleOrInvalidPriceValidation() {
        val zeroPrice = 0.0
        val negativePrice = -100.0
        val nanPrice = Double.NaN
        val infPrice = Double.POSITIVE_INFINITY
        val isStaleData = true

        fun isValidPrice(price: Double, stale: Boolean): Boolean {
            return price > 0.0 && !price.isNaN() && !price.isInfinite() && !stale
        }

        assertFalse(isValidPrice(zeroPrice, false))
        assertFalse(isValidPrice(negativePrice, false))
        assertFalse(isValidPrice(nanPrice, false))
        assertFalse(isValidPrice(infPrice, false))
        assertFalse(isValidPrice(64000.0, isStaleData))
        assertTrue(isValidPrice(64000.0, false))
    }

    // 8. ORDER VALIDATION: Zero or negative quantity rejected
    @Test
    fun testQuantityValidation() {
        fun isValidQuantity(qty: Double): Boolean {
            return qty > 0.0 && !qty.isNaN() && !qty.isInfinite()
        }

        assertFalse(isValidQuantity(0.0))
        assertFalse(isValidQuantity(-0.01))
        assertFalse(isValidQuantity(Double.NaN))
        assertTrue(isValidQuantity(0.005))
    }

    // 9. ORDER VALIDATION: Minimum Notional validation (Binance min 5.0 USDT)
    @Test
    fun testMinimumNotionalValidation() {
        val minNotional = 5.0

        val smallPrice = 10.0
        val smallQty = 0.1
        val smallNotional = smallPrice * smallQty // 1.0 < 5.0
        assertTrue(smallNotional < minNotional)

        val validPrice = 64000.0
        val validQty = 0.001
        val validNotional = validPrice * validQty // 64.0 >= 5.0
        assertTrue(validNotional >= minNotional)
    }

    // 10. BALANCE VALIDATION: BUY requires sufficient quote asset balance
    @Test
    fun testQuoteBalanceValidationForBuy() {
        val quoteAvailable = 50.0
        val orderNotional = 120.0

        val hasSufficientBalance = quoteAvailable >= orderNotional
        assertFalse("Should fail BUY validation when quote balance is less than required notional", hasSufficientBalance)

        val sufficientQuote = 200.0
        assertTrue(sufficientQuote >= orderNotional)
    }

    // 11. BALANCE VALIDATION: SELL requires sufficient base asset balance
    @Test
    fun testBaseAssetBalanceValidationForSell() {
        val baseAssetAvailable = 0.02
        val sellQuantity = 0.05

        val hasSufficientBase = baseAssetAvailable >= sellQuantity
        assertFalse("Should fail SELL validation when base asset balance is less than sell quantity", hasSufficientBase)

        val sufficientBase = 0.1
        assertTrue(sufficientBase >= sellQuantity)
    }

    // 12. DUPLICATE ORDER SPAM PREVENTION: Cooldown of 3 seconds per symbol
    @Test
    fun testDuplicateOrderPrevention() {
        val symbolCooldownMap = mutableMapOf<String, Long>()
        val symbol = "BTCUSDT"

        val t0 = 100000L
        symbolCooldownMap[symbol] = t0

        val t1 = t0 + 1500L // 1.5 seconds later
        val isAllowedT1 = (t1 - (symbolCooldownMap[symbol] ?: 0L)) >= 3000L
        assertFalse("Order within 3 seconds must be rejected as duplicate spam", isAllowedT1)

        val t2 = t0 + 3500L // 3.5 seconds later
        val isAllowedT2 = (t2 - (symbolCooldownMap[symbol] ?: 0L)) >= 3000L
        assertTrue("Order after 3 seconds should be allowed", isAllowedT2)
    }

    // 13. STOP LOSS / TAKE PROFIT: Directional validation
    @Test
    fun testStopLossAndTakeProfitValidity() {
        val entryPrice = 50000.0

        // BUY: Stop loss must be below entry, Take profit must be above entry
        val validBuySl = 48000.0
        val validBuyTp = 54000.0
        val invalidBuySl = 51000.0
        val invalidBuyTp = 49000.0

        assertTrue(validBuySl < entryPrice)
        assertTrue(validBuyTp > entryPrice)
        assertFalse(invalidBuySl < entryPrice)
        assertFalse(invalidBuyTp > entryPrice)

        // SELL: Stop loss must be above entry, Take profit must be below entry
        val validSellSl = 52000.0
        val validSellTp = 46000.0
        val invalidSellSl = 49000.0
        val invalidSellTp = 51000.0

        assertTrue(validSellSl > entryPrice)
        assertTrue(validSellTp < entryPrice)
        assertFalse(invalidSellSl > entryPrice)
        assertFalse(invalidSellTp < entryPrice)
    }

    // 14. REAL ORDER LIFECYCLE: SUBMITTED -> FILLED
    @Test
    fun testRealOrderLifecycleSuccess() {
        val clientOrderId = "IQ_TEST_12345"
        val requestedPrice = 65000.0
        val requestedQty = 0.1

        // Initial submitted record
        var trade = TradeRecordEntity(
            id = 1L,
            symbol = "BTCUSDT",
            side = "BUY",
            orderType = "MARKET",
            quantity = requestedQty,
            price = requestedPrice,
            total = requestedPrice * requestedQty,
            isPaper = false,
            isOpen = false,
            status = "SUBMITTED",
            clientOrderId = clientOrderId,
            requestedPrice = requestedPrice
        )

        assertEquals("SUBMITTED", trade.status)
        assertFalse(trade.isOpen)
        assertNull(trade.exchangeOrderId)

        // Exchange confirmation
        val exchangeOrderId = "11223344"
        val fillPrice = 64980.0
        val executedQty = 0.1
        val commission = 0.00004
        val commissionAsset = "BNB"

        trade = trade.copy(
            exchangeOrderId = exchangeOrderId,
            status = "FILLED",
            price = fillPrice,
            averageFillPrice = fillPrice,
            executedQuantity = executedQty,
            total = fillPrice * executedQty,
            isOpen = true,
            commission = commission,
            commissionAsset = commissionAsset,
            filledTimestamp = System.currentTimeMillis(),
            updatedTimestamp = System.currentTimeMillis()
        )

        assertEquals("FILLED", trade.status)
        assertTrue(trade.isOpen)
        assertEquals(exchangeOrderId, trade.exchangeOrderId)
        assertEquals(fillPrice, trade.averageFillPrice ?: 0.0, 0.001)
        assertEquals(executedQty, trade.executedQuantity ?: 0.0, 0.0001)
        assertEquals(commission, trade.commission ?: 0.0, 0.000001)
        assertEquals("BNB", trade.commissionAsset)
    }

    // 15. PARTIAL FILL LIFECYCLE: Continues synchronization until fully filled
    @Test
    fun testPartialFillLifecycle() {
        var trade = TradeRecordEntity(
            id = 2L,
            symbol = "ETHUSDT",
            side = "BUY",
            orderType = "LIMIT",
            quantity = 2.0,
            price = 3500.0,
            total = 7000.0,
            isPaper = false,
            isOpen = false,
            status = "SUBMITTED",
            clientOrderId = "ETH_LIMIT_1"
        )

        // Partial fill response: 0.8 executed
        trade = trade.copy(
            exchangeOrderId = "556677",
            status = "PARTIALLY_FILLED",
            executedQuantity = 0.8,
            averageFillPrice = 3495.0,
            isOpen = true
        )

        assertEquals("PARTIALLY_FILLED", trade.status)
        assertTrue(trade.isOpen)
        assertEquals(0.8, trade.executedQuantity ?: 0.0, 0.0001)

        // Complete fill response: remaining 1.2 executed (total 2.0)
        trade = trade.copy(
            status = "FILLED",
            executedQuantity = 2.0,
            averageFillPrice = 3498.0
        )

        assertEquals("FILLED", trade.status)
        assertEquals(2.0, trade.executedQuantity ?: 0.0, 0.0001)
    }

    // 16. EXCHANGE REJECTION: Proper REJECTED state without opening position
    @Test
    fun testExchangeRejectionHandling() {
        var trade = TradeRecordEntity(
            id = 3L,
            symbol = "SOLUSDT",
            side = "BUY",
            orderType = "MARKET",
            quantity = 1.0,
            price = 150.0,
            total = 150.0,
            isPaper = false,
            isOpen = false,
            status = "SUBMITTED"
        )

        // Mark rejected
        trade = trade.copy(
            status = "REJECTED",
            isOpen = false,
            updatedTimestamp = System.currentTimeMillis()
        )

        assertEquals("REJECTED", trade.status)
        assertFalse(trade.isOpen)
    }

    // 17. TRAILING STOP RATCHET: Favorable direction only
    @Test
    fun testLiveTrailingStopRatchet() {
        val entryPrice = 60000.0
        val trailingDistPct = 2.0 // 2%
        var currentStop = entryPrice * (1.0 - (trailingDistPct / 100.0)) // 58800.0

        // Price moves up favorably to 62000.0
        val newHigherPrice = 62000.0
        val candidateStop1 = newHigherPrice * (1.0 - (trailingDistPct / 100.0)) // 60760.0
        if (candidateStop1 > currentStop) {
            currentStop = candidateStop1
        }
        assertEquals(60760.0, currentStop, 0.01)

        // Price drops to 61000.0 - Stop MUST NOT ratchet down
        val pullBackPrice = 61000.0
        val candidateStop2 = pullBackPrice * (1.0 - (trailingDistPct / 100.0)) // 59780.0
        if (candidateStop2 > currentStop) {
            currentStop = candidateStop2
        }
        assertEquals("Stop loss must never move downwards on pullback", 60760.0, currentStop, 0.01)
    }

    // 18. LIVE P&L AND FEES ISOLATION: Live trades do not touch Paper balance
    @Test
    fun testPnlAndBalanceIsolation() {
        val paperBalanceBefore = 10000.0
        val liveBalanceBefore = 2500.0

        // Execute Live Trade fill: BUY 0.1 BTC @ 60000.0, Fee = $5.0
        val liveTrade = TradeRecordEntity(
            id = 10L,
            symbol = "BTCUSDT",
            side = "BUY",
            orderType = "MARKET",
            quantity = 0.1,
            price = 60000.0,
            total = 6000.0,
            isPaper = false,
            isOpen = true,
            status = "FILLED",
            commission = 5.0,
            commissionAsset = "USDT"
        )

        // Paper balance must remain completely unaffected
        val paperBalanceAfter = paperBalanceBefore
        assertEquals(10000.0, paperBalanceAfter, 0.001)

        // Live unrealized P&L calculation with current price = 62000.0
        val currentPrice = 62000.0
        val unrealizedPnl = (currentPrice - liveTrade.price) * liveTrade.quantity
        assertEquals(200.0, unrealizedPnl, 0.001)

        // Close position
        val closePrice = 62500.0
        val realizedPnl = (closePrice - liveTrade.price) * liveTrade.quantity
        assertEquals(250.0, realizedPnl, 0.001)

        // Net PnL after fee
        val netPnl = realizedPnl - (liveTrade.commission ?: 0.0)
        assertEquals(245.0, netPnl, 0.001)
    }

    // 19. WIN RATE ISOLATION: Paper win rate and Live win rate calculated separately
    @Test
    fun testWinRateIsolation() {
        val trades = listOf(
            // Paper trades: 1 win, 1 loss = 50%
            TradeRecordEntity(id = 1, symbol = "BTCUSDT", side = "BUY", orderType = "MARKET", quantity = 0.1, price = 60000.0, total = 6000.0, isPaper = true, isOpen = false, realizedPnl = 150.0),
            TradeRecordEntity(id = 2, symbol = "ETHUSDT", side = "BUY", orderType = "MARKET", quantity = 1.0, price = 3000.0, total = 3000.0, isPaper = true, isOpen = false, realizedPnl = -50.0),
            // Live trades: 2 wins, 0 losses = 100%
            TradeRecordEntity(id = 3, symbol = "BTCUSDT", side = "BUY", orderType = "MARKET", quantity = 0.05, price = 61000.0, total = 3050.0, isPaper = false, isOpen = false, realizedPnl = 80.0),
            TradeRecordEntity(id = 4, symbol = "SOLUSDT", side = "BUY", orderType = "MARKET", quantity = 2.0, price = 140.0, total = 280.0, isPaper = false, isOpen = false, realizedPnl = 40.0)
        )

        val paperClosed = trades.filter { it.isPaper && !it.isOpen && it.realizedPnl != null }
        val paperWinRate = (paperClosed.count { (it.realizedPnl ?: 0.0) > 0 }.toDouble() / paperClosed.size) * 100.0
        assertEquals(50.0, paperWinRate, 0.01)

        val liveClosed = trades.filter { !it.isPaper && !it.isOpen && it.realizedPnl != null }
        val liveWinRate = (liveClosed.count { (it.realizedPnl ?: 0.0) > 0 }.toDouble() / liveClosed.size) * 100.0
        assertEquals(100.0, liveWinRate, 0.01)
    }

    // 20. EMERGENCY PANIC CLOSE: Disarms Auto & Live Trading and closes open positions
    @Test
    fun testPanicCloseBehavior() {
        var autoTradingArmed = true
        var liveTradingState = LiveTradingState.LIVE_TRADING_ENABLED

        val openTrades = mutableListOf(
            TradeRecordEntity(id = 1, symbol = "BTCUSDT", side = "BUY", orderType = "MARKET", quantity = 0.1, price = 60000.0, total = 6000.0, isPaper = true, isOpen = true),
            TradeRecordEntity(id = 2, symbol = "ETHUSDT", side = "BUY", orderType = "MARKET", quantity = 1.0, price = 3000.0, total = 3000.0, isPaper = false, isOpen = true)
        )

        // Execute Panic Stop
        autoTradingArmed = false
        liveTradingState = LiveTradingState.LIVE_TRADING_OFF
        for (i in openTrades.indices) {
            openTrades[i] = openTrades[i].copy(isOpen = false, status = "CLOSED")
        }

        assertFalse("Auto trading must be disarmed immediately", autoTradingArmed)
        assertEquals("Live trading must be locked immediately", LiveTradingState.LIVE_TRADING_OFF, liveTradingState)
        assertTrue("All positions must be closed", openTrades.none { it.isOpen })
    }

    // 21. API SECURITY: Never print secret keys or sensitive auth tokens in logs
    @Test
    fun testApiSecurityAuditLogDoesNotContainSecret() {
        val apiKey = "vmPUZE6mv9SD5VNHk4HlWFsOr6aKE2zvsw0MuIgwCIPy6utIco14y7Ju91duEh8A"
        val secretKey = "NhqPtmdSJYdKjVHjA7PZj4Mge3R5YNiP1e3UZjPRSTtkAcDsGather2491bXv"

        val auditLogMessage = "Submitting Live Order: symbol=BTCUSDT, side=BUY, type=MARKET, qty=0.01, clientOrderId=IQ_123"

        assertFalse("Audit log must NEVER contain private secret key", auditLogMessage.contains(secretKey))
        assertFalse("Audit log must NEVER contain API key", auditLogMessage.contains(apiKey))
    }

    // 22. AUTO TRADING ENGINE ISOLATION: Auto trade must not execute live orders without authorization
    @Test
    fun testAutoTradeEngineCannotSilentlyExecuteLiveOrders() {
        val isAutoTradingEnabled = true
        val activeMode = TradingMode.LIVE_TRADE
        val isLiveAuthorized = false
        val liveState = LiveTradingState.LIVE_TRADING_OFF

        val canExecute = isAutoTradingEnabled &&
                (activeMode != TradingMode.LIVE_TRADE || (isLiveAuthorized && liveState == LiveTradingState.LIVE_TRADING_ENABLED))

        assertFalse("Auto Trading must NOT trigger live order without explicit Live authorization", canExecute)
    }

    // 23. ORDER TYPE SUPPORT: MARKET, LIMIT, STOP_TRIGGER correctly mapped
    @Test
    fun testOrderTypeMapping() {
        val marketOrder = OrderType.MARKET
        val limitOrder = OrderType.LIMIT
        val stopOrder = OrderType.STOP_TRIGGER

        val binanceMarketType = when (marketOrder) {
            OrderType.MARKET -> "MARKET"
            OrderType.LIMIT -> "LIMIT"
            OrderType.STOP_TRIGGER -> "STOP_LOSS_LIMIT"
        }
        assertEquals("MARKET", binanceMarketType)

        val binanceLimitType = when (limitOrder) {
            OrderType.MARKET -> "MARKET"
            OrderType.LIMIT -> "LIMIT"
            OrderType.STOP_TRIGGER -> "STOP_LOSS_LIMIT"
        }
        assertEquals("LIMIT", binanceLimitType)

        val binanceStopType = when (stopOrder) {
            OrderType.MARKET -> "MARKET"
            OrderType.LIMIT -> "LIMIT"
            OrderType.STOP_TRIGGER -> "STOP_LOSS_LIMIT"
        }
        assertEquals("STOP_LOSS_LIMIT", binanceStopType)
    }

    // 24. RECONCILIATION: Reconciling open orders with authoritative exchange status
    @Test
    fun testOrderReconciliationWithExchange() = runBlocking {
        val gateway = MockLiveTradingGateway()
        gateway.nextSubmitResult = LiveOrderResult.Success(
            exchangeOrderId = "888",
            clientOrderId = "RECON_1",
            symbol = "BTCUSDT",
            side = "BUY",
            orderType = "LIMIT",
            status = "FILLED",
            executedQty = 0.05,
            origQty = 0.05,
            avgFillPrice = 64150.0,
            commission = 0.00003,
            commissionAsset = "BNB",
            transactTime = System.currentTimeMillis()
        )

        val result = gateway.queryOrder("key", "secret", "BTCUSDT", "888", "RECON_1")
        assertTrue(result is LiveOrderResult.Success)
        val success = result as LiveOrderResult.Success
        assertEquals("FILLED", success.status)
        assertEquals(64150.0, success.avgFillPrice, 0.01)
        assertEquals(0.05, success.executedQty, 0.0001)
    }

    // 25. ACCOUNT BALANCE QUERY: Reactive balance parsing (Free and Locked)
    @Test
    fun testLiveAccountBalancesQuery() = runBlocking {
        val gateway = MockLiveTradingGateway()
        val res = gateway.queryAccountBalances("key", "secret")
        assertTrue(res.isSuccess)
        val balances = res.getOrThrow()

        val usdtBal = balances.find { it.asset == "USDT" }
        assertNotNull(usdtBal)
        assertEquals(2500.0, usdtBal?.free ?: 0.0, 0.01)
        assertEquals(100.0, usdtBal?.locked ?: 0.0, 0.01)
        assertEquals(2600.0, (usdtBal?.free ?: 0.0) + (usdtBal?.locked ?: 0.0), 0.01)

        val btcBal = balances.find { it.asset == "BTC" }
        assertNotNull(btcBal)
        assertEquals(0.75, btcBal?.free ?: 0.0, 0.0001)
    }

    // 26. STOP LOSS MODE VALIDATION: Fixed, Trailing, and Manual
    @Test
    fun testProtectionStopLossModes() {
        val fixedProtection = TradeProtectionState(stopLossMode = StopLossMode.FIXED, stopLossPercentage = 1.5)
        assertEquals(StopLossMode.FIXED, fixedProtection.stopLossMode)
        assertEquals(1.5, fixedProtection.stopLossPercentage, 0.001)

        val trailingProtection = TradeProtectionState(stopLossMode = StopLossMode.TRAILING, trailingDistancePct = 2.5)
        assertEquals(StopLossMode.TRAILING, trailingProtection.stopLossMode)
        assertEquals(2.5, trailingProtection.trailingDistancePct, 0.001)

        val manualProtection = TradeProtectionState(stopLossMode = StopLossMode.MANUAL, stopLossPrice = 58500.0)
        assertEquals(StopLossMode.MANUAL, manualProtection.stopLossMode)
        assertEquals(58500.0, manualProtection.stopLossPrice ?: 0.0, 0.01)
    }
}
