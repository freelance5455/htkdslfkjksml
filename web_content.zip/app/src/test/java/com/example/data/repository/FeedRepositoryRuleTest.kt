package com.example.data.repository

import com.example.base.FirestoreEmulatorTestBase
import com.example.data.model.ArkGroup
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.UUID

class FeedRepositoryRuleTest : FirestoreEmulatorTestBase() {

    private fun uniqueEmail(prefix: String) = "${prefix}_${UUID.randomUUID().toString().take(8)}@test.com"

    @Test
    fun createPost_paginatedFeed_reactions_comments_and_poll_workEndToEnd() = runBlocking {
        val aliceEmail = uniqueEmail("alice_social")
        val bobEmail = uniqueEmail("bob_social")
        val aliceUid = signInTestUser(aliceEmail)

        val userRepo = UserRepository(firestore)
        val feedRepo = FeedRepository(firestore)

        val aliceUsername = "alice_${UUID.randomUUID().toString().take(5)}"
        assertTrue(
            withTimeout(DEFAULT_TIMEOUT_MS) {
                userRepo.createProfile(aliceUsername, "Alice", "", "prism_cyan", "adult_18_plus", true, aliceEmail)
            }.isSuccess
        )
        // Enable public posts in privacy settings for Explore test
        assertTrue(
            withTimeout(DEFAULT_TIMEOUT_MS) {
                userRepo.updatePrivacyPreferences(
                    isPrivateAccount = false,
                    allowFriendRequests = "everyone",
                    showOnlineStatus = true,
                    optOutLeaderboard = false
                )
            }.isSuccess
        )
        val aliceProfile = withTimeout(FLOW_TIMEOUT_MS) {
            userRepo.observeUserProfile(aliceUid).first { it != null && !it.isPrivateAccount }
        }!!

        // Create a poll post (public)
        val pollIdRes = withTimeout(DEFAULT_TIMEOUT_MS) {
            feedRepo.createPost(
                author = aliceProfile,
                postType = "poll",
                category = "Gaming",
                caption = "Which party game tonight?",
                imageBase64List = emptyList(),
                visibility = "public",
                friends = emptyList(),
                selectedGroups = emptyList(),
                pollQuestion = "Best late night ARK game?",
                pollOptions = listOf("Mafia", "Quiz Battle", "Word Chain")
            )
        }
        assertTrue("Poll post create failed: ${pollIdRes.exceptionOrNull()}", pollIdRes.isSuccess)
        val pollPostId = pollIdRes.getOrThrow()

        // Create a friends-only text post
        val privIdRes = withTimeout(DEFAULT_TIMEOUT_MS) {
            feedRepo.createPost(
                author = aliceProfile,
                postType = "text",
                category = "Friends",
                caption = "Private squad update!",
                imageBase64List = emptyList(),
                visibility = "friends",
                friends = emptyList(),
                selectedGroups = emptyList()
            )
        }
        assertTrue("Friends post create failed: ${privIdRes.exceptionOrNull()}", privIdRes.isSuccess)
        val friendsPostId = privIdRes.getOrThrow()

        // Cursor pagination check on Alice's feed
        val page1 = withTimeout(DEFAULT_TIMEOUT_MS) {
            feedRepo.fetchFeedPage(aliceUid, pageSize = 1L)
        }.getOrThrow()
        assertEquals(1, page1.posts.size)
        assertTrue(page1.hasMore)

        val page2 = withTimeout(DEFAULT_TIMEOUT_MS) {
            feedRepo.fetchFeedPage(aliceUid, pageSize = 1L, lastDocument = page1.lastDocument)
        }.getOrThrow()
        assertEquals(1, page2.posts.size)

        // Switch to Bob (not Alice's friend) -> Bob sees Explore public poll, NOT Alice's friends-only post
        val bobUid = signInTestUser(bobEmail)
        val bobUsername = "bob_${UUID.randomUUID().toString().take(5)}"
        assertTrue(
            withTimeout(DEFAULT_TIMEOUT_MS) {
                userRepo.createProfile(bobUsername, "Bob", "", "cyber_violet", "adult_18_plus", true, bobEmail)
            }.isSuccess
        )
        val bobProfile = withTimeout(FLOW_TIMEOUT_MS) {
            userRepo.observeUserProfile(bobUid).first { it != null }
        }!!

        val explorePage = withTimeout(DEFAULT_TIMEOUT_MS) {
            feedRepo.fetchExplorePage(pageSize = 20L)
        }.getOrThrow()
        assertTrue(explorePage.posts.any { it.id == pollPostId })
        assertTrue(explorePage.posts.none { it.id == friendsPostId })

        // Bob likes/reacts & votes & comments on Alice's public poll
        assertTrue(withTimeout(DEFAULT_TIMEOUT_MS) { feedRepo.toggleReaction(pollPostId, bobUsername, "fire") }.isSuccess)
        assertTrue(withTimeout(DEFAULT_TIMEOUT_MS) { feedRepo.votePoll(pollPostId, 1) }.isSuccess)
        // Duplicate poll vote fails cleanly
        assertTrue(withTimeout(DEFAULT_TIMEOUT_MS) { feedRepo.votePoll(pollPostId, 0) }.isFailure)

        val pollPost = explorePage.posts.first { it.id == pollPostId }
        assertTrue(withTimeout(DEFAULT_TIMEOUT_MS) {
            feedRepo.addComment(pollPost, bobProfile, "Quiz Battle for sure!")
        }.isSuccess)
        val comments = withTimeout(FLOW_TIMEOUT_MS) {
            feedRepo.observeComments(pollPostId).first { it.isNotEmpty() }
        }
        assertEquals("Quiz Battle for sure!", comments.first().text)

        // Bookmark & unbookmark
        val saved = withTimeout(DEFAULT_TIMEOUT_MS) { feedRepo.toggleBookmark(pollPostId) }.getOrThrow()
        assertTrue(saved)
        val unsaved = withTimeout(DEFAULT_TIMEOUT_MS) { feedRepo.toggleBookmark(pollPostId) }.getOrThrow()
        assertFalse(unsaved)
    }

    @Test
    fun stories_create_viewersOwnerOnly_and_deleteWorkCorrectly() = runBlocking {
        val aliceEmail = uniqueEmail("alice_st")
        val bobEmail = uniqueEmail("bob_st")
        val aliceUid = signInTestUser(aliceEmail)

        val userRepo = UserRepository(firestore)
        val storyRepo = StoryRepository(firestore)

        assertTrue(
            withTimeout(DEFAULT_TIMEOUT_MS) {
                userRepo.createProfile("alice_${UUID.randomUUID().toString().take(5)}", "Alice", "", "prism_cyan", "adult_18_plus", true, aliceEmail)
            }.isSuccess
        )
        val aliceProfile = withTimeout(FLOW_TIMEOUT_MS) { userRepo.observeUserProfile(aliceUid).first { it != null } }!!

        // Create Bob first so we can put him in visibleToUids
        val bobUid = signInTestUser(bobEmail)
        assertTrue(
            withTimeout(DEFAULT_TIMEOUT_MS) {
                userRepo.createProfile("bob_${UUID.randomUUID().toString().take(5)}", "Bob", "", "cyber_violet", "adult_18_plus", true, bobEmail)
            }.isSuccess
        )
        val bobProfile = withTimeout(FLOW_TIMEOUT_MS) { userRepo.observeUserProfile(bobUid).first { it != null } }!!

        // Sign back in as Alice to create a group-scoped story visible to Bob
        signInTestUser(aliceEmail)
        val group = ArkGroup(id = "g1", memberUids = listOf(aliceUid, bobUid))
        val storyId = withTimeout(DEFAULT_TIMEOUT_MS) {
            storyRepo.createStory(
                author = aliceProfile,
                mediaType = "image",
                imageBase64 = "ZmFrZV9pbWFnZQ==",
                caption = "Ready to game!",
                visibility = "group",
                friends = emptyList(),
                selectedGroups = listOf(group)
            )
        }.getOrThrow()

        // Bob views Alice's story -> viewer record created
        signInTestUser(bobEmail)
        val bobVisibleStories = withTimeout(FLOW_TIMEOUT_MS) {
            storyRepo.observeActiveStories(bobUid).first { list -> list.any { it.id == storyId } }
        }
        val targetStory = bobVisibleStories.first { it.id == storyId }
        val markRes = withTimeout(DEFAULT_TIMEOUT_MS) {
            storyRepo.markStoryViewed(targetStory, bobProfile)
        }
        assertTrue("markStoryViewed failed: ${markRes.exceptionOrNull()}", markRes.isSuccess)

        // Bob cannot list viewers -> flow catches PERMISSION_DENIED and emits emptyList()
        val bobViewers = withTimeout(FLOW_TIMEOUT_MS) {
            storyRepo.observeStoryViewers(storyId).first()
        }
        assertTrue("Non-owner must not see viewers", bobViewers.isEmpty())

        // Alice (story owner) sees Bob in viewers and can delete own story!
        signInTestUser(aliceEmail)
        val aliceViewers = withTimeout(FLOW_TIMEOUT_MS) {
            storyRepo.observeStoryViewers(storyId).first { it.isNotEmpty() }
        }
        assertEquals(bobUid, aliceViewers.first().viewerUid)
        assertTrue(withTimeout(DEFAULT_TIMEOUT_MS) { storyRepo.deleteStory(storyId) }.isSuccess)
    }

    @Test
    fun unauthenticatedUser_cannotListPosts() = runBlocking {
        auth.signOut()
        val feedRepo = FeedRepository(firestore)
        val res = withTimeout(DEFAULT_TIMEOUT_MS) {
            feedRepo.fetchExplorePage()
        }
        assertTrue(res.isFailure)
        val ex = res.exceptionOrNull()?.unwrapFirestoreException()
        assertNotNull(ex)
        assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, ex?.code)
    }

    @Test
    fun videoPost_and_videoStory_multiBatchChunks_uploadEndToEnd() = runBlocking {
        val aliceEmail = uniqueEmail("alice_video")
        val aliceUid = signInTestUser(aliceEmail)

        val userRepo = UserRepository(firestore)
        val feedRepo = FeedRepository(firestore)
        val storyRepo = StoryRepository(firestore)

        assertTrue(
            withTimeout(DEFAULT_TIMEOUT_MS) {
                userRepo.createProfile(
                    username = "avid_${UUID.randomUUID().toString().take(5)}",
                    displayTag = "VideoCreator",
                    bio = "",
                    avatarPreset = "prism_cyan",
                    ageBracket = "adult_18_plus",
                    parentalConsentApproved = true,
                    email = aliceEmail
                )
            }.isSuccess
        )
        assertTrue(
            withTimeout(DEFAULT_TIMEOUT_MS) {
                userRepo.updatePrivacyPreferences(
                    isPrivateAccount = false,
                    allowFriendRequests = "everyone",
                    showOnlineStatus = true,
                    optOutLeaderboard = false
                )
            }.isSuccess
        )
        val aliceProfile = withTimeout(FLOW_TIMEOUT_MS) {
            userRepo.observeUserProfile(aliceUid).first { it != null && !it.isPrivateAccount }
        }!!

        // 11 chunks forces Batch 1 (chunks 0..8) + Batch 2 (chunks 9..10)
        val chunks = List(11) { idx -> "Y2h1bmtf$idx" }
        val videoPostRes = withTimeout(DEFAULT_TIMEOUT_MS) {
            feedRepo.createPost(
                author = aliceProfile,
                postType = "video",
                category = "Creativity",
                caption = "Testing multi-batch video upload",
                imageBase64List = emptyList(),
                visibility = "public",
                friends = emptyList(),
                selectedGroups = emptyList(),
                videoThumbnailBase64 = "dGh1bWJuYWls",
                videoDurationMs = 8500L,
                videoChunksBase64 = chunks
            )
        }
        assertTrue("Video post create failed: ${videoPostRes.exceptionOrNull()}", videoPostRes.isSuccess)
        val postId = videoPostRes.getOrThrow()

        val loadedPage = withTimeout(DEFAULT_TIMEOUT_MS) {
            feedRepo.fetchFeedPage(aliceUid, pageSize = 10L)
        }.getOrThrow()
        val createdPost = loadedPage.posts.firstOrNull { it.id == postId }
        assertNotNull(createdPost)
        assertEquals(11L, createdPost?.videoChunkCount)

        // Video Story with 10 chunks (Batch 1 + Batch 2)
        val storyChunks = List(10) { idx -> "c3Rvcnlf$idx" }
        val storyRes = withTimeout(DEFAULT_TIMEOUT_MS) {
            storyRepo.createStory(
                author = aliceProfile,
                mediaType = "video",
                imageBase64 = "dGh1bWJuYWls",
                caption = "Video story!",
                visibility = "friends",
                friends = emptyList(),
                selectedGroups = emptyList(),
                videoDurationMs = 6200L,
                videoChunksBase64 = storyChunks
            )
        }
        assertTrue("Video story create failed: ${storyRes.exceptionOrNull()}", storyRes.isSuccess)
        val storyId = storyRes.getOrThrow()

        val activeStories = withTimeout(FLOW_TIMEOUT_MS) {
            storyRepo.observeActiveStories(aliceUid).first { list -> list.any { it.id == storyId } }
        }
        val createdStory = activeStories.first { it.id == storyId }
        assertEquals("video", createdStory.mediaType)
        assertEquals(10L, createdStory.videoChunkCount)
    }

    private companion object {
        const val DEFAULT_TIMEOUT_MS = 6000L
        const val FLOW_TIMEOUT_MS = 5000L
    }
}

