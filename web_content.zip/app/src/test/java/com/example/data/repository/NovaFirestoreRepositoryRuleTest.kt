package com.example.data.repository

import com.example.base.FirestoreEmulatorTestBase
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class NovaFirestoreRepositoryRuleTest : FirestoreEmulatorTestBase() {

    @Test
    fun createAndObserveConversation_authenticatedOwner_succeeds() = runBlocking {
        val aliceUid = signInTestUser(ALICE_EMAIL)
        val repository = NovaFirestoreRepository(firestore, auth)

        val createResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.createConversation("NOVA AI Architecture", "Hello NOVA!")
        }
        assertTrue(createResult.isSuccess)
        val convId = createResult.getOrThrow()
        assertTrue(convId.isNotEmpty())

        val emitted = withTimeout(FLOW_TIMEOUT_MS) {
            repository.observeConversations(aliceUid).first { list -> list.any { it.id == convId } }
        }
        assertTrue(emitted.any { it.id == convId && it.title == "NOVA AI Architecture" })

        val msgResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.addMessage(convId, "user", "Hello NOVA, explain Kotlin coroutines.")
        }
        assertTrue(msgResult.isSuccess)
        val msgId = msgResult.getOrThrow()

        val messages = withTimeout(FLOW_TIMEOUT_MS) {
            repository.observeMessages(aliceUid, convId).first { list -> list.any { it.id == msgId } }
        }
        assertTrue(messages.any { it.id == msgId && it.role == "user" })
    }

    @Test
    fun getConversation_crossUserAccess_failsWithPermissionDenied() = runBlocking {
        val aliceUid = signInTestUser(ALICE_EMAIL)
        val aliceRepo = NovaFirestoreRepository(firestore, auth)
        val convId = withTimeout(DEFAULT_TIMEOUT_MS) {
            aliceRepo.createConversation("Alice Private Chat", "Secret").getOrThrow()
        }

        signInTestUser(BOB_EMAIL)
        val bobRepo = NovaFirestoreRepository(firestore, auth)
        val result = withTimeout(DEFAULT_TIMEOUT_MS) {
            bobRepo.getConversationById(aliceUid, convId)
        }
        assertTrue(result.isFailure)
        val exception = result.exceptionOrNull() as? FirebaseFirestoreException
        assertNotNull(exception)
        assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, exception?.code)
    }

    @Test
    fun observeConversations_unauthenticatedUser_failsWithPermissionDenied() = runBlocking {
        val aliceUid = signInTestUser(ALICE_EMAIL)
        auth.signOut()
        val repository = NovaFirestoreRepository(firestore, auth)

        var caughtException: FirebaseFirestoreException? = null
        try {
            withTimeout(FLOW_TIMEOUT_MS) {
                repository.observeConversations(aliceUid).first()
            }
        } catch (t: Throwable) {
            var curr: Throwable? = t
            while (curr != null) {
                if (curr is FirebaseFirestoreException) {
                    caughtException = curr
                    break
                }
                curr = curr.cause
            }
        }
        assertNotNull(caughtException)
        assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, caughtException?.code)
    }

    private companion object {
        const val ALICE_EMAIL = "alice_nova@test.com"
        const val BOB_EMAIL = "bob_nova@test.com"
        const val DEFAULT_TIMEOUT_MS = 5000L
        const val FLOW_TIMEOUT_MS = 3000L
    }
}
