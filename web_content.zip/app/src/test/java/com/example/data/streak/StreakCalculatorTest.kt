package com.example.data.streak

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

class StreakCalculatorTest {

    @Test
    fun `test a normal streak without missed days`() {
        val baseDate = LocalDate.of(2026, 11, 10)
        val minutesMap = mapOf(
            baseDate.plusDays(0) to 25,
            baseDate.plusDays(1) to 30,
            baseDate.plusDays(2) to 15,
            baseDate.plusDays(3) to 45,
            baseDate.plusDays(4) to 20
        )
        val today = baseDate.plusDays(4) // 5 days total

        val result = StreakCalculator.calculateStreak(minutesMap, today)

        assertEquals("Current streak should be 5", 5, result.currentStreak)
        assertEquals("Longest streak should be 5", 5, result.longestStreak)
        assertTrue("Frozen dates should be empty", result.frozenDates.isEmpty())
        assertEquals("Freezes used should be 0", 0, result.freezesUsedThisMonth)
        assertEquals("Freezes remaining should be 2", 2, result.freezesRemainingThisMonth)
        assertTrue("Studied today should be true", result.isStudiedToday)
    }

    @Test
    fun `test a single missed day covered by an automatic streak freeze`() {
        val baseDate = LocalDate.of(2026, 11, 1)
        val minutesMap = mapOf(
            baseDate.plusDays(0) to 20, // Day 1: studied
            // Day 2: missed (0 minutes)
            baseDate.plusDays(2) to 35  // Day 3 (today): studied
        )
        val today = baseDate.plusDays(2)

        val result = StreakCalculator.calculateStreak(minutesMap, today)

        // Day 1 (+1), Day 2 (freeze applied, keeps alive, does not add to count), Day 3 (+1) -> streak = 2
        assertEquals("Current streak should be 2", 2, result.currentStreak)
        assertEquals("Longest streak should be 2", 2, result.longestStreak)
        assertTrue("Day 2 should be in frozen dates", result.frozenDates.contains(baseDate.plusDays(1)))
        assertEquals("Frozen dates count should be 1", 1, result.frozenDates.size)
        assertEquals("Freezes used in November should be 1", 1, result.freezesUsedThisMonth)
        assertEquals("Freezes remaining in November should be 1", 1, result.freezesRemainingThisMonth)
        assertTrue("Studied today should be true", result.isStudiedToday)
    }

    @Test
    fun `test two missed days in a row resets current streak to 0`() {
        val baseDate = LocalDate.of(2026, 11, 1)
        val minutesMap = mapOf(
            baseDate.plusDays(0) to 40, // Day 1: studied (streak = 1)
            // Day 2: missed (would consume 1 freeze)
            // Day 3: missed (second missed day in a row -> streak breaks to 0)
            // Day 4 (today): not studied yet
        )
        val today = baseDate.plusDays(3)

        val result = StreakCalculator.calculateStreak(minutesMap, today)

        assertEquals("Current streak must reset to 0 after 2 consecutive missed days", 0, result.currentStreak)
        assertEquals("Longest streak should remain 1", 1, result.longestStreak)
        assertFalse("Studied today should be false", result.isStudiedToday)
    }

    @Test
    fun `test running out of freezes in the same calendar month resets streak`() {
        val baseDate = LocalDate.of(2026, 11, 1)
        val minutesMap = mapOf(
            baseDate.plusDays(0) to 25, // Nov 1: studied (streak = 1)
            // Nov 2: missed -> freeze 1 used
            baseDate.plusDays(2) to 20, // Nov 3: studied (streak = 2)
            // Nov 4: missed -> freeze 2 used (all 2 freezes for November exhausted)
            baseDate.plusDays(4) to 30, // Nov 5: studied (streak = 3)
            // Nov 6: missed -> 0 freezes left in Nov -> streak resets to 0!
            baseDate.plusDays(6) to 15  // Nov 7 (today): studied -> new streak of 1
        )
        val today = baseDate.plusDays(6)

        val result = StreakCalculator.calculateStreak(minutesMap, today)

        assertEquals("Current streak should be 1 after restarting following exhausted freezes", 1, result.currentStreak)
        assertEquals("Longest streak should be 3 from Nov 1-5", 3, result.longestStreak)
        assertEquals("All 2 freezes should be used this month", 2, result.freezesUsedThisMonth)
        assertEquals("0 freezes remaining this month", 0, result.freezesRemainingThisMonth)
        assertEquals("Exactly 2 days should be marked frozen", 2, result.frozenDates.size)
        assertTrue("Nov 2 was frozen", result.frozenDates.contains(baseDate.plusDays(1)))
        assertTrue("Nov 4 was frozen", result.frozenDates.contains(baseDate.plusDays(3)))
        assertFalse("Nov 6 could not be frozen", result.frozenDates.contains(baseDate.plusDays(5)))
        assertTrue("Studied today should be true", result.isStudiedToday)
    }

    @Test
    fun `test day requires at least 10 minutes to count toward streak`() {
        val baseDate = LocalDate.of(2026, 11, 1)
        val minutesMap = mapOf(
            baseDate.plusDays(0) to 9,  // Day 1: 9 minutes (< 10 min -> partial, not qualified)
            baseDate.plusDays(1) to 10  // Day 2 (today): 10 minutes (qualified)
        )
        val today = baseDate.plusDays(1)

        val result = StreakCalculator.calculateStreak(minutesMap, today)

        assertEquals("Current streak should be 1 because 9 mins does not qualify", 1, result.currentStreak)
        assertTrue("Day 1 should be in partialDates", result.partialDates.contains(baseDate.plusDays(0)))
        assertFalse("Day 1 should not be in studiedDates", result.studiedDates.contains(baseDate.plusDays(0)))
        assertTrue("Day 2 should be in studiedDates", result.studiedDates.contains(baseDate.plusDays(1)))
    }
}
