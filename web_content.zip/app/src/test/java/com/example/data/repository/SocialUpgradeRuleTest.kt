package com.example.data.repository

import com.example.base.FirestoreEmulatorTestBase
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.UUID

class SocialUpgradeRuleTest : FirestoreEmulatorTestBase() {

    private fun uniqueEmail(prefix: String) = "${prefix}_${UUID.randomUUID().toString().take(8)}@test.com"

    @Test
    fun followPublic_followRequestPrivate_and_unfollowUpdateCountsCorrectly() = runBlocking {
        val aliceEmail = uniqueEmail("alice_flw")
        val bobEmail = uniqueEmail("bob_flw")
        val aliceUid = signInTestUser(aliceEmail)

        val userRepo = UserRepository(firestore)
        val followRepo = FollowRepository(firestore)

        val aliceUser = "alice_${UUID.randomUUID().toString().take(5)}"
        assertTrue(
            withTimeout(DEFAULT_TIMEOUT_MS) {
                userRepo.createProfile(aliceUser, "Alice", "Creator", "prism_cyan", "adult_18_plus", true, aliceEmail, fullName = "Alice Ray")
            }.isSuccess
        )
        // Alice switches to public account
        assertTrue(
            withTimeout(DEFAULT_TIMEOUT_MS) {
                userRepo.updatePrivacyPreferences(
                    isPrivateAccount = false,
                    allowFriendRequests = "everyone",
                    showOnlineStatus = true,
                    optOutLeaderboard = false,
                    allowMessagesFrom = "everyone"
                )
            }.isSuccess
        )
        val aliceProfile = withTimeout(FLOW_TIMEOUT_MS) {
            userRepo.observeUserProfile(aliceUid).first { it != null && !it.isPrivateAccount }
        }!!

        // Bob signs up (private by default)
        val bobUid = signInTestUser(bobEmail)
        val bobUser = "bob_${UUID.randomUUID().toString().take(5)}"
        assertTrue(
            withTimeout(DEFAULT_TIMEOUT_MS) {
                userRepo.createProfile(bobUser, "Bob", "Gamer", "cyber_violet", "adult_18_plus", true, bobEmail, fullName = "Bob Rao")
            }.isSuccess
        )
        val bobProfile = withTimeout(FLOW_TIMEOUT_MS) {
            userRepo.observeUserProfile(bobUid).first { it != null }
        }!!

        // Bob follows public Alice -> immediate "following"
        val res1 = withTimeout(DEFAULT_TIMEOUT_MS) {
            followRepo.followOrRequestUser(bobProfile, aliceProfile)
        }.getOrThrow()
        assertEquals("following", res1)

        val bobFollowing = withTimeout(FLOW_TIMEOUT_MS) {
            followRepo.observeFollowing(bobUid).first { it.any { e -> e.peerUid == aliceUid } }
        }
        assertEquals(1, bobFollowing.size)

        // Alice checks username availability + requests to follow private Bob
        signInTestUser(aliceEmail)
        assertFalse(withTimeout(DEFAULT_TIMEOUT_MS) { userRepo.checkUsernameAvailable(bobUser, aliceUid) }.getOrThrow())
        assertTrue(withTimeout(DEFAULT_TIMEOUT_MS) { userRepo.checkUsernameAvailable("brand_new_name", aliceUid) }.getOrThrow())

        val refreshedAlice = withTimeout(FLOW_TIMEOUT_MS) {
            userRepo.observeUserProfile(aliceUid).first { it != null && it.followersCount == 1L }
        }!!
        val res2 = withTimeout(DEFAULT_TIMEOUT_MS) {
            followRepo.followOrRequestUser(refreshedAlice, bobProfile)
        }.getOrThrow()
        assertEquals("requested", res2)

        // Bob accepts Alice's follow request
        signInTestUser(bobEmail)
        val incoming = withTimeout(FLOW_TIMEOUT_MS) {
            followRepo.observeIncomingFollowRequests(bobUid).first { it.isNotEmpty() }
        }
        val refreshedBob = withTimeout(FLOW_TIMEOUT_MS) {
            userRepo.observeUserProfile(bobUid).first { it != null }
        }!!
        assertTrue(
            withTimeout(DEFAULT_TIMEOUT_MS) {
                followRepo.acceptFollowRequest(incoming.first(), refreshedBob)
            }.isSuccess
        )

        val bobFollowers = withTimeout(FLOW_TIMEOUT_MS) {
            followRepo.observeFollowers(bobUid).first { it.any { e -> e.peerUid == aliceUid } }
        }
        assertEquals(1, bobFollowers.size)

        // Bob unfollows Alice -> count decrements cleanly
        assertTrue(withTimeout(DEFAULT_TIMEOUT_MS) { followRepo.unfollowUser(aliceUid) }.isSuccess)
        val bobAfterUnfollow = withTimeout(FLOW_TIMEOUT_MS) {
            userRepo.observeUserProfile(bobUid).first { it != null && it.followingCount == 0L }
        }!!
        assertEquals(0L, bobAfterUnfollow.followingCount)
    }

    @Test
    fun hashtags_tagApproval_highlights_and_directMessages_workEndToEnd() = runBlocking {
        val aliceEmail = uniqueEmail("alice_dm")
        val bobEmail = uniqueEmail("bob_dm")
        val aliceUid = signInTestUser(aliceEmail)

        val userRepo = UserRepository(firestore)
        val feedRepo = FeedRepository(firestore)
        val storyRepo = StoryRepository(firestore)
        val dmRepo = DirectMessageRepository(firestore)

        assertTrue(
            withTimeout(DEFAULT_TIMEOUT_MS) {
                userRepo.createProfile("alice_${UUID.randomUUID().toString().take(5)}", "Alice", "", "prism_cyan", "adult_18_plus", true, aliceEmail)
            }.isSuccess
        )
        assertTrue(
            withTimeout(DEFAULT_TIMEOUT_MS) {
                userRepo.updatePrivacyPreferences(
                    isPrivateAccount = false,
                    allowFriendRequests = "everyone",
                    showOnlineStatus = true,
                    optOutLeaderboard = false,
                    allowMessagesFrom = "everyone",
                    requireTagApproval = false
                )
            }.isSuccess
        )

        val bobUid = signInTestUser(bobEmail)
        assertTrue(
            withTimeout(DEFAULT_TIMEOUT_MS) {
                userRepo.createProfile("bob_${UUID.randomUUID().toString().take(5)}", "Bob", "", "cyber_violet", "adult_18_plus", true, bobEmail)
            }.isSuccess
        )
        assertTrue(
            withTimeout(DEFAULT_TIMEOUT_MS) {
                userRepo.updatePrivacyPreferences(
                    isPrivateAccount = false,
                    allowFriendRequests = "everyone",
                    showOnlineStatus = true,
                    optOutLeaderboard = false,
                    allowMessagesFrom = "everyone",
                    requireTagApproval = true
                )
            }.isSuccess
        )
        val bobProfile = withTimeout(FLOW_TIMEOUT_MS) {
            userRepo.observeUserProfile(bobUid).first { it != null && it.requireTagApproval }
        }!!

        // Alice publishes a hashtagged post tagging Bob + saves a Story into Highlight
        signInTestUser(aliceEmail)
        val aliceProfile = withTimeout(FLOW_TIMEOUT_MS) {
            userRepo.observeUserProfile(aliceUid).first { it != null && !it.isPrivateAccount }
        }!!
        val postId = withTimeout(DEFAULT_TIMEOUT_MS) {
            feedRepo.createPost(
                author = aliceProfile,
                postType = "photo",
                category = "Photography",
                caption = "Evening vibes with #ArkSquad #Sunset",
                imageBase64List = listOf("ZmFrZV9pbWFnZQ=="),
                visibility = "public",
                friends = emptyList(),
                selectedGroups = emptyList(),
                locationLabel = "Bengaluru",
                altTexts = listOf("Orange sunset over rooftops"),
                taggedUids = listOf(bobUid)
            )
        }.getOrThrow()

        val tagPosts = withTimeout(FLOW_TIMEOUT_MS) {
            feedRepo.observeExplorePostsByHashtag("arksquad").first { list -> list.any { it.id == postId } }
        }
        assertEquals("Bengaluru", tagPosts.first().locationLabel)
        assertTrue(tagPosts.first().pendingTagUids.contains(bobUid))

        // Bob sees pending tag request and approves it, plus opens DM & sends message
        signInTestUser(bobEmail)
        val pending = withTimeout(FLOW_TIMEOUT_MS) {
            feedRepo.observePendingTagRequests(bobUid).first { list -> list.any { it.id == postId } }
        }
        assertTrue(pending.isNotEmpty())
        assertTrue(withTimeout(DEFAULT_TIMEOUT_MS) { feedRepo.approvePostTag(postId) }.isSuccess)

        val conv = withTimeout(DEFAULT_TIMEOUT_MS) {
            dmRepo.openOrStartConversation(bobProfile, aliceProfile, emptyList(), emptyList(), isBlocked = false)
        }.getOrThrow()
        assertTrue(
            withTimeout(DEFAULT_TIMEOUT_MS) {
                dmRepo.sendDirectMessage(conv, bobProfile, "Loved that sunset photo!")
            }.isSuccess
        )

        signInTestUser(aliceEmail)
        val msgs = withTimeout(FLOW_TIMEOUT_MS) {
            dmRepo.observeMessages(conv.id).first { it.isNotEmpty() }
        }
        assertEquals("Loved that sunset photo!", msgs.first().text)

        // Alice creates Story + saves to permanent Highlight
        val storyId = withTimeout(DEFAULT_TIMEOUT_MS) {
            storyRepo.createStory(
                author = aliceProfile,
                mediaType = "image",
                imageBase64 = "ZmFrZV9zdG9yeQ==",
                caption = "Highlight moment",
                visibility = "public",
                friends = emptyList(),
                selectedGroups = emptyList()
            )
        }.getOrThrow()
        val story = withTimeout(FLOW_TIMEOUT_MS) {
            storyRepo.observeActiveStories(aliceUid).first { list -> list.any { it.id == storyId } }
        }.first { it.id == storyId }

        val hlRes = withTimeout(DEFAULT_TIMEOUT_MS) {
            storyRepo.createHighlight(aliceProfile, "Best Moments", story, emptyList(), emptyList())
        }
        assertTrue("Create highlight failed: ${hlRes.exceptionOrNull()}", hlRes.isSuccess)
    }

    private companion object {
        const val DEFAULT_TIMEOUT_MS = 6000L
        const val FLOW_TIMEOUT_MS = 5000L
    }
}
