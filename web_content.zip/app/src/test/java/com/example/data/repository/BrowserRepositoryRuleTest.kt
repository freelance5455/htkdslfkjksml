package com.example.data.repository

import com.example.base.FirestoreEmulatorTestBase
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class BrowserRepositoryRuleTest : FirestoreEmulatorTestBase() {

    @Test
    fun createAndObserveBookmark_authenticatedOwner_succeeds() = runBlocking {
        val uid = signInTestUser(ALICE_EMAIL)
        val repository = BrowserRepository(firestore)

        val createResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.addBookmark(
                title = "Yapay Zeka Makalesi",
                url = "https://ai.google.dev",
                category = "Araştırma",
                note = "Gemini notları"
            )
        }
        assertTrue(createResult.isSuccess)
        val bookmarkId = createResult.getOrThrow()
        assertTrue(bookmarkId.isNotEmpty())

        val emitted = withTimeout(FLOW_TIMEOUT_MS) {
            repository.observeBookmarks(uid).first { list -> list.any { it.id == bookmarkId } }
        }
        assertTrue(emitted.any { it.id == bookmarkId && it.title == "Yapay Zeka Makalesi" })
    }

    @Test
    fun createAndUpdateTab_authenticatedOwner_succeeds() = runBlocking {
        val uid = signInTestUser(ALICE_EMAIL)
        val repository = BrowserRepository(firestore)

        val tabId = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.createTab(
                title = "İlk Sekme",
                url = "bratcher://index.html",
                lastQuery = "Kuantum Fiziği"
            ).getOrThrow()
        }

        val updateRes = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.updateTab(
                tabId = tabId,
                title = "Kuantum Araştırması",
                url = "https://tr.wikipedia.org/wiki/Kuantum_mekani%C4%9Fi",
                lastQuery = "Kuantum Fiziği",
                isPinned = true
            )
        }
        assertTrue(updateRes.isSuccess)

        val tabs = withTimeout(FLOW_TIMEOUT_MS) {
            repository.observeTabs(uid).first { list -> list.any { it.id == tabId && it.isPinned } }
        }
        assertTrue(tabs.any { it.id == tabId && it.title == "Kuantum Araştırması" })
    }

    @Test
    fun crossUserBookmarkRead_failsWithPermissionDenied() = runBlocking {
        signInTestUser(ALICE_EMAIL)
        val aliceRepo = BrowserRepository(firestore)
        val bookmarkId = withTimeout(DEFAULT_TIMEOUT_MS) {
            aliceRepo.addBookmark(
                title = "Alice Özel Kasa",
                url = "https://example.com/secret",
                category = "Güvenli Kasa",
                note = "Gizli not"
            ).getOrThrow()
        }

        signInTestUser(BOB_EMAIL)
        val bobRepo = BrowserRepository(firestore)
        val result = withTimeout(DEFAULT_TIMEOUT_MS) {
            bobRepo.getBookmarkById(bookmarkId)
        }
        assertTrue(result.isFailure)
        val firestoreException = result.exceptionOrNull()?.unwrapFirestoreException()
        assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, firestoreException?.code)
    }

    @Test
    fun unauthenticatedObserveBookmarks_failsWithPermissionDenied() = runBlocking {
        auth.signOut()
        val repository = BrowserRepository(firestore)

        try {
            withTimeout(FLOW_TIMEOUT_MS) {
                repository.observeBookmarks("unauth_user").first()
            }
            fail("Expected exception for unauthenticated user")
        } catch (e: Exception) {
            val firestoreException = e.unwrapFirestoreException()
            assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, firestoreException?.code)
        }
    }

    private companion object {
        const val ALICE_EMAIL = "alice@bratcher.test"
        const val BOB_EMAIL = "bob@bratcher.test"
        const val DEFAULT_TIMEOUT_MS = 5000L
        const val FLOW_TIMEOUT_MS = 3000L
    }
}
