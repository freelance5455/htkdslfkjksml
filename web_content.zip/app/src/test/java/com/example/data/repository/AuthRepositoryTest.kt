package com.example.data.repository

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.database.AppDatabase
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class AuthRepositoryTest {

    private lateinit var database: AppDatabase
    private lateinit var authRepository: AuthRepository

    @Before
    fun setup() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        database = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        authRepository = AuthRepository(
            userDao = database.userDao(),
            profileDao = database.profileDao(),
            appSettingsDao = database.appSettingsDao(),
            internalFilesDir = File(context.filesDir, "test")
        )
    }

    @After
    fun tearDown() {
        database.close()
    }

    @Test
    fun testLoginWithoutAccountReturnsClearSignUpGuidance() = runBlocking {
        val result = authRepository.login("someuser", "password123")
        assertTrue("Result should be error", result is AuthResult.Error)
        val errorMessage = (result as AuthResult.Error).message
        assertTrue(
            "Error message should guide user to Sign Up",
            errorMessage.contains("Sign Up", ignoreCase = true)
        )
    }

    @Test
    fun testLoginWithEmailPrefixAndTrailingSpaceMatchesRegisteredUser() = runBlocking {
        // Sign up with username "arjunasalpara"
        val signUpResult = authRepository.signUp("arjunasalpara", "SecureStudy2026")
        assertTrue("Sign up must succeed", signUpResult is AuthResult.Success)

        // 1. Login with exact username
        val exactLogin = authRepository.login("arjunasalpara", "SecureStudy2026")
        assertTrue("Exact login must succeed", exactLogin is AuthResult.Success)

        // 2. Login with email address (e.g. arjunasalpara@gmail.com)
        val emailLogin = authRepository.login("arjunasalpara@gmail.com", "SecureStudy2026")
        assertTrue("Email address matching prefix must succeed", emailLogin is AuthResult.Success)

        // 3. Login with trailing space in password (common mobile keyboard auto-space issue)
        val spaceLogin = authRepository.login("arjunasalpara", "SecureStudy2026 ")
        assertTrue("Login with password trailing space must succeed", spaceLogin is AuthResult.Success)
    }
}
