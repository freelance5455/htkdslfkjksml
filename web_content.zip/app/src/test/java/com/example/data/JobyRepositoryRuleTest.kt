package com.example.data

import com.example.base.FirestoreEmulatorTestBase
import com.example.model.JobListing
import com.example.model.UserProfile
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.UUID

class JobyRepositoryRuleTest : FirestoreEmulatorTestBase() {

  @Test
  fun upsertUserProfile_authenticatedOwner_writesAndObservesProfile() = runBlocking {
    val uid = signInTestUser("seeker_${UUID.randomUUID()}@joby.in")
    val repo = JobyRepository(firestore)

    val profile = UserProfile(
      userId = uid,
      displayName = "Priya Nair",
      email = "priya@joby.in",
      role = "SEEKER",
      age = 24L,
      state = "Kerala",
      city = "Kochi",
      pincode = "682001",
      skills = listOf("Kotlin", "UI Design")
    )

    val result = withTimeout(DEFAULT_TIMEOUT_MS) { repo.upsertUserProfile(profile) }
    assertTrue("Profile upsert should succeed: ${result.exceptionOrNull()}", result.isSuccess)

    val observed = withTimeout(FLOW_TIMEOUT_MS) {
      repo.observeUserProfile(uid).first { it != null && it.displayName == "Priya Nair" }
    }
    assertEquals("Kochi", observed?.city)
  }

  @Test
  fun createJob_authenticatedEmployer_createsPendingZeroFeeJob() = runBlocking {
    val employerUid = signInTestUser("employer_${UUID.randomUUID()}@joby.in")
    val repo = JobyRepository(firestore)

    val job = JobListing(
      employerId = employerUid,
      companyName = "Deccan Tech Systems",
      companyVerified = false,
      title = "Support Engineer",
      category = "Technology",
      jobType = "FULL_TIME",
      state = "Telangana",
      city = "Hyderabad",
      pincode = "500081",
      isRemote = false,
      salaryMinInr = 25000L,
      salaryMaxInr = 40000L,
      salaryPeriod = "MONTH",
      experienceLevel = "FRESHER",
      description = "Assist enterprise customers in Hyderabad with onboarding and troubleshooting.",
      requirements = "Graduate, fluent in Telugu and English.",
      minAge = 18L,
      isHazardousOrRestricted = false,
      applicationFee = 0L
    )

    val createRes = withTimeout(DEFAULT_TIMEOUT_MS) { repo.createJob(job) }
    assertTrue("Job creation should succeed: ${createRes.exceptionOrNull()}", createRes.isSuccess)
    val jobId = createRes.getOrThrow()

    val employerJobs = withTimeout(FLOW_TIMEOUT_MS) {
      repo.observeEmployerJobs(employerUid).first { list -> list.any { it.id == jobId } }
    }
    val created = employerJobs.first { it.id == jobId }
    assertEquals("PENDING", created.moderationStatus)
    assertEquals(0L, created.applicationFee)
  }

  @Test
  fun getUserProfile_crossUserAccess_failsWithPermissionDenied() = runBlocking {
    val aliceUid = signInTestUser("alice_${UUID.randomUUID()}@joby.in")
    val aliceRepo = JobyRepository(firestore)
    withTimeout(DEFAULT_TIMEOUT_MS) {
      aliceRepo.upsertUserProfile(
        UserProfile(userId = aliceUid, displayName = "Alice Verma", role = "SEEKER", age = 21L)
      ).getOrThrow()
    }

    signInTestUser("bob_${UUID.randomUUID()}@joby.in")
    val bobRepo = JobyRepository(firestore)

    var thrown: FirebaseFirestoreException? = null
    try {
      withTimeout(DEFAULT_TIMEOUT_MS) { bobRepo.getUserProfile(aliceUid) }
    } catch (e: Exception) {
      thrown = e.unwrapFirestoreException()
    }
    assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, thrown?.code)
  }

  @Test
  fun observeApprovedJobs_unauthenticated_failsWithPermissionDenied() = runBlocking {
    auth.signOut()
    val repo = JobyRepository(firestore)

    var thrown: FirebaseFirestoreException? = null
    try {
      withTimeout(FLOW_TIMEOUT_MS) { repo.observeApprovedJobs("anon").first() }
    } catch (e: Exception) {
      thrown = e.unwrapFirestoreException()
    }
    assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, thrown?.code)
  }

  private companion object {
    const val DEFAULT_TIMEOUT_MS = 5000L
    const val FLOW_TIMEOUT_MS = 3000L
  }
}
