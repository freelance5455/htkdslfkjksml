package com.example.data.analytics

import com.example.data.model.StudySessionEntity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

class PerformanceCalculatorTest {

    @Test
    fun `test week boundaries calculation for current and previous weeks`() {
        // Wednesday Nov 11, 2026
        val refDate = LocalDate.of(2026, 11, 11)
        val range = PerformanceCalculator.getWeekDateRange(refDate, weekOffset = 0)

        // Monday Nov 9 to Sunday Nov 15
        assertEquals(LocalDate.of(2026, 11, 9), range.startDate)
        assertEquals(LocalDate.of(2026, 11, 15), range.endDate)

        // Previous week: Monday Nov 2 to Sunday Nov 8
        assertEquals(LocalDate.of(2026, 11, 2), range.prevStartDate)
        assertEquals(LocalDate.of(2026, 11, 8), range.prevEndDate)

        // Previous week offset (-1)
        val prevRange = PerformanceCalculator.getWeekDateRange(refDate, weekOffset = -1)
        assertEquals(LocalDate.of(2026, 11, 2), prevRange.startDate)
        assertEquals(LocalDate.of(2026, 11, 8), prevRange.endDate)
    }

    @Test
    fun `test month boundaries calculation for standard and leap periods`() {
        // November has 30 days
        val novDate = LocalDate.of(2026, 11, 15)
        val novRange = PerformanceCalculator.getMonthDateRange(novDate, monthOffset = 0)
        assertEquals(LocalDate.of(2026, 11, 1), novRange.startDate)
        assertEquals(LocalDate.of(2026, 11, 30), novRange.endDate)

        // Previous month is October (31 days)
        assertEquals(LocalDate.of(2026, 10, 1), novRange.prevStartDate)
        assertEquals(LocalDate.of(2026, 10, 31), novRange.prevEndDate)

        // Leap year February (e.g. 2028 has 29 days)
        val feb2028 = LocalDate.of(2028, 2, 10)
        val febRange = PerformanceCalculator.getMonthDateRange(feb2028, monthOffset = 0)
        assertEquals(LocalDate.of(2028, 2, 1), febRange.startDate)
        assertEquals(LocalDate.of(2028, 2, 29), febRange.endDate)
    }

    @Test
    fun `test year comparisons and percentage change calculation`() {
        val refDate = LocalDate.of(2026, 6, 15)
        val yearRange = PerformanceCalculator.getYearDateRange(refDate, yearOffset = 0)
        assertEquals(LocalDate.of(2026, 1, 1), yearRange.startDate)
        assertEquals(LocalDate.of(2026, 12, 31), yearRange.endDate)
        assertEquals(LocalDate.of(2025, 1, 1), yearRange.prevStartDate)
        assertEquals(LocalDate.of(2025, 12, 31), yearRange.prevEndDate)

        val sessions = listOf(
            // Previous year: 2025 (10 hours total = 600 mins)
            StudySessionEntity(id = 1, subjectId = 1, date = "2025-04-10", startTime = "10:00", durationMinutes = 600),
            // Current year: 2026 (15 hours total = 900 mins)
            StudySessionEntity(id = 2, subjectId = 1, date = "2026-05-12", startTime = "11:00", durationMinutes = 900)
        )

        val metrics = PerformanceCalculator.calculateYearlyPerformance(sessions, refDate, yearOffset = 0)
        assertEquals(900, metrics.totalMinutes)
        assertEquals(15.0, metrics.totalHours, 0.01)
        assertEquals(600, metrics.prevTotalMinutes)
        assertNotNull(metrics.percentageChange)
        // 900 vs 600 -> +50% increase
        assertEquals(50.0, metrics.percentageChange!!, 0.01)
        assertEquals(12, metrics.chartBars.size)
    }

    @Test
    fun `test weekly performance metrics best day and subject split`() {
        val refDate = LocalDate.of(2026, 11, 11) // Wed
        val sessions = listOf(
            // Mon Nov 9: 60 mins Math (id 1)
            StudySessionEntity(id = 1, subjectId = 1, date = "2026-11-09", startTime = "10:00", durationMinutes = 60),
            // Wed Nov 11: 180 mins Physics (id 2)
            StudySessionEntity(id = 2, subjectId = 2, date = "2026-11-11", startTime = "14:00", durationMinutes = 180)
        )

        val subjectNames = mapOf(1L to "Math", 2L to "Physics")
        val metrics = PerformanceCalculator.calculateWeeklyPerformance(sessions, refDate, weekOffset = 0, subjectNames)

        assertEquals(240, metrics.totalMinutes)
        assertEquals(4.0, metrics.totalHours, 0.01)
        assertEquals(2, metrics.sessionCount)
        assertEquals(LocalDate.of(2026, 11, 11), metrics.bestDayDate)
        assertEquals(180, metrics.bestDayMinutes)
        assertEquals(2L, metrics.mostStudiedSubjectId)
        assertEquals(1L, metrics.leastStudiedSubjectId)
        assertTrue(metrics.textSummary.contains("Physics"))
    }
}
