package com.example.data.repository

import com.example.base.FirestoreEmulatorTestBase
import com.example.data.model.ArkChallenge
import com.example.data.model.ArkGameType
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.UUID

class ArkRepositoryRuleTest : FirestoreEmulatorTestBase() {

    private fun uniqueEmail(prefix: String) = "${prefix}_${UUID.randomUUID().toString().take(8)}@test.com"

    @Test
    fun createProfile_and_observeProfile_succeedsForAuthenticatedOwner() = runBlocking {
        val email = uniqueEmail("alice_prof")
        val uid = signInTestUser(email)
        val userRepo = UserRepository(firestore)
        val username = "alice_${UUID.randomUUID().toString().take(6)}"

        val createResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            userRepo.createProfile(
                username = username,
                displayTag = "Alice Spark",
                bio = "Building squads on ARK",
                avatarPreset = "prism_cyan",
                ageBracket = "teen_13_17",
                parentalConsentApproved = true,
                email = email
            )
        }
        assertTrue("Expected profile creation to succeed: ${createResult.exceptionOrNull()}", createResult.isSuccess)

        val profile = withTimeout(FLOW_TIMEOUT_MS) {
            userRepo.observeUserProfile(uid).first { it != null }
        }
        assertNotNull(profile)
        assertEquals(username, profile?.username)
        assertEquals(50L, profile?.points)
    }

    @Test
    fun createGroup_and_sendMessage_enforcesPrivateMembershipIsolation() = runBlocking {
        val aliceEmail = uniqueEmail("alice_grp")
        val bobEmail = uniqueEmail("bob_grp")
        val aliceUid = signInTestUser(aliceEmail)
        val userRepo = UserRepository(firestore)
        val groupRepo = GroupRepository(firestore)

        val profRes = withTimeout(DEFAULT_TIMEOUT_MS) {
            userRepo.createProfile("alice_${UUID.randomUUID().toString().take(5)}", "Alice", "", "prism_cyan", "adult_18_plus", true, aliceEmail)
        }
        assertTrue("Profile creation failed: ${profRes.exceptionOrNull()}", profRes.isSuccess)
        val aliceProfile = withTimeout(FLOW_TIMEOUT_MS) { userRepo.observeUserProfile(aliceUid).first { it != null } }!!

        val groupResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            groupRepo.createGroup(
                name = "Test Squad ${UUID.randomUUID().toString().take(4)}",
                description = "Private crew",
                theme = "aurora",
                isPrivate = true,
                allowMediaDownloads = true
            )
        }
        assertTrue("Group creation failed: ${groupResult.exceptionOrNull()}", groupResult.isSuccess)
        val group = groupResult.getOrThrow()

        val msgResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            groupRepo.sendMessage(group, aliceProfile, "Hey squad! Ready for Quiz Battle?")
        }
        assertTrue("Message send failed: ${msgResult.exceptionOrNull()}", msgResult.isSuccess)

        val messages = withTimeout(FLOW_TIMEOUT_MS) {
            groupRepo.observeMessages(group.id, aliceUid).first { it.isNotEmpty() }
        }
        assertTrue(messages.any { it.text.contains("Quiz Battle") })

        // Cross-user isolation check: Bob is NOT a member and cannot observe Alice's private group
        val bobUid = signInTestUser(bobEmail)
        val bobGroups = withTimeout(FLOW_TIMEOUT_MS) {
            groupRepo.observeMyGroups(bobUid).first()
        }
        assertTrue(bobGroups.none { it.id == group.id })
    }

    @Test
    fun createGameRoom_and_submitMove_updatesScoresForJoinedPlayers() = runBlocking {
        val aliceEmail = uniqueEmail("alice_game")
        val aliceUid = signInTestUser(aliceEmail)
        val userRepo = UserRepository(firestore)
        val gameRepo = GameRepository(firestore)

        val profRes = withTimeout(DEFAULT_TIMEOUT_MS) {
            userRepo.createProfile("alice_${UUID.randomUUID().toString().take(5)}", "Alice", "", "prism_cyan", "adult_18_plus", true, aliceEmail)
        }
        assertTrue("Profile creation failed: ${profRes.exceptionOrNull()}", profRes.isSuccess)
        val aliceProfile = withTimeout(FLOW_TIMEOUT_MS) { userRepo.observeUserProfile(aliceUid).first { it != null } }!!

        val roomId = withTimeout(DEFAULT_TIMEOUT_MS) {
            gameRepo.createGameRoom(aliceProfile, ArkGameType.QUIZ_BATTLE, isPrivate = false).getOrThrow()
        }
        val room = withTimeout(FLOW_TIMEOUT_MS) {
            gameRepo.observeRoom(roomId).first { it != null }
        }!!

        withTimeout(DEFAULT_TIMEOUT_MS) {
            gameRepo.startOrAdvanceRound(room, 1L).getOrThrow()
        }
        val activeRoom = withTimeout(FLOW_TIMEOUT_MS) {
            gameRepo.observeRoom(roomId).first { it?.status == "playing" }
        }!!

        withTimeout(DEFAULT_TIMEOUT_MS) {
            gameRepo.submitMoveOrVote(activeRoom, "1", 40L).getOrThrow()
        }
        val scoredRoom = withTimeout(FLOW_TIMEOUT_MS) {
            gameRepo.observeRoom(roomId).first { (it?.scores?.get(aliceUid) ?: 0L) >= 40L }
        }!!
        assertEquals(40L, scoredRoom.scores[aliceUid])
    }

    @Test
    fun completeChallenge_preventsDuplicateRewardClaims() = runBlocking {
        val aliceEmail = uniqueEmail("alice_ch")
        val aliceUid = signInTestUser(aliceEmail)
        val userRepo = UserRepository(firestore)
        val challengeRepo = ChallengeRepository(firestore)

        val profRes = withTimeout(DEFAULT_TIMEOUT_MS) {
            userRepo.createProfile("alice_${UUID.randomUUID().toString().take(5)}", "Alice", "", "prism_cyan", "adult_18_plus", true, aliceEmail)
        }
        assertTrue("Profile creation failed: ${profRes.exceptionOrNull()}", profRes.isSuccess)

        val challenge = ArkChallenge(
            id = "ch_${UUID.randomUUID().toString().take(8)}",
            title = "Team Hype",
            description = "Send encouragement to a friend",
            category = "Friendship",
            difficulty = "Easy",
            frequency = "Daily",
            rewardPoints = 40L,
            isGroupChallenge = false,
            isActive = true,
            expiresLabel = "Today",
            createdBy = aliceUid
        )

        val firstClaim = withTimeout(DEFAULT_TIMEOUT_MS) {
            challengeRepo.completeChallenge(challenge, "Hyped my squad!", userRepo)
        }
        assertTrue("First challenge claim should succeed: ${firstClaim.exceptionOrNull()}", firstClaim.isSuccess)

        val secondClaim = withTimeout(DEFAULT_TIMEOUT_MS) {
            challengeRepo.completeChallenge(challenge, "Trying again", userRepo)
        }
        assertTrue("Duplicate claim must fail", secondClaim.isFailure)
    }

    @Test
    fun searchUserByUsername_and_joinPrivateGroupByInvite_succeedForAuthenticatedUsers() = runBlocking {
        val aliceEmail = uniqueEmail("alice_soc")
        val bobEmail = uniqueEmail("bob_soc")
        val aliceUid = signInTestUser(aliceEmail)
        val userRepo = UserRepository(firestore)
        val groupRepo = GroupRepository(firestore)
        val socialRepo = SocialRepository(firestore)
        val challengeRepo = ChallengeRepository(firestore)

        val aliceUsername = "alice_${UUID.randomUUID().toString().take(6)}"
        assertTrue(
            withTimeout(DEFAULT_TIMEOUT_MS) {
                userRepo.createProfile(aliceUsername, "Alice", "", "prism_cyan", "adult_18_plus", true, aliceEmail)
            }.isSuccess
        )

        val privateGroup = withTimeout(DEFAULT_TIMEOUT_MS) {
            groupRepo.createGroup("Invite Only ${UUID.randomUUID().toString().take(4)}", "Secret", "aurora", true, true)
        }.getOrThrow()

        withTimeout(DEFAULT_TIMEOUT_MS) {
            challengeRepo.ensureSafeChallengesSeeded()
        }

        // Bob searches Alice by exact username and joins Alice's private group using invite code
        val bobUid = signInTestUser(bobEmail)
        val bobUsername = "bob_${UUID.randomUUID().toString().take(6)}"
        assertTrue(
            withTimeout(DEFAULT_TIMEOUT_MS) {
                userRepo.createProfile(bobUsername, "Bob", "", "cyber_violet", "adult_18_plus", true, bobEmail)
            }.isSuccess
        )

        withTimeout(DEFAULT_TIMEOUT_MS) {
            challengeRepo.ensureSafeChallengesSeeded()
        }

        val searchRes = withTimeout(DEFAULT_TIMEOUT_MS) {
            socialRepo.searchUserByUsername(aliceUsername)
        }
        assertTrue("Expected username search to succeed: ${searchRes.exceptionOrNull()}", searchRes.isSuccess)
        assertTrue(searchRes.getOrThrow().any { it.userId == aliceUid })

        val joinRes = withTimeout(DEFAULT_TIMEOUT_MS) {
            groupRepo.joinGroupByInviteCode(privateGroup.inviteCode)
        }
        assertTrue("Expected private invite join to succeed: ${joinRes.exceptionOrNull()}", joinRes.isSuccess)
        assertEquals(privateGroup.id, joinRes.getOrThrow())

        val bobGroups = withTimeout(FLOW_TIMEOUT_MS) {
            groupRepo.observeMyGroups(bobUid).first { list -> list.any { it.id == privateGroup.id } }
        }
        assertTrue(bobGroups.any { it.id == privateGroup.id })
    }

    @Test
    fun unauthenticatedUser_observePublicLobbies_failsWithPermissionDenied() = runBlocking {
        auth.signOut()
        val gameRepo = GameRepository(firestore)

        var caught: Throwable? = null
        try {
            withTimeout(FLOW_TIMEOUT_MS) {
                gameRepo.observePublicLobbies().first()
            }
        } catch (e: Throwable) {
            caught = e
        }
        val firestoreEx = caught?.unwrapFirestoreException()
        assertNotNull("Expected nested FirebaseFirestoreException, got $caught", firestoreEx)
        assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, firestoreEx?.code)
    }

    @Test
    fun friendRequest_sendDuplicateResendAcceptAndBlocked_enforcesRulesAndWorksEndToEnd() = runBlocking {
        val aliceEmail = uniqueEmail("alice_fr")
        val bobEmail = uniqueEmail("bob_fr")
        val userRepo = UserRepository(firestore)
        val socialRepo = SocialRepository(firestore)

        // Create Alice
        val aliceUid = signInTestUser(aliceEmail)
        val aliceUsername = "alice_${UUID.randomUUID().toString().take(6)}"
        assertTrue(
            withTimeout(DEFAULT_TIMEOUT_MS) {
                userRepo.createProfile(aliceUsername, "Alice", "", "prism_cyan", "adult_18_plus", true, aliceEmail)
            }.isSuccess
        )
        val aliceProfile = withTimeout(FLOW_TIMEOUT_MS) {
            userRepo.observeUserProfile(aliceUid).first { it != null }
        }!!

        // Create Bob
        val bobUid = signInTestUser(bobEmail)
        val bobUsername = "bob_${UUID.randomUUID().toString().take(6)}"
        assertTrue(
            withTimeout(DEFAULT_TIMEOUT_MS) {
                userRepo.createProfile(bobUsername, "Bob", "", "cyber_violet", "adult_18_plus", true, bobEmail)
            }.isSuccess
        )
        val bobProfile = withTimeout(FLOW_TIMEOUT_MS) {
            userRepo.observeUserProfile(bobUid).first { it != null }
        }!!

        // Sign back in as Alice and send friend request + notification
        signInTestUser(aliceEmail)
        val firstSend = withTimeout(DEFAULT_TIMEOUT_MS) {
            socialRepo.sendFriendRequest(aliceProfile, bobProfile)
        }
        assertTrue("First sendFriendRequest failed: ${firstSend.exceptionOrNull()}", firstSend.isSuccess)
        withTimeout(DEFAULT_TIMEOUT_MS) {
            userRepo.sendNotification(
                recipientUid = bobUid,
                senderUsername = aliceProfile.username,
                type = "friend_request",
                title = "New Friend Request",
                body = "@${aliceProfile.username} wants to connect on ARK!"
            )
        }

        // Duplicate click while pending succeeds idempotently (no PERMISSION_DENIED)
        val duplicateSend = withTimeout(DEFAULT_TIMEOUT_MS) {
            socialRepo.sendFriendRequest(aliceProfile, bobProfile)
        }
        assertTrue("Duplicate send while pending failed: ${duplicateSend.exceptionOrNull()}", duplicateSend.isSuccess)

        // Alice cancels, then re-sends
        val cancelRes = withTimeout(DEFAULT_TIMEOUT_MS) {
            socialRepo.cancelFriendRequest(firstSend.getOrThrow())
        }
        assertTrue("Cancel failed: ${cancelRes.exceptionOrNull()}", cancelRes.isSuccess)
        val resendAfterCancel = withTimeout(DEFAULT_TIMEOUT_MS) {
            socialRepo.sendFriendRequest(aliceProfile, bobProfile)
        }
        assertTrue("Re-send after cancel failed: ${resendAfterCancel.exceptionOrNull()}", resendAfterCancel.isSuccess)

        // Bob declines, then Alice re-sends
        signInTestUser(bobEmail)
        val rejectRes = withTimeout(DEFAULT_TIMEOUT_MS) {
            socialRepo.rejectFriendRequest(firstSend.getOrThrow())
        }
        assertTrue("Reject failed: ${rejectRes.exceptionOrNull()}", rejectRes.isSuccess)

        signInTestUser(aliceEmail)
        val resendAfterReject = withTimeout(DEFAULT_TIMEOUT_MS) {
            socialRepo.sendFriendRequest(aliceProfile, bobProfile)
        }
        assertTrue("Re-send after reject failed: ${resendAfterReject.exceptionOrNull()}", resendAfterReject.isSuccess)

        // Bob accepts request
        signInTestUser(bobEmail)
        val incomingForBob = withTimeout(FLOW_TIMEOUT_MS) {
            socialRepo.observeIncomingRequests(bobUid).first { list -> list.any { it.fromUid == aliceUid } }
        }
        val reqForBob = incomingForBob.first { it.fromUid == aliceUid }
        val acceptRes = withTimeout(DEFAULT_TIMEOUT_MS) {
            socialRepo.acceptFriendRequest(reqForBob, bobProfile)
        }
        assertTrue("Accept friend request failed: ${acceptRes.exceptionOrNull()}", acceptRes.isSuccess)

        // Unfriend and re-add
        val removeRes = withTimeout(DEFAULT_TIMEOUT_MS) {
            socialRepo.removeFriend(aliceUid)
        }
        assertTrue("Remove friend failed: ${removeRes.exceptionOrNull()}", removeRes.isSuccess)

        signInTestUser(aliceEmail)
        val resendAfterUnfriend = withTimeout(DEFAULT_TIMEOUT_MS) {
            socialRepo.sendFriendRequest(aliceProfile, bobProfile)
        }
        assertTrue("Re-send after unfriend failed: ${resendAfterUnfriend.exceptionOrNull()}", resendAfterUnfriend.isSuccess)

        // Bob blocks Alice -> Alice's sendFriendRequest must fail with PERMISSION_DENIED
        signInTestUser(bobEmail)
        assertTrue(
            withTimeout(DEFAULT_TIMEOUT_MS) {
                socialRepo.blockUser(aliceUid, aliceUsername)
            }.isSuccess
        )

        signInTestUser(aliceEmail)
        val blockedSend = withTimeout(DEFAULT_TIMEOUT_MS) {
            socialRepo.sendFriendRequest(aliceProfile, bobProfile)
        }
        assertTrue("Blocked sendFriendRequest must fail", blockedSend.isFailure)
        val blockedFsEx = blockedSend.exceptionOrNull()?.unwrapFirestoreException()
        assertNotNull("Expected FirebaseFirestoreException when blocked, got ${blockedSend.exceptionOrNull()}", blockedFsEx)
        assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, blockedFsEx?.code)
    }

    private companion object {
        const val DEFAULT_TIMEOUT_MS = 5000L
        const val FLOW_TIMEOUT_MS = 4000L
    }
}
