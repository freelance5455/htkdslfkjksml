package com.example.data

import com.example.base.FirestoreEmulatorTestBase
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CreditRepositoryRuleTest : FirestoreEmulatorTestBase() {

  @Test
  fun ensureUserProfile_regularUser_createsAccountWith10Credits() = runBlocking {
    val freshEmail = "fresh.${java.util.UUID.randomUUID().toString().take(8)}@test.com"
    val uid = signInTestUser(freshEmail)
    val repo = CreditRepository(firestore, auth)

    val result = withTimeout(DEFAULT_TIMEOUT_MS) { repo.ensureUserProfile() }
    assertTrue("Expected ensureUserProfile to succeed: ${result.exceptionOrNull()}", result.isSuccess)
    val account = result.getOrThrow()
    assertEquals(uid, account.uid)
    assertEquals("user", account.role)
    assertEquals(10L, account.credits)
  }

  @Test
  fun adjustUserCredits_regularUser_failsWithPermissionDenied() = runBlocking {
    val aliceUid = signInTestUser(ALICE_EMAIL)
    val repo = CreditRepository(firestore, auth)
    withTimeout(DEFAULT_TIMEOUT_MS) { repo.ensureUserProfile().getOrThrow() }

    val result =
        withTimeout(DEFAULT_TIMEOUT_MS) {
          repo.adjustUserCredits(aliceUid, 100L, "Unauthorized self grant")
        }
    assertTrue("Regular user must NOT be able to add credits", result.isFailure)
    val fsErr = result.exceptionOrNull()?.unwrapFirestoreException()
    assertNotNull("Expected FirebaseFirestoreException", fsErr)
    assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, fsErr?.code)
  }

  @Test
  fun adminAdjustUserCredits_selfAndOtherUser_updatesBalanceAndWritesAuditLog() = runBlocking {
    // 1. Alice signs in first so her account exists
    val aliceUid = signInTestUser(ALICE_EMAIL)
    val aliceRepo = CreditRepository(firestore, auth)
    val aliceProfile = withTimeout(DEFAULT_TIMEOUT_MS) { aliceRepo.ensureUserProfile().getOrThrow() }
    val startAliceCredits = aliceProfile.credits

    // 2. Bootstrapped admin signs in
    val adminUid = signInTestUser(ADMIN_EMAIL)
    verifyEmulatorEmail(adminUid)
    withTimeout(DEFAULT_TIMEOUT_MS) { auth.currentUser?.getIdToken(true)?.await() }

    val adminRepo = CreditRepository(firestore, auth)
    val adminProfile = withTimeout(DEFAULT_TIMEOUT_MS) { adminRepo.ensureUserProfile().getOrThrow() }
    val startAdminCredits = adminProfile.credits

    // Admin adds 50 credits to own account
    val selfGrant =
        withTimeout(DEFAULT_TIMEOUT_MS) {
          adminRepo.adjustUserCredits(adminUid, 50L, "Self top-up test")
        }
    assertTrue("Admin self-grant failed: ${selfGrant.exceptionOrNull()}", selfGrant.isSuccess)
    assertEquals(startAdminCredits + 50L, selfGrant.getOrThrow())

    // Admin adds 25 credits to Alice's account
    val expectedAliceCredits = startAliceCredits + 25L
    val aliceGrant =
        withTimeout(DEFAULT_TIMEOUT_MS) {
          adminRepo.adjustUserCredits(aliceUid, 25L, "Gift to Alice")
        }
    assertTrue("Admin grant to Alice failed: ${aliceGrant.exceptionOrNull()}", aliceGrant.isSuccess)
    assertEquals(expectedAliceCredits, aliceGrant.getOrThrow())

    // Verify Alice sees updated balance
    signInTestUser(ALICE_EMAIL)
    val aliceObserved =
        withTimeout(FLOW_TIMEOUT_MS) {
          aliceRepo.observeCurrentUser(aliceUid).first { it != null && it.credits >= expectedAliceCredits }
        }
    assertEquals(expectedAliceCredits, aliceObserved?.credits)
  }

  @Test
  fun spendCredits_regularUser_decrementsOwnBalance() = runBlocking {
    val aliceUid = signInTestUser(ALICE_EMAIL)
    val repo = CreditRepository(firestore, auth)
    val initial = withTimeout(DEFAULT_TIMEOUT_MS) { repo.ensureUserProfile().getOrThrow() }

    val spendResult =
        withTimeout(DEFAULT_TIMEOUT_MS) { repo.spendCredits(1L, "AI Background Remover") }
    assertTrue("Spend credits failed: ${spendResult.exceptionOrNull()}", spendResult.isSuccess)
    assertEquals(initial.credits - 1L, spendResult.getOrThrow())

    val txs =
        withTimeout(FLOW_TIMEOUT_MS) {
          repo.observeTransactions(aliceUid, isAdmin = false).first { it.isNotEmpty() }
        }
    assertTrue(txs.any { it.type == "ai_usage" && it.amount == -1L })
  }

  @Test
  fun observeAllUsers_unauthenticatedUser_failsWithPermissionDenied() = runBlocking {
    auth.signOut()
    val repo = CreditRepository(firestore, auth)

    var caught: Throwable? = null
    try {
      withTimeout(FLOW_TIMEOUT_MS) { repo.observeAllUsers().first() }
    } catch (e: Exception) {
      caught = e
    }
    assertNotNull("Expected PERMISSION_DENIED exception", caught)
    val fsErr = caught?.unwrapFirestoreException()
    assertNotNull("Expected nested FirebaseFirestoreException, got $caught", fsErr)
    assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, fsErr?.code)
  }

  private fun verifyEmulatorEmail(uid: String) {
    // Mark emailVerified=true in Firebase Auth Emulator using owner admin header
    val url = java.net.URL("http://127.0.0.1:9099/identitytoolkit.googleapis.com/v1/projects/demo-no-project/accounts:update")
    val conn = (url.openConnection() as java.net.HttpURLConnection).apply {
      requestMethod = "POST"
      doOutput = true
      setRequestProperty("Content-Type", "application/json")
      setRequestProperty("Authorization", "Bearer owner")
    }
    val body = """{"localId":"$uid","emailVerified":true}"""
    conn.outputStream.use { it.write(body.toByteArray()) }
    val code = conn.responseCode
    conn.disconnect()
    assertTrue("Auth emulator emailVerified update failed with HTTP $code", code in 200..299)
  }

  private companion object {
    const val ADMIN_EMAIL = "mia85478667@gmail.com"
    const val ALICE_EMAIL = "alice.pixelforge@test.com"
    const val DEFAULT_TIMEOUT_MS = 5000L
    const val FLOW_TIMEOUT_MS = 3000L
  }
}
