package com.example.data.repository

import com.example.base.FirestoreEmulatorTestBase
import com.example.data.model.AiGeneratedChapterDraft
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class BookRepositoryRuleTest : FirestoreEmulatorTestBase() {

    @Test
    fun createBookWithChapters_authenticatedOwner_createsBookAndChapters() = runBlocking {
        val aliceUid = signInTestUser(ALICE_EMAIL)
        val repository = BookRepository(firestore)

        val drafts = listOf(
            AiGeneratedChapterDraft(
                chapterNumber = 1,
                title = "1. Bölüm: Başlangıç",
                summary = "İlk bölüm özeti",
                content = "Güneş doğarken eski kütüphanenin kapıları açıldı."
            )
        )

        val bookId = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.createBookWithChapters(
                title = "Zamanın Kütüphanesi",
                subtitle = "Bir Keşif Hikayesi",
                synopsis = "Antik el yazmalarının peşinde bir macera.",
                genre = "Roman",
                tone = "Edebi ve Derin",
                creationMethod = "ai",
                coverTheme = "crimson",
                chapters = drafts
            )
        }

        assertTrue(bookId.isNotEmpty())

        val books = withTimeout(FLOW_TIMEOUT_MS) {
            repository.observeBooks(aliceUid).first { list -> list.any { it.id == bookId } }
        }
        assertTrue(books.any { it.id == bookId && it.title == "Zamanın Kütüphanesi" })

        val chapters = withTimeout(FLOW_TIMEOUT_MS) {
            repository.observeChapters(aliceUid, bookId).first { it.isNotEmpty() }
        }
        assertEquals(1, chapters.size)
        assertEquals("1. Bölüm: Başlangıç", chapters.first().title)
    }

    @Test
    fun getBookById_crossUserAccess_failsWithPermissionDenied() = runBlocking {
        val aliceUid = signInTestUser(ALICE_EMAIL)
        val aliceRepo = BookRepository(firestore)

        val bookId = withTimeout(DEFAULT_TIMEOUT_MS) {
            aliceRepo.createBookWithChapters(
                title = "Alice'in Özel Kitabı",
                subtitle = "",
                synopsis = "Özel notlar",
                genre = "Roman",
                tone = "Akıcı ve Sürükleyici",
                creationMethod = "manual",
                coverTheme = "midnight",
                chapters = listOf(
                    AiGeneratedChapterDraft(1, "Bölüm 1", "", "Gizli içerik.")
                )
            )
        }

        signInTestUser(BOB_EMAIL)
        val bobRepo = BookRepository(firestore)
        try {
            withTimeout(DEFAULT_TIMEOUT_MS) {
                bobRepo.getBookById(aliceUid, bookId)
            }
            fail("Expected FirebaseFirestoreException PERMISSION_DENIED for cross-user access")
        } catch (e: FirebaseFirestoreException) {
            assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, e.code)
        }
    }

    @Test
    fun observeBooks_unauthenticatedUser_failsWithPermissionDenied() = runBlocking {
        val aliceUid = signInTestUser(ALICE_EMAIL)
        auth.signOut()
        val repository = BookRepository(firestore)

        try {
            withTimeout(FLOW_TIMEOUT_MS) {
                repository.observeBooks(aliceUid).first()
            }
            fail("Expected exception when observing books while unauthenticated")
        } catch (e: Exception) {
            val firestoreEx = e.unwrapFirestoreException()
            assertNotNull("Expected nested FirebaseFirestoreException, got $e", firestoreEx)
            assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, firestoreEx?.code)
        }
    }

    private companion object {
        const val ALICE_EMAIL = "alice@kitapatolyesi.test"
        const val BOB_EMAIL = "bob@kitapatolyesi.test"
        const val DEFAULT_TIMEOUT_MS = 5000L
        const val FLOW_TIMEOUT_MS = 3000L
    }
}
