package com.example.data.repository

import com.example.base.FirestoreEmulatorTestBase
import com.example.data.model.StudioProject
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class StudioProjectRepositoryRuleTest : FirestoreEmulatorTestBase() {

    private fun buildSampleProject(uid: String) = StudioProject(
        userId = uid,
        title = "JSON Schema Validator",
        prompt = "Build a JSON schema validator and formatter tool",
        provider = "GEMINI",
        modelId = "gemini-4-argon",
        summary = "Interactive validator with syntax diagnostics.",
        sandboxSpecJson = """{"appTitle":"JSON Validator","widgets":[]}""",
        kotlinCode = "package com.example\nclass MainActivity",
        manifestXml = "<manifest/>",
        buildGradleKts = "plugins {}",
        isPinned = false
    )

    @Test
    fun createProject_validPayload_createsDocumentAndReturnsId() = runBlocking {
        val uid = signInTestUser(ALICE_EMAIL)
        val repository = StudioProjectRepository(firestore)

        val createResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.createProject(buildSampleProject(uid))
        }
        assertTrue(createResult.isSuccess)
        val projectId = createResult.getOrThrow()
        assertTrue(projectId.isNotEmpty())
    }

    @Test
    fun getUserProjects_authenticatedOwner_returnsMatchingProjects() = runBlocking {
        val uid = signInTestUser(ALICE_EMAIL)
        val repository = StudioProjectRepository(firestore)
        val projectId = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.createProject(buildSampleProject(uid)).getOrThrow()
        }

        val projectsResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.getUserProjects()
        }
        assertTrue(projectsResult.isSuccess)
        assertTrue(projectsResult.getOrThrow().map { it.id }.contains(projectId))
    }

    @Test
    fun observeProjects_authenticatedOwner_emitsRealtimeUpdates() = runBlocking {
        val uid = signInTestUser(ALICE_EMAIL)
        val repository = StudioProjectRepository(firestore)
        val projectId = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.createProject(buildSampleProject(uid)).getOrThrow()
        }

        val emitted = withTimeout(FLOW_TIMEOUT_MS) {
            repository.observeProjects(uid).first { list -> list.any { it.id == projectId } }
        }
        assertTrue(emitted.map { it.id }.contains(projectId))
    }

    @Test
    fun getProjectById_crossUserAccess_failsWithPermissionDenied() = runBlocking {
        val aliceUid = signInTestUser(ALICE_EMAIL)
        val aliceRepo = StudioProjectRepository(firestore)
        val projectId = withTimeout(DEFAULT_TIMEOUT_MS) {
            aliceRepo.createProject(buildSampleProject(aliceUid)).getOrThrow()
        }

        signInTestUser(BOB_EMAIL)
        val bobRepo = StudioProjectRepository(firestore)
        val result = withTimeout(DEFAULT_TIMEOUT_MS) {
            bobRepo.getProjectById(projectId)
        }
        assertTrue(result.isFailure)
        val ex = result.exceptionOrNull()?.unwrapFirestoreException()
        assertNotNull(ex)
        assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, ex?.code)
    }

    @Test
    fun observeProjects_unauthenticatedUser_failsWithPermissionDenied() = runBlocking {
        auth.signOut()
        val repository = StudioProjectRepository(firestore)

        try {
            withTimeout(FLOW_TIMEOUT_MS) {
                repository.observeProjects("unauthenticated_uid").first()
            }
            fail("Expected exception for unauthenticated flow observation")
        } catch (e: Exception) {
            val firestoreException = checkNotNull(e.unwrapFirestoreException()) {
                "Expected nested FirebaseFirestoreException, got $e"
            }
            assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, firestoreException.code)
        }
    }

    private companion object {
        const val ALICE_EMAIL = "alice@test.com"
        const val BOB_EMAIL = "bob@test.com"
        const val DEFAULT_TIMEOUT_MS = 5000L
        const val FLOW_TIMEOUT_MS = 3000L
    }
}
