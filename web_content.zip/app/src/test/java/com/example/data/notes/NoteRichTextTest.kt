package com.example.data.notes

import com.example.data.model.NoteEntity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class NoteRichTextTest {

    @Test
    fun `test that a saved note reopens with its formatting intact`() {
        // 1. Build a comprehensive rich-text document covering all PRD 6.2 requirements:
        // - Font family: Handwriting
        // - Font size: 20sp
        // - Alignment: Center
        // - Headings (H1)
        // - Rich spans: Bold, Italic, Underline, Strikethrough, Text color, Highlight color
        // - Interactive Checklists (checked and unchecked)
        // - Bullet points
        val originalDocument = RichNoteDocument(
            fontFamily = NoteFontFamily.HANDWRITING.key,
            fontSize = 20,
            alignment = NoteAlignment.CENTER,
            blocks = listOf(
                LineBlock(
                    id = "b1",
                    text = "Biology Study Notes",
                    type = BlockType.HEADING_1,
                    spans = listOf(
                        RichSpan(
                            start = 0,
                            end = 7,
                            isBold = true,
                            textColorHex = "#DC2626"
                        )
                    )
                ),
                LineBlock(
                    id = "b2",
                    text = "Photosynthesis requires sunlight, water, and CO2.",
                    type = BlockType.PARAGRAPH,
                    spans = listOf(
                        RichSpan(
                            start = 0,
                            end = 14,
                            isItalic = true,
                            isUnderline = true,
                            highlightColorHex = "#FEF08A"
                        ),
                        RichSpan(
                            start = 34,
                            end = 39,
                            isStrikethrough = true
                        )
                    )
                ),
                LineBlock(
                    id = "b3",
                    text = "Review chloroplast diagram",
                    type = BlockType.CHECKLIST,
                    isChecked = true // Checked task
                ),
                LineBlock(
                    id = "b4",
                    text = "Solve chapter quiz questions",
                    type = BlockType.CHECKLIST,
                    isChecked = false // Pending task
                ),
                LineBlock(
                    id = "b5",
                    text = "Key formula: 6CO2 + 6H2O -> C6H12O6 + 6O2",
                    type = BlockType.BULLET
                )
            )
        )

        // 2. Serialize document to JSON (as stored in Room NoteEntity)
        val jsonPayload = originalDocument.toJson()
        assertNotNull(jsonPayload)
        assertTrue(jsonPayload.contains("handwriting"))
        assertTrue(jsonPayload.contains("Biology Study Notes"))

        // 3. Simulate saving to Room NoteEntity
        val noteEntity = NoteEntity(
            id = 42,
            title = "Biology Notes",
            contentJson = jsonPayload,
            plainTextPreview = originalDocument.toPreviewText(),
            subjectId = 1,
            isPinned = true,
            fontFamily = originalDocument.fontFamily,
            fontSize = originalDocument.fontSize,
            textAlign = originalDocument.alignment.key,
            createdAt = 1000L,
            updatedAt = 2000L
        )

        // 4. Reopen and deserialize note from Room entity (simulating note reopen)
        val reopenedDocument = RichNoteDocument.fromJson(noteEntity.contentJson)

        // 5. Verify every single formatting attribute is 100% intact:
        assertEquals("Font family must be restored intact", NoteFontFamily.HANDWRITING.key, reopenedDocument.fontFamily)
        assertEquals("Font size must be restored intact", 20, reopenedDocument.fontSize)
        assertEquals("Alignment must be restored intact", NoteAlignment.CENTER, reopenedDocument.alignment)
        assertEquals("Block count must be restored intact", 5, reopenedDocument.blocks.size)

        // Block 1 (Heading 1 + Bold + Text Color)
        val b1 = reopenedDocument.blocks[0]
        assertEquals("Biology Study Notes", b1.text)
        assertEquals(BlockType.HEADING_1, b1.type)
        assertEquals(1, b1.spans.size)
        assertTrue("Span must have bold enabled", b1.spans[0].isBold)
        assertEquals("#DC2626", b1.spans[0].textColorHex)

        // Block 2 (Paragraph + Italic + Underline + Highlight + Strikethrough)
        val b2 = reopenedDocument.blocks[1]
        assertEquals(BlockType.PARAGRAPH, b2.type)
        assertEquals(2, b2.spans.size)
        assertTrue("Span 1 must be italic", b2.spans[0].isItalic)
        assertTrue("Span 1 must be underlined", b2.spans[0].isUnderline)
        assertEquals("#FEF08A", b2.spans[0].highlightColorHex)
        assertTrue("Span 2 must be strikethrough", b2.spans[1].isStrikethrough)

        // Block 3 (Checklist Checked)
        val b3 = reopenedDocument.blocks[2]
        assertEquals(BlockType.CHECKLIST, b3.type)
        assertTrue("Checklist item 1 must remain checked", b3.isChecked)
        assertEquals("Review chloroplast diagram", b3.text)

        // Block 4 (Checklist Unchecked)
        val b4 = reopenedDocument.blocks[3]
        assertEquals(BlockType.CHECKLIST, b4.type)
        assertFalse("Checklist item 2 must remain unchecked", b4.isChecked)
        assertEquals("Solve chapter quiz questions", b4.text)

        // Block 5 (Bullet item)
        val b5 = reopenedDocument.blocks[4]
        assertEquals(BlockType.BULLET, b5.type)
        assertEquals("Key formula: 6CO2 + 6H2O -> C6H12O6 + 6O2", b5.text)
    }

    @Test
    fun `test undo and redo manager restores previous snapshots`() {
        val undoManager = UndoRedoManager(maxHistorySize = 10)
        val doc1 = RichNoteDocument(blocks = listOf(LineBlock(text = "Initial")))
        val doc2 = RichNoteDocument(blocks = listOf(LineBlock(text = "Typed something")))
        val doc3 = RichNoteDocument(blocks = listOf(LineBlock(text = "Typed something else")))

        undoManager.initialize("Title 1", doc1)
        assertFalse(undoManager.canUndo())
        assertFalse(undoManager.canRedo())

        undoManager.pushSnapshot("Title 1", doc2, force = true)
        assertTrue(undoManager.canUndo())
        assertFalse(undoManager.canRedo())

        undoManager.pushSnapshot("Title 2", doc3, force = true)
        assertTrue(undoManager.canUndo())

        // Undo to doc2
        val undoResult1 = undoManager.undo()
        assertNotNull(undoResult1)
        assertEquals("Title 1", undoResult1!!.first)
        assertEquals("Typed something", undoResult1.second.blocks[0].text)
        assertTrue(undoManager.canRedo())

        // Undo to doc1
        val undoResult2 = undoManager.undo()
        assertNotNull(undoResult2)
        assertEquals("Initial", undoResult2!!.second.blocks[0].text)
        assertFalse(undoManager.canUndo())

        // Redo to doc2
        val redoResult1 = undoManager.redo()
        assertNotNull(redoResult1)
        assertEquals("Typed something", redoResult1!!.second.blocks[0].text)

        // Redo to doc3
        val redoResult2 = undoManager.redo()
        assertNotNull(redoResult2)
        assertEquals("Title 2", redoResult2!!.first)
        assertEquals("Typed something else", redoResult2.second.blocks[0].text)
        assertFalse(undoManager.canRedo())
    }

    @Test
    fun `test font family and alignment mapping fallbacks`() {
        assertEquals(NoteFontFamily.SANS, NoteFontFamily.fromKey("unknown"))
        assertEquals(NoteFontFamily.HANDWRITING, NoteFontFamily.fromKey("handwriting"))
        assertEquals(NoteFontFamily.SERIF, NoteFontFamily.fromKey("serif"))
        assertEquals(NoteFontFamily.MONOSPACE, NoteFontFamily.fromKey("monospace"))

        assertEquals(NoteAlignment.LEFT, NoteAlignment.fromKey("invalid"))
        assertEquals(NoteAlignment.CENTER, NoteAlignment.fromKey("center"))
        assertEquals(NoteAlignment.RIGHT, NoteAlignment.fromKey("right"))
    }
}
