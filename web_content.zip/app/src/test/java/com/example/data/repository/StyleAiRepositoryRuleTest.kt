package com.example.data.repository

import com.example.base.FirestoreEmulatorTestBase
import com.google.firebase.firestore.FirebaseFirestoreException
import java.util.UUID
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class StyleAiRepositoryRuleTest : FirestoreEmulatorTestBase() {

    @Test
    fun createAndObserveProfile_authenticatedOwner_succeeds() = runBlocking {
        val uid = signInTestUser(ALICE_EMAIL)
        val repository = StyleAiRepository(firestore)

        val createRes = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.createOrInitializeProfile(
                displayName = "Aarav Style",
                userGender = "MALE",
                preferredLanguage = "Indian English"
            )
        }
        assertTrue("Profile creation should succeed", createRes.isSuccess)

        val genderLangRes = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.updateGenderAndLanguage(
                userGender = "FEMALE",
                preferredLanguage = "हिन्दी (Hindi)"
            )
        }
        assertTrue("Gender & language update should succeed", genderLangRes.isSuccess)

        val bodyMeasRes = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.updateBodyMeasurements(
                heightCm = 168,
                weightKg = 62,
                preferredTopSize = "M",
                preferredBottomSize = "30",
                bodyFitPreference = "Tailored Fit"
            )
        }
        assertTrue("Body measurements update should succeed", bodyMeasRes.isSuccess)

        val updateRes = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.updateStylingPreferences(
                preferredStyle = "Streetwear",
                preferredOccasion = "College",
                preferredColors = "Black, White, Olive",
                budgetMaxInr = 2500L,
                preferredRetailers = "Myntra, AJIO"
            )
        }
        assertTrue("Profile preference update should succeed", updateRes.isSuccess)

        val observed = withTimeout(FLOW_TIMEOUT_MS) {
            repository.observeUserProfile(uid).first { it != null && it.preferredStyle == "Streetwear" }
        }
        assertNotNull(observed)
        assertEquals("College", observed?.preferredOccasion)
        assertEquals("FEMALE", observed?.userGender)
        assertEquals(168L, observed?.heightCm)
        assertEquals(62L, observed?.weightKg)
        assertEquals("30", observed?.preferredBottomSize)
    }

    @Test
    fun saveAndObserveOutfits_authenticatedOwner_succeeds() = runBlocking {
        val uid = signInTestUser(ALICE_EMAIL)
        val repository = StyleAiRepository(firestore)
        val outfitKey = "outfit_${UUID.randomUUID().toString().take(8)}"

        val saveResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.saveOutfitToWardrobe(
                outfitId = outfitKey,
                title = "Monochrome Tailored Overshirt Combo",
                category = "Complete outfit combinations",
                occasion = "College",
                brand = "H&M Studio",
                color = "Obsidian Black",
                priceInr = 1899,
                imageUrl = "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f",
                productUrl = "https://www.myntra.com/shirts",
                retailer = "Myntra",
                stylistNote = "Clean monochrome layering ideal for college and casual evenings.",
                matchingShoes = "White Chunky Sole Sneakers",
                matchingAccessories = "Matte Black Minimalist Watch"
            )
        }
        assertTrue("Save outfit should succeed", saveResult.isSuccess)

        val list = withTimeout(FLOW_TIMEOUT_MS) {
            repository.observeSavedOutfits(uid).first { outfits -> outfits.any { it.id == outfitKey } }
        }
        assertTrue(list.any { it.id == outfitKey })
    }

    @Test
    fun addUpdateRemoveAndObserveWishlistItems_authenticatedOwner_succeeds() = runBlocking {
        val uid = signInTestUser(ALICE_EMAIL)
        val repository = StyleAiRepository(firestore)
        val productKey = "prod_${UUID.randomUUID().toString().take(8)}"

        val addRes = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.addItemToWishlist(
                productId = productKey,
                title = "Embroidered Silk Bandhgala",
                brand = "MANYAVAR",
                category = "Ethnic wear",
                occasion = "Wedding",
                selectedColor = "Obsidian Black",
                selectedSize = "M",
                priceInr = 3999,
                originalPriceInr = 5999,
                imageUrl = "https://images.unsplash.com/photo-1507679799987-c73779587ccf",
                productUrl = "https://www.myntra.com/ethnic",
                retailer = "Myntra",
                notes = "Saved to Wishlist for December wedding."
            )
        }
        assertTrue("Add to wishlist should succeed", addRes.isSuccess)
        val wishDocId = addRes.getOrThrow()

        val observedInitial = withTimeout(FLOW_TIMEOUT_MS) {
            repository.observeWishlistItems(uid).first { list -> list.any { it.id == wishDocId } }
        }
        assertTrue(observedInitial.any { it.id == wishDocId && it.selectedSize == "M" })

        val updateRes = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.updateWishlistItemVariant(
                itemId = wishDocId,
                selectedColor = "Emerald Green",
                selectedSize = "L",
                notes = "Updated to size L."
            )
        }
        assertTrue("Update wishlist item variant should succeed", updateRes.isSuccess)

        val observedUpdated = withTimeout(FLOW_TIMEOUT_MS) {
            repository.observeWishlistItems(uid).first { list ->
                list.any { it.id == wishDocId && it.selectedSize == "L" }
            }
        }
        assertEquals("Emerald Green", observedUpdated.first { it.id == wishDocId }.selectedColor)

        val removeRes = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.removeWishlistItem(wishDocId)
        }
        assertTrue("Remove wishlist item should succeed", removeRes.isSuccess)
    }

    @Test
    fun crossUserReadSavedOutfits_failsWithPermissionDenied() = runBlocking {
        val aliceUid = signInTestUser(ALICE_EMAIL)
        val aliceRepo = StyleAiRepository(firestore)
        val outfitKey = "outfit_${UUID.randomUUID().toString().take(8)}"

        withTimeout(DEFAULT_TIMEOUT_MS) {
            aliceRepo.saveOutfitToWardrobe(
                outfitId = outfitKey,
                title = "Alice Private Look",
                category = "Shirts",
                occasion = "Office",
                brand = "ZARA",
                color = "White",
                priceInr = 2499,
                imageUrl = "https://images.unsplash.com/photo-1598033129183-c4f50c736f10",
                productUrl = "https://www.ajio.com",
                retailer = "AJIO",
                stylistNote = "Crisp poplin weave.",
                matchingShoes = "Black Loafers",
                matchingAccessories = "Silver Cufflinks"
            ).getOrThrow()
        }

        signInTestUser(BOB_EMAIL)
        var caughtException: Exception? = null
        try {
            withTimeout(DEFAULT_TIMEOUT_MS) {
                firestore.collection("users").document(aliceUid)
                    .collection("saved_outfits").document(outfitKey)
                    .get().await()
            }
        } catch (e: Exception) {
            caughtException = e
        }
        val fsEx = caughtException?.unwrapFirestoreException()
        assertNotNull("Expected FirebaseFirestoreException for cross-user read", fsEx)
        assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, fsEx?.code)
    }

    @Test
    fun unauthenticatedObserveProfile_failsWithPermissionDenied() = runBlocking {
        val aliceUid = signInTestUser(ALICE_EMAIL)
        auth.signOut()
        val repository = StyleAiRepository(firestore)

        var caughtException: Throwable? = null
        try {
            withTimeout(FLOW_TIMEOUT_MS) {
                repository.observeUserProfile(aliceUid).first()
            }
        } catch (t: Throwable) {
            caughtException = t
        }
        val fsEx = caughtException?.unwrapFirestoreException()
        assertNotNull("Expected nested FirebaseFirestoreException on unauthenticated access", fsEx)
        assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, fsEx?.code)
    }

    private companion object {
        const val ALICE_EMAIL = "alice.styleai@test.com"
        const val BOB_EMAIL = "bob.styleai@test.com"
        const val DEFAULT_TIMEOUT_MS = 5000L
        const val FLOW_TIMEOUT_MS = 3000L
    }
}
