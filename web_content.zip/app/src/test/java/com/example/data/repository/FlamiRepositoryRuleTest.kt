package com.example.data.repository

import com.example.base.FirestoreEmulatorTestBase
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.util.UUID

class FlamiRepositoryRuleTest : FirestoreEmulatorTestBase() {

    @Test
    fun ensureUserProfile_createChat_addMessage_and_addMemory_succeedsForOwner() = runBlocking {
        signInTestUser("alice_${UUID.randomUUID()}@test.com")
        val repo = FlamiRepository(firestore, auth)

        val profileRes = withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.ensureUserProfile("Alice", "ru")
        }
        assertTrue(profileRes.isSuccess)
        assertEquals("ru", profileRes.getOrThrow().preferredLanguage)

        val chatRes = withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.createChat("Kotlin Architecture")
        }
        assertTrue(chatRes.isSuccess)
        val chatId = chatRes.getOrThrow()
        assertTrue(chatId.isNotBlank())

        val msgRes = withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.addMessage(
                chatId = chatId,
                role = "user",
                text = "Explain Coroutines Flow",
                hasImage = false,
                languageCode = "ru"
            )
        }
        assertTrue(msgRes.isSuccess)

        val msgs = withTimeout(FLOW_TIMEOUT_MS) {
            repo.observeMessages(chatId).first { it.isNotEmpty() }
        }
        assertEquals(1, msgs.size)
        assertEquals("Explain Coroutines Flow", msgs.first().text)

        val memRes = withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.addMemory("Building an Android Compose app", "project", chatId)
        }
        assertTrue(memRes.isSuccess)

        val memories = withTimeout(FLOW_TIMEOUT_MS) {
            repo.observeMemories().first { it.isNotEmpty() }
        }
        assertTrue(memories.any { it.fact == "Building an Android Compose app" })
    }

    @Test
    fun crossUserChatAccess_failsWithPermissionDenied() = runBlocking {
        val aliceEmail = "alice_cross_${UUID.randomUUID()}@test.com"
        val bobEmail = "bob_cross_${UUID.randomUUID()}@test.com"

        val aliceUid = signInTestUser(aliceEmail)
        val aliceRepo = FlamiRepository(firestore, auth)
        withTimeout(DEFAULT_TIMEOUT_MS) { aliceRepo.ensureUserProfile("Alice") }
        val chatId = withTimeout(DEFAULT_TIMEOUT_MS) { aliceRepo.createChat("Private Notes").getOrThrow() }

        signInTestUser(bobEmail)
        // Attempt direct read of Alice's chat as Bob
        try {
            withTimeout(DEFAULT_TIMEOUT_MS) {
                firestore.collection("users").document(aliceUid)
                    .collection("chats").document(chatId)
                    .get()
                    .await()
            }
            fail("Expected PERMISSION_DENIED for cross-user read")
        } catch (e: Exception) {
            val ffe = e.unwrapFirestoreException()
            assertNotNull("Expected FirebaseFirestoreException, got $e", ffe)
            assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, ffe!!.code)
        }
    }

    @Test
    fun observeChats_unauthenticatedUser_failsCleanly() = runBlocking {
        auth.signOut()
        val repo = FlamiRepository(firestore, auth)

        try {
            withTimeout(FLOW_TIMEOUT_MS) {
                repo.observeChats().first()
            }
            fail("Expected IllegalStateException or PERMISSION_DENIED when unauthenticated")
        } catch (e: Exception) {
            assertTrue(e is IllegalStateException || e.unwrapFirestoreException() != null)
        }
    }

    @Test
    fun unauthenticatedDirectCollectionQuery_failsWithPermissionDenied() = runBlocking {
        auth.signOut()
        try {
            withTimeout(DEFAULT_TIMEOUT_MS) {
                firestore.collection("users").document("someone").collection("chats").get().await()
            }
            fail("Expected PERMISSION_DENIED when unauthenticated")
        } catch (e: Exception) {
            val ffe = e.unwrapFirestoreException()
            assertNotNull("Expected FirebaseFirestoreException, got $e", ffe)
            assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, ffe!!.code)
        }
    }

    private companion object {
        const val DEFAULT_TIMEOUT_MS = 5000L
        const val FLOW_TIMEOUT_MS = 3000L
    }
}
