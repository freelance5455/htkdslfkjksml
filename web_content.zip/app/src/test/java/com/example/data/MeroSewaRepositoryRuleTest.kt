package com.example.data

import com.example.base.FirestoreEmulatorTestBase
import com.example.model.Booking
import com.example.model.Provider
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class MeroSewaRepositoryRuleTest : FirestoreEmulatorTestBase() {

    @Test
    fun createBooking_authenticatedCustomer_createsBooking() = runBlocking {
        val uid = signInTestUser(ALICE_EMAIL)
        val bookingRepo = BookingRepository(firestore)

        val booking = Booking(
            customerUid = uid,
            customerName = "Alice Shrestha",
            customerPhone = "9841234567",
            providerId = "provider_101",
            providerName = "Ram Sharma",
            category = "electrician",
            city = "Tulsipur",
            address = "Line-mini chowk",
            description = "Main board MCB trip repair",
            preferredDate = "2026-10-25",
            preferredTime = "Morning",
            status = "pending"
        )

        val result = withTimeout(DEFAULT_TIMEOUT_MS) {
            bookingRepo.createBooking(booking)
        }
        assertTrue("Booking creation should succeed", result.isSuccess)
        val bookingId = result.getOrThrow()
        assertNotNull(bookingId)
    }

    @Test
    fun submitBookingForm_capturesLocationAddressDescriptionTime_savesToFirestore() = runBlocking {
        val uid = signInTestUser(BOB_EMAIL)
        val bookingRepo = BookingRepository(firestore)

        // Booking form payload: location (city), address, work description, preferred time
        val formBooking = Booking(
            customerUid = uid,
            customerName = "Bob Chaudhary",
            customerPhone = "9809811223",
            providerId = "any_verified_provider",
            providerName = "प्रमाणित स्थानीय प्राविधिक",
            category = "plumber",
            city = "Ghorahi",
            address = "घोराही वडा १५, ट्राफिक चोक नजिक",
            description = "बाथरुमको तातोपानीको पाइप फुट्यो, तत्काल मर्मत आवश्यक",
            preferredDate = "आजै (Today)",
            preferredTime = "तत्काल आवश्यक (Urgent)",
            status = "pending"
        )

        val result = withTimeout(DEFAULT_TIMEOUT_MS) {
            bookingRepo.createBooking(formBooking)
        }
        assertTrue("Form submission should succeed", result.isSuccess)
        val savedId = result.getOrThrow()

        // Fetch back and assert stored fields
        val savedBookings = withTimeout(FLOW_TIMEOUT_MS) {
            bookingRepo.observeCustomerBookings(uid).first { it.any { b -> b.id == savedId } }
        }
        val retrieved = savedBookings.first { it.id == savedId }
        assertEquals("Ghorahi", retrieved.city)
        assertEquals("घोराही वडा १५, ट्राफिक चोक नजिक", retrieved.address)
        assertEquals("बाथरुमको तातोपानीको पाइप फुट्यो, तत्काल मर्मत आवश्यक", retrieved.description)
        assertEquals("तत्काल आवश्यक (Urgent)", retrieved.preferredTime)
        assertEquals("pending", retrieved.status)
        assertEquals(uid, retrieved.customerUid)
    }

    @Test
    fun observeCustomerBookings_authenticatedOwner_returnsOwnBookings() = runBlocking {
        val uid = signInTestUser(ALICE_EMAIL)
        val bookingRepo = BookingRepository(firestore)

        val booking = Booking(
            customerUid = uid,
            customerName = "Alice Shrestha",
            customerPhone = "9841234567",
            providerId = "provider_102",
            providerName = "Suresh Plumber",
            category = "plumber",
            city = "Tulsipur",
            address = "Ward 4",
            description = "Pipe leakage fixing",
            preferredDate = "Today",
            preferredTime = "Now",
            status = "pending"
        )

        val createResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            bookingRepo.createBooking(booking)
        }
        assertTrue(createResult.isSuccess)
        val bookingId = createResult.getOrThrow()

        val list = withTimeout(FLOW_TIMEOUT_MS) {
            bookingRepo.observeCustomerBookings(uid).first { it.any { b -> b.id == bookingId } }
        }
        assertTrue(list.any { it.id == bookingId })
    }

    @Test
    fun observeActiveProviders_unauthenticated_readsActiveProviders() = runBlocking {
        auth.signOut()
        val providerRepo = ProviderRepository(firestore)

        // Seed provider as admin first
        signInTestUser(ADMIN_EMAIL)
        val adminRepo = ProviderRepository(firestore)
        val createResult = adminRepo.createProvider(
            Provider(
                name = "Test Provider",
                category = "electrician",
                city = "Tulsipur",
                description = "Experienced electrician",
                phone = "9847111222",
                phonePublic = true,
                active = true,
                rating = 4.8,
                experienceYears = 5
            )
        )
        assertTrue(createResult.isSuccess)

        // Now test as unauthenticated user
        auth.signOut()
        val providers = withTimeout(FLOW_TIMEOUT_MS) {
            providerRepo.observeActiveProviders().first()
        }
        assertTrue(providers.isNotEmpty())
    }

    private companion object {
        const val ALICE_EMAIL = "alice@example.com"
        const val BOB_EMAIL = "bob@example.com"
        const val ADMIN_EMAIL = "bhandaribimal778@gmail.com"
        const val DEFAULT_TIMEOUT_MS = 5000L
        const val FLOW_TIMEOUT_MS = 5000L
    }
}
