package com.example.data.exam

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

class ExamDateHelperTest {

    @Test
    fun `test exam days left on the exact exam day shows Today`() {
        val today = LocalDate.of(2026, 11, 13)
        val examDate = LocalDate.of(2026, 11, 13)

        val daysLeft = ExamDateHelper.calculateDaysLeft(examDate, today)
        assertEquals(0L, daysLeft)

        val formatted = ExamDateHelper.formatDaysLeft(daysLeft)
        assertEquals("Today", formatted)

        // Today is NOT past yet (exam day is today)
        assertFalse(ExamDateHelper.isExamPast(examDate, today))
    }

    @Test
    fun `test exam days left for future exams`() {
        val today = LocalDate.of(2026, 11, 13)

        // Tomorrow (1 day left)
        val tomorrow = LocalDate.of(2026, 11, 14)
        assertEquals(1L, ExamDateHelper.calculateDaysLeft(tomorrow, today))
        assertEquals("1 day left", ExamDateHelper.formatDaysLeft(1L))

        // 42 days left (as described in PRD section 5.5)
        val examIn42Days = today.plusDays(42)
        val days42 = ExamDateHelper.calculateDaysLeft(examIn42Days, today)
        assertEquals(42L, days42)
        assertEquals("42 days left", ExamDateHelper.formatDaysLeft(days42))
        assertFalse(ExamDateHelper.isExamPast(examIn42Days, today))
    }

    @Test
    fun `test past exams move to archive list`() {
        val today = LocalDate.of(2026, 11, 13)

        // Yesterday's exam
        val yesterday = LocalDate.of(2026, 11, 12)
        val daysPast = ExamDateHelper.calculateDaysLeft(yesterday, today)
        assertEquals(-1L, daysPast)
        assertTrue("Yesterday's exam should be marked past/archived", ExamDateHelper.isExamPast(yesterday, today))

        // 10 days ago
        val pastExam = today.minusDays(10)
        assertTrue(ExamDateHelper.isExamPast(pastExam, today))
    }

    @Test
    fun `test reminders triggered at 30, 7, and 1 days before exam`() {
        val examDate = LocalDate.of(2026, 12, 13)

        // Exactly 30 days before
        val date30DaysBefore = examDate.minusDays(30)
        val reminders30 = ExamDateHelper.getEligibleReminders(
            examDate = examDate,
            today = date30DaysBefore,
            remind30 = true,
            remind7 = true,
            remind1 = true
        )
        assertEquals(listOf(30), reminders30)

        // Exactly 7 days before
        val date7DaysBefore = examDate.minusDays(7)
        val reminders7 = ExamDateHelper.getEligibleReminders(
            examDate = examDate,
            today = date7DaysBefore,
            remind30 = true,
            remind7 = true,
            remind1 = true
        )
        assertEquals(listOf(7), reminders7)

        // Exactly 1 day before
        val date1DayBefore = examDate.minusDays(1)
        val reminders1 = ExamDateHelper.getEligibleReminders(
            examDate = examDate,
            today = date1DayBefore,
            remind30 = true,
            remind7 = true,
            remind1 = true
        )
        assertEquals(listOf(1), reminders1)

        // Reminder disabled by user
        val remindersDisabled = ExamDateHelper.getEligibleReminders(
            examDate = examDate,
            today = date1DayBefore,
            remind30 = true,
            remind7 = true,
            remind1 = false
        )
        assertTrue(remindersDisabled.isEmpty())
    }
}
