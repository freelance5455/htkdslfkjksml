package com.example.data.backup

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.database.AppDatabase
import com.example.data.model.AppSettingsEntity
import com.example.data.model.ExamEntity
import com.example.data.model.NoteEntity
import com.example.data.model.ProfileEntity
import com.example.data.model.StudySessionEntity
import com.example.data.model.SubjectEntity
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class BackupRestoreTest {

    private lateinit var database: AppDatabase
    private lateinit var backupManager: BackupManager

    @Before
    fun setup() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        database = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        backupManager = BackupManager(database)
    }

    @After
    fun tearDown() {
        database.close()
    }

    @Test
    fun testExportFollowedByImportRestoresIdenticalData() = runBlocking {
        // 1. Seed comprehensive test data across all tables
        val subject1 = SubjectEntity(
            id = 101L,
            name = "Advanced Mathematics",
            colorHex = "#2563EB",
            iconName = "calculate",
            weeklyTargetHours = 8.5f,
            isArchived = false,
            createdAt = 1700000000000L
        )
        val subject2 = SubjectEntity(
            id = 102L,
            name = "Organic Chemistry",
            colorHex = "#16A34A",
            iconName = "science",
            weeklyTargetHours = 6.0f,
            isArchived = true,
            createdAt = 1700001000000L
        )
        database.subjectDao().insertAll(listOf(subject1, subject2))

        val session1 = StudySessionEntity(
            id = 201L,
            subjectId = 101L,
            date = "2026-11-10",
            startTime = "09:30",
            durationMinutes = 90,
            topic = "Linear Algebra & Matrices",
            remark = "Completed all chapter review problems",
            createdAt = 1700002000000L
        )
        val session2 = StudySessionEntity(
            id = 202L,
            subjectId = 102L,
            date = "2026-11-11",
            startTime = "14:15",
            durationMinutes = 45,
            topic = "Stereochemistry Mechanisms",
            remark = null,
            createdAt = 1700003000000L
        )
        database.studySessionDao().insertAll(listOf(session1, session2))

        val exam1 = ExamEntity(
            id = 301L,
            name = "Math Midterm Exam",
            date = "2026-12-01",
            subjectId = 101L,
            remind30Days = true,
            remind7Days = true,
            remind1Day = true,
            isArchived = false,
            createdAt = 1700004000000L
        )
        database.examDao().insertAll(listOf(exam1))

        val note1 = NoteEntity(
            id = 401L,
            title = "Calculus Integration Formulas",
            contentJson = "{\"blocks\":[{\"id\":\"b1\",\"type\":\"heading1\",\"text\":\"Integration Rules\"}]}",
            plainTextPreview = "Integration Rules",
            subjectId = 101L,
            isPinned = true,
            fontFamily = "serif",
            fontSize = 18,
            textAlign = "left",
            createdAt = 1700005000000L,
            updatedAt = 1700006000000L
        )
        database.noteDao().insertAll(listOf(note1))

        val profile = ProfileEntity(
            id = 1,
            name = "Alex Johnson",
            photoUri = null,
            instituteName = "Tech Academy"
        )
        database.profileDao().insertOrUpdate(profile)

        val settings = AppSettingsEntity(
            id = 1,
            themeMode = AppSettingsEntity.THEME_BOOK
        )
        database.appSettingsDao().insertOrUpdate(settings)

        // 2. Perform Export
        val exportedJson = backupManager.generateBackupJson()
        assertNotNull("Exported JSON should not be null", exportedJson)
        assertTrue("JSON should contain app title", exportedJson.contains("Daily Study Manager"))
        assertTrue("JSON should contain subject name", exportedJson.contains("Advanced Mathematics"))
        assertTrue("JSON should contain session topic", exportedJson.contains("Linear Algebra"))
        assertTrue("JSON should contain exam name", exportedJson.contains("Math Midterm Exam"))
        assertTrue("JSON should contain note title", exportedJson.contains("Calculus Integration Formulas"))
        assertTrue("JSON should contain profile name", exportedJson.contains("Alex Johnson"))
        assertTrue("JSON should contain theme", exportedJson.contains("BOOK"))

        // 3. Clear or overwrite the database with different data to simulate a fresh/dirty state
        database.studySessionDao().deleteAll()
        database.examDao().deleteAll()
        database.noteDao().deleteAll()
        database.subjectDao().deleteAll()
        database.profileDao().deleteAll()
        database.appSettingsDao().deleteAll()

        assertEquals("Database should have 0 subjects", 0, database.subjectDao().getAllSubjectsOnce().size)
        assertEquals("Database should have 0 sessions", 0, database.studySessionDao().getAllSessionsOnce().size)

        // 4. Perform Restore from the exported JSON
        val restoreResult = backupManager.restoreFromJson(exportedJson)
        assertTrue("Restore must succeed", restoreResult is RestoreResult.Success)

        val summary = (restoreResult as RestoreResult.Success).summary
        assertEquals("Restored 2 subjects", 2, summary.subjectCount)
        assertEquals("Restored 2 sessions", 2, summary.sessionCount)
        assertEquals("Restored 1 exam", 1, summary.examCount)
        assertEquals("Restored 1 note", 1, summary.noteCount)
        assertTrue("Profile restored", summary.profileRestored)
        assertTrue("Settings restored", summary.settingsRestored)

        // 5. Verify restored data is 100% IDENTICAL to original
        val restoredSubjects = database.subjectDao().getAllSubjectsOnce()
        assertEquals(2, restoredSubjects.size)
        assertEquals(subject1.id, restoredSubjects[0].id)
        assertEquals(subject1.name, restoredSubjects[0].name)
        assertEquals(subject1.colorHex, restoredSubjects[0].colorHex)
        assertEquals(subject1.weeklyTargetHours, restoredSubjects[0].weeklyTargetHours)
        assertEquals(subject1.isArchived, restoredSubjects[0].isArchived)

        assertEquals(subject2.id, restoredSubjects[1].id)
        assertEquals(subject2.name, restoredSubjects[1].name)
        assertEquals(subject2.isArchived, restoredSubjects[1].isArchived)

        val restoredSessions = database.studySessionDao().getAllSessionsOnce()
        assertEquals(2, restoredSessions.size)
        assertEquals(session1.id, restoredSessions[0].id)
        assertEquals(session1.subjectId, restoredSessions[0].subjectId)
        assertEquals(session1.date, restoredSessions[0].date)
        assertEquals(session1.startTime, restoredSessions[0].startTime)
        assertEquals(session1.durationMinutes, restoredSessions[0].durationMinutes)
        assertEquals(session1.topic, restoredSessions[0].topic)
        assertEquals(session1.remark, restoredSessions[0].remark)

        val restoredExams = database.examDao().getAllExamsOnce()
        assertEquals(1, restoredExams.size)
        assertEquals(exam1.id, restoredExams[0].id)
        assertEquals(exam1.name, restoredExams[0].name)
        assertEquals(exam1.date, restoredExams[0].date)
        assertEquals(exam1.subjectId, restoredExams[0].subjectId)
        assertEquals(exam1.remind7Days, restoredExams[0].remind7Days)

        val restoredNotes = database.noteDao().getAllNotesOnce()
        assertEquals(1, restoredNotes.size)
        assertEquals(note1.id, restoredNotes[0].id)
        assertEquals(note1.title, restoredNotes[0].title)
        assertEquals(note1.contentJson, restoredNotes[0].contentJson)
        assertEquals(note1.isPinned, restoredNotes[0].isPinned)
        assertEquals(note1.fontFamily, restoredNotes[0].fontFamily)
        assertEquals(note1.fontSize, restoredNotes[0].fontSize)

        val restoredProfile = database.profileDao().getProfile()
        assertNotNull(restoredProfile)
        assertEquals(profile.name, restoredProfile?.name)
        assertEquals(profile.instituteName, restoredProfile?.instituteName)

        val restoredSettings = database.appSettingsDao().getSettings()
        assertNotNull(restoredSettings)
        assertEquals(AppSettingsEntity.THEME_BOOK, restoredSettings?.themeMode)
    }
}
