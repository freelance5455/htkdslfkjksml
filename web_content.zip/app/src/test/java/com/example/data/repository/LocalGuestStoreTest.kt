package com.example.data.repository

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class LocalGuestStoreTest {

    @Test
    fun `guest store persists chats messages and memories across instances`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        File(context.filesDir, "flami_guest_store.json").delete()

        val store1 = LocalGuestStore(context)
        store1.ensureUserProfile("Guest", "ru")

        val chatId = store1.createChat("Test Direct Chat").getOrThrow()
        store1.addMessage(chatId = chatId, role = "user", text = "Привет, FLAMI!")
        store1.addMessage(chatId = chatId, role = "model", text = "Привет! Чем помочь?")
        store1.addMemory("Uses Jetpack Compose", "preference", chatId)

        // Create a second instance reading from disk to verify persistence across restarts
        val store2 = LocalGuestStore(context)
        val chats = store2.observeChats().first()
        assertEquals(1, chats.size)
        assertEquals("Test Direct Chat", chats.first().title)

        val messages = store2.observeMessages(chatId).first()
        assertEquals(2, messages.size)
        assertEquals("Привет, FLAMI!", messages[0].text)

        val memories = store2.observeMemories().first()
        assertEquals(1, memories.size)
        assertEquals("Uses Jetpack Compose", memories.first().fact)

        val searchHits = store2.searchMessages("FLAMI", chats).getOrThrow()
        assertTrue(searchHits.isNotEmpty())
    }
}
