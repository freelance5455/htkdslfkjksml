package com.example.core

import com.example.data.model.ChatMessage
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.zip.ZipInputStream

class DocumentExportManagerTest {

    @Test
    fun extractCodeBlocks_parsesHtmlCssJsFences() {
        val markdown = """
            Here is your site:
            ```html
            <!DOCTYPE html><html><body><h1>FLAMI</h1></body></html>
            ```
            ```css
            body { color: #fff; }
            ```
            ```js
            console.log("hi");
            ```
        """.trimIndent()

        val blocks = DocumentExportManager.extractCodeBlocks(markdown)
        assertEquals(3, blocks.size)
        assertEquals("html", blocks[0].language)
        assertEquals("css", blocks[1].language)
        assertEquals("js", blocks[2].language)
    }

    @Test
    fun buildStandaloneHtml_containsTitleAndMessages() {
        val html = DocumentExportManager.buildStandaloneHtml(
            title = "Math Session",
            messages = listOf(
                ChatMessage(id = "1", role = "user", text = "Solve x^2 = 9"),
                ChatMessage(id = "2", role = "model", text = "x = 3 or x = -3")
            )
        )
        assertTrue(html.contains("<!DOCTYPE html>"))
        assertTrue(html.contains("Math Session"))
        assertTrue(html.contains("x = 3 or x = -3"))
    }

    @Test
    fun localization_resolvesMultipleLanguages() {
        assertEquals("Новый чат", FlamiL10n.strings("ru").newChat)
        assertEquals("New Chat", FlamiL10n.strings("en").newChat)
        assertEquals("Nuevo chat", FlamiL10n.strings("es").newChat)
    }

    @Test
    fun writeZipWithRootIndexHtml_placesIndexHtmlAtRoot() {
        val markdown = """
            ```html
            <!DOCTYPE html><html><body>Hello ZIP</body></html>
            ```
            ```css
            body { margin: 0; }
            ```
            ```js
            console.log('ready');
            ```
        """.trimIndent()
        val baos = ByteArrayOutputStream()
        DocumentExportManager.writeZipWithRootIndexHtml(
            outputStream = baos,
            title = "Web Demo",
            messages = listOf(ChatMessage(id = "1", role = "model", text = markdown))
        )
        val entries = mutableListOf<String>()
        ZipInputStream(ByteArrayInputStream(baos.toByteArray())).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                entries.add(entry.name)
                entry = zis.nextEntry
            }
        }
        assertTrue(entries.contains("index.html"))
        assertTrue(entries.contains("styles.css"))
        assertTrue(entries.contains("script.js"))
        assertTrue(entries.contains("conversation.md"))
    }
}
