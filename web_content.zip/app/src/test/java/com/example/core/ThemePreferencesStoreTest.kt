package com.example.core

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ThemePreferencesStoreTest {

    @Test
    fun `design system and classic mode round-trip storage keys`() {
        assertEquals(DesignSystem.ANIME_WORLD, DesignSystem.fromKey("anime_world"))
        assertEquals(DesignSystem.FLAMI_ORIGINAL, DesignSystem.fromKey("flami_original"))
        assertEquals(DesignSystem.CLASSIC_AI, DesignSystem.fromKey("classic_ai"))
        assertEquals(DesignSystem.FLAMI_ORIGINAL, DesignSystem.fromKey(null))
        assertEquals(DesignSystem.FLAMI_ORIGINAL, DesignSystem.fromKey("unknown"))

        assertEquals(ClassicThemeMode.SYSTEM, ClassicThemeMode.fromKey("system"))
        assertEquals(ClassicThemeMode.LIGHT, ClassicThemeMode.fromKey("light"))
        assertEquals(ClassicThemeMode.DARK, ClassicThemeMode.fromKey("dark"))
        assertEquals(ClassicThemeMode.DARK, ClassicThemeMode.fromKey(null))
    }

    @Test
    fun `datastore persists design system anime wallpaper and classic mode`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val store = ThemePreferencesStore(context)

        store.setDesignSystem(DesignSystem.ANIME_WORLD)
        store.setAnimeBackgroundIndex(2)
        store.setClassicThemeMode(ClassicThemeMode.LIGHT)

        val saved = store.appearanceFlow.first()
        assertEquals(DesignSystem.ANIME_WORLD, saved.designSystem)
        assertEquals(2, saved.animeBgIndex)
        assertEquals(ClassicThemeMode.LIGHT, saved.classicThemeMode)

        store.setDesignSystem(DesignSystem.CLASSIC_AI)
        val updated = store.appearanceFlow.first()
        assertEquals(DesignSystem.CLASSIC_AI, updated.designSystem)
    }

    @Test
    fun `localization includes appearance and voice strings for all languages`() {
        listOf("ru", "en", "es", "de", "fr", "uk", "zh").forEach { code ->
            val s = FlamiL10n.strings(code)
            assertTrue(s.appearanceTitle.isNotBlank())
            assertTrue(s.animeThemeTitle.isNotBlank())
            assertTrue(s.flamiOriginalTitle.isNotBlank())
            assertTrue(s.classicAiTitle.isNotBlank())
            assertTrue(s.voiceAssistantTitle.isNotBlank())
            assertTrue(s.cameraPhotoAction.isNotBlank())
        }
    }
}
