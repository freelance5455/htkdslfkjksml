package com.example

import com.example.model.TargetTrigger
import com.example.model.TriggerType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TargetTriggerTest {

    @Test
    fun defaultTriggers_hasRedGreenYellowEnabled() {
        val triggers = TargetTrigger.createDefaultTriggers()
        val red = triggers.first { it.type == TriggerType.RED }
        val green = triggers.first { it.type == TriggerType.GREEN }
        val yellow = triggers.first { it.type == TriggerType.YELLOW }

        assertTrue("Red trigger should be enabled by default", red.isEnabled)
        assertTrue("Green trigger should be enabled by default", green.isEnabled)
        assertTrue("Yellow trigger should be enabled by default", yellow.isEnabled)
    }

    @Test
    fun redTrigger_matchesRedHueRanges() {
        val red = TargetTrigger.createDefaultTriggers().first { it.type == TriggerType.RED }

        // Hue 5 degrees, high saturation, good brightness
        assertTrue(red.matches(floatArrayOf(5f, 0.8f, 0.9f)))

        // Hue 355 degrees (wrap-around)
        assertTrue(red.matches(floatArrayOf(355f, 0.85f, 0.85f)))

        // Non-red (e.g. blue Hue 210)
        assertFalse(red.matches(floatArrayOf(210f, 0.8f, 0.9f)))

        // Very desaturated (grayish)
        assertFalse(red.matches(floatArrayOf(5f, 0.1f, 0.9f)))
    }

    @Test
    fun greenTrigger_matchesGreenHueRange() {
        val green = TargetTrigger.createDefaultTriggers().first { it.type == TriggerType.GREEN }

        // Hue 120 (pure green)
        assertTrue(green.matches(floatArrayOf(120f, 0.8f, 0.8f)))

        // Hue 90 (yellowish-green)
        assertTrue(green.matches(floatArrayOf(90f, 0.6f, 0.7f)))

        // Non-green (e.g. red)
        assertFalse(green.matches(floatArrayOf(0f, 0.8f, 0.8f)))
    }

    @Test
    fun yellowTrigger_matchesYellowHueRange() {
        val yellow = TargetTrigger.createDefaultTriggers().first { it.type == TriggerType.YELLOW }

        // Hue 55 (pure yellow)
        assertTrue(yellow.matches(floatArrayOf(55f, 0.85f, 0.9f)))

        // Non-yellow
        assertFalse(yellow.matches(floatArrayOf(180f, 0.8f, 0.8f)))
    }
}
