package com.example

import com.example.converter.ConverterCategory
import com.example.converter.UnitConverter
import com.example.data.local.CalculationHistoryEntity
import com.example.data.preferences.PreferencesDataSource
import com.example.data.preferences.UserPreferences
import com.example.data.repository.HistoryDataSource
import com.example.engine.AngleMode
import com.example.engine.CalcError
import com.example.engine.CalculationEngine
import com.example.engine.EvalResult
import com.example.engine.FormattingOptions
import com.example.engine.NumberFormatter
import com.example.engine.NumberGroupingStyle
import com.example.tools.CompoundingFrequency
import com.example.tools.FractionOp
import com.example.tools.MotionTarget
import com.example.tools.SimpleDate
import com.example.tools.ToolsEngine
import com.example.ui.calculator.CalculatorViewModel
import com.example.ui.converter.ConverterViewModel
import com.example.ui.theme.AppThemeMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import java.math.BigDecimal
import java.math.BigInteger
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

@OptIn(ExperimentalCoroutinesApi::class)
class AdversarialAuditTest {

  private val testDispatcher = StandardTestDispatcher()

  @Before
  fun setup() {
    Dispatchers.setMain(testDispatcher)
  }

  @After
  fun tearDown() {
    Dispatchers.resetMain()
  }

  private fun evalOk(
    expr: String,
    angleMode: AngleMode = AngleMode.DEG,
    formatting: FormattingOptions = FormattingOptions(),
  ): EvalResult.Success {
    val res = CalculationEngine.evaluate(expr, angleMode, formatting)
    assertTrue("Expected Success for '$expr' ($angleMode), got $res", res is EvalResult.Success)
    return res as EvalResult.Success
  }

  private fun evalErr(
    expr: String,
    expected: CalcError,
    angleMode: AngleMode = AngleMode.DEG,
  ) {
    val res = CalculationEngine.evaluate(expr, angleMode)
    assertTrue("Expected Error($expected) for '$expr', got $res", res is EvalResult.Error)
    assertEquals("Wrong error for '$expr'", expected, (res as EvalResult.Error).error)
  }

  // --- 1. Precision Attack: 50, 100, 120+ digits, vastly different magnitudes, raw reuse ---
  @Test
  fun `precision attack large integers vastly different magnitudes and raw reuse`() {
    // 50-digit and 100-digit exact integer addition/subtraction & reuse
    val int50 = "1234567890".repeat(5) // 50 digits
    val res50 = evalOk("$int50+7")
    val expected50 = BigDecimal(int50).add(BigDecimal(7))
    assertEquals(0, expected50.compareTo(res50.value))

    // Reusing rawNumericString of a 50-digit integer must NOT truncate at 34 digits!
    val reused50 = evalOk("${res50.rawNumericString}−$int50")
    assertEquals("7", reused50.formatted)

    // 100-digit exact integer arithmetic
    val int100 = "9876543210".repeat(10)
    val res100 = evalOk("$int100+42")
    assertEquals(0, BigDecimal(int100).add(BigDecimal(42)).compareTo(res100.value))
    val reused100 = evalOk("${res100.rawNumericString}−$int100")
    assertEquals("42", reused100.formatted)

    // 120-digit + 120-digit
    val int120 = "9".repeat(120)
    val res120 = evalOk("$int120+1")
    assertEquals(0, BigDecimal("1" + "0".repeat(120)).compareTo(res120.value))

    // Vastly different magnitudes: 10^130 + 1 - 10^130 == 1
    val catCancel = evalOk("1e130+1−1e130")
    assertEquals(0, BigDecimal.ONE.compareTo(catCancel.value))

    // 50-digit percentage must preserve precision
    val bigPctBase = "1" + "0".repeat(49) // 10^49 (50 digits)
    val bigPct = evalOk("$bigPctBase+10%")
    assertEquals(0, BigDecimal("11" + "0".repeat(48)).compareTo(bigPct.value))
  }

  // --- 2. Near-zero & Scientific Function Attack ---
  @Test
  fun `near zero values in trig inverse trig hyperbolic and huge or tiny logs and roots`() {
    // Near-zero 1e-13 must NOT be wiped to zero in RAD or inverse trig or hyperbolic
    val sinTinyRad = evalOk("sin(1e-13)", AngleMode.RAD)
    assertTrue("sin(1e-13) RAD must not be 0, got ${sinTinyRad.value}", sinTinyRad.value > BigDecimal("9e-14"))

    val asinTinyRad = evalOk("asin(1e-13)", AngleMode.RAD)
    assertTrue("asin(1e-13) RAD must not be 0, got ${asinTinyRad.value}", asinTinyRad.value > BigDecimal("9e-14"))

    val atanTinyRad = evalOk("atan(1e-13)", AngleMode.RAD)
    assertTrue("atan(1e-13) RAD must not be 0, got ${atanTinyRad.value}", atanTinyRad.value > BigDecimal("9e-14"))

    val sinhTiny = evalOk("sinh(1e-13)")
    assertTrue("sinh(1e-13) must not be 0, got ${sinhTiny.value}", sinhTiny.value > BigDecimal("9e-14"))

    val tanhTiny = evalOk("tanh(1e-13)")
    assertTrue("tanh(1e-13) must not be 0, got ${tanhTiny.value}", tanhTiny.value > BigDecimal("9e-14"))

    // Exact DEG multiples remain exact even for huge multiples like 360000000000000030
    assertEquals("0.5", evalOk("sin(360000000000000030)", AngleMode.DEG).formatted)
    assertEquals("0", evalOk("sin(180000000000000000)", AngleMode.DEG).formatted)
    assertEquals("0", evalOk("cos(900000000000000090)", AngleMode.DEG).formatted)
    evalErr("tan(900000000000000090)", CalcError.DOMAIN_ERROR, AngleMode.DEG)

    // Beyond Double.MAX_VALUE (~1e308) and below Double.MIN_VALUE (~1e-324):
    // log(10^400) == 400
    assertEquals("400", evalOk("log(10^400)").formatted)
    // log(10^-400) == -400 (must NOT be DOMAIN_ERROR!)
    assertEquals("−400", evalOk("log(10^(−400))").formatted)
    // ln(10^400) == 400 * ln(10)
    val ln400 = evalOk("ln(10^400)").value.toDouble()
    assertEquals(400.0 * ln(10.0), ln400, 1e-8)
    // ln(10^-400) == -400 * ln(10)
    val lnNeg400 = evalOk("ln(10^(−400))").value.toDouble()
    assertEquals(-400.0 * ln(10.0), lnNeg400, 1e-8)
    // logBase(2, 2^1500) == 1500
    assertEquals("1,500", evalOk("logBase(2,2^1500)").formatted)
    // sqrt(10^400) == 10^200
    assertEquals(0, BigDecimal("1e200").compareTo(evalOk("√(10^400)").value))
    // sqrt(10^-400) == 10^-200
    assertEquals(0, BigDecimal("1e-200").compareTo(evalOk("√(10^(−400))").value))
    // cbrt(10^600) == 10^200
    assertEquals(0, BigDecimal("1e200").compareTo(evalOk("∛(10^600)").value))
    // tanh(10^400) == 1
    assertEquals("1", evalOk("tanh(10^400)").formatted)
  }

  // --- 3. Formatter Fixed-Precision Negative Zero Attack ---
  @Test
  fun `formatter never produces negative zero with fixed decimal precision`() {
    val fixed2 = FormattingOptions(decimalPrecision = 2)
    assertEquals("0.00", NumberFormatter.formatResult(BigDecimal("-0.001"), fixed2))
    assertEquals("0.00", NumberFormatter.formatDouble(-0.001, fixed2))
    assertEquals("0", NumberFormatter.formatResult(BigDecimal("-0.1"), FormattingOptions(decimalPrecision = 0)))
  }

  // --- 4. Unit Converter Constants, Overflow, & ViewModel Header Attack ---
  @Test
  fun `unit converter extreme magnitudes all 16 categories and header rate label`() {
    // 1e300 TB -> GB must NOT overflow intermediate baseValue
    val dataUnits = UnitConverter.unitsFor(ConverterCategory.DATA_STORAGE)
    val tb = dataUnits.first { it.id == "tb" }
    val gb = dataUnits.first { it.id == "gb" }
    val convBig = UnitConverter.convert(1e300, tb, gb, ConverterCategory.DATA_STORAGE)
    assertNotNull("1e300 TB -> GB should not return null/Inf", convBig)
    assertEquals(1e303, convBig!!, 1e292)

    // Overflow beyond Double.MAX_VALUE must return null cleanly (not Infinity)
    val lenUnits = UnitConverter.unitsFor(ConverterCategory.LENGTH)
    val km = lenUnits.first { it.id == "km" }
    val mm = lenUnits.first { it.id == "mm" }
    assertNull(UnitConverter.convert(1e308, km, mm, ConverterCategory.LENGTH))

    // Independent physical constant verification across categories
    assertEquals(1609.344, UnitConverter.convert(1.0, lenUnits.first { it.id == "mi" }, lenUnits.first { it.id == "m" }, ConverterCategory.LENGTH)!!, 1e-9)
    assertEquals(5280.0, UnitConverter.convert(1.0, lenUnits.first { it.id == "mi" }, lenUnits.first { it.id == "ft" }, ConverterCategory.LENGTH)!!, 1e-9)
    assertEquals(180.0 / Math.PI, UnitConverter.convert(1.0, UnitConverter.unitsFor(ConverterCategory.ANGLE).first { it.id == "rad" }, UnitConverter.unitsFor(ConverterCategory.ANGLE).first { it.id == "deg" }, ConverterCategory.ANGLE)!!, 1e-9)

    val fuelUnits = UnitConverter.unitsFor(ConverterCategory.FUEL_ECONOMY)
    val mpgUs = fuelUnits.first { it.id == "mpg_us" }
    val l100 = fuelUnits.first { it.id == "l100km" }
    // 235.214583... / mpg_us = L/100km
    val expectedL100 = 100.0 / (30.0 * 1.609344 / 3.785411784)
    assertEquals(expectedL100, UnitConverter.convert(30.0, mpgUs, l100, ConverterCategory.FUEL_ECONOMY)!!, 1e-9)

    // ViewModel effectiveRateLabel must NOT say "1 °C = 1 °F" or "1 km/L = 1 L/100km"
    val cvm = ConverterViewModel()
    cvm.selectCategory(ConverterCategory.TEMPERATURE)
    val tempLabel = cvm.state.value.effectiveRateLabel()
    assertTrue("Temperature label was '$tempLabel'", tempLabel.contains("33.8"))

    cvm.selectCategory(ConverterCategory.FUEL_ECONOMY)
    val fuelLabel = cvm.state.value.effectiveRateLabel()
    assertTrue("Fuel label was '$fuelLabel'", fuelLabel.contains("100"))

    // Switching from negative Temperature to Length must clear minus sign
    cvm.selectCategory(ConverterCategory.TEMPERATURE)
    cvm.onClear()
    cvm.onDigit("4")
    cvm.onDigit("0")
    cvm.onToggleSign()
    assertEquals("−40", cvm.state.value.inputText)
    cvm.selectCategory(ConverterCategory.LENGTH)
    assertEquals("40", cvm.state.value.inputText)
  }

  // --- 5. Tools Engine Adversarial Edge Cases ---
  @Test
  fun `tools engine extreme inputs tiny EMI rates Long MIN_VALUE ratio and dates`() {
    // Ratio with Long.MIN_VALUE must NOT overflow abs()
    val rMin = ToolsEngine.ratio(Long.MIN_VALUE, Long.MIN_VALUE, null)!!
    assertEquals(1L to 1L, rMin.first)

    // Tiny interest rate EMI must NOT fail due to 1.0 + r == 1.0 cancellation
    val tinyEmi = ToolsEngine.calculateEmi(120_000.0, 1e-14, 12)
    assertNotNull("Tiny rate EMI must not return null", tinyEmi)
    assertEquals(10_000.0, tinyEmi!!.first, 1e-6)

    // Extreme percent difference without overflow
    val pd = ToolsEngine.percentDifference(1e308, -1e308)
    assertTrue("percentDifference(1e308, -1e308) must be finite, got $pd", pd.isFinite())

    // Average median overflow safety
    val avgMax = ToolsEngine.average(listOf(1e308, 1e308))!!
    assertTrue("median must not overflow, got ${avgMax.median}", avgMax.median.isFinite())

    // Pre-1582 date difference must match proleptic Gregorian calendar (consistent with calendarYmdDiff)
    val pre1582 = ToolsEngine.dateDifference(SimpleDate(1500, 3, 1), SimpleDate(1500, 3, 10))
    assertEquals(9L, pre1582.totalDays)
    val across1582 = ToolsEngine.dateDifference(SimpleDate(1582, 10, 4), SimpleDate(1582, 10, 15))
    assertEquals(11L, across1582.totalDays) // proleptic Gregorian is continuous without 10-day cutover gap

    // Leap day age boundary
    val leapBday = ToolsEngine.calculateAge(SimpleDate(2000, 2, 29), SimpleDate(2024, 2, 28))!!
    assertEquals(1L, leapBday.daysUntilNextBirthday)
  }

  // --- 6. CalculatorViewModel Race Condition & Scientific Notation Repeat Equals ---
  @Test
  fun `viewmodel delayed datastore memory load race and scientific notation repeat equals`() = runTest {
    val delayedMemory = MutableStateFlow(UserPreferences(memoryValue = BigDecimal("50")))
    val fakeHistory = object : HistoryDataSource {
      private val list = MutableStateFlow<List<CalculationHistoryEntity>>(emptyList())
      override val history: Flow<List<CalculationHistoryEntity>> = list
      override suspend fun saveCalculation(expression: String, resultFormatted: String, resultRaw: String, angleMode: String, isScientific: Boolean) {
        list.value = listOf(CalculationHistoryEntity(1, expression, resultFormatted, resultRaw, angleMode, isScientific)) + list.value
      }
      override suspend fun deleteById(id: Long) {}
      override suspend fun clearAll() {}
    }
    val delayedPrefs = object : PreferencesDataSource {
      override val preferences: Flow<UserPreferences> = flow {
        delay(50) // simulate DataStore async disk read delay
        emit(delayedMemory.value)
        delayedMemory.collect { emit(it) }
      }
      override suspend fun setThemeMode(mode: AppThemeMode) {}
      override suspend fun setHapticEnabled(enabled: Boolean) {}
      override suspend fun setGroupingStyle(style: NumberGroupingStyle) {}
      override suspend fun setDecimalPrecision(precision: Int) {}
      override suspend fun setAngleMode(mode: AngleMode) {}
      override suspend fun setMemoryValue(value: BigDecimal?) {
        delayedMemory.value = delayedMemory.value.copy(memoryValue = value)
      }
    }

    val vm = CalculatorViewModel(fakeHistory, delayedPrefs)
    val job = backgroundScope.launch(UnconfinedTestDispatcher(testScheduler)) {
      vm.uiState.collect()
    }

    // User immediately taps 10 then M+ BEFORE DataStore's 50ms initial emission arrives!
    vm.onDigit("1")
    vm.onDigit("0")
    vm.onMemoryAdd()
    advanceUntilIdle()

    // Persisted memory 50 + 10 MUST be 60, NOT overwritten with 10!
    assertEquals("60", vm.uiState.value.memoryFormatted)

    // Test repeated '=' when RHS uses scientific notation like 2 * 1e+3
    vm.onClearAll()
    vm.onDigit("2")
    vm.onOperator('×')
    vm.onDigit("1")
    vm.onDigit("0")
    // Force expression via history reuse to simulate scientific notation operand in expression
    vm.reuseHistoryItem(
      CalculationHistoryEntity(
        id = 99,
        expression = "2×1E+3",
        resultFormatted = "2,000",
        resultRaw = "2000",
        angleMode = "DEG",
        isScientific = false,
      )
    )
    vm.onEquals()
    advanceUntilIdle()
    assertEquals("2,000", vm.uiState.value.resultText)
    // Pressing '=' again must repeat ×1E+3 -> 2,000,000!
    vm.onEquals()
    advanceUntilIdle()
    assertEquals("2,000,000", vm.uiState.value.resultText)

    job.cancel()
  }

  // --- 7. Long.MIN_VALUE Exponent, Repeated Division, Implicit Mul, & Fractional Power Beyond Double ---
  @Test
  fun `long min exponent overflow repeated division implicit multiplication and scaled fractional powers`() {
    // Regression: Long.MIN_VALUE exponent must NOT wrap abs() to negative and return 1!
    evalErr("2^(−9223372036854775808)", CalcError.OVERFLOW)
    assertEquals("1", evalOk("1^(−9223372036854775808)").formatted)

    // Fractional powers beyond Double.MAX_VALUE and below Double.MIN_VALUE
    assertEquals(0, BigDecimal("1e200").compareTo(evalOk("(10^400)^0.5").value))
    assertEquals(0, BigDecimal("1e-200").compareTo(evalOk("(10^(−400))^0.5").value))
    assertEquals(0, BigDecimal("-1e200").compareTo(evalOk("nroot(3,−(10^600))").value))
    assertEquals("−2", evalOk("nroot(5,−32)").formatted)
    assertEquals("1", evalOk("0^0").formatted)

    // Repeated division precision
    val repDiv = evalOk("1÷3÷3÷3÷3")
    val direct81 = evalOk("1÷81")
    assertEquals(direct81.formatted, repDiv.formatted)
    assertTrue(repDiv.value.subtract(direct81.value).abs() < BigDecimal("1e-32"))

    // Implicit multiplication & scientific notation vs Euler's constant
    assertEquals("240", evalOk("5!2").formatted)
    assertEquals("1", evalOk("50%2").formatted)
    assertEquals("2,000", evalOk("2e3").formatted)
    assertEquals(0.25, evalOk("sin(30)cos(60)", AngleMode.DEG).value.toDouble(), 1e-12)
    assertEquals(2.0 * Math.E, evalOk("2e").value.toDouble(), 1e-12)

    // Wrong arity / malformed function calls
    evalErr("logBase(2)", CalcError.SYNTAX_ERROR)
    evalErr("nroot(3)", CalcError.SYNTAX_ERROR)
    evalErr("sin(1,2)", CalcError.SYNTAX_ERROR)
    evalErr("10^99999999", CalcError.OVERFLOW)
    evalErr("1E10000000", CalcError.OVERFLOW)
  }

  // --- 8. Independent Spot Verification of All 16 Converter Categories ---
  @Test
  fun `all 16 converter categories exact physical constant verification`() {
    fun conv(cat: ConverterCategory, fromId: String, toId: String, value: Double): Double {
      val units = UnitConverter.unitsFor(cat)
      val f = units.first { it.id == fromId }
      val t = units.first { it.id == toId }
      return UnitConverter.convert(value, f, t, cat)!!
    }

    // 1. Length: 1 yd = 3 ft = 36 in = 0.9144 m; 1 nmi = 1852 m
    assertEquals(36.0, conv(ConverterCategory.LENGTH, "yd", "in", 1.0), 1e-12)
    assertEquals(1852.0, conv(ConverterCategory.LENGTH, "nmi", "m", 1.0), 1e-12)
    // 2. Weight: 1 st = 14 lb; 1 lb = 16 oz = 0.45359237 kg
    assertEquals(14.0, conv(ConverterCategory.WEIGHT, "st", "lb", 1.0), 1e-12)
    assertEquals(16.0, conv(ConverterCategory.WEIGHT, "lb", "oz", 1.0), 1e-12)
    assertEquals(453.59237, conv(ConverterCategory.WEIGHT, "lb", "g", 1.0), 1e-9)
    // 3. Temperature: 37 °C = 98.6 °F = 310.15 K
    assertEquals(98.6, conv(ConverterCategory.TEMPERATURE, "c", "f", 37.0), 1e-12)
    assertEquals(310.15, conv(ConverterCategory.TEMPERATURE, "c", "k", 37.0), 1e-12)
    // 4. Area: 1 ac = 43560 ft² = 4840 yd²; 1 ha = 10000 m²
    assertEquals(43560.0, conv(ConverterCategory.AREA, "ac", "ft2", 1.0), 1e-9)
    assertEquals(4840.0, conv(ConverterCategory.AREA, "ac", "yd2", 1.0), 1e-9)
    // 5. Volume: 1 US gal = 4 qt = 8 pt = 16 cup = 128 fl oz = 256 tbsp = 768 tsp
    assertEquals(128.0, conv(ConverterCategory.VOLUME, "gal", "floz", 1.0), 1e-9)
    assertEquals(768.0, conv(ConverterCategory.VOLUME, "gal", "tsp", 1.0), 1e-9)
    // 6. Speed: 100 km/h -> m/s = 27.777777...; 1 knot = 1.852 km/h
    assertEquals(100.0 / 3.6, conv(ConverterCategory.SPEED, "kmh", "ms", 100.0), 1e-12)
    assertEquals(1.852, conv(ConverterCategory.SPEED, "kn", "kmh", 1.0), 1e-12)
    // 7. Time: 1 yr (Julian) = 365.25 days; 1 wk = 168 h
    assertEquals(365.25, conv(ConverterCategory.TIME, "yr", "d", 1.0), 1e-12)
    assertEquals(168.0, conv(ConverterCategory.TIME, "wk", "h", 1.0), 1e-12)
    // 8. Data Storage: 1 TiB = 1024 GiB; 1 B = 8 bit
    assertEquals(1024.0, conv(ConverterCategory.DATA_STORAGE, "tib", "gib", 1.0), 1e-12)
    assertEquals(8.0, conv(ConverterCategory.DATA_STORAGE, "b", "bit", 1.0), 1e-12)
    // 9. Pressure: 1 atm = 101.325 kPa = 1.01325 bar
    assertEquals(101.325, conv(ConverterCategory.PRESSURE, "atm", "kpa", 1.0), 1e-12)
    assertEquals(1.01325, conv(ConverterCategory.PRESSURE, "atm", "bar", 1.0), 1e-12)
    // 10. Energy: 1 kWh = 3600 kJ; 1 kcal = 4184 J
    assertEquals(3600.0, conv(ConverterCategory.ENERGY, "kwh", "kj", 1.0), 1e-12)
    assertEquals(4184.0, conv(ConverterCategory.ENERGY, "kcal", "j", 1.0), 1e-12)
    // 11. Power: 1 hp (mech) = 745.6998715822702 W; 1000 BTU/h = 293.0710701722222 W
    assertEquals(745.6998715822702, conv(ConverterCategory.POWER, "hp", "w", 1.0), 1e-9)
    assertEquals(293.0710701722222, conv(ConverterCategory.POWER, "btuh", "w", 1000.0), 1e-9)
    // 12. Force: 1 kgf = 9.80665 N; 1 N = 100,000 dyn
    assertEquals(9.80665, conv(ConverterCategory.FORCE, "kgf", "n", 1.0), 1e-12)
    assertEquals(100_000.0, conv(ConverterCategory.FORCE, "n", "dyn", 1.0), 1e-9)
    // 13. Angle: 1 rev = 360 deg = 400 grad = 21600 arcmin = 1296000 arcsec
    assertEquals(400.0, conv(ConverterCategory.ANGLE, "rev", "grad", 1.0), 1e-9)
    assertEquals(1_296_000.0, conv(ConverterCategory.ANGLE, "rev", "arcsec", 1.0), 1e-6)
    // 14. Frequency: 1 GHz = 1e6 kHz
    assertEquals(1_000_000.0, conv(ConverterCategory.FREQUENCY, "ghz", "khz", 1.0), 1e-6)
    // 15. Fuel Economy: negative invalid; 1 mpg UK = (3.785411784 / 4.54609) mpg US
    assertNull(UnitConverter.convert(-5.0, UnitConverter.unitsFor(ConverterCategory.FUEL_ECONOMY)[0], UnitConverter.unitsFor(ConverterCategory.FUEL_ECONOMY)[1], ConverterCategory.FUEL_ECONOMY))
    assertEquals(3.785411784 / 4.54609, conv(ConverterCategory.FUEL_ECONOMY, "mpg_uk", "mpg_us", 1.0), 1e-9)
    // 16. Currency: custom rate ignored when same unit (returns exact input)
    val usd = UnitConverter.unitsFor(ConverterCategory.CURRENCY).first { it.id == "usd" }
    assertEquals(100.0, UnitConverter.convert(100.0, usd, usd, ConverterCategory.CURRENCY, customCurrencyRate = 5.0)!!, 1e-9)
  }

  // --- 9. All 21 Tools Independent Checks & ViewModel Backspace/Decimal/Reuse Edges ---
  @Test
  fun `tools edge cases and viewmodel backspace decimal sign and history result reuse`() = runTest {
    // Average rejects non-finite
    assertNull(ToolsEngine.average(listOf(1.0, Double.NaN)))
    assertNull(ToolsEngine.average(listOf(1.0, Double.POSITIVE_INFINITY)))
    // Fraction negative denominators & Long.MIN_VALUE safety
    val fracNeg = ToolsEngine.fraction(1, -2, 1, -4, FractionOp.ADD)!!
    assertEquals(-3L, fracNeg.numerator)
    assertEquals(4L, fracNeg.denominator)
    assertEquals(0L, fracNeg.mixedWhole)
    // Time duration explicit same-day backwards
    val tdAbs = ToolsEngine.timeDuration(14, 0, 12, 30, overnightIfBefore = false)!!
    assertEquals(1, tdAbs.first)
    assertEquals(30, tdAbs.second)
    // Age when today == birthDate
    val newborn = ToolsEngine.calculateAge(SimpleDate(2026, 5, 1), SimpleDate(2026, 5, 1))!!
    assertEquals(0, newborn.years)
    assertEquals(0L, newborn.totalDays)
    assertEquals(365L, newborn.daysUntilNextBirthday)
    // Unit price equal
    val eqPrice = ToolsEngine.unitPriceCompare(10.0, 5.0, 20.0, 10.0)!!
    assertEquals(0.0, eqPrice.third, 1e-12)

    // ViewModel untested UI flows: onBackspace on multi-char functions, onDecimal on 1E-10, reuseHistoryResult
    val hist = object : HistoryDataSource {
      private val list = MutableStateFlow<List<CalculationHistoryEntity>>(emptyList())
      override val history: Flow<List<CalculationHistoryEntity>> = list
      override suspend fun saveCalculation(expression: String, resultFormatted: String, resultRaw: String, angleMode: String, isScientific: Boolean) {}
      override suspend fun deleteById(id: Long) {}
      override suspend fun clearAll() {}
    }
    val prefs = object : PreferencesDataSource {
      val s = MutableStateFlow(UserPreferences())
      override val preferences: Flow<UserPreferences> = s
      override suspend fun setThemeMode(mode: AppThemeMode) {}
      override suspend fun setHapticEnabled(enabled: Boolean) {}
      override suspend fun setGroupingStyle(style: NumberGroupingStyle) {}
      override suspend fun setDecimalPrecision(precision: Int) {}
      override suspend fun setAngleMode(mode: AngleMode) {}
      override suspend fun setMemoryValue(value: BigDecimal?) { s.value = s.value.copy(memoryValue = value) }
    }
    val vm = CalculatorViewModel(hist, prefs)
    val job = backgroundScope.launch(UnconfinedTestDispatcher(testScheduler)) { vm.uiState.collect() }
    advanceUntilIdle()

    vm.onScientificFunction("logBase(")
    advanceUntilIdle()
    assertEquals("logBase(", vm.uiState.value.expression)
    vm.onBackspace()
    advanceUntilIdle()
    assertEquals("", vm.uiState.value.expression)

    // onDecimal must block adding '.' inside scientific exponent 1E−10
    vm.reuseHistoryResult(CalculationHistoryEntity(1, "1÷1e10", "1×10^−10", "1E-10", "DEG", false))
    advanceUntilIdle()
    assertEquals("1E-10", vm.uiState.value.expression)
    vm.onDecimal()
    advanceUntilIdle()
    assertEquals("1E-10", vm.uiState.value.expression)

    // Negative result reuse appends wrapped in parens when expression non-empty
    vm.onClearAll()
    vm.onDigit("5")
    vm.onOperator('+')
    vm.reuseHistoryResult(CalculationHistoryEntity(2, "1−4", "−3", "−3", "DEG", false))
    advanceUntilIdle()
    assertEquals("5+(−3)", vm.uiState.value.expression)
    vm.onEquals()
    advanceUntilIdle()
    assertEquals("2", vm.uiState.value.resultText)

    job.cancel()
  }
}
