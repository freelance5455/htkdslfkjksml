package com.example

import com.example.ai.AIEngine
import com.example.ai.AIProcessingState
import com.example.ai.AppIntent
import com.example.ai.AppType
import com.example.ai.ConversationEngine
import com.example.ai.IntentEngine
import com.example.data.local.ChatMessage
import com.example.data.local.ChatSession
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SuesaAITest {

    private val conversationEngine = ConversationEngine()
    private val intentEngine = IntentEngine()
    private val aiEngine = AIEngine()

    @Test
    fun testChatSessionCreation() {
        val session = ChatSession(id = 1L, title = "Yapay Zeka Sohbeti")
        assertEquals(1L, session.id)
        assertEquals("Yapay Zeka Sohbeti", session.title)
        assertTrue(session.createdAt > 0)
    }

    @Test
    fun testChatMessageCreation() {
        val message = ChatMessage(
            id = 10L,
            sessionId = 1L,
            role = "user",
            content = "Merhaba Suesa AI!"
        )
        assertEquals(10L, message.id)
        assertEquals("user", message.role)
        assertEquals("Merhaba Suesa AI!", message.content)
    }

    // TEST 1: “Merhaba” & “Sa” -> Doğal selamlaşma, şablon yok
    @Test
    fun test1_GreetingReturnsNaturalAnswer() {
        val reply1 = conversationEngine.generateResponse("Merhaba")
        assertNotNull(reply1)
        assertTrue("Cevap 'Merhaba' veya 'Selam' içermeli", reply1.contains("Merhaba") || reply1.contains("Selam"))
        assertFalse(reply1.contains("Sorunu değerlendirdim"))
        assertFalse(reply1.contains("Mesajını değerlendirdim"))

        val reply2 = conversationEngine.generateResponse("Sa")
        assertTrue(reply2.contains("selam", ignoreCase = true))
    }

    // TEST 2: “Sen kimsin?” -> Suesa kendisini tanıtır
    @Test
    fun test2_IdentityResponse() {
        val reply = conversationEngine.generateResponse("Sen kimsin?")
        assertNotNull(reply)
        assertTrue(reply.contains("Suesa"))
        assertFalse(reply.contains("Sorunu değerlendirdim"))
    }

    // TEST 3: “2+2 kaç?” -> 4
    @Test
    fun test3_MathEvaluation() {
        val mathResult = conversationEngine.evaluateMathExpression("2+2 kaç?")
        assertNotNull(mathResult)
        assertEquals("4", mathResult)

        val fullReply = conversationEngine.generateResponse("2+2 kaç?")
        assertTrue(fullReply.contains("4"))
    }

    // TEST 4: “Bana kısa bir hikâye anlat.” -> Hikâye üretir
    @Test
    fun test4_StoryGeneration() {
        val story = conversationEngine.generateResponse("Bana kısa bir hikâye anlat.")
        assertNotNull(story)
        assertTrue("Hikaye yeterli uzunlukta olmalı", story.length > 50)
        assertFalse(story.contains("Sorunu değerlendirdim"))
    }

    // TEST 5: “YouTube'u aç.” -> IntentEngine OPEN_APP YOUTUBE
    @Test
    fun test5_YouTubeIntent() {
        val intent = intentEngine.parse("YouTube'u aç")
        assertTrue(intent is AppIntent.OpenApp)
        assertEquals(AppType.YOUTUBE, (intent as AppIntent.OpenApp).appType)
    }

    // TEST 6: “Google'ı aç.” -> IntentEngine OPEN_APP GOOGLE
    @Test
    fun test6_GoogleIntent() {
        val intent = intentEngine.parse("Google'ı aç")
        assertTrue(intent is AppIntent.OpenApp)
        assertEquals(AppType.GOOGLE, (intent as AppIntent.OpenApp).appType)
    }

    // TEST 7: “Kamerayı aç.” -> IntentEngine OPEN_APP CAMERA
    @Test
    fun test7_CameraIntent() {
        val intent = intentEngine.parse("Kamerayı aç")
        assertTrue(intent is AppIntent.OpenApp)
        assertEquals(AppType.CAMERA, (intent as AppIntent.OpenApp).appType)
    }

    // TEST 8: “Bugün hava nasıl?” -> WebSearch intent veya hava durumu sorgusu
    @Test
    fun test8_WeatherSearchIntent() {
        val intent = intentEngine.parse("Bugün hava nasıl?")
        assertTrue("Hava durumu canlı arama intenti olmalı", intent is AppIntent.WebSearch)
    }

    // TEST 9: Robotik şablonlar ("Sorunu değerlendirdim", "Mesajını değerlendirdim") asla kullanılmaz
    @Test
    fun test9_NoRoboticTemplates() = runBlocking {
        val queries = listOf(
            "Selam",
            "Nasılsın?",
            "Canım sıkılıyor.",
            "Bir şaka yap.",
            "Kod yazmayı nasıl öğrenebilirim?",
            "Fransa'nın başkenti neresi?"
        )

        for (q in queries) {
            val result = aiEngine.processUserRequest(
                userPrompt = q,
                apiKey = "",
                imageBase64 = null,
                isWebSearchEnabled = true,
                onStatusUpdate = {}
            )
            assertTrue(result is AIProcessingState.Complete)
            val text = (result as AIProcessingState.Complete).response.text
            assertFalse("Robotik 'Sorunu değerlendirdim' bulunmamalı: $text", text.contains("Sorunu değerlendirdim"))
            assertFalse("Robotik 'Mesajını değerlendirdim' bulunmamalı: $text", text.contains("Mesajını değerlendirdim"))
            assertFalse("Robotik 'Bu konuda sana yardımcı olmaktan' bulunmamalı: $text", text.contains("Bu konuda sana yardımcı olmaktan"))
            assertTrue("Dolu ve mantıklı bir cevap olmalı", text.isNotBlank())
        }
    }
}
