package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.engine.AudioAnalyzer
import com.example.engine.RecipeParser
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class MotionForgeTest {

  @Test
  fun testAppName() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("MotionForge AI", appName)
  }

  @Test
  fun testRecipeParserSample() {
    val samples = RecipeParser.getSampleRecipes()
    assertFalse(samples.isEmpty())

    val json = samples["Cyberpunk Cinematic Title"]
    assertNotNull(json)

    val validation = RecipeParser.parseAndValidate(json!!)
    assertTrue(validation.isValid)
    assertNotNull(validation.recipe)
    assertEquals("Cyberpunk Cinematic Title", validation.recipe?.projectName)
    assertEquals(1, validation.recipe?.scenes?.size)
  }

  @Test
  fun testAudioAnalyzer() {
    val analysis = AudioAnalyzer.analyzeAudio("Test Track", 10.0f, "balanced")
    assertEquals("Test Track", analysis.trackTitle)
    assertEquals(10.0f, analysis.durationSeconds)
    assertTrue(analysis.beatTimestamps.isNotEmpty())
    assertTrue(analysis.envelopeIntensity.isNotEmpty())
  }
}
