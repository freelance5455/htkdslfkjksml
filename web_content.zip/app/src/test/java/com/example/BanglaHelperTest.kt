package com.example

import com.example.ui.util.BanglaHelper
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class BanglaHelperTest {

    @Test
    fun testDigitConversions() {
        assertEquals("১২৩৪৫৬৭৮৯০", BanglaHelper.toBanglaDigits("1234567890"))
        assertEquals("1234567890", BanglaHelper.toEnglishDigits("১২৩৪৫৬৭৮৯০"))
    }

    @Test
    fun testParseAmount() {
        assertEquals(5000.0, BanglaHelper.parseAmount("৫০০০") ?: 0.0, 0.001)
        assertEquals(12500.5, BanglaHelper.parseAmount("12,500.50") ?: 0.0, 0.001)
        assertNull(BanglaHelper.parseAmount("-500"))
        assertNull(BanglaHelper.parseAmount("abc"))
    }

    @Test
    fun testFormatCurrency() {
        assertEquals("৳ ৫,০০০", BanglaHelper.formatCurrency(5000.0))
        assertEquals("- ৳ ৫০০", BanglaHelper.formatCurrency(-500.0))
    }

    @Test
    fun testBanglaMonths() {
        assertEquals(12, BanglaHelper.BANGLA_MONTHS.size)
        assertEquals("জানুয়ারি", BanglaHelper.BANGLA_MONTHS[0])
        assertEquals("ডিসেম্বর", BanglaHelper.BANGLA_MONTHS[11])
    }
}
