package com.example

import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import com.example.core.model.TradingMode
import com.example.features.autotrade.AutoTradeScreen
import com.example.ui.theme.IQTradeProTheme
import com.example.viewmodel.MainUiState
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class TradingModesComposeUiTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    @Test
    fun testAllSevenTradingModesVisiblyRenderedInUI() {
        var selectedMode = TradingMode.AUTO_TRADE

        composeTestRule.setContent {
            IQTradeProTheme {
                val state = MainUiState(
                    tradingMode = selectedMode.id,
                    selectedSymbol = "BTCUSDT",
                    selectedTimeframe = "15m"
                )
                AutoTradeScreen(
                    state = state,
                    onSelectTradingMode = { selectedMode = it },
                    onToggleSmartMode = {},
                    onToggleAutoTrading = {},
                    onToggleLiveTrading = {}
                )
            }
        }

        // Verify selector card is present
        composeTestRule.onNodeWithTag("trading_modes_selector_card").assertExists()

        // Verify all 7 modes exist and have corresponding test tags
        for (mode in TradingMode.entries) {
            composeTestRule.onNodeWithTag("mode_chip_${mode.name}").assertExists()
        }
    }

    @Test
    fun testTappingEachModeOneByOneSelectsWorkspace() {
        var currentActiveMode = TradingMode.AUTO_TRADE
        val tappedModes = mutableListOf<TradingMode>()

        composeTestRule.setContent {
            IQTradeProTheme {
                val state = MainUiState(
                    tradingMode = currentActiveMode.id,
                    selectedSymbol = "BTCUSDT",
                    selectedTimeframe = "15m"
                )
                AutoTradeScreen(
                    state = state,
                    onSelectTradingMode = {
                        currentActiveMode = it
                        tappedModes.add(it)
                    },
                    onToggleSmartMode = {},
                    onToggleAutoTrading = {},
                    onToggleLiveTrading = {}
                )
            }
        }

        // Tap each of the 7 modes sequentially using scroll-to
        for (mode in TradingMode.entries) {
            composeTestRule.onNodeWithTag("mode_chip_${mode.name}").performScrollTo().performClick()
        }

        assertEquals(7, tappedModes.size)
        assertEquals(TradingMode.AUTO_TRADE, tappedModes[0])
        assertEquals(TradingMode.SCALPING_TRADE, tappedModes[1])
        assertEquals(TradingMode.MANUAL_TRADE, tappedModes[2])
        assertEquals(TradingMode.LIVE_TRADE, tappedModes[3])
        assertEquals(TradingMode.PAPER_TRADE, tappedModes[4])
        assertEquals(TradingMode.ONLY_SIGNAL, tappedModes[5])
        assertEquals(TradingMode.CUSTOM_MODE, tappedModes[6])
    }

    @Test
    fun testCustomModeWorkspaceRendersAndSavesConfiguration() {
        var savedIndicators = listOf<String>()
        var savedTimeframes = listOf<String>()

        composeTestRule.setContent {
            IQTradeProTheme {
                val state = MainUiState(
                    tradingMode = TradingMode.CUSTOM_MODE.id,
                    selectedSymbol = "BTCUSDT",
                    selectedTimeframe = "15m",
                    customSelectedIndicators = listOf("EMA", "RSI", "MACD"),
                    customSelectedTimeframes = listOf("5m", "15m", "1h")
                )
                AutoTradeScreen(
                    state = state,
                    onUpdateCustomConfig = { ind, tf ->
                        savedIndicators = ind
                        savedTimeframes = tf
                    },
                    onToggleSmartMode = {},
                    onToggleAutoTrading = {},
                    onToggleLiveTrading = {}
                )
            }
        }

        // Scroll to and click save custom configuration button
        composeTestRule.onNodeWithTag("btn_save_custom_config").performScrollTo().performClick()

        // Verify save callback was executed with 3 timeframes
        assertEquals(3, savedTimeframes.size)
        assertEquals(listOf("5m", "15m", "1h"), savedTimeframes)
        assertEquals(listOf("EMA", "RSI", "MACD"), savedIndicators)
    }

    @Test
    fun testOnlySignalWorkspaceRendersWithoutCrash() {
        composeTestRule.setContent {
            IQTradeProTheme {
                val state = MainUiState(
                    tradingMode = TradingMode.ONLY_SIGNAL.id,
                    selectedSymbol = "BTCUSDT",
                    selectedTimeframe = "15m"
                )
                AutoTradeScreen(
                    state = state,
                    onSelectTradingMode = {},
                    onToggleSmartMode = {},
                    onToggleAutoTrading = {},
                    onToggleLiveTrading = {}
                )
            }
        }

        // Verify ONLY_SIGNAL workspace renders properly with no FormatFlagsConversionMismatchException
        composeTestRule.onNodeWithTag("only_signal_banner").assertExists()
    }
}
