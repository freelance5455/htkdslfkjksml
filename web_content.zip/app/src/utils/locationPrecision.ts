import {clampLat, clampLng, haversineDistanceMeters} from '../types/tracking';

export interface PrecisionPosition {
  lat: number;
  lng: number;
  accuracy: number;
  speed: number;
  heading: number;
  altitude: number | null;
  timestamp: number;
  sampleCount: number;
  rejectedOutliers: number;
  wasOutlierRejected: boolean;
}

export type AccuracyTier = 'high' | 'moderate' | 'low';

export interface AccuracyDiagnostic {
  tier: AccuracyTier;
  label: string;
  shortLabel: string;
}

export function getAccuracyDiagnostic(
  accuracyMeters: number
): AccuracyDiagnostic {
  if (!Number.isFinite(accuracyMeters) || accuracyMeters <= 12) {
    return {
      tier: 'high',
      label: 'Alta precisão (GPS)',
      shortLabel: 'GPS preciso',
    };
  }
  if (accuracyMeters <= 35) {
    return {
      tier: 'moderate',
      label: 'Precisão moderada',
      shortLabel: 'Moderada',
    };
  }
  return {
    tier: 'low',
    label: 'Aproximada (Wi-Fi / Rede)',
    shortLabel: 'Aproximada',
  };
}

export function computeBearingDegrees(
  from: {lat: number; lng: number},
  to: {lat: number; lng: number}
): number {
  const toRad = (d: number) => (d * Math.PI) / 180;
  const toDeg = (r: number) => (r * 180) / Math.PI;
  const lat1 = toRad(from.lat);
  const lat2 = toRad(to.lat);
  const dLng = toRad(to.lng - from.lng);

  const y = Math.sin(dLng) * Math.cos(lat2);
  const x =
    Math.cos(lat1) * Math.sin(lat2) -
    Math.sin(lat1) * Math.cos(lat2) * Math.cos(dLng);
  const brng = (toDeg(Math.atan2(y, x)) + 360) % 360;
  return Number.isFinite(brng) ? brng : 0;
}

/**
 * 2D Kalman / accuracy-weighted fusion filter with outlier & cell-tower jump rejection.
 * Reduces stationary GPS drift while remaining responsive during real movement.
 */
export class PrecisionLocationFilter {
  private lat = 0;
  private lng = 0;
  private varianceM2 = 0;
  private lastAccuracy = 0;
  private lastTimestamp = 0;
  private lastHeading = 0;
  private lastSpeed = 0;
  private initialized = false;
  private sampleCount = 0;
  private rejectedOutliers = 0;

  reset(): void {
    this.initialized = false;
    this.varianceM2 = 0;
    this.lastAccuracy = 0;
    this.lastTimestamp = 0;
    this.lastHeading = 0;
    this.lastSpeed = 0;
    this.sampleCount = 0;
    this.rejectedOutliers = 0;
  }

  process(pos: GeolocationPosition): PrecisionPosition | null {
    const rawLat = clampLat(pos.coords.latitude);
    const rawLng = clampLng(pos.coords.longitude);
    const rawAccuracy = Math.max(
      1,
      Math.min(100000, Math.round(pos.coords.accuracy || 15))
    );
    const timestamp =
      typeof pos.timestamp === 'number' && pos.timestamp > 0
        ? pos.timestamp
        : Date.now();
    const altitude =
      typeof pos.coords.altitude === 'number' &&
      Number.isFinite(pos.coords.altitude)
        ? pos.coords.altitude
        : null;

    if (!this.initialized) {
      this.lat = rawLat;
      this.lng = rawLng;
      this.varianceM2 = rawAccuracy * rawAccuracy;
      this.lastAccuracy = rawAccuracy;
      this.lastTimestamp = timestamp;
      this.lastSpeed = Math.max(
        0,
        Math.min(1000, Number(pos.coords.speed ?? 0) || 0)
      );
      this.lastHeading = Math.max(
        0,
        Math.min(360, Number(pos.coords.heading ?? 0) || 0)
      );
      this.initialized = true;
      this.sampleCount = 1;

      return {
        lat: this.lat,
        lng: this.lng,
        accuracy: rawAccuracy,
        speed: this.lastSpeed,
        heading: this.lastHeading,
        altitude,
        timestamp,
        sampleCount: this.sampleCount,
        rejectedOutliers: this.rejectedOutliers,
        wasOutlierRejected: false,
      };
    }

    // Ignore out-of-order stale timestamps
    if (timestamp < this.lastTimestamp - 1500) {
      return null;
    }

    const dtSec = Math.max(0.25, (timestamp - this.lastTimestamp) / 1000);
    const distanceMeters = haversineDistanceMeters(
      {lat: this.lat, lng: this.lng},
      {lat: rawLat, lng: rawLng}
    );
    const impliedSpeedMps = distanceMeters / dtSec;

    // Check if the new sample is dramatically better than the previous coarse fix
    const isMajorPrecisionUpgrade = rawAccuracy <= this.lastAccuracy * 0.4;

    // Reject sudden coarse cell-tower/Wi-Fi fallback spikes while a fresh GPS lock exists
    const isDegradedTowerJump =
      !isMajorPrecisionUpgrade &&
      dtSec < 25 &&
      rawAccuracy > Math.max(120, this.lastAccuracy * 3.5);

    // Reject physically impossible teleport spikes (> 130 m/s = ~468 km/h) unless precision just locked on
    const isImpossibleVelocitySpike =
      !isMajorPrecisionUpgrade &&
      impliedSpeedMps > 130 &&
      distanceMeters > Math.max(80, rawAccuracy * 1.5);

    if (isDegradedTowerJump || isImpossibleVelocitySpike) {
      this.rejectedOutliers += 1;
      return {
        lat: this.lat,
        lng: this.lng,
        accuracy: this.lastAccuracy,
        speed: this.lastSpeed,
        heading: this.lastHeading,
        altitude,
        timestamp: this.lastTimestamp,
        sampleCount: this.sampleCount,
        rejectedOutliers: this.rejectedOutliers,
        wasOutlierRejected: true,
      };
    }

    const reportedSpeed =
      typeof pos.coords.speed === 'number' &&
      Number.isFinite(pos.coords.speed) &&
      pos.coords.speed >= 0
        ? Math.min(1000, pos.coords.speed)
        : null;

    const estimatedSpeed =
      reportedSpeed !== null
        ? reportedSpeed
        : distanceMeters > Math.max(3, rawAccuracy * 0.4)
          ? Math.min(120, distanceMeters / dtSec)
          : 0;

    // Stationary micro-jitter deadband: hold rock-steady coordinates when parked/still
    const deadbandMeters = Math.min(4, rawAccuracy * 0.35);
    if (
      !isMajorPrecisionUpgrade &&
      estimatedSpeed < 0.45 &&
      distanceMeters < deadbandMeters &&
      rawAccuracy >= this.lastAccuracy * 0.85
    ) {
      this.lastTimestamp = timestamp;
      this.sampleCount += 1;
      if (rawAccuracy < this.lastAccuracy) {
        this.lastAccuracy = rawAccuracy;
      }
      return {
        lat: this.lat,
        lng: this.lng,
        accuracy: this.lastAccuracy,
        speed: 0,
        heading: this.lastHeading,
        altitude,
        timestamp,
        sampleCount: this.sampleCount,
        rejectedOutliers: this.rejectedOutliers,
        wasOutlierRejected: false,
      };
    }

    // Snap immediately when upgrading from coarse Wi-Fi/IP (>80m) to crisp GPS lock
    if (isMajorPrecisionUpgrade && this.lastAccuracy > 60 && rawAccuracy <= 25) {
      this.lat = rawLat;
      this.lng = rawLng;
      this.varianceM2 = rawAccuracy * rawAccuracy;
      this.lastAccuracy = rawAccuracy;
    } else {
      // Adaptive process noise: low when still, responsive when moving
      const qPerSec =
        estimatedSpeed < 0.5
          ? 0.45
          : Math.max(2.5, estimatedSpeed * estimatedSpeed * 0.35);
      const predictedVariance = this.varianceM2 + qPerSec * dtSec;
      const measurementVariance = Math.max(3, rawAccuracy) ** 2;
      const kalmanGain =
        predictedVariance / (predictedVariance + measurementVariance);

      const prevCoords = {lat: this.lat, lng: this.lng};
      this.lat = clampLat(this.lat + kalmanGain * (rawLat - this.lat));
      this.lng = clampLng(this.lng + kalmanGain * (rawLng - this.lng));
      this.varianceM2 = (1 - kalmanGain) * predictedVariance;
      this.lastAccuracy = rawAccuracy;

      // Update heading from hardware or smoothed displacement vector
      if (
        typeof pos.coords.heading === 'number' &&
        Number.isFinite(pos.coords.heading) &&
        pos.coords.heading >= 0 &&
        estimatedSpeed >= 0.4
      ) {
        this.lastHeading = Math.min(360, pos.coords.heading);
      } else if (
        haversineDistanceMeters(prevCoords, {lat: this.lat, lng: this.lng}) >= 3
      ) {
        this.lastHeading = computeBearingDegrees(prevCoords, {
          lat: this.lat,
          lng: this.lng,
        });
      }
    }

    this.lastTimestamp = timestamp;
    this.lastSpeed = estimatedSpeed;
    this.sampleCount += 1;

    return {
      lat: this.lat,
      lng: this.lng,
      accuracy: this.lastAccuracy,
      speed: this.lastSpeed,
      heading: this.lastHeading,
      altitude,
      timestamp,
      sampleCount: this.sampleCount,
      rejectedOutliers: this.rejectedOutliers,
      wasOutlierRejected: false,
    };
  }
}

function getSinglePosition(
  options: PositionOptions
): Promise<GeolocationPosition> {
  return new Promise((resolve, reject) => {
    navigator.geolocation.getCurrentPosition(resolve, reject, options);
  });
}

/**
 * Multi-sample burst lock: opens a high-accuracy watch for a short window and
 * returns the single highest-precision fix (stopping early once <= targetAccuracyMeters).
 */
export function acquireBestPosition(options?: {
  windowMs?: number;
  targetAccuracyMeters?: number;
  maxWaitMs?: number;
}): Promise<GeolocationPosition> {
  const windowMs = options?.windowMs ?? 3800;
  const targetAccuracy = options?.targetAccuracyMeters ?? 10;
  const maxWaitMs = options?.maxWaitMs ?? 8500;

  if (!navigator.geolocation) {
    return Promise.reject(new Error('Geolocation unavailable'));
  }

  return new Promise((resolve, reject) => {
    let bestPos: GeolocationPosition | null = null;
    let settled = false;
    let watchId: number | null = null;
    let windowTimer: number | null = null;
    let hardTimer: number | null = null;

    const cleanup = () => {
      if (watchId !== null) {
        navigator.geolocation.clearWatch(watchId);
        watchId = null;
      }
      if (windowTimer !== null) {
        window.clearTimeout(windowTimer);
        windowTimer = null;
      }
      if (hardTimer !== null) {
        window.clearTimeout(hardTimer);
        hardTimer = null;
      }
    };

    const finishWithBest = () => {
      if (settled) return;
      settled = true;
      cleanup();
      if (bestPos) {
        resolve(bestPos);
      } else {
        getSinglePosition({
          enableHighAccuracy: false,
          timeout: 7000,
          maximumAge: 30000,
        })
          .then(resolve)
          .catch(reject);
      }
    };

    windowTimer = window.setTimeout(() => {
      if (bestPos) {
        finishWithBest();
      }
    }, windowMs);

    hardTimer = window.setTimeout(() => {
      finishWithBest();
    }, maxWaitMs);

    watchId = navigator.geolocation.watchPosition(
      (pos) => {
        if (settled) return;
        const acc = pos.coords.accuracy || 9999;
        if (!bestPos || acc < (bestPos.coords.accuracy || 9999)) {
          bestPos = pos;
        }
        // Stop early as soon as a crisp high-accuracy GNSS lock arrives
        if (acc <= targetAccuracy) {
          settled = true;
          cleanup();
          resolve(bestPos);
        }
      },
      (err) => {
        if (settled) return;
        if (err.code === err.PERMISSION_DENIED) {
          settled = true;
          cleanup();
          reject(err);
          return;
        }
        if (bestPos) {
          finishWithBest();
        } else {
          settled = true;
          cleanup();
          getSinglePosition({
            enableHighAccuracy: false,
            timeout: 8000,
            maximumAge: 30000,
          })
            .then(resolve)
            .catch(reject);
        }
      },
      {
        enableHighAccuracy: true,
        maximumAge: 0,
        timeout: maxWaitMs,
      }
    );
  });
}
