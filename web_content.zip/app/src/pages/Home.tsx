import AppLayout from "@/components/AppLayout";
import { MonthSwitcher } from "@/components/MonthSwitcher";
import { TransactionDialog } from "@/components/TransactionDialog";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import {
  CategoryIcon,
  currentMonthKey,
  dayLabel,
  formatAmount,
  type BudgetRow,
  type CategoryRow,
  type TransactionRow,
} from "@/lib/finance";
import { ArrowDownLeft, ArrowUpRight, Plus, Wallet } from "lucide-react";
import { useMemo, useState } from "react";
import { Link } from "react-router";

export default function Home() {
  const [month, setMonth] = useState(currentMonthKey());
  const [dialogOpen, setDialogOpen] = useState(false);
  const { user } = useAuth();

  const txQuery = trpc.finance.transactions.list.useQuery({ monthKey: month });
  const budgetsQuery = trpc.finance.budgets.list.useQuery({ monthKey: month });
  const categoriesQuery = trpc.finance.categories.list.useQuery();
  const settingsQuery = trpc.finance.settings.get.useQuery();

  const currency = settingsQuery.data?.currency ?? "SAR";
  const familyName = settingsQuery.data?.familyName;

  const { income, expense, byCategory } = useMemo(() => {
    let income = 0;
    let expense = 0;
    const map = new Map<number, { row: TransactionRow; total: number }>();
    for (const t of txQuery.data ?? []) {
      if (t.categoryKind === "income") income += t.amount;
      else {
        expense += t.amount;
        const entry = map.get(t.categoryId);
        if (entry) entry.total += t.amount;
        else map.set(t.categoryId, { row: t, total: t.amount });
      }
    }
    const byCategory = [...map.values()].sort((a, b) => b.total - a.total);
    return { income, expense, byCategory };
  }, [txQuery.data]);

  const recent = (txQuery.data ?? []).slice(0, 6);

  return (
    <AppLayout>
      <div className="mx-auto max-w-6xl px-4 py-6 lg:px-8">
        {/* Header */}
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold">
              أهلاً، {user?.name?.split(" ")[0] ?? "بك"}
            </h1>
            <p className="mt-1 text-sm text-muted-foreground">
              {familyName ? `أسرة ${familyName} — ` : ""}
              هذا ملخص شؤون بيتك لشهر
            </p>
          </div>
          <div className="flex items-center gap-3">
            <MonthSwitcher value={month} onChange={setMonth} />
            <Button onClick={() => setDialogOpen(true)} className="gap-1.5">
              <Plus size={17} />
              <span className="hidden sm:inline">إضافة معاملة</span>
            </Button>
          </div>
        </div>

        {/* Summary */}
        <div className="mt-6 grid gap-3 sm:grid-cols-3">
          <StatCard
            label="إجمالي الدخل"
            amount={income}
            currency={currency}
            icon={<ArrowDownLeft size={18} />}
            tone="forest"
            loading={txQuery.isLoading}
          />
          <StatCard
            label="إجمالي المصاريف"
            amount={expense}
            currency={currency}
            icon={<ArrowUpRight size={18} />}
            tone="ember"
            loading={txQuery.isLoading}
          />
          <StatCard
            label="المتبقي من الدخل"
            amount={income - expense}
            currency={currency}
            icon={<Wallet size={18} />}
            tone={income - expense >= 0 ? "gold" : "ember"}
            loading={txQuery.isLoading}
          />
        </div>

        {/* Main grid */}
        <div className="mt-6 grid gap-6 lg:grid-cols-5">
          {/* Spending by category */}
          <section className="min-w-0 rounded-2xl border bg-card p-5 lg:col-span-3">
            <div className="flex items-center justify-between">
              <h2 className="text-base font-semibold">أين ذهبت الأموال؟</h2>
              <Link
                to="/transactions"
                className="text-sm font-medium text-ember hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ember rounded"
              >
                كل المعاملات
              </Link>
            </div>
            {txQuery.isLoading ? (
              <div className="mt-5 space-y-4">
                {[...Array(5)].map((_, i) => (
                  <Skeleton key={i} className="h-9 w-full" />
                ))}
              </div>
            ) : byCategory.length === 0 ? (
              <EmptyState onAdd={() => setDialogOpen(true)} />
            ) : (
              <div className="mt-5 space-y-4">
                {byCategory.slice(0, 7).map(({ row, total }) => (
                  <div key={row.categoryId}>
                    <div className="mb-1.5 flex flex-wrap items-center justify-between gap-x-2 text-sm">
                      <span className="flex min-w-0 items-center gap-2 font-medium">
                        <CategoryIcon
                          icon={row.categoryIcon}
                          color={row.categoryColor}
                          size={15}
                        />
                        <span className="truncate">{row.categoryName}</span>
                      </span>
                      <span className="tnum text-muted-foreground">
                        {formatAmount(total, currency)}
                        <span className="mr-2 text-xs">
                          {expense > 0 ? `${Math.round((total / expense) * 100)}٪` : ""}
                        </span>
                      </span>
                    </div>
                    <div className="h-2 overflow-hidden rounded-full bg-muted">
                      <div
                        className="h-full rounded-full transition-all duration-300"
                        style={{
                          width: `${expense > 0 ? Math.max((total / expense) * 100, 3) : 0}%`,
                          backgroundColor: row.categoryColor,
                        }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </section>

          {/* Side column */}
          <div className="min-w-0 space-y-6 lg:col-span-2">
            <BudgetSnapshot
              budgets={budgetsQuery.data ?? []}
              transactions={txQuery.data ?? []}
              currency={currency}
              loading={budgetsQuery.isLoading || txQuery.isLoading}
            />
            <RecentTransactions
              rows={recent}
              currency={currency}
              loading={txQuery.isLoading}
            />
          </div>
        </div>
      </div>

      <TransactionDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        categories={(categoriesQuery.data ?? []) as CategoryRow[]}
        editing={null}
      />
    </AppLayout>
  );
}

// ---------------------------------------------------------------------------

const TONES = {
  forest: { bg: "bg-forest/10", text: "text-forest" },
  ember: { bg: "bg-ember/10", text: "text-ember" },
  gold: { bg: "bg-gold/10", text: "text-gold" },
} as const;

function StatCard({
  label,
  amount,
  currency,
  icon,
  tone,
  loading,
}: {
  label: string;
  amount: number;
  currency: string;
  icon: React.ReactNode;
  tone: keyof typeof TONES;
  loading: boolean;
}) {
  const t = TONES[tone];
  return (
    <div className="rounded-2xl border bg-card p-5">
      <div className="flex items-center justify-between">
        <span className="text-sm text-muted-foreground">{label}</span>
        <span className={`flex h-8 w-8 items-center justify-center rounded-lg ${t.bg} ${t.text}`}>
          {icon}
        </span>
      </div>
      {loading ? (
        <Skeleton className="mt-3 h-8 w-32" />
      ) : (
        <div className={`tnum mt-3 text-[1.65rem] font-bold leading-none ${t.text}`}>
          {formatAmount(amount, currency)}
        </div>
      )}
    </div>
  );
}

function EmptyState({ onAdd }: { onAdd: () => void }) {
  return (
    <div className="mt-5 flex flex-col items-center gap-3 rounded-xl border border-dashed p-10 text-center">
      <p className="text-sm text-muted-foreground">
        لا توجد مصاريف مسجّلة هذا الشهر بعد.
      </p>
      <Button variant="outline" onClick={onAdd} className="gap-1.5">
        <Plus size={16} />
        سجّل أول مصروف
      </Button>
    </div>
  );
}

function BudgetSnapshot({
  budgets,
  transactions,
  currency,
  loading,
}: {
  budgets: BudgetRow[];
  transactions: TransactionRow[];
  currency: string;
  loading: boolean;
}) {
  const spentByCategory = useMemo(() => {
    const m = new Map<number, number>();
    for (const t of transactions) {
      if (t.categoryKind === "expense") {
        m.set(t.categoryId, (m.get(t.categoryId) ?? 0) + t.amount);
      }
    }
    return m;
  }, [transactions]);

  return (
    <section className="rounded-2xl border bg-card p-5">
      <div className="flex items-center justify-between">
        <h2 className="text-base font-semibold">الميزانيات</h2>
        <Link
          to="/budgets"
          className="rounded text-sm font-medium text-ember hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ember"
        >
          إدارة
        </Link>
      </div>
      {loading ? (
        <div className="mt-4 space-y-3">
          {[...Array(3)].map((_, i) => (
            <Skeleton key={i} className="h-12 w-full" />
          ))}
        </div>
      ) : budgets.length === 0 ? (
        <p className="mt-4 rounded-xl border border-dashed p-5 text-center text-sm text-muted-foreground">
          لم تحدد ميزانيات بعد — حدّد سقفاً لكل فئة من صفحة الميزانيات.
        </p>
      ) : (
        <div className="mt-4 space-y-4">
          {budgets.slice(0, 4).map(b => {
            const spent = spentByCategory.get(b.categoryId) ?? 0;
            const pct = b.amount > 0 ? (spent / b.amount) * 100 : 0;
            const barColor = pct > 100 ? "#de5126" : pct > 75 ? "#9b702c" : "#224e37";
            return (
              <div key={b.id}>
                <div className="mb-1.5 flex flex-wrap items-center justify-between gap-x-2 text-sm">
                  <span className="flex min-w-0 items-center gap-2 font-medium">
                    <CategoryIcon icon={b.categoryIcon} color={b.categoryColor} size={15} />
                    <span className="truncate">{b.categoryName}</span>
                  </span>
                  <span className="tnum whitespace-nowrap text-xs text-muted-foreground">
                    {formatAmount(spent, currency)} / {formatAmount(b.amount, currency)}
                  </span>
                </div>
                <div className="h-2 overflow-hidden rounded-full bg-muted">
                  <div
                    className="h-full rounded-full transition-all duration-300"
                    style={{ width: `${Math.min(pct, 100)}%`, backgroundColor: barColor }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      )}
    </section>
  );
}

function RecentTransactions({
  rows,
  currency,
  loading,
}: {
  rows: TransactionRow[];
  currency: string;
  loading: boolean;
}) {
  return (
    <section className="rounded-2xl border bg-card p-5">
      <h2 className="text-base font-semibold">أحدث المعاملات</h2>
      {loading ? (
        <div className="mt-4 space-y-3">
          {[...Array(4)].map((_, i) => (
            <Skeleton key={i} className="h-10 w-full" />
          ))}
        </div>
      ) : rows.length === 0 ? (
        <p className="mt-4 rounded-xl border border-dashed p-5 text-center text-sm text-muted-foreground">
          لا معاملات هذا الشهر.
        </p>
      ) : (
        <ul className="mt-4 divide-y">
          {rows.map(t => (
            <li key={t.id} className="flex items-center gap-3 py-2.5">
              <CategoryIcon icon={t.categoryIcon} color={t.categoryColor} size={15} />
              <div className="min-w-0 flex-1">
                <div className="truncate text-sm font-medium">{t.categoryName}</div>
                <div className="truncate text-xs text-muted-foreground">
                  {dayLabel(t.txDate)}
                  {t.note ? ` · ${t.note}` : ""}
                </div>
              </div>
              <span
                className={`tnum text-sm font-semibold ${
                  t.categoryKind === "income" ? "text-forest" : "text-ink"
                }`}
              >
                {t.categoryKind === "income" ? "+" : "−"}
                {formatAmount(t.amount, currency)}
              </span>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
