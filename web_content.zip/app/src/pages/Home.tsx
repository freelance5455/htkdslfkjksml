import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { trpc } from "@/providers/trpc";
import Navbar from "@/components/Navbar";
import FullScreenAd from "@/components/FullScreenAd";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { RefreshCw, CheckCircle2, TrendingUp, MousePointerClick, Wallet2 } from "lucide-react";

type Challenge = { id: number; svg: string };

export default function Home() {
  const { user, isLoading } = useAuth({ redirectOnUnauthenticated: true });
  const utils = trpc.useUtils();
  const summary = trpc.wallet.summary.useQuery(undefined, { enabled: !!user });

  const [challenge, setChallenge] = useState<Challenge | null>(null);
  const [answer, setAnswer] = useState("");
  const [ad, setAd] = useState<{ unitId: string; reward: number } | null>(null);
  const [lastReward, setLastReward] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);

  const getChallenge = trpc.captcha.getChallenge.useMutation({
    onSuccess: (data) => {
      setChallenge(data);
      setAnswer("");
      setError(null);
    },
  });

  const submit = trpc.captcha.submit.useMutation({
    onSuccess: (data) => {
      setAd({ unitId: data.adUnitId, reward: data.reward });
      setChallenge(null);
      setAnswer("");
    },
    onError: (e) => setError(e.message),
  });

  useEffect(() => {
    if (user && !challenge) getChallenge.mutate();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);

  if (isLoading || !user) {
    return <div className="flex min-h-screen items-center justify-center bg-[#0a0a1f] text-[#7a8292]">Loading…</div>;
  }

  return (
    <div className="min-h-screen bg-[#0a0a1f] pb-[env(safe-area-inset-bottom)] text-white">
      <Navbar />

      <main className="mx-auto max-w-3xl space-y-6 px-4 py-6">
        {/* balance hero */}
        <section className="rounded-3xl border border-white/10 bg-gradient-to-br from-[#12142a] to-[#0d0f24] p-6">
          <p className="text-sm text-[#7a8292]">Your balance</p>
          <p className="mt-1 font-mono text-4xl font-extrabold tabular-nums text-[#74f7b2] sm:text-5xl">
            ${(summary.data?.balance ?? 0).toFixed(4)}
          </p>
          <div className="mt-4 grid grid-cols-3 gap-3 text-center">
            <div className="rounded-2xl bg-white/5 p-3">
              <TrendingUp className="mx-auto h-4 w-4 text-[#74f7b2]" />
              <p className="mt-1 font-mono text-sm font-bold tabular-nums">${(summary.data?.todayEarned ?? 0).toFixed(4)}</p>
              <p className="text-[11px] text-[#7a8292]">Today</p>
            </div>
            <div className="rounded-2xl bg-white/5 p-3">
              <MousePointerClick className="mx-auto h-4 w-4 text-[#8ecbff]" />
              <p className="mt-1 font-mono text-sm font-bold tabular-nums">{summary.data?.todaySolves ?? 0}</p>
              <p className="text-[11px] text-[#7a8292]">Solves today</p>
            </div>
            <div className="rounded-2xl bg-white/5 p-3">
              <Wallet2 className="mx-auto h-4 w-4 text-[#c9b8ff]" />
              <p className="mt-1 font-mono text-sm font-bold tabular-nums">{summary.data?.totalSolves ?? 0}</p>
              <p className="text-[11px] text-[#7a8292]">All time</p>
            </div>
          </div>
        </section>

        {lastReward !== null && (
          <div className="flex items-center gap-2 rounded-2xl border border-[#74f7b2]/30 bg-[#74f7b2]/10 px-4 py-3 text-sm text-[#74f7b2]">
            <CheckCircle2 className="h-4 w-4 shrink-0" />
            +${lastReward.toFixed(4)} credited to your wallet. Keep going!
          </div>
        )}

        {/* captcha card */}
        <section className="rounded-3xl border border-white/10 bg-[#12142a] p-6">
          <h2 className="text-lg font-bold">Solve &amp; Earn</h2>
          <p className="mt-1 text-sm text-[#7a8292]">
            Type the characters below, submit, and watch a short ad to earn cash instantly.
          </p>

          <div className="mt-5 flex flex-col items-center gap-4">
            {challenge ? (
              <img
                src={`data:image/svg+xml;utf8,${encodeURIComponent(challenge.svg)}`}
                alt="captcha"
                className="h-20 w-60 rounded-xl border border-white/10"
                draggable={false}
              />
            ) : (
              <div className="flex h-20 w-60 items-center justify-center rounded-xl border border-white/10 bg-white/5 text-sm text-[#7a8292]">
                Loading captcha…
              </div>
            )}

            <div className="flex w-full max-w-sm flex-col gap-3 sm:flex-row">
              <Input
                value={answer}
                onChange={(e) => setAnswer(e.target.value.toUpperCase())}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && answer.trim() && challenge && !submit.isPending) {
                    submit.mutate({ id: challenge.id, answer });
                  }
                }}
                placeholder="Enter captcha"
                maxLength={8}
                className="h-12 flex-1 border-white/15 bg-white/5 text-center font-mono text-lg tracking-[0.3em] text-white placeholder:tracking-normal"
              />
              <Button
                disabled={!challenge || !answer.trim() || submit.isPending}
                onClick={() => challenge && submit.mutate({ id: challenge.id, answer })}
                className="h-12 min-w-28 bg-[#74f7b2] font-bold text-[#01102e] hover:bg-[#8ffcc4]"
              >
                {submit.isPending ? "Checking…" : "Submit"}
              </Button>
            </div>

            {error && <p className="text-sm text-rose-400">{error}</p>}

            <button
              onClick={() => getChallenge.mutate()}
              className="flex min-h-11 items-center gap-1.5 text-sm text-[#7a8292] hover:text-white"
            >
              <RefreshCw className="h-4 w-4" /> New captcha
            </button>
          </div>
        </section>

        <p className="pb-4 text-center text-xs text-[#7a8292]">
          Every solved captcha is rewarded after a short full-screen ad. Cash out from your wallet anytime.
        </p>
      </main>

      {ad && (
        <FullScreenAd
          adUnitId={ad.unitId}
          onClose={() => {
            setLastReward(ad.reward);
            setAd(null);
            utils.wallet.summary.invalidate();
            getChallenge.mutate();
          }}
        />
      )}
    </div>
  );
}
