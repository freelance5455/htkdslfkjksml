import { useEffect, useRef } from 'react'
import { startGame, stopGame } from '@/game/boot'

export default function Home() {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    startGame(canvas)
    return () => stopGame()
  }, [])

  return (
    <div id="game-root">
      <canvas id="game-canvas" ref={canvasRef} />
      <div id="ui-overlay">
        <section id="title-screen" className="screen active" aria-label="Main menu">
          <header className="title-topbar">
            <div className="brand-small"><span className="brand-mark">A</span> APEX MOTORSPORT</div>
            <div className="profile-strip"><span id="title-level">DRIVER 1</span><strong id="title-credits">0 CR</strong></div>
          </header>
          <div className="title-layout">
            <div className="hero-copy">
              <div className="eyebrow"><span /> THE WORLD IS YOUR PLAYGROUND</div>
              <h1>APEX<br /><em>FESTIVAL</em></h1>
              <p className="hero-subtitle">Drive real-world inspired roads across Switzerland, the Netherlands, Finland and Britain. Master every region.</p>
              <button className="primary-button" data-action="free"><span>START ENGINE</span><b>↗</b></button>
              <div className="control-hint"><kbd>WASD</kbd> DRIVE <kbd>SPACE</kbd> BOOST <kbd>SHIFT</kbd> DRIFT <kbd>ESC</kbd> PAUSE</div>
            </div>
            <div className="event-board">
              <div className="board-heading"><span>WORLD MAP</span><small>CHOOSE A COUNTRY</small></div>
              <button className="event-card region-ch" data-region="switzerland">
                <span className="event-number">🇨🇭</span>
                <span className="event-info"><strong>SWITZERLAND</strong><small>Alpine passes · steep climbs</small><i className="event-best">ALPS</i></span>
                <span className="event-arrow">→</span>
              </button>
              <button className="event-card region-nl" data-region="netherlands">
                <span className="event-number">🇳🇱</span>
                <span className="event-info"><strong>NETHERLANDS</strong><small>Canal roads · wind farms</small><i className="event-best">FLAT</i></span>
                <span className="event-arrow">→</span>
              </button>
              <button className="event-card region-fi" data-region="finland">
                <span className="event-number">🇫🇮</span>
                <span className="event-info"><strong>FINLAND</strong><small>Lakes · dense forest</small><i className="event-best">NORDIC</i></span>
                <span className="event-arrow">→</span>
              </button>
              <button className="event-card region-gb" data-region="britain">
                <span className="event-number">🇬🇧</span>
                <span className="event-info"><strong>BRITAIN</strong><small>Festival lanes · highlands</small><i className="event-best">CLASSIC</i></span>
                <span className="event-arrow">→</span>
              </button>
              <div className="board-footer"><span className="live-dot" /> REAL WORLD REGIONS · OPEN ROADS</div>
            </div>
          </div>
          <footer className="title-footer"><span>MOBILE + GAMEPAD READY</span><span>LANDSCAPE RECOMMENDED</span><span>v1.5 · OPEN WORLD · OFFLINE</span></footer>
        </section>

        <section id="hud" aria-label="Driving HUD">
          <div id="speed-fx" aria-hidden="true" />
          <div className="hud-top-left glass-panel">
            <span className="hud-label">NOW DRIVING</span>
            <strong id="hud-event">FESTIVAL FREE ROAM</strong>
            <small id="hud-objective">Explore the region · enter a glowing event ring</small>
          </div>
          <div className="hud-center">
            <strong id="hud-primary">0</strong>
            <span id="hud-secondary">SKILL SCORE</span>
          </div>
          <div className="hud-top-right">
            <div className="season-chip"><span id="hud-season">SUMMER</span><b id="hud-time">16:24</b></div>
            <button className="icon-button" data-action="mute" aria-label="Toggle sound">♪</button>
            <button className="icon-button" data-action="pause" aria-label="Pause game">Ⅱ</button>
          </div>
          <div className="minimap-wrap"><canvas id="minimap" width="160" height="160" /><span>N</span></div>
          <div id="toast" role="status" />
          <button id="event-prompt" data-action="start-nearby"><small>FESTIVAL EVENT</small><strong id="event-prompt-name">VILLAGE SPRINT</strong><span>TAP OR PRESS E TO START →</span></button>
          <div className="condition-panel"><span>CONDITION</span><b id="condition-value">100%</b><span id="hud-credits">0 CR</span></div>
          <div className="speed-cluster">
            <div className="boost-row"><span>NITRO</span><div className="meter"><i id="boost-fill" /></div><kbd>SPACE</kbd></div>
            <div className="speedo">
              <div className="speedo-ring" id="speedo-ring">
                <div className="speedo-fill" id="speed-arc"></div>
                <div className="speedo-center">
                  <strong id="speed-value">0</strong>
                  <span>KM/H</span>
                </div>
              </div>
            </div>
            <div className="region-chip"><span id="hud-region">🇨🇭 SWITZERLAND</span></div>
          </div>
        </section>

        <div id="touch-controls" aria-label="Touch driving controls">
          <div className="steering-controls">
            <button data-control="left" aria-label="Steer left">‹</button>
            <button data-control="right" aria-label="Steer right">›</button>
          </div>
          <div className="pedal-controls">
            <button className="small-control drift-control" data-control="handbrake">DRIFT</button>
            <button className="small-control boost-control" data-control="boost">BOOST</button>
            <button className="brake-control" data-control="brake">BRAKE</button>
            <button className="throttle-control" data-control="throttle">GAS</button>
          </div>
        </div>

        <section id="pause-screen" className="screen modal-screen" aria-label="Pause menu">
          <div className="modal-card pause-card">
            <div className="eyebrow"><span /> FESTIVAL CONTROL</div>
            <h2>PAUSED</h2>
            <p id="pause-season" className="season-summary">SUMMER · CLEAR</p>
            <div className="menu-grid">
              <button className="primary-button" data-action="resume"><span>RESUME DRIVE</span><b>→</b></button>
              <button data-action="restart">RESTART EVENT</button>
              <button data-action="season">CHANGE SEASON</button>
              <button id="quality-label" data-action="quality">GRAPHICS AUTO</button>
              <button data-action="time">TIME OF DAY</button>
              <button id="mute-label" data-action="mute">SOUND ON</button>
              <button id="fps-label" data-action="fps">FPS: OFF</button>
              <button data-action="title">MAIN MENU</button>
            </div>
            <div className="pause-events"><span>QUICK EVENT</span><div id="pause-events-list" /></div>
            <div className="pause-help">W / S — throttle & brake · A / D — steer<br />Shift — handbrake · Space — nitro · R — recover car</div>
            <button className="text-button" data-action="reset-save">Reset browser-local progress</button>
          </div>
        </section>

        <section id="results-screen" className="screen modal-screen" aria-label="Race results">
          <div className="modal-card results-card">
            <div id="result-kicker" className="eyebrow"><span /> VICTORY</div>
            <div id="result-title" className="result-position">P1</div>
            <h2 id="result-event">VILLAGE SPRINT</h2>
            <p id="result-note">A masterclass under festival lights</p>
            <div className="result-stats"><div><span>RACE TIME</span><strong id="result-time">0:00.0</strong></div><div><span>REWARD</span><strong id="result-reward">+0 CR</strong></div></div>
            <div className="results-actions"><button className="primary-button" data-action="restart"><span>RACE AGAIN</span><b>↻</b></button><button data-action="next">NEXT EVENT</button><button data-action="free">FREE ROAM</button><button data-action="title">MAIN MENU</button></div>
          </div>
        </section>
        <div id="fps-counter" aria-hidden="true" />
        <section id="loading-screen" className="screen loading-screen" aria-label="Loading region">
          <strong id="loading-title">LOADING</strong>
          <span id="loading-sub">BUILDING ROADS</span>
          <i className="loader-bar" />
        </section>
      </div>
      <div className="rotate-notice"><strong>ROTATE TO DRIVE</strong><span>Apex Festival is built for landscape.</span></div>
    </div>
  )
}
