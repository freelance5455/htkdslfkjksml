import { useEffect, useRef } from 'react'
import { startGame, stopGame } from '@/game/boot'

export default function Home() {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    startGame(canvas)
    return () => stopGame()
  }, [])

  return (
    <div id="game-root" dir="rtl">
      <canvas id="game-canvas" ref={canvasRef} aria-label="ساحة لعبة ساحة الفوضى" />
      <div id="ui-overlay">
        <div id="hud" className="is-hidden">
          <div className="hud-top">
            <div className="hud-group hud-wave-group">
              <div className="hud-chip wave-chip"><span className="chip-label">الموجة</span><strong id="hud-wave">١ / ٥</strong></div>
              <div className="wave-time" id="hud-time">٢٢</div>
            </div>
            <div className="xp-panel">
              <div className="xp-caption"><span>المستوى <b id="hud-level">١</b></span><span id="hud-xp-text">٠ / ٧</span></div>
              <div className="bar xp-bar"><div id="xp-fill" /></div>
            </div>
            <div className="hud-group hud-actions">
              <div className="score-block"><span>النقاط</span><strong id="hud-score">٠</strong></div>
              <button className="icon-button" data-action="mute" id="mute-button" aria-label="كتم الصوت">الصوت: يعمل</button>
              <button className="icon-button square" data-action="pause" aria-label="إيقاف مؤقت">Ⅱ</button>
            </div>
          </div>
          <div className="health-panel">
            <div className="health-caption"><span>سلامة النواة</span><strong id="hud-hp">١٠٠</strong></div>
            <div className="bar health-bar"><div id="health-fill" /></div>
          </div>
          <div id="boss-panel" className="boss-panel is-hidden">
            <div className="boss-caption"><span>المدمّر الأعظم</span><span>الزعيم</span></div>
            <div className="bar boss-bar"><div id="boss-fill" /></div>
          </div>
          <div className="hud-bottom">
            <div id="active-upgrades" className="active-upgrades" />
            <div className="dash-meter"><span id="dash-label">الاندفاع جاهز</span><div className="bar"><div id="dash-fill" /></div><kbd>SPACE</kbd></div>
          </div>
        </div>

        <section id="screen-title" className="screen title-screen">
          <div className="title-content">
            <div className="eyebrow"><span className="live-dot" /> بروتوكول البقاء // القطاع ٠٥</div>
            <h1>ساحة <span>الفوضى</span></h1>
            <p className="title-lead">وحوش من كل اتجاه. سلاح لا يتوقف.<br />وفي كل مستوى… قوة جديدة تكسر قواعد المعركة.</p>
            <button className="primary-button" data-action="start"><span>ابدأ الغزو</span><b>SPACE</b></button>
            <div className="title-features"><span>٥ موجات متصاعدة</span><i /><span>١٢ ترقية خارقة</span><i /><span>زعيم نهائي</span></div>
            <div className="controls-card">
              <div><kbd>WASD</kbd><span>أو الأسهم للحركة</span></div>
              <div><kbd>SPACE</kbd><span>اندفاع مع مناعة قصيرة</span></div>
              <div><kbd>AUTO</kbd><span>تصويب وإطلاق تلقائي</span></div>
            </div>
            <div className="best-line">أفضل نتيجة محفوظة <strong id="best-score">٠</strong><span>•</span> على الجوال: اسحب يسار الشاشة للحركة</div>
          </div>
          <div className="title-side-note">ابقَ متحركًا<br /><span>لا تدعهم يحاصرونك</span></div>
        </section>

        <section id="screen-level" className="screen modal-screen is-hidden">
          <div className="level-header"><div className="eyebrow">تم اختراق حد القوة</div><h2>اختر تطويرًا خارقًا</h2><p>الوقت متوقف. اختر بزر ١ أو ٢ أو ٣.</p></div>
          <div id="upgrade-options" className="upgrade-options" />
        </section>

        <section id="screen-pause" className="screen modal-screen is-hidden">
          <div className="menu-panel">
            <div className="eyebrow">النظام في وضع الاستعداد</div><h2>توقّف مؤقت</h2>
            <p>خذ نفسًا. الحشود ستنتظرك… مؤقتًا.</p>
            <button className="primary-button" data-action="resume">متابعة القتال <b>ESC</b></button>
            <button className="secondary-button" data-action="restart">إعادة من البداية</button>
            <button className="text-button" data-action="title">العودة إلى الشاشة الرئيسية</button>
          </div>
        </section>

        <section id="screen-end" className="screen modal-screen is-hidden">
          <div className="menu-panel end-panel">
            <div id="end-eyebrow" className="eyebrow">انتهت المحاولة</div><h2 id="end-title">سقطت النواة</h2>
            <p id="end-description">الفوضى ابتلعتك هذه المرة. عد أقوى.</p>
            <div className="results-grid"><div><span>النقاط</span><strong id="end-score">٠</strong></div><div><span>الوحوش</span><strong id="end-kills">٠</strong></div><div><span>المستوى</span><strong id="end-level">١</strong></div></div>
            <button className="primary-button" data-action="restart">محاولة جديدة <b>SPACE</b></button>
            <button className="text-button" data-action="title">الشاشة الرئيسية</button>
          </div>
        </section>

        <div id="toast" className="toast is-hidden"><strong id="toast-title" /><span id="toast-subtitle" /></div>
        <div className="touch-controls">
          <div className="touch-stick"><span>اسحب للحركة</span><i /></div>
          <button className="dash-button" data-action="dash"><span>اندفاع</span><small>مناعة قصيرة</small></button>
        </div>
      </div>
    </div>
  )
}
