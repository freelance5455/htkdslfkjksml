import { Loader2 } from "lucide-react";
import { trpc } from "@/providers/trpc";
import { addDays, diffDays, fmtDateShort, todayStr } from "@/lib/dates";

/** Last `days` days clean-map: 1 = clean day (no relapse that day), 0 = relapse. */
function buildDailyMap(startDate: string, relapseDates: string[], days: number) {
  const today = todayStr();
  const relapseSet = new Set(relapseDates);
  const result: { date: string; clean: boolean; inFuture: boolean }[] = [];
  for (let i = days - 1; i >= 0; i--) {
    const d = addDays(today, -i);
    result.push({
      date: d,
      clean: !relapseSet.has(d),
      inFuture: d < startDate,
    });
  }
  return result;
}

function buildMonthlyRelapses(relapseDates: string[], months = 6) {
  const counts = new Map<string, number>();
  const now = new Date();
  const keys: string[] = [];
  for (let i = months - 1; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
    keys.push(key);
    counts.set(key, 0);
  }
  for (const r of relapseDates) {
    const key = r.slice(0, 7);
    if (counts.has(key)) counts.set(key, (counts.get(key) ?? 0) + 1);
  }
  return keys.map((k) => ({ key: k, count: counts.get(k) ?? 0 }));
}

const BULAN_SINGKAT = ["Jan","Feb","Mar","Apr","Mei","Jun","Jul","Agu","Sep","Okt","Nov","Des"];

export default function Statistik() {
  const { data, isLoading } = trpc.tracker.my.useQuery();

  if (isLoading || !data) {
    return (
      <div className="flex items-center justify-center py-24">
        <Loader2 className="w-6 h-6 animate-spin text-primary" />
      </div>
    );
  }

  const { stats } = data;
  const relapseDates = data.relapses.map((r) => r.date);
  const daily = buildDailyMap(data.relapses.length ? relapseDates[0] : todayStr(), relapseDates, 30);
  const monthly = buildMonthlyRelapses(relapseDates);
  const maxMonthly = Math.max(1, ...monthly.map((m) => m.count));
  const segments: number[] = [];
  {
    let prev = null as string | null;
    const start = addDays(relapseDates.length ? relapseDates[0] : todayStr(), -30);
    for (const r of relapseDates) segments.push(diffDays(prev ?? start, r));
    segments.push(diffDays(prev ?? start, todayStr()));
  }

  return (
    <div className="space-y-6 max-w-2xl mx-auto">
      <h1 className="font-display text-2xl font-bold">Statistik</h1>

      <section className="grid grid-cols-2 gap-3">
        {[
          { label: "Streak saat ini", value: stats.currentStreak, accent: true },
          { label: "Streak terbaik", value: stats.bestStreak, accent: false },
          { label: "Total hari bersih", value: stats.totalCleanDays, accent: false },
          { label: "Total relaps", value: stats.totalRelapses, accent: false },
        ].map((s) => (
          <div key={s.label} className="rounded-2xl border border-border bg-card p-5">
            <div
              className={`font-display text-3xl font-bold ${
                s.accent ? "text-primary" : ""
              }`}
            >
              {s.value}
            </div>
            <div className="text-xs text-muted-foreground mt-1">{s.label}</div>
          </div>
        ))}
      </section>

      <section className="rounded-2xl border border-border bg-card p-5">
        <h2 className="font-display font-semibold mb-1">30 hari terakhir</h2>
        <p className="text-sm text-muted-foreground mb-4">
          Kotak hijau = hari bersih, merah = hari relaps.
        </p>
        <div className="grid grid-cols-10 gap-1.5" role="img" aria-label="Peta 30 hari terakhir">
          {daily.map((d) => (
            <div
              key={d.date}
              title={`${fmtDateShort(d.date)}: ${d.clean ? "bersih" : "relaps"}`}
              className={`aspect-square rounded ${
                d.inFuture
                  ? "bg-muted/40"
                  : d.clean
                    ? "bg-primary/70"
                    : "bg-destructive/80"
              }`}
            />
          ))}
        </div>
      </section>

      <section className="rounded-2xl border border-border bg-card p-5">
        <h2 className="font-display font-semibold mb-1">Relaps per bulan</h2>
        <p className="text-sm text-muted-foreground mb-4">6 bulan terakhir.</p>
        <div className="flex items-end gap-3 h-32">
          {monthly.map((m) => (
            <div key={m.key} className="flex-1 flex flex-col items-center gap-1.5">
              <span className="text-xs text-muted-foreground">{m.count}</span>
              <div
                className="w-full rounded-t bg-primary/60"
                style={{ height: `${Math.max(4, (m.count / maxMonthly) * 80)}px` }}
              />
              <span className="text-[10px] text-muted-foreground">
                {BULAN_SINGKAT[parseInt(m.key.slice(5), 10) - 1]}
              </span>
            </div>
          ))}
        </div>
      </section>

      <section className="rounded-2xl border border-border bg-card p-5">
        <h2 className="font-display font-semibold mb-1">Panjang streak per periode</h2>
        <p className="text-sm text-muted-foreground mb-4">
          Durasi hari bersih di setiap segmen antar relaps.
        </p>
        {segments.length <= 1 ? (
          <p className="text-sm text-muted-foreground">
            Belum cukup data — segmen pertama masih berjalan ({stats.currentStreak} hari).
          </p>
        ) : (
          <div className="space-y-2">
            {segments.map((len, i) => (
              <div key={i} className="flex items-center gap-3">
                <span className="text-xs text-muted-foreground w-16 shrink-0">
                  {i === segments.length - 1 ? "Sekarang" : `Segmen ${i + 1}`}
                </span>
                <div className="flex-1 h-4 rounded bg-muted overflow-hidden">
                  <div
                    className="h-full bg-primary/70 rounded"
                    style={{
                      width: `${Math.min(100, (len / Math.max(1, stats.bestStreak)) * 100)}%`,
                    }}
                  />
                </div>
                <span className="text-xs w-10 text-right shrink-0">{len} h</span>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
