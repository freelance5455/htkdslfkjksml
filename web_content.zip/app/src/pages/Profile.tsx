import { useEffect, useState } from "react";
import { Loader2 } from "lucide-react";
import { trpc } from "@/providers/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { todayStr } from "@/lib/dates";

export default function Profile() {
  const utils = trpc.useUtils();
  const { data: me } = trpc.auth.me.useQuery();

  const [name, setName] = useState("");
  const [start, setStart] = useState("");
  const [profileMsg, setProfileMsg] = useState("");
  const [curPass, setCurPass] = useState("");
  const [newPass, setNewPass] = useState("");
  const [passMsg, setPassMsg] = useState("");

  useEffect(() => {
    if (me) {
      setName(me.displayName);
      setStart(me.startDate);
    }
  }, [me]);

  const updateProfile = trpc.auth.updateProfile.useMutation({
    onSuccess: () => {
      setProfileMsg("Profil tersimpan.");
      utils.auth.me.invalidate();
    },
    onError: (e) => setProfileMsg(e.message),
  });
  const changePassword = trpc.auth.changePassword.useMutation({
    onSuccess: () => {
      setPassMsg("Password berhasil diganti.");
      setCurPass("");
      setNewPass("");
    },
    onError: (e) => setPassMsg(e.message),
  });

  if (!me) {
    return (
      <div className="flex items-center justify-center py-24">
        <Loader2 className="w-6 h-6 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-2xl mx-auto">
      <h1 className="font-display text-2xl font-bold">Profil</h1>

      <section className="rounded-2xl border border-border bg-card p-5 space-y-4">
        <div>
          <h2 className="font-display font-semibold">Informasi akun</h2>
          <p className="text-xs text-muted-foreground mt-0.5">
            @{me.username} · {me.role === "admin" ? "Admin" : "Member"}
          </p>
        </div>
        <form
          className="space-y-4"
          onSubmit={(e) => {
            e.preventDefault();
            setProfileMsg("");
            updateProfile.mutate({ displayName: name, startDate: start });
          }}
        >
          <div className="space-y-2">
            <Label htmlFor="p-name">Nama tampilan</Label>
            <Input id="p-name" value={name} onChange={(e) => setName(e.target.value)} required />
          </div>
          <div className="space-y-2">
            <Label htmlFor="p-start">Tanggal mulai perjalanan</Label>
            <Input
              id="p-start"
              type="date"
              max={todayStr()}
              value={start}
              onChange={(e) => setStart(e.target.value)}
              required
            />
            <p className="text-xs text-muted-foreground">
              Menghitung mundur streak dimulai dari tanggal ini.
            </p>
          </div>
          {profileMsg && <p className="text-sm text-primary">{profileMsg}</p>}
          <Button type="submit" disabled={updateProfile.isPending}>Simpan profil</Button>
        </form>
      </section>

      <section className="rounded-2xl border border-border bg-card p-5 space-y-4">
        <h2 className="font-display font-semibold">Ganti password</h2>
        <form
          className="space-y-4"
          onSubmit={(e) => {
            e.preventDefault();
            setPassMsg("");
            changePassword.mutate({ currentPassword: curPass, newPassword: newPass });
          }}
        >
          <div className="space-y-2">
            <Label htmlFor="p-cur">Password saat ini</Label>
            <Input
              id="p-cur"
              type="password"
              autoComplete="current-password"
              value={curPass}
              onChange={(e) => setCurPass(e.target.value)}
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="p-new">Password baru (min. 6 karakter)</Label>
            <Input
              id="p-new"
              type="password"
              autoComplete="new-password"
              value={newPass}
              onChange={(e) => setNewPass(e.target.value)}
              minLength={6}
              required
            />
          </div>
          {passMsg && (
            <p className={`text-sm ${changePassword.isError ? "text-destructive" : "text-primary"}`}>
              {passMsg}
            </p>
          )}
          <Button type="submit" disabled={changePassword.isPending}>Ganti password</Button>
        </form>
      </section>
    </div>
  );
}
