import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { trpc } from "@/providers/trpc";
import Navbar from "@/components/Navbar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Shield, Landmark, Users, Eye, Settings2 } from "lucide-react";

const METHODS = ["PayPal", "Bank Transfer", "UPI", "Paytm", "USDT (TRC20)"];

export default function Admin() {
  const { user, isLoading } = useAuth({ redirectOnUnauthenticated: true });
  const utils = trpc.useUtils();
  const isAdmin = user?.role === "admin";

  const stats = trpc.admin.stats.useQuery(undefined, { enabled: isAdmin });
  const userWithdrawals = trpc.admin.userWithdrawals.useQuery(undefined, { enabled: isAdmin });
  const ownerWithdrawals = trpc.admin.ownerWithdrawals.useQuery(undefined, { enabled: isAdmin });
  const adConfig = trpc.admin.getAdConfig.useQuery(undefined, { enabled: isAdmin });
  const payout = trpc.admin.getOwnerPayout.useQuery(undefined, { enabled: isAdmin });

  const [amount, setAmount] = useState("");
  const [method, setMethod] = useState("UPI");
  const [account, setAccount] = useState("8756106197@ibl");
  const [unitId, setUnitId] = useState<string | null>(null);
  const [msg, setMsg] = useState<string | null>(null);

  const claim = trpc.admin.claimOwnership.useMutation({
    onSuccess: () => utils.invalidate(),
    onError: (e) => setMsg(e.message),
  });
  const ownerWithdraw = trpc.admin.requestOwnerWithdrawal.useMutation({
    onSuccess: () => {
      setMsg("Owner payout recorded.");
      setAmount("");
      utils.admin.stats.invalidate();
      utils.admin.ownerWithdrawals.invalidate();
    },
    onError: (e) => setMsg(e.message),
  });
  const setStatus = trpc.admin.setWithdrawalStatus.useMutation({
    onSuccess: () => utils.admin.userWithdrawals.invalidate(),
  });
  const saveAdConfig = trpc.admin.setAdConfig.useMutation({
    onSuccess: () => {
      setMsg("Ad unit saved.");
      utils.admin.getAdConfig.invalidate();
    },
  });

  if (isLoading || !user) {
    return <div className="flex min-h-screen items-center justify-center bg-[#0a0a1f] text-[#7a8292]">Loading…</div>;
  }

  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-[#0a0a1f] text-white">
        <Navbar />
        <main className="mx-auto flex max-w-md flex-col items-center gap-4 px-4 py-16 text-center">
          <Shield className="h-10 w-10 text-[#74f7b2]" />
          <h1 className="text-xl font-bold">Owner access required</h1>
          <p className="text-sm text-[#7a8292]">
            If this is your app and no owner has been set yet, claim ownership below (only the first account can).
          </p>
          <Button
            onClick={() => claim.mutate()}
            disabled={claim.isPending}
            className="h-12 bg-[#74f7b2] font-bold text-[#01102e] hover:bg-[#8ffcc4]"
          >
            Claim ownership
          </Button>
          {msg && <p className="text-sm text-rose-400">{msg}</p>}
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0a0a1f] pb-[env(safe-area-inset-bottom)] text-white">
      <Navbar />
      <main className="mx-auto max-w-3xl space-y-6 px-4 py-6">
        {/* revenue stats */}
        <section className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          {[
            { icon: Landmark, label: "Ad revenue", value: `$${(stats.data?.platformRevenueTotal ?? 0).toFixed(4)}` },
            { icon: Users, label: "User payouts", value: `$${(stats.data?.userPayoutsTotal ?? 0).toFixed(4)}` },
            { icon: Eye, label: "Ad impressions", value: String(stats.data?.adImpressions ?? 0) },
            { icon: Users, label: "Users", value: String(stats.data?.userCount ?? 0) },
          ].map((s) => (
            <div key={s.label} className="rounded-2xl border border-white/10 bg-[#12142a] p-4">
              <s.icon className="h-4 w-4 text-[#74f7b2]" />
              <p className="mt-2 font-mono text-lg font-bold tabular-nums">{s.value}</p>
              <p className="text-[11px] text-[#7a8292]">{s.label}</p>
            </div>
          ))}
        </section>

        {/* owner withdrawal */}
        <section className="rounded-3xl border border-[#74f7b2]/20 bg-[#12142a] p-6">
          <h2 className="flex items-center gap-2 text-lg font-bold">
            <Landmark className="h-5 w-5 text-[#74f7b2]" /> My ad revenue
          </h2>
          <p className="mt-1 font-mono text-3xl font-extrabold tabular-nums text-[#74f7b2]">
            ${(stats.data?.platformRevenueAvailable ?? 0).toFixed(4)}
          </p>
          <p className="mt-1 text-xs text-[#7a8292]">
            Available to withdraw · min ${(stats.data?.minOwnerWithdrawal ?? 5).toFixed(2)}
          </p>
          <p className="mt-2 inline-block rounded-full border border-[#74f7b2]/30 bg-[#74f7b2]/10 px-3 py-1 font-mono text-xs text-[#74f7b2]">
            All ad revenue settles to UPI: {payout.data?.upiId ?? "8756106197@ibl"}
          </p>
          <div className="mt-4 grid gap-3 sm:grid-cols-3">
            <Select value={method} onValueChange={setMethod}>
              <SelectTrigger className="h-12 border-white/15 bg-white/5"><SelectValue /></SelectTrigger>
              <SelectContent>
                {METHODS.map((m) => <SelectItem key={m} value={m}>{m}</SelectItem>)}
              </SelectContent>
            </Select>
            <Input value={account} onChange={(e) => setAccount(e.target.value)} placeholder="Payout account" className="h-12 border-white/15 bg-white/5" />
            <Input value={amount} onChange={(e) => setAmount(e.target.value.replace(/[^0-9.]/g, ""))} placeholder="Amount" inputMode="decimal" className="h-12 border-white/15 bg-white/5 font-mono" />
          </div>
          <Button
            className="mt-3 h-12 bg-[#74f7b2] font-bold text-[#01102e] hover:bg-[#8ffcc4]"
            disabled={ownerWithdraw.isPending || !amount || !account.trim()}
            onClick={() => ownerWithdraw.mutate({ amount: Number(amount), method, account: account.trim() })}
          >
            Withdraw ad revenue
          </Button>
          {msg && <p className="mt-2 text-sm text-[#7a8292]">{msg}</p>}

          <div className="mt-4 divide-y divide-white/5">
            {(ownerWithdrawals.data ?? []).map((w) => (
              <div key={w.id} className="flex items-center justify-between py-2 text-sm">
                <span className="font-mono tabular-nums">${Number(w.amount).toFixed(2)} · {w.method}</span>
                <Badge variant="outline" className="border-[#74f7b2]/40 text-[#74f7b2]">{w.status}</Badge>
              </div>
            ))}
          </div>
        </section>

        {/* ad config */}
        <section className="rounded-3xl border border-white/10 bg-[#12142a] p-6">
          <h2 className="flex items-center gap-2 text-lg font-bold">
            <Settings2 className="h-5 w-5 text-[#8ecbff]" /> AppLovin MAX ad unit
          </h2>
          <p className="mt-1 text-xs text-[#7a8292]">
            Paste your interstitial ad unit ID from the MAX dashboard. The web preview shows simulated ads; the unit ID is served to clients for the native SDK.
          </p>
          <div className="mt-3 flex flex-col gap-3 sm:flex-row">
            <Input
              value={unitId ?? adConfig.data?.unitId ?? ""}
              onChange={(e) => setUnitId(e.target.value)}
              placeholder="e.g. 3f8a… interstitial unit id"
              className="h-12 flex-1 border-white/15 bg-white/5 font-mono text-sm"
            />
            <Button
              onClick={() => unitId && saveAdConfig.mutate({ unitId })}
              disabled={!unitId || saveAdConfig.isPending}
              className="h-12 bg-white/10 text-white hover:bg-white/20"
            >
              Save
            </Button>
          </div>
        </section>

        {/* user withdrawals */}
        <section className="rounded-3xl border border-white/10 bg-[#12142a] p-6">
          <h2 className="text-lg font-bold">User withdrawal requests</h2>
          <div className="mt-4 space-y-3">
            {(userWithdrawals.data ?? []).length === 0 && <p className="text-sm text-[#7a8292]">No requests yet.</p>}
            {(userWithdrawals.data ?? []).map((w) => (
              <div key={w.id} className="rounded-2xl bg-white/5 p-4">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <p className="font-mono font-bold tabular-nums">${Number(w.amount).toFixed(2)}</p>
                    <p className="text-xs text-[#7a8292]">
                      {w.userName ?? w.userEmail ?? "user"} · {w.method} · {w.account}
                    </p>
                  </div>
                  <Badge variant="outline" className="border-white/20">{w.status}</Badge>
                </div>
                {w.status === "pending" && (
                  <div className="mt-3 flex gap-2">
                    <Button size="sm" className="min-h-11 bg-[#74f7b2] text-[#01102e] hover:bg-[#8ffcc4]" onClick={() => setStatus.mutate({ id: w.id, status: "paid" })}>Mark paid</Button>
                    <Button size="sm" variant="outline" className="min-h-11 border-white/20" onClick={() => setStatus.mutate({ id: w.id, status: "approved" })}>Approve</Button>
                    <Button size="sm" variant="outline" className="min-h-11 border-rose-400/40 text-rose-300" onClick={() => setStatus.mutate({ id: w.id, status: "rejected" })}>Reject</Button>
                  </div>
                )}
              </div>
            ))}
          </div>
        </section>
      </main>
    </div>
  );
}
