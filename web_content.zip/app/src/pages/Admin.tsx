import { useState } from "react";
import { Loader2, Plus, Search, UserCheck, UserX, KeyRound, Trash2, Eye } from "lucide-react";
import { trpc } from "@/providers/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { fmtAgo, fmtDate, todayStr } from "@/lib/dates";

export default function Admin() {
  const utils = trpc.useUtils();
  const { data: members, isLoading } = trpc.admin.members.useQuery();
  const [query, setQuery] = useState("");
  const [detailId, setDetailId] = useState<number | null>(null);
  const [resetId, setResetId] = useState<number | null>(null);
  const [deleteId, setDeleteId] = useState<number | null>(null);
  const [newPassword, setNewPassword] = useState("");

  // form tambah member
  const [fUsername, setFUsername] = useState("");
  const [fPassword, setFPassword] = useState("");
  const [fName, setFName] = useState("");
  const [fStart, setFStart] = useState(todayStr());
  const [showForm, setShowForm] = useState(false);

  const invalidate = () => {
    utils.admin.members.invalidate();
    if (detailId) utils.admin.memberDetail.invalidate({ id: detailId });
  };

  const createMember = trpc.admin.createMember.useMutation({
    onSuccess: () => {
      setFUsername(""); setFPassword(""); setFName(""); setFStart(todayStr());
      setShowForm(false);
      invalidate();
    },
  });
  const setStatus = trpc.admin.setStatus.useMutation({ onSuccess: invalidate });
  const resetPassword = trpc.admin.resetPassword.useMutation({
    onSuccess: () => { setResetId(null); setNewPassword(""); },
  });
  const deleteMember = trpc.admin.deleteMember.useMutation({
    onSuccess: () => { setDeleteId(null); invalidate(); },
  });

  const detail = trpc.admin.memberDetail.useQuery(
    { id: detailId! },
    { enabled: detailId !== null },
  );

  const filtered = (members ?? []).filter(
    (m) =>
      m.role === "member" &&
      (m.displayName.toLowerCase().includes(query.toLowerCase()) ||
        m.username.toLowerCase().includes(query.toLowerCase())),
  );
  const memberList = filtered;
  const admins = (members ?? []).filter((m) => m.role === "admin");

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-24">
        <Loader2 className="w-6 h-6 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-3xl mx-auto">
      <div className="flex items-center justify-between gap-3">
        <h1 className="font-display text-2xl font-bold">Panel Admin</h1>
        <Button className="gap-2" onClick={() => setShowForm((v) => !v)}>
          <Plus className="w-4 h-4" />
          Member baru
        </Button>
      </div>

      {showForm && (
        <form
          className="rounded-2xl border border-border bg-card p-4 space-y-3"
          onSubmit={(e) => {
            e.preventDefault();
            createMember.mutate({
              username: fUsername,
              password: fPassword,
              displayName: fName,
              startDate: fStart,
            });
          }}
        >
          <div className="grid sm:grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label htmlFor="m-username">Username</Label>
              <Input id="m-username" value={fUsername} onChange={(e) => setFUsername(e.target.value)} required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="m-pass">Password awal</Label>
              <Input id="m-pass" value={fPassword} onChange={(e) => setFPassword(e.target.value)} required minLength={6} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="m-name">Nama tampilan</Label>
              <Input id="m-name" value={fName} onChange={(e) => setFName(e.target.value)} required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="m-start">Tanggal mulai</Label>
              <Input id="m-start" type="date" max={todayStr()} value={fStart} onChange={(e) => setFStart(e.target.value)} required />
            </div>
          </div>
          {createMember.error && <p className="text-sm text-destructive">{createMember.error.message}</p>}
          <Button type="submit" disabled={createMember.isPending}>
            {createMember.isPending && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
            Buat akun member
          </Button>
        </form>
      )}

      <div className="relative">
        <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
        <Input
          placeholder="Cari member…"
          className="pl-9"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
      </div>

      {memberList.length === 0 ? (
        <p className="text-sm text-muted-foreground text-center py-8">
          Tidak ada member yang cocok.
        </p>
      ) : (
        <ul className="space-y-2">
          {memberList.map((m) => (
            <li
              key={m.id}
              className={`rounded-2xl border p-4 ${
                m.status === "inactive" ? "border-border opacity-60" : "border-border bg-card"
              }`}
            >
              <div className="flex items-center gap-3">
                <div className="flex-1 min-w-0">
                  <div className="font-medium truncate">
                    {m.displayName}
                    {m.status === "inactive" && (
                      <span className="ml-2 text-xs text-destructive">nonaktif</span>
                    )}
                  </div>
                  <div className="text-xs text-muted-foreground">
                    @{m.username}
                    {m.stats &&
                      ` · streak ${m.stats.currentStreak} hari · terbaik ${m.stats.bestStreak} · relaps ${m.stats.totalRelapses}x`}
                  </div>
                </div>
                <Button variant="ghost" size="icon" aria-label={`Lihat detail ${m.displayName}`} onClick={() => setDetailId(m.id)}>
                  <Eye className="w-4 h-4" />
                </Button>
                <Button variant="ghost" size="icon" aria-label={`Reset password ${m.displayName}`} onClick={() => setResetId(m.id)}>
                  <KeyRound className="w-4 h-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  aria-label={m.status === "active" ? `Nonaktifkan ${m.displayName}` : `Aktifkan ${m.displayName}`}
                  onClick={() =>
                    setStatus.mutate({ id: m.id, status: m.status === "active" ? "inactive" : "active" })
                  }
                >
                  {m.status === "active" ? (
                    <UserX className="w-4 h-4 text-muted-foreground hover:text-destructive" />
                  ) : (
                    <UserCheck className="w-4 h-4 text-primary" />
                  )}
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  aria-label={`Hapus ${m.displayName}`}
                  className="text-muted-foreground hover:text-destructive"
                  onClick={() => setDeleteId(m.id)}
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            </li>
          ))}
        </ul>
      )}

      {admins.length > 0 && (
        <p className="text-xs text-muted-foreground">
          Admin: {admins.map((a) => a.displayName).join(", ")}
        </p>
      )}

      {/* Detail member */}
      <Dialog open={detailId !== null} onOpenChange={(v) => !v && setDetailId(null)}>
        <DialogContent className="max-h-[85dvh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="font-display">
              {detail.data?.user.displayName ?? "Detail member"}
            </DialogTitle>
            <DialogDescription>
              {detail.data ? `@${detail.data.user.username} · mulai ${fmtDate(detail.data.user.startDate)}` : ""}
            </DialogDescription>
          </DialogHeader>
          {detail.isLoading && <Loader2 className="w-5 h-5 animate-spin text-primary" />}
          {detail.data && (
            <div className="space-y-5">
              <div className="grid grid-cols-4 gap-2 text-center">
                {[
                  { l: "Streak", v: detail.data.stats.currentStreak },
                  { l: "Terbaik", v: detail.data.stats.bestStreak },
                  { l: "Bersih", v: detail.data.stats.totalCleanDays },
                  { l: "Relaps", v: detail.data.stats.totalRelapses },
                ].map((s) => (
                  <div key={s.l} className="rounded-xl border border-border p-2.5">
                    <div className="font-display font-bold">{s.v}</div>
                    <div className="text-[10px] text-muted-foreground">{s.l}</div>
                  </div>
                ))}
              </div>
              <div>
                <h3 className="text-sm font-semibold mb-2">Check-in 14 hari terakhir</h3>
                <div className="flex gap-1">
                  {detail.data.checkins.slice(0, 14).reverse().map((d) => (
                    <span key={d} className="flex-1 h-6 rounded bg-primary/50" title={fmtDate(d)} />
                  ))}
                  {detail.data.checkins.length === 0 && (
                    <p className="text-xs text-muted-foreground">Belum ada check-in.</p>
                  )}
                </div>
              </div>
              <div>
                <h3 className="text-sm font-semibold mb-2">Riwayat relaps</h3>
                {detail.data.relapses.length === 0 ? (
                  <p className="text-xs text-muted-foreground">Tidak ada relaps.</p>
                ) : (
                  <ul className="space-y-1.5">
                    {detail.data.relapses.slice(0, 10).map((r) => (
                      <li key={r.id} className="text-xs text-muted-foreground">
                        <span className="text-foreground font-medium">{fmtDate(r.date)}</span>
                        {" · "}
                        {fmtAgo(r.date)}
                        {r.note ? ` · ${r.note}` : ""}
                      </li>
                    ))}
                  </ul>
                )}
              </div>
              <div>
                <h3 className="text-sm font-semibold mb-2">Habit</h3>
                {detail.data.habits.length === 0 ? (
                  <p className="text-xs text-muted-foreground">Belum ada habit.</p>
                ) : (
                  <ul className="space-y-1.5">
                    {detail.data.habits.map((h) => (
                      <li key={h.id} className="text-xs text-muted-foreground">
                        <span className="text-foreground font-medium">{h.name}</span>
                        {" · "}
                        {h.completions}x selesai
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Reset password */}
      <Dialog open={resetId !== null} onOpenChange={(v) => !v && setResetId(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="font-display">Reset password</DialogTitle>
            <DialogDescription>
              Atur password baru untuk member ini.
            </DialogDescription>
          </DialogHeader>
          <form
            className="space-y-4"
            onSubmit={(e) => {
              e.preventDefault();
              if (resetId) resetPassword.mutate({ id: resetId, newPassword });
            }}
          >
            <div className="space-y-2">
              <Label htmlFor="reset-pass">Password baru</Label>
              <Input
                id="reset-pass"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                minLength={6}
                required
              />
            </div>
            {resetPassword.error && <p className="text-sm text-destructive">{resetPassword.error.message}</p>}
            <DialogFooter>
              <Button type="submit" disabled={resetPassword.isPending}>Simpan password</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Hapus member */}
      <AlertDialog open={deleteId !== null} onOpenChange={(v) => !v && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Hapus member?</AlertDialogTitle>
            <AlertDialogDescription>
              Semua data member ini (relaps, check-in, habit) akan dihapus permanen dan tidak bisa dikembalikan.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={() => deleteId && deleteMember.mutate({ id: deleteId })}
            >
              Hapus permanen
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
