import { useState } from "react";
import { Check, Loader2, Pencil, Plus, Trash2, X } from "lucide-react";
import { trpc } from "@/providers/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { addDays, fmtDay, fmtDateShort, todayStr } from "@/lib/dates";

export default function Habits() {
  const utils = trpc.useUtils();
  const { data: habits, isLoading } = trpc.habits.mine.useQuery();
  const [name, setName] = useState("");
  const [desc, setDesc] = useState("");
  const [editing, setEditing] = useState<number | null>(null);
  const [editName, setEditName] = useState("");
  const [editDesc, setEditDesc] = useState("");

  const invalidate = () => utils.habits.mine.invalidate();
  const create = trpc.habits.create.useMutation({ onSuccess: () => { setName(""); setDesc(""); invalidate(); } });
  const update = trpc.habits.update.useMutation({ onSuccess: () => { setEditing(null); invalidate(); } });
  const remove = trpc.habits.remove.useMutation({ onSuccess: invalidate });
  const toggle = trpc.habits.toggle.useMutation({ onSuccess: invalidate });

  const today = todayStr();
  const weekDates = Array.from({ length: 7 }, (_, i) => addDays(today, i - 6));

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-24">
        <Loader2 className="w-6 h-6 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-2xl mx-auto">
      <h1 className="font-display text-2xl font-bold">Habit Tracker</h1>

      <form
        className="rounded-2xl border border-border bg-card p-4 space-y-3"
        onSubmit={(e) => {
          e.preventDefault();
          create.mutate({ name, description: desc || undefined });
        }}
      >
        <div className="space-y-2">
          <Label htmlFor="habit-name">Habit baru</Label>
          <Input
            id="habit-name"
            placeholder="contoh: Olahraga 30 menit"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="habit-desc">Deskripsi (opsional)</Label>
          <Input
            id="habit-desc"
            placeholder="detail kecil yang membantu"
            value={desc}
            onChange={(e) => setDesc(e.target.value)}
          />
        </div>
        {create.error && <p className="text-sm text-destructive">{create.error.message}</p>}
        <Button type="submit" className="gap-2" disabled={create.isPending}>
          <Plus className="w-4 h-4" />
          Tambah habit
        </Button>
      </form>

      {habits && habits.length === 0 && (
        <p className="text-sm text-muted-foreground text-center py-6">
          Belum ada habit. Tambahkan habit pertama Anda di atas.
        </p>
      )}

      <ul className="space-y-3">
        {(habits ?? []).map((h) => {
          const doneSet = new Set(h.recentDates);
          return (
            <li key={h.id} className="rounded-2xl border border-border bg-card p-4">
              {editing === h.id ? (
                <form
                  className="space-y-3"
                  onSubmit={(e) => {
                    e.preventDefault();
                    update.mutate({ id: h.id, name: editName, description: editDesc || undefined });
                  }}
                >
                  <Input value={editName} onChange={(e) => setEditName(e.target.value)} required />
                  <Input value={editDesc} onChange={(e) => setEditDesc(e.target.value)} placeholder="Deskripsi" />
                  <div className="flex gap-2">
                    <Button type="submit" size="sm" disabled={update.isPending}>Simpan</Button>
                    <Button type="button" size="sm" variant="ghost" onClick={() => setEditing(null)}>
                      Batal
                    </Button>
                  </div>
                </form>
              ) : (
                <>
                  <div className="flex items-start gap-2">
                    <div className="flex-1 min-w-0">
                      <div className="font-medium">{h.name}</div>
                      {h.description && (
                        <div className="text-xs text-muted-foreground mt-0.5">{h.description}</div>
                      )}
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      aria-label={`Ubah ${h.name}`}
                      onClick={() => {
                        setEditing(h.id);
                        setEditName(h.name);
                        setEditDesc(h.description ?? "");
                      }}
                    >
                      <Pencil className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="text-muted-foreground hover:text-destructive"
                      aria-label={`Hapus ${h.name}`}
                      onClick={() => remove.mutate({ id: h.id })}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                  <div className="mt-3 flex items-center gap-2">
                    {weekDates.map((d) => {
                      const done = doneSet.has(d);
                      const isToday = d === today;
                      return (
                        <button
                          key={d}
                          type="button"
                          onClick={() => toggle.mutate({ habitId: h.id, date: d })}
                          disabled={toggle.isPending}
                          title={`${fmtDay(d)}, ${fmtDateShort(d)} — ${done ? "selesai" : "belum"}`}
                          aria-label={`${h.name} ${fmtDateShort(d)}: ${done ? "selesai" : "belum"}`}
                          aria-pressed={done}
                          className={`flex-1 min-h-[44px] rounded-lg border flex flex-col items-center justify-center gap-0.5 transition-colors ${
                            isToday ? "border-primary/50" : "border-border"
                          } ${
                            done
                              ? "bg-primary/15 text-primary"
                              : "bg-muted/40 text-muted-foreground"
                          }`}
                        >
                          <span className="text-[10px]">{fmtDay(d).slice(0, 3)}</span>
                          {done ? <Check className="w-3.5 h-3.5" /> : <X className="w-3.5 h-3.5 opacity-30" />}
                        </button>
                      );
                    })}
                  </div>
                </>
              )}
            </li>
          );
        })}
      </ul>
    </div>
  );
}
