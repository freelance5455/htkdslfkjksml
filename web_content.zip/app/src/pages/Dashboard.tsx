import { useState } from "react";
import { Flame, CheckCircle2, AlertTriangle, Loader2, Trash2 } from "lucide-react";
import { trpc } from "@/providers/trpc";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { fmtAgo, fmtDate } from "@/lib/dates";

const MILESTONES = [1, 3, 7, 14, 30, 60, 90, 180, 365];

function nextMilestone(streak: number): { target: number; remaining: number } | null {
  const next = MILESTONES.find((m) => m > streak);
  if (!next) return null;
  return { target: next, remaining: next - streak };
}

export default function Dashboard() {
  const utils = trpc.useUtils();
  const { data, isLoading, error } = trpc.tracker.my.useQuery();
  const [relapseDate, setRelapseDate] = useState("");
  const [relapseNote, setRelapseNote] = useState("");
  const [dialogOpen, setDialogOpen] = useState(false);

  const invalidate = () => utils.tracker.my.invalidate();

  const checkin = trpc.tracker.checkin.useMutation({ onSuccess: invalidate });
  const relapse = trpc.tracker.relapse.useMutation({
    onSuccess: () => {
      setDialogOpen(false);
      setRelapseNote("");
      invalidate();
    },
  });
  const deleteRelapse = trpc.tracker.deleteRelapse.useMutation({ onSuccess: invalidate });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-24">
        <Loader2 className="w-6 h-6 animate-spin text-primary" />
      </div>
    );
  }
  if (error || !data) {
    return (
      <p className="text-destructive text-sm py-10 text-center">
        Gagal memuat data. Coba muat ulang halaman.
      </p>
    );
  }

  const { stats, today } = data;
  const milestone = nextMilestone(stats.currentStreak);
  const passedMilestones = MILESTONES.filter((m) => m <= stats.currentStreak);

  return (
    <div className="space-y-6 max-w-2xl mx-auto">
      {/* Kartu streak utama */}
      <section className="rounded-2xl border border-border bg-card p-8 text-center">
        <div className="inline-flex items-center gap-2 text-muted-foreground text-sm mb-3">
          <Flame className="w-4 h-4 text-primary" />
          Streak saat ini
        </div>
        <div className="font-display text-7xl font-bold text-primary leading-none">
          {stats.currentStreak}
        </div>
        <div className="text-muted-foreground mt-2">
          {stats.currentStreak === 0
            ? stats.relapsedToday
              ? "Hari ini terjadi relaps. Besok adalah hari ke-1."
              : "Belum ada streak. Mulai hari ini."
            : `hari bersih${stats.currentStreak > 1 ? "" : ""} — pertahankan!`}
        </div>

        <div className="mt-6 flex flex-col sm:flex-row gap-3 justify-center">
          {data.checkedToday ? (
            <Button disabled className="gap-2">
              <CheckCircle2 className="w-4 h-4" />
              Sudah check-in hari ini
            </Button>
          ) : (
            <Button
              className="gap-2"
              onClick={() => checkin.mutate()}
              disabled={checkin.isPending}
            >
              {checkin.isPending ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <CheckCircle2 className="w-4 h-4" />
              )}
              Check-in hari ini
            </Button>
          )}
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="outline" className="gap-2 text-destructive border-destructive/40 hover:bg-destructive/10">
                <AlertTriangle className="w-4 h-4" />
                Catat relaps
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle className="font-display">Catat relaps</DialogTitle>
                <DialogDescription>
                  Kejujuran adalah bagian dari pemulihan. Jangan berhenti — mulai lagi hari ini.
                </DialogDescription>
              </DialogHeader>
              <form
                className="space-y-4"
                onSubmit={(e) => {
                  e.preventDefault();
                  relapse.mutate({
                    date: relapseDate || today,
                    note: relapseNote || undefined,
                  });
                }}
              >
                <div className="space-y-2">
                  <Label htmlFor="relapse-date">Tanggal relaps</Label>
                  <Input
                    id="relapse-date"
                    type="date"
                    max={today}
                    value={relapseDate || today}
                    onChange={(e) => setRelapseDate(e.target.value)}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="relapse-note">Catatan (opsional)</Label>
                  <Textarea
                    id="relapse-note"
                    placeholder="Apa pemicunya? Apa yang bisa dilakukan lain kali?"
                    value={relapseNote}
                    onChange={(e) => setRelapseNote(e.target.value)}
                    rows={3}
                  />
                </div>
                {relapse.error && (
                  <p className="text-sm text-destructive">{relapse.error.message}</p>
                )}
                <DialogFooter>
                  <Button type="submit" variant="destructive" disabled={relapse.isPending}>
                    {relapse.isPending && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                    Simpan relaps
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </section>

      {/* Milestone */}
      <section className="rounded-2xl border border-border bg-card p-5">
        <h2 className="font-display font-semibold mb-3">Milestone</h2>
        <div className="flex flex-wrap gap-2">
          {MILESTONES.map((m) => (
            <span
              key={m}
              className={`px-3 py-1.5 rounded-full text-xs font-medium border ${
                passedMilestones.includes(m)
                  ? "bg-primary/15 text-primary border-primary/40"
                  : "text-muted-foreground border-border"
              }`}
            >
              {m} hari
            </span>
          ))}
        </div>
        {milestone && stats.currentStreak > 0 && (
          <p className="text-sm text-muted-foreground mt-3">
            {milestone.remaining} hari lagi menuju milestone {milestone.target} hari.
          </p>
        )}
      </section>

      {/* Statistik ringkas */}
      <section className="grid grid-cols-3 gap-3">
        {[
          { label: "Streak terbaik", value: stats.bestStreak },
          { label: "Total hari bersih", value: stats.totalCleanDays },
          { label: "Total relaps", value: stats.totalRelapses },
        ].map((s) => (
          <div key={s.label} className="rounded-2xl border border-border bg-card p-4 text-center">
            <div className="font-display text-2xl font-bold">{s.value}</div>
            <div className="text-xs text-muted-foreground mt-1">{s.label}</div>
          </div>
        ))}
      </section>

      {/* Riwayat relaps terbaru */}
      <section className="rounded-2xl border border-border bg-card p-5">
        <h2 className="font-display font-semibold mb-1">Riwayat relaps</h2>
        <p className="text-sm text-muted-foreground mb-4">
          {data.relapses.length === 0
            ? "Belum ada relaps tercatat. Pertahankan!"
            : `${data.relapses.length} relaps tercatat.`}
        </p>
        {data.relapses.length > 0 && (
          <ul className="divide-y divide-border">
            {data.relapses.slice(0, 5).map((r) => (
              <li key={r.id} className="py-3 flex items-start gap-3">
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium">{fmtDate(r.date)}</div>
                  <div className="text-xs text-muted-foreground">
                    {fmtAgo(r.date)}
                    {r.note ? ` · ${r.note}` : ""}
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  className="text-muted-foreground hover:text-destructive"
                  aria-label="Hapus catatan relaps"
                  onClick={() => deleteRelapse.mutate({ id: r.id })}
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
