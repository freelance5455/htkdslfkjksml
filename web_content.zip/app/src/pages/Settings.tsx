import AppLayout from "@/components/AppLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { trpc } from "@/providers/trpc";
import { CURRENCIES } from "@/lib/finance";
import { Save } from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";

export default function Settings() {
  const utils = trpc.useUtils();
  const settingsQuery = trpc.finance.settings.get.useQuery();
  const [familyName, setFamilyName] = useState("");
  const [currency, setCurrency] = useState("SAR");

  useEffect(() => {
    if (settingsQuery.data) {
      setFamilyName(settingsQuery.data.familyName ?? "");
      setCurrency(settingsQuery.data.currency);
    }
  }, [settingsQuery.data]);

  const updateMutation = trpc.finance.settings.update.useMutation({
    onSuccess: async () => {
      await utils.finance.settings.get.invalidate();
      toast.success("تم حفظ الإعدادات");
    },
    onError: () => toast.error("تعذّر حفظ الإعدادات"),
  });

  const dirty =
    settingsQuery.data &&
    (familyName !== (settingsQuery.data.familyName ?? "") ||
      currency !== settingsQuery.data.currency);

  return (
    <AppLayout>
      <div className="mx-auto max-w-2xl px-4 py-6 lg:px-8">
        <h1 className="text-2xl font-bold">الإعدادات</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          إعدادات بيتك الشخصية وتفضيلات العرض.
        </p>

        {settingsQuery.isLoading ? (
          <div className="mt-6 space-y-4">
            <Skeleton className="h-16 rounded-xl" />
            <Skeleton className="h-16 rounded-xl" />
          </div>
        ) : (
          <div className="mt-6 space-y-4">
            <div className="rounded-2xl border bg-card p-5">
              <Label htmlFor="family-name">اسم الأسرة (اختياري)</Label>
              <Input
                id="family-name"
                value={familyName}
                onChange={e => setFamilyName(e.target.value)}
                maxLength={100}
                placeholder="مثال: آل أحمد"
                className="mt-2"
              />
              <p className="mt-2 text-xs text-muted-foreground">
                يظهر الاسم في تحية لوحة التحكم.
              </p>
            </div>

            <div className="rounded-2xl border bg-card p-5">
              <Label>العملة</Label>
              <Select value={currency} onValueChange={setCurrency}>
                <SelectTrigger className="mt-2">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {CURRENCIES.map(c => (
                    <SelectItem key={c.code} value={c.code}>
                      {c.label} ({c.code})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="mt-2 text-xs text-muted-foreground">
                تُعرض جميع المبالغ في هذه العملة.
              </p>
            </div>

            <Button
              onClick={() =>
                updateMutation.mutate({
                  familyName: familyName.trim(),
                  currency,
                })
              }
              disabled={!dirty || updateMutation.isPending}
              className="gap-1.5"
            >
              <Save size={16} />
              حفظ الإعدادات
            </Button>
          </div>
        )}
      </div>
    </AppLayout>
  );
}
