import AppLayout from "@/components/AppLayout";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { trpc } from "@/providers/trpc";
import {
  CATEGORY_ICON_KEYS,
  CategoryIcon,
  type CategoryRow,
} from "@/lib/finance";
import { Pencil, Plus, Trash2 } from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";

const COLOR_SWATCHES = [
  "#de5126",
  "#224e37",
  "#9b702c",
  "#75b858",
  "#3f6b8a",
  "#5b4a8a",
  "#b3372f",
  "#c96f2e",
  "#2b6d6a",
  "#6d6d6d",
];

export default function Categories() {
  const utils = trpc.useUtils();
  const categoriesQuery = trpc.finance.categories.list.useQuery();

  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<CategoryRow | null>(null);
  const [deleting, setDeleting] = useState<CategoryRow | null>(null);

  const [name, setName] = useState("");
  const [kind, setKind] = useState<"expense" | "income">("expense");
  const [icon, setIcon] = useState("tag");
  const [color, setColor] = useState(COLOR_SWATCHES[0]);

  useEffect(() => {
    if (!dialogOpen) return;
    if (editing) {
      setName(editing.name);
      setKind(editing.kind);
      setIcon(editing.icon);
      setColor(editing.color);
    } else {
      setName("");
      setKind("expense");
      setIcon("tag");
      setColor(COLOR_SWATCHES[0]);
    }
  }, [dialogOpen, editing]);

  const invalidate = async () => {
    await utils.finance.categories.list.invalidate();
  };

  const createMutation = trpc.finance.categories.create.useMutation({
    onSuccess: async () => {
      await invalidate();
      toast.success("تمت إضافة الفئة");
      setDialogOpen(false);
    },
    onError: () => toast.error("تعذّر إضافة الفئة"),
  });

  const updateMutation = trpc.finance.categories.update.useMutation({
    onSuccess: async () => {
      await invalidate();
      toast.success("تم تحديث الفئة");
      setDialogOpen(false);
    },
    onError: () => toast.error("تعذّر تحديث الفئة"),
  });

  const deleteMutation = trpc.finance.categories.delete.useMutation({
    onSuccess: async () => {
      await invalidate();
      await utils.finance.transactions.list.invalidate();
      await utils.finance.budgets.list.invalidate();
      toast.success("تم حذف الفئة");
      setDeleting(null);
    },
    onError: () => toast.error("تعذّر حذف الفئة"),
  });

  const submit = () => {
    if (!name.trim()) {
      toast.error("أدخل اسم الفئة");
      return;
    }
    if (editing) {
      updateMutation.mutate({ id: editing.id, name: name.trim(), icon, color });
    } else {
      createMutation.mutate({ name: name.trim(), kind, icon, color });
    }
  };

  const pending = createMutation.isPending || updateMutation.isPending;

  const expenseCats = (categoriesQuery.data ?? []).filter(c => c.kind === "expense");
  const incomeCats = (categoriesQuery.data ?? []).filter(c => c.kind === "income");

  return (
    <AppLayout>
      <div className="mx-auto max-w-6xl px-4 py-6 lg:px-8">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold">الفئات</h1>
            <p className="mt-1 text-sm text-muted-foreground">
              نظّم مصاريفك ودخلك بالفئات التي تناسب بيتك.
            </p>
          </div>
          <Button
            onClick={() => {
              setEditing(null);
              setDialogOpen(true);
            }}
            className="gap-1.5"
          >
            <Plus size={17} />
            فئة جديدة
          </Button>
        </div>

        {categoriesQuery.isLoading ? (
          <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {[...Array(6)].map((_, i) => (
              <Skeleton key={i} className="h-16 rounded-xl" />
            ))}
          </div>
        ) : (
          <>
            <CategorySection
              title="فئات المصاريف"
              categories={expenseCats}
              onEdit={cat => {
                setEditing(cat);
                setDialogOpen(true);
              }}
              onDelete={setDeleting}
            />
            <CategorySection
              title="فئات الدخل"
              categories={incomeCats}
              onEdit={cat => {
                setEditing(cat);
                setDialogOpen(true);
              }}
              onDelete={setDeleting}
            />
          </>
        )}
      </div>

      {/* Add / edit dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-md" dir="rtl">
          <DialogHeader>
            <DialogTitle>{editing ? "تعديل فئة" : "فئة جديدة"}</DialogTitle>
            <DialogDescription>
              {editing
                ? "عدّل اسم الفئة أو أيقونتها أو لونها."
                : "أنشئ فئة مخصصة لتصنيف معاملاتك."}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-2">
            {!editing && (
              <div className="space-y-1.5">
                <Label>نوع الفئة</Label>
                <Select
                  value={kind}
                  onValueChange={v => setKind(v as "expense" | "income")}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="expense">مصروف</SelectItem>
                    <SelectItem value="income">دخل</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            )}

            <div className="space-y-1.5">
              <Label htmlFor="cat-name">اسم الفئة</Label>
              <Input
                id="cat-name"
                value={name}
                onChange={e => setName(e.target.value)}
                maxLength={100}
                placeholder="مثال: حديقة الحيوان"
              />
            </div>

            <div className="space-y-1.5">
              <Label>الأيقونة</Label>
              <div className="grid grid-cols-7 gap-1.5">
                {CATEGORY_ICON_KEYS.map(key => (
                  <button
                    key={key}
                    type="button"
                    onClick={() => setIcon(key)}
                    aria-label={key}
                    className={`flex h-10 items-center justify-center rounded-lg transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ember ${
                      icon === key
                        ? "bg-ember/15 ring-2 ring-ember"
                        : "bg-muted hover:bg-muted/70"
                    }`}
                  >
                    <CategoryIcon icon={key} color={color} size={15} />
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-1.5">
              <Label>اللون</Label>
              <div className="flex flex-wrap gap-2">
                {COLOR_SWATCHES.map(c => (
                  <button
                    key={c}
                    type="button"
                    onClick={() => setColor(c)}
                    aria-label={`لون ${c}`}
                    className={`h-8 w-8 rounded-full transition-transform focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ember focus-visible:ring-offset-2 ${
                      color === c ? "scale-110 ring-2 ring-ink ring-offset-2" : ""
                    }`}
                    style={{ backgroundColor: c }}
                  />
                ))}
              </div>
            </div>
          </div>

          <DialogFooter className="gap-2 sm:gap-0">
            <Button variant="outline" onClick={() => setDialogOpen(false)}>
              إلغاء
            </Button>
            <Button onClick={submit} disabled={pending}>
              {pending ? "جارٍ الحفظ…" : editing ? "حفظ التعديلات" : "إضافة الفئة"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete confirm */}
      <AlertDialog open={!!deleting} onOpenChange={o => !o && setDeleting(null)}>
        <AlertDialogContent dir="rtl">
          <AlertDialogHeader>
            <AlertDialogTitle>حذف الفئة «{deleting?.name}»؟</AlertDialogTitle>
            <AlertDialogDescription>
              سيتم حذف هذه الفئة مع جميع معاملاتها وميزانياتها المرتبطة بها نهائياً.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>إلغاء</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deleting && deleteMutation.mutate({ id: deleting.id })}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              حذف نهائي
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </AppLayout>
  );
}

function CategorySection({
  title,
  categories,
  onEdit,
  onDelete,
}: {
  title: string;
  categories: CategoryRow[];
  onEdit: (cat: CategoryRow) => void;
  onDelete: (cat: CategoryRow) => void;
}) {
  if (categories.length === 0) return null;
  return (
    <section className="mt-6">
      <h2 className="mb-3 text-sm font-semibold text-muted-foreground">{title}</h2>
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {categories.map(cat => (
          <div
            key={cat.id}
            className="flex items-center gap-3 rounded-xl border bg-card p-3"
          >
            <CategoryIcon icon={cat.icon} color={cat.color} size={16} />
            <span className="flex-1 truncate text-sm font-medium">{cat.name}</span>
            <button
              aria-label="تعديل"
              onClick={() => onEdit(cat)}
              className="flex h-8 w-8 items-center justify-center rounded-lg text-muted-foreground transition-colors hover:bg-muted hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ember"
            >
              <Pencil size={15} />
            </button>
            <button
              aria-label="حذف"
              onClick={() => onDelete(cat)}
              className="flex h-8 w-8 items-center justify-center rounded-lg text-muted-foreground transition-colors hover:bg-destructive/10 hover:text-destructive focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ember"
            >
              <Trash2 size={15} />
            </button>
          </div>
        ))}
      </div>
    </section>
  );
}
