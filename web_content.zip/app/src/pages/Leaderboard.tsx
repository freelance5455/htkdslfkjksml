import { Crown, Flame, Loader2, Medal } from "lucide-react";
import { trpc } from "@/providers/trpc";

function rankIcon(rank: number) {
  if (rank === 1) return <Crown className="w-5 h-5 text-primary" />;
  if (rank === 2) return <Medal className="w-5 h-5 text-muted-foreground" />;
  if (rank === 3) return <Medal className="w-5 h-5 text-amber-600" />;
  return <span className="w-5 text-center text-sm text-muted-foreground">{rank}</span>;
}

export default function Leaderboard() {
  const { data, isLoading } = trpc.leaderboard.list.useQuery();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-24">
        <Loader2 className="w-6 h-6 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-2xl mx-auto">
      <div>
        <h1 className="font-display text-2xl font-bold">Peringkat</h1>
        <p className="text-sm text-muted-foreground mt-1">
          Streak saat ini seluruh member. Saling dorong, bukan saling menjatuhkan.
        </p>
      </div>

      {!data || data.length === 0 ? (
        <p className="text-sm text-muted-foreground text-center py-10">
          Belum ada member aktif.
        </p>
      ) : (
        <ul className="space-y-2">
          {data.map((m) => (
            <li
              key={m.id}
              className={`rounded-2xl border p-4 flex items-center gap-4 ${
                m.isMe
                  ? "border-primary/50 bg-primary/5"
                  : "border-border bg-card"
              }`}
            >
              <div className="w-8 flex justify-center shrink-0">{rankIcon(m.rank)}</div>
              <div className="flex-1 min-w-0">
                <div className="font-medium truncate">
                  {m.displayName}
                  {m.isMe && <span className="text-xs text-primary ml-2">(Anda)</span>}
                </div>
                <div className="text-xs text-muted-foreground">
                  Terbaik {m.bestStreak} hari · Total bersih {m.totalCleanDays} hari · Relaps {m.totalRelapses}x
                </div>
              </div>
              <div className="flex items-center gap-1.5 shrink-0">
                <Flame className="w-4 h-4 text-primary" />
                <span className="font-display font-bold text-lg">{m.currentStreak}</span>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
