import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { trpc } from "@/providers/trpc";
import Navbar from "@/components/Navbar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { ArrowUpRight } from "lucide-react";

const METHODS = ["PayPal", "Bank Transfer", "UPI", "Paytm", "USDT (TRC20)"];

function statusBadge(s: string) {
  const map: Record<string, string> = {
    pending: "border-amber-400/40 text-amber-300",
    approved: "border-sky-400/40 text-sky-300",
    paid: "border-[#74f7b2]/40 text-[#74f7b2]",
    rejected: "border-rose-400/40 text-rose-300",
  };
  return <Badge variant="outline" className={map[s] ?? ""}>{s}</Badge>;
}

export default function Wallet() {
  const { user, isLoading } = useAuth({ redirectOnUnauthenticated: true });
  const utils = trpc.useUtils();
  const summary = trpc.wallet.summary.useQuery(undefined, { enabled: !!user });
  const history = trpc.wallet.myWithdrawals.useQuery(undefined, { enabled: !!user });

  const [amount, setAmount] = useState("");
  const [method, setMethod] = useState(METHODS[0]);
  const [account, setAccount] = useState("");
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);

  const withdraw = trpc.wallet.requestWithdrawal.useMutation({
    onSuccess: () => {
      setMsg({ ok: true, text: "Withdrawal request submitted. It will be reviewed shortly." });
      setAmount("");
      utils.wallet.summary.invalidate();
      utils.wallet.myWithdrawals.invalidate();
    },
    onError: (e) => setMsg({ ok: false, text: e.message }),
  });

  if (isLoading || !user) {
    return <div className="flex min-h-screen items-center justify-center bg-[#0a0a1f] text-[#7a8292]">Loading…</div>;
  }

  const balance = summary.data?.balance ?? 0;
  const min = summary.data?.minWithdrawal ?? 1;

  return (
    <div className="min-h-screen bg-[#0a0a1f] pb-[env(safe-area-inset-bottom)] text-white">
      <Navbar />
      <main className="mx-auto max-w-3xl space-y-6 px-4 py-6">
        <section className="rounded-3xl border border-white/10 bg-[#12142a] p-6">
          <p className="text-sm text-[#7a8292]">Available balance</p>
          <p className="mt-1 font-mono text-4xl font-extrabold tabular-nums text-[#74f7b2]">${balance.toFixed(4)}</p>
          <p className="mt-2 text-xs text-[#7a8292]">Minimum withdrawal: ${min.toFixed(2)}</p>
        </section>

        <section className="rounded-3xl border border-white/10 bg-[#12142a] p-6">
          <h2 className="flex items-center gap-2 text-lg font-bold">
            <ArrowUpRight className="h-5 w-5 text-[#74f7b2]" /> Withdraw funds
          </h2>
          <div className="mt-4 grid gap-3">
            <Select value={method} onValueChange={setMethod}>
              <SelectTrigger className="h-12 border-white/15 bg-white/5">
                <SelectValue placeholder="Payout method" />
              </SelectTrigger>
              <SelectContent>
                {METHODS.map((m) => (
                  <SelectItem key={m} value={m}>{m}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Input
              value={account}
              onChange={(e) => setAccount(e.target.value)}
              placeholder={method === "PayPal" ? "PayPal email" : method === "UPI" ? "yourname@upi" : "Account / wallet address"}
              className="h-12 border-white/15 bg-white/5 text-white"
            />
            <Input
              value={amount}
              onChange={(e) => setAmount(e.target.value.replace(/[^0-9.]/g, ""))}
              placeholder={`Amount (min $${min.toFixed(2)})`}
              inputMode="decimal"
              className="h-12 border-white/15 bg-white/5 font-mono text-white"
            />
            <Button
              className="h-12 bg-[#74f7b2] font-bold text-[#01102e] hover:bg-[#8ffcc4]"
              disabled={withdraw.isPending || !amount || !account.trim()}
              onClick={() => withdraw.mutate({ amount: Number(amount), method, account: account.trim() })}
            >
              {withdraw.isPending ? "Submitting…" : "Request withdrawal"}
            </Button>
            {msg && <p className={`text-sm ${msg.ok ? "text-[#74f7b2]" : "text-rose-400"}`}>{msg.text}</p>}
          </div>
        </section>

        <section className="rounded-3xl border border-white/10 bg-[#12142a] p-6">
          <h2 className="text-lg font-bold">Withdrawal history</h2>
          <div className="mt-4 divide-y divide-white/5">
            {(history.data ?? []).length === 0 && (
              <p className="py-4 text-sm text-[#7a8292]">No withdrawals yet.</p>
            )}
            {(history.data ?? []).map((w) => (
              <div key={w.id} className="flex items-center justify-between gap-3 py-3">
                <div>
                  <p className="font-mono font-bold tabular-nums">${Number(w.amount).toFixed(2)}</p>
                  <p className="text-xs text-[#7a8292]">
                    {w.method} · {new Date(w.createdAt).toLocaleDateString()}
                  </p>
                </div>
                {statusBadge(w.status)}
              </div>
            ))}
          </div>
        </section>
      </main>
    </div>
  );
}
