import { Button } from "@/components/ui/button";
import { ScanFace } from "lucide-react";

function getOAuthUrl() {
  const kimiAuthUrl = import.meta.env.VITE_KIMI_AUTH_URL;
  const appID = import.meta.env.VITE_APP_ID;
  const redirectUri = `${window.location.origin}/api/oauth/callback`;
  const state = btoa(redirectUri);

  const url = new URL(`${kimiAuthUrl}/api/oauth/authorize`);
  url.searchParams.set("client_id", appID);
  url.searchParams.set("redirect_uri", redirectUri);
  url.searchParams.set("response_type", "code");
  url.searchParams.set("scope", "profile");
  url.searchParams.set("state", state);

  return url.toString();
}

export default function Login() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-[#0a0a1f] px-4 text-white">
      <div className="w-full max-w-sm rounded-3xl border border-white/10 bg-[#12142a] p-8 text-center">
        <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-[#74f7b2]/10">
          <ScanFace className="h-7 w-7 text-[#74f7b2]" />
        </div>
        <h1 className="mt-4 text-2xl font-extrabold tracking-tight">CaptchaEarn</h1>
        <p className="mt-2 text-sm text-[#7a8292]">
          Solve captchas, watch short ads, earn real cash. Sign up in seconds.
        </p>
        <Button
          className="mt-6 h-12 w-full bg-[#74f7b2] font-bold text-[#01102e] hover:bg-[#8ffcc4]"
          size="lg"
          onClick={() => (window.location.href = getOAuthUrl())}
        >
          Sign up / Log in
        </Button>
        <p className="mt-4 text-xs text-[#7a8292]">Secure one-tap sign-in. No password needed.</p>
      </div>
    </div>
  );
}
