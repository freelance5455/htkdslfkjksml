import { Button } from "@/components/ui/button";

function getOAuthUrl() {
  const kimiAuthUrl = import.meta.env.VITE_KIMI_AUTH_URL;
  const appID = import.meta.env.VITE_APP_ID;
  const redirectUri = `${window.location.origin}/api/oauth/callback`;
  const state = btoa(redirectUri);

  const url = new URL(`${kimiAuthUrl}/api/oauth/authorize`);
  url.searchParams.set("client_id", appID);
  url.searchParams.set("redirect_uri", redirectUri);
  url.searchParams.set("response_type", "code");
  url.searchParams.set("scope", "profile");
  url.searchParams.set("state", state);

  return url.toString();
}

export default function Login() {
  return (
    <div className="flex min-h-[100dvh] items-center justify-center bg-background p-6">
      <div className="flex w-full max-w-sm flex-col items-center gap-6 text-center">
        <svg width="56" height="56" viewBox="0 0 30 30" fill="none" aria-hidden>
          <rect width="30" height="30" rx="8" fill="#de5126" />
          <path
            d="M8 15.5 15 9l7 6.5"
            stroke="#fdfcfa"
            strokeWidth="2.2"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <path
            d="M10 14.5V21h10v-6.5"
            stroke="#fdfcfa"
            strokeWidth="2.2"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <circle cx="15" cy="17.5" r="1.4" fill="#fdfcfa" />
        </svg>
        <div>
          <h1 className="text-2xl font-bold">بيتي — مدير مصاريف البيت</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            سجّل الدخول لتتابع مصاريف بيتك وميزانياتك من أي جهاز.
          </p>
        </div>
        <Button
          className="w-full"
          size="lg"
          onClick={() => {
            window.location.href = getOAuthUrl();
          }}
        >
          تسجيل الدخول بحساب Kimi
        </Button>
      </div>
    </div>
  );
}
