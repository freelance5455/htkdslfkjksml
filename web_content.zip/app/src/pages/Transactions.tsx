import AppLayout from "@/components/AppLayout";
import { MonthSwitcher } from "@/components/MonthSwitcher";
import { TransactionDialog } from "@/components/TransactionDialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { trpc } from "@/providers/trpc";
import {
  CategoryIcon,
  currentMonthKey,
  dayLabel,
  formatAmount,
  type CategoryRow,
  type TransactionRow,
} from "@/lib/finance";
import { Pencil, Plus, Search, Trash2 } from "lucide-react";
import { useMemo, useState } from "react";
import { toast } from "sonner";

type KindFilter = "all" | "expense" | "income";

export default function Transactions() {
  const [month, setMonth] = useState(currentMonthKey());
  const [search, setSearch] = useState("");
  const [kindFilter, setKindFilter] = useState<KindFilter>("all");
  const [categoryFilter, setCategoryFilter] = useState<string>("all");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<TransactionRow | null>(null);
  const [deleting, setDeleting] = useState<TransactionRow | null>(null);

  const utils = trpc.useUtils();
  const txQuery = trpc.finance.transactions.list.useQuery({ monthKey: month });
  const categoriesQuery = trpc.finance.categories.list.useQuery();
  const settingsQuery = trpc.finance.settings.get.useQuery();
  const currency = settingsQuery.data?.currency ?? "SAR";

  const deleteMutation = trpc.finance.transactions.delete.useMutation({
    onSuccess: async () => {
      await utils.finance.transactions.list.invalidate();
      await utils.finance.budgets.list.invalidate();
      toast.success("تم حذف المعاملة");
      setDeleting(null);
    },
    onError: () => toast.error("تعذّر حذف المعاملة"),
  });

  const filtered = useMemo(() => {
    const q = search.trim();
    return (txQuery.data ?? []).filter(t => {
      if (kindFilter !== "all" && t.categoryKind !== kindFilter) return false;
      if (categoryFilter !== "all" && t.categoryId !== Number(categoryFilter))
        return false;
      if (q && !(t.categoryName.includes(q) || (t.note ?? "").includes(q)))
        return false;
      return true;
    });
  }, [txQuery.data, search, kindFilter, categoryFilter]);

  // Group by day, keep chronological order (query is already desc).
  const groups = useMemo(() => {
    const out: { day: string; rows: TransactionRow[]; total: number }[] = [];
    for (const t of filtered) {
      const last = out[out.length - 1];
      if (last && last.day === t.txDate) {
        last.rows.push(t);
        if (t.categoryKind === "expense") last.total -= t.amount;
        else last.total += t.amount;
      } else {
        out.push({
          day: t.txDate,
          rows: [t],
          total: t.categoryKind === "expense" ? -t.amount : t.amount,
        });
      }
    }
    return out;
  }, [filtered]);

  const openAdd = () => {
    setEditing(null);
    setDialogOpen(true);
  };

  return (
    <AppLayout>
      <div className="mx-auto max-w-6xl px-4 py-6 lg:px-8">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <h1 className="text-2xl font-bold">المعاملات</h1>
          <div className="flex items-center gap-3">
            <MonthSwitcher value={month} onChange={setMonth} />
            <Button onClick={openAdd} className="gap-1.5">
              <Plus size={17} />
              <span className="hidden sm:inline">إضافة</span>
            </Button>
          </div>
        </div>

        {/* Filters */}
        <div className="mt-5 flex flex-wrap items-center gap-2">
          <div className="relative min-w-[180px] flex-1 sm:max-w-xs">
            <Search
              size={16}
              className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground"
            />
            <Input
              placeholder="بحث بالاسم أو الملاحظة…"
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="pr-9"
            />
          </div>
          <Select
            value={kindFilter}
            onValueChange={v => setKindFilter(v as KindFilter)}
          >
            <SelectTrigger className="w-[130px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">الكل</SelectItem>
              <SelectItem value="expense">مصاريف</SelectItem>
              <SelectItem value="income">دخل</SelectItem>
            </SelectContent>
          </Select>
          <Select value={categoryFilter} onValueChange={setCategoryFilter}>
            <SelectTrigger className="w-[160px]">
              <SelectValue placeholder="كل الفئات" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">كل الفئات</SelectItem>
              {(categoriesQuery.data ?? []).map(c => (
                <SelectItem key={c.id} value={String(c.id)}>
                  {c.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* List */}
        <div className="mt-5">
          {txQuery.isLoading ? (
            <div className="space-y-3">
              {[...Array(6)].map((_, i) => (
                <Skeleton key={i} className="h-14 w-full" />
              ))}
            </div>
          ) : groups.length === 0 ? (
            <div className="flex flex-col items-center gap-3 rounded-xl border border-dashed p-12 text-center">
              <p className="text-sm text-muted-foreground">
                {txQuery.data?.length
                  ? "لا نتائج مطابقة لبحثك."
                  : "لا توجد معاملات هذا الشهر."}
              </p>
              <Button variant="outline" onClick={openAdd} className="gap-1.5">
                <Plus size={16} />
                إضافة معاملة
              </Button>
            </div>
          ) : (
            groups.map(g => (
              <section key={g.day} className="mb-5">
                <div className="mb-2 flex items-center justify-between px-1">
                  <h2 className="text-sm font-semibold text-muted-foreground">
                    {dayLabel(g.day)}
                  </h2>
                  <span
                    className={`tnum text-xs font-semibold ${
                      g.total >= 0 ? "text-forest" : "text-muted-foreground"
                    }`}
                  >
                    {g.total >= 0 ? "+" : "−"}
                    {formatAmount(Math.abs(g.total), currency)}
                  </span>
                </div>
                <div className="overflow-hidden rounded-xl border bg-card">
                  {g.rows.map((t, i) => (
                    <div
                      key={t.id}
                      className={`flex items-center gap-3 px-4 py-3 ${
                        i > 0 ? "border-t" : ""
                      }`}
                    >
                      <CategoryIcon
                        icon={t.categoryIcon}
                        color={t.categoryColor}
                        size={16}
                      />
                      <div className="min-w-0 flex-1">
                        <div className="truncate text-sm font-medium">
                          {t.categoryName}
                        </div>
                        {t.note && (
                          <div className="truncate text-xs text-muted-foreground">
                            {t.note}
                          </div>
                        )}
                      </div>
                      <span
                        className={`tnum text-sm font-bold ${
                          t.categoryKind === "income" ? "text-forest" : "text-ink"
                        }`}
                      >
                        {t.categoryKind === "income" ? "+" : "−"}
                        {formatAmount(t.amount, currency)}
                      </span>
                      <div className="flex items-center">
                        <button
                          aria-label="تعديل"
                          onClick={() => {
                            setEditing(t);
                            setDialogOpen(true);
                          }}
                          className="flex h-8 w-8 items-center justify-center rounded-lg text-muted-foreground transition-colors hover:bg-muted hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ember"
                        >
                          <Pencil size={15} />
                        </button>
                        <button
                          aria-label="حذف"
                          onClick={() => setDeleting(t)}
                          className="flex h-8 w-8 items-center justify-center rounded-lg text-muted-foreground transition-colors hover:bg-destructive/10 hover:text-destructive focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ember"
                        >
                          <Trash2 size={15} />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </section>
            ))
          )}
        </div>
      </div>

      <TransactionDialog
        open={dialogOpen}
        onOpenChange={open => {
          setDialogOpen(open);
          if (!open) setEditing(null);
        }}
        categories={(categoriesQuery.data ?? []) as CategoryRow[]}
        editing={editing}
      />

      <AlertDialog open={!!deleting} onOpenChange={o => !o && setDeleting(null)}>
        <AlertDialogContent dir="rtl">
          <AlertDialogHeader>
            <AlertDialogTitle>حذف المعاملة؟</AlertDialogTitle>
            <AlertDialogDescription>
              سيتم حذف هذه المعاملة نهائياً ولا يمكن التراجع عن ذلك.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>إلغاء</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deleting && deleteMutation.mutate({ id: deleting.id })}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              حذف
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </AppLayout>
  );
}
