import AppLayout from "@/components/AppLayout";
import { MonthSwitcher } from "@/components/MonthSwitcher";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { trpc } from "@/providers/trpc";
import {
  CategoryIcon,
  currentMonthKey,
  formatAmount,
  parseAmountToMinor,
  type BudgetRow,
  type CategoryRow,
} from "@/lib/finance";
import { Check, Pencil, Plus, Trash2, X } from "lucide-react";
import { useMemo, useState } from "react";
import { toast } from "sonner";

export default function Budgets() {
  const [month, setMonth] = useState(currentMonthKey());
  const utils = trpc.useUtils();

  const txQuery = trpc.finance.transactions.list.useQuery({ monthKey: month });
  const budgetsQuery = trpc.finance.budgets.list.useQuery({ monthKey: month });
  const categoriesQuery = trpc.finance.categories.list.useQuery();
  const settingsQuery = trpc.finance.settings.get.useQuery();
  const currency = settingsQuery.data?.currency ?? "SAR";

  const invalidate = async () => {
    await utils.finance.budgets.list.invalidate();
  };

  const upsertMutation = trpc.finance.budgets.upsert.useMutation({
    onSuccess: async () => {
      await invalidate();
      toast.success("تم حفظ الميزانية");
    },
    onError: () => toast.error("تعذّر حفظ الميزانية"),
  });

  const deleteMutation = trpc.finance.budgets.delete.useMutation({
    onSuccess: async () => {
      await invalidate();
      toast.success("تم حذف الميزانية");
    },
    onError: () => toast.error("تعذّر حذف الميزانية"),
  });

  const expenseCategories = useMemo(
    () => (categoriesQuery.data ?? []).filter(c => c.kind === "expense"),
    [categoriesQuery.data],
  );

  const budgetByCategory = useMemo(() => {
    const m = new Map<number, BudgetRow>();
    for (const b of budgetsQuery.data ?? []) m.set(b.categoryId, b);
    return m;
  }, [budgetsQuery.data]);

  const spentByCategory = useMemo(() => {
    const m = new Map<number, number>();
    for (const t of txQuery.data ?? []) {
      if (t.categoryKind === "expense") {
        m.set(t.categoryId, (m.get(t.categoryId) ?? 0) + t.amount);
      }
    }
    return m;
  }, [txQuery.data]);

  const totalBudget = (budgetsQuery.data ?? []).reduce((s, b) => s + b.amount, 0);
  const totalBudgetedSpent = (budgetsQuery.data ?? []).reduce(
    (s, b) => s + (spentByCategory.get(b.categoryId) ?? 0),
    0,
  );

  return (
    <AppLayout>
      <div className="mx-auto max-w-6xl px-4 py-6 lg:px-8">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold">الميزانيات الشهرية</h1>
            <p className="mt-1 text-sm text-muted-foreground">
              حدّد سقف إنفاق لكل فئة وتابع التزامك به أولاً بأول.
            </p>
          </div>
          <MonthSwitcher value={month} onChange={setMonth} />
        </div>

        {/* Totals */}
        <div className="mt-6 grid gap-3 sm:grid-cols-3">
          <div className="rounded-2xl border bg-card p-5">
            <div className="text-sm text-muted-foreground">إجمالي الميزانيات</div>
            {budgetsQuery.isLoading ? (
              <Skeleton className="mt-3 h-8 w-32" />
            ) : (
              <div className="tnum mt-3 text-2xl font-bold">
                {formatAmount(totalBudget, currency)}
              </div>
            )}
          </div>
          <div className="rounded-2xl border bg-card p-5">
            <div className="text-sm text-muted-foreground">المصروف ضمن الميزانيات</div>
            {txQuery.isLoading ? (
              <Skeleton className="mt-3 h-8 w-32" />
            ) : (
              <div className="tnum mt-3 text-2xl font-bold text-ember">
                {formatAmount(totalBudgetedSpent, currency)}
              </div>
            )}
          </div>
          <div className="rounded-2xl border bg-card p-5">
            <div className="text-sm text-muted-foreground">المتبقي للصرف</div>
            {txQuery.isLoading || budgetsQuery.isLoading ? (
              <Skeleton className="mt-3 h-8 w-32" />
            ) : (
              <div
                className={`tnum mt-3 text-2xl font-bold ${
                  totalBudget - totalBudgetedSpent >= 0 ? "text-forest" : "text-ember"
                }`}
              >
                {formatAmount(totalBudget - totalBudgetedSpent, currency)}
              </div>
            )}
          </div>
        </div>

        {/* Category budget rows */}
        <div className="mt-6">
          {categoriesQuery.isLoading ? (
            <div className="space-y-3">
              {[...Array(5)].map((_, i) => (
                <Skeleton key={i} className="h-20 w-full rounded-xl" />
              ))}
            </div>
          ) : (
            <div className="grid gap-3 md:grid-cols-2">
              {expenseCategories.map(cat => (
                <BudgetRowCard
                  key={cat.id}
                  category={cat}
                  budget={budgetByCategory.get(cat.id)}
                  spent={spentByCategory.get(cat.id) ?? 0}
                  currency={currency}
                  onSave={amount =>
                    upsertMutation.mutate({
                      categoryId: cat.id,
                      monthKey: month,
                      amount,
                    })
                  }
                  onDelete={id => deleteMutation.mutate({ id })}
                  pending={upsertMutation.isPending || deleteMutation.isPending}
                />
              ))}
            </div>
          )}
        </div>
      </div>
    </AppLayout>
  );
}

function BudgetRowCard({
  category,
  budget,
  spent,
  currency,
  onSave,
  onDelete,
  pending,
}: {
  category: CategoryRow;
  budget?: BudgetRow;
  spent: number;
  currency: string;
  onSave: (amountMinor: number) => void;
  onDelete: (budgetId: number) => void;
  pending: boolean;
}) {
  const [editing, setEditing] = useState(false);
  const [text, setText] = useState("");

  const startEdit = () => {
    setText(budget ? (budget.amount / 100).toString() : "");
    setEditing(true);
  };

  const save = () => {
    const amount = parseAmountToMinor(text);
    if (!amount || amount <= 0) {
      toast.error("أدخل مبلغاً صحيحاً أكبر من صفر");
      return;
    }
    onSave(amount);
    setEditing(false);
  };

  const pct = budget && budget.amount > 0 ? (spent / budget.amount) * 100 : 0;
  const barColor = pct > 100 ? "#de5126" : pct > 75 ? "#9b702c" : "#224e37";

  return (
    <div className="rounded-2xl border bg-card p-4">
      <div className="flex items-center gap-3">
        <CategoryIcon icon={category.icon} color={category.color} size={16} />
        <span className="flex-1 text-sm font-semibold">{category.name}</span>
        {editing ? (
          <div className="flex items-center gap-1.5">
            <Input
              autoFocus
              inputMode="decimal"
              value={text}
              onChange={e => setText(e.target.value)}
              onKeyDown={e => {
                if (e.key === "Enter") save();
                if (e.key === "Escape") setEditing(false);
              }}
              placeholder="0.00"
              className="tnum h-9 w-28 text-left"
              dir="ltr"
            />
            <Button
              size="icon"
              aria-label="حفظ الميزانية"
              className="h-9 w-9"
              onClick={save}
              disabled={pending}
            >
              <Check size={16} />
            </Button>
            <Button
              size="icon"
              variant="outline"
              aria-label="إلغاء التعديل"
              className="h-9 w-9"
              onClick={() => setEditing(false)}
            >
              <X size={16} />
            </Button>
          </div>
        ) : budget ? (
          <div className="flex items-center gap-1">
            <span className="tnum text-sm font-semibold">
              {formatAmount(budget.amount, currency)}
            </span>
            <button
              aria-label="تعديل الميزانية"
              onClick={startEdit}
              className="flex h-8 w-8 items-center justify-center rounded-lg text-muted-foreground transition-colors hover:bg-muted hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ember"
            >
              <Pencil size={14} />
            </button>
            <button
              aria-label="حذف الميزانية"
              onClick={() => onDelete(budget.id)}
              disabled={pending}
              className="flex h-8 w-8 items-center justify-center rounded-lg text-muted-foreground transition-colors hover:bg-destructive/10 hover:text-destructive focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ember"
            >
              <Trash2 size={14} />
            </button>
          </div>
        ) : (
          <Button variant="outline" size="sm" onClick={startEdit} className="gap-1">
            <Plus size={14} />
            تعيين ميزانية
          </Button>
        )}
      </div>

      {budget && !editing && (
        <div className="mt-3">
          <div className="mb-1.5 flex flex-wrap items-center justify-between gap-x-2 text-xs text-muted-foreground">
            <span className="tnum whitespace-nowrap">
              {formatAmount(spent, currency)} من {formatAmount(budget.amount, currency)}
            </span>
            <span
              className="tnum font-semibold"
              style={{ color: barColor }}
            >
              {Math.round(pct)}٪
            </span>
          </div>
          <div className="h-2 overflow-hidden rounded-full bg-muted">
            <div
              className="h-full rounded-full transition-all duration-300"
              style={{ width: `${Math.min(pct, 100)}%`, backgroundColor: barColor }}
            />
          </div>
          {pct > 100 && (
            <p className="mt-1.5 text-xs font-medium text-ember">
              تجاوزت الميزانية بمقدار {formatAmount(spent - budget.amount, currency)}
            </p>
          )}
        </div>
      )}
    </div>
  );
}
