export type Profile = {
  phone: string
  name: string
  firstName: string
  initials: string
  relation: string
  color: string
}

export type Task = {
  id: string
  title: string
  start: string
  end?: string
  icon: string
  reminder: boolean
  prayer?: boolean
}

export const family: Profile[] = [
  { phone: '9909020', name: 'Ismail Mohamed', firstName: 'Ismail', initials: 'IM', relation: 'Father', color: '#d8a854' },
  { phone: '9192914', name: 'Aishath Fairooza', firstName: 'Fairooza', initials: 'AF', relation: 'Mother', color: '#68b9a5' },
  { phone: '9506054', name: 'Naailaa Mohamed', firstName: 'Naailaa', initials: 'NM', relation: 'Family member', color: '#d7997e' },
  { phone: '7922464', name: 'Hawwa Nihaaya', firstName: 'Nihaaya', initials: 'HN', relation: 'Family member', color: '#8fa8cf' },
]

export const defaultTasks: Task[] = [
  { id: 'fajr', title: 'Fajr Prayer', start: '05:15', icon: 'mosque', reminder: true, prayer: true },
  { id: 'wake', title: 'Wake Up', start: '08:30', icon: 'sun', reminder: true },
  { id: 'breakfast', title: 'Breakfast', start: '08:45', icon: 'coffee', reminder: true },
  { id: 'ipad-am', title: 'iPad Screen Time', start: '09:00', end: '09:25', icon: 'tablet', reminder: true },
  { id: 'story-am', title: 'Story Time · English / Dhivehi', start: '09:25', end: '09:40', icon: 'book', reminder: true },
  { id: 'craft', title: 'Craft Work', start: '09:45', end: '10:25', icon: 'palette', reminder: true },
  { id: 'quran-class', title: 'Quran Class', start: '10:30', end: '11:00', icon: 'quran', reminder: true },
  { id: 'shower', title: 'Shower for School', start: '11:30', icon: 'shower', reminder: true },
  { id: 'lunch', title: 'Lunch', start: '11:45', icon: 'utensils', reminder: true },
  { id: 'dhuhr', title: 'Dhuhr Prayer', start: '12:15', icon: 'mosque', reminder: true, prayer: true },
  { id: 'school', title: 'School Time', start: '12:30', end: '17:30', icon: 'school', reminder: true },
  { id: 'refresh', title: 'Wash Body & Refresh', start: '17:45', icon: 'droplets', reminder: true },
  { id: 'asr', title: 'Asr Prayer', start: '17:50', icon: 'mosque', reminder: true, prayer: true },
  { id: 'ipad-pm', title: 'iPad Screen Time', start: '18:00', end: '18:35', icon: 'tablet', reminder: true },
  { id: 'story-pm', title: 'Story Time · English / Dhivehi', start: '18:40', end: '18:50', icon: 'book', reminder: true },
  { id: 'maghrib', title: 'Maghrib Prayer', start: '18:55', icon: 'mosque', reminder: true, prayer: true },
  { id: 'homework', title: 'Quran / Homework / Reading', start: '19:10', end: '20:15', icon: 'quran', reminder: true },
  { id: 'isha', title: 'Isha Prayer', start: '19:45', icon: 'mosque', reminder: true, prayer: true },
  { id: 'dinner', title: 'Family Dinner', start: '20:15', end: '20:30', icon: 'utensils', reminder: true },
  { id: 'wudhu', title: 'Wash, Brush & Wudhu', start: '20:50', icon: 'droplets', reminder: true },
  { id: 'sleep', title: 'Sleeping Time & Adhkar', start: '21:00', icon: 'moon', reminder: true },
]

export type Island = { name: string; atoll: string; lat: number; lng: number }
export const islands: Island[] = [
  { name: 'Malé', atoll: 'Kaafu Atoll', lat: 4.1755, lng: 73.5093 },
  { name: 'Hulhumalé', atoll: 'Kaafu Atoll', lat: 4.2106, lng: 73.5406 },
  { name: 'Villingili', atoll: 'Kaafu Atoll', lat: 4.1737, lng: 73.4847 },
  { name: 'Addu City', atoll: 'Seenu Atoll', lat: -0.6301, lng: 73.1583 },
  { name: 'Fuvahmulah', atoll: 'Gnaviyani Atoll', lat: -0.2988, lng: 73.4247 },
  { name: 'Kulhudhuffushi', atoll: 'Haa Dhaalu Atoll', lat: 6.6221, lng: 73.0699 },
  { name: 'Thinadhoo', atoll: 'Gaafu Dhaalu Atoll', lat: 0.5307, lng: 72.9984 },
  { name: 'Naifaru', atoll: 'Lhaviyani Atoll', lat: 5.4444, lng: 73.3658 },
  { name: 'Hinnavaru', atoll: 'Lhaviyani Atoll', lat: 5.4917, lng: 73.4026 },
  { name: 'Eydhafushi', atoll: 'Baa Atoll', lat: 5.1033, lng: 73.0707 },
  { name: 'Dharavandhoo', atoll: 'Baa Atoll', lat: 5.1576, lng: 73.1302 },
  { name: 'Mahibadhoo', atoll: 'Alifu Dhaalu Atoll', lat: 3.7564, lng: 72.9686 },
  { name: 'Rasdhoo', atoll: 'Alifu Alifu Atoll', lat: 4.2636, lng: 72.9914 },
  { name: 'Thulusdhoo', atoll: 'Kaafu Atoll', lat: 4.3733, lng: 73.6500 },
  { name: 'Maafushi', atoll: 'Kaafu Atoll', lat: 3.9400, lng: 73.4900 },
  { name: 'Dhiffushi', atoll: 'Kaafu Atoll', lat: 4.4417, lng: 73.7125 },
  { name: 'Felidhoo', atoll: 'Vaavu Atoll', lat: 3.4716, lng: 73.5469 },
  { name: 'Keyodhoo', atoll: 'Vaavu Atoll', lat: 3.4594, lng: 73.5514 },
  { name: 'Muli', atoll: 'Meemu Atoll', lat: 2.9236, lng: 73.5797 },
  { name: 'Kolhufushi', atoll: 'Meemu Atoll', lat: 2.7731, lng: 73.4269 },
  { name: 'Nilandhoo', atoll: 'Faafu Atoll', lat: 3.0556, lng: 72.8922 },
  { name: 'Magoodhoo', atoll: 'Faafu Atoll', lat: 3.0820, lng: 72.9635 },
  { name: 'Veymandoo', atoll: 'Thaa Atoll', lat: 2.1877, lng: 73.0956 },
  { name: 'Thimarafushi', atoll: 'Thaa Atoll', lat: 2.1978, lng: 73.1525 },
  { name: 'Fonadhoo', atoll: 'Laamu Atoll', lat: 1.8333, lng: 73.5000 },
  { name: 'Gan', atoll: 'Laamu Atoll', lat: 1.9200, lng: 73.5333 },
  { name: 'Kudahuvadhoo', atoll: 'Dhaalu Atoll', lat: 2.6710, lng: 72.8944 },
  { name: 'Meedhoo', atoll: 'Dhaalu Atoll', lat: 2.5968, lng: 72.9216 },
  { name: 'Viligili', atoll: 'Gaafu Alifu Atoll', lat: 0.7586, lng: 73.4330 },
  { name: 'Vilingili', atoll: 'Gaafu Alifu Atoll', lat: 0.7586, lng: 73.4330 },
  { name: 'Kolamaafushi', atoll: 'Gaafu Alifu Atoll', lat: 0.1690, lng: 73.1820 },
  { name: 'Hoandeddhoo', atoll: 'Gaafu Dhaalu Atoll', lat: 0.2386, lng: 73.1220 },
  { name: 'Hithadhoo', atoll: 'Seenu Atoll', lat: -0.6000, lng: 73.0833 },
  { name: 'Maradhoo', atoll: 'Seenu Atoll', lat: -0.6500, lng: 73.1167 },
  { name: 'Ungoofaaru', atoll: 'Raa Atoll', lat: 5.6681, lng: 73.0306 },
  { name: 'Meedhoo', atoll: 'Raa Atoll', lat: 5.4610, lng: 72.9630 },
  { name: 'Manadhoo', atoll: 'Noonu Atoll', lat: 5.7700, lng: 73.4050 },
  { name: 'Velidhoo', atoll: 'Noonu Atoll', lat: 5.9267, lng: 73.4680 },
  { name: 'Nolhivaran', atoll: 'Haa Dhaalu Atoll', lat: 6.6690, lng: 73.0910 },
  { name: 'Hanimaadhoo', atoll: 'Haa Dhaalu Atoll', lat: 6.7570, lng: 73.1690 },
  { name: 'Ihavandhoo', atoll: 'Haa Alifu Atoll', lat: 6.9550, lng: 73.1300 },
  { name: 'Dhidhdhoo', atoll: 'Haa Alifu Atoll', lat: 6.8860, lng: 73.1080 },
  { name: 'Funadhoo', atoll: 'Shaviyani Atoll', lat: 6.1500, lng: 73.2900 },
  { name: 'Milandhoo', atoll: 'Shaviyani Atoll', lat: 6.3500, lng: 73.2200 },
]

export const taskIcons = ['mosque', 'sun', 'coffee', 'tablet', 'book', 'palette', 'quran', 'shower', 'utensils', 'school', 'droplets', 'moon', 'star']
