import { AudioSystem } from "./audio";
import { GAME } from "./config";
import { Input } from "./input";
import { storage } from "./storage";
import { UPGRADES, type UpgradeDef } from "./upgrades";
import type {
  Bullet, Enemy, EnemyKind, FloatText, GameState, HudData, Lightning,
  Particle, Pickup, Player, Shockwave, UpgradeId,
} from "./types";

export interface GameEvents {
  onState: (state: GameState) => void;
  onUpgrades: (options: UpgradeDef[], levels: Record<UpgradeId, number>) => void;
  onHud: (hud: HudData) => void;
  onToast: (title: string, subtitle?: string) => void;
  onMute: (muted: boolean) => void;
  onUpgradesChanged: (levels: Record<UpgradeId, number>) => void;
}

class Rng {
  private state = 0x91e10da5;
  reset(seed: number): void { this.state = seed >>> 0 || 1; }
  next(): number {
    let t = (this.state += 0x6d2b79f5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  }
  range(a: number, b: number): number { return a + (b - a) * this.next(); }
  int(n: number): number { return Math.floor(this.next() * n); }
}

const zeroUpgrades = (): Record<UpgradeId, number> => ({
  split: 0, orbit: 0, chain: 0, missile: 0, nova: 0, overdrive: 0,
  pierce: 0, time: 0, vamp: 0, shield: 0, reactor: 0, magnet: 0,
});

const makePlayer = (): Player => ({
  x: 0, y: 0, vx: 0, vy: 0, r: 15, hp: 100, maxHp: 100, speed: GAME.PLAYER_SPEED,
  fireCd: 0, fireRate: 3.4, bulletSpeed: 590, damage: 28,
  dashCd: 0, dashTime: 0, invuln: 0, shieldCd: 0,
  aim: -Math.PI / 2, shotCount: 0, level: 1, xp: 0, nextXp: 7,
});

export class ChaosGame {
  state: GameState = "title";
  readonly player = makePlayer();
  readonly upgrades = zeroUpgrades();
  readonly enemies: Enemy[] = [];
  readonly bullets: Bullet[] = [];
  readonly particles: Particle[] = [];
  readonly pickups: Pickup[] = [];
  readonly shockwaves: Shockwave[] = [];
  readonly lightning: Lightning[] = [];
  readonly texts: FloatText[] = [];
  readonly stars: { x: number; y: number; size: number; phase: number }[] = [];
  width = 1280;
  height = 720;
  wave = 1;
  waveTime = 0;
  runTime = 0;
  kills = 0;
  score = 0;
  gameTime = 0;
  shake = 0;
  hurtFlash = 0;
  orbAngle = 0;
  boss: Enemy | null = null;
  currentOffers: UpgradeDef[] = [];
  fps = 60;
  activeParticles = 0;
  private rng = new Rng();
  private spawnCd = 0.4;
  private novaCd = 5;
  private hudCd = 0;
  private fpsTime = 0;
  private fpsFrames = 0;
  private chainBuffer: (Enemy | null)[] = new Array(8).fill(null);
  private bestScore = Math.max(0, Number(storage.get("chaos.best", 0)) || 0);

  constructor(private input: Input, private audio: AudioSystem, private events: GameEvents) {
    for (let i = 0; i < GAME.MAX_ENEMIES; i++) this.enemies.push(this.newEnemy());
    for (let i = 0; i < GAME.MAX_BULLETS; i++) this.bullets.push(this.newBullet());
    for (let i = 0; i < GAME.MAX_PARTICLES; i++) this.particles.push({ alive: false, x: 0, y: 0, vx: 0, vy: 0, life: 0, maxLife: 1, size: 2, color: "#fff", drag: 1 });
    for (let i = 0; i < GAME.MAX_PICKUPS; i++) this.pickups.push({ alive: false, x: 0, y: 0, vx: 0, vy: 0, value: 1, life: 0, health: false, phase: 0 });
    for (let i = 0; i < GAME.MAX_SHOCKWAVES; i++) this.shockwaves.push({ alive: false, x: 0, y: 0, r: 0, maxR: 100, life: 0, maxLife: 1, color: "#fff" });
    for (let i = 0; i < GAME.MAX_LIGHTNING; i++) this.lightning.push({ alive: false, x1: 0, y1: 0, x2: 0, y2: 0, life: 0, seed: 0 });
    for (let i = 0; i < GAME.MAX_TEXTS; i++) this.texts.push({ alive: false, x: 0, y: 0, life: 0, text: "", color: "#fff" });
    for (let i = 0; i < 95; i++) this.stars.push({ x: this.rng.next(), y: this.rng.next(), size: this.rng.range(0.5, 1.8), phase: this.rng.range(0, Math.PI * 2) });
    this.player.x = this.width / 2;
    this.player.y = this.height / 2;
  }

  resize(width: number, height: number): void {
    const oldW = this.width, oldH = this.height;
    this.width = Math.max(320, width);
    this.height = Math.max(360, height);
    if (this.state === "title") {
      this.player.x = this.width / 2;
      this.player.y = this.height / 2;
    } else {
      this.player.x = Math.max(24, Math.min(this.width - 24, this.player.x * this.width / oldW));
      this.player.y = Math.max(70, Math.min(this.height - 24, this.player.y * this.height / oldH));
    }
  }

  private newEnemy(): Enemy {
    return { alive: false, kind: "hound", x: 0, y: 0, vx: 0, vy: 0, r: 14, hp: 1, maxHp: 1,
      speed: 70, damage: 10, xp: 1, spawn: 0, hitFlash: 0, attackCd: 0, orbitCd: 0,
      phase: 0, charge: 0, angle: 0, worth: 10 };
  }

  private newBullet(): Bullet {
    return { alive: false, hostile: false, missile: false, x: 0, y: 0, vx: 0, vy: 0,
      r: 4, damage: 1, life: 0, pierce: 0, target: null, lastHit: null, color: "#fff" };
  }

  private setState(state: GameState): void {
    this.state = state;
    this.events.onState(state);
    this.pushHud();
  }

  startRun(): void {
    this.rng.reset((Date.now() ^ 0xc4a05) >>> 0);
    for (const e of this.enemies) e.alive = false;
    for (const b of this.bullets) b.alive = false;
    for (const p of this.particles) p.alive = false;
    for (const p of this.pickups) p.alive = false;
    for (const s of this.shockwaves) s.alive = false;
    for (const l of this.lightning) l.alive = false;
    for (const t of this.texts) t.alive = false;
    Object.assign(this.upgrades, zeroUpgrades());
    Object.assign(this.player, makePlayer());
    this.player.x = this.width / 2;
    this.player.y = this.height / 2;
    this.wave = 1; this.waveTime = 0; this.runTime = 0; this.kills = 0; this.score = 0;
    this.spawnCd = 0.35; this.novaCd = 5; this.boss = null; this.shake = 0; this.hurtFlash = 0;
    this.audio.startMusic();
    this.setState("playing");
    this.events.onUpgradesChanged(this.upgrades);
    this.events.onToast("الموجة الأولى", "تحرّك باستمرار — السلاح يصوّب تلقائيًا");
  }

  toTitle(): void {
    this.setState("title");
    this.player.x = this.width / 2;
    this.player.y = this.height / 2;
  }

  togglePause(): void {
    if (this.state === "playing") this.setState("paused");
    else if (this.state === "paused") this.setState("playing");
  }

  tryDash(): void {
    const p = this.player;
    if (this.state !== "playing" || p.dashCd > 0 || p.dashTime > 0) return;
    let dx = this.input.moveX, dy = -this.input.moveZ;
    const len = Math.hypot(dx, dy);
    if (len < 0.1) { dx = Math.cos(p.aim); dy = Math.sin(p.aim); }
    else { dx /= len; dy /= len; }
    p.vx = dx * GAME.DASH_SPEED; p.vy = dy * GAME.DASH_SPEED;
    p.dashTime = GAME.DASH_DURATION; p.dashCd = GAME.DASH_COOLDOWN; p.invuln = Math.max(p.invuln, 0.34);
    this.addShockwave(p.x, p.y, 58, GAME.COLORS.cyan, 0.25);
    this.burst(p.x, p.y, GAME.COLORS.cyan, 12, 170);
    this.audio.sfx("move");
  }

  update(dt: number): void {
    this.gameTime += dt;
    if (this.input.consumeAction("KeyM")) this.events.onMute(this.audio.toggleMute());
    if (this.state === "title") {
      if (this.input.consumeAction("Space") || this.input.consumeAction("Enter")) this.startRun();
      this.updateEffects(dt);
      return;
    }
    if (this.state === "playing") {
      if (this.input.consumeAction("Escape") || this.input.consumeAction("KeyP")) { this.togglePause(); return; }
      if (this.input.consumeAction("Space")) this.tryDash();
      this.updatePlaying(dt);
      return;
    }
    if (this.state === "paused") {
      if (this.input.consumeAction("Escape") || this.input.consumeAction("KeyP") || this.input.consumeAction("Space")) this.togglePause();
      return;
    }
    if (this.state === "levelup") {
      if (this.input.consumeAction("Digit1")) this.chooseUpgrade(0);
      else if (this.input.consumeAction("Digit2")) this.chooseUpgrade(1);
      else if (this.input.consumeAction("Digit3")) this.chooseUpgrade(2);
      return;
    }
    if (this.state === "gameover" || this.state === "victory") {
      if (this.input.consumeAction("Space") || this.input.consumeAction("Enter")) this.startRun();
      else if (this.input.consumeAction("Escape")) this.toTitle();
    }
  }

  private updatePlaying(dt: number): void {
    const p = this.player;
    this.runTime += dt; this.waveTime += dt;
    p.fireCd -= dt; p.dashCd = Math.max(0, p.dashCd - dt); p.invuln = Math.max(0, p.invuln - dt);
    p.shieldCd = Math.max(0, p.shieldCd - dt); this.shake = Math.max(0, this.shake - dt * 20);
    this.hurtFlash = Math.max(0, this.hurtFlash - dt * 2.8);
    this.orbAngle += dt * (2.8 + this.upgrades.orbit * 0.35);

    let mx = this.input.moveX, my = -this.input.moveZ;
    const ml = Math.hypot(mx, my);
    if (ml > 1) { mx /= ml; my /= ml; }
    if (p.dashTime > 0) {
      p.dashTime -= dt;
      if (this.rng.next() < 0.65) this.addParticle(p.x, p.y, -p.vx * 0.08, -p.vy * 0.08, 0.25, 8, GAME.COLORS.cyan, 0.9);
    } else {
      const speed = p.speed * (1 + this.upgrades.magnet * 0.07);
      const responsiveness = 1 - Math.exp(-dt * 18);
      p.vx += (mx * speed - p.vx) * responsiveness;
      p.vy += (my * speed - p.vy) * responsiveness;
    }
    p.x = Math.max(22, Math.min(this.width - 22, p.x + p.vx * dt));
    p.y = Math.max(72, Math.min(this.height - 22, p.y + p.vy * dt));

    const target = this.nearestEnemy(p.x, p.y, 900);
    if (target) {
      p.aim = Math.atan2(target.y - p.y, target.x - p.x);
      if (p.fireCd <= 0) {
        this.fireWeapon(target);
        p.fireCd = 1 / p.fireRate;
      }
    } else if (ml > 0.1) p.aim = Math.atan2(my, mx);

    if (this.wave < GAME.FINAL_WAVE && this.waveTime >= GAME.WAVE_DURATION) {
      this.wave++; this.waveTime = 0;
      this.events.onToast(`الموجة ${this.arabicWave(this.wave)}`, this.wave === GAME.FINAL_WAVE ? "الزعيم يقترب — لا تتوقف عن الحركة" : "وحوش أسرع وأشرس من كل الاتجاهات");
      this.audio.sfx("ui");
      if (this.wave === GAME.FINAL_WAVE) this.spawnBoss();
    }

    this.spawnCd -= dt;
    const activeCap = Math.min(GAME.MAX_ENEMIES - 8, 18 + this.wave * 15);
    if (this.spawnCd <= 0 && this.countEnemies() < activeCap) {
      this.spawnEnemy(this.pickEnemyKind());
      if (this.wave >= 3 && this.rng.next() < 0.22) this.spawnEnemy(this.pickEnemyKind());
      this.spawnCd = Math.max(0.19, 0.82 - this.wave * 0.105) * this.rng.range(0.78, 1.2);
    }

    this.updateEnemies(dt);
    this.updateBullets(dt);
    this.updatePickups(dt);
    this.updateOrbitals(dt);
    this.updateNova(dt);
    this.updateEffects(dt);

    if (p.hp <= 0) { this.endRun(false); return; }
    this.checkLevelUp();
    this.hudCd -= dt;
    if (this.hudCd <= 0) { this.pushHud(); this.hudCd = 0.08; }
  }

  private arabicWave(wave: number): string {
    return ["الأولى", "الثانية", "الثالثة", "الرابعة", "الأخيرة"][wave - 1] ?? String(wave);
  }

  private pickEnemyKind(): EnemyKind {
    const r = this.rng.next();
    if (this.wave === 1) return r < 0.72 ? "hound" : "wisp";
    if (this.wave === 2) return r < 0.48 ? "hound" : r < 0.75 ? "wisp" : "splitter";
    if (this.wave === 3) return r < 0.32 ? "hound" : r < 0.53 ? "wisp" : r < 0.72 ? "splitter" : r < 0.87 ? "spitter" : "brute";
    return r < 0.24 ? "hound" : r < 0.43 ? "wisp" : r < 0.62 ? "splitter" : r < 0.81 ? "spitter" : "brute";
  }

  private spawnEnemy(kind: EnemyKind, atX?: number, atY?: number): Enemy | null {
    let e: Enemy | null = null;
    for (const candidate of this.enemies) if (!candidate.alive) { e = candidate; break; }
    if (!e) return null;
    let x = atX ?? 0, y = atY ?? 0;
    if (atX === undefined || atY === undefined) {
      const side = this.rng.int(4), pad = 36;
      if (side === 0) { x = this.rng.range(20, this.width - 20); y = -pad; }
      else if (side === 1) { x = this.width + pad; y = this.rng.range(75, this.height - 20); }
      else if (side === 2) { x = this.rng.range(20, this.width - 20); y = this.height + pad; }
      else { x = -pad; y = this.rng.range(75, this.height - 20); }
    }
    const scale = 1 + (this.wave - 1) * 0.17;
    e.alive = true; e.kind = kind; e.x = x; e.y = y; e.vx = 0; e.vy = 0; e.spawn = kind === "boss" ? 1.5 : 0.62;
    e.hitFlash = 0; e.attackCd = this.rng.range(0.8, 1.8); e.orbitCd = 0; e.phase = this.rng.range(0, Math.PI * 2);
    e.charge = 0; e.angle = 0;
    if (kind === "hound") { e.r = 13; e.maxHp = 28 * scale; e.speed = 92 + this.wave * 5; e.damage = 10; e.xp = 1; e.worth = 20; }
    else if (kind === "wisp") { e.r = 11; e.maxHp = 23 * scale; e.speed = 118 + this.wave * 5; e.damage = 8; e.xp = 1; e.worth = 25; }
    else if (kind === "splitter") { e.r = 20; e.maxHp = 72 * scale; e.speed = 62; e.damage = 14; e.xp = 3; e.worth = 55; }
    else if (kind === "spitter") { e.r = 16; e.maxHp = 60 * scale; e.speed = 58; e.damage = 10; e.xp = 3; e.worth = 65; }
    else if (kind === "brute") { e.r = 27; e.maxHp = 180 * scale; e.speed = 42; e.damage = 22; e.xp = 5; e.worth = 110; }
    else { e.r = 54; e.maxHp = 1850; e.speed = 40; e.damage = 28; e.xp = 30; e.worth = 2500; }
    e.hp = e.maxHp;
    return e;
  }

  private spawnBoss(): void {
    this.boss = this.spawnEnemy("boss", this.width / 2, -65);
    this.addShockwave(this.width / 2, 60, 180, GAME.COLORS.pink, 0.8);
  }

  private nearestEnemy(x: number, y: number, maxDist: number): Enemy | null {
    let best: Enemy | null = null, bestD = maxDist * maxDist;
    for (const e of this.enemies) {
      if (!e.alive || e.spawn > 0) continue;
      const d = (e.x - x) ** 2 + (e.y - y) ** 2;
      if (d < bestD) { bestD = d; best = e; }
    }
    return best;
  }

  private countEnemies(): number {
    let n = 0;
    for (const e of this.enemies) if (e.alive) n++;
    return n;
  }

  private updateEnemies(dt: number): void {
    const p = this.player;
    for (const e of this.enemies) {
      if (!e.alive) continue;
      e.hitFlash = Math.max(0, e.hitFlash - dt * 7);
      e.orbitCd = Math.max(0, e.orbitCd - dt);
      e.attackCd -= dt;
      if (e.spawn > 0) { e.spawn -= dt; continue; }
      let dx = p.x - e.x, dy = p.y - e.y;
      const dist = Math.max(0.001, Math.hypot(dx, dy));
      dx /= dist; dy /= dist;
      let slow = 1;
      if (this.upgrades.time > 0 && dist < 175 + this.upgrades.time * 15) slow = Math.max(0.32, 0.65 - this.upgrades.time * 0.07);
      e.phase += dt * 4;

      if (e.kind === "wisp") {
        const sway = Math.sin(e.phase) * 0.78;
        e.vx = (dx - dy * sway) * e.speed * slow;
        e.vy = (dy + dx * sway) * e.speed * slow;
      } else if (e.kind === "spitter") {
        const direction = dist > 285 ? 1 : dist < 185 ? -0.8 : 0;
        e.vx = dx * e.speed * direction * slow; e.vy = dy * e.speed * direction * slow;
        if (e.attackCd <= 0 && dist < 560) {
          this.fireHostile(e.x, e.y, Math.atan2(dy, dx), 195, 12);
          e.attackCd = Math.max(0.85, 1.8 - this.wave * 0.1);
        }
      } else if (e.kind === "brute") {
        if (e.charge > 0) {
          e.charge -= dt;
          if (e.charge < 0.42) { e.vx = Math.cos(e.angle) * 360 * slow; e.vy = Math.sin(e.angle) * 360 * slow; }
          else { e.vx *= 0.85; e.vy *= 0.85; }
        } else {
          e.vx = dx * e.speed * slow; e.vy = dy * e.speed * slow;
          if (e.attackCd <= 0 && dist < 360) { e.charge = 0.82; e.angle = Math.atan2(dy, dx); e.attackCd = 3.4; }
        }
      } else if (e.kind === "boss") {
        const direction = dist > 265 ? 1 : dist < 175 ? -0.5 : 0;
        e.vx = dx * e.speed * direction; e.vy = dy * e.speed * direction;
        if (e.attackCd <= 0) {
          const base = Math.atan2(dy, dx);
          for (let i = -2; i <= 2; i++) this.fireHostile(e.x, e.y, base + i * 0.19, 230, 14);
          const radial = 12;
          for (let i = 0; i < radial; i++) this.fireHostile(e.x, e.y, e.phase + i * Math.PI * 2 / radial, 145, 11);
          e.attackCd = 2.25;
          this.addShockwave(e.x, e.y, 110, GAME.COLORS.pink, 0.45);
          this.shake = Math.max(this.shake, 4);
        }
        if (Math.floor(this.runTime) % 7 === 0 && this.rng.next() < dt * 1.5) this.spawnEnemy("hound");
      } else {
        e.vx = dx * e.speed * slow; e.vy = dy * e.speed * slow;
      }
      e.x += e.vx * dt; e.y += e.vy * dt;

      const hitDist = p.r + e.r;
      if (dist < hitDist) {
        if (p.dashTime > 0) {
          this.damageEnemy(e, 55 + this.upgrades.pierce * 15, false);
          p.vx *= 0.96; p.vy *= 0.96;
        } else if (p.invuln <= 0) {
          this.damagePlayer(e.damage);
          p.vx = dx * 230; p.vy = dy * 230;
          e.vx = -dx * 140; e.vy = -dy * 140;
        }
      }
    }
  }

  private fireWeapon(target: Enemy): void {
    const p = this.player;
    const count = 1 + this.upgrades.split * 2;
    const spread = Math.min(0.72, 0.13 * (count - 1));
    for (let i = 0; i < count; i++) {
      const offset = count === 1 ? 0 : -spread / 2 + spread * i / (count - 1);
      this.firePlayer(p.aim + offset, p.damage, false);
    }
    p.shotCount++;
    if (this.upgrades.missile > 0 && p.shotCount % Math.max(2, 6 - this.upgrades.missile) === 0) {
      const b = this.firePlayer(p.aim - 0.5, p.damage * (1.3 + this.upgrades.missile * 0.35), true);
      if (b) b.target = target;
    }
    this.addParticle(p.x + Math.cos(p.aim) * 21, p.y + Math.sin(p.aim) * 21, Math.cos(p.aim) * 45, Math.sin(p.aim) * 45, 0.12, 8, GAME.COLORS.gold, 0.85);
    this.audio.sfx("move");
  }

  private firePlayer(angle: number, damage: number, missile: boolean): Bullet | null {
    const p = this.player;
    const b = this.obtainBullet();
    if (!b) return null;
    b.hostile = false; b.missile = missile; b.x = p.x + Math.cos(angle) * 22; b.y = p.y + Math.sin(angle) * 22;
    const speed = missile ? 390 : p.bulletSpeed;
    b.vx = Math.cos(angle) * speed; b.vy = Math.sin(angle) * speed;
    b.r = missile ? 7 : 4; b.damage = damage; b.life = missile ? 3.5 : 1.65;
    b.pierce = missile ? 0 : this.upgrades.pierce; b.target = null; b.lastHit = null;
    b.color = missile ? GAME.COLORS.orange : GAME.COLORS.cyan;
    return b;
  }

  private fireHostile(x: number, y: number, angle: number, speed: number, damage: number): void {
    const b = this.obtainBullet();
    if (!b) return;
    b.hostile = true; b.missile = false; b.x = x; b.y = y;
    b.vx = Math.cos(angle) * speed; b.vy = Math.sin(angle) * speed;
    b.r = 6; b.damage = damage; b.life = 5; b.pierce = 0; b.target = null; b.lastHit = null; b.color = GAME.COLORS.pink;
  }

  private obtainBullet(): Bullet | null {
    for (const b of this.bullets) if (!b.alive) { b.alive = true; return b; }
    return null;
  }

  private updateBullets(dt: number): void {
    const p = this.player;
    for (const b of this.bullets) {
      if (!b.alive) continue;
      b.life -= dt;
      if (b.life <= 0) { b.alive = false; continue; }
      if (b.missile) {
        if (!b.target?.alive) b.target = this.nearestEnemy(b.x, b.y, 700);
        if (b.target) {
          const desired = Math.atan2(b.target.y - b.y, b.target.x - b.x);
          const current = Math.atan2(b.vy, b.vx);
          let diff = ((desired - current + Math.PI * 3) % (Math.PI * 2)) - Math.PI;
          const angle = current + Math.max(-4.8 * dt, Math.min(4.8 * dt, diff));
          const speed = Math.min(610, Math.hypot(b.vx, b.vy) + 230 * dt);
          b.vx = Math.cos(angle) * speed; b.vy = Math.sin(angle) * speed;
        }
        if (this.rng.next() < 0.5) this.addParticle(b.x, b.y, -b.vx * 0.05, -b.vy * 0.05, 0.2, 5, GAME.COLORS.orange, 0.9);
      }
      b.x += b.vx * dt; b.y += b.vy * dt;
      if (b.x < -90 || b.x > this.width + 90 || b.y < -90 || b.y > this.height + 90) { b.alive = false; continue; }
      if (b.hostile) {
        const d = Math.hypot(b.x - p.x, b.y - p.y);
        if (p.dashTime > 0 && d < 62) { b.alive = false; this.burst(b.x, b.y, GAME.COLORS.cyan, 3, 70); continue; }
        if (d < p.r + b.r && p.invuln <= 0) { b.alive = false; this.damagePlayer(b.damage); }
        continue;
      }
      for (const e of this.enemies) {
        if (!e.alive || e.spawn > 0 || e === b.lastHit) continue;
        if (Math.abs(e.x - b.x) > e.r + b.r || Math.abs(e.y - b.y) > e.r + b.r) continue;
        if ((e.x - b.x) ** 2 + (e.y - b.y) ** 2 > (e.r + b.r) ** 2) continue;
        b.lastHit = e;
        this.damageEnemy(e, b.damage, true);
        if (this.upgrades.chain > 0 && this.rng.next() < 0.3 + this.upgrades.chain * 0.12) this.chainFrom(e, b.damage);
        if (b.missile) {
          this.explode(b.x, b.y, 88 + this.upgrades.missile * 15, b.damage * 0.8, GAME.COLORS.orange);
          b.alive = false; break;
        }
        if (b.pierce > 0) { b.pierce--; b.x += b.vx * 0.018; b.y += b.vy * 0.018; }
        else { b.alive = false; break; }
      }
    }
  }

  private chainFrom(source: Enemy, damage: number): void {
    const jumps = 1 + this.upgrades.chain;
    this.chainBuffer[0] = source;
    let current = source;
    for (let j = 1; j <= jumps; j++) {
      let best: Enemy | null = null, bestD = (155 + this.upgrades.chain * 20) ** 2;
      for (const e of this.enemies) {
        if (!e.alive || e.spawn > 0) continue;
        let used = false;
        for (let k = 0; k < j; k++) if (this.chainBuffer[k] === e) { used = true; break; }
        if (used) continue;
        const d = (e.x - current.x) ** 2 + (e.y - current.y) ** 2;
        if (d < bestD) { bestD = d; best = e; }
      }
      if (!best) break;
      this.chainBuffer[j] = best;
      this.addLightning(current.x, current.y, best.x, best.y);
      this.damageEnemy(best, damage * 0.48, false);
      current = best;
    }
  }

  private updateOrbitals(_dt: number): void {
    const level = this.upgrades.orbit;
    if (!level) return;
    const count = level * 2, radius = 58 + level * 9;
    for (let i = 0; i < count; i++) {
      const a = this.orbAngle + i * Math.PI * 2 / count;
      const x = this.player.x + Math.cos(a) * radius, y = this.player.y + Math.sin(a) * radius;
      for (const e of this.enemies) {
        if (!e.alive || e.spawn > 0 || e.orbitCd > 0) continue;
        if ((e.x - x) ** 2 + (e.y - y) ** 2 < (e.r + 12) ** 2) {
          e.orbitCd = 0.22;
          this.damageEnemy(e, 16 + level * 10, false);
        }
      }
    }
  }

  private updateNova(dt: number): void {
    const level = this.upgrades.nova;
    if (!level) return;
    this.novaCd -= dt;
    if (this.novaCd > 0) return;
    this.novaCd = Math.max(2.8, 6.2 - level * 0.8);
    const radius = 170 + level * 28;
    this.addShockwave(this.player.x, this.player.y, radius, GAME.COLORS.purple, 0.55);
    for (const e of this.enemies) {
      if (!e.alive || e.spawn > 0) continue;
      if ((e.x - this.player.x) ** 2 + (e.y - this.player.y) ** 2 < (radius + e.r) ** 2) this.damageEnemy(e, 28 + level * 20, false);
    }
    for (const b of this.bullets) if (b.alive && b.hostile && Math.hypot(b.x - this.player.x, b.y - this.player.y) < radius) b.alive = false;
    this.shake = Math.max(this.shake, 5);
    this.audio.sfx("explosion");
  }

  private damageEnemy(e: Enemy, amount: number, impact: boolean): void {
    if (!e.alive) return;
    e.hp -= amount; e.hitFlash = 1;
    if (impact) this.burst(e.x, e.y, GAME.COLORS.white, 2, 65);
    if (e.hp > 0) return;
    e.alive = false;
    this.kills++; this.score += e.worth * this.wave;
    this.burst(e.x, e.y, this.enemyColor(e.kind), e.kind === "boss" ? 45 : e.kind === "brute" ? 18 : 8, e.kind === "boss" ? 290 : 150);
    this.dropPickup(e.x, e.y, e.xp, false);
    if (this.rng.next() < 0.025 && e.kind !== "boss") this.dropPickup(e.x + 8, e.y, 18, true);
    if (this.upgrades.vamp > 0 && this.rng.next() < 0.08 + this.upgrades.vamp * 0.035) {
      this.player.hp = Math.min(this.player.maxHp, this.player.hp + 2 + this.upgrades.vamp * 2);
    }
    if (this.upgrades.reactor > 0 && e.kind !== "boss") this.explode(e.x, e.y, 68 + this.upgrades.reactor * 18, 14 + this.upgrades.reactor * 14, GAME.COLORS.orange);
    if (e.kind === "splitter") {
      for (let i = 0; i < 2; i++) {
        const child = this.spawnEnemy("hound", e.x + (i ? 16 : -16), e.y);
        if (child) { child.spawn = 0.18; child.hp *= 0.62; child.maxHp = child.hp; child.r = 10; }
      }
    }
    if (e.kind === "brute" || e.kind === "boss") this.audio.sfx("explosion");
    if (e.kind === "boss") { this.boss = null; this.addShockwave(e.x, e.y, 360, GAME.COLORS.gold, 1); this.endRun(true); }
  }

  private explode(x: number, y: number, radius: number, damage: number, color: string): void {
    this.addShockwave(x, y, radius, color, 0.36);
    this.burst(x, y, color, 12, 210);
    for (const e of this.enemies) {
      if (!e.alive || e.spawn > 0) continue;
      const d = Math.hypot(e.x - x, e.y - y);
      if (d < radius + e.r) this.damageEnemy(e, damage * (1 - Math.min(0.55, d / radius * 0.45)), false);
    }
    this.shake = Math.max(this.shake, 3);
  }

  private damagePlayer(amount: number): void {
    const p = this.player;
    if (p.invuln > 0 || this.state !== "playing") return;
    if (this.upgrades.shield > 0 && p.shieldCd <= 0) {
      p.shieldCd = Math.max(5.5, 12 - this.upgrades.shield * 1.7); p.invuln = 0.45;
      this.addShockwave(p.x, p.y, 80, GAME.COLORS.blue, 0.35);
      this.events.onToast("الدرع امتص الضربة", "استغل المناعة القصيرة لإعادة التموضع");
      this.audio.sfx("pickup");
      return;
    }
    p.hp -= amount; p.invuln = GAME.CONTACT_INVULN; this.hurtFlash = 0.72; this.shake = Math.max(this.shake, 9);
    this.burst(p.x, p.y, GAME.COLORS.red, 16, 220);
    this.audio.sfx("hit");
    this.pushHud();
  }

  private dropPickup(x: number, y: number, value: number, health: boolean): void {
    for (const p of this.pickups) if (!p.alive) {
      p.alive = true; p.x = x; p.y = y; p.vx = this.rng.range(-55, 55); p.vy = this.rng.range(-55, 55);
      p.value = value; p.health = health; p.life = 18; p.phase = this.rng.range(0, 6.28); return;
    }
  }

  private updatePickups(dt: number): void {
    const p = this.player;
    const magnet = 115 + this.upgrades.magnet * 75;
    for (const item of this.pickups) {
      if (!item.alive) continue;
      item.life -= dt; item.phase += dt * 4;
      if (item.life <= 0) { item.alive = false; continue; }
      const dx = p.x - item.x, dy = p.y - item.y, d = Math.max(1, Math.hypot(dx, dy));
      if (d < magnet) {
        const pull = 250 + (magnet - d) * 5;
        item.vx += dx / d * pull * dt; item.vy += dy / d * pull * dt;
      }
      item.vx *= Math.pow(0.15, dt); item.vy *= Math.pow(0.15, dt);
      item.x += item.vx * dt; item.y += item.vy * dt;
      if (d < p.r + 11) {
        item.alive = false;
        if (item.health) p.hp = Math.min(p.maxHp, p.hp + item.value);
        else { p.xp += item.value; this.score += item.value * 3; }
        this.burst(item.x, item.y, item.health ? GAME.COLORS.green : GAME.COLORS.xp, 4, 90);
      }
    }
  }

  private checkLevelUp(): void {
    const p = this.player;
    if (p.xp < p.nextXp || this.state !== "playing") return;
    p.xp -= p.nextXp; p.level++; p.nextXp = Math.floor(7 + p.level * 4.4 + p.level * p.level * 0.32);
    this.currentOffers = this.rollUpgrades();
    if (this.currentOffers.length === 0) { p.hp = Math.min(p.maxHp, p.hp + 30); this.score += 500; return; }
    this.setState("levelup");
    this.events.onUpgrades(this.currentOffers, this.upgrades);
    this.audio.sfx("pickup");
  }

  private rollUpgrades(): UpgradeDef[] {
    const available = UPGRADES.filter((u) => this.upgrades[u.id] < u.max);
    const result: UpgradeDef[] = [];
    while (result.length < 3 && available.length > 0) {
      const index = this.rng.int(available.length);
      result.push(available[index]);
      available.splice(index, 1);
    }
    return result;
  }

  chooseUpgrade(index: number): void {
    if (this.state !== "levelup") return;
    const upgrade = this.currentOffers[index];
    if (!upgrade) return;
    const id = upgrade.id;
    this.upgrades[id]++;
    const p = this.player;
    if (id === "overdrive") { p.fireRate *= 1.55; p.bulletSpeed *= 1.16; }
    else if (id === "pierce") p.damage *= 1.65;
    else if (id === "vamp") { p.maxHp += 24; p.hp = Math.min(p.maxHp, p.hp + 35); }
    else if (id === "shield") p.shieldCd = 0;
    this.events.onUpgradesChanged(this.upgrades);
    this.events.onToast(upgrade.name, `وصلت الترقية إلى المستوى ${this.upgrades[id]}`);
    this.addShockwave(p.x, p.y, 130, upgrade.color, 0.5);
    this.burst(p.x, p.y, upgrade.color, 20, 190);
    this.audio.sfx("win");
    this.setState("playing");
    if (p.xp >= p.nextXp) this.checkLevelUp();
  }

  private endRun(victory: boolean): void {
    if (this.state !== "playing") return;
    this.bestScore = Math.max(this.bestScore, this.score);
    storage.set("chaos.best", this.bestScore);
    storage.set("chaos.bestWave", Math.max(this.wave, Number(storage.get("chaos.bestWave", 0)) || 0));
    if (victory) storage.set("chaos.wins", (Number(storage.get("chaos.wins", 0)) || 0) + 1);
    this.setState(victory ? "victory" : "gameover");
    this.audio.sfx(victory ? "win" : "lose");
  }

  getBestScore(): number { return this.bestScore; }

  pushHud(): void {
    this.events.onHud({
      hp: Math.max(0, this.player.hp), maxHp: this.player.maxHp, level: this.player.level,
      xp: this.player.xp, nextXp: this.player.nextXp, wave: this.wave,
      waveTime: this.waveTime, kills: this.kills, score: this.score,
      dash: this.player.dashCd / GAME.DASH_COOLDOWN,
      bossHp: this.boss?.alive ? Math.max(0, this.boss.hp) : 0,
      bossMaxHp: this.boss?.alive ? this.boss.maxHp : 0,
      state: this.state,
    });
  }

  private addParticle(x: number, y: number, vx: number, vy: number, life: number, size: number, color: string, drag: number): void {
    for (const p of this.particles) if (!p.alive) {
      p.alive = true; p.x = x; p.y = y; p.vx = vx; p.vy = vy;
      p.life = life; p.maxLife = life; p.size = size; p.color = color; p.drag = drag; return;
    }
  }

  private burst(x: number, y: number, color: string, count: number, speed: number): void {
    for (let i = 0; i < count; i++) {
      const a = this.rng.range(0, Math.PI * 2), s = this.rng.range(speed * 0.25, speed);
      this.addParticle(x, y, Math.cos(a) * s, Math.sin(a) * s, this.rng.range(0.18, 0.52), this.rng.range(2, 6), color, 0.055);
    }
  }

  private addShockwave(x: number, y: number, maxR: number, color: string, life: number): void {
    for (const s of this.shockwaves) if (!s.alive) {
      s.alive = true; s.x = x; s.y = y; s.r = 8; s.maxR = maxR; s.life = life; s.maxLife = life; s.color = color; return;
    }
  }

  private addLightning(x1: number, y1: number, x2: number, y2: number): void {
    for (const l of this.lightning) if (!l.alive) {
      l.alive = true; l.x1 = x1; l.y1 = y1; l.x2 = x2; l.y2 = y2; l.life = 0.16; l.seed = this.rng.range(0, 100); return;
    }
  }

  private updateEffects(dt: number): void {
    this.activeParticles = 0;
    for (const p of this.particles) {
      if (!p.alive) continue;
      p.life -= dt;
      if (p.life <= 0) { p.alive = false; continue; }
      p.vx *= Math.pow(p.drag, dt); p.vy *= Math.pow(p.drag, dt);
      p.x += p.vx * dt; p.y += p.vy * dt; this.activeParticles++;
    }
    for (const s of this.shockwaves) {
      if (!s.alive) continue;
      s.life -= dt;
      if (s.life <= 0) { s.alive = false; continue; }
      const t = 1 - s.life / s.maxLife;
      s.r = 8 + (s.maxR - 8) * (1 - (1 - t) ** 3);
    }
    for (const l of this.lightning) { if (l.alive) { l.life -= dt; if (l.life <= 0) l.alive = false; } }
    for (const t of this.texts) { if (t.alive) { t.life -= dt; t.y -= 25 * dt; if (t.life <= 0) t.alive = false; } }
  }

  render(ctx: CanvasRenderingContext2D): void {
    const now = performance.now();
    if (this.lastRenderTime > 0) {
      this.fpsTime += (now - this.lastRenderTime) / 1000; this.fpsFrames++;
      if (this.fpsTime >= 1) { this.fps = Math.round(this.fpsFrames / this.fpsTime); this.fpsTime = 0; this.fpsFrames = 0; }
    }
    this.lastRenderTime = now;
    ctx.clearRect(0, 0, this.width, this.height);
    ctx.fillStyle = GAME.COLORS.bg; ctx.fillRect(0, 0, this.width, this.height);
    this.drawBackground(ctx);
    if (this.state === "title" && this.width > 650) this.drawTitleArt(ctx);
    ctx.save();
    if (this.shake > 0) ctx.translate(Math.sin(this.gameTime * 83) * this.shake, Math.cos(this.gameTime * 71) * this.shake * 0.65);
    if (this.upgrades.time > 0 && this.state !== "title") this.drawTimeField(ctx);
    this.drawPickups(ctx);
    this.drawShockwaves(ctx);
    this.drawEnemies(ctx);
    this.drawBullets(ctx);
    if (this.state !== "title") this.drawPlayer(ctx);
    this.drawParticles(ctx);
    this.drawLightning(ctx);
    ctx.restore();
    if (this.hurtFlash > 0) {
      ctx.fillStyle = `rgba(255,45,80,${this.hurtFlash * 0.18})`;
      ctx.fillRect(0, 0, this.width, this.height);
      ctx.strokeStyle = `rgba(255,70,95,${this.hurtFlash * 0.8})`; ctx.lineWidth = 10;
      ctx.strokeRect(3, 3, this.width - 6, this.height - 6);
    }
  }

  private lastRenderTime = 0;

  private drawBackground(ctx: CanvasRenderingContext2D): void {
    const grid = 64, offset = (this.gameTime * 4) % grid;
    ctx.strokeStyle = "rgba(63,93,137,0.13)"; ctx.lineWidth = 1; ctx.beginPath();
    for (let x = -grid + offset; x < this.width + grid; x += grid) { ctx.moveTo(x, 0); ctx.lineTo(x, this.height); }
    for (let y = -grid + offset; y < this.height + grid; y += grid) { ctx.moveTo(0, y); ctx.lineTo(this.width, y); }
    ctx.stroke();
    ctx.fillStyle = GAME.COLORS.blue;
    for (const s of this.stars) {
      const alpha = 0.1 + (Math.sin(this.gameTime * 0.8 + s.phase) + 1) * 0.09;
      ctx.globalAlpha = alpha; ctx.fillRect(s.x * this.width, s.y * this.height, s.size, s.size);
    }
    ctx.globalAlpha = 1;
    const cx = this.width / 2, cy = this.height / 2;
    ctx.strokeStyle = "rgba(85,246,210,0.055)"; ctx.lineWidth = 1;
    for (let r = 120; r < Math.max(this.width, this.height) * 0.7; r += 120) {
      ctx.beginPath(); ctx.arc(cx, cy, r + Math.sin(this.gameTime * 0.35 + r) * 4, 0, Math.PI * 2); ctx.stroke();
    }
    ctx.strokeStyle = "rgba(98,168,255,0.2)"; ctx.lineWidth = 2; ctx.strokeRect(10, 10, this.width - 20, this.height - 20);
    ctx.strokeStyle = "rgba(85,246,210,0.75)"; ctx.lineWidth = 3;
    const l = 30;
    ctx.beginPath();
    ctx.moveTo(10, 10 + l); ctx.lineTo(10, 10); ctx.lineTo(10 + l, 10);
    ctx.moveTo(this.width - 10 - l, 10); ctx.lineTo(this.width - 10, 10); ctx.lineTo(this.width - 10, 10 + l);
    ctx.moveTo(10, this.height - 10 - l); ctx.lineTo(10, this.height - 10); ctx.lineTo(10 + l, this.height - 10);
    ctx.moveTo(this.width - 10 - l, this.height - 10); ctx.lineTo(this.width - 10, this.height - 10); ctx.lineTo(this.width - 10, this.height - 10 - l); ctx.stroke();
  }

  private drawTitleArt(ctx: CanvasRenderingContext2D): void {
    const x = this.width * 0.25, y = this.height * 0.48;
    ctx.save(); ctx.translate(x, y);
    ctx.strokeStyle = "rgba(85,246,210,0.16)"; ctx.lineWidth = 1;
    for (let r = 72; r <= 216; r += 48) { ctx.beginPath(); ctx.arc(0, 0, r, 0, Math.PI * 2); ctx.stroke(); }
    ctx.rotate(this.gameTime * 0.12);
    ctx.strokeStyle = "rgba(98,168,255,0.35)"; ctx.lineWidth = 2; ctx.setLineDash([34, 18]);
    ctx.beginPath(); ctx.arc(0, 0, 182, 0, Math.PI * 2); ctx.stroke(); ctx.setLineDash([]);
    for (let i = 0; i < 8; i++) {
      const a = i * Math.PI / 4 + this.gameTime * (i % 2 ? -0.16 : 0.1), r = i % 2 ? 182 : 132;
      const ex = Math.cos(a) * r, ey = Math.sin(a) * r;
      ctx.save(); ctx.translate(ex, ey); ctx.rotate(a + Math.PI / 2);
      ctx.fillStyle = i % 3 === 0 ? "rgba(255,79,129,0.65)" : "rgba(98,168,255,0.5)";
      ctx.beginPath(); ctx.moveTo(10, 0); ctx.lineTo(-8, -7); ctx.lineTo(-4, 0); ctx.lineTo(-8, 7); ctx.closePath(); ctx.fill(); ctx.restore();
    }
    ctx.rotate(-this.gameTime * 0.12);
    ctx.fillStyle = "rgba(85,246,210,0.045)"; ctx.beginPath(); ctx.arc(0, 0, 70 + Math.sin(this.gameTime * 2) * 4, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = GAME.COLORS.cyan; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(0, 0, 44, 0, Math.PI * 2); ctx.stroke();
    ctx.rotate(this.gameTime * 0.6); ctx.fillStyle = GAME.COLORS.cyan;
    ctx.beginPath(); ctx.moveTo(0, -30); ctx.lineTo(22, 18); ctx.lineTo(0, 9); ctx.lineTo(-22, 18); ctx.closePath(); ctx.fill();
    ctx.fillStyle = GAME.COLORS.bg; ctx.beginPath(); ctx.arc(0, 0, 8, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
    ctx.fillStyle = "rgba(143,169,190,0.42)"; ctx.font = "10px ui-monospace, monospace"; ctx.textAlign = "center";
    ctx.fillText("NEXUS // ONLINE", x, y + 252);
  }

  private drawTimeField(ctx: CanvasRenderingContext2D): void {
    const p = this.player, r = 175 + this.upgrades.time * 15;
    ctx.fillStyle = "rgba(98,168,255,0.025)"; ctx.beginPath(); ctx.arc(p.x, p.y, r, 0, Math.PI * 2); ctx.fill();
    ctx.setLineDash([7, 12]); ctx.lineDashOffset = -this.gameTime * 18;
    ctx.strokeStyle = "rgba(143,199,255,0.22)"; ctx.lineWidth = 1.5; ctx.stroke(); ctx.setLineDash([]);
  }

  private drawPickups(ctx: CanvasRenderingContext2D): void {
    for (const p of this.pickups) {
      if (!p.alive) continue;
      const bob = Math.sin(p.phase) * 3;
      ctx.save(); ctx.translate(p.x, p.y + bob); ctx.rotate(p.phase * 0.35);
      ctx.fillStyle = p.health ? GAME.COLORS.green : GAME.COLORS.xp;
      ctx.globalAlpha = Math.min(1, p.life * 2);
      if (p.health) { ctx.fillRect(-3, -9, 6, 18); ctx.fillRect(-9, -3, 18, 6); }
      else { ctx.beginPath(); ctx.moveTo(0, -7); ctx.lineTo(6, 0); ctx.lineTo(0, 7); ctx.lineTo(-6, 0); ctx.closePath(); ctx.fill(); }
      ctx.restore();
    }
    ctx.globalAlpha = 1;
  }

  private drawShockwaves(ctx: CanvasRenderingContext2D): void {
    for (const s of this.shockwaves) {
      if (!s.alive) continue;
      ctx.globalAlpha = Math.max(0, s.life / s.maxLife) * 0.75;
      ctx.strokeStyle = s.color; ctx.lineWidth = 3 + s.life * 4;
      ctx.beginPath(); ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2); ctx.stroke();
    }
    ctx.globalAlpha = 1;
  }

  private enemyColor(kind: EnemyKind): string {
    if (kind === "wisp") return GAME.COLORS.orange;
    if (kind === "brute" || kind === "boss") return GAME.COLORS.purple;
    if (kind === "spitter") return GAME.COLORS.green;
    if (kind === "splitter") return GAME.COLORS.pink;
    return GAME.COLORS.red;
  }

  private drawEnemies(ctx: CanvasRenderingContext2D): void {
    for (const e of this.enemies) {
      if (!e.alive) continue;
      if (e.spawn > 0) {
        const pulse = 0.5 + Math.sin(this.gameTime * 18 + e.phase) * 0.25;
        ctx.strokeStyle = this.enemyColor(e.kind); ctx.globalAlpha = pulse; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.arc(e.x, e.y, e.r + 10 + e.spawn * 10, 0, Math.PI * 2); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(e.x - 7, e.y); ctx.lineTo(e.x + 7, e.y); ctx.moveTo(e.x, e.y - 7); ctx.lineTo(e.x, e.y + 7); ctx.stroke();
        ctx.globalAlpha = 1; continue;
      }
      const angle = Math.atan2(this.player.y - e.y, this.player.x - e.x);
      ctx.save(); ctx.translate(e.x, e.y); ctx.rotate(e.kind === "boss" ? this.gameTime * 0.18 : e.kind === "brute" && e.charge > 0 ? e.angle : angle);
      const color = e.hitFlash > 0 ? GAME.COLORS.white : this.enemyColor(e.kind);
      ctx.fillStyle = color; ctx.strokeStyle = color; ctx.lineWidth = 2;
      if (e.kind === "hound") {
        ctx.beginPath(); ctx.moveTo(e.r + 4, 0); ctx.lineTo(-e.r, -e.r * 0.8); ctx.lineTo(-e.r * 0.55, 0); ctx.lineTo(-e.r, e.r * 0.8); ctx.closePath(); ctx.fill();
        ctx.fillStyle = GAME.COLORS.bg; ctx.beginPath(); ctx.arc(3, 0, 3.5, 0, Math.PI * 2); ctx.fill();
      } else if (e.kind === "wisp") {
        ctx.rotate(this.gameTime * 2 + e.phase); ctx.beginPath();
        for (let i = 0; i < 8; i++) { const a = i * Math.PI / 4, r = i % 2 ? e.r * 0.45 : e.r + 3; ctx.lineTo(Math.cos(a) * r, Math.sin(a) * r); }
        ctx.closePath(); ctx.fill(); ctx.fillStyle = GAME.COLORS.bg; ctx.beginPath(); ctx.arc(0, 0, 3, 0, Math.PI * 2); ctx.fill();
      } else if (e.kind === "splitter") {
        ctx.beginPath(); ctx.moveTo(e.r, 0); ctx.lineTo(0, -e.r); ctx.lineTo(-e.r, 0); ctx.lineTo(0, e.r); ctx.closePath(); ctx.fill();
        ctx.strokeStyle = GAME.COLORS.bg; ctx.beginPath(); ctx.moveTo(0, -e.r); ctx.lineTo(0, e.r); ctx.stroke();
      } else if (e.kind === "spitter") {
        ctx.beginPath(); ctx.arc(0, 0, e.r, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = GAME.COLORS.bg; ctx.beginPath(); ctx.arc(4, 0, 7, 0, Math.PI * 2); ctx.fill();
        ctx.strokeStyle = color; ctx.beginPath(); ctx.moveTo(7, 0); ctx.lineTo(e.r + 8, 0); ctx.stroke();
      } else if (e.kind === "brute") {
        if (e.charge > 0.42) { ctx.globalAlpha = 0.35 + Math.sin(this.gameTime * 28) * 0.2; ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(110, 0); ctx.stroke(); ctx.globalAlpha = 1; }
        ctx.beginPath(); for (let i = 0; i < 6; i++) { const a = i * Math.PI / 3; ctx.lineTo(Math.cos(a) * e.r, Math.sin(a) * e.r); } ctx.closePath(); ctx.fill();
        ctx.fillStyle = GAME.COLORS.bg; ctx.fillRect(-9, -5, 20, 10); ctx.fillStyle = color; ctx.fillRect(2, -3, 8, 6);
      } else {
        ctx.lineWidth = 7; ctx.beginPath(); ctx.arc(0, 0, e.r, 0, Math.PI * 2); ctx.stroke();
        ctx.rotate(-this.gameTime * 0.55); ctx.setLineDash([18, 12]); ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(0, 0, e.r + 15, 0, Math.PI * 2); ctx.stroke(); ctx.setLineDash([]);
        ctx.rotate(this.gameTime * 0.9); ctx.fillStyle = color; ctx.beginPath();
        for (let i = 0; i < 12; i++) { const a = i * Math.PI / 6, r = i % 2 ? 25 : 40; ctx.lineTo(Math.cos(a) * r, Math.sin(a) * r); } ctx.closePath(); ctx.fill();
        ctx.fillStyle = GAME.COLORS.bg; ctx.beginPath(); ctx.arc(0, 0, 16, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = GAME.COLORS.white; ctx.beginPath(); ctx.arc(6, 0, 5, 0, Math.PI * 2); ctx.fill();
      }
      ctx.restore();
      if (e.kind !== "boss" && e.hp < e.maxHp) {
        const w = e.r * 2; ctx.fillStyle = "rgba(0,0,0,0.55)"; ctx.fillRect(e.x - w / 2, e.y - e.r - 10, w, 3);
        ctx.fillStyle = this.enemyColor(e.kind); ctx.fillRect(e.x - w / 2, e.y - e.r - 10, w * Math.max(0, e.hp / e.maxHp), 3);
      }
    }
  }

  private drawBullets(ctx: CanvasRenderingContext2D): void {
    for (const b of this.bullets) {
      if (!b.alive) continue;
      ctx.strokeStyle = b.color; ctx.fillStyle = b.color;
      ctx.globalAlpha = b.hostile ? 0.85 : 0.5; ctx.lineWidth = b.missile ? 5 : 3;
      ctx.beginPath(); ctx.moveTo(b.x, b.y); ctx.lineTo(b.x - b.vx * 0.025, b.y - b.vy * 0.025); ctx.stroke();
      ctx.globalAlpha = 1; ctx.beginPath(); ctx.arc(b.x, b.y, b.r, 0, Math.PI * 2); ctx.fill();
      if (b.hostile) { ctx.fillStyle = GAME.COLORS.white; ctx.beginPath(); ctx.arc(b.x, b.y, 2, 0, Math.PI * 2); ctx.fill(); }
    }
  }

  private drawPlayer(ctx: CanvasRenderingContext2D): void {
    const p = this.player;
    if (this.state === "title") p.aim = -Math.PI / 2 + Math.sin(this.gameTime * 0.7) * 0.15;
    if (p.invuln > 0 && Math.floor(this.gameTime * 22) % 2 === 0 && p.dashTime <= 0) ctx.globalAlpha = 0.38;
    if (this.upgrades.shield > 0 && p.shieldCd <= 0 && this.state !== "title") {
      ctx.strokeStyle = GAME.COLORS.blue; ctx.globalAlpha = 0.45 + Math.sin(this.gameTime * 5) * 0.15; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.arc(p.x, p.y, p.r + 11, 0, Math.PI * 2); ctx.stroke(); ctx.globalAlpha = 1;
    }
    ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.aim);
    ctx.fillStyle = GAME.COLORS.cyan;
    ctx.beginPath(); ctx.moveTo(23, 0); ctx.lineTo(-13, -13); ctx.lineTo(-7, 0); ctx.lineTo(-13, 13); ctx.closePath(); ctx.fill();
    ctx.fillStyle = GAME.COLORS.bg; ctx.beginPath(); ctx.moveTo(9, 0); ctx.lineTo(-7, -5); ctx.lineTo(-4, 0); ctx.lineTo(-7, 5); ctx.closePath(); ctx.fill();
    ctx.fillStyle = GAME.COLORS.white; ctx.beginPath(); ctx.arc(3, 0, 3.5, 0, Math.PI * 2); ctx.fill();
    ctx.restore(); ctx.globalAlpha = 1;
    if (this.upgrades.orbit > 0 && this.state !== "title") {
      const count = this.upgrades.orbit * 2, radius = 58 + this.upgrades.orbit * 9;
      for (let i = 0; i < count; i++) {
        const a = this.orbAngle + i * Math.PI * 2 / count, x = p.x + Math.cos(a) * radius, y = p.y + Math.sin(a) * radius;
        ctx.save(); ctx.translate(x, y); ctx.rotate(a + Math.PI / 2); ctx.fillStyle = GAME.COLORS.xp;
        ctx.beginPath(); ctx.moveTo(0, -12); ctx.lineTo(6, 7); ctx.lineTo(0, 4); ctx.lineTo(-6, 7); ctx.closePath(); ctx.fill(); ctx.restore();
      }
    }
  }

  private drawParticles(ctx: CanvasRenderingContext2D): void {
    for (const p of this.particles) {
      if (!p.alive) continue;
      ctx.globalAlpha = Math.max(0, p.life / p.maxLife); ctx.fillStyle = p.color;
      const size = p.size * (0.4 + p.life / p.maxLife * 0.6); ctx.fillRect(p.x - size / 2, p.y - size / 2, size, size);
    }
    ctx.globalAlpha = 1;
  }

  private drawLightning(ctx: CanvasRenderingContext2D): void {
    ctx.strokeStyle = GAME.COLORS.gold; ctx.lineWidth = 2.5;
    for (const l of this.lightning) {
      if (!l.alive) continue;
      ctx.globalAlpha = Math.min(1, l.life * 8); ctx.beginPath(); ctx.moveTo(l.x1, l.y1);
      const dx = l.x2 - l.x1, dy = l.y2 - l.y1, len = Math.max(1, Math.hypot(dx, dy));
      const nx = -dy / len, ny = dx / len;
      for (let i = 1; i < 7; i++) {
        const t = i / 7, jitter = Math.sin(l.seed + i * 12.73) * 9 * Math.sin(t * Math.PI);
        ctx.lineTo(l.x1 + dx * t + nx * jitter, l.y1 + dy * t + ny * jitter);
      }
      ctx.lineTo(l.x2, l.y2); ctx.stroke();
    }
    ctx.globalAlpha = 1;
  }

  debugLevelUp(): void {
    if (this.state !== "playing") return;
    this.player.xp = this.player.nextXp; this.checkLevelUp();
  }

  debugBusy(): void {
    if (this.state !== "playing") this.startRun();
    this.wave = 4; this.waveTime = 10;
    for (const upgrade of UPGRADES) this.upgrades[upgrade.id] = 1;
    this.player.fireRate = 6; this.player.damage = 42; this.player.maxHp = 160; this.player.hp = 160;
    for (let i = 0; i < 42; i++) this.spawnEnemy(this.pickEnemyKind());
    this.events.onUpgradesChanged(this.upgrades); this.pushHud();
  }

  debugBoss(): void {
    if (this.state !== "playing") this.startRun();
    this.wave = GAME.FINAL_WAVE; this.waveTime = 0;
    if (!this.boss?.alive) this.spawnBoss();
    if (this.boss) { this.boss.spawn = 0; this.boss.y = Math.max(150, this.boss.y); }
    this.pushHud();
  }

  debugEnd(victory: boolean): void {
    if (this.state !== "playing") return;
    if (victory) {
      if (!this.boss?.alive) this.spawnBoss();
      if (this.boss) { this.boss.spawn = 0; this.damageEnemy(this.boss, 1e9, false); }
    } else { this.player.hp = 0; this.endRun(false); }
  }

  snapshot(): Record<string, number | string> {
    let enemies = 0, bullets = 0;
    for (const e of this.enemies) if (e.alive) enemies++;
    for (const b of this.bullets) if (b.alive) bullets++;
    return { state: this.state, wave: this.wave, level: this.player.level, hp: this.player.hp,
      kills: this.kills, score: this.score, enemies, bullets, particles: this.activeParticles, fps: this.fps };
  }
}
