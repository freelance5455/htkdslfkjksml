/**
 * characters.ts — procedural humanoid/creature mesh factory + skeletal-style animation.
 * All characters are built from primitives with joint pivots; animation is code-driven.
 */
import * as THREE from "three";
import { mergeGeos } from "./world";
import { clamp, lerp } from "./noise";

export interface HumanoidParts {
  root: THREE.Group;      // at ground level
  body: THREE.Group;      // bobs, leans
  torso: THREE.Mesh;
  head: THREE.Group;
  eyes: THREE.Mesh[];
  armL: THREE.Group; armR: THREE.Group;
  legL: THREE.Group; legR: THREE.Group;
  cape: THREE.Mesh;
  weaponMount: THREE.Group; // attach weapon meshes here (right hand)
  glow: THREE.PointLight;
}

export interface HumanoidOpts {
  armorColor: number;
  clothColor: number;
  skinColor: number;
  eyeColor: number;
  scale: number;
  cape?: boolean;
  bulky?: boolean;    // wide shoulders (knight/giant)
  hood?: boolean;
  glowIntensity?: number;
}

const MATS = new Map<string, THREE.MeshStandardMaterial>();
function mat(color: number, opts: Partial<THREE.MeshStandardMaterialParameters> = {}): THREE.MeshStandardMaterial {
  const key = `${color}|${JSON.stringify(opts)}`;
  let m = MATS.get(key);
  if (!m) {
    m = new THREE.MeshStandardMaterial({ color, roughness: 0.75, metalness: 0.25, ...opts });
    MATS.set(key, m);
  }
  return m;
}

export function buildHumanoid(o: HumanoidOpts): HumanoidParts {
  const s = o.scale;
  const bulky = o.bulky ? 1.35 : 1;
  const root = new THREE.Group();
  const body = new THREE.Group();
  root.add(body);

  // legs (pivot at hip)
  const legGeo = new THREE.CapsuleGeometry(0.13 * s * bulky, 0.62 * s, 3, 6);
  legGeo.translate(0, -0.42 * s, 0);
  const legL = new THREE.Group(); legL.position.set(-0.16 * s * bulky, 0.95 * s, 0);
  const legR = new THREE.Group(); legR.position.set(0.16 * s * bulky, 0.95 * s, 0);
  legL.add(new THREE.Mesh(legGeo, mat(o.armorColor)));
  legR.add(new THREE.Mesh(legGeo, mat(o.armorColor)));
  body.add(legL, legR);

  // torso
  const torso = new THREE.Mesh(
    new THREE.CapsuleGeometry(0.3 * s * bulky, 0.55 * s, 4, 8),
    mat(o.armorColor, { metalness: 0.45, roughness: 0.5 }),
  );
  torso.position.y = 1.35 * s;
  body.add(torso);
  // pauldrons
  const pdGeo = new THREE.SphereGeometry(0.17 * s * bulky, 8, 6, 0, Math.PI * 2, 0, Math.PI / 2);
  const pdL = new THREE.Mesh(pdGeo, mat(o.armorColor, { metalness: 0.5, roughness: 0.45 }));
  pdL.position.set(-0.34 * s * bulky, 1.62 * s, 0);
  const pdR = pdL.clone(); pdR.position.x *= -1;
  body.add(pdL, pdR);
  // belt / tabard
  const tabard = new THREE.Mesh(new THREE.BoxGeometry(0.4 * s, 0.5 * s, 0.08 * s), mat(o.clothColor, { roughness: 0.9, metalness: 0 }));
  tabard.position.set(0, 1.05 * s, 0.24 * s);
  body.add(tabard);

  // arms (pivot at shoulder)
  const armGeo = new THREE.CapsuleGeometry(0.1 * s * bulky, 0.55 * s, 3, 6);
  armGeo.translate(0, -0.36 * s, 0);
  const armL = new THREE.Group(); armL.position.set(-0.4 * s * bulky, 1.6 * s, 0);
  const armR = new THREE.Group(); armR.position.set(0.4 * s * bulky, 1.6 * s, 0);
  armL.add(new THREE.Mesh(armGeo, mat(o.armorColor)));
  armR.add(new THREE.Mesh(armGeo, mat(o.armorColor)));
  body.add(armL, armR);

  // head
  const head = new THREE.Group();
  head.position.y = 1.88 * s;
  const skull = new THREE.Mesh(new THREE.SphereGeometry(0.2 * s, 10, 8), mat(o.skinColor, { roughness: 0.6, metalness: 0.05 }));
  head.add(skull);
  if (o.hood) {
    const hood = new THREE.Mesh(new THREE.ConeGeometry(0.26 * s, 0.5 * s, 8), mat(o.clothColor, { roughness: 0.95, metalness: 0 }));
    hood.position.y = 0.14 * s;
    head.add(hood);
  }
  const eyeGeo = new THREE.SphereGeometry(0.035 * s, 6, 5);
  const eyeMat = new THREE.MeshBasicMaterial({ color: o.eyeColor });
  const eyeL = new THREE.Mesh(eyeGeo, eyeMat); eyeL.position.set(-0.075 * s, 0.02 * s, 0.17 * s);
  const eyeR = new THREE.Mesh(eyeGeo, eyeMat); eyeR.position.set(0.075 * s, 0.02 * s, 0.17 * s);
  head.add(eyeL, eyeR);
  body.add(head);

  // cape (cloth plane with swaying vertices)
  let cape: THREE.Mesh;
  if (o.cape !== false) {
    const cw = 0.62 * s * bulky, ch = 1.15 * s;
    const cg = new THREE.PlaneGeometry(cw, ch, 6, 8);
    cg.translate(0, -ch / 2, 0);
    const cm = new THREE.MeshStandardMaterial({ color: o.clothColor, roughness: 0.95, metalness: 0, side: THREE.DoubleSide });
    cape = new THREE.Mesh(cg, cm);
    cape.position.set(0, 1.68 * s, -0.26 * s * bulky);
    cape.castShadow = true;
    body.add(cape);
  } else {
    cape = new THREE.Mesh();
  }

  // weapon mount at right hand
  const weaponMount = new THREE.Group();
  weaponMount.position.set(0, -0.75 * s, 0.05 * s);
  armR.add(weaponMount);

  // subtle magic glow
  const glow = new THREE.PointLight(o.eyeColor, o.glowIntensity ?? 0, 6, 2);
  glow.position.y = 1.6 * s;
  body.add(glow);

  root.traverse((c) => { if ((c as THREE.Mesh).isMesh) { c.castShadow = true; } });

  return { root, body, torso, head, eyes: [eyeL, eyeR], armL, armR, legL, legR, cape, weaponMount, glow };
}

// ---------------- animation ----------------

export interface AnimState {
  speed: number;        // 0 idle .. 1 running
  t: number;            // time accumulator
  attackT: number;      // -1 none, else 0..1 progress of swing
  attackKind: number;   // 0 light, 1 heavy, 2 spin
  blocking: boolean;
  airborne: boolean;
  dodgeT: number;       // 0..1 roll progress
  dead: boolean;
  castT: number;       // 0..1 magic cast
  hitT: number;         // flinch timer
}

export function makeAnimState(): AnimState {
  return { speed: 0, t: 0, attackT: -1, attackKind: 0, blocking: false, airborne: false, dodgeT: 0, dead: false, castT: -1, hitT: 0 };
}

/** Drive all joints from an AnimState. Call every frame. */
export function animateHumanoid(p: HumanoidParts, a: AnimState, dt: number, windStrength = 1): void {
  a.t += dt * (1 + a.speed * 1.2);
  const w = a.t * 9;
  const runK = clamp(a.speed, 0, 1);

  if (a.dead) {
    p.body.rotation.x = lerp(p.body.rotation.x, -Math.PI / 2, dt * 5);
    p.body.position.y = lerp(p.body.position.y, 0.3, dt * 5);
    return;
  }
  p.body.rotation.x = lerp(p.body.rotation.x, a.hitT > 0 ? -0.25 : runK * 0.14, dt * 8);
  if (a.hitT > 0) a.hitT -= dt;

  // locomotion swing
  const swing = Math.sin(w) * (0.25 + runK * 0.75);
  const idle = Math.sin(a.t * 1.8) * 0.03;

  if (a.airborne) {
    p.legL.rotation.x = lerp(p.legL.rotation.x, -0.5, dt * 10);
    p.legR.rotation.x = lerp(p.legR.rotation.x, 0.35, dt * 10);
    p.armL.rotation.x = lerp(p.armL.rotation.x, -2.4, dt * 8);
  } else if (a.dodgeT > 0) {
    // roll: tuck
    const d = a.dodgeT;
    p.body.rotation.x = -d * Math.PI * 2 * 0.25;
    p.legL.rotation.x = -1.2; p.legR.rotation.x = -1.2;
    p.armL.rotation.x = -1; p.armR.rotation.x = -1;
  } else if (a.attackT >= 0) {
    animateAttack(p, a);
  } else if (a.castT >= 0) {
    const c = Math.sin(a.castT * Math.PI);
    p.armL.rotation.x = -2.6 * c; p.armL.rotation.z = 0.5 * c;
    p.armR.rotation.x = -0.6 * c;
    p.armR.rotation.z = lerp(p.armR.rotation.z, 0, dt * 10);
  } else {
    p.legL.rotation.x = swing; p.legR.rotation.x = -swing;
    p.armL.rotation.x = -swing * 0.8 + idle;
    p.armR.rotation.x = a.blocking ? -1.3 : swing * 0.8 - idle;
    p.armR.rotation.z = a.blocking ? -0.5 : lerp(p.armR.rotation.z, 0, dt * 8);
    p.armL.rotation.z = lerp(p.armL.rotation.z, 0.06, dt * 8);
    p.body.position.y = Math.abs(Math.sin(w)) * 0.06 * runK + idle * 0.5;
    p.body.rotation.x = lerp(p.body.rotation.x, runK * 0.14, dt * 8);
  }

  // cape cloth simulation (vertex wave)
  if (p.cape.geometry.attributes.position) {
    const pos = p.cape.geometry.attributes.position as THREE.BufferAttribute;
    const ch = 1.15;
    for (let i = 0; i < pos.count; i++) {
      const vy = pos.getY(i); // 0 at top .. -ch at bottom
      const depth = -vy / ch; // 0..1
      const wave = Math.sin(a.t * 3.2 + depth * 4 + pos.getX(i) * 3) * 0.09 * depth * windStrength;
      const lift = (runK * 0.55 + depth * 0.1) * depth * windStrength;
      pos.setZ(i, -(depth * depth) * 0.35 * windStrength - wave);
      pos.setX(i, pos.getX(i) * (1 + depth * 0.15));
      pos.setY(i, vy + lift * 0.35);
    }
    pos.needsUpdate = true;
    p.cape.geometry.computeVertexNormals();
  }
}

function animateAttack(p: HumanoidParts, a: AnimState): void {
  const t = a.attackT;
  const wind = 0.25, strike = 0.35;
  let arm: number, twist: number, armZ = 0;
  if (a.attackKind === 0) {
    // horizontal slashes alternating
    if (t < wind) { arm = lerp(-0.3, -2.2, t / wind); twist = lerp(0.6, -0.6, t / wind); }
    else if (t < wind + strike) { const k = (t - wind) / strike; arm = lerp(-2.2, -0.5, ease(k)); twist = lerp(-0.6, 0.8, ease(k)); }
    else { const k = (t - wind - strike) / (1 - wind - strike); arm = lerp(-0.5, -0.3, k); twist = lerp(0.8, 0, k); }
  } else if (a.attackKind === 1) {
    // overhead heavy
    if (t < wind + 0.1) { arm = lerp(-0.3, -3.1, t / (wind + 0.1)); twist = 0; }
    else if (t < wind + strike + 0.1) { const k = (t - wind - 0.1) / strike; arm = lerp(-3.1, 0.5, ease(k)); twist = lerp(0, 0.3, k); }
    else { const k = (t - wind - strike - 0.1) / (1 - wind - strike - 0.1); arm = lerp(0.5, -0.3, k); twist = lerp(0.3, 0, k); }
  } else {
    // spin
    arm = -1.5; twist = t * Math.PI * 2;
    armZ = -1.2;
  }
  p.armR.rotation.x = arm;
  p.armR.rotation.z = armZ;
  p.body.rotation.y = twist;
}

function ease(t: number): number { return 1 - (1 - t) * (1 - t) * (1 - t); }

// ---------------- weapon meshes ----------------

/** Build a sword mesh of a given tier (visual evolution). */
export function buildSwordMesh(tier: number, hue: number): THREE.Group {
  const g = new THREE.Group();
  const glowC = new THREE.Color().setHSL(hue, 0.85, 0.55);
  const bladeLen = 1.1 + tier * 0.12;
  const blade = new THREE.Mesh(
    new THREE.BoxGeometry(0.07 + tier * 0.008, bladeLen, 0.016),
    new THREE.MeshStandardMaterial({
      color: new THREE.Color().setHSL(hue, 0.35, 0.55),
      emissive: glowC, emissiveIntensity: tier * 0.45,
      metalness: 0.85, roughness: 0.25,
    }),
  );
  blade.position.y = bladeLen / 2 + 0.16;
  g.add(blade);
  const guard = new THREE.Mesh(new THREE.BoxGeometry(0.24 + tier * 0.03, 0.05, 0.05),
    new THREE.MeshStandardMaterial({ color: 0x2a2d3a, metalness: 0.7, roughness: 0.4 }));
  guard.position.y = 0.14;
  g.add(guard);
  const grip = new THREE.Mesh(new THREE.CylinderGeometry(0.028, 0.033, 0.24, 6),
    new THREE.MeshStandardMaterial({ color: 0x1c1620, roughness: 0.9 }));
  g.add(grip);
  if (tier >= 2) {
    const gem = new THREE.Mesh(new THREE.OctahedronGeometry(0.05, 0), new THREE.MeshBasicMaterial({ color: glowC }));
    gem.position.y = 0.2;
    g.add(gem);
  }
  if (tier >= 3) {
    // winged crossguard
    for (const s of [-1, 1]) {
      const wing = new THREE.Mesh(new THREE.ConeGeometry(0.04, 0.3, 4), new THREE.MeshStandardMaterial({ color: 0x2a2d3a, metalness: 0.75 }));
      wing.rotation.z = s * Math.PI / 2.6;
      wing.position.set(s * 0.22, 0.2, 0);
      g.add(wing);
    }
  }
  if (tier >= 4) {
    const halo = new THREE.Mesh(new THREE.TorusGeometry(0.16, 0.012, 6, 20),
      new THREE.MeshBasicMaterial({ color: glowC, transparent: true, opacity: 0.8 }));
    halo.rotation.x = Math.PI / 2;
    halo.position.y = 0.2;
    halo.name = "halo";
    g.add(halo);
  }
  g.traverse((c) => { if ((c as THREE.Mesh).isMesh) c.castShadow = true; });
  return g;
}

export function buildWeaponMesh(kind: string, tier: number, hue: number): THREE.Group {
  const glowC = new THREE.Color().setHSL(hue, 0.8, 0.5);
  const dark = new THREE.MeshStandardMaterial({ color: 0x232634, metalness: 0.7, roughness: 0.4 });
  const glowM = new THREE.MeshStandardMaterial({ color: 0x3a3f55, emissive: glowC, emissiveIntensity: 0.4 + tier * 0.35, metalness: 0.6, roughness: 0.3 });
  const g = new THREE.Group();
  if (kind === "hammer") {
    const handle = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.045, 1.3, 6), dark); handle.position.y = 0.4; g.add(handle);
    const head = new THREE.Mesh(new THREE.BoxGeometry(0.5 + tier * 0.04, 0.3, 0.3), glowM); head.position.y = 1.0; g.add(head);
  } else if (kind === "daggers") {
    for (const s of [0, 1]) {
      const blade = new THREE.Mesh(new THREE.BoxGeometry(0.045, 0.6 + tier * 0.05, 0.012), glowM);
      blade.position.set(0, 0.4, s * 0.09); g.add(blade);
    }
    const grip = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.03, 0.2, 6), dark); g.add(grip);
  } else if (kind === "spear") {
    const shaft = new THREE.Mesh(new THREE.CylinderGeometry(0.028, 0.028, 2.0, 6), dark); shaft.position.y = 0.7; g.add(shaft);
    const tip = new THREE.Mesh(new THREE.ConeGeometry(0.09 + tier * 0.01, 0.5, 6), glowM); tip.position.y = 1.95; g.add(tip);
  } else if (kind === "dragon") {
    const blade = new THREE.Mesh(new THREE.BoxGeometry(0.1, 1.35, 0.03), glowM); blade.position.y = 0.75; g.add(blade);
    const guard = new THREE.Mesh(new THREE.BoxGeometry(0.34, 0.06, 0.06), dark); guard.position.y = 0.14; g.add(guard);
    const flame = new THREE.Mesh(new THREE.ConeGeometry(0.06, 0.3, 5), glowM); flame.rotation.z = Math.PI; flame.position.y = 1.5; g.add(flame);
  } else if (kind === "bow") {
    const curve = new THREE.Mesh(new THREE.TorusGeometry(0.55, 0.025, 5, 14, Math.PI), dark);
    curve.rotation.z = -Math.PI / 2; curve.position.y = 0.5; g.add(curve);
    const str = new THREE.Mesh(new THREE.BoxGeometry(0.008, 1.06, 0.008), glowM); str.position.set(-0.0, 0.5, 0); str.position.x = 0.0; g.add(str);
    const arrow = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.012, 0.7, 5), glowM); arrow.rotation.x = Math.PI / 2; arrow.position.set(0, 0.5, 0.2); g.add(arrow);
  } else {
    return buildSwordMesh(tier, hue);
  }
  g.traverse((c) => { if ((c as THREE.Mesh).isMesh) c.castShadow = true; });
  return g;
}

/** Wolf / beast quadruped. */
export function buildBeast(opts: { scale: number; bodyColor: number; eyeColor: number; spikes?: boolean }): { root: THREE.Group; head: THREE.Group; legs: THREE.Group[]; tail: THREE.Mesh; } {
  const s = opts.scale;
  const root = new THREE.Group();
  const body = new THREE.Group();
  root.add(body);
  const bm = mat(opts.bodyColor, { roughness: 0.9, metalness: 0.05 });
  const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.34 * s, 0.9 * s, 4, 8), bm);
  torso.rotation.x = Math.PI / 2;
  torso.position.y = 0.72 * s;
  body.add(torso);
  const head = new THREE.Group();
  head.position.set(0, 0.88 * s, 0.62 * s);
  const skull = new THREE.Mesh(new THREE.BoxGeometry(0.34 * s, 0.3 * s, 0.5 * s), bm);
  skull.position.z = 0.14 * s;
  head.add(skull);
  const snout = new THREE.Mesh(new THREE.BoxGeometry(0.18 * s, 0.16 * s, 0.3 * s), bm);
  snout.position.set(0, -0.06 * s, 0.44 * s);
  head.add(snout);
  const eyeMat = new THREE.MeshBasicMaterial({ color: opts.eyeColor });
  for (const sx of [-1, 1]) {
    const e = new THREE.Mesh(new THREE.SphereGeometry(0.045 * s, 6, 5), eyeMat);
    e.position.set(sx * 0.1 * s, 0.06 * s, 0.38 * s);
    head.add(e);
  }
  body.add(head);
  const legs: THREE.Group[] = [];
  const legGeo = new THREE.CapsuleGeometry(0.09 * s, 0.5 * s, 3, 5);
  legGeo.translate(0, -0.3 * s, 0);
  for (const [lx, lz] of [[-0.22, 0.42], [0.22, 0.42], [-0.22, -0.42], [0.22, -0.42]] as const) {
    const leg = new THREE.Group();
    leg.position.set(lx * s, 0.62 * s, lz * s);
    leg.add(new THREE.Mesh(legGeo, bm));
    body.add(leg);
    legs.push(leg);
  }
  if (opts.spikes) {
    for (let i = 0; i < 4; i++) {
      const sp = new THREE.Mesh(new THREE.ConeGeometry(0.07 * s, 0.35 * s, 4), bm);
      sp.position.set(0, (1.0 + i * -0.03) * s, (0.3 - i * 0.28) * s);
      sp.rotation.x = -0.5;
      body.add(sp);
    }
  }
  const tail = new THREE.Mesh(new THREE.CapsuleGeometry(0.06 * s, 0.5 * s, 3, 5), bm);
  tail.rotation.x = Math.PI / 2.6;
  tail.position.set(0, 0.78 * s, -0.75 * s);
  body.add(tail);
  root.traverse((c) => { if ((c as THREE.Mesh).isMesh) c.castShadow = true; });
  return { root, head, legs, tail };
}

/** Treant boss — giant tree creature. */
export function buildTreant(scale: number): { root: THREE.Group; head: THREE.Group; armL: THREE.Group; armR: THREE.Group; core: THREE.Mesh; } {
  const s = scale;
  const root = new THREE.Group();
  const bark = mat(0x3a2f28, { roughness: 0.95, metalness: 0 });
  const body = new THREE.Mesh(new THREE.CylinderGeometry(0.9 * s, 1.5 * s, 3.4 * s, 8), bark);
  body.position.y = 2.0 * s;
  root.add(body);
  const head = new THREE.Group();
  head.position.y = 4.1 * s;
  const husk = new THREE.Mesh(new THREE.IcosahedronGeometry(0.75 * s, 0), bark);
  head.add(husk);
  const eyeMat = new THREE.MeshBasicMaterial({ color: 0x8aff5a });
  for (const sx of [-1, 1]) {
    const e = new THREE.Mesh(new THREE.SphereGeometry(0.13 * s, 8, 6), eyeMat);
    e.position.set(sx * 0.3 * s, 0.1 * s, 0.55 * s);
    head.add(e);
  }
  // antler branches
  for (const sx of [-1, 1]) {
    const br = new THREE.Mesh(new THREE.CylinderGeometry(0.05 * s, 0.14 * s, 1.6 * s, 5), bark);
    br.position.set(sx * 0.55 * s, 0.8 * s, 0);
    br.rotation.z = sx * -0.7;
    head.add(br);
  }
  root.add(head);
  const core = new THREE.Mesh(new THREE.OctahedronGeometry(0.42 * s, 0), new THREE.MeshBasicMaterial({ color: 0x8aff5a }));
  core.position.set(0, 2.4 * s, 0.95 * s);
  root.add(core);
  const mkArm = (sx: number) => {
    const arm = new THREE.Group();
    arm.position.set(sx * 1.4 * s, 3.3 * s, 0);
    const limb = new THREE.Mesh(new THREE.CylinderGeometry(0.22 * s, 0.34 * s, 2.6 * s, 6), bark);
    limb.position.y = -1.3 * s;
    arm.add(limb);
    const claw = new THREE.Group();
    claw.position.y = -2.6 * s;
    for (let f = 0; f < 3; f++) {
      const fin = new THREE.Mesh(new THREE.ConeGeometry(0.1 * s, 0.8 * s, 4), bark);
      fin.position.set((f - 1) * 0.28 * s, -0.3 * s, 0.1 * s);
      fin.rotation.x = Math.PI;
      claw.add(fin);
    }
    arm.add(claw);
    root.add(arm);
    return arm;
  };
  const armL = mkArm(-1), armR = mkArm(1);
  // roots feet
  for (let i = 0; i < 5; i++) {
    const a = (i / 5) * Math.PI * 2;
    const rt = new THREE.Mesh(new THREE.ConeGeometry(0.35 * s, 1.2 * s, 5), bark);
    rt.position.set(Math.cos(a) * 1.3 * s, 0.4 * s, Math.sin(a) * 1.3 * s);
    rt.rotation.x = Math.PI;
    rt.rotation.z = Math.cos(a) * 0.4;
    root.add(rt);
  }
  root.traverse((c) => { if ((c as THREE.Mesh).isMesh) c.castShadow = true; });
  return { root, head, armL, armR, core };
}
