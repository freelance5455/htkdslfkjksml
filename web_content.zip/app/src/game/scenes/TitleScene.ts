/**
 * TitleScene — tela inicial: logo animado, recordes e controles.
 * Espaço/Enter/toque começa a campanha.
 */
import Phaser from "phaser";
import { VIEW, WORLD, COLORS } from "../config";
import { LEVELS } from "../levels";
import { makeStarsTexture, makeGlowTexture, makeMountainTexture } from "../art";
import { gameAudio } from "../audio";
import { run, records } from "../run";

export class TitleScene extends Phaser.Scene {
  private crystal!: Phaser.GameObjects.Container;
  private startText!: Phaser.GameObjects.Text;

  constructor() {
    super("Title");
  }

  create(): void {
    makeStarsTexture(this, "stars");
    makeGlowTexture(this, "glow-cyan", 0x66e0ff);
    makeGlowTexture(this, "glow-violet", 0xb07dff);
    makeMountainTexture(this, "mtn-title-far", LEVELS[0].theme.mountainFar, 1);
    makeMountainTexture(this, "mtn-title-near", LEVELS[0].theme.mountain, 2);

    const g = this.add.graphics();
    g.fillGradientStyle(0x0a1626, 0x0a1626, 0x14384a, 0x1d4a5e, 1);
    g.fillRect(0, 0, VIEW.WIDTH, VIEW.HEIGHT);
    this.add.image(VIEW.WIDTH / 2, 150, "stars").setAlpha(0.9);
    this.add.tileSprite(0, WORLD.GROUND_Y + 40, VIEW.WIDTH * 2, WORLD.GROUND_Y, "mtn-title-far").setOrigin(0, 1).setAlpha(0.8);
    this.add.tileSprite(0, WORLD.GROUND_Y + 46, VIEW.WIDTH * 2, WORLD.GROUND_Y, "mtn-title-near").setOrigin(0, 1);

    // cristal flutuante do logo
    this.crystal = this.add.container(VIEW.WIDTH / 2, 168);
    const glow = this.add.image(0, 0, "glow-cyan").setScale(3.2).setAlpha(0.6);
    const outer = this.add.ellipse(0, 0, 46, 60, COLORS.crystal);
    const core = this.add.ellipse(0, 0, 20, 28, COLORS.crystalCore);
    const facet = this.add.triangle(-6, -8, 0, 0, 10, 4, 2, 14, 0xffffff).setAlpha(0.5);
    this.crystal.add([glow, outer, core, facet]);

    this.add
      .text(VIEW.WIDTH / 2, 250, "CRÔNICAS DO CRISTAL", {
        fontFamily: "monospace",
        fontSize: "40px",
        color: "#f2f7ff",
        stroke: "#0a1a2e",
        strokeThickness: 6,
      })
      .setOrigin(0.5);
    this.add
      .text(VIEW.WIDTH / 2, 292, "Uma aventura de ação e plataforma em três reinos", {
        fontFamily: "monospace",
        fontSize: "15px",
        color: "#9fd8e8",
      })
      .setOrigin(0.5);

    const best = records.bestCrystals;
    this.add
      .text(
        VIEW.WIDTH / 2,
        330,
        `${records.wins > 0 ? `Vitórias: ${records.wins}   •   Recorde de cristais: ${best}` : "Nenhuma jornada registrada ainda — boa sorte, herói!"}`,
        { fontFamily: "monospace", fontSize: "14px", color: "#ffe68c" },
      )
      .setOrigin(0.5);

    this.add
      .text(
        VIEW.WIDTH / 2,
        386,
        "A/D ou ←/→ mover   •   Espaço/W pular   •   J espada   •   K magia\n" +
          "Colete 5 cristais para desbloquear a Explosão Arcana.\n" +
          "Toque nos botões da tela no celular.   M liga/desliga o som.",
        { fontFamily: "monospace", fontSize: "13px", color: "#8fa8c8", align: "center", lineSpacing: 6 },
      )
      .setOrigin(0.5);

    this.startText = this.add
      .text(VIEW.WIDTH / 2, 470, "PRESSIONE ESPAÇO OU TOQUE PARA COMEÇAR", {
        fontFamily: "monospace",
        fontSize: "17px",
        color: "#ffffff",
      })
      .setOrigin(0.5);
    this.tweens.add({ targets: this.startText, alpha: 0.25, duration: 700, yoyo: true, repeat: -1 });

    const start = () => {
      if (this.scene.isActive("Game")) return;
      gameAudio.unlock();
      gameAudio.play("ui", 0.7);
      run.reset();
      run.startedAt = performance.now();
      this.scene.start("Game");
    };
    this.input.keyboard!.once("keydown-SPACE", start);
    this.input.keyboard!.once("keydown-ENTER", start);
    this.input.once(Phaser.Input.Events.POINTER_DOWN, start);
  }

  override update(_t: number, dtMs: number): void {
    const dt = dtMs / 1000;
    this.crystal.y = 168 + Math.sin(_t / 500) * 8;
    this.crystal.rotation = Math.sin(_t / 900) * 0.08;
    this.crystal.setScale(1 + Math.sin(_t / 400) * 0.03);
    void dt;
  }
}
