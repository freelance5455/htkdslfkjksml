/**
 * EndScene — vitória ou derrota, com estatísticas da jornada.
 */
import Phaser from "phaser";
import { VIEW, WORLD } from "../config";
import { LEVELS } from "../levels";
import { makeStarsTexture, makeGlowTexture, makeMountainTexture } from "../art";
import { gameAudio } from "../audio";
import { run, records } from "../run";
import { touchState } from "../input";

export class EndScene extends Phaser.Scene {
  private victory = false;

  constructor() {
    super("End");
  }

  init(data: { victory: boolean }): void {
    this.victory = data.victory;
  }

  create(): void {
    makeStarsTexture(this, "stars");
    makeGlowTexture(this, "glow-cyan", 0x66e0ff);
    makeGlowTexture(this, "glow-violet", 0xb07dff);
    const lastTheme = LEVELS[Math.min(run.levelIndex, LEVELS.length - 1)].theme;
    makeMountainTexture(this, "mtn-end-far", lastTheme.mountainFar, 1);
    makeMountainTexture(this, "mtn-end-near", lastTheme.mountain, 2);

    const g = this.add.graphics();
    if (this.victory) g.fillGradientStyle(0x0a1e2e, 0x0a1e2e, 0x14435f, 0x2a7a8c, 1);
    else g.fillGradientStyle(0x160f14, 0x160f14, 0x2e1420, 0x401825, 1);
    g.fillRect(0, 0, VIEW.WIDTH, VIEW.HEIGHT);
    this.add.image(VIEW.WIDTH / 2, 140, "stars").setAlpha(this.victory ? 0.9 : 0.4);
    this.add.tileSprite(0, WORLD.GROUND_Y + 44, VIEW.WIDTH * 2, WORLD.GROUND_Y, "mtn-end-far").setOrigin(0, 1).setAlpha(0.8);
    this.add.tileSprite(0, WORLD.GROUND_Y + 50, VIEW.WIDTH * 2, WORLD.GROUND_Y, "mtn-end-near").setOrigin(0, 1);

    if (this.victory) {
      const crystal = this.add.container(VIEW.WIDTH / 2, 150);
      const glow = this.add.image(0, 0, "glow-cyan").setScale(4).setAlpha(0.7);
      const outer = this.add.ellipse(0, 0, 56, 74, 0x40d9ff);
      const core = this.add.ellipse(0, 0, 24, 34, 0xccfbff);
      crystal.add([glow, outer, core]);
      this.tweens.add({ targets: crystal, y: 138, duration: 1200, yoyo: true, repeat: -1, ease: "Sine.InOut" });
    }

    this.add
      .text(VIEW.WIDTH / 2, 236, this.victory ? "VITÓRIA!" : "O HERÓI CAIU…", {
        fontFamily: "monospace",
        fontSize: "42px",
        color: this.victory ? "#ffe68c" : "#ff9a8a",
        stroke: "#0a0f18",
        strokeThickness: 6,
      })
      .setOrigin(0.5);
    this.add
      .text(
        VIEW.WIDTH / 2,
        286,
        this.victory
          ? "Você venceu! O Cristal Ancestral é seu."
          : `${LEVELS[run.levelIndex].name} ainda guarda seus segredos. Tente de novo!`,
        { fontFamily: "monospace", fontSize: "16px", color: "#cfe3ff" },
      )
      .setOrigin(0.5);

    const mins = Math.floor(run.elapsedSeconds() / 60);
    const secs = run.elapsedSeconds() % 60;
    this.add
      .text(
        VIEW.WIDTH / 2,
        336,
        `Cristais: ${run.crystals}   •   Inimigos derrotados: ${run.enemiesDefeated}   •   Tempo: ${mins}:${String(secs).padStart(2, "0")}` +
          (this.victory ? `\nRecorde de cristais: ${records.bestCrystals}` : ""),
        { fontFamily: "monospace", fontSize: "14px", color: "#9fb8d8", align: "center", lineSpacing: 8 },
      )
      .setOrigin(0.5);

    this.makeButton(VIEW.WIDTH / 2, 418, this.victory ? "JOGAR NOVAMENTE" : "TENTAR NOVAMENTE  (ESPAÇO)", () => this.retry());
    this.makeButton(VIEW.WIDTH / 2, 474, "TÍTULO", () => {
      gameAudio.play("ui", 0.6);
      this.scene.start("Title");
      touchState.reset();
    });

    this.input.keyboard!.once("keydown-SPACE", () => this.retry());
    this.input.keyboard!.once("keydown-ENTER", () => this.retry());
  }

  private retry(): void {
    gameAudio.play("ui", 0.7);
    if (this.victory) run.reset();
    // derrota: mantém run.levelIndex para recomeçar na fase atual
    run.startedAt = performance.now();
    this.scene.start("Game");
    touchState.reset();
  }

  private makeButton(x: number, y: number, label: string, cb: () => void): void {
    const txt = this.add
      .text(x, y, label, {
        fontFamily: "monospace",
        fontSize: "17px",
        color: "#f2f7ff",
        backgroundColor: "#14273d",
        padding: { x: 22, y: 12 },
      })
      .setOrigin(0.5)
      .setInteractive({ useHandCursor: true });
    txt.on("pointerover", () => txt.setColor("#ffffff").setBackgroundColor("#1d3a5c"));
    txt.on("pointerout", () => txt.setColor("#f2f7ff").setBackgroundColor("#14273d"));
    txt.on("pointerdown", cb);
  }
}
