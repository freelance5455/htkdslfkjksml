/**
 * GameScene — o coração do jogo: monta a fase, roda o combate e o fluxo
 * fase a fase. Portado do game.gd/player.gd/enemy.gd/pickup.gd do protótipo Godot.
 */
import Phaser from "phaser";
import { VIEW, PLAYER, COMBAT, WORLD, COLORS } from "../config";
import { LEVELS } from "../levels";
import { Hero } from "../hero";
import { Enemy } from "../enemy";
import { buildLevelTextures } from "../art";
import { touchState } from "../input";
import { gameAudio } from "../audio";
import { run, records } from "../run";

interface Crystal {
  c: Phaser.GameObjects.Container;
  taken: boolean;
  phase: number;
}

export class GameScene extends Phaser.Scene {
  private hero!: Hero;
  private enemies: Enemy[] = [];
  private crystals: Crystal[] = [];
  private staticBodies!: Phaser.Physics.Arcade.StaticGroup;
  private level = LEVELS[0];
  private keys!: Record<string, Phaser.Input.Keyboard.Key>;
  private msgText!: Phaser.GameObjects.Text;
  private msgTimer = 0;
  private hudG!: Phaser.GameObjects.Graphics;
  private crystalText!: Phaser.GameObjects.Text;
  private phaseText!: Phaser.GameObjects.Text;
  private magicHint!: Phaser.GameObjects.Text;
  private bossBarG!: Phaser.GameObjects.Graphics;
  private bossBarText!: Phaser.GameObjects.Text;
  private portal!: Phaser.GameObjects.Container;
  private portalRing!: Phaser.GameObjects.Arc;
  private portalGlow!: Phaser.GameObjects.Rectangle;
  private transitioning = false;
  private crystalEmitter!: Phaser.GameObjects.Particles.ParticleEmitter;
  private hitEmitter!: Phaser.GameObjects.Particles.ParticleEmitter;
  private dieEmitter!: Phaser.GameObjects.Particles.ParticleEmitter;
  private magicEmitter!: Phaser.GameObjects.Particles.ParticleEmitter;
  private dustEmitter!: Phaser.GameObjects.Particles.ParticleEmitter;
  private areaClearAnnounced = false;

  constructor() {
    super("Game");
  }

  create(): void {
    this.level = LEVELS[run.levelIndex];
    this.transitioning = false;
    this.areaClearAnnounced = false;
    this.enemies = [];
    this.crystals = [];

    buildLevelTextures(this, this.level, run.levelIndex);
    this.buildBackground();
    this.buildTerrain();
    this.buildHero();
    this.buildEnemies();
    this.buildCrystals();
    this.buildPortal();
    this.buildEmitters();
    this.buildHud();
    this.setupInput();
    this.setupCamera();

    this.showMessage(`${this.level.name} — encontre o portal!`, 3);
    gameAudio.startMusic(this.level.music);
    this.events.once(Phaser.Scenes.Events.SHUTDOWN, () => gameAudio.stopMusic());

    window.__gameProbe = () => ({ x: this.hero.x, y: this.hero.y, z: 0 });
  }

  // ---------- construção ----------

  private buildBackground(): void {
    const i = run.levelIndex;
    this.add.image(VIEW.WIDTH / 2, VIEW.HEIGHT / 2, `sky-${i}`).setScrollFactor(0).setDepth(-100);
    this.add.image(VIEW.WIDTH / 2, 160, "stars").setScrollFactor(0).setDepth(-99).setAlpha(0.8);
    this.add
      .tileSprite(0, WORLD.GROUND_Y, this.level.length + VIEW.WIDTH, WORLD.GROUND_Y, `mtn-far-${i}`)
      .setOrigin(0, 1)
      .setScrollFactor(0.25, 1)
      .setDepth(-90)
      .setAlpha(0.85);
    this.add
      .tileSprite(0, WORLD.GROUND_Y + 6, this.level.length + VIEW.WIDTH, WORLD.GROUND_Y, `mtn-near-${i}`)
      .setOrigin(0, 1)
      .setScrollFactor(0.5, 1)
      .setDepth(-80);
    this.add
      .tileSprite(0, WORLD.GROUND_Y, this.level.length + 512, 64, `fog-${i}`)
      .setOrigin(0, 1)
      .setScrollFactor(0.7, 1)
      .setDepth(-70)
      .setAlpha(0.35);
    // brilho de acento decorativo no chão
    this.add
      .tileSprite(0, WORLD.GROUND_Y + 42, this.level.length + 512, 84, `floor-${i}`)
      .setOrigin(0, 0.5)
      .setDepth(2);
  }

  private buildTerrain(): void {
    this.staticBodies = this.physics.add.staticGroup();
    const ground = WORLD.GROUND_Y;

    const floor = this.add.rectangle(this.level.length / 2, ground + 42, this.level.length + 400, 84, 0, 0);
    this.staticBodies.add(floor);

    for (let k = 1; k <= 8; k++) {
      const px = 300 + k * WORLD.PLATFORM_STEP;
      const py = ground - WORLD.PLATFORM_LIFT - (k % 2) * WORLD.PLATFORM_LIFT_ALT;
      const plat = this.add.image(px, py, `plat-${run.levelIndex}`);
      plat.setDepth(3);
      this.staticBodies.add(plat);
    }
  }

  private buildHero(): void {
    this.hero = new Hero(this, 100, WORLD.GROUND_Y - 2);
    this.physics.add.collider(this.hero.container, this.staticBodies);
  }

  private buildEnemies(): void {
    const ground = WORLD.GROUND_Y;
    const n = this.level.enemyCount;
    for (let i = 0; i < n; i++) {
      const isBoss = this.level.boss && i === n - 1;
      const x = 450 + (i * (this.level.length - 700)) / Math.max(1, n - 1);
      const e = new Enemy(this, x, ground - 2, isBoss);
      this.physics.add.collider(e.container, this.staticBodies);
      this.enemies.push(e);
    }
  }

  private buildCrystals(): void {
    const ground = WORLD.GROUND_Y;
    for (let i = 1; i <= WORLD.CRYSTAL_COUNT; i++) {
      const x = 180 + i * 125;
      const y = ground - 65 - (i % 3) * 45;
      const c = this.add.container(x, y);
      const glow = this.add.image(0, 0, "glow-cyan").setScale(1.4).setAlpha(0.55);
      const outer = this.add.ellipse(0, 0, 24, 30, COLORS.crystal);
      const core = this.add.ellipse(0, 0, 11, 14, COLORS.crystalCore);
      c.add([glow, outer, core]);
      c.setDepth(5);
      this.crystals.push({ c, taken: false, phase: i * 0.7 });
    }
  }

  private buildPortal(): void {
    const px = this.level.length - WORLD.PORTAL_OFFSET;
    const py = WORLD.GROUND_Y;
    this.portal = this.add.container(px, py);
    this.portalGlow = this.add.rectangle(0, -45, 44, 90, COLORS.portal, 0.35);
    this.portalRing = this.add.arc(0, -45, 38, 0, 360, false, 0x6fdcff, 0.9);
    this.portalRing.setStrokeStyle(5, 0x6fdcff, 0.9);
    const inner = this.add.image(0, -45, "glow-cyan").setScale(3).setAlpha(0.5);
    this.portal.add([inner, this.portalGlow, this.portalRing]);
    this.portal.setDepth(4);
  }

  private buildEmitters(): void {
    const mk = (key: string, config: Phaser.Types.GameObjects.Particles.ParticleEmitterConfig) =>
      this.add.particles(0, 0, key, {
        ...config,
        emitting: false,
      }).setDepth(20);
    this.crystalEmitter = mk("glow-cyan", {
      speed: { min: 40, max: 120 },
      scale: { start: 0.5, end: 0 },
      lifespan: 500,
      quantity: 10,
    });
    this.hitEmitter = mk("glow-white", {
      speed: { min: 60, max: 180 },
      scale: { start: 0.45, end: 0 },
      lifespan: 320,
      quantity: 8,
    });
    this.dieEmitter = mk("glow-red", {
      speed: { min: 50, max: 220 },
      scale: { start: 0.7, end: 0 },
      lifespan: 600,
      quantity: 22,
    });
    this.magicEmitter = mk("glow-violet", {
      speed: { min: 120, max: 420 },
      scale: { start: 0.9, end: 0 },
      lifespan: 700,
      quantity: 40,
    });
    this.dustEmitter = mk("glow-white", {
      speed: { min: 20, max: 70 },
      scale: { start: 0.3, end: 0 },
      lifespan: 400,
      alpha: { start: 0.4, end: 0 },
      quantity: 6,
    });
  }

  private buildHud(): void {
    this.hudG = this.add.graphics().setScrollFactor(0).setDepth(1000);
    this.bossBarG = this.add.graphics().setScrollFactor(0).setDepth(1000);
    const font = { fontFamily: "monospace", fontSize: "16px", color: "#f2f7ff" };

    this.crystalText = this.add.text(VIEW.WIDTH - 20, 14, "", font).setOrigin(1, 0).setScrollFactor(0).setDepth(1001);
    this.phaseText = this.add
      .text(VIEW.WIDTH / 2, 12, "", { ...font, fontSize: "15px", color: "#cfe3ff" })
      .setOrigin(0.5, 0)
      .setScrollFactor(0)
      .setDepth(1001);
    this.magicHint = this.add
      .text(20, 66, "", { ...font, fontSize: "13px", color: "#8fa8c8" })
      .setScrollFactor(0)
      .setDepth(1001);
    this.bossBarText = this.add
      .text(VIEW.WIDTH / 2, 40, "GUARDIÃO DA CIDADELA", { ...font, fontSize: "13px", color: "#ffb0c0" })
      .setOrigin(0.5, 0)
      .setScrollFactor(0)
      .setDepth(1001)
      .setVisible(false);
    this.msgText = this.add
      .text(VIEW.WIDTH / 2, 92, "", {
        fontFamily: "monospace",
        fontSize: "20px",
        color: "#ffe68c",
        stroke: "#1a1408",
        strokeThickness: 4,
      })
      .setOrigin(0.5, 0)
      .setScrollFactor(0)
      .setDepth(1001)
      .setAlpha(0);
    this.refreshHudText();
  }

  /** Ações discretas: eventos keydown setam flags, consumidas no próximo update.
   *  (JustDown perde toques mais curtos que um frame — keyup limpa _justDown na mesma fila.) */
  private pendingJump = false;
  private pendingAttack = false;
  private pendingMagic = false;

  private setupInput(): void {
    const kb = this.input.keyboard!;
    kb.addCapture(["SPACE", "UP", "DOWN", "LEFT", "RIGHT", "W", "A", "S", "D"]);
    this.keys = kb.addKeys({
      left: Phaser.Input.Keyboard.KeyCodes.A,
      right: Phaser.Input.Keyboard.KeyCodes.D,
      arrowLeft: Phaser.Input.Keyboard.KeyCodes.LEFT,
      arrowRight: Phaser.Input.Keyboard.KeyCodes.RIGHT,
    }) as Record<string, Phaser.Input.Keyboard.Key>;

    kb.on("keydown-SPACE", () => (this.pendingJump = true));
    kb.on("keydown-W", () => (this.pendingJump = true));
    kb.on("keydown-UP", () => (this.pendingJump = true));
    kb.on("keydown-J", () => (this.pendingAttack = true));
    kb.on("keydown-X", () => (this.pendingAttack = true));
    kb.on("keydown-K", () => (this.pendingMagic = true));
    kb.on("keydown-C", () => (this.pendingMagic = true));
    kb.on("keydown-M", () => {
      gameAudio.unlock();
      gameAudio.toggleMuted();
      this.showMessage(gameAudio.muted ? "Som desligado (M)" : "Som ligado (M)", 1.2);
    });
    kb.on("keydown-ESC", () => this.pauseGame());
    kb.on("keydown-P", () => this.pauseGame());

    this.input.on(Phaser.Input.Events.POINTER_DOWN, () => gameAudio.unlock());
  }

  private setupCamera(): void {
    const cam = this.cameras.main;
    cam.setBounds(0, 0, this.level.length, VIEW.HEIGHT);
    cam.startFollow(this.hero.container, true, 0.12, 0.12);
  }

  // ---------- loop ----------

  override update(_time: number, deltaMs: number): void {
    const dt = Math.min(deltaMs / 1000, 0.05);
    if (!this.hero) return;

    if (touchState.pause) {
      touchState.pause = false;
      this.pauseGame();
      return;
    }

    // eixo de movimento: teclado + touch
    const keyAxis =
      (this.keys.right.isDown || this.keys.arrowRight.isDown ? 1 : 0) -
      (this.keys.left.isDown || this.keys.arrowLeft.isDown ? 1 : 0);
    const axis = Phaser.Math.Clamp(keyAxis + (touchState.right ? 1 : 0) - (touchState.left ? 1 : 0), -1, 1);
    this.hero.setAxis(axis);

    const jumpPressed = this.pendingJump || touchState.jump;
    this.pendingJump = false;
    if (jumpPressed) {
      if (this.hero.onFloor) {
        gameAudio.play("jump", 0.7, 0.95 + Math.random() * 0.1);
        this.dustEmitter.explode(6, this.hero.x, this.hero.y);
      }
      this.hero.jump();
    }

    const attackPressed = this.pendingAttack || touchState.attack;
    this.pendingAttack = false;
    if (attackPressed) this.tryAttack();

    const magicPressed = this.pendingMagic || touchState.magic;
    this.pendingMagic = false;
    if (magicPressed) this.tryMagic();

    // timers/anim do herói
    const landed = this.hero.update(dt);
    if (landed) this.dustEmitter.explode(6, this.hero.x, this.hero.y);

    // cair no vazio
    if (this.hero.y > WORLD.KILL_Y) this.respawnFromFall();

    // inimigos
    for (const e of this.enemies) {
      const hitHero = e.update(dt, this.hero, () => this.damageHero(COMBAT.CONTACT_DAMAGE));
      if (hitHero) {
        this.hitEmitter.explode(10, this.hero.x, this.hero.y - 30);
      }
    }

    // cristais (coleta por distância — círculo de raio 22 do protótipo)
    for (const cr of this.crystals) {
      if (cr.taken) continue;
      cr.phase += dt * 3;
      cr.c.y += Math.sin(cr.phase) * 0.08;
      cr.c.setScale(1 + Math.sin(cr.phase * 2) * 0.06);
      if (Math.abs(cr.c.x - this.hero.x) < WORLD.CRYSTAL_RADIUS && Math.abs(cr.c.y - (this.hero.y - 27)) < WORLD.CRYSTAL_RADIUS + 27) {
        cr.taken = true;
        cr.c.setVisible(false);
        this.collectCrystal(cr.c.x, cr.c.y);
      }
    }

    // portal
    this.portalRing.rotation += dt * 1.5;
    this.portalGlow.setAlpha(0.3 + Math.sin(_time / 300) * 0.12);

    // mensagem
    if (this.msgTimer > 0) {
      this.msgTimer -= dt;
      if (this.msgTimer <= 0) this.msgText.setAlpha(0);
    }

    this.drawBars();
    this.tryAdvance();
  }

  private tryAttack(): void {
    if (!this.hero.canAttack()) return;
    this.hero.startAttack();
    gameAudio.play("slash", 0.8, 0.9 + Math.random() * 0.2);
    const f = this.hero.facing;
    let hitAny = false;
    for (const e of this.enemies) {
      const dx = e.x - this.hero.x;
      const dy = e.y - this.hero.y;
      if (Math.abs(dx) < COMBAT.SWORD_RANGE_X && Math.abs(dy) < COMBAT.SWORD_RANGE_Y && Math.sign(dx || f) === f) {
        hitAny = true;
        this.hitEmitter.explode(8, e.x, e.y - 30);
        this.hurtEnemy(e, COMBAT.SWORD_DAMAGE);
      }
    }
    if (hitAny) {
      gameAudio.play("hit", 0.7);
      this.cameras.main.shake(80, 0.004);
    }
  }

  private tryMagic(): void {
    if (!this.hero.canMagic()) {
      if (!run.magicUnlocked) this.showMessage("Magia bloqueada — colete 5 cristais!", 1.6);
      else if (this.hero.mana < PLAYER.MAGIC_COST) this.showMessage("Mana insuficiente!", 1.2);
      return;
    }
    this.hero.startCast();
    gameAudio.play("magic", 0.9);
    this.magicEmitter.explode(40, this.hero.x, this.hero.y - 30);
    this.cameras.main.shake(200, 0.008);
    this.cameras.main.flash(150, 120, 90, 220);
    this.showMessage("EXPLOSÃO ARCANA!", 1.6);
    for (const e of [...this.enemies]) {
      const dx = e.x - this.hero.x;
      const dy = e.y - this.hero.y;
      if (Math.abs(dx) < COMBAT.MAGIC_RANGE_X && Math.abs(dy) < COMBAT.MAGIC_RANGE_Y) {
        this.hurtEnemy(e, COMBAT.MAGIC_DAMAGE);
      }
    }
  }

  private hurtEnemy(e: Enemy, damage: number): void {
    const died = e.takeHit(damage);
    if (died) {
      gameAudio.play("enemyDie", 0.7, e.isBoss ? 0.7 : 1);
      this.dieEmitter.explode(e.isBoss ? 40 : 20, e.x, e.y - 30);
      this.enemies = this.enemies.filter((x) => x !== e);
      e.destroy();
      run.enemiesDefeated++;
      if (this.enemies.length === 0) {
        this.areaClearAnnounced = true;
        this.showMessage("Área limpa! Siga até o portal.", 2.5);
      }
    }
  }

  private damageHero(amount: number): boolean {
    const applied = this.hero.takeDamage(amount);
    if (applied) {
      gameAudio.play("hurt", 0.8);
      this.cameras.main.shake(140, 0.007);
      if (this.hero.hp <= 0) this.gameOver();
    }
    return applied;
  }

  private respawnFromFall(): void {
    const nx = Math.max(80, this.hero.x - PLAYER.RESPAWN_BACK);
    this.hero.respawnAt(nx, 250);
    const applied = this.hero.takeDamage(PLAYER.FALL_DAMAGE, true);
    gameAudio.play("hurt", 0.6);
    this.cameras.main.shake(120, 0.006);
    if (applied && this.hero.hp <= 0) this.gameOver();
  }

  private collectCrystal(x: number, y: number): void {
    run.crystals++;
    gameAudio.play("crystal", 0.6, 1 + Math.min(0.5, run.crystals * 0.02));
    this.crystalEmitter.explode(10, x, y);
    this.refreshHudText();
    if (!run.magicUnlocked && run.crystals >= COMBAT.UNLOCK_CRYSTALS) {
      run.magicUnlocked = true;
      gameAudio.play("unlock", 0.9);
      this.showMessage("Poder desbloqueado: Explosão Arcana! (K)", 3);
      this.refreshHudText();
    }
  }

  private tryAdvance(): void {
    if (this.transitioning) return;
    if (this.hero.x < this.level.length - WORLD.ADVANCE_OFFSET) return;
    this.transitioning = true;
    gameAudio.play("portal", 0.8);
    if (run.levelIndex < LEVELS.length - 1) {
      run.levelIndex++;
      this.cameras.main.fadeOut(450, 5, 8, 14);
      this.cameras.main.once(Phaser.Cameras.Scene2D.Events.FADE_OUT_COMPLETE, () => {
        this.scene.restart();
        this.cameras.main.fadeIn(300, 5, 8, 14);
      });
    } else {
      this.victory();
    }
  }

  private victory(): void {
    records.wins = records.wins + 1;
    records.bestCrystals = Math.max(records.bestCrystals, run.crystals);
    gameAudio.play("victory", 1);
    this.scene.start("End", { victory: true });
  }

  private gameOver(): void {
    run.deaths++;
    gameAudio.play("defeat", 0.9);
    this.scene.start("End", { victory: false });
  }

  private pauseGame(): void {
    if (!this.hero || this.sys.settings.status !== 5) return; // só pausa em jogo ativo
    gameAudio.play("ui", 0.5);
    this.scene.launch("Pause");
    this.scene.pause();
  }

  // ---------- HUD ----------

  private showMessage(text: string, seconds: number): void {
    this.msgText.setText(text).setAlpha(1);
    this.msgTimer = seconds;
  }

  private refreshHudText(): void {
    this.crystalText.setText(`CRISTAIS: ${run.crystals}`);
    this.phaseText.setText(`FASE ${run.levelIndex + 1}/3 — ${this.level.name}`);
    this.magicHint.setText(
      run.magicUnlocked ? "K — Explosão Arcana" : `Magia: colete ${Math.max(0, COMBAT.UNLOCK_CRYSTALS - run.crystals)} cristais`,
    );
  }

  private drawBars(): void {
    const g = this.hudG;
    g.clear();
    // vida
    g.fillStyle(COLORS.hpBack, 0.9).fillRect(18, 16, 204, 16);
    g.fillStyle(COLORS.hp, 1).fillRect(20, 18, 200 * (this.hero.hp / PLAYER.MAX_HP), 12);
    // mana
    g.fillStyle(COLORS.manaBack, 0.9).fillRect(18, 38, 204, 12);
    g.fillStyle(COLORS.mana, 1).fillRect(20, 40, 200 * (this.hero.mana / PLAYER.MAX_MANA), 8);

    // barra do chefe
    const boss = this.enemies.find((e) => e.isBoss);
    this.bossBarText.setVisible(!!boss);
    this.bossBarG.clear();
    if (boss) {
      this.bossBarG.fillStyle(0x2a0f18, 0.9).fillRect(VIEW.WIDTH / 2 - 152, 58, 304, 14);
      this.bossBarG.fillStyle(COLORS.bossHorn, 1).fillRect(VIEW.WIDTH / 2 - 150, 60, 300 * (boss.hp / 40), 10);
    }
  }
}
