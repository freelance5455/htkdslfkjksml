/**
 * PauseScene — overlay de pausa sobre a GameScene congelada.
 * ESC retoma; botões recomeçam a fase ou voltam ao título.
 */
import Phaser from "phaser";
import { VIEW } from "../config";
import { gameAudio } from "../audio";
import { touchState } from "../input";

export class PauseScene extends Phaser.Scene {
  constructor() {
    super("Pause");
  }

  create(): void {
    const shade = this.add.rectangle(VIEW.WIDTH / 2, VIEW.HEIGHT / 2, VIEW.WIDTH, VIEW.HEIGHT, 0x05080e, 0.72);
    shade.setInteractive(); // bloqueia cliques que atravessariam para o jogo

    this.add
      .text(VIEW.WIDTH / 2, 170, "PAUSADO", {
        fontFamily: "monospace",
        fontSize: "34px",
        color: "#f2f7ff",
      })
      .setOrigin(0.5);

    this.makeButton(VIEW.WIDTH / 2, 260, "CONTINUAR  (ESC)", () => this.resumeGame());
    this.makeButton(VIEW.WIDTH / 2, 316, "RECOMEÇAR FASE", () => {
      gameAudio.play("ui", 0.6);
      this.scene.stop("Game");
      this.scene.start("Game");
      touchState.reset();
    });
    this.makeButton(VIEW.WIDTH / 2, 372, "SAIR PARA O TÍTULO", () => {
      gameAudio.play("ui", 0.6);
      this.scene.stop("Game");
      this.scene.start("Title");
      touchState.reset();
    });

    this.input.keyboard!.on("keydown-ESC", this.resumeGame, this);
    this.input.keyboard!.on("keydown-P", this.resumeGame, this);
  }

  private resumeGame(): void {
    gameAudio.play("ui", 0.5);
    this.scene.resume("Game");
    this.scene.stop();
  }

  private makeButton(x: number, y: number, label: string, cb: () => void): void {
    const txt = this.add
      .text(x, y, label, {
        fontFamily: "monospace",
        fontSize: "18px",
        color: "#cfe3ff",
        backgroundColor: "#14273d",
        padding: { x: 22, y: 12 },
      })
      .setOrigin(0.5)
      .setInteractive({ useHandCursor: true });
    txt.on("pointerover", () => txt.setColor("#ffffff").setBackgroundColor("#1d3a5c"));
    txt.on("pointerout", () => txt.setColor("#cfe3ff").setBackgroundColor("#14273d"));
    txt.on("pointerdown", cb);
  }
}
