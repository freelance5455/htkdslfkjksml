import * as THREE from 'three';

// Общие утилиты материалов
export function mat(color, opts = {}) {
  return new THREE.MeshStandardMaterial({ color, roughness: 0.75, metalness: 0.05, ...opts });
}

function shadowed(mesh) { mesh.castShadow = true; mesh.receiveShadow = true; return mesh; }

// ---------------- ПЕРСОНАЖ (игрок / работник) ----------------
export function makeCharacter({ shirt = 0x2e9e5b, pants = 0x2b3a55, skin = 0xe8b88a, cap = 0x1d7dd8 } = {}) {
  const g = new THREE.Group();
  const parts = {};

  const skinM = mat(skin, { roughness: 0.6 });
  const shirtM = mat(shirt);
  const pantsM = mat(pants);

  // Ноги
  const legGeo = new THREE.CapsuleGeometry(0.09, 0.34, 3, 8);
  parts.legL = new THREE.Mesh(legGeo, pantsM);
  parts.legR = new THREE.Mesh(legGeo, pantsM);
  parts.legL.position.set(-0.13, 0.36, 0);
  parts.legR.position.set(0.13, 0.36, 0);
  // Ботинки
  const bootGeo = new THREE.BoxGeometry(0.16, 0.1, 0.26);
  const bootM = mat(0x22262e, { roughness: 0.5 });
  const bootL = new THREE.Mesh(bootGeo, bootM); bootL.position.set(0, -0.2, 0.04);
  const bootR = bootL.clone();
  parts.legL.add(bootL); parts.legR.add(bootR);

  // Торс
  const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.21, 0.34, 4, 10), shirtM);
  torso.position.y = 0.86;
  parts.torso = torso;

  // Руки
  const armGeo = new THREE.CapsuleGeometry(0.07, 0.3, 3, 8);
  parts.armL = new THREE.Mesh(armGeo, shirtM);
  parts.armR = new THREE.Mesh(armGeo, shirtM);
  parts.armL.position.set(-0.3, 1.02, 0);
  parts.armR.position.set(0.3, 1.02, 0);
  const handGeo = new THREE.SphereGeometry(0.075, 8, 8);
  const handL = new THREE.Mesh(handGeo, skinM); handL.position.y = -0.22;
  const handR = handL.clone();
  parts.armL.add(handL); parts.armR.add(handR);
  // Губка в правой руке
  const sponge = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.07, 0.11), mat(0xf7d54a, { roughness: 0.9 }));
  sponge.position.set(0, -0.26, 0.06);
  parts.armR.add(sponge);

  // Голова
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.19, 14, 12), skinM);
  head.position.y = 1.36;
  parts.head = head;
  // Глаза
  const eyeGeo = new THREE.SphereGeometry(0.028, 6, 6);
  const eyeM = mat(0x1c1c22, { roughness: 0.3 });
  const eyeL = new THREE.Mesh(eyeGeo, eyeM); eyeL.position.set(-0.07, 0.03, 0.165);
  const eyeR = eyeL.clone(); eyeR.position.x = 0.07;
  head.add(eyeL, eyeR);
  // Кепка
  const capM = mat(cap, { roughness: 0.55 });
  const capTop = new THREE.Mesh(new THREE.SphereGeometry(0.2, 12, 8, 0, Math.PI * 2, 0, Math.PI / 2), capM);
  capTop.position.y = 0.06;
  const brim = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.2, 0.03, 12, 1, false, -Math.PI / 2.6, Math.PI / 1.3), capM);
  brim.position.set(0, 0.07, 0.12);
  head.add(capTop, brim);

  g.add(parts.legL, parts.legR, torso, parts.armL, parts.armR, head);
  g.traverse(o => { if (o.isMesh) shadowed(o); });
  g.userData.parts = parts;
  return g;
}

// Анимация ходьбы/бездействия
export function animateCharacter(g, time, speed) {
  const p = g.userData.parts;
  const t = time * 9;
  const swing = Math.min(speed / 3.2, 1) * 0.55;
  p.legL.rotation.x = Math.sin(t) * swing;
  p.legR.rotation.x = -Math.sin(t) * swing;
  p.armL.rotation.x = -Math.sin(t) * swing * 0.8;
  p.armR.rotation.x = Math.sin(t) * swing * 0.8;
  const idle = Math.sin(time * 2.2) * 0.02;
  p.torso.position.y = 0.86 + Math.abs(Math.sin(t)) * swing * 0.06 + idle;
  p.head.position.y = 1.36 + idle;
}

// Анимация мойки (рука трёт)
export function animateWashing(g, time) {
  const p = g.userData.parts;
  p.armR.rotation.x = -1.5 + Math.sin(time * 11) * 0.5;
  p.armR.rotation.z = Math.cos(time * 11) * 0.35;
  p.torso.rotation.x = 0.12;
}

export function resetWashPose(g) {
  const p = g.userData.parts;
  p.armR.rotation.z = 0;
  p.torso.rotation.x = 0;
}

// ---------------- АВТОМОБИЛЬ ----------------
const CAR_COLORS = [0xd64545, 0x3f7fd9, 0x3fbf5a, 0xe8b93a, 0x9b59d0, 0xe87f30, 0x4ec9c9, 0xdadfe6];

export function makeCar(colorIndex = 0) {
  const g = new THREE.Group();
  const color = CAR_COLORS[colorIndex % CAR_COLORS.length];
  const bodyM = mat(color, { roughness: 0.32, metalness: 0.45 });
  const glassM = mat(0x1a2836, { roughness: 0.08, metalness: 0.6 });
  const darkM = mat(0x1e2229, { roughness: 0.6 });

  // Нижний корпус
  const hull = new THREE.Mesh(new THREE.BoxGeometry(1.7, 0.5, 3.6), bodyM);
  hull.position.y = 0.52;
  // Скругление капота/багажника
  const nose = new THREE.Mesh(new THREE.BoxGeometry(1.66, 0.34, 0.5), bodyM);
  nose.position.set(0, 0.44, 1.95);
  const tail = nose.clone(); tail.position.z = -1.95;

  // Кабина
  const cabin = new THREE.Mesh(new THREE.BoxGeometry(1.5, 0.46, 1.9), glassM);
  cabin.position.set(0, 0.98, -0.15);
  const roof = new THREE.Mesh(new THREE.BoxGeometry(1.44, 0.09, 1.6), bodyM);
  roof.position.set(0, 1.24, -0.15);

  // Колёса
  const wheelGeo = new THREE.CylinderGeometry(0.34, 0.34, 0.24, 14);
  wheelGeo.rotateZ(Math.PI / 2);
  const hubGeo = new THREE.CylinderGeometry(0.15, 0.15, 0.26, 10);
  hubGeo.rotateZ(Math.PI / 2);
  const hubM = mat(0xb8bfc9, { roughness: 0.3, metalness: 0.7 });
  const wheels = [];
  for (const [x, z] of [[-0.82, 1.15], [0.82, 1.15], [-0.82, -1.15], [0.82, -1.15]]) {
    const w = new THREE.Mesh(wheelGeo, darkM);
    w.position.set(x, 0.34, z);
    const hub = new THREE.Mesh(hubGeo, hubM);
    w.add(hub);
    wheels.push(w); g.add(w);
  }

  // Фары и стопы
  const lightM = mat(0xfff6c9, { emissive: 0xffeeaa, emissiveIntensity: 0.7, roughness: 0.2 });
  const stopM = mat(0xd92020, { emissive: 0xaa1010, emissiveIntensity: 0.6, roughness: 0.3 });
  const lGeo = new THREE.BoxGeometry(0.3, 0.12, 0.06);
  for (const x of [-0.55, 0.55]) {
    const fl = new THREE.Mesh(lGeo, lightM); fl.position.set(x, 0.55, 2.19); g.add(fl);
    const sl = new THREE.Mesh(lGeo, stopM); sl.position.set(x, 0.55, -2.19); g.add(sl);
  }
  // Бамперы
  const bumpGeo = new THREE.BoxGeometry(1.76, 0.16, 0.18);
  const bumpM = mat(0x2b3038, { roughness: 0.5 });
  const bf = new THREE.Mesh(bumpGeo, bumpM); bf.position.set(0, 0.3, 2.14); g.add(bf);
  const bb = bf.clone(); bb.position.z = -2.14; g.add(bb);

  g.add(hull, nose, tail, cabin, roof);
  g.traverse(o => { if (o.isMesh) shadowed(o); });
  g.userData = { wheels, bodyMaterial: bodyM, cleanColor: new THREE.Color(color), dirtyColor: new THREE.Color(color).multiplyScalar(0.55) };
  return g;
}

// ---------------- АРКА МОЙКИ ----------------
export function makeWashArch() {
  const g = new THREE.Group();
  const colM = mat(0x2f6db3, { roughness: 0.4, metalness: 0.3 });
  const accentM = mat(0xf5c542, { roughness: 0.45 });

  // Колонны
  const colGeo = new THREE.BoxGeometry(0.5, 3.1, 0.6);
  const colL = new THREE.Mesh(colGeo, colM); colL.position.set(-2.1, 1.55, 0);
  const colR = new THREE.Mesh(colGeo, colM); colR.position.set(2.1, 1.55, 0);
  // Балка
  const beam = new THREE.Mesh(new THREE.BoxGeometry(4.9, 0.6, 0.8), colM);
  beam.position.y = 3.3;
  const stripe = new THREE.Mesh(new THREE.BoxGeometry(4.9, 0.16, 0.84), accentM);
  stripe.position.y = 3.06;
  // Боковые щётки (вращаются при мойке)
  const brushM = mat(0x3fa9f5, { roughness: 0.9 });
  const brushGeo = new THREE.CylinderGeometry(0.42, 0.42, 2.4, 10);
  const brushL = new THREE.Mesh(brushGeo, brushM); brushL.position.set(-1.55, 1.35, 0);
  const brushR = new THREE.Mesh(brushGeo, brushM); brushR.position.set(1.55, 1.35, 0);
  // Верхняя щётка
  const brushT = new THREE.Mesh(new THREE.CylinderGeometry(0.34, 0.34, 3.4, 10).rotateZ(Math.PI / 2), brushM);
  brushT.position.y = 2.6;
  brushT.userData.spinAxis = 'x'; // ось вдоль X — крутим вокруг X

  // Подиум
  const pad = new THREE.Mesh(new THREE.BoxGeometry(4.6, 0.12, 6.4), mat(0x9aa4ae, { roughness: 0.85 }));
  pad.position.y = 0.06;
  // Полосы разметки
  const lineM = mat(0xf5c542, { roughness: 0.8 });
  for (const x of [-1.9, 1.9]) {
    const line = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.02, 6.0), lineM);
    line.position.set(x, 0.13, 0);
    g.add(line);
  }

  g.add(colL, colR, beam, stripe, brushL, brushR, brushT, pad);
  g.traverse(o => { if (o.isMesh) shadowed(o); });
  g.userData.brushes = [brushL, brushR, brushT];
  return g;
}

// ---------------- КИОСК-ОФИС ----------------
function makeTextSprite(text, { size = 64, fg = '#ffffff', bg = '#1d7dd8', pad = 18 } = {}) {
  const cv = document.createElement('canvas');
  const ctx = cv.getContext('2d');
  ctx.font = `900 ${size}px 'Trebuchet MS', sans-serif`;
  const w = Math.ceil(ctx.measureText(text).width) + pad * 2;
  cv.width = w; cv.height = size + pad * 2;
  ctx.fillStyle = bg;
  ctx.beginPath();
  ctx.roundRect(0, 0, cv.width, cv.height, 22);
  ctx.fill();
  ctx.font = `900 ${size}px 'Trebuchet MS', sans-serif`;
  ctx.fillStyle = fg;
  ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  ctx.fillText(text, cv.width / 2, cv.height / 2 + 2);
  const tex = new THREE.CanvasTexture(cv);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

export function makeKiosk() {
  const g = new THREE.Group();
  const wallM = mat(0xe8e2d5, { roughness: 0.8 });
  const base = new THREE.Mesh(new THREE.BoxGeometry(3.4, 2.3, 2.6), wallM);
  base.position.y = 1.15;
  const roofM = mat(0xd64545, { roughness: 0.55 });
  const roof = new THREE.Mesh(new THREE.BoxGeometry(3.9, 0.28, 3.1), roofM);
  roof.position.y = 2.44;
  // Окно-касса
  const win = new THREE.Mesh(new THREE.BoxGeometry(1.6, 0.9, 0.08), mat(0x22384e, { roughness: 0.1, metalness: 0.5 }));
  win.position.set(0, 1.35, 1.32);
  // Прилавок
  const counter = new THREE.Mesh(new THREE.BoxGeometry(1.9, 0.1, 0.4), mat(0x8a6a45, { roughness: 0.7 }));
  counter.position.set(0, 0.95, 1.45);
  // Дверь
  const door = new THREE.Mesh(new THREE.BoxGeometry(0.8, 1.7, 0.08), mat(0x6a4a2f, { roughness: 0.7 }));
  door.position.set(-1.1, 0.85, 1.31);
  // Вывеска
  const signTex = makeTextSprite('МОЙКА 24', { size: 72, bg: '#1d7dd8' });
  const sign = new THREE.Mesh(new THREE.PlaneGeometry(3.0, 1.0),
    new THREE.MeshBasicMaterial({ map: signTex, transparent: true }));
  sign.position.set(0, 3.15, 1.0);
  sign.rotation.x = -0.12;
  const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 0.7), mat(0x555f6a, { metalness: 0.5, roughness: 0.4 }));
  pole.position.set(0, 2.7, 0.95);

  g.add(base, roof, win, counter, door, sign, pole);
  g.traverse(o => { if (o.isMesh) shadowed(o); });
  return g;
}

// ---------------- ОКРУЖЕНИЕ ----------------
export function makeTree(rand) {
  const g = new THREE.Group();
  const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.2, 1.1, 7), mat(0x7a5230, { roughness: 0.95 }));
  trunk.position.y = 0.55;
  g.add(trunk);
  const greens = [0x3f8f4f, 0x4da35a, 0x357a42];
  const c = greens[Math.floor(rand() * greens.length)];
  let y = 1.2;
  for (let i = 0; i < 3; i++) {
    const r = 0.9 - i * 0.24;
    const cone = new THREE.Mesh(new THREE.ConeGeometry(r, 0.95, 8), mat(c, { roughness: 0.9 }));
    cone.position.y = y + i * 0.62;
    g.add(cone);
  }
  g.traverse(o => { if (o.isMesh) shadowed(o); });
  const s = 0.8 + rand() * 0.7;
  g.scale.setScalar(s);
  return g;
}

export function makeBush(rand) {
  const b = new THREE.Mesh(new THREE.SphereGeometry(0.45 + rand() * 0.25, 8, 6),
    mat(rand() > 0.5 ? 0x4da35a : 0x5db768, { roughness: 0.95 }));
  b.position.y = 0.35;
  b.scale.y = 0.75;
  return shadowed(b);
}

export function makeCloud() {
  const g = new THREE.Group();
  const m = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 1, transparent: true, opacity: 0.92 });
  for (const [x, y, z, s] of [[0, 0, 0, 1.6], [1.4, 0.15, 0.2, 1.1], [-1.4, 0.1, -0.1, 1.2], [0.4, 0.5, 0, 1.0]]) {
    const p = new THREE.Mesh(new THREE.SphereGeometry(s, 10, 8), m);
    p.position.set(x, y, z);
    p.scale.y = 0.55;
    g.add(p);
  }
  return g;
}

// Ведро с водой — декоративный реквизит у мойки
export function makeBucket() {
  const g = new THREE.Group();
  const b = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.22, 0.4, 10), mat(0x3fa9f5, { roughness: 0.5 }));
  b.position.y = 0.2;
  const water = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.24, 0.04, 10),
    mat(0x8fd0ff, { roughness: 0.1, metalness: 0.2 }));
  water.position.y = 0.38;
  g.add(b, water);
  g.traverse(o => { if (o.isMesh) shadowed(o); });
  return g;
}
