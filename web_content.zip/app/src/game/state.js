// Экономика, улучшения, задания и сохранение прогресса (localStorage)
const SAVE_KEY = 'empire_world_3d_save_v1';

export const UPGRADES = [
  {
    id: 'speed', icon: '⚡', name: 'Скорость мойки',
    desc: lvl => `Вы и работники моете быстрее. Текущий бонус: +${lvl * 35}%`,
    costs: [150, 320, 650, 1300, 2600],
  },
  {
    id: 'price', icon: '💰', name: 'Премиум-услуга',
    desc: lvl => `Цена за мойку выше. Сейчас: ${60 + lvl * 30} сом`,
    costs: [200, 450, 900, 1800, 3600],
  },
  {
    id: 'slot2', icon: '🅿️', name: 'Место мойки №2',
    desc: () => 'Открывает второй пост — обслуживайте две машины сразу',
    costs: [500],
  },
  {
    id: 'slot3', icon: '🅿️', name: 'Место мойки №3',
    desc: () => 'Третий пост для максимального потока клиентов',
    costs: [2200],
  },
  {
    id: 'worker1', icon: '🧑‍🔧', name: 'Работник Айбек',
    desc: () => 'Моет машины сам, пока вы занимаетесь развитием',
    costs: [900],
  },
  {
    id: 'worker2', icon: '🧑‍🔧', name: 'Работник Мирлан',
    desc: () => 'Второй помощник — вместе они моют вдвое больше',
    costs: [3200],
  },
];

export const TASKS = [
  { id: 'wash3', text: 'Обслужите 3 автомобиля', goal: 3, stat: 'cars', reward: 150 },
  { id: 'earn500', text: 'Заработайте 500 сом', goal: 500, stat: 'earned', reward: 200 },
  { id: 'slot2', text: 'Откройте 2-е место мойки', goal: 1, stat: 'slots2', reward: 400 },
  { id: 'wash10', text: 'Обслужите 10 автомобилей', goal: 10, stat: 'cars', reward: 350 },
  { id: 'worker1', text: 'Наймите первого работника', goal: 1, stat: 'workers', reward: 600 },
  { id: 'earn2500', text: 'Заработайте 2 500 сом', goal: 2500, stat: 'earned', reward: 700 },
  { id: 'slot3', text: 'Откройте 3-е место мойки', goal: 1, stat: 'slots3', reward: 1500 },
  { id: 'wash30', text: 'Обслужите 30 автомобилей', goal: 30, stat: 'cars', reward: 2000 },
  { id: 'earn8000', text: 'Заработайте 8 000 сом', goal: 8000, stat: 'earned', reward: 3000 },
  { id: 'wash75', text: 'Обслужите 75 автомобилей', goal: 75, stat: 'cars', reward: 8000 },
];

export class GameState {
  constructor() {
    this.money = 0;
    this.levels = { speed: 0, price: 0, slot2: 0, slot3: 0, worker1: 0, worker2: 0 };
    this.stats = { cars: 0, earned: 0 };
    this.taskIndex = 0;
    this.started = false;
  }

  // ——— Производные величины ———
  get washPrice() { return 60 + this.levels.price * 30; }
  get washRate() { return 0.5 * (1 + this.levels.speed * 0.35); } // доля мойки в секунду
  get slotsUnlocked() { return 1 + this.levels.slot2 + this.levels.slot3; }
  get workers() { return this.levels.worker1 + this.levels.worker2; }

  statValue(stat) {
    if (stat === 'cars') return this.stats.cars;
    if (stat === 'earned') return this.stats.earned;
    if (stat === 'workers') return this.workers;
    if (stat === 'slots2') return this.slotsUnlocked >= 2 ? 1 : 0;
    if (stat === 'slots3') return this.slotsUnlocked >= 3 ? 1 : 0;
    return 0;
  }

  get currentTask() { return TASKS[this.taskIndex] || null; }

  addMoney(n) {
    this.money += n;
    if (n > 0) this.stats.earned += n;
  }

  canBuy(id) {
    const u = UPGRADES.find(x => x.id === id);
    const lvl = this.levels[id];
    if (lvl >= u.costs.length) return { ok: false, maxed: true };
    const cost = u.costs[lvl];
    // Место №3 требует место №2; работник №2 требует №1
    if (id === 'slot3' && !this.levels.slot2) return { ok: false, locked: 'Сначала откройте место №2' };
    if (id === 'worker2' && !this.levels.worker1) return { ok: false, locked: 'Сначала наймите Айбека' };
    return { ok: this.money >= cost, cost };
  }

  buy(id) {
    const check = this.canBuy(id);
    if (!check.ok || check.maxed) return false;
    this.money -= check.cost;
    this.levels[id]++;
    return true;
  }

  /** Проверяет текущее задание; возвращает выполненное задание или null */
  checkTask() {
    const task = this.currentTask;
    if (!task) return null;
    if (this.statValue(task.stat) >= task.goal) {
      this.addMoney(task.reward);
      this.taskIndex++;
      return task;
    }
    return null;
  }

  // ——— Сохранение ———
  save() {
    try {
      localStorage.setItem(SAVE_KEY, JSON.stringify({
        money: this.money, levels: this.levels, stats: this.stats,
        taskIndex: this.taskIndex, started: this.started,
      }));
    } catch (e) { /* приватный режим — играем без сохранения */ }
  }

  load() {
    try {
      const raw = localStorage.getItem(SAVE_KEY);
      if (!raw) return false;
      const d = JSON.parse(raw);
      this.money = d.money ?? 0;
      Object.assign(this.levels, d.levels || {});
      Object.assign(this.stats, d.stats || {});
      this.taskIndex = Math.min(d.taskIndex ?? 0, TASKS.length);
      this.started = !!d.started;
      return true;
    } catch (e) { return false; }
  }

  reset() {
    try { localStorage.removeItem(SAVE_KEY); } catch (e) {}
  }
}

export function fmtMoney(n) {
  return Math.floor(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
}
