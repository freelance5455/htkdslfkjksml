/**
 * effects.ts — pooled combat visuals: bullet tracers, muzzle flashes, impact sparks,
 * flesh hits and grenade explosions. Zero per-frame allocation: fixed pools, reused buffers.
 */

import * as THREE from "three";
import { COLORS } from "./config";

const TRACER_POOL = 28;
const PARTICLE_POOL = 320;
const FLASH_POOL = 3;
const EXPLOSION_POOL = 3;

interface Tracer { alive: boolean; life: number; mesh: THREE.Mesh }
interface Particle { alive: boolean; life: number; maxLife: number; vx: number; vy: number; vz: number }

export class Effects {
  private tracers: Tracer[] = [];
  private particles: Particle[] = [];
  private flashes: { alive: boolean; life: number; light: THREE.PointLight; sprite: THREE.Sprite }[] = [];
  private explosions: { alive: boolean; life: number; maxLife: number; sphere: THREE.Mesh; ring: THREE.Mesh; light: THREE.PointLight }[] = [];

  private points: THREE.Points;
  private posAttr: THREE.BufferAttribute;
  private colAttr: THREE.BufferAttribute;

  constructor(private scene: THREE.Scene, particleBudget: number) {
    const budget = Math.min(particleBudget, PARTICLE_POOL);

    // ---- tracers: stretched additive boxes ----
    const tGeo = new THREE.CylinderGeometry(0.012, 0.012, 1, 4, 1, true);
    tGeo.translate(0, 0.5, 0); // origin at base so scale.y = length
    const tMat = new THREE.MeshBasicMaterial({ color: COLORS.muzzle, transparent: true, opacity: 0.9, blending: THREE.AdditiveBlending, depthWrite: false });
    for (let i = 0; i < TRACER_POOL; i++) {
      const mesh = new THREE.Mesh(tGeo, tMat.clone());
      mesh.visible = false;
      scene.add(mesh);
      this.tracers.push({ alive: false, life: 0, mesh });
    }

    // ---- particles: one Points cloud ----
    const geo = new THREE.BufferGeometry();
    const positions = new Float32Array(budget * 3);
    const colors = new Float32Array(budget * 3);
    for (let i = 0; i < budget; i++) positions[i * 3 + 1] = -999;
    this.posAttr = new THREE.BufferAttribute(positions, 3);
    this.colAttr = new THREE.BufferAttribute(colors, 3);
    geo.setAttribute("position", this.posAttr);
    geo.setAttribute("color", this.colAttr);
    const mat = new THREE.PointsMaterial({ size: 0.09, vertexColors: true, transparent: true, opacity: 0.95, depthWrite: false });
    this.points = new THREE.Points(geo, mat);
    this.points.frustumCulled = false;
    scene.add(this.points);
    for (let i = 0; i < budget; i++) {
      this.particles.push({ alive: false, life: 0, maxLife: 1, vx: 0, vy: 0, vz: 0 });
    }

    // ---- muzzle flashes: sprite + pooled point light ----
    const flashTex = makeFlashTexture();
    for (let i = 0; i < FLASH_POOL; i++) {
      const light = new THREE.PointLight(COLORS.muzzle, 0, 9, 2);
      scene.add(light);
      const sprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: flashTex, color: 0xffd9a0, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false }));
      sprite.visible = false;
      scene.add(sprite);
      this.flashes.push({ alive: false, life: 0, light, sprite });
    }

    // ---- explosions ----
    const eGeo = new THREE.SphereGeometry(1, 14, 10);
    const eMat = new THREE.MeshBasicMaterial({ color: 0xffb35c, transparent: true, opacity: 0.9, blending: THREE.AdditiveBlending, depthWrite: false });
    const rGeo = new THREE.RingGeometry(0.85, 1, 28);
    rGeo.rotateX(-Math.PI / 2);
    for (let i = 0; i < EXPLOSION_POOL; i++) {
      const sphere = new THREE.Mesh(eGeo, eMat.clone());
      const ring = new THREE.Mesh(rGeo, new THREE.MeshBasicMaterial({ color: 0xffcf8a, transparent: true, opacity: 0.7, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide }));
      const light = new THREE.PointLight(0xff8a3c, 0, 22, 1.6);
      sphere.visible = ring.visible = false;
      scene.add(sphere, ring, light);
      this.explosions.push({ alive: false, life: 0, maxLife: 1.15, sphere, ring, light });
    }
  }

  /** Bright streak from muzzle to hit point. */
  tracer(from: THREE.Vector3, to: THREE.Vector3, color: number = COLORS.muzzle): void {
    const t = this.tracers.find((x) => !x.alive) ?? this.tracers[0];
    t.alive = true;
    t.life = 0.07;
    const len = from.distanceTo(to);
    t.mesh.position.copy(from);
    t.mesh.scale.set(1, Math.max(0.1, len), 1);
    t.mesh.lookAt(to);
    t.mesh.rotateX(Math.PI / 2); // cylinder +Y axis → toward target
    (t.mesh.material as THREE.MeshBasicMaterial).color.setHex(color);
    t.mesh.visible = true;
  }

  muzzleFlash(pos: THREE.Vector3, intensity = 26): void {
    const f = this.flashes.find((x) => !x.alive) ?? this.flashes[0];
    f.alive = true;
    f.life = 0.055;
    f.light.position.copy(pos);
    f.light.intensity = intensity;
    f.sprite.position.copy(pos);
    f.sprite.scale.setScalar(0.5 + Math.random() * 0.25);
    f.sprite.material.rotation = Math.random() * Math.PI;
    f.sprite.visible = true;
  }

  /** Sparks on stone / dust on flesh. */
  impact(pos: THREE.Vector3, flesh: boolean): void {
    const base = flesh ? new THREE.Color(0xb03028) : new THREE.Color(0xd8c9a3);
    this.burst(pos, base, flesh ? 10 : 7, flesh ? 2.2 : 3.4, flesh ? 0.5 : 0.35);
  }

  explosion(pos: THREE.Vector3): void {
    const e = this.explosions.find((x) => !x.alive) ?? this.explosions[0];
    e.alive = true;
    e.life = e.maxLife;
    e.sphere.position.copy(pos);
    e.ring.position.set(pos.x, 0.12, pos.z);
    e.light.position.set(pos.x, pos.y + 0.6, pos.z);
    e.light.intensity = 160;
    e.sphere.visible = e.ring.visible = true;
    this.burst(pos, new THREE.Color(0xffa050), 46, 9, 0.8);
    this.burst(pos, new THREE.Color(0x554a3a), 24, 5, 1.3);
  }

  private burst(pos: THREE.Vector3, color: THREE.Color, count: number, speed: number, life: number): void {
    const positions = this.posAttr.array as Float32Array;
    const colors = this.colAttr.array as Float32Array;
    let spawned = 0;
    for (let i = 0; i < this.particles.length && spawned < count; i++) {
      const p = this.particles[i];
      if (p.alive) continue;
      p.alive = true;
      p.life = p.maxLife = life * (0.6 + Math.random() * 0.7);
      const a = Math.random() * Math.PI * 2;
      const up = Math.random() * 0.9 + 0.2;
      p.vx = Math.cos(a) * speed * Math.random();
      p.vz = Math.sin(a) * speed * Math.random();
      p.vy = up * speed * 0.55;
      positions[i * 3] = pos.x;
      positions[i * 3 + 1] = pos.y;
      positions[i * 3 + 2] = pos.z;
      colors[i * 3] = color.r;
      colors[i * 3 + 1] = color.g;
      colors[i * 3 + 2] = color.b;
      spawned++;
    }
  }

  update(dt: number): void {
    for (const t of this.tracers) {
      if (!t.alive) continue;
      t.life -= dt;
      if (t.life <= 0) { t.alive = false; t.mesh.visible = false; }
    }
    const positions = this.posAttr.array as Float32Array;
    for (let i = 0; i < this.particles.length; i++) {
      const p = this.particles[i];
      if (!p.alive) continue;
      p.life -= dt;
      if (p.life <= 0) {
        p.alive = false;
        positions[i * 3 + 1] = -999;
        continue;
      }
      p.vy -= 12 * dt;
      positions[i * 3] += p.vx * dt;
      positions[i * 3 + 1] = Math.max(0.02, positions[i * 3 + 1] + p.vy * dt);
      positions[i * 3 + 2] += p.vz * dt;
    }
    this.posAttr.needsUpdate = true;
    this.colAttr.needsUpdate = true;

    for (const f of this.flashes) {
      if (!f.alive) continue;
      f.life -= dt;
      f.light.intensity *= 0.7;
      if (f.life <= 0) { f.alive = false; f.light.intensity = 0; f.sprite.visible = false; }
    }
    for (const e of this.explosions) {
      if (!e.alive) continue;
      e.life -= dt;
      const k = Math.min(1, 1 - e.life / e.maxLife);
      e.sphere.scale.setScalar(0.5 + k * 4.6);
      // slow opacity decay: the fireball stays hot for most of its life
      (e.sphere.material as THREE.MeshBasicMaterial).opacity = 0.95 * Math.pow(1 - k, 0.55);
      e.ring.scale.setScalar(0.5 + k * 8);
      (e.ring.material as THREE.MeshBasicMaterial).opacity = 0.75 * (1 - k);
      e.light.intensity = 160 * (1 - k) * (1 - k);
      if (e.life <= 0) {
        e.alive = false;
        e.sphere.visible = e.ring.visible = false;
        e.light.intensity = 0;
      }
    }
  }
}

function makeFlashTexture(): THREE.Texture {
  const c = document.createElement("canvas");
  c.width = c.height = 64;
  const g = c.getContext("2d")!;
  const grad = g.createRadialGradient(32, 32, 2, 32, 32, 30);
  grad.addColorStop(0, "rgba(255,240,200,1)");
  grad.addColorStop(0.4, "rgba(255,180,80,0.8)");
  grad.addColorStop(1, "rgba(255,120,20,0)");
  g.fillStyle = grad;
  g.fillRect(0, 0, 64, 64);
  // star spikes
  g.strokeStyle = "rgba(255,220,150,0.9)";
  g.lineWidth = 3;
  g.beginPath(); g.moveTo(32, 2); g.lineTo(32, 62); g.stroke();
  g.beginPath(); g.moveTo(2, 32); g.lineTo(62, 32); g.stroke();
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}
