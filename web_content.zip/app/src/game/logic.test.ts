import { describe, it, expect } from "vitest";
import { QualityGovernor, TIERS, initialTierIndex } from "./quality";
import { Heightfield, RoadIndex, ObstacleGrid, mixHex, smoothstep } from "./spatial";
import { REGIONS, RACES } from "./content";

function simulate(startTier: number, cost: (pr: number, tier: number) => number, seconds: number, cap = 0) {
  const g = new QualityGovernor(startTier, 1.5, 30);
  let t = 0;
  const events: string[] = [];
  while (t < seconds) {
    const ms = cost(g.pixelRatio, g.tier);
    const e = g.sample(ms, cap);
    if (e !== "none") events.push(e);
    t += ms / 1000;
  }
  return { g, events };
}

describe("quality governor", () => {
  it("settles a weak phone under the 30 FPS budget by lowering resolution", () => {
    const { g } = simulate(1, (pr, tier) => 14 * pr * pr * [1.9, 1.4, 1][tier] + 8, 40);
    expect(g.avgMs < 34).toBe(true);
  });
  it("drops a whole tier on a very weak phone", () => {
    const { g } = simulate(1, (pr, tier) => 30 * pr * pr * [1.9, 1.4, 1][tier] + 14, 60);
    expect(g.tier).toBe(2);
  });
  it("promotes a strong phone and never downgrades it on rare hiccups", () => {
    let n = 0;
    const { g, events } = simulate(1, () => (++n % 200 === 0 ? 120 : 14), 30);
    expect(g.tier <= 1).toBe(true);
    expect(events.includes("tier-down")).toBe(false);
  });
  it("does not mistake a deliberate 30 FPS cap for slowness", () => {
    const { g } = simulate(2, () => 33.3, 30, 33.3);
    expect(g.tier).toBe(2);
  });
  it("starts weaker devices on lower tiers", () => {
    expect(initialTierIndex({ cores: 8, memoryGb: 3, mobile: true, dpr: 2 })).toBe(2);
    expect(initialTierIndex({ cores: 8, memoryGb: 0, mobile: false, dpr: 1 })).toBe(0);
    expect(TIERS.length).toBe(3);
  });
});

describe("terrain, roads and obstacles", () => {
  const fin = REGIONS.find((r) => r.id === "finland")!;
  const route = RACES.find((r) => r.id === "finnish-lake")!.route;
  const lakes = [{ x: 0, z: 0, r: 52 }, { x: -260, z: 150, r: 64 }, { x: 250, z: -180, r: 70 }, { x: 262, z: 225, r: 48 }];

  it("keeps the Finnish route dry while the lakes exist", () => {
    const hf = new Heightfield({ hillScale: fin.hillScale, hillFreq: fin.hillFreq, highlandBias: fin.highlandBias });
    let minRoad = Infinity;
    const samples: Array<[number, number]> = [];
    for (let i = 0; i < route.length - 1; i++) for (let t = 0; t <= 1; t += 0.02) {
      samples.push([route[i][0] + (route[i + 1][0] - route[i][0]) * t, route[i][1] + (route[i + 1][1] - route[i][1]) * t]);
    }
    for (const [x, z] of samples) minRoad = Math.min(minRoad, hf.baseHeight(x, z) + 0.12);
    hf.waterY = minRoad - 0.67;
    hf.lakes = lakes;
    expect(hf.isWater(0, 0)).toBe(true);
    expect(samples.filter(([x, z]) => hf.isWater(x, z)).length).toBe(0);
  });
  it("road index finds nearby road points only", () => {
    const ri = new RoadIndex(28);
    for (let x = -100; x <= 100; x += 3) ri.add(x, 50);
    expect(ri.near(0, 57, 8.2)).toBe(true);
    expect(ri.near(0, 70, 8.2)).toBe(false);
  });
  it("obstacle grid queries stay local", () => {
    const og = new ObstacleGrid(24);
    for (let i = 0; i < 5000; i++) og.add({ x: (i % 100) * 8 - 400, z: Math.floor(i / 100) * 8 - 200, radius: 0.5 });
    let visited = 0;
    og.forEachNear(0, 0, () => { visited++; });
    expect(visited < 120).toBe(true);
    expect(og.blocked(-400, -200, 0.1)).toBe(true);
  });
  it("colour and easing helpers", () => {
    expect(mixHex(0x000000, 0xffffff, 0.5)).toBe(0x808080);
    expect(smoothstep(-1)).toBe(0);
    expect(smoothstep(2)).toBe(1);
  });
});
