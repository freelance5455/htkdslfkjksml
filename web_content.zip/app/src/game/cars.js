import * as THREE from 'three';
import { makeCar } from './models.js';
import { ProgressBar } from './effects.js';
import { LAYOUT } from './world.js';

const _dir = new THREE.Vector3();
let carSeq = 0;

class Car {
  constructor(scene, slotIndex, colorIndex) {
    this.mesh = makeCar(colorIndex);
    this.mesh.userData.bodyMaterial.color.copy(this.mesh.userData.dirtyColor); // грязная
    this.slotIndex = slotIndex;
    this.progress = 0;
    this.washer = null;   // 'player' | worker object | null
    this.foam = null;
    this.doneTimer = 0;
    this.bar = new ProgressBar(this.mesh);

    // Маршрут: появление на дороге → въезд → полоса → место мойки
    const sx = LAYOUT.slotXs[slotIndex];
    this.mesh.position.set(-70, 0, LAYOUT.roadZ + 1.6);
    this.mesh.rotation.y = Math.PI / 2; // смотрит +x
    this.waypoints = [
      new THREE.Vector3(LAYOUT.entryX, 0, LAYOUT.roadZ + 1.6),
      new THREE.Vector3(LAYOUT.entryX, 0, LAYOUT.laneZ),
      new THREE.Vector3(sx, 0, LAYOUT.laneZ),
      new THREE.Vector3(sx, 0, LAYOUT.slotZ),
    ];
    this.wpIndex = 0;
    this.state = 'arrive';
    scene.add(this.mesh);
  }

  leaveRoute() {
    const sx = LAYOUT.slotXs[this.slotIndex];
    this.waypoints = [
      new THREE.Vector3(sx, 0, LAYOUT.laneZ),
      new THREE.Vector3(LAYOUT.exitX, 0, LAYOUT.laneZ),
      new THREE.Vector3(LAYOUT.exitX, 0, LAYOUT.roadZ + 1.6),
      new THREE.Vector3(80, 0, LAYOUT.roadZ + 1.6),
    ];
    this.wpIndex = 0;
    this.state = 'leave';
  }

  drive(dt) {
    const wp = this.waypoints[this.wpIndex];
    if (!wp) return true;
    _dir.subVectors(wp, this.mesh.position); _dir.y = 0;
    const dist = _dir.length();
    if (dist < 0.4) {
      this.wpIndex++;
      return this.wpIndex >= this.waypoints.length;
    }
    _dir.normalize();
    const speed = this.state === 'arrive' || this.state === 'leave' ? (this.wpIndex === 0 || this.wpIndex >= this.waypoints.length - 1 ? 8 : 5) : 5;
    // Плавный поворот к направлению
    const targetAngle = Math.atan2(_dir.x, _dir.z);
    let da = targetAngle - this.mesh.rotation.y;
    while (da > Math.PI) da -= Math.PI * 2;
    while (da < -Math.PI) da += Math.PI * 2;
    this.mesh.rotation.y += THREE.MathUtils.clamp(da, -3.2 * dt, 3.2 * dt);
    // Двигаемся вперёд по носу, когда почти развернулись
    const k = Math.max(0.25, 1 - Math.abs(da) * 0.8);
    this.mesh.position.x += Math.sin(this.mesh.rotation.y) * speed * k * dt;
    this.mesh.position.z += Math.cos(this.mesh.rotation.y) * speed * k * dt;
    // Пробуксовка колёс
    for (const w of this.mesh.userData.wheels) w.rotation.x += speed * k * dt / 0.34;
    return false;
  }
}

export class Traffic {
  constructor(scene, effects) {
    this.scene = scene;
    this.effects = effects;
    this.cars = [];
    this.spawnTimer = 2.2; // первая машина приезжает быстро
    this.slots = LAYOUT.slotXs.map((x, i) => ({ index: i, x, z: LAYOUT.slotZ, car: null }));
  }

  slotUnlocked(i, state) { return i < state.slotsUnlocked; }

  update(dt, time, state, hooks) {
    // ——— Спавн ———
    this.spawnTimer -= dt;
    if (this.spawnTimer <= 0) {
      const free = this.slots.find((s, i) => this.slotUnlocked(i, state) && !s.car);
      if (free) {
        free.car = new Car(this.scene, free.index, carSeq++);
        this.cars.push(free.car);
        this.spawnTimer = Math.max(2.5, 8.5 - state.slotsUnlocked * 1.6 - state.workers * 0.5) * (0.75 + Math.random() * 0.5);
      } else {
        this.spawnTimer = 1.2; // нет мест — проверим позже
      }
    }

    // ——— Машины ———
    for (const car of [...this.cars]) {
      switch (car.state) {
        case 'arrive':
          if (car.drive(dt)) car.state = 'wait';
          break;

        case 'wait':
        case 'washing': {
          if (car.washer) {
            car.state = 'washing';
            const rate = car.washer === 'player' ? state.washRate : state.washRate * 0.55;
            car.progress += rate * dt;
            car.bar.set(car.progress);
            if (!car.foam) car.foam = this.effects.startFoam(car.mesh.position);
            // Вращение щёток арки
            const arch = hooks.arches[car.slotIndex];
            for (const b of arch.userData.brushes) {
              if (b.userData.spinAxis === 'x') b.rotation.x += dt * 9;
              else b.rotation.y += dt * 9;
            }
            if (car.progress >= 1) this._finishWash(car, state, hooks);
          } else {
            car.state = 'wait';
            if (car.foam) { this.effects.stopFoam(car.foam); car.foam = null; }
          }
          break;
        }

        case 'done':
          car.doneTimer -= dt;
          if (car.doneTimer <= 0) {
            this.slots[car.slotIndex].car = null;
            car.leaveRoute();
          }
          break;

        case 'leave':
          if (car.drive(dt)) {
            this.scene.remove(car.mesh);
            this.cars = this.cars.filter(c => c !== car);
          }
          break;
      }
      car.bar.faceCamera(hooks.camera);
    }
  }

  _finishWash(car, state, hooks) {
    car.progress = 1;
    car.bar.set(1);
    car.washer = null;
    if (car.foam) { this.effects.stopFoam(car.foam); car.foam = null; }
    car.mesh.userData.bodyMaterial.color.copy(car.mesh.userData.cleanColor); // чистая!
    car.state = 'done';
    car.doneTimer = 1.0;
    state.stats.cars++;
    const price = state.washPrice;
    // Монетки летят к игроку, деньги начисляются по прибытии
    const targetPos = hooks.playerPos;
    this.effects.coinBurst(car.mesh.position, 5,
      () => targetPos().clone().add(new THREE.Vector3(0, 1, 0)),
      () => {
        state.addMoney(price);
        hooks.onMoney(price, car.mesh.position);
      });
    hooks.onCarWashed(car);
  }

  /** Ближайшая ждущая машина в радиусе r от позиции (для игрока/работников) */
  nearestWaiting(pos, r, exceptCar = null, includeReserved = false) {
    let best = null, bestD = r;
    for (const car of this.cars) {
      if (car.state !== 'wait' || car === exceptCar) continue;
      if (car.reservedBy && !includeReserved) continue;
      const d = car.mesh.position.distanceTo(pos);
      if (d < bestD) { best = car; bestD = d; }
    }
    return best;
  }
}
