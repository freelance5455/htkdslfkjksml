// Ввод: виртуальный джойстик + свайп камеры + клавиатура (для ПК)
export class Input {
  constructor() {
    this.move = { x: 0, y: 0 };   // -1..1, y>0 = вперёд
    this.camDX = 0;               // накопленный поворот камеры за кадр
    this._joyId = null;
    this._lookId = null;
    this._keys = new Set();
  }

  attach(joyEl, knobEl, lookEl) {
    const radius = 44;

    joyEl.addEventListener('pointerdown', e => {
      this._joyId = e.pointerId;
      joyEl.setPointerCapture(e.pointerId);
      this._joyMove(e, joyEl, knobEl, radius);
    });
    joyEl.addEventListener('pointermove', e => {
      if (e.pointerId === this._joyId) this._joyMove(e, joyEl, knobEl, radius);
    });
    const joyEnd = e => {
      if (e.pointerId !== this._joyId) return;
      this._joyId = null;
      this.move.x = 0; this.move.y = 0;
      knobEl.style.transform = 'translate(-50%,-50%)';
    };
    joyEl.addEventListener('pointerup', joyEnd);
    joyEl.addEventListener('pointercancel', joyEnd);

    // Свайп по остальному экрану — обзор камеры
    lookEl.addEventListener('pointerdown', e => {
      if (this._lookId !== null) return;
      this._lookId = e.pointerId;
      this._lookX = e.clientX;
    });
    lookEl.addEventListener('pointermove', e => {
      if (e.pointerId !== this._lookId) return;
      this.camDX += (e.clientX - this._lookX) * 0.006;
      this._lookX = e.clientX;
    });
    const lookEnd = e => { if (e.pointerId === this._lookId) this._lookId = null; };
    lookEl.addEventListener('pointerup', lookEnd);
    lookEl.addEventListener('pointercancel', lookEnd);

    // Клавиатура (WASD / стрелки) — для тестирования на ПК
    addEventListener('keydown', e => this._keys.add(e.code));
    addEventListener('keyup', e => this._keys.delete(e.code));

    // Запрет нежелательных жестов
    document.addEventListener('touchmove', e => e.preventDefault(), { passive: false });
    document.addEventListener('contextmenu', e => e.preventDefault());
    document.addEventListener('dblclick', e => e.preventDefault());
  }

  _joyMove(e, joyEl, knobEl, radius) {
    const r = joyEl.getBoundingClientRect();
    let dx = e.clientX - (r.left + r.width / 2);
    let dy = e.clientY - (r.top + r.height / 2);
    const len = Math.hypot(dx, dy);
    if (len > radius) { dx = dx / len * radius; dy = dy / len * radius; }
    this.move.x = dx / radius;
    this.move.y = -dy / radius; // вверх по экрану = вперёд
    knobEl.style.transform = `translate(calc(-50% + ${dx}px), calc(-50% + ${dy}px))`;
  }

  /** Итоговый вектор движения с учётом клавиатуры */
  getMove() {
    let x = this.move.x, y = this.move.y;
    if (this._keys.has('KeyA') || this._keys.has('ArrowLeft')) x -= 1;
    if (this._keys.has('KeyD') || this._keys.has('ArrowRight')) x += 1;
    if (this._keys.has('KeyW') || this._keys.has('ArrowUp')) y += 1;
    if (this._keys.has('KeyS') || this._keys.has('ArrowDown')) y -= 1;
    const len = Math.hypot(x, y);
    if (len > 1) { x /= len; y /= len; }
    return { x, y };
  }

  /** Забрать накопленный поворот камеры и обнулить */
  takeCamDX() { const v = this.camDX; this.camDX = 0; return v; }
}
