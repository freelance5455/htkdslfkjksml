/**
 * ui.ts — all DOM UI: HUD, menus, dialogue, blacksmith, map, endings.
 * The game drives this imperatively; React is not involved.
 */
import { WORLD } from "./config";
import { ITEMS, WEAPONS, SKILLS, EQUIPMENT, RARITY_COLORS, RARITY_NAMES, MAX_WEAPON_TIER, upgradeCost, WeaponKind, SkillDef, ITEMS as IT } from "./data";
import { QuestState, MAIN_QUESTS, SIDE_QUESTS, ENDINGS, Ending } from "./quests";

export interface HUDData {
  hp: number; maxHp: number; stamina: number; maxStamina: number; mana: number; maxMana: number;
  level: number; xp: number; xpNext: number; gold: number; potions: number;
  zoneName: string; clock: string;
  questTitle: string; questObj: string;
  posX: number; posZ: number; yaw: number;
  enemies: { x: number; z: number; alive: boolean; boss?: boolean }[];
  waystones: { x: number; z: number; discovered: boolean; name: string }[];
  lockOn: boolean; boss: { name: string; hp: number; maxHp: number } | null;
  interactText: string;
  skillQ: string; skillV: string;
  cloak: boolean;
}

export interface UIHandlers {
  onStart: (fresh: boolean) => void;
  onResume: () => void;
  onOpenMenu: () => void;
  onQuitToTitle: () => void;
  onWeaponSelect: (kind: WeaponKind) => void;
  onUpgrade: (kind: WeaponKind) => void;
  onBuySkill: (id: string) => void;
  onCraft: (what: "potion" | "salve" | "crystal") => void;
  onTravel: (id: string) => void;
  onEquip: (id: string) => void;
  onEnding: (id: string) => void;
  onRestart: () => void;
  onQuality: (q: "low" | "medium" | "high" | "ultra") => void;
  onVolume: (v: number) => void;
  onInvertY: (v: boolean) => void;
  onMute: () => boolean;
}

type Screen = "none" | "title" | "pause" | "menu" | "smith" | "dead" | "ending" | "dialogue";

const TABS = ["الأسلحة", "المهارات", "المعدات", "الحقيبة", "الخريطة", "المهمات"] as const;
type Tab = (typeof TABS)[number];

export class UI {
  root: HTMLElement;
  handlers!: UIHandlers;
  private screen: Screen = "none";
  private menuTab: Tab = "الأسلحة";
  private el = (tag: string, cls = "", parent?: HTMLElement, text = ""): HTMLElement => {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text) e.textContent = text;
    (parent ?? this.root).appendChild(e);
    return e;
  };

  // hud refs
  private hpBar!: HTMLElement; private stBar!: HTMLElement; private mpBar!: HTMLElement;
  private xpBar!: HTMLElement; private lvlEl!: HTMLElement; private goldEl!: HTMLElement;
  private zoneEl!: HTMLElement; private clockEl!: HTMLElement;
  private questEl!: HTMLElement; private questObjEl!: HTMLElement;
  private minimap!: HTMLCanvasElement;
  private bossWrap!: HTMLElement; private bossName!: HTMLElement; private bossBar!: HTMLElement;
  private interactEl!: HTMLElement; private notifyWrap!: HTMLElement;
  private skillQEl!: HTMLElement; private skillVEl!: HTMLElement;
  private vignette!: HTMLElement;
  private lockEl!: HTMLElement;

  // overlays
  private overlay!: HTMLElement;
  private dialogueEl!: HTMLElement;
  private dialogueText!: HTMLElement; private dialogueSpeaker!: HTMLElement;
  private dialogueNext!: HTMLElement;
  private dialogueChoicesEl!: HTMLElement;
  private currentLines: { speaker: string; text: string }[] = [];
  private lineIdx = 0;
  onDialogueDone: (() => void) | null = null;
  onChoice: ((effect: string) => void) | null = null;

  private menuData: any = null;
  private lastScreen: Screen = "none";

  constructor(container: HTMLElement) {
    this.root = container;
    this.buildHUD();
    this.overlay = this.el("div", "overlay", this.root);
  }

  // ---------------- HUD ----------------

  private buildHUD(): void {
    const hud = this.el("div", "hud", this.root);

    // top-left: player bars
    const pl = this.el("div", "pl-panel", hud);
    this.lvlEl = this.el("div", "lvl", pl, "1");
    const bars = this.el("div", "bars", pl);
    this.hpBar = this.el("div", "bar hp", bars);
    this.stBar = this.el("div", "bar st", bars);
    this.mpBar = this.el("div", "bar mp", bars);
    const under = this.el("div", "under-bars", pl);
    this.goldEl = this.el("span", "gold", under, "0 ذهب");
    this.el("span", "potion-hint", under, "R جرعة");

    // top-center: zone + clock
    const top = this.el("div", "top-center", hud);
    this.zoneEl = this.el("div", "zone", top, "");
    this.clockEl = this.el("div", "clock", top, "");

    // right: minimap
    const mmWrap = this.el("div", "minimap-wrap", hud);
    this.minimap = this.el("canvas", "minimap", mmWrap) as HTMLCanvasElement;
    this.minimap.width = 180; this.minimap.height = 180;
    this.lockEl = this.el("div", "lockon", mmWrap, "◎ قفل");

    // left-bottom: quest tracker
    const q = this.el("div", "quest-panel", hud);
    this.questEl = this.el("div", "quest-title", q, "");
    this.questObjEl = this.el("div", "quest-obj", q, "");

    // boss bar
    this.bossWrap = this.el("div", "boss-wrap", hud);
    this.bossName = this.el("div", "boss-name", this.bossWrap, "");
    const bb = this.el("div", "boss-bar-outer", this.bossWrap);
    this.bossBar = this.el("div", "boss-bar-inner", bb);

    // interact prompt
    this.interactEl = this.el("div", "interact", hud, "");

    // skill slots bottom-right
    const skills = this.el("div", "skill-slots", hud);
    const q1 = this.el("div", "slot", skills);
    this.el("span", "key", q1, "Q");
    this.skillQEl = this.el("span", "nm", q1, "—");
    const q2 = this.el("div", "slot", skills);
    this.el("span", "key", q2, "V");
    this.skillVEl = this.el("span", "nm", q2, "—");

    this.notifyWrap = this.el("div", "notify-wrap", hud);
    this.vignette = this.el("div", "vignette", hud);
  }

  updateHUD(d: HUDData): void {
    this.hpBar.style.width = `${(d.hp / d.maxHp) * 100}%`;
    this.stBar.style.width = `${(d.stamina / d.maxStamina) * 100}%`;
    this.mpBar.style.width = `${(d.mana / d.maxMana) * 100}%`;
    this.lvlEl.textContent = String(d.level);
    this.goldEl.textContent = `${d.gold} ذهب · ${d.potions} جرعة`;
    this.zoneEl.textContent = d.zoneName;
    this.clockEl.textContent = d.clock;
    if (d.questTitle) {
      this.questEl.textContent = "⚔ " + d.questTitle;
      this.questObjEl.textContent = d.questObj;
      (this.questEl.parentElement as HTMLElement).style.display = "block";
    } else {
      (this.questEl.parentElement as HTMLElement).style.display = "none";
    }
    this.skillQEl.textContent = d.skillQ;
    this.skillVEl.textContent = d.skillV;
    this.lockEl.style.opacity = d.lockOn ? "1" : "0.25";
    // boss bar
    if (d.boss) {
      this.bossWrap.style.display = "block";
      this.bossName.textContent = d.boss.name;
      this.bossBar.style.width = `${(d.boss.hp / d.boss.maxHp) * 100}%`;
    } else this.bossWrap.style.display = "none";
    // interact
    this.interactEl.style.display = d.interactText ? "block" : "none";
    if (d.interactText) this.interactEl.textContent = d.interactText;
    this.drawMinimap(d);
  }

  setHurt(f: number): void {
    this.vignette.style.opacity = String(Math.min(0.85, f));
  }

  private drawMinimap(d: HUDData): void {
    const ctx = this.minimap.getContext("2d")!;
    const S = 180, R = 95; // world meters shown
    ctx.clearRect(0, 0, S, S);
    ctx.save();
    ctx.beginPath(); ctx.arc(S / 2, S / 2, S / 2 - 2, 0, Math.PI * 2); ctx.clip();
    ctx.fillStyle = "#10131d";
    ctx.fillRect(0, 0, S, S);
    const k = S / (R * 2);
    const toMap = (wx: number, wz: number): [number, number] => [S / 2 + (wx - d.posX) * k, S / 2 + (wz - d.posZ) * k];
    // zone blobs
    const zones = Object.values(WORLD.ZONES);
    for (const zn of zones) {
      const [mx, my] = toMap(zn.x, zn.z);
      ctx.fillStyle = "rgba(80,90,140,0.25)";
      ctx.beginPath(); ctx.arc(mx, my, zn.r * k, 0, Math.PI * 2); ctx.fill();
    }
    // waystones
    for (const w of d.waystones) {
      if (!w.discovered) continue;
      const [mx, my] = toMap(w.x, w.z);
      ctx.fillStyle = "#5a8aff";
      ctx.beginPath(); ctx.arc(mx, my, 3, 0, Math.PI * 2); ctx.fill();
    }
    // enemies
    for (const e of d.enemies) {
      if (!e.alive) continue;
      const [mx, my] = toMap(e.x, e.z);
      if (mx < 0 || mx > S || my < 0 || my > S) continue;
      ctx.fillStyle = e.boss ? "#ff5a5a" : "#c05a5a";
      ctx.beginPath(); ctx.arc(mx, my, e.boss ? 4 : 2.2, 0, Math.PI * 2); ctx.fill();
    }
    // player arrow
    ctx.translate(S / 2, S / 2);
    ctx.rotate(-d.yaw + Math.PI);
    ctx.fillStyle = "#ffd76a";
    ctx.beginPath(); ctx.moveTo(0, -6); ctx.lineTo(4, 5); ctx.lineTo(-4, 5); ctx.closePath(); ctx.fill();
    ctx.restore();
    ctx.strokeStyle = "rgba(140,150,200,0.5)";
    ctx.beginPath(); ctx.arc(S / 2, S / 2, S / 2 - 1.5, 0, Math.PI * 2); ctx.stroke();
  }

  notify(text: string, kind: "info" | "quest" | "loot" | "warn" = "info"): void {
    const n = this.el("div", `notify ${kind}`, this.notifyWrap, text);
    setTimeout(() => n.classList.add("show"), 16);
    setTimeout(() => { n.classList.remove("show"); setTimeout(() => n.remove(), 500); }, 3600);
    while (this.notifyWrap.children.length > 5) this.notifyWrap.firstChild?.remove();
  }

  // ---------------- overlay screens ----------------

  private clearOverlay(): void {
    this.overlay.innerHTML = "";
    this.overlay.style.display = "none";
  }

  private openOverlay(cls: string): HTMLElement {
    this.clearOverlay();
    this.overlay.style.display = "flex";
    const box = this.el("div", `panel ${cls}`, this.overlay);
    return box;
  }

  showTitle(hasSave: boolean, stats: { level: number; bosses: number; time: number } | null): void {
    this.screen = "title";
    const box = this.openOverlay("title-panel");
    this.el("div", "game-logo", box, "KINGDOM OF SHADOWS");
    this.el("div", "game-logo-ar", box, "مملكة الظلال");
    this.el("div", "title-sub", box, "فانتازيا مظلمة · عالم مفتوح · حركة وقدرات · قصة متفرعة");
    const btns = this.el("div", "title-btns", box);
    const b1 = this.el("button", "btn primary", btns, hasSave ? "متابعة الرحلة" : "ابدأ الرحلة");
    b1.onclick = () => this.handlers.onStart(!hasSave);
    if (hasSave) {
      const b2 = this.el("button", "btn", btns, "رحلة جديدة");
      b2.onclick = () => this.handlers.onStart(true);
    }
    if (stats) {
      const s = this.el("div", "title-stats", box,
        `المستوى ${stats.level} · زعماء مهزومون ${stats.bosses} · وقت اللعب ${Math.floor(stats.time / 60)}د`);
    }
    const hint = this.el("div", "controls-hint", box);
    hint.innerHTML = "WASD تحريك · فأرة كاميرا · زر أيسر هجوم · F هجوم قوي · زر أيمن صد/صد مضاد · Shift مراوغة · مسافة قفز<br>" +
      "Q قدرة الظل · V قدرة النور · R جرعة · E تفاعل · Tab قفل على العدو · 1-6 تبديل السلاح · C القائمة · M خريطة · Esc إيقاف";
  }

  showPause(): void {
    this.screen = "pause";
    const box = this.openOverlay("pause-panel");
    this.el("h2", "", box, "إيقاف مؤقت");
    const btns = this.el("div", "col-btns", box);
    const mk = (t: string, fn: () => void, cls = "btn") => { const b = this.el("button", cls, btns, t); b.onclick = fn; };
    mk("استئناف", () => this.handlers.onResume(), "btn primary");
    mk("قائمة الشخصية", () => this.handlers.onOpenMenu());
    mk("حفظ ومتابعة", () => this.handlers.onResume());
    mk("العودة للعنوان", () => this.handlers.onQuitToTitle());
  }

  showDead(): void {
    this.screen = "dead";
    const box = this.openOverlay("dead-panel");
    this.el("h2", "", box, "سقط آرين...");
    this.el("p", "", box, "لكن قلب النور لا ينطفئ بسهولة. ستفيق عند آخر نقطة طاقة اكتشفتها.");
    const btns = this.el("div", "col-btns", box);
    const b = this.el("button", "btn primary", btns, "الاستيقاظ من جديد");
    b.onclick = () => this.handlers.onRestart();
    const b2 = this.el("button", "btn", btns, "العودة للعنوان");
    b2.onclick = () => this.handlers.onQuitToTitle();
  }

  showIntro(texts: string[], onDone: () => void): void {
    this.screen = "dialogue";
    const box = this.openOverlay("intro-panel");
    let i = 0;
    const p = this.el("p", "intro-text", box, texts[0]);
    const next = () => {
      i++;
      if (i >= texts.length) { onDone(); return; }
      p.classList.remove("fade");
      void p.offsetWidth;
      p.textContent = texts[i];
      p.classList.add("fade");
    };
    this.overlay.onclick = next;
    p.onclick = next;
  }

  // ---------------- dialogue ----------------

  showDialogue(lines: { speaker: string; text: string }[], choices: { text: string; effect: string }[] | undefined, onDone: () => void, onChoice: ((effect: string) => void) | null): void {
    this.screen = "dialogue";
    this.lastScreen = "none";
    this.dialogueEl = this.el("div", "dialogue", this.root);
    const head = this.el("div", "dlg-head", this.dialogueEl);
    this.dialogueSpeaker = this.el("span", "dlg-speaker", head, "");
    const body = this.el("div", "dlg-body", this.dialogueEl);
    this.dialogueText = this.el("p", "dlg-text", body, "");
    this.dialogueChoicesEl = this.el("div", "dlg-choices", this.dialogueEl);
    this.dialogueNext = this.el("div", "dlg-next", this.dialogueEl, "اضغط E أو انقر للمتابعة ▼");
    this.currentLines = lines;
    this.lineIdx = 0;
    this.onDialogueDone = onDone;
    this.onChoice = onChoice;
    this.showLine();
    const advance = () => this.advanceDialogue();
    this.dialogueEl.onclick = advance;
    this._dlgKey = advance;
  }

  private _dlgKey: (() => void) | null = null;
  get dialogueKeyHandler(): (() => void) | null { return this._dlgKey; }

  private showLine(): void {
    const l = this.currentLines[this.lineIdx];
    this.dialogueSpeaker.textContent = l.speaker;
    this.dialogueText.textContent = l.text;
    this.dialogueNext.style.display = this.lineIdx >= this.currentLines.length - 1 ? "none" : "block";
    if (this.lineIdx >= this.currentLines.length - 1 && (this as any)._choices) {
      this.renderChoices((this as any)._choices);
    }
  }

  private advanceDialogue(): void {
    if (this.lineIdx < this.currentLines.length - 1) {
      this.lineIdx++;
      this.showLine();
    }
  }

  private renderChoices(choices: { text: string; effect: string }[]): void {
    this.dialogueChoicesEl.innerHTML = "";
    for (const c of choices) {
      const b = this.el("button", "btn choice", this.dialogueChoicesEl, c.text);
      b.onclick = (e) => { e.stopPropagation(); this.onChoice?.(c.effect); };
    }
  }

  /** Call with choices available at the last line. */
  setChoices(choices: { text: string; effect: string }[]): void {
    (this as any)._choices = choices;
    if (this.lineIdx >= this.currentLines.length - 1) this.renderChoices(choices);
  }

  closeDialogue(): void {
    this.dialogueEl?.remove();
    this.dialogueEl = undefined as never;
    this._dlgKey = null;
    (this as any)._choices = null;
    if (this.screen === "dialogue") this.screen = "none";
  }

  get isDialogueOpen(): boolean { return !!this.dialogueEl; }

  // ---------------- character menu ----------------

  showMenu(data: MenuData, tab?: Tab): void {
    this.screen = "menu";
    this.menuData = data;
    if (tab) this.menuTab = tab;
    const box = this.openOverlay("menu-panel");
    const head = this.el("div", "menu-head", box);
    for (const t of TABS) {
      const b = this.el("button", `tab ${t === this.menuTab ? "active" : ""}`, head, t);
      b.onclick = () => this.showMenu(data, t);
    }
    const close = this.el("button", "btn close-x", head, "✕");
    close.onclick = () => this.closeMenu();
    const body = this.el("div", "menu-body", box);
    switch (this.menuTab) {
      case "الأسلحة": this.tabWeapons(body, data); break;
      case "المهارات": this.tabSkills(body, data); break;
      case "المعدات": this.tabEquip(body, data); break;
      case "الحقيبة": this.tabBag(body, data); break;
      case "الخريطة": this.tabMap(body, data); break;
      case "المهمات": this.tabQuests(body, data); break;
    }
  }

  closeMenu(): void {
    this.clearOverlay();
    this.screen = "none";
  }

  get isMenuOpen(): boolean { return this.screen === "menu"; }
  get currentScreen(): Screen { return this.screen; }
  setScreen(s: Screen): void { this.screen = s; }

  private tabWeapons(body: HTMLElement, d: MenuData): void {
    const stats = this.el("div", "char-stats", body);
    stats.innerHTML =
      `<span>المستوى <b>${d.level}</b></span><span>الضرر <b>${d.dmg}</b></span>` +
      `<span>الصحة <b>${d.maxHp}</b></span><span>التحمل <b>${d.maxStamina}</b></span><span>الطاقة <b>${d.maxMana}</b></span>` +
      `<span>نقاط المهارات <b>${d.skillPoints}</b></span>`;
    const grid = this.el("div", "weapon-grid", body);
    for (const kind of d.weaponList) {
      const w = WEAPONS[kind];
      const owned = d.owned.includes(kind);
      const tier = d.tiers[kind] ?? 1;
      const card = this.el("div", `weapon-card ${d.current === kind ? "active" : ""} ${owned ? "" : "locked"}`, grid);
      const nm = this.el("div", "w-name", card, owned ? w.name : "؟؟؟");
      const tierStr = "★".repeat(tier) + "☆".repeat(MAX_WEAPON_TIER - tier);
      this.el("div", "w-tier", card, owned ? tierStr : "");
      this.el("div", "w-desc", card, owned ? w.desc : "سلاح لم تكتشفه بعد.");
      this.el("div", "w-spec", card, owned ? `مهارة: ${w.special} — ${w.specialDesc}` : "");
      if (owned) {
        this.el("div", "w-dmg", card, `الضرر: ${Math.round(w.baseDmg * (1 + (tier - 1) * 0.35))}`);
        const row = this.el("div", "w-actions", card);
        const eq = this.el("button", "btn small", row, d.current === kind ? "مُجهَّز ✓" : "تجهيز");
        eq.onclick = () => this.handlers.onWeaponSelect(kind);
        if (tier < MAX_WEAPON_TIER) {
          const cost = upgradeCost(tier);
          const can = d.inv["crystal"] >= cost.crystals && d.inv["ore"] >= cost.ore && d.gold >= cost.gold;
          const up = this.el("button", `btn small ${can ? "primary" : "disabled"}`, row,
            `ترقية (${cost.crystals}🔷 ${cost.ore}⛏️ ${cost.gold}💰)`);
          if (can) up.onclick = () => this.handlers.onUpgrade(kind);
        } else {
          this.el("div", "w-max", card, "الحد الأقصى ✦");
        }
      }
    }
  }

  private tabSkills(body: HTMLElement, d: MenuData): void {
    const head = this.el("div", "skill-head", body);
    head.innerHTML = `<span>نقاط المهارات: <b>${d.skillPoints}</b></span><span class="sp-hint">اكسب نقاطاً عند كل مستوى جديد</span>`;
    const branches: { id: string; name: string; color: string }[] = [
      { id: "shadow", name: "قوى الظلال", color: "#a060ff" },
      { id: "light", name: "قوى النور", color: "#ffd76a" },
      { id: "warrior", name: "قوى المحارب", color: "#ff7a5a" },
    ];
    for (const br of branches) {
      const sec = this.el("div", "skill-branch", body);
      sec.style.borderColor = br.color;
      this.el("h3", "", sec, br.name).style.color = br.color;
      const row = this.el("div", "skill-row", sec);
      for (const s of SKILLS.filter((x) => x.branch === br.id)) {
        const lvl = d.skills[s.id] ?? 0;
        const reqOk = !s.requires || (d.skills[s.requires] ?? 0) > 0;
        const node = this.el("div", `skill-node ${lvl > 0 ? "owned" : ""} ${reqOk ? "" : "locked"}`, row);
        this.el("div", "s-name", node, s.name);
        this.el("div", "s-lvl", node, lvl > 0 ? "م".repeat(lvl) + "·".repeat(s.max - lvl) : "—");
        this.el("div", "s-desc", node, s.desc);
        if (lvl < s.max && reqOk) {
          const b = this.el("button", `btn small ${d.skillPoints >= s.cost ? "primary" : "disabled"}`, node, `تعلّم (${s.cost})`);
          if (d.skillPoints >= s.cost) b.onclick = () => this.handlers.onBuySkill(s.id);
        } else if (lvl >= s.max) {
          this.el("div", "s-max", node, "أتقن ✦");
        } else {
          this.el("div", "s-max", node, "يتطلب سابقاً");
        }
      }
    }
  }

  private tabEquip(body: HTMLElement, d: MenuData): void {
    const slots: [string, string][] = [["armor", "الدرع"], ["helm", "الخوذة"], ["gauntlet", "القفازات"], ["boots", "الحذاء"], ["cloak", "العباءة"], ["ring", "الخاتم"]];
    const grid = this.el("div", "equip-grid", body);
    for (const [slot, label] of slots) {
      const sec = this.el("div", "equip-slot", grid);
      this.el("h4", "", sec, label);
      const owned = d.equipment.filter((e) => e.slot === slot);
      if (owned.length === 0) { this.el("div", "eq-empty", sec, "لا قطع — ابحث عن الصناديق"); continue; }
      for (const e of owned) {
        const eq = d.equipped[slot] === e.id;
        const card = this.el("div", `eq-card ${eq ? "active" : ""}`, sec);
        card.style.borderColor = RARITY_COLORS[e.rarity];
        this.el("div", "eq-name", card, e.name).style.color = RARITY_COLORS[e.rarity];
        this.el("div", "eq-rar", card, RARITY_NAMES[e.rarity]);
        const stats: string[] = [];
        if (e.hp) stats.push(`+${e.hp} صحة`);
        if (e.stamina) stats.push(`+${e.stamina} تحمل`);
        if (e.mana) stats.push(`+${e.mana} طاقة`);
        if (e.dmgMult) stats.push(`+${Math.round((e.dmgMult - 1) * 100)}% ضرر`);
        if (e.defMult) stats.push(`+${Math.round((e.defMult - 1) * 100)}% دفاع`);
        if (e.speedMult) stats.push(`+${Math.round((e.speedMult - 1) * 100)}% سرعة`);
        this.el("div", "eq-stats", card, stats.join(" · "));
        const b = this.el("button", "btn small", card, eq ? "مرتدٍ ✓" : "ارتداء");
        b.onclick = () => this.handlers.onEquip(e.id);
      }
    }
  }

  private tabBag(body: HTMLElement, d: MenuData): void {
    const grid = this.el("div", "bag-grid", body);
    for (const [id, count] of Object.entries(d.inv)) {
      if (count <= 0) continue;
      const it = ITEMS[id];
      if (!it) continue;
      const card = this.el("div", "bag-card", grid);
      this.el("div", "bag-icon", card, it.icon);
      this.el("div", "bag-name", card, it.name);
      this.el("div", "bag-count", card, `×${count}`);
      this.el("div", "bag-desc", card, it.desc);
    }
    const craft = this.el("div", "craft-box", body);
    this.el("h4", "", craft, "الصناعة");
    const c1 = this.el("button", "btn small", craft, `جرعة الحياة (2🌿) — لديك ${d.inv["herb"] ?? 0}`);
    if ((d.inv["herb"] ?? 0) >= 2) c1.onclick = () => this.handlers.onCraft("potion");
    else c1.classList.add("disabled");
    const c2 = this.el("button", "btn small", craft, `مرهم التحمل (2🌿 + 1✨)`);
    if ((d.inv["herb"] ?? 0) >= 2 && (d.inv["essence"] ?? 0) >= 1) c2.onclick = () => this.handlers.onCraft("salve");
    else c2.classList.add("disabled");
    this.el("div", "bag-hint", body, "الجرعات: R أثناء اللعب · المرهم يملأ التحمل فوراً");
  }

  private tabMap(body: HTMLElement, d: MenuData): void {
    const c = this.el("canvas", "world-map", body) as HTMLCanvasElement;
    c.width = 560; c.height = 560;
    const ctx = c.getContext("2d")!;
    const S = 560, half = 520;
    const k = S / (half * 2);
    const toMap = (x: number, z: number): [number, number] => [S / 2 + x * k, S / 2 + z * k];
    ctx.fillStyle = "#0d1018"; ctx.fillRect(0, 0, S, S);
    for (const zn of Object.values(WORLD.ZONES)) {
      const [mx, my] = toMap(zn.x, zn.z);
      ctx.fillStyle = "rgba(90,100,160,0.18)";
      ctx.beginPath(); ctx.arc(mx, my, zn.r * k, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = "rgba(120,130,190,0.4)";
      ctx.beginPath(); ctx.arc(mx, my, zn.r * k, 0, Math.PI * 2); ctx.stroke();
      ctx.fillStyle = "#cdd4ee";
      ctx.font = "14px sans-serif"; ctx.textAlign = "center";
      ctx.fillText(zn.name, mx, my - zn.r * k - 6);
    }
    for (const w of d.waystones) {
      if (!w.discovered) continue;
      const [mx, my] = toMap(w.x, w.z);
      ctx.fillStyle = "#5a8aff";
      ctx.beginPath(); ctx.arc(mx, my, 5, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = "#9fb4ff"; ctx.font = "11px sans-serif";
      ctx.fillText(w.name, mx, my + 18);
    }
    const [px, py] = toMap(d.posX, d.posZ);
    ctx.fillStyle = "#ffd76a";
    ctx.beginPath(); ctx.arc(px, py, 6, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = "#ffd76a";
    ctx.beginPath(); ctx.arc(px, py, 11, 0, Math.PI * 2); ctx.stroke();
  }

  private tabQuests(body: HTMLElement, d: MenuData): void {
    this.el("h3", "q-sec", body, "القصة الرئيسية");
    const main = MAIN_QUESTS[Math.min(d.qs.mainStage, MAIN_QUESTS.length - 1)];
    if (d.qs.mainStage < MAIN_QUESTS.length) {
      const card = this.el("div", "quest-card main", body);
      this.el("div", "q-name", card, main.name);
      this.el("div", "q-obj", card, main.objective(d.qs));
      this.el("div", "q-desc", card, main.desc);
    }
    this.el("h3", "q-sec", body, "مهمات جانبية");
    let any = false;
    for (const sq of SIDE_QUESTS) {
      const st = d.qs.side[sq.id];
      if (st === undefined || st === 0) continue;
      any = true;
      const card = this.el("div", "quest-card", body);
      this.el("div", "q-name", card, sq.name + (st === 2 ? " ✓" : ""));
      this.el("div", "q-obj", card, sq.objective(d.qs));
    }
    if (!any) this.el("div", "q-none", body, "لا مهمات جانبية بعد — تحدث مع الشخصيات في العالم.");
  }

  // ---------------- blacksmith ----------------

  showSmith(data: MenuData): void {
    this.screen = "smith";
    const box = this.openOverlay("smith-panel");
    this.el("h2", "", box, "🔥 ورشة بروم");
    this.el("p", "smith-sub", box, "اصقل نصلك، واسكب المعادن، واشهد ولادة سلاح أسطوري.");
    const tabs = this.el("div", "menu-head", box);
    const mkTab = (label: string, fn: () => void, active = false) => {
      const b = this.el("button", `tab ${active ? "active" : ""}`, tabs, label);
      b.onclick = fn;
    };
    mkTab("ترقية الأسلحة", () => this.smithUpgrade(box, data), true);
    mkTab("صياغة", () => this.smithCraft(box, data));
    const close = this.el("button", "btn close-x", tabs, "✕");
    close.onclick = () => this.closeSmith();
    const body = this.el("div", "menu-body", box);
    this.smithUpgrade(body, data);
  }

  closeSmith(): void {
    this.clearOverlay();
    this.screen = "none";
  }
  get isSmithOpen(): boolean { return this.screen === "smith"; }

  private smithUpgrade(body: HTMLElement, d: MenuData): void {
    body.innerHTML = "";
    this.el("h4", "", body, "اختر سلاحاً للترقية");
    const grid = this.el("div", "weapon-grid", body);
    for (const kind of d.owned) {
      const w = WEAPONS[kind];
      const tier = d.tiers[kind] ?? 1;
      const card = this.el("div", "weapon-card", grid);
      this.el("div", "w-name", card, w.name);
      this.el("div", "w-tier", card, "★".repeat(tier) + "☆".repeat(MAX_WEAPON_TIER - tier));
      if (tier >= MAX_WEAPON_TIER) {
        this.el("div", "w-max", card, "بلغ قمته الأسطورية ✦");
        continue;
      }
      const cost = upgradeCost(tier);
      const can = d.inv["crystal"] >= cost.crystals && d.inv["ore"] >= cost.ore && d.gold >= cost.gold;
      const b = this.el("button", `btn ${can ? "primary" : "disabled"}`, card,
        `ترقية للمستوى ${tier + 1} — ${cost.crystals}🔷 ${cost.ore}⛏️ ${cost.gold}💰`);
      if (can) b.onclick = () => this.handlers.onUpgrade(kind);
      const dmgNow = Math.round(w.baseDmg * (1 + (tier - 1) * 0.35));
      const dmgNext = Math.round(w.baseDmg * (1 + tier * 0.35));
      this.el("div", "w-dmg", card, `الضرر: ${dmgNow} ← ${dmgNext} · مظهر جديد وتوهج أعمق`);
    }
  }

  private smithCraft(body: HTMLElement, d: MenuData): void {
    body.innerHTML = "";
    this.el("h4", "", body, "الصياغة");
    const rows = this.el("div", "craft-rows", body);
    const mk = (label: string, costTxt: string, can: boolean, fn: () => void) => {
      const r = this.el("div", "craft-row", rows);
      this.el("div", "cr-name", r, label);
      this.el("div", "cr-cost", r, costTxt);
      const b = this.el("button", `btn small ${can ? "primary" : "disabled"}`, r, "اصنع");
      if (can) b.onclick = fn;
    };
    mk("جرعة الحياة", "2🌿", (d.inv["herb"] ?? 0) >= 2, () => this.handlers.onCraft("potion"));
    mk("مرهم التحمل", "2🌿 + 1✨", (d.inv["herb"] ?? 0) >= 2 && (d.inv["essence"] ?? 0) >= 1, () => this.handlers.onCraft("salve"));
    mk("بلورة النور", "3 نياش + 1 جوهر", (d.inv["fang"] ?? 0) >= 3 && (d.inv["essence"] ?? 0) >= 1, () => this.handlers.onCraft("crystal"));
  }

  // ---------------- waystone travel ----------------

  showTravel(waystones: { id: string; name: string; discovered: boolean }[], currentId: string): void {
    this.screen = "menu";
    const box = this.openOverlay("travel-panel");
    this.el("h2", "", box, "⬡ نقطة الطاقة");
    this.el("p", "", box, "تنقّل فورياً بين نقاط الطاقة المكتشفة.");
    const list = this.el("div", "travel-list", box);
    for (const w of waystones) {
      if (!w.discovered || w.id === currentId) continue;
      const b = this.el("button", "btn travel-btn", list, w.name);
      b.onclick = () => { this.closeMenu(); this.handlers.onTravel(w.id); };
    }
    const c = this.el("button", "btn", list, "إلغاء");
    c.onclick = () => this.closeMenu();
  }

  // ---------------- endings ----------------

  showEndings(onPick: (id: string) => void, canShadow: boolean): void {
    this.screen = "ending";
    const box = this.openOverlay("ending-panel");
    this.el("h2", "", box, "القرار الأخير");
    this.el("p", "", box, "يقف ملك الظلال مهزوماً أمامك، والقلب بين يديك. كيف تُنهي اللعنة؟");
    const list = this.el("div", "ending-list", box);
    for (const e of ENDINGS) {
      const locked = e.id === "shadow" && !canShadow;
      const b = this.el("button", `btn ending-btn ${locked ? "disabled" : ""}`, list, e.name + (locked ? " (يتطلب إتقان الظلال)" : ""));
      if (!locked) b.onclick = () => onPick(e.id);
    }
  }

  showEndingText(e: Ending, stats: string, onDone: () => void): void {
    this.screen = "ending";
    const box = this.openOverlay("ending-text-panel");
    this.el("div", "ending-name", box, e.name);
    const p = this.el("p", "ending-text", box, e.text);
    void p.offsetWidth; p.classList.add("fade");
    this.el("div", "ending-stats", box, stats);
    const b = this.el("button", "btn primary", box, "عودة إلى العنوان");
    b.onclick = onDone;
  }

  hideAll(): void {
    this.clearOverlay();
    this.closeDialogue();
    this.screen = "none";
  }
}

export interface MenuData {
  level: number; dmg: number; maxHp: number; maxStamina: number; maxMana: number;
  skillPoints: number; gold: number;
  weaponList: WeaponKind[];
  owned: WeaponKind[];
  current: WeaponKind;
  tiers: Record<string, number>;
  inv: Record<string, number>;
  skills: Record<string, number>;
  equipment: { id: string; slot: string; name: string; rarity: string; hp?: number; stamina?: number; mana?: number; dmgMult?: number; defMult?: number; speedMult?: number }[];
  equipped: Record<string, string>;
  posX: number; posZ: number;
  qs: QuestState;
  waystones: { id: string; x: number; z: number; discovered: boolean; name: string }[];
}
