import * as THREE from "three";
import { mergeGeometries } from "three/addons/utils/BufferGeometryUtils.js";
import { RACES, SEASON_INFO, getRegion, mulberry32, type RaceDef, type Season, type RegionId, type RegionDef } from "./content";
import { Heightfield, RoadIndex, ObstacleGrid, mixHex, WORLD_HALF, type Lake, type Obstacle } from "./spatial";
import type { QualityTier } from "./quality";

export type { Obstacle };

const CHUNK = 106;
const CHUNKS = Math.ceil((WORLD_HALF * 2) / CHUNK);
const TERRAIN_SEGMENTS = 112;
const SKY_RADIUS = 640;

interface RegionStyle {
  trees: number;
  conifer: number;
  avenue: number;
  rocks: number;
  zones: Array<{ x: number; z: number; count: number; spread: number }>;
  walls: number[];
  roofs: number[];
  steepRoof: boolean;
  peaks: { count: number; height: number; snow: boolean; rock: number; foot: number };
  windmills: Array<[number, number]>;
  tulips: Array<{ x: number; z: number; w: number; d: number }>;
  lakes: Lake[];
  ferris: boolean;
}

const STYLE: Record<RegionId, RegionStyle> = {
  britain: {
    trees: 1000, conifer: 0.25, avenue: 38, rocks: 40,
    zones: [{ x: -105, z: -65, count: 25, spread: 72 }, { x: 125, z: -65, count: 20, spread: 65 }, { x: -45, z: 100, count: 12, spread: 45 }],
    walls: [0xd7c6a5, 0xcbb994, 0xe2d6b8, 0xb8a583], roofs: [0x69463a, 0x5b3f35, 0x7a5444, 0x4b4b52], steepRoof: false,
    peaks: { count: 14, height: 110, snow: false, rock: 0x6f7a6c, foot: 0x4a6040 },
    windmills: [[-275, 105]], tulips: [], lakes: [], ferris: true,
  },
  switzerland: {
    trees: 1250, conifer: 0.8, avenue: 0, rocks: 130,
    zones: [{ x: 120, z: 60, count: 16, spread: 55 }, { x: -150, z: -110, count: 12, spread: 50 }],
    walls: [0xb89968, 0xa88556, 0xc7a878], roofs: [0x4a3328, 0x3b2a22], steepRoof: true,
    peaks: { count: 22, height: 300, snow: true, rock: 0x7b8088, foot: 0x3f5a3a },
    windmills: [], tulips: [], lakes: [], ferris: false,
  },
  netherlands: {
    trees: 420, conifer: 0.1, avenue: 22, rocks: 0,
    zones: [{ x: -120, z: 60, count: 14, spread: 60 }, { x: 140, z: -120, count: 12, spread: 55 }],
    walls: [0xa5543f, 0x9a4a38, 0xb86a4c], roofs: [0x8a3b2a, 0xb4532f], steepRoof: false,
    peaks: { count: 8, height: 30, snow: false, rock: 0x7a8f6a, foot: 0x5a7a48 },
    windmills: [[-210, 100], [200, 170], [-250, -150], [240, -260]],
    tulips: [{ x: -150, z: -120, w: 60, d: 42 }, { x: 175, z: 70, w: 54, d: 40 }, { x: -30, z: 285, w: 60, d: 36 }],
    lakes: [], ferris: false,
  },
  finland: {
    trees: 1500, conifer: 0.85, avenue: 0, rocks: 90,
    zones: [{ x: 150, z: 130, count: 8, spread: 40 }, { x: -170, z: -60, count: 7, spread: 40 }],
    walls: [0x8a3b2a, 0x7a3326], roofs: [0x2b2b2e, 0x3a3a3f], steepRoof: false,
    peaks: { count: 12, height: 60, snow: false, rock: 0x56685a, foot: 0x2f4a30 },
    windmills: [], tulips: [],
    lakes: [{ x: 0, z: 0, r: 52 }, { x: -260, z: 150, r: 64 }, { x: 250, z: -180, r: 70 }, { x: 262, z: 225, r: 48 }],
    ferris: false,
  },
};

interface TreeRec { x: number; y: number; z: number; s: number; rot: number; kind: 0 | 1; rank: number; shade: number; hue: number }
interface Chunk { group: THREE.Group; center: THREE.Vector3; meshes: THREE.InstancedMesh[]; totals: number[] }
interface CrownSet { mesh: THREE.InstancedMesh; data: Float32Array }
interface Token { x: number; y: number; z: number; alive: boolean }

const NIGHT_TOP = 0x04071a;
const NIGHT_HORIZON = 0x131b33;
const WARM = new THREE.Color(0xff9b5c);

export class World {
  /** Persistent objects (gate, weather). */
  readonly group = new THREE.Group();
  /** Everything that belongs to the current region; disposed and rebuilt by setRegion(). */
  private regionGroup = new THREE.Group();
  readonly obstacles = new ObstacleGrid(24);
  readonly curves = new Map<string, THREE.CatmullRomCurve3>();
  readonly startMarkers = new THREE.Group();
  readonly checkpointGate: THREE.Group;
  regionRaces: RaceDef[] = [];
  season: Season = "summer";
  region: RegionDef = getRegion("britain");
  tokensCollected = 0;
  tokenTotal = 0;

  private hf = new Heightfield({ hillScale: 1, hillFreq: 1, highlandBias: 0 });
  private roads = new RoadIndex(28);
  private style: RegionStyle = STYLE.britain;
  private tracked: Array<{ dispose(): void }> = [];
  private random = mulberry32(9182);

  // region materials (recreated per build)
  private terrainMat!: THREE.MeshLambertMaterial;
  private skirtMat!: THREE.MeshLambertMaterial;
  private asphaltMat!: THREE.MeshLambertMaterial;
  private dirtMat!: THREE.MeshLambertMaterial;
  private mountainMat!: THREE.MeshLambertMaterial;
  private waterMat!: THREE.MeshLambertMaterial;
  private crowns: CrownSet[] = [];
  private chunks: Chunk[] = [];
  private blades: THREE.Object3D[] = [];
  private ferris: THREE.Object3D | null = null;
  private tokenMesh: THREE.InstancedMesh | null = null;
  private tokens: Token[] = [];
  private tulipMesh: THREE.InstancedMesh | null = null;
  private mountainBase: Float32Array = new Float32Array(0);
  private mountainT: Float32Array = new Float32Array(0);
  private mountainColor!: THREE.BufferAttribute;
  private mountainTint = new THREE.Color(0xffffff);

  // persistent scene pieces
  private weather!: THREE.Points;
  private weatherPositions!: Float32Array;
  private weatherCount = 420;
  private gateBeam!: THREE.Mesh;
  private skyRig = new THREE.Group();
  private skyGeo!: THREE.SphereGeometry;
  private skyMat!: THREE.MeshBasicMaterial;
  private sunGroup = new THREE.Group();
  private sunDisc!: THREE.Mesh;
  private moon!: THREE.Mesh;
  private stars!: THREE.Points;
  private clouds!: THREE.Mesh;
  private cloudMat!: THREE.MeshBasicMaterial;
  private fog: THREE.Fog;
  private skyClock = 0;

  // runtime state
  private tier!: QualityTier;
  private propDistance = 280;
  private density = 1;
  private cullClock = 0;
  private time = 0;
  private dayTop = 0x5aa9d6;
  private dayHorizon = 0x96c4dc;
  private foliageHex = 0x367535;
  private foliageAltHex = 0x4b8f3a;
  private foliageAltMax = 0.4;
  private tmpA = new THREE.Color();
  private tmpB = new THREE.Color();
  private tmpC = new THREE.Color();
  private tmpM = new THREE.Matrix4();
  private tmpQ = new THREE.Quaternion();
  private tmpP = new THREE.Vector3();
  private tmpS = new THREE.Vector3();
  private yAxis = new THREE.Vector3(0, 1, 0);

  constructor(private scene: THREE.Scene, tier: QualityTier) {
    this.tier = tier;
    this.fog = new THREE.Fog(0x96c4dc, 100, tier.viewDistance);
    this.scene.fog = this.fog;
    this.scene.background = new THREE.Color(0x96c4dc);
    this.group.add(this.regionGroup);
    this.buildSky();
    this.buildWeather();
    this.checkpointGate = this.buildGate();
    this.checkpointGate.visible = false;
    this.group.add(this.checkpointGate);
    this.group.add(this.startMarkers);
    this.scene.add(this.group);
    this.setRegion("britain");
  }

  // ---------------------------------------------------------------------------------------------- queries

  heightAt(x: number, z: number): number { return this.hf.heightAt(x, z); }
  isWater(x: number, z: number): boolean { return this.hf.isWater(x, z); }

  /** True when the point lies on the paved/dirt road surface. */
  isRoad(x: number, z: number): boolean { return this.roads.near(x, z, 8.2); }

  tokensLeft(): number { return this.tokenTotal - this.tokensCollected; }

  get lakes(): Lake[] { return this.hf.lakes; }

  /** Visit tokens that are still uncollected (used by the minimap). */
  forEachToken(fn: (x: number, z: number) => void): void {
    for (const token of this.tokens) if (token.alive) fn(token.x, token.z);
  }

  // ----------------------------------------------------------------------------------------- region/season

  setRegion(id: RegionId): void {
    this.clearRegion();
    this.region = getRegion(id);
    this.style = STYLE[id];
    this.season = this.region.defaultSeason;
    this.regionRaces = RACES.filter((race) => race.region === id);
    this.random = mulberry32(9182 + id.length * 131);
    this.hf = new Heightfield({ hillScale: this.region.hillScale, hillFreq: this.region.hillFreq, highlandBias: this.region.highlandBias });
    this.buildCurves();
    this.hf.lakes = this.style.lakes;
    if (this.style.lakes.length) {
      let minY = Infinity;
      for (const curve of this.curves.values()) for (const p of curve.getPoints(240)) minY = Math.min(minY, p.y);
      this.hf.waterY = minY - 0.12 - 0.55;
    }
    this.buildTerrain();
    this.buildRoads();
    this.buildProps();
    this.buildTokens();
    this.buildMountains();
    if (this.style.lakes.length) this.buildWater();
    this.buildStartMarkers();
    this.hideGate();
    this.setSeason(this.season);
    this.applyTier(this.tier);
  }

  setSeason(season: Season): void {
    this.season = season;
    const info = SEASON_INFO[season];
    const reg = this.region;
    const k = season === "winter" ? 0 : 0.55; // winter looks the same everywhere
    this.terrainMat.color.setHex(mixHex(info.ground, reg.ground, k));
    this.skirtMat.color.setHex(mixHex(info.ground, reg.ground, k));
    this.asphaltMat.color.setHex(mixHex(info.road, reg.road, 0.5));
    this.dirtMat.color.setHex(season === "winter" ? 0x8c8f90 : season === "autumn" ? 0x6b5036 : 0x7a5d3d);
    this.foliageHex = mixHex(info.foliage, reg.foliage, k);
    this.foliageAltHex = season === "autumn" ? 0xe8b02a : season === "winter" ? 0xd3dcda : season === "spring" ? 0x93c76b : 0x58a044;
    this.foliageAltMax = season === "autumn" ? 0.75 : season === "winter" ? 0.85 : 0.45;
    this.dayTop = mixHex(info.sky, reg.sky, k);
    this.dayHorizon = mixHex(info.fog, reg.fog, k);
    this.recolorCrowns();
    this.weather.visible = season === "spring" || season === "winter";
    const material = this.weather.material as THREE.PointsMaterial;
    material.color.setHex(season === "winter" ? 0xffffff : 0xb9dded);
    material.size = season === "winter" ? 0.24 : 0.11;
    this.fog.near = this.tier.viewDistance * (season === "winter" ? 0.18 : 0.3);
    this.fog.far = this.tier.viewDistance * (season === "winter" ? 0.78 : 1);
  }

  /** Apply a graphics tier at runtime: pure parameter changes, never a rebuild. */
  applyTier(tier: QualityTier): void {
    this.tier = tier;
    this.density = tier.propDensity;
    this.propDistance = tier.propDistance;
    for (const chunk of this.chunks) {
      chunk.meshes.forEach((mesh, i) => { mesh.count = Math.floor(chunk.totals[i] * this.density); });
    }
    this.weatherCount = tier.weatherParticles;
    this.weather.geometry.setDrawRange(0, this.weatherCount);
    this.clouds.visible = tier.clouds;
    this.fog.near = tier.viewDistance * (this.season === "winter" ? 0.18 : 0.3);
    this.fog.far = tier.viewDistance * (this.season === "winter" ? 0.78 : 1);
    this.cullClock = 0;
  }

  // --------------------------------------------------------------------------------------------- gate etc

  setGate(position: THREE.Vector3, next: THREE.Vector3 | null): void {
    this.checkpointGate.visible = true;
    this.checkpointGate.position.copy(position);
    this.checkpointGate.position.y = this.heightAt(position.x, position.z);
    if (next) this.checkpointGate.rotation.y = Math.atan2(next.x - position.x, next.z - position.z);
  }

  hideGate(): void { this.checkpointGate.visible = false; }

  showStartMarkers(visible: boolean): void { this.startMarkers.visible = visible; }

  /** Collect festival tokens near a point; returns how many were picked up this call. */
  collectTokens(x: number, z: number): number {
    let got = 0;
    for (const token of this.tokens) {
      if (!token.alive) continue;
      const dx = token.x - x, dz = token.z - z;
      if (dx * dx + dz * dz < 12) { token.alive = false; got++; }
    }
    this.tokensCollected += got;
    return got;
  }

  resetTokens(): void {
    for (const token of this.tokens) token.alive = true;
    this.tokensCollected = 0;
  }

  // ------------------------------------------------------------------------------------------- per-frame

  /**
   * Sky, sun/moon, fog colour. daylight 0..1, glow 0..1 (sunrise/sunset warmth), sunDir unit vector.
   */
  atmosphere(dt: number, daylight: number, glow: number, sunDir: THREE.Vector3, cam: THREE.Vector3): void {
    this.skyRig.position.copy(cam);
    const night = 1 - daylight;
    const top = this.tmpA.setHex(this.dayTop).lerp(this.tmpC.setHex(NIGHT_TOP), night);
    const horizon = this.tmpB.setHex(this.dayHorizon).lerp(this.tmpC.setHex(NIGHT_HORIZON), night).lerp(WARM, glow * 0.5);
    (this.scene.background as THREE.Color).copy(horizon);
    this.fog.color.copy(horizon);

    this.sunGroup.position.copy(sunDir).multiplyScalar(560);
    this.sunGroup.visible = sunDir.y > -0.12;
    (this.sunDisc.material as THREE.MeshBasicMaterial).color.setHex(0xfff3d0).lerp(WARM, glow * 0.8);
    this.moon.position.copy(sunDir).multiplyScalar(-540);
    this.moon.visible = night > 0.45 && sunDir.y < 0.1;
    (this.stars.material as THREE.PointsMaterial).opacity = Math.max(0, night * night * 1.1 - 0.1);
    this.stars.visible = night > 0.35;

    this.cloudMat.color.setHex(0xffffff).lerp(this.tmpC.setHex(0x2b3350), night * 0.88).lerp(WARM, glow * 0.35);
    this.mountainTint.setHex(0xffffff).lerp(this.tmpC.setHex(0x1a2238), night * 0.8).lerp(WARM, glow * 0.18);

    this.skyClock -= dt;
    if (this.skyClock <= 0) {
      this.skyClock = 0.25;
      this.recolorSky(top, horizon, sunDir, glow * (1 - night * 0.6));
    }
  }

  update(dt: number, player: THREE.Vector3, cam: THREE.Vector3): void {
    this.time += dt;
    for (const blade of this.blades) blade.rotation.z += dt * 0.55;
    if (this.ferris) this.ferris.rotation.z += dt * 0.07;
    this.clouds.rotation.y += dt * 0.004;
    this.clouds.position.set(cam.x, 0, cam.z);

    for (let i = 0; i < this.startMarkers.children.length; i++) {
      const marker = this.startMarkers.children[i];
      marker.rotation.y += dt * (0.4 + i * 0.08);
      marker.position.y = this.heightAt(marker.position.x, marker.position.z) + 0.55 + Math.sin(this.time * 2 + i) * 0.18;
    }
    this.gateBeam.scale.y = 1 + Math.sin(this.time * 3) * 0.05;

    if (this.tokenMesh) {
      for (let i = 0; i < this.tokens.length; i++) {
        const t = this.tokens[i];
        const s = t.alive ? 1 : 0;
        this.tmpQ.setFromAxisAngle(this.yAxis, this.time * 2 + i);
        this.tmpP.set(t.x, t.y + Math.sin(this.time * 2.4 + i) * 0.25, t.z);
        this.tmpS.set(s, s, s);
        this.tmpM.compose(this.tmpP, this.tmpQ, this.tmpS);
        this.tokenMesh.setMatrixAt(i, this.tmpM);
      }
      this.tokenMesh.instanceMatrix.needsUpdate = true;
    }

    if (this.weather.visible) {
      const winter = this.season === "winter";
      const fall = winter ? 3.2 : 18;
      const arr = this.weatherPositions;
      const limit = this.weatherCount * 3;
      for (let i = 0; i < limit; i += 3) {
        arr[i + 1] -= fall * dt;
        if (winter) arr[i] += Math.sin(arr[i + 1] + i) * dt * 0.25;
        if (arr[i + 1] < 0) {
          arr[i] = (this.random() - 0.5) * 55;
          arr[i + 1] = 22 + this.random() * 8;
          arr[i + 2] = (this.random() - 0.5) * 55;
        }
      }
      this.weather.geometry.attributes.position.needsUpdate = true;
      this.weather.position.set(player.x, player.y, player.z);
    }

    this.cullClock -= dt;
    if (this.cullClock <= 0) {
      this.cullClock = 0.12;
      const limit = this.propDistance + CHUNK * 0.75;
      for (const chunk of this.chunks) {
        const dx = chunk.center.x - cam.x, dz = chunk.center.z - cam.z;
        chunk.group.visible = dx * dx + dz * dz < limit * limit;
      }
    }
  }

  dispose(): void {
    this.clearRegion();
    this.scene.remove(this.group, this.skyRig);
    this.weather.geometry.dispose();
    (this.weather.material as THREE.Material).dispose();
    this.skyGeo.dispose(); this.skyMat.dispose();
    this.gateBeam.geometry.dispose();
  }

  // ------------------------------------------------------------------------------------------------ build

  private track<T extends { dispose(): void }>(obj: T): T { this.tracked.push(obj); return obj; }

  private clearRegion(): void {
    this.regionGroup.removeFromParent();
    for (const item of this.tracked) item.dispose();
    this.tracked = [];
    this.regionGroup = new THREE.Group();
    this.group.add(this.regionGroup);
    for (const child of [...this.startMarkers.children]) this.startMarkers.remove(child);
    this.curves.clear();
    this.roads.clear();
    this.obstacles.clear();
    this.crowns = []; this.chunks = []; this.blades = []; this.ferris = null;
    this.tokenMesh = null; this.tokens = []; this.tulipMesh = null;
    this.tokensCollected = 0; this.tokenTotal = 0;
    this.hf.lakes = []; this.hf.waterY = -Infinity;
  }

  private buildCurves(): void {
    for (const race of this.regionRaces) {
      const points = race.route.map(([x, z]) => new THREE.Vector3(x, this.hf.heightAt(x, z) + 0.12, z));
      this.curves.set(race.id, new THREE.CatmullRomCurve3(points, false, "catmullrom", 0.35));
    }
  }

  private buildTerrain(): void {
    const size = WORLD_HALF * 2;
    const n = TERRAIN_SEGMENTS;
    const geometry = this.track(new THREE.PlaneGeometry(size, size, n, n));
    geometry.rotateX(-Math.PI / 2);
    const positions = geometry.attributes.position;
    const skirtY = Math.min(-4.2, this.hf.waterY - 1.5);
    for (let i = 0; i < positions.count; i++) {
      const row = Math.floor(i / (n + 1)), col = i % (n + 1);
      const edge = row === 0 || row === n || col === 0 || col === n;
      positions.setY(i, edge ? skirtY : this.hf.heightAt(positions.getX(i), positions.getZ(i)));
    }
    geometry.computeVertexNormals();
    const normals = geometry.attributes.normal;
    const colors = new Float32Array(positions.count * 3);
    const random = mulberry32(881);
    for (let i = 0; i < positions.count; i++) {
      const h = positions.getY(i);
      const slope = 1 - Math.min(1, normals.getY(i));
      const rock = Math.max(0, Math.min(1, (slope - 0.1) * 4));
      const shore = Number.isFinite(this.hf.waterY) ? Math.max(0, Math.min(1, (this.hf.waterY + 1 - h) / 1)) : 0;
      const shade = (0.74 + random() * 0.3 + Math.min(Math.max(h, 0) * 0.018, 0.12)) * (1 - shore * 0.3);
      colors[i * 3] = shade * (0.95 + 0.28 * rock);
      colors[i * 3 + 1] = shade * (1 - 0.3 * rock);
      colors[i * 3 + 2] = shade * (0.88 + 0.22 * rock);
    }
    geometry.setAttribute("color", new THREE.BufferAttribute(colors, 3));
    this.terrainMat = this.track(new THREE.MeshLambertMaterial({ color: 0x668348, vertexColors: true }));
    this.regionGroup.add(new THREE.Mesh(geometry, this.terrainMat));

    // Far skirt so the map border dissolves into fog instead of showing a void.
    const skirtGeo = this.track(new THREE.CircleGeometry(2400, 24));
    skirtGeo.rotateX(-Math.PI / 2);
    this.skirtMat = this.track(new THREE.MeshLambertMaterial({ color: 0x668348 }));
    const skirt = new THREE.Mesh(skirtGeo, this.skirtMat);
    skirt.position.y = skirtY - 0.05;
    this.regionGroup.add(skirt);
  }

  private buildRoads(): void {
    interface Batch { pos: number[]; idx: number[] }
    const asphalt: Batch = { pos: [], idx: [] };
    const dirt: Batch = { pos: [], idx: [] };
    const marks: Batch = { pos: [], idx: [] };
    const posts: number[] = [];
    const p = new THREE.Vector3(), tangent = new THREE.Vector3();
    const quad = (batch: Batch, a: number[], b: number[], c: number[], d: number[]): void => {
      // a/b = hi/lo edge at the start sample, c/d = hi/lo edge at the end sample (same winding as the road ribbon).
      const base = batch.pos.length / 3;
      batch.pos.push(...a, ...b, ...c, ...d);
      batch.idx.push(base, base + 2, base + 1, base + 2, base + 3, base + 1);
    };

    this.regionRaces.forEach((race, ri) => {
      const curve = this.curves.get(race.id)!;
      const isDirt = race.id === "forest";
      const half = isDirt ? 6.2 : 7.4;
      const count = Math.ceil(curve.getLength() / 3);
      const batch = isDirt ? dirt : asphalt;
      const lift = ri * 0.02;
      const base = batch.pos.length / 3;
      let prev: { x: number; y: number; z: number; nx: number; nz: number } | null = null;
      for (let i = 0; i <= count; i++) {
        const t = i / count;
        curve.getPointAt(t, p);
        curve.getTangentAt(t, tangent);
        const nx = -tangent.z, nz = tangent.x;
        batch.pos.push(p.x + nx * half, p.y + lift, p.z + nz * half, p.x - nx * half, p.y + lift, p.z - nz * half);
        this.roads.add(p.x, p.z);
        if (i < count) { const a = base + i * 2; batch.idx.push(a, a + 2, a + 1, a + 2, a + 3, a + 1); }
        const cur = { x: p.x, y: p.y + lift + 0.03, z: p.z, nx, nz };
        if (prev && !isDirt) {
          const edge = (o1: number, o2: number): void => quad(
            marks,
            [prev!.x + prev!.nx * o1, prev!.y, prev!.z + prev!.nz * o1], [prev!.x + prev!.nx * o2, prev!.y, prev!.z + prev!.nz * o2],
            [cur.x + nx * o1, cur.y, cur.z + nz * o1], [cur.x + nx * o2, cur.y, cur.z + nz * o2],
          );
          edge(half - 0.35, half - 0.62);
          edge(-(half - 0.62), -(half - 0.35));
          if ((i - 1) % 4 === 0) edge(0.1, -0.1);
        }
        if (i % 8 === 0) {
          for (const side of [-1, 1]) posts.push(p.x + nx * side * (half + 1.5), p.z + nz * side * (half + 1.5));
        }
        prev = cur;
      }
    });

    const make = (batch: Batch, material: THREE.Material, order = 0): void => {
      if (!batch.idx.length) return;
      const geometry = this.track(new THREE.BufferGeometry());
      geometry.setAttribute("position", new THREE.Float32BufferAttribute(batch.pos, 3));
      geometry.setIndex(batch.idx);
      geometry.computeVertexNormals();
      const mesh = new THREE.Mesh(geometry, material);
      mesh.renderOrder = order;
      this.regionGroup.add(mesh);
    };
    const roadOffset = { polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2 };
    this.asphaltMat = this.track(new THREE.MeshLambertMaterial({ color: 0x353838, ...roadOffset }));
    this.dirtMat = this.track(new THREE.MeshLambertMaterial({ color: 0x7a5d3d, ...roadOffset }));
    const markMat = this.track(new THREE.MeshBasicMaterial({ color: 0xece6cf, polygonOffset: true, polygonOffsetFactor: -4, polygonOffsetUnits: -4 }));
    make(asphalt, this.asphaltMat); make(dirt, this.dirtMat); make(marks, markMat, 1);

    // Roadside posts: strong speed cue for almost no cost (one instanced draw call).
    if (posts.length) {
      const geo = this.track(new THREE.BoxGeometry(0.16, 0.95, 0.16)); geo.translate(0, 0.475, 0);
      const mat = this.track(new THREE.MeshLambertMaterial({ color: 0xe9e9e2 }));
      const mesh = this.track(new THREE.InstancedMesh(geo, mat, posts.length / 2));
      for (let i = 0; i < posts.length; i += 2) {
        this.tmpP.set(posts[i], this.heightAt(posts[i], posts[i + 1]), posts[i + 1]);
        this.tmpM.compose(this.tmpP, this.tmpQ.identity(), this.tmpS.set(1, 1, 1));
        mesh.setMatrixAt(i / 2, this.tmpM);
      }
      mesh.frustumCulled = false;
      this.regionGroup.add(mesh);
    }
  }

  private nearRoad(x: number, z: number, r: number): boolean { return this.roads.near(x, z, r); }

  private buildProps(): void {
    const st = this.style;
    const rnd = this.random;

    // ----- Houses (placed first so trees can avoid them) -----
    const total = st.zones.reduce((sum, zone) => sum + zone.count, 0);
    const wallGeo = this.track(new THREE.BoxGeometry(1, 1, 1));
    const roofGeo = this.track(new THREE.ConeGeometry(st.steepRoof ? 0.74 : 0.72, st.steepRoof ? 0.95 : 0.5, 4));
    roofGeo.rotateY(Math.PI / 4);
    const walls = this.track(new THREE.InstancedMesh(wallGeo, this.track(new THREE.MeshLambertMaterial({ color: 0xffffff })), Math.max(1, total)));
    const roofs = this.track(new THREE.InstancedMesh(roofGeo, this.track(new THREE.MeshLambertMaterial({ color: 0xffffff })), Math.max(1, total)));
    let placed = 0;
    for (const zone of st.zones) {
      let local = 0, attempts = 0;
      while (local < zone.count && attempts++ < 800) {
        const x = zone.x + (rnd() - 0.5) * zone.spread * 2;
        const z = zone.z + (rnd() - 0.5) * zone.spread * 2;
        if (this.nearRoad(x, z, 15) || this.hf.isWater(x, z) || this.hf.heightAt(x, z) < this.hf.waterY + 1) continue;
        const w = 5 + rnd() * 5, h = 4 + rnd() * 5, depth = 5 + rnd() * 5;
        if (this.obstacles.blocked(x, z, Math.max(w, depth) * 0.6 + 2)) continue;
        const y = this.hf.heightAt(x, z);
        this.tmpQ.setFromAxisAngle(this.yAxis, Math.round(rnd() * 4) * Math.PI / 2);
        this.tmpP.set(x, y + h / 2, z); this.tmpS.set(w, h, depth);
        this.tmpM.compose(this.tmpP, this.tmpQ, this.tmpS); walls.setMatrixAt(placed, this.tmpM);
        const roofH = st.steepRoof ? h * 0.95 : h * 0.65;
        this.tmpP.set(x, y + h + roofH * 0.26, z); this.tmpS.set(w * 1.06, roofH, depth * 1.06);
        this.tmpM.compose(this.tmpP, this.tmpQ, this.tmpS); roofs.setMatrixAt(placed, this.tmpM);
        walls.setColorAt(placed, this.tmpA.setHex(st.walls[Math.floor(rnd() * st.walls.length)]));
        roofs.setColorAt(placed, this.tmpA.setHex(st.roofs[Math.floor(rnd() * st.roofs.length)]));
        this.obstacles.add({ x, z, radius: Math.max(w, depth) * 0.54 });
        placed++; local++;
      }
    }
    walls.count = placed; roofs.count = placed;
    walls.frustumCulled = false; roofs.frustumCulled = false;
    this.regionGroup.add(walls, roofs);

    // ----- Trees (chunked instancing) -----
    const trees: TreeRec[] = [];
    const tryTree = (x: number, z: number, rank: number, forceKind?: 0 | 1): void => {
      if (Math.abs(x) > WORLD_HALF - 14 || Math.abs(z) > WORLD_HALF - 14) return;
      if (this.nearRoad(x, z, 11.5)) return;
      const y = this.hf.heightAt(x, z);
      if (y < this.hf.waterY + 0.5) return;
      if (Math.hypot(x, z - 180) < 32) return; // festival arch + spawn
      if (this.obstacles.blocked(x, z, 3)) return;
      const s = 0.75 + rnd() * 0.85;
      trees.push({
        x, y, z, s, rot: rnd() * Math.PI * 2, rank,
        kind: forceKind ?? (rnd() < st.conifer ? 1 : 0), shade: 0.74 + rnd() * 0.42, hue: rnd(),
      });
    };
    let attempts = 0;
    const wanted = st.trees;
    let got = 0;
    while (got < wanted && attempts++ < wanted * 6) {
      const x = (rnd() - 0.5) * (WORLD_HALF * 2 - 20), z = (rnd() - 0.5) * (WORLD_HALF * 2 - 20);
      // clustered groves: noise mask makes forests and meadows instead of uniform scatter
      const mask = Math.sin(x * 0.011 + 1.3) * Math.sin(z * 0.013 + 0.4) + Math.sin((x + z) * 0.006) * 0.6;
      if (rnd() > 0.28 + Math.max(0, mask) * 0.9) continue;
      const before = trees.length;
      tryTree(x, z, rnd());
      if (trees.length > before) got++;
    }
    if (st.avenue > 0) {
      for (const curve of this.curves.values()) {
        const length = curve.getLength();
        const step = st.avenue / length;
        const p = new THREE.Vector3(), tg = new THREE.Vector3();
        for (let t = 0; t < 1; t += step) {
          curve.getPointAt(t, p); curve.getTangentAt(t, tg);
          for (const side of [-1, 1]) {
            const off = side * (9.6 + rnd() * 1.2);
            // Tree-lined roads: placed just outside the verge (tryTree's wider clearance is bypassed on purpose).
            const x = p.x - tg.z * off, z = p.z + tg.x * off;
            if (Math.abs(x) > WORLD_HALF - 14 || Math.abs(z) > WORLD_HALF - 14) continue;
            const y = this.hf.heightAt(x, z);
            if (y < this.hf.waterY + 0.5 || this.obstacles.blocked(x, z, 3) || this.nearRoad(x, z, 8.6)) continue;
            trees.push({ x, y, z, s: 0.9 + rnd() * 0.5, rot: rnd() * 6.28, rank: rnd() * 0.4, kind: 0, shade: 0.8 + rnd() * 0.3, hue: rnd() });
          }
        }
      }
    }
    trees.sort((a, b) => a.rank - b.rank);

    const trunkGeo = this.track(new THREE.CylinderGeometry(0.15, 0.26, 2.2, 5)); trunkGeo.translate(0, 1.1, 0);
    const broadGeo = this.track(new THREE.IcosahedronGeometry(1.7, 0)); broadGeo.scale(1, 0.9, 1); broadGeo.translate(0, 3.1, 0);
    const c1 = new THREE.ConeGeometry(1.9, 2.8, 6); c1.translate(0, 2.7, 0);
    const c2 = new THREE.ConeGeometry(1.5, 2.5, 6); c2.translate(0, 4.1, 0);
    const c3 = new THREE.ConeGeometry(1.0, 2.1, 6); c3.translate(0, 5.4, 0);
    const coniGeo = this.track(mergeGeometries([c1, c2, c3], false)!);
    c1.dispose(); c2.dispose(); c3.dispose();
    const trunkMat = this.track(new THREE.MeshLambertMaterial({ color: 0x574736 }));
    const crownMat = this.track(new THREE.MeshLambertMaterial({ color: 0xffffff, flatShading: true }));

    const buckets = new Map<number, TreeRec[]>();
    for (const t of trees) {
      const cx = Math.max(0, Math.min(CHUNKS - 1, Math.floor((t.x + WORLD_HALF) / CHUNK)));
      const cz = Math.max(0, Math.min(CHUNKS - 1, Math.floor((t.z + WORLD_HALF) / CHUNK)));
      const key = cx * 100 + cz;
      let list = buckets.get(key);
      if (!list) { list = []; buckets.set(key, list); }
      list.push(t);
      if (t.rank < 0.45) this.obstacles.add({ x: t.x, z: t.z, radius: 0.3 * t.s });
    }
    const place = (mesh: THREE.InstancedMesh, i: number, t: TreeRec): void => {
      this.tmpQ.setFromAxisAngle(this.yAxis, t.rot);
      this.tmpP.set(t.x, t.y, t.z); this.tmpS.set(t.s, t.s, t.s);
      this.tmpM.compose(this.tmpP, this.tmpQ, this.tmpS);
      mesh.setMatrixAt(i, this.tmpM);
    };
    for (const [key, list] of buckets) {
      const cx = Math.floor(key / 100), cz = key % 100;
      const group = new THREE.Group();
      const meshes: THREE.InstancedMesh[] = [];
      const totals: number[] = [];
      const trunks = this.track(new THREE.InstancedMesh(trunkGeo, trunkMat, list.length));
      list.forEach((t, i) => place(trunks, i, t));
      trunks.instanceMatrix.needsUpdate = true; trunks.computeBoundingSphere();
      group.add(trunks); meshes.push(trunks); totals.push(list.length);
      for (const kind of [0, 1] as const) {
        const subset = list.filter((t) => t.kind === kind);
        if (!subset.length) continue;
        const mesh = this.track(new THREE.InstancedMesh(kind === 0 ? broadGeo : coniGeo, crownMat, subset.length));
        const data = new Float32Array(subset.length * 2);
        subset.forEach((t, i) => { place(mesh, i, t); data[i * 2] = t.shade; data[i * 2 + 1] = t.hue; mesh.setColorAt(i, this.tmpA.setHex(0xffffff)); });
        mesh.instanceMatrix.needsUpdate = true; mesh.computeBoundingSphere();
        group.add(mesh); meshes.push(mesh); totals.push(subset.length);
        this.crowns.push({ mesh, data });
      }
      this.regionGroup.add(group);
      this.chunks.push({
        group, meshes, totals,
        center: new THREE.Vector3(-WORLD_HALF + (cx + 0.5) * CHUNK, 0, -WORLD_HALF + (cz + 0.5) * CHUNK),
      });
    }

    // ----- Rocks -----
    if (st.rocks > 0) {
      const rockGeo = this.track(new THREE.DodecahedronGeometry(1, 0));
      const rockMat = this.track(new THREE.MeshLambertMaterial({ color: 0xffffff, flatShading: true }));
      const mesh = this.track(new THREE.InstancedMesh(rockGeo, rockMat, st.rocks));
      let n = 0, tries = 0;
      while (n < st.rocks && tries++ < st.rocks * 8) {
        const x = (rnd() - 0.5) * (WORLD_HALF * 2 - 30), z = (rnd() - 0.5) * (WORLD_HALF * 2 - 30);
        if (this.nearRoad(x, z, 10.5) || this.obstacles.blocked(x, z, 2) || this.hf.heightAt(x, z) < this.hf.waterY + 0.4) continue;
        const s = 0.6 + rnd() * rnd() * 2.4;
        this.tmpQ.setFromAxisAngle(this.yAxis, rnd() * 6.28);
        this.tmpP.set(x, this.hf.heightAt(x, z) + s * 0.35, z); this.tmpS.set(s * 1.2, s * 0.8, s);
        this.tmpM.compose(this.tmpP, this.tmpQ, this.tmpS);
        mesh.setMatrixAt(n, this.tmpM);
        mesh.setColorAt(n, this.tmpA.setHex(0x7d8286).multiplyScalar(0.8 + rnd() * 0.4));
        if (s > 1.2) this.obstacles.add({ x, z, radius: s * 0.95 });
        n++;
      }
      mesh.count = n; mesh.frustumCulled = false;
      this.regionGroup.add(mesh);
    }

    // ----- Landmarks -----
    this.buildArch();
    for (const [x, z] of st.windmills) this.buildWindmill(x, z, st.windmills.length > 1 ? 1.15 : 1);
    if (st.ferris) this.buildFerrisWheel(65, 225);
    this.buildTulips();
  }

  private buildArch(): void {
    const stone = this.track(new THREE.MeshLambertMaterial({ color: 0x283239 }));
    const orange = this.track(new THREE.MeshBasicMaterial({ color: 0xff9d3c }));
    const pillarGeo = this.track(new THREE.BoxGeometry(0.8, 7, 0.8)); pillarGeo.translate(0, 3.5, 0);
    const bannerGeo = this.track(new THREE.BoxGeometry(19, 1.1, 0.65));
    const festival = new THREE.Group();
    for (const x of [-9, 9]) { const pillar = new THREE.Mesh(pillarGeo, stone); pillar.position.x = x; festival.add(pillar); }
    const banner = new THREE.Mesh(bannerGeo, orange); banner.position.y = 7; festival.add(banner);
    festival.position.set(0, this.heightAt(0, 180), 180);
    this.regionGroup.add(festival);
  }

  private buildWindmill(x: number, z: number, scale: number): void {
    const stone = this.track(new THREE.MeshLambertMaterial({ color: 0xe3d7bd }));
    const dark = this.track(new THREE.MeshLambertMaterial({ color: 0x283239 }));
    const towerGeo = this.track(new THREE.CylinderGeometry(2.4, 3.5, 12, 10)); towerGeo.translate(0, 6, 0);
    const parts: THREE.BufferGeometry[] = [];
    for (let i = 0; i < 4; i++) { const b = new THREE.BoxGeometry(0.35, 8, 0.18); b.translate(0, 4, 0); b.rotateZ(i * Math.PI / 2); parts.push(b); }
    const bladeGeo = this.track(mergeGeometries(parts, false)!);
    parts.forEach((g) => g.dispose());
    const mill = new THREE.Group();
    mill.add(new THREE.Mesh(towerGeo, stone));
    const blades = new THREE.Mesh(bladeGeo, dark);
    blades.position.set(0, 9, 2.7);
    mill.add(blades);
    this.blades.push(blades);
    mill.scale.setScalar(scale);
    mill.position.set(x, this.heightAt(x, z), z);
    mill.rotation.y = this.random() * Math.PI * 2;
    this.regionGroup.add(mill);
    this.obstacles.add({ x, z, radius: 3.6 * scale });
  }

  private buildFerrisWheel(x: number, z: number): void {
    const orange = this.track(new THREE.MeshBasicMaterial({ color: 0xff9d3c }));
    const stone = this.track(new THREE.MeshLambertMaterial({ color: 0xe3d7bd }));
    const ringGeo = this.track(new THREE.TorusGeometry(10, 0.28, 6, 32));
    const spokes: THREE.BufferGeometry[] = [];
    for (let i = 0; i < 8; i++) { const s = new THREE.BoxGeometry(0.14, 20, 0.14); s.rotateZ(i * Math.PI / 8); spokes.push(s); }
    const spokeGeo = this.track(mergeGeometries(spokes, false)!);
    spokes.forEach((g) => g.dispose());
    const wheel = new THREE.Group();
    wheel.add(new THREE.Mesh(ringGeo, orange), new THREE.Mesh(spokeGeo, stone));
    wheel.position.set(x, this.heightAt(x, z) + 13, z);
    this.ferris = wheel;
    this.regionGroup.add(wheel);
    this.obstacles.add({ x, z, radius: 2 });
  }

  private buildTulips(): void {
    const fields = this.style.tulips;
    if (!fields.length) return;
    const cell = 3;
    const palette = [0xe63946, 0xffd166, 0xf72585, 0xf1f1f1, 0x9b5de5, 0xff8c42];
    const spots: Array<[number, number, number]> = [];
    fields.forEach((f, fi) => {
      const cols = Math.floor(f.w / cell), rows = Math.floor(f.d / cell);
      for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++) {
        const x = f.x - f.w / 2 + (c + 0.5) * cell, z = f.z - f.d / 2 + (r + 0.5) * cell;
        if (this.nearRoad(x, z, 10) || this.obstacles.blocked(x, z, 1)) continue;
        spots.push([x, z, palette[(Math.floor(c / 2) + fi * 2) % palette.length]]);
      }
    });
    if (!spots.length) return;
    const geo = this.track(new THREE.PlaneGeometry(cell * 0.92, cell * 0.92)); geo.rotateX(-Math.PI / 2);
    const mesh = this.track(new THREE.InstancedMesh(geo, this.track(new THREE.MeshLambertMaterial({ color: 0xffffff })), spots.length));
    spots.forEach(([x, z, color], i) => {
      this.tmpP.set(x, this.heightAt(x, z) + 0.1, z);
      this.tmpM.compose(this.tmpP, this.tmpQ.identity(), this.tmpS.set(1, 1, 1));
      mesh.setMatrixAt(i, this.tmpM);
      mesh.setColorAt(i, this.tmpA.setHex(color));
    });
    mesh.frustumCulled = false;
    this.tulipMesh = mesh;
    this.regionGroup.add(mesh);
  }

  private buildTokens(): void {
    const count = 28;
    const list = [...this.curves.values()];
    if (!list.length) return;
    const p = new THREE.Vector3();
    for (let i = 0; i < count; i++) {
      const curve = list[i % list.length];
      curve.getPointAt(this.random() * 0.96 + 0.02, p);
      const off = (this.random() - 0.5) * 8;
      const x = p.x + off * 0.9, z = p.z - off * 0.4;
      this.tokens.push({ x, z, y: this.heightAt(x, z) + 1.1, alive: true });
    }
    this.tokenTotal = this.tokens.length;
    const geo = this.track(new THREE.OctahedronGeometry(0.75));
    const mat = this.track(new THREE.MeshBasicMaterial({ color: 0xffc83a }));
    this.tokenMesh = this.track(new THREE.InstancedMesh(geo, mat, this.tokens.length));
    this.tokenMesh.frustumCulled = false;
    this.regionGroup.add(this.tokenMesh);
  }

  private buildMountains(): void {
    const pk = this.style.peaks;
    const rnd = mulberry32(4242 + pk.count);
    // Position-based jitter: the cone's seam vertices are duplicated, so random() per vertex would open cracks.
    const jitter = (a: number, b: number, c: number): number => { const v = Math.sin(a * 12.9898 + b * 78.233 + c * 37.719) * 43758.5453; return v - Math.floor(v); };
    const parts: THREE.BufferGeometry[] = [];
    const foot = new THREE.Color(pk.foot), rock = new THREE.Color(pk.rock), snow = new THREE.Color(0xf4f7fb);
    const col = new THREE.Color();
    const tValues: number[] = [];
    for (let i = 0; i < pk.count; i++) {
      const angle = (i / pk.count) * Math.PI * 2 + (rnd() - 0.5) * 0.18;
      const radius = 520 + rnd() * 90;
      const height = pk.height * (0.55 + rnd() * 0.6);
      const base = height * (0.78 + rnd() * 0.3);
      const geo = new THREE.ConeGeometry(base, height, 7, 3);
      const pos = geo.attributes.position;
      const colors = new Float32Array(pos.count * 3);
      for (let v = 0; v < pos.count; v++) {
        const x = pos.getX(v), y = pos.getY(v), z = pos.getZ(v);
        const t = (y + height / 2) / height; // 0 foot .. 1 summit
        if (t < 0.97) {
          const k = 0.85 + jitter(x, y, z + i) * 0.3;
          pos.setX(v, x * k); pos.setZ(v, z * k);
        }
        if (t < 0.32) col.copy(foot).lerp(rock, t / 0.32);
        else if (pk.snow && t > 0.62) col.copy(rock).lerp(snow, Math.min(1, (t - 0.62) / 0.12));
        else col.copy(rock);
        col.toArray(colors, v * 3);
        tValues.push(t);
      }
      geo.setAttribute("color", new THREE.BufferAttribute(colors, 3));
      geo.translate(Math.cos(angle) * radius, height / 2 - 22, Math.sin(angle) * radius);
      parts.push(geo);
    }
    const merged = this.track(mergeGeometries(parts, false)!);
    parts.forEach((g) => g.dispose());
    this.mountainColor = merged.attributes.color as THREE.BufferAttribute;
    this.mountainBase = new Float32Array(this.mountainColor.array as ArrayLike<number>);
    this.mountainT = new Float32Array(tValues);
    this.mountainMat = this.track(new THREE.MeshLambertMaterial({ vertexColors: true, flatShading: true, fog: false }));
    const mesh = new THREE.Mesh(merged, this.mountainMat);
    mesh.frustumCulled = false;
    this.regionGroup.add(mesh);
  }

  private buildWater(): void {
    const geo = this.track(new THREE.PlaneGeometry(WORLD_HALF * 2 + 200, WORLD_HALF * 2 + 200)); geo.rotateX(-Math.PI / 2);
    this.waterMat = this.track(new THREE.MeshLambertMaterial({ color: 0x2f6f8f, transparent: true, opacity: 0.9 }));
    const water = new THREE.Mesh(geo, this.waterMat);
    water.position.y = this.hf.waterY;
    this.regionGroup.add(water);
  }

  private buildStartMarkers(): void {
    this.regionRaces.forEach((race, index) => {
      const [x, z] = race.route[0];
      const ring = new THREE.Mesh(
        this.track(new THREE.TorusGeometry(3.2, 0.16, 6, 28)),
        this.track(new THREE.MeshBasicMaterial({ color: [0xffa84c, 0x68e0ab, 0x91b5ff][index % 3], transparent: true, opacity: 0.85 })),
      );
      ring.rotation.x = Math.PI / 2;
      ring.position.set(x + index * 8, this.heightAt(x, z) + 0.55, z + 8);
      this.startMarkers.add(ring);
    });
  }

  // ---------------------------------------------------------------------------------- persistent pieces

  private buildSky(): void {
    this.skyGeo = new THREE.SphereGeometry(SKY_RADIUS, 20, 12);
    const count = this.skyGeo.attributes.position.count;
    this.skyGeo.setAttribute("color", new THREE.BufferAttribute(new Float32Array(count * 3), 3));
    this.skyMat = new THREE.MeshBasicMaterial({ vertexColors: true, side: THREE.BackSide, fog: false, depthWrite: false, depthTest: false });
    const dome = new THREE.Mesh(this.skyGeo, this.skyMat);
    dome.renderOrder = -10; dome.frustumCulled = false;
    this.skyRig.add(dome);

    // Stars
    const rnd = mulberry32(777);
    const starPos = new Float32Array(260 * 3);
    for (let i = 0; i < 260; i++) {
      const a = rnd() * Math.PI * 2, e = 0.08 + rnd() * 1.4;
      const r = SKY_RADIUS * 0.96;
      starPos[i * 3] = Math.cos(a) * Math.cos(e) * r; starPos[i * 3 + 1] = Math.sin(e) * r; starPos[i * 3 + 2] = Math.sin(a) * Math.cos(e) * r;
    }
    const starGeo = new THREE.BufferGeometry();
    starGeo.setAttribute("position", new THREE.BufferAttribute(starPos, 3));
    this.stars = new THREE.Points(starGeo, new THREE.PointsMaterial({ color: 0xffffff, size: 1.7, sizeAttenuation: false, transparent: true, opacity: 0, depthWrite: false, fog: false }));
    this.stars.renderOrder = -9; this.stars.frustumCulled = false; this.stars.visible = false;
    this.skyRig.add(this.stars);

    // Sun (disc + soft halo) and moon
    this.sunDisc = new THREE.Mesh(new THREE.SphereGeometry(20, 12, 8), new THREE.MeshBasicMaterial({ color: 0xfff3d0, fog: false, depthTest: false, depthWrite: false }));
    this.sunDisc.renderOrder = -8;
    const halo = new THREE.Mesh(new THREE.SphereGeometry(58, 12, 8), new THREE.MeshBasicMaterial({ color: 0xffd9a0, fog: false, transparent: true, opacity: 0.16, blending: THREE.AdditiveBlending, depthWrite: false }));
    halo.renderOrder = -7;
    this.sunGroup.add(this.sunDisc, halo);
    this.skyRig.add(this.sunGroup);
    this.moon = new THREE.Mesh(new THREE.SphereGeometry(13, 10, 8), new THREE.MeshBasicMaterial({ color: 0xd5dcff, fog: false, depthTest: false, depthWrite: false }));
    this.moon.renderOrder = -8; this.moon.visible = false;
    this.skyRig.add(this.moon);

    // Clouds: ~16 low-poly puffs merged into a single mesh (one draw call).
    const cr = mulberry32(1234);
    const puffs: THREE.BufferGeometry[] = [];
    for (let i = 0; i < 16; i++) {
      const a = cr() * Math.PI * 2, d = 90 + cr() * 330, y = 105 + cr() * 55;
      const parts = 3 + Math.floor(cr() * 3);
      for (let k = 0; k < parts; k++) {
        const puff = new THREE.IcosahedronGeometry(1, 1);
        const s = 18 + cr() * 22;
        puff.scale(s * 1.5, s * 0.5, s);
        puff.translate(Math.cos(a) * d + (k - parts / 2) * 26 * 0.8, y + cr() * 5, Math.sin(a) * d + (cr() - 0.5) * 18);
        puffs.push(puff);
      }
    }
    const cloudGeo = mergeGeometries(puffs, false)!;
    puffs.forEach((g) => g.dispose());
    this.cloudMat = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.9, depthWrite: false });
    this.clouds = new THREE.Mesh(cloudGeo, this.cloudMat);
    this.clouds.frustumCulled = false; this.clouds.renderOrder = -1;
    this.scene.add(this.clouds);
    this.scene.add(this.skyRig);
  }

  private recolorSky(top: THREE.Color, horizon: THREE.Color, sunDir: THREE.Vector3, glow: number): void {
    const pos = this.skyGeo.attributes.position, col = this.skyGeo.attributes.color;
    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i) / SKY_RADIUS, y = pos.getY(i) / SKY_RADIUS, z = pos.getZ(i) / SKY_RADIUS;
      const t = Math.pow(Math.max(0, Math.min(1, y)), 0.5);
      let r = horizon.r + (top.r - horizon.r) * t, g = horizon.g + (top.g - horizon.g) * t, b = horizon.b + (top.b - horizon.b) * t;
      if (glow > 0.01) {
        const d = Math.max(0, x * sunDir.x + y * sunDir.y + z * sunDir.z);
        const k = Math.pow(d, 5) * glow * 0.9;
        r += WARM.r * k; g += WARM.g * k; b += WARM.b * k;
      }
      col.setXYZ(i, r, g, b);
    }
    col.needsUpdate = true;
    this.recolorMountains(horizon);
  }

  /** Mountains ignore scene fog (they sit beyond it), so their foot is hazed toward the horizon colour by hand. */
  private recolorMountains(horizon: THREE.Color): void {
    if (!this.mountainBase.length) return;
    const arr = this.mountainColor.array as Float32Array;
    const tint = this.mountainTint;
    for (let i = 0; i < this.mountainT.length; i++) {
      const haze = Math.pow(1 - this.mountainT[i], 1.6) * 0.88;
      const r = this.mountainBase[i * 3] * tint.r, g = this.mountainBase[i * 3 + 1] * tint.g, b = this.mountainBase[i * 3 + 2] * tint.b;
      arr[i * 3] = r + (horizon.r - r) * haze;
      arr[i * 3 + 1] = g + (horizon.g - g) * haze;
      arr[i * 3 + 2] = b + (horizon.b - b) * haze;
    }
    this.mountainColor.needsUpdate = true;
  }

  private recolorCrowns(): void {
    const base = this.tmpA.setHex(this.foliageHex), alt = this.tmpB.setHex(this.foliageAltHex);
    const c = this.tmpC;
    for (const set of this.crowns) {
      const n = set.data.length / 2;
      for (let i = 0; i < n; i++) {
        c.copy(base).lerp(alt, set.data[i * 2 + 1] * this.foliageAltMax).multiplyScalar(set.data[i * 2]);
        set.mesh.setColorAt(i, c);
      }
      if (set.mesh.instanceColor) set.mesh.instanceColor.needsUpdate = true;
    }
  }

  private buildGate(): THREE.Group {
    const gate = new THREE.Group();
    const glow = new THREE.MeshBasicMaterial({ color: 0xffc45c });
    const dark = new THREE.MeshLambertMaterial({ color: 0x17252a });
    const pillarGeo = new THREE.BoxGeometry(0.5, 5.5, 0.5); pillarGeo.translate(0, 2.75, 0);
    const lightGeo = new THREE.BoxGeometry(0.62, 1.5, 0.62); lightGeo.translate(0, 4.5, 0);
    for (const x of [-8.5, 8.5]) {
      const pillar = new THREE.Mesh(pillarGeo, dark); pillar.position.x = x; gate.add(pillar);
      const light = new THREE.Mesh(lightGeo, glow); light.position.x = x; gate.add(light);
    }
    const top = new THREE.Mesh(new THREE.BoxGeometry(17.5, 0.55, 0.55), glow);
    top.position.y = 5.5;
    gate.add(top);
    // Tall translucent beam so the next checkpoint is visible from far away.
    const beamGeo = new THREE.CylinderGeometry(1.1, 1.1, 90, 10, 1, true); beamGeo.translate(0, 45, 0);
    this.gateBeam = new THREE.Mesh(beamGeo, new THREE.MeshBasicMaterial({ color: 0xffb54a, transparent: true, opacity: 0.2, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, fog: false }));
    this.gateBeam.frustumCulled = false;
    gate.add(this.gateBeam);
    return gate;
  }

  private buildWeather(): void {
    const count = 420;
    const positions = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      positions[i * 3] = (this.random() - 0.5) * 55;
      positions[i * 3 + 1] = this.random() * 30;
      positions[i * 3 + 2] = (this.random() - 0.5) * 55;
    }
    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute("position", new THREE.BufferAttribute(positions, 3));
    const material = new THREE.PointsMaterial({ color: 0xc7e5f2, size: 0.11, transparent: true, opacity: 0.7, depthWrite: false });
    const points = new THREE.Points(geometry, material);
    points.frustumCulled = false;
    this.group.add(points);
    this.weather = points;
    this.weatherPositions = positions;
  }
}

