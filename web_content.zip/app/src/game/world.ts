/**
 * world.ts — terrain, biomes, props, sky, day/night cycle, weather, water, waystones.
 * The kingdom of Erath: Ash Forest (center), Ruined City (N), Ice Mountains (E),
 * Spirit Swamp (S), Bone Desert (W), Shadow Castle plateau (far N).
 */
import * as THREE from "three";
import { ValueNoise, mulberry32, clamp, lerp, smoothstep, dist2 } from "./noise";
import { WORLD } from "./config";

export type ZoneId = "temple" | "forest" | "city" | "ice" | "swamp" | "desert" | "castle";
export type WeatherKind = "clear" | "rain" | "storm" | "fog";

export interface Waystone { id: string; x: number; z: number; name: string; discovered: boolean; mesh: THREE.Object3D; }

interface ZoneStyle {
  ground: THREE.Color; ground2: THREE.Color;
  fogColor: THREE.Color; fogDay: number; fogNight: number;
  treeColor: THREE.Color; density: number;
}

const Z: Record<ZoneId, ZoneStyle> = {
  temple: { ground: new THREE.Color(0x3a4152), ground2: new THREE.Color(0x2c3242), fogColor: new THREE.Color(0x1c2030), fogDay: 40, fogNight: 55, treeColor: new THREE.Color(0x44404f), density: 0.1 },
  forest: { ground: new THREE.Color(0x2e3038), ground2: new THREE.Color(0x23252e), fogColor: new THREE.Color(0x272b3a), fogDay: 55, fogNight: 42, treeColor: new THREE.Color(0x3d3347), density: 1 },
  city:   { ground: new THREE.Color(0x3c3a42), ground2: new THREE.Color(0x2b2a33), fogColor: new THREE.Color(0x2b2836), fogDay: 70, fogNight: 50, treeColor: new THREE.Color(0x4a3b52), density: 0.25 },
  ice:    { ground: new THREE.Color(0xb9c7d8), ground2: new THREE.Color(0x8fa4bd), fogColor: new THREE.Color(0x8fa5c0), fogDay: 80, fogNight: 60, treeColor: new THREE.Color(0x223448), density: 0.7 },
  swamp:  { ground: new THREE.Color(0x2c3a2a), ground2: new THREE.Color(0x1e2b22), fogColor: new THREE.Color(0x24352c), fogDay: 30, fogNight: 22, treeColor: new THREE.Color(0x33422e), density: 0.8 },
  desert: { ground: new THREE.Color(0x9c8a68), ground2: new THREE.Color(0x7e6e52), fogColor: new THREE.Color(0x9a8a70), fogDay: 85, fogNight: 70, treeColor: new THREE.Color(0x5a4c3a), density: 0.2 },
  castle: { ground: new THREE.Color(0x26232e), ground2: new THREE.Color(0x1a1824), fogColor: new THREE.Color(0x171423), fogDay: 60, fogNight: 45, treeColor: new THREE.Color(0x1c1626), density: 0.4 },
};

export class World {
  scene: THREE.Scene;
  noise = new ValueNoise(WORLD.SEED);
  sun: THREE.DirectionalLight;
  moon: THREE.DirectionalLight;
  hemi: THREE.HemisphereLight;
  ambient: THREE.AmbientLight;
  stars: THREE.Points;
  sunMesh: THREE.Mesh;
  moonMesh: THREE.Mesh;

  timeOfDay = 0.32; // 0..1, 0.25=sunrise 0.5=noon 0.75=sunset
  weather: WeatherKind = "clear";
  private weatherTimer = 40;
  private rainPts: THREE.Points;
  private snowPts: THREE.Points;
  private rainVel: Float32Array;
  private snowVel: Float32Array;
  water: THREE.Mesh;
  waterLevel = -0.4;

  waystones: Waystone[] = [];
  private propColliders: { x: number; z: number; r: number }[] = [];
  private grassMat!: THREE.ShaderMaterial;
  private treeSway: THREE.InstancedMesh[] = [];
  private tmpM = new THREE.Matrix4();
  private tmpC = new THREE.Color();
  private castleGate: THREE.Group;

  get night(): boolean { return this.timeOfDay < 0.22 || this.timeOfDay > 0.78; }

  constructor(scene: THREE.Scene) {
    this.scene = scene;
    scene.fog = new THREE.FogExp2(0x272b3a, 0.012);

    this.hemi = new THREE.HemisphereLight(0x8fa3c7, 0x2a2438, 0.55);
    scene.add(this.hemi);
    this.ambient = new THREE.AmbientLight(0x404860, 0.35);
    scene.add(this.ambient);
    this.sun = new THREE.DirectionalLight(0xffd9a0, 1.3);
    this.sun.castShadow = true;
    this.sun.shadow.mapSize.set(2048, 2048);
    const sc = this.sun.shadow.camera;
    sc.left = -60; sc.right = 60; sc.top = 60; sc.bottom = -60; sc.near = 1; sc.far = 260;
    this.sun.shadow.bias = -0.0015;
    scene.add(this.sun); scene.add(this.sun.target);
    this.moon = new THREE.DirectionalLight(0x8fa8ff, 0.0);
    scene.add(this.moon); scene.add(this.moon.target);

    // sun & moon discs
    this.sunMesh = new THREE.Mesh(new THREE.SphereGeometry(14, 16, 16), new THREE.MeshBasicMaterial({ color: 0xffe9b0, fog: false }));
    this.moonMesh = new THREE.Mesh(new THREE.SphereGeometry(9, 16, 16), new THREE.MeshBasicMaterial({ color: 0xcfe0ff, fog: false }));
    scene.add(this.sunMesh, this.moonMesh);

    // stars
    const starGeo = new THREE.BufferGeometry();
    const starN = 700, sp = new Float32Array(starN * 3);
    const rng = mulberry32(777);
    for (let i = 0; i < starN; i++) {
      const th = rng() * Math.PI * 2, ph = Math.acos(rng() * 0.95);
      const r = 900;
      sp[i * 3] = r * Math.sin(ph) * Math.cos(th);
      sp[i * 3 + 1] = Math.abs(r * Math.cos(ph)) + 40;
      sp[i * 3 + 2] = r * Math.sin(ph) * Math.sin(th);
    }
    starGeo.setAttribute("position", new THREE.BufferAttribute(sp, 3));
    this.stars = new THREE.Points(starGeo, new THREE.PointsMaterial({ color: 0xbfd0ff, size: 1.8, sizeAttenuation: false, transparent: true, opacity: 0, fog: false }));
    scene.add(this.stars);

    this.buildTerrain();
    this.buildProps();
    this.water = this.buildWater();
    scene.add(this.water);
    this.castleGate = this.buildCastle();
    scene.add(this.castleGate);
    this.rainPts = this.buildPrecip(900, 0x9fb4d8);
    this.snowPts = this.buildPrecip(700, 0xffffff);
    this.rainVel = new Float32Array(900).fill(0).map(() => -(28 + Math.random() * 14));
    this.snowVel = new Float32Array(700).fill(0).map(() => -(1.6 + Math.random() * 2));
    scene.add(this.rainPts, this.snowPts);
    this.buildWaystones();
    this.buildTemple();
  }

  // ---------- height & biome ----------

  /** Terrain height at world (x,z) — single source of truth for ground collision. */
  height(x: number, z: number): number {
    const n = this.noise;
    let h = (n.fbm(x * 0.008 + 10, z * 0.008 + 10, 4) - 0.45) * 14;
    h += (n.fbm(x * 0.035, z * 0.035, 2) - 0.5) * 2.2;
    // ice mountains (east)
    const dIce = dist2(x, z, WORLD.ZONES.ice.x, WORLD.ZONES.ice.z);
    const mMask = smoothstep(150, 60, dIce);
    h += mMask * (n.fbm(x * 0.02 + 99, z * 0.02 + 99, 5) * 58);
    // swamp lowlands (south)
    const dSw = dist2(x, z, WORLD.ZONES.swamp.x, WORLD.ZONES.swamp.z);
    h = lerp(h, -1.6 + n.fbm(x * 0.03, z * 0.03, 2) * 1.4, smoothstep(140, 70, dSw) * 0.9);
    // desert dunes (west)
    const dDe = dist2(x, z, WORLD.ZONES.desert.x, WORLD.ZONES.desert.z);
    h += smoothstep(140, 60, dDe) * (Math.sin(x * 0.045) * Math.cos(z * 0.05) * 2.4 + n.fbm(x * 0.015, z * 0.015, 3) * 5);
    // castle plateau (far north)
    const dCa = dist2(x, z, WORLD.ZONES.castle.x, WORLD.ZONES.castle.z);
    h = lerp(h, 10 + n.fbm(x * 0.02 + 5, z * 0.02 + 5, 3) * 6, smoothstep(150, 90, dCa));
    // city flatten
    const dCi = dist2(x, z, WORLD.ZONES.city.x, WORLD.ZONES.city.z);
    h = lerp(h, 2.5 + n.fbm(x * 0.02, z * 0.02, 2) * 1.2, smoothstep(120, 60, dCi) * 0.85);
    // temple & spawn flatten
    const dTe = dist2(x, z, 0, 6);
    h = lerp(h, 1.2, smoothstep(30, 12, dTe));
    // gentle bowl at world edge
    const edge = Math.max(Math.abs(x), Math.abs(z));
    h += smoothstep(460, 540, edge) * 30;
    return h;
  }

  zoneAt(x: number, z: number): ZoneId {
    let best: ZoneId = "forest";
    let bd = Infinity;
    const order: ZoneId[] = ["castle", "city", "ice", "swamp", "desert", "temple", "forest"];
    for (const id of order) {
      const zn = WORLD.ZONES[id];
      const d = dist2(x, z, zn.x, zn.z);
      if (d < zn.r && d < bd) { bd = d; best = id; }
    }
    return best;
  }

  zoneWeight(x: number, z: number, id: ZoneId): number {
    const zn = WORLD.ZONES[id];
    return smoothstep(zn.r, zn.r * 0.45, dist2(x, z, zn.x, zn.z));
  }

  // ---------- construction ----------

  private buildTerrain(): void {
    const seg = 220, size = WORLD.SIZE;
    const geo = new THREE.PlaneGeometry(size, size, seg, seg);
    geo.rotateX(-Math.PI / 2);
    const pos = geo.attributes.position as THREE.BufferAttribute;
    const colors = new Float32Array(pos.count * 3);
    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i), z = pos.getZ(i);
      const h = this.height(x, z);
      pos.setY(i, h);
      // blend zone ground colors
      const c = this.tmpC.setRGB(0, 0, 0);
      let wsum = 0;
      const ids: ZoneId[] = ["forest", "city", "ice", "swamp", "desert", "castle"];
      const wts = ids.map((id) => this.zoneWeight(x, z, id));
      const wTe = smoothstep(36, 14, dist2(x, z, 0, 6));
      wts.push(wTe); ids.push("temple" as ZoneId);
      for (let k = 0; k < ids.length; k++) {
        const st = Z[ids[k]];
        const n = this.noise.fbm(x * 0.05 + k * 7, z * 0.05, 2);
        this.tmpC.set(st.ground).lerp(st.ground2, n).multiplyScalar(wts[k]);
        c.r += this.tmpC.r; c.g += this.tmpC.g; c.b += this.tmpC.b;
        wsum += wts[k];
      }
      if (wsum < 0.001) { c.copy(Z.forest.ground); wsum = 1; }
      // altitude tint: rock high, dark low
      const t = clamp((h - 6) / 30, 0, 1);
      c.lerp(new THREE.Color(0x6a7080), t * 0.6);
      c.multiplyScalar(1 / Math.max(0.2, wsum));
      colors[i * 3] = c.r; colors[i * 3 + 1] = c.g; colors[i * 3 + 2] = c.b;
    }
    geo.setAttribute("color", new THREE.BufferAttribute(colors, 3));
    geo.computeVertexNormals();
    const mat = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.95, metalness: 0.02 });
    const mesh = new THREE.Mesh(geo, mat);
    mesh.receiveShadow = true;
    this.scene.add(mesh);
  }

  private makeDeadTree(scale = 1): THREE.BufferGeometry {
    // twisted dead tree: merged trunk + 3 branch cylinders
    const geos: THREE.BufferGeometry[] = [];
    const trunk = new THREE.CylinderGeometry(0.22 * scale, 0.55 * scale, 7 * scale, 5, 3);
    trunk.translate(0, 3.5 * scale, 0);
    const tp = trunk.attributes.position as THREE.BufferAttribute;
    for (let i = 0; i < tp.count; i++) {
      const y = tp.getY(i);
      tp.setX(i, tp.getX(i) + Math.sin(y * 1.3) * 0.35 * scale);
      tp.setZ(i, tp.getZ(i) + Math.cos(y * 0.9) * 0.3 * scale);
    }
    trunk.computeVertexNormals();
    geos.push(trunk);
    const rng = mulberry32((scale * 1000) | 0 + 5);
    for (let b = 0; b < 3; b++) {
      const br = new THREE.CylinderGeometry(0.05 * scale, 0.14 * scale, 3.2 * scale, 4);
      br.translate(0, 1.6 * scale, 0);
      br.rotateZ(0.7 + rng() * 0.7);
      br.rotateY(rng() * Math.PI * 2);
      br.translate(0, (3.4 + b * 1.1) * scale, 0);
      geos.push(br);
    }
    return mergeGeos(geos);
  }

  private makePine(): THREE.BufferGeometry {
    const geos: THREE.BufferGeometry[] = [];
    const trunk = new THREE.CylinderGeometry(0.18, 0.4, 3.4, 5);
    trunk.translate(0, 1.7, 0);
    geos.push(trunk);
    for (let i = 0; i < 3; i++) {
      const cone = new THREE.ConeGeometry(2.1 - i * 0.55, 3.2, 7);
      cone.translate(0, 3.4 + i * 2.1, 0);
      geos.push(cone);
    }
    return mergeGeos(geos);
  }

  private makeRock(scale = 1): THREE.BufferGeometry {
    const g = new THREE.IcosahedronGeometry(1 * scale, 0);
    const p = g.attributes.position as THREE.BufferAttribute;
    const rng = mulberry32(42);
    for (let i = 0; i < p.count; i++) {
      p.setXYZ(i, p.getX(i) * (0.7 + rng() * 0.7), p.getY(i) * (0.5 + rng() * 0.5), p.getZ(i) * (0.7 + rng() * 0.7));
    }
    g.computeVertexNormals();
    return g;
  }

  private makeRuin(): THREE.BufferGeometry {
    const geos: THREE.BufferGeometry[] = [];
    const rng = mulberry32(9);
    // broken wall segments + pillar
    const wall = new THREE.BoxGeometry(6, 4.5, 1.2);
    const wp = wall.attributes.position as THREE.BufferAttribute;
    for (let i = 0; i < wp.count; i++) if (wp.getY(i) > 0) wp.setY(i, wp.getY(i) * (0.3 + rng() * 0.9));
    wall.computeVertexNormals();
    geos.push(wall);
    const pillar = new THREE.CylinderGeometry(0.5, 0.6, 5, 6);
    pillar.translate(3.6, 2.2, 0);
    geos.push(pillar);
    return mergeGeos(geos);
  }

  private makeBone(): THREE.BufferGeometry {
    const geos: THREE.BufferGeometry[] = [];
    const arc = new THREE.TorusGeometry(3, 0.32, 5, 10, Math.PI);
    arc.rotateZ(Math.PI);
    geos.push(arc);
    const rib = new THREE.TorusGeometry(1.6, 0.18, 5, 8, Math.PI);
    rib.rotateZ(Math.PI);
    rib.translate(1.4, 0, 0.6);
    geos.push(rib);
    return mergeGeos(geos);
  }

  private makeCrystal(): THREE.BufferGeometry {
    const g = new THREE.OctahedronGeometry(1, 0);
    g.scale(0.6, 1.9, 0.6);
    return g;
  }

  private makeGrass(): THREE.BufferGeometry {
    const g = new THREE.ConeGeometry(0.09, 1.1, 3);
    g.translate(0, 0.55, 0);
    return g;
  }

  private makeSpire(): THREE.BufferGeometry {
    const geos: THREE.BufferGeometry[] = [];
    const base = new THREE.CylinderGeometry(2.4, 3.4, 14, 6);
    base.translate(0, 7, 0);
    geos.push(base);
    const top = new THREE.ConeGeometry(2.2, 9, 6);
    top.translate(0, 18.5, 0);
    geos.push(top);
    return mergeGeos(geos);
  }

  private addInstanced(geo: THREE.BufferGeometry, mat: THREE.Material, items: { x: number; z: number; s: number; ry: number; tint?: number; collide?: number }[], sway = false): THREE.InstancedMesh {
    const im = new THREE.InstancedMesh(geo, mat, items.length);
    const m = this.tmpM, col = this.tmpC;
    for (let i = 0; i < items.length; i++) {
      const it = items[i];
      const y = it.collide === 0 ? this.height(it.x, it.z) : this.height(it.x, it.z) - 0.15;
      m.makeRotationY(it.ry).scale(new THREE.Vector3(it.s, it.s, it.s)).setPosition(it.x, y, it.z);
      im.setMatrixAt(i, m);
      if (it.tint !== undefined) { col.set(it.tint); im.setColorAt(i, col); }
      if (it.collide && it.collide > 0) this.propColliders.push({ x: it.x, z: it.z, r: it.collide * it.s });
    }
    im.castShadow = true;
    im.receiveShadow = true;
    im.instanceMatrix.needsUpdate = true;
    if (im.instanceColor) im.instanceColor.needsUpdate = true;
    this.scene.add(im);
    if (sway) this.treeSway.push(im);
    return im;
  }

  private buildProps(): void {
    const rng = mulberry32(WORLD.SEED + 1);
    const half = WORLD.SIZE / 2 - 30;
    const scatter = (zone: ZoneId, count: number, minS: number, maxS: number, collide: number, tintBase?: number, avoid = 8): { x: number; z: number; s: number; ry: number; tint?: number; collide?: number }[] => {
      const out: { x: number; z: number; s: number; ry: number; tint?: number; collide?: number }[] = [];
      const zn = WORLD.ZONES[zone];
      let tries = 0;
      while (out.length < count && tries < count * 30) {
        tries++;
        const a = rng() * Math.PI * 2;
        const r = Math.sqrt(rng()) * zn.r * 0.98;
        const x = zn.x + Math.cos(a) * r, z = zn.z + Math.sin(a) * r;
        if (Math.abs(x) > half || Math.abs(z) > half) continue;
        if (dist2(x, z, 0, 6) < avoid + 14) continue; // keep temple clear
        const s = minS + rng() * (maxS - minS);
        const it: { x: number; z: number; s: number; ry: number; tint?: number; collide?: number } = { x, z, s, ry: rng() * Math.PI * 2, collide };
        if (tintBase !== undefined) it.tint = tintBase + ((rng() - 0.5) * 0.12);
        out.push(it);
      }
      return out;
    };

    const stdMat = (color: number, opts: Partial<THREE.MeshStandardMaterialParameters> = {}) =>
      new THREE.MeshStandardMaterial({ color, roughness: 0.95, ...opts });

    // forest dead trees
    this.addInstanced(this.makeDeadTree(1), stdMat(0x3d3347), scatter("forest", 320, 0.7, 1.6, 0.55, 0xffffff), true);
    // forest rocks + glowing mushrooms
    this.addInstanced(this.makeRock(1), stdMat(0x4a4550), scatter("forest", 90, 0.5, 1.8, 0.9, 0xffffff));
    const shroomMat = new THREE.MeshStandardMaterial({ color: 0x6f5f9e, emissive: 0x7a4fd0, emissiveIntensity: 1.6, roughness: 0.6 });
    this.addInstanced(new THREE.SphereGeometry(0.28, 6, 5), shroomMat, scatter("forest", 130, 0.6, 1.6, 0, undefined));
    // grass everywhere (custom shader, sway)
    this.buildGrassField(scatter("forest", 900, 0.7, 1.5, 0).concat(scatter("swamp", 500, 0.8, 1.6, 0), scatter("temple", 120, 0.6, 1.2, 0)));
    // pines (ice + forest edges)
    this.addInstanced(this.makePine(), stdMat(0x223448), scatter("ice", 200, 0.8, 1.9, 0.5, 0xffffff), true);
    this.addInstanced(this.makePine(), stdMat(0x2c3a4c), scatter("forest", 80, 0.7, 1.4, 0.5, 0xffffff), true);
    // ice crystals & rocks
    const crysMat = new THREE.MeshStandardMaterial({ color: 0x9fd0ff, emissive: 0x3a7ac0, emissiveIntensity: 0.7, roughness: 0.2, metalness: 0.3 });
    this.addInstanced(this.makeCrystal(), crysMat, scatter("ice", 110, 0.8, 2.6, 0.7, 0xffffff));
    this.addInstanced(this.makeRock(1.4), stdMat(0x7e8ea6), scatter("ice", 120, 0.6, 2.2, 1.0, 0xffffff));
    // swamp twisted trees + glow plants
    this.addInstanced(this.makeDeadTree(0.8), stdMat(0x33422e), scatter("swamp", 180, 0.8, 1.7, 0.5, 0xffffff), true);
    const glowMat = new THREE.MeshStandardMaterial({ color: 0x4a7a5a, emissive: 0x3aff9a, emissiveIntensity: 1.2 });
    this.addInstanced(new THREE.SphereGeometry(0.2, 6, 5), glowMat, scatter("swamp", 140, 0.6, 1.4, 0));
    // desert bones & rocks
    this.addInstanced(this.makeBone(), stdMat(0xcfc4a8), scatter("desert", 60, 0.7, 1.8, 0));
    this.addInstanced(this.makeRock(1), stdMat(0x6e5f48), scatter("desert", 140, 0.6, 2.4, 0.9, 0xffffff));
    this.addInstanced(this.makeDeadTree(0.6), stdMat(0x5a4c3a), scatter("desert", 60, 0.6, 1.2, 0.4, 0xffffff), true);
    // city ruins
    this.addInstanced(this.makeRuin(), stdMat(0x55525e), scatter("city", 90, 0.9, 1.8, 1.4, 0xffffff));
    const brazierMat = new THREE.MeshStandardMaterial({ color: 0x2a2a33, emissive: 0xff7a30, emissiveIntensity: 1.8 });
    this.addInstanced(new THREE.CylinderGeometry(0.35, 0.25, 1.4, 6), brazierMat, scatter("city", 30, 0.9, 1.2, 0));
    // castle spires
    this.addInstanced(this.makeSpire(), stdMat(0x1c1626), scatter("castle", 46, 0.9, 1.9, 1.8, 0xffffff));
    const flameMat = new THREE.MeshStandardMaterial({ color: 0x1c1626, emissive: 0x9040ff, emissiveIntensity: 2.2 });
    this.addInstanced(new THREE.OctahedronGeometry(0.5, 0), flameMat, scatter("castle", 40, 0.8, 1.5, 0));
    // scattered trees between zones
    this.addInstanced(this.makeDeadTree(1), stdMat(0x38304a), scatter("forest", 150, 0.6, 1.2, 0.5, 0xffffff), true);
  }

  private buildGrassField(items: { x: number; z: number; s: number; ry: number }[]): void {
    const geo = this.makeGrass();
    this.grassMat = new THREE.ShaderMaterial({
      uniforms: { uTime: { value: 0 }, uFogColor: { value: new THREE.Color(0x272b3a) }, uFogDensity: { value: 0.012 } },
      vertexShader: `
        uniform float uTime;
        varying float vY; varying float vFogDepth;
        void main(){
          vY = position.y;
          vec3 p = position;
          vec4 wp = instanceMatrix * vec4(p,1.0);
          float sway = sin(uTime*1.7 + wp.x*0.35 + wp.z*0.27) * 0.16 * position.y;
          wp.x += sway; wp.z += sway*0.6;
          vec4 mv = viewMatrix * modelMatrix * wp;
          vFogDepth = -mv.z;
          gl_Position = projectionMatrix * mv;
        }`,
      fragmentShader: `
        uniform vec3 uFogColor; uniform float uFogDensity;
        varying float vY; varying float vFogDepth;
        void main(){
          vec3 col = mix(vec3(0.13,0.14,0.19), vec3(0.28,0.26,0.38), vY);
          float f = 1.0 - exp(-uFogDensity*uFogDensity*vFogDepth*vFogDepth);
          gl_FragColor = vec4(mix(col, uFogColor, f), 1.0);
        }`,
    });
    const im = new THREE.InstancedMesh(geo, this.grassMat, items.length);
    const m = this.tmpM;
    for (let i = 0; i < items.length; i++) {
      const it = items[i];
      m.makeRotationY(it.ry).scale(new THREE.Vector3(it.s, it.s * (1.2 + (i % 5) * 0.2), it.s)).setPosition(it.x, this.height(it.x, it.z) - 0.05, it.z);
      im.setMatrixAt(i, m);
    }
    im.instanceMatrix.needsUpdate = true;
    this.scene.add(im);
  }

  private buildWater(): THREE.Mesh {
    const geo = new THREE.PlaneGeometry(WORLD.SIZE, WORLD.SIZE, 48, 48);
    geo.rotateX(-Math.PI / 2);
    const mat = new THREE.MeshStandardMaterial({
      color: 0x18303a, transparent: true, opacity: 0.72, roughness: 0.15, metalness: 0.6,
    });
    const mesh = new THREE.Mesh(geo, mat);
    mesh.position.y = this.waterLevel;
    return mesh;
  }

  private buildCastle(): THREE.Group {
    const g = new THREE.Group();
    const cz = WORLD.ZONES.castle;
    const y = this.height(cz.x, cz.z);
    const mat = new THREE.MeshStandardMaterial({ color: 0x17131f, roughness: 0.9 });
    // central keep
    const keep = new THREE.Mesh(new THREE.CylinderGeometry(16, 20, 46, 8), mat);
    keep.position.set(cz.x, y + 23, cz.z - 30);
    keep.castShadow = true;
    g.add(keep);
    const crown = new THREE.Mesh(new THREE.ConeGeometry(17, 22, 8), new THREE.MeshStandardMaterial({ color: 0x0f0c18, roughness: 0.85 }));
    crown.position.set(cz.x, y + 57, cz.z - 30);
    g.add(crown);
    // eye of the shadow king
    const eye = new THREE.Mesh(new THREE.SphereGeometry(3.2, 16, 16), new THREE.MeshBasicMaterial({ color: 0xa040ff }));
    eye.position.set(cz.x, y + 40, cz.z - 30 + 15.5);
    g.add(eye);
    // gate
    const gateMat = new THREE.MeshStandardMaterial({ color: 0x241d33, emissive: 0x5a2a9a, emissiveIntensity: 0.6 });
    const gate = new THREE.Mesh(new THREE.BoxGeometry(10, 14, 2), gateMat);
    gate.position.set(cz.x, y + 7, cz.z + 4);
    gate.castShadow = true;
    g.add(gate);
    (g.userData as { gate: THREE.Mesh; eye: THREE.Mesh }).gate = gate;
    (g.userData as { gate: THREE.Mesh; eye: THREE.Mesh }).eye = eye;
    return g;
  }

  getCastleGate(): THREE.Mesh { return (this.castleGate.userData as { gate: THREE.Mesh }).gate; }

  private buildPrecip(count: number, color: number): THREE.Points {
    const geo = new THREE.BufferGeometry();
    geo.setAttribute("position", new THREE.BufferAttribute(new Float32Array(count * 3), 3));
    const mat = new THREE.PointsMaterial({ color, size: 0.12, transparent: true, opacity: 0.6, sizeAttenuation: true });
    const pts = new THREE.Points(geo, mat);
    pts.visible = false;
    pts.frustumCulled = false;
    return pts;
  }

  private buildWaystones(): void {
    const defs = [
      { id: "temple", x: 4, z: 14, name: "المعبد المهجور" },
      { id: "forest", x: -40, z: -60, name: "قلب غابة الرماد" },
      { id: "city", x: 10, z: -200, name: "بوابة إيراث" },
      { id: "ice", x: 220, z: 15, name: "ممر الجليد" },
      { id: "swamp", x: -15, z: 215, name: "ضفة المستنقع" },
      { id: "desert", x: -220, z: 5, name: "رمال العظام" },
      { id: "castle", x: 0, z: -395, name: "ساحة الظلال" },
    ];
    const mat = new THREE.MeshStandardMaterial({ color: 0x2a2f45, emissive: 0x3a6aff, emissiveIntensity: 0.8, roughness: 0.4 });
    for (const d of defs) {
      const grp = new THREE.Group();
      const y = this.height(d.x, d.z);
      const ob = new THREE.Mesh(new THREE.CylinderGeometry(0.7, 1.1, 4.6, 5), mat);
      ob.position.y = 2.3; ob.castShadow = true;
      const tip = new THREE.Mesh(new THREE.OctahedronGeometry(0.55, 0), new THREE.MeshBasicMaterial({ color: 0x7aa8ff }));
      tip.position.y = 5.3;
      grp.add(ob, tip);
      grp.position.set(d.x, y, d.z);
      (grp.userData as { tip: THREE.Mesh }).tip = tip;
      this.scene.add(grp);
      this.waystones.push({ ...d, discovered: d.id === "temple", mesh: grp });
      this.propColliders.push({ x: d.x, z: d.z, r: 1.2 });
    }
  }

  private buildTemple(): void {
    // ruined temple where Aren wakes: broken pillars + braziers + the pedestal
    const g = new THREE.Group();
    const mat = new THREE.MeshStandardMaterial({ color: 0x4c5266, roughness: 0.85 });
    const rng = mulberry32(31);
    for (let i = 0; i < 8; i++) {
      const a = (i / 8) * Math.PI * 2;
      const r = 11;
      const x = Math.cos(a) * r, z = 6 + Math.sin(a) * r;
      const h = 3 + rng() * 5;
      const p = new THREE.Mesh(new THREE.CylinderGeometry(0.75, 0.9, h, 8), mat);
      p.position.set(x, this.height(x, z) + h / 2 - 0.3, z);
      p.castShadow = true; p.receiveShadow = true;
      g.add(p);
      this.propColliders.push({ x, z, r: 1.0 });
    }
    // floor disc
    const floor = new THREE.Mesh(new THREE.CylinderGeometry(13, 13.5, 0.5, 24), new THREE.MeshStandardMaterial({ color: 0x3a4055, roughness: 0.9 }));
    floor.position.set(0, this.height(0, 6) + 0.05, 6);
    floor.receiveShadow = true;
    g.add(floor);
    // braziers with fire light
    for (const [bx, bz] of [[-6, 0], [6, 0], [-6, 12], [6, 12]] as const) {
      const y = this.height(bx, bz);
      const b = new THREE.Mesh(new THREE.CylinderGeometry(0.4, 0.3, 1.3, 6), new THREE.MeshStandardMaterial({ color: 0x2a2a33, emissive: 0xff7a30, emissiveIntensity: 1.6 }));
      b.position.set(bx, y + 0.65, bz);
      g.add(b);
      const l = new THREE.PointLight(0xff8a40, 8, 18, 2);
      l.position.set(bx, y + 1.8, bz);
      g.add(l);
    }
    // sword pedestal
    const ped = new THREE.Mesh(new THREE.BoxGeometry(1.2, 1.1, 1.2), mat);
    ped.position.set(0, this.height(0, 6) + 0.55, 6);
    ped.castShadow = true;
    g.add(ped);
    this.scene.add(g);
  }

  // ---------- per-frame ----------

  /** Push an entity out of prop colliders. Returns corrected position. */
  collide(x: number, z: number, r: number): { x: number; z: number } {
    for (const c of this.propColliders) {
      const dx = x - c.x, dz = z - c.z;
      const d = Math.sqrt(dx * dx + dz * dz);
      const min = r + c.r;
      if (d < min && d > 0.0001) {
        x = c.x + (dx / d) * min;
        z = c.z + (dz / d) * min;
      }
    }
    return { x, z };
  }

  update(dt: number, px: number, pz: number, t: number): void {
    // day/night
    this.timeOfDay = (this.timeOfDay + dt / WORLD.DAY_LENGTH) % 1;
    const ang = (this.timeOfDay - 0.25) * Math.PI * 2;
    const sunY = Math.sin(ang), sunX = Math.cos(ang);
    this.sun.position.set(px + sunX * 120, sunY * 140, pz + 60);
    this.sun.target.position.set(px, 0, pz);
    this.sun.intensity = clamp(sunY, 0, 1) * 1.35;
    this.moon.position.set(px - sunX * 100, -sunY * 130 + 40, pz - 50);
    this.moon.target.position.set(px, 0, pz);
    this.moon.intensity = clamp(-sunY, 0, 1) * 0.5;
    this.sunMesh.position.set(px + sunX * 800, sunY * 700, pz + 300);
    this.moonMesh.position.set(px - sunX * 800, -sunY * 680 + 80, pz - 300);
    const day = clamp(sunY * 2 + 0.35, 0, 1);

    // weather state machine
    this.weatherTimer -= dt;
    if (this.weatherTimer <= 0) {
      const roll = Math.random();
      const zone = this.zoneAt(px, pz);
      if (zone === "ice") this.weather = roll < 0.55 ? "clear" : roll < 0.9 ? "fog" : "storm";
      else if (zone === "desert") this.weather = roll < 0.75 ? "clear" : "fog";
      else this.weather = roll < 0.45 ? "clear" : roll < 0.7 ? "fog" : roll < 0.9 ? "rain" : "storm";
      this.weatherTimer = 35 + Math.random() * 45;
      if (this.weather === "storm" && Math.random() < 0.8) this.onThunder?.();
    }

    // zone fog blending
    const zone = this.zoneAt(px, pz);
    const st = Z[zone];
    const nightF = this.night ? 1 : 0;
    const fogCol = this.tmpC.copy(st.fogColor).multiplyScalar(lerp(1, 0.35, nightF));
    let density = lerp(st.fogDay, st.fogNight, nightF) / 1000;
    if (this.weather === "fog") density *= 1.9;
    if (this.weather === "rain" || this.weather === "storm") density *= 1.35;
    const fog = this.scene.fog as THREE.FogExp2;
    fog.color.lerp(fogCol, 0.03);
    fog.density += (density - fog.density) * 0.03;
    const bg = fog.color.clone().multiplyScalar(lerp(1.05, 0.55, nightF));
    this.scene.background = bg;

    this.hemi.intensity = lerp(0.16, 0.55, day);
    this.ambient.intensity = lerp(0.14, 0.35, day);
    (this.stars.material as THREE.PointsMaterial).opacity = this.night ? 0.85 : 0;

    // precip follows player
    const raining = this.weather === "rain" || this.weather === "storm";
    this.rainPts.visible = raining && zone !== "ice" && zone !== "desert";
    this.snowPts.visible = (zone === "ice" && this.weather !== "storm") || (zone === "castle");
    const wind = Math.sin(t * 0.4) * (this.weather === "storm" ? 22 : 6);
    this.updatePrecip(this.rainPts, this.rainVel, px, pz, wind, dt, 40);
    this.updatePrecip(this.snowPts, this.snowVel, px, pz, wind * 0.4 + Math.sin(t) * 1.5, dt, 40);
    (this.rainPts.material as THREE.PointsMaterial).opacity = this.weather === "storm" ? 0.75 : 0.45;

    // grass sway + water
    this.grassMat.uniforms.uTime.value = t;
    (this.grassMat.uniforms.uFogColor.value as THREE.Color).copy(fog.color);
    this.grassMat.uniforms.uFogDensity.value = fog.density;
    this.water.position.y = this.waterLevel + Math.sin(t * 0.7) * 0.06;

    // waystone tips pulse
    for (const w of this.waystones) {
      const tip = (w.mesh.userData as { tip: THREE.Mesh }).tip;
      tip.rotation.y = t * (w.discovered ? 1.6 : 0.5);
      tip.position.y = 5.3 + Math.sin(t * 2 + w.x) * 0.15;
    }
    // castle eye pulse
    const ud = this.castleGate.userData as { eye: THREE.Mesh };
    (ud.eye.material as THREE.MeshBasicMaterial).color.setHSL(0.78, 0.9, 0.45 + Math.sin(t * 2.2) * 0.15);
  }

  onThunder: (() => void) | null = null;
  private thunderTimer = 5;

  private updatePrecip(pts: THREE.Points, vel: Float32Array, px: number, pz: number, wind: number, dt: number, range: number): void {
    if (!pts.visible) return;
    const pos = pts.geometry.attributes.position as THREE.BufferAttribute;
    const arr = pos.array as Float32Array;
    for (let i = 0; i < vel.length; i++) {
      let x = arr[i * 3], y = arr[i * 3 + 1], z = arr[i * 3 + 2];
      if (y < this.height(x, z) - 2 || Math.abs(x - px) > range || Math.abs(z - pz) > range) {
        x = px + (Math.random() - 0.5) * range * 2;
        z = pz + (Math.random() - 0.5) * range * 2;
        y = this.height(x, z) + 18 + Math.random() * 14;
      }
      y += vel[i] * dt;
      x += wind * dt;
      arr[i * 3] = x; arr[i * 3 + 1] = y; arr[i * 3 + 2] = z;
    }
    pos.needsUpdate = true;
  }
}

/** Merge BufferGeometries (positions+normals+uvs), non-indexed. */
export function mergeGeos(geos: THREE.BufferGeometry[]): THREE.BufferGeometry {
  const nonIndexed = geos.map((g) => g.toNonIndexed());
  let total = 0;
  for (const g of nonIndexed) total += g.attributes.position.count;
  const pos = new Float32Array(total * 3);
  const norm = new Float32Array(total * 3);
  let off = 0;
  for (const g of nonIndexed) {
    pos.set(g.attributes.position.array as Float32Array, off * 3);
    norm.set(g.attributes.normal.array as Float32Array, off * 3);
    off += g.attributes.position.count;
  }
  const out = new THREE.BufferGeometry();
  out.setAttribute("position", new THREE.BufferAttribute(pos, 3));
  out.setAttribute("normal", new THREE.BufferAttribute(norm, 3));
  return out;
}
