export type GameState = "title" | "playing" | "paused" | "levelup" | "gameover" | "victory";
export type EnemyKind = "hound" | "wisp" | "brute" | "spitter" | "splitter" | "boss";
export type UpgradeId =
  | "split" | "orbit" | "chain" | "missile" | "nova" | "overdrive"
  | "pierce" | "time" | "vamp" | "shield" | "reactor" | "magnet";

export interface Player {
  x: number; y: number; vx: number; vy: number; r: number;
  hp: number; maxHp: number; speed: number;
  fireCd: number; fireRate: number; bulletSpeed: number; damage: number;
  dashCd: number; dashTime: number; invuln: number; shieldCd: number;
  aim: number; shotCount: number; level: number; xp: number; nextXp: number;
}

export interface Enemy {
  alive: boolean; kind: EnemyKind; x: number; y: number; vx: number; vy: number;
  r: number; hp: number; maxHp: number; speed: number; damage: number; xp: number;
  spawn: number; hitFlash: number; attackCd: number; orbitCd: number; phase: number;
  charge: number; angle: number; worth: number;
}

export interface Bullet {
  alive: boolean; hostile: boolean; missile: boolean; x: number; y: number;
  vx: number; vy: number; r: number; damage: number; life: number; pierce: number;
  target: Enemy | null; lastHit: Enemy | null; color: string;
}

export interface Particle {
  alive: boolean; x: number; y: number; vx: number; vy: number;
  life: number; maxLife: number; size: number; color: string; drag: number;
}

export interface Pickup {
  alive: boolean; x: number; y: number; vx: number; vy: number;
  value: number; life: number; health: boolean; phase: number;
}

export interface Shockwave {
  alive: boolean; x: number; y: number; r: number; maxR: number;
  life: number; maxLife: number; color: string;
}

export interface Lightning {
  alive: boolean; x1: number; y1: number; x2: number; y2: number;
  life: number; seed: number;
}

export interface FloatText {
  alive: boolean; x: number; y: number; life: number; text: string; color: string;
}

export interface HudData {
  hp: number; maxHp: number; level: number; xp: number; nextXp: number;
  wave: number; waveTime: number; kills: number; score: number;
  dash: number; bossHp: number; bossMaxHp: number; state: GameState;
}
