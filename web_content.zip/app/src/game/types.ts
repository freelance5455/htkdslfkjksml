/**
 * types.ts — shared types for Steel Courtyard FPS.
 */

import type { TeamId } from "./config";

/** Axis-aligned box collider (static level geometry). */
export interface AABB {
  minX: number;
  maxX: number;
  minZ: number;
  maxZ: number;
  /** Collision height — bullets can fly over low cover. */
  height: number;
}

/** A damage event routed through MatchManager so the kill feed / scores stay consistent. */
export interface DamageEvent {
  amount: number;
  /** Who dealt it ("player" or a bot name); undefined = world/explosion environmental. */
  attacker: string | null;
  attackerTeam: TeamId;
  /** Who received it. */
  victim: string;
  victimTeam: TeamId;
  /** Weapon label shown in the kill feed. */
  weapon: string;
  headshot?: boolean;
}

export interface Vec3 {
  x: number;
  y: number;
  z: number;
}

export const BOT_NAMES = ["PETYA_224", "VASLRY", "KESTREL_7", "DARKWOLF", "HAVOC-2", "RICO_88", "MOSS_13", "BANSHEE"];
export const PLAYER_NAME = "YOU";
export const ALLY_NAMES = ["ORION", "SILT-4"];
