/**
 * match.ts — MatchManager.
 * Round-based team combat: countdown → fight → round end → reset → … first to ROUNDS_TO_WIN.
 * Owns team scores, drives the kill feed + banners via HUD callbacks, and decides round wins
 * (all red down = blue round; player down = red round).
 */

import * as THREE from "three";
import { MATCH, TeamId } from "./config";
import { KillEvent } from "./enemy";

export type MatchPhase = "idle" | "countdown" | "fight" | "roundEnd" | "matchEnd";

export interface MatchHooks {
  /** Respawn everyone at their team spawns and reset HP/ammo for a fresh round. */
  resetRound: () => void;
  onKillFeed: (ev: KillEvent) => void;
  onScores: (blue: number, red: number) => void;
  onBanner: (text: string, sub: string, tone: "info" | "good" | "bad", seconds: number) => void;
  onMatchEnd: (winner: TeamId) => void;
  onCountdownTick: (n: number) => void;
}

export class MatchManager {
  phase: MatchPhase = "idle";
  scores: [number, number] = [0, 0];
  roundNumber = 0;
  private timer = 0;
  private lastCountdownInt = -1;
  playerAlive = true;
  winner: TeamId | null = null;

  constructor(private hooks: MatchHooks) {}

  startMatch(): void {
    this.scores = [0, 0];
    this.roundNumber = 0;
    this.winner = null;
    this.hooks.onScores(0, 0);
    this.startRound();
  }

  startRound(): void {
    this.roundNumber++;
    this.phase = "countdown";
    this.timer = MATCH.COUNTDOWN;
    this.lastCountdownInt = -1;
    this.playerAlive = true;
    this.hooks.resetRound();
    this.hooks.onBanner(`ROUND ${this.roundNumber}`, "eliminate the red squad", "info", MATCH.COUNTDOWN);
  }

  /** Every elimination in the match flows through here. */
  onKill(ev: KillEvent): void {
    if (this.phase !== "fight") return;
    this.hooks.onKillFeed(ev);
    if (ev.victim === "YOU") {
      this.playerAlive = false;
      this.endRound(1);
      return;
    }
    // blue ally bots dying doesn't end the round; only wiping red (or losing the player) does
    if (ev.victimTeam === 1 && this.redAlive() === 0) {
      this.endRound(0);
    }
  }

  /** Remaining red combatants — wired from boot (bots list). */
  redAliveFn: () => number = () => 0;

  private redAlive(): number { return this.redAliveFn(); }

  private endRound(winner: TeamId): void {
    this.phase = "roundEnd";
    this.timer = MATCH.ROUND_RESET_DELAY;
    this.scores[winner]++;
    this.hooks.onScores(this.scores[0], this.scores[1]);
    if (this.scores[winner] >= MATCH.ROUNDS_TO_WIN) {
      this.winner = winner;
    }
    if (winner === 0) this.hooks.onBanner("ROUND WON", "red squad eliminated", "good", MATCH.ROUND_RESET_DELAY);
    else this.hooks.onBanner("ROUND LOST", "you were eliminated", "bad", MATCH.ROUND_RESET_DELAY);
  }

  update(dt: number): void {
    switch (this.phase) {
      case "countdown": {
        this.timer -= dt;
        const n = Math.ceil(this.timer);
        if (n !== this.lastCountdownInt && n > 0 && n <= 3) {
          this.lastCountdownInt = n;
          this.hooks.onCountdownTick(n);
        }
        if (this.timer <= 0) {
          this.phase = "fight";
          this.hooks.onBanner("FIGHT", "", "info", 0.8);
        }
        break;
      }
      case "roundEnd": {
        this.timer -= dt;
        if (this.timer <= 0) {
          if (this.winner !== null) {
            this.phase = "matchEnd";
            this.hooks.onMatchEnd(this.winner);
          } else {
            this.startRound();
          }
        }
        break;
      }
      default:
        break;
    }
  }

  get inFight(): boolean { return this.phase === "fight"; }
}

/** Pick a spawn point from a list, avoiding close proximity to enemies when possible. */
export function pickSpawn(spawns: THREE.Vector3[], enemies: THREE.Vector3[]): THREE.Vector3 {
  let best = spawns[0];
  let bestScore = -1;
  for (const s of spawns) {
    let minD = Infinity;
    for (const e of enemies) minD = Math.min(minD, s.distanceTo(e));
    if (minD > bestScore) { bestScore = minD; best = s; }
  }
  return best;
}
