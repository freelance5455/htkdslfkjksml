/**
 * engine.ts — fixed-timestep game loop (decoupled from frame rate).
 * Gameplay logic advances at a fixed step in update(dt); rendering runs with interpolation in render(alpha).
 * An optional FPS cap lets weak phones hold a *stable* 30 FPS instead of oscillating between 25 and 45.
 */

export interface GameLoopHooks {
  /** Fixed-step logic update. dt is always STEP (seconds). */
  update: (dt: number) => void;
  /** Render. alpha ∈ [0,1) is the interpolation factor between the previous and current step.
   *  frameMs is the time since the previous *rendered* frame. */
  render: (alpha: number, frameMs: number) => void;
}

export class GameLoop {
  /** Fixed step: 60Hz. */
  static readonly STEP = 1 / 60;
  /** Never catch up more than 100ms after a stall (spiral-of-death guard; also avoids long CPU bursts on phones). */
  private static readonly MAX_FRAME = 0.1;
  /** Hard ceiling of simulation steps per rendered frame. */
  private static readonly MAX_STEPS = 4;

  private acc = 0;
  private last = 0;
  private lastRender = 0;
  private raf = 0;
  private running = false;
  private frameInterval = 0; // ms; 0 = render every display frame

  constructor(private hooks: GameLoopHooks) {}

  /** 0 = uncapped (display refresh), otherwise the maximum rendered FPS. */
  setFpsCap(fps: number): void {
    this.frameInterval = fps > 0 ? 1000 / fps : 0;
  }

  get cappedIntervalMs(): number { return this.frameInterval; }

  start(): void {
    if (this.running) return;
    this.running = true;
    this.last = performance.now();
    this.lastRender = this.last;
    const frame = (now: number) => {
      if (!this.running) return;
      this.raf = requestAnimationFrame(frame);
      // Frame limiter: skip this display frame when it is too early. A 4 ms tolerance prevents the classic
      // 60 Hz vsync jitter from turning a 30 FPS cap into 20 FPS.
      if (this.frameInterval > 0 && now - this.lastRender < this.frameInterval - 4) return;
      let delta = (now - this.last) / 1000;
      this.last = now;
      if (delta > GameLoop.MAX_FRAME) delta = GameLoop.MAX_FRAME;
      this.acc += delta;
      let steps = 0;
      while (this.acc >= GameLoop.STEP && steps < GameLoop.MAX_STEPS) {
        this.hooks.update(GameLoop.STEP);
        this.acc -= GameLoop.STEP;
        steps++;
      }
      if (steps === GameLoop.MAX_STEPS) this.acc = 0; // drop the backlog instead of spiralling
      const frameMs = now - this.lastRender;
      this.lastRender = now;
      this.hooks.render(this.acc / GameLoop.STEP, frameMs);
    };
    this.raf = requestAnimationFrame(frame);
  }

  stop(): void {
    this.running = false;
    cancelAnimationFrame(this.raf);
  }
}
