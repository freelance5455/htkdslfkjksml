/**
 * combat.ts — particles pool, floating damage numbers, screen shake, hit flashes.
 * All pooled; zero allocation in the hot loop.
 */
import * as THREE from "three";
import { clamp } from "./noise";

const MAX_PARTICLES = 800;

interface P {
  x: number; y: number; z: number;
  vx: number; vy: number; vz: number;
  life: number; maxLife: number;
  size: number; r: number; g: number; b: number;
  gravity: number;
}

export class Particles {
  private pool: P[] = [];
  private pts: THREE.Points;
  private pos: Float32Array;
  private col: Float32Array;
  private cursor = 0;
  quality = 1; // multiplier

  constructor(scene: THREE.Scene) {
    for (let i = 0; i < MAX_PARTICLES; i++) {
      this.pool.push({ x: 0, y: -999, z: 0, vx: 0, vy: 0, vz: 0, life: 0, maxLife: 1, size: 1, r: 1, g: 1, b: 1, gravity: 0 });
    }
    this.pos = new Float32Array(MAX_PARTICLES * 3);
    this.col = new Float32Array(MAX_PARTICLES * 3);
    const geo = new THREE.BufferGeometry();
    geo.setAttribute("position", new THREE.BufferAttribute(this.pos, 3));
    geo.setAttribute("color", new THREE.BufferAttribute(this.col, 3));
    const mat = new THREE.PointsMaterial({ size: 0.14, vertexColors: true, transparent: true, opacity: 0.95, blending: THREE.AdditiveBlending, depthWrite: false, sizeAttenuation: true });
    this.pts = new THREE.Points(geo, mat);
    this.pts.frustumCulled = false;
    scene.add(this.pts);
  }

  burst(x: number, y: number, z: number, count: number, color: number, speed = 4, life = 0.5, gravity = 8): void {
    count = Math.max(1, (count * this.quality) | 0);
    const c = new THREE.Color(color);
    for (let i = 0; i < count; i++) {
      const p = this.pool[this.cursor];
      this.cursor = (this.cursor + 1) % MAX_PARTICLES;
      p.x = x; p.y = y; p.z = z;
      const th = Math.random() * Math.PI * 2, ph = Math.acos(Math.random() * 2 - 1);
      const sp = speed * (0.4 + Math.random() * 0.8);
      p.vx = Math.sin(ph) * Math.cos(th) * sp;
      p.vy = Math.cos(ph) * sp * 0.8 + speed * 0.25;
      p.vz = Math.sin(ph) * Math.sin(th) * sp;
      p.maxLife = life * (0.6 + Math.random() * 0.7);
      p.life = p.maxLife;
      p.r = c.r; p.g = c.g; p.b = c.b;
      p.gravity = gravity;
    }
  }

  update(dt: number): void {
    for (let i = 0; i < MAX_PARTICLES; i++) {
      const p = this.pool[i];
      if (p.life <= 0) { this.pos[i * 3 + 1] = -999; continue; }
      p.life -= dt;
      p.vy -= p.gravity * dt;
      p.x += p.vx * dt; p.y += p.vy * dt; p.z += p.vz * dt;
      const k = clamp(p.life / p.maxLife, 0, 1);
      this.pos[i * 3] = p.x; this.pos[i * 3 + 1] = p.y; this.pos[i * 3 + 2] = p.z;
      this.col[i * 3] = p.r * k; this.col[i * 3 + 1] = p.g * k; this.col[i * 3 + 2] = p.b * k;
    }
    (this.pts.geometry.attributes.position as THREE.BufferAttribute).needsUpdate = true;
    (this.pts.geometry.attributes.color as THREE.BufferAttribute).needsUpdate = true;
  }
}

// ---------------- damage numbers ----------------

interface DMG { sprite: THREE.Sprite; life: number; vy: number; }
const DMG_POOL = 22;

export class DamageNumbers {
  private pool: DMG[] = [];
  private cursor = 0;
  private scene: THREE.Scene;

  constructor(scene: THREE.Scene) {
    this.scene = scene;
    for (let i = 0; i < DMG_POOL; i++) {
      const canvas = document.createElement("canvas");
      canvas.width = 160; canvas.height = 64;
      const tex = new THREE.CanvasTexture(canvas);
      const sprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true, depthWrite: false }));
      sprite.scale.set(1.6, 0.64, 1);
      sprite.visible = false;
      scene.add(sprite);
      this.pool.push({ sprite, life: 0, vy: 0 });
    }
  }

  show(x: number, y: number, z: number, text: string, color = "#ffd76a", big = false): void {
    const d = this.pool[this.cursor];
    this.cursor = (this.cursor + 1) % DMG_POOL;
    const canvas = (d.sprite.material.map as THREE.CanvasTexture).image as HTMLCanvasElement;
    const ctx = canvas.getContext("2d")!;
    ctx.clearRect(0, 0, 160, 64);
    ctx.font = `bold ${big ? 44 : 32}px Arial`;
    ctx.textAlign = "center"; ctx.textBaseline = "middle";
    ctx.strokeStyle = "rgba(0,0,0,0.9)"; ctx.lineWidth = 7;
    ctx.strokeText(text, 80, 32);
    ctx.fillStyle = color;
    ctx.fillText(text, 80, 32);
    d.sprite.material.map!.needsUpdate = true;
    d.sprite.position.set(x + (Math.random() - 0.5) * 0.6, y, z + (Math.random() - 0.5) * 0.6);
    d.sprite.scale.set(big ? 2.4 : 1.6, big ? 0.96 : 0.64, 1);
    d.sprite.visible = true;
    d.sprite.material.opacity = 1;
    d.life = 0.9;
    d.vy = 2.2;
  }

  update(dt: number): void {
    for (const d of this.pool) {
      if (!d.sprite.visible) continue;
      d.life -= dt;
      if (d.life <= 0) { d.sprite.visible = false; continue; }
      d.sprite.position.y += d.vy * dt;
      d.vy -= 3 * dt;
      d.sprite.material.opacity = clamp(d.life / 0.35, 0, 1);
    }
  }
}

// ---------------- screen shake ----------------

export class ScreenShake {
  trauma = 0;
  add(v: number): void { this.trauma = clamp(this.trauma + v, 0, 1); }
  update(dt: number): void { this.trauma = Math.max(0, this.trauma - dt * 2.2); }
  offset(t: number): { x: number; y: number; rot: number } {
    const k = this.trauma * this.trauma;
    return {
      x: k * 0.35 * Math.sin(t * 91),
      y: k * 0.3 * Math.sin(t * 83 + 2),
      rot: k * 0.03 * Math.sin(t * 77),
    };
  }
}

// ---------------- shared combat helpers ----------------

export interface Hitbox {
  x: number; y: number; z: number; r: number;
  dmg: number; knockback: number; team: "player" | "enemy";
  hitSet?: Set<unknown>;
}

export function hitOverlap(h: { x: number; y: number; z: number; r: number }, tx: number, ty: number, tz: number, tr: number): boolean {
  const dx = h.x - tx, dy = h.y - ty, dz = h.z - tz;
  const rr = h.r + tr;
  return dx * dx + dy * dy + dz * dz < rr * rr;
}
