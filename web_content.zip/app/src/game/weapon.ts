/**
 * weapon.ts — WeaponSystem.
 * Owns the first-person viewmodel (gloved arms + dark rifle with red-accented handguard),
 * hitscan firing with spread/recoil/bloom, ADS (fov + viewmodel lerp), reload, muzzle flash
 * and tracers. Damage routing goes through the injected hitTarget callback so MatchManager
 * stays the single source of truth for kills and scores.
 */

import * as THREE from "three";
import { WEAPONS, WeaponId, COLORS } from "./config";
import { raycastColliders, AABB } from "./arena";
import { GameInput } from "./input";
import { AudioSystem } from "./audio";
import { Effects } from "./effects";
import type { PlayerController } from "./player";

/** Anything the player's bullets can hit (bots; the player never shoots themselves). */
export interface Shootable {
  name: string;
  team: 0 | 1;
  alive: boolean;
  pos: THREE.Vector3; // feet position
  height: number;
  headY: number;
  radius: number;
}

export interface HitResult {
  target: Shootable;
  point: THREE.Vector3;
  headshot: boolean;
}

export class WeaponSystem {
  private mag: Record<WeaponId, number> = { rifle: WEAPONS.rifle.magSize, pistol: WEAPONS.pistol.magSize };
  private reserve: Record<WeaponId, number> = { rifle: WEAPONS.rifle.reserve, pistol: WEAPONS.pistol.reserve };
  current: WeaponId = "rifle";

  private fireTimer = 0;
  private reloadTimer = 0;
  private prevFireHeld = false;
  private bloom = 0;
  private autoReloadTimer = -1;

  /** Vertical recoil offset (radians) applied on top of player pitch, recovers over time. */
  recoilPitch = 0;
  /** 0 = hip, 1 = fully aimed down sights. */
  adsAmount = 0;

  // viewmodel
  private vm: THREE.Group;
  private vmMuzzle: THREE.Object3D;
  private vmPose = { hip: new THREE.Vector3(0.21, -0.19, -0.4), ads: new THREE.Vector3(0, -0.115, -0.3) };
  private bobPhase = 0;
  private kickZ = 0;
  private reloadAnim = 0;

  constructor(
    private camera: THREE.PerspectiveCamera,
    scene: THREE.Scene,
    private colliders: AABB[],
    private effects: Effects,
    private audio: AudioSystem,
    private getTargets: () => Shootable[],
    /** Apply damage to what was hit; returns true if it was a kill. Boot wires this to Bot.takeDamage. */
    private onShoot: (target: Shootable, dmg: number, headshot: boolean) => boolean,
    private onHitmarker: (killed: boolean, headshot: boolean) => void,
  ) {
    this.vm = buildViewmodel("rifle");
    this.vmMuzzle = this.vm.getObjectByName("muzzle")!;
    camera.add(this.vm);
    scene.add(camera);
  }

  // ---------- queries for HUD ----------
  get def() { return WEAPONS[this.current]; }
  magAmmo(): number { return this.mag[this.current]; }
  reserveAmmo(): number { return this.reserve[this.current]; }
  get reloading(): boolean { return this.reloadTimer > 0; }
  /** 0..1 progress of the ongoing reload (0 when not reloading). */
  get reloadProgress(): number {
    return this.reloadTimer > 0 ? 1 - this.reloadTimer / this.def.reloadTime : 0;
  }
  weaponName(): string { return this.def.name; }

  /** Current spread in radians (HUD crosshair uses it too). */
  spread(player: PlayerController): number {
    const d = this.def;
    let s = THREE.MathUtils.lerp(d.spreadHip, d.spreadAds, this.adsAmount);
    s += d.spreadMovePenalty * player.speedRatio * (1 - this.adsAmount * 0.6);
    if (player.crouched) s *= d.spreadCrouchBonus;
    s += this.bloom;
    return s;
  }

  muzzleWorld(out: THREE.Vector3): THREE.Vector3 {
    return this.vmMuzzle.getWorldPosition(out);
  }

  // ---------- actions ----------
  switchWeapon(): void {
    if (this.reloadTimer > 0) this.reloadTimer = 0; // cancel reload
    this.current = this.current === "rifle" ? "pistol" : "rifle";
    // rebuild viewmodel for the new weapon
    this.camera.remove(this.vm);
    this.vm = buildViewmodel(this.current);
    this.vmMuzzle = this.vm.getObjectByName("muzzle")!;
    this.camera.add(this.vm);
    this.bloom = 0;
    this.audio.sfx("reloadEnd");
  }

  startReload(): void {
    if (this.reloadTimer > 0) return;
    if (this.mag[this.current] >= this.def.magSize || this.reserve[this.current] <= 0) return;
    this.reloadTimer = this.def.reloadTime;
    this.reloadAnim = 1;
    this.audio.sfx("reloadStart");
  }

  /** Full refill between rounds. */
  resetAmmo(): void {
    this.mag = { rifle: WEAPONS.rifle.magSize, pistol: WEAPONS.pistol.magSize };
    this.reserve = { rifle: WEAPONS.rifle.reserve, pistol: WEAPONS.pistol.reserve };
    this.reloadTimer = 0;
    this.bloom = 0;
    this.recoilPitch = 0;
  }

  update(dt: number, input: GameInput, player: PlayerController, canFire: boolean): void {
    const d = this.def;
    this.fireTimer -= dt;
    this.bloom = Math.max(0, this.bloom - dt * 0.05);
    this.recoilPitch = THREE.MathUtils.damp(this.recoilPitch, 0, d.recoilRecover, dt);
    this.kickZ = THREE.MathUtils.damp(this.kickZ, 0, 10, dt);

    // ADS amount follows the held state
    this.adsAmount = THREE.MathUtils.damp(this.adsAmount, input.aimHeld && this.reloadTimer <= 0 ? 1 : 0, 14, dt);

    // reload
    if (this.reloadTimer > 0) {
      this.reloadTimer -= dt;
      if (this.reloadTimer <= 0) {
        const need = d.magSize - this.mag[this.current];
        const take = Math.min(need, this.reserve[this.current]);
        this.mag[this.current] += take;
        this.reserve[this.current] -= take;
        this.audio.sfx("reloadEnd");
      }
    }

    // auto-reload after dry click
    if (this.autoReloadTimer > 0) {
      this.autoReloadTimer -= dt;
      if (this.autoReloadTimer <= 0) this.startReload();
    }

    if (input.takeAction("reload") || input.takeAction("KeyR")) this.startReload();
    if (input.takeAction("switch") || input.takeAction("KeyQ") || input.takeAction("Digit1") || input.takeAction("Digit2")) this.switchWeapon();

    // firing
    const wantFire = input.fireHeld && canFire && player.alive;
    const edge = wantFire && !this.prevFireHeld;
    this.prevFireHeld = wantFire;
    const canShoot = this.reloadTimer <= 0 && this.fireTimer <= 0;
    if (wantFire && canShoot) {
      const semiOk = d.auto || edge;
      if (semiOk) {
        if (this.mag[this.current] <= 0) {
          this.audio.sfx("empty");
          this.fireTimer = 0.3;
          this.autoReloadTimer = 0.35; // dry click → auto reload
        } else {
          this.fire(dt, player);
        }
      }
    }

    this.updateViewmodel(dt, player);
  }

  private fire(dt: number, player: PlayerController): void {
    void dt;
    const d = this.def;
    this.mag[this.current]--;
    this.fireTimer = 60 / d.rpm;
    this.bloom = Math.min(0.05, this.bloom + 0.006);
    this.recoilPitch += d.recoilKick * (1 - this.adsAmount * 0.35);
    this.kickZ = Math.min(0.12, this.kickZ + 0.035);
    this.audio.sfx(this.current === "rifle" ? "shot" : "pistol");

    // ray from camera center
    const spread = this.spread(player);
    const dir = _dir.set(
      (Math.random() - 0.5) * 2 * spread,
      (Math.random() - 0.5) * 2 * spread,
      -1,
    ).normalize().applyQuaternion(this.camera.quaternion);
    const origin = this.camera.getWorldPosition(_origin);

    // nearest wall hit
    const wallT = raycastColliders(this.colliders, origin.x, origin.y, origin.z, dir.x, dir.y, dir.z, d.range);

    // nearest target hit
    let bestT = wallT;
    let bestTarget: Shootable | null = null;
    let headshot = false;
    for (const t of this.getTargets()) {
      if (!t.alive || t.team === player.team) continue;
      const ht = raySphere(origin, dir, t.pos.x, t.headY, t.pos.z, 0.2, bestT);
      if (ht > 0 && ht < bestT) { bestT = ht; bestTarget = t; headshot = true; continue; }
      const ct = rayCylinder(origin, dir, t.pos.x, t.pos.z, t.radius, t.height, bestT);
      if (ct > 0 && ct < bestT) { bestT = ct; bestTarget = t; headshot = false; }
    }

    const end = _end.copy(origin).addScaledVector(dir, bestT);
    this.muzzleWorld(_muzzle);
    this.effects.tracer(_muzzle, end);
    this.effects.muzzleFlash(_muzzle, 22);

    if (bestTarget) {
      // damage falloff past 24m
      const falloff = bestT > 24 ? Math.max(0.55, 1 - (bestT - 24) / 60) : 1;
      const dmg = d.damage * (headshot ? d.headMult : 1) * falloff;
      const killed = this.onShoot(bestTarget, dmg, headshot);
      this.effects.impact(end, true);
      this.onHitmarker(killed, headshot);
    } else if (bestT < d.range) {
      this.effects.impact(end, false);
    }
  }

  // ---------- viewmodel animation ----------
  private updateViewmodel(dt: number, player: PlayerController): void {
    const speed = player.speedRatio;
    this.bobPhase += dt * (4 + speed * 6) * (player.crouched ? 0.6 : 1);
    const bobAmp = 0.011 * speed * (1 - this.adsAmount * 0.85);
    const bobX = Math.sin(this.bobPhase) * bobAmp;
    const bobY = -Math.abs(Math.cos(this.bobPhase)) * bobAmp;

    const target = _pose.copy(this.vmPose.hip).lerp(this.vmPose.ads, this.adsAmount);
    target.x += bobX + Math.sin(performance.now() * 0.0011) * 0.0016; // idle sway
    target.y += bobY + Math.cos(performance.now() * 0.0014) * 0.0013;
    target.z += this.kickZ;
    this.vm.position.lerp(target, 1 - Math.exp(-18 * dt));

    // reload dip + tilt
    if (this.reloadTimer > 0) {
      const k = Math.sin((1 - this.reloadTimer / this.def.reloadTime) * Math.PI);
      this.vm.position.y -= k * 0.16;
      this.vm.rotation.x = k * 0.7;
      this.vm.rotation.z = k * 0.25;
    } else {
      this.vm.rotation.x = THREE.MathUtils.damp(this.vm.rotation.x, 0, 14, dt);
      this.vm.rotation.z = THREE.MathUtils.damp(this.vm.rotation.z, 0, 14, dt);
      this.vm.rotation.y = THREE.MathUtils.damp(this.vm.rotation.y, this.adsAmount * 0.0, 14, dt);
    }
  }

  setVisible(v: boolean): void { this.vm.visible = v; }

  dispose(): void {
    this.camera.remove(this.vm);
  }
}

/** Ray → sphere: returns hit t or -1. */
export function raySphere(o: THREE.Vector3, d: THREE.Vector3, cx: number, cy: number, cz: number, r: number, maxT: number): number {
  const ox = o.x - cx, oy = o.y - cy, oz = o.z - cz;
  const b = ox * d.x + oy * d.y + oz * d.z;
  const c = ox * ox + oy * oy + oz * oz - r * r;
  const disc = b * b - c;
  if (disc < 0) return -1;
  const t = -b - Math.sqrt(disc);
  return t > 0 && t < maxT ? t : -1;
}

/** Ray → vertical cylinder (feet at y=0..height): returns hit t or -1. */
export function rayCylinder(o: THREE.Vector3, d: THREE.Vector3, cx: number, cz: number, r: number, height: number, maxT: number): number {
  const ox = o.x - cx, oz = o.z - cz;
  const a = d.x * d.x + d.z * d.z;
  if (a < 1e-9) return -1;
  const b = ox * d.x + oz * d.z;
  const c = ox * ox + oz * oz - r * r;
  const disc = b * b - a * c;
  if (disc < 0) return -1;
  const t = (-b - Math.sqrt(disc)) / a;
  if (t <= 0 || t >= maxT) return -1;
  const y = o.y + d.y * t;
  return y >= 0 && y <= height ? t : -1;
}

// scratch
const _dir = new THREE.Vector3();
const _origin = new THREE.Vector3();
const _end = new THREE.Vector3();
const _muzzle = new THREE.Vector3();
const _pose = new THREE.Vector3();

// ---------------------------------------------------------------------------
// viewmodel construction — gloved arms + dark rifle with red accents
// ---------------------------------------------------------------------------

function buildViewmodel(weapon: WeaponId): THREE.Group {
  const g = new THREE.Group();
  g.scale.setScalar(0.62); // keep the weapon compact in the lower-right of the frame
  const dark = new THREE.MeshStandardMaterial({ color: 0x3a3f47, roughness: 0.5, metalness: 0.55 });
  const darker = new THREE.MeshStandardMaterial({ color: 0x26292f, roughness: 0.55, metalness: 0.5 });
  const red = new THREE.MeshStandardMaterial({ color: 0xc22630, roughness: 0.4, metalness: 0.35 });
  const glove = new THREE.MeshStandardMaterial({ color: 0x453e33, roughness: 0.95 });
  const skinDark = new THREE.MeshStandardMaterial({ color: 0x4a4238, roughness: 0.9 });

  const box = (w: number, h: number, d: number, mat: THREE.Material, x: number, y: number, z: number, rx = 0, ry = 0, rz = 0): THREE.Mesh => {
    const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
    m.position.set(x, y, z);
    m.rotation.set(rx, ry, rz);
    g.add(m);
    return m;
  };

  if (weapon === "rifle") {
    // receiver + red-accented handguard
    box(0.055, 0.09, 0.34, dark, 0, 0, -0.1);
    box(0.05, 0.055, 0.3, red, 0, 0.005, -0.38);
    // barrel + muzzle
    const barrel = new THREE.Mesh(new THREE.CylinderGeometry(0.014, 0.014, 0.3, 8), darker);
    barrel.rotation.x = Math.PI / 2;
    barrel.position.set(0, 0.01, -0.62);
    g.add(barrel);
    // muzzle reference point (world pos read for flash/tracer origin)
    const muzzle = new THREE.Object3D();
    muzzle.name = "muzzle";
    muzzle.position.set(0, 0.01, -0.78);
    g.add(muzzle);
    // mag (angled)
    box(0.04, 0.14, 0.07, darker, 0, -0.1, -0.16, 0.25);
    // stock + grip + sight
    box(0.05, 0.08, 0.18, darker, 0, -0.01, 0.12);
    box(0.035, 0.1, 0.045, darker, 0, -0.09, 0.02, 0.3);
    box(0.02, 0.045, 0.05, dark, 0, 0.075, -0.06);
    // arms: right hand on grip, left hand on handguard
    box(0.055, 0.055, 0.14, glove, 0.005, -0.115, 0.02, 0.3);
    box(0.06, 0.06, 0.2, skinDark, 0.01, -0.16, 0.1, 0.5);
    box(0.055, 0.05, 0.12, glove, -0.005, -0.045, -0.4, 0, 0, 0.15);
    box(0.06, 0.06, 0.22, skinDark, -0.03, -0.1, -0.3, -0.4, 0.5, 0.4);
  } else {
    // pistol
    box(0.04, 0.06, 0.2, dark, 0, 0, -0.08);
    box(0.038, 0.03, 0.1, red, 0, 0.005, -0.2);
    const muzzle = new THREE.Object3D();
    muzzle.name = "muzzle";
    muzzle.position.set(0, 0.005, -0.26);
    g.add(muzzle);
    box(0.035, 0.11, 0.05, darker, 0, -0.08, 0.0, 0.25);
    box(0.055, 0.055, 0.12, glove, 0.005, -0.09, 0.0, 0.25);
    box(0.06, 0.06, 0.18, skinDark, 0.01, -0.14, 0.08, 0.5);
  }
  return g;
}
