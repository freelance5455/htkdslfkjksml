import * as THREE from 'three';

// ——— Эффекты: пена, монеты, всплывающий текст, полоса прогресса мойки ———

const _v = new THREE.Vector3();

export class Effects {
  constructor(scene, camera, floatLayer) {
    this.scene = scene;
    this.camera = camera;
    this.floatLayer = floatLayer;
    this.foams = [];   // активные пены {group, bubbles, t}
    this.coins = [];   // летящие монеты {mesh, from, t, target, onDone}
    this.foamGeo = new THREE.SphereGeometry(0.09, 6, 5);
    this.foamMat = new THREE.MeshStandardMaterial({ color: 0xf4fbff, roughness: 0.35, transparent: true, opacity: 0.9 });
    this.coinGeo = new THREE.CylinderGeometry(0.16, 0.16, 0.05, 12);
    this.coinMat = new THREE.MeshStandardMaterial({ color: 0xf5c542, metalness: 0.75, roughness: 0.25, emissive: 0x664d05, emissiveIntensity: 0.4 });
  }

  // Пена вокруг машины (включается на время мойки)
  startFoam(anchor) {
    const group = new THREE.Group();
    const bubbles = [];
    for (let i = 0; i < 22; i++) {
      const b = new THREE.Mesh(this.foamGeo, this.foamMat);
      const a = Math.random() * Math.PI * 2;
      b.userData = { a, r: 0.7 + Math.random() * 1.2, y: 0.3 + Math.random() * 1.2, s: 0.6 + Math.random() * 1.6, sp: 1 + Math.random() * 2 };
      b.scale.setScalar(b.userData.s);
      bubbles.push(b);
      group.add(b);
    }
    group.position.copy(anchor);
    this.scene.add(group);
    const foam = { group, bubbles, t: 0 };
    this.foams.push(foam);
    return foam;
  }

  stopFoam(foam) {
    if (!foam) return;
    this.scene.remove(foam.group);
    this.foams = this.foams.filter(f => f !== foam);
  }

  // Монетки летят к цели (игроку), по прибытии — onDone
  coinBurst(worldPos, count, targetGetter, onDone) {
    for (let i = 0; i < count; i++) {
      const mesh = new THREE.Mesh(this.coinGeo, this.coinMat);
      mesh.rotation.x = Math.PI / 2;
      mesh.position.copy(worldPos).add(new THREE.Vector3((Math.random() - 0.5) * 1.4, 1 + Math.random() * 0.8, (Math.random() - 0.5) * 1.4));
      mesh.castShadow = true;
      this.scene.add(mesh);
      this.coins.push({ mesh, t: -i * 0.09, from: mesh.position.clone(), targetGetter, onDone: i === count - 1 ? onDone : null });
    }
  }

  // Всплывающий текст в мировых координатах (HTML-слой)
  floatText(worldPos, text, color = '#ffe9a8') {
    _v.copy(worldPos).project(this.camera);
    if (_v.z > 1) return;
    const el = document.createElement('div');
    el.className = 'float-text';
    el.textContent = text;
    el.style.color = color;
    el.style.left = `${(_v.x * 0.5 + 0.5) * innerWidth}px`;
    el.style.top = `${(-_v.y * 0.5 + 0.5) * innerHeight}px`;
    this.floatLayer.appendChild(el);
    setTimeout(() => el.remove(), 1150);
  }

  update(dt, time) {
    // Пена
    for (const f of this.foams) {
      f.t += dt;
      for (const b of f.bubbles) {
        const u = b.userData;
        const wob = time * u.sp + u.a;
        b.position.set(Math.cos(u.a + time * 0.7) * u.r, u.y + Math.sin(wob) * 0.15, Math.sin(u.a + time * 0.7) * u.r * 1.5);
        b.scale.setScalar(u.s * (0.8 + 0.25 * Math.sin(wob * 1.7)));
      }
    }
    // Монеты
    for (const c of [...this.coins]) {
      c.t += dt;
      if (c.t < 0) continue;
      const target = c.targetGetter();
      const k = Math.min(c.t / 0.55, 1);
      const ease = 1 - (1 - k) * (1 - k);
      c.mesh.position.lerpVectors(c.from, target, ease);
      c.mesh.position.y += Math.sin(k * Math.PI) * 1.6;
      c.mesh.rotation.z += dt * 9;
      if (k >= 1) {
        this.scene.remove(c.mesh);
        this.coins = this.coins.filter(x => x !== c);
        if (c.onDone) c.onDone();
      }
    }
  }
}

// ——— Полоса прогресса над машиной ———
export class ProgressBar {
  constructor(parent) {
    this.group = new THREE.Group();
    const bg = new THREE.Mesh(new THREE.PlaneGeometry(1.8, 0.22),
      new THREE.MeshBasicMaterial({ color: 0x14202c, transparent: true, opacity: 0.85, depthWrite: false }));
    this.fill = new THREE.Mesh(new THREE.PlaneGeometry(1.72, 0.14),
      new THREE.MeshBasicMaterial({ color: 0x57d977, depthWrite: false }));
    this.fill.position.z = 0.01;
    this.group.add(bg, this.fill);
    this.group.position.y = 2.5;
    this.group.visible = false;
    parent.add(this.group);
    this._p = 0;
  }
  set(p) {
    this._p = p;
    this.group.visible = p > 0.001 && p < 0.999;
    this.fill.scale.x = Math.max(p, 0.001);
    this.fill.position.x = -0.86 * (1 - p);
  }
  faceCamera(camera) {
    if (this.group.visible) this.group.quaternion.copy(camera.quaternion);
  }
}
