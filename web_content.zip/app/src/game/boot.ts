/**
 * boot.ts — KINGDOM OF SHADOWS (مملكة الظلال): game orchestration.
 * 3D open-world dark-fantasy action RPG: exploration, souls-like combat,
 * weapon upgrades, skill tree, quests, day/night, weather, bosses, endings.
 */
import * as THREE from "three";
import { GameLoop } from "./engine";
import { Input } from "./input";
import { AudioSystem } from "./audio";
import { World, Waystone } from "./world";
import { Player } from "./player";
import { Spawner, Enemy, Projectiles, EnemyEvents } from "./enemies";
import { Particles, DamageNumbers, ScreenShake, hitOverlap } from "./combat";
import { UI, HUDData, MenuData, UIHandlers } from "./ui";
import { WORLD, PLAYER, XP_LEVELS } from "./config";
import { WEAPONS, WeaponKind, MAX_WEAPON_TIER, upgradeCost, EQUIPMENT, EquipDef, ITEMS, SKILLS } from "./data";
import { NPCS, CHESTS, LORE_NOTES, MAIN_QUESTS, SIDE_QUESTS, QuestState, INTRO_TEXT, ENDINGS as ENDINGS_LIST, freshQuestState } from "./quests";
import { hasSave, readSave, writeSave, clearSave, SaveData, freshSaveState } from "./save";
import { buildHumanoid, HumanoidParts } from "./characters";
import { clamp, lerp, dist2 } from "./noise";

declare global {
  interface Window {
    __gameProbe?: () => { x: number; y: number; z: number };
    __GAME_READY__?: boolean;
  }
}

type GameState = "title" | "intro" | "play" | "dead" | "ending";

interface Interactable {
  id: string;
  x: number; z: number; r: number;
  label: string;
  action: () => void;
  available: () => boolean;
}

interface NpcEntity { id: string; parts: HumanoidParts; x: number; z: number; }

class Game {
  renderer: THREE.WebGLRenderer;
  scene = new THREE.Scene();
  camera: THREE.PerspectiveCamera;
  loop: GameLoop;
  input = new Input();
  audio = new AudioSystem();
  world!: World;
  player!: Player;
  spawner!: Spawner;
  projectiles!: Projectiles;
  particles!: Particles;
  dmgNum!: DamageNumbers;
  shake = new ScreenShake();
  ui: UI;

  state: GameState = "title";
  quests: QuestState = freshQuestState();
  chestsOpened = new Set<string>();
  notesRead = new Set<string>();
  discoveredZones = new Set<string>();
  playTime = 0;
  totalKills = 0;
  deaths = 0;
  endedRuns = 0;
  ended: string | null = null;

  npcs: NpcEntity[] = [];
  chestMeshes = new Map<string, THREE.Object3D>();
  noteMeshes = new Map<string, THREE.Object3D>();
  pillarMeshes: { id: string; mesh: THREE.Object3D; x: number; z: number }[] = [];
  swordMesh: THREE.Group | null = null;
  anvilPos = { x: 24, z: -218 };
  anvilMesh: THREE.Object3D | null = null;

  currentBoss: Enemy | null = null;
  treantSpawned = false;
  kingSpawned = false;
  kingDefeated = false;
  private enemyEvents!: EnemyEvents;
  private clones: { parts: HumanoidParts; t: number; atkCd: number }[] = [];

  private interactables: Interactable[] = [];
  private currentInteract: Interactable | null = null;
  private autosaveT = 20;
  private musicT = 0;
  private sweepT = 5;
  private fpsAcc = 0; private fpsN = 0; private fpsLowT = 0;
  quality: "low" | "medium" | "high" | "ultra" = "high";
  private t = 0;
  private introCamT = 0;
  private deadT = 0;
  private waveState: { x: number; z: number; dirX: number; dirZ: number; traveled: number; dmg: number } | null = null;
  private waveMesh: THREE.Mesh | null = null;

  private canvas: HTMLCanvasElement;
  private disposers: (() => void)[] = [];

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    this.renderer = new THREE.WebGLRenderer({ canvas, preserveDrawingBuffer: true, antialias: true });
    this.camera = new THREE.PerspectiveCamera(66, window.innerWidth / window.innerHeight, 0.1, 1200);

    this.ui = new UI(document.getElementById("ui-overlay") as HTMLElement);
    this.ui.handlers = this.makeHandlers();

    this.readQuality();
    this.applyQuality();

    const onResize = () => {
      this.camera.aspect = window.innerWidth / window.innerHeight;
      this.camera.updateProjectionMatrix();
      this.renderer.setSize(window.innerWidth, window.innerHeight, false);
    };
    window.addEventListener("resize", onResize);
    this.disposers.push(() => window.removeEventListener("resize", onResize));
    onResize();

    // mouse buttons
    const onMouseDown = (e: MouseEvent) => {
      if (this.state !== "play" || this.isOverlayOpen()) return;
      if (e.button === 0) this.input.actions.add("MouseLeft");
      if (e.button === 1) this.input.actions.add("MouseMiddle");
      if (e.button === 2) this.player?.notifyMouseRight();
      if (document.pointerLockElement !== this.canvas) this.canvas.requestPointerLock?.();
    };
    const onMouseUp = (e: MouseEvent) => { if (e.button === 2) this.player?.notifyMouseRightUp(); };
    const onCtx = (e: Event) => e.preventDefault();
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.code === "Tab" || e.code === "Space") e.preventDefault();
      if (this.state === "title" && (e.code === "Space" || e.code === "Enter")) {
        this.ui.handlers.onStart(!hasSave());
      }
      if (e.code === "Escape") this.handleEscape();
      if (e.code === "KeyE") this.handleInteract();
      if (e.code === "KeyC" || e.code === "KeyM" || e.code === "KeyJ") this.toggleMenu();
      if (this.state === "intro" && (e.code === "Space" || e.code === "KeyE")) this.endIntro();
    };
    window.addEventListener("mousedown", onMouseDown);
    window.addEventListener("mouseup", onMouseUp);
    window.addEventListener("contextmenu", onCtx);
    window.addEventListener("keydown", onKeyDown);
    this.disposers.push(() => {
      window.removeEventListener("mousedown", onMouseDown);
      window.removeEventListener("mouseup", onMouseUp);
      window.removeEventListener("contextmenu", onCtx);
      window.removeEventListener("keydown", onKeyDown);
    });

    this.loop = new GameLoop({
      update: (dt) => this.update(dt),
      render: () => this.render(),
    });
  }

  // ---------------- setup ----------------

  private buildWorldAndEntities(): void {
    // clean previous scene children except camera-related (fresh scene each start)
    this.scene = new THREE.Scene();
    this.world = new World(this.scene);
    this.particles = new Particles(this.scene);
    this.dmgNum = new DamageNumbers(this.scene);
    this.projectiles = new Projectiles(this.scene);
    this.player = new Player(this.world, this.input, this.audio, this.particles, this.dmgNum, this.shake);
    this.scene.add(this.player.parts.root);
    this.spawner = new Spawner(this.world, this.scene);
    this.world.onThunder = () => { setTimeout(() => this.audio.sfx("thunder"), 300 + Math.random() * 1200); };
    this.buildNpcs();
    this.buildChests();
    this.buildNotes();
    this.buildPillars();
    this.buildSwordPedestal();
    this.buildAnvil();
    this.buildInteractables();
    this.makeEnemyEvents();
  }

  private buildNpcs(): void {
    for (const def of NPCS) {
      const parts = buildHumanoid({
        armorColor: def.color, clothColor: def.color, skinColor: 0xc9a184,
        eyeColor: 0xffd76a, scale: 0.98, cape: false, hood: def.hood, glowIntensity: 0,
      });
      const y = this.world.height(def.x, def.z);
      parts.root.position.set(def.x, y, def.z);
      parts.root.rotation.y = Math.random() * Math.PI * 2;
      this.scene.add(parts.root);
      this.npcs.push({ id: def.id, parts, x: def.x, z: def.z });
    }
  }

  private buildChests(): void {
    const geo = new THREE.BoxGeometry(1.1, 0.7, 0.7);
    const lidGeo = new THREE.BoxGeometry(1.1, 0.3, 0.7);
    for (const c of CHESTS) {
      const g = new THREE.Group();
      const mat = new THREE.MeshStandardMaterial({ color: 0x5a4630, roughness: 0.8, metalness: 0.15 });
      const base = new THREE.Mesh(geo, mat);
      base.position.y = 0.35;
      const lid = new THREE.Mesh(lidGeo, new THREE.MeshStandardMaterial({ color: 0x6a5238, roughness: 0.75 }));
      lid.position.y = 0.85;
      const glow = new THREE.Mesh(new THREE.BoxGeometry(1.14, 0.1, 0.74), new THREE.MeshBasicMaterial({ color: 0xffd76a }));
      glow.position.y = 0.72;
      g.add(base, lid, glow);
      g.traverse((m) => { if ((m as THREE.Mesh).isMesh) m.castShadow = true; });
      g.position.set(c.x, this.world.height(c.x, c.z), c.z);
      g.rotation.y = (c.x * 13 + c.z * 7) % 3;
      this.scene.add(g);
      this.chestMeshes.set(c.id, g);
    }
  }

  private buildNotes(): void {
    for (const n of LORE_NOTES) {
      const g = new THREE.Group();
      const page = new THREE.Mesh(new THREE.PlaneGeometry(0.5, 0.65),
        new THREE.MeshStandardMaterial({ color: 0xd8cfae, emissive: 0x8a7a4a, emissiveIntensity: 0.35, side: THREE.DoubleSide }));
      page.position.y = 0.7;
      page.rotation.x = -0.4;
      g.add(page);
      g.position.set(n.x, this.world.height(n.x, n.z), n.z);
      this.scene.add(g);
      this.noteMeshes.set(n.id, g);
    }
  }

  private buildPillars(): void {
    const defs = [
      { id: "pillar_city", x: 30, z: -250 },
      { id: "pillar_ice", x: 235, z: 40 },
      { id: "pillar_swamp", x: -45, z: 255 },
    ];
    for (const d of defs) {
      const g = new THREE.Group();
      const col = new THREE.Mesh(new THREE.CylinderGeometry(0.55, 0.8, 4.6, 6),
        new THREE.MeshStandardMaterial({ color: 0x3a3f55, roughness: 0.7 }));
      col.position.y = 2.3;
      const orb = new THREE.Mesh(new THREE.SphereGeometry(0.45, 12, 10),
        new THREE.MeshStandardMaterial({ color: 0x22262e, emissive: 0x334, emissiveIntensity: 0.4 }));
      orb.position.y = 5.1;
      g.add(col, orb);
      g.position.set(d.x, this.world.height(d.x, d.z), d.z);
      g.traverse((m) => { if ((m as THREE.Mesh).isMesh) m.castShadow = true; });
      this.scene.add(g);
      this.pillarMeshes.push({ id: d.id, mesh: g, x: d.x, z: d.z });
    }
  }

  private buildSwordPedestal(): void {
    const g = new THREE.Group();
    const blade = new THREE.Mesh(new THREE.BoxGeometry(0.09, 1.25, 0.02),
      new THREE.MeshStandardMaterial({ color: 0xd8dcff, emissive: 0x8a9fff, emissiveIntensity: 1.4, metalness: 0.9, roughness: 0.2 }));
    blade.position.y = 1.35;
    const guard = new THREE.Mesh(new THREE.BoxGeometry(0.34, 0.06, 0.06), new THREE.MeshStandardMaterial({ color: 0x2a2d3a, metalness: 0.7 }));
    guard.position.y = 0.72;
    g.add(blade, guard);
    g.position.set(0, this.world.height(0, 6) + 1.0, 6);
    this.scene.add(g);
    this.swordMesh = g;
  }

  private buildAnvil(): void {
    const g = new THREE.Group();
    const base = new THREE.Mesh(new THREE.BoxGeometry(0.8, 0.5, 0.5), new THREE.MeshStandardMaterial({ color: 0x2e3242, metalness: 0.6, roughness: 0.5 }));
    base.position.y = 0.55;
    const top = new THREE.Mesh(new THREE.BoxGeometry(1.1, 0.25, 0.45), new THREE.MeshStandardMaterial({ color: 0x3a3f52, metalness: 0.7, roughness: 0.4 }));
    top.position.y = 0.9;
    g.add(base, top);
    g.position.set(this.anvilPos.x, this.world.height(this.anvilPos.x, this.anvilPos.z), this.anvilPos.z);
    this.scene.add(g);
    this.anvilMesh = g;
  }

  // ---------------- interactables ----------------

  private buildInteractables(): void {
    const I = this.interactables;
    I.length = 0;
    // sword
    I.push({
      id: "sword", x: 0, z: 6, r: 3, label: "E — خذ نصل الفجر",
      action: () => {
        this.quests.flags["hasSword"] = 1;
        if (this.swordMesh) { this.scene.remove(this.swordMesh); this.swordMesh = null; }
        this.player.arm("dawnblade");
        this.audio.sfx("crystal");
        this.particles.burst(0, this.world.height(0, 6) + 2, 6, 40, 0x9fb0ff, 5, 1);
        this.ui.notify("حصلت على نصل الفجر!", "quest");
        this.shake.add(0.2);
      },
      available: () => this.quests.flags["hasSword"] !== 1 && !this.player.hasWeapon,
    });
    // npcs
    for (const def of NPCS) {
      I.push({
        id: "npc_" + def.id, x: def.x, z: def.z, r: 3.6, label: `E — تحدث مع ${def.name}`,
        action: () => this.talkTo(def.id),
        available: () => true,
      });
    }
    // chests
    for (const c of CHESTS) {
      I.push({
        id: "chest_" + c.id, x: c.x, z: c.z, r: 2.6, label: "E — افتح الصندوق",
        action: () => this.openChest(c.id),
        available: () => !this.chestsOpened.has(c.id),
      });
    }
    // notes
    for (const n of LORE_NOTES) {
      I.push({
        id: "note_" + n.id, x: n.x, z: n.z, r: 2.6, label: "E — اقرأ الرسالة",
        action: () => {
          this.notesRead.add(n.id);
          const m = this.noteMeshes.get(n.id);
          if (m) m.visible = false;
          this.ui.notify(`${n.title}: ${n.text}`, "info");
          this.audio.sfx("pickup");
          this.save();
        },
        available: () => !this.notesRead.has(n.id),
      });
    }
    // waystones
    for (const w of this.world.waystones) {
      I.push({
        id: "ws_" + w.id, x: w.x, z: w.z, r: 3.4, label: "E — نقطة الطاقة (سفر/حفظ)",
        action: () => {
          this.save();
          this.audio.sfx("ui");
          this.ui.showTravel(
            this.world.waystones.map((x) => ({ id: x.id, name: x.name, discovered: x.discovered })),
            w.id,
          );
        },
        available: () => w.discovered,
      });
    }
    // pillars
    for (const p of this.pillarMeshes) {
      I.push({
        id: p.id, x: p.x, z: p.z, r: 3.6, label: "E — أشعل عمود الطاقة",
        action: () => this.lightPillar(p.id),
        available: () => this.quests.mainStage >= 6 && this.quests.flags[p.id] !== 1,
      });
    }
    // anvil
    I.push({
      id: "anvil", x: this.anvilPos.x, z: this.anvilPos.z, r: 4, label: "E — ورشة الحدادة",
      action: () => { if (this.quests.flags["forgeLit"] === 1) { this.ui.showSmith(this.menuData()); this.audio.sfx("anvil"); } else this.ui.notify("الورشة بلا نار... أحضر البلورات لبروم أولاً.", "warn"); },
      available: () => true,
    });
  }

  private lightPillar(id: string): void {
    this.quests.flags[id] = 1;
    const p = this.pillarMeshes.find((x) => x.id === id);
    if (p) {
      p.mesh.traverse((m) => {
        const mm = m as THREE.Mesh;
        if (mm.isMesh && mm.geometry.type === "SphereGeometry") {
          (mm.material as THREE.MeshStandardMaterial).emissive.set(0x5a8aff);
          (mm.material as THREE.MeshStandardMaterial).emissiveIntensity = 2.5;
        }
      });
      const l = new THREE.PointLight(0x5a8aff, 20, 20, 2);
      l.position.set(p.x, this.world.height(p.x, p.z) + 5, p.z);
      this.scene.add(l);
    }
    this.audio.sfx("crystal");
    this.particles.burst(p?.x ?? 0, this.world.height(p?.x ?? 0, p?.z ?? 0) + 5, p?.z ?? 0, 50, 0x5a8aff, 6, 1);
    const lit = (this.quests.flags["pillar_city"] ?? 0) + (this.quests.flags["pillar_ice"] ?? 0) + (this.quests.flags["pillar_swamp"] ?? 0);
    this.ui.notify(`أُشعل العمود! (${lit}/3)`, "quest");
    if (lit >= 3) {
      this.giveWeapon("dragon");
      this.ui.notify("سيف التنين يتوهج بين يديك — بوابة القلعة مفتوحة الآن!", "quest");
      this.audio.sfx("questDone");
    }
    this.save();
  }

  private openChest(id: string): void {
    const c = CHESTS.find((x) => x.id === id);
    if (!c) return;
    this.chestsOpened.add(id);
    const m = this.chestsMeshesGet(id);
    if (m) m.rotation.x = -0.25;
    this.audio.sfx("pickup");
    const loot: string[] = [];
    if (c.loot.gold) { this.player.stats.gold += c.loot.gold; loot.push(`${c.loot.gold} ذهب`); }
    if (c.loot.items) {
      for (const [k, v] of Object.entries(c.loot.items)) {
        this.player.inventory[k] = (this.player.inventory[k] ?? 0) + v;
        loot.push(`${ITEMS[k]?.name ?? k} ×${v}`);
      }
    }
    if (c.loot.equipment) {
      this.giveEquipment(c.loot.equipment);
    }
    if (c.loot.weapon) this.giveWeapon(c.loot.weapon as WeaponKind);
    this.ui.notify("صندوق الكنز: " + loot.join(" · "), "loot");
    this.particles.burst(c.x, this.world.height(c.x, c.z) + 1, c.z, 20, 0xffd76a, 4, 0.6);
    this.save();
  }

  private chestsMeshesGet(id: string): THREE.Object3D | undefined { return this.chestMeshes.get(id); }

  private giveEquipment(id: string): void {
    const eq = EQUIPMENT.find((e) => e.id === id);
    if (!eq) return;
    (this.player as unknown as { _ownedEquip?: string[] })._ownedEquip = (this.player as unknown as { _ownedEquip?: string[] })._ownedEquip ?? [];
    const owned = (this.player as unknown as { _ownedEquip: string[] })._ownedEquip;
    if (!owned.includes(id)) {
      owned.push(id);
      this.ui.notify(`معدات جديدة: ${eq.name} (${{ common: "عادية", rare: "نادرة", epic: "ملحمية", legendary: "أسطورية" }[eq.rarity]})`, "loot");
    }
  }

  private giveWeapon(kind: WeaponKind): void {
    if (!this.player.ownedWeapons.includes(kind)) {
      this.player.ownedWeapons.push(kind);
      this.player.weaponTiers[kind] = this.player.weaponTiers[kind] ?? 1;
      this.ui.notify(`سلاح جديد: ${WEAPONS[kind].name}!`, "quest");
      this.audio.sfx("quest");
    }
  }

  private talkTo(id: string): void {
    const def = NPCS.find((n) => n.id === id);
    if (!def) return;
    const dlg = def.dialogues(this.quests);
    const d = dlg[Math.min(this.quests.flags["dlg_" + id] ?? 0, dlg.length - 1)];
    document.exitPointerLock?.();
    this.audio.sfx("uiOpen");
    // side quest auto-start
    if (id === "irys" && this.quests.side["herbs"] === undefined) this.quests.side["herbs"] = 1;
    if (id === "syla" && this.quests.side["relics"] === undefined) this.quests.side["relics"] = 1;
    this.ui.showDialogue(d.lines, d.choices, () => {
      this.ui.closeDialogue();
      this.afterTalk(id);
      document.exitPointerLock?.();
    }, (effect) => {
      this.quests.choices[effect] = "1";
    });
    if (d.choices) this.ui.setChoices(d.choices);
  }

  private afterTalk(id: string): void {
    if (id === "mira" && this.quests.flags["metMira"] !== 1) {
      this.quests.flags["metMira"] = 1;
      this.ui.notify("مهمة جديدة: أسنان الرماد", "quest");
      this.audio.sfx("quest");
    }
    if (id === "irys" && this.quests.side["herbs"] === 1 && (this.player.inventory["herb"] ?? 0) >= 5 && (this.quests.flags["herbsGiven"] ?? 0) < 5) {
      this.player.inventory["herb"] -= 5;
      this.quests.flags["herbsGiven"] = 5;
      this.quests.side["herbs"] = 2;
      this.player.stats.gold += 120;
      this.ui.notify("أكملت مهمة: دواء الغائب (+120 ذهب)", "quest");
      this.audio.sfx("questDone");
    }
    if (id === "syla" && this.quests.side["relics"] === 1 && (this.player.inventory["relic"] ?? 0) >= 3 && (this.quests.flags["relicsGiven"] ?? 0) < 3) {
      this.player.inventory["relic"] -= 3;
      this.quests.flags["relicsGiven"] = 3;
      this.quests.side["relics"] = 2;
      this.player.stats.skillPoints += 2;
      this.giveEquipment("lightRing");
      this.ui.notify("أكملت مهمة: ذاكرة المملكة (+2 نقطة مهارات)", "quest");
      this.audio.sfx("questDone");
    }
    if (id === "brom" && this.quests.flags["forgeLit"] !== 1) {
      if ((this.player.inventory["crystal"] ?? 0) >= 4) {
        this.player.inventory["crystal"] -= 4;
        this.quests.flags["forgeLit"] = 1;
        this.ui.notify("أُيقظت نار الورشة! يمكنك الآن ترقية الأسلحة.", "quest");
        this.audio.sfx("questDone");
      } else {
        this.ui.notify(`بروم يحتاج 4 بلورات نور (لديك ${this.player.inventory["crystal"] ?? 0})`, "warn");
      }
    }
    if (id === "oldman" && this.kingDefeated) {
      this.startEndings();
      return;
    }
    this.checkQuests();
    this.save();
  }

  private handleInteract(): void {
    if (this.ui.isDialogueOpen) { this.ui.dialogueKeyHandler?.(); return; }
    if (this.state !== "play" || this.isOverlayOpen()) return;
    if (this.currentInteract) {
      this.currentInteract.action();
      this.buildInteractablesRefresh();
    }
  }

  private buildInteractablesRefresh(): void {
    // labels/availability may have changed; recompute lazily next frame
    this.interactDirty = true;
  }
  private interactDirty = false;

  private handleEscape(): void {
    if (this.state === "play") {
      if (this.ui.currentScreen === "pause") { this.ui.hideAll(); return; }
      if (this.ui.isMenuOpen || this.ui.isSmithOpen) { this.ui.closeMenu(); this.ui.closeSmith(); return; }
      if (this.ui.isDialogueOpen) { this.ui.closeDialogue(); return; }
      this.ui.showPause();
      document.exitPointerLock?.();
    }
  }

  private toggleMenu(): void {
    if (this.state !== "play") return;
    if (this.ui.isMenuOpen) this.ui.closeMenu();
    else if (!this.isOverlayOpen()) { this.ui.showMenu(this.menuData()); this.audio.sfx("uiOpen"); document.exitPointerLock?.(); }
  }

  private isOverlayOpen(): boolean {
    return this.ui.isMenuOpen || this.ui.isSmithOpen || this.ui.isDialogueOpen || this.ui.currentScreen === "pause";
  }

  // ---------------- enemy events ----------------

  private makeEnemyEvents(): void {
    this.enemyEvents = {
      onDeath: (e) => this.onEnemyDeath(e),
      onPlayerHit: () => { this.shake.add(0.2); },
      spawnProjectile: (x, y, z, dir, dmg, color, speed, team) => this.projectiles.fire(x, y, z, dir, dmg, color, speed, team),
      shake: (v) => this.shake.add(v),
      requestMinions: (boss, n) => {
        for (let i = 0; i < n; i++) {
          const a = Math.random() * Math.PI * 2;
          const e = new (Object.getPrototypeOf(boss).constructor as typeof Enemy)("guard", boss.pos.x + Math.cos(a) * 4, boss.pos.z + Math.sin(a) * 4, "castle", this.world);
          e.aggro = true;
          e.state = "chase";
          this.spawner.enemies.push(e);
          this.scene.add(e.mesh);
          this.particles.burst(e.pos.x, e.pos.y + 1, e.pos.z, 20, 0xa040ff, 4, 0.6);
        }
      },
    };
  }

  private onEnemyDeath(e: Enemy): void {
    this.totalKills++;
    this.quests.kills[e.def.kind] = (this.quests.kills[e.def.kind] ?? 0) + 1;
    // loot
    for (const l of e.def.loot) {
      if (Math.random() < l.chance) {
        const n = l.min + Math.floor(Math.random() * (l.max - l.min + 1));
        this.player.inventory[l.id] = (this.player.inventory[l.id] ?? 0) + n;
      }
    }
    this.player.stats.gold += e.def.gold;
    this.audio.sfx("coin");
    // xp
    this.giveXp(e.def.xp);
    // boss rewards
    if (e.def.kind === "treant") {
      this.quests.bossesDefeated.push("treant");
      this.giveWeapon("daggers");
      this.quests.flags["memory2"] = 1;
      this.ui.notify("هزمت حارس الغابة! شظية ذاكرة تعود إليك... وخناجر الأشباح بين يديك.", "quest");
      this.audio.sfx("questDone");
      this.currentBoss = null;
    }
    if (e.def.kind === "shadowking") {
      this.kingDefeated = true;
      this.quests.bossesDefeated.push("shadowking");
      this.currentBoss = null;
      this.audio.sfx("stingerDark");
      setTimeout(() => this.startEndings(), 2500);
    }
    // side quest: giants
    if (e.def.kind === "giant" && this.quests.side["giants"] === 1 && (this.quests.kills["giant"] ?? 0) >= 3) {
      this.quests.side["giants"] = 2;
      this.player.stats.gold += 200;
      this.giveEquipment("knightGauntlet");
      this.ui.notify("أكملت مهمة: خطر الجبال (+200 ذهب)", "quest");
      this.audio.sfx("questDone");
    }
    this.checkQuests();
  }

  private giveXp(v: number): void {
    const st = this.player.stats;
    st.xp += v;
    while (st.level < XP_LEVELS.length - 1 && st.xp >= XP_LEVELS[st.level]) {
      st.level++;
      st.skillPoints += 2;
      st.maxHp += 12;
      st.maxStamina += 5;
      st.maxMana += 4;
      st.hp = st.maxHp;
      st.mana = st.maxMana;
      this.ui.notify(`المستوى ${st.level}! +2 نقطة مهارات وتحسن القدرات`, "quest");
      this.audio.sfx("levelUp");
      this.particles.burst(this.player.pos.x, this.player.pos.y + 1.5, this.player.pos.z, 40, 0x5affc8, 5, 1);
    }
  }

  // ---------------- quests ----------------

  private checkQuests(): void {
    const q = this.quests;
    while (q.mainStage < MAIN_QUESTS.length - 1 && MAIN_QUESTS[q.mainStage].isDone(q)) {
      q.mainStage++;
      const nq = MAIN_QUESTS[q.mainStage];
      this.ui.notify(`مهمة جديدة: ${nq.name}`, "quest");
      this.audio.sfx("quest");
    }
  }

  // ---------------- main update ----------------

  private update(dt: number): void {
    this.t += dt;

    if (this.state === "title" || this.state === "ending") return;

    if (this.state === "intro") {
      this.introCamT += dt;
      // orbit camera around temple
      const a = this.introCamT * 0.15;
      const cx = Math.cos(a) * 26, cz = 6 + Math.sin(a) * 26;
      this.camera.position.set(cx, this.world.height(cx, cz) + 9 + Math.sin(this.introCamT * 0.3), cz);
      this.camera.lookAt(0, this.world.height(0, 6) + 2, 6);
      this.world.update(dt, 0, 6, this.t);
      this.particles.update(dt);
      // skip if player moves
      if (Math.abs(this.input.moveX) > 0.2 || Math.abs(this.input.moveZ) > 0.2) this.endIntro();
      return;
    }

    if (this.state === "play" && this.isOverlayOpen()) {
      // world keeps breathing behind menus, but gameplay is frozen
      this.world.update(dt * 0.2, this.player.pos.x, this.player.pos.z, this.t);
      this.particles.update(dt);
      this.dmgNum.update(dt);
      return;
    }

    if (this.state === "dead") {
      this.deadT += dt;
      this.world.update(dt, this.player.pos.x, this.player.pos.z, this.t);
      this.player.update(dt, [], this.camera);
      this.particles.update(dt);
      this.dmgNum.update(dt);
      return;
    }

    // ======= full play update =======
    this.playTime += dt;

    // hit-stop: freeze world briefly on heavy hits
    if (this.player.hitStop > 0) {
      this.player.hitStop -= dt;
      return;
    }

    this.world.update(dt, this.player.pos.x, this.player.pos.z, this.t);

    // enemies (skip if player cloaked? no — they keep last known position)
    this.spawner.update(dt, this.player, this.enemyEvents, this.t, this.particles);

    // player
    const enemyTargets = this.spawner.enemies.filter((e) => e.alive).map((e) => ({ pos: e.pos, alive: e.alive, radius: e.radius }));
    this.player.update(dt, enemyTargets, this.camera);
    if (this.player.lockTarget) {
      const lt = this.spawner.enemies.find((e) => e.pos === this.player.lockTarget!.pos);
      if (lt) { /* fine */ } else this.player.lockTarget = null;
    }

    // weapon hotkeys 1-6
    for (let i = 0; i < 6; i++) {
      if (this.input.consumeAction("Digit" + (i + 1))) {
        const w = this.player.ownedWeapons[i];
        if (w && w !== this.player.currentWeapon) {
          this.player.equipWeapon(w);
          this.audio.sfx("ui");
          this.ui.notify(WEAPONS[w].name, "info");
        }
      }
    }

    // apply player melee hits
    if (this.player.activeHit) {
      const hit = this.player.activeHit;
      const bow = this.player.currentWeapon === "bow";
      if (bow && !this.player.bowFired) {
        // bow: fire arrows instead of melee
        this.player.bowFired = true;
        this.player.activeHit = null;
        const dir = new THREE.Vector3(Math.sin(this.player.yaw), 0.02, Math.cos(this.player.yaw));
        if (this.player.lockTarget) dir.subVectors(this.player.lockTarget.pos, this.player.pos).setY(0.1).normalize();
        const n = this.player.heavyAttack ? 5 : 1;
        for (let i = 0; i < n; i++) {
          const spread = n > 1 ? (i - 2) * 0.09 : 0;
          const d2 = dir.clone().applyAxisAngle(new THREE.Vector3(0, 1, 0), spread);
          this.projectiles.fire(this.player.pos.x, this.player.pos.y + 1.5, this.player.pos.z, d2, this.player.atkDmg * (this.player.heavyAttack ? WEAPONS.bow.heavyMult : 1) / n, 0x9fff8a, 34, "player");
        }
        this.audio.sfx("swing");
      } else if (!bow) {
        let hitAny = false;
        for (const e of this.spawner.enemies) {
          if (!e.alive || hit.hitSet!.has(e.id)) continue;
          if (hitOverlap(hit, e.pos.x, e.pos.y + 1.1, e.pos.z, e.radius + 0.35)) {
            hit.hitSet!.add(e.id);
            hitAny = true;
            const dmg = hit.dmg;
            e.damage(dmg, this.player, this.particles, this.dmgNum, this.audio, hit.knockback);
            this.player.hitStop = this.player.heavyAttack ? 0.11 : 0.045;
            this.shake.add(this.player.heavyAttack ? 0.3 : 0.12);
            this.audio.sfx(this.player.heavyAttack ? "hitHeavy" : "hit");
            // weapon special on heavy
            if (this.player.heavyAttack) this.weaponSpecial(e);
          }
        }
        void hitAny;
      }
    }

    // wave ability (light)
    if (this.player.pendingWave) {
      const w = this.player.pendingWave;
      this.player.pendingWave = null;
      this.waveState = {
        x: this.player.pos.x, z: this.player.pos.z,
        dirX: Math.sin(this.player.yaw), dirZ: Math.cos(this.player.yaw),
        traveled: 0, dmg: w.dmg,
      };
      this.audio.sfx("magic");
    }
    if (this.waveState) {
      const w = this.waveState;
      const step = 26 * dt;
      w.x += w.dirX * step; w.z += w.dirZ * step;
      w.traveled += step;
      this.particles.burst(w.x, this.player.pos.y + 1.2, w.z, 4, 0xffd76a, 2, 0.3, 0);
      for (const e of this.spawner.enemies) {
        if (!e.alive || e._waveHit) continue;
        if (dist2(w.x, w.z, e.pos.x, e.pos.z) < 2.4) {
          e._waveHit = true;
          e.damage(w.dmg, this.player, this.particles, this.dmgNum, this.audio, 5);
        }
      }
      if (w.traveled > 14) {
        this.waveState = null;
        for (const e of this.spawner.enemies) e._waveHit = false;
      }
    }

    // burst AoE (shadow)
    if (this.player.pendingAoE) {
      const a = this.player.pendingAoE;
      this.player.pendingAoE = null;
      this.particles.burst(this.player.pos.x, this.player.pos.y + 1, this.player.pos.z, 60, a.color, 8, 0.8);
      this.audio.sfx("hitHeavy");
      this.shake.add(0.4);
      for (const e of this.spawner.enemies) {
        if (!e.alive) continue;
        if (dist2(e.pos.x, e.pos.z, this.player.pos.x, this.player.pos.z) < a.r) {
          e.damage(a.dmg, this.player, this.particles, this.dmgNum, this.audio, 7);
        }
      }
    }

    // clone summon
    if (this.player.pendingCloneLvl > 0) {
      const lvl = this.player.pendingCloneLvl;
      this.player.pendingCloneLvl = 0;
      const parts = buildHumanoid({ armorColor: 0x15101f, clothColor: 0x0f0c18, skinColor: 0x2a2440, eyeColor: 0xa040ff, scale: 1, cape: true, glowIntensity: 3 });
      (parts.root.traverse((m) => {
        const mm = m as THREE.Mesh;
        if (mm.isMesh) {
          const sm = mm.material as THREE.MeshStandardMaterial;
          if (sm) { sm.transparent = true; sm.opacity = 0.65; }
        }
      }));
      this.scene.add(parts.root);
      this.clones.push({ parts, t: 18 + lvl * 6, atkCd: 0 });
      this.ui.notify("استدعت نسخة الظل!", "info");
    }
    // update clones
    for (let i = this.clones.length - 1; i >= 0; i--) {
      const c = this.clones[i];
      c.t -= dt;
      c.atkCd -= dt;
      const off = 1.6;
      c.parts.root.position.set(this.player.pos.x - Math.sin(this.player.yaw) * off, this.player.pos.y, this.player.pos.z - Math.cos(this.player.yaw) * off);
      c.parts.root.rotation.y = this.player.yaw;
      c.parts.armR.rotation.x = Math.sin(this.t * 8) * 0.6 - 0.4;
      if (c.atkCd <= 0) {
        let best: Enemy | null = null;
        let bd = 10;
        for (const e of this.spawner.enemies) {
          if (!e.alive) continue;
          const d = dist2(e.pos.x, e.pos.z, c.parts.root.position.x, c.parts.root.position.z);
          if (d < bd) { bd = d; best = e; }
        }
        if (best) {
          c.atkCd = 1.4;
          c.parts.root.rotation.y = Math.atan2(best.pos.x - c.parts.root.position.x, best.pos.z - c.parts.root.position.z);
          best.damage(14 + this.player.skillLevel("clone") * 10, this.player, this.particles, this.dmgNum, this.audio, 2);
        } else c.atkCd = 0.3;
      }
      if (c.t <= 0) {
        this.particles.burst(c.parts.root.position.x, c.parts.root.position.y + 1, c.parts.root.position.z, 20, 0xa040ff, 4, 0.6);
        this.scene.remove(c.parts.root);
        this.clones.splice(i, 1);
      }
    }

    // projectiles
    this.projectiles.update(dt, this.player, this.spawner.enemies, this.world, this.particles, this.dmgNum, this.audio, () => this.shake.add(0.15));

    // boss triggers
    this.checkBossTriggers();

    // interactions
    this.updateInteract();

    // waystone discovery
    for (const w of this.world.waystones) {
      if (!w.discovered && dist2(w.x, w.z, this.player.pos.x, this.player.pos.z) < 8) {
        w.discovered = true;
        this.ui.notify(`اكتشفت نقطة طاقة: ${w.name}`, "quest");
        this.audio.sfx("crystal");
        this.save();
      }
    }

    // zone discovery
    const zid = this.world.zoneAt(this.player.pos.x, this.player.pos.z);
    if (!this.discoveredZones.has(zid)) {
      this.discoveredZones.add(zid);
      const name = (WORLD.ZONES as Record<string, { name: string }>)[zid].name;
      this.ui.notify(`اكتشفت منطقة: ${name}`, "quest");
      if (zid === "ice" && this.quests.side["giants"] === undefined) {
        this.quests.side["giants"] = 1;
        this.ui.notify("مهمة جانبية: خطر الجبال", "quest");
      }
      if (zid === "castle") this.audio.sfx("stingerDark");
    }

    // castle gate prompt
    if (zid === "castle" && this.quests.mainStage < 7 && dist2(0, -430 + 34, this.player.pos.x, this.player.pos.z) < 12) {
      // handled by interact-less barrier: gate blocks path visually
    }

    // music
    this.musicT -= dt;
    if (this.musicT <= 0) {
      this.musicT = 1.5;
      let mode: "explore" | "combat" | "boss" = "explore";
      if (this.currentBoss && this.currentBoss.alive && this.currentBoss.aggro) mode = "boss";
      else {
        for (const e of this.spawner.enemies) {
          if (e.alive && e.aggro && dist2(e.pos.x, e.pos.z, this.player.pos.x, this.player.pos.z) < 35) { mode = "combat"; break; }
        }
      }
      this.audio.setMusic(mode);
    }

    // npc idle anims
    for (const n of this.npcs) {
      const d = dist2(n.x, n.z, this.player.pos.x, this.player.pos.z);
      if (d < 60) {
        n.parts.body.position.y = Math.sin(this.t * 1.5 + n.x) * 0.02;
        if (d < 6) {
          n.parts.root.rotation.y = Math.atan2(this.player.pos.x - n.x, this.player.pos.z - n.z);
        }
        (n.parts.cape as THREE.Mesh).visible = false;
      }
    }

    // autosave
    this.autosaveT -= dt;
    if (this.autosaveT <= 0) { this.autosaveT = 25; this.save(); }

    // sweep dead enemies
    this.sweepT -= dt;
    if (this.sweepT <= 0) { this.sweepT = 8; this.spawner.sweep(); }

    // death check
    if (this.player.dead && this.state === "play") {
      this.state = "dead";
      this.deadT = 0;
      this.deaths++;
      this.audio.setMusic("none");
      if (this.currentBoss) {
        // reset boss
        const b = this.currentBoss;
        b.hp = b.maxHp;
        b.phase = 1;
        b.aggro = false;
        b.state = "return";
      }
      setTimeout(() => { if (this.state === "dead") this.ui.showDead(); }, 1800);
      this.save();
    }

    // HUD
    this.updateHUD();

    // fps degrade
    this.fpsAcc += dt; this.fpsN++;
    if (this.fpsAcc > 1) {
      const fps = this.fpsN / this.fpsAcc;
      this.fpsAcc = 0; this.fpsN = 0;
      if (fps < 45) { this.fpsLowT++; if (this.fpsLowT >= 3 && this.quality !== "low") { this.quality = this.quality === "ultra" ? "high" : this.quality === "high" ? "medium" : "low"; this.applyQuality(); this.ui.notify("خُفّضت الجودة لتحسين الأداء", "warn"); } }
      else this.fpsLowT = 0;
    }
  }

  private weaponSpecial(primary: Enemy): void {
    const kind = this.player.currentWeapon;
    const p = this.player;
    switch (kind) {
      case "dawnblade":
        this.projectiles.fire(p.pos.x, p.pos.y + 1.4, p.pos.z, new THREE.Vector3(Math.sin(p.yaw), 0.04, Math.cos(p.yaw)), p.atkDmg * 1.2, 0xffd76a, 24, "player");
        break;
      case "hammer": {
        this.audio.sfx("hitHeavy");
        this.shake.add(0.5);
        this.particles.burst(p.pos.x, p.pos.y + 0.3, p.pos.z, 40, 0x8a94ff, 7, 0.7);
        for (const e of this.spawner.enemies) {
          if (!e.alive || e === primary) continue;
          if (dist2(e.pos.x, e.pos.z, p.pos.x, p.pos.z) < 4.5) e.damage(p.atkDmg * 0.8, p, this.particles, this.dmgNum, this.audio, 8);
        }
        break;
      }
      case "daggers": {
        for (let i = 0; i < 2; i++) {
          if (primary.alive) primary.damage(p.atkDmg * 0.5, p, this.particles, this.dmgNum, this.audio, 1);
        }
        break;
      }
      case "spear":
        this.projectiles.fire(p.pos.x, p.pos.y + 1.4, p.pos.z, new THREE.Vector3(Math.sin(p.yaw), 0.02, Math.cos(p.yaw)), p.atkDmg * 1.5, 0x6adfff, 30, "player");
        break;
      case "dragon": {
        this.particles.burst(p.pos.x + Math.sin(p.yaw) * 3, p.pos.y + 1.2, p.pos.z + Math.cos(p.yaw) * 3, 50, 0xff6a2a, 6, 0.8);
        for (const e of this.spawner.enemies) {
          if (!e.alive) continue;
          const dx = e.pos.x - p.pos.x, dz = e.pos.z - p.pos.z;
          const d = Math.hypot(dx, dz);
          if (d < 6) {
            const dot = (dx / d) * Math.sin(p.yaw) + (dz / d) * Math.cos(p.yaw);
            if (dot > 0.5) e.damage(p.atkDmg * 1.1, p, this.particles, this.dmgNum, this.audio, 6);
          }
        }
        this.audio.sfx("hitHeavy");
        break;
      }
      case "bow": break; // handled by multi-arrow
    }
  }

  private checkBossTriggers(): void {
    const p = this.player.pos;
    // treant
    if (!this.treantSpawned && this.quests.mainStage === 4) {
      if (dist2(p.x, p.z, -80, 105) < 20) {
        this.treantSpawned = true;
        const b = this.spawner.spawnBoss("treant", -80, 110);
        this.currentBoss = b;
        this.audio.sfx("bossRoar");
        this.ui.notify("حارس الغابة استيقظ!", "warn");
      }
    }
    if (this.currentBoss?.def.kind === "treant" && !this.currentBoss.alive) this.currentBoss = null;
    // shadow king
    if (!this.kingSpawned && this.quests.mainStage === 7 && this.quests.bossesDefeated.includes("shadowking") === false) {
      if (dist2(p.x, p.z, 0, -440) < 24) {
        this.kingSpawned = true;
        const b = this.spawner.spawnBoss("shadowking", 0, -455);
        this.currentBoss = b;
        this.audio.sfx("bossRoar");
        this.audio.sfx("stingerDark");
        this.ui.notify("«عدتَ أخيراً... حارسُ قلبي.» — ملك الظلال", "warn");
        // open gate visual
        const gate = this.world.getCastleGate();
        gate.position.y -= 12;
        this.audio.sfx("doorOpen");
      }
    }
  }

  private updateInteract(): void {
    if (this.interactDirty) { this.interactDirty = false; }
    let best: Interactable | null = null;
    let bd = Infinity;
    for (const it of this.interactables) {
      if (!it.available()) continue;
      const d = dist2(it.x, it.z, this.player.pos.x, this.player.pos.z);
      if (d < it.r && d < bd) { bd = d; best = it; }
    }
    this.currentInteract = best;
  }

  // ---------------- HUD ----------------

  private updateHUD(): void {
    const p = this.player;
    const st = p.stats;
    const zoneId = this.world.zoneAt(p.pos.x, p.pos.z);
    const hour = ((this.world.timeOfDay - 0.25 + 1) % 1) * 24 + 6;
    const hh = Math.floor(hour % 24);
    const clock = `${this.world.night ? "🌙" : "☀️"} ${String(hh).padStart(2, "0")}:${String(Math.floor((hour % 1) * 60)).padStart(2, "0")} · ${this.weatherName()}`;
    const mainQ = MAIN_QUESTS[Math.min(this.quests.mainStage, MAIN_QUESTS.length - 1)];
    const d: HUDData = {
      hp: st.hp, maxHp: st.maxHp, stamina: st.stamina, maxStamina: st.maxStamina,
      mana: st.mana, maxMana: st.maxMana,
      level: st.level, xp: st.xp, xpNext: XP_LEVELS[Math.min(st.level, XP_LEVELS.length - 1)],
      gold: st.gold, potions: p.inventory["potion"] ?? 0,
      zoneName: (WORLD.ZONES as Record<string, { name: string }>)[zoneId].name,
      clock,
      questTitle: this.quests.mainStage < MAIN_QUESTS.length ? mainQ.name : "",
      questObj: mainQ.objective(this.quests),
      posX: p.pos.x, posZ: p.pos.z, yaw: p.yaw,
      enemies: this.spawner.enemies.filter((e) => e.alive).map((e) => ({ x: e.pos.x, z: e.pos.z, alive: e.alive, boss: e.isBoss })),
      waystones: this.world.waystones.map((w) => ({ x: w.x, z: w.z, discovered: w.discovered, name: w.name })),
      lockOn: !!p.lockTarget,
      boss: this.currentBoss && this.currentBoss.alive && this.currentBoss.aggro
        ? { name: this.currentBoss.bossName, hp: this.currentBoss.hp, maxHp: this.currentBoss.maxHp }
        : null,
      interactText: this.currentInteract ? this.currentInteract.label : (this.world.zoneAt(p.pos.x, p.pos.z) === "castle" && this.quests.mainStage < 7 && dist2(0, -400, p.pos.x, p.pos.z) < 30 ? "بوابة القلعة مغلقة — أشعل الأعمدة الثلاثة أولاً" : ""),
      skillQ: p.skillLevel("dash") > 0 ? "اندفاع الظل" : "—",
      skillV: p.skillLevel("wave") > 0 ? "موجة النور" : "—",
      cloak: p.cloakT > 0,
    };
    this.ui.updateHUD(d);
    this.ui.setHurt(p.hurtFlash * 1.6 + (p.stats.hp < p.stats.maxHp * 0.25 ? 0.25 : 0));
  }

  private weatherName(): string {
    const w = this.world.weather;
    return w === "clear" ? "صافٍ" : w === "rain" ? "ممطر" : w === "storm" ? "عاصفة رعدية" : "ضباب كثيف";
  }

  // ---------------- handlers ----------------

  private makeHandlers(): UIHandlers {
    return {
      onStart: (fresh) => this.startGame(fresh),
      onResume: () => { this.ui.hideAll(); this.ui.setScreen("none"); },
      onOpenMenu: () => { this.ui.hideAll(); this.ui.showMenu(this.menuData()); },
      onQuitToTitle: () => { this.save(); this.toTitle(); },
      onWeaponSelect: (kind) => {
        this.player.equipWeapon(kind);
        this.ui.showMenu(this.menuData(), "الأسلحة");
      },
      onUpgrade: (kind) => {
        const tier = this.player.weaponTiers[kind] ?? 1;
        if (tier >= MAX_WEAPON_TIER) return;
        const cost = upgradeCost(tier);
        const inv = this.player.inventory;
        if ((inv["crystal"] ?? 0) < cost.crystals || (inv["ore"] ?? 0) < cost.ore || this.player.stats.gold < cost.gold) return;
        inv["crystal"] -= cost.crystals;
        inv["ore"] -= cost.ore;
        this.player.stats.gold -= cost.gold;
        this.player.weaponTiers[kind] = tier + 1;
        if (this.player.currentWeapon === kind) this.player.refreshWeaponVisual();
        this.audio.sfx("anvil");
        this.particles.burst(this.player.pos.x, this.player.pos.y + 1.4, this.player.pos.z, 30, 0xffb545, 5, 0.7);
        this.ui.notify(`${WEAPONS[kind].name} وصل للمستوى ${tier + 1}!`, "quest");
        if (this.ui.isSmithOpen) this.ui.showSmith(this.menuData());
        else this.ui.showMenu(this.menuData(), "الأسلحة");
        this.save();
      },
      onBuySkill: (id) => {
        const st = this.player.stats;
        if (st.skillPoints <= 0) return;
        const def = SKILLS.find((s) => s.id === id);
        if (!def) return;
        const lvl = this.player.skills[id] ?? 0;
        if (lvl >= def.max) return;
        if (def.requires && (this.player.skills[def.requires] ?? 0) <= 0) return;
        this.player.skills[id] = lvl + 1;
        st.skillPoints -= def.cost;
        this.audio.sfx("levelUp");
        this.particles.burst(this.player.pos.x, this.player.pos.y + 1.5, this.player.pos.z, 30, id === "dash" || id === "burst" || id === "cloak" || id === "clone" ? 0xa040ff : 0xffd76a, 4, 0.8);
        this.ui.showMenu(this.menuData(), "المهارات");
        this.save();
      },
      onCraft: (what) => {
        const inv = this.player.inventory;
        if (what === "potion" && (inv["herb"] ?? 0) >= 2) {
          inv["herb"] -= 2;
          inv["potion"] = (inv["potion"] ?? 0) + 1;
          this.audio.sfx("anvil");
          this.ui.notify("صنعت جرعة حياة!", "loot");
        } else if (what === "salve" && (inv["herb"] ?? 0) >= 2 && (inv["essence"] ?? 0) >= 1) {
          inv["herb"] -= 2; inv["essence"] -= 1;
          this.player.stats.stamina = this.player.stats.maxStamina;
          this.audio.sfx("heal");
          this.ui.notify("استعدت تحملك بالكامل!", "loot");
        } else if (what === "crystal" && (inv["fang"] ?? 0) >= 3 && (inv["essence"] ?? 0) >= 1) {
          inv["fang"] -= 3; inv["essence"] -= 1;
          inv["crystal"] = (inv["crystal"] ?? 0) + 1;
          this.audio.sfx("anvil");
          this.ui.notify("صنعت بلورة نور!", "loot");
        }
        if (this.ui.isSmithOpen) this.ui.showSmith(this.menuData());
        else this.ui.showMenu(this.menuData(), this.ui.isMenuOpen ? "الحقيبة" : "الحقيبة");
      },
      onTravel: (id) => {
        const w = this.world.waystones.find((x) => x.id === id);
        if (!w) return;
        this.audio.sfx("teleport");
        this.particles.burst(this.player.pos.x, this.player.pos.y + 1, this.player.pos.z, 40, 0x5a8aff, 6, 0.8);
        this.player.pos.set(w.x + 2, this.world.height(w.x + 2, w.z + 2) + 0.5, w.z + 2);
        this.player.vel.set(0, 0, 0);
        this.particles.burst(this.player.pos.x, this.player.pos.y + 1, this.player.pos.z, 40, 0x5a8aff, 6, 0.8);
      },
      onEquip: (id) => {
        const eq = EQUIPMENT.find((e) => e.id === id);
        if (!eq) return;
        this.player.equipment[eq.slot] = id;
        this.recalcEquipment();
        this.audio.sfx("ui");
        this.ui.showMenu(this.menuData(), "المعدات");
        this.save();
      },
      onEnding: (id) => this.finishGame(id),
      onRestart: () => this.respawn(),
      onQuality: (q) => { this.quality = q; this.writeQuality(); this.applyQuality(); },
      onVolume: (v) => this.audio.setVolume(v),
      onInvertY: (v) => { /* sensitivity handled in input config at boot */ },
      onMute: () => this.audio.toggleMute(),
    };
  }

  private recalcEquipment(): void {
    const owned = (this.player as unknown as { _ownedEquip?: string[] })._ownedEquip ?? [];
    let speed = 1, def = 1;
    let hpBonus = 0, stBonus = 0, mpBonus = 0;
    for (const [slot, id] of Object.entries(this.player.equipment)) {
      void slot;
      const eq = EQUIPMENT.find((e) => e.id === id);
      if (!eq || !owned.includes(eq.id)) continue;
      if (eq.speedMult) speed *= eq.speedMult;
      if (eq.defMult) def *= eq.defMult;
      hpBonus += eq.hp ?? 0;
      stBonus += eq.stamina ?? 0;
      mpBonus += eq.mana ?? 0;
    }
    const st = this.player.stats;
    st.maxHp = 100 + (st.level - 1) * 12 + hpBonus;
    st.maxStamina = 100 + (st.level - 1) * 5 + stBonus;
    st.maxMana = 60 + (st.level - 1) * 4 + mpBonus;
    st.hp = Math.min(st.hp, st.maxHp);
    (this.player as unknown as { _speedMult?: number })._speedMult = speed;
    (this.player as unknown as { _defMult?: number })._defMult = def;
  }

  // ---------------- menu data ----------------

  private menuData(): MenuData {
    const p = this.player;
    const ownedEquip = ((p as unknown as { _ownedEquip?: string[] })._ownedEquip ?? []).map((id) => EQUIPMENT.find((e) => e.id === id)).filter(Boolean) as EquipDef[];
    return {
      level: p.stats.level,
      dmg: Math.round(p.weapon.baseDmg * (1 + (p.weaponTier - 1) * 0.35) * (1 + (p.skills["power"] ?? 0) * 0.08)),
      maxHp: p.stats.maxHp, maxStamina: p.stats.maxStamina, maxMana: p.stats.maxMana,
      skillPoints: p.stats.skillPoints, gold: p.stats.gold,
      weaponList: Object.keys(WEAPONS) as WeaponKind[],
      owned: p.ownedWeapons,
      current: p.currentWeapon,
      tiers: p.weaponTiers,
      inv: p.inventory,
      skills: p.skills,
      equipment: ownedEquip,
      equipped: p.equipment as Record<string, string>,
      posX: p.pos.x, posZ: p.pos.z,
      qs: this.quests,
      waystones: this.world.waystones.map((w) => ({ id: w.id, x: w.x, z: w.z, discovered: w.discovered, name: w.name })),
    };
  }

  // ---------------- save / load ----------------

  private save(): void {
    if (!this.player) return;
    const p = this.player;
    const d: SaveData = {
      version: 1,
      stats: p.stats,
      pos: [p.pos.x, p.pos.y, p.pos.z],
      weapon: p.currentWeapon,
      weaponTiers: p.weaponTiers,
      ownedWeapons: p.ownedWeapons,
      skills: p.skills,
      inventory: p.inventory,
      equipment: p.equipment as Record<string, string>,
      quests: this.quests,
      waystones: this.world.waystones.filter((w) => w.discovered).map((w) => w.id),
      chestsOpened: [...this.chestsOpened],
      notesRead: [...this.notesRead],
      discoveredZones: [...this.discoveredZones],
      playTime: this.playTime,
      kills: this.totalKills,
      deaths: this.deaths,
      ended: this.ended,
      endedRuns: this.endedRuns,
    };
    writeSave(d);
  }

  private load(d: SaveData): void {
    const p = this.player;
    p.stats = d.stats;
    p.pos.set(d.pos[0], d.pos[1], d.pos[2]);
    p.weaponTiers = d.weaponTiers;
    p.ownedWeapons = d.ownedWeapons;
    p.skills = d.skills;
    p.inventory = d.inventory;
    p.equipment = d.equipment;
    this.quests = d.quests;
    this.chestsOpened = new Set(d.chestsOpened);
    this.notesRead = new Set(d.notesRead);
    this.discoveredZones = new Set(d.discoveredZones);
    this.playTime = d.playTime;
    this.totalKills = d.kills;
    this.deaths = d.deaths;
    this.ended = d.ended;
    this.endedRuns = d.endedRuns;
    for (const id of d.waystones) {
      const w = this.world.waystones.find((x) => x.id === id);
      if (w) w.discovered = true;
    }
    // restore world state visuals
    if (this.quests.flags["hasSword"] === 1 && this.swordMesh) { this.scene.remove(this.swordMesh); this.swordMesh = null; }
    for (const [id, m] of this.chestMeshes) if (this.chestsOpened.has(id)) m.rotation.x = -0.25;
    for (const [id, m] of this.noteMeshes) if (this.notesRead.has(id)) m.visible = false;
    for (const pm of this.pillarMeshes) {
      if (this.quests.flags[pm.id] === 1) {
        pm.mesh.traverse((m) => {
          const mm = m as THREE.Mesh;
          if (mm.isMesh && mm.geometry.type === "SphereGeometry") {
            (mm.material as THREE.MeshStandardMaterial).emissive.set(0x5a8aff);
            (mm.material as THREE.MeshStandardMaterial).emissiveIntensity = 2.5;
          }
        });
      }
    }
    if (this.quests.bossesDefeated.includes("treant")) this.treantSpawned = true;
    if (this.quests.bossesDefeated.includes("shadowking")) this.kingSpawned = true;
    if (this.quests.flags["hasSword"] === 1) p.arm(d.weapon); else p.disarm();
    this.recalcEquipment();
    this.buildInteractables();
  }

  // ---------------- game flow ----------------

  private startGame(fresh: boolean): void {
    this.buildWorldAndEntities();
    const saved = fresh ? null : readSave();
    if (saved && !fresh) {
      this.load(saved);
      this.state = "play";
      this.ui.hideAll();
      this.audio.setMusic("explore");
      this.ui.notify("عدت إلى مملكة الظلال.", "quest");
    } else {
      if (fresh) clearSave();
      this.resetRunState();
      this.state = "intro";
      this.introCamT = 0;
      this.ui.hideAll();
      this.ui.showIntro(INTRO_TEXT, () => this.endIntro());
      this.audio.setMusic("title");
    }
  }

  private resetRunState(): void {
    this.quests = freshQuestState();
    this.chestsOpened = new Set();
    this.notesRead = new Set();
    this.discoveredZones = new Set();
    this.playTime = 0;
    this.totalKills = 0;
    this.deaths = 0;
    this.ended = null;
    const p = this.player;
    const f = freshSaveState();
    p.stats = f.stats;
    p.skills = {};
    p.inventory = { crystal: 0, darkcrystal: 0, ore: 0, herb: 2, fang: 0, essence: 0, relic: 0, potion: 1 };
    p.ownedWeapons = ["dawnblade"];
    p.weaponTiers = { dawnblade: 1 };
    p.equipment = { armor: "wornArmor" };
    (p as unknown as { _ownedEquip?: string[] })._ownedEquip = ["wornArmor"];
    p.respawn(0, 12);
    p.disarm();
    this.recalcEquipment();
    this.buildInteractables();
  }

  private endIntro(): void {
    if (this.state !== "intro") return;
    this.state = "play";
    this.ui.hideAll();
    this.audio.setMusic("explore");
    this.ui.notify("WASD للتحريك · اتبع توهج المذبح", "info");
    this.save();
  }

  private respawn(): void {
    // nearest discovered waystone
    let best: Waystone | null = this.world.waystones[0];
    let bd = Infinity;
    for (const w of this.world.waystones) {
      if (!w.discovered) continue;
      const d = dist2(w.x, w.z, this.player.pos.x, this.player.pos.z);
      if (d < bd) { bd = d; best = w; }
    }
    this.player.respawn((best?.x ?? 0) + 2, (best?.z ?? 14) + 2);
    this.state = "play";
    this.ui.hideAll();
    this.audio.setMusic("explore");
    this.ui.notify("تفيق آرين من جديد...", "info");
  }

  private toTitle(): void {
    this.state = "title";
    this.ui.hideAll();
    this.showTitle();
    this.audio.setMusic("title");
  }

  private showTitle(): void {
    const s = readSave();
    this.ui.showTitle(hasSave(), s ? { level: s.stats.level, bosses: s.quests.bossesDefeated.length, time: s.playTime } : null);
  }

  private startEndings(): void {
    this.state = "ending";
    document.exitPointerLock?.();
    const canShadow = (this.player.skills["cloak"] ?? 0) >= 1 && (this.player.skills["burst"] ?? 0) >= 2;
    this.ui.showEndings((id) => this.finishGame(id), canShadow);
  }

  private finishGame(id: string): void {
    this.ended = id;
    this.endedRuns++;
    this.quests.choices["ending"] = id;
    this.save();
    const end = ENDINGS_LIST.find((x) => x.id === id) ?? ENDINGS_LIST[2];
    this.audio.setMusic("title");
    this.ui.showEndingText(end, this.endingStats(), () => this.toTitle());
  }

  private endingStats(): string {
    return `المستوى ${this.player.stats.level} · قتل ${this.totalKills} · أزمنة ${this.deaths === 0 ? "بلا موت — إنجاز نادر" : this.deaths + " موتات"} · وقت اللعب ${Math.floor(this.playTime / 60)} دقيقة`;
  }

  // ---------------- quality ----------------

  private readQuality(): void {
    try {
      const q = localStorage.getItem("kos.quality");
      if (q === "low" || q === "medium" || q === "high" || q === "ultra") this.quality = q;
    } catch { /* default */ }
  }
  private writeQuality(): void {
    try { localStorage.setItem("kos.quality", this.quality); } catch { /* ignore */ }
  }
  private applyQuality(): void {
    const dpr = window.devicePixelRatio || 1;
    const pr = this.quality === "low" ? 0.7 : this.quality === "medium" ? 1 : this.quality === "high" ? Math.min(dpr, 1.5) : Math.min(dpr, 2);
    this.renderer.setPixelRatio(pr);
    if (this.particles) this.particles.quality = this.quality === "low" ? 0.4 : this.quality === "medium" ? 0.7 : 1;
    if (this.world) {
      this.world.sun.castShadow = this.quality !== "low";
      this.world.sun.shadow.mapSize.set(this.quality === "ultra" ? 4096 : 2048, this.quality === "ultra" ? 4096 : 2048);
      this.world.sun.shadow.map?.dispose();
      (this.world.sun.shadow.map as unknown as null) = null;
    }
    this.renderer.setSize(window.innerWidth, window.innerHeight, false);
  }

  // ---------------- render ----------------

  private render(): void {
    // camera shake
    if (this.state === "play") {
      const o = this.shake.offset(this.t);
      this.camera.position.x += o.x;
      this.camera.position.y += o.y;
      this.camera.rotation.z += o.rot;
    }
    this.shake.update(1 / 60);
    this.particles?.update(0); // noop guard
    this.dmgNum?.update(1 / 60);
    this.renderer.render(this.scene, this.camera);
  }

  // gamepad polling (basic)
  private pollGamepad(): void {
    const gp = navigator.getGamepads?.()[0];
    if (!gp || this.state !== "play" || this.isOverlayOpen()) return;
    const dz = (v: number) => (Math.abs(v) < 0.18 ? 0 : v);
    this.input.moveX = dz(gp.axes[0] ?? 0);
    this.input.moveZ = -dz(gp.axes[1] ?? 0);
    this.input.yawDelta -= dz(gp.axes[2] ?? 0) * 0.04;
    this.input.pitchDelta += -dz(gp.axes[3] ?? 0) * 0.03;
    const btn = (i: number) => gp.buttons[i]?.pressed;
    if (btn(0)) this.input.actions.add("Space");         // A jump
    if (btn(2)) this.input.actions.add("MouseLeft");     // X attack
    if (btn(1)) this.input.actions.add("ShiftLeft");     // B dodge
    if (btn(3)) this.input.actions.add("KeyF");          // Y heavy
    if (btn(4)) this.player.notifyMouseRight(); else this.player.notifyMouseRightUp();
    if (btn(5)) this.input.actions.add("KeyQ");
    if (btn(9)) this.handleEscape();                     // start
    if (btn(8)) this.input.actions.add("KeyE");          // select
  }

  start(): void {
    this.buildWorldAndEntities();
    this.showTitle();
    this.audio.setMusic("title");
    this.loop.start();
    // gamepad + probe
    const gpTimer = setInterval(() => this.pollGamepad(), 50);
    this.disposers.push(() => clearInterval(gpTimer));
    const tick = () => { if (this.state !== "title") { window.__GAME_READY__ = true; return; } requestAnimationFrame(tick); };
    requestAnimationFrame(tick);
    window.__gameProbe = () => ({ x: this.player?.pos.x ?? 0, y: this.player?.pos.y ?? 0, z: this.player?.pos.z ?? 0 });
  }

  dispose(): void {
    this.save();
    this.loop?.stop();
    for (const d of this.disposers) d();
    this.input.dispose();
    this.audio.dispose();
    this.renderer.dispose();
    window.__gameProbe = undefined;
    window.__GAME_READY__ = false;
  }
}

// ---------------- module contract ----------------

let game: Game | null = null;

export function startGame(canvas: HTMLCanvasElement): void {
  stopGame();
  game = new Game(canvas);
  game.start();
}

export function stopGame(): void {
  game?.dispose();
  game = null;
}
