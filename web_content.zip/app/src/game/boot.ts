import { AudioSystem } from "./audio";
import { GameLoop } from "./engine";
import { ChaosGame } from "./game";
import { Input } from "./input";
import { GAME } from "./config";
import { UPGRADES } from "./upgrades";
import type { GameState, HudData, UpgradeId } from "./types";
import type { UpgradeDef } from "./upgrades";

declare global {
  interface Window {
    __gameProbe?: () => { x: number; y: number; z: number };
    __GAME_READY__?: boolean;
    __chaosTest?: {
      start: () => void; level: () => void; busy: () => void; boss: () => void;
      victory: () => void; gameover: () => void; snapshot: () => Record<string, number | string>;
    };
  }
}

let session: { dispose: () => void } | null = null;
const arabicNumber = (value: number): string => Math.round(value).toLocaleString("ar-EG");

export function startGame(canvas: HTMLCanvasElement): void {
  stopGame();
  const ctx = canvas.getContext("2d", { alpha: false });
  if (!ctx) throw new Error("Canvas 2D is unavailable");
  const input = new Input(canvas);
  const audio = new AudioSystem();
  let game: ChaosGame;
  let toastTimer = 0;

  const byId = <T extends HTMLElement = HTMLElement>(id: string): T => document.getElementById(id) as T;
  const screens: Record<string, HTMLElement> = {
    title: byId("screen-title"), levelup: byId("screen-level"), paused: byId("screen-pause"),
    end: byId("screen-end"),
  };

  const showState = (state: GameState): void => {
    document.body.dataset.state = state;
    screens.title.classList.toggle("is-hidden", state !== "title");
    screens.levelup.classList.toggle("is-hidden", state !== "levelup");
    screens.paused.classList.toggle("is-hidden", state !== "paused");
    screens.end.classList.toggle("is-hidden", state !== "gameover" && state !== "victory");
    byId("hud").classList.toggle("is-hidden", state === "title");
    if (state !== "playing") { window.clearTimeout(toastTimer); byId("toast").classList.add("is-hidden"); }
    if (state === "title") byId("best-score").textContent = arabicNumber(game.getBestScore());
    if (state === "gameover" || state === "victory") {
      const victory = state === "victory";
      byId("end-eyebrow").textContent = victory ? "تم تطهير القطاع بالكامل" : "انتهت المحاولة";
      byId("end-title").textContent = victory ? "روّضت الفوضى" : "سقطت النواة";
      byId("end-description").textContent = victory ? "تحطّم المدمّر الأعظم، وأصبحت قوتك خارج كل المقاييس." : "الفوضى ابتلعتك هذه المرة. جرّب مزيج ترقيات مختلفًا.";
      byId("end-score").textContent = arabicNumber(game.score);
      byId("end-kills").textContent = arabicNumber(game.kills);
      byId("end-level").textContent = arabicNumber(game.player.level);
      byId("screen-end").querySelector(".end-panel")?.classList.toggle("victory", victory);
    }
  };

  const updateHud = (hud: HudData): void => {
    byId("hud-wave").textContent = `${arabicNumber(hud.wave)} / ${arabicNumber(GAME.FINAL_WAVE)}`;
    byId("hud-time").textContent = hud.wave === GAME.FINAL_WAVE ? "BOSS" : arabicNumber(Math.max(0, GAME.WAVE_DURATION - hud.waveTime));
    byId("hud-level").textContent = arabicNumber(hud.level);
    byId("hud-xp-text").textContent = `${arabicNumber(hud.xp)} / ${arabicNumber(hud.nextXp)}`;
    byId("xp-fill").style.width = `${Math.min(100, hud.xp / hud.nextXp * 100)}%`;
    byId("hud-score").textContent = arabicNumber(hud.score);
    byId("hud-hp").textContent = `${arabicNumber(hud.hp)} / ${arabicNumber(hud.maxHp)}`;
    byId("health-fill").style.width = `${Math.max(0, hud.hp / hud.maxHp * 100)}%`;
    byId("dash-fill").style.width = `${Math.max(0, 100 - hud.dash * 100)}%`;
    byId("dash-label").textContent = hud.dash <= 0 ? "الاندفاع جاهز" : "إعادة شحن الاندفاع";
    byId("boss-panel").classList.toggle("is-hidden", hud.bossMaxHp <= 0);
    if (hud.bossMaxHp > 0) byId("boss-fill").style.width = `${hud.bossHp / hud.bossMaxHp * 100}%`;
  };

  const showUpgrades = (options: UpgradeDef[], levels: Record<UpgradeId, number>): void => {
    const container = byId("upgrade-options");
    container.replaceChildren();
    options.forEach((upgrade, index) => {
      const button = document.createElement("button");
      button.className = "upgrade-card";
      button.style.setProperty("--card-color", upgrade.color);
      button.setAttribute("aria-label", `${upgrade.name}: ${upgrade.description}`);
      const number = document.createElement("span"); number.className = "upgrade-number"; number.textContent = arabicNumber(index + 1);
      const icon = document.createElement("div"); icon.className = "upgrade-icon"; icon.textContent = upgrade.icon;
      const rarity = document.createElement("div"); rarity.className = "upgrade-rarity"; rarity.textContent = "تطوير خارق";
      const title = document.createElement("h3"); title.textContent = upgrade.name;
      const description = document.createElement("p"); description.textContent = upgrade.description;
      const level = document.createElement("div"); level.className = "upgrade-level";
      level.textContent = levels[upgrade.id] ? `المستوى الحالي ${arabicNumber(levels[upgrade.id])} ← ${arabicNumber(levels[upgrade.id] + 1)}` : "قدرة جديدة كليًا";
      button.append(number, icon, rarity, title, description, level);
      button.addEventListener("click", () => game.chooseUpgrade(index), { once: true });
      container.appendChild(button);
    });
  };

  const showActiveUpgrades = (levels: Record<UpgradeId, number>): void => {
    const container = byId("active-upgrades");
    container.replaceChildren();
    for (const upgrade of UPGRADES) {
      if (!levels[upgrade.id]) continue;
      const chip = document.createElement("span"); chip.className = "upgrade-mini";
      const icon = document.createElement("b"); icon.textContent = upgrade.icon; icon.style.color = upgrade.color;
      chip.append(icon, document.createTextNode(`${upgrade.name} ${arabicNumber(levels[upgrade.id])}`));
      container.appendChild(chip);
    }
  };

  game = new ChaosGame(input, audio, {
    onState: showState,
    onUpgrades: showUpgrades,
    onHud: updateHud,
    onUpgradesChanged: showActiveUpgrades,
    onMute: (muted) => { byId("mute-button").textContent = muted ? "الصوت: مكتوم" : "الصوت: يعمل"; },
    onToast: (title, subtitle = "") => {
      window.clearTimeout(toastTimer);
      byId("toast-title").textContent = title; byId("toast-subtitle").textContent = subtitle;
      byId("toast").classList.remove("is-hidden");
      toastTimer = window.setTimeout(() => byId("toast").classList.add("is-hidden"), 2400);
    },
  });

  const resize = (): void => {
    const width = window.innerWidth, height = window.innerHeight;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = Math.floor(width * dpr); canvas.height = Math.floor(height * dpr);
    canvas.style.width = `${width}px`; canvas.style.height = `${height}px`;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    game.resize(width, height);
  };

  const onAction = (event: Event): void => {
    const target = event.target;
    if (!(target instanceof Element)) return;
    const button = target.closest<HTMLElement>("[data-action]");
    if (!button) return;
    const action = button.dataset.action;
    if (action === "start" || action === "restart") game.startRun();
    else if (action === "resume" || action === "pause") game.togglePause();
    else if (action === "title") game.toTitle();
    else if (action === "dash") game.tryDash();
    else if (action === "mute") byId("mute-button").textContent = audio.toggleMute() ? "الصوت: مكتوم" : "الصوت: يعمل";
  };

  const onVisibility = (): void => {
    if (document.hidden && game.state === "playing") game.togglePause();
  };

  const root = byId("game-root");
  root.addEventListener("click", onAction);
  window.addEventListener("resize", resize);
  document.addEventListener("visibilitychange", onVisibility);
  byId("mute-button").textContent = audio.muted ? "الصوت: مكتوم" : "الصوت: يعمل";
  resize(); showState("title"); game.pushHud();

  const loop = new GameLoop({
    update: (dt) => game.update(dt),
    render: () => { game.render(ctx); window.__GAME_READY__ = true; },
  });
  loop.start();

  window.__gameProbe = () => ({ x: game.player.x, y: 0, z: game.player.y });
  window.__chaosTest = {
    start: () => game.startRun(), level: () => game.debugLevelUp(), busy: () => game.debugBusy(), boss: () => game.debugBoss(),
    victory: () => game.debugEnd(true), gameover: () => game.debugEnd(false), snapshot: () => game.snapshot(),
  };

  session = {
    dispose: () => {
      loop.stop();
      window.clearTimeout(toastTimer);
      window.removeEventListener("resize", resize);
      document.removeEventListener("visibilitychange", onVisibility);
      root.removeEventListener("click", onAction);
      input.dispose(); audio.dispose();
      delete window.__gameProbe; delete window.__chaosTest;
      window.__GAME_READY__ = false;
      delete document.body.dataset.state;
    },
  };
}

export function stopGame(): void {
  session?.dispose();
  session = null;
}
