/**
 * boot.ts — ponto de entrada do jogo: cria o Phaser.Game sobre o <canvas> do shell,
 * injeta os controles touch (DOM) e os ganchos de verificação (__GAME_READY__ / __gameProbe__).
 *
 * Contrato com o React shell (src/pages/Home.tsx):
 *   startGame(canvas)  monta o jogo sobre o canvas existente
 *   stopGame()         desmonta tudo (jogo, botões touch, áudio)
 * Chamar startGame duas vezes é seguro: a sessão anterior é encerrada primeiro.
 */
import Phaser from "phaser";
import { VIEW, PLAYER } from "./config";
import { TitleScene } from "./scenes/TitleScene";
import { GameScene } from "./scenes/GameScene";
import { PauseScene } from "./scenes/PauseScene";
import { EndScene } from "./scenes/EndScene";
import { gameAudio } from "./audio";
import { touchState } from "./input";

declare global {
  interface Window {
    __gameProbe?: () => { x: number; y: number; z: number };
    __GAME_READY__?: boolean;
    __game?: Phaser.Game;
  }
}

let game: Phaser.Game | null = null;
let touchLayer: HTMLElement | null = null;

function bindHold(el: HTMLElement, on: () => void, off: () => void): void {
  const start = (e: Event) => {
    e.preventDefault();
    on();
  };
  const end = (e: Event) => {
    e.preventDefault();
    off();
  };
  el.addEventListener("pointerdown", start);
  el.addEventListener("pointerup", end);
  el.addEventListener("pointercancel", end);
  el.addEventListener("pointerleave", end);
  el.addEventListener("contextmenu", (e) => e.preventDefault());
}

function buildTouchControls(): HTMLElement {
  const layer = document.createElement("div");
  layer.id = "touch-layer";
  layer.setAttribute("aria-label", "Controles de toque");

  const mk = (label: string, cls: string, on: () => void, off: () => void): HTMLElement => {
    const b = document.createElement("button");
    b.className = `tbtn ${cls}`;
    b.textContent = label;
    b.setAttribute("aria-label", label);
    bindHold(b, on, off);
    layer.appendChild(b);
    return b;
  };

  mk("◀", "tbtn-left", () => (touchState.left = true), () => (touchState.left = false));
  mk("▶", "tbtn-right", () => (touchState.right = true), () => (touchState.right = false));
  mk("PULAR", "tbtn-jump", () => (touchState.jump = true), () => (touchState.jump = false));
  mk("ATQ", "tbtn-attack", () => (touchState.attack = true), () => (touchState.attack = false));
  mk("MAG", "tbtn-magic", () => (touchState.magic = true), () => (touchState.magic = false));

  const pause = document.createElement("button");
  pause.className = "tbtn tbtn-pause";
  pause.textContent = "❚❚";
  pause.setAttribute("aria-label", "Pausar");
  pause.addEventListener("click", (e) => {
    e.preventDefault();
    touchState.pause = true;
  });
  layer.appendChild(pause);

  const sound = document.createElement("button");
  sound.className = "tbtn tbtn-sound";
  sound.textContent = gameAudio.muted ? "🔇" : "🔊";
  sound.setAttribute("aria-label", "Ligar ou desligar som");
  sound.addEventListener("click", (e) => {
    e.preventDefault();
    gameAudio.unlock();
    sound.textContent = gameAudio.toggleMuted() ? "🔇" : "🔊";
  });
  layer.appendChild(sound);

  return layer;
}

export function startGame(canvas: HTMLCanvasElement): void {
  stopGame();

  window.__GAME_READY__ = false;
  touchLayer = buildTouchControls();
  canvas.parentElement?.appendChild(touchLayer);

  game = new Phaser.Game({
    title: "Crônicas do Cristal",
    type: Phaser.CANVAS,
    canvas,
    backgroundColor: "#0a0f16",
    scale: {
      mode: Phaser.Scale.FIT,
      autoCenter: Phaser.Scale.CENTER_BOTH,
      width: VIEW.WIDTH,
      height: VIEW.HEIGHT,
    },
    physics: {
      default: "arcade",
      arcade: {
        gravity: { x: 0, y: PLAYER.GRAVITY },
        debug: false,
      },
    },
    render: {
      antialias: true,
    },
    scene: [TitleScene, GameScene, PauseScene, EndScene],
    callbacks: {
      postBoot: (g: Phaser.Game) => {
        window.__game = g;
        window.__GAME_READY__ = true;
      },
    },
  });
}

export function stopGame(): void {
  if (game) {
    game.destroy(true);
    game = null;
  }
  window.__game = undefined;
  touchLayer?.remove();
  touchLayer = null;
  window.__gameProbe = undefined;
  window.__GAME_READY__ = false;
  gameAudio.dispose();
  touchState.reset();
}
