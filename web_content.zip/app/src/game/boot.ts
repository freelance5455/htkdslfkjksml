/**
 * boot.ts — Steel Courtyard FPS: bootstrap + game orchestration.
 * Owns the renderer/scene/camera, the fixed-timestep loop, the title → playing ⇄ paused →
 * gameover state machine, touch-look on the canvas, and all cross-system wiring:
 * player damage, kill feed routing, damage numbers, round resets and HUD updates.
 */

import * as THREE from "three";
import { GameLoop } from "./engine";
import { GameStateMachine } from "./state";
import { COLORS, PLAYER, QUALITY, TeamId } from "./config";
import { buildArena, Arena } from "./arena";
import { PlayerController } from "./player";
import { WeaponSystem, Shootable } from "./weapon";
import { GrenadeSystem } from "./grenade";
import { Bot, Targetable, KillEvent } from "./enemy";
import { MatchManager } from "./match";
import { MobileHUDController, HudFrameData, MinimapBlip } from "./hud";
import { GameInput } from "./input";
import { AudioSystem } from "./audio";
import { Effects } from "./effects";
import { ALLY_NAMES, BOT_NAMES, PLAYER_NAME } from "./types";
import { BOTS, GRENADE, MATCH, WEAPONS } from "./config";

declare global {
  interface Window {
    __gameProbe?: () => { x: number; y: number; z: number };
    __GAME_READY__?: boolean;
  }
}

let session: { dispose: () => void } | null = null;

export function startGame(canvas: HTMLCanvasElement): void {
  stopGame();

  // ---------------- renderer / scene / camera ----------------
  const renderer = new THREE.WebGLRenderer({ canvas, preserveDrawingBuffer: true, antialias: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.setSize(window.innerWidth, window.innerHeight, false);
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.28;

  const scene = new THREE.Scene();
  scene.background = new THREE.Color(COLORS.background);
  scene.fog = new THREE.Fog(COLORS.fog, 38, 110);

  const camera = new THREE.PerspectiveCamera(72, window.innerWidth / window.innerHeight, 0.05, 220);
  const BASE_FOV = 72;
  // soft fill so the first-person viewmodel never reads as a black silhouette
  const fill = new THREE.PointLight(0xffe8cc, 0.85, 2.2, 1.5);
  fill.position.set(0.15, -0.05, -0.25);
  camera.add(fill);

  // ---------------- world + systems ----------------
  const arena: Arena = buildArena();
  scene.add(arena.group);

  const audio = new AudioSystem();
  const effects = new Effects(scene, QUALITY.PARTICLES_HIGH);
  const input = new GameInput(canvas);
  const overlay = document.getElementById("ui-overlay")!;
  const hud = new MobileHUDController(overlay, input);
  hud.setWallData(arena.colliders, arena.wallHalf);
  hud.refreshMute(audio.muted);

  const player = new PlayerController(arena.colliders);
  player.respawn(arena.spawns.blue[0].clone(), 0);

  // player as an AI targetable
  const playerProxy: Targetable = {
    name: PLAYER_NAME,
    team: 0,
    get alive() { return player.alive; },
    pos: player.pos,
    get height() { return player.crouched ? 1.15 : 1.78; },
    get headY() { return player.eyeHeight; },
    radius: PLAYER.RADIUS,
  };

  const state = new GameStateMachine();

  // ---------------- bots ----------------
  const bots: Bot[] = [];
  const killFeedRouter = (ev: KillEvent) => match.onKill(ev);
  const botHooks = {
    colliders: arena.colliders,
    waypoints: arena.waypoints,
    effects,
    audio,
    getCombatants: (): Targetable[] => [playerProxy, ...bots],
    getPlayer: (): Targetable => playerProxy,
    onKill: killFeedRouter,
    onPlayerHit: (dmg: number, botName: string) => damagePlayer(dmg, botName, 1, "AR-77 VANDAL"),
    distanceToPlayer: (pos: THREE.Vector3) => pos.distanceTo(player.pos),
  };
  for (let i = 0; i < BOTS.COUNT_RED; i++) bots.push(new Bot(BOT_NAMES[i], 1, botHooks));
  for (let i = 0; i < BOTS.COUNT_BLUE; i++) bots.push(new Bot(ALLY_NAMES[i], 0, botHooks));
  for (const b of bots) scene.add(b.object);

  // ---------------- match manager ----------------
  const match = new MatchManager({
    resetRound,
    onKillFeed: (ev) => hud.addKill(ev),
    onScores: () => {},
    onBanner: (t, s, tone, sec) => hud.showBanner(t, s, tone, sec),
    onCountdownTick: (n) => audio.sfx("countdown"),
    onMatchEnd: (winner) => endMatch(winner),
  });
  match.redAliveFn = () => bots.reduce((n, b) => n + (b.team === 1 && b.alive ? 1 : 0), 0);

  // ---------------- weapons & grenades ----------------
  const _proj = new THREE.Vector3();
  function projectToScreen(pos: THREE.Vector3): { x: number; y: number } {
    _proj.copy(pos).project(camera);
    return {
      x: (_proj.x * 0.5 + 0.5) * window.innerWidth,
      y: (-_proj.y * 0.5 + 0.5) * window.innerHeight,
    };
  }

  const weapons = new WeaponSystem(
    camera, scene, arena.colliders, effects, audio,
    () => bots as Shootable[],
    (target, dmg, headshot) => {
      const bot = target as unknown as Bot;
      const chest = new THREE.Vector3(bot.pos.x, bot.pos.y + bot.height * 0.62, bot.pos.z);
      const killed = bot.takeDamage(dmg, PLAYER_NAME, 0, weapons.weaponName(), playerProxy, headshot);
      const p = projectToScreen(chest);
      hud.damageNumber(p.x, p.y, dmg, killed, headshot);
      return killed;
    },
    (killed, headshot) => {
      hud.hitmark(killed, headshot);
      audio.sfx(killed ? "kill" : "hit");
    },
  );

  const grenades = new GrenadeSystem(
    scene, arena.colliders, effects, audio,
    () => bots as Shootable[],
    () => (player.alive ? new THREE.Vector3(player.pos.x, player.eyeHeight, player.pos.z) : null),
    (dmg, attacker, attackerTeam) => damagePlayer(dmg, attacker, attackerTeam, "M67 FRAG"),
    (bot, dmg, attacker, attackerTeam) => {
      (bot as unknown as Bot).takeDamage(dmg, attacker, attackerTeam, "M67 FRAG");
    },
  );

  function damagePlayer(dmg: number, attacker: string, attackerTeam: TeamId, weapon: string): void {
    if (!player.alive || !match.inFight) return;
    const ev = player.damage(dmg, attacker, attackerTeam, weapon);
    if (!ev) return;
    hud.damageFlash(dmg / 60);
    audio.sfx("hurt");
    if (!player.alive) {
      match.onKill({ attacker, attackerTeam, victim: PLAYER_NAME, victimTeam: 0, weapon, headshot: false });
    }
  }

  // ---------------- round reset / match end ----------------
  function resetRound(): void {
    player.respawn(arena.spawns.blue[0].clone(), 0);
    weapons.resetAmmo();
    grenades.reset();
    let ri = 0, bi = 0;
    for (const b of bots) {
      if (b.team === 1) {
        b.spawnAt(arena.spawns.red[ri % arena.spawns.red.length].clone(), Math.PI);
        ri++;
      } else {
        b.spawnAt(arena.spawns.blue[(bi + 1) % arena.spawns.blue.length].clone(), 0);
        bi++;
      }
    }
  }

  function endMatch(winner: TeamId): void {
    const win = winner === 0;
    audio.sfx(win ? "matchWin" : "matchLose");
    audio.stopMusic();
    state.transition("gameover");
    input.exitPointerLock();
    hud.setHudVisible(false);
    hud.showScreen("gameover", {
      title: win ? "VICTORY" : "DEFEAT",
      sub: `FINAL SCORE  ${match.scores[0]} — ${match.scores[1]}`,
    });
    (hud as unknown as { _lastWin?: boolean })._lastWin = win;
    applyGameoverTone();
  }

  function applyGameoverTone(): void {
    const win = (hud as unknown as { _lastWin?: boolean })._lastWin;
    const scr = document.querySelector(".gameover-screen");
    if (scr) { scr.classList.toggle("win", !!win); scr.classList.toggle("lose", !win); }
  }

  // ---------------- state transitions / HUD wiring ----------------
  hud.onDeploy = () => {
    if (!state.is("title")) return;
    audio.startMusic();
    state.transition("playing");
    hud.showScreen(null);
    hud.setHudVisible(true);
    match.startMatch();
    if (isDesktop()) input.requestPointerLock();
  };
  hud.onRestart = () => {
    if (!state.is("gameover", "paused")) return;
    state.transition("playing");
    hud.showScreen(null);
    hud.setHudVisible(true);
    match.startMatch();
  };
  hud.onPause = () => {
    if (!state.is("playing")) return;
    state.transition("paused");
    input.exitPointerLock();
    hud.showScreen("pause");
    audio.sfx("ui");
  };
  hud.onResume = () => {
    if (!state.is("paused")) return;
    state.transition("playing");
    hud.showScreen(null);
    if (isDesktop()) input.requestPointerLock();
  };
  hud.onMuteToggle = () => audio.toggleMute();

  function isDesktop(): boolean {
    return window.matchMedia("(pointer: fine)").matches;
  }

  state.onChange((s) => {
    if (s === "title") hud.showScreen("title");
  });
  hud.showScreen("title");

  // desktop: click the canvas to (re)acquire pointer lock while playing
  canvas.addEventListener("pointerdown", () => {
    if (state.is("playing") && isDesktop()) input.requestPointerLock();
  });

  // touch-look: drag on the open canvas rotates the camera
  let lookId: number | null = null;
  let lookX = 0, lookY = 0;
  canvas.addEventListener("pointerdown", (e) => {
    if (lookId !== null) return;
    lookId = e.pointerId;
    lookX = e.clientX;
    lookY = e.clientY;
  });
  canvas.addEventListener("pointermove", (e) => {
    if (e.pointerId !== lookId) return;
    input.feedLook(e.clientX - lookX, e.clientY - lookY);
    lookX = e.clientX;
    lookY = e.clientY;
  });
  const lookEnd = (e: PointerEvent) => { if (e.pointerId === lookId) lookId = null; };
  canvas.addEventListener("pointerup", lookEnd);
  canvas.addEventListener("pointercancel", lookEnd);

  // ---------------- per-frame helpers ----------------
  const blips: MinimapBlip[] = [];
  let camBobPhase = 0;
  const hudData: HudFrameData = {
    hp: 100, maxHp: PLAYER.HP, plates: 2, plateProgress: -1,
    mag: 30, reserve: 120, weaponName: "", reloading: false, reloadProgress: 0,
    grenades: GRENADE.COUNT, grenadeCooldown: 1, spread: 0.02, adsAmount: 0,
    crouched: false, scores: [0, 0], round: 1,
  };

  function updateHudData(): void {
    hudData.hp = player.hp;
    hudData.plates = player.plates;
    hudData.plateProgress = player.plateTimer > 0 ? 1 - player.plateTimer / PLAYER.PLATE_TIME : -1;
    hudData.mag = weapons.magAmmo();
    hudData.reserve = weapons.reserveAmmo();
    hudData.weaponName = weapons.weaponName();
    hudData.reloading = weapons.reloading;
    hudData.reloadProgress = weapons.reloadProgress;
    hudData.grenades = grenades.count;
    hudData.grenadeCooldown = 1 - grenades.cooldown / GRENADE.COOLDOWN;
    hudData.spread = weapons.spread(player);
    hudData.adsAmount = weapons.adsAmount;
    hudData.crouched = player.crouched;
    hudData.scores = match.scores;
    hudData.round = match.roundNumber;
  }

  function buildBlips(): void {
    blips.length = 0;
    blips.push({ x: player.pos.x, z: player.pos.z, team: 0, isPlayer: true, yaw: player.yaw });
    for (const b of bots) {
      if (!b.alive) continue;
      blips.push({ x: b.pos.x, z: b.pos.z, team: b.team, isPlayer: false, yaw: 0 });
    }
  }

  // ---------------- main loop ----------------
  const loop = new GameLoop({
    update: (dt) => {
      // global keys
      if (state.is("title") && (input.takeAction("Space") || input.takeAction("Enter"))) {
        hud.onDeploy();
      } else if (state.is("playing") && input.takeAction("Escape")) {
        hud.onPause();
      } else if (state.is("paused") && (input.takeAction("Escape") || input.takeAction("Space"))) {
        hud.onResume();
      } else if (state.is("gameover") && input.takeAction("Space")) {
        hud.onRestart();
      }

      if (state.is("playing")) {
        match.update(dt);
        const inFight = match.inFight;

        player.update(dt, input, audio, true);
        weapons.update(dt, input, player, inFight);

        // grenade throw
        if (inFight && (input.takeAction("grenade") || input.takeAction("KeyG"))) {
          const dir = new THREE.Vector3();
          camera.getWorldDirection(dir);
          const origin = new THREE.Vector3(player.pos.x, player.eyeHeight, player.pos.z);
          if (grenades.throwGrenade(origin, dir, PLAYER_NAME, 0)) {
            // thrown — the parabolic sim + fuse take over in GrenadeSystem
          }
        }
        grenades.update(dt);

        // bots fight only during the fight phase
        if (inFight) {
          for (const b of bots) b.update(dt);
        }

        effects.update(dt);
      }
    },
    render: (alpha) => {
      void alpha;
      const playing = state.is("playing");
      const paused = state.is("paused");

      // camera pose + bob
      const speed = player.speedRatio;
      camBobPhase += GameLoop.STEP * (4 + speed * 6);
      const bobY = Math.abs(Math.cos(camBobPhase)) * 0.028 * speed * (player.crouched ? 0.5 : 1);
      const bobX = Math.sin(camBobPhase) * 0.014 * speed;
      player.applyToCamera(camera, bobY, bobX);
      camera.rotation.x += weapons.recoilPitch;

      // ADS fov
      const targetFov = THREE.MathUtils.lerp(BASE_FOV, WEAPONS[weapons.current].adsFov, weapons.adsAmount);
      if (Math.abs(camera.fov - targetFov) > 0.05) {
        camera.fov = THREE.MathUtils.damp(camera.fov, targetFov, 16, GameLoop.STEP);
        camera.updateProjectionMatrix();
      }

      // viewmodel visible only in first person while playing (and not dead)
      weapons.setVisible(playing && player.alive);

      renderer.render(scene, camera);
      window.__GAME_READY__ = true;

      if (playing || paused) {
        updateHudData();
        buildBlips();
        hud.update(GameLoop.STEP, hudData, blips, player.hp);
      }
    },
  });
  loop.start();

  const onResize = () => {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight, false);
  };
  window.addEventListener("resize", onResize);

  window.__gameProbe = () => ({ x: player.pos.x, y: player.pos.y, z: player.pos.z });
  // verification hook: live match state (used by the automated self-checks)
  (window as unknown as { __matchInfo?: () => Record<string, unknown> }).__matchInfo = () => ({
    phase: match.phase,
    round: match.roundNumber,
    scores: [...match.scores],
    playerHp: Math.round(player.hp),
    playerAlive: player.alive,
    redAlive: match.redAliveFn(),
    blueAlive: bots.reduce((n, b) => n + (b.team === 0 && b.alive ? 1 : 0), 0),
    mag: weapons.magAmmo(),
    grenades: grenades.count,
  });

  session = {
    dispose: () => {
      loop.stop();
      window.removeEventListener("resize", onResize);
      input.dispose();
      audio.dispose();
      hud.dispose();
      weapons.dispose();
      renderer.dispose();
      delete window.__gameProbe;
      window.__GAME_READY__ = false;
    },
  };
}

export function stopGame(): void {
  session?.dispose();
  session = null;
}
