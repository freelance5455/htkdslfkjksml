import * as THREE from "three";
import { GameLoop } from "./engine";
import { Input } from "./input";
import { AudioSystem } from "./audio";
import { GameStateMachine } from "./state";
import { storage } from "./storage";
import { loadCarModel, CarVisual, Fleet, type CarModel } from "./car";
import { World } from "./world";
import { SkidMarks } from "./skid";
import { QualityGovernor, TIERS, initialTierIndex, modeToTier, type QualityMode } from "./quality";
import { smoothstep } from "./spatial";
import { CAR_COLORS, RACES, SEASONS, SEASON_INFO, TUNING, getRegion, type RaceDef, type Season, type RegionId } from "./content";

interface SaveData {
  credits: number;
  influence: number;
  races: number;
  best: Record<string, number>;
}

interface Rival {
  visual: CarVisual;
  progress: number;
  pace: number;
  lane: number;
  finished: boolean;
  x: number; y: number; z: number; heading: number;
  color: number;
}

interface TrafficCar {
  curve: THREE.CatmullRomCurve3 | null;
  length: number;
  t: number;
  dir: 1 | -1;
  speed: number;
  color: number;
  x: number; y: number; z: number; heading: number;
}

interface ToastState { text: string; time: number }

declare global {
  interface Window {
    __gameProbe?: () => { x: number; y: number; z: number };
    __GAME_READY__?: boolean;
    __gameMetrics?: () => Record<string, number | string>;
    __apexTest?: {
      startRace: (id: string) => void;
      finish: () => void;
      dnf: () => void;
      season: (season: Season) => void;
    };
  }
}

const QUALITY_MODES: QualityMode[] = ["AUTO", "HIGH", "BALANCED", "ECO"];
const TRAFFIC_COLORS = [0xd9d9d6, 0x2f3b4a, 0xb3261e, 0xe0b32e, 0x3b7a57, 0x5d6b78, 0xf0f0ee, 0x7d3c98];
const TIME_PRESETS = [7.2, 12.5, 17.9, 22.5];
const WARM = new THREE.Color(0xff9b5c);

let session: RacingGame | null = null;

export function startGame(canvas: HTMLCanvasElement): void {
  stopGame();
  session = new RacingGame(canvas);
}

export function stopGame(): void {
  session?.dispose();
  session = null;
}

class RacingGame {
  private renderer: THREE.WebGLRenderer;
  private scene = new THREE.Scene();
  private camera = new THREE.PerspectiveCamera(64, 1, 0.6, 900);
  private input: Input;
  private audio = new AudioSystem();
  private machine = new GameStateMachine();
  private world: World;
  private loop: GameLoop;
  private governor: QualityGovernor;
  private fleet = new Fleet(12);
  private skid = new SkidMarks(150, 0.15);
  private model: CarModel | null = null;
  private player: CarVisual | null = null;
  private rivals: Rival[] = [];
  private traffic: TrafficCar[] = [];
  private curveList: THREE.CatmullRomCurve3[] = [];
  private disposed = false;
  private verify: boolean;

  // vehicle state
  private position = new THREE.Vector3(0, 0, 180);
  private prevPos = new THREE.Vector3(0, 0, 180);
  private velocity = new THREE.Vector3();
  private heading = 0;
  private prevHeading = 0;
  private alpha = 1;
  private angularVel = 0;
  private condition = 100;
  private boost = 55;
  private driftScore = 0;
  private driftChain = 0;
  private driftIdle = 0;
  private collisionCooldown = 0;
  private waterCooldown = 0;
  private lastAccel = 0;
  private lastLateral = 0;
  private forwardSpeed = 0;
  private isBoosting = false;
  private isBraking = false;

  // effects
  private tireSmoke: THREE.Points | null = null;
  private smokePositions: Float32Array | null = null;
  private smokeLife: Float32Array | null = null;
  private smokeIdx = 0;
  private smokeLimit = 96;

  // game flow
  private mode: "free" | "race" = "free";
  private race: RaceDef | null = null;
  private checkpoint = 0;
  private countdown = 0;
  private lastCountdown = 4;
  private raceElapsed = 0;
  private finishPosition = 0;
  private nearbyRace: RaceDef | null = null;
  private loadingRegion = false;

  // atmosphere
  private timeOfDay = 16.2;
  private night = 0;
  private sun = new THREE.DirectionalLight(0xfff2d6, 2.2);
  private hemisphere = new THREE.HemisphereLight(0xcce7ff, 0x536044, 1.6);
  private sunDir = new THREE.Vector3(0, 1, 0);
  private lightDir = new THREE.Vector3(0, 1, 0);
  private dayColor = new THREE.Color();
  private nightColor = new THREE.Color();

  private save: SaveData;
  private toast: ToastState = { text: "", time: 0 };
  private cameraShake = 0;
  private cameraTarget = new THREE.Vector3();
  private cameraPosition = new THREE.Vector3(12, 8, 198);
  private viewPos = new THREE.Vector3(0, 0, 180);
  private viewHeading = 0;
  private renderPrevious = performance.now();
  private tempA = new THREE.Vector3();
  private tempB = new THREE.Vector3();
  private tempC = new THREE.Vector3();
  private hudClock = 0;
  private fps = 60;
  private frameCount = 0;
  private qualityMode: QualityMode = "AUTO";
  private showFps = false;
  private resize = () => this.onResize();
  private uiClick = (event: Event) => this.onUiClick(event);
  private visibility = () => {
    if (document.hidden && this.machine.state === "playing") this.pause();
  };
  private minimap: CanvasRenderingContext2D | null = null;
  private minimapStatic: HTMLCanvasElement | null = null;
  private domCache = new Map<string, HTMLElement | null>();

  constructor(private canvas: HTMLCanvasElement) {
    const params = new URLSearchParams(location.search);
    // The drawing buffer is only preserved for automated checks (readPixels); real players get the faster path.
    this.verify = params.has("verify") || navigator.webdriver === true;
    this.renderer = new THREE.WebGLRenderer({
      canvas,
      antialias: false,
      powerPreference: "high-performance",
      preserveDrawingBuffer: this.verify,
      alpha: false,
      stencil: false,
      depth: true,
    });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.18;
    this.renderer.shadowMap.enabled = false;

    // ---- adaptive quality ----
    const isMobile = /Android|iPhone|iPad|Mobile/i.test(navigator.userAgent) || window.innerWidth < 900;
    const nav = navigator as Navigator & { deviceMemory?: number };
    const hints = { cores: navigator.hardwareConcurrency || 4, memoryGb: nav.deviceMemory || 0, mobile: isMobile, dpr: window.devicePixelRatio || 1 };
    const savedMode = storage.get<string>("apex.quality", "AUTO");
    this.qualityMode = (QUALITY_MODES as string[]).includes(savedMode) ? (savedMode as QualityMode) : "AUTO";
    const savedTier = storage.get<number>("apex.tier", -1);
    const autoTier = Number.isInteger(savedTier) && savedTier >= 0 && savedTier < TIERS.length ? savedTier : initialTierIndex(hints);
    const maxPixelRatio = Math.min(window.devicePixelRatio || 1, isMobile ? 1.75 : 2);
    this.governor = new QualityGovernor(modeToTier(this.qualityMode, autoTier), maxPixelRatio, 30);
    this.renderer.setPixelRatio(this.governor.pixelRatio);

    // ---- lighting: one key light + one hemisphere light (cheap for Lambert/Phong on mobile) ----
    this.sun.position.set(-125, 175, 48);
    this.scene.add(this.sun, this.hemisphere, this.sun.target);

    this.world = new World(this.scene, this.governor.current);
    this.scene.add(this.fleet.group, this.skid.mesh);
    this.initTireSmoke();
    for (let i = 0; i < 8; i++) {
      this.traffic.push({ curve: null, length: 1, t: 0, dir: 1, speed: 14, color: TRAFFIC_COLORS[i % TRAFFIC_COLORS.length], x: 0, y: 0, z: 0, heading: 0 });
    }
    this.input = new Input(canvas);
    this.save = this.loadSave();
    this.minimap = document.querySelector<HTMLCanvasElement>("#minimap")?.getContext("2d") ?? null;
    this.bindUi();
    this.onResize();
    window.addEventListener("resize", this.resize);
    document.addEventListener("visibilitychange", this.visibility);
    document.querySelector("#ui-overlay")?.addEventListener("click", this.uiClick);
    this.updatePersistentUi();
    this.showScreen("title");
    this.loop = new GameLoop({ update: (dt) => this.update(dt), render: (alpha, frameMs) => this.render(alpha, frameMs) });
    this.afterRegionLoaded();
    window.__gameProbe = () => ({ x: this.position.x, y: this.position.y, z: this.position.z });
    window.__gameMetrics = () => ({
      fps: Math.round(this.fps),
      drawCalls: this.renderer.info.render.calls,
      triangles: this.renderer.info.render.triangles,
      state: this.machine.state,
      mode: this.mode,
      season: this.world.season,
      region: this.world.region.id,
      tier: this.governor.current.name,
      pixelRatio: Math.round(this.governor.pixelRatio * 100) / 100,
      checkpoint: this.checkpoint,
      speed: Math.round(this.velocity.length() * 3.6),
    });
    if (this.verify) {
      window.__apexTest = {
        startRace: (id) => { const race = RACES.find((item) => item.id === id); if (race) this.startRace(race); },
        finish: () => { if (this.race) this.finishRace(false); },
        dnf: () => { if (this.race) this.finishRace(true); },
        season: (season) => this.setSeason(season),
      };
    }
    loadCarModel().then((model) => {
      if (this.disposed) return;
      this.model = model;
      this.player = new CarVisual(model, CAR_COLORS[0], true);
      this.scene.add(this.player.group);
      for (let i = 0; i < 3; i++) {
        const visual = new CarVisual(model, CAR_COLORS[i + 1]);
        visual.group.visible = false;
        this.scene.add(visual.group);
        this.rivals.push({ visual, progress: 0, pace: 0, lane: (i - 1) * 2.4, finished: false, x: 0, y: 0, z: 0, heading: 0, color: CAR_COLORS[i + 1] });
      }
      this.position.y = this.world.heightAt(this.position.x, this.position.z);
      this.prevPos.copy(this.position);
      this.player.setPose(this.position.x, this.position.y, this.position.z, this.heading);
      this.loop.start();
    });
  }

  // ------------------------------------------------------------------------------------------------ quality

  /** Push the governor's current state into the renderer, world and effects. */
  private applyQuality(resize = true): void {
    const tier = this.governor.current;
    this.renderer.setPixelRatio(this.governor.pixelRatio);
    if (resize) this.onResize();
    this.world.applyTier(tier);
    this.loop?.setFpsCap(tier.fpsCap);
    this.skid.setEnabled(tier.skidMarks);
    this.smokeLimit = Math.min(96, tier.smokeParticles);
    this.tireSmoke?.geometry.setDrawRange(0, this.smokeLimit);
    this.camera.far = Math.max(900, tier.viewDistance + 400);
    this.camera.updateProjectionMatrix();
  }

  private cycleQuality(): void {
    const next = QUALITY_MODES[(QUALITY_MODES.indexOf(this.qualityMode) + 1) % QUALITY_MODES.length];
    this.qualityMode = next;
    storage.set("apex.quality", next);
    this.governor.setTier(modeToTier(next, this.governor.tier));
    if (next !== "AUTO") this.governor.pixelRatio = this.governor.ceiling;
    this.applyQuality();
    this.setText("quality-label", `GRAPHICS ${next}`);
  }

  private onFrameTime(frameMs: number): void {
    this.fps += (1000 / Math.max(1, frameMs) - this.fps) * 0.1;
    this.frameCount++;
    if (this.qualityMode !== "AUTO" || this.frameCount < 60) return;
    const event = this.governor.sample(frameMs, this.loop.cappedIntervalMs);
    if (event === "none") return;
    this.applyQuality();
    if (event === "tier-down" || event === "tier-up") storage.set("apex.tier", this.governor.tier);
  }

  // ------------------------------------------------------------------------------------------------ save/ui

  private loadSave(): SaveData {
    const fallback: SaveData = { credits: 0, influence: 0, races: 0, best: {} };
    const stored = storage.get<Partial<SaveData> | null>("apex.save.v1", fallback);
    const value = stored && typeof stored === "object" ? stored : fallback;
    return {
      credits: Number.isFinite(value.credits) ? Math.max(0, value.credits!) : 0,
      influence: Number.isFinite(value.influence) ? Math.max(0, value.influence!) : 0,
      races: Number.isFinite(value.races) ? Math.max(0, value.races!) : 0,
      best: value.best && typeof value.best === "object" ? value.best : {},
    };
  }

  private persist(): void {
    storage.set("apex.save.v1", this.save);
    this.updatePersistentUi();
  }

  private updatePersistentUi(): void {
    this.setText("title-credits", `${Math.round(this.save.credits).toLocaleString()} CR`);
    this.setText("title-level", `DRIVER ${1 + Math.floor(this.save.influence / 2500)}`);
    this.setText("hud-credits", `${Math.round(this.save.credits).toLocaleString()} CR`);
  }

  private bindUi(): void {
    document.querySelectorAll<HTMLElement>("[data-race]").forEach((card) => {
      const race = RACES.find((item) => item.id === card.dataset.race);
      if (!race) return;
      const best = this.save.best[race.id];
      const bestEl = card.querySelector(".event-best");
      if (bestEl) bestEl.textContent = best ? `BEST ${this.formatTime(best)}` : "NEW EVENT";
    });
    this.setText("mute-label", this.audio.muted ? "SOUND OFF" : "SOUND ON");
    this.setText("fps-label", this.showFps ? "FPS: ON" : "FPS: OFF");
  }

  private onUiClick(event: Event): void {
    const target = (event.target as HTMLElement).closest<HTMLElement>("[data-action], [data-race], [data-region]");
    if (!target || target.hasAttribute("disabled")) return;
    this.audio.start();
    this.audio.sfx("ui");
    if (target.dataset.region) {
      this.enterRegion(target.dataset.region as RegionId);
      return;
    }
    if (target.dataset.race) {
      const race = RACES.find((item) => item.id === target.dataset.race);
      if (race) this.startRace(race);
      return;
    }
    switch (target.dataset.action) {
      case "free": this.startFree(); break;
      case "pause": this.pause(); break;
      case "resume": this.resume(); break;
      case "restart": this.restart(); break;
      case "title": this.toTitle(); break;
      case "season": this.cycleSeason(); break;
      case "quality": this.cycleQuality(); break;
      case "time": this.cycleTime(); break;
      case "fps":
        this.showFps = !this.showFps;
        this.el("fps-counter")?.classList.toggle("visible", this.showFps);
        this.setText("fps-label", this.showFps ? "FPS: ON" : "FPS: OFF");
        break;
      case "mute": this.audio.toggleMute(); this.setText("mute-label", this.audio.muted ? "SOUND OFF" : "SOUND ON"); break;
      case "start-nearby": if (this.nearbyRace) this.startRace(this.nearbyRace); break;
      case "next": {
        const index = this.race ? RACES.indexOf(this.race) : -1;
        this.startRace(RACES[(index + 1 + RACES.length) % RACES.length]);
        break;
      }
      case "reset-save":
        this.save = { credits: 0, influence: 0, races: 0, best: {} };
        storage.remove("apex.save.v1");
        this.updatePersistentUi();
        document.querySelectorAll(".event-best").forEach((el) => { el.textContent = "NEW EVENT"; });
        this.notify("LOCAL PROGRESS RESET");
        break;
    }
  }

  // ------------------------------------------------------------------------------------------- game flow

  /**
   * Load a region (terrain, roads, props are rebuilt) behind a loading screen, then start free roam or a race.
   * This was missing in v1.4: tapping a country called a method that did not exist.
   */
  private enterRegion(id: RegionId, thenRace: RaceDef | null = null): void {
    if (this.loadingRegion) return;
    if (id === this.world.region.id && this.world.curves.size > 0) {
      if (thenRace) this.startRace(thenRace); else this.startFree();
      return;
    }
    this.loadingRegion = true;
    const region = getRegion(id);
    this.setText("loading-title", `${region.flag} ${region.name.toUpperCase()}`);
    this.setText("loading-sub", "BUILDING ROADS · PLANTING FORESTS");
    this.el("loading-screen")?.classList.add("active");
    // Let the browser paint the loading screen before the (blocking) world rebuild starts.
    requestAnimationFrame(() => requestAnimationFrame(() => {
      if (this.disposed) return;
      try {
        this.world.setRegion(id);
        this.afterRegionLoaded();
      } finally {
        this.loadingRegion = false;
        this.el("loading-screen")?.classList.remove("active");
      }
      if (thenRace) this.startRace(thenRace); else this.startFree();
    }));
  }

  private afterRegionLoaded(): void {
    this.curveList = [...this.world.curves.values()];
    this.rebuildMinimap();
    for (const car of this.traffic) car.curve = null;
    this.skid.clear();
    this.governor.reset();
    this.frameCount = 0;
    this.applyQuality(false);
    const region = this.world.region;
    this.setText("hud-region", `${region.flag} ${region.name.toUpperCase()}`);
    this.setText("hud-season", SEASON_INFO[this.world.season].label.toUpperCase());
  }

  private startFree(): void {
    this.audio.start();
    this.mode = "free";
    this.race = null;
    this.nearbyRace = null;
    this.resetCar(new THREE.Vector3(0, 0, 180), 0);
    this.condition = 100;
    this.boost = Math.max(this.boost, 40);
    this.world.hideGate();
    this.world.showStartMarkers(true);
    for (const rival of this.rivals) rival.visual.group.visible = false;
    const region = this.world.region;
    this.setText("hud-event", `${region.flag} ${region.name.toUpperCase()} FREE ROAM`);
    this.setText("hud-objective", region.description);
    this.setText("hud-region", `${region.flag} ${region.name.toUpperCase()}`);
    if (this.machine.state !== "playing") this.machine.transition("playing");
    this.showScreen("hud");
    this.notify(`FREE ROAM · COLLECT ${this.world.tokenTotal} FESTIVAL TOKENS`);
  }

  private startRace(race: RaceDef): void {
    if (!this.player) return;
    if (race.region !== this.world.region.id) { this.enterRegion(race.region, race); return; }
    this.audio.start();
    this.mode = "race";
    this.race = race;
    this.checkpoint = 1;
    this.raceElapsed = 0;
    this.countdown = 3.8;
    this.lastCountdown = 4;
    this.finishPosition = 0;
    this.condition = 100;
    this.boost = 55;
    const [x, z] = race.route[0];
    const [nx, nz] = race.route[1];
    const heading = Math.atan2(nx - x, -(nz - z));
    this.resetCar(new THREE.Vector3(x, 0, z), heading);
    this.world.showStartMarkers(false);
    const curve = this.world.curves.get(race.id)!;
    const length = curve.getLength();
    this.rivals.forEach((rival, index) => {
      rival.progress = 0;
      rival.pace = race.aiPace * (0.94 + index * 0.035);
      rival.finished = false;
      rival.lane = (index - 1) * 2.3;
      this.positionRival(rival, curve, length);
    });
    const gate = race.route[this.checkpoint];
    const next = race.route[this.checkpoint + 1] ?? null;
    this.world.setGate(new THREE.Vector3(gate[0], 0, gate[1]), next ? new THREE.Vector3(next[0], 0, next[1]) : null);
    if (this.machine.state !== "playing") this.machine.transition("playing");
    this.showScreen("hud");
    this.setText("hud-event", race.name.toUpperCase());
    this.notify("3 · 2 · 1 · GO!");
  }

  private resetCar(position: THREE.Vector3, heading: number): void {
    this.position.copy(position);
    this.position.y = this.world.heightAt(position.x, position.z);
    this.prevPos.copy(this.position);
    this.velocity.set(0, 0, 0);
    this.heading = heading;
    this.prevHeading = heading;
    this.angularVel = 0;
    this.forwardSpeed = 0;
    this.driftChain = 0;
    this.driftIdle = 0;
    this.skid.breakChains();
    this.player?.setPose(this.position.x, this.position.y, this.position.z, heading);
  }

  private restart(): void {
    if (this.race) this.startRace(this.race);
    else this.startFree();
  }

  private pause(): void {
    if (this.machine.state !== "playing") return;
    this.machine.transition("paused");
    this.audio.updateEngine(0, 0, false, false);
    this.showScreen("pause");
    this.setText("pause-season", `${SEASON_INFO[this.world.season].label.toUpperCase()} · ${SEASON_INFO[this.world.season].weather.toUpperCase()}`);
    this.setText("quality-label", `GRAPHICS ${this.qualityMode}`);
    this.setText("fps-label", this.showFps ? "FPS: ON" : "FPS: OFF");
    this.renderPauseEvents();
  }

  private renderPauseEvents(): void {
    const box = this.el("pause-events-list");
    if (!box || box.childElementCount === RACES.length) return;
    box.replaceChildren();
    for (const race of RACES) {
      const button = document.createElement("button");
      button.dataset.race = race.id;
      button.textContent = `${getRegion(race.region).flag} ${race.shortName.toUpperCase()}`;
      box.appendChild(button);
    }
  }

  private resume(): void {
    if (this.machine.state !== "paused") return;
    this.machine.transition("playing");
    this.showScreen("hud");
  }

  private toTitle(): void {
    if (this.machine.state !== "title") this.machine.transition("title");
    this.mode = "free";
    this.race = null;
    this.audio.updateEngine(0, 0, false, false);
    this.world.hideGate();
    this.world.showStartMarkers(true);
    for (const rival of this.rivals) rival.visual.group.visible = false;
    this.showScreen("title");
    this.bindUi();
  }

  private cycleSeason(): void {
    const next = SEASONS[(SEASONS.indexOf(this.world.season) + 1) % SEASONS.length];
    this.setSeason(next);
    this.setText("pause-season", `${SEASON_INFO[next].label.toUpperCase()} · ${SEASON_INFO[next].weather.toUpperCase()}`);
    this.notify(`${SEASON_INFO[next].label.toUpperCase()} · GRIP ${Math.round(SEASON_INFO[next].grip * 100)}%`);
  }

  private setSeason(season: Season): void {
    this.world.setSeason(season);
    this.setText("hud-season", SEASON_INFO[season].label.toUpperCase());
  }

  private cycleTime(): void {
    const next = TIME_PRESETS.find((hour) => hour > this.timeOfDay + 0.05) ?? TIME_PRESETS[0];
    this.timeOfDay = next;
    const label = next < 10 ? "SUNRISE" : next < 15 ? "NOON" : next < 20 ? "SUNSET" : "NIGHT";
    this.notify(`${label} · ${this.formatClock(next)}`);
  }

  // ------------------------------------------------------------------------------------------- simulation

  private update(dt: number): void {
    if (!this.player) return;
    if (this.machine.state === "title") {
      if (this.input.consumeAction("Space")) this.startFree();
      return;
    }
    if (this.machine.state === "paused") {
      if (this.input.consumeAction("Escape") || this.input.consumeAction("Space")) this.resume();
      return;
    }
    if (this.machine.state === "gameover") {
      if (this.input.consumeAction("Space")) this.restart();
      return;
    }
    if (this.input.consumeAction("Escape")) { this.pause(); return; }
    this.input.consumeAction("Space"); // Space is held for boost; do not leave a stale resume action.
    if (this.input.consumeAction("KeyM")) this.audio.toggleMute();
    if (this.input.consumeAction("KeyR")) this.recoverCar();
    if (this.input.consumeAction("KeyE") && this.nearbyRace) this.startRace(this.nearbyRace);
    this.input.pollGamepad();
    this.collisionCooldown = Math.max(0, this.collisionCooldown - dt);
    this.waterCooldown = Math.max(0, this.waterCooldown - dt);
    if (this.toast.time > 0) this.toast.time -= dt;
    if (this.mode === "race" && this.race) this.updateRace(dt);
    else { this.updateFreeRoam(dt); this.updateTraffic(dt); }
    this.updateCar(dt);
  }

  private updateFreeRoam(_dt: number): void {
    let nearby: RaceDef | null = null;
    const markers = this.world.startMarkers.children;
    for (let index = 0; index < markers.length; index++) {
      const dx = markers[index].position.x - this.position.x, dz = markers[index].position.z - this.position.z;
      if (dx * dx + dz * dz < 100) nearby = this.world.regionRaces[index] ?? null;
    }
    this.nearbyRace = nearby;
    const prompt = this.el("event-prompt");
    prompt?.classList.toggle("visible", !!nearby);
    if (nearby) this.setText("event-prompt-name", nearby.name.toUpperCase());
  }

  private updateRace(dt: number): void {
    if (!this.race) return;
    this.el("event-prompt")?.classList.remove("visible");
    if (this.countdown > 0) {
      this.countdown -= dt;
      const shown = Math.ceil(this.countdown);
      if (shown < this.lastCountdown && shown > 0) {
        this.audio.sfx("countdown");
        this.lastCountdown = shown;
      }
      if (this.countdown <= 0) this.audio.sfx("go");
      return;
    }
    this.raceElapsed += dt;
    const curve = this.world.curves.get(this.race.id)!;
    const length = curve.getLength();
    for (const rival of this.rivals) {
      if (rival.finished) continue;
      const seasonPace = 0.88 + SEASON_INFO[this.world.season].grip * 0.12;
      rival.progress += (rival.pace * seasonPace * dt) / length;
      if (rival.progress >= 1) { rival.progress = 1; rival.finished = true; }
      this.positionRival(rival, curve, length);
    }
    const point = this.race.route[this.checkpoint];
    const dx = this.position.x - point[0], dz = this.position.z - point[1];
    if (dx * dx + dz * dz < 225) {
      this.checkpoint++;
      this.boost = Math.min(100, this.boost + 22);
      this.audio.sfx("checkpoint");
      if (this.checkpoint >= this.race.route.length) {
        this.finishRace(false);
        return;
      }
      const gate = this.race.route[this.checkpoint];
      const next = this.race.route[this.checkpoint + 1];
      this.world.setGate(new THREE.Vector3(gate[0], 0, gate[1]), next ? new THREE.Vector3(next[0], 0, next[1]) : null);
      this.notify(`CHECKPOINT ${this.checkpoint} / ${this.race.route.length - 1}  ·  +BOOST`);
    }
    if (this.race.timeLimit - this.raceElapsed <= 0 || this.condition <= 0) this.finishRace(true);
  }

  private positionRival(rival: Rival, curve: THREE.CatmullRomCurve3, _length: number): void {
    const t = Math.min(0.9999, rival.progress);
    curve.getPointAt(t, this.tempA);
    curve.getTangentAt(t, this.tempB);
    // right of travel = (-tz, tx)
    rival.x = this.tempA.x - this.tempB.z * rival.lane;
    rival.z = this.tempA.z + this.tempB.x * rival.lane;
    rival.y = this.world.heightAt(rival.x, rival.z);
    rival.heading = Math.atan2(this.tempB.x, -this.tempB.z);
    rival.visual.setPose(rival.x, rival.y, rival.z, rival.heading);
  }

  // ---------------------------------------------------------------------------------------------- traffic

  private spawnTraffic(car: TrafficCar): void {
    const curves = this.curveList;
    if (!curves.length) return;
    for (let attempt = 0; attempt < 10; attempt++) {
      const curve = curves[Math.floor(Math.random() * curves.length)];
      const t = 0.03 + Math.random() * 0.94;
      curve.getPointAt(t, this.tempA);
      const dx = this.tempA.x - this.position.x, dz = this.tempA.z - this.position.z;
      const d2 = dx * dx + dz * dz;
      if ((d2 > 90 * 90 && d2 < 260 * 260) || attempt === 9) {
        car.curve = curve;
        car.length = curve.getLength();
        car.t = t;
        car.dir = Math.random() < 0.5 ? 1 : -1;
        car.speed = 11 + Math.random() * 9;
        car.color = TRAFFIC_COLORS[Math.floor(Math.random() * TRAFFIC_COLORS.length)];
        return;
      }
    }
  }

  private updateTraffic(dt: number): void {
    const active = Math.min(this.traffic.length, this.mode === "free" ? this.governor.current.trafficCars : 0);
    const far = this.governor.current.propDistance + 80;
    for (let i = 0; i < active; i++) {
      const car = this.traffic[i];
      if (!car.curve) { this.spawnTraffic(car); if (!car.curve) continue; }
      car.t += (car.dir * car.speed * dt) / car.length;
      const dx0 = car.x - this.position.x, dz0 = car.z - this.position.z;
      if (car.t < 0.015 || car.t > 0.985 || dx0 * dx0 + dz0 * dz0 > far * far) { this.spawnTraffic(car); if (!car.curve) continue; }
      car.curve.getPointAt(car.t, this.tempA);
      car.curve.getTangentAt(car.t, this.tempB);
      const fx = this.tempB.x * car.dir, fz = this.tempB.z * car.dir;
      const len = Math.hypot(fx, fz) || 1;
      // drive in the right-hand lane: right of travel = (-fz, fx)
      car.x = this.tempA.x + (-fz / len) * 2.7;
      car.z = this.tempA.z + (fx / len) * 2.7;
      car.y = this.world.heightAt(car.x, car.z);
      car.heading = Math.atan2(fx, -fz);
    }
  }

  private checkTraffic(speed: number): void {
    if (this.mode !== "free") return;
    const active = Math.min(this.traffic.length, this.governor.current.trafficCars);
    for (let i = 0; i < active; i++) {
      const car = this.traffic[i];
      if (!car.curve) continue;
      const dx = this.position.x - car.x, dz = this.position.z - car.z;
      const min = 2.7;
      const d2 = dx * dx + dz * dz;
      if (d2 >= min * min || d2 < 0.0001) continue;
      const d = Math.sqrt(d2);
      this.position.x = car.x + (dx / d) * min;
      this.position.z = car.z + (dz / d) * min;
      this.velocity.multiplyScalar(0.55);
      if (this.collisionCooldown <= 0 && speed > 6) {
        this.condition = Math.max(0, this.condition - Math.min(20, speed * 0.4));
        this.collisionCooldown = 0.8;
        this.cameraShake = 0.3;
        this.audio.sfx("hit");
        this.notify(`TRAFFIC HIT · CONDITION ${Math.round(this.condition)}%`);
      }
      break;
    }
  }

  // ------------------------------------------------------------------------------------------------ smoke

  private initTireSmoke(): void {
    const COUNT = 96;
    this.smokePositions = new Float32Array(COUNT * 3);
    this.smokeLife = new Float32Array(COUNT);
    for (let i = 0; i < COUNT; i++) this.smokePositions[i * 3 + 1] = -500;
    const geo = new THREE.BufferGeometry();
    geo.setAttribute("position", new THREE.BufferAttribute(this.smokePositions, 3));
    const mat = new THREE.PointsMaterial({ color: 0xc8d0d4, size: 0.55, transparent: true, opacity: 0.45, depthWrite: false, sizeAttenuation: true });
    this.tireSmoke = new THREE.Points(geo, mat);
    this.tireSmoke.frustumCulled = false;
    this.scene.add(this.tireSmoke);
  }

  private spawnSmoke(x: number, y: number, z: number, intensity: number): void {
    if (!this.smokePositions || !this.smokeLife) return;
    const i = this.smokeIdx % this.smokeLimit;
    this.smokeIdx++;
    this.smokePositions[i * 3] = x + (Math.random() - 0.5) * 0.6;
    this.smokePositions[i * 3 + 1] = y + 0.15;
    this.smokePositions[i * 3 + 2] = z + (Math.random() - 0.5) * 0.6;
    this.smokeLife[i] = 0.55 + intensity * 0.4;
  }

  private updateSmoke(dt: number): void {
    if (!this.smokePositions || !this.smokeLife || !this.tireSmoke) return;
    let dirty = false;
    for (let i = 0; i < this.smokeLife.length; i++) {
      if (this.smokeLife[i] <= 0) continue;
      this.smokeLife[i] -= dt;
      dirty = true;
      if (this.smokeLife[i] <= 0) { this.smokePositions[i * 3 + 1] = -500; continue; } // hide dead particles
      this.smokePositions[i * 3 + 1] += dt * 1.8;
      this.smokePositions[i * 3] += (Math.random() - 0.5) * dt * 0.8;
      this.smokePositions[i * 3 + 2] += (Math.random() - 0.5) * dt * 0.8;
    }
    if (dirty) (this.tireSmoke.geometry.attributes.position as THREE.BufferAttribute).needsUpdate = true;
  }

  // --------------------------------------------------------------------------------------------- vehicle

  private updateCar(dt: number): void {
    if (!this.player) return;
    this.prevPos.copy(this.position);
    this.prevHeading = this.heading;
    const controlsEnabled = this.mode === "free" || this.countdown <= 0;
    const throttle = controlsEnabled ? this.input.throttle : 0;
    const brake = controlsEnabled ? this.input.brake : 0;
    const steerInput = controlsEnabled ? this.input.moveX : 0;
    const handbrake = controlsEnabled && this.input.handbrake;
    const onRoad = this.world.isRoad(this.position.x, this.position.z);
    const inWater = this.world.isWater(this.position.x, this.position.z);
    const seasonGrip = SEASON_INFO[this.world.season].grip * this.world.region.gripBias;

    const surfaceMul = onRoad ? 1.0 : (1.0 - TUNING.surfaceTractionLoss);
    const gripMul = seasonGrip * surfaceMul * (handbrake ? TUNING.handbrakeGripMul : 1.0);

    const forward = this.tempA.set(Math.sin(this.heading), 0, -Math.cos(this.heading));
    const right = this.tempC.set(Math.cos(this.heading), 0, Math.sin(this.heading));

    let forwardSpeed = this.velocity.dot(forward);
    let lateralSpeed = this.velocity.dot(right);

    let longForce = 0;
    if (throttle > 0) {
      if (forwardSpeed < -1.5) {
        longForce = TUNING.brake * 0.9;
      } else {
        const powerFactor = 1.0 - Math.min(Math.abs(forwardSpeed) / (TUNING.maxSpeed * 1.15), 0.72);
        longForce = TUNING.acceleration * powerFactor * gripMul * throttle;
      }
    }
    if (brake > 0) {
      if (forwardSpeed > 0.8) longForce -= TUNING.brake * brake;
      else if (forwardSpeed < -0.8) longForce += TUNING.acceleration * 0.55 * brake;
      else longForce -= Math.sign(forwardSpeed || 1) * TUNING.brake * 0.4 * brake;
    }
    this.isBraking = brake > 0 && forwardSpeed > 0.8;

    const boosting = controlsEnabled && this.input.boost && this.boost > 0 && forwardSpeed > 4;
    this.isBoosting = boosting;
    if (boosting) {
      longForce += TUNING.boostAcceleration * (0.85 + seasonGrip * 0.15);
      this.boost = Math.max(0, this.boost - 28 * dt);
      this.cameraShake = Math.max(this.cameraShake, 0.07);
    }

    const speed = this.velocity.length();
    const dragForce = TUNING.drag * (onRoad ? 1 : 2.4) * speed * speed * 0.018;
    longForce -= Math.sign(forwardSpeed || 1) * dragForce;
    const downforceGrip = 1 + TUNING.downforce * speed * speed;

    this.velocity.addScaledVector(forward, longForce * dt);

    const speedFactor = Math.min(Math.abs(forwardSpeed) / 6, 1);
    const highSpeedDamp = 1 - Math.min(Math.abs(forwardSpeed) / 95, 0.45);
    const steerAuthority = speedFactor * highSpeedDamp * (handbrake ? 1.55 : 1);
    const targetYawRate = steerInput * TUNING.steerRate * steerAuthority * (forwardSpeed < -0.4 ? -1 : 1);
    this.angularVel = THREE.MathUtils.lerp(this.angularVel, targetYawRate, 1 - Math.exp(-12 * dt));
    this.heading += this.angularVel * dt;

    forward.set(Math.sin(this.heading), 0, -Math.cos(this.heading));
    right.set(Math.cos(this.heading), 0, Math.sin(this.heading));
    forwardSpeed = this.velocity.dot(forward);
    lateralSpeed = this.velocity.dot(right);

    const slipAngle = Math.atan2(lateralSpeed, Math.max(Math.abs(forwardSpeed), 1.2));
    const peakGrip = TUNING.tireGripPeak * gripMul * downforceGrip;
    const slipMag = Math.abs(slipAngle);
    const lateralGrip = peakGrip * Math.tanh(slipMag / TUNING.slipAngleSoftness);
    const lateralForce = -Math.sign(lateralSpeed || slipAngle) * lateralGrip * TUNING.roadGrip * 0.55;

    const lateralDamping = (onRoad ? TUNING.roadGrip : TUNING.offroadGrip) * gripMul;
    lateralSpeed *= Math.exp(-lateralDamping * dt);
    lateralSpeed += lateralForce * dt * 0.35;

    this.velocity.copy(forward).multiplyScalar(forwardSpeed).addScaledVector(right, lateralSpeed);

    const maxSpd = (onRoad ? TUNING.maxSpeed : TUNING.maxSpeed * 0.62) * (inWater ? 0.35 : 1) * (boosting ? 1.18 : 1) * (0.92 + seasonGrip * 0.08);
    const curSpeed = this.velocity.length();
    if (curSpeed > maxSpd) this.velocity.multiplyScalar(maxSpd / curSpeed);
    if (inWater) {
      this.velocity.multiplyScalar(Math.exp(-1.4 * dt));
      if (this.waterCooldown <= 0) { this.waterCooldown = 3; this.notify("WATER · PRESS R TO RECOVER"); }
    }

    this.position.addScaledVector(this.velocity, dt);
    this.position.x = THREE.MathUtils.clamp(this.position.x, -TUNING.worldLimit, TUNING.worldLimit);
    this.position.z = THREE.MathUtils.clamp(this.position.z, -TUNING.worldLimit, TUNING.worldLimit);
    this.position.y = this.world.heightAt(this.position.x, this.position.z);

    // Capture the axes before collision code runs (it never touches tempA/tempC, but keep this explicit).
    const fx = forward.x, fz = forward.z, rx = right.x, rz = right.z;
    this.checkCollisions(curSpeed);
    this.checkTraffic(curSpeed);
    this.forwardSpeed = forwardSpeed;

    // Drift detection, skill chain and skid marks
    const lateralAbs = Math.abs(lateralSpeed);
    const slipping = lateralAbs > 2.4 && curSpeed > 9;
    const rearX = this.position.x - fx * 1.25, rearZ = this.position.z - fz * 1.25;
    this.skid.add(0, rearX - rx * 0.82, this.position.y, rearZ - rz * 0.82, slipping && !inWater);
    this.skid.add(1, rearX + rx * 0.82, this.position.y, rearZ + rz * 0.82, slipping && !inWater);
    if (slipping) {
      const gain = Math.min(22, lateralAbs * 1.35) * dt;
      this.boost = Math.min(100, this.boost + gain * 1.1);
      this.driftScore += gain * 14;
      this.driftChain += gain * 14;
      this.driftIdle = 0;
      if (Math.random() < 0.45) {
        this.spawnSmoke(rearX - rx * 0.9, this.position.y, rearZ - rz * 0.9, lateralAbs / 12);
        this.spawnSmoke(rearX + rx * 0.9, this.position.y, rearZ + rz * 0.9, lateralAbs / 12);
      }
    } else if (this.driftChain > 0) {
      this.driftIdle += dt;
      if (this.driftIdle > 1.1) {
        if (this.driftChain >= 120) {
          const bonus = Math.round(this.driftChain / 18);
          this.save.credits += bonus;
          this.persist();
          this.notify(`DRIFT CHAIN +${Math.round(this.driftChain)}  ·  +${bonus} CR`);
        }
        this.driftChain = 0;
      }
    }
    this.updateSmoke(dt);

    // Festival tokens
    if (this.mode === "free") {
      const got = this.world.collectTokens(this.position.x, this.position.z);
      if (got > 0) {
        this.boost = Math.min(100, this.boost + 12 * got);
        this.save.credits += 40 * got;
        this.persist();
        this.audio.sfx("checkpoint");
        const left = this.world.tokensLeft();
        this.notify(left === 0 ? "ALL TOKENS COLLECTED · +BONUS" : `TOKEN +40 CR · ${this.world.tokensCollected}/${this.world.tokenTotal}`);
        if (left === 0) { this.save.credits += 500; this.persist(); this.world.resetTokens(); }
      }
    }

    const accel = longForce * 0.06;
    this.lastAccel = THREE.MathUtils.lerp(this.lastAccel, accel, 0.25);
    this.lastLateral = THREE.MathUtils.lerp(this.lastLateral, lateralSpeed * 0.8 + this.angularVel * 4, 0.2);
    this.player.update(dt, forwardSpeed, steerInput, this.lastAccel, this.lastLateral, slipping);
    this.audio.updateEngine(curSpeed, throttle, slipping, true);
  }

  private checkCollisions(speed: number): void {
    this.world.obstacles.forEachNear(this.position.x, this.position.z, (obstacle) => {
      const dx = this.position.x - obstacle.x, dz = this.position.z - obstacle.z;
      const minDistance = obstacle.radius + 1.1;
      const distanceSq = dx * dx + dz * dz;
      if (distanceSq >= minDistance * minDistance || distanceSq < 0.0001) return false;
      const distance = Math.sqrt(distanceSq);
      this.position.x = obstacle.x + (dx / distance) * minDistance;
      this.position.z = obstacle.z + (dz / distance) * minDistance;
      this.velocity.multiplyScalar(-0.22);
      if (this.collisionCooldown <= 0 && speed > 7) {
        this.condition = Math.max(0, this.condition - Math.min(24, speed * 0.5));
        this.collisionCooldown = 0.8;
        this.cameraShake = 0.35;
        this.audio.sfx("hit");
        this.notify(`IMPACT · CONDITION ${Math.round(this.condition)}%`);
      }
      return true;
    });
  }

  private recoverCar(): void {
    if (this.mode === "race" && this.race) {
      const index = Math.max(0, this.checkpoint - 1);
      const [x, z] = this.race.route[index];
      const next = this.race.route[Math.min(index + 1, this.race.route.length - 1)];
      this.resetCar(new THREE.Vector3(x, 0, z), Math.atan2(next[0] - x, -(next[1] - z)));
    } else {
      // Free roam: back onto the nearest road point, facing along it.
      let best: { x: number; z: number; h: number } | null = null;
      let bestD = Infinity;
      for (const curve of this.curveList) {
        const pts = curve.getSpacedPoints(160);
        for (let i = 0; i < pts.length - 1; i++) {
          const dx = pts[i].x - this.position.x, dz = pts[i].z - this.position.z;
          const d = dx * dx + dz * dz;
          if (d < bestD) { bestD = d; best = { x: pts[i].x, z: pts[i].z, h: Math.atan2(pts[i + 1].x - pts[i].x, -(pts[i + 1].z - pts[i].z)) }; }
        }
      }
      if (best) this.resetCar(new THREE.Vector3(best.x, 0, best.z), best.h);
      else this.resetCar(new THREE.Vector3(0, 0, 180), 0);
    }
    this.notify("CAR RECOVERED");
  }

  private finishRace(dnf: boolean): void {
    if (!this.race || this.machine.state !== "playing") return;
    this.finishPosition = dnf ? 4 : this.calculateRank();
    const reward = dnf ? 0 : Math.round(this.race.reward * (1.15 - (this.finishPosition - 1) * 0.2));
    if (!dnf) {
      this.save.credits += reward;
      this.save.influence += 450 + (4 - this.finishPosition) * 150;
      this.save.races++;
      const previous = this.save.best[this.race.id];
      if (!previous || this.raceElapsed < previous) this.save.best[this.race.id] = this.raceElapsed;
      this.persist();
    }
    this.machine.transition("gameover");
    this.audio.sfx(dnf || this.finishPosition > 1 ? "lose" : "win");
    this.audio.updateEngine(0, 0, false, false);
    this.showScreen("results");
    this.setText("result-kicker", dnf ? "EVENT ENDED" : this.finishPosition === 1 ? "VICTORY" : "FINISH");
    this.setText("result-title", dnf ? "DNF" : `P${this.finishPosition}`);
    this.setText("result-event", this.race.name.toUpperCase());
    this.setText("result-time", dnf ? "—" : this.formatTime(this.raceElapsed));
    this.setText("result-reward", `+${reward.toLocaleString()} CR`);
    this.setText("result-note", dnf ? (this.condition <= 0 ? "Car retired · repair and retry" : "Time expired · use shortcuts and boost") : this.finishPosition === 1 ? "A masterclass under festival lights" : this.finishPosition <= 3 ? "Podium secured · chase the win next run" : "Finished · chase the podium next run");
  }

  private calculateRank(): number {
    if (!this.race) return 1;
    const playerProgress = (this.checkpoint - 1) / (this.race.route.length - 1);
    return 1 + this.rivals.filter((rival) => rival.progress > playerProgress + 0.015).length;
  }

  // ---------------------------------------------------------------------------------------------- daylight

  private updateDaylight(dt: number): void {
    const angle0 = (this.timeOfDay / 24) * Math.PI * 2 - Math.PI / 2;
    const sunH0 = Math.sin(angle0);
    // Nights pass faster than days so players are not stuck in the dark for 20 minutes.
    this.timeOfDay = (this.timeOfDay + dt * (sunH0 < -0.12 ? 0.045 : 0.012)) % 24;
    const angle = (this.timeOfDay / 24) * Math.PI * 2 - Math.PI / 2;
    const sunH = Math.sin(angle);
    const daylight = smoothstep((sunH + 0.16) / 0.46);
    const glow = Math.max(0, 1 - Math.abs(sunH - 0.05) / 0.28);
    this.night = 1 - daylight;
    this.sunDir.set(Math.cos(angle) * 0.95, sunH, 0.32).normalize();

    // Key light: sun by day, cold moonlight by night; always above the horizon so surfaces stay readable.
    this.lightDir.copy(this.sunDir).multiplyScalar(2 * daylight - 1);
    this.lightDir.y += 0.55; // overhead at the day/night crossover keeps the transition continuous
    this.lightDir.normalize();
    if (this.lightDir.y < 0.14) { this.lightDir.y = 0.14; this.lightDir.normalize(); }
    this.sun.position.copy(this.lightDir).multiplyScalar(150);
    this.dayColor.setHex(0xfff0d8).lerp(WARM, glow * 0.55);
    this.nightColor.setHex(0x7d93d6);
    this.sun.color.copy(this.dayColor).lerp(this.nightColor, 1 - daylight);
    this.sun.intensity = 0.42 + daylight * 2.45;
    this.hemisphere.color.setHex(0xb8d9f0).lerp(this.nightColor.setHex(0x2d3f6e), 1 - daylight);
    this.hemisphere.groundColor.setHex(0x4a5a3c).lerp(this.nightColor.setHex(0x151b27), 1 - daylight);
    this.hemisphere.intensity = 0.52 + daylight * 1.05;
    this.renderer.toneMappingExposure = 1.22 - daylight * 0.04;

    this.world.atmosphere(dt, daylight, glow, this.sunDir, this.camera.position);
  }

  // ---------------------------------------------------------------------------------------------- HUD

  private el(id: string): HTMLElement | null {
    let element = this.domCache.get(id);
    if (element === undefined || (element === null && document.getElementById(id))) {
      element = document.getElementById(id);
      this.domCache.set(id, element);
    }
    return element;
  }

  private updateHud(): void {
    const speed = Math.round(this.velocity.length() * 3.6);
    this.setText("speed-value", String(speed));
    this.setText("hud-season", SEASON_INFO[this.world.season].label.toUpperCase());
    this.setText("hud-time", this.formatClock(this.timeOfDay));
    this.setText("condition-value", `${Math.round(this.condition)}%`);
    const boostBar = this.el("boost-fill");
    if (boostBar) boostBar.style.width = `${this.boost}%`;
    const ring = this.el("speedo-ring");
    if (ring) ring.style.setProperty("--spd", `${Math.min(280, (speed / 220) * 280)}deg`);
    const fx = this.el("speed-fx");
    if (fx) {
      fx.style.opacity = String(Math.min(0.85, Math.max(0, (speed - 110) / 130) * 0.6 + (this.isBoosting ? 0.35 : 0)));
      fx.classList.toggle("boost", this.isBoosting);
    }
    if (this.showFps) {
      const tier = this.governor.current;
      this.setText("fps-counter", `${Math.round(this.fps)} FPS · ${tier.name.toUpperCase()} · ${this.governor.pixelRatio.toFixed(2)}x`);
    }
    if (this.mode === "race" && this.race) {
      const remaining = Math.max(0, this.race.timeLimit - this.raceElapsed);
      this.setText("hud-event", this.race.name.toUpperCase());
      this.setText("hud-primary", this.countdown > 0 ? String(Math.max(1, Math.ceil(this.countdown))) : this.formatTime(remaining));
      this.setText("hud-secondary", `GATE ${Math.min(this.checkpoint, this.race.route.length - 1)}/${this.race.route.length - 1}  ·  P${this.calculateRank()}/4`);
      this.setText("hud-objective", this.countdown > 0 ? "Hold throttle. Launch on GO." : "Follow the amber gates · drift to charge boost");
    } else {
      const region = this.world.region;
      this.setText("hud-event", `${region.flag} ${region.name.toUpperCase()} FREE ROAM`);
      this.setText("hud-primary", `${Math.round(this.driftScore).toLocaleString()}`);
      this.setText("hud-secondary", this.driftChain > 40 ? `CHAIN +${Math.round(this.driftChain)}` : `SKILL · TOKENS ${this.world.tokensCollected}/${this.world.tokenTotal}`);
      this.setText("hud-objective", "Collect tokens · enter a glowing event ring");
    }
    const toast = this.el("toast");
    if (toast) {
      if (toast.textContent !== this.toast.text) toast.textContent = this.toast.text;
      toast.classList.toggle("visible", this.toast.time > 0);
    }
    this.drawMinimap();
  }

  /** Roads/lakes never change within a region, so they are drawn once into an offscreen canvas. */
  private rebuildMinimap(): void {
    const target = document.querySelector<HTMLCanvasElement>("#minimap");
    if (!target) return;
    const canvas = this.minimapStatic ?? document.createElement("canvas");
    canvas.width = target.width; canvas.height = target.height;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const size = canvas.width;
    const scale = size / 820;
    ctx.fillStyle = "rgba(7,18,21,.82)";
    ctx.fillRect(0, 0, size, size);
    ctx.fillStyle = "rgba(76,140,176,.55)";
    for (const lake of this.world.lakes) {
      ctx.beginPath();
      ctx.arc(size / 2 + lake.x * scale, size / 2 + lake.z * scale, lake.r * scale, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.lineWidth = 2;
    ctx.strokeStyle = "rgba(207,228,215,.32)";
    for (const race of this.world.regionRaces) {
      ctx.beginPath();
      race.route.forEach(([x, z], index) => {
        const mx = size / 2 + x * scale, my = size / 2 + z * scale;
        if (index === 0) ctx.moveTo(mx, my); else ctx.lineTo(mx, my);
      });
      ctx.stroke();
    }
    this.minimapStatic = canvas;
  }

  private drawMinimap(): void {
    const ctx = this.minimap;
    if (!ctx) return;
    const size = ctx.canvas.width;
    const scale = size / 820;
    ctx.clearRect(0, 0, size, size);
    if (this.minimapStatic) ctx.drawImage(this.minimapStatic, 0, 0);
    const map = (x: number, z: number) => [size / 2 + x * scale, size / 2 + z * scale] as const;
    if (this.race) {
      ctx.lineWidth = 2;
      ctx.strokeStyle = "#ffbd61";
      ctx.beginPath();
      this.race.route.forEach(([x, z], index) => {
        const [mx, my] = map(x, z);
        if (index === 0) ctx.moveTo(mx, my); else ctx.lineTo(mx, my);
      });
      ctx.stroke();
    } else {
      ctx.fillStyle = "#68e0ab";
      this.world.regionRaces.forEach((race, index) => {
        const [mx, my] = map(race.route[0][0] + index * 8, race.route[0][1] + 8);
        ctx.fillRect(mx - 2, my - 2, 4, 4);
      });
      ctx.fillStyle = "#ffc83a";
      this.world.forEachToken((x, z) => { const [mx, my] = map(x, z); ctx.fillRect(mx - 1, my - 1, 2, 2); });
    }
    if (this.mode === "race") for (const rival of this.rivals) {
      const [x, y] = map(rival.x, rival.z);
      ctx.fillStyle = "#e9f1ec";
      ctx.fillRect(x - 1.5, y - 1.5, 3, 3);
    }
    const [px, py] = map(this.position.x, this.position.z);
    ctx.save();
    ctx.translate(px, py);
    ctx.rotate(this.heading); // clockwise on screen = turning right; v1.4 used -heading (mirrored arrow)
    ctx.fillStyle = "#ff9f43";
    ctx.beginPath();
    ctx.moveTo(0, -6); ctx.lineTo(4, 5); ctx.lineTo(-4, 5); ctx.closePath(); ctx.fill();
    ctx.restore();
  }

  // ------------------------------------------------------------------------------------------- rendering

  private render(alpha: number, frameMs: number): void {
    if (!this.player) return;
    const now = performance.now();
    const renderDelta = Math.min(0.1, Math.max(0.001, (now - this.renderPrevious) / 1000));
    this.renderPrevious = now;
    const cameraBlend = 1 - Math.exp(-renderDelta * 9.5);
    const playing = this.machine.state === "playing";
    const a = playing ? alpha : 1;

    // Interpolated pose: the simulation runs at a fixed 60 Hz while rendering may run at 30..120 Hz.
    this.viewPos.lerpVectors(this.prevPos, this.position, a);
    this.viewHeading = this.prevHeading + (this.heading - this.prevHeading) * a;
    this.player.setPose(this.viewPos.x, this.viewPos.y, this.viewPos.z, this.viewHeading);

    if (this.machine.state === "title") {
      const time = now * 0.00007;
      this.cameraPosition.set(Math.sin(time) * 38, 11.5, 182 + Math.cos(time) * 32);
      this.camera.position.copy(this.cameraPosition);
      this.camera.lookAt(0, 2.2, 180);
    } else {
      const forward = this.tempA.set(Math.sin(this.viewHeading), 0, -Math.cos(this.viewHeading));
      const right = this.tempB.set(Math.cos(this.viewHeading), 0, Math.sin(this.viewHeading));
      const speed = this.velocity.length();
      const distance = 7.2 + Math.min(speed * 0.055, 3.4);
      const height = 3.15 + Math.min(speed * 0.022, 1.1);
      const yawOffset = this.angularVel * -0.35;

      this.cameraTarget.copy(this.viewPos).addScaledVector(forward, -distance).addScaledVector(right, yawOffset);
      this.cameraTarget.y += height;
      this.cameraPosition.lerp(this.cameraTarget, cameraBlend);
      this.camera.position.copy(this.cameraPosition);
      // never dip under the terrain on hills
      this.camera.position.y = Math.max(this.camera.position.y, this.world.heightAt(this.camera.position.x, this.camera.position.z) + 1.2);

      if (this.cameraShake > 0.004) {
        this.camera.position.x += Math.sin(now * 0.068) * this.cameraShake;
        this.camera.position.y += Math.cos(now * 0.081) * this.cameraShake * 0.55;
        this.camera.position.z += Math.sin(now * 0.055) * this.cameraShake * 0.3;
        this.cameraShake *= 0.86;
      }

      this.cameraTarget.copy(this.viewPos).addScaledVector(forward, 5.5 + Math.min(speed * 0.04, 2.5));
      this.cameraTarget.y += 1.05 + Math.min(speed * 0.008, 0.4);
      this.camera.lookAt(this.cameraTarget);

      const targetFov = 62 + Math.min(speed * 0.16, 9) + (this.isBoosting ? 4 : 0);
      const nextFov = THREE.MathUtils.lerp(this.camera.fov, targetFov, cameraBlend * 0.65);
      if (Math.abs(nextFov - this.camera.fov) > 0.01) { this.camera.fov = nextFov; this.camera.updateProjectionMatrix(); }
    }

    this.updateDaylight(renderDelta);
    this.world.update(renderDelta, this.position, this.camera.position);
    this.player.setLights(this.night, this.isBraking, this.isBoosting, now * 0.001);

    // Rivals: full model when close, instanced low-poly stand-in when far; traffic is always instanced.
    this.fleet.begin();
    if (this.mode === "race") {
      const seasonPace = 0.88 + SEASON_INFO[this.world.season].grip * 0.12;
      for (const rival of this.rivals) {
        const dx = rival.x - this.camera.position.x, dz = rival.z - this.camera.position.z;
        const near = dx * dx + dz * dz < 60 * 60;
        rival.visual.group.visible = near;
        if (near) {
          rival.visual.update(renderDelta, rival.finished ? 0 : rival.pace * seasonPace, 0);
          rival.visual.setLights(this.night, false, false, now * 0.001);
        } else this.fleet.push(rival.x, rival.y, rival.z, rival.heading, rival.color);
      }
    } else {
      const active = Math.min(this.traffic.length, this.governor.current.trafficCars);
      for (let i = 0; i < active; i++) {
        const car = this.traffic[i];
        if (car.curve) this.fleet.push(car.x, car.y, car.z, car.heading, car.color);
      }
    }
    this.fleet.end();

    this.hudClock -= renderDelta;
    if (this.hudClock <= 0) {
      this.hudClock = 0.1;
      this.updateHud();
    }

    this.renderer.render(this.scene, this.camera);
    this.onFrameTime(frameMs);
    window.__GAME_READY__ = true;
  }

  private showScreen(name: "title" | "hud" | "pause" | "results"): void {
    for (const id of ["title-screen", "hud", "pause-screen", "results-screen"]) {
      this.el(id)?.classList.toggle("active", id === `${name}-screen` || (name === "hud" && id === "hud"));
    }
    this.el("touch-controls")?.classList.toggle("active", name === "hud");
  }

  private notify(text: string): void {
    this.toast.text = text;
    this.toast.time = 2.4;
  }

  private setText(id: string, text: string): void {
    const element = this.el(id);
    if (element && element.textContent !== text) element.textContent = text;
  }

  private formatTime(seconds: number): string {
    const minutes = Math.floor(seconds / 60);
    const remaining = seconds - minutes * 60;
    return `${minutes}:${remaining.toFixed(1).padStart(4, "0")}`;
  }

  private formatClock(time: number): string {
    const hours = Math.floor(time);
    const minutes = Math.floor((time - hours) * 60);
    return `${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}`;
  }

  private onResize(): void {
    const width = window.innerWidth, height = window.innerHeight;
    this.camera.aspect = width / Math.max(1, height);
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height, false);
  }

  dispose(): void {
    if (this.disposed) return;
    this.disposed = true;
    this.loop.stop();
    this.input.dispose();
    this.audio.dispose();
    window.removeEventListener("resize", this.resize);
    document.removeEventListener("visibilitychange", this.visibility);
    document.querySelector("#ui-overlay")?.removeEventListener("click", this.uiClick);
    this.world.dispose();
    this.fleet.dispose();
    this.skid.dispose();
    this.scene.traverse((object) => {
      if (object instanceof THREE.Mesh || object instanceof THREE.Points) {
        object.geometry.dispose();
        const materials = Array.isArray(object.material) ? object.material : [object.material];
        materials.forEach((material) => material.dispose());
      }
    });
    this.renderer.dispose();
    delete window.__gameProbe;
    delete window.__gameMetrics;
    delete window.__apexTest;
    window.__GAME_READY__ = false;
  }
}
