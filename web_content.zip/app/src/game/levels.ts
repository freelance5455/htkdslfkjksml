/**
 * levels.ts — as três áreas de "Crônicas do Cristal" (fiel ao protótipo Godot).
 */
import type { LevelTheme } from "./config";

export interface LevelData {
  name: string;
  length: number;
  enemyCount: number;
  boss: boolean;
  theme: LevelTheme;
  music: "forest" | "ruins" | "citadel";
}

export const LEVELS: LevelData[] = [
  {
    name: "Bosque dos Ecos",
    length: 2600,
    enemyCount: 5,
    boss: false,
    music: "forest",
    theme: {
      skyTop: 0x0e2233,
      skyBottom: 0x1d4a5e,
      mountain: 0x1a2f3b,
      mountainFar: 0x12222e,
      floor: 0x1f4038,
      platform: 0x3d6156,
      accent: 0x57e6b0,
      fog: 0x9adfcf,
    },
  },
  {
    name: "Ruínas Submersas",
    length: 3000,
    enemyCount: 7,
    boss: false,
    music: "ruins",
    theme: {
      skyTop: 0x0a1e33,
      skyBottom: 0x14435f,
      mountain: 0x16324a,
      mountainFar: 0x0f2538,
      floor: 0x1d3d4a,
      platform: 0x356077,
      accent: 0x4fc8ff,
      fog: 0x8fd4ef,
    },
  },
  {
    name: "Cidadela Sombria",
    length: 3400,
    enemyCount: 6,
    boss: true,
    music: "citadel",
    theme: {
      skyTop: 0x160f2e,
      skyBottom: 0x3a1f4f,
      mountain: 0x241a3d,
      mountainFar: 0x191230,
      floor: 0x2a2340,
      platform: 0x453a66,
      accent: 0xb07dff,
      fog: 0xc9aef2,
    },
  },
];
