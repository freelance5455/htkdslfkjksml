/**
 * arena.ts — the walled stone fortress / courtyard.
 * Builds all level geometry, static AABB colliders, patrol waypoints and spawn points.
 * Bullet raycasts and AI line-of-sight both go through raycastColliders() (analytic slab test —
 * no physics engine needed for a static box world).
 */

import * as THREE from "three";

export interface AABB {
  minX: number;
  maxX: number;
  minZ: number;
  maxZ: number;
  height: number;
}

export interface Arena {
  group: THREE.Group;
  colliders: AABB[];
  waypoints: { x: number; z: number }[];
  spawns: { blue: THREE.Vector3[]; red: THREE.Vector3[] };
  /** Half-size of the playfield (walls at ±wallHalf). */
  wallHalf: number;
}

const WALL_H = 5;
const WALL_T = 2;
const HALF = 32; // wall inner face at ±32

/** Procedural weathered stone-block texture (canvas → CanvasTexture). */
function makeStoneTexture(base: string, mortar: string, blockW: number, blockH: number): THREE.CanvasTexture {
  const c = document.createElement("canvas");
  c.width = 256;
  c.height = 256;
  const g = c.getContext("2d")!;
  g.fillStyle = base;
  g.fillRect(0, 0, 256, 256);
  // per-block mottling
  for (let y = 0; y < 256; y += blockH) {
    const offset = (y / blockH) % 2 === 0 ? 0 : blockW / 2;
    for (let x = -blockW; x < 256 + blockW; x += blockW) {
      const shade = 0.82 + Math.random() * 0.36;
      const rr = parseInt(base.slice(1, 3), 16) * shade;
      const gg = parseInt(base.slice(3, 5), 16) * shade;
      const bb = parseInt(base.slice(5, 7), 16) * shade;
      g.fillStyle = `rgb(${rr | 0},${gg | 0},${bb | 0})`;
      g.fillRect(x + offset + 1.5, y + 1.5, blockW - 3, blockH - 3);
      // weathering streaks
      g.fillStyle = "rgba(0,0,0,0.08)";
      for (let s = 0; s < 3; s++) {
        const sx = x + offset + Math.random() * blockW;
        g.fillRect(sx, y + Math.random() * blockH * 0.4, 2, blockH * (0.3 + Math.random() * 0.6));
      }
    }
  }
  // mortar lines
  g.strokeStyle = mortar;
  g.lineWidth = 3;
  for (let y = 0; y <= 256; y += blockH) {
    g.beginPath(); g.moveTo(0, y); g.lineTo(256, y); g.stroke();
    const offset = (y / blockH) % 2 === 0 ? 0 : blockW / 2;
    for (let x = -blockW; x < 256 + blockW; x += blockW) {
      g.beginPath(); g.moveTo(x + offset, y); g.lineTo(x + offset, y + blockH); g.stroke();
    }
  }
  const tex = new THREE.CanvasTexture(c);
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

/** Procedural dirt/sand ground texture with pebbles and stains. */
function makeGroundTexture(): THREE.CanvasTexture {
  const c = document.createElement("canvas");
  c.width = 256;
  c.height = 256;
  const g = c.getContext("2d")!;
  g.fillStyle = "#8a7a5c";
  g.fillRect(0, 0, 256, 256);
  for (let i = 0; i < 2600; i++) {
    const v = Math.random();
    g.fillStyle = v < 0.5 ? "rgba(60,50,35,0.16)" : "rgba(200,185,150,0.13)";
    const r = 1 + Math.random() * 2.4;
    g.beginPath();
    g.arc(Math.random() * 256, Math.random() * 256, r, 0, Math.PI * 2);
    g.fill();
  }
  for (let i = 0; i < 24; i++) {
    g.fillStyle = "rgba(45,38,26,0.12)";
    g.beginPath();
    g.ellipse(Math.random() * 256, Math.random() * 256, 12 + Math.random() * 26, 8 + Math.random() * 18, Math.random() * 3, 0, Math.PI * 2);
    g.fill();
  }
  const tex = new THREE.CanvasTexture(c);
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

/** Nearest positive ray→AABB hit distance, or Infinity. Slab method, 2D XZ + height slab. */
export function raycastColliders(colliders: AABB[], ox: number, oy: number, oz: number, dx: number, dy: number, dz: number, maxDist: number): number {
  let best = maxDist;
  for (let i = 0; i < colliders.length; i++) {
    const b = colliders[i];
    let tmin = 0, tmax = best;
    // X slab
    if (Math.abs(dx) < 1e-9) { if (ox < b.minX || ox > b.maxX) continue; }
    else {
      let t1 = (b.minX - ox) / dx, t2 = (b.maxX - ox) / dx;
      if (t1 > t2) { const t = t1; t1 = t2; t2 = t; }
      tmin = Math.max(tmin, t1); tmax = Math.min(tmax, t2);
      if (tmin > tmax) continue;
    }
    // Y slab (0 .. height)
    if (Math.abs(dy) < 1e-9) { if (oy < 0 || oy > b.height) continue; }
    else {
      let t1 = (0 - oy) / dy, t2 = (b.height - oy) / dy;
      if (t1 > t2) { const t = t1; t1 = t2; t2 = t; }
      tmin = Math.max(tmin, t1); tmax = Math.min(tmax, t2);
      if (tmin > tmax) continue;
    }
    // Z slab
    if (Math.abs(dz) < 1e-9) { if (oz < b.minZ || oz > b.maxZ) continue; }
    else {
      let t1 = (b.minZ - oz) / dz, t2 = (b.maxZ - oz) / dz;
      if (t1 > t2) { const t = t1; t1 = t2; t2 = t; }
      tmin = Math.max(tmin, t1); tmax = Math.min(tmax, t2);
      if (tmin > tmax) continue;
    }
    if (tmin < best && tmin > 0) best = tmin;
  }
  return best;
}

/** 2D segment LOS check: true if no collider taller than `minClear` blocks the segment. */
export function hasLineOfSight(colliders: AABB[], ax: number, ay: number, az: number, bx: number, by: number, bz: number): boolean {
  const dx = bx - ax, dy = by - ay, dz = bz - az;
  const dist = Math.hypot(dx, dy, dz);
  if (dist < 1e-6) return true;
  return raycastColliders(colliders, ax, ay, az, dx / dist, dy / dist, dz / dist, dist) >= dist - 0.01;
}

/** Resolve a moving circle (radius r) against colliders; mutates pos (XZ only). */
export function resolveCollision(colliders: AABB[], pos: THREE.Vector3, r: number): void {
  for (let pass = 0; pass < 2; pass++) {
    for (let i = 0; i < colliders.length; i++) {
      const b = colliders[i];
      // Only colliders tall enough to block a body matter
      if (b.height < 0.5) continue;
      const cx = Math.max(b.minX, Math.min(pos.x, b.maxX));
      const cz = Math.max(b.minZ, Math.min(pos.z, b.maxZ));
      const ddx = pos.x - cx, ddz = pos.z - cz;
      const d2 = ddx * ddx + ddz * ddz;
      if (d2 < r * r) {
        if (d2 > 1e-9) {
          const d = Math.sqrt(d2);
          pos.x = cx + (ddx / d) * r;
          pos.z = cz + (ddz / d) * r;
        } else {
          // center inside the box: push out along the smallest penetration axis
          const px1 = pos.x - b.minX, px2 = b.maxX - pos.x;
          const pz1 = pos.z - b.minZ, pz2 = b.maxZ - pos.z;
          const m = Math.min(px1, px2, pz1, pz2);
          if (m === px1) pos.x = b.minX - r;
          else if (m === px2) pos.x = b.maxX + r;
          else if (m === pz1) pos.z = b.minZ - r;
          else pos.z = b.maxZ + r;
        }
      }
    }
  }
}

export function buildArena(): Arena {
  const group = new THREE.Group();
  const colliders: AABB[] = [];
  const wallTex = makeStoneTexture("#7d7a72", "#4a4741", 42, 22);
  const darkTex = makeStoneTexture("#5d5a54", "#38352f", 46, 24);
  const groundTex = makeGroundTexture();
  groundTex.repeat.set(16, 16);

  const groundMat = new THREE.MeshStandardMaterial({ map: groundTex, roughness: 1, metalness: 0 });
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(2 * (HALF + 14), 2 * (HALF + 14)), groundMat);
  ground.rotation.x = -Math.PI / 2;
  ground.receiveShadow = true;
  group.add(ground);

  const wallMat = new THREE.MeshStandardMaterial({ map: wallTex, roughness: 0.95, metalness: 0.02 });
  const darkMat = new THREE.MeshStandardMaterial({ map: darkTex, roughness: 0.9, metalness: 0.05 });
  const ironMat = new THREE.MeshStandardMaterial({ color: 0x2b2e33, roughness: 0.45, metalness: 0.85 });
  const woodMat = new THREE.MeshStandardMaterial({ color: 0x6b543a, roughness: 0.9 });
  const bagMat = new THREE.MeshStandardMaterial({ color: 0x77705a, roughness: 1 });

  const addBox = (
    minX: number, maxX: number, minZ: number, maxZ: number, h: number,
    mat: THREE.Material, opts: { collide?: boolean; cast?: boolean; y?: number; receive?: boolean } = {},
  ): THREE.Mesh => {
    const { collide = true, cast = true, y = 0, receive = true } = opts;
    const m = new THREE.Mesh(new THREE.BoxGeometry(maxX - minX, h, maxZ - minZ), mat);
    m.position.set((minX + maxX) / 2, y + h / 2, (minZ + maxZ) / 2);
    m.castShadow = cast;
    m.receiveShadow = receive;
    group.add(m);
    if (collide) colliders.push({ minX, maxX, minZ, maxZ, height: y + h });
    return m;
  };

  // ---------- perimeter walls with a north gate + east/west arch rooms ----------
  // North wall: two segments leaving a gate gap x∈[-3,3]
  addBox(-HALF - WALL_T, -3, -HALF - WALL_T, -HALF, WALL_H, wallMat);
  addBox(3, HALF + WALL_T, -HALF - WALL_T, -HALF, WALL_H, wallMat);
  // lintel above the gate gap
  addBox(-3, 3, -HALF - WALL_T, -HALF, WALL_H, wallMat, { collide: false, y: 3.4, cast: false });
  // gate room behind the bars (decor, blocked)
  addBox(-8.5, 8.5, -HALF - 9, -HALF - WALL_T, WALL_H, darkMat, { collide: true }); // back wall
  addBox(-8.5, -3, -HALF - 9, -HALF, WALL_H, darkMat, { collide: false }); // room sides (visual, bars block anyway)
  addBox(3, 8.5, -HALF - 9, -HALF, WALL_H, darkMat, { collide: false });
  // iron bars filling the gate gap — solid collision
  colliders.push({ minX: -3, maxX: 3, minZ: -HALF - 0.3, maxZ: -HALF + 0.3, height: WALL_H });
  for (let i = 0; i <= 6; i++) {
    const bar = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 3.4, 6), ironMat);
    bar.position.set(-3 + i, 1.7, -HALF);
    bar.castShadow = true;
    group.add(bar);
  }
  const gateBar = new THREE.Mesh(new THREE.BoxGeometry(6, 0.12, 0.12), ironMat);
  gateBar.position.set(0, 1.7, -HALF);
  group.add(gateBar);

  // South wall: solid
  addBox(-HALF - WALL_T, HALF + WALL_T, HALF, HALF + WALL_T, WALL_H, wallMat);
  // East wall with arch gap z∈[-2.5,2.5]
  addBox(HALF, HALF + WALL_T, -HALF - WALL_T, -2.5, WALL_H, wallMat);
  addBox(HALF, HALF + WALL_T, 2.5, HALF + WALL_T, WALL_H, wallMat);
  addBox(HALF, HALF + WALL_T, -2.5, 2.5, WALL_H, wallMat, { collide: false, y: 3.2, cast: false }); // arch lintel
  // East arch room (walkable alcove): back wall + two side walls
  addBox(HALF + WALL_T, HALF + 9, -6.5, 6.5, WALL_H, darkMat);
  addBox(HALF + WALL_T, HALF + 9, -6.5, -2.5, WALL_H, darkMat); // north side of room
  addBox(HALF + WALL_T, HALF + 9, 2.5, 6.5, WALL_H, darkMat);   // south side of room
  // West wall mirrored
  addBox(-HALF - WALL_T, -HALF, -HALF - WALL_T, -2.5, WALL_H, wallMat);
  addBox(-HALF - WALL_T, -HALF, 2.5, HALF + WALL_T, WALL_H, wallMat);
  addBox(-HALF - WALL_T, -HALF, -2.5, 2.5, WALL_H, wallMat, { collide: false, y: 3.2, cast: false });
  addBox(-HALF - 9, -HALF - WALL_T, -6.5, 6.5, WALL_H, darkMat);
  addBox(-HALF - 9, -HALF - WALL_T, -6.5, -2.5, WALL_H, darkMat);
  addBox(-HALF - 9, -HALF - WALL_T, 2.5, 6.5, WALL_H, darkMat);

  // ---------- courtyard cover ----------
  // central raised platform (bullets pass over, blocks movement)
  addBox(-5, 5, -5, 5, 0.55, darkMat);
  const platTrim = new THREE.Mesh(new THREE.BoxGeometry(10.4, 0.12, 10.4), darkMat);
  platTrim.position.set(0, 0.55, 0);
  platTrim.receiveShadow = true;
  group.add(platTrim);

  // four tall pillars
  for (const [px, pz] of [[-11, -11], [11, -11], [-11, 11], [11, 11]] as const) {
    addBox(px - 0.9, px + 0.9, pz - 0.9, pz + 0.9, 4.6, wallMat);
    const cap = new THREE.Mesh(new THREE.BoxGeometry(2.3, 0.35, 2.3), darkMat);
    cap.position.set(px, 4.75, pz);
    cap.castShadow = true;
    group.add(cap);
  }

  // sandbag lines (low cover, h≈1.05)
  const sandbags = (minX: number, maxX: number, minZ: number, maxZ: number) => {
    addBox(minX, maxX, minZ, maxZ, 1.05, bagMat);
    // rounded bag look: row of capsules on top
    const len = Math.max(maxX - minX, maxZ - minZ);
    const horizontal = maxX - minX > maxZ - minZ;
    for (let i = 0; i < len / 0.9; i++) {
      const bag = new THREE.Mesh(new THREE.CapsuleGeometry(0.26, 0.5, 3, 6), bagMat);
      bag.rotation.z = Math.PI / 2;
      if (!horizontal) bag.rotation.y = Math.PI / 2;
      const t = -len / 2 + 0.5 + i * 0.9;
      bag.position.set(horizontal ? (minX + maxX) / 2 + t : (minX + maxX) / 2, 1.12, horizontal ? (minZ + maxZ) / 2 : (minZ + maxZ) / 2 + t);
      bag.castShadow = true;
      group.add(bag);
    }
  };
  sandbags(-8, 8, 13.4, 14.6);   // south midfield line
  sandbags(-8, 8, -14.6, -13.4); // north midfield line
  sandbags(-22.6, -21.4, -6, 6); // west flank
  sandbags(21.4, 22.6, -6, 6);   // east flank

  // crates
  const crates: [number, number, number, number][] = [
    [-18, 18, 0, 0], [-16.6, 19.4, 0, 0], [-17.4, 18.6, 1.2, 0], // southwest cluster w/ stack
    [17, -19, 0, 0], [18.6, -17.6, 0, 0],                        // northeast cluster
    [20, 20, 0, 0],                                              // southeast single
    [-19, -17.5, 0, 0],
  ];
  for (const [cx, cz, stack, rot] of crates) {
    const s = 1.25;
    const m = new THREE.Mesh(new THREE.BoxGeometry(s, s, s), woodMat);
    m.position.set(cx, stack + s / 2, cz);
    m.rotation.y = rot;
    m.castShadow = m.receiveShadow = true;
    group.add(m);
    // frame edges
    const edge = new THREE.Mesh(new THREE.BoxGeometry(s + 0.04, 0.1, s + 0.04), darkMat);
    edge.position.set(cx, stack + s - 0.05, cz);
    group.add(edge);
    if (stack === 0) colliders.push({ minX: cx - s / 2, maxX: cx + s / 2, minZ: cz - s / 2, maxZ: cz + s / 2, height: s });
    else colliders.push({ minX: cx - s / 2, maxX: cx + s / 2, minZ: cz - s / 2, maxZ: cz + s / 2, height: stack + s });
  }

  // barrels (small collide)
  for (const [bx, bz] of [[6, 18], [-6, -18], [26, 8], [-26, -8]] as const) {
    const barrel = new THREE.Mesh(new THREE.CylinderGeometry(0.42, 0.42, 1.0, 10), ironMat);
    barrel.position.set(bx, 0.5, bz);
    barrel.castShadow = barrel.receiveShadow = true;
    group.add(barrel);
    colliders.push({ minX: bx - 0.42, maxX: bx + 0.42, minZ: bz - 0.42, maxZ: bz + 0.42, height: 1.0 });
  }

  // scattered stone debris (instanced, no collision)
  const rockGeo = new THREE.DodecahedronGeometry(0.16, 0);
  const rockMat = new THREE.MeshStandardMaterial({ color: 0x6f6a60, roughness: 1 });
  const rocks = new THREE.InstancedMesh(rockGeo, rockMat, 90);
  const dummy = new THREE.Object3D();
  let seed = 7;
  const rand = () => { seed = (seed * 16807) % 2147483647; return seed / 2147483647; };
  for (let i = 0; i < 90; i++) {
    dummy.position.set((rand() - 0.5) * 2 * (HALF - 2), 0.06, (rand() - 0.5) * 2 * (HALF - 2));
    dummy.rotation.set(rand() * 3, rand() * 3, rand() * 3);
    const s = 0.5 + rand() * 1.6;
    dummy.scale.set(s, s * 0.6, s);
    dummy.updateMatrix();
    rocks.setMatrixAt(i, dummy.matrix);
  }
  rocks.receiveShadow = true;
  group.add(rocks);

  // ---------- lighting ----------
  const hemi = new THREE.HemisphereLight(0xa8c0e0, 0x5a5040, 1.15);
  group.add(hemi);
  const sun = new THREE.DirectionalLight(0xffe9c4, 2.9);
  sun.position.set(28, 42, 18);
  sun.castShadow = true;
  sun.shadow.mapSize.set(2048, 2048);
  sun.shadow.camera.left = -46;
  sun.shadow.camera.right = 46;
  sun.shadow.camera.top = 46;
  sun.shadow.camera.bottom = -46;
  sun.shadow.camera.far = 120;
  sun.shadow.bias = -0.0006;
  group.add(sun);
  // warm gate braziers (no shadows)
  const brazier = (x: number, z: number) => {
    const light = new THREE.PointLight(0xff9a3c, 12, 14, 1.8);
    light.position.set(x, 2.4, z);
    group.add(light);
    const bowl = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.18, 0.35, 8), ironMat);
    bowl.position.set(x, 2.1, z);
    group.add(bowl);
  };
  brazier(-4.4, -HALF + 1.2);
  brazier(4.4, -HALF + 1.2);

  // ---------- waypoints & spawns ----------
  const waypoints = [
    { x: 0, z: 9 }, { x: 8, z: 4 }, { x: -8, z: 4 }, { x: 9, z: -8 }, { x: -9, z: -8 },
    { x: 0, z: -9 }, { x: 17, z: 0 }, { x: -17, z: 0 }, { x: 14, z: 14 }, { x: -14, z: 14 },
    { x: 14, z: -14 }, { x: -14, z: -14 }, { x: 0, z: 20 }, { x: 0, z: -20 },
    { x: HALF + 5, z: 0 }, { x: -HALF - 5, z: 0 }, // inside the two arch rooms
  ];
  const spawns = {
    blue: [new THREE.Vector3(0, 0, 26), new THREE.Vector3(-7, 0, 27), new THREE.Vector3(7, 0, 27)],
    red: [new THREE.Vector3(0, 0, -26), new THREE.Vector3(-7, 0, -27), new THREE.Vector3(7, 0, -27), new THREE.Vector3(-3, 0, -24), new THREE.Vector3(3, 0, -24)],
  };

  return { group, colliders, waypoints, spawns, wallHalf: HALF };
}
