/**
 * quality.ts — graphics tiers + adaptive governor. No Three.js dependency, so the logic is unit-testable.
 *
 * Goal: hold a stable >= 30 FPS on mid-range phones (Mali-G52 / Adreno 610 class).
 * The governor first lowers render resolution (cheap, invisible), and only when the resolution floor is
 * reached does it drop a whole tier (draw distance, props, particles, traffic).
 */

export type QualityMode = "AUTO" | "HIGH" | "BALANCED" | "ECO";

export interface QualityTier {
  name: "high" | "medium" | "low";
  /** Upper bound for devicePixelRatio-based render scale. */
  maxPixelRatio: number;
  /** Lower bound the governor may scale down to. */
  minPixelRatio: number;
  /** Fog far plane / camera far (metres). */
  viewDistance: number;
  /** Prop chunks farther than this from the camera are hidden (metres). */
  propDistance: number;
  /** Prop density multiplier 0..1 (applied when the world is built). */
  propDensity: number;
  weatherParticles: number;
  smokeParticles: number;
  trafficCars: number;
  skidMarks: boolean;
  clouds: boolean;
  /** Frame cap in FPS. 0 = uncapped (follow display refresh). */
  fpsCap: number;
}

export const TIERS: readonly QualityTier[] = [
  { name: "high", maxPixelRatio: 1.75, minPixelRatio: 0.9, viewDistance: 520, propDistance: 360, propDensity: 1, weatherParticles: 420, smokeParticles: 96, trafficCars: 8, skidMarks: true, clouds: true, fpsCap: 0 },
  { name: "medium", maxPixelRatio: 1.25, minPixelRatio: 0.7, viewDistance: 400, propDistance: 280, propDensity: 0.72, weatherParticles: 260, smokeParticles: 64, trafficCars: 5, skidMarks: true, clouds: true, fpsCap: 0 },
  { name: "low", maxPixelRatio: 1, minPixelRatio: 0.55, viewDistance: 300, propDistance: 200, propDensity: 0.45, weatherParticles: 120, smokeParticles: 32, trafficCars: 3, skidMarks: false, clouds: false, fpsCap: 30 },
] as const;

export interface DeviceHints {
  cores: number;
  memoryGb: number;
  mobile: boolean;
  dpr: number;
}

/** Initial tier guess from coarse device hints (refined by the governor at runtime). */
export function initialTierIndex(h: DeviceHints): number {
  if (!h.mobile) return 0;
  if (h.memoryGb > 0 && h.memoryGb <= 3) return 2;
  if (h.cores > 0 && h.cores <= 4) return 2;
  if (h.cores <= 6 || (h.memoryGb > 0 && h.memoryGb <= 4)) return 1;
  return 1; // even flagship phones start at medium; the governor promotes after a stable window
}

export interface GovernorState {
  tier: number;
  pixelRatio: number;
}

export type GovernorEvent = "none" | "resolution" | "tier-down" | "tier-up";

/**
 * Feed it one frame time (ms) per rendered frame. It keeps an exponential average and reacts on a slow clock
 * so single GC hiccups never trigger a downgrade.
 */
export class QualityGovernor {
  tier: number;
  pixelRatio: number;
  avgMs = 16.7;
  private sinceChange = 0;
  private goodTime = 0;
  private badTime = 0;
  private readonly targetMs: number;

  /** @param targetFps the FPS the governor defends (30 default for phones). */
  constructor(startTier: number, private maxPR: number, targetFps = 30) {
    this.tier = Math.max(0, Math.min(TIERS.length - 1, startTier));
    this.targetMs = 1000 / targetFps;
    this.pixelRatio = Math.min(this.maxPR, TIERS[this.tier].maxPixelRatio);
  }

  get current(): QualityTier { return TIERS[this.tier]; }

  get ceiling(): number { return Math.min(this.maxPR, this.current.maxPixelRatio); }

  /** Force a tier (user choice). Resets the history. */
  setTier(index: number): void {
    this.tier = Math.max(0, Math.min(TIERS.length - 1, index));
    this.pixelRatio = Math.min(this.ceiling, Math.max(this.current.minPixelRatio, this.pixelRatio));
    this.reset();
  }

  reset(): void {
    this.sinceChange = 0; this.goodTime = 0; this.badTime = 0;
  }

  /**
   * @param frameMs time between two rendered frames.
   * @param cappedMs the frame interval implied by the FPS cap (0 when uncapped); used so that a deliberate
   *                 30 FPS cap is not mistaken for slowness.
   */
  sample(frameMs: number, cappedMs = 0): GovernorEvent {
    // ignore tab-switch / load stalls
    if (frameMs > 250) return "none";
    this.avgMs += (frameMs - this.avgMs) * 0.08;
    const dt = frameMs / 1000;
    this.sinceChange += dt;
    if (this.sinceChange < 1.2) return "none"; // settle time after every change

    const budget = Math.max(this.targetMs, cappedMs);
    // Uncapped: defend ~32 FPS average so dips still stay >= 30. Capped: only react when the cap is being missed.
    const slow = this.avgMs > budget * (cappedMs ? 1.12 : 0.93);
    const fast = this.avgMs < Math.max(18.5, budget * 0.58) && !cappedMs; // clearly > 54 FPS

    if (slow) { this.badTime += dt; this.goodTime = 0; }
    else if (fast) { this.goodTime += dt; this.badTime = Math.max(0, this.badTime - dt); }
    else { this.goodTime = Math.max(0, this.goodTime - dt * 0.5); this.badTime = Math.max(0, this.badTime - dt); }

    if (this.badTime > 0.9) {
      this.badTime = 0;
      const floor = this.current.minPixelRatio;
      if (this.pixelRatio > floor + 0.02) {
        this.pixelRatio = Math.max(floor, this.pixelRatio - 0.12);
        this.sinceChange = 0;
        return "resolution";
      }
      if (this.tier < TIERS.length - 1) {
        this.tier++;
        this.pixelRatio = Math.min(this.ceiling, Math.max(this.current.minPixelRatio, this.pixelRatio));
        this.sinceChange = 0;
        this.avgMs = this.targetMs; // give the new tier a fair start
        return "tier-down";
      }
      return "none";
    }

    if (this.goodTime > 5) {
      this.goodTime = 0;
      if (this.pixelRatio < this.ceiling - 0.02) {
        this.pixelRatio = Math.min(this.ceiling, this.pixelRatio + 0.08);
        this.sinceChange = 0;
        return "resolution";
      }
      if (this.tier > 0 && this.pixelRatio >= this.ceiling - 0.02 && this.avgMs < this.targetMs * 0.5) {
        this.tier--;
        this.sinceChange = 0;
        return "tier-up";
      }
    }
    return "none";
  }
}

export function modeToTier(mode: QualityMode, auto: number): number {
  if (mode === "HIGH") return 0;
  if (mode === "BALANCED") return 1;
  if (mode === "ECO") return 2;
  return auto;
}
