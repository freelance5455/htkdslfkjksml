export type Season = "spring" | "summer" | "autumn" | "winter";
export type GameMode = "free" | "race";
export type RegionId = "switzerland" | "netherlands" | "finland" | "britain";

export interface RaceDef {
  id: string;
  name: string;
  shortName: string;
  description: string;
  route: Array<[number, number]>;
  timeLimit: number;
  aiPace: number;
  reward: number;
  accent: string;
  region: RegionId;
}

export interface RegionDef {
  id: RegionId;
  name: string;
  shortName: string;
  flag: string;
  description: string;
  defaultSeason: Season;
  accent: string;
  // Visual / terrain parameters
  sky: number;
  fog: number;
  ground: number;
  foliage: number;
  road: number;
  gripBias: number;
  hillScale: number;
  hillFreq: number;
  highlandBias: number;
}

export const SEASONS: Season[] = ["spring", "summer", "autumn", "winter"];

export const SEASON_INFO: Record<Season, {
  label: string;
  weather: string;
  grip: number;
  sky: number;
  fog: number;
  ground: number;
  foliage: number;
  road: number;
}> = {
  spring: { label: "Spring", weather: "Light rain", grip: 0.88, sky: 0x7eabbc, fog: 0x9bb8bd, ground: 0x4f7544, foliage: 0x5a9450, road: 0x2f3639 },
  summer: { label: "Summer", weather: "Clear", grip: 1, sky: 0x5aa9d6, fog: 0x96c4dc, ground: 0x5d7a42, foliage: 0x367535, road: 0x353838 },
  autumn: { label: "Autumn", weather: "Overcast", grip: 0.82, sky: 0xa88f6e, fog: 0xb09e86, ground: 0x6f6438, foliage: 0xc05a28, road: 0x383431 },
  winter: { label: "Winter", weather: "Snow", grip: 0.62, sky: 0x9eb0c0, fog: 0xcdd6de, ground: 0xd0dce0, foliage: 0x7a8a84, road: 0x5e6a74 },
};

/** Real-world inspired regions for free roam & events */
export const REGIONS: RegionDef[] = [
  {
    id: "switzerland",
    name: "Switzerland",
    shortName: "CH",
    flag: "🇨🇭",
    description: "Alpine passes · steep climbs · crisp air",
    defaultSeason: "summer",
    accent: "#e74c3c",
    sky: 0x6aa8d4,
    fog: 0xa8c8e0,
    ground: 0x4a6b3a,
    foliage: 0x2f5c2a,
    road: 0x3a3d40,
    gripBias: 1.02,
    hillScale: 2.4,
    hillFreq: 1.35,
    highlandBias: 18,
  },
  {
    id: "netherlands",
    name: "Netherlands",
    shortName: "NL",
    flag: "🇳🇱",
    description: "Flat dykes · canal roads · wind farms",
    defaultSeason: "spring",
    accent: "#f39c12",
    sky: 0x7eb8d0,
    fog: 0xb0cdd8,
    ground: 0x5a7a48,
    foliage: 0x3d6e38,
    road: 0x3c4042,
    gripBias: 0.98,
    hillScale: 0.22,
    hillFreq: 0.55,
    highlandBias: 0,
  },
  {
    id: "finland",
    name: "Finland",
    shortName: "FI",
    flag: "🇫🇮",
    description: "Lakes · dense forest · long twilight",
    defaultSeason: "autumn",
    accent: "#3498db",
    sky: 0x6a90a8,
    fog: 0x9ab0c0,
    ground: 0x3d5a3a,
    foliage: 0x2a4a28,
    road: 0x35383a,
    gripBias: 0.94,
    hillScale: 1.1,
    hillFreq: 0.9,
    highlandBias: 4,
  },
  {
    id: "britain",
    name: "Britain",
    shortName: "GB",
    flag: "🇬🇧",
    description: "Festival lanes · villages · highlands",
    defaultSeason: "summer",
    accent: "#00e5a8",
    sky: 0x5aa9d6,
    fog: 0x96c4dc,
    ground: 0x5d7a42,
    foliage: 0x367535,
    road: 0x353838,
    gripBias: 1.0,
    hillScale: 1.0,
    hillFreq: 1.0,
    highlandBias: 8,
  },
];

export const RACES: RaceDef[] = [
  {
    id: "swiss-pass",
    name: "Alpine Pass",
    shortName: "Alps",
    description: "Steep · technical · 3 rivals",
    route: [[0, 160], [-40, 100], [-90, 40], [-140, -20], [-100, -90], [-30, -140], [50, -120], [90, -50], [60, 40], [0, 160]],
    timeLimit: 100,
    aiPace: 24,
    reward: 2000,
    accent: "#e74c3c",
    region: "switzerland",
  },
  {
    id: "dutch-canal",
    name: "Canal Sprint",
    shortName: "Canal",
    description: "Fast flats · 3 rivals · open roads",
    route: [[0, 180], [0, 90], [40, 20], [100, -40], [160, -100], [120, -180], [40, -200], [-40, -160], [-20, -60], [0, 180]],
    timeLimit: 85,
    aiPace: 27,
    reward: 1600,
    accent: "#f39c12",
    region: "netherlands",
  },
  {
    id: "finnish-lake",
    name: "Lake Circuit",
    shortName: "Lakes",
    description: "Forest mix · 3 rivals · grip test",
    route: [[20, 150], [80, 110], [140, 50], [120, -40], [60, -110], [-20, -150], [-90, -100], [-120, -20], [-80, 60], [20, 150]],
    timeLimit: 95,
    aiPace: 25.5,
    reward: 1800,
    accent: "#3498db",
    region: "finland",
  },
  {
    id: "village",
    name: "Village Sprint",
    shortName: "Village",
    description: "Fast lanes · 3 rivals · 8 gates",
    route: [[0, 180], [0, 110], [-20, 50], [-70, 0], [-130, -40], [-170, -100], [-160, -170], [-100, -220], [0, -240]],
    timeLimit: 75,
    aiPace: 25,
    reward: 1200,
    accent: "#ffb347",
    region: "britain",
  },
  {
    id: "forest",
    name: "Blackpine Trail",
    shortName: "Forest",
    description: "Mixed surface · 3 rivals · 8 gates",
    route: [[40, 160], [70, 140], [140, 100], [190, 40], [180, -40], [130, -100], [150, -170], [220, -210]],
    timeLimit: 85,
    aiPace: 26.5,
    reward: 1600,
    accent: "#75dfad",
    region: "britain",
  },
  {
    id: "highlands",
    name: "Highland Circuit",
    shortName: "Highlands",
    description: "Technical · 3 rivals · 13 gates",
    route: [[-40, 165], [-70, 150], [-150, 110], [-210, 50], [-220, -30], [-180, -100], [-100, -160], [0, -180], [90, -160], [150, -100], [190, -20], [160, 60], [90, 130], [-40, 165]],
    timeLimit: 120,
    aiPace: 27.5,
    reward: 2200,
    accent: "#9db9ff",
    region: "britain",
  },
];

export const CAR_COLORS = [0x00b7d4, 0xff5b3f, 0xf3cf4a, 0x8b5cf6, 0xe8edf0];

export const TUNING = {
  maxSpeed: 58,
  reverseSpeed: 14,
  acceleration: 28,
  brake: 48,
  drag: 0.28,
  steerRate: 2.15,
  roadGrip: 9.4,
  offroadGrip: 3.6,
  boostAcceleration: 32,
  worldLimit: 410,
  mass: 1450,
  wheelbase: 2.65,
  trackWidth: 1.55,
  cgHeight: 0.48,
  tireGripPeak: 1.35,
  slipAngleSoftness: 0.55,
  handbrakeGripMul: 0.18,
  surfaceTractionLoss: 0.42,
  suspensionStiffness: 42,
  suspensionDamping: 9.5,
  bodyRollFactor: 0.38,
  bodyPitchFactor: 0.22,
  downforce: 0.0018,
} as const;

export function mulberry32(seed: number): () => number {
  return () => {
    let t = seed += 0x6d2b79f5;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function getRegion(id: RegionId): RegionDef {
  return REGIONS.find((r) => r.id === id) ?? REGIONS[0];
}
