/**
 * spatial.ts — Three.js-free helpers: terrain height field, road index, obstacle grid, colour maths.
 * Kept separate from rendering code so the maths can be unit-tested headlessly.
 */

export const WORLD_HALF = 425;

export interface Lake { x: number; z: number; r: number }

export interface HeightParams {
  hillScale: number;
  hillFreq: number;
  highlandBias: number;
}

export function smoothstep(t: number): number {
  const c = t < 0 ? 0 : t > 1 ? 1 : t;
  return c * c * (3 - 2 * c);
}

export class Heightfield {
  /** Water surface height; -Infinity when the region has no water. */
  waterY = -Infinity;
  lakes: Lake[] = [];
  constructor(public params: HeightParams) {}

  /** Terrain height without lake carving (used to place roads before the water level is known). */
  baseHeight(x: number, z: number): number {
    const { hillFreq: f, hillScale: s, highlandBias } = this.params;
    const rolling =
      Math.sin(x * 0.018 * f) * 2.1 * s +
      Math.cos(z * 0.015 * f) * 1.8 * s +
      Math.sin((x + z) * 0.009 * f) * 2.4 * s;
    const highland = Math.max(0, (-x - 90) / 180) * highlandBias;
    return rolling + highland;
  }

  heightAt(x: number, z: number): number {
    let h = this.baseHeight(x, z);
    if (this.lakes.length && this.waterY > -1e8) {
      for (let i = 0; i < this.lakes.length; i++) {
        const lake = this.lakes[i];
        const d = Math.hypot(x - lake.x, z - lake.z);
        const outer = lake.r * 1.3;
        if (d >= outer) continue;
        const s = smoothstep((outer - d) / (outer - lake.r * 0.55));
        h = h * (1 - s) + (this.waterY - 3.2) * s;
      }
    }
    return h;
  }

  isWater(x: number, z: number): boolean {
    return this.waterY > -1e8 && this.heightAt(x, z) < this.waterY - 0.12;
  }
}

/** Uniform-grid index over sampled road centre-line points. */
export class RoadIndex {
  private cells = new Map<number, number[]>();
  constructor(private cell = 28) {}

  private key(cx: number, cz: number): number { return (cx + 64) * 256 + (cz + 64); }

  clear(): void { this.cells.clear(); }

  add(x: number, z: number): void {
    const k = this.key(Math.floor(x / this.cell), Math.floor(z / this.cell));
    let list = this.cells.get(k);
    if (!list) { list = []; this.cells.set(k, list); }
    list.push(x, z);
  }

  /** True when (x,z) is within `radius` metres of a road centre-line sample. */
  near(x: number, z: number, radius: number): boolean {
    const r2 = radius * radius;
    const span = Math.ceil(radius / this.cell);
    const cx = Math.floor(x / this.cell), cz = Math.floor(z / this.cell);
    for (let dx = -span; dx <= span; dx++) for (let dz = -span; dz <= span; dz++) {
      const values = this.cells.get(this.key(cx + dx, cz + dz));
      if (!values) continue;
      for (let i = 0; i < values.length; i += 2) {
        const px = values[i] - x, pz = values[i + 1] - z;
        if (px * px + pz * pz < r2) return true;
      }
    }
    return false;
  }
}

export interface Obstacle { x: number; z: number; radius: number }

/** Uniform grid of circular obstacles; query cost is independent of the total obstacle count. */
export class ObstacleGrid {
  private cells = new Map<number, Obstacle[]>();
  count = 0;
  constructor(private cell = 24) {}

  private key(cx: number, cz: number): number { return (cx + 64) * 256 + (cz + 64); }

  clear(): void { this.cells.clear(); this.count = 0; }

  add(o: Obstacle): void {
    const k = this.key(Math.floor(o.x / this.cell), Math.floor(o.z / this.cell));
    let list = this.cells.get(k);
    if (!list) { list = []; this.cells.set(k, list); }
    list.push(o);
    this.count++;
  }

  /** Visit obstacles in the 3×3 cells around (x,z). The callback may return true to stop. */
  forEachNear(x: number, z: number, fn: (o: Obstacle) => boolean | void): void {
    const cx = Math.floor(x / this.cell), cz = Math.floor(z / this.cell);
    for (let dx = -1; dx <= 1; dx++) for (let dz = -1; dz <= 1; dz++) {
      const list = this.cells.get(this.key(cx + dx, cz + dz));
      if (!list) continue;
      for (let i = 0; i < list.length; i++) if (fn(list[i]) === true) return;
    }
  }

  /** True when any obstacle (plus `margin`) covers the point. */
  blocked(x: number, z: number, margin: number): boolean {
    let hit = false;
    this.forEachNear(x, z, (o) => {
      const r = o.radius + margin;
      const dx = o.x - x, dz = o.z - z;
      if (dx * dx + dz * dz < r * r) { hit = true; return true; }
      return false;
    });
    return hit;
  }
}

/** Linear mix of two 0xRRGGBB colours. */
export function mixHex(a: number, b: number, t: number): number {
  const k = t < 0 ? 0 : t > 1 ? 1 : t;
  const ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
  const br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
  const r = Math.round(ar + (br - ar) * k), g = Math.round(ag + (bg - ag) * k), bl = Math.round(ab + (bb - ab) * k);
  return (r << 16) | (g << 8) | bl;
}
