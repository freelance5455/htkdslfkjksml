const DRIVE_KEYS = new Set(["KeyW", "KeyA", "KeyS", "KeyD", "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight", "Space", "ShiftLeft", "ShiftRight"]);

export class Input {
  moveX = 0;
  moveZ = 0;
  throttle = 0;
  brake = 0;
  handbrake = false;
  boost = false;
  readonly actions = new Set<string>();
  private held = new Set<string>();
  private virtual = new Set<string>();
  private pointers = new Map<number, string>();
  private unsubscribe: Array<() => void> = [];

  constructor(private target: HTMLElement) {
    const on = <T extends Event>(el: Window | Document | HTMLElement, type: string, fn: (e: T) => void, opts?: AddEventListenerOptions) => {
      const handler = fn as EventListener;
      el.addEventListener(type, handler, opts);
      this.unsubscribe.push(() => el.removeEventListener(type, handler, opts));
    };
    on<KeyboardEvent>(window, "keydown", (e) => {
      if (DRIVE_KEYS.has(e.code)) e.preventDefault();
      if (!e.repeat) this.actions.add(e.code);
      this.held.add(e.code);
      this.recompute();
    });
    on<KeyboardEvent>(window, "keyup", (e) => {
      this.held.delete(e.code);
      this.recompute();
    });
    on(window, "blur", () => this.resetAll());
    on(document, "visibilitychange", () => { if (document.hidden) this.resetAll(); });
    on<PointerEvent>(document, "pointerdown", (e) => {
      const el = (e.target as HTMLElement).closest<HTMLElement>("[data-control]");
      if (!el) return;
      e.preventDefault();
      const control = el.dataset.control!;
      this.pointers.set(e.pointerId, control);
      this.virtual.add(control);
      el.classList.add("pressed");
      el.setPointerCapture?.(e.pointerId);
      this.recompute();
    }, { passive: false });
    const release = (e: PointerEvent) => {
      const control = this.pointers.get(e.pointerId);
      if (!control) return;
      this.pointers.delete(e.pointerId);
      if (![...this.pointers.values()].includes(control)) this.virtual.delete(control);
      document.querySelectorAll(`[data-control="${control}"]`).forEach((el) => el.classList.remove("pressed"));
      this.recompute();
    };
    on<PointerEvent>(document, "pointerup", release);
    on<PointerEvent>(document, "pointercancel", release);
    on(target, "contextmenu", (e) => e.preventDefault());
  }

  pollGamepad(): void {
    const pad = navigator.getGamepads?.()[0];
    if (!pad) return;
    const axis = Math.abs(pad.axes[0] ?? 0) > 0.12 ? pad.axes[0] : 0;
    if (Math.abs(axis) > Math.abs(this.moveX)) this.moveX = axis;
    this.throttle = Math.max(this.throttle, pad.buttons[7]?.value ?? 0);
    this.brake = Math.max(this.brake, pad.buttons[6]?.value ?? 0);
    this.handbrake ||= !!pad.buttons[0]?.pressed;
    this.boost ||= !!pad.buttons[1]?.pressed;
    this.moveZ = this.throttle - this.brake;
  }

  consumeAction(code: string): boolean {
    const value = this.actions.has(code);
    if (value) this.actions.delete(code);
    return value;
  }

  dispose(): void {
    for (const off of this.unsubscribe) off();
    this.unsubscribe = [];
    this.resetAll();
  }

  private resetAll(): void {
    this.held.clear();
    this.virtual.clear();
    this.pointers.clear();
    this.actions.clear();
    this.recompute();
  }

  private recompute(): void {
    const left = this.held.has("KeyA") || this.held.has("ArrowLeft") || this.virtual.has("left");
    const right = this.held.has("KeyD") || this.held.has("ArrowRight") || this.virtual.has("right");
    const forward = this.held.has("KeyW") || this.held.has("ArrowUp") || this.virtual.has("throttle");
    const back = this.held.has("KeyS") || this.held.has("ArrowDown") || this.virtual.has("brake");
    this.moveX = Number(right) - Number(left);
    this.throttle = Number(forward);
    this.brake = Number(back);
    this.moveZ = this.throttle - this.brake;
    this.handbrake = this.held.has("ShiftLeft") || this.held.has("ShiftRight") || this.virtual.has("handbrake");
    this.boost = this.held.has("Space") || this.virtual.has("boost");
  }
}
