/**
 * input.ts — estado compartilhado dos controles touch (os botões DOM escrevem aqui;
 * o teclado é lido pelo Phaser diretamente na GameScene).
 */
export class TouchState {
  left = false;
  right = false;
  jump = false;
  attack = false;
  magic = false;
  /** Pulsado uma vez pelo botão de pausa touch; consumido pela GameScene. */
  pause = false;

  reset(): void {
    this.left = this.right = this.jump = this.attack = this.magic = false;
    this.pause = false;
  }
}

export const touchState = new TouchState();
