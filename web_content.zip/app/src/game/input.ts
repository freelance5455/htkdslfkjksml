/**
 * input.ts — unified input for desktop + mobile.
 *
 * The MobileHUDController feeds touch state (joystick axes, held buttons, look drags)
 * into the public fields; desktop keyboard/mouse writes the same fields. Game systems
 * read a single source of truth each frame. Conventions (fixed, sync verify-game.mjs):
 *   moveZ +1 = forward · moveX +1 = right · look yaw - = turn right · pitch + = look up
 */

import { INPUT_CONFIG } from "./config";

const KEYMAP: Record<string, [axis: "moveX" | "moveZ", dir: 1 | -1]> = {
  KeyW: ["moveZ", 1], ArrowUp: ["moveZ", 1],
  KeyS: ["moveZ", -1], ArrowDown: ["moveZ", -1],
  KeyA: ["moveX", -1], ArrowLeft: ["moveX", -1],
  KeyD: ["moveX", 1], ArrowRight: ["moveX", 1],
};

export class GameInput {
  /** Keyboard-held axes (joystick from the HUD is merged on top in axes()). */
  keyX = 0;
  keyZ = 0;
  /** Touch joystick axes, written by the HUD controller. */
  joyX = 0;
  joyY = 0;

  /** Look deltas accumulated since last consume (radians). */
  private yawD = 0;
  private pitchD = 0;

  /** Held-state buttons (desktop mouse + touch buttons both write these). */
  fireHeld = false;
  aimHeld = false;

  /** Instant actions queued since last frame; consume via takeAction(). */
  private actionQueue = new Set<string>();

  /** Whether the mouse is pointer-locked (desktop). */
  pointerLocked = false;

  private held = new Set<string>();
  private unsubscribe: Array<() => void> = [];
  /** Touch-look drag is fed by the HUD (canvas drag); separate from joystick. */
  lookTouchId: number | null = null;
  lastLookX = 0;
  lastLookY = 0;

  constructor(private target: HTMLElement) {
    const on = <T extends Event>(
      el: Window | Document | HTMLElement,
      type: string,
      fn: (e: T) => void,
      opts?: AddEventListenerOptions,
    ) => {
      const handler = fn as EventListener;
      el.addEventListener(type, handler, opts);
      this.unsubscribe.push(() => el.removeEventListener(type, handler, opts));
    };

    on<KeyboardEvent>(window, "keydown", (e) => {
      if (e.repeat) return;
      const m = KEYMAP[e.code];
      if (m) this.held.add(e.code);
      this.actionQueue.add(e.code);
      this.recompute();
      // keep the game from scrolling / triggering browser UI while playing
      if (["Space", "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight", "Tab"].includes(e.code)) e.preventDefault();
    });
    on<KeyboardEvent>(window, "keyup", (e) => { this.held.delete(e.code); this.recompute(); });
    on(window, "blur", () => this.resetAll());
    on(document, "visibilitychange", () => { if (document.hidden) this.resetAll(); });

    // pointer lock drives desktop mouse-look; clicking the canvas requests it
    on<MouseEvent>(target, "mousedown", (e) => {
      if (e.button === 0) { this.fireHeld = true; this.actionQueue.add("Mouse0"); }
      if (e.button === 2) this.aimHeld = true;
    });
    on<MouseEvent>(window, "mouseup", (e) => {
      if (e.button === 0) this.fireHeld = false;
      if (e.button === 2) this.aimHeld = false;
    });
    on<MouseEvent>(window, "contextmenu", (e) => e.preventDefault());
    on<PointerEvent>(document, "pointerlockchange", () => {
      this.pointerLocked = document.pointerLockElement === target;
    });
    on<MouseEvent>(window, "mousemove", (e) => {
      if (!this.pointerLocked) return;
      const sx = INPUT_CONFIG.MOUSE_SENS_X * (INPUT_CONFIG.INVERT_X ? -1 : 1);
      const sy = INPUT_CONFIG.MOUSE_SENS_Y * (INPUT_CONFIG.INVERT_Y ? -1 : 1);
      // mouse right => turn right => yaw decreases (right-handed); mouse up => pitch increases
      this.yawD -= e.movementX * sx;
      this.pitchD += -e.movementY * sy;
    });
  }

  /** HUD touch-look: call with movement deltas in pixels. */
  feedLook(dxPx: number, dyPx: number): void {
    const s = INPUT_CONFIG.TOUCH_LOOK_SENS;
    this.yawD -= dxPx * s * (INPUT_CONFIG.INVERT_X ? -1 : 1);
    this.pitchD += -dyPx * s * (INPUT_CONFIG.INVERT_Y ? -1 : 1);
  }

  queueAction(id: string): void { this.actionQueue.add(id); }

  takeAction(id: string): boolean {
    const has = this.actionQueue.has(id);
    if (has) this.actionQueue.delete(id);
    return has;
  }

  /** Merged movement axes (keyboard + joystick), clamped to [-1, 1]. */
  axes(): { x: number; z: number } {
    const x = clamp(this.keyX + this.joyX, -1, 1);
    const z = clamp(this.keyZ - this.joyY, -1, 1); // joystick up (joyY negative) = forward
    return { x, z };
  }

  consumeLook(): { yaw: number; pitch: number } {
    const r = { yaw: this.yawD, pitch: this.pitchD };
    this.yawD = 0;
    this.pitchD = 0;
    return r;
  }

  requestPointerLock(): void {
    if (!this.pointerLocked) this.target.requestPointerLock?.();
  }
  exitPointerLock(): void {
    if (this.pointerLocked) document.exitPointerLock?.();
  }

  resetAll(): void {
    this.held.clear();
    this.fireHeld = false;
    this.aimHeld = false;
    this.joyX = 0;
    this.joyY = 0;
    this.recompute();
  }

  dispose(): void {
    for (const off of this.unsubscribe) off();
    this.unsubscribe = [];
    this.actionQueue.clear();
    this.resetAll();
  }

  private recompute(): void {
    let x = 0, z = 0;
    for (const code of this.held) {
      const m = KEYMAP[code];
      if (m) { if (m[0] === "moveX") x += m[1]; else z += m[1]; }
    }
    this.keyX = clamp(x, -1, 1);
    this.keyZ = clamp(z, -1, 1);
  }
}

function clamp(v: number, lo: number, hi: number): number {
  return v < lo ? lo : v > hi ? hi : v;
}
