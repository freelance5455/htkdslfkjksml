import * as THREE from "three";
export function createAsset(three: typeof THREE, options?: { state?: string; states?: string; sharedResources?: boolean }): Promise<THREE.Group>;
