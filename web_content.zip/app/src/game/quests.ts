/**
 * quests.ts — main quest chain, side quests, NPCs and dialogues.
 * Story: Aren wakes in the ruined temple with no memory, finds the Dawnblade,
 * and journeys to uncover the curse of the Shadow King.
 */

export interface DialogueLine { speaker: string; text: string; }
export interface DialogueChoice { text: string; effect: string; }

export interface NpcDef {
  id: string;
  name: string;
  role: string;
  x: number; z: number;
  color: number;
  hood?: boolean;
  dialogues: (qs: QuestState) => { lines: DialogueLine[]; choices?: DialogueChoice[] }[];
}

export interface QuestState {
  mainStage: number;         // index into MAIN_QUESTS
  side: Record<string, number>; // side quest id -> stage (0 not started, 1 active, 2 done)
  kills: Record<string, number>;
  flags: Record<string, number>;
  choices: Record<string, string>;
  bossesDefeated: string[];
}

export function freshQuestState(): QuestState {
  return { mainStage: 0, side: {}, kills: {}, flags: {}, choices: {}, bossesDefeated: [] };
}

export interface QuestDef {
  id: string;
  name: string;
  desc: string;
  type: "main" | "side";
  objective: (qs: QuestState) => string;
  isDone: (qs: QuestState) => boolean;
}

export const MAIN_QUESTS: QuestDef[] = [
  {
    id: "wake", type: "main", name: "الاستيقاظ",
    desc: "استيقظ آرين في معبد مهجور دون ذاكرة. خذ نصل الفجر من المذبح.",
    objective: () => "خذ نصل الفجر من المذبح",
    isDone: (q) => q.flags["hasSword"] === 1,
  },
  {
    id: "leave", type: "main", name: "خارج الأطلال",
    desc: "غادر المعبد واكتشف ما يحيط بك. اعثر على الناجي الغامض قرب الغابة.",
    objective: () => "اعثر على الناجي قرب الغابة (اتبع الدخان)",
    isDone: (q) => q.flags["metMira"] === 1,
  },
  {
    id: "wolves", type: "main", name: "أسنان الرماد",
    desc: "ذئاب الرماد تحاصر الناجي. اصطد 5 منها لتأمين الطريق.",
    objective: (q) => `اصطد ذئاب الرماد (${Math.min(q.kills["wolf"] ?? 0, 5)}/5)`,
    isDone: (q) => (q.kills["wolf"] ?? 0) >= 5,
  },
  {
    id: "forge", type: "main", name: "نار الحدادة",
    desc: "خذ البلورات إلى الحداد بروم في أطلال المدينة لإيقاد نار الورشة.",
    objective: (q) => `اجمع بلورات النور (${Math.min(q.flags["crystals"] ?? 0, 4)}/4) وأوصلها إلى بروم`,
    isDone: (q) => q.flags["forgeLit"] === 1,
  },
  {
    id: "treant", type: "main", name: "قلب الغابة",
    desc: "ينبض قلب النور داخل ساحة حارس الغابة. اهزمه لاسترداد شظية الذاكرة.",
    objective: () => "اهزم حارس الغابة في قلب غابة الرماد",
    isDone: (q) => q.bossesDefeated.includes("treant"),
  },
  {
    id: "memory", type: "main", name: "شظايا الحقيقة",
    desc: "استعد ذكرى أولى: كان آرين حارساً لقلب النور... وأحد أفراد حرس الملك نفسه.",
    objective: () => "تحدث مع ميرا واعبر إلى الشمال",
    isDone: (q) => q.flags["memory2"] === 1,
  },
  {
    id: "stones", type: "main", name: "عبّادات الطاقة",
    desc: "افتح طريق القلعة: أشعل ثلاثة أعمدة طاقة في المدينة المدمرة والجليد والمستنقع.",
    objective: (q) => `أشعل الأعمدة (${q.flags["pillar_city"] ?? 0}/${q.flags["pillar_ice"] ?? 0}/${q.flags["pillar_swamp"] ?? 0} — تحتاج 3)`,
    isDone: (q) => (q.flags["pillar_city"] ?? 0) + (q.flags["pillar_ice"] ?? 0) + (q.flags["pillar_swamp"] ?? 0) >= 3,
  },
  {
    id: "castle", type: "main", name: "بوابة الظلال",
    desc: "البوابة مفتوحة. اعبر ساحة الظلال وواجه ملك الظلال في قلعته.",
    objective: () => "اهزم ملك الظلال",
    isDone: (q) => q.bossesDefeated.includes("shadowking"),
  },
  {
    id: "end", type: "main", name: "الحقيقة",
    desc: "اللعنة انكسرَت والذاكرة عادت. اختر مصير مملكة إيراث.",
    objective: () => "اختر نهاية قصتك",
    isDone: () => false,
  },
];

export const SIDE_QUESTS: QuestDef[] = [
  {
    id: "herbs", type: "side", name: "دواء الغائب",
    desc: "الجاسوس إيريس يحتاج 5 أعشاب علاجية من المستنقع لجرحه.",
    objective: (q) => `اجمع الأعشاب العلاجية (${Math.min(q.flags["herbsGiven"] ?? 0, 5)}/5)`,
    isDone: (q) => q.side["herbs"] === 2,
  },
  {
    id: "relics", type: "side", name: "ذاكرة المملكة",
    desc: "العالمة سيلا تبحث عن 3 قطع أثرية من ماضي إيراث. ابحث في الصناديق القديمة.",
    objective: (q) => `اجمع القطع الأثرية (${Math.min(q.flags["relicsGiven"] ?? 0, 3)}/3)`,
    isDone: (q) => q.side["relics"] === 2,
  },
  {
    id: "giants", type: "side", name: "خطر الجبال",
    desc: "عمالقة الجبال ينزحون نحو الممرات الجليدية. اهزم 3 منهم.",
    objective: (q) => `اهزم العمالقة (${Math.min(q.kills["giant"] ?? 0, 3)}/3)`,
    isDone: (q) => q.side["giants"] === 2,
  },
];

export const NPCS: NpcDef[] = [
  {
    id: "mira", name: "ميرا", role: "الناجية الغامضة", x: 24, z: 42, color: 0x4a5a8a, hood: true,
    dialogues: (q) => {
      if (q.flags["metMira"] !== 1) {
        return [{
          lines: [
            { speaker: "ميرا", text: "توقف!... إنسانٌ حيّ؟ بعد كل هذه السنين؟" },
            { speaker: "آرين", text: "أين أنا؟ لا أتذكر شيئاً... لا حتى اسمي." },
            { speaker: "ميرا", text: "مملكة إيراث. أو ما تبقى منها. لعنة ملك الظلال حوّلت كل شيء إلى رماد. أنا ميرا... آخر من تبقى من حراس المعبد." },
            { speaker: "ميرا", text: "هذا السيف بيدك... نصل الفجر! إذن أنت هو من تنبأت به الرؤى. اذهب — ذئاب الرماد تحاصرنا من كل جانب. اصطد خمسة منها وسأخبرك بكل ما أعرف." },
          ],
          choices: [{ text: "سأحميكِ.", effect: "kindMira" }, { text: "ما الذي حدث هنا؟", effect: "curiousMira" }],
        }];
      }
      if ((q.kills["wolf"] ?? 0) < 5) {
        return [{ lines: [{ speaker: "ميرا", text: `الذئاب لا تزال هناك... اصطد ${5 - (q.kills["wolf"] ?? 0)} أخرى وسأفتح لك سرّ الحدادين.` }] }];
      }
      if (q.flags["forgeLit"] !== 1) {
        return [{ lines: [
          { speaker: "ميرا", text: "أحسنت. الآن استمع: في مدينة إيراث المدمرة شمالاً يختبئ الحداد بروم. اجمع له بلورات النور من وحوش الغابة المتوهجة، فورشته وحدها تصقل نصل الفجر." },
        ] }];
      }
      if (q.bossesDefeated.includes("treant")) {
        return [{ lines: [
          { speaker: "ميرا", text: "شظية الذاكرة... رأيت وجهك فيها، لم أكن أعلم. كنتَ من حرس الملك أيام ازدهار إيراث." },
          { speaker: "ميرا", text: "الحقيقة كاملة عند ملك الظلال. أشعل الأعمدة الثلاثة — في المدينة، والجليد، والمستنقع — لتفتح بوابة قلعته. وحذارٍ... قلبُك يعرفه أكثر مما تظن." },
        ] }];
      }
      return [{ lines: [{ speaker: "ميرا", text: "قلب الغابة ينبض في أقصى الغرب... حارسٌ قديم يحمي شظية ذاكرتك الأولى. كُن حذراً." }] }];
    },
  },
  {
    id: "brom", name: "بروم", role: "الحداد", x: 18, z: -222, color: 0x6a4a2a, hood: false,
    dialogues: (q) => {
      if (q.flags["forgeLit"] !== 1) {
        return [{
          lines: [
            { speaker: "بروم", text: "من يطرق باب بروم في زمن الرماد؟... مهلاً، هذا النصل! نصل الفجر نفسه!" },
            { speaker: "بروم", text: "ورشتي بلا نار منذ سقوط المدينة. أحضر لي 4 بلورات نور، وسأعيد إحياء المطرقة والسندان. عندها سأطوّر سلاحك كما يطوّر الحدادون لملوك قدامى." },
          ],
        }];
      }
      return [{ lines: [
        { speaker: "بروم", text: "النار مشتعلة والسندان ينتظر. ضع مواردك على الطاولة وشاهد السحر الحقيقي — حدادة الدماء والعرق، لا تلك الأوهام." },
      ] }];
    },
  },
  {
    id: "irys", name: "إيريس", role: "الجاسوسة الجريحة", x: -36, z: 205, color: 0x3a5a4a, hood: true,
    dialogues: (q) => {
      if (q.side["herbs"] === undefined || q.side["herbs"] === 0) {
        return [{
          lines: [
            { speaker: "إيريس", text: "لا تقترب كثيراً... جرحي يزداد سُمّاً كلما هبّت رياح المستنقع." },
            { speaker: "إيريس", text: "خمس أعشاب علاجية فقط تنقذ حياتي. إن نجوتُ، سأدلّك على كنز العمالقة في الصحراء. أقسم بظلال أسلافي." },
          ],
        }];
      }
      if (q.side["herbs"] === 1 && (q.flags["herbsGiven"] ?? 0) < 5) {
        return [{ lines: [{ speaker: "إيريس", text: `ما زلت تحتاج ${5 - (q.flags["herbsGiven"] ?? 0)} أعشاب... أسرع، أشعر بالبرودة في عظامي.` }] }];
      }
      return [{ lines: [{ speaker: "إيريس", text: "الأعشاب... تشعر بالدفء يعود. ذكري وعدي: ابحث عن هيكل العملاق في صحراء العظام غرباً. تحته يرقد كنز من عصر الأبطال." }] }];
    },
  },
  {
    id: "syla", name: "سيلا", role: "العالمة", x: -28, z: -30, color: 0x5a4a7a, hood: true,
    dialogues: (q) => {
      if (q.side["relics"] === undefined || q.side["relics"] === 0) {
        return [{
          lines: [
            { speaker: "سيلا", text: "أرى أنك تجمع آثار الدمار... أنا سيلا، حفيدة علماء القصر. أبحث عن ذاكرة المملكة قبل أن يبتلعها الظلام." },
            { speaker: "سيلا", text: "ثلاث قطع أثرية تكفي لكشف خريطة الطريق إلى القلعة. ابحث في الصناديق القديمة المنتشرة في الأراضي." },
          ],
        }];
      }
      if (q.side["relics"] === 1 && (q.flags["relicsGiven"] ?? 0) < 3) {
        return [{ lines: [{ speaker: "سيلا", text: `القطع الأثرية... أحتاج ${3 - (q.flags["relicsGiven"] ?? 0)} أخرى. كل قطعة تحكي فصلاً من سقوطنا.` }] }];
      }
      return [{ lines: [
        { speaker: "سيلا", text: "مذهل... خاتم ملك إيراث الأخير بين يدي. خذ هذه القطع من مكتبي — واذكرني حين تكتب الحقيقة من جديد." },
      ] }];
    },
  },
  {
    id: "oldman", name: "الزائر الأعمى", role: "غامض", x: 60, z: -390, color: 0x2a2a35, hood: true,
    dialogues: () => [{
      lines: [
        { speaker: "الزائر الأعمى", text: "آرين... حارسُ القلب. عدتَ أخيراً إلى حيث بدأ كل شيء." },
        { speaker: "الزائر الأعمى", text: "ملكُ الظلال لم يكن شراً دائماً. كان مثلك: يحمل القلب، ويخشى فقدانه. حين اختارت المملكة النور وحده، ابتُلي بالظل وحده." },
        { speaker: "الزائر الأعمى", text: "ادخل. وعندما تنتصر... تذكّر أن لكل نورٍ ظلاً، ولكل ظلٍ قلباً. قرارك عند البوابة سيحدد مصير ما بعد اللعنة." },
      ],
    }],
  },
];

// ---------------- lore notes (hidden messages) ----------------

export const LORE_NOTES: { id: string; x: number; z: number; title: string; text: string }[] = [
  { id: "n1", x: 40, z: -60, title: "رسالة محروقة", text: "«إلى من يجد هذا: القلب ليس في القلعة. القلب في من يحمله. — آخر كاهنة النور»" },
  { id: "n2", x: 30, z: -250, title: "يوميات جندي", text: "«اليوم الرابع والعشرون من الحصار. الملك لم ينم منذ ظهور الظلال. يهمس ليلاً باسمٍ واحد... آرين.»" },
  { id: "n3", x: 240, z: 60, title: "نقش على جليد", text: "«هنا سقط التنين الأخير. لم يقتله سيف، بل ندم.»" },
  { id: "n4", x: -60, z: 250, title: "همسة المستنقع", text: "«الأرواح هنا ليست أعداءك. إنها شهودٌ على خطيئتك القادمة.»" },
  { id: "n5", x: -240, z: -40, title: "خريطة عظمية", text: "«الصحراء كانت بحراً. والبحر كان عيناً. والعين... ترى القلعة من كل مكان.»" },
  { id: "n6", x: 8, z: -410, title: "آخر صفحة", text: "«إذا قرأتَ هذا فاللعنة أوشكت على الانكسار. تذكر: الظلام ليس عدوّ النور، بل فراغٌ ينتظر من يملؤه.»" },
];

// ---------------- treasure chests ----------------

export interface ChestDef { id: string; x: number; z: number; loot: { gold?: number; items?: Record<string, number>; equipment?: string; weapon?: string }; }
export const CHESTS: ChestDef[] = [
  { id: "c1", x: -80, z: 80, loot: { gold: 60, items: { crystal: 2 } } },
  { id: "c2", x: 90, z: -120, loot: { gold: 80, items: { ore: 2 }, equipment: "guardHelm" } },
  { id: "c3", x: -160, z: -100, loot: { gold: 100, items: { darkcrystal: 2 } } },
  { id: "c4", x: 160, z: 120, loot: { gold: 120, items: { crystal: 3 } } },
  { id: "c5", x: 60, z: 180, loot: { gold: 70, items: { herb: 3 }, equipment: "ashCloak" } },
  { id: "c6", x: -60, z: -180, loot: { gold: 150, items: { relic: 1 } } },
  { id: "c7", x: 240, z: -60, loot: { gold: 90, items: { ore: 3 }, equipment: "swiftBoots" } },
  { id: "c8", x: -260, z: 120, loot: { gold: 200, items: { crystal: 2, darkcrystal: 2 } } },
  { id: "c9", x: 15, z: -300, loot: { gold: 100, items: { relic: 1 }, equipment: "knightGauntlet" } },
  { id: "c10", x: -120, z: 300, loot: { gold: 250, items: { essence: 3 }, equipment: "titanArmor" } },
  { id: "c11", x: 300, z: 60, loot: { gold: 300, items: { darkcrystal: 3 }, equipment: "lightRing" } },
  { id: "c12", x: -300, z: -80, loot: { gold: 350, items: { relic: 2, essence: 2 } } },
  // desert giant skeleton treasure (Irys's hint)
  { id: "c13", x: -320, z: 40, loot: { gold: 500, items: { crystal: 5, darkcrystal: 5 }, equipment: "shadowRing", weapon: "hammer" } },
  { id: "c14", x: 120, z: 280, loot: { gold: 120, items: { essence: 2 } } },
  { id: "c15", x: -100, z: 20, loot: { gold: 40, items: { herb: 2 } } },
  { id: "c16", x: 200, z: 200, loot: { gold: 160, items: { ore: 2, crystal: 2 } } },
  { id: "c17", x: -200, z: -200, loot: { gold: 140, items: { relic: 1 } } },
  { id: "c18", x: 40, z: 300, loot: { gold: 110, items: { darkcrystal: 2 } } },
  // legendary weapons hidden
  { id: "c19", x: 280, z: -80, loot: { weapon: "spear", gold: 100, items: { crystal: 2 } } },
  { id: "c20", x: -40, z: 330, loot: { weapon: "bow", gold: 100, items: { essence: 2 } } },
];

// ---------------- endings ----------------

export interface Ending { id: string; name: string; text: string; }
export const ENDINGS: Ending[] = [
  {
    id: "light", name: "نهاية النور",
    text: "رفع آرين نصل الفجر وغرسه في قلب الظلال. انكسر التاج الأسود، وانسابت اللعنة كدخانٍ تحت أول ضوء الفجر. عادت الذاكرة كاملة: لم يكن ملك الظلال عدوّاً، بل مرآةً لخوف المملكة. في الربيع التالي، أنبتت غابة الرماد أوراقها الخضراء لأول مرة منذ ألف عام. ووقف آرين على أطلال المعبد حيث استيقظ، يعلّم الأطفال أن النور لا يُورَث... بل يُختار.",
  },
  {
    id: "shadow", name: "نهاية الظلال",
    text: "مدّ آرين يده بدل سيفه، وامتصّ قلب الظلال إلى صدره. شعر بالبرودة تعبر عروقه كأنها ألف همسة. صار حاكماً جديداً على مملكةٍ صامتة، عيونه تتوهج بنفس البنفسجية القديمة. في عهد الظل الجديد لم تمت وحشٌ واحدة... لكن لم يضحك إنسانٌ واحد أيضاً. وفي ليالٍ طويلة، يهمس ملك الظلال الجديد باسمٍ عرفه قبل أن ينسى: ميرا.",
  },
  {
    id: "balance", name: "نهاية التوازن",
    text: "كسر آرين نصل الفجر نصفين، وزرع نصفيه في تاج الملك الساقط. توهّجت القلعة بنورٍ وبنفسجية معاً — أول شروقٍ فيها ليس للشمس ولا للقمر، بل لقلبٍ واحد. نهض ملك الظلال بلا تاج، رجلاً عادياً يبكي ذنوب ألف عام. قالت ميرا وهي تنظر إلى الأفق: «لم نستعد إيراث القديمة... بنينا ما هو أعظم: إيراث التي تتسع للنور والظل معاً.»",
  },
];

export const INTRO_TEXT = [
  "قبل ألف عام، كانت مملكة إيراث تلمع كألف شمس...",
  "حتى ظهر كيانٌ من بين الظلال، نشر لعنته على الأرض.",
  "تحوّلت المدن إلى رماد، والمخلوقات إلى وحوش، والناس إلى أسطورة.",
  "لكن النبوءة قالت: سيستيقظ حارس القلب يوماً ما...",
  "وهذا اليوم هو اليوم.",
];
