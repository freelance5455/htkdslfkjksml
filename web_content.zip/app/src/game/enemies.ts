/**
 * enemies.ts — enemy entities with AI states, projectiles, summons, and bosses
 * (Treant Guardian of the Ash Forest, and the Shadow King).
 */
import * as THREE from "three";
import { World } from "./world";
import { AudioSystem } from "./audio";
import { Particles, DamageNumbers, Hitbox, hitOverlap } from "./combat";
import { buildHumanoid, buildBeast, buildTreant, animateHumanoid, makeAnimState, AnimState } from "./characters";
import { ENEMIES, EnemyKind, EnemyDef, ZONE_SPAWNS } from "./data";
import { clamp, lerp, mulberry32, dist2 } from "./noise";
import { Player } from "./player";

export type AIState = "idle" | "patrol" | "chase" | "windup" | "attack" | "recover" | "dead" | "return";

export interface EnemyEvents {
  onDeath: (e: Enemy) => void;
  onPlayerHit: (dmg: number, e: Enemy) => void;
  spawnProjectile: (x: number, y: number, z: number, dir: THREE.Vector3, dmg: number, color: number, speed: number, team: "enemy") => void;
  shake: (v: number) => void;
  requestMinions?: (boss: Enemy, n: number) => void;
}

let UID = 1;

export class Enemy {
  id = UID++;
  def: EnemyDef;
  pos = new THREE.Vector3();
  home = new THREE.Vector3();
  yaw = 0;
  hp: number;
  maxHp: number;
  alive = true;
  state: AIState = "idle";
  stateT = 0;
  attackCd = 0;
  radius: number;
  isBoss = false;
  phase = 1;
  zone: string;
  aggro = false;
  stunT = 0;
  anim: AnimState = makeAnimState();
  mesh: THREE.Object3D;
  human: ReturnType<typeof buildHumanoid> | null = null;
  beast: ReturnType<typeof buildBeast> | null = null;
  treant: ReturnType<typeof buildTreant> | null = null;
  hitFlash = 0;
  bossName = "";
  flying = false;
  _waveHit = false;
  patrolT = 0;
  patrolDir = new THREE.Vector3(1, 0, 0);
  private moveVel = new THREE.Vector3();

  constructor(kind: EnemyKind, x: number, z: number, zone: string, world: World) {
    this.def = ENEMIES[kind];
    this.zone = zone;
    const elite = kind === "treant" || kind === "shadowking";
    this.isBoss = elite;
    this.maxHp = this.def.hp;
    this.hp = this.maxHp;
    this.radius = this.def.beast ? 0.7 * this.def.scale : 0.55 * this.def.scale;
    this.pos.set(x, world.height(x, z), z);
    this.home.copy(this.pos);

    if (kind === "treant") {
      this.treant = buildTreant(1.35);
      this.mesh = this.treant.root;
      this.radius = 1.9;
      this.flying = false;
      this.bossName = "حارس الغابة";
    } else if (this.def.beast) {
      this.beast = buildBeast({ scale: this.def.scale, bodyColor: this.def.bodyColor, eyeColor: this.def.eyeColor, spikes: kind === "swamper" });
      this.mesh = this.beast.root;
    } else {
      this.human = buildHumanoid({
        armorColor: this.def.bodyColor, clothColor: this.def.bodyColor, skinColor: this.def.bodyColor,
        eyeColor: this.def.eyeColor, scale: this.def.scale, cape: !this.def.hood,
        bulky: this.def.bulky, hood: this.def.hood, glowIntensity: 1.2,
      });
      this.mesh = this.human.root;
      if (kind === "shadowking") {
        this.bossName = "ملك الظلال";
        this.human.glow.intensity = 6;
        this.human.glow.color.set(0xa040ff);
        this.human.glow.distance = 14;
        // crown
        const crown = new THREE.Mesh(new THREE.ConeGeometry(0.24, 0.42, 6), new THREE.MeshStandardMaterial({ color: 0x2a1f3a, emissive: 0xa040ff, emissiveIntensity: 1.4 }));
        crown.position.y = 0.35;
        this.human.head.add(crown);
        this.radius = 0.9;
      }
    }
    this.mesh.position.copy(this.pos);
  }

  /** Attempt to damage this enemy. Returns true if damage landed. */
  damage(amount: number, player: Player, particles: Particles, dmgNum: DamageNumbers, audio: AudioSystem, knockback = 3): boolean {
    if (!this.alive) return false;
    const backstab = player.cloakT > 0;
    if (backstab) amount *= 1.8;
    this.hp -= amount;
    this.hitFlash = 0.15;
    this.aggro = true;
    if (this.stunT <= 0 && Math.random() < 0.25 && !this.isBoss) this.stunT = 0.4;
    const col = this.def.eyeColor;
    particles.burst(this.pos.x, this.pos.y + 1.2 * this.def.scale, this.pos.z, 14, col, 4.5, 0.45);
    dmgNum.show(this.pos.x, this.pos.y + 2 * this.def.scale, this.pos.z, String(Math.round(amount)), backstab ? "#c07aff" : "#ffd76a", amount > 40);
    // knockback
    const kb = knockback * (this.isBoss ? 0.05 : 1);
    this.moveVel.x += (this.pos.x - player.pos.x) * kb * 0.4;
    this.moveVel.z += (this.pos.z - player.pos.z) * kb * 0.4;
    if (this.hp <= 0) {
      this.hp = 0;
      this.alive = false;
      this.state = "dead";
      this.anim.dead = true;
      audio.sfx(this.isBoss ? "roar2" : "enemyDie");
      particles.burst(this.pos.x, this.pos.y + 1.4, this.pos.z, 40, col, 6, 0.9);
    }
    return true;
  }

  update(dt: number, player: Player, world: World, events: EnemyEvents, t: number, particles: Particles): void {
    if (this.state === "dead") {
      this.anim.t += dt;
      if (this.human) animateHumanoid(this.human, this.anim, dt);
      this.mesh.position.y = lerp(this.mesh.position.y, world.height(this.pos.x, this.pos.z) - (this.anim.t > 1.2 ? 1.6 : 0), dt * 2);
      return;
    }
    if (this.hitFlash > 0) this.hitFlash -= dt;
    if (this.stunT > 0) { this.stunT -= dt; this.updateVisual(dt, world, t); return; }

    const d = dist2(this.pos.x, this.pos.z, player.pos.x, player.pos.z);
    const def = this.def;
    const playerVisible = player.cloakT <= 0;

    // aggro logic
    if (!this.aggro && playerVisible && d < def.aggroR && !player.dead) {
      this.aggro = true;
      this.state = "chase";
      if (this.isBoss) events.shake(0.3);
    }
    if (this.aggro && (d > def.aggroR * 2.6 || player.dead)) {
      this.aggro = false;
      this.state = "return";
    }

    this.attackCd -= dt;
    this.stateT -= dt;

    switch (this.state) {
      case "idle":
      case "patrol": {
        if (!this.aggro) {
          this.patrolT -= dt;
          if (this.patrolT <= 0) {
            this.patrolT = 3 + Math.random() * 4;
            const a = Math.random() * Math.PI * 2;
            this.patrolDir.set(Math.cos(a), 0, Math.sin(a));
          }
          const wander = this.stateT > -8 ? 0.25 : 0;
          this.move(this.patrolDir.x * def.speed * wander, this.patrolDir.z * def.speed * wander, dt, world, player);
          if (dist2(this.pos.x, this.pos.z, this.home.x, this.home.z) > 30) this.state = "return";
          this.anim.speed = wander;
          break;
        }
        this.state = "chase";
        break;
      }
      case "return": {
        const hx = this.home.x - this.pos.x, hz = this.home.z - this.pos.z;
        const hd = Math.hypot(hx, hz);
        if (hd < 2) { this.state = "patrol"; break; }
        this.move((hx / hd) * def.speed * 0.6, (hz / hd) * def.speed * 0.6, dt, world, player);
        this.yawTowards(this.home.x, this.home.z, dt);
        this.anim.speed = 0.5;
        break;
      }
      case "chase": {
        if (player.dead) { this.state = "return"; break; }
        this.yawTowards(player.pos.x, player.pos.z, dt);
        if (d < def.attackR && this.attackCd <= 0 && playerVisible) {
          this.state = "windup";
          this.stateT = this.isBoss ? 0.55 : 0.45;
          this.anim.attackT = 0;
          this.anim.attackKind = Math.random() < 0.3 ? 1 : 0;
        } else if (d >= def.attackR * 0.85) {
          const sp = def.speed * (this.flying ? 1 : 1);
          const dx = (player.pos.x - this.pos.x) / d, dz = (player.pos.z - this.pos.z) / d;
          this.move(dx * sp, dz * sp, dt, world, player);
          this.anim.speed = 1;
        } else {
          this.anim.speed = 0;
        }
        // ranged enemies keep distance
        if ((def.kind === "mage" || def.kind === "spirit") && d < 8) {
          const dx = (this.pos.x - player.pos.x) / d, dz = (this.pos.z - player.pos.z) / d;
          this.move(dx * def.speed * 0.7, dz * def.speed * 0.7, dt, world, player);
        }
        // ranged attack
        if ((def.kind === "mage" || def.kind === "spirit") && d < def.attackR && this.attackCd <= 0 && playerVisible) {
          this.state = "windup";
          this.stateT = 0.6;
        }
        // boss behaviors
        if (this.isBoss) this.bossChase(dt, player, world, events, d, particles);
        break;
      }
      case "windup": {
        this.yawTowards(player.pos.x, player.pos.z, dt * 0.6);
        this.anim.attackT = Math.min(0.3, this.anim.attackT + dt);
        if (this.stateT <= 0) {
          this.state = "attack";
          this.stateT = 0.35;
          this.attackLanded = false;
        }
        break;
      }
      case "attack": {
        this.anim.attackT = Math.min(1, this.anim.attackT + dt * 3);
        if (!this.attackLanded && this.anim.attackT > 0.45) {
          this.attackLanded = true;
          this.executeAttack(player, world, events, particles);
        }
        if (this.stateT <= 0) {
          this.state = "recover";
          this.stateT = 0.5;
          this.attackCd = def.attackCd * (0.85 + Math.random() * 0.4);
          this.anim.attackT = -1;
        }
        break;
      }
      case "recover": {
        this.anim.speed = 0;
        if (this.stateT <= 0) this.state = "chase";
        break;
      }
    }

    // knockback decay + integrate
    this.pos.x += this.moveVel.x * dt;
    this.pos.z += this.moveVel.z * dt;
    this.moveVel.multiplyScalar(Math.max(0, 1 - dt * 8));
    const c = world.collide(this.pos.x, this.pos.z, this.radius);
    this.pos.x = c.x; this.pos.z = c.z;
    this.pos.y = world.height(this.pos.x, this.pos.z) + (this.flying ? 1.6 + Math.sin(t * 2 + this.id) * 0.4 : 0);

    this.updateVisual(dt, world, t);
  }

  private attackLanded = false;

  private move(vx: number, vz: number, dt: number, world: World, player: Player): void {
    this.pos.x += vx * dt;
    this.pos.z += vz * dt;
    if (vx || vz) {
      const want = Math.atan2(vx, vz);
      let dy = want - this.yaw;
      while (dy > Math.PI) dy -= Math.PI * 2;
      while (dy < -Math.PI) dy += Math.PI * 2;
      this.yaw += dy * clamp(dt * 6, 0, 1);
    }
  }

  private yawTowards(x: number, z: number, dt: number): void {
    const want = Math.atan2(x - this.pos.x, z - this.pos.z);
    let dy = want - this.yaw;
    while (dy > Math.PI) dy -= Math.PI * 2;
    while (dy < -Math.PI) dy += Math.PI * 2;
    this.yaw += dy * clamp(dt * 8, 0, 1);
  }

  private executeAttack(player: Player, world: World, events: EnemyEvents, particles: Particles): void {
    const def = this.def;
    if (def.kind === "mage" || def.kind === "spirit") {
      const dir = new THREE.Vector3(player.pos.x - this.pos.x, (player.pos.y + 1.2) - (this.pos.y + 1.4), player.pos.z - this.pos.z).normalize();
      events.spawnProjectile(this.pos.x, this.pos.y + 1.4, this.pos.z, dir, def.dmg, def.eyeColor, 14, "enemy");
      return;
    }
    // melee: hitbox in front
    const hx = this.pos.x + Math.sin(this.yaw) * def.attackR * 0.6;
    const hz = this.pos.z + Math.cos(this.yaw) * def.attackR * 0.6;
    const hit: Hitbox = { x: hx, y: this.pos.y + 1.2, z: hz, r: def.attackR * 0.75, dmg: def.dmg, knockback: 4, team: "enemy" };
    if (hitOverlap(hit, player.pos.x, player.pos.y + 1, player.pos.z, 0.6)) {
      const res = player.takeDamage(def.dmg, this.pos.x, this.pos.z);
      if (res === "parry") {
        this.stunT = 1.6;
        events.shake(0.2);
      } else if (res) {
        events.onPlayerHit(def.dmg, this);
      }
    }
    if (this.treant) {
      events.shake(0.35);
      particles.burst(hx, this.pos.y + 0.5, hz, 24, 0x6a5a40, 5, 0.6);
    }
  }

  // ---------- boss behaviors ----------

  private bossAttackT = 3;
  bossSpecial = 0;

  private bossChase(dt: number, player: Player, world: World, events: EnemyEvents, d: number, particles: Particles): void {
    this.bossAttackT -= dt;
    // phase transitions
    if (this.def.kind === "treant" && this.phase === 1 && this.hp < this.maxHp * 0.55) {
      this.phase = 2;
      events.shake(0.6);
      this.bossAttackT = 1;
    }
    if (this.def.kind === "shadowking") {
      if (this.phase === 1 && this.hp < this.maxHp * 0.66) this.phase = 2;
      if (this.phase === 2 && this.hp < this.maxHp * 0.33) this.phase = 3;
    }
    if (this.bossAttackT > 0) return;
    this.bossAttackT = this.phase >= 2 ? 2.2 : 3.2;

    if (this.def.kind === "treant") {
      // slam AoE
      const r = this.phase >= 2 ? 7 : 5.5;
      events.shake(0.5);
      particles.burst(this.pos.x, this.pos.y + 0.4, this.pos.z, 50, 0x8aff5a, 8, 0.8);
      if (dist2(this.pos.x, this.pos.z, player.pos.x, player.pos.z) < r) {
        const res = player.takeDamage(this.def.dmg, this.pos.x, this.pos.z);
        if (res === true) events.onPlayerHit(this.def.dmg, this);
      }
      this.anim.attackKind = 1;
      this.anim.attackT = 0;
      this.state = "windup";
      this.stateT = 0.01;
    } else if (this.def.kind === "shadowking") {
      const roll = Math.random();
      if (this.phase >= 2 && roll < 0.35) {
        // teleport behind player + slash
        const a = player.yaw + Math.PI;
        this.pos.x = player.pos.x + Math.sin(a) * 2.2;
        this.pos.z = player.pos.z + Math.cos(a) * 2.2;
        particles.burst(this.pos.x, this.pos.y + 1.5, this.pos.z, 40, 0xa040ff, 6, 0.7);
        events.shake(0.3);
        const res = player.takeDamage(this.def.dmg * 0.8, this.pos.x, this.pos.z, true);
        if (res === true) events.onPlayerHit(this.def.dmg, this);
      } else if (roll < 0.6) {
        // projectile fan
        for (let i = -2; i <= 2; i++) {
          const base = Math.atan2(player.pos.x - this.pos.x, player.pos.z - this.pos.z);
          const a = base + i * 0.22;
          events.spawnProjectile(this.pos.x, this.pos.y + 1.8, this.pos.z, new THREE.Vector3(Math.sin(a), 0.05, Math.cos(a)), this.def.dmg * 0.7, 0xc040ff, 16, "enemy");
        }
      } else {
        // summon minions in phase 3
        if (this.phase >= 3) events.requestMinions?.(this, 2);
        events.shake(0.4);
        if (d < 6) {
          const res = player.takeDamage(this.def.dmg, this.pos.x, this.pos.z);
          if (res === true) events.onPlayerHit(this.def.dmg, this);
        }
        particles.burst(this.pos.x, this.pos.y + 1, this.pos.z, 60, 0x4020a0, 7, 0.9);
      }
    }
  }

  private updateVisual(dt: number, world: World, t: number): void {
    this.mesh.position.copy(this.pos);
    this.mesh.rotation.y = this.yaw;
    if (this.human) {
      if (this.hitFlash > 0) {
        this.human.torso.material = this.human.torso.material;
      }
      animateHumanoid(this.human, this.anim, dt, 0.8);
      // floating for spirits
      if (this.def.kind === "spirit") {
        this.human.legL.rotation.x = -0.9;
        this.human.legR.rotation.x = -0.7;
        this.mesh.position.y = this.pos.y + 0.4 + Math.sin(t * 2.4 + this.id) * 0.25;
      }
    } else if (this.beast) {
      const w = t * 10 * Math.max(this.anim.speed, 0.15);
      const s = Math.sin(w) * 0.7;
      this.beast.legs[0].rotation.x = s; this.beast.legs[3].rotation.x = s;
      this.beast.legs[1].rotation.x = -s; this.beast.legs[2].rotation.x = -s;
      this.beast.head.rotation.x = Math.sin(t * 1.5 + this.id) * 0.1;
      this.beast.tail.rotation.z = Math.sin(t * 3) * 0.3;
      if (this.aggro) this.beast.head.rotation.x = -0.15 + Math.sin(t * 8) * 0.08;
    } else if (this.treant) {
      // sway arms, pulse core
      this.treant.armL.rotation.x = Math.sin(t * 1.1) * 0.15;
      this.treant.armR.rotation.x = -Math.sin(t * 1.1) * 0.15;
      this.treant.head.rotation.z = Math.sin(t * 0.7) * 0.08;
      const core = this.treant.core;
      core.scale.setScalar(1 + Math.sin(t * 3) * 0.12);
      if (this.phase >= 2) (core.material as THREE.MeshBasicMaterial).color.set(0xff5a3a);
    }
    if (this.hitFlash > 0) {
      const k = this.hitFlash / 0.15;
      this.mesh.traverse((c) => {
        const m = c as THREE.Mesh;
        if (m.isMesh) {
          const sm = m.material as THREE.MeshStandardMaterial;
          if (sm && sm.emissive) {
            if (sm.userData._e === undefined) sm.userData._e = sm.emissive.getHex();
            sm.emissive.setHex(0xffffff);
            sm.emissiveIntensity = k * 0.9;
          }
        }
      });
    } else {
      this.mesh.traverse((c) => {
        const m = c as THREE.Mesh;
        if (m.isMesh) {
          const sm = m.material as THREE.MeshStandardMaterial;
          if (sm && sm.emissive && sm.userData._e !== undefined) {
            sm.emissive.setHex(sm.userData._e);
            sm.emissiveIntensity = 1;
          }
        }
      });
    }
  }
}

// ---------------- projectiles ----------------

interface Proj { mesh: THREE.Mesh; pos: THREE.Vector3; vel: THREE.Vector3; dmg: number; alive: boolean; life: number; team: "enemy" | "player"; color: number; }

export class Projectiles {
  private pool: Proj[] = [];
  private scene: THREE.Scene;
  constructor(scene: THREE.Scene) {
    this.scene = scene;
    for (let i = 0; i < 40; i++) {
      const mesh = new THREE.Mesh(new THREE.SphereGeometry(0.18, 8, 6), new THREE.MeshBasicMaterial({ color: 0xffffff }));
      mesh.visible = false;
      scene.add(mesh);
      this.pool.push({ mesh, pos: new THREE.Vector3(), vel: new THREE.Vector3(), dmg: 10, alive: false, life: 0, team: "enemy", color: 0xffffff });
    }
  }
  fire(x: number, y: number, z: number, dir: THREE.Vector3, dmg: number, color: number, speed: number, team: "enemy" | "player"): void {
    const p = this.pool.find((q) => !q.alive);
    if (!p) return;
    p.alive = true; p.life = 3;
    p.pos.set(x, y, z);
    p.vel.copy(dir).normalize().multiplyScalar(speed);
    p.dmg = dmg; p.team = team; p.color = color;
    p.mesh.visible = true;
    (p.mesh.material as THREE.MeshBasicMaterial).color.set(color);
  }
  update(dt: number, player: Player, enemies: Enemy[], world: World, particles: Particles, dmgNum: DamageNumbers, audio: AudioSystem, onPlayerHit: (dmg: number) => void): void {
    for (const p of this.pool) {
      if (!p.alive) continue;
      p.life -= dt;
      p.pos.addScaledVector(p.vel, dt);
      p.mesh.position.copy(p.pos);
      let hit = false;
      if (p.team === "enemy") {
        if (dist2(p.pos.x, p.pos.z, player.pos.x, player.pos.z) < 0.7 && Math.abs(p.pos.y - player.pos.y - 1) < 1.4) {
          const res = player.takeDamage(p.dmg, p.pos.x - p.vel.x, p.pos.z - p.vel.z);
          if (res === true) onPlayerHit(p.dmg);
          hit = true;
        }
      } else {
        for (const e of enemies) {
          if (!e.alive) continue;
          if (dist2(p.pos.x, p.pos.z, e.pos.x, e.pos.z) < e.radius + 0.4 && Math.abs(p.pos.y - e.pos.y - 1) < 2) {
            e.damage(p.dmg, player, particles, dmgNum, audio, 2);
            hit = true;
            break;
          }
        }
      }
      if (p.pos.y < world.height(p.pos.x, p.pos.z)) hit = true;
      if (hit || p.life <= 0) {
        particles.burst(p.pos.x, p.pos.y, p.pos.z, 10, p.color, 3, 0.35);
        p.alive = false;
        p.mesh.visible = false;
      }
    }
  }
}

// ---------------- spawner ----------------

export class Spawner {
  enemies: Enemy[] = [];
  private rng = mulberry32(4242);

  constructor(private world: World, private scene: THREE.Scene) {
    this.populate();
  }

  private populate(): void {
    for (const [zone, list] of Object.entries(ZONE_SPAWNS)) {
      const zn = (this.world as unknown as { constructor: { name: string } });
      const centers: Record<string, { x: number; z: number; r: number }> = {
        forest: { x: 0, z: 0, r: 150 }, city: { x: 10, z: -230, r: 115 },
        ice: { x: 250, z: 20, r: 125 }, swamp: { x: -20, z: 240, r: 115 },
        desert: { x: -250, z: 10, r: 115 }, castle: { x: 0, z: -430, r: 120 },
      };
      const c = centers[zone];
      for (const sp of list) {
        for (let i = 0; i < sp.count; i++) {
          const a = this.rng() * Math.PI * 2;
          const r = 25 + Math.sqrt(this.rng()) * (c.r - 30);
          const x = c.x + Math.cos(a) * r, z = c.z + Math.sin(a) * r;
          if (Math.abs(x) > 500 || Math.abs(z) > 500) continue;
          if (dist2(x, z, 0, 6) < 24) continue; // temple safe zone
          const e = new Enemy(sp.kind, x, z, zone, this.world);
          this.enemies.push(e);
          this.scene.add(e.mesh);
        }
      }
    }
  }

  /** Spawn bosses on demand. */
  spawnBoss(kind: "treant" | "shadowking", x: number, z: number): Enemy {
    const e = new Enemy(kind, x, z, "boss", this.world);
    e.aggro = true;
    e.state = "chase";
    this.enemies.push(e);
    this.scene.add(e.mesh);
    return e;
  }

  update(dt: number, player: Player, events: EnemyEvents, t: number, particles: Particles): void {
    for (const e of this.enemies) {
      // only simulate nearby enemies (others sleep)
      const d = dist2(e.pos.x, e.pos.z, player.pos.x, player.pos.z);
      if (d > 130 && !e.isBoss) continue;
      e.update(dt, player, this.world, events, t, particles);
    }
  }

  /** Remove long-dead enemies (sweep occasionally). */
  sweep(): void {
    for (let i = this.enemies.length - 1; i >= 0; i--) {
      const e = this.enemies[i];
      if (!e.alive && e.anim.t > 3) {
        this.scene.remove(e.mesh);
        this.enemies.splice(i, 1);
      }
    }
  }
}
