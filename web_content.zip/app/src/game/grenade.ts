/**
 * grenade.ts — GrenadeSystem.
 * Parabolic throw with wall/ground bounces, fuse timer, explosion visuals + radial AoE damage
 * that hurts every combatant (player and bots) with distance falloff. Pool of 6 live grenades.
 */

import * as THREE from "three";
import { GRENADE, TeamId } from "./config";
import { raycastColliders, AABB } from "./arena";
import { AudioSystem } from "./audio";
import { Effects } from "./effects";
import type { Shootable } from "./weapon";

interface Grenade {
  alive: boolean;
  pos: THREE.Vector3;
  vel: THREE.Vector3;
  fuse: number;
  mesh: THREE.Mesh;
  attacker: string;
  attackerTeam: TeamId;
}

export interface ExplosionEvent {
  x: number; y: number; z: number;
  radius: number;
  damage: (dist: number) => number;
  attacker: string;
  attackerTeam: TeamId;
}

const POOL = 6;

export class GrenadeSystem {
  private pool: Grenade[] = [];
  count = GRENADE.COUNT;
  cooldown = 0;

  constructor(
    private scene: THREE.Scene,
    private colliders: AABB[],
    private effects: Effects,
    private audio: AudioSystem,
    private getTargets: () => Shootable[],
    private getPlayerPos: () => THREE.Vector3 | null,
    private onPlayerDamage: (dmg: number, attacker: string, attackerTeam: TeamId) => void,
    private onBotDamage: (bot: Shootable, dmg: number, attacker: string, attackerTeam: TeamId) => void,
  ) {
    const geo = new THREE.SphereGeometry(0.11, 10, 8);
    const mat = new THREE.MeshStandardMaterial({ color: 0x2c3327, roughness: 0.5, metalness: 0.4 });
    for (let i = 0; i < POOL; i++) {
      const mesh = new THREE.Mesh(geo, mat);
      mesh.visible = false;
      mesh.castShadow = true;
      scene.add(mesh);
      this.pool.push({ alive: false, pos: new THREE.Vector3(), vel: new THREE.Vector3(), fuse: 0, mesh, attacker: "", attackerTeam: 0 });
    }
  }

  reset(): void {
    this.count = GRENADE.COUNT;
    this.cooldown = 0;
    for (const g of this.pool) { g.alive = false; g.mesh.visible = false; }
  }

  /** Throw from eye position along view direction. */
  throwGrenade(origin: THREE.Vector3, dir: THREE.Vector3, attacker: string, team: TeamId): boolean {
    if (this.count <= 0 || this.cooldown > 0) return false;
    const g = this.pool.find((x) => !x.alive);
    if (!g) return false;
    this.count--;
    this.cooldown = GRENADE.COOLDOWN;
    g.alive = true;
    g.pos.copy(origin).addScaledVector(dir, 0.5);
    g.vel.copy(dir).multiplyScalar(GRENADE.THROW_SPEED);
    g.vel.y += GRENADE.THROW_UP;
    g.fuse = GRENADE.FUSE;
    g.attacker = attacker;
    g.attackerTeam = team;
    g.mesh.visible = true;
    g.mesh.position.copy(g.pos);
    this.audio.sfx("throw");
    return true;
  }

  update(dt: number): void {
    this.cooldown = Math.max(0, this.cooldown - dt);
    for (const g of this.pool) {
      if (!g.alive) continue;
      g.fuse -= dt;
      if (g.fuse <= 0) {
        g.alive = false;
        g.mesh.visible = false;
        this.explode(g.pos, g.attacker, g.attackerTeam);
        continue;
      }
      // integrate with substeps so fast throws don't tunnel through walls
      const steps = 2;
      const sdt = dt / steps;
      for (let s = 0; s < steps; s++) {
        g.vel.y -= GRENADE.GRAVITY * sdt;
        const moveX = g.vel.x * sdt, moveY = g.vel.y * sdt, moveZ = g.vel.z * sdt;
        const len = Math.hypot(moveX, moveY, moveZ);
        if (len > 1e-6) {
          // wall probe
          const t = raycastColliders(this.colliders, g.pos.x, g.pos.y, g.pos.z, moveX / len, moveY / len, moveZ / len, len + 0.12);
          if (t < len + 0.12) {
            // bounce: reflect the dominant axis (cheap and stable for axis-aligned walls)
            const nx = Math.abs(moveX) > Math.abs(moveY) && Math.abs(moveX) > Math.abs(moveZ);
            const ny = !nx && Math.abs(moveY) > Math.abs(moveZ);
            if (nx) g.vel.x *= -0.42;
            else if (ny) { g.vel.y *= -0.42; g.vel.x *= 0.8; g.vel.z *= 0.8; }
            else g.vel.z *= -0.42;
            this.audio.sfx("bounce");
          } else {
            g.pos.x += moveX;
            g.pos.y += moveY;
            g.pos.z += moveZ;
          }
        }
        if (g.pos.y < 0.11) {
          g.pos.y = 0.11;
          if (Math.abs(g.vel.y) > 1.2) this.audio.sfx("bounce");
          g.vel.y = Math.abs(g.vel.y) * 0.42;
          g.vel.x *= 0.75;
          g.vel.z *= 0.75;
        }
      }
      g.mesh.position.copy(g.pos);
      // blink faster as the fuse runs out
      const blink = Math.sin(performance.now() * (g.fuse < 0.8 ? 0.045 : 0.012)) > 0;
      (g.mesh.material as THREE.MeshStandardMaterial).emissive.setHex(blink ? 0xff2211 : 0x000000);
      g.mesh.rotation.x += dt * 6;
      g.mesh.rotation.z += dt * 4;
    }
  }

  private explode(pos: THREE.Vector3, attacker: string, attackerTeam: TeamId): void {
    this.effects.explosion(pos);
    this.audio.sfx("explosion");
    const r = GRENADE.RADIUS;
    const falloff = (dist: number) =>
      dist > r ? 0 : GRENADE.MAX_DAMAGE - (GRENADE.MAX_DAMAGE - GRENADE.MIN_DAMAGE) * (dist / r);
    for (const t of this.getTargets()) {
      if (!t.alive) continue;
      const dx = t.pos.x - pos.x, dy = t.pos.y + t.height * 0.5 - pos.y, dz = t.pos.z - pos.z;
      const dmg = falloff(Math.hypot(dx, dy, dz));
      if (dmg > 0) this.onBotDamage(t, dmg, attacker, attackerTeam);
    }
    const pp = this.getPlayerPos();
    if (pp) {
      const dmg = falloff(Math.hypot(pp.x - pos.x, pp.y - pos.y, pp.z - pos.z));
      if (dmg > 0) this.onPlayerDamage(dmg, attacker, attackerTeam);
    }
  }
}
