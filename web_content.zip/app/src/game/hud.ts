/**
 * hud.ts — MobileHUDController.
 * Builds and wires the complete mobile touch overlay:
 *   · top-center scoreboard (blue vs red + round-win pips)
 *   · top-left pause button + tactical minimap
 *   · top-right kill feed
 *   · left: virtual joystick, crouch toggle, armor-plate (interact) button
 *   · right: FIRE, reload, ADS, grenade (with count badge), quick weapon switch
 *   · bottom-center loadout bar (armor / weapon+ammo / grenade charge) + HP bar
 *   · center: dynamic crosshair, hitmarker, damage vignette, floating damage numbers, banners
 *   · full-screen title / pause / game-over overlays
 * Touch controls write straight into GameInput; look-drag stays in boot (canvas surface).
 */

import { GameInput } from "./input";
import { AABB } from "./arena";
import { MATCH, TeamId } from "./config";
import { KillEvent } from "./enemy";

export type ScreenId = "title" | "pause" | "gameover" | null;

export interface HudFrameData {
  hp: number;
  maxHp: number;
  plates: number;
  plateProgress: number; // 0..1 channel, -1 = not channeling
  mag: number;
  reserve: number;
  weaponName: string;
  reloading: boolean;
  reloadProgress: number; // 0..1
  grenades: number;
  grenadeCooldown: number; // 0..1 (1 = ready)
  spread: number;          // radians — drives crosshair gap
  adsAmount: number;
  crouched: boolean;
  scores: [number, number];
  round: number;
}

export interface MinimapBlip {
  x: number;
  z: number;
  team: TeamId;
  isPlayer: boolean;
  yaw: number;
}

/** Small inline SVG icons (no external assets). */
const ICON = {
  pause: '<svg viewBox="0 0 24 24"><rect x="5" y="4" width="4.5" height="16" rx="1.2"/><rect x="14.5" y="4" width="4.5" height="16" rx="1.2"/></svg>',
  rifle: '<svg viewBox="0 0 48 16"><path d="M2 6h22l2-3h6l1 3h9v3h-6l-1 4h-5l-1-4H20l-2 2h-6l-1-2H2z"/></svg>',
  crouch: '<svg viewBox="0 0 24 24"><circle cx="9" cy="5" r="2.6"/><path d="M6 21v-6l3-4 5 1 4 3h4v3h-5l-4-2-2 5z"/></svg>',
  stand: '<svg viewBox="0 0 24 24"><circle cx="12" cy="4.5" r="2.6"/><path d="M12 8l-3 6 2 3v6h2.4v-5l-1-2 1-2 1 2-1 2v5H16v-6l2-3z"/></svg>',
  plate: '<svg viewBox="0 0 24 24"><path d="M12 2l8 3v6c0 5-3.5 9.4-8 11-4.5-1.6-8-6-8-11V5z" fill="none" stroke="currentColor" stroke-width="2"/><path d="M12 7v10M7 12h10" stroke="currentColor" stroke-width="2.4"/></svg>',
  fire: '<svg viewBox="0 0 24 24"><path d="M12 2c1 4-3 5-3 9a3.6 3.6 0 007.2.4C17.6 8 14 6 12 2z"/><circle cx="12" cy="15" r="4.2" fill="none" stroke="currentColor" stroke-width="2"/></svg>',
  reload: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><path d="M20 12a8 8 0 11-2.3-5.6"/><path d="M20 3v4h-4" stroke-linecap="round"/></svg>',
  ads: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="7.5"/><path d="M12 1.5v5M12 17.5v5M1.5 12h5M17.5 12h5" stroke-linecap="round"/><circle cx="12" cy="12" r="1.6" fill="currentColor"/></svg>',
  grenade: '<svg viewBox="0 0 24 24"><circle cx="12" cy="14" r="8"/><path d="M9 6h6v3H9z" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M12 2v4M10 2h4" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>',
  swap: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M4 8h13l-3-3M20 16H7l3 3"/></svg>',
  skull: '<svg viewBox="0 0 24 24"><path d="M12 2a8 8 0 00-8 8c0 3 1.6 5 3.5 6.2V20a2 2 0 002 2h5a2 2 0 002-2v-3.8C18.4 15 20 13 20 10a8 8 0 00-8-8z"/><circle cx="9" cy="10" r="1.8"/><circle cx="15" cy="10" r="1.8"/></svg>',
};

const SVG = (s: string) => `<svg viewBox="0 0 24 24">${s}</svg>`;

function el(tag: string, cls: string, parent: HTMLElement, html = ""): HTMLElement {
  const e = document.createElement(tag);
  e.className = cls;
  if (html) e.innerHTML = html;
  parent.appendChild(e);
  return e;
}

export class MobileHUDController {
  private root: HTMLElement;
  private input: GameInput;

  // cached element refs
  private scoreEls: [HTMLElement, HTMLElement];
  private pipEls: [HTMLElement[], HTMLElement[]];
  private roundEl: HTMLElement;
  private killfeedEl: HTMLElement;
  private minimap: HTMLCanvasElement;
  private mapCtx: CanvasRenderingContext2D;
  private joyBase: HTMLElement;
  private joyKnob: HTMLElement;
  private btnFire: HTMLElement;
  private btnReload: HTMLElement;
  private btnAds: HTMLElement;
  private btnGrenade: HTMLElement;
  private grenadeBadge: HTMLElement;
  private btnWeapon: HTMLElement;
  private btnCrouch: HTMLElement;
  private btnPlate: HTMLElement;
  private plateBadge: HTMLElement;
  private hpFill: HTMLElement;
  private hpText: HTMLElement;
  private ammoEl: HTMLElement;
  private weaponNameEl: HTMLElement;
  private reloadBar: HTMLElement;
  private nadeCountEl: HTMLElement;
  private nadeBar: HTMLElement;
  private crosshair: HTMLElement;
  private chLines: HTMLElement[];
  private hitmarker: HTMLElement;
  private vignette: HTMLElement;
  private bannerEl: HTMLElement;
  private bannerTimer = 0;
  private dmgPool: HTMLElement[] = [];
  private screens: Record<"title" | "pause" | "gameover", HTMLElement>;
  private muteBtns: HTMLElement[] = [];

  /** Wired by boot. */
  onPause = () => {};
  onResume = () => {};
  onRestart = () => {};
  onDeploy = () => {};
  onMuteToggle = (): boolean => false;

  private wallRects: { x: number; z: number; w: number; h: number }[] = [];
  private mapScale = 1;

  constructor(container: HTMLElement, input: GameInput) {
    this.input = input;
    this.root = el("div", "hud", container);

    // ---------- top center scoreboard ----------
    const sb = el("div", "scoreboard", this.root);
    const mkTeam = (team: 0 | 1) => {
      const t = el("div", `sb-team ${team === 0 ? "blue" : "red"}`, sb);
      const score = el("div", "sb-score", t, "0");
      const pips = el("div", "sb-pips", t);
      const pipArr: HTMLElement[] = [];
      for (let i = 0; i < MATCH.ROUNDS_TO_WIN; i++) pipArr.push(el("span", "sb-pip", pips));
      return { score, pips: pipArr };
    };
    const blue = mkTeam(0);
    this.roundEl = el("div", "sb-round", sb, "ROUND 1");
    const red = mkTeam(1);
    this.scoreEls = [blue.score, red.score];
    this.pipEls = [blue.pips, red.pips];

    // ---------- top left: pause + minimap ----------
    const tl = el("div", "hud-topleft", this.root);
    const pauseBtn = el("button", "hud-btn square", tl, ICON.pause);
    pauseBtn.addEventListener("pointerdown", (e) => { e.stopPropagation(); this.onPause(); });
    this.minimap = el("canvas", "minimap", tl) as HTMLCanvasElement;
    this.minimap.width = 132;
    this.minimap.height = 132;
    this.mapCtx = this.minimap.getContext("2d")!;

    // ---------- kill feed ----------
    this.killfeedEl = el("div", "killfeed", this.root);

    // ---------- left controls ----------
    const joyWrap = el("div", "joystick-zone", this.root);
    this.joyBase = el("div", "joystick-base", joyWrap);
    this.joyKnob = el("div", "joystick-knob", this.joyBase);
    this.bindJoystick(this.joyBase);

    const leftBtns = el("div", "left-buttons", this.root);
    this.btnPlate = el("button", "hud-btn round small", leftBtns, ICON.plate);
    this.plateBadge = el("span", "badge", this.btnPlate, "2");
    this.btnPlate.addEventListener("pointerdown", (e) => { e.stopPropagation(); input.queueAction("plate"); });
    this.btnCrouch = el("button", "hud-btn round", leftBtns, ICON.crouch);
    this.btnCrouch.addEventListener("pointerdown", (e) => { e.stopPropagation(); input.queueAction("crouch"); });

    // ---------- right controls ----------
    const right = el("div", "right-controls", this.root);
    const top = el("div", "rc-top", right);
    this.btnGrenade = el("button", "hud-btn round small", top, ICON.grenade);
    this.grenadeBadge = el("span", "badge", this.btnGrenade, "8");
    this.btnGrenade.addEventListener("pointerdown", (e) => { e.stopPropagation(); input.queueAction("grenade"); });
    this.btnAds = el("button", "hud-btn round small", top, ICON.ads);
    this.bindHold(this.btnAds, (v) => { input.aimHeld = v; });

    const mid = el("div", "rc-mid", right);
    this.btnWeapon = el("button", "hud-btn round small", mid, ICON.swap);
    this.btnWeapon.addEventListener("pointerdown", (e) => { e.stopPropagation(); input.queueAction("switch"); });
    this.btnReload = el("button", "hud-btn round small", mid, ICON.reload);
    this.btnReload.addEventListener("pointerdown", (e) => { e.stopPropagation(); input.queueAction("reload"); });

    this.btnFire = el("button", "hud-btn fire", right, `${ICON.fire}<span>FIRE</span>`);
    this.bindHold(this.btnFire, (v) => { input.fireHeld = v; });

    // ---------- bottom center: HP + loadout ----------
    const bottom = el("div", "hud-bottom", this.root);
    const hpWrap = el("div", "hpbar", bottom);
    this.hpFill = el("div", "hpfill", hpWrap);
    this.hpText = el("div", "hptext", hpWrap, "100");

    const loadout = el("div", "loadout", bottom);
    const armor = el("div", "slot", loadout, `${ICON.plate}<span class="slot-count" id="plateCount">2</span>`);
    el("div", "slot-label", armor, "ARMOR");
    this.plateSlot = armor;
    const weapon = el("div", "slot weapon", loadout, `${ICON.rifle}<div class="weapon-info"><div class="wname" id="wname">AR-77</div><div class="ammo" id="ammo">30/120</div></div>`);
    this.weaponNameEl = weapon.querySelector("#wname") as HTMLElement;
    this.ammoEl = weapon.querySelector("#ammo") as HTMLElement;
    this.reloadBar = el("div", "reloadbar", weapon);
    el("div", "slot-label", weapon, "PRIMARY");
    const nade = el("div", "slot", loadout, `${ICON.grenade}<span class="slot-count" id="nadeCount">8</span>`);
    this.nadeCountEl = nade.querySelector("#nadeCount") as HTMLElement;
    this.nadeBar = el("div", "nadebar", nade);
    el("div", "slot-label", nade, "FRAG");

    // ---------- center ----------
    this.crosshair = el("div", "crosshair", this.root);
    this.chLines = [
      el("i", "ch t", this.crosshair), el("i", "ch b", this.crosshair),
      el("i", "ch l", this.crosshair), el("i", "ch r", this.crosshair),
    ];
    el("i", "ch dot", this.crosshair);
    this.hitmarker = el("div", "hitmarker", this.root);
    for (let i = 0; i < 4; i++) el("i", `hm ${["t", "b", "l", "r"][i]}`, this.hitmarker);
    this.vignette = el("div", "vignette", this.root);
    this.bannerEl = el("div", "banner", this.root);
    const dmgWrap = el("div", "dmg-numbers", this.root);
    for (let i = 0; i < 10; i++) this.dmgPool.push(el("div", "dmg-num", dmgWrap));

    // ---------- screens ----------
    this.screens = {
      title: this.buildTitleScreen(),
      pause: this.buildPauseScreen(),
      gameover: this.buildGameoverScreen(),
    };
  }

  private plateSlot: HTMLElement;

  // ============================================================ screens
  private buildTitleScreen(): HTMLElement {
    const s = el("div", "screen title-screen", this.root);
    el("div", "title-logo", s, 'STEEL <em>COURTYARD</em>');
    el("div", "title-sub", s, "MOBILE TACTICAL FPS · 5 ROUND ARENA");
    const play = el("button", "big-btn", s, "▶ &nbsp;DEPLOY");
    play.addEventListener("click", () => this.onDeploy());
    const help = el("div", "title-help", s,
      `<b>TOUCH</b> left stick move · drag to aim · FIRE / ADS / ⟳ / ✚ buttons<br>
       <b>DESKTOP</b> WASD move · mouse aim (click to lock) · LMB fire · RMB ADS · R reload · Q swap · G frag · C crouch · E plate`);
    const mute = el("button", "hud-btn square mute-btn", s, "🔊");
    this.muteBtns.push(mute);
    mute.addEventListener("click", () => { this.refreshMute(this.onMuteToggle()); });
    return s;
  }

  private buildPauseScreen(): HTMLElement {
    const s = el("div", "screen pause-screen", this.root);
    el("div", "screen-title", s, "PAUSED");
    const resume = el("button", "big-btn", s, "RESUME");
    resume.addEventListener("click", () => this.onResume());
    const restart = el("button", "menu-btn", s, "RESTART MATCH");
    restart.addEventListener("click", () => this.onRestart());
    const mute = el("button", "menu-btn", s, "SOUND: ON");
    this.muteBtns.push(mute);
    mute.addEventListener("click", () => { const m = this.onMuteToggle(); mute.textContent = m ? "SOUND: OFF" : "SOUND: ON"; });
    return s;
  }

  private buildGameoverScreen(): HTMLElement {
    const s = el("div", "screen gameover-screen", this.root);
    el("div", "screen-title", s, "VICTORY");
    el("div", "screen-sub", s, "");
    const again = el("button", "big-btn", s, "PLAY AGAIN");
    again.addEventListener("click", () => this.onRestart());
    return s;
  }

  showScreen(id: ScreenId, data?: { title?: string; sub?: string }): void {
    (Object.keys(this.screens) as (keyof typeof this.screens)[]).forEach((k) => {
      this.screens[k].classList.toggle("visible", k === id);
    });
    if (id === "gameover" && data) {
      this.screens.gameover.querySelector(".screen-title")!.textContent = data.title ?? "";
      this.screens.gameover.querySelector(".screen-sub")!.textContent = data.sub ?? "";
    }
  }

  refreshMute(muted: boolean): void {
    for (const b of this.muteBtns) {
      if (b.classList.contains("mute-btn")) b.textContent = muted ? "🔇" : "🔊";
      else b.textContent = muted ? "SOUND: OFF" : "SOUND: ON";
    }
  }

  setHudVisible(v: boolean): void {
    this.root.classList.toggle("in-game", v);
  }

  // ============================================================ controls binding
  private bindHold(btn: HTMLElement, set: (v: boolean) => void): void {
    btn.addEventListener("pointerdown", (e) => { e.stopPropagation(); set(true); btn.classList.add("active"); });
    const off = (e: Event) => { e.stopPropagation(); set(false); btn.classList.remove("active"); };
    btn.addEventListener("pointerup", off);
    btn.addEventListener("pointercancel", off);
    btn.addEventListener("pointerleave", off);
  }

  private bindJoystick(base: HTMLElement): void {
    let activeId: number | null = null;
    const R = 52;
    const handle = (e: PointerEvent) => {
      const rect = base.getBoundingClientRect();
      let dx = e.clientX - (rect.left + rect.width / 2);
      let dy = e.clientY - (rect.top + rect.height / 2);
      const d = Math.hypot(dx, dy);
      if (d > R) { dx = (dx / d) * R; dy = (dy / d) * R; }
      this.joyKnob.style.transform = `translate(${dx}px, ${dy}px)`;
      this.input.joyX = dx / R;
      this.input.joyY = dy / R;
    };
    base.addEventListener("pointerdown", (e) => {
      e.stopPropagation();
      activeId = e.pointerId;
      base.setPointerCapture(e.pointerId);
      base.classList.add("active");
      handle(e);
    });
    base.addEventListener("pointermove", (e) => {
      if (e.pointerId !== activeId) return;
      e.stopPropagation();
      handle(e);
    });
    const end = (e: PointerEvent) => {
      if (e.pointerId !== activeId) return;
      e.stopPropagation();
      activeId = null;
      this.input.joyX = 0;
      this.input.joyY = 0;
      this.joyKnob.style.transform = "translate(0,0)";
      base.classList.remove("active");
    };
    base.addEventListener("pointerup", end);
    base.addEventListener("pointercancel", end);
  }

  // ============================================================ events → display
  addKill(ev: KillEvent): void {
    const row = el("div", "kf-row", this.killfeedEl);
    const atk = ev.attackerTeam === 0 ? "blue" : "red";
    const vic = ev.victimTeam === 0 ? "blue" : "red";
    row.innerHTML =
      `<span class="kf-name ${atk}">${ev.attacker}</span>` +
      `<span class="kf-wpn">${ICON.rifle}${ev.headshot ? '<span class="kf-hs">⦿</span>' : ""}</span>` +
      `<span class="kf-name ${vic}">${ev.victim}</span>`;
    // keep max 4
    while (this.killfeedEl.children.length > 4) this.killfeedEl.firstChild?.remove();
    setTimeout(() => { row.classList.add("fade"); setTimeout(() => row.remove(), 500); }, 4200);
  }

  showBanner(text: string, sub: string, tone: "info" | "good" | "bad", seconds: number): void {
    this.bannerEl.className = `banner show ${tone}`;
    this.bannerEl.innerHTML = `${text}${sub ? `<small>${sub}</small>` : ""}`;
    this.bannerTimer = seconds;
  }

  hitmark(killed: boolean, headshot: boolean): void {
    this.hitmarker.className = "hitmarker show" + (killed ? " kill" : headshot ? " head" : "");
    setTimeout(() => this.hitmarker.classList.remove("show"), 90);
  }

  damageFlash(strength: number): void {
    this.vignette.style.opacity = String(Math.min(0.85, 0.35 + strength));
  }

  damageNumber(x: number, y: number, amount: number, killed: boolean, headshot: boolean): void {
    const d = this.dmgPool.find((x) => !x.classList.contains("live")) ?? this.dmgPool[0];
    d.textContent = killed ? "☠" : String(Math.round(amount));
    d.className = "dmg-num live" + (killed ? " kill" : headshot ? " head" : "");
    d.style.left = `${x + (Math.random() - 0.5) * 40}px`;
    d.style.top = `${y - 10 + (Math.random() - 0.5) * 16}px`;
    setTimeout(() => d.classList.remove("live"), 700);
  }

  // ============================================================ per-frame update
  setWallData(colliders: AABB[], wallHalf: number): void {
    this.wallRects = [];
    const pad = wallHalf + 12; // world [-pad, pad] maps to map
    this.mapScale = this.minimap.width / (pad * 2);
    for (const c of colliders) {
      this.wallRects.push({
        x: (c.minX + pad) * this.mapScale,
        z: (c.minZ + pad) * this.mapScale,
        w: (c.maxX - c.minX) * this.mapScale,
        h: (c.maxZ - c.minZ) * this.mapScale,
      });
    }
  }

  update(dt: number, d: HudFrameData, blips: MinimapBlip[], playerHp: number): void {
    // banner
    if (this.bannerTimer > 0) {
      this.bannerTimer -= dt;
      if (this.bannerTimer <= 0) this.bannerEl.classList.remove("show");
    }
    // vignette decay
    const vo = parseFloat(this.vignette.style.opacity || "0");
    if (vo > 0) this.vignette.style.opacity = String(Math.max(0, vo - dt * 1.6));

    // scores + pips
    this.scoreEls[0].textContent = String(d.scores[0]);
    this.scoreEls[1].textContent = String(d.scores[1]);
    this.pipEls[0].forEach((p, i) => p.classList.toggle("on", i < d.scores[0]));
    this.pipEls[1].forEach((p, i) => p.classList.toggle("on", i < d.scores[1]));
    this.roundEl.textContent = `ROUND ${d.round}`;

    // hp
    const hpPct = Math.max(0, playerHp / d.maxHp);
    this.hpFill.style.width = `${hpPct * 100}%`;
    this.hpFill.classList.toggle("low", hpPct < 0.35);
    this.hpText.textContent = String(Math.ceil(playerHp));

    // ammo / weapon
    this.ammoEl.textContent = `${d.mag} / ${d.reserve}`;
    this.weaponNameEl.textContent = d.reloading ? "RELOADING…" : d.weaponName;
    this.reloadBar.style.width = d.reloading ? `${(1 - d.reloadProgress) * 100}%` : "0%";
    this.reloadBar.style.opacity = d.reloading ? "1" : "0";

    // grenades + cooldown
    this.grenadeBadge.textContent = String(d.grenades);
    this.nadeCountEl.textContent = String(d.grenades);
    this.nadeBar.style.width = `${d.grenadeCooldown * 100}%`;

    // plates
    this.plateBadge.textContent = String(d.plates);
    const pc = this.plateSlot.querySelector(".slot-count") as HTMLElement;
    pc.textContent = String(d.plates);
    pc.classList.toggle("channeling", d.plateProgress >= 0);
    if (d.plateProgress >= 0) (this.plateSlot as HTMLElement).style.setProperty("--ch", `${d.plateProgress * 100}%`);
    else (this.plateSlot as HTMLElement).style.setProperty("--ch", "0%");

    // crouch button state
    this.btnCrouch.classList.toggle("toggled", d.crouched);
    this.btnCrouch.innerHTML = d.crouched ? ICON.stand : ICON.crouch;

    // crosshair spread: gap in px from radians
    const gap = 10 + Math.tan(Math.min(0.12, d.spread)) * 900 * (1 - d.adsAmount * 0.55);
    const [t, b, l, r] = this.chLines;
    t.style.transform = `translate(-50%, ${-gap - 9}px)`;
    b.style.transform = `translate(-50%, ${gap}px)`;
    l.style.transform = `translate(${-gap - 9}px, -50%)`;
    r.style.transform = `translate(${gap}px, -50%)`;
    this.crosshair.style.opacity = d.adsAmount > 0.7 ? "0.55" : "1";

    // ADS button highlight
    this.btnAds.classList.toggle("toggled", d.adsAmount > 0.5);

    this.drawMinimap(blips);
  }

  private drawMinimap(blips: MinimapBlip[]): void {
    const g = this.mapCtx;
    const W = this.minimap.width;
    g.clearRect(0, 0, W, W);
    g.fillStyle = "rgba(10,14,20,0.72)";
    g.beginPath();
    g.arc(W / 2, W / 2, W / 2, 0, Math.PI * 2);
    g.fill();
    g.save();
    g.beginPath();
    g.arc(W / 2, W / 2, W / 2 - 2, 0, Math.PI * 2);
    g.clip();
    g.fillStyle = "rgba(150,155,165,0.5)";
    for (const r of this.wallRects) g.fillRect(r.x, r.z, Math.max(1, r.w), Math.max(1, r.h));
    for (const b of blips) {
      const px = b.x * this.mapScale + W / 2;
      const pz = b.z * this.mapScale + W / 2;
      if (b.isPlayer) {
        g.save();
        g.translate(px, pz);
        g.rotate(-b.yaw);
        g.fillStyle = "#4fc3ff";
        g.beginPath();
        g.moveTo(0, -6);
        g.lineTo(4.4, 5);
        g.lineTo(-4.4, 5);
        g.closePath();
        g.fill();
        g.restore();
      } else {
        g.fillStyle = b.team === 0 ? "#3fa9ff" : "#ff5040";
        g.beginPath();
        g.arc(px, pz, 3.2, 0, Math.PI * 2);
        g.fill();
      }
    }
    g.restore();
    g.strokeStyle = "rgba(120,180,255,0.4)";
    g.lineWidth = 2;
    g.beginPath();
    g.arc(W / 2, W / 2, W / 2 - 1.5, 0, Math.PI * 2);
    g.stroke();
  }

  dispose(): void {
    this.root.remove();
  }
}

void SVG;
