/**
 * config.ts — ajustes globais de "Crônicas do Cristal".
 * Valores herdados do protótipo Godot (player.gd / enemy.gd / game.gd),
 * com equilíbrio real de jogo (vida e mana finitas, com regeneração).
 */

export const VIEW = {
  WIDTH: 960,
  HEIGHT: 540,
} as const;

export const PLAYER = {
  SPEED: 290,
  JUMP_VELOCITY: -560,
  GRAVITY: 1450,
  BODY_W: 30,
  BODY_H: 54,
  MAX_HP: 100,
  MAX_MANA: 100,
  MANA_REGEN: 7, // por segundo
  ATTACK_COOLDOWN: 0.32,
  MAGIC_COOLDOWN: 0.65,
  MAGIC_COST: 35,
  INVULN_TIME: 0.5,
  FALL_DAMAGE: 10,
  RESPAWN_BACK: 150,
} as const;

export const COMBAT = {
  SWORD_DAMAGE: 2,
  SWORD_RANGE_X: 85,
  SWORD_RANGE_Y: 70,
  MAGIC_DAMAGE: 5,
  MAGIC_RANGE_X: 330,
  MAGIC_RANGE_Y: 130,
  CONTACT_DAMAGE: 10,
  CONTACT_RANGE_X: 45,
  CONTACT_RANGE_Y: 65,
  UNLOCK_CRYSTALS: 5,
} as const;

export const ENEMY = {
  HP: 6,
  BOSS_HP: 40,
  SPEED: 65,
  BOSS_SPEED: 95,
  CHASE_DISTANCE: 260,
  HIT_FLASH: 0.12,
} as const;

export const WORLD = {
  GROUND_Y: 430,
  KILL_Y: 700,
  PLATFORM_W: 150,
  PLATFORM_H: 22,
  PLATFORM_STEP: 270,
  PLATFORM_LIFT: 105,
  PLATFORM_LIFT_ALT: 55,
  PORTAL_OFFSET: 100, // portal a `length - PORTAL_OFFSET`
  ADVANCE_OFFSET: 120,
  CRYSTAL_COUNT: 18,
  CRYSTAL_RADIUS: 22,
} as const;

/** Paleta por tema (céu, montanhas, chão, plataformas, acento). */
export interface LevelTheme {
  skyTop: number;
  skyBottom: number;
  mountain: number;
  mountainFar: number;
  floor: number;
  platform: number;
  accent: number;
  fog: number;
}

export const COLORS = {
  heroSkin: 0xf3c795,
  heroBody: 0x1f335f,
  heroHood: 0x2ee0bf,
  heroCape: 0x173a6e,
  sword: 0xd9ecff,
  swordGlow: 0x73d9ff,
  enemyBody: 0x8c334e,
  enemyDark: 0x331f2e,
  enemyEye: 0xff4026,
  bossBody: 0x5a1f8c,
  bossHorn: 0xd94d59,
  crystal: 0x40d9ff,
  crystalCore: 0xccfbff,
  portal: 0x57d9ff,
  hp: 0x3ddc84,
  hpBack: 0x14321f,
  mana: 0x4aa8ff,
  manaBack: 0x12283f,
  text: 0xf2f7ff,
  gold: 0xffe68c,
} as const;
