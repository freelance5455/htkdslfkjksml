/** config.ts — global tuning. */

export const INPUT_CONFIG = {
  MOUSE_SENS_X: 0.0026,
  MOUSE_SENS_Y: 0.0022,
  INVERT_X: false,
  INVERT_Y: false,
} as const;

export const WORLD = {
  SIZE: 1100,          // world is SIZE x SIZE meters, centered on 0,0
  VIEW_DIST: 220,
  SEED: 20261119,
  /** Zone centers (x, z) — +z is south, -z is north. */
  ZONES: {
    temple:   { x: 0,    z: 0,    r: 34,  name: "المعبد المهجور" },
    forest:   { x: 0,    z: 0,    r: 150, name: "غابة الرماد" },
    city:     { x: 10,   z: -230, r: 120, name: "مدينة إيراث" },
    ice:      { x: 250,  z: 20,   r: 130, name: "جبال الجليد الأسود" },
    swamp:    { x: -20,  z: 240,  r: 120, name: "مستنقع الأرواح" },
    desert:   { x: -250, z: 10,   r: 120, name: "صحراء العظام" },
    castle:   { x: 0,    z: -430, r: 130, name: "قلعة ملك الظلال" },
  },
  DAY_LENGTH: 480, // seconds per full day cycle
} as const;

export const PLAYER = {
  HEIGHT: 1.8,
  RADIUS: 0.45,
  WALK: 4.2,
  RUN: 7.2,
  ACCEL: 26,
  FRICTION: 12,
  JUMP_V: 7.5,
  GRAVITY: 22,
  DODGE_SPEED: 12,
  DODGE_TIME: 0.38,
  DODGE_IFRAMES: 0.3,
  STAMINA_ROLL: 22,
  STAMINA_ATTACK: 12,
  STAMINA_BLOCK_HIT: 16,
  STAMINA_REGEN: 30,
  MANA_REGEN: 6,
  HP_BASE: 100,
  STAMINA_BASE: 100,
  MANA_BASE: 60,
} as const;

export const COMBAT = {
  LOCK_DIST: 26,
  LOCK_ANGLE: 0.9,
  HITSTOP_LIGHT: 0.05,
  HITSTOP_HEAVY: 0.11,
} as const;

export const XP_LEVELS = [0, 100, 260, 480, 780, 1150, 1600, 2150, 2800, 3600, 4600, 5800];

export const QUALITY = {
  PARTICLES_HIGH: 600,
  PARTICLES_LOW: 180,
  DEGRADE_FPS: 45,
} as const;
