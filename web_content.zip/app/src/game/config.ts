export const INPUT_CONFIG = {
  MOUSE_SENS_X: 0.0026,
  MOUSE_SENS_Y: 0.0022,
  INVERT_X: false,
  INVERT_Y: false,
} as const;

export const GAME = {
  STEP: 1 / 60,
  MAX_ENEMIES: 110,
  MAX_BULLETS: 240,
  MAX_PARTICLES: 360,
  MAX_PICKUPS: 150,
  MAX_SHOCKWAVES: 24,
  MAX_LIGHTNING: 32,
  MAX_TEXTS: 32,
  WAVE_DURATION: 22,
  FINAL_WAVE: 5,
  PLAYER_SPEED: 245,
  DASH_SPEED: 670,
  DASH_DURATION: 0.22,
  DASH_COOLDOWN: 2.15,
  CONTACT_INVULN: 0.72,
  COLORS: {
    bg: "#090e1b", grid: "#17223a", cyan: "#55f6d2", blue: "#62a8ff",
    pink: "#ff4f81", orange: "#ffb65c", purple: "#b58aff", green: "#8cff8a",
    white: "#edf7ff", red: "#ff5266", xp: "#7df9ff", gold: "#ffe27a",
  },
} as const;

export const QUALITY = { PARTICLES_HIGH: 360, PARTICLES_LOW: 150, DEGRADE_FPS: 45 } as const;
export const COLORS = { background: 0x070a14 } as const;
