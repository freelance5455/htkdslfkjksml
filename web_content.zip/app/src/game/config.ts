/**
 * config.ts — global tuning for Steel Courtyard FPS.
 * Input conventions (fixed — if changed, sync scripts/verify-game.mjs):
 *   W / ArrowUp = forward (moveZ +1) · S = back · A = left (moveX -1) · D = right
 *   mouse right => camera turns right (yaw decreases, right-handed) · mouse up => look up (pitch +)
 */

export const INPUT_CONFIG = {
  MOUSE_SENS_X: 0.0026,
  MOUSE_SENS_Y: 0.0022,
  TOUCH_LOOK_SENS: 0.0052,
  INVERT_X: false,
  INVERT_Y: false,
} as const;

export const QUALITY = {
  PARTICLES_HIGH: 400,
  PARTICLES_LOW: 120,
  DEGRADE_FPS: 45,
} as const;

export const PLAYER = {
  HEIGHT_STAND: 1.7,
  HEIGHT_CROUCH: 1.05,
  EYE_RATIO: 0.93,          // eye at this fraction of height
  RADIUS: 0.42,
  WALK_SPEED: 4.6,
  CROUCH_SPEED: 2.3,
  ADS_SPEED_MULT: 0.62,
  ACCEL: 34,
  FRICTION: 11,
  HP: 100,
  REGEN_DELAY: 5.0,         // seconds without damage before regen
  REGEN_RATE: 22,           // hp/s
  PLATE_ABSORB: 50,         // each armor plate absorbs this much
  MAX_PLATES: 2,
  PLATE_TIME: 1.4,          // seconds to apply a plate
} as const;

export const WEAPONS = {
  rifle: {
    name: "AR-77 VANDAL",
    damage: 26,
    headMult: 1.9,
    rpm: 540,
    magSize: 30,
    reserve: 120,
    spreadHip: 0.028,       // radians of base spread
    spreadAds: 0.0045,
    spreadMovePenalty: 0.05,
    spreadCrouchBonus: 0.45,// multiply spread by this when crouched
    recoilKick: 0.038,      // pitch added per shot
    recoilRecover: 6.5,     // rad/s recovery
    reloadTime: 2.1,
    range: 80,
    adsFov: 50,
    auto: true,
  },
  pistol: {
    name: "P9 SIDEARM",
    damage: 22,
    headMult: 1.7,
    rpm: 320,
    magSize: 12,
    reserve: 48,
    spreadHip: 0.022,
    spreadAds: 0.006,
    spreadMovePenalty: 0.04,
    spreadCrouchBonus: 0.5,
    recoilKick: 0.03,
    recoilRecover: 8,
    reloadTime: 1.5,
    range: 50,
    adsFov: 58,
    auto: false,
  },
} as const;

export type WeaponId = keyof typeof WEAPONS;

export const GRENADE = {
  COUNT: 8,
  FUSE: 2.2,
  RADIUS: 6.5,
  MAX_DAMAGE: 120,
  MIN_DAMAGE: 18,
  THROW_SPEED: 13,
  THROW_UP: 4.2,
  COOLDOWN: 1.1,
  GRAVITY: 16,
} as const;

export const BOTS = {
  COUNT_RED: 4,
  COUNT_BLUE: 2,
  HP: 100,
  WALK_SPEED: 3.4,
  STRAFE_SPEED: 2.6,
  SIGHT_RANGE: 40,
  FOV_COS: Math.cos((75 * Math.PI) / 180), // half-angle of vision cone
  REACTION_TIME: 0.55,      // seconds before first shot after acquiring target
  BURST_MIN: 3,
  BURST_MAX: 6,
  BURST_GAP: 0.75,          // seconds between bursts
  FIRE_INTERVAL: 0.11,
  DAMAGE: 7,                // per bullet vs player
  SPREAD: 0.035,
  RESPAWN_DELAY: 2.4,       // wave respawn (round mode keeps them dead; FFA-less)
  HEAD_Y: 1.62,
} as const;

export const MATCH = {
  ROUNDS_TO_WIN: 5,
  ROUND_RESET_DELAY: 3.2,
  COUNTDOWN: 2.2,
} as const;

export const COLORS = {
  background: 0x33415c,
  fog: 0x3a4763,
  blue: 0x3fa9ff,
  red: 0xff5040,
  muzzle: 0xffc46b,
} as const;

/** Team ids: 0 = blue (player), 1 = red. */
export type TeamId = 0 | 1;
