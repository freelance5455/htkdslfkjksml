/**
 * hero.ts — o herói de "Crônicas do Cristal": física do protótipo Godot
 * (speed 290 / pulo -560 / gravidade 1450) com animação por partes e
 * vida/mana reais (o protótipo tinha valores infinitos — aqui o jogo é de verdade).
 */
import Phaser from "phaser";
import { PLAYER, COLORS } from "./config";

export class Hero {
  readonly container: Phaser.GameObjects.Container;
  readonly body: Phaser.Physics.Arcade.Body;

  hp: number = PLAYER.MAX_HP;
  mana: number = PLAYER.MAX_MANA;
  facing: 1 | -1 = 1;
  onFloor = false;
  invuln = 0;
  attackCd = 0;
  magicCd = 0;
  attackAnim = 0;
  castAnim = 0;
  hurtAnim = 0;
  private runTime = 0;
  private wasOnFloor = true;

  // partes visuais
  private cape: Phaser.GameObjects.Graphics;
  private capePts: { x: number; y: number }[];
  private torso: Phaser.GameObjects.Ellipse;
  private belt: Phaser.GameObjects.Rectangle;
  private head: Phaser.GameObjects.Ellipse;
  private hood: Phaser.GameObjects.Arc;
  private face: Phaser.GameObjects.Ellipse;
  private eye: Phaser.GameObjects.Ellipse;
  private arm: Phaser.GameObjects.Container;
  private flash: Phaser.GameObjects.Ellipse;

  constructor(private scene: Phaser.Scene, x: number, y: number) {
    this.container = scene.add.container(x, y);
    const C = COLORS;

    this.cape = scene.add.graphics();
    this.capePts = [
      { x: 0, y: -50 },
      { x: -16, y: -8 },
      { x: 14, y: -6 },
    ];

    this.torso = scene.add.ellipse(0, -26, 30, 52, C.heroBody);
    this.belt = scene.add.rectangle(0, -16, 30, 7, 0x2ee0bf, 0.9);
    this.flash = scene.add.ellipse(0, -27, 34, 56, 0xffffff, 0);

    this.head = scene.add.ellipse(0, -46, 26, 26, C.heroSkin);
    this.hood = scene.add.arc(0, -50, 14, 180, 360, false, C.heroHood);
    this.face = scene.add.ellipse(3, -44, 16, 14, C.heroSkin);
    this.eye = scene.add.ellipse(6, -46, 4, 5, 0x12233f);

    // braço com espada
    this.arm = scene.add.container(10, -34);
    const blade = scene.add.rectangle(16, 0, 30, 5, C.sword).setRotation(Math.PI / 2);
    const tip = scene.add.triangle(31, 0, 0, 4, 0, -4, 8, 0, C.sword);
    const guard = scene.add.rectangle(1, 0, 4, 12, 0xd9a545);
    const glow = scene.add.ellipse(16, 0, 44, 16, C.swordGlow, 0.18);
    this.arm.add([glow, blade, tip, guard]);
    this.arm.setRotation(0.9);

    this.container.add([this.cape, this.torso, this.belt, this.flash, this.head, this.hood, this.face, this.eye, this.arm]);
    this.container.setDepth(10);

    scene.physics.add.existing(this.container);
    this.body = this.container.body as Phaser.Physics.Arcade.Body;
    this.body.setSize(PLAYER.BODY_W, PLAYER.BODY_H);
    this.body.setOffset(-PLAYER.BODY_W / 2, -PLAYER.BODY_H);
    this.body.setMaxVelocityY(900);
  }

  get x(): number {
    return this.container.x;
  }
  get y(): number {
    return this.container.y;
  }

  /** Movimento por eixo: -1 esquerda, +1 direita, 0 parado. */
  setAxis(axis: number): void {
    this.body.setVelocityX(axis * PLAYER.SPEED);
    if (axis !== 0) this.facing = axis > 0 ? 1 : -1;
  }

  jump(): void {
    if (this.onFloor) {
      this.body.setVelocityY(PLAYER.JUMP_VELOCITY);
      this.onFloor = false;
    }
  }

  canAttack(): boolean {
    return this.attackCd <= 0;
  }

  canMagic(): boolean {
    return this.magicCd <= 0 && this.mana >= PLAYER.MAGIC_COST;
  }

  startAttack(): void {
    this.attackCd = PLAYER.ATTACK_COOLDOWN;
    this.attackAnim = PLAYER.ATTACK_COOLDOWN;
  }

  startCast(): void {
    this.magicCd = PLAYER.MAGIC_COOLDOWN;
    this.castAnim = 0.45;
    this.mana = Math.max(0, this.mana - PLAYER.MAGIC_COST);
  }

  takeDamage(amount: number, force = false): boolean {
    if (this.invuln > 0 && !force) return false;
    this.hp = Math.max(0, this.hp - amount);
    this.invuln = PLAYER.INVULN_TIME;
    this.hurtAnim = 0.3;
    return true;
  }

  respawnAt(x: number, y: number): void {
    this.container.setPosition(x, y);
    this.body.reset(x, y);
    this.body.setVelocity(0, 0);
  }

  /** Atualiza timers e animação. Retorna true se o pé acabou de tocar o chão. */
  update(dt: number): boolean {
    let landed = false;
    this.invuln = Math.max(0, this.invuln - dt);
    this.attackCd = Math.max(0, this.attackCd - dt);
    this.magicCd = Math.max(0, this.magicCd - dt);
    this.attackAnim = Math.max(0, this.attackAnim - dt);
    this.castAnim = Math.max(0, this.castAnim - dt);
    this.hurtAnim = Math.max(0, this.hurtAnim - dt);
    this.mana = Math.min(PLAYER.MAX_MANA, this.mana + PLAYER.MANA_REGEN * dt);

    this.onFloor = this.body.blocked.down || this.body.touching.down;
    if (this.onFloor && !this.wasOnFloor) landed = true;
    this.wasOnFloor = this.onFloor;

    // ---- animação por partes ----
    const vx = this.body.velocity.x;
    const speedRatio = Math.abs(vx) / PLAYER.SPEED;
    if (this.onFloor && speedRatio > 0.05) this.runTime += dt * (8 + 6 * speedRatio);
    else this.runTime = 0;

    const bob = this.onFloor ? Math.abs(Math.sin(this.runTime)) * 3 * speedRatio : 0;
    const lean = this.onFloor ? vx * 0.0004 : vx * 0.0006;

    this.container.setRotation(lean);
    this.container.y += 0; // bob aplicado no torso para não brigar com o corpo físico
    this.torso.y = -26 - bob;
    this.belt.y = -16 - bob;
    this.head.y = -46 - bob * 1.2;
    this.hood.y = -50 - bob * 1.2;
    this.face.y = -44 - bob * 1.2;
    this.eye.y = -46 - bob * 1.2;

    // orientação (espelha as partes sem tocar no corpo de física)
    const f = this.facing;
    this.face.x = 3 * f;
    this.eye.x = 6 * f;
    this.arm.x = 10 * f;
    this.arm.setScale(f, 1);
    this.hood.setScale(f, 1);

    // capa com balanço
    const sway = Math.sin(this.runTime * 1.4) * 4 * Math.max(0.25, speedRatio) + vx * -0.02;
    const lift = this.onFloor ? 0 : 8; // capa levanta no ar
    this.capePts[0].x = 0;
    this.capePts[0].y = -50 - bob;
    this.capePts[1].x = -16 + sway - lift;
    this.capePts[1].y = -8 + lift * 0.4;
    this.capePts[2].x = 14 + sway * 0.6 - lift;
    this.capePts[2].y = -6 + lift * 0.4;
    this.cape.clear();
    this.cape.fillStyle(COLORS.heroCape, 1);
    this.cape.fillPoints(this.capePts, true);

    // espada: repouso / golpe / conjuração
    if (this.attackAnim > 0) {
      const t = 1 - this.attackAnim / PLAYER.ATTACK_COOLDOWN; // 0→1
      const swing = Phaser.Math.Easing.Cubic.Out(t);
      this.arm.setRotation(Phaser.Math.Linear(0.9, -1.9, swing) * f * f); // arco do golpe
    } else if (this.castAnim > 0) {
      this.arm.setRotation(-0.4 * f);
    } else {
      this.arm.setRotation(this.onFloor ? 0.9 : 1.4);
    }

    // flash de dano + piscar de invulnerabilidade
    const flashA = this.hurtAnim > 0 ? (this.hurtAnim / 0.3) * 0.65 : 0;
    this.flash.setAlpha(flashA);
    this.container.setAlpha(this.invuln > 0 && this.hurtAnim <= 0 ? 0.55 + 0.35 * Math.sin(this.invuln * 40) : 1);

    return landed;
  }

  destroy(): void {
    this.container.destroy();
  }
}
