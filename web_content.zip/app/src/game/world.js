import * as THREE from 'three';
import { mat, makeKiosk, makeTree, makeBush, makeCloud, makeBucket, makeWashArch } from './models.js';

// ——— Раскладка локации (в метрах) ———
export const LAYOUT = {
  bounds: { minX: -26, maxX: 26, minZ: -17, maxZ: 17 },   // границы ходьбы
  roadZ: -22,          // центр дороги
  laneZ: -8,           // полоса подъезда внутри территории
  entryX: -24,         // въезд с дороги
  exitX: 24,           // выезд на дорогу
  slotXs: [-9, 0, 9],  // X-координаты мест мойки
  slotZ: 2,            // Z мест мойки
  kioskPos: new THREE.Vector3(17, 0, 9),
  workerIdle: [new THREE.Vector3(14, 0, 6), new THREE.Vector3(19, 0, 6)],
  playerSpawn: new THREE.Vector3(0, 0, 10),
};

// Статичные препятствия (круги): игрок и работники их обходят простым выталкиванием
export const COLLIDERS = [
  { x: LAYOUT.kioskPos.x, z: LAYOUT.kioskPos.z, r: 2.4 },
  { x: -9, z: LAYOUT.slotZ, r: 0 }, // заполняется арками ниже
];

export function createWorld(scene, rand) {
  // ——— Свет ———
  const hemi = new THREE.HemisphereLight(0xcfe8ff, 0x6f8f5f, 0.95);
  scene.add(hemi);
  const sun = new THREE.DirectionalLight(0xfff3dd, 2.4);
  sun.position.set(24, 34, 16);
  sun.castShadow = true;
  sun.shadow.mapSize.set(2048, 2048);
  sun.shadow.camera.left = -34; sun.shadow.camera.right = 34;
  sun.shadow.camera.top = 34; sun.shadow.camera.bottom = -34;
  sun.shadow.camera.far = 90;
  sun.shadow.bias = -0.0008;
  scene.add(sun);

  scene.background = new THREE.Color(0x8ec8ee);
  scene.fog = new THREE.Fog(0x9fd0ee, 55, 140);

  // ——— Земля (трава) ———
  const ground = new THREE.Mesh(new THREE.CircleGeometry(160, 48).rotateX(-Math.PI / 2),
    mat(0x6fae5a, { roughness: 1 }));
  ground.receiveShadow = true;
  scene.add(ground);

  // ——— Асфальтовая территория мойки ———
  const lot = new THREE.Mesh(new THREE.BoxGeometry(56, 0.1, 30), mat(0xb8bec6, { roughness: 0.95 }));
  lot.position.set(0, 0.05, 0);
  lot.receiveShadow = true;
  scene.add(lot);
  // Бордюр территории
  const curbM = mat(0x8f979f, { roughness: 0.9 });
  for (const [w, d, x, z] of [[56, 0.4, 0, -15.2], [56, 0.4, 0, 15.2], [0.4, 30, -28.2, 0], [0.4, 30, 28.2, 0]]) {
    const c = new THREE.Mesh(new THREE.BoxGeometry(w, 0.24, d), curbM);
    c.position.set(x, 0.12, z);
    c.receiveShadow = true;
    scene.add(c);
  }

  // ——— Дорога (за территорией) ———
  const road = new THREE.Mesh(new THREE.BoxGeometry(200, 0.08, 7), mat(0x3d434c, { roughness: 0.95 }));
  road.position.set(0, 0.04, LAYOUT.roadZ);
  road.receiveShadow = true;
  scene.add(road);
  // Разметка
  const dashM = mat(0xf0f0e8, { roughness: 0.8 });
  for (let x = -96; x <= 96; x += 6) {
    const dash = new THREE.Mesh(new THREE.BoxGeometry(2.6, 0.02, 0.28), dashM);
    dash.position.set(x, 0.09, LAYOUT.roadZ);
    scene.add(dash);
  }
  // Въезд/выезд — полоса, соединяющая дорогу и территорию
  const laneM = mat(0x4a505a, { roughness: 0.95 });
  for (const x of [LAYOUT.entryX, LAYOUT.exitX]) {
    const lane = new THREE.Mesh(new THREE.BoxGeometry(5, 0.09, 14.5), laneM);
    lane.position.set(x, 0.05, (LAYOUT.roadZ + LAYOUT.laneZ) / 2 + 0.4);
    lane.receiveShadow = true;
    scene.add(lane);
  }

  // ——— Киоск ———
  const kiosk = makeKiosk();
  kiosk.position.copy(LAYOUT.kioskPos);
  kiosk.rotation.y = Math.PI; // окном к территории
  scene.add(kiosk);

  // ——— Арки мойки (3 места; неразблокированные скрыты) ———
  const arches = [];
  for (const x of LAYOUT.slotXs) {
    const arch = makeWashArch();
    arch.position.set(x, 0, LAYOUT.slotZ);
    scene.add(arch);
    arches.push(arch);
    COLLIDERS.push({ x: x - 2.1, z: LAYOUT.slotZ, r: 0.8 });
    COLLIDERS.push({ x: x + 2.1, z: LAYOUT.slotZ, r: 0.8 });
  }

  // Вёдра у мойки
  for (const [x, z] of [[-11.8, 5.4], [2.8, 5.4], [11.8, 5.4]]) {
    const b = makeBucket();
    b.position.set(x, 0, z);
    scene.add(b);
  }

  // ——— Деревья и кусты по периметру ———
  const deco = new THREE.Group();
  for (let i = 0; i < 26; i++) {
    const a = rand() * Math.PI * 2;
    const r = 38 + rand() * 55;
    const x = Math.cos(a) * r, z = Math.sin(a) * r * 0.8;
    if (Math.abs(z - LAYOUT.roadZ) < 9) continue;
    const tree = makeTree(rand);
    tree.position.set(x, 0, z);
    deco.add(tree);
  }
  for (let i = 0; i < 14; i++) {
    const x = -30 + rand() * 60;
    const z = 18 + rand() * 10;
    const b = makeBush(rand);
    b.position.x = x; b.position.z = z;
    deco.add(b);
  }
  // Ряд кустов вдоль южной границы
  for (let x = -24; x <= 24; x += 6) {
    if (Math.abs(x) < 3) continue;
    const b = makeBush(rand);
    b.position.set(x, 0, 16.4);
    deco.add(b);
  }
  scene.add(deco);

  // ——— Облака ———
  const clouds = [];
  for (let i = 0; i < 7; i++) {
    const c = makeCloud();
    c.position.set(-90 + rand() * 180, 26 + rand() * 12, -50 + rand() * 70);
    const s = 1.6 + rand() * 2.2;
    c.scale.setScalar(s);
    scene.add(c);
    clouds.push({ mesh: c, speed: 0.4 + rand() * 0.5 });
  }

  // ——— Дальние холмы для горизонта ———
  const hillM = mat(0x5c9450, { roughness: 1 });
  for (const [x, z, r, h] of [[-70, -60, 46, 12], [60, -70, 55, 15], [10, -90, 60, 10], [-90, 30, 40, 9], [90, 40, 48, 11]]) {
    const hill = new THREE.Mesh(new THREE.SphereGeometry(r, 16, 10), hillM);
    hill.position.set(x, -r + h, z);
    hill.scale.y = 0.35;
    scene.add(hill);
  }

  return {
    arches,
    update(dt) {
      for (const c of clouds) {
        c.mesh.position.x += c.speed * dt;
        if (c.mesh.position.x > 110) c.mesh.position.x = -110;
      }
    },
  };
}
