import * as THREE from 'three';
import { makeCharacter, animateCharacter, animateWashing, resetWashPose } from './models.js';
import { LAYOUT, COLLIDERS } from './world.js';

const _v = new THREE.Vector3();

export class Player {
  constructor(scene) {
    this.mesh = makeCharacter({ shirt: 0x2e9e5b, cap: 0xf5c542 });
    this.mesh.position.copy(LAYOUT.playerSpawn);
    scene.add(this.mesh);
    this.speed = 5.2;
    this.heading = Math.PI;
    this.washing = null;   // машина, которую моет
    this.moving = 0;
  }

  update(dt, move, camYaw) {
    const len = Math.hypot(move.x, move.y);
    this.moving = len;

    if (len > 0.05) {
      // Направление движения относительно камеры
      const ang = Math.atan2(move.x, move.y) + camYaw;
      const tx = Math.sin(ang), tz = Math.cos(ang);
      // Плавный разворот персонажа
      let da = ang - this.heading;
      while (da > Math.PI) da -= Math.PI * 2;
      while (da < -Math.PI) da += Math.PI * 2;
      this.heading += da * Math.min(1, dt * 12);
      const sp = this.speed * Math.min(len, 1);
      this.mesh.position.x += Math.sin(this.heading) * sp * dt;
      this.mesh.position.z += Math.cos(this.heading) * sp * dt;
      if (this.washing) { resetWashPose(this.mesh); this.washing.washer = null; this.washing = null; }
    }

    // Границы территории
    const b = LAYOUT.bounds;
    this.mesh.position.x = THREE.MathUtils.clamp(this.mesh.position.x, b.minX, b.maxX);
    this.mesh.position.z = THREE.MathUtils.clamp(this.mesh.position.z, b.minZ, b.maxZ);
    // Препятствия
    for (const c of COLLIDERS) {
      if (!c.r) continue;
      const dx = this.mesh.position.x - c.x, dz = this.mesh.position.z - c.z;
      const d = Math.hypot(dx, dz);
      if (d < c.r && d > 0.001) {
        this.mesh.position.x = c.x + dx / d * c.r;
        this.mesh.position.z = c.z + dz / d * c.r;
      }
    }

    this.mesh.rotation.y = this.heading;
  }

  /** Мойка: встаём к машине и трём */
  washCar(car, time) {
    if (this.washing !== car) {
      if (this.washing) this.washing.washer = null;
      this.washing = car;
      car.washer = 'player';
    }
    // Поворачиваемся к машине
    _v.subVectors(car.mesh.position, this.mesh.position);
    this.heading = Math.atan2(_v.x, _v.z);
    this.mesh.rotation.y = this.heading;
    animateWashing(this.mesh, time);
  }

  releaseCar() {
    if (this.washing) { this.washing.washer = null; this.washing = null; }
  }
}

// ——— Камера от третьего лица ———
export class FollowCamera {
  constructor(camera) {
    this.camera = camera;
    this.yaw = Math.PI;      // смотрим с юга на север
    this.dist = 9.5;
    this.height = 5.6;
    this._pos = new THREE.Vector3();
    this._look = new THREE.Vector3();
  }

  update(dt, targetPos, camDX) {
    this.yaw += camDX;
    const tx = targetPos.x - Math.sin(this.yaw) * this.dist;
    const tz = targetPos.z - Math.cos(this.yaw) * this.dist;
    this._pos.set(tx, this.height, tz);
    this.camera.position.lerp(this._pos, Math.min(1, dt * 5));
    this._look.set(targetPos.x, 1.4, targetPos.z);
    this.camera.lookAt(this._look);
  }
}
