/**
 * audio.ts — Web Audio synthesized SFX + adaptive dark-fantasy music layers.
 * Everything is generated at runtime — no audio assets.
 */

const MUTE_KEY = "kos.muted";
const VOL_KEY = "kos.volume";

function readLS(key: string, fallback: string): string {
  try { return localStorage.getItem(key) ?? fallback; } catch { return fallback; }
}
function writeLS(key: string, v: string): void {
  try { localStorage.setItem(key, v); } catch { /* storage blocked — in-memory only */ }
}

export type MusicMode = "title" | "explore" | "combat" | "boss" | "none";

export class AudioSystem {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private sfxBus: GainNode | null = null;
  private musicBus: GainNode | null = null;
  private disposed = false;
  muted = readLS(MUTE_KEY, "0") === "1";
  volume = parseFloat(readLS(VOL_KEY, "0.7")) || 0.7;

  // music layer state
  private musicMode: MusicMode = "none";
  private layers: { osc: OscillatorNode; gain: GainNode; lfo?: OscillatorNode; lfoGain?: GainNode }[] = [];
  private noiseBuffer: AudioBuffer | null = null;
  private combatGain: GainNode | null = null;
  private combatFilter: BiquadFilterNode | null = null;

  private readonly unlock = () => { this.ensureCtx(); };

  constructor() {
    window.addEventListener("pointerdown", this.unlock, { once: true });
    window.addEventListener("keydown", this.unlock, { once: true });
  }

  dispose(): void {
    if (this.disposed) return;
    this.disposed = true;
    window.removeEventListener("pointerdown", this.unlock);
    window.removeEventListener("keydown", this.unlock);
    this.stopMusic();
    this.master?.disconnect();
    this.master = null; this.ctx = null;
    const ctx = this.ctxRef;
    if (ctx && ctx.state !== "closed") void ctx.close();
  }
  private ctxRef: AudioContext | null = null;

  private ensureCtx(): AudioContext {
    if (!this.ctx) {
      this.ctx = new AudioContext();
      this.ctxRef = this.ctx;
      this.master = this.ctx.createGain();
      this.master.gain.value = this.muted ? 0 : this.volume;
      this.master.connect(this.ctx.destination);
      this.sfxBus = this.ctx.createGain();
      this.sfxBus.gain.value = 0.9;
      this.sfxBus.connect(this.master);
      this.musicBus = this.ctx.createGain();
      this.musicBus.gain.value = 0.5;
      this.musicBus.connect(this.master);
      // white noise buffer for percussive/wind sfx
      const len = this.ctx.sampleRate * 2;
      this.noiseBuffer = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
      const d = this.noiseBuffer.getChannelData(0);
      let seed = 12345;
      for (let i = 0; i < len; i++) {
        seed = (seed * 16807) % 2147483647;
        d[i] = (seed / 2147483647) * 2 - 1;
      }
    }
    if (this.ctx.state === "suspended") void this.ctx.resume();
    return this.ctx;
  }

  toggleMute(): boolean {
    this.muted = !this.muted;
    writeLS(MUTE_KEY, this.muted ? "1" : "0");
    if (this.master) this.master.gain.value = this.muted ? 0 : this.volume;
    return this.muted;
  }
  setVolume(v: number): void {
    this.volume = Math.max(0, Math.min(1, v));
    writeLS(VOL_KEY, String(this.volume));
    if (this.master && !this.muted) this.master.gain.value = this.volume;
  }
  getVolume(): number { return this.volume; }

  // ---------------- SFX primitives ----------------

  private tone(
    freq: number, dur: number, type: OscillatorType = "sine",
    vol = 0.3, attack = 0.005, freqEnd?: number, bus?: GainNode,
  ): void {
    const ctx = this.ensureCtx();
    const t = ctx.currentTime;
    const o = ctx.createOscillator();
    const g = ctx.createGain();
    o.type = type;
    o.frequency.setValueAtTime(freq, t);
    if (freqEnd !== undefined) o.frequency.exponentialRampToValueAtTime(Math.max(20, freqEnd), t + dur);
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(vol, t + attack);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g); g.connect(bus ?? this.sfxBus!);
    o.start(t); o.stop(t + dur + 0.05);
  }

  private noise(dur: number, vol = 0.3, filterFreq = 2000, type: BiquadFilterType = "bandpass", q = 1, freqEnd?: number): void {
    const ctx = this.ensureCtx();
    if (!this.noiseBuffer) return;
    const t = ctx.currentTime;
    const src = ctx.createBufferSource();
    src.buffer = this.noiseBuffer;
    src.loop = true;
    const f = ctx.createBiquadFilter();
    f.type = type; f.frequency.setValueAtTime(filterFreq, t); f.Q.value = q;
    if (freqEnd !== undefined) f.frequency.exponentialRampToValueAtTime(Math.max(30, freqEnd), t + dur);
    const g = ctx.createGain();
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    src.connect(f); f.connect(g); g.connect(this.sfxBus!);
    src.start(t); src.stop(t + dur + 0.05);
  }

  // ---------------- Game SFX ----------------

  sfx(name: string): void {
    if (this.muted) return;
    switch (name) {
      case "swing": this.noise(0.16, 0.22, 1400, "bandpass", 2, 500); break;
      case "swingHeavy": this.noise(0.3, 0.35, 900, "bandpass", 1.5, 200); this.tone(90, 0.25, "sawtooth", 0.1, 0.01, 45); break;
      case "hit": this.noise(0.1, 0.4, 2400, "bandpass", 1); this.tone(160, 0.12, "square", 0.18, 0.003, 60); break;
      case "hitHeavy": this.noise(0.22, 0.5, 1600, "bandpass", 1); this.tone(110, 0.3, "sawtooth", 0.28, 0.004, 35); break;
      case "playerHurt": this.tone(220, 0.25, "sawtooth", 0.25, 0.004, 70); this.noise(0.2, 0.25, 700, "lowpass"); break;
      case "block": this.tone(500, 0.1, "square", 0.2, 0.002, 300); this.noise(0.08, 0.3, 3000, "highpass"); break;
      case "parry": this.tone(880, 0.35, "triangle", 0.3, 0.003, 1320); this.tone(440, 0.3, "sine", 0.2, 0.003, 880); break;
      case "roll": this.noise(0.22, 0.18, 500, "lowpass", 1, 150); break;
      case "jump": this.noise(0.12, 0.12, 800, "lowpass"); break;
      case "step": this.noise(0.05, 0.07, 400 + Math.random() * 300, "bandpass", 2); break;
      case "magic": this.tone(600, 0.4, "sine", 0.22, 0.01, 1200); this.tone(300, 0.4, "triangle", 0.15, 0.01, 600); break;
      case "shadowMagic": this.tone(200, 0.5, "sawtooth", 0.2, 0.02, 50); this.noise(0.4, 0.2, 300, "lowpass", 1, 80); break;
      case "heal": this.tone(440, 0.5, "sine", 0.2, 0.05, 880); this.tone(660, 0.6, "sine", 0.15, 0.08, 990); break;
      case "pickup": this.tone(520, 0.12, "sine", 0.2, 0.005, 780); this.tone(780, 0.18, "sine", 0.15, 0.05, 1040); break;
      case "coin": this.tone(988, 0.08, "square", 0.12, 0.002, 988); this.tone(1319, 0.15, "square", 0.1, 0.05); break;
      case "ui": this.tone(700, 0.06, "sine", 0.12, 0.002, 900); break;
      case "uiOpen": this.tone(440, 0.1, "sine", 0.12, 0.005, 660); break;
      case "uiClose": this.tone(660, 0.1, "sine", 0.1, 0.005, 440); break;
      case "quest": this.tone(523, 0.3, "triangle", 0.2, 0.02); this.tone(659, 0.35, "triangle", 0.18, 0.1); this.tone(784, 0.5, "triangle", 0.18, 0.2); break;
      case "questDone": [523, 659, 784, 1047].forEach((f, i) => this.tone(f, 0.5, "triangle", 0.18, 0.02 + i * 0.09)); break;
      case "levelUp": [392, 523, 659, 784, 1047].forEach((f, i) => this.tone(f, 0.6, "sine", 0.16, 0.03 + i * 0.08)); break;
      case "death": this.tone(220, 1.2, "sawtooth", 0.25, 0.02, 40); this.noise(1.0, 0.3, 400, "lowpass", 1, 60); break;
      case "enemyDie": this.noise(0.5, 0.35, 900, "bandpass", 1, 100); this.tone(150, 0.5, "sawtooth", 0.2, 0.01, 40); break;
      case "bossRoar": this.tone(70, 1.4, "sawtooth", 0.4, 0.08, 45); this.noise(1.2, 0.35, 300, "lowpass", 1, 80); this.tone(140, 1.0, "square", 0.15, 0.15, 60); break;
      case "doorOpen": this.noise(0.8, 0.25, 200, "lowpass", 1, 500); this.tone(80, 0.7, "sawtooth", 0.12, 0.1, 120); break;
      case "anvil": this.tone(1800, 0.4, "square", 0.2, 0.001, 900); this.noise(0.15, 0.3, 4000, "highpass"); break;
      case "crystal": this.tone(1200, 0.5, "sine", 0.18, 0.01, 1800); this.tone(900, 0.6, "sine", 0.14, 0.05, 1500); break;
      case "thunder": this.noise(1.8, 0.5, 120, "lowpass", 1, 40); break;
      case "splash": this.noise(0.35, 0.25, 1000, "bandpass", 1, 300); break;
      case "teleport": this.tone(300, 0.6, "sine", 0.2, 0.02, 1500); this.noise(0.5, 0.15, 2000, "bandpass", 2, 4000); break;
      case "roar2": this.tone(60, 1.8, "sawtooth", 0.45, 0.1, 35); this.noise(1.5, 0.4, 250, "lowpass", 1, 60); break;
      case "stingerDark": this.tone(55, 2.5, "sawtooth", 0.35, 0.3, 40); this.tone(82, 2.2, "square", 0.2, 0.5, 55); break;
    }
  }

  // ---------------- Adaptive music ----------------

  /** Dark modal pad: root + fifth + minor third drifting slowly, tension layer for combat/boss. */
  setMusic(mode: MusicMode): void {
    if (mode === this.musicMode) return;
    this.musicMode = mode;
    this.stopMusic();
    if (mode === "none" || this.muted) return;
    const ctx = this.ensureCtx();
    this.musicBus = this.musicBus ?? ctx.createGain();

    const roots: Record<Exclude<MusicMode, "none">, number> = {
      title: 55,   // A1
      explore: 49, // G1
      combat: 58.27, // Bb1
      boss: 46.25, // F#1
    };
    const root = roots[mode as Exclude<MusicMode, "none">] ?? 55;
    const mk = (freq: number, type: OscillatorType, vol: number, detune = 0) => {
      const o = ctx.createOscillator();
      o.type = type; o.frequency.value = freq; o.detune.value = detune;
      const g = ctx.createGain();
      g.gain.value = 0;
      g.gain.linearRampToValueAtTime(vol, ctx.currentTime + 3);
      const lfo = ctx.createOscillator();
      lfo.frequency.value = 0.06 + Math.random() * 0.08;
      const lg = ctx.createGain();
      lg.gain.value = vol * 0.5;
      lfo.connect(lg); lg.connect(g.gain);
      o.connect(g); g.connect(this.musicBus!);
      o.start(); lfo.start();
      this.layers.push({ osc: o, gain: g, lfo, lfoGain: lg });
    };

    if (mode === "title") {
      mk(root, "sawtooth", 0.10); mk(root * 1.5, "sine", 0.12); mk(root * 3, "sine", 0.05, 8); mk(root * 2.4, "triangle", 0.05, -10);
    } else if (mode === "explore") {
      mk(root, "triangle", 0.12); mk(root * 1.498, "sine", 0.10); mk(root * 2, "sine", 0.05, 6); mk(root * 4, "sine", 0.02);
    } else {
      // combat & boss: dissonant cluster + driving low pulse
      mk(root, "sawtooth", 0.12); mk(root * 1.06, "sawtooth", 0.10, 12); mk(root * 1.5, "square", 0.05);
      mk(root * 2, "sine", 0.08);
      // percussive pulse via filtered noise LFO
      const src = ctx.createBufferSource();
      src.buffer = this.noiseBuffer; src.loop = true;
      const f = ctx.createBiquadFilter();
      f.type = "lowpass"; f.frequency.value = 300;
      const g = ctx.createGain(); g.gain.value = 0;
      const lfo = ctx.createOscillator();
      lfo.type = "square"; lfo.frequency.value = mode === "boss" ? 3.2 : 2.4;
      const lg = ctx.createGain(); lg.gain.value = 0.12;
      lfo.connect(lg); lg.connect(g.gain);
      src.connect(f); f.connect(g); g.connect(this.musicBus!);
      src.start(); lfo.start();
      this.layers.push({ osc: lfo, gain: g, lfo: src } as never);
      this.combatGain = g; this.combatFilter = f;
    }
  }

  stopMusic(): void {
    for (const l of this.layers) {
      try {
        l.gain.gain.linearRampToValueAtTime(0, (this.ctx?.currentTime ?? 0) + 1.2);
        setTimeout(() => {
          try { l.osc.stop(); l.lfo?.stop?.(); } catch { /* already stopped */ }
          l.gain.disconnect();
        }, 1400);
      } catch { /* ignore */ }
    }
    this.layers = [];
    this.combatGain = null; this.combatFilter = null;
  }
}
