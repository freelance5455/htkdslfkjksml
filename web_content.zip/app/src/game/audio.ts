import { mulberry32 } from "./content";

export type SfxId = "ui" | "checkpoint" | "hit" | "win" | "lose" | "countdown" | "go";

function readMuted(): boolean {
  try { return localStorage.getItem("apex.muted") === "1"; } catch { return false; }
}

export class AudioSystem {
  muted = readMuted();
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private engine: OscillatorNode | null = null;
  private engineGain: GainNode | null = null;
  private skid: AudioBufferSourceNode | null = null;
  private skidGain: GainNode | null = null;
  private music: OscillatorNode[] = [];
  private disposed = false;
  private readonly unlock = () => { this.ensureCtx(); this.detachUnlock(); };

  constructor() {
    window.addEventListener("pointerdown", this.unlock);
    window.addEventListener("keydown", this.unlock);
  }

  private detachUnlock(): void {
    window.removeEventListener("pointerdown", this.unlock);
    window.removeEventListener("keydown", this.unlock);
  }

  private ensureCtx(): AudioContext {
    if (!this.ctx) {
      this.ctx = new AudioContext();
      this.master = this.ctx.createGain();
      this.master.gain.value = this.muted ? 0 : 0.45;
      this.master.connect(this.ctx.destination);
    }
    if (this.ctx.state === "suspended") void this.ctx.resume();
    return this.ctx;
  }

  start(): void {
    if (this.disposed) return;
    const ctx = this.ensureCtx();
    if (!this.engine) {
      const filter = ctx.createBiquadFilter();
      filter.type = "lowpass";
      filter.frequency.value = 850;
      this.engine = ctx.createOscillator();
      this.engine.type = "sawtooth";
      this.engineGain = ctx.createGain();
      this.engineGain.gain.value = 0;
      this.engine.connect(filter).connect(this.engineGain).connect(this.master!);
      this.engine.start();
    }
    if (!this.skid) {
      const length = ctx.sampleRate * 2;
      const buffer = ctx.createBuffer(1, length, ctx.sampleRate);
      const data = buffer.getChannelData(0);
      const random = mulberry32(420);
      for (let i = 0; i < length; i++) data[i] = random() * 2 - 1;
      this.skid = ctx.createBufferSource();
      this.skid.buffer = buffer;
      this.skid.loop = true;
      const filter = ctx.createBiquadFilter();
      filter.type = "bandpass";
      filter.frequency.value = 1200;
      this.skidGain = ctx.createGain();
      this.skidGain.gain.value = 0;
      this.skid.connect(filter).connect(this.skidGain).connect(this.master!);
      this.skid.start();
    }
    if (!this.music.length) {
      [55, 82.5].forEach((frequency, index) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = index ? "triangle" : "sine";
        osc.frequency.value = frequency;
        gain.gain.value = index ? 0.018 : 0.035;
        osc.connect(gain).connect(this.master!);
        osc.start();
        this.music.push(osc);
      });
    }
  }

  updateEngine(speed: number, throttle: number, slipping: boolean, active: boolean): void {
    if (!this.ctx || !this.engine || !this.engineGain || !this.skidGain) return;
    const t = this.ctx.currentTime;
    const rpm = 45 + Math.abs(speed) * 4.2 + throttle * 35;
    this.engine.frequency.setTargetAtTime(rpm, t, 0.05);
    this.engineGain.gain.setTargetAtTime(active && !this.muted ? 0.055 + throttle * 0.05 : 0, t, 0.08);
    this.skidGain.gain.setTargetAtTime(active && slipping && !this.muted ? 0.07 : 0, t, 0.05);
  }

  toggleMute(): boolean {
    this.muted = !this.muted;
    try { localStorage.setItem("apex.muted", this.muted ? "1" : "0"); } catch { /* session-only */ }
    if (this.master && this.ctx) this.master.gain.setTargetAtTime(this.muted ? 0 : 0.45, this.ctx.currentTime, 0.03);
    return this.muted;
  }

  sfx(id: SfxId): void {
    if (this.disposed || this.muted) return;
    const ctx = this.ensureCtx();
    const spec: Record<SfxId, [OscillatorType, number, number, number, number]> = {
      ui: ["sine", 420, 560, 0.07, 0.12],
      checkpoint: ["sine", 650, 1100, 0.16, 0.2],
      hit: ["square", 130, 45, 0.18, 0.25],
      win: ["triangle", 520, 1040, 0.55, 0.24],
      lose: ["sawtooth", 190, 55, 0.55, 0.2],
      countdown: ["sine", 330, 330, 0.1, 0.18],
      go: ["triangle", 520, 880, 0.28, 0.24],
    };
    const [type, f0, f1, duration, volume] = spec[id];
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    const t = ctx.currentTime;
    osc.type = type;
    osc.frequency.setValueAtTime(f0, t);
    osc.frequency.exponentialRampToValueAtTime(Math.max(1, f1), t + duration);
    gain.gain.setValueAtTime(volume, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + duration);
    osc.connect(gain).connect(this.master!);
    osc.start(t);
    osc.stop(t + duration);
  }

  dispose(): void {
    if (this.disposed) return;
    this.disposed = true;
    this.detachUnlock();
    this.engine?.stop();
    this.skid?.stop();
    for (const osc of this.music) osc.stop();
    this.music = [];
    this.master?.disconnect();
    if (this.ctx && this.ctx.state !== "closed") void this.ctx.close();
    this.ctx = null;
  }
}
