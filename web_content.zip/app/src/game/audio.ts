/**
 * audio.ts — Web Audio synthesized SFX + ambient music for Steel Courtyard FPS.
 * No audio files: gunshots, explosions, UI and a tense low pulse are all synthesized.
 * Mute state persists in localStorage (defensive — never throws when storage is blocked).
 */

export type SfxId =
  | "shot"        // player rifle
  | "pistol"      // player pistol
  | "enemyShot"   // distant bot shot (volume scaled by distance)
  | "empty"       // dry trigger click
  | "reloadStart"
  | "reloadEnd"
  | "hit"         // hitmarker confirmed
  | "kill"        // elimination
  | "hurt"        // player takes damage
  | "plate"       // armor plate applied
  | "throw"       // grenade toss
  | "bounce"
  | "explosion"
  | "step"        // player footstep
  | "ui"
  | "countdown"
  | "roundWin"
  | "roundLose"
  | "matchWin"
  | "matchLose";

const MUTE_KEY = "scf.muted";

function readMuted(): boolean {
  try { return localStorage.getItem(MUTE_KEY) === "1"; } catch { return false; }
}
function writeMuted(v: boolean): void {
  try { localStorage.setItem(MUTE_KEY, v ? "1" : "0"); } catch { /* in-memory only */ }
}

export class AudioSystem {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private noiseBuf: AudioBuffer | null = null;
  private musicTimer: number | null = null;
  private disposed = false;
  muted = false;

  private readonly unlock = () => { this.ensureCtx(); this.detachUnlock(); };

  constructor() {
    this.muted = readMuted();
    window.addEventListener("pointerdown", this.unlock);
    window.addEventListener("keydown", this.unlock);
  }

  private detachUnlock(): void {
    window.removeEventListener("pointerdown", this.unlock);
    window.removeEventListener("keydown", this.unlock);
  }

  dispose(): void {
    if (this.disposed) return;
    this.disposed = true;
    this.detachUnlock();
    this.stopMusic();
    this.master?.disconnect();
    this.master = null;
    const ctx = this.ctx;
    this.ctx = null;
    if (ctx && ctx.state !== "closed") void ctx.close();
  }

  private ensureCtx(): AudioContext {
    if (!this.ctx) {
      this.ctx = new AudioContext();
      this.master = this.ctx.createGain();
      this.master.gain.value = this.muted ? 0 : 0.55;
      this.master.connect(this.ctx.destination);
      // 1s of white noise, reused by every gunshot / explosion
      const len = this.ctx.sampleRate;
      this.noiseBuf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
      const data = this.noiseBuf.getChannelData(0);
      for (let i = 0; i < len; i++) data[i] = Math.random() * 2 - 1;
    }
    if (this.ctx.state === "suspended") void this.ctx.resume();
    return this.ctx;
  }

  toggleMute(): boolean {
    this.muted = !this.muted;
    writeMuted(this.muted);
    if (this.master) this.master.gain.value = this.muted ? 0 : 0.55;
    return this.muted;
  }

  /** Fire a synthesized effect. `distance` (0 = self) attenuates distant shots. */
  sfx(id: SfxId, distance = 0): void {
    if (this.disposed || this.muted) return;
    const ctx = this.ensureCtx();
    const att = distance <= 0 ? 1 : Math.max(0.06, 1 / (1 + distance * 0.16));
    const t = ctx.currentTime;

    const noise = (dur: number, filterFreq: number, gain: number, type: BiquadFilterType = "lowpass", freqEnd?: number) => {
      if (!this.noiseBuf || !this.master) return;
      const src = ctx.createBufferSource();
      src.buffer = this.noiseBuf;
      src.loop = true;
      const filt = ctx.createBiquadFilter();
      filt.type = type;
      filt.frequency.setValueAtTime(filterFreq, t);
      if (freqEnd) filt.frequency.exponentialRampToValueAtTime(Math.max(40, freqEnd), t + dur);
      const g = ctx.createGain();
      g.gain.setValueAtTime(gain * att, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + dur);
      src.connect(filt).connect(g).connect(this.master);
      src.start(t);
      src.stop(t + dur + 0.02);
    };
    const tone = (freq: number, dur: number, gain: number, type: OscillatorType = "square", freqEnd?: number, delay = 0) => {
      if (!this.master) return;
      const o = ctx.createOscillator();
      o.type = type;
      o.frequency.setValueAtTime(freq, t + delay);
      if (freqEnd) o.frequency.exponentialRampToValueAtTime(Math.max(20, freqEnd), t + delay + dur);
      const g = ctx.createGain();
      g.gain.setValueAtTime(0.0001, t + delay);
      g.gain.exponentialRampToValueAtTime(gain * att, t + delay + 0.008);
      g.gain.exponentialRampToValueAtTime(0.001, t + delay + dur);
      o.connect(g).connect(this.master);
      o.start(t + delay);
      o.stop(t + delay + dur + 0.02);
    };

    switch (id) {
      case "shot":
        noise(0.09, 3200, 0.5, "lowpass", 500);
        tone(160, 0.07, 0.35, "sawtooth", 60);
        break;
      case "pistol":
        noise(0.07, 2600, 0.4, "lowpass", 400);
        tone(220, 0.06, 0.3, "square", 80);
        break;
      case "enemyShot":
        noise(0.08, 1800, 0.3, "lowpass", 350);
        tone(140, 0.06, 0.2, "sawtooth", 55);
        break;
      case "empty":
        tone(1200, 0.04, 0.14, "square", 800);
        break;
      case "reloadStart":
        tone(500, 0.05, 0.16, "square", 300);
        tone(320, 0.05, 0.14, "square", 200, 0.12);
        break;
      case "reloadEnd":
        tone(700, 0.05, 0.18, "square", 500);
        tone(950, 0.06, 0.16, "square", 700, 0.09);
        break;
      case "hit":
        tone(1500, 0.05, 0.2, "sine", 1100);
        break;
      case "kill":
        tone(880, 0.07, 0.2, "sine");
        tone(1320, 0.09, 0.2, "sine", undefined, 0.07);
        break;
      case "hurt":
        noise(0.12, 900, 0.35, "lowpass", 200);
        tone(180, 0.12, 0.25, "sawtooth", 70);
        break;
      case "plate":
        tone(600, 0.08, 0.18, "sine", 900);
        tone(900, 0.1, 0.15, "sine", 1200, 0.1);
        break;
      case "throw":
        noise(0.15, 1200, 0.14, "bandpass", 300);
        break;
      case "bounce":
        tone(300, 0.05, 0.15, "sine", 180);
        break;
      case "explosion":
        noise(0.7, 900, 0.9, "lowpass", 60);
        tone(90, 0.55, 0.55, "sine", 30);
        break;
      case "step":
        noise(0.05, 500, 0.08, "lowpass", 150);
        break;
      case "ui":
        tone(700, 0.05, 0.12, "sine", 900);
        break;
      case "countdown":
        tone(660, 0.09, 0.2, "sine");
        break;
      case "roundWin":
        tone(523, 0.12, 0.2, "sine");
        tone(659, 0.12, 0.2, "sine", undefined, 0.12);
        tone(784, 0.2, 0.22, "sine", undefined, 0.24);
        break;
      case "roundLose":
        tone(392, 0.15, 0.2, "sine");
        tone(311, 0.25, 0.2, "sine", undefined, 0.15);
        break;
      case "matchWin":
        [523, 659, 784, 1047].forEach((f, i) => tone(f, 0.18, 0.22, "sine", undefined, i * 0.14));
        break;
      case "matchLose":
        [392, 370, 311, 262].forEach((f, i) => tone(f, 0.22, 0.2, "sine", undefined, i * 0.16));
        break;
    }
  }

  /** Slow tactical pulse — starts on user gesture (autoplay policy), stops on dispose. */
  startMusic(): void {
    if (this.disposed || this.musicTimer !== null) return;
    const ctx = this.ensureCtx();
    let step = 0;
    const tick = () => {
      if (this.disposed || this.muted) return;
      const t = ctx.currentTime;
      const bass = [55, 55, 65.4, 49][step % 4];
      const o = ctx.createOscillator();
      o.type = "triangle";
      o.frequency.value = bass;
      const g = ctx.createGain();
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(0.09, t + 0.02);
      g.gain.exponentialRampToValueAtTime(0.001, t + 0.42);
      o.connect(g).connect(this.master!);
      o.start(t);
      o.stop(t + 0.5);
      if (step % 2 === 1) {
        const h = ctx.createOscillator();
        h.type = "sine";
        h.frequency.value = 220 * (step % 8 === 3 ? 1.5 : 1);
        const hg = ctx.createGain();
        hg.gain.setValueAtTime(0.0001, t);
        hg.gain.exponentialRampToValueAtTime(0.03, t + 0.01);
        hg.gain.exponentialRampToValueAtTime(0.001, t + 0.2);
        h.connect(hg).connect(this.master!);
        h.start(t);
        h.stop(t + 0.25);
      }
      step++;
      this.musicTimer = window.setTimeout(tick, 480);
    };
    tick();
  }

  stopMusic(): void {
    if (this.musicTimer !== null) { clearTimeout(this.musicTimer); this.musicTimer = null; }
  }
}
