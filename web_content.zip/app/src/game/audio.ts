/**
 * audio.ts — áudio 100% sintetizado (Web Audio): efeitos + música em camadas.
 * Sem arquivos externos; tudo gerado em runtime após o primeiro gesto do jogador.
 */
import { storage } from "./storage";

const MUTE_KEY = "muted";

type SfxName =
  | "jump"
  | "slash"
  | "hit"
  | "crystal"
  | "magic"
  | "hurt"
  | "enemyDie"
  | "unlock"
  | "portal"
  | "victory"
  | "defeat"
  | "ui";

export class GameAudio {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private sfxGain: GainNode | null = null;
  private musicGain: GainNode | null = null;
  private buffers = new Map<SfxName, AudioBuffer>();
  private musicTimer: number | null = null;
  private musicStep = 0;
  private currentTrack: "forest" | "ruins" | "citadel" | null = null;
  muted = storage.get<boolean>(MUTE_KEY, false);

  /** Deve ser chamado a partir de um gesto do usuário (clique/tecla). */
  unlock(): void {
    if (!this.ctx) {
      const AC = window.AudioContext ?? (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AC();
      this.master = this.ctx.createGain();
      this.master.gain.value = this.muted ? 0 : 1;
      this.master.connect(this.ctx.destination);
      this.sfxGain = this.ctx.createGain();
      this.sfxGain.gain.value = 0.5;
      this.sfxGain.connect(this.master);
      this.musicGain = this.ctx.createGain();
      this.musicGain.gain.value = 0.32;
      this.musicGain.connect(this.master);
      this.renderAll();
    }
    if (this.ctx.state === "suspended") void this.ctx.resume();
  }

  setMuted(m: boolean): void {
    this.muted = m;
    storage.set(MUTE_KEY, m);
    if (this.master && this.ctx) {
      this.master.gain.setTargetAtTime(m ? 0 : 1, this.ctx.currentTime, 0.03);
    }
  }

  toggleMuted(): boolean {
    this.setMuted(!this.muted);
    return this.muted;
  }

  dispose(): void {
    this.stopMusic();
    if (this.ctx) void this.ctx.close();
    this.ctx = null;
  }

  // ---------- SFX ----------

  private renderAll(): void {
    if (!this.ctx) return;
    const sr = this.ctx.sampleRate;
    const make = (dur: number, fn: (t: number) => number) => {
      const buf = this.ctx!.createBuffer(1, Math.ceil(sr * dur), sr);
      const d = buf.getChannelData(0);
      for (let i = 0; i < d.length; i++) d[i] = fn(i / sr);
      return buf;
    };
    const tone = (f0: number, f1: number, dur: number, type: "sine" | "square" | "sawtooth" | "triangle", vol = 1) =>
      make(dur, (t) => {
        const k = t / dur;
        const freq = f0 + (f1 - f0) * k;
        const ph = 2 * Math.PI * freq * t;
        const w =
          type === "sine" ? Math.sin(ph) :
          type === "square" ? Math.sign(Math.sin(ph)) :
          type === "sawtooth" ? 2 * (freq * t - Math.floor(0.5 + freq * t)) :
          2 * Math.abs(2 * (freq * t - Math.floor(freq * t))) - 1;
        return w * vol * (1 - k) * (1 - k);
      });
    const noise = (dur: number, vol = 1, decay = 2) =>
      make(dur, (t) => {
        const k = t / dur;
        // ruído determinístico (sem Math.random no hot path não é necessário; aqui é one-shot)
        const n = Math.sin(t * 4183.7) * Math.sin(t * 733.1) * Math.sin(t * 129.7);
        return n * vol * Math.exp(-decay * k * 4);
      });

    this.buffers.set("jump", tone(240, 620, 0.18, "square", 0.5));
    this.buffers.set("slash", noise(0.14, 0.8));
    this.buffers.set("hit", tone(180, 60, 0.12, "sawtooth", 0.7));
    this.buffers.set("crystal", (() => {
      const a = tone(880, 880, 0.32, "sine", 0.5);
      const b = tone(1320, 1320, 0.32, "sine", 0.3);
      const d = a.getChannelData(0);
      const e = b.getChannelData(0);
      for (let i = 0; i < d.length; i++) d[i] = (d[i] + e[i]) * (1 - i / d.length);
      return a;
    })());
    this.buffers.set("magic", (() => {
      const boom = tone(320, 40, 0.5, "sawtooth", 0.9);
      const shimmer = tone(1200, 2400, 0.4, "sine", 0.25);
      const d = boom.getChannelData(0);
      const e = shimmer.getChannelData(0);
      for (let i = 0; i < d.length; i++) d[i] = d[i] * 0.8 + e[i] * 0.5;
      return boom;
    })());
    this.buffers.set("hurt", tone(140, 50, 0.3, "square", 0.8));
    this.buffers.set("enemyDie", tone(300, 30, 0.35, "sawtooth", 0.6));
    this.buffers.set("unlock", (() => {
      const seq = [523, 659, 784, 1047];
      const dur = 0.8;
      const buf = this.ctx!.createBuffer(1, Math.ceil(sr * dur), sr);
      const d = buf.getChannelData(0);
      for (let i = 0; i < d.length; i++) {
        const t = i / sr;
        const note = Math.min(3, Math.floor(t / 0.18));
        const f = seq[note];
        const env = 1 - (t % 0.18) / 0.18;
        d[i] = Math.sin(2 * Math.PI * f * t) * env * 0.4 * (1 - t / dur);
      }
      return buf;
    })());
    this.buffers.set("portal", tone(300, 900, 0.45, "sine", 0.5));
    this.buffers.set("victory", (() => {
      const seq = [523, 659, 784, 1047, 784, 1047, 1319];
      const dur = 1.6;
      const buf = this.ctx!.createBuffer(1, Math.ceil(sr * dur), sr);
      const d = buf.getChannelData(0);
      for (let i = 0; i < d.length; i++) {
        const t = i / sr;
        const note = Math.min(6, Math.floor(t / 0.2));
        const f = seq[note];
        const env = 1 - (t % 0.2) / 0.2;
        d[i] = (Math.sin(2 * Math.PI * f * t) + 0.4 * Math.sin(2 * Math.PI * f * 2 * t)) * env * 0.35 * (1 - t / dur * 0.5);
      }
      return buf;
    })());
    this.buffers.set("defeat", tone(220, 55, 1.2, "triangle", 0.6));
    this.buffers.set("ui", tone(660, 880, 0.08, "sine", 0.35));
  }

  play(name: SfxName, volume = 1, rate = 1): void {
    if (!this.ctx || !this.sfxGain) return;
    const buf = this.buffers.get(name);
    if (!buf) return;
    const src = this.ctx.createBufferSource();
    src.buffer = buf;
    src.playbackRate.value = rate;
    const g = this.ctx.createGain();
    g.gain.value = volume;
    src.connect(g).connect(this.sfxGain);
    src.start();
  }

  // ---------- Música (sequenciador simples, camadas: baixo + arpejo + pad) ----------

  private static readonly TRACKS: Record<string, { bpm: number; bass: number[]; arp: number[]; pad: number[] }> = {
    forest: {
      bpm: 92,
      bass: [110, 110, 131, 98, 110, 110, 147, 131],
      arp: [440, 523, 659, 523, 440, 523, 587, 659],
      pad: [220, 262, 330, 262],
    },
    ruins: {
      bpm: 84,
      bass: [98, 98, 117, 98, 87, 87, 98, 117],
      arp: [392, 494, 587, 494, 392, 440, 523, 587],
      pad: [196, 233, 294, 233],
    },
    citadel: {
      bpm: 76,
      bass: [87, 87, 104, 87, 82, 82, 87, 104],
      arp: [349, 415, 523, 415, 349, 392, 466, 523],
      pad: [175, 208, 262, 208],
    },
  };

  startMusic(track: "forest" | "ruins" | "citadel"): void {
    if (this.currentTrack === track) return;
    this.stopMusic();
    if (!this.ctx || !this.musicGain) return;
    this.currentTrack = track;
    const data = GameAudio.TRACKS[track];
    const stepDur = 60 / data.bpm / 2; // colcheias
    this.musicStep = 0;
    this.musicTimer = window.setInterval(() => {
      if (!this.ctx || !this.musicGain) return;
      const t = this.ctx.currentTime;
      const step = this.musicStep++;
      const bar8 = step % 8;
      const bar4 = step % 4;
      // baixo (onda quadrada grave)
      this.note(data.bass[bar8], t, stepDur * 0.9, "square", 0.16);
      // arpejo (brilho, só em passos alternados)
      if (step % 2 === 0) this.note(data.arp[(step / 2) % 8], t, stepDur * 0.8, "triangle", 0.08);
      // pad (acorde sustentado, 1 nota por tempo)
      if (step % 4 === 0) this.note(data.pad[bar4], t, stepDur * 3.6, "sine", 0.1);
    }, stepDur * 1000);
  }

  private note(freq: number, t: number, dur: number, type: OscillatorType, vol: number): void {
    if (!this.ctx || !this.musicGain) return;
    const osc = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    osc.type = type;
    osc.frequency.value = freq;
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(vol, t + 0.02);
    g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    osc.connect(g).connect(this.musicGain);
    osc.start(t);
    osc.stop(t + dur + 0.05);
  }

  stopMusic(): void {
    if (this.musicTimer !== null) {
      window.clearInterval(this.musicTimer);
      this.musicTimer = null;
    }
    this.currentTrack = null;
  }
}

export const gameAudio = new GameAudio();
