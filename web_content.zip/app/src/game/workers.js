import * as THREE from 'three';
import { makeCharacter, animateCharacter, animateWashing, resetWashPose } from './models.js';
import { LAYOUT, COLLIDERS } from './world.js';

const _v = new THREE.Vector3();
const WORKER_COLORS = [
  { shirt: 0xd98032, cap: 0x2b3a55 },
  { shirt: 0x8a5cc9, cap: 0x2b3a55 },
];

export class Worker {
  constructor(scene, index) {
    this.mesh = makeCharacter(WORKER_COLORS[index % 2]);
    this.idlePos = LAYOUT.workerIdle[index % LAYOUT.workerIdle.length].clone();
    this.mesh.position.copy(this.idlePos);
    scene.add(this.mesh);
    this.speed = 3.6;
    this.target = null;   // машина-цель
    this.heading = 0;
    this.moving = 0;
  }

  update(dt, time, traffic) {
    // Нет цели — ищем ждущую машину
    if (!this.target) {
      const car = traffic.nearestWaiting(this.mesh.position, 100);
      if (car) { this.target = car; car.reservedBy = this; }
    }

    if (this.target) {
      const car = this.target;
      // Цель исчезла или её помыл игрок
      if (car.state !== 'wait' && car.washer !== this) {
        car.reservedBy = null;
        this.target = null;
        resetWashPose(this.mesh);
      } else {
        _v.subVectors(car.mesh.position, this.mesh.position); _v.y = 0;
        const d = _v.length();
        if (d > 2.5) {
          // Идём к машине
          _v.normalize();
          const ang = Math.atan2(_v.x, _v.z);
          let da = ang - this.heading;
          while (da > Math.PI) da -= Math.PI * 2;
          while (da < -Math.PI) da += Math.PI * 2;
          this.heading += da * Math.min(1, dt * 10);
          this.mesh.position.x += Math.sin(this.heading) * this.speed * dt;
          this.mesh.position.z += Math.cos(this.heading) * this.speed * dt;
          this._collide();
          this.moving = 1;
          animateCharacter(this.mesh, time, this.speed);
        } else {
          // Моем
          this.moving = 0;
          car.washer = this;
          this.heading = Math.atan2(_v.x, _v.z);
          this.mesh.rotation.y = this.heading;
          animateWashing(this.mesh, time);
        }
        this.mesh.rotation.y = this.heading;
        return;
      }
    }

    // Возвращаемся на место ожидания
    _v.subVectors(this.idlePos, this.mesh.position); _v.y = 0;
    const d = _v.length();
    if (d > 0.5) {
      _v.normalize();
      const ang = Math.atan2(_v.x, _v.z);
      let da = ang - this.heading;
      while (da > Math.PI) da -= Math.PI * 2;
      while (da < -Math.PI) da += Math.PI * 2;
      this.heading += da * Math.min(1, dt * 10);
      this.mesh.position.x += Math.sin(this.heading) * this.speed * 0.8 * dt;
      this.mesh.position.z += Math.cos(this.heading) * this.speed * 0.8 * dt;
      this._collide();
      this.moving = 1;
      animateCharacter(this.mesh, time, this.speed * 0.8);
    } else {
      this.moving = 0;
      animateCharacter(this.mesh, time, 0);
    }
    this.mesh.rotation.y = this.heading;
  }

  _collide() {
    for (const c of COLLIDERS) {
      if (!c.r) continue;
      const dx = this.mesh.position.x - c.x, dz = this.mesh.position.z - c.z;
      const d = Math.hypot(dx, dz);
      if (d < c.r && d > 0.001) {
        this.mesh.position.x = c.x + dx / d * c.r;
        this.mesh.position.z = c.z + dz / d * c.r;
      }
    }
    const b = LAYOUT.bounds;
    this.mesh.position.x = THREE.MathUtils.clamp(this.mesh.position.x, b.minX, b.maxX);
    this.mesh.position.z = THREE.MathUtils.clamp(this.mesh.position.z, b.minZ, b.maxZ);
  }

  dispose(scene) { scene.remove(this.mesh); }
}
