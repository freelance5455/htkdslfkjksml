/** data.ts — all game data: weapons, skills, items, equipment, dialogues. */

export type WeaponKind = "dawnblade" | "hammer" | "daggers" | "spear" | "dragon" | "bow";

export interface WeaponDef {
  kind: WeaponKind;
  name: string;
  desc: string;
  baseDmg: number;
  speed: number;       // attack speed multiplier
  range: number;       // hit range
  heavyMult: number;
  hue: number;         // visual evolution color
  special: string;     // special move name
  specialDesc: string;
}

export const WEAPONS: Record<WeaponKind, WeaponDef> = {
  dawnblade: { kind: "dawnblade", name: "نصل الفجر", desc: "سيف قديم متوازن يحمل شرارة قلب النور.", baseDmg: 18, speed: 1.0, range: 2.6, heavyMult: 2.1, hue: 0.13, special: "موجة الفجر", specialDesc: "ضربة ضوء أمامية تخترق الدروع." },
  hammer: { kind: "hammer", name: "مطرقة العمالقة", desc: "سلاح ثقيل يحطم كل ما يقف في طريقه.", baseDmg: 34, speed: 0.62, range: 2.9, heavyMult: 2.6, hue: 0.58, special: "الانهيار", specialDesc: "ضربة أرضية تصعق الأعداء من حولك." },
  daggers: { kind: "daggers", name: "خناجر الأشباح", desc: "زوج من الخناجر السريعة التي تلمع كالأشباح.", baseDmg: 11, speed: 1.55, range: 2.1, heavyMult: 1.7, hue: 0.75, special: "عاصفة النصل", specialDesc: "سلسلة طعنات خاطفة متتالية." },
  spear: { kind: "spear", name: "رمح النور", desc: "سلاح بعيد المدى يضرب قبل أن يراك العدو.", baseDmg: 16, speed: 0.92, range: 4.2, heavyMult: 2.0, hue: 0.52, special: "شعاع الرمح", specialDesc: "رمية طاقة تخترق الأعداء عن بُعد." },
  dragon: { kind: "dragon", name: "سيف التنين", desc: "سلاح أسطوري مكسو بلهب التنانين القديمة.", baseDmg: 30, speed: 0.95, range: 2.9, heavyMult: 2.4, hue: 0.02, special: "لهب التنين", specialDesc: "موجة نار تحرق الأعداء أمامك." },
  bow: { kind: "bow", name: "قوس الصياد", desc: "قوس قديم يطلق سهام النور الخالدة.", baseDmg: 15, speed: 1.1, range: 26, heavyMult: 2.2, hue: 0.33, special: "مطر السهام", specialDesc: "وابل من السهام الساقطة." },
};

export const MAX_WEAPON_TIER = 5;
export function weaponDmg(w: WeaponDef, tier: number): number {
  return Math.round(w.baseDmg * (1 + (tier - 1) * 0.35));
}
export function upgradeCost(tier: number): { crystals: number; ore: number; gold: number } {
  return { crystals: tier * 3, ore: tier * 2, gold: 80 * tier };
}

// ---------------- skills ----------------

export type SkillBranch = "shadow" | "light" | "warrior";
export interface SkillDef {
  id: string;
  branch: SkillBranch;
  name: string;
  desc: string;
  max: number;
  cost: number; // skill points per level
  requires?: string;
}

export const SKILLS: SkillDef[] = [
  { id: "dash", branch: "shadow", name: "اندفاع الظل", desc: "اندفاعة سريعة تخترق الظلام (Shift مرتين / زر القدرة).", max: 3, cost: 1 },
  { id: "cloak", branch: "shadow", name: "عباءة الظل", desc: "اختفاء مؤقت يجعل الأعداء تفقد أثرك.", max: 2, cost: 2, requires: "dash" },
  { id: "clone", branch: "shadow", name: "نسخة الظل", desc: "استدعاء نسخة تقاتل إلى جانبك.", max: 2, cost: 2, requires: "cloak" },
  { id: "burst", branch: "shadow", name: "انفجار الظلام", desc: "انفجار طاقة ظلالية يصعق كل من حولك.", max: 3, cost: 2, requires: "dash" },
  { id: "wave", branch: "light", name: "موجة النور", desc: "موجة طاقة مقدسة تعبر الأعداء.", max: 3, cost: 1 },
  { id: "shield", branch: "light", name: "الدرع السحري", desc: "درع يمتص الضرر لفترة قصيرة.", max: 2, cost: 2, requires: "wave" },
  { id: "heal", branch: "light", name: "استعادة الصحة", desc: "دورة شفاء تسترجع صحتك تدريجياً.", max: 3, cost: 2, requires: "wave" },
  { id: "beam", branch: "light", name: "شعاع الطاقة", desc: "شعاع مركز يضرب الأعداء البعيدين.", max: 2, cost: 2, requires: "wave" },
  { id: "power", branch: "warrior", name: "قوة المحارب", desc: "زيادة الضرر الأساسي لجميع الأسلحة.", max: 5, cost: 1 },
  { id: "agility", branch: "warrior", name: "رشاقة الظلال", desc: "تحسين المراوغة وتقليل كلفة التحمل.", max: 3, cost: 1 },
  { id: "endurance", branch: "warrior", name: "الصبر الأسطوري", desc: "زيادة التحمل الأقصى وسرعة استعادته.", max: 3, cost: 1 },
  { id: "combo", branch: "warrior", name: "الضربات المتتالية", desc: "إطالة سلاسل الكومبو وضرره.", max: 3, cost: 2 },
];

// ---------------- items / resources ----------------

export interface ItemDef { id: string; name: string; desc: string; icon: string; }
export const ITEMS: Record<string, ItemDef> = {
  crystal: { id: "crystal", name: "بلورة النور", desc: "بلورة متوهجة تُستخدم في ترقية الأسلحة.", icon: "🔷" },
  darkcrystal: { id: "darkcrystal", name: "بلورة الظلام", desc: "بلورة مظلمة تنبض بقوة غريبة.", icon: "🟣" },
  ore: { id: "ore", name: "معدن نادر", desc: "معدن متين من أعماق الجبال.", icon: "⛏️" },
  herb: { id: "herb", name: "عشبة علاجية", desc: "عشبة تُستخدم في صناعة الجرعات.", icon: "🌿" },
  fang: { id: "fang", name: "نيش وحش", desc: "نيش من مخلوق الظلال.", icon: "🦷" },
  essence: { id: "essence", name: "جوهر الروح", desc: "جوهر متبقٍ من أرواح الموتى.", icon: "✨" },
  relic: { id: "relic", name: "قطعة أثرية", desc: "قطعة من ماضي مملكة إيراث.", icon: "🏺" },
  potion: { id: "potion", name: "جرعة الحياة", desc: "تستعيد 50% من الصحة. (مفتاح R)", icon: "🧪" },
};

export type EquipSlot = "helm" | "armor" | "gauntlet" | "boots" | "cloak" | "ring";
export interface EquipDef {
  id: string; slot: EquipSlot; name: string; rarity: "common" | "rare" | "epic" | "legendary";
  desc: string; hp?: number; stamina?: number; mana?: number; dmgMult?: number; defMult?: number; speedMult?: number;
}
export const EQUIPMENT: EquipDef[] = [
  { id: "wornArmor", slot: "armor", name: "درع آرين القديم", rarity: "common", desc: "درع أسود بالٍ لا يزال يحمي حامله.", defMult: 1.05 },
  { id: "guardHelm", slot: "helm", name: "خوذة الحارس", rarity: "rare", desc: "خوذة من زمن الملوك القدامى.", hp: 20 },
  { id: "ashCloak", slot: "cloak", name: "عباءة الرماد", rarity: "rare", desc: "عباءة مُنسوجة من رماد الغابة.", stamina: 15 },
  { id: "knightGauntlet", slot: "gauntlet", name: "قفاز الفارس", rarity: "rare", desc: "قبضة حديدية للمحاربين.", dmgMult: 1.08 },
  { id: "swiftBoots", slot: "boots", name: "حذاء الرياح", rarity: "rare", desc: "خفيف كالنسيم.", speedMult: 1.1 },
  { id: "lightRing", slot: "ring", name: "خاتم النور", rarity: "epic", desc: "خاتم يتوهج ببقايا قلب النور.", mana: 25 },
  { id: "titanArmor", slot: "armor", name: "درع العمالقة", rarity: "epic", desc: "صُنع من جلد عملاق الجبال.", hp: 40, defMult: 1.12 },
  { id: "shadowRing", slot: "ring", name: "خاتم الظلال", rarity: "legendary", desc: "همسة ملك الظلال تحبس في داخله.", dmgMult: 1.2, mana: 15 },
];

export const RARITY_COLORS: Record<string, string> = {
  common: "#b8bcc8", rare: "#5aa8ff", epic: "#b06aff", legendary: "#ffb545",
};
export const RARITY_NAMES: Record<string, string> = {
  common: "عادية", rare: "نادرة", epic: "ملحمية", legendary: "أسطورية",
};

// ---------------- enemy defs ----------------

export type EnemyKind = "guard" | "wolf" | "spirit" | "knight" | "giant" | "mage" | "swamper" | "treant" | "shadowking";

export interface EnemyDef {
  kind: EnemyKind;
  name: string;
  hp: number; dmg: number; speed: number; xp: number; gold: number;
  aggroR: number; attackR: number; attackCd: number;
  bodyColor: number; eyeColor: number; scale: number;
  beast?: boolean; hood?: boolean; bulky?: boolean;
  loot: { id: string; min: number; max: number; chance: number }[];
}

export const ENEMIES: Record<EnemyKind, EnemyDef> = {
  guard: { kind: "guard", name: "حارس الظلام", hp: 55, dmg: 12, speed: 3.4, xp: 30, gold: 12, aggroR: 22, attackR: 2.4, attackCd: 1.4, bodyColor: 0x23242e, eyeColor: 0xa040ff, scale: 1.0, loot: [{ id: "darkcrystal", min: 1, max: 2, chance: 0.5 }, { id: "essence", min: 1, max: 1, chance: 0.25 }] },
  wolf: { kind: "wolf", name: "ذئب الرماد", hp: 34, dmg: 9, speed: 5.6, xp: 18, gold: 5, aggroR: 26, attackR: 2.2, attackCd: 1.1, bodyColor: 0x3a3542, eyeColor: 0xff5a3a, scale: 0.95, beast: true, loot: [{ id: "fang", min: 1, max: 2, chance: 0.7 }, { id: "herb", min: 1, max: 2, chance: 0.4 }] },
  spirit: { kind: "spirit", name: "روح الضباب", hp: 40, dmg: 14, speed: 3.0, xp: 26, gold: 8, aggroR: 24, attackR: 12, attackCd: 2.2, bodyColor: 0x9fb4d8, eyeColor: 0x8adfff, scale: 1.0, loot: [{ id: "essence", min: 1, max: 3, chance: 0.8 }, { id: "darkcrystal", min: 1, max: 1, chance: 0.35 }] },
  knight: { kind: "knight", name: "فارس اللعنة", hp: 90, dmg: 20, speed: 3.8, xp: 55, gold: 30, aggroR: 24, attackR: 2.8, attackCd: 1.8, bodyColor: 0x3a2f3f, eyeColor: 0xff3a3a, scale: 1.15, bulky: true, loot: [{ id: "ore", min: 1, max: 3, chance: 0.7 }, { id: "relic", min: 1, max: 1, chance: 0.2 }] },
  giant: { kind: "giant", name: "عملاق الجبال", hp: 220, dmg: 30, speed: 2.6, xp: 130, gold: 70, aggroR: 26, attackR: 4.0, attackCd: 2.4, bodyColor: 0x4a5568, eyeColor: 0x8adfff, scale: 2.0, bulky: true, hood: true, loot: [{ id: "ore", min: 3, max: 6, chance: 1 }, { id: "crystal", min: 1, max: 2, chance: 0.6 }] },
  mage: { kind: "mage", name: "ساحر الظلام", hp: 48, dmg: 18, speed: 3.0, xp: 45, gold: 25, aggroR: 30, attackR: 16, attackCd: 2.4, bodyColor: 0x2a1f3a, eyeColor: 0xc060ff, scale: 1.0, hood: true, loot: [{ id: "darkcrystal", min: 1, max: 3, chance: 0.8 }, { id: "essence", min: 1, max: 2, chance: 0.5 }] },
  swamper: { kind: "swamper", name: "وحش المستنقع", hp: 70, dmg: 16, speed: 4.2, xp: 38, gold: 15, aggroR: 22, attackR: 2.4, attackCd: 1.3, bodyColor: 0x2e4030, eyeColor: 0x7aff9a, scale: 1.05, beast: true, loot: [{ id: "herb", min: 2, max: 4, chance: 0.8 }, { id: "essence", min: 1, max: 1, chance: 0.4 }] },
  treant: { kind: "treant", name: "حارس الغابة", hp: 650, dmg: 26, speed: 2.8, xp: 400, gold: 250, aggroR: 40, attackR: 5.5, attackCd: 2.6, bodyColor: 0x3a2f28, eyeColor: 0x8aff5a, scale: 1.0, loot: [{ id: "relic", min: 2, max: 3, chance: 1 }, { id: "crystal", min: 4, max: 6, chance: 1 }] },
  shadowking: { kind: "shadowking", name: "ملك الظلال", hp: 1500, dmg: 34, speed: 3.6, xp: 1200, gold: 1000, aggroR: 60, attackR: 4.0, attackCd: 1.6, bodyColor: 0x15101f, eyeColor: 0xc040ff, scale: 1.5, bulky: true, loot: [] },
};

/** Which enemies spawn in each zone. */
export const ZONE_SPAWNS: Record<string, { kind: EnemyKind; count: number }[]> = {
  forest: [{ kind: "wolf", count: 10 }, { kind: "guard", count: 6 }],
  city: [{ kind: "guard", count: 6 }, { kind: "knight", count: 5 }, { kind: "mage", count: 3 }],
  ice: [{ kind: "wolf", count: 6 }, { kind: "giant", count: 3 }],
  swamp: [{ kind: "swamper", count: 8 }, { kind: "spirit", count: 5 }],
  desert: [{ kind: "giant", count: 4 }, { kind: "spirit", count: 4 }],
  castle: [{ kind: "mage", count: 6 }, { kind: "knight", count: 5 }],
};
