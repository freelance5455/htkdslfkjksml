/** save.ts — localStorage save/load (browser-local; no cross-device sync). */
import { PlayerStats } from "./player";
import { WeaponKind } from "./data";
import { QuestState, freshQuestState } from "./quests";

const KEY = "kos.save.v1";

export interface SaveData {
  version: 1;
  stats: PlayerStats;
  pos: [number, number, number];
  weapon: WeaponKind;
  weaponTiers: Record<string, number>;
  ownedWeapons: WeaponKind[];
  skills: Record<string, number>;
  inventory: Record<string, number>;
  equipment: Record<string, string>;
  quests: QuestState;
  waystones: string[];
  chestsOpened: string[];
  notesRead: string[];
  discoveredZones: string[];
  playTime: number;
  kills: number;
  deaths: number;
  ended: string | null;
  endedRuns: number;
}

export function hasSave(): boolean {
  try { return localStorage.getItem(KEY) !== null; } catch { return false; }
}

export function writeSave(d: SaveData): void {
  try { localStorage.setItem(KEY, JSON.stringify(d)); } catch { /* storage blocked */ }
}

export function readSave(): SaveData | null {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return null;
    const d = JSON.parse(raw) as SaveData;
    if (d.version !== 1 || !d.stats || !d.quests) return null;
    return d;
  } catch {
    return null;
  }
}

export function clearSave(): void {
  try { localStorage.removeItem(KEY); } catch { /* ignore */ }
}

export function freshSaveState(): { stats: PlayerStats; quests: QuestState } {
  return {
    stats: { hp: 100, maxHp: 100, stamina: 100, maxStamina: 100, mana: 60, maxMana: 60, level: 1, xp: 0, skillPoints: 1, gold: 0 },
    quests: freshQuestState(),
  };
}
