import * as THREE from "three";
import { mergeGeometries } from "three/addons/utils/BufferGeometryUtils.js";
import { createAsset } from "./carAsset/asset.mjs";

/**
 * car.ts — vehicle visuals.
 *
 * Frame conventions (verified from the asset's named parts: headlamps / grille at -X, hatch + red lamps at +X):
 *  - The merged asset geometry lives in the *source* frame: X = length (front = -X), Y = axle / lateral, Z = up.
 *  - `rootRotation` (-90° about X) converts that to Y-up. `facingYaw` (-90° about Y) then makes the car's front
 *    point to the group's local -Z, which is the game's "forward" at heading 0.
 *  - A visual group is therefore posed with rotation.y = -heading (see CarVisual.setPose).
 */

interface GeometryBucket {
  paint: THREE.BufferGeometry[];
  trim: THREE.BufferGeometry[];
  glass: THREE.BufferGeometry[];
  wheels: Map<string, THREE.BufferGeometry[]>;
}

export interface CarModel {
  paint: THREE.BufferGeometry;
  trim: THREE.BufferGeometry;
  glass: THREE.BufferGeometry;
  wheels: THREE.BufferGeometry[];
  /** Wheel centres in the source frame (before rootRotation). */
  wheelPositions: THREE.Vector3[];
  rootRotation: THREE.Euler;
  /** Yaw applied between the converted root and the game group so that the car's front points to local -Z. */
  facingYaw: number;
  groundOffset: number;
  /** Metres, in the game group frame. */
  length: number;
  width: number;
  height: number;
  wheelRadius: number;
}

export class CarVisual {
  readonly group = new THREE.Group();
  readonly wheels: THREE.Mesh[] = [];
  private frontWheel: boolean[] = [];
  private body: THREE.Group;
  private lift: THREE.Group;
  private wheelSpin = 0;
  private wheelRadius: number;
  private currentRoll = 0;
  private currentPitch = 0;
  private headlights: THREE.Mesh[] = [];
  private tailMat: THREE.MeshBasicMaterial;
  private beam: THREE.Mesh | null = null;
  private beamMat: THREE.MeshBasicMaterial | null = null;
  private flames: THREE.Mesh[] = [];
  private flameMat: THREE.MeshBasicMaterial;
  private lightsOn = false;

  constructor(model: CarModel, color: number, withBeam = false) {
    const root = new THREE.Group();
    root.rotation.copy(model.rootRotation);
    this.wheelRadius = model.wheelRadius;

    // Cheap shading: no clearcoat, no transmission (transmission forces an extra full-scene render pass on mobile).
    const paintMat = new THREE.MeshPhongMaterial({ color, vertexColors: true, shininess: 85, specular: 0x4a4f55 });
    const trimMat = new THREE.MeshLambertMaterial({ vertexColors: true });
    const glassMat = new THREE.MeshPhongMaterial({
      vertexColors: true, transparent: true, opacity: 0.62, shininess: 140, specular: 0xaab8c4, depthWrite: false,
    });
    const wheelMat = new THREE.MeshLambertMaterial({ vertexColors: true });

    root.add(new THREE.Mesh(model.paint, paintMat), new THREE.Mesh(model.trim, trimMat), new THREE.Mesh(model.glass, glassMat));

    model.wheels.forEach((geometry, index) => {
      const wheel = new THREE.Mesh(geometry, wheelMat);
      wheel.position.copy(model.wheelPositions[index]);
      // Steer about the (source) up axis Z, spin about the axle Y: R = Rz(steer) * Ry(spin).
      wheel.rotation.order = "ZYX";
      root.add(wheel);
      this.wheels.push(wheel);
      this.frontWheel.push(model.wheelPositions[index].x < 0); // front is -X in the source frame
    });

    const facing = new THREE.Group();
    facing.rotation.y = model.facingYaw;
    facing.add(root);

    this.body = new THREE.Group();
    this.body.add(facing);

    // Lights live in the game-group frame (front = -Z, rear = +Z, right = +X).
    const hl = new THREE.MeshBasicMaterial({ color: 0xfff1c4 });
    this.tailMat = new THREE.MeshBasicMaterial({ color: 0x7c1414 });
    const hlGeo = new THREE.BoxGeometry(0.34, 0.16, 0.06);
    const tlGeo = new THREE.BoxGeometry(0.34, 0.12, 0.05);
    const frontZ = -model.length / 2 - 0.01, rearZ = model.length / 2 + 0.01;
    for (const side of [-1, 1]) {
      const head = new THREE.Mesh(hlGeo, hl);
      head.position.set(side * model.width * 0.33, model.height * 0.45, frontZ);
      head.visible = false;
      this.body.add(head);
      this.headlights.push(head);
      const tail = new THREE.Mesh(tlGeo, this.tailMat);
      tail.position.set(side * model.width * 0.36, model.height * 0.62, rearZ);
      this.body.add(tail);
    }

    // Nitro flames (apex pointing backwards).
    this.flameMat = new THREE.MeshBasicMaterial({ color: 0xffa24a, transparent: true, opacity: 0.85, depthWrite: false, blending: THREE.AdditiveBlending });
    const flameGeo = new THREE.ConeGeometry(0.15, 1.1, 6);
    flameGeo.rotateX(Math.PI / 2); // apex (+Y) -> +Z
    for (const side of [-1, 1]) {
      const flame = new THREE.Mesh(flameGeo, this.flameMat);
      flame.position.set(side * model.width * 0.26, 0.32, rearZ + 0.5);
      flame.visible = false;
      this.body.add(flame);
      this.flames.push(flame);
    }

    this.lift = new THREE.Group();
    this.lift.position.y = model.groundOffset;
    this.lift.add(this.body);
    this.group.add(this.lift);

    // Soft contact shadow
    const shadow = new THREE.Mesh(
      new THREE.CircleGeometry(2.25, 20),
      new THREE.MeshBasicMaterial({ color: 0x050c0a, transparent: true, opacity: 0.32, depthWrite: false }),
    );
    shadow.scale.set(0.62, 1, 1.0);
    shadow.rotation.x = -Math.PI / 2;
    shadow.position.y = 0.04;
    this.group.add(shadow);

    if (withBeam) {
      // Ground light cone: additive, fades to black at the far end, so it needs no alpha channel.
      const geo = new THREE.BufferGeometry();
      const far = 30, wNear = 0.9, wFar = 9;
      const positions = new Float32Array([
        -wNear, 0.07, frontZ, wNear, 0.07, frontZ, wFar, 0.07, frontZ - far, -wFar, 0.07, frontZ - far,
      ]);
      const colors = new Float32Array([0.55, 0.5, 0.34, 0.55, 0.5, 0.34, 0, 0, 0, 0, 0, 0]);
      geo.setAttribute("position", new THREE.BufferAttribute(positions, 3));
      geo.setAttribute("color", new THREE.BufferAttribute(colors, 3));
      geo.setIndex([0, 1, 2, 0, 2, 3]);
      this.beamMat = new THREE.MeshBasicMaterial({ vertexColors: true, transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, fog: false });
      this.beam = new THREE.Mesh(geo, this.beamMat);
      this.beam.visible = false;
      this.beam.frustumCulled = false;
      this.group.add(this.beam);
    }
  }

  /** Posing uses -heading: see the frame notes at the top of this file. */
  setPose(x: number, y: number, z: number, heading: number): void {
    this.group.position.set(x, y, z);
    this.group.rotation.y = -heading;
  }

  /**
   * @param speed signed forward speed (m/s)
   * @param steering -1..1 (positive = right)
   * @param accel longitudinal acceleration proxy (positive = speeding up)
   * @param lateralAccel positive = sliding / turning right
   */
  update(dt: number, speed: number, steering: number, accel = 0, lateralAccel = 0, slipping = false): void {
    const steerAngle = -steering * 0.38;
    this.wheelSpin -= (speed * dt) / this.wheelRadius; // negative about +Y rolls toward the front (-X)
    for (let i = 0; i < this.wheels.length; i++) {
      const wheel = this.wheels[i];
      wheel.rotation.z = this.frontWheel[i] ? steerAngle : 0;
      wheel.rotation.y = this.wheelSpin;
    }

    const targetRoll = THREE.MathUtils.clamp(
      -lateralAccel * 0.018 - steering * Math.min(Math.abs(speed) / 40, 1) * 0.06, -0.14, 0.14);
    // Nose rises under acceleration and dives under braking.
    const targetPitch = THREE.MathUtils.clamp(accel * 0.03, -0.09, 0.09);
    const k = 1 - Math.exp(-dt * 8);
    this.currentRoll += (targetRoll - this.currentRoll) * k;
    this.currentPitch += (targetPitch - this.currentPitch) * k;
    this.body.rotation.z = this.currentRoll;
    this.body.rotation.x = this.currentPitch;

    const targetLift = slipping ? 0.04 + Math.sin(performance.now() * 0.03) * 0.015 : 0;
    this.lift.position.y += (targetLift - this.lift.position.y) * (1 - Math.exp(-dt * 12));
  }

  /** @param night 0..1  @param braking  @param boosting  @param time seconds (flame flicker) */
  setLights(night: number, braking: boolean, boosting: boolean, time: number): void {
    const on = night > 0.25;
    if (on !== this.lightsOn) {
      this.lightsOn = on;
      for (const h of this.headlights) h.visible = on;
    }
    if (this.beam && this.beamMat) {
      this.beam.visible = on;
      this.beamMat.opacity = on ? Math.min(1, night * 1.15) : 0;
    }
    this.tailMat.color.setHex(braking ? 0xff2d2d : on ? 0xc01c1c : 0x7c1414);
    for (let i = 0; i < this.flames.length; i++) {
      const f = this.flames[i];
      f.visible = boosting;
      if (boosting) {
        const flick = 0.75 + Math.sin(time * 55 + i * 2.1) * 0.25;
        f.scale.set(1, 1, 0.8 + flick * 1.1);
      }
    }
  }
}

// ---------------------------------------------------------------------------------------------------------
// Instanced low-poly fleet: traffic + far-away rivals in 2 draw calls total.
// ---------------------------------------------------------------------------------------------------------

function colored<T extends THREE.BufferGeometry>(geometry: T, color: number): T {
  const c = new THREE.Color(color);
  const count = geometry.attributes.position.count;
  const colors = new Float32Array(count * 3);
  for (let i = 0; i < count; i++) c.toArray(colors, i * 3);
  geometry.setAttribute("color", new THREE.BufferAttribute(colors, 3));
  return geometry;
}

export class Fleet {
  readonly group = new THREE.Group();
  private body: THREE.InstancedMesh;
  private detail: THREE.InstancedMesh;
  private n = 0;
  private matrix = new THREE.Matrix4();
  private quat = new THREE.Quaternion();
  private pos = new THREE.Vector3();
  private one = new THREE.Vector3(1, 1, 1);
  private yAxis = new THREE.Vector3(0, 1, 0);
  private tint = new THREE.Color();

  constructor(readonly capacity: number) {
    // Body (instance-coloured): lower hull + cabin.
    const hull = new THREE.BoxGeometry(1.82, 0.56, 4.0); hull.translate(0, 0.56, 0);
    const cabin = new THREE.BoxGeometry(1.5, 0.5, 2.1); cabin.translate(0, 1.07, 0.3);
    const bodyGeo = mergeGeometries([hull, cabin], false)!;
    hull.dispose(); cabin.dispose();

    // Details (fixed colours): glass band, wheels, lamps.
    const parts: THREE.BufferGeometry[] = [];
    const glass = new THREE.BoxGeometry(1.54, 0.3, 1.8); glass.translate(0, 1.1, 0.3); parts.push(colored(glass, 0x1b2630));
    for (const x of [-0.9, 0.9]) for (const z of [-1.3, 1.3]) {
      const wheel = new THREE.CylinderGeometry(0.34, 0.34, 0.26, 8); wheel.rotateZ(Math.PI / 2); wheel.translate(x, 0.34, z);
      parts.push(colored(wheel, 0x15171a));
    }
    for (const x of [-0.62, 0.62]) {
      const head = new THREE.BoxGeometry(0.4, 0.16, 0.06); head.translate(x, 0.66, -2.01); parts.push(colored(head, 0xfff1c4));
      const tail = new THREE.BoxGeometry(0.4, 0.14, 0.06); tail.translate(x, 0.7, 2.01); parts.push(colored(tail, 0xd12020));
    }
    const detailGeo = mergeGeometries(parts, false)!;
    parts.forEach((p) => p.dispose());

    this.body = new THREE.InstancedMesh(bodyGeo, new THREE.MeshLambertMaterial({ color: 0xffffff }), capacity);
    this.detail = new THREE.InstancedMesh(detailGeo, new THREE.MeshLambertMaterial({ vertexColors: true }), capacity);
    for (const mesh of [this.body, this.detail]) {
      mesh.frustumCulled = false; // at most a dozen instances: culling by a stale bounding sphere would be wrong
      mesh.count = 0;
      this.group.add(mesh);
    }
    // Make sure instanceColor exists from the start.
    for (let i = 0; i < capacity; i++) this.body.setColorAt(i, this.tint.setHex(0xffffff));
  }

  begin(): void { this.n = 0; }

  push(x: number, y: number, z: number, heading: number, color: number): boolean {
    if (this.n >= this.capacity) return false;
    this.quat.setFromAxisAngle(this.yAxis, -heading);
    this.pos.set(x, y, z);
    this.matrix.compose(this.pos, this.quat, this.one);
    this.body.setMatrixAt(this.n, this.matrix);
    this.detail.setMatrixAt(this.n, this.matrix);
    this.body.setColorAt(this.n, this.tint.setHex(color));
    this.n++;
    return true;
  }

  end(): void {
    this.body.count = this.n;
    this.detail.count = this.n;
    this.body.instanceMatrix.needsUpdate = true;
    this.detail.instanceMatrix.needsUpdate = true;
    if (this.body.instanceColor) this.body.instanceColor.needsUpdate = true;
  }

  dispose(): void {
    this.body.geometry.dispose(); (this.body.material as THREE.Material).dispose(); this.body.dispose();
    this.detail.geometry.dispose(); (this.detail.material as THREE.Material).dispose(); this.detail.dispose();
  }
}

// ---------------------------------------------------------------------------------------------------------
// Model loading
// ---------------------------------------------------------------------------------------------------------

let modelPromise: Promise<CarModel> | null = null;

export function loadCarModel(): Promise<CarModel> {
  modelPromise ??= buildOptimizedModel().catch((error) => {
    console.warn("Using procedural car fallback:", error instanceof Error ? error.message : error);
    return buildProceduralModel();
  });
  return modelPromise;
}

async function buildOptimizedModel(): Promise<CarModel> {
  const source = await createAsset(THREE, { states: "lazy", sharedResources: true });
  source.updateMatrixWorld(true);
  const inverseRoot = source.matrixWorld.clone().invert();
  const buckets: GeometryBucket = { paint: [], trim: [], glass: [], wheels: new Map() };
  const wheelPattern = /wheel|tyre|tire|rim|hubcap|spoke|brake disc/i;
  source.traverse((object) => {
    if (!(object instanceof THREE.Mesh)) return;
    const materials = Array.isArray(object.material) ? object.material : [object.material];
    const material = materials[0] as THREE.MeshPhysicalMaterial;
    let geometry = object.geometry.clone();
    if (geometry.index) {
      const nonIndexed = geometry.toNonIndexed();
      geometry.dispose();
      geometry = nonIndexed;
    }
    const matrix = new THREE.Matrix4().multiplyMatrices(inverseRoot, object.matrixWorld);
    geometry.applyMatrix4(matrix);
    for (const name of Object.keys(geometry.attributes)) {
      if (name !== "position" && name !== "normal") geometry.deleteAttribute(name);
    }
    if (!geometry.attributes.normal) geometry.computeVertexNormals();
    const count = geometry.attributes.position.count;
    const isPaint = material.name === "slot:body";
    const color = isPaint ? new THREE.Color(0xffffff) : material.color.clone();
    const colors = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) color.toArray(colors, i * 3);
    geometry.setAttribute("color", new THREE.BufferAttribute(colors, 3));
    let ancestor: THREE.Object3D | null = object;
    let isWheel = false;
    while (ancestor) {
      if (wheelPattern.test(ancestor.name)) { isWheel = true; break; }
      ancestor = ancestor.parent;
    }
    if (isWheel) {
      geometry.computeBoundingBox();
      const center = geometry.boundingBox!.getCenter(new THREE.Vector3());
      const key = `${center.x >= 0 ? "r" : "l"}:${center.y >= 0 ? "f" : "b"}`;
      if (!buckets.wheels.has(key)) buckets.wheels.set(key, []);
      buckets.wheels.get(key)!.push(geometry);
    } else if (material.transmission > 0.5) buckets.glass.push(geometry);
    else if (isPaint) buckets.paint.push(geometry);
    else buckets.trim.push(geometry);
  });
  const paint = mergeGeometries(buckets.paint, false);
  const trim = mergeGeometries(buckets.trim, false);
  const glass = mergeGeometries(buckets.glass, false);
  if (!paint || !trim || !glass) throw new Error("Car geometry optimization failed");
  const wheels: THREE.BufferGeometry[] = [];
  const wheelPositions: THREE.Vector3[] = [];
  let wheelRadius = 0.32;
  for (const geometries of buckets.wheels.values()) {
    const merged = mergeGeometries(geometries, false);
    if (!merged) continue;
    merged.computeBoundingBox();
    const center = merged.boundingBox!.getCenter(new THREE.Vector3());
    merged.translate(-center.x, -center.y, -center.z);
    merged.computeBoundingBox();
    // Source frame is Z-up: the wheel's vertical extent is its diameter.
    wheelRadius = Math.max(0.2, merged.boundingBox!.getSize(new THREE.Vector3()).z / 2);
    wheels.push(merged);
    wheelPositions.push(center);
  }
  const rootRotation = source.rotation.clone();
  const probe = new THREE.Group();
  probe.rotation.copy(rootRotation);
  probe.add(new THREE.Mesh(paint), new THREE.Mesh(trim));
  probe.updateMatrixWorld(true);
  const bounds = new THREE.Box3().setFromObject(probe);
  const size = bounds.getSize(new THREE.Vector3());
  const groundOffset = -bounds.min.y;
  await (source as THREE.Group & { dispose?: () => Promise<void> }).dispose?.();
  // After rootRotation the length runs along X (front = -X) and the width along Z.
  return {
    paint, trim, glass, wheels, wheelPositions, rootRotation, groundOffset, wheelRadius,
    facingYaw: -Math.PI / 2,
    length: size.x, width: size.z, height: size.y,
  };
}

/** Fallback built directly in the same source frame (X length / Y axle / Z up) so the visual code is shared. */
function buildProceduralModel(): CarModel {
  const paint = new THREE.BoxGeometry(4.1, 1.85, 0.48); paint.translate(0, 0, 0.58);
  const cabin = new THREE.BoxGeometry(1.95, 1.55, 0.62); cabin.translate(0.2, 0, 1.05);
  const glass = new THREE.BoxGeometry(1.55, 1.58, 0.38); glass.translate(0.12, 0, 1.15);
  for (const g of [paint, cabin, glass]) {
    const colors = new Float32Array(g.attributes.position.count * 3).fill(1);
    g.setAttribute("color", new THREE.BufferAttribute(colors, 3));
  }
  const wheels: THREE.BufferGeometry[] = [];
  const wheelPositions: THREE.Vector3[] = [];
  for (const x of [-1.3, 1.3]) for (const y of [-0.94, 0.94]) {
    const wheel = new THREE.CylinderGeometry(0.36, 0.36, 0.26, 12); // axle along Y already
    const colors = new Float32Array(wheel.attributes.position.count * 3).fill(0.12);
    wheel.setAttribute("color", new THREE.BufferAttribute(colors, 3));
    wheels.push(wheel);
    wheelPositions.push(new THREE.Vector3(x, y, 0.38));
  }
  return {
    paint, trim: cabin, glass, wheels, wheelPositions,
    rootRotation: new THREE.Euler(-Math.PI / 2, 0, 0), facingYaw: -Math.PI / 2, groundOffset: 0,
    length: 4.1, width: 1.85, height: 1.4, wheelRadius: 0.36,
  };
}
