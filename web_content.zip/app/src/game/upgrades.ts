import type { UpgradeId } from "./types";

export interface UpgradeDef {
  id: UpgradeId;
  name: string;
  description: string;
  icon: string;
  color: string;
  max: number;
}

export const UPGRADES: UpgradeDef[] = [
  { id: "split", name: "انشطار كمّي", description: "أضف مقذوفين مع كل طلقة، بمراوح تصيب الحشود من حولك.", icon: "⋔", color: "#55f6d2", max: 3 },
  { id: "orbit", name: "شفرات مدارية", description: "شفرتان تدوران حولك وتمزّقان كل وحش يقترب.", icon: "◌", color: "#7df9ff", max: 3 },
  { id: "chain", name: "برق متسلسل", description: "الإصابات تطلق برقًا يقفز بين الأعداء ويزداد مع كل مستوى.", icon: "ϟ", color: "#ffe27a", max: 3 },
  { id: "missile", name: "قذائف مطاردة", description: "كل خمس طلقات يطلق صاروخًا يطارد هدفًا وينفجر بين الحشود.", icon: "△", color: "#ff9d6c", max: 3 },
  { id: "nova", name: "نبضة نووية", description: "موجة صادمة دورية تجرح جميع الوحوش القريبة وتزيل رصاصهم.", icon: "◎", color: "#b58aff", max: 3 },
  { id: "overdrive", name: "تسارع جنوني", description: "معدل إطلاق أعلى بـ55٪ وسرعة مقذوفات أكبر.", icon: "»", color: "#ff4f81", max: 3 },
  { id: "pierce", name: "رصاص خارق", description: "ضرر أكبر بـ65٪، والمقذوف يخترق عدوًا إضافيًا.", icon: "↟", color: "#62a8ff", max: 3 },
  { id: "time", name: "حقل زمني", description: "الوحوش القريبة تتحرك أبطأ بـ35٪ داخل هالتك.", icon: "◷", color: "#8fc7ff", max: 3 },
  { id: "vamp", name: "امتصاص حيوي", description: "ارفع صحتك القصوى واستعد نقاط صحة عند سحق الوحوش.", icon: "+", color: "#8cff8a", max: 3 },
  { id: "shield", name: "درع طيفي", description: "درع يتجدد تلقائيًا ويمتص ضربة كاملة.", icon: "◇", color: "#a9b8ff", max: 3 },
  { id: "reactor", name: "انفجار تفاعلي", description: "الوحوش المهزومة تنفجر وتؤذي الأعداء المجاورين.", icon: "✦", color: "#ffb65c", max: 3 },
  { id: "magnet", name: "جاذبية نووية", description: "ضاعف مدى جذب الخبرة وسرعة الحركة لاقتناص الموارد.", icon: "∩", color: "#55f6d2", max: 3 },
];
