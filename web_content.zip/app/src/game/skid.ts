import * as THREE from "three";

/**
 * Skid marks: a ring buffer of ground quads rendered as ONE draw call. Old marks are overwritten, so the
 * cost is constant no matter how long the player drifts.
 */
export class SkidMarks {
  readonly mesh: THREE.Mesh;
  private positions: Float32Array;
  private geometry: THREE.BufferGeometry;
  private material: THREE.MeshBasicMaterial;
  private head = 0;
  private filled = 0;
  private enabled = true;
  private lastX = [0, 0];
  private lastY = [0, 0];
  private lastZ = [0, 0];
  private chain = [false, false];

  constructor(private capacity = 150, private halfWidth = 0.15) {
    this.positions = new Float32Array(capacity * 4 * 3);
    const index = new Uint16Array(capacity * 6);
    for (let s = 0; s < capacity; s++) {
      const b = s * 4;
      // Same winding as the road ribbon: (a, c, b), (c, d, b) -> faces up.
      index.set([b, b + 2, b + 1, b + 2, b + 3, b + 1], s * 6);
    }
    this.geometry = new THREE.BufferGeometry();
    this.geometry.setAttribute("position", new THREE.BufferAttribute(this.positions, 3));
    this.geometry.setIndex(new THREE.BufferAttribute(index, 1));
    this.geometry.setDrawRange(0, 0);
    this.material = new THREE.MeshBasicMaterial({
      color: 0x090a0b, transparent: true, opacity: 0.5, depthWrite: false,
      polygonOffset: true, polygonOffsetFactor: -6, polygonOffsetUnits: -6,
    });
    this.mesh = new THREE.Mesh(this.geometry, this.material);
    this.mesh.frustumCulled = false;
    this.mesh.renderOrder = 2;
  }

  setEnabled(on: boolean): void {
    this.enabled = on;
    this.mesh.visible = on;
    if (!on) this.breakChains();
  }

  breakChains(): void { this.chain[0] = false; this.chain[1] = false; }

  clear(): void {
    this.head = 0; this.filled = 0;
    this.geometry.setDrawRange(0, 0);
    this.breakChains();
  }

  /** @param wheel 0 = left rear, 1 = right rear */
  add(wheel: 0 | 1, x: number, y: number, z: number, marking: boolean): void {
    if (!this.enabled) return;
    if (!marking) { this.chain[wheel] = false; return; }
    if (!this.chain[wheel]) {
      this.lastX[wheel] = x; this.lastY[wheel] = y; this.lastZ[wheel] = z; this.chain[wheel] = true;
      return;
    }
    const dx = x - this.lastX[wheel], dz = z - this.lastZ[wheel];
    const len = Math.hypot(dx, dz);
    if (len < 0.5) return;
    if (len > 4) { this.lastX[wheel] = x; this.lastY[wheel] = y; this.lastZ[wheel] = z; return; }
    const sx = (-dz / len) * this.halfWidth, sz = (dx / len) * this.halfWidth;
    const o = this.head * 12;
    const a = this.positions;
    const ly = this.lastY[wheel] + 0.05, cy = y + 0.05;
    a[o] = this.lastX[wheel] + sx; a[o + 1] = ly; a[o + 2] = this.lastZ[wheel] + sz;
    a[o + 3] = this.lastX[wheel] - sx; a[o + 4] = ly; a[o + 5] = this.lastZ[wheel] - sz;
    a[o + 6] = x + sx; a[o + 7] = cy; a[o + 8] = z + sz;
    a[o + 9] = x - sx; a[o + 10] = cy; a[o + 11] = z - sz;
    this.head = (this.head + 1) % this.capacity;
    this.filled = Math.min(this.capacity, this.filled + 1);
    this.lastX[wheel] = x; this.lastY[wheel] = y; this.lastZ[wheel] = z;
    this.geometry.setDrawRange(0, this.filled * 6);
    (this.geometry.attributes.position as THREE.BufferAttribute).needsUpdate = true;
  }

  dispose(): void {
    this.geometry.dispose();
    this.material.dispose();
  }
}
