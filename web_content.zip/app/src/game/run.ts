/**
 * run.ts — estado da campanha atual (persiste entre fases) + recordes locais.
 * O armazenamento é local do navegador: não sincroniza entre dispositivos.
 */
import { storage } from "./storage";

export class RunState {
  levelIndex = 0;
  crystals = 0;
  magicUnlocked = false;
  enemiesDefeated = 0;
  deaths = 0;
  startedAt = 0;

  reset(): void {
    this.levelIndex = 0;
    this.crystals = 0;
    this.magicUnlocked = false;
    this.enemiesDefeated = 0;
    this.deaths = 0;
    this.startedAt = performance.now();
  }

  elapsedSeconds(): number {
    return Math.max(0, Math.floor((performance.now() - this.startedAt) / 1000));
  }
}

export const run = new RunState();

export const records = {
  get bestCrystals(): number {
    return storage.get<number>("bestCrystals", 0);
  },
  set bestCrystals(v: number) {
    storage.set("bestCrystals", v);
  },
  get wins(): number {
    return storage.get<number>("wins", 0);
  },
  set wins(v: number) {
    storage.set("wins", v);
  },
};
