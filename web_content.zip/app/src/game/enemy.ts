/**
 * enemy.ts — tactical soldier models (parametric 3D) + EnemyAI.
 *
 * Every combatant that isn't the player is a Bot: dark armor, helmet with visor,
 * team-colored shoulder patches, carrying a rifle. Bots run a patrol → engage state
 * machine: they navigate between waypoints, acquire visible enemies with a vision cone
 * + line-of-sight raycast, strafe while firing bursts with a reaction delay, and route
 * all kills through MatchManager so the kill feed and scores stay consistent.
 */

import * as THREE from "three";
import { BOTS, COLORS, TeamId } from "./config";
import { resolveCollision, hasLineOfSight, raycastColliders, AABB } from "./arena";
import { Effects } from "./effects";
import { AudioSystem } from "./audio";
import { rayCylinder, raySphere } from "./weapon";
import type { Shootable } from "./weapon";

/** Minimal combatant shape the AI can target (bots and the player both satisfy it). */
export interface Targetable {
  name: string;
  team: TeamId;
  alive: boolean;
  pos: THREE.Vector3;  // feet
  height: number;
  headY: number;
  radius: number;
}

export interface KillEvent {
  attacker: string;
  attackerTeam: TeamId;
  victim: string;
  victimTeam: TeamId;
  weapon: string;
  headshot: boolean;
}

export interface BotHooks {
  colliders: AABB[];
  waypoints: { x: number; z: number }[];
  effects: Effects;
  audio: AudioSystem;
  /** All live combatants (bots + the player proxy) for target selection. */
  getCombatants: () => Targetable[];
  /** The player as a targetable. */
  getPlayer: () => Targetable;
  onKill: (ev: KillEvent) => void;
  /** Bot bullet hit the player. */
  onPlayerHit: (dmg: number, botName: string) => void;
  /** Distance from player (for audio attenuation + LOD). */
  distanceToPlayer: (pos: THREE.Vector3) => number;
}

// ---------------------------------------------------------------------------
// parametric soldier model
// ---------------------------------------------------------------------------

export interface SoldierRig {
  group: THREE.Group;
  legL: THREE.Mesh;
  legR: THREE.Mesh;
  torso: THREE.Group;
  muzzle: THREE.Object3D;
}

export function createSoldier(team: TeamId): SoldierRig {
  const group = new THREE.Group();
  const armor = new THREE.MeshStandardMaterial({ color: 0x22252a, roughness: 0.7, metalness: 0.3 });
  const cloth = new THREE.MeshStandardMaterial({ color: 0x2c2f26, roughness: 0.95 });
  const visorMat = new THREE.MeshStandardMaterial({ color: 0x0d1420, roughness: 0.15, metalness: 0.9 });
  const teamMat = new THREE.MeshStandardMaterial({ color: team === 0 ? COLORS.blue : COLORS.red, roughness: 0.5, emissive: team === 0 ? 0x0a2c4a : 0x4a120a, emissiveIntensity: 0.6 });
  const gunMat = new THREE.MeshStandardMaterial({ color: 0x1b1d21, roughness: 0.5, metalness: 0.6 });

  const mesh = (geo: THREE.BufferGeometry, mat: THREE.Material, x: number, y: number, z: number): THREE.Mesh => {
    const m = new THREE.Mesh(geo, mat);
    m.position.set(x, y, z);
    m.castShadow = true;
    group.add(m);
    return m;
  };

  // legs
  const legGeo = new THREE.BoxGeometry(0.17, 0.78, 0.2);
  const legL = mesh(legGeo, cloth, -0.12, 0.39, 0);
  const legR = mesh(legGeo, cloth, 0.12, 0.39, 0);
  // boots
  mesh(new THREE.BoxGeometry(0.18, 0.12, 0.28), armor, -0.12, 0.06, 0.03);
  mesh(new THREE.BoxGeometry(0.18, 0.12, 0.28), armor, 0.12, 0.06, 0.03);

  // torso group (pivots at hip for aim lean)
  const torso = new THREE.Group();
  torso.position.y = 0.78;
  group.add(torso);
  const tMesh = (geo: THREE.BufferGeometry, mat: THREE.Material, x: number, y: number, z: number): THREE.Mesh => {
    const m = new THREE.Mesh(geo, mat);
    m.position.set(x, y, z);
    m.castShadow = true;
    torso.add(m);
    return m;
  };
  tMesh(new THREE.BoxGeometry(0.46, 0.56, 0.28), armor, 0, 0.32, 0);          // chest
  tMesh(new THREE.BoxGeometry(0.4, 0.34, 0.1), cloth, 0, 0.3, 0.16);          // plate carrier
  tMesh(new THREE.BoxGeometry(0.16, 0.1, 0.3), teamMat, -0.28, 0.52, 0);      // shoulder L
  tMesh(new THREE.BoxGeometry(0.16, 0.1, 0.3), teamMat, 0.28, 0.52, 0);       // shoulder R
  tMesh(new THREE.BoxGeometry(0.3, 0.18, 0.24), armor, 0, -0.02, 0);          // belt/pelvis
  // head + helmet + visor
  tMesh(new THREE.SphereGeometry(0.14, 10, 8), cloth, 0, 0.72, 0);            // head
  const helm = tMesh(new THREE.SphereGeometry(0.17, 10, 8), armor, 0, 0.76, 0);
  helm.scale.y = 0.85;
  tMesh(new THREE.BoxGeometry(0.22, 0.07, 0.06), visorMat, 0, 0.73, 0.13);    // visor slit
  // arms holding rifle forward
  const armGeo = new THREE.BoxGeometry(0.11, 0.11, 0.4);
  const armL = tMesh(armGeo, cloth, -0.2, 0.34, 0.26);
  armL.rotation.y = 0.5;
  const armR = tMesh(armGeo, cloth, 0.2, 0.3, 0.2);
  armR.rotation.y = -0.35;
  // rifle
  tMesh(new THREE.BoxGeometry(0.055, 0.09, 0.5), gunMat, 0.05, 0.36, 0.38);
  tMesh(new THREE.BoxGeometry(0.05, 0.05, 0.2), new THREE.MeshStandardMaterial({ color: 0x8a1f24, roughness: 0.5 }), 0.05, 0.38, 0.48);
  const muzzle = new THREE.Object3D();
  muzzle.position.set(0.05, 0.38, 0.75);
  torso.add(muzzle);

  return { group, legL, legR, torso, muzzle };
}

// ---------------------------------------------------------------------------
// Bot AI
// ---------------------------------------------------------------------------

type BotState = "patrol" | "engage";

export class Bot implements Targetable, Shootable {
  name: string;
  team: TeamId;
  alive = true;
  hp = BOTS.HP;
  pos = new THREE.Vector3();
  yaw = 0;
  readonly height = 1.78;
  readonly headY = 1.56;
  readonly radius = 0.38;

  rig: SoldierRig;
  private state: BotState = "patrol";
  private target: Targetable | null = null;
  private waypoint = { x: 0, z: 0 };
  private reactTimer = 0;
  private burstLeft: number = 0;
  private burstTimer = 0;
  private gapTimer = 0;
  private strafeDir = 1;
  private strafeTimer = 0;
  private loseTimer = 0;
  private walkPhase = 0;
  private deathAnim = -1; // <0 alive, else countdown of fall animation
  private lastHitBy: Targetable | null = null;
  private idleTime = 0; // patrol time without contact — drives aggression bias

  constructor(name: string, team: TeamId, private hooks: BotHooks) {
    this.name = name;
    this.team = team;
    this.rig = createSoldier(team);
    this.pickWaypoint();
  }

  get object(): THREE.Group { return this.rig.group; }

  spawnAt(pos: THREE.Vector3, yaw: number): void {
    this.pos.copy(pos);
    this.yaw = yaw;
    this.alive = true;
    this.hp = BOTS.HP;
    this.state = "patrol";
    this.target = null;
    this.deathAnim = -1;
    this.burstLeft = 0;
    this.rig.group.visible = true;
    this.rig.group.rotation.set(0, yaw, 0);
    this.rig.group.position.copy(pos);
    this.pickWaypoint();
  }

  /** Take damage from any source; returns true if this killed the bot. */
  takeDamage(dmg: number, attacker: string, attackerTeam: TeamId, weapon: string, attackerRef?: Targetable, headshot = false): boolean {
    if (!this.alive) return false;
    this.hp -= dmg;
    if (attackerRef) {
      this.lastHitBy = attackerRef;
      // getting shot reveals the shooter: snap to engage even outside the vision cone
      this.target = attackerRef;
      this.state = "engage";
      this.reactTimer = Math.min(this.reactTimer, BOTS.REACTION_TIME * 0.5);
      this.loseTimer = 0;
    }
    if (this.hp <= 0) {
      this.alive = false;
      this.deathAnim = 0.5;
      this.hooks.onKill({ attacker, attackerTeam, victim: this.name, victimTeam: this.team, weapon, headshot });
      return true;
    }
    return false;
  }

  update(dt: number): void {
    // death fall animation
    if (!this.alive) {
      if (this.deathAnim > 0) {
        this.deathAnim -= dt;
        const k = 1 - Math.max(0, this.deathAnim) / 0.5;
        this.rig.group.rotation.z = k * (Math.PI / 2) * 0.94;
        this.rig.group.position.y = this.pos.y + Math.sin(k * Math.PI) * 0.12 - k * 0.25;
      }
      return;
    }

    // acquire / validate target
    this.updateTarget();

    if (this.state === "engage" && this.target?.alive) {
      this.idleTime = 0;
      this.updateEngage(dt);
    } else {
      this.idleTime += dt;
      this.updatePatrol(dt);
      // push toward the enemy half after wandering too long — keeps rounds moving
      if (this.idleTime > 8) {
        this.idleTime = 0;
        const toward = this.team === 1 ? 1 : -1; // red pushes +z, blue pushes -z
        this.waypoint = { x: (Math.random() - 0.5) * 40, z: toward * (10 + Math.random() * 16) };
      }
    }

    // animate
    this.rig.group.position.copy(this.pos);
    this.rig.group.rotation.y = this.yaw;
    const swing = Math.sin(this.walkPhase) * 0.5;
    this.rig.legL.rotation.x = swing;
    this.rig.legR.rotation.x = -swing;
  }

  private updateTarget(): void {
    if (this.target && (!this.target.alive || this.target.pos.distanceTo(this.pos) > BOTS.SIGHT_RANGE * 1.6)) {
      this.target = null;
      this.state = "patrol";
    }
    if (this.target) return;

    // nearest visible enemy inside the vision cone
    let best: Targetable | null = null;
    let bestD: number = BOTS.SIGHT_RANGE;
    const fwdX = -Math.sin(this.yaw), fwdZ = -Math.cos(this.yaw);
    for (const c of this.hooks.getCombatants()) {
      if (c.team === this.team || !c.alive || c === (this as unknown as Targetable)) continue;
      const dx = c.pos.x - this.pos.x, dz = c.pos.z - this.pos.z;
      const d = Math.hypot(dx, dz);
      if (d > bestD || d < 0.01) continue;
      const dot = (dx / d) * fwdX + (dz / d) * fwdZ;
      const inCone = dot > BOTS.FOV_COS || d < 4; // close targets are noticed regardless of facing
      if (!inCone) continue;
      if (!this.canSee(c)) continue;
      best = c;
      bestD = d;
    }
    if (best) {
      this.target = best;
      this.state = "engage";
      this.reactTimer = BOTS.REACTION_TIME * (0.7 + Math.random() * 0.6);
      this.gapTimer = 0.2;
    }
  }

  private canSee(t: Targetable): boolean {
    return hasLineOfSight(
      this.hooks.colliders,
      this.pos.x, this.pos.y + this.headY, this.pos.z,
      t.pos.x, t.pos.y + t.headY * 0.8, t.pos.z,
    );
  }

  private updatePatrol(dt: number): void {
    const dx = this.waypoint.x - this.pos.x;
    const dz = this.waypoint.z - this.pos.z;
    const d = Math.hypot(dx, dz);
    if (d < 1.4) {
      this.pickWaypoint();
      return;
    }
    this.moveToward(dx / d, dz / d, BOTS.WALK_SPEED, dt);
  }

  private updateEngage(dt: number): void {
    const t = this.target!;
    const dx = t.pos.x - this.pos.x;
    const dz = t.pos.z - this.pos.z;
    const d = Math.hypot(dx, dz) || 0.01;

    // face the target
    const desiredYaw = Math.atan2(-dx, -dz);
    let dy = desiredYaw - this.yaw;
    while (dy > Math.PI) dy -= Math.PI * 2;
    while (dy < -Math.PI) dy += Math.PI * 2;
    this.yaw += THREE.MathUtils.clamp(dy, -5.2 * dt, 5.2 * dt);

    // strafe perpendicular; back off if too close, push in if far and no LOS
    this.strafeTimer -= dt;
    if (this.strafeTimer <= 0) {
      this.strafeTimer = 0.9 + Math.random() * 1.3;
      this.strafeDir = Math.random() < 0.5 ? -1 : 1;
    }
    const px = -dz / d, pz = dx / d; // perpendicular
    let mx = px * this.strafeDir, mz = pz * this.strafeDir;
    if (d < 6) { mx -= dx / d * 0.8; mz -= dz / d * 0.8; }
    else if (!this.canSee(t) && d > 10) { mx += dx / d; mz += dz / d; }
    const ml = Math.hypot(mx, mz) || 1;
    this.moveToward(mx / ml, mz / ml, BOTS.STRAFE_SPEED, dt);

    // LOS timeout → hunt last known position
    if (this.canSee(t)) {
      this.loseTimer = 0;
    } else {
      this.loseTimer += dt;
      if (this.loseTimer > 2.6) {
        this.target = this.lastHitBy?.alive ? this.lastHitBy : null;
        this.state = "patrol";
        if (this.target) return;
        this.waypoint = { x: t.pos.x, z: t.pos.z };
        return;
      }
    }

    // fire control: reaction → bursts with gaps
    if (this.reactTimer > 0) { this.reactTimer -= dt; return; }
    if (this.gapTimer > 0) {
      this.gapTimer -= dt;
      if (this.gapTimer <= 0) {
        this.burstLeft = BOTS.BURST_MIN + Math.floor(Math.random() * (BOTS.BURST_MAX - BOTS.BURST_MIN + 1));
      }
      return;
    }
    if (this.burstLeft > 0) {
      this.burstTimer -= dt;
      if (this.burstTimer <= 0) {
        this.burstTimer = BOTS.FIRE_INTERVAL;
        this.burstLeft--;
        if (this.burstLeft <= 0) this.gapTimer = BOTS.BURST_GAP * (0.8 + Math.random() * 0.5);
        this.shoot(t, d);
      }
    }
  }

  private shoot(t: Targetable, dist: number): void {
    const origin = _v1.set(this.pos.x, this.pos.y + this.headY * 0.92, this.pos.z);
    this.rig.muzzle.getWorldPosition(_v2);
    const aimY = t.pos.y + t.height * (0.5 + Math.random() * 0.25);
    const dir = _v3.set(
      t.pos.x - origin.x + (Math.random() - 0.5) * 2 * BOTS.SPREAD * dist,
      aimY - origin.y + (Math.random() - 0.5) * 2 * BOTS.SPREAD * dist * 0.6,
      t.pos.z - origin.z + (Math.random() - 0.5) * 2 * BOTS.SPREAD * dist,
    ).normalize();

    // what does the bullet hit first — wall or target?
    const wallT = raycastColliders(this.hooks.colliders, origin.x, origin.y, origin.z, dir.x, dir.y, dir.z, BOTS.SIGHT_RANGE + 10);
    let bestT = wallT;
    let hit: Targetable | null = null;
    // check the intended target's capsule
    const ht = raySphere(origin, dir, t.pos.x, t.pos.y + t.headY, t.pos.z, 0.22, bestT);
    if (ht > 0 && ht < bestT) { bestT = ht; hit = t; }
    const ct = rayCylinder(origin, dir, t.pos.x, t.pos.z, t.radius, t.height, bestT);
    if (ct > 0 && ct < bestT) { bestT = ct; hit = t; }

    const end = _v4.copy(origin).addScaledVector(dir, bestT);
    this.hooks.effects.tracer(_v2, end, this.team === 0 ? COLORS.blue : 0xff7050);
    const pd = this.hooks.distanceToPlayer(this.pos);
    this.hooks.audio.sfx("enemyShot", pd);
    if (pd < 30) this.hooks.effects.muzzleFlash(_v2, 10);

    if (hit) {
      const dmg = BOTS.DAMAGE * (dist > 18 ? Math.max(0.5, 1 - (dist - 18) / 45) : 1);
      if (hit === this.hooks.getPlayer()) {
        this.hooks.onPlayerHit(dmg, this.name);
        this.hooks.effects.impact(end, true);
      } else {
        const bot = hit as Bot;
        const died = bot.takeDamage(dmg, this.name, this.team, "AR-77 VANDAL", this as unknown as Targetable);
        this.hooks.effects.impact(end, true);
        if (died) void bot; // kill event already routed by takeDamage
      }
    } else if (bestT < BOTS.SIGHT_RANGE + 10) {
      this.hooks.effects.impact(end, false);
    }
  }

  private moveToward(nx: number, nz: number, speed: number, dt: number): void {
    this.pos.x += nx * speed * dt;
    this.pos.z += nz * speed * dt;
    resolveCollision(this.hooks.colliders, this.pos, this.radius);
    // separation from other bots
    for (const c of this.hooks.getCombatants()) {
      if (c === (this as unknown as Targetable) || !(c as unknown as Bot).rig) continue;
      const dx = this.pos.x - c.pos.x, dz = this.pos.z - c.pos.z;
      const d2 = dx * dx + dz * dz;
      const min = 0.9;
      if (d2 < min * min && d2 > 1e-6) {
        const d = Math.sqrt(d2);
        this.pos.x += (dx / d) * (min - d) * 0.5;
        this.pos.z += (dz / d) * (min - d) * 0.5;
      }
    }
    if (this.state === "patrol") {
      // face travel direction
      const desiredYaw = Math.atan2(-nx, -nz);
      let dy = desiredYaw - this.yaw;
      while (dy > Math.PI) dy -= Math.PI * 2;
      while (dy < -Math.PI) dy += Math.PI * 2;
      this.yaw += THREE.MathUtils.clamp(dy, -4 * dt, 4 * dt);
    }
    this.walkPhase += dt * speed * 2.4;
  }

  private pickWaypoint(): void {
    const wp = this.hooks.waypoints[Math.floor(Math.random() * this.hooks.waypoints.length)];
    this.waypoint = { x: wp.x + (Math.random() - 0.5) * 3, z: wp.z + (Math.random() - 0.5) * 3 };
  }
}

const _v1 = new THREE.Vector3();
const _v2 = new THREE.Vector3();
const _v3 = new THREE.Vector3();
const _v4 = new THREE.Vector3();
