/**
 * enemy.ts — inimigos e chefe: IA de patrulha/perseguição fiel ao protótipo
 * (perseguir se o herói estiver a menos de 260px; velocidade 65, chefe 95).
 */
import Phaser from "phaser";
import { ENEMY, COMBAT, COLORS } from "./config";

export class Enemy {
  readonly container: Phaser.GameObjects.Container;
  readonly body: Phaser.Physics.Arcade.Body;
  readonly isBoss: boolean;
  hp: number;
  direction: 1 | -1 = -1;
  private patrolTime = 0;
  private flashTime = 0;
  private bob = Math.random() * Math.PI * 2;
  private eye: Phaser.GameObjects.Ellipse;
  private flash: Phaser.GameObjects.Ellipse;
  private parts: Phaser.GameObjects.GameObject[];
  private touchCd = 0;

  constructor(private scene: Phaser.Scene, x: number, y: number, isBoss: boolean) {
    this.isBoss = isBoss;
    this.hp = isBoss ? ENEMY.BOSS_HP : ENEMY.HP;

    const r = isBoss ? 30 : 18;
    const bodyH = isBoss ? 85 : 54;
    const C = COLORS;
    const bodyColor = isBoss ? C.bossBody : C.enemyBody;

    this.container = scene.add.container(x, y);
    const torso = scene.add.ellipse(0, -bodyH / 2 + 4, r * 2, bodyH - 8, bodyColor);
    const head = scene.add.ellipse(0, -bodyH + (isBoss ? 14 : 10), isBoss ? 36 : 24, isBoss ? 30 : 22, C.enemyDark);
    this.eye = scene.add.ellipse(5, -bodyH + (isBoss ? 12 : 8), isBoss ? 9 : 6, isBoss ? 7 : 5, C.enemyEye);
    this.flash = scene.add.ellipse(0, -bodyH / 2, r * 2 + 6, bodyH, 0xffffff, 0);
    this.parts = [torso, head, this.eye, this.flash];

    if (isBoss) {
      const hornL = scene.add.triangle(-16, -82, 0, 14, 8, 14, -6, -8, C.bossHorn);
      const hornR = scene.add.triangle(16, -82, 0, 14, -8, 14, 6, -8, C.bossHorn);
      const crown = scene.add.ellipse(0, -84, 40, 10, 0x2a1544);
      this.parts.push(hornL, hornR, crown);
    } else {
      // ombreiras espinhosas
      const spikeL = scene.add.triangle(-14, -40, 0, 8, 8, 8, -4, -6, C.enemyBody);
      const spikeR = scene.add.triangle(14, -40, 0, 8, -8, 8, 4, -6, C.enemyBody);
      this.parts.push(spikeL, spikeR);
    }

    this.container.add(this.parts);
    this.container.setDepth(9);

    scene.physics.add.existing(this.container);
    this.body = this.container.body as Phaser.Physics.Arcade.Body;
    this.body.setSize(r * 2, bodyH);
    this.body.setOffset(-r, -bodyH);
  }

  get x(): number {
    return this.container.x;
  }
  get y(): number {
    return this.container.y;
  }

  takeHit(damage: number): boolean {
    this.hp -= damage;
    this.flashTime = ENEMY.HIT_FLASH;
    return this.hp <= 0;
  }

  /** Perseguição/contato. Retorna true se acabou de causar dano ao herói. */
  update(dt: number, hero: { x: number; y: number }, damageHero: () => boolean): boolean {
    this.patrolTime += dt;
    this.touchCd = Math.max(0, this.touchCd - dt);
    this.flashTime = Math.max(0, this.flashTime - dt);

    const dx = hero.x - this.x;
    if (Math.abs(dx) < ENEMY.CHASE_DISTANCE) {
      this.direction = dx > 0 ? 1 : -1;
    } else if (Math.floor(this.patrolTime * 1.4) % 3 === 0) {
      this.direction = 1;
    }
    this.body.setVelocityX(this.direction * (this.isBoss ? ENEMY.BOSS_SPEED : ENEMY.SPEED));

    // contato corpo a corpo
    let hit = false;
    if (
      this.touchCd <= 0 &&
      Math.abs(dx) < COMBAT.CONTACT_RANGE_X + (this.isBoss ? 18 : 0) &&
      Math.abs(hero.y - this.y) < COMBAT.CONTACT_RANGE_Y
    ) {
      if (damageHero()) {
        hit = true;
        this.touchCd = 0.6;
      }
    }

    // animação
    this.bob += dt * (Math.abs(this.body.velocity.x) > 1 ? 9 : 3);
    const squash = 1 + Math.sin(this.bob) * 0.04;
    this.container.setScale(this.direction >= 0 ? squash : -squash, 1 / squash);
    this.flash.setAlpha(this.flashTime > 0 ? 0.75 : 0);
    const chase = Math.abs(dx) < ENEMY.CHASE_DISTANCE;
    this.eye.setScale(chase ? 1.35 : 1);
    return hit;
  }

  destroy(): void {
    this.container.destroy();
  }
}
