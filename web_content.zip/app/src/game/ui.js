import { UPGRADES, fmtMoney } from './state.js';

export class UI {
  constructor(state, onBuy, onReset) {
    this.state = state;
    this.onBuy = onBuy;
    this.onReset = onReset;
    this.el = {
      money: document.getElementById('money'),
      moneyPill: document.getElementById('money-pill'),
      taskText: document.getElementById('task-text'),
      taskFill: document.getElementById('task-bar-fill'),
      taskProgress: document.getElementById('task-progress'),
      shopBtn: document.getElementById('shop-btn'),
      shopModal: document.getElementById('shop-modal'),
      shopList: document.getElementById('shop-list'),
      shopMoney: document.getElementById('shop-money-val'),
      shopClose: document.getElementById('shop-close'),
      toasts: document.getElementById('toasts'),
      startOverlay: document.getElementById('start-overlay'),
      startBtn: document.getElementById('start-btn'),
      resetSave: document.getElementById('reset-save'),
    };
    this._lastMoney = -1;
    this._lastTaskKey = '';
    this._shopOpen = false;

    this.el.shopBtn.addEventListener('click', () => this.openShop());
    this.el.shopClose.addEventListener('click', () => this.closeShop());
    this.el.shopModal.addEventListener('click', e => { if (e.target === this.el.shopModal) this.closeShop(); });
    this.el.resetSave.addEventListener('click', () => {
      if (confirm('Точно сбросить весь прогресс?')) { this.onReset(); this.closeShop(); }
    });
  }

  get shopOpen() { return this._shopOpen; }

  updateMoney() {
    const m = Math.floor(this.state.money);
    if (m === this._lastMoney) return;
    const grew = m > this._lastMoney && this._lastMoney >= 0;
    this._lastMoney = m;
    this.el.money.textContent = fmtMoney(m);
    this.el.shopMoney.textContent = fmtMoney(m);
    if (grew) {
      this.el.moneyPill.classList.remove('bump');
      void this.el.moneyPill.offsetWidth;
      this.el.moneyPill.classList.add('bump');
    }
    if (this._shopOpen) this.renderShop();
  }

  updateTask() {
    const t = this.state.currentTask;
    const key = t ? `${t.id}:${this.state.statValue(t.stat)}` : 'done';
    if (key === this._lastTaskKey) return;
    this._lastTaskKey = key;
    if (!t) {
      this.el.taskText.textContent = 'Бизнес процветает! Вы — легенда мойки 🏆';
      this.el.taskFill.style.width = '100%';
      this.el.taskProgress.textContent = 'все задания выполнены';
      return;
    }
    const val = Math.min(this.state.statValue(t.stat), t.goal);
    this.el.taskText.textContent = t.text;
    this.el.taskFill.style.width = `${(val / t.goal) * 100}%`;
    this.el.taskProgress.textContent = `${fmtMoney(val)} / ${fmtMoney(t.goal)} · награда ${fmtMoney(t.reward)} сом`;
  }

  toast(text, gold = false) {
    const el = document.createElement('div');
    el.className = 'toast' + (gold ? ' gold' : '');
    el.textContent = text;
    this.el.toasts.appendChild(el);
    setTimeout(() => el.remove(), 3300);
  }

  openShop() {
    this._shopOpen = true;
    this.el.shopModal.hidden = false;
    this.renderShop();
  }

  closeShop() {
    this._shopOpen = false;
    this.el.shopModal.hidden = true;
  }

  renderShop() {
    this.el.shopMoney.textContent = fmtMoney(this.state.money);
    this.el.shopList.innerHTML = '';
    for (const u of UPGRADES) {
      const lvl = this.state.levels[u.id];
      const check = this.state.canBuy(u.id);
      const maxed = lvl >= u.costs.length;
      const item = document.createElement('div');
      item.className = 'shop-item';
      const lvlTag = u.costs.length > 1 ? ` <small style="color:#8fd0ff">ур. ${lvl}/${u.costs.length}</small>` : '';
      item.innerHTML = `
        <div class="shop-ico">${u.icon}</div>
        <div class="shop-info">
          <div class="shop-name">${u.name}${lvlTag}</div>
          <div class="shop-desc">${check.locked || u.desc(lvl)}</div>
        </div>`;
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'shop-buy' + (maxed ? ' maxed' : '');
      if (maxed) {
        btn.textContent = 'МАКС';
        btn.disabled = true;
      } else {
        btn.textContent = `${fmtMoney(u.costs[lvl])} сом`;
        btn.disabled = !check.ok;
        btn.addEventListener('click', () => this.onBuy(u.id));
      }
      item.appendChild(btn);
      this.el.shopList.appendChild(item);
    }
  }

  showStart(hasSave, onStart) {
    this.el.startBtn.textContent = hasSave ? 'Продолжить' : 'Играть';
    this.el.startBtn.addEventListener('click', () => {
      this.el.startOverlay.classList.add('hidden');
      onStart();
    }, { once: true });
  }
}
