/**
 * art.ts — geração procedural de texturas (sem arquivos de imagem).
 * Tudo desenhado em canvas offscreen e registrado como textura do Phaser.
 */
import Phaser from "phaser";
import { VIEW, WORLD } from "./config";
import type { LevelTheme } from "./config";
import type { LevelData } from "./levels";

/** Ponto brilhante suave usado por todas as emissores de partículas. */
export function makeGlowTexture(scene: Phaser.Scene, key: string, color: number, size = 32): void {
  if (scene.textures.exists(key)) return;
  const c = document.createElement("canvas");
  c.width = c.height = size;
  const g = c.getContext("2d")!;
  const rgb = Phaser.Display.Color.IntegerToColor(color);
  const grad = g.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2);
  grad.addColorStop(0, `rgba(255,255,255,1)`);
  grad.addColorStop(0.25, `rgba(${rgb.red},${rgb.green},${rgb.blue},0.9)`);
  grad.addColorStop(1, `rgba(${rgb.red},${rgb.green},${rgb.blue},0)`);
  g.fillStyle = grad;
  g.fillRect(0, 0, size, size);
  scene.textures.addCanvas(key, c);
}

/** Gradiente vertical de céu para a fase. */
export function makeSkyTexture(scene: Phaser.Scene, key: string, theme: LevelTheme): void {
  if (scene.textures.exists(key)) return;
  const c = document.createElement("canvas");
  c.width = VIEW.WIDTH;
  c.height = VIEW.HEIGHT;
  const g = c.getContext("2d")!;
  const top = Phaser.Display.Color.IntegerToColor(theme.skyTop);
  const bottom = Phaser.Display.Color.IntegerToColor(theme.skyBottom);
  const grad = g.createLinearGradient(0, 0, 0, VIEW.HEIGHT);
  grad.addColorStop(0, top.rgba);
  grad.addColorStop(1, bottom.rgba);
  g.fillStyle = grad;
  g.fillRect(0, 0, c.width, c.height);
  // brilho difuso perto do horizonte
  const glow = g.createRadialGradient(VIEW.WIDTH * 0.5, WORLD.GROUND_Y + 60, 10, VIEW.WIDTH * 0.5, WORLD.GROUND_Y + 60, VIEW.WIDTH * 0.7);
  const acc = Phaser.Display.Color.IntegerToColor(theme.accent);
  glow.addColorStop(0, `rgba(${acc.red},${acc.green},${acc.blue},0.22)`);
  glow.addColorStop(1, "rgba(0,0,0,0)");
  g.fillStyle = glow;
  g.fillRect(0, 0, c.width, c.height);
  scene.textures.addCanvas(key, c);
}

/** Camada de montanhas: faixa repetida de triângulos. */
export function makeMountainTexture(scene: Phaser.Scene, key: string, color: number, seed: number): void {
  if (scene.textures.exists(key)) return;
  const w = 4 * 230;
  const h = WORLD.GROUND_Y;
  const c = document.createElement("canvas");
  c.width = w;
  c.height = h;
  const g = c.getContext("2d")!;
  g.fillStyle = Phaser.Display.Color.IntegerToColor(color).rgba;
  for (let i = 0; i < 4; i++) {
    const x = i * 230;
    const peak = 150 + ((i + seed) % 3) * 45;
    g.beginPath();
    g.moveTo(x, h);
    g.lineTo(x + 105, peak);
    g.lineTo(x + 230, h);
    g.closePath();
    g.fill();
  }
  scene.textures.addCanvas(key, c);
}

/** Textura do piso: faixa com topo de grama/cristal por tema. */
export function makeFloorTexture(scene: Phaser.Scene, key: string, theme: LevelTheme): void {
  if (scene.textures.exists(key)) return;
  const w = 256;
  const h = 96;
  const c = document.createElement("canvas");
  c.width = w;
  c.height = h;
  const g = c.getContext("2d")!;
  const base = Phaser.Display.Color.IntegerToColor(theme.floor);
  g.fillStyle = base.rgba;
  g.fillRect(0, 0, w, h);
  // topo mais claro
  const top = base.clone().brighten(18);
  g.fillStyle = top.rgba;
  g.fillRect(0, 0, w, 8);
  // veios/grama
  const acc = Phaser.Display.Color.IntegerToColor(theme.accent);
  g.fillStyle = `rgba(${acc.red},${acc.green},${acc.blue},0.35)`;
  for (let i = 0; i < 8; i++) {
    const x = (i * 37 + 13) % w;
    g.fillRect(x, 0, 3, 5 + (i % 3) * 4);
  }
  // sombreamento inferior
  const dark = base.clone().darken(25);
  g.fillStyle = dark.rgba;
  g.fillRect(0, h - 22, w, 22);
  scene.textures.addCanvas(key, c);
}

/** Textura das plataformas suspensas. */
export function makePlatformTexture(scene: Phaser.Scene, key: string, theme: LevelTheme): void {
  if (scene.textures.exists(key)) return;
  const w = WORLD.PLATFORM_W;
  const h = WORLD.PLATFORM_H;
  const c = document.createElement("canvas");
  c.width = w;
  c.height = h;
  const g = c.getContext("2d")!;
  const base = Phaser.Display.Color.IntegerToColor(theme.platform);
  g.fillStyle = base.rgba;
  g.beginPath();
  g.roundRect(0, 0, w, h, 6);
  g.fill();
  const top = base.clone().brighten(22);
  g.fillStyle = top.rgba;
  g.beginPath();
  g.roundRect(0, 0, w, 7, 4);
  g.fill();
  scene.textures.addCanvas(key, c);
}

/** Estrelas cintilantes para o fundo. */
export function makeStarsTexture(scene: Phaser.Scene, key: string): void {
  if (scene.textures.exists(key)) return;
  const c = document.createElement("canvas");
  c.width = VIEW.WIDTH;
  c.height = 320;
  const g = c.getContext("2d")!;
  for (let i = 0; i < 90; i++) {
    const x = (i * 137.5) % VIEW.WIDTH;
    const y = (i * 89.3) % 300;
    const r = 0.6 + (i % 3) * 0.5;
    g.fillStyle = `rgba(255,255,255,${0.25 + (i % 4) * 0.16})`;
    g.beginPath();
    g.arc(x, y, r, 0, Math.PI * 2);
    g.fill();
  }
  scene.textures.addCanvas(key, c);
}

/** Névoa suave na base do cenário. */
export function makeFogTexture(scene: Phaser.Scene, key: string, theme: LevelTheme): void {
  if (scene.textures.exists(key)) return;
  const c = document.createElement("canvas");
  c.width = 256;
  c.height = 64;
  const g = c.getContext("2d")!;
  const f = Phaser.Display.Color.IntegerToColor(theme.fog);
  const grad = g.createLinearGradient(0, 0, 0, 64);
  grad.addColorStop(0, `rgba(${f.red},${f.green},${f.blue},0)`);
  grad.addColorStop(1, `rgba(${f.red},${f.green},${f.blue},0.5)`);
  g.fillStyle = grad;
  g.fillRect(0, 0, 256, 64);
  scene.textures.addCanvas(key, c);
}

/** Gera todas as texturas de uma fase (chamado uma vez por GameScene.create). */
export function buildLevelTextures(scene: Phaser.Scene, level: LevelData, index: number): void {
  makeGlowTexture(scene, "glow-white", 0xffffff);
  makeGlowTexture(scene, "glow-cyan", 0x66e0ff);
  makeGlowTexture(scene, "glow-violet", 0xb07dff);
  makeGlowTexture(scene, "glow-red", 0xff5040);
  makeSkyTexture(scene, `sky-${index}`, level.theme);
  makeMountainTexture(scene, `mtn-far-${index}`, level.theme.mountainFar, 1);
  makeMountainTexture(scene, `mtn-near-${index}`, level.theme.mountain, 2);
  makeFloorTexture(scene, `floor-${index}`, level.theme);
  makePlatformTexture(scene, `plat-${index}`, level.theme);
  makeStarsTexture(scene, "stars");
  makeFogTexture(scene, `fog-${index}`, level.theme);
}
