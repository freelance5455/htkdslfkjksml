/**
 * player.ts — Aren: third-person controller, camera rig, combat actions, abilities.
 */
import * as THREE from "three";
import { World } from "./world";
import { Input } from "./input";
import { AudioSystem } from "./audio";
import { Particles, DamageNumbers, ScreenShake, Hitbox } from "./combat";
import { buildHumanoid, buildWeaponMesh, animateHumanoid, makeAnimState, HumanoidParts, AnimState } from "./characters";
import { PLAYER, COMBAT } from "./config";
import { clamp, lerp } from "./noise";
import { WEAPONS, WeaponKind, weaponDmg, SKILLS } from "./data";

export interface PlayerStats {
  hp: number; maxHp: number;
  stamina: number; maxStamina: number;
  mana: number; maxMana: number;
  level: number; xp: number; skillPoints: number;
  gold: number;
}

export class Player {
  pos = new THREE.Vector3(0, 1.2, 12);
  vel = new THREE.Vector3();
  yaw = Math.PI;           // facing -z (into the world)
  onGround = true;
  swimming = false;

  parts: HumanoidParts;
  anim: AnimState = makeAnimState();

  // camera
  camYaw = Math.PI;
  camPitch = 0.32;
  camDist = 5.2;
  lockTarget: { pos: THREE.Vector3; alive: boolean } | null = null;

  stats: PlayerStats = { hp: 100, maxHp: 100, stamina: 100, maxStamina: 100, mana: 60, maxMana: 60, level: 1, xp: 0, skillPoints: 0, gold: 0 };

  currentWeapon: WeaponKind = "dawnblade";
  weaponTiers: Record<string, number> = { dawnblade: 1 };
  ownedWeapons: WeaponKind[] = ["dawnblade"];
  skills: Record<string, number> = {}; // id -> level

  inventory: Record<string, number> = { crystal: 0, darkcrystal: 0, ore: 0, herb: 2, fang: 0, essence: 0, relic: 0, potion: 1 };
  equipment: Partial<Record<string, string>> = { armor: "wornArmor" };

  // combat state
  attackTimer = -1;      // time left in current swing
  attackDur = 0.45;
  comboStep = 0;
  comboWindow = 0;
  heavyAttack = false;
  dodging = 0;           // time left
  dodgeCd = 0;
  blocking = false;
  parryWindow = 0;
  iframes = 0;
  shieldT = 0;           // light shield remaining
  cloakT = 0;            // invisibility remaining
  cloneT = 0;
  hitStop = 0;
  attackHits = new Set<unknown>();
  activeHit: Hitbox | null = null;
  specialT = 0;
  casting: string | null = null;
  castT = 0;
  hurtFlash = 0;
  stepTimer = 0;
  eyeGlow = 0;           // grows when using magic
  dead = false;

  private weaponMesh: THREE.Group | null = null;
  private vel2 = new THREE.Vector3();

  constructor(
    private world: World,
    private input: Input,
    private audio: AudioSystem,
    private particles: Particles,
    public dmgNum: DamageNumbers,
    public shake: ScreenShake,
  ) {
    this.parts = buildHumanoid({
      armorColor: 0x23242e, clothColor: 0x1a1626, skinColor: 0xc9a184,
      eyeColor: 0x6ac8ff, scale: 1, cape: true, glowIntensity: 0,
    });
    this.equipWeapon("dawnblade");
  }

  get weapon() { return WEAPONS[this.currentWeapon]; }
  get weaponTier() { return this.weaponTiers[this.currentWeapon] ?? 1; }
  get atkDmg() {
    let m = 1 + (this.skills["power"] ?? 0) * 0.08;
    m *= 1 + (this.weaponTier - 1) * 0.35;
    if (this.comboStep >= 2) m *= 1 + (this.skills["combo"] ?? 0) * 0.12;
    return this.weapon.baseDmg * m;
  }
  get dmgMult(): number {
    let m = 1;
    for (const id of Object.values(this.equipment)) {
      // equipment bonuses resolved by game via data
    }
    return m;
  }
  skillLevel(id: string): number { return this.skills[id] ?? 0; }

  equipWeapon(kind: WeaponKind): void {
    this.currentWeapon = kind;
    if (this.weaponMesh) this.parts.weaponMount.remove(this.weaponMesh);
    this.weaponMesh = buildWeaponMesh(kind === "dawnblade" ? "sword" : kind, this.weaponTier, WEAPONS[kind].hue);
    this.weaponMesh.rotation.x = Math.PI / 2.4;
    this.weaponMesh.position.y = -0.1;
    this.parts.weaponMount.add(this.weaponMesh);
  }

  refreshWeaponVisual(): void {
    this.equipWeapon(this.currentWeapon);
  }

  takeDamage(amount: number, fromX: number, fromZ: number, unblockable = false): "parry" | boolean {
    if (this.dead || this.iframes > 0 || this.dodging > 0) return false;
    // blocking?
    if (this.blocking && !unblockable) {
      const dx = fromX - this.pos.x, dz = fromZ - this.pos.z;
      const facing = Math.atan2(dx, dz);
      let diff = Math.abs(facing - this.yaw) % (Math.PI * 2);
      if (diff > Math.PI) diff = Math.PI * 2 - diff;
      if (diff < 1.5) {
        if (this.parryWindow > 0) {
          this.audio.sfx("parry");
          this.particles.burst(this.pos.x, this.pos.y + 1.3, this.pos.z, 26, 0x9fd0ff, 7, 0.5);
          this.shake.add(0.25);
          this.stats.stamina = Math.min(this.stats.maxStamina, this.stats.stamina + 10);
          return "parry";
        }
        const cost = PLAYER.STAMINA_BLOCK_HIT * (1 - (this.skills["agility"] ?? 0) * 0.12);
        if (this.stats.stamina >= cost) {
          this.stats.stamina -= cost;
          this.audio.sfx("block");
          this.particles.burst(this.pos.x + Math.sin(this.yaw), this.pos.y + 1.2, this.pos.z + Math.cos(this.yaw), 12, 0x8a94b8, 4, 0.3);
          this.shake.add(0.12);
          this.vel2.set(this.pos.x - fromX, 0, this.pos.z - fromZ).normalize().multiplyScalar(3);
          this.vel.x += this.vel2.x; this.vel.z += this.vel2.z;
          return false;
        }
      }
    }
    if (this.shieldT > 0) {
      this.shieldT -= amount / 2;
      this.audio.sfx("block");
      this.particles.burst(this.pos.x, this.pos.y + 1.2, this.pos.z, 14, 0x9fd0ff, 5, 0.4);
      return false;
    }
    const def = this.equipmentDefMult();
    const final = Math.round(amount / def);
    this.stats.hp -= final;
    this.hurtFlash = 0.4;
    this.anim.hitT = 0.3;
    this.audio.sfx("playerHurt");
    this.particles.burst(this.pos.x, this.pos.y + 1.2, this.pos.z, 16, 0xc03040, 5, 0.5);
    this.shake.add(0.35);
    this.dmgNum.show(this.pos.x, this.pos.y + 2.1, this.pos.z, String(final), "#ff5a5a");
    this.vel2.set(this.pos.x - fromX, 0, this.pos.z - fromZ).normalize().multiplyScalar(5);
    this.vel.x += this.vel2.x; this.vel.z += this.vel2.z;
    if (this.stats.hp <= 0) {
      this.stats.hp = 0;
      this.dead = true;
      this.anim.dead = true;
      this.audio.sfx("death");
    }
    return true;
  }

  equipmentDefMult(): number {
    // resolved via data lookup in game.ts to avoid circular import
    return (this as unknown as { _defMult?: number })._defMult ?? 1;
  }

  heal(v: number): void {
    this.stats.hp = Math.min(this.stats.maxHp, this.stats.hp + v);
  }

  update(dt: number, enemies: { pos: THREE.Vector3; alive: boolean; radius: number }[], camera: THREE.PerspectiveCamera): void {
    if (this.dead) {
      animateHumanoid(this.parts, this.anim, dt);
      this.updateMesh();
      return;
    }
    const inp = this.input;
    const st = this.stats;

    // ---- timers ----
    if (this.iframes > 0) this.iframes -= dt;
    if (this.parryWindow > 0) this.parryWindow -= dt;
    if (this.dodgeCd > 0) this.dodgeCd -= dt;
    if (this.comboWindow > 0) { this.comboWindow -= dt; if (this.comboWindow <= 0) this.comboStep = 0; }
    if (this.shieldT > 0) this.shieldT -= dt;
    if (this.cloakT > 0) this.cloakT -= dt;
    if (this.hurtFlash > 0) this.hurtFlash -= dt;
    if (this.specialT > 0) this.specialT -= dt;
    if (this.hitStop > 0) this.hitStop -= dt;
    this.eyeGlow = lerp(this.eyeGlow, this.casting ? 1 : 0, dt * 5);
    this.parts.glow.intensity = this.shieldT > 0 ? 4 : this.eyeGlow * 6;
    (this.parts.eyes[0].material as THREE.MeshBasicMaterial).color.setHSL(this.casting === null ? 0.55 : 0.75, 1, 0.55 + this.eyeGlow * 0.3);

    // regen
    const stamRegenMul = this.blocking || this.attackTimer >= 0 ? 0.25 : 1;
    st.stamina = Math.min(st.maxStamina, st.stamina + PLAYER.STAMINA_REGEN * stamRegenMul * (1 + (this.skills["endurance"] ?? 0) * 0.2) * dt);
    st.mana = Math.min(st.maxMana, st.mana + PLAYER.MANA_REGEN * dt);

    // ---- camera orbit ----
    const look = inp.consumeLook();
    this.camYaw += look.yaw;
    this.camPitch = clamp(this.camPitch + look.pitch, -0.5, 1.15);

    // lock-on
    if (inp.consumeAction("Tab") || inp.consumeAction("MouseMiddle")) {
      if (this.lockTarget) this.lockTarget = null;
      else {
        let best: { pos: THREE.Vector3; alive: boolean; radius: number } | null = null;
        let bd: number = COMBAT.LOCK_DIST;
        for (const e of enemies) {
          if (!e.alive) continue;
          const d = e.pos.distanceTo(this.pos);
          if (d < bd) { bd = d; best = e; }
        }
        this.lockTarget = best as never;
        if (best) this.audio.sfx("ui");
      }
    }
    if (this.lockTarget && (!this.lockTarget.alive || this.lockTarget.pos.distanceTo(this.pos) > COMBAT.LOCK_DIST * 1.6)) {
      this.lockTarget = null;
    }

    // ---- casting (abilities) ----
    if (this.castT > 0) {
      this.castT -= dt;
      this.anim.castT = 1 - this.castT / 0.5;
      if (this.castT <= 0) { this.anim.castT = -1; this.castT = 0; this.casting = null; }
    }

    // ---- movement input ----
    const mx = inp.moveX, mz = inp.moveZ;
    const moving = (mx !== 0 || mz !== 0);
    let speedMul = (this.skills["agility"] ? 1 : 1) * this.equipSpeedMult();
    let targetSpeed = 0;
    if (moving && this.attackTimer < 0 && this.castT <= 0) {
      targetSpeed = PLAYER.RUN * speedMul * clamp(Math.sqrt(mx * mx + mz * mz), 0, 1);
    }

    // direction relative to camera: forward=(sin,cos), right=(-cos,sin)
    const sin = Math.sin(this.camYaw), cos = Math.cos(this.camYaw);
    let dirX = 0, dirZ = 0;
    if (moving) {
      dirX = mz * sin - mx * cos;
      dirZ = mz * cos + mx * sin;
      const len = Math.hypot(dirX, dirZ) || 1;
      dirX /= len; dirZ /= len;
    }

    // ---- dodge ----
    if (this.dodging > 0) {
      this.dodging -= dt;
      this.anim.dodgeT = 1 - Math.max(0, this.dodging) / PLAYER.DODGE_TIME;
      if (this.dodging <= 0) { this.anim.dodgeT = 0; }
      const ds = PLAYER.DODGE_SPEED * (0.5 + this.dodging / PLAYER.DODGE_TIME);
      this.vel.x = this.dodgeDir.x * ds;
      this.vel.z = this.dodgeDir.z * ds;
    } else if (inp.consumeAction("ShiftLeft") || inp.consumeAction("ShiftRight")) {
      if (st.stamina >= PLAYER.STAMINA_ROLL * (1 - (this.skills["agility"] ?? 0) * 0.1) && this.dodgeCd <= 0 && this.attackTimer < 0) {
        st.stamina -= PLAYER.STAMINA_ROLL * (1 - (this.skills["agility"] ?? 0) * 0.1);
        this.dodging = PLAYER.DODGE_TIME;
        this.dodgeCd = 0.1;
        this.iframes = PLAYER.DODGE_IFRAMES + (this.skills["agility"] ?? 0) * 0.04;
        if (moving) this.dodgeDir.set(dirX, 0, dirZ);
        else this.dodgeDir.set(Math.sin(this.yaw), 0, Math.cos(this.yaw));
        this.audio.sfx("roll");
        this.particles.burst(this.pos.x, this.pos.y + 0.3, this.pos.z, 10, 0x3a3f55, 2.5, 0.35);
      }
    }
    if (this.anim.dodgeT > 0 && this.dodging <= 0) this.anim.dodgeT = 0;

    // ---- jump / gravity ----
    const groundY = this.world.height(this.pos.x, this.pos.z);
    const inWater = this.world.zoneAt(this.pos.x, this.pos.z) === "swamp" && groundY < this.world.waterLevel - 0.2;
    this.swimming = inWater && this.pos.y <= this.world.waterLevel + 0.4;
    if (this.onGround && inp.consumeAction("Space")) {
      this.vel.y = PLAYER.JUMP_V;
      this.onGround = false;
      this.audio.sfx("jump");
    }

    // ---- attacks ----
    if (this.attackTimer >= 0) {
      this.attackTimer -= dt;
      this.anim.attackT = 1 - Math.max(0, this.attackTimer) / this.attackDur;
      // active frames
      const activeStart = 0.32, activeEnd = 0.62;
      if (this.anim.attackT >= activeStart && this.anim.attackT <= activeEnd && !this.attackDone) {
        this.activeHit = {
          x: this.pos.x + Math.sin(this.yaw) * this.weapon.range * 0.7,
          y: this.pos.y + 1.2,
          z: this.pos.z + Math.cos(this.yaw) * this.weapon.range * 0.7,
          r: this.weapon.range * 0.62,
          dmg: this.atkDmg * (this.heavyAttack ? this.weapon.heavyMult : 1) * (1 + this.comboStep * 0.1),
          knockback: this.heavyAttack ? 8 : 3.5,
          team: "player",
          hitSet: this.attackHits,
        };
        if (this.anim.attackT >= activeEnd - 0.08) this.attackDone = true;
      } else if (this.anim.attackT > activeEnd) {
        this.attackDone = true;
        this.activeHit = null;
      }
      if (this.attackTimer <= 0) {
        this.attackTimer = -1;
        this.anim.attackT = -1;
        this.activeHit = null;
        this.comboWindow = 0.9;
      }
    } else {
      this.activeHit = null;
      // light attack
      if (inp.consumeAction("MouseLeft")) {
        this.tryAttack(false);
      }
    }
    // heavy attack (works even mid combo)
    if (inp.consumeAction("KeyF")) this.tryAttack(true);

    // blocking
    this.blocking = this.attackTimer < 0 && this.castT <= 0 && this.isMouseRightHeld();
    if (this.blocking && this.parryWindow === 0 && this._rmbPressed) {
      this.parryWindow = 0.18; // parry on raise
    }
    this._rmbPressed = false;

    // ---- abilities ----
    if (inp.consumeAction("KeyQ")) this.tryCast("dash");
    if (inp.consumeAction("KeyX")) this.tryCast("burst");
    if (inp.consumeAction("KeyV")) this.tryCast("wave");
    if (inp.consumeAction("KeyB")) this.tryCast("heal");
    if (inp.consumeAction("KeyN")) this.tryCast("shield");
    if (inp.consumeAction("KeyG")) this.tryCast("clone");
    if (inp.consumeAction("KeyR")) this.drinkPotion();

    // ---- locomotion integration ----
    if (this.dodging <= 0) {
      const accel = moving ? PLAYER.ACCEL : PLAYER.FRICTION;
      const tx = dirX * targetSpeed, tz = dirZ * targetSpeed;
      this.vel.x = lerp(this.vel.x, tx, clamp(accel * dt / Math.max(targetSpeed, 4), 0, 1));
      this.vel.z = lerp(this.vel.z, tz, clamp(accel * dt / Math.max(targetSpeed, 4), 0, 1));
    }
    // face movement dir (or lock-on target / attack forward)
    let faceYaw = this.yaw;
    if (this.lockTarget && (this.attackTimer >= 0 || this.blocking)) {
      faceYaw = Math.atan2(this.lockTarget.pos.x - this.pos.x, this.lockTarget.pos.z - this.pos.z);
    } else if (this.attackTimer >= 0 && this.lockTarget) {
      faceYaw = Math.atan2(this.lockTarget.pos.x - this.pos.x, this.lockTarget.pos.z - this.pos.z);
    } else if (moving) {
      faceYaw = Math.atan2(dirX, dirZ);
    } else if (this.lockTarget && this.blocking) {
      faceYaw = Math.atan2(this.lockTarget.pos.x - this.pos.x, this.lockTarget.pos.z - this.pos.z);
    }
    if (this.lockTarget && (this.blocking || this.attackTimer >= 0)) {
      faceYaw = Math.atan2(this.lockTarget.pos.x - this.pos.x, this.lockTarget.pos.z - this.pos.z);
    }
    let dy = faceYaw - this.yaw;
    while (dy > Math.PI) dy -= Math.PI * 2;
    while (dy < -Math.PI) dy += Math.PI * 2;
    this.yaw += dy * clamp(dt * 12, 0, 1);

    // gravity & ground
    if (this.swimming) {
      this.vel.y = lerp(this.vel.y, 0, dt * 6);
      this.pos.y = lerp(this.pos.y, this.world.waterLevel - 0.4, dt * 4);
      this.onGround = false;
      this.anim.speed = moving ? 0.5 : 0.1;
    } else {
      this.vel.y -= PLAYER.GRAVITY * dt;
    }
    this.pos.x += this.vel.x * dt;
    this.pos.z += this.vel.z * dt;
    this.pos.y += this.vel.y * dt;

    // world bounds
    const B = 520;
    this.pos.x = clamp(this.pos.x, -B, B);
    this.pos.z = clamp(this.pos.z, -B, B);

    // prop collision
    const c = this.world.collide(this.pos.x, this.pos.z, PLAYER.RADIUS);
    this.pos.x = c.x; this.pos.z = c.z;

    const gY = this.world.height(this.pos.x, this.pos.z);
    if (this.pos.y <= gY) {
      this.pos.y = gY;
      this.vel.y = 0;
      this.onGround = true;
      this.anim.airborne = false;
    } else if (this.pos.y > gY + 0.15) {
      this.onGround = false;
      this.anim.airborne = true;
    }

    // footsteps
    const hSpeed = Math.hypot(this.vel.x, this.vel.z);
    this.anim.speed = clamp(hSpeed / PLAYER.RUN, 0, 1);
    if (this.onGround && hSpeed > 1) {
      this.stepTimer -= dt * hSpeed;
      if (this.stepTimer <= 0) {
        this.stepTimer = 2.4;
        this.audio.sfx("step");
      }
    }

    // ---- camera ----
    this.updateCamera(camera, dt);

    // ---- visuals ----
    animateHumanoid(this.parts, this.anim, dt, 1 + hSpeed * 0.12);
    this.updateMesh();
  }

  private dodgeDir = new THREE.Vector3(0, 0, 1);
  private attackDone = true;
  private _rmbPressed = false;
  mouseRightDown = false;

  private isMouseRightHeld(): boolean { return this.mouseRightDown; }
  notifyMouseRight(): void { this._rmbPressed = true; this.mouseRightDown = true; }
  notifyMouseRightUp(): void { this.mouseRightDown = false; }

  private equipSpeedMult(): number { return (this as unknown as { _speedMult?: number })._speedMult ?? 1; }

  private tryAttack(heavy: boolean): void {
    if (!this.hasWeapon) return;
    const st = this.stats;
    const cost = (heavy ? PLAYER.STAMINA_ATTACK * 1.6 : PLAYER.STAMINA_ATTACK) * (1 - (this.skills["agility"] ?? 0) * 0.08);
    if (this.attackTimer >= 0 || this.dodging > 0 || this.castT > 0) {
      // buffer: allow queueing next combo step
      if (this.attackTimer >= 0 && this.attackTimer < this.attackDur * 0.4) {
        this.comboBuffered = heavy;
      }
      return;
    }
    if (st.stamina < cost) { this.audio.sfx("ui"); return; }
    st.stamina -= cost;
    this.heavyAttack = heavy;
    this.attackHits.clear();
    this.bowFired = false;
    this.attackDone = false;
    const comboMax = 2 + (this.skills["combo"] ?? 0);
    this.comboStep = (this.comboStep + 1) % (comboMax + 1);
    if (this.comboStep === 0) this.comboStep = 1;
    const w = this.weapon;
    this.attackDur = (heavy ? 0.85 : 0.48) / w.speed;
    this.attackTimer = this.attackDur;
    this.anim.attackT = 0;
    this.anim.attackKind = heavy ? 1 : 0;
    if (!heavy && this.comboStep >= comboMax) this.anim.attackKind = 2; // finisher spin
    this.audio.sfx(heavy ? "swingHeavy" : "swing");
    if (heavy) this.shake.add(0.08);
  }
  private comboBuffered: boolean | null = null;
  private bufferedConsumed = false;
  hasWeapon = true;
  bowFired = false;

  disarm(): void {
    this.hasWeapon = false;
    if (this.weaponMesh) this.parts.weaponMount.remove(this.weaponMesh);
  }

  arm(kind: WeaponKind): void {
    this.hasWeapon = true;
    this.equipWeapon(kind);
  }

  consumeBufferedAttack(): boolean | null {
    const b = this.comboBuffered;
    this.comboBuffered = null;
    return b;
  }

  private drinkPotion(): void {
    if (this.inventory["potion"] > 0 && this.stats.hp < this.stats.maxHp) {
      this.inventory["potion"]--;
      this.heal(this.stats.maxHp * 0.5);
      this.audio.sfx("heal");
      this.particles.burst(this.pos.x, this.pos.y + 1, this.pos.z, 24, 0x5aff8a, 3, 0.8, 2);
    }
  }

  /** Cast a known ability by id. Returns true if cast succeeded. */
  tryCast(id: string): boolean {
    if (this.castT > 0 || this.dead) return false;
    const lvl = this.skillLevel(id);
    if (lvl <= 0) return false;
    const st = this.stats;
    const cast = (mana: number, sfxName: string): boolean => {
      if (st.mana < mana) { this.audio.sfx("ui"); return false; }
      st.mana -= mana;
      this.castT = 0.5;
      this.anim.castT = 0;
      this.casting = id;
      this.audio.sfx(sfxName);
      return true;
    };
    switch (id) {
      case "dash": {
        if (!cast(10, "shadowMagic")) return false;
        const dir = this.lockTarget
          ? new THREE.Vector3().subVectors(this.lockTarget.pos, this.pos).setY(0).normalize()
          : new THREE.Vector3(Math.sin(this.yaw), 0, Math.cos(this.yaw));
        const d = 7 + lvl * 2;
        this.pos.addScaledVector(dir, d);
        const g = this.world.height(this.pos.x, this.pos.z);
        this.pos.y = Math.max(this.pos.y, g);
        this.iframes = 0.3;
        this.particles.burst(this.pos.x, this.pos.y + 1, this.pos.z, 30, 0x8a40ff, 5, 0.6);
        return true;
      }
      case "burst":
        if (!cast(25, "shadowMagic")) return false;
        this.pendingAoE = { dmg: 30 + lvl * 15, r: 6, color: 0x8a40ff, team: "player" };
        return true;
      case "clone":
        if (!cast(30, "shadowMagic")) return false;
        this.pendingCloneLvl = lvl;
        return true;
      case "wave":
        if (!cast(12, "magic")) return false;
        this.pendingWave = { dmg: 20 + lvl * 10, speed: 22, range: 14, color: 0xffd76a };
        return true;
      case "heal": {
        if (st.hp >= st.maxHp * 0.995 || !cast(20, "heal")) return false;
        this.heal(20 + lvl * 15);
        this.particles.burst(this.pos.x, this.pos.y + 1.2, this.pos.z, 30, 0x5affc8, 3, 1, 1);
        return true;
      }
      case "shield":
        if (!cast(18, "magic")) return false;
        this.shieldT = 4 + lvl * 2;
        return true;
    }
    return false;
  }
  pendingCloneLvl = 0;

  pendingAoE: { dmg: number; r: number; color: number; team: "player" } | null = null;
  pendingWave: { dmg: number; speed: number; range: number; color: number } | null = null;
  pendingClone = false;

  private updateMesh(): void {
    this.parts.root.position.copy(this.pos);
    this.parts.root.rotation.y = this.yaw;
    // cloak transparency
    const cloakMat = (this.parts.cape as THREE.Mesh).material as THREE.MeshStandardMaterial;
    if (cloakMat) {
      cloakMat.transparent = true;
      cloakMat.opacity = this.cloakT > 0 ? 0.15 : 1;
    }
  }

  private updateCamera(camera: THREE.PerspectiveCamera, dt: number): void {
    // lock-on camera assist
    if (this.lockTarget) {
      const t = this.lockTarget.pos;
      const wantYaw = Math.atan2(this.pos.x - t.x, this.pos.z - t.z);
      let dy = wantYaw - this.camYaw;
      while (dy > Math.PI) dy -= Math.PI * 2;
      while (dy < -Math.PI) dy += Math.PI * 2;
      this.camYaw += dy * clamp(dt * 4, 0, 1);
      const d = this.pos.distanceTo(t);
      this.camPitch = lerp(this.camPitch, clamp(0.25 + d * 0.005, 0.2, 0.45), dt * 3);
    }
    const targetY = this.pos.y + 1.7;
    const cx = this.pos.x - Math.sin(this.camYaw) * Math.cos(this.camPitch) * this.camDist;
    const cz = this.pos.z - Math.cos(this.camYaw) * Math.cos(this.camPitch) * this.camDist;
    let cy = targetY + Math.sin(this.camPitch) * this.camDist;
    // keep camera above terrain
    const gY = this.world.height(cx, cz);
    if (cy < gY + 0.5) cy = gY + 0.5;
    camera.position.set(cx, cy, cz);
    const lx = this.pos.x + Math.sin(this.camYaw) * 2;
    const lz = this.pos.z + Math.cos(this.camYaw) * 2;
    camera.lookAt(lx, targetY + (this.lockTarget ? 0 : Math.sin(this.camPitch) * -1), lz);
    if (this.lockTarget) {
      camera.lookAt(
        (this.pos.x + this.lockTarget.pos.x) / 2,
        (targetY + this.lockTarget.pos.y + 1.2) / 2,
        (this.pos.z + this.lockTarget.pos.z) / 2,
      );
    }
  }

  respawn(x: number, z: number): void {
    this.pos.set(x, this.world.height(x, z) + 0.5, z);
    this.vel.set(0, 0, 0);
    this.dead = false;
    this.anim.dead = false;
    this.stats.hp = this.stats.maxHp;
    this.stats.stamina = this.stats.maxStamina;
    this.parts.body.rotation.x = 0;
    this.parts.body.position.y = 0;
  }
}
