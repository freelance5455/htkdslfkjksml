/**
 * player.ts — PlayerController.
 * First-person movement: joystick/WASD walk, crouch toggle with smooth camera-height transition,
 * touch-look / mouse-look with pitch clamp, circle-vs-AABB collision, footsteps and HP regen.
 */

import * as THREE from "three";
import { PLAYER, TeamId } from "./config";
import { resolveCollision, AABB } from "./arena";
import { GameInput } from "./input";
import { AudioSystem } from "./audio";
import type { DamageEvent } from "./types";

const PITCH_LIMIT = Math.PI / 2 - 0.06;

export class PlayerController {
  readonly team: TeamId = 0;
  readonly name = "YOU";
  pos = new THREE.Vector3(0, 0, 26);
  vel = new THREE.Vector3();
  yaw = 0; // forward() with yaw=0 is -Z — player spawns at +Z facing the courtyard center
  pitch = 0;
  crouched = false;
  alive = true;

  hp: number = PLAYER.HP;
  plates: number = PLAYER.MAX_PLATES;
  plateTimer = 0;         // >0 while applying a plate
  private regenTimer = 0;
  private stepTimer = 0;
  private heightCurrent: number = PLAYER.HEIGHT_STAND;

  constructor(private colliders: AABB[]) {}

  /** Camera forward on the ground plane. yaw=0 → -Z, turning right (yaw -) rotates toward -X...  */
  forward(out: THREE.Vector3): THREE.Vector3 {
    return out.set(-Math.sin(this.yaw), 0, -Math.cos(this.yaw));
  }
  right(out: THREE.Vector3): THREE.Vector3 {
    return out.set(Math.cos(this.yaw), 0, -Math.sin(this.yaw));
  }

  get eyeHeight(): number {
    return this.heightCurrent * PLAYER.EYE_RATIO;
  }

  get speedRatio(): number {
    // used by weapon spread + bob amplitude
    return Math.min(1, Math.hypot(this.vel.x, this.vel.z) / PLAYER.WALK_SPEED);
  }

  update(dt: number, input: GameInput, audio: AudioSystem, movingAllowed: boolean): void {
    if (!this.alive) return;

    // ---- look ----
    const look = input.consumeLook();
    this.yaw += look.yaw;
    this.pitch = THREE.MathUtils.clamp(this.pitch + look.pitch, -PITCH_LIMIT, PITCH_LIMIT);

    // ---- crouch toggle ----
    if (input.takeAction("crouch") || input.takeAction("KeyC") || input.takeAction("ShiftLeft") || input.takeAction("ShiftRight")) {
      this.crouched = !this.crouched;
      audio.sfx("ui");
    }

    // ---- movement ----
    const targetH = this.crouched ? PLAYER.HEIGHT_CROUCH : PLAYER.HEIGHT_STAND;
    this.heightCurrent = THREE.MathUtils.damp(this.heightCurrent, targetH, 12, dt);

    const axes = movingAllowed ? input.axes() : { x: 0, z: 0 };
    const fwd = this.forward(_tmpF);
    const rgt = this.right(_tmpR);
    let speed = this.crouched ? PLAYER.CROUCH_SPEED : PLAYER.WALK_SPEED;
    if (input.aimHeld) speed *= PLAYER.ADS_SPEED_MULT;
    const wishX = (rgt.x * axes.x + fwd.x * axes.z) * speed;
    const wishZ = (rgt.z * axes.x + fwd.z * axes.z) * speed;

    // acceleration + friction
    this.vel.x = THREE.MathUtils.damp(this.vel.x, wishX, axes.x || axes.z ? PLAYER.ACCEL / speed : PLAYER.FRICTION, dt);
    this.vel.z = THREE.MathUtils.damp(this.vel.z, wishZ, axes.x || axes.z ? PLAYER.ACCEL / speed : PLAYER.FRICTION, dt);

    this.pos.x += this.vel.x * dt;
    this.pos.z += this.vel.z * dt;
    resolveCollision(this.colliders, this.pos, PLAYER.RADIUS);

    // footsteps
    const sp = Math.hypot(this.vel.x, this.vel.z);
    if (sp > 1.2) {
      this.stepTimer -= dt * sp;
      if (this.stepTimer <= 0) {
        this.stepTimer = 2.1;
        audio.sfx("step");
      }
    }

    // ---- armor plate channel ----
    if (this.plateTimer > 0) {
      this.plateTimer -= dt;
      if (this.plateTimer <= 0) {
        this.plates = Math.max(0, this.plates - 1);
        audio.sfx("plate");
      }
    } else if (input.takeAction("plate") || input.takeAction("KeyE")) {
      this.tryUsePlate(audio);
    }

    // ---- HP regen (no plates — plates are bonus absorb) ----
    this.regenTimer += dt;
    if (this.regenTimer > PLAYER.REGEN_DELAY && this.hp < PLAYER.HP && this.hp > 0) {
      this.hp = Math.min(PLAYER.HP, this.hp + PLAYER.REGEN_RATE * dt);
    }
  }

  tryUsePlate(audio: AudioSystem): void {
    if (this.plates <= 0 || this.plateTimer > 0 || !this.alive) return;
    this.plateTimer = PLAYER.PLATE_TIME;
    audio.sfx("ui");
  }

  /** Apply damage; returns a DamageEvent for the match manager (or null when absorbed fully). */
  damage(amount: number, attacker: string | null, attackerTeam: TeamId, weapon: string): DamageEvent | null {
    if (!this.alive) return null;
    this.regenTimer = 0;
    let remaining = amount;
    // plates absorb first: while any plate charge remains, damage is reduced
    if (this.plates > 0) remaining *= 0.55;
    this.hp -= remaining;
    if (this.hp <= 0) {
      this.hp = 0;
      this.alive = false;
    }
    return { amount: remaining, attacker, attackerTeam, victim: this.name, victimTeam: this.team, weapon };
  }

  respawn(pos: THREE.Vector3, yaw: number): void {
    this.pos.copy(pos);
    this.vel.set(0, 0, 0);
    this.yaw = yaw;
    this.pitch = 0;
    this.hp = PLAYER.HP;
    this.plates = PLAYER.MAX_PLATES;
    this.plateTimer = 0;
    this.alive = true;
    this.crouched = false;
    this.regenTimer = 0;
  }

  /** Write the camera transform for this frame. */
  applyToCamera(cam: THREE.PerspectiveCamera, bobY: number, bobX: number): void {
    cam.position.set(this.pos.x + bobX, this.eyeHeight + bobY, this.pos.z);
    cam.rotation.set(0, 0, 0);
    cam.rotateY(this.yaw);
    cam.rotateX(this.pitch);
  }
}

const _tmpF = new THREE.Vector3();
const _tmpR = new THREE.Vector3();
