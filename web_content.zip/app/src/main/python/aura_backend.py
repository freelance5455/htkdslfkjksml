import json
from ytmusicapi import YTMusic
import yt_dlp

_yt = None

def _music():
    global _yt
    if _yt is None:
        _yt = YTMusic()
    return _yt

def search(query, limit=20):
    rows = _music().search(query, filter='songs', limit=int(limit))
    out=[]
    for x in rows:
        out.append({
            'videoId': x.get('videoId'),
            'title': x.get('title',''),
            'artist': ', '.join(a.get('name','') for a in x.get('artists',[]) if a.get('name')),
            'album': (x.get('album') or {}).get('name','') if isinstance(x.get('album'), dict) else '',
            'duration': x.get('duration',''),
            'duration_seconds': x.get('duration_seconds'),
            'thumbnail': ((x.get('thumbnails') or [{}])[-1]).get('url',''),
            'isExplicit': bool(x.get('isExplicit', False)),
        })
    return json.dumps(out, ensure_ascii=False)

def lyrics(video_id):
    try:
        data = _music().get_watch_playlist(video_id)
        bid = data.get('lyrics') if isinstance(data, dict) else None
        if not bid: return json.dumps({'lyrics': '', 'timed': []}, ensure_ascii=False)
        ly = _music().get_lyrics(bid, timestamps=True)
        if not ly: return json.dumps({'lyrics': '', 'timed': []}, ensure_ascii=False)
        if isinstance(ly, dict): return json.dumps(ly, ensure_ascii=False)
        return json.dumps({'lyrics': str(ly)}, ensure_ascii=False)
    except Exception as e:
        return json.dumps({'lyrics':'','error':str(e)}, ensure_ascii=False)

def resolve(video_id):
    url = 'https://www.youtube.com/watch?v=' + video_id
    opts = {
        'quiet': True,
        'no_warnings': True,
        'noplaylist': True,
        'skip_download': True,
        'format': 'bestaudio[ext=m4a]/bestaudio/best',
    }
    with yt_dlp.YoutubeDL(opts) as ydl:
        info = ydl.extract_info(url, download=False)
    if not info:
        raise RuntimeError('No se pudo resolver la canción')
    fmt = info
    if info.get('requested_formats'):
        fmt = info['requested_formats'][0]
    stream = fmt.get('url') or info.get('url')
    if not stream:
        raise RuntimeError('No hay stream disponible')
    return json.dumps({
        'url': stream,
        'title': info.get('title',''),
        'duration': info.get('duration'),
        'headers': fmt.get('http_headers') or info.get('http_headers') or {},
        'ext': fmt.get('ext') or info.get('ext') or 'm4a'
    }, ensure_ascii=False)
