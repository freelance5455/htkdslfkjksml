// Firebase client configuration for Coffee Trade ERP.
// Replace every PASTE_* value below with the Web app configuration
// from Firebase Console > Project settings > Your apps > Web app.
// Never put a Firebase Admin/service-account private key in this file.
export const firebaseConfig = {
  apiKey: "PASTE_FIREBASE_API_KEY",
  authDomain: "PASTE_PROJECT_ID.firebaseapp.com",
  projectId: "PASTE_PROJECT_ID",
  storageBucket: "PASTE_PROJECT_ID.firebasestorage.app",
  messagingSenderId: "PASTE_MESSAGING_SENDER_ID",
  appId: "PASTE_APP_ID"
};
