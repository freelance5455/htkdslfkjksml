const CACHE = 'ype-expiry-v3';
const ASSETS = ['./index.html', './manifest.webmanifest'];

self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE).then(c => c.addAll(ASSETS)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', event => {
  event.waitUntil(self.clients.claim());
});

function dayDiff(dateStr) {
  const now = new Date();
  now.setHours(0,0,0,0);
  const d = new Date(dateStr + 'T00:00:00');
  return Math.round((d-now)/86400000);
}

async function notifyForItems(items) {
  if (!Array.isArray(items) || Notification.permission !== 'granted') return;
  const seen = await caches.open('ype-notification-state');
  for (const item of items) {
    const n = dayDiff(item.expiry);
    if (![7,3,1,0].includes(n)) continue;
    const key = `${item.id}_${n}_${new Date().toISOString().slice(0,10)}`;
    const already = await seen.match(new Request('/' + encodeURIComponent(key)));
    if (already) continue;
    const body = n === 0
      ? `${item.name} expires today.`
      : `${item.name} expires in ${n} day${n === 1 ? '' : 's'}.`;
    await self.registration.showNotification('YPE Expiry Tracker', {
      body,
      tag: `ype-${item.id}-${n}`,
      renotify: true,
      icon: './icon-192.png',
      badge: './icon-192.png',
      data: {id:item.id}
    });
    await seen.put(new Request('/' + encodeURIComponent(key)), new Response('1'));
  }
}

self.addEventListener('message', event => {
  if (event.data?.type === 'SYNC_EXPIRY_DATA') {
    event.waitUntil(notifyForItems(event.data.items));
  }
});

self.addEventListener('sync', event => {
  if (event.tag === 'ype-expiry-check') {
    event.waitUntil(checkOpenClients());
  }
});

self.addEventListener('periodicsync', event => {
  if (event.tag === 'ype-expiry-periodic') {
    event.waitUntil(checkOpenClients());
  }
});

async function checkOpenClients() {
  const clients = await self.clients.matchAll({includeUncontrolled:true, type:'window'});
  for (const client of clients) {
    client.postMessage({type:'CHECK_EXPIRY'});
  }
}

self.addEventListener('notificationclick', event => {
  event.notification.close();
  event.waitUntil(self.clients.matchAll({type:'window', includeUncontrolled:true}).then(clients => {
    if (clients.length) return clients[0].focus();
    return self.clients.openWindow('./index.html');
  }));
});
