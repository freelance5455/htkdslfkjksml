const CACHE_NAME = 'morabaat-horouf-v2';
const APP_SHELL = [
  './',
  './index.html',
  './manifest.webmanifest'
];
const OPTIONAL_ASSETS = [
  './icon-192.png',
  './icon-512.png'
];

self.addEventListener('install', event => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE_NAME);

    // Required app files must be cached for offline startup.
    await cache.addAll(APP_SHELL);

    // Icons are optional: a missing icon must not break installation.
    await Promise.all(OPTIONAL_ASSETS.map(async asset => {
      try {
        const response = await fetch(asset, { cache: 'reload' });
        if (response.ok) await cache.put(asset, response);
      } catch (_) {
        // Ignore optional assets that are unavailable.
      }
    }));

    await self.skipWaiting();
  })());
});

self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(
      keys.filter(key => key.startsWith('morabaat-horouf-') && key !== CACHE_NAME)
        .map(key => caches.delete(key))
    );
    await self.clients.claim();
  })());
});

self.addEventListener('fetch', event => {
  const request = event.request;
  if (request.method !== 'GET') return;

  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;

  event.respondWith((async () => {
    const cache = await caches.open(CACHE_NAME);

    // For page navigation, use the requested page or the offline app shell.
    if (request.mode === 'navigate') {
      try {
        const response = await fetch(request);
        if (response && response.ok) cache.put('./index.html', response.clone());
        return response;
      } catch (_) {
        return (await cache.match(request)) ||
          (await cache.match('./index.html')) ||
          Response.error();
      }
    }

    const cached = await cache.match(request);
    if (cached) return cached;

    try {
      const response = await fetch(request);
      if (response && response.ok && response.type === 'basic') {
        await cache.put(request, response.clone());
      }
      return response;
    } catch (_) {
      return (await cache.match('./index.html')) || Response.error();
    }
  })());
});
