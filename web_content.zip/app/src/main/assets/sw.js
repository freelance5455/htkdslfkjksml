/* NOMIDMAN TRANS CO. LTD — offline shell cache */
const CACHE = "ea-shell-v7";
const SHELL = [
  "./", "./index.html", "./manifest.webmanifest", "./css/style.css",
  "./js/config.js", "./js/i18n.js", "./js/i18n_extra.js", "./js/geo.js", "./js/db.js", "./js/app.js",
  "./assets/map-bg.webp", "./assets/map-bg.jpg", "./assets/logo-header.png", "./assets/icon-192.png", "./assets/icon-512.png"
];
self.addEventListener("install", e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(SHELL)).then(() => self.skipWaiting()));
});
self.addEventListener("activate", e => {
  e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== CACHE).map(k => caches.delete(k))))
    .then(() => self.clients.claim()));
});
self.addEventListener("fetch", e => {
  if (e.request.method !== "GET") return;
  if (e.request.url.includes("/data/")) {
    // exchange rates: always try the network first so visitors get today's rates
    e.respondWith(fetch(e.request).catch(() => caches.match(e.request)));
    return;
  }
  e.respondWith(caches.match(e.request).then(hit => hit || fetch(e.request).then(res => {
    const copy = res.clone();
    caches.open(CACHE).then(c => c.put(e.request, copy));
    return res;
  }).catch(() => caches.match("./index.html"))));
});
