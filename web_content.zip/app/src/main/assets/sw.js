const CACHE="ims-cache-v3";
const ASSETS=["./","./index.html","./styles.css","./app.js","./manifest.json","./logo.svg"];
self.addEventListener("install",e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS))));
self.addEventListener("fetch",e=>e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request).catch(()=>caches.match("./index.html")))));
self.addEventListener("activate",e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith("ims-cache-")&&k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
