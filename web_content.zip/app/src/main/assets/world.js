// =====================================================================
//  DEAD ZONE - générateur de monde procédural
//  Chaque graine donne : un relief, des lacs, une base militaire, des villages,
//  des maisons / granges / commerces / casernes toutes différentes, des routes.
// =====================================================================
(function(){
"use strict";
const T=32,W=192,H=192,VW=W+1;
const O={TREE:1,ROCK:2,BUSH:3,RUIN:4,CRATE:5,WALL:6,FENCE:7,BENCH:8,FURN:9,FIRE:10,TURRET:11,WINDOW:12,DOORC:14,DOORO:15,TOWER:16,CAR:17,TABLE:18,BED:19,CAB:20,CABO:21,BARREL:22};
const ST={WOOD:0,STONE:1,BRICK:2,CONC:3,PLAST:4,METAL:5};
// tuiles : 0 herbe, 1 eau, 2 béton, 3 sable, 4 chemin de terre, 5 route asphalte, 6 sous-bois, 7 gravier
const tile=new Uint8Array(W*H),obj=new Uint8Array(W*H),sty=new Uint8Array(W*H),flo=new Uint8Array(W*H),roo=new Uint8Array(W*H),occ=new Uint8Array(W*H);
const HM=new Float32Array(VW*(H+1));
const BLD=[],POI=[];
let SEED=1,rnd=Math.random;

function mulberry(a){return function(){a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}}
function hash(x,y){let h=(Math.imul(x,374761393)+Math.imul(y,668265263)+SEED)|0;h=Math.imul(h^(h>>>13),1274126177);return((h^(h>>>16))>>>0)/4294967296}
function vn(x,y,s){const gx=x/s,gy=y/s,ix=Math.floor(gx),iy=Math.floor(gy),fx=gx-ix,fy=gy-iy;
 const a=hash(ix,iy),b=hash(ix+1,iy),c=hash(ix,iy+1),d=hash(ix+1,iy+1);
 const u=fx*fx*(3-2*fx),v=fy*fy*(3-2*fy);return a+(b-a)*u+(c-a)*v+(a-b-c+d)*u*v}
const clamp=(v,a,b)=>v<a?a:v>b?b:v;
const sstep=(a,b,v)=>{const t=clamp((v-a)/(b-a),0,1);return t*t*(3-2*t)};
const r=()=>rnd();
const ri=(a,b)=>a+Math.floor(rnd()*(b-a+1));
const pick=a=>a[Math.floor(rnd()*a.length)];
const inb=(x,y)=>x>=0&&y>=0&&x<W&&y<H;
const DIRS=[[0,-1],[1,0],[0,1],[-1,0]]; // N E S W

// ---------- relief ----------
function flat(x,y,w,h,m){
 let s=0,n=0;for(let j=y;j<=y+h;j++)for(let i=x;i<=x+w;i++){s+=HM[j*VW+i];n++}
 const lvl=clamp(s/n,0.06,1.1);
 for(let j=y-m;j<=y+h+m;j++)for(let i=x-m;i<=x+w+m;i++){
  if(i<0||j<0||i>W||j>H)continue;
  const dx=i<x?x-i:i>x+w?i-(x+w):0,dy=j<y?y-j:j>y+h?j-(y+h):0,d=Math.hypot(dx,dy);
  if(d>=m)continue;const t=1-d/m,s2=t*t*(3-2*t),k=j*VW+i;HM[k]=HM[k]*(1-s2)+lvl*s2;
 }
 return lvl;
}
function hAt(tx,ty){ // hauteur au centre d'une case (unités de case)
 const i=Math.floor(tx),j=Math.floor(ty);return(HM[j*VW+i]+HM[j*VW+i+1]+HM[(j+1)*VW+i]+HM[(j+1)*VW+i+1])/4;
}
function hSample(x,z){ // interpolation bilinéaire en coordonnées monde (unités de case)
 x=clamp(x,0,W-0.001);z=clamp(z,0,H-0.001);
 const i=Math.floor(x),j=Math.floor(z),fx=x-i,fz=z-j,k=j*VW+i;
 return(HM[k]*(1-fx)+HM[k+1]*fx)*(1-fz)+(HM[k+VW]*(1-fx)+HM[k+VW+1]*fx)*fz;
}

// ---------- zones libres ----------
function areaOK(x,y,w,h,frac,margin){
 let bad=0,n=0;
 for(let yy=y-margin;yy<y+h+margin;yy++)for(let xx=x-margin;xx<x+w+margin;xx++){
  n++;if(!inb(xx,yy)){bad++;continue}
  const i=yy*W+xx;if(tile[i]===1||occ[i]!==0)bad++;
 }
 return bad/n<=1-frac;
}
function rectFree(x,y,w,h,m){
 for(let yy=y-m;yy<y+h+m;yy++)for(let xx=x-m;xx<x+w+m;xx++){
  if(!inb(xx,yy))return false;const i=yy*W+xx;if(tile[i]===1||occ[i]!==0)return false;
 }
 return true;
}
function markOcc(x,y,w,h,v){for(let yy=y;yy<y+h;yy++)for(let xx=x;xx<x+w;xx++)if(inb(xx,yy))occ[yy*W+xx]=v}
function farFrom(cx,cy,d){for(const p of POI){if(Math.hypot(p.cx-cx,p.cy-cy)<d)return false}return true}

// ---------- bâtiment générique ----------
// o: style, door:{side,pos,width}, windowP, roof('gable'|'flat'|'none'), roofCol, floor, partition, furn:[[type,n]...], damage, kind
function makeBuilding(x,y,w,h,o){
 const style=o.style,dmg=o.damage||0;
 for(let j=0;j<h;j++)for(let i=0;i<w;i++){
  const gx=x+i,gy=y+j,ix=gy*W+gx,edge=(i===0||j===0||i===w-1||j===h-1);
  flo[ix]=o.floor;occ[ix]=1;obj[ix]=edge?O.WALL:0;sty[ix]=style;if(tile[ix]===1)tile[ix]=0;
 }
 // porte(s)
 const ds=o.door.side,dp=o.door.pos,dw=o.door.width||1,doorIdx=[];
 const doorT=[];
 for(let k=0;k<dw;k++){
  let gx,gy;
  if(ds===0){gx=x+dp+k;gy=y}else if(ds===2){gx=x+dp+k;gy=y+h-1}else if(ds===1){gx=x+w-1;gy=y+dp+k}else{gx=x;gy=y+dp+k}
  const ix=gy*W+gx;obj[ix]=r()<0.35?O.DOORO:O.DOORC;sty[ix]=style;doorT.push([gx,gy]);doorIdx.push(dp+k);
 }
 // fenêtres
 const wp=o.windowP==null?0.8:o.windowP;
 const trySide=(side,len)=>{
  for(let k=1;k<len-1;k++){
   if(side===ds&&doorIdx.some(d=>Math.abs(d-k)<=1))continue;
   if(len>=6?(k%2===0):(k!==Math.floor(len/2)))continue;
   if(r()>wp)continue;
   let gx,gy;
   if(side===0){gx=x+k;gy=y}else if(side===2){gx=x+k;gy=y+h-1}else if(side===1){gx=x+w-1;gy=y+k}else{gx=x;gy=y+k}
   const ix=gy*W+gx;if(obj[ix]===O.WALL)obj[ix]=O.WINDOW;
  }
 };
 if(wp>0){trySide(0,w);trySide(2,w);trySide(1,h);trySide(3,h)}
 // cloison intérieure
 if(o.partition){
  if(w>=8&&w>=h){
   const px=x+ri(3,w-4);let ok=true;for(const d of doorT)if(Math.abs(d[0]-px)<=1)ok=false;
   if(ok){const dj=ri(1,h-2);for(let j=1;j<h-1;j++){const ix=(y+j)*W+px;obj[ix]=(j===dj)?(r()<.5?O.DOORO:O.DOORC):O.WALL;sty[ix]=style}}
  }else if(h>=8){
   const py=y+ri(3,h-4);let ok=true;for(const d of doorT)if(Math.abs(d[1]-py)<=1)ok=false;
   if(ok){const di=ri(1,w-2);for(let i=1;i<w-1;i++){const ix=py*W+x+i;obj[ix]=(i===di)?(r()<.5?O.DOORO:O.DOORC):O.WALL;sty[ix]=style}}
  }
 }
 // mobilier : on garde libre l'entrée
 const keep=new Set();
 for(const d of doorT){for(let k=1;k<=2;k++){const nx=d[0]-DIRS[ds][0]*k,ny=d[1]-DIRS[ds][1]*k;keep.add(ny*W+nx)}}
 const free=[];
 for(let j=1;j<h-1;j++)for(let i=1;i<w-1;i++){const ix=(y+j)*W+x+i;if(obj[ix]===0&&!keep.has(ix))free.push([x+i,y+j])}
 const nearWall=(gx,gy)=>{for(const d of DIRS){const nx=gx+d[0],ny=gy+d[1];const o2=obj[ny*W+nx];if(o2===O.WALL||o2===O.WINDOW)return true}return false};
 for(const f of (o.furn||[])){
  for(let n=0;n<f[1];n++){
   if(!free.length)break;
   let idx=-1;
   for(let t=0;t<14;t++){const k=Math.floor(r()*free.length);if(f[0]===O.CRATE||nearWall(free[k][0],free[k][1])){idx=k;break}}
   if(idx<0)idx=Math.floor(r()*free.length);
   const p=free.splice(idx,1)[0];obj[p[1]*W+p[0]]=f[0];sty[p[1]*W+p[0]]=style;
  }
 }
 // dégâts : murs effondrés
 if(dmg>0){
  for(let j=0;j<h;j++)for(let i=0;i<w;i++){
   if(!(i===0||j===0||i===w-1||j===h-1))continue;const ix=(y+j)*W+x+i;
   if((obj[ix]===O.WALL||obj[ix]===O.WINDOW||obj[ix]===O.DOORC||obj[ix]===O.DOORO)&&r()<dmg*0.55)obj[ix]=r()<.35?O.RUIN:0;
  }
 }
 const lvl=hAt(x+w/2,y+h/2);
 BLD.push({x,y,w,h,style,roof:dmg>0.35?'none':o.roof,col:o.roofCol,ridge:w>=h?0:1,lvl,kind:o.kind||'house',dmg});
}

const ROOFS=[0xb0533a,0xa04a32,0x4a4f57,0x5b4636,0x6b3f2a,0x3d4a3c,0x7a2f2a];
const HOUSEW=[ST.BRICK,ST.BRICK,ST.PLAST,ST.PLAST,ST.WOOD,ST.STONE];

// porte sur le côté `side` (0N 1E 2S 3W) à une position aléatoire d'un mur de longueur len
function randDoor(side,w,h,width){const len=(side===0||side===2)?w:h;const dw=width||1;return{side,pos:ri(1,Math.max(1,len-1-dw)),width:dw}}

function houseOpts(side,w,h,kind){
 let style=pick(HOUSEW),o;
 if(kind==='barn'){o={style:ST.WOOD,door:{side,pos:Math.floor((((side%2===0)?w:h)-3)/2),width:3},windowP:0,roof:'gable',roofCol:pick([0x5b4636,0x6b3f2a,0x7a2f2a]),floor:1,partition:false,furn:[[O.CRATE,ri(3,6)],[O.BARREL,ri(1,3)]],kind}}
 else if(kind==='shop'){o={style:pick([ST.BRICK,ST.PLAST]),door:randDoor(side,w,h,1),windowP:1,roof:'flat',roofCol:0x55575c,floor:2,partition:false,furn:[[O.CAB,ri(3,5)],[O.TABLE,1],[O.CRATE,ri(2,4)]],kind}}
 else if(kind==='garage'){o={style:pick([ST.PLAST,ST.CONC]),door:randDoor(side,w,h,3),windowP:.3,roof:r()<.5?'flat':'gable',roofCol:0x4a4f57,floor:2,partition:false,furn:[[O.CAR,1],[O.CRATE,ri(1,3)],[O.BARREL,1]],kind}}
 else if(kind==='cabin'){o={style:ST.WOOD,door:randDoor(side,w,h,1),windowP:.7,roof:'gable',roofCol:pick([0x5b4636,0x6b3f2a,0x3d4a3c]),floor:1,partition:false,furn:[[O.BED,1],[O.TABLE,1],[O.CAB,1],[O.CRATE,ri(0,2)]],kind}}
 else{o={style,door:randDoor(side,w,h,1),windowP:.85,roof:r()<.8?'gable':'flat',roofCol:pick(ROOFS),floor:r()<.8?1:3,partition:true,furn:[[O.BED,ri(1,3)],[O.TABLE,1],[O.CAB,ri(1,2)],[O.CRATE,ri(0,2)]],kind:'house'}}
 o.damage=r()<.2?r()*.7:0;
 return o;
}

// ---------- BASE MILITAIRE ----------
function makeBase(){
 let bw,bh,x,y,found=false;
 for(let tries=0;tries<260&&!found;tries++){
  bw=ri(38,48);bh=ri(38,48);x=ri(14,W-14-bw);y=ri(14,H-14-bh);
  if(areaOK(x,y,bw,bh,tries<150?0.98:0.9,3))found=true;
 }
 if(!found){bw=40;bh=40;x=76;y=76} // secours : on force la terre ferme
 const lvl=flat(x,y,bw,bh,6);
 for(let j=y-1;j<y+bh+1;j++)for(let i=x-1;i<x+bw+1;i++){const k=j*W+i;if(tile[k]===1)tile[k]=0}
 const cx=x+(bw>>1),cy=y+(bh>>1);
 for(let j=y;j<y+bh;j++)for(let i=x;i<x+bw;i++){const k=j*W+i;tile[k]=2;obj[k]=0;occ[k]=0}
 // voies principales
 for(let j=y;j<y+bh;j++)for(let i=cx-1;i<=cx+1;i++){tile[j*W+i]=5;occ[j*W+i]=2}
 for(let i=x;i<x+bw;i++)for(let j=cy-1;j<=cy+1;j++){tile[j*W+i]=5;occ[j*W+i]=2}
 // clôture
 for(let k=0;k<bw;k++){for(const j of [y,y+bh-1]){const ix=j*W+x+k;obj[ix]=O.FENCE;sty[ix]=ST.METAL;occ[ix]=1}}
 for(let k=0;k<bh;k++){for(const i of [x,x+bw-1]){const ix=(y+k)*W+i;obj[ix]=O.FENCE;sty[ix]=ST.METAL;occ[ix]=1}}
 // portail
 const gside=ri(0,3);let gx,gy,out;
 for(let k=-1;k<=1;k++){
  let tx,ty;
  if(gside===0){tx=cx+k;ty=y}else if(gside===2){tx=cx+k;ty=y+bh-1}else if(gside===1){tx=x+bw-1;ty=cy+k}else{tx=x;ty=cy+k}
  obj[ty*W+tx]=0;occ[ty*W+tx]=2;
 }
 if(gside===0){gx=cx;gy=y}else if(gside===2){gx=cx;gy=y+bh-1}else if(gside===1){gx=x+bw-1;gy=cy}else{gx=x;gy=cy}
 out={x:gx+DIRS[gside][0]*4,y:gy+DIRS[gside][1]*4};
 // tours de guet
 const tw=[[x,y],[x+bw-1,y],[x,y+bh-1],[x+bw-1,y+bh-1]];
 for(const t of tw){const ix=t[1]*W+t[0];obj[ix]=O.TOWER;sty[ix]=ST.METAL;occ[ix]=1}
 for(const s of [-3,3]){let tx,ty;if(gside%2===0){tx=cx+s;ty=gy}else{tx=gx;ty=cy+s}const ix=ty*W+tx;obj[ix]=O.TOWER;sty[ix]=ST.METAL;occ[ix]=1}
 // bâtiments par quadrant
 const kinds={
  barracks:{w:[11,14],h:[5,6],style:[ST.CONC],roof:['flat','gable'],col:[0x5a5f57,0x4a5446],win:.9,floor:2,part:true,furn:()=>[[O.BED,ri(3,6)],[O.CAB,ri(1,3)],[O.CRATE,ri(1,3)]]},
  hangar:{w:[12,14],h:[8,10],style:[ST.METAL],roof:['gable'],col:[0x5d6b62,0x6a6f73],win:0,floor:2,part:false,bigdoor:true,furn:()=>[[O.CRATE,ri(5,9)],[O.BARREL,ri(2,4)],[O.CAR,ri(0,2)]]},
  warehouse:{w:[8,10],h:[6,8],style:[ST.CONC,ST.METAL],roof:['flat','gable'],col:[0x55575c,0x4a5446],win:.3,floor:2,part:false,furn:()=>[[O.CRATE,ri(6,10)],[O.CAB,ri(1,3)],[O.BARREL,ri(1,3)]]},
  office:{w:[7,8],h:[5,6],style:[ST.BRICK,ST.PLAST],roof:['flat','gable'],col:[0x4a4f57,0x7a2f2a],win:1,floor:3,part:true,furn:()=>[[O.TABLE,ri(2,3)],[O.CAB,ri(2,4)],[O.CRATE,ri(0,2)]]},
  bunker:{w:[5,6],h:[4,5],style:[ST.CONC],roof:['flat'],col:[0x4a4d50],win:0,floor:2,part:false,furn:()=>[[O.CAB,ri(2,3)],[O.CRATE,ri(3,5)]]},
  garage:{w:[6,8],h:[5,6],style:[ST.CONC,ST.METAL],roof:['flat','gable'],col:[0x55575c,0x4a5446],win:.2,floor:2,part:false,bigdoor:true,furn:()=>[[O.CAR,1],[O.CRATE,ri(1,3)],[O.BARREL,ri(1,2)]]}
 };
 const names=Object.keys(kinds);
 const quads=[[x+2,y+2,cx-3,cy-3],[cx+3,y+2,x+bw-3,cy-3],[x+2,cy+3,cx-3,y+bh-3],[cx+3,cy+3,x+bw-3,y+bh-3]];
 let nb=0;
 quads.forEach((q,qi)=>{
  const target=ri(3,5);let placed=0;
  for(let at=0;at<120&&placed<target;at++){
   const kn=names[(at<4&&placed<names.length)?(qi+placed)%names.length:ri(0,names.length-1)],K=kinds[kn];
   let w=ri(K.w[0],K.w[1]),h=ri(K.h[0],K.h[1]);if(r()<.5){const t=w;w=h;h=t}
   const bx0=q[0],bx1=q[2]-w+1,by0=q[1],by1=q[3]-h+1;if(bx1<bx0||by1<by0)continue;
   const bx=ri(bx0,bx1),by=ri(by0,by1);
   if(!rectFree(bx,by,w,h,1))continue;
   const left=bx+w-1<cx,above=by+h-1<cy;
   const dV=left?(cx-1)-(bx+w-1):bx-(cx+1),dH=above?(cy-1)-(by+h-1):by-(cy+1);
   const side=dV<=dH?(left?1:3):(above?2:0);
   const dw=K.bigdoor?3:1;
   const o={style:pick(K.style),door:randDoor(side,w,h,dw),windowP:K.win,roof:pick(K.roof),roofCol:pick(K.col),floor:K.floor,partition:K.part,furn:K.furn(),damage:r()<.25?r()*.6:0,kind:kn};
   makeBuilding(bx,by,w,h,o);placed++;nb++;
  }
 });
 // caisses, barils, voitures dans la cour
 for(let c=0;c<40;c++){const px=x+2+ri(0,bw-5),py=y+2+ri(0,bh-5),i=py*W+px;if(!obj[i]&&occ[i]!==1&&tile[i]!==5||(!obj[i]&&occ[i]===0)){if(!obj[i]){obj[i]=c%7===0?O.BARREL:O.CRATE;sty[i]=ST.METAL}}}
 for(let c=0;c<7;c++){const px=x+2+ri(0,bw-5),py=y+2+ri(0,bh-5),i=py*W+px;if(!obj[i]&&occ[i]===2)obj[i]=O.CAR}
 // le reste de la cour est réservé
 for(let j=y;j<y+bh;j++)for(let i=x;i<x+bw;i++){const k=j*W+i;if(occ[k]===0)occ[k]=3}
 for(let j=y-2;j<y+bh+2;j++)for(let i=x-2;i<x+bw+2;i++){if(inb(i,j)&&occ[j*W+i]===0)occ[j*W+i]=3}
 const poi={type:'base',x,y,w:bw,h:bh,cx,cy,gate:{x:gx,y:gy,side:gside},out,lvl};
 POI.push(poi);return poi;
}

// ---------- VILLAGES ----------
function makeVillage(){
 for(let tries=0;tries<120;tries++){
  const L=ri(24,34),horiz=r()<.5,bw=horiz?L+6:26,bh=horiz?26:L+6;
  const x=ri(10,W-10-bw),y=ri(10,H-10-bh);
  if(!areaOK(x,y,bw,bh,0.93,0))continue;
  const vcx=x+(bw>>1),vcy=y+(bh>>1);
  if(!farFrom(vcx,vcy,34))continue;
  flat(x,y,bw,bh,4);
  const toXY=(u,v)=>horiz?[x+u,y+v]:[x+v,y+u];
  const mid=(horiz?bh:bw)>>1,len=horiz?bw:bh;
  // rue principale (largeur 3)
  const asphalt=r()<.6;
  for(let u=1;u<len-1;u++)for(let v=mid-1;v<=mid+1;v++){const p=toXY(u,v),k=p[1]*W+p[0];tile[k]=asphalt?5:4;occ[k]=2;obj[k]=0}
  const houses=[];
  for(const sideSign of [-1,1]){
   let u=2;
   while(u<len-8){
    const kind=r()<.1?'barn':r()<.14?'shop':r()<.12?'garage':'house';
    let lw,lh;
    if(kind==='barn'){lw=ri(8,10);lh=ri(7,8)}else if(kind==='shop'){lw=ri(7,9);lh=ri(5,6)}else if(kind==='garage'){lw=ri(6,7);lh=ri(5,6)}else{lw=ri(5,8);lh=ri(4,6)}
    const v0=sideSign<0?(mid-2-lh):(mid+3);
    const [wx,wy]=toXY(u,v0);const rw=horiz?lw:lh,rh=horiz?lh:lw;
    if(u+lw>=len-1)break;
    if(rectFree(wx,wy,rw,rh,1)){
     // la porte regarde la rue
     let side;if(horiz)side=sideSign<0?2:0;else side=sideSign<0?1:3;
     const o=houseOpts(side,rw,rh,kind);
     makeBuilding(wx,wy,rw,rh,o);houses.push({x:wx,y:wy,w:rw,h:rh,side,o});
     // chemin d'accès jusqu'à la rue
     const d=o.door;let dx,dy;
     if(side===0){dx=wx+d.pos+(d.width>>1);dy=wy-1}else if(side===2){dx=wx+d.pos+(d.width>>1);dy=wy+rh}else if(side===1){dx=wx+rw;dy=wy+d.pos+(d.width>>1)}else{dx=wx-1;dy=wy+d.pos+(d.width>>1)}
     for(let s=0;s<6;s++){const px=dx+DIRS[side][0]*s,py=dy+DIRS[side][1]*s;if(!inb(px,py))break;const k=py*W+px;if(occ[k]===2)break;if(obj[k]===0&&tile[k]!==1&&occ[k]===0){tile[k]=4}}
     u+=lw+ri(1,3);
    }else u+=2;
   }
  }
  const poi={type:'village',x,y,w:bw,h:bh,cx:vcx,cy:vcy,horiz,houses:houses.length,streetA:toXY(1,mid),streetB:toXY(len-2,mid),streetM:toXY(len>>1,mid)};
  POI.push(poi);
  // jardins : quelques clôtures en bois le long de la rue
  return poi;
 }
 return null;
}

// ---------- CABANES / FERMES ISOLEES ----------
function makeCabin(kind){
 for(let tries=0;tries<80;tries++){
  const w=kind==='cabin'?ri(5,6):ri(6,8),h=kind==='cabin'?ri(4,5):ri(5,6);
  const x=ri(8,W-8-w),y=ri(8,H-8-h);
  if(!rectFree(x,y,w,h,3))continue;
  const cx=x+(w>>1),cy=y+(h>>1);if(!farFrom(cx,cy,14))continue;
  let n=0;for(let j=y-3;j<y+h+3;j++)for(let i=x-3;i<x+w+3;i++){if(tile[j*W+i]===3)n++}if(n>6)continue;
  flat(x,y,w,h,3);
  const side=ri(0,3);const o=houseOpts(side,w,h,kind==='cabin'?'cabin':'house');
  makeBuilding(x,y,w,h,o);
  let dx,dy;const d=o.door;
  if(side===0){dx=x+d.pos;dy=y-1}else if(side===2){dx=x+d.pos;dy=y+h}else if(side===1){dx=x+w;dy=y+d.pos}else{dx=x-1;dy=y+d.pos}
  const poi={type:'cabin',x,y,w,h,cx,cy,front:{x:dx,y:dy}};POI.push(poi);
  // grange pour une ferme
  if(kind==='farm'){
   for(let t2=0;t2<30;t2++){
    const bw2=ri(8,10),bh2=ri(7,8),bx=x+ri(-14,14),by=y+ri(-14,14);
    if(!inb(bx,by)||!rectFree(bx,by,bw2,bh2,2))continue;
    flat(bx,by,bw2,bh2,3);makeBuilding(bx,by,bw2,bh2,houseOpts(ri(0,3),bw2,bh2,'barn'));break;
   }
  }
  return poi;
 }
 return null;
}

// ---------- ROUTES ----------
function route(ax,ay,bx,by){
 const N=W*H,g=new Float32Array(N).fill(1e9),from=new Int32Array(N).fill(-1),done=new Uint8Array(N);
 const hf=[],hi=[];
 const push=(f,i)=>{let k=hf.length;hf.push(f);hi.push(i);while(k>0){const p=(k-1)>>1;if(hf[p]<=hf[k])break;[hf[p],hf[k]]=[hf[k],hf[p]];[hi[p],hi[k]]=[hi[k],hi[p]];k=p}};
 const pop=()=>{const top=hi[0],lf=hf.pop(),li=hi.pop();if(hf.length){hf[0]=lf;hi[0]=li;let k=0;for(;;){let l=2*k+1,rr=l+1,m=k;if(l<hf.length&&hf[l]<hf[m])m=l;if(rr<hf.length&&hf[rr]<hf[m])m=rr;if(m===k)break;[hf[m],hf[k]]=[hf[k],hf[m]];[hi[m],hi[k]]=[hi[k],hi[m]];k=m}}return top};
 const s=ay*W+ax,e=by*W+bx;g[s]=0;push(0,s);
 const hc=i=>hAt(i%W,Math.floor(i/W));
 while(hf.length){
  const i=pop();if(i===e)break;
  if(done[i])continue;done[i]=1;
  const x=i%W,y=(i/W)|0,hi0=hc(i);
  for(let dy=-1;dy<=1;dy++)for(let dx=-1;dx<=1;dx++){
   if(!dx&&!dy)continue;const nx=x+dx,ny=y+dy;if(nx<2||ny<2||nx>=W-2||ny>=H-2)continue;
   const j=ny*W+nx;if(occ[j]===1||occ[j]===3)continue;
   const step=(dx&&dy)?1.414:1;
   let c=step*(1+(tile[j]===1?6:0)+Math.abs(hc(j)-hi0)*4+(occ[j]===2?-0.5:0)+(tile[j]===5||tile[j]===4?-0.3:0));
   if(c<0.3)c=0.3;
   const ng=g[i]+c;if(ng<g[j]){g[j]=ng;from[j]=i;const hx=Math.abs(nx-bx),hy=Math.abs(ny-by);push(ng+0.3*(hx+hy-0.586*Math.min(hx,hy)),j)}
  }
 }
 if(from[e]<0&&s!==e)return null;
 const out=[];for(let i=e;i!==-1;i=from[i])out.push([i%W,(i/W)|0]);return out.reverse();
}
function carve(path,asphalt){
 if(!path)return;
 for(const p of path){
  for(let dy=0;dy<2;dy++)for(let dx=0;dx<2;dx++){
   const x=p[0]+dx,y=p[1]+dy;if(!inb(x,y))continue;const k=y*W+x;if(occ[k]===1||occ[k]===3)continue;
   if(tile[k]===2)continue;
   if(tile[k]===1){const hh=[k+(y)*0];for(const vv of [[x,y],[x+1,y],[x,y+1],[x+1,y+1]]){const q=vv[1]*VW+vv[0];if(HM[q]<0.1)HM[q]=0.1}}
   if(!(tile[k]===5&&!asphalt))tile[k]=asphalt?5:4;
   obj[k]=0;
  }
 }
}

// ---------- GENERATION ----------
function generate(seed){
 SEED=seed|0;rnd=mulberry(SEED);
 tile.fill(0);obj.fill(0);sty.fill(0);flo.fill(0);roo.fill(0);occ.fill(0);BLD.length=0;POI.length=0;
 // 1. altitude
 const elv=new Float32Array(VW*(H+1));
 for(let j=0;j<=H;j++)for(let i=0;i<=W;i++){
  const edge=Math.min(i,j,W-i,H-j),fall=clamp((18-edge)/18,0,1);
  elv[j*VW+i]=vn(i,j,38)*0.55+vn(i,j,17)*0.3+vn(i,j,6)*0.15-fall*fall*0.6;
 }
 const te=new Float32Array(W*H);
 for(let y=0;y<H;y++)for(let x=0;x<W;x++){const k=y*VW+x;te[y*W+x]=(elv[k]+elv[k+1]+elv[k+VW]+elv[k+VW+1])/4}
 const sorted=Float32Array.from(te).sort();const wl=sorted[Math.floor(W*H*0.25)];
 for(let j=0;j<=H;j++)for(let i=0;i<=W;i++){
  const e=elv[j*VW+i]-wl;
  const base=clamp(e*7,-0.55,0.3);
  const hills=(vn(i,j,30)*0.7+vn(i,j,11)*0.3-0.5)*2.6*sstep(0.02,0.18,e);
  HM[j*VW+i]=base+hills;
 }
 for(let y=0;y<H;y++)for(let x=0;x<W;x++){
  const i=y*W+x,e=te[i]-wl;
  if(e<0)tile[i]=1;else if(e<0.03)tile[i]=3;
  else if(vn(x+731,y+97,13)>0.56)tile[i]=6;
 }
 // 2. lieux
 makeBase();
 const nv=ri(3,5);for(let v=0;v<nv;v++)makeVillage();
 const nc=ri(7,11);for(let c=0;c<nc;c++)makeCabin(c%3===0?'farm':'cabin');
 // 3. point d'apparition du joueur
 let spawn=null;const base=POI.find(p=>p.type==='base');
 for(let t=0;t<2000&&!spawn;t++){
  const x=ri(10,W-10),y=ri(10,H-10),i=y*W+x;
  if(tile[i]===1||tile[i]===3||occ[i]!==0)continue;
  if(Math.hypot(x-base.cx,y-base.cy)<48)continue;
  if(!rectFree(x-4,y-4,9,9,0))continue;
  let ok=true;for(const p of POI){if(p.type!=='base'&&Math.hypot(x-p.cx,y-p.cy)<10)ok=false}
  if(!ok)continue;spawn={x,y};
 }
 if(!spawn){spawn={x:Math.max(6,base.x-12),y:base.cy};}
 flat(spawn.x-3,spawn.y-3,6,6,4);
 for(let j=spawn.y-4;j<=spawn.y+4;j++)for(let i=spawn.x-4;i<=spawn.x+4;i++){if(inb(i,j)){const k=j*W+i;if(tile[k]===1)tile[k]=0;obj[k]=0;if(tile[k]===6)tile[k]=0}}
 // 4. routes : arbre couvrant minimal entre les lieux
 const nodes=[{x:base.out.x,y:base.out.y,t:'base'},{x:spawn.x,y:spawn.y,t:'spawn'}];
 for(const p of POI){if(p.type==='village'){nodes.push({x:p.streetA[0],y:p.streetA[1],t:'village'});nodes.push({x:p.streetB[0],y:p.streetB[1],t:'village2'})}else if(p.type==='cabin')nodes.push({x:p.front.x,y:p.front.y,t:'cabin'})}
 const ok2=nodes.filter(n=>inb(n.x,n.y));
 const inTree=[ok2[0]],rest=ok2.slice(1);
 while(rest.length){
  let bi=-1,bj=-1,bd=1e9;
  for(let a=0;a<inTree.length;a++)for(let b=0;b<rest.length;b++){const d=Math.hypot(inTree[a].x-rest[b].x,inTree[a].y-rest[b].y);if(d<bd){bd=d;bi=a;bj=b}}
  const A=inTree[bi],B=rest.splice(bj,1)[0];
  const asphalt=(A.t==='base'||A.t.startsWith('village'))&&(B.t.startsWith('village')||B.t==='base');
  const pth=route(A.x,A.y,B.x,B.y);carve(pth,asphalt);inTree.push(B);
 }
 // 5. végétation
 for(let y=2;y<H-2;y++)for(let x=2;x<W-2;x++){
  const i=y*W+x;if(obj[i]||occ[i]!==0)continue;const t=tile[i];if(t!==0&&t!==6&&t!==3)continue;
  let near=false;
  for(const d of DIRS){const k=(y+d[1])*W+x+d[0];if(tile[k]===4||tile[k]===5||occ[k]===1||occ[k]===3)near=true}
  if(near)continue;
  const f=vn(x+500,y+200,14),rr=r(),hh=hAt(x,y);
  if(t===3){if(rr<0.004)obj[i]=O.ROCK;continue}
  if(f>0.5&&rr<0.4)obj[i]=O.TREE;
  else if(rr<0.03*(f>0.4?2:1))obj[i]=O.TREE;
  else if(rr<0.03+0.012+(hh>0.5?0.03:0))obj[i]=O.ROCK;
  else if(rr<0.03+0.012+(hh>0.5?0.03:0)+0.013)obj[i]=O.BUSH;
  else if(rr<0.03+0.012+(hh>0.5?0.03:0)+0.013+0.0015)obj[i]=O.CRATE;
 }
 // 6. voitures abandonnées le long des routes
 for(let y=3;y<H-3;y++)for(let x=3;x<W-3;x++){
  const i=y*W+x;if(tile[i]!==5||obj[i]||occ[i]===1||occ[i]===3)continue;
  if(r()>0.012)continue;
  let roadN=0;for(const d of DIRS){const k=(y+d[1])*W+x+d[0];if((tile[k]===5||tile[k]===4)&&!obj[k])roadN++}
  if(roadN>=3)obj[i]=O.CAR;
 }
 // 7. point d'apparition final
 const sp={x:spawn.x*T+16,y:spawn.y*T+16};
 return{spawn:sp,base,pois:POI,bld:BLD,wl};
}

const WORLD={T,W,H,VW,O,ST,tile,obj,sty,flo,roo,occ,HM,BLD,POI,generate,hAt,hSample,mulberry,hash,vn,
 isSolid:o=>o!==0&&o!==O.DOORO};
if(typeof module!=='undefined'&&module.exports)module.exports=WORLD;else window.DZW=WORLD;
})();
