/**
 * calendar.js
 * Calendar Engine for Taghvim Sina (تقویم سینا)
 * Handles Jalali (Persian), Gregorian, and Hijri conversions, week numbers, and Iranian events.
 */

class CalendarEngine {
  constructor() {
    this.jalaliMonthNames = [
      'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
      'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'
    ];

    this.gregorianMonthNames = [
      'ژانویه', 'فوریه', 'مارس', 'آوریل', 'مه', 'ژوئن',
      'ژوئیه', 'اوت', 'سپتامبر', 'اکتبر', 'نوامبر', 'دسامبر'
    ];

    this.hijriMonthNames = [
      'محرم', 'صفر', 'ربیع‌الاول', 'ربیع‌الثانی', 'جمادی‌الاول', 'جمادی‌الثانی',
      'رجب', 'شعبان', 'رمضان', 'شوال', 'ذیقعده', 'ذیحجه'
    ];

    this.weekDayNames = [
      'شنبه', 'یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنج‌شنبه', 'جمعه'
    ];

    // Static Iranian National (Solar/Jalali) Events Database
    this.events = {
      "1-1": { title: "عید نوروز", holiday: true },
      "1-2": { title: "عید نوروز (روز دوم)", holiday: true },
      "1-3": { title: "عید نوروز (روز سوم)", holiday: true },
      "1-4": { title: "عید نوروز (روز چهارم)", holiday: true },
      "1-12": { title: "روز جمهوری اسلامی ایران", holiday: true },
      "1-13": { title: "روز طبیعت (سیزده‌بدر)", holiday: true },
      "1-29": { title: "روز ارتش جمهوری اسلامی ایران", holiday: false },
      "2-1": { title: "روز بزرگداشت سعدی", holiday: false },
      "2-3": { title: "روز بزرگداشت شیخ بهایی / روز معمار", holiday: false },
      "2-10": { title: "روز ملی خلیج فارس", holiday: false },
      "2-12": { title: "روز معلم / شهادت استاد مطهری", holiday: false },
      "2-25": { title: "روز بزرگداشت فردوسی و پاسداشت زبان فارسی", holiday: false },
      "2-28": { title: "روز بزرگداشت خیام", holiday: false },
      "3-3": { title: "فتح خرمشهر (روز مقاومت و پیروزی)", holiday: false },
      "3-14": { title: "رحلت امام خمینی (ره)", holiday: true },
      "3-15": { title: "قیام ۱۵ خرداد", holiday: true },
      "3-20": { title: "روز جهانی صنایع دستی", holiday: false },
      "4-7": { title: "شهادت آیت‌الله بهشتی و ۷۲ تن از یارانش", holiday: false },
      "4-10": { title: "روز صنعت و معدن", holiday: false },
      "4-14": { title: "روز قلم", holiday: false },
      "5-8": { title: "روز بزرگداشت شیخ شهاب‌الدین سهروردی", holiday: false },
      "5-17": { title: "روز خبرنگار", holiday: false },
      "5-28": { title: "سالروز کودتای ۲۸ مرداد", holiday: false },
      "6-1": { title: "روز پزشک (بزرگداشت ابن‌سینا)", holiday: false },
      "6-2": { title: "آغاز هفته دولت", holiday: false },
      "6-5": { title: "روز داروساز (بزرگداشت زکریای رازی)", holiday: false },
      "6-13": { title: "روز بزرگداشت ابوریحان بیرونی", holiday: false },
      "6-27": { title: "روز شعر و ادب فارسی (بزرگداشت شهریار)", holiday: false },
      "6-31": { title: "آغاز هفته دفاع مقدس", holiday: false },
      "7-1": { title: "آغاز سال تحصیلی / روز بزرگداشت مولوی", holiday: false },
      "7-7": { title: "روز آتش‌نشانی و ایمنی", holiday: false },
      "7-8": { title: "روز بزرگداشت مولوی", holiday: false },
      "7-20": { title: "روز بزرگداشت حافظ", holiday: false },
      "7-26": { title: "روز تربیت بدنی و ورزش", holiday: false },
      "8-8": { title: "روز نوجوان و پدافند غیرعامل", holiday: false },
      "8-13": { title: "روز دانش‌آموز / روز مبارزه با استکبار", holiday: false },
      "8-24": { title: "روز کتاب و کتابخوانی", holiday: false },
      "9-7": { title: "روز نیروی دریایی", holiday: false },
      "9-16": { title: "روز دانشجو", holiday: false },
      "9-25": { title: "روز پژوهش", holiday: false },
      "9-30": { title: "شب یلدا", holiday: false },
      "10-5": { title: "روز کاهش بلایای طبیعی (زلزله بم)", holiday: false },
      "10-20": { title: "سالروز شهادت امیرکبیر", holiday: false },
      "11-12": { title: "بازگشت امام خمینی (ره) و آغاز دهه فجر", holiday: false },
      "11-22": { title: "پیروزی انقلاب اسلامی", holiday: true },
      "11-29": { title: "سپندارمذگان (روز عشق ایرانی)", holiday: false },
      "12-5": { title: "روز مهندس (بزرگداشت خواجه نصیرالدین طوسی)", holiday: false },
      "12-15": { title: "روز درختکاری", holiday: false },
      "12-25": { title: "روز بزرگداشت پروین اعتصامی و پایان سرایش شاهنامه", holiday: false },
      "12-29": { title: "روز ملی شدن صنعت نفت ایران", holiday: true }
    };

    // Gregorian (میلادی) Events
    this.gregorianEvents = {
      "1-1": { title: "آغاز سال نو میلادی", holiday: false },
      "1-24": { title: "روز جهانی آموزش", holiday: false },
      "2-4": { title: "روز جهانی سرطان", holiday: false },
      "2-14": { title: "روز ولنتاین (عشاق)", holiday: false },
      "2-21": { title: "روز جهانی زبان مادری", holiday: false },
      "3-8": { title: "روز جهانی زن", holiday: false },
      "3-20": { title: "روز جهانی شادی", holiday: false },
      "3-21": { title: "روز جهانی جنگل‌ها / نوروز سازمان ملل", holiday: false },
      "3-22": { title: "روز جهانی آب", holiday: false },
      "3-23": { title: "روز جهانی هواشناسی", holiday: false },
      "4-7": { title: "روز جهانی بهداشت", holiday: false },
      "4-22": { title: "روز زمین پاک", holiday: false },
      "5-1": { title: "روز جهانی کار و کارگر", holiday: false },
      "5-8": { title: "روز جهانی صلیب سرخ و هلال احمر", holiday: false },
      "5-15": { title: "روز جهانی خانواده", holiday: false },
      "5-17": { title: "روز جهانی ارتباطات", holiday: false },
      "5-31": { title: "روز جهانی بدون دخانیات", holiday: false },
      "6-1": { title: "روز جهانی کودکان", holiday: false },
      "6-5": { title: "روز جهانی محیط زیست", holiday: false },
      "6-21": { title: "روز جهانی یوگا", holiday: false },
      "7-11": { title: "روز جهانی جمعیت", holiday: false },
      "8-12": { title: "روز جهانی جوانان", holiday: false },
      "8-19": { title: "روز جهانی عکاسی", holiday: false },
      "9-8": { title: "روز جهانی سوادآموزی", holiday: false },
      "9-21": { title: "روز جهانی صلح", holiday: false },
      "9-27": { title: "روز جهانی جهانگردی", holiday: false },
      "10-1": { title: "روز جهانی سالمندان / روز جهانی موسیقی", holiday: false },
      "10-5": { title: "روز جهانی معلم", holiday: false },
      "10-10": { title: "روز جهانی سلامت روان", holiday: false },
      "10-16": { title: "روز جهانی غذا", holiday: false },
      "10-24": { title: "روز سازمان ملل متحد", holiday: false },
      "10-31": { title: "جشن هالووین", holiday: false },
      "11-14": { title: "روز جهانی دیابت", holiday: false },
      "11-20": { title: "روز جهانی کودک", holiday: false },
      "12-1": { title: "روز جهانی ایدز", holiday: false },
      "12-3": { title: "روز جهانی معلولان", holiday: false },
      "12-10": { title: "روز جهانی حقوق بشر", holiday: false },
      "12-25": { title: "میلاد حضرت عیسی مسیح (ع) / کریسمس", holiday: false },
      "12-31": { title: "شب سال نو میلادی", holiday: false }
    };

    // Hijri (قمری) Events
    this.hijriEvents = {
      "1-1": { title: "آغاز سال نو هجری قمری", holiday: false },
      "1-9": { title: "تاسوعای حسینی", holiday: true },
      "1-10": { title: "عاشورای حسینی", holiday: true },
      "2-20": { title: "اربعین حسینی", holiday: true },
      "2-28": { title: "رحلت پیامبر اکرم (ص) و شهادت امام حسن (ع)", holiday: true },
      "2-29": { title: "شهادت امام رضا (ع)", holiday: true },
      "3-1": { title: "هجرت پیامبر (ص) از مکه به مدینه", holiday: false },
      "3-8": { title: "شهادت امام حسن عسکری (ع)", holiday: true },
      "3-17": { title: "میلاد پیامبر اکرم (ص) و امام صادق (ع)", holiday: true },
      "5-5": { title: "میلاد حضرت زینب (س) و روز پرستار", holiday: false },
      "6-3": { title: "شهادت حضرت فاطمه زهرا (س)", holiday: true },
      "6-20": { title: "میلاد حضرت فاطمه (س) و روز مادر", holiday: false },
      "7-13": { title: "میلاد حضرت علی (ع) و روز پدر", holiday: true },
      "7-27": { title: "مبعث حضرت رسول اکرم (ص)", holiday: true },
      "8-3": { title: "میلاد امام حسین (ع) و روز پاسدار", holiday: false },
      "8-4": { title: "میلاد حضرت ابوالفضل (ع) و روز جانباز", holiday: false },
      "8-15": { title: "نیمه شعبان - میلاد حضرت مهدی (عج)", holiday: true },
      "9-15": { title: "میلاد امام حسن مجتبی (ع)", holiday: false },
      "9-21": { title: "شهادت حضرت علی (ع)", holiday: true },
      "10-1": { title: "عید سعید فطر", holiday: true },
      "10-2": { title: "تعطیل عید فطر", holiday: true },
      "10-25": { title: "شهادت امام جعفر صادق (ع)", holiday: true },
      "11-1": { title: "میلاد حضرت معصومه (س) و روز دختران", holiday: false },
      "11-11": { title: "میلاد امام رضا (ع)", holiday: false },
      "12-9": { title: "روز عرفه", holiday: false },
      "12-10": { title: "عید سعید قربان", holiday: true },
      "12-18": { title: "عید سعید غدیر خم", holiday: true }
    };
  }

  /**
   * Converts Gregorian date to Jalali (Persian) date
   * @param {number} gy Gregorian Year
   * @param {number} gm Gregorian Month (1-12)
   * @param {number} gd Gregorian Day (1-31)
   * @returns {Object} { jy, jm, jd }
   */
  gregorianToJalali(gy, gm, gd) {
    const g_d_m = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
    let gy2 = (gm > 2) ? (gy + 1) : gy;
    let days = 355666 + (365 * gy) + Math.floor((gy2 + 3) / 4) - Math.floor((gy2 + 99) / 100) + Math.floor((gy2 + 399) / 400) + gd + g_d_m[gm - 1];
    let jy = -1595 + (33 * Math.floor(days / 12053));
    days %= 12053;
    jy += 4 * Math.floor(days / 1461);
    days %= 1461;
    if (days > 365) {
      jy += Math.floor((days - 1) / 365);
      days = (days - 1) % 365;
    }
    let jm = (days < 186) ? 1 + Math.floor(days / 31) : 7 + Math.floor((days - 186) / 30);
    let jd = (days < 186) ? 1 + (days % 31) : 1 + ((days - 186) % 30);
    return { jy, jm, jd };
  }

  /**
   * Converts Jalali (Persian) date to Gregorian date
   * @param {number} jy Jalali Year
   * @param {number} jm Jalali Month (1-12)
   * @param {number} jd Jalali Day (1-31)
   * @returns {Object} { gy, gm, gd }
   */
  jalaliToGregorian(jy, jm, jd) {
    jy += 1595;
    let days = -355668 + (365 * jy) + (Math.floor(jy / 33) * 8) + Math.floor(((jy % 33) + 3) / 4) + jd + ((jm < 7) ? ((jm - 1) * 31) : (((jm - 7) * 30) + 186));
    let gy = 400 * Math.floor(days / 146097);
    days %= 146097;
    if (days > 36524) {
      days--;
      gy += 100 * Math.floor(days / 36524);
      days %= 36524;
      if (days >= 365) days++;
    }
    gy += 4 * Math.floor(days / 1461);
    days %= 1461;
    if (days > 365) {
      gy += Math.floor((days - 1) / 365);
      days = (days - 1) % 365;
    }
    let gd = days + 1;
    const sal_a = [0, 31, ((gy % 4 === 0 && gy % 100 !== 0) || (gy % 400 === 0)) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    let gm = 0;
    for (gm = 0; gm < 13 && gd > sal_a[gm]; gm++) {
      gd -= sal_a[gm];
    }
    return { gy, gm, gd };
  }

  /**
   * Accurate Gregorian to Hijri conversion using Intl Umm al-Qura standard with offset support
   * @param {number} gy Gregorian Year
   * @param {number} gm Gregorian Month (1-12)
   * @param {number} gd Gregorian Day (1-31)
   * @param {number|null} customOffset Optional day adjustment
   * @returns {Object} { hy, hm, hd }
   */
  gregorianToHijri(gy, gm, gd, customOffset = null) {
    const offset = (customOffset !== null && customOffset !== undefined)
      ? customOffset
      : (typeof window !== 'undefined' && window.settingsManager && window.settingsManager.settings && window.settingsManager.settings.hijriOffset !== undefined
          ? parseInt(window.settingsManager.settings.hijriOffset, 10) || 0
          : 0);

    const date = new Date(gy, gm - 1, gd);
    if (offset !== 0) {
      date.setDate(date.getDate() + offset);
    }

    // 1. Modern browser / Android WebView high-precision Intl Umm al-Qura engine
    try {
      const formatter = new Intl.DateTimeFormat('en-u-ca-islamic-umalqura', {
        year: 'numeric',
        month: 'numeric',
        day: 'numeric'
      });
      const parts = formatter.formatToParts(date);
      let hy, hm, hd;
      for (const p of parts) {
        if (p.type === 'year') hy = parseInt(p.value.replace(/\D/g, ''), 10);
        if (p.type === 'month') hm = parseInt(p.value, 10);
        if (p.type === 'day') hd = parseInt(p.value, 10);
      }
      if (hy && hm && hd) {
        return { hy, hm, hd };
      }
    } catch (e) {
      // Continue to fallback
    }

    // 2. Tabular Islamic fallback
    const jd = Math.floor((date.getTime() / 86400000) + 2440587.5);
    let l = jd - 1948440 + 10632;
    const n = Math.floor((l - 1) / 10631);
    l = l - 10631 * n + 354;
    const j = (Math.floor((10985 - l) / 5316)) * (Math.floor((50 * l) / 17719)) + (Math.floor(l / 5670)) * (Math.floor((43 * l) / 15238));
    l = l - (Math.floor((30 - j) / 15)) * (Math.floor((17719 * j) / 50)) - (Math.floor(j / 16)) * (Math.floor((15238 * j) / 43)) + 29;
    const hm = Math.floor((24 * l) / 709);
    const hd = l - Math.floor((709 * hm) / 24);
    const hy = 30 * n + j - 30;
    return { hy, hm, hd };
  }

  /**
   * Converts Hijri date to Gregorian date accurately
   * @param {number} hy Hijri Year
   * @param {number} hm Hijri Month (1-12)
   * @param {number} hd Hijri Day (1-30)
   * @param {number|null} customOffset
   * @returns {Object} { gy, gm, gd }
   */
  hijriToGregorian(hy, hm, hd, customOffset = null) {
    const offset = (customOffset !== null && customOffset !== undefined)
      ? customOffset
      : (typeof window !== 'undefined' && window.settingsManager && window.settingsManager.settings && window.settingsManager.settings.hijriOffset !== undefined
          ? parseInt(window.settingsManager.settings.hijriOffset, 10) || 0
          : 0);

    const approxJd = Math.floor((11 * hy + 3) / 30) + 354 * hy + 30 * hm - Math.floor((hm - 1) / 2) + hd + 1948440 - 385;
    let l = approxJd + 68569;
    let n = Math.floor((4 * l) / 146097);
    l = l - Math.floor((146097 * n + 3) / 4);
    let i = Math.floor((4000 * (l + 1)) / 1461001);
    l = l - Math.floor((1461 * i) / 4) + 31;
    let j = Math.floor((80 * l) / 2447);
    let gd = l - Math.floor((2447 * j) / 80);
    l = Math.floor(j / 11);
    let gm = j + 2 - 12 * l;
    let gy = 100 * (n - 49) + i + l;

    const baseDate = new Date(gy, gm - 1, gd);
    for (let delta = -5; delta <= 5; delta++) {
      const testDate = new Date(baseDate.getTime() + delta * 86400000);
      const h = this.gregorianToHijri(testDate.getFullYear(), testDate.getMonth() + 1, testDate.getDate(), offset);
      if (h.hy === hy && h.hm === hm && h.hd === hd) {
        return { gy: testDate.getFullYear(), gm: testDate.getMonth() + 1, gd: testDate.getDate() };
      }
    }
    return { gy, gm, gd };
  }

  /**
   * Checks if a Jalali year is leap year
   * @param {number} jy
   * @returns {boolean}
   */
  isJalaliLeapYear(jy) {
    const breaks = [-61, 9, 38, 199, 426, 686, 756, 818, 1111, 1181, 1210, 1635, 2060, 2097, 2192, 2262, 2324, 2394, 2456, 3178];
    const bl = breaks.length;
    let jp = breaks[0];
    let jm = 0;
    let jump = 0;
    if (jy < jp || jy >= breaks[bl - 1]) return false;
    for (let i = 1; i < bl; i++) {
      jm = breaks[i];
      jump = jm - jp;
      if (jy < jm) break;
      jp = jm;
    }
    let N = jy - jp;
    if (jump - N < 6) N = N - jump + Math.floor((jump + 4) / 33) * 33;
    let leap = (N + 1) % 33;
    if (leap < 0) leap += 33;
    return [1, 5, 9, 13, 17, 22, 26, 30].indexOf(leap) !== -1;
  }

  /**
   * Gets number of days in a Jalali month
   * @param {number} jy
   * @param {number} jm
   * @returns {number}
   */
  getJalaliMonthDays(jy, jm) {
    if (jm <= 6) return 31;
    if (jm <= 11) return 30;
    return this.isJalaliLeapYear(jy) ? 30 : 29;
  }

  /**
   * Gets the day of week index for 1st day of a Jalali month
   * 0 = Saturday, 1 = Sunday, ..., 6 = Friday
   * @param {number} jy
   * @param {number} jm
   * @returns {number}
   */
  getJalaliFirstDayOfWeek(jy, jm) {
    const g = this.jalaliToGregorian(jy, jm, 1);
    const date = new Date(g.gy, g.gm - 1, g.gd);
    // JS getDay(): 0 = Sun, 1 = Mon, ..., 6 = Sat
    // Convert to 0 = Sat, 1 = Sun, 2 = Mon, ..., 6 = Fri
    const jsDay = date.getDay();
    return (jsDay + 1) % 7;
  }

  /**
   * Calculates Jalali Day of Year (1-365 or 366)
   * @param {number} jy
   * @param {number} jm
   * @param {number} jd
   * @returns {number}
   */
  getJalaliDayOfYear(jy, jm, jd) {
    let dayOfYear = 0;
    for (let m = 1; m < jm; m++) {
      dayOfYear += this.getJalaliMonthDays(jy, m);
    }
    dayOfYear += jd;
    return dayOfYear;
  }

  /**
   * Gets total days in a Jalali year (365 or 366)
   * @param {number} jy
   * @returns {number}
   */
  getJalaliYearDays(jy) {
    return this.isJalaliLeapYear(jy) ? 366 : 365;
  }

  /**
   * Calculates Iranian Persian Week Number (1-53) starting Farvardin 1
   * @param {number} jy
   * @param {number} jm
   * @param {number} jd
   * @returns {number}
   */
  getJalaliWeekNumber(jy, jm, jd) {
    const dayOfYear = this.getJalaliDayOfYear(jy, jm, jd);
    const firstDayOfWeek = this.getJalaliFirstDayOfWeek(jy, 1);
    return Math.ceil((dayOfYear + firstDayOfWeek) / 7);
  }

  /**
   * Gets event information for a date combining Jalali, Gregorian, and Hijri events
   * @param {number} jm Jalali Month
   * @param {number} jd Jalali Day
   * @param {number|null} jy Jalali Year
   * @param {number|null} gm Gregorian Month
   * @param {number|null} gd Gregorian Day
   * @param {number|null} hm Hijri Month
   * @param {number|null} hd Hijri Day
   * @returns {Object|null} { title, holiday }
   */
  getEventForDate(jm, jd, jy = null, gm = null, gd = null, hm = null, hd = null) {
    if (!jy) jy = 1405; // Default current year fallback
    
    if (!gm || !gd) {
      const g = this.jalaliToGregorian(jy, jm, jd);
      gm = g.gm;
      gd = g.gd;
      const h = this.gregorianToHijri(g.gy, g.gm, g.gd);
      hm = h.hm;
      hd = h.hd;
    } else if (!hm || !hd) {
      const g = this.jalaliToGregorian(jy, jm, jd);
      const h = this.gregorianToHijri(g.gy, gm, gd);
      hm = h.hm;
      hd = h.hd;
    }

    const matchedTitles = [];
    let isHoliday = false;

    // 1. Jalali Events
    const jKey = `${jm}-${jd}`;
    if (this.events && this.events[jKey]) {
      const ev = this.events[jKey];
      matchedTitles.push(ev.title);
      if (ev.holiday) isHoliday = true;
    }

    // 2. Gregorian Events
    const gKey = `${gm}-${gd}`;
    if (this.gregorianEvents && this.gregorianEvents[gKey]) {
      const ev = this.gregorianEvents[gKey];
      matchedTitles.push(ev.title);
      if (ev.holiday) isHoliday = true;
    }

    // 3. Hijri Events
    const hKey = `${hm}-${hd}`;
    if (this.hijriEvents && this.hijriEvents[hKey]) {
      const ev = this.hijriEvents[hKey];
      matchedTitles.push(ev.title);
      if (ev.holiday) isHoliday = true;
    }

    if (matchedTitles.length === 0) return null;

    return {
      title: matchedTitles.join(' | '),
      holiday: isHoliday
    };
  }

  /**
   * Formats numbers to Persian Digits
   * @param {number|string} num
   * @returns {string}
   */
  toPersianDigits(num) {
    const persianDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
    return String(num).replace(/\d/g, (x) => persianDigits[parseInt(x, 10)]);
  }

  /**
   * Converts Persian and Arabic digits to English digits
   * @param {number|string} str
   * @returns {string}
   */
  toEnglishDigits(str) {
    if (str === null || str === undefined) return '';
    const persianDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
    const arabicDigits = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
    let result = String(str);
    for (let i = 0; i < 10; i++) {
      result = result.replace(new RegExp(persianDigits[i], 'g'), String(i));
      result = result.replace(new RegExp(arabicDigits[i], 'g'), String(i));
    }
    return result;
  }
}

// Global instance
window.calendarEngine = new CalendarEngine();
