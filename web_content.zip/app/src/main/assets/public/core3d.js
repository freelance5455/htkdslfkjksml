// ============================================================
// ULTRON OS — CORE VISUAL COMPONENT
// Noyau central animé (SVG), utilisé sur le dashboard.
// ============================================================
ULTRON.Core = (function(){

  function svg(pulseLevel){
    // pulseLevel: 'idle' | 'active' | 'alert'
    return `
    <svg viewBox="0 0 300 300" class="ucore-svg">
      <defs>
        <radialGradient id="coreGlow" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stop-color="#ff6a55" stop-opacity="0.9"/>
          <stop offset="45%" stop-color="#ff2a1f" stop-opacity="0.35"/>
          <stop offset="100%" stop-color="#ff2a1f" stop-opacity="0"/>
        </radialGradient>
      </defs>
      <circle cx="150" cy="150" r="120" fill="url(#coreGlow)" class="ucore-glow"/>
      <g class="ucore-ring ucore-ring-outer">
        <circle cx="150" cy="150" r="128" fill="none" stroke="var(--red-dim)" stroke-width="1"/>
        <g class="ucore-ticks-outer"></g>
      </g>
      <g class="ucore-ring ucore-ring-mid">
        <circle cx="150" cy="150" r="102" fill="none" stroke="var(--red)" stroke-width="1.4" stroke-dasharray="10 8" opacity="0.85"/>
      </g>
      <g class="ucore-ring ucore-ring-inner">
        <circle cx="150" cy="150" r="80" fill="none" stroke="var(--red-bright)" stroke-width="1" stroke-dasharray="2 5" opacity="0.7"/>
      </g>
      <g class="ucore-ring ucore-ring-hex">
        <polygon points="150,84 202,117 202,183 150,216 98,183 98,117"
          fill="none" stroke="var(--red)" stroke-width="1" opacity="0.5"/>
      </g>
      <circle cx="150" cy="150" r="46" fill="#1a0806" stroke="var(--red-bright)" stroke-width="1.5" class="ucore-nucleus"/>
      <circle cx="150" cy="150" r="20" fill="var(--red-bright)" class="ucore-eye"/>
      <circle cx="150" cy="150" r="20" fill="none" stroke="var(--red-bright)" stroke-width="8" opacity="0.25" class="ucore-eye-pulse"/>
    </svg>`;
  }

  function styleBlock(){
    return `
    <style>
      .ucore-wrap{position:relative; width:100%; max-width:280px; aspect-ratio:1/1; margin:0 auto;}
      .ucore-svg{width:100%; height:100%; overflow:visible;}
      .ucore-glow{animation:coreGlowPulse 3.2s ease-in-out infinite;}
      @keyframes coreGlowPulse{0%,100%{opacity:0.6;}50%{opacity:1;}}
      .ucore-ring-outer{transform-origin:150px 150px; animation:coreSpin 40s linear infinite;}
      .ucore-ring-mid{transform-origin:150px 150px; animation:coreSpin 22s linear infinite reverse;}
      .ucore-ring-inner{transform-origin:150px 150px; animation:coreSpin 14s linear infinite;}
      .ucore-ring-hex{transform-origin:150px 150px; animation:coreSpin 60s linear infinite reverse;}
      @keyframes coreSpin{from{transform:rotate(0deg);}to{transform:rotate(360deg);}}
      .ucore-nucleus{filter:drop-shadow(0 0 12px rgba(255,42,31,0.5));}
      .ucore-eye{filter:drop-shadow(0 0 10px var(--red-bright)) drop-shadow(0 0 22px rgba(255,42,31,0.7)); animation:eyePulse 2.6s ease-in-out infinite;}
      @keyframes eyePulse{0%,100%{opacity:0.85; r:19;}50%{opacity:1; r:21;}}
      .ucore-eye-pulse{animation:eyeRing 2.6s ease-in-out infinite;}
      @keyframes eyeRing{0%{r:20; opacity:0.3;}100%{r:38; opacity:0;}}
      .ucore-wrap.alert .ucore-ring-outer{animation-duration:12s;}
      .ucore-wrap.alert .ucore-ring-mid{animation-duration:7s;}
      .ucore-wrap.alert .ucore-eye{animation-duration:1s;}
      .ucore-wrap.alert .ucore-eye-pulse{animation-duration:1s;}
      .ucore-tick{stroke:var(--red-dim); stroke-width:1;}

      .ucore-data{
        position:absolute; font-family:var(--font-mono); font-size:9px; color:var(--red);
        letter-spacing:0.08em; opacity:0.75; white-space:nowrap;
      }
    </style>`;
  }

  function ticksMarkup(n, r){
    let out = '';
    for(let i=0;i<n;i++){
      const a = (i/n) * Math.PI * 2;
      const x1 = 150 + Math.cos(a)*r, y1 = 150 + Math.sin(a)*r;
      const x2 = 150 + Math.cos(a)*(r-8), y2 = 150 + Math.sin(a)*(r-8);
      out += `<line class="ucore-tick" x1="${x1.toFixed(1)}" y1="${y1.toFixed(1)}" x2="${x2.toFixed(1)}" y2="${y2.toFixed(1)}"/>`;
    }
    return out;
  }

  // Renders the core into a container element, returns a controller
  function mount(container, opts){
    opts = opts || {};
    container.innerHTML = styleBlock() + `<div class="ucore-wrap" id="ucore-wrap">${svg()}</div>`;
    const wrap = container.querySelector('#ucore-wrap');
    const ticksHost = wrap.querySelector('.ucore-ticks-outer');
    if(ticksHost) ticksHost.innerHTML = ticksMarkup(48, 128);

    function setState(state){
      wrap.classList.remove('alert');
      if(state === 'alert') wrap.classList.add('alert');
    }
    return { el: wrap, setState };
  }

  return { mount };
})();
