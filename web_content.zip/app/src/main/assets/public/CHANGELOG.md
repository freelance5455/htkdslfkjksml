# ULTRON OS — améliorations

## v2.2 — IA interne (assistant en langage naturel)
- **Nouvel assistant IA** (`assistant.js`) qui comprend des phrases en français et **exécute réellement** l'action demandée dans l'app — ce n'est pas un chatbot décoratif, il pilote les vraies fonctions de navigation/multitâche.
- Commandes comprises : ouvrir/fermer une application (« ouvre les marchés », « ferme intel »), retour à l'accueil, afficher les applications ouvertes, activer/choisir la vue partagée (« divise l'écran avec defense »), statut système, heure, recherche dans les renseignements, redémarrage.
- **Écran AI CORE transformé en vrai chat** : zone de conversation, suggestions rapides, historique conservé pendant la session.
- **Intégration vocale réelle** : la reconnaissance vocale déjà présente (`voice.js`) transmet maintenant toute phrase reconnue (au-delà de la phrase de réveil) à l'IA, qui l'exécute et répond par une notification — on peut littéralement dire « ouvre le terminal » à voix haute.
- Nouvelle commande terminal `ask [phrase]` pour interroger l'IA sans changer d'écran.

## v2.1 — gestion d'applications (multitâche) & vue partagée
- **Vraie gestion multitâche** : chaque module ouvert (WORLD, MARKETS, INTEL, DEFENSE...) est désormais suivi comme une application "en cours d'exécution", avec premier plan / arrière-plan, comme un vrai OS.
- **Sélecteur d'applications** (façon "recent apps") accessible via le bouton `APPS` dans la barre système ou le raccourci `Alt+A` : cartes des apps ouvertes, fermeture individuelle par ✕, retour à une app en un tap.
- Le compteur d'applications ouvertes est visible en permanence dans la barre système.
- **Terminal enrichi avec de vraies commandes de gestion d'applications** : `apps` (liste ouvertes/disponibles), `open [nom]`, `close [nom]` / `kill [nom]`, `switch` (ouvre le sélecteur).
- `ps` et `top` reflètent désormais les vraies applications ouvertes dans l'interface (PID simulé, statut foreground/background), en plus des services système simulés.
- Un redémarrage (`reboot`) ferme proprement toutes les applications ouvertes, comme un vrai reboot.
- **Vue partagée (fenêtrage réel)** : bouton `SPLIT` dans la barre système (ou `Alt+S`, ou commande terminal `split [app]`) pour afficher un second module en volet inférieur, avec sélecteur de chips.
- **Persistance de session** : les applications ouvertes et l'état de la vue partagée survivent à une relance de l'app (localStorage), comme un vrai OS qui restaure ses tâches en arrière-plan.

## v2.0 — démarrage réaliste & shell complet
- **Boot séquence en 3 phases**, façon vrai PC Linux : écran firmware/POST → menu **GRUB** → journal noyau (dmesg) avec vrais messages `Linux version`, `systemd`, montages, `fsck`, cibles systemd, jusqu'au prompt de login.
- Les lignes de log affichent désormais un badge `OK` uniquement sur les évènements qui en ont vraiment un (Started/Mounted/Reached...), comme un vrai `dmesg`.
- **Terminal transformé en mini-shell Unix fonctionnel** : système de fichiers virtuel navigable (`/root`, `/core`, `/data`, `/archives`, `/etc`, `/var/log`), avec `ls -l`, `cd`, `pwd`, `cat`, `mkdir`, `touch`, `rm`.
- Nouvelles commandes système : `uname -a`, `uptime`, `whoami`, `hostname`, `date`, `ps`, `top`, `df -h`, `free -h`, `neofetch`, `history`, `man [commande]`, `sudo`, `reboot` (rejoue le vrai boot), `shutdown`.
- Historique de commandes navigable (flèches haut/bas) et complétion partielle (Tab).
- Prompt dynamique affichant le répertoire courant (`root@ultron-core:~$`).
- **Interface réorganisée** : nouvelle barre système persistante en haut de l'écran (horloge en temps réel + statut réseau), menu "MORE" désormais groupé par catégories (Renseignement / Sécurité / Système) au lieu d'une liste plate.
- Correction du double espacement lié à l'encoche (`safe-area`) suite à l'ajout de la barre système.

## v1.1
- Persistance des réglages via `localStorage`.
- Raccourcis clavier `Alt+1` à `Alt+5` pour les vues principales.
- `Échap` ferme le menu MORE.
- Mode basse consommation qui désactive les effets ambiants lourds.
- Nettoyage des timers d'effets ambiants avant redémarrage.
- Meilleure ergonomie tactile avec zones de clic minimales.
- Support du `prefers-reduced-motion` déjà présent, conservé.
- Métadonnées HTML améliorées (`description`, `color-scheme`).
- Vérification syntaxique des 7 fichiers JavaScript : OK.

> Les données du projet restent simulées ; aucune connexion réseau réelle n'a été ajoutée.

## Correctif — informations des points
- Restauration des fiches détaillées des points du globe.
- Chaque point affiche désormais type, description, coordonnées, région, statut et importance.
- Conservation des frontières pays + continents intégrées localement.
- Conservation du zoom automatique au clic sur un point et retour au zoom initial à la fermeture de la fiche.
- Validation syntaxique des fichiers JavaScript.

## Voice activation
- Added voice wake phrase: “ULTRON initialisation”.
- Added Web Speech API listener when the web app is open and microphone permission is granted.
- Added `?ultron=initialisation` URL trigger for Siri/Google Assistant shortcuts.
- Added small VOICE status indicator.
