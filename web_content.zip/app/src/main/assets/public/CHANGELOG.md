# ULTRON OS — améliorations

## v1.1
- Persistance des réglages via `localStorage`.
- Raccourcis clavier `Alt+1` à `Alt+5` pour les vues principales.
- `Échap` ferme le menu MORE.
- Mode basse consommation qui désactive les effets ambiants lourds.
- Nettoyage des timers d'effets ambiants avant redémarrage.
- Meilleure ergonomie tactile avec zones de clic minimales.
- Support du `prefers-reduced-motion` déjà présent, conservé.
- Métadonnées HTML améliorées (`description`, `color-scheme`).
- Vérification syntaxique des 7 fichiers JavaScript : OK.

> Les données du projet restent simulées ; aucune connexion réseau réelle n'a été ajoutée.

## Correctif — informations des points
- Restauration des fiches détaillées des points du globe.
- Chaque point affiche désormais type, description, coordonnées, région, statut et importance.
- Conservation des frontières pays + continents intégrées localement.
- Conservation du zoom automatique au clic sur un point et retour au zoom initial à la fermeture de la fiche.
- Validation syntaxique des fichiers JavaScript.

## Voice activation
- Added voice wake phrase: “ULTRON initialisation”.
- Added Web Speech API listener when the web app is open and microphone permission is granted.
- Added `?ultron=initialisation` URL trigger for Siri/Google Assistant shortcuts.
- Added small VOICE status indicator.
