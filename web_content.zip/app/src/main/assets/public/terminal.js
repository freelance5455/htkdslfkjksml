// ============================================================
// ULTRON OS — TERMINAL
// ============================================================
ULTRON.Terminal = (function(){
  const D = ULTRON.DATA;
  let outputEl, inputEl;

  const HELP_TEXT = [
    'COMMANDES DISPONIBLES:',
    '  help              — afficher cette liste',
    '  status            — état général du système',
    '  markets           — résumé des marchés',
    '  world             — ouvrir WORLD VIEW',
    '  intel             — dernières informations',
    '  defense           — ouvrir DEFENSE WATCH',
    '  conflict          — ouvrir CONFLICT MONITOR',
    '  core              — état du noyau ULTRON',
    '  search [terme]    — rechercher dans les données',
    '  clear             — effacer l\'écran',
  ];

  const QUICK_CMDS = ['status','markets','world','intel','defense','core','clear'];

  function print(lines, cls){
    if(typeof lines === 'string') lines = [lines];
    lines.forEach(l=>{
      const line = document.createElement('div');
      line.className = 'term-line' + (cls ? ' '+cls : '');
      line.textContent = l;
      outputEl.appendChild(line);
    });
    outputEl.scrollTop = outputEl.scrollHeight;
  }

  function printCmdEcho(cmd){
    const line = document.createElement('div');
    line.className = 'term-line term-echo';
    line.innerHTML = `<span class="term-prompt">ULTRON@OS:~$</span> ${escapeHtml(cmd)}`;
    outputEl.appendChild(line);
    outputEl.scrollTop = outputEl.scrollHeight;
  }

  function escapeHtml(s){
    const d = document.createElement('div');
    d.textContent = s;
    return d.innerHTML;
  }

  function handleCommand(raw){
    const cmd = raw.trim();
    if(!cmd) return;
    printCmdEcho(cmd);
    const [base, ...rest] = cmd.toLowerCase().split(' ');
    const arg = rest.join(' ');

    switch(base){
      case 'help':
        print(HELP_TEXT);
        break;
      case 'status': {
        const m = D.getMarketsSnapshot();
        print([
          'SYSTEM STATUS: ONLINE',
          'CORE: OPERATIONAL',
          'DATA STREAM: ACTIVE',
          `GLOBAL MARKET STATUS: ${m.status}`,
          `TIMESTAMP: ${D.fmtDateTime(new Date())}`,
        ], 'term-ok');
        break;
      }
      case 'markets': {
        const m = D.getMarketsSnapshot();
        print([`MARKETS — ${m.upCount} en hausse / ${m.downCount} en baisse — STATUT: ${m.status}`]);
        m.indices.slice(0,5).forEach(i=>{
          print(`  ${i.name.padEnd(14)} ${i.value.toFixed(2).padStart(10)}  ${i.up?'▲':'▼'}${Math.abs(i.change).toFixed(2)}%`);
        });
        print('Tapez "markets" via le module MARKETS pour la vue complète.', 'term-dim');
        setTimeout(()=>ULTRON.App.navigate('markets'), 600);
        break;
      }
      case 'world':
        print('OUVERTURE DE WORLD VIEW...', 'term-ok');
        setTimeout(()=>ULTRON.App.navigate('world'), 400);
        break;
      case 'intel': {
        const feed = D.getIntelFeed().slice(0,5);
        print('DERNIÈRES INFORMATIONS:');
        feed.forEach(f=> print(`  [${f.priority}] ${f.title} — ${f.region}`));
        setTimeout(()=>ULTRON.App.navigate('intel'), 600);
        break;
      }
      case 'defense':
        print('OUVERTURE DE DEFENSE WATCH...', 'term-ok');
        setTimeout(()=>ULTRON.App.navigate('defense'), 400);
        break;
      case 'conflict':
        print('OUVERTURE DE CONFLICT MONITOR...', 'term-ok');
        setTimeout(()=>ULTRON.App.navigate('conflict'), 400);
        break;
      case 'core':
        print([
          'ULTRON CORE STATUS',
          '  INTEGRITY: 100%',
          '  SYNC: STABLE',
          '  ACTIVE FEEDS: 4',
          '  ROTATION: NOMINAL',
        ], 'term-ok');
        break;
      case 'search': {
        if(!arg){ print('Usage: search [terme]', 'term-err'); break; }
        const feed = D.getIntelFeed();
        const results = feed.filter(f =>
          f.title.toLowerCase().includes(arg) ||
          f.region.toLowerCase().includes(arg) ||
          f.cat.toLowerCase().includes(arg) ||
          f.summary.toLowerCase().includes(arg)
        );
        if(!results.length){
          print(`Aucun résultat pour "${arg}".`, 'term-dim');
        } else {
          print(`${results.length} résultat(s) pour "${arg}":`);
          results.forEach(r=> print(`  [${r.region}] ${r.title}`));
        }
        break;
      }
      case 'clear':
        outputEl.innerHTML = '';
        break;
      default:
        print(`COMMANDE INCONNUE: "${base}" — tapez "help" pour la liste des commandes.`, 'term-err');
    }
  }

  function renderInto(host){
    host.innerHTML = `
      <style>
        .term-wrap{display:flex; flex-direction:column; height:100%; background:#050202;}
        .term-output{
          flex:1; overflow-y:auto; padding:14px 16px; font-family:var(--font-mono); font-size:12.5px;
          line-height:1.7;
        }
        .term-line{color:var(--white); white-space:pre-wrap; word-break:break-word;}
        .term-line.term-ok{color:var(--green);}
        .term-line.term-err{color:var(--red-bright);}
        .term-line.term-dim{color:var(--grey-dim);}
        .term-line.term-echo{color:var(--red-bright); margin-top:8px;}
        .term-prompt{color:var(--red); margin-right:4px;}
        .term-quickrow{
          display:flex; gap:6px; padding:8px 12px; overflow-x:auto; border-top:1px solid var(--line);
          background:var(--bg-panel);
        }
        .term-quick-btn{
          flex-shrink:0; background:var(--bg-panel-2); border:1px solid var(--line); color:var(--grey);
          font-family:var(--font-mono); font-size:10px; padding:8px 12px;
        }
        .term-quick-btn:active{border-color:var(--red);}
        .term-inputrow{
          display:flex; align-items:center; gap:8px; padding:12px 16px calc(12px + var(--safe-bottom));
          border-top:1px solid var(--line-strong); background:var(--bg-panel);
        }
        .term-inputrow .term-prompt{font-family:var(--font-mono); font-size:12px; flex-shrink:0;}
        .term-input{
          flex:1; background:none; border:none; color:var(--white); font-family:var(--font-mono);
          font-size:13px; outline:none; caret-color:var(--red-bright);
        }
        .term-send{
          background:var(--red-deep); border:1px solid var(--line-strong); color:var(--red-bright);
          font-family:var(--font-mono); font-size:11px; padding:8px 14px; flex-shrink:0;
        }
      </style>
      <div class="term-wrap">
        ${(function(){
          const t = document.createElement('div');
          return '';
        })()}
        <div class="topbar">
          <div class="topbar-title">
            <span class="tb-name disp">TERMINAL</span>
            <span class="tb-sub mono">ULTRON COMMAND TERMINAL</span>
          </div>
          <div class="tb-status"><span class="tb-dot"></span><span class="mono">READY</span></div>
        </div>
        <div class="term-output" id="term-output"></div>
        <div class="term-quickrow" id="term-quickrow"></div>
        <div class="term-inputrow">
          <span class="term-prompt">ULTRON@OS:~$</span>
          <input type="text" class="term-input" id="term-input" autocomplete="off" autocapitalize="off" spellcheck="false" placeholder="entrez une commande...">
          <button class="term-send" id="term-send">RUN</button>
        </div>
      </div>
    `;

    outputEl = host.querySelector('#term-output');
    inputEl = host.querySelector('#term-input');
    const quickrow = host.querySelector('#term-quickrow');
    quickrow.innerHTML = QUICK_CMDS.map(c=>`<button class="term-quick-btn mono" data-cmd="${c}">${c}</button>`).join('');
    quickrow.querySelectorAll('.term-quick-btn').forEach(btn=>{
      btn.addEventListener('click', ()=> handleCommand(btn.dataset.cmd));
    });

    if(!outputEl.dataset.initialized){
      print([
        'ULTRON COMMAND TERMINAL — v1.0',
        'Tapez "help" pour afficher les commandes disponibles.',
        ''
      ], 'term-dim');
      outputEl.dataset.initialized = '1';
    }

    host.querySelector('#term-send').addEventListener('click', ()=>{
      handleCommand(inputEl.value);
      inputEl.value = '';
    });
    inputEl.addEventListener('keydown', (e)=>{
      if(e.key === 'Enter'){
        handleCommand(inputEl.value);
        inputEl.value = '';
      }
    });
  }

  return { renderInto, handleCommand };
})();
