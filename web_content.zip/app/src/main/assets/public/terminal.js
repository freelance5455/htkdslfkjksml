// ============================================================
// ULTRON OS — TERMINAL
// A themed but genuinely functional Unix-style shell: virtual filesystem,
// command history, and standard commands (ls, cd, cat, ps, uname...) in
// addition to the ULTRON-specific commands (markets, world, intel...).
// ============================================================
ULTRON.Terminal = (function(){
  const D = ULTRON.DATA;
  let outputEl, inputEl;

  const BOOT_TIME = Date.now();
  const HOSTNAME = 'ultron-core';
  const USER = 'root';

  // ---------------- virtual filesystem ----------------
  // Simple in-memory tree. Directories are {type:'dir', children:{...}}.
  // Files are {type:'file', content:'...'}. Session-only (not persisted).
  function dir(children){ return {type:'dir', children}; }
  function file(content){ return {type:'file', content}; }

  const FS = dir({
    root: dir({
      'readme.txt': file(
        'ULTRON OS — notes de session\n' +
        '------------------------------\n' +
        'Interface de supervision et de visualisation de données simulées.\n' +
        'Tapez "help" pour la liste des commandes, "neofetch" pour les infos système.'
      ),
      'notes.log': file('[session] aucune anomalie détectée.\n[session] tous les modules opérationnels.'),
    }),
    core: dir({
      'kernel.state': file('STATE: RUNNING\nINTEGRITY: 100%\nSYNC: STABLE'),
      'neural-matrix.log': file('neural-matrix.service: model weights loaded (4.1B parameters)\nneural-matrix.service: inference loop nominal'),
    }),
    data: dir({
      'markets.dat': file('binary market snapshot — utilisez la commande "markets" pour une vue lisible.'),
      'intel.dat': file('flux de renseignement compressé — utilisez la commande "intel" pour une vue lisible.'),
    }),
    archives: dir({
      'conflict_2024.arc': file('archive compressée — conflict monitor, exercice 2024.'),
      'defense_2024.arc': file('archive compressée — defense watch, exercice 2024.'),
    }),
    etc: dir({
      'ultron.conf': file('# configuration ULTRON OS\nhostname=ultron-core\ntarget=graphical.target\nfeeds=markets,intel,defense,conflict'),
      'hostname': file(HOSTNAME + '\n'),
    }),
    var: dir({
      log: dir({
        'boot.log': file('voir la séquence de démarrage complète au lancement de l\'application.'),
        'system.log': file('[OK] Tous les services systemd ont démarré normalement.'),
      }),
    }),
  });

  let cwd = ['root']; // path segments from filesystem root

  function resolvePath(argPath){
    if(!argPath) return cwd.slice();
    let parts;
    let base;
    if(argPath.startsWith('/')){
      base = [];
      parts = argPath.split('/').filter(Boolean);
    } else {
      base = cwd.slice();
      parts = argPath.split('/').filter(Boolean);
    }
    for(const p of parts){
      if(p === '.') continue;
      else if(p === '..') { if(base.length) base.pop(); }
      else base.push(p);
    }
    return base;
  }

  function getNode(pathArr){
    let node = FS;
    for(const seg of pathArr){
      if(node.type !== 'dir' || !node.children[seg]) return null;
      node = node.children[seg];
    }
    return node;
  }

  function pathToStr(pathArr){
    return '/' + pathArr.join('/');
  }

  function promptPathLabel(){
    const p = pathToStr(cwd);
    return p === '/root' ? '~' : p;
  }

  // ---------------- history ----------------
  let cmdHistory = [];
  let historyPos = -1;

  // ---------------- output helpers ----------------
  function print(lines, cls){
    if(typeof lines === 'string') lines = [lines];
    lines.forEach(l=>{
      const line = document.createElement('div');
      line.className = 'term-line' + (cls ? ' '+cls : '');
      line.textContent = l;
      outputEl.appendChild(line);
    });
    outputEl.scrollTop = outputEl.scrollHeight;
  }

  function printCmdEcho(cmd){
    const line = document.createElement('div');
    line.className = 'term-line term-echo';
    line.innerHTML = `<span class="term-prompt">${USER}@${HOSTNAME}:${escapeHtml(promptPathLabel())}$</span> ${escapeHtml(cmd)}`;
    outputEl.appendChild(line);
    outputEl.scrollTop = outputEl.scrollHeight;
  }

  function escapeHtml(s){
    const d = document.createElement('div');
    d.textContent = s;
    return d.innerHTML;
  }

  function fmtUptime(){
    const secs = Math.floor((Date.now() - BOOT_TIME)/1000);
    const h = Math.floor(secs/3600);
    const m = Math.floor((secs%3600)/60);
    const s = secs%60;
    return `${h}h ${m}m ${s}s`;
  }

  // ---------------- command table (for help/man/tab-complete) ----------------
  const COMMANDS = {
    help:      'afficher la liste des commandes',
    ls:        'lister le contenu du répertoire courant ([-la] supporté)',
    cd:        'changer de répertoire',
    pwd:       'afficher le répertoire courant',
    cat:       'afficher le contenu d\'un fichier',
    mkdir:     'créer un répertoire (session en cours)',
    touch:     'créer un fichier vide (session en cours)',
    rm:        'supprimer un fichier ou répertoire (session en cours)',
    echo:      'afficher un texte',
    whoami:    'afficher l\'utilisateur courant',
    hostname:  'afficher le nom de la machine',
    uname:     'informations noyau (-a pour tout afficher)',
    uptime:    'durée depuis le démarrage',
    date:      'date et heure courantes',
    ps:        'lister les processus / services actifs',
    top:       'aperçu des ressources système',
    df:        'utilisation des volumes (-h lisible)',
    free:      'utilisation mémoire (-h lisible)',
    history:   'afficher l\'historique des commandes',
    neofetch:  'résumé système façon "neofetch"',
    man:       'afficher l\'aide d\'une commande — ex: man ls',
    sudo:      'exécuter une commande — root a déjà tous les droits ici',
    reboot:    'redémarrer ULTRON OS (rejoue la séquence de boot)',
    shutdown:  'arrêter la session ULTRON',
    clear:     'effacer l\'écran',
    apps:      'lister les applications ouvertes et disponibles',
    open:      'ouvrir une application — ex: open markets',
    close:     'fermer une application ouverte — ex: close markets',
    kill:      'alias de "close"',
    switch:    'ouvrir le sélecteur d\'applications (multitâche)',
    split:     'activer/désactiver la vue partagée — ex: split markets',
    ask:       'demander quelque chose à l\'IA en langage naturel — ex: ask ouvre les marchés',
    status:    'état général du système ULTRON',
    markets:   'résumé des marchés',
    world:     'ouvrir WORLD VIEW',
    intel:     'dernières informations',
    defense:   'ouvrir DEFENSE WATCH',
    conflict:  'ouvrir CONFLICT MONITOR',
    core:      'état du noyau ULTRON',
    search:    'rechercher dans les données — ex: search europe',
  };

  const QUICK_CMDS = ['help','ls','apps','neofetch','status','clear'];

  function handleCommand(raw){
    const cmd = raw.trim();
    if(!cmd) return;
    printCmdEcho(cmd);
    cmdHistory.push(cmd);
    historyPos = cmdHistory.length;

    const tokens = cmd.split(/\s+/);
    let base = tokens[0].toLowerCase();
    let rest = tokens.slice(1);

    // sudo just strips itself — root already has full privileges
    if(base === 'sudo'){
      if(!rest.length){ print('usage: sudo [commande]', 'term-err'); return; }
      print('[sudo] root a déjà tous les droits sur ULTRON OS.', 'term-dim');
      base = rest[0].toLowerCase();
      rest = rest.slice(1);
    }

    const arg = rest.join(' ');
    const argLower = arg.toLowerCase();

    switch(base){
      case 'help': {
        print('COMMANDES DISPONIBLES:');
        Object.keys(COMMANDS).forEach(k=>{
          print(`  ${k.padEnd(10)} — ${COMMANDS[k]}`);
        });
        break;
      }
      case 'man': {
        if(!rest.length){ print('usage: man [commande]', 'term-err'); break; }
        const c = rest[0].toLowerCase();
        if(COMMANDS[c]) print(`${c.toUpperCase()}(1)\n  ${COMMANDS[c]}`);
        else print(`Aucune page de manuel pour "${c}".`, 'term-err');
        break;
      }
      case 'pwd':
        print(pathToStr(cwd));
        break;
      case 'ls': {
        const flags = rest.filter(r=>r.startsWith('-')).join('');
        const target = rest.find(r=>!r.startsWith('-'));
        const node = getNode(resolvePath(target));
        if(!node){ print(`ls: impossible d'accéder à "${target}": aucun fichier ou dossier de ce type`, 'term-err'); break; }
        if(node.type === 'file'){ print(target); break; }
        const entries = Object.keys(node.children);
        if(!entries.length){ print('(répertoire vide)', 'term-dim'); break; }
        if(flags.includes('l')){
          entries.forEach(name=>{
            const n = node.children[name];
            const kind = n.type === 'dir' ? 'd' : '-';
            const size = n.type === 'dir' ? 4096 : (n.content ? n.content.length : 0);
            print(`${kind}rwxr-xr-x  root root  ${String(size).padStart(6)}  ${name}${n.type==='dir'?'/':''}`);
          });
        } else {
          print(entries.map(name=> node.children[name].type==='dir' ? name+'/' : name).join('   '));
        }
        break;
      }
      case 'cd': {
        if(!rest.length || rest[0] === '~'){ cwd = ['root']; break; }
        const target = resolvePath(rest[0]);
        const node = getNode(target);
        if(!node){ print(`cd: ${rest[0]}: aucun fichier ou dossier de ce type`, 'term-err'); break; }
        if(node.type !== 'dir'){ print(`cd: ${rest[0]}: n'est pas un répertoire`, 'term-err'); break; }
        cwd = target;
        break;
      }
      case 'cat': {
        if(!rest.length){ print('usage: cat [fichier]', 'term-err'); break; }
        const node = getNode(resolvePath(rest[0]));
        if(!node){ print(`cat: ${rest[0]}: aucun fichier ou dossier de ce type`, 'term-err'); break; }
        if(node.type === 'dir'){ print(`cat: ${rest[0]}: est un répertoire`, 'term-err'); break; }
        print(node.content.split('\n'));
        break;
      }
      case 'mkdir': {
        if(!rest.length){ print('usage: mkdir [nom]', 'term-err'); break; }
        const parent = getNode(cwd);
        if(parent.children[rest[0]]){ print(`mkdir: "${rest[0]}" existe déjà`, 'term-err'); break; }
        parent.children[rest[0]] = dir({});
        break;
      }
      case 'touch': {
        if(!rest.length){ print('usage: touch [nom]', 'term-err'); break; }
        const parent = getNode(cwd);
        if(!parent.children[rest[0]]) parent.children[rest[0]] = file('');
        break;
      }
      case 'rm': {
        if(!rest.length){ print('usage: rm [nom]', 'term-err'); break; }
        const name = rest[rest.length-1];
        const parent = getNode(cwd);
        if(!parent.children[name]){ print(`rm: "${name}": aucun fichier ou dossier de ce type`, 'term-err'); break; }
        delete parent.children[name];
        break;
      }
      case 'echo':
        print(rest.join(' '));
        break;
      case 'whoami':
        print(USER);
        break;
      case 'hostname':
        print(HOSTNAME);
        break;
      case 'uname':
        if(rest.includes('-a')){
          print(`Linux ${HOSTNAME} 6.9.0-ultron #1 SMP PREEMPT_DYNAMIC aarch64 GNU/Linux`);
        } else {
          print('Linux');
        }
        break;
      case 'uptime':
        print(`up ${fmtUptime()} — utilisateur: ${USER} — charge: 0.12, 0.09, 0.05`);
        break;
      case 'date':
        print(new Date().toString());
        break;
      case 'ps': {
        print('  PID  NOM                       TYPE      STATUT');
        const services = [
          [1,'systemd','service'],
          [412,'systemd-udevd','service'],
          [520,'neural-matrix.service','service'],
          [640,'global-intel.service','service'],
          [655,'orbital-network.service','service'],
          [702,'markets-feed.service','service'],
          [718,'defense-watch.service','service'],
          [1024,'ultron-shell','service'],
        ];
        services.forEach(([pid,name,type])=> print(`  ${String(pid).padEnd(5)}${name.padEnd(26)}${type.padEnd(10)}running`));
        const apps = (ULTRON.App && ULTRON.App.getOpenApps) ? ULTRON.App.getOpenApps() : [];
        const foregroundId = apps.length ? apps[apps.length-1].id : null;
        apps.forEach((a,i)=>{
          const pid = 2000 + i;
          const status = a.id === foregroundId ? 'foreground' : 'background';
          print(`  ${String(pid).padEnd(5)}${a.label.padEnd(26)}${'ui-app'.padEnd(10)}${status}`);
        });
        if(!apps.length) print('  (aucune application utilisateur ouverte — voir "apps")', 'term-dim');
        break;
      }
      case 'top': {
        const apps = (ULTRON.App && ULTRON.App.getOpenApps) ? ULTRON.App.getOpenApps() : [];
        print(`ULTRON OS — uptime ${fmtUptime()} — ${apps.length} application(s) ouverte(s)`, 'term-dim');
        print('CPU:  [||||||||||------------] 41%');
        print('MEM:  [|||||||||||||||-------] 68%');
        print('NET:  [||||-------------------] 15%');
        break;
      }
      case 'df':
        print('VOLUME       TAILLE   UTILISÉ  DISPO   USE%');
        [
          ['/CORE','12G','4.8G','6.7G','41%'],
          ['/DATA','48G','31G','15G','68%'],
          ['/ARCHIVES','120G','54G','60G','48%'],
        ].forEach(([v,t,u,a,p])=> print(`${v.padEnd(13)}${t.padEnd(9)}${u.padEnd(9)}${a.padEnd(8)}${p}`));
        break;
      case 'free':
        print('            TOTAL     UTILISÉ   LIBRE');
        print('Mem:        64G       43G        21G');
        print('Swap:       8G        0G         8G');
        break;
      case 'history':
        cmdHistory.forEach((c,i)=> print(`  ${i+1}  ${c}`));
        break;
      case 'neofetch': {
        print([`${USER}@${HOSTNAME}`, '-'.repeat(16)]);
        print(`OS:        ULTRON OS (neural-kernel 6.9.0-ultron)`);
        print(`Host:      ULTRON Core Node`);
        print(`Uptime:    ${fmtUptime()}`);
        print(`Shell:     ultron-sh 1.0`);
        print(`CPU:       NPU-CORE x16 @ 4.80GHz`);
        print(`Memory:    43G / 64G`);
        print(`Services:  8 actifs`);
        break;
      }
      case 'reboot': {
        print('REDÉMARRAGE D\'ULTRON OS...', 'term-ok');
        setTimeout(()=>{
          if(ULTRON.App && ULTRON.App.reboot) ULTRON.App.reboot();
        }, 500);
        break;
      }
      case 'shutdown':
        print('ARRÊT DEMANDÉ. Fermez l\'application pour terminer la session.', 'term-dim');
        break;
      case 'status': {
        const m = D.getMarketsSnapshot();
        print([
          'SYSTEM STATUS: ONLINE',
          'CORE: OPERATIONAL',
          'DATA STREAM: ACTIVE',
          `GLOBAL MARKET STATUS: ${m.status}`,
          `TIMESTAMP: ${D.fmtDateTime(new Date())}`,
        ], 'term-ok');
        break;
      }
      case 'markets': {
        const m = D.getMarketsSnapshot();
        print([`MARKETS — ${m.upCount} en hausse / ${m.downCount} en baisse — STATUT: ${m.status}`]);
        m.indices.slice(0,5).forEach(i=>{
          print(`  ${i.name.padEnd(14)} ${i.value.toFixed(2).padStart(10)}  ${i.up?'▲':'▼'}${Math.abs(i.change).toFixed(2)}%`);
        });
        print('Tapez "markets" via le module MARKETS pour la vue complète.', 'term-dim');
        setTimeout(()=>ULTRON.App.navigate('markets'), 600);
        break;
      }
      case 'world':
        print('OUVERTURE DE WORLD VIEW...', 'term-ok');
        setTimeout(()=>ULTRON.App.navigate('world'), 400);
        break;
      case 'intel': {
        const feed = D.getIntelFeed().slice(0,5);
        print('DERNIÈRES INFORMATIONS:');
        feed.forEach(f=> print(`  [${f.priority}] ${f.title} — ${f.region}`));
        setTimeout(()=>ULTRON.App.navigate('intel'), 600);
        break;
      }
      case 'defense':
        print('OUVERTURE DE DEFENSE WATCH...', 'term-ok');
        setTimeout(()=>ULTRON.App.navigate('defense'), 400);
        break;
      case 'conflict':
        print('OUVERTURE DE CONFLICT MONITOR...', 'term-ok');
        setTimeout(()=>ULTRON.App.navigate('conflict'), 400);
        break;
      case 'core':
        print([
          'ULTRON CORE STATUS',
          '  INTEGRITY: 100%',
          '  SYNC: STABLE',
          '  ACTIVE FEEDS: 4',
          '  ROTATION: NOMINAL',
        ], 'term-ok');
        break;
      case 'search': {
        if(!arg){ print('Usage: search [terme]', 'term-err'); break; }
        const feed = D.getIntelFeed();
        const results = feed.filter(f =>
          f.title.toLowerCase().includes(argLower) ||
          f.region.toLowerCase().includes(argLower) ||
          f.cat.toLowerCase().includes(argLower) ||
          f.summary.toLowerCase().includes(argLower)
        );
        if(!results.length){
          print(`Aucun résultat pour "${arg}".`, 'term-dim');
        } else {
          print(`${results.length} résultat(s) pour "${arg}":`);
          results.forEach(r=> print(`  [${r.region}] ${r.title}`));
        }
        break;
      }
      case 'apps': {
        const running = (ULTRON.App && ULTRON.App.getOpenApps) ? ULTRON.App.getOpenApps() : [];
        const all = (ULTRON.App && ULTRON.App.getAllApps) ? ULTRON.App.getAllApps() : [];
        print('APPLICATIONS OUVERTES:', 'term-ok');
        if(!running.length){ print('  (aucune)', 'term-dim'); }
        else running.forEach(a=> print(`  ● ${a.label.padEnd(24)} ouvert il y a ${Math.max(1,Math.floor((Date.now()-a.openedAt)/1000))}s`));
        const runningIds = new Set(running.map(a=>a.id));
        const available = all.filter(a=>!runningIds.has(a.id));
        print('APPLICATIONS DISPONIBLES:', 'term-dim');
        if(!available.length){ print('  (toutes ouvertes)', 'term-dim'); }
        else print('  ' + available.map(a=>a.label).join('   '));
        print('Utilisez "open [nom]" / "close [nom]" / "switch" pour naviguer.', 'term-dim');
        break;
      }
      case 'open': {
        if(!rest.length){ print('usage: open [application]', 'term-err'); break; }
        const app = (ULTRON.App && ULTRON.App.openApp) ? ULTRON.App.openApp(arg) : null;
        if(app) print(`OUVERTURE DE ${app.label}...`, 'term-ok');
        else print(`open: application "${arg}" introuvable. Tapez "apps" pour la liste.`, 'term-err');
        break;
      }
      case 'close':
      case 'kill': {
        if(!rest.length){ print(`usage: ${base} [application]`, 'term-err'); break; }
        const closed = (ULTRON.App && ULTRON.App.closeApp) ? ULTRON.App.closeApp(arg) : null;
        if(closed) print(`APPLICATION FERMÉE: ${(closed.label||arg).toString()}`, 'term-ok');
        else print(`${base}: aucune application ouverte ne correspond à "${arg}".`, 'term-err');
        break;
      }
      case 'switch':
        print('OUVERTURE DU SÉLECTEUR D\'APPLICATIONS...', 'term-ok');
        if(ULTRON.App && ULTRON.App.openSwitcher) setTimeout(()=>ULTRON.App.openSwitcher(), 300);
        break;
      case 'split': {
        if(!ULTRON.App || !ULTRON.App.toggleSplit){ print('split: indisponible.', 'term-err'); break; }
        if(rest.length){
          const app = ULTRON.App.findApp ? ULTRON.App.findApp(arg) : null;
          if(!app){ print(`split: application "${arg}" introuvable.`, 'term-err'); break; }
          if(!ULTRON.App.isSplitOpen()) ULTRON.App.toggleSplit();
          ULTRON.App.setSplitApp(app.id);
          print(`VUE PARTAGÉE: ${app.label} affiché en volet secondaire.`, 'term-ok');
        } else {
          ULTRON.App.toggleSplit();
          print(ULTRON.App.isSplitOpen() ? 'VUE PARTAGÉE ACTIVÉE.' : 'VUE PARTAGÉE DÉSACTIVÉE.', 'term-ok');
        }
        break;
      }
      case 'ask': {
        if(!arg){ print('usage: ask [votre demande en langage naturel]', 'term-err'); break; }
        if(!ULTRON.Assistant){ print('ask: assistant indisponible.', 'term-err'); break; }
        const response = ULTRON.Assistant.handle(arg, {silentUser:true});
        print(`IA> ${response}`, 'term-ok');
        break;
      }
      case 'clear':
        outputEl.innerHTML = '';
        break;
      default:
        print(`${base}: commande introuvable. Tapez "help" pour la liste des commandes.`, 'term-err');
    }
  }

  function renderInto(host){
    host.innerHTML = `
      <style>
        .term-wrap{display:flex; flex-direction:column; height:100%; background:#050202;}
        .term-output{
          flex:1; overflow-y:auto; padding:14px 16px; font-family:var(--font-mono); font-size:12.5px;
          line-height:1.7;
        }
        .term-line{color:var(--white); white-space:pre-wrap; word-break:break-word;}
        .term-line.term-ok{color:var(--green);}
        .term-line.term-err{color:var(--red-bright);}
        .term-line.term-dim{color:var(--grey-dim);}
        .term-line.term-echo{color:var(--red-bright); margin-top:8px;}
        .term-prompt{color:var(--red); margin-right:4px;}
        .term-quickrow{
          display:flex; gap:6px; padding:8px 12px; overflow-x:auto; border-top:1px solid var(--line);
          background:var(--bg-panel);
        }
        .term-quick-btn{
          flex-shrink:0; background:var(--bg-panel-2); border:1px solid var(--line); color:var(--grey);
          font-family:var(--font-mono); font-size:10px; padding:8px 12px;
        }
        .term-quick-btn:active{border-color:var(--red);}
        .term-inputrow{
          display:flex; align-items:center; gap:8px; padding:12px 16px calc(12px + var(--safe-bottom));
          border-top:1px solid var(--line-strong); background:var(--bg-panel);
        }
        .term-inputrow .term-prompt{font-family:var(--font-mono); font-size:12px; flex-shrink:0;}
        .term-input{
          flex:1; background:none; border:none; color:var(--white); font-family:var(--font-mono);
          font-size:13px; outline:none; caret-color:var(--red-bright);
        }
        .term-send{
          background:var(--red-deep); border:1px solid var(--line-strong); color:var(--red-bright);
          font-family:var(--font-mono); font-size:11px; padding:8px 14px; flex-shrink:0;
        }
      </style>
      <div class="term-wrap">
        <div class="topbar">
          <div class="topbar-title">
            <span class="tb-name disp">TERMINAL</span>
            <span class="tb-sub mono">ULTRON COMMAND TERMINAL</span>
          </div>
          <div class="tb-status"><span class="tb-dot"></span><span class="mono">READY</span></div>
        </div>
        <div class="term-output" id="term-output"></div>
        <div class="term-quickrow" id="term-quickrow"></div>
        <div class="term-inputrow">
          <span class="term-prompt mono" id="term-prompt-live">${USER}@${HOSTNAME}:${promptPathLabel()}$</span>
          <input type="text" class="term-input" id="term-input" autocomplete="off" autocapitalize="off" spellcheck="false" placeholder="entrez une commande...">
          <button class="term-send" id="term-send">RUN</button>
        </div>
      </div>
    `;

    outputEl = host.querySelector('#term-output');
    inputEl = host.querySelector('#term-input');
    const promptLive = host.querySelector('#term-prompt-live');
    const quickrow = host.querySelector('#term-quickrow');
    quickrow.innerHTML = QUICK_CMDS.map(c=>`<button class="term-quick-btn mono" data-cmd="${c}">${c}</button>`).join('');
    quickrow.querySelectorAll('.term-quick-btn').forEach(btn=>{
      btn.addEventListener('click', ()=> { handleCommand(btn.dataset.cmd); promptLive.textContent = `${USER}@${HOSTNAME}:${promptPathLabel()}$`; });
    });

    if(!outputEl.dataset.initialized){
      print([
        'ULTRON COMMAND TERMINAL — v2.0',
        'Shell Unix-like complet : ls, cd, cat, ps, top, uname, neofetch...',
        'Tapez "help" pour afficher toutes les commandes.',
        ''
      ], 'term-dim');
      outputEl.dataset.initialized = '1';
    }

    function run(){
      handleCommand(inputEl.value);
      inputEl.value = '';
      promptLive.textContent = `${USER}@${HOSTNAME}:${promptPathLabel()}$`;
    }

    host.querySelector('#term-send').addEventListener('click', run);
    inputEl.addEventListener('keydown', (e)=>{
      if(e.key === 'Enter'){ run(); return; }
      if(e.key === 'ArrowUp'){
        if(cmdHistory.length){
          historyPos = Math.max(0, historyPos-1);
          inputEl.value = cmdHistory[historyPos] || '';
          setTimeout(()=>inputEl.setSelectionRange(inputEl.value.length, inputEl.value.length));
        }
        e.preventDefault();
      }
      if(e.key === 'ArrowDown'){
        if(cmdHistory.length){
          historyPos = Math.min(cmdHistory.length, historyPos+1);
          inputEl.value = cmdHistory[historyPos] || '';
        }
        e.preventDefault();
      }
      if(e.key === 'Tab'){
        e.preventDefault();
        const partial = inputEl.value.toLowerCase();
        if(!partial) return;
        const match = Object.keys(COMMANDS).find(c=>c.startsWith(partial));
        if(match) inputEl.value = match + ' ';
      }
    });
  }

  return { renderInto, handleCommand };
})();
