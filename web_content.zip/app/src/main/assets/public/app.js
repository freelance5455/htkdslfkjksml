// ============================================================
// ULTRON OS — APP SHELL
// ============================================================
ULTRON.App = (function(){

  let currentRoute = 'dashboard';
  const DEFAULT_SETTINGS = {
    animIntensity: 80,
    glitch: true,
    lowPower: false,
    notifications: true,
    regions: ['Europe','Amériques','Afrique','Moyen-Orient','Asie','Pacifique'],
  };

  let settings = loadSettings();
  let ambientTimers = [];

  function loadSettings(){
    try{
      const saved = JSON.parse(localStorage.getItem('ultron.settings') || 'null');
      return {...DEFAULT_SETTINGS, ...(saved && typeof saved === 'object' ? saved : {})};
    }catch(_){ return {...DEFAULT_SETTINGS}; }
  }

  function saveSettings(){
    try{ localStorage.setItem('ultron.settings', JSON.stringify(settings)); }catch(_){}
  }

  // ---------------- open-apps persistence (survives app relaunch) ----------------
  function savePersistedApps(){
    try{ localStorage.setItem('ultron.openApps', JSON.stringify(openApps.map(a=>a.id))); }catch(_){}
  }
  function loadPersistedApps(){
    try{
      const ids = JSON.parse(localStorage.getItem('ultron.openApps') || '[]');
      if(!Array.isArray(ids)) return [];
      return ids.filter(id => ALL_APPS.some(a=>a.id===id)).map(id=>({id, openedAt: Date.now()}));
    }catch(_){ return []; }
  }
  function clearPersistedApps(){
    try{ localStorage.removeItem('ultron.openApps'); localStorage.removeItem('ultron.splitState'); }catch(_){}
  }
  function saveSplitState(){
    try{ localStorage.setItem('ultron.splitState', JSON.stringify({splitMode, splitRoute})); }catch(_){}
  }
  function loadSplitState(){
    try{
      const s = JSON.parse(localStorage.getItem('ultron.splitState') || 'null');
      if(s && typeof s === 'object') return s;
    }catch(_){}
    return null;
  }

  const NAV_ITEMS = [
    {id:'dashboard', label:'HOME', icon:'home'},
    {id:'world', label:'WORLD', icon:'globe'},
    {id:'markets', label:'MARKETS', icon:'chart'},
    {id:'intel', label:'INTEL', icon:'signal'},
    {id:'terminal', label:'TERM', icon:'terminal'},
    {id:'more', label:'MORE', icon:'more'},
  ];

  // Grouped by function so the sheet reads like an organized OS app
  // launcher (Renseignement / Sécurité / Système) instead of a flat list.
  const MORE_GROUPS = [
    { label: 'RENSEIGNEMENT', icon:'signal', items: [
      {id:'conflict', label:'CONFLICT MONITOR'},
      {id:'archives', label:'ARCHIVES'},
      {id:'network', label:'NEURAL NETWORK'},
    ]},
    { label: 'SÉCURITÉ', icon:'shield', items: [
      {id:'defense', label:'DEFENSE WATCH'},
      {id:'surveillance', label:'SURVEILLANCE GRID'},
      {id:'protocols', label:'PROTOCOLS'},
    ]},
    { label: 'SYSTÈME', icon:'cpu', items: [
      {id:'ai', label:'AI CORE'},
      {id:'system', label:'SYSTEM CORE'},
      {id:'settings', label:'SETTINGS'},
    ]},
  ];
  const MORE_ITEMS = MORE_GROUPS.flatMap(g=>g.items.map(i=>({...i, icon:g.icon})));

  // Full app registry (everything that can be opened, closed, and listed
  // from the terminal or the app switcher). Dashboard is the home screen —
  // always available, not tracked as a "running" app.
  const ALL_APPS = [...NAV_ITEMS.filter(i=>i.id!=='more'&&i.id!=='dashboard'), ...MORE_ITEMS];

  // ---------------- running-apps / multitasking state ----------------
  // MRU (most-recently-used) list of open apps: [{id, openedAt}]
  let openApps = [];
  const MAX_OPEN_APPS = 8;
  // Split-view (window manager): primary pane = normal nav, secondary = splitRoute.
  // 'world' (3D canvas) and 'terminal' (singleton DOM refs) can't safely run in
  // both panes at once, so they're excluded from the secondary pane's choices.
  let splitMode = false;
  let splitRoute = null;
  const SPLIT_SAFE = ['markets','intel','conflict','defense','ai','network','surveillance','archives','protocols','system','settings'];

  function appMeta(id){ return ALL_APPS.find(a=>a.id===id); }

  function registerAppOpen(id){
    if(id === 'dashboard') return;
    openApps = openApps.filter(a=>a.id !== id);
    openApps.push({id, openedAt: Date.now()});
    if(openApps.length > MAX_OPEN_APPS) openApps.shift();
    savePersistedApps();
  }

  function closeApp(id){
    const was = openApps.some(a=>a.id===id);
    openApps = openApps.filter(a=>a.id !== id);
    if(!was) return false;
    savePersistedApps();
    if(id === currentRoute){
      const next = openApps.length ? openApps[openApps.length-1].id : 'dashboard';
      navigate(next);
    }
    refreshSwitcherIfOpen();
    return true;
  }

  function getOpenApps(){
    return openApps.map(a=>({id:a.id, label:(appMeta(a.id)||{}).label || a.id.toUpperCase(), openedAt:a.openedAt}));
  }

  function getAllApps(){
    return ALL_APPS.map(a=>({id:a.id, label:a.label}));
  }

  function findApp(query){
    if(!query) return null;
    const q = query.trim().toLowerCase();
    return ALL_APPS.find(a=>a.id===q) ||
           ALL_APPS.find(a=>a.label.toLowerCase()===q) ||
           ALL_APPS.find(a=>a.id.includes(q) || a.label.toLowerCase().includes(q)) ||
           null;
  }

  function openApp(query){
    const app = findApp(query);
    if(!app) return null;
    navigate(app.id);
    return app;
  }

  function closeAppByQuery(query){
    if(!query) return null;
    const q = query.trim().toLowerCase();
    const running = openApps.find(a=>a.id===q || (appMeta(a.id)||{}).label.toLowerCase()===q || a.id.includes(q));
    if(!running) return null;
    closeApp(running.id);
    return running;
  }

  let screensHost, navHost, moreSheet, switcherHost;

  function injectShellStyles(){
    const style = document.createElement('style');
    style.textContent = `
      /* -------- persistent system bar (desktop-style top panel) -------- */
      .sysbar{
        display:flex; align-items:center; justify-content:space-between;
        padding:calc(6px + var(--safe-top)) 14px 6px 14px;
        background:#050202; border-bottom:1px solid var(--line);
        font-family:var(--font-mono); font-size:9.5px; letter-spacing:0.1em;
        color:var(--grey-dim); flex-shrink:0; position:relative; z-index:40;
      }
      .sysbar-left{display:flex; align-items:center; gap:6px; color:var(--red-bright);}
      .sysbar-left .sb-eye{width:7px; height:7px; border-radius:50%; background:var(--red-bright); box-shadow:0 0 6px var(--red-bright);}
      .sysbar-right{display:flex; align-items:center; gap:12px;}
      .sysbar-right span{display:flex; align-items:center; gap:4px;}
      .sysbar-apps-btn{
        display:flex; align-items:center; gap:5px; background:none; border:1px solid var(--line);
        color:var(--grey-dim); font-family:var(--font-mono); font-size:9.5px; letter-spacing:0.08em;
        padding:4px 8px; position:relative;
      }
      .sysbar-apps-btn svg{width:11px; height:11px;}
      .sysbar-apps-btn .apps-count{
        background:var(--red-bright); color:#1a0505; border-radius:8px; padding:0 5px;
        font-size:8.5px; line-height:14px; min-width:14px; text-align:center;
      }
      .sysbar-apps-btn.has-apps{color:var(--red-bright); border-color:var(--line-strong);}
      .sysbar-split-btn{
        display:flex; align-items:center; background:none; border:1px solid var(--line);
        color:var(--grey-dim); padding:4px 7px;
      }
      .sysbar-split-btn svg{width:11px; height:11px; display:block;}
      .sysbar-split-btn.active{color:var(--red-bright); border-color:var(--red);}

      /* -------- split view (secondary pane / window manager) -------- */
      .panes-wrap{display:flex; flex-direction:column; flex:1; min-height:0;}
      .split-pane{display:none; flex-direction:column; flex:1; min-height:0; border-top:2px solid var(--line-strong);}
      .split-pane.show{display:flex;}
      .split-head{
        display:flex; align-items:center; gap:6px; padding:6px 8px; overflow-x:auto;
        background:var(--bg-panel); border-bottom:1px solid var(--line); flex-shrink:0;
      }
      .split-chip{
        flex-shrink:0; background:var(--bg-panel-2); border:1px solid var(--line); color:var(--grey);
        font-family:var(--font-mono); font-size:9px; letter-spacing:0.04em; padding:6px 9px;
      }
      .split-chip.active{color:var(--red-bright); border-color:var(--red);}
      .split-close-btn{margin-left:auto; flex-shrink:0; background:none; border:1px solid var(--line); color:var(--grey-dim); padding:6px 8px;}
      .split-content{flex:1; min-height:0; position:relative; overflow-y:auto;}

      /* -------- app switcher (multitasking overlay) -------- */
      .switcher-bg{
        position:absolute; inset:0; background:rgba(4,2,2,0.86); z-index:60;
        opacity:0; pointer-events:none; transition:opacity 0.25s ease;
        display:flex; flex-direction:column;
      }
      .switcher-bg.show{opacity:1; pointer-events:auto;}
      .switcher-head{
        display:flex; justify-content:space-between; align-items:center;
        padding:calc(16px + var(--safe-top)) 18px 10px;
        font-family:var(--font-mono); font-size:10px; letter-spacing:0.16em; color:var(--red);
      }
      .switcher-close{background:none; border:1px solid var(--line); color:var(--grey); padding:6px 10px; font-family:var(--font-mono); font-size:10px;}
      .switcher-body{flex:1; overflow-y:auto; padding:6px 16px calc(24px + var(--safe-bottom));}
      .switcher-empty{color:var(--grey-dim); font-family:var(--font-mono); font-size:11px; text-align:center; margin-top:60px;}
      .switcher-card{
        display:flex; align-items:center; gap:12px; width:100%;
        background:var(--bg-panel); border:1px solid var(--line); padding:12px 14px; margin-bottom:8px;
        color:var(--white); text-align:left;
      }
      .switcher-card.current{border-color:var(--line-strong); box-shadow:0 0 0 1px var(--line-strong) inset;}
      .switcher-card .sc-app-icon{width:18px; height:18px; color:var(--red-bright); flex-shrink:0;}
      .switcher-card .sc-app-info{flex:1; display:flex; flex-direction:column; gap:2px;}
      .switcher-card .sc-app-name{font-family:var(--font-ui); font-size:14px; font-weight:600;}
      .switcher-card .sc-app-sub{font-family:var(--font-mono); font-size:9px; color:var(--grey-dim); letter-spacing:0.06em;}
      .switcher-card .sc-app-close{
        background:none; border:1px solid var(--line); color:var(--grey-dim); padding:6px; flex-shrink:0;
      }
      .switcher-card .sc-app-close svg{width:12px; height:12px; display:block;}
      .switcher-card .sc-app-close:active{color:var(--red-bright); border-color:var(--red);}

      /* -------- more sheet: grouped sections -------- */
      .more-group-label{
        font-family:var(--font-mono); font-size:9.5px; letter-spacing:0.18em; color:var(--red);
        padding:14px 4px 6px; text-transform:uppercase;
      }
      .more-group-label:first-child{padding-top:2px;}

      .topbar{
        display:flex; justify-content:space-between; align-items:center;
        padding:12px 16px;
        border-bottom:1px solid var(--line);
        background:linear-gradient(180deg, rgba(20,8,7,0.6), transparent);
        flex-shrink:0;
      }
      .topbar-title{display:flex; flex-direction:column;}
      .tb-name{font-size:15px; letter-spacing:0.14em; color:var(--white);}
      .tb-sub{font-size:9px; letter-spacing:0.1em; color:var(--grey-dim); margin-top:2px;}
      .tb-status{display:flex; align-items:center; gap:6px; font-size:9px; color:var(--green); letter-spacing:0.1em;}
      .tb-dot{width:6px; height:6px; border-radius:50%; background:var(--green); box-shadow:0 0 6px var(--green); animation:blinkDot 2s ease-in-out infinite;}
      @keyframes blinkDot{0%,100%{opacity:1;}50%{opacity:0.35;}}

      .app-screen-inner{position:absolute; inset:0; display:flex; flex-direction:column;}

      /* -------- bottom nav -------- */
      .bottomnav{
        position:absolute; bottom:0; left:0; right:0; z-index:20;
        display:flex; background:rgba(12,6,5,0.92); backdrop-filter:blur(10px);
        border-top:1px solid var(--line-strong);
        padding-bottom:var(--safe-bottom);
      }
      .bn-item{
        flex:1; display:flex; flex-direction:column; align-items:center; gap:4px;
        padding:10px 4px 8px; background:none; border:none; color:var(--grey-dim);
        position:relative;
      }
      .bn-item .bn-icon{width:20px; height:20px;}
      .bn-item .bn-label{font-family:var(--font-mono); font-size:8.5px; letter-spacing:0.06em;}
      .bn-item.active{color:var(--red-bright);}
      .bn-item.active::before{
        content:''; position:absolute; top:0; left:50%; transform:translateX(-50%);
        width:24px; height:2px; background:var(--red-bright); box-shadow:0 0 8px var(--red-bright);
      }

      /* -------- more sheet -------- */
      .more-sheet-bg{
        position:absolute; inset:0; background:rgba(4,2,2,0.7); z-index:30;
        opacity:0; pointer-events:none; transition:opacity 0.25s ease;
        display:flex; align-items:flex-end;
      }
      .more-sheet-bg.show{opacity:1; pointer-events:auto;}
      .more-sheet{
        width:100%; background:var(--bg-panel); border-top:1px solid var(--line-strong);
        padding:8px 16px calc(24px + var(--safe-bottom)); transform:translateY(100%);
        transition:transform 0.3s ease;
      }
      .more-sheet-bg.show .more-sheet{transform:translateY(0);}
      .more-sheet-handle{width:36px; height:3px; background:var(--line-strong); margin:10px auto 16px;}
      .more-sheet-item{
        display:flex; align-items:center; justify-content:space-between; width:100%;
        background:none; border:none; border-bottom:1px solid var(--line); color:var(--white);
        padding:16px 4px; font-family:var(--font-ui); font-size:15px; font-weight:600;
      }
      .more-sheet-item:last-child{border-bottom:none;}
      .more-sheet-item .arrow{color:var(--red); font-family:var(--font-mono);}

      /* -------- notification toast -------- */
      .toast-host{position:absolute; top:calc(44px + var(--safe-top)); left:12px; right:12px; z-index:50; display:flex; flex-direction:column; gap:8px; pointer-events:none;}
      .toast{
        background:var(--bg-panel); border:1px solid var(--line-strong); border-left:3px solid var(--red-bright);
        padding:12px 14px; box-shadow:0 8px 24px rgba(0,0,0,0.5);
        transform:translateY(-16px); opacity:0; transition:all 0.35s ease;
        pointer-events:auto;
      }
      .toast.show{transform:translateY(0); opacity:1;}
      .toast-title{font-family:var(--font-mono); font-size:9.5px; letter-spacing:0.14em; color:var(--red-bright);}
      .toast-body{font-family:var(--font-ui); font-size:13px; color:var(--white); margin-top:4px;}
    `;
    document.head.appendChild(style);
  }

  function iconFor(name){
    const icons = {
      home: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M4 11l8-7 8 7"/><path d="M6 10v9h12v-9"/></svg>`,
      globe: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.5 2.7 3.8 6 3.8 9s-1.3 6.3-3.8 9c-2.5-2.7-3.8-6-3.8-9s1.3-6.3 3.8-9z"/></svg>`,
      chart: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M4 19V9M12 19V4M20 19v-6"/><path d="M2 19h20"/></svg>`,
      signal: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M4 12a8 8 0 0 1 16 0M7 12a5 5 0 0 1 10 0"/><circle cx="12" cy="12" r="1.6" fill="currentColor" stroke="none"/></svg>`,
      terminal: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="3" y="4" width="18" height="16" rx="1"/><path d="M7 9l3 3-3 3M13 15h4"/></svg>`,
      more: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><circle cx="5" cy="12" r="1.4" fill="currentColor" stroke="none"/><circle cx="12" cy="12" r="1.4" fill="currentColor" stroke="none"/><circle cx="19" cy="12" r="1.4" fill="currentColor" stroke="none"/></svg>`,
      shield: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M12 3l7 3v6c0 4.5-3 7.5-7 9-4-1.5-7-4.5-7-9V6l7-3z"/></svg>`,
      cpu: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="6" y="6" width="12" height="12" rx="1"/><path d="M9 3v3M15 3v3M9 18v3M15 18v3M3 9h3M3 15h3M18 9h3M18 15h3"/></svg>`,
      apps: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>`,
      close: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M5 5l14 14M19 5L5 19"/></svg>`,
      split: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="3" y="3" width="18" height="18" rx="1"/><path d="M3 12h18"/></svg>`,
      mic: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="9" y="2" width="6" height="12" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v4M8 22h8"/></svg>`,
      send: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 12l16-8-6 16-3-7-7-1z"/></svg>`,
    };
    return icons[name] || '';
  }

  let clockTimer = null;
  function startClock(){
    const el = document.getElementById('sysbar-clock');
    if(!el) return;
    if(clockTimer) clearInterval(clockTimer);
    const tick = ()=>{
      const d = new Date();
      el.textContent = d.toLocaleTimeString('fr-FR',{hour:'2-digit',minute:'2-digit',second:'2-digit'})
        + ' · ' + d.toLocaleDateString('fr-FR',{day:'2-digit',month:'2-digit',year:'numeric'});
    };
    tick();
    clockTimer = setInterval(tick, 1000);
  }

  function buildShell(){
    const root = document.getElementById('screens');
    root.innerHTML = `
      <div class="app-screen-inner" id="main-shell" style="display:none;">
        <div class="sysbar">
          <div class="sysbar-left"><span class="sb-eye"></span><span>ULTRON OS</span></div>
          <div class="sysbar-right">
            <span id="sysbar-net">NET: OK</span>
            <button class="sysbar-split-btn" id="sysbar-split-btn" title="Vue partagée">${iconFor('split')}</button>
            <button class="sysbar-apps-btn" id="sysbar-apps-btn">${iconFor('apps')}<span>APPS</span><span class="apps-count" id="sysbar-apps-count">0</span></button>
            <span id="sysbar-clock" class="mono"></span>
          </div>
        </div>
        <div class="panes-wrap" id="panes-wrap">
          <div id="route-host" style="position:relative; flex:1; min-height:0;"></div>
          <div class="split-pane" id="split-pane">
            <div class="split-head" id="split-head"></div>
            <div class="split-content" id="split-content"></div>
          </div>
        </div>
        <div class="bottomnav" id="bottomnav"></div>
        <div class="more-sheet-bg" id="more-sheet-bg">
          <div class="more-sheet">
            <div class="more-sheet-handle"></div>
            <div id="more-sheet-items"></div>
          </div>
        </div>
        <div class="switcher-bg" id="switcher-bg">
          <div class="switcher-head">
            <span>APPLICATIONS OUVERTES</span>
            <button class="switcher-close" id="switcher-close-btn">FERMER ✕</button>
          </div>
          <div class="switcher-body" id="switcher-body"></div>
        </div>
        <div class="toast-host" id="toast-host"></div>
      </div>
    `;
    screensHost = document.getElementById('route-host');
    navHost = document.getElementById('bottomnav');
    moreSheet = document.getElementById('more-sheet-bg');
    switcherHost = document.getElementById('switcher-bg');
    startClock();

    document.getElementById('sysbar-apps-btn').addEventListener('click', openSwitcher);
    document.getElementById('sysbar-split-btn').addEventListener('click', toggleSplit);
    document.getElementById('switcher-close-btn').addEventListener('click', closeSwitcher);
    switcherHost.addEventListener('click', (e)=>{
      if(e.target.id === 'switcher-bg') closeSwitcher();
    });

    navHost.innerHTML = NAV_ITEMS.map(item=>`
      <button class="bn-item" data-route="${item.id}">
        <span class="bn-icon">${iconFor(item.icon)}</span>
        <span class="bn-label mono">${item.label}</span>
      </button>
    `).join('');
    navHost.querySelectorAll('.bn-item').forEach(btn=>{
      btn.addEventListener('click', ()=>{
        if(btn.dataset.route === 'more'){
          openMoreSheet();
        } else {
          navigate(btn.dataset.route);
        }
      });
    });

    document.getElementById('more-sheet-items').innerHTML = MORE_GROUPS.map(group=>`
      <div class="more-group-label mono">${group.label}</div>
      ${group.items.map(m=>`
        <button class="more-sheet-item" data-route="${m.id}">
          <span>${m.label}</span><span class="arrow">›</span>
        </button>
      `).join('')}
    `).join('');
    document.querySelectorAll('.more-sheet-item').forEach(btn=>{
      btn.addEventListener('click', ()=>{
        closeMoreSheet();
        navigate(btn.dataset.route);
      });
    });
    moreSheet.addEventListener('click', (e)=>{
      if(e.target.id === 'more-sheet-bg') closeMoreSheet();
    });
  }

  function openMoreSheet(){ moreSheet.classList.add('show'); }
  function closeMoreSheet(){ moreSheet.classList.remove('show'); }

  function updateAppsBadge(){
    const btn = document.getElementById('sysbar-apps-btn');
    const count = document.getElementById('sysbar-apps-count');
    if(!btn || !count) return;
    count.textContent = String(openApps.length);
    btn.classList.toggle('has-apps', openApps.length > 0);
  }

  function relTime(ts){
    const secs = Math.floor((Date.now()-ts)/1000);
    if(secs < 60) return `${secs}s`;
    const mins = Math.floor(secs/60);
    if(mins < 60) return `${mins}m`;
    return `${Math.floor(mins/60)}h${mins%60}m`;
  }

  function renderSwitcher(){
    const body = document.getElementById('switcher-body');
    if(!body) return;
    if(!openApps.length){
      body.innerHTML = `<div class="switcher-empty">Aucune application ouverte.<br>Tout tourne depuis le HOME.</div>`;
      return;
    }
    // most-recently-used first
    const list = openApps.slice().reverse();
    body.innerHTML = list.map(a=>{
      const meta = appMeta(a.id) || {label:a.id.toUpperCase(), icon:'apps'};
      const isCurrent = a.id === currentRoute;
      return `
        <div class="switcher-card${isCurrent?' current':''}" data-route="${a.id}">
          <span class="sc-app-icon">${iconFor(meta.icon)}</span>
          <span class="sc-app-info">
            <span class="sc-app-name">${meta.label}</span>
            <span class="sc-app-sub mono">${isCurrent ? 'AU PREMIER PLAN' : 'EN ARRIÈRE-PLAN'} · ouvert il y a ${relTime(a.openedAt)}</span>
          </span>
          <button class="sc-app-close" data-close="${a.id}">${iconFor('close')}</button>
        </div>
      `;
    }).join('');
    body.querySelectorAll('.switcher-card').forEach(card=>{
      card.addEventListener('click', (e)=>{
        if(e.target.closest('.sc-app-close')) return;
        closeSwitcher();
        navigate(card.dataset.route);
      });
    });
    body.querySelectorAll('.sc-app-close').forEach(btn=>{
      btn.addEventListener('click', (e)=>{
        e.stopPropagation();
        closeApp(btn.dataset.close);
      });
    });
  }

  function refreshSwitcherIfOpen(){
    if(switcherHost && switcherHost.classList.contains('show')) renderSwitcher();
    updateAppsBadge();
  }

  function openSwitcher(){ renderSwitcher(); switcherHost.classList.add('show'); }
  function closeSwitcher(){ switcherHost.classList.remove('show'); }

  function dispatchRender(route, host){
    switch(route){
      case 'dashboard': ULTRON.Modules.renderDashboard(host); break;
      case 'world': ULTRON.Modules.renderWorld(host); break;
      case 'markets': ULTRON.Modules.renderMarkets(host); break;
      case 'intel': ULTRON.Modules.renderIntel(host); break;
      case 'conflict': ULTRON.Modules.renderConflict(host); break;
      case 'defense': ULTRON.Modules.renderDefense(host); break;
      case 'terminal': ULTRON.Terminal.renderInto(host); break;
      case 'settings': ULTRON.Modules.renderSettings(host); break;
      case 'ai': ULTRON.Modules.renderAI(host); break;
      case 'network': ULTRON.Modules.renderNetwork(host); break;
      case 'surveillance': ULTRON.Modules.renderSurveillance(host); break;
      case 'archives': ULTRON.Modules.renderArchives(host); break;
      case 'protocols': ULTRON.Modules.renderProtocols(host); break;
      case 'system': ULTRON.Modules.renderSystem(host); break;
      default: ULTRON.Modules.renderDashboard(host);
    }
  }

  function renderSplitChips(){
    const head = document.getElementById('split-head');
    if(!head) return;
    head.innerHTML = SPLIT_SAFE.map(id=>{
      const meta = appMeta(id);
      return `<button class="split-chip${id===splitRoute?' active':''}" data-route="${id}">${meta.label}</button>`;
    }).join('') + `<button class="split-close-btn" id="split-close-btn">${iconFor('close')}</button>`;
    head.querySelectorAll('.split-chip').forEach(btn=>{
      btn.addEventListener('click', ()=> setSplitApp(btn.dataset.route));
    });
    const closeBtn = document.getElementById('split-close-btn');
    if(closeBtn) closeBtn.addEventListener('click', toggleSplit);
  }

  function setSplitApp(route){
    if(!SPLIT_SAFE.includes(route)) return;
    splitRoute = route;
    const content = document.getElementById('split-content');
    if(content) dispatchRender(route, content);
    registerAppOpen(route);
    updateAppsBadge();
    saveSplitState();
    renderSplitChips();
  }

  function toggleSplit(){
    const pane = document.getElementById('split-pane');
    const btn = document.getElementById('sysbar-split-btn');
    splitMode = !splitMode;
    if(splitMode){
      if(!splitRoute || !SPLIT_SAFE.includes(splitRoute)){
        splitRoute = SPLIT_SAFE.find(id=>id!==currentRoute) || SPLIT_SAFE[0];
      }
      pane.classList.add('show');
      btn.classList.add('active');
      renderSplitChips();
      setSplitApp(splitRoute);
    } else {
      pane.classList.remove('show');
      btn.classList.remove('active');
    }
    saveSplitState();
  }

  function navigate(route){
    currentRoute = route;
    registerAppOpen(route);
    updateAppsBadge();

    // dispose globe if leaving world view
    if(route !== 'world'){
      ULTRON.Globe.dispose();
    }

    dispatchRender(route, screensHost);

    navHost.querySelectorAll('.bn-item').forEach(btn=>{
      const isMore = MORE_ITEMS.some(m=>m.id===route) && btn.dataset.route==='more';
      btn.classList.toggle('active', btn.dataset.route === route || isMore);
    });
  }

  // ---------------- notifications ----------------
  const NOTIF_POOL = [
    {title:'ULTRON ALERT', body:'NEW GLOBAL EVENT DETECTED'},
    {title:'ULTRON ALERT', body:'MARKET VOLATILITY INCREASED'},
    {title:'ULTRON ALERT', body:'NEW INTELLIGENCE REPORT AVAILABLE'},
  ];
  function maybeShowNotification(){
    if(!settings.notifications) return;
    const n = NOTIF_POOL[Math.floor(Math.random()*NOTIF_POOL.length)];
    const host = document.getElementById('toast-host');
    if(!host) return;
    const el = document.createElement('div');
    el.className = 'toast';
    el.innerHTML = `<div class="toast-title mono">${n.title}</div><div class="toast-body">${n.body}</div>`;
    host.appendChild(el);
    requestAnimationFrame(()=>el.classList.add('show'));
    setTimeout(()=>{
      el.classList.remove('show');
      setTimeout(()=>el.remove(), 400);
    }, 4200);
  }

  // ---------------- settings ----------------
  function getSettings(){ return settings; }
  function updateSetting(key, value){
    if(!(key in DEFAULT_SETTINGS)) return;
    settings[key] = value;
    saveSettings();
    document.documentElement.dataset.lowPower = settings.lowPower ? '1' : '0';
    document.documentElement.dataset.animIntensity = String(settings.animIntensity);
  }

  // ---------------- ambient flicker ----------------
  function startAmbientEffects(){
    const flicker = document.getElementById('flicker');
    ambientTimers.forEach(clearInterval);
    ambientTimers = [];

    ambientTimers.push(setInterval(()=>{
      if(document.visibilityState !== 'visible' || settings.lowPower || !settings.glitch) return;
      if(Math.random() < 0.06 && flicker){
        flicker.style.opacity = '1';
        setTimeout(()=>{ flicker.style.opacity = '0'; }, 70 + Math.random()*90);
      }
    }, 1200));

    ambientTimers.push(setInterval(()=>{
      if(document.visibilityState === 'visible' && !settings.lowPower && settings.notifications && Math.random() < 0.5){
        maybeShowNotification();
      }
    }, 45000));
  }

  function installKeyboardShortcuts(){
    document.addEventListener('keydown', (e)=>{
      if(e.key === 'Escape'){
        closeMoreSheet();
        closeSwitcher();
        return;
      }
      if(e.target && /input|textarea|select/i.test(e.target.tagName)) return;
      const routes = {1:'dashboard',2:'world',3:'markets',4:'intel',5:'terminal'};
      if(e.altKey && routes[e.key]){
        e.preventDefault();
        navigate(routes[e.key]);
      }
      if(e.altKey && e.key.toLowerCase() === 'a'){
        e.preventDefault();
        openSwitcher();
      }
      if(e.altKey && e.key.toLowerCase() === 's'){
        e.preventDefault();
        toggleSplit();
      }
    });
  }

  function start(){
    injectShellStyles();
    installKeyboardShortcuts();
    document.documentElement.dataset.lowPower = settings.lowPower ? '1' : '0';
    ULTRON.Boot.run(()=>{
      buildShell();
      document.getElementById('main-shell').style.display = 'flex';
      // restore apps left open from a previous session, like a real OS resuming background tasks
      openApps = loadPersistedApps();
      updateAppsBadge();
      navigate('dashboard');
      const savedSplit = loadSplitState();
      if(savedSplit && savedSplit.splitMode && savedSplit.splitRoute && SPLIT_SAFE.includes(savedSplit.splitRoute)){
        splitRoute = savedSplit.splitRoute;
        toggleSplit();
      }
      startAmbientEffects();
      setTimeout(maybeShowNotification, 6000);
    });
  }

  // Replays the full boot sequence (used by the terminal's "reboot" command)
  // and returns to the dashboard once it completes, just like a real reboot.
  function reboot(){
    ambientTimers.forEach(clearInterval);
    if(clockTimer) clearInterval(clockTimer);
    ULTRON.Globe.dispose();
    openApps = [];
    splitMode = false;
    splitRoute = null;
    clearPersistedApps();
    const shell = document.getElementById('main-shell');
    if(shell) shell.style.display = 'none';
    ULTRON.Boot.run(()=>{
      buildShell();
      document.getElementById('main-shell').style.display = 'flex';
      navigate('dashboard');
      startAmbientEffects();
    });
  }

  return {
    navigate, getSettings, updateSetting, start, buildShell, reboot,
    getOpenApps, getAllApps, openApp, closeApp: closeAppByQuery,
    openSwitcher, closeSwitcher, toggleSplit, setSplitApp,
    isSplitOpen: ()=>splitMode, getCurrentRoute: ()=>currentRoute,
    findApp,
  };
})();

document.addEventListener('DOMContentLoaded', ()=>{
  ULTRON.App.start();
});
