// ============================================================
// ULTRON OS — APP SHELL
// ============================================================
ULTRON.App = (function(){

  let currentRoute = 'dashboard';
  const DEFAULT_SETTINGS = {
    animIntensity: 80,
    glitch: true,
    lowPower: false,
    notifications: true,
    regions: ['Europe','Amériques','Afrique','Moyen-Orient','Asie','Pacifique'],
  };

  let settings = loadSettings();
  let ambientTimers = [];

  function loadSettings(){
    try{
      const saved = JSON.parse(localStorage.getItem('ultron.settings') || 'null');
      return {...DEFAULT_SETTINGS, ...(saved && typeof saved === 'object' ? saved : {})};
    }catch(_){ return {...DEFAULT_SETTINGS}; }
  }

  function saveSettings(){
    try{ localStorage.setItem('ultron.settings', JSON.stringify(settings)); }catch(_){}
  }

  const NAV_ITEMS = [
    {id:'dashboard', label:'HOME', icon:'home'},
    {id:'world', label:'WORLD', icon:'globe'},
    {id:'markets', label:'MARKETS', icon:'chart'},
    {id:'intel', label:'INTEL', icon:'signal'},
    {id:'terminal', label:'TERM', icon:'terminal'},
    {id:'more', label:'MORE', icon:'more'},
  ];

  const MORE_ITEMS = [
    {id:'conflict', label:'CONFLICT MONITOR'},
    {id:'defense', label:'DEFENSE WATCH'},
    {id:'settings', label:'SETTINGS'},
    {id:'ai', label:'AI CORE'},
    {id:'network', label:'NEURAL NETWORK'},
    {id:'surveillance', label:'SURVEILLANCE GRID'},
    {id:'archives', label:'ARCHIVES'},
    {id:'protocols', label:'PROTOCOLS'},
    {id:'system', label:'SYSTEM CORE'},
  ];

  let screensHost, navHost, moreSheet;

  function injectShellStyles(){
    const style = document.createElement('style');
    style.textContent = `
      .topbar{
        display:flex; justify-content:space-between; align-items:center;
        padding:calc(12px + var(--safe-top)) 16px 12px 16px;
        border-bottom:1px solid var(--line);
        background:linear-gradient(180deg, rgba(20,8,7,0.6), transparent);
        flex-shrink:0;
      }
      .topbar-title{display:flex; flex-direction:column;}
      .tb-name{font-size:15px; letter-spacing:0.14em; color:var(--white);}
      .tb-sub{font-size:9px; letter-spacing:0.1em; color:var(--grey-dim); margin-top:2px;}
      .tb-status{display:flex; align-items:center; gap:6px; font-size:9px; color:var(--green); letter-spacing:0.1em;}
      .tb-dot{width:6px; height:6px; border-radius:50%; background:var(--green); box-shadow:0 0 6px var(--green); animation:blinkDot 2s ease-in-out infinite;}
      @keyframes blinkDot{0%,100%{opacity:1;}50%{opacity:0.35;}}

      .app-screen-inner{position:absolute; inset:0; display:flex; flex-direction:column;}

      /* -------- bottom nav -------- */
      .bottomnav{
        position:absolute; bottom:0; left:0; right:0; z-index:20;
        display:flex; background:rgba(12,6,5,0.92); backdrop-filter:blur(10px);
        border-top:1px solid var(--line-strong);
        padding-bottom:var(--safe-bottom);
      }
      .bn-item{
        flex:1; display:flex; flex-direction:column; align-items:center; gap:4px;
        padding:10px 4px 8px; background:none; border:none; color:var(--grey-dim);
        position:relative;
      }
      .bn-item .bn-icon{width:20px; height:20px;}
      .bn-item .bn-label{font-family:var(--font-mono); font-size:8.5px; letter-spacing:0.06em;}
      .bn-item.active{color:var(--red-bright);}
      .bn-item.active::before{
        content:''; position:absolute; top:0; left:50%; transform:translateX(-50%);
        width:24px; height:2px; background:var(--red-bright); box-shadow:0 0 8px var(--red-bright);
      }

      /* -------- more sheet -------- */
      .more-sheet-bg{
        position:absolute; inset:0; background:rgba(4,2,2,0.7); z-index:30;
        opacity:0; pointer-events:none; transition:opacity 0.25s ease;
        display:flex; align-items:flex-end;
      }
      .more-sheet-bg.show{opacity:1; pointer-events:auto;}
      .more-sheet{
        width:100%; background:var(--bg-panel); border-top:1px solid var(--line-strong);
        padding:8px 16px calc(24px + var(--safe-bottom)); transform:translateY(100%);
        transition:transform 0.3s ease;
      }
      .more-sheet-bg.show .more-sheet{transform:translateY(0);}
      .more-sheet-handle{width:36px; height:3px; background:var(--line-strong); margin:10px auto 16px;}
      .more-sheet-item{
        display:flex; align-items:center; justify-content:space-between; width:100%;
        background:none; border:none; border-bottom:1px solid var(--line); color:var(--white);
        padding:16px 4px; font-family:var(--font-ui); font-size:15px; font-weight:600;
      }
      .more-sheet-item:last-child{border-bottom:none;}
      .more-sheet-item .arrow{color:var(--red); font-family:var(--font-mono);}

      /* -------- notification toast -------- */
      .toast-host{position:absolute; top:calc(10px + var(--safe-top)); left:12px; right:12px; z-index:50; display:flex; flex-direction:column; gap:8px; pointer-events:none;}
      .toast{
        background:var(--bg-panel); border:1px solid var(--line-strong); border-left:3px solid var(--red-bright);
        padding:12px 14px; box-shadow:0 8px 24px rgba(0,0,0,0.5);
        transform:translateY(-16px); opacity:0; transition:all 0.35s ease;
        pointer-events:auto;
      }
      .toast.show{transform:translateY(0); opacity:1;}
      .toast-title{font-family:var(--font-mono); font-size:9.5px; letter-spacing:0.14em; color:var(--red-bright);}
      .toast-body{font-family:var(--font-ui); font-size:13px; color:var(--white); margin-top:4px;}
    `;
    document.head.appendChild(style);
  }

  function iconFor(name){
    const icons = {
      home: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M4 11l8-7 8 7"/><path d="M6 10v9h12v-9"/></svg>`,
      globe: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.5 2.7 3.8 6 3.8 9s-1.3 6.3-3.8 9c-2.5-2.7-3.8-6-3.8-9s1.3-6.3 3.8-9z"/></svg>`,
      chart: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M4 19V9M12 19V4M20 19v-6"/><path d="M2 19h20"/></svg>`,
      signal: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M4 12a8 8 0 0 1 16 0M7 12a5 5 0 0 1 10 0"/><circle cx="12" cy="12" r="1.6" fill="currentColor" stroke="none"/></svg>`,
      terminal: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="3" y="4" width="18" height="16" rx="1"/><path d="M7 9l3 3-3 3M13 15h4"/></svg>`,
      more: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><circle cx="5" cy="12" r="1.4" fill="currentColor" stroke="none"/><circle cx="12" cy="12" r="1.4" fill="currentColor" stroke="none"/><circle cx="19" cy="12" r="1.4" fill="currentColor" stroke="none"/></svg>`,
    };
    return icons[name] || '';
  }

  function buildShell(){
    const root = document.getElementById('screens');
    root.innerHTML = `
      <div class="app-screen-inner" id="main-shell" style="display:none;">
        <div id="route-host" style="position:relative; flex:1; min-height:0;"></div>
        <div class="bottomnav" id="bottomnav"></div>
        <div class="more-sheet-bg" id="more-sheet-bg">
          <div class="more-sheet">
            <div class="more-sheet-handle"></div>
            <div id="more-sheet-items"></div>
          </div>
        </div>
        <div class="toast-host" id="toast-host"></div>
      </div>
    `;
    screensHost = document.getElementById('route-host');
    navHost = document.getElementById('bottomnav');
    moreSheet = document.getElementById('more-sheet-bg');

    navHost.innerHTML = NAV_ITEMS.map(item=>`
      <button class="bn-item" data-route="${item.id}">
        <span class="bn-icon">${iconFor(item.icon)}</span>
        <span class="bn-label mono">${item.label}</span>
      </button>
    `).join('');
    navHost.querySelectorAll('.bn-item').forEach(btn=>{
      btn.addEventListener('click', ()=>{
        if(btn.dataset.route === 'more'){
          openMoreSheet();
        } else {
          navigate(btn.dataset.route);
        }
      });
    });

    document.getElementById('more-sheet-items').innerHTML = MORE_ITEMS.map(m=>`
      <button class="more-sheet-item" data-route="${m.id}">
        <span>${m.label}</span><span class="arrow">›</span>
      </button>
    `).join('');
    document.querySelectorAll('.more-sheet-item').forEach(btn=>{
      btn.addEventListener('click', ()=>{
        closeMoreSheet();
        navigate(btn.dataset.route);
      });
    });
    moreSheet.addEventListener('click', (e)=>{
      if(e.target.id === 'more-sheet-bg') closeMoreSheet();
    });
  }

  function openMoreSheet(){ moreSheet.classList.add('show'); }
  function closeMoreSheet(){ moreSheet.classList.remove('show'); }

  function navigate(route){
    if(route === currentRoute && route !== 'terminal') {
      // still allow re-render for freshness on markets/intel etc. but skip for identical taps on same nav
    }
    currentRoute = route;

    // dispose globe if leaving world view
    if(route !== 'world'){
      ULTRON.Globe.dispose();
    }

    switch(route){
      case 'dashboard': ULTRON.Modules.renderDashboard(screensHost); break;
      case 'world': ULTRON.Modules.renderWorld(screensHost); break;
      case 'markets': ULTRON.Modules.renderMarkets(screensHost); break;
      case 'intel': ULTRON.Modules.renderIntel(screensHost); break;
      case 'conflict': ULTRON.Modules.renderConflict(screensHost); break;
      case 'defense': ULTRON.Modules.renderDefense(screensHost); break;
      case 'terminal': ULTRON.Terminal.renderInto(screensHost); break;
      case 'settings': ULTRON.Modules.renderSettings(screensHost); break;
      case 'ai': ULTRON.Modules.renderAI(screensHost); break;
      case 'network': ULTRON.Modules.renderNetwork(screensHost); break;
      case 'surveillance': ULTRON.Modules.renderSurveillance(screensHost); break;
      case 'archives': ULTRON.Modules.renderArchives(screensHost); break;
      case 'protocols': ULTRON.Modules.renderProtocols(screensHost); break;
      case 'system': ULTRON.Modules.renderSystem(screensHost); break;
      default: ULTRON.Modules.renderDashboard(screensHost);
    }

    navHost.querySelectorAll('.bn-item').forEach(btn=>{
      const isMore = MORE_ITEMS.some(m=>m.id===route) && btn.dataset.route==='more';
      btn.classList.toggle('active', btn.dataset.route === route || isMore);
    });
  }

  // ---------------- notifications ----------------
  const NOTIF_POOL = [
    {title:'ULTRON ALERT', body:'NEW GLOBAL EVENT DETECTED'},
    {title:'ULTRON ALERT', body:'MARKET VOLATILITY INCREASED'},
    {title:'ULTRON ALERT', body:'NEW INTELLIGENCE REPORT AVAILABLE'},
  ];
  function maybeShowNotification(){
    if(!settings.notifications) return;
    const n = NOTIF_POOL[Math.floor(Math.random()*NOTIF_POOL.length)];
    const host = document.getElementById('toast-host');
    if(!host) return;
    const el = document.createElement('div');
    el.className = 'toast';
    el.innerHTML = `<div class="toast-title mono">${n.title}</div><div class="toast-body">${n.body}</div>`;
    host.appendChild(el);
    requestAnimationFrame(()=>el.classList.add('show'));
    setTimeout(()=>{
      el.classList.remove('show');
      setTimeout(()=>el.remove(), 400);
    }, 4200);
  }

  // ---------------- settings ----------------
  function getSettings(){ return settings; }
  function updateSetting(key, value){
    if(!(key in DEFAULT_SETTINGS)) return;
    settings[key] = value;
    saveSettings();
    document.documentElement.dataset.lowPower = settings.lowPower ? '1' : '0';
    document.documentElement.dataset.animIntensity = String(settings.animIntensity);
  }

  // ---------------- ambient flicker ----------------
  function startAmbientEffects(){
    const flicker = document.getElementById('flicker');
    ambientTimers.forEach(clearInterval);
    ambientTimers = [];

    ambientTimers.push(setInterval(()=>{
      if(document.visibilityState !== 'visible' || settings.lowPower || !settings.glitch) return;
      if(Math.random() < 0.06 && flicker){
        flicker.style.opacity = '1';
        setTimeout(()=>{ flicker.style.opacity = '0'; }, 70 + Math.random()*90);
      }
    }, 1200));

    ambientTimers.push(setInterval(()=>{
      if(document.visibilityState === 'visible' && !settings.lowPower && settings.notifications && Math.random() < 0.5){
        maybeShowNotification();
      }
    }, 45000));
  }

  function installKeyboardShortcuts(){
    document.addEventListener('keydown', (e)=>{
      if(e.key === 'Escape'){
        closeMoreSheet();
        return;
      }
      if(e.target && /input|textarea|select/i.test(e.target.tagName)) return;
      const routes = {1:'dashboard',2:'world',3:'markets',4:'intel',5:'terminal'};
      if(e.altKey && routes[e.key]){
        e.preventDefault();
        navigate(routes[e.key]);
      }
    });
  }

  function start(){
    injectShellStyles();
    installKeyboardShortcuts();
    document.documentElement.dataset.lowPower = settings.lowPower ? '1' : '0';
    ULTRON.Boot.run(()=>{
      buildShell();
      document.getElementById('main-shell').style.display = 'flex';
      navigate('dashboard');
      startAmbientEffects();
      setTimeout(maybeShowNotification, 6000);
    });
  }

  return { navigate, getSettings, updateSetting, start, buildShell };
})();

document.addEventListener('DOMContentLoaded', ()=>{
  ULTRON.App.start();
});
