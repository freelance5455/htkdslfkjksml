// ============================================================
// ULTRON OS — WORLD VIEW (globe 3D, Three.js)
// ============================================================
ULTRON.Globe = (function(){

  let scene, camera, renderer, globeGroup, raycaster, mouse;
  let pointMeshes = [];
  let satMeshes = [];
  let animId = null;
  let container, canvas;
  let rotVX = 0, rotVY = 0.0009; // inertia
  let dragging = false, lastX = 0, lastY = 0;
  let pinchStartDist = null, camDistStart = 0;
  let camDist = 6.4;
  let targetCamDist = 6.4;
  let quality = 'high';
  let onPointTap = null;

  function latLonToVec3(lat, lon, r){
    const phi = (90 - lat) * (Math.PI/180);
    const theta = (lon + 180) * (Math.PI/180);
    return new THREE.Vector3(
      -r * Math.sin(phi) * Math.cos(theta),
      r * Math.cos(phi),
      r * Math.sin(phi) * Math.sin(theta)
    );
  }

  function detectQuality(){
    const cores = navigator.hardwareConcurrency || 4;
    const mem = navigator.deviceMemory || 4;
    const w = window.innerWidth;
    if(cores <= 4 || mem <= 3 || w < 380) return 'low';
    return 'high';
  }

  function buildWireGlobe(radius, segs){
    const geo = new THREE.SphereGeometry(radius, segs, segs);
    const wire = new THREE.WireframeGeometry(geo);
    const mat = new THREE.LineBasicMaterial({ color: 0xff2a1f, transparent:true, opacity:0.22 });
    return new THREE.LineSegments(wire, mat);
  }

  function buildParticleContinents(radius, density){
    // Simple continent silhouette approximation via a dot-density sphere
    // (procedural — not a real map dataset, purely aesthetic)
    const positions = [];
    const count = density;
    for(let i=0;i<count;i++){
      const lat = (Math.random()*180)-90;
      const lon = (Math.random()*360)-180;
      // bias toward "landy" bands to feel less random (loose sine mask)
      const landBias = Math.sin((lat+90)/180*Math.PI*2.3) * Math.cos(lon/180*Math.PI*1.7);
      if(Math.random() > (landBias*0.5+0.62)) continue;
      const v = latLonToVec3(lat, lon, radius+0.01);
      positions.push(v.x, v.y, v.z);
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
    const mat = new THREE.PointsMaterial({ color:0xff5a45, size:0.026, transparent:true, opacity:0.85 });
    return new THREE.Points(geo, mat);
  }

  function buildCore(radius){
    const geo = new THREE.SphereGeometry(radius*0.985, 48, 48);
    const mat = new THREE.MeshBasicMaterial({ color:0x0a0403, transparent:true, opacity:0.92 });
    return new THREE.Mesh(geo, mat);
  }

  function buildCountryBoundaries(radius){
    const group = new THREE.Group();
    const segments = (ULTRON.COUNTRY_BOUNDARIES || []);
    // Two layers create a subtle raised / holographic relief effect.
    const glowMat = new THREE.LineBasicMaterial({
      color:0xffffff, transparent:true, opacity:0.16, linewidth:1
    });
    const edgeMat = new THREE.LineBasicMaterial({
      color:0xffffff, transparent:true, opacity:0.78, linewidth:1
    });

    segments.forEach(seg=>{
      if(!seg || seg.length < 2) return;
      const ptsGlow = [];
      const ptsEdge = [];
      for(let i=0;i<seg.length;i++){
        const lon = seg[i][0], lat = seg[i][1];
        const a = latLonToVec3(lat, lon, radius + 0.024);
        const b = latLonToVec3(lat, lon, radius + 0.041);
        ptsGlow.push(a.x,a.y,a.z);
        ptsEdge.push(b.x,b.y,b.z);
      }
      const geoGlow = new THREE.BufferGeometry();
      geoGlow.setAttribute('position', new THREE.Float32BufferAttribute(ptsGlow,3));
      const geoEdge = new THREE.BufferGeometry();
      geoEdge.setAttribute('position', new THREE.Float32BufferAttribute(ptsEdge,3));
      group.add(new THREE.Line(geoGlow, glowMat));
      group.add(new THREE.Line(geoEdge, edgeMat));
    });
    return group;
  }

  function buildContinentBoundaries(radius){
    const group = new THREE.Group();
    const segments = (ULTRON.CONTINENT_BOUNDARIES || []);
    // Coastline / continental outlines: a brighter, slightly more raised layer
    // than the internal country borders, so the continents read clearly.
    const glowMat = new THREE.LineBasicMaterial({
      color:0xffffff, transparent:true, opacity:0.10, linewidth:1
    });
    const edgeMat = new THREE.LineBasicMaterial({
      color:0xffffff, transparent:true, opacity:0.46, linewidth:1
    });

    segments.forEach(seg=>{
      if(!seg || seg.length < 2) return;
      const ptsGlow = [];
      const ptsEdge = [];
      for(let i=0;i<seg.length;i++){
        const lon = seg[i][0], lat = seg[i][1];
        const a = latLonToVec3(lat, lon, radius + 0.052);
        const b = latLonToVec3(lat, lon, radius + 0.066);
        ptsGlow.push(a.x,a.y,a.z);
        ptsEdge.push(b.x,b.y,b.z);
      }
      const geoGlow = new THREE.BufferGeometry();
      geoGlow.setAttribute('position', new THREE.Float32BufferAttribute(ptsGlow,3));
      const geoEdge = new THREE.BufferGeometry();
      geoEdge.setAttribute('position', new THREE.Float32BufferAttribute(ptsEdge,3));
      group.add(new THREE.Line(geoGlow, glowMat));
      group.add(new THREE.Line(geoEdge, edgeMat));
    });
    return group;
  }

  function buildLatLines(radius){
    const g = new THREE.Group();
    const mat = new THREE.LineBasicMaterial({ color:0xff2a1f, transparent:true, opacity:0.09 });
    for(let i=-60;i<=60;i+=30){
      const pts = [];
      const phi = (90-i)*(Math.PI/180);
      for(let t=0;t<=64;t++){
        const theta = (t/64)*Math.PI*2;
        pts.push(new THREE.Vector3(
          -radius*Math.sin(phi)*Math.cos(theta),
          radius*Math.cos(phi),
          radius*Math.sin(phi)*Math.sin(theta)
        ));
      }
      const geo = new THREE.BufferGeometry().setFromPoints(pts);
      g.add(new THREE.Line(geo, mat));
    }
    return g;
  }

  function buildSatellites(radius){
    const defs = [
      {name:'ORBITAL NODE 01', r: radius*1.35, speed:0.18, incl:0.3, phase:0},
      {name:'ORBITAL NODE 02', r: radius*1.55, speed:-0.13, incl:1.1, phase:1.4},
      {name:'ULTRON RELAY', r: radius*1.7, speed:0.09, incl:0.7, phase:3.0},
      {name:'DEEP SPACE LINK', r: radius*1.95, speed:-0.06, incl:1.9, phase:4.6},
      {name:'GLOBAL DATA RELAY', r: radius*1.45, speed:0.15, incl:2.4, phase:2.1},
    ];
    const group = new THREE.Group();
    const meshes = [];
    defs.forEach(d=>{
      const orbitPts = [];
      for(let t=0;t<=64;t++){
        const a = (t/64)*Math.PI*2;
        const x = Math.cos(a)*d.r;
        const z = Math.sin(a)*d.r;
        const v = new THREE.Vector3(x, 0, z);
        v.applyAxisAngle(new THREE.Vector3(1,0,0), d.incl);
        orbitPts.push(v);
      }
      const orbitGeo = new THREE.BufferGeometry().setFromPoints(orbitPts);
      const orbitMat = new THREE.LineBasicMaterial({ color:0xff2a1f, transparent:true, opacity:0.16 });
      group.add(new THREE.Line(orbitGeo, orbitMat));

      const satGeo = new THREE.OctahedronGeometry(0.045, 0);
      const satMat = new THREE.MeshBasicMaterial({ color:0xff6a55 });
      const sat = new THREE.Mesh(satGeo, satMat);
      sat.userData = { ...d, angle: d.phase };
      group.add(sat);
      meshes.push(sat);
    });
    return { group, meshes };
  }

  function buildEventPoints(radius, points){
    const g = new THREE.Group();
    const colorMap = { intel:0xff4433, markets:0x2ee6a8, conflict:0xff2a1f, defense:0xffa722 };
    points.forEach(p=>{
      const pos = latLonToVec3(p.lat, p.lon, radius*1.008);
      const geo = new THREE.SphereGeometry(0.028, 8, 8);
      const mat = new THREE.MeshBasicMaterial({ color: colorMap[p.cat] || 0xff2a1f });
      const mesh = new THREE.Mesh(geo, mat);
      mesh.position.copy(pos);
      mesh.userData = { point: p };
      g.add(mesh);

      // pulse ring sprite via simple scaled ring geometry, oriented outward
      const ringGeo = new THREE.RingGeometry(0.035, 0.045, 16);
      const ringMat = new THREE.MeshBasicMaterial({ color: colorMap[p.cat] || 0xff2a1f, side:THREE.DoubleSide, transparent:true, opacity:0.55 });
      const ring = new THREE.Mesh(ringGeo, ringMat);
      ring.position.copy(pos);
      ring.lookAt(0,0,0);
      ring.userData = { pulse:true, baseScale:1, point:p };
      g.add(ring);

      pointMeshes.push(mesh);
    });
    return g;
  }

  function init(canvasEl, points){
    quality = detectQuality();
    canvas = canvasEl;
    container = canvas.parentElement;
    const w = container.clientWidth, h = container.clientHeight;

    scene = new THREE.Scene();
    camera = new THREE.PerspectiveCamera(45, w/h, 0.1, 100);
    camera.position.set(0, 0, camDist);
    targetCamDist = camDist;

    renderer = new THREE.WebGLRenderer({ canvas, antialias:true, alpha:true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, quality==='low'?1.3:2));
    renderer.setSize(w, h);

    globeGroup = new THREE.Group();
    scene.add(globeGroup);

    const radius = 2.4;
    globeGroup.add(buildCore(radius));
    globeGroup.add(buildWireGlobe(radius, quality==='low'?16:26));
    globeGroup.add(buildLatLines(radius));
    globeGroup.add(buildCountryBoundaries(radius));
    globeGroup.add(buildContinentBoundaries(radius));
    globeGroup.add(buildParticleContinents(radius, quality==='low'?900:2200));

    const { group: satGroup, meshes } = buildSatellites(radius);
    globeGroup.add(satGroup);
    satMeshes = meshes;

    globeGroup.add(buildEventPoints(radius, points));

    raycaster = new THREE.Raycaster();
    raycaster.params.Points.threshold = 0.06;
    mouse = new THREE.Vector2();

    attachInteraction(canvas);
    window.addEventListener('resize', onResize);

    animate();
  }

  function onResize(){
    if(!container || !renderer) return;
    const w = container.clientWidth, h = container.clientHeight;
    camera.aspect = w/h;
    camera.updateProjectionMatrix();
    renderer.setSize(w, h);
  }

  function attachInteraction(el){
    el.addEventListener('pointerdown', (e)=>{
      dragging = true; lastX = e.clientX; lastY = e.clientY;
      el.setPointerCapture(e.pointerId);
    });
    el.addEventListener('pointerup', (e)=>{
      dragging = false;
      const dx = Math.abs(e.clientX - lastX), dy = Math.abs(e.clientY - lastY);
      if(dx < 4 && dy < 4){ handleTap(e); }
    });
    el.addEventListener('pointermove', (e)=>{
      if(!dragging) return;
      const dx = e.clientX - lastX, dy = e.clientY - lastY;
      rotVY = dx * 0.0026;
      rotVX = dy * 0.0026;
      globeGroup.rotation.y += rotVY;
      globeGroup.rotation.x = Math.max(-1.1, Math.min(1.1, globeGroup.rotation.x + rotVX));
      lastX = e.clientX; lastY = e.clientY;
    });
    el.addEventListener('wheel', (e)=>{
      e.preventDefault();
      camDist = Math.max(3.6, Math.min(11, camDist + e.deltaY*0.003));
      targetCamDist = camDist;
      camera.position.z = camDist;
    }, { passive:false });

    // touch pinch zoom
    el.addEventListener('touchstart', (e)=>{
      if(e.touches.length === 2){
        pinchStartDist = dist2(e.touches[0], e.touches[1]);
        camDistStart = camDist;
      }
    }, { passive:true });
    el.addEventListener('touchmove', (e)=>{
      if(e.touches.length === 2 && pinchStartDist){
        const d = dist2(e.touches[0], e.touches[1]);
        const ratio = pinchStartDist / d;
        camDist = Math.max(3.6, Math.min(11, camDistStart * ratio));
        targetCamDist = camDist;
        camera.position.z = camDist;
      }
    }, { passive:true });
    el.addEventListener('touchend', ()=>{ pinchStartDist = null; });
  }

  function dist2(t1, t2){
    return Math.hypot(t1.clientX-t2.clientX, t1.clientY-t2.clientY);
  }

  function handleTap(e){
    const rect = canvas.getBoundingClientRect();
    mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
    raycaster.setFromCamera(mouse, camera);
    const hits = raycaster.intersectObjects(pointMeshes);
    if(hits.length && onPointTap){
      targetCamDist = 3.85;
      onPointTap(hits[0].object.userData.point);
    }
  }

  let clock = 0;
  function resetZoom(){ targetCamDist = 6.4; }
  function animate(){
    animId = requestAnimationFrame(animate);
    clock += 0.01;
    if(camera){
      camDist += (targetCamDist - camDist) * 0.08;
      camera.position.z = camDist;
    }

    if(!dragging){
      globeGroup.rotation.y += 0.0009;
      // damp any leftover inertia
      rotVX *= 0.94; rotVY *= 0.94;
    }

    satMeshes.forEach(sat=>{
      const d = sat.userData;
      d.angle += d.speed * 0.01;
      const x = Math.cos(d.angle) * d.r;
      const z = Math.sin(d.angle) * d.r;
      const v = new THREE.Vector3(x, 0, z);
      v.applyAxisAngle(new THREE.Vector3(1,0,0), d.incl);
      sat.position.copy(v);
      sat.rotation.x += 0.02;
      sat.rotation.y += 0.02;
    });

    globeGroup.children.forEach(child=>{
      if(child.type === 'Group'){
        child.children.forEach(c=>{
          if(c.userData && c.userData.pulse){
            const s = 1 + Math.sin(clock*2 + (c.position.x+c.position.y)*3)*0.35;
            c.scale.set(s,s,s);
          }
        });
      }
    });

    renderer.render(scene, camera);
  }

  function setOnPointTap(cb){ onPointTap = cb; }

  function pause(){
    if(animId) cancelAnimationFrame(animId);
    animId = null;
  }
  function resume(){
    if(!animId) animate();
  }

  function dispose(){
    pause();
    window.removeEventListener('resize', onResize);
  }

  return { init, setOnPointTap, resetZoom, pause, resume, dispose, onResize };
})();
