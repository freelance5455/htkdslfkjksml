// ============================================================
// ULTRON OS — DATA LAYER
// Toutes les données ci-dessous sont SIMULÉES à des fins de démonstration.
// Aucune connexion réseau réelle n'est établie. En production, ce fichier
// serait remplacé par des appels à des API de marché / actualités réelles,
// chacune horodatée et sourcée.
// ============================================================

ULTRON.DATA = (function(){

  function now(){ return Date.now(); }
  function minutesAgo(m){ return new Date(now() - m*60000); }
  function fmtTime(d){
    return d.toLocaleTimeString('fr-FR',{hour:'2-digit',minute:'2-digit'});
  }
  function fmtDateTime(d){
    return d.toLocaleDateString('fr-FR',{day:'2-digit',month:'2-digit'}) + ' — ' + fmtTime(d);
  }

  // ---------------- MARKETS ----------------
  const indices = [
    {name:'S&P 500', region:'US', base:5620.30},
    {name:'NASDAQ', region:'US', base:19840.10},
    {name:'DOW JONES', region:'US', base:41250.60},
    {name:'FTSE 100', region:'EU', base:8320.45},
    {name:'DAX', region:'EU', base:18960.80},
    {name:'CAC 40', region:'EU', base:7680.15},
    {name:'NIKKEI 225', region:'ASIA', base:38420.90},
    {name:'HANG SENG', region:'ASIA', base:17650.30},
    {name:'SHANGHAI', region:'ASIA', base:3120.55},
  ];
  const currencies = [
    {pair:'EUR/USD', base:1.0842},
    {pair:'USD/JPY', base:151.32},
    {pair:'GBP/USD', base:1.2685},
    {pair:'USD/CHF', base:0.8812},
    {pair:'USD/CNY', base:7.2410},
  ];
  const commodities = [
    {name:'OR (XAU)', unit:'/oz', base:2412.80},
    {name:'PÉTROLE BRENT', unit:'/bbl', base:82.15},
    {name:'PÉTROLE WTI', unit:'/bbl', base:78.40},
    {name:'ARGENT (XAG)', unit:'/oz', base:28.65},
    {name:'GAZ NATUREL', unit:'/MMBtu', base:2.31},
    {name:'CUIVRE', unit:'/lb', base:4.28},
  ];

  function seedRandom(seed){
    let s = seed;
    return function(){
      s = (s * 9301 + 49297) % 233280;
      return s / 233280;
    };
  }
  const rng = seedRandom(Math.floor(now()/300000)); // change every 5 min

  function genVariation(){
    return (rng() - 0.48) * 3.2;
  }

  function buildMarketSet(list, keyName){
    return list.map(item=>{
      const variation = genVariation();
      const value = item.base * (1 + variation/100);
      return {
        [keyName]: item.name || item.pair,
        region: item.region,
        unit: item.unit || '',
        value: value,
        change: variation,
        up: variation >= 0
      };
    });
  }

  function getMarketsSnapshot(){
    const idx = buildMarketSet(indices, 'name');
    const cur = buildMarketSet(currencies, 'name');
    const com = buildMarketSet(commodities, 'name');
    const all = [...idx, ...cur, ...com];
    const upCount = all.filter(x=>x.up).length;
    const downCount = all.length - upCount;
    const avgAbsChange = all.reduce((a,x)=>a+Math.abs(x.change),0)/all.length;
    let status = 'STABLE';
    if(avgAbsChange > 1.6) status = 'HIGH ACTIVITY';
    else if(avgAbsChange > 0.9) status = 'VOLATILE';
    return {
      indices: idx, currencies: cur, commodities: com,
      upCount, downCount, status, avgAbsChange,
      timestamp: new Date()
    };
  }

  // ---------------- GLOBAL INTEL ----------------
  const intelPool = [
    {title:'Sommet économique international annoncé', region:'Europe', cat:'Politique', priority:'IMPORTANT', src:'Agence de presse internationale', summary:'Les représentants de plusieurs économies majeures doivent se réunir pour discuter de coopération commerciale et de stabilité des chaînes d\'approvisionnement.'},
    {title:'Nouvelle réglementation sur les semi-conducteurs', region:'Asie', cat:'Technologie', priority:'INFO', src:'Bureau de presse gouvernemental', summary:'Un cadre réglementaire mis à jour concernant l\'exportation de composants électroniques avancés est entré en vigueur.'},
    {title:'Rencontre diplomatique au Moyen-Orient', region:'Moyen-Orient', cat:'Géopolitique', priority:'HIGH PRIORITY', src:'Correspondants régionaux', summary:'Des discussions multilatérales se poursuivent concernant la stabilité régionale, selon plusieurs sources diplomatiques.'},
    {title:'Rapport trimestriel sur la croissance mondiale', region:'Amériques', cat:'Économie', priority:'INFO', src:'Institution économique internationale', summary:'Le rapport souligne une croissance modérée dans les économies développées et une accélération dans certains marchés émergents.'},
    {title:'Avancée annoncée en calcul quantique', region:'Amériques', cat:'Technologie', priority:'INFO', src:'Laboratoire de recherche', summary:'Une équipe de recherche publique fait état de progrès dans la stabilité des qubits sur une durée prolongée.'},
    {title:'Mouvement social dans une grande métropole', region:'Europe', cat:'Politique', priority:'IMPORTANT', src:'Presse locale', summary:'Des rassemblements ont eu lieu concernant des réformes économiques annoncées récemment par les autorités.'},
    {title:'Accord commercial en cours de négociation', region:'Pacifique', cat:'Économie', priority:'INFO', src:'Ministère du commerce', summary:'Plusieurs délégations poursuivent les discussions autour d\'un accord de libre-échange régional.'},
    {title:'Alerte concernant une pénurie de ressources', region:'Afrique', cat:'Économie', priority:'HIGH PRIORITY', src:'Organisation humanitaire', summary:'Une organisation internationale signale des tensions sur l\'approvisionnement en eau dans plusieurs régions.'},
    {title:'Lancement d\'un programme spatial civil', region:'Asie', cat:'Technologie', priority:'INFO', src:'Agence spatiale nationale', summary:'Une nouvelle mission d\'observation terrestre a été confirmée pour le prochain trimestre.'},
    {title:'Tensions commerciales autour des tarifs douaniers', region:'Amériques', cat:'Économie', priority:'IMPORTANT', src:'Presse économique', summary:'De nouvelles mesures tarifaires font l\'objet de discussions entre plusieurs partenaires commerciaux.'},
    {title:'Sommet sur la sécurité énergétique', region:'Europe', cat:'Géopolitique', priority:'IMPORTANT', src:'Conseil énergétique européen', summary:'Les ministres de l\'énergie se sont réunis pour évoquer la diversification des approvisionnements.'},
    {title:'Développements dans les négociations régionales', region:'Moyen-Orient', cat:'Géopolitique', priority:'HIGH PRIORITY', src:'Sources multiples', summary:'La situation continue d\'évoluer avec des rapports contradictoires selon les sources consultées.'},
  ];

  function getIntelFeed(){
    return intelPool.map((item,i)=>({
      ...item,
      id:'intel-'+i,
      time: minutesAgo(i*17 + Math.floor(rng()*20))
    })).sort((a,b)=>b.time-a.time);
  }

  // ---------------- CONFLICT MONITOR ----------------
  const conflictZones = [
    {region:'Europe de l\'Est', status:'ACTIVE MONITORING', sourceStatus:'MULTIPLE SOURCES', lat:49, lon:32, summary:'Situation régionale suivie à partir de rapports publics multiples. Aucune information opérationnelle disponible dans cette application.'},
    {region:'Moyen-Orient', status:'ACTIVE MONITORING', sourceStatus:'DEVELOPING', lat:33, lon:44, summary:'Plusieurs zones de tension font l\'objet de rapports publics divergents. Vérification en cours.'},
    {region:'Corne de l\'Afrique', status:'ACTIVE MONITORING', sourceStatus:'MULTIPLE SOURCES', lat:8, lon:47, summary:'Rapports d\'organisations humanitaires internationales concernant des mouvements de population.'},
    {region:'Asie du Sud', status:'PASSIVE MONITORING', sourceStatus:'VERIFIED', lat:29, lon:78, summary:'Zone frontalière sous observation diplomatique de routine selon des sources gouvernementales publiques.'},
    {region:'Mer de Chine méridionale', status:'ACTIVE MONITORING', sourceStatus:'MULTIPLE SOURCES', lat:12, lon:114, summary:'Rapports concernant des activités maritimes dans la région, selon des communiqués officiels.'},
    {region:'Sahel', status:'ACTIVE MONITORING', sourceStatus:'DEVELOPING', lat:15, lon:2, summary:'Situation sécuritaire régionale suivie par plusieurs organisations internationales.'},
  ];

  function getConflictZones(){
    return conflictZones.map((z,i)=>({
      ...z, id:'conflict-'+i,
      lastUpdate: minutesAgo(i*40 + Math.floor(rng()*30))
    }));
  }

  // ---------------- DEFENSE WATCH ----------------
  const defenseNews = [
    {title:'Publication du budget de défense annuel', section:'BUDGETS', src:'Communiqué officiel', summary:'Un document budgétaire public détaille la répartition prévue des dépenses pour l\'exercice à venir.'},
    {title:'Contrat public d\'entretien annoncé', section:'PROCUREMENT', src:'Bulletin des marchés publics', summary:'Un appel d\'offres concernant la maintenance d\'équipements existants a été publié.'},
    {title:'Présentation d\'un programme aéronautique', section:'DEFENSE INDUSTRY', src:'Communiqué d\'entreprise', summary:'Un fabricant a présenté publiquement l\'avancement d\'un programme aéronautique en développement.'},
    {title:'Rapport comparatif sur les dépenses militaires', section:'HISTORICAL DATA', src:'Institut de recherche', summary:'Une étude compare l\'évolution des dépenses publiques de défense sur la dernière décennie.'},
    {title:'Salon international de la défense annoncé', section:'DEFENSE INDUSTRY', src:'Organisateur de l\'événement', summary:'Un événement rassemblant des exposants du secteur est prévu dans les prochains mois.'},
    {title:'Mise à jour de la base de données équipements', section:'EQUIPMENT DATABASE', src:'Documentation publique', summary:'Des fiches techniques d\'équipements déjà documentés publiquement ont été actualisées.'},
  ];

  const defenseBudgetHistory = [
    {year:2019, value:58},{year:2020, value:61},{year:2021, value:63},
    {year:2022, value:69},{year:2023, value:75},{year:2024, value:80},{year:2025, value:84}
  ];

  function getDefenseFeed(){
    return defenseNews.map((n,i)=>({
      ...n, id:'defense-'+i,
      time: minutesAgo(i*55 + Math.floor(rng()*25))
    }));
  }

  // ---------------- GLOBE EVENT POINTS ----------------
  const globePoints = [
    {lat:48.85, lon:2.35, label:'Paris', cat:'intel', type:'CAPITALE / CENTRE DE RENSEIGNEMENT', country:'France', region:'Europe', status:'ACTIF', importance:'ÉLEVÉE', description:'Point de données représentant Paris et son environnement stratégique.', metrics:[['COORDONNÉES','48.85° N · 2.35° E'],['RÉGION','Europe'],['TYPE','Capitale / centre de renseignement'],['STATUT','Actif']]},
    {lat:40.71, lon:-74.0, label:'New York', cat:'markets', type:'CENTRE FINANCIER', country:'États-Unis', region:'Amériques', status:'ACTIF', importance:'CRITIQUE', description:'Nœud représentant un important centre financier et économique mondial.', metrics:[['COORDONNÉES','40.71° N · 74.00° O'],['RÉGION','Amériques'],['TYPE','Centre financier'],['STATUT','Actif']]},
    {lat:35.68, lon:139.69, label:'Tokyo', cat:'markets', type:'CENTRE FINANCIER / TECHNOLOGIQUE', country:'Japon', region:'Asie', status:'ACTIF', importance:'ÉLEVÉE', description:'Nœud représentant un centre financier et technologique majeur.', metrics:[['COORDONNÉES','35.68° N · 139.69° E'],['RÉGION','Asie'],['TYPE','Finance / technologie'],['STATUT','Actif']]},
    {lat:51.50, lon:-0.12, label:'Londres', cat:'markets', type:'CENTRE FINANCIER', country:'Royaume-Uni', region:'Europe', status:'ACTIF', importance:'ÉLEVÉE', description:'Nœud représentant un centre financier international.', metrics:[['COORDONNÉES','51.50° N · 0.12° O'],['RÉGION','Europe'],['TYPE','Centre financier'],['STATUT','Actif']]},
    {lat:39.90, lon:116.40, label:'Pékin', cat:'intel', type:'CAPITALE / RENSEIGNEMENT', country:'Chine', region:'Asie', status:'ACTIF', importance:'CRITIQUE', description:'Point représentant une capitale et un centre stratégique national.', metrics:[['COORDONNÉES','39.90° N · 116.40° E'],['RÉGION','Asie'],['TYPE','Capitale / renseignement'],['STATUT','Actif']]},
    {lat:28.61, lon:77.20, label:'New Delhi', cat:'intel', type:'CAPITALE / RENSEIGNEMENT', country:'Inde', region:'Asie', status:'ACTIF', importance:'ÉLEVÉE', description:'Point représentant la capitale indienne et un nœud stratégique régional.', metrics:[['COORDONNÉES','28.61° N · 77.20° E'],['RÉGION','Asie'],['TYPE','Capitale / renseignement'],['STATUT','Actif']]},
    {lat:-33.86, lon:151.20, label:'Sydney', cat:'intel', type:'CENTRE STRATÉGIQUE', country:'Australie', region:'Pacifique', status:'ACTIF', importance:'MOYENNE', description:'Point représentant un nœud stratégique dans la région indo-pacifique.', metrics:[['COORDONNÉES','33.86° S · 151.20° E'],['RÉGION','Pacifique'],['TYPE','Centre stratégique'],['STATUT','Actif']]},
    {lat:55.75, lon:37.61, label:'Moscou', cat:'conflict', type:'ZONE DE TENSION / CAPITALE', country:'Russie', region:'Europe', status:'SURVEILLANCE', importance:'CRITIQUE', description:'Point de surveillance stratégique associé à une zone de tension géopolitique.', metrics:[['COORDONNÉES','55.75° N · 37.61° E'],['RÉGION','Europe'],['TYPE','Tension / capitale'],['STATUT','Surveillance']]},
    {lat:31.76, lon:35.21, label:'Jérusalem', cat:'conflict', type:'ZONE DE TENSION', country:'Israël / Palestine', region:'Moyen-Orient', status:'SURVEILLANCE', importance:'CRITIQUE', description:'Point de surveillance représentant une zone à forte sensibilité géopolitique.', metrics:[['COORDONNÉES','31.76° N · 35.21° E'],['RÉGION','Moyen-Orient'],['TYPE','Zone de tension'],['STATUT','Surveillance']]},
    {lat:6.5, lon:3.35, label:'Lagos', cat:'defense', type:'NŒUD STRATÉGIQUE / DÉFENSE', country:'Nigeria', region:'Afrique', status:'ACTIF', importance:'MOYENNE', description:'Point représentant un important nœud urbain et stratégique régional.', metrics:[['COORDONNÉES','6.50° N · 3.35° E'],['RÉGION','Afrique'],['TYPE','Stratégie / défense'],['STATUT','Actif']]},
    {lat:-23.55, lon:-46.63, label:'São Paulo', cat:'markets', type:'CENTRE ÉCONOMIQUE', country:'Brésil', region:'Amériques', status:'ACTIF', importance:'ÉLEVÉE', description:'Nœud représentant un centre économique majeur d’Amérique du Sud.', metrics:[['COORDONNÉES','23.55° S · 46.63° O'],['RÉGION','Amériques'],['TYPE','Centre économique'],['STATUT','Actif']]},
    {lat:1.35, lon:103.82, label:'Singapour', cat:'markets', type:'CENTRE FINANCIER / LOGISTIQUE', country:'Singapour', region:'Asie', status:'ACTIF', importance:'ÉLEVÉE', description:'Nœud représentant un centre financier et logistique stratégique.', metrics:[['COORDONNÉES','1.35° N · 103.82° E'],['RÉGION','Asie'],['TYPE','Finance / logistique'],['STATUT','Actif']]},
    {lat:50.45, lon:30.52, label:'Kyiv', cat:'conflict', type:'ZONE DE CONFLIT / CAPITALE', country:'Ukraine', region:'Europe', status:'SURVEILLANCE', importance:'CRITIQUE', description:'Point de surveillance représentant une zone directement concernée par un conflit.', metrics:[['COORDONNÉES','50.45° N · 30.52° E'],['RÉGION','Europe'],['TYPE','Conflit / capitale'],['STATUT','Surveillance']]},
    {lat:24.71, lon:46.68, label:'Riyad', cat:'defense', type:'CAPITALE / DÉFENSE', country:'Arabie saoudite', region:'Moyen-Orient', status:'ACTIF', importance:'ÉLEVÉE', description:'Point représentant une capitale et un centre stratégique de défense.', metrics:[['COORDONNÉES','24.71° N · 46.68° E'],['RÉGION','Moyen-Orient'],['TYPE','Capitale / défense'],['STATUT','Actif']]},
  ];

  return {
    getMarketsSnapshot, getIntelFeed, getConflictZones, getDefenseFeed,
    defenseBudgetHistory, globePoints, fmtDateTime, fmtTime
  };
})();
