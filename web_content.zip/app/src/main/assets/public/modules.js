// ============================================================
// ULTRON OS — UI MODULES
// ============================================================
ULTRON.Modules = (function(){
  const D = ULTRON.DATA;

  function el(html){
    const t = document.createElement('template');
    t.innerHTML = html.trim();
    return t.content.firstElementChild;
  }

  function topbar(title, sub){
    return `
      <div class="topbar">
        <div class="topbar-title">
          <span class="tb-name disp">${title}</span>
          ${sub ? `<span class="tb-sub mono">${sub}</span>` : ''}
        </div>
        <div class="tb-status">
          <span class="tb-dot"></span><span class="mono">LIVE</span>
        </div>
      </div>`;
  }

  // ============ DASHBOARD ============
  function renderDashboard(host){
    host.innerHTML = `
      <style>
        .dash{display:flex; flex-direction:column; height:100%; overflow:hidden;}
        .dash-scroll{flex:1; overflow-y:auto; padding:0 16px calc(100px + var(--safe-bottom)) 16px;}
        .dash-brand{
          text-align:center; padding:18px 0 6px;
        }
        .dash-brand .brand-name{
          font-family:var(--font-display); font-weight:900; font-size:22px;
          letter-spacing:0.32em; color:var(--white);
          text-shadow:0 0 16px rgba(255,68,51,0.45);
        }
        .dash-flags{
          display:flex; justify-content:center; gap:14px; margin-top:8px; flex-wrap:wrap;
        }
        .dash-flag{
          font-family:var(--font-mono); font-size:9px; letter-spacing:0.1em; color:var(--grey);
          display:flex; align-items:center; gap:5px;
        }
        .dash-flag .dot{width:5px; height:5px; border-radius:50%; background:var(--green); box-shadow:0 0 6px var(--green);}
        .dash-core-zone{padding:18px 0 6px; position:relative;}
        .dash-core-status{
          text-align:center; margin-top:6px;
          font-family:var(--font-mono); font-size:10px; letter-spacing:0.18em; color:var(--red);
        }
        .dash-shortcuts{
          display:grid; grid-template-columns:repeat(3,1fr); gap:10px; margin-top:22px;
        }
        .shortcut-btn{
          background:var(--bg-panel); border:1px solid var(--line);
          padding:14px 8px; display:flex; flex-direction:column; align-items:center; gap:8px;
          color:var(--white); text-align:center; position:relative; overflow:hidden;
        }
        .shortcut-btn:active{background:var(--bg-panel-2); border-color:var(--line-strong);}
        .shortcut-btn .sc-icon{width:22px; height:22px; color:var(--red-bright);}
        .shortcut-btn .sc-label{font-family:var(--font-mono); font-size:9.5px; letter-spacing:0.08em;}
        .shortcut-btn::before{
          content:''; position:absolute; top:0; left:0; right:0; height:2px;
          background:var(--red-dim);
        }
        .dash-summary{margin-top:26px; display:flex; flex-direction:column; gap:10px;}
        .sum-card{
          background:var(--bg-panel); border:1px solid var(--line); padding:14px;
          display:flex; justify-content:space-between; align-items:center;
        }
        .sum-card .sum-left .sum-title{
          font-family:var(--font-mono); font-size:10px; letter-spacing:0.14em; color:var(--grey);
        }
        .sum-card .sum-left .sum-value{
          font-family:var(--font-display); font-size:17px; margin-top:4px; color:var(--white);
        }
        .sum-card .sum-badge{
          font-family:var(--font-mono); font-size:10px; padding:5px 10px;
          border:1px solid var(--line-strong); letter-spacing:0.08em;
        }
        .badge-up{color:var(--green); border-color:rgba(46,230,168,0.3);}
        .badge-down{color:var(--red-bright); border-color:var(--line-strong);}
        .badge-warn{color:var(--amber); border-color:rgba(255,167,34,0.3);}
        .section-label{
          font-family:var(--font-mono); font-size:10px; letter-spacing:0.18em; color:var(--grey-dim);
          margin:26px 0 10px; display:flex; align-items:center; gap:8px;
        }
        .section-label::after{
          content:''; flex:1; height:1px;
          background:repeating-linear-gradient(90deg, var(--red-dim) 0 6px, transparent 6px 10px);
        }
      </style>
      <div class="dash">
        ${topbar('ULTRON OS','COMMAND CENTER')}
        <div class="dash-scroll">
          <div class="dash-brand">
            <div class="dash-flags">
              <span class="dash-flag"><span class="dot"></span>SYSTEM ONLINE</span>
              <span class="dash-flag"><span class="dot"></span>DATA STREAM ACTIVE</span>
              <span class="dash-flag"><span class="dot"></span>NETWORK CONNECTED</span>
            </div>
          </div>
          <div class="dash-core-zone">
            <div id="dash-core-mount"></div>
            <div class="dash-core-status mono" id="dash-core-status">CORE OPERATIONAL — MONITORING GLOBAL FEEDS</div>
          </div>

          <div class="dash-shortcuts" id="dash-shortcuts"></div>

          <div class="section-label">SYSTEM SUMMARY</div>
          <div class="dash-summary" id="dash-summary"></div>
        </div>
      </div>
    `;

    ULTRON.Core.mount(host.querySelector('#dash-core-mount'));

    const shortcuts = [
      {id:'world', label:'WORLD VIEW', icon: iconGlobe()},
      {id:'markets', label:'MARKETS', icon: iconChart()},
      {id:'intel', label:'GLOBAL INTEL', icon: iconSignal()},
      {id:'defense', label:'DEFENSE WATCH', icon: iconShield()},
      {id:'terminal', label:'TERMINAL', icon: iconTerminal()},
      {id:'settings', label:'SETTINGS', icon: iconGear()},
    ];
    const scHost = host.querySelector('#dash-shortcuts');
    shortcuts.forEach(s=>{
      const btn = el(`<button class="shortcut-btn" data-nav="${s.id}">
        <span class="sc-icon">${s.icon}</span>
        <span class="sc-label">${s.label}</span>
      </button>`);
      btn.addEventListener('click', ()=> ULTRON.App.navigate(s.id));
      scHost.appendChild(btn);
    });

    refreshDashboardSummary(host);
  }

  function refreshDashboardSummary(host){
    const summary = host.querySelector('#dash-summary');
    if(!summary) return;
    const m = D.getMarketsSnapshot();
    const intel = D.getIntelFeed();
    const conflicts = D.getConflictZones();
    const defense = D.getDefenseFeed();

    summary.innerHTML = `
      <div class="sum-card" data-nav="markets">
        <div class="sum-left">
          <div class="sum-title mono">MARKETS</div>
          <div class="sum-value disp">${m.upCount} ▲ / ${m.downCount} ▼</div>
        </div>
        <div class="sum-badge ${m.status==='STABLE'?'badge-up':m.status==='VOLATILE'?'badge-warn':'badge-down'}">${m.status}</div>
      </div>
      <div class="sum-card" data-nav="intel">
        <div class="sum-left">
          <div class="sum-title mono">GLOBAL EVENTS</div>
          <div class="sum-value disp">${intel.length} REPORTS</div>
        </div>
        <div class="sum-badge badge-up">UPDATED</div>
      </div>
      <div class="sum-card" data-nav="defense">
        <div class="sum-left">
          <div class="sum-title mono">DEFENSE WATCH</div>
          <div class="sum-value disp">${defense.length} PUBLIC ITEMS</div>
        </div>
        <div class="sum-badge badge-up">MONITORING</div>
      </div>
      <div class="sum-card" data-nav="world">
        <div class="sum-left">
          <div class="sum-title mono">SYSTEM</div>
          <div class="sum-value disp">${conflicts.length} ZONES TRACKED</div>
        </div>
        <div class="sum-badge badge-up">ONLINE</div>
      </div>
    `;
    summary.querySelectorAll('[data-nav]').forEach(c=>{
      c.addEventListener('click', ()=> ULTRON.App.navigate(c.dataset.nav));
    });
  }

  // ============ MARKETS ============
  function renderMarkets(host){
    const m = D.getMarketsSnapshot();
    host.innerHTML = `
      <style>
        .mk-wrap{display:flex; flex-direction:column; height:100%;}
        .mk-scroll{flex:1; overflow-y:auto; padding:12px 16px calc(100px + var(--safe-bottom)) 16px;}
        .mk-status-card{
          background:var(--bg-panel); border:1px solid var(--line-strong); padding:16px; margin-bottom:18px;
          text-align:center;
        }
        .mk-status-label{font-family:var(--font-mono); font-size:10px; letter-spacing:0.2em; color:var(--grey);}
        .mk-status-value{
          font-family:var(--font-display); font-size:24px; margin-top:8px; letter-spacing:0.06em;
        }
        .mk-status-value.stable{color:var(--green);}
        .mk-status-value.volatile{color:var(--amber);}
        .mk-status-value.high{color:var(--red-bright);}
        .mk-status-time{font-family:var(--font-mono); font-size:9px; color:var(--grey-dim); margin-top:8px;}
        .mk-tabs{display:flex; gap:6px; margin-bottom:14px;}
        .mk-tab{
          flex:1; background:var(--bg-panel); border:1px solid var(--line); color:var(--grey);
          font-family:var(--font-mono); font-size:10px; letter-spacing:0.08em; padding:9px 4px;
        }
        .mk-tab.active{color:var(--red-bright); border-color:var(--line-strong); background:var(--bg-panel-2);}
        .mk-row{
          display:flex; justify-content:space-between; align-items:center;
          padding:12px 4px; border-bottom:1px solid var(--line);
        }
        .mk-row .mk-name{font-family:var(--font-ui); font-weight:600; font-size:14px;}
        .mk-row .mk-region{font-family:var(--font-mono); font-size:9px; color:var(--grey-dim); margin-top:2px;}
        .mk-row .mk-right{text-align:right;}
        .mk-row .mk-value{font-family:var(--font-mono); font-size:13px; color:var(--white);}
        .mk-row .mk-change{font-family:var(--font-mono); font-size:11px; margin-top:3px;}
        .mk-change.up{color:var(--green);}
        .mk-change.down{color:var(--red-bright);}
        .mk-disclaimer{
          margin-top:22px; padding:12px; border:1px solid var(--line); font-family:var(--font-mono);
          font-size:10px; color:var(--grey-dim); line-height:1.6;
        }
      </style>
      <div class="mk-wrap">
        ${topbar('MARKETS','GLOBAL FINANCIAL FEED')}
        <div class="mk-scroll">
          <div class="mk-status-card">
            <div class="mk-status-label mono">GLOBAL MARKET STATUS</div>
            <div class="mk-status-value ${m.status==='STABLE'?'stable':m.status==='VOLATILE'?'volatile':'high'} disp">${m.status}</div>
            <div class="mk-status-time mono">LAST UPDATE — ${D.fmtDateTime(m.timestamp)}</div>
          </div>
          <div class="mk-tabs">
            <button class="mk-tab active" data-tab="indices">INDICES</button>
            <button class="mk-tab" data-tab="currencies">DEVISES</button>
            <button class="mk-tab" data-tab="commodities">MATIÈRES 1ÈRES</button>
          </div>
          <div id="mk-list"></div>
          <div class="mk-disclaimer">
            Cette synthèse est générée par ULTRON OS à titre indicatif et informatif uniquement.
            Elle ne constitue pas un conseil en investissement. Les valeurs affichées sont simulées
            à des fins de démonstration.
          </div>
        </div>
      </div>
    `;

    function drawList(tab){
      const list = host.querySelector('#mk-list');
      let data, keyLabel;
      if(tab==='indices'){ data=m.indices; }
      else if(tab==='currencies'){ data=m.currencies; }
      else { data=m.commodities; }

      list.innerHTML = data.map(item=>`
        <div class="mk-row">
          <div>
            <div class="mk-name">${item.name}</div>
            ${item.region ? `<div class="mk-region mono">${item.region}</div>` : ''}
          </div>
          <div class="mk-right">
            <div class="mk-value mono">${item.value.toFixed(item.value>1000?2:4).replace(/\B(?=(\d{3})+(?!\d))/g,'')} ${item.unit||''}</div>
            <div class="mk-change ${item.up?'up':'down'} mono">${item.up?'▲':'▼'} ${Math.abs(item.change).toFixed(2)}%</div>
          </div>
        </div>
      `).join('');
    }
    drawList('indices');
    host.querySelectorAll('.mk-tab').forEach(btn=>{
      btn.addEventListener('click', ()=>{
        host.querySelectorAll('.mk-tab').forEach(b=>b.classList.remove('active'));
        btn.classList.add('active');
        drawList(btn.dataset.tab);
      });
    });
  }

  // ============ GLOBAL INTEL ============
  function renderIntel(host){
    const feed = D.getIntelFeed();
    const regions = ['Toutes','Europe','Amériques','Afrique','Moyen-Orient','Asie','Pacifique'];
    host.innerHTML = `
      <style>
        .in-wrap{display:flex; flex-direction:column; height:100%;}
        .in-scroll{flex:1; overflow-y:auto; padding:12px 16px calc(100px + var(--safe-bottom)) 16px;}
        .in-filters{display:flex; gap:6px; overflow-x:auto; padding-bottom:12px; margin-bottom:6px;}
        .in-filter{
          flex-shrink:0; background:var(--bg-panel); border:1px solid var(--line); color:var(--grey);
          font-family:var(--font-mono); font-size:10px; padding:8px 12px; white-space:nowrap;
        }
        .in-filter.active{color:var(--red-bright); border-color:var(--line-strong);}
        .in-card{
          background:var(--bg-panel); border:1px solid var(--line); padding:14px; margin-bottom:10px;
          position:relative;
        }
        .in-card-top{display:flex; justify-content:space-between; align-items:flex-start; gap:10px;}
        .in-priority{
          font-family:var(--font-mono); font-size:9px; letter-spacing:0.08em; padding:3px 8px;
          border:1px solid; flex-shrink:0;
        }
        .pri-info{color:var(--grey); border-color:var(--line);}
        .pri-important{color:var(--amber); border-color:rgba(255,167,34,0.35);}
        .pri-high{color:var(--red-bright); border-color:var(--line-strong);}
        .in-title{font-family:var(--font-ui); font-weight:600; font-size:15px; margin-top:8px; line-height:1.35;}
        .in-meta{
          display:flex; gap:10px; margin-top:8px; font-family:var(--font-mono); font-size:9.5px; color:var(--grey-dim);
          flex-wrap:wrap;
        }
        .in-summary{font-size:12.5px; color:var(--grey); line-height:1.6; margin-top:8px;}
        .in-src{font-family:var(--font-mono); font-size:9px; color:var(--grey-dim); margin-top:10px; border-top:1px solid var(--line); padding-top:8px;}
      </style>
      <div class="in-wrap">
        ${topbar('GLOBAL INTEL','ACTUALITÉS INTERNATIONALES')}
        <div class="in-scroll">
          <div class="in-filters" id="in-filters">
            ${regions.map((r,i)=>`<button class="in-filter ${i===0?'active':''}" data-region="${r}">${r.toUpperCase()}</button>`).join('')}
          </div>
          <div id="in-list"></div>
        </div>
      </div>
    `;

    function draw(region){
      const list = host.querySelector('#in-list');
      const filtered = region==='Toutes' ? feed : feed.filter(f=>f.region===region);
      if(!filtered.length){
        list.innerHTML = `<div class="mk-disclaimer" style="margin-top:20px">Aucune information disponible pour cette région actuellement.</div>`;
        return;
      }
      list.innerHTML = filtered.map(item=>{
        const priClass = item.priority==='INFO'?'pri-info':item.priority==='IMPORTANT'?'pri-important':'pri-high';
        return `
        <div class="in-card">
          <div class="in-card-top">
            <span class="in-priority ${priClass} mono">${item.priority}</span>
          </div>
          <div class="in-title">${item.title}</div>
          <div class="in-meta">
            <span>📍 ${item.region}</span>
            <span>${item.cat}</span>
            <span>${D.fmtDateTime(item.time)}</span>
          </div>
          <div class="in-summary">${item.summary}</div>
          <div class="in-src mono">SOURCE — ${item.src}</div>
        </div>`;
      }).join('');
    }
    draw('Toutes');
    host.querySelectorAll('.in-filter').forEach(btn=>{
      btn.addEventListener('click', ()=>{
        host.querySelectorAll('.in-filter').forEach(b=>b.classList.remove('active'));
        btn.classList.add('active');
        draw(btn.dataset.region);
      });
    });
  }

  // ============ CONFLICT MONITOR ============
  function renderConflict(host){
    const zones = D.getConflictZones();
    host.innerHTML = `
      <style>
        .cf-wrap{display:flex; flex-direction:column; height:100%;}
        .cf-scroll{flex:1; overflow-y:auto; padding:12px 16px calc(100px + var(--safe-bottom)) 16px;}
        .cf-notice{
          background:var(--bg-panel-2); border:1px solid var(--line-strong); padding:12px 14px; margin-bottom:16px;
          font-family:var(--font-mono); font-size:10px; color:var(--grey); line-height:1.7;
        }
        .cf-notice b{color:var(--red-bright);}
        .cf-card{background:var(--bg-panel); border:1px solid var(--line); padding:14px; margin-bottom:10px;}
        .cf-region{font-family:var(--font-display); font-size:15px; color:var(--white);}
        .cf-fields{margin-top:10px; display:flex; flex-direction:column; gap:6px;}
        .cf-field{display:flex; justify-content:space-between; font-family:var(--font-mono); font-size:10.5px;}
        .cf-field .k{color:var(--grey-dim); letter-spacing:0.06em;}
        .cf-field .v{color:var(--white);}
        .v.status-active{color:var(--red-bright);}
        .v.status-passive{color:var(--amber);}
        .v.src-verified{color:var(--green);}
        .v.src-multiple{color:var(--amber);}
        .v.src-developing{color:var(--grey);}
        .cf-summary{margin-top:10px; font-size:12px; color:var(--grey); line-height:1.6;}
      </style>
      <div class="cf-wrap">
        ${topbar('CONFLICT MONITOR','VEILLE GÉOPOLITIQUE PUBLIQUE')}
        <div class="cf-scroll">
          <div class="cf-notice">
            ULTRON OS agit comme un outil de <b>veille et de consultation d'informations publiques</b>.
            Ce module ne fournit aucune donnée opérationnelle, aucun ciblage et aucune information sensible
            non publique. Il ne doit pas être utilisé comme un outil militaire.
          </div>
          ${zones.map(z=>`
            <div class="cf-card">
              <div class="cf-region">${z.region}</div>
              <div class="cf-fields">
                <div class="cf-field"><span class="k">STATUS</span><span class="v ${z.status.includes('ACTIVE')?'status-active':'status-passive'}">${z.status}</span></div>
                <div class="cf-field"><span class="k">LAST UPDATE</span><span class="v mono">${D.fmtDateTime(z.lastUpdate)}</span></div>
                <div class="cf-field"><span class="k">PUBLIC REPORTS</span><span class="v">AVAILABLE</span></div>
                <div class="cf-field"><span class="k">SOURCE STATUS</span><span class="v ${z.sourceStatus==='VERIFIED'?'src-verified':z.sourceStatus==='MULTIPLE SOURCES'?'src-multiple':'src-developing'}">${z.sourceStatus}</span></div>
              </div>
              <div class="cf-summary">${z.summary}</div>
            </div>
          `).join('')}
        </div>
      </div>
    `;
  }

  // ============ DEFENSE WATCH ============
  function renderDefense(host){
    const feed = D.getDefenseFeed();
    const hist = D.defenseBudgetHistory;
    const maxVal = Math.max(...hist.map(h=>h.value));
    const sections = ['DEFENSE INDUSTRY','PROCUREMENT','BUDGETS','EQUIPMENT DATABASE','HISTORICAL DATA'];
    host.innerHTML = `
      <style>
        .df-wrap{display:flex; flex-direction:column; height:100%;}
        .df-scroll{flex:1; overflow-y:auto; padding:12px 16px calc(100px + var(--safe-bottom)) 16px;}
        .df-notice{
          background:var(--bg-panel-2); border:1px solid var(--line-strong); padding:12px 14px; margin-bottom:16px;
          font-family:var(--font-mono); font-size:10px; color:var(--grey); line-height:1.7;
        }
        .df-chart{background:var(--bg-panel); border:1px solid var(--line); padding:16px; margin-bottom:18px;}
        .df-chart-title{font-family:var(--font-mono); font-size:10px; letter-spacing:0.14em; color:var(--grey); margin-bottom:14px;}
        .df-bars{display:flex; align-items:flex-end; gap:8px; height:110px;}
        .df-bar-col{flex:1; display:flex; flex-direction:column; align-items:center; gap:6px;}
        .df-bar{width:100%; background:linear-gradient(180deg, var(--red-bright), var(--red-dim)); box-shadow:0 0 8px rgba(255,42,31,0.3);}
        .df-bar-year{font-family:var(--font-mono); font-size:8.5px; color:var(--grey-dim);}
        .df-section-tabs{display:flex; gap:6px; overflow-x:auto; margin-bottom:12px; padding-bottom:4px;}
        .df-section-tab{
          flex-shrink:0; background:var(--bg-panel); border:1px solid var(--line); color:var(--grey);
          font-family:var(--font-mono); font-size:9.5px; padding:8px 10px; white-space:nowrap;
        }
        .df-section-tab.active{color:var(--red-bright); border-color:var(--line-strong);}
        .df-card{background:var(--bg-panel); border:1px solid var(--line); padding:14px; margin-bottom:10px;}
        .df-card-section{font-family:var(--font-mono); font-size:9px; color:var(--red); letter-spacing:0.1em;}
        .df-card-title{font-family:var(--font-ui); font-weight:600; font-size:14px; margin-top:6px;}
        .df-card-summary{font-size:12px; color:var(--grey); margin-top:6px; line-height:1.6;}
        .df-card-meta{font-family:var(--font-mono); font-size:9px; color:var(--grey-dim); margin-top:8px;}
      </style>
      <div class="df-wrap">
        ${topbar('DEFENSE WATCH','VEILLE PUBLIQUE — DÉFENSE & INDUSTRIE')}
        <div class="df-scroll">
          <div class="df-notice">
            Ce module recense exclusivement des <b>informations publiques</b> (communiqués, budgets officiels,
            marchés publics). ULTRON OS ne conçoit, ne simule et ne fournit aucune fonction opérationnelle
            ou militaire.
          </div>
          <div class="df-chart">
            <div class="df-chart-title mono">ÉVOLUTION BUDGÉTAIRE (INDICATIF, Md$)</div>
            <div class="df-bars">
              ${hist.map(h=>`
                <div class="df-bar-col">
                  <div class="df-bar" style="height:${(h.value/maxVal*90)}px"></div>
                  <div class="df-bar-year mono">${h.year}</div>
                </div>
              `).join('')}
            </div>
          </div>
          <div class="df-section-tabs" id="df-tabs">
            <button class="df-section-tab active" data-sec="ALL">TOUT</button>
            ${sections.map(s=>`<button class="df-section-tab" data-sec="${s}">${s}</button>`).join('')}
          </div>
          <div id="df-list"></div>
        </div>
      </div>
    `;

    function draw(sec){
      const list = host.querySelector('#df-list');
      const filtered = sec==='ALL' ? feed : feed.filter(f=>f.section===sec);
      list.innerHTML = filtered.map(item=>`
        <div class="df-card">
          <div class="df-card-section mono">${item.section}</div>
          <div class="df-card-title">${item.title}</div>
          <div class="df-card-summary">${item.summary}</div>
          <div class="df-card-meta mono">SOURCE — ${item.src} · ${D.fmtDateTime(item.time)}</div>
        </div>
      `).join('');
    }
    draw('ALL');
    host.querySelectorAll('.df-section-tab').forEach(btn=>{
      btn.addEventListener('click', ()=>{
        host.querySelectorAll('.df-section-tab').forEach(b=>b.classList.remove('active'));
        btn.classList.add('active');
        draw(btn.dataset.sec);
      });
    });
  }

  // ============ WORLD VIEW ============
  function renderWorld(host){
    host.innerHTML = `
      <style>
        .wv-wrap{display:flex; flex-direction:column; height:100%; position:relative;}
        .wv-canvas-zone{flex:1; position:relative;}
        .wv-canvas-zone canvas{width:100%; height:100%; display:block; touch-action:none;}
        .wv-hint{
          position:absolute; bottom:14px; left:50%; transform:translateX(-50%);
          font-family:var(--font-mono); font-size:9px; color:var(--grey-dim); letter-spacing:0.1em;
          background:rgba(10,5,5,0.6); padding:6px 12px; border:1px solid var(--line);
        }
        .wv-legend{
          position:absolute; top:12px; left:12px; display:flex; flex-direction:column; gap:6px;
          background:rgba(10,5,5,0.55); border:1px solid var(--line); padding:10px 12px;
        }
        .wv-legend-item{display:flex; align-items:center; gap:6px; font-family:var(--font-mono); font-size:9px; color:var(--grey);}
        .wv-legend-dot{width:6px; height:6px; border-radius:50%;}
        .wv-orbital-label{
          position:absolute; top:12px; right:12px; text-align:right;
          font-family:var(--font-mono); font-size:9px; color:var(--red); letter-spacing:0.1em;
          background:rgba(10,5,5,0.55); border:1px solid var(--line); padding:10px 12px;
        }
        .wv-orbital-label .ol-title{color:var(--grey); margin-bottom:4px;}
        .wv-modal-bg{
          position:absolute; inset:0; background:rgba(4,2,2,0.7); display:flex; align-items:flex-end;
          opacity:0; pointer-events:none; transition:opacity 0.25s ease; z-index:10;
        }
        .wv-modal-bg.show{opacity:1; pointer-events:auto;}
        .wv-modal{
          width:100%; background:var(--bg-panel); border-top:1px solid var(--line-strong);
          padding:20px 18px calc(20px + var(--safe-bottom)); transform:translateY(100%);
          transition:transform 0.3s ease;
        }
        .wv-modal-bg.show .wv-modal{transform:translateY(0);}
        .wv-modal-title{font-family:var(--font-display); font-size:17px; color:var(--white);}
        .wv-modal-type{font-family:var(--font-mono);font-size:10px;color:var(--red-bright);letter-spacing:.08em;margin-top:6px}
        .wv-modal-desc{font-family:var(--font-ui);font-size:14px;line-height:1.45;color:var(--grey);margin:12px 0 14px;max-width:900px}
        .wv-modal-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:7px;margin-bottom:12px}
        .wv-info-cell{border:1px solid var(--line);background:rgba(255,42,31,.035);padding:9px 10px}
        .wv-info-key{font-family:var(--font-mono);font-size:8px;color:var(--grey-dim);letter-spacing:.12em}
        .wv-info-val{font-family:var(--font-mono);font-size:11px;color:var(--white);margin-top:4px}
        .wv-modal-meta{font-family:var(--font-mono); font-size:10px; color:var(--grey-dim); margin-top:8px;}
        .wv-modal-close{
          position:absolute; top:14px; right:14px; background:none; border:1px solid var(--line);
          color:var(--grey); width:28px; height:28px; font-size:14px;
        }
      </style>
      <div class="wv-wrap">
        ${topbar('WORLD VIEW','GLOBE INTERACTIF — DONNÉES PUBLIQUES')}
        <div class="wv-canvas-zone">
          <canvas id="wv-canvas"></canvas>
          <div class="wv-legend">
            <div class="wv-legend-item"><span class="wv-legend-dot" style="background:#ff4433"></span>INTEL</div>
            <div class="wv-legend-item"><span class="wv-legend-dot" style="background:#2ee6a8"></span>MARCHÉS</div>
            <div class="wv-legend-item"><span class="wv-legend-dot" style="background:#ff2a1f"></span>CONFLITS</div>
            <div class="wv-legend-item"><span class="wv-legend-dot" style="background:#ffa722"></span>DÉFENSE</div>
          </div>
          <div class="wv-orbital-label">
            <div class="ol-title">ULTRON ORBITAL NETWORK</div>
            <div>5 NODES — SIMULATED</div>
          </div>
          <div class="wv-hint mono">GLISSER POUR PIVOTER · PINCER POUR ZOOMER</div>
          <div class="wv-modal-bg" id="wv-modal-bg">
            <div class="wv-modal">
              <button class="wv-modal-close" id="wv-modal-close">✕</button>
              <div class="wv-modal-title" id="wv-modal-title"></div>
              <div class="wv-modal-type" id="wv-modal-type"></div>
              <div class="wv-modal-desc" id="wv-modal-desc"></div>
              <div class="wv-modal-grid" id="wv-modal-grid"></div>
              <div class="wv-modal-meta" id="wv-modal-meta"></div>
            </div>
          </div>
        </div>
      </div>
    `;
    const canvas = host.querySelector('#wv-canvas');
    ULTRON.Globe.init(canvas, D.globePoints);
    ULTRON.Globe.setOnPointTap((point)=>{
      const bg = host.querySelector('#wv-modal-bg');
      host.querySelector('#wv-modal-title').textContent = point.label;
      host.querySelector('#wv-modal-type').textContent = point.type || point.cat.toUpperCase();
      host.querySelector('#wv-modal-desc').textContent = point.description || 'Aucune description disponible pour ce point.';
      host.querySelector('#wv-modal-grid').innerHTML = (point.metrics || [
        ['COORDONNÉES', `${point.lat}° · ${point.lon}°`],
        ['CATÉGORIE', point.cat.toUpperCase()],
        ['PAYS', point.country || '—'],
        ['RÉGION', point.region || '—'],
        ['STATUT', point.status || '—'],
        ['IMPORTANCE', point.importance || '—']
      ]).map(([k,v]) => `<div class="wv-info-cell"><div class="wv-info-key">${k}</div><div class="wv-info-val">${v}</div></div>`).join('');
      host.querySelector('#wv-modal-meta').textContent =
        `CATÉGORIE: ${point.cat.toUpperCase()} · DONNÉES SIMULÉES · RÉCUPÉRÉ ${D.fmtDateTime(new Date())}`;
      bg.classList.add('show');
    });
    host.querySelector('#wv-modal-close').addEventListener('click', ()=>{
      host.querySelector('#wv-modal-bg').classList.remove('show');
    });
    host.querySelector('#wv-modal-bg').addEventListener('click', (e)=>{
      if(e.target.id === 'wv-modal-bg'){ e.target.classList.remove('show'); if(ULTRON.Globe.resetZoom) ULTRON.Globe.resetZoom(); }
    });
  }

  // ============ SETTINGS ============
  function renderSettings(host){
    const s = ULTRON.App.getSettings();
    host.innerHTML = `
      <style>
        .st-wrap{display:flex; flex-direction:column; height:100%;}
        .st-scroll{flex:1; overflow-y:auto; padding:12px 16px calc(100px + var(--safe-bottom)) 16px;}
        .st-group{margin-bottom:24px;}
        .st-group-title{font-family:var(--font-mono); font-size:10px; letter-spacing:0.16em; color:var(--grey-dim); margin-bottom:10px;}
        .st-row{
          display:flex; justify-content:space-between; align-items:center; padding:14px 0;
          border-bottom:1px solid var(--line);
        }
        .st-row-label{font-family:var(--font-ui); font-size:14px; color:var(--white);}
        .st-row-desc{font-family:var(--font-mono); font-size:9.5px; color:var(--grey-dim); margin-top:3px;}
        .st-toggle{
          width:46px; height:26px; border:1px solid var(--line-strong); background:var(--bg-panel-2);
          position:relative; flex-shrink:0;
        }
        .st-toggle-knob{
          position:absolute; top:2px; left:2px; width:20px; height:20px; background:var(--grey-dim);
          transition:all 0.2s ease;
        }
        .st-toggle.on{border-color:var(--red);}
        .st-toggle.on .st-toggle-knob{left:22px; background:var(--red-bright); box-shadow:0 0 8px var(--red-bright);}
        .st-slider{width:100%; accent-color:var(--red-bright);}
        .st-region-chips{display:flex; flex-wrap:wrap; gap:8px; margin-top:10px;}
        .st-chip{
          background:var(--bg-panel); border:1px solid var(--line); color:var(--grey);
          font-family:var(--font-mono); font-size:10px; padding:7px 12px;
        }
        .st-chip.active{color:var(--red-bright); border-color:var(--line-strong);}
      </style>
      <div class="st-wrap">
        ${topbar('SETTINGS','PERSONNALISATION')}
        <div class="st-scroll">
          <div class="st-group">
            <div class="st-group-title">AFFICHAGE</div>
            <div class="st-row">
              <div>
                <div class="st-row-label">Intensité des animations</div>
                <div class="st-row-desc">Effets, rotations, pulsations</div>
              </div>
            </div>
            <input type="range" class="st-slider" id="st-anim" min="0" max="100" value="${s.animIntensity}">
            <div class="st-row">
              <div>
                <div class="st-row-label">Effet glitch</div>
                <div class="st-row-desc">Léger artefact visuel occasionnel</div>
              </div>
              <button class="st-toggle ${s.glitch?'on':''}" data-toggle="glitch"><span class="st-toggle-knob"></span></button>
            </div>
            <div class="st-row">
              <div>
                <div class="st-row-label">LOW POWER MODE</div>
                <div class="st-row-desc">Réduit les animations du globe et des satellites</div>
              </div>
              <button class="st-toggle ${s.lowPower?'on':''}" data-toggle="lowPower"><span class="st-toggle-knob"></span></button>
            </div>
          </div>

          <div class="st-group">
            <div class="st-group-title">NOTIFICATIONS</div>
            <div class="st-row">
              <div>
                <div class="st-row-label">Alertes ULTRON</div>
                <div class="st-row-desc">Notifications système internes</div>
              </div>
              <button class="st-toggle ${s.notifications?'on':''}" data-toggle="notifications"><span class="st-toggle-knob"></span></button>
            </div>
          </div>

          <div class="st-group">
            <div class="st-group-title">RÉGIONS SUIVIES</div>
            <div class="st-region-chips" id="st-regions">
              ${['Europe','Amériques','Afrique','Moyen-Orient','Asie','Pacifique'].map(r=>`
                <button class="st-chip ${s.regions.includes(r)?'active':''}" data-region="${r}">${r}</button>
              `).join('')}
            </div>
          </div>

          <div class="st-group">
            <div class="st-group-title">À PROPOS</div>
            <div class="st-row" style="border-bottom:none;">
              <div>
                <div class="st-row-label">ULTRON OS</div>
                <div class="st-row-desc">Interface conceptuelle · Données de démonstration simulées</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    `;

    host.querySelectorAll('.st-toggle').forEach(btn=>{
      btn.addEventListener('click', ()=>{
        btn.classList.toggle('on');
        ULTRON.App.updateSetting(btn.dataset.toggle, btn.classList.contains('on'));
      });
    });
    host.querySelector('#st-anim').addEventListener('input', (e)=>{
      ULTRON.App.updateSetting('animIntensity', parseInt(e.target.value));
    });
    host.querySelectorAll('.st-chip').forEach(chip=>{
      chip.addEventListener('click', ()=>{
        chip.classList.toggle('active');
        const active = [...host.querySelectorAll('.st-chip.active')].map(c=>c.dataset.region);
        ULTRON.App.updateSetting('regions', active);
      });
    });
  }


  // ============ EXTENDED ULTRON MODULES ============
  function extendedStyle(){ return `<style>
    .ux-wrap{height:100%;display:flex;flex-direction:column}.ux-scroll{flex:1;overflow-y:auto;padding:12px 16px calc(100px + var(--safe-bottom));}
    .ux-hero{border:1px solid var(--line-strong);background:linear-gradient(135deg,var(--bg-panel-2),var(--bg-panel));padding:18px;margin-bottom:12px;position:relative;overflow:hidden}
    .ux-hero:after{content:'';position:absolute;right:-30px;top:-30px;width:130px;height:130px;border:1px solid var(--line-strong);border-radius:50%;box-shadow:0 0 30px rgba(255,42,31,.12)}
    .ux-kicker{font:10px var(--font-mono);letter-spacing:.18em;color:var(--red)}.ux-title{font:22px var(--font-display);margin-top:6px}.ux-desc{color:var(--grey);font-size:13px;line-height:1.6;margin-top:8px}
    .ux-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px;margin:12px 0}.ux-card{background:var(--bg-panel);border:1px solid var(--line);padding:13px}.ux-card b{display:block;font:11px var(--font-mono);color:var(--grey-dim);letter-spacing:.08em}.ux-val{font:18px var(--font-display);margin-top:5px;color:var(--white)}
    .ux-list{border:1px solid var(--line);background:var(--bg-panel);margin-top:12px}.ux-row{padding:13px;border-bottom:1px solid var(--line)}.ux-row:last-child{border-bottom:0}.ux-row strong{font-size:14px}.ux-row p{margin:5px 0 0;color:var(--grey);font-size:12px;line-height:1.55}.ux-tag{display:inline-block;margin-top:7px;padding:3px 7px;border:1px solid var(--line-strong);color:var(--red-bright);font:9px var(--font-mono)}
    .ux-section{font:10px var(--font-mono);letter-spacing:.16em;color:var(--red);margin:18px 0 8px}.ux-meter{height:5px;background:var(--red-deep);margin-top:8px}.ux-meter i{display:block;height:100%;background:linear-gradient(90deg,var(--red-dim),var(--red-bright))}.ux-code{font:11px/1.65 var(--font-mono);white-space:pre-wrap;color:#cbbfbc;background:#080404;border:1px solid var(--line);padding:12px;margin-top:12px}
    @media(max-width:520px){.ux-grid{grid-template-columns:1fr 1fr}.ux-title{font-size:18px}}
  </style>`; }
  function extendedPage(host,title,sub,kicker,desc,cards,rows,code){
    host.innerHTML=extendedStyle()+`<div class="ux-wrap">${topbar(title,sub)}<div class="ux-scroll"><div class="ux-hero"><div class="ux-kicker mono">${kicker}</div><div class="ux-title disp">${title}</div><div class="ux-desc">${desc}</div></div><div class="ux-grid">${cards.map(c=>`<div class="ux-card"><b>${c[0]}</b><div class="ux-val">${c[1]}</div>${c[2]?`<div class="ux-meter"><i style="width:${c[2]}%"></i></div>`:''}</div>`).join('')}</div><div class="ux-section">DETAILED ANALYSIS</div><div class="ux-list">${rows.map(r=>`<div class="ux-row"><strong>${r[0]}</strong><p>${r[1]}</p>${r[2]?`<span class="ux-tag">${r[2]}</span>`:''}</div>`).join('')}</div>${code?`<div class="ux-section">LOCAL SYSTEM TRACE</div><div class="ux-code">${code}</div>`:''}</div></div>`;
  }
  function renderAI(host){
    host.innerHTML = `
      <style>
        .ai-wrap{display:flex; flex-direction:column; height:100%; background:#050202;}
        .ai-hero{
          padding:14px 16px; border-bottom:1px solid var(--line);
          background:linear-gradient(135deg,var(--bg-panel-2),var(--bg-panel));
        }
        .ai-hero .ux-kicker{font:10px var(--font-mono); letter-spacing:.18em; color:var(--red);}
        .ai-hero .ux-desc{color:var(--grey); font-size:12px; line-height:1.5; margin-top:6px;}
        .ai-chat-log{flex:1; overflow-y:auto; padding:14px 16px; display:flex; flex-direction:column; gap:10px;}
        .ai-msg{max-width:86%; padding:10px 12px; line-height:1.5; font-size:13px;}
        .ai-msg-role{display:block; font-size:9px; letter-spacing:0.12em; margin-bottom:3px; color:var(--grey-dim);}
        .ai-msg-user{align-self:flex-end; background:var(--red-deep); border:1px solid var(--line-strong); color:var(--white);}
        .ai-msg-user .ai-msg-role{color:var(--red-bright); text-align:right;}
        .ai-msg-bot{align-self:flex-start; background:var(--bg-panel); border:1px solid var(--line); color:var(--white);}
        .ai-msg-bot .ai-msg-role{color:var(--green);}
        .ai-suggest-row{display:flex; gap:6px; padding:8px 12px; overflow-x:auto; border-top:1px solid var(--line); background:var(--bg-panel);}
        .ai-suggest-chip{
          flex-shrink:0; background:var(--bg-panel-2); border:1px solid var(--line); color:var(--grey);
          font-family:var(--font-mono); font-size:10px; padding:8px 12px;
        }
        .ai-inputrow{
          display:flex; align-items:center; gap:8px; padding:12px 16px calc(12px + var(--safe-bottom));
          border-top:1px solid var(--line-strong); background:var(--bg-panel);
        }
        .ai-input{
          flex:1; background:none; border:1px solid var(--line); color:var(--white); font-family:var(--font-ui);
          font-size:13px; outline:none; padding:10px 12px; caret-color:var(--red-bright);
        }
        .ai-send{
          background:var(--red-deep); border:1px solid var(--line-strong); color:var(--red-bright);
          font-family:var(--font-mono); font-size:11px; padding:10px 14px; flex-shrink:0;
        }
      </style>
      <div class="ai-wrap">
        ${topbar('AI CORE','ASSISTANT ULTRON — LANGAGE NATUREL')}
        <div class="ai-hero">
          <div class="ux-kicker">ULTRON / COGNITIVE ENGINE</div>
          <div class="ux-desc">Dites ce que vous voulez faire : « ouvre les marchés », « ferme intel », « divise l'écran avec defense », « redémarre »... L'IA exécute réellement l'action dans l'interface. Fonctionne aussi à la voix (icône micro en haut de l'écran) après la phrase « ULTRON initialisation ».</div>
        </div>
        <div class="ai-chat-log" id="ai-chat-log"></div>
        <div class="ai-suggest-row">
          ${['ouvre les marchés','affiche les applications ouvertes','statut','divise l\'écran avec defense','aide'].map(s=>`<button class="ai-suggest-chip mono" data-q="${s}">${s}</button>`).join('')}
        </div>
        <div class="ai-inputrow">
          <input type="text" class="ai-input" id="ai-input" autocomplete="off" autocapitalize="off" placeholder="Demandez quelque chose à ULTRON...">
          <button class="ai-send mono" id="ai-send">ENVOYER</button>
        </div>
      </div>
    `;

    const logHost = host.querySelector('#ai-chat-log');
    const input = host.querySelector('#ai-input');

    // Replay the existing conversation (persists across screen switches within the session)
    const history = ULTRON.Assistant.getLog();
    if(!history.length){
      const bubble = document.createElement('div');
      bubble.className = 'ai-msg ai-msg-bot';
      bubble.innerHTML = `<span class="ai-msg-role mono">ULTRON</span><span class="ai-msg-text">Bonjour. Je suis l'IA interne d'ULTRON OS. Dites-moi ce que vous voulez ouvrir, fermer ou consulter.</span>`;
      logHost.appendChild(bubble);
    } else {
      history.forEach(m=>{
        const bubble = document.createElement('div');
        bubble.className = 'ai-msg ' + (m.role==='user' ? 'ai-msg-user' : 'ai-msg-bot');
        bubble.innerHTML = `<span class="ai-msg-role mono">${m.role==='user'?'VOUS':'ULTRON'}</span><span class="ai-msg-text"></span>`;
        bubble.querySelector('.ai-msg-text').textContent = m.text;
        logHost.appendChild(bubble);
      });
    }
    logHost.scrollTop = logHost.scrollHeight;

    function send(text){
      const t = (text !== undefined ? text : input.value).trim();
      if(!t) return;
      ULTRON.Assistant.handle(t);
      input.value = '';
    }

    host.querySelector('#ai-send').addEventListener('click', ()=>send());
    input.addEventListener('keydown', (e)=>{ if(e.key === 'Enter') send(); });
    host.querySelectorAll('.ai-suggest-chip').forEach(chip=>{
      chip.addEventListener('click', ()=> send(chip.dataset.q));
    });
  }
  function renderNetwork(host){ extendedPage(host,'NEURAL NETWORK','GLOBAL NODE FABRIC','NETWORK / TOPOLOGY','Cartographie logique des nœuds ULTRON : relais, centres de calcul, stations orbitales simulées et chemins de synchronisation.',[['NODES','184',91],['LINKS','642',76],['LATENCY','38 ms',38],['UPTIME','99.98%',99]],[['EUROPE CLUSTER','Paris, London, Frankfurt et nœuds régionaux. Haute densité de calcul et de relais.','STABLE'],['AMERICAS CLUSTER','New York, São Paulo et relais nord-américains. Flux marchés et renseignement public simulé.','ACTIVE'],['ASIA-PACIFIC','Tokyo, Singapore, Beijing, New Delhi et Sydney. Couverture haute priorité.','ACTIVE'],['ORBITAL LAYER','Relais fictifs utilisés pour animer la visualisation globale et illustrer la redondance.','SIMULATED'],['FAILOVER','En cas de nœud indisponible, le modèle de démonstration bascule vers un chemin logique secondaire.','REDUNDANT']], 'NET> route.scan()\nNET> topology.validate()\nNET> redundancy.check()\nNET> sync.broadcast()'); }
  function renderSurveillance(host){ extendedPage(host,'SURVEILLANCE GRID','GLOBAL SITUATIONAL AWARENESS','WORLD / MONITORING','Vue consolidée des zones, signaux et anomalies visibles dans les données simulées de la carte mondiale.',[['TRACKED POINTS','14',82],['SIGNALS','327',67],['ANOMALIES','9',31],['COVERAGE','87%',87]],[['GEOPOLITICAL','Événements diplomatiques, tensions régionales et mouvements politiques agrégés à partir du dataset local.','INTEL'],['ECONOMIC','Indices, devises et matières premières surveillés pour détecter des variations inhabituelles.','MARKETS'],['CONFLICT','Zones de tension affichées uniquement comme indicateurs de contexte géopolitique.','CONTEXT'],['INFRASTRUCTURE','Nœuds, ports, hubs et centres économiques représentés à un niveau général, sans données sensibles.','GENERAL'],['ANOMALY ENGINE','Détection simulée de changements de régime, pics de volatilité et ruptures de tendance.','SIMULATION']], 'GRID> ingest(local_feeds)\nGRID> normalize()\nGRID> detect(anomalies)\nGRID> map(world)\nGRID> status=MONITORING'); }
  function renderArchives(host){ extendedPage(host,'ARCHIVES','EVENT MEMORY','MEMORY / TIMELINE','Bibliothèque locale des événements et états importants observés par ULTRON OS depuis le démarrage.',[['EVENTS','2,418',72],['REPORTS','684',54],['SESSIONS','96',44],['RETENTION','365 J',100]],[['RECENT','Dernières alertes, changements de statut et mises à jour des flux internes.','LIVE'],['HISTORICAL','Chronologie synthétique permettant de comparer plusieurs périodes de données simulées.','TIMELINE'],['CLASSIFIED UI','Certaines entrées peuvent apparaître comme « CLASSIFIED » dans l’interface pour renforcer l’esthétique fictionnelle.','FICTION'],['EXPORT','Les journaux de démonstration peuvent être copiés depuis le terminal ; aucun secret réel n’est stocké.','LOCAL'],['INTEGRITY','Chaque session affiche une empreinte logique de cohérence pour détecter une modification inattendue du dataset.','CHECK']], 'ARCHIVE> open(index)\nARCHIVE> verify(integrity)\nARCHIVE> query("global events")\nARCHIVE> result=READY'); }
  function renderProtocols(host){ extendedPage(host,'PROTOCOLS','ULTRON OPERATING DOCTRINE','CORE / PROTOCOLS','Référentiel des protocoles fictifs qui structurent le comportement visuel et logique de l’interface.',[['PROTOCOLS','32',80],['SAFETY','100%',100],['SYNC','ACTIVE',88],['AUTH','LOCAL',61]],[['AEGIS','Maintient les modules en mode démonstration et empêche toute action externe non prévue.','SAFETY'],['SENTINEL','Surveille les changements d’état et génère des alertes d’interface.','MONITOR'],['OMEGA','Procédure fictive de consolidation des informations en cas d’événement majeur.','FICTION'],['REDLINE','Mode d’alerte visuelle : intensification des éléments rouges, scanlines et priorités.','UI'],['SILENT','Réduit les animations et notifications pour privilégier la lisibilité et les performances.','LOW POWER']], 'PROTO> aegis.validate()\nPROTO> sentinel.watch()\nPROTO> omega.standby()\nPROTO> redline.ready()\nPROTO> silent=available'); }
  function renderSystem(host){ extendedPage(host,'SYSTEM CORE','ULTRON OS / INTERNAL STATUS','SYSTEM / DIAGNOSTICS','Tableau technique du cœur de l’application : mémoire, rendu, modules chargés, stockage local et état de la session.',[['CORE','ONLINE',100],['RENDER','THREE.JS',82],['STORAGE','LOCAL',70],['ERRORS','0',100]],[['RUNTIME','Les modules JavaScript sont chargés dans l’ordre : données, boot, cœur 3D, frontières, globe, modules, terminal puis shell applicatif.','PIPELINE'],['PERSISTENCE','Les préférences utilisateur sont enregistrées localement dans localStorage lorsque le navigateur l’autorise.','LOCAL'],['GRAPHICS','Le WORLD VIEW utilise WebGL via Three.js et adapte ses effets en mode faible consommation.','WEBGL'],['OFFLINE MAP','Les contours géographiques intégrés au projet sont chargés depuis des fichiers locaux, sans appel GeoJSON distant.','OFFLINE'],['DIAGNOSTICS','Les erreurs critiques peuvent être signalées par l’interface de démarrage au lieu de laisser un écran noir.','SAFE']], 'SYSTEM> modules.check()\nSYSTEM> storage.check()\nSYSTEM> graphics.check()\nSYSTEM> diagnostics=OK'); }

  // ---------- icons (inline svg, stroke=currentColor) ----------
  function iconGlobe(){return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.5 2.7 3.8 6 3.8 9s-1.3 6.3-3.8 9c-2.5-2.7-3.8-6-3.8-9s1.3-6.3 3.8-9z"/></svg>`;}
  function iconChart(){return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M4 19V9M12 19V4M20 19v-6"/><path d="M2 19h20"/></svg>`;}
  function iconSignal(){return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M4 12a8 8 0 0 1 16 0M7 12a5 5 0 0 1 10 0"/><circle cx="12" cy="12" r="1.6" fill="currentColor" stroke="none"/></svg>`;}
  function iconShield(){return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M12 3l7 3v6c0 4.5-3 7.5-7 9-4-1.5-7-4.5-7-9V6l7-3z"/></svg>`;}
  function iconTerminal(){return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="3" y="4" width="18" height="16" rx="1"/><path d="M7 9l3 3-3 3M13 15h4"/></svg>`;}
  function iconGear(){return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><circle cx="12" cy="12" r="3"/><path d="M19.4 13a7.6 7.6 0 000-2l2-1.5-2-3.4-2.3.9a7.7 7.7 0 00-1.8-1l-.3-2.5H9l-.3 2.5a7.7 7.7 0 00-1.8 1l-2.3-.9-2 3.4L4.6 11a7.6 7.6 0 000 2l-2 1.5 2 3.4 2.3-.9c.5.4 1.1.7 1.8 1l.3 2.5h4.8l.3-2.5c.7-.3 1.3-.6 1.8-1l2.3.9 2-3.4-2-1.5z"/></svg>`;}

  return {
    renderDashboard, refreshDashboardSummary, renderMarkets, renderIntel,
    renderConflict, renderDefense, renderWorld, renderSettings, renderAI, renderNetwork, renderSurveillance, renderArchives, renderProtocols, renderSystem
  };
})();
