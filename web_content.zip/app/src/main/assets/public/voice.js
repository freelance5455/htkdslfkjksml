// ============================================================
// ULTRON OS — VOICE ACTIVATION
// Wake phrase: "ultron initialisation"
// Browser limitation: microphone listening requires the page to be open.
// ============================================================
ULTRON.Voice = (function(){
  let recognition = null;
  let listening = false;
  let booting = false;
  let enabled = true;

  const PHRASES = [
    'ultron initialisation',
    'ultron initialisation.',
    'ultron initialization',
    'ultron initialization.'
  ];

  function normalize(s){
    return (s || '')
      .toLowerCase()
      .normalize('NFD').replace(/[\u0300-\u036f]/g,'')
      .replace(/[^a-z0-9 ]/g,' ')
      .replace(/\s+/g,' ')
      .trim();
  }

  function toast(title, body){
    const host = document.getElementById('toast-host');
    if(!host) return;
    const el = document.createElement('div');
    el.className = 'toast';
    el.innerHTML = `<div class="toast-title mono">${title}</div><div class="toast-body">${body}</div>`;
    host.appendChild(el);
    requestAnimationFrame(()=>el.classList.add('show'));
    setTimeout(()=>{ el.classList.remove('show'); setTimeout(()=>el.remove(),350); }, 3200);
  }

  function setIndicator(active){
    let el = document.getElementById('voice-indicator');
    if(!el){
      el = document.createElement('div');
      el.id = 'voice-indicator';
      el.innerHTML = '<span class="voice-dot"></span><span class="voice-label">VOICE // STANDBY</span>';
      document.body.appendChild(el);
    }
    el.classList.toggle('active', !!active);
    el.querySelector('.voice-label').textContent = active ? 'VOICE // LISTENING' : 'VOICE // STANDBY';
  }

  function activate(){
    if(booting) return;
    booting = true;
    toast('ULTRON VOICE', 'INITIALISATION ACCEPTÉE');
    const shell = document.getElementById('main-shell');
    if(shell) shell.style.display = 'none';
    if(ULTRON.Globe && ULTRON.Globe.dispose) ULTRON.Globe.dispose();
    ULTRON.Boot.run(()=>{
      if(!document.getElementById('main-shell')) ULTRON.App.buildShell?.();
      const main = document.getElementById('main-shell');
      if(main) main.style.display = 'flex';
      ULTRON.App.navigate('dashboard');
      booting = false;
    });
  }

  function setup(){
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if(!SR){ setIndicator(false); return false; }
    recognition = new SR();
    recognition.lang = 'fr-FR';
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.maxAlternatives = 3;

    recognition.onstart = ()=>{ listening = true; setIndicator(true); };
    recognition.onend = ()=>{
      listening = false;
      setIndicator(false);
      if(enabled && document.visibilityState === 'visible'){
        setTimeout(()=>{ try{ recognition.start(); }catch(_){} }, 700);
      }
    };
    recognition.onerror = (e)=>{
      if(e.error === 'not-allowed' || e.error === 'service-not-allowed'){
        enabled = false;
        setIndicator(false);
        toast('VOICE', 'ACCÈS MICRO REQUIS POUR L’ACTIVATION VOCALE');
      }
    };
    recognition.onresult = (event)=>{
      let text = '';
      let isFinal = false;
      for(let i=event.resultIndex;i<event.results.length;i++){
        text += ' ' + event.results[i][0].transcript;
        if(event.results[i].isFinal) isFinal = true;
      }
      const n = normalize(text);
      if(PHRASES.some(p => n.includes(normalize(p)))){ activate(); return; }
      // Anything else, once finalized, is handed to the internal AI assistant —
      // this is what actually lets spoken commands open/close apps, etc.
      if(isFinal && ULTRON.Assistant && text.trim().split(' ').length >= 2){
        const response = ULTRON.Assistant.handle(text.trim(), {silentUser:false});
        toast('ULTRON IA', response);
      }
    };
    try{ recognition.start(); }catch(_){}
    return true;
  }

  function init(){
    // Explicit URL trigger, useful with Siri/Google Assistant shortcuts.
    const params = new URLSearchParams(location.search);
    const command = normalize(params.get('ultron') || '');
    if(command === 'initialisation' || command === 'initialization'){
      setTimeout(activate, 500);
    }
    // Give the browser time to finish the normal boot before requesting the mic.
    setTimeout(setup, 2200);
  }

  return { init, activate };
})();
