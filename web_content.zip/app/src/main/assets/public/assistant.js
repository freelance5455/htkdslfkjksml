// ============================================================
// ULTRON OS — IA INTERNE (ASSISTANT)
// Comprend des phrases en langage naturel (texte ou voix) et exécute
// vraiment les actions correspondantes dans l'application : ouvrir/fermer
// une application, changer d'écran, activer la vue partagée, etc.
// Ce n'est pas un modèle de langage — c'est un interpréteur de commandes,
// mais le résultat est le même pour l'utilisateur : "l'IA le fait".
// ============================================================
ULTRON.Assistant = (function(){
  const D = ULTRON.DATA;
  let log = []; // {role:'user'|'ai', text, ts}
  const MAX_LOG = 60;

  function normalize(s){
    return (s || '')
      .toLowerCase()
      .normalize('NFD').replace(/[\u0300-\u036f]/g,'') // strip accents
      .replace(/[^a-z0-9 ]/g,' ')
      .replace(/\s+/g,' ')
      .trim();
  }

  // French/English synonyms → app id, so "ouvre le monde" resolves to 'world'
  // even though the on-screen label is the English "WORLD".
  const SYNONYMS = {
    monde:'world', world:'world', globe:'world', carte:'world',
    marches:'markets', marche:'markets', markets:'markets', bourse:'markets',
    informations:'intel', information:'intel', renseignement:'intel', renseignements:'intel', intel:'intel', actualites:'intel',
    terminal:'terminal', console:'terminal', shell:'terminal',
    parametres:'settings', reglages:'settings', settings:'settings', configuration:'settings',
    reseau:'network', neuronal:'network', network:'network',
    surveillance:'surveillance',
    archives:'archives', archive:'archives',
    protocoles:'protocols', protocole:'protocols', protocols:'protocols',
    systeme:'system', system:'system', noyau:'system',
    defense:'defense', securite:'defense',
    conflit:'conflict', conflits:'conflict', conflict:'conflict',
    ia:'ai', ai:'ai', intelligence:'ai', assistant:'ai',
  };

  function resolveAppQuery(remainder){
    const n = normalize(remainder);
    if(!n) return remainder;
    const tokens = n.split(' ');
    for(const t of tokens){
      if(SYNONYMS[t]) return SYNONYMS[t];
    }
    return remainder;
  }

  function stripTrigger(text, patterns){
    let out = text;
    for(const p of patterns) out = out.replace(p, ' ');
    return out.replace(/\s+/g,' ').trim();
  }

  // ---------------- intent rules, tested in order ----------------
  const RULES = [
    { // wake filler — "ultron, ..." → drop the name and re-run on the rest
      test: n => /^ultron[ ,]+.+/.test(n),
      run: (n, raw) => interpret(raw.replace(/^ultron[ ,]*/i,'').trim())
    },
    {
      test: n => /\b(bonjour|salut|hey|coucou)\b/.test(n) && n.split(' ').length <= 3,
      run: () => "Bonjour. Je suis à votre écoute — dites-moi quoi ouvrir, fermer ou consulter."
    },
    {
      test: n => /\b(aide|help|que peux tu faire|quelles sont tes commandes)\b/.test(n),
      run: () => "Je peux : ouvrir/fermer une application (« ouvre les marchés », « ferme intel »), " +
                 "revenir à l'accueil, afficher les applications ouvertes, activer la vue partagée " +
                 "(« divise l'écran avec defense »), donner le statut système, chercher une information, " +
                 "ou redémarrer ULTRON OS."
    },
    {
      test: n => /\b(accueil|dashboard|maison|home)\b/.test(n) && /\b(va|aller|reviens|retourne|ouvre|montre|affiche)\b/.test(n),
      run: () => { ULTRON.App.navigate('dashboard'); return "RETOUR À L'ACCUEIL."; }
    },
    {
      test: n => /\b(applications? ouvertes?|multitache|selecteur d application|apps? ouvertes?|recents?)\b/.test(n),
      run: () => {
        ULTRON.App.openSwitcher();
        const apps = ULTRON.App.getOpenApps();
        return apps.length
          ? `${apps.length} application(s) ouverte(s) : ${apps.map(a=>a.label).join(', ')}.`
          : "Aucune application ouverte pour le moment.";
      }
    },
    {
      test: n => /\b(ferme|fermer|quitte|quitter)\b.*\b(vue partagee|partage|split)\b/.test(n) || /\b(desactive|arrete)\b.*\bpartag/.test(n),
      run: () => {
        if(ULTRON.App.isSplitOpen()) ULTRON.App.toggleSplit();
        return "VUE PARTAGÉE DÉSACTIVÉE.";
      }
    },
    {
      test: n => /\b(divise|diviser|partage|partager)\b.*\b(ecran|vue)\b|vue partagee|split screen/.test(n),
      run: (n, raw) => {
        const remainder = stripTrigger(raw, [/divise[rz]?/gi,/partage[rz]?/gi,/l.?ecran/gi,/vue partagee/gi,/split screen/gi,/avec/gi]);
        const appId = resolveAppQuery(remainder);
        const app = ULTRON.App.findApp(appId);
        if(!ULTRON.App.isSplitOpen()) ULTRON.App.toggleSplit();
        if(app){ ULTRON.App.setSplitApp(app.id); return `VUE PARTAGÉE ACTIVÉE avec ${app.label}.`; }
        return "VUE PARTAGÉE ACTIVÉE.";
      }
    },
    {
      test: n => /\b(redemarre|redemarrage|reboot|relance le systeme)\b/.test(n),
      run: () => { setTimeout(()=>ULTRON.App.reboot(), 400); return "REDÉMARRAGE D'ULTRON OS EN COURS..."; }
    },
    {
      test: n => /\b(statut|etat du systeme|status)\b/.test(n),
      run: () => {
        const m = D.getMarketsSnapshot();
        return `SYSTÈME EN LIGNE. Cœur opérationnel. Marchés : ${m.status}. ` +
               `${ULTRON.App.getOpenApps().length} application(s) ouverte(s).`;
      }
    },
    {
      test: n => /\b(quelle heure|heure est il|quelle est l heure)\b/.test(n),
      run: () => `Il est ${new Date().toLocaleTimeString('fr-FR',{hour:'2-digit',minute:'2-digit'})}.`
    },
    {
      test: n => /\b(cherche|recherche|trouve)\b/.test(n),
      run: (n, raw) => {
        const q = stripTrigger(raw, [/cherche[rz]?/gi,/recherche[rz]?/gi,/trouve[rz]?/gi]);
        if(!q) return "Que dois-je chercher ?";
        const feed = D.getIntelFeed();
        const ql = normalize(q);
        const results = feed.filter(f => normalize(f.title).includes(ql) || normalize(f.region).includes(ql) || normalize(f.summary).includes(ql));
        if(!results.length) return `Aucun résultat pour « ${q} ».`;
        ULTRON.App.navigate('intel');
        return `${results.length} résultat(s) pour « ${q} » : ${results.slice(0,3).map(r=>r.title).join(' — ')}.`;
      }
    },
    {
      // "ferme X" / "quitte X" — checked before "ouvre X" so they never collide
      test: n => /\b(ferme|fermer|quitte|quitter|tue|tuer)\b/.test(n),
      run: (n, raw) => {
        const remainder = resolveAppQuery(stripTrigger(raw, [/ferme[rz]?/gi,/quitte[rz]?/gi,/tue[rz]?/gi]));
        const closed = ULTRON.App.closeApp(remainder);
        return closed ? `FERMETURE DE ${closed.label}.` : `Aucune application ouverte ne correspond à « ${remainder} ».`;
      }
    },
    {
      test: n => /\b(ouvre|ouvrir|affiche|afficher|montre|montrer|lance|lancer|va sur|va a|acceder a|aller sur)\b/.test(n),
      run: (n, raw) => {
        const remainder = resolveAppQuery(stripTrigger(raw, [
          /ouvre[rz]?/gi,/affiche[rz]?/gi,/montre[rz]?/gi,/lance[rz]?/gi,/va sur/gi,/va a/gi,/acceder a/gi,/aller sur/gi,/^moi/gi
        ]));
        if(!remainder) return "Que dois-je ouvrir ?";
        const app = ULTRON.App.openApp(remainder);
        return app ? `OUVERTURE DE ${app.label}...` : `Je ne trouve pas d'application correspondant à « ${remainder} ». Dites « aide » pour la liste.`;
      }
    },
  ];

  function interpret(rawText){
    const text = (rawText || '').trim();
    if(!text) return "Je n'ai rien entendu.";
    const n = normalize(text);
    for(const rule of RULES){
      if(rule.test(n)) return rule.run(n, text);
    }
    return "Commande non reconnue. Essayez « ouvre les marchés » ou dites « aide ».";
  }

  function appendToChatDOM(role, text){
    const host = document.getElementById('ai-chat-log');
    if(!host) return;
    const bubble = document.createElement('div');
    bubble.className = 'ai-msg ' + (role === 'user' ? 'ai-msg-user' : 'ai-msg-bot');
    bubble.innerHTML = `<span class="ai-msg-role mono">${role==='user'?'VOUS':'ULTRON'}</span><span class="ai-msg-text">${escapeHtml(text)}</span>`;
    host.appendChild(bubble);
    host.scrollTop = host.scrollHeight;
  }

  function escapeHtml(s){
    const d = document.createElement('div');
    d.textContent = s;
    return d.innerHTML;
  }

  function handle(text, opts){
    opts = opts || {};
    if(!opts.silentUser) { log.push({role:'user', text, ts:Date.now()}); appendToChatDOM('user', text); }
    let response;
    try{ response = interpret(text); }
    catch(e){ response = "Erreur d'interprétation de la commande."; }
    log.push({role:'ai', text:response, ts:Date.now()});
    appendToChatDOM('ai', response);
    if(log.length > MAX_LOG) log = log.slice(-MAX_LOG);
    return response;
  }

  function getLog(){ return log.slice(); }

  return { handle, interpret, getLog };
})();
