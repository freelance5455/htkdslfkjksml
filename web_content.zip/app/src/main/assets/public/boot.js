// ============================================================
// ULTRON OS — BOOT SEQUENCE
// ============================================================
ULTRON.Boot = (function(){

  // Phase 0 — firmware / bootloader, shown on its own black "POST" screen
  // before the kernel log panel appears, just like real hardware.
  const FIRMWARE_LINES = [
    'ULTRON-UEFI BIOS — v4.12.0-ultron',
    'Copyright (C) Stark Industries Research Division',
    '',
    'CPU: NPU-CORE x16 @ 4.80 GHz — 16 cores / 32 threads',
    'Memory: 65536 MB OK',
    'Initializing storage controllers... done',
    'Detecting boot devices... /dev/nvme0n1',
    '',
    'Booting from /dev/nvme0n1p1 (GRUB2)...',
  ];

  const GRUB_LINES = [
    'GNU GRUB  version 2.12',
    '',
    ' *ULTRON OS  GNU/Linux (neural-kernel 6.9.0-ultron)',
    '  ULTRON OS  GNU/Linux (recovery mode)',
    '  UEFI Firmware Settings',
    '',
    'Booting default entry in 1s...'
  ];

  // Phase 1 — real-looking kernel ring buffer (dmesg-style) output.
  // Kept close to genuine Linux boot messages, themed just enough to fit ULTRON.
  const MESSAGES = [
    '[    0.000000] Linux version 6.9.0-ultron (root@ultron-build) (gcc 13.2.0) #1 SMP PREEMPT_DYNAMIC',
    '[    0.000000] Command line: BOOT_IMAGE=/vmlinuz-ultron root=/dev/nvme0n1p2 ro quiet splash',
    '[    0.000412] BIOS-provided physical RAM map: usable',
    '[    0.012884] ACPI: Core revision 20230628',
    '[    0.041207] Detected CPU: NPU-CORE x16 @ 4.80GHz, 16 cores / 32 threads',
    '[    0.081942] smpboot: CPU0: NPU-CORE-0 online',
    '[    0.114360] smpboot: Total of 16 processors activated',
    '[    0.143728] mem: initializing 64 GiB address space, zone DMA/Normal/HighMem',
    '[    0.176541] pci_bus 0000:00: root bus resource [io 0x0000-0xffff]',
    '[    0.209884] NVMe: nvme0: pci function 0000:01:00.0',
    '[    0.238117] nvme0n1: p1 p2 p3',
    '[    0.266905] EXT4-fs (nvme0n1p2): mounted filesystem with ordered data mode',
    '[    0.298440] VFS: Mounted root (ext4 filesystem) readonly on device 259:2',
    '[    0.331290] devtmpfs: initialized',
    '[    0.359773] random: crng init done',
    '[    0.388012] usb 1-1: new high-speed USB device detected',
    '[    0.412665] input: ULTRON HID interface as /devices/virtual/input/input0',
    '[    0.447210] systemd[1]: Inserting module \'autofs4\'',
    '[    0.481093] systemd[1]: systemd 255 running in system mode (+PAM +AUDIT +APPARMOR)',
    '[    0.512740] systemd[1]: Detected architecture arm64.',
    '[    0.540108] systemd[1]: Hostname set to <ultron-core>.',
    '[    0.568990] systemd[1]: Started Journal Service.',
    '[    0.590184] systemd[1]: Starting Load Kernel Modules...',
    '[    0.612455] systemd[1]: Starting Remount Root and Kernel File Systems...',
    '[    0.640233] systemd[1]: Mounting /CORE /DATA /ARCHIVES...',
    '[    0.671840] systemd[1]: Mounted /CORE.',
    '[    0.672933] systemd[1]: Mounted /DATA.',
    '[    0.673981] systemd[1]: Mounted /ARCHIVES.',
    '[    0.702118] fsck.ext4: /dev/nvme0n1p2: clean, 812433/2621440 files, 4823011/10485760 blocks',
    '[    0.733602] systemd[1]: Starting Network Manager...',
    '[    0.771356] systemd[1]: Starting udev Kernel Device Manager...',
    '[    0.804219] systemd-udevd[412]: starting version 255',
    '[    0.839002] systemd[1]: Starting neural-matrix.service — cognitive core',
    '[    0.867455] neural-matrix[520]: model weights loaded (4.1B parameters)',
    '[    0.901775] systemd[1]: Reached target Network Online',
    '[    0.933310] systemd[1]: Starting global-intel.service...',
    '[    0.961084] systemd[1]: Starting orbital-network.service...',
    '[    0.989721] systemd[1]: Starting markets-feed.service...',
    '[    1.021460] systemd[1]: Starting defense-watch.service...',
    '[    1.052908] systemd[1]: Started D-Bus System Message Bus.',
    '[    1.084233] systemd[1]: Reached target Graphical Interface.',
    '[    1.112667] ultron-shell[1024]: initializing display server (wayland)',
    '[    1.153429] ultron-shell[1024]: compositor ready, 1 output detected',
    '[    1.190005] systemd[1]: Started ULTRON Session Manager.',
    '[    1.221844] systemd[1]: Reached target Multi-User System.',
    '[    1.244817] ultron-core[1]: self-check complete — all systems operational',
    '',
    'ultron-core login: root (automatic login)',
    'Last login: ' + new Date().toString(),
    'Welcome to ULTRON OS — secure neural command interface'
  ];

  function buildDOM(){
    const el = document.createElement('div');
    el.className = 'screen boot-screen';
    el.id = 'screen-boot';
    el.innerHTML = `
      <style>
        .boot-screen{
          align-items:center; justify-content:center;
          background:radial-gradient(ellipse at 50% 50%, #120606 0%, #030303 72%);
        }
        .boot-linux{width:100%; max-width:760px; border:1px solid rgba(255,60,50,.22); background:rgba(0,0,0,.72); box-shadow:0 0 50px rgba(255,42,31,.08), inset 0 0 40px rgba(255,42,31,.025);}
        .boot-top{display:flex;justify-content:space-between;align-items:center;padding:9px 12px;border-bottom:1px solid rgba(255,60,50,.18);font-family:var(--font-mono);font-size:10px;color:var(--red);letter-spacing:.08em}
        .boot-prompt{color:var(--grey-dim)}
        .boot-log{padding:14px 16px; min-height:260px; max-height:330px; overflow:hidden; text-align:left;}
        .boot-log-line{font-size:11px; line-height:1.72; font-family:var(--font-mono);}
        .boot-log-line .b-caret{color:var(--red-bright);}
        .boot-log-line .b-txt{color:#d8cecb; letter-spacing:0;}
        .boot-log-line .b-ok{color:var(--green); float:right; font-size:10px;}
        .boot-log-line.welcome .b-txt{color:var(--red-bright);}
        .boot-log-line:empty::after{content:'\\00a0';}
        .boot-shell-prompt{padding:7px 16px 12px;font-family:var(--font-mono);font-size:11px;color:var(--grey-dim)}
        .boot-shell-prompt span{color:var(--red-bright)}
        .boot-wrap{
          display:flex; flex-direction:column; align-items:center;
          gap:28px; padding:24px; width:100%; max-width:420px;
        }
        .boot-core{
          position:relative; width:180px; height:180px;
        }
        .boot-core svg{width:100%; height:100%;}
        .boot-ring{
          transform-origin:100px 100px;
          fill:none;
        }
        .boot-ring.r1{stroke:var(--red-dim); stroke-width:1;}
        .boot-ring.r2{stroke:var(--red); stroke-width:1.5; stroke-dasharray:8 14; opacity:0.8;}
        .boot-ring.r3{stroke:var(--red-bright); stroke-width:1; stroke-dasharray:2 6; opacity:0.6;}
        .boot-eye{
          fill:var(--red-bright);
          filter:drop-shadow(0 0 10px var(--red-bright)) drop-shadow(0 0 24px rgba(255,42,31,0.6));
          opacity:0;
          animation:eyeIn 1.8s ease forwards 0.3s;
        }
        @keyframes eyeIn{
          0%{opacity:0; r:0;}
          60%{opacity:1;}
          100%{opacity:0.95;}
        }
        .boot-core.spin-slow{animation:spin 14s linear infinite;}
        .boot-core.spin-mid{animation:spin 7s linear infinite reverse;}
        @keyframes spin{from{transform:rotate(0deg);}to{transform:rotate(360deg);}}

        .boot-title{
          font-family:var(--font-display); font-weight:900;
          font-size:26px; letter-spacing:0.28em;
          color:var(--white); text-align:center;
          text-shadow:0 0 14px rgba(255,68,51,0.5);
          opacity:0; animation:fadeUp 0.8s ease forwards 0.6s, titleGlitch 4s ease-in-out infinite 2s;
          position:relative;
        }
        @keyframes titleGlitch{
          0%,92%,100%{ text-shadow:0 0 14px rgba(255,68,51,0.5); transform:translate(0);}
          93%{ text-shadow:-2px 0 var(--green), 2px 0 var(--red-bright); transform:translate(-1px,0);}
          94%{ text-shadow:2px 0 var(--green), -2px 0 var(--red-bright); transform:translate(1px,0);}
          95%{ text-shadow:0 0 14px rgba(255,68,51,0.5); transform:translate(0);}
        }
        .boot-sub{
          font-family:var(--font-mono); font-size:10px; letter-spacing:0.3em;
          color:var(--red); text-align:center; margin-top:4px;
          opacity:0; animation:fadeUp 0.8s ease forwards 0.9s;
        }
        @keyframes fadeUp{from{opacity:0; transform:translateY(8px);}to{opacity:1; transform:translateY(0);}}

        .boot-bar-wrap{width:100%;}
        .boot-bar-track{
          width:100%; height:3px; background:var(--red-deep);
          position:relative; overflow:hidden;
        }
        .boot-bar-fill{
          height:100%; width:0%; background:linear-gradient(90deg, var(--red-dim), var(--red-bright));
          box-shadow:0 0 10px var(--red-bright);
          transition:width 0.3s ease;
        }
        .boot-bar-pct{
          font-family:var(--font-mono); font-size:10px; color:var(--red);
          letter-spacing:0.15em; margin-top:6px; text-align:right;
        }
        .boot-skip{
          position:absolute; bottom:calc(24px + var(--safe-bottom)); right:24px;
          font-family:var(--font-mono); font-size:10px; letter-spacing:0.15em;
          color:var(--grey-dim); background:none; border:1px solid var(--line);
          padding:8px 14px; z-index:5;
        }
        /* -------- pre-boot: firmware / GRUB phase -------- */
        .boot-pre{
          position:absolute; inset:0; background:#000; color:#c9c9c9;
          font-family:var(--font-mono); font-size:12px; line-height:1.75;
          padding:26px 24px; padding-top:calc(26px + var(--safe-top));
          z-index:6; opacity:1; transition:opacity 0.35s ease;
        }
        .boot-pre.hide{opacity:0; pointer-events:none;}
        .boot-pre .pre-line{white-space:pre-wrap;}
        .boot-pre .pre-dim{color:#6b6b6b;}
        .boot-grub{display:none;}
        .boot-grub .pre-sel{color:#000; background:#c9c9c9; padding:1px 4px;}
        .boot-grub .pre-item{padding:1px 4px;}
      </style>
      <div class="boot-pre" id="boot-pre">
        <div id="boot-firmware"></div>
        <div class="boot-grub" id="boot-grub"></div>
      </div>
      <div class="boot-wrap">
        <div class="boot-core">
          <svg viewBox="0 0 200 200">
            <g class="spin-slow">
              <circle class="boot-ring r1" cx="100" cy="100" r="94"/>
            </g>
            <g class="spin-mid">
              <circle class="boot-ring r2" cx="100" cy="100" r="76"/>
            </g>
            <g class="spin-slow">
              <circle class="boot-ring r3" cx="100" cy="100" r="58"/>
            </g>
            <circle class="boot-eye" cx="100" cy="100" r="16"/>
          </svg>
        </div>
        <div class="boot-linux">
          <div class="boot-top"><span>ULTRON TTY1</span><span class="boot-prompt">root@ultron:~# systemctl start ultron.target</span></div>
          <div class="boot-log mono" id="boot-log"></div>
          <div class="boot-shell-prompt"><span>root@ultron:~#</span> _</div>
        </div>
        <div>
          <div class="boot-title">ULTRON OS</div>
          <div class="boot-sub">NEURAL COMMAND INTERFACE</div>
        </div>
        <div class="boot-bar-wrap">
          <div class="boot-bar-track"><div class="boot-bar-fill" id="boot-bar-fill"></div></div>
          <div class="boot-bar-pct" id="boot-bar-pct">0%</div>
        </div>
      </div>
      <button class="boot-skip" id="boot-skip">SKIP ▸</button>
    `;
    return el;
  }

  // A line gets an "OK" badge only if it reads like a real init/service
  // result (Starting/Started/Mounted/Reached...). Blank lines, timest-less
  // login lines, etc. print as plain text — like a genuine console.
  function statusFor(msg){
    if(!msg) return null;
    if(/^\[.*\](.*)(Started|Mounted|Reached|clean,|detected|online|ready|loaded|initialized|crng init done)/.test(msg)) return 'OK';
    if(/^\[.*\] Command line:/.test(msg)) return null;
    if(/^\[.*\]/.test(msg)) return null;
    return null;
  }

  function run(onComplete){
    const el = buildDOM();
    document.getElementById('screens').appendChild(el);
    requestAnimationFrame(()=>el.classList.add('active'));

    const pre = el.querySelector('#boot-pre');
    const firmwareHost = el.querySelector('#boot-firmware');
    const grubHost = el.querySelector('#boot-grub');
    const log = el.querySelector('#boot-log');
    const barFill = el.querySelector('#boot-bar-fill');
    const barPct = el.querySelector('#boot-bar-pct');
    const skipBtn = el.querySelector('#boot-skip');

    let finished = false;
    let timers = [];
    function after(ms, fn){ timers.push(setTimeout(fn, ms)); }

    function finish(){
      if(finished) return;
      finished = true;
      timers.forEach(t=>clearTimeout(t));
      el.style.transition = 'opacity 0.5s ease';
      el.style.opacity = '0';
      setTimeout(()=>{
        el.remove();
        onComplete();
      }, 500);
    }

    skipBtn.addEventListener('click', finish);

    // ---- phase 1: firmware / POST ----
    FIRMWARE_LINES.forEach((msg, i)=>{
      after(i*70, ()=>{
        const l = document.createElement('div');
        l.className = 'pre-line' + (msg === '' ? ' pre-dim' : '');
        l.textContent = msg;
        firmwareHost.appendChild(l);
      });
    });

    const firmwareDuration = FIRMWARE_LINES.length*70 + 250;

    // ---- phase 2: GRUB menu ----
    after(firmwareDuration, ()=>{
      firmwareHost.style.display = 'none';
      grubHost.style.display = 'block';
      grubHost.innerHTML = GRUB_LINES.map((l,i)=>{
        if(l.startsWith(' *')) return `<div class="pre-item pre-sel">${l}</div>`;
        if(l.startsWith('  ')) return `<div class="pre-item pre-dim">${l}</div>`;
        return `<div class="pre-line${l===''?' pre-dim':''}">${l}</div>`;
      }).join('');
    });

    const grubDuration = firmwareDuration + 1300;

    // ---- phase 3: hide pre-boot, reveal kernel log + spinner core ----
    after(grubDuration, ()=>{
      pre.classList.add('hide');
    });

    const kernelStart = grubDuration + 200;

    MESSAGES.forEach((msg, i)=>{
      const delay = kernelStart + i * 120;
      timers.push(setTimeout(()=>{
        const line = document.createElement('div');
        const isWelcome = msg.startsWith('Welcome');
        const status = statusFor(msg);
        line.className = 'boot-log-line' + (isWelcome ? ' welcome' : '');
        const caret = msg ? '<span class="b-caret">›</span>' : '';
        const badge = status ? `<span class="b-ok">${status}</span>` : '';
        line.innerHTML = `${caret}<span class="b-txt">${msg}</span>${badge}`;
        log.appendChild(line);
        log.scrollTop = log.scrollHeight;
        const pct = Math.round(((i+1)/MESSAGES.length)*100);
        barFill.style.width = pct + '%';
        barPct.textContent = pct + '%';
      }, delay));
    });

    const totalDuration = kernelStart + MESSAGES.length*120 + 700;
    timers.push(setTimeout(finish, totalDuration));
  }

  return { run };
})();
