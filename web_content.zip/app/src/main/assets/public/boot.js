// ============================================================
// ULTRON OS — BOOT SEQUENCE
// ============================================================
ULTRON.Boot = (function(){

  const MESSAGES = [
    '[    0.000000] ULTRON kernel: booting Linux-compatible core',
    '[    0.081942] CPU0: Neural Processing Unit detected',
    '[    0.143728] memory: initializing 64 GiB cognitive address space',
    '[    0.221504] systemd[1]: Starting ULTRON system manager...',
    '[    0.318992] systemd[1]: Starting neural-matrix.service',
    '[    0.447210] systemd[1]: Starting global-intel.service',
    '[    0.590184] systemd[1]: Starting orbital-network.service',
    '[    0.733602] systemd[1]: Mounting /CORE /DATA /ARCHIVES',
    '[    0.901775] systemd[1]: Reached target Network Online',
    '[    1.084233] ULTRON: loading graphical interface',
    '[    1.244817] ULTRON: all systems operational',
    'Welcome to ULTRON OS — secure neural command interface'
  ];

  function buildDOM(){
    const el = document.createElement('div');
    el.className = 'screen boot-screen';
    el.id = 'screen-boot';
    el.innerHTML = `
      <style>
        .boot-screen{
          align-items:center; justify-content:center;
          background:radial-gradient(ellipse at 50% 50%, #120606 0%, #030303 72%);
        }
        .boot-linux{width:100%; max-width:760px; border:1px solid rgba(255,60,50,.22); background:rgba(0,0,0,.72); box-shadow:0 0 50px rgba(255,42,31,.08), inset 0 0 40px rgba(255,42,31,.025);}
        .boot-top{display:flex;justify-content:space-between;align-items:center;padding:9px 12px;border-bottom:1px solid rgba(255,60,50,.18);font-family:var(--font-mono);font-size:10px;color:var(--red);letter-spacing:.08em}
        .boot-prompt{color:var(--grey-dim)}
        .boot-log{padding:14px 16px; min-height:260px; max-height:330px; overflow:hidden; text-align:left;}
        .boot-log-line{font-size:11px; line-height:1.72; font-family:var(--font-mono);}
        .boot-log-line .b-caret{color:var(--red-bright);}
        .boot-log-line .b-txt{color:#d8cecb; letter-spacing:0;}
        .boot-log-line .b-ok{color:var(--green);}
        .boot-log-line.welcome .b-txt{color:var(--red-bright);}
        .boot-shell-prompt{padding:7px 16px 12px;font-family:var(--font-mono);font-size:11px;color:var(--grey-dim)}
        .boot-shell-prompt span{color:var(--red-bright)}
        .boot-wrap{
          display:flex; flex-direction:column; align-items:center;
          gap:28px; padding:24px; width:100%; max-width:420px;
        }
        .boot-core{
          position:relative; width:180px; height:180px;
        }
        .boot-core svg{width:100%; height:100%;}
        .boot-ring{
          transform-origin:100px 100px;
          fill:none;
        }
        .boot-ring.r1{stroke:var(--red-dim); stroke-width:1;}
        .boot-ring.r2{stroke:var(--red); stroke-width:1.5; stroke-dasharray:8 14; opacity:0.8;}
        .boot-ring.r3{stroke:var(--red-bright); stroke-width:1; stroke-dasharray:2 6; opacity:0.6;}
        .boot-eye{
          fill:var(--red-bright);
          filter:drop-shadow(0 0 10px var(--red-bright)) drop-shadow(0 0 24px rgba(255,42,31,0.6));
          opacity:0;
          animation:eyeIn 1.8s ease forwards 0.3s;
        }
        @keyframes eyeIn{
          0%{opacity:0; r:0;}
          60%{opacity:1;}
          100%{opacity:0.95;}
        }
        .boot-core.spin-slow{animation:spin 14s linear infinite;}
        .boot-core.spin-mid{animation:spin 7s linear infinite reverse;}
        @keyframes spin{from{transform:rotate(0deg);}to{transform:rotate(360deg);}}

        .boot-title{
          font-family:var(--font-display); font-weight:900;
          font-size:26px; letter-spacing:0.28em;
          color:var(--white); text-align:center;
          text-shadow:0 0 14px rgba(255,68,51,0.5);
          opacity:0; animation:fadeUp 0.8s ease forwards 0.6s;
        }
        .boot-sub{
          font-family:var(--font-mono); font-size:10px; letter-spacing:0.3em;
          color:var(--red); text-align:center; margin-top:4px;
          opacity:0; animation:fadeUp 0.8s ease forwards 0.9s;
        }
        @keyframes fadeUp{from{opacity:0; transform:translateY(8px);}to{opacity:1; transform:translateY(0);}}

        .boot-bar-wrap{width:100%;}
        .boot-bar-track{
          width:100%; height:3px; background:var(--red-deep);
          position:relative; overflow:hidden;
        }
        .boot-bar-fill{
          height:100%; width:0%; background:linear-gradient(90deg, var(--red-dim), var(--red-bright));
          box-shadow:0 0 10px var(--red-bright);
          transition:width 0.3s ease;
        }
        .boot-bar-pct{
          font-family:var(--font-mono); font-size:10px; color:var(--red);
          letter-spacing:0.15em; margin-top:6px; text-align:right;
        }
        .boot-skip{
          position:absolute; bottom:calc(24px + var(--safe-bottom)); right:24px;
          font-family:var(--font-mono); font-size:10px; letter-spacing:0.15em;
          color:var(--grey-dim); background:none; border:1px solid var(--line);
          padding:8px 14px;
        }
      </style>
      <div class="boot-wrap">
        <div class="boot-core">
          <svg viewBox="0 0 200 200">
            <g class="spin-slow">
              <circle class="boot-ring r1" cx="100" cy="100" r="94"/>
            </g>
            <g class="spin-mid">
              <circle class="boot-ring r2" cx="100" cy="100" r="76"/>
            </g>
            <g class="spin-slow">
              <circle class="boot-ring r3" cx="100" cy="100" r="58"/>
            </g>
            <circle class="boot-eye" cx="100" cy="100" r="16"/>
          </svg>
        </div>
        <div class="boot-linux">
          <div class="boot-top"><span>ULTRON TTY1</span><span class="boot-prompt">root@ultron:~# systemctl start ultron.target</span></div>
          <div class="boot-log mono" id="boot-log"></div>
          <div class="boot-shell-prompt"><span>root@ultron:~#</span> _</div>
        </div>
        <div>
          <div class="boot-title">ULTRON OS</div>
          <div class="boot-sub">NEURAL COMMAND INTERFACE</div>
        </div>
        <div class="boot-bar-wrap">
          <div class="boot-bar-track"><div class="boot-bar-fill" id="boot-bar-fill"></div></div>
          <div class="boot-bar-pct" id="boot-bar-pct">0%</div>
        </div>
      </div>
      <button class="boot-skip" id="boot-skip">SKIP ▸</button>
    `;
    return el;
  }

  function run(onComplete){
    const el = buildDOM();
    document.getElementById('screens').appendChild(el);
    requestAnimationFrame(()=>el.classList.add('active'));

    const log = el.querySelector('#boot-log');
    const barFill = el.querySelector('#boot-bar-fill');
    const barPct = el.querySelector('#boot-bar-pct');
    const skipBtn = el.querySelector('#boot-skip');

    let finished = false;
    let timers = [];

    function finish(){
      if(finished) return;
      finished = true;
      timers.forEach(t=>clearTimeout(t));
      el.style.transition = 'opacity 0.5s ease';
      el.style.opacity = '0';
      setTimeout(()=>{
        el.remove();
        onComplete();
      }, 500);
    }

    skipBtn.addEventListener('click', finish);

    MESSAGES.forEach((msg, i)=>{
      const delay = i * 250;
      timers.push(setTimeout(()=>{
        const line = document.createElement('div');
        line.className = 'boot-log-line' + (msg.startsWith('Welcome') ? ' welcome' : '');
        line.style.animationDelay = '0.02s';
        line.innerHTML = `<span class="b-caret">›</span><span class="b-txt">${msg}</span><span class="b-ok">OK</span>`;
        log.appendChild(line);
        log.scrollTop = log.scrollHeight;
        const pct = Math.round(((i+1)/MESSAGES.length)*100);
        barFill.style.width = pct + '%';
        barPct.textContent = pct + '%';
      }, delay));
    });

    timers.push(setTimeout(finish, MESSAGES.length*250 + 650));
  }

  return { run };
})();
