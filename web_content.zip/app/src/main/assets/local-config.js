/* Bundled local configuration loaded before the game starts. */
window.ETQ_LOCAL_CONFIG = {
  preferences: { theme: "aurora", accent: "#c45cff", transparency: "strong", blur: "level", blurStrength: 14, sound: true, vibration: false, autoColor: true, paletteVersion: 2 },
  localFiles: { lessons: "game-data.js", audioDirectory: "local/audio/", click: "click.ogg", correct: ["well-done.ogg", "keep-it-up.ogg", "awesome.ogg", "smart.ogg"], incorrect: ["revise-the-rule.ogg", "try-again.ogg"] }
};
