/**
 * shiftCalculator.js
 * Shift Engine for Taghvim Sina (تقویم سینا)
 * Calculates shift schedules, active teams, countdowns, and statistics.
 * Supports 1 shift (روزکاری), 2 shifts (روزکاری و شبکاری), and 3 shifts (روزکاری، عصرکاری و شبکاری).
 */

class ShiftCalculator {
  constructor() {
    this.initDefaults();
  }

  /**
   * Initializes or reloads settings from LocalStorage or defaults
   */
  initDefaults() {
    const savedSettings = localStorage.getItem('taghvim_sina_settings');
    let settings = savedSettings ? JSON.parse(savedSettings) : {};

    // Default configuration based on requirements
    this.teamsCount = settings.teamsCount || 5;
    this.rotation = settings.rotation || [1, 3, 5, 2, 4];
    this.shiftsPer24h = settings.shiftsPer24h || 2; // 1, 2, or 3

    this.dayShiftStart = settings.dayShiftStart || '07:00';
    this.dayShiftEnd = settings.dayShiftEnd || (this.shiftsPer24h === 3 ? '15:00' : '19:00');
    this.eveningShiftStart = settings.eveningShiftStart || '15:00';
    this.eveningShiftEnd = settings.eveningShiftEnd || '23:00';
    this.nightShiftStart = settings.nightShiftStart || (this.shiftsPer24h === 3 ? '23:00' : '19:00');
    this.nightShiftEnd = settings.nightShiftEnd || '07:00';

    this.shiftDurationHours = settings.shiftDurationHours || (this.shiftsPer24h === 1 ? 8 : this.shiftsPer24h === 3 ? 8 : 12);
    
    // Numeric start hours for quick checks
    this.dayShiftStartHour = parseInt(this.dayShiftStart.split(':')[0], 10) || 7;
    this.dayShiftStartMinute = parseInt(this.dayShiftStart.split(':')[1], 10) || 0;
    this.dayShiftEndHour = parseInt(this.dayShiftEnd.split(':')[0], 10) || (this.shiftsPer24h === 3 ? 15 : 19);
    
    this.eveningShiftStartHour = parseInt(this.eveningShiftStart.split(':')[0], 10) || 15;
    this.eveningShiftStartMinute = parseInt(this.eveningShiftStart.split(':')[1], 10) || 0;
    this.eveningShiftEndHour = parseInt(this.eveningShiftEnd.split(':')[0], 10) || 23;

    this.nightShiftStartHour = parseInt(this.nightShiftStart.split(':')[0], 10) || (this.shiftsPer24h === 3 ? 23 : 19);
    this.nightShiftStartMinute = parseInt(this.nightShiftStart.split(':')[1], 10) || 0;
    this.nightShiftEndHour = parseInt(this.nightShiftEnd.split(':')[0], 10) || 7;

    this.refDayTeam = settings.refDayTeam || 2;
    if (settings.refDateGregorian) {
      this.refDateGregorian = new Date(settings.refDateGregorian);
    } else if (settings.refDateJalali && window.calendarEngine) {
      const parts = settings.refDateJalali.replace(/[-.]/g, '/').split('/').map(Number);
      if (parts.length === 3 && !isNaN(parts[0]) && !isNaN(parts[1]) && !isNaN(parts[2])) {
        const g = window.calendarEngine.jalaliToGregorian(parts[0], parts[1], parts[2]);
        this.refDateGregorian = new Date(g.gy, g.gm - 1, g.gd, this.dayShiftStartHour, this.dayShiftStartMinute, 0);
      } else {
        this.refDateGregorian = new Date(2026, 6, 20, 7, 0, 0);
      }
    } else {
      this.refDateGregorian = new Date(2026, 6, 20, 7, 0, 0);
    }
  }

  /**
   * Updates configuration parameters
   * @param {Object} config New configuration object
   */
  updateConfig(config) {
    if (config.teamsCount) this.teamsCount = parseInt(config.teamsCount, 10);
    if (config.rotation) this.rotation = config.rotation.map(Number);
    if (config.shiftsPer24h) this.shiftsPer24h = parseInt(config.shiftsPer24h, 10);
    if (config.shiftDurationHours) this.shiftDurationHours = parseInt(config.shiftDurationHours, 10);
    if (config.dayShiftStart) this.dayShiftStart = config.dayShiftStart;
    if (config.dayShiftEnd) this.dayShiftEnd = config.dayShiftEnd;
    if (config.eveningShiftStart) this.eveningShiftStart = config.eveningShiftStart;
    if (config.eveningShiftEnd) this.eveningShiftEnd = config.eveningShiftEnd;
    if (config.nightShiftStart) this.nightShiftStart = config.nightShiftStart;
    if (config.nightShiftEnd) this.nightShiftEnd = config.nightShiftEnd;
    if (config.refDateGregorian) this.refDateGregorian = new Date(config.refDateGregorian);
    if (config.refDayTeam) this.refDayTeam = parseInt(config.refDayTeam, 10);
  }

  /**
   * Calculates the shift slot index given a specific JavaScript Date object
   * @param {Date} date Target Date object
   * @returns {number} Slot index (integer)
   */
  getSlotIndex(date) {
    const diffMs = date.getTime() - this.refDateGregorian.getTime();
    const diffDays = Math.floor(diffMs / (24 * 60 * 60 * 1000));
    return diffDays;
  }

  /**
   * Gets the active teams for a specific calendar date
   * @param {Date} targetDate Date object for the calendar day
   * @returns {Object} { dayTeam: number, eveningTeam: number|null, nightTeam: number|null, shiftsCount: number }
   */
  getTeamsForDate(targetDate) {
    const dayStart = new Date(targetDate.getFullYear(), targetDate.getMonth(), targetDate.getDate(), this.dayShiftStartHour, this.dayShiftStartMinute, 0);
    const dayDiff = this.getSlotIndex(dayStart);

    let refIndex = this.rotation.indexOf(this.refDayTeam);
    if (refIndex === -1) refIndex = 0;

    const count = this.shiftsPer24h || 2;

    if (count === 1) {
      // 1 Shift per 24 hours
      let dayTeamIndex = (refIndex + dayDiff) % this.rotation.length;
      if (dayTeamIndex < 0) dayTeamIndex += this.rotation.length;
      return {
        dayTeam: this.rotation[dayTeamIndex],
        eveningTeam: null,
        nightTeam: null,
        shiftsCount: 1
      };
    } else if (count === 3) {
      // 3 Shifts per 24 hours (Day, Evening, Night)
      const baseSlot = dayDiff * 3;
      let dayIndex = (refIndex + baseSlot) % this.rotation.length;
      if (dayIndex < 0) dayIndex += this.rotation.length;

      let eveIndex = (refIndex + baseSlot + 1) % this.rotation.length;
      if (eveIndex < 0) eveIndex += this.rotation.length;

      let nightIndex = (refIndex + baseSlot + 2) % this.rotation.length;
      if (nightIndex < 0) nightIndex += this.rotation.length;

      return {
        dayTeam: this.rotation[dayIndex],
        eveningTeam: this.rotation[eveIndex],
        nightTeam: this.rotation[nightIndex],
        shiftsCount: 3
      };
    } else {
      // Default: 2 Shifts per 24 hours (Day, Night)
      const baseSlot = dayDiff * 2;
      let dayIndex = (refIndex + baseSlot) % this.rotation.length;
      if (dayIndex < 0) dayIndex += this.rotation.length;

      let nightIndex = (refIndex + baseSlot + 1) % this.rotation.length;
      if (nightIndex < 0) nightIndex += this.rotation.length;

      return {
        dayTeam: this.rotation[dayIndex],
        eveningTeam: null,
        nightTeam: this.rotation[nightIndex],
        shiftsCount: 2
      };
    }
  }

  /**
   * Determines current active team, active shift type, and next shift info right now
   * @param {Date} now Current Date object (defaults to new Date())
   * @returns {Object} Detailed shift state
   */
  getCurrentShiftStatus(now = new Date()) {
    const currentMinutesOfDay = now.getHours() * 60 + now.getMinutes();

    const parseToMinutes = (timeStr, defVal) => {
      if (!timeStr) return defVal;
      const parts = timeStr.split(':').map(Number);
      return (parts[0] || 0) * 60 + (parts[1] || 0);
    };

    const count = this.shiftsPer24h || 2;
    const dayStartMin = parseToMinutes(this.dayShiftStart, 7 * 60);
    const dayEndMin = parseToMinutes(this.dayShiftEnd, (count === 3 ? 15 : 19) * 60);
    const eveStartMin = parseToMinutes(this.eveningShiftStart, 15 * 60);
    const eveEndMin = parseToMinutes(this.eveningShiftEnd, 23 * 60);
    const nightStartMin = parseToMinutes(this.nightShiftStart, (count === 3 ? 23 : 19) * 60);
    const nightEndMin = parseToMinutes(this.nightShiftEnd, 7 * 60);

    let shiftDate = new Date(now.getFullYear(), now.getMonth(), now.getDate(), this.dayShiftStartHour, this.dayShiftStartMinute, 0);
    if (currentMinutesOfDay < dayStartMin) {
      // Before day shift start, belongs to previous cycle's night shift
      shiftDate.setDate(shiftDate.getDate() - 1);
    }

    const todayTeams = this.getTeamsForDate(shiftDate);
    const tomorrowDate = new Date(shiftDate);
    tomorrowDate.setDate(tomorrowDate.getDate() + 1);
    const tomorrowTeams = this.getTeamsForDate(tomorrowDate);

    let activeShiftLabel = 'روزکاری';
    let activeTeam = todayTeams.dayTeam;
    let nextShiftLabel = 'شبکاری';
    let nextShiftTeam = todayTeams.nightTeam;
    let nextShiftTime = new Date(shiftDate);
    let isDayShift = true;
    let isEveningShift = false;
    let isNightShift = false;

    if (count === 1) {
      // 1 Shift mode
      if (currentMinutesOfDay >= dayStartMin && currentMinutesOfDay < dayEndMin) {
        activeShiftLabel = 'روزکاری';
        activeTeam = todayTeams.dayTeam;
        isDayShift = true;
        nextShiftLabel = 'روزکاری بعدی';
        nextShiftTeam = tomorrowTeams.dayTeam;
        nextShiftTime = new Date(tomorrowDate);
        nextShiftTime.setHours(Math.floor(dayStartMin / 60), dayStartMin % 60, 0, 0);
      } else {
        activeShiftLabel = 'استراحت / غیر شیفت';
        activeTeam = todayTeams.dayTeam;
        isDayShift = false;
        nextShiftLabel = 'روزکاری';
        if (currentMinutesOfDay < dayStartMin) {
          nextShiftTeam = todayTeams.dayTeam;
          nextShiftTime = new Date(now);
          nextShiftTime.setHours(Math.floor(dayStartMin / 60), dayStartMin % 60, 0, 0);
        } else {
          nextShiftTeam = tomorrowTeams.dayTeam;
          nextShiftTime = new Date(tomorrowDate);
          nextShiftTime.setHours(Math.floor(dayStartMin / 60), dayStartMin % 60, 0, 0);
        }
      }
    } else if (count === 3) {
      // 3 Shifts mode (Day, Evening, Night)
      if (currentMinutesOfDay >= dayStartMin && currentMinutesOfDay < eveStartMin) {
        // Day Shift
        activeShiftLabel = 'روزکاری';
        activeTeam = todayTeams.dayTeam;
        isDayShift = true;
        nextShiftLabel = 'عصرکاری';
        nextShiftTeam = todayTeams.eveningTeam;
        nextShiftTime = new Date(shiftDate);
        nextShiftTime.setHours(Math.floor(eveStartMin / 60), eveStartMin % 60, 0, 0);
      } else if (currentMinutesOfDay >= eveStartMin && currentMinutesOfDay < nightStartMin) {
        // Evening Shift
        activeShiftLabel = 'عصرکاری';
        activeTeam = todayTeams.eveningTeam;
        isEveningShift = true;
        isDayShift = false;
        nextShiftLabel = 'شبکاری';
        nextShiftTeam = todayTeams.nightTeam;
        nextShiftTime = new Date(shiftDate);
        nextShiftTime.setHours(Math.floor(nightStartMin / 60), nightStartMin % 60, 0, 0);
      } else {
        // Night Shift
        activeShiftLabel = 'شبکاری';
        activeTeam = todayTeams.nightTeam;
        isNightShift = true;
        isDayShift = false;
        nextShiftLabel = 'روزکاری';
        nextShiftTeam = tomorrowTeams.dayTeam;
        nextShiftTime = new Date(tomorrowDate);
        nextShiftTime.setHours(Math.floor(dayStartMin / 60), dayStartMin % 60, 0, 0);
      }
    } else {
      // 2 Shifts mode (Day, Night)
      if (currentMinutesOfDay >= dayStartMin && currentMinutesOfDay < nightStartMin) {
        // Day Shift
        activeShiftLabel = 'روزکاری';
        activeTeam = todayTeams.dayTeam;
        isDayShift = true;
        nextShiftLabel = 'شبکاری';
        nextShiftTeam = todayTeams.nightTeam;
        nextShiftTime = new Date(shiftDate);
        nextShiftTime.setHours(Math.floor(nightStartMin / 60), nightStartMin % 60, 0, 0);
      } else {
        // Night Shift
        activeShiftLabel = 'شبکاری';
        activeTeam = todayTeams.nightTeam;
        isNightShift = true;
        isDayShift = false;
        nextShiftLabel = 'روزکاری';
        nextShiftTeam = tomorrowTeams.dayTeam;
        nextShiftTime = new Date(tomorrowDate);
        nextShiftTime.setHours(Math.floor(dayStartMin / 60), dayStartMin % 60, 0, 0);
      }
    }

    const timeRemainingMs = Math.max(0, nextShiftTime.getTime() - now.getTime());
    const remainingHours = Math.floor(timeRemainingMs / (1000 * 60 * 60));
    const remainingMinutes = Math.floor((timeRemainingMs % (1000 * 60 * 60)) / (1000 * 60));
    const remainingSeconds = Math.floor((timeRemainingMs % (1000 * 60)) / 1000);

    return {
      dayTeam: todayTeams.dayTeam,
      eveningTeam: todayTeams.eveningTeam,
      nightTeam: todayTeams.nightTeam,
      activeTeam,
      activeShiftLabel,
      isDayShift,
      isEveningShift,
      isNightShift,
      nextShiftLabel,
      nextShiftTeam,
      nextShiftTime,
      remainingHours,
      remainingMinutes,
      remainingSeconds,
      timeRemainingMs
    };
  }

  /**
   * Generates shift information for a given team over a specific Jalali/Gregorian month or year range
   * @param {number} teamNumber Team ID (e.g. 1, 2, 3, 4, 5)
   * @param {Date} startDate Start range
   * @param {Date} endDate End range
   * @returns {Object} Monthly / Yearly Statistics
   */
  getTeamStatistics(teamNumber, startDate, endDate) {
    let dayShiftsCount = 0;
    let eveningShiftsCount = 0;
    let nightShiftsCount = 0;
    let totalWorkingHours = 0;
    let totalRestDays = 0;

    let curr = new Date(startDate.getFullYear(), startDate.getMonth(), startDate.getDate(), 7, 0, 0);
    const end = new Date(endDate.getFullYear(), endDate.getMonth(), endDate.getDate(), 7, 0, 0);

    while (curr <= end) {
      const teams = this.getTeamsForDate(curr);
      let workedToday = false;

      if (teams.dayTeam === teamNumber) {
        dayShiftsCount++;
        totalWorkingHours += this.shiftDurationHours;
        workedToday = true;
      }
      if (teams.eveningTeam === teamNumber) {
        eveningShiftsCount++;
        totalWorkingHours += this.shiftDurationHours;
        workedToday = true;
      }
      if (teams.nightTeam === teamNumber) {
        nightShiftsCount++;
        totalWorkingHours += this.shiftDurationHours;
        workedToday = true;
      }

      if (!workedToday) {
        totalRestDays++;
      }

      curr.setDate(curr.getDate() + 1);
    }

    return {
      teamNumber,
      dayShiftsCount,
      eveningShiftsCount,
      nightShiftsCount,
      totalShifts: dayShiftsCount + eveningShiftsCount + nightShiftsCount,
      totalWorkingHours,
      totalRestDays
    };
  }
}

// Global instance
window.shiftCalculator = new ShiftCalculator();

