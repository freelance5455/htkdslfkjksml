LOCAL APP CONTENT

The app loads local-config.js before app.js. Game lessons are bundled in game-data.js.
Place any licensed audio assets in local/audio/ using the filenames declared in local-config.js.
No audio picker is exposed in the app; content is bundled with the project and included in the APK at build time.
Only the wallpaper image is selected by the user inside the app.

Audio files are not included in this project yet; the app currently uses Android WebView speech synthesis for spoken feedback and a generated click tone.
