const CACHE='lana-falcon-mobile-v1.157.3-currency-strength-candidate';
const FILES=['./','./index.html','./mt5_connect.html','./manifest.webmanifest','./icons/icon-192.png','./icons/icon-512.png','./unit_art/salem.webp','./unit_art/falcon.webp','./unit_art/fighter.webp','./unit_art/correction.webp','./unit_art/psychologist.webp','./unit_art/economic.webp','./unit_art/risk.webp'];
self.addEventListener('install',event=>event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(FILES)).then(()=>self.skipWaiting())));
self.addEventListener('activate',event=>event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith('lana-falcon-')&&k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',event=>{
  const req=event.request; const url=new URL(req.url);
  if(req.method!=='GET'||url.pathname.includes('/api/')) return;
  event.respondWith(caches.match(req).then(hit=>hit||fetch(req).then(res=>{if(res.ok&&url.origin===self.location.origin){const copy=res.clone();caches.open(CACHE).then(c=>c.put(req,copy));}return res;}).catch(()=>caches.match('./index.html'))));
});
