# NOMIDMAN TRANS CO. LTD — Estate & Asset Marketplace (Website)

A responsive, bilingual-plus (English · French · Arabic with RTL) property and asset listing
website with light/dark mode, owner and customer accounts, a cascading location finder built
from your Excel address file, subscription plans, and an admin area.

## 1. Folder structure

```
eassetco/
├── index.html            Main page (single-page app)
├── README.md             This file
├── css/style.css         Theme, layout, responsive + RTL styles
├── assets/map-bg.webp    Background map (webp), with map-bg.jpg as fallback
└── js/
    ├── config.js         Business name, fees, plans, currencies, demo/live switch, endpoints
    ├── i18n.js           English / French / Arabic text
    ├── i18n_extra.js     Additional translated text
    ├── geo.js            Location hierarchies generated from WED_ADDRESS.xlsx
    ├── db.js             Accounts, OTP, listings, subscriptions, payments, admin data
    └── app.js            Pages, forms, dashboards, admin, router
```

## 2. How to run

Open `index.html` through any web server (double-clicking works for most features, but a
local server is recommended):

```bash
cd eassetco
python3 -m http.server 8080      # then open http://localhost:8080
```

### Test accounts (demo data)

| Role  | Login                          | Password        |
|-------|--------------------------------|-----------------|
| Admin | admin@e-asset.co.ug            | Admin@EAsset2026 |
| Owner | grace@example.com              | Owner@1234      |

Create your own account from **Register**; OTP codes are shown in a yellow toast while
`demoMode` is `true` (see §5).

## 3. Features implemented

**Branding & experience**
- Business name "NOMIDMAN TRANS CO. LTD" in header, footer and page title.
- Background estate photo, glass-style cards, larger readable text (18px base, scaling down on phones).
- Language switcher: English, Français, العربية (Arabic switches to right-to-left layout).
- Dark / light mode toggle (remembers the choice).
- Fully responsive: phone, tablet and desktop layouts; mobile hamburger menu.

**Accounts**
- Sign in / Sign out (session kept in the browser).
- Registration: role (owner or customer), first and last legal names, age (18–120), gender
  (male/female), nationality, ID type (National ID, Driving Permit or Passport) and number,
  telephone with OTP verification, email with OTP verification, and a mixed-character
  password (8+ characters with upper, lower, number and symbol, plus confirmation).
- ID numbers are **hashed** and only shown **masked** (e.g. `CM•••••••8AB`).
- Forgot password: send a code to the registered phone or email, verify it, set a new password.
- Passwords are salted and hashed with PBKDF2-SHA-256 (60,000 iterations). Never stored in plain text.

**Listing photos**
- Max photos per listing by plan: **Budget 3, Economy 6, Premium 10**.
- Accepted types: JPEG, PNG, WebP. Files up to 20 MB are accepted and each is automatically resized to 4 MB or less.
- Photos are resized to 1600 px wide and saved as JPEG; compression is increased automatically until each stored photo is 4 MB or less.
- The first photo is the card cover; the detail page shows a gallery with thumbnails.
- Limits are set in `js/config.js` (`plans[...].photos` and the `photos` block).

**Trust, discovery and owner tools (added in this version)**
- **Verified owner badge:** admins mark owners as verified in the Users tab. The badge appears on their listings and contact card.
- **WhatsApp button:** opens a chat with the owner's number, with the listing title pre-filled.
- **Similar listings:** up to three other listings in the same category, shown under each listing.
- **Saved searches:** customers and owners save a browse filter from the Browse page, see how many listings match now, and run it again from the dashboard. Email alerts need the backend.
- **Listing boost:** owners pay to put a listing at the top of search and home for 7 days, marked "Featured". The price (UGX 10,000) is a placeholder set in `config.js` under `boost`.
- **Owner insights:** each listing shows views, likes and contact clicks on the owner dashboard.
- **Renewal warning:** the owner dashboard warns when a plan ends within 7 days, or when listings are hidden and will be deleted.
- **Payment receipts:** owners can view and print a receipt for each payment.
- **Activity log:** the admin area records verification, suspension, listing removal and deletion.
- **Installable app:** the site includes a web app manifest, icons and an offline cache, so it can be added to a phone's home screen. Installation needs the site to be served over HTTPS in production.

Not yet built: map view and sort-by-distance (these need latitude and longitude for each location), emailed monthly reports and renewal emails (these need the backend).

**Language of listing text**
- The four demo listings have French and Arabic titles and descriptions (set in `js/app.js` under `SAMPLE_TX`).
- Listings typed by owners are shown exactly as the owner wrote them. Owners can add their own French or Arabic text if you later add optional translation fields to the listing form.

**Location names in French and Arabic**
- The 80 top-level names (regions, provinces, states and counties in all six countries) show in French and Arabic. Their translations are in `js/app.js` under `TOP_TX`.
- Districts and smaller places keep their official spelling in every language.

**Registration and support updates**
- The phone field starts with the dialling code of the country of registration: +256 Uganda, +255 Tanzania, +250 Rwanda, +211 South Sudan, +254 Kenya, +243 DR Congo.
- Accepted identity documents: National ID, driving permit, passport and Voter ID card.
- Currencies include CDF (Congolese franc). South Sudanese pound (SSP) is not included because its exchange rates are unofficial and volatile.
- The four DRC provinces missing from the spreadsheet (Kongo-Central, Kwango, Kwilu and Lomami) are added as top-level names, but their districts and smaller places must be supplied before listings can be made there.
- A help line (English, French and Arabic call handlers) appears in the footer and on the About Us page.

**Office hours**
- Monday to Friday 8:30 AM – 5:00 PM, Saturday 9:00 AM – 2:00 PM, Sunday closed (East Africa Time). Set in `js/config.js` under `hours`.
- The footer and About Us page show whether the office is open now, based on the visitor's clock in East Africa Time. Public holidays are not yet excluded.

**Daily exchange rates**
- `scripts/update-rates.mjs` fetches USD-based rates from a provider and saves them to `data/rates.json`. The website reads that file on every visit and shows the date the rates were taken.
- The script checks the rates before saving: every currency must be a positive number, and no rate may move more than 25% since the last update (`RATES_MAX_CHANGE`). If the download or a check fails, the last saved rates are kept and the script exits with an error.
- If the rates file cannot be loaded, the site uses the built-in fallback rates in `js/config.js` and shows "Converted prices are indicative."
- Rates older than 3 days show a "may be out of date" warning.
- The default provider is open.er-api.com, which is free and needs no key, but check its terms for commercial use and its attribution requirement before launch. Other providers can be used by setting `RATES_API_URL` (and `RATES_API_KEY` if required).
- Run once a day on the server, for example at 06:00 East Africa Time:
  `0 6 * * * cd /path/to/eassetco && node scripts/update-rates.mjs >> logs/rates.log 2>&1`
  (Node.js 18 or newer is required. On Windows, use Task Scheduler with the same command.)

**DRC provinces: Kongo Central, Kwango, Kwilu and Lomami**
- Loaded from the four provincial documents supplied. Each province runs: territory or city, then secteur, chefferie or commune, then groupement or quartier.
- Communes are labelled "(commune)" and chefferies "(chefferie)". Where a city shares its name with a territory, the city is labelled "(city)", for example "Kenge (city)" and "Kabinda (city)".
- Some levels are not in the documents, so the cascade stops there. These include the quartiers of Bandundu, Kikwit, Mwene-Ditu and Kabinda cities, and the groupements of several Kwango and Lomami territories. Some documents give only examples ("e.g.") rather than full lists, and only the named examples are included. Please send the complete lists if you need them.
- Only the top-level names are translated into French and Arabic, as agreed.

**Identity document number checks**
- At registration, document numbers must contain only letters and numbers (spaces and dashes are removed), fall within the length set for the document type, and not be obviously fake (all one digit, or simple sequences such as 12345678).
- National ID rules depend on the country of registration (`idRules.national_id` in `js/config.js`):
  - Uganda: 14 characters, letters and numbers
  - Tanzania: 20 digits
  - Rwanda: 16 digits
  - DR Congo: 12 digits
  - South Sudan: 9 digits
  - Kenya: 8 to 9 digits
  - Other nationalities: 8 to 20 characters (generic)
- Driving permit numbers are alphanumeric in all six countries (`idRules.driving_permit`):
  - Uganda: 10 to 12 characters
  - Tanzania: 10 to 14 characters
  - South Sudan: 11 characters
  - Kenya: 8 characters
  - Rwanda and DR Congo: lengths vary, so a general range of 6 to 20 characters is used until a fixed range is confirmed.
- Passport numbers (`idRules.passport`): two letters followed by digits in Uganda (8 or 9 characters), Kenya (7 or 9), Tanzania (8 or 9), Rwanda (8) and DR Congo (9). South Sudan is alphanumeric, 9 characters.
- Voter ID lengths are still a generic placeholder (8 to 20 characters). Confirm the official lengths before launch.
- The number field shows the expected format for the chosen nationality.
- These checks confirm the format only. They do not confirm that a number is genuine. Document upload with staff review is the planned next step.

**Other nationality**
- Choosing "Other" at registration shows a box where the person types their country name.
- The typed country is stored as the nationality, so the Users tab shows it in a Nationality column, the search finds it, and the revenue-by-country report lists it by name.

**Arabic numerals**
- In Arabic mode, prices, totals, counts and dates use Arabic-Indic digits (٠١٢٣٤٥٦٧٨٩).
- Phone numbers, email addresses, ID numbers and OTP codes stay in Latin digits so they can be dialled, typed and copied exactly.

**Appreciation gifts**
- A voluntary "Show appreciation" link is in the footer. No sign-in is needed.
- Givers choose any amount in UGX, USD, GBP, EURO, KES, TZS or RWF. The UGX equivalent must be between UGX 1,000 and UGX 50,000 (limits in `config.js` under `gift`).
- Gifts appear as their own category in the admin revenue reports.

**Owner registration fee**
- One-time registration fee of **UGX 20,000**, required before listing. The amount charged is always UGX.
- Display currency by country of registration (`registrationDisplayCurrency` in `js/config.js`): UGX Uganda, TZS Tanzania, RWF Rwanda, CDF DR Congo, KES Kenya, USD South Sudan. "Other" and any unlisted country use USD (`displayCurrencyDefault`).
- Subscription plan prices follow the same rule on the owner dashboard and in the payment dialog. On the home page they follow the currency selector.

**Subscriptions (91-day periods)**

| Plan           | Price          | Items allowed |
|----------------|----------------|---------------|
| BUDGET DISPLAY | UGX 50,000     | up to 2       |
| ECONOMY DISPLAY| UGX 150,000    | up to 13      |
| PREMIUM DISPLAY| UGX 300,000    | up to 25      |

- When a subscription expires, its listings **disappear from the public site** and remain on the
  owner's dashboard marked as hidden.
- Renew at any time (extends by 91 days from the current expiry).
- After **15 days** without renewal, the listings are **automatically deleted** from the dashboard.

**Listings (Sale or Rent)**
- Categories: Plots & Farm Land, Houses & Hostels, Commercial Premises, Hotels, Automobiles, and Other Items (for example animals, P.A systems, schools and parking yards).
- Location dropdowns in the correct order, drawn from the Excel file:
  - **Uganda:** Region → District → Sub-county/Division → Parish/Ward → Village/Cell
  - **Tanzania:** Region → District Council → Ward → Village
  - **Rwanda:** Region → District → Sector → Cell → Village
  - **South Sudan:** State → County → Payam → Boma
  - **Kenya:** Province → County → Constituency → Ward
  - **DR Congo:** Province → Territory → Chiefdom/Sector → Grouping/Quarter → Village/Sub-quarter
- Multi-select feature dropdowns that match each category (e.g. houses: single room, double
  rooms, self-contained, fenced, solar, camera, ceiling board, tiled floor, resident landlord;
  land: titled, road access, water access, electricity access, market proximity, expansion).
- Payment terms: Full payment and/or Installments (sale); Daily, Weekly, Monthly, Quarterly, Yearly (rent).
- Prices in UGX, USD, GBP (British Pound), EURO, KES, TZS or RWF, with approximate equivalents.

**Customers**
- Browse, filter by category, sale/rent, country and cascading location, min/max price,
  display currency and sort order.
- Like, save, and view saved and liked items on their dashboard.
- Contact the owner by **call** or **email** using the owner's verified phone and email.
  Contact details are shown only to signed-in users.
- The site does not process property payments. Owner and customer transact on site.

**Payments**
- Methods shown with brand badges: MTN MoMo, Airtel Money, Orange Money, M-PESA, VISA,
  Mastercard, Google Pay and bank transfer.
- All subscription and registration payments are routed through **Flutterwave** (see the Flutterwave edition section).

**Admin area** (`#/admin`)
- Sign-in is two-step: password first, then a 6-digit security code sent to the admin's email. The admin session starts only after the code is entered. In demo mode the code is shown on screen. In production the backend must send and verify the code (see §6, item 2).
- Overview: total users, owners, live listings, hidden listings, total revenue.
- Users: suspend / reactivate / delete.
- Listings: remove / restore.
- Payments: full history with CSV export.

## 4. Routes (for links and navigation)

| Route | Page |
|-------|------|
| `#/` | Home |
| `#/listings` | Browse and filter |
| `#/listings?cat=house&type=rent` | Pre-filtered browse |
| `#/listing/<id>` | Listing details, like, save, contact |
| `#/register`, `#/login`, `#/forgot` | Accounts |
| `#/dashboard` | Owner or customer dashboard |
| `#/new`, `#/edit/<id>` | Add or edit a listing (owners) |
| `#/admin` | Admin area |

## 5. Demo mode vs. live mode

`js/config.js`:

```js
demoMode: true   // OTP codes are shown on screen; payments are simulated
demoMode: false  // OTP and payments call your backend endpoints
```

Demo mode is for testing the design and flows only. **Do not run live with `demoMode: true`.**

## 6. Going live — what you must add

The website is a front end. A few things must run on a secure server before real money or
personal data is handled. Do **not** put secret keys in the browser.

1. **Backend & database.** Move the logic in `js/db.js` (accounts, listings, subscriptions,
   payments) to a server with a real database (e.g. PostgreSQL) and an API. Keep password
   hashing on the server.
2. **SMS and email OTP.** Implement the endpoints in `config.js`:
   - `POST /api/otp/send` — generate a 6-digit code, store it with a 5-minute expiry, send it
     by SMS (e.g. Africa's Talking, Twilio) or email (SMTP / SendGrid).
   - `POST /api/otp/verify` — return `{ "ok": true }` only if the code matches and has not expired.
3. **Flutterwave.** Create a merchant account at Flutterwave and get your public key (in the site) and secret key (on the server only). Then build the server endpoint `/api/flutterwave/verify` that confirms each transaction with Flutterwave before any benefit is recorded.
4. **Official logos.** The payment badges are styled text placeholders. Replace them with the
   official logo files supplied by each provider (MTN MoMo, Airtel Money, Orange Money, M-PESA,
   VISA, Mastercard, Google Pay) and check each brand's usage guidelines.
5. **Subscription clock.** Run a scheduled job (daily) that hides expired listings and deletes
   listings 15 days after expiry, then notifies owners before deletion. The browser currently
   does this check on page load.
6. **Security checklist.** HTTPS everywhere; rate-limit OTP and login attempts; CSRF protection;
   server-side validation of every field; audit log for admin actions; regular backups; and
   privacy notices covering how ID data is stored and used (data protection law applies in
   Uganda, Kenya, Rwanda, Tanzania and DR Congo).
7. **Terms and business details.** Replace the placeholder support email and phone in
   `config.js`. Add your Terms of Use, Privacy Policy and refund policy.
8. **FX rates.** The conversions in `config.js` are indicative. Update them regularly or fetch
   live rates from a reliable source.

## 7. Updating locations

`js/geo.js` was generated from `WED_ADDRESS.xlsx`. To refresh it after editing the spreadsheet,
run a script that reads each sheet into a nested object (Region → District → … → Village),
trims spaces, removes duplicates, and writes `window.GEO = {...}`. Keep the same country codes
(UGA, TZA, RWA, SSD, KEN, COD).

Note: the sheet `KSL` (Kenya sub-locations) is a flat list with no parent hierarchy, so it is
not used in the cascading dropdowns. Use `KPCA` for Kenya.

## 8. Known limits of this build

- Data is stored in the browser (localStorage) for testing. Clearing browser data resets it.
- Photos are stored inside the browser (localStorage, roughly 5 MB in total), so demo mode fills up after a
  few listings with full photo sets. Live sites should store photos in cloud object storage (S3 or Cloudinary).
- Passwords and ID checks are client-side in demo mode; enforce them server-side in production.

## Flutterwave edition

This edition uses **Flutterwave** for live payments. Everything else is the same.

**Settings (`js/config.js`)**
- `paymentProvider: "flutterwave"` selects Flutterwave for live payments.
- `flutterwave.publicKey`: replace the placeholder with your **public** key. It is safe in the browser.
- `flutterwave.paymentOptions`: card, mobile money, bank transfer and USSD. Flutterwave shows the options available in each country.
- Amounts are always charged in UGX. Keep the **secret** key only on the server.

**How a live payment works**
1. The browser loads Flutterwave's checkout script only when a live payment starts.
2. The customer pays in the Flutterwave checkout window.
3. The browser sends the transaction ID to your server at `/api/flutterwave/verify`.
4. The server calls Flutterwave with the **secret** key to confirm the transaction is successful, the amount is correct, and the transaction has not been used before.
5. Only then does the server record the registration, subscription, boost or gift. The browser must never grant a benefit by itself.

**Before going live**
- Switch `demoMode` to `false` only after the server verification endpoint is built.
- Use Flutterwave's test keys first, then live keys.
- Check coverage with Flutterwave for each country. Their documentation clearly covers Uganda, Tanzania, Rwanda, Kenya, Ghana and Zambia. Coverage for the DR Congo and South Sudan is not confirmed, so please check with Flutterwave in writing.
- Confirm which currencies Flutterwave settles in for your account. Charged amounts are UGX.

## One codebase, several editions (developers)

This folder is the **single source** for every edition. Do not edit the packaged copies.

- `js/edition.js` holds the only per-edition settings: brand and payment provider.
- `node scripts/build-editions.mjs` builds every edition into `dist/`. It also checks that each edition shows only its own payment provider's wording.
- `node tests/run-all.mjs` builds each edition, serves it, runs the automatic checks (`tests/suite.mjs`) and reports one summary. The exit code is 0 only if everything passes. It needs Node.js 18+, Python 3, and Playwright (`npm i playwright && npx playwright install chromium`).

## Admin tools (saved in the browser)

- **Settings tab:** office address, P.O. Box, phone, support email, registration fee, boost price, plan prices, gift limits and office hours.
- **Content tab:** site text in English, French or Arabic (headline, tagline, About Us paragraphs, help line, footer text and the four "How it works" steps).
- **Overview tab:** choose which dashboard widgets to show.

These changes are saved only in the admin's browser. The live site must store them on the server. Until then, use them for testing and for setting up the content before launch.

## Sign-up rules (agreed)

- **Owners pay first.** The registration fee is held as a pending payment. The SMS and email codes can be requested only after the fee is held. The account is created and the payment confirmed only when both the phone and the email are verified.
- **Refund rule.** A held payment not confirmed within 24 hours is marked "refund_due" for the admin to refund.
- **Customers get no codes.** Customers enter name, nationality, email and password. The phone is optional. No code is sent at sign-up, and customer accounts are marked unverified.
- The backend must enforce the same rules on the server; the browser version only demonstrates them.

## Upgrade to List (agreed)

- A customer chooses **Upgrade to List** on the dashboard and **pays** the registration fee first.
- Only after payment do the phone and email verification codes become available. The customer can add a phone number if they didn't give one at sign-up.
- When both the phone and the email are verified, the account becomes an owner automatically, and saved searches, likes and saved listings are kept.
- Refund rule: if the phone and email are not verified within 24 hours of payment, the payment is refunded.
- The prototype confirms the payment itself with a demo step. On the live site, the server confirms it with the payment provider.

## Gift limits

The gift limits are set in **Settings** (Minimum and Maximum gift). The explanatory sentence in the gift box fills in these live values, so it always matches the limits in use.

## Admin address

The admin sign-in page opens at **`#/zero`**, for example `yoursite.com/#/zero`. Change the route name in `js/app.js` (search for `"zero"`) if you ever need a different address. This is a convenience, not security: real protection comes from server-side sign-in and rate limits.

## NOTICE box

Switched on and off in the admin **Notice** tab. The box is labelled NOTICE, appears at the top of the home page, and shows the text in the visitor's language (English, French or Arabic, falling back to English).

## Owner referral (promotions)

- Each owner has a referral code (for example `NTO-0001`) and a link: `yoursite.com/#/register?ref=NTO-0001`. The owner can share the link by WhatsApp, SMS or email from the dashboard.
- A new owner who registers through the link is recorded as a referral. Self-referrals (same phone or email) are not counted.
- The referrer's credit (UGX 2,000 by default, adjustable in Settings) is released only when the referred owner has **registered and completed a subscription plan**.
- Credit is applied to a subscription plan at payment. It cannot be withdrawn as cash.
- Unused credit expires after 12 months without use. The expiry period is set in `js/config.js` under `referral`.
