// =====================================================================
//  DEAD ZONE - personnages : joueur personnalisable + zombies
// =====================================================================
(function(){
"use strict";
const DZ=window.DZ;const M=DZ.models,mergeGeo=M.mergeGeo,T4=M.T4;
const SKIN=[0xf1c9a5,0xe0ac82,0xc68c5f,0xa5693f,0x7a4a2c,0x4e2f1d];
const HAIRC=[0x1a1410,0x4a3320,0x7a5230,0xb58a4a,0xc9c0b0,0xa0301c,0x2a3f66];
const JACKET=[0x6b5a3e,0x3f4d3a,0x2e3a55,0x7a2b2b,0x3a3a3a,0x8a7a4a,0x5a3f6a,0xcfcfcf];
const PANTS=[0x3a3a2e,0x2b3a55,0x1f1f1f,0x5a4a32,0x4a5a3a,0x6a6a6a];
const PACKC=[0x4a4a32,0x55402a,0x2a3a4a];
const OPT={
 skin:{label:'Peau',n:6,colors:SKIN},
 hair:{label:'Coiffure',n:5,names:['Chauve','Courts','Longs','Crête','Côtés rasés']},
 hairCol:{label:'Couleur cheveux',n:7,colors:HAIRC},
 beard:{label:'Barbe',n:3,names:['Aucune','Courte','Longue']},
 hat:{label:'Couvre-chef',n:4,names:['Aucun','Casquette','Bonnet','Chapeau']},
 jacket:{label:'Veste',n:8,colors:JACKET},
 pants:{label:'Pantalon',n:6,colors:PANTS},
 pack:{label:'Sac',n:3,names:['Aucun','Sac à dos','Gros sac']},
 build:{label:'Corpulence',n:3,names:['Mince','Normal','Costaud']}
};
const DEFAULT={skin:1,hair:1,hairCol:1,beard:0,hat:1,jacket:0,pants:0,pack:1,build:1};
const cap=(r,l,s)=>new THREE.CapsuleGeometry(r,l,4,s||8);
const sph=(r,w,h)=>new THREE.SphereGeometry(r,w||10,h||8);
const cyl=(a,b,h,s)=>new THREE.CylinderGeometry(a,b,h,s||10);
const box=(w,h,d)=>new THREE.BoxGeometry(w,h,d);

// géométries fusionnées d'un humanoïde (couleurs dans les sommets)
function geos(c,z){
 z=z||{};
 const bw=[0.88,1,1.18][c.build==null?1:c.build]*(z.bw||1);
 const skin=z.skin!=null?z.skin:SKIN[c.skin],hair=HAIRC[c.hairCol],jacket=z.jacket!=null?z.jacket:JACKET[c.jacket],pants=z.pants!=null?z.pants:PANTS[c.pants];
 const dark=0x2b2118;
 // corps
 const b=[];
 b.push({g:cap(0.14*bw,0.2),m:T4(0,0.74,0,0,0,0,1,1,0.72),c:jacket});
 b.push({g:cap(0.125*bw,0.06),m:T4(0,0.56,0,0,0,0,1,1,0.78),c:pants});
 b.push({g:cyl(0.138*bw,0.138*bw,0.04,10),m:T4(0,0.63,0,0,0,0,1,1,0.74),c:dark});
 b.push({g:cyl(0.05,0.055,0.08,8),m:T4(0,0.97,0),c:skin});
 if(!z.zombie){
  b.push({g:cyl(0.1*bw,0.12*bw,0.05,10),m:T4(0,0.92,0,0,0,0,1,1,0.8),c:jacket}); // col
  if(c.pack===1){b.push({g:box(0.26*bw,0.3,0.12),m:T4(0,0.78,-0.15),c:PACKC[0]});b.push({g:box(0.22*bw,0.1,0.13),m:T4(0,0.9,-0.15),c:0x3a3a28});b.push({g:box(0.03,0.28,0.2),m:T4(-0.09*bw,0.8,-0.02),c:0x2a2a22});b.push({g:box(0.03,0.28,0.2),m:T4(0.09*bw,0.8,-0.02),c:0x2a2a22})}
  if(c.pack===2){b.push({g:box(0.34*bw,0.44,0.17),m:T4(0,0.78,-0.17),c:PACKC[1]});b.push({g:box(0.3*bw,0.12,0.18),m:T4(0,0.96,-0.17),c:0x44331f});b.push({g:cyl(0.06,0.06,0.34*bw,8),m:T4(0,1.07,-0.17,0,0,Math.PI/2),c:0xc9772a});b.push({g:box(0.08,0.2,0.1),m:T4(-0.2*bw,0.7,-0.17),c:0x44331f});b.push({g:box(0.08,0.2,0.1),m:T4(0.2*bw,0.7,-0.17),c:0x44331f});b.push({g:box(0.03,0.3,0.22),m:T4(-0.1*bw,0.8,-0.02),c:0x2a2a22});b.push({g:box(0.03,0.3,0.22),m:T4(0.1*bw,0.8,-0.02),c:0x2a2a22})}
 }else{
  for(let k=0;k<4;k++)b.push({g:sph(0.04+k%2*0.02,6,4),m:T4(-0.07+k*0.05,0.66+k%3*0.08,0.095,0,0,0,1,0.7,0.4),c:0x5a1414});
  b.push({g:box(0.16*bw,0.05,0.1),m:T4(0.06,0.5,0.08,0,0,0.3),c:jacket*0.6|0});
 }
 // tête
 const h=[];
 h.push({g:sph(0.125),m:T4(0,1.075,0,0,0,0,1,1.1,0.97),c:skin});
 h.push({g:sph(0.03,6,5),m:T4(-0.125,1.07,0),c:skin});h.push({g:sph(0.03,6,5),m:T4(0.125,1.07,0),c:skin});
 h.push({g:sph(0.026,6,5),m:T4(0,1.052,0.122),c:skin});
 const eye=z.zombie?0xd22020:0x14110f;
 h.push({g:sph(0.016,6,4),m:T4(-0.045,1.095,0.113),c:eye});h.push({g:sph(0.016,6,4),m:T4(0.045,1.095,0.113),c:eye});
 if(!z.zombie){h.push({g:box(0.05,0.012,0.012),m:T4(-0.045,1.12,0.118),c:hair});h.push({g:box(0.05,0.012,0.012),m:T4(0.045,1.12,0.118),c:hair})}
 else{h.push({g:box(0.07,0.012,0.012),m:T4(0,1.02,0.12),c:0x401010})}
 const hs=z.zombie?(c.hair||0):c.hair;
 if(hs===1)h.push({g:new THREE.SphereGeometry(0.132,12,8,0,Math.PI*2,0,Math.PI*0.56),m:T4(0,1.09,-0.004,0,0,0,1,1.05,1),c:hair});
 if(hs===2){h.push({g:new THREE.SphereGeometry(0.134,12,8,0,Math.PI*2,0,Math.PI*0.6),m:T4(0,1.09,-0.004,0,0,0,1,1.05,1),c:hair});h.push({g:cap(0.1,0.16),m:T4(0,0.99,-0.07,0,0,0,1,1,0.7),c:hair})}
 if(hs===3){for(let k=0;k<5;k++){const a=-0.5+k*0.28;h.push({g:new THREE.ConeGeometry(0.035,0.12+(k===2?0.04:0),5),m:T4(0,1.16+Math.cos(a)*0.06,Math.sin(a)*0.1-0.01,a*0.6,0,0),c:hair})}}
 if(hs===4){h.push({g:new THREE.SphereGeometry(0.128,12,8,0,Math.PI*2,0,Math.PI*0.4),m:T4(0,1.1,-0.004,0,0,0,1,1.05,1),c:hair})}
 if(!z.zombie){
  if(c.beard>=1)h.push({g:new THREE.SphereGeometry(0.128,12,8,0,Math.PI*2,Math.PI*0.58,Math.PI*0.3),m:T4(0,1.07,0.012,0,0,0,1,1.1,1),c:hair});
  if(c.beard===2){h.push({g:sph(0.075,8,6),m:T4(0,1.0,0.06,0,0,0,1,1.2,0.9),c:hair})}
  if(c.hat===1){h.push({g:new THREE.SphereGeometry(0.142,12,8,0,Math.PI*2,0,Math.PI*0.52),m:T4(0,1.095,0,0,0,0,1,1,1),c:0x2b3a4a});h.push({g:box(0.2,0.012,0.13),m:T4(0,1.15,0.155,0.12,0,0),c:0x22303e})}
  if(c.hat===2){h.push({g:new THREE.SphereGeometry(0.14,12,8,0,Math.PI*2,0,Math.PI*0.62),m:T4(0,1.09,0,0,0,0,1,1.05,1),c:0x7a2b2b});h.push({g:cyl(0.14,0.14,0.035,12),m:T4(0,1.05,0),c:0x5a1f1f})}
  if(c.hat===3){h.push({g:cyl(0.23,0.23,0.012,16),m:T4(0,1.14,0),c:0x4a3a28});h.push({g:cyl(0.12,0.135,0.11,12),m:T4(0,1.2,0),c:0x4a3a28});h.push({g:cyl(0.136,0.136,0.025,12),m:T4(0,1.16,0),c:0x22180e})}
 }
 // bras / jambes (pivot en haut)
 const sleeve=z.zombie?jacket:jacket;
 const arm=[{g:cap(0.05*bw,0.24),m:T4(0,-0.15,0),c:sleeve},{g:sph(0.045,8,6),m:T4(0,-0.31,0),c:skin}];
 if(z.zombie)arm.push({g:cap(0.045*bw,0.1),m:T4(0,-0.28,0),c:skin});
 const leg=[{g:cap(0.075*bw,0.26),m:T4(0,-0.23,0),c:pants},{g:box(0.13*bw,0.09,0.21),m:T4(0,-0.46,0.035),c:dark}];
 return{torso:mergeGeo(b,{jit:0.08}),head:mergeGeo(h,{jit:0.05}),arm:mergeGeo(arm,{jit:0.06}),leg:mergeGeo(leg,{jit:0.06}),bw};
}
function mesh(g){const m=new THREE.Mesh(g,M.MAT.vc);m.castShadow=true;return m}
function assemble(G,o){
 o=o||{};const root=new THREE.Group(),body=new THREE.Group();root.add(body);
 const parts=[];
 const torso=mesh(G.torso),head=mesh(G.head);body.add(torso);body.add(head);parts.push(torso,head);
 const mk=(geo,x,y)=>{const g=new THREE.Group();g.position.set(x,y,0);const m=mesh(geo);g.add(m);parts.push(m);body.add(g);return g};
 const bw=G.bw;
 const legL=mk(G.leg,-0.085*bw,0.53),legR=mk(G.leg,0.085*bw,0.53);
 const armL=mk(G.arm,-(0.165*bw+0.045),0.9),armR=mk(G.arm,0.165*bw+0.045,0.9);
 // armes (main droite)
 const bat=new THREE.Group(),pistol=new THREE.Group();
 const wood=new THREE.MeshPhongMaterial({color:0x8a5a2a,shininess:8});
 const bm=new THREE.Mesh(new THREE.CylinderGeometry(0.03,0.018,0.58,8),wood);bm.rotation.x=Math.PI/2;bm.position.set(0,-0.31,0.26);bm.castShadow=true;bat.add(bm);
 for(let k=0;k<5;k++){const n=new THREE.Mesh(new THREE.ConeGeometry(0.01,0.04,4),new THREE.MeshPhongMaterial({color:0x999999}));n.position.set(0.03*Math.cos(k*1.3),-0.31+0.03*Math.sin(k*1.3),0.36+k*0.03);n.rotation.z=-Math.PI/2;bat.add(n)}
 const pm=new THREE.MeshPhongMaterial({color:0x22252a,shininess:50,specular:0x555555});
 const p1=new THREE.Mesh(new THREE.BoxGeometry(0.04,0.06,0.2),pm);p1.position.set(0,-0.3,0.1);const p2=new THREE.Mesh(new THREE.BoxGeometry(0.035,0.1,0.05),pm);p2.position.set(0,-0.36,0.03);p2.rotation.x=0.2;pistol.add(p1);pistol.add(p2);p1.castShadow=true;
 armR.add(bat);armR.add(pistol);bat.visible=pistol.visible=false;
 // ombre portée simple (secours)
 const blob=new THREE.Mesh(new THREE.CircleGeometry(0.3*bw,14).rotateX(-Math.PI/2),new THREE.MeshBasicMaterial({color:0,transparent:true,opacity:0.3,depthWrite:false}));blob.position.y=0.02;root.add(blob);
 return{root,body,legL,legR,armL,armR,bat,pistol,parts,blob};
}
function build(cfg){cfg=Object.assign({},DEFAULT,cfg||{});const o=assemble(geos(cfg),cfg);o.root.scale.setScalar(0.88);return o}

// ---------- zombies (géométries partagées par type/variante) ----------
const ZSKIN=[0x7fa07a,0x8aa68a,0x9aa070,0x6a8a78,0xa09a88];
const ZSHIRT=[0x4a4a3a,0x5a3a32,0x3a4a5a,0x6a6a5a,0x3a3a3a,0x6a2a2a];
const ZPANTS=[0x2a2a30,0x3a3a2e,0x2a3a4a,0x4a4034];
const kits={};
function zombie(type,variant,sc){
 const key=type+variant;
 if(!kits[key]){
  const rr=DZW.mulberry(900+variant*17+type.length);
  const z={zombie:true,skin:ZSKIN[(rr()*ZSKIN.length)|0],jacket:ZSHIRT[(rr()*ZSHIRT.length)|0],pants:ZPANTS[(rr()*ZPANTS.length)|0],bw:type==='brute'?1.25:type==='runner'?0.85:1};
  const c={hair:rr()<0.5?0:rr()<0.5?1:2,hairCol:rr()<.5?4:1,build:1,pack:0,hat:0,beard:0,jacket:0,pants:0,skin:0};
  kits[key]=geos(c,z);
 }
 const o=assemble(kits[key]);
 o.root.scale.setScalar(sc);
 o.armL.rotation.x=o.armR.rotation.x=-1.4;o.body.rotation.x=0.12;
 return o;
}
DZ.char={SKIN,HAIRC,JACKET,PANTS,OPT,DEFAULT,build,zombie};
})();
