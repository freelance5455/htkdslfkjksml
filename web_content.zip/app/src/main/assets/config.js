// V4 backend configuration.
// Create a Supabase project, then paste its Project URL and PUBLIC anon key here.
// Never put a service_role/private key in this file.
const GAMEHUB_CONFIG={supabaseUrl:"",supabaseAnonKey:""};
