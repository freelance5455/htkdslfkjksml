// Android standalone compatibility stub. The web app treats HUB as optional.
window.HUB = window.HUB || {
  getTheme: function(){ return localStorage.getItem('hub-theme') || 'amber'; },
  applyTheme: function(){},
  onThemeChange: function(){}
};
