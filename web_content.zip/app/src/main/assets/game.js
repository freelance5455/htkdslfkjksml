// Street Drift Legends - Master 3D Arcade Racing Engine
// Complete physics, drift scoring, nitro shockwave, AI opponents, career, garage, and UI logic

(function() {
  'use strict';

  // --- SAVE DATA & PERSISTENCE ---
  const DEFAULT_SAVE = {
    playerName: "Drift_King",
    level: 1,
    xp: 250,
    credits: 35000,
    tokens: 200,
    selectedCarId: "apex_sprint",
    ownedCars: ["apex_sprint"],
    carUpgrades: {
      "apex_sprint": { engine: 1, transmission: 1, tires: 1, brakes: 1, nitro: 1, drift: 1 }
    },
    carCustomization: {
      "apex_sprint": {
        bodyColor: "#00E5FF",
        accentColor: "#111111",
        neonColor: "#00E5FF",
        spoilerStyle: "sport",
        rimColor: "#E0E0E0",
        windowTint: "#1a1a2e"
      }
    },
    careerProgress: {
      currentSeries: 0,
      completedEvents: ["rookie_1"]
    },
    achievements: {
      first_win: false,
      drift_master: false,
      nitro_king: false,
      stunt_legend: false,
      races_count: 3,
      total_drift_score: 12500
    },
    settings: {
      controlMethod: "touch",
      steeringSens: 1.0,
      vibration: true,
      volMaster: 0.8,
      volMusic: 0.6,
      volSfx: 0.9,
      graphicsQuality: "high",
      cameraShake: true
    },
    dailyReward: {
      lastClaimDay: 0,
      streak: 1
    }
  };

  let playerData = Object.assign({}, DEFAULT_SAVE);

  function loadGameData() {
    try {
      const saved = localStorage.getItem("street_drift_legends_save");
      if (saved) {
        playerData = Object.assign(playerData, JSON.parse(saved));
      }
    } catch (e) {
      console.warn("Storage load error", e);
    }
  }

  function saveGameData() {
    try {
      localStorage.setItem("street_drift_legends_save", JSON.stringify(playerData));
      updateTopBarUI();
    } catch (e) {
      console.warn("Storage save error", e);
    }
  }

  // --- NATIVE HAPTICS BRIDGE ---
  function triggerHaptic(ms, strength = 180) {
    if (!playerData.settings.vibration) return;
    if (window.AndroidBridge && window.AndroidBridge.vibrateHaptic) {
      window.AndroidBridge.vibrateHaptic(ms, strength);
    } else if (navigator.vibrate) {
      navigator.vibrate(ms);
    }
  }

  // --- THREE.JS GLOBALS ---
  let scene, camera, renderer;
  let container = document.getElementById("canvas-container");
  let ambientLight, sunLight;
  let activeTrack = null;
  let playerCarMesh = null;
  let showcaseCarMesh = null;
  let aiCarMeshes = [];
  let trafficCars = [];

  // Particle systems
  let tireSmokeParticles = [];
  let nitroSparks = [];

  // Game States: 'MENU', 'GARAGE', 'COUNTDOWN', 'RACE', 'PAUSED', 'FINISH'
  let gameState = 'MENU';
  let currentGameMode = 'solo'; // 'solo', 'chase', 'drift', 'career', 'mp'
  let selectedTrackConfig = TRACK_CONFIGS[0];

  // Race Physics Variables
  const playerPhysics = {
    x: 0, y: 0, z: 0,
    speed: 0,             // km/h
    targetSpeed: 0,
    steerAngle: 0,        // -1 to 1
    heading: 0,           // radians
    driftAngle: 0,        // slip angle
    isDrifting: false,
    driftScore: 0,
    driftDuration: 0,
    driftCombo: 1,
    nitroAmount: 100,     // 0 to 100
    isNitro: false,
    nitroType: 'standard',// 'standard' or 'shockwave'
    isAirborne: false,
    verticalVelocity: 0,
    pitchAngle: 0,
    rollAngle: 0,
    spinAngle: 0,
    splineT: 0,           // 0 to 1 along track
    lap: 1,
    totalLaps: 2,
    lapProgress: 0,
    raceTime: 0,
    position: 1,
    gear: 1,
    rpm: 0
  };

  // AI Racers Data
  const AI_RACERS_COUNT = 5;
  const aiRacers = [];

  // Input states
  const keys = {
    forward: false,
    backward: false,
    left: false,
    right: false,
    drift: false,
    nitro: false
  };

  // Garage Orbit camera variables
  let garageOrbit = {
    rotX: 0.3,
    rotY: 0.8,
    distance: 7.5,
    isDragging: false,
    lastMouseX: 0,
    lastMouseY: 0
  };

  // --- INITIALIZATION ---
  function init() {
    loadGameData();

    // Setup Three.js Scene
    scene = new THREE.Scene();
    scene.background = new THREE.Color(0x050814);
    scene.fog = new THREE.FogExp2(0x080b18, 0.0035);

    camera = new THREE.PerspectiveCamera(62, window.innerWidth / window.innerHeight, 0.2, 1200);
    camera.position.set(0, 4, 12);

    renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: "high-performance" });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.1;
    container.appendChild(renderer.domElement);

    // Lights
    ambientLight = new THREE.AmbientLight(0x223355, 0.8);
    scene.add(ambientLight);

    sunLight = new THREE.DirectionalLight(0x4488ff, 1.2);
    sunLight.position.set(100, 200, 100);
    sunLight.castShadow = true;
    sunLight.shadow.mapSize.width = 1024;
    sunLight.shadow.mapSize.height = 1024;
    scene.add(sunLight);

    // Build Particles
    setupParticles();

    // Event Listeners
    setupInputListeners();
    setupUIEventListeners();

    // Apply Saved Settings to Audio
    window.AudioEngine.setVolumes(
      playerData.settings.volMaster,
      playerData.settings.volMusic,
      playerData.settings.volSfx
    );

    // Populate Menus
    updateTopBarUI();
    setupShowcaseScene();
    renderGarageCarList();
    renderTrackCards();
    renderAchievements();

    // Window Resize
    window.addEventListener("resize", onWindowResize);

    // Start 60fps Game Loop
    lastFrameTime = performance.now();
    requestAnimationFrame(gameLoop);
  }

  // --- THREE.JS PARTICLES ---
  function setupParticles() {
    // Tire Smoke
    const smokeGeo = new THREE.SphereGeometry(0.18, 5, 5);
    const smokeMat = new THREE.MeshBasicMaterial({ color: 0xdddddd, transparent: true, opacity: 0.6 });
    for (let i = 0; i < 40; i++) {
      const p = new THREE.Mesh(smokeGeo, smokeMat.clone());
      p.visible = false;
      scene.add(p);
      tireSmokeParticles.push({ mesh: p, life: 0, maxLife: 0.6, vx: 0, vy: 0, vz: 0 });
    }

    // Nitro Sparks / Speed Particles
    const sparkGeo = new THREE.BoxGeometry(0.08, 0.08, 0.5);
    const sparkMat = new THREE.MeshBasicMaterial({ color: 0x00e5ff });
    for (let i = 0; i < 30; i++) {
      const sp = new THREE.Mesh(sparkGeo, sparkMat);
      sp.visible = false;
      scene.add(sp);
      nitroSparks.push({ mesh: sp, life: 0, vx: 0, vy: 0, vz: 0 });
    }
  }

  function emitTireSmoke(pos) {
    const p = tireSmokeParticles.find(item => item.life <= 0);
    if (!p) return;
    p.mesh.position.copy(pos);
    p.mesh.visible = true;
    p.life = p.maxLife;
    p.vx = (Math.random() - 0.5) * 0.8;
    p.vy = 0.4 + Math.random() * 0.5;
    p.vz = (Math.random() - 0.5) * 0.8;
    p.mesh.scale.set(1, 1, 1);
  }

  function emitNitroSparks(pos, isShockwave) {
    const sp = nitroSparks.find(item => item.life <= 0);
    if (!sp) return;
    sp.mesh.position.copy(pos);
    sp.mesh.material.color.setHex(isShockwave ? 0xff007f : 0x00e5ff);
    sp.mesh.visible = true;
    sp.life = 0.35;
    sp.vx = (Math.random() - 0.5) * 1.5;
    sp.vy = (Math.random() - 0.5) * 0.5;
    sp.vz = -2.0 - Math.random() * 2.0;
  }

  // --- SHOWCASE CAR (MAIN MENU & GARAGE) ---
  function setupShowcaseScene() {
    clearSceneExceptLights();

    const carConfig = getCarConfig(playerData.selectedCarId);
    const custom = playerData.carCustomization[playerData.selectedCarId] || carConfig.defaultCustomization;

    showcaseCarMesh = CarModelBuilder.createCar(carConfig, custom, true);
    showcaseCarMesh.position.set(0, 0, 0);
    scene.add(showcaseCarMesh);

    // Floor platform for showroom
    const platGeo = new THREE.CylinderGeometry(5.2, 5.5, 0.3, 36);
    const platMat = new THREE.MeshStandardMaterial({
      color: 0x0f1420,
      metalness: 0.9,
      roughness: 0.2
    });
    const plat = new THREE.Mesh(platGeo, platMat);
    plat.position.y = -0.15;
    scene.add(plat);

    // Ambient showroom glow
    const neonRingGeo = new THREE.RingGeometry(4.8, 5.0, 36);
    neonRingGeo.rotateX(-Math.PI / 2);
    const neonRingMat = new THREE.MeshBasicMaterial({ color: 0x00e5ff, side: THREE.DoubleSide });
    const neonRing = new THREE.Mesh(neonRingGeo, neonRingMat);
    neonRing.position.y = 0.02;
    scene.add(neonRing);

    camera.position.set(0, 2.2, 6.5);
    camera.lookAt(0, 0.8, 0);
  }

  function clearSceneExceptLights() {
    for (let i = scene.children.length - 1; i >= 0; i--) {
      const child = scene.children[i];
      if (child !== ambientLight && child !== sunLight && !tireSmokeParticles.some(p => p.mesh === child) && !nitroSparks.some(p => p.mesh === child)) {
        scene.remove(child);
      }
    }
  }

  function getCarConfig(carId) {
    return CAR_CATALOG.find(c => c.id === carId) || CAR_CATALOG[0];
  }

  // --- RACE SETUP ---
  function startRace(trackConfig, mode = 'solo') {
    gameState = 'COUNTDOWN';
    currentGameMode = mode;
    selectedTrackConfig = trackConfig;

    // Switch Screens
    switchScreen('screen-hud');
    window.AudioEngine.stopMusic();
    window.AudioEngine.startMusic();
    window.AudioEngine.startEngine();

    clearSceneExceptLights();

    // Sky & Fog based on track theme
    scene.background = new THREE.Color(trackConfig.skyColor);
    scene.fog.color = new THREE.Color(trackConfig.fogColor);
    ambientLight.color = new THREE.Color(trackConfig.ambientLight);
    sunLight.color = new THREE.Color(trackConfig.sunLight);

    // Build 3D Track
    activeTrack = TrackBuilder.buildTrack(trackConfig, scene);

    // Reset Player Physics
    const startPoint = activeTrack.curve.getPointAt(0);
    const startTangent = activeTrack.curve.getTangentAt(0);

    playerPhysics.x = startPoint.x;
    playerPhysics.y = startPoint.y + 0.1;
    playerPhysics.z = startPoint.z;
    playerPhysics.speed = 0;
    playerPhysics.steerAngle = 0;
    playerPhysics.heading = Math.atan2(startTangent.x, startTangent.z);
    playerPhysics.driftScore = 0;
    playerPhysics.driftCombo = 1;
    playerPhysics.nitroAmount = 100;
    playerPhysics.isNitro = false;
    playerPhysics.lap = 1;
    playerPhysics.totalLaps = trackConfig.defaultLaps || 2;
    playerPhysics.raceTime = 0;
    playerPhysics.splineT = 0;
    playerPhysics.position = 1;

    // Build Player Car
    const carConfig = getCarConfig(playerData.selectedCarId);
    const custom = playerData.carCustomization[playerData.selectedCarId] || carConfig.defaultCustomization;
    playerCarMesh = CarModelBuilder.createCar(carConfig, custom, true);
    playerCarMesh.position.set(playerPhysics.x, playerPhysics.y, playerPhysics.z);
    playerCarMesh.rotation.y = playerPhysics.heading;
    scene.add(playerCarMesh);

    // Spawn AI Competitors on Grid
    aiCarMeshes = [];
    aiRacers.length = 0;

    const aiNames = ["Viper GT", "Ghost_R", "Katsuo 86", "Torque V8", "Shadow Apex", "Neon Pulse"];
    const otherCars = CAR_CATALOG.filter(c => c.id !== carConfig.id);

    for (let i = 0; i < AI_RACERS_COUNT; i++) {
      const aiConf = otherCars[i % otherCars.length];
      const aiMesh = CarModelBuilder.createCar(aiConf, aiConf.defaultCustomization, false);
      
      const gridOffset = (i + 1) * 0.012;
      const sideOffset = (i % 2 === 0 ? 1 : -1) * 4.0;
      const aiP = activeTrack.curve.getPointAt(gridOffset);
      const aiT = activeTrack.curve.getTangentAt(gridOffset);
      const aiNorm = new THREE.Vector3(-aiT.z, 0, aiT.x).normalize();

      aiMesh.position.copy(aiP).addScaledVector(aiNorm, sideOffset);
      aiMesh.position.y += 0.1;
      aiMesh.rotation.y = Math.atan2(aiT.x, aiT.z);

      scene.add(aiMesh);
      aiCarMeshes.push(aiMesh);

      aiRacers.push({
        name: aiNames[i % aiNames.length],
        mesh: aiMesh,
        splineT: gridOffset,
        speed: 0,
        targetSpeed: 180 + Math.random() * 40,
        laneOffset: sideOffset,
        heading: Math.atan2(aiT.x, aiT.z),
        lap: 1
      });
    }

    // Spawn Civilian Traffic if enabled
    trafficCars = [];
    for (let i = 0; i < 4; i++) {
      const trafU = (0.2 + i * 0.22) % 1.0;
      const trafP = activeTrack.curve.getPointAt(trafU);
      const trafT = activeTrack.curve.getTangentAt(trafU);
      const trafNorm = new THREE.Vector3(-trafT.z, 0, trafT.x).normalize();
      
      const trafCarConf = CAR_CATALOG[2]; // Muscle
      const trafMesh = CarModelBuilder.createCar(trafCarConf, { bodyColor: "#555555" }, false);
      trafMesh.scale.set(0.9, 0.9, 0.9);
      trafMesh.position.copy(trafP).addScaledVector(trafNorm, (i % 2 === 0 ? 3.5 : -3.5));
      trafMesh.rotation.y = Math.atan2(trafT.x, trafT.z);
      scene.add(trafMesh);

      trafficCars.push({
        mesh: trafMesh,
        splineT: trafU,
        speed: 70,
        laneOffset: (i % 2 === 0 ? 3.5 : -3.5)
      });
    }

    // Run Starting Countdown 3, 2, 1, GO!
    runCountdownSequence();
  }

  function runCountdownSequence() {
    const cdEl = document.getElementById("countdown-overlay");
    cdEl.style.display = "block";
    let count = 3;

    function tick() {
      if (count > 0) {
        cdEl.textContent = count;
        window.AudioEngine.playCountdown(count);
        triggerHaptic(60);
        count--;
        setTimeout(tick, 900);
      } else if (count === 0) {
        cdEl.textContent = "GO!";
        cdEl.style.color = "#00e5ff";
        window.AudioEngine.playCountdown(0);
        triggerHaptic(180, 255);
        gameState = 'RACE';
        setTimeout(() => {
          cdEl.style.display = "none";
          cdEl.style.color = "#fff";
        }, 800);
      }
    }
    tick();
  }

  // --- GAME LOOP & PHYSICS ---
  let lastFrameTime = performance.now();

  function gameLoop(currentTime) {
    const dt = Math.min((currentTime - lastFrameTime) / 1000, 0.1);
    lastFrameTime = currentTime;

    if (gameState === 'MENU') {
      if (showcaseCarMesh) {
        showcaseCarMesh.rotation.y += dt * 0.4;
      }
    } else if (gameState === 'GARAGE') {
      // Rotate car slowly unless dragging
      if (showcaseCarMesh && !garageOrbit.isDragging) {
        showcaseCarMesh.rotation.y += dt * 0.25;
      }
    } else if (gameState === 'COUNTDOWN' || gameState === 'RACE') {
      updateRacePhysics(dt);
      updateAIRacers(dt);
      updateTraffic(dt);
      updateCameraFollow(dt);
      updateParticles(dt);
      updateInRaceHUD();
      drawMinimap();
    }

    renderer.render(scene, camera);
    requestAnimationFrame(gameLoop);
  }

  // --- RACING PHYSICS SIMULATION ---
  function updateRacePhysics(dt) {
    if (!activeTrack) return;

    const carConfig = getCarConfig(playerData.selectedCarId);
    const upgrades = playerData.carUpgrades[carConfig.id] || { engine: 1, transmission: 1, tires: 1, brakes: 1, nitro: 1, drift: 1 };

    // Calculate effective performance stats based on base + upgrades
    const maxSpeed = (carConfig.baseStats.topSpeed + (upgrades.engine - 1) * 12) * (playerPhysics.isNitro ? (playerPhysics.nitroType === 'shockwave' ? 1.45 : 1.25) : 1.0);
    const accelPower = (carConfig.baseStats.acceleration + (upgrades.transmission - 1) * 8) * 1.8;
    const handlingPower = (carConfig.baseStats.handling + (upgrades.tires - 1) * 6) * 0.038 * playerData.settings.steeringSens;
    const brakePower = (carConfig.baseStats.brakes + (upgrades.brakes - 1) * 10) * 4.5;
    const driftGrip = (carConfig.baseStats.driftControl + (upgrades.drift - 1) * 8) * 0.01;

    // Controls input handling
    let throttle = 0;
    if (gameState === 'RACE') {
      if (keys.forward) throttle = 1;
      if (keys.backward) throttle = -0.6;
    }

    // Acceleration & Braking
    if (throttle > 0) {
      playerPhysics.speed += accelPower * dt;
      if (playerPhysics.speed > maxSpeed) {
        playerPhysics.speed = Math.max(maxSpeed, playerPhysics.speed - dt * 15);
      }
    } else if (throttle < 0) {
      playerPhysics.speed -= brakePower * dt;
      if (playerPhysics.speed < -35) playerPhysics.speed = -35;
    } else {
      // Natural rolling friction
      playerPhysics.speed = Math.max(0, playerPhysics.speed - dt * 25);
    }

    // Steering & Drifting
    let steerDir = 0;
    if (keys.left) steerDir -= 1;
    if (keys.right) steerDir += 1;

    // TouchDrive simplified lane steering assist
    if (playerData.settings.controlMethod === 'touchdrive') {
      steerDir *= 0.75;
    }

    playerPhysics.steerAngle += (steerDir - playerPhysics.steerAngle) * dt * 8;

    // Handbrake / Drift Condition
    const wantsDrift = keys.drift && Math.abs(playerPhysics.speed) > 45;
    if (wantsDrift && Math.abs(playerPhysics.steerAngle) > 0.15) {
      playerPhysics.isDrifting = true;
      playerPhysics.driftDuration += dt;
      playerPhysics.driftAngle += (playerPhysics.steerAngle * 0.8 - playerPhysics.driftAngle) * dt * 4;

      // Drift Score Calculation
      const driftPoints = Math.floor(dt * Math.abs(playerPhysics.driftAngle) * playerPhysics.speed * driftGrip * 3.5);
      playerPhysics.driftScore += driftPoints;

      // Nitro refill via drifting
      playerPhysics.nitroAmount = Math.min(100, playerPhysics.nitroAmount + dt * 14);

      // Sound & Haptic
      window.AudioEngine.setDriftIntensity(Math.abs(playerPhysics.driftAngle));
      if (Math.random() > 0.6) triggerHaptic(20, 80);

      // Show Drift HUD notification
      showDriftBadge(playerPhysics.driftScore, playerPhysics.driftCombo);

      // Smoke emissions from rear tires
      if (playerCarMesh && playerCarMesh.wheels) {
        const rearL = new THREE.Vector3();
        playerCarMesh.wheels.meshRL.getWorldPosition(rearL);
        emitTireSmoke(rearL);

        const rearR = new THREE.Vector3();
        playerCarMesh.wheels.meshRR.getWorldPosition(rearR);
        emitTireSmoke(rearR);
      }
    } else {
      playerPhysics.isDrifting = false;
      playerPhysics.driftAngle += (0 - playerPhysics.driftAngle) * dt * 6;
      window.AudioEngine.setDriftIntensity(0);
      hideDriftBadge();
    }

    // Nitro Boost Activation
    if (keys.nitro && playerPhysics.nitroAmount > 5) {
      if (!playerPhysics.isNitro) {
        // Check for Perfect Nitro sweet spot timing
        const isShockwave = playerPhysics.nitroAmount > 80;
        playerPhysics.isNitro = true;
        playerPhysics.nitroType = isShockwave ? 'shockwave' : 'standard';
        window.AudioEngine.playNitro(isShockwave);
        triggerHaptic(isShockwave ? 150 : 80, 220);
      }
      playerPhysics.nitroAmount = Math.max(0, playerPhysics.nitroAmount - dt * 28);

      // Emit Nitro Exhaust Flames
      if (playerCarMesh && playerCarMesh.exhausts) {
        playerCarMesh.exhausts.forEach(ex => {
          const exPos = new THREE.Vector3();
          ex.getWorldPosition(exPos);
          emitNitroSparks(exPos, playerPhysics.nitroType === 'shockwave');
        });
      }
    } else {
      playerPhysics.isNitro = false;
    }

    // Heading and Spline progression
    const turnRate = handlingPower * (playerPhysics.isDrifting ? 1.5 : 1.0);
    playerPhysics.heading -= playerPhysics.steerAngle * turnRate * (playerPhysics.speed / 100);

    // Update car position based on velocity vector
    const speedMs = (playerPhysics.speed / 3.6);
    const moveDist = speedMs * dt;

    playerPhysics.x += Math.sin(playerPhysics.heading + playerPhysics.driftAngle * 0.4) * moveDist;
    playerPhysics.z += Math.cos(playerPhysics.heading + playerPhysics.driftAngle * 0.4) * moveDist;

    // Track Progress & Nearest Spline point
    const trackLen = activeTrack.lengthMeters;
    const progressInc = moveDist / trackLen;
    playerPhysics.splineT = (playerPhysics.splineT + progressInc) % 1.0;

    // Lap Completion Check
    if (playerPhysics.splineT < 0.05 && playerPhysics.lapProgress > 0.85) {
      playerPhysics.lap++;
      playerPhysics.lapProgress = 0;
      window.AudioEngine.playReward();
      triggerHaptic(120);

      if (playerPhysics.lap > playerPhysics.totalLaps) {
        onRaceFinished();
        return;
      }
    } else {
      playerPhysics.lapProgress = Math.max(playerPhysics.lapProgress, playerPhysics.splineT);
    }

    // Stunt Ramp Detection & Air Physics
    const carPosVec = new THREE.Vector3(playerPhysics.x, 0, playerPhysics.z);
    for (let ramp of activeTrack.ramps) {
      if (carPosVec.distanceTo(ramp.position) < 6.0 && playerPhysics.speed > 80 && !playerPhysics.isAirborne) {
        playerPhysics.isAirborne = true;
        playerPhysics.verticalVelocity = 8.5 + (playerPhysics.speed / 50);
        window.AudioEngine.playStunt();
        triggerHaptic(100);
        showStuntAlert("LAUNCH RAMP JUMP! +300 PTS");
        playerPhysics.driftScore += 300;
        playerPhysics.nitroAmount = Math.min(100, playerPhysics.nitroAmount + 30);
      }
    }

    if (playerPhysics.isAirborne) {
      playerPhysics.y += playerPhysics.verticalVelocity * dt;
      playerPhysics.verticalVelocity -= 22 * dt; // Gravity
      
      // Perform Air Spin if handbrake pressed in air
      if (keys.drift) {
        playerPhysics.spinAngle += dt * 10;
        if (playerPhysics.spinAngle > Math.PI * 2) {
          showStuntAlert("360 AIR SPIN! +500 PTS");
          playerPhysics.driftScore += 500;
          playerPhysics.spinAngle = 0;
        }
      }

      if (playerPhysics.y <= 0.1) {
        playerPhysics.y = 0.1;
        playerPhysics.isAirborne = false;
        playerPhysics.verticalVelocity = 0;
        playerPhysics.spinAngle = 0;
        window.AudioEngine.playCrash(0.6);
        triggerHaptic(80);
      }
    }

    // Update Car 3D Mesh
    if (playerCarMesh) {
      playerCarMesh.position.set(playerPhysics.x, playerPhysics.y, playerPhysics.z);
      playerCarMesh.rotation.y = playerPhysics.heading + playerPhysics.driftAngle * 0.4 + playerPhysics.spinAngle;
      playerCarMesh.rotation.z = -playerPhysics.driftAngle * 0.15; // Chassis roll into corner

      // Front wheel steering
      if (playerCarMesh.wheels) {
        playerCarMesh.wheels.steerFL.rotation.y = playerPhysics.steerAngle * 0.6;
        playerCarMesh.wheels.steerFR.rotation.y = playerPhysics.steerAngle * 0.6;
      }
    }

    // Engine Audio updates
    playerPhysics.rpm = Math.min(1.0, (playerPhysics.speed % 60) / 60);
    playerPhysics.gear = Math.max(1, Math.min(6, Math.floor(playerPhysics.speed / 50) + 1));
    window.AudioEngine.updateEngine(playerPhysics.rpm, throttle > 0, playerPhysics.isDrifting, playerPhysics.isNitro);
  }

  // --- AI RACERS UPDATE ---
  function updateAIRacers(dt) {
    if (!activeTrack) return;

    aiRacers.forEach((ai, idx) => {
      // Follow track spline curve
      const speedMs = ai.speed / 3.6;
      ai.splineT = (ai.splineT + (speedMs * dt) / activeTrack.lengthMeters) % 1.0;

      // Smooth acceleration
      ai.speed += (ai.targetSpeed - ai.speed) * dt * 0.8;

      const p = activeTrack.curve.getPointAt(ai.splineT);
      const t = activeTrack.curve.getTangentAt(ai.splineT);
      const norm = new THREE.Vector3(-t.z, 0, t.x).normalize();

      ai.mesh.position.copy(p).addScaledVector(norm, ai.laneOffset);
      ai.mesh.position.y += 0.1;
      ai.mesh.rotation.y = Math.atan2(t.x, t.z);

      // Check collision with Player
      const distToPlayer = ai.mesh.position.distanceTo(playerCarMesh.position);
      if (distToPlayer < 2.8) {
        // Arcade bump recoil
        playerPhysics.speed *= 0.88;
        window.AudioEngine.playCrash(1.0);
        triggerHaptic(120);
      }
    });

    // Compute Race Position (1 to 8)
    let rank = 1;
    aiRacers.forEach(ai => {
      const aiDist = ai.lap + ai.splineT;
      const playerDist = playerPhysics.lap + playerPhysics.splineT;
      if (aiDist > playerDist) rank++;
    });
    playerPhysics.position = rank;
  }

  // --- TRAFFIC UPDATE ---
  function updateTraffic(dt) {
    if (!activeTrack) return;
    trafficCars.forEach(traf => {
      const speedMs = traf.speed / 3.6;
      traf.splineT = (traf.splineT + (speedMs * dt) / activeTrack.lengthMeters) % 1.0;

      const p = activeTrack.curve.getPointAt(traf.splineT);
      const t = activeTrack.curve.getTangentAt(traf.splineT);
      const norm = new THREE.Vector3(-t.z, 0, t.x).normalize();

      traf.mesh.position.copy(p).addScaledVector(norm, traf.laneOffset);
      traf.mesh.position.y = 0.2;
      traf.mesh.rotation.y = Math.atan2(t.x, t.z);

      // Near-miss bonus or Crash
      const dist = traf.mesh.position.distanceTo(playerCarMesh.position);
      if (dist < 2.4) {
        // Crash
        playerPhysics.speed = Math.max(0, playerPhysics.speed - 60);
        window.AudioEngine.playCrash(1.5);
        triggerHaptic(200, 255);
      } else if (dist < 4.5 && playerPhysics.speed > 100) {
        showStuntAlert("NEAR MISS! +150 PTS");
        playerPhysics.nitroAmount = Math.min(100, playerPhysics.nitroAmount + 20);
      }
    });
  }

  // --- CAMERA FOLLOW PHYSICS ---
  function updateCameraFollow(dt) {
    if (!playerCarMesh) return;

    const carPos = playerCarMesh.position;
    const carHeading = playerPhysics.heading + playerPhysics.driftAngle * 0.3;

    // Follow distance & height
    const baseDist = 6.2 + (playerPhysics.isNitro ? 1.5 : 0);
    const baseHeight = 2.4;

    const targetCamX = carPos.x - Math.sin(carHeading) * baseDist;
    const targetCamZ = carPos.z - Math.cos(carHeading) * baseDist;
    const targetCamY = carPos.y + baseHeight;

    // Smooth spring interpolation
    camera.position.x += (targetCamX - camera.position.x) * dt * 8;
    camera.position.z += (targetCamZ - camera.position.z) * dt * 8;
    camera.position.y += (targetCamY - camera.position.y) * dt * 8;

    // Speed-based dynamic FOV
    const targetFov = 62 + (playerPhysics.speed / 300) * 22 + (playerPhysics.isNitro ? 8 : 0);
    camera.fov += (targetFov - camera.fov) * dt * 5;
    camera.updateProjectionMatrix();

    // Look slightly ahead of car
    const lookTarget = new THREE.Vector3(
      carPos.x + Math.sin(carHeading) * 4.0,
      carPos.y + 1.2,
      carPos.z + Math.cos(carHeading) * 4.0
    );
    camera.lookAt(lookTarget);
  }

  function updateParticles(dt) {
    tireSmokeParticles.forEach(p => {
      if (p.life > 0) {
        p.life -= dt;
        p.mesh.position.x += p.vx * dt;
        p.mesh.position.y += p.vy * dt;
        p.mesh.position.z += p.vz * dt;
        const scale = (1 - p.life / p.maxLife) * 2.5 + 1;
        p.mesh.scale.set(scale, scale, scale);
        p.mesh.material.opacity = (p.life / p.maxLife) * 0.5;
        if (p.life <= 0) p.mesh.visible = false;
      }
    });

    nitroSparks.forEach(sp => {
      if (sp.life > 0) {
        sp.life -= dt;
        sp.mesh.position.x += sp.vx * dt;
        sp.mesh.position.y += sp.vy * dt;
        sp.mesh.position.z += sp.vz * dt;
        if (sp.life <= 0) sp.mesh.visible = false;
      }
    });
  }

  // --- HUD & MINIMAP ---
  function updateInRaceHUD() {
    document.getElementById("hud-speed").textContent = Math.round(playerPhysics.speed);
    document.getElementById("hud-gear").textContent = "GEAR " + playerPhysics.gear;
    document.getElementById("hud-pos").textContent = playerPhysics.position;
    document.getElementById("hud-lap").textContent = `LAP ${playerPhysics.lap}/${playerPhysics.totalLaps}`;

    // Timer format mm:ss.ms
    playerPhysics.raceTime += (1 / 60);
    const m = Math.floor(playerPhysics.raceTime / 60);
    const s = Math.floor(playerPhysics.raceTime % 60);
    const ms = Math.floor((playerPhysics.raceTime * 100) % 100);
    document.getElementById("hud-timer").textContent =
      `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}.${ms.toString().padStart(2, '0')}`;

    // Nitro gauge
    const nitroFill = document.getElementById("hud-nitro-fill");
    nitroFill.style.width = playerPhysics.nitroAmount + "%";
    if (playerPhysics.isNitro && playerPhysics.nitroType === 'shockwave') {
      nitroFill.classList.add("shockwave");
    } else {
      nitroFill.classList.remove("shockwave");
    }
  }

  function drawMinimap() {
    const canvas = document.getElementById("minimap-canvas");
    if (!canvas || !activeTrack) return;
    const ctx = canvas.getContext("2d");
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    const cx = canvas.width * 0.5;
    const cy = canvas.height * 0.5;
    const mapScale = 0.12;

    // Draw track spline loop
    ctx.strokeStyle = "rgba(0, 229, 255, 0.4)";
    ctx.lineWidth = 3;
    ctx.beginPath();
    for (let i = 0; i <= 60; i++) {
      const p = activeTrack.curve.getPointAt(i / 60);
      const mx = cx + (p.x - playerPhysics.x) * mapScale;
      const my = cy + (p.z - playerPhysics.z) * mapScale;
      if (i === 0) ctx.moveTo(mx, my);
      else ctx.lineTo(mx, my);
    }
    ctx.stroke();

    // Draw AI Racers (red/orange dots)
    aiRacers.forEach(ai => {
      const ax = cx + (ai.mesh.position.x - playerPhysics.x) * mapScale;
      const ay = cy + (ai.mesh.position.z - playerPhysics.z) * mapScale;
      ctx.fillStyle = "#ff1744";
      ctx.beginPath();
      ctx.arc(ax, ay, 3.5, 0, Math.PI * 2);
      ctx.fill();
    });

    // Draw Player marker (cyan triangle pointing in heading)
    ctx.fillStyle = "#00e5ff";
    ctx.beginPath();
    ctx.arc(cx, cy, 5, 0, Math.PI * 2);
    ctx.fill();
  }

  function showDriftBadge(score, combo) {
    const b = document.getElementById("drift-score-badge");
    const cb = document.getElementById("drift-combo-badge");
    b.textContent = `DRIFT +${score}`;
    b.classList.add("visible");
    if (combo > 1) {
      cb.textContent = `COMBO x${combo}`;
      cb.style.display = "inline-block";
    }
  }

  function hideDriftBadge() {
    const b = document.getElementById("drift-score-badge");
    const cb = document.getElementById("drift-combo-badge");
    b.classList.remove("visible");
    cb.style.display = "none";
  }

  let stuntTimeout = null;
  function showStuntAlert(msg) {
    const b = document.getElementById("stunt-alert-badge");
    b.textContent = msg;
    b.style.display = "block";
    if (stuntTimeout) clearTimeout(stuntTimeout);
    stuntTimeout = setTimeout(() => {
      b.style.display = "none";
    }, 1200);
  }

  // --- RACE FINISHED SEQUENCE ---
  function onRaceFinished() {
    gameState = 'FINISH';
    window.AudioEngine.stopEngine();
    window.AudioEngine.playReward();

    const isWinner = playerPhysics.position === 1;
    const earnedCredits = isWinner ? 5000 : 2500;
    const earnedXP = isWinner ? 750 : 350;

    playerData.credits += earnedCredits;
    playerData.xp += earnedXP;
    playerData.achievements.races_count++;
    playerData.achievements.total_drift_score += playerPhysics.driftScore;

    if (isWinner) playerData.achievements.first_win = true;
    if (playerPhysics.driftScore > 3000) playerData.achievements.drift_master = true;

    // Check level up
    const nextLevelXp = playerData.level * 1000;
    if (playerData.xp >= nextLevelXp) {
      playerData.level++;
      playerData.xp -= nextLevelXp;
    }

    saveGameData();

    // Populate Finish Screen
    document.getElementById("finish-title").textContent = isWinner ? "VICTORY!" : "RACE COMPLETE";
    document.getElementById("finish-position").textContent = `${playerPhysics.position}${getOrdinal(playerPhysics.position)} PLACE`;
    document.getElementById("finish-time").textContent = document.getElementById("hud-timer").textContent;
    document.getElementById("finish-drift").textContent = `${playerPhysics.driftScore} PTS`;
    document.getElementById("finish-xp").textContent = `+${earnedXP} XP`;
    document.getElementById("finish-credits").textContent = `+${earnedCredits.toLocaleString()} 🪙`;

    openModal("screen-finish");
  }

  function getOrdinal(n) {
    const s = ["TH", "ST", "ND", "RD"];
    const v = n % 100;
    return s[(v - 20) % 10] || s[v] || s[0];
  }

  // --- SCREENS & MODALS TRANSITIONS ---
  function switchScreen(screenId) {
    document.querySelectorAll(".screen").forEach(s => s.classList.remove("active"));
    const target = document.getElementById(screenId);
    if (target) target.classList.add("active");

    const topBar = document.getElementById("top-status-bar");
    if (screenId === 'screen-hud') {
      topBar.style.display = "none";
    } else {
      topBar.style.display = "flex";
    }
  }

  function openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) modal.classList.add("active");
  }

  function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) modal.classList.remove("active");
  }

  function updateTopBarUI() {
    document.getElementById("hud-player-name").textContent = playerData.playerName;
    document.getElementById("hud-player-level").textContent = playerData.level;
    document.getElementById("hud-credits").textContent = playerData.credits.toLocaleString();
    document.getElementById("hud-tokens").textContent = playerData.tokens.toLocaleString();

    const xpRatio = (playerData.xp % 1000) / 1000;
    document.getElementById("hud-xp-fill").style.width = (xpRatio * 100) + "%";

    const car = getCarConfig(playerData.selectedCarId);
    document.getElementById("menu-car-name").textContent = car.name;
  }

  // --- GARAGE LOGIC ---
  function renderGarageCarList() {
    const listEl = document.getElementById("garage-car-list");
    listEl.innerHTML = "";

    CAR_CATALOG.forEach(car => {
      const isOwned = playerData.ownedCars.includes(car.id);
      const isSelected = car.id === playerData.selectedCarId;

      const card = document.createElement("div");
      card.className = `car-item-card ${isSelected ? 'selected' : ''}`;
      card.innerHTML = `
        <div class="car-info">
          <h4>${car.name}</h4>
          <span class="badge" style="color:var(--neon-cyan);">${car.carClass}</span>
        </div>
        <div>
          ${isOwned ? '<span style="color:var(--neon-green); font-size:0.8rem; font-weight:bold;">OWNED</span>' : `<span style="color:#ffca28; font-size:0.8rem; font-weight:bold;">🪙 ${car.price.toLocaleString()}</span>`}
        </div>
      `;

      card.addEventListener("click", () => {
        selectGarageCar(car.id);
      });

      listEl.appendChild(card);
    });

    updateGarageDetails(playerData.selectedCarId);
  }

  function selectGarageCar(carId) {
    const car = getCarConfig(carId);
    const isOwned = playerData.ownedCars.includes(carId);

    // Update 3D model in showcase
    if (showcaseCarMesh) scene.remove(showcaseCarMesh);
    const custom = playerData.carCustomization[carId] || car.defaultCustomization;
    showcaseCarMesh = CarModelBuilder.createCar(car, custom, true);
    scene.add(showcaseCarMesh);

    // Update Action Button
    const actBtn = document.getElementById("btn-garage-action");
    if (isOwned) {
      playerData.selectedCarId = carId;
      saveGameData();
      actBtn.textContent = "SELECTED";
      actBtn.disabled = true;
    } else {
      actBtn.textContent = `BUY CAR (${car.price.toLocaleString()} 🪙)`;
      actBtn.disabled = playerData.credits < car.price;
      actBtn.onclick = () => {
        if (playerData.credits >= car.price) {
          playerData.credits -= car.price;
          playerData.ownedCars.push(carId);
          playerData.selectedCarId = carId;
          saveGameData();
          window.AudioEngine.playReward();
          renderGarageCarList();
        }
      };
    }

    renderGarageCarListHighlight(carId);
    updateGarageDetails(carId);
  }

  function renderGarageCarListHighlight(selectedId) {
    document.querySelectorAll(".car-item-card").forEach((card, idx) => {
      const car = CAR_CATALOG[idx];
      if (car.id === selectedId) {
        card.classList.add("selected");
      } else {
        card.classList.remove("selected");
      }
    });
  }

  function updateGarageDetails(carId) {
    const car = getCarConfig(carId);
    const upgrades = playerData.carUpgrades[carId] || { engine: 1, transmission: 1, tires: 1, brakes: 1, nitro: 1, drift: 1 };

    // Stats
    const topSpd = car.baseStats.topSpeed + (upgrades.engine - 1) * 12;
    document.getElementById("stat-speed-val").textContent = `${topSpd} km/h`;
    document.getElementById("stat-speed-fill").style.width = Math.min(100, (topSpd / 350) * 100) + "%";

    const accel = car.baseStats.acceleration + (upgrades.transmission - 1) * 6;
    document.getElementById("stat-accel-val").textContent = accel;
    document.getElementById("stat-accel-fill").style.width = accel + "%";

    const handling = car.baseStats.handling + (upgrades.tires - 1) * 5;
    document.getElementById("stat-handling-val").textContent = handling;
    document.getElementById("stat-handling-fill").style.width = handling + "%";

    const nitro = car.baseStats.nitro + (upgrades.nitro - 1) * 7;
    document.getElementById("stat-nitro-val").textContent = nitro;
    document.getElementById("stat-nitro-fill").style.width = nitro + "%";

    const drift = car.baseStats.driftControl + (upgrades.drift - 1) * 6;
    document.getElementById("stat-drift-val").textContent = drift;
    document.getElementById("stat-drift-fill").style.width = drift + "%";

    // Upgrades tab
    const upList = document.getElementById("upgrades-list");
    upList.innerHTML = "";
    const upgradeCategories = [
      { key: 'engine', name: 'Engine Stage' },
      { key: 'transmission', name: 'Transmission' },
      { key: 'tires', name: 'Drift Tires' },
      { key: 'brakes', name: 'Carbon Brakes' },
      { key: 'nitro', name: 'Nitro Manifold' },
      { key: 'drift', name: 'Drift Suspension' }
    ];

    upgradeCategories.forEach(cat => {
      const lvl = upgrades[cat.key] || 1;
      const cost = lvl * 4000;
      const row = document.createElement("div");
      row.className = "setting-row";
      row.innerHTML = `
        <div>
          <span style="font-weight:bold;">${cat.name}</span>
          <span style="color:var(--neon-cyan); font-size:0.8rem; margin-left:6px;">LVL ${lvl}/5</span>
        </div>
        <div>
          ${lvl < 5 ? `<button class="btn btn-sm btn-primary" style="padding:4px 10px;">UPGRADE (🪙 ${cost})</button>` : `<span style="color:var(--neon-green); font-size:0.8rem; font-weight:bold;">MAX</span>`}
        </div>
      `;

      if (lvl < 5) {
        const btn = row.querySelector("button");
        btn.onclick = () => {
          if (playerData.credits >= cost) {
            playerData.credits -= cost;
            if (!playerData.carUpgrades[carId]) {
              playerData.carUpgrades[carId] = { engine: 1, transmission: 1, tires: 1, brakes: 1, nitro: 1, drift: 1 };
            }
            playerData.carUpgrades[carId][cat.key]++;
            saveGameData();
            window.AudioEngine.playReward();
            updateGarageDetails(carId);
          } else {
            alert("Not enough Credits! Race to earn more.");
          }
        };
      }

      upList.appendChild(row);
    });

    // Customization Swatches
    renderSwatches();
  }

  function renderSwatches() {
    const carId = playerData.selectedCarId;
    if (!playerData.carCustomization[carId]) {
      playerData.carCustomization[carId] = Object.assign({}, getCarConfig(carId).defaultCustomization);
    }
    const custom = playerData.carCustomization[carId];

    const colors = ["#00E5FF", "#FF1744", "#FF9100", "#00E676", "#D500F9", "#FFD700", "#FFFFFF", "#111111"];
    
    // Body swatches
    const bCont = document.getElementById("swatches-body");
    bCont.innerHTML = "";
    colors.forEach(col => {
      const btn = document.createElement("button");
      btn.className = `swatch-btn ${custom.bodyColor === col ? 'active' : ''}`;
      btn.style.backgroundColor = col;
      btn.onclick = () => {
        custom.bodyColor = col;
        saveGameData();
        selectGarageCar(carId);
      };
      bCont.appendChild(btn);
    });

    // Neon swatches
    const nCont = document.getElementById("swatches-neon");
    nCont.innerHTML = "";
    colors.concat(["#000000"]).forEach(col => {
      const btn = document.createElement("button");
      btn.className = `swatch-btn ${custom.neonColor === col ? 'active' : ''}`;
      btn.style.backgroundColor = col === "#000000" ? "#333" : col;
      btn.title = col === "#000000" ? "Off" : "Neon";
      btn.onclick = () => {
        custom.neonColor = col;
        saveGameData();
        selectGarageCar(carId);
      };
      nCont.appendChild(btn);
    });

    // Rim swatches
    const rCont = document.getElementById("swatches-rims");
    rCont.innerHTML = "";
    colors.forEach(col => {
      const btn = document.createElement("button");
      btn.className = `swatch-btn ${custom.rimColor === col ? 'active' : ''}`;
      btn.style.backgroundColor = col;
      btn.onclick = () => {
        custom.rimColor = col;
        saveGameData();
        selectGarageCar(carId);
      };
      rCont.appendChild(btn);
    });
  }

  // --- TRACK SELECTION & MODES ---
  function renderTrackCards() {
    const grid = document.getElementById("track-cards-grid");
    grid.innerHTML = "";

    TRACK_CONFIGS.forEach(track => {
      const card = document.createElement("div");
      card.className = `car-item-card ${track.id === selectedTrackConfig.id ? 'selected' : ''}`;
      card.style.flexDirection = "column";
      card.style.alignItems = "flex-start";
      card.style.gap = "6px";
      card.innerHTML = `
        <div style="display:flex; justify-content:space-between; width:100%;">
          <h4 style="font-size:1.1rem; color:#fff;">${track.name}</h4>
          <span class="badge" style="background:#00e5ff; color:#000;">${track.difficulty}</span>
        </div>
        <div style="font-size:0.8rem; color:var(--text-muted);">${track.location} • ${track.lengthKm} • ${track.defaultLaps} Laps</div>
        <p style="font-size:0.75rem; color:#bbb;">${track.description}</p>
      `;

      card.addEventListener("click", () => {
        selectedTrackConfig = track;
        document.querySelectorAll("#track-cards-grid .car-item-card").forEach(c => c.classList.remove("selected"));
        card.classList.add("selected");
      });

      grid.appendChild(card);
    });
  }

  // --- ACHIEVEMENTS & CAREER DATA ---
  function renderAchievements() {
    const cont = document.getElementById("achievements-list");
    cont.innerHTML = "";

    const achs = [
      { key: 'first_win', name: 'First Victory', desc: 'Win 1st place in any racing event', completed: playerData.achievements.first_win },
      { key: 'drift_master', name: 'Drift Master', desc: 'Score over 3,000 drift points in a single race', completed: playerData.achievements.drift_master },
      { key: 'races_count', name: 'Street Veteran', desc: 'Complete 10 total races', completed: playerData.achievements.races_count >= 10, prog: `${playerData.achievements.races_count}/10` }
    ];

    achs.forEach(ach => {
      const row = document.createElement("div");
      row.className = "setting-row";
      row.innerHTML = `
        <div>
          <span style="font-weight:bold; color:${ach.completed ? 'var(--neon-green)' : '#fff'}">${ach.name} ${ach.completed ? '✓' : ''}</span>
          <p style="font-size:0.75rem; color:var(--text-muted);">${ach.desc} ${ach.prog ? `(${ach.prog})` : ''}</p>
        </div>
        <div>
          ${ach.completed ? '<span class="badge" style="background:#00e676; color:#000;">UNLOCKED</span>' : '<span class="badge" style="background:#444;">LOCKED</span>'}
        </div>
      `;
      cont.appendChild(row);
    });
  }

  // --- USER INPUT EVENT LISTENERS ---
  function setupInputListeners() {
    // Keyboard desktop controls
    window.addEventListener("keydown", e => {
      switch (e.code) {
        case "KeyW":
        case "ArrowUp":
          keys.forward = true;
          break;
        case "KeyS":
        case "ArrowDown":
          keys.backward = true;
          break;
        case "KeyA":
        case "ArrowLeft":
          keys.left = true;
          break;
        case "KeyD":
        case "ArrowRight":
          keys.right = true;
          break;
        case "Space":
          keys.drift = true;
          break;
        case "ShiftLeft":
        case "ShiftRight":
          keys.nitro = true;
          break;
        case "Escape":
          if (gameState === 'RACE') openModal("screen-pause");
          break;
      }
    });

    window.addEventListener("keyup", e => {
      switch (e.code) {
        case "KeyW":
        case "ArrowUp":
          keys.forward = false;
          break;
        case "KeyS":
        case "ArrowDown":
          keys.backward = false;
          break;
        case "KeyA":
        case "ArrowLeft":
          keys.left = false;
          break;
        case "KeyD":
        case "ArrowRight":
          keys.right = false;
          break;
        case "Space":
          keys.drift = false;
          break;
        case "ShiftLeft":
        case "ShiftRight":
          keys.nitro = false;
          break;
      }
    });

    // Touch controls on mobile HUD
    bindTouchBtn("btn-touch-left", state => { keys.left = state; });
    bindTouchBtn("btn-touch-right", state => { keys.right = state; });
    bindTouchBtn("btn-touch-accel", state => { keys.forward = state; });
    bindTouchBtn("btn-touch-brake", state => { keys.backward = state; });
    bindTouchBtn("btn-touch-drift", state => { keys.drift = state; });
    bindTouchBtn("btn-touch-nitro", state => { keys.nitro = state; });

    // Garage 3D Drag Orbit
    container.addEventListener("pointerdown", e => {
      if (gameState === 'GARAGE') {
        garageOrbit.isDragging = true;
        garageOrbit.lastMouseX = e.clientX;
        garageOrbit.lastMouseY = e.clientY;
      }
    });

    window.addEventListener("pointermove", e => {
      if (garageOrbit.isDragging && gameState === 'GARAGE' && showcaseCarMesh) {
        const dx = e.clientX - garageOrbit.lastMouseX;
        showcaseCarMesh.rotation.y += dx * 0.008;
        garageOrbit.lastMouseX = e.clientX;
        garageOrbit.lastMouseY = e.clientY;
      }
    });

    window.addEventListener("pointerup", () => {
      garageOrbit.isDragging = false;
    });
  }

  function bindTouchBtn(btnId, callback) {
    const el = document.getElementById(btnId);
    if (!el) return;

    el.addEventListener("touchstart", e => {
      e.preventDefault();
      el.classList.add("pressed");
      callback(true);
      triggerHaptic(20);
    }, { passive: false });

    el.addEventListener("touchend", e => {
      e.preventDefault();
      el.classList.remove("pressed");
      callback(false);
    }, { passive: false });

    el.addEventListener("mousedown", () => {
      el.classList.add("pressed");
      callback(true);
    });

    el.addEventListener("mouseup", () => {
      el.classList.remove("pressed");
      callback(false);
    });

    el.addEventListener("mouseleave", () => {
      el.classList.remove("pressed");
      callback(false);
    });
  }

  // --- UI BUTTONS & NAVIGATION LISTENERS ---
  function setupUIEventListeners() {
    // Main Menu Buttons
    document.getElementById("btn-play-race").onclick = () => {
      window.AudioEngine.playClick();
      openModal("modal-track-select");
    };

    document.getElementById("btn-quick-garage").onclick =
    document.getElementById("btn-open-garage").onclick = () => {
      window.AudioEngine.playClick();
      gameState = 'GARAGE';
      switchScreen("screen-garage");
      renderGarageCarList();
    };

    document.getElementById("btn-open-career").onclick = () => {
      window.AudioEngine.playClick();
      openCareerModal();
    };

    document.getElementById("btn-open-multiplayer").onclick = () => {
      window.AudioEngine.playClick();
      openModal("modal-multiplayer");
    };

    document.getElementById("btn-open-events").onclick = () => {
      window.AudioEngine.playClick();
      openEventsModal();
    };

    document.getElementById("btn-open-clubs").onclick = () => {
      window.AudioEngine.playClick();
      openClubsModal();
    };

    document.getElementById("btn-open-leaderboard").onclick = () => {
      window.AudioEngine.playClick();
      openLeaderboardModal();
    };

    document.getElementById("btn-open-friends").onclick = () => {
      window.AudioEngine.playClick();
      openFriendsModal();
    };

    document.getElementById("btn-daily-reward").onclick = () => {
      window.AudioEngine.playClick();
      openDailyRewardModal();
    };

    document.getElementById("btn-open-profile").onclick = () => {
      window.AudioEngine.playClick();
      openModal("modal-profile");
    };

    document.getElementById("btn-open-settings").onclick =
    document.getElementById("btn-pause-settings").onclick = () => {
      window.AudioEngine.playClick();
      openModal("modal-settings");
    };

    // Track Select Modal
    document.getElementById("btn-close-track-select").onclick =
    document.getElementById("btn-cancel-track-select").onclick = () => {
      closeModal("modal-track-select");
    };

    document.getElementById("btn-start-selected-race").onclick = () => {
      closeModal("modal-track-select");
      startRace(selectedTrackConfig, currentGameMode);
    };

    // Garage Navigation
    document.getElementById("btn-garage-back").onclick = () => {
      window.AudioEngine.playClick();
      gameState = 'MENU';
      switchScreen("screen-main-menu");
      setupShowcaseScene();
    };

    document.getElementById("btn-garage-race").onclick = () => {
      window.AudioEngine.playClick();
      startRace(selectedTrackConfig, 'solo');
    };

    // Garage Tabs
    document.querySelectorAll(".garage-tab-btn").forEach(tab => {
      tab.onclick = () => {
        document.querySelectorAll(".garage-tab-btn").forEach(t => t.classList.remove("active"));
        tab.classList.add("active");
        const target = tab.dataset.tab;
        document.getElementById("tab-content-stats").style.display = target === 'stats' ? 'flex' : 'none';
        document.getElementById("tab-content-upgrades").style.display = target === 'upgrades' ? 'flex' : 'none';
        document.getElementById("tab-content-custom").style.display = target === 'custom' ? 'flex' : 'none';
      };
    });

    // Pause Screen Buttons
    document.getElementById("btn-pause-race").onclick = () => {
      openModal("screen-pause");
    };

    document.getElementById("btn-pause-resume").onclick = () => {
      closeModal("screen-pause");
    };

    document.getElementById("btn-pause-restart").onclick = () => {
      closeModal("screen-pause");
      startRace(selectedTrackConfig, currentGameMode);
    };

    document.getElementById("btn-pause-quit").onclick = () => {
      closeModal("screen-pause");
      window.AudioEngine.stopEngine();
      gameState = 'MENU';
      switchScreen("screen-main-menu");
      setupShowcaseScene();
    };

    // Finish Screen Buttons
    document.getElementById("btn-finish-menu").onclick = () => {
      closeModal("screen-finish");
      gameState = 'MENU';
      switchScreen("screen-main-menu");
      setupShowcaseScene();
    };

    document.getElementById("btn-finish-restart").onclick = () => {
      closeModal("screen-finish");
      startRace(selectedTrackConfig, currentGameMode);
    };

    document.getElementById("btn-finish-garage").onclick = () => {
      closeModal("screen-finish");
      gameState = 'GARAGE';
      switchScreen("screen-garage");
      renderGarageCarList();
    };

    // Career Modal
    document.getElementById("btn-close-career").onclick =
    document.getElementById("btn-back-career").onclick = () => {
      closeModal("modal-career");
    };

    // Multiplayer Modal
    document.getElementById("btn-close-multiplayer").onclick = () => {
      closeModal("modal-multiplayer");
    };

    document.getElementById("btn-mp-quickmatch").onclick = () => {
      simulateMpMatchmaking();
    };

    document.getElementById("btn-mp-create-room").onclick = () => {
      const code = "DRIFT" + Math.floor(10 + Math.random() * 89);
      document.getElementById("input-room-code").value = code;
      simulateMpMatchmaking(code);
    };

    document.getElementById("btn-mp-join-room").onclick = () => {
      const code = document.getElementById("input-room-code").value.trim();
      if (code) simulateMpMatchmaking(code);
    };

    document.getElementById("btn-mp-start-grid").onclick = () => {
      closeModal("modal-multiplayer");
      startRace(TRACK_CONFIGS[4], 'mp');
    };

    // Daily Reward
    document.getElementById("btn-claim-daily").onclick = () => {
      playerData.credits += 10000;
      playerData.tokens += 50;
      saveGameData();
      window.AudioEngine.playReward();
      document.getElementById("daily-reward-status").textContent = "Claimed! +10,000 🪙 +50 💎";
      document.getElementById("btn-claim-daily").disabled = true;
    };

    document.getElementById("btn-close-daily").onclick = () => {
      closeModal("modal-daily-reward");
    };

    // Settings Modal
    document.getElementById("btn-close-settings").onclick =
    document.getElementById("btn-save-settings").onclick = () => {
      applySettingsFromUI();
      closeModal("modal-settings");
    };

    document.getElementById("btn-reset-save").onclick = () => {
      if (confirm("Reset all game save data? This cannot be undone.")) {
        localStorage.removeItem("street_drift_legends_save");
        location.reload();
      }
    };

    // Other Modals Close
    document.getElementById("btn-close-events").onclick = () => closeModal("modal-events");
    document.getElementById("btn-close-clubs").onclick = () => closeModal("modal-clubs");
    document.getElementById("btn-close-leaderboard").onclick = () => closeModal("modal-leaderboard");
    document.getElementById("btn-close-friends").onclick = () => closeModal("modal-friends");
    document.getElementById("btn-close-profile").onclick = () => closeModal("modal-profile");

    // Profile save
    document.getElementById("btn-save-profile").onclick = () => {
      const newName = document.getElementById("input-profile-name").value.trim();
      if (newName) {
        playerData.playerName = newName;
        saveGameData();
        closeModal("modal-profile");
      }
    };
  }

  function simulateMpMatchmaking(roomCode = "DRIFT88") {
    document.getElementById("mp-room-tag").textContent = roomCode;
    const lobby = document.getElementById("mp-lobby-container");
    lobby.style.display = "block";

    const racersCont = document.getElementById("mp-lobby-racers");
    racersCont.innerHTML = "";

    const mpPlayers = [
      { name: playerData.playerName, ping: "22ms", isMe: true },
      { name: "TokyoDrifter", ping: "38ms" },
      { name: "AeroGhost", ping: "45ms" },
      { name: "NightRider", ping: "52ms" },
      { name: "SpeedDemon", ping: "60ms" },
      { name: "ApexPredator", ping: "34ms" },
      { name: "KanseiMaster", ping: "71ms" },
      { name: "V8Overload", ping: "29ms" }
    ];

    mpPlayers.forEach(p => {
      const item = document.createElement("div");
      item.style.background = p.isMe ? "rgba(0, 229, 255, 0.2)" : "rgba(255, 255, 255, 0.05)";
      item.style.padding = "8px";
      item.style.borderRadius = "6px";
      item.style.fontSize = "0.8rem";
      item.innerHTML = `
        <div style="font-weight:bold; color:${p.isMe ? 'var(--neon-cyan)' : '#fff'};">${p.name}</div>
        <div style="color:#00e676; font-size:0.7rem;">READY (${p.ping})</div>
      `;
      racersCont.appendChild(item);
    });
  }

  function openCareerModal() {
    openModal("modal-career");
    const tabsCont = document.getElementById("career-series-tabs");
    tabsCont.innerHTML = "";

    const seriesList = [
      "Rookie Series", "Street Series", "Pro Series", "Elite Series", "Drift Masters", "World Championship"
    ];

    seriesList.forEach((sName, idx) => {
      const btn = document.createElement("button");
      btn.className = `btn btn-sm ${idx === 0 ? 'btn-primary' : ''}`;
      btn.textContent = sName;
      btn.onclick = () => {
        document.querySelectorAll("#career-series-tabs button").forEach(b => b.classList.remove("btn-primary"));
        btn.classList.add("btn-primary");
        renderCareerEvents(idx);
      };
      tabsCont.appendChild(btn);
    });

    renderCareerEvents(0);
  }

  function renderCareerEvents(seriesIdx) {
    const grid = document.getElementById("career-events-grid");
    grid.innerHTML = "";

    const eventTypes = ["Solo Race", "Drift Challenge", "Time Trial", "Knockdown Sprint", "Boss Showdown"];
    eventTypes.forEach((type, idx) => {
      const card = document.createElement("div");
      card.className = "car-item-card";
      card.style.flexDirection = "column";
      card.style.alignItems = "flex-start";
      card.innerHTML = `
        <div style="display:flex; justify-content:space-between; width:100%;">
          <strong>${type}</strong>
          <span style="color:#ffca28;">★★★</span>
        </div>
        <div style="font-size:0.75rem; color:var(--text-muted); margin-top:4px;">Circuit: ${TRACK_CONFIGS[idx % TRACK_CONFIGS.length].name}</div>
        <button class="btn btn-sm btn-primary" style="margin-top:8px; width:100%;">RACE EVENT ▶</button>
      `;

      card.querySelector("button").onclick = () => {
        closeModal("modal-career");
        startRace(TRACK_CONFIGS[idx % TRACK_CONFIGS.length], 'career');
      };

      grid.appendChild(card);
    });
  }

  function openEventsModal() {
    openModal("modal-events");
    const cont = document.getElementById("events-list-container");
    cont.innerHTML = `
      <div class="car-item-card" style="margin-bottom:10px;">
        <div>
          <h4>WEEKEND DRIFT INFERNO</h4>
          <p style="font-size:0.8rem; color:var(--text-muted);">Score 5,000 drift points in Neon Tokyo. Reward: 25,000 🪙</p>
        </div>
        <button class="btn btn-sm btn-primary" onclick="window.startEventRace(0)">ENTER</button>
      </div>
      <div class="car-item-card">
        <div>
          <h4>DESERT CANYON HYPER RUSH</h4>
          <p style="font-size:0.8rem; color:var(--text-muted);">Reach top speed 280 km/h and win 1st place. Reward: 100 💎</p>
        </div>
        <button class="btn btn-sm btn-primary" onclick="window.startEventRace(1)">ENTER</button>
      </div>
    `;
  }

  window.startEventRace = function(trackIdx) {
    closeModal("modal-events");
    startRace(TRACK_CONFIGS[trackIdx], 'solo');
  };

  function openClubsModal() {
    openModal("modal-clubs");
    const cont = document.getElementById("clubs-content");
    cont.innerHTML = `
      <div style="background:rgba(255,255,255,0.05); padding:14px; border-radius:8px;">
        <h3>CURRENT CLUB: TOKYO MIDNIGHT</h3>
        <p style="font-size:0.85rem; color:var(--neon-cyan);">Club Rank #4 • 24/30 Members • 142,500 Club XP</p>
      </div>
      <h4 style="margin-top:10px;">TOP CLUBS LEADERBOARD</h4>
      <div style="display:flex; flex-direction:column; gap:6px; font-size:0.9rem;">
        <div class="setting-row"><span>#1 APEX DRIFTERS</span><span style="color:#ffca28;">280,000 XP</span></div>
        <div class="setting-row"><span>#2 NEON SYNDICATE</span><span style="color:#ffca28;">210,000 XP</span></div>
        <div class="setting-row"><span>#3 PHANTOM CREW</span><span style="color:#ffca28;">185,000 XP</span></div>
      </div>
    `;
  }

  function openLeaderboardModal() {
    openModal("modal-leaderboard");
    const cont = document.getElementById("leaderboard-table");
    cont.innerHTML = `
      <div class="setting-row" style="background:rgba(0, 229, 255, 0.15); padding:8px 12px; border-radius:6px;">
        <span>#1 ${playerData.playerName} (YOU)</span>
        <span style="color:var(--neon-cyan); font-weight:bold;">${playerData.achievements.total_drift_score.toLocaleString()} PTS</span>
      </div>
      <div class="setting-row"><span>#2 DriftKing_99</span><span>84,200 PTS</span></div>
      <div class="setting-row"><span>#3 TurboRaven</span><span>78,900 PTS</span></div>
      <div class="setting-row"><span>#4 Kenji_Drift</span><span>69,400 PTS</span></div>
      <div class="setting-row"><span>#5 ShadowDriver</span><span>58,100 PTS</span></div>
    `;
  }

  function openFriendsModal() {
    openModal("modal-friends");
    const cont = document.getElementById("friends-list");
    cont.innerHTML = `
      <div class="setting-row"><span>⚡ Ryan_Drift (Online)</span><button class="btn btn-sm btn-primary">INVITE</button></div>
      <div class="setting-row"><span>⚡ Akira86 (In Race)</span><button class="btn btn-sm">SPECTATE</button></div>
      <div class="setting-row"><span>⚡ Speedster (Offline)</span><span style="color:var(--text-muted); font-size:0.8rem;">2h ago</span></div>
    `;
  }

  function openDailyRewardModal() {
    openModal("modal-daily-reward");
    const cal = document.getElementById("daily-rewards-calendar");
    cal.innerHTML = "";
    for (let i = 1; i <= 7; i++) {
      const dayEl = document.createElement("div");
      dayEl.style.background = i === 1 ? "rgba(0,229,255,0.2)" : "rgba(255,255,255,0.05)";
      dayEl.style.border = i === 1 ? "1px solid var(--neon-cyan)" : "1px solid rgba(255,255,255,0.1)";
      dayEl.style.padding = "8px 4px";
      dayEl.style.borderRadius = "6px";
      dayEl.style.fontSize = "0.75rem";
      dayEl.innerHTML = `
        <div style="font-weight:bold;">DAY ${i}</div>
        <div style="font-size:1.2rem; margin:4px 0;">🪙</div>
        <div>+${i * 5000}</div>
      `;
      cal.appendChild(dayEl);
    }
  }

  function applySettingsFromUI() {
    playerData.settings.controlMethod = document.getElementById("setting-control-method").value;
    playerData.settings.steeringSens = parseFloat(document.getElementById("setting-steering-sens").value);
    playerData.settings.vibration = document.getElementById("setting-vibration").checked;
    playerData.settings.volMaster = parseFloat(document.getElementById("setting-vol-master").value);
    playerData.settings.volMusic = parseFloat(document.getElementById("setting-vol-music").value);
    playerData.settings.volSfx = parseFloat(document.getElementById("setting-vol-sfx").value);
    playerData.settings.graphicsQuality = document.getElementById("setting-graphics-quality").value;

    window.AudioEngine.setVolumes(
      playerData.settings.volMaster,
      playerData.settings.volMusic,
      playerData.settings.volSfx
    );

    saveGameData();
  }

  function onWindowResize() {
    if (!camera || !renderer) return;
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
  }

  // Launch on window load
  window.addEventListener("DOMContentLoaded", init);

})();
