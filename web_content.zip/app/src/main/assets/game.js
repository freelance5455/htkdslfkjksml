(()=>{
"use strict";
const Wd=DZW,{T,W,H,VW,O,ST,tile,obj,sty,flo,roo,HM,BLD,POI}=Wd;
const S=1/T,DZ=window.DZ,M=DZ.models,GEO=M.GEO,MAT=M.MAT,TEX=M.TEX,CH=DZ.char;
const $=id=>document.getElementById(id);
const clamp=(v,a,b)=>v<a?a:v>b?b:v;
const hv=(x,y,k)=>Wd.hash(x*7+k*131,y*13+k*17);
const cv=$('c'),ov=$('ov'),octx=ov.getContext('2d'),mmc=$('mm'),mx=mmc.getContext('2d');
let VWp=innerWidth,VHp=innerHeight,DPR=1;
Object.assign(O,{ANVIL:23,GUNB:24,STOVE:25,MILL:26,FIELD:27,STAIRS:28,RAIL:29,CHAIR:30,SOFA:31,SHELF:32,LAMP:33});
M.makeTextures();M.makeMaterials();M.makeGeos();
const obj2=new Uint8Array(W*H),sty2=new Uint8Array(W*H),flo2=new Uint8Array(W*H),gro=new Uint8Array(W*H);

// =====================================================================
//  CONFIG (qualité + personnage)
// =====================================================================
const CFG={quality:1,fp:true,char:Object.assign({},CH.DEFAULT)};
try{const c=JSON.parse(localStorage.getItem('dz_cfg'));if(c){if(c.quality!=null)CFG.quality=c.quality;if(c.fp!=null)CFG.fp=!!c.fp;if(c.char)Object.assign(CFG.char,c.char)}}catch(e){}
function saveCfg(){try{localStorage.setItem('dz_cfg',JSON.stringify(CFG))}catch(e){}}
const QUAL=[{shadow:false,dpr:0.75,R:18,sm:0,grass:0,gr:0,wind:0,cloud:0,aniso:1,vig:0},{shadow:true,dpr:1,R:26,sm:1024,grass:1,gr:10,wind:1,cloud:1,aniso:2,vig:1},{shadow:true,dpr:1.75,R:36,sm:2048,grass:3,gr:16,wind:1,cloud:1,aniso:8,vig:1}];
let RAD=30;

// =====================================================================
//  ETAT
// =====================================================================
const items={bois:'Bois',pierre:'Pierre',ferraille:'Ferraille',minerai:'Minerai de fer',metal:'Lingot de fer',tissu:'Tissu',
 graine_ble:'Graines de blé',graine_carotte:'Graines de carotte',graine_patate:'Plants de patate',
 ble:'Blé',farine:'Farine',carotte:'Carotte',patate:'Pomme de terre',baies:'Baies',compote:'Compote',patate_cuite:'Patate rôtie',pain:'Pain',pates:'Pâtes',ragout:'Ragoût',conserve:'Conserve',bandage:'Bandage',munitions:'Munitions',
 hache_bois:'Hache en bois',pioche_bois:'Pioche en bois',houe:'Houe',hache_pierre:'Hache en pierre',pioche_pierre:'Pioche en pierre',hache_fer:'Hache en fer',pioche_fer:'Pioche en fer',
 batte:'Batte cloutée',machette:'Machette',pistolet:'Pistolet',fusil:'Fusil'};
const TOOLS=new Set(['hache_bois','pioche_bois','houe','hache_pierre','pioche_pierre','hache_fer','pioche_fer']);
const WPN={poing:{n:'Poings',dmg:6,rng:38},batte:{n:'Batte',dmg:16,rng:54},machette:{n:'Machette',dmg:26,rng:52},pistolet:{n:'Pistolet',dmg:26,rng:300,gun:1,cd:0.45},fusil:{n:'Fusil',dmg:62,rng:420,gun:1,cd:0.85}};
const FOOD={baies:[6,2],carotte:[10,3],patate:[4,0],patate_cuite:[22,0],compote:[20,2],pain:[30,0],pates:[38,0],ragout:[55,6],conserve:[40,0]};
const P={x:0,y:0,h:0,hp:100,food:100,water:100,fx:0,fy:1,w:'poing',cd:0,hurt:0,swing:0,mv:0,lv:0,inv:{}};
for(const k in items)P.inv[k]=0;
const axeT=()=>P.inv.hache_fer?3:P.inv.hache_pierre?2:P.inv.hache_bois?1:0;
const pickT=()=>P.inv.pioche_fer?3:P.inv.pioche_pierre?2:P.inv.pioche_bois?1:0;
let D=0.06,day=1,paused=false,dead=false,buildSel=null,demo=false,menuTab=null,inGame=false,cur=null,WRES=null;
let zs=[],fxs=[],txts=[],turrets=[],spawnT=0,saveT=0,hudT=0,mmT=0,DT=0.016,msgT=0,savedT=0,hintT=0,fields=[],growT=0;
let dirty=true,mmDirty=true;
const hpm=new Map(),tcd={},trample=new Map();
let camYaw=0,camPitch=0.95,fpPitch=0;const CD=7.6,EYE=1.42;
let SPAWN={x:0,y:0};
const bAt=new Uint16Array(W*H);let bTint=[];
const TOOLN={hache_bois:'une hache en bois',pioche_bois:'une pioche en bois',houe:'une houe',hache_pierre:'une hache en pierre',pioche_pierre:'une pioche en pierre',hache_fer:'une hache en fer',pioche_fer:'une pioche en fer'};

const BUILD=[
 {id:'mur_bois',cat:'Murs & ouvertures',n:'Mur en bois',o:O.WALL,s:ST.WOOD,c:{bois:3}},
 {id:'mur_pierre',n:'Mur en pierre',o:O.WALL,s:ST.STONE,c:{pierre:3},req:'hache_bois'},
 {id:'mur_beton',n:'Mur en béton',o:O.WALL,s:ST.CONC,c:{pierre:4,ferraille:2},req:'pioche_pierre'},
 {id:'fen_bois',n:'Mur avec fenêtre (bois)',o:O.WINDOW,s:ST.WOOD,c:{bois:4}},
 {id:'fen_pierre',n:'Mur avec fenêtre (pierre)',o:O.WINDOW,s:ST.STONE,c:{pierre:3,ferraille:1},req:'hache_bois'},
 {id:'porte_bois',n:'Porte en bois',o:O.DOORC,s:ST.WOOD,c:{bois:5}},
 {id:'porte_metal',n:'Porte blindée',o:O.DOORC,s:ST.METAL,c:{metal:3,bois:1},req:'hache_fer'},
 {id:'palissade',cat:'Clôtures',n:'Palissade en bois',o:O.FENCE,s:ST.WOOD,c:{bois:2}},
 {id:'cloture',n:'Clôture grillagée',o:O.FENCE,s:ST.METAL,c:{ferraille:3}},
 {id:'sol_bois',cat:'Sols, étages & toits',n:'Plancher en bois (rez)',fl:1,c:{bois:2}},
 {id:'sol_dalle',n:'Dalle en béton (rez)',fl:2,c:{pierre:2},req:'pioche_bois'},
 {id:'sol_carrelage',n:'Carrelage (rez)',fl:3,c:{pierre:2,ferraille:1},req:'pioche_pierre'},
 {id:'etage_bois',n:'Plancher d\'étage en bois',fl2:1,c:{bois:4},req:'hache_bois'},
 {id:'etage_beton',n:'Plancher d\'étage en béton',fl2:2,c:{pierre:4,ferraille:2},req:'pioche_pierre'},
 {id:'escalier',n:'Escalier (monte devant toi)',o:O.STAIRS,c:{bois:8,ferraille:1},req:'hache_bois'},
 {id:'rambarde',n:'Rambarde',o:O.RAIL,c:{bois:2}},
 {id:'toit_plat',n:'Toit plat',ro:1,c:{bois:2,ferraille:1}},
 {id:'toit_pente',n:'Toit en pente (haut = devant toi)',ro:2,c:{bois:3}},
 {id:'table',cat:'Meubles',n:'Table',o:O.TABLE,c:{bois:6}},
 {id:'chaise',n:'Chaise',o:O.CHAIR,c:{bois:3}},
 {id:'canape',n:'Canapé',o:O.SOFA,c:{bois:6,tissu:5},req:'hache_bois'},
 {id:'lit',n:'Lit (dormir la nuit)',o:O.BED,c:{bois:6,tissu:4},req:'hache_bois'},
 {id:'armoire',n:'Armoire',o:O.CABO,c:{bois:8}},
 {id:'etagere',n:'Étagère',o:O.SHELF,c:{bois:5}},
 {id:'lampe',n:'Lampe',o:O.LAMP,c:{ferraille:2,tissu:1}},
 {id:'etabli',cat:'Ateliers (chaîne technologique)',n:'1. Établi — outils en pierre',o:O.BENCH,c:{bois:14,pierre:3},req:'hache_bois'},
 {id:'four',n:'2. Four — fond le minerai',o:O.FURN,c:{pierre:14},req:'pioche_pierre'},
 {id:'forge',n:'3. Forge — outils & armes blanches en fer',o:O.ANVIL,c:{pierre:10,ferraille:8,bois:6},req:'pioche_pierre'},
 {id:'armurerie',n:'4. Établi d\'armurier — armes à feu',o:O.GUNB,c:{metal:10,bois:8,ferraille:6},req:'pioche_fer'},
 {id:'cuisiniere',n:'Cuisinière',o:O.STOVE,c:{pierre:6,ferraille:6},req:'hache_pierre'},
 {id:'moulin',n:'Moulin à main (blé → farine)',o:O.MILL,c:{bois:10,pierre:6},req:'hache_bois'},
 {id:'feu',n:'Feu de camp',o:O.FIRE,c:{bois:4,pierre:2}},
 {id:'tourelle',n:'Tourelle automatique',o:O.TURRET,c:{metal:8,ferraille:6,munitions:20},req:'pioche_fer'},
 {id:'champ',cat:'Culture',n:'Champ labouré (herbe / terre)',o:O.FIELD,c:{bois:1},req:'houe'}
];
const STN={etabli:[O.BENCH],furn:[O.FURN],forge:[O.ANVIL],armu:[O.GUNB],stove:[O.STOVE],mill:[O.MILL],fire:[O.FIRE,O.STOVE]};
const STNAME={main:'à la main',etabli:'Établi',furn:'Four',forge:'Forge',armu:'Établi d\'armurier',stove:'Cuisinière',mill:'Moulin',fire:'Feu / cuisinière'};
const REC=[
 {id:'hache_bois',n:'Hache en bois',st:'main',c:{bois:5,pierre:1},give:{hache_bois:1},uniq:1},
 {id:'pioche_bois',n:'Pioche en bois',st:'main',c:{bois:5,pierre:2},give:{pioche_bois:1},uniq:1},
 {id:'houe',n:'Houe',st:'main',c:{bois:4,pierre:1},give:{houe:1},uniq:1},
 {id:'bandage',n:'Bandages x2',st:'main',c:{tissu:2,baies:1},give:{bandage:2}},
 {id:'hache_pierre',n:'Hache en pierre',st:'etabli',c:{bois:4,pierre:5},give:{hache_pierre:1},uniq:1,req:'hache_bois'},
 {id:'pioche_pierre',n:'Pioche en pierre',st:'etabli',c:{bois:4,pierre:5},give:{pioche_pierre:1},uniq:1,req:'pioche_bois'},
 {id:'batte',n:'Batte cloutée',st:'etabli',c:{bois:8,ferraille:2},give:{batte:1},uniq:1},
 {id:'lingot1',n:'Lingot de fer (minerai)',st:'furn',c:{minerai:2,bois:1},give:{metal:1}},
 {id:'lingot2',n:'Lingot de fer (ferraille)',st:'furn',c:{ferraille:4,bois:1},give:{metal:1}},
 {id:'hache_fer',n:'Hache en fer',st:'forge',c:{metal:4,bois:3},give:{hache_fer:1},uniq:1},
 {id:'pioche_fer',n:'Pioche en fer',st:'forge',c:{metal:4,bois:3},give:{pioche_fer:1},uniq:1},
 {id:'machette',n:'Machette',st:'forge',c:{metal:4,bois:2},give:{machette:1},uniq:1},
 {id:'munitions',n:'Munitions x10',st:'armu',c:{metal:1,ferraille:3},give:{munitions:10}},
 {id:'pistolet',n:'Pistolet',st:'armu',c:{metal:6,ferraille:4},give:{pistolet:1},uniq:1},
 {id:'fusil',n:'Fusil',st:'armu',c:{metal:12,bois:6,ferraille:6},give:{fusil:1},uniq:1},
 {id:'farine',n:'Farine x2',st:'mill',c:{ble:3},give:{farine:2}},
 {id:'compote',n:'Compote',st:'fire',c:{baies:3},give:{compote:1}},
 {id:'patate_cuite',n:'Patate rôtie',st:'fire',c:{patate:1},give:{patate_cuite:1}},
 {id:'pain',n:'Pain',st:'stove',c:{farine:2,bois:1},give:{pain:1}},
 {id:'pates',n:'Pâtes',st:'stove',c:{farine:2,bois:1},give:{pates:2}},
 {id:'ragout',n:'Ragoût',st:'stove',c:{carotte:2,patate:2,bois:1},give:{ragout:1}}
];
const CROPS=[null,{n:'Blé',seed:'graine_ble',yield:'ble',lo:2,hi:4,tint:[0x8ab04a,0x9ab84a,0xe8c860]},{n:'Carottes',seed:'graine_carotte',yield:'carotte',lo:2,hi:3,tint:[0x6aa040,0x58a038,0xe08a3a]},{n:'Pommes de terre',seed:'graine_patate',yield:'patate',lo:2,hi:4,tint:[0x5a9a3a,0x4a8a30,0x9ac060]}];
const ZT={
 walker:{hp:30,sp:45,dmg:8,r:10,sc:1},
 runner:{hp:18,sp:95,dmg:6,r:9,sc:0.93},
 brute:{hp:110,sp:38,dmg:22,r:14,sc:1.4}
};

// =====================================================================
//  COLLISIONS (murs minces, portes, mobilier)
// =====================================================================
const WALLISH=new Uint8Array(40);[6,12,14,15].forEach(k=>WALLISH[k]=1);
const EXT={1:.2,2:.36,3:.3,4:.42,5:.34,8:.42,9:.44,10:.3,11:.3,16:.5,17:.5,18:.38,19:.42,20:.35,21:.35,22:.24,23:.44,24:.46,25:.42,26:.38,30:.22,31:.46,32:.42,33:.12};
const DX4=[0,1,0,-1],DY4=[-1,0,1,0];
const connW=(A,x,y)=>x>=0&&y>=0&&x<W&&y<H&&WALLISH[A[y*W+x]]===1;
const connF=(A,x,y)=>{if(x<0||y<0||x>=W||y>=H)return false;const o=A[y*W+x];return o===O.FENCE||o===O.TOWER||o===O.RAIL};
function stairT(d,lx,lz){ // progression (0 bas → 1 haut) et décalage latéral
 return d===0?[0.5-lz,lx]:d===1?[lx+0.5,lz]:d===2?[lz+0.5,lx]:[0.5-lx,lz];
}
function solid(px,py,lv){
 const tx=Math.floor(px/T),ty=Math.floor(py/T);
 if(tx<0||ty<0||tx>=W||ty>=H)return true;
 const i=ty*W+tx,lx=px/T-tx-.5,lz=py/T-ty-.5;
 let A=obj,o;
 if(lv===1){
  if(obj[i]===O.STAIRS){const st=stairT(sty[i],lx,lz);return st[0]<0.55||Math.abs(st[1])>0.34}
  if(!flo2[i])return true;
  A=obj2;o=obj2[i];
 }else{
  if(tile[i]===1)return true;
  o=obj[i];
  if(o===O.STAIRS){const st=stairT(sty[i],lx,lz);return Math.abs(st[1])>0.34}
 }
 if(o===0||o===O.FIELD)return false;
 if(WALLISH[o]===1||o===O.FENCE||o===O.RAIL){
  const fn=o===O.FENCE||o===O.RAIL,cn=fn?connF:connW,th=fn?0.1:0.17;
  const nN=cn(A,tx,ty-1),nE=cn(A,tx+1,ty),nS=cn(A,tx,ty+1),nW=cn(A,tx-1,ty);
  if(o===O.DOORO){
   if(nE||nW){return Math.abs(lx)>0.35&&Math.abs(lz)<th}
   return Math.abs(lz)>0.35&&Math.abs(lx)<th;
  }
  if(!nN&&!nE&&!nS&&!nW)return Math.abs(lz)<th;
  if(Math.abs(lx)<th&&Math.abs(lz)<th)return true;
  if(nE&&lx>0&&Math.abs(lz)<th)return true;
  if(nW&&lx<0&&Math.abs(lz)<th)return true;
  if(nN&&lz<0&&Math.abs(lx)<th)return true;
  if(nS&&lz>0&&Math.abs(lx)<th)return true;
  return false;
 }
 const e=EXT[o]||0.4;return Math.abs(lx)<e&&Math.abs(lz)<e;
}
function canMove(x,y,r,lv){lv=lv||0;return!(solid(x-r,y-r,lv)||solid(x+r,y-r,lv)||solid(x-r,y+r,lv)||solid(x+r,y+r,lv))}
const hP=(x,y)=>Wd.hSample(x*S,y*S);
const WHh=GEO.WH;
function hLevel(x,y,lv){
 const base=hP(x,y);
 if(lv===0){const tx=Math.floor(x/T),ty=Math.floor(y/T);if(tx>=0&&ty>=0&&tx<W&&ty<H){const i=ty*W+tx;if(obj[i]===O.STAIRS){const st=stairT(sty[i],x/T-tx-.5,y/T-ty-.5);return base+WHh*clamp(st[0],0,1)}}return base}
 return base+WHh;
}

// ---------- points de vie des structures ----------
const STYHP=[1,2.2,2,2.6,1.4,3.2];
const BASEHP={6:20,7:12,8:25,9:30,10:10,11:40,12:14,14:16,15:16,16:60,4:3,5:1,22:1,17:1,23:40,24:40,25:30,26:25,28:20,29:8,30:6,31:12,32:10,33:4,18:10,19:12,21:10};
BASEHP[1]=3;BASEHP[2]=3;BASEHP[3]=2;
const DAMAGEABLE=new Set([6,7,8,9,10,11,12,14,15,16,23,24,25,26,28,29]);
function maxHp(i){const o=obj[i];let h=BASEHP[o]||1;if(o===6||o===7||o===12||o===14||o===15)h*=STYHP[sty[i]];return h}
function dmgObj(i,d){let h=hpm.has(i)?hpm.get(i):maxHp(i);h-=d;if(h<=0){hpm.delete(i);return true}hpm.set(i,h);return false}
function setObj(i,v,s){obj[i]=v;if(s!=null)sty[i]=s;dirty=true;mmDirty=true}
function setObj2(i,v,s){obj2[i]=v;if(s!=null)sty2[i]=s;dirty=true}
function add(k,n){P.inv[k]=(P.inv[k]||0)+n}
function has(c){for(const k in c)if((P.inv[k]||0)<c[k])return false;return true}
function pay(c){for(const k in c)P.inv[k]-=c[k]}
function costStr(c){return Object.keys(c).map(k=>c[k]+' '+items[k]).join(', ')}
function nearStn(k){if(k==='main')return true;const ids=STN[k],tx=Math.floor(P.x/T),ty=Math.floor(P.y/T);for(let y=ty-4;y<=ty+4;y++)for(let x=tx-4;x<=tx+4;x++){if(x>=0&&y>=0&&x<W&&y<H&&ids.indexOf(obj[y*W+x])>=0)return true}return false}
function rebuildTurrets(){turrets=[];for(let i=0;i<W*H;i++)if(obj[i]===O.TURRET)turrets.push(i)}
function msg(s){const m=$('msg');m.textContent=s;m.style.opacity=1;msgT=3.2}
function pop(x,y,s,col){txts.push({x,y,s,t:1,col:col||'#fff'})}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}

// =====================================================================
//  ZOMBIES (logique)
// =====================================================================
function mkZ(x,y,type,wild){const t=ZT[type];return{x,y,type,hp:t.hp,mhp:t.hp,sp:t.sp,dmg:t.dmg,r:t.r,cd:0,wt:0,wx:0,wy:0,slide:0,sa:0,flash:0,wild:!!wild,dead:false,m:null,o:null,ph:Math.random()*6,ang:Math.random()*6,fl:false,var:Math.floor(Math.random()*3),hh:0}}
function pickType(night){const r=Math.random();if(r<(night?0.12:0.08))return'brute';if(r<(night?0.45:0.33))return'runner';return'walker'}
function clearZ(){for(const z of zs)if(z.m&&scene){scene.remove(z.m);z.m=null}zs=[]}
function walkable(tx,ty){if(tx<1||ty<1||tx>=W-1||ty>=H-1)return false;const i=ty*W+tx;return tile[i]!==1&&(obj[i]===0||obj[i]===O.DOORO)}
function initZ(){
 clearZ();const base=WRES.base;
 const add2=(x0,y0,w,h,n,night,wild)=>{let c=0,t=0;while(c<n&&t<n*40){t++;const tx=x0+Math.floor(Math.random()*w),ty=y0+Math.floor(Math.random()*h);if(!walkable(tx,ty))continue;zs.push(mkZ(tx*T+16,ty*T+16,pickType(night),wild));c++}};
 add2(base.x+1,base.y+1,base.w-2,base.h-2,70,true,false);
 for(const p of POI){
  if(p.type==='village')add2(p.x,p.y,p.w,p.h,7,false,false);
  else if(p.type==='cabin')add2(p.x,p.y,p.w,p.h,1,false,false);
 }
 let n=0,t=0;
 while(n<55&&t<5000){t++;const tx=4+Math.floor(Math.random()*(W-8)),ty=4+Math.floor(Math.random()*(H-8));if(!walkable(tx,ty))continue;
  const px=tx*T+16,py=ty*T+16;if(Math.hypot(px-SPAWN.x,py-SPAWN.y)<900)continue;if(tx>=base.x&&tx<base.x+base.w&&ty>=base.y&&ty<base.y+base.h)continue;
  zs.push(mkZ(px,py,pickType(false),false));n++}
}
function dropLoot(z){
 const r=Math.random();
 if(r<0.35){add('ferraille',1);pop(z.x,z.y,'+1 ferraille','#ccc')}
 else if(r<0.5){add('bandage',1);pop(z.x,z.y,'+1 bandage','#8f8')}
 else if(r<0.6){add('munitions',3);pop(z.x,z.y,'+3 munitions','#fd6')}
 else if(r<0.72){add('tissu',1);pop(z.x,z.y,'+1 tissu','#ddd')}
}
function hurtZ(z,d){
 z.hp-=d;z.flash=0.15;pop(z.x,z.y,'-'+Math.round(d),'#ff7b7b');
 const dx=z.x-P.x,dy=z.y-P.y,l=Math.hypot(dx,dy)||1;
 const kx=dx/l*8,ky=dy/l*8;
 if(canMove(z.x+kx,z.y,z.r))z.x+=kx;if(canMove(z.x,z.y+ky,z.r))z.y+=ky;
 if(z.hp<=0&&!z.dead){z.dead=true;dropLoot(z)}
}
function nearestZ(x,y,rng,cone){let b=null,bd=rng;for(const z of zs){if(z.dead)continue;const dx=z.x-x,dy=z.y-y,d=Math.hypot(dx,dy);if(d>=bd)continue;if(cone&&d>14&&(dx*P.fx+dy*P.fy)/d<0.55)continue;bd=d;b=z}return b}
function hitS(px,py,z){
 const tx=Math.floor(px/T),ty=Math.floor(py/T);if(tx<0||ty<0||tx>=W||ty>=H)return;
 const i=ty*W+tx,t=obj[i];
 if(DAMAGEABLE.has(t)){z.slide=0;if(dmgObj(i,z.dmg*0.5*DT)){setObj(i,0);hpm.delete(i)}}
 else if(t!==0){if(z.slide<=0){z.slide=0.6;z.sa=Math.atan2(P.y-z.y,P.x-z.x)+(Math.random()<0.5?1.6:-1.6)}}
}
function zmove(z,dx,dy){
 if(canMove(z.x+dx,z.y,z.r))z.x+=dx;else if(dx!==0)hitS(z.x+Math.sign(dx)*(z.r+3),z.y,z);
 if(canMove(z.x,z.y+dy,z.r))z.y+=dy;else if(dy!==0)hitS(z.x,z.y+Math.sign(dy)*(z.r+3),z);
}
function updZ(z,dt,night){
 if(z.flash>0)z.flash-=dt;if(z.cd>0)z.cd-=dt;if(z.slide>0)z.slide-=dt;
 const dx=P.x-z.x,dy=P.y-z.y,d=Math.hypot(dx,dy);
 const aggro=(night?330:210)*(z.type==='runner'?1.2:1);
 let sp=z.sp*(night?1.1:1);
 if(d<aggro){
  if(z.slide>0){zmove(z,Math.cos(z.sa)*sp*dt,Math.sin(z.sa)*sp*dt)}
  else if(d>18){zmove(z,dx/d*sp*dt,dy/d*sp*dt)}
  if(d<z.r+14&&z.cd<=0){P.hp-=z.dmg;P.hurt=0.25;z.cd=1}
 }else{
  z.wt-=dt;if(z.wt<=0){z.wt=1+Math.random()*3;const a=Math.random()*6.283,s=Math.random()<0.4?0:1;z.wx=Math.cos(a)*s;z.wy=Math.sin(a)*s}
  zmove(z,z.wx*sp*0.4*dt,z.wy*sp*0.4*dt);
 }
}

// =====================================================================
//  ACTIONS
// =====================================================================
function shoot(z,w){
 const l0=Math.hypot(z.x-P.x,z.y-P.y)||1;if(!CFG.fp){P.fx=(z.x-P.x)/l0;P.fy=(z.y-P.y)/l0}
 addTracer(P.x*S+P.fx*0.3,P.h+(CFG.fp?1.3:0.9),P.y*S+P.fy*0.3,z.x*S,z.hh+0.7,z.y*S,0);hurtZ(z,w.dmg);
}
function act(){
 if(P.cd>0||dead||paused)return;
 if(buildSel){if(demo)demolish();else place();return}
 const w=WPN[P.w]||WPN.poing,cone=CFG.fp;
 if(w.gun&&P.inv.munitions>0){
  const z=nearestZ(P.x,P.y,w.rng,cone);
  if(z){P.inv.munitions--;shoot(z,w);P.cd=w.cd;P.swing=0.2;return}
 }
 const z=nearestZ(P.x,P.y,w.gun?40:w.rng,cone);
 if(z){
  if(!CFG.fp){const l0=Math.hypot(z.x-P.x,z.y-P.y)||1;P.fx=(z.x-P.x)/l0;P.fy=(z.y-P.y)/l0}
  hurtZ(z,w.gun?8:w.dmg);P.cd=0.45;P.swing=0.22;return}
 interact();
}
const NAMES={1:'Arbre',2:'Rocher',3:'Buisson',4:'Décombres',5:'Caisse',8:'Banc',9:'Four',10:'Feu de camp',11:'Tourelle',12:'Fenêtre',14:'Porte (ouvrir)',15:'Porte (fermer)',16:'Tour',17:'Épave',18:'Table',19:'Lit',20:'Armoire',21:'Armoire vide',22:'Baril',23:'Forge',24:'Établi d\'armurier',25:'Cuisinière',26:'Moulin',27:'Champ',28:'Escalier',29:'Rambarde',30:'Chaise',31:'Canapé',32:'Étagère',33:'Lampe',6:'Mur',7:'Clôture'};
function targetAt(){
 const A=P.lv?obj2:obj;
 for(const d of [18,36,0,52]){
  const tx=Math.floor((P.x+P.fx*d)/T),ty=Math.floor((P.y+P.fy*d)/T);
  if(tx<0||ty<0||tx>=W||ty>=H)continue;
  const i=ty*W+tx;let t=A[i];if(!t&&P.lv===0)t=0;
  if(t)return{i,t};
  if(!P.lv&&tile[i]===1)return{i,t:-1};
 }
 return null;
}
function interact(){
 const g=targetAt();if(!g)return;
 if(g.t===-1){P.water=Math.min(100,P.water+15);P.cd=0.5;pop(P.x,P.y,'+eau','#6cf');return}
 useObj(g.i,g.t);
}
function gather(i,res,n,dm){
 add(res,n);P.cd=0.4-axeT()*0.04;P.swing=0.22;pop(P.x+P.fx*24,P.y+P.fy*24,'+'+n+' '+items[res].toLowerCase());
 if(dmgObj(i,dm||1))setObj(i,0);
}
function rndSeed(){const r=Math.random();return r<0.45?'graine_ble':r<0.75?'graine_carotte':'graine_patate'}
function useObj(i,t){
 const x=i%W,y=(i/W)|0,lv=P.lv;
 switch(t){
  case O.TREE:{gather(i,'bois',[1,2,3,4][axeT()]);if(!axeT()&&Math.random()<0.5)msg('Astuce : une hache en bois récolte bien plus vite');break}
  case O.ROCK:{
   const pt=pickT();
   if(pt===0){if(Math.random()<0.5){gather(i,'pierre',1)}else{P.cd=0.4;P.swing=0.22;msg('Des cailloux… une pioche en bois serait plus efficace')}break}
   gather(i,'pierre',[0,2,3,4][pt]);
   if(pt>=2&&Math.random()<(pt===2?0.35:0.6)){add('minerai',1);pop(P.x,P.y-8,'+1 minerai de fer','#e0a060')}
   break}
  case O.BUSH:{
   if(hv(x,y,6)<.5)gather(i,'baies',2);
   else{gather(i,'bois',1);if(Math.random()<0.35){const sd=rndSeed();add(sd,1);pop(P.x,P.y-8,'+1 '+items[sd].toLowerCase(),'#cfe')}}
   break}
  case O.RUIN:{gather(i,'ferraille',1);if(Math.random()<0.15){add('tissu',1);pop(P.x,P.y-8,'+1 tissu','#ddd')}break}
  case O.CRATE:case O.BARREL:setObj(i,0);hpm.delete(i);P.cd=0.4;lootCrate();break;
  case O.CAR:{setObj(i,0);P.cd=0.5;const n=3+Math.floor(Math.random()*4);add('ferraille',n);let s='+'+n+' ferraille';if(Math.random()<0.4){add('metal',1);s+=' +1 lingot'}if(Math.random()<0.3){add('munitions',4);s+=' +4 mun.'}if(Math.random()<0.4){add('tissu',2);s+=' +2 tissu'}pop(P.x,P.y,s,'#ffd36a');msg('Épave fouillée : '+s);break}
  case O.CAB:{if(lv)break;setObj(i,O.CABO);P.cd=0.4;lootCabinet();break}
  case O.CABO:msg('Cette armoire est vide');P.cd=0.4;break;
  case O.TABLE:msg('Une table');P.cd=0.4;break;
  case O.CHAIR:msg('Tu t\'assois un instant…');P.cd=0.6;break;
  case O.SOFA:msg('Un canapé confortable');P.cd=0.6;break;
  case O.SHELF:msg('Une étagère');P.cd=0.4;break;
  case O.LAMP:msg('Une lampe');P.cd=0.4;break;
  case O.BED:{P.cd=0.8;if(dayLight()<0.4&&!nearestZ(P.x,P.y,500)){D=0.8;P.hp=Math.min(100,P.hp+25);msg('Tu dors jusqu\'au matin…');saveGame(true)}else msg(dayLight()<0.4?'Trop de zombies près d\'ici pour dormir':'Tu n\'as pas sommeil (dors la nuit)');break}
  case O.DOORC:if(lv)setObj2(i,O.DOORO);else setObj(i,O.DOORO);P.cd=0.35;break;
  case O.DOORO:if(lv)setObj2(i,O.DOORC);else setObj(i,O.DOORC);P.cd=0.35;break;
  case O.BENCH:case O.FURN:case O.ANVIL:case O.GUNB:case O.STOVE:case O.MILL:case O.FIRE:openMenu('fab');P.cd=0.3;break;
  case O.FIELD:{
   const c=sty[i];
   if(c===0){
    const k=[1,2,3].find(k=>P.inv[CROPS[k].seed]>0);
    if(!k){msg('Champ vide : trouve des graines (buissons, armoires, caisses)');P.cd=0.4;break}
    P.inv[CROPS[k].seed]--;sty[i]=k;gro[i]=1;dirty=true;if(fields.indexOf(i)<0)fields.push(i);pop(P.x,P.y,'Planté : '+CROPS[k].n,'#9f9');P.cd=0.4;
   }else if(gro[i]>=250){
    const cr=CROPS[c],n=cr.lo+Math.floor(Math.random()*(cr.hi-cr.lo+1));
    add(cr.yield,n);if(Math.random()<0.7)add(cr.seed,1);sty[i]=0;gro[i]=0;dirty=true;P.cd=0.4;pop(P.x,P.y,'+'+n+' '+items[cr.yield].toLowerCase(),'#ffd36a');
   }else{msg(CROPS[c].n+' : '+Math.floor(gro[i]/2.5)+'% — protège le champ des zombies !');P.cd=0.4}
   break}
  case O.WINDOW:msg('Fenêtre : trop étroite pour passer');P.cd=0.4;break;
  default:msg('Menu → Construction → Démolir pour reprendre la structure');P.cd=0.4;
 }
}
function lootCrate(){
 const r=Math.random();let s;
 if(r<0.3){const n=2+Math.floor(Math.random()*5);add('ferraille',n);s='+'+n+' ferraille'}
 else if(r<0.45){add('conserve',1);s='+1 conserve'}
 else if(r<0.58){const n=4+Math.floor(Math.random()*5);add('munitions',n);s='+'+n+' munitions'}
 else if(r<0.66){add('bandage',1);s='+1 bandage'}
 else if(r<0.76){const n=2+Math.floor(Math.random()*3);add('tissu',n);s='+'+n+' tissu'}
 else if(r<0.86){const sd=rndSeed();add(sd,2);s='+2 '+items[sd].toLowerCase()}
 else if(r<0.95){const n=1+Math.floor(Math.random()*2);add('metal',n);s='+'+n+' lingot'}
 else if(!P.inv.pistolet){add('pistolet',1);s='PISTOLET trouvé !'}
 else{add('metal',2);s='+2 lingots'}
 pop(P.x,P.y,s,'#ffd36a');msg('Trouvé : '+s)
}
function lootCabinet(){
 const r=Math.random();let s;
 if(r<0.25){const n=1+Math.floor(Math.random()*2);add('conserve',n);s='+'+n+' conserve'}
 else if(r<0.4){add('bandage',2);s='+2 bandages'}
 else if(r<0.6){const n=2+Math.floor(Math.random()*3);add('tissu',n);s='+'+n+' tissu'}
 else if(r<0.78){const sd=rndSeed();add(sd,2);s='+2 '+items[sd].toLowerCase()}
 else if(r<0.9){const n=2+Math.floor(Math.random()*3);add('ferraille',n);s='+'+n+' ferraille'}
 else{add('munitions',6);s='+6 munitions'}
 pop(P.x,P.y,s,'#ffd36a');msg('Armoire : '+s)
}
function ghostPos(){return{x:Math.floor((P.x+P.fx*T*1.2)/T),y:Math.floor((P.y+P.fy*T*1.2)/T)}}
function facingDir(){return Math.abs(P.fx)>Math.abs(P.fy)?(P.fx>0?1:3):(P.fy>0?2:0)}
function place(){
 const b=buildSel,g=ghostPos(),lv=P.lv;
 if(g.x<1||g.y<1||g.x>=W-1||g.y>=H-1)return;
 const i=g.y*W+g.x;
 if(b.req&&!P.inv[b.req]){msg('Il te faut '+TOOLN[b.req]+' pour construire ça');P.cd=0.4;return}
 if(tile[i]===1){msg('Impossible dans l\'eau');P.cd=0.3;return}
 if(!has(b.c)){msg('Il manque : '+costStr(b.c));P.cd=0.3;return}
 if(b.fl){
  if(lv){msg('Les sols du rez se posent depuis le rez');P.cd=0.3;return}
  if(flo[i]){msg('Il y a déjà un sol ici');P.cd=0.3;return}
  pay(b.c);flo[i]=b.fl;dirty=true;P.cd=0.25;return;
 }
 if(b.fl2){
  if(flo2[i]){msg('Il y a déjà un plancher d\'étage ici');P.cd=0.3;return}
  if(obj[i]===O.STAIRS){msg('Garde le trou au-dessus de l\'escalier');P.cd=0.3;return}
  pay(b.c);flo2[i]=b.fl2;dirty=true;P.cd=0.25;return;
 }
 if(b.ro){
  const v=(b.ro===1?1:2+facingDir())+(lv?8:0);
  if(roo[i]){msg('Il y a déjà un toit ici');P.cd=0.3;return}
  pay(b.c);roo[i]=v;dirty=true;P.cd=0.25;return;
 }
 if(b.o===O.STAIRS){
  if(lv||obj[i]||flo2[i]){msg('Emplacement impossible pour l\'escalier (rez, case libre et sans plancher au-dessus)');P.cd=0.3;return}
  pay(b.c);setObj(i,O.STAIRS,facingDir());P.cd=0.3;return;
 }
 if(b.o===O.FIELD){
  if(lv||obj[i]){msg('Emplacement occupé');P.cd=0.3;return}
  const t=tile[i];if(t!==0&&t!==4&&t!==6){msg('Il faut de l\'herbe ou de la terre');P.cd=0.3;return}
  pay(b.c);setObj(i,O.FIELD,0);gro[i]=0;fields.push(i);P.cd=0.3;return;
 }
 const A=lv?obj2:obj;
 if(lv&&!flo2[i]){msg('Pose d\'abord un plancher d\'étage ici');P.cd=0.3;return}
 if(A[i]||(!lv&&obj[i])){msg('Emplacement occupé');P.cd=0.3;return}
 if(Math.floor(P.x/T)===g.x&&Math.floor(P.y/T)===g.y&&b.o!==O.DOORC){msg('Tu es sur la case');P.cd=0.3;return}
 pay(b.c);
 if(lv)setObj2(i,b.o,b.s||0);else{setObj(i,b.o,b.s||0);hpm.delete(i);if(b.o===O.TURRET)turrets.push(i)}
 P.cd=0.25;
}
const DEMO=new Set([...DAMAGEABLE,18,19,20,21,30,31,32,33,27,28,29]);
function refundFor(o,s){
 if(o===O.FIELD)return{};
 for(const b of BUILD){if(b.o===o&&(b.s||0)===s){const r={};for(const k in b.c)if(!TOOLS.has(k))r[k]=Math.floor(b.c[k]/2);return r}}
 if(s===ST.WOOD)return{bois:1};if(s===ST.METAL)return{ferraille:1};return{pierre:1};
}
function demolish(){
 const g=ghostPos(),i=g.y*W+g.x;if(g.x<0||g.y<0||g.x>=W||g.y>=H)return;
 const lv=P.lv,A=lv?obj2:obj,Sx=lv?sty2:sty,t=A[i];
 if(t&&DEMO.has(t)){
  const r=refundFor(t,Sx[i]);for(const k in r)add(k,r[k]);
  if(lv)setObj2(i,0);else{setObj(i,0);hpm.delete(i);if(t===O.FIELD){gro[i]=0;sty[i]=0}}
  P.cd=0.3;msg('Structure démolie');return;
 }
 if(roo[i]&&((roo[i]>=8)===(lv===1))){roo[i]=0;add('bois',1);dirty=true;P.cd=0.3;msg('Toit retiré');return}
 if(lv){if(flo2[i]){flo2[i]=0;add('bois',1);dirty=true;P.cd=0.3;msg('Plancher d\'étage retiré');return}}
 else if(flo[i]){flo[i]=0;add('pierre',1);dirty=true;P.cd=0.3;msg('Sol retiré');return}
 msg('Rien à démolir ici');P.cd=0.3;
}

// =====================================================================
//  MENU EN JEU
// =====================================================================
function openMenu(tab){menuTab=tab;paused=true;renderMenu()}
function closeMenu(){menuTab=null;paused=false;$('menu').style.display='none'}
function renderMenu(){
 let h='<div class="tabs">';
 [['sac','Sac'],['fab','Fabrication'],['bld','Construction'],['sys','Pause']].forEach(a=>{h+='<b data-a="tab:'+a[0]+'" class="'+(menuTab===a[0]?'on':'')+'">'+a[1]+'</b>'});
 h+='<b data-a="close" style="margin-left:auto">Fermer ✕</b></div>';
 if(menuTab==='sac'){
  h+='<div class="sec" style="margin:6px 4px 2px">Armes</div>';
  for(const k in WPN){if(k!=='poing'&&!P.inv[k])continue;h+='<div class="row"><span>'+WPN[k].n+(WPN[k].gun?' <small>'+P.inv.munitions+' munitions</small>':'')+'</span><span class="go'+(P.w===k?' off':'')+'" data-a="eq:'+k+'">'+(P.w===k?'Équipée':'Équiper')+'</span></div>'}
  h+='<div class="sec" style="margin:10px 4px 2px">Outils</div>';
  let nt=0;for(const k of TOOLS)if(P.inv[k]){nt++;h+='<div class="row"><span>'+items[k]+'</span></div>'}
  if(!nt)h+='<div class="row"><small>Aucun outil — fabrique une hache et une pioche en bois (onglet Fabrication).</small></div>';
  h+='<div class="sec" style="margin:10px 4px 2px">Ressources & nourriture</div>';
  let any=false;
  for(const k in items){
   if(TOOLS.has(k)||WPN[k]||k==='munitions')continue;
   const n=P.inv[k]||0;if(!n)continue;any=true;
   let btn='';
   if(FOOD[k])btn='<span class="go" data-a="use:'+k+'">Manger</span>';
   else if(k==='bandage')btn='<span class="go" data-a="use:bandage">Soigner</span>';
   h+='<div class="row"><span>'+items[k]+' <b>x'+n+'</b></span>'+btn+'</div>';
  }
  if(P.inv.munitions)h+='<div class="row"><span>Munitions <b>x'+P.inv.munitions+'</b></span></div>';
  if(!any&&!P.inv.munitions)h+='<div class="row">Sac vide — récolte, fouille les maisons et la base militaire !</div>';
 }else if(menuTab==='fab'){
  h+='<div class="row"><small>Chaque recette demande son atelier à moins de 4 cases. Progression : mains → établi → four → forge → armurerie. Cuisine : feu, cuisinière, moulin.</small></div>';
  let lastSt='';
  REC.forEach(r=>{
   if(r.st!==lastSt){lastSt=r.st;h+='<div class="sec" style="margin:10px 4px 2px">'+STNAME[r.st]+(nearStn(r.st)?' ✓':' — atelier trop loin / non construit')+'</div>'}
   const owned=r.uniq&&P.inv[r.id]>0,ok=has(r.c)&&nearStn(r.st)&&!owned&&(!r.req||P.inv[r.req]);
   h+='<div class="row"><span>'+r.n+'<small class="'+(has(r.c)?'':'no')+'">'+costStr(r.c)+(r.req&&!P.inv[r.req]?' · requis : '+items[r.req]:'')+'</small></span><span class="go'+(ok?'':' off')+'" data-a="craft:'+r.id+'">'+(owned?'Possédé':'Fabriquer')+'</span></div>';
  });
 }else if(menuTab==='bld'){
  h+='<div class="row"><small>Choisis une pièce puis pose-la avec ACTION devant toi. À l\'étage (après un escalier), les murs et meubles se posent sur un plancher d\'étage. Portes : ACTION pour ouvrir/fermer. Toit en pente : le haut est du côté où tu regardes.</small></div>';
  for(const b of BUILD){
   if(b.cat)h+='<div class="sec" style="margin:10px 4px 2px">'+b.cat+'</div>';
   const lock=b.req&&!P.inv[b.req];
   h+='<div class="row"><span>'+b.n+'<small class="'+(has(b.c)?'':'no')+'">'+costStr(b.c)+(lock?' · requis : '+items[b.req]:'')+'</small></span><span class="go'+(lock?' off':'')+'" data-a="build:'+b.id+'">'+(lock?'Verrouillé':'Choisir')+'</span></div>';
  }
  h+='<div class="row"><span>Démolir<small>Retire la structure, le toit ou le sol devant toi (rend la moitié)</small></span><span class="go red" data-a="demo">Démolir</span></div>';
 }else if(menuTab==='sys'){
  h+='<div class="row"><span>Monde : <b>'+(cur?esc(cur.name):'')+'</b><small>Jour '+day+' — sauvegarde automatique toutes les 15 secondes</small></span></div>';
  h+='<div class="row"><span>Reprendre la partie</span><span class="go" data-a="close">Reprendre</span></div>';
  h+='<div class="row"><span>Vue<small>Première ou troisième personne</small></span><span class="go" data-a="view">'+(CFG.fp?'1ère personne':'3e personne')+'</span></div>';
  h+='<div class="row"><span>Qualité graphique<small>Bas = sans ombres ni herbe (téléphones modestes) · Élevé = ombres nettes, herbe, vent, haute résolution</small></span><span style="display:flex;gap:6px">'+['Bas','Moyen','Élevé'].map((n,k)=>'<span class="go'+(CFG.quality===k?' sel':' off')+'" data-a="q:'+k+'">'+n+'</span>').join('')+'</span></div>';
  h+='<div class="row"><span>Sauvegarder maintenant</span><span class="go" data-a="save">Sauvegarder</span></div>';
  h+='<div class="row"><span>Retour au menu principal<small>La partie est sauvegardée avant de quitter</small></span><span class="go red" data-a="exit">Quitter</span></div>';
 }
 const m=$('menu');m.innerHTML=h;m.style.display='block';
}
$('menu').addEventListener('click',e=>{
 const a=e.target.getAttribute&&e.target.getAttribute('data-a');if(!a)return;
 const [c,v]=a.split(':');
 if(c==='close'){closeMenu();return}
 if(c==='tab'){menuTab=v;renderMenu();return}
 if(c==='save'){saveGame(true);return}
 if(c==='exit'){exitToMenu();return}
 if(c==='view'){setView(!CFG.fp);renderMenu();return}
 if(c==='q'){CFG.quality=+v;saveCfg();applyQuality();renderMenu();return}
 if(c==='demo'){buildSel=BUILD[0];demo=true;closeMenu();showBbar();return}
 if(c==='eq'){P.w=(v==='poing'||P.inv[v]>0)?v:'poing';renderMenu();return}
 if(c==='use'){
  if(!P.inv[v])return;
  if(FOOD[v]){P.food=Math.min(100,P.food+FOOD[v][0]);P.water=Math.min(100,P.water+FOOD[v][1])}
  else if(v==='bandage'){if(P.hp>=100){msg('Déjà en pleine forme');return}P.hp=Math.min(100,P.hp+35)}
  P.inv[v]--;renderMenu();return}
 if(c==='craft'){
  const r=REC.find(x=>x.id===v);if(!r)return;
  if(!has(r.c)||!nearStn(r.st)||(r.uniq&&P.inv[r.id]>0)||(r.req&&!P.inv[r.req]))return;
  pay(r.c);for(const k in r.give)add(k,r.give[k]);
  if(WPN[r.id]&&r.id!=='poing')P.w=r.id;
  msg(r.n+' fabriqué');renderMenu();return}
 if(c==='build'){const b=BUILD.find(b=>b.id===v);if(b.req&&!P.inv[b.req])return;buildSel=b;demo=false;closeMenu();showBbar();return}
});
function showBbar(){
 const b=$('bbar');
 if(!buildSel){b.style.display='none';return}
 b.style.display='flex';$('bname').textContent=demo?'Démolition — ACTION pour détruire':buildSel.n+' — ACTION pour poser';
 $('bDem').className=demo?'on':'';
}
$('bDem').addEventListener('pointerdown',()=>{demo=!demo;showBbar()});
$('bQuit').addEventListener('pointerdown',()=>{buildSel=null;demo=false;showBbar()});
$('bMenu').addEventListener('pointerdown',()=>{if(dead||!inGame)return;openMenu('sac')});
$('bView').addEventListener('pointerdown',()=>{if(dead||!inGame||paused)return;setView(!CFG.fp)});
$('bWpn').addEventListener('pointerdown',()=>{if(dead||!inGame||paused)return;cycleWeapon()});
$('bResp').addEventListener('pointerdown',()=>{
 for(const k in P.inv)if(!TOOLS.has(k)&&!WPN[k])P.inv[k]=Math.floor(P.inv[k]/2);P.lv=0;
 P.x=SPAWN.x;P.y=SPAWN.y;P.hp=100;P.food=70;P.water=70;dead=false;$('dead').style.display='none';
 for(let k=zs.length-1;k>=0;k--){const z=zs[k];if(z.wild&&Math.hypot(z.x-P.x,z.y-P.y)<=600){if(z.m)scene.remove(z.m);zs.splice(k,1)}}
});

// =====================================================================
//  ENTREES TACTILES
// =====================================================================
let joy=null,look=null,actHeld=false;const keys={};
const touch=$('touch');
touch.addEventListener('pointerdown',e=>{
 if(paused||!inGame)return;
 try{touch.setPointerCapture(e.pointerId)}catch(_){}
 if(e.clientX<VWp*0.5&&!joy){joy={id:e.pointerId,ox:e.clientX,oy:e.clientY,x:e.clientX,y:e.clientY}}
 else if(!look){look={id:e.pointerId,x:e.clientX,y:e.clientY}}
});
touch.addEventListener('pointermove',e=>{
 if(joy&&joy.id===e.pointerId){joy.x=e.clientX;joy.y=e.clientY}
 else if(look&&look.id===e.pointerId){
  if(CFG.fp){camYaw-=(e.clientX-look.x)*0.006;fpPitch=clamp(fpPitch-(e.clientY-look.y)*0.005,-1.3,1.3)}
  else{camYaw-=(e.clientX-look.x)*0.008;camPitch=clamp(camPitch+(e.clientY-look.y)*0.004,0.5,1.25)}
  look.x=e.clientX;look.y=e.clientY}
});
const endP=e=>{if(joy&&joy.id===e.pointerId)joy=null;if(look&&look.id===e.pointerId)look=null};
touch.addEventListener('pointerup',endP);touch.addEventListener('pointercancel',endP);
const ba=$('bAct');
ba.addEventListener('pointerdown',e=>{actHeld=true;try{ba.setPointerCapture(e.pointerId)}catch(_){}});
ba.addEventListener('pointerup',()=>{actHeld=false});ba.addEventListener('pointercancel',()=>{actHeld=false});
addEventListener('keydown',e=>{if(e.target&&e.target.tagName==='INPUT')return;keys[e.key.toLowerCase()]=1;if(e.key===' ')actHeld=true});
addEventListener('keyup',e=>{keys[e.key.toLowerCase()]=0;if(e.key===' ')actHeld=false});
addEventListener('contextmenu',e=>e.preventDefault());

// =====================================================================
//  MONDES MULTIPLES + SAUVEGARDE v3
// =====================================================================
const WKEY='dz_worlds',SKEY='dz_w_';
function getWorlds(){try{const a=JSON.parse(localStorage.getItem(WKEY));return Array.isArray(a)?a:[]}catch(e){return[]}}
function setWorlds(a){try{localStorage.setItem(WKEY,JSON.stringify(a))}catch(e){}}
function b64of(a){let s='';for(let i=0;i<a.length;i+=8192)s+=String.fromCharCode.apply(null,a.subarray(i,i+8192));return btoa(s)}
function fromB64(str,a){const bin=atob(str);if(bin.length!==a.length)return false;for(let i=0;i<bin.length;i++)a[i]=bin.charCodeAt(i);return true}
function saveGame(manual){
 if(!inGame||dead||!cur)return;
 try{
  localStorage.setItem(SKEY+cur.id,JSON.stringify({v:4,p:{x:P.x,y:P.y,hp:P.hp,food:P.food,water:P.water,w:P.w,lv:P.lv},inv:P.inv,D,day,L:{obj:b64of(obj),sty:b64of(sty),flo:b64of(flo),roo:b64of(roo),obj2:b64of(obj2),sty2:b64of(sty2),flo2:b64of(flo2),gro:b64of(gro)}}));
  const ws=getWorlds(),w=ws.find(a=>a.id===cur.id);
  if(w){w.last=Date.now();w.day=day;setWorlds(ws);cur=w}
  const s=$('saved');s.textContent=manual?'Partie sauvegardée':'Sauvegardé';s.style.opacity=1;savedT=1.6;
 }catch(e){}
}
window.saveGame=()=>saveGame(false);
function loadSave(w){
 try{
  const s=localStorage.getItem(SKEY+w.id);if(!s)return 0;
  const o=JSON.parse(s);if(o.v!==3&&o.v!==4)return -1;
  Object.assign(P,{x:o.p.x,y:o.p.y,hp:Math.max(1,o.p.hp),food:o.p.food,water:o.p.water,w:WPN[o.p.w]?o.p.w:'poing'});
  for(const k in o.inv)P.inv[k]=o.inv[k];
  D=o.D;day=o.day;
  fromB64(o.L.obj,obj);fromB64(o.L.sty,sty);fromB64(o.L.flo,flo);fromB64(o.L.roo,roo);
  if(o.v===4){fromB64(o.L.obj2,obj2);fromB64(o.L.sty2,sty2);fromB64(o.L.flo2,flo2);fromB64(o.L.gro,gro);P.lv=o.p.lv|0}
  return 1;
 }catch(e){return 0}
}
document.addEventListener('visibilitychange',()=>{if(document.hidden)saveGame(false)});
addEventListener('pagehide',()=>saveGame(false));

// ---------- menu d'accueil ----------
let view='home';
function strSeed(s){let h=2166136261;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619)}return h|0}
function showView(v){
 view=v;
 for(const [id,k] of [['vMain','home'],['vWorlds','worlds'],['vNew','new'],['vChar','char'],['vOpts','opts']])$(id).classList.toggle('on',v===k);
 $('home').classList.toggle('charmode',v==='char');
 if(v==='home')renderHome();if(v==='worlds')renderWorlds();
 if(v==='new'){const n=getWorlds().length+1;$('nName').value='';$('nName').placeholder='Monde '+n;$('nSeed').value=''}
 if(v==='char'){initPreview();renderCharRows();refreshPreview()}
 if(v==='opts')renderOpts();
}
function fmtDate(t){if(!t)return'';const d=new Date(t);return d.toLocaleDateString('fr-FR',{day:'2-digit',month:'2-digit'})+' '+d.toLocaleTimeString('fr-FR',{hour:'2-digit',minute:'2-digit'})}
function lastWorld(){const ws=getWorlds();let b=null;for(const w of ws)if(!b||(w.last||0)>(b.last||0))b=w;return b}
function renderHome(){
 const lw=lastWorld(),n=getWorlds().length;
 $('hContinue').disabled=!lw;
 const a=$('hContinueSub');if(a)a.textContent=lw?(lw.name+' — Jour '+(lw.day||1)):'Aucune partie en cours';
 const b=$('hWorldsSub');if(b)b.textContent=n?(n+' monde'+(n>1?'s':'')):'';
}
function renderWorlds(){
 const ws=getWorlds().slice().sort((a,b)=>(b.last||0)-(a.last||0));
 let h='';
 if(!ws.length)h='<div class="empty">Aucun monde pour le moment. Crée ta première partie !</div>';
 ws.forEach(w=>{
  h+='<div class="wc"><div class="grow"><div class="nm">'+esc(w.name)+'</div><div class="mt">Jour '+(w.day||1)+' · '+fmtDate(w.last)+' · graine '+esc(w.seedLabel||w.seed)+'</div></div>'+
     '<button class="sm" data-w="'+w.id+'" data-k="play">Jouer</button><button class="sm x" data-w="'+w.id+'" data-k="del">✕</button></div>';
 });
 $('wlist').innerHTML=h;
}
$('wlist').addEventListener('click',e=>{
 const b=e.target.closest('button');if(!b)return;
 const id=b.getAttribute('data-w'),k=b.getAttribute('data-k');
 if(k==='play'){const w=getWorlds().find(a=>a.id===id);if(w)startWorld(w)}
 else if(k==='del'){
  if(b.classList.contains('sure')){
   setWorlds(getWorlds().filter(a=>a.id!==id));try{localStorage.removeItem(SKEY+id)}catch(_){}
   renderWorlds();
  }else{b.classList.add('sure');b.textContent='Supprimer ?';setTimeout(()=>{if(b.isConnected){b.classList.remove('sure');b.textContent='✕'}},3000)}
 }
});
$('hContinue').addEventListener('click',()=>{const w=lastWorld();if(w)startWorld(w)});
$('hNew').addEventListener('click',()=>showView('new'));
$('hWorlds').addEventListener('click',()=>showView('worlds'));
$('hChar').addEventListener('click',()=>showView('char'));
$('hOpts').addEventListener('click',()=>showView('opts'));
$('wNew').addEventListener('click',()=>showView('new'));
$('wBack').addEventListener('click',()=>showView('home'));
$('nBack').addEventListener('click',()=>showView('home'));
$('cDone').addEventListener('click',()=>showView('home'));
$('oDone').addEventListener('click',()=>showView('home'));
$('nGo').addEventListener('click',()=>{
 const ws=getWorlds();
 if(ws.length>=12){alert('12 mondes maximum. Supprime-en un pour en créer un nouveau.');return}
 const name=($('nName').value.trim()||('Monde '+(ws.length+1))).slice(0,20);
 const sl=$('nSeed').value.trim();
 const seed=sl?(/^-?\d{1,9}$/.test(sl)?parseInt(sl,10):strSeed(sl)):(((Math.random()*2147483647)^(Date.now()&0x7fffffff))|0);
 const w={id:'w'+Date.now().toString(36)+Math.floor(Math.random()*1296).toString(36),name,seed,seedLabel:sl||String(Math.abs(seed)%100000),created:Date.now(),last:Date.now(),day:1};
 ws.push(w);setWorlds(ws);startWorld(w);
});
function renderOpts(){document.querySelectorAll('#qChips .chip').forEach(c=>c.classList.toggle('on',+c.dataset.q===CFG.quality))}
$('qChips').addEventListener('click',e=>{const c=e.target.closest('.chip');if(!c)return;CFG.quality=+c.dataset.q;saveCfg();renderOpts()});
function exitToMenu(){
 saveGame(true);
 inGame=false;closeMenu();joy=null;look=null;actHeld=false;buildSel=null;showBbar();
 $('ui').style.display='none';$('xh').style.display='none';$('dead').style.display='none';$('home').style.display='flex';
 octx.clearRect(0,0,VWp,VHp);showView('home');
}
window.dzBack=()=>{
 if(inGame){
  if(menuTab){closeMenu();return true}
  if(buildSel){buildSel=null;demo=false;showBbar();return true}
  openMenu('sys');return true;
 }
 if(view!=='home'){showView(view==='new'&&getWorlds().length?'worlds':'home');return true}
 return false;
};

// ---------- personnalisation ----------
const pv={r:null,s:null,c:null,m:null,rot:0.5,drag:null};
function hex6(n){return '#'+('000000'+n.toString(16)).slice(-6)}
function renderCharRows(){
 const keys2=['skin','hair','hairCol','beard','hat','jacket','pants','pack','build'];let h='';
 for(const k of keys2){
  const o=CH.OPT[k],v=CFG.char[k];
  h+='<div class="crow"><div class="cl">'+o.label+'</div>';
  if(o.colors)h+='<div class="sw">'+o.colors.map((c,i)=>'<i data-c="'+k+':'+i+'" class="'+(v===i?'on':'')+'" style="background:'+hex6(c)+'"></i>').join('')+'</div>';
  else h+='<div class="ar"><b data-c="'+k+':-1">◀</b><span>'+o.names[v]+'</span><b data-c="'+k+':+1">▶</b></div>';
  h+='</div>';
 }
 $('charRows').innerHTML=h;
}
$('charRows').addEventListener('click',e=>{
 const t=e.target.closest('[data-c]');if(!t)return;
 const [k,v]=t.getAttribute('data-c').split(':'),o=CH.OPT[k];
 if(v==='-1'||v==='+1'){CFG.char[k]=(CFG.char[k]+(v==='+1'?1:-1)+o.n)%o.n}else CFG.char[k]=+v;
 saveCfg();renderCharRows();refreshPreview();if(pl)buildPlayerModel();
});
$('cRand').addEventListener('click',()=>{for(const k in CH.OPT)CFG.char[k]=Math.floor(Math.random()*CH.OPT[k].n);saveCfg();renderCharRows();refreshPreview();if(pl)buildPlayerModel()});
function initPreview(){
 if(pv.r)return;
 const c=$('pv');
 pv.r=new THREE.WebGLRenderer({canvas:c,antialias:true,alpha:true});
 pv.r.setPixelRatio(Math.min(window.devicePixelRatio||1,2));pv.r.outputEncoding=THREE.sRGBEncoding;pv.r.toneMapping=THREE.ACESFilmicToneMapping;
 pv.s=new THREE.Scene();pv.c=new THREE.PerspectiveCamera(28,1,0.1,30);pv.c.position.set(0,1.05,3.7);pv.c.lookAt(0,0.55,0);
 pv.s.add(new THREE.HemisphereLight(0xdde8ff,0x403428,1.1));
 const dl=new THREE.DirectionalLight(0xffe6c0,2.0);dl.position.set(2,3,3);pv.s.add(dl);
 const rim=new THREE.DirectionalLight(0xff4444,1.2);rim.position.set(-3,2,-2);pv.s.add(rim);
 const disc=new THREE.Mesh(new THREE.CylinderGeometry(0.62,0.66,0.06,40),new THREE.MeshPhongMaterial({color:0x1a1a1a,shininess:40}));disc.position.y=-0.03;pv.s.add(disc);
 const ring=new THREE.Mesh(new THREE.TorusGeometry(0.64,0.012,6,48),new THREE.MeshBasicMaterial({color:0xc4161c}));ring.rotation.x=Math.PI/2;ring.position.y=0.002;pv.s.add(ring);
 c.addEventListener('pointerdown',e=>{pv.drag={x:e.clientX,id:e.pointerId};try{c.setPointerCapture(e.pointerId)}catch(_){}});
 c.addEventListener('pointermove',e=>{if(pv.drag){pv.rot+=(e.clientX-pv.drag.x)*0.012;pv.drag.x=e.clientX}});
 const up=()=>{pv.drag=null};c.addEventListener('pointerup',up);c.addEventListener('pointercancel',up);
}
function refreshPreview(){
 if(!pv.r)return;
 if(pv.m)pv.s.remove(pv.m.root);
 pv.m=CH.build(CFG.char);pv.s.add(pv.m.root);pv.m.blob.visible=false;
 pv.m.armL.rotation.x=0.05;pv.m.armR.rotation.x=-0.05;
}
function renderPreview(dt){
 if(!pv.r||!pv.m)return;
 if(!pv.drag)pv.rot+=dt*0.5;
 pv.m.root.rotation.y=pv.rot;
 const t=performance.now()/1000;pv.m.body.position.y=Math.sin(t*1.6)*0.004;
 pv.r.render(pv.s,pv.c);
}

// =====================================================================
//  3D : SCENE
// =====================================================================
let renderer,scene,camera,hemi,sun,moon,torch,fireL,skyMesh,skyU,terrain,terrainTex,terrainCv,water,ghost3,matFlash,matBar,matBarBg,tracerGeo,tracerMats=[];
let windU=null,pl=null,pAng=0,roadMeshes=[],bRoofs=[],fires=[];
const INST={},dummy=new THREE.Object3D(),tmpC=new THREE.Color();dummy.rotation.order='YXZ';
let rbx=-999,rby=-999,hiddenRoo=new Set(),wasUnder=false;
const gray=v=>{const c=clamp(Math.round(v*255),0,255);return(c<<16)|(c<<8)|c};

function mkInst(key,geo,mat,max,shadow){
 const m=new THREE.InstancedMesh(geo,mat,max);
 m.instanceMatrix.setUsage(THREE.DynamicDrawUsage);m.setColorAt(0,tmpC.setRGB(1,1,1));m.instanceColor.setUsage(THREE.DynamicDrawUsage);
 m.count=0;m.frustumCulled=false;m.castShadow=!!shadow;m.receiveShadow=true;m.visible=false;scene.add(m);INST[key]={m,n:0,max};
}
function put(key,x,y,z,ry,sx,sy,sz,col,rx,rz){
 const I=INST[key];if(!I||I.n>=I.max)return;
 dummy.position.set(x,y,z);dummy.rotation.set(rx||0,ry||0,rz||0);dummy.scale.set(sx,sy,sz);dummy.updateMatrix();
 I.m.setMatrixAt(I.n,dummy.matrix);I.m.setColorAt(I.n,tmpC.setHex(col==null?0xffffff:col));I.n++;
}
function initInst(){
 MAT.vegS=new THREE.MeshLambertMaterial({vertexColors:true});M.allMats.push(MAT.vegS);
 for(let v=0;v<3;v++){mkInst('pine'+v,GEO.pine[v],MAT.veg,1500,true);mkInst('broad'+v,GEO.broad[v],MAT.veg,1500,true);mkInst('rock'+v,GEO.rock[v],MAT.vegS,800,true)}
 mkInst('dead',GEO.dead,MAT.veg,500,true);mkInst('bush0',GEO.bush[0],MAT.veg,1200,true);mkInst('bush1',GEO.bush[1],MAT.veg,1200,true);mkInst('rubble',GEO.rubble,MAT.vegS,1200,true);
 mkInst('crate',GEO.crate,MAT.vc,1500,true);mkInst('barrel',GEO.barrel,MAT.vc,800,true);mkInst('car',GEO.car,MAT.vc,500,true);
 mkInst('table',GEO.table,MAT.vc,500,true);mkInst('bed',GEO.bed,MAT.vc,500,true);mkInst('cab',GEO.cab,MAT.vc,700,true);mkInst('cabo',GEO.cabo,MAT.vc,700,true);
 mkInst('bench',GEO.bench,MAT.vc,200,true);mkInst('furn',GEO.furn,MAT.vc,200,true);mkInst('fire',GEO.fire,MAT.vc,200,false);mkInst('turret',GEO.turret,MAT.vc,200,true);mkInst('tower',GEO.tower,MAT.vc,100,true);
 mkInst('flame',GEO.flame,MAT.flame,200,false);mkInst('flame2',GEO.flame2,MAT.flame,200,false);mkInst('furnGlow',GEO.furnGlow,MAT.glow,200,false);mkInst('redlight',GEO.redlight,MAT.glow,200,false);
 mkInst('fpost',GEO.fpost,MAT.vc,2500,true);mkInst('fpanel',GEO.fpanel,MAT.fence,2500,false);mkInst('palis',GEO.palis,MAT.vc,2500,true);
 for(let s=0;s<6;s++){
  mkInst('wPlain'+s,GEO.wPlain,MAT.wall[s],3200,true);mkInst('wCenter'+s,GEO.wCenter,MAT.wall[s],1500,true);mkInst('wArm'+s,GEO.wArm,MAT.wall[s],2400,true);
  mkInst('wSill'+s,GEO.wSill,MAT.wall[s],1500,true);mkInst('wTop'+s,GEO.wTop,MAT.wall[s],1500,true);mkInst('wSide'+s,GEO.wSide,MAT.wall[s],3000,true);
  mkInst('dTop'+s,GEO.dTop,MAT.wall[s],700,true);mkInst('dSide'+s,GEO.dSide,MAT.wall[s],1400,true);
 }
 mkInst('sillTrim',GEO.sillTrim,MAT.trim,1500,true);mkInst('glass',GEO.glass,MAT.glass,1500,false);mkInst('frameH',GEO.frameH,MAT.trim,3000,false);mkInst('frameV',GEO.frameV,MAT.trim,3000,false);
 mkInst('doorLeaf',GEO.doorLeaf,MAT.door,900,true);
 mkInst('fl1',GEO.slab,MAT.floor[1],2500,false);mkInst('fl2',GEO.slab,MAT.floor[2],2500,false);mkInst('fl3',GEO.slab,MAT.floor[3],2500,false);
 mkInst('roofSlab',GEO.roofSlab,MAT.roofTile,1500,true);mkInst('roofSlope',GEO.roofSlope,MAT.roofTile,1500,true);
 mkInst('chimney',GEO.chimney,MAT.wall[2],200,true);
 mkInst('stairs',GEO.stairs,MAT.vc,300,true);mkInst('rail',GEO.rail,MAT.vc,1500,true);mkInst('chair',GEO.chair,MAT.vc,300,true);mkInst('sofa',GEO.sofa,MAT.vc,200,true);mkInst('shelf',GEO.shelf,MAT.vc,200,true);mkInst('lamp',GEO.lamp,MAT.vc,200,false);mkInst('lampGlow',GEO.lampGlow,MAT.glow,200,false);
 mkInst('anvil',GEO.anvil,MAT.vc,100,true);mkInst('anvilGlow',GEO.anvilGlow,MAT.glow,100,false);mkInst('gunb',GEO.gunb,MAT.vc,100,true);mkInst('stove',GEO.stove,MAT.vc,100,true);mkInst('mill',GEO.mill,MAT.vc,100,true);
 mkInst('soil',GEO.soil,MAT.veg,1500,false);for(let k=0;k<3;k++)mkInst('crop'+k,GEO.crop[k],MAT.veg,1500,false);mkInst('grass',GEO.grass,MAT.veg,5200,false);
}

// ---------- éléments dépendants du monde ----------
function tintOf(i,x,y){
 const bi=CO===obj?bAt[i]:0,base=bi?bTint[bi-1]:0xffffff,f=0.94+0.12*hv(x,y,11);
 const r=Math.min(255,((base>>16)&255)*f)|0,g=Math.min(255,((base>>8)&255)*f)|0,b=Math.min(255,(base&255)*f)|0;return(r<<16)|(g<<8)|b;
}
let CO=obj,CS=sty;const cW=(x,y)=>connW(CO,x,y),cF=(x,y)=>connF(CO,x,y);
function wallDirRy(x,y){
 const t=[[0,-1,0],[1,0,-Math.PI/2],[0,1,Math.PI],[-1,0,Math.PI/2]];
 for(const d of t){const o=CO[(y+d[1])*W+x+d[0]];if(WALLISH[o]===1)return d[2]}
 return hv(x,y,5)*6.28;
}
const BTINTS=[[0xffffff,0xe0c09a,0xc9a577,0xb8b8a8,0x9fb59a],[0xffffff,0xe8e0d0,0xd0d0d0],[0xffffff,0xf0d8c8,0xd8b0a0,0xe8c0a8],[0xffffff,0xe8e8e8,0xd0d4d8],[0xffffff,0xf3e2c0,0xd9e3d0,0xf0cfc0,0xcfdae6,0xf2e6a0],[0xffffff,0xc8d8d0,0xd8c8b0,0xb8c4d4]];
const CARC=[0xb02a2a,0x2a4a8a,0xcfcfcf,0x2a2a2a,0x8a6a2a,0x3a6a4a,0x7a7a7a],BARC=[0x2a5a8a,0x7a2a2a,0x3a6a3a,0x8a7a2a];
const WH=GEO.WH,tw=GEO.t;

function buildWall(o,x,y,i,y0){
 const s=CS[i],px=x+.5,pz=y+.5,col=tintOf(i,x,y);
 const nn=cW(x,y-1),ne=cW(x+1,y),ns=cW(x,y+1),nw=cW(x-1,y);
 const cx=(ne?1:0)+(nw?1:0),cz=(nn?1:0)+(ns?1:0);
 let axis=(cx>0&&cz===0)?0:(cz>0&&cx===0)?1:(cx===0&&cz===0)?0:2;
 if(axis===2&&o!==O.WALL)axis=cx>=cz?0:1;
 const ry=axis===1?Math.PI/2:0,c=Math.cos(ry),sn=Math.sin(ry);
 const off=(a)=>[a*c,-a*sn];
 if(o===O.WALL||o===O.RUIN){
  if(axis!==2)put('wPlain'+s,px,y0,pz,ry,1,1,1,col);
  else{
   put('wCenter'+s,px,y0,pz,0,1,1,1,col);
   const a=0.25+tw/4;
   if(ne)put('wArm'+s,px+a,y0,pz,0,1,1,1,col);if(nw)put('wArm'+s,px-a,y0,pz,0,1,1,1,col);
   if(nn)put('wArm'+s,px,y0,pz-a,Math.PI/2,1,1,1,col);if(ns)put('wArm'+s,px,y0,pz+a,Math.PI/2,1,1,1,col);
  }
  return;
 }
 if(o===O.WINDOW){
  put('wSill'+s,px,y0,pz,ry,1,1,1,col);put('wTop'+s,px,y0,pz,ry,1,1,1,col);
  const so=off(0.385);put('wSide'+s,px+so[0],y0,pz+so[1],ry,1,1,1,col);put('wSide'+s,px-so[0],y0,pz-so[1],ry,1,1,1,col);
  put('sillTrim',px,y0,pz,ry,1,1,1,0xe9e4d8);put('glass',px,y0,pz,ry,1,1,1,0xffffff);
  put('frameH',px,y0-0.3,pz,ry,1,1,1,0xeeeae0);put('frameH',px,y0+0.3,pz,ry,1,1,1,0xeeeae0);
  const fo=off(0.28);put('frameV',px+fo[0],y0,pz+fo[1],ry,1,1,1,0xeeeae0);put('frameV',px-fo[0],y0,pz-fo[1],ry,1,1,1,0xeeeae0);put('frameV',px,y0,pz,ry,1,1,1,0xeeeae0);
  return;
 }
 put('dTop'+s,px,y0,pz,ry,1,1,1,col);
 const so=off(0.425);put('dSide'+s,px+so[0],y0,pz+so[1],ry,1,1,1,col);put('dSide'+s,px-so[0],y0,pz-so[1],ry,1,1,1,col);
 const dc=s===ST.METAL?0x8a9490:[0xcaa070,0x7a4a2a,0x4a6a8a,0x8a3a2a][Math.floor(hv(x,y,12)*4)];
 const ho=off(-0.35);
 if(o===O.DOORC)put('doorLeaf',px+ho[0],y0,pz+ho[1],ry,1,1,1,dc);
 else put('doorLeaf',px+ho[0],y0,pz+ho[1],ry+(hv(x,y,13)<.5?1:-1)*Math.PI/2*0.95,1,1,1,dc);
}
function buildFence(x,y,i,y0){
 const s=CS[i],px=x+.5,pz=y+.5,nn=cF(x,y-1),ne=cF(x+1,y),ns=cF(x,y+1),nw=cF(x-1,y);
 const drawX=ne||nw||(!nn&&!ns),drawZ=nn||ns;
 if(s===ST.METAL){
  put('fpost',px,y0,pz,0,1,1,1,0xffffff);
  if(drawX){put('fpanel',px,y0,pz,0,1,1,1,0xffffff);put('fpost',px,y0,pz,0,1,1,1,0xffffff)}
  if(drawZ){put('fpanel',px,y0,pz,Math.PI/2,1,1,1,0xffffff);put('fpost',px,y0,pz,Math.PI/2,1,1,1,0xffffff)}
 }else{
  if(drawX)put('palis',px,y0,pz,0,1,1,1,0xffffff);
  if(drawZ)put('palis',px,y0,pz,Math.PI/2,1,1,1,0xffffff);
 }
}
function buildObj(o,x,y,i,y0){
 const px=x+.5,pz=y+.5,h1=hv(x,y,1),h2=hv(x,y,2),h3=hv(x,y,3);
 switch(o){
  case O.TREE:{
   const forest=tile[i]===6;let kind;
   if(h1<0.06)kind='dead';else if(forest?h1<0.78:h1<0.3)kind='pine'+Math.floor(h2*3);else kind='broad'+Math.floor(h2*3);
   const sc=0.85+0.5*h3;put(kind,px,y0,pz,h1*37%6.28,sc,sc*(0.9+0.2*h2),sc,gray(0.9+0.2*hv(x,y,4)));break}
  case O.ROCK:{const sc=0.8+0.8*h3;put('rock'+Math.floor(h2*3),px,y0,pz,h1*6.28,sc,sc*(0.8+0.5*h1),sc,0xffffff);break}
  case O.BUSH:put(hv(x,y,6)<.5?'bush1':'bush0',px,y0,pz,h1*6.28,0.9+0.3*h3,0.9+0.3*h3,0.9+0.3*h3,gray(0.92+0.15*h2));break;
  case O.RUIN:put('rubble',px,y0,pz,h1*6.28,1,1,1,0xffffff);break;
  case O.CRATE:put('crate',px,y0,pz,h1*3.14,1,1,1,gray(0.9+0.2*h2));break;
  case O.BARREL:put('barrel',px,y0,pz,0,1,1,1,BARC[Math.floor(h1*4)]);break;
  case O.CAR:{
   const rd=a=>a===4||a===5;
   const hz=rd(tile[i+1])||rd(tile[i-1]),vt=rd(tile[i+W])||rd(tile[i-W]);
   const ry=hz?0:vt?Math.PI/2:h1*3.14;put('car',px,y0,pz,ry+(h2-.5)*0.15,1,1,1,CARC[Math.floor(h3*7)]);break}
  case O.TABLE:put('table',px,y0,pz,wallDirRy(x,y),1,1,1,0xffffff);break;
  case O.BED:put('bed',px,y0,pz,wallDirRy(x,y),1,1,1,0xffffff);break;
  case O.CAB:put('cab',px,y0,pz,wallDirRy(x,y),1,1,1,0xffffff);break;
  case O.CABO:put('cabo',px,y0,pz,wallDirRy(x,y),1,1,1,0xffffff);break;
  case O.BENCH:put('bench',px,y0,pz,wallDirRy(x,y),1,1,1,0xffffff);break;
  case O.FURN:{const r=wallDirRy(x,y);put('furn',px,y0,pz,r,1,1,1,0xffffff);put('furnGlow',px,y0,pz,r,1,1,1,0xff8a20);break}
  case O.FIRE:put('fire',px,y0,pz,h1*6,1,1,1,0xffffff);put('flame',px,y0,pz,0,1,1,1,0xffffff);put('flame2',px,y0,pz,0,1,1,1,0xffe070);fires.push(px,y0,pz);break;
  case O.TURRET:put('turret',px,y0,pz,0,1,1,1,0xffffff);put('redlight',px,y0,pz,0,1,1,1,0xff3030);break;
  case O.TOWER:put('tower',px,y0,pz,Math.floor(h1*4)*Math.PI/2,1,1,1,0xffffff);break;
  case O.FENCE:buildFence(x,y,i,y0);break;
  case O.RAIL:{const nn=cF(x,y-1),ne=cF(x+1,y),ns=cF(x,y+1),nw=cF(x-1,y),dX=ne||nw||(!nn&&!ns),dZ=nn||ns;if(dX)put('rail',px,y0,pz,0,1,1,1,0xffffff);if(dZ)put('rail',px,y0,pz,Math.PI/2,1,1,1,0xffffff);break}
  case O.STAIRS:put('stairs',px,y0,pz,[0,-Math.PI/2,Math.PI,Math.PI/2][CS[i]&3],1,1,1,0xffffff);break;
  case O.CHAIR:put('chair',px,y0,pz,wallDirRy(x,y),1,1,1,0xffffff);break;
  case O.SOFA:put('sofa',px,y0,pz,wallDirRy(x,y),1,1,1,0xffffff);break;
  case O.SHELF:put('shelf',px,y0,pz,wallDirRy(x,y),1,1,1,0xffffff);break;
  case O.LAMP:put('lamp',px,y0,pz,0,1,1,1,0xffffff);put('lampGlow',px,y0,pz,0,1,1,1,0xffe9a0);break;
  case O.ANVIL:{const r=wallDirRy(x,y);put('anvil',px,y0,pz,r,1,1,1,0xffffff);put('anvilGlow',px,y0,pz,r,1,1,1,0xff7a20);break}
  case O.GUNB:put('gunb',px,y0,pz,wallDirRy(x,y),1,1,1,0xffffff);break;
  case O.STOVE:put('stove',px,y0,pz,wallDirRy(x,y),1,1,1,0xffffff);break;
  case O.MILL:put('mill',px,y0,pz,wallDirRy(x,y),1,1,1,0xffffff);break;
  case O.FIELD:{put('soil',px,y0,pz,0,1,1,1,0xffffff);const c=CS[i];if(c){const g=gro[i],st=g<90?0:g<220?1:2;put('crop'+st,px,y0+0.05,pz,hv(x,y,8)*6,1,1,1,CROPS[c].tint[st])}break}
  case O.WALL:case O.WINDOW:case O.DOORC:case O.DOORO:buildWall(o,x,y,i,y0);break;
 }
}
function computeHiddenRoo(tx,ty){
 hiddenRoo=new Set();if(CFG.fp||tx<0||ty<0||tx>=W||ty>=H)return;
 const s=ty*W+tx;if(!roo[s])return;
 const q=[s];hiddenRoo.add(s);
 for(let h=0;h<q.length&&q.length<900;h++){const i=q[h],x=i%W,y=(i/W)|0;for(const d of [[1,0],[-1,0],[0,1],[0,-1]]){const nx=x+d[0],ny=y+d[1];if(nx<0||ny<0||nx>=W||ny>=H)continue;const j=ny*W+nx;if(roo[j]&&!hiddenRoo.has(j)){hiddenRoo.add(j);q.push(j)}}}
}
function rebuild(){
 for(const k in INST)INST[k].n=0;fires.length=0;
 const cxT=Math.floor(P.x/T),cyT=Math.floor(P.y/T),R=RAD;
 computeHiddenRoo(cxT,cyT);
 const x0=Math.max(0,cxT-R),x1=Math.min(W-1,cxT+R),y0=Math.max(0,cyT-R),y1=Math.min(H-1,cyT+R);
 const ROOFA=Math.atan2(0.55,1),RY=[0,-Math.PI/2,Math.PI,Math.PI/2],ql=QUAL[CFG.quality];
 for(let y=y0;y<=y1;y++)for(let x=x0;x<=x1;x++){
  const i=y*W+x,o=obj[i],f=flo[i],r=roo[i],f2=flo2[i],o2=obj2[i];
  const hh=Wd.hAt(x,y);
  if(ql.grass&&tile[i]===0&&!o&&!f&&Math.abs(x-cxT)<=ql.gr&&Math.abs(y-cyT)<=ql.gr){
   for(let k=0;k<ql.grass;k++){const a=hv(x,y,20+k),b=hv(x,y,30+k);if(a<0.35)continue;put('grass',x+0.15+0.7*a,Wd.hSample(x+0.15+0.7*a,y+0.15+0.7*b),y+0.15+0.7*b,b*6.28,0.8+0.6*a,0.8+0.8*b,0.8+0.6*a,gray(0.82+0.3*hv(x,y,40+k)))}
  }
  if(!o&&!f&&!r&&!f2&&!o2)continue;
  CO=obj;CS=sty;
  if(f)put('fl'+f,x+.5,hh,y+.5,0,1,1,1,gray(0.95+0.1*hv(x,y,14)));
  if(o)buildObj(o,x,y,i,hh);
  if(f2)put('fl'+f2,x+.5,hh+WH,y+.5,0,1,1,1,gray(0.95+0.1*hv(x,y,15)));
  if(o2){CO=obj2;CS=sty2;buildObj(o2,x,y,i,hh+WH);CO=obj;CS=sty}
  if(r&&!hiddenRoo.has(i)){
   const up=r>=8,rv=r&7,yb=hh+WH*(up?2:1);
   if(rv===1)put('roofSlab',x+.5,yb,y+.5,0,1,1,1,0x8a5a3a);
   else put('roofSlope',x+.5,yb+0.28,y+.5,RY[rv-2],1,1,1,0x8a5a3a,ROOFA,0);
  }
 }
 for(const b of BLD){
  if(b.roof!=='gable'||!b.chim)continue;
  if(Math.abs(b.x-cxT)>R||Math.abs(b.y-cyT)>R)continue;
  put('chimney',b.chim.x,b.lvl+WH+b.chim.rise*0.5,b.chim.z,0,1,1,1,0xd8a898);
 }
 for(const k in INST){const I=INST[k];I.m.count=I.n;I.m.visible=I.n>0;I.m.instanceMatrix.needsUpdate=true;if(I.m.instanceColor)I.m.instanceColor.needsUpdate=true}
 rbx=cxT;rby=cyT;dirty=false;
}

// ---------- toits des bâtiments ----------
const roofMatCache={};
function roofMat(base,hex){const k=base===MAT.roofMetal?'m'+hex:'t'+hex;if(!roofMatCache[k]){const m=base.clone();m.color.setHex(hex);roofMatCache[k]=m;M.allMats.push(m)}return roofMatCache[k]}
let gableMats=[];
function buildBuildingRoofs(){
 for(const r of bRoofs){for(const m of r.meshes){scene.remove(m);m.geometry.dispose()}}
 bRoofs=[];
 if(!gableMats.length){for(let s=0;s<6;s++){const m=MAT.wall[s].clone();m.side=THREE.DoubleSide;gableMats.push(m);M.allMats.push(m)}}
 bAt.fill(0);bTint=[];
 BLD.forEach((b,bi)=>{
  const rr=Wd.mulberry(b.x*131+b.y*17+bi);const pal=BTINTS[b.style];bTint.push(pal[Math.floor(rr()*pal.length)]);
  for(let j=0;j<b.h;j++)for(let i=0;i<b.w;i++)bAt[(b.y+j)*W+b.x+i]=bi+1;
  b.chim=null;
  if(b.roof==='none')return;
  const base=b.lvl+WH,meshes=[];
  if(b.roof==='gable'){
   const g=M.roofGeo(b);
   const rm=new THREE.Mesh(g.roof,roofMat(b.style===ST.METAL?MAT.roofMetal:MAT.roofTile,b.col));rm.position.y=base;rm.castShadow=true;rm.receiveShadow=true;scene.add(rm);meshes.push(rm);
   const gm=new THREE.Mesh(g.gable,gableMats[b.style]);gm.position.y=base;gm.castShadow=true;scene.add(gm);gm.material.color.setHex(bTint[bi]);meshes.push(gm);
   if(b.style!==ST.METAL&&rr()<0.7){const t=0.25+rr()*0.5;b.chim=b.ridge===0?{x:b.x+0.5+(b.w-1)*t,z:b.y+b.h/2,rise:g.rise}:{x:b.x+b.w/2,z:b.y+0.5+(b.h-1)*t,rise:g.rise}}
  }else{
   const f=M.flatRoofGeo(b);
   const rm=new THREE.Mesh(f.slab,MAT.roofFlat);rm.position.y=base;rm.castShadow=true;rm.receiveShadow=true;scene.add(rm);meshes.push(rm);
   const pg=M.mergeGeo(f.parapet.map(g=>({g,c:0xffffff})));
   const pm=new THREE.Mesh(pg,MAT.wall[3===b.style||b.style===5?b.style:3]);pm.position.y=base;pm.castShadow=true;scene.add(pm);meshes.push(pm);
  }
  bRoofs.push({b,meshes});
 });
}
function updRoofVis(tx,ty){
 for(const r of bRoofs){
  const b=r.b,inside=tx>=b.x&&tx<b.x+b.w&&ty>=b.y&&ty<b.y+b.h,near=Math.abs(b.x-tx)<RAD+14&&Math.abs(b.y-ty)<RAD+14;
  const vis=(CFG.fp||!inside)&&near;for(const m of r.meshes)m.visible=vis;
 }
}

// ---------- terrain ----------
function paintTerrain(){
 const c=terrainCv.getContext('2d'),im=c.createImageData(W,H),d=im.data;
 for(let y=0;y<H;y++)for(let x=0;x<W;x++){
  const i=y*W+x,t=tile[i],n=Wd.vn(x,y,9),n2=Wd.vn(x+99,y+7,3),hh=Wd.hAt(x,y),jt=hv(x,y,9);
  let r,g,b;
  if(t===1){const dp=clamp(-hh/0.5,0,1);r=40-dp*22;g=105-dp*45;b=128-dp*28}
  else if(t===3){r=198;g=182;b=132;const k=0.92+0.14*n;r*=k;g*=k;b*=k}
  else if(t===4){r=134;g=106;b=74;const k=0.9+0.2*n;r*=k;g*=k;b*=k}
  else if(t===5){r=66;g=67;b=70}
  else if(t===2){r=124;g=124;b=122}
  else if(t===7){r=142;g=138;b=128}
  else if(t===6){r=50;g=78;b=34;const k=0.85+0.3*n;r*=k;g*=k;b*=k}
  else{const k=0.82+0.36*n,y2=0.8+0.4*n2;r=(76+(1-y2)*40)*k;g=(116+ y2*8)*k;b=(48+(1-y2)*10)*k}
  if(t!==1&&t!==5&&t!==2){const rocky=clamp((hh-0.75)/0.6,0,0.6);r+=(120-r)*rocky;g+=(116-g)*rocky;b+=(104-b)*rocky}
  const k2=0.95+0.1*jt,o=i*4;d[o]=clamp(r*k2,0,255);d[o+1]=clamp(g*k2,0,255);d[o+2]=clamp(b*k2,0,255);d[o+3]=255;
 }
 c.putImageData(im,0,0);terrainTex.needsUpdate=true;
}
function shapeTerrain(){
 const pos=terrain.geometry.attributes.position;
 for(let k=0;k<pos.count;k++)pos.setY(k,HM[k]);
 pos.needsUpdate=true;terrain.geometry.computeVertexNormals();terrain.geometry.computeBoundingSphere();
}
function buildRoads(){
 for(const r of roadMeshes){scene.remove(r);r.geometry.dispose()}roadMeshes=[];
 const mk=(tp,mat,uvs)=>{
  const pos=[],uv=[],idx=[];let o=0;
  for(let y=0;y<H;y++)for(let x=0;x<W;x++){
   if(tile[y*W+x]!==tp)continue;
   const a=HM[y*VW+x]+0.035,b=HM[y*VW+x+1]+0.035,c=HM[(y+1)*VW+x+1]+0.035,d=HM[(y+1)*VW+x]+0.035;
   pos.push(x,a,y,x+1,b,y,x+1,c,y+1,x,d,y+1);uv.push(x*uvs,y*uvs,(x+1)*uvs,y*uvs,(x+1)*uvs,(y+1)*uvs,x*uvs,(y+1)*uvs);idx.push(o,o+2,o+1,o,o+3,o+2);o+=4;
  }
  if(!o)return;
  const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(pos,3));g.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));g.setIndex(idx);g.computeVertexNormals();
  const m=new THREE.Mesh(g,mat);m.receiveShadow=true;scene.add(m);roadMeshes.push(m);
 };
 mk(5,MAT.asphalt,0.5);mk(2,MAT.pave,0.5);
}

// ---------- ciel ----------
function makeSky(){
 skyU={top:{value:new THREE.Color()},hor:{value:new THREE.Color()},sunDir:{value:new THREE.Vector3(0,1,0)},moonDir:{value:new THREE.Vector3(0,-1,0)},sunCol:{value:new THREE.Color()},night:{value:0},time:{value:0},cloudA:{value:0.6},cloudCol:{value:new THREE.Color()}};
 const mat=new THREE.ShaderMaterial({uniforms:skyU,side:THREE.BackSide,depthWrite:false,fog:false,
  vertexShader:'varying vec3 vDir;void main(){vDir=position;vec4 p=modelViewMatrix*vec4(position,1.0);gl_Position=projectionMatrix*p;}',
  fragmentShader:`varying vec3 vDir;uniform vec3 top,hor,sunDir,moonDir,sunCol,cloudCol;uniform float night,time,cloudA;
  float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
  float noise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(hash(i),hash(i+vec2(1,0)),f.x),mix(hash(i+vec2(0,1)),hash(i+vec2(1,1)),f.x),f.y);}
  float fbm(vec2 p){float v=0.,a=.5;for(int i=0;i<4;i++){v+=a*noise(p);p*=2.03;a*=.5;}return v;}
  void main(){
   vec3 d=normalize(vDir);float h=clamp(d.y,0.,1.);
   vec3 col=mix(hor,top,pow(h,0.5));
   float sd=max(dot(d,sunDir),0.);col+=sunCol*(pow(sd,700.)*4.0+pow(sd,10.)*0.22);
   float md=max(dot(d,moonDir),0.);col+=vec3(.75,.8,1.)*(pow(md,900.)*2.5+pow(md,20.)*0.08)*night;
   if(d.y>0.0){
    vec2 sp=d.xz/(d.y+0.35)*55.;float st=hash(floor(sp));col+=vec3(step(0.986,st)*(.35+.65*hash(floor(sp)+7.)))*night*smoothstep(0.0,.25,d.y);
    if(cloudA>0.01){vec2 cp=d.xz/(d.y+0.28)*1.7+vec2(time*0.012,time*0.004);float c=fbm(cp);c=smoothstep(.48,.82,c)*cloudA*smoothstep(.0,.22,d.y);
    col=mix(col,cloudCol,c*.88);}
   }
   gl_FragColor=vec4(col,1.0);
   #include <tonemapping_fragment>
   #include <encodings_fragment>
  }`});
 skyMesh=new THREE.Mesh(new THREE.SphereGeometry(70,24,16),mat);skyMesh.renderOrder=-10;skyMesh.frustumCulled=false;scene.add(skyMesh);
}
const cTop=new THREE.Color(),cHor=new THREE.Color(),cA=new THREE.Color(),cB=new THREE.Color();
const SK={dayTop:0x3f78d0,dayHor:0xa9c8e8,duskTop:0x3a4a80,duskHor:0xf0884a,nightTop:0x02040c,nightHor:0x0a1020};
function dayLight(){return 0.5+0.5*Math.cos(D*6.283185)}
function updEnv(px,py,pz,t){
 const th=D*6.283185,e=Math.cos(th);
 const sd=new THREE.Vector3(Math.sin(th)*0.85,e*0.95+0.02,0.4).normalize();
 const k=clamp((sd.y+0.08)/0.4,0,1),dusk=clamp(1-Math.abs(sd.y-0.04)/0.3,0,1);
 cTop.setHex(SK.nightTop).lerp(cA.setHex(SK.dayTop),k).lerp(cB.setHex(SK.duskTop),dusk*0.6);
 cHor.setHex(SK.nightHor).lerp(cA.setHex(SK.dayHor),k).lerp(cB.setHex(SK.duskHor),dusk*0.9);
 skyU.top.value.copy(cTop);skyU.hor.value.copy(cHor);skyU.sunDir.value.copy(sd);skyU.moonDir.value.copy(sd).multiplyScalar(-1);
 skyU.sunCol.value.setHex(dusk>0.3?0xff9a50:0xfff4d8);skyU.night.value=1-k;skyU.time.value=t;
 skyU.cloudCol.value.setHex(0xffffff).lerp(cA.setHex(0x151a2a),1-k).lerp(cB.setHex(0xffb890),dusk*0.6);
 skyMesh.position.set(camera.position.x,camera.position.y,camera.position.z);
 scene.fog.color.copy(cHor).lerp(cA.setHex(0x000000),0.05);scene.background=null;
 hemi.color.copy(cTop).lerp(cA.setHex(0xffffff),0.4);hemi.intensity=0.28+0.62*k;
 sun.color.setHex(dusk>0.3?0xffb070:0xfff0d6);sun.intensity=2.1*k*(1-dusk*0.35);
 sun.position.set(px+sd.x*45,py+sd.y*45,pz+sd.z*45);sun.target.position.set(px,py,pz);sun.target.updateMatrixWorld();
 moon.intensity=0.45*(1-k);moon.position.set(px-sd.x*30,py-sd.y*30+10,pz-sd.z*30);
 torch.intensity=(1-k)*2.2;torch.position.set(px,py+1.5,pz);
}

// ---------- initialisation 3D ----------
function init3D(){
 if(renderer)return;
 renderer=new THREE.WebGLRenderer({canvas:cv,antialias:false,powerPreference:'high-performance'});
 renderer.outputEncoding=THREE.sRGBEncoding;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.0;
 renderer.shadowMap.type=THREE.PCFSoftShadowMap;renderer.autoClear=false;
 scene=new THREE.Scene();scene.fog=new THREE.Fog(0xaabbcc,10,40);
 camera=new THREE.PerspectiveCamera(55,VWp/VHp,0.1,90);
 hemi=new THREE.HemisphereLight(0xcfe6ff,0x4a5a30,0.9);scene.add(hemi);
 sun=new THREE.DirectionalLight(0xfff0d6,2.0);scene.add(sun);scene.add(sun.target);
 const sc=sun.shadow.camera;sc.left=-26;sc.right=26;sc.top=26;sc.bottom=-26;sc.near=1;sc.far=130;sun.shadow.bias=-0.0006;sun.shadow.normalBias=0.04;
 moon=new THREE.DirectionalLight(0x6f86c8,0.0);scene.add(moon);
 torch=new THREE.PointLight(0xffd9a0,0,11,1.4);scene.add(torch);
 fireL=new THREE.PointLight(0xff8a30,0,9,1.6);scene.add(fireL);
 terrainCv=document.createElement('canvas');terrainCv.width=W;terrainCv.height=H;
 terrainTex=new THREE.CanvasTexture(terrainCv);terrainTex.encoding=THREE.sRGBEncoding;terrainTex.magFilter=THREE.LinearFilter;terrainTex.minFilter=THREE.LinearFilter;terrainTex.generateMipmaps=false;
 const tg=new THREE.PlaneGeometry(W,H,W,H);tg.rotateX(-Math.PI/2);tg.translate(W/2,0,H/2);
 const tm=new THREE.MeshLambertMaterial({map:terrainTex});M.allMats.push(tm);
 tm.onBeforeCompile=sh=>{
  sh.uniforms.det1={value:TEX.groundDetail};sh.uniforms.det2={value:TEX.groundDetail2};
  sh.fragmentShader=sh.fragmentShader.replace('#include <common>','#include <common>\nuniform sampler2D det1;uniform sampler2D det2;')
   .replace('#include <map_fragment>','#include <map_fragment>\n vec3 d1=texture2D(det1,vUv*'+(W/2.2).toFixed(2)+').rgb; vec3 d2=texture2D(det2,vUv*'+(W/13).toFixed(2)+').rgb; diffuseColor.rgb*=d1*d2*2.15;');
 };
 terrain=new THREE.Mesh(tg,tm);terrain.receiveShadow=true;scene.add(terrain);
 const wg=new THREE.PlaneGeometry(W,H);wg.rotateX(-Math.PI/2);wg.translate(W/2,-0.1,H/2);
 TEX.water.repeat.set(36,36);water=new THREE.Mesh(wg,MAT.water);scene.add(water);
 makeSky();initInst();
 ghost3=new THREE.Mesh(new THREE.BoxGeometry(1,1,1).translate(0,0.5,0),new THREE.MeshBasicMaterial({color:0x44ff44,transparent:true,opacity:0.35,depthWrite:false}));ghost3.visible=false;scene.add(ghost3);
 matFlash=new THREE.MeshBasicMaterial({color:0xffffff});
 matBar=new THREE.SpriteMaterial({color:0xee3333,depthTest:false});matBarBg=new THREE.SpriteMaterial({color:0x000000,depthTest:false,opacity:.7,transparent:true});
 tracerGeo=new THREE.BoxGeometry(1,1,1);tracerMats=[new THREE.MeshBasicMaterial({color:0xffe27a}),new THREE.MeshBasicMaterial({color:0xff5555})];
 windU={uTime:{value:0},uWind:{value:1}};
 MAT.veg.onBeforeCompile=sh=>{sh.uniforms.uTime=windU.uTime;sh.uniforms.uWind=windU.uWind;
  sh.vertexShader=sh.vertexShader.replace('#include <common>','#include <common>\nuniform float uTime;uniform float uWind;').replace('#include <begin_vertex>','#include <begin_vertex>\n#ifdef USE_INSTANCING\n float wph=instanceMatrix[3].x*0.9+instanceMatrix[3].z*0.7;float wvv=sin(uTime*1.6+wph)*0.05*uWind*clamp(position.y,0.0,2.5)*(0.6+0.4*sin(uTime*0.7+wph*1.3));transformed.x+=wvv;transformed.z+=wvv*0.6;\n#endif')};
 scene.add(camera);makeVM();
 buildPlayerModel();
 applyQuality();setView(CFG.fp);
}
function buildPlayerModel(){
 if(pl)scene.remove(pl.root);
 pl=CH.build(CFG.char);scene.add(pl.root);
}
function applyQuality(){
 const q=QUAL[CFG.quality];
 DPR=Math.min(window.devicePixelRatio||1,q.dpr);RAD=q.R;
 if(renderer){
  renderer.shadowMap.enabled=q.shadow;sun.castShadow=q.shadow;
  if(q.shadow){sun.shadow.mapSize.set(q.sm,q.sm);if(sun.shadow.map){sun.shadow.map.dispose();sun.shadow.map=null}}
  for(const m of M.allMats)m.needsUpdate=true;
  scene.fog.near=RAD*0.35;scene.fog.far=RAD+5;
  if(windU)windU.uWind.value=q.wind;if(skyU)skyU.cloudA.value=q.cloud?0.6:0;
  const an=Math.min(q.aniso,renderer.capabilities.getMaxAnisotropy());for(const k in TEX){const t=TEX[k];if(t&&t.isTexture&&t.anisotropy!==an){t.anisotropy=an;t.needsUpdate=true}}
  resize();dirty=true;
 }
}
function addTracer(x1,y1,z1,x2,y2,z2,ci){
 const dx=x2-x1,dy=y2-y1,dz=z2-z1,len=Math.hypot(dx,dy,dz)||.01;
 const m=new THREE.Mesh(tracerGeo,tracerMats[ci]);m.scale.set(.05,.05,len);m.position.set((x1+x2)/2,(y1+y2)/2,(z1+z2)/2);m.lookAt(x2,y2,z2);scene.add(m);fxs.push({m,t:.08});
}

// ---------- vue 1ère personne : bras + arme ----------
let vmScene,vmCam,vmRoot,vmArmR,vmArmL,vmW={},vmAmb,vmSun;
function makeVM(){
 vmScene=new THREE.Scene();vmCam=new THREE.PerspectiveCamera(60,VWp/VHp,0.02,5);
 vmAmb=new THREE.HemisphereLight(0xffffff,0x555555,1.0);vmScene.add(vmAmb);vmSun=new THREE.DirectionalLight(0xfff0d6,1.4);vmSun.position.set(0.5,1,0.6);vmScene.add(vmSun);
 const L=(c,sh)=>new THREE.MeshLambertMaterial({color:c});
 const skin=L(CH.SKIN[CFG.char.skin]),jk=L(CH.JACKET[CFG.char.jacket]),dark=L(0x242628),wood=L(0x7a5230),steel=L(0xa9b0b6),nail=L(0xcfcfcf);
 vmRoot=new THREE.Group();vmScene.add(vmRoot);
 const mk=(w,h,d,m,x,y,z,rx)=>{const b=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),m);b.position.set(x,y,z);if(rx)b.rotation.x=rx;return b};
 const arm=()=>{const g=new THREE.Group();g.add(mk(0.07,0.07,0.3,skin,0,0,-0.1));g.add(mk(0.095,0.095,0.34,jk,0,0.003,0.2));return g};
 vmArmR=arm();vmArmR.position.set(0.19,-0.25,-0.4);vmArmR.rotation.set(0.0,0.1,0);vmRoot.add(vmArmR);
 vmArmL=arm();vmArmL.position.set(-0.19,-0.27,-0.4);vmArmL.rotation.set(0.0,-0.1,0);vmRoot.add(vmArmL);
 const hand=new THREE.Group();hand.position.set(0,0.0,-0.3);vmArmR.add(hand);
 const w={};
 w.poing=new THREE.Group();w.poing.add(mk(0.08,0.08,0.08,skin,0,0,-0.02));
 w.batte=new THREE.Group();{const c=new THREE.Mesh(new THREE.CylinderGeometry(0.03,0.045,0.8,8),wood);c.rotation.x=Math.PI/2+0.35;c.position.set(0,0.2,-0.2);w.batte.add(c);for(let k=0;k<5;k++){const n=mk(0.012,0.012,0.04,nail,(k%2?0.04:-0.04),0.32+0.0*k,-0.45+k*0.0);n.position.set(k%2?0.04:-0.04,0.38-k*0.045,-0.38-k*0.02);w.batte.add(n)}}
 w.machette=new THREE.Group();w.machette.add(mk(0.03,0.04,0.12,dark,0,0,0));w.machette.add(mk(0.012,0.1,0.5,steel,0,0.02,-0.3));
 w.pistolet=new THREE.Group();w.pistolet.add(mk(0.05,0.1,0.12,dark,0,-0.03,0.02,-0.2));w.pistolet.add(mk(0.055,0.07,0.24,dark,0,0.04,-0.12));w.pistolet.add(mk(0.02,0.02,0.1,steel,0,0.045,-0.3));
 w.fusil=new THREE.Group();w.fusil.add(mk(0.06,0.09,0.55,dark,0,0.03,-0.3));w.fusil.add(mk(0.05,0.12,0.3,wood,0,-0.01,0.1));w.fusil.add(mk(0.025,0.025,0.4,steel,0,0.045,-0.7));w.fusil.add(mk(0.04,0.06,0.14,dark,0,-0.05,-0.2));
 for(const k in w){w[k].visible=false;hand.add(w[k])}
 vmW=w;
}
function updVM(tt,dt){
 vmCam.fov=camera.fov;vmCam.aspect=camera.aspect;vmCam.updateProjectionMatrix();
 vmAmb.intensity=0.35+hemi.intensity*0.85;vmSun.intensity=0.2+sun.intensity*0.45;
 for(const k in vmW)vmW[k].visible=(k===P.w);
 const mv=P.mv,bx=Math.sin(tt*10)*0.012*mv,by=Math.abs(Math.cos(tt*10))*0.012*mv;
 const sw=P.swing>0?P.swing/0.22:0,gun=WPN[P.w].gun;
 vmArmR.position.set(0.19+bx,-0.25-by+(sw&&!gun?0.04:0),-0.4+(gun?0.05*sw:0));
 vmArmR.rotation.set(0.0+(gun?0.25*sw:-0.9*sw*(P.w==='poing'?-0.4:1)),-0.1-(gun?0:0.4*sw),0);
 vmArmL.position.set(-0.19-bx,-0.27-by,-0.4);
 if(gun){vmArmL.position.set(P.w==='fusil'?-0.08:-0.18,-0.25,-0.5);vmArmL.rotation.set(0.1,P.w==='fusil'?0.55:0.35,0)}else vmArmL.rotation.set(0.0,-0.1,0);
}
function setView(fp){
 CFG.fp=!!fp;saveCfg();
 if(camera){camera.fov=CFG.fp?72:55;camera.near=CFG.fp?0.04:0.1;camera.rotation.order=CFG.fp?'YXZ':'XYZ';camera.updateProjectionMatrix();if(pl)pl.root.visible=!CFG.fp}
 $('xh').style.display=CFG.fp&&inGame?'block':'none';
 if(CFG.fp){P.fx=-Math.sin(camYaw);P.fy=-Math.cos(camYaw)}
 dirty=true;
}
const WORDER=['poing','batte','machette','pistolet','fusil'];
function cycleWeapon(){
 const own=WORDER.filter(k=>k==='poing'||P.inv[k]>0);let i=own.indexOf(P.w);P.w=own[(i+1)%own.length];msg('Arme : '+WPN[P.w].n);
}

// ---------- zombies (rendu) ----------
function makeZ(z){
 const t=ZT[z.type],o=CH.zombie(z.type,z.var,t.sc);z.o=o;z.m=o.root;
 const bg=new THREE.Sprite(matBarBg),fg=new THREE.Sprite(matBar);bg.scale.set(.7,.09,1);fg.scale.set(.66,.06,1);fg.center.set(0,.5);
 const by=1.2*t.sc+.25;bg.position.set(0,by,0);fg.position.set(-.33,by,0);bg.visible=fg.visible=false;o.root.add(bg);o.root.add(fg);
 z.bg=bg;z.fg=fg;z.w=.66;scene.add(z.m);
}

// =====================================================================
//  BOUCLE
// =====================================================================
function resize(){
 VWp=innerWidth;VHp=innerHeight;
 document.documentElement.style.setProperty('--u',clamp(Math.min(VHp/360,VWp/700),0.75,1.7).toFixed(3));
 const q=QUAL[CFG.quality];DPR=Math.min(window.devicePixelRatio||1,q.dpr);
 ov.width=Math.round(VWp*DPR);ov.height=Math.round(VHp*DPR);
 if(renderer){renderer.setPixelRatio(DPR);renderer.setSize(VWp,VHp,false);camera.aspect=VWp/VHp;camera.updateProjectionMatrix()}
 $('ov').style.imageRendering='auto';
}
resize();addEventListener('resize',resize);

const mmBuf=document.createElement('canvas');mmBuf.width=W;mmBuf.height=H;
function drawMM(){
 const g=mmBuf.getContext('2d'),im=g.createImageData(W,H),d=im.data;
 for(let i=0;i<W*H;i++){
  let c=[58,95,42];const t=tile[i];
  if(t===1)c=[42,93,138];else if(t===3)c=[190,176,130];else if(t===2)c=[120,122,124];else if(t===4)c=[134,106,74];else if(t===5)c=[70,70,74];else if(t===6)c=[38,66,30];
  const o=obj[i];
  if(o===1)c=[28,64,28];else if(o===6||o===12||o===14||o===15)c=[200,70,70];else if(o===7||o===16)c=[160,160,170];else if(o===5||o===20)c=[236,176,44];else if((o>=8&&o<=11)||(o>=23&&o<=26))c=[240,150,60];else if(o===27)c=[196,168,60];else if(o===28)c=[150,110,70];
  d[i*4]=c[0];d[i*4+1]=c[1];d[i*4+2]=c[2];d[i*4+3]=255;
 }
 g.putImageData(im,0,0);mmDirty=false;
}
function drawMiniOverlay(){
 mx.imageSmoothingEnabled=false;mx.drawImage(mmBuf,0,0,W,H,0,0,100,100);
 const k=100/W;
 mx.fillStyle='#f33';for(const z of zs){if(!z.dead&&Math.hypot(z.x-P.x,z.y-P.y)<500)mx.fillRect(z.x/T*k-1,z.y/T*k-1,2,2)}
 mx.fillStyle='#4af';mx.fillRect(P.x/T*k-2,P.y/T*k-2,4,4);
}
const vec=new THREE.Vector3();
function renderFrame(now,dt){
 const tt=now/1000;
 P.h+=(hLevel(P.x,P.y,P.lv)-P.h)*Math.min(1,dt*14);
 const px=P.x*S,pz=P.y*S,py=P.h;
 const tx=Math.floor(P.x/T),ty=Math.floor(P.y/T);
 const under=roo[ty*W+tx]>0;
 if(!CFG.fp&&(under!==wasUnder||(under&&!hiddenRoo.has(ty*W+tx)))){dirty=true;wasUnder=under}
 if(dirty||Math.abs(tx-rbx)>4||Math.abs(ty-rby)>4)rebuild();
 updRoofVis(tx,ty);
 if(CFG.fp){
  camera.position.set(px,py+EYE+Math.sin(tt*10)*0.03*P.mv,pz);camera.rotation.set(fpPitch,camYaw,0);
 }else{
  camera.position.set(px+Math.sin(camYaw)*Math.cos(camPitch)*CD,py+0.7+Math.sin(camPitch)*CD,pz+Math.cos(camYaw)*Math.cos(camPitch)*CD);
  const gh=Wd.hSample(camera.position.x,camera.position.z)+0.6+(P.lv?WH:0);if(camera.position.y<gh)camera.position.y=gh;
  camera.lookAt(px,py+0.6,pz);
 }
 pl.root.visible=!CFG.fp;
 updEnv(px,py,pz,tt);
 if(windU)windU.uTime.value=tt;water.position.y=0;TEX.water.offset.set(tt*0.012,tt*0.008);
 MAT.flame.color.setRGB(.9+.1*Math.sin(tt*14),.75+.2*Math.sin(tt*11+1),.55+.25*Math.sin(tt*17+2));
 let bf=-1,bd=1e9;for(let k=0;k<fires.length;k+=3){const d=(fires[k]-px)**2+(fires[k+2]-pz)**2;if(d<bd){bd=d;bf=k}}
 if(bf>=0&&bd<900){fireL.position.set(fires[bf],fires[bf+1]+0.7,fires[bf+2]);fireL.intensity=1.6+.6*Math.sin(tt*13)}else fireL.intensity=0;
 pl.root.position.set(px,py,pz);
 const ta=Math.atan2(P.fx,P.fy);let da=ta-pAng;while(da>Math.PI)da-=6.2832;while(da<-Math.PI)da+=6.2832;pAng+=da*Math.min(1,dt*14);
 pl.body.rotation.y=pAng;
 const sw=Math.sin(tt*10)*0.7*P.mv;
 pl.legL.rotation.x=sw;pl.legR.rotation.x=-sw;pl.armL.rotation.x=-sw*.8;
 pl.armR.rotation.x=P.swing>0?-1.7+(P.swing/0.22)*1.3:(WPN[P.w].gun?-1.3:sw*.8);
 pl.bat.visible=P.w==='batte'||P.w==='machette';pl.pistol.visible=P.w==='pistolet'||P.w==='fusil';
 pl.body.position.y=Math.abs(Math.sin(tt*10))*0.02*P.mv;
 MAT.vc.emissive.setHex(P.hurt>0?0x551111:0x000000);
 if(buildSel){
  const g=ghostPos(),b=buildSel,gx=g.x+.5,gz=g.y+.5,hh=Wd.hAt(g.x,g.y)+(P.lv&&!b.fl2&&!b.ro?WH:0);
  ghost3.visible=true;ghost3.material.color.setHex(demo?0xff4444:0x44ff44);
  ghost3.rotation.set(0,0,0);
  if(b.fl){ghost3.position.set(gx,hh,gz);ghost3.scale.set(1,0.08,1)}
  else if(b.fl2){ghost3.position.set(gx,hh+WH,gz);ghost3.scale.set(1,0.08,1)}
  else if(b.ro){ghost3.position.set(gx,hh+WH*(1+P.lv),gz);ghost3.scale.set(1,0.12,1)}
  else{ghost3.position.set(gx,hh,gz);
   if(b.o===O.WALL||b.o===O.WINDOW||b.o===O.DOORC){ghost3.scale.set(1,WH,0.5);const f=facingDir();ghost3.rotation.y=(f===1||f===3)?Math.PI/2:0}
   else if(b.o===O.STAIRS)ghost3.scale.set(0.9,WH,0.9);else ghost3.scale.set(0.9,b.o===O.FENCE||b.o===O.RAIL?0.9:0.8,0.9)}
  if(demo){ghost3.rotation.set(0,0,0);ghost3.scale.set(1,1,1)}
 }else ghost3.visible=false;
 const lim=(RAD*T)*(RAD*T);
 for(const z of zs){
  const dxp=z.x-P.x,dyp=z.y-P.y,d2=dxp*dxp+dyp*dyp,near=d2<lim;
  if(!z.m){if(!near)continue;makeZ(z)}
  z.m.visible=near;if(!near)continue;
  const u=z.o;
  z.hh+=(hP(z.x,z.y)-z.hh)*Math.min(1,dt*10);
  z.m.position.set(z.x*S,z.hh,z.y*S);
  if(d2<350*350)z.ang=Math.atan2(-dxp,-dyp);else if(z.wx||z.wy)z.ang=Math.atan2(z.wx,z.wy);
  u.body.rotation.y=z.ang;
  const moving=d2<350*350||(z.wx||z.wy);
  z.ph+=dt*z.sp*0.11*(moving?1:0.2);
  const s=Math.sin(z.ph)*0.6;
  u.legL.rotation.x=s;u.legR.rotation.x=-s;u.armL.rotation.x=-1.4+Math.sin(z.ph*.7)*.15;u.armR.rotation.x=-1.4-Math.sin(z.ph*.7)*.15;
  u.body.rotation.z=Math.sin(z.ph)*0.05;
  const fl=z.flash>0;if(fl!==z.fl){z.fl=fl;for(const p of u.parts)p.material=fl?matFlash:MAT.vc}
  const hb=z.hp<z.mhp;z.bg.visible=z.fg.visible=hb;if(hb)z.fg.scale.x=z.w*Math.max(0,z.hp/z.mhp);
 }
 for(let k=fxs.length-1;k>=0;k--){fxs[k].t-=dt;if(fxs[k].t<=0){scene.remove(fxs[k].m);fxs.splice(k,1)}}
 renderer.clear();renderer.render(scene,camera);
 if(CFG.fp){updVM(tt,dt);renderer.clearDepth();renderer.render(vmScene,vmCam)}
 octx.setTransform(DPR,0,0,DPR,0,0);octx.clearRect(0,0,VWp,VHp);
 octx.font='bold 13px sans-serif';octx.textAlign='center';octx.lineWidth=3;octx.strokeStyle='rgba(0,0,0,.8)';
 for(const t of txts){
  vec.set(t.x*S,py+1.2+(1-t.t)*0.9,t.y*S).project(camera);if(vec.z>1)continue;
  const sx=(vec.x*.5+.5)*VWp,sy=(-vec.y*.5+.5)*VHp;
  octx.globalAlpha=Math.max(0,t.t);octx.strokeText(t.s,sx,sy);octx.fillStyle=t.col;octx.fillText(t.s,sx,sy);
 }
 octx.globalAlpha=1;
 if(QUAL[CFG.quality].vig){const vg=octx.createRadialGradient(VWp/2,VHp/2,Math.min(VWp,VHp)*0.45,VWp/2,VHp/2,Math.max(VWp,VHp)*0.75);vg.addColorStop(0,'rgba(0,0,0,0)');vg.addColorStop(1,'rgba(0,0,0,0.38)');octx.fillStyle=vg;octx.fillRect(0,0,VWp,VHp)}
 if(P.hurt>0){octx.fillStyle='rgba(255,0,0,'+(P.hurt*0.8)+')';octx.fillRect(0,0,VWp,VHp)}
 if(joy){
  octx.strokeStyle='rgba(255,255,255,.5)';octx.lineWidth=3;octx.beginPath();octx.arc(joy.ox,joy.oy,50,0,6.283);octx.stroke();
  const dx=joy.x-joy.ox,dy=joy.y-joy.oy,l=Math.hypot(dx,dy),m=Math.min(l,50),kx=l?joy.ox+dx/l*m:joy.ox,ky=l?joy.oy+dy/l*m:joy.oy;
  octx.fillStyle='rgba(255,255,255,.4)';octx.beginPath();octx.arc(kx,ky,22,0,6.283);octx.fill();
 }
}
function hud(){
 $('bh').style.width=Math.max(0,P.hp)+'%';$('bf').style.width=Math.max(0,P.food)+'%';$('bw').style.width=Math.max(0,P.water)+'%';
 const tm=((D*24+12)%24),hh=Math.floor(tm),mi=Math.floor((tm-hh)*60);
 $('clock').textContent='Jour '+day+' — '+String(hh).padStart(2,'0')+'h'+String(mi).padStart(2,'0');
 const i=P.inv;$('res').textContent='Bois '+i.bois+' · Pierre '+i.pierre+' · Ferraille '+i.ferraille+' · Lingots '+i.metal+(i.munitions?' · Mun. '+i.munitions:'');
}
function update(dt){
 DT=dt;
 const night=dayLight()<0.38;
 D+=dt/300;if(D>=1){D-=1;day++}
 let vx=0,vy=0;
 if(joy){const dx=joy.x-joy.ox,dy=joy.y-joy.oy,l=Math.hypot(dx,dy);if(l>8){const m=Math.min(1,l/55);vx=dx/l*m;vy=dy/l*m}}
 if(keys['arrowleft']||keys['a']||keys['q'])vx-=1;if(keys['arrowright']||keys['d'])vx+=1;
 if(keys['arrowup']||keys['w']||keys['z'])vy-=1;if(keys['arrowdown']||keys['s'])vy+=1;
 if(keys['j'])camYaw+=dt*1.8;if(keys['l'])camYaw-=dt*1.8;
 const cy=Math.cos(camYaw),sy=Math.sin(camYaw);
 let wx=cy*vx+sy*vy,wz=-sy*vx+cy*vy;
 const ml=Math.hypot(wx,wz);P.mv=ml>0.1?1:0;
 if(ml>0.1){
  if(ml>1){wx/=ml;wz/=ml}
  const nl=Math.hypot(wx,wz);if(!CFG.fp){P.fx=wx/nl;P.fy=wz/nl}
  const sp=130*dt,i0=Math.floor(P.y/T)*W+Math.floor(P.x/T);
  if(canMove(P.x+wx*sp,P.y,9,P.lv))P.x+=wx*sp;
  if(canMove(P.x,P.y+wz*sp,9,P.lv))P.y+=wz*sp;
  const i1=Math.floor(P.y/T)*W+Math.floor(P.x/T);
  if(P.lv===1&&obj[i1]===O.STAIRS)P.lv=0;
  else if(P.lv===0&&i1!==i0&&obj[i0]===O.STAIRS&&flo2[i1]>0){const d=sty[i0]&3;if(i1===i0+DY4[d]*W+DX4[d])P.lv=1}
 }
 if(CFG.fp){P.fx=-Math.sin(camYaw);P.fy=-Math.cos(camYaw)}
 if(P.cd>0)P.cd-=dt;if(P.hurt>0)P.hurt-=dt;if(P.swing>0)P.swing-=dt;
 if(actHeld)act();
 P.food=Math.max(0,P.food-dt/7);P.water=Math.max(0,P.water-dt/5.5);
 if(P.food<=0||P.water<=0)P.hp-=dt*1.5;
 else if(P.hp<100&&P.food>40&&P.water>40)P.hp=Math.min(100,P.hp+dt*0.8);
 if(P.hp<=0){dead=true;P.mv=0;$('dead').style.display='flex';return}
 for(const z of zs){if(z.dead)continue;if(Math.abs(z.x-P.x)<900&&Math.abs(z.y-P.y)<900)updZ(z,dt,night)}
 zs=zs.filter(z=>{const keep=!z.dead&&!(z.wild&&Math.hypot(z.x-P.x,z.y-P.y)>1500);if(!keep&&z.m){scene.remove(z.m);z.m=null}return keep});
 spawnT-=dt;
 if(night&&spawnT<=0){
  spawnT=2.5;
  let near=0;for(const z of zs)if(z.wild)near++;
  if(near<16){
   for(let k=0;k<10;k++){
    const a=Math.random()*6.283,d=520+Math.random()*180,x=P.x+Math.cos(a)*d,y=P.y+Math.sin(a)*d;
    if(!solid(x,y)&&canMove(x,y,14)){zs.push(mkZ(x,y,pickType(true),true));break}
   }
  }
 }
 growT-=dt;
 if(growT<=0){growT=1;
  for(let k=fields.length-1;k>=0;k--){const i=fields[k];if(obj[i]!==O.FIELD){fields.splice(k,1);continue}
   if(sty[i]&&gro[i]<250){const o=gro[i],n=Math.min(250,o+(Math.random()<0.39?2:1));gro[i]=n;if((o<90)!==(n<90)||(o<220)!==(n<220)||n>=250&&o<250)dirty=true}}
  for(const [k,v] of trample){if(v<=0.4)trample.delete(k);else trample.set(k,v-0.4)}
 }
 for(const z of zs){if(z.dead)continue;const i=Math.floor(z.y/T)*W+Math.floor(z.x/T);if(obj[i]===O.FIELD&&sty[i]){const v=(trample.get(i)||0)+dt;if(v>2){sty[i]=0;gro[i]=0;trample.delete(i);dirty=true;if(Math.hypot(z.x-P.x,z.y-P.y)<700)msg('Des zombies ont piétiné ton champ !')}else trample.set(i,v)}}
 for(let k=turrets.length-1;k>=0;k--){
  const i=turrets[k];if(obj[i]!==O.TURRET){turrets.splice(k,1);continue}
  const tx=(i%W)*T+16,ty=Math.floor(i/W)*T+16;
  const cd=(tcd[i]||0)-dt;tcd[i]=cd;
  if(cd<=0){const z=nearestZ(tx,ty,230);if(z){addTracer(tx*S,.9+Wd.hAt(i%W,(i/W)|0),ty*S,z.x*S,z.hh+.5,z.y*S,1);z.hp-=14;z.flash=0.1;if(z.hp<=0&&!z.dead){z.dead=true;dropLoot(z)}tcd[i]=0.8}else tcd[i]=0.2}
 }
 for(let k=txts.length-1;k>=0;k--){txts[k].t-=dt*0.9;if(txts[k].t<=0)txts.splice(k,1)}
}

let last=performance.now();
function loop(now){
 let dt=(now-last)/1000;last=now;if(dt>0.05)dt=0.05;if(!(dt>0))dt=0.016;
 requestAnimationFrame(loop);
 if(!inGame){if(view==='char')renderPreview(dt);return}
 if(!paused&&!dead)update(dt);
 renderFrame(now,dt);
 hudT-=dt;if(hudT<=0){hudT=0.15;hud()}
 mmT-=dt;if(mmT<=0){mmT=0.25;if(mmDirty)drawMM();drawMiniOverlay()}
 hintT-=dt;if(hintT<=0){hintT=0.2;const g=(!buildSel&&!paused)?targetAt():null;$('hint').textContent=g?(g.t===-1?'Eau — ACTION pour boire':(NAMES[g.t]||'')):''}
 if(msgT>0){msgT-=dt;if(msgT<=0)$('msg').style.opacity=0}
 if(savedT>0){savedT-=dt;if(savedT<=0)$('saved').style.opacity=0}
 saveT-=dt;if(saveT<=0){saveT=15;saveGame(false)}
}

// =====================================================================
//  LANCEMENT D'UN MONDE
// =====================================================================
function startWorld(w){
 cur=w;$('loading').innerHTML='<div>GÉNÉRATION DU MONDE<i>...</i></div><div style="font-size:12px;letter-spacing:3px;color:#777;font-family:sans-serif">graine '+esc(w.seedLabel||w.seed)+'</div>';$('loading').style.display='flex';
 setTimeout(()=>{
  try{
   init3D();resize();
   clearZ();for(const f of fxs)scene.remove(f.m);fxs=[];txts=[];hpm.clear();for(const k in tcd)delete tcd[k];
   WRES=Wd.generate(w.seed|0);SPAWN=WRES.spawn;
   obj2.fill(0);sty2.fill(0);flo2.fill(0);gro.fill(0);trample.clear();fields=[];
   Object.assign(P,{x:SPAWN.x,y:SPAWN.y,hp:100,food:100,water:100,fx:0,fy:1,w:'poing',cd:0,hurt:0,swing:0,mv:0,lv:0});
   for(const k in P.inv)P.inv[k]=0;
   D=0.06;day=1;paused=false;dead=false;buildSel=null;demo=false;menuTab=null;spawnT=0;camYaw=0;camPitch=0.95;
   const lr=loadSave(w);
   for(let i=0;i<W*H;i++)if(obj[i]===O.FIELD)fields.push(i);
   P.h=hLevel(P.x,P.y,P.lv);if(CFG.fp){P.fx=-Math.sin(camYaw);P.fy=-Math.cos(camYaw)}
   shapeTerrain();paintTerrain();buildRoads();buildBuildingRoofs();
   rebuildTurrets();initZ();
   dirty=true;rbx=-999;wasUnder=false;drawMM();buildPlayerModel();
   inGame=true;last=performance.now();saveT=15;fpPitch=0;setView(CFG.fp);
   $('home').style.display='none';$('ui').style.display='block';$('dead').style.display='none';showBbar();
   hud();
   if(lr===1)msg('Partie chargée — '+w.name+' · Jour '+day);
   else if(lr===-1)msg('Ancienne sauvegarde incompatible : nouveau monde généré');
   else msg('Glisse à gauche pour bouger, à droite pour tourner la caméra · ACTION pour frapper / récolter / ouvrir');
   if(lr!==1)saveGame(false);
  }catch(e){
   console.error(e);
   $('loading').innerHTML='<div style="font-size:16px;letter-spacing:1px;text-align:center;padding:20px">Impossible de lancer la 3D (WebGL indisponible ?).<br><small>'+esc(e&&e.message||e)+'</small></div>';
   setTimeout(()=>{$('loading').style.display='none'},5000);return;
  }
  $('loading').style.display='none';
 },60);
}

showView('home');
requestAnimationFrame(loop);
window.__dz={obj2,flo2,sty2,gro,setView,fields:()=>fields,hLevel,cycleWeapon,P,zs:()=>zs,update,obj,sty,flo,roo,tile,act,startWorld,getWorlds,cur:()=>cur,saveGame,dayLight,setD:v=>{D=v},state:()=>({inGame,day,D,view,parts:Object.keys(INST).filter(k=>INST[k].n).map(k=>k+':'+INST[k].n)}),setCam:(y,p)=>{camYaw=y;camPitch=p},exitToMenu,showView,setObj,mkZ,addZ:z=>zs.push(z),WRES:()=>WRES,CFG,BUILD,setBuild:id=>{buildSel=BUILD.find(b=>b.id===id);demo=false;showBbar()},place,hP,solid};
})();
