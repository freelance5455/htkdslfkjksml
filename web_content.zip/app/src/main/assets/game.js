let canvas = document.getElementById("game");
let ctx = canvas.getContext("2d");

let planeY = 200;
let planeVelocity = 0;
let gravity = 0.35;
let jumpPower = -7.5;
let score = 0;
let best = localStorage.getItem("bestScore") || 0;
let gameSpeed = 2.2;
let playing = false;

let pipes = [];
let pipeTimer = 0;
let clouds = [
  { x: 50, y: 80 },
  { x: 280, y: 150 },
  { x: 180, y: 60 }
];

// الصوت
let audioCtx = null;
function playSound(freq, duration, type) {
  try {
    if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    let osc = audioCtx.createOscillator();
    let gain = audioCtx.createGain();
    osc.connect(gain);
    gain.connect(audioCtx.destination);
    osc.frequency.value = freq;
    osc.type = type || "sine";
    gain.gain.value = 0.15;
    osc.start();
    osc.stop(audioCtx.currentTime + duration);
  } catch(e) {}
}

function startGame() {
  planeY = 200;
  planeVelocity = 0;
  score = 0;
  pipes = [];
  pipeTimer = 0;
  gameSpeed = 2.2;
  playing = true;
  document.getElementById("score").innerText = "0 | أحسن: " + best;
}

function doJump() {
  if (playing) {
    planeVelocity = jumpPower;
    playSound(500, 0.1, "sine");
  }
}

canvas.addEventListener("click", doJump);
canvas.addEventListener("touchstart", function(e) {
  e.preventDefault();
  doJump();
});

function drawClouds() {
  ctx.fillStyle = "rgba(255,255,255,0.9)";
  for (let c of clouds) {
    ctx.beginPath();
    ctx.arc(c.x, c.y, 22, 0, Math.PI * 2);
    ctx.arc(c.x + 25, c.y, 28, 0, Math.PI * 2);
    ctx.arc(c.x + 50, c.y, 20, 0, Math.PI * 2);
    ctx.fill();
    c.x -= 0.5;
    if (c.x < -70) {
      c.x = 420;
      c.y = Math.random() * 200 + 30;
    }
  }
}

function drawPlane() {
  ctx.save();
  let angle = planeVelocity * 0.04;
  if (angle > 0.5) angle = 0.5;
  if (angle < -0.4) angle = -0.4;
  ctx.translate(95, planeY + 15);
  ctx.rotate(angle);
  ctx.fillStyle = "white";
  ctx.beginPath();
  ctx.moveTo(-28, 0);
  ctx.lineTo(28, -14);
  ctx.lineTo(12, 6);
  ctx.lineTo(28, 14);
  ctx.lineTo(-28, 0);
  ctx.closePath();
  ctx.fill();
  ctx.strokeStyle = "#BDBDBD";
  ctx.lineWidth = 1;
  ctx.stroke();
  ctx.fillStyle = "#EEEEEE";
  ctx.beginPath();
  ctx.moveTo(-28, 0);
  ctx.lineTo(28, -14);
  ctx.lineTo(12, 6);
  ctx.closePath();
  ctx.fill();
  ctx.fillStyle = "#FF4444";
  ctx.beginPath();
  ctx.moveTo(28, -14);
  ctx.lineTo(12, 6);
  ctx.lineTo(28, 14);
  ctx.closePath();
  ctx.fill();
  ctx.restore();
}

function drawPipes() {
  for (let i = 0; i < pipes.length; i++) {
    let p = pipes[i];
    ctx.fillStyle = "#2E7D32";
    ctx.fillRect(p.x, 0, 55, p.gap - 80);
    ctx.fillStyle = "#66BB6A";
    ctx.fillRect(p.x + 6, 0, 18, p.gap - 80);
    ctx.fillStyle = "#1B5E20";
    ctx.fillRect(p.x - 3, p.gap - 95, 61, 18);
    ctx.fillStyle = "#2E7D32";
    ctx.fillRect(p.x, p.gap + 80, 55, 500);
    ctx.fillStyle = "#66BB6A";
    ctx.fillRect(p.x + 6, p.gap + 80, 18, 500);
    ctx.fillStyle = "#1B5E20";
    ctx.fillRect(p.x - 3, p.gap + 80, 61, 18);
  }
}

function gameOver() {
  playing = false;
  if (score > best) {
    best = score;
    localStorage.setItem("bestScore", best);
  }
  playSound(150, 0.4, "sawtooth");
  setTimeout(function() {
    alert("خسرتي! النقاط: " + score + "\nأحسن نقطة: " + best);
  }, 100);
}

function draw() {
  let grad = ctx.createLinearGradient(0, 0, 0, 500);
  grad.addColorStop(0, "#29B6F6");
  grad.addColorStop(1, "#B3E5FC");
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 400, 500);
  drawClouds();
  if (playing) {
    planeVelocity += gravity;
    planeY += planeVelocity;
    pipeTimer++;
    if (pipeTimer > 110) {
      pipeTimer = 0;
      let gap = Math.random() * 180 + 120;
      pipes.push({ x: 400, gap: gap, counted: false });
    }
    for (let i = 0; i < pipes.length; i++) {
      let p = pipes[i];
      p.x -= gameSpeed;
      if (!p.counted && p.x + 55 < 95) {
        p.counted = true;
        score++;
        playSound(900, 0.15, "sine");
        if (score % 5 == 0) gameSpeed += 0.3;
        document.getElementById("score").innerText = score + " | أحسن: " + best;
      }
      if (p.x < 120 && p.x + 55 > 70) {
        if (planeY < p.gap - 80 || planeY + 30 > p.gap + 80) {
          gameOver();
        }
      }
    }
    pipes = pipes.filter(function(p) { return p.x > -60; });
    if (planeY > 470 || planeY < -20) {
      gameOver();
    }
  }
  drawPipes();
  drawPlane();
  if (!playing && score == 0 && pipes.length == 0) {
    ctx.fillStyle = "white";
    ctx.font = "bold 18px Arial";
    ctx.textAlign = "center";
    ctx.fillText("ورك على العب و بدا تلعب!", 200, 400);
  }
  requestAnimationFrame(draw);
}
draw();