# NOMIDMAN TRANS CO. LTD: Privacy Policy, Terms and Conditions, and Disclaimer

**DRAFT FOR REVIEW.** These drafts describe how the website and app work today. They must be checked by a qualified Ugandan lawyer, and by counsel in each other country where you operate, before publication. Items in [square brackets] need your decision or confirmation.

Website: https://nomidtrans.shop
Company: NOMIDMAN TRANS CO. LTD, Along Juba Rd, Jinja Camp, Lira City West, Lira City, Uganda. P.O. Box 332567, Lira.
Contact: [support e-mail on your domain, e.g. support@nomidtrans.shop] · Phone: +256 764 502 805 · Office hours: [confirm]

---

## Part 1: Privacy Policy

**Last updated:** [date]

### 1. Who we are
NOMIDMAN TRANS CO. LTD ("we", "us") runs the NOMIDMAN TRANS website and mobile app, which connect property and vehicle owners directly with buyers and renters in Uganda, Tanzania, Rwanda, Kenya, the Democratic Republic of Congo and South Sudan. We are the data controller for the personal information described here.

**Data Protection Officer / privacy contact:** [name and e-mail, e.g. privacy@nomidtrans.shop]

### 2. Information we collect

**From owners:**
- Full legal name, age, gender, nationality
- Identity document type and number. The number is stored in a protected form (a one-way hash) so that it cannot be read back in full.
- Phone number and e-mail address, which we verify with one-time codes
- Listing details, photos, and for vehicles the engine number, chassis number and number plate you choose to provide
- Payment records: amount, method, date and status. Card and mobile money details are handled by our payment providers, not by us.

**From customers:**
- Name, nationality and e-mail address
- Phone number, if you choose to add one
- Saved searches, liked and saved listings
- Identity document number, if requested at sign-up (stored as above)

**From everyone:**
- Technical information needed to run the service: device type, browser, and your session while signed in
- Views and contact counts on listings. Owners see these as totals, not as the names of the people involved.

We do not use advertising trackers or sell your information.

### 3. How we use your information
- To create and run your account, and to verify your phone and e-mail
- To publish listings and show them to visitors
- To process registration fees, subscriptions, boosts, referral credit and voluntary gifts
- To keep the service secure and prevent fraud, including checking for duplicate or fake accounts
- To send service messages such as verification codes, renewal reminders and payment receipts
- To meet legal, tax and regulatory obligations
- To answer complaints and support requests

### 4. Legal basis
We process information because it is needed to provide the service you request, to meet legal obligations, and where you have given consent (for example, when you choose to add a phone number or send us a message). Where we rely on consent, you may withdraw it at any time.

### 5. Who we share information with
We share information only as needed to run the service:
- **Payment providers** (for example Flutterwave and, where used, PESAPAL) to take and confirm payments
- **Messaging providers** (Postmark for e-mail codes, eSMS Africa for SMS codes)
- **Hosting and storage providers**, including Google Cloud for listing photos, that store our data on our behalf
- **Other users:** when you publish a listing, its details, photos and your public name are visible to visitors. Owner contact details are shown only to signed-in users who open a listing.
- **Authorities**, when the law requires it
- **A buyer or seller in a transaction**, only where you have agreed to it

### 6. Where your information is stored
- **Photos** of listings are stored on Google Cloud.
- **All other information** (accounts, listings, payment records and settings) is stored on our own servers located at [server location to confirm].
- Backups of this information are kept on the same servers for [30] days.

Some providers, including Google Cloud, may process information outside your country. We take steps to protect it when it is transferred.

### 7. How long we keep information
- Account information: while your account is active. When you close your account, your information is removed from our servers 30 days after closure, unless the law requires us to keep certain records longer
- Listings: visible while the owner's subscription is valid. Expired listings are removed 15 days after expiry unless renewed.
- Held registration payments that are not verified within 24 hours: refunded, and the record kept for [period] for accounting
- Payment records: [period, e.g. as required by tax law]
- Verification codes: expire within 10 minutes and are not kept in readable form
- Backups: kept for [30] days, then deleted. Closed-account information therefore leaves the live system after 30 days, and the backups within a further 30 days.

### 8. Security
We protect information with encryption in transit (https), protected storage of passwords and ID numbers, limits on sign-in attempts, two-step sign-in for administrators, and regular backups. No system is completely secure, and we cannot guarantee absolute security.

### 9. Your rights
Under the Data Protection and Privacy Act, 2019 of Uganda, and similar laws where you live, you may ask us to:
- Tell you what information we hold about you
- Correct inaccurate information
- Delete your information, where we do not need to keep it for legal reasons
- Restrict or object to certain uses
- Withdraw consent, and receive a copy of your information in a usable form

To make a request, write to [privacy e-mail]. We will respond within [30] days. You may also complain to the Personal Data Protection Office of Uganda, or to the data protection authority in your country.

### 10. Children
Our service is for people aged 18 and over. We do not knowingly collect information from children. If you believe a child has given us information, contact us and we will delete it.

### 11. Cookies and local storage
The website uses essential storage in your browser to remember your sign-in, language, theme, saved searches and preferences. It does not use advertising cookies. You can clear this storage from your browser settings, but some features will stop working.

### 12. Changes to this policy
We may update this policy. We will show the new date at the top and, for significant changes, tell you through the website or by e-mail.

---

## Part 2: Terms and Conditions

**Last updated:** [date]

By creating an account, listing a property or vehicle, making a payment, or using the website or app, you agree to these Terms. If you do not agree, do not use the service.

### 1. The service
NOMIDMAN TRANS is an online platform that lets owners advertise property and vehicles for sale or rent, and lets visitors find them and contact owners directly. We are not a broker, agent, estate agent, dealer, bank or party to any sale or rental agreement between users.

### 2. Eligibility and accounts
- You must be at least 18 years old and legally able to enter a contract.
- You must give accurate information, and keep it up to date.
- Owners must verify their phone and e-mail before a listing is published.
- You are responsible for keeping your password and codes private, and for all activity on your account.
- We may suspend or close accounts that give false information, breach these Terms, or are used for fraud.

### 3. Owners
Owners must:
- Own the property or vehicle, or have the owner's written authority to advertise it
- Describe it honestly, including its condition, price, terms, and any defects or legal limits, and upload only photos of that item
- Keep listings current, and remove them when they are sold or let
- Comply with all laws, including those on property, land, vehicles, taxes and consumer protection

**Fees and plans** (amounts in UGX unless stated; shown in your local currency for information):

| Item | Price | Notes |
|---|---|---|
| Registration (once) | UGX 20,000 | Paid before verification codes are sent |
| Budget plan | UGX 50,000 per 91 days | Up to 2 listings, 3 photos each |
| Economy plan | UGX 150,000 per 91 days | Up to 13 listings, 6 photos each |
| Premium plan | UGX 300,000 per 91 days | Up to 25 listings, 10 photos each |
| Boost | UGX [10,000] for 7 days | Places one listing at the top of search. [Confirm price] |

Prices may change. A change does not affect a plan you have already paid for until it ends. Listings remain visible while the subscription is valid. They are hidden at expiry and removed 15 days after expiry unless renewed.

### 4. Payments and refunds
- Payments are processed by our payment providers. We do not store full card or mobile money details.
- **Registration fee:** payment is held until your phone and e-mail are verified. If they are not verified within 24 hours, the payment is refunded.
- **Subscriptions and boosts:** [refund policy to confirm, e.g. non-refundable once the plan is active, except where the service was not provided or the law requires a refund].
- **Upgrade to List:** customers who pay to become owners follow the same 24-hour rule.
- Refunds, where due, are returned by the original method, or as agreed in writing. Processing may take [number] working days.
- Fees are charged in UGX. Local-currency amounts are shown for convenience and are approximate.

### 5. Referral credit
- Owners can share a referral link. Credit of UGX [2,000] (or the local equivalent) is given to the referring owner once the new owner has registered and taken a subscription plan.
- Credit can only be used against subscription plans. It cannot be withdrawn as cash, transferred, or exchanged.
- Unused credit expires after 12 months without use.
- Self-referrals and referrals that use false details are void. We may withdraw credit obtained by fraud.

### 6. Voluntary gifts
The "Show your appreciation" gift is optional and goes to our operations. It is not a payment for any service and is not refundable. Gifts from UGX 1,000 up to UGX 100,000 (the equivalent of two Budget subscriptions) are accepted.

### 7. Customers and visitors
- Visitors may browse without an account. Owner contact details are shown to signed-in users only.
- You must not use contact details to harass, spam, or misuse owners.
- You must check all property titles, vehicle records, identities and prices yourself before you pay anyone. Use the official government portals to check vehicle numbers.

### 8. Prohibited conduct
You must not:
- Post false, misleading, duplicate, offensive or illegal listings
- Advertise stolen, disputed, mortgaged or unlawfully obtained property or vehicles
- Use the service for fraud, money laundering, or scams
- Scrape, copy or overload the service, or try to bypass its security
- Impersonate another person or organisation
- Upload content you do not have the right to use

### 9. Listings and content
You keep ownership of what you post, but you give us a licence to host, display, copy and promote it on the website and app, and in our marketing, for as long as the listing is published. We may remove or hide any content that breaks these Terms, without notice.

### 10. Our rights
We may change, suspend or stop any part of the service, with reasonable notice where practical. We may remove listings and suspend accounts to protect users or meet legal duties.

### 11. Transactions between users
Any sale, purchase, rental or agreement you make with another user is between you and that user. We do not guarantee the quality, legality, title, condition or price of any property or vehicle, or that a user will perform. We are not responsible for losses from such dealings.

### 12. Limitation of liability
To the fullest extent the law allows, we are not liable for indirect, special or consequential loss, lost profit, lost opportunity, or loss caused by user content or third-party services. Our total liability to you will not exceed the fees you paid us in the [3] months before the claim.

### 13. Indemnity
You agree to indemnify us against claims arising from your listings, your use of the service, or your breach of these Terms.

### 14. Governing law and disputes
These Terms are governed by the laws of the Republic of Uganda. We will try to resolve disputes first through our complaints process. Any dispute not resolved this way will be decided by [the courts of Uganda, sitting at Lira / arbitration under the Uganda Arbitration and Conciliation Act, 2000]. Nothing here limits any consumer right you have under the law of your country.

### 15. Complaints
Send complaints to [support e-mail] with your name, contact details and reference number. We will acknowledge each complaint within [2] working days and aim to resolve it within [14] days.

### 16. General
If any part of these Terms is found invalid, the rest stays in force. These Terms and the Privacy Policy are the whole agreement between you and us on this subject. Our failure to enforce a right is not a waiver of it.

---

## Part 3: Disclaimer

**Last updated:** [date]

The information on NOMIDMAN TRANS is provided by owners and by the company "as is", for general information only.

1. **Listings are supplied by owners.** We check basic details but do not verify the accuracy of descriptions, photos, prices, titles, ownership, condition or legal status of any property or vehicle.
2. **Vehicle numbers are for your own checks.** Engine, chassis and number plate details are shown so you can check them on official government portals before buying. We do not search or confirm vehicle records.
3. **Prices and currency.** Prices are as stated by owners. Converted amounts in other currencies are approximate, based on indicative exchange rates, and may differ from your bank or payment provider's rates.
4. **Verify every piece of information on the site.** Get independent or legal advice before you proceed to buy, rent or pay any money to an owner.
5. **Third-party services.** Payment, messaging, mapping and hosting services are provided by others. We are not responsible for their failures, fees or policies.
6. **External links.** We are not responsible for content on other websites or apps, including social-media sharing services.
7. **Owner responsibility.** Owners are responsible for the accuracy of their listings and for the legality of what they advertise.

---

## Items to confirm before publishing
1. Boost price (UGX 10,000 placeholder), and whether it applies in all countries.
2. Refund policy for subscriptions and boosts once active.
3. Referral credit amount (UGX 2,000) and expiry (12 months).
4. Server location for non-photo data, and the retention period for payment records required by tax law.
5. Privacy contact (DPO) and support e-mail on nomidtrans.shop.
6. Governing law and dispute forum.
7. Whether owners must be shown on-site as verified before listing, and what "verified" means.
8. Cookie and local-storage wording, once the backend stores the sign-in session.
