(function () {
  if (window.__ichimatsuBridgeInstalled) return;
  window.__ichimatsuBridgeInstalled = true;

  // ---- 1. Gemini AI backend bridge (replaces claude.use("sample")) ----
  var nextReqId = 1;
  var pendingAi = new Map();

  window.__androidAiChunk = function (reqId, text) {
    var entry = pendingAi.get(reqId);
    if (entry && entry.onText) {
      try {
        entry.onText({ text: String(text || "") });
      } catch (e) {}
    }
  };

  window.__androidAiResolve = function (reqId, text) {
    var entry = pendingAi.get(reqId);
    if (entry) {
      pendingAi.delete(reqId);
      entry.resolve({ text: String(text || "") });
    }
  };

  window.__androidAiReject = function (reqId, errMsg) {
    var entry = pendingAi.get(reqId);
    if (entry) {
      pendingAi.delete(reqId);
      entry.reject(new Error(String(errMsg || "AI generation failed")));
    }
  };

  function blobToBase64(blob) {
    return new Promise(function (resolve) {
      if (!blob) {
        resolve("");
        return;
      }
      try {
        var reader = new FileReader();
        reader.onloadend = function () {
          var res = String(reader.result || "");
          var comma = res.indexOf(",");
          resolve(comma >= 0 ? res.slice(comma + 1) : res);
        };
        reader.onerror = function () {
          resolve("");
        };
        reader.readAsDataURL(blob);
      } catch (e) {
        resolve("");
      }
    });
  }

  var sampleFn = async function (msgs, opts) {
    if (!window.AndroidBridge) {
      throw new Error("Android AI bridge is not connected.");
    }
    var reqId = String(nextReqId++);
    var imgB64 = "";
    if (opts && Array.isArray(opts.images) && opts.images.length > 0 && opts.images[0]) {
      imgB64 = await blobToBase64(opts.images[0]);
    }
    return new Promise(function (resolve, reject) {
      pendingAi.set(reqId, {
        resolve: resolve,
        reject: reject,
        onText: opts && typeof opts.onText === "function" ? opts.onText : null
      });
      try {
        window.AndroidBridge.generateResponse(reqId, JSON.stringify(msgs), imgB64);
      } catch (e) {
        pendingAi.delete(reqId);
        reject(e);
      }
    });
  };
  sampleFn.limits = async function () {
    return { images: true };
  };

  window.claude = {
    use: async function (name) {
      if (name === "sample") return sampleFn;
      return null;
    }
  };

  // ---- 2. Native Android TextToSpeech polyfill for window.speechSynthesis ----
  if (window.AndroidBridge) {
    var uttSeq = 1;
    var uttMap = new Map();

    window.__androidTtsDone = function (uttId, ok) {
      var u = uttMap.get(uttId);
      if (!u) return;
      uttMap.delete(uttId);
      if (ok && typeof u.onend === "function") {
        try { u.onend(); } catch (e) {}
      } else if (!ok && typeof u.onerror === "function") {
        try { u.onerror(); } catch (e) {}
      }
    };

    function AndroidUtterance(text) {
      this.text = text || "";
      this.lang = "en-US";
      this.pitch = 1.0;
      this.rate = 1.0;
      this.volume = 1.0;
      this.voice = null;
      this.onend = null;
      this.onerror = null;
    }
    window.SpeechSynthesisUtterance = AndroidUtterance;

    var synthVoices = [
      { name: "Google 日本語 (Ichimatsu)", lang: "ja-JP", default: false },
      { name: "Google US English (Female)", lang: "en-US", default: true }
    ];

    window.speechSynthesis = {
      onvoiceschanged: null,
      getVoices: function () {
        return synthVoices;
      },
      cancel: function () {
        uttMap.clear();
        try {
          window.AndroidBridge.stopSpeaking();
        } catch (e) {}
      },
      speak: function (u) {
        if (!u || !u.text) return;
        var id = String(uttSeq++);
        uttMap.set(id, u);
        try {
          window.AndroidBridge.speakText(
            id,
            String(u.text),
            String(u.lang || "en-US"),
            Number(u.pitch || 1.0),
            Number(u.rate || 1.0)
          );
        } catch (e) {
          uttMap.delete(id);
          if (typeof u.onerror === "function") {
            try { u.onerror(); } catch (err) {}
          }
        }
      }
    };

    // ---- 3. Native Android SpeechRecognizer polyfill ----
    var activeRec = null;

    window.__androidSrResult = function (transcript, isFinal) {
      if (!activeRec || typeof activeRec.onresult !== "function") return;
      var item = [{ transcript: String(transcript || "") }];
      item.isFinal = !!isFinal;
      try {
        activeRec.onresult({ resultIndex: 0, results: [item] });
      } catch (e) {}
    };

    window.__androidSrError = function (code) {
      if (activeRec && typeof activeRec.onerror === "function") {
        try {
          activeRec.onerror({ error: String(code || "aborted") });
        } catch (e) {}
      }
    };

    window.__androidSrEnd = function () {
      var rec = activeRec;
      activeRec = null;
      if (rec && typeof rec.onend === "function") {
        try {
          rec.onend();
        } catch (e) {}
      }
    };

    function AndroidSpeechRecognition() {
      this.lang = "en-US";
      this.interimResults = true;
      this.continuous = false;
      this.onresult = null;
      this.onerror = null;
      this.onend = null;
    }

    AndroidSpeechRecognition.prototype.start = function () {
      activeRec = this;
      try {
        window.AndroidBridge.startListening(String(this.lang || "en-US"));
      } catch (e) {
        if (typeof this.onerror === "function") {
          this.onerror({ error: "not-allowed" });
        }
      }
    };

    AndroidSpeechRecognition.prototype.abort = function () {
      if (activeRec === this) activeRec = null;
      try {
        window.AndroidBridge.stopListening();
      } catch (e) {}
    };
    AndroidSpeechRecognition.prototype.stop = AndroidSpeechRecognition.prototype.abort;

    window.SpeechRecognition = AndroidSpeechRecognition;
    window.webkitSpeechRecognition = AndroidSpeechRecognition;
  }
})();
