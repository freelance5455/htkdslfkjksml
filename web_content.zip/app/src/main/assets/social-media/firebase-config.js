// Firebase Web SDK configuration for the Android WebView app.
export const firebaseConfig = {
  apiKey: "AIzaSyByYYCtazMQdo6rJ5O-ZwQQrDIhW6UfAm0",
  authDomain: "miraz-voice.firebaseapp.com",
  projectId: "miraz-voice",
  storageBucket: "miraz-voice.firebasestorage.app",
  messagingSenderId: "676373661521",
  appId: "1:676373661521:android:8254660e92488864d6f570"
};
