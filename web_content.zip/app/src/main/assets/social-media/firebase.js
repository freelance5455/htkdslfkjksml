// SOCIAL MEDIA - Firebase runtime (Real Auth)
// Google + Phone OTP + Email/Password
import { initializeApp } from 'https://www.gstatic.com/firebasejs/12.19.0/firebase-app.js';
import {
  getAuth, onAuthStateChanged, createUserWithEmailAndPassword,
  signInWithEmailAndPassword, signOut, updateProfile, GoogleAuthProvider,
  signInWithPopup, RecaptchaVerifier, signInWithPhoneNumber
} from 'https://www.gstatic.com/firebasejs/12.19.0/firebase-auth.js';
import {
  getFirestore, doc, getDoc, setDoc, serverTimestamp
} from 'https://www.gstatic.com/firebasejs/12.19.0/firebase-firestore.js';
import { firebaseConfig } from './firebase-config.js';

const configured = firebaseConfig && firebaseConfig.apiKey && !String(firebaseConfig.apiKey).includes('PASTE_');
let auth = null;
let db = null;
let currentUser = null;
let confirmationResult = null;
let recaptchaVerifier = null;

async function boot() {
  if (!configured) {
    window.__firebaseStatus = { configured: false, error: 'Firebase config is not filled in yet.' };
    return null;
  }
  const app = initializeApp(firebaseConfig);
  auth = getAuth(app);
  db = getFirestore(app);
  return new Promise(resolve => {
    let first = true;
    onAuthStateChanged(auth, async user => {
      currentUser = user || null;
      window.__firebaseUser = currentUser;
      window.dispatchEvent(new CustomEvent('firebase-auth-changed', { detail: { user: currentUser } }));
      if (first) { first = false; resolve(currentUser); }
    });
  });
}

function normalizeBdPhone(raw) {
  let p = String(raw || '').replace(/\D/g, '');
  if (p.startsWith('880') && p.length === 13) p = p.slice(2);
  if (p.startsWith('0') && p.length === 11) return '+88' + p;
  if (p.length === 10 && p.startsWith('1')) return '+880' + p;
  if (p.startsWith('880') && p.length >= 12) return '+' + p;
  return null;
}

async function ensureUserDoc(user, extra = {}) {
  const ref = doc(db, 'users', user.uid);
  const existing = await getDoc(ref);
  if (existing.exists()) {
    if (Object.keys(extra).length) {
      await setDoc(ref, { ...extra, updatedAt: serverTimestamp() }, { merge: true });
    }
    return existing.data();
  }
  const base = {
    name: extra.name || user.displayName || (user.email ? user.email.split('@')[0] : (user.phoneNumber || 'User')),
    bio: extra.bio || 'Connect • Talk • Learn • Share',
    email: user.email || extra.email || '',
    phone: user.phoneNumber || extra.phone || '',
    provider: extra.provider || 'unknown',
    dob: extra.dob || '',
    age: extra.age ?? null,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp()
  };
  await setDoc(ref, base, { merge: true });
  return base;
}

window.__firebaseReady = boot();
window.socialFirebase = {
  isConfigured: () => configured,

  async signIn(email, password) {
    await window.__firebaseReady;
    if (!configured) throw new Error('FIREBASE_CONFIG_MISSING');
    return signInWithEmailAndPassword(auth, email, password);
  },

  async signInWithGoogle() {
    await window.__firebaseReady;
    if (!configured) throw new Error('FIREBASE_CONFIG_MISSING');
    const provider = new GoogleAuthProvider();
    provider.setCustomParameters({ prompt: 'select_account' });
    const cred = await signInWithPopup(auth, provider);
    await ensureUserDoc(cred.user, { provider: 'google', name: cred.user.displayName || '' });
    return cred.user;
  },

  async signUp(email, password, profile) {
    await window.__firebaseReady;
    if (!configured) throw new Error('FIREBASE_CONFIG_MISSING');
    const cred = await createUserWithEmailAndPassword(auth, email, password);
    if (profile?.name) {
      await updateProfile(cred.user, { displayName: profile.name });
    }
    await ensureUserDoc(cred.user, {
      name: profile.name || '',
      bio: profile.bio || 'Connect • Talk • Learn • Share',
      provider: 'email',
      dob: profile.dob || '',
      age: profile.age ?? null
    });
    return cred.user;
  },

  async sendPhoneOtp(phoneRaw, recaptchaContainerId = 'recaptcha-container') {
    await window.__firebaseReady;
    if (!configured) throw new Error('FIREBASE_CONFIG_MISSING');
    const e164 = normalizeBdPhone(phoneRaw);
    if (!e164) throw Object.assign(new Error('Invalid phone'), { code: 'auth/invalid-phone-number' });

    if (recaptchaVerifier) {
      try { recaptchaVerifier.clear(); } catch (_) {}
      recaptchaVerifier = null;
    }
    const el = document.getElementById(recaptchaContainerId);
    if (el) el.innerHTML = '';

    recaptchaVerifier = new RecaptchaVerifier(auth, recaptchaContainerId, {
      size: 'invisible',
      callback: () => {},
      'expired-callback': () => {}
    });
    await recaptchaVerifier.render();
    confirmationResult = await signInWithPhoneNumber(auth, e164, recaptchaVerifier);
    return { phone: e164 };
  },

  async confirmPhoneOtp(code) {
    await window.__firebaseReady;
    if (!configured) throw new Error('FIREBASE_CONFIG_MISSING');
    if (!confirmationResult) throw Object.assign(new Error('No OTP session'), { code: 'auth/missing-verification-code' });
    const cred = await confirmationResult.confirm(String(code).trim());
    confirmationResult = null;
    await ensureUserDoc(cred.user, {
      provider: 'phone',
      phone: cred.user.phoneNumber || '',
      name: cred.user.displayName || cred.user.phoneNumber || 'User'
    });
    return cred.user;
  },

  clearPhoneSession() {
    confirmationResult = null;
    if (recaptchaVerifier) {
      try { recaptchaVerifier.clear(); } catch (_) {}
      recaptchaVerifier = null;
    }
  },

  async loadProfile(uid) {
    await window.__firebaseReady;
    if (!configured) return null;
    const snap = await getDoc(doc(db, 'users', uid));
    return snap.exists() ? snap.data() : null;
  },

  async saveProfile(uid, profile) {
    await window.__firebaseReady;
    if (!configured) throw new Error('FIREBASE_CONFIG_MISSING');
    await setDoc(doc(db, 'users', uid), {
      ...profile,
      email: currentUser?.email || profile.email || '',
      phone: currentUser?.phoneNumber || profile.phone || '',
      updatedAt: serverTimestamp()
    }, { merge: true });
    if (currentUser && profile.name && currentUser.displayName !== profile.name) {
      await updateProfile(currentUser, { displayName: profile.name });
    }
  },

  async logout() {
    await window.__firebaseReady;
    this.clearPhoneSession();
    if (auth) await signOut(auth);
  },

  onAuthChanged(fn) {
    window.addEventListener('firebase-auth-changed', e => fn(e.detail.user));
  }
};

// Persistent room foundation (voice transport can be connected later).
import { collection, addDoc, query, orderBy, limit, onSnapshot, updateDoc, arrayUnion, arrayRemove } from 'https://www.gstatic.com/firebasejs/12.19.0/firebase-firestore.js';
window.socialFirebase.rooms = {
  async create(data){ await window.__firebaseReady; if(!db||!currentUser) throw new Error('LOGIN_REQUIRED'); return addDoc(collection(db,'rooms'), {...data, hostUid:currentUser.uid, createdAt:serverTimestamp(), updatedAt:serverTimestamp(), active:true, speakerCount:1, maxSpeakers:15}); },
  watch(fn){ if(!db) return ()=>{}; return onSnapshot(query(collection(db,'rooms'),orderBy('createdAt','desc'),limit(100)), s=>fn(s.docs.map(d=>({id:d.id,...d.data()})))); },
  async update(id,data){ await window.__firebaseReady; return updateDoc(doc(db,'rooms',id),{...data,updatedAt:serverTimestamp()}); }
};
