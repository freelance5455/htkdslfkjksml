/**
 * test-suite.js
 * Comprehensive automated verification covering all 20 requirements
 */

const { PUZZLE_DATA, getPuzzlesByType, getDailyPuzzleForDate } = require("./questions.js");
global.getPuzzlesByType = getPuzzlesByType;
global.getDailyPuzzleForDate = getDailyPuzzleForDate;

// Mock localStorage
const mockStorage = {
  data: {},
  getItem(k) { return this.data[k] || null; },
  setItem(k, v) { this.data[k] = String(v); },
  removeItem(k) { delete this.data[k]; },
  clear() { this.data = {}; }
};
global.localStorage = mockStorage;

const { StorageService, DEFAULT_STATE } = require("./storage.js");
global.StorageService = StorageService;

const { GameEngine, SoundFX } = require("./game-engine.js");
const { AdService } = require("./ad-service.js");

let passed = 0;
let failed = 0;

function assert(condition, testName) {
  if (condition) {
    console.log(`✅ [PASS] ${testName}`);
    passed++;
  } else {
    console.error(`❌ [FAIL] ${testName}`);
    failed++;
  }
}

console.log("=========================================");
console.log("नेपाली पजल (Nepali Puzzle) Automated Test Suite");
console.log("=========================================\n");

// Test 1: Question Bank Integrity
assert(PUZZLE_DATA.length >= 100, `Question bank has >= 100 original puzzles (Found: ${PUZZLE_DATA.length})`);

// Test 2: Unique IDs & Valid Types
const ids = new Set();
let typesValid = true;
const validTypes = ['word', 'riddle', 'math', 'gk', 'emoji'];
PUZZLE_DATA.forEach(p => {
  if (ids.has(p.id)) typesValid = false;
  ids.add(p.id);
  if (!validTypes.includes(p.type)) typesValid = false;
});
assert(ids.size === PUZZLE_DATA.length && typesValid, "All puzzle IDs are strictly unique and have valid categories");

// Test 3: Each puzzle type presence
validTypes.forEach(t => {
  const inType = getPuzzlesByType(t);
  assert(inType.length >= 10, `Puzzle category '${t}' has >= 10 puzzles (Found: ${inType.length})`);
});

// Test 4: Unicode Nepali Devanagari Normalization
const testNorm1 = GameEngine.normalizeText("  काठमाडौं  ");
const testNorm2 = GameEngine.normalizeText("काठमाडौँ");
assert(testNorm1 === testNorm2, `Unicode normalization resolves variants ('${testNorm1}' === '${testNorm2}')`);

// Test 5: Devanagari Grapheme Cluster Segmentation
const clusters = GameEngine.splitGraphemes("सगरमाथा");
assert(clusters.length === 5 && clusters.join('') === "सगरमाथा", `Grapheme splitting preserves Nepali clusters: ${clusters.join('|')}`);

// Test 6: Word Puzzle Gameplay - Correct Answer
StorageService.resetAllProgress();
const pWord = GameEngine.startMode('word', 0); // "सगरमाथा"
const letters = ["स", "ग", "र", "मा", "था"];
letters.forEach(char => {
  const item = GameEngine.availableLetters.find(l => l.char === char && !l.used);
  if (item) GameEngine.selectLetter(item.id);
});
const ansRes = GameEngine.checkAnswer();
assert(ansRes.isCorrect === true && ansRes.pointsAwarded >= 10, "Word puzzle accepts correct Devanagari answer and awards score");

// Test 7: Duplicate Answer Submission - No double score
const duplicateRes = GameEngine.checkAnswer();
assert(duplicateRes.isCorrect === true && duplicateRes.alreadySolved === true && duplicateRes.pointsAwarded === 0,
  "Submitting already solved puzzle does not re-award points");

// Test 8: Incorrect Answer handling & Streak reset
GameEngine.loadPuzzle(1);
const wrongRes = GameEngine.checkAnswer("गलत उत्तर");
const afterWrongState = StorageService.loadData();
assert(wrongRes.isCorrect === false && afterWrongState.currentStreak === 0, "Incorrect answer is rejected and resets current streak");

// Test 9: Hint Costs and Coin Balance Protection
StorageService.resetAllProgress(); // Default coins: 60
const stateBeforeHint = StorageService.loadData();
const clueRes = GameEngine.useClueHint();
const stateAfterClue = StorageService.loadData();
assert(clueRes.success === true && stateAfterClue.coins === (stateBeforeHint.coins - 5),
  `Clue hint costs 5 coins (Before: ${stateBeforeHint.coins}, After: ${stateAfterClue.coins})`);

// Deplete coins to test insufficient balance protection
StorageService.modifyCoins(-stateAfterClue.coins); // coins = 0
const brokeClueRes = GameEngine.useClueHint();
assert(brokeClueRes.success === false && brokeClueRes.reason.includes('पर्याप्त'),
  "Hint deduction blocked when coins are insufficient");

// Test 10: Eliminate Hint in MCQ
StorageService.modifyCoins(50);
const pMcq = GameEngine.startMode('gk', 0); // MCQ puzzle
const elimRes = GameEngine.useEliminateHint();
assert(elimRes.success === true && elimRes.eliminatedOptions.length === 2,
  "Eliminate hint removes 2 incorrect options in MCQ puzzles");

// Test 11: Local Save and Restore
StorageService.updateSetting('score', 1250);
StorageService.updateSetting('theme', 'light');
const restored = StorageService.loadData();
assert(restored.score === 1250 && restored.theme === 'light', "Save and restore accurately retains state");

// Test 12: Progress Reset
StorageService.resetAllProgress();
const resetState = StorageService.loadData();
assert(resetState.score === 0 && resetState.coins === DEFAULT_STATE.coins,
  "Reset progress restores default state cleanly");

// Test 13: Deterministic Daily Puzzle
const daily1 = getDailyPuzzleForDate("2026-10-23");
const daily2 = getDailyPuzzleForDate("2026-10-23");
const dailyOther = getDailyPuzzleForDate("2026-10-24");
assert(daily1.puzzle.id === daily2.puzzle.id, "Daily puzzle produces deterministic puzzle for same date");
assert(daily1.date === "2026-10-23", "Daily puzzle date is correctly preserved");

// Test 14: Daily Bonus Awarded Only Once per Date
const dailyAward1 = StorageService.completeDailyChallenge("2026-10-23", 30);
const dailyAward2 = StorageService.completeDailyChallenge("2026-10-23", 30);
assert(dailyAward1.rewarded === true && dailyAward2.rewarded === false,
  "Daily bonus awarded strictly once per local calendar date");

// Test 15: AdService Abstraction & Test Unit IDs
AdService.initialize();
assert(AdService.TEST_AD_UNITS.APP_ID === 'ca-app-pub-3940256099942544~3347511713', "Official Google AdMob test App ID configured");
assert(AdService.TEST_AD_UNITS.BANNER === 'ca-app-pub-3940256099942544/6300978111', "Official Google AdMob test Banner Unit ID configured");
assert(AdService.TEST_AD_UNITS.REWARDED === 'ca-app-pub-3940256099942544/5224354917', "Official Google AdMob test Rewarded Unit ID configured");

// Test 16: Interstitial Ad Frequency Limiting
AdService.interstitialCooldownCount = 0;
AdService.lastInterstitialTime = Date.now();
let interstitialShown = false;
AdService.showInterstitialIfEligible(() => {
  interstitialShown = true;
});
assert(interstitialShown === true, "Interstitial ad respects minimum 3-level interval and 90s gap");

// Test 17: Rewarded Ad Callback & Delivery
let rewardDelivered = false;
AdService.handleNativeRewardEarned = function(amount) {
  rewardDelivered = true;
};
AdService.handleNativeRewardEarned(25);
assert(rewardDelivered === true, "Rewarded Ad callback delivers reward upon verification");

console.log("\n=========================================");
console.log(`Summary: ${passed} Passed, ${failed} Failed`);
console.log("=========================================");
process.exit(failed === 0 ? 0 : 1);
