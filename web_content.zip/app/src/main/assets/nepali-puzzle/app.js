/**
 * app.js
 * नेपाली पजल — मुख्य एप नियन्त्रक, UI अन्तरक्रिया, इभेन्ट ह्यान्डलर र नेभिगेसन
 */

document.addEventListener('DOMContentLoaded', () => {
  // १. प्रारम्भिक सेवाहरू सुरु गर्ने
  const state = StorageService.loadData();
  applyTheme(state.theme || 'dark');
  AdService.initialize();
  AdService.showBanner('admob-banner-container');

  // २. UI एलिमेन्ट सन्दर्भहरू
  const headerCoinsVal = document.getElementById('header-coins-val');
  const headerScoreVal = document.getElementById('header-score-val');
  const btnSoundToggle = document.getElementById('btn-sound-toggle');
  const homeScreen = document.getElementById('home-screen');
  const gameScreen = document.getElementById('game-screen');

  // Gameplay Elements
  const gameLevelTag = document.getElementById('game-level-tag');
  const gameStreakTag = document.getElementById('game-streak-tag');
  const questionCard = document.getElementById('question-card');
  const questionCategoryText = document.getElementById('question-category-text');
  const questionEmoji = document.getElementById('question-emoji');
  const questionTitleText = document.getElementById('question-title-text');
  const questionClueText = document.getElementById('question-clue-text');

  const wordGameArea = document.getElementById('word-game-area');
  const answerSlots = document.getElementById('answer-slots');
  const lettersPool = document.getElementById('letters-pool');
  const btnWordShuffle = document.getElementById('btn-word-shuffle');
  const btnWordClear = document.getElementById('btn-word-clear');
  const btnSubmitWord = document.getElementById('btn-submit-word');

  const mcqGameArea = document.getElementById('mcq-game-area');
  const mcqOptions = document.getElementById('mcq-options');

  // Hint Buttons
  const btnHintClue = document.getElementById('btn-hint-clue');
  const btnHintEliminate = document.getElementById('btn-hint-eliminate');
  const btnHintReveal = document.getElementById('btn-hint-reveal');
  const btnWatchAd = document.getElementById('btn-watch-ad');

  // Modals
  const victoryModal = document.getElementById('victory-modal');
  const victoryTitle = document.getElementById('victory-title');
  const victoryDesc = document.getElementById('victory-desc');
  const victoryExplanation = document.getElementById('victory-explanation');
  const btnNextPuzzle = document.getElementById('btn-next-puzzle');
  const btnVictoryHome = document.getElementById('btn-victory-home');

  const settingsModal = document.getElementById('settings-modal');
  const settingSoundCheckbox = document.getElementById('setting-sound-checkbox');
  const settingThemeSelect = document.getElementById('setting-theme-select');
  const btnResetProgress = document.getElementById('btn-reset-progress');

  const statsModal = document.getElementById('stats-modal');
  const levelModal = document.getElementById('level-modal');
  const aboutModal = document.getElementById('about-modal');

  // ३. डेटा र UI सिङ्क गर्ने
  function updateHeaderStats() {
    const s = StorageService.loadData();
    headerCoinsVal.textContent = toNepaliNumeral(s.coins);
    headerScoreVal.textContent = toNepaliNumeral(s.score);
    btnSoundToggle.textContent = s.soundEnabled ? '🔊' : '🔇';

    // दैनिक चुनौतीको अवस्था
    const now = new Date();
    const dateStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
    const dailyDone = StorageService.isDailyCompletedToday(dateStr);
    const dailyStatus = document.getElementById('daily-card-status');
    const btnPlayDaily = document.getElementById('btn-play-daily');
    if (dailyDone) {
      dailyStatus.textContent = '✅ आजको दैनिक चुनौती पूरा भइसक्यो! भोलि नयाँ आउनेछ।';
      btnPlayDaily.textContent = 'समीक्षा गर्नुहोस्';
    } else {
      dailyStatus.textContent = 'आजको नयाँ पजल खेल्नुहोस् र +३० सिक्का जित्नुहोस्!';
      btnPlayDaily.textContent = 'सुरु गर्नुहोस्';
    }

    // विधा अनुसारका ब्याच स्तरहरू
    ['word', 'riddle', 'math', 'gk', 'emoji'].forEach(mode => {
      const el = document.getElementById(`badge-${mode}-prog`);
      if (el && s.currentCategoryLevel[mode]) {
        el.textContent = `स्तर ${toNepaliNumeral(s.currentCategoryLevel[mode])}`;
      }
    });
  }

  function applyTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    StorageService.updateSetting('theme', theme);
  }

  function toNepaliNumeral(num) {
    const nepaliDigits = ['०', '१', '२', '३', '४', '५', '६', '७', '८', '९'];
    return String(num).replace(/\d/g, d => nepaliDigits[parseInt(d, 10)]);
  }

  // ४. स्क्रिन नेभिगेसन
  function showScreen(screenId) {
    [homeScreen, gameScreen].forEach(s => s.classList.remove('active'));
    if (screenId === 'home') {
      homeScreen.classList.add('active');
      updateHeaderStats();
    } else if (screenId === 'game') {
      gameScreen.classList.add('active');
    }
  }

  // ५. खेल सुरु गर्ने र प्रश्न रेन्डर गर्ने
  function launchGame(mode, levelIndex = 0) {
    const puzzle = GameEngine.startMode(mode, levelIndex);
    if (!puzzle) {
      alert('यस विधामा हाल प्रश्न उपलब्ध छैनन्।');
      return;
    }
    showScreen('game');
    renderCurrentPuzzle();
  }

  function renderCurrentPuzzle() {
    const p = GameEngine.currentPuzzle;
    if (!p) return;

    const s = StorageService.loadData();
    const totalInCat = GameEngine.activePuzzles.length;
    gameLevelTag.textContent = `${p.category || 'पजल'} • स्तर ${toNepaliNumeral(GameEngine.currentIndex + 1)} / ${toNepaliNumeral(totalInCat)}`;
    gameStreakTag.textContent = `🔥 स्ट्रिक: ${toNepaliNumeral(s.currentStreak)}`;

    questionCategoryText.textContent = `${p.difficulty} • ${p.category}`;
    questionTitleText.textContent = p.question;
    questionClueText.textContent = p.clue ? `💡 सङ्केत: ${p.clue}` : '';

    if (p.emoji) {
      questionEmoji.textContent = p.emoji;
      questionEmoji.style.display = 'block';
    } else {
      questionEmoji.style.display = 'none';
    }

    if (p.type === 'word') {
      wordGameArea.style.display = 'block';
      mcqGameArea.style.display = 'none';
      renderWordPuzzle();
    } else {
      wordGameArea.style.display = 'none';
      mcqGameArea.style.display = 'block';
      renderMcqPuzzle();
    }
  }

  // ६. शब्द पजल रेन्डरिङ र अक्षर छनोट
  function renderWordPuzzle() {
    // उत्तर स्लटहरू
    answerSlots.innerHTML = '';
    if (GameEngine.selectedLetters.length === 0) {
      answerSlots.innerHTML = '<span style="color:var(--text-muted); font-size:0.9rem; align-self:center;">तलका अक्षरहरू थिचेर शब्द बनाउनुहोस्</span>';
    } else {
      GameEngine.selectedLetters.forEach((l) => {
        const tile = document.createElement('div');
        tile.className = 'slot-tile';
        tile.textContent = l.char;
        tile.title = 'हटाउन थिच्नुहोस्';
        tile.onclick = () => {
          GameEngine.deselectLetter(l.id);
          renderWordPuzzle();
        };
        answerSlots.appendChild(tile);
      });
    }

    // उपलब्ध अक्षरहरू
    lettersPool.innerHTML = '';
    GameEngine.availableLetters.forEach((l) => {
      const btn = document.createElement('button');
      btn.className = `letter-btn ${l.used ? 'used' : ''} ${l.eliminated ? 'eliminated' : ''}`;
      btn.textContent = l.char;
      btn.disabled = l.used || l.eliminated;
      btn.onclick = () => {
        GameEngine.selectLetter(l.id);
        renderWordPuzzle();
      };
      lettersPool.appendChild(btn);
    });
  }

  // ७. बहुवैकल्पिक (MCQ) रेन्डरिङ
  function renderMcqPuzzle() {
    mcqOptions.innerHTML = '';
    const p = GameEngine.currentPuzzle;
    if (!p.options) return;

    p.options.forEach((opt) => {
      const btn = document.createElement('button');
      btn.className = 'mcq-btn';
      btn.textContent = opt;

      if (GameEngine.eliminatedOptions.includes(opt)) {
        btn.classList.add('eliminated');
        btn.disabled = true;
      }

      btn.onclick = () => {
        handleAnswerSubmission(opt, btn);
      };
      mcqOptions.appendChild(btn);
    });
  }

  // ८. उत्तर प्रमाणीकरण ह्यान्डलर
  function handleAnswerSubmission(answerStr, targetButton = null) {
    const result = GameEngine.checkAnswer(answerStr);

    if (result.isCorrect) {
      if (targetButton) {
        targetButton.classList.add('correct-highlight');
      }
      setTimeout(() => {
        showVictoryModal(result);
      }, 300);
    } else {
      // गलत उत्तर भए हल्का भाइब्रेट र सन्देश
      if (targetButton) {
        targetButton.style.borderColor = 'var(--danger)';
        targetButton.style.background = 'rgba(239, 68, 68, 0.15)';
        setTimeout(() => {
          targetButton.style.borderColor = '';
          targetButton.style.background = '';
        }, 800);
      }
      questionClueText.textContent = result.message;
      questionClueText.style.color = 'var(--danger)';
      setTimeout(() => {
        const p = GameEngine.currentPuzzle;
        questionClueText.textContent = p.clue ? `💡 सङ्केत: ${p.clue}` : '';
        questionClueText.style.color = 'var(--accent)';
      }, 2500);
    }
    updateHeaderStats();
  }

  function showVictoryModal(res) {
    victoryModal.classList.add('active');
    victoryTitle.textContent = res.alreadySolved ? 'अगाडि नै हल भइसकेको!' : '🎉 उत्कृष्ट! सही उत्तर';
    victoryDesc.textContent = res.alreadySolved 
      ? 'तपाईंले यो प्रश्न पहिले नै पूरा गरिसक्नुभएको छ।'
      : `+${toNepaliNumeral(res.pointsAwarded)} अङ्क र +${toNepaliNumeral(res.coinsAwarded)} सिक्का प्राप्त भयो!`;
    victoryExplanation.innerHTML = `<strong>सही उत्तर:</strong> ${res.correctAnswer}<br><br><strong>जानकारी:</strong> ${res.explanation}`;
  }

  // ९. इभेन्ट लिसनरहरू (Home, Buttons, Hints)
  // विधा कार्डहरू
  document.querySelectorAll('.mode-card').forEach(card => {
    card.addEventListener('click', () => {
      const mode = card.getAttribute('data-mode');
      const s = StorageService.loadData();
      const currentLevel = (s.currentCategoryLevel[mode] || 1) - 1;
      launchGame(mode, currentLevel);
    });
  });

  // दैनिक चुनौती बटन
  document.getElementById('btn-play-daily').addEventListener('click', () => {
    launchGame('daily', 0);
  });

  // गृहपृष्ठ फिर्ता बटन
  document.getElementById('btn-back-home').addEventListener('click', () => {
    showScreen('home');
  });

  // शब्द पजलका टुलहरू
  btnWordShuffle.addEventListener('click', () => {
    GameEngine.shuffleAvailableLetters();
    renderWordPuzzle();
  });

  btnWordClear.addEventListener('click', () => {
    GameEngine.clearSelectedLetters();
    renderWordPuzzle();
  });

  btnSubmitWord.addEventListener('click', () => {
    handleAnswerSubmission();
  });

  // अर्को प्रश्न बटन (Victory Modal)
  btnNextPuzzle.addEventListener('click', () => {
    victoryModal.classList.remove('active');
    // योग्यता पुगेको खण्डमा इन्टरस्टिसियल विज्ञापन
    AdService.showInterstitialIfEligible(() => {
      proceedToNextPuzzle();
    });
  });

  function proceedToNextPuzzle() {
    const next = GameEngine.nextPuzzle();
    if (next) {
      renderCurrentPuzzle();
    } else {
      alert('बधाई छ! यस विधाका सबै उपलब्ध स्तरहरू तपाईंले पार गर्नुभयो! 🎉');
      showScreen('home');
    }
  }

  btnVictoryHome.addEventListener('click', () => {
    victoryModal.classList.remove('active');
    showScreen('home');
  });

  // १०. सङ्केत (Hints) प्रणाली
  btnHintClue.addEventListener('click', () => {
    const res = GameEngine.useClueHint();
    if (res.success) {
      questionClueText.textContent = `💡 क्लु: ${res.clue}`;
      updateHeaderStats();
    } else {
      alert(res.reason);
    }
  });

  btnHintEliminate.addEventListener('click', () => {
    const res = GameEngine.useEliminateHint();
    if (res.success) {
      if (res.eliminatedOptions) {
        renderMcqPuzzle();
      } else if (res.eliminatedLetters) {
        renderWordPuzzle();
      }
      updateHeaderStats();
    } else {
      alert(res.reason);
    }
  });

  btnHintReveal.addEventListener('click', () => {
    const res = GameEngine.useRevealLetterHint();
    if (res.success) {
      if (GameEngine.currentPuzzle.type === 'word') {
        renderWordPuzzle();
      } else if (res.directAnswer) {
        alert(`सही उत्तर: ${res.directAnswer}`);
      }
      updateHeaderStats();
    } else {
      alert(res.reason);
    }
  });

  // भिडियो विज्ञापन हेरेर +२५ सिक्का
  btnWatchAd.addEventListener('click', () => {
    AdService.showRewardedAd(
      (reward) => {
        StorageService.modifyCoins(reward.amount || 25);
        if (StorageService.loadData().soundEnabled) SoundFX.playCoin();
        updateHeaderStats();
        alert(`बधाई छ! विज्ञापन हेर्नुभएकोमा +${toNepaliNumeral(reward.amount || 25)} सिक्का थपियो! 🎉`);
      },
      (error) => {
        alert(`विज्ञापन लोड हुन सकेन: ${error}`);
      }
    );
  });

  // ११. सेटिङ, साउन्ड, र मोडलहरू
  btnSoundToggle.addEventListener('click', () => {
    const s = StorageService.loadData();
    const newVal = !s.soundEnabled;
    StorageService.updateSetting('soundEnabled', newVal);
    updateHeaderStats();
  });

  document.getElementById('btn-open-settings').addEventListener('click', () => {
    const s = StorageService.loadData();
    settingSoundCheckbox.checked = s.soundEnabled;
    settingThemeSelect.value = s.theme || 'dark';
    settingsModal.classList.add('active');
  });

  document.getElementById('btn-close-settings-modal').addEventListener('click', () => {
    StorageService.updateSetting('soundEnabled', settingSoundCheckbox.checked);
    applyTheme(settingThemeSelect.value);
    settingsModal.classList.remove('active');
    updateHeaderStats();
  });

  settingThemeSelect.addEventListener('change', (e) => {
    applyTheme(e.target.value);
  });

  btnResetProgress.addEventListener('click', () => {
    if (confirm('के तपाईं निश्चित रूपमा आफ्नो सबै स्कोर, स्तर र सिक्का रिसेट गर्न चाहनुहुन्छ? यो पूर्ववत् गर्न सकिने छैन।')) {
      StorageService.resetAllProgress();
      settingsModal.classList.remove('active');
      updateHeaderStats();
      alert('खेल प्रगति पूर्ण रूपमा रिसेट भयो!');
    }
  });

  // तथ्याङ्क (Stats) Modal
  document.getElementById('btn-open-stats').addEventListener('click', () => {
    const s = StorageService.loadData();
    const accuracy = s.totalAnswered > 0 ? Math.round((s.totalCorrect / s.totalAnswered) * 100) : 0;
    const statsList = document.getElementById('stats-details-list');
    statsList.innerHTML = `
      <div class="settings-item"><span>कुल हल गरिएका पजल:</span> <strong>${toNepaliNumeral(s.solvedIds.length)}</strong></div>
      <div class="settings-item"><span>कुल सही दर (Accuracy):</span> <strong>${toNepaliNumeral(accuracy)}%</strong></div>
      <div class="settings-item"><span>सबैभन्दा लामो स्ट्रिक:</span> <strong>${toNepaliNumeral(s.bestStreak)}</strong></div>
      <div class="settings-item"><span>कुल प्राप्त अङ्क:</span> <strong>${toNepaliNumeral(s.score)}</strong></div>
      <div class="settings-item"><span>हालको सिक्का ब्यालेन्स:</span> <strong>${toNepaliNumeral(s.coins)} 🪙</strong></div>
      <div class="settings-item"><span>दैनिक चुनौतीहरू सम्पन्न:</span> <strong>${toNepaliNumeral(s.stats ? s.stats.dailySolved : 0)}</strong></div>
    `;
    statsModal.classList.add('active');
  });

  document.getElementById('btn-close-stats-modal').addEventListener('click', () => {
    statsModal.classList.remove('active');
  });

  // स्तर छनोट (Level Select) Modal
  document.getElementById('btn-open-levels').addEventListener('click', () => {
    const list = document.getElementById('level-select-list');
    list.innerHTML = '';
    const modes = [
      { id: 'word', name: 'शब्द पजल', icon: '🔤' },
      { id: 'riddle', name: 'गाउँखाने कथा', icon: '🤔' },
      { id: 'math', name: 'गणितीय पजल', icon: '🔢' },
      { id: 'gk', name: 'सामान्य ज्ञान', icon: '🇳🇵' },
      { id: 'emoji', name: 'इमोजी पजल', icon: '💡' }
    ];

    modes.forEach(m => {
      const item = document.createElement('button');
      item.className = 'mcq-btn';
      item.style.marginBottom = '8px';
      item.innerHTML = `<span>${m.icon} ${m.name}</span>`;
      item.onclick = () => {
        levelModal.classList.remove('active');
        launchGame(m.id, 0);
      };
      list.appendChild(item);
    });
    levelModal.classList.add('active');
  });

  document.getElementById('btn-close-level-modal').addEventListener('click', () => {
    levelModal.classList.remove('active');
  });

  // जानकारी (About) Modal
  document.getElementById('btn-open-about').addEventListener('click', () => {
    aboutModal.classList.add('active');
  });

  document.getElementById('btn-close-about-modal').addEventListener('click', () => {
    aboutModal.classList.remove('active');
  });

  // एन्ड्रोइड ब्याक बटन नियन्त्रण
  window.onAndroidBackPressed = function() {
    if (victoryModal.classList.contains('active')) {
      victoryModal.classList.remove('active');
      return true;
    }
    if (settingsModal.classList.contains('active')) {
      settingsModal.classList.remove('active');
      return true;
    }
    if (statsModal.classList.contains('active')) {
      statsModal.classList.remove('active');
      return true;
    }
    if (levelModal.classList.contains('active')) {
      levelModal.classList.remove('active');
      return true;
    }
    if (aboutModal.classList.contains('active')) {
      aboutModal.classList.remove('active');
      return true;
    }
    if (gameScreen.classList.contains('active')) {
      showScreen('home');
      return true;
    }
    return false; // होम स्क्रिनमा छ भने एप बन्द गर्न अनुमति
  };

  // पहिलो लोडमा तथ्याङ्क देखाउने
  updateHeaderStats();
});
