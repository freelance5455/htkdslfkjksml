/**
 * storage.js
 * स्थानीय डेटा व्यवस्थापन र प्रोग्रेस सुरक्षित राख्ने मोड्युल
 * localStorage प्रयोग, संस्करण जाँच, सुरक्षा र प्रमाणीकरण
 */

const STORAGE_KEY = 'nepali_puzzle_save_data_v1';
const CURRENT_VERSION = 1;

const DEFAULT_STATE = {
  version: CURRENT_VERSION,
  coins: 60,                // प्रारम्भिक उपहार सिक्का
  score: 0,
  solvedIds: [],            // समाधान गरिएका सबै पजल ID हरू
  currentCategoryLevel: {   // वर्ग अनुसारको स्तर
    word: 1,
    riddle: 1,
    math: 1,
    gk: 1,
    emoji: 1,
    all: 1
  },
  currentStreak: 0,
  bestStreak: 0,
  totalAnswered: 0,
  totalCorrect: 0,
  dailyCompletedDates: [],  // पूरा गरिएको स्थानीय मितिहरू ['YYYY-MM-DD']
  soundEnabled: true,
  theme: 'dark',            // 'dark' वा 'light'
  hintsUsedCount: 0,
  stats: {
    wordSolved: 0,
    riddleSolved: 0,
    mathSolved: 0,
    gkSolved: 0,
    emojiSolved: 0,
    dailySolved: 0
  }
};

const StorageService = {
  /**
   * सुरक्षित रूपमा लोड गर्ने र ढाँचा जाँच गर्ने
   */
  loadData() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) {
        return this.saveData(DEFAULT_STATE);
      }
      const parsed = JSON.parse(raw);

      // ढाँचा प्रमाणीकरण
      if (!parsed || typeof parsed !== 'object') {
        console.warn('अमान्य बचत डेटा, पूर्वनिर्धारित लोड गरिँदैछ।');
        return this.saveData(DEFAULT_STATE);
      }

      // संस्करण माइग्रेसन यदि आवश्यक भएमा
      const state = { ...DEFAULT_STATE, ...parsed };
      if (typeof state.coins !== 'number' || isNaN(state.coins)) state.coins = DEFAULT_STATE.coins;
      if (typeof state.score !== 'number' || isNaN(state.score)) state.score = DEFAULT_STATE.score;
      if (!Array.isArray(state.solvedIds)) state.solvedIds = [];
      if (!Array.isArray(state.dailyCompletedDates)) state.dailyCompletedDates = [];
      if (!state.currentCategoryLevel || typeof state.currentCategoryLevel !== 'object') {
        state.currentCategoryLevel = { ...DEFAULT_STATE.currentCategoryLevel };
      }
      if (!state.stats || typeof state.stats !== 'object') {
        state.stats = { ...DEFAULT_STATE.stats };
      }
      return state;
    } catch (e) {
      console.error('डेटा लोड गर्दा त्रुटि:', e);
      return { ...DEFAULT_STATE };
    }
  },

  /**
   * स्थानीय स्टोरेजमा डेटा सुरक्षित गर्ने
   */
  saveData(state) {
    try {
      state.version = CURRENT_VERSION;
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
      return state;
    } catch (e) {
      console.error('डेटा सेभ गर्न सकिएन:', e);
      return state;
    }
  },

  /**
   * पजल हल भएपछि प्रगति अद्यावधिक गर्ने
   */
  recordSolve(puzzleId, type, pointsAwarded, coinsAwarded) {
    const state = this.loadData();
    const alreadySolved = state.solvedIds.includes(puzzleId);

    if (!alreadySolved) {
      state.solvedIds.push(puzzleId);
      state.totalCorrect += 1;
      state.currentStreak += 1;
      if (state.currentStreak > state.bestStreak) {
        state.bestStreak = state.currentStreak;
      }
      state.score += (pointsAwarded || 10);
      state.coins += (coinsAwarded || 5);

      if (type && state.stats && state.stats[`${type}Solved`] !== undefined) {
        state.stats[`${type}Solved`] += 1;
      }
      if (type && state.currentCategoryLevel[type]) {
        state.currentCategoryLevel[type] += 1;
      }
      state.currentCategoryLevel.all += 1;
    }
    state.totalAnswered += 1;
    this.saveData(state);
    return state;
  },

  /**
   * गलत उत्तर रेकर्ड गर्ने (स्ट्रिक शून्य हुन्छ)
   */
  recordWrongAnswer() {
    const state = this.loadData();
    state.totalAnswered += 1;
    state.currentStreak = 0;
    this.saveData(state);
    return state;
  },

  /**
   * सिक्का थप वा घटाउ गर्ने
   */
  modifyCoins(delta) {
    const state = this.loadData();
    if (delta < 0 && state.coins < Math.abs(delta)) {
      return { success: false, currentCoins: state.coins };
    }
    state.coins += delta;
    if (delta < 0) {
      state.hintsUsedCount += 1;
    }
    this.saveData(state);
    return { success: true, currentCoins: state.coins };
  },

  /**
   * दैनिक चुनौती सम्पन्न भएको दर्ता गर्ने
   */
  completeDailyChallenge(dateStr, bonusCoins) {
    const state = this.loadData();
    if (!state.dailyCompletedDates.includes(dateStr)) {
      state.dailyCompletedDates.push(dateStr);
      state.coins += (bonusCoins || 30);
      state.score += 25;
      if (state.stats) state.stats.dailySolved += 1;
      this.saveData(state);
      return { rewarded: true, coins: state.coins };
    }
    return { rewarded: false, coins: state.coins };
  },

  /**
   * दैनिक चुनौती आज पूरा भइसकेको छ कि छैन जाँच्ने
   */
  isDailyCompletedToday(dateStr) {
    const state = this.loadData();
    return state.dailyCompletedDates.includes(dateStr);
  },

  /**
   * थिम वा साउन्ड सेटिङ अपडेट गर्ने
   */
  updateSetting(key, value) {
    const state = this.loadData();
    state[key] = value;
    this.saveData(state);
    return state;
  },

  /**
   * प्रगति रिसेट गर्ने
   */
  resetAllProgress() {
    try {
      localStorage.removeItem(STORAGE_KEY);
      return this.saveData({ ...DEFAULT_STATE, version: CURRENT_VERSION });
    } catch (e) {
      console.error('रिसेट त्रुटि:', e);
      return { ...DEFAULT_STATE };
    }
  }
};

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { StorageService, DEFAULT_STATE };
}
