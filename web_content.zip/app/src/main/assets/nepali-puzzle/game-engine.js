/**
 * game-engine.js
 * नेपाली पजल — खेलको मुख्य लजिक, युनिकोड सञ्चालन, सङ्केत प्रणाली र स्कोर गणना
 */

const SoundFX = {
  ctx: null,
  getAudioContext() {
    if (!this.ctx && typeof window !== 'undefined') {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
    return this.ctx;
  },

  playTone(freq, type = 'sine', duration = 0.15, gainVal = 0.1) {
    try {
      const ctx = this.getAudioContext();
      if (!ctx) return;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = type;
      osc.frequency.setValueAtTime(freq, ctx.currentTime);
      gain.gain.setValueAtTime(gainVal, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + duration);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + duration);
    } catch (e) {
      // AudioContext unavailable or blocked
    }
  },

  playClick() {
    this.playTone(600, 'triangle', 0.05, 0.05);
  },

  playCorrect() {
    const ctx = this.getAudioContext();
    if (!ctx) return;
    this.playTone(523.25, 'sine', 0.12, 0.15); // C5
    setTimeout(() => this.playTone(659.25, 'sine', 0.12, 0.15), 100); // E5
    setTimeout(() => this.playTone(783.99, 'sine', 0.25, 0.18), 200); // G5
  },

  playWrong() {
    this.playTone(220, 'sawtooth', 0.2, 0.12);
    setTimeout(() => this.playTone(180, 'sawtooth', 0.25, 0.15), 120);
  },

  playCoin() {
    this.playTone(987.77, 'sine', 0.08, 0.15); // B5
    setTimeout(() => this.playTone(1318.51, 'sine', 0.2, 0.18), 80); // E6
  },

  playLevelUp() {
    [440, 554, 659, 880].forEach((freq, idx) => {
      setTimeout(() => this.playTone(freq, 'sine', 0.15, 0.2), idx * 90);
    });
  }
};

const GameEngine = {
  currentMode: 'word',
  activePuzzles: [],
  currentIndex: 0,
  currentPuzzle: null,
  selectedLetters: [],     // शब्द पजलमा छनोट गरिएका अक्षरहरू
  availableLetters: [],    // बाँकी अक्षरहरू
  eliminatedOptions: [],   // हटाइएका गलत विकल्पहरू (Hint 2)
  isProcessingHint: false, // द्रुत दोहोरो ट्याप रोक्ने
  isDailyMode: false,
  dailyDateStr: '',

  /**
   * देवनागरी युनिकोड सामान्यीकरण (Unicode Normalization)
   */
  normalizeText(str) {
    if (!str) return '';
    return str
      .trim()
      .normalize('NFC')
      .replace(/\s+/g, ' ')
      .replace(/[\u200B-\u200D\uFEFF]/g, '') // Zero-width characters
      .replace(/काठमाडौं/g, 'काठमाडौँ')
      .replace(/दशैं/g, 'दसैँ')
      .replace(/गैंडा/g, 'गैँडा')
      .replace(/पंखा/g, 'पङ्खा');
  },

  /**
   * देवनागरी अक्षर गुच्छा (Grapheme Clusters) सुरक्षित टुक्र्याउने
   */
  splitGraphemes(text) {
    if (!text) return [];
    if (typeof Intl !== 'undefined' && Intl.Segmenter) {
      const segmenter = new Intl.Segmenter('ne', { granularity: 'grapheme' });
      return Array.from(segmenter.segment(text), s => s.segment);
    }
    // Fallback: Unicode regex for Indic conjuncts
    const regex = /(?:[\u0904-\u0939\u0958-\u0961](?:\u094D[\u0904-\u0939\u0958-\u0961])*[\u093E-\u094C\u0962\u0963]?[\u0901-\u0903]?)|[^\u0900-\u097F]/g;
    return text.match(regex) || text.split('');
  },

  /**
   * मोड अनुसार खेल सुरु गर्ने
   */
  startMode(mode = 'word', startIndex = 0) {
    this.currentMode = mode;
    this.isDailyMode = (mode === 'daily');

    if (this.isDailyMode) {
      const now = new Date();
      this.dailyDateStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
      const dailyObj = getDailyPuzzleForDate(this.dailyDateStr);
      this.activePuzzles = [dailyObj.puzzle];
      this.currentIndex = 0;
    } else {
      this.activePuzzles = getPuzzlesByType(mode);
      this.currentIndex = Math.max(0, Math.min(startIndex, this.activePuzzles.length - 1));
    }

    return this.loadPuzzle(this.currentIndex);
  },

  /**
   * निश्चित इन्डेक्सको पजल लोड गर्ने
   */
  loadPuzzle(index) {
    if (!this.activePuzzles || this.activePuzzles.length === 0) return null;
    this.currentIndex = index;
    this.currentPuzzle = this.activePuzzles[index];
    this.selectedLetters = [];
    this.eliminatedOptions = [];
    this.isProcessingHint = false;

    // यदि शब्द पजल हो भने अक्षरहरू तयार गर्ने
    if (this.currentPuzzle.type === 'word') {
      if (this.currentPuzzle.scrambledLetters && this.currentPuzzle.scrambledLetters.length > 0) {
        this.availableLetters = this.currentPuzzle.scrambledLetters.map((char, i) => ({
          id: `letter_${i}`,
          char: char,
          used: false,
          eliminated: false
        }));
      } else {
        // स्वतः देवनागरी ग्रेफिमहरू छुट्ट्याउने
        const chars = this.splitGraphemes(this.currentPuzzle.answer);
        // केही अतिरिक्त अक्षर थप्ने
        const distractors = ['क', 'म', 'र', 'ल', 'स', 'न', 'प'];
        const combined = [...chars, ...distractors.slice(0, 3)].sort(() => Math.random() - 0.5);
        this.availableLetters = combined.map((char, i) => ({
          id: `letter_${i}`,
          char: char,
          used: false,
          eliminated: false
        }));
      }
    }

    return this.currentPuzzle;
  },

  /**
   * अक्षर छनोट गर्ने (Word Puzzle)
   */
  selectLetter(letterId) {
    const item = this.availableLetters.find(l => l.id === letterId);
    if (!item || item.used || item.eliminated) return false;

    item.used = true;
    this.selectedLetters.push(item);
    this.triggerHaptic(20);
    return true;
  },

  /**
   * छनोट गरिएको अक्षर फिर्ता गर्ने
   */
  deselectLetter(letterId) {
    const idx = this.selectedLetters.findIndex(l => l.id === letterId);
    if (idx === -1) return false;

    const [removed] = this.selectedLetters.splice(idx, 1);
    const item = this.availableLetters.find(l => l.id === removed.id);
    if (item) item.used = false;
    this.triggerHaptic(15);
    return true;
  },

  /**
   * सबै अक्षर खाली गर्ने
   */
  clearSelectedLetters() {
    this.selectedLetters.forEach(l => {
      const item = this.availableLetters.find(a => a.id === l.id);
      if (item) item.used = false;
    });
    this.selectedLetters = [];
    this.triggerHaptic(20);
  },

  /**
   * अक्षरहरू फेरबदल (Shuffle) गर्ने
   */
  shuffleAvailableLetters() {
    this.availableLetters.sort(() => Math.random() - 0.5);
    this.triggerHaptic(30);
  },

  /**
   * उत्तर प्रमाणीकरण गर्ने
   */
  checkAnswer(submittedAnswer) {
    if (!this.currentPuzzle) return { isCorrect: false };

    let candidate = '';
    if (this.currentPuzzle.type === 'word') {
      candidate = this.selectedLetters.map(l => l.char).join('');
    } else {
      candidate = submittedAnswer || '';
    }

    const normCandidate = this.normalizeText(candidate);
    const normCorrect = this.normalizeText(this.currentPuzzle.answer);

    // सम्भावित मान्य रूपहरू (Accepted Variants) जाँच
    let isCorrect = (normCandidate === normCorrect);
    if (!isCorrect && this.currentPuzzle.acceptedVariants) {
      isCorrect = this.currentPuzzle.acceptedVariants.some(v => this.normalizeText(v) === normCandidate);
    }

    const state = StorageService.loadData();
    const alreadySolved = state.solvedIds.includes(this.currentPuzzle.id);

    if (isCorrect) {
      if (state.soundEnabled) SoundFX.playCorrect();
      this.triggerHaptic(60);

      let pointsAwarded = 0;
      let coinsAwarded = 0;

      // यदि पहिले हल भइसकेको छैन भने मात्र स्कोर र सिक्का दिने
      if (!alreadySolved) {
        pointsAwarded = 10;
        if (this.currentPuzzle.difficulty === 'मध्यम') pointsAwarded += 5;
        if (this.currentPuzzle.difficulty === 'कठिन') pointsAwarded += 10;

        // स्ट्रिक बोनस (अधिकतम +१०)
        const streakBonus = Math.min(state.currentStreak * 2, 10);
        pointsAwarded += streakBonus;
        coinsAwarded = 5;

        // दैनिक चुनौती हो भने विशेष बोनस
        if (this.isDailyMode) {
          const dailyRes = StorageService.completeDailyChallenge(this.dailyDateStr, 30);
          if (dailyRes.rewarded) {
            coinsAwarded += 30;
            pointsAwarded += 25;
          }
        }

        StorageService.recordSolve(this.currentPuzzle.id, this.currentPuzzle.type, pointsAwarded, coinsAwarded);
      }

      return {
        isCorrect: true,
        alreadySolved,
        pointsAwarded,
        coinsAwarded,
        explanation: this.currentPuzzle.explanation,
        correctAnswer: this.currentPuzzle.answer
      };
    } else {
      if (state.soundEnabled) SoundFX.playWrong();
      this.triggerHaptic([40, 60, 40]);
      StorageService.recordWrongAnswer();
      return {
        isCorrect: false,
        alreadySolved,
        message: 'उत्तर मिलेन! पुनः प्रयास गर्नुहोस् वा सङ्केत लिनुहोस्।'
      };
    }
  },

  /**
   * सङ्केत १: सुत्र/क्लु देखाउने (५ सिक्का)
   */
  useClueHint() {
    if (this.isProcessingHint) return { success: false, reason: 'कृपया पर्खनुहोस्' };
    this.isProcessingHint = true;
    const res = StorageService.modifyCoins(-5);
    this.isProcessingHint = false;

    if (!res.success) {
      return { success: false, reason: 'पर्याप्त सिक्का छैन (५ सिक्का चाहिन्छ)' };
    }
    this.triggerHaptic(30);
    return { success: true, clue: this.currentPuzzle.hint, coins: res.currentCoins };
  },

  /**
   * सङ्केत २: गलत विकल्पहरू हटाउने (१० सिक्का)
   */
  useEliminateHint() {
    if (this.isProcessingHint) return { success: false, reason: 'कृपया पर्खनुहोस्' };
    this.isProcessingHint = true;

    // यदि पहिले नै हटाइसकिएको छ भने
    if (this.eliminatedOptions.length > 0) {
      this.isProcessingHint = false;
      return { success: false, reason: 'गलत विकल्पहरू हटाइसकिएको छ' };
    }

    const res = StorageService.modifyCoins(-10);
    this.isProcessingHint = false;

    if (!res.success) {
      return { success: false, reason: 'पर्याप्त सिक्का छैन (१० सिक्का चाहिन्छ)' };
    }

    // बहुवैकल्पिक भए गलत २ वटा विकल्प हटाउने
    if (this.currentPuzzle.options && this.currentPuzzle.options.length > 2) {
      const wrong = this.currentPuzzle.options.filter(opt => this.normalizeText(opt) !== this.normalizeText(this.currentPuzzle.answer));
      const toRemove = wrong.slice(0, 2);
      this.eliminatedOptions = toRemove;
      this.triggerHaptic(40);
      return { success: true, eliminatedOptions: toRemove, coins: res.currentCoins };
    }

    // शब्द पजल भए उत्तरमा नपर्ने २ वटा अक्षर हटाउने
    if (this.currentPuzzle.type === 'word' && this.availableLetters.length > 0) {
      const correctGraphemes = this.splitGraphemes(this.currentPuzzle.answer);
      const distractors = this.availableLetters.filter(l => !correctGraphemes.includes(l.char) && !l.used && !l.eliminated);
      const toEliminate = distractors.slice(0, 2);
      toEliminate.forEach(l => l.eliminated = true);
      this.triggerHaptic(40);
      return { success: true, eliminatedLetters: toEliminate.map(l => l.id), coins: res.currentCoins };
    }

    return { success: false, reason: 'यस प्रश्नमा विकल्प हटाउन मिल्दैन' };
  },

  /**
   * सङ्केत ३: सही अक्षर वा उत्तर पत्ता लगाउने (१५ सिक्का)
   */
  useRevealLetterHint() {
    if (this.isProcessingHint) return { success: false, reason: 'कृपया पर्खनुहोस्' };
    this.isProcessingHint = true;

    const res = StorageService.modifyCoins(-15);
    this.isProcessingHint = false;

    if (!res.success) {
      return { success: false, reason: 'पर्याप्त सिक्का छैन (१५ सिक्का चाहिन्छ)' };
    }

    if (this.currentPuzzle.type === 'word') {
      const targetGraphemes = this.splitGraphemes(this.currentPuzzle.answer);
      const currentCount = this.selectedLetters.length;
      if (currentCount < targetGraphemes.length) {
        const nextChar = targetGraphemes[currentCount];
        // उपलब्ध अक्षरहरूबाट खोज्ने
        const letterObj = this.availableLetters.find(l => l.char === nextChar && !l.used);
        if (letterObj) {
          this.selectLetter(letterObj.id);
        }
      }
      this.triggerHaptic(50);
      return { success: true, coins: res.currentCoins };
    } else {
      // बहुवैकल्पिकमा सही उत्तर औँल्याइदिने
      this.triggerHaptic(50);
      return { success: true, directAnswer: this.currentPuzzle.answer, coins: res.currentCoins };
    }
  },

  /**
   * अर्को प्रश्नमा जाने
   */
  nextPuzzle() {
    if (this.currentIndex < this.activePuzzles.length - 1) {
      return this.loadPuzzle(this.currentIndex + 1);
    }
    return null; // यस श्रेणीका प्रश्नहरू समाप्त भए
  },

  triggerHaptic(pattern) {
    if (typeof navigator !== 'undefined' && navigator.vibrate) {
      try { navigator.vibrate(pattern); } catch (e) {}
    }
    // यदि एन्ड्रोइड ब्रिज उपलब्ध छ भने
    if (typeof window !== 'undefined' && window.AndroidAdMobBridge && window.AndroidAdMobBridge.vibrateHaptic) {
      try {
        const ms = Array.isArray(pattern) ? pattern[0] : pattern;
        window.AndroidAdMobBridge.vibrateHaptic(ms || 30);
      } catch (e) {}
    }
  }
};

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { GameEngine, SoundFX };
}
