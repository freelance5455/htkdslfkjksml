/**
 * ad-service.js
 * गुगल एडमोब (Google AdMob) विज्ञापन सेवा इन्टरफेस र एब्स्ट्र्याक्सन
 * वेब ब्राउजरमा टेस्ट सिम्युलेटर र एन्ड्रोइड नेटिभ एपमा वास्तविक AdMob SDK सँग जोड्छ।
 */

const AdService = {
  isInitialized: false,
  isNativeAndroid: false,
  interstitialCooldownCount: 0,
  INTERSTITIAL_LEVEL_INTERVAL: 3, // हरेक ३ स्तर समाप्तिमा मात्र फुल-स्क्रिन विज्ञापन
  lastInterstitialTime: 0,
  MIN_INTERSTITIAL_GAP_MS: 90000, // कम्तिमा ९० सेकेन्डको अन्तर

  // गुगलका आधिकारिक आधिकारिक परीक्षण Ad Unit ID हरू
  TEST_AD_UNITS: {
    APP_ID: 'ca-app-pub-3940256099942544~3347511713',
    BANNER: 'ca-app-pub-3940256099942544/6300978111',
    INTERSTITIAL: 'ca-app-pub-3940256099942544/1033173712',
    REWARDED: 'ca-app-pub-3940256099942544/5224354917'
  },

  /**
   * सेवा सुरु गर्ने
   */
  initialize() {
    this.isNativeAndroid = typeof window !== 'undefined' && 
      (window.AndroidAdMobBridge !== undefined || window.Capacitor !== undefined);
    
    console.log(`[AdService] सुरु भयो। वातावरण: ${this.isNativeAndroid ? 'एन्ड्रोइड नेटिभ (Android Bridge)' : 'वेब ब्राउजर (Test Simulator)'}`);
    this.isInitialized = true;

    // एन्ड्रोइडबाट प्राप्त हुने कलब्याकहरू विन्डोमा दर्ता गर्ने
    if (typeof window !== 'undefined') {
      window._adServiceInstance = this;
    }
  },

  /**
   * ब्यानर विज्ञापन देखाउने
   */
  showBanner(containerId = 'admob-banner-container') {
    if (!this.isInitialized) this.initialize();

    if (this.isNativeAndroid && window.AndroidAdMobBridge && window.AndroidAdMobBridge.showBannerAd) {
      try {
        window.AndroidAdMobBridge.showBannerAd();
        return;
      } catch (e) {
        console.warn('नेटिभ ब्यानर देखाउन असमर्थ:', e);
      }
    }

    // वेब ब्राउजर सिमुलेटर
    const container = document.getElementById(containerId);
    if (container) {
      container.innerHTML = `
        <div class="admob-simulated-banner">
          <span class="ad-badge">गुगल परीक्षण विज्ञापन</span>
          <span class="ad-content">📢 AdMob Test Banner • ३२० × ५०</span>
          <button class="ad-info-btn" onclick="AdService.showAdInfoModal()" title="विज्ञापन जानकारी">ℹ️</button>
        </div>
      `;
      container.style.display = 'block';
    }
  },

  /**
   * ब्यानर विज्ञापन लुकाउने
   */
  hideBanner(containerId = 'admob-banner-container') {
    if (this.isNativeAndroid && window.AndroidAdMobBridge && window.AndroidAdMobBridge.hideBannerAd) {
      try {
        window.AndroidAdMobBridge.hideBannerAd();
        return;
      } catch (e) {
        console.warn('नेटिभ ब्यानर लुकाउन असमर्थ:', e);
      }
    }
    const container = document.getElementById(containerId);
    if (container) {
      container.style.display = 'none';
      container.innerHTML = '';
    }
  },

  /**
   * रिवार्डेड विज्ञापन देखाउने (पुरस्कारको लागि भिडियो)
   * @param {Function} onRewarded - पुरस्कार प्राप्त भएपछि चल्ने कलब्याक
   * @param {Function} onFailure - विज्ञापन रद्द वा असफल हुँदा चल्ने कलब्याक
   */
  showRewardedAd(onRewarded, onFailure) {
    if (!this.isInitialized) this.initialize();

    if (this.isNativeAndroid && window.AndroidAdMobBridge && window.AndroidAdMobBridge.showRewardedAd) {
      this._pendingRewardedSuccess = onRewarded;
      this._pendingRewardedFailure = onFailure;
      try {
        window.AndroidAdMobBridge.showRewardedAd();
        return;
      } catch (e) {
        console.error('नेटिभ रिवार्ड विज्ञापन त्रुटि:', e);
        if (onFailure) onFailure('नेटिभ लोड त्रुटि');
      }
    }

    // वेब ब्राउजर परीक्षण सिमुलेटर मोडाल
    this._renderBrowserRewardedAdModal(onRewarded, onFailure);
  },

  /**
   * इन्टरस्टिसियल (पूर्ण स्क्रिन) विज्ञापन देखाउने (नियम र सीमा अनुसार मात्र)
   */
  showInterstitialIfEligible(onDismissed) {
    this.interstitialCooldownCount += 1;
    const now = Date.now();
    const timeDiff = now - this.lastInterstitialTime;

    // कम्तिमा ३ स्तर पूरा भएको र ९० सेकेन्डको अन्तर पुगेको हुनुपर्छ
    if (this.interstitialCooldownCount >= this.INTERSTITIAL_LEVEL_INTERVAL && timeDiff >= this.MIN_INTERSTITIAL_GAP_MS) {
      this.interstitialCooldownCount = 0;
      this.lastInterstitialTime = now;

      if (this.isNativeAndroid && window.AndroidAdMobBridge && window.AndroidAdMobBridge.showInterstitialAd) {
        this._pendingInterstitialDismiss = onDismissed;
        try {
          window.AndroidAdMobBridge.showInterstitialAd();
          return;
        } catch (e) {
          console.warn('नेटिभ इन्टरस्टिसियल देखाउन असमर्थ:', e);
        }
      }

      // वेब ब्राउजर परीक्षण मोडल
      this._renderBrowserInterstitialModal(onDismissed);
    } else {
      // योग्यता नपुगेको भए तुरुन्तै खेल जारी राख्ने
      if (onDismissed) onDismissed();
    }
  },

  /**
   * ब्राउजर विकास मोडमा रिवार्डेड विज्ञापन सिमुलेसन
   */
  _renderBrowserRewardedAdModal(onRewarded, onFailure) {
    const modal = document.createElement('div');
    modal.className = 'ad-modal-overlay';
    modal.id = 'browser-ad-modal';

    let countdown = 5;
    modal.innerHTML = `
      <div class="ad-modal-card">
        <div class="ad-modal-header">
          <span class="ad-tag">गुगल एडमोब टेस्ट सिम्युलेटर</span>
          <button class="ad-close-btn" id="ad-sim-close" disabled title="भिडियो समाप्त भएपछि बन्द गर्न सकिनेछ">✕</button>
        </div>
        <div class="ad-modal-body">
          <div class="ad-video-mock">
            <div class="ad-play-icon">🎬</div>
            <h3>परीक्षण विज्ञापन चलिरहेको छ...</h3>
            <p>मोबाइलमा यहाँ वास्तविक Google AdMob भिडियो विज्ञापन बज्नेछ।</p>
            <div class="ad-countdown-ring" id="ad-countdown">${countdown}s</div>
          </div>
          <div class="ad-reward-note">
            🎁 भिडियो सकिएपछि <strong>+२५ सिक्का</strong> पुरस्कार प्राप्त हुनेछ!
          </div>
        </div>
      </div>
    `;
    document.body.appendChild(modal);

    const countdownEl = document.getElementById('ad-countdown');
    const closeBtn = document.getElementById('ad-sim-close');

    const timer = setInterval(() => {
      countdown -= 1;
      if (countdownEl) countdownEl.textContent = `${countdown}s`;
      if (countdown <= 0) {
        clearInterval(timer);
        if (countdownEl) countdownEl.textContent = 'सम्पन्न! 🎉';
        if (closeBtn) {
          closeBtn.disabled = false;
          closeBtn.classList.add('active');
        }
        setTimeout(() => {
          this._closeBrowserModal();
          if (onRewarded) onRewarded({ amount: 25, type: 'coins' });
        }, 1200);
      }
    }, 1000);

    closeBtn.onclick = () => {
      clearInterval(timer);
      this._closeBrowserModal();
      if (countdown <= 0 && onRewarded) {
        onRewarded({ amount: 25, type: 'coins' });
      } else if (onFailure) {
        onFailure('विज्ञापन पूरा हेरिएन');
      }
    };
  },

  /**
   * ब्राउजर विकास मोडमा इन्टरस्टिसियल विज्ञापन सिमुलेसन
   */
  _renderBrowserInterstitialModal(onDismissed) {
    const modal = document.createElement('div');
    modal.className = 'ad-modal-overlay';
    modal.id = 'browser-interstitial-modal';

    modal.innerHTML = `
      <div class="ad-modal-card interstitial">
        <div class="ad-modal-header">
          <span class="ad-tag">गुगल एडमोब इन्टरस्टिसियल टेस्ट</span>
          <button class="ad-close-btn active" id="ad-interstitial-close">✕ बन्द गर्नुहोस्</button>
        </div>
        <div class="ad-modal-body">
          <div class="ad-banner-placeholder">
            <h2>🎉 बधाई छ! स्तर सफलतापूर्वक पार भयो</h2>
            <p>यो स्क्रिन प्राकृतिक विश्राममा मात्र देखाइने पूर्ण स्क्रिन विज्ञापनको नमुना हो।</p>
            <small>AdMob Interstitial Unit: ${this.TEST_AD_UNITS.INTERSTITIAL}</small>
          </div>
        </div>
      </div>
    `;
    document.body.appendChild(modal);

    document.getElementById('ad-interstitial-close').onclick = () => {
      const el = document.getElementById('browser-interstitial-modal');
      if (el) el.remove();
      if (onDismissed) onDismissed();
    };
  },

  _closeBrowserModal() {
    const el = document.getElementById('browser-ad-modal');
    if (el) el.remove();
  },

  showAdInfoModal() {
    alert(
      'विज्ञापन जानकारी:\n\n' +
      'यस खेलमा खेलाडीलाई अवरोध नहुने गरी गुगल एडमोब (Google AdMob) का आधिकारिक टेस्ट विज्ञापनहरू प्रयोग गरिएको छ।\n\n' +
      '• ब्यानर: स्क्रिनको तल्लो भागमा खेललाई असर नगर्ने गरी\n' +
      '• रिवार्डेड: ऐच्छिक संकेत वा सिक्का प्राप्त गर्न खेलाडीको रोजाइमा मात्र\n' +
      '• इन्टरस्टिसियल: निश्चित स्तर समाप्तिपछि मात्र\n\n' +
      'कुनै पनि वास्तविक पैसा वा जुवा समावेश छैन।'
    );
  },

  // नेटिभ एन्ड्रोइड ब्रिजबाट कल गरिने मेथडहरू
  handleNativeRewardEarned(rewardAmount) {
    console.log('[AdService] नेटिभ विज्ञापनबाट पुरस्कार प्राप्त भयो:', rewardAmount);
    if (this._pendingRewardedSuccess) {
      this._pendingRewardedSuccess({ amount: rewardAmount || 25, type: 'coins' });
      this._pendingRewardedSuccess = null;
    }
  },

  handleNativeRewardFailed(reason) {
    console.warn('[AdService] नेटिभ विज्ञापन असफल वा रद्द:', reason);
    if (this._pendingRewardedFailure) {
      this._pendingRewardedFailure(reason);
      this._pendingRewardedFailure = null;
    }
  },

  handleNativeInterstitialDismissed() {
    if (this._pendingInterstitialDismiss) {
      this._pendingInterstitialDismiss();
      this._pendingInterstitialDismiss = null;
    }
  }
};

// विश्वव्यापी विन्डो कलब्याकहरू
if (typeof window !== 'undefined') {
  window.onNativeRewardedAdCompleted = function(amount) {
    AdService.handleNativeRewardEarned(amount);
  };
  window.onNativeRewardedAdFailed = function(reason) {
    AdService.handleNativeRewardFailed(reason);
  };
  window.onNativeInterstitialDismissed = function() {
    AdService.handleNativeInterstitialDismissed();
  };
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { AdService };
}
