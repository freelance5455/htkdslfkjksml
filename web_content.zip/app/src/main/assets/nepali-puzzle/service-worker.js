/**
 * service-worker.js
 * अफलाइन गेमप्लेका लागि PWA क्यास व्यवस्थापन
 */

const CACHE_NAME = 'nepali-puzzle-cache-v1';
const ASSETS_TO_CACHE = [
  './',
  './index.html',
  './style.css',
  './app.js',
  './questions.js',
  './storage.js',
  './game-engine.js',
  './ad-service.js',
  './manifest.json',
  './privacy-policy.html',
  './assets/icons/icon-192.png',
  './assets/icons/icon-512.png',
  './assets/icons/favicon.png'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      console.log('[ServiceWorker] मुख्य फाइलहरू क्यास गरिँदैछ...');
      return cache.addAll(ASSETS_TO_CACHE);
    }).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) => {
      return Promise.all(
        keys.map((key) => {
          if (key !== CACHE_NAME) {
            console.log('[ServiceWorker] पुरानो क्यास हटाइयो:', key);
            return caches.delete(key);
          }
        })
      );
    }).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  // विज्ञापन वा बाह्य API हरू क्यास नगर्ने
  const url = new URL(event.request.url);
  if (url.origin !== self.location.origin || url.pathname.includes('/ads/') || url.hostname.includes('google')) {
    return;
  }

  event.respondWith(
    caches.match(event.request).then((cachedResponse) => {
      if (cachedResponse) {
        return cachedResponse;
      }
      return fetch(event.request).catch(() => {
        // अफलाइन हुँदा fallback
        if (event.request.mode === 'navigate') {
          return caches.match('./index.html');
        }
      });
    })
  );
});
