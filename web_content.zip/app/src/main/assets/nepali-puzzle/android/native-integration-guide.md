# Native Android & Google AdMob Integration Guide
## नेपाली पजल — दिमाग खेल

यो गाइडले तपाईंलाई यो वेब-आधारित नेपाली पजल गेमलाई उत्पादन-स्तरको एन्ड्रोइड एप्लिकेसनमा प्याकेज गरी वास्तविक गुगल एडमोब (Google AdMob) सँग कसरी जोड्ने भन्ने चरणबद्ध निर्देशन दिन्छ।

---

### चरण १: `build.gradle.kts` मा AdMob SDK थप्ने

तपाईंको `app/build.gradle.kts` मा Google Play Services Ads SDK थप्नुहोस्:

```kotlin
dependencies {
    // Official Google Mobile Ads SDK
    implementation("com.google.android.gms:play-services-ads:23.6.0")
    
    // Core AndroidX & Compose
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.compose.material3)
}
```

---

### चरण २: `AndroidManifest.xml` कन्फिगरेसन

`app/src/main/AndroidManifest.xml` मा इन्टरनेट अनुमति र AdMob Application ID थप्नुहोस्:

```xml
<manifest xmlns:android="http://schemas.android.com/apk/res/android">
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.VIBRATE" />

    <application
        android:label="@string/app_name"
        android:icon="@mipmap/ic_launcher"
        android:roundIcon="@mipmap/ic_launcher_round">

        <!-- गुगल एडमोब टेस्ट एप आईडी (उत्पादनमा आफ्नै वास्तविक App ID राख्नुहोस्) -->
        <meta-data
            android:name="com.google.android.gms.ads.APPLICATION_ID"
            android:value="ca-app-pub-3940256099942544~3347511713" />

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:screenOrientation="portrait"
            android:configChanges="orientation|screenSize|keyboardHidden">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>
```

---

### चरण ३: JavaScriptInterface (`AndroidAdMobBridge.kt`)

वेब गेम र नेटिभ एन्ड्रोइड AdMob बीच सञ्चार गर्न निम्न जाभास्क्रिप्ट ब्रिज क्लास तयार गर्नुहोस्:

```kotlin
package com.example

import android.app.Activity
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.widget.Toast
import com.google.android.gms.ads.*
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback

class AndroidAdMobBridge(
    private val activity: Activity,
    private val webView: WebView
) {
    private var rewardedAd: RewardedAd? = null
    private var interstitialAd: InterstitialAd? = null

    init {
        loadRewardedAd()
        loadInterstitialAd()
    }

    private fun loadRewardedAd() {
        val adRequest = AdRequest.Builder().build()
        // आधिकारिक Google Rewarded Test Unit ID
        RewardedAd.load(activity, "ca-app-pub-3940256099942544/5224354917", adRequest,
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    rewardedAd = ad
                }
                override fun onAdFailedToLoad(error: LoadAdError) {
                    rewardedAd = null
                }
            })
    }

    private fun loadInterstitialAd() {
        val adRequest = AdRequest.Builder().build()
        // आधिकारिक Google Interstitial Test Unit ID
        InterstitialAd.load(activity, "ca-app-pub-3940256099942544/1033173712", adRequest,
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    interstitialAd = ad
                }
                override fun onAdFailedToLoad(error: LoadAdError) {
                    interstitialAd = null
                }
            })
    }

    @JavascriptInterface
    fun showRewardedAd() {
        activity.runOnUiThread {
            if (rewardedAd != null) {
                rewardedAd?.show(activity) { rewardItem ->
                    val amount = rewardItem.amount
                    // JavaScript मा पुरस्कार सूचना पठाउने
                    webView.evaluateJavascript("window.onNativeRewardedAdCompleted($amount);", null)
                    loadRewardedAd() // अर्कोको लागि पूर्व-लोड
                }
            } else {
                Toast.makeText(activity, "विज्ञापन लोड हुँदैछ, कृपया एकछिन पर्खनुहोस्...", Toast.LENGTH_SHORT).show()
                webView.evaluateJavascript("window.onNativeRewardedAdFailed('विज्ञापन तयार छैन');", null)
                loadRewardedAd()
            }
        }
    }

    @JavascriptInterface
    fun showInterstitialAd() {
        activity.runOnUiThread {
            if (interstitialAd != null) {
                interstitialAd?.fullScreenContentCallback = object : FullScreenContentCallback() {
                    override fun onAdDismissedFullScreenContent() {
                        webView.evaluateJavascript("window.onNativeInterstitialDismissed();", null)
                        loadInterstitialAd()
                    }
                    override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                        webView.evaluateJavascript("window.onNativeInterstitialDismissed();", null)
                        loadInterstitialAd()
                    }
                }
                interstitialAd?.show(activity)
            } else {
                webView.evaluateJavascript("window.onNativeInterstitialDismissed();", null)
                loadInterstitialAd()
            }
        }
    }

    @JavascriptInterface
    fun vibrateHaptic(durationMs: Long) {
        val vibrator = activity.getSystemService(Activity.VIBRATOR_SERVICE) as? Vibrator
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator?.vibrate(VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION")
            vibrator?.vibrate(durationMs)
        }
    }
}
```

---

### चरण ४: उत्पादनमा जानुअघि चेकलिस्ट (Publishing Checklist)

1. **AdMob खातामा नयाँ App सिर्जना गर्नुहोस्:**
   - AdMob कन्सोलमा जानुहोस् (https://apps.admob.com).
   - "Add App" मा क्लिक गरी Android छान्नुहोस्।
   - ब्यानर, इन्टरस्टिसियल, र रिवार्डेड Ad Unit हरू बनाउनुहोस्।
2. **टेस्ट आईडीहरू बदल्नुहोस्:**
   - `AndroidManifest.xml` मा आफ्नो वास्तविक `APPLICATION_ID` राख्नुहोस्।
   - कोडमा आफ्नो वास्तविक Ad Unit ID हरू प्रतिस्थापन गर्नुहोस्।
3. **App-ads.txt:**
   - तपाईंको वेबसाइट वा होस्टिङ रुटमा Google द्वारा प्रदान गरिएको `app-ads.txt` फाइल राख्नुहोस्।
4. **गुगल प्ले कन्सोलमा रिलिज:**
   - Signed Android App Bundle (`.aab`) निर्माण गर्नुहोस्।
   - कन्सोलमा डाटा सुरक्षा (Data Safety) फारम भर्दा AdMob ले विज्ञापन आईडी प्रयोग गर्छ भनी उल्लेख गर्नुहोस्।
