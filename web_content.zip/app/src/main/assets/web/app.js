/* EC Technologie — V4 PRO
 * Version corrigée : données numériques robustes, stock/marge, logo,
 * documents, aperçu, sauvegarde et synchronisation.
 */
'use strict';

const KEY = 'ec-tech-v4';
const LEGACY_KEY = 'ec-tech-v3';
const DEFAULT = {
  products: [], docs: [], purchases: [], contacts: [], expenses: [], log: [],
  settings: {
    name: 'EC Technologie', currency: 'Ar', defaultTax: 20,
    prefixDEV: 'DEV', prefixPRO: 'PRO', prefixBL: 'BL', prefixFAC: 'FAC',
    themeColor: '#0f6b43', paper: 'landscape', tableTheme: 'grid',
    docModel: 'classic', dashboardModel: 'manager', theme: 'classic',
    logo: '', logoPosition: 'right', logoSize: 'medium',
    supabaseUrl: '', supabaseKey: '', deviceName: '', cloudEmail: '', cloudSession: null, cloudUserId: '', cloudRevision: 0, syncBase: null
  }
};

const $ = id => document.getElementById(id);
const clone = obj => JSON.parse(JSON.stringify(obj));
const uid = () => (globalThis.crypto && typeof crypto.randomUUID === 'function') ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`;

function num(value) {
  if (typeof value === 'number') return Number.isFinite(value) ? value : 0;
  let s = String(value ?? '').trim();
  if (!s) return 0;
  s = s.replace(/[\u00A0\u202F\s']/g, '').replace(/[^0-9,.-]/g, '');
  const commas = (s.match(/,/g) || []).length;
  const dots = (s.match(/\./g) || []).length;
  if (commas && dots) {
    if (s.lastIndexOf(',') > s.lastIndexOf('.')) s = s.replace(/\./g, '').replace(',', '.');
    else s = s.replace(/,/g, '');
  } else if (commas || dots) {
    const sep = commas ? ',' : '.';
    const count = commas || dots;
    if (count > 1) s = s.split(sep).join('');
    else {
      const pos = s.lastIndexOf(sep);
      const decimals = s.length - pos - 1;
      // For Ariary/business entry, 5.000 / 5,000 means 5 000, not 5.
      if (decimals === 3 && pos > 0) s = s.replace(sep, '');
      else if (sep === ',') s = s.replace(',', '.');
    }
  }
  const n = Number(s);
  return Number.isFinite(n) ? n : 0;
}

function normalizeProduct(p = {}) {
  const buy = num(p.buy);
  const marginPct = p.marginPct !== undefined && p.marginPct !== null
    ? num(p.marginPct)
    : (buy > 0 && num(p.sell) > 0 ? ((num(p.sell) - buy) / buy) * 100 : 0);
  const manualSell = !!p.manualSell;
  const sell = manualSell ? num(p.sell) : buy * (1 + marginPct / 100);
  return {
    ...p,
    ref: String(p.ref || '').trim(),
    name: String(p.name || '').trim(),
    buy,
    sell: Math.round(sell),
    marginPct,
    manualSell,
    qty: Math.max(0, num(p.qty)),
    min: Math.max(0, num(p.min)),
    tax: Math.max(0, num(p.tax))
  };
}

function load() {
  try {
    const current = localStorage.getItem(KEY);
    const legacy = localStorage.getItem(LEGACY_KEY);
    const raw = JSON.parse(current || legacy || '{}');
    if (!current && legacy) localStorage.setItem(KEY, legacy);
    const d = {
      ...clone(DEFAULT), ...raw,
      settings: { ...DEFAULT.settings, ...(raw.settings || {}) },
      products: Array.isArray(raw.products) ? raw.products.map(normalizeProduct) : [],
      docs: Array.isArray(raw.docs) ? raw.docs : [],
      purchases: Array.isArray(raw.purchases) ? raw.purchases : [],
      contacts: Array.isArray(raw.contacts) ? raw.contacts : [],
      expenses: Array.isArray(raw.expenses) ? raw.expenses : [],
      log: Array.isArray(raw.log) ? raw.log : []
    };
    return d;
  } catch (_) { return clone(DEFAULT); }
}

let db = load();
let editingId = null;

let syncTimer = null;
function save(options = {}) {
  db.products = db.products.map(normalizeProduct);
  localStorage.setItem(KEY, JSON.stringify(db));
  renderAll();
  if (!options.noCloud) scheduleCloudSync();
}

function cloudCfg(){ return {url:String(db.settings.supabaseUrl||'').replace(/\/$/,''), key:db.settings.supabaseKey||'', session:db.settings.cloudSession||null}; }
function cloudReady(){ const c=cloudCfg(); return !!(c.url && c.key); }
function setCloudState(text, cls=''){ if($('cloudState')){ $('cloudState').textContent=text; $('cloudState').className='cloud-state '+cls; } }
function setSyncStatus(text){ if($('syncStatus')) $('syncStatus').textContent=text; }
function cloudHeaders(access){ const c=cloudCfg(); return {'apikey':c.key,'Authorization':`Bearer ${access||c.session?.access_token||c.key}`,'Content-Type':'application/json'}; }
async function cloudFetch(path, opts={}){ const c=cloudCfg(); if(!c.url||!c.key) throw Error('Cloud non configuré.'); const r=await fetch(c.url+path,{...opts,headers:{...cloudHeaders(),...(opts.headers||{})}}); const txt=await r.text(); let body=null; try{body=txt?JSON.parse(txt):null}catch{} if(!r.ok) throw Error(body?.msg||body?.message||body?.error_description||`HTTP ${r.status}`); return body; }

function syncSnapshot(){ const x=clone(db); x.settings={...x.settings,cloudSession:null,supabaseKey:'',supabaseUrl:'',cloudRevision:0,syncBase:null}; return x; }
function entityKey(x){ return String(x?.id || x?.ref || x?.num || x?.code || JSON.stringify(x)); }
function same(a,b){ return JSON.stringify(a)===JSON.stringify(b); }
function mergeArray(local, server, base){
  const L=Array.isArray(local)?local:[], S=Array.isArray(server)?server:[], B=Array.isArray(base)?base:[];
  const bm=new Map(B.map(x=>[entityKey(x),x])), lm=new Map(L.map(x=>[entityKey(x),x])), sm=new Map(S.map(x=>[entityKey(x),x]));
  const keys=new Set([...bm.keys(),...lm.keys(),...sm.keys()]); const out=[];
  for(const k of keys){ const l=lm.get(k), sv=sm.get(k), b=bm.get(k);
    if(l && !sv && b && !same(l,b)){ out.push(l); continue; }
    if(sv && !l && b && !same(sv,b)){ out.push(sv); continue; }
    if(l && sv){ if(b && same(l,b)) out.push(sv); else if(b && same(sv,b)) out.push(l); else out.push(l); }
    else if(l) out.push(l); else if(sv) out.push(sv);
  }
  return out;
}
function mergeCloudData(local, server, base){
  const merged={...clone(DEFAULT),...server,settings:{...DEFAULT.settings,...(server?.settings||{})}};
  for(const k of ['products','docs','purchases','contacts','expenses','log']) merged[k]=mergeArray(local?.[k],server?.[k],base?.[k]);
  // Cloud never stores runtime credentials/session metadata. Preserve those locally.
  const runtime={supabaseUrl:local?.settings?.supabaseUrl||'',supabaseKey:local?.settings?.supabaseKey||'',cloudSession:local?.settings?.cloudSession||null,cloudEmail:local?.settings?.cloudEmail||'',cloudUserId:local?.settings?.cloudUserId||'',deviceName:local?.settings?.deviceName||'',cloudRevision:Number(server?.settings?.cloudRevision||0),syncBase:null};
  // Local UI/company settings win only when they changed since the last sync; otherwise take server settings.
  const localChanged=base ? !same(local?.settings,base.settings) : false;
  merged.settings = localChanged ? {...DEFAULT.settings,...server.settings,...local.settings,...runtime} : {...DEFAULT.settings,...server.settings,...runtime};
  return merged;
}
async function refreshCloudSession(){
  const c=cloudCfg(); if(!c.session?.refresh_token) return false;
  try{ const body=await fetch(c.url+'/auth/v1/token?grant_type=refresh_token',{method:'POST',headers:{'apikey':c.key,'Content-Type':'application/json'},body:JSON.stringify({refresh_token:c.session.refresh_token})}); const j=await body.json(); if(!body.ok) throw Error(j.error_description||j.msg||'Session expirée'); db.settings.cloudSession=j; db.settings.cloudUserId=j.user?.id||db.settings.cloudUserId; localStorage.setItem(KEY,JSON.stringify(db)); return true; }catch(e){ db.settings.cloudSession=null; localStorage.setItem(KEY,JSON.stringify(db)); return false; }
}
async function cloudAuth(mode){
  if(!cloudReady()) return alert('Enregistre d’abord l’URL et la clé publique Supabase.');
  const email=safeVal('cloudEmail').trim(), password=safeVal('cloudPassword'); if(!email||!password) return alert('E-mail et mot de passe obligatoires.');
  const c=cloudCfg(); setCloudState(mode==='signup'?'Création…':'Connexion…','busy');
  try{ const endpoint=mode==='signup'?'/auth/v1/signup':'/auth/v1/token?grant_type=password'; const body=mode==='signup'?{email,password}:{email,password}; const r=await fetch(c.url+endpoint,{method:'POST',headers:{'apikey':c.key,'Content-Type':'application/json'},body:JSON.stringify(body)}); const j=await r.json(); if(!r.ok) throw Error(j.msg||j.error_description||j.message||'Connexion impossible'); if(mode==='signup' && !j.access_token){ setSyncStatus('Compte créé. Vérifie ton e-mail si la confirmation est activée, puis connecte-toi.'); setCloudState('Compte créé'); return; } db.settings.cloudSession=j; db.settings.cloudUserId=j.user?.id||''; db.settings.cloudEmail=email; localStorage.setItem(KEY,JSON.stringify(db)); await registerDevice(); await cloudSync(true); setCloudState('Connecté','online'); }catch(e){setCloudState('Erreur','error');setSyncStatus(`Cloud : ${e.message}`);}
}
async function registerDevice(){
  if(!db.settings.cloudSession?.access_token) return;
  const name=(db.settings.deviceName||`${navigator.platform||'Appareil'} — ${navigator.userAgent.includes('Android')?'Android':'Windows/Web'}`).slice(0,80);
  const id=getDeviceId();
  const body=await cloudFetch('/rest/v1/rpc/register_device',{method:'POST',body:JSON.stringify({p_device_id:id,p_name:name})});
  if(body && body.ok===false) throw Error(body.message||'Limite de 5 appareils atteinte.');
}
function getDeviceId(){ let id=localStorage.getItem('ec-tech-device-id'); if(!id){id=uid();localStorage.setItem('ec-tech-device-id',id);} return id; }
async function cloudSync(force=false){
  if(!cloudReady() || !db.settings.cloudSession?.access_token) return;
  if(!navigator.onLine) {setCloudState('Hors ligne');setSyncStatus('Hors connexion : données conservées localement.');return;}
  setCloudState('Synchronisation…','busy');
  try{
    if(Date.now() > (db.settings.cloudSession.expires_at||0)*1000-60000) await refreshCloudSession();
    if(!db.settings.cloudSession?.access_token) throw Error('Session expirée.');
    await registerDevice();
    const base=db.settings.syncBase || null;
    const payload={p_base_revision:Number(db.settings.cloudRevision||0),p_data:syncSnapshot(),p_device_id:getDeviceId()};
    const result=await cloudFetch('/rest/v1/rpc/sync_data',{method:'POST',body:JSON.stringify(payload)});
    if(result?.status==='conflict'){
      const merged=mergeCloudData(db,result.data||{},base||{});
      db=merged; db.settings.cloudRevision=Number(result.revision||0); db.settings.syncBase=clone(result.data||{});
      localStorage.setItem(KEY,JSON.stringify(db)); renderAll();
      const retry=await cloudFetch('/rest/v1/rpc/sync_data',{method:'POST',body:JSON.stringify({p_base_revision:db.settings.cloudRevision,p_data:syncSnapshot(),p_device_id:getDeviceId()})});
      if(retry?.status!=='ok') throw Error('Conflit persistant : nouvelle synchronisation nécessaire.');
      db.settings.cloudRevision=Number(retry.revision||db.settings.cloudRevision); db.settings.syncBase=syncSnapshot();
    } else if(result?.status==='ok'){
      db.settings.cloudRevision=Number(result.revision||db.settings.cloudRevision); db.settings.syncBase=syncSnapshot();
    } else throw Error('Réponse cloud invalide.');
    localStorage.setItem(KEY,JSON.stringify(db)); setCloudState('Cloud synchronisé','online'); setSyncStatus(`Synchronisé automatiquement • ${new Date().toLocaleString('fr-FR')}`);
  }catch(e){ setCloudState('Hors ligne / à resynchroniser','error'); setSyncStatus(`Synchronisation en attente : ${e.message}`); }
}
function scheduleCloudSync(){ clearTimeout(syncTimer); syncTimer=setTimeout(()=>cloudSync(),900); }
window.addEventListener('online',()=>cloudSync(true)); window.addEventListener('offline',()=>{setCloudState('Hors ligne');setSyncStatus('Internet absent : les données restent disponibles localement.')});


const money = value => `${new Intl.NumberFormat('fr-FR', { maximumFractionDigits: 0 }).format(Math.round(num(value)))} ${db.settings.currency || 'Ar'}`;
const today = () => new Date().toISOString().slice(0, 10);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#039;' }[c]));
const product = ref => db.products.find(p => p.ref.toLowerCase() === String(ref || '').trim().toLowerCase());
const clients = () => db.contacts.filter(c => c.type === 'Client');
const suppliers = () => db.contacts.filter(c => c.type === 'Fournisseur');
const safeVal = id => $(id) ? $(id).value : '';

function log(action) {
  db.log.unshift({ date: new Date().toLocaleString('fr-FR'), action });
  db.log = db.log.slice(0, 300);
}

function nextNum(type) {
  const prefix = db.settings[`prefix${type}`] || type;
  const year = new Date().getFullYear();
  const nums = db.docs.filter(d => d.typeCode === type).map(d => Number(String(d.num || '').split('-').pop()) || 0);
  return `${prefix}-${year}-${String(Math.max(0, ...nums) + 1).padStart(4, '0')}`;
}

function showPage(id) {
  document.querySelectorAll('.page').forEach(p => p.classList.toggle('active', p.id === id));
}

document.querySelectorAll('#nav button').forEach(b => b.addEventListener('click', () => showPage(b.dataset.page)));
document.querySelectorAll('[data-go]').forEach(b => b.addEventListener('click', () => showPage(b.dataset.go)));

function updateSellFromMargin() {
  const buy = num(safeVal('buy'));
  const margin = num(safeVal('margin'));
  if (!$('manualSell').checked) $('sell').value = Math.round(buy * (1 + margin / 100));
}

function clearProduct() {
  ['ref','name','buy','sell','qty'].forEach(id => { if ($(id)) $(id).value = ''; });
  $('margin').value = '30';
  $('tax').value = db.settings.defaultTax ?? 20;
  $('min').value = 2;
  $('unit').value = 'pièce';
  $('manualSell').checked = false;
  $('sell').disabled = true;
  $('ref').focus();
}

function fillProductFromRef() {
  const r = safeVal('ref'), br = safeVal('buyRef');
  const p = product(r) || product(br);
  if (!p) return;
  $('name').value = p.name;
  $('buy').value = p.buy;
  $('margin').value = p.marginPct;
  $('sell').value = p.sell;
  $('manualSell').checked = p.manualSell;
  $('sell').disabled = !p.manualSell;
  $('tax').value = p.tax ?? db.settings.defaultTax ?? 20;
  $('unit').value = p.unit || 'pièce';
  if (document.activeElement === $('buyRef')) $('buyUnit').value = p.buy;
}

$('newProduct').onclick = clearProduct;
$('clearProduct').onclick = clearProduct;
$('manualSell').onchange = e => { $('sell').disabled = !e.target.checked; updateSellFromMargin(); };
$('buy').oninput = updateSellFromMargin;
$('margin').oninput = updateSellFromMargin;
$('ref').addEventListener('input', fillProductFromRef);
$('buyRef').addEventListener('input', fillProductFromRef);

function refreshDatalist() {
  $('refs').innerHTML = db.products.map(p => `<option value="${esc(p.ref)}">${esc(p.name)}</option>`).join('');
}

$('saveProduct').onclick = () => {
  const ref = safeVal('ref').trim();
  if (!ref) return alert('Référence obligatoire.');
  const buy = num(safeVal('buy'));
  const margin = num(safeVal('margin'));
  const manual = $('manualSell').checked;
  const sell = manual ? num(safeVal('sell')) : Math.round(buy * (1 + margin / 100));
  if (buy < 0 || sell < 0 || margin < 0) return alert('Prix ou marge invalide.');
  if (!manual && buy > 0 && sell <= 0) return alert('Le prix de vente calculé est invalide.');
  let p = product(ref);
  if (!p) { p = { ref, created: today() }; db.products.push(p); }
  Object.assign(p, {
    name: safeVal('name').trim(), buy, marginPct: margin, sell: Math.round(sell), manualSell: manual,
    tax: num(safeVal('tax')), qty: Math.max(0, num(safeVal('qty'))), min: Math.max(0, num(safeVal('min'))), unit: safeVal('unit') || 'pièce'
  });
  db.products = db.products.map(normalizeProduct);
  log(`Produit ${ref} enregistré`);
  save();
  alert(`Produit enregistré : ${money(sell)} prix de vente.`);
  clearProduct();
};

window.editProduct = ref => {
  const p = product(ref); if (!p) return;
  showPage('stock');
  $('ref').value = p.ref; $('name').value = p.name; $('buy').value = p.buy; $('margin').value = p.marginPct;
  $('sell').value = p.sell; $('manualSell').checked = p.manualSell; $('sell').disabled = !p.manualSell;
  $('tax').value = p.tax; $('qty').value = p.qty; $('min').value = p.min; $('unit').value = p.unit || 'pièce';
};

window.deleteProduct = ref => {
  const p = product(ref); if (!p) return;
  if (!confirm(`Supprimer le produit ${p.ref} ?`)) return;
  db.products = db.products.filter(x => x.ref.toLowerCase() !== p.ref.toLowerCase());
  log(`Produit ${p.ref} supprimé`); save();
};

function renderProducts() {
  const q = safeVal('stockSearch').toLowerCase();
  const arr = db.products.filter(p => `${p.ref} ${p.name}`.toLowerCase().includes(q));
  const potential = arr.reduce((s,p) => s + p.qty * Math.max(0, p.sell - p.buy), 0);
  $('products').innerHTML = `<div class="hint">Gain potentiel du stock affiché : <b>${money(potential)}</b></div>
  <table><thead><tr><th>Référence</th><th>Désignation</th><th>Stock</th><th>Prix achat</th><th>Marge</th><th>Gain / unité</th><th>Prix vente</th><th>Actions</th></tr></thead><tbody>
  ${arr.map(p => `<tr class="${p.qty <= p.min ? 'low' : ''}"><td>${esc(p.ref)}</td><td>${esc(p.name)}</td><td>${p.qty}${p.qty <= p.min ? ' ⚠️' : ''}</td><td>${money(p.buy)}</td><td>${num(p.marginPct).toFixed(2).replace('.00','')} %<br><small>${money(p.sell-p.buy)}</small></td><td>${money(p.sell-p.buy)}</td><td>${money(p.sell)}</td><td><button class="secondary" onclick="editProduct('${esc(p.ref)}')">Modifier</button> <button class="danger" onclick="deleteProduct('${esc(p.ref)}')">Supprimer</button></td></tr>`).join('')}</tbody></table>`;
}
$('stockSearch').oninput = renderProducts;

function populateClients() {
  $('docClient').innerHTML = '<option value="">Client comptant</option>' + clients().map(c => `<option value="${esc(c.id)}">${esc(c.code ? c.code + ' — ' : '')}${esc(c.name)}</option>`).join('');
}

function resetDoc() {
  editingId = null; $('docTitle').textContent = 'Nouveau document'; $('docType').value = 'Devis'; $('docDate').value = today();
  populateClients(); $('docClient').value = ''; $('conversion').textContent = ''; $('lines').querySelector('tbody').innerHTML = ''; addLine();
}

function addLine(data) {
  const tr = document.createElement('tr');
  tr.innerHTML = `<td><input class="lr" list="refs" autocomplete="off" value="${esc(data?.ref || '')}"></td>
  <td class="ld">${esc(data?.name || '')}</td><td><input class="lq" type="number" min="1" step="1" value="${data?.qty || 1}"></td>
  <td class="lp">${money(data?.price || 0)}</td><td class="lt">${data?.tax ?? db.settings.defaultTax ?? 20} %</td>
  <td class="lh">${money((data?.qty || 0) * (data?.price || 0))}</td><td class="ltt">${money((data?.qty || 0) * (data?.price || 0) * (1 + (data?.tax || 0) / 100))}</td>
  <td><button type="button" class="secondary">×</button></td>`;
  $('lines').querySelector('tbody').appendChild(tr);
  tr.querySelector('.lr').oninput = () => calcLine(tr);
  tr.querySelector('.lq').oninput = () => calcLine(tr);
  tr.querySelector('button').onclick = () => { tr.remove(); calcTotals(); };
  if (data) calcLine(tr);
}

function calcLine(tr) {
  const p = product(tr.querySelector('.lr').value);
  const q = Math.max(0, num(tr.querySelector('.lq').value));
  const price = p ? num(p.sell) : 0;
  const tax = p ? num(p.tax) : num(db.settings.defaultTax);
  tr.querySelector('.ld').textContent = p ? p.name : '';
  tr.querySelector('.lp').textContent = money(price);
  tr.querySelector('.lt').textContent = `${tax} %`;
  tr.querySelector('.lh').textContent = money(q * price);
  tr.querySelector('.ltt').textContent = money(q * price * (1 + tax / 100));
  tr.dataset.ht = String(q * price); tr.dataset.ttc = String(q * price * (1 + tax / 100));
  calcTotals();
}

function calcTotals() {
  let ht = 0, ttc = 0;
  document.querySelectorAll('#lines tbody tr').forEach(tr => { ht += num(tr.dataset.ht); ttc += num(tr.dataset.ttc); });
  $('ht').textContent = money(ht); $('vat').textContent = money(ttc - ht); $('ttc').textContent = money(ttc);
}

$('newDoc').onclick = () => { resetDoc(); $('docEditor').classList.remove('hidden'); showPage('documents'); };
$('quickDoc').onclick = () => $('newDoc').click();
$('addLine').onclick = () => addLine();
$('cancelDoc').onclick = () => $('docEditor').classList.add('hidden');
$('docType').onchange = () => { $('conversion').textContent = $('docType').value === 'Facture' ? 'Une facture sort le stock lorsqu’elle est enregistrée.' : $('docType').value === 'BL' ? 'Un BL sort le stock lorsqu’il est enregistré.' : ''; };

function readDoc() {
  const rows = [...document.querySelectorAll('#lines tbody tr')];
  if (!rows.length) throw Error('Ajoute au moins une ligne.');
  const items = rows.map(tr => {
    const ref = tr.querySelector('.lr').value.trim(), p = product(ref);
    if (!p) throw Error(`Référence inconnue : ${ref}`);
    const qty = Math.max(1, num(tr.querySelector('.lq').value));
    return { ref: p.ref, name: p.name, qty, price: num(p.sell), tax: num(p.tax), buy: num(p.buy) };
  });
  const ht = items.reduce((s,i) => s + i.qty*i.price, 0);
  const vat = items.reduce((s,i) => s + i.qty*i.price*i.tax/100, 0);
  const cid = safeVal('docClient'), c = clients().find(x => x.id === cid);
  const type = safeVal('docType');
  return { items, ht, vat, ttc: ht + vat, clientId: cid || '', client: c ? c.name : 'Client comptant', date: safeVal('docDate') || today(), type, typeCode: {Devis:'DEV',Proforma:'PRO',BL:'BL',Facture:'FAC'}[type], logoSnapshot: db.settings.logo || '', docModel: db.settings.docModel || 'classic' };
}

function adjustStock(d, sign) {
  d.items.forEach(i => { const p = product(i.ref); if (p) p.qty = Math.max(0, num(p.qty) + sign * num(i.qty)); });
}
function stockImpact(d) { return d && (d.type === 'Facture' || d.type === 'BL') ? -1 : 0; }

$('saveDoc').onclick = () => {
  try {
    const d = readDoc();
    if (editingId) {
      const old = db.docs.find(x => x.id === editingId);
      if (!old) throw Error('Document introuvable.');
      // Restore old stock impact before applying the edited document.
      adjustStock(old, -stockImpact(old));
      const preservedLogo = old.logoSnapshot || d.logoSnapshot || '';
      const preservedModel = old.docModel || d.docModel || 'classic';
      Object.assign(old, d, { logoSnapshot: preservedLogo, docModel: preservedModel });
      adjustStock(old, stockImpact(old));
      log(`Modification ${old.num}`);
      save(); $('docEditor').classList.add('hidden'); alert(`Document modifié : ${old.num}`); return;
    }
    d.id = uid(); d.num = nextNum(d.typeCode); d.status = d.type === 'Facture' ? 'Facturée' : d.type === 'BL' ? 'Livré' : 'Brouillon';
    db.docs.unshift(d); adjustStock(d, stockImpact(d)); log(`Création ${d.num}`); save(); $('docEditor').classList.add('hidden'); alert(`Document enregistré : ${d.num}`);
  } catch (e) { alert(e.message); }
};

function renderDocs() {
  const filter = safeVal('docFilter'), search = safeVal('docSearch').toLowerCase();
  const arr = db.docs.filter(d => (filter === 'Tous' || d.type === filter) && JSON.stringify(d).toLowerCase().includes(search));
  $('documentsList').innerHTML = `<table><thead><tr><th>N°</th><th>Date</th><th>Type</th><th>Client</th><th>TTC</th><th>Actions</th></tr></thead><tbody>${arr.map(d => `<tr><td>${esc(d.num)}</td><td>${esc(d.date)}</td><td>${esc(d.type)}</td><td>${esc(d.client)}</td><td>${money(d.ttc)}</td><td><button class="secondary" onclick="openDoc('${esc(d.id)}')">Aperçu</button> <button class="secondary" onclick="editDoc('${esc(d.id)}')">Modifier</button></td></tr>`).join('')}</tbody></table>`;
}
$('docSearch').oninput = renderDocs; $('docFilter').onchange = renderDocs;
window.openDoc = id => { const d = db.docs.find(x => x.id === id); if (d) showPreview(d); };
window.editDoc = id => { const d = db.docs.find(x => x.id === id); if (!d) return; editingId=id; $('docTitle').textContent=`Modifier ${d.num}`; $('docType').value=d.type; $('docDate').value=d.date; populateClients(); $('docClient').value=d.clientId||''; $('lines').querySelector('tbody').innerHTML=''; d.items.forEach(addLine); $('docEditor').classList.remove('hidden'); showPage('documents'); };

function clientBlock(c) { return c ? `<div><b>${esc(c.name)}</b><br>${esc(c.address||'')}<br>${esc(c.phone||'')}${c.email?' · '+esc(c.email):''}${c.nif?' · NIF '+esc(c.nif):''}${c.stat?' · STAT '+esc(c.stat):''}</div>` : '<div><b>Client comptant</b></div>'; }

function buildPreview(d) {
  const c=clients().find(x=>x.id===d.clientId), s=db.settings, logo=d.logoSnapshot || s.logo || '', model=d.docModel || s.docModel || 'classic';
  const logoPos=s.logoPosition||'right', logoSize=s.logoSize||'medium';
  const rows=d.items.map(i=>`<tr><td>${esc(i.ref)}</td><td>${esc(i.name)}</td><td>${i.qty}</td><td>${money(i.price)}</td><td>${i.tax}%</td><td>${money(i.qty*i.price)}</td><td>${money(i.qty*i.price*(1+i.tax/100))}</td></tr>`).join('');
  return `<div class="paper model-${esc(model)} logo-${esc(logoPos)} logo-size-${esc(logoSize)}" style="--theme:${esc(s.themeColor||'#0f6b43')}">
    <div class="top">${logo && logoPos==='left'?`<img src="${esc(logo)}" class="doc-logo" alt="Logo">`:''}<div class="company"><h1>${esc(s.name||'EC Technologie')}</h1><div>${esc(s.address||'')}<br>${esc(s.phone||'')} ${s.email?'· '+esc(s.email):''}<br>${s.nif?'NIF : '+esc(s.nif):''} ${s.stat?' · STAT : '+esc(s.stat):''} ${s.rcs?' · RCS : '+esc(s.rcs):''}</div></div>${logo && logoPos!=='left'?`<img src="${esc(logo)}" class="doc-logo" alt="Logo">`:''}</div>
    <div class="meta"><div><h2>${esc(d.type)} N° ${esc(d.num)}</h2><div>Date : ${esc(d.date)}</div></div>${clientBlock(c)}</div>
    <table><thead><tr><th>Référence</th><th>Désignation</th><th>Qté</th><th>Prix U.</th><th>TVA</th><th>HT</th><th>TTC</th></tr></thead><tbody>${rows}</tbody></table>
    <div class="amount"><div>Total HT : <b>${money(d.ht)}</b></div><div>TVA : <b>${money(d.vat)}</b></div><div class="grand-total">Total TTC : <b>${money(d.ttc)}</b></div></div>
    <div class="foot">${s.terms?'Conditions de paiement : '+esc(s.terms)+' · ':''}${d.type==='Devis'&&s.quoteValidity?'Validité : '+esc(s.quoteValidity)+' · ':''}${s.warranty?'Garantie / SAV : '+esc(s.warranty):''}<br>${esc(s.footerText||'')}</div>
  </div>`;
}
function showPreview(d) { $('previewPaper').innerHTML=buildPreview(d); $('previewModal').classList.remove('hidden'); }
$('previewDoc').onclick=()=>{try{const d=readDoc();d.num=editingId?(db.docs.find(x=>x.id===editingId)||{}).num:nextNum(d.typeCode);showPreview(d);}catch(e){alert(e.message);}};
$('closePreview').onclick=()=>$('previewModal').classList.add('hidden'); $('printPreview').onclick=()=>window.print();

function clearPurchase(){ $('buyRef').value=''; $('buyQty').value=1; $('buyUnit').value=''; $('supplierSelect').value=''; }
$('newPurchase').onclick=clearPurchase; $('clearPurchase').onclick=clearPurchase;
$('savePurchase').onclick=()=>{
  const p=product(safeVal('buyRef')), q=Math.max(0,num(safeVal('buyQty'))), cost=num(safeVal('buyUnit'));
  if(!p) return alert('Référence inconnue.'); if(q<=0) return alert('Quantité invalide.'); if(cost<0) return alert('Coût invalide.');
  p.qty=num(p.qty)+q; p.buy=cost;
  if(!p.manualSell) p.sell=Math.round(p.buy*(1+num(p.marginPct)/100));
  db.purchases.unshift({id:uid(),date:today(),ref:p.ref,supplierId:safeVal('supplierSelect'),supplier:(suppliers().find(x=>x.id===safeVal('supplierSelect'))||{}).name||'Fournisseur',qty:q,cost,total:q*cost});
  log(`Achat ${q} × ${p.ref}`); save(); alert(`Achat enregistré. Stock : ${p.qty} • Prix achat : ${money(p.buy)} • Vente : ${money(p.sell)}`); clearPurchase();
};
function renderPurchases(){ $('purchaseList').innerHTML=`<table><thead><tr><th>Date</th><th>Réf.</th><th>Fournisseur</th><th>Qté</th><th>Coût U.</th><th>Total</th></tr></thead><tbody>${db.purchases.map(x=>`<tr><td>${esc(x.date)}</td><td>${esc(x.ref)}</td><td>${esc(x.supplier)}</td><td>${num(x.qty)}</td><td>${money(x.cost)}</td><td>${money(x.total)}</td></tr>`).join('')}</tbody></table>`; }

function clearContact(){['ccode','cn','ccontact','cp','ce','ca','cnif','cstat','cnotes'].forEach(id=>$(id).value='');$('ct').value='Client';$('cn').focus();}
$('newContact').onclick=clearContact; $('clearContact').onclick=clearContact;
$('saveContact').onclick=()=>{const n=safeVal('cn').trim();if(!n)return alert('Nom obligatoire.');db.contacts.unshift({id:uid(),type:safeVal('ct'),code:safeVal('ccode').trim(),name:n,contact:safeVal('ccontact'),phone:safeVal('cp'),email:safeVal('ce'),address:safeVal('ca'),nif:safeVal('cnif'),stat:safeVal('cstat'),notes:safeVal('cnotes')});log(`${safeVal('ct')} ${n} ajouté`);save();alert('Enregistré.');clearContact();};
function renderContacts(){ $('contactList').innerHTML=`<table><thead><tr><th>Type</th><th>Code</th><th>Nom / Société</th><th>Contact</th><th>Téléphone</th><th>Email</th><th>Adresse</th><th>NIF</th><th>STAT</th></tr></thead><tbody>${db.contacts.map(x=>`<tr><td>${esc(x.type)}</td><td>${esc(x.code)}</td><td>${esc(x.name)}</td><td>${esc(x.contact)}</td><td>${esc(x.phone)}</td><td>${esc(x.email)}</td><td>${esc(x.address)}</td><td>${esc(x.nif)}</td><td>${esc(x.stat)}</td></tr>`).join('')}</tbody></table>`; }

function clearExpense(){$('expenseLabel').value='';$('expenseAmount').value='';$('expenseDate').value=today();$('expenseLabel').focus();}
$('newExpense').onclick=clearExpense; clearExpense();
$('saveExpense').onclick=()=>{const a=num(safeVal('expenseAmount'));if(a<=0)return alert('Montant invalide.');db.expenses.unshift({date:safeVal('expenseDate')||today(),label:safeVal('expenseLabel')||'Dépense',amount:a});log(`Dépense ${money(a)}`);save();clearExpense();};
function renderExpenses(){ $('expenseList').innerHTML=`<table><thead><tr><th>Date</th><th>Libellé</th><th>Montant</th></tr></thead><tbody>${db.expenses.map(x=>`<tr><td>${esc(x.date)}</td><td>${esc(x.label)}</td><td>${money(x.amount)}</td></tr>`).join('')}</tbody></table>`; }

function loadSettings(){
  const s=db.settings;
  $('bizName').value=s.name||'';$('bizPhone').value=s.phone||'';$('bizEmail').value=s.email||'';$('bizAddress').value=s.address||'';$('bizNif').value=s.nif||'';$('bizStat').value=s.stat||'';$('bizRcs').value=s.rcs||'';$('bizWeb').value=s.web||'';
  $('logoFile').value='';$('logoPreview').src=s.logo||'logo.png';$('logoPreview').dataset.logo=s.logo||'';
  $('currency').value=s.currency||'Ar';$('defaultTax').value=s.defaultTax??20;$('quoteValidity').value=s.quoteValidity||'30 jours';$('terms').value=s.terms||'';$('warranty').value=s.warranty||'';$('footerText').value=s.footerText||'';
  $('themeColor').value=s.themeColor||'#0f6b43';
  applyTheme(s.theme || 'classic');$('tableTheme').value=s.tableTheme||'grid';$('paper').value=s.paper||'landscape';$('docModel').value=s.docModel||'classic';$('dashboardModel').value=s.dashboardModel||'manager';$('logoPosition').value=s.logoPosition||'right';$('logoSize').value=s.logoSize||'medium';
  $('prefixDEV').value=s.prefixDEV||'DEV';$('prefixPRO').value=s.prefixPRO||'PRO';$('prefixBL').value=s.prefixBL||'BL';$('prefixFAC').value=s.prefixFAC||'FAC';$('syncUrl').value=s.syncUrl||'';$('syncToken').value=s.syncToken||'';
  if($('supabaseUrl')) $('supabaseUrl').value=s.supabaseUrl||''; if($('supabaseKey')) $('supabaseKey').value=s.supabaseKey||''; if($('cloudEmail')) $('cloudEmail').value=s.cloudEmail||''; if($('deviceName')) $('deviceName').value=s.deviceName||'';
  if(s.cloudSession?.access_token) setCloudState('Connecté','online'); else setCloudState('Hors connexion');
}
$('saveSettings').onclick=()=>{db.settings={...db.settings,name:safeVal('bizName'),phone:safeVal('bizPhone'),email:safeVal('bizEmail'),address:safeVal('bizAddress'),nif:safeVal('bizNif'),stat:safeVal('bizStat'),rcs:safeVal('bizRcs'),web:safeVal('bizWeb'),logo:$('logoPreview').dataset.logo||db.settings.logo||'',docModel:safeVal('docModel'),dashboardModel:safeVal('dashboardModel'),logoPosition:safeVal('logoPosition'),logoSize:safeVal('logoSize'),currency:safeVal('currency')||'Ar',defaultTax:num(safeVal('defaultTax')),quoteValidity:safeVal('quoteValidity'),terms:safeVal('terms'),warranty:safeVal('warranty'),footerText:safeVal('footerText'),themeColor:safeVal('themeColor'),tableTheme:safeVal('tableTheme'),paper:safeVal('paper'),prefixDEV:safeVal('prefixDEV')||'DEV',prefixPRO:safeVal('prefixPRO')||'PRO',prefixBL:safeVal('prefixBL')||'BL',prefixFAC:safeVal('prefixFAC')||'FAC',syncUrl:safeVal('syncUrl').trim(),syncToken:safeVal('syncToken'),supabaseUrl:safeVal('supabaseUrl').trim(),supabaseKey:safeVal('supabaseKey').trim(),cloudEmail:safeVal('cloudEmail').trim(),deviceName:safeVal('deviceName').trim(),cloudSession:db.settings.cloudSession||null,cloudUserId:db.settings.cloudUserId||'',cloudRevision:Number(db.settings.cloudRevision||0),syncBase:db.settings.syncBase||null,theme:db.settings.theme||'classic'};log('Paramètres modifiés');save();alert('Paramètres sauvegardés.');};
$('logoFile').onchange=e=>{const f=e.target.files && e.target.files[0];if(!f)return;if(!/^image\/(png|jpeg|webp)$/.test(f.type))return alert('Format logo non supporté.');if(f.size>3*1024*1024)return alert('Logo trop volumineux (maximum 3 Mo).');const r=new FileReader();r.onload=()=>{$('logoPreview').src=r.result;$('logoPreview').dataset.logo=r.result;};r.readAsDataURL(f);};
$('logoPreview').onclick=()=>$('logoFile').click();$('chooseLogo').onclick=()=>$('logoFile').click();

$('backup').onclick=()=>{const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([JSON.stringify(db,null,2)],{type:'application/json'}));a.download=`EC_Technologie_V4_${today()}.json`;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);};
$('restore').onchange=e=>{const f=e.target.files&&e.target.files[0];if(!f)return;const r=new FileReader();r.onload=()=>{try{const incoming=JSON.parse(r.result);if(!incoming||!Array.isArray(incoming.products)||!incoming.settings)throw Error('Structure invalide');db={...clone(DEFAULT),...incoming,settings:{...DEFAULT.settings,...incoming.settings},products:incoming.products.map(normalizeProduct)};save();loadSettings();alert('Sauvegarde restaurée avec succès.');}catch(err){alert(`Fichier invalide : ${err.message}`);}};r.readAsText(f);};
$('resetData').onclick=()=>{if(confirm('Supprimer toutes les données locales ?')){db=clone(DEFAULT);save();loadSettings();}};

async function sync(mode){ if(mode==='push') return cloudSync(true); return cloudSync(true); }
$('syncPush').onclick=()=>cloudSync(true);$('syncPull').onclick=()=>cloudSync(true);
if($('cloudSaveConfig')) $('cloudSaveConfig').onclick=()=>{ db.settings.supabaseUrl=safeVal('supabaseUrl').trim();db.settings.supabaseKey=safeVal('supabaseKey').trim();db.settings.cloudEmail=safeVal('cloudEmail').trim();db.settings.deviceName=safeVal('deviceName').trim();localStorage.setItem(KEY,JSON.stringify(db));setSyncStatus('Configuration Cloud enregistrée.');alert('Configuration Cloud enregistrée.'); };
if($('cloudLogin')) $('cloudLogin').onclick=()=>cloudAuth('login');
if($('cloudSignup')) $('cloudSignup').onclick=()=>cloudAuth('signup');
if($('cloudLogout')) $('cloudLogout').onclick=()=>{db.settings.cloudSession=null;db.settings.cloudUserId='';db.settings.cloudRevision=0;db.settings.syncBase=null;localStorage.setItem(KEY,JSON.stringify(db));setCloudState('Hors connexion');setSyncStatus('Déconnecté. Les données locales restent intactes.');};
if($('cloudSyncNow')) $('cloudSyncNow').onclick=()=>cloudSync(true);

function monthKey(date){ return String(date||'').slice(0,7); }
function currentMonth(){ return new Date().toISOString().slice(0,7); }
function monthLabel(key){ const [y,m]=key.split('-').map(Number); return new Date(y,m-1,1).toLocaleDateString('fr-FR',{month:'short'}).replace('.',''); }
function monthStats(key){
  const sales=db.docs.filter(d=>d.type==='Facture' && monthKey(d.date)===key);
  const purchases=db.purchases.filter(x=>monthKey(x.date)===key);
  const expenses=db.expenses.filter(x=>monthKey(x.date)===key);
  const ca=sales.reduce((s,d)=>s+num(d.ttc),0);
  const gain=sales.reduce((s,d)=>s+d.items.reduce((a,i)=>a+num(i.qty)*(num(i.price)-num(i.buy)),0),0);
  return {ca,gain, purchases:purchases.reduce((s,x)=>s+num(x.total),0), expenses:expenses.reduce((s,x)=>s+num(x.amount),0), sales:sales.length};
}
function applyTheme(theme){
  const allowed=['classic','ultra','dark','light','royal','purple','teal','orange','red','graphite','glass','sand'];
  const t=allowed.includes(theme)?theme:'classic';
  document.body.dataset.theme=t;
  const names={classic:'EC Classic',ultra:'Ultra Pro',dark:'Dark Pro',light:'Light Pro',royal:'Royal',purple:'Modern Purple',teal:'Teal Business',orange:'Orange Business',red:'Red Pro',graphite:'Graphite',glass:'Glass Premium',sand:'Sand Business'};
  if($('themeCurrent')) $('themeCurrent').textContent=names[t];
  document.querySelectorAll('.theme-card').forEach(b=>b.classList.toggle('selected',b.dataset.theme===t));
  const colors={classic:'#0f6b43',ultra:'#2454d6',dark:'#8ee1b4',light:'#2563eb',royal:'#173b8f',purple:'#7c3aed',teal:'#0f766e',orange:'#c2410c',red:'#b4232d',graphite:'#3f4650',glass:'#3b82f6',sand:'#a16207'};
  const color=colors[t]||colors.classic;
  document.documentElement.style.setProperty('--theme',color);
  if($('metaTheme')) $('metaTheme').setAttribute('content',color);
}
function renderMonthlyChart(){
  const now=new Date(); const keys=[];
  for(let i=5;i>=0;i--){ const d=new Date(now.getFullYear(),now.getMonth()-i,1); keys.push(`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}`); }
  const stats=keys.map(monthStats); const max=Math.max(1,...stats.map(x=>Math.max(x.ca,x.gain)));
  $('monthlyChart').innerHTML=stats.map((x,i)=>`<div class="month-col"><div class="bars"><div class="bar ca" style="height:${Math.max(5,x.ca/max*100)}%" title="CA ${money(x.ca)}"></div><div class="bar gain" style="height:${Math.max(4,x.gain/max*100)}%" title="Bénéfice ${money(x.gain)}"></div></div><b>${monthLabel(keys[i])}</b><small>${money(x.ca)}</small></div>`).join('');
}
function renderDashboard(){
  const model=db.settings.dashboardModel||'manager';$('dashboard').className=`page active dashboard-${model}`;
  applyTheme(db.settings.theme||'classic');
  const key=currentMonth(), m=monthStats(key);
  const sales=db.docs.filter(d=>d.type==='Facture'), ca=sales.reduce((s,d)=>s+num(d.ttc),0), ach=db.purchases.reduce((s,d)=>s+num(d.total),0);
  const gain=sales.reduce((s,d)=>s+d.items.reduce((a,i)=>a+num(i.qty)*(num(i.price)-num(i.buy)),0),0);
  const stockValue=db.products.reduce((s,p)=>s+num(p.qty)*num(p.buy),0);
  const receiv=sales.filter(d=>d.paymentStatus!=='paid').reduce((s,d)=>s+num(d.ttc),0);
  const net=m.gain-m.expenses;
  $('kpiCA').textContent=money(m.ca);$('kpiPurchases').textContent=money(m.purchases);$('kpiGain').textContent=money(m.gain);$('kpiStock').textContent=money(stockValue);$('kpiReceivables').textContent=money(receiv);$('kpiAlerts').textContent=db.products.filter(p=>num(p.qty)<=num(p.min)).length;
  if($('kpiExpenses')) $('kpiExpenses').textContent=money(m.expenses); if($('kpiNet')) $('kpiNet').textContent=money(net);
  $('dashboardPeriod').textContent=`${new Date().toLocaleDateString('fr-FR',{month:'long',year:'numeric'})} • ${m.sales} facture(s)`;
  $('syncBadge').textContent=db.settings.syncUrl?'Synchronisation configurée':'Données locales';
  $('activity').innerHTML=db.log.slice(0,10).map(x=>`<p><b>${esc(x.date)}</b> — ${esc(x.action)}</p>`).join('')||'<p>Aucune opération.</p>';
  const low=db.products.filter(p=>num(p.qty)<=num(p.min)).length;
  const grossRate=m.ca>0?(m.gain/m.ca*100):0;
  $('summary').innerHTML=`<p>Produits : <b>${db.products.length}</b></p><p>Clients : <b>${clients().length}</b></p><p>Fournisseurs : <b>${suppliers().length}</b></p><p>Documents : <b>${db.docs.length}</b></p><p>Factures ce mois : <b>${m.sales}</b></p>`;
  $('healthMetrics').innerHTML=`<div class="health-row"><span>Marge brute</span><b>${grossRate.toFixed(1)} %</b></div><div class="health-row"><span>Stock faible</span><b>${low}</b></div><div class="health-row"><span>Bénéfice net estimé</span><b>${money(net)}</b></div><div class="health-row"><span>Factures impayées</span><b>${money(receiv)}</b></div>`;
  renderMonthlyChart();
}
function renderAll(){refreshDatalist();renderProducts();populateClients();$('supplierSelect').innerHTML='<option value="">Fournisseur</option>'+suppliers().map(c=>`<option value="${esc(c.id)}">${esc(c.name)}</option>`).join('');renderPurchases();renderContacts();renderExpenses();renderDocs();renderDashboard();$('log').innerHTML=db.log.map(x=>`<p>${esc(x.date)} — ${esc(x.action)}</p>`).join('');}

document.querySelectorAll('.theme-card').forEach(b=>b.addEventListener('click',()=>{ const t=b.dataset.theme; db.settings.theme=t; applyTheme(t); log(`Thème ${b.querySelector('b')?.textContent||t} sélectionné`); localStorage.setItem(KEY,JSON.stringify(db)); }));
loadSettings();
renderAll();
if(cloudReady() && db.settings.cloudSession?.access_token && navigator.onLine) cloudSync(true);
if('serviceWorker' in navigator) navigator.serviceWorker.register('sw.js').catch(()=>{});
