
const API_BASES=['https://api.binance.com'];
const LBANK_WS='wss://www.lbkex.net/ws/V2/';
const LBANK_API_BASES=['https://api.lbkex.com','https://www.lbkex.net','https://api.lbank.info'];
const LBANK_WS_BASES=['wss://api.lbank.info/ws/V2/'];
const liveCache={};
const liveListeners={};
const liveSockets={};
const liveHub={ws:null,connecting:false,retry:0,timer:null,watchdog:null,pingTimer:null,lastMessage:0,provider:'lbank'};
const pair=(sym)=>String(sym).toLowerCase()+'_usdt';
const lbankType=(interval)=>({ '1m':'minute1','5m':'minute5','15m':'minute15','30m':'minute30','1h':'hour1','4h':'hour4','1d':'day1','1w':'week1' }[interval]||'hour1');
function normalizeLbankKline(rows){return (rows||[]).map(k=>{const rawTs=Array.isArray(k)?Number(k[0]):Number(k.timestamp??k.t);const ts=Number.isFinite(rawTs)?(rawTs<100000000000?rawTs*1000:rawTs):NaN;return Array.isArray(k)?[ts,String(k[1]),String(k[2]),String(k[3]),String(k[4]),String(k[5]),Date.now(),'0','0','0','0','0']:[ts,String(k.open??k.o),String(k.high??k.h),String(k.low??k.l),String(k.close??k.c),String(k.volume??k.v),Date.now(),'0','0','0','0','0']}).filter(k=>Number.isFinite(k[0]));}
async function lbankFetch(path){
  let last;
  for(const base of LBANK_API_BASES){const ctl=new AbortController();const timer=setTimeout(()=>ctl.abort(),7000);try{const r=await fetch(base+path,{cache:'no-store',signal:ctl.signal});if(!r.ok)throw new Error('HTTP '+r.status);return await r.json()}catch(e){last=e}finally{clearTimeout(timer)}}
  throw last||new Error('LBank network');
}
function markLiveData(){liveHub.lastMessage=Date.now()}
function notifyLive(sym,payload){(liveListeners[String(sym).toUpperCase()]||[]).slice().forEach(fn=>{try{fn(payload)}catch(e){}})}
function showNetworkAlert(){setDataStatus(false)}
function toast(t){const e=document.getElementById('toast');if(!e)return;e.textContent=t;e.classList.add('show');setTimeout(()=>e.classList.remove('show'),1800)}

// V101.2 Pull-to-refresh: robust Android WebView gesture + real refresh lifecycle.
function initPullToRefresh(){
  if(window.__cpPullRefreshReady)return;
  window.__cpPullRefreshReady=true;

  const wrap=document.createElement('div');
  wrap.id='cpPullRefresh';
  wrap.innerHTML=`<div class="cp-pull-card" role="status" aria-live="polite">
    <div class="cp-pull-orb"><span></span><b>CP</b></div>
    <div class="cp-pull-copy">
      <strong id="cpPullTitle">برای به‌روزرسانی بکشید</strong>
      <small id="cpPullSub">داده‌های بازار تازه می‌شوند</small>
    </div>
  </div>`;
  (document.body||document.documentElement).appendChild(wrap);

  const card=wrap.querySelector('.cp-pull-card');
  const title=wrap.querySelector('#cpPullTitle');
  const sub=wrap.querySelector('#cpPullSub');

  let startY=0, distance=0, tracking=false, refreshing=false, touchMoved=false;
  const threshold=72, maxPull=120;

  function scrollTop(){
    return Math.max(
      Number(window.scrollY||window.pageYOffset||0),
      Number(document.scrollingElement?.scrollTop||0),
      Number(document.documentElement?.scrollTop||0),
      Number(document.body?.scrollTop||0)
    );
  }

  function reset(){
    wrap.classList.remove('active','ready','refreshing');
    card.style.transform='translate3d(-50%,-112px,0) scale(.96)';
    title.textContent='برای به‌روزرسانی بکشید';
    sub.textContent='صفحه را از بالا به پایین بکشید';
    distance=0; tracking=false; touchMoved=false;
  }

  function setPull(d){
    distance=Math.max(0,Math.min(maxPull,d));
    const p=Math.min(1,distance/threshold);
    wrap.classList.toggle('active',distance>4);
    wrap.classList.toggle('ready',distance>=threshold);
    card.style.transform=`translate3d(-50%,${-112+Math.round(distance*.72)}px,0) scale(${.96+p*.04})`;
    title.textContent=distance>=threshold?'رها کنید تا به‌روزرسانی شود':'برای به‌روزرسانی بکشید';
    sub.textContent=distance>=threshold?'رها کنید؛ دریافت داده شروع می‌شود':'صفحه را کمی بیشتر به پایین بکشید';
  }

  function isChartTouch(target){
    return !!(target&&target.closest&&target.closest('#chart,#candleCanvas,canvas'));
  }

  document.addEventListener('touchstart',e=>{
    if(refreshing||e.touches.length!==1)return;
    if(isChartTouch(e.target)){tracking=false;return;}
    if(scrollTop()>4){tracking=false;return;}
    startY=e.touches[0].clientY;
    distance=0;
    touchMoved=false;
    tracking=true;
  },{passive:true,capture:true});

  document.addEventListener('touchmove',e=>{
    if(!tracking||refreshing||e.touches.length!==1)return;
    const dy=e.touches[0].clientY-startY;
    if(dy<=0){setPull(0);return;}
    touchMoved=true;
    if(dy>4)e.preventDefault();
    // Resistance: natural pull feel on mobile.
    setPull(Math.pow(dy,0.92)*0.95);
  },{passive:false,capture:true});

  document.addEventListener('touchcancel',()=>{
    if(!tracking||refreshing)return;
    reset();
  },{passive:true,capture:true});

  document.addEventListener('touchend',()=>{
    if(!tracking||refreshing)return;
    tracking=false;
    if(distance>=threshold)doRefresh();
    else reset();
  },{passive:true,capture:true});

  async function doRefresh(){
    refreshing=true;
    wrap.classList.add('active','refreshing');
    wrap.classList.remove('ready');
    card.style.transform='translate3d(-50%,8px,0) scale(1)';
    title.textContent='در حال به‌روزرسانی';
    sub.textContent='در حال دریافت آخرین داده‌ها از LBank…';

    let gotLive=false;
    const markLive=()=>{gotLive=true;};
    window.addEventListener('cp-live-ticker',markLive,{once:true});
    window.addEventListener('cp-live-kline',markLive,{once:true});
    window.addEventListener('cp-live-tick',markLive,{once:true});

    try{
      if(typeof closeLiveHub==='function')closeLiveHub();
      if(typeof startLiveSocket==='function')startLiveSocket();
      window.dispatchEvent(new CustomEvent('cp-manual-refresh'));
    }catch(e){}

    // Give the new socket/REST request enough time; do not reload the whole page.
    await new Promise(r=>setTimeout(r,2600));

    title.textContent=gotLive?'به‌روزرسانی انجام شد ✓':'اتصال دوباره انجام شد';
    sub.textContent=gotLive?'داده‌های زنده دریافت شدند':'اگر داده نیامد، وضعیت اتصال LBank را بررسی می‌کنیم';
    wrap.classList.remove('refreshing');
    await new Promise(r=>setTimeout(r,900));
    window.removeEventListener('cp-live-ticker',markLive);
    window.removeEventListener('cp-live-kline',markLive);
    window.removeEventListener('cp-live-tick',markLive);
    refreshing=false;
    reset();
  }

  reset();
}
setTimeout(initPullToRefresh,0);

function notifications(){try{const a=JSON.parse(localStorage.getItem('cp_notifications')||'[]');return Array.isArray(a)?a:[]}catch(e){return[]}}
function pushNotification(title,text,type='info'){const a=notifications();a.unshift({id:Date.now(),title,text,type,read:false,time:Date.now()});localStorage.setItem('cp_notifications',JSON.stringify(a.slice(0,50)))}
function unreadNotifications(){return notifications().filter(x=>!x.read).length}
function setDataStatus(ok){const e=document.getElementById('dataStatus');if(!e)return;e.textContent=ok?'● LIVE DATA':'● OFFLINE';e.className=ok?'live':'pill'}
function coinCards(list=coins){return list.map(c=>`<a href="asset.html?symbol=${c[0]}" class="coin" style="text-decoration:none;color:inherit"><div class="coin-left"><div class="coin-icon">${c[0][0]}</div><div><b>${c[0]}</b><div class="muted">${c[1]}</div></div></div><div class="coin-price"><b>${c[2]}</b><div class="${String(c[3])[0]=='+'?'up':'down'}" style="font-size:11px">${c[3]}</div></div></a>`).join('')}
function getCoin(sym){return coins.find(c=>c[0]===sym)||coins[0]}
function latinDigits(v){return String(v??'').replace(/[۰-۹٠-٩]/g,d=>String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d)>=0?'۰۱۲۳۴۵۶۷۸۹'.indexOf(d):'٠١٢٣٤٥٦٧٨٩'.indexOf(d)));}
function money(n){return Number(n||0).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2})}
function latinizeVisibleNumbers(root=document.body){if(!root)return;const w=document.createTreeWalker(root,NodeFilter.SHOW_TEXT);const nodes=[];while(w.nextNode())nodes.push(w.currentNode);nodes.forEach(n=>{if(n.parentElement&&['SCRIPT','STYLE'].includes(n.parentElement.tagName))return;const x=latinDigits(n.nodeValue);if(x!==n.nodeValue)n.nodeValue=x});root.querySelectorAll('input').forEach(e=>{if(e.value)e.value=latinDigits(e.value);if(e.placeholder)e.placeholder=latinDigits(e.placeholder)});}
const LANG_PAIRS={
'فارسی':'English','خانه':'Home','بازار':'Markets','معامله':'Trade','کیف پول':'Wallet','پروفایل':'Profile','تحلیل':'Analysis','استراتژی':'Strategies','تنظیمات':'Settings','اعلان‌ها':'Notifications','ذخیره تنظیمات':'Save Settings','بازنشانی':'Reset','زبان':'Language','تم برنامه':'App Theme','واحد حساب':'Account Currency','نمایش':'Display','حساب آزمایشی':'Paper Account','امنیت':'Security','فعال':'Enabled','خاموش':'Disabled','روشن، تیره یا حالت نیمه‌تیره':'Light, dark or midnight mode','زبان رابط کاربری':'Interface language','واحد نمایش ارزش دارایی':'Asset value unit','موجودی شبیه‌سازی‌شده برای تمرین':'Simulated balance for practice','هشدار قیمت و رویدادهای برنامه':'Price and app event alerts','رمز ورود برنامه':'App password','اختیاری؛ فقط برای تجربه محلی برنامه':'Optional; local app only','اتصال صرافی':'Exchange connection','در این نسخه سفارش واقعی ارسال نمی‌شود.':'Real orders are not sent in this version.','معاملات باز':'Open Positions','پوزیشن باز':'Open Position','هنوز پوزیشن بازی وجود ندارد.':'No open position yet.','سود/زیان':'P/L','قیمت باز شدن':'Entry Price','قیمت لیکویید شدن':'Liquidation Price','زمان باز شدن':'Open Time','مارجین':'Margin','اهرم':'Leverage','قیمت فعلی':'Current Price','ارزش معامله':'Position Value','بستن معامله':'Close Position','تایم‌فریم':'Timeframe','نمودار':'Chart','قیمت':'Price','مقدار':'Amount','خرید':'Buy','فروش':'Sell'};
const LANG_REVERSE=Object.fromEntries(Object.entries(LANG_PAIRS).map(([a,b])=>[b,a]));
function translatePage(en){const map=en?LANG_PAIRS:LANG_REVERSE;const w=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);const nodes=[];while(w.nextNode())nodes.push(w.currentNode);nodes.forEach(n=>{if(!n.parentElement||['SCRIPT','STYLE','INPUT','TEXTAREA'].includes(n.parentElement.tagName))return;let t=n.nodeValue.trim();if(!t)return;for(const [a,b] of Object.entries(map)){if(t===a){n.nodeValue=n.nodeValue.replace(a,b);break}}});document.querySelectorAll('input,button,a,option,select').forEach(e=>{['placeholder','title','aria-label'].forEach(k=>{if(e.getAttribute(k)){let v=e.getAttribute(k);for(const [a,b] of Object.entries(map))v=v.split(a).join(b);e.setAttribute(k,v)}});if(e.tagName==='OPTION'){let v=e.textContent;for(const [a,b] of Object.entries(map))v=v.split(a).join(b);e.textContent=v}})}
function applyLanguage(){const en=isEnglish();document.documentElement.lang=en?'en':'fa';document.documentElement.dir=en?'ltr':'rtl';translatePage(en);latinizeVisibleNumbers();}
let _digitObserver=null;function startDigitObserver(){if(_digitObserver)_digitObserver.disconnect();_digitObserver=new MutationObserver(()=>latinizeVisibleNumbers());_digitObserver.observe(document.body,{subtree:true,childList:true,characterData:true});}
function chartSVG(seed=1){let pts=[];for(let i=0;i<48;i++){let y=150-Math.sin(i*.48+seed)*30-i*1.2+Math.sin(i*1.8)*8;pts.push(`${i*(800/47)},${y}`)}return `<svg viewBox="0 0 800 260" preserveAspectRatio="none"><g>${[40,90,140,190,240].map(y=>`<line class="chart-grid" x1="0" y1="${y}" x2="800" y2="${y}"/>`).join('')}</g><polyline class="chart-line" points="${pts.join(' ')}"/></svg>`}
function safeSettings(){try{const raw=localStorage.getItem('cp_settings')||'{}';const d=JSON.parse(raw);return d&&typeof d==='object'?d:{}}catch(e){try{localStorage.removeItem('cp_settings')}catch(_e){};return {}}}
function layout(title,subtitle,body,active){
 const prefs=safeSettings();
 document.documentElement.dataset.theme=prefs.theme||'Dark Pro';
 const safeBody=body==null?'':String(body);
 document.body.innerHTML=`<div class="app"><header class="top"><div class="brand"><div class="logo">CP</div><div><b>CryptoPulse</b><small>${subtitle||title||''}</small></div></div><div class="top-actions"><a class="notify-head" href="notifications.html" aria-label="اعلان‌ها">♧<em id="notifyBadge">${unreadNotifications()||''}</em></a><span id="dataStatus" class="live">● CONNECTING</span></div></header>${safeBody}<div id="toast" class="toast"></div></div>${navHTML(active)}`;
 applyLanguage();startDigitObserver();
}
window.addEventListener('error',e=>{try{const el=document.getElementById('toast');if(el){el.textContent='خطای داخلی برنامه؛ لطفاً دوباره تلاش کنید';el.classList.add('show')}}catch(_e){}});
const coins=[['BTC','Bitcoin','67420.20','+2.84%','38.4B'],['ETH','Ethereum','2516.70','+1.91%','21.7B'],['SOL','Solana','142.18','-0.72%','6.2B'],['BNB','BNB','612.40','+0.44%','3.8B'],['XRP','XRP','2.31','+3.18%','2.9B'],['ADA','Cardano','0.74','-1.02%','1.4B'],['DOGE','Dogecoin','0.18','+1.22%','1.1B'],['AVAX','Avalanche','29.44','-0.38%','0.8B'],['LINK','Chainlink','22.08','+2.06%','0.7B']];
const navFa=[['index.html','⌂','خانه'],['markets.html','◈','بازار'],['spot.html','⇄','معامله'],['assets.html','◫','کیف پول'],['profile.html','◉','پروفایل']];
const navEn=[['index.html','⌂','Home'],['markets.html','◈','Markets'],['spot.html','⇄','Trade'],['assets.html','◫','Wallet'],['profile.html','◉','Profile']];
const moreFa=[['analysis.html','⌁','تحلیل'],['strategies.html','◎','استراتژی']];
const moreEn=[['analysis.html','⌁','Analysis'],['strategies.html','◎','Strategies']];
const isEnglish=()=>((safeSettings().lang||'فارسی')==='English');
const nav=()=>isEnglish()?navEn:navFa;
const moreNav=()=>isEnglish()?moreEn:moreFa;
const state=()=>{try{const d=JSON.parse(localStorage.getItem('cp_state'))||{};return {balance:+(d.balance??10000),history:Array.isArray(d.history)?d.history:[],open:d.open||null,openOrders:Array.isArray(d.openOrders)?d.openOrders:[],spot:Array.isArray(d.spot)?d.spot:[],holdings:d.holdings&&typeof d.holdings==='object'?d.holdings:{}}}catch(e){return{balance:10000,history:[],open:null,openOrders:[],spot:[],holdings:{}}}};
function saveState(s){localStorage.setItem('cp_state',JSON.stringify(s))}
function navHTML(active){
 const n=nav();
 const items=n.map(x=>`<a class="nav-item ${x[0]===active?'active':''}" href="${x[0]}" data-nav="${x[0]}" aria-label="${x[2]}"><span>${x[1]}</span>${x[2]}</a>`).join('');
 return `<nav class="nav" id="bottomNav">${items}</nav>`;
}
function toggleMoreNav(){}
function navigateLocal(href){if(!href)return false;try{window.location.href=href}catch(e){window.location.assign(href)}return false}
function bindBottomNav(){
 const go=e=>{const el=e.currentTarget;const href=el.getAttribute('data-nav')||el.getAttribute('href');if(!href)return;e.preventDefault();e.stopPropagation();navigateLocal(href)};
 document.querySelectorAll('#bottomNav [data-nav]').forEach(a=>{a.addEventListener('click',go,false);a.addEventListener('touchend',go,{passive:false})});
}
async function binanceFetch(path){
  let lastErr;
  for(const base of API_BASES){const ctl=new AbortController();const timer=setTimeout(()=>ctl.abort(),7000);try{const r=await fetch(base+path,{cache:'no-store',signal:ctl.signal});if(!r.ok)throw new Error('HTTP '+r.status);return await r.json()}catch(e){lastErr=e}finally{clearTimeout(timer)}}
  throw lastErr||new Error('network');
}
async function api(path){return binanceFetch(path)}
function handleLiveMessage(m){
  if(!m||typeof m!=='object')return;
  const h=liveHub; h.lastMessage=Date.now();
  if(m.action==='ping'&&m.ping){try{h.ws?.send(JSON.stringify({action:'pong',pong:m.ping}))}catch(e){};return}
  if((m.action==='request'||m.request==='kbar'||Array.isArray(m.data)||Array.isArray(m.kbar))&&handleLbankHistoryMessage(m))return;
  const type=m.type;
  const raw=String(m.pair||'').toUpperCase();
  const key=raw.endsWith('_USDT')?raw.slice(0,-5):raw.replace('USDT','');
  if(!key)return;
  markLiveData(); setDataStatus(true);
  if(type==='tick'&&m.tick){const t=m.tick;cpUpsert1m(key,Number(t.latest),Date.now(),0);const out={price:+t.latest,change:+t.change,volume:+t.vol,high:+t.high,low:+t.low,connected:true,lastUpdate:Date.now(),provider:'LBank'};liveCache[key]={...(liveCache[key]||{}),...out};notifyLive(key,{type:'ticker',...out,event:m});;try{window.dispatchEvent(new CustomEvent('cp-live-ticker',{detail:{symbol:key,price:out.price,at:out.lastUpdate}}))}catch(e){}}
  if(type==='trade'&&m.trade){const t=m.trade;const price=Number(t.price??t.p);if(Number.isFinite(price)){const tsRaw=t.TS??t.ts??t.time;const n=Number(tsRaw);const ts=Number.isFinite(n)?(n<100000000000?n*1000:n):(Date.parse(String(tsRaw))||Date.now());cpUpsert1m(key,price,ts,Number(t.amount??t.vol??0));liveCache[key]={...(liveCache[key]||{}),price,lastUpdate:Date.now(),connected:true,provider:'LBank'};notifyLive(key,{type:'ticker',price,ts,trade:t});try{window.dispatchEvent(new CustomEvent('cp-live-tick',{detail:{symbol:key,price,ts}}))}catch(e){}}}
  if(type==='kbar'&&m.kbar){
    const k=m.kbar;
    const rawTs=Number(k.t);
    const parsedTs=Date.parse(String(k.t));
    const kt=Number.isFinite(rawTs)?(rawTs<100000000000?rawTs*1000:rawTs):(Number.isFinite(parsedTs)?parsedTs:Date.now());
    const row=[kt,String(k.o),String(k.h),String(k.l),String(k.c),String(k.v),Date.now(),'0','0','0','0','0'];
    const a=cpOneMin[key]||(cpOneMin[key]=[]);
    const b=cpBucket1m(kt);
    let q=a.length?a[a.length-1]:null;
    if(!q||q[0]!==b){q=[b,Number(k.o),Number(k.h),Number(k.l),Number(k.c),Number(k.v)||0];a.push(q);}
    else{q[1]=Number(k.o);q[2]=Math.max(Number(q[2]),Number(k.h));q[3]=Math.min(Number(q[3]),Number(k.l));q[4]=Number(k.c);q[5]=Number(k.v)||0;}
    if(a.length>3000)a.splice(0,a.length-3000);
    liveCache[key]={...(liveCache[key]||{}),price:+k.c,kline:row,connected:true,lastUpdate:Date.now(),provider:'LBank'};
    notifyLive(key,{type:'kline',row,kline:k});
    try{window.dispatchEvent(new CustomEvent('cp-live-kline',{detail:{symbol:key,row}}))}catch(e){}
  }
}
function ingestLbankHistory(key,rows){
  if(!Array.isArray(rows)||!rows.length)return 0;
  const a=cpOneMin[key]||(cpOneMin[key]=[]),map=new Map(a.map(r=>[r[0],r]));let added=0;
  for(const r of rows){
    const ts=Number(r?.[0]??r?.t??r?.time),o=Number(r?.[1]??r?.o),h=Number(r?.[2]??r?.h),l=Number(r?.[3]??r?.l),c=Number(r?.[4]??r?.c),v=Number(r?.[5]??r?.v??0);
    if(!Number.isFinite(ts)||![o,h,l,c].every(Number.isFinite)||![o,h,l,c].every(x=>x>0))continue;
    const b=cpBucket1m(ts<100000000000?ts*1000:ts),q=map.get(b);
    if(!q){map.set(b,[b,o,h,l,c,Number.isFinite(v)?v:0]);added++}else{q[1]=o;q[2]=Math.max(q[2],h);q[3]=Math.min(q[3],l);q[4]=c;q[5]=Number.isFinite(v)?v:q[5]}
  }
  a.splice(0,a.length,...Array.from(map.values()).sort((x,y)=>x[0]-y[0]).slice(-3000));return added;
}
function handleLbankHistoryMessage(m){
  const raw=String(m?.pair||m?.symbol||m?.data?.pair||m?.data?.symbol||m?.kbar?.pair||'').toUpperCase();
  const key=raw.endsWith('_USDT')?raw.slice(0,-5):raw.replace('USDT','');if(!key)return false;
  let rows=[];if(Array.isArray(m?.data))rows=m.data;else if(Array.isArray(m?.kbar))rows=m.kbar;else if(Array.isArray(m?.data?.data))rows=m.data.data;else if(Array.isArray(m?.result?.data))rows=m.result.data;else if(m?.kbar&&typeof m.kbar==='object')rows=[m.kbar];
  if(!rows.length)return false;const added=ingestLbankHistory(key,rows);
  if(added){setDataStatus(true);try{window.dispatchEvent(new CustomEvent('cp-live-history',{detail:{symbol:key,count:added}}))}catch(e){}}return added>0;
}
function closeLiveHub(){const h=liveHub;if(h.timer){clearTimeout(h.timer);h.timer=null}if(h.watchdog){clearInterval(h.watchdog);h.watchdog=null}if(h.pingTimer){clearInterval(h.pingTimer);h.pingTimer=null}const ws=h.ws;h.ws=null;h.connecting=false;if(ws){try{ws.onclose=null;ws.close()}catch(e){}}Object.keys(liveSockets).forEach(k=>delete liveSockets[k])}
function scheduleLiveReconnect(){const h=liveHub;if(h.timer||!navigator.onLine)return;const delay=Math.min(30000,Math.max(1200,1800*Math.pow(1.7,h.retry++)))+Math.floor(Math.random()*600);h.timer=setTimeout(()=>{h.timer=null;startLiveSocket()},delay)}
function startLiveSocket(){
  const h=liveHub;
  if(h.ws&&[WebSocket.OPEN,WebSocket.CONNECTING].includes(h.ws.readyState))return;
  if(!navigator.onLine||h.connecting)return;
  h.connecting=true; h.provider='lbank';
  let ws;
  try{const host=LBANK_WS_BASES[h.retry%LBANK_WS_BASES.length];ws=new WebSocket(host);h.wsHost=host}catch(e){h.connecting=false;scheduleLiveReconnect();return}
  h.ws=ws;
  ws.onopen=()=>{
    h.connecting=false;h.retry=0;h.lastMessage=Date.now();
    coins.forEach(c=>{
      const p=pair(c[0]);
      try{ws.send(JSON.stringify({action:'subscribe',subscribe:'tick',pair:p}))}catch(e){}
      try{ws.send(JSON.stringify({action:'subscribe',subscribe:'kbar',kbar:'1min',pair:p}))}catch(e){}
      try{const end=Math.floor(Date.now()/1000),start=end-240*60;ws.send(JSON.stringify({action:'request',request:'kbar',kbar:'1min',pair:p,start:String(start),end:String(end),size:'240'}))}catch(e){}
      liveSockets[c[0]]=ws;
    });
    if(h.pingTimer)clearInterval(h.pingTimer);h.pingTimer=setInterval(()=>{try{if(ws.readyState===WebSocket.OPEN)ws.send(JSON.stringify({action:'ping',ping:String(Date.now())}))}catch(e){}},25000);
  };
  ws.onmessage=e=>{try{const raw=typeof e.data==='string'?e.data:new TextDecoder().decode(e.data);handleLiveMessage(JSON.parse(raw))}catch(err){}};
  ws.onerror=()=>{try{ws.close()}catch(e){}};
  ws.onclose=()=>{if(h.ws===ws)h.ws=null;h.connecting=false;h.retry++;if(h.pingTimer){clearInterval(h.pingTimer);h.pingTimer=null}Object.keys(liveSockets).forEach(k=>delete liveSockets[k]);Object.keys(liveCache).forEach(k=>{liveCache[k].connected=false});setDataStatus(false);scheduleLiveReconnect()};
  if(h.watchdog)clearInterval(h.watchdog);
  h.watchdog=setInterval(()=>{if(h.ws&&h.ws.readyState===WebSocket.OPEN&&Date.now()-h.lastMessage>20000){try{h.ws.close()}catch(e){}}else if(!h.ws&&!h.connecting&&navigator.onLine)startLiveSocket()},5000);
}
// V101 shared 1-minute live chart engine
const cpOneMin={};
function cpBucket1m(ts){return Math.floor((Number(ts)||Date.now())/60000)*60000}
function cpUpsert1m(sym,price,ts,vol=0){const key=String(sym).toUpperCase(),p=Number(price);if(!Number.isFinite(p))return null;const b=cpBucket1m(ts);let a=cpOneMin[key]||(cpOneMin[key]=[]),k=a.length?a[a.length-1]:null;if(!k||k[0]!==b){k=[b,p,p,p,p,Number(vol)||0];a.push(k)}else{k[2]=Math.max(k[2],p);k[3]=Math.min(k[3],p);k[4]=p;k[5]=Math.max(0,Number(k[5])+(Number(vol)||0))}if(a.length>3000)a.splice(0,a.length-3000);return k}
function cpAggregate1m(rows,interval){const ms=({'1m':60000,'5m':300000,'15m':900000,'30m':1800000,'1h':3600000,'4h':14400000,'1d':86400000,'1w':604800000}[interval]||60000);const out=[];for(const r of (rows||[])){const ts=Number(r[0]),o=Number(r[1]),h=Number(r[2]),l=Number(r[3]),c=Number(r[4]),v=Number(r[5]||0);if(![ts,o,h,l,c].every(Number.isFinite))continue;const b=Math.floor(ts/ms)*ms,last=out[out.length-1];if(!last||last[0]!==b)out.push([b,o,h,l,c,v,Date.now(),'0','0','0','0','0']);else{last[2]=Math.max(last[2],h);last[3]=Math.min(last[3],l);last[4]=c;last[5]+=Number.isFinite(v)?v:0}}return out}
async function candlesFromShared1m(sym,interval='1h',limit=240){
  const key=String(sym).toUpperCase(),minuteNow=Math.floor(Date.now()/60000)*60;
  const anchors=[Math.max(0,minuteNow-2000*60),Math.max(0,minuteNow-1500*60),Math.max(0,minuteNow-1000*60),Math.max(0,minuteNow-500*60)];
  function valid(rows){
    const a=normalizeLbankKline(Array.isArray(rows)?rows:[]).filter(r=>{
      const o=+r[1],h=+r[2],l=+r[3],c=+r[4];
      return [r[0],o,h,l,c].every(Number.isFinite)&&o>0&&h>0&&l>0&&c>0&&h>=Math.max(o,c)&&l<=Math.min(o,c)
    }).sort((x,y)=>x[0]-y[0]),out=[];
    for(const r of a)if(!out.length||out[out.length-1][0]!==r[0])out.push(r);
    return out;
  }
  async function fetchValid(path){
    let best=[];
    for(const base of LBANK_API_BASES){
      const ctl=new AbortController(),timer=setTimeout(()=>ctl.abort(),8000);
      try{
        const r=await fetch(base+path,{cache:'no-store',signal:ctl.signal});
        if(!r.ok)continue;
        const j=await r.json();
        if(j&&j.result!==undefined&&String(j.result).toLowerCase()!=='true')continue;
        const raw=Array.isArray(j?.data)?j.data:(Array.isArray(j?.data?.data)?j.data.data:j);
        const rows=valid(raw);
        if(rows.length>best.length)best=rows;
        if(rows.length>=Math.min(100,limit))break;
      }catch(_e){}finally{clearTimeout(timer)}
    }
    return best;
  }
  let rows=[];
  for(const t of anchors){
    const got=await fetchValid(`/v2/kline.do?symbol=${encodeURIComponent(pair(key))}&type=minute1&size=2000&time=${t}`);
    if(got.length>rows.length)rows=got;
    if(rows.length>=100)break;
  }
  if(rows.length<20){
    try{const wsRows=await requestLbankHistory(key,2000,9000);if(wsRows.length>rows.length)rows=wsRows}catch(_e){}
  }
  const merged=[...(rows||[]),...(cpOneMin[key]||[])].sort((x,y)=>x[0]-y[0]),dedup=[];
  for(const r of merged){
    const q=dedup[dedup.length-1];
    if(q&&q[0]===r[0]){q[1]=r[1];q[2]=Math.max(+q[2],+r[2]);q[3]=Math.min(+q[3],+r[3]);q[4]=r[4];q[5]=Math.max(+(q[5]||0),+(r[5]||0))}
    else dedup.push(r);
  }
  return cpAggregate1m(dedup.slice(-2000),interval).slice(-limit);
}
function sharedLiveCandle(sym,interval='1m'){const a=cpOneMin[String(sym).toUpperCase()]||[];return cpAggregate1m(a,interval).slice(-1)[0]||null}

function subscribeLive(sym,fn){const key=String(sym).toUpperCase();(liveListeners[key]||(liveListeners[key]=[])).push(fn);startLiveSocket();return ()=>{liveListeners[key]=(liveListeners[key]||[]).filter(x=>x!==fn)}}
async function ticker(sym){
  const key=String(sym).toUpperCase();
  try{
    const d=await lbankFetch('/v2/supplement/ticker/price.do?symbol='+encodeURIComponent(pair(key)));
    const row=Array.isArray(d?.data)?d.data[0]:d?.data; const price=Number(row?.price);
    if(!Number.isFinite(price))throw new Error('bad latest price');
    let extra={change:0,volume:0,high:price,low:price};
    try{const q=await lbankFetch('/v2/ticker/24hr.do?symbol='+encodeURIComponent(pair(key)));const t=Array.isArray(q?.data)?q.data[0]?.ticker:q?.data?.ticker;if(t)extra={change:Number(t.change)||0,volume:Number(t.vol)||0,high:Number(t.high)||price,low:Number(t.low)||price}}catch(_e){}
    const out={price,...extra,lastUpdate:Date.now(),connected:true,provider:'LBank'};liveCache[key]={...(liveCache[key]||{}),...out};setDataStatus(true);return out;
  }catch(e){setDataStatus(false);throw e}
}
async function candles(sym,interval='1h',limit=240){
  const key=String(sym).toUpperCase();
  try{const d=await lbankFetch(`/v2/kline.do?symbol=${encodeURIComponent(pair(key))}&type=${lbankType(interval)}&size=${Math.min(2000,limit)}`);const rows=Array.isArray(d?.data)?d.data:d;const out=normalizeLbankKline(rows).sort((a,b)=>+a[0]-+b[0]);if(out.length<Math.min(10,limit))throw new Error('No LBank candles');setDataStatus(true);return out}catch(e){setDataStatus(false);throw e}
}
async function depth(sym,limit=10){
  const key=String(sym).toUpperCase();
  try{const d=await lbankFetch(`/v2/depth.do?symbol=${encodeURIComponent(pair(key))}&size=${Math.min(60,limit)}`);if(d?.asks&&d?.bids){setDataStatus(true);return d}}
  catch(e){}
  throw new Error('LBank depth unavailable')
}
function normalizeDepth(d){
  const raw=d?.data||d;
  const asks=(raw?.asks||raw?.ask||[]).map(x=>Array.isArray(x)?[+x[0],+x[1]]:[+(x.price??x.p),+(x.amount??x.qty??x.volume??x.v)]).filter(x=>Number.isFinite(x[0])&&Number.isFinite(x[1]));
  const bids=(raw?.bids||raw?.bid||[]).map(x=>Array.isArray(x)?[+x[0],+x[1]]:[+(x.price??x.p),+(x.amount??x.qty??x.volume??x.v)]).filter(x=>Number.isFinite(x[0])&&Number.isFinite(x[1]));
  return {asks,bids};
}
async function livePrice(sym){return (await ticker(sym)).price}
function initLivePrice(sym,id){const update=()=>livePrice(sym).then(p=>{const e=document.getElementById(id);if(e)e.textContent=money(p)}).catch(()=>{});update();const off=subscribeLive(sym,d=>{if(d.type==='ticker'){const e=document.getElementById(id);if(e)e.textContent=money(d.price)}});return off}
window.addEventListener('online',()=>{liveHub.retry=0;closeLiveHub();setTimeout(()=>startLiveSocket(),300)});
window.addEventListener('offline',()=>{closeLiveHub();setDataStatus(false);showNetworkAlert(true)});
if(!/\basset\.html$/i.test(location.pathname))startLiveSocket();

function formatCompact(n){if(n>=1e9)return (n/1e9).toFixed(2)+'B';if(n>=1e6)return (n/1e6).toFixed(2)+'M';if(n>=1e3)return (n/1e3).toFixed(2)+'K';return Number(n||0).toFixed(2)}
function favorites(){try{return JSON.parse(localStorage.getItem('cp_favorites')||'[]')}catch{return[]}}
function toggleFavorite(sym){let a=favorites();a=a.includes(sym)?a.filter(x=>x!==sym):[...a,sym];localStorage.setItem('cp_favorites',JSON.stringify(a));return a}
function isFavorite(sym){return favorites().includes(sym)}
function saveAlert(sym,target,dir='above'){let a=[];try{a=JSON.parse(localStorage.getItem('cp_alerts')||'[]')}catch{};a.push({id:Date.now(),sym,target:+target,dir,active:true});localStorage.setItem('cp_alerts',JSON.stringify(a));return a}
function checkAlerts(sym,price){let a=[];try{a=JSON.parse(localStorage.getItem('cp_alerts')||'[]')}catch{};let changed=false;a=a.map(x=>{if(x.active&&x.sym===sym&&((x.dir==='above'&&price>=x.target)||(x.dir==='below'&&price<=x.target))){x.active=false;changed=true;toast(`هشدار ${sym}: قیمت به ${money(x.target)} رسید`)}return x});if(changed){localStorage.setItem('cp_alerts',JSON.stringify(a));pushNotification('هشدار قیمت',`هشدار ${sym} فعال شد؛ قیمت به ${money(price)} رسید`,'alert')}}


function profileState(){try{const d=JSON.parse(localStorage.getItem('cp_profile')||'{}');return {name:d.name||'CryptoPulse User',email:d.email||'',ref:d.ref||'',joined:d.joined||new Date().toLocaleDateString('en-US'),referrals:+(d.referrals||0),reward:+(d.reward||0),tier:d.tier||'Starter'}}catch(e){return {name:'CryptoPulse User',email:'',ref:'',joined:new Date().toLocaleDateString('en-US'),referrals:0,reward:0,tier:'Starter'}}}
function saveProfile(p){localStorage.setItem('cp_profile',JSON.stringify(p))}
function makeReferral(){const p=profileState();if(!p.ref)p.ref='CP'+Math.random().toString(36).slice(2,8).toUpperCase();saveProfile(p);return p.ref}
function copyText(t){navigator.clipboard?.writeText(t).then(()=>toast('کپی شد')).catch(()=>toast('کپی خودکار در دسترس نیست','error'))}
function profileStats(){const p=profileState(),s=state();return {trades:(s.history||[]).length+(s.spot||[]).length, pnl:(s.history||[]).reduce((a,x)=>a+(+x.pnl||0),0),referrals:p.referrals,reward:p.reward}}


function portfolioSummary(){
  const s=state(), holdings=s.holdings||{}; let total=0, assets=0;
  Object.entries(holdings).forEach(([sym,v])=>{const qty=+(v||0); if(qty>0){assets++; const cached=liveCache[String(sym).toUpperCase()]; const px=Number(cached?.price)||Number(getCoin(sym)?.[2])||0; total+=qty*px}});
  let futuresMargin=0, futuresPnl=0;
  const p=s.open;
  if(p&&Number.isFinite(+p.margin)){
    futuresMargin=+p.margin||0;
    const cached=liveCache[String(p.symbol||'').toUpperCase()];
    const mark=Number(cached?.price)||0;
    if(mark&&+p.entry){
      const move=p.side==='LONG'?(mark-p.entry)/p.entry:(p.entry-mark)/p.entry;
      futuresPnl=futuresMargin*(+p.leverage||1)*move;
    }
  }
  return {cash:+s.balance||0,assets,total,futuresMargin,futuresPnl,equity:(+s.balance||0)+total+futuresMargin+futuresPnl,history:(s.history||[]).length+(s.spot||[]).length};
}
function renderHomeSnapshot(){
  const el=document.getElementById('homeSnapshot'); if(!el)return;
  const p=portfolioSummary();
  el.innerHTML=`<div class="snapshot-card"><span>Paper Balance</span><b>${money(p.cash)} USDT</b><small>${p.history} معامله ثبت‌شده</small></div><div class="snapshot-card"><span>دارایی‌ها</span><b>${p.assets}</b><small>دارایی دارای موجودی</small></div><div class="snapshot-card"><span>ارزش تقریبی</span><b>${money(p.cash+p.total)} USDT</b><small>بر پایه قیمت‌های نمایشی</small></div>`;
}
function initDashboard(){
  const render=async()=>{
    const d=await ticker('BTC');
    const price=document.getElementById('btcPrice'); if(price)price.textContent=money(d.price);
    const ch=document.getElementById('btcChange'); if(ch){ch.textContent=(d.change>=0?'+':'')+d.change.toFixed(2)+'%';ch.className=d.change>=0?'up':'down'}
    const cc=document.getElementById('btcChangeCard'); if(cc){cc.textContent=(d.change>=0?'+':'')+d.change.toFixed(2)+'% امروز';cc.className=d.change>=0?'up':'down'}
    const vol=document.getElementById('btcVolume'); if(vol)vol.textContent=formatCompact(d.volume);
    const st=document.getElementById('syncTime'); if(st)st.textContent=new Date().toLocaleTimeString('fa-IR',{hour:'2-digit',minute:'2-digit',second:'2-digit'});
    checkAlerts('BTC',d.price);
  };
  render(); setInterval(render,10000);
  renderWatchlist();
  renderHomeSnapshot();
}
function renderWatchlist(){
  const box=document.getElementById('watchlist'), empty=document.getElementById('watchEmpty'); if(!box)return;
  const fav=favorites(); const list=coins.filter(c=>fav.includes(c[0]));
  box.innerHTML=list.length?coinCards(list.slice(0,6)) : ''; if(empty)empty.style.display=list.length?'none':'block';
}

function calcRSI(values, period=14){if(values.length<=period)return 50;let gains=0,losses=0;for(let i=1;i<=period;i++){const d=values[i]-values[i-1];if(d>=0)gains+=d;else losses-=d}let avgG=gains/period,avgL=losses/period;for(let i=period+1;i<values.length;i++){const d=values[i]-values[i-1];avgG=((avgG*(period-1))+Math.max(d,0))/period;avgL=((avgL*(period-1))+Math.max(-d,0))/period}if(avgL===0)return 100;return 100-(100/(1+avgG/avgL))}
function calcEMA(values,period){const k=2/(period+1);let ema=values[0];for(let i=1;i<values.length;i++)ema=values[i]*k+ema*(1-k);return ema}
function calcMACD(values){const fast=calcEMA(values.slice(-60),12),slow=calcEMA(values.slice(-60),26);const macd=fast-slow;return {value:macd,signal:macd*0.88}}
function volatility(values){if(values.length<2)return 0;const r=[];for(let i=1;i<values.length;i++)r.push(Math.log(values[i]/values[i-1]));const avg=r.reduce((a,b)=>a+b,0)/r.length;return Math.sqrt(r.reduce((a,b)=>a+(b-avg)**2,0)/r.length)*100}
