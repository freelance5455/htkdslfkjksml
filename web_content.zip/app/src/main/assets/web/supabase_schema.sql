-- EC Technologie V4 Cloud
-- À exécuter une seule fois dans Supabase > SQL Editor.
create table if not exists public.app_data (
  user_id uuid primary key references auth.users(id) on delete cascade,
  data jsonb not null default '{}'::jsonb,
  revision bigint not null default 0,
  updated_at timestamptz not null default now(),
  updated_by_device text
);

create table if not exists public.devices (
  user_id uuid not null references auth.users(id) on delete cascade,
  device_id text not null,
  name text not null default 'Appareil',
  created_at timestamptz not null default now(),
  last_seen timestamptz not null default now(),
  primary key (user_id, device_id)
);

alter table public.app_data enable row level security;
alter table public.devices enable row level security;

-- Les fonctions ci-dessous sont le seul chemin d'écriture utilisé par l'application.
create or replace function public.register_device(p_device_id text, p_name text)
returns jsonb language plpgsql security definer set search_path=public as $$
declare n integer;
begin
  if auth.uid() is null then return jsonb_build_object('ok',false,'message','Non authentifié.'); end if;
  insert into public.devices(user_id,device_id,name,last_seen)
  values(auth.uid(),p_device_id,coalesce(nullif(p_name,''),'Appareil'),now())
  on conflict(user_id,device_id) do update set name=excluded.name,last_seen=now();
  select count(*) into n from public.devices where user_id=auth.uid();
  if n > 5 then
    delete from public.devices where user_id=auth.uid() and device_id=p_device_id;
    return jsonb_build_object('ok',false,'message','Limite de 5 appareils atteinte.');
  end if;
  return jsonb_build_object('ok',true,'count',n,'max',5);
end; $$;

create or replace function public.sync_data(p_base_revision bigint, p_data jsonb, p_device_id text)
returns jsonb language plpgsql security definer set search_path=public as $$
declare r bigint; d jsonb;
begin
  if auth.uid() is null then return jsonb_build_object('status','error','message','Non authentifié.'); end if;
  select revision,data into r,d from public.app_data where user_id=auth.uid();
  if not found then
    insert into public.app_data(user_id,data,revision,updated_by_device) values(auth.uid(),p_data,1,p_device_id);
    update public.devices set last_seen=now() where user_id=auth.uid() and device_id=p_device_id;
    return jsonb_build_object('status','ok','revision',1);
  end if;
  if coalesce(p_base_revision,0) <> r then
    return jsonb_build_object('status','conflict','revision',r,'data',d);
  end if;
  update public.app_data set data=p_data,revision=r+1,updated_at=now(),updated_by_device=p_device_id where user_id=auth.uid();
  update public.devices set last_seen=now() where user_id=auth.uid() and device_id=p_device_id;
  return jsonb_build_object('status','ok','revision',r+1);
end; $$;

revoke all on public.app_data from anon, authenticated;
revoke all on public.devices from anon, authenticated;
grant execute on function public.register_device(text,text) to authenticated;
grant execute on function public.sync_data(bigint,jsonb,text) to authenticated;
