let expression = "";
const display = document.getElementById("display");

function render() {
  display.textContent = expression || "0";
}

function appendValue(value) {
  if (expression === "Error") expression = "";
  expression += value;
  render();
}

function clearDisplay() {
  expression = "";
  render();
}

function backspace() {
  expression = expression.slice(0, -1);
  render();
}

function calculate() {
  if (!expression) return;
  try {
    // Calculator-only expression evaluation.
    if (!/^[0-9+\-*/%.() ]+$/.test(expression)) throw new Error();
    let result = Function('"use strict"; return (' + expression + ')')();
    if (!Number.isFinite(result)) throw new Error();
    expression = String(Math.round((result + Number.EPSILON) * 1e12) / 1e12);
  } catch (e) {
    expression = "Error";
  }
  render();
}
