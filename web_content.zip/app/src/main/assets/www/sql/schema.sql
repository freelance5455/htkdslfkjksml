-- ==============================================================================
-- আলী আজগর সিদ্দিকিয়া মাদ্রাসা (Ali Azgar Siddiqia Madrasa)
-- Supabase Cloud Database Complete Schema & Open Permissions Setup
-- ==============================================================================

-- 1. Members Table
CREATE TABLE IF NOT EXISTS public.members (
    id TEXT PRIMARY KEY,
    member_id TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    phone TEXT DEFAULT '',
    photo_url TEXT DEFAULT '',
    address TEXT DEFAULT '',
    join_date DATE DEFAULT CURRENT_DATE,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now())
);

-- 2. Payments Table (মাসিক চাঁদা ও অনুদান)
CREATE TABLE IF NOT EXISTS public.payments (
    id TEXT PRIMARY KEY,
    receipt_no TEXT UNIQUE NOT NULL,
    member_id TEXT NOT NULL,
    month TEXT NOT NULL,
    amount NUMERIC(10,2) NOT NULL,
    status TEXT DEFAULT 'paid',
    payment_date DATE DEFAULT CURRENT_DATE,
    payment_method TEXT DEFAULT 'নগদ',
    trx_id TEXT,
    note TEXT,
    confirmed_by TEXT,
    confirmed_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now())
);

-- 3. Expenses Table (মাদ্রাসার খরচ ও ভাউচার)
CREATE TABLE IF NOT EXISTS public.expenses (
    id TEXT PRIMARY KEY,
    voucher_no TEXT UNIQUE NOT NULL,
    title TEXT NOT NULL,
    amount NUMERIC(10,2) NOT NULL,
    category TEXT DEFAULT 'সাধারণ',
    expense_date DATE DEFAULT CURRENT_DATE,
    note TEXT,
    created_by TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now())
);

-- 4. Notices Table (নোটিশ বোর্ড)
CREATE TABLE IF NOT EXISTS public.notices (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    body TEXT NOT NULL,
    is_pinned BOOLEAN DEFAULT false,
    published_date DATE DEFAULT CURRENT_DATE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now())
);

-- 5. Projects Table (উন্নয়নমূলক প্রকল্প)
CREATE TABLE IF NOT EXISTS public.projects (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT,
    estimated_cost NUMERIC(12,2) DEFAULT 0,
    collected_amount NUMERIC(12,2) DEFAULT 0,
    spent_amount NUMERIC(12,2) DEFAULT 0,
    status TEXT DEFAULT 'পরিকল্পনাধীন',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now())
);

-- 6. Settings Table
CREATE TABLE IF NOT EXISTS public.app_settings (
    key TEXT PRIMARY KEY,
    value JSONB NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now())
);

-- 7. Disable Row Level Security (RLS) to allow seamless mobile app syncing
ALTER TABLE public.members DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.payments DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.expenses DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.notices DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.projects DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.app_settings DISABLE ROW LEVEL SECURITY;

-- If RLS is ever enabled on the project, create open policies for anon & authenticated roles:
DROP POLICY IF EXISTS "Allow all members" ON public.members;
CREATE POLICY "Allow all members" ON public.members FOR ALL USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "Allow all payments" ON public.payments;
CREATE POLICY "Allow all payments" ON public.payments FOR ALL USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "Allow all expenses" ON public.expenses;
CREATE POLICY "Allow all expenses" ON public.expenses FOR ALL USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "Allow all notices" ON public.notices;
CREATE POLICY "Allow all notices" ON public.notices FOR ALL USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "Allow all projects" ON public.projects;
CREATE POLICY "Allow all projects" ON public.projects FOR ALL USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "Allow all settings" ON public.app_settings;
CREATE POLICY "Allow all settings" ON public.app_settings FOR ALL USING (true) WITH CHECK (true);

-- 8. Grant full permissions
GRANT ALL ON TABLE public.members TO anon, authenticated, service_role;
GRANT ALL ON TABLE public.payments TO anon, authenticated, service_role;
GRANT ALL ON TABLE public.expenses TO anon, authenticated, service_role;
GRANT ALL ON TABLE public.notices TO anon, authenticated, service_role;
GRANT ALL ON TABLE public.projects TO anon, authenticated, service_role;
GRANT ALL ON TABLE public.app_settings TO anon, authenticated, service_role;
