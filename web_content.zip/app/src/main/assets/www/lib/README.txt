Optional offline libs: html2pdf.bundle.min.js, jspdf.umd.min.js, jspdf.plugin.autotable.min.js, xlsx.full.min.js (cdnjs: html2pdf.js 0.10.1, jspdf 2.5.1, jspdf-autotable 3.8.2, xlsx 0.18.5)
