// Configure no Supabase: Project Settings > API (ou Connect).
// Use apenas a chave pública anon/publishable. NUNCA use service_role/secret aqui.
window.APP_CONFIG = {
  SUPABASE_URL: "https://djgefblhxxkojyxfsuxl.supabase.co",
  SUPABASE_ANON_KEY: "sb_publishable_XOT0LWqzcW0wcIiD5dEnCQ_4KtrEu3h"
};