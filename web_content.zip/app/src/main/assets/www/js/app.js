
(function () {
    "use strict";

    const PAGINAS = {
        painel: {
            titulo: "Painel principal",
            descricao: "Visão geral da situação financeira"
        },
        entradas: {
            titulo: "Gestão de entradas",
            descricao: "Controlo de mensalidades, matrículas e outras receitas"
        },
        salarios: {
            titulo: "Gestão de salários",
            descricao: "Funcionários, folhas salariais e pagamentos"
        },
        despesas: {
            titulo: "Outras saídas",
            descricao: "Controlo das despesas da instituição"
        },
        relatorios: {
            titulo: "Relatórios",
            descricao: "Consultas, balanços e análises financeiras"
        },
        configuracoes: {
            titulo: "Configurações",
            descricao: "Personalização e administração do sistema"
        }
    };

    let paginaAtual = "painel";

    const elementos = {
        menu: document.querySelector(".menu-lateral"),
        botaoMenu: document.getElementById("btnMenu"),
        botoesNavegacao: document.querySelectorAll("[data-pagina]"),
        paginaPainel: document.getElementById("paginaPainel"),
        paginaModulo: document.getElementById("paginaModulo"),
        moduloTitulo: document.getElementById("moduloTitulo"),
        moduloDescricao: document.getElementById("moduloDescricao"),
        dataAtual: document.getElementById("dataAtual"),
        anoAtual: document.getElementById("anoAtual"),
        conteudoModulo: document.getElementById("conteudoModulo")
    };

    // Actualizar data e ano
    function actualizarData() {
        const agora = new Date();

        if (elementos.dataAtual) {
            elementos.dataAtual.textContent =
                agora.toLocaleDateString("pt-AO", {
                    weekday: "short",
                    day: "2-digit",
                    month: "short",
                    year: "numeric"
                });
        }

        if (elementos.anoAtual) {
            elementos.anoAtual.textContent = agora.getFullYear();
        }
    }

    // Abrir uma página do sistema
    async function abrirPagina(nome) {
        const pagina = PAGINAS[nome];

        if (!pagina) return;

        paginaAtual = nome;

        // Actualizar os botões do menu
        elementos.botoesNavegacao.forEach(botao => {
            const activo = botao.dataset.pagina === nome;

            botao.classList.toggle("ativo", activo);

            if (activo) {
                botao.setAttribute("aria-current", "page");
            } else {
                botao.removeAttribute("aria-current");
            }
        });

        // Abrir painel principal
        if (nome === "painel") {
            if (elementos.paginaPainel) {
                elementos.paginaPainel.hidden = false;
            }

            if (elementos.paginaModulo) {
                elementos.paginaModulo.hidden = true;
            }

            if (window.SGFE_PAINEL) {
                try {
                    await window.SGFE_PAINEL.atualizar();
                } catch (erro) {
                    console.error("Erro ao actualizar painel:", erro);
                }
            }

        } else {
            // Abrir área dos módulos
            if (elementos.paginaPainel) {
                elementos.paginaPainel.hidden = true;
            }

            if (elementos.paginaModulo) {
                elementos.paginaModulo.hidden = false;
            }

            if (elementos.moduloTitulo) {
                elementos.moduloTitulo.textContent = pagina.titulo;
            }

            if (elementos.moduloDescricao) {
                elementos.moduloDescricao.textContent = pagina.descricao;
            }

            // Limpar conteúdo anterior
            if (elementos.conteudoModulo) {
                elementos.conteudoModulo.innerHTML = "";
            }

            // Activar o módulo correspondente
            await activarModulo(nome);
        }

        fecharMenu();
    }

    // Activar os módulos disponíveis
    async function activarModulo(nome) {
        const modulos = {
            entradas: window.SGFE_ENTRADAS,
            salarios: window.SGFE_SALARIOS,
            despesas: window.SGFE_DESPESAS,
            relatorios: window.SGFE_RELATORIOS,
            configuracoes: window.SGFE_CONFIGURACOES
        };

        const modulo = modulos[nome];

        if (modulo && typeof modulo.abrir === "function") {
            try {
                await modulo.abrir();
                return;
            } catch (erro) {
                console.error("Erro ao abrir módulo:", nome, erro);
            }
        }

        // Mensagem provisória para módulos ainda não desenvolvidos
        if (elementos.conteudoModulo) {
            elementos.conteudoModulo.innerHTML = `
                <div class="modulo-placeholder">
                    <div class="placeholder-icone">▤</div>
                    <h3>${PAGINAS[nome].titulo}</h3>
                    <p>Este módulo será desenvolvido nas próximas etapas.</p>
                </div>
            `;
        }
    }

    // Abrir menu lateral
    function abrirMenu() {
        if (elementos.menu) {
            elementos.menu.classList.add("aberto");
        }
    }

    // Fechar menu lateral
    function fecharMenu() {
        if (elementos.menu) {
            elementos.menu.classList.remove("aberto");
        }
    }

    // Alternar menu lateral
    function alternarMenu() {
        if (!elementos.menu) return;

        elementos.menu.classList.toggle("aberto");
    }

    // Eventos dos botões de navegação
    elementos.botoesNavegacao.forEach(botao => {
        botao.addEventListener("click", function () {
            abrirPagina(this.dataset.pagina);
        });
    });

    // Evento do botão do menu
    if (elementos.botaoMenu) {
        elementos.botaoMenu.addEventListener("click", function (evento) {
            evento.stopPropagation();
            alternarMenu();
        });
    }

    // Fechar menu ao clicar fora dele
    document.addEventListener("click", function (evento) {
        if (!elementos.menu || !elementos.botaoMenu) return;

        const clicouNoMenu = elementos.menu.contains(evento.target);
        const clicouNoBotao = elementos.botaoMenu.contains(evento.target);

        if (!clicouNoMenu && !clicouNoBotao) {
            fecharMenu();
        }
    });

    // Inicialização do sistema
    function iniciar() {
        actualizarData();
        abrirPagina("painel");
    }

    // Disponibilizar funções para outros módulos
    window.SGFE_APP = Object.freeze({
        abrirPagina,
        abrirMenu,
        fecharMenu,
        alternarMenu,
        actualizarData,

        get paginaAtual() {
            return paginaAtual;
        }
    });

    // Activar funcionamento offline
    function activarModoOffline() {
        if ("serviceWorker" in navigator) {
            window.addEventListener("load", function () {
                navigator.serviceWorker.register("./sw.js")
                    .then(function () {
                        console.log(
                            "SGFE: funcionamento offline activado."
                        );
                    })
                    .catch(function (erro) {
                        console.error(
                            "SGFE: erro ao activar funcionamento offline:",
                            erro
                        );
                    });
            });
        }
    }

    iniciar();
    activarModoOffline();

})();
