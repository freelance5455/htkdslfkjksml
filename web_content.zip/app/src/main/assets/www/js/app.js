/**
 * আলী আজগর সিদ্দিকিয়া মাদ্রাসা (Ali Azgar Siddiqia Madrasa)
 * Primary UI Controller, Internationalization & Event Dispatcher
 */

document.addEventListener('DOMContentLoaded', async () => {
  // 1. Initialize Internationalization (Bengali / English)
  if (window.I18n) {
    window.I18n.init();
  }

  // 2. Initialize Supabase if credentials saved
  window.SupabaseModule.initSupabase();

  // 3. Setup Realtime hook
  window.onSupabaseRealtimeChange = (payload) => {
    App.showToast(App.t('msg_realtime_sync', "সার্ভার থেকে রিয়েল-টাইম ডাটা আপডেট হয়েছে"), "success");
    App.refreshCurrentView();
  };

  // 4. Initialize Application UI
  App.init();
});

const App = {
  currentView: 'dashboard',
  selectedMonth: new Date().toISOString().slice(0, 7), // e.g. "2026-09"
  selectedYear: new Date().getFullYear().toString(),
  memberFilter: 'all',
  activeMemberId: null,

  async init() {
    this.bindEvents();
    this.updateAdminUI();
    await this.renderDashboard();
    this.setupPWA();
  },

  // --------------------------------------------------------------------------
  // Internationalization Helpers
  // --------------------------------------------------------------------------
  t(key, fallback = '') {
    return window.I18n ? window.I18n.get(key, fallback) : fallback || key;
  },

  toggleLanguage() {
    if (window.I18n) {
      window.I18n.toggleLanguage();
      this.updateAdminUI();
      this.refreshCurrentView();
    }
  },

  setLanguage(lang) {
    if (window.I18n) {
      window.I18n.setLanguage(lang);
      this.updateAdminUI();
      this.refreshCurrentView();
    }
  },

  // --------------------------------------------------------------------------
  // Navigation & View Routing
  // --------------------------------------------------------------------------
  navigate(viewId) {
    this.currentView = viewId;
    document.querySelectorAll('.view-section').forEach(sec => sec.classList.remove('active'));
    
    const target = document.getElementById(`view-${viewId}`);
    if (target) {
      target.classList.add('active');
    }

    // Update bottom navigation bar active states
    document.querySelectorAll('.nav-item').forEach(btn => {
      btn.classList.toggle('active', btn.dataset.view === viewId);
    });

    window.scrollTo({ top: 0, behavior: 'smooth' });

    // Render corresponding view data
    switch (viewId) {
      case 'dashboard':
        this.renderDashboard();
        break;
      case 'members':
        this.renderMembers();
        break;
      case 'chanda':
        this.renderChanda();
        break;
      case 'monthly-accounts':
        this.renderMonthlyAccounts();
        break;
      case 'expenses':
        this.renderExpenses();
        break;
      case 'yearly-report':
        this.renderYearlyReport();
        break;
      case 'notices':
        this.renderNotices();
        break;
      case 'projects':
        this.renderProjects();
        break;
      case 'payment-qr':
        this.renderPaymentQR();
        break;
      case 'settings':
        this.renderSettings();
        break;
      default:
        this.renderDashboard();
    }
  },

  refreshCurrentView() {
    this.navigate(this.currentView);
  },

  // --------------------------------------------------------------------------
  // Date & Month Formatters (Bilingual)
  // --------------------------------------------------------------------------
  getCurrentDateString() {
    const isEn = window.I18n && window.I18n.currentLang === 'en';
    const now = new Date();
    if (isEn) {
      const monthsEn = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
      return `${now.getDate()} ${monthsEn[now.getMonth()]}, ${now.getFullYear()}`;
    } else {
      const monthsBn = ['জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন', 'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'];
      const day = DB.toBnNum(now.getDate());
      const month = monthsBn[now.getMonth()];
      const year = DB.toBnNum(now.getFullYear());
      return `${day} ${month}, ${year}`;
    }
  },

  getMonthNameBn(monthStr) {
    return this.getMonthLabel(monthStr);
  },

  getMonthLabel(monthStr) {
    if (!monthStr) return '';
    const [year, m] = monthStr.split('-');
    const idx = parseInt(m, 10) - 1;
    const isEn = window.I18n && window.I18n.currentLang === 'en';
    if (isEn) {
      const monthsEn = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
      return `${monthsEn[idx] || m} ${year}`;
    } else {
      const monthsBn = ['জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন', 'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'];
      return `${monthsBn[idx] || m} ${DB.toBnNum(year)}`;
    }
  },

  // --------------------------------------------------------------------------
  // Admin UI State
  // --------------------------------------------------------------------------
  updateAdminUI() {
    const isAdmin = window.Auth.isAdmin();
    const adminUser = window.Auth.getCurrentUser();
    const adminPill = document.getElementById('admin-status-pill');
    const adminActionEls = document.querySelectorAll('.admin-only');

    if (adminPill) {
      if (isAdmin) {
        adminPill.innerHTML = `<span>👑 ${this.t('admin_label', 'অ্যাডমিন')}: ${adminUser.name || this.t('authorized', 'অনুমোদিত')}</span>`;
        adminPill.classList.add('logged-in');
      } else {
        adminPill.innerHTML = `<span>🔐 ${this.t('login', 'অ্যাডমিন লগইন')}</span>`;
        adminPill.classList.remove('logged-in');
      }
    }

    // Toggle admin-only controls
    adminActionEls.forEach(el => {
      el.style.display = isAdmin ? '' : 'none';
    });

    // Connection status indicator
    const syncPill = document.getElementById('supabase-sync-pill');
    if (syncPill) {
      const isSb = window.SupabaseModule.isConfiguredWithSupabase();
      syncPill.innerHTML = `
        <span class="sync-indicator ${isSb ? '' : 'offline'}"></span>
        <span>${isSb ? this.t('sync_supabase', 'Supabase সংযুক্ত') : this.t('sync_local', 'লোকাল মোড')}</span>
      `;
    }

    // Update Language selection buttons in Settings card
    const curLang = window.I18n ? window.I18n.currentLang : 'bn';
    document.querySelectorAll('.lang-select-btn').forEach(btn => {
      btn.classList.toggle('active', btn.dataset.lang === curLang);
    });
  },

  // --------------------------------------------------------------------------
  // 1. Dashboard View
  // --------------------------------------------------------------------------
  async renderDashboard() {
    const metrics = await DB.getDashboardMetrics(this.selectedMonth);
    const dateDisplay = document.getElementById('hero-date-display');
    if (dateDisplay) dateDisplay.textContent = this.getCurrentDateString();

    const monthLabel = this.getMonthLabel(metrics.currentMonth);
    const monthEl = document.getElementById('metric-month-name');
    if (monthEl) monthEl.textContent = monthLabel;

    // Numbers display
    const totalColl = document.getElementById('dash-total-collection');
    const totalExp = document.getElementById('dash-total-expense');
    const currBal = document.getElementById('dash-current-balance');
    const totalM = document.getElementById('dash-total-members');
    const paidM = document.getElementById('dash-paid-members');
    const unpaidM = document.getElementById('dash-unpaid-members');

    if (totalColl) totalColl.textContent = DB.formatTaka(metrics.thisMonthCollection);
    if (totalExp) totalExp.textContent = DB.formatTaka(metrics.thisMonthExpense);
    if (currBal) currBal.textContent = DB.formatTaka(metrics.currentBalance);
    if (totalM) totalM.textContent = `${DB.toBnNum(metrics.totalMembers)} ${this.t('persons_unit', 'জন')}`;
    if (paidM) paidM.textContent = `${DB.toBnNum(metrics.paidMembersCount)} ${this.t('persons_unit', 'জন')}`;
    if (unpaidM) unpaidM.textContent = `${DB.toBnNum(metrics.unpaidMembersCount)} ${this.t('persons_unit', 'জন')}`;

    // Render Recent Transactions
    const txContainer = document.getElementById('dash-recent-tx');
    if (txContainer) {
      const members = await DB.getMembers();
      const memberMap = {};
      members.forEach(m => {
        memberMap[String(m.id)] = m;
        if (m.member_id) memberMap[String(m.member_id)] = m;
      });

      if (metrics.recentPayments.length === 0) {
        txContainer.innerHTML = `<div class="empty-state">${this.t('no_recent_tx', 'কোন সাম্প্রতিক লেনদেন পাওয়া যায়নি')}</div>`;
      } else {
        txContainer.innerHTML = metrics.recentPayments.map(p => {
          const m = memberMap[String(p.member_id)] || { name: this.t('member', 'সদস্য'), member_id: '---' };
          const isPaid = p.status === 'paid';
          const monthText = this.getMonthLabel(p.month);
          const statusText = isPaid ? this.t('status_approved', 'অনুমোদিত') : this.t('status_pending', 'যাচাইাধীন');

          return `
            <div class="member-item-card" onclick="App.showMoneyReceiptById('${p.id}')">
              <div class="member-avatar">
                ${isPaid ? '৳' : '⏳'}
              </div>
              <div class="member-info">
                <div class="member-name">${m.name} <span class="id-badge">${m.member_id}</span></div>
                <div class="member-meta">
                  <span>${this.t('table_month', 'মাস')}: ${monthText}</span> • 
                  <span>${this.t('receipt_method', 'পদ্ধতি')}: ${p.payment_method}</span>
                </div>
              </div>
              <div style="text-align: right;">
                <div style="font-weight: 700; color: ${isPaid ? 'var(--primary)' : 'var(--status-pending)'}">
                  + ${DB.formatTaka(p.amount)}
                </div>
                <span class="status-badge ${p.status}">
                  ${statusText}
                </span>
              </div>
            </div>
          `;
        }).join('');
      }
    }
  },

  // --------------------------------------------------------------------------
  // 2. Member Management View
  // --------------------------------------------------------------------------
  async renderMembers() {
    const container = document.getElementById('members-list-container');
    if (!container) return;
    container.innerHTML = `<div style="text-align:center; padding: 20px;">${this.t('loading_members', 'সদস্যদের তথ্য লোড হচ্ছে...')}</div>`;

    const [members, payments] = await Promise.all([
      DB.getMembers(),
      DB.getPayments(this.selectedMonth)
    ]);

    const paidMemberIds = new Set(
      payments
        .filter(p => p.status === 'paid')
        .flatMap(p => [String(p.member_id), String(p.id)])
    );

    const searchQuery = (document.getElementById('member-search-input')?.value || '').toLowerCase().trim();

    let filtered = members.filter(m => {
      if (searchQuery) {
        const matchName = (m.name || '').toLowerCase().includes(searchQuery);
        const matchPhone = (m.phone || '').includes(searchQuery);
        const matchId = (m.member_id || '').toLowerCase().includes(searchQuery);
        if (!matchName && !matchPhone && !matchId) return false;
      }

      const isPaid = paidMemberIds.has(String(m.id)) || paidMemberIds.has(String(m.member_id));
      if (this.memberFilter === 'paid') {
        return isPaid;
      } else if (this.memberFilter === 'unpaid') {
        return !isPaid;
      }
      return true;
    });

    const badge = document.getElementById('members-count-badge');
    if (badge) {
      badge.textContent = `${DB.toBnNum(filtered.length)} ${this.t('persons_unit', 'জন')}`;
    }

    if (filtered.length === 0) {
      container.innerHTML = `
        <div class="app-card" style="text-align: center; padding: 30px 20px;">
          <div style="font-size: 36px; margin-bottom: 8px;">👥</div>
          <p style="color: var(--text-muted);">${this.t('no_members_found', 'কোন সদস্য পাওয়া যায়নি')}</p>
          <button class="btn-primary" style="margin: 12px auto 0 auto; width: auto;" onclick="App.openModal('add-member-modal')">
            ${this.t('btn_add_member_top', '+ নতুন সদস্য যোগ')}
          </button>
        </div>
      `;
      return;
    }

    container.innerHTML = filtered.map(m => {
      const isPaid = paidMemberIds.has(String(m.id)) || paidMemberIds.has(String(m.member_id));
      const statusText = isPaid ? this.t('status_paid', 'পরিশোধিত') : this.t('status_unpaid', 'বকেয়া');
      const initial = (m.name || 'স').trim().charAt(0);

      return `
        <div class="member-item-card" onclick="App.openMemberDetails('${m.id || m.member_id}')">
          <div class="member-avatar">
            ${m.photo_url ? `<img src="${m.photo_url}" alt="${m.name}"/>` : initial}
          </div>
          <div class="member-info">
            <div class="member-name">${m.name}</div>
            <div class="member-meta">
              <span class="id-badge">${m.member_id}</span>
              ${m.phone ? `<span>📞 ${DB.toBnNum(m.phone)}</span>` : ''}
            </div>
          </div>
          <div>
            <span class="status-badge ${isPaid ? 'paid' : 'unpaid'}">
              ${statusText}
            </span>
          </div>
        </div>
      `;
    }).join('');
  },

  async openMemberDetails(memberId) {
    const member = await DB.getMemberById(memberId);
    if (!member) return;
    this.activeMemberId = member.id || memberId;

    const allPayments = await DB.getPayments();
    const memberPayments = allPayments.filter(p => 
      (String(p.member_id) === String(member.id) || String(p.member_id) === String(member.member_id)) && 
      p.status === 'paid'
    );
    const totalPaid = memberPayments.reduce((acc, p) => acc + Number(p.amount), 0);

    // Populate modal
    const nameEl = document.getElementById('detail-member-name');
    const idEl = document.getElementById('detail-member-id');
    const phoneEl = document.getElementById('detail-member-phone');
    const addrEl = document.getElementById('detail-member-address');
    const joinEl = document.getElementById('detail-member-joindate');
    const totalPaidEl = document.getElementById('detail-member-totalpaid');

    if (nameEl) nameEl.textContent = member.name;
    if (idEl) idEl.textContent = member.member_id;
    if (phoneEl) phoneEl.textContent = member.phone ? DB.toBnNum(member.phone) : this.t('no_info', 'তথ্য নেই');
    if (addrEl) addrEl.textContent = member.address || this.t('no_info', 'তথ্য নেই');
    if (joinEl) joinEl.textContent = DB.toBnNum(member.join_date);
    if (totalPaidEl) totalPaidEl.textContent = DB.formatTaka(totalPaid);

    // Phone call button
    const callBtn = document.getElementById('detail-call-btn');
    if (callBtn) {
      if (member.phone) {
        callBtn.href = `tel:${member.phone}`;
        callBtn.style.display = 'inline-flex';
      } else {
        callBtn.style.display = 'none';
      }
    }

    // Payment history list
    const historyContainer = document.getElementById('detail-payment-history');
    if (historyContainer) {
      if (memberPayments.length === 0) {
        historyContainer.innerHTML = `<p style="color: var(--text-muted); font-size: 0.85rem;">${this.t('no_payments_yet', 'এখনো কোনো পরিশোধের তথ্য জমা হয়নি।')}</p>`;
      } else {
        historyContainer.innerHTML = memberPayments.map(p => `
          <div style="display: flex; justify-content: space-between; padding: 6px 0; border-bottom: 1px dashed #e2e8f0; font-size: 0.84rem;">
            <span>${this.t('table_month', 'মাস')}: ${App.getMonthLabel(p.month)} (${p.payment_method})</span>
            <span style="font-weight: 700; color: var(--primary);">+ ${DB.formatTaka(p.amount)}</span>
          </div>
        `).join('');
      }
    }

    this.openModal('member-details-modal');
  },

  // --------------------------------------------------------------------------
  // 3. Monthly Chanda / Donation View
  // --------------------------------------------------------------------------
  async renderChanda() {
    const monthSelector = document.getElementById('chanda-month-picker');
    if (monthSelector) {
      monthSelector.value = this.selectedMonth;
    }

    const [members, payments, settings] = await Promise.all([
      DB.getMembers(),
      DB.getPayments(this.selectedMonth),
      DB.getSettings()
    ]);

    const defaultAmount = settings?.chanda_config?.default_amount || 100;
    const paymentMap = {};
    payments.forEach(p => {
      paymentMap[String(p.member_id)] = p;
    });

    const confirmedPayments = payments.filter(p => p.status === 'paid');
    const totalCollected = confirmedPayments.reduce((acc, p) => acc + Number(p.amount), 0);
    const totalMembers = members.length;
    const expected = totalMembers * defaultAmount;
    const unpaidDues = Math.max(0, expected - totalCollected);

    const expEl = document.getElementById('chanda-stat-expected');
    const collEl = document.getElementById('chanda-stat-collected');
    const unpEl = document.getElementById('chanda-stat-unpaid');

    if (expEl) expEl.textContent = DB.formatTaka(expected);
    if (collEl) collEl.textContent = DB.formatTaka(totalCollected);
    if (unpEl) unpEl.textContent = DB.formatTaka(unpaidDues);

    const listContainer = document.getElementById('chanda-members-list');
    if (!listContainer) return;

    listContainer.innerHTML = members.map(m => {
      const p = paymentMap[String(m.id)] || paymentMap[String(m.member_id)];
      const isPaid = p && p.status === 'paid';
      const isPending = p && p.status === 'pending';

      return `
        <div class="member-item-card">
          <div class="member-avatar">${(m.name || 'স').charAt(0)}</div>
          <div class="member-info">
            <div class="member-name">${m.name} <span class="id-badge">${m.member_id}</span></div>
            <div class="member-meta">
              <span>${this.t('target_amount', 'ধার্য')}: ${DB.formatTaka(defaultAmount)}</span>
              ${p ? `• <span>${this.t('paid_amount', 'প্রদান')}: ${DB.formatTaka(p.amount)} (${p.payment_method})</span>` : ''}
            </div>
          </div>
          <div>
            ${isPaid ? `
              <span class="status-badge paid" onclick="App.showMoneyReceiptById('${p.id}')">
                ✅ ${this.t('status_paid', 'পরিশোধিত')}
              </span>
            ` : isPending ? `
              <div style="display:flex; flex-direction:column; gap:4px;">
                <span class="status-badge pending">⏳ ${this.t('status_pending', 'অপেক্ষমাণ')}</span>
                ${window.Auth.isAdmin() ? `
                  <button class="btn-primary" style="padding:4px 8px; font-size:0.75rem; min-height:auto;" onclick="App.confirmPaymentAction('${p.id}')">
                    ${this.t('btn_approve', 'অনুমোদন')}
                  </button>
                ` : ''}
              </div>
            ` : `
              ${window.Auth.isAdmin() ? `
                <button class="btn-primary" style="padding:6px 12px; font-size:0.78rem; min-height:auto;" onclick="App.openRecordPaymentModal('${m.id}', '${m.name}', ${defaultAmount})">
                  ${this.t('btn_collect', 'জমা নিন')}
                </button>
              ` : `
                <span class="status-badge unpaid">${this.t('status_unpaid', 'বকেয়া')}</span>
              `}
            `}
          </div>
        </div>
      `;
    }).join('');
  },

  openRecordPaymentModal(memberId, memberName, amount) {
    if (!window.Auth.isAdmin()) {
      this.showToast(this.t('err_admin_only_payment', "চাঁদা জমা দেওয়ার জন্য অ্যাডমিন লগইন প্রয়োজন"), "error");
      return;
    }
    document.getElementById('pay-modal-member-id').value = memberId;
    document.getElementById('pay-modal-member-name').value = memberName;
    document.getElementById('pay-modal-month').value = this.selectedMonth;
    document.getElementById('pay-modal-amount').value = amount || 100;
    document.getElementById('pay-modal-method').value = 'নগদ';
    document.getElementById('pay-modal-trx').value = '';
    this.openModal('record-payment-modal');
  },

  async confirmPaymentAction(paymentId) {
    if (!window.Auth.isAdmin()) {
      this.showToast(this.t('err_admin_only_approval', "অনুমোদনের অনুমতি কেবল অ্যাডমিনের রয়েছে"), "error");
      return;
    }
    try {
      await DB.confirmPayment(paymentId, window.Auth.getCurrentUser()?.id);
      this.showToast(this.t('msg_payment_confirmed', "পেমেন্ট সফলভাবে অনুমোদিত ও রসিদ তৈরি হয়েছে"), "success");
      this.renderChanda();
      this.renderDashboard();
    } catch (e) {
      this.showToast(e.message, "error");
    }
  },

  // --------------------------------------------------------------------------
  // 4. Monthly Accounts (মাসিক হিসাব)
  // --------------------------------------------------------------------------
  async renderMonthlyAccounts() {
    const monthPicker = document.getElementById('accounts-month-picker');
    if (monthPicker) monthPicker.value = this.selectedMonth;

    const [members, payments, expenses, settings] = await Promise.all([
      DB.getMembers(),
      DB.getPayments(this.selectedMonth),
      DB.getExpenses(this.selectedMonth),
      DB.getSettings()
    ]);

    const defaultAmount = settings?.chanda_config?.default_amount || 100;
    const totalMembers = members.length;
    const expected = totalMembers * defaultAmount;

    const confirmedPayments = payments.filter(p => p.status === 'paid');
    const actualCollection = confirmedPayments.reduce((acc, p) => acc + Number(p.amount), 0);
    const unpaidAmount = Math.max(0, expected - actualCollection);

    const totalExpense = expenses.reduce((acc, e) => acc + Number(e.amount), 0);
    const monthlyBalance = actualCollection - totalExpense;

    const memEl = document.getElementById('acc-stat-members');
    const expEl = document.getElementById('acc-stat-expected');
    const actEl = document.getElementById('acc-stat-actual');
    const unpEl = document.getElementById('acc-stat-unpaid');
    const expnEl = document.getElementById('acc-stat-expense');
    const balEl = document.getElementById('acc-stat-balance');

    if (memEl) memEl.textContent = `${DB.toBnNum(totalMembers)} ${this.t('persons_unit', 'জন')}`;
    if (expEl) expEl.textContent = DB.formatTaka(expected);
    if (actEl) actEl.textContent = DB.formatTaka(actualCollection);
    if (unpEl) unpEl.textContent = DB.formatTaka(unpaidAmount);
    if (expnEl) expnEl.textContent = DB.formatTaka(totalExpense);
    if (balEl) balEl.textContent = DB.formatTaka(monthlyBalance);

    // Detailed table
    const tableBody = document.getElementById('accounts-table-body');
    if (tableBody) {
      const paymentMap = {};
      payments.forEach(p => {
        paymentMap[String(p.member_id)] = p;
      });

      tableBody.innerHTML = members.map(m => {
        const p = paymentMap[String(m.id)] || paymentMap[String(m.member_id)];
        const isPaid = p && p.status === 'paid';
        return `
          <tr>
            <td><strong>${m.member_id}</strong></td>
            <td>${m.name}</td>
            <td>${p ? DB.formatTaka(p.amount) : '০ ৳'}</td>
            <td>
              <span class="status-badge ${isPaid ? 'paid' : 'unpaid'}">
                ${isPaid ? this.t('status_paid', 'পরিশোধিত') : this.t('status_unpaid', 'বকেয়া')}
              </span>
            </td>
            <td>${p ? DB.toBnNum(p.payment_date) : '---'}</td>
          </tr>
        `;
      }).join('');
    }
  },

  // --------------------------------------------------------------------------
  // 5. Expense Management View
  // --------------------------------------------------------------------------
  async renderExpenses() {
    const listContainer = document.getElementById('expenses-list-container');
    if (!listContainer) return;

    const expenses = await DB.getExpenses();
    const totalExpense = expenses.reduce((acc, e) => acc + Number(e.amount), 0);
    const badge = document.getElementById('total-expense-amount-badge');
    if (badge) badge.textContent = DB.formatTaka(totalExpense);

    if (expenses.length === 0) {
      listContainer.innerHTML = `
        <div class="app-card" style="text-align: center; padding: 30px;">
          <p style="color: var(--text-muted);">${this.t('no_expenses_found', 'কোন খরচের রেকর্ড পাওয়া যায়নি।')}</p>
        </div>
      `;
      return;
    }

    listContainer.innerHTML = expenses.map(e => `
      <div class="member-item-card">
        <div class="metric-icon-box icon-expense" style="flex-shrink:0;">
          💸
        </div>
        <div class="member-info">
          <div class="member-name">${e.title}</div>
          <div class="member-meta">
            <span class="id-badge">${e.voucher_no || 'EXP'}</span>
            <span>${this.t('category', 'খাত')}: ${e.category}</span> • 
            <span>${this.t('date', 'তারিখ')}: ${DB.toBnNum(e.expense_date)}</span>
          </div>
          ${e.note ? `<div style="font-size:0.76rem; color:var(--text-muted); margin-top:2px;">${this.t('note', 'নোট')}: ${e.note}</div>` : ''}
        </div>
        <div style="text-align: right;">
          <div style="font-weight: 700; color: var(--status-unpaid); font-size: 1.05rem;">
            - ${DB.formatTaka(e.amount)}
          </div>
          ${window.Auth.isAdmin() ? `
            <div style="display:flex; gap:6px; justify-content:flex-end; margin-top:4px;">
              <button onclick="App.openEditExpenseModal('${e.id}')" style="background:none; border:none; color:#2563eb; font-size:12px; cursor:pointer; font-weight:600;">
                ${this.t('btn_edit', 'এডিট')}
              </button>
              <button onclick="App.deleteExpenseAction('${e.id}')" style="background:none; border:none; color:#ef4444; font-size:12px; cursor:pointer;">
                ${this.t('btn_delete', 'মুছুন')}
              </button>
            </div>
          ` : ''}
        </div>
      </div>
    `).join('');
  },

  async openEditExpenseModal(id) {
    const expenses = await DB.getExpenses();
    const expense = expenses.find(e => e.id === id);
    if (!expense) return;

    document.getElementById('edit-expense-id').value = expense.id;
    document.getElementById('edit-expense-title').value = expense.title;
    document.getElementById('edit-expense-amount').value = expense.amount;
    document.getElementById('edit-expense-category').value = expense.category || 'অন্যান্য';
    document.getElementById('edit-expense-date').value = expense.expense_date || '';
    document.getElementById('edit-expense-note').value = expense.note || '';

    this.openModal('edit-expense-modal');
  },

  async deleteExpenseAction(id) {
    if (!confirm(this.t('confirm_delete_expense', "আপনি কি নিশ্চিতভাবে এই খরচের হিসাবটি মুছে ফেলতে চান?"))) return;
    try {
      await DB.deleteExpense(id);
      this.showToast(this.t('msg_expense_deleted', "খরচের হিসাব মুছে ফেলা হয়েছে"), "success");
      this.renderExpenses();
      this.renderDashboard();
    } catch (e) {
      this.showToast(e.message, "error");
    }
  },

  // --------------------------------------------------------------------------
  // 6. Payment QR Code View
  // --------------------------------------------------------------------------
  async renderPaymentQR() {
    const settings = await DB.getSettings();
    const accounts = settings?.payment_accounts || {};
    
    const bkashRow = document.getElementById('qr-bkash-row');
    const nagadRow = document.getElementById('qr-nagad-row');
    const bkashEl = document.getElementById('qr-bkash-no');
    const nagadEl = document.getElementById('qr-nagad-no');
    const bankEl = document.getElementById('qr-bank-details');

    if (bkashEl) bkashEl.textContent = accounts.bkash || 'প্রযোজ্য নয়';
    if (nagadEl) nagadEl.textContent = accounts.nagad || 'প্রযোজ্য নয়';
    if (bankEl) bankEl.textContent = accounts.bank_details || 'ইসলামী ব্যাংক বাংলাদেশ লিমিটেড';

    if (bkashRow) bkashRow.style.display = accounts.bkash ? 'flex' : 'none';
    if (nagadRow) nagadRow.style.display = accounts.nagad ? 'flex' : 'none';

    const qrImgEl = document.getElementById('madrasa-qr-image');
    if (qrImgEl) {
      if (settings?.qr_image) {
        qrImgEl.src = settings.qr_image;
      } else {
        qrImgEl.src = "https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=AliAzgarSiddiqiaMadrasaPayment";
      }
    }
  },

  // --------------------------------------------------------------------------
  // 7. Yearly Report View with HTML5 Canvas Charts
  // --------------------------------------------------------------------------
  async renderYearlyReport() {
    const yearPicker = document.getElementById('report-year-picker');
    const selectedYear = yearPicker ? yearPicker.value : this.selectedYear;

    const [payments, expenses] = await Promise.all([
      DB.getPayments(),
      DB.getExpenses()
    ]);

    const confirmed = payments.filter(p => p.status === 'paid' && p.month.startsWith(selectedYear));
    const yearlyExpenses = expenses.filter(e => e.expense_date.startsWith(selectedYear));

    const totalCollection = confirmed.reduce((acc, p) => acc + Number(p.amount), 0);
    const totalExpense = yearlyExpenses.reduce((acc, e) => acc + Number(e.amount), 0);
    const yearBalance = totalCollection - totalExpense;

    const collEl = document.getElementById('yearly-stat-collection');
    const expEl = document.getElementById('yearly-stat-expense');
    const balEl = document.getElementById('yearly-stat-balance');

    if (collEl) collEl.textContent = DB.formatTaka(totalCollection);
    if (expEl) expEl.textContent = DB.formatTaka(totalExpense);
    if (balEl) balEl.textContent = DB.formatTaka(yearBalance);

    // Prepare 12 months data
    const isEn = window.I18n && window.I18n.currentLang === 'en';
    const monthLabels = isEn 
      ? ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
      : ['জানু', 'ফেব্রু', 'মার্চ', 'এপ্রিল', 'মে', 'জুন', 'জুলাই', 'আগস্ট', 'সেপ্টে', 'অক্টো', 'নভে', 'ডিসে'];

    const collectionsByMonth = new Array(12).fill(0);
    const expensesByMonth = new Array(12).fill(0);

    confirmed.forEach(p => {
      const mIdx = parseInt(p.month.split('-')[1], 10) - 1;
      if (mIdx >= 0 && mIdx < 12) collectionsByMonth[mIdx] += Number(p.amount);
    });

    yearlyExpenses.forEach(e => {
      const mIdx = parseInt(e.expense_date.split('-')[1], 10) - 1;
      if (mIdx >= 0 && mIdx < 12) expensesByMonth[mIdx] += Number(e.amount);
    });

    // Draw Chart onto HTML5 Canvas
    this.drawYearlyChart('yearly-bar-chart', monthLabels, collectionsByMonth, expensesByMonth);
  },

  drawYearlyChart(canvasId, labels, collections, expenses) {
    const canvas = document.getElementById(canvasId);
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const dpr = window.devicePixelRatio || 1;
    const width = canvas.clientWidth || 340;
    const height = 220;

    canvas.width = width * dpr;
    canvas.height = height * dpr;
    ctx.scale(dpr, dpr);

    ctx.clearRect(0, 0, width, height);

    const maxVal = Math.max(...collections, ...expenses, 1000);
    const paddingBottom = 26;
    const paddingTop = 20;
    const chartHeight = height - paddingBottom - paddingTop;
    const barGroupWidth = width / labels.length;
    const barWidth = Math.max(4, (barGroupWidth - 8) / 2);

    // Draw background grid lines
    ctx.strokeStyle = '#e2e8f0';
    ctx.lineWidth = 1;
    for (let i = 0; i <= 4; i++) {
      const y = paddingTop + (chartHeight / 4) * i;
      ctx.beginPath();
      ctx.moveTo(10, y);
      ctx.lineTo(width - 10, y);
      ctx.stroke();
    }

    // Draw Bars
    labels.forEach((label, i) => {
      const x = i * barGroupWidth + 4;
      const colHeight = (collections[i] / maxVal) * chartHeight;
      const expHeight = (expenses[i] / maxVal) * chartHeight;

      // Collection Bar (Emerald Green)
      ctx.fillStyle = '#059669';
      ctx.beginPath();
      ctx.roundRect(x, height - paddingBottom - colHeight, barWidth, colHeight, [3, 3, 0, 0]);
      ctx.fill();

      // Expense Bar (Rose Red)
      ctx.fillStyle = '#ef4444';
      ctx.beginPath();
      ctx.roundRect(x + barWidth + 2, height - paddingBottom - expHeight, barWidth, expHeight, [3, 3, 0, 0]);
      ctx.fill();

      // X Axis Label
      ctx.fillStyle = '#64748b';
      ctx.font = '10px Hind Siliguri, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(label, x + barWidth, height - 8);
    });
  },

  // --------------------------------------------------------------------------
  // 8. Notices / Announcements View
  // --------------------------------------------------------------------------
  async renderNotices() {
    const listContainer = document.getElementById('notices-list-container');
    if (!listContainer) return;

    const notices = await DB.getNotices();
    if (notices.length === 0) {
      listContainer.innerHTML = `<div class="app-card"><p style="color:var(--text-muted);">${this.t('no_notices', 'কোন নোটিশ নেই।')}</p></div>`;
      return;
    }

    listContainer.innerHTML = notices.map(n => `
      <div class="app-card" style="${n.is_pinned ? 'border-left: 4px solid var(--accent-gold); background: #fffdf5;' : ''}">
        <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom: 6px;">
          <h4 style="font-size:1.02rem; font-weight:700; color:var(--text-main);">
            ${n.is_pinned ? '📌 ' : ''}${n.title}
          </h4>
          <span style="font-size:0.75rem; color:var(--text-muted);">${DB.toBnNum(n.published_date)}</span>
        </div>
        <p style="font-size:0.88rem; color:#334155; line-height:1.5; white-space:pre-wrap;">${n.body}</p>
        ${window.Auth.isAdmin() ? `
          <div style="text-align:right; margin-top:8px;">
            <button onclick="App.deleteNoticeAction('${n.id}')" style="background:none; border:none; color:#ef4444; font-size:12px; cursor:pointer;">
              ${this.t('btn_delete', 'মুছে ফেলুন')}
            </button>
          </div>
        ` : ''}
      </div>
    `).join('');
  },

  async deleteNoticeAction(id) {
    if (!confirm(this.t('confirm_delete_notice', "আপনি কি নিশ্চিত এই ঘোষণাটি মুছে ফেলতে চান?"))) return;
    try {
      await DB.deleteNotice(id);
      this.showToast(this.t('msg_notice_deleted', "ঘোষণা মুছে ফেলা হয়েছে"), "success");
      this.renderNotices();
    } catch (e) {
      this.showToast(e.message, "error");
    }
  },

  // --------------------------------------------------------------------------
  // 9. Madrasa Projects View
  // --------------------------------------------------------------------------
  async renderProjects() {
    const listContainer = document.getElementById('projects-list-container');
    if (!listContainer) return;

    const projects = await DB.getProjects();
    listContainer.innerHTML = projects.map(p => {
      const est = Number(p.estimated_cost) || 1;
      const coll = Number(p.collected_amount) || 0;
      const spent = Number(p.spent_amount) || 0;
      const percent = Math.min(100, Math.round((coll / est) * 100));

      return `
        <div class="app-card">
          <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;">
            <h4 style="font-size:1.05rem; font-weight:700;">${p.name}</h4>
            <span class="status-badge ${p.status === 'সম্পন্ন' ? 'paid' : p.status === 'চলমান' ? 'pending' : 'unpaid'}">
              ${p.status}
            </span>
          </div>
          <p style="font-size:0.84rem; color:var(--text-muted); margin-bottom:12px;">${p.description}</p>
          
          <div style="margin-bottom:6px; font-size:0.82rem; display:flex; justify-content:space-between;">
            <span>${this.t('project_collected', 'সংগৃহীত')}: ${DB.formatTaka(coll)}</span>
            <span>${this.t('project_budget', 'বাজেট')}: ${DB.formatTaka(est)} (${DB.toBnNum(percent)}%)</span>
          </div>
          <div style="height:8px; border-radius:4px; background:#e2e8f0; overflow:hidden; margin-bottom:10px;">
            <div style="width:${percent}%; height:100%; background:linear-gradient(90deg, var(--primary), var(--accent-gold));"></div>
          </div>
          <div style="font-size:0.8rem; color:#64748b;">
            ${this.t('project_spent', 'ব্যয়িত')}: <strong>${DB.formatTaka(spent)}</strong> • ${this.t('project_remaining', 'অবশিষ্ট')}: <strong>${DB.formatTaka(coll - spent)}</strong>
          </div>
        </div>
      `;
    }).join('');
  },

  // --------------------------------------------------------------------------
  // 10. Settings View
  // --------------------------------------------------------------------------
  async renderSettings() {
    const settings = await DB.getSettings();
    const creds = window.SupabaseModule.getSupabaseCredentials();

    const sbUrlEl = document.getElementById('settings-sb-url');
    const sbKeyEl = document.getElementById('settings-sb-key');
    if (sbUrlEl) sbUrlEl.value = creds.url;
    if (sbKeyEl) sbKeyEl.value = creds.key;

    if (settings?.chanda_config) {
      const defAmtEl = document.getElementById('settings-default-amount');
      if (defAmtEl) defAmtEl.value = settings.chanda_config.default_amount || 100;
    }

    const accounts = settings?.payment_accounts || {};
    const accBkashEl = document.getElementById('settings-acc-bkash');
    const accNagadEl = document.getElementById('settings-acc-nagad');
    const accBankEl = document.getElementById('settings-acc-bank');
    const qrImgInput = document.getElementById('settings-qr-image');

    if (accBkashEl) accBkashEl.value = accounts.bkash || '';
    if (accNagadEl) accNagadEl.value = accounts.nagad || '';
    if (accBankEl) accBankEl.value = accounts.bank_details || '';
    if (qrImgInput) qrImgInput.value = settings?.qr_image || '';
  },

  // --------------------------------------------------------------------------
  // Money Receipt (মানি রসিদ) Generator
  // --------------------------------------------------------------------------
  async showMoneyReceiptById(paymentId) {
    const payments = await DB.getPayments();
    const payment = payments.find(p => p.id === paymentId);
    if (!payment) return;

    const members = await DB.getMembers();
    const member = members.find(m => String(m.id) === String(payment.member_id) || String(m.member_id) === String(payment.member_id)) || { name: 'সদস্য', member_id: '---', phone: '' };

    const rNo = document.getElementById('receipt-no-disp');
    const rDate = document.getElementById('receipt-date-disp');
    const rName = document.getElementById('receipt-member-name');
    const rId = document.getElementById('receipt-member-id');
    const rMonth = document.getElementById('receipt-month-disp');
    const rMethod = document.getElementById('receipt-method-disp');
    const rTrx = document.getElementById('receipt-trx-disp');
    const rAmt = document.getElementById('receipt-amount-disp');
    const rBadge = document.getElementById('receipt-status-badge');

    if (rNo) rNo.textContent = payment.receipt_no || `REC-${payment.id}`;
    if (rDate) rDate.textContent = DB.toBnNum(payment.payment_date);
    if (rName) rName.textContent = member.name;
    if (rId) rId.textContent = member.member_id;
    if (rMonth) rMonth.textContent = this.getMonthLabel(payment.month);
    if (rMethod) rMethod.textContent = payment.payment_method;
    if (rTrx) rTrx.textContent = payment.trx_id || this.t('cash_receipt', 'নগদ গ্রহণ');
    if (rAmt) rAmt.textContent = DB.formatTaka(payment.amount);
    if (rBadge) rBadge.textContent = payment.status === 'paid' ? this.t('status_paid_approved', 'পরিশোধিত (অনুমোদিত)') : this.t('status_pending', 'যাচাইাধীন');

    this.openModal('money-receipt-modal');
  },

  // --------------------------------------------------------------------------
  // Modals & Notifications
  // --------------------------------------------------------------------------
  openModal(id) {
    const el = document.getElementById(id);
    if (el) {
      el.classList.add('active');
      this.updateAdminUI();
    }
  },

  closeModal(id) {
    const el = document.getElementById(id);
    if (el) el.classList.remove('active');
  },

  showToast(message, type = 'success') {
    const container = document.getElementById('toast-container');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    const icon = type === 'success' ? '✅' : type === 'error' ? '❌' : '⚠️';
    toast.innerHTML = `<span>${icon}</span><span>${message}</span>`;

    container.appendChild(toast);
    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateY(-10px)';
      setTimeout(() => toast.remove(), 300);
    }, 3200);
  },

  // --------------------------------------------------------------------------
  // PWA Setup
  // --------------------------------------------------------------------------
  setupPWA() {
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('./service-worker.js')
        .then(() => console.log('Service Worker registered successfully'))
        .catch(err => console.warn('Service Worker registration skipped:', err));
    }

    let deferredPrompt;
    window.addEventListener('beforeinstallprompt', (e) => {
      e.preventDefault();
      deferredPrompt = e;
      const installPill = document.getElementById('pwa-install-btn');
      if (installPill) {
        installPill.style.display = 'inline-flex';
        installPill.onclick = () => {
          deferredPrompt.prompt();
          deferredPrompt.userChoice.then(() => {
            installPill.style.display = 'none';
          });
        };
      }
    });
  },

  // --------------------------------------------------------------------------
  // Event Bindings
  // --------------------------------------------------------------------------
  bindEvents() {
    // Bottom Navigation click handlers
    document.querySelectorAll('.nav-item').forEach(btn => {
      btn.addEventListener('click', () => {
        const view = btn.dataset.view;
        if (view) this.navigate(view);
      });
    });

    // Close modals on backdrop click or close button
    document.querySelectorAll('.modal-overlay').forEach(modal => {
      modal.addEventListener('click', (e) => {
        if (e.target === modal) modal.classList.remove('active');
      });
      const closeBtn = modal.querySelector('.modal-close-btn');
      if (closeBtn) {
        closeBtn.addEventListener('click', () => modal.classList.remove('active'));
      }
    });

    // Admin Status Header Pill click
    document.getElementById('admin-status-pill')?.addEventListener('click', () => {
      if (window.Auth.isAdmin()) {
        if (confirm(this.t('confirm_logout', "আপনি কি অ্যাডমিন প্যানেল থেকে লগআউট করতে চান?"))) {
          window.Auth.logout();
          this.updateAdminUI();
          this.showToast(this.t('msg_logout', "লগআউট সম্পন্ন হয়েছে"), "success");
          this.refreshCurrentView();
        }
      } else {
        this.openModal('admin-login-modal');
      }
    });

    // Month Selector in Dashboard/Chanda
    document.getElementById('chanda-month-picker')?.addEventListener('change', (e) => {
      this.selectedMonth = e.target.value;
      this.renderChanda();
      this.renderDashboard();
    });

    document.getElementById('accounts-month-picker')?.addEventListener('change', (e) => {
      this.selectedMonth = e.target.value;
      this.renderMonthlyAccounts();
    });

    document.getElementById('report-year-picker')?.addEventListener('change', (e) => {
      this.selectedYear = e.target.value;
      this.renderYearlyReport();
    });

    // Member search and filter
    document.getElementById('member-search-input')?.addEventListener('input', () => {
      this.renderMembers();
    });

    document.querySelectorAll('.filter-pill').forEach(pill => {
      pill.addEventListener('click', () => {
        document.querySelectorAll('.filter-pill').forEach(p => p.classList.remove('active'));
        pill.classList.add('active');
        this.memberFilter = pill.dataset.filter || 'all';
        this.renderMembers();
      });
    });

    // ------------------------------------------------------------------------
    // Form Submissions:
    // 1. Add Member Form (Bulletproof Local + Supabase sync)
    // ------------------------------------------------------------------------
    document.getElementById('add-member-form')?.addEventListener('submit', async (e) => {
      e.preventDefault();
      const nameInput = document.getElementById('new-member-name');
      const phoneInput = document.getElementById('new-member-phone');
      const addressInput = document.getElementById('new-member-address');
      const photoInput = document.getElementById('new-member-photo-url');

      const name = nameInput ? nameInput.value.trim() : '';
      const phone = phoneInput ? phoneInput.value.trim() : '';
      const address = addressInput ? addressInput.value.trim() : '';
      const photoUrl = photoInput ? photoInput.value.trim() : '';

      if (!name) {
        this.showToast(this.t('err_name_required', "অনুগ্রহ করে সদস্যের নাম লিখুন"), "error");
        return;
      }

      try {
        const added = await DB.addMember({ name, phone, address, photo_url: photoUrl });
        console.log("Member added successfully:", added);
        this.showToast(this.t('msg_member_added', "সদস্য সফলভাবে যুক্ত করা হয়েছে"), "success");
        this.closeModal('add-member-modal');
        e.target.reset();
        await this.renderMembers();
        await this.renderDashboard();
      } catch (err) {
        console.error("Failed to add member:", err);
        this.showToast(err.message || "সদস্য যোগ করতে সমস্যা হয়েছে", "error");
      }
    });

    // 2. Record Payment Form
    document.getElementById('record-payment-form')?.addEventListener('submit', async (e) => {
      e.preventDefault();
      const memberId = document.getElementById('pay-modal-member-id').value;
      const month = document.getElementById('pay-modal-month').value;
      const amount = document.getElementById('pay-modal-amount').value;
      const method = document.getElementById('pay-modal-method').value;
      const trxId = document.getElementById('pay-modal-trx').value;

      try {
        const payment = await DB.recordPayment({
          member_id: memberId,
          month,
          amount,
          payment_method: method,
          trx_id: trxId,
          status: 'paid',
          confirmed_by: window.Auth.getCurrentUser()?.id
        });
        this.showToast(this.t('msg_payment_recorded', "চাঁদা জমা সফলভাবে সম্পন্ন হয়েছে"), "success");
        this.closeModal('record-payment-modal');
        await this.renderChanda();
        await this.renderDashboard();
        this.showMoneyReceiptById(payment.id);
      } catch (err) {
        this.showToast(err.message, "error");
      }
    });

    // 3. Add Expense Form
    document.getElementById('add-expense-form')?.addEventListener('submit', async (e) => {
      e.preventDefault();
      const title = document.getElementById('new-expense-title').value.trim();
      const amount = document.getElementById('new-expense-amount').value;
      const category = document.getElementById('new-expense-category').value;
      const date = document.getElementById('new-expense-date').value;
      const note = document.getElementById('new-expense-note').value.trim();

      if (!title || !amount) {
        this.showToast("অনুগ্রহ করে খরচের বিবরণ ও টাকার পরিমাণ দিন", "error");
        return;
      }

      try {
        await DB.addExpense({ title, amount, category, expense_date: date, note });
        this.showToast(this.t('msg_expense_added', "খরচের হিসাব যুক্ত হয়েছে"), "success");
        this.closeModal('add-expense-modal');
        e.target.reset();
        await this.renderExpenses();
        await this.renderDashboard();
      } catch (err) {
        this.showToast(err.message, "error");
      }
    });

    // 4. Add Notice Form
    document.getElementById('add-notice-form')?.addEventListener('submit', async (e) => {
      e.preventDefault();
      const title = document.getElementById('new-notice-title').value.trim();
      const body = document.getElementById('new-notice-body').value.trim();
      const isPinned = document.getElementById('new-notice-pinned').checked;

      if (!title || !body) {
        this.showToast("অনুগ্রহ করে নোটিশের শিরোনাম ও বিস্তারিত বিবরণ দিন", "error");
        return;
      }

      try {
        await DB.addNotice({ title, body, is_pinned: isPinned });
        this.showToast(this.t('msg_notice_added', "ঘোষণা সফলভাবে প্রকাশিত হয়েছে"), "success");
        this.closeModal('add-notice-modal');
        e.target.reset();
        await this.renderNotices();
      } catch (err) {
        this.showToast(err.message, "error");
      }
    });

    // 5. Admin Login Form
    document.getElementById('admin-login-form')?.addEventListener('submit', async (e) => {
      e.preventDefault();
      const email = document.getElementById('login-email').value.trim();
      const pass = document.getElementById('login-password').value.trim();

      try {
        await window.Auth.login(email, pass);
        this.showToast(this.t('msg_login_success', "অ্যাডমিন লগইন সফল হয়েছে!"), "success");
        this.closeModal('admin-login-modal');
        e.target.reset();
        this.updateAdminUI();
        this.refreshCurrentView();
      } catch (err) {
        this.showToast(err.message, "error");
      }
    });

    // Demo login button helper
    document.getElementById('btn-fill-demo-login')?.addEventListener('click', () => {
      document.getElementById('login-email').value = 'admin@siddiqiamadrasa.edu.bd';
      document.getElementById('login-password').value = 'admin123';
    });

    // 6. Supabase Settings Form
    document.getElementById('supabase-settings-form')?.addEventListener('submit', (e) => {
      e.preventDefault();
      const url = document.getElementById('settings-sb-url').value.trim();
      const key = document.getElementById('settings-sb-key').value.trim();

      try {
        window.SupabaseModule.saveSupabaseCredentials(url, key);
        this.showToast(this.t('msg_supabase_saved', "Supabase সংযোগ সফলভাবে সংরক্ষিত হয়েছে"), "success");
        this.updateAdminUI();
        this.refreshCurrentView();
      } catch (err) {
        this.showToast(err.message, "error");
      }
    });

    // 7. General Settings (Default Chanda amount)
    document.getElementById('general-settings-form')?.addEventListener('submit', async (e) => {
      e.preventDefault();
      const defaultAmount = Number(document.getElementById('settings-default-amount').value) || 100;
      const settings = await DB.getSettings();
      if (!settings.chanda_config) settings.chanda_config = {};
      settings.chanda_config.default_amount = defaultAmount;

      await DB.updateSetting('chanda_config', settings.chanda_config);
      this.showToast(this.t('msg_settings_saved', "মাসিক চাঁদার পরিমাণ আপডেট হয়েছে"), "success");
      this.renderDashboard();
    });

    // Member Detail Actions (Admin only edit/delete)
    document.getElementById('detail-edit-member-btn')?.addEventListener('click', async () => {
      if (!this.activeMemberId) return;
      const member = await DB.getMemberById(this.activeMemberId);
      if (!member) return;

      document.getElementById('edit-member-id').value = member.id;
      document.getElementById('edit-member-name').value = member.name || '';
      document.getElementById('edit-member-phone').value = member.phone || '';
      document.getElementById('edit-member-address').value = member.address || '';
      document.getElementById('edit-member-photo-url').value = member.photo_url || '';

      this.closeModal('member-details-modal');
      this.openModal('edit-member-modal');
    });

    document.getElementById('detail-delete-member-btn')?.addEventListener('click', async () => {
      if (!this.activeMemberId) return;
      if (!confirm(this.t('confirm_delete_member', "আপনি কি নিশ্চিতভাবে এই সদস্যকে মুছে ফেলতে চান?"))) return;

      try {
        await DB.deleteMember(this.activeMemberId);
        this.showToast(this.t('msg_member_deleted', "সদস্য সফলভাবে মুছে ফেলা হয়েছে"), "success");
        this.closeModal('member-details-modal');
        this.activeMemberId = null;
        await this.renderMembers();
        await this.renderDashboard();
      } catch (err) {
        this.showToast(err.message, "error");
      }
    });

    // Edit Member Form Submission
    document.getElementById('edit-member-form')?.addEventListener('submit', async (e) => {
      e.preventDefault();
      const id = document.getElementById('edit-member-id').value;
      const name = document.getElementById('edit-member-name').value.trim();
      const phone = document.getElementById('edit-member-phone').value.trim();
      const address = document.getElementById('edit-member-address').value.trim();
      const photoUrl = document.getElementById('edit-member-photo-url').value.trim();

      try {
        await DB.updateMember(id, { name, phone, address, photo_url: photoUrl });
        this.showToast(this.t('msg_member_updated', "সদস্যের তথ্য সফলভাবে আপডেট হয়েছে"), "success");
        this.closeModal('edit-member-modal');
        await this.renderMembers();
        await this.renderDashboard();
      } catch (err) {
        this.showToast(err.message, "error");
      }
    });

    // Edit Expense Form Submission
    document.getElementById('edit-expense-form')?.addEventListener('submit', async (e) => {
      e.preventDefault();
      const id = document.getElementById('edit-expense-id').value;
      const title = document.getElementById('edit-expense-title').value.trim();
      const amount = Number(document.getElementById('edit-expense-amount').value) || 0;
      const category = document.getElementById('edit-expense-category').value;
      const date = document.getElementById('edit-expense-date').value;
      const note = document.getElementById('edit-expense-note').value.trim();

      try {
        await DB.updateExpense(id, {
          title,
          amount,
          category,
          expense_date: date,
          note
        });
        this.showToast(this.t('msg_expense_updated', "খরচের হিসাব আপডেট হয়েছে"), "success");
        this.closeModal('edit-expense-modal');
        await this.renderExpenses();
        await this.renderDashboard();
      } catch (err) {
        this.showToast(err.message, "error");
      }
    });

    // Payment Settings Form Submission
    document.getElementById('payment-settings-form')?.addEventListener('submit', async (e) => {
      e.preventDefault();
      const bkash = document.getElementById('settings-acc-bkash').value.trim();
      const nagad = document.getElementById('settings-acc-nagad').value.trim();
      const bankDetails = document.getElementById('settings-acc-bank').value.trim();
      const qrImage = document.getElementById('settings-qr-image').value.trim();

      try {
        await DB.updateSetting('payment_accounts', {
          bkash,
          nagad,
          rocket: '',
          bank_details: bankDetails
        });

        if (qrImage) {
          await DB.updateSetting('qr_image', qrImage);
        }

        this.showToast(this.t('msg_payment_settings_saved', "পেমেন্ট ও QR তথ্য সফলভাবে সংরক্ষিত হয়েছে"), "success");
        this.renderPaymentQR();
      } catch (err) {
        this.showToast(err.message, "error");
      }
    });

    // Copy SQL Schema Button (Instant in-memory copy)
    document.getElementById('btn-copy-sql')?.addEventListener('click', () => {
      const sql = DB.getSupabaseSetupSQL();
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(sql)
          .then(() => this.showToast(this.t('msg_sql_copied', "SQL কোড ক্লিপবোর্ডে কপি হয়েছে!"), "success"))
          .catch(() => {
            const ta = document.createElement('textarea');
            ta.value = sql;
            document.body.appendChild(ta);
            ta.select();
            document.execCommand('copy');
            document.body.removeChild(ta);
            this.showToast(this.t('msg_sql_copied', "SQL কোড ক্লিপবোর্ডে কপি হয়েছে!"), "success");
          });
      } else {
        const ta = document.createElement('textarea');
        ta.value = sql;
        document.body.appendChild(ta);
        ta.select();
        document.execCommand('copy');
        document.body.removeChild(ta);
        this.showToast(this.t('msg_sql_copied', "SQL কোড ক্লিপবোর্ডে কপি হয়েছে!"), "success");
      }
    });
  }
};

window.App = App;
