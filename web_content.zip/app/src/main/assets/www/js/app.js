/**
 * RoboSim AI Studio Pro - Master UI Application Orchestrator
 * Connects 3D Engine, Electrical Engine, Cloud Hub, AI Assistant, and Android Native Bridge.
 */

window.RoboApp = (function() {
  // UI State
  let currentLeftTab = "library"; // "library", "cloud", "inspector"
  let currentRightTab = "ai"; // "ai", "electrical", "collisions"
  let leftPanelOpen = true;
  let rightPanelOpen = true;
  let bottomConsoleOpen = true;

  // Logging
  const logs = [];

  function init() {
    console.log("Initializing RoboSim AI Studio Pro...");

    // 1. Initialize 3D Engine
    const container = document.getElementById("canvas-container");
    window.RoboEngine.init(container);

    // 2. Initialize AI Engine
    window.RoboAI.init();

    // 3. Render initial UI components
    renderLocalLibrary();
    renderCloudHub();
    renderElectricalPanel();
    renderAIChat();
    renderCollisionsPanel();

    // 4. Bind DOM events
    bindEvents();

    // 5. Default starting setup (spawn Arduino Uno on empty workspace for immediate interaction)
    window.RoboEngine.addComponent("arduino_uno", { x: 0, y: 0, z: 0 });

    addLog("RoboSim AI Studio Pro iniciado con éxito.");
    addLog("Motor Three.js WebGL acelerado por hardware activo.");
    addLog("Sistema Snap-to-Grid (10mm) y anclaje electromagnético habilitados.");

    // Update initial status
    updateStatusBar();
  }

  function bindEvents() {
    // --- Left Tabs ---
    document.getElementById("btn-tab-library").addEventListener("click", () => setLeftTab("library"));
    document.getElementById("btn-tab-cloud").addEventListener("click", () => setLeftTab("cloud"));
    document.getElementById("btn-tab-inspector").addEventListener("click", () => setLeftTab("inspector"));
    document.getElementById("btn-toggle-left-panel").addEventListener("click", toggleLeftPanel);

    // --- Right Tabs ---
    document.getElementById("btn-tab-ai").addEventListener("click", () => setRightTab("ai"));
    document.getElementById("btn-tab-electrical").addEventListener("click", () => setRightTab("electrical"));
    document.getElementById("btn-tab-collisions").addEventListener("click", () => setRightTab("collisions"));
    document.getElementById("btn-toggle-right-panel").addEventListener("click", toggleRightPanel);

    // --- Bottom Console Toggle ---
    document.getElementById("btn-toggle-console").addEventListener("click", toggleBottomConsole);

    // --- Top Toolbar Controls ---
    // Snap-to-grid select
    const snapSelect = document.getElementById("select-snap-grid");
    if (snapSelect) {
      snapSelect.addEventListener("change", (e) => {
        const val = parseInt(e.target.value, 10);
        window.RoboEngine.setSnapGrid(val);
        addLog(`Snap-to-Grid ajustado a: ${val === 0 ? "Libre (Desactivado)" : val + " mm"}`);
      });
    }

    // Magnetic Snap Toggle
    const toggleMag = document.getElementById("btn-toggle-magnetic");
    if (toggleMag) {
      toggleMag.addEventListener("click", function() {
        this.classList.toggle("active");
        const active = this.classList.contains("active");
        window.RoboEngine.setMagneticSnap(active);
        addLog(`Puntos de anclaje magnéticos: ${active ? "ACTIVADOS" : "DESACTIVADOS"}`);
      });
    }

    // Check Collisions Button
    const btnCheckCollisions = document.getElementById("btn-check-collisions");
    if (btnCheckCollisions) {
      btnCheckCollisions.addEventListener("click", () => {
        setRightTab("collisions");
        const collisions = window.RoboEngine.checkCollisions();
        addLog(`Comprobación mecánica ejecutada: ${collisions.length} interferencias encontradas.`);
      });
    }

    // Electrical Calculator Button
    const btnCalcElec = document.getElementById("btn-calc-electrical");
    if (btnCalcElec) {
      btnCalcElec.addEventListener("click", () => {
        setRightTab("electrical");
        renderElectricalPanel();
      });
    }

    // Export .INO Button
    const btnExportIno = document.getElementById("btn-export-ino");
    if (btnExportIno) {
      btnExportIno.addEventListener("click", () => {
        window.RoboAI.exportInoFile();
        showNotification("Firmware .ino exportado correctamente.");
        addLog("Firmware exportado: RoboSim_Firmware.ino listo para Arduino IDE.");
      });
    }

    // Save Project JSON
    const btnSaveProject = document.getElementById("btn-save-project");
    if (btnSaveProject) {
      btnSaveProject.addEventListener("click", saveProjectJson);
    }

    // Clear Scene
    const btnClearScene = document.getElementById("btn-clear-scene");
    if (btnClearScene) {
      btnClearScene.addEventListener("click", () => {
        if (confirm("¿Deseas vaciar la escena 3D? Se eliminarán todas las piezas colocadas.")) {
          window.RoboEngine.clearAll();
          addLog("Escena limpiada.");
        }
      });
    }

    // Camera preset buttons (HUD)
    document.querySelectorAll("[data-camera-view]").forEach(btn => {
      btn.addEventListener("click", function() {
        const view = this.getAttribute("data-camera-view");
        window.RoboEngine.setCameraView(view);
      });
    });

    // Cloud Store search and category filters
    const searchInput = document.getElementById("cloud-search-input");
    if (searchInput) {
      searchInput.addEventListener("input", (e) => {
        window.RoboCloud.setSearchQuery(e.target.value);
        renderCloudHub();
      });
    }

    document.querySelectorAll(".cloud-category-btn").forEach(btn => {
      btn.addEventListener("click", function() {
        document.querySelectorAll(".cloud-category-btn").forEach(b => b.classList.remove("bg-cyan-600", "text-white"));
        this.classList.add("bg-cyan-600", "text-white");
        window.RoboCloud.setFilter(this.getAttribute("data-category"));
        renderCloudHub();
      });
    });

    // Local file input
    const fileInput = document.getElementById("input-import-file");
    if (fileInput) {
      fileInput.addEventListener("change", (e) => {
        const file = e.target.files[0];
        if (file) {
          window.RoboCloud.importLocalFile(file, (success, msg) => {
            showNotification(msg);
            addLog(msg);
            e.target.value = "";
          });
        }
      });
    }

    // AI Chat Input
    const chatInput = document.getElementById("ai-chat-input");
    const chatSendBtn = document.getElementById("ai-chat-send");
    if (chatSendBtn && chatInput) {
      const sendAction = () => {
        const text = chatInput.value.trim();
        if (!text) return;
        chatInput.value = "";
        renderAIChat();

        window.RoboAI.processUserMessage(text, () => {
          renderAIChat();
          renderInoCodeViewer();
          onSceneUpdated();
        });
        renderAIChat();
      };

      chatSendBtn.addEventListener("click", sendAction);
      chatInput.addEventListener("keydown", (e) => {
        if (e.key === "Enter" && !e.shiftKey) {
          e.preventDefault();
          sendAction();
        }
      });
    }

    // AI Prototype quick buttons
    document.querySelectorAll("[data-ai-preset]").forEach(btn => {
      btn.addEventListener("click", function() {
        const prompt = this.getAttribute("data-ai-preset");
        setRightTab("ai");
        window.RoboAI.processUserMessage(prompt, () => {
          renderAIChat();
          renderInoCodeViewer();
          onSceneUpdated();
        });
        renderAIChat();
      });
    });

    // Copy Code Button
    const btnCopyCode = document.getElementById("btn-copy-code");
    if (btnCopyCode) {
      btnCopyCode.addEventListener("click", () => {
        const code = window.RoboAI.getCurrentCode() || window.RoboAI.generateInoCode();
        navigator.clipboard.writeText(code).then(() => {
          showNotification("Código copiado al portapapeles.");
        });
      });
    }
  }

  // --- Rendering Local Components Library ---
  function renderLocalLibrary() {
    const listContainer = document.getElementById("local-components-list");
    if (!listContainer) return;

    listContainer.innerHTML = "";
    const all = window.COMPONENTS_DB;

    for (let key in all) {
      const item = all[key];
      if (item.cloudOnly) continue; // Only local components

      const card = document.createElement("div");
      card.className = "p-3 bg-slate-800/80 hover:bg-slate-700/80 border border-slate-700/50 rounded-lg transition-all flex flex-col gap-2 group cursor-pointer";

      card.innerHTML = `
        <div class="flex items-start justify-between">
          <div>
            <h4 class="text-sm font-semibold text-slate-100 group-hover:text-cyan-400 transition-colors">${item.name}</h4>
            <span class="text-[11px] text-cyan-400/80 font-mono">${item.category}</span>
          </div>
          <button class="add-comp-btn px-2.5 py-1 text-xs bg-cyan-600 hover:bg-cyan-500 text-white rounded font-medium flex items-center gap-1 shadow-sm">
            <span>+</span> Añadir
          </button>
        </div>
        <p class="text-xs text-slate-400 line-clamp-2">${item.description}</p>
        <div class="flex items-center gap-2 pt-1 border-t border-slate-700/40 text-[11px] text-slate-300 font-mono">
          <span>⚡ ${item.specs.voltage ? item.specs.voltage + "V" : "Mecánico"}</span>
          <span>•</span>
          <span>I_idle: ${item.specs.idleCurrent || 0}mA</span>
          <span>•</span>
          <span>I_peak: ${item.specs.peakCurrent || 0}mA</span>
        </div>
      `;

      card.querySelector(".add-comp-btn").addEventListener("click", (e) => {
        e.stopPropagation();
        window.RoboEngine.addComponent(item.id);
        showNotification(`Añadido: ${item.name}`);
        addLog(`Componente añadido a la escena: ${item.name}`);
      });

      card.addEventListener("click", () => {
        window.RoboEngine.addComponent(item.id);
        showNotification(`Añadido: ${item.name}`);
        addLog(`Componente añadido a la escena: ${item.name}`);
      });

      listContainer.appendChild(card);
    }
  }

  // --- Rendering Cloud Hub Catalog ---
  function renderCloudHub() {
    const listContainer = document.getElementById("cloud-components-list");
    if (!listContainer) return;

    listContainer.innerHTML = "";
    const items = window.RoboCloud.filterItems();

    if (items.length === 0) {
      listContainer.innerHTML = `
        <div class="p-6 text-center text-slate-400">
          <p class="text-sm">No se encontraron componentes en la nube con ese criterio.</p>
        </div>
      `;
      return;
    }

    items.forEach(item => {
      const card = document.createElement("div");
      card.className = "p-3 bg-slate-800/80 border border-slate-700/60 rounded-lg flex flex-col gap-2 relative overflow-hidden";

      const isDownloaded = window.RoboCloud.isDownloaded(item.id);

      card.innerHTML = `
        <div class="flex items-start justify-between">
          <div>
            <div class="flex items-center gap-1.5">
              <span class="inline-block w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              <h4 class="text-sm font-semibold text-slate-100">${item.name}</h4>
            </div>
            <div class="flex items-center gap-2 text-[11px] text-slate-400 font-mono mt-0.5">
              <span class="text-sky-400">${item.category}</span>
              <span>•</span>
              <span>${item.cloudVersion || "v1.0"}</span>
              <span>•</span>
              <span>⭐ ${item.rating || "4.9"}</span>
            </div>
          </div>
          <button class="download-cloud-btn px-2.5 py-1 text-xs ${isDownloaded ? 'bg-slate-700 text-slate-300' : 'bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white'} rounded font-medium shadow flex items-center gap-1 transition-all">
            ${isDownloaded ? "✓ Insertar" : "☁️ Descargar"}
          </button>
        </div>
        <p class="text-xs text-slate-400">${item.description}</p>
        <div class="flex items-center justify-between text-[11px] text-slate-400 font-mono pt-1 border-t border-slate-700/40">
          <span>📦 ${item.fileSize || "180 KB"}</span>
          <span>Descargas: ${item.downloads || "12k"}</span>
        </div>
        <div class="progress-bar-container hidden w-full bg-slate-900 rounded-full h-1.5 mt-1 overflow-hidden">
          <div class="progress-bar-fill bg-cyan-400 h-full w-0 transition-all duration-300"></div>
        </div>
      `;

      const btn = card.querySelector(".download-cloud-btn");
      const progContainer = card.querySelector(".progress-bar-container");
      const progFill = card.querySelector(".progress-bar-fill");

      btn.addEventListener("click", () => {
        if (isDownloaded) {
          window.RoboEngine.addComponent(item.id);
          showNotification(`Insertado: ${item.name}`);
          return;
        }

        btn.disabled = true;
        btn.innerHTML = `<span class="animate-spin inline-block">⏳</span> Descargando...`;
        progContainer.classList.remove("hidden");

        window.RoboCloud.downloadAndInstall(
          item.id,
          (statusText, percent) => {
            progFill.style.width = percent + "%";
            btn.innerText = percent + "%";
          },
          (spawned) => {
            btn.disabled = false;
            btn.className = "download-cloud-btn px-2.5 py-1 text-xs bg-slate-700 text-slate-300 rounded font-medium shadow flex items-center gap-1";
            btn.innerText = "✓ Insertar";
            progContainer.classList.add("hidden");
            addLog(`Componente Cloud ${item.name} descargado e integrado en la escena 3D.`);
          }
        );
      });

      listContainer.appendChild(card);
    });
  }

  // --- Rendering Electrical Calculator ---
  function renderElectricalPanel() {
    const data = window.RoboElectrical.calculate();

    // Source Selector
    const powerSelect = document.getElementById("select-power-source");
    if (powerSelect && powerSelect.children.length === 0) {
      const sources = window.RoboElectrical.getAvailablePowerSources();
      for (let key in sources) {
        const opt = document.createElement("option");
        opt.value = key;
        opt.innerText = sources[key].name;
        powerSelect.appendChild(opt);
      }
      powerSelect.addEventListener("change", (e) => {
        window.RoboElectrical.setPowerSource(e.target.value);
        renderElectricalPanel();
        addLog(`Fuente de alimentación cambiada a: ${sources[e.target.value].name}`);
      });
    }

    // Gauges / Numbers
    document.getElementById("elec-current-idle").innerText = data.totalIdleMa + " mA";
    document.getElementById("elec-current-avg").innerText = data.totalAvgMa + " mA";
    document.getElementById("elec-current-peak").innerText = data.totalPeakMa + " mA";
    document.getElementById("elec-power-watts").innerText = data.powerWattsAvg + " W";
    document.getElementById("elec-battery-runtime").innerText = data.runtimeHoursAvg;

    // Progress bar of peak vs max power source capacity
    const maxCapacity = data.powerSource.maxDischargeMa || 5000;
    const loadPercent = Math.min(100, Math.round((data.totalPeakMa / maxCapacity) * 100));
    const loadBar = document.getElementById("elec-load-bar");
    if (loadBar) {
      loadBar.style.width = loadPercent + "%";
      if (loadPercent > 90) {
        loadBar.className = "h-full bg-red-500 transition-all";
      } else if (loadPercent > 60) {
        loadBar.className = "h-full bg-amber-500 transition-all";
      } else {
        loadBar.className = "h-full bg-emerald-500 transition-all";
      }
    }
    document.getElementById("elec-load-percent").innerText = loadPercent + "%";

    // Warnings list
    const warningsContainer = document.getElementById("elec-warnings-container");
    if (warningsContainer) {
      warningsContainer.innerHTML = "";
      data.warnings.forEach(w => {
        const card = document.createElement("div");
        const colorClasses = {
          danger: "bg-red-950/60 border-red-800 text-red-200",
          warning: "bg-amber-950/60 border-amber-800 text-amber-200",
          info: "bg-blue-950/60 border-blue-800 text-blue-200",
          success: "bg-emerald-950/60 border-emerald-800 text-emerald-200"
        }[w.level] || "bg-slate-800 border-slate-700 text-slate-200";

        card.className = `p-3 rounded-lg border text-xs flex flex-col gap-1 ${colorClasses}`;
        card.innerHTML = `
          <strong class="font-semibold">${w.title}</strong>
          <p class="leading-relaxed opacity-90">${w.message}</p>
        `;
        warningsContainer.appendChild(card);
      });
    }
  }

  // --- Rendering Mechanical Collisions ---
  function renderCollisionsPanel() {
    const collisions = window.RoboEngine.getActiveCollisions();
    const countBadge = document.getElementById("collision-badge-count");
    if (countBadge) {
      countBadge.innerText = collisions.length;
      if (collisions.length > 0) {
        countBadge.classList.remove("hidden");
      } else {
        countBadge.classList.add("hidden");
      }
    }

    const list = document.getElementById("collisions-list");
    if (!list) return;

    list.innerHTML = "";

    if (collisions.length === 0) {
      list.innerHTML = `
        <div class="p-6 text-center text-slate-400">
          <div class="w-12 h-12 rounded-full bg-emerald-900/30 border border-emerald-500/30 flex items-center justify-center mx-auto mb-2 text-emerald-400 text-xl">✓</div>
          <h4 class="text-sm font-semibold text-slate-200">Sin Interferencias Mecánicas</h4>
          <p class="text-xs text-slate-400 mt-1">Todas las piezas en la escena tienen holgura y espacio físico libre.</p>
        </div>
      `;
      return;
    }

    collisions.forEach((c, idx) => {
      const card = document.createElement("div");
      card.className = "p-3 bg-red-950/40 border border-red-500/50 rounded-lg flex flex-col gap-1.5 text-xs text-slate-200";
      card.innerHTML = `
        <div class="flex items-center justify-between text-red-400 font-semibold">
          <span>⚠️ Conflicto #${idx + 1}</span>
          <span>Volumen: ${c.interferenceVolMm3} mm³</span>
        </div>
        <div class="text-slate-300">
          <strong>Pieza A:</strong> ${c.objA.name}<br>
          <strong>Pieza B:</strong> ${c.objB.name}
        </div>
        <div class="p-2 bg-slate-900/80 rounded border border-slate-700/60 text-[11px] text-amber-300">
          💡 <strong>Acción Recomendada:</strong> Desplazar '${c.objA.name}' o rotar para despejar el montaje físico.
        </div>
      `;
      list.appendChild(card);
    });
  }

  // --- Rendering AI Chat & Code Viewer ---
  function renderAIChat() {
    const container = document.getElementById("ai-chat-messages");
    if (!container) return;

    container.innerHTML = "";
    const history = window.RoboAI.getChatHistory();

    history.forEach(msg => {
      const div = document.createElement("div");
      div.className = `flex flex-col gap-1 max-w-[90%] text-xs ${msg.sender === 'user' ? 'ml-auto items-end' : 'mr-auto items-start'}`;

      const bubble = document.createElement("div");
      bubble.className = msg.sender === 'user'
        ? "p-2.5 rounded-xl bg-cyan-600 text-white rounded-br-none shadow"
        : "p-2.5 rounded-xl bg-slate-800 text-slate-200 rounded-bl-none border border-slate-700 shadow";

      // Convert simple markdown bullets and bold
      let formattedText = msg.text
        .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
        .replace(/\*(.*?)\*/g, '<em>$1</em>')
        .replace(/\n/g, '<br>');

      bubble.innerHTML = formattedText;

      const time = document.createElement("span");
      time.className = "text-[10px] text-slate-500";
      time.innerText = msg.timestamp || "";

      div.appendChild(bubble);
      div.appendChild(time);
      container.appendChild(div);
    });

    container.scrollTop = container.scrollHeight;
  }

  function renderInoCodeViewer() {
    const codeElem = document.getElementById("ino-code-content");
    if (codeElem) {
      codeElem.innerText = window.RoboAI.getCurrentCode() || window.RoboAI.generateInoCode();
    }
  }

  // --- Inspector of Selected Object ---
  function onObjectSelected(item) {
    const noSelection = document.getElementById("inspector-no-selection");
    const details = document.getElementById("inspector-details");

    if (!item) {
      if (noSelection) noSelection.classList.remove("hidden");
      if (details) details.classList.add("hidden");
      return;
    }

    if (noSelection) noSelection.classList.add("hidden");
    if (details) details.classList.remove("hidden");

    // Populate fields
    document.getElementById("insp-name").innerText = item.name;
    document.getElementById("insp-category").innerText = item.dbData.category;
    document.getElementById("insp-id").innerText = item.id;
    document.getElementById("insp-voltage").innerText = item.dbData.specs.voltage ? item.dbData.specs.voltage + " V" : "N/A";
    document.getElementById("insp-current").innerText = `${item.dbData.specs.idleCurrent || 0} / ${item.dbData.specs.peakCurrent || 0} mA`;

    // Coordinates
    updateInspectorCoords(item);

    // Delete button
    const deleteBtn = document.getElementById("btn-delete-selected");
    deleteBtn.onclick = () => {
      window.RoboEngine.removeObject(item.id);
      showNotification(`Eliminado: ${item.name}`);
      addLog(`Eliminado de la escena: ${item.name}`);
    };

    // Rotation buttons
    document.getElementById("btn-rot-y-plus").onclick = () => window.RoboEngine.rotateSelected("y", 45);
    document.getElementById("btn-rot-y-minus").onclick = () => window.RoboEngine.rotateSelected("y", -45);
    document.getElementById("btn-rot-x").onclick = () => window.RoboEngine.rotateSelected("x", 45);
    document.getElementById("btn-rot-z").onclick = () => window.RoboEngine.rotateSelected("z", 45);

    // Position buttons
    document.getElementById("btn-pos-x-plus").onclick = () => window.RoboEngine.moveSelected("x", 1);
    document.getElementById("btn-pos-x-minus").onclick = () => window.RoboEngine.moveSelected("x", -1);
    document.getElementById("btn-pos-z-plus").onclick = () => window.RoboEngine.moveSelected("z", 1);
    document.getElementById("btn-pos-z-minus").onclick = () => window.RoboEngine.moveSelected("z", -1);
    document.getElementById("btn-pos-y-plus").onclick = () => window.RoboEngine.moveSelected("y", 1);
    document.getElementById("btn-pos-y-minus").onclick = () => window.RoboEngine.moveSelected("y", -1);
  }

  function onObjectTransformed(item) {
    if (item) {
      updateInspectorCoords(item);
    }
  }

  function updateInspectorCoords(item) {
    if (!item) return;
    document.getElementById("insp-pos-x").innerText = (item.mesh.position.x * 10).toFixed(1) + " mm";
    document.getElementById("insp-pos-y").innerText = (item.mesh.position.y * 10).toFixed(1) + " mm";
    document.getElementById("insp-pos-z").innerText = (item.mesh.position.z * 10).toFixed(1) + " mm";
    document.getElementById("insp-rot-y").innerText = Math.round(THREE.MathUtils.radToDeg(item.mesh.rotation.y)) + "°";
  }

  // --- Scene Events ---
  function onSceneUpdated() {
    renderElectricalPanel();
    renderCollisionsPanel();
    renderInoCodeViewer();
    updateStatusBar();
  }

  function onCollisionStateChanged(collisions) {
    renderCollisionsPanel();
    updateStatusBar();
  }

  function updateStatusBar() {
    const placed = window.RoboEngine.getPlacedObjects();
    const collisions = window.RoboEngine.getActiveCollisions();

    const compCount = document.getElementById("status-component-count");
    if (compCount) compCount.innerText = placed.length + " piezas";

    const colStatus = document.getElementById("status-collision-summary");
    if (colStatus) {
      if (collisions.length > 0) {
        colStatus.innerHTML = `<span class="text-red-400 font-semibold">⚠️ ${collisions.length} Colisiones activas</span>`;
      } else {
        colStatus.innerHTML = `<span class="text-emerald-400">✓ Mecánica OK</span>`;
      }
    }
  }

  // --- Tab Management ---
  function setLeftTab(tab) {
    currentLeftTab = tab;
    document.querySelectorAll(".left-tab-btn").forEach(b => b.classList.remove("text-cyan-400", "border-cyan-400"));
    document.querySelectorAll(".left-tab-content").forEach(c => c.classList.add("hidden"));

    document.getElementById(`btn-tab-${tab}`).classList.add("text-cyan-400", "border-cyan-400");
    document.getElementById(`left-content-${tab}`).classList.remove("hidden");

    if (!leftPanelOpen) toggleLeftPanel();
  }

  function setRightTab(tab) {
    currentRightTab = tab;
    document.querySelectorAll(".right-tab-btn").forEach(b => b.classList.remove("text-cyan-400", "border-cyan-400"));
    document.querySelectorAll(".right-tab-content").forEach(c => c.classList.add("hidden"));

    document.getElementById(`btn-tab-${tab}`).classList.add("text-cyan-400", "border-cyan-400");
    document.getElementById(`right-content-${tab}`).classList.remove("hidden");

    if (!rightPanelOpen) toggleRightPanel();

    if (tab === "electrical") renderElectricalPanel();
    if (tab === "collisions") renderCollisionsPanel();
    if (tab === "ai") renderInoCodeViewer();
  }

  function toggleLeftPanel() {
    const panel = document.getElementById("left-panel");
    leftPanelOpen = !leftPanelOpen;
    panel.classList.toggle("cad-panel-collapsed", !leftPanelOpen);
  }

  function toggleRightPanel() {
    const panel = document.getElementById("right-panel");
    rightPanelOpen = !rightPanelOpen;
    panel.classList.toggle("cad-panel-right-collapsed", !rightPanelOpen);
  }

  function toggleBottomConsole() {
    const consoleBody = document.getElementById("bottom-console-body");
    bottomConsoleOpen = !bottomConsoleOpen;
    consoleBody.classList.toggle("hidden", !bottomConsoleOpen);
  }

  // --- Helpers ---
  function addLog(text) {
    const time = new Date().toLocaleTimeString();
    logs.push(`[${time}] ${text}`);
    const consoleText = document.getElementById("console-logs");
    if (consoleText) {
      consoleText.innerHTML += `<div><span class="text-slate-500">[${time}]</span> ${text}</div>`;
      consoleText.scrollTop = consoleText.scrollHeight;
    }
  }

  function showNotification(text) {
    const toast = document.getElementById("app-toast");
    if (!toast) return;
    toast.innerText = text;
    toast.classList.remove("opacity-0", "pointer-events-none");
    setTimeout(() => {
      toast.classList.add("opacity-0", "pointer-events-none");
    }, 2500);

    // Call Android native toast if bridge exists
    if (window.AndroidBridge && window.AndroidBridge.showToast) {
      window.AndroidBridge.showToast(text);
    }
  }

  function saveProjectJson() {
    const placed = window.RoboEngine.getPlacedObjects();
    const project = {
      name: "RoboSim_Proyecto_" + new Date().toISOString().slice(0, 10),
      version: "1.0",
      created: new Date().toISOString(),
      components: placed.map(o => ({
        id: o.id,
        dbId: o.dbId,
        name: o.name,
        position: { x: o.mesh.position.x, y: o.mesh.position.y, z: o.mesh.position.z },
        rotation: { x: o.mesh.rotation.x, y: o.mesh.rotation.y, z: o.mesh.rotation.z }
      }))
    };

    const jsonStr = JSON.stringify(project, null, 2);

    if (window.AndroidBridge && window.AndroidBridge.shareProjectJson) {
      window.AndroidBridge.shareProjectJson(project.name + ".json", jsonStr);
      return;
    }

    const blob = new Blob([jsonStr], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = project.name + ".json";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    showNotification("Proyecto guardado en archivo JSON.");
    addLog(`Proyecto guardado con ${placed.length} componentes.`);
  }

  return {
    init,
    onObjectSelected,
    onObjectTransformed,
    onSceneUpdated,
    onCollisionStateChanged,
    showNotification,
    addLog
  };
})();

// Start application when DOM is ready
window.addEventListener("DOMContentLoaded", () => {
  window.RoboApp.init();
});
