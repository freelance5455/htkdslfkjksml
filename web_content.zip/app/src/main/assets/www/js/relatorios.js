(function () {
    "use strict";

    const modulo = document.getElementById("conteudoModulo");

    const nomesDocumentos = {
        entradas: "Registo completo de entradas",
        historico: "Histórico de pagamentos e anulações",
        folhaIndividual: "Folha salarial individual",
        folhaColetiva: "Folha salarial colectiva",
        pagamentosSalariais: "Relação de pagamentos salariais",
        despesas: "Relatório de despesas",
        financeiro: "Relatório financeiro geral",
        graficos: "Gráficos financeiros"
    };

    let dados = {
        receitas: [],
        pagamentos: [],
        despesas: [],
        salarios: [],
        funcionarios: [],
        configuracao: {}
    };

    let documentoActual = "entradas";

    // --------------------------------------------------
    // FUNÇÕES GERAIS
    // --------------------------------------------------

    function escapar(valor) {
        return String(valor ?? "").replace(/[&<>"']/g, function (caractere) {
            return {
                "&": "&amp;",
                "<": "&lt;",
                ">": "&gt;",
                '"': "&quot;",
                "'": "&#039;"
            }[caractere];
        });
    }

    function numero(valor) {
        const n = Number(valor);
        return Number.isFinite(n) ? n : 0;
    }

    function moeda(valor) {
        return numero(valor).toLocaleString("pt-AO", {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        }) + " Kz";
    }

    function dataISO(valor) {
        if (!valor) return "";
        return String(valor).slice(0, 10);
    }

    function dataFormatada(valor) {
        const data = dataISO(valor);
        if (!data) return "—";

        const partes = data.split("-");

        if (partes.length !== 3) {
            return escapar(data);
        }

        return partes[2] + "/" + partes[1] + "/" + partes[0];
    }

    function dentroPeriodo(data, inicio, fim) {
        const valor = dataISO(data);

        if (!valor) return false;
        if (inicio && valor < inicio) return false;
        if (fim && valor > fim) return false;

        return true;
    }

    function somar(lista, funcao) {
        return lista.reduce(
            (total, item) => total + numero(funcao(item)),
            0
        );
    }

    // Data limite para calcular pendências
    function obterDataLimite(filtro) {
        return filtro.fim || new Date().toISOString().slice(0, 10);
    }

    function dataAteLimite(data, limite) {
        const valor = dataISO(data);

        return !!valor && valor <= limite;
    }

    // --------------------------------------------------
    // RECEITAS E PAGAMENTOS
    // --------------------------------------------------

    function obterPagamentosReceita(receitaId) {
        return dados.pagamentos.filter(p =>
            String(p.receitaId) === String(receitaId)
        );
    }

    function pagamentosConfirmadosReceita(receitaId) {
        return obterPagamentosReceita(receitaId).filter(p =>
            p.estado !== "anulado"
        );
    }

    function totalRecebido(receitaId) {
        return somar(
            pagamentosConfirmadosReceita(receitaId),
            p => p.valor
        );
    }

    function totalRecebidoAte(receitaId, limite) {
        return somar(
            pagamentosConfirmadosReceita(receitaId).filter(p =>
                dataAteLimite(p.data, limite)
            ),
            p => p.valor
        );
    }

    function totalRecebidoReceitaNoPeriodo(receitaId, filtro) {
        return somar(
            pagamentosConfirmadosReceita(receitaId).filter(p =>
                dentroPeriodo(p.data, filtro.inicio, filtro.fim)
            ),
            p => p.valor
        );
    }

    function saldoReceitaAte(receita, limite) {
        const recebido = totalRecebidoAte(receita.id, limite);

        return Math.max(
            0,
            numero(receita.valor) - recebido
        );
    }

    // --------------------------------------------------
    // SALÁRIOS
    // --------------------------------------------------

    function pagamentosSalariais(salario) {
        return Array.isArray(salario.pagamentos)
            ? salario.pagamentos
            : [];
    }

    function totalPagoSalario(salario) {
        return somar(
            pagamentosSalariais(salario).filter(p =>
                p.estado !== "anulado"
            ),
            p => p.valor
        );
    }

    function totalPagoSalarioAte(salario, limite) {
        return somar(
            pagamentosSalariais(salario).filter(p =>
                p.estado !== "anulado" &&
                dataAteLimite(p.data, limite)
            ),
            p => p.valor
        );
    }

    function saldoSalario(salario) {
        return Math.max(
            0,
            numero(salario.salarioLiquido) - totalPagoSalario(salario)
        );
    }

    function saldoSalarioAte(salario, limite) {
        return Math.max(
            0,
            numero(salario.salarioLiquido) -
            totalPagoSalarioAte(salario, limite)
        );
    }

    function estadoSalario(salario) {
        const liquido = numero(salario.salarioLiquido);
        const pago = totalPagoSalario(salario);

        if (pago >= liquido && liquido > 0) return "Pago";
        if (pago > 0) return "Parcial";

        return "Pendente";
    }

    function dataFolhaSalario(salario) {
        return String(salario.ano) + "-" +
            String(salario.mes).padStart(2, "0") + "-01";
    }

    // --------------------------------------------------
    // DESPESAS
    // --------------------------------------------------

    function pagamentosDespesa(despesa) {
        const pagamentos = Array.isArray(despesa.pagamentos)
            ? despesa.pagamentos
            : [];

        if (pagamentos.length) {
            return pagamentos.filter(p =>
                p.estado !== "anulado"
            );
        }

        if (numero(despesa.valorPago) > 0) {
            return [{
                valor: numero(despesa.valorPago),
                data: despesa.dataPagamento || despesa.data,
                estado: "confirmado",
                metodo: despesa.metodo || ""
            }];
        }

        return [];
    }

    function totalPagoDespesa(despesa) {
        return somar(
            pagamentosDespesa(despesa),
            p => p.valor
        );
    }

    function totalPagoDespesaAte(despesa, limite) {
        return somar(
            pagamentosDespesa(despesa).filter(p =>
                dataAteLimite(p.data, limite)
            ),
            p => p.valor
        );
    }

    function saldoDespesaAte(despesa, limite) {
        return Math.max(
            0,
            numero(despesa.valor) - totalPagoDespesaAte(despesa, limite)
        );
    }

    // --------------------------------------------------
    // CARREGAMENTO DOS DADOS
    // --------------------------------------------------

    async function carregarDados() {
        const db = window.SGFE_DB;

        if (!db) {
            throw new Error("O armazenamento do SGFE não está disponível.");
        }

        const resultados = await Promise.all([
            db.listar("receitas"),
            db.listar("pagamentos"),
            db.listar("despesas"),
            db.listar("salarios"),
            db.listar("funcionarios")
        ]);

        dados.receitas = resultados[0] || [];
        dados.pagamentos = resultados[1] || [];
        dados.despesas = resultados[2] || [];
        dados.salarios = resultados[3] || [];
        dados.funcionarios = resultados[4] || [];

        if (window.SGFE_CONFIGURACOES) {
            try {
                dados.configuracao =
                    await window.SGFE_CONFIGURACOES.carregar() || {};
            } catch (erro) {
                console.warn(
                    "Não foi possível carregar as configurações.",
                    erro
                );

                dados.configuracao = {};
            }
        }
    }

    // --------------------------------------------------
    // FILTROS
    // --------------------------------------------------

    function obterFiltro() {
        const inicio = document.getElementById("relatorioDataInicio");
        const fim = document.getElementById("relatorioDataFim");
        const mes = document.getElementById("relatorioMes");
        const ano = document.getElementById("relatorioAno");
        const funcionario = document.getElementById("relatorioFuncionario");

        return {
            inicio: inicio ? inicio.value : "",
            fim: fim ? fim.value : "",
            mes: mes ? Number(mes.value) : new Date().getMonth() + 1,
            ano: ano ? Number(ano.value) : new Date().getFullYear(),
            funcionarioId: funcionario ? funcionario.value : ""
        };
    }

    function filtrarPorPeriodo(lista, campo, filtro) {
        return lista.filter(item =>
            dentroPeriodo(item[campo], filtro.inicio, filtro.fim)
        );
    }

    // --------------------------------------------------
    // ELEMENTOS HTML DOS RELATÓRIOS
    // --------------------------------------------------

    function tabela(cabecalhos, linhas, classe = "") {
        let html = '<div class="sgfe-tabela-relatorio"><table class="' +
            escapar(classe) + '"><thead><tr>';

        cabecalhos.forEach(cabecalho => {
            html += "<th>" + escapar(cabecalho) + "</th>";
        });

        html += "</tr></thead><tbody>";

        if (!linhas.length) {
            html += '<tr><td colspan="' + cabecalhos.length +
                '" style="text-align:center">Não existem registos para apresentar.</td></tr>';
        } else {
            linhas.forEach(linha => {
                html += "<tr>";

                linha.forEach(celula => {
                    html += "<td>" + (celula ?? "—") + "</td>";
                });

                html += "</tr>";
            });
        }

        html += "</tbody></table></div>";

        return html;
    }

    function resumoLinha(rotulo, valor) {
        return '<div class="sgfe-resumo-linha"><span>' +
            escapar(rotulo) + '</span><strong>' +
            escapar(valor) + '</strong></div>';
    }

    function cabecalhoRelatorio(titulo, periodo) {
        return '<div class="sgfe-relatorio-cabecalho">' +
            '<h2>' + escapar(titulo) + '</h2>' +
            '<p>Período: ' + escapar(periodo || "Todos os períodos") + '</p>' +
            '<p>Data de emissão: ' +
            dataFormatada(new Date().toISOString()) +
            '</p>' +
            '</div>';
    }

    function periodoTexto(filtro) {
        if (filtro.inicio && filtro.fim) {
            return dataFormatada(filtro.inicio) +
                " a " + dataFormatada(filtro.fim);
        }

        if (filtro.inicio) {
            return "A partir de " + dataFormatada(filtro.inicio);
        }

        if (filtro.fim) {
            return "Até " + dataFormatada(filtro.fim);
        }

        return "Todos os períodos";
    }

    // --------------------------------------------------
    // FUNÇÕES DE ORGANIZAÇÃO MENSAL
    // --------------------------------------------------

    function obterMesChave(data) {
        const valor = dataISO(data);

        return /^\d{4}-\d{2}/.test(valor)
            ? valor.slice(0, 7)
            : "";
    }

    function formatarMes(mesChave) {
        const partes = mesChave.split("-");

        const nomes = [
            "Janeiro", "Fevereiro", "Março", "Abril",
            "Maio", "Junho", "Julho", "Agosto",
            "Setembro", "Outubro", "Novembro", "Dezembro"
        ];

        return nomes[Number(partes[1]) - 1] + " " + partes[0];
    }

    // --------------------------------------------------
    // REGISTO COMPLETO DE ENTRADAS
    // --------------------------------------------------

    function gerarRelatorioEntradas(filtro) {
        const limite = obterDataLimite(filtro);

        const receitas = dados.receitas.filter(receita => {
            if (receita.estado === "anulado") return false;

            const dataRegisto = dataISO(receita.data);

            if (!dataRegisto || dataRegisto > limite) {
                return false;
            }

            const pendente = saldoReceitaAte(receita, limite);

            const registadaNoPeriodo = dentroPeriodo(
                receita.data,
                filtro.inicio,
                filtro.fim
            );

            // Mostrar registos do período e dívidas antigas ainda abertas.
            return registadaNoPeriodo || pendente > 0;
        });

        receitas.sort((a, b) =>
            dataISO(b.data).localeCompare(dataISO(a.data))
        );

        let totalPrevisto = 0;
        let totalRecebidoPeriodo = 0;
        let totalPendente = 0;

        const linhas = receitas.map(receita => {
            const previsto = numero(receita.valor);
            const recebido = totalRecebidoAte(receita.id, limite);
            const pendente = Math.max(0, previsto - recebido);

            totalPrevisto += previsto;
            totalRecebidoPeriodo += recebido;
            totalPendente += pendente;

            let estado = "Pendente";

            if (pendente <= 0 && previsto > 0) {
                estado = "Pago";
            } else if (recebido > 0) {
                estado = "Parcial";
            }

            return [
                escapar(dataFormatada(receita.data)),
                escapar(receita.descricao || "Entrada"),
                escapar(receita.categoria || "—"),
                escapar(receita.aluno || "—"),
                escapar(receita.turma || "—"),
                escapar(moeda(previsto)),
                escapar(moeda(recebido)),
                escapar(moeda(pendente)),
                escapar(estado)
            ];
        });

        const conteudo =
            cabecalhoRelatorio(
                nomesDocumentos.entradas,
                periodoTexto(filtro)
            ) +

            '<div class="sgfe-resumo-relatorio">' +
            resumoLinha("Total previsto dos registos apresentados", moeda(totalPrevisto)) +
            resumoLinha("Total recebido até à data final", moeda(totalRecebidoPeriodo)) +
            resumoLinha("Total ainda por receber", moeda(totalPendente)) +
            '</div>' +

            tabela(
                [
                    "Data",
                    "Descrição",
                    "Categoria",
                    "Aluno",
                    "Turma",
                    "Valor previsto",
                    "Valor recebido",
                    "Valor pendente",
                    "Estado"
                ],
                linhas
            ) +

            '<p class="sgfe-nota-relatorio">' +
            'Este relatório inclui os registos efectuados no período seleccionado ' +
            'e as receitas anteriores que ainda apresentam valores por receber. ' +
            'Os valores recebidos e pendentes são calculados até ' +
            escapar(dataFormatada(limite)) + '. ' +
            'Pagamentos anulados não são considerados.' +
            '</p>';

        return {
            titulo: nomesDocumentos.entradas,
            conteudo
        };
    }

    // --------------------------------------------------
    // RESUMO FINANCEIRO DETALHADO
    // --------------------------------------------------

    function obterResumoFinanceiroDetalhado(filtro) {
        const limite = obterDataLimite(filtro);

        // 1. Receitas efectivamente recebidas no período
        const receitasRecebidas = somar(
            dados.pagamentos.filter(p =>
                p.estado !== "anulado" &&
                dentroPeriodo(p.data, filtro.inicio, filtro.fim)
            ),
            p => p.valor
        );

        // 2. Receitas ainda por receber até à data limite
        let receitasPendentes = 0;

        dados.receitas.forEach(receita => {
            if (receita.estado === "anulado") return;

            if (!dataAteLimite(receita.data, limite)) return;

            receitasPendentes += saldoReceitaAte(receita, limite);
        });

        // 3. Despesas efectivamente pagas no período
        let despesasPagas = 0;

        dados.despesas.forEach(despesa => {
            despesasPagas += somar(
                pagamentosDespesa(despesa).filter(p =>
                    dentroPeriodo(p.data, filtro.inicio, filtro.fim)
                ),
                p => p.valor
            );
        });

        // 4. Despesas ainda por pagar até à data limite
        let despesasPendentes = 0;

        dados.despesas.forEach(despesa => {
            if (!dataAteLimite(despesa.data, limite)) return;

            despesasPendentes += saldoDespesaAte(despesa, limite);
        });

        // 5. Salários efectivamente pagos no período
        let salariosPagos = 0;

        dados.salarios.forEach(salario => {
            salariosPagos += somar(
                pagamentosSalariais(salario).filter(p =>
                    p.estado !== "anulado" &&
                    dentroPeriodo(p.data, filtro.inicio, filtro.fim)
                ),
                p => p.valor
            );
        });

        // 6. Salários ainda por pagar até à data limite
        let salariosPendentes = 0;

        dados.salarios.forEach(salario => {
            if (!dataAteLimite(dataFolhaSalario(salario), limite)) {
                return;
            }

            salariosPendentes += saldoSalarioAte(salario, limite);
        });

        const totalEntradas =
            receitasRecebidas + receitasPendentes;

        const totalSaidas =
            despesasPagas + salariosPagos;

        const totalSaidasPendentes =
            despesasPendentes + salariosPendentes;

        return {
            receitasRecebidas,
            receitasPendentes,
            totalEntradas,

            despesasPagas,
            despesasPendentes,

            salariosPagos,
            salariosPendentes,

            totalSaidas,
            totalSaidasPendentes,

            saldo: receitasRecebidas - totalSaidas,

            saldoProjetado:
                totalEntradas -
                totalSaidas -
                totalSaidasPendentes
        };
    }

    // --------------------------------------------------
    // MOVIMENTOS MENSAIS
    // --------------------------------------------------

    function obterMovimentosMensais(filtro) {
        const meses = {};

        function garantirMes(chave) {
            if (!chave) return null;

            if (!meses[chave]) {
                meses[chave] = {
                    mes: chave,
                    entradas: 0,
                    despesas: 0,
                    salarios: 0,
                    receitasPendentes: 0,
                    despesasPendentes: 0,
                    salariosPendentes: 0
                };
            }

            return meses[chave];
        }

        // Entradas efectivamente recebidas
        dados.pagamentos.forEach(p => {
            if (
                p.estado === "anulado" ||
                !dentroPeriodo(p.data, filtro.inicio, filtro.fim)
            ) {
                return;
            }

            const mes = garantirMes(obterMesChave(p.data));

            if (mes) {
                mes.entradas += numero(p.valor);
            }
        });

        // Receitas pendentes
        const limite = obterDataLimite(filtro);

        dados.receitas.forEach(r => {
            if (
                r.estado === "anulado" ||
                !dataAteLimite(r.data, limite)
            ) {
                return;
            }

            const pendente = saldoReceitaAte(r, limite);
            const mes = garantirMes(obterMesChave(r.data));

            if (mes) {
                mes.receitasPendentes += pendente;
            }
        });

        // Despesas pagas e pendentes
        dados.despesas.forEach(d => {
            pagamentosDespesa(d).forEach(p => {
                if (!dentroPeriodo(p.data, filtro.inicio, filtro.fim)) {
                    return;
                }

                const mes = garantirMes(obterMesChave(p.data));

                if (mes) {
                    mes.despesas += numero(p.valor);
                }
            });

            if (dataAteLimite(d.data, limite)) {
                const pendente = saldoDespesaAte(d, limite);
                const mes = garantirMes(obterMesChave(d.data));

                if (mes) {
                    mes.despesasPendentes += pendente;
                }
            }
        });

        // Salários pagos e pendentes
        dados.salarios.forEach(s => {
            const dataFolha = dataFolhaSalario(s);

            if (dataAteLimite(dataFolha, limite)) {
                const mes = garantirMes(obterMesChave(dataFolha));

                if (mes) {
                    mes.salariosPendentes += saldoSalarioAte(s, limite);
                }
            }

            pagamentosSalariais(s).forEach(p => {
                if (
                    p.estado === "anulado" ||
                    !dentroPeriodo(p.data, filtro.inicio, filtro.fim)
                ) {
                    return;
                }

                const mes = garantirMes(obterMesChave(p.data));

                if (mes) {
                    mes.salarios += numero(p.valor);
                }
            });
        });

        return Object.values(meses).sort((a, b) =>
            a.mes.localeCompare(b.mes)
        );
    }

    // --------------------------------------------------
    // RELATÓRIO FINANCEIRO GERAL
    // --------------------------------------------------

    function gerarRelatorioFinanceiro(filtro) {
        const resumo = obterResumoFinanceiroDetalhado(filtro);

        const conteudo =
            cabecalhoRelatorio(
                nomesDocumentos.financeiro,
                periodoTexto(filtro)
            ) +

            '<h3>Resumo das entradas</h3>' +

            tabela(
                ["Descrição", "Valor"],
                [
                    [
                        "Receitas recebidas no período",
                        escapar(moeda(resumo.receitasRecebidas))
                    ],
                    [
                        "Receitas pendentes até à data final",
                        escapar(moeda(resumo.receitasPendentes))
                    ],
                    [
                        "Total de entradas",
                        "<strong>" +
                        escapar(moeda(resumo.totalEntradas)) +
                        "</strong>"
                    ]
                ]
            ) +

            '<h3>Resumo das saídas</h3>' +

            tabela(
                ["Descrição", "Valor"],
                [
                    [
                        "Despesas pagas no período",
                        escapar(moeda(resumo.despesasPagas))
                    ],
                    [
                        "Despesas pendentes até à data final",
                        escapar(moeda(resumo.despesasPendentes))
                    ],
                    [
                        "Salários pagos no período",
                        escapar(moeda(resumo.salariosPagos))
                    ],
                    [
                        "Salários pendentes até à data final",
                        escapar(moeda(resumo.salariosPendentes))
                    ],
                    [
                        "Total de saídas pagas",
                        "<strong>" +
                        escapar(moeda(resumo.totalSaidas)) +
                        "</strong>"
                    ],
                    [
                        "Total de saídas pendentes",
                        "<strong>" +
                        escapar(moeda(resumo.totalSaidasPendentes)) +
                        "</strong>"
                    ]
                ]
            ) +

            '<h3>Resultado financeiro</h3>' +

            tabela(
                ["Indicador", "Valor"],
                [
                    [
                        "Total de entradas",
                        escapar(moeda(resumo.totalEntradas))
                    ],
                    [
                        "Total de saídas pagas",
                        escapar(moeda(resumo.totalSaidas))
                    ],
                    [
                        "Saldo disponível do período",
                        "<strong>" +
                        escapar(moeda(resumo.saldo)) +
                        "</strong>"
                    ],
                    [
                        "Saldo projectado após liquidação das pendências",
                        "<strong>" +
                        escapar(moeda(resumo.saldoProjetado)) +
                        "</strong>"
                    ]
                ]
            ) +

            '<p class="sgfe-nota-relatorio">' +
            'O saldo disponível corresponde às receitas recebidas no período ' +
            'menos as saídas efectivamente pagas no período. ' +
            'O saldo projectado considera também as receitas ainda por receber ' +
            'e as obrigações ainda por pagar até à data final seleccionada. ' +
            'Os pagamentos anulados não são considerados.' +
            '</p>';

        return {
            titulo: nomesDocumentos.financeiro,
            conteudo
        };
    }

    // --------------------------------------------------
    // HISTÓRICO DE PAGAMENTOS E ANULAÇÕES
    // --------------------------------------------------

    function gerarHistoricoEntradas(filtro) {
        const pagamentos = filtrarPorPeriodo(
            dados.pagamentos,
            "data",
            filtro
        );

        let confirmados = 0;
        let anulados = 0;

        const linhas = pagamentos.map(pagamento => {
            const receita = dados.receitas.find(r =>
                String(r.id) === String(pagamento.receitaId)
            );

            const anulado = pagamento.estado === "anulado";

            if (anulado) {
                anulados += numero(pagamento.valor);
            } else {
                confirmados += numero(pagamento.valor);
            }

            return [
                escapar(dataFormatada(pagamento.data)),
                escapar(
                    pagamento.descricao ||
                    receita?.descricao ||
                    "Pagamento"
                ),
                escapar(receita?.aluno || "—"),
                escapar(pagamento.metodo || "—"),
                escapar(pagamento.referencia || "—"),
                escapar(moeda(pagamento.valor)),
                anulado
                    ? '<strong style="color:#a32626">ANULADO</strong>'
                    : "Confirmado"
            ];
        });

        const conteudo =
            cabecalhoRelatorio(
                nomesDocumentos.historico,
                periodoTexto(filtro)
            ) +

            '<div class="sgfe-resumo-relatorio">' +
            resumoLinha("Pagamentos confirmados", moeda(confirmados)) +
            resumoLinha("Pagamentos anulados", moeda(anulados)) +
            '</div>' +

            tabela(
                [
                    "Data",
                    "Descrição",
                    "Aluno",
                    "Método",
                    "Referência",
                    "Valor",
                    "Estado"
                ],
                linhas
            );

        return {
            titulo: nomesDocumentos.historico,
            conteudo
        };
    }

    // --------------------------------------------------
    // FOLHA SALARIAL INDIVIDUAL
    // --------------------------------------------------

    function gerarFolhaIndividual(filtro) {
        const salario = dados.salarios.find(s =>
            String(s.funcionarioId) === String(filtro.funcionarioId) &&
            Number(s.mes) === filtro.mes &&
            Number(s.ano) === filtro.ano
        );

        if (!salario) {
            return {
                titulo: nomesDocumentos.folhaIndividual,
                conteudo:
                    cabecalhoRelatorio(
                        nomesDocumentos.folhaIndividual,
                        filtro.mes + "/" + filtro.ano
                    ) +
                    '<p class="sgfe-aviso-relatorio">' +
                    'Não foi encontrada uma folha salarial para o funcionário e período seleccionados.' +
                    '</p>'
            };
        }

        const pagamentos = pagamentosSalariais(salario);

        const confirmados = pagamentos.filter(p =>
            p.estado !== "anulado"
        );

        const anulados = pagamentos.filter(p =>
            p.estado === "anulado"
        );

        const linhasPagamentos = pagamentos.map(p => [
            escapar(dataFormatada(p.data)),
            escapar(moeda(p.valor)),
            escapar(p.metodo || "—"),
            p.estado === "anulado"
                ? '<strong style="color:#a32626">Anulado</strong>'
                : "Confirmado",
            escapar(p.motivoAnulacao || "—")
        ]);

        const conteudo =
            cabecalhoRelatorio(
                nomesDocumentos.folhaIndividual,
                String(filtro.mes).padStart(2, "0") + "/" + filtro.ano
            ) +

            '<h3>Identificação do funcionário</h3>' +

            tabela(
                ["Nome", "Cargo", "Mês", "Ano"],
                [[
                    escapar(salario.funcionarioNome || "—"),
                    escapar(salario.cargo || "—"),
                    escapar(filtro.mes),
                    escapar(filtro.ano)
                ]]
            ) +

            '<h3>Composição salarial</h3>' +

            tabela(
                [
                    "Salário base",
                    "Subsídios",
                    "Descontos",
                    "Salário líquido"
                ],
                [[
                    escapar(moeda(salario.salarioBase)),
                    escapar(moeda(salario.subsidios)),
                    escapar(moeda(salario.descontos)),
                    escapar(moeda(salario.salarioLiquido))
                ]]
            ) +

            '<div class="sgfe-resumo-relatorio">' +
            resumoLinha("Total pago", moeda(totalPagoSalario(salario))) +
            resumoLinha("Saldo pendente", moeda(saldoSalario(salario))) +
            resumoLinha("Estado da folha", estadoSalario(salario)) +
            '</div>' +

            '<h3>Histórico de pagamentos</h3>' +

            tabela(
                ["Data", "Valor", "Método", "Estado", "Observação"],
                linhasPagamentos
            ) +

            '<p class="sgfe-nota-relatorio">' +
            'Pagamentos confirmados: ' + confirmados.length +
            ' | Pagamentos anulados: ' + anulados.length +
            '</p>';

        return {
            titulo: nomesDocumentos.folhaIndividual,
            conteudo
        };
    }

    // --------------------------------------------------
    // FOLHA SALARIAL COLECTIVA
    // --------------------------------------------------

    function gerarFolhaColetiva(filtro) {
        const folhas = dados.salarios.filter(s =>
            Number(s.mes) === filtro.mes &&
            Number(s.ano) === filtro.ano
        );

        const funcionarios = dados.funcionarios.filter(f =>
            f.estado !== "inativo" &&
            f.estado !== "desativado"
        );

        const linhas = [];

        let totalBase = 0;
        let totalSubsidios = 0;
        let totalDescontos = 0;
        let totalLiquido = 0;
        let totalPago = 0;
        let totalPendente = 0;

        funcionarios.forEach(funcionario => {
            const folha = folhas.find(s =>
                String(s.funcionarioId) === String(funcionario.id)
            );

            if (!folha) {
                linhas.push([
                    escapar(funcionario.nome || "—"),
                    escapar(funcionario.cargo || "—"),
                    "—",
                    "—",
                    "—",
                    "—",
                    "—",
                    "—",
                    '<strong>Sem folha</strong>'
                ]);

                return;
            }

            const base = numero(folha.salarioBase);
            const subsidios = numero(folha.subsidios);
            const descontos = numero(folha.descontos);
            const liquido = numero(folha.salarioLiquido);
            const pago = totalPagoSalario(folha);
            const pendente = saldoSalario(folha);

            totalBase += base;
            totalSubsidios += subsidios;
            totalDescontos += descontos;
            totalLiquido += liquido;
            totalPago += pago;
            totalPendente += pendente;

            linhas.push([
                escapar(folha.funcionarioNome || funcionario.nome || "—"),
                escapar(folha.cargo || funcionario.cargo || "—"),
                escapar(moeda(base)),
                escapar(moeda(subsidios)),
                escapar(moeda(descontos)),
                escapar(moeda(liquido)),
                escapar(moeda(pago)),
                escapar(moeda(pendente)),
                escapar(estadoSalario(folha))
            ]);
        });

        linhas.push([
            "<strong>TOTAIS</strong>",
            "",
            "<strong>" + escapar(moeda(totalBase)) + "</strong>",
            "<strong>" + escapar(moeda(totalSubsidios)) + "</strong>",
            "<strong>" + escapar(moeda(totalDescontos)) + "</strong>",
            "<strong>" + escapar(moeda(totalLiquido)) + "</strong>",
            "<strong>" + escapar(moeda(totalPago)) + "</strong>",
            "<strong>" + escapar(moeda(totalPendente)) + "</strong>",
            ""
        ]);

        const conteudo =
            cabecalhoRelatorio(
                nomesDocumentos.folhaColetiva,
                String(filtro.mes).padStart(2, "0") + "/" + filtro.ano
            ) +

            '<div class="sgfe-resumo-relatorio">' +
            resumoLinha(
                "Total líquido das folhas existentes",
                moeda(totalLiquido)
            ) +
            resumoLinha("Total pago", moeda(totalPago)) +
            resumoLinha("Total pendente", moeda(totalPendente)) +
            '</div>' +

            tabela(
                [
                    "Funcionário",
                    "Cargo",
                    "Base",
                    "Subsídios",
                    "Descontos",
                    "Líquido",
                    "Pago",
                    "Pendente",
                    "Estado"
                ],
                linhas
            );

        return {
            titulo: nomesDocumentos.folhaColetiva,
            conteudo,
            orientacao: "paisagem"
        };
    }

    // --------------------------------------------------
    // RELAÇÃO DE PAGAMENTOS SALARIAIS
    // --------------------------------------------------

    function gerarPagamentosSalariais(filtro) {
        const linhas = [];

        let totalConfirmado = 0;
        let totalAnulado = 0;

        dados.salarios.forEach(salario => {
            pagamentosSalariais(salario).forEach(pagamento => {
                if (!dentroPeriodo(
                    pagamento.data,
                    filtro.inicio,
                    filtro.fim
                )) {
                    return;
                }

                const anulado = pagamento.estado === "anulado";

                if (anulado) {
                    totalAnulado += numero(pagamento.valor);
                } else {
                    totalConfirmado += numero(pagamento.valor);
                }

                linhas.push([
                    escapar(dataFormatada(pagamento.data)),
                    escapar(salario.funcionarioNome || "—"),
                    escapar(salario.cargo || "—"),
                    escapar(moeda(pagamento.valor)),
                    escapar(pagamento.metodo || "—"),
                    anulado
                        ? '<strong style="color:#a32626">Anulado</strong>'
                        : "Confirmado",
                    escapar(pagamento.motivoAnulacao || "—")
                ]);
            });
        });

        const conteudo =
            cabecalhoRelatorio(
                nomesDocumentos.pagamentosSalariais,
                periodoTexto(filtro)
            ) +

            '<div class="sgfe-resumo-relatorio">' +
            resumoLinha(
                "Pagamentos confirmados",
                moeda(totalConfirmado)
            ) +
            resumoLinha(
                "Pagamentos anulados",
                moeda(totalAnulado)
            ) +
            '</div>' +

            tabela(
                [
                    "Data",
                    "Funcionário",
                    "Cargo",
                    "Valor",
                    "Método",
                    "Estado",
                    "Observação"
                ],
                linhas
            );

        return {
            titulo: nomesDocumentos.pagamentosSalariais,
            conteudo
        };
    }

    // --------------------------------------------------
    // RELATÓRIO DE DESPESAS
    // --------------------------------------------------

    function gerarRelatorioDespesas(filtro) {
        const linhas = [];

        let totalPrevisto = 0;
        let totalPago = 0;
        let totalPendente = 0;

        const limite = obterDataLimite(filtro);

        dados.despesas.forEach(despesa => {
            const pagamentos = pagamentosDespesa(despesa);

            const pagosNoPeriodo = pagamentos.filter(p =>
                dentroPeriodo(p.data, filtro.inicio, filtro.fim)
            );

            const previstaNoPeriodo = dentroPeriodo(
                despesa.data,
                filtro.inicio,
                filtro.fim
            );

            const pendenteAteLimite = dataAteLimite(
                despesa.data,
                limite
            )
                ? saldoDespesaAte(despesa, limite)
                : 0;

            if (
                !previstaNoPeriodo &&
                !pagosNoPeriodo.length &&
                pendenteAteLimite <= 0
            ) {
                return;
            }

            const previsto = previstaNoPeriodo
                ? numero(despesa.valor)
                : 0;

            const pago = somar(pagosNoPeriodo, p => p.valor);

            totalPrevisto += previsto;
            totalPago += pago;

            if (pendenteAteLimite > 0) {
                totalPendente += pendenteAteLimite;
            }

            let estado = "Pendente";

            if (pendenteAteLimite <= 0 && previsto > 0) {
                estado = "Pago";
            } else if (pago > 0 || totalPagoDespesaAte(despesa, limite) > 0) {
                estado = "Parcial";
            }

            linhas.push([
                escapar(dataFormatada(despesa.data)),
                escapar(despesa.descricao || despesa.nome || "Despesa"),
                escapar(despesa.categoria || despesa.tipo || "—"),
                escapar(despesa.servico || "—"),
                escapar(moeda(previsto)),
                escapar(moeda(pago)),
                escapar(moeda(pendenteAteLimite)),
                escapar(estado)
            ]);
        });

        const conteudo =
            cabecalhoRelatorio(
                nomesDocumentos.despesas,
                periodoTexto(filtro)
            ) +

            '<div class="sgfe-resumo-relatorio">' +
            resumoLinha("Total previsto no período", moeda(totalPrevisto)) +
            resumoLinha("Total pago no período", moeda(totalPago)) +
            resumoLinha("Total pendente até à data final", moeda(totalPendente)) +
            '</div>' +

            tabela(
                [
                    "Data",
                    "Descrição",
                    "Categoria",
                    "Serviço",
                    "Previsto",
                    "Pago no período",
                    "Pendente",
                    "Estado"
                ],
                linhas
            );

        return {
            titulo: nomesDocumentos.despesas,
            conteudo
        };
    }

    // --------------------------------------------------
    // GRÁFICOS FINANCEIROS
    // --------------------------------------------------

    function gerarGraficos(filtro) {
        const resumo = obterResumoFinanceiroDetalhado(filtro);
        const movimentos = obterMovimentosMensais(filtro);

        const maiorEntrada = Math.max(
            1,
            ...movimentos.map(m => m.entradas)
        );

        const maiorSaida = Math.max(
            1,
            ...movimentos.map(m => m.despesas + m.salarios)
        );

        function barraMensal(nome, valor, maior) {
            const largura = Math.max(
                0,
                (valor / maior) * 100
            );

            return '<div class="sgfe-grafico-linha">' +
                '<div class="sgfe-grafico-legenda">' +
                '<span>' + escapar(nome) + '</span>' +
                '<strong>' + escapar(moeda(valor)) + '</strong>' +
                '</div>' +
                '<div class="sgfe-grafico-fundo">' +
                '<div class="sgfe-barra" style="width:' +
                largura + '%"></div>' +
                '</div></div>';
        }

        const graficosEntradas = movimentos.map(m =>
            '<div class="sgfe-grafico-mes">' +
            '<h4>' + escapar(formatarMes(m.mes)) + '</h4>' +
            barraMensal(
                "Entradas recebidas",
                m.entradas,
                maiorEntrada
            ) +
            '</div>'
        ).join("");

        const graficosSaidas = movimentos.map(m =>
            '<div class="sgfe-grafico-mes">' +
            '<h4>' + escapar(formatarMes(m.mes)) + '</h4>' +
            barraMensal(
                "Despesas pagas",
                m.despesas,
                maiorSaida
            ) +
            barraMensal(
                "Salários pagos",
                m.salarios,
                maiorSaida
            ) +
            '</div>'
        ).join("");

        const linhasMensais = movimentos.map(m => [
            escapar(formatarMes(m.mes)),
            escapar(moeda(m.entradas)),
            escapar(moeda(m.despesas)),
            escapar(moeda(m.salarios)),
            escapar(moeda(
                m.entradas - m.despesas - m.salarios
            ))
        ]);

        const conteudo =
            cabecalhoRelatorio(
                nomesDocumentos.graficos,
                periodoTexto(filtro)
            ) +

            '<div class="sgfe-resumo-relatorio">' +
            resumoLinha(
                "Total de entradas",
                moeda(resumo.totalEntradas)
            ) +
            resumoLinha(
                "Total de saídas pagas",
                moeda(resumo.totalSaidas)
            ) +
            resumoLinha(
                "Saldo disponível",
                moeda(resumo.saldo)
            ) +
            resumoLinha(
                "Total de pendências",
                moeda(
                    resumo.receitasPendentes +
                    resumo.totalSaidasPendentes
                )
            ) +
            '</div>' +

            '<h3>Entradas por mês</h3>' +
            '<div class="sgfe-grafico">' +
            (
                graficosEntradas ||
                '<p>Sem movimentos de entrada no período.</p>'
            ) +
            '</div>' +

            '<div class="sgfe-quebra-pagina"></div>' +

            '<h3>Saídas por mês</h3>' +
            '<div class="sgfe-grafico">' +
            (
                graficosSaidas ||
                '<p>Sem movimentos de saída no período.</p>'
            ) +
            '</div>' +

            '<div class="sgfe-quebra-pagina"></div>' +

            '<h3>Resumo mensal de movimentos</h3>' +

            tabela(
                [
                    "Mês",
                    "Entradas",
                    "Despesas",
                    "Salários",
                    "Saldo mensal"
                ],
                linhasMensais
            ) +

            '<h3>Situação das pendências</h3>' +

            tabela(
                ["Tipo", "Valor pendente"],
                [
                    [
                        "Receitas por receber",
                        escapar(moeda(resumo.receitasPendentes))
                    ],
                    [
                        "Despesas por pagar",
                        escapar(moeda(resumo.despesasPendentes))
                    ],
                    [
                        "Salários por pagar",
                        escapar(moeda(resumo.salariosPendentes))
                    ]
                ]
            );

        return {
            titulo: nomesDocumentos.graficos,
            conteudo,
            orientacao: "paisagem"
        };
    }

    // --------------------------------------------------
    // CONSTRUIR O DOCUMENTO SELECCIONADO
    // --------------------------------------------------

    function construirDocumento(tipo, filtro) {
        switch (tipo) {
            case "entradas":
                return gerarRelatorioEntradas(filtro);

            case "historico":
                return gerarHistoricoEntradas(filtro);

            case "folhaIndividual":
                return gerarFolhaIndividual(filtro);

            case "folhaColetiva":
                return gerarFolhaColetiva(filtro);

            case "pagamentosSalariais":
                return gerarPagamentosSalariais(filtro);

            case "despesas":
                return gerarRelatorioDespesas(filtro);

            case "financeiro":
                return gerarRelatorioFinanceiro(filtro);

            case "graficos":
                return gerarGraficos(filtro);

            default:
                return gerarRelatorioEntradas(filtro);
        }
    }

    // --------------------------------------------------
    // INTERFACE DA CENTRAL DE RELATÓRIOS
    // --------------------------------------------------

    function criarInterface() {
        const hoje = new Date();

        const anoActual = hoje.getFullYear();

        const mesActual = String(
            hoje.getMonth() + 1
        ).padStart(2, "0");

        const funcionariosOptions = dados.funcionarios.map(f =>
            '<option value="' + escapar(f.id) + '">' +
            escapar(f.nome || "Funcionário") +
            '</option>'
        ).join("");

        modulo.innerHTML = `
            <section class="entradas-modulo sgfe-relatorios">
                <div class="cabecalho-modulo">
                    <div>
                        <h2>Central de Relatórios</h2>
                        <p>Consulta, organização e impressão dos documentos financeiros.</p>
                    </div>
                </div>

                <div class="painel-formulario sgfe-filtros-relatorio">
                    <h3>Seleccionar documento</h3>

                    <div class="formulario-grelha">
                        <div class="campo-formulario">
                            <label for="relatorioTipo">Tipo de relatório</label>
                            <select id="relatorioTipo">
                                <option value="entradas">Registo completo de entradas</option>
                                <option value="historico">Histórico de pagamentos e anulações</option>
                                <option value="folhaIndividual">Folha salarial individual</option>
                                <option value="folhaColetiva">Folha salarial colectiva</option>
                                <option value="pagamentosSalariais">Relação de pagamentos salariais</option>
                                <option value="despesas">Relatório de despesas</option>
                                <option value="financeiro">Relatório financeiro geral</option>
                                <option value="graficos">Gráficos financeiros</option>
                            </select>
                        </div>

                        <div class="campo-formulario">
                            <label for="relatorioDataInicio">Data inicial</label>
                            <input type="date" id="relatorioDataInicio">
                        </div>

                        <div class="campo-formulario">
                            <label for="relatorioDataFim">Data final</label>
                            <input type="date" id="relatorioDataFim">
                        </div>

                        <div class="campo-formulario sgfe-campo-folha" hidden>
                            <label for="relatorioMes">Mês da folha</label>
                            <select id="relatorioMes">
                                <option value="1">Janeiro</option>
                                <option value="2">Fevereiro</option>
                                <option value="3">Março</option>
                                <option value="4">Abril</option>
                                <option value="5">Maio</option>
                                <option value="6">Junho</option>
                                <option value="7">Julho</option>
                                <option value="8">Agosto</option>
                                <option value="9">Setembro</option>
                                <option value="10">Outubro</option>
                                <option value="11">Novembro</option>
                                <option value="12">Dezembro</option>
                            </select>
                        </div>

                        <div class="campo-formulario sgfe-campo-folha" hidden>
                            <label for="relatorioAno">Ano</label>
                            <input type="number" id="relatorioAno" min="2000" max="2100" value="${anoActual}">
                        </div>

                        <div class="campo-formulario sgfe-campo-funcionario" hidden>
                            <label for="relatorioFuncionario">Funcionário</label>
                            <select id="relatorioFuncionario">
                                <option value="">Seleccionar funcionário</option>
                                ${funcionariosOptions}
                            </select>
                        </div>
                    </div>

                    <div class="botoes-formulario">
                        <button type="button" class="botao-principal" id="btnVisualizarRelatorio">
                            Visualizar relatório
                        </button>

                        <button type="button" class="botao-secundario" id="btnImprimirRelatorio" disabled>
                            Imprimir / Guardar PDF
                        </button>
                    </div>
                </div>

                <div class="painel-tabela sgfe-area-visualizacao">
                    <div class="cabecalho-tabela">
                        <h3>Pré-visualização</h3>
                        <span id="relatorioEstado">Seleccione um documento para começar.</span>
                    </div>

                    <div id="relatorioVisualizacao" class="sgfe-visualizacao-conteudo">
                        <div class="modulo-placeholder">
                            <div class="placeholder-icone">▤</div>
                            <h3>Central de documentos</h3>
                            <p>Escolha o tipo de relatório e clique em “Visualizar relatório”.</p>
                        </div>
                    </div>
                </div>
            </section>
        `;

        document.getElementById("relatorioMes").value = mesActual;
        document.getElementById("relatorioAno").value = anoActual;

        document.getElementById("relatorioTipo").addEventListener(
            "change",
            atualizarCampos
        );

        document.getElementById("btnVisualizarRelatorio").addEventListener(
            "click",
            visualizar
        );

        document.getElementById("btnImprimirRelatorio").addEventListener(
            "click",
            imprimir
        );

        atualizarCampos();
    }

    function atualizarCampos() {
        const tipo = document.getElementById("relatorioTipo").value;

        const usaFolha =
            tipo === "folhaIndividual" ||
            tipo === "folhaColetiva";

        const usaFuncionario =
            tipo === "folhaIndividual";

        document.querySelectorAll(".sgfe-campo-folha").forEach(campo => {
            campo.hidden = !usaFolha;
        });

        document.querySelectorAll(".sgfe-campo-funcionario").forEach(campo => {
            campo.hidden = !usaFuncionario;
        });

        const usaPeriodo = !usaFolha;

        document.getElementById("relatorioDataInicio").disabled =
            !usaPeriodo;

        document.getElementById("relatorioDataFim").disabled =
            !usaPeriodo;
    }

    // --------------------------------------------------
    // VISUALIZAÇÃO DO RELATÓRIO
    // --------------------------------------------------

    async function visualizar() {
        const botao = document.getElementById("btnVisualizarRelatorio");
        const estado = document.getElementById("relatorioEstado");
        const area = document.getElementById("relatorioVisualizacao");
        const imprimirBotao = document.getElementById("btnImprimirRelatorio");

        try {
            botao.disabled = true;

            estado.textContent = "A preparar relatório...";

            await carregarDados();

            documentoActual =
                document.getElementById("relatorioTipo").value;

            const filtro = obterFiltro();

            if (
                filtro.inicio &&
                filtro.fim &&
                filtro.inicio > filtro.fim
            ) {
                throw new Error(
                    "A data inicial não pode ser posterior à data final."
                );
            }

            if (
                documentoActual === "folhaIndividual" &&
                !filtro.funcionarioId
            ) {
                throw new Error(
                    "Seleccione o funcionário para consultar a folha individual."
                );
            }

            const documento = construirDocumento(
                documentoActual,
                filtro
            );

            area.innerHTML = documento.conteudo;

            estado.textContent = "Relatório preparado.";

            imprimirBotao.disabled = false;

            area.dataset.titulo = documento.titulo;

            area.dataset.orientacao =
                documento.orientacao || "retrato";

        } catch (erro) {
            area.innerHTML =
                '<p class="sgfe-erro-relatorio">' +
                escapar(
                    erro.message ||
                    "Não foi possível gerar o relatório."
                ) +
                '</p>';

            estado.textContent =
                "Não foi possível preparar o documento.";

            imprimirBotao.disabled = true;

        } finally {
            botao.disabled = false;
        }
    }

    // --------------------------------------------------
    // IMPRESSÃO
    // --------------------------------------------------

    function imprimir() {
        const area = document.getElementById("relatorioVisualizacao");

        const botao = document.getElementById(
            "btnImprimirRelatorio"
        );

        if (
            !area ||
            !area.innerHTML.trim() ||
            botao.disabled
        ) {
            alert("Primeiro, visualize o relatório.");
            return;
        }

        if (!window.SGFE_IMPRESSAO) {
            alert(
                "O motor de impressão não está disponível. Verifique o ficheiro impressao.js."
            );

            return;
        }

        window.SGFE_IMPRESSAO.imprimir({
            titulo: area.dataset.titulo || "Relatório financeiro",
            periodo: periodoTexto(obterFiltro()),
            conteudo: area.innerHTML,
            orientacao: area.dataset.orientacao || "retrato",
            assinaturas: true
        });
    }

    // --------------------------------------------------
    // FUNÇÕES DE RESUMO DISPONÍVEIS PARA OUTROS MÓDULOS
    // --------------------------------------------------

    async function obterResumoReceitas(inicio, fim) {
        await carregarDados();

        const filtro = {
            inicio: inicio || "",
            fim: fim || ""
        };

        const receitas = filtrarPorPeriodo(
            dados.receitas,
            "data",
            filtro
        ).filter(r => r.estado !== "anulado");

        return {
            quantidade: receitas.length,

            previsto: somar(
                receitas,
                r => r.valor
            ),

            recebido: somar(
                dados.pagamentos.filter(p =>
                    p.estado !== "anulado" &&
                    dentroPeriodo(
                        p.data,
                        filtro.inicio,
                        filtro.fim
                    )
                ),
                p => p.valor
            )
        };
    }

    async function obterResumoDespesas(inicio, fim) {
        await carregarDados();

        const filtro = {
            inicio: inicio || "",
            fim: fim || ""
        };

        const despesas = dados.despesas.filter(d =>
            dentroPeriodo(
                d.data,
                filtro.inicio,
                filtro.fim
            )
        );

        return {
            quantidade: despesas.length,

            total: somar(
                despesas,
                d => d.valor
            ),

            pago: somar(
                despesas,
                d => somar(
                    pagamentosDespesa(d).filter(p =>
                        dentroPeriodo(
                            p.data,
                            filtro.inicio,
                            filtro.fim
                        )
                    ),
                    p => p.valor
                )
            )
        };
    }

    async function obterResumoSalarios(mes, ano) {
        await carregarDados();

        const folhas = dados.salarios.filter(s =>
            Number(s.mes) === Number(mes) &&
            Number(s.ano) === Number(ano)
        );

        return {
            quantidade: folhas.length,

            total: somar(
                folhas,
                s => s.salarioLiquido
            ),

            pago: somar(
                folhas,
                s => totalPagoSalario(s)
            ),

            pendente: somar(
                folhas,
                s => saldoSalario(s)
            )
        };
    }

    async function obterBalanco(inicio, fim) {
        await carregarDados();

        const filtro = {
            inicio: inicio || "",
            fim: fim || ""
        };

        const receitas = somar(
            dados.pagamentos.filter(p =>
                p.estado !== "anulado" &&
                dentroPeriodo(
                    p.data,
                    filtro.inicio,
                    filtro.fim
                )
            ),
            p => p.valor
        );

        let despesas = 0;

        dados.despesas.forEach(d => {
            despesas += somar(
                pagamentosDespesa(d).filter(p =>
                    dentroPeriodo(
                        p.data,
                        filtro.inicio,
                        filtro.fim
                    )
                ),
                p => p.valor
            );
        });

        let salarios = 0;

        dados.salarios.forEach(s => {
            salarios += somar(
                pagamentosSalariais(s).filter(p =>
                    p.estado !== "anulado" &&
                    dentroPeriodo(
                        p.data,
                        filtro.inicio,
                        filtro.fim
                    )
                ),
                p => p.valor
            );
        });

        return {
            receitas,
            despesas,
            salarios,
            totalSaidas: despesas + salarios,
            saldo: receitas - despesas - salarios
        };
    }

    async function despesasPorCategoria(inicio, fim) {
        await carregarDados();

        const filtro = {
            inicio: inicio || "",
            fim: fim || ""
        };

        const resultado = {};

        dados.despesas.forEach(d => {
            const categoria =
                d.categoria ||
                d.tipo ||
                "Sem categoria";

            const pago = somar(
                pagamentosDespesa(d).filter(p =>
                    dentroPeriodo(
                        p.data,
                        filtro.inicio,
                        filtro.fim
                    )
                ),
                p => p.valor
            );

            if (pago > 0) {
                resultado[categoria] =
                    (resultado[categoria] || 0) + pago;
            }
        });

        return resultado;
    }

    async function obterMovimentos(inicio, fim) {
        await carregarDados();

        const filtro = {
            inicio: inicio || "",
            fim: fim || ""
        };

        const movimentos = [];

        dados.pagamentos.forEach(p => {
            if (
                p.estado === "anulado" ||
                !dentroPeriodo(
                    p.data,
                    filtro.inicio,
                    filtro.fim
                )
            ) {
                return;
            }

            movimentos.push({
                tipo: "Entrada",
                descricao: p.descricao || "Pagamento recebido",
                valor: numero(p.valor),
                data: p.data
            });
        });

        dados.despesas.forEach(d => {
            pagamentosDespesa(d).forEach(p => {
                if (!dentroPeriodo(
                    p.data,
                    filtro.inicio,
                    filtro.fim
                )) {
                    return;
                }

                movimentos.push({
                    tipo: "Despesa",
                    descricao: d.descricao || d.nome || "Despesa",
                    valor: numero(p.valor),
                    data: p.data
                });
            });
        });

        dados.salarios.forEach(s => {
            pagamentosSalariais(s).forEach(p => {
                if (
                    p.estado === "anulado" ||
                    !dentroPeriodo(
                        p.data,
                        filtro.inicio,
                        filtro.fim
                    )
                ) {
                    return;
                }

                movimentos.push({
                    tipo: "Salário",
                    descricao:
                        "Pagamento salarial - " +
                        (s.funcionarioNome || ""),
                    valor: numero(p.valor),
                    data: p.data
                });
            });
        });

        return movimentos.sort((a, b) =>
            dataISO(b.data).localeCompare(dataISO(a.data))
        );
    }

    // --------------------------------------------------
    // INICIALIZAÇÃO DO MÓDULO
    // --------------------------------------------------

    async function abrir() {
        if (!modulo) {
            console.error(
                "A área conteudoModulo não foi encontrada."
            );

            return;
        }

        try {
            await carregarDados();

            criarInterface();

        } catch (erro) {
            modulo.innerHTML =
                '<div class="modulo-placeholder">' +
                '<h2>Central de Relatórios</h2>' +
                '<p>Não foi possível carregar os dados.</p>' +
                '<small>' + escapar(erro.message) + '</small>' +
                '</div>';
        }
    }

    async function atualizar() {
        await abrir();
    }

    window.SGFE_RELATORIOS = Object.freeze({
        abrir,
        atualizar,
        obterResumoReceitas,
        obterResumoDespesas,
        obterResumoSalarios,
        obterBalanco,
        despesasPorCategoria,
        obterMovimentos
    });

})();