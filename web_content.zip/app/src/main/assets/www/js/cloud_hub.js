/**
 * RoboSim AI Studio Pro - Online Cloud Store & Component Hub
 * Live simulated cloud repository, online search & filtering, instant download & 3D injection,
 * and local file importer (JSON, GLTF, OBJ, STL).
 */

window.RoboCloud = (function() {
  let activeFilter = "Todos";
  let searchQuery = "";
  const downloadedComponents = new Set(); // Track downloaded cloud IDs

  function getCloudCatalog() {
    const all = window.COMPONENTS_DB;
    const cloudItems = [];

    for (let key in all) {
      if (all[key].cloudOnly) {
        cloudItems.push(all[key]);
      }
    }

    return cloudItems;
  }

  function filterItems() {
    const catalog = getCloudCatalog();
    return catalog.filter(item => {
      const matchCategory = activeFilter === "Todos" || item.category === activeFilter;
      const matchQuery = !searchQuery || 
        item.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
        item.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.category.toLowerCase().includes(searchQuery.toLowerCase());
      return matchCategory && matchQuery;
    });
  }

  function downloadAndInstall(dbId, onProgress, onComplete) {
    const item = window.COMPONENTS_DB[dbId];
    if (!item) return;

    if (onProgress) onProgress("Conectando a Cloud CDN...", 25);

    setTimeout(() => {
      if (onProgress) onProgress(`Descargando geometría 3D (${item.fileSize || "250 KB"})...`, 65);

      setTimeout(() => {
        if (onProgress) onProgress("Verificando integridad y compatibilidad...", 90);

        setTimeout(() => {
          downloadedComponents.add(dbId);
          // Add to 3D scene
          const spawned = window.RoboEngine.addComponent(dbId);

          if (onProgress) onProgress("¡Instalado con éxito!", 100);
          if (onComplete) onComplete(spawned);

          // Toast message
          if (window.RoboApp && window.RoboApp.showNotification) {
            window.RoboApp.showNotification(`Componente '${item.name}' descargado e insertado.`);
          }
        }, 300);
      }, 350);
    }, 200);
  }

  // Handle local file import (JSON project or 3D files)
  function importLocalFile(file, callback) {
    if (!file) return;

    const reader = new FileReader();

    if (file.name.endsWith(".json")) {
      reader.onload = function(e) {
        try {
          const projectData = JSON.parse(e.target.result);
          if (projectData && projectData.components) {
            window.RoboEngine.clearAll();

            for (let comp of projectData.components) {
              const added = window.RoboEngine.addComponent(comp.dbId, comp.position);
              if (added && comp.rotation) {
                added.mesh.rotation.x = comp.rotation.x || 0;
                added.mesh.rotation.y = comp.rotation.y || 0;
                added.mesh.rotation.z = comp.rotation.z || 0;
              }
            }

            if (callback) callback(true, `Proyecto '${projectData.name || file.name}' cargado.`);
          } else {
            if (callback) callback(false, "Formato JSON de proyecto inválido.");
          }
        } catch (err) {
          if (callback) callback(false, "Error al parsear el archivo JSON: " + err.message);
        }
      };
      reader.readAsText(file);
    } else {
      // For STL/OBJ/GLTF: create custom generic CAD block with file name
      reader.onload = function() {
        // Register custom procedural component
        const customId = "imported_" + Date.now();
        window.COMPONENTS_DB[customId] = {
          id: customId,
          name: "Pieza CAD: " + file.name.replace(/\.[^/.]+$/, ""),
          category: "Chasis & Estructuras",
          description: `Pieza 3D importada localmente desde ${file.name} (${(file.size / 1024).toFixed(1)} KB).`,
          specs: { voltage: 0, idleCurrent: 0, peakCurrent: 0, isPowerSource: false, pins: [] },
          dimensions: { x: 30, y: 15, z: 30 },
          anchorPoints: [{ id: "center_mount", pos: [0, 0, 0], type: "custom_mount" }],
          createMesh: function() {
            const group = new THREE.Group();
            group.name = file.name;
            const geo = new THREE.BoxGeometry(3.0, 1.5, 3.0);
            const mat = new THREE.MeshStandardMaterial({
              color: 0x64748b,
              roughness: 0.3,
              metalness: 0.5
            });
            const m = new THREE.Mesh(geo, mat);
            m.castShadow = true;
            group.add(m);
            return group;
          }
        };

        const added = window.RoboEngine.addComponent(customId);
        if (callback) callback(true, `Archivo '${file.name}' importado como pieza CAD en la escena.`);
      };
      reader.readAsArrayBuffer(file);
    }
  }

  return {
    getCloudCatalog,
    filterItems,
    downloadAndInstall,
    importLocalFile,
    setFilter: (category) => { activeFilter = category; },
    setSearchQuery: (query) => { searchQuery = query; },
    getFilter: () => activeFilter,
    isDownloaded: (id) => downloadedComponents.has(id)
  };
})();
