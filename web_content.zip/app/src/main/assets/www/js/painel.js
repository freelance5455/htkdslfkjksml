
/* ============================================
   SGFE - PAINEL PRINCIPAL
   CÁLCULOS E INDICADORES FINANCEIROS
   Integração com pagamentos salariais
============================================ */

(function () {
    "use strict";

    const DB = window.SGFE_DB;

    if (!DB) {
        console.error("SGFE: armazenamento não encontrado.");
        return;
    }

    let periodoAtual = "ano";

    const ELEMENTOS = {
        receitas: document.getElementById("totalReceitas"),
        despesas: document.getElementById("totalDespesas"),
        saldo: document.getElementById("saldoPeriodo"),
        pendentes: document.getElementById("valoresPendentes"),
        despesasPendentes: document.getElementById("despesasPendentes"),
        salariosPagos: document.getElementById("salariosPagos"),
        salariosPendentes: document.getElementById("salariosPendentes"),
        mensalidades: document.getElementById("mensalidadesPendentes"),
        movimentacoes: document.getElementById("ultimasMovimentacoes"),
        periodo: document.getElementById("periodoPainel")
    };

    /* 1. FORMATAÇÃO */

    function moeda(valor) {
        return new Intl.NumberFormat("pt-AO", {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        }).format(Number(valor) || 0) + " Kz";
    }

    function numero(valor) {
        const resultado = Number(valor);
        return Number.isFinite(resultado) ? resultado : 0;
    }

    function dataValida(valor) {
        if (!valor) return null;

        const data = new Date(valor);

        return Number.isNaN(data.getTime()) ? null : data;
    }

    /* 2. FILTRAR POR PERÍODO */

    function pertenceAoPeriodo(data) {
        if (!data) return false;

        const agora = new Date();

        if (periodoAtual === "mes") {
            return data.getMonth() === agora.getMonth() &&
                data.getFullYear() === agora.getFullYear();
        }

        if (periodoAtual === "trimestre") {
            return Math.floor(data.getMonth() / 3) ===
                Math.floor(agora.getMonth() / 3) &&
                data.getFullYear() === agora.getFullYear();
        }

        if (periodoAtual === "semestre") {
            return Math.floor(data.getMonth() / 6) ===
                Math.floor(agora.getMonth() / 6) &&
                data.getFullYear() === agora.getFullYear();
        }

        return data.getFullYear() === agora.getFullYear();
    }

    function filtrarPeriodo(registos) {
        return registos.filter(registo => {
            const data = dataValida(
                registo.data || registo.criadoEm
            );

            return pertenceAoPeriodo(data);
        });
    }

    /* 3. RECEITAS */

    function valorRecebido(registo) {
        if (Array.isArray(registo.pagamentos)) {
            return registo.pagamentos.reduce((total, pagamento) => {
                if (pagamento.estado === "anulado") return total;
                return total + numero(pagamento.valor);
            }, 0);
        }

        if (registo.estado === "pago") {
            return numero(registo.valor);
        }

        if (registo.estado === "parcial") {
            return numero(
                registo.valorPago ?? registo.valorRecebido
            );
        }

        return 0;
    }

    function valorPendente(registo) {
        if (registo.estado === "anulado") return 0;

        return Math.max(
            0,
            numero(registo.valor) - valorRecebido(registo)
        );
    }

    /* 4. DESPESAS COMUNS */

    function valorPago(registo) {
        if (registo.estado === "anulado") return 0;

        if (registo.estado === "pago") {
            return numero(registo.valor);
        }

        if (registo.estado === "parcial") {
            return numero(registo.valorPago);
        }

        return 0;
    }

    function valorPendenteDespesa(registo) {
        if (registo.estado === "anulado") return 0;

        return Math.max(
            0,
            numero(registo.valor) - valorPago(registo)
        );
    }

    /* 5. FOLHAS SALARIAIS */

    function pagamentosSalariais(salario) {
        return (salario.pagamentos || []).filter(
            pagamento => pagamento.estado !== "anulado"
        );
    }

    function totalPagoSalario(salario) {
        if (Array.isArray(salario.pagamentos)) {
            return pagamentosSalariais(salario).reduce(
                (total, pagamento) =>
                    total + numero(pagamento.valor),
                0
            );
        }

        // Compatibilidade com registos salariais antigos.
        return valorPago(salario);
    }

    function pendenteSalario(salario) {
        const previsto = numero(
            salario.salarioLiquido ?? salario.valor
        );

        return Math.max(
            0,
            previsto - totalPagoSalario(salario)
        );
    }

    function dataFolhaSalarial(salario) {
        if (salario.ano && salario.mes) {
            return new Date(
                Number(salario.ano),
                Number(salario.mes) - 1,
                1
            );
        }

        return dataValida(salario.data || salario.criadoEm);
    }

    function salariosDoPeriodo(salarios) {
        return salarios.filter(salario =>
            pertenceAoPeriodo(dataFolhaSalarial(salario))
        );
    }

    function pagamentosSalariaisDoPeriodo(salarios) {
        let movimentos = [];

        salarios.forEach(salario => {
            if (Array.isArray(salario.pagamentos)) {
                pagamentosSalariais(salario).forEach(pagamento => {
                    const data = dataValida(
                        pagamento.data || pagamento.criadoEm
                    );

                    if (!data || !pertenceAoPeriodo(data)) return;

                    movimentos.push({
                        data: pagamento.data,
                        descricao:
                            salario.funcionarioNome ||
                            "Pagamento salarial",
                        categoria: "Salários",
                        tipo: "Saída",
                        valor: numero(pagamento.valor)
                    });
                });
            } else {
                const valor = valorPago(salario);

                if (valor > 0) {
                    const data = salario.data || salario.criadoEm;

                    if (pertenceAoPeriodo(dataValida(data))) {
                        movimentos.push({
                            data,
                            descricao:
                                salario.funcionarioNome ||
                                "Pagamento salarial",
                            categoria: "Salários",
                            tipo: "Saída",
                            valor
                        });
                    }
                }
            }
        });

        return movimentos;
    }

    /* 6. SOMAR VALORES */

    function somar(registos, funcao) {
        return registos.reduce(
            (total, registo) => total + funcao(registo),
            0
        );
    }

    /* 7. CARREGAR DADOS */

    async function carregarDados() {
        try {
            const [
                receitas,
                pagamentos,
                despesas,
                salarios
            ] = await Promise.all([
                DB.listar("receitas"),
                DB.listar("pagamentos"),
                DB.listar("despesas"),
                DB.listar("salarios")
            ]);

            atualizarPainel({
                receitas,
                pagamentos,
                despesas,
                salarios
            });

        } catch (erro) {
            console.error(
                "Erro ao carregar painel financeiro:",
                erro
            );
        }
    }

    /* 8. ACTUALIZAR INDICADORES */

    function atualizarPainel(dados) {
        const receitas = filtrarPeriodo(dados.receitas);

        const despesas = filtrarPeriodo(dados.despesas);

        const salarios = salariosDoPeriodo(dados.salarios);

        const pagamentos = filtrarPeriodo(dados.pagamentos);

        // RECEITAS

        const totalReceitas = somar(
            receitas,
            valorRecebido
        );

        // DESPESAS COMUNS

        const despesasComuns = despesas.filter(
            despesa => despesa.origem !== "salario"
        );

        const totalDespesasComuns = somar(
            despesasComuns,
            valorPago
        );

        const despesasPendentes = somar(
            despesasComuns,
            valorPendenteDespesa
        );

        // SALÁRIOS

        const salariosPagos = somar(
            pagamentosSalariaisDoPeriodo(dados.salarios),
            pagamento => numero(pagamento.valor)
        );

        const salariosPendentes = somar(
            salarios,
            pendenteSalario
        );

        // RECEITAS PENDENTES

        const totalPendentes = somar(
            receitas,
            valorPendente
        );

        // MENSALIDADES PENDENTES

        const mensalidades = receitas.filter(receita =>
            receita.tipo === "mensalidade" ||
            receita.categoria === "mensalidade"
        );

        const totalMensalidades = somar(
            mensalidades,
            valorPendente
        );

        // TOTAL DE DESPESAS E SALDO

        const totalDespesasRealizadas =
            totalDespesasComuns + salariosPagos;

        const saldo =
            totalReceitas - totalDespesasRealizadas;

        // APRESENTAR RESULTADOS

        if (ELEMENTOS.receitas)
            ELEMENTOS.receitas.textContent = moeda(totalReceitas);

        if (ELEMENTOS.despesas)
            ELEMENTOS.despesas.textContent =
                moeda(totalDespesasRealizadas);

        if (ELEMENTOS.saldo) {
            ELEMENTOS.saldo.textContent = moeda(saldo);

            ELEMENTOS.saldo.style.color =
                saldo < 0 ? "#C64B4B" : "#23865B";
        }

        if (ELEMENTOS.pendentes)
            ELEMENTOS.pendentes.textContent = moeda(totalPendentes);

        if (ELEMENTOS.despesasPendentes)
            ELEMENTOS.despesasPendentes.textContent =
                moeda(despesasPendentes);

        if (ELEMENTOS.salariosPagos)
            ELEMENTOS.salariosPagos.textContent =
                moeda(salariosPagos);

        if (ELEMENTOS.salariosPendentes)
            ELEMENTOS.salariosPendentes.textContent =
                moeda(salariosPendentes);

        if (ELEMENTOS.mensalidades)
            ELEMENTOS.mensalidades.textContent =
                moeda(totalMensalidades);

        // MOVIMENTAÇÕES

        apresentarMovimentacoes(
            receitas,
            pagamentos,
            despesasComuns,
            pagamentosSalariaisDoPeriodo(dados.salarios)
        );
    }

    /* 9. ÚLTIMAS MOVIMENTAÇÕES */

    function apresentarMovimentacoes(
        receitas,
        pagamentos,
        despesas,
        movimentosSalariais
    ) {
        let movimentos = [];

        receitas.forEach(registo => {
            if (valorRecebido(registo) > 0) {
                movimentos.push({
                    data: registo.data || registo.criadoEm,
                    descricao:
                        registo.descricao ||
                        registo.tipo ||
                        "Receita",
                    categoria: registo.categoria || "Receitas",
                    tipo: "Entrada",
                    valor: valorRecebido(registo)
                });
            }
        });

        // Pagamentos independentes registados na colecção.
        pagamentos.forEach(registo => {
            if (registo.estado === "anulado") return;

            movimentos.push({
                data: registo.data || registo.criadoEm,
                descricao: registo.descricao || "Pagamento",
                categoria: registo.categoria || "Receitas",
                tipo: "Entrada",
                valor: numero(registo.valor)
            });
        });

        despesas.forEach(registo => {
            if (valorPago(registo) > 0) {
                movimentos.push({
                    data: registo.data || registo.criadoEm,
                    descricao: registo.descricao || "Despesa",
                    categoria: registo.categoria || "Despesas",
                    tipo: "Saída",
                    valor: valorPago(registo)
                });
            }
        });

        movimentosSalariais.forEach(registo => {
            movimentos.push(registo);
        });

        movimentos.sort((a, b) =>
            new Date(b.data) - new Date(a.data)
        );

        const recentes = movimentos.slice(0, 10);

        if (!ELEMENTOS.movimentacoes) return;

        if (recentes.length === 0) {
            ELEMENTOS.movimentacoes.innerHTML = `
                <tr>
                    <td colspan="5">
                        Ainda não existem movimentações.
                    </td>
                </tr>
            `;
            return;
        }

        ELEMENTOS.movimentacoes.innerHTML =
            recentes.map(registo => {
                const data = dataValida(registo.data);

                const dataFormatada = data
                    ? data.toLocaleDateString("pt-AO")
                    : "—";

                return `
                    <tr>
                        <td>${dataFormatada}</td>
                        <td>${escaparHTML(registo.descricao)}</td>
                        <td>${escaparHTML(registo.categoria)}</td>
                        <td>${registo.tipo}</td>
                        <td>${moeda(registo.valor)}</td>
                    </tr>
                `;
            }).join("");
    }

    /* 10. PROTEGER TEXTO */

    function escaparHTML(valor) {
        return String(valor ?? "").replace(
            /[&<>"']/g,
            caracter => ({
                "&": "&amp;",
                "<": "&lt;",
                ">": "&gt;",
                '"': "&quot;",
                "'": "&#039;"
            })[caracter]
        );
    }

    /* 11. ALTERAR PERÍODO */

    if (ELEMENTOS.periodo) {
        ELEMENTOS.periodo.addEventListener("change", function () {
            periodoAtual = this.value;
            carregarDados();
        });
    }

    /* 12. DISPONIBILIZAR ACTUALIZAÇÃO */

    window.SGFE_PAINEL = Object.freeze({
        atualizar: carregarDados
    });

    /* 13. INICIALIZAÇÃO */

    carregarDados();

})();
