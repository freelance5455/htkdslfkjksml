/**
 * আলী আজগর সিদ্দিকিয়া মাদ্রাসা (Ali Azgar Siddiqia Madrasa)
 * Database & Financial Operations Service
 * Robust Dual-Persistence (Supabase Cloud + Local Storage Sync)
 */

const DB = {
  // --------------------------------------------------------------------------
  // UUID & Validation Utilities
  // --------------------------------------------------------------------------
  generateUUID() {
    if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
      try {
        return crypto.randomUUID();
      } catch (e) {}
    }
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
      const r = (Math.random() * 16) | 0;
      const v = c === 'x' ? r : (r & 0x3) | 0x8;
      return v.toString(16);
    });
  },

  isValidUUID(str) {
    if (!str || typeof str !== 'string') return false;
    const regex = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
    return regex.test(str.trim());
  },

  // --------------------------------------------------------------------------
  // Number & Currency Helpers (Bilingual aware)
  // --------------------------------------------------------------------------
  toBnNum(num) {
    if (num === null || num === undefined) return window.I18n && window.I18n.currentLang === 'en' ? '0' : '০';
    if (window.I18n && window.I18n.currentLang === 'en') {
      return num.toString();
    }
    const bnDigits = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
    return num.toString().replace(/\d/g, d => bnDigits[parseInt(d, 10)]);
  },

  formatTaka(amount) {
    const val = Number(amount) || 0;
    const formatted = val.toLocaleString('en-IN');
    if (window.I18n && window.I18n.currentLang === 'en') {
      return `৳ ${formatted}`;
    }
    return `${this.toBnNum(formatted)} ৳`;
  },

  // --------------------------------------------------------------------------
  // Settings Management
  // --------------------------------------------------------------------------
  async getSettings() {
    if (window.SupabaseModule && window.SupabaseModule.isConfiguredWithSupabase()) {
      try {
        const client = window.SupabaseModule.getClient();
        const { data, error } = await client.from('app_settings').select('*');
        if (!error && Array.isArray(data) && data.length > 0) {
          const settingsObj = {};
          data.forEach(item => {
            settingsObj[item.key] = item.value;
          });
          return settingsObj;
        }
      } catch (e) {
        console.warn("Supabase fetch settings failed, using local store:", e);
      }
    }
    const local = window.SupabaseModule.getLocalData();
    return local.settings || {};
  },

  async updateSetting(key, value) {
    if (window.SupabaseModule && window.SupabaseModule.isConfiguredWithSupabase()) {
      try {
        const client = window.SupabaseModule.getClient();
        await client.from('app_settings').upsert({
          key,
          value,
          updated_at: new Date().toISOString()
        });
      } catch (e) {
        console.warn("Supabase update setting error:", e);
      }
    }
    const local = window.SupabaseModule.getLocalData();
    if (!local.settings) local.settings = {};
    local.settings[key] = value;
    window.SupabaseModule.saveLocalData(local);
    return true;
  },

  // --------------------------------------------------------------------------
  // Member Management
  // --------------------------------------------------------------------------
  async getMembers() {
    let remoteMembers = [];
    let isRemoteOk = false;

    if (window.SupabaseModule && window.SupabaseModule.isConfiguredWithSupabase()) {
      try {
        const client = window.SupabaseModule.getClient();
        const { data, error } = await client
          .from('members')
          .select('*')
          .order('member_id', { ascending: true });

        if (!error && Array.isArray(data)) {
          remoteMembers = data;
          isRemoteOk = true;
        } else if (error) {
          console.warn("Supabase get members failed:", error.message || error);
        }
      } catch (e) {
        console.warn("Supabase get members error:", e);
      }
    }

    const local = window.SupabaseModule.getLocalData();
    const localMembers = local.members || [];

    // When remote is accessible, merge local members that aren't yet in remote
    if (isRemoteOk) {
      const remoteIdMap = new Set();
      const remoteMemberIdMap = new Set();

      remoteMembers.forEach(m => {
        if (m.id) remoteIdMap.add(String(m.id));
        if (m.member_id) remoteMemberIdMap.add(String(m.member_id));
      });

      const combined = [...remoteMembers];
      let needsLocalUpdate = false;

      localMembers.forEach(lm => {
        const hasMatch = (lm.id && remoteIdMap.has(String(lm.id))) ||
                         (lm.member_id && remoteMemberIdMap.has(String(lm.member_id)));
        if (!hasMatch) {
          combined.push(lm);
          // Try background push to Supabase
          this.tryPushMemberToSupabase(lm);
        }
      });

      // Update local cache with combined list
      local.members = combined;
      window.SupabaseModule.saveLocalData(local);
      return combined;
    }

    // Supabase offline or error: return local members directly
    return localMembers;
  },

  async getMemberById(id) {
    const members = await this.getMembers();
    return members.find(m => String(m.id) === String(id) || String(m.member_id) === String(id));
  },

  async addMember(member) {
    const memberName = (member.name || '').trim();
    if (!memberName) {
      const errText = window.I18n && window.I18n.currentLang === 'en' 
        ? "Member name is required" 
        : "সদস্যের নাম প্রদান করা আবশ্যক";
      throw new Error(errText);
    }

    // Get current members to determine next M-0001 format ID
    const members = await this.getMembers();
    let nextNum = 1;
    members.forEach(m => {
      if (m.member_id && typeof m.member_id === 'string' && m.member_id.startsWith('M-')) {
        const num = parseInt(m.member_id.replace('M-', ''), 10);
        if (!isNaN(num) && num >= nextNum) {
          nextNum = num + 1;
        }
      }
    });

    const generatedId = `M-${String(nextNum).padStart(4, '0')}`;
    const newUUID = this.generateUUID();

    const newMember = {
      id: newUUID,
      member_id: member.member_id || generatedId,
      name: memberName,
      phone: member.phone ? member.phone.trim() : '',
      address: member.address ? member.address.trim() : '',
      photo_url: member.photo_url ? member.photo_url.trim() : '',
      join_date: member.join_date || new Date().toISOString().split('T')[0],
      is_active: true
    };

    // 1. Always save to local storage immediately so data is NEVER lost
    const local = window.SupabaseModule.getLocalData();
    if (!local.members) local.members = [];
    local.members.unshift(newMember);
    window.SupabaseModule.saveLocalData(local);

    // 2. Insert to Supabase if configured
    if (window.SupabaseModule && window.SupabaseModule.isConfiguredWithSupabase()) {
      try {
        const client = window.SupabaseModule.getClient();
        const payload = {
          id: newMember.id,
          member_id: newMember.member_id,
          name: newMember.name,
          phone: newMember.phone,
          address: newMember.address,
          photo_url: newMember.photo_url,
          join_date: newMember.join_date,
          is_active: true
        };

        const { data, error } = await client.from('members').insert([payload]).select();
        if (error) {
          console.warn("Supabase insert member warning:", error.message || error);
        } else if (data && data[0]) {
          if (data[0].id) newMember.id = data[0].id;
          // Update local with remote id
          const idx = local.members.findIndex(m => m.member_id === newMember.member_id);
          if (idx !== -1) {
            local.members[idx] = { ...local.members[idx], ...data[0] };
            window.SupabaseModule.saveLocalData(local);
          }
        }
      } catch (e) {
        console.warn("Supabase add member error (saved locally):", e);
      }
    }

    return newMember;
  },

  async tryPushMemberToSupabase(member) {
    if (!window.SupabaseModule || !window.SupabaseModule.isConfiguredWithSupabase()) return;
    try {
      const client = window.SupabaseModule.getClient();
      const payload = {
        id: this.isValidUUID(member.id) ? member.id : this.generateUUID(),
        member_id: member.member_id,
        name: member.name,
        phone: member.phone || '',
        address: member.address || '',
        photo_url: member.photo_url || '',
        join_date: member.join_date || new Date().toISOString().split('T')[0],
        is_active: member.is_active !== false
      };
      await client.from('members').upsert([payload], { onConflict: 'member_id' });
    } catch (e) {
      // Background push non-blocking
    }
  },

  async updateMember(id, updates) {
    // 1. Update local immediately
    const local = window.SupabaseModule.getLocalData();
    const idx = (local.members || []).findIndex(m => String(m.id) === String(id) || String(m.member_id) === String(id));
    if (idx !== -1) {
      local.members[idx] = { ...local.members[idx], ...updates };
      window.SupabaseModule.saveLocalData(local);
    }

    // 2. Update Supabase if configured
    if (window.SupabaseModule && window.SupabaseModule.isConfiguredWithSupabase()) {
      try {
        const client = window.SupabaseModule.getClient();
        const { error } = await client
          .from('members')
          .update(updates)
          .or(`id.eq.${id},member_id.eq.${id}`);
        if (error) console.warn("Supabase update member warning:", error);
      } catch (e) {
        console.warn("Supabase update member error:", e);
      }
    }

    if (idx !== -1) return local.members[idx];
    throw new Error(window.I18n && window.I18n.currentLang === 'en' ? "Member not found" : "সদস্য খুঁজে পাওয়া যায়নি");
  },

  async deleteMember(id) {
    // 1. Delete from local immediately
    const local = window.SupabaseModule.getLocalData();
    local.members = (local.members || []).filter(m => String(m.id) !== String(id) && String(m.member_id) !== String(id));
    window.SupabaseModule.saveLocalData(local);

    // 2. Delete from Supabase if configured
    if (window.SupabaseModule && window.SupabaseModule.isConfiguredWithSupabase()) {
      try {
        const client = window.SupabaseModule.getClient();
        await client.from('members').delete().or(`id.eq.${id},member_id.eq.${id}`);
      } catch (e) {
        console.warn("Supabase delete member error:", e);
      }
    }
    return true;
  },

  // --------------------------------------------------------------------------
  // Monthly Chanda & Payment Management
  // --------------------------------------------------------------------------
  async getPayments(filterMonth = null) {
    let remotePayments = [];
    let isRemoteOk = false;

    if (window.SupabaseModule && window.SupabaseModule.isConfiguredWithSupabase()) {
      try {
        const client = window.SupabaseModule.getClient();
        let query = client.from('payments').select('*, members(name, member_id, phone)');
        if (filterMonth) {
          query = query.eq('month', filterMonth);
        }
        const { data, error } = await query.order('payment_date', { ascending: false });
        if (!error && Array.isArray(data)) {
          remotePayments = data;
          isRemoteOk = true;
        }
      } catch (e) {
        console.warn("Supabase get payments error:", e);
      }
    }

    const local = window.SupabaseModule.getLocalData();
    let localPayments = local.payments || [];

    if (isRemoteOk) {
      const remoteIds = new Set(remotePayments.map(p => String(p.id)));
      const combined = [...remotePayments];

      localPayments.forEach(lp => {
        if (!remoteIds.has(String(lp.id))) {
          if (!filterMonth || lp.month === filterMonth) {
            combined.push(lp);
          }
        }
      });
      return combined;
    }

    if (filterMonth) {
      localPayments = localPayments.filter(p => p.month === filterMonth);
    }
    return localPayments;
  },

  async recordPayment(payment) {
    if (!payment.member_id) {
      throw new Error(window.I18n && window.I18n.currentLang === 'en' ? "Please select a member" : "সদস্য নির্বাচন করা আবশ্যক");
    }
    if (!payment.month) {
      throw new Error(window.I18n && window.I18n.currentLang === 'en' ? "Please select a month" : "চাঁদার মাস নির্বাচন করুন");
    }
    if (!payment.amount || Number(payment.amount) <= 0) {
      throw new Error(window.I18n && window.I18n.currentLang === 'en' ? "Invalid amount" : "চাঁদার পরিমাণ সঠিক নয়");
    }

    const existing = await this.getPayments(payment.month);
    const isDup = existing.some(p => String(p.member_id) === String(payment.member_id) && p.status === 'paid');
    if (isDup) {
      const dupMsg = window.I18n && window.I18n.currentLang === 'en'
        ? `This member has already paid chanda for ${payment.month}`
        : `এই সদস্য ইতিমধ্যে ${payment.month} মাসের চাঁদা পরিশোধ করেছেন`;
      throw new Error(dupMsg);
    }

    const receiptNo = `REC-${payment.month.replace('-', '')}-${Math.floor(1000 + Math.random() * 9000)}`;
    const newUUID = this.generateUUID();

    const newPayment = {
      id: newUUID,
      receipt_no: receiptNo,
      member_id: payment.member_id,
      month: payment.month,
      amount: Number(payment.amount),
      status: payment.status || 'paid',
      payment_date: payment.payment_date || new Date().toISOString().split('T')[0],
      payment_method: payment.payment_method || (window.I18n && window.I18n.currentLang === 'en' ? 'Cash' : 'নগদ'),
      trx_id: payment.trx_id ? payment.trx_id.trim() : `REF-${Date.now().toString().slice(-6)}`,
      note: payment.note || '',
      confirmed_by: this.isValidUUID(payment.confirmed_by) ? payment.confirmed_by : null,
      confirmed_at: new Date().toISOString()
    };

    // 1. Save locally immediately
    const local = window.SupabaseModule.getLocalData();
    if (!local.payments) local.payments = [];
    local.payments.unshift(newPayment);
    window.SupabaseModule.saveLocalData(local);

    // 2. Insert to Supabase if configured
    if (window.SupabaseModule && window.SupabaseModule.isConfiguredWithSupabase()) {
      try {
        const client = window.SupabaseModule.getClient();
        const payload = {
          id: newPayment.id,
          receipt_no: newPayment.receipt_no,
          member_id: newPayment.member_id,
          month: newPayment.month,
          amount: newPayment.amount,
          status: newPayment.status,
          payment_date: newPayment.payment_date,
          payment_method: newPayment.payment_method,
          trx_id: newPayment.trx_id,
          note: newPayment.note,
          confirmed_by: newPayment.confirmed_by,
          confirmed_at: newPayment.confirmed_at
        };

        const { data, error } = await client.from('payments').insert([payload]).select();
        if (error) {
          console.warn("Supabase record payment warning:", error.message || error);
        } else if (data && data[0]) {
          return data[0];
        }
      } catch (e) {
        console.warn("Supabase record payment error (saved locally):", e);
      }
    }

    return newPayment;
  },

  async deletePayment(id) {
    const local = window.SupabaseModule.getLocalData();
    local.payments = (local.payments || []).filter(p => String(p.id) !== String(id));
    window.SupabaseModule.saveLocalData(local);

    if (window.SupabaseModule && window.SupabaseModule.isConfiguredWithSupabase()) {
      try {
        const client = window.SupabaseModule.getClient();
        await client.from('payments').delete().eq('id', id);
      } catch (e) {
        console.warn("Supabase delete payment error:", e);
      }
    }
    return true;
  },

  // --------------------------------------------------------------------------
  // Expense Management
  // --------------------------------------------------------------------------
  async getExpenses(filterMonth = null) {
    let remoteExpenses = [];
    let isRemoteOk = false;

    if (window.SupabaseModule && window.SupabaseModule.isConfiguredWithSupabase()) {
      try {
        const client = window.SupabaseModule.getClient();
        let query = client.from('expenses').select('*');
        if (filterMonth) {
          query = query.gte('expense_date', `${filterMonth}-01`).lte('expense_date', `${filterMonth}-31`);
        }
        const { data, error } = await query.order('expense_date', { ascending: false });
        if (!error && Array.isArray(data)) {
          remoteExpenses = data;
          isRemoteOk = true;
        }
      } catch (e) {
        console.warn("Supabase get expenses error:", e);
      }
    }

    const local = window.SupabaseModule.getLocalData();
    let localExpenses = local.expenses || [];

    if (isRemoteOk) {
      const remoteIds = new Set(remoteExpenses.map(e => String(e.id)));
      const combined = [...remoteExpenses];
      localExpenses.forEach(le => {
        if (!remoteIds.has(String(le.id))) {
          if (!filterMonth || le.expense_date.startsWith(filterMonth)) {
            combined.push(le);
          }
        }
      });
      return combined;
    }

    if (filterMonth) {
      localExpenses = localExpenses.filter(e => e.expense_date.startsWith(filterMonth));
    }
    return localExpenses;
  },

  async addExpense(expense) {
    const title = (expense.title || '').trim();
    if (!title) {
      throw new Error(window.I18n && window.I18n.currentLang === 'en' ? "Please enter expense description" : "খরচের বিবরণ/খাত উল্লেখ করুন");
    }
    if (!expense.amount || Number(expense.amount) <= 0) {
      throw new Error(window.I18n && window.I18n.currentLang === 'en' ? "Invalid expense amount" : "খরচের পরিমাণ সঠিক নয়");
    }

    const newExpense = {
      id: this.generateUUID(),
      voucher_no: `EXP-${Date.now().toString().slice(-6)}`,
      title: title,
      amount: Number(expense.amount),
      category: expense.category || (window.I18n && window.I18n.currentLang === 'en' ? 'Others' : 'অন্যান্য'),
      expense_date: expense.expense_date || new Date().toISOString().split('T')[0],
      note: expense.note ? expense.note.trim() : '',
      created_by: this.isValidUUID(expense.created_by) ? expense.created_by : null
    };

    // 1. Save locally
    const local = window.SupabaseModule.getLocalData();
    if (!local.expenses) local.expenses = [];
    local.expenses.unshift(newExpense);
    window.SupabaseModule.saveLocalData(local);

    // 2. Insert to Supabase if configured
    if (window.SupabaseModule && window.SupabaseModule.isConfiguredWithSupabase()) {
      try {
        const client = window.SupabaseModule.getClient();
        const payload = {
          id: newExpense.id,
          voucher_no: newExpense.voucher_no,
          title: newExpense.title,
          amount: newExpense.amount,
          category: newExpense.category,
          expense_date: newExpense.expense_date,
          note: newExpense.note,
          created_by: newExpense.created_by
        };
        const { data, error } = await client.from('expenses').insert([payload]).select();
        if (error) {
          console.warn("Supabase add expense warning:", error.message || error);
        } else if (data && data[0]) {
          return data[0];
        }
      } catch (e) {
        console.warn("Supabase add expense error (saved locally):", e);
      }
    }

    return newExpense;
  },

  async deleteExpense(id) {
    const local = window.SupabaseModule.getLocalData();
    local.expenses = (local.expenses || []).filter(e => String(e.id) !== String(id));
    window.SupabaseModule.saveLocalData(local);

    if (window.SupabaseModule && window.SupabaseModule.isConfiguredWithSupabase()) {
      try {
        const client = window.SupabaseModule.getClient();
        await client.from('expenses').delete().eq('id', id);
      } catch (e) {
        console.warn("Supabase delete expense error:", e);
      }
    }
    return true;
  },

  // --------------------------------------------------------------------------
  // Notices & Announcements
  // --------------------------------------------------------------------------
  async getNotices() {
    if (window.SupabaseModule && window.SupabaseModule.isConfiguredWithSupabase()) {
      try {
        const client = window.SupabaseModule.getClient();
        const { data, error } = await client
          .from('notices')
          .select('*')
          .order('is_pinned', { ascending: false })
          .order('published_date', { ascending: false });
        if (!error && Array.isArray(data) && data.length > 0) return data;
      } catch (e) {
        console.warn("Supabase get notices failed:", e);
      }
    }
    const local = window.SupabaseModule.getLocalData();
    return local.notices || [];
  },

  async addNotice(notice) {
    if (!notice.title || !notice.title.trim()) throw new Error("ঘোষণার শিরোনাম আবশ্যক");
    if (!notice.body || !notice.body.trim()) throw new Error("ঘোষণার বিস্তারিত তথ্য আবশ্যক");

    const newNotice = {
      id: this.generateUUID(),
      title: notice.title.trim(),
      body: notice.body.trim(),
      is_pinned: Boolean(notice.is_pinned),
      published_date: notice.published_date || new Date().toISOString().split('T')[0]
    };

    const local = window.SupabaseModule.getLocalData();
    if (!local.notices) local.notices = [];
    local.notices.unshift(newNotice);
    window.SupabaseModule.saveLocalData(local);

    if (window.SupabaseModule && window.SupabaseModule.isConfiguredWithSupabase()) {
      try {
        const client = window.SupabaseModule.getClient();
        await client.from('notices').insert([newNotice]);
      } catch (e) {
        console.warn("Supabase add notice error:", e);
      }
    }
    return newNotice;
  },

  async deleteNotice(id) {
    const local = window.SupabaseModule.getLocalData();
    local.notices = (local.notices || []).filter(n => String(n.id) !== String(id));
    window.SupabaseModule.saveLocalData(local);

    if (window.SupabaseModule && window.SupabaseModule.isConfiguredWithSupabase()) {
      try {
        const client = window.SupabaseModule.getClient();
        await client.from('notices').delete().eq('id', id);
      } catch (e) {
        console.warn("Supabase delete notice error:", e);
      }
    }
    return true;
  },

  // --------------------------------------------------------------------------
  // Projects Management
  // --------------------------------------------------------------------------
  async getProjects() {
    if (window.SupabaseModule && window.SupabaseModule.isConfiguredWithSupabase()) {
      try {
        const client = window.SupabaseModule.getClient();
        const { data, error } = await client.from('projects').select('*').order('created_at', { ascending: false });
        if (!error && Array.isArray(data) && data.length > 0) return data;
      } catch (e) {
        console.warn("Supabase get projects failed:", e);
      }
    }
    const local = window.SupabaseModule.getLocalData();
    return local.projects || [];
  },

  async addProject(project) {
    if (!project.name || !project.name.trim()) throw new Error("কাজের নাম আবশ্যক");

    const newProject = {
      id: this.generateUUID(),
      name: project.name.trim(),
      description: project.description ? project.description.trim() : '',
      estimated_cost: Number(project.estimated_cost) || 0,
      collected_amount: Number(project.collected_amount) || 0,
      spent_amount: Number(project.spent_amount) || 0,
      status: project.status || 'পরিকল্পনাধীন'
    };

    const local = window.SupabaseModule.getLocalData();
    if (!local.projects) local.projects = [];
    local.projects.push(newProject);
    window.SupabaseModule.saveLocalData(local);

    if (window.SupabaseModule && window.SupabaseModule.isConfiguredWithSupabase()) {
      try {
        const client = window.SupabaseModule.getClient();
        await client.from('projects').insert([newProject]);
      } catch (e) {
        console.warn("Supabase add project error:", e);
      }
    }
    return newProject;
  },

  // --------------------------------------------------------------------------
  // Financial Dashboard & Monthly Calculations
  // --------------------------------------------------------------------------
  async getDashboardMetrics(selectedMonth = null) {
    const currentMonth = selectedMonth || new Date().toISOString().slice(0, 7);
    const currentYear = currentMonth.slice(0, 4);

    const [members, payments, expenses, settings] = await Promise.all([
      this.getMembers(),
      this.getPayments(),
      this.getExpenses(),
      this.getSettings()
    ]);

    const defaultAmount = settings?.chanda_config?.default_amount || 100;
    const totalMembers = members.filter(m => m.is_active !== false).length;

    // Filter confirmed payments
    const confirmedPayments = payments.filter(p => p.status === 'paid');

    // This Month's collections
    const thisMonthPayments = confirmedPayments.filter(p => p.month === currentMonth);
    const thisMonthCollection = thisMonthPayments.reduce((acc, p) => acc + Number(p.amount), 0);

    // Paid members this month
    const paidMemberIds = new Set(thisMonthPayments.map(p => String(p.member_id)));
    const paidMembersCount = members.filter(m => paidMemberIds.has(String(m.id)) || paidMemberIds.has(String(m.member_id))).length;
    const unpaidMembersCount = Math.max(0, totalMembers - paidMembersCount);

    // This Month's expenses
    const thisMonthExpensesList = expenses.filter(e => e.expense_date && e.expense_date.startsWith(currentMonth));
    const thisMonthExpense = thisMonthExpensesList.reduce((acc, e) => acc + Number(e.amount), 0);

    // Expected collection for this month
    const expectedMonthlyCollection = totalMembers * defaultAmount;
    const pendingMonthlyDues = Math.max(0, expectedMonthlyCollection - thisMonthCollection);

    // Yearly calculations
    const yearlyPayments = confirmedPayments.filter(p => p.month && p.month.startsWith(currentYear));
    const totalYearlyCollection = yearlyPayments.reduce((acc, p) => acc + Number(p.amount), 0);

    const yearlyExpenses = expenses.filter(e => e.expense_date && e.expense_date.startsWith(currentYear));
    const totalYearlyExpense = yearlyExpenses.reduce((acc, e) => acc + Number(e.amount), 0);

    // All-time Grand Totals & Net Balance
    const totalAllTimeCollection = confirmedPayments.reduce((acc, p) => acc + Number(p.amount), 0);
    const totalAllTimeExpense = expenses.reduce((acc, e) => acc + Number(e.amount), 0);
    const currentBalance = totalAllTimeCollection - totalAllTimeExpense;

    return {
      currentMonth,
      currentYear,
      totalMembers,
      defaultAmount,
      thisMonthCollection,
      thisMonthExpense,
      paidMembersCount,
      unpaidMembersCount,
      expectedMonthlyCollection,
      pendingMonthlyDues,
      totalYearlyCollection,
      totalYearlyExpense,
      currentBalance,
      recentPayments: payments.slice(-5).reverse(),
      recentExpenses: expenses.slice(-5).reverse()
    };
  },

  // --------------------------------------------------------------------------
  // Supabase Setup SQL Script Generator (Permissive & Error-free)
  // --------------------------------------------------------------------------
  getSupabaseSetupSQL() {
    return `-- ==============================================================================
-- আলী আজগর সিদ্দিকিয়া মাদ্রাসা (Ali Azgar Siddiqia Madrasa)
-- Supabase Cloud Database Complete Schema & Open Permissions Setup
-- ==============================================================================

-- 1. Members Table
CREATE TABLE IF NOT EXISTS public.members (
    id TEXT PRIMARY KEY,
    member_id TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    phone TEXT DEFAULT '',
    photo_url TEXT DEFAULT '',
    address TEXT DEFAULT '',
    join_date DATE DEFAULT CURRENT_DATE,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now())
);

-- 2. Payments Table
CREATE TABLE IF NOT EXISTS public.payments (
    id TEXT PRIMARY KEY,
    receipt_no TEXT UNIQUE NOT NULL,
    member_id TEXT NOT NULL,
    month TEXT NOT NULL,
    amount NUMERIC(10,2) NOT NULL,
    status TEXT DEFAULT 'paid',
    payment_date DATE DEFAULT CURRENT_DATE,
    payment_method TEXT DEFAULT 'নগদ',
    trx_id TEXT,
    note TEXT,
    confirmed_by TEXT,
    confirmed_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now())
);

-- 3. Expenses Table
CREATE TABLE IF NOT EXISTS public.expenses (
    id TEXT PRIMARY KEY,
    voucher_no TEXT UNIQUE NOT NULL,
    title TEXT NOT NULL,
    amount NUMERIC(10,2) NOT NULL,
    category TEXT DEFAULT 'সাধারণ',
    expense_date DATE DEFAULT CURRENT_DATE,
    note TEXT,
    created_by TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now())
);

-- 4. Notices Table
CREATE TABLE IF NOT EXISTS public.notices (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    body TEXT NOT NULL,
    is_pinned BOOLEAN DEFAULT false,
    published_date DATE DEFAULT CURRENT_DATE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now())
);

-- 5. Projects Table
CREATE TABLE IF NOT EXISTS public.projects (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT,
    estimated_cost NUMERIC(12,2) DEFAULT 0,
    collected_amount NUMERIC(12,2) DEFAULT 0,
    spent_amount NUMERIC(12,2) DEFAULT 0,
    status TEXT DEFAULT 'পরিকল্পনাধীন',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now())
);

-- 6. Settings Table
CREATE TABLE IF NOT EXISTS public.app_settings (
    key TEXT PRIMARY KEY,
    value JSONB NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now())
);

-- 7. Disable RLS or Enable Public Access for seamless mobile app connection
ALTER TABLE public.members DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.payments DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.expenses DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.notices DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.projects DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.app_settings DISABLE ROW LEVEL SECURITY;

-- Grant full access to anon and authenticated roles
GRANT ALL ON TABLE public.members TO anon, authenticated, service_role;
GRANT ALL ON TABLE public.payments TO anon, authenticated, service_role;
GRANT ALL ON TABLE public.expenses TO anon, authenticated, service_role;
GRANT ALL ON TABLE public.notices TO anon, authenticated, service_role;
GRANT ALL ON TABLE public.projects TO anon, authenticated, service_role;
GRANT ALL ON TABLE public.app_settings TO anon, authenticated, service_role;
`;
  }
};

window.DB = DB;
