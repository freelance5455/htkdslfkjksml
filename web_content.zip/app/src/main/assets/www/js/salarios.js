
/* ============================================
   SGFE - GESTÃO DE SALÁRIOS
   Funcionários, folhas salariais e pagamentos
============================================ */

(function () {
    "use strict";

    const DB = () => window.SGFE_DB;

    const MESES = [
        "Janeiro", "Fevereiro", "Março", "Abril",
        "Maio", "Junho", "Julho", "Agosto",
        "Setembro", "Outubro", "Novembro", "Dezembro"
    ];

    let funcionarios = [];
    let salarios = [];
    let formularioFuncionarioAberto = false;
    let funcionarioEmEdicao = null;

    const moeda = valor =>
        Number(valor || 0).toLocaleString("pt-AO") + " Kz";

    const numero = valor => {
        const n = Number(valor);
        return Number.isFinite(n) ? n : 0;
    };

    const escapar = valor =>
        String(valor ?? "").replace(/[&<>"']/g, c => ({
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&#039;"
        })[c]);

    const dataAtual = () =>
        new Date().toISOString().slice(0, 10);

    function notificar(mensagem) {
        alert(mensagem);
    }

    async function carregarDados() {
        funcionarios = await DB().listar("funcionarios");
        salarios = await DB().listar("salarios");
    }

    function pagamentosValidos(salario) {
        return (salario.pagamentos || []).filter(
            p => p.estado !== "anulado"
        );
    }

    function totalPago(salario) {
        return pagamentosValidos(salario).reduce(
            (total, p) => total + numero(p.valor), 0
        );
    }

    function saldoPendente(salario) {
        return Math.max(
            0,
            numero(salario.salarioLiquido) - totalPago(salario)
        );
    }

    function atualizarEstado(salario) {
        const pago = totalPago(salario);
        const previsto = numero(salario.salarioLiquido);

        if (pago <= 0) {
            salario.estado = "pendente";
        } else if (pago >= previsto) {
            salario.estado = "pago";
        } else {
            salario.estado = "parcial";
        }

        return salario.estado;
    }

    function estadoHTML(estado) {
        const nomes = {
            pago: "Pago",
            parcial: "Parcial",
            pendente: "Pendente"
        };

        return `<span class="estado-entrada estado-${estado}">
            ${nomes[estado] || estado}
        </span>`;
    }

    async function registarHistorico(tipo, descricao, valor, motivo = "") {
        await DB().registarHistorico({
            tipo,
            modulo: "Salários",
            descricao,
            valor,
            motivo
        });
    }

    /* ========================================
       FUNCIONÁRIOS
    ======================================== */

    async function guardarFuncionario(evento) {
        evento.preventDefault();

        const nome = document.getElementById("salNomeFuncionario").value.trim();
        const cargo = document.getElementById("salCargoFuncionario").value.trim();
        const contacto = document.getElementById("salContactoFuncionario").value.trim();
        const salarioBase = numero(document.getElementById("salBaseFuncionario").value);

        if (!nome || !cargo || salarioBase <= 0) {
            notificar("Preencha o nome, cargo e salário-base correctamente.");
            return;
        }

        const dados = {
            nome,
            cargo,
            contacto,
            salarioBase,
            estado: "ativo"
        };

        try {
            if (funcionarioEmEdicao) {
                const anterior = await DB().obter(
                    "funcionarios",
                    funcionarioEmEdicao
                );

                await DB().guardar("funcionarios", {
                    ...anterior,
                    ...dados,
                    estado: anterior.estado || "ativo"
                });

                await registarHistorico(
                    "Edição",
                    "Dados do funcionário " + nome + " actualizados.",
                    salarioBase
                );

            } else {
                await DB().guardar("funcionarios", dados);

                await registarHistorico(
                    "Registo",
                    "Novo funcionário registado: " + nome,
                    salarioBase
                );
            }

            funcionarioEmEdicao = null;
            formularioFuncionarioAberto = false;

            await carregarDados();
            abrir();

        } catch (erro) {
            console.error(erro);
            notificar("Não foi possível guardar o funcionário.");
        }
    }

    async function editarFuncionario(id) {
        const funcionario = await DB().obter("funcionarios", id);

        if (!funcionario) return;

        funcionarioEmEdicao = id;
        formularioFuncionarioAberto = true;

        abrir();

        document.getElementById("salNomeFuncionario").value = funcionario.nome || "";
        document.getElementById("salCargoFuncionario").value = funcionario.cargo || "";
        document.getElementById("salContactoFuncionario").value = funcionario.contacto || "";
        document.getElementById("salBaseFuncionario").value = funcionario.salarioBase || 0;

        document.getElementById("salNomeFuncionario").focus();
    }

    async function alterarEstadoFuncionario(id) {
        const funcionario = await DB().obter("funcionarios", id);

        if (!funcionario) return;

        const novoEstado =
            funcionario.estado === "inativo" ? "ativo" : "inativo";

        if (!confirm(
            `Deseja ${novoEstado === "ativo" ? "activar" : "desactivar"} ${funcionario.nome}?`
        )) return;

        await DB().guardar("funcionarios", {
            ...funcionario,
            estado: novoEstado
        });

        await registarHistorico(
            "Alteração",
            `Funcionário ${funcionario.nome}: estado alterado para ${novoEstado}.`
        );

        await carregarDados();
        abrir();
    }

    /* ========================================
       FOLHAS SALARIAIS
    ======================================== */

    async function gerarSalario(evento) {
        evento.preventDefault();

        const funcionarioId = document.getElementById("salFuncionario").value;
        const mes = Number(document.getElementById("salMes").value);
        const ano = Number(document.getElementById("salAno").value);

        const base = numero(document.getElementById("salBase").value);
        const subsidios = numero(document.getElementById("salSubsidios").value);
        const descontos = numero(document.getElementById("salDescontos").value);

        const funcionario = funcionarios.find(
            f => f.id === funcionarioId
        );

        if (!funcionario) {
            notificar("Seleccione um funcionário válido.");
            return;
        }

        if (base <= 0 || mes < 1 || mes > 12 || ano < 2000) {
            notificar("Verifique os valores da folha salarial.");
            return;
        }

        const liquido = base + subsidios - descontos;

        if (liquido <= 0) {
            notificar("O salário líquido deve ser superior a zero.");
            return;
        }

        const duplicado = salarios.some(s =>
            s.funcionarioId === funcionarioId &&
            Number(s.mes) === mes &&
            Number(s.ano) === ano
        );

        if (duplicado) {
            notificar("Já existe uma folha salarial para este funcionário neste mês e ano.");
            return;
        }

        const folha = {
            funcionarioId,
            funcionarioNome: funcionario.nome,
            cargo: funcionario.cargo,
            mes,
            ano,
            salarioBase: base,
            subsidios,
            descontos,
            salarioLiquido: liquido,
            pagamentos: [],
            estado: "pendente",
            data: dataAtual()
        };

        try {
            await DB().guardar("salarios", folha);

            await registarHistorico(
                "Registo",
                `Folha salarial criada para ${funcionario.nome} - ${MESES[mes - 1]} de ${ano}.`,
                liquido
            );

            await carregarDados();
            abrir();

            notificar("Folha salarial criada com sucesso.");

        } catch (erro) {
            console.error(erro);
            notificar("Não foi possível criar a folha salarial.");
        }
    }

    /* ========================================
       PAGAMENTOS
    ======================================== */

    async function registarPagamento(id) {
        const salario = await DB().obter("salarios", id);

        if (!salario) return;

        const saldo = saldoPendente(salario);

        if (saldo <= 0) {
            notificar("Esta folha salarial já está totalmente paga.");
            return;
        }

        const resposta = prompt(
            `Funcionário: ${salario.funcionarioNome}\n` +
            `Salário previsto: ${moeda(salario.salarioLiquido)}\n` +
            `Total pago: ${moeda(totalPago(salario))}\n` +
            `Saldo pendente: ${moeda(saldo)}\n\n` +
            "Introduza o valor a pagar:"
        );

        if (resposta === null) return;

        const valor = Number(resposta.replace(",", "."));

        if (!Number.isFinite(valor) || valor <= 0) {
            notificar("Introduza um valor válido.");
            return;
        }

        if (valor > saldo) {
            notificar("O pagamento não pode ultrapassar o saldo pendente.");
            return;
        }

        const metodo = prompt(
            "Método de pagamento:\n" +
            "Dinheiro, Transferência ou Outro"
        );

        if (metodo === null || !metodo.trim()) return;

        const pagamento = {
            id: DB().gerarID(),
            valor,
            data: dataAtual(),
            metodo: metodo.trim(),
            estado: "confirmado"
        };

        salario.pagamentos = salario.pagamentos || [];
        salario.pagamentos.push(pagamento);

        atualizarEstado(salario);

        try {
            await DB().guardar("salarios", salario);

            await registarHistorico(
                "Pagamento",
                `Pagamento de salário a ${salario.funcionarioNome} - ${MESES[salario.mes - 1]}/${salario.ano}.`,
                valor
            );

            await carregarDados();
            abrir();

            notificar("Pagamento registado com sucesso.");

        } catch (erro) {
            console.error(erro);
            notificar("Não foi possível registar o pagamento.");
        }
    }

    async function anularPagamento(salarioId, pagamentoId) {
        const salario = await DB().obter("salarios", salarioId);

        if (!salario) return;

        const pagamento = (salario.pagamentos || []).find(
            p => p.id === pagamentoId
        );

        if (!pagamento || pagamento.estado === "anulado") return;

        const motivo = prompt(
            "Indique o motivo da anulação deste pagamento:"
        );

        if (motivo === null || !motivo.trim()) {
            notificar("É necessário indicar o motivo da anulação.");
            return;
        }

        if (!confirm(
            `Confirma a anulação do pagamento de ${moeda(pagamento.valor)}?`
        )) return;

        pagamento.estado = "anulado";
        pagamento.motivoAnulacao = motivo.trim();
        pagamento.dataAnulacao = new Date().toISOString();

        atualizarEstado(salario);

        try {
            await DB().guardar("salarios", salario);

            await registarHistorico(
                "Anulação",
                `Pagamento de ${salario.funcionarioNome} - ${MESES[salario.mes - 1]}/${salario.ano} anulado.`,
                pagamento.valor,
                motivo.trim()
            );

            await carregarDados();
            consultarSalario(salarioId);

            notificar("Pagamento anulado. O registo foi preservado no histórico.");

        } catch (erro) {
            console.error(erro);
            notificar("Não foi possível anular o pagamento.");
        }
    }

    /* ========================================
       CONSULTA DE FOLHA
    ======================================== */

    async function consultarSalario(id) {
        const salario = await DB().obter("salarios", id);

        if (!salario) return;

        const pagamentos = (salario.pagamentos || []).map(p => `
            <tr>
                <td>${escapar(p.data || "")}</td>
                <td>${moeda(p.valor)}</td>
                <td>${escapar(p.metodo || "—")}</td>
                <td>
                    ${p.estado === "anulado"
                        ? '<span class="estado-entrada estado-pendente">Anulado</span>'
                        : '<span class="estado-entrada estado-pago">Confirmado</span>'}
                </td>
                <td>
                    ${p.estado === "anulado"
                        ? escapar(p.motivoAnulacao || "")
                        : `<button class="botao-secundario sal-anular-pagamento"
                            data-pagamento="${escapar(p.id)}"
                            data-salario="${escapar(id)}">
                            Anular
                           </button>`}
                </td>
            </tr>
        `).join("");

        const conteudo = `
            <div class="painel-formulario">
                <div class="cabecalho-tabela">
                    <h3>Detalhes da folha salarial</h3>
                    <button class="botao-secundario" id="salVoltar">
                        Voltar
                    </button>
                </div>

                <p><strong>Funcionário:</strong> ${escapar(salario.funcionarioNome)}</p>
                <p><strong>Cargo:</strong> ${escapar(salario.cargo)}</p>
                <p><strong>Período:</strong> ${MESES[salario.mes - 1]} de ${salario.ano}</p>

                <div class="entradas-indicadores">
                    <div class="cartao-indicador">
                        <span>Salário líquido</span>
                        <strong>${moeda(salario.salarioLiquido)}</strong>
                    </div>
                    <div class="cartao-indicador">
                        <span>Total pago</span>
                        <strong>${moeda(totalPago(salario))}</strong>
                    </div>
                    <div class="cartao-indicador">
                        <span>Saldo pendente</span>
                        <strong>${moeda(saldoPendente(salario))}</strong>
                    </div>
                </div>

                <h3>Composição salarial</h3>
                <p>Salário-base: ${moeda(salario.salarioBase)}</p>
                <p>Subsídios: ${moeda(salario.subsidios)}</p>
                <p>Descontos: ${moeda(salario.descontos)}</p>

                <h3>Histórico de pagamentos</h3>
                <div class="tabela-deslizante">
                    <table>
                        <thead>
                            <tr>
                                <th>Data</th>
                                <th>Valor</th>
                                <th>Método</th>
                                <th>Estado</th>
                                <th>Acção / Motivo</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${pagamentos || '<tr><td colspan="5">Ainda não existem pagamentos.</td></tr>'}
                        </tbody>
                    </table>
                </div>
            </div>
        `;

        const area = document.getElementById("conteudoModulo");
        area.innerHTML = conteudo;

        document.getElementById("salVoltar").addEventListener("click", abrir);

        area.querySelectorAll(".sal-anular-pagamento").forEach(botao => {
            botao.addEventListener("click", () =>
                anularPagamento(
                    botao.dataset.salario,
                    botao.dataset.pagamento
                )
            );
        });
    }

    /* ========================================
       INTERFACE
    ======================================== */

    function renderizarFuncionarios() {
        const ativos = funcionarios.filter(
            f => f.estado !== "inativo"
        );

        return `
            <div class="painel-tabela">
                <div class="cabecalho-tabela">
                    <h3>Funcionários registados</h3>
                </div>

                <div class="tabela-deslizante">
                    <table>
                        <thead>
                            <tr>
                                <th>Funcionário</th>
                                <th>Cargo</th>
                                <th>Salário-base</th>
                                <th>Estado</th>
                                <th>Acções</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${funcionarios.map(f => `
                                <tr>
                                    <td>${escapar(f.nome)}</td>
                                    <td>${escapar(f.cargo)}</td>
                                    <td>${moeda(f.salarioBase)}</td>
                                    <td>${f.estado === "inativo" ? "Inactivo" : "Activo"}</td>
                                    <td>
                                        <button class="botao-secundario sal-editar-funcionario"
                                            data-id="${escapar(f.id)}">
                                            Editar
                                        </button>
                                        <button class="botao-secundario sal-estado-funcionario"
                                            data-id="${escapar(f.id)}">
                                            ${f.estado === "inativo" ? "Activar" : "Desactivar"}
                                        </button>
                                    </td>
                                </tr>
                            `).join("") || '<tr><td colspan="5">Nenhum funcionário registado.</td></tr>'}
                        </tbody>
                    </table>
                </div>
            </div>
        `;
    }

    function renderizarSalarios() {
        return `
            <div class="painel-tabela">
                <div class="cabecalho-tabela">
                    <h3>Folhas salariais</h3>
                </div>

                <div class="tabela-deslizante">
                    <table>
                        <thead>
                            <tr>
                                <th>Funcionário</th>
                                <th>Período</th>
                                <th>Salário líquido</th>
                                <th>Total pago</th>
                                <th>Pendente</th>
                                <th>Estado</th>
                                <th>Acções</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${[...salarios].sort((a, b) =>
                                Number(b.ano) - Number(a.ano) ||
                                Number(b.mes) - Number(a.mes)
                            ).map(s => `
                                <tr>
                                    <td>${escapar(s.funcionarioNome)}</td>
                                    <td>${MESES[s.mes - 1]} / ${s.ano}</td>
                                    <td>${moeda(s.salarioLiquido)}</td>
                                    <td>${moeda(totalPago(s))}</td>
                                    <td>${moeda(saldoPendente(s))}</td>
                                    <td>${estadoHTML(atualizarEstado(s))}</td>
                                    <td>
                                        <button class="botao-secundario sal-consultar"
                                            data-id="${escapar(s.id)}">
                                            Consultar
                                        </button>
                                        ${saldoPendente(s) > 0 ? `
                                            <button class="botao-principal sal-pagar"
                                                data-id="${escapar(s.id)}">
                                                Registar pagamento
                                            </button>
                                        ` : ""}
                                    </td>
                                </tr>
                            `).join("") || '<tr><td colspan="7">Nenhuma folha salarial criada.</td></tr>'}
                        </tbody>
                    </table>
                </div>
            </div>
        `;
    }

    async function abrir() {
        await carregarDados();

        const area = document.getElementById("conteudoModulo");

        const totalPrevisto = salarios.reduce(
            (soma, s) => soma + numero(s.salarioLiquido), 0
        );

        const totalPagoGeral = salarios.reduce(
            (soma, s) => soma + totalPago(s), 0
        );

        const totalPendente = salarios.reduce(
            (soma, s) => soma + saldoPendente(s), 0
        );

        const ativos = funcionarios.filter(
            f => f.estado !== "inativo"
        ).length;

        const mesAtual = new Date().getMonth() + 1;
        const anoAtual = new Date().getFullYear();

        const opcoesFuncionarios = funcionarios
            .filter(f => f.estado !== "inativo")
            .map(f => `
                <option value="${escapar(f.id)}">
                    ${escapar(f.nome)} - ${escapar(f.cargo)}
                </option>
            `).join("");

        area.innerHTML = `
            <div class="entradas-modulo">

                <div class="cabecalho-modulo">
                    <div>
                        <h2>Gestão de Salários</h2>
                        <p>Administração de funcionários, folhas salariais e pagamentos.</p>
                    </div>
                </div>

                <div class="entradas-indicadores">
                    <div class="cartao-indicador">
                        <span>Funcionários activos</span>
                        <strong>${ativos}</strong>
                    </div>
                    <div class="cartao-indicador">
                        <span>Total previsto</span>
                        <strong>${moeda(totalPrevisto)}</strong>
                    </div>
                    <div class="cartao-indicador">
                        <span>Total pago</span>
                        <strong>${moeda(totalPagoGeral)}</strong>
                    </div>
                    <div class="cartao-indicador">
                        <span>Total pendente</span>
                        <strong>${moeda(totalPendente)}</strong>
                    </div>
                </div>

                <div class="entradas-acoes">
                    <button class="botao-principal" id="salAbrirFuncionario">
                        + Registar funcionário
                    </button>
                    <button class="botao-destaque" id="salAbrirFolha">
                        + Criar folha salarial
                    </button>
                </div>

                ${formularioFuncionarioAberto ? `
                    <div class="painel-formulario">
                        <h3>${funcionarioEmEdicao ? "Editar funcionário" : "Novo funcionário"}</h3>

                        <form id="salFormFuncionario">
                            <div class="formulario-grelha">
                                <div>
                                    <label>Nome completo</label>
                                    <input id="salNomeFuncionario" required>
                                </div>
                                <div>
                                    <label>Cargo / Função</label>
                                    <input id="salCargoFuncionario" required>
                                </div>
                                <div>
                                    <label>Contacto</label>
                                    <input id="salContactoFuncionario">
                                </div>
                                <div>
                                    <label>Salário-base (Kz)</label>
                                    <input id="salBaseFuncionario" type="number" min="1" step="0.01" required>
                                </div>
                            </div>

                            <div class="botoes-formulario">
                                <button class="botao-principal" type="submit">Guardar funcionário</button>
                                <button class="botao-secundario" type="button" id="salCancelarFuncionario">Cancelar</button>
                            </div>
                        </form>
                    </div>
                ` : ""}

                <div class="painel-formulario" id="salPainelFolha" hidden>
                    <h3>Criar folha salarial</h3>

                    <form id="salFormFolha">
                        <div class="formulario-grelha">
                            <div>
                                <label>Funcionário</label>
                                <select id="salFuncionario" required>
                                    <option value="">Seleccione o funcionário</option>
                                    ${opcoesFuncionarios}
                                </select>
                            </div>
                            <div>
                                <label>Mês</label>
                                <select id="salMes" required>
                                    ${MESES.map((m, i) => `
                                        <option value="${i + 1}" ${mesAtual === i + 1 ? "selected" : ""}>${m}</option>
                                    `).join("")}
                                </select>
                            </div>
                            <div>
                                <label>Ano</label>
                                <input id="salAno" type="number" min="2000" value="${anoAtual}" required>
                            </div>
                            <div>
                                <label>Salário-base (Kz)</label>
                                <input id="salBase" type="number" min="1" step="0.01" required>
                            </div>
                            <div>
                                <label>Subsídios (Kz)</label>
                                <input id="salSubsidios" type="number" min="0" step="0.01" value="0">
                            </div>
                            <div>
                                <label>Descontos (Kz)</label>
                                <input id="salDescontos" type="number" min="0" step="0.01" value="0">
                            </div>
                        </div>

                        <div class="informacao-saldo" id="salResumoLiquido">
                            Salário líquido: 0 Kz
                        </div>

                        <div class="botoes-formulario">
                            <button class="botao-principal" type="submit">Criar folha salarial</button>
                            <button class="botao-secundario" type="button" id="salCancelarFolha">Cancelar</button>
                        </div>
                    </form>
                </div>

                ${renderizarFuncionarios()}
                ${renderizarSalarios()}

            </div>
        `;

        ligarEventos();
    }

    /* ========================================
       EVENTOS
    ======================================== */

    function ligarEventos() {
        const area = document.getElementById("conteudoModulo");

        document.getElementById("salAbrirFuncionario")
            .addEventListener("click", () => {
                funcionarioEmEdicao = null;
                formularioFuncionarioAberto = true;
                abrir();
            });

        document.getElementById("salAbrirFolha")
            .addEventListener("click", () => {
                const painel = document.getElementById("salPainelFolha");
                painel.hidden = !painel.hidden;
            });

        const formFuncionario = document.getElementById("salFormFuncionario");

        if (formFuncionario) {
            formFuncionario.addEventListener("submit", guardarFuncionario);

            document.getElementById("salCancelarFuncionario")
                .addEventListener("click", () => {
                    formularioFuncionarioAberto = false;
                    funcionarioEmEdicao = null;
                    abrir();
                });
        }

        const formFolha = document.getElementById("salFormFolha");

        if (formFolha) {
            formFolha.addEventListener("submit", gerarSalario);

            document.getElementById("salCancelarFolha")
                .addEventListener("click", () => {
                    document.getElementById("salPainelFolha").hidden = true;
                });

            const selectFuncionario = document.getElementById("salFuncionario");

            selectFuncionario.addEventListener("change", () => {
                const funcionario = funcionarios.find(
                    f => f.id === selectFuncionario.value
                );

                document.getElementById("salBase").value =
                    funcionario ? funcionario.salarioBase : "";
            });

            const campos = [
                "salBase",
                "salSubsidios",
                "salDescontos"
            ];

            campos.forEach(id => {
                document.getElementById(id).addEventListener(
                    "input",
                    atualizarResumoLiquido
                );
            });
        }

        area.querySelectorAll(".sal-editar-funcionario").forEach(botao => {
            botao.addEventListener("click", () =>
                editarFuncionario(botao.dataset.id)
            );
        });

        area.querySelectorAll(".sal-estado-funcionario").forEach(botao => {
            botao.addEventListener("click", () =>
                alterarEstadoFuncionario(botao.dataset.id)
            );
        });

        area.querySelectorAll(".sal-consultar").forEach(botao => {
            botao.addEventListener("click", () =>
                consultarSalario(botao.dataset.id)
            );
        });

        area.querySelectorAll(".sal-pagar").forEach(botao => {
            botao.addEventListener("click", () =>
                registarPagamento(botao.dataset.id)
            );
        });
    }

    function atualizarResumoLiquido() {
        const base = numero(document.getElementById("salBase").value);
        const subsidios = numero(document.getElementById("salSubsidios").value);
        const descontos = numero(document.getElementById("salDescontos").value);

        const liquido = base + subsidios - descontos;

        document.getElementById("salResumoLiquido").textContent =
            "Salário líquido: " + moeda(liquido);
    }

    /* ========================================
       ACTUALIZAÇÃO E DISPONIBILIZAÇÃO
    ======================================== */

    async function atualizar() {
        await carregarDados();
        await abrir();
    }

    window.SGFE_SALARIOS = Object.freeze({
        abrir,
        atualizar
    });

})();
