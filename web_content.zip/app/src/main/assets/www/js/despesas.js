
(function () {
    "use strict";

    const COLECAO = "despesas";

    function verificarBanco() {
        if (!window.SGFE_DB) {
            throw new Error("O armazenamento do SGFE não está disponível.");
        }
    }

    function formatarValor(valor) {
        return Number(valor || 0).toLocaleString("pt-AO") + " Kz";
    }

    function escapar(texto) {
        return String(texto ?? "").replace(/[&<>"']/g, function (c) {
            return {
                "&": "&amp;",
                "<": "&lt;",
                ">": "&gt;",
                '"': "&quot;",
                "'": "&#039;"
            }[c];
        });
    }

    function notificar(mensagem) {
        alert(mensagem);
    }

    function dataHoje() {
        return new Date().toISOString().slice(0, 10);
    }

    function pagamentosDaDespesa(despesa) {
        return Array.isArray(despesa.pagamentos)
            ? despesa.pagamentos
            : [];
    }

    function totalPago(despesa) {
        const pagamentos = pagamentosDaDespesa(despesa);

        if (pagamentos.length) {
            return pagamentos
                .filter(p => p.estado !== "anulado")
                .reduce((total, p) => total + Number(p.valor || 0), 0);
        }

        return Number(despesa.valorPago || 0);
    }

    function saldoDespesa(despesa) {
        return Math.max(
            0,
            Number(despesa.valor || 0) - totalPago(despesa)
        );
    }

    function estadoDespesa(despesa) {
        if (despesa.estado === "anulada") return "Anulada";

        const pago = totalPago(despesa);
        const saldo = saldoDespesa(despesa);

        if (saldo <= 0) return "Pago";
        if (pago > 0) return "Parcial";

        return "Pendente";
    }

    function classeEstado(estado) {
        const classes = {
            Pago: "estado-pago",
            Parcial: "estado-parcial",
            Pendente: "estado-pendente",
            Anulada: "estado-pendente"
        };

        return classes[estado] || "estado-pendente";
    }

    async function listarDespesas() {
        verificarBanco();
        return await window.SGFE_DB.listar(COLECAO);
    }

    async function obterDespesa(id) {
        verificarBanco();
        return await window.SGFE_DB.obter(COLECAO, id);
    }

    // REGISTAR DESPESA

    async function registarDespesa(dados) {
        verificarBanco();

        if (!dados || !dados.descricao || !dados.categoria) {
            throw new Error(
                "Informe a descrição e a categoria da despesa."
            );
        }

        const valor = Number(dados.valor);

        if (!Number.isFinite(valor) || valor <= 0) {
            throw new Error(
                "O valor da despesa deve ser superior a zero."
            );
        }

        const despesa = {
            id: window.SGFE_DB.gerarID(),
            descricao: String(dados.descricao).trim(),
            categoria: String(dados.categoria).trim(),
            tipo: dados.tipo || "variavel",
            servico: dados.servico || "",
            fornecedor: dados.fornecedor || "",
            valor,
            valorPago: 0,
            pagamentos: [],
            data: dados.data || dataHoje(),
            vencimento: dados.vencimento || "",
            observacao: dados.observacao || "",
            estado: "pendente",
            criadoEm: new Date().toISOString()
        };

        await window.SGFE_DB.guardar(COLECAO, despesa);

        await window.SGFE_DB.registarHistorico({
            operacao: "criar",
            modulo: "despesas",
            descricao: "Nova despesa: " + despesa.descricao,
            valor,
            data: new Date().toISOString()
        });

        return despesa;
    }

    // EDITAR DESPESA

    async function atualizarDespesa(id, dados) {
        verificarBanco();

        const despesa = await obterDespesa(id);

        if (!despesa) {
            throw new Error("Despesa não encontrada.");
        }

        if (despesa.estado === "anulada") {
            throw new Error("Não é possível editar uma despesa anulada.");
        }

        if (!dados.descricao || !dados.categoria) {
            throw new Error(
                "Informe a descrição e a categoria da despesa."
            );
        }

        const valor = Number(dados.valor);
        const pago = totalPago(despesa);

        if (!Number.isFinite(valor) || valor <= 0) {
            throw new Error("O valor deve ser superior a zero.");
        }

        if (valor < pago) {
            throw new Error(
                "O valor da despesa não pode ser inferior ao total já pago: " +
                formatarValor(pago)
            );
        }

        despesa.descricao = String(dados.descricao).trim();
        despesa.categoria = String(dados.categoria).trim();
        despesa.tipo = dados.tipo || "variavel";
        despesa.servico = dados.servico || "";
        despesa.fornecedor = dados.fornecedor || "";
        despesa.valor = valor;
        despesa.data = dados.data || despesa.data;
        despesa.vencimento = dados.vencimento || "";
        despesa.observacao = dados.observacao || "";

        despesa.valorPago = pago;
        despesa.estado = pago >= valor
            ? "pago"
            : pago > 0 ? "parcial" : "pendente";

        despesa.atualizadoEm = new Date().toISOString();

        await window.SGFE_DB.guardar(COLECAO, despesa);

        await window.SGFE_DB.registarHistorico({
            operacao: "editar",
            modulo: "despesas",
            descricao: "Despesa actualizada: " + despesa.descricao,
            valor,
            data: new Date().toISOString()
        });

        return despesa;
    }

    // REGISTAR PAGAMENTO

    async function pagarDespesa(dados) {
        verificarBanco();

        if (!dados || !dados.despesaId) {
            throw new Error("Seleccione uma despesa.");
        }

        const despesa = await obterDespesa(dados.despesaId);

        if (!despesa) {
            throw new Error("Despesa não encontrada.");
        }

        if (despesa.estado === "anulada") {
            throw new Error(
                "Não é possível pagar uma despesa anulada."
            );
        }

        const valor = Number(dados.valor);

        if (!Number.isFinite(valor) || valor <= 0) {
            throw new Error(
                "O valor do pagamento deve ser superior a zero."
            );
        }

        const saldo = saldoDespesa(despesa);

        if (valor > saldo) {
            throw new Error(
                "O pagamento ultrapassa o saldo da despesa. Saldo disponível: " +
                formatarValor(saldo)
            );
        }

        despesa.pagamentos = pagamentosDaDespesa(despesa);

        const pagamento = {
            id: window.SGFE_DB.gerarID(),
            valor,
            data: dados.data || dataHoje(),
            metodo: dados.metodo || "Dinheiro",
            referencia: dados.referencia || "",
            estado: "confirmado",
            criadoEm: new Date().toISOString()
        };

        despesa.pagamentos.push(pagamento);

        despesa.valorPago = totalPago(despesa);

        despesa.estado = despesa.valorPago >= Number(despesa.valor)
            ? "pago"
            : "parcial";

        despesa.atualizadoEm = new Date().toISOString();

        await window.SGFE_DB.guardar(COLECAO, despesa);

        await window.SGFE_DB.registarHistorico({
            operacao: "pagamento",
            modulo: "despesas",
            descricao: "Pagamento de despesa: " + despesa.descricao,
            valor,
            data: new Date().toISOString()
        });

        return despesa;
    }

    // ANULAR PAGAMENTO

    async function anularPagamentoDespesa(despesaId, pagamentoId) {
        verificarBanco();

        const despesa = await obterDespesa(despesaId);

        if (!despesa) {
            throw new Error("Despesa não encontrada.");
        }

        const pagamentos = pagamentosDaDespesa(despesa);

        const pagamento = pagamentos.find(p => p.id === pagamentoId);

        if (!pagamento) {
            throw new Error("Pagamento não encontrado.");
        }

        if (pagamento.estado === "anulado") {
            throw new Error("Este pagamento já foi anulado.");
        }

        pagamento.estado = "anulado";
        pagamento.anuladoEm = new Date().toISOString();

        despesa.valorPago = totalPago(despesa);

        despesa.estado = despesa.valorPago >= Number(despesa.valor)
            ? "pago"
            : despesa.valorPago > 0 ? "parcial" : "pendente";

        despesa.atualizadoEm = new Date().toISOString();

        await window.SGFE_DB.guardar(COLECAO, despesa);

        await window.SGFE_DB.registarHistorico({
            operacao: "anulacao_pagamento",
            modulo: "despesas",
            descricao: "Pagamento de despesa anulado: " + despesa.descricao,
            valor: pagamento.valor,
            data: new Date().toISOString()
        });

        return despesa;
    }

    // CONSULTAR SALDO

    async function calcularSaldo(id) {
        const despesa = await obterDespesa(id);

        if (!despesa) {
            throw new Error("Despesa não encontrada.");
        }

        return saldoDespesa(despesa);
    }

    // ANULAR DESPESA

    async function anularDespesa(id, motivo) {
        verificarBanco();

        const despesa = await obterDespesa(id);

        if (!despesa) {
            throw new Error("Despesa não encontrada.");
        }

        if (despesa.estado === "anulada") {
            throw new Error("Esta despesa já foi anulada.");
        }

        if (totalPago(despesa) > 0) {
            throw new Error(
                "Não é possível anular uma despesa com pagamentos registados."
            );
        }

        despesa.estado = "anulada";
        despesa.motivoAnulacao = motivo || "Não especificado";
        despesa.dataAnulacao = new Date().toISOString();

        await window.SGFE_DB.guardar(COLECAO, despesa);

        await window.SGFE_DB.registarHistorico({
            operacao: "anulacao",
            modulo: "despesas",
            descricao: "Despesa anulada: " + despesa.descricao,
            data: new Date().toISOString()
        });

        return despesa;
    }

    // RESUMO FINANCEIRO

    async function obterResumo() {
        const despesas = await listarDespesas();

        const validas = despesas.filter(
            d => d.estado !== "anulada"
        );

        const total = validas.reduce(
            (soma, d) => soma + Number(d.valor || 0),
            0
        );

        const pago = validas.reduce(
            (soma, d) => soma + totalPago(d),
            0
        );

        return {
            quantidade: validas.length,
            total,
            pago,
            pendente: Math.max(0, total - pago)
        };
    }

    // INTERFACE DO MÓDULO

    function obterConteudo() {
        return document.getElementById("conteudoModulo");
    }

    async function abrir() {
        const conteudo = obterConteudo();

        if (!conteudo) {
            console.error(
                "Área de conteúdo do módulo não encontrada."
            );
            return;
        }

        conteudo.innerHTML = `
            <div class="entradas-modulo">

                <div class="cabecalho-modulo">
                    <div>
                        <h2>Gestão de Despesas</h2>
                        <p>Registo e controlo das saídas financeiras da instituição.</p>
                    </div>
                </div>

                <div class="entradas-indicadores">
                    <div class="cartao-indicador">
                        <span>Total de despesas</span>
                        <strong id="despesasTotal">0 Kz</strong>
                    </div>

                    <div class="cartao-indicador">
                        <span>Total pago</span>
                        <strong id="despesasPago">0 Kz</strong>
                    </div>

                    <div class="cartao-indicador">
                        <span>Total pendente</span>
                        <strong id="despesasPendente">0 Kz</strong>
                    </div>
                </div>

                <div class="entradas-acoes">
                    <button type="button" id="btnNovaDespesa">
                        + Registar despesa
                    </button>

                    <button type="button" id="btnNovoPagamentoDespesa">
                        + Registar pagamento
                    </button>
                </div>

                <div id="formularioDespesa" class="painel-formulario" hidden>
                    <h3>Registar nova despesa</h3>

                    <form id="formDespesa">
                        <div class="formulario-grelha">

                            <label>
                                Descrição
                                <input name="descricao" required
                                    placeholder="Ex.: Compra de material escolar">
                            </label>

                            <label>
                                Categoria
                                <select name="categoria" required>
                                    <option value="">Seleccione</option>
                                    <option value="Água">Água</option>
                                    <option value="Energia">Energia eléctrica</option>
                                    <option value="Alimentação">Alimentação</option>
                                    <option value="Material escolar">Material escolar</option>
                                    <option value="Material de escritório">Material de escritório</option>
                                    <option value="Manutenção">Manutenção</option>
                                    <option value="Transporte">Transporte</option>
                                    <option value="Comunicação">Comunicação</option>
                                    <option value="Limpeza">Limpeza</option>
                                    <option value="Serviços">Serviços</option>
                                    <option value="Outras despesas">Outras despesas</option>
                                </select>
                            </label>

                            <label>
                                Tipo de despesa
                                <select name="tipo">
                                    <option value="variavel">Variável</option>
                                    <option value="fixa">Fixa</option>
                                    <option value="extraordinaria">Extraordinária</option>
                                </select>
                            </label>

                            <label>
                                Valor previsto (Kz)
                                <input name="valor" type="number" min="1"
                                    step="0.01" required>
                            </label>

                            <label>
                                Data de registo
                                <input name="data" type="date" required>
                            </label>

                            <label>
                                Data de vencimento (opcional)
                                <input name="vencimento" type="date">
                            </label>

                            <label>
                                Fornecedor (opcional)
                                <input name="fornecedor"
                                    placeholder="Nome do fornecedor">
                            </label>

                            <label>
                                Serviço associado (opcional)
                                <input name="servico"
                                    placeholder="Ex.: Manutenção eléctrica">
                            </label>

                            <label class="campo-completo">
                                Observação
                                <input name="observacao"
                                    placeholder="Informação adicional">
                            </label>

                        </div>

                        <div class="botoes-formulario">
                            <button type="submit">Guardar despesa</button>
                            <button type="button" id="btnCancelarDespesa">
                                Cancelar
                            </button>
                        </div>
                    </form>
                </div>

                <div id="formularioPagamentoDespesa"
                    class="painel-formulario" hidden>

                    <h3>Registar pagamento de despesa</h3>

                    <form id="formPagamentoDespesa">
                        <div class="formulario-grelha">

                            <label class="campo-completo">
                                Seleccionar despesa
                                <select name="despesaId"
                                    id="selectDespesa" required>
                                    <option value="">Seleccione uma despesa</option>
                                </select>
                            </label>

                            <label>
                                Valor pago (Kz)
                                <input name="valor" type="number" min="1"
                                    step="0.01" required>
                            </label>

                            <label>
                                Data do pagamento
                                <input name="data" type="date" required>
                            </label>

                            <label>
                                Método de pagamento
                                <select name="metodo">
                                    <option value="Dinheiro">Dinheiro</option>
                                    <option value="Transferência">Transferência</option>
                                    <option value="Multicaixa">Multicaixa</option>
                                    <option value="Outro">Outro</option>
                                </select>
                            </label>

                            <label>
                                Referência (opcional)
                                <input name="referencia"
                                    placeholder="Número do comprovativo">
                            </label>

                        </div>

                        <div id="saldoDespesa"
                            class="informacao-saldo">
                            Seleccione uma despesa para consultar o saldo.
                        </div>

                        <div class="botoes-formulario">
                            <button type="submit">Confirmar pagamento</button>
                            <button type="button" id="btnCancelarPagamentoDespesa">
                                Cancelar
                            </button>
                        </div>
                    </form>
                </div>

                <div id="detalheDespesa"
                    class="painel-formulario" hidden></div>

                <div class="painel-tabela">
                    <div class="cabecalho-tabela">
                        <div>
                            <h3>Registo de despesas</h3>
                            <p>Histórico das despesas da instituição.</p>
                        </div>

                        <input type="search" id="pesquisaDespesas"
                            placeholder="Pesquisar despesa...">
                    </div>

                    <div class="tabela-deslizante">
                        <table>
                            <thead>
                                <tr>
                                    <th>Data</th>
                                    <th>Descrição</th>
                                    <th>Categoria</th>
                                    <th>Valor previsto</th>
                                    <th>Pago</th>
                                    <th>Saldo</th>
                                    <th>Estado</th>
                                    <th>Acção</th>
                                </tr>
                            </thead>

                            <tbody id="corpoTabelaDespesas">
                                <tr>
                                    <td colspan="8">A carregar despesas...</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>

            </div>
        `;

        document.getElementById("btnNovaDespesa").addEventListener(
            "click", () => alternarFormulario("despesa")
        );

        document.getElementById("btnNovoPagamentoDespesa").addEventListener(
            "click", () => alternarFormulario("pagamento")
        );

        document.getElementById("btnCancelarDespesa").addEventListener(
            "click", () => alternarFormulario("")
        );

        document.getElementById("btnCancelarPagamentoDespesa").addEventListener(
            "click", () => alternarFormulario("")
        );

        document.getElementById("formDespesa").addEventListener(
            "submit", guardarFormularioDespesa
        );

        document.getElementById("formPagamentoDespesa").addEventListener(
            "submit", guardarFormularioPagamento
        );

        document.getElementById("selectDespesa").addEventListener(
            "change", atualizarSaldoSelecionado
        );

        document.getElementById("pesquisaDespesas").addEventListener(
            "input", carregarTabela
        );

        document.getElementById("corpoTabelaDespesas").addEventListener(
            "click", function (evento) {
                const botao = evento.target.closest("[data-consultar]");

                if (botao) {
                    consultarDespesa(botao.dataset.consultar);
                }
            }
        );

        const formulario = document.getElementById("formDespesa");
        formulario.elements.data.value = dataHoje();

        const formularioPagamento =
            document.getElementById("formPagamentoDespesa");

        formularioPagamento.elements.data.value = dataHoje();

        await atualizarInterface();
    }

    function alternarFormulario(tipo) {
        const formularioDespesa =
            document.getElementById("formularioDespesa");

        const formularioPagamento =
            document.getElementById("formularioPagamentoDespesa");

        if (!formularioDespesa || !formularioPagamento) return;

        formularioDespesa.hidden = tipo !== "despesa";
        formularioPagamento.hidden = tipo !== "pagamento";

        if (tipo) {
            fecharDetalhe();
        }
    }

    function fecharDetalhe() {
        const detalhe = document.getElementById("detalheDespesa");

        if (detalhe) {
            detalhe.hidden = true;
            detalhe.innerHTML = "";
        }
    }

    // GUARDAR FORMULÁRIOS

    async function guardarFormularioDespesa(evento) {
        evento.preventDefault();

        const formulario = evento.currentTarget;
        const dados = Object.fromEntries(
            new FormData(formulario).entries()
        );

        try {
            await registarDespesa(dados);

            formulario.reset();
            formulario.elements.data.value = dataHoje();

            alternarFormulario("");
            await atualizarInterface();

            notificar("Despesa registada com sucesso!");

        } catch (erro) {
            notificar(erro.message);
        }
    }

    async function guardarFormularioPagamento(evento) {
        evento.preventDefault();

        const formulario = evento.currentTarget;
        const dados = Object.fromEntries(
            new FormData(formulario).entries()
        );

        try {
            await pagarDespesa(dados);

            formulario.reset();
            formulario.elements.data.value = dataHoje();

            alternarFormulario("");
            await atualizarInterface();

            notificar("Pagamento registado com sucesso!");

        } catch (erro) {
            notificar(erro.message);
        }
    }

    // ACTUALIZAR INTERFACE

    async function atualizarInterface() {
        await atualizarIndicadores();
        await carregarOpcoesDespesas();
        await carregarTabela();

        if (window.SGFE_PAINEL) {
            await window.SGFE_PAINEL.atualizar();
        }
    }

    async function atualizarIndicadores() {
        const resumo = await obterResumo();

        document.getElementById("despesasTotal").textContent =
            formatarValor(resumo.total);

        document.getElementById("despesasPago").textContent =
            formatarValor(resumo.pago);

        document.getElementById("despesasPendente").textContent =
            formatarValor(resumo.pendente);
    }

    async function carregarOpcoesDespesas() {
        const select = document.getElementById("selectDespesa");

        if (!select) return;

        const despesas = await listarDespesas();

        select.innerHTML =
            '<option value="">Seleccione uma despesa</option>';

        for (const despesa of despesas) {
            if (despesa.estado === "anulada") continue;

            const saldo = saldoDespesa(despesa);

            if (saldo <= 0) continue;

            const opcao = document.createElement("option");

            opcao.value = despesa.id;
            opcao.textContent =
                despesa.descricao + " — Saldo: " +
                formatarValor(saldo);

            select.appendChild(opcao);
        }
    }

    async function atualizarSaldoSelecionado() {
        const select = document.getElementById("selectDespesa");
        const campo = document.getElementById("saldoDespesa");

        if (!select || !campo) return;

        const id = select.value;

        if (!id) {
            campo.textContent =
                "Seleccione uma despesa para consultar o saldo.";
            return;
        }

        const saldo = await calcularSaldo(id);

        campo.textContent =
            "Saldo pendente: " + formatarValor(saldo);
    }

    // CONSULTAR DESPESA

    async function consultarDespesa(id) {
        try {
            const despesa = await obterDespesa(id);

            if (!despesa) {
                throw new Error(
                    "Não foi possível encontrar esta despesa."
                );
            }

            const pagamentos = pagamentosDaDespesa(despesa);

            const ordenados = [...pagamentos].sort((a, b) =>
                String(b.data || "").localeCompare(String(a.data || ""))
            );

            const pago = totalPago(despesa);
            const saldo = saldoDespesa(despesa);
            const estado = estadoDespesa(despesa);

            let linhasHistorico = "";

            if (ordenados.length === 0) {
                linhasHistorico = `
                    <tr>
                        <td colspan="6">
                            Ainda não existem pagamentos registados.
                        </td>
                    </tr>
                `;
            } else {
                for (const pagamento of ordenados) {
                    const anulado = pagamento.estado === "anulado";

                    const botaoAcao = anulado
                        ? "—"
                        : `<button type="button"
                            data-anular-pagamento="${escapar(pagamento.id)}">
                            Anular
                           </button>`;

                    linhasHistorico += `
                        <tr>
                            <td>${escapar(pagamento.data || "—")}</td>

                            <td>${escapar(
                                pagamento.metodo || "Não indicado"
                            )}</td>

                            <td>${escapar(
                                pagamento.referencia || "—"
                            )}</td>

                            <td>${formatarValor(pagamento.valor)}</td>

                            <td>
                                <span class="estado-entrada ${
                                    anulado
                                        ? "estado-pendente"
                                        : "estado-pago"
                                }">
                                    ${anulado ? "Anulado" : "Confirmado"}
                                </span>
                            </td>

                            <td>${botaoAcao}</td>
                        </tr>
                    `;
                }
            }

            const detalhe = document.getElementById("detalheDespesa");

            detalhe.innerHTML = `
                <div class="cabecalho-tabela">
                    <div>
                        <h3>Detalhes da despesa</h3>
                        <p>Consulta individual da despesa seleccionada.</p>
                    </div>

                    <div class="botoes-formulario">
                        ${
                            estado !== "Anulada"
                                ? `<button type="button" id="btnEditarDespesa">
                                    Editar despesa
                                   </button>`
                                : ""
                        }

                        ${
                            estado === "Pendente"
                                ? `<button type="button" id="btnAnularDespesa">
                                    Anular despesa
                                   </button>`
                                : ""
                        }

                        <button type="button" id="btnFecharDetalheDespesa">
                            Fechar consulta
                        </button>
                    </div>
                </div>

                <div class="entradas-indicadores">
                    <div class="cartao-indicador">
                        <span>Valor previsto</span>
                        <strong>${formatarValor(despesa.valor)}</strong>
                    </div>

                    <div class="cartao-indicador">
                        <span>Total pago</span>
                        <strong>${formatarValor(pago)}</strong>
                    </div>

                    <div class="cartao-indicador">
                        <span>Saldo pendente</span>
                        <strong>${formatarValor(saldo)}</strong>
                    </div>
                </div>

                <div class="formulario-grelha">

                    <label>
                        Descrição
                        <input value="${escapar(despesa.descricao)}" readonly>
                    </label>

                    <label>
                        Categoria
                        <input value="${escapar(despesa.categoria)}" readonly>
                    </label>

                    <label>
                        Tipo
                        <input value="${escapar(despesa.tipo || "variavel")}" readonly>
                    </label>

                    <label>
                        Data de registo
                        <input value="${escapar(despesa.data || "—")}" readonly>
                    </label>

                    <label>
                        Vencimento
                        <input value="${escapar(despesa.vencimento || "—")}" readonly>
                    </label>

                    <label>
                        Estado
                        <input value="${estado}" readonly>
                    </label>

                    <label>
                        Fornecedor
                        <input value="${escapar(despesa.fornecedor || "Não indicado")}" readonly>
                    </label>

                    <label>
                        Serviço associado
                        <input value="${escapar(despesa.servico || "Não indicado")}" readonly>
                    </label>

                    <label class="campo-completo">
                        Observação
                        <input value="${escapar(despesa.observacao || "Sem observações")}" readonly>
                    </label>

                    ${
                        despesa.estado === "anulada"
                            ? `<label class="campo-completo">
                                Motivo da anulação
                                <input value="${escapar(despesa.motivoAnulacao || "Não especificado")}" readonly>
                               </label>`
                            : ""
                    }

                </div>

                <div class="cabecalho-tabela">
                    <div>
                        <h3>Histórico de pagamentos</h3>
                        <p>${ordenados.length} registo(s) de pagamento.</p>
                    </div>
                </div>

                <div class="tabela-deslizante">
                    <table>
                        <thead>
                            <tr>
                                <th>Data</th>
                                <th>Método</th>
                                <th>Referência</th>
                                <th>Valor</th>
                                <th>Estado</th>
                                <th>Acção</th>
                            </tr>
                        </thead>

                        <tbody>${linhasHistorico}</tbody>
                    </table>
                </div>
            `;

            detalhe.hidden = false;

            document.getElementById("btnFecharDetalheDespesa")
                .addEventListener("click", fecharDetalhe);

            const btnEditar = document.getElementById("btnEditarDespesa");

            if (btnEditar) {
                btnEditar.addEventListener(
                    "click",
                    () => abrirEdicaoDespesa(despesa)
                );
            }

            const btnAnular = document.getElementById("btnAnularDespesa");

            if (btnAnular) {
                btnAnular.addEventListener("click", async function () {
                    const motivo = prompt(
                        "Indique o motivo da anulação desta despesa:"
                    );

                    if (motivo === null) return;

                    const confirmar = confirm(
                        "Confirma a anulação desta despesa?"
                    );

                    if (!confirmar) return;

                    try {
                        await anularDespesa(despesa.id, motivo);

                        await atualizarInterface();
                        await consultarDespesa(despesa.id);

                        notificar("Despesa anulada com sucesso!");

                    } catch (erro) {
                        notificar(erro.message);
                    }
                });
            }

            detalhe.querySelectorAll("[data-anular-pagamento]")
                .forEach(botao => {
                    botao.addEventListener("click", async function () {
                        const confirmar = confirm(
                            "Tem a certeza de que pretende anular este pagamento?\n\n" +
                            "O registo será mantido no histórico, mas deixará " +
                            "de contar como valor pago."
                        );

                        if (!confirmar) return;

                        try {
                            await anularPagamentoDespesa(
                                despesa.id,
                                botao.dataset.anularPagamento
                            );

                            await atualizarInterface();
                            await consultarDespesa(despesa.id);

                            notificar("Pagamento anulado com sucesso!");

                        } catch (erro) {
                            notificar(erro.message);
                        }
                    });
                });

            detalhe.scrollIntoView({
                behavior: "smooth",
                block: "start"
            });

        } catch (erro) {
            notificar(erro.message);
        }
    }

    // EDITAR DESPESA

    function abrirEdicaoDespesa(despesa) {
        const detalhe = document.getElementById("detalheDespesa");

        const categorias = [
            "Água",
            "Energia",
            "Alimentação",
            "Material escolar",
            "Material de escritório",
            "Manutenção",
            "Transporte",
            "Comunicação",
            "Limpeza",
            "Serviços",
            "Outras despesas"
        ];

        const opcoesCategoria = categorias.map(categoria => `
            <option value="${escapar(categoria)}"
                ${despesa.categoria === categoria ? "selected" : ""}>
                ${escapar(categoria)}
            </option>
        `).join("");

        detalhe.innerHTML = `
            <div class="cabecalho-tabela">
                <div>
                    <h3>Editar despesa</h3>
                    <p>Altere os dados da despesa seleccionada.</p>
                </div>
            </div>

            <form id="formEditarDespesa">
                <div class="formulario-grelha">

                    <label>
                        Descrição
                        <input name="descricao" required
                            value="${escapar(despesa.descricao)}">
                    </label>

                    <label>
                        Categoria
                        <select name="categoria" required>
                            ${opcoesCategoria}
                        </select>
                    </label>

                    <label>
                        Tipo de despesa
                        <select name="tipo">
                            <option value="variavel"
                                ${despesa.tipo === "variavel" ? "selected" : ""}>
                                Variável
                            </option>

                            <option value="fixa"
                                ${despesa.tipo === "fixa" ? "selected" : ""}>
                                Fixa
                            </option>

                            <option value="extraordinaria"
                                ${despesa.tipo === "extraordinaria" ? "selected" : ""}>
                                Extraordinária
                            </option>
                        </select>
                    </label>

                    <label>
                        Valor previsto (Kz)
                        <input name="valor" type="number" min="1"
                            step="0.01" required
                            value="${Number(despesa.valor)}">
                    </label>

                    <label>
                        Data de registo
                        <input name="data" type="date" required
                            value="${escapar(despesa.data || "")}">
                    </label>

                    <label>
                        Data de vencimento
                        <input name="vencimento" type="date"
                            value="${escapar(despesa.vencimento || "")}">
                    </label>

                    <label>
                        Fornecedor
                        <input name="fornecedor"
                            value="${escapar(despesa.fornecedor || "")}">
                    </label>

                    <label>
                        Serviço associado
                        <input name="servico"
                            value="${escapar(despesa.servico || "")}">
                    </label>

                    <label class="campo-completo">
                        Observação
                        <input name="observacao"
                            value="${escapar(despesa.observacao || "")}">
                    </label>

                </div>

                <div class="botoes-formulario">
                    <button type="submit">Guardar alterações</button>

                    <button type="button" id="btnCancelarEdicaoDespesa">
                        Cancelar
                    </button>
                </div>
            </form>
        `;

        document.getElementById("btnCancelarEdicaoDespesa")
            .addEventListener(
                "click",
                () => consultarDespesa(despesa.id)
            );

        document.getElementById("formEditarDespesa")
            .addEventListener("submit", async function (evento) {
                evento.preventDefault();

                const dados = Object.fromEntries(
                    new FormData(evento.currentTarget).entries()
                );

                try {
                    await atualizarDespesa(despesa.id, dados);

                    await atualizarInterface();
                    await consultarDespesa(despesa.id);

                    notificar("Despesa actualizada com sucesso!");

                } catch (erro) {
                    notificar(erro.message);
                }
            });
    }

    // CARREGAR TABELA

    async function carregarTabela() {
        const corpo = document.getElementById("corpoTabelaDespesas");

        if (!corpo) return;

        const despesas = await listarDespesas();

        const campoPesquisa =
            document.getElementById("pesquisaDespesas");

        const pesquisa = campoPesquisa
            ? campoPesquisa.value.trim().toLowerCase()
            : "";

        if (despesas.length === 0) {
            corpo.innerHTML = `
                <tr>
                    <td colspan="8">
                        Ainda não existem despesas registadas.
                    </td>
                </tr>
            `;
            return;
        }

        const filtradas = despesas.filter(d =>
            [
                d.descricao,
                d.categoria,
                d.fornecedor,
                d.servico,
                d.observacao,
                d.tipo
            ].join(" ").toLowerCase().includes(pesquisa)
        );

        if (filtradas.length === 0) {
            corpo.innerHTML = `
                <tr>
                    <td colspan="8">Nenhum resultado encontrado.</td>
                </tr>
            `;
            return;
        }

        filtradas.sort((a, b) =>
            String(b.data || "").localeCompare(String(a.data || ""))
        );

        let html = "";

        for (const despesa of filtradas) {
            const pago = totalPago(despesa);
            const saldo = saldoDespesa(despesa);
            const estado = estadoDespesa(despesa);

            html += `
                <tr>
                    <td>${escapar(despesa.data || "—")}</td>

                    <td>${escapar(despesa.descricao)}</td>

                    <td>${escapar(despesa.categoria)}</td>

                    <td>${formatarValor(despesa.valor)}</td>

                    <td>${formatarValor(pago)}</td>

                    <td>${formatarValor(saldo)}</td>

                    <td>
                        <span class="estado-entrada ${classeEstado(estado)}">
                            ${estado}
                        </span>
                    </td>

                    <td>
                        <button type="button"
                            data-consultar="${escapar(despesa.id)}">
                            Consultar
                        </button>
                    </td>
                </tr>
            `;
        }

        corpo.innerHTML = html;
    }

    // DISPONIBILIZAR MÓDULO

    window.SGFE_DESPESAS = Object.freeze({
        registarDespesa,
        listarDespesas,
        obterDespesa,
        atualizarDespesa,
        pagarDespesa,
        anularPagamentoDespesa,
        calcularSaldo,
        anularDespesa,
        obterResumo,
        abrir,
        atualizarInterface,
        consultarDespesa
    });

})();
