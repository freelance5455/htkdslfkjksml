
/* ============================================
   SGFE - MOTOR DE IMPRESSÃO
   Sistema centralizado de documentos A4
============================================ */

(function () {
    "use strict";

    let areaImpressao = null;

    function escapar(valor) {
        return String(valor ?? "").replace(/[&<>"']/g, c => ({
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&#039;"
        })[c]);
    }

    function dataActual() {
        return new Date().toLocaleDateString("pt-AO", {
            day: "2-digit",
            month: "long",
            year: "numeric"
        });
    }

    function formatarLogo(logotipo) {
        if (!logotipo) return "";

        return `
            <img class="sgfe-logo"
                 src="${escapar(logotipo)}"
                 alt="Logótipo institucional">
        `;
    }

    function instalarEstilos() {
        if (document.getElementById("sgfe-estilos-impressao")) {
            return;
        }

        const estilo = document.createElement("style");

        estilo.id = "sgfe-estilos-impressao";

        estilo.textContent = `
            /* Área de impressão */

            #sgfe-area-impressao {
                display: none;
                background: white;
                color: #111;
                font-family: Arial, Helvetica, sans-serif;
                font-size: 11px;
                line-height: 1.4;
            }

            #sgfe-area-impressao .sgfe-cabecalho {
                display: flex;
                align-items: center;
                justify-content: center;
                gap: 15px;
                text-align: center;
                border-bottom: 2px solid #17365D;
                padding-bottom: 12px;
                margin-bottom: 18px;
            }

            #sgfe-area-impressao .sgfe-logo {
                max-width: 85px;
                max-height: 85px;
                object-fit: contain;
            }

            #sgfe-area-impressao .sgfe-identidade {
                flex: 1;
            }

            #sgfe-area-impressao .sgfe-identidade h2 {
                font-size: 16px;
                margin: 0 0 5px;
                text-transform: uppercase;
            }

            #sgfe-area-impressao .sgfe-identidade p {
                margin: 2px 0;
                font-size: 10px;
            }

            #sgfe-area-impressao .sgfe-titulo {
                text-align: center;
                margin: 15px 0 5px;
                font-size: 15px;
                text-transform: uppercase;
            }

            #sgfe-area-impressao .sgfe-periodo {
                text-align: center;
                margin-bottom: 18px;
                font-size: 11px;
            }

            #sgfe-area-impressao .sgfe-documento {
                width: 100%;
            }

            #sgfe-area-impressao h3 {
                font-size: 12px;
                margin: 15px 0 8px;
            }

            #sgfe-area-impressao p {
                margin: 5px 0;
            }

            #sgfe-area-impressao table {
                width: 100%;
                border-collapse: collapse;
                margin: 10px 0 15px;
                font-size: 10px;
            }

            #sgfe-area-impressao th,
            #sgfe-area-impressao td {
                border: 1px solid #777;
                padding: 6px;
                text-align: left;
                vertical-align: middle;
            }

            #sgfe-area-impressao th {
                background: #e9edf2 !important;
                font-weight: bold;
            }

            #sgfe-area-impressao .texto-direita {
                text-align: right;
            }

            #sgfe-area-impressao .texto-centro {
                text-align: center;
            }

            #sgfe-area-impressao .total-geral {
                font-weight: bold;
                background: #edf1f5 !important;
            }

            #sgfe-area-impressao .sgfe-resumo {
                margin: 12px 0;
                padding: 9px;
                border: 1px solid #777;
            }

            #sgfe-area-impressao .sgfe-assinaturas {
                display: flex;
                justify-content: space-around;
                gap: 25px;
                margin-top: 55px;
                text-align: center;
            }

            #sgfe-area-impressao .sgfe-assinaturas div {
                flex: 1;
                border-top: 1px solid #222;
                padding-top: 7px;
            }

            #sgfe-area-impressao .sgfe-rodape {
                margin-top: 25px;
                padding-top: 8px;
                border-top: 1px solid #aaa;
                text-align: center;
                font-size: 9px;
            }

            #sgfe-area-impressao .sgfe-quebra-pagina {
                break-before: page;
                page-break-before: always;
            }

            #sgfe-area-impressao .sgfe-grafico {
                margin: 18px 0;
            }

            #sgfe-area-impressao .sgfe-barra {
                height: 17px;
                background: #17365D;
                margin: 5px 0 12px;
                min-width: 2px;
            }

            #sgfe-area-impressao .sgfe-barra-destaque {
                background: #D5A43B;
            }

            #sgfe-area-impressao .sgfe-grafico-item {
                margin: 12px 0;
            }

            #sgfe-area-impressao .sgfe-grafico-valor {
                font-weight: bold;
            }

            @media screen {
                #sgfe-area-impressao {
                    display: none !important;
                }
            }

            @media print {
                @page {
                    size: A4 portrait;
                    margin: 14mm;
                }

                body * {
                    visibility: hidden !important;
                }

                #sgfe-area-impressao,
                #sgfe-area-impressao * {
                    visibility: visible !important;
                }

                #sgfe-area-impressao {
                    display: block !important;
                    position: absolute;
                    top: 0;
                    left: 0;
                    width: 100%;
                    margin: 0;
                    padding: 0;
                }

                #sgfe-area-impressao table {
                    page-break-inside: auto;
                    break-inside: auto;
                }

                #sgfe-area-impressao thead {
                    display: table-header-group;
                }

                #sgfe-area-impressao tfoot {
                    display: table-footer-group;
                }

                #sgfe-area-impressao tr {
                    break-inside: avoid;
                    page-break-inside: avoid;
                }

                #sgfe-area-impressao .sgfe-cabecalho,
                #sgfe-area-impressao .sgfe-resumo,
                #sgfe-area-impressao .sgfe-assinaturas {
                    break-inside: avoid;
                    page-break-inside: avoid;
                }

                #sgfe-area-impressao .sgfe-quebra-pagina {
                    break-before: page;
                    page-break-before: always;
                }

                #sgfe-area-impressao .sgfe-barra {
                    print-color-adjust: exact;
                    -webkit-print-color-adjust: exact;
                }

                #sgfe-area-impressao th,
                #sgfe-area-impressao .total-geral {
                    print-color-adjust: exact;
                    -webkit-print-color-adjust: exact;
                }
            }
        `;

        document.head.appendChild(estilo);
    }

    async function obterInstituicao() {
        const padrao = {
            nome: "INSTITUIÇÃO DE ENSINO",
            nomeAbreviado: "",
            logotipo: "",
            endereco: "",
            telefone: "",
            email: "",
            municipio: "",
            provincia: ""
        };

        try {
            if (!window.SGFE_CONFIGURACOES) {
                return padrao;
            }

            const config = await window.SGFE_CONFIGURACOES.carregar();

            return {
                ...padrao,
                ...(config.instituicao || {})
            };

        } catch (erro) {
            console.error("Erro ao carregar identidade institucional:", erro);
            return padrao;
        }
    }

    async function prepararDocumento(opcoes) {
        instalarEstilos();

        const instituicao = await obterInstituicao();

        const titulo = escapar(opcoes.titulo || "Relatório");
        const periodo = escapar(opcoes.periodo || "Período não especificado");

        const nome = escapar(
            instituicao.nome || "INSTITUIÇÃO DE ENSINO"
        );

        const localidade = [
            instituicao.municipio,
            instituicao.provincia
        ].filter(Boolean).join(" - ");

        const contactos = [
            instituicao.telefone,
            instituicao.email
        ].filter(Boolean).join(" | ");

        if (areaImpressao) {
            areaImpressao.remove();
        }

        areaImpressao = document.createElement("section");
        areaImpressao.id = "sgfe-area-impressao";

        areaImpressao.innerHTML = `
            <header class="sgfe-cabecalho">

                ${formatarLogo(instituicao.logotipo)}

                <div class="sgfe-identidade">
                    <h2>${nome}</h2>

                    ${instituicao.endereco
                        ? `<p>${escapar(instituicao.endereco)}</p>`
                        : ""}

                    ${localidade
                        ? `<p>${escapar(localidade)}</p>`
                        : ""}

                    ${contactos
                        ? `<p>${escapar(contactos)}</p>`
                        : ""}
                </div>

            </header>

            <h1 class="sgfe-titulo">${titulo}</h1>

            <p class="sgfe-periodo">
                <strong>Período:</strong> ${periodo}
            </p>

            <main class="sgfe-documento">
                ${opcoes.conteudo || ""}
            </main>

            ${opcoes.assinaturas !== false ? `
                <div class="sgfe-assinaturas">
                    <div>
                        O Responsável
                    </div>

                    <div>
                        A Direcção
                    </div>
                </div>
            ` : ""}

            <footer class="sgfe-rodape">
                Documento emitido pelo SGFE em ${dataActual()}
            </footer>
        `;

        document.body.appendChild(areaImpressao);
    }

    async function imprimir(opcoes = {}) {
        try {
            await prepararDocumento(opcoes);

            const estiloPagina = document.getElementById(
                "sgfe-estilos-impressao"
            );

            if (opcoes.orientacao === "paisagem") {
                const regra = `
                    @media print {
                        @page {
                            size: A4 landscape;
                            margin: 12mm;
                        }
                    }
                `;

                let paisagem = document.getElementById(
                    "sgfe-estilo-paisagem"
                );

                if (!paisagem) {
                    paisagem = document.createElement("style");
                    paisagem.id = "sgfe-estilo-paisagem";
                    document.head.appendChild(paisagem);
                }

                paisagem.textContent = regra;

            } else {
                const paisagem = document.getElementById(
                    "sgfe-estilo-paisagem"
                );

                if (paisagem) paisagem.remove();
            }

            if (!estiloPagina) {
                instalarEstilos();
            }

            window.addEventListener("afterprint", function limpar() {
                if (areaImpressao) {
                    areaImpressao.remove();
                    areaImpressao = null;
                }

                const paisagem = document.getElementById(
                    "sgfe-estilo-paisagem"
                );

                if (paisagem) paisagem.remove();

            }, { once: true });

            window.print();

        } catch (erro) {
            console.error("Erro ao preparar impressão:", erro);
            alert("Não foi possível preparar o documento para impressão.");
        }
    }

    window.SGFE_IMPRESSAO = Object.freeze({
        imprimir,
        obterInstituicao
    });

})();
