/**
 * RoboSim AI Studio Pro - AI Engineering Assistant & .INO Firmware Generator
 * Powers natural language design consults, automated pin mapping, complete C++ Arduino/ESP32 sketch generation,
 * direct .ino file export, and 3D prototype creation from user descriptions.
 */

window.RoboAI = (function() {
  const chatHistory = [];
  let currentGeneratedCode = "";

  // Preset prototype templates for natural language AI generation
  const AI_PROTOTYPE_PRESETS = [
    {
      keywords: ["esquivador", "obstaculos", "car", "carro", "vehiculo", "2wd", "evasor", "ruedas"],
      title: "Robot Móvil Autónomo Esquivador de Obstáculos 2WD",
      description: "Robot sobre chasis 2WD con Arduino Uno, sensor ultrasónico HC-SR04 frontal para detección de colisiones, driver L298N y batería 7.4V.",
      components: [
        { id: "cloud_chassis_2wd", pos: { x: 0, y: 0, z: 0 }, rotY: 0 },
        { id: "arduino_uno", pos: { x: -2, y: 3.5, z: -2 }, rotY: 0 },
        { id: "driver_l298n", pos: { x: -2, y: 3.5, z: 4 }, rotY: 0 },
        { id: "hc_sr04", pos: { x: 8, y: 4.0, z: 0 }, rotY: 0 },
        { id: "battery_18650_pack", pos: { x: -6, y: 3.5, z: 0 }, rotY: Math.PI / 2 }
      ],
      customPrompt: "Genera el firmware completo para un robot esquivador de obstáculos 2WD con HC-SR04 montado al frente y motores controlados por L298N."
    },
    {
      keywords: ["brazo", "arm", "articulado", "servo", "pinza", "gripper", "pan tilt"],
      title: "Brazo Robótico Articulado 3-DOF con Pinza",
      description: "Estructura de brazo robótico acrílico con 3 servomotores (base, codo, pinza), protoboard 830 puntos y Arduino Uno R3.",
      components: [
        { id: "cloud_robotic_arm_kit", pos: { x: 0, y: 0, z: 0 }, rotY: 0 },
        { id: "servo_mg996r", pos: { x: -8, y: 0, z: -5 }, rotY: 0 },
        { id: "servo_sg90", pos: { x: 8, y: 0, z: -5 }, rotY: 0 },
        { id: "arduino_uno", pos: { x: -10, y: 0, z: 8 }, rotY: 0 },
        { id: "breadboard_830", pos: { x: 5, y: 0, z: 12 }, rotY: 0 }
      ],
      customPrompt: "Escribe el código C++ para controlar un brazo robótico de 3 servomotores con secuencias cinemáticas preprogramadas y control serie."
    },
    {
      keywords: ["estacion", "clima", "iot", "pantalla", "oled", "dht", "temperatura", "humedad", "esp32", "wifi"],
      title: "Estación Ambiental Inteligente IoT ESP32",
      description: "Estación meteorológica y de calidad ambiental con ESP32 NodeMCU, pantalla OLED SSD1306, sensor DHT22 y sensor de color TCS34725.",
      components: [
        { id: "esp32_nodemcu", pos: { x: -6, y: 0.5, z: 0 }, rotY: 0 },
        { id: "cloud_oled_096", pos: { x: 0, y: 0.5, z: 0 }, rotY: 0 },
        { id: "cloud_dht22", pos: { x: 6, y: 0.5, z: -3 }, rotY: 0 },
        { id: "cloud_tcs34725", pos: { x: 6, y: 0.5, z: 3 }, rotY: 0 },
        { id: "breadboard_830", pos: { x: 0, y: -0.85, z: 0 }, rotY: 0 }
      ],
      customPrompt: "Firmware para estación ambiental ESP32: lee temperatura/humedad de DHT22 y muestra lecturas con interfaz gráfica en pantalla OLED 128x64."
    },
    {
      keywords: ["gimbal", "estabilizador", "inercial", "imu", "mpu", "giroscopio"],
      title: "Gimbal Estabilizador Inercial de 2 Ejes (MPU6050)",
      description: "Sistema de compensación de cabeceo (Pitch) y balanceo (Roll) utilizando sensor inercial MPU6050 y dos servomotores MG996R.",
      components: [
        { id: "arduino_uno", pos: { x: -6, y: 0, z: 0 }, rotY: 0 },
        { id: "mpu6050", pos: { x: 0, y: 0.2, z: 0 }, rotY: 0 },
        { id: "servo_mg996r", pos: { x: 8, y: 0, z: -4 }, rotY: 0 },
        { id: "servo_sg90", pos: { x: 8, y: 0, z: 4 }, rotY: 0 },
        { id: "battery_18650_pack", pos: { x: 0, y: 0, z: 9 }, rotY: 0 }
      ],
      customPrompt: "Código de estabilización inercial: filtro complementario para MPU6050 y servos de compensación para gimbal activo."
    }
  ];

  // Initialize with helpful welcome message
  function init() {
    chatHistory.push({
      sender: "ai",
      text: "👋 ¡Hola! Soy tu **Asistente de IA de RoboSim AI Studio Pro**.\n\nPuedo ayudarte a:\n- 🤖 **Construir prototipos 3D** en lenguaje natural (ej: *'Crea un robot esquivador de obstáculos'*).\n- ⚡ **Generar código C++ (.ino)** optimizado para Arduino o ESP32 según las piezas de tu escena.\n- 🔧 **Resolver dudas de circuitos**, compatibilidad de voltajes y cinemática robótica.",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    });
  }

  // Generate .ino code based on active components in scene
  function generateInoCode() {
    const placed = window.RoboEngine.getPlacedObjects();
    const hasESP32 = placed.some(o => o.dbId === "esp32_nodemcu");
    const hasArduino = placed.some(o => o.dbId === "arduino_uno") || !hasESP32;
    const hasHCSR04 = placed.some(o => o.dbId === "hc_sr04");
    const hasL298N = placed.some(o => o.dbId === "driver_l298n" || o.dbId === "motor_dc_tt");
    const hasSG90 = placed.some(o => o.dbId === "servo_sg90");
    const hasMG996R = placed.some(o => o.dbId === "servo_mg996r");
    const hasMPU6050 = placed.some(o => o.dbId === "mpu6050");
    const hasOLED = placed.some(o => o.dbId === "cloud_oled_096");
    const hasDHT22 = placed.some(o => o.dbId === "cloud_dht22");
    const hasTCS34725 = placed.some(o => o.dbId === "cloud_tcs34725");
    const hasRelay = placed.some(o => o.dbId === "cloud_relay_5v");
    const hasNema17 = placed.some(o => o.dbId === "motor_nema17");

    const boardName = hasESP32 ? "ESP32 Dev Module" : "Arduino Uno R3";

    let code = `/**
 * ====================================================================
 *   RoboSim AI Studio Pro - Firmware Generado Automáticamente
 *   Placa Destino: ${boardName}
 *   Componentes en Escena: ${placed.map(p => p.name).join(", ") || "Placa Base"}
 *   Fecha de Síntesis: ${new Date().toLocaleString()}
 * ====================================================================
 */

`;

    // Headers & Includes
    code += `// --- LIBRERÍAS REQUERIDAS ---\n`;
    code += `#include <Arduino.h>\n`;
    if (hasMPU6050 || hasOLED || hasTCS34725) {
      code += `#include <Wire.h>\n`;
    }
    if (hasSG90 || hasMG996R) {
      if (hasESP32) {
        code += `#include <ESP32Servo.h>\n`;
      } else {
        code += `#include <Servo.h>\n`;
      }
    }
    if (hasOLED) {
      code += `#include <Adafruit_GFX.h>\n`;
      code += `#include <Adafruit_SSD1306.h>\n`;
    }
    if (hasDHT22) {
      code += `#include <DHT.h>\n`;
    }

    code += `\n// --- DEFINICIÓN DE PINES Y CONSTANTES ---\n`;

    if (hasHCSR04) {
      code += `// Sensor Ultrasonido HC-SR04\n`;
      code += `#define PIN_TRIG 11\n`;
      code += `#define PIN_ECHO 12\n`;
      code += `#define DISTANCIA_UMBRAL_CM 20\n\n`;
    }

    if (hasL298N) {
      code += `// Driver de Motores L298N (Puente H)\n`;
      code += `#define ENA 5  // PWM Control Velocidad Motor Izq\n`;
      code += `#define IN1 6  // Dirección Motor Izq\n`;
      code += `#define IN2 7\n`;
      code += `#define IN3 8  // Dirección Motor Der\n`;
      code += `#define IN4 4\n`;
      code += `#define ENB 3  // PWM Control Velocidad Motor Der\n`;
      code += `#define VELOCIDAD_BASE 180 // Rango 0-255\n\n`;
    }

    if (hasSG90) {
      code += `// Servomotor SG90\n`;
      code += `#define PIN_SERVO_SG90 9\n`;
    }

    if (hasMG996R) {
      code += `// Servomotor MG996R\n`;
      code += `#define PIN_SERVO_MG996R 10\n`;
    }

    if (hasDHT22) {
      code += `// Sensor DHT22\n`;
      code += `#define PIN_DHT 2\n`;
      code += `#define DHTTYPE DHT22\n`;
    }

    if (hasRelay) {
      code += `// Módulo Relé 5V\n`;
      code += `#define PIN_RELE 13\n`;
    }

    code += `\n// --- INSTANCIAS Y VARIABLES GLOBALES ---\n`;
    if (hasSG90) code += `Servo servoSG90;\n`;
    if (hasMG996R) code += `Servo servoMG996R;\n`;
    if (hasDHT22) code += `DHT dht(PIN_DHT, DHTTYPE);\n`;
    if (hasOLED) code += `Adafruit_SSD1306 display(128, 64, &Wire, -1);\n`;

    // SETUP
    code += `\nvoid setup() {\n`;
    code += `  Serial.begin(115200);\n`;
    code += `  while (!Serial && millis() < 3000); // Espera inicial puerto serie\n`;
    code += `  Serial.println(F(">>> RoboSim AI Studio Pro: Sistema Inicializado <<<"));\n\n`;

    if (hasHCSR04) {
      code += `  pinMode(PIN_TRIG, OUTPUT);\n`;
      code += `  pinMode(PIN_ECHO, INPUT);\n`;
      code += `  digitalWrite(PIN_TRIG, LOW);\n`;
    }

    if (hasL298N) {
      code += `  pinMode(ENA, OUTPUT);\n`;
      code += `  pinMode(ENB, OUTPUT);\n`;
      code += `  pinMode(IN1, OUTPUT);\n`;
      code += `  pinMode(IN2, OUTPUT);\n`;
      code += `  pinMode(IN3, OUTPUT);\n`;
      code += `  pinMode(IN4, OUTPUT);\n`;
      code += `  detenerMotores();\n`;
    }

    if (hasSG90) {
      code += `  servoSG90.attach(PIN_SERVO_SG90);\n`;
      code += `  servoSG90.write(90); // Posición inicial neutra\n`;
    }

    if (hasMG996R) {
      code += `  servoMG996R.attach(PIN_SERVO_MG996R);\n`;
      code += `  servoMG996R.write(90);\n`;
    }

    if (hasRelay) {
      code += `  pinMode(PIN_RELE, OUTPUT);\n`;
      code += `  digitalWrite(PIN_RELE, LOW); // Relé apagado\n`;
    }

    if (hasDHT22) {
      code += `  dht.begin();\n`;
    }

    if (hasOLED) {
      code += `  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {\n`;
      code += `    Serial.println(F("Fallo al inicializar pantalla OLED"));\n`;
      code += `  } else {\n`;
      code += `    display.clearDisplay();\n`;
      code += `    display.setTextSize(1);\n`;
      code += `    display.setTextColor(SSD1306_WHITE);\n`;
      code += `    display.setCursor(10, 20);\n`;
      code += `    display.println(F("RoboSim AI Pro"));\n`;
      code += `    display.display();\n`;
      code += `  }\n`;
    }

    code += `}\n\n`;

    // LOOP
    code += `void loop() {\n`;

    if (hasHCSR04 && hasL298N) {
      code += `  // 1. Lectura del sensor de distancia\n`;
      code += `  long distancia = medirDistanciaCm();\n`;
      code += `  Serial.print(F("Distancia HC-SR04: "));\n`;
      code += `  Serial.print(distancia);\n`;
      code += `  Serial.println(F(" cm"));\n\n`;
      code += `  // 2. Lógica de navegación y evasión de obstáculos\n`;
      code += `  if (distancia > 0 && distancia < DISTANCIA_UMBRAL_CM) {\n`;
      code += `    Serial.println(F("¡Obstáculo detectado! Maniobra evasiva..."));\n`;
      code += `    detenerMotores();\n`;
      code += `    delay(150);\n`;
      code += `    retroceder(160);\n`;
      code += `    delay(400);\n`;
      code += `    girarDerecha(180);\n`;
      code += `    delay(500);\n`;
      code += `  } else {\n`;
      code += `    avanzar(VELOCIDAD_BASE);\n`;
      code += `  }\n`;
    } else if (hasHCSR04) {
      code += `  long distancia = medirDistanciaCm();\n`;
      code += `  Serial.print(F("Distancia: "));\n`;
      code += `  Serial.print(distancia);\n`;
      code += `  Serial.println(F(" cm"));\n`;
      if (hasSG90) {
        code += `  // Mapear distancia a ángulo del servo (2cm - 50cm -> 0° - 180°)\n`;
        code += `  int angulo = map(constrain(distancia, 5, 45), 5, 45, 0, 180);\n`;
        code += `  servoSG90.write(angulo);\n`;
      }
    } else if (hasSG90 || hasMG996R) {
      code += `  // Barrido cíclico de servomotores\n`;
      code += `  for (int pos = 0; pos <= 180; pos += 10) {\n`;
      if (hasSG90) code += `    servoSG90.write(pos);\n`;
      if (hasMG996R) code += `    servoMG996R.write(180 - pos);\n`;
      code += `    delay(25);\n`;
      code += `  }\n`;
      code += `  for (int pos = 180; pos >= 0; pos -= 10) {\n`;
      if (hasSG90) code += `    servoSG90.write(pos);\n`;
      if (hasMG996R) code += `    servoMG996R.write(180 - pos);\n`;
      code += `    delay(25);\n`;
      code += `  }\n`;
    }

    if (hasDHT22) {
      code += `  float t = dht.readTemperature();\n`;
      code += `  float h = dht.readHumidity();\n`;
      code += `  Serial.print(F("Temp: ")); Serial.print(t); Serial.print(F(" *C | Hum: ")); Serial.println(h);\n`;
      if (hasOLED) {
        code += `  display.clearDisplay();\n`;
        code += `  display.setCursor(0, 0);\n`;
        code += `  display.print(F("Temp: ")); display.print(t); display.println(F(" C"));\n`;
        code += `  display.print(F("Humedad: ")); display.print(h); display.println(F(" %"));\n`;
        code += `  display.display();\n`;
      }
    }

    code += `\n  delay(50); // Tiempo de muestreo\n`;
    code += `}\n\n`;

    // Helper functions
    if (hasHCSR04) {
      code += `// Función para medir distancia en cm con HC-SR04\n`;
      code += `long medirDistanciaCm() {\n`;
      code += `  digitalWrite(PIN_TRIG, LOW);\n`;
      code += `  delayMicroseconds(2);\n`;
      code += `  digitalWrite(PIN_TRIG, HIGH);\n`;
      code += `  delayMicroseconds(10);\n`;
      code += `  digitalWrite(PIN_TRIG, LOW);\n`;
      code += `  long duracion = pulseIn(PIN_ECHO, HIGH, 30000); // Timeout 30ms\n`;
      code += `  if (duracion == 0) return 400; // Sin rebote\n`;
      code += `  return duracion * 0.0343 / 2;\n`;
      code += `}\n\n`;
    }

    if (hasL298N) {
      code += `// Funciones de control de movimiento L298N\n`;
      code += `void avanzar(int vel) {\n`;
      code += `  analogWrite(ENA, vel);\n`;
      code += `  analogWrite(ENB, vel);\n`;
      code += `  digitalWrite(IN1, HIGH);\n`;
      code += `  digitalWrite(IN2, LOW);\n`;
      code += `  digitalWrite(IN3, HIGH);\n`;
      code += `  digitalWrite(IN4, LOW);\n`;
      code += `}\n\n`;
      code += `void retroceder(int vel) {\n`;
      code += `  analogWrite(ENA, vel);\n`;
      code += `  analogWrite(ENB, vel);\n`;
      code += `  digitalWrite(IN1, LOW);\n`;
      code += `  digitalWrite(IN2, HIGH);\n`;
      code += `  digitalWrite(IN3, LOW);\n`;
      code += `  digitalWrite(IN4, HIGH);\n`;
      code += `}\n\n`;
      code += `void girarDerecha(int vel) {\n`;
      code += `  analogWrite(ENA, vel);\n`;
      code += `  analogWrite(ENB, vel);\n`;
      code += `  digitalWrite(IN1, HIGH);\n`;
      code += `  digitalWrite(IN2, LOW);\n`;
      code += `  digitalWrite(IN3, LOW);\n`;
      code += `  digitalWrite(IN4, HIGH);\n`;
      code += `}\n\n`;
      code += `void detenerMotores() {\n`;
      code += `  analogWrite(ENA, 0);\n`;
      code += `  analogWrite(ENB, 0);\n`;
      code += `  digitalWrite(IN1, LOW);\n`;
      code += `  digitalWrite(IN2, LOW);\n`;
      code += `  digitalWrite(IN3, LOW);\n`;
      code += `  digitalWrite(IN4, LOW);\n`;
      code += `}\n`;
    }

    currentGeneratedCode = code;
    return code;
  }

  // Export .ino file to disk or native Android download
  function exportInoFile() {
    if (!currentGeneratedCode) {
      generateInoCode();
    }

    const filename = "RoboSim_Firmware.ino";

    // 1. If running inside Android WebView with Native Bridge
    if (window.AndroidBridge && window.AndroidBridge.exportInoFile) {
      window.AndroidBridge.exportInoFile(filename, currentGeneratedCode);
      return;
    }

    // 2. Standard Web Blob Download
    const blob = new Blob([currentGeneratedCode], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    console.log("Exported .ino file:", filename);
  }

  // Build a complete 3D prototype from natural language prompt
  function buildPrototypeFromPrompt(userPrompt) {
    const promptLower = userPrompt.toLowerCase();
    let matchedPreset = null;

    // Find best match in presets
    for (let preset of AI_PROTOTYPE_PRESETS) {
      for (let kw of preset.keywords) {
        if (promptLower.includes(kw)) {
          matchedPreset = preset;
          break;
        }
      }
      if (matchedPreset) break;
    }

    // Fallback to obstacle avoider if generic
    if (!matchedPreset) {
      matchedPreset = AI_PROTOTYPE_PRESETS[0];
    }

    // Clear existing scene
    window.RoboEngine.clearAll();

    // Assemble new 3D components
    for (let item of matchedPreset.components) {
      const added = window.RoboEngine.addComponent(item.id, item.pos);
      if (added && item.rotY) {
        added.mesh.rotation.y = item.rotY;
      }
    }

    // Adjust camera view
    window.RoboEngine.setCameraView("isometric");

    // Generate matching .ino code immediately
    const ino = generateInoCode();

    const responseText = `🤖 **Prototipo Generado con Éxito:**\n**${matchedPreset.title}**\n\n${matchedPreset.description}\n\n✅ Se han ensamblado **${matchedPreset.components.length} componentes** en la escena 3D con posiciones alineadas y comprobación de colisiones.\n\n💻 He generado el código **.ino** listo para compilar en la pestaña **Código Firmware**.`;

    chatHistory.push({
      sender: "ai",
      text: responseText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    });

    return {
      preset: matchedPreset,
      response: responseText,
      code: ino
    };
  }

  // Answer user chat queries (with Gemini or offline engineering logic)
  function processUserMessage(userText, callback) {
    chatHistory.push({
      sender: "user",
      text: userText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    });

    const lower = userText.toLowerCase();

    // Check if user is asking to build or generate a 3D prototype
    if (lower.includes("crea") || lower.includes("arma") || lower.includes("construye") || lower.includes("prototipo") || lower.includes("diseña") || lower.includes("haz un robot")) {
      const result = buildPrototypeFromPrompt(userText);
      if (callback) callback(result.response);
      return;
    }

    // Check if Android Bridge has Gemini API configured
    if (window.AndroidBridge && window.AndroidBridge.queryGemini) {
      window.AndroidBridge.queryGemini(userText, (aiReply) => {
        chatHistory.push({
          sender: "ai",
          text: aiReply,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        });
        if (callback) callback(aiReply);
      });
      return;
    }

    // Intelligent Embedded Robotics Engineering Knowledge Base (Offline Fallback)
    setTimeout(() => {
      let reply = "";
      if (lower.includes("l298n") || lower.includes("motor")) {
        reply = "⚡ **Conexión recomendada para el Driver L298N:**\n- Conecta la batería externa (7.4V - 12V) a **12V** y **GND**.\n- Une la tierra **GND** del L298N con el **GND del Arduino** (tierra común obligatoria).\n- Si tu batería es < 12V, deja puesto el jumper de 5V integrado para alimentar la lógica interna.\n- Usa pines PWM del Arduino (ej: D5 y D3) para **ENA y ENB** si deseas modular velocidad.";
      } else if (lower.includes("servo") || lower.includes("sg90") || lower.includes("mg996r")) {
        reply = "🦾 **Consejos para Servomotores:**\n- El servo **SG90** consume hasta 650mA en stall, mientras que el **MG996R** puede alcanzar 1.4A.\n- ⚠️ **NUNCA** alimentes más de un servo desde el pin 5V del Arduino, pues provocará reinicios (brownout).\n- Usa una fuente externa de 5V-6V con capacidad mínima de 2A y une las masas (GND común).";
      } else if (lower.includes("hc-sr04") || lower.includes("ultrasonido") || lower.includes("distancia")) {
        reply = "📡 **Sensor Ultrasonido HC-SR04:**\n- Requiere 5V en VCC.\n- Si usas **ESP32** (3.3V), conecta un divisor de tensión en el pin **Echo** (por ejemplo 1kΩ y 2kΩ) para reducir la señal de 5V a 3.3V seguro para el GPIO.";
      } else if (lower.includes("bateria") || lower.includes("consumo") || lower.includes("alimentacion")) {
        reply = "🔋 **Selección de Fuente de Poder:**\n- Para robótica móvil, el mejor equilibrio costo/rendimiento es un pack de **2 celdas Li-Ion 18650 (7.4V 2500mAh)**.\n- Evita usar pilas alcalinas rectangulares de 9V, ya que colapsan ante cualquier demanda de corriente de motores.";
      } else {
        reply = `💡 **Análisis de Diseño RoboSim AI:**\nBasado en los componentes de tu escena, te sugiero revisar la pestaña **Calculador Eléctrico** para asegurar que el consumo pico esté dentro del margen de tu batería.\n\nPuedes presionar **'Exportar a .ino'** para obtener el código C++ completo listo para abrir en Arduino IDE.`;
      }

      chatHistory.push({
        sender: "ai",
        text: reply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      });

      if (callback) callback(reply);
    }, 400);
  }

  return {
    init,
    generateInoCode,
    exportInoFile,
    buildPrototypeFromPrompt,
    processUserMessage,
    getChatHistory: () => chatHistory,
    getCurrentCode: () => currentGeneratedCode
  };
})();
