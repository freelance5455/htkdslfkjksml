
(function () {
    "use strict";

    const COLECAO_RECEITAS = "receitas";
    const COLECAO_PAGAMENTOS = "pagamentos";

    function verificarBanco() {
        if (!window.SGFE_DB) {
            throw new Error("O armazenamento do SGFE não está disponível.");
        }
    }

    function formatarValor(valor) {
        return Number(valor || 0).toLocaleString("pt-AO") + " Kz";
    }

    function escapar(texto) {
        return String(texto ?? "").replace(/[&<>"']/g, function (c) {
            return {
                "&": "&amp;",
                "<": "&lt;",
                ">": "&gt;",
                '"': "&quot;",
                "'": "&#039;"
            }[c];
        });
    }

    function notificar(mensagem) {
        alert(mensagem);
    }

    async function listarReceitas() {
        verificarBanco();
        return await window.SGFE_DB.listar(COLECAO_RECEITAS);
    }

    async function obterReceita(id) {
        verificarBanco();
        return await window.SGFE_DB.obter(COLECAO_RECEITAS, id);
    }

    async function listarPagamentos() {
        verificarBanco();
        return await window.SGFE_DB.listar(COLECAO_PAGAMENTOS);
    }

    async function calcularTotalPago(receitaId) {
        const pagamentos = await listarPagamentos();

        return pagamentos
            .filter(p => p.receitaId === receitaId && p.estado !== "anulado")
            .reduce((total, p) => total + Number(p.valor || 0), 0);
    }

    async function registarReceita(dados) {
        verificarBanco();

        if (!dados || !dados.descricao || !dados.tipo) {
            throw new Error("Preencha os dados obrigatórios da receita.");
        }

        const valor = Number(dados.valor);

        if (!Number.isFinite(valor) || valor <= 0) {
            throw new Error("O valor da receita deve ser superior a zero.");
        }

        const receita = {
            id: window.SGFE_DB.gerarID(),
            descricao: String(dados.descricao).trim(),
            tipo: String(dados.tipo).trim(),
            categoria: dados.tipo,
            valor,
            aluno: dados.aluno || "",
            turma: dados.turma || "",
            referencia: dados.referencia || "",
            data: dados.data || new Date().toISOString().slice(0, 10),
            estado: "pendente",
            criadoEm: new Date().toISOString()
        };

        await window.SGFE_DB.guardar(COLECAO_RECEITAS, receita);

        await window.SGFE_DB.registarHistorico({
            operacao: "criar",
            modulo: "entradas",
            descricao: "Nova receita registada: " + receita.descricao,
            data: new Date().toISOString()
        });

        return receita;
    }

    async function atualizarReceita(id, dados) {
        const receita = await obterReceita(id);

        if (!receita) {
            throw new Error("Receita não encontrada.");
        }

        const valor = Number(dados.valor);

        if (!Number.isFinite(valor) || valor <= 0) {
            throw new Error("O valor previsto deve ser superior a zero.");
        }

        const totalPago = await calcularTotalPago(id);

        if (valor < totalPago) {
            throw new Error(
                "O valor previsto não pode ser inferior ao total já recebido: " +
                formatarValor(totalPago)
            );
        }

        receita.descricao = String(dados.descricao || "").trim();
        receita.tipo = String(dados.tipo || "").trim();
        receita.categoria = receita.tipo;
        receita.valor = valor;
        receita.data = dados.data || receita.data;
        receita.aluno = dados.aluno || "";
        receita.turma = dados.turma || "";
        receita.referencia = dados.referencia || "";

        receita.estado = totalPago >= valor
            ? "pago"
            : totalPago > 0 ? "parcial" : "pendente";

        receita.atualizadoEm = new Date().toISOString();

        await window.SGFE_DB.guardar(COLECAO_RECEITAS, receita);

        await window.SGFE_DB.registarHistorico({
            operacao: "editar",
            modulo: "entradas",
            descricao: "Receita actualizada: " + receita.descricao,
            data: new Date().toISOString()
        });

        return receita;
    }

    async function registarPagamento(dados) {
        if (!dados || !dados.receitaId) {
            throw new Error("É necessário indicar a receita.");
        }

        const receita = await obterReceita(dados.receitaId);

        if (!receita) {
            throw new Error("A receita indicada não foi encontrada.");
        }

        const valor = Number(dados.valor);

        if (!Number.isFinite(valor) || valor <= 0) {
            throw new Error("O valor do pagamento deve ser superior a zero.");
        }

        const totalPago = await calcularTotalPago(receita.id);
        const saldo = Number(receita.valor) - totalPago;

        if (valor > saldo) {
            throw new Error(
                "O pagamento ultrapassa o saldo em dívida. Saldo disponível: " +
                formatarValor(saldo)
            );
        }

        const pagamento = {
            id: window.SGFE_DB.gerarID(),
            receitaId: receita.id,
            descricao: receita.descricao,
            valor,
            data: dados.data || new Date().toISOString().slice(0, 10),
            metodo: dados.metodo || "Dinheiro",
            referencia: dados.referencia || "",
            estado: "confirmado",
            criadoEm: new Date().toISOString()
        };

        await window.SGFE_DB.guardar(COLECAO_PAGAMENTOS, pagamento);

        const novoTotal = totalPago + valor;

        receita.estado = novoTotal >= Number(receita.valor)
            ? "pago"
            : "parcial";

        await window.SGFE_DB.guardar(COLECAO_RECEITAS, receita);

        await window.SGFE_DB.registarHistorico({
            operacao: "pagamento",
            modulo: "entradas",
            descricao: "Pagamento recebido: " + receita.descricao,
            valor,
            data: new Date().toISOString()
        });

        return pagamento;
    }

    async function anularPagamento(id) {
        const pagamentos = await listarPagamentos();
        const pagamento = pagamentos.find(p => p.id === id);

        if (!pagamento) {
            throw new Error("Pagamento não encontrado.");
        }

        if (pagamento.estado === "anulado") {
            throw new Error("Este pagamento já foi anulado.");
        }

        const receita = await obterReceita(pagamento.receitaId);

        if (!receita) {
            throw new Error("A receita associada não foi encontrada.");
        }

        pagamento.estado = "anulado";
        pagamento.anuladoEm = new Date().toISOString();

        await window.SGFE_DB.guardar(COLECAO_PAGAMENTOS, pagamento);

        const totalPago = await calcularTotalPago(receita.id);

        receita.estado = totalPago >= Number(receita.valor)
            ? "pago"
            : totalPago > 0 ? "parcial" : "pendente";

        await window.SGFE_DB.guardar(COLECAO_RECEITAS, receita);

        await window.SGFE_DB.registarHistorico({
            operacao: "anulacao_pagamento",
            modulo: "entradas",
            descricao: "Pagamento anulado: " + receita.descricao,
            valor: pagamento.valor,
            data: new Date().toISOString()
        });

        return pagamento;
    }

    async function calcularSaldo(id) {
        const receita = await obterReceita(id);

        if (!receita) {
            throw new Error("Receita não encontrada.");
        }

        const totalPago = await calcularTotalPago(id);

        return Math.max(0, Number(receita.valor) - totalPago);
    }

    // INTERFACE DO MÓDULO

    function obterConteudo() {
        return document.getElementById("conteudoModulo");
    }

    async function abrir() {
        const conteudo = obterConteudo();

        if (!conteudo) {
            console.error("Área de conteúdo do módulo não encontrada.");
            return;
        }

        const placeholder = document.querySelector(".modulo-placeholder");

        if (placeholder) {
            placeholder.hidden = true;
        }

        conteudo.innerHTML = `
            <div class="entradas-modulo">

                <div class="cabecalho-modulo">
                    <div>
                        <h2>Gestão de Entradas</h2>
                        <p>Registo e controlo das receitas da instituição.</p>
                    </div>
                </div>

                <div class="entradas-indicadores">
                    <div class="cartao-indicador">
                        <span>Total previsto</span>
                        <strong id="entradasPrevisto">0 Kz</strong>
                    </div>

                    <div class="cartao-indicador">
                        <span>Total recebido</span>
                        <strong id="entradasRecebido">0 Kz</strong>
                    </div>

                    <div class="cartao-indicador">
                        <span>Total pendente</span>
                        <strong id="entradasPendente">0 Kz</strong>
                    </div>
                </div>

                <div class="entradas-acoes">
                    <button type="button" id="btnNovaReceita">
                        + Registar entrada
                    </button>

                    <button type="button" id="btnNovoPagamento">
                        + Registar pagamento
                    </button>
                </div>

                <div id="formularioEntrada" class="painel-formulario" hidden>
                    <h3>Registar nova entrada</h3>

                    <form id="formReceita">
                        <div class="formulario-grelha">

                            <label>
                                Descrição
                                <input name="descricao" required
                                    placeholder="Ex.: Mensalidade de Janeiro">
                            </label>

                            <label>
                                Tipo de entrada
                                <select name="tipo" required>
                                    <option value="">Seleccione</option>
                                    <option value="Matrícula">Matrícula</option>
                                    <option value="Mensalidade">Mensalidade</option>
                                    <option value="Cantina">Cantina</option>
                                    <option value="Papelaria">Papelaria</option>
                                    <option value="Outras receitas">Outras receitas</option>
                                </select>
                            </label>

                            <label>
                                Valor previsto (Kz)
                                <input name="valor" type="number" min="1"
                                    step="0.01" required>
                            </label>

                            <label>
                                Data de referência
                                <input name="data" type="date" required>
                            </label>

                            <label>
                                Nome do aluno (opcional)
                                <input name="aluno" placeholder="Nome do aluno">
                            </label>

                            <label>
                                Turma (opcional)
                                <input name="turma" placeholder="Ex.: 10.ª A">
                            </label>

                            <label class="campo-completo">
                                Referência / Observação
                                <input name="referencia"
                                    placeholder="Informação adicional">
                            </label>

                        </div>

                        <div class="botoes-formulario">
                            <button type="submit">Guardar entrada</button>
                            <button type="button" id="btnCancelarReceita">
                                Cancelar
                            </button>
                        </div>
                    </form>
                </div>

                <div id="formularioPagamento" class="painel-formulario" hidden>
                    <h3>Registar pagamento</h3>

                    <form id="formPagamento">
                        <div class="formulario-grelha">

                            <label class="campo-completo">
                                Seleccionar receita
                                <select name="receitaId" id="selectReceita" required>
                                    <option value="">Seleccione uma receita</option>
                                </select>
                            </label>

                            <label>
                                Valor recebido (Kz)
                                <input name="valor" type="number" min="1"
                                    step="0.01" required>
                            </label>

                            <label>
                                Data do pagamento
                                <input name="data" type="date" required>
                            </label>

                            <label>
                                Método de pagamento
                                <select name="metodo">
                                    <option value="Dinheiro">Dinheiro</option>
                                    <option value="Transferência">Transferência</option>
                                    <option value="Multicaixa">Multicaixa</option>
                                    <option value="Outro">Outro</option>
                                </select>
                            </label>

                            <label>
                                Referência (opcional)
                                <input name="referencia"
                                    placeholder="Número do recibo">
                            </label>

                        </div>

                        <div id="saldoReceita" class="informacao-saldo">
                            Seleccione uma receita para consultar o saldo.
                        </div>

                        <div class="botoes-formulario">
                            <button type="submit">Confirmar pagamento</button>
                            <button type="button" id="btnCancelarPagamento">
                                Cancelar
                            </button>
                        </div>
                    </form>
                </div>

                <div id="detalheReceita" class="painel-formulario" hidden></div>

                <div class="painel-tabela">
                    <div class="cabecalho-tabela">
                        <div>
                            <h3>Registo de entradas</h3>
                            <p>Histórico das receitas registadas.</p>
                        </div>

                        <input type="search" id="pesquisaEntradas"
                            placeholder="Pesquisar entrada...">
                    </div>

                    <div class="tabela-deslizante">
                        <table>
                            <thead>
                                <tr>
                                    <th>Data</th>
                                    <th>Descrição</th>
                                    <th>Tipo</th>
                                    <th>Valor previsto</th>
                                    <th>Recebido</th>
                                    <th>Saldo</th>
                                    <th>Estado</th>
                                    <th>Acção</th>
                                </tr>
                            </thead>

                            <tbody id="corpoTabelaEntradas">
                                <tr>
                                    <td colspan="8">A carregar registos...</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>

            </div>
        `;

        document.getElementById("btnNovaReceita").addEventListener(
            "click", () => alternarFormulario("receita")
        );

        document.getElementById("btnNovoPagamento").addEventListener(
            "click", () => alternarFormulario("pagamento")
        );

        document.getElementById("btnCancelarReceita").addEventListener(
            "click", () => alternarFormulario("")
        );

        document.getElementById("btnCancelarPagamento").addEventListener(
            "click", () => alternarFormulario("")
        );

        document.getElementById("formReceita").addEventListener(
            "submit", guardarFormularioReceita
        );

        document.getElementById("formPagamento").addEventListener(
            "submit", guardarFormularioPagamento
        );

        document.getElementById("selectReceita").addEventListener(
            "change", atualizarSaldoSelecionado
        );

        document.getElementById("pesquisaEntradas").addEventListener(
            "input", carregarTabela
        );

        document.getElementById("corpoTabelaEntradas").addEventListener(
            "click", function (evento) {
                const botao = evento.target.closest("[data-consultar]");

                if (botao) {
                    consultarReceita(botao.dataset.consultar);
                }
            }
        );

        await atualizarInterface();
    }

    function alternarFormulario(tipo) {
        document.getElementById("formularioEntrada").hidden =
            tipo !== "receita";

        document.getElementById("formularioPagamento").hidden =
            tipo !== "pagamento";

        if (tipo) {
            fecharDetalhe();
        }
    }

    function fecharDetalhe() {
        const detalhe = document.getElementById("detalheReceita");

        if (detalhe) {
            detalhe.hidden = true;
            detalhe.innerHTML = "";
        }
    }

    async function guardarFormularioReceita(evento) {
        evento.preventDefault();

        const formulario = evento.currentTarget;
        const dados = Object.fromEntries(new FormData(formulario).entries());

        try {
            await registarReceita(dados);
            formulario.reset();
            alternarFormulario("");
            await atualizarInterface();
            notificar("Entrada registada com sucesso!");
        } catch (erro) {
            notificar(erro.message);
        }
    }

    async function guardarFormularioPagamento(evento) {
        evento.preventDefault();

        const formulario = evento.currentTarget;
        const dados = Object.fromEntries(new FormData(formulario).entries());

        try {
            await registarPagamento(dados);
            formulario.reset();
            alternarFormulario("");
            await atualizarInterface();
            notificar("Pagamento registado com sucesso!");
        } catch (erro) {
            notificar(erro.message);
        }
    }

    async function atualizarInterface() {
        await atualizarIndicadores();
        await carregarOpcoesReceitas();
        await carregarTabela();

        if (window.SGFE_PAINEL) {
            await window.SGFE_PAINEL.atualizar();
        }
    }

    async function atualizarIndicadores() {
        const receitas = await listarReceitas();
        const pagamentos = await listarPagamentos();

        const previsto = receitas.reduce(
            (total, r) => total + Number(r.valor || 0), 0
        );

        const recebido = pagamentos
            .filter(p => p.estado !== "anulado")
            .reduce((total, p) => total + Number(p.valor || 0), 0);

        const pendente = Math.max(0, previsto - recebido);

        document.getElementById("entradasPrevisto").textContent =
            formatarValor(previsto);

        document.getElementById("entradasRecebido").textContent =
            formatarValor(recebido);

        document.getElementById("entradasPendente").textContent =
            formatarValor(pendente);
    }

    async function carregarOpcoesReceitas() {
        const select = document.getElementById("selectReceita");
        const receitas = await listarReceitas();

        select.innerHTML = '<option value="">Seleccione uma receita</option>';

        for (const receita of receitas) {
            const saldo = await calcularSaldo(receita.id);

            if (saldo <= 0) continue;

            const opcao = document.createElement("option");
            opcao.value = receita.id;
            opcao.textContent =
                receita.descricao + " — Saldo: " + formatarValor(saldo);

            select.appendChild(opcao);
        }
    }

    async function atualizarSaldoSelecionado() {
        const id = document.getElementById("selectReceita").value;
        const campo = document.getElementById("saldoReceita");

        if (!id) {
            campo.textContent = "Seleccione uma receita para consultar o saldo.";
            return;
        }

        const saldo = await calcularSaldo(id);
        campo.textContent = "Saldo em dívida: " + formatarValor(saldo);
    }

    async function consultarReceita(id) {
        try {
            const receita = await obterReceita(id);

            if (!receita) {
                throw new Error("Não foi possível encontrar esta receita.");
            }

            const pagamentos = await listarPagamentos();

            const historico = pagamentos
                .filter(p => p.receitaId === receita.id)
                .sort((a, b) =>
                    String(b.data || "").localeCompare(String(a.data || ""))
                );

            const recebido = historico
                .filter(p => p.estado !== "anulado")
                .reduce((total, p) => total + Number(p.valor || 0), 0);

            const saldo = Math.max(0, Number(receita.valor || 0) - recebido);

            const estado = saldo <= 0
                ? "Pago"
                : recebido > 0 ? "Parcial" : "Pendente";

            let linhasHistorico = "";

            if (historico.length === 0) {
                linhasHistorico = `
                    <tr>
                        <td colspan="6">
                            Ainda não existem pagamentos registados.
                        </td>
                    </tr>
                `;
            } else {
                for (const pagamento of historico) {
                    const anulado = pagamento.estado === "anulado";

                    const botaoAcao = anulado
                        ? "—"
                        : `<button type="button"
                            data-anular="${escapar(pagamento.id)}">
                            Anular
                           </button>`;

                    linhasHistorico += `
                        <tr>
                            <td>${escapar(pagamento.data || "—")}</td>
                            <td>${escapar(pagamento.metodo || "Não indicado")}</td>
                            <td>${escapar(pagamento.referencia || "—")}</td>
                            <td>${formatarValor(pagamento.valor)}</td>
                            <td>
                                <span class="estado-entrada ${
                                    anulado ? "estado-pendente" : "estado-pago"
                                }">
                                    ${anulado ? "Anulado" : "Confirmado"}
                                </span>
                            </td>
                            <td>${botaoAcao}</td>
                        </tr>
                    `;
                }
            }

            const detalhe = document.getElementById("detalheReceita");

            detalhe.innerHTML = `
                <div class="cabecalho-tabela">
                    <div>
                        <h3>Detalhes da entrada</h3>
                        <p>Consulta individual da receita seleccionada.</p>
                    </div>

                    <div class="botoes-formulario">
                        <button type="button" id="btnEditarReceita">
                            Editar receita
                        </button>

                        <button type="button" id="btnFecharDetalhe">
                            Fechar consulta
                        </button>
                    </div>
                </div>

                <div class="entradas-indicadores">
                    <div class="cartao-indicador">
                        <span>Valor previsto</span>
                        <strong>${formatarValor(receita.valor)}</strong>
                    </div>

                    <div class="cartao-indicador">
                        <span>Total recebido</span>
                        <strong>${formatarValor(recebido)}</strong>
                    </div>

                    <div class="cartao-indicador">
                        <span>Saldo em dívida</span>
                        <strong>${formatarValor(saldo)}</strong>
                    </div>
                </div>

                <div class="formulario-grelha">
                    <label>
                        Descrição
                        <input value="${escapar(receita.descricao)}" readonly>
                    </label>

                    <label>
                        Tipo de entrada
                        <input value="${escapar(receita.tipo)}" readonly>
                    </label>

                    <label>
                        Data de referência
                        <input value="${escapar(receita.data || "—")}" readonly>
                    </label>

                    <label>
                        Estado
                        <input value="${estado}" readonly>
                    </label>

                    <label>
                        Aluno
                        <input value="${escapar(receita.aluno || "Não indicado")}" readonly>
                    </label>

                    <label>
                        Turma
                        <input value="${escapar(receita.turma || "Não indicada")}" readonly>
                    </label>

                    <label class="campo-completo">
                        Referência / Observação
                        <input value="${escapar(receita.referencia || "Sem observações")}" readonly>
                    </label>
                </div>

                <div class="cabecalho-tabela">
                    <div>
                        <h3>Histórico de pagamentos</h3>
                        <p>${historico.length} registo(s) de pagamento.</p>
                    </div>
                </div>

                <div class="tabela-deslizante">
                    <table>
                        <thead>
                            <tr>
                                <th>Data</th>
                                <th>Método</th>
                                <th>Referência</th>
                                <th>Valor</th>
                                <th>Estado</th>
                                <th>Acção</th>
                            </tr>
                        </thead>

                        <tbody>${linhasHistorico}</tbody>
                    </table>
                </div>
            `;

            detalhe.hidden = false;

            document.getElementById("btnFecharDetalhe").addEventListener(
                "click", fecharDetalhe
            );

            document.getElementById("btnEditarReceita").addEventListener(
                "click", () => abrirEdicaoReceita(receita)
            );

            detalhe.querySelectorAll("[data-anular]").forEach(botao => {
                botao.addEventListener("click", async function () {
                    const confirmar = confirm(
                        "Tem a certeza de que pretende anular este pagamento?\n\n" +
                        "O registo será mantido no histórico, mas deixará de contar " +
                        "como valor recebido."
                    );

                    if (!confirmar) return;

                    try {
                        await anularPagamento(botao.dataset.anular);
                        await atualizarInterface();
                        await consultarReceita(receita.id);
                        notificar("Pagamento anulado com sucesso!");
                    } catch (erro) {
                        notificar(erro.message);
                    }
                });
            });

            detalhe.scrollIntoView({
                behavior: "smooth",
                block: "start"
            });

        } catch (erro) {
            notificar(erro.message);
        }
    }

    function abrirEdicaoReceita(receita) {
        const detalhe = document.getElementById("detalheReceita");

        const tipos = [
            "Matrícula",
            "Mensalidade",
            "Cantina",
            "Papelaria",
            "Outras receitas"
        ];

        const opcoesTipo = tipos.map(tipo => `
            <option value="${escapar(tipo)}"
                ${receita.tipo === tipo ? "selected" : ""}>
                ${escapar(tipo)}
            </option>
        `).join("");

        detalhe.innerHTML = `
            <div class="cabecalho-tabela">
                <div>
                    <h3>Editar receita</h3>
                    <p>Altere os dados da entrada seleccionada.</p>
                </div>
            </div>

            <form id="formEditarReceita">
                <div class="formulario-grelha">

                    <label>
                        Descrição
                        <input name="descricao" required
                            value="${escapar(receita.descricao)}">
                    </label>

                    <label>
                        Tipo de entrada
                        <select name="tipo" required>
                            ${opcoesTipo}
                        </select>
                    </label>

                    <label>
                        Valor previsto (Kz)
                        <input name="valor" type="number" min="1"
                            step="0.01" required
                            value="${Number(receita.valor)}">
                    </label>

                    <label>
                        Data de referência
                        <input name="data" type="date" required
                            value="${escapar(receita.data || "")}">
                    </label>

                    <label>
                        Nome do aluno
                        <input name="aluno"
                            value="${escapar(receita.aluno || "")}">
                    </label>

                    <label>
                        Turma
                        <input name="turma"
                            value="${escapar(receita.turma || "")}">
                    </label>

                    <label class="campo-completo">
                        Referência / Observação
                        <input name="referencia"
                            value="${escapar(receita.referencia || "")}">
                    </label>

                </div>

                <div class="botoes-formulario">
                    <button type="submit">Guardar alterações</button>

                    <button type="button" id="btnCancelarEdicao">
                        Cancelar
                    </button>
                </div>
            </form>
        `;

        document.getElementById("btnCancelarEdicao").addEventListener(
            "click", () => consultarReceita(receita.id)
        );

        document.getElementById("formEditarReceita").addEventListener(
            "submit",
            async function (evento) {
                evento.preventDefault();

                const dados = Object.fromEntries(
                    new FormData(evento.currentTarget).entries()
                );

                try {
                    await atualizarReceita(receita.id, dados);
                    await atualizarInterface();
                    await consultarReceita(receita.id);
                    notificar("Receita actualizada com sucesso!");
                } catch (erro) {
                    notificar(erro.message);
                }
            }
        );
    }

    async function carregarTabela() {
        const corpo = document.getElementById("corpoTabelaEntradas");

        if (!corpo) return;

        const receitas = await listarReceitas();
        const pagamentos = await listarPagamentos();

        const pesquisa = document.getElementById("pesquisaEntradas")
            .value.trim().toLowerCase();

        if (receitas.length === 0) {
            corpo.innerHTML = `
                <tr>
                    <td colspan="8">Ainda não existem entradas registadas.</td>
                </tr>
            `;
            return;
        }

        const filtradas = receitas.filter(r =>
            [
                r.descricao,
                r.tipo,
                r.aluno,
                r.turma,
                r.referencia
            ].join(" ").toLowerCase().includes(pesquisa)
        );

        if (filtradas.length === 0) {
            corpo.innerHTML = `
                <tr>
                    <td colspan="8">Nenhum resultado encontrado.</td>
                </tr>
            `;
            return;
        }

        let html = "";

        for (const receita of filtradas) {
            const recebido = pagamentos
                .filter(p =>
                    p.receitaId === receita.id &&
                    p.estado !== "anulado"
                )
                .reduce((total, p) => total + Number(p.valor || 0), 0);

            const saldo = Math.max(0, Number(receita.valor) - recebido);

            const estado = saldo <= 0
                ? "Pago"
                : recebido > 0 ? "Parcial" : "Pendente";

            html += `
                <tr>
                    <td>${escapar(receita.data)}</td>
                    <td>${escapar(receita.descricao)}</td>
                    <td>${escapar(receita.tipo)}</td>
                    <td>${formatarValor(receita.valor)}</td>
                    <td>${formatarValor(recebido)}</td>
                    <td>${formatarValor(saldo)}</td>
                    <td>
                        <span class="estado-entrada estado-${estado.toLowerCase()}">
                            ${estado}
                        </span>
                    </td>
                    <td>
                        <button type="button"
                            data-consultar="${escapar(receita.id)}">
                            Consultar
                        </button>
                    </td>
                </tr>
            `;
        }

        corpo.innerHTML = html;
    }

    window.SGFE_ENTRADAS = Object.freeze({
        registarReceita,
        listarReceitas,
        obterReceita,
        atualizarReceita,
        registarPagamento,
        listarPagamentos,
        anularPagamento,
        calcularSaldo,
        consultarReceita,
        abrir,
        atualizarInterface
    });

})();
