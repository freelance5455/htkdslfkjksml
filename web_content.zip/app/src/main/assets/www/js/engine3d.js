/**
 * RoboSim AI Studio Pro - 3D Simulation Engine (Three.js)
 * Implements OrbitControls, Snap-to-Grid, Magnetic Anchor Snapping, and Mechanical Collision Detection.
 */

window.RoboEngine = (function() {
  let scene, camera, renderer, controls;
  let gridHelper, axesHelper;
  let raycaster, mouse, plane;
  let container;

  // Scene state
  const placedObjects = []; // Array of { id, dbId, name, mesh, dbData, anchorPoints }
  let selectedObject = null;
  let isDragging = false;
  let dragOffset = new THREE.Vector3();

  // Settings
  let snapGridSize = 10; // in mm (1 unit = 10mm in visual scale: 1 unit = 1cm)
  let snapGridEnabled = true;
  let magneticSnapEnabled = true;
  const magneticDistance = 2.5; // units distance for auto snap
  let collisionDetectionEnabled = true;
  let activeCollisions = []; // [{ objA, objB, boxA, boxB, overlap }]

  // Collision highlight material
  const collisionMaterial = new THREE.MeshStandardMaterial({
    color: 0xef4444,
    emissive: 0xef4444,
    emissiveIntensity: 0.6,
    roughness: 0.2,
    transparent: true,
    opacity: 0.75,
    wireframe: false
  });

  // Visual helper for magnetic anchor snapping
  let magneticBeaconMesh = null;

  function init(containerElement) {
    container = containerElement;
    const width = container.clientWidth || window.innerWidth;
    const height = container.clientHeight || window.innerHeight;

    // 1. Scene
    scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0b0f19);
    scene.fog = new THREE.FogExp2(0x0b0f19, 0.008);

    // 2. Camera
    camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    camera.position.set(25, 30, 35);

    // 3. Renderer with hardware acceleration and antialiasing
    renderer = new THREE.WebGLRenderer({
      antialias: true,
      powerPreference: "high-performance",
      alpha: false
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.1;
    container.appendChild(renderer.domElement);

    // 4. Orbit Controls with touch support
    controls = new THREE.OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.06;
    controls.maxPolarAngle = Math.PI / 2 - 0.02; // Don't go below ground
    controls.minDistance = 5;
    controls.maxDistance = 180;
    controls.target.set(0, 2, 0);

    // 5. Lighting
    setupLighting();

    // 6. Grid and Ground Plane
    setupEnvironment();

    // 7. Raycasting & Drag plane
    raycaster = new THREE.Raycaster();
    mouse = new THREE.Vector2();
    plane = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0);

    // 8. Magnetic Beacon visualizer
    const beaconGeo = new THREE.SphereGeometry(0.35, 16, 16);
    const beaconMat = new THREE.MeshBasicMaterial({
      color: 0x06b6d4,
      wireframe: true,
      transparent: true,
      opacity: 0.8
    });
    magneticBeaconMesh = new THREE.Mesh(beaconGeo, beaconMat);
    magneticBeaconMesh.visible = false;
    scene.add(magneticBeaconMesh);

    // 9. Event Listeners
    setupEvents();

    // 10. Start Animation Loop
    animate();

    console.log("RoboSim 3D Engine initialized successfully.");
  }

  function setupLighting() {
    // Ambient light
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.85);
    scene.add(ambientLight);

    // Directional Main Key Light (with shadows)
    const dirLight = new THREE.DirectionalLight(0xffffff, 1.2);
    dirLight.position.set(40, 60, 30);
    dirLight.castShadow = true;
    dirLight.shadow.mapSize.width = 2048;
    dirLight.shadow.mapSize.height = 2048;
    dirLight.shadow.camera.near = 0.5;
    dirLight.shadow.camera.far = 200;
    const d = 50;
    dirLight.shadow.camera.left = -d;
    dirLight.shadow.camera.right = d;
    dirLight.shadow.camera.top = d;
    dirLight.shadow.camera.bottom = -d;
    dirLight.shadow.bias = -0.0005;
    scene.add(dirLight);

    // Fill Light (Cyan blue hue)
    const fillLight = new THREE.DirectionalLight(0x38bdf8, 0.5);
    fillLight.position.set(-30, 20, -30);
    scene.add(fillLight);

    // Ground bounce light
    const hemiLight = new THREE.HemisphereLight(0xffffff, 0x1e293b, 0.4);
    hemiLight.position.set(0, 50, 0);
    scene.add(hemiLight);
  }

  function setupEnvironment() {
    // Interactive Grid with millimeter subdivisions
    gridHelper = new THREE.GridHelper(80, 80, 0x06b6d4, 0x1e293b);
    gridHelper.position.y = 0.01;
    scene.add(gridHelper);

    // Coordinate Axes (Red = X, Green = Y, Blue = Z)
    axesHelper = new THREE.AxesHelper(15);
    axesHelper.position.set(0, 0.02, 0);
    scene.add(axesHelper);

    // Invisible shadow receiver ground
    const shadowPlaneGeo = new THREE.PlaneGeometry(200, 200);
    const shadowPlaneMat = new THREE.ShadowMaterial({ opacity: 0.35 });
    const shadowPlane = new THREE.Mesh(shadowPlaneGeo, shadowPlaneMat);
    shadowPlane.rotation.x = -Math.PI / 2;
    shadowPlane.receiveShadow = true;
    scene.add(shadowPlane);
  }

  function setupEvents() {
    window.addEventListener("resize", onWindowResize);

    const canvas = renderer.domElement;
    canvas.addEventListener("pointerdown", onPointerDown);
    canvas.addEventListener("pointermove", onPointerMove);
    canvas.addEventListener("pointerup", onPointerUp);
  }

  function onWindowResize() {
    if (!container || !camera || !renderer) return;
    const width = container.clientWidth || window.innerWidth;
    const height = container.clientHeight || window.innerHeight;
    camera.aspect = width / height;
    camera.updateProjectionMatrix();
    renderer.setSize(width, height);
  }

  // --- Interaction & Selection ---
  function onPointerDown(e) {
    if (e.target !== renderer.domElement) return;

    updateMouseCoords(e);
    raycaster.setFromCamera(mouse, camera);

    // Raycast against placed meshes
    const meshes = placedObjects.map(o => o.mesh);
    const intersects = raycaster.intersectObjects(meshes, true);

    if (intersects.length > 0) {
      // Find top-level placed object root
      let hitMesh = intersects[0].object;
      let rootObj = null;

      while (hitMesh && hitMesh.parent) {
        rootObj = placedObjects.find(o => o.mesh === hitMesh);
        if (rootObj) break;
        hitMesh = hitMesh.parent;
      }

      if (rootObj) {
        selectObject(rootObj);
        isDragging = true;
        controls.enabled = false; // Disable orbit during object drag

        // Calculate drag offset on ground plane
        const intersectionPoint = new THREE.Vector3();
        raycaster.ray.intersectPlane(plane, intersectionPoint);
        dragOffset.copy(rootObj.mesh.position).sub(intersectionPoint);
        dragOffset.y = 0; // Lock vertical during ground drag
      }
    } else {
      // Clicked on empty space
      if (!isDragging) {
        selectObject(null);
      }
    }
  }

  function onPointerMove(e) {
    updateMouseCoords(e);

    if (isDragging && selectedObject) {
      raycaster.setFromCamera(mouse, camera);
      const intersectionPoint = new THREE.Vector3();

      if (raycaster.ray.intersectPlane(plane, intersectionPoint)) {
        let targetPos = intersectionPoint.add(dragOffset);

        // 1. Snap to Grid
        if (snapGridEnabled && snapGridSize > 0) {
          // snapGridSize in mm; 10mm = 1 Three.js unit
          const gridUnit = snapGridSize / 10;
          targetPos.x = Math.round(targetPos.x / gridUnit) * gridUnit;
          targetPos.z = Math.round(targetPos.z / gridUnit) * gridUnit;
        }

        // 2. Magnetic Anchor Snapping
        if (magneticSnapEnabled) {
          const snapped = checkMagneticSnap(selectedObject, targetPos);
          if (snapped) {
            targetPos.copy(snapped);
          } else {
            magneticBeaconMesh.visible = false;
          }
        }

        selectedObject.mesh.position.x = targetPos.x;
        selectedObject.mesh.position.z = targetPos.z;

        // Check collisions in real time
        if (collisionDetectionEnabled) {
          checkCollisions();
        }

        // Dispatch selection update for inspector UI
        if (window.RoboApp && window.RoboApp.onObjectTransformed) {
          window.RoboApp.onObjectTransformed(selectedObject);
        }
      }
    }
  }

  function onPointerUp(e) {
    if (isDragging) {
      isDragging = false;
      controls.enabled = true;
      magneticBeaconMesh.visible = false;

      // Final collision audit & vibration if collision or magnetic snapped
      if (collisionDetectionEnabled) {
        checkCollisions();
      }
    }
  }

  function updateMouseCoords(e) {
    const rect = renderer.domElement.getBoundingClientRect();
    mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
  }

  // --- Magnetic Snapping Algorithm ---
  function checkMagneticSnap(currentObj, targetPos) {
    if (!currentObj.dbData.anchorPoints || currentObj.dbData.anchorPoints.length === 0) return null;

    let closestDist = Infinity;
    let snapTarget = null;
    let beaconWorldPos = new THREE.Vector3();

    // Check anchors of current object against all other placed objects
    for (let other of placedObjects) {
      if (other.id === currentObj.id) continue;
      if (!other.dbData.anchorPoints) continue;

      for (let anchorA of currentObj.dbData.anchorPoints) {
        // Calculate anchor A world position at targetPos
        const aLocal = new THREE.Vector3(...anchorA.pos).multiplyScalar(0.1); // mm to units
        aLocal.applyEuler(currentObj.mesh.rotation);
        const aWorld = targetPos.clone().add(aLocal);

        for (let anchorB of other.dbData.anchorPoints) {
          const bLocal = new THREE.Vector3(...anchorB.pos).multiplyScalar(0.1);
          bLocal.applyEuler(other.mesh.rotation);
          const bWorld = other.mesh.position.clone().add(bLocal);

          const dist = aWorld.distanceTo(bWorld);

          if (dist < magneticDistance && dist < closestDist) {
            closestDist = dist;
            // Snap target position such that anchor A aligns with anchor B
            snapTarget = bWorld.clone().sub(aLocal);
            beaconWorldPos.copy(bWorld);

            // Trigger haptic feedback if Android bridge available
            if (window.AndroidBridge && window.AndroidBridge.vibrate) {
              window.AndroidBridge.vibrate(25);
            }
          }
        }
      }
    }

    if (snapTarget) {
      magneticBeaconMesh.position.copy(beaconWorldPos);
      magneticBeaconMesh.visible = true;
      return snapTarget;
    }

    return null;
  }

  // --- Mechanical Collision Detection Engine ---
  function checkCollisions() {
    activeCollisions = [];

    // Reset previous collision highlights
    for (let obj of placedObjects) {
      restoreOriginalMaterials(obj);
    }

    // Pairwise AABB check using THREE.Box3
    for (let i = 0; i < placedObjects.length; i++) {
      const objA = placedObjects[i];
      const boxA = new THREE.Box3().setFromObject(objA.mesh);

      // Add a small tolerance margin (0.1 units = 1mm)
      boxA.expandByScalar(-0.05);

      for (let j = i + 1; j < placedObjects.length; j++) {
        const objB = placedObjects[j];
        const boxB = new THREE.Box3().setFromObject(objB.mesh);
        boxB.expandByScalar(-0.05);

        if (boxA.intersectsBox(boxB)) {
          // Calculate intersection box
          const intersectionBox = new THREE.Box3();
          intersectionBox.copy(boxA).intersect(boxB);
          const overlapSize = new THREE.Vector3();
          intersectionBox.getSize(overlapSize);

          activeCollisions.push({
            objA: objA,
            objB: objB,
            overlapSize: overlapSize,
            interferenceVolMm3: Math.round(overlapSize.x * overlapSize.y * overlapSize.z * 1000)
          });

          // Highlight both objects in translucent glowing red
          highlightCollision(objA);
          highlightCollision(objB);

          // Haptic alert on collision
          if (window.AndroidBridge && window.AndroidBridge.vibrate) {
            window.AndroidBridge.vibrate(40);
          }
        }
      }
    }

    // Notify UI
    if (window.RoboApp && window.RoboApp.onCollisionStateChanged) {
      window.RoboApp.onCollisionStateChanged(activeCollisions);
    }

    return activeCollisions;
  }

  function highlightCollision(obj) {
    if (obj.isColliding) return;
    obj.isColliding = true;

    obj.mesh.traverse(child => {
      if (child.isMesh && child !== magneticBeaconMesh) {
        if (!child.userData.origMaterial) {
          child.userData.origMaterial = child.material;
        }
        child.material = collisionMaterial;
      }
    });
  }

  function restoreOriginalMaterials(obj) {
    if (!obj.isColliding) return;
    obj.isColliding = false;

    obj.mesh.traverse(child => {
      if (child.isMesh && child.userData.origMaterial) {
        child.material = child.userData.origMaterial;
        delete child.userData.origMaterial;
      }
    });
  }

  // --- Component Management ---
  function addComponent(dbId, customPosition) {
    const dbData = window.COMPONENTS_DB[dbId];
    if (!dbData) {
      console.error("Component not found in database:", dbId);
      return null;
    }

    const mesh = dbData.createMesh();
    mesh.castShadow = true;
    mesh.receiveShadow = true;

    // Position on ground or at custom coordinate
    if (customPosition) {
      mesh.position.set(customPosition.x, customPosition.y, customPosition.z);
    } else {
      // Find a clear spot with a little offset
      const offset = (placedObjects.length % 5) * 4 - 8;
      mesh.position.set(offset, 0, (placedObjects.length % 3) * 4);
    }

    // Ensure resting on ground
    const bbox = new THREE.Box3().setFromObject(mesh);
    const minY = bbox.min.y;
    if (minY < 0) {
      mesh.position.y -= minY;
    }

    scene.add(mesh);

    const instanceId = dbId + "_" + Date.now().toString(36) + Math.random().toString(36).substr(2, 4);
    const item = {
      id: instanceId,
      dbId: dbId,
      name: dbData.name,
      mesh: mesh,
      dbData: dbData,
      isColliding: false
    };

    placedObjects.push(item);
    selectObject(item);

    // Run collision and electrical check
    checkCollisions();
    if (window.RoboApp && window.RoboApp.onSceneUpdated) {
      window.RoboApp.onSceneUpdated();
    }

    console.log(`Added ${dbData.name} to scene [${instanceId}]. Total: ${placedObjects.length}`);
    return item;
  }

  function removeObject(id) {
    const index = placedObjects.findIndex(o => o.id === id);
    if (index === -1) return;

    const item = placedObjects[index];
    scene.remove(item.mesh);

    if (selectedObject && selectedObject.id === id) {
      selectObject(null);
    }

    placedObjects.splice(index, 1);
    checkCollisions();

    if (window.RoboApp && window.RoboApp.onSceneUpdated) {
      window.RoboApp.onSceneUpdated();
    }
  }

  function clearAll() {
    for (let obj of placedObjects) {
      scene.remove(obj.mesh);
    }
    placedObjects.length = 0;
    selectObject(null);
    checkCollisions();

    if (window.RoboApp && window.RoboApp.onSceneUpdated) {
      window.RoboApp.onSceneUpdated();
    }
  }

  function selectObject(item) {
    // Remove previous selection box
    if (selectedObject && selectedObject.selectionBox) {
      scene.remove(selectedObject.selectionBox);
      selectedObject.selectionBox = null;
    }

    selectedObject = item;

    if (selectedObject) {
      // Add a sleek glowing selection bounding box helper
      const boxHelper = new THREE.BoxHelper(selectedObject.mesh, 0x06b6d4);
      scene.add(boxHelper);
      selectedObject.selectionBox = boxHelper;
    }

    if (window.RoboApp && window.RoboApp.onObjectSelected) {
      window.RoboApp.onObjectSelected(selectedObject);
    }
  }

  function rotateSelected(axis, angleDegrees) {
    if (!selectedObject) return;
    const rad = THREE.MathUtils.degToRad(angleDegrees);

    if (axis === "y") selectedObject.mesh.rotation.y += rad;
    if (axis === "x") selectedObject.mesh.rotation.x += rad;
    if (axis === "z") selectedObject.mesh.rotation.z += rad;

    if (selectedObject.selectionBox) {
      selectedObject.selectionBox.update();
    }

    checkCollisions();
    if (window.RoboApp && window.RoboApp.onObjectTransformed) {
      window.RoboApp.onObjectTransformed(selectedObject);
    }
  }

  function moveSelected(axis, delta) {
    if (!selectedObject) return;
    selectedObject.mesh.position[axis] += delta;

    if (selectedObject.selectionBox) {
      selectedObject.selectionBox.update();
    }

    checkCollisions();
    if (window.RoboApp && window.RoboApp.onObjectTransformed) {
      window.RoboApp.onObjectTransformed(selectedObject);
    }
  }

  // Camera presets
  function setCameraView(preset) {
    if (!camera || !controls) return;
    switch (preset) {
      case "top":
        camera.position.set(0, 50, 0.01);
        controls.target.set(0, 0, 0);
        break;
      case "front":
        camera.position.set(0, 10, 45);
        controls.target.set(0, 2, 0);
        break;
      case "side":
        camera.position.set(45, 10, 0);
        controls.target.set(0, 2, 0);
        break;
      case "isometric":
      default:
        camera.position.set(28, 32, 38);
        controls.target.set(0, 2, 0);
        break;
    }
    controls.update();
  }

  // Main render loop
  function animate() {
    requestAnimationFrame(animate);

    // Update orbit controls
    controls.update();

    // Pulse magnetic beacon if active
    if (magneticBeaconMesh.visible) {
      const scale = 1.0 + 0.2 * Math.sin(Date.now() * 0.008);
      magneticBeaconMesh.scale.set(scale, scale, scale);
    }

    // Update selection box if active
    if (selectedObject && selectedObject.selectionBox) {
      selectedObject.selectionBox.update();
    }

    renderer.render(scene, camera);
  }

  return {
    init,
    addComponent,
    removeObject,
    clearAll,
    selectObject,
    rotateSelected,
    moveSelected,
    setCameraView,
    checkCollisions,
    getPlacedObjects: () => placedObjects,
    getSelectedObject: () => selectedObject,
    getActiveCollisions: () => activeCollisions,
    setSnapGrid: (sizeMm) => {
      snapGridSize = sizeMm;
      snapGridEnabled = sizeMm > 0;
    },
    setMagneticSnap: (enabled) => {
      magneticSnapEnabled = enabled;
    },
    setCollisionDetection: (enabled) => {
      collisionDetectionEnabled = enabled;
      if (!enabled) {
        for (let obj of placedObjects) restoreOriginalMaterials(obj);
        activeCollisions = [];
      } else {
        checkCollisions();
      }
    }
  };
})();
