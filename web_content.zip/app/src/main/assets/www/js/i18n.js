/**
 * আলী আজগর সিদ্দিকিয়া মাদ্রাসা (Ali Azgar Siddiqia Madrasa)
 * Internationalization (i18n) Module - Bengali & English
 */

const LANG_KEY = 'siddiqia_app_lang';

const I18n = {
  currentLang: 'bn',

  translations: {
    bn: {
      // Header & Brand
      brand_title: "আলী আজগর সিদ্দিকিয়া মাদ্রাসা",
      brand_subtitle: "Ali Azgar Siddiqia Madrasa",
      sync_connected: "Supabase সংযুক্ত",
      sync_local: "লোকাল মোড",
      admin_logged_in: "অ্যাডমিন",
      login: "🔐 লগইন",
      logout: "লগআউট",
      switch_lang_btn: "English",

      // Bottom Nav
      nav_home: "হোম",
      nav_members: "সদস্য",
      nav_chanda: "চাঁদা",
      nav_expenses: "খরচ",
      nav_accounts: "হিসাব",
      nav_menu: "মেনু",

      // Dashboard
      hero_headline: "আলী আজগর সিদ্দিকিয়া মাদ্রাসা",
      hero_subtext: "মাসিক চাঁদা সংগ্রহ ও সমন্বিত ডিজিটাল হিসাব ব্যবস্থাপনা",
      hero_rule_label: "নিয়ম:",
      hero_rule_text: "প্রতি মাসের ১ তারিখ থেকে ১০ তারিখের মধ্যে মাসিক চাঁদা জমা দেওয়ার নিয়ম।",
      btn_download_apk: "📥 অ্যান্ড্রয়েড APK ডাউনলোড করুন (Direct APK)",
      financial_overview_title: "চলতি মাসের আর্থিক চিত্র",
      metric_total_collection: "মোট সংগ্রহ",
      metric_sub_collected: "চলতি মাসে আদায়কৃত",
      metric_total_expense: "মোট খরচ",
      metric_sub_expense: "চলতি মাসের ব্যয়",
      metric_current_balance: "বর্তমান স্থিতি/ব্যালেন্স",
      metric_sub_balance: "মোট আদায় - মোট খরচ",
      metric_total_members: "মোট সদস্য",
      metric_sub_members: "নিবন্ধিত সদস্যবৃন্দ",
      metric_paid_members: "চাঁদা পরিশোধিত",
      metric_sub_paid: "চলতি মাসে সম্পূর্ণ",
      metric_unpaid_members: "চাঁদা বকেয়া",
      metric_sub_unpaid: "পরিশোধ অপেক্ষমাণ",
      quick_actions_title: "দ্রুত কার্যক্রম",
      btn_quick_add_member: "সদস্য যোগ",
      btn_quick_chanda: "চাঁদা জমা",
      btn_quick_expense: "খরচ যোগ",
      btn_quick_qr: "পেমেন্ট QR",
      btn_quick_accounts: "মাসিক হিসাব",
      btn_quick_yearly: "বার্ষিক রিপোর্ট",
      notice_board_title: "জরুরি ঘোষণা ও নোটিশ বোর্ড",
      btn_new_notice: "➕ নতুন নোটিশ",
      project_works_title: "মাদ্রাসার চলমান উন্নয়নমূলক কাজ",
      btn_new_project: "➕ নতুন প্রকল্প",

      // Members View
      members_title: "সদস্য তালিকা",
      btn_add_member_top: "➕ নতুন সদস্য",
      search_member_ph: "সদস্যের নাম, নম্বর বা আইডি (M-0001) খুঁজুন...",
      filter_all: "সকল সদস্য",
      filter_paid: "পরিশোধিত",
      filter_unpaid: "বকেয়া সদস্য",
      no_members_found: "কোন সদস্য পাওয়া যায়নি",
      loading_members: "সদস্যদের তথ্য লোড হচ্ছে...",
      status_paid: "পরিশোধিত",
      status_unpaid: "বকেয়া",
      persons_unit: "জন",

      // Add/Edit Member Modal
      modal_add_member_title: "নতুন সদস্য নিবন্ধন",
      modal_edit_member_title: "সদস্যের তথ্য সংশোধন (Edit)",
      lbl_member_name: "সদস্যের পুরো নাম * :",
      ph_member_name: "যেমন: আলহাজ্ব আব্দুল মালেক",
      lbl_member_phone: "মোবাইল ফোন নম্বর :",
      ph_member_phone: "যেমন: 01712345678",
      lbl_member_address: "ঠিকানা :",
      ph_member_address: "গ্রাম/এলাকা/মহল্লা",
      lbl_member_photo: "প্রোফাইল ছবির লিঙ্ক (ঐচ্ছিক):",
      btn_save_member: "সদস্য সংরক্ষণ করুন",
      btn_update_member: "আপডেট সংরক্ষণ করুন",

      // Member Details Modal
      modal_details_title: "সদস্যের বিস্তারিত তথ্য",
      lbl_detail_phone: "ফোন নম্বর:",
      lbl_detail_address: "ঠিকানা:",
      lbl_detail_joindate: "যোগদানের তারিখ:",
      lbl_detail_totalpaid: "মোট জমাকৃত চাঁদা:",
      btn_call: "📞 কল",
      btn_edit: "✏️ তথ্য এডিট",
      btn_delete: "🗑️ মুছুন",
      payment_history_title: "পরিশোধের ইতিহাস",
      no_payment_history: "এখনো কোনো পরিশোধের তথ্য জমা হয়নি।",

      // Chanda View
      chanda_title: "মাসিক চাঁদা গ্রহণ ও ট্র্যাকিং",
      lbl_chanda_month: "হিসাবের মাস নির্বাচন করুন:",
      stat_expected: "প্রত্যাশিত",
      stat_collected: "আদায়কৃত",
      stat_unpaid: "বকেয়া",
      btn_record_pay: "চাঁদা জমা নিন",
      btn_view_receipt: "রসিদ দেখুন",

      // Record Payment Modal
      modal_payment_title: "চাঁদা জমার রশিদ লিপিবদ্ধকরণ",
      lbl_pay_member: "সদস্য নির্বাচন করুন * :",
      lbl_pay_month: "চাঁদার মাস * :",
      lbl_pay_amount: "টাকার পরিমাণ (৳) * :",
      lbl_pay_method: "পেমেন্টের মাধ্যম :",
      lbl_pay_trx: "ট্রানজেকশন আইডি / রেফারেন্স :",
      btn_confirm_pay: "চাঁদা জমা নিশ্চিত করুন",

      // Expenses View
      expenses_title: "মাদ্রাসার খরচের হিসাব (ভাউচার)",
      btn_add_expense_top: "➕ নতুন খরচ",
      total_expense_label: "মোট ব্যয়:",
      no_expenses_found: "এই মাসে কোনো খরচের হিসাব নেই",
      modal_add_expense_title: "নতুন খরচের ভাউচার তৈরি",
      lbl_exp_title: "খরচের খাত / বিবরণ * :",
      ph_exp_title: "যেমন: বিদ্যুৎ বিল / শিক্ষক ভাতা",
      lbl_exp_amount: "খরচের পরিমাণ (৳) * :",
      lbl_exp_cat: "খরচের ক্যাটাগরি :",
      lbl_exp_date: "তারিখ :",
      lbl_exp_note: "অতিরিক্ত মন্তব্য/নোট :",
      btn_save_expense: "খরচ সংরক্ষণ করুন",

      // Monthly Accounts View
      accounts_title: "মাসিক হিসাব বিবরণী",
      lbl_accounts_month: "মাস ও বছর নির্বাচন:",
      formula_label: "হিসাব সূত্র:",
      formula_text: "বর্তমান উদ্বৃত্ত = বিগত মাসের উদ্বৃত্ত + চলতি মাসের মোট আদায় - চলতি মাসের মোট খরচ",
      opening_balance_label: "১. বিগত মাসের উদ্বৃত্ত/জের (Opening Balance):",
      this_month_income_label: "২. চলতি মাসে মোট চাঁদা আদায় (Income):",
      total_funds_label: "৩. মোট তহবিল (১ + ২):",
      this_month_exp_label: "৪. চলতি মাসে মোট খরচ (Expense):",
      closing_balance_label: "৫. মাস শেষে বর্তমান স্থিতি/উদ্বৃত্ত (Closing Balance):",
      btn_print_accounts: "🖨️ পূর্ণাঙ্গ মাসিক হিসাব প্রিন্ট / PDF",

      // Yearly Report View
      yearly_title: "বার্ষিক আয়-ব্যয় ও অডিট রিপোর্ট",
      lbl_select_year: "বছর নির্বাচন:",
      annual_collection: "বার্ষিক মোট চাঁদা আদায়",
      annual_expense: "বার্ষিক মোট ব্যয়",
      annual_net: "বার্ষিক নীট স্থিতি/সঞ্চয়",
      month_wise_table: "মাসভিত্তিক পূর্ণাঙ্গ আয়-ব্যয় খতিয়ান",
      col_month: "মাস",
      col_income: "আদায়",
      col_expense: "ব্যয়",
      col_balance: "উদ্বৃত্ত",
      btn_print_yearly: "🖨️ বার্ষিক অডিট রিপোর্ট প্রিন্ট",

      // Settings View
      settings_title: "মাদ্রাসা সেটিংস ও মেনু",
      madrasa_info_card: "মাদ্রাসার মৌলিক তথ্য ও প্রোফাইল",
      lbl_info_name: "মাদ্রাসার নাম:",
      lbl_info_est: "স্থাপিত:",
      lbl_info_addr: "ঠিকানা:",
      lbl_info_phone: "যোগাযোগ:",
      lang_card_title: "🌐 ভাষা নির্বাচন / Choose Language",
      supabase_sync_card: "সুপাবেস (Supabase) ক্লাউড সিঙ্ক",
      supabase_desc: "আপনার নিজস্ব Supabase ডাটাবেজে সকল সদস্য, চাঁদা ও খরচের তথ্য রিয়েল-টাইমে ক্লাউডে সংরক্ষণ করুন।",
      lbl_sb_url: "Supabase Project URL :",
      lbl_sb_key: "Supabase Anon Public API Key :",
      btn_save_supabase: "💾 সংরক্ষণ ও সংযোগ পরীক্ষা",
      btn_copy_sql: "📋 Supabase SQL কপি করুন (Copy SQL)",
      sql_help_text: "Supabase এ টেবিল ও পারমিশন কাজ না করলে এই বাটনে চাপ দিয়ে SQL কপি করে Supabase SQL Editor এ Run চাপুন।",
      chanda_rules_card: "চাঁদা নীতি ও সময়সীমা",
      lbl_rule_amount: "ডিফল্ট মাসিক চাঁদা (টাকা):",
      lbl_rule_start: "চাঁদা জমার শুরুর দিন (তারিখ):",
      lbl_rule_end: "চাঁদা জমার শেষ দিন (তারিখ):",
      btn_save_rules: "নিয়মাবলী সংরক্ষণ করুন",
      danger_zone_card: "ডেটা রিসেট ও ব্যাকআপ",
      btn_export_json: "💾 সমস্ত ডেটা ব্যাকআপ নিন (JSON Export)",
      btn_reset_data: "⚠️ সমস্ত লোকাল ডেটা রিসেট করুন",

      // Receipt Modal
      receipt_modal_title: "আলী আজগর সিদ্দিকিয়া মাদ্রাসা - চাঁদার রসিদ",
      receipt_tagline: "অফিসিয়াল মানি রিসিট ও দান স্বীকারপত্র",
      lbl_rec_no: "রসিদ নম্বর:",
      lbl_rec_date: "তারিখ:",
      lbl_rec_name: "সদস্যের নাম:",
      lbl_rec_id: "সদস্য আইডি:",
      lbl_rec_phone: "মোবাইল নম্বর:",
      lbl_rec_month: "চাঁদার মাস:",
      lbl_rec_method: "পরিশোধের মাধ্যম:",
      lbl_rec_amount: "জমাকৃত চাঁদা:",
      btn_print_receipt: "🖨️ রসিদ প্রিন্ট করুন",

      // Messages & Toasts
      msg_member_added: "সদস্য সফলভাবে যুক্ত করা হয়েছে",
      msg_member_updated: "সদস্যের তথ্য সফলভাবে আপডেট করা হয়েছে",
      msg_member_deleted: "সদস্য সফলভাবে মুছে ফেলা হয়েছে",
      msg_payment_recorded: "চাঁদা জমা সফলভাবে সম্পন্ন হয়েছে",
      msg_expense_added: "খরচের হিসাব যুক্ত হয়েছে",
      msg_notice_added: "নোটিশ সফলভাবে প্রকাশিত হয়েছে",
      msg_project_added: "নতুন প্রকল্প সফলভাবে যুক্ত হয়েছে",
      msg_supabase_saved: "Supabase কনফিগারেশন সফলভাবে সংরক্ষিত ও সংযুক্ত হয়েছে!",
      msg_sql_copied: "Supabase SQL ক্লিপবোর্ডে কপি করা হয়েছে! Supabase SQL Editor এ পেস্ট করে Run করুন।",
      msg_confirm_delete: "আপনি কি নিশ্চিতভাবে এই সদস্যকে মুছে ফেলতে চান?"
    },

    en: {
      // Header & Brand
      brand_title: "Ali Azgar Siddiqia Madrasa",
      brand_subtitle: "Digital Management & Chanda Tracker",
      sync_connected: "Supabase Connected",
      sync_local: "Local Mode",
      admin_logged_in: "Admin",
      login: "🔐 Login",
      logout: "Logout",
      switch_lang_btn: "বাংলা",

      // Bottom Nav
      nav_home: "Home",
      nav_members: "Members",
      nav_chanda: "Chanda",
      nav_expenses: "Expenses",
      nav_accounts: "Accounts",
      nav_menu: "Menu",

      // Dashboard
      hero_headline: "Ali Azgar Siddiqia Madrasa",
      hero_subtext: "Monthly Chanda Collection & Integrated Digital Financial System",
      hero_rule_label: "Rule:",
      hero_rule_text: "Monthly chanda collection period: 1st to 10th of every month.",
      btn_download_apk: "📥 Download Android APK (Direct APK)",
      financial_overview_title: "Current Month Financial Overview",
      metric_total_collection: "Total Collection",
      metric_sub_collected: "Collected this month",
      metric_total_expense: "Total Expense",
      metric_sub_expense: "Spent this month",
      metric_current_balance: "Current Balance",
      metric_sub_balance: "Total Income - Expense",
      metric_total_members: "Total Members",
      metric_sub_members: "Registered members",
      metric_paid_members: "Chanda Paid",
      metric_sub_paid: "Paid for this month",
      metric_unpaid_members: "Chanda Due",
      metric_sub_unpaid: "Payment pending",
      quick_actions_title: "Quick Actions",
      btn_quick_add_member: "Add Member",
      btn_quick_chanda: "Pay Chanda",
      btn_quick_expense: "Add Expense",
      btn_quick_qr: "Payment QR",
      btn_quick_accounts: "Accounts",
      btn_quick_yearly: "Annual Report",
      notice_board_title: "Notice Board & Announcements",
      btn_new_notice: "➕ New Notice",
      project_works_title: "Madrasa Development Projects",
      btn_new_project: "➕ New Project",

      // Members View
      members_title: "Members List",
      btn_add_member_top: "➕ New Member",
      search_member_ph: "Search member name, phone or ID (M-0001)...",
      filter_all: "All Members",
      filter_paid: "Paid",
      filter_unpaid: "Due Members",
      no_members_found: "No members found",
      loading_members: "Loading members...",
      status_paid: "Paid",
      status_unpaid: "Due",
      persons_unit: "members",

      // Add/Edit Member Modal
      modal_add_member_title: "Register New Member",
      modal_edit_member_title: "Edit Member Information",
      lbl_member_name: "Member Full Name * :",
      ph_member_name: "e.g. Alhaj Abdul Malek",
      lbl_member_phone: "Mobile Phone Number :",
      ph_member_phone: "e.g. 01712345678",
      lbl_member_address: "Address :",
      ph_member_address: "Village / Area / Post",
      lbl_member_photo: "Profile Photo URL (Optional):",
      btn_save_member: "Save Member",
      btn_update_member: "Update Member",

      // Member Details Modal
      modal_details_title: "Member Details",
      lbl_detail_phone: "Phone Number:",
      lbl_detail_address: "Address:",
      lbl_detail_joindate: "Join Date:",
      lbl_detail_totalpaid: "Total Chanda Paid:",
      btn_call: "📞 Call",
      btn_edit: "✏️ Edit Info",
      btn_delete: "🗑️ Delete",
      payment_history_title: "Payment History",
      no_payment_history: "No payment history recorded yet.",

      // Chanda View
      chanda_title: "Monthly Chanda Collection & Tracking",
      lbl_chanda_month: "Select Month:",
      stat_expected: "Expected",
      stat_collected: "Collected",
      stat_unpaid: "Due",
      btn_record_pay: "Collect Chanda",
      btn_view_receipt: "View Receipt",

      // Record Payment Modal
      modal_payment_title: "Record Chanda Payment Receipt",
      lbl_pay_member: "Select Member * :",
      lbl_pay_month: "Chanda Month * :",
      lbl_pay_amount: "Amount (৳) * :",
      lbl_pay_method: "Payment Method :",
      lbl_pay_trx: "Transaction ID / Reference :",
      btn_confirm_pay: "Confirm Payment",

      // Expenses View
      expenses_title: "Madrasa Expenses & Vouchers",
      btn_add_expense_top: "➕ New Expense",
      total_expense_label: "Total Expense:",
      no_expenses_found: "No expenses recorded for this month",
      modal_add_expense_title: "Create Expense Voucher",
      lbl_exp_title: "Expense Purpose / Title * :",
      ph_exp_title: "e.g. Electricity Bill / Teacher Salary",
      lbl_exp_amount: "Amount (৳) * :",
      lbl_exp_cat: "Expense Category :",
      lbl_exp_date: "Date :",
      lbl_exp_note: "Additional Notes :",
      btn_save_expense: "Save Expense",

      // Monthly Accounts View
      accounts_title: "Monthly Financial Statement",
      lbl_accounts_month: "Select Month & Year:",
      formula_label: "Formula:",
      formula_text: "Closing Balance = Opening Balance + Total Income - Total Expense",
      opening_balance_label: "1. Previous Month Carryforward (Opening Balance):",
      this_month_income_label: "2. Current Month Total Chanda (Income):",
      total_funds_label: "3. Total Available Funds (1 + 2):",
      this_month_exp_label: "4. Current Month Total Expense:",
      closing_balance_label: "5. Month-end Net Balance (Closing Balance):",
      btn_print_accounts: "🖨️ Print / Save Statement (PDF)",

      // Yearly Report View
      yearly_title: "Annual Financial & Audit Report",
      lbl_select_year: "Select Year:",
      annual_collection: "Total Annual Chanda",
      annual_expense: "Total Annual Expense",
      annual_net: "Annual Net Savings",
      month_wise_table: "Month-by-Month Statement",
      col_month: "Month",
      col_income: "Income",
      col_expense: "Expense",
      col_balance: "Balance",
      btn_print_yearly: "🖨️ Print Annual Audit Report",

      // Settings View
      settings_title: "Madrasa Settings & Menu",
      madrasa_info_card: "Madrasa Profile & Information",
      lbl_info_name: "Madrasa Name:",
      lbl_info_est: "Established:",
      lbl_info_addr: "Address:",
      lbl_info_phone: "Contact:",
      lang_card_title: "🌐 Select Language / ভাষা নির্বাচন",
      supabase_sync_card: "Supabase Cloud Synchronization",
      supabase_desc: "Synchronize all members, payments, and expenses in real-time to your Supabase PostgreSQL cloud database.",
      lbl_sb_url: "Supabase Project URL :",
      lbl_sb_key: "Supabase Anon Public API Key :",
      btn_save_supabase: "💾 Save & Test Connection",
      btn_copy_sql: "📋 Copy Supabase SQL (Copy SQL)",
      sql_help_text: "If Supabase tables or permissions block inserts, click this button to copy the SQL script and run it in Supabase SQL Editor.",
      chanda_rules_card: "Chanda Policy & Timeline",
      lbl_rule_amount: "Default Monthly Chanda (৳):",
      lbl_rule_start: "Chanda Collection Start Day:",
      lbl_rule_end: "Chanda Collection End Day:",
      btn_save_rules: "Save Policy Settings",
      danger_zone_card: "Data Backup & Reset",
      btn_export_json: "💾 Backup All Data (JSON Export)",
      btn_reset_data: "⚠️ Reset All Local Data",

      // Receipt Modal
      receipt_modal_title: "Ali Azgar Siddiqia Madrasa - Chanda Receipt",
      receipt_tagline: "Official Money Receipt & Contribution Acknowledgment",
      lbl_rec_no: "Receipt No:",
      lbl_rec_date: "Date:",
      lbl_rec_name: "Member Name:",
      lbl_rec_id: "Member ID:",
      lbl_rec_phone: "Mobile Phone:",
      lbl_rec_month: "Chanda Month:",
      lbl_rec_method: "Payment Method:",
      lbl_rec_amount: "Amount Paid:",
      btn_print_receipt: "🖨️ Print Receipt",

      // Messages & Toasts
      msg_member_added: "Member added successfully",
      msg_member_updated: "Member updated successfully",
      msg_member_deleted: "Member deleted successfully",
      msg_payment_recorded: "Chanda payment recorded successfully",
      msg_expense_added: "Expense recorded successfully",
      msg_notice_added: "Notice published successfully",
      msg_project_added: "Project added successfully",
      msg_supabase_saved: "Supabase credentials saved and connected successfully!",
      msg_sql_copied: "Supabase SQL script copied to clipboard! Paste and Run in Supabase SQL Editor.",
      msg_confirm_delete: "Are you sure you want to delete this member?"
    }
  },

  init() {
    const saved = localStorage.getItem(LANG_KEY);
    if (saved === 'en' || saved === 'bn') {
      this.currentLang = saved;
    } else {
      this.currentLang = 'bn';
    }
    this.applyLanguage(this.currentLang);
  },

  get(key, fallback = '') {
    const langDict = this.translations[this.currentLang] || this.translations.bn;
    return langDict[key] || this.translations.bn[key] || fallback || key;
  },

  setLanguage(lang) {
    if (lang !== 'bn' && lang !== 'en') return;
    this.currentLang = lang;
    localStorage.setItem(LANG_KEY, lang);
    this.applyLanguage(lang);
    if (window.App && typeof window.App.onLanguageChange === 'function') {
      window.App.onLanguageChange(lang);
    }
  },

  toggleLanguage() {
    const nextLang = this.currentLang === 'bn' ? 'en' : 'bn';
    this.setLanguage(nextLang);
    return nextLang;
  },

  applyLanguage(lang) {
    document.documentElement.lang = lang;

    // 1. Text elements with data-i18n
    document.querySelectorAll('[data-i18n]').forEach(el => {
      const key = el.getAttribute('data-i18n');
      const translation = this.get(key);
      if (translation) {
        el.textContent = translation;
      }
    });

    // 2. Placeholder elements with data-i18n-ph
    document.querySelectorAll('[data-i18n-ph]').forEach(el => {
      const key = el.getAttribute('data-i18n-ph');
      const translation = this.get(key);
      if (translation) {
        el.setAttribute('placeholder', translation);
      }
    });

    // 3. Update Language Switcher label in header
    const langLabel = document.getElementById('lang-label');
    if (langLabel) {
      langLabel.textContent = lang === 'bn' ? 'বাংলা (BN)' : 'English (EN)';
    }

    // 4. Update language active buttons if in settings
    document.querySelectorAll('.lang-select-btn').forEach(btn => {
      if (btn.dataset.lang === lang) {
        btn.classList.add('active');
      } else {
        btn.classList.remove('active');
      }
    });
  }
};

window.I18n = I18n;
