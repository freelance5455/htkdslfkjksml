
/* ============================================
   SGFE - SISTEMA DE GESTÃO FINANCEIRA ESCOLAR
   MÓDULO DE ARMAZENAMENTO LOCAL
   Tecnologia: IndexedDB
============================================ */

(function () {
    "use strict";

    const NOME_BANCO = "SGFE_Banco_Local";
    const VERSAO_BANCO = 1;

    const COLECOES = [
        "receitas",
        "pagamentos",
        "turmas",
        "funcionarios",
        "salarios",
        "despesas",
        "categorias",
        "servicos",
        "configuracoes",
        "historico"
    ];

    let banco = null;
    let inicializacao = null;


    /* 1. IDENTIFICADOR ÚNICO */

    function gerarID() {
        if (crypto.randomUUID) {
            return crypto.randomUUID();
        }

        return "SGFE-" +
            Date.now() + "-" +
            Math.random().toString(36).substring(2, 10);
    }


    /* 2. ABRIR A BASE DE ARMAZENAMENTO */

    function iniciar() {

        if (banco) {
            return Promise.resolve(banco);
        }

        if (inicializacao) {
            return inicializacao;
        }

        inicializacao = new Promise((resolve, reject) => {

            if (!("indexedDB" in window)) {
                inicializacao = null;

                reject(new Error(
                    "Este navegador não suporta armazenamento IndexedDB."
                ));

                return;
            }

            const pedido = indexedDB.open(
                NOME_BANCO,
                VERSAO_BANCO
            );

            pedido.onupgradeneeded = function (evento) {

                const db = evento.target.result;

                COLECOES.forEach(nome => {

                    if (!db.objectStoreNames.contains(nome)) {

                        const armazenamento = db.createObjectStore(
                            nome,
                            { keyPath: "id" }
                        );

                        armazenamento.createIndex(
                            "data",
                            "data",
                            { unique: false }
                        );

                        armazenamento.createIndex(
                            "estado",
                            "estado",
                            { unique: false }
                        );

                        armazenamento.createIndex(
                            "criadoEm",
                            "criadoEm",
                            { unique: false }
                        );

                    }

                });

            };


            pedido.onsuccess = function (evento) {

                banco = evento.target.result;

                banco.onversionchange = function () {
                    banco.close();
                    banco = null;
                    inicializacao = null;
                };

                banco.onclose = function () {
                    banco = null;
                    inicializacao = null;
                };

                resolve(banco);

            };


            pedido.onerror = function () {

                inicializacao = null;

                reject(
                    pedido.error ||
                    new Error("Não foi possível abrir o armazenamento.")
                );

            };


            pedido.onblocked = function () {

                console.warn(
                    "O armazenamento está bloqueado por outra janela."
                );

            };

        });

        return inicializacao;

    }


    /* 3. EXECUTAR OPERAÇÕES */

    async function executar(nome, modo, operacao) {

        const db = await iniciar();

        return new Promise((resolve, reject) => {

            let resultado;

            const transacao = db.transaction(nome, modo);
            const armazenamento = transacao.objectStore(nome);

            try {

                resultado = operacao(armazenamento);

            } catch (erro) {

                try {
                    transacao.abort();
                } catch (_) {}

                reject(erro);
                return;

            }

            transacao.oncomplete = function () {
                resolve(resultado);
            };

            transacao.onerror = function () {
                reject(
                    transacao.error ||
                    new Error("Erro ao executar operação.")
                );
            };

            transacao.onabort = function () {
                reject(
                    transacao.error ||
                    new Error("Operação cancelada.")
                );
            };

        });

    }


    /* 4. GUARDAR REGISTOS */

    async function guardar(nome, dados) {

        verificarColecao(nome);

        if (!dados || typeof dados !== "object" ||
            Array.isArray(dados)) {

            throw new Error("Os dados fornecidos são inválidos.");

        }

        const registo = { ...dados };

        if (registo.id === undefined || registo.id === null) {
            registo.id = gerarID();
        }

        if (!registo.criadoEm) {
            registo.criadoEm = new Date().toISOString();
        }

        registo.atualizadoEm = new Date().toISOString();

        await executar(nome, "readwrite", armazenamento => {
            armazenamento.put(registo);
        });

        return registo;

    }


    /* 5. CONSULTAR TODOS OS REGISTOS */

    async function listar(nome) {

        verificarColecao(nome);

        return executar(nome, "readonly", armazenamento => {

            return new Promise((resolve, reject) => {

                const pedido = armazenamento.getAll();

                pedido.onsuccess = () => resolve(pedido.result);
                pedido.onerror = () => reject(pedido.error);

            });

        });

    }


    /* 6. CONSULTAR UM REGISTO */

    async function obter(nome, id) {

        verificarColecao(nome);

        return executar(nome, "readonly", armazenamento => {

            return new Promise((resolve, reject) => {

                const pedido = armazenamento.get(id);

                pedido.onsuccess = () => {
                    resolve(pedido.result || null);
                };

                pedido.onerror = () => reject(pedido.error);

            });

        });

    }


    /* 7. ELIMINAR UM REGISTO */

    async function eliminar(nome, id) {

        verificarColecao(nome);

        await executar(nome, "readwrite", armazenamento => {
            armazenamento.delete(id);
        });

        return true;

    }


    /* 8. PESQUISAR REGISTOS */

    async function pesquisar(nome, campo, valor) {

        verificarColecao(nome);

        const dados = await listar(nome);

        return dados.filter(registo => {

            return String(registo[campo] ?? "")
                .toLowerCase()
                .includes(String(valor).toLowerCase());

        });

    }


    /* 9. VERIFICAR COLEÇÃO */

    function verificarColecao(nome) {

        if (!COLECOES.includes(nome)) {

            throw new Error(
                "Coleção não autorizada: " + nome
            );

        }

    }


    /* 10. CRIAR CÓPIA DE SEGURANÇA */

    async function criarBackup() {

        const db = await iniciar();

        const copia = {
            sistema: "SGFE",
            versao: VERSAO_BANCO,
            dataCriacao: new Date().toISOString(),
            dados: {}
        };

        for (const nome of COLECOES) {
            copia.dados[nome] = await listar(nome);
        }

        const conteudo = JSON.stringify(copia, null, 2);

        const ficheiro = new Blob(
            [conteudo],
            { type: "application/json" }
        );

        const url = URL.createObjectURL(ficheiro);

        const link = document.createElement("a");

        const data = new Date()
            .toISOString()
            .replace(/[:.]/g, "-");

        link.href = url;
        link.download = "SGFE_Backup_" + data + ".json";

        document.body.appendChild(link);
        link.click();
        link.remove();

        setTimeout(() => URL.revokeObjectURL(url), 1000);

        return true;

    }


    /* 11. RESTAURAR CÓPIA DE SEGURANÇA */

    async function restaurarBackup(ficheiro, substituir = false) {

        if (!ficheiro) {
            throw new Error("Nenhum ficheiro foi seleccionado.");
        }

        const conteudo = await ficheiro.text();

        let copia;

        try {
            copia = JSON.parse(conteudo);
        } catch (_) {
            throw new Error("O ficheiro não contém um JSON válido.");
        }

        if (
            copia.sistema !== "SGFE" ||
            !copia.dados ||
            typeof copia.dados !== "object"
        ) {
            throw new Error("Este ficheiro não é uma cópia válida do SGFE.");
        }

        const db = await iniciar();

        const nomes = COLECOES.filter(nome =>
            Object.prototype.hasOwnProperty.call(copia.dados, nome)
        );

        if (nomes.length === 0) {
            throw new Error("A cópia não contém dados reconhecidos.");
        }

        for (const nome of nomes) {

            if (!Array.isArray(copia.dados[nome])) {
                throw new Error(
                    "Dados inválidos na coleção: " + nome
                );
            }

            for (const registo of copia.dados[nome]) {

                if (
                    !registo ||
                    typeof registo !== "object" ||
                    Array.isArray(registo) ||
                    registo.id === undefined ||
                    registo.id === null
                ) {
                    throw new Error(
                        "Foi encontrado um registo inválido em " + nome
                    );
                }

            }

        }

        const transacao = db.transaction(nomes, "readwrite");

        return new Promise((resolve, reject) => {

            let erro = null;

            transacao.oncomplete = () => {
                resolve({
                    sucesso: true,
                    colecoes: nomes,
                    modo: substituir ? "substituir" : "integrar"
                });
            };

            transacao.onerror = () => {
                erro = transacao.error;
            };

            transacao.onabort = () => {
                reject(
                    erro ||
                    transacao.error ||
                    new Error("Não foi possível restaurar a cópia.")
                );
            };

            nomes.forEach(nome => {

                const armazenamento =
                    transacao.objectStore(nome);

                if (substituir) {
                    armazenamento.clear();
                }

                copia.dados[nome].forEach(registo => {
                    armazenamento.put(registo);
                });

            });

        });

    }


    /* 12. HISTÓRICO DE OPERAÇÕES */

    async function registarHistorico(dados) {

        const registo = {
            tipo: dados.tipo || "Alteração",
            modulo: dados.modulo || "Sistema",
            descricao: dados.descricao || "",
            valor: Number(dados.valor) || 0,
            motivo: dados.motivo || "",
            data: new Date().toISOString()
        };

        return guardar("historico", registo);

    }


    /* 13. CONSULTAR ESTADO DO ARMAZENAMENTO */

    async function verificarArmazenamento() {

        const db = await iniciar();

        return {
            disponivel: true,
            nome: db.name,
            versao: db.version,
            colecoes: COLECOES.length,
            armazenamento: "IndexedDB",
            offline: !navigator.onLine
        };

    }


    /* 14. DISPONIBILIZAR FUNÇÕES À APLICAÇÃO */

    window.SGFE_DB = Object.freeze({

        iniciar,
        gerarID,

        guardar,
        listar,
        obter,
        eliminar,
        pesquisar,

        criarBackup,
        restaurarBackup,

        registarHistorico,
        verificarArmazenamento,

        colecoes: [...COLECOES]

    });


    /* 15. INICIALIZAÇÃO AUTOMÁTICA */

    iniciar()
        .then(() => {

            console.info(
                "SGFE: armazenamento local iniciado com sucesso."
            );

        })
        .catch(erro => {

            console.error(
                "SGFE: erro ao iniciar armazenamento.",
                erro
            );

        });

})();
