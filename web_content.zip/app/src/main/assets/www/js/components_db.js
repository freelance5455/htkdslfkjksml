/**
 * RoboSim AI Studio Pro - Database of 3D Components & Specifications
 * Contains procedural 3D model generators, electrical metadata, and magnetic anchor points.
 */

window.COMPONENTS_DB = {
  // ==========================================
  // LOCAL STANDARD COMPONENTS
  // ==========================================
  "arduino_uno": {
    id: "arduino_uno",
    name: "Arduino Uno R3",
    category: "Microcontroladores",
    description: "Placa de desarrollo con microcontrolador ATmega328P de 16MHz, 14 pines I/O digitales y 6 analógicos.",
    specs: {
      voltage: 5.0,
      inputVoltageRange: "7-12V DC (Barrel) o 5V USB",
      idleCurrent: 45, // mA
      peakCurrent: 80, // mA
      maxPinCurrent: 40, // mA por pin (máx 200mA total)
      isPowerSource: false,
      isController: true,
      pins: ["D0/RX", "D1/TX", "D2", "D3~", "D4", "D5~", "D6~", "D7", "D8", "D9~", "D10~", "D11~", "D12", "D13/LED", "A0", "A1", "A2", "A3", "A4/SDA", "A5/SCL", "5V", "3.3V", "GND", "VIN"]
    },
    dimensions: { x: 68.6, y: 15.0, z: 53.4 }, // mm
    anchorPoints: [
      { id: "hole1", pos: [-26, 0, -22], type: "mount_m3" },
      { id: "hole2", pos: [26, 0, -24], type: "mount_m3" },
      { id: "hole3", pos: [26, 0, 24], type: "mount_m3" },
      { id: "hole4", pos: [-24, 0, 14], type: "mount_m3" },
      { id: "usb_port", pos: [-34, 5, -16], type: "usb_b" },
      { id: "header_digital", pos: [0, 8, -25], type: "pin_header_female" },
      { id: "header_analog", pos: [12, 8, 25], type: "pin_header_female" }
    ],
    createMesh: function() {
      const group = new THREE.Group();
      group.name = "Arduino Uno R3";

      // PCB Principal (Azul oscuro Arduino)
      const pcbGeo = new THREE.BoxGeometry(6.86, 0.16, 5.34);
      const pcbMat = new THREE.MeshStandardMaterial({
        color: 0x00646e,
        roughness: 0.3,
        metalness: 0.1
      });
      const pcb = new THREE.Mesh(pcbGeo, pcbMat);
      pcb.castShadow = true;
      pcb.receiveShadow = true;
      group.add(pcb);

      // Microcontrolador ATmega328P DIP-28
      const mcuGeo = new THREE.BoxGeometry(3.5, 0.35, 0.8);
      const mcuMat = new THREE.MeshStandardMaterial({ color: 0x18181b, roughness: 0.6 });
      const mcu = new THREE.Mesh(mcuGeo, mcuMat);
      mcu.position.set(0.6, 0.25, 1.2);
      mcu.castShadow = true;
      group.add(mcu);

      // Conector USB-B (Plateado metálico)
      const usbGeo = new THREE.BoxGeometry(1.2, 1.1, 1.2);
      const metalMat = new THREE.MeshStandardMaterial({ color: 0xd4d4d8, metalness: 0.85, roughness: 0.2 });
      const usb = new THREE.Mesh(usbGeo, metalMat);
      usb.position.set(-2.8, 0.63, -1.6);
      usb.castShadow = true;
      group.add(usb);

      // Jack de Alimentación DC Barrel (Negro)
      const jackGeo = new THREE.BoxGeometry(1.4, 1.1, 0.9);
      const jackMat = new THREE.MeshStandardMaterial({ color: 0x27272a, roughness: 0.4 });
      const jack = new THREE.Mesh(jackGeo, jackMat);
      jack.position.set(-2.7, 0.63, 1.8);
      jack.castShadow = true;
      group.add(jack);

      // Regletas de Pines Hembra (Negras)
      const headerMat = new THREE.MeshStandardMaterial({ color: 0x1f2937, roughness: 0.8 });
      // Digital Header 1
      const d1Geo = new THREE.BoxGeometry(2.6, 0.85, 0.25);
      const d1 = new THREE.Mesh(d1Geo, headerMat);
      d1.position.set(-0.2, 0.5, -2.45);
      group.add(d1);
      // Digital Header 2
      const d2Geo = new THREE.BoxGeometry(2.1, 0.85, 0.25);
      const d2 = new THREE.Mesh(d2Geo, headerMat);
      d2.position.set(2.2, 0.5, -2.45);
      group.add(d2);
      // Power / Analog Header
      const aGeo = new THREE.BoxGeometry(4.2, 0.85, 0.25);
      const a = new THREE.Mesh(aGeo, headerMat);
      a.position.set(1.0, 0.5, 2.45);
      group.add(a);

      // Cristal oscilador 16MHz (Plateado cilíndrico)
      const oscGeo = new THREE.CylinderGeometry(0.18, 0.18, 0.8, 12);
      const osc = new THREE.Mesh(oscGeo, metalMat);
      osc.rotation.z = Math.PI / 2;
      osc.position.set(-1.0, 0.2, -0.6);
      group.add(osc);

      // Botón Reset (Rojo con base de metal)
      const btnBaseGeo = new THREE.BoxGeometry(0.6, 0.3, 0.6);
      const btnBase = new THREE.Mesh(btnBaseGeo, metalMat);
      btnBase.position.set(-2.8, 0.25, -2.2);
      group.add(btnBase);
      const btnPshGeo = new THREE.CylinderGeometry(0.15, 0.15, 0.2, 12);
      const btnPshMat = new THREE.MeshStandardMaterial({ color: 0xdc2626 });
      const btnPsh = new THREE.Mesh(btnPshGeo, btnPshMat);
      btnPsh.position.set(-2.8, 0.45, -2.2);
      group.add(btnPsh);

      // Silkscreen "ARDUINO" Badge simulado
      const badgeGeo = new THREE.PlaneGeometry(1.8, 0.5);
      const badgeMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
      const badge = new THREE.Mesh(badgeGeo, badgeMat);
      badge.rotation.x = -Math.PI / 2;
      badge.position.set(1.5, 0.09, -0.8);
      group.add(badge);

      return group;
    }
  },

  "esp32_nodemcu": {
    id: "esp32_nodemcu",
    name: "ESP32 NodeMCU",
    category: "Microcontroladores",
    description: "Módulo Wi-Fi + Bluetooth dual core a 240MHz, 30 pines, ultrabaja potencia y alta capacidad de procesamiento.",
    specs: {
      voltage: 3.3,
      inputVoltageRange: "5V USB o VIN (3.3V LDO interno)",
      idleCurrent: 80, // mA (con Wi-Fi activo aprox 130mA)
      peakCurrent: 240, // mA transmitiendo RF
      isPowerSource: false,
      isController: true,
      pins: ["EN", "VP", "VN", "D34", "D35", "D32", "D33", "D25", "D26", "D27", "D14", "D12", "D13", "GND", "VIN", "D23/MOSI", "D22/SCL", "TX0", "RX0", "D21/SDA", "D19/MISO", "D18/SCK", "D5", "TX2", "RX2", "D4", "D2", "D15", "GND", "3V3"]
    },
    dimensions: { x: 51.5, y: 13.0, z: 28.5 },
    anchorPoints: [
      { id: "pin_row_1", pos: [0, -4, -13], type: "male_pins" },
      { id: "pin_row_2", pos: [0, -4, 13], type: "male_pins" },
      { id: "micro_usb", pos: [-25, 2, 0], type: "micro_usb" }
    ],
    createMesh: function() {
      const group = new THREE.Group();
      group.name = "ESP32 NodeMCU";

      // PCB Negro/Azul marino
      const pcbGeo = new THREE.BoxGeometry(5.15, 0.16, 2.85);
      const pcbMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.4 });
      const pcb = new THREE.Mesh(pcbGeo, pcbMat);
      pcb.castShadow = true;
      group.add(pcb);

      // Blindaje Metálico ESP-WROOM-32
      const shieldGeo = new THREE.BoxGeometry(1.8, 0.3, 1.8);
      const shieldMat = new THREE.MeshStandardMaterial({ color: 0xd4d4d8, metalness: 0.9, roughness: 0.15 });
      const shield = new THREE.Mesh(shieldGeo, shieldMat);
      shield.position.set(0.6, 0.22, 0);
      shield.castShadow = true;
      group.add(shield);

      // Antena PCB Dorada (Meander Trace)
      const antGeo = new THREE.BoxGeometry(0.8, 0.05, 1.6);
      const antMat = new THREE.MeshStandardMaterial({ color: 0xb45309, metalness: 0.8, roughness: 0.2 });
      const ant = new THREE.Mesh(antGeo, antMat);
      ant.position.set(2.0, 0.11, 0);
      group.add(ant);

      // Micro-USB
      const usbGeo = new THREE.BoxGeometry(0.8, 0.35, 0.6);
      const usbMat = new THREE.MeshStandardMaterial({ color: 0xe2e8f0, metalness: 0.8 });
      const usb = new THREE.Mesh(usbGeo, usbMat);
      usb.position.set(-2.4, 0.22, 0);
      group.add(usb);

      // Botones EN y BOOT
      const bGeo = new THREE.BoxGeometry(0.35, 0.2, 0.3);
      const bMat = new THREE.MeshStandardMaterial({ color: 0x475569 });
      const b1 = new THREE.Mesh(bGeo, bMat);
      b1.position.set(-1.8, 0.18, -0.9);
      const b2 = new THREE.Mesh(bGeo, bMat);
      b2.position.set(-1.8, 0.18, 0.9);
      group.add(b1);
      group.add(b2);

      // Pines macho laterales (inferiores)
      const pinMat = new THREE.MeshStandardMaterial({ color: 0xd97706, metalness: 0.85, roughness: 0.3 });
      const pinRowGeo = new THREE.BoxGeometry(4.6, 0.7, 0.1);
      const pr1 = new THREE.Mesh(pinRowGeo, pinMat);
      pr1.position.set(0, -0.4, -1.3);
      const pr2 = new THREE.Mesh(pinRowGeo, pinMat);
      pr2.position.set(0, -0.4, 1.3);
      group.add(pr1);
      group.add(pr2);

      return group;
    }
  },

  "servo_sg90": {
    id: "servo_sg90",
    name: "Servomotor SG90 (9g)",
    category: "Actuadores",
    description: "Micro servomotor de 9 gramos con torque de 1.8 kg·cm, rotación de 180° y control por señal PWM.",
    specs: {
      voltage: 5.0,
      voltageRange: "4.8V - 6.0V",
      idleCurrent: 10, // mA
      peakCurrent: 650, // mA en bloqueo (stall)
      torque: "1.8 kg·cm (a 4.8V)",
      speed: "0.1 s/60°",
      isPowerSource: false,
      pins: ["GND (Marrón)", "VCC 5V (Rojo)", "PWM Signal (Naranja)"]
    },
    dimensions: { x: 22.8, y: 31.0, z: 12.2 },
    anchorPoints: [
      { id: "output_shaft", pos: [-6, 17, 0], type: "shaft_servo_horn" },
      { id: "mount_ear_left", pos: [-15, 6, 0], type: "mount_m2" },
      { id: "mount_ear_right", pos: [15, 6, 0], type: "mount_m2" },
      { id: "cable_exit", pos: [11, -8, 0], type: "wire_3pin" }
    ],
    createMesh: function() {
      const group = new THREE.Group();
      group.name = "Servomotor SG90";

      // Carcasa azul semitransparente
      const bodyGeo = new THREE.BoxGeometry(2.28, 2.2, 1.22);
      const bodyMat = new THREE.MeshPhysicalMaterial({
        color: 0x0284c7,
        roughness: 0.2,
        transmission: 0.6,
        thickness: 0.5,
        opacity: 0.9,
        transparent: true
      });
      const body = new THREE.Mesh(bodyGeo, bodyMat);
      body.castShadow = true;
      group.add(body);

      // Orejetas de montaje laterales
      const earGeo = new THREE.BoxGeometry(3.2, 0.2, 1.22);
      const ear = new THREE.Mesh(earGeo, bodyMat);
      ear.position.set(0, 0.6, 0);
      group.add(ear);

      // Torreta de engranajes superior
      const towerGeo = new THREE.CylinderGeometry(0.55, 0.55, 0.6, 16);
      const tower = new THREE.Mesh(towerGeo, bodyMat);
      tower.position.set(-0.6, 1.35, 0);
      group.add(tower);

      // Eje / Cuerno de servo blanco (Horn)
      const hornGroup = new THREE.Group();
      hornGroup.name = "ServoHorn";
      const hornHubGeo = new THREE.CylinderGeometry(0.35, 0.35, 0.2, 16);
      const hornMat = new THREE.MeshStandardMaterial({ color: 0xf8fafc, roughness: 0.3 });
      const hub = new THREE.Mesh(hornHubGeo, hornMat);
      hub.position.set(0, 0.1, 0);
      hornGroup.add(hub);

      // Brazo cruzado de servo
      const armGeo = new THREE.BoxGeometry(1.6, 0.12, 0.35);
      const arm = new THREE.Mesh(armGeo, hornMat);
      arm.position.set(0, 0.1, 0);
      hornGroup.add(arm);

      hornGroup.position.set(-0.6, 1.65, 0);
      group.add(hornGroup);

      // Cable plano tricolor
      const cableGeo = new THREE.BoxGeometry(0.8, 0.15, 0.4);
      const cableMat = new THREE.MeshStandardMaterial({ color: 0xd97706 });
      const cable = new THREE.Mesh(cableGeo, cableMat);
      cable.position.set(1.2, -0.9, 0);
      group.add(cable);

      return group;
    }
  },

  "servo_mg996r": {
    id: "servo_mg996r",
    name: "Servomotor MG996R (Torque Alto)",
    category: "Actuadores",
    description: "Servomotor robusto de piñonería metálica de latón, torque de 11 kg·cm para brazos robóticos y articulaciones de alta carga.",
    specs: {
      voltage: 6.0,
      voltageRange: "4.8V - 7.2V",
      idleCurrent: 15, // mA
      peakCurrent: 1400, // mA en bloqueo (stall)
      torque: "11 kg·cm (a 6.0V)",
      speed: "0.17 s/60°",
      isPowerSource: false,
      pins: ["GND (Marrón/Negro)", "VCC 5-7.2V (Rojo)", "PWM Signal (Naranja/Blanco)"]
    },
    dimensions: { x: 40.7, y: 42.9, z: 19.7 },
    anchorPoints: [
      { id: "output_shaft", pos: [-10, 23, 0], type: "shaft_metal_spline" },
      { id: "mount_ear_left", pos: [-24, 8, 0], type: "mount_m3" },
      { id: "mount_ear_right", pos: [24, 8, 0], type: "mount_m3" }
    ],
    createMesh: function() {
      const group = new THREE.Group();
      group.name = "Servomotor MG996R";

      // Carcasa negra reforzada
      const bodyGeo = new THREE.BoxGeometry(4.07, 3.6, 1.97);
      const bodyMat = new THREE.MeshStandardMaterial({ color: 0x18181b, roughness: 0.7 });
      const body = new THREE.Mesh(bodyGeo, bodyMat);
      body.castShadow = true;
      group.add(body);

      // Flange de montaje reforzado
      const flangeGeo = new THREE.BoxGeometry(5.4, 0.35, 1.97);
      const flange = new THREE.Mesh(flangeGeo, bodyMat);
      flange.position.set(0, 0.9, 0);
      group.add(flange);

      // Eje de salida de latón dorado
      const brassMat = new THREE.MeshStandardMaterial({ color: 0xd97706, metalness: 0.9, roughness: 0.2 });
      const shaftGeo = new THREE.CylinderGeometry(0.3, 0.3, 0.5, 16);
      const shaft = new THREE.Mesh(shaftGeo, brassMat);
      shaft.position.set(-1.0, 2.05, 0);
      group.add(shaft);

      // Horn redondo metálico de aluminio (disco CNC)
      const hornGeo = new THREE.CylinderGeometry(1.0, 1.0, 0.15, 24);
      const hornMat = new THREE.MeshStandardMaterial({ color: 0x2563eb, metalness: 0.7, roughness: 0.2 });
      const horn = new THREE.Mesh(hornGeo, hornMat);
      horn.position.set(-1.0, 2.3, 0);
      group.add(horn);

      // Etiqueta distintiva "MG996R"
      const labelGeo = new THREE.PlaneGeometry(2.4, 0.8);
      const labelMat = new THREE.MeshBasicMaterial({ color: 0xe2e8f0 });
      const label = new THREE.Mesh(labelGeo, labelMat);
      label.position.set(0, 0, 1.0);
      group.add(label);

      return group;
    }
  },

  "motor_dc_tt": {
    id: "motor_dc_tt",
    name: "Motor DC TT Amarillo con Caja Reductora",
    category: "Actuadores",
    description: "Motorreductor 1:48 clásico con caja de engranajes plástica amarilla para tracción de robots móviles y vehículos autónomos.",
    specs: {
      voltage: 6.0,
      voltageRange: "3V - 6V DC",
      idleCurrent: 70, // mA sin carga
      peakCurrent: 800, // mA en bloqueo
      rpm: "200 RPM a 6V",
      gearRatio: "1:48",
      isPowerSource: false,
      pins: ["Motor Terminal (+)", "Motor Terminal (-)"]
    },
    dimensions: { x: 70.0, y: 22.0, z: 19.0 },
    anchorPoints: [
      { id: "wheel_shaft_left", pos: [14, 0, -14], type: "tt_axle" },
      { id: "wheel_shaft_right", pos: [14, 0, 14], type: "tt_axle" },
      { id: "chassis_mount_1", pos: [-10, 8, 0], type: "mount_m3" },
      { id: "chassis_mount_2", pos: [5, 8, 0], type: "mount_m3" }
    ],
    createMesh: function() {
      const group = new THREE.Group();
      group.name = "Motor DC TT";

      // Caja reductora plástica amarilla icónica
      const boxGeo = new THREE.BoxGeometry(4.2, 2.2, 1.9);
      const yellowMat = new THREE.MeshStandardMaterial({ color: 0xeab308, roughness: 0.35 });
      const box = new THREE.Mesh(boxGeo, yellowMat);
      box.castShadow = true;
      group.add(box);

      // Motor cilíndrico metálico trasero (tipo 130)
      const motorGeo = new THREE.CylinderGeometry(0.75, 0.75, 2.8, 20);
      const metalMat = new THREE.MeshStandardMaterial({ color: 0x94a3b8, metalness: 0.8, roughness: 0.25 });
      const motor = new THREE.Mesh(motorGeo, metalMat);
      motor.rotation.z = Math.PI / 2;
      motor.position.set(-2.8, 0, 0);
      motor.castShadow = true;
      group.add(motor);

      // Eje de salida blanco doble plano (D-shaft que atraviesa a ambos lados)
      const axleGeo = new THREE.CylinderGeometry(0.26, 0.26, 3.2, 16);
      const axleMat = new THREE.MeshStandardMaterial({ color: 0xf1f5f9, roughness: 0.2 });
      const axle = new THREE.Mesh(axleGeo, axleMat);
      axle.rotation.x = Math.PI / 2;
      axle.position.set(1.4, 0, 0);
      group.add(axle);

      return group;
    }
  },

  "motor_nema17": {
    id: "motor_nema17",
    name: "Motor Paso a Paso NEMA 17",
    category: "Actuadores",
    description: "Motor paso a paso híbrido de 200 pasos/rev (1.8° por paso) con alto torque de retención para impresoras 3D y brazos CNC.",
    specs: {
      voltage: 12.0,
      voltageRange: "12V - 24V DC",
      idleCurrent: 100, // mA en standby chopper
      peakCurrent: 1500, // mA por fase
      stepAngle: "1.8°",
      holdingTorque: "40 N·cm",
      isPowerSource: false,
      pins: ["Phase A+", "Phase A-", "Phase B+", "Phase B-"]
    },
    dimensions: { x: 42.0, y: 38.0, z: 42.0 },
    anchorPoints: [
      { id: "shaft", pos: [0, 24, 0], type: "d_shaft_5mm" },
      { id: "mount_hole_1", pos: [-15.5, 19, -15.5], type: "mount_m3" },
      { id: "mount_hole_2", pos: [15.5, 19, -15.5], type: "mount_m3" },
      { id: "mount_hole_3", pos: [15.5, 19, 15.5], type: "mount_m3" },
      { id: "mount_hole_4", pos: [-15.5, 19, 15.5], type: "mount_m3" },
      { id: "jst_connector", pos: [0, -10, 21], type: "jst_4pin" }
    ],
    createMesh: function() {
      const group = new THREE.Group();
      group.name = "Motor NEMA 17";

      // Placa frontal de aluminio negro
      const faceGeo = new THREE.BoxGeometry(4.2, 0.8, 4.2);
      const blackAlumMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, metalness: 0.6, roughness: 0.3 });
      const frontFace = new THREE.Mesh(faceGeo, blackAlumMat);
      frontFace.position.set(0, 1.5, 0);
      group.add(frontFace);

      // Estator laminado central (Acero plateado con ranuras)
      const statorGeo = new THREE.BoxGeometry(4.1, 2.2, 4.1);
      const steelMat = new THREE.MeshStandardMaterial({ color: 0x64748b, metalness: 0.8, roughness: 0.4 });
      const stator = new THREE.Mesh(statorGeo, steelMat);
      stator.position.set(0, 0, 0);
      stator.castShadow = true;
      group.add(stator);

      // Placa trasera negra
      const backFace = new THREE.Mesh(faceGeo, blackAlumMat);
      backFace.position.set(0, -1.5, 0);
      group.add(backFace);

      // Cuello de montaje cilíndrico
      const bossGeo = new THREE.CylinderGeometry(1.1, 1.1, 0.3, 24);
      const boss = new THREE.Mesh(bossGeo, blackAlumMat);
      boss.position.set(0, 2.0, 0);
      group.add(boss);

      // Eje de acero inoxidable D-Shaft de 5mm
      const shaftGeo = new THREE.CylinderGeometry(0.25, 0.25, 2.4, 20);
      const shaftMat = new THREE.MeshStandardMaterial({ color: 0xe2e8f0, metalness: 0.9, roughness: 0.1 });
      const shaft = new THREE.Mesh(shaftGeo, shaftMat);
      shaft.position.set(0, 3.1, 0);
      group.add(shaft);

      return group;
    }
  },

  "hc_sr04": {
    id: "hc_sr04",
    name: "Sensor Ultrasonido HC-SR04",
    category: "Sensores",
    description: "Sensor de distancia por ultrasonidos de 2cm a 400cm de alcance, con transductores emisor y receptor de 40kHz.",
    specs: {
      voltage: 5.0,
      voltageRange: "4.5V - 5.5V DC",
      idleCurrent: 2, // mA
      peakCurrent: 15, // mA durante disparo de pulso
      range: "2cm - 400cm",
      accuracy: "3mm",
      isPowerSource: false,
      pins: ["VCC", "Trig", "Echo", "GND"]
    },
    dimensions: { x: 45.0, y: 20.0, z: 15.0 },
    anchorPoints: [
      { id: "transducer_t", pos: [-13, 0, 10], type: "ultrasonic_beam" },
      { id: "transducer_r", pos: [13, 0, 10], type: "ultrasonic_beam" },
      { id: "pin_header", pos: [0, -9, -3], type: "male_pins_4" }
    ],
    createMesh: function() {
      const group = new THREE.Group();
      group.name = "Sensor HC-SR04";

      // PCB Azul
      const pcbGeo = new THREE.BoxGeometry(4.5, 2.0, 0.16);
      const pcbMat = new THREE.MeshStandardMaterial({ color: 0x0284c7, roughness: 0.3 });
      const pcb = new THREE.Mesh(pcbGeo, pcbMat);
      pcb.castShadow = true;
      group.add(pcb);

      // Dos Cápsulas Cilindricas de Metal ("Ojos" T y R)
      const canGeo = new THREE.CylinderGeometry(0.8, 0.8, 1.2, 24);
      const canMat = new THREE.MeshStandardMaterial({ color: 0xd4d4d8, metalness: 0.9, roughness: 0.15 });

      const canT = new THREE.Mesh(canGeo, canMat);
      canT.rotation.x = Math.PI / 2;
      canT.position.set(-1.3, 0, 0.6);
      canT.castShadow = true;
      group.add(canT);

      const canR = new THREE.Mesh(canGeo, canMat);
      canR.rotation.x = Math.PI / 2;
      canR.position.set(1.3, 0, 0.6);
      canR.castShadow = true;
      group.add(canR);

      // Rejilla interior de las cápsulas
      const grillGeo = new THREE.CylinderGeometry(0.7, 0.7, 0.05, 20);
      const grillMat = new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.9 });
      const grill1 = new THREE.Mesh(grillGeo, grillMat);
      grill1.rotation.x = Math.PI / 2;
      grill1.position.set(-1.3, 0, 1.22);
      const grill2 = new THREE.Mesh(grillGeo, grillMat);
      grill2.rotation.x = Math.PI / 2;
      grill2.position.set(1.3, 0, 1.22);
      group.add(grill1);
      group.add(grill2);

      // Cristal de cuarzo central
      const qzGeo = new THREE.BoxGeometry(0.8, 0.3, 0.2);
      const qzMat = new THREE.MeshStandardMaterial({ color: 0xa1a1aa, metalness: 0.7 });
      const qz = new THREE.Mesh(qzGeo, qzMat);
      qz.position.set(0, 0.4, 0.15);
      group.add(qz);

      // Pines de conexión inferiores
      const pinMat = new THREE.MeshStandardMaterial({ color: 0xd97706, metalness: 0.8 });
      const pinGeo = new THREE.BoxGeometry(1.0, 0.6, 0.1);
      const pins = new THREE.Mesh(pinGeo, pinMat);
      pins.position.set(0, -1.1, 0);
      group.add(pins);

      return group;
    }
  },

  "driver_l298n": {
    id: "driver_l298n",
    name: "Módulo Driver Puente H L298N",
    category: "Controladores de Potencia",
    description: "Controlador dual de motores DC o paso a paso bipolar hasta 2A por canal, con gran disipador térmico y regulador 5V.",
    specs: {
      voltage: 12.0,
      motorVoltageRange: "5V - 35V DC",
      logicVoltage: 5.0,
      idleCurrent: 36, // mA (consumo de reposo lógica + LEDs)
      peakCurrent: 2000, // mA por canal (4A peak total)
      isPowerSource: false,
      pins: ["12V Power In", "GND", "5V Logic Output/In", "ENA", "IN1", "IN2", "IN3", "IN4", "ENB", "OUT1", "OUT2", "OUT3", "OUT4"]
    },
    dimensions: { x: 43.0, y: 26.0, z: 43.0 },
    anchorPoints: [
      { id: "terminal_power", pos: [-16, 5, 17], type: "screw_terminal_3" },
      { id: "terminal_motor_a", pos: [-17, 5, -8], type: "screw_terminal_2" },
      { id: "terminal_motor_b", pos: [17, 5, -8], type: "screw_terminal_2" },
      { id: "logic_pins", pos: [10, 5, 18], type: "pin_header_6" }
    ],
    createMesh: function() {
      const group = new THREE.Group();
      group.name = "Driver L298N";

      // PCB Rojo
      const pcbGeo = new THREE.BoxGeometry(4.3, 0.16, 4.3);
      const pcbMat = new THREE.MeshStandardMaterial({ color: 0xb91c1c, roughness: 0.35 });
      const pcb = new THREE.Mesh(pcbGeo, pcbMat);
      pcb.castShadow = true;
      group.add(pcb);

      // Gran disipador de aluminio negro con aletas
      const hsBaseGeo = new THREE.BoxGeometry(2.8, 0.3, 1.2);
      const hsMat = new THREE.MeshStandardMaterial({ color: 0x18181b, metalness: 0.8, roughness: 0.3 });
      const hsBase = new THREE.Mesh(hsBaseGeo, hsMat);
      hsBase.position.set(0, 0.25, -0.6);
      group.add(hsBase);

      // Aletas de disipación verticales
      for (let i = -1.2; i <= 1.2; i += 0.4) {
        const finGeo = new THREE.BoxGeometry(0.08, 1.8, 1.2);
        const fin = new THREE.Mesh(finGeo, hsMat);
        fin.position.set(i, 1.1, -0.6);
        fin.castShadow = true;
        group.add(fin);
      }

      // Chip L298 multiwatt atornillado
      const chipGeo = new THREE.BoxGeometry(2.0, 1.2, 0.2);
      const chipMat = new THREE.MeshStandardMaterial({ color: 0x09090b });
      const chip = new THREE.Mesh(chipGeo, chipMat);
      chip.position.set(0, 0.8, 0.05);
      group.add(chip);

      // Borneras de tornillos verdes para conexión de cables
      const termMat = new THREE.MeshStandardMaterial({ color: 0x15803d, roughness: 0.5 });
      const term1Geo = new THREE.BoxGeometry(1.2, 1.0, 1.0);
      const termPower = new THREE.Mesh(term1Geo, termMat);
      termPower.position.set(-1.4, 0.55, 1.5);
      group.add(termPower);

      const termMotorA = new THREE.Mesh(term1Geo, termMat);
      termMotorA.position.set(-1.6, 0.55, -0.8);
      group.add(termMotorA);

      const termMotorB = new THREE.Mesh(term1Geo, termMat);
      termMotorB.position.set(1.6, 0.55, -0.8);
      group.add(termMotorB);

      // Condensador electrolítico cilíndrico grande
      const capGeo = new THREE.CylinderGeometry(0.4, 0.4, 1.1, 16);
      const capMat = new THREE.MeshStandardMaterial({ color: 0x1e293b });
      const cap = new THREE.Mesh(capGeo, capMat);
      cap.position.set(1.4, 0.65, 0.8);
      group.add(cap);

      return group;
    }
  },

  "mpu6050": {
    id: "mpu6050",
    name: "Sensor Giroscopio/Acelerómetro MPU6050",
    category: "Sensores",
    description: "Unidad de Medición Inercial (IMU) de 6 grados de libertad con giroscopio de 3 ejes y acelerómetro con bus I2C.",
    specs: {
      voltage: 3.3,
      voltageRange: "3.0V - 5.0V (regulador integrado)",
      idleCurrent: 3.8, // mA
      peakCurrent: 4.5, // mA
      interface: "I2C (0x68 por defecto)",
      isPowerSource: false,
      pins: ["VCC", "GND", "SCL", "SDA", "XDA", "XCL", "AD0", "INT"]
    },
    dimensions: { x: 20.0, y: 5.0, z: 15.0 },
    anchorPoints: [
      { id: "i2c_header", pos: [0, 0, -6], type: "pin_header_8" }
    ],
    createMesh: function() {
      const group = new THREE.Group();
      group.name = "Módulo MPU6050";

      // PCB Azul
      const pcbGeo = new THREE.BoxGeometry(2.0, 0.16, 1.5);
      const pcbMat = new THREE.MeshStandardMaterial({ color: 0x0284c7, roughness: 0.3 });
      const pcb = new THREE.Mesh(pcbGeo, pcbMat);
      pcb.castShadow = true;
      group.add(pcb);

      // Chip QFN MPU-6050 central cuadrado
      const chipGeo = new THREE.BoxGeometry(0.5, 0.15, 0.5);
      const chipMat = new THREE.MeshStandardMaterial({ color: 0x18181b, roughness: 0.4 });
      const chip = new THREE.Mesh(chipGeo, chipMat);
      chip.position.set(0, 0.15, 0);
      group.add(chip);

      // Pines dorados en línea
      const pinMat = new THREE.MeshStandardMaterial({ color: 0xd97706, metalness: 0.85 });
      const pinsGeo = new THREE.BoxGeometry(1.8, 0.4, 0.1);
      const pins = new THREE.Mesh(pinsGeo, pinMat);
      pins.position.set(0, -0.2, -0.65);
      group.add(pins);

      return group;
    }
  },

  "breadboard_830": {
    id: "breadboard_830",
    name: "Protoboard 830 Puntos",
    category: "Bases y Prototipado",
    description: "Placa de inserción sin soldadura con 830 puntos de conexión, buses laterales de alimentación positiva (+) y negativa (-).",
    specs: {
      voltage: 0,
      idleCurrent: 0,
      peakCurrent: 0,
      maxCurrentRating: 2000, // mA max recomendados por pista
      isPowerSource: false,
      pins: ["Línea Bus +", "Línea Bus -", "Puntos 1-63 (A-J)"]
    },
    dimensions: { x: 165.0, y: 8.5, z: 55.0 },
    anchorPoints: [
      { id: "bb_center", pos: [0, 5, 0], type: "tie_point_matrix" },
      { id: "bb_power_left", pos: [0, 5, -23], type: "power_rail_vcc" },
      { id: "bb_power_right", pos: [0, 5, 23], type: "power_rail_gnd" }
    ],
    createMesh: function() {
      const group = new THREE.Group();
      group.name = "Protoboard 830";

      // Cuerpo de plástico blanco marfil
      const bodyGeo = new THREE.BoxGeometry(16.5, 0.85, 5.5);
      const bodyMat = new THREE.MeshStandardMaterial({ color: 0xf8fafc, roughness: 0.5 });
      const body = new THREE.Mesh(bodyGeo, bodyMat);
      body.castShadow = true;
      body.receiveShadow = true;
      group.add(body);

      // Surco central divisor de DIPs
      const trenchGeo = new THREE.BoxGeometry(16.0, 0.2, 0.3);
      const trenchMat = new THREE.MeshStandardMaterial({ color: 0xd1d5db, roughness: 0.8 });
      const trench = new THREE.Mesh(trenchGeo, trenchMat);
      trench.position.set(0, 0.38, 0);
      group.add(trench);

      // Líneas de bus de alimentación rojo (+) y azul (-)
      const redLineGeo = new THREE.BoxGeometry(15.6, 0.02, 0.08);
      const redLineMat = new THREE.MeshBasicMaterial({ color: 0xef4444 });
      const r1 = new THREE.Mesh(redLineGeo, redLineMat);
      r1.position.set(0, 0.44, -2.4);
      const r2 = new THREE.Mesh(redLineGeo, redLineMat);
      r2.position.set(0, 0.44, 2.4);
      group.add(r1);
      group.add(r2);

      const blueLineMat = new THREE.MeshBasicMaterial({ color: 0x3b82f6 });
      const b1 = new THREE.Mesh(redLineGeo, blueLineMat);
      b1.position.set(0, 0.44, -2.1);
      const b2 = new THREE.Mesh(redLineGeo, blueLineMat);
      b2.position.set(0, 0.44, 2.1);
      group.add(b1);
      group.add(b2);

      return group;
    }
  },

  "battery_18650_pack": {
    id: "battery_18650_pack",
    name: "Pack de Baterías 18650 x2 (7.4V)",
    category: "Fuentes de Alimentación",
    description: "Dos celdas de Ion de Litio 18650 en serie con portapilas plástico, entregando 7.4V nominales y 2500mAh de capacidad.",
    specs: {
      voltage: 7.4,
      nominalVoltage: 7.4,
      fullChargeVoltage: 8.4,
      capacityMah: 2500, // mAh
      maxContinuousDischarge: 5000, // mA (2C rate)
      isPowerSource: true,
      pins: ["VCC (+7.4V Rojo)", "GND (Negro)"]
    },
    dimensions: { x: 76.0, y: 20.0, z: 42.0 },
    anchorPoints: [
      { id: "wire_output", pos: [38, 5, 0], type: "battery_leads" },
      { id: "bottom_mount", pos: [0, -10, 0], type: "flat_surface" }
    ],
    createMesh: function() {
      const group = new THREE.Group();
      group.name = "Batería 18650 Pack";

      // Portapilas plástico negro ABS
      const holderGeo = new THREE.BoxGeometry(7.6, 2.0, 4.2);
      const holderMat = new THREE.MeshStandardMaterial({ color: 0x18181b, roughness: 0.7 });
      const holder = new THREE.Mesh(holderGeo, holderMat);
      holder.castShadow = true;
      group.add(holder);

      // Celdas cilíndricas 18650 Verde Lima (color característico Li-Ion)
      const cellGeo = new THREE.CylinderGeometry(0.9, 0.9, 6.5, 20);
      const cellMat = new THREE.MeshStandardMaterial({ color: 0x22c55e, roughness: 0.35 });

      const cell1 = new THREE.Mesh(cellGeo, cellMat);
      cell1.rotation.z = Math.PI / 2;
      cell1.position.set(0, 0.3, -1.0);
      group.add(cell1);

      const cell2 = new THREE.Mesh(cellGeo, cellMat);
      cell2.rotation.z = Math.PI / 2;
      cell2.position.set(0, 0.3, 1.0);
      group.add(cell2);

      // Polos de níquel brillante
      const niGeo = new THREE.CylinderGeometry(0.35, 0.35, 0.15, 16);
      const niMat = new THREE.MeshStandardMaterial({ color: 0xe2e8f0, metalness: 0.9 });
      const n1 = new THREE.Mesh(niGeo, niMat);
      n1.rotation.z = Math.PI / 2;
      n1.position.set(3.35, 0.3, -1.0);
      const n2 = new THREE.Mesh(niGeo, niMat);
      n2.rotation.z = Math.PI / 2;
      n2.position.set(3.35, 0.3, 1.0);
      group.add(n1);
      group.add(n2);

      return group;
    }
  },

  // ==========================================
  // CLOUD COMPONENT REPOSITORY (Online Hub)
  // ==========================================
  "cloud_tcs34725": {
    id: "cloud_tcs34725",
    name: "Sensor de Color TCS34725 con LED RGB",
    category: "Sensores",
    cloudOnly: true,
    cloudVersion: "v2.1",
    fileSize: "142 KB",
    downloads: "18.4K",
    rating: "4.9/5",
    description: "Sensor óptico de color RGBC con filtro de bloqueo infrarrojo y LED blanco de iluminación para identificación de materiales y líneas.",
    specs: {
      voltage: 3.3,
      voltageRange: "3.3V - 5.0V",
      idleCurrent: 15, // mA con LED encendido
      peakCurrent: 25, // mA
      interface: "I2C (0x29)",
      isPowerSource: false,
      pins: ["VIN", "GND", "3V3", "SCL", "SDA", "INT", "LED"]
    },
    dimensions: { x: 21.0, y: 6.0, z: 20.0 },
    anchorPoints: [{ id: "i2c_port", pos: [0, 0, -8], type: "header_7pin" }],
    createMesh: function() {
      const group = new THREE.Group();
      group.name = "Sensor Color TCS34725";
      const pcb = new THREE.Mesh(
        new THREE.BoxGeometry(2.1, 0.16, 2.0),
        new THREE.MeshStandardMaterial({ color: 0x4c1d95, roughness: 0.4 })
      );
      group.add(pcb);
      // Lente sensor óptico
      const lens = new THREE.Mesh(
        new THREE.CylinderGeometry(0.3, 0.3, 0.3, 16),
        new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.1, metalness: 0.5 })
      );
      lens.position.set(0, 0.2, 0);
      group.add(lens);
      // LED blanco de iluminación
      const led = new THREE.Mesh(
        new THREE.BoxGeometry(0.3, 0.2, 0.3),
        new THREE.MeshStandardMaterial({ color: 0xfef08a, emissive: 0xfef08a, emissiveIntensity: 0.5 })
      );
      led.position.set(0.6, 0.18, 0);
      group.add(led);
      return group;
    }
  },

  "cloud_oled_096": {
    id: "cloud_oled_096",
    name: "Pantalla OLED 0.96\" I2C 128x64",
    category: "Pantallas & Salidas",
    cloudOnly: true,
    cloudVersion: "v3.0",
    fileSize: "210 KB",
    downloads: "42.1K",
    rating: "5.0/5",
    description: "Display gráfico monocromo azul/blanco de 128x64 píxeles con controlador SSD1306, alto contraste y mínimo consumo de energía.",
    specs: {
      voltage: 5.0,
      voltageRange: "3.3V - 5.0V",
      idleCurrent: 10, // mA
      peakCurrent: 25, // mA (todos los píxeles encendidos)
      interface: "I2C (0x3C o 0x3D)",
      isPowerSource: false,
      pins: ["GND", "VCC", "SCL", "SDA"]
    },
    dimensions: { x: 27.3, y: 5.0, z: 27.8 },
    anchorPoints: [{ id: "top_pins", pos: [0, 0, -12], type: "header_4pin" }],
    createMesh: function() {
      const group = new THREE.Group();
      group.name = "Pantalla OLED 0.96\"";
      // PCB Azul
      const pcb = new THREE.Mesh(
        new THREE.BoxGeometry(2.7, 0.16, 2.8),
        new THREE.MeshStandardMaterial({ color: 0x0369a1, roughness: 0.3 })
      );
      group.add(pcb);
      // Vidrio Display OLED negro brillante
      const glass = new THREE.Mesh(
        new THREE.BoxGeometry(2.4, 0.15, 1.8),
        new THREE.MeshStandardMaterial({
          color: 0x050b14,
          roughness: 0.1,
          metalness: 0.9,
          emissive: 0x0284c7,
          emissiveIntensity: 0.2
        })
      );
      glass.position.set(0, 0.16, 0.3);
      group.add(glass);
      return group;
    }
  },

  "cloud_gps_neo6m": {
    id: "cloud_gps_neo6m",
    name: "Módulo GPS u-blox NEO-6M con Antena Cerámica",
    category: "Comunicaciones & IoT",
    cloudOnly: true,
    cloudVersion: "v1.4",
    fileSize: "320 KB",
    downloads: "15.9K",
    rating: "4.8/5",
    description: "Receptor satelital GPS/GNSS con antena activa tipo parche de alta sensibilidad y batería de respaldo EEPROM para arranque en caliente.",
    specs: {
      voltage: 5.0,
      voltageRange: "3.0V - 5.0V",
      idleCurrent: 45, // mA rastreo continuo
      peakCurrent: 67, // mA adquisición de satélites
      interface: "UART Serial (9600 baud)",
      isPowerSource: false,
      pins: ["VCC", "RX", "TX", "GND"]
    },
    dimensions: { x: 26.0, y: 12.0, z: 36.0 },
    anchorPoints: [{ id: "uart_pins", pos: [0, 0, -16], type: "header_4pin" }],
    createMesh: function() {
      const group = new THREE.Group();
      group.name = "Módulo GPS NEO-6M";
      // PCB Azul
      const pcb = new THREE.Mesh(
        new THREE.BoxGeometry(2.6, 0.16, 3.6),
        new THREE.MeshStandardMaterial({ color: 0x1d4ed8 })
      );
      group.add(pcb);
      // Antena cerámica dorada/beige
      const ant = new THREE.Mesh(
        new THREE.BoxGeometry(2.2, 0.6, 2.2),
        new THREE.MeshStandardMaterial({ color: 0xd97706, roughness: 0.8 })
      );
      ant.position.set(0, 0.4, 0.4);
      group.add(ant);
      // Punto plateado central
      const dot = new THREE.Mesh(
        new THREE.CylinderGeometry(0.15, 0.15, 0.05, 12),
        new THREE.MeshStandardMaterial({ color: 0xe2e8f0, metalness: 0.9 })
      );
      dot.position.set(0, 0.72, 0.4);
      group.add(dot);
      return group;
    }
  },

  "cloud_robotic_arm_kit": {
    id: "cloud_robotic_arm_kit",
    name: "Estructura Brazo Robótico Acrílico 3-DOF",
    category: "Chasis & Estructuras",
    cloudOnly: true,
    cloudVersion: "v4.0",
    fileSize: "580 KB",
    downloads: "29.7K",
    rating: "4.9/5",
    description: "Kit cortado por láser con base giratoria, eslabón de elevación y pinza mecánica articulada para acoplar 3x servomotores SG90 o MG996R.",
    specs: {
      voltage: 0,
      idleCurrent: 0,
      peakCurrent: 0,
      dof: "3 Grados de Libertad + Pinza",
      payload: "Hasta 250 gramos",
      isPowerSource: false,
      pins: []
    },
    dimensions: { x: 90.0, y: 140.0, z: 90.0 },
    anchorPoints: [
      { id: "base_mount", pos: [0, 0, 0], type: "ground_plate" },
      { id: "servo_base_slot", pos: [0, 15, 0], type: "servo_sg90_slot" },
      { id: "servo_elbow_slot", pos: [0, 60, 20], type: "servo_sg90_slot" },
      { id: "gripper_mount", pos: [0, 110, 40], type: "gripper_slot" }
    ],
    createMesh: function() {
      const group = new THREE.Group();
      group.name = "Brazo Robótico Acrílico";
      const acrylicMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.2, metalness: 0.1 });
      // Base redonda
      const base = new THREE.Mesh(new THREE.CylinderGeometry(4.5, 4.5, 0.3, 32), acrylicMat);
      group.add(base);
      // Eslabón vertical
      const link1 = new THREE.Mesh(new THREE.BoxGeometry(0.8, 5.0, 1.2), acrylicMat);
      link1.position.set(0, 2.7, 0);
      group.add(link1);
      // Eslabón inclinado
      const link2 = new THREE.Mesh(new THREE.BoxGeometry(0.7, 4.0, 1.0), acrylicMat);
      link2.rotation.x = -0.5;
      link2.position.set(0, 6.2, 1.2);
      group.add(link2);
      // Pinza mecánica frontal
      const clawMat = new THREE.MeshStandardMaterial({ color: 0x38bdf8, roughness: 0.3 });
      const claw1 = new THREE.Mesh(new THREE.BoxGeometry(0.2, 1.5, 0.8), clawMat);
      claw1.position.set(-0.6, 8.2, 2.5);
      const claw2 = new THREE.Mesh(new THREE.BoxGeometry(0.2, 1.5, 0.8), clawMat);
      claw2.position.set(0.6, 8.2, 2.5);
      group.add(claw1);
      group.add(claw2);
      return group;
    }
  },

  "cloud_dht22": {
    id: "cloud_dht22",
    name: "Sensor de Temperatura y Humedad DHT22",
    category: "Sensores",
    cloudOnly: true,
    cloudVersion: "v1.8",
    fileSize: "115 KB",
    downloads: "24.5K",
    rating: "4.7/5",
    description: "Sensor digital capacitivo de alta precisión para temperatura (-40 a 80°C) y humedad relativa (0 a 100% RH).",
    specs: {
      voltage: 5.0,
      voltageRange: "3.3V - 6V DC",
      idleCurrent: 1.5, // mA
      peakCurrent: 2.5, // mA durante medición
      interface: "1-Wire Digital",
      isPowerSource: false,
      pins: ["VCC", "DATA", "NC", "GND"]
    },
    dimensions: { x: 15.0, y: 25.0, z: 8.0 },
    anchorPoints: [{ id: "pins", pos: [0, -12, 0], type: "pin_4" }],
    createMesh: function() {
      const group = new THREE.Group();
      group.name = "Sensor DHT22";
      const caseMat = new THREE.MeshStandardMaterial({ color: 0xf8fafc, roughness: 0.6 });
      const body = new THREE.Mesh(new THREE.BoxGeometry(1.5, 2.5, 0.8), caseMat);
      group.add(body);
      // Rejilla frontal
      const grillMat = new THREE.MeshStandardMaterial({ color: 0x64748b });
      const grill = new THREE.Mesh(new THREE.BoxGeometry(1.1, 1.6, 0.05), grillMat);
      grill.position.set(0, 0.2, 0.42);
      group.add(grill);
      return group;
    }
  },

  "cloud_relay_5v": {
    id: "cloud_relay_5v",
    name: "Módulo Relé 5V de 1 Canal con Optoacoplador",
    category: "Controladores de Potencia",
    cloudOnly: true,
    cloudVersion: "v2.0",
    fileSize: "160 KB",
    downloads: "21.3K",
    rating: "4.8/5",
    description: "Módulo con relé electromecánico Songle para conmutar cargas de 250V AC / 10A desde señales lógicas de 5V.",
    specs: {
      voltage: 5.0,
      idleCurrent: 4, // mA desenergizado
      peakCurrent: 75, // mA bobina energizada
      contactRating: "250V AC / 10A o 30V DC / 10A",
      isPowerSource: false,
      pins: ["VCC", "GND", "IN", "NO (Normal Abierto)", "COM (Común)", "NC (Normal Cerrado)"]
    },
    dimensions: { x: 43.0, y: 18.0, z: 17.0 },
    anchorPoints: [
      { id: "signal_in", pos: [-18, 0, 0], type: "header_3pin" },
      { id: "terminal_out", pos: [18, 5, 0], type: "screw_terminal_3" }
    ],
    createMesh: function() {
      const group = new THREE.Group();
      group.name = "Módulo Relé 5V";
      const pcb = new THREE.Mesh(
        new THREE.BoxGeometry(4.3, 0.16, 1.7),
        new THREE.MeshStandardMaterial({ color: 0x1e3a8a })
      );
      group.add(pcb);
      // Cubo de relé azul Songle
      const cube = new THREE.Mesh(
        new THREE.BoxGeometry(1.9, 1.5, 1.5),
        new THREE.MeshStandardMaterial({ color: 0x2563eb, roughness: 0.4 })
      );
      cube.position.set(0, 0.8, 0);
      group.add(cube);
      // Bornera de salida azul
      const term = new THREE.Mesh(
        new THREE.BoxGeometry(1.2, 1.0, 1.3),
        new THREE.MeshStandardMaterial({ color: 0x15803d })
      );
      term.position.set(1.4, 0.55, 0);
      group.add(term);
      return group;
    }
  },

  "cloud_chassis_2wd": {
    id: "cloud_chassis_2wd",
    name: "Chasis Robot 2WD Smart Car con Ruedas y Caster",
    category: "Chasis & Estructuras",
    cloudOnly: true,
    cloudVersion: "v3.2",
    fileSize: "690 KB",
    downloads: "38.2K",
    rating: "5.0/5",
    description: "Plataforma robótica completa en acrílico con 2 ruedas motrices de goma de 65mm, rueda loca caster frontal y soporte para baterías y sensores.",
    specs: {
      voltage: 0,
      idleCurrent: 0,
      peakCurrent: 0,
      wheelDiameter: "65 mm",
      isPowerSource: false,
      pins: []
    },
    dimensions: { x: 200.0, y: 65.0, z: 150.0 },
    anchorPoints: [
      { id: "deck_center", pos: [0, 32, 0], type: "main_deck" },
      { id: "motor_slot_left", pos: [-30, 15, -60], type: "motor_tt_slot" },
      { id: "motor_slot_right", pos: [-30, 15, 60], type: "motor_tt_slot" },
      { id: "sensor_bumper", pos: [80, 35, 0], type: "sensor_bracket" }
    ],
    createMesh: function() {
      const group = new THREE.Group();
      group.name = "Chasis 2WD Smart Car";
      // Placa de acrílico ahumado
      const plateGeo = new THREE.BoxGeometry(20.0, 0.3, 15.0);
      const plateMat = new THREE.MeshPhysicalMaterial({
        color: 0x1e293b,
        roughness: 0.1,
        transmission: 0.8,
        thickness: 0.5,
        transparent: true,
        opacity: 0.85
      });
      const plate = new THREE.Mesh(plateGeo, plateMat);
      plate.position.set(0, 3.2, 0);
      group.add(plate);

      // Rueda izquierda (Neumático negro + Rin amarillo)
      const tireGeo = new THREE.CylinderGeometry(3.25, 3.25, 1.2, 24);
      const tireMat = new THREE.MeshStandardMaterial({ color: 0x18181b, roughness: 0.9 });
      const rimMat = new THREE.MeshStandardMaterial({ color: 0xfacc15, roughness: 0.3 });

      const wheelL = new THREE.Group();
      const tireL = new THREE.Mesh(tireGeo, tireMat);
      const rimL = new THREE.Mesh(new THREE.CylinderGeometry(2.4, 2.4, 1.22, 24), rimMat);
      wheelL.add(tireL);
      wheelL.add(rimL);
      wheelL.rotation.x = Math.PI / 2;
      wheelL.position.set(-3.0, 3.25, -7.8);
      group.add(wheelL);

      // Rueda derecha
      const wheelR = wheelL.clone();
      wheelR.position.set(-3.0, 3.25, 7.8);
      group.add(wheelR);

      // Rueda loca caster frontal (Bola metálica)
      const casterGeo = new THREE.SphereGeometry(1.2, 20, 20);
      const casterMat = new THREE.MeshStandardMaterial({ color: 0xe2e8f0, metalness: 0.9, roughness: 0.1 });
      const caster = new THREE.Mesh(casterGeo, casterMat);
      caster.position.set(7.5, 1.2, 0);
      group.add(caster);

      return group;
    }
  }
};
