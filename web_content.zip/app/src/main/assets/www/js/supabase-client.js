/**
 * আলী আজগর সিদ্দিকিয়া মাদ্রাসা
 * Supabase Client & Realtime Synchronization Module
 */

// Storage keys
const SB_URL_KEY = 'siddiqia_sb_url';
const SB_KEY_KEY = 'siddiqia_sb_anon_key';
const LOCAL_DB_KEY = 'siddiqia_local_db_v1';

let supabaseClient = null;
let isConnectedToSupabase = false;
let realtimeChannels = [];

// Default initial data for instant out-of-the-box functionality & offline resilience
const initialDemoData = {
  settings: {
    madrasa_profile: {
      name_bn: "আলী আজগর সিদ্দিকিয়া মাদ্রাসা",
      name_en: "Ali Azgar Siddiqia Madrasa",
      address: "সিদ্দিকিয়া রোড, ঢাকা",
      established: "১৯৮২",
      phone: "০১৭১২-৩৪৫৬৭৮",
      email: "aliazgarmadrasa@gmail.com"
    },
    chanda_config: {
      default_amount: 100,
      due_day_start: 1,
      due_day_end: 10,
      rule_text: "প্রতি মাসের ১ তারিখ থেকে ১০ তারিখের মধ্যে মাসিক চাঁদা জমা দেওয়ার নিয়ম।"
    },
    payment_accounts: {
      bkash: "UPI / PhonePe / GPay",
      nagad: "অফিসিয়াল যোগাযোগ",
      rocket: "",
      bank_details: "State Bank of India (SBI)\nহিসাব নাম: আলী আজগর সিদ্দিকিয়া মাদ্রাসা\nশাখা: স্থানীয় শাখা\nA/C নং: 6580..."
    },
    qr_image: ""
  },
  members: [
    { id: "m-001", member_id: "M-0001", name: "মুফতি নুরুল হক সিদ্দিকী", phone: "01711112233", address: "মাদ্রাসা কোয়ার্টার", join_date: "2024-01-10", is_active: true },
    { id: "m-002", member_id: "M-0002", name: "হাজী আব্দুর রহমান লস্কর", phone: "01822223344", address: "পূর্বপাড়া", join_date: "2024-01-15", is_active: true },
    { id: "m-003", member_id: "M-0003", name: "মাওলানা হাফিজুর রহমান", phone: "01933334455", address: "দক্ষিণ পাড়া", join_date: "2024-02-01", is_active: true },
    { id: "m-004", member_id: "M-0004", name: "আলহাজ্ব আবুল কাশেম", phone: "01744445566", address: "বাজার রোড", join_date: "2024-02-10", is_active: true },
    { id: "m-005", member_id: "M-0005", name: "জনাব শফিকুল ইসলাম", phone: "01855556677", address: "পশ্চিম পাড়া", join_date: "2024-03-05", is_active: true },
    { id: "m-006", member_id: "M-0006", name: "কারী আব্দুল্লাহ আল-মামুন", phone: "01666667788", address: "উত্তর পাড়া", join_date: "2024-03-12", is_active: true }
  ],
  payments: [
    { id: "p-001", receipt_no: "REC-2026-09-01", member_id: "m-001", month: "2026-09", amount: 100, status: "paid", payment_date: "2026-09-02", payment_method: "নগদ", trx_id: "CASH-001", confirmed_by: "admin-1", confirmed_at: "2026-09-02T10:00:00Z" },
    { id: "p-002", receipt_no: "REC-2026-09-02", member_id: "m-002", month: "2026-09", amount: 100, status: "paid", payment_date: "2026-09-04", payment_method: "বিকাশ", trx_id: "BK9X3489P", confirmed_by: "admin-1", confirmed_at: "2026-09-04T12:30:00Z" },
    { id: "p-003", receipt_no: "REC-2026-09-03", member_id: "m-003", month: "2026-09", amount: 100, status: "pending", payment_date: "2026-09-04", payment_method: "নগদ-অ্যাপ", trx_id: "NG782341", confirmed_by: null, confirmed_at: null },
    { id: "p-004", receipt_no: "REC-2026-08-01", member_id: "m-001", month: "2026-08", amount: 100, status: "paid", payment_date: "2026-08-05", payment_method: "নগদ", trx_id: "CASH-AUG1", confirmed_by: "admin-1", confirmed_at: "2026-08-05T09:00:00Z" },
    { id: "p-005", receipt_no: "REC-2026-08-02", member_id: "m-002", month: "2026-08", amount: 100, status: "paid", payment_date: "2026-08-06", payment_method: "বিকাশ", trx_id: "BK8899AA", confirmed_by: "admin-1", confirmed_at: "2026-08-06T11:00:00Z" },
    { id: "p-006", receipt_no: "REC-2026-08-03", member_id: "m-004", month: "2026-08", amount: 100, status: "paid", payment_date: "2026-08-08", payment_method: "নগদ", trx_id: "CASH-AUG4", confirmed_by: "admin-1", confirmed_at: "2026-08-08T15:00:00Z" }
  ],
  expenses: [
    { id: "e-001", voucher_no: "EXP-2026-001", title: "১৫ আগস্ট উপলক্ষে পতাকা ও অন্যান্য খরচ", amount: 580, category: "অনুষ্ঠান ও মাহফিল", expense_date: "2026-08-15", note: "জাতীয় পতাকা ও মিষ্টি বিতরণ", created_by: "admin-1" },
    { id: "e-002", voucher_no: "EXP-2026-002", title: "মাদ্রাসার বিদ্যুৎ বিল পরিশোধ", amount: 1250, category: "বিদ্যুৎ ও ইউটিলিটি", expense_date: "2026-08-20", note: "আগস্ট মাসের বিল", created_by: "admin-1" },
    { id: "e-003", voucher_no: "EXP-2026-003", title: "মসজিদ ও মাদ্রাসার পরিচ্ছন্নতা সামগ্রী ক্রয়", amount: 450, category: "রক্ষণাবেক্ষণ", expense_date: "2026-09-02", note: "হারপিক, ফিনাইল, ঝাড়ু", created_by: "admin-1" }
  ],
  notices: [
    { id: "n-001", title: "মাসিক চাঁদা জমা সংক্রান্ত জরুরি নিয়ম", body: "সম্মানিত সদস্যবৃন্দ, প্রতি মাসের ১ তারিখ থেকে ১০ তারিখের মধ্যে মাসিক চাঁদা জমা দেওয়ার নিয়ম। মাদ্রাসার উন্নয়ন ও শিক্ষক বেতনের সুবিধার্থে সময়মতো চাঁদা পরিশোধে সহযোগিতা করুন।", is_pinned: true, published_date: "2026-09-01" },
    { id: "n-002", title: "আসন্ন বার্ষিক ওয়াজ মাহফিল প্রস্তুতি সভা", body: "আগামী জুমাবার বাদ আসর মাদ্রাসা প্রাঙ্গণে বার্ষিক তাফসিরুল কুরআন ও ওয়াজ মাহফিল সংক্রান্ত পরামর্শ সভা অনুষ্ঠিত হবে। সকল সদস্যকে উপস্থিত থাকার অনুরোধ করা হলো।", is_pinned: false, published_date: "2026-08-28" }
  ],
  projects: [
    { id: "pr-001", name: "মাদ্রাসার মাইক ও সাউন্ড সিস্টেম মেরামত", description: "মসজিদ ও মাদ্রাসার আযান ও মাহফিলের জন্য উচ্চমানের সাউন্ড ইউনিট স্থাপন", estimated_cost: 15000, collected_amount: 15000, spent_amount: 14200, status: "সম্পন্ন" },
    { id: "pr-002", name: "মাদ্রাসার প্রবেশপথ ও রাস্তা ঢালাই", description: "বৃষ্টির দিনে চলাচলের সুবিধার জন্য পাকা কংক্রিট ঢালাই রাস্তা নির্মাণ", estimated_cost: 85000, collected_amount: 52000, spent_amount: 48000, status: "চলমান" },
    { id: "pr-003", name: "সোলার প্যানেল সিস্টেম স্থাপন", description: "নিরবচ্ছিন্ন আলোর জন্য ৩ কিলোওয়াট সোলার ইনভার্টার সিস্টেম", estimated_cost: 120000, collected_amount: 35000, spent_amount: 0, status: "পরিকল্পনাধীন" }
  ]
};

// Initialize Local Storage if empty
function initLocalStore() {
  if (!localStorage.getItem(LOCAL_DB_KEY)) {
    localStorage.setItem(LOCAL_DB_KEY, JSON.stringify(initialDemoData));
  }
}
initLocalStore();

function getLocalData() {
  try {
    const raw = localStorage.getItem(LOCAL_DB_KEY);
    return raw ? JSON.parse(raw) : initialDemoData;
  } catch (e) {
    console.error("Local data parse error:", e);
    return initialDemoData;
  }
}

function saveLocalData(data) {
  try {
    localStorage.setItem(LOCAL_DB_KEY, JSON.stringify(data));
  } catch (e) {
    console.error("Local data save error:", e);
  }
}

// Initialize Supabase Client
function initSupabase() {
  const url = localStorage.getItem(SB_URL_KEY);
  const key = localStorage.getItem(SB_KEY_KEY);

  if (url && key && window.supabase) {
    try {
      supabaseClient = window.supabase.createClient(url, key, {
        auth: {
          persistSession: true,
          autoRefreshToken: true
        }
      });
      isConnectedToSupabase = true;
      console.log("Supabase client initialized successfully with URL:", url);
      setupRealtime();
      return true;
    } catch (e) {
      console.warn("Failed to initialize Supabase client:", e);
      isConnectedToSupabase = false;
      return false;
    }
  } else {
    isConnectedToSupabase = false;
    return false;
  }
}

// Set up Supabase Realtime Channels
function setupRealtime() {
  if (!supabaseClient) return;

  // Clean old channels
  realtimeChannels.forEach(ch => ch.unsubscribe());
  realtimeChannels = [];

  try {
    const channel = supabaseClient
      .channel('schema-db-changes')
      .on('postgres_changes', { event: '*', schema: 'public' }, (payload) => {
        console.log('Realtime database update received:', payload);
        if (window.onSupabaseRealtimeChange) {
          window.onSupabaseRealtimeChange(payload);
        }
      })
      .subscribe();

    realtimeChannels.push(channel);
  } catch (e) {
    console.warn("Realtime subscription notice:", e);
  }
}

// Check configuration status
function isConfiguredWithSupabase() {
  return isConnectedToSupabase && supabaseClient !== null;
}

// Save credentials
function saveSupabaseCredentials(url, key) {
  if (!url || !key) {
    throw new Error("Supabase URL এবং Anon Key উভয়ই প্রয়োজন");
  }
  localStorage.setItem(SB_URL_KEY, url.trim());
  localStorage.setItem(SB_KEY_KEY, key.trim());
  return initSupabase();
}

function getSupabaseCredentials() {
  return {
    url: localStorage.getItem(SB_URL_KEY) || '',
    key: localStorage.getItem(SB_KEY_KEY) || ''
  };
}

// Expose on window
window.SupabaseModule = {
  initSupabase,
  isConfiguredWithSupabase,
  saveSupabaseCredentials,
  getSupabaseCredentials,
  getLocalData,
  saveLocalData,
  getClient: () => supabaseClient
};
