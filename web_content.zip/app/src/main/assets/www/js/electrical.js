/**
 * RoboSim AI Studio Pro - Electrical & Power Consumption Calculator
 * Analyzes active 3D components, sums milliampere (mA) draw, estimates battery runtime,
 * and generates advanced engineering alerts for brownouts, regulator overheating, and voltage drops.
 */

window.RoboElectrical = (function() {
  // Available power source presets
  const POWER_PRESETS = {
    "battery_18650_2s": {
      name: "Batería Li-Ion 18650 x2 (7.4V)",
      voltage: 7.4,
      capacityMah: 2500,
      maxDischargeMa: 5000,
      type: "Batería Recargable",
      internalResistance: "Baja (0.05 Ω)"
    },
    "battery_9v_alkaline": {
      name: "Pila Alcalina 9V (6LR61)",
      voltage: 9.0,
      capacityMah: 550,
      maxDischargeMa: 400,
      type: "Pila Primaria",
      internalResistance: "Alta (1.5 - 2.5 Ω)"
    },
    "battery_lipo_3s": {
      name: "Batería LiPo 3S 11.1V (2200mAh 30C)",
      voltage: 11.1,
      capacityMah: 2200,
      maxDischargeMa: 66000, // 30C
      type: "LiPo Alto Rendimiento",
      internalResistance: "Muy Baja (< 0.01 Ω)"
    },
    "usb_5v_port": {
      name: "Puerto USB 5V (PC / Cargador)",
      voltage: 5.0,
      capacityMah: Infinity,
      maxDischargeMa: 500, // Estándar USB 2.0 (o 900mA USB 3.0)
      type: "Fuente Fija USB",
      internalResistance: "N/A"
    },
    "adapter_12v_5a": {
      name: "Fuente de Poder 12V 5A (Taller)",
      voltage: 12.0,
      capacityMah: Infinity,
      maxDischargeMa: 5000,
      type: "Fuente Conmutada DC",
      internalResistance: "N/A"
    }
  };

  let selectedPowerSourceKey = "battery_18650_2s";

  function setPowerSource(key) {
    if (POWER_PRESETS[key]) {
      selectedPowerSourceKey = key;
    }
  }

  function getPowerSource() {
    return POWER_PRESETS[selectedPowerSourceKey];
  }

  function getAvailablePowerSources() {
    return POWER_PRESETS;
  }

  function calculate() {
    const placed = window.RoboEngine.getPlacedObjects();
    const powerSource = getPowerSource();

    let totalIdleMa = 0;
    let totalPeakMa = 0;
    let componentsSummary = [];
    let hasBatteryInScene = false;
    let hasController = false;
    let hasMotorsOrServos = false;
    let hasDriver = false;
    let hasESP32 = false;
    let has5VComponents = false;

    for (let item of placed) {
      const specs = item.dbData.specs || {};
      const idle = specs.idleCurrent || 0;
      const peak = specs.peakCurrent || idle;

      totalIdleMa += idle;
      totalPeakMa += peak;

      if (specs.isPowerSource) {
        hasBatteryInScene = true;
      }
      if (specs.isController) {
        hasController = true;
        if (item.dbId === "esp32_nodemcu") hasESP32 = true;
      }
      if (item.dbData.category === "Actuadores") {
        hasMotorsOrServos = true;
      }
      if (item.dbId === "driver_l298n") {
        hasDriver = true;
      }
      if (specs.voltage === 5.0) {
        has5VComponents = true;
      }

      componentsSummary.push({
        id: item.id,
        name: item.name,
        category: item.dbData.category,
        voltage: specs.voltage || 5.0,
        idleMa: idle,
        peakMa: peak
      });
    }

    // Weighted average consumption: 70% idle/cruising + 30% peak activity
    const totalAvgMa = Math.round(totalIdleMa * 0.65 + totalPeakMa * 0.35);

    // Calculate battery autonomy
    let runtimeHoursIdle = 0;
    let runtimeHoursAvg = 0;
    let runtimeHoursPeak = 0;

    if (isFinite(powerSource.capacityMah)) {
      runtimeHoursIdle = totalIdleMa > 0 ? (powerSource.capacityMah / totalIdleMa) : 0;
      runtimeHoursAvg = totalAvgMa > 0 ? (powerSource.capacityMah / totalAvgMa) : 0;
      runtimeHoursPeak = totalPeakMa > 0 ? (powerSource.capacityMah / totalPeakMa) : 0;
    } else {
      runtimeHoursIdle = Infinity;
      runtimeHoursAvg = Infinity;
      runtimeHoursPeak = Infinity;
    }

    // Power in Watts (P = V * I)
    const powerWattsAvg = ((powerSource.voltage * totalAvgMa) / 1000).toFixed(2);
    const powerWattsPeak = ((powerSource.voltage * totalPeakMa) / 1000).toFixed(2);

    // Generate intelligent engineering alerts
    const warnings = [];

    // 1. Brownout Reset Warning (Crucial Robotics Issue!)
    if (hasController && hasMotorsOrServos && !hasDriver && !hasBatteryInScene) {
      warnings.push({
        level: "danger",
        title: "🚨 Riesgo Crítico de Caída de Tensión (Brownout)",
        message: "Hay motores o servos en la escena sin etapa de potencia separada (driver L298N o batería dedicada). Alimentar motores directamente desde los 5V del microcontrolador provocará caídas bruscas de voltaje y reinicios espontáneos del procesador."
      });
    }

    // 2. High Current vs USB limit
    if (selectedPowerSourceKey === "usb_5v_port" && totalPeakMa > 500) {
      warnings.push({
        level: "warning",
        title: "⚠️ Exceso de Corriente en Puerto USB",
        message: `El consumo pico (${totalPeakMa} mA) supera el límite estándar de 500 mA de un puerto USB 2.0. El puerto del PC puede desactivarse por protección térmica.`
      });
    }

    // 3. 9V Alkaline Battery with Motors (Classic beginner mistake)
    if (selectedPowerSourceKey === "battery_9v_alkaline" && hasMotorsOrServos) {
      warnings.push({
        level: "danger",
        title: "⚠️ Pila de 9V Inadecuada para Motores",
        message: "Las pilas rectangulares de 9V tienen alta resistencia interna (~2Ω) y solo pueden suministrar unos 200-300mA continuos. Conectar servomotores o motores DC hará que el voltaje colapse a menos de 5V instantáneamente."
      });
    }

    // 4. Linear Regulator Overheating (LDO Thermal dissipation)
    if (powerSource.voltage >= 9.0 && totalAvgMa > 300) {
      const dropV = powerSource.voltage - 5.0;
      const heatWatts = ((dropV * totalAvgMa) / 1000).toFixed(2);
      warnings.push({
        level: "warning",
        title: "🌡️ Disipación Térmica en Regulador Lineal (LDO)",
        message: `La fuente entrega ${powerSource.voltage}V para circuitos lógicos de 5V. El regulador integrado deberá disipar aprox. ${heatWatts} W en forma de calor puro. A partir de 1.0W se requiere disipador adicional o un convertidor reductor DC-DC tipo Buck (LM2596).`
      });
    }

    // 5. Logic Level Mismatch (ESP32 3.3V vs 5V sensors)
    if (hasESP32 && has5VComponents) {
      warnings.push({
        level: "info",
        title: "ℹ️ Consideración de Niveles Lógicos (3.3V / 5V)",
        message: "El ESP32 opera a niveles lógicos de 3.3V en sus pines GPIO (no tolerantes a 5V). Al conectar señales de salida de 5V (ej: HC-SR04 Echo), se recomienda emplear un divisor resistivo (1kΩ / 2kΩ) o un convertidor de nivel bidireccional."
      });
    }

    if (warnings.length === 0 && placed.length > 0) {
      warnings.push({
        level: "success",
        title: "✅ Dimensionamiento Eléctrico Óptimo",
        message: `La fuente seleccionada (${powerSource.name}) proporciona suficiente corriente con margen de seguridad para los ${placed.length} componentes ensamblados.`
      });
    }

    return {
      powerSource,
      componentsCount: placed.length,
      componentsSummary,
      totalIdleMa,
      totalAvgMa,
      totalPeakMa,
      powerWattsAvg,
      powerWattsPeak,
      runtimeHoursIdle: formatHours(runtimeHoursIdle),
      runtimeHoursAvg: formatHours(runtimeHoursAvg),
      runtimeHoursPeak: formatHours(runtimeHoursPeak),
      warnings
    };
  }

  function formatHours(hours) {
    if (hours === Infinity) return "Ilimitada (Fuente AC/DC)";
    if (hours <= 0) return "0 min";
    if (hours < 1) {
      return `${Math.round(hours * 60)} min`;
    }
    const h = Math.floor(hours);
    const m = Math.round((hours - h) * 60);
    return `${h}h ${m}m`;
  }

  return {
    calculate,
    setPowerSource,
    getPowerSource,
    getAvailablePowerSources
  };
})();
