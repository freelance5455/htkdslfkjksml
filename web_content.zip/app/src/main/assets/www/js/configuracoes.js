
(function () {
    "use strict";

    const COLECAO = "configuracoes";

    const CONFIG_ID = "configuracao_principal";

    function verificarBanco() {
        if (!window.SGFE_DB) {
            throw new Error("O armazenamento do SGFE não está disponível.");
        }
    }

    // Configurações iniciais
    function configuracoesPadrao() {
        return {
            id: CONFIG_ID,

            instituicao: {
                nome: "",
                nomeAbreviado: "",
                logotipo: "",
                endereco: "",
                telefone: "",
                email: "",
                municipio: "",
                provincia: ""
            },

            financeira: {
                moeda: "Kz",
                casasDecimais: 2
            },

            categoriasReceitas: [
                "Matrícula",
                "Mensalidade",
                "Cantina",
                "Papelaria",
                "Outras receitas"
            ],

            categoriasDespesas: [
                "Água",
                "Energia eléctrica",
                "Internet",
                "Material escolar",
                "Manutenção",
                "Transporte",
                "Outras despesas"
            ],

            cargos: [
                "Director",
                "Director administrativo",
                "Professor",
                "Secretário",
                "Contabilista",
                "Auxiliar",
                "Outro"
            ],

            criadoEm: new Date().toISOString()
        };
    }

    // Carregar configurações
    async function carregar() {
        verificarBanco();

        let config = await window.SGFE_DB.obter(
            COLECAO,
            CONFIG_ID
        );

        if (!config) {
            config = configuracoesPadrao();

            await window.SGFE_DB.guardar(
                COLECAO,
                config
            );
        }

        return config;
    }

    // Guardar configurações
    async function guardar(dados) {
        verificarBanco();

        if (!dados || typeof dados !== "object") {
            throw new Error("Configurações inválidas.");
        }

        const anteriores = await carregar();

        const actualizadas = {
            ...anteriores,
            ...dados,
            id: CONFIG_ID,
            actualizadoEm: new Date().toISOString()
        };

        await window.SGFE_DB.guardar(
            COLECAO,
            actualizadas
        );

        await window.SGFE_DB.registarHistorico({
            operacao: "actualizacao",
            modulo: "configuracoes",
            descricao: "Configurações gerais actualizadas.",
            data: new Date().toISOString()
        });

        return actualizadas;
    }

    // Adicionar uma categoria
    async function adicionarCategoria(tipo, nome) {
        const config = await carregar();

        const campos = {
            receita: "categoriasReceitas",
            despesa: "categoriasDespesas",
            cargo: "cargos"
        };

        const campo = campos[tipo];

        if (!campo) {
            throw new Error("Tipo de categoria inválido.");
        }

        const valor = String(nome || "").trim();

        if (!valor) {
            throw new Error("Informe o nome da categoria.");
        }

        const lista = config[campo] || [];

        if (lista.some(item =>
            item.toLowerCase() === valor.toLowerCase()
        )) {
            throw new Error("Esta categoria já existe.");
        }

        lista.push(valor);
        config[campo] = lista;

        return await guardar(config);
    }

    // Remover uma categoria
    async function removerCategoria(tipo, nome) {
        const config = await carregar();

        const campos = {
            receita: "categoriasReceitas",
            despesa: "categoriasDespesas",
            cargo: "cargos"
        };

        const campo = campos[tipo];

        if (!campo) {
            throw new Error("Tipo de categoria inválido.");
        }

        config[campo] = (config[campo] || []).filter(item =>
            item !== nome
        );

        return await guardar(config);
    }

    // Criar cópia de segurança
    async function criarBackup() {
        verificarBanco();

        return await window.SGFE_DB.criarBackup();
    }

    // Restaurar cópia de segurança
    async function restaurarBackup(ficheiro, substituir = true) {
        verificarBanco();

        if (!ficheiro) {
            throw new Error("Seleccione um ficheiro de backup.");
        }

        return await window.SGFE_DB.restaurarBackup(
            ficheiro,
            substituir
        );
    }

    // Consultar espaço de armazenamento
    async function verificarEspaco() {
        verificarBanco();

        return await window.SGFE_DB.verificarArmazenamento();
    }

    window.SGFE_CONFIGURACOES = Object.freeze({
        carregar,
        guardar,
        adicionarCategoria,
        removerCategoria,
        criarBackup,
        restaurarBackup,
        verificarEspaco
    });

})();
