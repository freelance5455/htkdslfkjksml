/**
 * আলী আজগর সিদ্দিকিয়া মাদ্রাসা
 * Supabase Auth & Role-Based Security Manager
 */

const AUTH_USER_KEY = 'siddiqia_current_admin';

const Auth = {
  currentAdmin: null,
  authListeners: [],

  init() {
    try {
      const saved = localStorage.getItem(AUTH_USER_KEY);
      if (saved) {
        this.currentAdmin = JSON.parse(saved);
      }
    } catch (e) {
      console.warn("Auth parse error:", e);
      this.currentAdmin = null;
    }
  },

  isAdmin() {
    return this.currentAdmin !== null && (this.currentAdmin.role === 'admin' || this.currentAdmin.role === 'super_admin');
  },

  getCurrentUser() {
    return this.currentAdmin;
  },

  onAuthStateChange(cb) {
    if (typeof cb === 'function') {
      this.authListeners.push(cb);
    }
  },

  notifyListeners() {
    this.authListeners.forEach(cb => cb(this.currentAdmin));
  },

  async login(email, password) {
    if (!email || !password) {
      throw new Error("ইমেইল ও পাসওয়ার্ড উভয়ই আবশ্যক");
    }

    const cleanEmail = email.trim().toLowerCase();

    // 1. Check if Supabase Auth is configured and online
    if (window.SupabaseModule.isConfiguredWithSupabase()) {
      try {
        const client = window.SupabaseModule.getClient();
        const { data, error } = await client.auth.signInWithPassword({
          email: cleanEmail,
          password: password
        });

        if (error) throw error;

        if (data && data.user) {
          // Check admin_users table for verification
          const { data: adminRecord, error: adminErr } = await client
            .from('admin_users')
            .select('*')
            .eq('id', data.user.id)
            .single();

          if (adminErr || !adminRecord) {
            await client.auth.signOut();
            throw new Error("আপনার অ্যাকাউন্টটি অ্যাডমিন তালিকায় অনুমোদিত নয়");
          }

          this.currentAdmin = {
            id: adminRecord.id,
            email: adminRecord.email,
            name: adminRecord.full_name,
            role: adminRecord.role || 'admin',
            token: data.session?.access_token
          };

          localStorage.setItem(AUTH_USER_KEY, JSON.stringify(this.currentAdmin));
          this.notifyListeners();
          return this.currentAdmin;
        }
      } catch (sbError) {
        console.warn("Supabase Auth failed, checking demo fallback:", sbError);
        // If the user entered the default admin demo credentials, allow fallback
        if ((cleanEmail === 'admin@siddiqiamadrasa.edu.bd' || cleanEmail === 'admin@madrasa.com') && password === 'admin123') {
          return this.loginDemoAdmin(cleanEmail);
        }
        throw new Error(sbError.message || "লগইন ব্যর্থ হয়েছে। তথ্য যাচাই করুন।");
      }
    }

    // 2. Demo / Offline Admin Fallback
    if ((cleanEmail === 'admin@siddiqiamadrasa.edu.bd' || cleanEmail === 'admin@madrasa.com') && password === 'admin123') {
      return this.loginDemoAdmin(cleanEmail);
    }

    throw new Error("ভুল ইমেইল বা পাসওয়ার্ড প্রদান করা হয়েছে। (ডেমো অ্যাডমিন: admin@siddiqiamadrasa.edu.bd / পাসওয়ার্ড: admin123)");
  },

  loginDemoAdmin(email) {
    this.currentAdmin = {
      id: 'admin-1',
      email: email,
      name: 'প্রধান মুহতামিম (অ্যাডমিন)',
      role: 'super_admin'
    };
    localStorage.setItem(AUTH_USER_KEY, JSON.stringify(this.currentAdmin));
    this.notifyListeners();
    return this.currentAdmin;
  },

  async logout() {
    if (window.SupabaseModule.isConfiguredWithSupabase()) {
      try {
        const client = window.SupabaseModule.getClient();
        await client.auth.signOut();
      } catch (e) {
        console.warn("Supabase signout warning:", e);
      }
    }
    this.currentAdmin = null;
    localStorage.removeItem(AUTH_USER_KEY);
    this.notifyListeners();
    return true;
  }
};

Auth.init();
window.Auth = Auth;
