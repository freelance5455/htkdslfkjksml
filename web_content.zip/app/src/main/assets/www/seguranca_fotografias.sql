-- Edna Jongolo — Beauty & Loyalty
-- Restringe o carregamento/alteração/eliminação de fotografias à equipa autenticada.
-- Não apaga fotografias nem dados de clientes.

INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES ('customer-photos', 'customer-photos', true, 5242880,
        ARRAY['image/jpeg','image/png','image/webp'])
ON CONFLICT (id) DO UPDATE
SET public = true,
    file_size_limit = 5242880,
    allowed_mime_types = ARRAY['image/jpeg','image/png','image/webp'];

DROP POLICY IF EXISTS "Authenticated staff upload customer photos" ON storage.objects;
CREATE POLICY "Authenticated staff upload customer photos"
ON storage.objects FOR INSERT TO authenticated
WITH CHECK (bucket_id = 'customer-photos' AND public.is_manager_or_staff());

DROP POLICY IF EXISTS "Authenticated staff update customer photos" ON storage.objects;
CREATE POLICY "Authenticated staff update customer photos"
ON storage.objects FOR UPDATE TO authenticated
USING (bucket_id = 'customer-photos' AND public.is_manager_or_staff())
WITH CHECK (bucket_id = 'customer-photos' AND public.is_manager_or_staff());

DROP POLICY IF EXISTS "Authenticated staff delete customer photos" ON storage.objects;
CREATE POLICY "Authenticated staff delete customer photos"
ON storage.objects FOR DELETE TO authenticated
USING (bucket_id = 'customer-photos' AND public.is_manager_or_staff());
