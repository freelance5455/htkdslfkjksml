# Jay Jagannath Puja Committee App

A mobile-friendly, installable web app starter with:
- Photo gallery preloaded with the supplied Jay Jagannath photos.
- Firebase email/password member sign-in and registration.
- Members group chat using Cloud Firestore.
- Photo uploads using Firebase Storage.
- Responsive design and basic offline caching.

## Important
This ZIP is the **app source project**, not a compiled Android APK. Firebase cloud features will not work until you configure your own Firebase web app and publish the rules. The sample photo gallery works locally without Firebase. Do not upload a Firebase Admin SDK service-account JSON file or service-role secret into this project.

## 1. Configure Firebase
1. Open https://console.firebase.google.com/ and create/select your committee project.
2. In Project settings, create/register a **Web app** and copy its Firebase web configuration.
3. Edit `firebase-config.js` and replace each `YOUR_...` placeholder with the values from the Firebase web app configuration. The `apiKey` here is the public web app API key, not an Admin SDK private key.
4. In Firebase Authentication > Sign-in method, enable **Email/Password**.
5. Create a Cloud Firestore database.
6. In Firestore Rules, publish the contents of `firestore.rules`.
7. In Storage, enable Firebase Storage and publish the contents of `storage.rules`.
8. The app now loads saved cloud-gallery photo records from Firestore and uploads image files to Firebase Storage. Keep Firestore and Storage enabled for this feature.
9. For a private committee group, only share member accounts with approved committee members. The starter rules allow any signed-in account to read the chat; registration is open in this starter, so for a production private group restrict account creation or add an administrator approval/allowlist before sharing.

## 2. Run locally
Because this uses JavaScript modules, run it from a local web server rather than opening `index.html` directly.
- Install Node.js from https://nodejs.org/
- In this folder run: `npx serve .`
- Open the local address shown in the terminal.

You can also host the folder on Firebase Hosting or another HTTPS static host.

## 3. Deploy with Firebase Hosting (optional)
Install the Firebase CLI, sign in, run `firebase init hosting`, choose this project folder as the public directory, configure it as a single-page app only if desired (not required for this simple app), then run `firebase deploy`.

## 4. Add to Android home screen
After hosting on HTTPS, open the site in Chrome on Android and use the browser menu > **Add to Home screen**. This creates an installable shortcut/PWA. A native APK requires an additional Android build/wrapper step.

## Included photos
The `assets/` folder contains the five supplied images. Replace or add your own committee event photos as needed.

## Privacy and safety
- Do not publish personal phone numbers or private member information without permission.
- Use a strong password and restrict membership before using the group chat for committee business.
- Review Firebase billing, access rules, and data retention before public launch.


## Entry password and credit
- Entry screen password: `Jay jagannath` (case-sensitive).
- App credit: **Produced by Mr Biswa**.
- The entry screen is a basic convenience gate. Because the password is stored in browser JavaScript, it is not suitable for protecting confidential information. Use Firebase Authentication and restrictive database/storage rules for real member-only security.
