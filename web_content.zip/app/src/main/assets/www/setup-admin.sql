-- EXECUTE APENAS NO SQL EDITOR DO SEU PROJECTO.
-- Primeiro crie o utilizador em Authentication > Users.
-- Substitua os valores de exemplo pelos dados correctos.
-- Não partilhe este ficheiro publicamente.

insert into public.profiles (id, full_name, role)
values (
  'COLOQUE_O_UUID_DO_UTILIZADOR'::uuid,
  'Edna Jongolo',
  'manager'
)
on conflict (id) do update
set full_name = excluded.full_name,
    role = 'manager';

-- Se o esquema tiver sido executado antes e o perfil já existir,
-- a consulta acima actualiza-o para gerente.
