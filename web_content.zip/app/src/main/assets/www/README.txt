FORGELIFE PRO — OFFLINE-FIRST PERSONAL LIFE APP

PROJECT STRUCTURE
- index.html: app screens and semantic UI
- assets/styles.css: responsive design and accessibility styles
- assets/app.js: finance, budget, goals, workouts, notes, calendar, offline assistant and local memory
- assets/register-sw.js: safe service-worker registration
- service-worker.js: versioned app-shell cache for offline reopening
- manifest.json and icons/: install metadata and app icons

RUN / INSTALL ON ANDROID
1. Extract this ZIP. Keep the folders together.
2. For a quick test, open index.html in a modern browser. Some browser features are restricted on local files.
3. For PWA installation and reliable offline caching, host the entire folder on an HTTPS static host. A service worker cannot be installed from an ordinary file:// URL.
4. Open the HTTPS address in Chrome, wait for the first load to finish, then use Chrome menu > Install app / Add to Home screen.
5. Launch it once while online so the service worker can cache all app-shell files; then test offline mode.

DATA SAFETY
- Records and memories are stored locally in this browser/device, not automatically synced.
- Use the app's Export backup function before changing browser, clearing site data, or moving devices.
- Import only backups you trust. Do not use this prototype as the sole copy of important financial records.

AI LIMITATIONS
Forge's assistant uses bundled offline reference material and rules. It is not a genuine large language model and does not have live internet access. Current time/date come from the device. Personal plans can only be reported if they exist in the app's saved data.

BUILD STATUS
This is a modular PWA source project, not a signed Android APK. Creating an APK requires a native wrapper/build environment and signing.


ANDROID APP BUILDER ZIP LAYOUT (UPDATED)
This archive is flattened so index.html is at the ZIP root, with assets/, icons/, manifest.json and service-worker.js beside it. For an HTML-to-APK builder, select ZIP-to-APK / website bundle mode if available. Set the start page to index.html. If the builder requires a web/ folder, put the entire extracted bundle inside web/ without changing relative paths.

KNOWLEDGE DIRECTORY
The app includes 4,000 searchable offline guide entries across everyday domains. Entries are reference prompts and general guidance, not 4,000 separate AI models. Forge remains a rule-and-retrieval assistant, not a full language model; it can make mistakes and cannot fetch live facts offline.

CHAT AND MEMORY
The chat is text-only. Recent chat is saved locally in the same browser/app storage, and saved memories are stored on the device. Data may be lost if the app builder clears app data or changes the WebView storage origin; export a backup before reinstalling.


Version 2.1 finance cleanup: removed the “Use transaction total” control from the Finance page. The manual current-balance field and transaction records remain.


KNOWLEDGE DIRECTORY — BUILD 2.3
- Includes 4,000 distinct, searchable offline knowledge entries across 20 practical categories.
- The directory search scans all entries but renders at most 100 results at a time to keep Android WebView responsive.
- Content is practical general guidance, not a substitute for live information or professional advice. Forge remains a rule-based offline assistant, not a hosted neural AI model.
- The launch screen stays until the user taps ENTER FORGELIFE. Finance current balance persistence uses local storage plus IndexedDB where supported.
