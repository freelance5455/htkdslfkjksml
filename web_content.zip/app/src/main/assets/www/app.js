(() => {
 const cfg=window.FILMTO_CONFIG||{};
 const configured=cfg.SUPABASE_URL&&cfg.SUPABASE_ANON_KEY&&!cfg.SUPABASE_URL.includes("YOUR_")&&!cfg.SUPABASE_ANON_KEY.includes("YOUR_");
 const client=configured&&window.supabase?window.supabase.createClient(cfg.SUPABASE_URL,cfg.SUPABASE_ANON_KEY):null;
 const $=id=>document.getElementById(id);
 let user=null,signup=false,showMine=false,query="";
 const toast=t=>{const el=$("toast");el.textContent=t;el.style.display="block";setTimeout(()=>el.style.display="none",2600)};
 const msg=(id,t)=>$(id).textContent=t;
 const escapeHtml=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
 function setupNotice(){if(!client){$("feed").innerHTML='<div class="empty">برای فعال شدن نسخه چندکاربره، ابتدا اطلاعات پروژه Supabase را در فایل config.js وارد کنید.</div>'; $("authBtn").disabled=true;return;}}
 function authPanel(force){$("authPanel").classList.toggle("hidden",!force);if(force)$("email").focus();}
 $("authBtn").onclick=()=>authPanel($("authPanel").classList.contains("hidden"));
 $("switchAuth").onclick=()=>{signup=!signup;$("authTitle").textContent=signup?"ساخت حساب فیلم‌تو":"ورود به فیلم‌تو";$("submitAuth").textContent=signup?"ثبت‌نام":"ورود";$("displayName").classList.toggle("hidden",!signup);$("switchText").textContent=signup?"قبلاً حساب داری؟":"حساب نداری؟";$("switchAuth").textContent=signup?"وارد شو":"ثبت‌نام کن";};
 $("submitAuth").onclick=async()=>{if(!client)return;const email=$("email").value.trim(),password=$("password").value;msg("authMsg","در حال اتصال...");
 try{let r;if(signup){r=await client.auth.signUp({email,password,options:{data:{display_name:$("displayName").value.trim()||email.split("@")[0]}}});}else{r=await client.auth.signInWithPassword({email,password});}
 if(r.error)throw r.error;msg("authMsg",signup?"حساب ساخته شد. اگر تأیید ایمیل فعال است، ایمیلت را بررسی کن.":"ورود موفق بود.");if(r.data.session){authPanel(false);toast("خوش آمدی!");} }catch(e){msg("authMsg",e.message||"خطا در ورود");}};
 async function syncAuth(){if(!client)return;const {data}=await client.auth.getSession();user=data.session?.user||null;client.auth.onAuthStateChange((_event,session)=>{user=session?.user||null;updateUI();loadFeed();});updateUI();}
 function updateUI(){$("authBtn").textContent=user?"خروج":"ورود";$("uploadPanel").classList.toggle("hidden",!user);if(!user)showMine=false;}
 $("authBtn").addEventListener("click",async()=>{if(user){await client.auth.signOut();user=null;updateUI();loadFeed();toast("خارج شدی");}});
 async function loadFeed(){if(!client)return; $("feed").innerHTML='<div class="empty">در حال دریافت ویدئوها...</div>';
 try{let q=client.from("videos").select("*").order("created_at",{ascending:false}).limit(50);if(showMine&&user)q=q.eq("user_id",user.id);if(query)q=q.ilike("title",`%${query}%`);const {data,error}=await q;if(error)throw error;renderVideos(data||[]);}catch(e){$("feed").innerHTML='<div class="empty">دریافت ویدئوها ناموفق بود: '+escapeHtml(e.message)+'</div>';}}
 function renderVideos(videos){if(!videos.length){$("feed").innerHTML='<div class="empty">هنوز ویدئویی منتشر نشده است.</div>';return;}
 $("feed").innerHTML=videos.map(v=>`<article class="video-card" data-id="${v.id}">
 <video controls playsinline preload="metadata" src="${escapeHtml(v.video_url)}"></video>
 <div class="video-meta"><h3>${escapeHtml(v.title)}</h3><p>${escapeHtml(v.description||"")}</p>
 <div class="meta-row"><span>${escapeHtml(v.display_name||"کاربر فیلم‌تو")}</span><span>${new Date(v.created_at).toLocaleDateString("fa-IR")}</span></div>
 <div class="actions"><button class="like">♡ لایک</button><button class="comment-toggle">نظرها</button></div>
 <div class="comments-area"></div></div></article>`).join("");
 document.querySelectorAll(".video-card").forEach(card=>{const id=card.dataset.id;card.querySelector(".like").onclick=()=>likeVideo(id,card.querySelector(".like"));card.querySelector(".comment-toggle").onclick=()=>showComments(id,card.querySelector(".comments-area"));});
 }
 async function likeVideo(id,button){if(!user){toast("برای لایک ابتدا وارد شو");return;}try{const {error}=await client.from("video_likes").upsert({video_id:id,user_id:user.id},{onConflict:"video_id,user_id",ignoreDuplicates:true});if(error)throw error;button.classList.add("liked");button.textContent="♥ پسندیدم";}catch(e){toast(e.message);}}
 async function showComments(id,area){if(!client)return;area.innerHTML='<div class="comments">در حال دریافت نظرها...</div>';try{const {data,error}=await client.from("video_comments").select("id,body,created_at").eq("video_id",id).order("created_at",{ascending:false}).limit(30);if(error)throw error;area.innerHTML=(data||[]).map(c=>`<div class="comments">• ${escapeHtml(c.body)}</div>`).join("")+`<div class="comment-box"><input maxlength="500" placeholder="نظر خود را بنویس..."><button class="primary">ارسال</button></div>`;const inp=area.querySelector("input");area.querySelector("button").onclick=async()=>{if(!user){toast("برای نظر دادن وارد شو");return;}const body=inp.value.trim();if(!body)return;const {error}=await client.from("video_comments").insert({video_id:id,user_id:user.id,body});if(error)toast(error.message);else showComments(id,area);};}catch(e){area.textContent=e.message;}}
 $("uploadBtn").onclick=async()=>{if(!user){toast("ابتدا وارد حساب شو");return;}const file=$("videoFile").files[0],title=$("videoTitle").value.trim();if(!file||!title){msg("uploadStatus","عنوان و فایل ویدئو را انتخاب کن.");return;}if(!file.type.startsWith("video/")){msg("uploadStatus","فقط فایل ویدئویی مجاز است.");return;}if(file.size>200*1024*1024){msg("uploadStatus","حداکثر حجم این نسخه ۲۰۰ مگابایت است.");return;}
 const btn=$("uploadBtn");btn.disabled=true;msg("uploadStatus","در حال آپلود؛ برنامه را نبند...");
 try{const ext=(file.name.split(".").pop()||"mp4").replace(/[^a-zA-Z0-9]/g,"");const path=`${user.id}/${crypto.randomUUID()}.${ext}`;const {error:upErr}=await client.storage.from("videos").upload(path,file,{contentType:file.type,upsert:false});if(upErr)throw upErr;const {data:urlData}=client.storage.from("videos").getPublicUrl(path);const {error:dbErr}=await client.from("videos").insert({user_id:user.id,title,description:$("videoDescription").value.trim(),storage_path:path,video_url:urlData.publicUrl,display_name:user.user_metadata?.display_name||user.email?.split("@")[0]});if(dbErr)throw dbErr;msg("uploadStatus","ویدئو با موفقیت منتشر شد.");$("videoTitle").value="";$("videoDescription").value="";$("videoFile").value="";showMine=false;loadFeed();toast("ویدئو منتشر شد!");}catch(e){msg("uploadStatus","خطا: "+e.message);}finally{btn.disabled=false;}};
 $("refresh").onclick=loadFeed;$("search").oninput=e=>{query=e.target.value.trim();loadFeed();};
 $("homeNav").onclick=()=>{showMine=false;loadFeed();};$("uploadNav").onclick=()=>{if(!user){authPanel(true);toast("برای انتشار وارد شو");}else{$("uploadPanel").classList.remove("hidden");$("uploadPanel").scrollIntoView({behavior:"smooth"});}};
 $("myNav").onclick=()=>{if(!user){authPanel(true);return;}showMine=true;loadFeed();};$("profileNav").onclick=()=>authPanel(true);
 setupNotice();if(client){syncAuth().then(loadFeed);}
})();