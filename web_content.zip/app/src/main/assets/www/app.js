const KEY='mtp_data_v1';
const incomeCats=['เงินเดือน','ค่าจ้าง','โบนัส','ธุรกิจ','ขายสินค้า','ดอกเบี้ย','ของขวัญ','อื่นๆ'];
const expenseCats=['อาหาร','เดินทาง','ที่พัก','ค่าน้ำ','ค่าไฟ','โทรศัพท์/อินเทอร์เน็ต','ช้อปปิ้ง','สุขภาพ','การศึกษา','บันเทิง','ครอบครัว','ภาษี/ประกัน','อื่นๆ'];
let data=load();
let currentType='EXPENSE';
const $=id=>document.getElementById(id);
function load(){try{return JSON.parse(localStorage.getItem(KEY))||{transactions:[],budget:0,goals:[],theme:'dark'}}catch{return {transactions:[],budget:0,goals:[],theme:'dark'}}}
function save(){localStorage.setItem(KEY,JSON.stringify(data));render()}
function money(n){return new Intl.NumberFormat('th-TH',{style:'currency',currency:'THB'}).format(Number(n)||0)}
function dateToday(){return new Date().toISOString().slice(0,10)}
function monthNow(){return dateToday().slice(0,7)}
function setPage(name){document.querySelectorAll('.page').forEach(p=>p.classList.toggle('active',p.id===name));document.querySelectorAll('.tab').forEach(b=>b.classList.toggle('active',b.dataset.page===name));if(name==='add')$('entryDate').value=dateToday()}
function categories(){const list=currentType==='INCOME'?incomeCats:expenseCats;$('entryCategory').innerHTML=list.map(x=>`<option>${x}</option>`).join('')}
function setType(type){currentType=type;$('entryType').value=type;document.querySelectorAll('.segmented button').forEach(b=>b.classList.toggle('selected',b.dataset.type===type));categories()}
function addTx(tx){data.transactions.unshift({...tx,id:crypto.randomUUID?crypto.randomUUID():String(Date.now()),createdAt:Date.now()});save()}
function render(){const tx=data.transactions;const inc=tx.filter(x=>x.type==='INCOME').reduce((a,x)=>a+x.amount,0);const exp=tx.filter(x=>x.type==='EXPENSE').reduce((a,x)=>a+x.amount,0);$('totalIncome').textContent=money(inc);$('totalExpense').textContent=money(exp);$('balance').textContent=money(inc-exp);$('savedTotal').textContent=money(data.goals.reduce((a,g)=>a+g.saved,0));drawList($('recentList'),tx.slice(0,5));const q=($('searchInput')?.value||'').toLowerCase();const filter=$('filterType')?.value||'ALL';drawList($('allList'),tx.filter(x=>(filter==='ALL'||x.type===filter)&&(`${x.title} ${x.category} ${x.note}`).toLowerCase().includes(q)));renderBudget(exp);renderGoals();$('storageStatus').textContent='พร้อมใช้งาน'}
function drawList(el,items){if(!items.length){el.className='transaction-list empty';el.textContent='ยังไม่มีรายการ';return}el.className='transaction-list';el.innerHTML=items.map(x=>`<div class="tx"><div class="tx-icon">${x.type==='INCOME'?'↙':'↗'}</div><div class="tx-info"><b>${esc(x.title)}</b><small>${esc(x.category)} • ${esc(x.wallet)} • ${esc(x.date)}</small></div><div class="tx-amount ${x.type.toLowerCase()}">${x.type==='INCOME'?'+':'−'}${money(x.amount)}</div><button class="delete" data-delete="${x.id}" aria-label="ลบ">×</button></div>`).join('')}
function renderBudget(){const spent=data.transactions.filter(x=>x.type==='EXPENSE'&&x.date?.startsWith(monthNow())).reduce((a,x)=>a+x.amount,0);const b=Number(data.budget)||0;$('budgetProgressText').textContent=b?`${money(spent)} / ${money(b)} (${Math.min(100,spent/b*100).toFixed(0)}%)`:'ยังไม่ได้กำหนดงบประมาณ';$('budgetProgress').style.width=b?`${Math.min(100,spent/b*100)}%`:'0%'}
function renderGoals(){$('goalList').innerHTML=data.goals.map(g=>`<article class="goal-card"><b>${esc(g.name)}</b><p>${money(g.saved)} / ${money(g.target)}</p><div class="progress"><span style="width:${Math.min(100,g.saved/g.target*100)}%"></span></div></article>`).join('')||'<p class="hint">ยังไม่มีเป้าหมายเงินออม</p>'}
function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
document.querySelectorAll('.tab').forEach(b=>b.addEventListener('click',()=>setPage(b.dataset.page)));
document.querySelectorAll('[data-go]').forEach(b=>b.addEventListener('click',()=>setPage(b.dataset.go)));
$('quickAdd').onclick=$('addFromList').onclick=()=>setPage('add');
document.querySelectorAll('.segmented button').forEach(b=>b.addEventListener('click',()=>setType(b.dataset.type)));
$('transactionForm').addEventListener('submit',e=>{e.preventDefault();const amount=Number($('entryAmount').value);if(!Number.isFinite(amount)||amount<=0)return alert('กรุณากรอกจำนวนเงินให้ถูกต้อง');addTx({title:$('entryTitle').value.trim(),amount,type:currentType,category:$('entryCategory').value,wallet:$('entryWallet').value,date:$('entryDate').value,note:$('entryNote').value.trim()});e.target.reset();$('entryDate').value=dateToday();setType('EXPENSE');setPage('dashboard')});
document.addEventListener('click',e=>{const id=e.target.closest('[data-delete]')?.dataset.delete;if(id&&confirm('ต้องการลบรายการนี้หรือไม่?')){data.transactions=data.transactions.filter(x=>x.id!==id);save()}});
$('searchInput').addEventListener('input',render);$('filterType').addEventListener('change',render);
$('budgetForm').addEventListener('submit',e=>{e.preventDefault();data.budget=Number($('budgetAmount').value)||0;save();alert('บันทึกงบประมาณแล้ว')});
$('savingsForm').addEventListener('submit',e=>{e.preventDefault();data.goals.push({name:$('goalName').value.trim(),target:Number($('goalTarget').value),saved:Number($('goalSaved').value)||0});save();e.target.reset()});
$('themeBtn').onclick=()=>{data.theme=data.theme==='dark'?'light':'dark';applyTheme();save()};
function applyTheme(){document.documentElement.classList.toggle('light',data.theme==='light')}
function download(name,content,type){const a=document.createElement('a');const u=URL.createObjectURL(new Blob([content],{type}));a.href=u;a.download=name;a.click();URL.revokeObjectURL(u)}
$('exportCsv').onclick=()=>{const rows=[['date','type','title','amount','category','wallet','note'],...data.transactions.map(x=>[x.date,x.type,x.title,x.amount,x.category,x.wallet,x.note])];const csv='\ufeff'+rows.map(r=>r.map(v=>'"'+String(v??'').replace(/"/g,'""')+'"').join(',')).join('\n');download('money-tracker-transactions.csv',csv,'text/csv;charset=utf-8')};
$('backupJson').onclick=()=>download('money-tracker-backup.json',JSON.stringify(data,null,2),'application/json');
$('restoreJson').onchange=async e=>{try{const f=e.target.files[0];if(!f)return;const incoming=JSON.parse(await f.text());if(!Array.isArray(incoming.transactions)||!Array.isArray(incoming.goals))throw Error();if(confirm('นำเข้าข้อมูลและแทนที่ข้อมูลปัจจุบัน?')){data={...data,...incoming};save();alert('นำเข้าข้อมูลสำเร็จ')}}catch{alert('ไฟล์สำรองไม่ถูกต้อง')}e.target.value=''};
$('clearData').onclick=()=>{if(confirm('ลบข้อมูลทั้งหมดอย่างถาวร? ควรสำรองข้อมูลก่อน')){data={transactions:[],budget:0,goals:[],theme:data.theme};save()}};
applyTheme();$('entryDate').value=dateToday();categories();render();
