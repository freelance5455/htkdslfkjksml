(() => {
  const $ = id => document.getElementById(id);
  const cfg = window.APP_CONFIG || {};
  const configured = cfg.SUPABASE_URL && cfg.SUPABASE_ANON_KEY &&
    cfg.SUPABASE_URL.startsWith("https://") &&
    !cfg.SUPABASE_URL.includes("COLOQUE_AQUI") &&
    !cfg.SUPABASE_ANON_KEY.includes("COLOQUE_AQUI");

  let supabase = null, customers = [], installPrompt = null;

  const show = (id, yes = true) => $(id).classList.toggle("hidden", !yes);
  const msg = (id, text, kind = "") => {
    $(id).textContent = text;
    $(id).className = "message " + kind;
  };
  const errorText = e => e?.message || String(e || "Ocorreu um erro.");
  const escapeHtml = s => String(s ?? "").replace(/[&<>"']/g, c => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  }[c]));

  function tokenHex(bytes = 32) {
    const arr = new Uint8Array(bytes);
    crypto.getRandomValues(arr);
    return [...arr].map(x => x.toString(16).padStart(2, "0")).join("");
  }

  async function sha256(text) {
    const data = new TextEncoder().encode(text);
    const digest = await crypto.subtle.digest("SHA-256", data);
    return [...new Uint8Array(digest)].map(x => x.toString(16).padStart(2, "0")).join("");
  }

  function getQrToken() {
    return new URL(location.href).searchParams.get("card");
  }

  async function init() {
    const token = getQrToken();
    if (token) {
      show("loginPanel", false);
      show("publicCard", true);
      await loadPublicCard(token);
      return;
    }
    if (!configured || !window.supabase) {
      show("setupNotice", true);
      msg("loginMessage", "Preencha primeiro o ficheiro config.js e publique o site por HTTPS.", "error");
      return;
    }
    supabase = window.supabase.createClient(cfg.SUPABASE_URL, cfg.SUPABASE_ANON_KEY);
    const { data: { session } } = await supabase.auth.getSession();
    if (session) await showDashboard(session.user);
  }

  async function loadPublicCard(token) {
    if (!configured || !window.supabase) {
      msg("publicMessage", "O cartão ainda não está ligado ao Supabase.", "error");
      return;
    }
    const client = window.supabase.createClient(cfg.SUPABASE_URL, cfg.SUPABASE_ANON_KEY);
    const { data, error } = await client.rpc("customer_card_by_qr", { p_token: token });
    if (error) {
      msg("publicMessage", "Não foi possível consultar este cartão. Confirme se o QR é válido e se a função customer_card_by_qr está instalada.", "error");
      return;
    }
    msg("publicMessage", "");
    const target = $("publicCardData");
    show("publicCardData", true);
    const photo = data.photo_url ? `<img class="customer-photo" src="${escapeHtml(data.photo_url)}" alt="Fotografia de ${escapeHtml(data.customer_name)}">` : "";
    target.innerHTML = `<div class="loyalty-card">${photo}<p class="eyebrow">CLIENTE</p><h3>${escapeHtml(data.customer_name)}</h3><div class="progress-line"><span style="width:${Math.min(100, Number(data.paid_services_progress || 0) * 10)}%"></span></div><p><strong>${Number(data.paid_services_progress || 0)} de 10 serviços</strong></p><p>Faltam <strong>${Number(data.services_remaining || 0)}</strong> serviço(s) para a próxima recompensa.</p><p>Recompensas disponíveis: <strong>${Number(data.available_rewards || 0)}</strong></p></div>`;
  }

  async function showDashboard(user) {
    show("loginPanel", false);
    show("dashboard", true);
    $("staffEmail").textContent = user.email || "";
    await loadCustomers();
    await loadStats();
  }

  async function loadCustomers() {
    const { data, error } = await supabase.from("customers")
      .select("id,full_name,phone,photo_url,created_at").order("created_at", { ascending: false });
    if (error) {
      $("customersTable").innerHTML = `<tr><td colspan="6">${escapeHtml(error.message)} — confirme se o perfil tem função gerente/equipa.</td></tr>`;
      return;
    }
    customers = data || [];
    const [servicesResult, rewardsResult] = await Promise.all([
      supabase.from("service_records").select("customer_id,kind"),
      supabase.from("rewards").select("id,customer_id,status")
    ]);
    if (servicesResult.error || rewardsResult.error) {
      const err = servicesResult.error || rewardsResult.error;
      $("customersTable").innerHTML = `<tr><td colspan="6">Não foi possível consultar os totais por cliente: ${escapeHtml(err.message)}. Os registos não foram alterados.</td></tr>`;
      $("serviceCustomer").innerHTML = `<option value="">Escolha uma cliente</option>` + customers.map(c => `<option value="${c.id}">${escapeHtml(c.full_name)}</option>`).join("");
      $("customerCount").textContent = customers.length;
      return;
    }

    const paidByCustomer = {}, availableRewardsByCustomer = {};
    const firstAvailableReward = {};
    (servicesResult.data || []).forEach(r => {
      if (r.kind === "paid") paidByCustomer[r.customer_id] = (paidByCustomer[r.customer_id] || 0) + 1;
    });
    (rewardsResult.data || []).forEach(r => {
      if (r.status === "available") {
        availableRewardsByCustomer[r.customer_id] = (availableRewardsByCustomer[r.customer_id] || 0) + 1;
        if (!firstAvailableReward[r.customer_id]) firstAvailableReward[r.customer_id] = r.id;
      }
    });

    $("customerCount").textContent = customers.length;
    $("customersTable").innerHTML = customers.length ? customers.map(c => {
      const rewardCount = availableRewardsByCustomer[c.id] || 0;
      const redeemButton = rewardCount > 0
        ? ` <button class="small-btn" data-redeem="${c.id}" data-reward="${firstAvailableReward[c.id]}">Utilizar recompensa</button>`
        : "";
      return `<tr>
  <td>${escapeHtml(c.full_name)}</td>
  <td>${escapeHtml(c.phone || "—")}</td>
  <td>${c.created_at ? new Date(c.created_at).toLocaleDateString("pt-PT") : "—"}</td>
  <td>${paidByCustomer[c.id] || 0}</td>
  <td>${rewardCount}</td>
  <td>
    <button class="small-btn" data-customer="${c.id}">Seleccionar</button>
    <button class="small-btn" data-reissue="${c.id}">Novo QR</button>
    ${redeemButton}
    <button class="small-btn" data-delete="${c.id}">Eliminar</button>
  </td>
</tr>`;
    }).join("") : `<tr><td colspan="6" class="muted">Ainda não há clientes.</td></tr>`;
    $("serviceCustomer").innerHTML = `<option value="">Escolha uma cliente</option>` + customers.map(c => `<option value="${c.id}">${escapeHtml(c.full_name)}</option>`).join("");
  }

  async function loadStats() {
    const [s, r] = await Promise.all([
      supabase.from("service_records").select("id", { count: "exact", head: true }),
      supabase.from("rewards").select("id", { count: "exact", head: true }).eq("status", "available")
    ]);
    $("serviceCount").textContent = s.error ? "—" : (s.count ?? 0);
    $("rewardCount").textContent = r.error ? "—" : (r.count ?? 0);
  }

  async function redeemReward(customerId, rewardId) {
    const customer = customers.find(c => c.id === customerId);
    if (!customer || !rewardId) return;
    const serviceName = window.prompt(`Indique o serviço gratuito utilizado por ${customer.full_name}:`);
    if (serviceName === null) return;
    if (!serviceName.trim()) {
      window.alert("Indique o nome do serviço gratuito.");
      return;
    }
    if (!window.confirm(`Confirmas a utilização da recompensa de ${customer.full_name} para o serviço «${serviceName.trim()}»?`)) return;
    try {
      const { error } = await supabase.rpc("redeem_reward", {
        p_reward_id: rewardId,
        p_service_name: serviceName.trim()
      });
      if (error) throw error;
      msg("serviceMessage", `Recompensa utilizada para ${customer.full_name}. O histórico foi preservado.`, "success");
      await loadCustomers();
      await loadStats();
    } catch (err) {
      msg("serviceMessage", `Não foi possível utilizar a recompensa: ${errorText(err)}`, "error");
    }
  }
  async function reissueCustomerQr(customerId) {
  const customer = customers.find(c => c.id === customerId);
  if (!customer) return;

  if (!window.confirm(
    `Queres gerar um novo QR Code para ${customer.full_name}? O cartão QR anterior deixará de funcionar.`
  )) {
    return;
  }

  try {
    const token = tokenHex();
    const tokenHash = await sha256(token);

    const { error } = await supabase
      .from("customers")
      .update({ qr_token_hash: tokenHash })
      .eq("id", customerId);

    if (error) throw error;

    const cardUrl =
      `${location.origin}${location.pathname}?card=${encodeURIComponent(token)}`;

    const qrPage = window.open("", "_blank");

    if (!qrPage) {
      window.prompt(
        "O navegador bloqueou a nova página. Copia este endereço:",
        cardUrl
      );
      return;
    }

    qrPage.document.open();
    qrPage.document.write(`
      <!DOCTYPE html>
      <html lang="pt">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Cartão QR — Edna Jongolo Beauty & Loyalty</title>
        <style>
          body {
            font-family: Arial, sans-serif;
            text-align: center;
            background: #fff8fb;
            color: #6f294f;
            padding: 30px 15px;
          }
          .card {
            max-width: 420px;
            margin: 20px auto;
            padding: 28px;
            background: white;
            border: 2px solid #6f294f;
            border-radius: 18px;
          }
          #qrcode {
            display: flex;
            justify-content: center;
            margin: 25px 0;
          }
          button {
            background: #6f294f;
            color: white;
            border: 0;
            border-radius: 8px;
            padding: 12px 20px;
            cursor: pointer;
            font-size: 16px;
          }
          .url {
            overflow-wrap: anywhere;
            font-size: 12px;
            color: #444;
          }
          @media print {
            button { display: none; }
            body { background: white; }
          }
        </style>
      </head>
      <body>
        <div class="card">
          <h2>EDNA JONGOLO</h2>
          <h3>BEAUTY & LOYALTY</h3>
          <hr>
          <p>Cartão de fidelização de</p>
          <h2>${customer.full_name.replace(/[&<>"']/g, c => ({
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&#39;"
          }[c]))}</h2>
          <div id="qrcode"></div>
          <p>Digitaliza o QR Code para consultar o teu cartão.</p>
          <p class="url">${cardUrl}</p>
          <button onclick="window.print()">Imprimir / Guardar em PDF</button>
        </div>

        <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"><\/script>
        <script>
          new QRCode(document.getElementById("qrcode"), {
            text: ${JSON.stringify(cardUrl)},
            width: 220,
            height: 220,
            correctLevel: QRCode.CorrectLevel.H
          });
        <\/script>
      </body>
      </html>
    `);
    qrPage.document.close();

    await loadCustomers();
    msg(
      "serviceMessage",
      `Novo cartão QR preparado para ${customer.full_name}.`,
      "success"
    );
  } catch (err) {
    msg(
      "serviceMessage",
      `Não foi possível gerar o novo cartão QR: ${errorText(err)}`,
      "error"
    );
  }
}
async function deleteCustomer(customerId) {
  const customer = customers.find(c => c.id === customerId);
  if (!customer) return;

  const confirmation = window.prompt(
    `ATENÇÃO: serão eliminados definitivamente a cliente, os serviços e as recompensas.\n\nPara confirmar, escreve o nome completo:\n${customer.full_name}`
  );

  if (confirmation === null) return;

  if (confirmation.trim() !== customer.full_name.trim()) {
    window.alert("O nome não corresponde. A cliente não foi eliminada.");
    return;
  }

  try {
    const { data, error } = await supabase.rpc(
      "delete_customer_with_history",
      { p_customer_id: customerId }
    );

    if (error) throw error;

    msg(
      "serviceMessage",
      data?.message || "Cliente eliminada com sucesso.",
      "success"
    );

    await loadCustomers();
    await loadStats();
  } catch (err) {
    msg(
      "serviceMessage",
      `Não foi possível eliminar a cliente: ${errorText(err)}`,
      "error"
    );
  }
}
  async function createCustomer(event) {
    event.preventDefault();
    msg("customerMessage", "");

    const fullName = $("customerName").value.trim();
    const phone = $("customerPhone").value.trim();
    const photoFile = $("customerPhoto").files?.[0];

    if (!fullName) {
      msg("customerMessage", "Introduza o nome completo da cliente.", "error");
      return;
    }

    if (photoFile) {
      if (!["image/jpeg", "image/png", "image/webp"].includes(photoFile.type)) {
        msg("customerMessage", "Use uma fotografia JPG, PNG ou WebP.", "error");
        return;
      }

      if (photoFile.size > 5 * 1024 * 1024) {
        msg("customerMessage", "A fotografia deve ter no máximo 5 MB.", "error");
        return;
      }
    }

    try {
      const token = tokenHex();
      const tokenHash = await sha256(token);

      const { data, error } = await supabase.from("customers")
        .insert({
          full_name: fullName,
          phone: phone || null,
          qr_token_hash: tokenHash
        })
        .select("id,full_name")
        .single();

      if (error) throw error;

      if (photoFile) {
        const ext = photoFile.type === "image/png" ? "png"
          : photoFile.type === "image/webp" ? "webp" : "jpg";

        const photoPath = `${data.id}/${Date.now()}.${ext}`;

        const { data: sessionData, error: sessionError } =
          await supabase.auth.getSession();

        if (sessionError) {
          throw new Error(`Não foi possível verificar a sessão: ${sessionError.message}`);
        }

        if (!sessionData?.session) {
          throw new Error("A sessão expirou. Entre novamente na área de gestão.");
        }

        const { data: uploadData, error: uploadError } =
          await supabase.storage.from("customer-photos").upload(
            photoPath,
            photoFile,
            {
              upsert: false,
              contentType: photoFile.type
            }
          );

        if (uploadError) {
          console.error("Falha ao carregar fotografia:", {
            message: uploadError.message,
            statusCode: uploadError.statusCode,
            error: uploadError.error,
            name: uploadError.name,
            path: photoPath
          });

          throw new Error(
            `A cliente foi criada, mas a fotografia não foi carregada: ${uploadError.message}. Verifique a política INSERT do bucket customer-photos no Supabase.`
          );
        }

        const { data: publicPhoto } = supabase.storage
          .from("customer-photos")
          .getPublicUrl(uploadData?.path || photoPath);

        const { error: photoSaveError } = await supabase
          .from("customers")
          .update({ photo_url: publicPhoto.publicUrl })
          .eq("id", data.id);

        if (photoSaveError) {
          throw new Error(
            `A cliente foi criada e a fotografia carregada, mas não foi possível guardar o endereço da fotografia: ${photoSaveError.message}`
          );
        }
      }

      const cardUrl = `${location.origin}${location.pathname}?card=${encodeURIComponent(token)}`;

      $("customerForm").reset();

      await loadCustomers();
      await loadStats();

      msg("customerMessage", `Cliente ${data.full_name} criada com sucesso.`, "success");

      window.prompt(
        "Guarda o endereço do cartão QR da cliente:",
        cardUrl
      );

    } catch (err) {
      console.error("Erro ao criar cliente:", err);
      msg("customerMessage", errorText(err), "error");
    }
  }

  async function registerPaidService(event) {
    event.preventDefault();
    msg("serviceMessage", "");

    const customerId = $("serviceCustomer").value;
    const serviceName = $("serviceName").value.trim();
    const amountText = $("serviceAmount").value.trim();

    if (!customerId) {
      msg("serviceMessage", "Escolha uma cliente.", "error");
      return;
    }

    if (!serviceName) {
      msg("serviceMessage", "Indique o serviço realizado.", "error");
      return;
    }

    const amount = amountText === "" ? null : Number(amountText);

    if (amount !== null && (!Number.isFinite(amount) || amount < 0)) {
      msg("serviceMessage", "Introduza um valor válido.", "error");
      return;
    }

    try {
      const { error } = await supabase.rpc("register_paid_service", {
        p_customer_id: customerId,
        p_service_name: serviceName,
        p_amount: amount
      });

      if (error) throw error;

      $("serviceName").value = "Maquiagem";
      $("serviceAmount").value = "0";

      msg("serviceMessage", "Serviço pago registado com sucesso.", "success");

      await loadCustomers();
      await loadStats();

    } catch (err) {
      msg("serviceMessage", `Não foi possível registar o serviço: ${errorText(err)}`, "error");
    }
  }
  function setupEvents() {
    $("loginForm")?.addEventListener("submit", async event => {
      event.preventDefault();
      msg("loginMessage", "");

      try {
        const email = $("email").value.trim();
        const password = $("password").value;

        const { data, error } = await supabase.auth.signInWithPassword({
          email,
          password
        });

        if (error) throw error;

        await showDashboard(data.user);
      } catch (err) {
        msg("loginMessage", `Não foi possível entrar: ${errorText(err)}`, "error");
      }
    });

    $("logoutBtn")?.addEventListener("click", async () => {
  const button = $("logoutButton");

  try {
    if (button) button.disabled = true;

    const { error } = await supabase.auth.signOut();

    if (error) throw error;

    window.location.replace(location.pathname);
  } catch (err) {
    console.error("Erro ao terminar sessão:", err);

    alert(
      "Não foi possível terminar a sessão. Verifica a ligação à Internet e tenta novamente."
    );

    if (button) button.disabled = false;
  }
});
    $("customerForm")?.addEventListener("submit", createCustomer);
    $("serviceForm")?.addEventListener("submit", registerPaidService);

    $("customersTable")?.addEventListener("click", async event => {
      const button = event.target.closest("button");
      if (!button) return;

  if (button.dataset.delete) {
  await deleteCustomer(button.dataset.delete);
  return;
}

      if (button.dataset.reissue) {
        await reissueCustomerQr(button.dataset.reissue);
        return;
      }

      if (button.dataset.redeem) {
        await redeemReward(button.dataset.redeem, button.dataset.reward);
        return;
      }

      if (button.dataset.customer) {
        $("serviceCustomer").value = button.dataset.customer;
        $("serviceCustomer").focus();
      }
    });

    $("refreshButton")?.addEventListener("click", async () => {
      await loadCustomers();
      await loadStats();
    });

    $("installButton")?.addEventListener("click", async () => {
      if (!installPrompt) return;

      installPrompt.prompt();
      await installPrompt.userChoice;
      installPrompt = null;
      show("installButton", false);
    });

    window.addEventListener("beforeinstallprompt", event => {
      event.preventDefault();
      installPrompt = event;
      show("installButton", true);
    });
  }

  document.addEventListener("DOMContentLoaded", async () => {
    setupEvents();

    if (configured && window.supabase) {
      supabase = window.supabase.createClient(
        cfg.SUPABASE_URL,
        cfg.SUPABASE_ANON_KEY
      );

      supabase.auth.onAuthStateChange(async (event, session) => {
        if (event === "SIGNED_OUT") {
          show("dashboard", false);
          show("loginPanel", true);
        }
      });
    }

    try {
      await init();
    } catch (err) {
      console.error(err);

      if ($("loginMessage")) {
        msg("loginMessage", errorText(err), "error");
      }
    }
  });
})();