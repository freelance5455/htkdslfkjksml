(() => {
'use strict';
const $=id=>document.getElementById(id);
const canvas=$('postCanvas'),ctx=canvas.getContext('2d');
const dims={square:[1080,1080],portrait:[1080,1350],story:[1080,1920],landscape:[1200,630]};
const makeLayer=(text,y,size=82)=>({text,x:540,y,font:'Arial',size,color:'#ffffff',outline:'#111827',bold:true,italic:false,outlineOn:true,shadowOn:true,align:'center',lineSpacing:1.15});
const S={format:'square',bg1:'#111827',bg2:'#4338ca',gradient:true,transparent:false,layers:[makeLayer('Your amazing idea\\nstarts here',540)],selected:0,history:[],drag:false,offset:{x:0,y:0}};
const current=()=>S.layers[S.selected];
function status(t){$('saveStatus').textContent=t}
function remember(){S.history.push(JSON.stringify(S.layers));if(S.history.length>35)S.history.shift()}
function drawBg(){if(S.transparent)return; if(S.gradient){let g=ctx.createLinearGradient(0,0,canvas.width,canvas.height);g.addColorStop(0,S.bg1);g.addColorStop(1,S.bg2);ctx.fillStyle=g}else ctx.fillStyle=S.bg1;ctx.fillRect(0,0,canvas.width,canvas.height);let glow=ctx.createRadialGradient(canvas.width*.8,canvas.height*.1,0,canvas.width*.8,canvas.height*.1,canvas.width*.65);glow.addColorStop(0,'#ffffff10');glow.addColorStop(1,'#ffffff00');ctx.fillStyle=glow;ctx.fillRect(0,0,canvas.width,canvas.height)}
function fontFor(l){return `${l.italic?'italic ':''}${l.bold?'700':'400'} ${l.size}px "${l.font}"`}
function linesFor(l){ctx.font=fontFor(l);let result=[];String(l.text||' ').split('\n').forEach(p=>{if(!p){result.push('');return}let line='';p.split(/\s+/).forEach(word=>{let test=line?line+' '+word:word;if(line&&ctx.measureText(test).width>canvas.width*.84){result.push(line);line=word}else line=test});result.push(line)});return result}
function drawLayer(l,i){let lines=linesFor(l),lh=l.size*l.lineSpacing,total=lh*lines.length,start=l.y-total/2+lh/2;ctx.save();ctx.font=fontFor(l);ctx.textAlign=l.align;ctx.textBaseline='middle';ctx.lineJoin='round';ctx.lineWidth=Math.max(3,l.size*.075);ctx.shadowColor=l.shadowOn?'#000b':'transparent';ctx.shadowBlur=l.shadowOn?l.size*.18:0;ctx.shadowOffsetX=l.shadowOn?3:0;ctx.shadowOffsetY=l.shadowOn?5:0;lines.forEach((line,n)=>{let y=start+n*lh;if(l.outlineOn){ctx.strokeStyle=l.outline;ctx.strokeText(line,l.x,y,canvas.width*.88)}ctx.fillStyle=l.color;ctx.fillText(line,l.x,y,canvas.width*.88)});if(i===S.selected){ctx.shadowColor='transparent';ctx.shadowBlur=0;ctx.setLineDash([12,9]);ctx.strokeStyle='#a78bfa';ctx.lineWidth=3;ctx.strokeRect(22,Math.max(22,start-lh*.65),canvas.width-44,Math.min(canvas.height-44,total+lh*.3))}ctx.restore()}
function renderLayers(){let root=$('layers');root.innerHTML='';S.layers.forEach((l,i)=>{let b=document.createElement('button');b.className='layer'+(i===S.selected?' active':'');b.textContent=(l.text||'Empty text').replace(/\n/g,' / ').slice(0,24);b.onclick=()=>{S.selected=i;render()};root.appendChild(b)})}
function sync(){let l=current();if(!l)return;$('layerText').value=l.text;$('font').value=l.font;$('fontSize').value=l.size;$('fontOut').value=l.size;$('textColour').value=l.color;$('outlineColour').value=l.outline;$('bold').classList.toggle('active',l.bold);$('italic').classList.toggle('active',l.italic);$('stroke').classList.toggle('active',l.outlineOn);$('shadow').classList.toggle('active',l.shadowOn);document.querySelectorAll('[data-align]').forEach(b=>b.classList.toggle('active',b.dataset.align===l.align));$('xPos').value=Math.round(l.x/canvas.width*100);$('xOut').value=$('xPos').value+'%';$('yPos').value=Math.round(l.y/canvas.height*100);$('yOut').value=$('yPos').value+'%';$('lineSpace').value=l.lineSpacing;$('spaceOut').value=Number(l.lineSpacing).toFixed(2)+'×'}
function render(){ctx.clearRect(0,0,canvas.width,canvas.height);drawBg();S.layers.forEach(drawLayer);renderLayers();sync()}
function resize(){let [w,h]=dims[S.format];canvas.width=w;canvas.height=h;$('dimensionBadge').textContent=`${w} × ${h}`;S.layers.forEach(l=>{l.x=Math.min(w-25,Math.max(25,l.x));l.y=Math.min(h-25,Math.max(25,l.y))});render()}
function update(key,val){remember();current()[key]=val;render()}
$('format').onchange=e=>{S.format=e.target.value;resize()};
$('bg1').oninput=e=>{S.bg1=e.target.value;render()};$('bg2').oninput=e=>{S.bg2=e.target.value;render()};
$('gradient').onchange=e=>{S.gradient=e.target.checked;render()};$('transparent').onchange=e=>{S.transparent=e.target.checked;render()};
document.querySelectorAll('.swatches button').forEach(b=>b.onclick=()=>{S.bg1=b.dataset.a;S.bg2=b.dataset.b;$('bg1').value=S.bg1;$('bg2').value=S.bg2;S.gradient=true;$('gradient').checked=true;render()});
$('layerText').oninput=e=>{current().text=e.target.value;renderLayers();ctx.clearRect(0,0,canvas.width,canvas.height);drawBg();S.layers.forEach(drawLayer)};
$('layerText').onchange=remember;$('font').onchange=e=>update('font',e.target.value);
$('fontSize').oninput=e=>{current().size=+e.target.value;$('fontOut').value=e.target.value;render()};$('fontSize').onchange=remember;
$('textColour').oninput=e=>{current().color=e.target.value;render()};$('outlineColour').oninput=e=>{current().outline=e.target.value;render()};
$('bold').onclick=()=>update('bold',!current().bold);$('italic').onclick=()=>update('italic',!current().italic);$('stroke').onclick=()=>update('outlineOn',!current().outlineOn);$('shadow').onclick=()=>update('shadowOn',!current().shadowOn);
document.querySelectorAll('[data-align]').forEach(b=>b.onclick=()=>update('align',b.dataset.align));
$('xPos').oninput=e=>{current().x=canvas.width*(+e.target.value/100);$('xOut').value=e.target.value+'%';render()};$('xPos').onchange=remember;
$('yPos').oninput=e=>{current().y=canvas.height*(+e.target.value/100);$('yOut').value=e.target.value+'%';render()};$('yPos').onchange=remember;
$('lineSpace').oninput=e=>{current().lineSpacing=+e.target.value;$('spaceOut').value=(+e.target.value).toFixed(2)+'×';render()};$('lineSpace').onchange=remember;
$('addText').onclick=()=>{remember();S.layers.push(makeLayer('New text',canvas.height/2,64));S.selected=S.layers.length-1;render();$('layerText').focus();$('layerText').select()};
$('deleteLayer').onclick=()=>{if(S.layers.length===1){current().text='';render();return}remember();S.layers.splice(S.selected,1);S.selected=Math.max(0,S.selected-1);render()};
$('undo').onclick=()=>{if(S.history.length){S.layers=JSON.parse(S.history.pop());S.selected=Math.min(S.selected,S.layers.length-1);render();status('Last layer change undone.')}else status('Nothing to undo yet.')};
function saveImage(){render();canvas.toBlob(async blob=>{if(!blob){status('Export failed. Try again.');return}const fileName=`text-design-${S.format}.png`;try{
  // Native Android bridge can be added by a Capacitor/Android wrapper.
  if(window.AndroidBridge&&typeof window.AndroidBridge.savePngBase64==='function'){const data=await blobToDataURL(blob);window.AndroidBridge.savePngBase64(data.split(',')[1],fileName);status('Sent image to Android save bridge.');return}
  // Web Share with files is useful on Android Chrome and many WebViews.
  const file=new File([blob],fileName,{type:'image/png'});
  if(navigator.canShare&&navigator.canShare({files:[file]})&&navigator.share){await navigator.share({files:[file],title:'Text Design Studio PNG',text:'Your designed post'});status('Image shared. Choose Save to device or Photos in the share sheet.');return}
  const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=fileName;a.style.display='none';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),3000);status('PNG download started. Check Downloads; if no prompt appears, use a browser with download support.');
}catch(err){if(err&&err.name==='AbortError'){status('Save/share cancelled. Try Save PNG again.');return}try{const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=fileName;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),3000);status('Download fallback started. Check Downloads.')}catch(e){status('Could not save automatically. Try opening this page in Chrome and tap Save PNG.')}}},'image/png')}
function blobToDataURL(blob){return new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(r.result);r.onerror=reject;r.readAsDataURL(blob)})}
$('savePng').onclick=saveImage;$('exportPng').onclick=saveImage;$('quickSave').onclick=saveImage;

// Code editor: editable separate HTML, CSS and JS tabs, with a sandboxed live preview.
const sample={html:'<!doctype html>\\n<html>\\n<head>\\n  <meta charset="utf-8">\\n  <meta name="viewport" content="width=device-width, initial-scale=1">\\n  <title>My Design</title>\\n</head>\\n<body>\\n  <main class="card">\\n    <p class="eyebrow">MY FACEBOOK POST</p>\\n    <h1>Hello, world!</h1>\\n    <p>Edit the HTML, CSS and JavaScript tabs, then press Run code.</p>\\n    <button id="demoButton">Tap me</button>\\n  </main>\\n</body>\\n</html>',css:'* { box-sizing: border-box; }\\nbody { margin: 0; min-height: 100vh; display: grid; place-items: center; font-family: system-ui, sans-serif; color: white; background: linear-gradient(135deg, #111827, #4338ca); }\\n.card { width: min(90%, 560px); padding: 36px; border: 1px solid #ffffff55; border-radius: 24px; text-align: center; box-shadow: 0 20px 60px #0005; }\\n.eyebrow { letter-spacing: .18em; font-size: 12px; color: #c4b5fd; }\\nh1 { font-size: clamp(36px, 8vw, 64px); margin: 16px 0; }\\nbutton { padding: 12px 20px; border: 0; border-radius: 999px; background: #fbbf24; color: #111827; font-weight: 800; }',js:'document.getElementById("demoButton")?.addEventListener("click", () => {\\n  document.querySelector("h1").textContent = "Looking good! ✨";\\n});'};
let codeType='html',code={...sample};const editor=$('codeEditor');
function loadEditor(){editor.value=code[codeType];document.querySelectorAll('[data-code]').forEach(b=>b.classList.toggle('active',b.dataset.code===codeType))}
document.querySelectorAll('[data-code]').forEach(b=>b.onclick=()=>{code[codeType]=editor.value;codeType=b.dataset.code;loadEditor()});
function runCode(){code[codeType]=editor.value;const src=code.html.replace(/<\/head>/i,`<style>${code.css.replace(/<\/style/gi,'<\\/style')}</style></head>`).replace(/<\/body>/i,`<script>${code.js.replace(/<\/script/gi,'<\\/script')}<\\/script></body>`);$('livePreview').srcdoc=src;status('Live preview updated.');}
$('runCode').onclick=runCode;$('refreshPreview').onclick=runCode;
$('resetCode').onclick=()=>{if(confirm('Restore the sample HTML, CSS and JavaScript?')){code={...sample};loadEditor();runCode()}};
document.querySelectorAll('.tab').forEach(b=>b.onclick=()=>{document.querySelectorAll('.tab').forEach(x=>x.classList.toggle('active',x===b));document.querySelectorAll('.panel').forEach(p=>p.classList.remove('active'));$(b.dataset.panel+'Panel').classList.add('active');if(b.dataset.panel==='preview')runCode()});
editor.addEventListener('input',()=>{code[codeType]=editor.value});
canvas.addEventListener('pointerdown',e=>{let r=canvas.getBoundingClientRect(),p={x:(e.clientX-r.left)*canvas.width/r.width,y:(e.clientY-r.top)*canvas.height/r.height};if(!S.layers.length)return;let best=0,dist=Infinity;S.layers.forEach((l,i)=>{let d=Math.hypot(p.x-l.x,(p.y-l.y)*canvas.width/canvas.height);if(d<dist){dist=d;best=i}});S.selected=best;let l=current();S.drag=true;S.offset={x:p.x-l.x,y:p.y-l.y};canvas.setPointerCapture(e.pointerId);render()});
canvas.addEventListener('pointermove',e=>{if(!S.drag)return;let r=canvas.getBoundingClientRect(),p={x:(e.clientX-r.left)*canvas.width/r.width,y:(e.clientY-r.top)*canvas.height/r.height},l=current();l.x=Math.max(20,Math.min(canvas.width-20,p.x-S.offset.x));l.y=Math.max(20,Math.min(canvas.height-20,p.y-S.offset.y));render()});
canvas.addEventListener('pointerup',()=>{if(S.drag){S.drag=false;remember();status('Text position updated.')}});canvas.addEventListener('pointercancel',()=>S.drag=false);
remember();resize();loadEditor();runCode();
})();