
// Simple entry gate. This is a convenience screen, not secure authentication.
// For genuine private access, use Firebase Authentication and server-side rules.
const ENTRY_PASSWORD = "Jay jagannath";
const entryGate = document.querySelector("#entryGate");
const appShell = document.querySelector("#appShell");
const entryForm = document.querySelector("#entryForm");
if (sessionStorage.getItem("jjpc_entry_ok") === "yes") {
  entryGate.hidden = true;
  appShell.hidden = false;
}
entryForm.addEventListener("submit", event => {
  event.preventDefault();
  const entered = document.querySelector("#entryPassword").value;
  if (entered === ENTRY_PASSWORD) {
    sessionStorage.setItem("jjpc_entry_ok", "yes");
    entryGate.hidden = true;
    appShell.hidden = false;
    document.querySelector("#entryPassword").value = "";
  } else {
    document.querySelector("#entryStatus").textContent = "Incorrect password. Please try again.";
  }
});

import { initializeApp } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js";
import { getAuth, onAuthStateChanged, createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js";
import { getFirestore, collection, addDoc, query, orderBy, limit, onSnapshot, serverTimestamp } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js";
import { getStorage, ref, uploadBytes, getDownloadURL } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-storage.js";
import { firebaseConfig } from "./firebase-config.js";

const starterPhotos = [
  ["assets/darshan-1.jpg","Jagannath Darshan"],
  ["assets/darshan-2.jpg","Jay Jagannath Puja"],
  ["assets/jay-jagannath-banner.png","Jay Jagannath"],
  ["assets/committee-poster.png","Jay Jagannath Puja Committee"],
  ["assets/jagannath-art.jpg","Lord Jagannath"]
];
const grid = document.querySelector("#galleryGrid");
function addPhoto(src, caption, remote=false) {
  const card=document.createElement("article"); card.className="photo-card"+(remote?" cloud-photo":"");
  const img=document.createElement("img"); img.src=src; img.alt=caption; img.loading="lazy";
  const cap=document.createElement("div"); cap.className="photo-caption"; cap.textContent=caption;
  card.append(img,cap); card.addEventListener("click",()=>{document.querySelector("#lightboxImage").src=src;document.querySelector("#lightbox").hidden=false;});
  grid.append(card);
}
starterPhotos.forEach(([src,title])=>addPhoto(src,title));
document.querySelector("#closeLightbox").onclick=()=>document.querySelector("#lightbox").hidden=true;
document.querySelector("#lightbox").onclick=e=>{if(e.target.id==="lightbox")e.currentTarget.hidden=true;};
document.querySelectorAll(".tab").forEach(btn=>btn.addEventListener("click",()=>{
  document.querySelectorAll(".tab").forEach(b=>b.classList.toggle("active",b===btn));
  document.querySelectorAll(".view").forEach(v=>v.classList.toggle("active",v.id===btn.dataset.view));
}));

const status=document.querySelector("#authStatus");
const setupWarning=document.querySelector("#setupWarning");
const configReady=firebaseConfig.apiKey && !firebaseConfig.apiKey.startsWith("YOUR_") && firebaseConfig.projectId && !firebaseConfig.projectId.startsWith("YOUR_");
let auth, db, storage, currentUser, stopMessages;
if(!configReady){
  setupWarning.hidden=false;
  status.textContent="Firebase is not configured yet. The sample photo gallery works now; login, cloud uploads and group chat activate after setup.";
} else {
  try {
    const app=initializeApp(firebaseConfig); auth=getAuth(app); db=getFirestore(app); storage=getStorage(app);
    onAuthStateChanged(auth, user=>{
      currentUser=user;
      document.querySelector("#signedInPanel").hidden=!user;
      document.querySelector("#signedInText").textContent=user?`Signed in as ${user.email}`:"";
      document.querySelector("#chatInput").disabled=!user;
      document.querySelector("#sendButton").disabled=!user;
      document.querySelector("#chatNotice").textContent=user?"You are signed in. Messages are shared with authenticated members.":"Please sign in with your member account to read and send group messages.";
      document.querySelector("#uploadLabel").hidden=!user;
      if(stopMessages) stopMessages();
      if(user) startMessages(); else document.querySelector("#chatMessages").innerHTML='<div class="empty">Sign in to view members’ messages.</div>';
    });
    document.querySelector("#galleryStatus").textContent="Cloud gallery connected. Sign in to upload photos.";
    // Load photos already stored in Firebase Storage (their download links are in Firestore).
    onSnapshot(query(collection(db,"gallery"),orderBy("createdAt","desc"),limit(100)), snap=>{
      grid.querySelectorAll(".cloud-photo").forEach(card=>card.remove());
      snap.forEach(photoDoc=>{
        const photo=photoDoc.data();
        if(photo.url) addPhoto(photo.url,photo.caption||"Committee photo",true);
      });
      document.querySelector("#galleryStatus").textContent=`${snap.size} cloud photo(s) loaded.`;
    }, err=>{
      document.querySelector("#galleryStatus").textContent="Cloud gallery read error: "+err.message;
    });
    document.querySelector("#photoUpload").addEventListener("change", async e=>{
      if(!currentUser)return;
      const statusEl=document.querySelector("#galleryStatus");
      for(const file of e.target.files){
        try{
          const safeName=file.name.replace(/[^a-zA-Z0-9._-]/g,"_");
          const storageRef=ref(storage,`gallery/${Date.now()}_${safeName}`);
          await uploadBytes(storageRef,file);
          const url=await getDownloadURL(storageRef);
          await addDoc(collection(db,"gallery"),{url,caption:file.name,uploadedBy:currentUser.email,createdAt:serverTimestamp()});
        }catch(err){statusEl.textContent="Upload failed: "+err.message;}
      }
      statusEl.textContent="Upload complete.";
    });
  } catch(err) { setupWarning.hidden=false; status.textContent="Firebase setup error: "+err.message; }
}
document.querySelector("#authForm").addEventListener("submit",async e=>{
  e.preventDefault(); if(!auth){status.textContent="Set up Firebase first (see README.md).";return;}
  status.textContent="Signing in…";
  try{await signInWithEmailAndPassword(auth,document.querySelector("#email").value.trim(),document.querySelector("#password").value);status.textContent="Signed in successfully.";}
  catch(err){status.textContent=authError(err);}
});
document.querySelector("#registerButton").addEventListener("click",async()=>{
  if(!auth){status.textContent="Set up Firebase first (see README.md).";return;}
  status.textContent="Creating account…";
  try{await createUserWithEmailAndPassword(auth,document.querySelector("#email").value.trim(),document.querySelector("#password").value);status.textContent="Account created. Ask your committee administrator to approve access.";}
  catch(err){status.textContent=authError(err);}
});
document.querySelector("#logoutButton").addEventListener("click",async()=>{if(auth)await signOut(auth);});
document.querySelector("#chatForm").addEventListener("submit",async e=>{
  e.preventDefault();const input=document.querySelector("#chatInput"), message=input.value.trim();
  if(!currentUser||!message||!db)return;
  input.disabled=true;
  try{await addDoc(collection(db,"messages"),{text:message,uid:currentUser.uid,email:currentUser.email,createdAt:serverTimestamp()});input.value="";}
  catch(err){document.querySelector("#chatNotice").textContent="Could not send message: "+err.message;}
  input.disabled=false;input.focus();
});
function startMessages(){
  const box=document.querySelector("#chatMessages");
  const q=query(collection(db,"messages"),orderBy("createdAt","asc"),limit(150));
  stopMessages=onSnapshot(q,snap=>{
    box.innerHTML="";
    if(snap.empty){box.innerHTML='<div class="empty">Be the first to say Jai Jagannath! 🙏</div>';return;}
    snap.forEach(docSnap=>{
      const m=docSnap.data(), item=document.createElement("div");
      item.className="message"+(m.uid===currentUser?.uid?" mine":"");
      const name=document.createElement("strong");name.textContent=m.email||"Committee member";
      const body=document.createElement("div");body.textContent=m.text||"";
      const time=document.createElement("time");time.textContent=m.createdAt?.toDate?m.createdAt.toDate().toLocaleString():"Just now";
      item.append(name,body,time);box.append(item);
    });box.scrollTop=box.scrollHeight;
  },err=>{box.innerHTML="";const msg=document.createElement("p");msg.className="status";msg.textContent="Chat access error: "+err.message;box.append(msg);});
}
function authError(err){return ({"auth/invalid-credential":"Email or password is incorrect.","auth/email-already-in-use":"That email already has an account.","auth/weak-password":"Choose a password with at least 6 characters.","auth/invalid-email":"Please enter a valid email address."})[err.code]||err.message;}
if("serviceWorker" in navigator && location.protocol!=="file:") window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}));