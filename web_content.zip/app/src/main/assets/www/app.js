/**
 * Sinji Shorts - Core Mobile Frontend Controller
 * Complete interactive logic for Home, Search, Notifications, Profile, and Settings
 */

(function () {
  'use strict';

  // State Management
  const state = {
    currentScreen: 'screen-home',
    userCoinBalance: 500,
    selectedGift: { name: 'Rose', coins: 10, emoji: '🌹' },
    activeVideoIdForComments: 'v1',
    isFollowing: {
      aarav: false,
      sneha: true,
      rohit: false
    },
    likes: {
      v1: { count: 248600, liked: false },
      v2: { count: 512100, liked: false },
      v3: { count: 89400, liked: false }
    },
    comments: {
      v1: [
        { name: 'Pooja Patel', time: '15m ago', text: 'The visual colors and beat timing is legendary! 🔥💯', likes: 142, avatar: 'P' },
        { name: 'Kabir Mehta', time: '40m ago', text: 'Watched this 5 times in a loop already! Amazing vibe', likes: 88, avatar: 'K' },
        { name: 'Rohan Joshi', time: '1h ago', text: 'Sinji Shorts feed is crazy smooth! Love the music 🎧', likes: 31, avatar: 'R' }
      ],
      v2: [
        { name: 'Ananya Roy', time: '5m ago', text: 'Mumbai rain aesthetic is so nostalgic! Beautiful dance steps 💃', likes: 210, avatar: 'A' },
        { name: 'Sameer Khan', time: '22m ago', text: 'The camera work is top notch!', likes: 64, avatar: 'S' }
      ],
      v3: [
        { name: 'Devendra K', time: '12m ago', text: 'That split-screen gesture trick blew my mind! 🤯', likes: 195, avatar: 'D' },
        { name: 'Priya Verma', time: '30m ago', text: 'Bookmarked and shared with my brother!', likes: 45, avatar: 'P' }
      ]
    }
  };

  // Toast Utility
  function showToast(message) {
    const toast = document.getElementById('toast-banner');
    const toastMsg = document.getElementById('toast-message');
    if (!toast || !toastMsg) return;
    
    toastMsg.textContent = message;
    toast.classList.remove('hidden');

    if (window._toastTimeout) {
      clearTimeout(window._toastTimeout);
    }
    window._toastTimeout = setTimeout(() => {
      toast.classList.add('hidden');
    }, 2400);
  }

  // Format numbers nicely (e.g. 248.6K)
  function formatCount(num) {
    if (num >= 1000000) {
      return (num / 1000000).toFixed(1) + 'M';
    } else if (num >= 1000) {
      return (num / 1000).toFixed(1) + 'K';
    }
    return num.toString();
  }

  // 1. Navigation Switching (Home, Search, Notifications, Profile, Settings)
  function initNavigation() {
    const navButtons = document.querySelectorAll('.bottom-nav .nav-btn');
    const screens = document.querySelectorAll('.screen-section');

    navButtons.forEach(btn => {
      btn.addEventListener('click', (e) => {
        const targetScreenId = btn.getAttribute('data-screen');

        if (btn.id === 'nav-create') {
          showToast('🎬 Camera & Gallery upload opened in Sinji Studio!');
          return;
        }

        if (!targetScreenId) return;

        // Update active nav button
        navButtons.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');

        // Switch screen section
        screens.forEach(s => s.classList.remove('active'));
        const targetScreen = document.getElementById(targetScreenId);
        if (targetScreen) {
          targetScreen.classList.add('active');
          state.currentScreen = targetScreenId;
          // Scroll screen to top
          const mainContent = document.querySelector('.main-content');
          if (mainContent) mainContent.scrollTop = 0;
        }
      });
    });

    // Top Header Earn Button Shortcut to Profile & Monetization
    const headerEarnBtn = document.getElementById('header-earn-btn');
    if (headerEarnBtn) {
      headerEarnBtn.addEventListener('click', () => {
        document.getElementById('nav-profile')?.click();
        showToast('🪙 Welcome to Creator Monetization Studio!');
      });
    }

    // Feed Tabs (Following / For You)
    const feedTabs = document.querySelectorAll('.feed-tab-btn');
    feedTabs.forEach(tab => {
      tab.addEventListener('click', () => {
        feedTabs.forEach(t => t.classList.remove('active'));
        tab.classList.add('active');
        const feedType = tab.getAttribute('data-feed');
        showToast(`Showing ${feedType === 'following' ? 'Following' : 'For You'} Reels feed`);
      });
    });
  }

  // 2. Reels Interactions (Likes, Follows, Comments, Gifts, Share)
  function initReelsInteractions() {
    // Likes
    const likeButtons = document.querySelectorAll('.like-btn');
    likeButtons.forEach(btn => {
      btn.addEventListener('click', () => {
        const videoId = btn.getAttribute('data-id');
        const countSpan = btn.querySelector('.like-count');
        const videoState = state.likes[videoId];
        
        if (!videoState) return;

        videoState.liked = !videoState.liked;
        if (videoState.liked) {
          videoState.count += 1;
          btn.classList.add('liked');
          showToast('❤️ Liked reel!');
        } else {
          videoState.count = Math.max(0, videoState.count - 1);
          btn.classList.remove('liked');
        }
        if (countSpan) countSpan.textContent = formatCount(videoState.count);
      });
    });

    // Follow Buttons
    const followButtons = document.querySelectorAll('.btn-follow');
    followButtons.forEach(btn => {
      btn.addEventListener('click', () => {
        const userKey = btn.getAttribute('data-user');
        const currentFollowStatus = state.isFollowing[userKey] || false;
        state.isFollowing[userKey] = !currentFollowStatus;

        if (state.isFollowing[userKey]) {
          btn.textContent = 'Following';
          btn.classList.add('following');
          showToast(`Now following @${userKey}!`);
        } else {
          btn.textContent = 'Follow';
          btn.classList.remove('following');
          showToast(`Unfollowed @${userKey}`);
        }
      });
    });

    // Comment Openers
    const commentButtons = document.querySelectorAll('.comment-btn');
    const commentsModal = document.getElementById('comments-modal');
    const closeCommentsBtn = document.getElementById('close-comments-btn');

    commentButtons.forEach(btn => {
      btn.addEventListener('click', () => {
        const videoId = btn.getAttribute('data-id') || 'v1';
        state.activeVideoIdForComments = videoId;
        renderComments(videoId);
        commentsModal?.classList.remove('hidden');
      });
    });

    closeCommentsBtn?.addEventListener('click', () => {
      commentsModal?.classList.add('hidden');
    });

    // New Comment Posting
    const sendCommentBtn = document.getElementById('send-comment-btn');
    const newCommentInput = document.getElementById('new-comment-input');

    function handleNewComment() {
      const text = newCommentInput.value.trim();
      if (!text) {
        showToast('Please type a comment first!');
        return;
      }

      const videoId = state.activeVideoIdForComments;
      if (!state.comments[videoId]) state.comments[videoId] = [];

      state.comments[videoId].unshift({
        name: 'Sinji Creator',
        time: 'Just now',
        text: text,
        likes: 0,
        avatar: 'S'
      });

      newCommentInput.value = '';
      renderComments(videoId);
      showToast('Comment posted! 💬');

      // Update count on reel
      const commentBtn = document.querySelector(`.comment-btn[data-id="${videoId}"] .comment-count`);
      if (commentBtn) {
        const currentCount = state.comments[videoId].length;
        commentBtn.textContent = formatCount(currentCount);
      }
    }

    sendCommentBtn?.addEventListener('click', handleNewComment);
    newCommentInput?.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') handleNewComment();
    });

    // Gifts Openers
    const giftButtons = document.querySelectorAll('.gift-btn');
    const giftsModal = document.getElementById('gifts-modal');
    const closeGiftsBtn = document.getElementById('close-gifts-btn');
    const giftRecipientSpan = document.getElementById('gift-recipient-name');
    const confirmSendGiftBtn = document.getElementById('confirm-send-gift-btn');
    const giftItems = document.querySelectorAll('.gift-item');

    giftButtons.forEach(btn => {
      btn.addEventListener('click', () => {
        const creator = btn.getAttribute('data-creator') || 'Creator';
        if (giftRecipientSpan) giftRecipientSpan.textContent = creator;
        giftsModal?.classList.remove('hidden');
      });
    });

    closeGiftsBtn?.addEventListener('click', () => {
      giftsModal?.classList.add('hidden');
    });

    giftItems.forEach(item => {
      item.addEventListener('click', () => {
        giftItems.forEach(i => i.classList.remove('selected'));
        item.classList.add('selected');
        const coins = parseInt(item.getAttribute('data-coins'), 10);
        const name = item.getAttribute('data-name');
        const emoji = item.querySelector('.gift-emoji')?.textContent || '🎁';
        state.selectedGift = { name, coins, emoji };

        if (confirmSendGiftBtn) {
          confirmSendGiftBtn.textContent = `Send ${name} (${coins} Coins)`;
        }
      });
    });

    confirmSendGiftBtn?.addEventListener('click', () => {
      const needed = state.selectedGift.coins;
      if (state.userCoinBalance < needed) {
        showToast('Insufficient coins! Recharge in wallet.');
        return;
      }

      state.userCoinBalance -= needed;
      const coinBalanceEl = document.getElementById('user-coin-balance');
      if (coinBalanceEl) coinBalanceEl.textContent = state.userCoinBalance;

      giftsModal?.classList.add('hidden');
      showToast(`Sent ${state.selectedGift.emoji} ${state.selectedGift.name} (${needed} Coins)! 🚀`);
    });

    // Share Buttons
    const shareButtons = document.querySelectorAll('.share-btn');
    shareButtons.forEach(btn => {
      btn.addEventListener('click', () => {
        const videoId = btn.getAttribute('data-id') || 'v1';
        const shareUrl = `https://sinjishorts.app/v/${videoId}`;
        const shareData = {
          title: 'Sinji Shorts Video',
          text: 'Watch this trending short on Sinji Shorts! 🔥',
          url: shareUrl
        };

        if (navigator.share) {
          navigator.share(shareData).catch(() => {});
        } else if (navigator.clipboard) {
          navigator.clipboard.writeText(shareUrl).then(() => {
            showToast('Link copied to clipboard! 📋');
          });
        } else {
          showToast(`Link copied: ${shareUrl}`);
        }
      });
    });
  }

  function renderComments(videoId) {
    const list = document.getElementById('comments-list');
    const countTitle = document.getElementById('modal-comments-count');
    if (!list) return;

    const videoComments = state.comments[videoId] || [];
    if (countTitle) countTitle.textContent = `(${videoComments.length})`;

    list.innerHTML = videoComments.map(c => `
      <div class="comment-row">
        <div class="comment-avatar ${c.avatar === 'K' || c.avatar === 'R' ? 'cyan' : ''}">${c.avatar}</div>
        <div class="comment-content">
          <div class="comment-user">${c.name} <span class="comment-time">${c.time}</span></div>
          <p class="comment-msg">${escapeHtml(c.text)}</p>
        </div>
        <button class="comment-like-btn" onclick="this.textContent = '❤️ ' + (${c.likes} + 1)">❤️ ${c.likes}</button>
      </div>
    `).join('');
  }

  function escapeHtml(text) {
    return text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }

  // 3. Search & Explore Filtering
  function initSearch() {
    const searchInput = document.getElementById('search-input');
    const clearBtn = document.getElementById('search-clear-btn');
    const categoryChips = document.querySelectorAll('#category-chips .chip-btn');
    const gridCards = document.querySelectorAll('#explore-grid .grid-card');
    const trendCards = document.querySelectorAll('.trend-tag-card');

    if (searchInput && clearBtn) {
      searchInput.addEventListener('input', () => {
        const query = searchInput.value.trim().toLowerCase();
        if (query) {
          clearBtn.classList.remove('hidden');
        } else {
          clearBtn.classList.add('hidden');
        }

        gridCards.forEach(card => {
          const previewText = card.querySelector('.card-caption-preview')?.textContent.toLowerCase() || '';
          if (!query || previewText.includes(query)) {
            card.style.display = 'flex';
          } else {
            card.style.display = 'none';
          }
        });
      });

      clearBtn.addEventListener('click', () => {
        searchInput.value = '';
        clearBtn.classList.add('hidden');
        gridCards.forEach(card => card.style.display = 'flex');
        searchInput.focus();
      });
    }

    categoryChips.forEach(chip => {
      chip.addEventListener('click', () => {
        categoryChips.forEach(c => c.classList.remove('active'));
        chip.classList.add('active');
        const cat = chip.getAttribute('data-cat');
        showToast(`Filtered reels by ${cat.toUpperCase()}`);
      });
    });

    trendCards.forEach(card => {
      card.addEventListener('click', () => {
        const tag = card.getAttribute('data-tag');
        if (searchInput) {
          searchInput.value = tag;
          clearBtn?.classList.remove('hidden');
          showToast(`Searching ${tag}`);
        }
      });
    });
  }

  // 4. Notifications Filtering & Mark All Read
  function initNotifications() {
    const notifChips = document.querySelectorAll('.notif-filter-chips .chip-btn');
    const notifItems = document.querySelectorAll('.notif-item');
    const markAllReadBtn = document.getElementById('mark-all-read-btn');

    notifChips.forEach(chip => {
      chip.addEventListener('click', () => {
        notifChips.forEach(c => c.classList.remove('active'));
        chip.classList.add('active');
        const filter = chip.getAttribute('data-notif-filter');

        notifItems.forEach(item => {
          const type = item.getAttribute('data-type');
          if (filter === 'all' || type === filter) {
            item.style.display = 'flex';
          } else {
            item.style.display = 'none';
          }
        });
      });
    });

    markAllReadBtn?.addEventListener('click', () => {
      notifItems.forEach(item => item.classList.remove('unread'));
      showToast('All notifications marked as read! ✓');
    });
  }

  // 5. Profile Interactions & Editing
  function initProfile() {
    const openStudioBtn = document.getElementById('open-creator-studio-btn');
    const editProfileBtn = document.getElementById('edit-profile-btn');
    const editProfileModal = document.getElementById('edit-profile-modal');
    const closeEditProfileBtn = document.getElementById('close-edit-profile-btn');
    const saveProfileBtn = document.getElementById('save-profile-btn');
    const withdrawBtn = document.getElementById('withdraw-btn');
    const profileTabs = document.querySelectorAll('.profile-tab-btn');

    openStudioBtn?.addEventListener('click', () => {
      showToast('Monetization Studio: 55% ad rev share active!');
    });

    withdrawBtn?.addEventListener('click', () => {
      showToast('Payout request of ₹48,250 submitted via UPI! 💸');
    });

    editProfileBtn?.addEventListener('click', () => {
      editProfileModal?.classList.remove('hidden');
    });

    closeEditProfileBtn?.addEventListener('click', () => {
      editProfileModal?.classList.add('hidden');
    });

    saveProfileBtn?.addEventListener('click', () => {
      const newName = document.getElementById('edit-name-input')?.value.trim();
      const newBio = document.getElementById('edit-bio-input')?.value.trim();

      if (newName) {
        const nameEl = document.getElementById('user-display-name');
        if (nameEl) nameEl.innerHTML = `${escapeHtml(newName)} <span class="verified-icon">✓</span>`;
      }
      if (newBio) {
        const bioEl = document.getElementById('user-bio');
        if (bioEl) bioEl.textContent = newBio;
      }

      editProfileModal?.classList.add('hidden');
      showToast('Profile updated successfully! ✨');
    });

    profileTabs.forEach(tab => {
      tab.addEventListener('click', () => {
        profileTabs.forEach(t => t.classList.remove('active'));
        tab.classList.add('active');
        const tabKey = tab.getAttribute('data-tab');
        showToast(tabKey === 'my-reels' ? 'Showing your published reels' : 'Showing reels you liked');
      });
    });
  }

  // 6. Settings Interactions
  function initSettings() {
    const toggleDarkMode = document.getElementById('toggle-dark-mode');
    const toggleAutoplay = document.getElementById('toggle-autoplay');
    const toggleHaptics = document.getElementById('toggle-haptics');
    const togglePrivateAcc = document.getElementById('toggle-private-acc');
    const clearCacheItem = document.getElementById('clear-cache-item');
    const payoutMethodItem = document.getElementById('payout-method-item');
    const rewardsTierItem = document.getElementById('rewards-tier-item');
    const blockedUsersItem = document.getElementById('blocked-users-item');

    toggleDarkMode?.addEventListener('change', (e) => {
      if (e.target.checked) {
        document.body.classList.remove('light-theme');
        showToast('Dark Neon Theme enabled');
      } else {
        document.body.classList.add('light-theme');
        showToast('Clean Light Theme enabled');
      }
    });

    toggleAutoplay?.addEventListener('change', (e) => {
      showToast(e.target.checked ? 'Reels autoplay enabled' : 'Autoplay paused');
    });

    toggleHaptics?.addEventListener('change', (e) => {
      showToast(e.target.checked ? 'Haptic feedback on' : 'Haptics off');
    });

    togglePrivateAcc?.addEventListener('change', (e) => {
      showToast(e.target.checked ? 'Account set to Private 🔒' : 'Account is now Public 🌐');
    });

    clearCacheItem?.addEventListener('click', () => {
      showToast('Video cache cleared (24.5 MB freed) 🧹');
    });

    payoutMethodItem?.addEventListener('click', () => {
      showToast('Linked Payout UPI: creator@oksbi');
    });

    rewardsTierItem?.addEventListener('click', () => {
      showToast('Current Level: Silver Tier 2 (Next: Gold)');
    });

    blockedUsersItem?.addEventListener('click', () => {
      showToast('0 Blocked Users');
    });
  }

  // Global Bootstrap
  document.addEventListener('DOMContentLoaded', () => {
    initNavigation();
    initReelsInteractions();
    initSearch();
    initNotifications();
    initProfile();
    initSettings();
  });
})();
