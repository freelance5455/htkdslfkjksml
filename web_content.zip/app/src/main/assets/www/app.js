(()=>{'use strict';
const TILE=256,MIN_Z=3,MAX_Z=18,DB='offline-map-db',STORE='tiles';
const $=id=>document.getElementById(id),canvas=$('map'),ctx=canvas.getContext('2d');
let view={lat:32.4279,lng:53.6880,z:5},A=null,B=null,selectNext='A',cache=new Map(),db=null;
const fa=n=>String(n).replace(/\d/g,d=>'۰۱۲۳۴۵۶۷۸۹'[d]);
const world=z=>TILE*2**z;
function project(lat,lng,z){let s=world(z),v=Math.sin(lat*Math.PI/180);return{x:(lng+180)/360*s,y:(.5-Math.log((1+v)/(1-v))/(4*Math.PI))*s}}
function unproject(x,y,z){let s=world(z),n=Math.PI-2*Math.PI*y/s;return{lat:180/Math.PI*Math.atan(Math.sinh(n)),lng:x/s*360-180}}
function distance(a,b){let r=Math.PI/180,d1=(b.lat-a.lat)*r,d2=(b.lng-a.lng)*r,h=Math.sin(d1/2)**2+Math.cos(a.lat*r)*Math.cos(b.lat*r)*Math.sin(d2/2)**2;return 6371*2*Math.asin(Math.sqrt(h))}
function openDB(){return new Promise((resolve,reject)=>{let req=indexedDB.open(DB,1);req.onupgradeneeded=()=>req.result.createObjectStore(STORE);req.onsuccess=()=>{db=req.result;resolve(db)};req.onerror=()=>reject(req.error)})}
function dbGet(k){return new Promise(resolve=>{try{let r=db.transaction(STORE).objectStore(STORE).get(k);r.onsuccess=()=>resolve(r.result||null);r.onerror=()=>resolve(null)}catch{resolve(null)}})}
function dbPut(k,v){return new Promise((resolve,reject)=>{let t=db.transaction(STORE,'readwrite');t.objectStore(STORE).put(v,k);t.oncomplete=resolve;t.onerror=()=>reject(t.error)})}
function tile(z,x,y){
 const key=`${z}/${x}/${y}`;if(cache.has(key))return cache.get(key);
 const t={state:'loading',img:new Image()};cache.set(key,t);
 (async()=>{
  const blob=await dbGet(key);
  t.img.onload=()=>{t.state='ok';draw()};
  t.img.onerror=()=>{t.state='missing';draw()};
  if(blob){t.img.src=URL.createObjectURL(blob);return}
  const template=$('tileUrl')?.value.trim();
  if(template&&template.includes('{z}')&&template.includes('{x}')&&template.includes('{y}')){
   // نمایش فقط کاشی‌های داخل قاب فعلی؛ دریافت انبوه فقط از سرویس‌دهنده‌ای که اجازه داده باشد.
   t.img.src=tileUrl(template,z,x,y);
  }else{t.state='missing'}
 })();return t;
}
const W=()=>canvas.clientWidth,H=()=>canvas.clientHeight;
function resize(){let d=devicePixelRatio||1;canvas.width=Math.round(W()*d);canvas.height=Math.round(H()*d);ctx.setTransform(d,0,0,d,0,0);draw()}
function screen(p){let c=project(view.lat,view.lng,view.z),q=project(p.lat,p.lng,view.z);return{x:q.x-c.x+W()/2,y:q.y-c.y+H()/2}}
function latlng(x,y){let c=project(view.lat,view.lng,view.z);return unproject(c.x+x-W()/2,c.y+y-H()/2,view.z)}
function draw(){if(!ctx)return;ctx.clearRect(0,0,W(),H());let c=project(view.lat,view.lng,view.z),left=c.x-W()/2,top=c.y-H()/2,n=2**view.z;
for(let y=Math.floor(top/TILE);y<=Math.floor((top+H())/TILE);y++){if(y<0||y>=n)continue;for(let x=Math.floor(left/TILE);x<=Math.floor((left+W())/TILE);x++){let xx=(x%n+n)%n,px=x*TILE-left,py=y*TILE-top,t=tile(view.z,xx,y);if(t.state==='ok')ctx.drawImage(t.img,px,py,TILE,TILE);else{ctx.fillStyle='#e9e6dc';ctx.fillRect(px,py,TILE,TILE);ctx.strokeStyle='#d5d0c5';ctx.strokeRect(px,py,TILE,TILE)}}}
if(A&&B){let a=screen(A),b=screen(B);ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.lineTo(b.x,b.y);ctx.strokeStyle='#1976d2';ctx.lineWidth=4;ctx.stroke()}
if(A)pin(A,'#16834a','A');if(B)pin(B,'#d33b35','B');updateInfo()}
function pin(p,color,label){let s=screen(p);ctx.beginPath();ctx.arc(s.x,s.y,10,0,Math.PI*2);ctx.fillStyle=color;ctx.fill();ctx.lineWidth=3;ctx.strokeStyle='white';ctx.stroke();ctx.fillStyle='white';ctx.font='bold 11px sans-serif';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(label,s.x,s.y)}
function updateInfo(){if(A&&B)$('info').textContent=`فاصله مستقیم: ${fa(distance(A,B).toFixed(2))} کیلومتر — این خط مسیر جاده‌ای نیست.`;else if(A)$('info').textContent='مبدأ ثبت شد؛ مقصد را انتخاب کنید.';else $('info').textContent='برای شروع، نقطه مبدأ را روی نقشه انتخاب کنید.'}
function zoomAt(x,y,dz){let z=Math.max(MIN_Z,Math.min(MAX_Z,view.z+dz));if(z===view.z)return;let p=latlng(x,y);view.z=z;let q=project(p.lat,p.lng,z);let c=unproject(q.x-(x-W()/2),q.y-(y-H()/2),z);view.lat=c.lat;view.lng=c.lng;draw()}
let pointers=new Map(),lastPinch=0,moved=0;
canvas.addEventListener('pointerdown',e=>{canvas.setPointerCapture(e.pointerId);pointers.set(e.pointerId,{x:e.offsetX,y:e.offsetY});moved=0});
canvas.addEventListener('pointermove',e=>{let p=pointers.get(e.pointerId);if(!p)return;let dx=e.offsetX-p.x,dy=e.offsetY-p.y;if(pointers.size===1){moved+=Math.abs(dx)+Math.abs(dy);let c=project(view.lat,view.lng,view.z),ll=unproject(c.x-dx,c.y-dy,view.z);view.lat=Math.max(-85,Math.min(85,ll.lat));view.lng=ll.lng;p.x=e.offsetX;p.y=e.offsetY;draw()}else if(pointers.size===2){p.x=e.offsetX;p.y=e.offsetY;let[a,b]=[...pointers.values()],d=Math.hypot(a.x-b.x,a.y-b.y);if(lastPinch&&Math.abs(d-lastPinch)>35){zoomAt((a.x+b.x)/2,(a.y+b.y)/2,d>lastPinch?1:-1);lastPinch=d}else if(!lastPinch)lastPinch=d}});
canvas.addEventListener('pointerup',e=>{let one=pointers.size===1;pointers.delete(e.pointerId);lastPinch=0;if(one&&moved<7){let ll=latlng(e.offsetX,e.offsetY);if(selectNext==='A'){A=ll;selectNext='B'}else{B=ll;selectNext='A'}draw()}});
canvas.addEventListener('pointercancel',e=>pointers.delete(e.pointerId));canvas.addEventListener('wheel',e=>{e.preventDefault();zoomAt(e.offsetX,e.offsetY,e.deltaY<0?1:-1)},{passive:false});
$('zin').onclick=()=>zoomAt(W()/2,H()/2,1);$('zout').onclick=()=>zoomAt(W()/2,H()/2,-1);
$('reset').onclick=()=>{view={lat:32.4279,lng:53.6880,z:5};draw()};
$('clearRoute').onclick=()=>{A=B=null;selectNext='A';draw()};
$('swap').onclick=()=>{[A,B]=[B,A];draw()};
$('fit').onclick=()=>fitBounds();
function fitBounds(){if(!A&&!B)return;let p=A||B;view={lat:p.lat,lng:p.lng,z:14};if(A&&B){for(let z=MAX_Z;z>=MIN_Z;z--){let a=project(A.lat,A.lng,z),b=project(B.lat,B.lng,z);if(Math.abs(a.x-b.x)<W()*.65&&Math.abs(a.y-b.y)<H()*.65){view={lat:(A.lat+B.lat)/2,lng:(A.lng+B.lng)/2,z};break}}}draw()}
$('locate').onclick=()=>{if(!navigator.geolocation){alert('مرورگر شما GPS را پشتیبانی نمی‌کند.');return}$('status').textContent='در حال دریافت موقعیت…';navigator.geolocation.getCurrentPosition(pos=>{view={lat:pos.coords.latitude,lng:pos.coords.longitude,z:15};A={...view};B=null;selectNext='B';$('status').textContent='موقعیت دریافت شد';draw()},err=>{$('status').textContent='خطا در GPS';alert('موقعیت دریافت نشد. در تنظیمات Android دسترسی مکان برنامه را فعال کنید. GPS به‌تنهایی اینترنت نمی‌خواهد؛ اما WebView/مرورگر ممکن است برای Geolocation به مبدأ امن HTTPS نیاز داشته باشد. اگر برنامه از صفحه ناامن یا file:// اجرا شود، موقعیت می‌تواند مسدود شود. کد خطا: '+err.code)},{enableHighAccuracy:true,timeout:15000})};
$('importBtn').onclick=()=>{
  $('zipInput').click();
};
// واردسازی ZIP استاندارد شامل کاشی‌ها با ساختار z/x/y.png یا z/x/y.jpg
async function unzipTileArchive(file){
 const buf=await file.arrayBuffer(),dv=new DataView(buf);let eocd=-1;
 for(let i=buf.byteLength-22;i>=Math.max(0,buf.byteLength-65557);i--){if(dv.getUint32(i,true)===0x06054b50){eocd=i;break}}
 if(eocd<0)throw new Error('ساختار ZIP معتبر نیست.');
 const count=dv.getUint16(eocd+10,true),central=dv.getUint32(eocd+16,true);let pos=central,done=0,skip=0;
 for(let i=0;i<count;i++){
  if(dv.getUint32(pos,true)!==0x02014b50)throw new Error('فهرست ZIP خراب است.');
  const method=dv.getUint16(pos+10,true),compressed=dv.getUint32(pos+20,true),nameLen=dv.getUint16(pos+28,true),extraLen=dv.getUint16(pos+30,true),commentLen=dv.getUint16(pos+32,true),local=dv.getUint32(pos+42,true);
  const name=new TextDecoder().decode(new Uint8Array(buf,pos+46,nameLen));pos+=46+nameLen+extraLen+commentLen;
  const parts=name.split('/'),idx=parts.findIndex(x=>/^\d{1,2}$/.test(x));
  if(idx<0||parts.length<idx+3||! /\.(png|jpe?g|webp)$/i.test(parts[parts.length-1])){skip++;continue}
  const key=parts.slice(idx,idx+3).join('/').replace(/\.(png|jpe?g|webp)$/i,'');if(!/^\d+\/\d+\/\d+$/.test(key)){skip++;continue}
  if(dv.getUint32(local,true)!==0x04034b50){skip++;continue}
  const ln=dv.getUint16(local+26,true),le=dv.getUint16(local+28,true),start=local+30+ln+le,compressedBytes=buf.slice(start,start+compressed);let blob;
  try{
   let bytes;
   if(method===0)bytes=compressedBytes;
   else if(method===8){if(!('DecompressionStream'in window))throw new Error('مرورگر این گوشی بازکردن ZIP فشرده را پشتیبانی نمی‌کند.');const stream=new Blob([compressedBytes]).stream().pipeThrough(new DecompressionStream('deflate-raw'));bytes=await new Response(stream).arrayBuffer()}
   else {skip++;continue}
   const ext=name.match(/\.(png|jpe?g|webp)$/i)[1].toLowerCase();blob=new Blob([bytes],{type:ext==='jpg'||ext==='jpeg'?'image/jpeg':`image/${ext}`});
   await dbPut(key,blob);cache.delete(key);done++;
  }catch(err){if(err.message&&err.message.includes('پشتیبانی'))throw err;skip++}
 }
 return {done,skip};
}
$('zipInput').addEventListener('change',async e=>{
 const file=e.target.files&&e.target.files[0];if(!file)return;
 if(/\.mbtiles$/i.test(file.name)){alert('این فایل MBTiles شناسایی شد، اما نسخه فعلی هنوز امکان خواندن پایگاه‌داده MBTiles را ندارد. لطفاً ZIP کاشی‌های z/x/y.png انتخاب کنید.');e.target.value='';return;}
 if(!/\.zip$/i.test(file.name)){alert('لطفاً فایل ZIP نقشه را انتخاب کنید.');e.target.value='';return;}
 $('status').textContent='در حال بازکردن فایل ZIP…';$('tileStatus').textContent='لطفاً تا پایان واردسازی صبر کنید.';
 try{const r=await unzipTileArchive(file);$('status').textContent='واردسازی ZIP تمام شد';$('tileStatus').textContent=`${fa(r.done)} کاشی وارد شد؛ ${fa(r.skip)} فایل نادیده گرفته شد.`;cache.clear();draw();}
 catch(err){alert(err.message||'بازکردن فایل ZIP ناموفق بود.');$('status').textContent='خطا در واردسازی';}
 e.target.value='';
});

// دانلود منطقه‌ای از سرویس کاشی مجازِ انتخاب‌شده توسط کاربر
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const tileXY=(lat,lng,z)=>{const n=2**z,latR=Math.max(-85.05112878,Math.min(85.05112878,lat))*Math.PI/180;return{x:Math.floor((lng+180)/360*n),y:Math.floor((1-Math.asinh(Math.tan(latR))/Math.PI)/2*n)}};
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
function tileUrl(template,z,x,y){return template.split('{z}').join(String(z)).split('{x}').join(String(x)).split('{y}').join(String(y))}
function regionTiles(lat,lng,radius,zmin,zmax){
 const out=[];
 for(let z=zmin;z<=zmax;z++){
  const dLat=radius/111.32, dLng=radius/(111.32*Math.max(.15,Math.cos(lat*Math.PI/180)));
  const nw=tileXY(clamp(lat+dLat,-85,85),clamp(lng-dLng,-180,180),z);
  const se=tileXY(clamp(lat-dLat,-85,85),clamp(lng+dLng,-180,180),z);
  const n=2**z;
  for(let y=Math.max(0,nw.y);y<=Math.min(n-1,se.y);y++)
   for(let x=nw.x;x<=se.x;x++)out.push({z,x:(x%n+n)%n,y});
 }
 return out;
}
let downloadController=null;
$('tileUrl').addEventListener('change',()=>{cache.clear();draw();$('downloadStatus').textContent='منبع نقشه به‌روزرسانی شد؛ اگر نشانی معتبر باشد کاشی‌های محدوده فعلی نمایش داده می‌شوند.'});
$('downloadBtn').onclick=async()=>{
 if(downloadController){downloadController.abort();downloadController=null;$('downloadStatus').textContent='درخواست توقف دانلود ثبت شد.';return}
 const template=$('tileUrl').value.trim(),radius=Number($('radius').value),zmin=Number($('minZoom').value),zmax=Number($('maxZoom').value);
 if(!template.includes('{z}')||!template.includes('{x}')||!template.includes('{y}')){alert('نشانی سرویس باید شامل {z} و {x} و {y} باشد.');return}
 if(!(radius>0&&radius<=100)||!(zmin>=3&&zmax<=18&&zmin<=zmax)){alert('محدوده یا بزرگنمایی معتبر نیست. شعاع حداکثر ۱۰۰ کیلومتر است.');return}
 const tiles=regionTiles(view.lat,view.lng,radius,zmin,zmax);
 if(tiles.length>2500){alert(`این محدوده ${fa(tiles.length)} کاشی دارد و از سقف ۲۵۰۰ کاشی بیشتر است. شعاع یا بزرگنمایی را کم کنید.`);return}
 if(!confirm(`دانلود ${fa(tiles.length)} کاشی در شعاع ${fa(radius)} کیلومتر انجام شود؟ هزینه اینترنت و شرایط سرویس‌دهنده را بررسی کنید.`))return;
 downloadController=new AbortController();const signal=downloadController.signal;
 $('downloadBtn').textContent='توقف دانلود';let done=0,failed=0;
 try{
  for(const t of tiles){
   if(signal.aborted)break;
   const key=`${t.z}/${t.x}/${t.y}`;
   try{
    const response=await fetch(tileUrl(template,t.z,t.x,t.y),{mode:'cors',credentials:'omit',signal});
    if(!response.ok)throw new Error('HTTP '+response.status);
    const blob=await response.blob();
    if(!blob.size)throw new Error('پاسخ خالی است');
    const head=new Uint8Array(await blob.slice(0,12).arrayBuffer());
    const isPng=head.length>=8&&head[0]===137&&head[1]===80&&head[2]===78&&head[3]===71;
    const isJpeg=head.length>=3&&head[0]===255&&head[1]===216&&head[2]===255;
    const isWebp=head.length>=12&&String.fromCharCode(...head.slice(0,4))==='RIFF'&&String.fromCharCode(...head.slice(8,12))==='WEBP';
    if(!(isPng||isJpeg||isWebp))throw new Error('پاسخ سرویس تصویر نقشه نیست');
    const safeBlob=blob.type?blob:new Blob([blob],{type:isPng?'image/png':isJpeg?'image/jpeg':'image/webp'});
    await dbPut(key,safeBlob);cache.delete(key);done++;
   }catch(err){if(signal.aborted)break;failed++;if(!window.__yaTileError)window.__yaTileError=err?.message||'خطای شبکه/CORS'}
   $('downloadStatus').textContent=`دریافت: ${fa(done+failed)} از ${fa(tiles.length)} | موفق: ${fa(done)} | ناموفق: ${fa(failed)}`;
   await sleep(1000); // رعایت فاصله درخواست؛ محدودیت سرویس‌دهنده مقدم است
  }
 }finally{
  downloadController=null;$('downloadBtn').textContent='دانلود محدوده فعلی';
  $('downloadStatus').textContent=signal.aborted?'دانلود متوقف شد. ': 'دانلود تمام شد. ';
  $('downloadStatus').textContent+=`موفق: ${fa(done)}، ناموفق: ${fa(failed)}.`+(failed?' خطای نمونه: '+(window.__yaTileError||'شبکه/CORS')+'. نشانی سرویس، مجوز CORS و اجازه دانلود آفلاین سرویس‌دهنده را بررسی کنید.':'');window.__yaTileError=null;
  cache.clear();draw();
 }
};

$('storageBtn').onclick=async()=>{let count=0;try{count=await new Promise((resolve,reject)=>{let r=db.transaction(STORE).objectStore(STORE).count();r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)})}catch{}let estimate=navigator.storage?.estimate?await navigator.storage.estimate():null;let used=estimate?`${(estimate.usage/1048576).toFixed(1)} MB`:'نامشخص';alert(`تعداد کاشی‌های ذخیره‌شده: ${fa(count)}\\nحافظه استفاده‌شده در مرورگر: ${fa(used)}`)};
window.addEventListener('resize',resize);
openDB().then(()=>{$('tileStatus').textContent='آماده؛ برای نمایش آنلاین، نشانی منبع کاشی را در بخش دانلود وارد کنید. نقشه‌های واردشده/دانلودشده در حافظه همین برنامه ذخیره می‌شوند.';resize()}).catch(()=>{$('tileStatus').textContent='ذخیره‌سازی مرورگر در دسترس نیست.';resize()});
if('serviceWorker'in navigator&&location.protocol.startsWith('http'))navigator.serviceWorker.register('sw.js').catch(()=>{});
})();