Optional tile layout: tiles/{z}/{x}/{y}.png
