(function () {
  var BUILTIN = [
    { n: 'YouTube',   i: '▶️', u: 'https://m.youtube.com' },
    { n: 'Google',    i: '🔎', u: 'https://www.google.com' },
    { n: 'Instagram', i: '📸', u: 'https://www.instagram.com' },
    { n: 'Facebook',  i: '👍', u: 'https://m.facebook.com' },
    { n: 'X',         i: '🐦', u: 'https://x.com' },
    { n: 'WhatsApp',  i: '💬', u: 'https://web.whatsapp.com' },
    { n: 'Telegram',  i: '✈️', u: 'https://web.telegram.org' },
    { n: 'Gmail',     i: '✉️', u: 'https://mail.google.com' },
    { n: 'Maps',      i: '🗺️', u: 'https://maps.google.com' },
    { n: 'Spotify',   i: '🎵', u: 'https://open.spotify.com' },
    { n: 'Hotstar',   i: '📺', u: 'https://www.hotstar.com' },
    { n: 'Amazon',    i: '🛒', u: 'https://www.amazon.in' },
    { n: 'Flipkart',  i: '🛍️', u: 'https://www.flipkart.com' },
    { n: 'Reddit',    i: '👽', u: 'https://www.reddit.com' },
    { n: 'Wikipedia', i: '📚', u: 'https://en.m.wikipedia.org' }
  ];

  function loadCustom() {
    try { return JSON.parse(localStorage.getItem('airtouch.shortcuts') || '[]'); } catch (e) { return []; }
  }
  function saveCustom(list) {
    try { localStorage.setItem('airtouch.shortcuts', JSON.stringify(list)); } catch (e) {}
  }
  function normalize(t) {
    t = (t || '').trim();
    if (!t) return '';
    if (/^https?:\/\//i.test(t)) return t;
    if (t.indexOf(' ') < 0 && t.indexOf('.') > 0) return 'https://' + t;
    return 'https://www.google.com/search?q=' + encodeURIComponent(t);
  }

  var grid = document.getElementById('grid');
  function render() {
    grid.innerHTML = '';
    BUILTIN.forEach(function (s) { grid.appendChild(tile(s, -1)); });
    loadCustom().forEach(function (s, idx) { grid.appendChild(tile(s, idx)); });
  }
  function tile(s, customIdx) {
    var a = document.createElement('a');
    a.className = 'tile';
    a.href = s.u;
    var ico = document.createElement('span'); ico.className = 'ico'; ico.textContent = s.i || '🌐';
    var name = document.createElement('span'); name.textContent = s.n;
    a.appendChild(ico); a.appendChild(name);
    if (customIdx >= 0) {
      var d = document.createElement('span'); d.className = 'del'; d.textContent = '✕';
      d.addEventListener('click', function (e) {
        e.preventDefault(); e.stopPropagation();
        var l = loadCustom(); l.splice(customIdx, 1); saveCustom(l); render();
      });
      a.appendChild(d);
    }
    return a;
  }

  document.getElementById('searchForm').addEventListener('submit', function (e) {
    e.preventDefault();
    var u = normalize(document.getElementById('q').value);
    if (u) location.href = u;
  });
  document.getElementById('addForm').addEventListener('submit', function (e) {
    e.preventDefault();
    var n = document.getElementById('addName').value.trim();
    var u = normalize(document.getElementById('addUrl').value);
    if (!u) return;
    var l = loadCustom(); l.push({ n: n || u.replace(/^https?:\/\//, '').split('/')[0], i: '⭐', u: u });
    saveCustom(l);
    document.getElementById('addName').value = ''; document.getElementById('addUrl').value = '';
    render();
  });
  render();
})();
