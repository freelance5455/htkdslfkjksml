-- Edna Jongolo — Beauty & Loyalty
-- Base inicial para Supabase (PostgreSQL). Rever e testar num projeto de desenvolvimento antes de produção.
-- Regra: cada 10 serviços pagos elegíveis dão direito a 1 serviço gratuito.

create extension if not exists pgcrypto;

create type public.app_role as enum ('manager', 'staff', 'customer');
create type public.service_record_kind as enum ('paid', 'reward');
create type public.reward_status as enum ('available', 'redeemed', 'cancelled');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  role public.app_role not null default 'customer',
  created_at timestamptz not null default now()
);

create table public.customers (
  id uuid primary key default gen_random_uuid(),
  full_name text not null,
  phone text,
  -- Hash do token aleatório do cartão QR. Nunca guardar o token original nesta tabela.
  qr_token_hash text not null unique,
  created_at timestamptz not null default now(),
  created_by uuid references public.profiles(id)
);

create table public.service_catalog (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table public.service_records (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid not null references public.customers(id),
  service_id uuid references public.service_catalog(id),
  service_name text not null,
  kind public.service_record_kind not null,
  amount numeric(12,2),
  staff_id uuid references public.profiles(id),
  notes text,
  created_at timestamptz not null default now(),
  idempotency_key uuid not null default gen_random_uuid(),
  unique (idempotency_key),
  constraint paid_amount_nonnegative check (amount is null or amount >= 0)
);

create table public.rewards (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid not null references public.customers(id),
  status public.reward_status not null default 'available',
  earned_at timestamptz not null default now(),
  redeemed_at timestamptz,
  redeemed_service_name text,
  issued_by uuid references public.profiles(id),
  redeemed_by uuid references public.profiles(id)
);

create index service_records_customer_created_idx on public.service_records(customer_id, created_at desc);
create index rewards_customer_status_idx on public.rewards(customer_id, status);

insert into public.service_catalog(name) values
 ('Maquiagem'), ('Penteado'), ('Manicure'), ('Pedicure'), ('Tratamento de pele'), ('Outro')
on conflict (name) do nothing;

-- Função para consultar o perfil da sessão autenticada.
create or replace function public.current_app_role()
returns public.app_role
language sql stable security definer
set search_path = public
as $$
  select role from public.profiles where id = auth.uid()
$$;

create or replace function public.is_manager_or_staff()
returns boolean
language sql stable security definer
set search_path = public
as $$
  select coalesce(public.current_app_role() in ('manager', 'staff'), false)
$$;

-- Função privada: chamadas de registo devem ser feitas por funcionário/gerente autenticado.
-- Regista um serviço pago e, a cada 10 serviços pagos desde a última recompensa,
-- emite uma recompensa disponível. Transações garantem que as duas operações ficam juntas.
create or replace function public.register_paid_service(
  p_customer_id uuid,
  p_service_name text,
  p_amount numeric default null,
  p_idempotency_key uuid default gen_random_uuid()
)
returns jsonb
language plpgsql security definer
set search_path = public
as $$
declare
  v_record_id uuid;
  v_total_paid integer;
  v_reward_count integer;
  v_new_reward_id uuid;
begin
  if auth.uid() is null or not public.is_manager_or_staff() then
    raise exception 'Acesso não autorizado';
  end if;
  if p_service_name is null or length(trim(p_service_name)) = 0 then
    raise exception 'Indique o serviço';
  end if;
  if p_amount is not null and p_amount < 0 then
    raise exception 'O valor não pode ser negativo';
  end if;

  -- Impede duplicação por repetição do mesmo pedido.
  select id into v_record_id from public.service_records where idempotency_key = p_idempotency_key;
  if v_record_id is not null then
    return jsonb_build_object('record_id', v_record_id, 'duplicate', true);
  end if;

  perform 1 from public.customers where id = p_customer_id for update;
  if not found then raise exception 'Cliente não encontrado'; end if;

  insert into public.service_records(customer_id, service_name, kind, amount, staff_id, idempotency_key)
  values (p_customer_id, trim(p_service_name), 'paid', p_amount, auth.uid(), p_idempotency_key)
  returning id into v_record_id;

  select count(*)::integer into v_total_paid
  from public.service_records
  where customer_id = p_customer_id and kind = 'paid';

  select count(*)::integer into v_reward_count
  from public.rewards
  where customer_id = p_customer_id and status in ('available', 'redeemed');

  -- Cada bloco completo de 10 serviços pagos corresponde a uma recompensa emitida.
  if floor(v_total_paid / 10.0) > v_reward_count then
    insert into public.rewards(customer_id, issued_by)
    values (p_customer_id, auth.uid()) returning id into v_new_reward_id;
  end if;

  return jsonb_build_object(
    'record_id', v_record_id,
    'paid_services_total', v_total_paid,
    'reward_issued', v_new_reward_id is not null,
    'reward_id', v_new_reward_id,
    'duplicate', false
  );
end;
$$;

-- Resgatar uma recompensa. O servidor valida o estado; o cliente não pode fazê-lo diretamente.
create or replace function public.redeem_reward(
  p_reward_id uuid,
  p_service_name text
)
returns jsonb
language plpgsql security definer
set search_path = public
as $$
declare
  v_customer_id uuid;
begin
  if auth.uid() is null or not public.is_manager_or_staff() then
    raise exception 'Acesso não autorizado';
  end if;
  if p_service_name is null or length(trim(p_service_name)) = 0 then
    raise exception 'Indique o serviço gratuito escolhido';
  end if;

  update public.rewards
  set status = 'redeemed', redeemed_at = now(),
      redeemed_service_name = trim(p_service_name), redeemed_by = auth.uid()
  where id = p_reward_id and status = 'available'
  returning customer_id into v_customer_id;

  if v_customer_id is null then
    raise exception 'Recompensa inexistente, já utilizada ou indisponível';
  end if;

  insert into public.service_records(customer_id, service_name, kind, staff_id)
  values (v_customer_id, trim(p_service_name), 'reward', auth.uid());

  return jsonb_build_object('reward_id', p_reward_id, 'redeemed', true);
end;
$$;

-- Consulta pública via QR: recebe token secreto aleatório, compara o hash e devolve apenas
-- o resumo do cartão. O token deve ser suficientemente aleatório e tratado como credencial.
create or replace function public.customer_card_by_qr(p_token text)
returns jsonb
language plpgsql security definer
set search_path = public
as $$
declare
  v_customer public.customers%rowtype;
  v_paid_total integer;
  v_progress integer;
  v_available_rewards integer;
begin
  if p_token is null or length(p_token) < 32 then
    raise exception 'Cartão inválido';
  end if;
  select * into v_customer
  from public.customers
  where qr_token_hash = encode(digest(p_token, 'sha256'), 'hex');
  if not found then raise exception 'Cartão inválido'; end if;

  select count(*)::integer into v_paid_total
  from public.service_records
  where customer_id = v_customer.id and kind = 'paid';

  select count(*)::integer into v_available_rewards
  from public.rewards where customer_id = v_customer.id and status = 'available';

  v_progress := mod(v_paid_total, 10);
  if v_available_rewards > 0 then v_progress := 10; end if;

  return jsonb_build_object(
    'customer_name', v_customer.full_name,
    'paid_services_progress', v_progress,
    'services_remaining', case when v_available_rewards > 0 then 0 else 10 - v_progress end,
    'available_rewards', v_available_rewards
  );
end;
$$;

-- Row Level Security: as tabelas não ficam abertas ao público.
alter table public.profiles enable row level security;
alter table public.customers enable row level security;
alter table public.service_catalog enable row level security;
alter table public.service_records enable row level security;
alter table public.rewards enable row level security;

create policy "profiles read self or manager" on public.profiles
for select to authenticated
using (id = auth.uid() or public.current_app_role() = 'manager');

create policy "manager manages profiles" on public.profiles
for all to authenticated
using (public.current_app_role() = 'manager')
with check (public.current_app_role() = 'manager');

create policy "staff and manager read customers" on public.customers
for select to authenticated
using (public.is_manager_or_staff());

create policy "manager and staff create customers" on public.customers
for insert to authenticated
with check (public.is_manager_or_staff());

create policy "manager updates customers" on public.customers
for update to authenticated
using (public.current_app_role() = 'manager')
with check (public.current_app_role() = 'manager');

create policy "authenticated read active service catalog" on public.service_catalog
for select to authenticated using (active or public.current_app_role() = 'manager');

create policy "manager manages service catalog" on public.service_catalog
for all to authenticated
using (public.current_app_role() = 'manager')
with check (public.current_app_role() = 'manager');

create policy "staff and manager read service records" on public.service_records
for select to authenticated
using (public.is_manager_or_staff());

create policy "staff and manager read rewards" on public.rewards
for select to authenticated
using (public.is_manager_or_staff());

-- Não permitir inserção/alteração direta do histórico. Usar as funções RPC acima.
revoke insert, update, delete on public.service_records from anon, authenticated;
revoke insert, update, delete on public.rewards from anon, authenticated;
revoke all on function public.register_paid_service(uuid, text, numeric, uuid) from public, anon;
revoke all on function public.redeem_reward(uuid, text) from public, anon;
grant execute on function public.register_paid_service(uuid, text, numeric, uuid) to authenticated;
grant execute on function public.redeem_reward(uuid, text) to authenticated;
revoke all on function public.customer_card_by_qr(text) from public;
grant execute on function public.customer_card_by_qr(text) to anon, authenticated;

-- IMPORTANTE: criar o primeiro perfil de gerente por um processo administrativo seguro.
-- Não atribuir role='manager' através de um formulário público.
