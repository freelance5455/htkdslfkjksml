/**
 * আল-ইনসাফ মানব কল্যাণ ফাউন্ডেশন
 * Firebase Configuration & Service Wrapper
 */

const firebaseConfig = {
  apiKey: "AIzaSyChYecEER368-hj5I3hvaY8sB8L_SCNNlc",
  authDomain: "al-insaf-foundation.firebaseapp.com",
  projectId: "al-insaf-foundation",
  storageBucket: "al-insaf-foundation.firebasestorage.app",
  messagingSenderId: "1053198861401",
  appId: "1:1053198861401:web:3b31d46022caa131659d48"
};

let firebaseApp = null;
let firebaseAuth = null;
let firebaseFirestore = null;

// Firebase initialization
if (typeof firebase !== 'undefined') {
  try {
    if (!firebase.apps || firebase.apps.length === 0) {
      firebaseApp = firebase.initializeApp(firebaseConfig);
    } else {
      firebaseApp = firebase.app();
    }
    firebaseAuth = firebase.auth();
    firebaseFirestore = firebase.firestore();

    // Enable offline persistence so data is cached locally and synced to Cloud Firestore automatically
    firebaseFirestore.enablePersistence({ synchronizeTabs: true }).catch(err => {
      if (err.code === 'failed-precondition') {
        console.warn("Firestore persistence: Multiple tabs open, active in first tab.");
      } else if (err.code === 'unimplemented') {
        console.warn("Firestore persistence not supported in this browser environment.");
      } else {
        console.warn("Firestore persistence note:", err.message);
      }
    });

    console.log("Firebase initialized successfully. Project:", firebaseConfig.projectId);
  } catch (err) {
    console.error("Firebase initialization error:", err);
  }
} else {
  console.warn("Firebase SDK not loaded yet.");
}

// Check Firebase connection status
async function checkFirebaseConnection() {
  const status = {
    initialized: !!firebaseApp,
    authAvailable: !!firebaseAuth,
    firestoreAvailable: !!firebaseFirestore,
    storageUsed: false,
    projectId: firebaseConfig.projectId,
    error: null
  };

  if (!firebaseFirestore) {
    status.error = "Cloud Firestore is not initialized";
    return status;
  }

  try {
    await firebaseFirestore.collection('settings').doc('general').get();
    status.connected = true;
    console.log("Firebase connection test successful! Project:", firebaseConfig.projectId);
  } catch (err) {
    status.error = err.message;
    console.warn("Firebase connection test notice:", err.message);
  }
  return status;
}

window.AlInsafFirebase = {
  app: firebaseApp,
  auth: firebaseAuth,
  db: firebaseFirestore,
  config: firebaseConfig,
  isLive: () => !!firebaseAuth,
  checkConnection: checkFirebaseConnection
};
