/* Register the service worker only in secure contexts supported by browsers. */
(() => {
  if (!('serviceWorker' in navigator)) return;
  const secure = location.protocol === 'https:' || location.hostname === 'localhost' || location.hostname === '127.0.0.1';
  if (!secure) return;
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('./service-worker.js').catch(() => {
      const status = document.getElementById('aiStatus');
      if (status) status.textContent = 'Offline caching unavailable in this browser context.';
    });
  });
})();
