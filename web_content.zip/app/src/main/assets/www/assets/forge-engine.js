/* Forge AI Engine v1.0 — deterministic offline reasoning and retrieval layer.
   This is a symbolic/rule-based engine, not a trained neural language model. */
(function(){
'use strict';
const STORE='forgelife_engine_state_v1';
const STOP=new Set(('the and for with from that this what when where how why can could should would please tell about your you are is a an to of in on it my me i we our do does did based give make best possible').split(' '));
const SYN={fat:['weight','calorie','diet','belly','slim','nutrition'],loose:['lose','weight','fat'],fit:['fitness','exercise','workout','health'],money:['finance','budget','income','expense','saving','spending'],time:['schedule','clock','date','routine','plan'],planned:['calendar','event','task','schedule','next'],remember:['memory','saved','recall'],phone:['android','mobile','device'],problem:['solve','solution','troubleshoot'],anxious:['stress','overwhelmed','worry'],study:['learn','exam','education','revision'],cook:['food','meal','recipe'],safe:['safety','risk','protect'],bike:['motorcycle','vehicle','ride']};
const tokenize=s=>(String(s||'').toLowerCase().match(/[a-z0-9]+/g)||[]).filter(x=>x.length>2&&!STOP.has(x));
const uniq=a=>[...new Set(a)];
function state(){try{return JSON.parse(localStorage.getItem(STORE)||'{}')}catch(_){return {}}}
function saveState(s){try{localStorage.setItem(STORE,JSON.stringify(s))}catch(_){}}
function history(){try{return JSON.parse(localStorage.getItem('forgelife_forge_chat_v1')||'[]').slice(-12)}catch(_){return []}}
function expand(q){let a=tokenize(q),b=[...a];a.forEach(w=>(SYN[w]||[]).forEach(x=>b.push(x)));return uniq(b)}
function retrieve(q){if(typeof FORGE_KB==='undefined')return [];let terms=expand(q),orig=tokenize(q),source=FORGE_KB.slice(0,1000000);return source.map(d=>{let title=tokenize(d.title),tags=tokenize(d.tags),body=tokenize(d.text),category=tokenize(d.category),score=0;terms.forEach(w=>{if(title.includes(w))score+=9;if(tags.includes(w))score+=5;if(category.includes(w))score+=3;if(body.includes(w))score+=1});if(orig.some(w=>title.includes(w)))score+=6;let phrase=String(q||'').toLowerCase();if(phrase.length>4&&String(d.title+' '+d.tags).toLowerCase().includes(phrase))score+=12;return {doc:d,score}}).filter(x=>x.score>0).sort((a,b)=>b.score-a.score).slice(0,10)}
function memory(q){let arr=[];try{arr=JSON.parse(localStorage.getItem('forgelife_forge_memory_v1')||'[]')}catch(_){}let terms=tokenize(q);return arr.map(m=>({text:m.text,score:tokenize(m.text).filter(w=>terms.includes(w)).length})).filter(x=>x.score>0).sort((a,b)=>b.score-a.score).slice(0,3).map(x=>x.text)}
function calc(q){let m=q.match(/(?:what is|calculate|compute)?\s*(-?\d+(?:\.\d+)?)\s*([+\-*/×÷%])\s*(-?\d+(?:\.\d+)?)/i);if(!m)return null;let a=+m[1],b=+m[3],v;switch(m[2]){case '+':v=a+b;break;case '-':v=a-b;break;case '*':case '×':v=a*b;break;case '/':case '÷':if(!b)return 'Division by zero is undefined.';v=a/b;break;case '%':v=a*b/100;break;}return Number.isFinite(v)?`${m[1]} ${m[2]} ${m[3]} = ${Number(v.toPrecision(10))}`:null}
function percent(q){let m=q.match(/(\d+(?:\.\d+)?)\s*%\s*of\s*(\d+(?:\.\d+)?)/i);if(!m)return null;let v=+m[1]*+m[2]/100;return `${m[1]}% of ${m[2]} is ${Number(v.toPrecision(10))}.`}
function live(q){let s=q.toLowerCase(),d=new Date();if(/\b(time now|current time|what time is it|tell me the time)\b/.test(s))return 'The time on this device is '+d.toLocaleTimeString('en-IN',{hour:'numeric',minute:'2-digit'})+'.';if(/\b(today'?s date|what is the date|current date|what day is it|what is today)\b/.test(s))return 'Today is '+d.toLocaleDateString('en-IN',{weekday:'long',day:'numeric',month:'long',year:'numeric'})+'.';if(/\btomorrow('?s date| date| day)\b/.test(s)){d.setDate(d.getDate()+1);return 'Tomorrow is '+d.toLocaleDateString('en-IN',{weekday:'long',day:'numeric',month:'long',year:'numeric'})+'.'}return null}
function appFacts(q){if(typeof db==='undefined')return null;let s=q.toLowerCase();if(/my (money|balance|budget|expenses|spending|income|savings)|how much.*(spent|saved)|my finance/.test(s)){let inc=db.transactions.filter(x=>x.type==='income').reduce((n,x)=>n+Number(x.amount||0),0),exp=db.transactions.filter(x=>x.type==='expense').reduce((n,x)=>n+Number(x.amount||0),0),bal=db.currentBalance==null?inc-exp:Number(db.currentBalance);return `From the records in ForgeLife: current balance ${money(bal)}; recorded income ${money(inc)}; recorded expenses ${money(exp)}; transaction net ${money(inc-exp)}; budget ${money(db.budget||0)}. These figures only include entries saved in the app.`}if(/my (workout|fitness|exercise)|workout progress/.test(s))return `You have ${db.workouts.length} recorded workout sessions, totaling ${db.workouts.reduce((n,x)=>n+Number(x.minutes||0),0)} minutes.`;if(/what.*(next|planned)|upcoming (event|plan)|my calendar/.test(s)){let today=iso(new Date()),e=db.events.filter(x=>x.date>=today).sort((a,b)=>a.date.localeCompare(b.date))[0];return e?`Your next saved event is ${e.title} on ${e.date}${e.details?' — '+e.details:''}.`:'I could not find an upcoming event in your saved calendar.'}return null}
function makePlan(q){let s=q.toLowerCase();if(/how (do i|can i)|step by step|make a plan|routine|roadmap/.test(s)){let topic=q.replace(/^(how do i|how can i|how to|please|make a plan for|give me a plan for)\s*/i,'').replace(/[?.]$/,'').trim();return `Here is a practical way to approach ${topic||'this'}:\n1. Define the exact result you want.\n2. Check your starting point, available time, budget, and constraints.\n3. Break the result into small actions you can complete one at a time.\n4. Start with the safest, easiest useful action today.\n5. Track what happened and review progress after a few days.\n6. Adjust the plan based on results rather than trying to change everything at once.`}return null}
function answer(q){let raw=q.trim(),low=raw.toLowerCase();if(!raw)return 'What would you like help with?';let c=calc(raw)||percent(raw);if(c)return c;let l=live(raw);if(l)return l;if(typeof forgeMemoryCommand==='function'){let mc=forgeMemoryCommand(raw);if(mc)return mc}let facts=appFacts(raw);if(facts)return facts;if(/^(hi|hello|hey|good morning|good afternoon|good evening)[!. ]*$/i.test(raw))return 'Hey! I’m Forge AI. What can I help you figure out?';if(/^(thanks|thank you)[!. ]*$/i.test(raw))return 'You’re welcome!';
let prev=history(),follow=/^(and|also|why|how about|what about|explain more|tell me more|continue|that one|it|which one)\b/i.test(raw);if(follow&&prev.length)low=(prev[prev.length-1].q+' '+raw).toLowerCase();
let mem=memory(low),hits=retrieve(low),plan=makePlan(raw);if(plan){if(mem.length)plan+='\n\nI also considered your saved detail: '+mem.join('; ')+'.';return plan}
if(!hits.length){if(/who are you|what are you/.test(low))return 'I’m Forge AI, the offline assistant built into ForgeLife. I can use the app’s local knowledge directory, saved memories, calculations, and your ForgeLife records. I don’t have a trained neural language model or live internet access in this engine-only version.';return 'I don’t have enough reliable information in my offline knowledge base to answer that confidently. Try asking more specifically, or add a useful note to Forge memory. I won’t invent an answer.'}
let best=hits.slice(0,3),out=best.map((h,i)=>`${i===0?'': '\n\n'}${h.doc.text}`).join('');out=out.replace(/\s+/g,' ').trim();if(mem.length)out+='\n\nRelevant saved memory: '+mem.join('; ')+'.';if(best[0].score<3)out+='\n\nI found only a broad match, so treat this as general guidance rather than a precise answer.';if(/health|symptom|medicine|pain|fever/.test(low))out+=' For severe or worsening symptoms, seek qualified medical care.';if(/invest|stock|share market|loan|debt/.test(low))out+=' Financial outcomes are uncertain; verify current details and consider qualified advice before acting.';return out}
// Friend persona layer: warm, natural and supportive without pretending to be human.
const coreAnswer=answer;
function friendAnswer(q){
 const raw=String(q||'').trim(),s=raw.toLowerCase();
 let out=coreAnswer(raw);
 if(!out)return "I'm here. What's on your mind?";
 // Natural social exchanges should feel like a conversation, not a help-desk script.
 if(/^(hi|hello|hey|heyy|yo|sup)[!. ]*$/i.test(raw)){
  const h=new Date().getHours();
  return (h<12?'Hey, good morning!':h<17?'Hey, good afternoon!':'Hey, good evening!')+" 😊 What's happening? Need a hand with something, or just feel like chatting?";
 }
 if(/^(how are you|how're you|how are things|what's up)[?! .]*$/i.test(raw))return "I'm doing well and ready to help. How are things going on your side?";
 if(/^(thanks|thank you|thx|ty)[!. ]*$/i.test(raw))return "Anytime! That's what I'm here for. 😊";
 if(/^(bye|goodbye|see you|gotta go)[!. ]*$/i.test(raw))return "See you! Take care, and come back whenever you need me.";
 if(/\b(i feel|i am feeling|i'm feeling|i feel like|i'm sad|i am sad|i'm lonely|i am lonely|i'm stressed|i am stressed|i'm worried|i am worried|i'm scared|i am scared|rough day|bad day)\b/.test(s)){
  if(/\b(suicid|kill myself|end my life|self[- ]harm)\b/.test(s))return "I'm really glad you told me. You don't have to handle this alone. If you might hurt yourself or are in immediate danger, contact local emergency services now and reach someone you trust who can stay with you. If you can, tell me: are you in immediate danger right now?";
  return "I'm sorry it's feeling like that. You don't have to make it sound neat or explain it perfectly — I'm here to listen. "+(out.includes("don't have enough reliable information")?"Want to tell me what happened?":"");
 }
 if(/\b(i failed|i messed up|i made a mistake|i'm useless|i am useless|i can't do this|i cannot do this)\b/.test(s))return "Hey, one setback doesn't define you. Let's take it one piece at a time. What happened? We can figure out the next move together.";
 if(/\b(I'm bored|i am bored|bored)\b/.test(s))return "We can fix that 😄 Want to talk, learn something random, plan something, or try a quick challenge?";
 // Add a light conversational frame to reference answers, but keep calculations and live facts clean.
 const factual=/=\s*-?\d|% of .* is |time on this device|Today is |Tomorrow is |current balance /.test(out);
 if(!factual&&!/^(Hey|I'm|I’m|You’re|Anytime|See you|I'm sorry|Hey, one)/.test(out)){
  const lead=/^(how|what|why|when|where|which|who|can|could|should|is|are|do|does|tell me|explain)\b/i.test(s)?"Sure — ":"Okay, here's what I found: ";
  out=lead+out;
 }
 // Avoid stiff repeated endings; invite a useful follow-up only when the answer is broad.
 if(out.length>100&&out.length<900&&!/[?]$/.test(out)&&!factual&&/\b(plan|routine|steps|general guidance|approach)\b/i.test(out))out+=" If you tell me a little about your situation, I can make this more practical.";
 return out;
}
window.ForgeEngine={version:'1.1.0',persona:'friendly-companion',respond:friendAnswer,search:retrieve,diagnostics:()=>({engine:'symbolic-offline',persona:'friendly-companion',knowledgeEntries:typeof FORGE_KB==='undefined'?0:Math.min(FORGE_KB.length,1000000),directories:typeof FORGE_KB==='undefined'?0:new Set(FORGE_KB.map(d=>d.category)).size,knowledgeLimit:1000000,memoryItems:(()=>{try{return JSON.parse(localStorage.getItem('forgelife_forge_memory_v1')||'[]').length}catch(_){return 0}})(),nativeModel:false})};
})();
