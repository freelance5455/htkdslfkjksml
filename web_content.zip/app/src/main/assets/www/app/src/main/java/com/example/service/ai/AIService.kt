package com.example.service.ai

import android.graphics.Bitmap
import android.graphics.Rect
import com.example.BuildConfig

enum class AIProviderType(val displayName: String, val isCloud: Boolean, val badge: String) {
    LOCAL_EDGE("Local Edge CV Engine", false, "On-Device"),
    GEMINI_CLOUD("Google Gemini AI Studio", true, "Cloud AI"),
    CUSTOM_API("Custom Backend Endpoint", true, "Self-Hosted")
}

data class AIConfiguration(
    val activeProvider: AIProviderType = AIProviderType.LOCAL_EDGE,
    val apiKey: String = "",
    val customEndpoint: String = "https://api.enhancex.app/v1",
    val isCloudConnected: Boolean = false
)

interface AIService {
    suspend fun enhanceImage(bitmap: Bitmap, upscale: Boolean = false): Bitmap
    suspend fun removeBackground(bitmap: Bitmap): Bitmap
    suspend fun removeObject(bitmap: Bitmap, maskRects: List<Rect>): Bitmap
    suspend fun restorePhoto(bitmap: Bitmap): Bitmap
    fun getProviderInfo(): AIProviderType
    fun isCloudAvailable(): Boolean
}

class AIServiceManager(
    private val localEngine: com.example.service.ImageProcessingEngine
) : AIService {

    var currentConfig = AIConfiguration(
        activeProvider = if (hasValidGeminiKey()) AIProviderType.GEMINI_CLOUD else AIProviderType.LOCAL_EDGE,
        apiKey = getEffectiveGeminiKey(),
        isCloudConnected = hasValidGeminiKey()
    )
        private set

    fun updateConfig(config: AIConfiguration) {
        currentConfig = config
    }

    override suspend fun enhanceImage(bitmap: Bitmap, upscale: Boolean): Bitmap {
        // High quality on-device processing engine
        val params = com.example.service.EnhancementParams(
            autoEnhance = true,
            sharpness = 40f,
            contrast = 15f,
            saturation = 20f,
            clarity = 25f,
            upscaleFactor = if (upscale) 2 else 1
        )
        return localEngine.processEnhancement(bitmap, params)
    }

    override suspend fun removeBackground(bitmap: Bitmap): Bitmap {
        return localEngine.removeOrReplaceBackground(bitmap, backgroundColorHex = null)
    }

    override suspend fun removeObject(bitmap: Bitmap, maskRects: List<Rect>): Bitmap {
        return localEngine.removeObject(bitmap, maskRects)
    }

    override suspend fun restorePhoto(bitmap: Bitmap): Bitmap {
        return localEngine.restorePhoto(bitmap)
    }

    override fun getProviderInfo(): AIProviderType = currentConfig.activeProvider

    override fun isCloudAvailable(): Boolean = currentConfig.isCloudConnected

    companion object {
        fun hasValidGeminiKey(): Boolean {
            return try {
                val field = BuildConfig::class.java.getDeclaredField("GEMINI_API_KEY")
                val key = field.get(null) as? String
                key != null && key.isNotBlank() && key != "MY_GEMINI_API_KEY"
            } catch (e: Throwable) {
                false
            }
        }

        fun getEffectiveGeminiKey(): String {
            return try {
                val field = BuildConfig::class.java.getDeclaredField("GEMINI_API_KEY")
                (field.get(null) as? String) ?: ""
            } catch (e: Throwable) {
                ""
            }
        }
    }
}
