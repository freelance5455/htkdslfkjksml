package com.example.ui.screens

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.BrightnessMedium
import androidx.compose.material.icons.filled.Contrast
import androidx.compose.material.icons.filled.Details
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MediaMetadata
import com.example.service.VideoEnhancementParams
import com.example.utils.SampleMediaProvider

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VideoEnhanceScreen(
    videoMetadata: MediaMetadata,
    sampleFrameBitmap: Bitmap? = null,
    onBack: () -> Unit,
    onChangeVideo: () -> Unit,
    onEnhance: (VideoEnhancementParams) -> Unit
) {
    // Adjustment Sliders
    var sharpen by remember { mutableFloatStateOf(45f) }
    var brightness by remember { mutableFloatStateOf(0f) }
    var contrast by remember { mutableFloatStateOf(15f) }
    var saturation by remember { mutableFloatStateOf(15f) }

    // AI Pipeline Toggles
    var upscale4k by remember { mutableStateOf(true) }
    var fps60 by remember { mutableStateOf(true) }
    var hdrTone by remember { mutableStateOf(true) }
    var stabilize by remember { mutableStateOf(false) }
    var aiDetailRecovery by remember { mutableStateOf(true) }

    var selectedPreset by remember { mutableStateOf("Vivid HDR") }
    val presets = listOf("Natural", "Vivid HDR", "Ultra Sharp", "Cinema Warm", "Night Boost", "Studio Pro")

    val scrollState = rememberScrollState()

    // Preview frame fallback
    val frameBitmap = remember(sampleFrameBitmap) {
        sampleFrameBitmap ?: SampleMediaProvider.createScenicSample(640, 360)
    }

    // Dynamic ColorMatrix for live real-time preview of adjustments
    val previewColorFilter = remember(brightness, contrast, saturation) {
        val sat = ((100f + saturation) / 100f).coerceIn(0f, 3f)
        val contrastFactor = ((100f + contrast) / 100f).coerceIn(0.2f, 3f)
        val brightnessOffset = brightness * 2.55f

        val androidCm = android.graphics.ColorMatrix().apply {
            setSaturation(sat)
            val cmContrast = android.graphics.ColorMatrix(
                floatArrayOf(
                    contrastFactor, 0f, 0f, 0f, brightnessOffset,
                    0f, contrastFactor, 0f, 0f, brightnessOffset,
                    0f, 0f, contrastFactor, 0f, brightnessOffset,
                    0f, 0f, 0f, 1f, 0f
                )
            )
            postConcat(cmContrast)
        }
        ColorFilter.colorMatrix(ColorMatrix(androidCm.array))
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .testTag("video_enhance_screen")
    ) {
        TopAppBar(
            colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface),
            title = {
                Text(
                    text = "Video Enhance & AI",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
            },
            navigationIcon = {
                IconButton(onClick = onBack) {
                    Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                }
            },
            actions = {
                IconButton(
                    onClick = {
                        sharpen = 0f
                        brightness = 0f
                        contrast = 0f
                        saturation = 0f
                        selectedPreset = "Natural"
                    }
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Reset adjustments",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        )

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(scrollState)
                .padding(16.dp)
        ) {
            // Live Video Frame Preview Card with Real-time Adjustments
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0E1320)),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x661E293B)),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("video_preview_card")
            ) {
                Column {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(16f / 9f)
                            .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
                            .background(Color.Black)
                    ) {
                        Image(
                            bitmap = frameBitmap.asImageBitmap(),
                            contentDescription = "Live Video Frame Preview",
                            colorFilter = previewColorFilter,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )

                        // Top Badges Overlay
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Color.Black.copy(alpha = 0.65f),
                                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x40FFFFFF))
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(6.dp)
                                            .clip(CircleShape)
                                            .background(Color(0xFF10B981))
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "LIVE FRAME PREVIEW",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                }
                            }

                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Color(0xFF4F46E5).copy(alpha = 0.85f)
                            ) {
                                Text(
                                    text = if (upscale4k) "4K UHD" else "1080P",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }

                        // Center Play Indicator
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(Color.Black.copy(alpha = 0.5f))
                                .align(Alignment.Center)
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }

                    // Metadata footer & Change Video Button
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = videoMetadata.fileName,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface,
                                maxLines = 1
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "${videoMetadata.readableDimensions} • ${videoMetadata.readableDuration} • ${videoMetadata.readableSize}",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.primaryContainer,
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .clickable(onClick = onChangeVideo)
                                .testTag("change_video_button")
                        ) {
                            Text(
                                text = "Change Video",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Presets Horizontal Row
            Text(
                text = "ENHANCEMENT PRESETS",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                letterSpacing = 0.5.sp
            )

            Spacer(modifier = Modifier.height(8.dp))

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(vertical = 4.dp)
            ) {
                items(presets) { preset ->
                    val isSelected = preset == selectedPreset
                    FilterChip(
                        selected = isSelected,
                        onClick = {
                            selectedPreset = preset
                            when (preset) {
                                "Natural" -> {
                                    sharpen = 15f
                                    brightness = 0f
                                    contrast = 5f
                                    saturation = 5f
                                }
                                "Vivid HDR" -> {
                                    sharpen = 50f
                                    brightness = 4f
                                    contrast = 20f
                                    saturation = 25f
                                }
                                "Ultra Sharp" -> {
                                    sharpen = 85f
                                    brightness = 2f
                                    contrast = 15f
                                    saturation = 10f
                                }
                                "Cinema Warm" -> {
                                    sharpen = 40f
                                    brightness = -2f
                                    contrast = 22f
                                    saturation = 18f
                                }
                                "Night Boost" -> {
                                    sharpen = 45f
                                    brightness = 25f
                                    contrast = 18f
                                    saturation = 12f
                                }
                                "Studio Pro" -> {
                                    sharpen = 60f
                                    brightness = 8f
                                    contrast = 14f
                                    saturation = 12f
                                }
                            }
                        },
                        label = { Text(preset, fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primary,
                            selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Live Adjustments: Sharpen, Brightness, Contrast, Saturation
            Text(
                text = "MANUAL ADJUSTMENTS (REAL-TIME PREVIEW)",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                letterSpacing = 0.5.sp
            )

            Spacer(modifier = Modifier.height(10.dp))

            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    // Sharpen Slider
                    VideoAdjustmentSlider(
                        title = "Sharpening",
                        value = sharpen,
                        valueDisplay = "${sharpen.toInt()}%",
                        range = 0f..100f,
                        icon = Icons.Default.Details,
                        onValueChange = {
                            sharpen = it
                            selectedPreset = "Custom"
                        }
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Brightness Slider
                    VideoAdjustmentSlider(
                        title = "Brightness",
                        value = brightness,
                        valueDisplay = if (brightness > 0) "+${brightness.toInt()}" else "${brightness.toInt()}",
                        range = -50f..50f,
                        icon = Icons.Default.BrightnessMedium,
                        onValueChange = {
                            brightness = it
                            selectedPreset = "Custom"
                        }
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Contrast Slider
                    VideoAdjustmentSlider(
                        title = "Contrast",
                        value = contrast,
                        valueDisplay = if (contrast > 0) "+${contrast.toInt()}" else "${contrast.toInt()}",
                        range = -50f..50f,
                        icon = Icons.Default.Contrast,
                        onValueChange = {
                            contrast = it
                            selectedPreset = "Custom"
                        }
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Saturation Slider
                    VideoAdjustmentSlider(
                        title = "Saturation",
                        value = saturation,
                        valueDisplay = if (saturation > 0) "+${saturation.toInt()}" else "${saturation.toInt()}",
                        range = -50f..50f,
                        icon = Icons.Default.Palette,
                        onValueChange = {
                            saturation = it
                            selectedPreset = "Custom"
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // AI Enhancement Pipeline Toggles
            Text(
                text = "AI NEURAL PIPELINE",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                letterSpacing = 0.5.sp
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Switch Item 1: 4K Super Resolution
            EnhanceToggleCard(
                title = "4K Super-Resolution Pass",
                subtitle = "Neural bicubic edge-preserving upscaler to 3840×2160",
                badge = "4K AI",
                checked = upscale4k,
                onCheckedChange = { upscale4k = it }
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Switch Item 2: 60 FPS Smoother
            EnhanceToggleCard(
                title = "60 FPS Motion Interpolation",
                subtitle = "Smooth out low framerate jitter with frame blending",
                badge = "60 FPS",
                checked = fps60,
                onCheckedChange = { fps60 = it }
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Switch Item 3: HDR Tone Boost
            EnhanceToggleCard(
                title = "Vivid HDR Dynamic Range",
                subtitle = "Expands shadow details and increases dynamic color punch",
                badge = "HDR",
                checked = hdrTone,
                onCheckedChange = { hdrTone = it }
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Switch Item 4: AI Detail & Noise Removal
            EnhanceToggleCard(
                title = "AI Neural Detail Recovery",
                subtitle = "Restores lost textures and suppresses compression artifacts",
                badge = "AI",
                checked = aiDetailRecovery,
                onCheckedChange = { aiDetailRecovery = it }
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Switch Item 5: Stabilization
            EnhanceToggleCard(
                title = "Gimbal Stabilization Pass",
                subtitle = "Reduces handheld camera shake and horizon wobble",
                badge = "Smooth",
                checked = stabilize,
                onCheckedChange = { stabilize = it }
            )

            Spacer(modifier = Modifier.height(24.dp))
        }

        // Bottom Action Bar
        Surface(
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Box(modifier = Modifier.padding(16.dp)) {
                Button(
                    onClick = {
                        onEnhance(
                            VideoEnhancementParams(
                                sharpen = sharpen,
                                brightness = brightness,
                                contrast = contrast,
                                saturation = saturation,
                                upscale4k = upscale4k,
                                fps60 = fps60,
                                hdrTone = hdrTone,
                                stabilize = stabilize,
                                aiDetailRecovery = aiDetailRecovery
                            )
                        )
                    },
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("execute_video_enhance_button")
                ) {
                    Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Enhance Video (Fast AI)",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun VideoAdjustmentSlider(
    title: String,
    value: Float,
    valueDisplay: String,
    range: ClosedFloatingPointRange<Float>,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onValueChange: (Float) -> Unit
) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = title,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
            Text(
                text = valueDisplay,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = range,
            colors = SliderDefaults.colors(
                thumbColor = MaterialTheme.colorScheme.primary,
                activeTrackColor = MaterialTheme.colorScheme.primary
            ),
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
private fun EnhanceToggleCard(
    title: String,
    subtitle: String,
    badge: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (checked) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
            else MaterialTheme.colorScheme.surface
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = title,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
                    ) {
                        Text(
                            text = badge,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Switch(
                checked = checked,
                onCheckedChange = onCheckedChange,
                colors = SwitchDefaults.colors(checkedThumbColor = MaterialTheme.colorScheme.primary)
            )
        }
    }
}
