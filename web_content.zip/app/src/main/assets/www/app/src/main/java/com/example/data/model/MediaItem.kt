package com.example.data.model

enum class MediaType {
    IMAGE,
    VIDEO
}

enum class ToolType(val displayName: String, val isAi: Boolean, val defaultTag: String) {
    PHOTO_ENHANCE("Photo Enhance", true, "AI"),
    VIDEO_ENHANCE("Video Enhance", true, "AI"),
    COMPRESS_VIDEO("Compress Video", false, "Core"),
    REMOVE_BACKGROUND("Remove Background", true, "AI"),
    IMAGE_COMPRESS("Image Compressor", false, "Local"),
    RESIZE_IMAGE("Resize Image", false, "Local"),
    IMAGE_CONVERT("Image Converter", false, "Local"),
    VIDEO_CONVERT("Video Converter", false, "Tool"),
    VIDEO_TO_GIF("Video to GIF", false, "Local"),
    OBJECT_REMOVE("Object Remover", true, "AI"),
    PHOTO_RESTORE("Photo Restoration", true, "AI"),
    MORE_TOOLS("Media Utilities", false, "Info")
}

data class MediaMetadata(
    val fileName: String,
    val width: Int,
    val height: Int,
    val fileSizeBytes: Long,
    val format: String,
    val durationMs: Long = 0L,
    val frameRate: Float = 0f
) {
    val readableSize: String
        get() {
            if (fileSizeBytes <= 0) return "0 KB"
            val kb = fileSizeBytes / 1024.0
            val mb = kb / 1024.0
            val gb = mb / 1024.0
            return when {
                gb >= 1.0 -> String.format("%.2f GB", gb)
                mb >= 1.0 -> String.format("%.1f MB", mb)
                else -> String.format("%.0f KB", kb)
            }
        }

    val readableDimensions: String
        get() = if (width > 0 && height > 0) "${width} × ${height}" else "Unknown"

    val readableDuration: String
        get() {
            if (durationMs <= 0) return "0:00"
            val totalSec = durationMs / 1000
            val min = totalSec / 60
            val sec = totalSec % 60
            return String.format("%d:%02d", min, sec)
        }
}
