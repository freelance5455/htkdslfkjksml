package com.example.utils

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader

object SampleMediaProvider {

    /**
     * Generates a high quality scenic landscape bitmap for testing photo enhancement,
     * compression, resizing, and conversion.
     */
    fun createScenicSample(width: Int = 1200, height: Int = 900): Bitmap {
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)

        // Sky gradient
        paint.shader = LinearGradient(
            0f, 0f, 0f, height * 0.65f,
            intArrayOf(
                Color.rgb(24, 76, 140),
                Color.rgb(79, 148, 204),
                Color.rgb(238, 168, 107),
                Color.rgb(247, 214, 148)
            ),
            floatArrayOf(0f, 0.4f, 0.8f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, 0f, width.toFloat(), height * 0.65f, paint)

        // Sun
        paint.shader = RadialGradient(
            width * 0.7f, height * 0.42f, width * 0.12f,
            intArrayOf(Color.rgb(255, 250, 230), Color.argb(180, 255, 200, 100), Color.TRANSPARENT),
            floatArrayOf(0f, 0.4f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(width * 0.7f, height * 0.42f, width * 0.15f, paint)

        // Distant Mountains
        paint.shader = null
        paint.color = Color.rgb(65, 80, 115)
        val mountainFar = Path().apply {
            moveTo(0f, height * 0.55f)
            lineTo(width * 0.2f, height * 0.38f)
            lineTo(width * 0.45f, height * 0.48f)
            lineTo(width * 0.68f, height * 0.35f)
            lineTo(width * 0.88f, height * 0.45f)
            lineTo(width.toFloat(), height * 0.40f)
            lineTo(width.toFloat(), height.toFloat())
            lineTo(0f, height.toFloat())
            close()
        }
        canvas.drawPath(mountainFar, paint)

        // Midground Mountains
        paint.color = Color.rgb(42, 58, 88)
        val mountainMid = Path().apply {
            moveTo(0f, height * 0.62f)
            lineTo(width * 0.32f, height * 0.46f)
            lineTo(width * 0.58f, height * 0.56f)
            lineTo(width * 0.82f, height * 0.44f)
            lineTo(width.toFloat(), height * 0.58f)
            lineTo(width.toFloat(), height.toFloat())
            lineTo(0f, height.toFloat())
            close()
        }
        canvas.drawPath(mountainMid, paint)

        // Lake / Foreground Water
        paint.shader = LinearGradient(
            0f, height * 0.62f, 0f, height.toFloat(),
            intArrayOf(Color.rgb(30, 60, 95), Color.rgb(18, 40, 70), Color.rgb(10, 25, 45)),
            null,
            Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, height * 0.62f, width.toFloat(), height.toFloat(), paint)

        // Water reflection
        paint.shader = null
        paint.color = Color.argb(60, 255, 210, 150)
        canvas.drawRect(width * 0.65f, height * 0.62f, width * 0.75f, height * 0.85f, paint)

        // Foreground Pine Trees Silhouette
        paint.color = Color.rgb(12, 22, 36)
        drawPineTree(canvas, paint, width * 0.08f, height * 0.88f, height * 0.35f)
        drawPineTree(canvas, paint, width * 0.16f, height * 0.92f, height * 0.28f)
        drawPineTree(canvas, paint, width * 0.88f, height * 0.90f, height * 0.32f)
        drawPineTree(canvas, paint, width * 0.94f, height * 0.94f, height * 0.25f)

        return bitmap
    }

    /**
     * Generates a sample portrait / subject on studio background for background removal,
     * object removal, and face/detail enhancement.
     */
    fun createPortraitSample(width: Int = 1000, height: Int = 1000): Bitmap {
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)

        // Studio backdrop gradient (radial)
        paint.shader = RadialGradient(
            width * 0.5f, height * 0.45f, width * 0.65f,
            intArrayOf(Color.rgb(220, 225, 235), Color.rgb(160, 175, 195), Color.rgb(110, 125, 145)),
            floatArrayOf(0f, 0.6f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)

        // Subject silhouette & avatar
        paint.shader = null

        // Shoulders / Torso
        paint.color = Color.rgb(30, 41, 59)
        val bodyPath = Path().apply {
            moveTo(width * 0.22f, height.toFloat())
            quadTo(width * 0.28f, height * 0.70f, width * 0.38f, height * 0.62f)
            lineTo(width * 0.62f, height * 0.62f)
            quadTo(width * 0.72f, height * 0.70f, width * 0.78f, height.toFloat())
            close()
        }
        canvas.drawPath(bodyPath, paint)

        // Neck
        paint.color = Color.rgb(224, 166, 134)
        canvas.drawRect(width * 0.44f, height * 0.52f, width * 0.56f, height * 0.65f, paint)

        // Head
        paint.color = Color.rgb(238, 185, 154)
        canvas.drawOval(width * 0.36f, height * 0.28f, width * 0.64f, height * 0.56f, paint)

        // Hair
        paint.color = Color.rgb(40, 30, 25)
        val hairPath = Path().apply {
            moveTo(width * 0.34f, height * 0.40f)
            cubicTo(width * 0.32f, height * 0.20f, width * 0.68f, height * 0.20f, width * 0.66f, height * 0.40f)
            lineTo(width * 0.60f, height * 0.30f)
            quadTo(width * 0.50f, height * 0.26f, width * 0.38f, height * 0.32f)
            close()
        }
        canvas.drawPath(hairPath, paint)

        // Eyeglasses (nice subject detail)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 10f
        paint.color = Color.rgb(15, 23, 42)
        canvas.drawCircle(width * 0.44f, height * 0.42f, 32f, paint)
        canvas.drawCircle(width * 0.56f, height * 0.42f, 32f, paint)
        canvas.drawLine(width * 0.47f, height * 0.42f, width * 0.53f, height * 0.42f, paint)

        // Smile
        paint.strokeWidth = 6f
        paint.color = Color.rgb(180, 80, 80)
        canvas.drawArc(width * 0.45f, height * 0.46f, width * 0.55f, height * 0.52f, 10f, 160f, false, paint)

        // An unwanted coffee cup object on the side (for Object Remover testing!)
        paint.style = Paint.Style.FILL
        paint.color = Color.rgb(220, 38, 38) // Red mug
        canvas.drawRoundRect(width * 0.78f, height * 0.74f, width * 0.92f, height * 0.90f, 16f, 16f, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 8f
        canvas.drawArc(width * 0.88f, height * 0.78f, width * 0.98f, height * 0.86f, 270f, 180f, false, paint)

        return bitmap
    }

    private fun drawPineTree(canvas: Canvas, paint: Paint, x: Float, baseY: Float, treeHeight: Float) {
        val path = Path()
        val halfW = treeHeight * 0.22f
        path.moveTo(x, baseY - treeHeight)
        path.lineTo(x + halfW * 0.4f, baseY - treeHeight * 0.7f)
        path.lineTo(x + halfW * 0.25f, baseY - treeHeight * 0.7f)
        path.lineTo(x + halfW * 0.7f, baseY - treeHeight * 0.4f)
        path.lineTo(x + halfW * 0.45f, baseY - treeHeight * 0.4f)
        path.lineTo(x + halfW, baseY)
        path.lineTo(x - halfW, baseY)
        path.lineTo(x - halfW * 0.45f, baseY - treeHeight * 0.4f)
        path.lineTo(x - halfW * 0.7f, baseY - treeHeight * 0.4f)
        path.lineTo(x - halfW * 0.25f, baseY - treeHeight * 0.7f)
        path.lineTo(x - halfW * 0.4f, baseY - treeHeight * 0.7f)
        path.close()
        canvas.drawPath(path, paint)
    }
}
