package com.example.viewmodel

import android.app.Application
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.AppDatabase
import com.example.data.db.ProjectEntity
import com.example.data.db.ProjectRepository
import com.example.data.model.MediaMetadata
import com.example.data.model.MediaType
import com.example.data.model.ToolType
import com.example.service.EnhancementParams
import com.example.service.ImageProcessingEngine
import com.example.service.VideoEnhancementParams
import com.example.service.VideoProcessingEngine
import com.example.service.ai.AIServiceManager
import com.example.ui.components.AppDestination
import com.example.ui.theme.ThemeMode
import com.example.utils.SampleMediaProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

sealed class ScreenDestination {
    object MainNavigation : ScreenDestination()
    data class ActiveToolScreen(val toolType: ToolType) : ScreenDestination()
    data class ResultScreen(
        val title: String,
        val toolName: String,
        val beforeBitmap: Bitmap? = null,
        val afterBitmap: Bitmap? = null,
        val originalSizeText: String,
        val outputSizeText: String,
        val reductionPercent: Int = 0,
        val dimensionsText: String,
        val formatText: String,
        val processingTimeText: String = "1.2s",
        val savedFile: File? = null
    ) : ScreenDestination()
}

class EnhanceXViewModel(application: Application) : AndroidViewModel(application) {

    private val context = application.applicationContext
    private val database = AppDatabase.getDatabase(context)
    private val repository = ProjectRepository(database.projectDao())

    val imageEngine = ImageProcessingEngine(context)
    val videoEngine = VideoProcessingEngine(context)
    val aiServiceManager = AIServiceManager(imageEngine)

    // History from Room
    val projects: StateFlow<List<ProjectEntity>> = repository.allProjects
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Navigation state
    private val _currentNavDestination = MutableStateFlow(AppDestination.HOME)
    val currentNavDestination = _currentNavDestination.asStateFlow()

    private val _screenDestination = MutableStateFlow<ScreenDestination>(ScreenDestination.MainNavigation)
    val screenDestination = _screenDestination.asStateFlow()

    // Processing Dialog State
    private val _isProcessing = MutableStateFlow(false)
    val isProcessing = _isProcessing.asStateFlow()

    private val _processingProgress = MutableStateFlow(0)
    val processingProgress = _processingProgress.asStateFlow()

    private val _processingStage = MutableStateFlow("Preparing...")
    val processingStage = _processingStage.asStateFlow()

    private val _processingTitle = MutableStateFlow("Processing Media...")
    val processingTitle = _processingTitle.asStateFlow()

    // Media Picking State
    private val _showPickerSheet = MutableStateFlow(false)
    val showPickerSheet = _showPickerSheet.asStateFlow()

    private val _targetPickerMediaType = MutableStateFlow(MediaType.IMAGE)
    val targetPickerMediaType = _targetPickerMediaType.asStateFlow()

    private var pendingToolLaunch: ToolType? = null

    // Active Media in Memory
    var currentPhotoBitmap: Bitmap = SampleMediaProvider.createScenicSample()
        private set

    var currentVideoMetadata: MediaMetadata = videoEngine.getSampleVideoMetadata()
        private set

    // Theme Mode
    private val _themeMode = MutableStateFlow(ThemeMode.DARK)
    val themeMode = _themeMode.asStateFlow()

    // Cache Size State
    private val _cacheSize = MutableStateFlow("0 KB")
    val cacheSize = _cacheSize.asStateFlow()

    init {
        updateCacheSize()
    }

    fun setNavDestination(destination: AppDestination) {
        _currentNavDestination.value = destination
        _screenDestination.value = ScreenDestination.MainNavigation
    }

    fun setThemeMode(mode: ThemeMode) {
        _themeMode.value = mode
    }

    fun openTool(toolType: ToolType) {
        pendingToolLaunch = toolType
        val requiredMediaType = if (toolType == ToolType.COMPRESS_VIDEO || toolType == ToolType.VIDEO_ENHANCE ||
            toolType == ToolType.VIDEO_TO_GIF || toolType == ToolType.VIDEO_CONVERT) {
            MediaType.VIDEO
        } else {
            MediaType.IMAGE
        }

        _targetPickerMediaType.value = requiredMediaType
        _showPickerSheet.value = false
        // Instantly launch the tool without blocking modal sheet
        _screenDestination.value = ScreenDestination.ActiveToolScreen(toolType)
    }

    fun requestMediaPicker(mediaType: MediaType) {
        _targetPickerMediaType.value = mediaType
        _showPickerSheet.value = true
    }

    fun dismissPickerSheet() {
        _showPickerSheet.value = false
    }

    fun onSelectDeviceImage(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                context.contentResolver.openInputStream(uri)?.use { stream ->
                    val bitmap = BitmapFactory.decodeStream(stream)
                    if (bitmap != null) {
                        currentPhotoBitmap = bitmap
                        launchPendingTool()
                    }
                }
            } catch (e: Exception) {
                // Fallback to sample
                launchPendingTool()
            }
        }
    }

    fun onSelectDeviceVideo(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            currentVideoMetadata = videoEngine.analyzeVideo(uri)
            launchPendingTool()
        }
    }

    fun useSamplePhotoScenic() {
        currentPhotoBitmap = SampleMediaProvider.createScenicSample()
        launchPendingTool()
    }

    fun useSamplePhotoPortrait() {
        currentPhotoBitmap = SampleMediaProvider.createPortraitSample()
        launchPendingTool()
    }

    fun useSampleVideo() {
        currentVideoMetadata = videoEngine.getSampleVideoMetadata()
        launchPendingTool()
    }

    private fun launchPendingTool() {
        _showPickerSheet.value = false
        val tool = pendingToolLaunch ?: ToolType.PHOTO_ENHANCE
        _screenDestination.value = ScreenDestination.ActiveToolScreen(tool)
    }

    fun navigateBackToNav() {
        _screenDestination.value = ScreenDestination.MainNavigation
    }

    private fun createVideoCacheFile(title: String): File {
        val dir = File(context.filesDir, "exports").apply { mkdirs() }
        val safeName = title.replace("[^a-zA-Z0-9._-]".toRegex(), "_")
        val file = File(dir, safeName)
        if (!file.exists()) {
            file.writeBytes(ByteArray(1024))
        }
        return file
    }

    // Execution: Photo Enhance (Optimized with Room instant cache lookup)
    fun processPhotoEnhancement(params: EnhancementParams) {
        viewModelScope.launch {
            val beforeBitmap = currentPhotoBitmap
            val cacheKey = "photo_enhance_${beforeBitmap.width}x${beforeBitmap.height}_${params.upscaleFactor}_" +
                    "${params.autoEnhance}_${params.brightness.toInt()}_${params.contrast.toInt()}_" +
                    "${params.saturation.toInt()}_${params.sharpness.toInt()}_${params.denoise.toInt()}_${params.presetName}"

            // 1. Instant Cache Check from Room
            val cached = withContext(Dispatchers.IO) { repository.findByCacheKey(cacheKey) }
            if (cached != null && cached.hasValidFile) {
                val cachedBitmap = withContext(Dispatchers.IO) {
                    BitmapFactory.decodeFile(cached.outputPath)
                }
                if (cachedBitmap != null) {
                    _screenDestination.value = ScreenDestination.ResultScreen(
                        title = cached.title,
                        toolName = "Photo Enhance",
                        beforeBitmap = beforeBitmap,
                        afterBitmap = cachedBitmap,
                        originalSizeText = cached.readableOriginalSize,
                        outputSizeText = cached.readableOutputSize,
                        reductionPercent = cached.reductionPercent,
                        dimensionsText = cached.outputDimensions,
                        formatText = if (cached.formatText.isNotEmpty()) cached.formatText else "JPEG (High Quality)",
                        savedFile = File(cached.outputPath),
                        processingTimeText = "0ms (Instant Cache)"
                    )
                    return@launch
                }
            }

            _isProcessing.value = true
            _processingTitle.value = "Enhancing Photo..."
            _processingProgress.value = 25
            _processingStage.value = "Analyzing color histograms & dynamic range..."
            kotlinx.coroutines.delay(60)

            _processingProgress.value = 65
            _processingStage.value = "Applying AI sharpening & neural kernels..."
            val enhancedBitmap = withContext(Dispatchers.Default) {
                imageEngine.processEnhancement(beforeBitmap, params)
            }

            _processingProgress.value = 90
            _processingStage.value = "Writing enhanced bitmap buffer..."
            val savedFile = withContext(Dispatchers.IO) {
                imageEngine.saveBitmapToFile(enhancedBitmap, "JPEG", 94)
            }

            _processingProgress.value = 100
            _processingStage.value = "Done!"
            kotlinx.coroutines.delay(40)
            _isProcessing.value = false

            // Save to Room database with cache key and local file path
            val entity = ProjectEntity(
                title = "Enhanced_Photo_${System.currentTimeMillis() % 1000}.jpg",
                mediaType = MediaType.IMAGE,
                toolType = ToolType.PHOTO_ENHANCE,
                originalSizeBytes = (beforeBitmap.width * beforeBitmap.height * 2L),
                outputSizeBytes = savedFile.length(),
                originalDimensions = "${beforeBitmap.width} × ${beforeBitmap.height}",
                outputDimensions = "${enhancedBitmap.width} × ${enhancedBitmap.height}",
                outputPath = savedFile.absolutePath,
                cacheKey = cacheKey,
                formatText = "JPEG (High Quality)",
                settingsSummary = "Scale: ${params.upscaleFactor}x • ${params.presetName}",
                isCached = true
            )
            repository.insertProject(entity)

            _screenDestination.value = ScreenDestination.ResultScreen(
                title = "Enhanced Photo",
                toolName = "Photo Enhance",
                beforeBitmap = beforeBitmap,
                afterBitmap = enhancedBitmap,
                originalSizeText = String.format("%.1f MB", (beforeBitmap.width * beforeBitmap.height * 2.0) / (1024 * 1024)),
                outputSizeText = String.format("%.1f MB", savedFile.length() / (1024.0 * 1024.0)),
                reductionPercent = 0,
                dimensionsText = "${enhancedBitmap.width} × ${enhancedBitmap.height}",
                formatText = "JPEG (High Quality)",
                savedFile = savedFile,
                processingTimeText = "0.2s"
            )
            updateCacheSize()
        }
    }

    // Execution: Image Compression (with Room cache check)
    fun processImageCompression(format: String, quality: Int, scalePercent: Int) {
        viewModelScope.launch {
            val cacheKey = "img_compress_${currentPhotoBitmap.width}x${currentPhotoBitmap.height}_${format}_${quality}_${scalePercent}"
            val cached = withContext(Dispatchers.IO) { repository.findByCacheKey(cacheKey) }
            if (cached != null && cached.hasValidFile) {
                val cachedBitmap = withContext(Dispatchers.IO) {
                    BitmapFactory.decodeFile(cached.outputPath)
                }
                if (cachedBitmap != null) {
                    _screenDestination.value = ScreenDestination.ResultScreen(
                        title = cached.title,
                        toolName = "Image Compressor",
                        beforeBitmap = currentPhotoBitmap,
                        afterBitmap = cachedBitmap,
                        originalSizeText = cached.readableOriginalSize,
                        outputSizeText = cached.readableOutputSize,
                        reductionPercent = cached.reductionPercent,
                        dimensionsText = cached.outputDimensions,
                        formatText = if (cached.formatText.isNotEmpty()) cached.formatText else format,
                        savedFile = File(cached.outputPath),
                        processingTimeText = "0ms (Instant Cache)"
                    )
                    return@launch
                }
            }

            _isProcessing.value = true
            _processingTitle.value = "Compressing Image..."
            _processingProgress.value = 20
            _processingStage.value = "Rescaling and quantizing color palette..."
            kotlinx.coroutines.delay(300)

            _processingProgress.value = 70
            _processingStage.value = "Compressing stream ($format at $quality%)..."
            val result = imageEngine.compressImage(currentPhotoBitmap, format, quality, scalePercent)

            _processingProgress.value = 100
            _processingStage.value = "Compression completed!"
            kotlinx.coroutines.delay(200)
            _isProcessing.value = false

            // Save to Room with cache key
            repository.insertProject(
                ProjectEntity(
                    title = "Compressed_${System.currentTimeMillis() % 1000}.${format.lowercase()}",
                    mediaType = MediaType.IMAGE,
                    toolType = ToolType.IMAGE_COMPRESS,
                    originalSizeBytes = result.originalBytes,
                    outputSizeBytes = result.compressedBytes,
                    originalDimensions = "${currentPhotoBitmap.width} × ${currentPhotoBitmap.height}",
                    outputDimensions = "${result.compressedBitmap.width} × ${result.compressedBitmap.height}",
                    outputPath = result.savedFile?.absolutePath ?: "",
                    cacheKey = cacheKey,
                    formatText = format,
                    settingsSummary = "Quality: $quality% • Scale: $scalePercent%",
                    isCached = true
                )
            )

            _screenDestination.value = ScreenDestination.ResultScreen(
                title = "Compressed Image",
                toolName = "Image Compressor",
                beforeBitmap = currentPhotoBitmap,
                afterBitmap = result.compressedBitmap,
                originalSizeText = String.format("%.1f MB", result.originalBytes / (1024.0 * 1024.0)),
                outputSizeText = if (result.compressedBytes > 1024 * 1024) String.format("%.1f MB", result.compressedBytes / (1024.0 * 1024.0)) else String.format("%.0f KB", result.compressedBytes / 1024.0),
                reductionPercent = result.reductionPercent,
                dimensionsText = "${result.compressedBitmap.width} × ${result.compressedBitmap.height}",
                formatText = format,
                savedFile = result.savedFile
            )
            updateCacheSize()
        }
    }

    // Execution: Resize Image (with Room cache check)
    fun processImageResize(targetW: Int, targetH: Int) {
        viewModelScope.launch {
            val cacheKey = "img_resize_${currentPhotoBitmap.width}x${currentPhotoBitmap.height}_to_${targetW}x${targetH}"
            val cached = withContext(Dispatchers.IO) { repository.findByCacheKey(cacheKey) }
            if (cached != null && cached.hasValidFile) {
                val cachedBitmap = withContext(Dispatchers.IO) {
                    BitmapFactory.decodeFile(cached.outputPath)
                }
                if (cachedBitmap != null) {
                    _screenDestination.value = ScreenDestination.ResultScreen(
                        title = cached.title,
                        toolName = "Image Resizer",
                        beforeBitmap = currentPhotoBitmap,
                        afterBitmap = cachedBitmap,
                        originalSizeText = cached.originalDimensions,
                        outputSizeText = cached.outputDimensions,
                        reductionPercent = 0,
                        dimensionsText = cached.outputDimensions,
                        formatText = if (cached.formatText.isNotEmpty()) cached.formatText else "JPEG",
                        savedFile = File(cached.outputPath),
                        processingTimeText = "0ms (Instant Cache)"
                    )
                    return@launch
                }
            }

            _isProcessing.value = true
            _processingTitle.value = "Resizing Image..."
            _processingProgress.value = 30
            _processingStage.value = "Bicubic pixel interpolation..."
            kotlinx.coroutines.delay(250)

            val resized = imageEngine.resizeImage(currentPhotoBitmap, targetW, targetH)
            val savedFile = imageEngine.saveBitmapToFile(resized, "JPEG", 90)

            _processingProgress.value = 100
            _processingStage.value = "Done!"
            kotlinx.coroutines.delay(150)
            _isProcessing.value = false

            repository.insertProject(
                ProjectEntity(
                    title = "Resized_${targetW}x${targetH}.jpg",
                    mediaType = MediaType.IMAGE,
                    toolType = ToolType.RESIZE_IMAGE,
                    originalSizeBytes = (currentPhotoBitmap.width * currentPhotoBitmap.height * 2L),
                    outputSizeBytes = savedFile.length(),
                    originalDimensions = "${currentPhotoBitmap.width} × ${currentPhotoBitmap.height}",
                    outputDimensions = "${targetW} × ${targetH}",
                    outputPath = savedFile.absolutePath,
                    cacheKey = cacheKey,
                    formatText = "JPEG",
                    settingsSummary = "${targetW} × ${targetH}",
                    isCached = true
                )
            )

            _screenDestination.value = ScreenDestination.ResultScreen(
                title = "Resized Image",
                toolName = "Image Resizer",
                beforeBitmap = currentPhotoBitmap,
                afterBitmap = resized,
                originalSizeText = "${currentPhotoBitmap.width} × ${currentPhotoBitmap.height}",
                outputSizeText = "${targetW} × ${targetH}",
                reductionPercent = 0,
                dimensionsText = "${targetW} × ${targetH}",
                formatText = "JPEG",
                savedFile = savedFile
            )
            updateCacheSize()
        }
    }

    // Execution: Background Removal (with Room cache check)
    fun processBackgroundRemoval(backgroundColorHex: String?, blurBackground: Boolean) {
        viewModelScope.launch {
            val cacheKey = "bg_remove_${currentPhotoBitmap.width}x${currentPhotoBitmap.height}_hex_${backgroundColorHex}_blur_${blurBackground}"
            val cached = withContext(Dispatchers.IO) { repository.findByCacheKey(cacheKey) }
            if (cached != null && cached.hasValidFile) {
                val cachedBitmap = withContext(Dispatchers.IO) {
                    BitmapFactory.decodeFile(cached.outputPath)
                }
                if (cachedBitmap != null) {
                    _screenDestination.value = ScreenDestination.ResultScreen(
                        title = cached.title,
                        toolName = "Background Remover",
                        beforeBitmap = currentPhotoBitmap,
                        afterBitmap = cachedBitmap,
                        originalSizeText = cached.readableOriginalSize,
                        outputSizeText = cached.readableOutputSize,
                        reductionPercent = 0,
                        dimensionsText = cached.outputDimensions,
                        formatText = if (cached.formatText.isNotEmpty()) cached.formatText else "PNG",
                        savedFile = File(cached.outputPath),
                        processingTimeText = "0ms (Instant Cache)"
                    )
                    return@launch
                }
            }

            _isProcessing.value = true
            _processingTitle.value = "Removing Background..."
            _processingProgress.value = 25
            _processingStage.value = "Computing edge gradients & luminance mask..."
            kotlinx.coroutines.delay(400)

            _processingProgress.value = 65
            _processingStage.value = "Feathering boundary & synthesizing backdrop..."
            val cutout = imageEngine.removeOrReplaceBackground(currentPhotoBitmap, backgroundColorHex, blurBackground)
            val format = if (backgroundColorHex == null && !blurBackground) "PNG" else "JPEG"
            val savedFile = imageEngine.saveBitmapToFile(cutout, format, 95)

            _processingProgress.value = 100
            _processingStage.value = "Completed!"
            kotlinx.coroutines.delay(200)
            _isProcessing.value = false

            repository.insertProject(
                ProjectEntity(
                    title = "Cutout_${System.currentTimeMillis() % 1000}.$format",
                    mediaType = MediaType.IMAGE,
                    toolType = ToolType.REMOVE_BACKGROUND,
                    originalSizeBytes = (currentPhotoBitmap.width * currentPhotoBitmap.height * 2L),
                    outputSizeBytes = savedFile.length(),
                    originalDimensions = "${currentPhotoBitmap.width} × ${currentPhotoBitmap.height}",
                    outputDimensions = "${cutout.width} × ${cutout.height}",
                    outputPath = savedFile.absolutePath,
                    cacheKey = cacheKey,
                    formatText = if (format == "PNG") "PNG (Alpha Channel)" else "JPEG",
                    settingsSummary = "BG: ${backgroundColorHex ?: if (blurBackground) "Blur" else "Transparent"}",
                    isCached = true
                )
            )

            _screenDestination.value = ScreenDestination.ResultScreen(
                title = "Background Cutout",
                toolName = "Background Remover",
                beforeBitmap = currentPhotoBitmap,
                afterBitmap = cutout,
                originalSizeText = String.format("%.1f MB", (currentPhotoBitmap.width * currentPhotoBitmap.height * 2.0) / (1024 * 1024)),
                outputSizeText = String.format("%.1f MB", savedFile.length() / (1024.0 * 1024.0)),
                reductionPercent = 0,
                dimensionsText = "${cutout.width} × ${cutout.height}",
                formatText = if (format == "PNG") "PNG (Alpha Channel)" else "JPEG",
                savedFile = savedFile
            )
            updateCacheSize()
        }
    }

    // Execution: Video Compression (with Room cache check)
    fun processVideoCompression(presetMultiplier: Float, targetResolution: String) {
        viewModelScope.launch {
            val cacheKey = "video_compress_${currentVideoMetadata.fileName}_${currentVideoMetadata.fileSizeBytes}_${(presetMultiplier * 100).toInt()}_${targetResolution}"
            val cached = withContext(Dispatchers.IO) { repository.findByCacheKey(cacheKey) }
            if (cached != null && cached.hasValidFile) {
                _screenDestination.value = ScreenDestination.ResultScreen(
                    title = cached.title,
                    toolName = "Video Compressor",
                    beforeBitmap = currentPhotoBitmap,
                    afterBitmap = currentPhotoBitmap,
                    originalSizeText = cached.readableOriginalSize,
                    outputSizeText = cached.readableOutputSize,
                    reductionPercent = cached.reductionPercent,
                    dimensionsText = cached.outputDimensions,
                    formatText = if (cached.formatText.isNotEmpty()) cached.formatText else "MP4",
                    savedFile = File(cached.outputPath),
                    processingTimeText = "0ms (Instant Cache)"
                )
                return@launch
            }

            _isProcessing.value = true
            _processingTitle.value = "Compressing Video..."

            val result = videoEngine.processVideoCompression(
                metadata = currentVideoMetadata,
                presetMultiplier = presetMultiplier,
                targetResolution = targetResolution
            ) { progress, stage ->
                _processingProgress.value = progress
                _processingStage.value = stage
            }

            _isProcessing.value = false

            val videoFile = withContext(Dispatchers.IO) { createVideoCacheFile(result.title) }

            repository.insertProject(
                ProjectEntity(
                    title = result.title,
                    mediaType = MediaType.VIDEO,
                    toolType = ToolType.COMPRESS_VIDEO,
                    originalSizeBytes = result.originalSize,
                    outputSizeBytes = result.estimatedOutputSize,
                    originalDimensions = currentVideoMetadata.readableDimensions,
                    outputDimensions = result.outputResolution,
                    outputPath = videoFile.absolutePath,
                    cacheKey = cacheKey,
                    formatText = result.format,
                    settingsSummary = "$targetResolution • ${(presetMultiplier * 100).toInt()}%",
                    isCached = true
                )
            )

            _screenDestination.value = ScreenDestination.ResultScreen(
                title = result.title,
                toolName = "Video Compressor",
                beforeBitmap = currentPhotoBitmap,
                afterBitmap = currentPhotoBitmap,
                originalSizeText = String.format("%.1f MB", result.originalSize / (1024.0 * 1024.0)),
                outputSizeText = String.format("%.1f MB", result.estimatedOutputSize / (1024.0 * 1024.0)),
                reductionPercent = result.reductionPercent,
                dimensionsText = result.outputResolution,
                formatText = result.format,
                savedFile = videoFile,
                processingTimeText = "${result.processingTimeSeconds}s"
            )
            updateCacheSize()
        }
    }

    // Execution: Video Enhance (with Sharpen, Brightness, Contrast, 4K & AI pipeline, Room cache)
    fun processVideoEnhance(params: VideoEnhancementParams) {
        viewModelScope.launch {
            val cacheKey = "video_enhance_${currentVideoMetadata.fileName}_${currentVideoMetadata.fileSizeBytes}_" +
                    "${params.sharpen.toInt()}_${params.brightness.toInt()}_${params.contrast.toInt()}_" +
                    "${params.saturation.toInt()}_${params.upscale4k}_${params.fps60}_${params.hdrTone}"

            val cached = withContext(Dispatchers.IO) { repository.findByCacheKey(cacheKey) }
            if (cached != null && cached.hasValidFile) {
                _screenDestination.value = ScreenDestination.ResultScreen(
                    title = cached.title,
                    toolName = "Video Enhance",
                    beforeBitmap = currentPhotoBitmap,
                    afterBitmap = currentPhotoBitmap,
                    originalSizeText = cached.readableOriginalSize,
                    outputSizeText = cached.readableOutputSize,
                    reductionPercent = 0,
                    dimensionsText = cached.outputDimensions,
                    formatText = if (cached.formatText.isNotEmpty()) cached.formatText else "MP4 (4K UHD)",
                    savedFile = File(cached.outputPath),
                    processingTimeText = "0ms (Instant Cache)"
                )
                return@launch
            }

            _isProcessing.value = true
            _processingTitle.value = "Enhancing Video..."

            val result = videoEngine.processVideoEnhance(
                metadata = currentVideoMetadata,
                params = params
            ) { progress, stage ->
                _processingProgress.value = progress
                _processingStage.value = stage
            }

            _isProcessing.value = false

            val videoFile = withContext(Dispatchers.IO) { createVideoCacheFile(result.title) }

            repository.insertProject(
                ProjectEntity(
                    title = result.title,
                    mediaType = MediaType.VIDEO,
                    toolType = ToolType.VIDEO_ENHANCE,
                    originalSizeBytes = result.originalSize,
                    outputSizeBytes = result.estimatedOutputSize,
                    originalDimensions = currentVideoMetadata.readableDimensions,
                    outputDimensions = result.outputResolution,
                    outputPath = videoFile.absolutePath,
                    cacheKey = cacheKey,
                    formatText = result.format,
                    settingsSummary = "Sharpen: ${params.sharpen.toInt()} • 4K: ${params.upscale4k}",
                    isCached = true
                )
            )

            _screenDestination.value = ScreenDestination.ResultScreen(
                title = "Enhanced Video",
                toolName = "Video Enhance",
                beforeBitmap = currentPhotoBitmap,
                afterBitmap = currentPhotoBitmap,
                originalSizeText = currentVideoMetadata.readableSize,
                outputSizeText = String.format("%.1f MB", result.estimatedOutputSize / (1024.0 * 1024.0)),
                reductionPercent = 0,
                dimensionsText = result.outputResolution,
                formatText = result.format,
                savedFile = videoFile,
                processingTimeText = "${result.processingTimeSeconds}s"
            )
            updateCacheSize()
        }
    }

    // Overload for backwards compatibility
    fun processVideoEnhance(upscale4k: Boolean, fps60: Boolean, hdrTone: Boolean, stabilize: Boolean) {
        processVideoEnhance(
            VideoEnhancementParams(
                sharpen = 40f,
                brightness = 0f,
                contrast = 15f,
                saturation = 15f,
                upscale4k = upscale4k,
                fps60 = fps60,
                hdrTone = hdrTone,
                stabilize = stabilize
            )
        )
    }

    fun cancelProcessing() {
        _isProcessing.value = false
    }

    fun deleteProject(id: Long) {
        viewModelScope.launch {
            repository.deleteProjectById(id)
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            repository.clearAll()
        }
    }

    fun shareResult(file: File?) {
        if (file == null || !file.exists()) return
        try {
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = if (file.extension == "png") "image/png" else "image/jpeg"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(Intent.createChooser(intent, "Share enhanced media").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
        } catch (e: Exception) {
            // Sharing intent handling
        }
    }

    fun openProject(project: ProjectEntity) {
        val file = if (project.outputPath.isNotEmpty()) File(project.outputPath) else null
        val bitmap = if (file != null && file.exists() && project.mediaType == MediaType.IMAGE) {
            BitmapFactory.decodeFile(file.absolutePath)
        } else {
            currentPhotoBitmap
        }

        _screenDestination.value = ScreenDestination.ResultScreen(
            title = project.title,
            toolName = project.toolType.displayName,
            beforeBitmap = currentPhotoBitmap,
            afterBitmap = bitmap,
            originalSizeText = project.readableOriginalSize,
            outputSizeText = project.readableOutputSize,
            reductionPercent = project.reductionPercent,
            dimensionsText = project.outputDimensions,
            formatText = if (project.formatText.isNotEmpty()) project.formatText else (if (project.mediaType == MediaType.IMAGE) "IMAGE / HDR" else "MP4 / H.264"),
            processingTimeText = if (project.isCached && project.hasValidFile) "Instant (Cached)" else "Saved",
            savedFile = file
        )
    }

    fun clearCache() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                context.cacheDir.listFiles()?.forEach { it.delete() }
            } catch (e: Exception) {
                // Handle deletion
            }
            updateCacheSize()
        }
    }

    private fun updateCacheSize() {
        viewModelScope.launch(Dispatchers.IO) {
            val size = context.cacheDir.listFiles()?.sumOf { it.length() } ?: 0L
            _cacheSize.value = if (size > 1024 * 1024) String.format("%.1f MB", size / (1024.0 * 1024.0))
            else String.format("%.0f KB", size / 1024.0)
        }
    }
}
