package com.example.data.db

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.MediaType
import com.example.data.model.ToolType
import kotlinx.coroutines.flow.Flow

/**
 * Data Access Object providing reactive queries and cache lookups for processed media.
 */
@Dao
interface ProjectDao {
    @Query("SELECT * FROM projects ORDER BY timestamp DESC")
    fun getAllProjects(): Flow<List<ProjectEntity>>

    @Query("SELECT * FROM projects WHERE mediaType = :type ORDER BY timestamp DESC")
    fun getProjectsByType(type: MediaType): Flow<List<ProjectEntity>>

    @Query("SELECT * FROM projects ORDER BY timestamp DESC LIMIT :limit")
    fun getRecentProjects(limit: Int = 5): Flow<List<ProjectEntity>>

    @Query("SELECT * FROM projects WHERE toolType = :toolType ORDER BY timestamp DESC LIMIT :limit")
    fun getRecentByTool(toolType: ToolType, limit: Int = 10): Flow<List<ProjectEntity>>

    @Query("SELECT * FROM projects WHERE outputPath != '' ORDER BY timestamp DESC")
    fun getCachedProjectsWithFiles(): Flow<List<ProjectEntity>>

    @Query("SELECT * FROM projects WHERE id = :id LIMIT 1")
    suspend fun getProjectById(id: Long): ProjectEntity?

    @Query("SELECT * FROM projects WHERE cacheKey = :key LIMIT 1")
    suspend fun findByCacheKey(key: String): ProjectEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProject(project: ProjectEntity): Long

    @Update
    suspend fun updateProject(project: ProjectEntity)

    @Delete
    suspend fun deleteProject(project: ProjectEntity)

    @Query("DELETE FROM projects WHERE id = :id")
    suspend fun deleteProjectById(id: Long)

    @Query("DELETE FROM projects")
    suspend fun clearAll()

    @Query("SELECT COUNT(*) FROM projects")
    suspend fun getCount(): Int

    @Query("SELECT SUM(outputSizeBytes) FROM projects WHERE outputPath != ''")
    suspend fun getTotalCachedSizeBytes(): Long?
}
