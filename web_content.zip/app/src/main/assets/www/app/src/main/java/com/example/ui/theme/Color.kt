package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Brand Colors
val EnhancePrimary = Color(0xFF4F46E5) // Indigo 600
val EnhancePrimaryVariant = Color(0xFF4338CA) // Indigo 700
val EnhancePrimaryLight = Color(0xFF818CF8) // Indigo 400
val EnhanceSecondary = Color(0xFF06B6D4) // Cyan 500
val EnhanceTertiary = Color(0xFF8B5CF6) // Purple 500

// Elegant Dark Specific Accents
val ElegantDarkBg = Color(0xFF05060B) // Ultra-deep obsidian
val ElegantDarkNavBg = Color(0xFF0A0C14) // Deep navy-black for navigation
val ElegantDarkSurface = Color(0xFF0E1320) // Slate-900 blended surface card
val ElegantDarkBorder = Color(0xFF1E293B) // Slate 800 border
val ElegantDarkBorderSubtle = Color(0x801E293B) // Slate 800 50% opacity
val ElegantDarkTextPrimary = Color(0xFFF1F5F9) // Slate 100
val ElegantDarkTextSecondary = Color(0xFF94A3B8) // Slate 400
val ElegantDarkTextMuted = Color(0xFF64748B) // Slate 500

// Tool Specific Accent Tints (from Design spec)
val AccentPhoto = Color(0xFF818CF8) // Indigo 400
val AccentVideo = Color(0xFFC084FC) // Purple 400
val AccentCompress = Color(0xFF34D399) // Emerald 400
val AccentCutout = Color(0xFF60A5FA) // Blue 400

// Light Palette
val BackgroundLight = Color(0xFFF8FAFC) // Slate 50
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFF1F5F9) // Slate 100
val OutlineLight = Color(0xFFE2E8F0) // Slate 200
val TextPrimaryLight = Color(0xFF0F172A) // Slate 900
val TextSecondaryLight = Color(0xFF64748B) // Slate 500

// Dark Palette (Aligned to Elegant Dark)
val BackgroundDark = Color(0xFF05060B) // Deep obsidian #05060B
val SurfaceDark = Color(0xFF0E1320) // Slate 900 surface
val SurfaceVariantDark = Color(0xFF1E293B) // Slate 800
val OutlineDark = Color(0xFF1E293B) // Slate 800
val TextPrimaryDark = Color(0xFFF1F5F9) // Slate 100
val TextSecondaryDark = Color(0xFF94A3B8) // Slate 400

// Status Colors
val StatusSuccess = Color(0xFF10B981) // Emerald 500
val StatusWarning = Color(0xFFF59E0B) // Amber 500
val StatusError = Color(0xFFEF4444) // Red 500
val StatusInfo = Color(0xFF3B82F6) // Blue 500
