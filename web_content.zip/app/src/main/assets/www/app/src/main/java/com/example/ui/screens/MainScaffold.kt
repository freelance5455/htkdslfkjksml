package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import com.example.data.db.ProjectEntity
import com.example.data.model.ToolType
import com.example.ui.components.AppDestination
import com.example.ui.components.BottomNavigationBar
import com.example.ui.components.EnhanceXTopBar
import com.example.ui.theme.ThemeMode

/**
 * State holder for [MainScaffold], managing the current navigation destination
 * and tab stack history across configuration changes.
 */
class MainScaffoldState(
    initialDestination: AppDestination = AppDestination.HOME
) {
    var currentDestination by mutableStateOf(initialDestination)
        private set

    fun navigateTo(destination: AppDestination) {
        currentDestination = destination
    }

    /**
     * Handles back navigation within the main tab scaffold.
     * Returns true if back was handled (i.e. popped to HOME from another tab), false otherwise.
     */
    fun navigateBack(): Boolean {
        if (currentDestination != AppDestination.HOME) {
            currentDestination = AppDestination.HOME
            return true
        }
        return false
    }

    companion object {
        val Saver: Saver<MainScaffoldState, String> = Saver(
            save = { it.currentDestination.name },
            restore = { name ->
                val dest = runCatching { AppDestination.valueOf(name) }.getOrDefault(AppDestination.HOME)
                MainScaffoldState(dest)
            }
        )
    }
}

/**
 * Creates and remembers a [MainScaffoldState] instance that survives configuration changes.
 */
@Composable
fun rememberMainScaffoldState(
    initialDestination: AppDestination = AppDestination.HOME
): MainScaffoldState {
    return rememberSaveable(saver = MainScaffoldState.Saver) {
        MainScaffoldState(initialDestination)
    }
}

/**
 * Main application scaffold component using Material 3, hosting the top application bar,
 * the reusable [BottomNavigationBar], and state management to switch cleanly between
 * Home, Tools, History, and Settings screens with predictive back support.
 *
 * This overload is self-managed using [MainScaffoldState].
 */
@Composable
fun MainScaffold(
    projects: List<ProjectEntity>,
    currentThemeMode: ThemeMode,
    cacheSizeText: String,
    isCloudActive: Boolean,
    onSelectTool: (ToolType) -> Unit,
    onOpenProject: (ProjectEntity) -> Unit,
    onDeleteProject: (Long) -> Unit,
    onClearAllHistory: () -> Unit,
    onSelectThemeMode: (ThemeMode) -> Unit,
    onClearCache: () -> Unit,
    modifier: Modifier = Modifier,
    scaffoldState: MainScaffoldState = rememberMainScaffoldState()
) {
    MainScaffold(
        currentDestination = scaffoldState.currentDestination,
        onNavigate = { scaffoldState.navigateTo(it) },
        projects = projects,
        currentThemeMode = currentThemeMode,
        cacheSizeText = cacheSizeText,
        isCloudActive = isCloudActive,
        onSelectTool = onSelectTool,
        onOpenProject = onOpenProject,
        onDeleteProject = onDeleteProject,
        onClearAllHistory = onClearAllHistory,
        onSelectThemeMode = onSelectThemeMode,
        onClearCache = onClearCache,
        modifier = modifier
    )
}

/**
 * Controlled overload of [MainScaffold], driven by external state (e.g. ViewModel or NavHost).
 *
 * @param currentDestination The currently active primary screen destination.
 * @param onNavigate Invoked when a tab or action navigates to a new destination.
 */
@Composable
fun MainScaffold(
    currentDestination: AppDestination,
    onNavigate: (AppDestination) -> Unit,
    projects: List<ProjectEntity>,
    currentThemeMode: ThemeMode,
    cacheSizeText: String,
    isCloudActive: Boolean,
    onSelectTool: (ToolType) -> Unit,
    onOpenProject: (ProjectEntity) -> Unit,
    onDeleteProject: (Long) -> Unit,
    onClearAllHistory: () -> Unit,
    onSelectThemeMode: (ThemeMode) -> Unit,
    onClearCache: () -> Unit,
    modifier: Modifier = Modifier
) {
    // Intercept system Back press on secondary tabs to return to HOME
    BackHandler(enabled = currentDestination != AppDestination.HOME) {
        onNavigate(AppDestination.HOME)
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .testTag("main_scaffold"),
        containerColor = Color(0xFF05060B),
        topBar = {
            EnhanceXTopBar(
                currentDestination = currentDestination,
                isCloudActive = isCloudActive,
                onOpenSettings = { onNavigate(AppDestination.SETTINGS) }
            )
        },
        bottomBar = {
            BottomNavigationBar(
                currentDestination = currentDestination,
                onNavigate = onNavigate
            )
        }
    ) { innerPadding ->
        val contentModifier = Modifier
            .fillMaxSize()
            .padding(innerPadding)

        // Smooth visual crossfade between primary sections
        AnimatedContent(
            targetState = currentDestination,
            transitionSpec = {
                fadeIn(animationSpec = tween(180)) togetherWith fadeOut(animationSpec = tween(120))
            },
            label = "screen_section_transition",
            modifier = Modifier.fillMaxSize()
        ) { targetDestination ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF05060B))
            ) {
                when (targetDestination) {
                    AppDestination.HOME -> {
                        HomeScreen(
                            recentProjects = projects,
                            onSelectTool = onSelectTool,
                            onOpenProject = onOpenProject,
                            onViewAllHistory = { onNavigate(AppDestination.HISTORY) },
                            modifier = contentModifier
                        )
                    }

                    AppDestination.TOOLS -> {
                        ToolsScreen(
                            onSelectTool = onSelectTool,
                            modifier = contentModifier
                        )
                    }

                    AppDestination.HISTORY -> {
                        HistoryScreen(
                            projects = projects,
                            onOpenProject = onOpenProject,
                            onDeleteProject = onDeleteProject,
                            onClearAll = onClearAllHistory,
                            modifier = contentModifier
                        )
                    }

                    AppDestination.SETTINGS -> {
                        SettingsScreen(
                            currentThemeMode = currentThemeMode,
                            onSelectThemeMode = onSelectThemeMode,
                            cacheSizeText = cacheSizeText,
                            onClearCache = onClearCache,
                            isCloudActive = isCloudActive,
                            modifier = contentModifier
                        )
                    }
                }
            }
        }
    }
}
