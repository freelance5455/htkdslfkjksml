package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("EnhanceX", appName)
  }

  @Test
  fun `verify navigation destinations`() {
    val destinations = com.example.ui.components.AppDestination.values()
    assertEquals(4, destinations.size)
    assertEquals("Home", destinations[0].title)
    assertEquals("Tools", destinations[1].title)
    assertEquals("History", destinations[2].title)
    assertEquals("Settings", destinations[3].title)
  }

  @Test
  fun `verify MainScaffoldState destination switching and back navigation`() {
    val state = com.example.ui.screens.MainScaffoldState(com.example.ui.components.AppDestination.HOME)
    assertEquals(com.example.ui.components.AppDestination.HOME, state.currentDestination)

    // Switch to Tools
    state.navigateTo(com.example.ui.components.AppDestination.TOOLS)
    assertEquals(com.example.ui.components.AppDestination.TOOLS, state.currentDestination)

    // Back from Tools returns to HOME
    val backHandled1 = state.navigateBack()
    org.junit.Assert.assertTrue(backHandled1)
    assertEquals(com.example.ui.components.AppDestination.HOME, state.currentDestination)

    // Switch to History
    state.navigateTo(com.example.ui.components.AppDestination.HISTORY)
    assertEquals(com.example.ui.components.AppDestination.HISTORY, state.currentDestination)

    // Switch to Settings
    state.navigateTo(com.example.ui.components.AppDestination.SETTINGS)
    assertEquals(com.example.ui.components.AppDestination.SETTINGS, state.currentDestination)

    // Back from Settings returns to HOME
    val backHandled2 = state.navigateBack()
    org.junit.Assert.assertTrue(backHandled2)
    assertEquals(com.example.ui.components.AppDestination.HOME, state.currentDestination)

    // Back on HOME returns false (let system exit app)
    val backHandled3 = state.navigateBack()
    org.junit.Assert.assertFalse(backHandled3)
    assertEquals(com.example.ui.components.AppDestination.HOME, state.currentDestination)
  }

  @Test
  fun `verify VideoEnhancementParams and Photo EnhancementParams initialization`() {
    val videoParams = com.example.service.VideoEnhancementParams(
      sharpen = 50f,
      brightness = 5f,
      contrast = 20f,
      saturation = 15f,
      upscale4k = true,
      fps60 = true,
      hdrTone = true,
      stabilize = false,
      aiDetailRecovery = true
    )
    assertEquals(50f, videoParams.sharpen)
    assertEquals(5f, videoParams.brightness)
    assertEquals(20f, videoParams.contrast)
    org.junit.Assert.assertTrue(videoParams.upscale4k)
    org.junit.Assert.assertTrue(videoParams.fps60)
    org.junit.Assert.assertTrue(videoParams.aiDetailRecovery)

    val photoParams = com.example.service.EnhancementParams(
      autoEnhance = true,
      brightness = 10f,
      contrast = 15f,
      sharpness = 45f,
      upscaleFactor = 2,
      presetName = "Vivid HD"
    )
    org.junit.Assert.assertTrue(photoParams.autoEnhance)
    assertEquals(2, photoParams.upscaleFactor)
    assertEquals("Vivid HD", photoParams.presetName)
  }

  @Test
  fun `verify VideoProcessingEngine compression estimation logic`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val engine = com.example.service.VideoProcessingEngine(context)
    val sampleMeta = engine.getSampleVideoMetadata()
    org.junit.Assert.assertTrue(sampleMeta.fileSizeBytes > 0)
    assertEquals(3840, sampleMeta.width)
    assertEquals(2160, sampleMeta.height)

    val (estSize, reduction) = engine.calculateEstimatedCompression(
      originalSize = 100_000_000L,
      presetMultiplier = 0.5f,
      targetResolution = "1080p"
    )
    org.junit.Assert.assertTrue(estSize < 100_000_000L)
    org.junit.Assert.assertTrue(reduction > 0)
  }

  @Test
  fun `verify ProjectEntity caching properties and file validity`() {
    val tempFile = java.io.File.createTempFile("test_cached_file", ".jpg")
    try {
      tempFile.writeBytes(ByteArray(2048))

      val entityWithValidFile = com.example.data.db.ProjectEntity(
        id = 1L,
        title = "Enhanced_Photo_1.jpg",
        mediaType = com.example.data.model.MediaType.IMAGE,
        toolType = com.example.data.model.ToolType.PHOTO_ENHANCE,
        originalSizeBytes = 5_000_000L,
        outputSizeBytes = 2_000_000L,
        originalDimensions = "1920 × 1080",
        outputDimensions = "3840 × 2160",
        outputPath = tempFile.absolutePath,
        cacheKey = "photo_enhance_1920x1080_4K",
        formatText = "JPEG (High Quality)",
        isCached = true
      )

      org.junit.Assert.assertTrue(entityWithValidFile.hasValidFile)
      org.junit.Assert.assertTrue(entityWithValidFile.isCached)
      assertEquals("photo_enhance_1920x1080_4K", entityWithValidFile.cacheKey)
      assertEquals(60, entityWithValidFile.reductionPercent)
      assertEquals("4.8 MB", entityWithValidFile.readableOriginalSize)
      assertEquals("1.9 MB", entityWithValidFile.readableOutputSize)

      val entityWithMissingFile = entityWithValidFile.copy(
        outputPath = "/non_existent_path/fake.jpg"
      )
      org.junit.Assert.assertFalse(entityWithMissingFile.hasValidFile)
    } finally {
      tempFile.delete()
    }
  }

  @Test
  fun `verify Room Database DAO caching and cacheKey queries`() = kotlinx.coroutines.runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val inMemoryDb = androidx.room.Room.inMemoryDatabaseBuilder(
      context,
      com.example.data.db.AppDatabase::class.java
    ).allowMainThreadQueries().build()

    try {
      val dao = inMemoryDb.projectDao()
      assertEquals(0, dao.getCount())

      val project1 = com.example.data.db.ProjectEntity(
        title = "Cached_HDR.jpg",
        mediaType = com.example.data.model.MediaType.IMAGE,
        toolType = com.example.data.model.ToolType.PHOTO_ENHANCE,
        originalSizeBytes = 4_000_000L,
        outputSizeBytes = 1_500_000L,
        originalDimensions = "1000 × 1000",
        outputDimensions = "2000 × 2000",
        outputPath = "/tmp/cached_hdr.jpg",
        cacheKey = "photo_enhance_1000x1000_2x_hdr",
        formatText = "JPEG",
        isCached = true
      )

      val id = dao.insertProject(project1)
      org.junit.Assert.assertTrue(id > 0)
      assertEquals(1, dao.getCount())

      // Verify query by cacheKey
      val cached = dao.findByCacheKey("photo_enhance_1000x1000_2x_hdr")
      org.junit.Assert.assertNotNull(cached)
      assertEquals("Cached_HDR.jpg", cached?.title)
      assertEquals("/tmp/cached_hdr.jpg", cached?.outputPath)
      assertEquals("photo_enhance_1000x1000_2x_hdr", cached?.cacheKey)

      // Query by non-existent cacheKey returns null
      val nonExistent = dao.findByCacheKey("non_existent_key")
      org.junit.Assert.assertNull(nonExistent)

      // Verify cache size aggregation
      val totalBytes = dao.getTotalCachedSizeBytes()
      assertEquals(1_500_000L, totalBytes)
    } finally {
      inMemoryDb.close()
    }
  }
}
