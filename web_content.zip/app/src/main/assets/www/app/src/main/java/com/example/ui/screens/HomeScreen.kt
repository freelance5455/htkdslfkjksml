package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Brush
import androidx.compose.material.icons.filled.Compress
import androidx.compose.material.icons.filled.Gif
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.PhotoFilter
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Transform
import androidx.compose.material.icons.filled.VideoFile
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.db.ProjectEntity
import com.example.data.model.MediaType
import com.example.data.model.ToolType
import com.example.ui.components.SecondaryToolItem
import com.example.ui.components.ToolCard

/**
 * Scrollable dashboard presenting the EnhanceX app branding header, welcoming hero section,
 * and a 2x2 grid of primary [ToolCard] actions ('Photo Enhance', 'Video Enhance',
 * 'Compress Video', and 'Remove Background').
 */
@Composable
fun HomeScreen(
    recentProjects: List<ProjectEntity>,
    onSelectTool: (ToolType) -> Unit,
    onOpenProject: (ProjectEntity) -> Unit,
    onViewAllHistory: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF05060B))
            .verticalScroll(scrollState)
            .padding(horizontal = 20.dp)
            .testTag("home_screen")
    ) {
        Spacer(modifier = Modifier.height(12.dp))

        // App Branding Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp)
                .testTag("home_branding_header"),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(38.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFF4F46E5))
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.ic_enhancex_logo),
                        contentDescription = "EnhanceX Logo",
                        modifier = Modifier.size(30.dp)
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "Enhance",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFF1F5F9),
                            letterSpacing = (-0.5).sp
                        )
                        Text(
                            text = "X",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF818CF8),
                            letterSpacing = (-0.5).sp
                        )
                    }
                    Text(
                        text = "AI Media Studio",
                        fontSize = 11.sp,
                        color = Color(0xFF64748B),
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            // On-Device Privacy Pill
            Surface(
                shape = CircleShape,
                color = Color(0xFF1E293B),
                border = BorderStroke(1.dp, Color(0x661E293B))
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(7.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF10B981))
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "On-Device",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF94A3B8)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Welcoming Hero Section
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color(0xFF0E1320), Color(0xFF090D17))
                    )
                )
                .border(BorderStroke(1.dp, Color(0x661E293B)), RoundedCornerShape(24.dp))
                .padding(20.dp)
                .testTag("hero_banner")
        ) {
            // Pill tag
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = Color(0xFF1E293B),
                border = BorderStroke(1.dp, Color(0x804F46E5))
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = Color(0xFF818CF8),
                        modifier = Modifier.size(13.dp)
                    )
                    Spacer(modifier = Modifier.width(5.dp))
                    Text(
                        text = "LIGHTWEIGHT & PRIVATE",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF818CF8),
                        letterSpacing = 0.5.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Main Title
            Text(
                text = "Make your\nmedia better.",
                fontSize = 32.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFFF1F5F9),
                lineHeight = 38.sp,
                letterSpacing = (-0.5).sp
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Welcoming Subtitle
            Text(
                text = "Welcome to your all-in-one studio. Enhance, compress, and transform your photos and videos with high-performance on-device AI.",
                fontSize = 13.sp,
                color = Color(0xFF94A3B8),
                lineHeight = 19.sp
            )

            Spacer(modifier = Modifier.height(18.dp))

            // Quick launch buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = { onSelectTool(ToolType.PHOTO_ENHANCE) },
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4F46E5)),
                    modifier = Modifier
                        .weight(1f)
                        .height(46.dp)
                        .testTag("quick_photo_enhance_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.PhotoCamera,
                        contentDescription = null,
                        modifier = Modifier.size(17.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Enhance Photo",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Button(
                    onClick = { onSelectTool(ToolType.COMPRESS_VIDEO) },
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                    border = BorderStroke(1.dp, Color(0x661E293B)),
                    modifier = Modifier
                        .weight(1f)
                        .height(46.dp)
                        .testTag("quick_compress_video_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Compress,
                        contentDescription = null,
                        tint = Color(0xFF34D399),
                        modifier = Modifier.size(17.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Compress Video",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFFF1F5F9)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(26.dp))

        // Section Title: Primary Actions
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "PRIMARY ACTIONS",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF64748B),
                letterSpacing = 0.8.sp
            )
            Text(
                text = "Tap to launch",
                fontSize = 11.sp,
                color = Color(0xFF475569)
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // 2x2 Grid of ToolCard Components for 'Photo Enhance', 'Video Enhance', 'Compress Video', and 'Remove Background'
        Row(modifier = Modifier.fillMaxWidth()) {
            ToolCard(
                toolType = ToolType.PHOTO_ENHANCE,
                icon = Icons.Default.PhotoFilter,
                title = "Photo Enhance",
                description = "Upscale & AI Denoise",
                badgeText = "AI 4K",
                badgeColor = Color(0xFF818CF8),
                accentGradient = listOf(Color(0xFF818CF8)),
                onClick = { onSelectTool(ToolType.PHOTO_ENHANCE) },
                modifier = Modifier.weight(1f)
            )

            Spacer(modifier = Modifier.width(12.dp))

            ToolCard(
                toolType = ToolType.VIDEO_ENHANCE,
                icon = Icons.Default.Videocam,
                title = "Video Enhance",
                description = "4K AI Upscaling",
                badgeText = "AI PRO",
                badgeColor = Color(0xFFC084FC),
                accentGradient = listOf(Color(0xFFC084FC)),
                onClick = { onSelectTool(ToolType.VIDEO_ENHANCE) },
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        Row(modifier = Modifier.fillMaxWidth()) {
            ToolCard(
                toolType = ToolType.COMPRESS_VIDEO,
                icon = Icons.Default.Compress,
                title = "Compress Video",
                description = "Shrink size up to 70%",
                badgeText = "FAST",
                badgeColor = Color(0xFF34D399),
                accentGradient = listOf(Color(0xFF34D399)),
                onClick = { onSelectTool(ToolType.COMPRESS_VIDEO) },
                modifier = Modifier.weight(1f)
            )

            Spacer(modifier = Modifier.width(12.dp))

            ToolCard(
                toolType = ToolType.REMOVE_BACKGROUND,
                icon = Icons.Default.PhotoCamera,
                title = "Remove Background",
                description = "Instant Cutout & PNG",
                badgeText = "AI MAGIC",
                badgeColor = Color(0xFF60A5FA),
                accentGradient = listOf(Color(0xFF60A5FA)),
                onClick = { onSelectTool(ToolType.REMOVE_BACKGROUND) },
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(28.dp))

        // Recent Projects Section
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "RECENT PROJECTS",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF64748B),
                letterSpacing = 0.8.sp
            )
            Text(
                text = "View All",
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFF818CF8),
                modifier = Modifier
                    .clickable(onClick = onViewAllHistory)
                    .padding(vertical = 4.dp, horizontal = 2.dp)
                    .testTag("home_view_all_history")
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (recentProjects.isNotEmpty()) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                recentProjects.take(3).forEach { project ->
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF0E1320)),
                        border = BorderStroke(1.dp, Color(0x801E293B)),
                        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onOpenProject(project) }
                            .testTag("recent_project_${project.id}")
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color(0xFF1E293B))
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(
                                            Brush.linearGradient(
                                                listOf(Color(0x33818CF8), Color(0x33C084FC))
                                            )
                                        )
                                )
                                Icon(
                                    imageVector = if (project.mediaType == MediaType.IMAGE) Icons.Default.Image else Icons.Default.VideoFile,
                                    contentDescription = null,
                                    tint = Color(0xFF94A3B8),
                                    modifier = Modifier.size(20.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(14.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = project.title,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = Color(0xFFF1F5F9),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f, fill = false)
                                    )
                                    if (project.isCached && project.hasValidFile) {
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Surface(
                                            shape = RoundedCornerShape(4.dp),
                                            color = Color(0x3310B981)
                                        ) {
                                            Text(
                                                text = "Cached",
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color(0xFF34D399),
                                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                            )
                                        }
                                    }
                                }
                                Spacer(modifier = Modifier.height(3.dp))
                                Text(
                                    text = "${project.toolType.displayName} • ${project.readableOutputSize}${if (project.reductionPercent > 0) " (-${project.reductionPercent}%)" else ""}",
                                    fontSize = 11.sp,
                                    color = Color(0xFF64748B)
                                )
                            }

                            Icon(
                                imageVector = Icons.Default.ArrowForward,
                                contentDescription = "Open",
                                tint = Color(0xFF475569),
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        } else {
            // Elegant placeholder matching Design HTML
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                // Item 1
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0E1320)),
                    border = BorderStroke(1.dp, Color(0x801E293B)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSelectTool(ToolType.PHOTO_ENHANCE) }
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(46.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFF1E293B))
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(
                                        Brush.linearGradient(
                                            listOf(Color(0x33818CF8), Color(0x33C084FC))
                                        )
                                    )
                            )
                            Icon(
                                imageVector = Icons.Default.Image,
                                contentDescription = null,
                                tint = Color(0xFF818CF8),
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(14.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Sample_Landscape_Photo.jpg",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Medium,
                                color = Color(0xFFF1F5F9),
                                maxLines = 1
                            )
                            Spacer(modifier = Modifier.height(3.dp))
                            Text(
                                text = "Photo Enhance • 2.4MB • Tap to try",
                                fontSize = 11.sp,
                                color = Color(0xFF64748B)
                            )
                        }

                        Icon(
                            imageVector = Icons.Default.ArrowForward,
                            contentDescription = null,
                            tint = Color(0xFF475569),
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                // Item 2
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0E1320).copy(alpha = 0.7f)),
                    border = BorderStroke(1.dp, Color(0x501E293B)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSelectTool(ToolType.COMPRESS_VIDEO) }
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(46.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFF1E293B))
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(
                                        Brush.linearGradient(
                                            listOf(Color(0x3334D399), Color(0x3306B6D4))
                                        )
                                    )
                            )
                            Icon(
                                imageVector = Icons.Default.VideoFile,
                                contentDescription = null,
                                tint = Color(0xFF34D399),
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(14.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Sample_Travel_Clip.mp4",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Medium,
                                color = Color(0xFFF1F5F9),
                                maxLines = 1
                            )
                            Spacer(modifier = Modifier.height(3.dp))
                            Text(
                                text = "Compress Video • 42MB • Tap to try",
                                fontSize = 11.sp,
                                color = Color(0xFF64748B)
                            )
                        }

                        Icon(
                            imageVector = Icons.Default.ArrowForward,
                            contentDescription = null,
                            tint = Color(0xFF475569),
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(28.dp))

        // More Media Utilities
        Text(
            text = "MORE UTILITIES",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF64748B),
            letterSpacing = 0.8.sp
        )

        Spacer(modifier = Modifier.height(12.dp))

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            SecondaryToolItem(
                toolType = ToolType.IMAGE_COMPRESS,
                icon = Icons.Default.Compress,
                title = "Image Compressor",
                badgeText = "JPG/PNG/WebP",
                onClick = { onSelectTool(ToolType.IMAGE_COMPRESS) }
            )
            SecondaryToolItem(
                toolType = ToolType.RESIZE_IMAGE,
                icon = Icons.Default.AspectRatio,
                title = "Resize Image",
                badgeText = "Presets & Custom",
                onClick = { onSelectTool(ToolType.RESIZE_IMAGE) }
            )
            SecondaryToolItem(
                toolType = ToolType.IMAGE_CONVERT,
                icon = Icons.Default.Transform,
                title = "Image Converter",
                badgeText = "Fast Format Switch",
                onClick = { onSelectTool(ToolType.IMAGE_CONVERT) }
            )
            SecondaryToolItem(
                toolType = ToolType.VIDEO_TO_GIF,
                icon = Icons.Default.Gif,
                title = "Video to GIF",
                badgeText = "Trim & FPS",
                onClick = { onSelectTool(ToolType.VIDEO_TO_GIF) }
            )
            SecondaryToolItem(
                toolType = ToolType.OBJECT_REMOVE,
                icon = Icons.Default.Brush,
                title = "Object Remover",
                badgeText = "Smart Inpainting",
                onClick = { onSelectTool(ToolType.OBJECT_REMOVE) }
            )
            SecondaryToolItem(
                toolType = ToolType.PHOTO_RESTORE,
                icon = Icons.Default.History,
                title = "Photo Restoration",
                badgeText = "Old Photo Fix",
                onClick = { onSelectTool(ToolType.PHOTO_RESTORE) }
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Privacy & On-Device Security Info Card
        Card(
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0E1320)),
            border = BorderStroke(1.dp, Color(0x661E293B)),
            elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF1E293B))
                ) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = "Privacy",
                        tint = Color(0xFF818CF8),
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(14.dp))
                Column {
                    Text(
                        text = "100% On-Device Privacy",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFFF1F5F9)
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "Your photos and videos are processed locally using your device's hardware. Nothing leaves your device without consent.",
                        fontSize = 11.sp,
                        color = Color(0xFF64748B),
                        lineHeight = 16.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(36.dp))
    }
}
