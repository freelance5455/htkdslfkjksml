package com.example.data.db

import com.example.data.model.MediaType
import com.example.data.model.ToolType
import kotlinx.coroutines.flow.Flow

/**
 * Repository mediating between the local Room database cache and ViewModel/UI layers.
 */
class ProjectRepository(private val projectDao: ProjectDao) {
    val allProjects: Flow<List<ProjectEntity>> = projectDao.getAllProjects()

    fun getProjectsByType(type: MediaType): Flow<List<ProjectEntity>> =
        projectDao.getProjectsByType(type)

    fun getRecentProjects(limit: Int = 5): Flow<List<ProjectEntity>> =
        projectDao.getRecentProjects(limit)

    fun getRecentByTool(toolType: ToolType, limit: Int = 10): Flow<List<ProjectEntity>> =
        projectDao.getRecentByTool(toolType, limit)

    fun getCachedProjectsWithFiles(): Flow<List<ProjectEntity>> =
        projectDao.getCachedProjectsWithFiles()

    suspend fun findByCacheKey(key: String): ProjectEntity? =
        projectDao.findByCacheKey(key)

    suspend fun getProjectById(id: Long): ProjectEntity? =
        projectDao.getProjectById(id)

    suspend fun insertProject(project: ProjectEntity): Long =
        projectDao.insertProject(project)

    suspend fun updateProject(project: ProjectEntity) =
        projectDao.updateProject(project)

    suspend fun deleteProject(project: ProjectEntity) =
        projectDao.deleteProject(project)

    suspend fun deleteProjectById(id: Long) =
        projectDao.deleteProjectById(id)

    suspend fun clearAll() =
        projectDao.clearAll()

    suspend fun getCount(): Int =
        projectDao.getCount()

    suspend fun getTotalCachedSizeBytes(): Long =
        projectDao.getTotalCachedSizeBytes() ?: 0L
}
