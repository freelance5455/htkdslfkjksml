package com.example

import android.graphics.BitmapFactory
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import com.example.data.model.MediaType
import com.example.data.model.ToolType
import com.example.ui.components.AppDestination
import com.example.ui.components.BottomNavigationBar
import com.example.ui.components.EnhanceXBottomBar
import com.example.ui.components.EnhanceXTopBar
import com.example.ui.components.FilePickerSheet
import com.example.ui.components.ProcessingDialog
import com.example.ui.components.ResultView
import com.example.ui.screens.BackgroundRemovalScreen
import com.example.ui.screens.MainScaffold
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.ImageCompressorScreen
import com.example.ui.screens.ImageResizerScreen
import com.example.ui.screens.PhotoEnhanceScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.ToolsScreen
import com.example.ui.screens.VideoCompressorScreen
import com.example.ui.screens.VideoEnhanceScreen
import com.example.ui.theme.EnhanceXTheme
import com.example.viewmodel.EnhanceXViewModel
import com.example.viewmodel.ScreenDestination
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val viewModel: EnhanceXViewModel by viewModels()

    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val themeMode by viewModel.themeMode.collectAsState()
            val navDestination by viewModel.currentNavDestination.collectAsState()
            val screenDestination by viewModel.screenDestination.collectAsState()
            val isProcessing by viewModel.isProcessing.collectAsState()
            val progressPercent by viewModel.processingProgress.collectAsState()
            val stageText by viewModel.processingStage.collectAsState()
            val processingTitle by viewModel.processingTitle.collectAsState()
            val showPickerSheet by viewModel.showPickerSheet.collectAsState()
            val targetMediaType by viewModel.targetPickerMediaType.collectAsState()
            val projects by viewModel.projects.collectAsState()
            val cacheSize by viewModel.cacheSize.collectAsState()

            val context = LocalContext.current
            val scope = rememberCoroutineScope()
            val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

            // System Photo Picker launcher
            val imagePickerLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.PickVisualMedia()
            ) { uri ->
                if (uri != null) {
                    viewModel.onSelectDeviceImage(uri)
                }
            }

            // System Video Picker launcher
            val videoPickerLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.PickVisualMedia()
            ) { uri ->
                if (uri != null) {
                    viewModel.onSelectDeviceVideo(uri)
                }
            }

            EnhanceXTheme(themeMode = themeMode) {
                Box(modifier = Modifier.fillMaxSize().testTag("app_root")) {
                    when (val screen = screenDestination) {
                        is ScreenDestination.MainNavigation -> {
                            MainScaffold(
                                currentDestination = navDestination,
                                onNavigate = { viewModel.setNavDestination(it) },
                                projects = projects,
                                currentThemeMode = themeMode,
                                cacheSizeText = cacheSize,
                                isCloudActive = viewModel.aiServiceManager.isCloudAvailable(),
                                onSelectTool = { viewModel.openTool(it) },
                                onOpenProject = { project ->
                                    viewModel.openProject(project)
                                },
                                onDeleteProject = { viewModel.deleteProject(it) },
                                onClearAllHistory = { viewModel.clearAllHistory() },
                                onSelectThemeMode = { viewModel.setThemeMode(it) },
                                onClearCache = {
                                    viewModel.clearCache()
                                    Toast.makeText(context, "Cache cleared", Toast.LENGTH_SHORT).show()
                                }
                            )
                        }

                        is ScreenDestination.ActiveToolScreen -> {
                            when (screen.toolType) {
                                ToolType.PHOTO_ENHANCE -> {
                                    PhotoEnhanceScreen(
                                        currentBitmap = viewModel.currentPhotoBitmap,
                                        onBack = { viewModel.navigateBackToNav() },
                                        onChangePhoto = { viewModel.requestMediaPicker(MediaType.IMAGE) },
                                        onProcess = { params -> viewModel.processPhotoEnhancement(params) }
                                    )
                                }
                                ToolType.IMAGE_COMPRESS -> {
                                    ImageCompressorScreen(
                                        currentBitmap = viewModel.currentPhotoBitmap,
                                        onBack = { viewModel.navigateBackToNav() },
                                        onChangePhoto = { viewModel.requestMediaPicker(MediaType.IMAGE) },
                                        onCompress = { format, quality, scale ->
                                            viewModel.processImageCompression(format, quality, scale)
                                        }
                                    )
                                }
                                ToolType.RESIZE_IMAGE -> {
                                    ImageResizerScreen(
                                        currentBitmap = viewModel.currentPhotoBitmap,
                                        onBack = { viewModel.navigateBackToNav() },
                                        onChangePhoto = { viewModel.requestMediaPicker(MediaType.IMAGE) },
                                        onResize = { w, h ->
                                            viewModel.processImageResize(w, h)
                                        }
                                    )
                                }
                                ToolType.REMOVE_BACKGROUND -> {
                                    BackgroundRemovalScreen(
                                        currentBitmap = viewModel.currentPhotoBitmap,
                                        onBack = { viewModel.navigateBackToNav() },
                                        onChangePhoto = { viewModel.requestMediaPicker(MediaType.IMAGE) },
                                        onRemoveBackground = { bgHex, blur ->
                                            viewModel.processBackgroundRemoval(bgHex, blur)
                                        }
                                    )
                                }
                                ToolType.COMPRESS_VIDEO -> {
                                    VideoCompressorScreen(
                                        videoMetadata = viewModel.currentVideoMetadata,
                                        onBack = { viewModel.navigateBackToNav() },
                                        onChangeVideo = { viewModel.requestMediaPicker(MediaType.VIDEO) },
                                        onCompress = { mult, res ->
                                            viewModel.processVideoCompression(mult, res)
                                        }
                                    )
                                }
                                ToolType.VIDEO_ENHANCE -> {
                                    VideoEnhanceScreen(
                                        videoMetadata = viewModel.currentVideoMetadata,
                                        sampleFrameBitmap = viewModel.currentPhotoBitmap,
                                        onBack = { viewModel.navigateBackToNav() },
                                        onChangeVideo = { viewModel.requestMediaPicker(MediaType.VIDEO) },
                                        onEnhance = { params ->
                                            viewModel.processVideoEnhance(params)
                                        }
                                    )
                                }
                                else -> {
                                    // Default to Photo Enhance for other photo utilities
                                    PhotoEnhanceScreen(
                                        currentBitmap = viewModel.currentPhotoBitmap,
                                        onBack = { viewModel.navigateBackToNav() },
                                        onChangePhoto = { viewModel.requestMediaPicker(MediaType.IMAGE) },
                                        onProcess = { params -> viewModel.processPhotoEnhancement(params) }
                                    )
                                }
                            }
                        }

                        is ScreenDestination.ResultScreen -> {
                            ResultView(
                                title = screen.title,
                                toolName = screen.toolName,
                                beforeBitmap = screen.beforeBitmap,
                                afterBitmap = screen.afterBitmap,
                                originalSizeText = screen.originalSizeText,
                                outputSizeText = screen.outputSizeText,
                                reductionPercent = screen.reductionPercent,
                                dimensionsText = screen.dimensionsText,
                                formatText = screen.formatText,
                                processingTimeText = screen.processingTimeText,
                                onSave = {
                                    Toast.makeText(context, "Saved to EnhanceX Exports & Gallery", Toast.LENGTH_LONG).show()
                                },
                                onShare = {
                                    viewModel.shareResult(screen.savedFile)
                                },
                                onEditAgain = {
                                    viewModel.navigateBackToNav()
                                },
                                onStartNew = {
                                    viewModel.navigateBackToNav()
                                }
                            )
                        }
                    }

                    // Processing Dialog Overlay
                    if (isProcessing) {
                        ProcessingDialog(
                            progressPercent = progressPercent,
                            stageText = stageText,
                            taskTitle = processingTitle,
                            onCancel = { viewModel.cancelProcessing() }
                        )
                    }

                    // File Picker Bottom Sheet
                    if (showPickerSheet) {
                        FilePickerSheet(
                            mediaType = targetMediaType,
                            sheetState = sheetState,
                            onDismiss = { viewModel.dismissPickerSheet() },
                            onPickFromGallery = {
                                if (targetMediaType == MediaType.IMAGE) {
                                    imagePickerLauncher.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                } else {
                                    videoPickerLauncher.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                                    )
                                }
                            },
                            onUseSampleScenic = {
                                if (targetMediaType == MediaType.IMAGE) {
                                    viewModel.useSamplePhotoScenic()
                                } else {
                                    viewModel.useSampleVideo()
                                }
                            },
                            onUseSamplePortrait = {
                                viewModel.useSamplePhotoPortrait()
                            }
                        )
                    }
                }
            }
        }
    }
}
