package com.example.data.db

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.example.data.model.MediaType
import com.example.data.model.ToolType
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Room database entity caching processed media metadata, local file paths,
 * parameters, and thumbnail references for instant re-access without re-processing.
 */
@Entity(
    tableName = "projects",
    indices = [
        Index(value = ["cacheKey"]),
        Index(value = ["timestamp"]),
        Index(value = ["toolType"])
    ]
)
data class ProjectEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val mediaType: MediaType,
    val toolType: ToolType,
    val originalSizeBytes: Long = 0L,
    val outputSizeBytes: Long = 0L,
    val originalDimensions: String = "",
    val outputDimensions: String = "",
    val originalPath: String = "",
    val outputPath: String = "",
    val thumbnailPath: String = "",
    val cacheKey: String = "",
    val formatText: String = "",
    val settingsSummary: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val isCached: Boolean = true,
    val notes: String = ""
) {
    val reductionPercent: Int
        get() {
            if (originalSizeBytes <= 0 || outputSizeBytes >= originalSizeBytes) return 0
            val diff = originalSizeBytes - outputSizeBytes
            return ((diff.toDouble() / originalSizeBytes) * 100).toInt()
        }

    val readableOriginalSize: String
        get() = formatBytes(originalSizeBytes)

    val readableOutputSize: String
        get() = formatBytes(outputSizeBytes)

    val formattedDate: String
        get() {
            val sdf = SimpleDateFormat("MMM d, h:mm a", Locale.getDefault())
            return sdf.format(Date(timestamp))
        }

    val hasValidFile: Boolean
        get() = outputPath.isNotEmpty() && File(outputPath).exists()

    private fun formatBytes(bytes: Long): String {
        if (bytes <= 0) return "0 KB"
        val kb = bytes / 1024.0
        val mb = kb / 1024.0
        return if (mb >= 1.0) String.format("%.1f MB", mb) else String.format("%.0f KB", kb)
    }
}
