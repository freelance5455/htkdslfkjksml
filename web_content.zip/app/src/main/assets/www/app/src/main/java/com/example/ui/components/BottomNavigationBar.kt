package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarDefaults
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Data model representing a destination item in the reusable [BottomNavigationBar].
 *
 * @param route Unique key identifying the destination.
 * @param title User-facing label displayed beneath the destination icon.
 * @param selectedIcon Icon vector shown when this destination is active.
 * @param unselectedIcon Icon vector shown when this destination is inactive.
 * @param contentDescription Accessibility description for screen readers.
 * @param badgeText Optional numeric or text badge (e.g. "3" or "NEW").
 * @param hasBadge Whether to display an unread notification dot badge.
 * @param testTag Unique test tag for automated testing.
 */
data class BottomNavDestination(
    val route: String,
    val title: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector = selectedIcon,
    val contentDescription: String = title,
    val badgeText: String? = null,
    val hasBadge: Boolean = false,
    val testTag: String = "nav_item_${route.lowercase()}"
)

/**
 * Converts an [AppDestination] into a [BottomNavDestination] specification.
 */
fun AppDestination.toBottomNavDestination(
    badgeText: String? = null,
    hasBadge: Boolean = false
): BottomNavDestination {
    return BottomNavDestination(
        route = this.name,
        title = this.title,
        selectedIcon = this.selectedIcon,
        unselectedIcon = this.unselectedIcon,
        contentDescription = this.title,
        badgeText = badgeText,
        hasBadge = hasBadge,
        testTag = "nav_item_${this.name.lowercase()}"
    )
}

/**
 * Reusable Material3 Bottom Navigation Bar that provides clean access to the app's
 * primary sections while respecting mobile-first safe areas (gesture insets and 3-button bars).
 *
 * Safe Area handling:
 * - Uses [NavigationBarDefaults.windowInsets] by default, which maps to
 *   [WindowInsets.systemBars] on the horizontal and bottom edges.
 * - Allows the outer container background to bleed into the bottom navigation bar area
 *   seamlessly, avoiding clipped backgrounds or awkward white/black margins.
 * - Navigation items maintain standard 80.dp M3 component height plus safe area insets
 *   so icons and labels are never truncated or overlapping the Android navigation bar.
 *
 * @param destinations List of [BottomNavDestination] items to display.
 * @param currentRoute The route key of the currently selected destination.
 * @param onDestinationSelected Callback fired when an item is tapped.
 * @param modifier Optional modifier for the navigation bar layout.
 * @param containerColor Background color of the navigation bar and safe area backing.
 * @param contentColor Default content color for items.
 * @param activeColor Color for the active icon and active text label.
 * @param inactiveColor Color for inactive icons and labels.
 * @param indicatorColor Subtle background aura color behind the active icon.
 * @param showTopBorder Whether to render a hairline border above the navigation bar.
 * @param borderColor Color for the optional top border.
 * @param windowInsets Safe area window insets to apply to the [NavigationBar].
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BottomNavigationBar(
    destinations: List<BottomNavDestination>,
    currentRoute: String,
    onDestinationSelected: (BottomNavDestination) -> Unit,
    modifier: Modifier = Modifier,
    containerColor: Color = Color(0xFF0A0C14),
    contentColor: Color = MaterialTheme.colorScheme.onSurface,
    activeColor: Color = Color(0xFF818CF8),
    inactiveColor: Color = Color(0xFF64748B),
    indicatorColor: Color = Color(0xFF4F46E5).copy(alpha = 0.20f),
    tonalElevation: Dp = 0.dp,
    showTopBorder: Boolean = true,
    borderColor: Color = Color(0x661E293B),
    windowInsets: WindowInsets = NavigationBarDefaults.windowInsets
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(containerColor)
    ) {
        if (showTopBorder) {
            HorizontalDivider(
                color = borderColor,
                thickness = 1.dp,
                modifier = Modifier.fillMaxWidth()
            )
        }

        NavigationBar(
            containerColor = containerColor,
            contentColor = contentColor,
            tonalElevation = tonalElevation,
            windowInsets = windowInsets,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("bottom_nav_bar")
        ) {
            destinations.forEach { item ->
                val isSelected = item.route.equals(currentRoute, ignoreCase = true)

                NavigationBarItem(
                    selected = isSelected,
                    onClick = { onDestinationSelected(item) },
                    icon = {
                        BadgedBox(
                            badge = {
                                if (item.badgeText != null) {
                                    Badge(
                                        containerColor = activeColor,
                                        contentColor = Color.White
                                    ) {
                                        Text(
                                            text = item.badgeText,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                } else if (item.hasBadge) {
                                    Badge(
                                        containerColor = activeColor,
                                        modifier = Modifier.size(6.dp)
                                    )
                                }
                            }
                        ) {
                            Icon(
                                imageVector = if (isSelected) item.selectedIcon else item.unselectedIcon,
                                contentDescription = item.contentDescription,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    },
                    label = {
                        Text(
                            text = item.title,
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Medium,
                            letterSpacing = 0.1.sp,
                            maxLines = 1
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        indicatorColor = indicatorColor,
                        selectedIconColor = activeColor,
                        unselectedIconColor = inactiveColor,
                        selectedTextColor = activeColor,
                        unselectedTextColor = inactiveColor
                    ),
                    modifier = Modifier.testTag(item.testTag)
                )
            }
        }
    }
}

/**
 * Overloaded convenience [BottomNavigationBar] for [AppDestination] enum values.
 *
 * @param currentDestination The currently active [AppDestination].
 * @param onNavigate Callback invoked when the user selects a destination.
 * @param modifier Layout modifier.
 * @param destinations List of [AppDestination] entries (defaults to all entries).
 * @param windowInsets WindowInsets for safe area padding.
 */
@Composable
fun BottomNavigationBar(
    currentDestination: AppDestination,
    onNavigate: (AppDestination) -> Unit,
    modifier: Modifier = Modifier,
    destinations: List<AppDestination> = AppDestination.values().toList(),
    windowInsets: WindowInsets = NavigationBarDefaults.windowInsets
) {
    val navDestinations = destinations.map { it.toBottomNavDestination() }

    BottomNavigationBar(
        destinations = navDestinations,
        currentRoute = currentDestination.name,
        onDestinationSelected = { selectedItem ->
            val matchingDest = destinations.find { it.name.equals(selectedItem.route, ignoreCase = true) }
            if (matchingDest != null) {
                onNavigate(matchingDest)
            }
        },
        modifier = modifier,
        windowInsets = windowInsets
    )
}
