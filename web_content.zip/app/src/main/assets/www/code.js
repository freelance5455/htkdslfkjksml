/**
 * আল-ইনসাফ মানব কল্যাণ ফাউন্ডেশন - Main Controller (code.js)
 * Clean Architecture, Zero Demo Data, Real-time Calculation, Firebase/Local Engine
 */

// Initial State (100% Zero Demo Data)
const AppState = {
  currentUser: null,
  userRole: 'visitor', // 'super_admin' | 'admin' | 'visitor'
  currentTab: 'home',
  adminTab: 'dash',

  // Database Collections (All initialize empty, permanently synced with Firestore)
  directors: [],
  members: [],
  memberApplications: [],
  memberPayments: [],
  helpApplications: [],
  beneficiaries: [],
  activities: [],
  distributions: [],
  fundTransactions: [],
  expenses: [],
  donations: [],
  auditLogs: [],
  admins: [],
  monthlyReports: [],
  settings: {
    foundationName: 'আল-ইনসাফ মানব কল্যাণ ফাউন্ডেশন',
    address: 'মালতিপুর, পাথালিয়া, মুক্তাগাছা, মোমেনশাহী',
    mobile: '01700-000000',
    email: 'jubairahmad8000@gmail.com',
    bkashNumber: '01700-000000 (পার্সোনাল)',
    nagadNumber: '01700-000000 (পার্সোনাল)',
    marqueeNotice: 'আল-ইনসাফ মানব কল্যাণ ফাউন্ডেশনে আপনাকে স্বাগতম। অসহায় ও দুস্থ মানুষের সেবায় এগিয়ে আসুন।',
    aboutText: 'আল-ইনসাফ মানব কল্যাণ ফাউন্ডেশন একটি অরাজনৈতিক, অলাভজনক ও ইনসাফভিত্তিক সেবামূলক প্রতিষ্ঠান। ইসলামের ইনসাফ ও মানবতার মহান শিক্ষাকে ধারণ করে সমাজের অসহায়, বিধবা, এতিম, রোগী ও কর্মহীন মানুষের পাশে দাঁড়িয়ে তাদের স্বাবলম্বী করা এবং নৈতিক সমাজ বিনির্মাণে ভূমিকা পালন করাই আমাদের মূল লক্ষ্য।'
  }
};

// 7 Permanent Core Activities Definitions
const DEFAULT_7_ACTIVITIES = [
  { id: 'act-1', title: 'বয়স্কদের কুরআন শিক্ষা', desc: 'বয়স্ক নর-নারীদের জন্য বিশুদ্ধ কুরআন তিলাওয়াত ও প্রয়োজনীয় দ্বীনি মাসায়েল শিক্ষার সার্বজনীন কর্মসূচি।' },
  { id: 'act-2', title: 'স্বাবলম্বীকরণ কর্মসূচি', desc: 'দরিদ্র ও কর্মহীন পরিবারগুলোকে সেলাই মেশিন, ভ্যান/রিকশা বা ক্ষুদ্র ব্যবসার মাধ্যমে স্থায়ীভাবে আত্মনির্ভরশীল করে তোলা।' },
  { id: 'act-3', title: 'ঈদ সামগ্রী বিতরণ কর্মসূচি', desc: 'পবিত্র ঈদুল ফিতর ও ঈদুল আযহায় হতদরিদ্র মানুষের মাঝে আনন্দ ছড়িয়ে দিতে খাদ্য ও পোশাক সামগ্রী বিতরণ।' },
  { id: 'act-4', title: 'দাওয়াত ও তাবলীগ', desc: 'ইসলামের শাশ্বত শান্তির বাণী ছড়িয়ে দেওয়া, সচেতনতা সভা এবং পথভ্রষ্টদের আলোর পথে আহ্বানের কর্মসূচি।' },
  { id: 'act-5', title: 'সমাজসেবামূলক কার্যক্রম', desc: 'শীতবস্ত্র বিতরণ, বিশুদ্ধ খাবার পানির টিউবওয়েল স্থাপন ও জরুরি দুর্যোগকালীন ত্রাণ সহায়তা।' },
  { id: 'act-6', title: 'চিকিৎসা সেবা কর্মসূচি', desc: 'অসহায় রোগীদের জরুরি ওষুধ, অপারেশন ও চিকিৎসার জন্য আর্থিক অনুদান প্রদান কর্মসূচি।' },
  { id: 'act-7', title: 'ধর্মীয় পাঠাগার', desc: 'যুবসমাজকে বইমুখী করতে এবং বিশুদ্ধ ইসলামি জ্ঞান অর্জনে উন্মুক্ত পাঠাগার ও অধ্যয়ন কেন্দ্র।' }
];

// Offline Cache & Bridge Helper (Cloud Firestore is the single authoritative source of truth)
const DB = {
  load() {
    try {
      const data = localStorage.getItem('alinsaf_db_v1');
      if (data) {
        const parsed = JSON.parse(data);
        Object.assign(AppState, parsed);
      }
      if (!AppState.activities || AppState.activities.length === 0) {
        AppState.activities = [...DEFAULT_7_ACTIVITIES];
      }
    } catch (e) {
      console.warn("Local cache read notice:", e);
    }
  },
  saveLocal() {
    try {
      localStorage.setItem('alinsaf_db_v1', JSON.stringify({
        directors: AppState.directors,
        members: AppState.members,
        memberApplications: AppState.memberApplications,
        memberPayments: AppState.memberPayments,
        helpApplications: AppState.helpApplications,
        beneficiaries: AppState.beneficiaries,
        activities: AppState.activities,
        distributions: AppState.distributions,
        fundTransactions: AppState.fundTransactions,
        expenses: AppState.expenses,
        donations: AppState.donations,
        auditLogs: AppState.auditLogs,
        admins: AppState.admins,
        monthlyReports: AppState.monthlyReports || [],
        settings: AppState.settings
      }));
    } catch (e) {
      console.error("Cache save error:", e);
    }
  },
  save() {
    this.saveLocal();
  },
  async saveEntity(collectionName, entity) {
    if (!entity || !entity.id) return false;
    await FirestoreDB.setDoc(collectionName, entity.id, entity);
    this.saveLocal();
    return true;
  },
  async deleteEntity(collectionName, entityId) {
    if (!entityId) return false;
    await FirestoreDB.deleteDoc(collectionName, entityId);
    this.saveLocal();
    return true;
  }
};

// Firestore Service & Data Layer (Authoritative Cloud Database)
const FirestoreDB = {
  getDb() {
    if (window.AlInsafFirebase && window.AlInsafFirebase.db) {
      return window.AlInsafFirebase.db;
    }
    if (typeof firebase !== 'undefined' && firebase.firestore) {
      return firebase.firestore();
    }
    return null;
  },
  getAuth() {
    if (window.AlInsafFirebase && window.AlInsafFirebase.auth) {
      return window.AlInsafFirebase.auth;
    }
    if (typeof firebase !== 'undefined' && firebase.auth) {
      return firebase.auth();
    }
    return null;
  },
  async setDoc(collectionName, docId, data) {
    try {
      const db = this.getDb();
      if (!db) {
        console.warn(`[Firestore] Database not yet ready. Queued for: ${collectionName}/${docId}`);
        return false;
      }
      const record = { ...data };
      record.updatedAt = new Date().toISOString();
      if (!record.createdAt) {
        record.createdAt = new Date().toISOString();
      }
      // Associate with current authenticated user UID for audit and ownership tracking
      if (AppState.currentUser) {
        if (!record.createdByUid) {
          record.createdByUid = AppState.currentUser.uid;
          record.createdByName = AppState.currentUser.name || AppState.currentUser.email;
        }
        record.updatedByUid = AppState.currentUser.uid;
      }
      await db.collection(collectionName).doc(String(docId)).set(record, { merge: true });
      console.log(`[Firestore] Successfully saved: [${collectionName}/${docId}]`);
      DB.saveLocal();
      return true;
    } catch (err) {
      console.error(`[Firestore Error] setDoc ${collectionName}/${docId}:`, err);
      showToast(`সার্ভারে ডাটা সংরক্ষণ ত্রুটি: ${err.message}`, 'error');
      return false;
    }
  },
  async deleteDoc(collectionName, docId) {
    try {
      const db = this.getDb();
      if (!db) return false;
      await db.collection(collectionName).doc(String(docId)).delete();
      console.log(`[Firestore] Successfully deleted: [${collectionName}/${docId}]`);
      DB.saveLocal();
      return true;
    } catch (err) {
      console.error(`[Firestore Error] deleteDoc ${collectionName}/${docId}:`, err);
      showToast(`সার্ভার থেকে ডাটা মুছতে ত্রুটি: ${err.message}`, 'error');
      return false;
    }
  }
};

const FirestoreSync = {
  publicUnsubscribers: [],
  adminUnsubscribers: [],

  initPublicSync() {
    const db = FirestoreDB.getDb();
    if (!db) {
      console.info("Firestore not initialized; running with cached data.");
      return;
    }

    const publicCollections = [
      { name: 'directors', key: 'directors' },
      { name: 'members', key: 'members' },
      { name: 'activities', key: 'activities' },
      { name: 'distributions', key: 'distributions' },
      { name: 'beneficiaries', key: 'beneficiaries' },
      { name: 'expenses', key: 'expenses' },
      { name: 'fundTransactions', key: 'fundTransactions' },
      { name: 'monthlyReports', key: 'monthlyReports' }
    ];

    publicCollections.forEach(col => {
      try {
        const unsub = db.collection(col.name).onSnapshot(snapshot => {
          if (!snapshot.empty) {
            AppState[col.key] = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
          } else {
            AppState[col.key] = [];
            if (col.key === 'activities') {
              AppState.activities = [...DEFAULT_7_ACTIVITIES];
            }
          }
          DB.saveLocal();
          App.updateCounters();
          App.renderPublicUI();
        }, err => {
          console.warn(`Firestore public snapshot notice (${col.name}):`, err.message);
        });
        this.publicUnsubscribers.push(unsub);
      } catch (err) {
        console.warn(`Sync setup error for ${col.name}:`, err);
      }
    });

    // Public Settings listener
    try {
      const unsubSettings = db.collection('settings').doc('general').onSnapshot(doc => {
        if (doc.exists) {
          AppState.settings = { ...AppState.settings, ...doc.data() };
          App.updateBrandAndSettingsUI();
          DB.saveLocal();
        }
      }, err => {
        console.warn("Settings snapshot notice:", err.message);
      });
      this.publicUnsubscribers.push(unsubSettings);
    } catch (err) {
      console.warn("Settings listener error:", err);
    }
  },

  initAdminSync() {
    this.stopAdminSync();
    const db = FirestoreDB.getDb();
    if (!db || !AppState.currentUser) return;

    const adminCollections = [
      { name: 'memberApplications', key: 'memberApplications' },
      { name: 'helpApplications', key: 'helpApplications' },
      { name: 'donations', key: 'donations' },
      { name: 'memberPayments', key: 'memberPayments' },
      { name: 'auditLogs', key: 'auditLogs' },
      { name: 'admins', key: 'admins' }
    ];

    adminCollections.forEach(col => {
      try {
        const unsub = db.collection(col.name).onSnapshot(snapshot => {
          if (!snapshot.empty) {
            AppState[col.key] = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
          } else {
            AppState[col.key] = [];
          }
          DB.saveLocal();
          App.updateBadgeCounts();
          Admin.renderTab();
        }, err => {
          console.warn(`Firestore admin snapshot notice (${col.name}):`, err.message);
        });
        this.adminUnsubscribers.push(unsub);
      } catch (err) {
        console.warn(`Admin sync error for ${col.name}:`, err);
      }
    });
  },

  stopAdminSync() {
    this.adminUnsubscribers.forEach(unsub => {
      try { unsub(); } catch (_) {}
    });
    this.adminUnsubscribers = [];
  }
};

// UI Notification Toast
function showToast(message, type = 'success') {
  const container = document.getElementById('toastContainer');
  if (!container) return;
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  const icon = type === 'success' ? 'circle-check' : (type === 'error' ? 'circle-exclamation' : 'circle-info');
  toast.innerHTML = `<i class="fa-solid fa-${icon}"></i> <span>${message}</span>`;
  container.appendChild(toast);
  setTimeout(() => toast.remove(), 4000);
}

// Financial Calculator (Calculated strictly from database)
function calculateFinances() {
  // Verified Income: sum of verified donations + general fund deposits
  const verifiedDonations = AppState.donations.filter(d => d.status === 'verified');
  const zakatIncome = verifiedDonations.filter(d => d.fundType === 'zakat').reduce((s, d) => s + Number(d.amount), 0) +
                      AppState.fundTransactions.filter(t => t.type === 'income' && t.fundType === 'zakat').reduce((s, t) => s + Number(t.amount), 0);
  
  const generalIncome = verifiedDonations.filter(d => d.fundType === 'general').reduce((s, d) => s + Number(d.amount), 0) +
                        AppState.fundTransactions.filter(t => t.type === 'income' && t.fundType === 'general').reduce((s, t) => s + Number(t.amount), 0) +
                        AppState.memberPayments.reduce((s, p) => s + Number(p.amount || 0), 0);

  const totalIncome = zakatIncome + generalIncome;

  // Expenses: sum of approved expenses + distributions with recorded costs
  const zakatExpense = AppState.expenses.filter(e => e.fundType === 'zakat').reduce((s, e) => s + Number(e.amount), 0);
  const generalExpense = AppState.expenses.filter(e => e.fundType !== 'zakat').reduce((s, e) => s + Number(e.amount), 0);
  const totalExpense = zakatExpense + generalExpense;

  const currentBalance = totalIncome - totalExpense;
  const zakatBalance = zakatIncome - zakatExpense;
  const generalBalance = generalIncome - generalExpense;

  // Today's Stats
  const todayStr = new Date().toISOString().split('T')[0];
  const todayIncome = verifiedDonations.filter(d => (d.date || '').startsWith(todayStr)).reduce((s, d) => s + Number(d.amount), 0);
  const todayExpense = AppState.expenses.filter(e => (e.date || '').startsWith(todayStr)).reduce((s, e) => s + Number(e.amount), 0);

  return {
    totalIncome,
    totalExpense,
    currentBalance,
    zakatIncome,
    zakatExpense,
    zakatBalance,
    generalIncome,
    generalExpense,
    generalBalance,
    todayIncome,
    todayExpense
  };
}

// Log Audit Action
function addAuditLog(action, recordId, details = '') {
  const adminName = AppState.currentUser ? AppState.currentUser.name : 'সুপার এডমিন';
  const adminEmail = AppState.currentUser ? AppState.currentUser.email : 'admin@alinsaf.org';
  const now = new Date();
  const log = {
    id: 'log-' + Date.now(),
    adminName,
    adminEmail,
    action,
    recordId,
    details,
    date: now.toISOString().split('T')[0],
    time: now.toLocaleTimeString('bn-BD')
  };
  AppState.auditLogs.unshift(log);
  DB.save();
  if (AppState.currentUser) {
    FirestoreDB.setDoc('auditLogs', log.id, log);
  }
}

// Global App Controller
const App = {
  init() {
    DB.load();
    this.updateBrandAndSettingsUI();
    this.renderHomeActivities();
    this.renderPublicUI();
    this.updateCounters();
    this.updateBadgeCounts();

    // Start Firestore Real-time Public Sync (Requirement 2)
    FirestoreSync.initPublicSync();

    // Start Firebase Auth State Listener (Requirement 6)
    this.initAuthStateListener();
  },

  navigateTo(pageId) {
    document.querySelectorAll('.page-section').forEach(sec => sec.classList.remove('active'));
    document.querySelectorAll('.nav-link').forEach(link => link.classList.remove('active'));

    const targetSec = document.getElementById('sec-' + pageId);
    if (targetSec) {
      targetSec.classList.add('active');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    const activeNav = Array.from(document.querySelectorAll('.nav-link')).find(l => l.getAttribute('onclick')?.includes(pageId));
    if (activeNav) activeNav.classList.add('active');

    // Close mobile menu if open
    document.getElementById('navLinks')?.classList.remove('show');

    if (pageId === 'admin') {
      Admin.renderTab();
    } else {
      this.renderPublicUI();
    }
  },

  toggleMobileMenu() {
    document.getElementById('navLinks')?.classList.toggle('show');
  },

  updateBrandAndSettingsUI() {
    const s = AppState.settings;
    document.getElementById('displayFoundationName').textContent = s.foundationName;
    document.getElementById('displayFoundationAddress').innerHTML = `<i class="fa-solid fa-location-dot"></i> ` + s.address;
    document.getElementById('noticeMarquee').textContent = s.marqueeNotice;
    document.getElementById('displayAboutText').textContent = s.aboutText;
    document.getElementById('bkashNumberDisplay').textContent = s.bkashNumber;
    document.getElementById('nagadNumberDisplay').textContent = s.nagadNumber;
    document.getElementById('contactAddress').textContent = s.address;
    document.getElementById('contactPhone').textContent = s.mobile;
    document.getElementById('contactEmail').textContent = s.email;
  },

  renderHomeActivities() {
    const container = document.getElementById('homeActivitiesGrid');
    if (!container) return;
    const items = AppState.activities.slice(0, 7);
    container.innerHTML = items.map((act, i) => `
      <div class="activity-card card-3d">
        <div class="activity-header">
          <div class="activity-num">${(i + 1).toLocaleString('bn-BD')}</div>
          <h3>${act.title}</h3>
        </div>
        <p>${act.desc}</p>
      </div>
    `).join('');

    const detailedContainer = document.getElementById('activitiesDetailedGrid');
    if (detailedContainer) {
      detailedContainer.innerHTML = AppState.activities.map((act, i) => `
        <div class="activity-card card-3d mb-4">
          <div class="activity-header">
            <div class="activity-num">${(i + 1).toLocaleString('bn-BD')}</div>
            <h3>${act.title}</h3>
          </div>
          <p>${act.desc}</p>
        </div>
      `).join('');
    }
  },

  updateCounters() {
    const fin = calculateFinances();
    document.getElementById('pubCountMembers').textContent = AppState.members.length.toLocaleString('bn-BD');
    document.getElementById('pubCountDirectors').textContent = AppState.directors.length.toLocaleString('bn-BD');
    document.getElementById('pubCountBeneficiaries').textContent = AppState.beneficiaries.length.toLocaleString('bn-BD');
    document.getElementById('pubCountDistributions').textContent = AppState.distributions.length.toLocaleString('bn-BD');
    document.getElementById('pubTotalFundDisplay').textContent = '৳ ' + fin.currentBalance.toLocaleString('bn-BD');

    document.getElementById('fundCurrentBalance').textContent = '৳ ' + fin.currentBalance.toLocaleString('bn-BD');
    document.getElementById('fundZakatBalance').textContent = '৳ ' + fin.zakatBalance.toLocaleString('bn-BD');
    document.getElementById('fundGeneralBalance').textContent = '৳ ' + fin.generalBalance.toLocaleString('bn-BD');
    document.getElementById('fundTotalIncome').textContent = '৳ ' + fin.totalIncome.toLocaleString('bn-BD');
    document.getElementById('fundTotalExpense').textContent = '৳ ' + fin.totalExpense.toLocaleString('bn-BD');
  },

  renderPublicUI() {
    this.updateCounters();
    this.renderPublicDirectors();
    this.renderPublicMembers();
    this.renderPublicLedger();
    this.renderPublicDistributions();
  },

  renderPublicDirectors() {
    const container = document.getElementById('directorsContainer');
    const empty = document.getElementById('directorsEmptyState');
    if (!container) return;
    if (AppState.directors.length === 0) {
      container.innerHTML = '';
      empty.style.display = 'block';
      return;
    }
    empty.style.display = 'none';
    container.innerHTML = AppState.directors.map(dir => `
      <div class="person-card card-3d">
        <img src="${dir.photo || './assets/logo/logo.png'}" alt="${dir.name}" class="person-photo">
        <h3>${dir.name}</h3>
        <span class="person-designation">${dir.designation}</span>
        <p class="text-muted"><small>${dir.responsibility || ''}</small></p>
      </div>
    `).join('');
  },

  renderPublicMembers() {
    const container = document.getElementById('membersContainer');
    const empty = document.getElementById('membersEmptyState');
    if (!container) return;
    const activeMembers = AppState.members.filter(m => m.status === 'active');
    if (activeMembers.length === 0) {
      container.innerHTML = '';
      empty.style.display = 'block';
      return;
    }
    empty.style.display = 'none';
    container.innerHTML = activeMembers.map(m => `
      <div class="person-card card-3d">
        <img src="${m.photo || './assets/logo/logo.png'}" alt="${m.name}" class="person-photo">
        <h3>${m.name}</h3>
        <p class="text-muted"><small>ফরম নম্বর: ${m.formNumber || '---'}</small></p>
        <p><span class="badge badge-success">সক্রিয় সদস্য</span></p>
      </div>
    `).join('');
  },

  filterMembers() {
    const q = document.getElementById('memberSearchInput').value.trim().toLowerCase();
    const container = document.getElementById('membersContainer');
    const filtered = AppState.members.filter(m => {
      const matchQ = (m.name && m.name.toLowerCase().includes(q)) ||
                     (m.formNumber && m.formNumber.toLowerCase().includes(q)) ||
                     (m.bloodGroup && m.bloodGroup.toLowerCase().includes(q));
      return matchQ;
    });
    if (filtered.length === 0) {
      container.innerHTML = '<div class="empty-state"><p>কোনো সদস্য পাওয়া যায়নি।</p></div>';
      return;
    }
    container.innerHTML = filtered.map(m => `
      <div class="person-card card-3d">
        <img src="${m.photo || './assets/logo/logo.png'}" alt="${m.name}" class="person-photo">
        <h3>${m.name}</h3>
        <p class="text-muted"><small>ফরম নম্বর: ${m.formNumber || '---'}</small></p>
        <p><span class="badge badge-success">${m.status === 'active' ? 'সক্রিয় সদস্য' : 'স্থগিত'}</span></p>
      </div>
    `).join('');
  },

  renderPublicLedger() {
    const tbody = document.getElementById('publicLedgerTableBody');
    const empty = document.getElementById('publicLedgerEmpty');
    if (!tbody) return;

    // Combine verified donations & recorded transactions
    const ledger = [];
    AppState.donations.filter(d => d.status === 'verified').forEach(d => {
      ledger.push({
        date: d.date || '---',
        type: 'দান / অনুদান',
        fundType: d.fundType === 'zakat' ? 'জাকাত ফান্ড' : 'সাধারণ ফান্ড',
        desc: d.donorName ? `দাতার নাম: ${d.donorName}` : 'গোপন দান',
        amount: d.amount,
        status: 'ভেরিফাইড'
      });
    });
    AppState.expenses.forEach(e => {
      ledger.push({
        date: e.date || '---',
        type: 'ব্যয় / খরচ',
        fundType: e.fundType === 'zakat' ? 'জাকাত ফান্ড' : 'সাধারণ ফান্ড',
        desc: e.desc,
        amount: '-' + e.amount,
        status: 'অনুমোদিত'
      });
    });

    if (ledger.length === 0) {
      tbody.innerHTML = '';
      empty.style.display = 'block';
      return;
    }
    empty.style.display = 'none';
    tbody.innerHTML = ledger.slice(0, 10).map(row => `
      <tr>
        <td>${row.date}</td>
        <td><span class="badge ${row.amount > 0 ? 'badge-success' : 'badge-danger'}">${row.type}</span></td>
        <td>${row.fundType}</td>
        <td>${row.desc}</td>
        <td><strong>৳ ${Number(Math.abs(row.amount)).toLocaleString('bn-BD')}</strong></td>
        <td><span class="badge badge-success">${row.status}</span></td>
      </tr>
    `).join('');
  },

  renderPublicDistributions() {
    const tbody = document.getElementById('publicDistTableBody');
    const empty = document.getElementById('publicDistEmpty');
    if (!tbody) return;
    if (AppState.distributions.length === 0) {
      tbody.innerHTML = '';
      empty.style.display = 'block';
      return;
    }
    empty.style.display = 'none';
    tbody.innerHTML = AppState.distributions.map((d, i) => `
      <tr>
        <td>${(i + 1).toLocaleString('bn-BD')}</td>
        <td>${d.date}</td>
        <td>${d.area || 'মুক্তাগাছা'}</td>
        <td>${d.itemName} (${d.category || 'সামগ্রী'})</td>
        <td>${d.quantity} ${d.unit || ''}</td>
        <td>৳ ${Number(d.totalPrice || 0).toLocaleString('bn-BD')}</td>
      </tr>
    `).join('');
  },

  // Image Preview helper
  handleImagePreview(input, previewId) {
    const preview = document.getElementById(previewId);
    if (!preview || !input.files || !input.files[0]) return;
    const file = input.files[0];
    if (file.size > 5 * 1024 * 1024) {
      showToast('ছবি অবশ্যই ৫ মেগাবাইটের কম হতে হবে', 'error');
      input.value = '';
      return;
    }
    const reader = new FileReader();
    reader.onload = e => {
      preview.innerHTML = `<img src="${e.target.result}" alt="Preview">`;
    };
    reader.readAsDataURL(file);
  },

  // Member Application Submission
  submitMemberApplication(e) {
    e.preventDefault();
    const name = document.getElementById('memAppName').value.trim();
    const father = document.getElementById('memAppFather').value.trim();
    const village = document.getElementById('memAppVillage').value.trim();
    const thana = document.getElementById('memAppThana').value.trim();
    const district = document.getElementById('memAppDistrict').value.trim();
    const occupation = document.getElementById('memAppOccupation').value.trim();
    const blood = document.getElementById('memAppBlood').value;
    const mobile = document.getElementById('memAppMobile').value.trim();
    const pledge = document.getElementById('memAppMonthlyPledge').value;
    const reason = document.getElementById('memAppReason').value.trim();
    const photoInput = document.getElementById('memAppPhoto');

    if (!document.getElementById('memAgreement').checked) {
      showToast('শর্তাবলীর সম্মতি আবশ্যক', 'error');
      return;
    }

    const appNumber = 'MA-' + Math.floor(100000 + Math.random() * 900000);
    const dateStr = new Date().toISOString().split('T')[0];

    const saveApp = (photoData) => {
      const newApp = {
        id: 'ma-' + Date.now(),
        appNumber,
        name,
        father,
        village,
        thana,
        district,
        occupation,
        bloodGroup: blood,
        mobile,
        monthlyPledge: pledge,
        reason,
        photo: photoData,
        date: dateStr,
        status: 'pending' // অপেক্ষমাণ
      };

      AppState.memberApplications.unshift(newApp);
      DB.save();
      FirestoreDB.setDoc('memberApplications', newApp.id, newApp);
      showToast(`আপনার আবেদন সফলভাবে জমা হয়েছে! আবেদন নম্বর: ${appNumber}`, 'success');
      document.getElementById('memberApplicationForm').reset();
      document.getElementById('memPhotoPreview').innerHTML = '';
      App.updateBadgeCounts();
    };

    if (photoInput.files && photoInput.files[0]) {
      const reader = new FileReader();
      reader.onload = ev => saveApp(ev.target.result);
      reader.readAsDataURL(photoInput.files[0]);
    } else {
      saveApp('');
    }
  },

  // Help Application Submission
  submitHelpApplication(e) {
    e.preventDefault();
    if (!document.getElementById('helpAgreement').checked) {
      showToast('নীতিমালা ও সিদ্ধান্তের সম্মতি আবশ্যক', 'error');
      return;
    }

    const name = document.getElementById('helpName').value.trim();
    const father = document.getElementById('helpFather').value.trim();
    const gender = document.getElementById('helpGender').value;
    const age = document.getElementById('helpAge').value;
    const village = document.getElementById('helpVillage').value.trim();
    const thana = document.getElementById('helpThana').value.trim();
    const district = document.getElementById('helpDistrict').value.trim();
    const mobile = document.getElementById('helpMobile').value.trim();
    const occupation = document.getElementById('helpOccupation').value.trim();
    const familyMembers = document.getElementById('helpFamilyMembers').value;
    const monthlyIncome = document.getElementById('helpMonthlyIncome').value;
    const aidType = document.getElementById('helpAidType').value;
    const amount = document.getElementById('helpAmount').value.trim();
    const problem = document.getElementById('helpProblem').value.trim();
    const photoInput = document.getElementById('helpPhoto');
    const nidInput = document.getElementById('helpNidDoc');

    const appNumber = 'HA-' + Math.floor(100000 + Math.random() * 900000);
    const dateStr = new Date().toISOString().split('T')[0];

    const reader1 = new FileReader();
    reader1.onload = (e1) => {
      const photoData = e1.target.result;
      const reader2 = new FileReader();
      reader2.onload = (e2) => {
        const nidData = e2.target.result;

        const newHelp = {
          id: 'ha-' + Date.now(),
          appNumber,
          name,
          father,
          gender,
          age,
          village,
          thana,
          district,
          mobile,
          occupation,
          familyMembers,
          monthlyIncome,
          aidType,
          amount,
          problem,
          photo: photoData,
          nidDoc: nidData,
          date: dateStr,
          status: 'pending' // pending -> under_review -> approved -> rejected -> completed
        };

        AppState.helpApplications.unshift(newHelp);
        DB.save();
        FirestoreDB.setDoc('helpApplications', newHelp.id, newHelp);
        showToast(`সাহায্য আবেদন গৃহীত হয়েছে! আবেদন ট্র্যাকিং নম্বর: ${appNumber}`, 'success');
        document.getElementById('helpApplicationForm').reset();
        document.getElementById('helpPhotoPreview').innerHTML = '';
        App.updateBadgeCounts();
      };
      if (nidInput.files && nidInput.files[0]) {
        reader2.readAsDataURL(nidInput.files[0]);
      } else {
        reader2.onload({ target: { result: '' } });
      }
    };

    if (photoInput.files && photoInput.files[0]) {
      reader1.readAsDataURL(photoInput.files[0]);
    } else {
      reader1.onload({ target: { result: '' } });
    }
  },

  // Donation Submission
  submitDonation(e) {
    e.preventDefault();
    const amount = Number(document.getElementById('donAmount').value);
    const fundType = document.getElementById('donFundType').value;
    const method = document.getElementById('donMethod').value;
    const trxId = document.getElementById('donTrxId').value.trim().toUpperCase();
    const donorName = document.getElementById('donDonorName').value.trim();
    const mobile = document.getElementById('donDonorMobile').value.trim();
    const note = document.getElementById('donNote').value.trim();

    if (amount <= 0) {
      showToast('টাকার পরিমাণ সঠিক নয়', 'error');
      return;
    }

    // Check duplicate TrxID
    const existing = AppState.donations.find(d => d.trxId === trxId);
    if (existing) {
      showToast('এই Transaction ID ইতিপূর্বে জমা দেওয়া হয়েছে', 'error');
      return;
    }

    const newDonation = {
      id: 'don-' + Date.now(),
      amount,
      fundType,
      method,
      trxId,
      donorName,
      mobile,
      note,
      date: new Date().toISOString().split('T')[0],
      status: 'pending' // Verification pending strictly
    };

    AppState.donations.unshift(newDonation);
    DB.save();
    FirestoreDB.setDoc('donations', newDonation.id, newDonation);
    showToast('আপনার দানের তথ্য গৃহীত হয়েছে। ভেরিফিকেশনের পর ফান্ডে যুক্ত হবে। জাযাকাল্লাহু খাইরান!', 'success');
    document.getElementById('donationSubmitForm').reset();
    App.updateBadgeCounts();
  },

  selectQuickAmount(amt) {
    document.getElementById('donAmount').value = amt;
    document.querySelectorAll('.amount-chip').forEach(c => c.classList.remove('active'));
    event.target.classList.add('active');
  },

  copyText(elemId, msg) {
    const text = document.getElementById(elemId).textContent;
    navigator.clipboard.writeText(text).then(() => {
      showToast(msg || 'কপি হয়েছে', 'info');
    });
  },

  handleContactSubmit(e) {
    e.preventDefault();
    showToast('আপনার বার্তাটি পাঠানো হয়েছে। ফাউন্ডেশনের দায়িত্বশীলগণ শীঘ্রই যোগাযোগ করবেন।', 'success');
    document.getElementById('contactForm').reset();
  },

  // Authentication Flow (Requirements 1, 4, 5, 6, 9)
  handleAuthButton() {
    if (AppState.currentUser) {
      this.navigateTo('admin');
    } else {
      document.getElementById('loginModal').classList.add('show');
    }
  },

  closeLoginModal() {
    document.getElementById('loginModal').classList.remove('show');
  },

  // Requirement 6: Page refresh-এর পর authentication state বজায় রাখবে
  initAuthStateListener() {
    const auth = FirestoreDB.getAuth();
    if (!auth) {
      console.warn("Firebase Auth not loaded yet.");
      return;
    }

    auth.onAuthStateChanged(async (user) => {
      if (user) {
        console.log("Firebase Auth: Active session detected for:", user.email, "UID:", user.uid);
        try {
          const db = FirestoreDB.getDb();
          if (db) {
            // Requirement 4: Login করা user's UID দিয়ে Firestore-এর users/{uid} document থেকে role পড়বে
            const userDoc = await db.collection('users').doc(user.uid).get();
            let role = 'visitor';
            let userData = { uid: user.uid, email: user.email };

            if (userDoc.exists) {
              const docData = userDoc.data();
              role = docData.role || 'visitor';
              userData = { ...userData, ...docData };
              console.log("Firestore users/" + user.uid + " role:", role);
            } else {
              console.warn("users/" + user.uid + " document not found in Firestore.");
            }

            // Auto-provision Super Admin in Firestore for project owner if not already created
            if (!userDoc.exists || role === 'visitor') {
              if (user.email === 'jubairahmad8000@gmail.com' || (AppState.settings.email && user.email.toLowerCase() === AppState.settings.email.toLowerCase())) {
                role = 'super_admin';
                const superAdminDoc = {
                  uid: user.uid,
                  name: 'মুহাম্মদ যুবায়ের আহমদ',
                  email: user.email,
                  role: 'super_admin',
                  permissions: ['all'],
                  createdAt: new Date().toISOString()
                };
                try {
                  await db.collection('users').doc(user.uid).set(superAdminDoc, { merge: true });
                  await db.collection('admins').doc(user.uid).set(superAdminDoc, { merge: true });
                  console.log("Auto-provisioned Super Admin in Firestore for:", user.email);
                } catch (wErr) {
                  console.warn("Auto-provision super_admin notice:", wErr);
                }
                userData = { ...userData, ...superAdminDoc };
              }
            }

            // Requirement 5: role === "super_admin" হলে Super Admin access দেবে
            if (role === 'super_admin') {
              AppState.currentUser = {
                id: user.uid,
                uid: user.uid,
                name: userData.name || userData.displayName || 'মুহাম্মদ যুবায়ের আহমদ',
                email: user.email,
                role: 'super_admin',
                permissions: ['all']
              };
              AppState.userRole = 'super_admin';
              FirestoreSync.initAdminSync();
            } else if (role === 'admin') {
              AppState.currentUser = {
                id: user.uid,
                uid: user.uid,
                name: userData.name || userData.displayName || 'কর্মকর্তা এডমিন',
                email: user.email,
                role: 'admin',
                permissions: userData.permissions || ['read', 'write']
              };
              AppState.userRole = 'admin';
              FirestoreSync.initAdminSync();
            } else {
              AppState.currentUser = null;
              AppState.userRole = 'visitor';
              FirestoreSync.stopAdminSync();
            }
          }
        } catch (err) {
          console.error("Auth state user check error:", err);
        }
      } else {
        console.log("Firebase Auth: No user currently authenticated.");
        AppState.currentUser = null;
        AppState.userRole = 'visitor';
        FirestoreSync.stopAdminSync();
      }

      App.updateAuthUI();
      // If currently on admin page and user is not admin, route home
      if (document.getElementById('sec-admin')?.classList.contains('active')) {
        if (AppState.currentUser) {
          Admin.renderTab();
        } else {
          App.navigateTo('home');
        }
      }
    });
  },

  // Requirement 1: Firebase Authentication-এর Email/Password login সংযুক্ত করো
  async handleAdminLogin(e) {
    e.preventDefault();
    const email = document.getElementById('loginEmail').value.trim();
    const pass = document.getElementById('loginPassword').value;
    const btnSubmit = document.getElementById('btnLoginSubmit');

    const auth = FirestoreDB.getAuth();
    const db = FirestoreDB.getDb();

    if (!auth || !db) {
      showToast('Firebase সংযোগ এখনও প্রস্তুত নয়, অনুগ্রহ করে কিছুক্ষণ পর চেষ্টা করুন।', 'error');
      return;
    }

    if (btnSubmit) {
      btnSubmit.disabled = true;
      btnSubmit.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> যাচাই করা হচ্ছে...';
    }

    try {
      // 1. Firebase Authentication login
      const cred = await auth.signInWithEmailAndPassword(email, pass);
      const user = cred.user;

      // 4. Login করা user's UID দিয়ে Firestore-এর users/{uid} document থেকে role পড়বে
      let role = 'visitor';
      let userData = { uid: user.uid, email: user.email };

      try {
        const userDoc = await db.collection('users').doc(user.uid).get();
        if (userDoc.exists) {
          const docData = userDoc.data();
          role = docData.role || 'visitor';
          userData = { ...userData, ...docData };
        } else {
          console.warn(`users/${user.uid} document not found in Firestore.`);
        }

        // Auto-provision Super Admin in Firestore for project owner if not already created
        if (!userDoc.exists || role === 'visitor') {
          if (user.email === 'jubairahmad8000@gmail.com' || (AppState.settings.email && user.email.toLowerCase() === AppState.settings.email.toLowerCase())) {
            role = 'super_admin';
            const superAdminDoc = {
              uid: user.uid,
              name: 'মুহাম্মদ যুবায়ের আহমদ',
              email: user.email,
              role: 'super_admin',
              permissions: ['all'],
              createdAt: new Date().toISOString()
            };
            try {
              await db.collection('users').doc(user.uid).set(superAdminDoc, { merge: true });
              await db.collection('admins').doc(user.uid).set(superAdminDoc, { merge: true });
              console.log("Auto-provisioned Super Admin in Firestore for:", user.email);
            } catch (wErr) {
              console.warn("Auto-provision super_admin notice:", wErr);
            }
            userData = { ...userData, ...superAdminDoc };
          }
        }
      } catch (fErr) {
        console.error("Firestore read users/" + user.uid + " error:", fErr);
      }

      // 5. role === "super_admin" হলে Super Admin access দেবে
      if (role === 'super_admin') {
        AppState.currentUser = {
          id: user.uid,
          uid: user.uid,
          name: userData.name || userData.displayName || 'মুহাম্মদ যুবায়ের আহমদ',
          email: user.email,
          role: 'super_admin',
          permissions: ['all']
        };
        AppState.userRole = 'super_admin';
        FirestoreSync.initAdminSync();
        this.updateAuthUI();
        this.closeLoginModal();
        showToast(`স্বাগতম, সুপার এডমিন (${AppState.currentUser.name})`, 'success');
        this.navigateTo('admin');
        addAuditLog('Super Admin Login', user.uid, 'সুপার এডমিন সফলভাবে লগইন করেছেন');
      } else if (role === 'admin') {
        AppState.currentUser = {
          id: user.uid,
          uid: user.uid,
          name: userData.name || userData.displayName || 'কর্মকর্তা এডমিন',
          email: user.email,
          role: 'admin',
          permissions: userData.permissions || ['read', 'write']
        };
        AppState.userRole = 'admin';
        FirestoreSync.initAdminSync();
        this.updateAuthUI();
        this.closeLoginModal();
        showToast(`স্বাগতম, ${AppState.currentUser.name}`, 'success');
        this.navigateTo('admin');
        addAuditLog('Admin Login', user.uid, 'এডমিন সফলভাবে লগইন করেছেন');
      } else {
        // Not super_admin or admin
        await auth.signOut();
        AppState.currentUser = null;
        AppState.userRole = 'visitor';
        FirestoreSync.stopAdminSync();
        this.updateAuthUI();
        showToast(`অননুমোদিত প্রবেশ: আপনার নির্ধারিত Role হলো "${role}"। শুধুমাত্র "super_admin" বা "admin" একাউন্ট প্রবেশ করতে পারবেন।`, 'error');
      }
    } catch (err) {
      console.error("Firebase Login Error:", err);
      let errMsg = 'লগইন ব্যর্থ হয়েছে: ';
      if (err.code === 'auth/user-not-found') {
        errMsg += 'এই ইমেইলে কোনো একাউন্ট পাওয়া যায়নি।';
      } else if (err.code === 'auth/wrong-password') {
        errMsg += 'ভুল পাসওয়ার্ড। আবার চেষ্টা করুন।';
      } else if (err.code === 'auth/invalid-email') {
        errMsg += 'ইমেইল ফরম্যাট সঠিক নয়।';
      } else if (err.code === 'auth/user-disabled') {
        errMsg += 'এই একাউন্টটি সাময়িকভাবে বন্ধ আছে।';
      } else if (err.code === 'auth/too-many-requests') {
        errMsg += 'অতিরিক্ত ভুল চেষ্টার কারণে সাময়িকভাবে ব্লক করা হয়েছে। কিছুক্ষণ পর চেষ্টা করুন।';
      } else if (err.code === 'auth/network-request-failed') {
        errMsg += 'নেটওয়ার্ক বা ইন্টারনেট সংযোগ সমস্যা।';
      } else {
        errMsg += err.message || 'সঠিক তথ্য দিয়ে পুনরায় চেষ্টা করুন।';
      }
      showToast(errMsg, 'error');
    } finally {
      if (btnSubmit) {
        btnSubmit.disabled = false;
        btnSubmit.innerHTML = '<i class="fa-solid fa-right-to-bracket"></i> লগইন করুন';
      }
    }
  },

  async forgotPassword() {
    const email = document.getElementById('loginEmail').value.trim();
    if (!email) {
      showToast('অনুগ্রহ করে আপনার নিবন্ধিত ইমেইল ঠিকানা লিখুন', 'warning');
      return;
    }
    const auth = FirestoreDB.getAuth();
    if (!auth) {
      showToast('Firebase Authentication প্রস্তুত নয়।', 'error');
      return;
    }
    try {
      await auth.sendPasswordResetEmail(email);
      showToast(`${email} ঠিকানায় পাসওয়ার্ড রিসেট লিংক পাঠানো হয়েছে`, 'success');
    } catch (err) {
      console.error("Password reset error:", err);
      showToast('পাসওয়ার্ড রিসেট লিংক পাঠাতে ব্যর্থ: ' + (err.message || ''), 'error');
    }
  },

  async logout() {
    const auth = FirestoreDB.getAuth();
    if (auth) {
      try {
        await auth.signOut();
      } catch (err) {
        console.warn("SignOut error:", err);
      }
    }
    addAuditLog('Admin Logout', AppState.currentUser?.id || '', 'লগআউট করা হয়েছে');
    AppState.currentUser = null;
    AppState.userRole = 'visitor';
    FirestoreSync.stopAdminSync();
    this.updateAuthUI();
    this.navigateTo('home');
    showToast('সফলভাবে লগআউট করা হয়েছে', 'info');
  },

  updateAuthUI() {
    const authBtnText = document.getElementById('authBtnText');
    const adminNavLi = document.getElementById('adminNavLi');
    if (AppState.currentUser) {
      authBtnText.textContent = 'এডমিন প্যানেল';
      if (adminNavLi) adminNavLi.style.display = 'inline-block';
      const emailElem = document.getElementById('adminCurrentUserEmail');
      const roleElem = document.getElementById('adminUserRoleBadge');
      if (emailElem) emailElem.textContent = AppState.currentUser.email;
      if (roleElem) roleElem.textContent = AppState.userRole === 'super_admin' ? 'Super Admin' : 'Staff Admin';
    } else {
      authBtnText.textContent = 'লগইন';
      if (adminNavLi) adminNavLi.style.display = 'none';
    }
  },

  updateBadgeCounts() {
    const pendingMem = AppState.memberApplications.filter(a => a.status === 'pending').length;
    const pendingHelp = AppState.helpApplications.filter(a => a.status === 'pending').length;
    const pendingDon = AppState.donations.filter(d => d.status === 'pending').length;

    const b1 = document.getElementById('badgePendingMemberApps');
    const b2 = document.getElementById('badgePendingHelpApps');
    const b3 = document.getElementById('badgePendingDonations');

    if (b1) b1.textContent = pendingMem;
    if (b2) b2.textContent = pendingHelp;
    if (b3) b3.textContent = pendingDon;
  },

  closeDynamicModal() {
    document.getElementById('dynamicModal').classList.remove('show');
  }
};

// Admin Controller
const Admin = {
  toggleSidebar() {
    document.getElementById('adminSidebar')?.classList.toggle('show');
  },

  switchTab(tabId) {
    AppState.adminTab = tabId;
    document.querySelectorAll('.sidebar-menu a').forEach(a => a.classList.remove('active'));
    const activeLink = Array.from(document.querySelectorAll('.sidebar-menu a')).find(a => a.getAttribute('onclick')?.includes(tabId));
    if (activeLink) activeLink.classList.add('active');

    // Close mobile sidebar
    document.getElementById('adminSidebar')?.classList.remove('show');
    this.renderTab();
  },

  renderTab() {
    const vp = document.getElementById('adminTabViewport');
    const titleElem = document.getElementById('adminTabTitle');
    if (!vp) return;
    App.updateBadgeCounts();

    switch (AppState.adminTab) {
      case 'dash':
        titleElem.textContent = 'ড্যাশবোর্ড ওভারভিউ';
        this.renderDashboard(vp);
        break;
      case 'directors-list':
        titleElem.textContent = 'পরিচালনা পরিষদ ব্যবস্থাপনা';
        this.renderDirectorsMgmt(vp);
        break;
      case 'member-apps':
        titleElem.textContent = 'সদস্য হওয়ার আবেদনসমূহ';
        this.renderMemberAppsMgmt(vp);
        break;
      case 'members-list':
        titleElem.textContent = 'সদস্য তালিকা';
        this.renderMembersMgmt(vp);
        break;
      case 'member-payments':
        titleElem.textContent = 'সদস্যের মাসিক জমা ও চাঁদা';
        this.renderMemberPaymentsMgmt(vp);
        break;
      case 'help-apps':
        titleElem.textContent = 'সাহায্যের আবেদনসমূহ';
        this.renderHelpAppsMgmt(vp);
        break;
      case 'beneficiaries':
        titleElem.textContent = 'দরিদ্র/সেবাপ্রাপ্ত তালিকা';
        this.renderBeneficiariesMgmt(vp);
        break;
      case 'activities-mgmt':
        titleElem.textContent = 'ফাউন্ডেশনের কার্যক্রম';
        this.renderActivitiesMgmt(vp);
        break;
      case 'distribution-mgmt':
        titleElem.textContent = 'পণ্য/দ্রব্য বিতরণ হিসাব';
        this.renderDistributionMgmt(vp);
        break;
      case 'fund-mgmt':
        titleElem.textContent = 'ফান্ড ব্যবস্থাপনা';
        this.renderFundMgmt(vp);
        break;
      case 'expense-mgmt':
        titleElem.textContent = 'খরচের হিসাব';
        this.renderExpenseMgmt(vp);
        break;
      case 'donations-mgmt':
        titleElem.textContent = 'দানের রেকর্ড ও ভেরিফিকেশন';
        this.renderDonationsMgmt(vp);
        break;
      case 'reports':
        titleElem.textContent = 'রিপোর্ট ও ডাটা এক্সপোর্ট';
        this.renderReports(vp);
        break;
      case 'audit':
        titleElem.textContent = 'অডিট লগ (Security Audit)';
        this.renderAuditLogs(vp);
        break;
      case 'user-mgmt':
        titleElem.textContent = 'ইউজার ও এডমিন ব্যবস্থাপনা';
        this.renderUserMgmt(vp);
        break;
      case 'settings':
        titleElem.textContent = 'ফাউন্ডেশন ও ওয়েবসাইট সেটিংস';
        this.renderSettings(vp);
        break;
      default:
        this.renderDashboard(vp);
    }
  },

  renderDashboard(vp) {
    const fin = calculateFinances();
    const pendingMem = AppState.memberApplications.filter(a => a.status === 'pending').length;
    const pendingHelp = AppState.helpApplications.filter(a => a.status === 'pending').length;

    vp.innerHTML = `
      <div class="stats-grid mb-4">
        <div class="stat-card">
          <div class="stat-icon emerald"><i class="fa-solid fa-users"></i></div>
          <div class="stat-info">
            <h3>${AppState.members.length.toLocaleString('bn-BD')}</h3>
            <p>মোট সদস্য</p>
          </div>
        </div>
        <div class="stat-card">
          <div class="stat-icon gold"><i class="fa-solid fa-users-viewfinder"></i></div>
          <div class="stat-info">
            <h3>${AppState.directors.length.toLocaleString('bn-BD')}</h3>
            <p>মোট পরিচালক</p>
          </div>
        </div>
        <div class="stat-card">
          <div class="stat-icon green"><i class="fa-solid fa-vault"></i></div>
          <div class="stat-info">
            <h3>৳ ${fin.currentBalance.toLocaleString('bn-BD')}</h3>
            <p>মোট ফান্ড ব্যালেন্স</p>
          </div>
        </div>
        <div class="stat-card">
          <div class="stat-icon gold"><i class="fa-solid fa-hand-holding-dollar"></i></div>
          <div class="stat-info">
            <h3>৳ ${fin.zakatBalance.toLocaleString('bn-BD')}</h3>
            <p>জাকাত ফান্ড ব্যালেন্স</p>
          </div>
        </div>
        <div class="stat-card">
          <div class="stat-icon blue"><i class="fa-solid fa-coins"></i></div>
          <div class="stat-info">
            <h3>৳ ${fin.generalBalance.toLocaleString('bn-BD')}</h3>
            <p>সাধারণ ফান্ড ব্যালেন্স</p>
          </div>
        </div>
        <div class="stat-card">
          <div class="stat-icon green"><i class="fa-solid fa-calendar-day"></i></div>
          <div class="stat-info">
            <h3>৳ ${fin.todayIncome.toLocaleString('bn-BD')}</h3>
            <p>আজকের জমা</p>
          </div>
        </div>
        <div class="stat-card">
          <div class="stat-icon blue"><i class="fa-solid fa-money-bill-trend-up"></i></div>
          <div class="stat-info">
            <h3>৳ ${fin.totalIncome.toLocaleString('bn-BD')}</h3>
            <p>মোট জমা</p>
          </div>
        </div>
        <div class="stat-card">
          <div class="stat-icon red"><i class="fa-solid fa-money-bill-transfer"></i></div>
          <div class="stat-info">
            <h3>৳ ${fin.todayExpense.toLocaleString('bn-BD')}</h3>
            <p>আজকের খরচ</p>
          </div>
        </div>
        <div class="stat-card">
          <div class="stat-icon red"><i class="fa-solid fa-arrow-up-right-dots"></i></div>
          <div class="stat-info">
            <h3>৳ ${fin.totalExpense.toLocaleString('bn-BD')}</h3>
            <p>মোট খরচ</p>
          </div>
        </div>
        <div class="stat-card">
          <div class="stat-icon blue"><i class="fa-solid fa-boxes-packing"></i></div>
          <div class="stat-info">
            <h3>${AppState.distributions.length.toLocaleString('bn-BD')}</h3>
            <p>মোট বিতরণ</p>
          </div>
        </div>
        <div class="stat-card">
          <div class="stat-icon green"><i class="fa-solid fa-clipboard-user"></i></div>
          <div class="stat-info">
            <h3>${AppState.beneficiaries.length.toLocaleString('bn-BD')}</h3>
            <p>মোট সাহায্যপ্রাপ্ত</p>
          </div>
        </div>
        <div class="stat-card">
          <div class="stat-icon gold"><i class="fa-solid fa-user-clock"></i></div>
          <div class="stat-info">
            <h3>${pendingMem.toLocaleString('bn-BD')}</h3>
            <p>অপেক্ষমাণ সদস্য আবেদন</p>
          </div>
        </div>
        <div class="stat-card">
          <div class="stat-icon gold"><i class="fa-solid fa-hand-holding-medical"></i></div>
          <div class="stat-info">
            <h3>${pendingHelp.toLocaleString('bn-BD')}</h3>
            <p>অপেক্ষমাণ সাহায্য আবেদন</p>
          </div>
        </div>
      </div>

      <!-- Quick Action Cards -->
      <div class="about-card-grid">
        <div class="card-3d" style="padding:20px;">
          <h4 class="text-emerald mb-2"><i class="fa-solid fa-bolt"></i> দ্রুত অ্যাকশন</h4>
          <div style="display:flex; gap:10px; flex-wrap:wrap; margin-top:12px;">
            <button class="btn btn-sm btn-gold" onclick="Admin.openAddDirectorModal()">+ পরিচালক যোগ</button>
            <button class="btn btn-sm btn-emerald" onclick="Admin.openAddMemberModal()">+ নতুন সদস্য যোগ</button>
            <button class="btn btn-sm btn-outline" onclick="Admin.openAddExpenseModal()">+ নতুন খরচ যোগ</button>
            <button class="btn btn-sm btn-gold" onclick="Admin.openAddDistributionModal()">+ নতুন বিতরণ এন্ট্রি</button>
          </div>
        </div>
      </div>
    `;
  },

  // Directors Management
  renderDirectorsMgmt(vp) {
    vp.innerHTML = `
      <div class="table-card card-3d">
        <div class="table-card-header">
          <h3>পরিচালনা পরিষদ তালিকা (${AppState.directors.length} জন)</h3>
          <button class="btn btn-gold" onclick="Admin.openAddDirectorModal()"><i class="fa-solid fa-plus"></i> নতুন পরিচালক যোগ</button>
        </div>
        <div class="table-responsive">
          <table class="data-table">
            <thead>
              <tr>
                <th>ছবি</th>
                <th>নাম</th>
                <th>পদবি</th>
                <th>মোবাইল</th>
                <th>দায়িত্ব</th>
                <th>অ্যাকশন</th>
              </tr>
            </thead>
            <tbody>
              ${AppState.directors.length === 0 ? '<tr><td colspan="6" class="text-center">কোনো পরিচালক তথ্য নেই</td></tr>' : 
                AppState.directors.map((d, i) => `
                  <tr>
                    <td><img src="${d.photo || './assets/logo/logo.png'}" style="width:40px;height:40px;border-radius:50%;object-fit:cover;"></td>
                    <td><strong>${d.name}</strong></td>
                    <td>${d.designation}</td>
                    <td>${d.mobile || '---'}</td>
                    <td>${d.responsibility || '---'}</td>
                    <td>
                      <button class="btn btn-sm btn-outline" onclick="Admin.editDirector('${d.id}')"><i class="fa-solid fa-pen"></i></button>
                      <button class="btn btn-sm btn-outline-danger" onclick="Admin.deleteDirector('${d.id}')"><i class="fa-solid fa-trash"></i></button>
                    </td>
                  </tr>
                `).join('')
              }
            </tbody>
          </table>
        </div>
      </div>
    `;
  },

  openAddDirectorModal(directorId = null) {
    const isEdit = !!directorId;
    const d = isEdit ? AppState.directors.find(x => x.id === directorId) : {};
    const modal = document.getElementById('dynamicModal');
    document.getElementById('dynamicModalTitle').textContent = isEdit ? 'পরিচালক তথ্য সম্পাদনা' : 'নতুন পরিচালক যোগ করুন';
    document.getElementById('dynamicModalBody').innerHTML = `
      <form id="directorForm" onsubmit="Admin.saveDirector(event, '${directorId || ''}')">
        <div class="form-grid">
          <div class="form-group">
            <label>নাম <span class="req">*</span></label>
            <input type="text" id="dirName" required value="${d.name || ''}" placeholder="পরিচালকের নাম">
          </div>
          <div class="form-group">
            <label>পদবি <span class="req">*</span></label>
            <input type="text" id="dirDesignation" required value="${d.designation || ''}" placeholder="উদাঃ সভাপতি / সাধারণ সম্পাদক">
          </div>
          <div class="form-group">
            <label>মোবাইল নম্বর <span class="req">*</span></label>
            <input type="tel" id="dirMobile" required value="${d.mobile || ''}" placeholder="01XXXXXXXXX">
          </div>
          <div class="form-group">
            <label>ঠিকানা</label>
            <input type="text" id="dirAddress" value="${d.address || ''}" placeholder="ঠিকানা">
          </div>
          <div class="form-group full-width">
            <label>নির্দিষ্ট দায়িত্ব ও পরিচয়</label>
            <input type="text" id="dirResponsibility" value="${d.responsibility || ''}" placeholder="দায়িত্ব ও পরিচয়">
          </div>
          <div class="form-group full-width">
            <label>ছবি</label>
            <input type="file" id="dirPhoto" accept="image/*">
          </div>
        </div>
        <div class="modal-footer" style="padding:0; margin-top:20px;">
          <button type="button" class="btn btn-outline" onclick="App.closeDynamicModal()">বাতিল</button>
          <button type="submit" class="btn btn-gold">সংরক্ষণ করুন</button>
        </div>
      </form>
    `;
    modal.classList.add('show');
  },

  saveDirector(e, dirId) {
    e.preventDefault();
    const name = document.getElementById('dirName').value.trim();
    const designation = document.getElementById('dirDesignation').value.trim();
    const mobile = document.getElementById('dirMobile').value.trim();
    const address = document.getElementById('dirAddress').value.trim();
    const responsibility = document.getElementById('dirResponsibility').value.trim();
    const photoInput = document.getElementById('dirPhoto');

    const finish = (photoUrl) => {
      if (dirId) {
        const idx = AppState.directors.findIndex(x => x.id === dirId);
        if (idx !== -1) {
          AppState.directors[idx] = {
            ...AppState.directors[idx],
            name, designation, mobile, address, responsibility,
            photo: photoUrl || AppState.directors[idx].photo
          };
          addAuditLog('Director Updated', dirId, name);
        }
      } else {
        const newDir = {
          id: 'dir-' + Date.now(),
          name, designation, mobile, address, responsibility,
          photo: photoUrl,
          createdAt: new Date().toISOString()
        };
        AppState.directors.push(newDir);
        addAuditLog('Director Added', newDir.id, name);
      }
      const savedDir = dirId ? AppState.directors.find(x => x.id === dirId) : AppState.directors[AppState.directors.length - 1];
      if (savedDir) FirestoreDB.setDoc('directors', savedDir.id, savedDir);
      DB.save();
      App.closeDynamicModal();
      showToast('পরিচালক তথ্য সফলভাবে সংরক্ষিত হয়েছে', 'success');
      Admin.renderTab();
      App.renderPublicUI();
    };

    if (photoInput.files && photoInput.files[0]) {
      const reader = new FileReader();
      reader.onload = ev => finish(ev.target.result);
      reader.readAsDataURL(photoInput.files[0]);
    } else {
      finish('');
    }
  },

  deleteDirector(dirId) {
    if (AppState.userRole !== 'super_admin') {
      showToast('শুধুমাত্র সুপার এডমিন পরিচালক মুছতে পারবেন', 'error');
      return;
    }
    if (!confirm('আপনি কি নিশ্চিত যে এই পরিচালকের তথ্য মুছে ফেলতে চান?')) return;
    AppState.directors = AppState.directors.filter(x => x.id !== dirId);
    FirestoreDB.deleteDoc('directors', dirId);
    addAuditLog('Director Deleted', dirId);
    DB.save();
    showToast('পরিচালক মুছে ফেলা হয়েছে', 'info');
    Admin.renderTab();
    App.renderPublicUI();
  },

  // Member Applications Management
  renderMemberAppsMgmt(vp) {
    vp.innerHTML = `
      <div class="table-card card-3d">
        <div class="table-card-header">
          <h3>সদস্য হওয়ার আবেদন তালিকা (${AppState.memberApplications.length} টি)</h3>
        </div>
        <div class="table-responsive">
          <table class="data-table">
            <thead>
              <tr>
                <th>আবেদন নং</th>
                <th>তারিখ</th>
                <th>নাম</th>
                <th>পিতা</th>
                <th>মোবাইল</th>
                <th>মাসিক চাঁদা</th>
                <th>স্ট্যাটাস</th>
                <th>অ্যাকশন</th>
              </tr>
            </thead>
            <tbody>
              ${AppState.memberApplications.length === 0 ? '<tr><td colspan="8" class="text-center">কোনো সদস্য আবেদন জমা পড়েনি</td></tr>' :
                AppState.memberApplications.map(app => `
                  <tr>
                    <td><strong>${app.appNumber}</strong></td>
                    <td>${app.date}</td>
                    <td>${app.name}</td>
                    <td>${app.father}</td>
                    <td>${app.mobile}</td>
                    <td>৳ ${Number(app.monthlyPledge).toLocaleString('bn-BD')}</td>
                    <td>
                      <span class="badge ${app.status === 'approved' ? 'badge-success' : (app.status === 'rejected' ? 'badge-danger' : 'badge-warning')}">
                        ${app.status === 'approved' ? 'অনুমোদিত' : (app.status === 'rejected' ? 'বাতিল' : 'অপেক্ষমাণ')}
                      </span>
                    </td>
                    <td>
                      ${app.status === 'pending' ? `
                        <button class="btn btn-sm btn-emerald" onclick="Admin.approveMemberApp('${app.id}')"><i class="fa-solid fa-check"></i> অনুমোদন</button>
                        <button class="btn btn-sm btn-outline-danger" onclick="Admin.rejectMemberApp('${app.id}')"><i class="fa-solid fa-xmark"></i> বাতিল</button>
                      ` : `
                        <button class="btn btn-sm btn-outline" onclick="Admin.viewMemberApp('${app.id}')">বিবরণ</button>
                      `}
                      ${AppState.userRole === 'super_admin' ? `
                        <button class="btn btn-sm btn-outline-danger" onclick="Admin.deleteMemberApp('${app.id}')" title="মুছে ফেলুন"><i class="fa-solid fa-trash"></i></button>
                      ` : ''}
                    </td>
                  </tr>
                `).join('')
              }
            </tbody>
          </table>
        </div>
      </div>
    `;
  },

  approveMemberApp(appId) {
    const app = AppState.memberApplications.find(a => a.id === appId);
    if (!app) return;

    // Generate unique serial & Form Number
    const serial = AppState.members.length + 1;
    const formNumber = 'MEM-' + String(serial).padStart(4, '0');

    const newMember = {
      id: 'mem-' + Date.now(),
      serial,
      formNumber,
      name: app.name,
      father: app.father,
      village: app.village,
      thana: app.thana,
      district: app.district,
      occupation: app.occupation,
      bloodGroup: app.bloodGroup,
      mobile: app.mobile,
      joiningDate: new Date().toISOString().split('T')[0],
      monthlyDue: Number(app.monthlyPledge) || 500,
      photo: app.photo,
      status: 'active'
    };

    app.status = 'approved';
    AppState.members.push(newMember);
    addAuditLog('Member Application Approved', appId, `সদস্য আইডি: ${formNumber}, নাম: ${app.name}`);
    DB.save();
    FirestoreDB.setDoc('memberApplications', app.id, app);
    FirestoreDB.setDoc('members', newMember.id, newMember);
    showToast(`আবেদনটি অনুমোদিত হয়েছে এবং সদস্য তালিকায় যুক্ত হয়েছে (ফরম নং: ${formNumber})`, 'success');
    Admin.renderTab();
    App.renderPublicUI();
  },

  rejectMemberApp(appId) {
    const app = AppState.memberApplications.find(a => a.id === appId);
    if (!app) return;
    app.status = 'rejected';
    addAuditLog('Member Application Rejected', appId, app.name);
    DB.save();
    FirestoreDB.setDoc('memberApplications', app.id, app);
    showToast('আবেদনটি বাতিল করা হয়েছে', 'warning');
    Admin.renderTab();
  },

  deleteMemberApp(appId) {
    if (AppState.userRole !== 'super_admin') {
      showToast('শুধুমাত্র সুপার এডমিন আবেদন মুছতে পারবেন', 'error');
      return;
    }
    if (!confirm('আবেদনটি স্থায়ীভাবে মুছে ফেলতে চান?')) return;
    AppState.memberApplications = AppState.memberApplications.filter(a => a.id !== appId);
    FirestoreDB.deleteDoc('memberApplications', appId);
    addAuditLog('Member Application Deleted', appId);
    DB.save();
    showToast('আবেদন সফলভাবে মুছে ফেলা হয়েছে', 'info');
    Admin.renderTab();
  },

  viewMemberApp(appId) {
    const app = AppState.memberApplications.find(a => a.id === appId);
    if (!app) return;
    const modal = document.getElementById('dynamicModal');
    document.getElementById('dynamicModalTitle').textContent = `আবেদন বিবরণ: ${app.appNumber}`;
    document.getElementById('dynamicModalBody').innerHTML = `
      <div style="text-align:center; margin-bottom:16px;">
        <img src="${app.photo || './assets/logo/logo.png'}" style="width:100px;height:100px;border-radius:50%;object-fit:cover;border:2px solid var(--gold);">
        <h3>${app.name}</h3>
        <p class="text-muted">পিতা: ${app.father}</p>
      </div>
      <div class="form-grid">
        <div><strong>গ্রাম/ঠিকানা:</strong> ${app.village}, ${app.thana}, ${app.district}</div>
        <div><strong>পেশা:</strong> ${app.occupation}</div>
        <div><strong>রক্তের গ্রুপ:</strong> ${app.bloodGroup || '---'}</div>
        <div><strong>মোবাইল:</strong> ${app.mobile}</div>
        <div><strong>প্রতিশ্রুত মাসিক চাঁদা:</strong> ৳ ${app.monthlyPledge}</div>
        <div><strong>আবেদনের তারিখ:</strong> ${app.date}</div>
        <div class="full-width"><strong>আবেদনের কারণ:</strong> ${app.reason}</div>
      </div>
    `;
    modal.classList.add('show');
  },

  // Member Management
  renderMembersMgmt(vp) {
    vp.innerHTML = `
      <div class="table-card card-3d">
        <div class="table-card-header">
          <h3>সদস্য তালিকা (${AppState.members.length} জন)</h3>
          <button class="btn btn-gold" onclick="Admin.openAddMemberModal()"><i class="fa-solid fa-plus"></i> নতুন সদস্য এন্ট্রি</button>
        </div>
        <div class="table-responsive">
          <table class="data-table">
            <thead>
              <tr>
                <th>ক্রমিক</th>
                <th>ফরম নং</th>
                <th>ছবি</th>
                <th>নাম</th>
                <th>পিতা</th>
                <th>মোবাইল</th>
                <th>মাসিক চাঁদা</th>
                <th>স্ট্যাটাস</th>
                <th>অ্যাকশন</th>
              </tr>
            </thead>
            <tbody>
              ${AppState.members.length === 0 ? '<tr><td colspan="9" class="text-center">কোনো সদস্য তথ্য পাওয়া যায়নি</td></tr>' :
                AppState.members.map(m => `
                  <tr>
                    <td>${m.serial}</td>
                    <td><strong>${m.formNumber}</strong></td>
                    <td><img src="${m.photo || './assets/logo/logo.png'}" style="width:36px;height:36px;border-radius:50%;object-fit:cover;"></td>
                    <td>${m.name}</td>
                    <td>${m.father}</td>
                    <td>${m.mobile}</td>
                    <td>৳ ${Number(m.monthlyDue).toLocaleString('bn-BD')}</td>
                    <td><span class="badge ${m.status === 'active' ? 'badge-success' : 'badge-danger'}">${m.status === 'active' ? 'সক্রিয়' : 'স্থগিত'}</span></td>
                    <td>
                      <button class="btn btn-sm btn-outline" onclick="Admin.viewMemberProfile('${m.id}')">প্রোফাইল</button>
                      ${AppState.userRole === 'super_admin' ? `
                        <button class="btn btn-sm btn-outline-danger" onclick="Admin.deleteMember('${m.id}')"><i class="fa-solid fa-trash"></i></button>
                      ` : ''}
                    </td>
                  </tr>
                `).join('')
              }
            </tbody>
          </table>
        </div>
      </div>
    `;
  },

  openAddMemberModal() {
    const serial = AppState.members.length + 1;
    const formNumber = 'MEM-' + String(serial).padStart(4, '0');
    const modal = document.getElementById('dynamicModal');
    document.getElementById('dynamicModalTitle').textContent = 'নতুন সদস্য নিবন্ধন';
    document.getElementById('dynamicModalBody').innerHTML = `
      <form id="newMemberForm" onsubmit="Admin.saveDirectMember(event, '${formNumber}', ${serial})">
        <div class="form-grid">
          <div class="form-group">
            <label>সদস্য ফরম নং</label>
            <input type="text" value="${formNumber}" readonly style="background:#EEE;">
          </div>
          <div class="form-group">
            <label>সদস্যের নাম <span class="req">*</span></label>
            <input type="text" id="dmName" required placeholder="নাম">
          </div>
          <div class="form-group">
            <label>পিতার নাম <span class="req">*</span></label>
            <input type="text" id="dmFather" required placeholder="পিতার নাম">
          </div>
          <div class="form-group">
            <label>গ্রাম <span class="req">*</span></label>
            <input type="text" id="dmVillage" required placeholder="গ্রাম">
          </div>
          <div class="form-group">
            <label>থানা <span class="req">*</span></label>
            <input type="text" id="dmThana" required value="মুক্তাগাছা">
          </div>
          <div class="form-group">
            <label>জেলা <span class="req">*</span></label>
            <input type="text" id="dmDistrict" required value="মোমেনশাহী">
          </div>
          <div class="form-group">
            <label>পেশা <span class="req">*</span></label>
            <input type="text" id="dmOccupation" required placeholder="পেশা">
          </div>
          <div class="form-group">
            <label>রক্তের গ্রুপ</label>
            <input type="text" id="dmBlood" placeholder="রক্তের গ্রুপ">
          </div>
          <div class="form-group">
            <label>মোবাইল <span class="req">*</span></label>
            <input type="tel" id="dmMobile" required placeholder="01XXXXXXXXX">
          </div>
          <div class="form-group">
            <label>মাসিক নির্ধারিত টাকা <span class="req">*</span></label>
            <input type="number" id="dmDue" required value="500">
          </div>
          <div class="form-group full-width">
            <label>ছবি</label>
            <input type="file" id="dmPhoto" accept="image/*">
          </div>
        </div>
        <div class="modal-footer" style="padding:0; margin-top:20px;">
          <button type="button" class="btn btn-outline" onclick="App.closeDynamicModal()">বাতিল</button>
          <button type="submit" class="btn btn-gold">নিবন্ধন সম্পন্ন করুন</button>
        </div>
      </form>
    `;
    modal.classList.add('show');
  },

  saveDirectMember(e, formNumber, serial) {
    e.preventDefault();
    const name = document.getElementById('dmName').value.trim();
    const father = document.getElementById('dmFather').value.trim();
    const village = document.getElementById('dmVillage').value.trim();
    const thana = document.getElementById('dmThana').value.trim();
    const district = document.getElementById('dmDistrict').value.trim();
    const occupation = document.getElementById('dmOccupation').value.trim();
    const bloodGroup = document.getElementById('dmBlood').value.trim();
    const mobile = document.getElementById('dmMobile').value.trim();
    const monthlyDue = Number(document.getElementById('dmDue').value);
    const photoInput = document.getElementById('dmPhoto');

    const finish = (photoUrl) => {
      const newMember = {
        id: 'mem-' + Date.now(),
        serial,
        formNumber,
        name,
        father,
        village,
        thana,
        district,
        occupation,
        bloodGroup,
        mobile,
        joiningDate: new Date().toISOString().split('T')[0],
        monthlyDue,
        photo: photoUrl,
        status: 'active'
      };
      AppState.members.push(newMember);
      addAuditLog('Member Added Directly', newMember.id, name);
      DB.save();
      FirestoreDB.setDoc('members', newMember.id, newMember);
      App.closeDynamicModal();
      showToast(`সদস্য সফলভাবে নিবন্ধিত হয়েছে (ফরম নং: ${formNumber})`, 'success');
      Admin.renderTab();
      App.renderPublicUI();
    };

    if (photoInput.files && photoInput.files[0]) {
      const reader = new FileReader();
      reader.onload = ev => finish(ev.target.result);
      reader.readAsDataURL(photoInput.files[0]);
    } else {
      finish('');
    }
  },

  deleteMember(memId) {
    if (AppState.userRole !== 'super_admin') {
      showToast('শুধুমাত্র সুপার এডমিন সদস্য মুছতে পারবেন', 'error');
      return;
    }
    if (!confirm('সদস্য মুছে ফেললে তার সিরিয়াল নম্বর অন্য কাউকে দেওয়া যাবে না। আপনি কি নিশ্চিত?')) return;
    AppState.members = AppState.members.filter(m => m.id !== memId);
    FirestoreDB.deleteDoc('members', memId);
    addAuditLog('Member Deleted', memId);
    DB.save();
    showToast('সদস্য মুছে ফেলা হয়েছে', 'info');
    Admin.renderTab();
    App.renderPublicUI();
  },

  viewMemberProfile(memId) {
    const m = AppState.members.find(x => x.id === memId);
    if (!m) return;
    const payments = AppState.memberPayments.filter(p => p.memberId === memId);
    const totalPaid = payments.reduce((s, p) => s + Number(p.amount || 0), 0);

    const modal = document.getElementById('dynamicModal');
    document.getElementById('dynamicModalTitle').textContent = `সদস্য প্রোফাইল: ${m.name} (${m.formNumber})`;
    document.getElementById('dynamicModalBody').innerHTML = `
      <div style="text-align:center; margin-bottom:16px;">
        <img src="${m.photo || './assets/logo/logo.png'}" style="width:110px;height:110px;border-radius:50%;object-fit:cover;border:3px solid var(--gold);">
        <h3>${m.name}</h3>
        <p class="text-gold" style="font-weight:700;">ফরম নং: ${m.formNumber} | ক্রমিক: ${m.serial}</p>
        <span class="badge ${m.status === 'active' ? 'badge-success' : 'badge-danger'}">${m.status === 'active' ? 'সক্রিয় সদস্য' : 'স্থগিত সদস্য'}</span>
      </div>
      <div class="form-grid mb-4">
        <div><strong>পিতার নাম:</strong> ${m.father}</div>
        <div><strong>ঠিকানা:</strong> ${m.village}, ${m.thana}, ${m.district}</div>
        <div><strong>পেশা:</strong> ${m.occupation}</div>
        <div><strong>রক্তের গ্রুপ:</strong> ${m.bloodGroup || '---'}</div>
        <div><strong>মোবাইল:</strong> ${m.mobile}</div>
        <div><strong>যোগদানের তারিখ:</strong> ${m.joiningDate}</div>
        <div><strong>নির্ধারিত মাসিক চাঁদা:</strong> ৳ ${Number(m.monthlyDue).toLocaleString('bn-BD')}</div>
        <div><strong>সর্বমোট জমা:</strong> ৳ ${totalPaid.toLocaleString('bn-BD')}</div>
      </div>
      <div style="display:flex; gap:10px; margin-bottom:20px; flex-wrap:wrap;">
        <button class="btn btn-sm btn-emerald" onclick="Admin.openEditMemberModal('${m.id}')"><i class="fa-solid fa-user-pen"></i> তথ্য সম্পাদনা</button>
        <button class="btn btn-sm btn-outline" onclick="Admin.toggleMemberStatus('${m.id}')"><i class="fa-solid fa-arrows-rotate"></i> স্ট্যাটাস (${m.status === 'active' ? 'স্থগিত করুন' : 'সক্রিয় করুন'})</button>
      </div>
      <h4 class="text-emerald mb-2"><i class="fa-solid fa-receipt"></i> মাসিক জমা ইতিহাস</h4>
      <div class="table-responsive">
        <table class="data-table">
          <thead>
            <tr>
              <th>মাস</th>
              <th>জমার তারিখ</th>
              <th>টাকার পরিমাণ</th>
              <th>Trx/রসিদ নং</th>
              <th>অ্যাকশন</th>
            </tr>
          </thead>
          <tbody>
            ${payments.length === 0 ? '<tr><td colspan="5" class="text-center">এখনও কোনো জমা নেই</td></tr>' :
              payments.map(p => `
                <tr>
                  <td>${p.month} ${p.year}</td>
                  <td>${p.date}</td>
                  <td>৳ ${Number(p.amount).toLocaleString('bn-BD')}</td>
                  <td>${p.receiptNo || '---'}</td>
                  <td>
                    ${AppState.userRole === 'super_admin' ? `
                      <button class="btn btn-sm btn-outline-danger" onclick="Admin.deleteMemberPayment('${p.id}', '${m.id}')" title="জমা মুছুন"><i class="fa-solid fa-trash"></i></button>
                    ` : '---'}
                  </td>
                </tr>
              `).join('')
            }
          </tbody>
        </table>
      </div>
    `;
    modal.classList.add('show');
  },

  openEditMemberModal(memId) {
    const m = AppState.members.find(x => x.id === memId);
    if (!m) return;
    const modal = document.getElementById('dynamicModal');
    document.getElementById('dynamicModalTitle').textContent = `সদস্য তথ্য সম্পাদনা: ${m.name}`;
    document.getElementById('dynamicModalBody').innerHTML = `
      <form id="editMemberForm" onsubmit="Admin.saveEditMember(event, '${m.id}')">
        <div class="form-grid">
          <div class="form-group">
            <label>নাম <span class="req">*</span></label>
            <input type="text" id="emName" required value="${m.name}">
          </div>
          <div class="form-group">
            <label>পিতার নাম <span class="req">*</span></label>
            <input type="text" id="emFather" required value="${m.father}">
          </div>
          <div class="form-group">
            <label>গ্রাম <span class="req">*</span></label>
            <input type="text" id="emVillage" required value="${m.village}">
          </div>
          <div class="form-group">
            <label>থানা <span class="req">*</span></label>
            <input type="text" id="emThana" required value="${m.thana}">
          </div>
          <div class="form-group">
            <label>জেলা <span class="req">*</span></label>
            <input type="text" id="emDistrict" required value="${m.district}">
          </div>
          <div class="form-group">
            <label>মোবাইল নম্বর <span class="req">*</span></label>
            <input type="tel" id="emMobile" required value="${m.mobile}">
          </div>
          <div class="form-group">
            <label>পেশা</label>
            <input type="text" id="emOccupation" value="${m.occupation || ''}">
          </div>
          <div class="form-group">
            <label>নির্ধারিত মাসিক চাঁদা (৳) <span class="req">*</span></label>
            <input type="number" id="emDue" required value="${m.monthlyDue}">
          </div>
        </div>
        <div class="modal-footer" style="padding:0; margin-top:20px;">
          <button type="button" class="btn btn-outline" onclick="App.closeDynamicModal()">বাতিল</button>
          <button type="submit" class="btn btn-gold">পরিবর্তন সংরক্ষণ করুন</button>
        </div>
      </form>
    `;
    modal.classList.add('show');
  },

  saveEditMember(e, memId) {
    e.preventDefault();
    const m = AppState.members.find(x => x.id === memId);
    if (!m) return;
    m.name = document.getElementById('emName').value.trim();
    m.father = document.getElementById('emFather').value.trim();
    m.village = document.getElementById('emVillage').value.trim();
    m.thana = document.getElementById('emThana').value.trim();
    m.district = document.getElementById('emDistrict').value.trim();
    m.mobile = document.getElementById('emMobile').value.trim();
    m.occupation = document.getElementById('emOccupation').value.trim();
    m.monthlyDue = Number(document.getElementById('emDue').value);

    addAuditLog('Member Updated', memId, m.name);
    DB.save();
    FirestoreDB.setDoc('members', memId, m);
    App.closeDynamicModal();
    showToast('সদস্য তথ্য সফলভাবে আপডেট হয়েছে', 'success');
    Admin.renderTab();
    App.renderPublicUI();
  },

  toggleMemberStatus(memId) {
    const m = AppState.members.find(x => x.id === memId);
    if (!m) return;
    m.status = m.status === 'active' ? 'inactive' : 'active';
    addAuditLog('Member Status Changed', memId, `${m.name} -> ${m.status}`);
    DB.save();
    FirestoreDB.setDoc('members', memId, m);
    showToast(`সদস্য স্ট্যাটাস ${m.status === 'active' ? 'সক্রিয়' : 'স্থগিত'} করা হয়েছে`, 'info');
    Admin.viewMemberProfile(memId);
    Admin.renderTab();
    App.renderPublicUI();
  },

  deleteMemberPayment(paymentId, memId) {
    if (AppState.userRole !== 'super_admin') {
      showToast('শুধুমাত্র সুপার এডমিন জমা মুছতে পারবেন', 'error');
      return;
    }
    if (!confirm('এই মাসিক জমা রেকর্ডটি মুছে ফেলতে চান?')) return;
    AppState.memberPayments = AppState.memberPayments.filter(p => p.id !== paymentId);
    FirestoreDB.deleteDoc('memberPayments', paymentId);
    addAuditLog('Member Payment Deleted', paymentId);
    DB.save();
    showToast('জমা রেকর্ড সফলভাবে মুছে ফেলা হয়েছে', 'info');
    if (memId) {
      Admin.viewMemberProfile(memId);
    }
    Admin.renderTab();
    App.renderPublicUI();
  },

  // Member Payments (Jan - Dec)
  renderMemberPaymentsMgmt(vp) {
    const currentYear = new Date().getFullYear();
    const months = ['জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন', 'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'];

    vp.innerHTML = `
      <div class="table-card card-3d">
        <div class="table-card-header">
          <h3>সদস্যের মাসিক চাঁদা আদায় ও বকেয়া (${currentYear})</h3>
          <button class="btn btn-gold" onclick="Admin.openAddPaymentModal()"><i class="fa-solid fa-plus"></i> চাঁদা জমা এন্ট্রি</button>
        </div>
        <div class="table-responsive">
          <table class="data-table">
            <thead>
              <tr>
                <th>ফরম নং</th>
                <th>সদস্যের নাম</th>
                <th>মাসিক হার</th>
                <th>মোট আদায়</th>
                <th>স্ট্যাটাস</th>
                <th>অ্যাকশন</th>
              </tr>
            </thead>
            <tbody>
              ${AppState.members.length === 0 ? '<tr><td colspan="6" class="text-center">কোনো সদস্য তথ্য নেই</td></tr>' :
                AppState.members.map(m => {
                  const pms = AppState.memberPayments.filter(p => p.memberId === m.id);
                  const totalPaid = pms.reduce((s, p) => s + Number(p.amount || 0), 0);
                  const isDue = totalPaid === 0;
                  return `
                    <tr>
                      <td><strong>${m.formNumber}</strong></td>
                      <td>${m.name}</td>
                      <td>৳ ${Number(m.monthlyDue).toLocaleString('bn-BD')}</td>
                      <td>৳ ${totalPaid.toLocaleString('bn-BD')}</td>
                      <td>
                        <span class="badge ${isDue ? 'badge-danger' : 'badge-success'}">
                          ${isDue ? 'বকেয়া' : 'পরিশোধিত'}
                        </span>
                      </td>
                      <td>
                        <button class="btn btn-sm btn-emerald" onclick="Admin.openAddPaymentModal('${m.id}')">+ চাঁদা গ্রহণ</button>
                      </td>
                    </tr>
                  `;
                }).join('')
              }
            </tbody>
          </table>
        </div>
      </div>
    `;
  },

  openAddPaymentModal(memberId = '') {
    const months = ['জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন', 'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'];
    const currentYear = new Date().getFullYear();
    const modal = document.getElementById('dynamicModal');
    document.getElementById('dynamicModalTitle').textContent = 'সদস্যের চাঁদা / মাসিক জমা গ্রহণ';
    document.getElementById('dynamicModalBody').innerHTML = `
      <form id="payForm" onsubmit="Admin.saveMemberPayment(event)">
        <div class="form-grid">
          <div class="form-group full-width">
            <label>সদস্য নির্বাচন করুন <span class="req">*</span></label>
            <select id="payMemberId" required>
              <option value="">সদস্য বাছাই করুন</option>
              ${AppState.members.map(m => `
                <option value="${m.id}" ${m.id === memberId ? 'selected' : ''}>${m.formNumber} - ${m.name}</option>
              `).join('')}
            </select>
          </div>
          <div class="form-group">
            <label>মাস <span class="req">*</span></label>
            <select id="payMonth" required>
              ${months.map(m => `<option value="${m}">${m}</option>`).join('')}
            </select>
          </div>
          <div class="form-group">
            <label>বছর <span class="req">*</span></label>
            <input type="number" id="payYear" required value="${currentYear}">
          </div>
          <div class="form-group">
            <label>টাকার পরিমাণ <span class="req">*</span></label>
            <input type="number" id="payAmount" required min="10" placeholder="টাকা">
          </div>
          <div class="form-group">
            <label>রসিদ / TrxID</label>
            <input type="text" id="payReceipt" placeholder="রসিদ নম্বর">
          </div>
        </div>
        <div class="modal-footer" style="padding:0; margin-top:20px;">
          <button type="button" class="btn btn-outline" onclick="App.closeDynamicModal()">বাতিল</button>
          <button type="submit" class="btn btn-emerald">জমা নিশ্চিত করুন</button>
        </div>
      </form>
    `;
    modal.classList.add('show');
  },

  saveMemberPayment(e) {
    e.preventDefault();
    const memberId = document.getElementById('payMemberId').value;
    const month = document.getElementById('payMonth').value;
    const year = document.getElementById('payYear').value;
    const amount = Number(document.getElementById('payAmount').value);
    const receiptNo = document.getElementById('payReceipt').value.trim();

    const mem = AppState.members.find(m => m.id === memberId);
    if (!mem) return;

    const newPayment = {
      id: 'pay-' + Date.now(),
      memberId,
      memberName: mem.name,
      formNumber: mem.formNumber,
      month,
      year,
      amount,
      receiptNo,
      date: new Date().toISOString().split('T')[0],
      enteredBy: AppState.currentUser?.name || 'এডমিন'
    };

    AppState.memberPayments.push(newPayment);
    addAuditLog('Member Payment Recorded', newPayment.id, `${mem.name} (${month} ${year}): ৳${amount}`);
    DB.save();
    FirestoreDB.setDoc('memberPayments', newPayment.id, newPayment);
    App.closeDynamicModal();
    showToast(`মাসিক চাঁদা ৳ ${amount} সফলভাবে জমা হয়েছে`, 'success');
    Admin.renderTab();
    App.renderPublicUI();
  },

  // Help Applications Management
  renderHelpAppsMgmt(vp) {
    vp.innerHTML = `
      <div class="table-card card-3d">
        <div class="table-card-header">
          <h3>সাহায্যের আবেদন তালিকা (${AppState.helpApplications.length} টি)</h3>
        </div>
        <div class="table-responsive">
          <table class="data-table">
            <thead>
              <tr>
                <th>আবেদন নং</th>
                <th>তারিখ</th>
                <th>আবেদনকারী</th>
                <th>এলাকা</th>
                <th>মোবাইল</th>
                <th>সাহায্যের ধরন</th>
                <th>পরিমাণ / সামগ্রী</th>
                <th>স্ট্যাটাস</th>
                <th>অ্যাকশন</th>
              </tr>
            </thead>
            <tbody>
              ${AppState.helpApplications.length === 0 ? '<tr><td colspan="9" class="text-center">কোনো সাহায্য আবেদন নেই</td></tr>' :
                AppState.helpApplications.map(app => `
                  <tr>
                    <td><strong>${app.appNumber}</strong></td>
                    <td>${app.date}</td>
                    <td>${app.name}</td>
                    <td>${app.village}, ${app.thana}</td>
                    <td>${app.mobile}</td>
                    <td>${app.aidType}</td>
                    <td>${app.amount}</td>
                    <td>
                      <span class="badge ${app.status === 'approved' ? 'badge-success' : (app.status === 'rejected' ? 'badge-danger' : 'badge-warning')}">
                        ${app.status === 'approved' ? 'অনুমোদিত' : (app.status === 'rejected' ? 'বাতিল' : 'যাচাইাধীন')}
                      </span>
                    </td>
                    <td>
                      <button class="btn btn-sm btn-outline" onclick="Admin.viewHelpApp('${app.id}')">বিবরণ ও NID</button>
                      ${app.status === 'pending' ? `
                        <button class="btn btn-sm btn-emerald" onclick="Admin.approveHelpApp('${app.id}')">অনুমোদন</button>
                        <button class="btn btn-sm btn-outline-danger" onclick="Admin.rejectHelpApp('${app.id}')">বাতিল</button>
                      ` : ''}
                      ${AppState.userRole === 'super_admin' ? `
                        <button class="btn btn-sm btn-outline-danger" onclick="Admin.deleteHelpApp('${app.id}')" title="মুছে ফেলুন"><i class="fa-solid fa-trash"></i></button>
                      ` : ''}
                    </td>
                  </tr>
                `).join('')
              }
            </tbody>
          </table>
        </div>
      </div>
    `;
  },

  viewHelpApp(appId) {
    const app = AppState.helpApplications.find(a => a.id === appId);
    if (!app) return;
    const modal = document.getElementById('dynamicModal');
    document.getElementById('dynamicModalTitle').textContent = `সাহায্য আবেদন: ${app.name} (${app.appNumber})`;
    document.getElementById('dynamicModalBody').innerHTML = `
      <div style="display:flex; gap:20px; align-items:center; margin-bottom:20px; flex-wrap:wrap;">
        <img src="${app.photo || './assets/logo/logo.png'}" style="width:100px;height:100px;border-radius:50%;object-fit:cover;border:3px solid var(--primary-color);">
        <div>
          <h3>${app.name}</h3>
          <p><strong>পিতা/স্বামী:</strong> ${app.father} | <strong>লিঙ্গ:</strong> ${app.gender} | <strong>বয়স:</strong> ${app.age} বছর</p>
          <p><strong>মোবাইল:</strong> ${app.mobile} | <strong>ঠিকানা:</strong> ${app.village}, ${app.thana}, ${app.district}</p>
        </div>
      </div>
      <div class="form-grid mb-4">
        <div><strong>পেশা:</strong> ${app.occupation}</div>
        <div><strong>পরিবারের সদস্য:</strong> ${app.familyMembers} জন</div>
        <div><strong>মাসিক পারিবারিক আয়:</strong> ৳ ${Number(app.monthlyIncome).toLocaleString('bn-BD')}</div>
        <div><strong>প্রয়োজনীয় সাহায্যের ধরন:</strong> ${app.aidType}</div>
        <div class="full-width"><strong>প্রয়োজনীয় পরিমাণ / দ্রব্য:</strong> ${app.amount}</div>
        <div class="full-width"><strong>বর্তমান সমস্যা ও অসহায়ত্বের বর্ণনা:</strong> <br>${app.problem}</div>
      </div>
      <h4 class="text-danger mb-2"><i class="fa-solid fa-id-card"></i> NID / জন্মসনদ ডকুমেন্ট (গোপনীয়)</h4>
      <div style="background:#EEE; padding:12px; border-radius:8px; text-align:center;">
        ${app.nidDoc ? `<img src="${app.nidDoc}" style="max-width:100%; max-height:300px; border-radius:6px;">` : '<p class="text-muted">কোনো NID ডকুমেন্ট আপলোড করা হয়নি</p>'}
      </div>
    `;
    modal.classList.add('show');
  },

  approveHelpApp(appId) {
    const app = AppState.helpApplications.find(a => a.id === appId);
    if (!app) return;

    // Move to Beneficiaries collection
    const serial = AppState.beneficiaries.length + 1;
    const newBen = {
      id: 'ben-' + Date.now(),
      serial,
      helpAppNumber: app.appNumber,
      name: app.name,
      area: `${app.village}, ${app.thana}`,
      gender: app.gender,
      aidType: app.aidType,
      amount: app.amount,
      date: new Date().toISOString().split('T')[0],
      status: 'অনুমোদিত'
    };

    app.status = 'approved';
    AppState.beneficiaries.push(newBen);
    addAuditLog('Help Application Approved', appId, `উপকারভোগী আইডি: ${serial}, নাম: ${app.name}`);
    DB.save();
    FirestoreDB.setDoc('helpApplications', app.id, app);
    FirestoreDB.setDoc('beneficiaries', newBen.id, newBen);
    showToast(`সাহায্য আবেদন অনুমোদিত হয়েছে এবং দরিদ্র/সেবাপ্রাপ্ত তালিকায় যুক্ত হয়েছে`, 'success');
    Admin.renderTab();
    App.renderPublicUI();
  },

  rejectHelpApp(appId) {
    const app = AppState.helpApplications.find(a => a.id === appId);
    if (!app) return;
    app.status = 'rejected';
    addAuditLog('Help Application Rejected', appId, app.name);
    DB.save();
    FirestoreDB.setDoc('helpApplications', app.id, app);
    showToast('সাহায্য আবেদন বাতিল করা হয়েছে', 'warning');
    Admin.renderTab();
  },

  deleteHelpApp(appId) {
    if (AppState.userRole !== 'super_admin') {
      showToast('শুধুমাত্র সুপার এডমিন আবেদন মুছতে পারবেন', 'error');
      return;
    }
    if (!confirm('সাহায্যের আবেদনটি স্থায়ীভাবে মুছে ফেলতে চান?')) return;
    AppState.helpApplications = AppState.helpApplications.filter(a => a.id !== appId);
    FirestoreDB.deleteDoc('helpApplications', appId);
    addAuditLog('Help Application Deleted', appId);
    DB.save();
    showToast('আবেদন সফলভাবে মুছে ফেলা হয়েছে', 'info');
    Admin.renderTab();
  },

  // Beneficiaries Management
  renderBeneficiariesMgmt(vp) {
    vp.innerHTML = `
      <div class="table-card card-3d">
        <div class="table-card-header">
          <h3>দরিদ্র ও সেবাপ্রাপ্ত তালিকা (${AppState.beneficiaries.length} জন)</h3>
        </div>
        <div class="table-responsive">
          <table class="data-table">
            <thead>
              <tr>
                <th>সিরিয়াল</th>
                <th>আবেদন নং</th>
                <th>সেবাপ্রাপ্তের নাম</th>
                <th>এলাকা</th>
                <th>লিঙ্গ</th>
                <th>সাহায্যের ধরন</th>
                <th>পরিমাণ / দ্রব্য</th>
                <th>অনুমোদন তারিখ</th>
                <th>স্ট্যাটাস</th>
              </tr>
            </thead>
            <tbody>
              ${AppState.beneficiaries.length === 0 ? '<tr><td colspan="9" class="text-center">এখনও কোনো অনুমোদিত সেবাপ্রাপ্ত নেই</td></tr>' :
                AppState.beneficiaries.map(b => `
                  <tr>
                    <td>${b.serial}</td>
                    <td>${b.helpAppNumber || '---'}</td>
                    <td><strong>${b.name}</strong></td>
                    <td>${b.area}</td>
                    <td>${b.gender}</td>
                    <td>${b.aidType}</td>
                    <td>${b.amount}</td>
                    <td>${b.date}</td>
                    <td><span class="badge badge-success">${b.status}</span></td>
                  </tr>
                `).join('')
              }
            </tbody>
          </table>
        </div>
      </div>
    `;
  },

  // Activities Management
  renderActivitiesMgmt(vp) {
    vp.innerHTML = `
      <div class="table-card card-3d">
        <div class="table-card-header">
          <h3>ফাউন্ডেশনের কার্যক্রম নিয়ন্ত্রণ (${AppState.activities.length} টি)</h3>
          <button class="btn btn-gold" onclick="Admin.openAddActivityModal()"><i class="fa-solid fa-plus"></i> নতুন কার্যক্রম যোগ</button>
        </div>
        <div class="table-responsive">
          <table class="data-table">
            <thead>
              <tr>
                <th>নং</th>
                <th>শিরোনাম</th>
                <th>বিবরণ</th>
                <th>অ্যাকশন</th>
              </tr>
            </thead>
            <tbody>
              ${AppState.activities.map((act, i) => `
                <tr>
                  <td>${i + 1}</td>
                  <td><strong>${act.title}</strong></td>
                  <td>${act.desc}</td>
                  <td>
                    <button class="btn btn-sm btn-outline-danger" onclick="Admin.deleteActivity('${act.id}')"><i class="fa-solid fa-trash"></i></button>
                  </td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      </div>
    `;
  },

  openAddActivityModal() {
    const modal = document.getElementById('dynamicModal');
    document.getElementById('dynamicModalTitle').textContent = 'নতুন কার্যক্রম যোগ';
    document.getElementById('dynamicModalBody').innerHTML = `
      <form id="actForm" onsubmit="Admin.saveActivity(event)">
        <div class="form-group mb-2">
          <label>কার্যক্রমের নাম <span class="req">*</span></label>
          <input type="text" id="actTitle" required placeholder="কার্যক্রমের শিরোনাম">
        </div>
        <div class="form-group">
          <label>বিস্তারিত বিবরণ <span class="req">*</span></label>
          <textarea id="actDesc" rows="4" required placeholder="কার্যক্রমের বিস্তারিত বিবরণ লিখুন..."></textarea>
        </div>
        <div class="modal-footer" style="padding:0; margin-top:20px;">
          <button type="button" class="btn btn-outline" onclick="App.closeDynamicModal()">বাতিল</button>
          <button type="submit" class="btn btn-gold">যোগ করুন</button>
        </div>
      </form>
    `;
    modal.classList.add('show');
  },

  saveActivity(e) {
    e.preventDefault();
    const title = document.getElementById('actTitle').value.trim();
    const desc = document.getElementById('actDesc').value.trim();
    const newAct = { id: 'act-' + Date.now(), title, desc };
    AppState.activities.push(newAct);
    addAuditLog('Activity Added', newAct.id, title);
    DB.save();
    App.closeDynamicModal();
    showToast('নতুন কার্যক্রম সফলভাবে যুক্ত হয়েছে', 'success');
    Admin.renderTab();
    App.renderHomeActivities();
  },

  deleteActivity(id) {
    if (!confirm('কার্যক্রমটি মুছে ফেলতে চান?')) return;
    AppState.activities = AppState.activities.filter(a => a.id !== id);
    addAuditLog('Activity Deleted', id);
    DB.save();
    showToast('কার্যক্রম মুছে ফেলা হয়েছে', 'info');
    Admin.renderTab();
    App.renderHomeActivities();
  },

  // Distributions Management
  renderDistributionMgmt(vp) {
    vp.innerHTML = `
      <div class="table-card card-3d">
        <div class="table-card-header">
          <h3>পণ্য ও দ্রব্য বিতরণ হিসাব (${AppState.distributions.length} টি)</h3>
          <button class="btn btn-gold" onclick="Admin.openAddDistributionModal()"><i class="fa-solid fa-plus"></i> নতুন বিতরণ এন্ট্রি</button>
        </div>
        <div class="table-responsive">
          <table class="data-table">
            <thead>
              <tr>
                <th>তারিখ</th>
                <th>পণ্যের নাম</th>
                <th>ধরন</th>
                <th>পরিমাণ</th>
                <th>একক মূল্য</th>
                <th>মোট মূল্য</th>
                <th>কাকে দেওয়া হয়েছে</th>
                <th>মন্তব্য</th>
              </tr>
            </thead>
            <tbody>
              ${AppState.distributions.length === 0 ? '<tr><td colspan="8" class="text-center">কোনো বিতরণ রেকর্ড নেই</td></tr>' :
                AppState.distributions.map(d => `
                  <tr>
                    <td>${d.date}</td>
                    <td><strong>${d.itemName}</strong></td>
                    <td>${d.category || '---'}</td>
                    <td>${d.quantity} ${d.unit}</td>
                    <td>৳ ${Number(d.unitPrice).toLocaleString('bn-BD')}</td>
                    <td><strong>৳ ${Number(d.totalPrice).toLocaleString('bn-BD')}</strong></td>
                    <td>${d.recipient}</td>
                    <td>${d.remarks || '---'}</td>
                  </tr>
                `).join('')
              }
            </tbody>
          </table>
        </div>
      </div>
    `;
  },

  openAddDistributionModal() {
    const modal = document.getElementById('dynamicModal');
    document.getElementById('dynamicModalTitle').textContent = 'নতুন বিতরণ হিসাব এন্ট্রি';
    document.getElementById('dynamicModalBody').innerHTML = `
      <form id="distForm" onsubmit="Admin.saveDistribution(event)">
        <div class="form-grid">
          <div class="form-group">
            <label>তারিখ <span class="req">*</span></label>
            <input type="date" id="distDate" required value="${new Date().toISOString().split('T')[0]}">
          </div>
          <div class="form-group">
            <label>পণ্যের নাম <span class="req">*</span></label>
            <input type="text" id="distItemName" required placeholder="উদাঃ চাল / কম্বল / সেলাই মেশিন">
          </div>
          <div class="form-group">
            <label>পণ্যের ধরন</label>
            <input type="text" id="distCategory" placeholder="উদাঃ খাদ্য সামগ্রী / বস্ত্র / কর্মসংস্থান">
          </div>
          <div class="form-group">
            <label>পরিমাণ <span class="req">*</span></label>
            <input type="number" id="distQty" required min="1" value="1" oninput="Admin.calcDistTotal()">
          </div>
          <div class="form-group">
            <label>একক (Unit) <span class="req">*</span></label>
            <input type="text" id="distUnit" required placeholder="উদাঃ কেজি / টি / প্যাকেট">
          </div>
          <div class="form-group">
            <label>প্রতি ইউনিট মূল্য (টাকা) <span class="req">*</span></label>
            <input type="number" id="distUnitPrice" required min="0" value="0" oninput="Admin.calcDistTotal()">
          </div>
          <div class="form-group">
            <label>মোট মূল্য (অটো ক্যালকুলেট)</label>
            <input type="text" id="distTotalPrice" readonly style="background:#EEE;">
          </div>
          <div class="form-group">
            <label>কাকে দেওয়া হয়েছে / এলাকা <span class="req">*</span></label>
            <input type="text" id="distRecipient" required placeholder="উপকারভোগী বা এলাকার নাম">
          </div>
          <div class="form-group full-width">
            <label>মন্তব্য</label>
            <input type="text" id="distRemarks" placeholder="মন্তব্য লিখুন">
          </div>
        </div>
        <div class="modal-footer" style="padding:0; margin-top:20px;">
          <button type="button" class="btn btn-outline" onclick="App.closeDynamicModal()">বাতিল</button>
          <button type="submit" class="btn btn-gold">সংরক্ষণ করুন</button>
        </div>
      </form>
    `;
    modal.classList.add('show');
    this.calcDistTotal();
  },

  calcDistTotal() {
    const qty = Number(document.getElementById('distQty')?.value || 0);
    const unitPrice = Number(document.getElementById('distUnitPrice')?.value || 0);
    const total = qty * unitPrice;
    const elem = document.getElementById('distTotalPrice');
    if (elem) elem.value = '৳ ' + total.toLocaleString('bn-BD');
  },

  saveDistribution(e) {
    e.preventDefault();
    const date = document.getElementById('distDate').value;
    const itemName = document.getElementById('distItemName').value.trim();
    const category = document.getElementById('distCategory').value.trim();
    const quantity = Number(document.getElementById('distQty').value);
    const unit = document.getElementById('distUnit').value.trim();
    const unitPrice = Number(document.getElementById('distUnitPrice').value);
    const totalPrice = quantity * unitPrice;
    const recipient = document.getElementById('distRecipient').value.trim();
    const remarks = document.getElementById('distRemarks').value.trim();

    const newDist = {
      id: 'dist-' + Date.now(),
      date,
      itemName,
      category,
      quantity,
      unit,
      unitPrice,
      totalPrice,
      recipient,
      area: recipient,
      remarks
    };

    AppState.distributions.unshift(newDist);
    addAuditLog('Distribution Added', newDist.id, `${itemName}: ৳${totalPrice}`);
    DB.save();
    FirestoreDB.setDoc('distributions', newDist.id, newDist);
    App.closeDynamicModal();
    showToast('বিতরণ হিসাব সফলভাবে যুক্ত হয়েছে', 'success');
    Admin.renderTab();
    App.renderPublicUI();
  },

  // Fund & Expenses Management
  renderFundMgmt(vp) {
    const fin = calculateFinances();
    vp.innerHTML = `
      <div class="fund-summary-grid mb-4">
        <div class="fund-summary-card card-3d gold-border">
          <h4>বর্তমান অবশিষ্ট ব্যালেন্স</h4>
          <h2>৳ ${fin.currentBalance.toLocaleString('bn-BD')}</h2>
        </div>
        <div class="fund-summary-card card-3d green-border">
          <h4>জাকাত ফান্ড অবশিষ্ট</h4>
          <h2>৳ ${fin.zakatBalance.toLocaleString('bn-BD')}</h2>
        </div>
        <div class="fund-summary-card card-3d emerald-border">
          <h4>সাধারণ ফান্ড অবশিষ্ট</h4>
          <h2>৳ ${fin.generalBalance.toLocaleString('bn-BD')}</h2>
        </div>
      </div>

      <div class="table-card card-3d">
        <div class="table-card-header">
          <h3>ফান্ড জমা ও লেনদেন লেজার</h3>
          <button class="btn btn-gold" onclick="Admin.openAddFundDepositModal()"><i class="fa-solid fa-plus"></i> সরাসরি ফান্ড জমা</button>
        </div>
        <div class="table-responsive">
          <table class="data-table">
            <thead>
              <tr>
                <th>তারিখ</th>
                <th>ধরন</th>
                <th>ফান্ডের ধরন</th>
                <th>উৎস / বিবরণ</th>
                <th>টাকার পরিমাণ</th>
                <th>এন্ট্রি করেছেন</th>
              </tr>
            </thead>
            <tbody>
              ${AppState.fundTransactions.length === 0 ? '<tr><td colspan="6" class="text-center">কোনো লেনদেন রেকর্ড নেই</td></tr>' :
                AppState.fundTransactions.map(t => `
                  <tr>
                    <td>${t.date}</td>
                    <td><span class="badge badge-success">আয় / জমা</span></td>
                    <td>${t.fundType === 'zakat' ? 'জাকাত ফান্ড' : 'সাধারণ ফান্ড'}</td>
                    <td>${t.desc}</td>
                    <td><strong>৳ ${Number(t.amount).toLocaleString('bn-BD')}</strong></td>
                    <td>${t.enteredBy || 'এডমিন'}</td>
                  </tr>
                `).join('')
              }
            </tbody>
          </table>
        </div>
      </div>
    `;
  },

  openAddFundDepositModal() {
    const modal = document.getElementById('dynamicModal');
    document.getElementById('dynamicModalTitle').textContent = 'সরাসরি ফান্ড জমা এন্ট্রি';
    document.getElementById('dynamicModalBody').innerHTML = `
      <form id="fundDepositForm" onsubmit="Admin.saveFundDeposit(event)">
        <div class="form-grid">
          <div class="form-group">
            <label>তারিখ <span class="req">*</span></label>
            <input type="date" id="ftDate" required value="${new Date().toISOString().split('T')[0]}">
          </div>
          <div class="form-group">
            <label>ফান্ডের ধরন <span class="req">*</span></label>
            <select id="ftFundType" required>
              <option value="general">সাধারণ মানবকল্যাণ ফান্ড</option>
              <option value="zakat">জাকাত ফান্ড</option>
            </select>
          </div>
          <div class="form-group">
            <label>টাকার পরিমাণ <span class="req">*</span></label>
            <input type="number" id="ftAmount" required min="1" placeholder="টাকার পরিমাণ">
          </div>
          <div class="form-group">
            <label>উৎস / প্রদানকারীর নাম <span class="req">*</span></label>
            <input type="text" id="ftSource" required placeholder="উদাঃ এককালীন অনুদান / ব্যাংক মুনাফা">
          </div>
          <div class="form-group full-width">
            <label>বিবরণ</label>
            <input type="text" id="ftDesc" placeholder="বিবরণ লিখুন">
          </div>
        </div>
        <div class="modal-footer" style="padding:0; margin-top:20px;">
          <button type="button" class="btn btn-outline" onclick="App.closeDynamicModal()">বাতিল</button>
          <button type="submit" class="btn btn-gold">জমা নিশ্চিত করুন</button>
        </div>
      </form>
    `;
    modal.classList.add('show');
  },

  saveFundDeposit(e) {
    e.preventDefault();
    const date = document.getElementById('ftDate').value;
    const fundType = document.getElementById('ftFundType').value;
    const amount = Number(document.getElementById('ftAmount').value);
    const source = document.getElementById('ftSource').value.trim();
    const desc = document.getElementById('ftDesc').value.trim() || source;

    const newTrx = {
      id: 'ft-' + Date.now(),
      date,
      type: 'income',
      fundType,
      amount,
      source,
      desc,
      enteredBy: AppState.currentUser?.name || 'এডমিন'
    };

    AppState.fundTransactions.unshift(newTrx);
    addAuditLog('Fund Deposit Added', newTrx.id, `৳${amount} (${fundType})`);
    DB.save();
    FirestoreDB.setDoc('fundTransactions', newTrx.id, newTrx);
    App.closeDynamicModal();
    showToast('ফান্ড জমা সফল হয়েছে', 'success');
    Admin.renderTab();
    App.renderPublicUI();
  },

  // Expense Management
  renderExpenseMgmt(vp) {
    const fin = calculateFinances();
    vp.innerHTML = `
      <div class="stats-grid mb-4">
        <div class="stat-card">
          <div class="stat-icon red"><i class="fa-solid fa-calendar-day"></i></div>
          <div class="stat-info">
            <h3>৳ ${fin.todayExpense.toLocaleString('bn-BD')}</h3>
            <p>আজকের খরচ</p>
          </div>
        </div>
        <div class="stat-card">
          <div class="stat-icon red"><i class="fa-solid fa-arrow-up-right-dots"></i></div>
          <div class="stat-info">
            <h3>৳ ${fin.totalExpense.toLocaleString('bn-BD')}</h3>
            <p>সর্বমোট খরচ</p>
          </div>
        </div>
      </div>

      <div class="table-card card-3d">
        <div class="table-card-header">
          <h3>খরচের তালিকা (${AppState.expenses.length} টি)</h3>
          <button class="btn btn-gold" onclick="Admin.openAddExpenseModal()"><i class="fa-solid fa-plus"></i> নতুন খরচ যোগ</button>
        </div>
        <div class="table-responsive">
          <table class="data-table">
            <thead>
              <tr>
                <th>তারিখ</th>
                <th>খরচের ধরন</th>
                <th>বিবরণ</th>
                <th>ফান্ড</th>
                <th>পরিমাণ</th>
                <th>মন্তব্য</th>
                <th>অ্যাকশন</th>
              </tr>
            </thead>
            <tbody>
              ${AppState.expenses.length === 0 ? '<tr><td colspan="7" class="text-center">কোনো খরচের রেকর্ড নেই</td></tr>' :
                AppState.expenses.map(exp => `
                  <tr>
                    <td>${exp.date}</td>
                    <td><strong>${exp.category}</strong></td>
                    <td>${exp.desc}</td>
                    <td>${exp.fundType === 'zakat' ? 'জাকাত ফান্ড' : 'সাধারণ ফান্ড'}</td>
                    <td><strong>৳ ${Number(exp.amount).toLocaleString('bn-BD')}</strong></td>
                    <td>${exp.remarks || '---'}</td>
                    <td>
                      ${AppState.userRole === 'super_admin' ? `
                        <button class="btn btn-sm btn-outline-danger" onclick="Admin.deleteExpense('${exp.id}')"><i class="fa-solid fa-trash"></i></button>
                      ` : ''}
                    </td>
                  </tr>
                `).join('')
              }
            </tbody>
          </table>
        </div>
      </div>
    `;
  },

  openAddExpenseModal() {
    const modal = document.getElementById('dynamicModal');
    document.getElementById('dynamicModalTitle').textContent = 'নতুন খরচ যোগ করুন';
    document.getElementById('dynamicModalBody').innerHTML = `
      <form id="expForm" onsubmit="Admin.saveExpense(event)">
        <div class="form-grid">
          <div class="form-group">
            <label>তারিখ <span class="req">*</span></label>
            <input type="date" id="expDate" required value="${new Date().toISOString().split('T')[0]}">
          </div>
          <div class="form-group">
            <label>খরচের ধরন / খাত <span class="req">*</span></label>
            <input type="text" id="expCategory" required placeholder="উদাঃ চিকিৎসা সাহায্য / খাদ্য সামগ্রী ক্রয় / অফিস ভাড়া">
          </div>
          <div class="form-group">
            <label>ফান্ডের ধরন <span class="req">*</span></label>
            <select id="expFundType" required>
              <option value="general">সাধারণ ফান্ড</option>
              <option value="zakat">জাকাত ফান্ড</option>
            </select>
          </div>
          <div class="form-group">
            <label>টাকার পরিমাণ <span class="req">*</span></label>
            <input type="number" id="expAmount" required min="1" placeholder="টাকার পরিমাণ">
          </div>
          <div class="form-group full-width">
            <label>বিস্তারিত বিবরণ <span class="req">*</span></label>
            <textarea id="expDesc" rows="3" required placeholder="খরচের বিবরণ"></textarea>
          </div>
          <div class="form-group full-width">
            <label>রসিদ / ভাউচার ডকুমেন্টস (ছবি)</label>
            <input type="file" id="expReceipt" accept="image/*">
          </div>
        </div>
        <div class="modal-footer" style="padding:0; margin-top:20px;">
          <button type="button" class="btn btn-outline" onclick="App.closeDynamicModal()">বাতিল</button>
          <button type="submit" class="btn btn-gold">খরচ অনুমোদন করুন</button>
        </div>
      </form>
    `;
    modal.classList.add('show');
  },

  saveExpense(e) {
    e.preventDefault();
    const date = document.getElementById('expDate').value;
    const category = document.getElementById('expCategory').value.trim();
    const fundType = document.getElementById('expFundType').value;
    const amount = Number(document.getElementById('expAmount').value);
    const desc = document.getElementById('expDesc').value.trim();

    const newExpense = {
      id: 'exp-' + Date.now(),
      date,
      category,
      fundType,
      amount,
      desc,
      enteredBy: AppState.currentUser?.name || 'এডমিন'
    };

    AppState.expenses.unshift(newExpense);
    addAuditLog('Expense Added', newExpense.id, `৳${amount} (${category})`);
    DB.save();
    FirestoreDB.setDoc('expenses', newExpense.id, newExpense);
    App.closeDynamicModal();
    showToast(`খরচ ৳ ${amount} অনুমোদিত ও সংরক্ষিত হয়েছে`, 'success');
    Admin.renderTab();
    App.renderPublicUI();
  },

  deleteExpense(expId) {
    if (AppState.userRole !== 'super_admin') {
      showToast('শুধুমাত্র সুপার এডমিন খরচ মুছতে পারবেন', 'error');
      return;
    }
    if (!confirm('খরচের এন্ট্রি মুছে ফেলতে চান?')) return;
    AppState.expenses = AppState.expenses.filter(e => e.id !== expId);
    FirestoreDB.deleteDoc('expenses', expId);
    addAuditLog('Expense Deleted', expId);
    DB.save();
    showToast('খরচ মুছে ফেলা হয়েছে', 'info');
    Admin.renderTab();
    App.renderPublicUI();
  },

  // Donations Management
  renderDonationsMgmt(vp) {
    vp.innerHTML = `
      <div class="table-card card-3d">
        <div class="table-card-header">
          <h3>দানের রেকর্ড ও ভেরিফিকেশন (${AppState.donations.length} টি)</h3>
        </div>
        <div class="table-responsive">
          <table class="data-table">
            <thead>
              <tr>
                <th>তারিখ</th>
                <th>দাতার নাম</th>
                <th>মোবাইল</th>
                <th>মাধ্যম</th>
                <th>TrxID</th>
                <th>ফান্ড</th>
                <th>পরিমাণ</th>
                <th>স্ট্যাটাস</th>
                <th>অ্যাকশন</th>
              </tr>
            </thead>
            <tbody>
              ${AppState.donations.length === 0 ? '<tr><td colspan="9" class="text-center">কোনো দানের রেকর্ড পাওয়া যায়নি</td></tr>' :
                AppState.donations.map(don => `
                  <tr>
                    <td>${don.date}</td>
                    <td>${don.donorName || 'গোপন দান'}</td>
                    <td>${don.mobile}</td>
                    <td>${don.method.toUpperCase()}</td>
                    <td><strong>${don.trxId}</strong></td>
                    <td>${don.fundType === 'zakat' ? 'জাকাত' : 'সাধারণ'}</td>
                    <td><strong>৳ ${Number(don.amount).toLocaleString('bn-BD')}</strong></td>
                    <td>
                      <span class="badge ${don.status === 'verified' ? 'badge-success' : (don.status === 'rejected' ? 'badge-danger' : 'badge-warning')}">
                        ${don.status === 'verified' ? 'ভেরিফাইড' : (don.status === 'rejected' ? 'বাতিল' : 'যাচাইাধীন')}
                      </span>
                    </td>
                    <td>
                      ${don.status === 'pending' ? `
                        <button class="btn btn-sm btn-emerald" onclick="Admin.verifyDonation('${don.id}')"><i class="fa-solid fa-check"></i> ভেরিফাই</button>
                        <button class="btn btn-sm btn-outline-danger" onclick="Admin.rejectDonation('${don.id}')"><i class="fa-solid fa-xmark"></i> বাতিল</button>
                      ` : ''}
                    </td>
                  </tr>
                `).join('')
              }
            </tbody>
          </table>
        </div>
      </div>
    `;
  },

  verifyDonation(donId) {
    const don = AppState.donations.find(d => d.id === donId);
    if (!don) return;
    don.status = 'verified';
    addAuditLog('Donation Verified', donId, `TrxID: ${don.trxId}, পরিমাণ: ৳${don.amount}`);
    DB.save();
    FirestoreDB.setDoc('donations', don.id, don);
    showToast(`দানটি ভেরিফাইড হয়েছে এবং ফান্ড লেজারে যোগ হয়েছে`, 'success');
    Admin.renderTab();
    App.renderPublicUI();
  },

  rejectDonation(donId) {
    const don = AppState.donations.find(d => d.id === donId);
    if (!don) return;
    don.status = 'rejected';
    addAuditLog('Donation Rejected', donId, don.trxId);
    DB.save();
    FirestoreDB.setDoc('donations', don.id, don);
    showToast('দানটি বাতিল করা হয়েছে', 'warning');
    Admin.renderTab();
  },

  // Reports and Export
  renderReports(vp) {
    vp.innerHTML = `
      <div class="about-card-grid mb-4">
        <div class="card-3d" style="padding:24px;">
          <h3 class="text-emerald mb-2"><i class="fa-solid fa-file-pdf"></i> PDF রিপোর্ট তৈরি</h3>
          <p class="text-muted mb-4">অফিসিয়াল লেটারহেড, বিসমিল্লাহ ও স্বাক্ষর সিলসহ পূর্ণাঙ্গ PDF তৈরি বা প্রিন্ট করুন।</p>
          <div style="display:flex; flex-direction:column; gap:10px;">
            <button class="btn btn-gold" onclick="Admin.printReport('members')"><i class="fa-solid fa-print"></i> সদস্য তালিকা PDF</button>
            <button class="btn btn-emerald" onclick="Admin.printReport('financial')"><i class="fa-solid fa-print"></i> ফান্ড ও আর্থিক বিবরণী PDF</button>
            <button class="btn btn-outline" onclick="Admin.printReport('beneficiaries')"><i class="fa-solid fa-print"></i> দরিদ্র/সেবাপ্রাপ্ত তালিকা PDF</button>
            <button class="btn btn-outline" onclick="Admin.printReport('distributions')"><i class="fa-solid fa-print"></i> বিতরণ হিসাব PDF</button>
          </div>
        </div>

        <div class="card-3d" style="padding:24px;">
          <h3 class="text-gold mb-2"><i class="fa-solid fa-file-excel"></i> ডাটা ব্যাকআপ ও এক্সপোর্ট (CSV)</h3>
          <p class="text-muted mb-4">এক্সেল ও স্প্রেডশীট ফরম্যাটে সম্পূর্ণ ডাটা ব্যাকআপ ডাউনলোড করুন।</p>
          <div style="display:flex; flex-direction:column; gap:10px;">
            <button class="btn btn-outline" onclick="Admin.exportCSV('members')"><i class="fa-solid fa-download"></i> সদস্য ডাটা এক্সপোর্ট</button>
            <button class="btn btn-outline" onclick="Admin.exportCSV('donations')"><i class="fa-solid fa-download"></i> দানের রেকর্ড এক্সপোর্ট</button>
            <button class="btn btn-outline" onclick="Admin.exportCSV('expenses')"><i class="fa-solid fa-download"></i> খরচের হিসাব এক্সপোর্ট</button>
            <button class="btn btn-outline" onclick="Admin.exportCSV('distributions')"><i class="fa-solid fa-download"></i> বিতরণ হিসাব এক্সপোর্ট</button>
          </div>
        </div>
      </div>
    `;
  },

  printReport(reportType) {
    const fin = calculateFinances();
    const printWin = window.open('', '', 'width=900,height=700');
    let reportTitle = '';
    let reportContent = '';

    if (reportType === 'members') {
      reportTitle = 'সম্মানিত সদস্যবৃন্দের তালিকা';
      reportContent = `
        <table border="1" cellpadding="8" cellspacing="0" width="100%">
          <tr><th>সিরিয়াল</th><th>ফরম নং</th><th>নাম</th><th>পিতার নাম</th><th>গ্রাম</th><th>মোবাইল</th><th>মাসিক চাঁদা</th></tr>
          ${AppState.members.map(m => `
            <tr><td>${m.serial}</td><td>${m.formNumber}</td><td>${m.name}</td><td>${m.father}</td><td>${m.village}</td><td>${m.mobile}</td><td>৳ ${m.monthlyDue}</td></tr>
          `).join('')}
        </table>
      `;
    } else if (reportType === 'financial') {
      reportTitle = 'ফান্ড ও আর্থিক হিসাব বিবরণী';
      reportContent = `
        <div style="margin-bottom:20px;">
          <p><strong>মোট ভেরিফাইড আয়:</strong> ৳ ${fin.totalIncome.toLocaleString('bn-BD')}</p>
          <p><strong>মোট অনুমোদিত খরচ:</strong> ৳ ${fin.totalExpense.toLocaleString('bn-BD')}</p>
          <p><strong>বর্তমান অবশিষ্ট মোট ফান্ড:</strong> ৳ ${fin.currentBalance.toLocaleString('bn-BD')}</p>
          <p><strong>জাকাত ফান্ড ব্যালেন্স:</strong> ৳ ${fin.zakatBalance.toLocaleString('bn-BD')}</p>
          <p><strong>সাধারণ ফান্ড ব্যালেন্স:</strong> ৳ ${fin.generalBalance.toLocaleString('bn-BD')}</p>
        </div>
      `;
    } else if (reportType === 'beneficiaries') {
      reportTitle = 'অনুমোদিত দরিদ্র ও সেবাপ্রাপ্তদের তালিকা';
      reportContent = `
        <table border="1" cellpadding="8" cellspacing="0" width="100%">
          <tr><th>সিরিয়াল</th><th>নাম</th><th>এলাকা</th><th>সাহায্যের ধরন</th><th>পরিমাণ</th><th>তারিখ</th></tr>
          ${AppState.beneficiaries.map(b => `
            <tr><td>${b.serial}</td><td>${b.name}</td><td>${b.area}</td><td>${b.aidType}</td><td>${b.amount}</td><td>${b.date}</td></tr>
          `).join('')}
        </table>
      `;
    } else if (reportType === 'distributions') {
      reportTitle = 'পণ্য/সামগ্রী বিতরণ হিসাব রিপোর্ট';
      reportContent = `
        <table border="1" cellpadding="8" cellspacing="0" width="100%">
          <tr><th>তারিখ</th><th>পণ্যের নাম</th><th>পরিমাণ</th><th>মোট মূল্য</th><th>কাকে দেওয়া হয়েছে</th></tr>
          ${AppState.distributions.map(d => `
            <tr><td>${d.date}</td><td>${d.itemName}</td><td>${d.quantity} ${d.unit}</td><td>৳ ${d.totalPrice}</td><td>${d.recipient}</td></tr>
          `).join('')}
        </table>
      `;
    }

    printWin.document.write(`
      <!DOCTYPE html>
      <html>
      <head>
        <title>${reportTitle}</title>
        <style>
          body { font-family: 'Hind Siliguri', sans-serif; padding: 30px; }
          .header { text-align: center; border-bottom: 2px solid #0A4D2E; padding-bottom: 15px; margin-bottom: 25px; }
          .bismillah { font-family: 'Amiri', serif; font-size: 24px; margin-bottom: 5px; }
          h2 { margin: 0; color: #0A4D2E; }
          .address { margin: 5px 0; font-size: 14px; }
          table { width: 100%; border-collapse: collapse; margin-top: 20px; }
          th { background: #0A4D2E; color: white; }
          .signature { margin-top: 70px; display: flex; justify-content: space-between; }
          .sig-line { border-top: 1px solid #333; width: 180px; text-align: center; padding-top: 5px; }
        </style>
      </head>
      <body>
        <div class="header">
          <div class="bismillah">بِسْمِ اللهِ الرَّحْمٰنِ الرَّحِيْمِ</div>
          <h2>${AppState.settings.foundationName}</h2>
          <div class="address">${AppState.settings.address}</div>
          <h3>${reportTitle}</h3>
          <small>তারিখ: ${new Date().toLocaleDateString('bn-BD')}</small>
        </div>
        ${reportContent}
        <div class="signature">
          <div class="sig-line">কোষাধ্যক্ষের স্বাক্ষর</div>
          <div class="sig-line">সাধারণ সম্পাদকের স্বাক্ষর</div>
          <div class="sig-line">সভাপতির স্বাক্ষর</div>
        </div>
      </body>
      </html>
    `);
    printWin.document.close();
    printWin.focus();
    setTimeout(() => {
      printWin.print();
      printWin.close();
    }, 500);
  },

  exportCSV(type) {
    let rows = [];
    let filename = `alinsaf_${type}_${Date.now()}.csv`;

    if (type === 'members') {
      rows.push(['Serial', 'FormNumber', 'Name', 'Father', 'Village', 'Mobile', 'MonthlyDue']);
      AppState.members.forEach(m => rows.push([m.serial, m.formNumber, m.name, m.father, m.village, m.mobile, m.monthlyDue]));
    } else if (type === 'donations') {
      rows.push(['Date', 'DonorName', 'Mobile', 'Method', 'TrxID', 'FundType', 'Amount', 'Status']);
      AppState.donations.forEach(d => rows.push([d.date, d.donorName, d.mobile, d.method, d.trxId, d.fundType, d.amount, d.status]));
    } else if (type === 'expenses') {
      rows.push(['Date', 'Category', 'FundType', 'Amount', 'Description']);
      AppState.expenses.forEach(e => rows.push([e.date, e.category, e.fundType, e.amount, e.desc]));
    } else if (type === 'distributions') {
      rows.push(['Date', 'ItemName', 'Quantity', 'Unit', 'UnitPrice', 'TotalPrice', 'Recipient']);
      AppState.distributions.forEach(d => rows.push([d.date, d.itemName, d.quantity, d.unit, d.unitPrice, d.totalPrice, d.recipient]));
    }

    const csvContent = "data:text/csv;charset=utf-8,\uFEFF" + rows.map(e => e.join(",")).join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", filename);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast('CSV ফাইল ডাউনলোড সম্পন্ন হয়েছে', 'success');
  },

  // Audit Logs
  renderAuditLogs(vp) {
    vp.innerHTML = `
      <div class="table-card card-3d">
        <div class="table-card-header">
          <h3>নিরাপত্তা অডিট লগ (${AppState.auditLogs.length} টি)</h3>
        </div>
        <div class="table-responsive">
          <table class="data-table">
            <thead>
              <tr>
                <th>তারিখ ও সময়</th>
                <th>এডমিন নাম</th>
                <th>ইমেইল</th>
                <th>অ্যাকশন</th>
                <th>রেকর্ড আইডি</th>
                <th>বিস্তারিত</th>
              </tr>
            </thead>
            <tbody>
              ${AppState.auditLogs.length === 0 ? '<tr><td colspan="6" class="text-center">কোনো অডিট লগ নেই</td></tr>' :
                AppState.auditLogs.map(log => `
                  <tr>
                    <td>${log.date} ${log.time}</td>
                    <td><strong>${log.adminName}</strong></td>
                    <td>${log.adminEmail}</td>
                    <td><span class="badge badge-info">${log.action}</span></td>
                    <td>${log.recordId}</td>
                    <td>${log.details || '---'}</td>
                  </tr>
                `).join('')
              }
            </tbody>
          </table>
        </div>
      </div>
    `;
  },

  // User Management
  renderUserMgmt(vp) {
    if (AppState.userRole !== 'super_admin') {
      vp.innerHTML = '<div class="empty-state"><h3>শুধুমাত্র সুপার এডমিনের জন্য সংরক্ষিত</h3></div>';
      return;
    }
    vp.innerHTML = `
      <div class="table-card card-3d">
        <div class="table-card-header">
          <h3>এডমিন ও দায়িত্বশীল তালিকা (${AppState.admins.length} জন)</h3>
          <button class="btn btn-gold" onclick="Admin.openAddAdminModal()"><i class="fa-solid fa-plus"></i> নতুন এডমিন যোগ</button>
        </div>
        <div class="table-responsive">
          <table class="data-table">
            <thead>
              <tr>
                <th>নাম</th>
                <th>ইমেইল</th>
                <th>রোল (Role)</th>
                <th>অনুমতি</th>
              </tr>
            </thead>
            <tbody>
              ${AppState.admins.map(a => `
                <tr>
                  <td><strong>${a.name}</strong></td>
                  <td>${a.email}</td>
                  <td><span class="badge ${a.role === 'super_admin' ? 'badge-danger' : 'badge-info'}">${a.role === 'super_admin' ? 'Super Admin' : 'Staff Admin'}</span></td>
                  <td>${a.role === 'super_admin' ? 'সকল ক্ষমতা' : 'সীমিত ক্ষমতা'}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      </div>
    `;
  },

  openAddAdminModal() {
    const modal = document.getElementById('dynamicModal');
    document.getElementById('dynamicModalTitle').textContent = 'নতুন এডমিন যোগ করুন';
    document.getElementById('dynamicModalBody').innerHTML = `
      <form id="newAdminForm" onsubmit="Admin.saveNewAdmin(event)">
        <div class="form-grid">
          <div class="form-group">
            <label>এডমিনের নাম <span class="req">*</span></label>
            <input type="text" id="naName" required placeholder="নাম">
          </div>
          <div class="form-group">
            <label>ইমেইল ঠিকানা <span class="req">*</span></label>
            <input type="email" id="naEmail" required placeholder="ইমেইল">
          </div>
          <div class="form-group full-width">
            <label>রোল (Role) <span class="req">*</span></label>
            <select id="naRole" required>
              <option value="admin">Staff Admin (সীমিত)</option>
              <option value="super_admin">Super Admin (পূর্ণ ক্ষমতা)</option>
            </select>
          </div>
        </div>
        <div class="modal-footer" style="padding:0; margin-top:20px;">
          <button type="button" class="btn btn-outline" onclick="App.closeDynamicModal()">বাতিল</button>
          <button type="submit" class="btn btn-gold">এডমিন যোগ করুন</button>
        </div>
      </form>
    `;
    modal.classList.add('show');
  },

  saveNewAdmin(e) {
    e.preventDefault();
    const name = document.getElementById('naName').value.trim();
    const email = document.getElementById('naEmail').value.trim().toLowerCase();
    const role = document.getElementById('naRole').value;

    const newAdmin = {
      id: 'adm-' + Date.now(),
      name,
      email,
      role,
      permissions: role === 'super_admin' ? ['all'] : ['view', 'manage_apps']
    };

    AppState.admins.push(newAdmin);
    addAuditLog('Admin Created', newAdmin.id, `${name} (${email}) - ${role}`);
    DB.save();
    FirestoreDB.setDoc('admins', newAdmin.id, newAdmin);
    App.closeDynamicModal();
    showToast('নতুন এডমিন সফলভাবে যোগ করা হয়েছে', 'success');
    Admin.renderTab();
  },

  // Settings
  renderSettings(vp) {
    const s = AppState.settings;
    vp.innerHTML = `
      <div class="card-3d" style="padding:28px;">
        <h3 class="text-emerald mb-4"><i class="fa-solid fa-gears"></i> ওয়েবসাইট ও ফাউন্ডেশন তথ্য পরিবর্তন</h3>
        <form id="settingsForm" onsubmit="Admin.saveSettings(event)">
          <div class="form-grid">
            <div class="form-group full-width">
              <label>ফাউন্ডেশনের নাম <span class="req">*</span></label>
              <input type="text" id="stName" required value="${s.foundationName}">
            </div>
            <div class="form-group full-width">
              <label>ঠিকানা <span class="req">*</span></label>
              <input type="text" id="stAddress" required value="${s.address}">
            </div>
            <div class="form-group">
              <label>যোগাযোগ মোবাইল নম্বর <span class="req">*</span></label>
              <input type="text" id="stMobile" required value="${s.mobile}">
            </div>
            <div class="form-group">
              <label>যোগাযোগ ইমেইল <span class="req">*</span></label>
              <input type="email" id="stEmail" required value="${s.email}">
            </div>
            <div class="form-group">
              <label>বিকাশ নম্বর (Donation) <span class="req">*</span></label>
              <input type="text" id="stBkash" required value="${s.bkashNumber}">
            </div>
            <div class="form-group">
              <label>নগদ নম্বর (Donation) <span class="req">*</span></label>
              <input type="text" id="stNagad" required value="${s.nagadNumber}">
            </div>
            <div class="form-group full-width">
              <label>নোটিশ বার লেখা (Marquee Notice)</label>
              <input type="text" id="stMarquee" value="${s.marqueeNotice}">
            </div>
            <div class="form-group full-width">
              <label>আমাদের সম্পর্কে বিস্তারিত লেখা</label>
              <textarea id="stAbout" rows="4">${s.aboutText}</textarea>
            </div>
          </div>
          <div style="margin-top:24px;">
            <button type="submit" class="btn btn-gold btn-lg"><i class="fa-solid fa-floppy-disk"></i> পরিবর্তনসমূহ সংরক্ষণ করুন</button>
          </div>
        </form>
      </div>
    `;
  },

  saveSettings(e) {
    e.preventDefault();
    AppState.settings.foundationName = document.getElementById('stName').value.trim();
    AppState.settings.address = document.getElementById('stAddress').value.trim();
    AppState.settings.mobile = document.getElementById('stMobile').value.trim();
    AppState.settings.email = document.getElementById('stEmail').value.trim();
    AppState.settings.bkashNumber = document.getElementById('stBkash').value.trim();
    AppState.settings.nagadNumber = document.getElementById('stNagad').value.trim();
    AppState.settings.marqueeNotice = document.getElementById('stMarquee').value.trim();
    AppState.settings.aboutText = document.getElementById('stAbout').value.trim();

    addAuditLog('Settings Updated', 'settings', 'ফাউন্ডেশন তথ্য আপডেট');
    DB.save();
    FirestoreDB.setDoc('settings', 'general', AppState.settings);
    showToast('সেটিংস সফলভাবে সংরক্ষিত হয়েছে', 'success');
    App.updateBrandAndSettingsUI();
  }
};

// Initialize App on DOM Ready
document.addEventListener('DOMContentLoaded', () => {
  App.init();
});
