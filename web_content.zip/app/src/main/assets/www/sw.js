
"use strict";

const NOME_CACHE = "sgfe-cache-v8";

const FICHEIROS = [
    "./",
    "./index.html",
    "./manifest.json",

    "./css/estilo.css",
    "./css/responsivo.css",

    "./js/armazenamento.js",
    "./js/painel.js",
    "./js/entradas.js",
    "./js/salarios.js",
    "./js/despesas.js",
    "./js/relatorios.js",
    "./js/configuracoes.js",
    "./js/app.js"
];

// Instalação
self.addEventListener("install", evento => {
    evento.waitUntil(
        caches.open(NOME_CACHE).then(cache => {
            return cache.addAll(FICHEIROS);
        })
    );

    self.skipWaiting();
});

// Activação
self.addEventListener("activate", evento => {
    evento.waitUntil(
        caches.keys().then(nomes => {
            return Promise.all(
                nomes
                    .filter(nome =>
                        nome.startsWith("sgfe-cache-") &&
                        nome !== NOME_CACHE
                    )
                    .map(nome => caches.delete(nome))
            );
        })
    );

    self.clients.claim();
});

// Carregamento dos recursos
self.addEventListener("fetch", evento => {
    const pedido = evento.request;

    if (pedido.method !== "GET") return;

    const url = new URL(pedido.url);

    if (url.origin !== self.location.origin) return;

    // Páginas HTML
    if (pedido.mode === "navigate") {
        evento.respondWith(
            fetch(pedido)
                .then(resposta => {
                    const copia = resposta.clone();

                    caches.open(NOME_CACHE).then(cache => {
                        cache.put(pedido, copia);
                    });

                    return resposta;
                })
                .catch(async () => {
                    return await caches.match(pedido) ||
                           await caches.match("./index.html");
                })
        );

        return;
    }

    // CSS, JavaScript e outros recursos
    evento.respondWith(
        caches.match(pedido).then(resposta => {
            if (resposta) return resposta;

            return fetch(pedido).then(respostaRede => {
                if (respostaRede && respostaRede.ok) {
                    const copia = respostaRede.clone();

                    caches.open(NOME_CACHE).then(cache => {
                        cache.put(pedido, copia);
                    });
                }

                return respostaRede;
            });
        })
    );
});
