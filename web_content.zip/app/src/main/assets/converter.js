/**
 * converter.js
 * Date Converter Engine for Taghvim Sina (تقویم سینا)
 * Converts bi-directionally between Jalali (Persian), Gregorian, and Hijri dates.
 */

class DateConverter {
  constructor() {
    this.cal = window.calendarEngine;
    this.shift = window.shiftCalculator;
  }

  /**
   * Converts a Jalali date to all calendar systems and includes shift team info
   * @param {number} jy Jalali Year
   * @param {number} jm Jalali Month
   * @param {number} jd Jalali Day
   * @returns {Object} Detailed conversion result
   */
  convertFromJalali(jy, jm, jd) {
    const g = this.cal.jalaliToGregorian(jy, jm, jd);
    const h = this.cal.gregorianToHijri(g.gy, g.gm, g.gd);

    const gDate = new Date(g.gy, g.gm - 1, g.gd, 7, 0, 0);
    const dayOfWeekIndex = (gDate.getDay() + 1) % 7;
    const weekDayName = this.cal.weekDayNames[dayOfWeekIndex];
    const teams = this.shift.getTeamsForDate(gDate);
    const weekNumber = this.cal.getJalaliWeekNumber(jy, jm, jd);
    const event = this.cal.getEventForDate(jm, jd);

    return {
      jalali: {
        year: jy,
        month: jm,
        day: jd,
        monthName: this.cal.jalaliMonthNames[jm - 1],
        formatted: `${jy}/${String(jm).padStart(2, '0')}/${String(jd).padStart(2, '0')}`,
        formattedPersian: `${this.cal.toPersianDigits(jy)}/${this.cal.toPersianDigits(String(jm).padStart(2, '0'))}/${this.cal.toPersianDigits(String(jd).padStart(2, '0'))}`
      },
      gregorian: {
        year: g.gy,
        month: g.gm,
        day: g.gd,
        monthName: this.cal.gregorianMonthNames[g.gm - 1],
        formatted: `${g.gy}-${String(g.gm).padStart(2, '0')}-${String(g.gd).padStart(2, '0')}`
      },
      hijri: {
        year: h.hy,
        month: h.hm,
        day: h.hd,
        monthName: this.cal.hijriMonthNames[h.hm - 1] || '',
        formatted: `${h.hy}/${String(h.hm).padStart(2, '0')}/${String(h.hd).padStart(2, '0')}`
      },
      weekDayName,
      weekNumber,
      dayTeam: teams.dayTeam,
      nightTeam: teams.nightTeam,
      event
    };
  }

  /**
   * Converts a Gregorian date to all calendar systems
   * @param {number} gy
   * @param {number} gm
   * @param {number} gd
   * @returns {Object}
   */
  convertFromGregorian(gy, gm, gd) {
    const j = this.cal.gregorianToJalali(gy, gm, gd);
    return this.convertFromJalali(j.jy, j.jm, j.jd);
  }

  /**
   * Accurate conversion from Hijri date to Gregorian then Jalali
   * @param {number} hy Hijri Year
   * @param {number} hm Hijri Month
   * @param {number} hd Hijri Day
   * @returns {Object}
   */
  convertFromHijri(hy, hm, hd) {
    const g = this.cal.hijriToGregorian(hy, hm, hd);
    return this.convertFromGregorian(g.gy, g.gm, g.gd);
  }
}

// Global instance
window.dateConverter = new DateConverter();
