// Ruffle & Legacy Flash Compatibility Polyfill
(function() {
  console.log("Adobe Flash Player v10 & Ruffle Compatibility Engine Active");
  window.FlashPlayerVersion = "10.3.183.90";

  // Check for embed or object elements with flash
  function polyfillFlash() {
    var embeds = document.querySelectorAll('embed[type*="flash"], embed[src*=".swf"], object[data*=".swf"], object[classid*="D27CDB6E-AE6D-11cf-96B8-444553540000"]');
    if (embeds.length > 0) {
      console.log("Found " + embeds.length + " legacy Flash elements. Polyfilling with Ruffle...");
      if (!window.RufflePlayer && !document.getElementById('ruffle-script')) {
        var s = document.createElement('script');
        s.id = 'ruffle-script';
        s.src = 'https://unpkg.com/@ruffle-rs/ruffle';
        document.head.appendChild(s);
      }
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', polyfillFlash);
  } else {
    polyfillFlash();
  }
})();
