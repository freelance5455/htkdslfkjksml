// Street Drift Legends - Vehicle Catalog & Procedural 3D Car Generator
// Creates realistic stylized 3D arcade racing vehicles using Three.js

const CAR_CATALOG = [
  {
    id: "apex_sprint",
    name: "Apex Sprint",
    carClass: "Street",
    description: "Balanced entry-level rear-wheel drive sports coupe. Perfect for learning drift dynamics.",
    price: 0,
    unlocked: true,
    baseStats: {
      topSpeed: 210,      // km/h
      acceleration: 68,   // 0-100 index
      handling: 72,
      nitro: 65,
      driftControl: 75
    },
    defaultCustomization: {
      bodyColor: "#00E5FF",
      accentColor: "#111111",
      neonColor: "#00E5FF",
      spoilerStyle: "sport",
      rimColor: "#E0E0E0",
      windowTint: "#1a1a2e"
    }
  },
  {
    id: "phantom_gt",
    name: "Phantom GT",
    carClass: "Street",
    description: "Twin-turbo lightweight Japanese street tuner with aggressive front splitter and high RPM band.",
    price: 15000,
    unlocked: false,
    baseStats: {
      topSpeed: 235,
      acceleration: 78,
      handling: 80,
      nitro: 72,
      driftControl: 85
    },
    defaultCustomization: {
      bodyColor: "#FF1744",
      accentColor: "#1a1a1a",
      neonColor: "#FF1744",
      spoilerStyle: "gt_wing",
      rimColor: "#FFD700",
      windowTint: "#0a0a0f"
    }
  },
  {
    id: "thunder_v8",
    name: "Thunder V8",
    carClass: "Muscle",
    description: "American supercharged 6.4L V8 with immense torque. Roars off the line and slides wide.",
    price: 28000,
    unlocked: false,
    baseStats: {
      topSpeed: 255,
      acceleration: 85,
      handling: 65,
      nitro: 78,
      driftControl: 82
    },
    defaultCustomization: {
      bodyColor: "#FF9100",
      accentColor: "#000000",
      neonColor: "#FF9100",
      spoilerStyle: "ducktail",
      rimColor: "#333333",
      windowTint: "#111111"
    }
  },
  {
    id: "vortex_rally",
    name: "Vortex Rally",
    carClass: "Sports",
    description: "All-wheel-drive gravel specialist adapted for street dominance. Unbeatable cornering grip.",
    price: 45000,
    unlocked: false,
    baseStats: {
      topSpeed: 245,
      acceleration: 84,
      handling: 90,
      nitro: 75,
      driftControl: 88
    },
    defaultCustomization: {
      bodyColor: "#00E676",
      accentColor: "#212121",
      neonColor: "#00E676",
      spoilerStyle: "rally_wing",
      rimColor: "#FFFFFF",
      windowTint: "#121212"
    }
  },
  {
    id: "kansei_drift",
    name: "Kansei Drift-R",
    carClass: "Sports",
    description: "Purpose-built sideways champion with extended steering lock and lightning-fast transition response.",
    price: 65000,
    unlocked: false,
    baseStats: {
      topSpeed: 260,
      acceleration: 86,
      handling: 85,
      nitro: 80,
      driftControl: 98
    },
    defaultCustomization: {
      bodyColor: "#D500F9",
      accentColor: "#00E5FF",
      neonColor: "#D500F9",
      spoilerStyle: "gt_wing",
      rimColor: "#D500F9",
      windowTint: "#0d0d1a"
    }
  },
  {
    id: "venom_r",
    name: "Venom R",
    carClass: "Super",
    description: "Mid-engine aerodynamic predator crafted with carbon composites. Razor sharp at 290 km/h.",
    price: 95000,
    unlocked: false,
    baseStats: {
      topSpeed: 295,
      acceleration: 92,
      handling: 88,
      nitro: 88,
      driftControl: 84
    },
    defaultCustomization: {
      bodyColor: "#2979FF",
      accentColor: "#111111",
      neonColor: "#2979FF",
      spoilerStyle: "active_wing",
      rimColor: "#111111",
      windowTint: "#050510"
    }
  },
  {
    id: "titan_baja",
    name: "Titan Baja",
    carClass: "Muscle",
    description: "Heavy-duty armored trophy truck. Immune to minor crashes and dominates massive ramp jumps.",
    price: 120000,
    unlocked: false,
    baseStats: {
      topSpeed: 265,
      acceleration: 88,
      handling: 74,
      nitro: 85,
      driftControl: 80
    },
    defaultCustomization: {
      bodyColor: "#795548",
      accentColor: "#212121",
      neonColor: "#FFAB00",
      spoilerStyle: "none",
      rimColor: "#424242",
      windowTint: "#1a1a1a"
    }
  },
  {
    id: "hyperion_x",
    name: "Hyperion X",
    carClass: "Hyper",
    description: "Quad-turbo hybrid hypercar with quad exhaust, active aero, and supersonic Shockwave nitro.",
    price: 200000,
    unlocked: false,
    baseStats: {
      topSpeed: 335,
      acceleration: 98,
      handling: 94,
      nitro: 98,
      driftControl: 92
    },
    defaultCustomization: {
      bodyColor: "#FFD700",
      accentColor: "#050505",
      neonColor: "#00E5FF",
      spoilerStyle: "hyper_wing",
      rimColor: "#FFD700",
      windowTint: "#030308"
    }
  }
];

class CarModelBuilder {
  static createCar(carConfig, custom = {}, isPlayer = false) {
    const group = new THREE.Group();
    group.name = "carRoot";

    const bodyCol = custom.bodyColor || carConfig.defaultCustomization.bodyColor;
    const accentCol = custom.accentColor || carConfig.defaultCustomization.accentColor;
    const neonCol = custom.neonColor || carConfig.defaultCustomization.neonColor;
    const rimCol = custom.rimColor || carConfig.defaultCustomization.rimColor;
    const spoiler = custom.spoilerStyle || carConfig.defaultCustomization.spoilerStyle;
    const tintCol = custom.windowTint || "#111122";

    // Common Materials
    const bodyMat = new THREE.MeshStandardMaterial({
      color: bodyCol,
      metalness: 0.85,
      roughness: 0.22,
      envMapIntensity: 1.2
    });

    const accentMat = new THREE.MeshStandardMaterial({
      color: accentCol,
      metalness: 0.5,
      roughness: 0.4
    });

    const glassMat = new THREE.MeshPhysicalMaterial({
      color: tintCol,
      metalness: 0.1,
      roughness: 0.1,
      transmission: 0.6,
      transparent: true,
      opacity: 0.85
    });

    const tireMat = new THREE.MeshStandardMaterial({
      color: 0x1a1a1a,
      roughness: 0.85,
      metalness: 0.05
    });

    const rimMat = new THREE.MeshStandardMaterial({
      color: rimCol,
      metalness: 0.9,
      roughness: 0.15
    });

    const brakeMat = new THREE.MeshStandardMaterial({
      color: 0xff1744,
      metalness: 0.5,
      roughness: 0.3
    });

    const headlightMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
    const taillightMat = new THREE.MeshBasicMaterial({ color: 0xff1744 });
    const reverseLightMat = new THREE.MeshBasicMaterial({ color: 0xffffff });

    // Shape dimensions based on car class
    let length = 4.2;
    let width = 1.95;
    let height = 1.05;
    let cabinRatio = 0.55;

    if (carConfig.carClass === "Muscle") {
      length = 4.5;
      width = 2.05;
      height = 1.15;
    } else if (carConfig.carClass === "Hyper") {
      length = 4.6;
      width = 2.15;
      height = 0.95;
    } else if (carConfig.id === "titan_baja") {
      length = 4.4;
      width = 2.1;
      height = 1.35;
    }

    // 1. Main Lower Chassis / Body
    const chassisGeo = new THREE.BoxGeometry(width, height * 0.5, length);
    const chassisMesh = new THREE.Mesh(chassisGeo, bodyMat);
    chassisMesh.position.y = height * 0.45;
    chassisMesh.castShadow = true;
    chassisMesh.receiveShadow = true;
    group.add(chassisMesh);

    // Front Bumper & Splitter
    const splitterGeo = new THREE.BoxGeometry(width * 1.02, 0.08, 0.8);
    const splitterMesh = new THREE.Mesh(splitterGeo, accentMat);
    splitterMesh.position.set(0, 0.22, length * 0.48);
    splitterMesh.castShadow = true;
    group.add(splitterMesh);

    // Rear Diffuser
    const diffuserGeo = new THREE.BoxGeometry(width * 0.98, 0.15, 0.6);
    const diffuserMesh = new THREE.Mesh(diffuserGeo, accentMat);
    diffuserMesh.position.set(0, 0.26, -length * 0.48);
    group.add(diffuserMesh);

    // Exhaust Pipes
    const exhaustGeo = new THREE.CylinderGeometry(0.06, 0.06, 0.2, 12);
    exhaustGeo.rotateX(Math.PI / 2);
    const exhaustMat = new THREE.MeshStandardMaterial({ color: 0xcccccc, metalness: 0.9, roughness: 0.2 });

    const exhaustL = new THREE.Mesh(exhaustGeo, exhaustMat);
    exhaustL.position.set(-width * 0.28, 0.28, -length * 0.51);
    group.add(exhaustL);

    const exhaustR = new THREE.Mesh(exhaustGeo, exhaustMat);
    exhaustR.position.set(width * 0.28, 0.28, -length * 0.51);
    group.add(exhaustR);

    // 2. Cabin / Roof (Greenhouse)
    const cabinLength = length * cabinRatio;
    const cabinWidth = width * 0.84;
    const cabinHeight = height * 0.55;
    const cabinGeo = new THREE.BoxGeometry(cabinWidth, cabinHeight, cabinLength);
    const cabinMesh = new THREE.Mesh(cabinGeo, glassMat);
    cabinMesh.position.set(0, height * 0.85, -length * 0.04);
    cabinMesh.castShadow = true;
    group.add(cabinMesh);

    // Roof Top Shell
    const roofGeo = new THREE.BoxGeometry(cabinWidth * 0.92, 0.05, cabinLength * 0.75);
    const roofMesh = new THREE.Mesh(roofGeo, bodyMat);
    roofMesh.position.set(0, height * 1.13, -length * 0.04);
    group.add(roofMesh);

    // Hood scoop or bonnet line
    const hoodGeo = new THREE.BoxGeometry(width * 0.55, 0.08, length * 0.35);
    const hoodMesh = new THREE.Mesh(hoodGeo, accentMat);
    hoodMesh.position.set(0, height * 0.72, length * 0.25);
    group.add(hoodMesh);

    // 3. Spoilers
    if (spoiler !== "none") {
      const wingGroup = new THREE.Group();
      wingGroup.name = "spoilerGroup";
      const wingY = height * 0.75;
      const wingZ = -length * 0.44;

      if (spoiler === "ducktail") {
        const duckGeo = new THREE.BoxGeometry(width * 0.8, 0.12, 0.2);
        duckGeo.rotateX(-0.3);
        const duckMesh = new THREE.Mesh(duckGeo, accentMat);
        duckMesh.position.set(0, wingY + 0.05, wingZ);
        wingGroup.add(duckMesh);
      } else {
        // Wing pedestals
        const pedGeo = new THREE.BoxGeometry(0.04, 0.35, 0.12);
        const pedL = new THREE.Mesh(pedGeo, accentMat);
        pedL.position.set(-width * 0.32, wingY + 0.18, wingZ);
        wingGroup.add(pedL);

        const pedR = new THREE.Mesh(pedGeo, accentMat);
        pedR.position.set(width * 0.32, wingY + 0.18, wingZ);
        wingGroup.add(pedR);

        // Aerofoil blade
        const bladeGeo = new THREE.BoxGeometry(width * 0.95, 0.04, 0.3);
        bladeGeo.rotateX(-0.1);
        const bladeMesh = new THREE.Mesh(bladeGeo, accentMat);
        bladeMesh.position.set(0, wingY + 0.35, wingZ + 0.02);
        wingGroup.add(bladeMesh);

        // Side endplates
        const plateGeo = new THREE.BoxGeometry(0.02, 0.18, 0.35);
        const plateL = new THREE.Mesh(plateGeo, accentMat);
        plateL.position.set(-width * 0.47, wingY + 0.35, wingZ + 0.02);
        wingGroup.add(plateL);

        const plateR = new THREE.Mesh(plateGeo, accentMat);
        plateR.position.set(width * 0.47, wingY + 0.35, wingZ + 0.02);
        wingGroup.add(plateR);
      }
      group.add(wingGroup);
    }

    // 4. Lights
    // Headlights
    const hlGeo = new THREE.BoxGeometry(0.35, 0.1, 0.06);
    const hlL = new THREE.Mesh(hlGeo, headlightMat);
    hlL.position.set(-width * 0.36, height * 0.55, length * 0.5);
    group.add(hlL);

    const hlR = new THREE.Mesh(hlGeo, headlightMat);
    hlR.position.set(width * 0.36, height * 0.55, length * 0.5);
    group.add(hlR);

    // Taillights
    const tlGeo = new THREE.BoxGeometry(0.4, 0.08, 0.06);
    const tlL = new THREE.Mesh(tlGeo, taillightMat);
    tlL.position.set(-width * 0.36, height * 0.58, -length * 0.5);
    group.add(tlL);

    const tlR = new THREE.Mesh(tlGeo, taillightMat);
    tlR.position.set(width * 0.36, height * 0.58, -length * 0.5);
    group.add(tlR);

    group.taillights = [tlL, tlR];
    group.headlights = [hlL, hlR];

    // 5. Underglow Neon (if enabled)
    if (neonCol && neonCol !== "none" && neonCol !== "#000000") {
      const neonPlaneGeo = new THREE.PlaneGeometry(width * 0.9, length * 0.7);
      neonPlaneGeo.rotateX(-Math.PI / 2);
      const neonMat = new THREE.MeshBasicMaterial({
        color: neonCol,
        transparent: true,
        opacity: 0.75,
        side: THREE.DoubleSide
      });
      const neonMesh = new THREE.Mesh(neonPlaneGeo, neonMat);
      neonMesh.position.set(0, 0.08, 0);
      group.add(neonMesh);
      group.neonMesh = neonMesh;

      if (isPlayer) {
        const neonLight = new THREE.PointLight(neonCol, 1.2, 3.5);
        neonLight.position.set(0, 0.15, 0);
        group.add(neonLight);
      }
    }

    // 6. Wheels Assembly
    const wheelRadius = 0.38;
    const wheelWidth = 0.28;
    const tireGeo = new THREE.CylinderGeometry(wheelRadius, wheelRadius, wheelWidth, 18);
    tireGeo.rotateZ(Math.PI / 2);

    const rimGeo = new THREE.CylinderGeometry(wheelRadius * 0.68, wheelRadius * 0.68, wheelWidth * 1.02, 14);
    rimGeo.rotateZ(Math.PI / 2);

    const discGeo = new THREE.CylinderGeometry(wheelRadius * 0.55, wheelRadius * 0.55, 0.02, 12);
    discGeo.rotateZ(Math.PI / 2);

    const caliperGeo = new THREE.BoxGeometry(0.06, 0.14, 0.12);

    function buildWheelMesh() {
      const wGroup = new THREE.Group();
      const tire = new THREE.Mesh(tireGeo, tireMat);
      tire.castShadow = true;
      wGroup.add(tire);

      const rim = new THREE.Mesh(rimGeo, rimMat);
      wGroup.add(rim);

      const disc = new THREE.Mesh(discGeo, rimMat);
      wGroup.add(disc);

      const caliper = new THREE.Mesh(caliperGeo, brakeMat);
      caliper.position.set(0, wheelRadius * 0.25, 0);
      wGroup.add(caliper);

      return wGroup;
    }

    const frontZ = length * 0.32;
    const rearZ = -length * 0.32;
    const wheelX = width * 0.52;
    const wheelY = wheelRadius;

    const wheelFL = buildWheelMesh();
    wheelFL.position.set(-wheelX, wheelY, frontZ);
    const steerFL = new THREE.Group();
    steerFL.position.set(-wheelX, wheelY, frontZ);
    wheelFL.position.set(0, 0, 0);
    steerFL.add(wheelFL);
    group.add(steerFL);

    const wheelFR = buildWheelMesh();
    const steerFR = new THREE.Group();
    steerFR.position.set(wheelX, wheelY, frontZ);
    wheelFR.position.set(0, 0, 0);
    steerFR.add(wheelFR);
    group.add(steerFR);

    const wheelRL = buildWheelMesh();
    wheelRL.position.set(-wheelX, wheelY, rearZ);
    group.add(wheelRL);

    const wheelRR = buildWheelMesh();
    wheelRR.position.set(wheelX, wheelY, rearZ);
    group.add(wheelRR);

    group.wheels = {
      steerFL,
      steerFR,
      meshFL: wheelFL,
      meshFR: wheelFR,
      meshRL: wheelRL,
      meshRR: wheelRR
    };

    group.exhausts = [exhaustL, exhaustR];

    // Reference materials for live customization updates in garage
    group.materials = {
      bodyMat,
      accentMat,
      rimMat,
      glassMat
    };

    return group;
  }
}

window.CAR_CATALOG = CAR_CATALOG;
window.CarModelBuilder = CarModelBuilder;
