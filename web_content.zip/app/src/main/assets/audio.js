// Street Drift Legends - Audio Synthesizer Engine (Web Audio API)
// 100% offline, zero-asset procedural arcade racing soundscape

class AudioManager {
  constructor() {
    this.ctx = null;
    this.masterGain = null;
    this.musicGain = null;
    this.sfxGain = null;
    
    this.masterVol = 0.8;
    this.musicVol = 0.6;
    this.sfxVol = 0.9;
    
    this.engineNode = null;
    this.engineGain = null;
    this.engineFilter = null;
    this.engineSub = null;
    
    this.driftNoise = null;
    this.driftGain = null;
    
    this.isMusicPlaying = false;
    this.musicInterval = null;
    this.step = 0;
    
    this.initialized = false;
  }

  init() {
    if (this.initialized) return;
    try {
      const AudioContext = window.AudioContext || window.webkitAudioContext;
      if (!AudioContext) return;
      this.ctx = new AudioContext();
      
      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.setValueAtTime(this.masterVol, this.ctx.currentTime);
      this.masterGain.connect(this.ctx.destination);
      
      this.musicGain = this.ctx.createGain();
      this.musicGain.gain.setValueAtTime(this.musicVol, this.ctx.currentTime);
      this.musicGain.connect(this.masterGain);
      
      this.sfxGain = this.ctx.createGain();
      this.sfxGain.gain.setValueAtTime(this.sfxVol, this.ctx.currentTime);
      this.sfxGain.connect(this.masterGain);
      
      this.setupDriftSound();
      this.initialized = true;
    } catch (e) {
      console.warn("WebAudio init error", e);
    }
  }

  resume() {
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  setVolumes(master, music, sfx) {
    this.masterVol = master;
    this.musicVol = music;
    this.sfxVol = sfx;
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    this.masterGain.gain.setValueAtTime(master, t);
    this.musicGain.gain.setValueAtTime(music, t);
    this.sfxGain.gain.setValueAtTime(sfx, t);
  }

  // Engine sound generator
  startEngine() {
    this.init();
    if (!this.ctx || this.engineNode) return;
    try {
      const t = this.ctx.currentTime;
      this.engineNode = this.ctx.createOscillator();
      this.engineSub = this.ctx.createOscillator();
      this.engineFilter = this.ctx.createBiquadFilter();
      this.engineGain = this.ctx.createGain();

      this.engineNode.type = 'sawtooth';
      this.engineNode.frequency.setValueAtTime(45, t);

      this.engineSub.type = 'triangle';
      this.engineSub.frequency.setValueAtTime(22.5, t);

      this.engineFilter.type = 'lowpass';
      this.engineFilter.frequency.setValueAtTime(250, t);
      this.engineFilter.Q.setValueAtTime(2.5, t);

      this.engineGain.gain.setValueAtTime(0.08, t);

      this.engineNode.connect(this.engineFilter);
      this.engineSub.connect(this.engineFilter);
      this.engineFilter.connect(this.engineGain);
      this.engineGain.connect(this.sfxGain);

      this.engineNode.start();
      this.engineSub.start();
    } catch (e) {
      console.warn(e);
    }
  }

  updateEngine(rpmRatio, throttle, isDrifting, isNitro) {
    if (!this.engineNode || !this.ctx) return;
    try {
      const t = this.ctx.currentTime;
      const baseFreq = 42 + rpmRatio * 180 + (isNitro ? 60 : 0);
      this.engineNode.frequency.setTargetAtTime(baseFreq, t, 0.05);
      this.engineSub.frequency.setTargetAtTime(baseFreq * 0.5, t, 0.05);

      const cutoff = 200 + rpmRatio * 750 + (throttle ? 300 : 0) + (isNitro ? 500 : 0);
      this.engineFilter.frequency.setTargetAtTime(cutoff, t, 0.06);

      const vol = 0.05 + rpmRatio * 0.15 + (throttle ? 0.08 : 0) + (isNitro ? 0.12 : 0);
      this.engineGain.gain.setTargetAtTime(vol, t, 0.05);
    } catch (e) {}
  }

  stopEngine() {
    if (this.engineNode) {
      try {
        this.engineNode.stop();
        this.engineSub.stop();
        this.engineNode.disconnect();
        this.engineSub.disconnect();
      } catch (e) {}
      this.engineNode = null;
      this.engineSub = null;
    }
  }

  // Drift screech sound with white noise + bandpass
  setupDriftSound() {
    if (!this.ctx) return;
    const bufferSize = this.ctx.sampleRate * 2;
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = Math.random() * 2 - 1;
    }

    const noise = this.ctx.createBufferSource();
    noise.buffer = buffer;
    noise.loop = true;

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.value = 1100;
    filter.Q.value = 3.5;

    this.driftGain = this.ctx.createGain();
    this.driftGain.gain.value = 0.0001;

    noise.connect(filter);
    filter.connect(this.driftGain);
    this.driftGain.connect(this.sfxGain);

    noise.start();
    this.driftNoise = noise;
  }

  setDriftIntensity(slip) {
    if (!this.driftGain || !this.ctx) return;
    const targetGain = Math.min(0.25, Math.max(0, slip) * 0.28);
    this.driftGain.gain.setTargetAtTime(targetGain, this.ctx.currentTime, 0.04);
  }

  // Nitro whoosh / shockwave blast
  playNitro(isShockwave = false) {
    this.init();
    if (!this.ctx) return;
    try {
      const t = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const filter = this.ctx.createBiquadFilter();

      osc.type = isShockwave ? 'sawtooth' : 'sine';
      osc.frequency.setValueAtTime(isShockwave ? 220 : 140, t);
      osc.frequency.exponentialRampToValueAtTime(isShockwave ? 550 : 320, t + 0.5);

      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(800, t);
      filter.frequency.linearRampToValueAtTime(2500, t + 0.4);

      gain.gain.setValueAtTime(0.25, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + (isShockwave ? 0.9 : 0.6));

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(this.sfxGain);

      osc.start(t);
      osc.stop(t + 0.9);
    } catch (e) {}
  }

  // Crash impact sound
  playCrash(intensity = 1) {
    this.init();
    if (!this.ctx) return;
    try {
      const t = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(120, t);
      osc.frequency.exponentialRampToValueAtTime(30, t + 0.35);

      gain.gain.setValueAtTime(Math.min(0.4, 0.2 * intensity), t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.35);

      osc.connect(gain);
      gain.connect(this.sfxGain);

      osc.start(t);
      osc.stop(t + 0.35);
    } catch (e) {}
  }

  // Stunt trigger sound
  playStunt() {
    this.init();
    if (!this.ctx) return;
    try {
      const t = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(350, t);
      osc.frequency.linearRampToValueAtTime(880, t + 0.25);

      gain.gain.setValueAtTime(0.18, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.35);

      osc.connect(gain);
      gain.connect(this.sfxGain);

      osc.start(t);
      osc.stop(t + 0.35);
    } catch (e) {}
  }

  // Countdown beeps
  playCountdown(count) {
    this.init();
    if (!this.ctx) return;
    try {
      const t = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const isGo = count <= 0;

      osc.type = 'sine';
      osc.frequency.setValueAtTime(isGo ? 880 : 440, t);

      gain.gain.setValueAtTime(0.25, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + (isGo ? 0.6 : 0.2));

      osc.connect(gain);
      gain.connect(this.sfxGain);

      osc.start(t);
      osc.stop(t + (isGo ? 0.6 : 0.2));
    } catch (e) {}
  }

  playClick() {
    this.init();
    if (!this.ctx) return;
    try {
      const t = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(600, t);
      osc.frequency.exponentialRampToValueAtTime(300, t + 0.04);
      gain.gain.setValueAtTime(0.1, t);
      gain.gain.linearRampToValueAtTime(0.001, t + 0.04);
      osc.connect(gain);
      gain.connect(this.sfxGain);
      osc.start(t);
      osc.stop(t + 0.04);
    } catch (e) {}
  }

  playReward() {
    this.init();
    if (!this.ctx) return;
    const notes = [523.25, 659.25, 783.99, 1046.50]; // C5, E5, G5, C6
    notes.forEach((freq, idx) => {
      setTimeout(() => {
        try {
          const t = this.ctx.currentTime;
          const osc = this.ctx.createOscillator();
          const gain = this.ctx.createGain();
          osc.type = 'triangle';
          osc.frequency.setValueAtTime(freq, t);
          gain.gain.setValueAtTime(0.15, t);
          gain.gain.exponentialRampToValueAtTime(0.001, t + 0.3);
          osc.connect(gain);
          gain.connect(this.sfxGain);
          osc.start(t);
          osc.stop(t + 0.3);
        } catch (e) {}
      }, idx * 80);
    });
  }

  // Procedural Electro/Synthwave background music generator
  startMusic() {
    this.init();
    if (this.isMusicPlaying || !this.ctx) return;
    this.isMusicPlaying = true;
    this.step = 0;

    const bassLine = [55, 55, 65.41, 55, 73.42, 65.41, 55, 49]; // A1, C2, D2...
    const melodyLine = [220, 261.63, 329.63, 392.00, 440, 329.63, 261.63, 196];

    const bpm = 138;
    const intervalMs = (60 / bpm / 4) * 1000; // 16th notes

    this.musicInterval = setInterval(() => {
      if (!this.isMusicPlaying || !this.ctx) return;
      const t = this.ctx.currentTime;

      // Kick on 0, 4, 8, 12
      if (this.step % 4 === 0) {
        const kick = this.ctx.createOscillator();
        const kickGain = this.ctx.createGain();
        kick.frequency.setValueAtTime(130, t);
        kick.frequency.exponentialRampToValueAtTime(35, t + 0.12);
        kickGain.gain.setValueAtTime(0.3, t);
        kickGain.gain.exponentialRampToValueAtTime(0.001, t + 0.13);
        kick.connect(kickGain);
        kickGain.connect(this.musicGain);
        kick.start(t);
        kick.stop(t + 0.13);
      }

      // Snare on 4, 12
      if (this.step % 8 === 4) {
        const snareOsc = this.ctx.createOscillator();
        const snareGain = this.ctx.createGain();
        snareOsc.type = 'triangle';
        snareOsc.frequency.setValueAtTime(180, t);
        snareOsc.frequency.exponentialRampToValueAtTime(60, t + 0.1);
        snareGain.gain.setValueAtTime(0.18, t);
        snareGain.gain.exponentialRampToValueAtTime(0.001, t + 0.1);
        snareOsc.connect(snareGain);
        snareGain.connect(this.musicGain);
        snareOsc.start(t);
        snareOsc.stop(t + 0.1);
      }

      // Bass synth on 8th notes
      if (this.step % 2 === 0) {
        const bassNote = bassLine[Math.floor(this.step / 2) % bassLine.length];
        const bassOsc = this.ctx.createOscillator();
        const bassFilter = this.ctx.createBiquadFilter();
        const bassGain = this.ctx.createGain();

        bassOsc.type = 'sawtooth';
        bassOsc.frequency.setValueAtTime(bassNote, t);

        bassFilter.type = 'lowpass';
        bassFilter.frequency.setValueAtTime(320, t);

        bassGain.gain.setValueAtTime(0.15, t);
        bassGain.gain.exponentialRampToValueAtTime(0.001, t + 0.16);

        bassOsc.connect(bassFilter);
        bassFilter.connect(bassGain);
        bassGain.connect(this.musicGain);

        bassOsc.start(t);
        bassOsc.stop(t + 0.18);
      }

      // Synth arpeggio
      if (this.step % 2 === 1 && Math.random() > 0.3) {
        const note = melodyLine[(this.step + 3) % melodyLine.length];
        const leadOsc = this.ctx.createOscillator();
        const leadGain = this.ctx.createGain();

        leadOsc.type = 'square';
        leadOsc.frequency.setValueAtTime(note * 1.5, t);

        leadGain.gain.setValueAtTime(0.04, t);
        leadGain.gain.exponentialRampToValueAtTime(0.001, t + 0.1);

        leadOsc.connect(leadGain);
        leadGain.connect(this.musicGain);

        leadOsc.start(t);
        leadOsc.stop(t + 0.1);
      }

      this.step = (this.step + 1) % 32;
    }, intervalMs);
  }

  stopMusic() {
    this.isMusicPlaying = false;
    if (this.musicInterval) {
      clearInterval(this.musicInterval);
      this.musicInterval = null;
    }
  }
}

window.AudioEngine = new AudioManager();
