// ChirpCoop 2D Game Engine - Extended Wooden Coop, Ragdoll Physics, Chick AI, Achievements & Seasonal Themes

(function() {
  'use strict';

  // --- NAMES & SEEDS ---
  const CHICK_NAMES = [
    'Pip', 'Nugget', 'Buttercup', 'Biscuit', 'Sunny', 'Peep', 'Clover',
    'Waffles', 'Peanut', 'Fluff', 'Rusty', 'Penny', 'Barnaby', 'Coco',
    'Mochi', 'Cheep', 'Dot', 'Ollie', 'Clementine', 'Dottie', 'Paprika',
    'Popcorn', 'Dumpling', 'Sesame', 'Sprout', 'Marshmallow', 'Tater',
    'Pebble', 'Buttons', 'Bumble', 'Noodle', 'Pickle', 'Pudding'
  ];

  // --- ACHIEVEMENTS DEFINITION ---
  const ACHIEVEMENTS_DEF = [
    { id: 'first_time', title: 'First Time', desc: 'First Time Playing the Game', icon: '🐣' },
    { id: 'raising_them', title: 'Raising Them', desc: 'Feed Them First Time', icon: '🌾' },
    { id: 'angry', title: 'Angry', desc: 'Angry Chick', icon: '😡' },
    { id: 'nooo', title: 'Nooo!', desc: 'First Dead Chick', icon: '😢' },
    { id: 'failed_them', title: 'I Failed Them', desc: 'All Chick Are Dead', icon: '🪦' },
    { id: 'boo', title: 'Boo!', desc: 'Play the Game on Halloween', icon: '🎃' },
    { id: 'tweet', title: "It's Tweeeettt!!", desc: 'Play the Game on Christmas', icon: '🎄' },
    { id: 'happy_new_year', title: 'Happy New Year!', desc: 'Play the Game on New Year', icon: '🎆' }
  ];

  // --- GAME CONSTANTS ---
  const COOP_WIDTH = 2600;
  const GRAVITY = 0.45;
  const MAX_FALL_SPEED = 14;

  // --- ENGINE STATE ---
  let canvas, ctx;
  let coopHeight = 700;
  let viewportWidth = window.innerWidth;
  let viewportHeight = window.innerHeight;

  let cameraX = 0;
  let isDragging = false;
  let dragStartX = 0;
  let dragStartCameraX = 0;
  let dragVelocityX = 0;
  let lastDragTime = 0;
  let lastTouchX = 0;

  let screenShake = 0;
  let screenShakeX = 0;
  let screenShakeY = 0;

  let lastFrameTime = performance.now();
  let selectedChick = null;
  let toastTimer = null;

  // Floating particles (hearts, zZZ, sweat, crumbs, snow, confetti)
  let particles = [];

  // Platforms & geometry
  let platforms = [];
  let ramps = [];
  let foodTrough = null;
  let waterTrough = null;

  // State Persistence
  let gameState = {
    chicks: [],
    settings: {
      maxChicks: 15,
      timezone: 'device', // 'device' | 'utc'
      themeMode: 'auto',  // 'auto' | 'halloween' | 'christmas' | 'newyear' | 'classic'
      masterVolume: 0.8,
      chirpVolume: 0.8,
      slamVolume: 0.9,
      bellVolume: 0.85,
      ambienceVolume: 0.35,
      ambienceEnabled: true
    },
    achievements: {},
    troughFood: 100,
    troughWater: 100,
    hatchDate: Date.now(),
    hasFedOnce: false
  };

  function getGroundY() {
    return coopHeight - 65;
  }

  // --- SEASONAL THEME RESOLVER ---
  function getActiveTheme() {
    if (gameState.settings.themeMode && gameState.settings.themeMode !== 'auto') {
      return gameState.settings.themeMode;
    }
    const now = new Date();
    const month = now.getMonth(); // 0 = Jan, 9 = Oct, 10 = Nov, 11 = Dec
    const day = now.getDate();

    // Halloween: October 30th til November 1st
    if ((month === 9 && (day === 30 || day === 31)) || (month === 10 && day === 1)) {
      return 'halloween';
    }

    // Christmas: December 25th til December 30th
    if (month === 11 && day >= 25 && day <= 30) {
      return 'christmas';
    }

    // New Year: January 1st to Midnight Jan 2nd
    if (month === 0 && (day === 1 || day === 2)) {
      return 'newyear';
    }

    return 'classic';
  }

  // --- ACHIEVEMENTS SYSTEM ---
  function unlockAchievement(id) {
    if (!gameState.achievements) gameState.achievements = {};
    if (gameState.achievements[id]) return; // already unlocked

    const def = ACHIEVEMENTS_DEF.find(a => a.id === id);
    if (!def) return;

    gameState.achievements[id] = Date.now();
    saveToStorage();

    // Play sound
    if (window.soundEngine) {
      window.soundEngine.playAchievement();
    }

    // Display animated toast notification
    showAchievementToast(def);
    updateAchievementsModal();
  }

  function showAchievementToast(def) {
    const toast = document.getElementById('achievement-toast');
    if (!toast) return;

    document.getElementById('toast-icon').textContent = def.icon;
    document.getElementById('toast-title').textContent = def.title;
    document.getElementById('toast-desc').textContent = def.desc;

    toast.classList.remove('toast-hidden');
    toast.classList.add('toast-visible');

    if (toastTimer) clearTimeout(toastTimer);
    toastTimer = setTimeout(() => {
      toast.classList.remove('toast-visible');
      toast.classList.add('toast-hidden');
    }, 4500);
  }

  function checkSeasonalAchievements() {
    const theme = getActiveTheme();
    if (theme === 'halloween') {
      unlockAchievement('boo');
    } else if (theme === 'christmas') {
      unlockAchievement('tweet');
    } else if (theme === 'newyear') {
      unlockAchievement('happy_new_year');
    }
  }

  window.openAchievements = function() {
    window.soundEngine.ensureReady();
    updateAchievementsModal();
    document.getElementById('achievements-modal').classList.remove('hidden-modal');
  };

  window.closeAchievements = function() {
    document.getElementById('achievements-modal').classList.add('hidden-modal');
  };

  function updateAchievementsModal() {
    const listEl = document.getElementById('achievements-list');
    const progressEl = document.getElementById('achievements-progress');
    if (!listEl) return;

    const achs = gameState.achievements || {};
    let unlockedCount = 0;

    listEl.innerHTML = ACHIEVEMENTS_DEF.map(def => {
      const isUnlocked = !!achs[def.id];
      if (isUnlocked) unlockedCount++;

      const dateStr = isUnlocked && typeof achs[def.id] === 'number'
        ? new Date(achs[def.id]).toLocaleDateString(undefined, { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })
        : 'Unlocked';

      return `
        <div class="achievement-card ${isUnlocked ? 'unlocked' : 'locked'} rounded-2xl p-3.5 flex items-center justify-between gap-3 border">
          <div class="flex items-center gap-3">
            <div class="w-12 h-12 rounded-xl ${isUnlocked ? 'bg-amber-500/25 border border-amber-400/40 text-amber-200' : 'bg-white/5 border border-white/10 text-slate-500'} flex items-center justify-center text-2xl shadow-inner shrink-0">
              ${isUnlocked ? def.icon : '🔒'}
            </div>
            <div>
              <div class="flex items-center gap-2">
                <h4 class="font-bold text-sm ${isUnlocked ? 'text-amber-100 font-sans' : 'text-slate-400'}">${def.title}</h4>
                ${isUnlocked ? '<span class="text-[10px] font-black px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/30">COMPLETED</span>' : ''}
              </div>
              <p class="text-xs ${isUnlocked ? 'text-amber-200/75' : 'text-slate-500'} mt-0.5">${def.desc}</p>
            </div>
          </div>
          <div class="text-right shrink-0">
            ${isUnlocked 
              ? `<span class="text-[11px] text-amber-300/80 font-mono">${dateStr}</span>`
              : `<span class="text-xs text-slate-500 font-semibold">Locked</span>`
            }
          </div>
        </div>
      `;
    }).join('');

    if (progressEl) {
      const pct = Math.round((unlockedCount / ACHIEVEMENTS_DEF.length) * 100);
      progressEl.textContent = `${unlockedCount} / ${ACHIEVEMENTS_DEF.length} Unlocked (${pct}%)`;
    }
  }

  // --- COOP GEOMETRY GENERATOR ---
  function initCoopGeometry() {
    coopHeight = window.innerHeight;
    const groundY = getGroundY();

    const h1 = Math.min(100, coopHeight * 0.26);
    const h2 = Math.min(180, coopHeight * 0.48);
    const h3 = Math.min(250, coopHeight * 0.66);
    const h4 = Math.min(120, coopHeight * 0.32);
    const h5 = Math.min(190, coopHeight * 0.50);

    platforms = [
      // Ground floor
      { x: 0, y: groundY, w: COOP_WIDTH, h: 90, isGround: true },
      // Lower Left Straw Tier
      { x: 120, y: groundY - h1, w: 420, h: 18, name: 'Hay Loft' },
      // Middle High Lookout Platform
      { x: 740, y: groundY - h2, w: 560, h: 18, name: 'Sun Deck' },
      // High Roosting Bar (thin perch)
      { x: 1100, y: groundY - h3, w: 450, h: 12, isRoost: true, name: 'High Perch' },
      // Right Nesting Station
      { x: 1680, y: groundY - h4, w: 560, h: 18, name: 'Nesting Shelf' },
      // Far Right Cozy Bunk
      { x: 2280, y: groundY - h5, w: 300, h: 18, name: 'Top Bunk' }
    ];

    ramps = [
      // Ground up to Lower Left Shelf
      { x1: 40, y1: groundY, x2: 140, y2: groundY - h1 },
      // Lower Left Shelf up to Middle Platform
      { x1: 520, y1: groundY - h1, x2: 760, y2: groundY - h2 },
      // Ground up to Right Nesting Shelf
      { x1: 1520, y1: groundY, x2: 1700, y2: groundY - h4 },
      // Right Shelf up to Far Right Bunk
      { x1: 2220, y1: groundY - h4, x2: 2300, y2: groundY - h5 }
    ];

    // Troughs
    foodTrough = {
      x: 620,
      y: groundY - 34,
      w: 160,
      h: 34,
      foodLevel: gameState.troughFood
    };

    waterTrough = {
      x: 1380,
      y: groundY - 34,
      w: 160,
      h: 34,
      waterLevel: gameState.troughWater
    };
  }

  // --- PROCEDURAL CHICK GENERATION ---
  function createChick(initialX = null, initialY = null) {
    const groundY = getGroundY();
    const name = CHICK_NAMES[Math.floor(Math.random() * CHICK_NAMES.length)];
    const gender = Math.random() < 0.5 ? 'male' : 'female';
    const now = new Date();
    const hours = now.getHours();
    const mins = String(now.getMinutes()).padStart(2, '0');
    const ampm = hours >= 12 ? 'PM' : 'AM';
    const hour12 = hours % 12 || 12;
    const birthFormatted = `Born today at ${hour12}:${mins} ${ampm}`;

    return {
      id: 'chick_' + Math.random().toString(36).substr(2, 9),
      name: name,
      gender: gender,
      outfitIndex: Math.floor(Math.random() * 4),
      birthTimestamp: Date.now(),
      x: initialX !== null ? initialX : 200 + Math.random() * (COOP_WIDTH - 400),
      y: (initialY !== null && initialY <= groundY - 17 && initialY >= 20) ? initialY : (groundY - 17),
      vx: (Math.random() - 0.5) * 1.5,
      vy: 0,
      radius: 17,
      facing: Math.random() < 0.5 ? 1 : -1,
      state: 'idle',
      stateTimer: 1 + Math.random() * 3,
      angryTimer: 0,
      isAngry: false,
      isGrounded: false,
      rotation: 0,
      angularVelocity: 0,
      petCount: 0,
      hopCooldown: Math.random() * 4,
      chirpCooldown: 3 + Math.random() * 8,
      peckPhase: 0,
      walkPhase: 0,
      sleepPhase: 0,
      wingFlutter: 0,
      hunger: 80 + Math.random() * 20,
      isFedMorning: false,
      isFedEvening: false,
      dead: false
    };
  }

  // --- TIME & FEEDING LOGIC ---
  function getTimeInfo() {
    const now = new Date();
    let hours, minutes;
    if (gameState.settings.timezone === 'utc') {
      hours = now.getUTCHours();
      minutes = now.getUTCMinutes();
    } else {
      hours = now.getHours();
      minutes = now.getMinutes();
    }
    const minsPadded = String(minutes).padStart(2, '0');
    const hoursPadded = String(hours).padStart(2, '0');
    const timeStr = `${hoursPadded}:${minsPadded}`;

    let statusText = 'Flock Happy & Safe';
    let statusLevel = 'safe';

    if (hours >= 7 && hours < 14) {
      statusText = 'Morning Feed Window (7 AM - 2 PM)';
      statusLevel = 'ready';
    } else if (hours >= 14 && hours < 16) {
      statusText = 'Afternoon Rest (Feed at 4:00 PM)';
      statusLevel = 'safe';
    } else if (hours >= 16 && hours < 21) {
      statusText = 'Evening Feed Window (4 PM - 9 PM)';
      statusLevel = 'ready';
    } else {
      statusText = 'Night Roosting (Feed at 7:00 AM)';
      statusLevel = 'safe';
    }

    return {
      hours,
      minutes,
      timeStr,
      statusText,
      statusLevel
    };
  }

  function checkHungerAndDeath() {
    const timeInfo = getTimeInfo();

    gameState.chicks.forEach(chick => {
      if (chick.dead) return;

      // Missed 7 AM feeding window past 2 PM (14:00)
      if (timeInfo.hours >= 14 && timeInfo.hours < 16 && !chick.isFedMorning) {
        killChick(chick, 'Starved (Missed 7:00 AM window by 2:00 PM)');
      }
      // Missed 4 PM feeding window past 9 PM (21:00)
      if ((timeInfo.hours >= 21 || timeInfo.hours < 7) && !chick.isFedEvening) {
        killChick(chick, 'Starved (Missed 4:00 PM window by 9:00 PM)');
      }
    });

    if (timeInfo.hours === 7 && timeInfo.minutes === 0) {
      gameState.chicks.forEach(c => { c.isFedMorning = false; });
    }
    if (timeInfo.hours === 16 && timeInfo.minutes === 0) {
      gameState.chicks.forEach(c => { c.isFedEvening = false; });
    }

    const aliveCount = gameState.chicks.filter(c => !c.dead).length;
    const gameOverEl = document.getElementById('game-over-modal');
    if (aliveCount === 0 && gameState.chicks.length > 0 && gameOverEl.classList.contains('hidden-modal')) {
      showGameOver();
    }
  }

  function killChick(chick, reason) {
    chick.dead = true;
    chick.state = 'dead';
    chick.isAngry = false;
    chick.rotation = Math.PI / 2;
    chick.vy = 2;

    // Achievement: First Dead Chick
    unlockAchievement('nooo');
  }

  function showGameOver() {
    const modal = document.getElementById('game-over-modal');
    const statsEl = document.getElementById('game-over-stats');
    const totalBorn = gameState.chicks.length;
    statsEl.textContent = `All ${totalBorn} chicks have passed away due to missed feeding schedules. Ensure troughs are filled during 7 AM & 4 PM windows!`;
    modal.classList.remove('hidden-modal');

    // Achievement: All Chick Are Dead
    unlockAchievement('failed_them');
  }

  // --- CHICK PHYSICS & BEHAVIOR UPDATE ---
  function updateChicks(dt) {
    const groundY = getGroundY();

    // Random bully / angry trigger
    if (Math.random() < 0.003 && !gameState.chicks.some(c => c.isAngry && !c.dead)) {
      const livingChicks = gameState.chicks.filter(c => !c.dead && c.state !== 'sleeping');
      if (livingChicks.length > 0) {
        const bully = livingChicks[Math.floor(Math.random() * livingChicks.length)];
        bully.isAngry = true;
        bully.state = 'angry';
        bully.angryTimer = 20;
        window.soundEngine.playChirp('angry', (bully.x - cameraX - viewportWidth/2) / (viewportWidth/2));

        // Achievement: Angry Chick
        unlockAchievement('angry');
      }
    }

    gameState.chicks.forEach(chick => {
      if (chick.dead) {
        if (!chick.isGrounded) {
          chick.vy += GRAVITY;
          chick.y += chick.vy;
          if (chick.y >= groundY - 10) {
            chick.y = groundY - 10;
            chick.vy = 0;
            chick.isGrounded = true;
          }
        }
        return;
      }

      chick.stateTimer -= dt;
      chick.hopCooldown -= dt;
      chick.chirpCooldown -= dt;

      if (chick.chirpCooldown <= 0) {
        chick.chirpCooldown = 6 + Math.random() * 12;
        if (chick.state !== 'sleeping') {
          const pan = (chick.x - cameraX - viewportWidth / 2) / (viewportWidth / 2);
          window.soundEngine.playChirp(chick.isAngry ? 'angry' : 'happy', pan);
        }
      }

      // Angry Troublemaker behavior
      if (chick.isAngry) {
        chick.angryTimer -= dt;
        if (chick.angryTimer <= 0) {
          chick.isAngry = false;
          chick.state = 'idle';
        } else {
          let nearestSibling = null;
          let minDist = 400;
          gameState.chicks.forEach(s => {
            if (s !== chick && !s.dead) {
              const d = Math.abs(s.x - chick.x);
              if (d < minDist) {
                minDist = d;
                nearestSibling = s;
              }
            }
          });

          if (nearestSibling) {
            chick.facing = nearestSibling.x > chick.x ? 1 : -1;
            chick.vx = chick.facing * 1.8;
            chick.state = 'angry';

            if (minDist < 30) {
              nearestSibling.vx = chick.facing * 3;
              nearestSibling.vy = -3;
              nearestSibling.isGrounded = false;
              spawnParticles('💢', (chick.x + nearestSibling.x) / 2, chick.y - 15, 1);
              window.soundEngine.playChirp('angry', (chick.x - cameraX - viewportWidth/2) / (viewportWidth/2));
            }
          }
        }
      }

      // State transitions
      if (chick.stateTimer <= 0 && !chick.isAngry && chick.state !== 'startled' && chick.state !== 'eating') {
        const roll = Math.random();
        if (roll < 0.35) {
          chick.state = 'idle';
          chick.vx = 0;
          chick.stateTimer = 2 + Math.random() * 4;
        } else if (roll < 0.7) {
          chick.state = 'walking';
          chick.facing = Math.random() < 0.5 ? 1 : -1;
          chick.vx = chick.facing * (0.6 + Math.random() * 0.8);
          chick.stateTimer = 3 + Math.random() * 5;
        } else if (roll < 0.85) {
          chick.state = 'sleeping';
          chick.vx = 0;
          chick.stateTimer = 8 + Math.random() * 12;
        } else {
          chick.state = 'walking';
          chick.vx = (Math.random() < 0.5 ? 1 : -1) * 1.2;
          chick.stateTimer = 2;
          if (chick.isGrounded && chick.hopCooldown <= 0) {
            chick.vy = -5.5 - Math.random() * 2;
            chick.isGrounded = false;
            chick.hopCooldown = 4;
          }
        }
      }

      // Eating State Behavior
      if (chick.state === 'eating') {
        chick.peckPhase += 0.2;
        chick.vx = 0;
        if (Math.sin(chick.peckPhase) > 0.8 && Math.random() < 0.2) {
          window.soundEngine.playPeck();
          spawnParticles('🌾', chick.x + chick.facing * 10, chick.y + 10, 1);
        }
        if (chick.stateTimer <= 0) {
          chick.state = 'idle';
          chick.isFedMorning = true;
          chick.isFedEvening = true;
          chick.hunger = 100;
        }
      }

      // Sleeping Particles
      if (chick.state === 'sleeping') {
        chick.sleepPhase += dt;
        if (Math.random() < 0.03) {
          spawnParticles('zZZ', chick.x + 8, chick.y - 18, 1);
        }
      }

      // Startled Recovery
      if (chick.state === 'startled' && chick.isGrounded) {
        chick.state = 'idle';
        chick.stateTimer = 1.5;
      }

      chick.vy = Math.min(chick.vy + GRAVITY, MAX_FALL_SPEED);
      chick.x += chick.vx;
      chick.y += chick.vy;

      // Boundary clamping
      if (chick.x < 30) {
        chick.x = 30;
        chick.vx = Math.abs(chick.vx);
        chick.facing = 1;
      }
      if (chick.x > COOP_WIDTH - 30) {
        chick.x = COOP_WIDTH - 30;
        chick.vx = -Math.abs(chick.vx);
        chick.facing = -1;
      }

      // Ramp Collisions
      let onRamp = false;
      for (const ramp of ramps) {
        const minX = Math.min(ramp.x1, ramp.x2);
        const maxX = Math.max(ramp.x1, ramp.x2);
        if (chick.x >= minX && chick.x <= maxX) {
          const t = (chick.x - ramp.x1) / (ramp.x2 - ramp.x1);
          const rampY = ramp.y1 + t * (ramp.y2 - ramp.y1);
          if (chick.y + chick.radius >= rampY - 6 && chick.y + chick.radius <= rampY + 16 && chick.vy >= 0) {
            chick.y = rampY - chick.radius;
            chick.vy = 0;
            chick.isGrounded = true;
            onRamp = true;
            break;
          }
        }
      }

      // Platform Collisions
      if (!onRamp) {
        let landed = false;
        for (const plat of platforms) {
          if (chick.x >= plat.x && chick.x <= plat.x + plat.w) {
            if (chick.y + chick.radius >= plat.y && chick.y + chick.radius <= plat.y + 18 && chick.vy >= 0) {
              chick.y = plat.y - chick.radius;
              chick.vy = 0;
              chick.isGrounded = true;
              landed = true;
              break;
            }
          }
        }

        // Hard floor boundary safety clamp - guarantees chicks never fall through floor
        if (chick.y + chick.radius >= groundY) {
          chick.y = groundY - chick.radius;
          chick.vy = 0;
          chick.isGrounded = true;
          landed = true;
        }

        if (!landed) {
          chick.isGrounded = false;
          if (chick.vy > 4) {
            chick.rotation += chick.facing * 0.08;
            chick.wingFlutter += 0.4;
          } else {
            chick.rotation *= 0.85;
          }
        } else {
          chick.rotation = 0;
        }
      }

      if (chick.state === 'walking' || chick.state === 'angry') {
        chick.walkPhase += 0.25;
      } else {
        chick.walkPhase = 0;
      }
    });
  }

  // --- PARTICLES ENGINE ---
  function spawnParticles(type, x, y, count = 1) {
    for (let i = 0; i < count; i++) {
      particles.push({
        type: type,
        x: x + (Math.random() - 0.5) * 12,
        y: y + (Math.random() - 0.5) * 6,
        vx: (Math.random() - 0.5) * 1.5,
        vy: -0.8 - Math.random() * 1.2,
        opacity: 1,
        life: 1.0,
        scale: 0.8 + Math.random() * 0.4
      });
    }
  }

  function updateParticles(dt) {
    const theme = getActiveTheme();

    // Atmospheric weather particles based on season
    if (theme === 'christmas') {
      const snowCount = particles.filter(p => p.type === 'snow').length;
      if (snowCount < 60) {
        particles.push({
          type: 'snow',
          x: cameraX + Math.random() * viewportWidth,
          y: -10,
          vx: (Math.random() - 0.5) * 0.8,
          vy: 0.8 + Math.random() * 1.2,
          radius: 1.5 + Math.random() * 2,
          opacity: 0.85,
          life: 8.0
        });
      }
    } else if (theme === 'newyear') {
      const confettiCount = particles.filter(p => p.type === 'confetti').length;
      if (confettiCount < 40) {
        const colors = ['#facc15', '#38bdf8', '#f43f5e', '#a855f7', '#ffffff'];
        particles.push({
          type: 'confetti',
          x: cameraX + Math.random() * viewportWidth,
          y: -10,
          vx: (Math.random() - 0.5) * 1.2,
          vy: 1.2 + Math.random() * 1.5,
          color: colors[Math.floor(Math.random() * colors.length)],
          rot: Math.random() * Math.PI,
          rotV: (Math.random() - 0.5) * 0.1,
          size: 4 + Math.random() * 4,
          opacity: 0.9,
          life: 6.0
        });
      }
    }

    for (let i = particles.length - 1; i >= 0; i--) {
      const p = particles[i];
      p.x += p.vx;
      p.y += p.vy;

      if (p.type === 'snow') {
        p.vx = Math.sin(p.y * 0.04) * 0.6;
        if (p.y > coopHeight) particles.splice(i, 1);
      } else if (p.type === 'confetti') {
        p.rot += p.rotV;
        if (p.y > coopHeight) particles.splice(i, 1);
      } else {
        p.life -= dt * 0.9;
        p.opacity = Math.max(0, p.life);
        if (p.life <= 0) particles.splice(i, 1);
      }
    }
  }

  // --- RENDERING PIPELINE ---
  function render() {
    ctx.clearRect(0, 0, viewportWidth, viewportHeight);

    ctx.save();
    if (screenShake > 0) {
      screenShakeX = (Math.random() - 0.5) * screenShake * 14;
      screenShakeY = (Math.random() - 0.5) * screenShake * 14;
      screenShake = Math.max(0, screenShake - 0.05);
      ctx.translate(screenShakeX, screenShakeY);
    }

    ctx.translate(-cameraX, 0);

    const theme = getActiveTheme();

    // 1. Draw Wooden Background Planks & Lighting
    drawCoopBackground(theme);

    // 2. Draw Platforms, Ramps & Seasonal Structures (Christmas Tree / Pumpkins / Banners)
    drawCoopArchitecture(theme);

    // 3. Draw Troughs (Food & Water)
    drawTroughs(theme);

    // 4. Draw Chicks with Seasonal Outfits
    drawChicks(theme);

    // 5. Draw Atmospheric / Interaction Particles
    drawParticles();

    // 6. Draw Foreground Lighting & Vignette
    drawCoopForeground();

    ctx.restore();
  }

  function drawCoopBackground(theme) {
    const plankWidth = 140;
    const totalPlanks = Math.ceil(COOP_WIDTH / plankWidth);

    for (let i = 0; i < totalPlanks; i++) {
      const px = i * plankWidth;
      const isAlt = i % 2 === 0;

      if (theme === 'halloween') {
        ctx.fillStyle = isAlt ? '#2d161a' : '#241014';
      } else if (theme === 'christmas') {
        ctx.fillStyle = isAlt ? '#2a1a14' : '#22140f';
      } else if (theme === 'newyear') {
        ctx.fillStyle = isAlt ? '#201625' : '#19101f';
      } else {
        ctx.fillStyle = isAlt ? '#3b2014' : '#331b11';
      }

      ctx.fillRect(px, 0, plankWidth, coopHeight);

      ctx.strokeStyle = '#1a0b05';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(px, 0);
      ctx.lineTo(px, coopHeight);
      ctx.stroke();

      ctx.fillStyle = '#140803';
      ctx.beginPath();
      ctx.arc(px + 20, 50, 3.5, 0, Math.PI * 2);
      ctx.arc(px + plankWidth - 20, 50, 3.5, 0, Math.PI * 2);
      ctx.arc(px + 20, coopHeight - 90, 3.5, 0, Math.PI * 2);
      ctx.arc(px + plankWidth - 20, coopHeight - 90, 3.5, 0, Math.PI * 2);
      ctx.fill();
    }

    // Ambient Lighting Glows
    let glowColor1 = 'rgba(253, 230, 138, 0.28)';
    let glowColor2 = 'rgba(245, 158, 11, 0.12)';
    if (theme === 'halloween') {
      glowColor1 = 'rgba(249, 115, 22, 0.28)';
      glowColor2 = 'rgba(168, 85, 247, 0.16)';
    } else if (theme === 'christmas') {
      glowColor1 = 'rgba(254, 240, 138, 0.26)';
      glowColor2 = 'rgba(34, 197, 94, 0.12)';
    } else if (theme === 'newyear') {
      glowColor1 = 'rgba(250, 204, 21, 0.32)';
      glowColor2 = 'rgba(192, 132, 252, 0.18)';
    }

    const lampGlow = ctx.createRadialGradient(900, 120, 10, 900, 120, 380);
    lampGlow.addColorStop(0, glowColor1);
    lampGlow.addColorStop(0.5, glowColor2);
    lampGlow.addColorStop(1, 'rgba(0, 0, 0, 0)');
    ctx.fillStyle = lampGlow;
    ctx.fillRect(450, 0, 900, 500);

    const lamp2Glow = ctx.createRadialGradient(1900, 120, 10, 1900, 120, 360);
    lamp2Glow.addColorStop(0, glowColor1);
    lamp2Glow.addColorStop(0.6, glowColor2);
    lamp2Glow.addColorStop(1, 'rgba(0, 0, 0, 0)');
    ctx.fillStyle = lamp2Glow;
    ctx.fillRect(1500, 0, 800, 500);

    // Hanging Lamps
    [900, 1900].forEach(lx => {
      ctx.strokeStyle = '#1e1008';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(lx, 0);
      ctx.lineTo(lx, 85);
      ctx.stroke();

      ctx.fillStyle = theme === 'halloween' ? '#581c87' : (theme === 'christmas' ? '#991b1b' : '#a16207');
      ctx.beginPath();
      ctx.moveTo(lx - 26, 105);
      ctx.lineTo(lx + 26, 105);
      ctx.lineTo(lx + 8, 85);
      ctx.lineTo(lx - 8, 85);
      ctx.closePath();
      ctx.fill();

      ctx.fillStyle = theme === 'halloween' ? '#fb923c' : '#fef08a';
      ctx.beginPath();
      ctx.arc(lx, 108, 9, 0, Math.PI * 2);
      ctx.fill();
    });

    // Halloween Cobwebs
    if (theme === 'halloween') {
      drawCobwebs();
    }

    // New Year Hanging Banner
    if (theme === 'newyear') {
      drawNewYearBanner();
    }
  }

  function drawCobwebs() {
    ctx.save();
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.28)';
    ctx.lineWidth = 1.2;

    // Left Corner Web
    ctx.beginPath();
    ctx.moveTo(0, 0); ctx.lineTo(130, 0);
    ctx.moveTo(0, 0); ctx.lineTo(95, 45);
    ctx.moveTo(0, 0); ctx.lineTo(45, 95);
    ctx.moveTo(0, 0); ctx.lineTo(0, 130);
    [35, 70, 105].forEach(r => {
      ctx.moveTo(r, 0);
      ctx.quadraticCurveTo(r * 0.7, r * 0.7, 0, r);
    });
    ctx.stroke();

    // Far Right Corner Web
    ctx.beginPath();
    ctx.moveTo(COOP_WIDTH, 0); ctx.lineTo(COOP_WIDTH - 130, 0);
    ctx.moveTo(COOP_WIDTH, 0); ctx.lineTo(COOP_WIDTH - 95, 45);
    ctx.moveTo(COOP_WIDTH, 0); ctx.lineTo(COOP_WIDTH - 45, 95);
    ctx.moveTo(COOP_WIDTH, 0); ctx.lineTo(COOP_WIDTH, 130);
    [35, 70, 105].forEach(r => {
      ctx.moveTo(COOP_WIDTH - r, 0);
      ctx.quadraticCurveTo(COOP_WIDTH - r * 0.7, r * 0.7, COOP_WIDTH, r);
    });
    ctx.stroke();
    ctx.restore();
  }

  function drawNewYearBanner() {
    ctx.save();
    const bx = 1100;
    const by = 45;
    ctx.fillStyle = 'rgba(24, 10, 36, 0.85)';
    ctx.strokeStyle = '#facc15';
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ctx.roundRect(bx - 160, by - 20, 320, 42, 12);
    ctx.fill();
    ctx.stroke();

    ctx.font = '900 16px sans-serif';
    ctx.fillStyle = '#fef08a';
    ctx.textAlign = 'center';
    ctx.fillText('🎆 HAPPY NEW YEAR 2027 🎆', bx, by + 6);
    ctx.restore();
  }

  function drawCoopArchitecture(theme) {
    const groundY = getGroundY();

    // Draw Ramps
    ramps.forEach(ramp => {
      ctx.save();
      ctx.strokeStyle = '#5c351f';
      ctx.lineWidth = 14;
      ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.moveTo(ramp.x1, ramp.y1);
      ctx.lineTo(ramp.x2, ramp.y2);
      ctx.stroke();

      const dx = ramp.x2 - ramp.x1;
      const dy = ramp.y2 - ramp.y1;
      const steps = 6;
      ctx.strokeStyle = '#7c4a2d';
      ctx.lineWidth = 4;
      for (let s = 1; s < steps; s++) {
        const sx = ramp.x1 + (dx / steps) * s;
        const sy = ramp.y1 + (dy / steps) * s;
        ctx.beginPath();
        ctx.moveTo(sx - 8, sy - 6);
        ctx.lineTo(sx + 8, sy + 6);
        ctx.stroke();
      }

      // Christmas Snow on Ramps
      if (theme === 'christmas') {
        ctx.strokeStyle = '#f8fafc';
        ctx.lineWidth = 5;
        ctx.beginPath();
        ctx.moveTo(ramp.x1, ramp.y1 - 6);
        ctx.lineTo(ramp.x2, ramp.y2 - 6);
        ctx.stroke();
      }

      ctx.restore();
    });

    // Draw Platforms
    platforms.forEach(plat => {
      if (plat.isGround) {
        ctx.fillStyle = '#4a2816';
        ctx.fillRect(plat.x, plat.y, plat.w, plat.h);

        // Bedding
        if (theme === 'christmas') {
          // Frosty straw + snow layer
          ctx.fillStyle = '#e2e8f0';
          ctx.fillRect(plat.x, plat.y, plat.w, 14);
        } else {
          ctx.fillStyle = '#d97706';
          ctx.fillRect(plat.x, plat.y, plat.w, 14);

          ctx.strokeStyle = '#fde68a';
          ctx.lineWidth = 2;
          for (let bx = 0; bx < COOP_WIDTH; bx += 22) {
            ctx.beginPath();
            ctx.moveTo(bx, plat.y + 12);
            ctx.lineTo(bx + (bx % 16) - 8, plat.y - 4);
            ctx.stroke();
          }
        }
      } else if (plat.isRoost) {
        ctx.fillStyle = '#78350f';
        ctx.beginPath();
        ctx.roundRect(plat.x, plat.y, plat.w, plat.h, 6);
        ctx.fill();

        ctx.fillStyle = '#92400e';
        ctx.fillRect(plat.x, plat.y + 2, plat.w, 4);

        ctx.fillStyle = '#3b1c0e';
        ctx.fillRect(plat.x + 20, plat.y + plat.h, 12, 120);
        ctx.fillRect(plat.x + plat.w - 32, plat.y + plat.h, 12, 120);

        // Christmas Snow on Roost
        if (theme === 'christmas') {
          ctx.fillStyle = '#ffffff';
          ctx.beginPath();
          ctx.roundRect(plat.x, plat.y - 3, plat.w, 5, 2.5);
          ctx.fill();
        }
      } else {
        ctx.fillStyle = '#3f1f10';
        ctx.fillRect(plat.x + 30, plat.y + plat.h, 16, groundY - plat.y);
        ctx.fillRect(plat.x + plat.w - 46, plat.y + plat.h, 16, groundY - plat.y);

        ctx.fillStyle = '#5c3118';
        ctx.beginPath();
        ctx.roundRect(plat.x, plat.y, plat.w, plat.h, [4, 4, 0, 0]);
        ctx.fill();

        ctx.fillStyle = '#784222';
        ctx.fillRect(plat.x, plat.y, plat.w, 4);

        // Christmas Snow on Shelf Platforms
        if (theme === 'christmas') {
          ctx.fillStyle = '#f8fafc';
          ctx.beginPath();
          ctx.roundRect(plat.x - 2, plat.y - 4, plat.w + 4, 7, [4, 4, 2, 2]);
          ctx.fill();
        } else {
          ctx.fillStyle = '#fef08a';
          for (let s = 10; s < plat.w - 10; s += 28) {
            ctx.fillRect(plat.x + s, plat.y - 2, 8, 3);
          }
        }
      }
    });

    // Nesting Boxes on Shelf 3
    const plat3 = platforms.find(p => p.name === 'Nesting Shelf');
    const nestX = 1740;
    const nestY = plat3 ? plat3.y - 50 : groundY - 180;
    ctx.fillStyle = '#45220f';
    ctx.fillRect(nestX, nestY, 200, 50);
    ctx.fillStyle = '#653317';
    ctx.fillRect(nestX + 10, nestY + 10, 80, 40);
    ctx.fillRect(nestX + 110, nestY + 10, 80, 40);

    ctx.fillStyle = theme === 'christmas' ? '#e2e8f0' : '#facc15';
    ctx.beginPath();
    ctx.ellipse(nestX + 50, nestY + 38, 28, 9, 0, 0, Math.PI * 2);
    ctx.ellipse(nestX + 150, nestY + 38, 28, 9, 0, 0, Math.PI * 2);
    ctx.fill();

    // SEASONAL PROPS:
    // 1. Christmas: Decorated Christmas Tree
    if (theme === 'christmas') {
      const plat2 = platforms.find(p => p.name === 'Sun Deck');
      const treeX = plat2 ? plat2.x + plat2.w / 2 : 1000;
      const treeY = plat2 ? plat2.y : groundY;
      drawChristmasTree(treeX, treeY);
    }

    // 2. Halloween: Carved Jack-o'-Lanterns with glowing faces
    if (theme === 'halloween') {
      drawJackOLantern(240, groundY - 14 - Math.min(100, coopHeight * 0.26));
      drawJackOLantern(1150, groundY - 14 - Math.min(180, coopHeight * 0.48));
      drawJackOLantern(1660, groundY - 14 - Math.min(120, coopHeight * 0.32));
      drawJackOLantern(500, groundY - 14);
    }
  }

  function drawChristmasTree(treeX, treeBaseY) {
    ctx.save();
    // Tree Trunk
    ctx.fillStyle = '#5c2d13';
    ctx.fillRect(treeX - 7, treeBaseY - 14, 14, 14);

    // 3 Tiered Pine Branches
    const tiers = [
      { y: treeBaseY - 12, w: 62, h: 26 },
      { y: treeBaseY - 32, w: 48, h: 24 },
      { y: treeBaseY - 50, w: 34, h: 22 }
    ];
    tiers.forEach((tier, idx) => {
      ctx.fillStyle = idx % 2 === 0 ? '#15803d' : '#166534';
      ctx.beginPath();
      ctx.moveTo(treeX - tier.w / 2, tier.y);
      ctx.lineTo(treeX, tier.y - tier.h);
      ctx.lineTo(treeX + tier.w / 2, tier.y);
      ctx.closePath();
      ctx.fill();

      // Snow on pine tier
      ctx.fillStyle = 'rgba(255, 255, 255, 0.75)';
      ctx.fillRect(treeX - tier.w / 2 + 4, tier.y - 2, tier.w - 8, 3);
    });

    // Twinkling Christmas Lights
    const lightColors = ['#ef4444', '#facc15', '#38bdf8', '#e11d48', '#22c55e'];
    const lightPositions = [
      { x: -18, y: -20 }, { x: 0, y: -24 }, { x: 18, y: -21 },
      { x: -12, y: -38 }, { x: 9, y: -40 }, { x: -4, y: -54 }
    ];
    const animOffset = Math.floor(Date.now() / 400);
    lightPositions.forEach((pos, idx) => {
      const color = lightColors[(idx + animOffset) % lightColors.length];
      ctx.fillStyle = color;
      ctx.beginPath();
      ctx.arc(treeX + pos.x, treeBaseY + pos.y, 3, 0, Math.PI * 2);
      ctx.fill();
    });

    // Golden Christmas Star on Top
    ctx.fillStyle = '#facc15';
    drawGoldenStar(treeX, treeBaseY - 74, 8);
    ctx.restore();
  }

  function drawGoldenStar(cx, cy, r) {
    ctx.save();
    ctx.beginPath();
    for (let i = 0; i < 5; i++) {
      ctx.lineTo(
        cx + r * Math.cos((18 + i * 72) * Math.PI / 180),
        cy - r * Math.sin((18 + i * 72) * Math.PI / 180)
      );
      ctx.lineTo(
        cx + (r / 2) * Math.cos((54 + i * 72) * Math.PI / 180),
        cy - (r / 2) * Math.sin((54 + i * 72) * Math.PI / 180)
      );
    }
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  }

  function drawJackOLantern(px, py) {
    ctx.save();
    // Pumpkin Body
    ctx.fillStyle = '#ea580c';
    ctx.beginPath();
    ctx.ellipse(px, py, 14, 12, 0, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = '#c2410c';
    ctx.beginPath();
    ctx.ellipse(px, py, 7, 11, 0, 0, Math.PI * 2);
    ctx.fill();

    // Green Stem
    ctx.fillStyle = '#15803d';
    ctx.fillRect(px - 1.5, py - 16, 3, 5);

    // Glowing Carved Face with candle flicker
    const flicker = 0.75 + Math.sin(Date.now() * 0.015 + px) * 0.25;
    ctx.fillStyle = `rgba(254, 240, 138, ${flicker})`;

    // Triangular eyes
    ctx.beginPath();
    ctx.moveTo(px - 7, py - 3); ctx.lineTo(px - 4, py - 7); ctx.lineTo(px - 1, py - 3);
    ctx.moveTo(px + 1, py - 3); ctx.lineTo(px + 4, py - 7); ctx.lineTo(px + 7, py - 3);
    // Jagged smile
    ctx.moveTo(px - 8, py + 3);
    ctx.lineTo(px - 5, py + 6);
    ctx.lineTo(px, py + 3);
    ctx.lineTo(px + 5, py + 6);
    ctx.lineTo(px + 8, py + 3);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  }

  function drawTroughs(theme) {
    // 1. Food Trough
    const ft = foodTrough;
    ctx.fillStyle = '#3f2113';
    ctx.fillRect(ft.x, ft.y, ft.w, ft.h);
    ctx.fillStyle = '#59301b';
    ctx.fillRect(ft.x + 4, ft.y + 4, ft.w - 8, ft.h - 8);

    if (gameState.troughFood > 0) {
      const foodHeight = (ft.h - 10) * (gameState.troughFood / 100);

      if (theme === 'halloween') {
        // Candy corn layer
        ctx.fillStyle = '#ea580c';
        ctx.fillRect(ft.x + 6, ft.y + ft.h - 6 - foodHeight, ft.w - 12, foodHeight);
        // Candy corn triangles
        for (let gx = ft.x + 10; gx < ft.x + ft.w - 10; gx += 12) {
          ctx.fillStyle = '#fef08a';
          ctx.beginPath();
          ctx.moveTo(gx, ft.y + ft.h - 6 - foodHeight + 4);
          ctx.lineTo(gx + 4, ft.y + ft.h - 6 - foodHeight - 2);
          ctx.lineTo(gx + 8, ft.y + ft.h - 6 - foodHeight + 4);
          ctx.closePath();
          ctx.fill();
        }
      } else if (theme === 'christmas') {
        // Red & green holiday grain mix
        ctx.fillStyle = '#dc2626';
        ctx.fillRect(ft.x + 6, ft.y + ft.h - 6 - foodHeight, ft.w - 12, foodHeight);
        ctx.fillStyle = '#22c55e';
        for (let gx = ft.x + 10; gx < ft.x + ft.w - 10; gx += 10) {
          ctx.fillRect(gx, ft.y + ft.h - 6 - foodHeight + 2, 4, 4);
        }
      } else {
        // Standard golden cracked corn
        ctx.fillStyle = '#fbbf24';
        ctx.fillRect(ft.x + 6, ft.y + ft.h - 6 - foodHeight, ft.w - 12, foodHeight);
        ctx.fillStyle = '#d97706';
        for (let gx = ft.x + 10; gx < ft.x + ft.w - 10; gx += 10) {
          ctx.beginPath();
          ctx.arc(gx + (gx % 4), ft.y + ft.h - 6 - foodHeight + 4, 2.5, 0, Math.PI * 2);
          ctx.fill();
        }
      }
    }

    ctx.fillStyle = '#fed7aa';
    ctx.font = 'bold 11px sans-serif';
    ctx.textAlign = 'center';
    const grainLabel = theme === 'halloween' ? '🎃 CANDY' : (theme === 'christmas' ? '🎄 FEAST' : '🌾 GRAIN');
    ctx.fillText(grainLabel, ft.x + ft.w / 2, ft.y + ft.h + 14);

    // 2. Water Trough
    const wt = waterTrough;
    ctx.fillStyle = '#223843';
    ctx.fillRect(wt.x, wt.y, wt.w, wt.h);
    ctx.fillStyle = '#314e5b';
    ctx.fillRect(wt.x + 4, wt.y + 4, wt.w - 8, wt.h - 8);

    if (gameState.troughWater > 0) {
      const waterHeight = (wt.h - 10) * (gameState.troughWater / 100);

      if (theme === 'halloween') {
        // Eerie bubbling purple/green potion
        ctx.fillStyle = '#8b5cf6';
        ctx.fillRect(wt.x + 6, wt.y + wt.h - 6 - waterHeight, wt.w - 12, waterHeight);
        // Slime glow ripple
        ctx.fillStyle = '#a7f3d0';
        ctx.fillRect(wt.x + 12, wt.y + wt.h - 6 - waterHeight + 2, wt.w - 24, 2);
      } else if (theme === 'newyear') {
        // Fizzy golden champagne water
        ctx.fillStyle = '#fde047';
        ctx.fillRect(wt.x + 6, wt.y + wt.h - 6 - waterHeight, wt.w - 12, waterHeight);
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(wt.x + 12, wt.y + wt.h - 6 - waterHeight + 2, wt.w - 24, 2);
      } else {
        ctx.fillStyle = '#38bdf8';
        ctx.fillRect(wt.x + 6, wt.y + wt.h - 6 - waterHeight, wt.w - 12, waterHeight);
        ctx.fillStyle = 'rgba(255, 255, 255, 0.45)';
        ctx.fillRect(wt.x + 12, wt.y + wt.h - 6 - waterHeight + 2, wt.w - 24, 2);
      }
    }

    ctx.fillStyle = '#bae6fd';
    ctx.font = 'bold 11px sans-serif';
    ctx.textAlign = 'center';
    const waterLabel = theme === 'halloween' ? '🧪 POTION' : (theme === 'newyear' ? '🥂 SPARKLE' : '💧 WATER');
    ctx.fillText(waterLabel, wt.x + wt.w / 2, wt.y + wt.h + 14);
  }

  function drawChicks(theme) {
    gameState.chicks.forEach(chick => {
      ctx.save();
      ctx.translate(chick.x, chick.y);
      ctx.rotate(chick.rotation);
      ctx.scale(chick.facing, 1);

      if (chick.dead) {
        drawDeadChick(chick);
      } else {
        drawAliveChick(chick, theme);
      }

      ctx.restore();
    });
  }

  function drawAliveChick(chick, theme) {
    const isSleeping = chick.state === 'sleeping';
    const isAngry = chick.isAngry;
    const isStartled = chick.state === 'startled';
    const isEating = chick.state === 'eating';

    let bodyGradient = ctx.createRadialGradient(-2, -4, 2, 0, 0, chick.radius + 3);
    if (isAngry) {
      bodyGradient.addColorStop(0, '#fca5a5');
      bodyGradient.addColorStop(0.7, '#ef4444');
      bodyGradient.addColorStop(1, '#b91c1c');
    } else {
      bodyGradient.addColorStop(0, '#fef08a');
      bodyGradient.addColorStop(0.7, '#facc15');
      bodyGradient.addColorStop(1, '#eab308');
    }

    // Shadow
    if (chick.isGrounded) {
      ctx.fillStyle = 'rgba(0, 0, 0, 0.25)';
      ctx.beginPath();
      ctx.ellipse(0, chick.radius + 2, chick.radius * 0.9, 4, 0, 0, Math.PI * 2);
      ctx.fill();
    }

    // Legs / Feet
    const legOffset = Math.sin(chick.walkPhase) * 4;
    ctx.strokeStyle = '#f97316';
    ctx.lineWidth = 2.5;
    ctx.lineCap = 'round';

    if (!isSleeping) {
      ctx.beginPath();
      ctx.moveTo(-5, chick.radius - 4);
      ctx.lineTo(-5 - legOffset, chick.radius + 4);
      ctx.lineTo(-2 - legOffset, chick.radius + 4);
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(5, chick.radius - 4);
      ctx.lineTo(5 + legOffset, chick.radius + 4);
      ctx.lineTo(8 + legOffset, chick.radius + 4);
      ctx.stroke();
    }

    // Body
    ctx.fillStyle = bodyGradient;
    ctx.beginPath();
    const squishY = isSleeping ? 2 : (chick.isGrounded ? 0 : -2);
    ctx.ellipse(0, squishY, chick.radius, chick.radius - squishY, 0, 0, Math.PI * 2);
    ctx.fill();

    // Boy Sprout Feather or Girl Fluff (if no seasonal hat covers it)
    if (theme === 'classic' || !chick.outfitIndex) {
      if (chick.gender === 'male') {
        ctx.fillStyle = isAngry ? '#dc2626' : '#ea580c';
        ctx.beginPath();
        ctx.ellipse(-2, -chick.radius - 2, 3, 5, -0.2, 0, Math.PI * 2);
        ctx.fill();
      } else {
        ctx.fillStyle = isAngry ? '#f87171' : '#fef08a';
        ctx.beginPath();
        ctx.arc(-1, -chick.radius - 1, 3.5, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    // Wing
    const wingFlap = Math.sin(chick.wingFlutter || 0) * 8;
    ctx.fillStyle = isAngry ? '#dc2626' : '#eab308';
    ctx.beginPath();
    ctx.ellipse(-chick.radius * 0.35, 1 - wingFlap * 0.3, chick.radius * 0.55, chick.radius * 0.4, 0.2 + wingFlap * 0.05, 0, Math.PI * 2);
    ctx.fill();

    // Beak
    ctx.fillStyle = '#f97316';
    const peckOffsetY = isEating ? Math.sin(chick.peckPhase) * 6 : 0;
    ctx.beginPath();
    ctx.moveTo(chick.radius - 2, -2 + peckOffsetY);
    ctx.lineTo(chick.radius + 7, 2 + peckOffsetY);
    ctx.lineTo(chick.radius - 2, 5 + peckOffsetY);
    ctx.closePath();
    ctx.fill();

    // Cheek Blush
    ctx.fillStyle = isAngry ? 'rgba(185, 28, 28, 0.4)' : 'rgba(251, 113, 133, 0.45)';
    ctx.beginPath();
    ctx.arc(chick.radius * 0.4, 3, 3.5, 0, Math.PI * 2);
    ctx.fill();

    // Eyes
    if (isSleeping) {
      ctx.strokeStyle = '#713f12';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(chick.radius * 0.45, -3, 3.5, 0.1 * Math.PI, 0.9 * Math.PI);
      ctx.stroke();
    } else if (isAngry) {
      ctx.fillStyle = '#000';
      ctx.beginPath();
      ctx.arc(chick.radius * 0.45, -3, 3, 0, Math.PI * 2);
      ctx.fill();

      ctx.strokeStyle = '#7f1d1d';
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.moveTo(chick.radius * 0.15, -9);
      ctx.lineTo(chick.radius * 0.65, -5);
      ctx.stroke();
    } else if (isStartled) {
      ctx.fillStyle = '#fff';
      ctx.beginPath();
      ctx.arc(chick.radius * 0.45, -3, 4.5, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = '#000';
      ctx.beginPath();
      ctx.arc(chick.radius * 0.5, -3, 2.5, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = '#38bdf8';
      ctx.beginPath();
      ctx.arc(chick.radius * 0.2, -12, 2.5, 0, Math.PI * 2);
      ctx.fill();
    } else {
      ctx.fillStyle = '#1e1b4b';
      ctx.beginPath();
      ctx.arc(chick.radius * 0.45, -3, 3.2, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = '#fff';
      ctx.beginPath();
      ctx.arc(chick.radius * 0.55, -4.2, 1.2, 0, Math.PI * 2);
      ctx.fill();
    }

    // DRAW SEASONAL OUTFIT!
    if (theme !== 'classic') {
      drawSeasonalOutfit(chick, theme);
    }

    // Selected Outline
    if (selectedChick && selectedChick.id === chick.id) {
      ctx.strokeStyle = '#f59e0b';
      ctx.lineWidth = 2.5;
      ctx.setLineDash([4, 4]);
      ctx.beginPath();
      ctx.arc(0, 0, chick.radius + 8, 0, Math.PI * 2);
      ctx.stroke();
      ctx.setLineDash([]);
    }
  }

  function drawSeasonalOutfit(chick, theme) {
    const outfit = chick.outfitIndex % 4;

    if (theme === 'halloween') {
      if (outfit === 0) {
        // Witch Hat
        ctx.save();
        ctx.fillStyle = '#1e1b4b';
        ctx.beginPath();
        ctx.ellipse(0, -chick.radius - 2, 13, 3.5, 0, 0, Math.PI * 2);
        ctx.fill();

        ctx.beginPath();
        ctx.moveTo(-9, -chick.radius - 2);
        ctx.lineTo(2, -chick.radius - 20);
        ctx.lineTo(7, -chick.radius - 2);
        ctx.closePath();
        ctx.fill();

        ctx.fillStyle = '#9333ea';
        ctx.fillRect(-7, -chick.radius - 6, 13, 3.5);
        ctx.fillStyle = '#facc15';
        ctx.fillRect(-2, -chick.radius - 6, 4, 3.5);
        ctx.restore();
      } else if (outfit === 1) {
        // Little Bat Wings
        ctx.save();
        ctx.fillStyle = '#18181b';
        ctx.beginPath();
        ctx.moveTo(-chick.radius * 0.4, -4);
        ctx.lineTo(-chick.radius - 12, -14);
        ctx.lineTo(-chick.radius - 6, -4);
        ctx.lineTo(-chick.radius - 14, 4);
        ctx.lineTo(-chick.radius * 0.4, 2);
        ctx.closePath();
        ctx.fill();
        ctx.restore();
      } else if (outfit === 2) {
        // Vampire Collar
        ctx.save();
        ctx.fillStyle = '#7f1d1d';
        ctx.beginPath();
        ctx.moveTo(-chick.radius * 0.3, -2);
        ctx.lineTo(-chick.radius - 6, -12);
        ctx.lineTo(-chick.radius - 2, 4);
        ctx.closePath();
        ctx.fill();
        ctx.restore();
      } else {
        // Pumpkin Cap
        ctx.save();
        ctx.fillStyle = '#ea580c';
        ctx.beginPath();
        ctx.ellipse(0, -chick.radius - 4, 5.5, 4.5, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#16a34a';
        ctx.fillRect(-1, -chick.radius - 9, 2.5, 4);
        ctx.restore();
      }
    } else if (theme === 'christmas') {
      if (outfit === 0) {
        // Santa Hat
        ctx.save();
        ctx.fillStyle = '#dc2626';
        ctx.beginPath();
        ctx.moveTo(-8, -chick.radius - 1);
        ctx.quadraticCurveTo(-2, -chick.radius - 18, -14, -chick.radius - 16);
        ctx.quadraticCurveTo(0, -chick.radius - 10, 8, -chick.radius - 1);
        ctx.closePath();
        ctx.fill();

        ctx.fillStyle = '#f8fafc';
        ctx.beginPath();
        ctx.roundRect(-10, -chick.radius - 3, 20, 5, 3);
        ctx.fill();

        ctx.beginPath();
        ctx.arc(-14, -chick.radius - 16, 4, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      } else if (outfit === 1) {
        // Reindeer Antlers
        ctx.save();
        ctx.strokeStyle = '#78350f';
        ctx.lineWidth = 2.5;
        ctx.lineCap = 'round';

        ctx.beginPath();
        ctx.moveTo(-4, -chick.radius);
        ctx.lineTo(-8, -chick.radius - 14);
        ctx.lineTo(-13, -chick.radius - 10);
        ctx.moveTo(-8, -chick.radius - 8);
        ctx.lineTo(-4, -chick.radius - 12);
        ctx.stroke();

        ctx.beginPath();
        ctx.moveTo(3, -chick.radius);
        ctx.lineTo(6, -chick.radius - 14);
        ctx.lineTo(11, -chick.radius - 10);
        ctx.moveTo(6, -chick.radius - 8);
        ctx.lineTo(2, -chick.radius - 12);
        ctx.stroke();

        ctx.fillStyle = '#ef4444';
        ctx.beginPath();
        ctx.arc(chick.radius + 5, 2, 2.5, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      } else if (outfit === 2) {
        // Cozy Winter Scarf
        ctx.save();
        ctx.fillStyle = '#dc2626';
        ctx.beginPath();
        ctx.roundRect(-8, chick.radius * 0.35, 18, 5, 2.5);
        ctx.fill();

        ctx.fillStyle = '#16a34a';
        ctx.fillRect(-3, chick.radius * 0.35, 3, 5);
        ctx.fillRect(4, chick.radius * 0.35, 3, 5);

        ctx.fillStyle = '#dc2626';
        ctx.fillRect(-7, chick.radius * 0.5, 4, 8);
        ctx.fillStyle = '#16a34a';
        ctx.fillRect(-7, chick.radius * 0.5 + 4, 4, 2);
        ctx.restore();
      } else {
        // Elf Hat
        ctx.save();
        ctx.fillStyle = '#16a34a';
        ctx.beginPath();
        ctx.moveTo(-8, -chick.radius - 1);
        ctx.lineTo(1, -chick.radius - 18);
        ctx.lineTo(8, -chick.radius - 1);
        ctx.closePath();
        ctx.fill();

        ctx.fillStyle = '#dc2626';
        ctx.beginPath();
        ctx.roundRect(-9, -chick.radius - 3, 18, 4, 2);
        ctx.fill();

        ctx.fillStyle = '#facc15';
        ctx.beginPath();
        ctx.arc(1, -chick.radius - 18, 3, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }
    } else if (theme === 'newyear') {
      if (outfit === 0) {
        // Gold Party Cone Hat
        ctx.save();
        ctx.fillStyle = '#f59e0b';
        ctx.beginPath();
        ctx.moveTo(-7, -chick.radius - 1);
        ctx.lineTo(0, -chick.radius - 18);
        ctx.lineTo(7, -chick.radius - 1);
        ctx.closePath();
        ctx.fill();

        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(-5, -chick.radius - 5);
        ctx.lineTo(3, -chick.radius - 9);
        ctx.moveTo(-3, -chick.radius - 11);
        ctx.lineTo(1, -chick.radius - 15);
        ctx.stroke();

        ctx.fillStyle = '#38bdf8';
        ctx.beginPath();
        ctx.arc(0, -chick.radius - 18, 3, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      } else if (outfit === 1) {
        // Dapper Bowtie
        ctx.save();
        ctx.fillStyle = '#0f172a';
        ctx.beginPath();
        ctx.moveTo(chick.radius * 0.4, 4);
        ctx.lineTo(chick.radius * 0.8, 1);
        ctx.lineTo(chick.radius * 0.8, 7);
        ctx.closePath();
        ctx.fill();
        ctx.beginPath();
        ctx.moveTo(chick.radius * 0.4, 4);
        ctx.lineTo(chick.radius * 0.1, 1);
        ctx.lineTo(chick.radius * 0.1, 7);
        ctx.closePath();
        ctx.fill();

        ctx.fillStyle = '#f59e0b';
        ctx.beginPath();
        ctx.arc(chick.radius * 0.4, 4, 1.8, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      } else if (outfit === 2) {
        // 2027 Star Headband
        ctx.save();
        ctx.strokeStyle = '#38bdf8';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(-3, -chick.radius);
        ctx.lineTo(-4, -chick.radius - 10);
        ctx.moveTo(3, -chick.radius);
        ctx.lineTo(4, -chick.radius - 10);
        ctx.stroke();

        ctx.fillStyle = '#facc15';
        ctx.beginPath();
        ctx.arc(-4, -chick.radius - 11, 3.5, 0, Math.PI * 2);
        ctx.arc(4, -chick.radius - 11, 3.5, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      } else {
        // Party Horn Noisemaker
        ctx.save();
        ctx.fillStyle = '#ec4899';
        ctx.beginPath();
        ctx.moveTo(chick.radius + 3, 3);
        ctx.lineTo(chick.radius + 15, 0);
        ctx.lineTo(chick.radius + 15, 6);
        ctx.closePath();
        ctx.fill();

        ctx.fillStyle = '#facc15';
        ctx.fillRect(chick.radius + 8, 1, 3, 4);
        ctx.restore();
      }
    }
  }

  function drawDeadChick(chick) {
    ctx.fillStyle = '#9ca3af';
    ctx.beginPath();
    ctx.ellipse(0, 0, chick.radius, chick.radius * 0.6, 0, 0, Math.PI * 2);
    ctx.fill();

    ctx.strokeStyle = '#374151';
    ctx.lineWidth = 2;
    const ex = 4;
    const ey = -2;
    ctx.beginPath();
    ctx.moveTo(ex - 3, ey - 3);
    ctx.lineTo(ex + 3, ey + 3);
    ctx.moveTo(ex + 3, ey - 3);
    ctx.lineTo(ex - 3, ey + 3);
    ctx.stroke();

    ctx.fillStyle = '#6b7280';
    ctx.beginPath();
    ctx.moveTo(chick.radius - 2, -2);
    ctx.lineTo(chick.radius + 5, 1);
    ctx.lineTo(chick.radius - 2, 4);
    ctx.closePath();
    ctx.fill();
  }

  function drawParticles() {
    particles.forEach(p => {
      ctx.save();
      ctx.globalAlpha = p.opacity;

      if (p.type === 'snow') {
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
        ctx.fill();
      } else if (p.type === 'confetti') {
        ctx.translate(p.x, p.y);
        ctx.rotate(p.rot);
        ctx.fillStyle = p.color;
        ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size * 0.6);
      } else {
        ctx.translate(p.x, p.y);
        ctx.scale(p.scale, p.scale);
        ctx.font = 'bold 15px sans-serif';
        ctx.textAlign = 'center';

        if (p.type === 'zZZ') {
          ctx.fillStyle = '#93c5fd';
          ctx.fillText('zZZ', 0, 0);
        } else if (p.type === '❤️') {
          ctx.fillStyle = '#f43f5e';
          ctx.fillText('❤️', 0, 0);
        } else if (p.type === '💢') {
          ctx.fillStyle = '#ef4444';
          ctx.fillText('💢', 0, 0);
        } else if (p.type === '🌾') {
          ctx.fillStyle = '#fbbf24';
          ctx.fillText('•', 0, 0);
        }
      }
      ctx.restore();
    });
  }

  function drawCoopForeground() {
    const vigL = ctx.createLinearGradient(0, 0, 180, 0);
    vigL.addColorStop(0, 'rgba(20, 10, 5, 0.45)');
    vigL.addColorStop(1, 'rgba(0, 0, 0, 0)');
    ctx.fillStyle = vigL;
    ctx.fillRect(0, 0, 180, coopHeight);

    const vigR = ctx.createLinearGradient(COOP_WIDTH - 180, 0, COOP_WIDTH, 0);
    vigR.addColorStop(0, 'rgba(0, 0, 0, 0)');
    vigR.addColorStop(1, 'rgba(20, 10, 5, 0.45)');
    ctx.fillStyle = vigR;
    ctx.fillRect(COOP_WIDTH - 180, 0, 180, coopHeight);
  }

  // --- TOUCH & MOUSE PAN / SWIPE / INTERACTION ---
  function setupInputHandlers() {
    const container = document.getElementById('canvas-container');

    container.addEventListener('mousedown', (e) => {
      window.soundEngine.ensureReady();
      isDragging = true;
      dragStartX = e.clientX;
      dragStartCameraX = cameraX;
      lastDragTime = performance.now();
      dragVelocityX = 0;
    });

    window.addEventListener('mousemove', (e) => {
      if (!isDragging) return;
      const dx = e.clientX - dragStartX;
      const now = performance.now();
      const dt = now - lastDragTime;
      if (dt > 0) {
        dragVelocityX = -(dx - (dragStartCameraX - cameraX)) / dt;
      }
      lastDragTime = now;
      cameraX = clampCamera(dragStartCameraX - dx);
    });

    window.addEventListener('mouseup', (e) => {
      if (!isDragging) return;
      isDragging = false;
      const moveDist = Math.abs(e.clientX - dragStartX);
      if (moveDist < 6) {
        handleTap(e.clientX, e.clientY);
      }
    });

    container.addEventListener('touchstart', (e) => {
      window.soundEngine.ensureReady();
      if (e.touches.length === 1) {
        isDragging = true;
        dragStartX = e.touches[0].clientX;
        lastTouchX = dragStartX;
        dragStartCameraX = cameraX;
        lastDragTime = performance.now();
        dragVelocityX = 0;
      }
    }, { passive: true });

    container.addEventListener('touchmove', (e) => {
      if (!isDragging || e.touches.length !== 1) return;
      const currentX = e.touches[0].clientX;
      const dx = currentX - dragStartX;
      const now = performance.now();
      const dt = now - lastDragTime;
      if (dt > 0) {
        dragVelocityX = -(currentX - lastTouchX) / dt * 15;
      }
      lastTouchX = currentX;
      lastDragTime = now;
      cameraX = clampCamera(dragStartCameraX - dx);
    }, { passive: true });

    container.addEventListener('touchend', (e) => {
      if (!isDragging) return;
      isDragging = false;
      const moveDist = Math.abs(lastTouchX - dragStartX);
      if (moveDist < 8) {
        handleTap(lastTouchX, e.changedTouches[0]?.clientY || 0);
      }
    });

    container.addEventListener('wheel', (e) => {
      window.soundEngine.ensureReady();
      const delta = e.deltaX !== 0 ? e.deltaX : e.deltaY;
      cameraX = clampCamera(cameraX + delta * 1.2);
    }, { passive: true });
  }

  function clampCamera(x) {
    const maxCam = Math.max(0, COOP_WIDTH - viewportWidth);
    return Math.max(0, Math.min(maxCam, x));
  }

  function handleTap(screenX, screenY) {
    const worldX = screenX + cameraX;
    const worldY = screenY;

    for (let i = gameState.chicks.length - 1; i >= 0; i--) {
      const chick = gameState.chicks[i];
      const dist = Math.hypot(chick.x - worldX, chick.y - worldY);
      if (dist <= chick.radius + 14) {
        if (chick.dead) return;

        if (chick.isAngry) {
          calmChick(chick);
          return;
        }

        openInspector(chick);
        return;
      }
    }
  }

  function calmChick(chick) {
    chick.isAngry = false;
    chick.state = 'idle';
    chick.angryTimer = 0;
    chick.petCount++;
    spawnParticles('❤️', chick.x, chick.y - 18, 4);
    window.soundEngine.playChirp('coo', (chick.x - cameraX - viewportWidth/2) / (viewportWidth/2));
    if (selectedChick && selectedChick.id === chick.id) {
      updateInspectorUI(chick);
    }
  }

  // --- ACTIONS ---
  window.triggerSlamCage = function() {
    window.soundEngine.ensureReady();
    window.soundEngine.playSlam();
    screenShake = 1.0;

    gameState.chicks.forEach(chick => {
      if (chick.dead) return;

      if (chick.state === 'sleeping' || Math.random() < 0.75) {
        chick.state = 'startled';
        chick.isAngry = false;
        chick.isGrounded = false;
        chick.vy = -11 - Math.random() * 4;
        chick.vx = (Math.random() - 0.5) * 4;
        spawnParticles('💦', chick.x, chick.y - 20, 2);
      }
    });
  };

  window.triggerFeedBell = function() {
    window.soundEngine.ensureReady();
    window.soundEngine.playBell();

    gameState.troughFood = 100;
    gameState.troughWater = 100;
    if (foodTrough) foodTrough.foodLevel = 100;
    if (waterTrough) waterTrough.waterLevel = 100;

    spawnParticles('🌾', foodTrough.x + 80, foodTrough.y + 10, 8);

    gameState.chicks.forEach(chick => {
      if (chick.dead) return;
      chick.state = 'eating';
      chick.stateTimer = 4 + Math.random() * 3;
      chick.facing = chick.x < foodTrough.x + 80 ? 1 : -1;
      chick.isFedMorning = true;
      chick.isFedEvening = true;
      chick.hunger = 100;
    });

    // Achievement: Raising Them
    unlockAchievement('raising_them');

    saveToStorage();
    updateHUD();
  };

  // --- INSPECTOR POPUP ---
  function openInspector(chick) {
    selectedChick = chick;
    updateInspectorUI(chick);
    const modal = document.getElementById('inspector-modal');
    modal.classList.remove('hidden-modal');
  }

  function updateInspectorUI(chick) {
    if (!chick) return;
    document.getElementById('inspector-name').textContent = chick.name;
    const genderEl = document.getElementById('inspector-gender');
    genderEl.textContent = chick.gender === 'male' ? '♂ Boy' : '♀ Girl';
    genderEl.className = chick.gender === 'male' 
      ? 'px-2.5 py-0.5 rounded-full text-xs font-bold bg-blue-500/20 text-blue-300 border border-blue-400/30' 
      : 'px-2.5 py-0.5 rounded-full text-xs font-bold bg-pink-500/20 text-pink-300 border border-pink-400/30';

    document.getElementById('inspector-born').textContent = chick.birthFormatted;

    let mood = 'Happy & Chirpy 😊';
    if (chick.isAngry) mood = 'Angry Bully! 😡 (Tap to calm)';
    else if (chick.state === 'sleeping') mood = 'Sleeping peacefully 💤';
    else if (chick.state === 'eating') mood = 'Eating seeds 🌾';
    else if (chick.state === 'startled') mood = 'Startled! ❗';
    document.getElementById('inspector-status').textContent = mood;

    document.getElementById('inspector-pets').textContent = `${chick.petCount} times`;
    const hungerPercent = Math.min(100, Math.max(0, Math.round(chick.hunger)));
    document.getElementById('inspector-hunger-bar').style.width = `${hungerPercent}%`;
  }

  window.petSelectedChick = function() {
    if (!selectedChick || selectedChick.dead) return;
    calmChick(selectedChick);
    updateInspectorUI(selectedChick);
  };

  window.closeInspector = function() {
    selectedChick = null;
    document.getElementById('inspector-modal').classList.add('hidden-modal');
  };

  // --- SETTINGS MODAL ---
  window.openSettings = function() {
    window.soundEngine.ensureReady();
    document.getElementById('settings-theme').value = gameState.settings.themeMode || 'auto';
    document.getElementById('settings-timezone').value = gameState.settings.timezone;
    document.getElementById('settings-master-vol').value = gameState.settings.masterVolume;
    document.getElementById('settings-chirp-vol').value = gameState.settings.chirpVolume;
    document.getElementById('settings-slam-vol').value = gameState.settings.slamVolume;
    document.getElementById('settings-bell-vol').value = gameState.settings.bellVolume;
    document.getElementById('settings-ambience').checked = gameState.settings.ambienceEnabled;
    document.getElementById('settings-flock-size').value = gameState.settings.maxChicks;
    document.getElementById('settings-flock-val').textContent = gameState.settings.maxChicks;

    document.getElementById('settings-modal').classList.remove('hidden-modal');
  };

  window.closeSettings = function() {
    document.getElementById('settings-modal').classList.add('hidden-modal');
    saveToStorage();
  };

  window.updateSetting = function(key, val) {
    if (key === 'timezone') {
      gameState.settings.timezone = val;
    } else if (key === 'themeMode') {
      gameState.settings.themeMode = val;
      checkSeasonalAchievements();
    } else if (key === 'ambienceEnabled') {
      gameState.settings.ambienceEnabled = val;
      window.soundEngine.toggleAmbience(val);
    } else if (key === 'maxChicks') {
      const targetCount = parseInt(val, 10);
      gameState.settings.maxChicks = targetCount;
      document.getElementById('settings-flock-val').textContent = targetCount;
      adjustFlockSize(targetCount);
    } else {
      const num = parseFloat(val);
      gameState.settings[key] = num;
      window.soundEngine.setVolume(key, num);
    }
    saveToStorage();
    updateHUD();
  };

  function adjustFlockSize(targetCount) {
    while (gameState.chicks.length < targetCount) {
      gameState.chicks.push(createChick());
    }
    while (gameState.chicks.length > targetCount) {
      gameState.chicks.pop();
    }
    saveToStorage();
  }

  window.restartHatchery = function() {
    if (!confirm('Are you sure you want to hatch a brand-new flock of baby chicks?')) return;
    resetHatchery();
    closeSettings();
    document.getElementById('game-over-modal').classList.add('hidden-modal');
  };

  function resetHatchery() {
    gameState.chicks = [];
    gameState.hatchDate = Date.now();
    gameState.troughFood = 100;
    gameState.troughWater = 100;
    const count = gameState.settings.maxChicks;
    for (let i = 0; i < count; i++) {
      gameState.chicks.push(createChick());
    }
    saveToStorage();
    window.soundEngine.playBell();
  }

  // --- PERSISTENCE ---
  function saveToStorage() {
    try {
      localStorage.setItem('chirpcoop_data', JSON.stringify({
        settings: gameState.settings,
        achievements: gameState.achievements,
        troughFood: gameState.troughFood,
        troughWater: gameState.troughWater,
        hatchDate: gameState.hatchDate,
        chicks: gameState.chicks.map(c => ({
          name: c.name,
          gender: c.gender,
          outfitIndex: c.outfitIndex,
          birthTimestamp: c.birthTimestamp,
          birthFormatted: c.birthFormatted,
          x: Math.round(c.x),
          y: Math.round(c.y),
          dead: c.dead,
          isFedMorning: c.isFedMorning,
          isFedEvening: c.isFedEvening,
          petCount: c.petCount
        }))
      }));
    } catch (e) {}
  }

  function loadFromStorage() {
    try {
      const raw = localStorage.getItem('chirpcoop_data');
      if (raw) {
        const data = JSON.parse(raw);
        if (data.settings) gameState.settings = Object.assign(gameState.settings, data.settings);
        if (data.achievements) gameState.achievements = Object.assign(gameState.achievements, data.achievements);
        if (typeof data.troughFood === 'number') gameState.troughFood = data.troughFood;
        if (typeof data.troughWater === 'number') gameState.troughWater = data.troughWater;
        if (data.hatchDate) gameState.hatchDate = data.hatchDate;

        if (Array.isArray(data.chicks) && data.chicks.length > 0) {
          const groundY = getGroundY();
          gameState.chicks = data.chicks.map(saved => {
            const validY = (typeof saved.y === 'number' && saved.y <= groundY - 17 && saved.y >= 30) ? saved.y : (groundY - 17);
            const chick = createChick(saved.x, validY);
            chick.name = saved.name || chick.name;
            chick.gender = saved.gender || chick.gender;
            chick.outfitIndex = saved.outfitIndex !== undefined ? saved.outfitIndex : Math.floor(Math.random() * 4);
            chick.birthTimestamp = saved.birthTimestamp || chick.birthTimestamp;
            chick.birthFormatted = saved.birthFormatted || chick.birthFormatted;
            chick.dead = !!saved.dead;
            chick.isFedMorning = !!saved.isFedMorning;
            chick.isFedEvening = !!saved.isFedEvening;
            chick.petCount = saved.petCount || 0;
            if (chick.dead) {
              chick.state = 'dead';
              chick.rotation = Math.PI / 2;
            }
            return chick;
          });
        }
      }
    } catch (e) {}

    if (gameState.chicks.length === 0) {
      const groundY = getGroundY();
      for (let i = 0; i < gameState.settings.maxChicks; i++) {
        gameState.chicks.push(createChick(null, groundY - 17));
      }
    }
  }

  // --- HUD UPDATE LOOP ---
  function updateHUD() {
    const timeInfo = getTimeInfo();
    const clockEl = document.getElementById('hud-clock');
    if (clockEl) clockEl.textContent = timeInfo.timeStr;

    const statusBadge = document.getElementById('hud-feed-status');
    if (statusBadge) {
      statusBadge.textContent = timeInfo.statusText;
      statusBadge.className = 'px-3 py-1 rounded-full text-xs font-semibold backdrop-blur-md shadow-sm ' +
        (timeInfo.statusLevel === 'ready'
          ? 'bg-amber-500/25 text-amber-200 border border-amber-400/40'
          : 'bg-emerald-500/25 text-emerald-200 border border-emerald-400/40');
    }

    const aliveCount = gameState.chicks.filter(c => !c.dead).length;
    const flockBadge = document.getElementById('hud-flock-count');
    if (flockBadge) {
      flockBadge.textContent = `${aliveCount}/${gameState.chicks.length} Alive 🐣`;
    }

    // Seasonal Badge
    const theme = getActiveTheme();
    const seasonBadge = document.getElementById('hud-season-badge');
    if (seasonBadge) {
      if (theme === 'halloween') {
        seasonBadge.textContent = '🎃 Halloween';
        seasonBadge.className = 'text-xs font-bold px-2 py-0.5 rounded-full bg-orange-500/25 text-orange-200 border border-orange-400/30';
        seasonBadge.classList.remove('hidden');
      } else if (theme === 'christmas') {
        seasonBadge.textContent = '🎄 Christmas';
        seasonBadge.className = 'text-xs font-bold px-2 py-0.5 rounded-full bg-red-500/25 text-red-200 border border-red-400/30';
        seasonBadge.classList.remove('hidden');
      } else if (theme === 'newyear') {
        seasonBadge.textContent = '🎆 New Year';
        seasonBadge.className = 'text-xs font-bold px-2 py-0.5 rounded-full bg-purple-500/25 text-purple-200 border border-purple-400/30';
        seasonBadge.classList.remove('hidden');
      } else {
        seasonBadge.classList.add('hidden');
      }
    }
  }

  // Android Back Button bridge
  window.handleAndroidBack = function() {
    const achModal = document.getElementById('achievements-modal');
    if (achModal && !achModal.classList.contains('hidden-modal')) {
      closeAchievements();
      return;
    }
    const inspectorModal = document.getElementById('inspector-modal');
    if (inspectorModal && !inspectorModal.classList.contains('hidden-modal')) {
      closeInspector();
      return;
    }
    const settingsModal = document.getElementById('settings-modal');
    if (settingsModal && !settingsModal.classList.contains('hidden-modal')) {
      closeSettings();
      return;
    }
  };

  // --- MAIN ENGINE LOOP ---
  function gameLoop(now) {
    const dt = Math.min((now - lastFrameTime) / 1000, 0.1);
    lastFrameTime = now;

    if (!isDragging && Math.abs(dragVelocityX) > 0.05) {
      cameraX = clampCamera(cameraX + dragVelocityX);
      dragVelocityX *= 0.92;
    }

    updateChicks(dt);
    updateParticles(dt);
    checkHungerAndDeath();

    render();

    requestAnimationFrame(gameLoop);
  }

  // --- FIRST-TIME ONBOARDING FLOW ---
  let onboardingCount = 12;

  window.adjustOnboardingCount = function(delta) {
    onboardingCount = Math.max(5, Math.min(20, onboardingCount + delta));
    updateOnboardingUI();
  };

  window.setOnboardingCount = function(val) {
    onboardingCount = Math.max(5, Math.min(20, parseInt(val, 10)));
    updateOnboardingUI();
  };

  function updateOnboardingUI() {
    const countDisplay = document.getElementById('onboarding-count-display');
    const slider = document.getElementById('onboarding-slider');
    if (countDisplay) countDisplay.textContent = onboardingCount;
    if (slider) slider.value = onboardingCount;
  }

  window.confirmOnboarding = function() {
    window.soundEngine.ensureReady();
    localStorage.setItem('chirpcoop_onboarded', 'true');

    gameState.settings.maxChicks = onboardingCount;
    const flockSizeInput = document.getElementById('settings-flock-size');
    const flockValEl = document.getElementById('settings-flock-val');
    if (flockSizeInput) flockSizeInput.value = onboardingCount;
    if (flockValEl) flockValEl.textContent = onboardingCount;

    // Spawn exact chosen count right in the visible area of the coop
    gameState.chicks = [];
    const groundY = getGroundY();
    const spawnCenterX = cameraX + viewportWidth / 2;
    for (let i = 0; i < onboardingCount; i++) {
      const sx = Math.max(120, Math.min(COOP_WIDTH - 120, spawnCenterX + (Math.random() - 0.5) * (viewportWidth * 0.75)));
      gameState.chicks.push(createChick(sx, groundY - 17));
    }

    const modal = document.getElementById('onboarding-modal');
    if (modal) modal.classList.add('hidden-modal');

    unlockAchievement('first_time');

    if (window.soundEngine) {
      window.soundEngine.playBell();
    }
    spawnParticles('❤️', spawnCenterX, groundY - 60, 10);

    saveToStorage();
    updateHUD();
  };

  // --- RESIZE & INIT ---
  function onResize() {
    viewportWidth = window.innerWidth;
    viewportHeight = window.innerHeight;
    canvas.width = viewportWidth;
    canvas.height = viewportHeight;
    initCoopGeometry();
    const groundY = getGroundY();

    // Ensure all chicks are within visible coop vertical bounds
    if (gameState && Array.isArray(gameState.chicks)) {
      gameState.chicks.forEach(chick => {
        if (chick.y > groundY - chick.radius || chick.y < 20 || isNaN(chick.y)) {
          chick.y = groundY - chick.radius;
          chick.vy = 0;
          chick.isGrounded = true;
        }
      });
    }

    cameraX = clampCamera(cameraX);
  }

  window.addEventListener('load', () => {
    canvas = document.getElementById('coop-canvas');
    ctx = canvas.getContext('2d');

    onResize();
    loadFromStorage();
    window.addEventListener('resize', onResize);

    setupInputHandlers();

    cameraX = (COOP_WIDTH - viewportWidth) / 2;

    // Check First-Time Onboarding
    const hasOnboarded = localStorage.getItem('chirpcoop_onboarded');
    if (!hasOnboarded) {
      const modal = document.getElementById('onboarding-modal');
      if (modal) modal.classList.remove('hidden-modal');
      updateOnboardingUI();
    } else {
      unlockAchievement('first_time');
    }

    // Check Holiday Achievements
    checkSeasonalAchievements();

    setInterval(updateHUD, 1000);
    setInterval(saveToStorage, 8000);

    updateHUD();
    requestAnimationFrame(gameLoop);
  });

})();
