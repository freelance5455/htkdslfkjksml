// ChirpCoop Procedural Web Audio Engine
// All SFX synthesized via Web Audio API without external audio file dependencies

class SoundEngine {
  constructor() {
    this.ctx = null;
    this.masterGain = null;
    this.ambienceGain = null;
    this.ambienceSource = null;
    this.isMuted = false;

    this.settings = {
      masterVolume: 0.8,
      chirpVolume: 0.8,
      slamVolume: 0.9,
      bellVolume: 0.85,
      ambienceVolume: 0.35,
      ambienceEnabled: true
    };
  }

  init() {
    if (this.ctx) return;
    try {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      this.ctx = new AudioCtx();
      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.setValueAtTime(this.settings.masterVolume, this.ctx.currentTime);
      this.masterGain.connect(this.ctx.destination);

      if (this.settings.ambienceEnabled) {
        this.startAmbience();
      }
    } catch (e) {
      console.warn('AudioContext init failed:', e);
    }
  }

  ensureReady() {
    if (!this.ctx) {
      this.init();
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  setVolume(category, val) {
    this.settings[category] = Math.max(0, Math.min(1, val));
    if (category === 'masterVolume' && this.masterGain && this.ctx) {
      this.masterGain.gain.setTargetAtTime(this.settings.masterVolume, this.ctx.currentTime, 0.05);
    }
    if (category === 'ambienceVolume' && this.ambienceGain && this.ctx) {
      this.ambienceGain.gain.setTargetAtTime(
        this.settings.ambienceEnabled ? this.settings.ambienceVolume : 0,
        this.ctx.currentTime,
        0.05
      );
    }
  }

  toggleAmbience(enabled) {
    this.settings.ambienceEnabled = enabled;
    if (enabled) {
      this.startAmbience();
    } else {
      this.stopAmbience();
    }
  }

  startAmbience() {
    if (!this.ctx || this.ambienceSource) return;
    try {
      const bufferSize = this.ctx.sampleRate * 2;
      const noiseBuffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
      const output = noiseBuffer.getChannelData(0);
      let lastOut = 0.0;
      for (let i = 0; i < bufferSize; i++) {
        const white = Math.random() * 2 - 1;
        output[i] = (lastOut + 0.02 * white) / 1.02; // soft pink noise
        lastOut = output[i];
      }

      this.ambienceSource = this.ctx.createBufferSource();
      this.ambienceSource.buffer = noiseBuffer;
      this.ambienceSource.loop = true;

      const filter = this.ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.value = 320;

      this.ambienceGain = this.ctx.createGain();
      const vol = this.settings.ambienceEnabled ? this.settings.ambienceVolume * 0.25 : 0;
      this.ambienceGain.gain.setValueAtTime(vol, this.ctx.currentTime);

      this.ambienceSource.connect(filter);
      filter.connect(this.ambienceGain);
      this.ambienceGain.connect(this.masterGain);

      this.ambienceSource.start();
    } catch (e) {
      console.warn('Failed to start ambient audio:', e);
    }
  }

  stopAmbience() {
    if (this.ambienceSource) {
      try {
        this.ambienceSource.stop();
        this.ambienceSource.disconnect();
      } catch (e) {}
      this.ambienceSource = null;
    }
  }

  // Play Baby Chick Chirp
  playChirp(type = 'happy', pan = 0) {
    this.ensureReady();
    if (!this.ctx) return;

    try {
      const t = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const panner = this.ctx.createStereoPanner ? this.ctx.createStereoPanner() : null;

      const baseVol = this.settings.chirpVolume;

      if (type === 'angry') {
        // Harsh sharp squawk
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(1400, t);
        osc.frequency.exponentialRampToValueAtTime(750, t + 0.12);

        gain.gain.setValueAtTime(baseVol * 0.45, t);
        gain.gain.exponentialRampToValueAtTime(0.001, t + 0.15);
        osc.start(t);
        osc.stop(t + 0.16);
      } else if (type === 'coo') {
        // Gentle comforting purr / coo
        osc.type = 'sine';
        osc.frequency.setValueAtTime(1100, t);
        osc.frequency.linearRampToValueAtTime(1350, t + 0.08);
        osc.frequency.exponentialRampToValueAtTime(950, t + 0.22);

        gain.gain.setValueAtTime(0.001, t);
        gain.gain.linearRampToValueAtTime(baseVol * 0.5, t + 0.04);
        gain.gain.exponentialRampToValueAtTime(0.001, t + 0.24);
        osc.start(t);
        osc.stop(t + 0.25);
      } else {
        // Classic high-pitched lively chirp
        osc.type = 'triangle';
        const startFreq = 2200 + Math.random() * 400;
        const peakFreq = startFreq + 700;
        osc.frequency.setValueAtTime(startFreq, t);
        osc.frequency.linearRampToValueAtTime(peakFreq, t + 0.04);
        osc.frequency.exponentialRampToValueAtTime(startFreq - 300, t + 0.1);

        gain.gain.setValueAtTime(0.001, t);
        gain.gain.linearRampToValueAtTime(baseVol * 0.4, t + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.001, t + 0.12);
        osc.start(t);
        osc.stop(t + 0.13);
      }

      if (panner) {
        panner.pan.setValueAtTime(Math.max(-0.9, Math.min(0.9, pan)), t);
        osc.connect(gain);
        gain.connect(panner);
        panner.connect(this.masterGain);
      } else {
        osc.connect(gain);
        gain.connect(this.masterGain);
      }
    } catch (e) {
      console.warn('playChirp failed:', e);
    }
  }

  // Play Heavy Coop Slam / Table Shock Effect
  playSlam() {
    this.ensureReady();
    if (!this.ctx) return;

    try {
      const t = this.ctx.currentTime;
      const vol = this.settings.slamVolume;

      // 1. Deep low-frequency wooden impact thud
      const subOsc = this.ctx.createOscillator();
      const subGain = this.ctx.createGain();
      subOsc.type = 'sine';
      subOsc.frequency.setValueAtTime(90, t);
      subOsc.frequency.exponentialRampToValueAtTime(32, t + 0.25);

      subGain.gain.setValueAtTime(vol * 0.9, t);
      subGain.gain.exponentialRampToValueAtTime(0.001, t + 0.35);

      subOsc.connect(subGain);
      subGain.connect(this.masterGain);
      subOsc.start(t);
      subOsc.stop(t + 0.36);

      // 2. Resonant wooden plank crack noise
      const bufferSize = Math.floor(this.ctx.sampleRate * 0.18);
      const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (this.ctx.sampleRate * 0.035));
      }

      const noiseSource = this.ctx.createBufferSource();
      noiseSource.buffer = buffer;

      const bandpass = this.ctx.createBiquadFilter();
      bandpass.type = 'bandpass';
      bandpass.frequency.setValueAtTime(140, t);
      bandpass.Q.setValueAtTime(4.0, t);

      const noiseGain = this.ctx.createGain();
      noiseGain.gain.setValueAtTime(vol * 0.75, t);
      noiseGain.gain.exponentialRampToValueAtTime(0.001, t + 0.2);

      noiseSource.connect(bandpass);
      bandpass.connect(noiseGain);
      noiseGain.connect(this.masterGain);

      noiseSource.start(t);
    } catch (e) {
      console.warn('playSlam failed:', e);
    }
  }

  // Play Feed Call Bell Chime
  playBell() {
    this.ensureReady();
    if (!this.ctx) return;

    try {
      const t = this.ctx.currentTime;
      const vol = this.settings.bellVolume;

      // Multi-frequency bell harmonics
      const frequencies = [1760, 2640, 3520, 5280];
      const amplitudes = [0.4, 0.25, 0.15, 0.08];

      frequencies.forEach((freq, idx) => {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, t);

        const amp = amplitudes[idx] * vol;
        gain.gain.setValueAtTime(amp, t);
        gain.gain.exponentialRampToValueAtTime(0.0001, t + 1.2 + idx * 0.2);

        osc.connect(gain);
        gain.connect(this.masterGain);

        osc.start(t);
        osc.stop(t + 1.6);
      });
    } catch (e) {
      console.warn('playBell failed:', e);
    }
  }

  // Play cute grain pecking sound
  playPeck() {
    this.ensureReady();
    if (!this.ctx) return;

    try {
      const t = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(950 + Math.random() * 200, t);
      osc.frequency.exponentialRampToValueAtTime(400, t + 0.035);

      gain.gain.setValueAtTime(this.settings.chirpVolume * 0.25, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.04);

      osc.connect(gain);
      gain.connect(this.masterGain);
      osc.start(t);
      osc.stop(t + 0.045);
    } catch (e) {}
  }

  // Play triumphant achievement unlock arpeggio chime
  playAchievement() {
    this.ensureReady();
    if (!this.ctx) return;

    try {
      const t = this.ctx.currentTime;
      const notes = [523.25, 659.25, 783.99, 1046.50];
      const vol = this.settings.bellVolume;

      notes.forEach((freq, idx) => {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        const noteStart = t + idx * 0.09;

        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, noteStart);

        gain.gain.setValueAtTime(0.001, noteStart);
        gain.gain.linearRampToValueAtTime(vol * 0.45, noteStart + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.0001, noteStart + 0.7);

        osc.connect(gain);
        gain.connect(this.masterGain);

        osc.start(noteStart);
        osc.stop(noteStart + 0.75);
      });
    } catch (e) {
      console.warn('playAchievement failed:', e);
    }
  }
}

window.soundEngine = new SoundEngine();
