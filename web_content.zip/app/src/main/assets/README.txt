HISAB BOOK — STARTER APP

Files:
- index.html: the app
- manifest.webmanifest and sw.js: basic install/offline support when hosted over HTTPS or localhost

Quick start:
1. Open index.html in a modern browser. On Android, Chrome can open the file, but browser restrictions vary.
2. For best install/offline behavior, host this folder on a static HTTPS host or run it on localhost.
3. Add people, then record transactions.
4. Go to Backup & settings > Download backup regularly.

Important:
- Records are stored in this browser's localStorage on this device.
- This starter version does not include cloud sync, user accounts, server backup, or bank integration.
- CSV export is available under Reports.
- Before relying on it for official bookkeeping, reconcile entries and keep independent backups.
