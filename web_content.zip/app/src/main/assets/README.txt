Satya Gyan Coaching Centre Website

Updated with class-wise monthly fees, Navodaya Vidyalaya entrance exam preparation information, teacher name SOEAL AHAMAD, and PhonePe QR payment image.

Open index.html in a browser. Keep phonepe_qr.png in the same folder as index.html.
