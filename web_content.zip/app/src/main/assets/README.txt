Coffee Trade ERP App

Open index.html in a modern browser. The app works as a standalone browser app and includes a PWA manifest/service worker for installability where supported.

Data is stored locally in the browser using localStorage, as in the original prototype.
