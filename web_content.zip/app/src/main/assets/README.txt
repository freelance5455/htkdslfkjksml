Ruth's Management App — V4.2 Reliability Pass

Purpose:
A reliability-focused build based on the V4.1 design approved by the user. This release intentionally avoids further visual redesign.

Preserved design:
- Diary: expressive plum/rose personal archive.
- Calendar: Monday-first constellation grid with distinct date tiles.
- Study: compact haunted archive.
- Projects: cyber-management console.

Reliability corrections:
- Corrected the service-worker cache version so it matches this build (ruth-management-v4-2).
- Updated visible version labels and the generated backup filename to V4.2.
- Preserved the existing localStorage key (ruthManagementV15), migration behavior, and app data structure.
- Backup JSON intentionally excludes App PIN and Diary PIN; these are screen locks, not encryption.

Checks performed on this package:
- Inline JavaScript syntax check.
- Service-worker JavaScript syntax check.
- ZIP integrity check.
- Isolated Node.js logic test of the app save/read-back routine, JSON round-trip, and migration normalization.

Not fully verified:
- Real-browser close/reopen persistence on Android.
- Physical Android phone behavior and touch ergonomics.
- Full offline launch after the browser has cached every required resource.
- Backup download and file-picker restore workflow end-to-end.
- Long-duration diary auto-lock behavior.

Important:
This is a development PWA/HTML package, not an Android APK. Browser storage is origin-specific. Use the same HTTPS address each time for reliable storage; opening a downloaded file directly can have inconsistent storage behavior. Export a backup before switching versions or entering important data. Keep V4.1 as your rollback copy.
