'use strict';
// Small dependency-free API proxy. Keep provider credentials in server environment variables.
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const ROOT = __dirname;
const PORT = Number(process.env.PORT || 8787);
const API_KEY = process.env.OPENAI_API_KEY || '';
const API_BASE = (process.env.OPENAI_BASE_URL || 'https://api.openai.com/v1').replace(/\/$/, '');
const MODEL = process.env.OPENAI_MODEL || 'gpt-4o-mini';
const SYSTEM_PROMPT = `You are MindTrace, an original detective-style reasoning assistant inspired by broad traits of observant, skeptical fictional consultants. Do not claim to be Patrick Jane or quote a show. Be warm, witty, quietly incisive, and very smart. Ask targeted questions that uncover definitions, assumptions, contradictions, and missing evidence. Continue from the previous messages, not a generic reset. Usually finish with one useful follow-up question. For extraordinary claims, define terms before judging. For images, separate visible observations from inference. For videos, the user may supply a few sampled frames, not every frame or audio. Be explicit about uncertainty. Body language alone cannot prove deception, and private mental states are not facts. Keep the response conversational, incisive, and clear.`;
const MIME = {'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.json':'application/json; charset=utf-8','.webmanifest':'application/manifest+json','.svg':'image/svg+xml','.md':'text/markdown; charset=utf-8'};
function respond(res, status, obj) { res.writeHead(status, {'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','Access-Control-Allow-Origin':'*'}); res.end(JSON.stringify(obj)); }
function parseBody(req) { return new Promise((resolve,reject)=>{let chunks=[],size=0;req.on('data',c=>{size+=c.length;if(size>18*1024*1024){reject(new Error('Request too large. Keep screenshot/video samples under 18 MB.'));req.destroy();return}chunks.push(c)});req.on('end',()=>{try{resolve(JSON.parse(Buffer.concat(chunks).toString('utf8')||'{}'))}catch{reject(new Error('Invalid JSON request.'))}});req.on('error',reject)}); }
const server = http.createServer(async (req,res)=>{
  const parsed = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  if(req.method==='OPTIONS'){res.writeHead(204,{'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'Content-Type','Access-Control-Allow-Methods':'GET,POST,OPTIONS'});return res.end()}
  if(parsed.pathname==='/api/health'&&req.method==='GET') return respond(res,200,{ok:true,name:'MindTrace API',model:MODEL,configured:!!API_KEY});
  if(parsed.pathname==='/api/chat'&&req.method==='POST'){
    if(!API_KEY)return respond(res,503,{error:'The server has no OPENAI_API_KEY configured. Add it to the server environment; do not put it in the browser app.'});
    let body;try{body=await parseBody(req)}catch(e){return respond(res,400,{error:e.message})}
    if(!Array.isArray(body.messages))return respond(res,400,{error:'messages must be an array'});
    const msgs=[{role:'system',content:SYSTEM_PROMPT},...body.messages.filter(m=>['user','assistant'].includes(m.role)).slice(-14).map(m=>({role:m.role,content:m.content}))];
    try {
      const upstream=await fetch(`${API_BASE}/chat/completions`,{method:'POST',headers:{'Authorization':`Bearer ${API_KEY}`,'Content-Type':'application/json'},body:JSON.stringify({model:MODEL,messages:msgs,temperature:0.8,max_tokens:800})});
      const raw=await upstream.text();let json;try{json=JSON.parse(raw)}catch{json={error:raw.slice(0,500)}};
      if(!upstream.ok)return respond(res,upstream.status,{error:json.error?.message||json.error||`AI provider returned HTTP ${upstream.status}`});
      const reply=json.choices?.[0]?.message?.content;if(!reply)return respond(res,502,{error:'No answer returned by the AI provider.'});
      return respond(res,200,{reply,model:json.model||MODEL});
    }catch(e){return respond(res,502,{error:`Could not reach AI provider: ${e.message}`})}
  }
  // Serve only files within the project directory. Keep API routes above this block.
  let p=decodeURIComponent(parsed.pathname);if(p==='/')p='/index.html';const full=path.resolve(ROOT,'.'+p);
  if(!full.startsWith(ROOT+path.sep)&&full!==path.join(ROOT,'index.html'))return respond(res,403,{error:'Forbidden'});
  fs.stat(full,(err,stat)=>{if(err||!stat.isFile()){res.writeHead(404,{'Content-Type':'text/plain'});return res.end('Not found')}const ext=path.extname(full);res.writeHead(200,{'Content-Type':MIME[ext]||'application/octet-stream','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer'});fs.createReadStream(full).pipe(res)});
});
server.listen(PORT,'0.0.0.0',()=>console.log(`MindTrace running on http://localhost:${PORT}; AI configured: ${Boolean(API_KEY)}`));
