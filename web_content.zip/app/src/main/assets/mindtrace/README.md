# MindTrace — detective-style AI conversation app

A mobile-first web/PWA app inspired by the broad traits of observant fictional detectives: skeptical reasoning, careful observation, witty follow-up questions, and testing assumptions. It is not affiliated with *The Mentalist* and does not reproduce Patrick Jane's dialogue.

## What is included
- Responsive mobile and desktop chat UI.
- Offline follow-up logic for claims, logic puzzles, and evidence-first questioning.
- Image upload; video upload with up to four locally sampled frames. Online vision requests send images/frames to the AI backend.
- Voice input through browser SpeechRecognition when the browser supports it; text-to-speech using the browser speech engine.
- Online AI mode using a configurable server endpoint. The provider key stays on the server, never in the browser JavaScript.
- Conversation context for the online model, connection test, new case, reply copying, read-aloud controls.
- PWA manifest and service-worker shell cache, supporting offline access after the app has first been hosted and loaded.

## Fastest way to test on a computer
Requires a recent Node.js installation. From this folder run:

```sh
node server.js
```

Then open `http://localhost:8787`. Offline mode works without an API key.

## Enable the smart online model
The included `server.js` is a small API proxy. Set the following environment variables on the server, then restart it:

- `OPENAI_API_KEY` — a private API key
- `OPENAI_BASE_URL` — defaults to `https://api.openai.com/v1`
- `OPENAI_MODEL` — defaults to `gpt-4o-mini`
- `PORT` — defaults to `8787`

Example in a terminal (Linux/macOS):

```sh
export OPENAI_API_KEY="your-private-key"
export OPENAI_MODEL="gpt-4o-mini"
node server.js
```

Do not commit a real key into GitHub. Use the host's secret/environment settings. Do not paste a private API key into the Settings URL field. The Settings field is for your backend URL, for example `https://your-own-backend.example`.

If you deploy only the static files on GitHub Pages, offline mode and the interface will work, but the online AI mode needs a separately hosted backend. GitHub Pages cannot run `server.js` itself.

## Media and privacy notes
Images are resized in the browser before upload. For video, the app sends a small number of sampled frames, not every frame or the video's audio. Avoid uploading private or sensitive media. An online request transmits the chosen message and attachment frames to your configured AI backend and its model provider.

## Important limitations
- Offline responses use rules and follow-up templates; they're not a full language model and do not truly understand images.
- Online mode depends on an available compatible model/provider, network access, API limits, and server configuration.
- Voice input depends on browser support and may use an online speech service provided by the browser.
- The app is a PWA/web app package, not a native Android APK. To install, host it over HTTPS, open it in a compatible browser, and choose the browser's Install/Add to Home Screen option.
- This app helps reason about behavior but cannot read minds or establish that someone is lying based on a single gesture.
