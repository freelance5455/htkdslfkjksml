let cart = JSON.parse(localStorage.getItem("cart")) || [];


function addToCart(product, price) {
  
  cart.push({
    name: product,
    price: price,
    quantity: 1
  });
  
  saveCart();
  
  alert("Added to cart 🛒");
}



function saveCart() {
  
  localStorage.setItem(
    "cart",
    JSON.stringify(cart)
  );
  
}



function loadCart() {
  
  let box = document.getElementById("cart");
  
  
  if (cart.length === 0) {
    
    box.innerHTML = "Your cart is empty";
    
    return;
    
  }
  
  
  box.innerHTML = "";
  
  let total = 0;
  
  
  cart.forEach((item, index) => {
    
    
    total += item.price * item.quantity;
    
    
    box.innerHTML += `

<div class="card">

<h3>${item.name}</h3>

<p>
$${item.price} x ${item.quantity}
</p>

<button onclick="removeItem(${index})">
Remove ❌
</button>

</div>

`;
    
  });
  
  
  box.innerHTML += `

<h2>Total: $${total}</h2>

`;
  
}



function removeItem(index) {
  
  cart.splice(index, 1);
  
  saveCart();
  
  loadCart();
  
}

function searchProducts() {
  
  let input =
    document.getElementById("search").value.toLowerCase();
  
  
  let products =
    document.getElementsByClassName("product");
  
  
  for (let i = 0; i < products.length; i++) {
    
    let name =
      products[i].getAttribute("data-name");
    
    
    if (name.includes(input)) {
      
      products[i].style.display = "block";
      
    }
    
    else {
      
      products[i].style.display = "none";
      
    }
    
  }
  
}