SMART SERVICES CENTRE website
================================

Files:
- index.html: website content
- styles.css: responsive design
- script.js: mobile menu and current year

Publish free using Cloudflare Pages (Direct Upload):
1. Sign up at https://dash.cloudflare.com/
2. Open Workers & Pages / Pages and create a project.
3. Choose Direct Upload if offered.
4. Upload the contents of this folder (index.html, styles.css, script.js).
5. Deploy and open the generated *.pages.dev address.

Alternative: Netlify Drop / manual deploy:
https://app.netlify.com/drop
Upload the website folder or a ZIP containing index.html, styles.css and script.js.

Important:
- This is a static website. Call, email, WhatsApp and map links work as external links.
- Replace/update details only if your business contact/address changes.
- Confirm your hosting provider's current free-plan limits before publishing.
- Government service approval/fees are controlled by the relevant department.
