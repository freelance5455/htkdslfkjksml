const CATS=["كل الألعاب","أكشن","مغامرات","رياضة","سباق","استراتيجية","رعب","ألعاب خفيفة","تطبيقات","PPSSPP"];
const TELEGRAM="https://t.me/XGamesMods";
const ADMIN_PASSWORD="XG@1234";
// ضع هنا رابط السيرفر بعد رفعه، مثال: https://your-domain.com/api
const SERVER_API="https://xgaming-api-1scl-production.up.railway.app/api";
let active="كل الألعاب", games=[];
const DELETED_GAMES_KEY="xg_deleted_games_v1", DELETED_COMPLAINTS_KEY="xg_deleted_complaints_v1";
let editingGameId="";
function getDeletedSet(key){try{return new Set(JSON.parse(localStorage.getItem(key)||"[]").map(String))}catch(e){return new Set()}}
function saveDeletedSet(key,set){localStorage.setItem(key,JSON.stringify([...set]))}
function markDeleted(key,id){const set=getDeletedSet(key);set.add(String(id));saveDeletedSet(key,set)}
function isDeleted(key,id){return getDeletedSet(key).has(String(id))}
function gameLinkValue(g){return normalizeUrl(g.apk||g.apkUrl||g.links?.apk||g.downloadUrl||g.downloadURL||g.url||g.link||g.download||g.pageUrl||g.pageURL||"")}
let imageLibrary=[];
const $=id=>document.getElementById(id);
// الاتصال بالإنترنت والسيرفر
const networkOverlay = () => $("networkOverlay");
const serverStatus = () => $("serverStatus");
const serverStatusText = () => $("serverStatusText");
let serverOnline = false;
function setNetworkUI(online){
  networkOverlay()?.classList.toggle("show", !online);
}
function setServerUI(online, text){
  serverOnline=!!online;
  const box=serverStatus();
  if(!box)return;
  box.classList.toggle("online",!!online); box.classList.toggle("offline",!online);
  serverStatusText().textContent=text || (online?"السيرفر متصل":"السيرفر غير متاح");
}
function nativeOnline(){try{return window.XGNetwork ? !!window.XGNetwork.isOnline() : navigator.onLine!==false}catch(e){return navigator.onLine!==false}}
function nativeNotify(title,message){if(localStorage.getItem("xg_notifications_enabled")==="0")return false;try{if(window.XGNetwork&&window.XGNetwork.showUpdateNotification){window.XGNetwork.showUpdateNotification(String(title),String(message));return true}}catch(e){}return false}
function notifyNewGames(remote){
  if(!Array.isArray(remote))return;
  const key="xg_seen_games_v1";
  let seen;
  try{seen=JSON.parse(localStorage.getItem(key)||"null")}catch(e){seen=null}
  const current={};
  remote.forEach(g=>{if(g?.id!=null)current[String(g.id)]=String(g.version||g.updatedAt||g.updated_at||"")});
  if(!seen){localStorage.setItem(key,JSON.stringify(current));return}
  Object.keys(current).forEach(id=>{
    if(!(id in seen)){
      const g=remote.find(x=>String(x?.id)===id);
      if(g)nativeNotify("🎮 لعبة جديدة",`تمت إضافة ${g.name||"لعبة جديدة"} إلى X Gaming`);
    }else if(current[id]!==seen[id] && current[id]!==""){
      const g=remote.find(x=>String(x?.id)===id);
      if(g)nativeNotify("🔄 تحديث لعبة",`تم تحديث ${g.name||"لعبة"} إلى الإصدار ${g.version||"الجديد"}`);
    }
  });
  localStorage.setItem(key,JSON.stringify(current));
}
window.nativeNetworkState=function(online){setNetworkUI(!!online);if(online) refreshRemoteState()};
async function checkServer(){
  if(!serverReady()){setServerUI(false,"السيرفر غير مُعد");return false}
  if(!nativeOnline()){setServerUI(false,"لا يوجد إنترنت");return false}
  try{
    await apiFetch("/health");
    setServerUI(true,"السيرفر متصل"); return true;
  }catch(e){
    setServerUI(false,"السيرفر غير متاح حالياً"); return false;
  }
}
async function refreshRemoteState(){
  setNetworkUI(nativeOnline());
  if(nativeOnline()) { await checkServer(); await loadServerGames(); await loadImageLibrary(); await syncAnnouncements(); await syncUserMessages(); await renderGames(); }
}
window.addEventListener("online",()=>refreshRemoteState());
window.addEventListener("offline",()=>{setNetworkUI(false);setServerUI(false,"لا يوجد إنترنت")});
if($("networkRetry")) $("networkRetry").onclick=()=>refreshRemoteState();

function save(){localStorage.setItem("xg_games",JSON.stringify(games))}
function placeholder(name){return "data:image/svg+xml;charset=UTF-8,"+encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" width="600" height="440"><defs><linearGradient id="g" x1="0" x2="1"><stop stop-color="#170c24"/><stop offset="1" stop-color="#5b16a0"/></linearGradient></defs><rect width="100%" height="100%" fill="url(#g)"/><text x="50%" y="52%" text-anchor="middle" fill="white" font-size="34" font-family="Arial">${name||"GAME"}</text></svg>`) }

// مكتبة صور دائمة داخل الجهاز باستخدام IndexedDB حتى لا تمتلئ localStorage بسهولة.
const DB_NAME="xgaming_media", DB_VERSION=1, STORE="images";
function openDB(){return new Promise((resolve,reject)=>{const r=indexedDB.open(DB_NAME,DB_VERSION);r.onupgradeneeded=()=>{if(!r.result.objectStoreNames.contains(STORE))r.result.createObjectStore(STORE,{keyPath:"id"})};r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)})}
async function dbPut(item){const db=await openDB();return new Promise((res,rej)=>{const tx=db.transaction(STORE,"readwrite");tx.objectStore(STORE).put(item);tx.oncomplete=()=>res();tx.onerror=()=>rej(tx.error)})}
async function dbGetAll(){const db=await openDB();return new Promise((res,rej)=>{const tx=db.transaction(STORE,"readonly");const r=tx.objectStore(STORE).getAll();r.onsuccess=()=>res(r.result||[]);r.onerror=()=>rej(r.error)})}
async function dbDelete(id){const db=await openDB();return new Promise((res,rej)=>{const tx=db.transaction(STORE,"readwrite");tx.objectStore(STORE).delete(id);tx.oncomplete=()=>res();tx.onerror=()=>rej(tx.error)})}
async function loadImageLibrary(){
  try{
    imageLibrary=await dbGetAll(); await migrateOldImages();
    if(serverReady()){
      const remote=await apiFetch("/images");
      imageLibrary=remote.map(x=>({id:x.id,name:x.name,data:x.url,remote:true})).concat(imageLibrary.filter(x=>!x.remote));
    }
  }catch(e){imageLibrary=await dbGetAll()}
}
async function migrateOldImages(){let changed=false;for(const g of games){if(g.image && !g.imageId){const id="legacy_"+g.id;await dbPut({id,name:g.name+" - صورة اللعبة",data:g.image,created:g.id});g.imageId=id;delete g.image;changed=true}}if(changed)save();imageLibrary=await dbGetAll()}

let categoriesExpanded=false;
function renderCats(){
  $("chips").innerHTML=CATS.map(c=>`<button class="chip ${c===active?"active":""}" data-cat="${esc(c)}">${esc(c)}</button>`).join("");
  if($("drawerCats")){
    $("drawerCats").innerHTML=CATS.slice(1).map(c=>`<button class="nav drawerCat ${c===active?"active":""}" data-cat="${esc(c)}"><span class="navIcon">●</span><span class="navText">${esc(c)}</span></button>`).join("");
    $("drawerCats").classList.toggle("drawerCatsCollapsed",!categoriesExpanded);
  }
  const toggle=$("categoriesToggle");
  if(toggle) toggle.classList.toggle("expanded",categoriesExpanded);
  if($("gCat")) $("gCat").innerHTML=CATS.slice(1).map(c=>`<option>${esc(c)}</option>`).join("");
  document.querySelectorAll("[data-cat]").forEach(x=>x.onclick=()=>{active=x.dataset.cat;renderCats();renderGames();closeDrawer()});
}
if($("categoriesToggle")) $("categoriesToggle").onclick=()=>{categoriesExpanded=!categoriesExpanded;renderCats()};
async function imageDataForGame(g){
  if(g.imageUrl)return g.imageUrl;
  if(g.imageId){const found=imageLibrary.find(x=>x.id===g.imageId);if(found)return found.data}
  return g.image||placeholder(g.name);
}
function ratingStars(value){const n=Math.max(0,Math.min(5,Number(value)||0));return n?`<span aria-label="التقييم ${n} من 5">${"★".repeat(n)}${"☆".repeat(5-n)}</span> <small>${n}/5</small>`:"<span>☆☆☆☆☆</span> <small>بدون تقييم</small>"}
async function renderGames(){
  const q=$("search").value.trim().toLowerCase();
  const list=games.filter(g=>!isDeleted(DELETED_GAMES_KEY,g.id)&&(active==="كل الألعاب"||(g.cat||g.category)===active)&&(!q||String(g.name||"").toLowerCase().includes(q)));
  const cards=await Promise.all(list.map(async g=>`<article class="card" data-game-id="${esc(g.id)}" tabindex="0" role="button"><img class="cover" loading="lazy" decoding="async" src="${esc(await imageDataForGame(g))}" alt="${esc(g.name)}"><div class="cardBody"><div class="cardTitle">${esc(g.name)}</div><div class="meta">الإصدار ${esc(g.version||"1.0")} · ${esc(g.size||"الحجم غير محدد")}</div><span class="tag">${esc(g.cat||g.category||"ألعاب")}</span></div></article>`));
  $("games").innerHTML=cards.join(""); $("empty").style.display=list.length?"none":"block";
  bindDownloadButtons($("games"));
  $("games").querySelectorAll(".card").forEach(card=>{
    const open=()=>{const g=games.find(x=>String(x.id)===String(card.dataset.gameId));if(g)showGamePage(g)};
    card.addEventListener("click",e=>{if(e.target.closest(".fileLink"))return;open()});
    card.addEventListener("keydown",e=>{if((e.key==="Enter"||e.key===" ")&&!e.target.closest(".fileLink")){e.preventDefault();open()}});
  });
}
function esc(s){return String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
function closeDrawer(){$("drawer").classList.remove("open");$("drawerBack").classList.remove("open")}
$("menuBtn").onclick=()=>{$("drawer").classList.add("open");$("drawerBack").classList.add("open")}
$("closeDrawer").onclick=closeDrawer;$("drawerBack").onclick=closeDrawer;

$("search").oninput=renderGames;
$("allBtn").onclick=()=>{active="كل الألعاب";renderCats();renderGames()};
$("reportOpen").onclick=()=>{$("reportModal").classList.add("show");closeDrawer();$("reportText").focus()};
$("adminOpen").onclick=()=>{$("loginModal").classList.add("show");closeDrawer();$("adminPass").focus()};
$("sendReport").onclick=sendProblemReport;
document.querySelectorAll("[data-close]").forEach(b=>b.onclick=()=>b.closest(".modal").classList.remove("show"));
$("loginBtn").onclick=async()=>{if($("adminPass").value===ADMIN_PASSWORD){$("loginModal").classList.remove("show");$("adminModal").classList.add("show");$("adminPass").value="";renderAdmin();renderImageLibrary();await loadComplaints()}else $("loginError").textContent="كلمة المرور غير صحيحة"};
async function sendProblemReport(){
  const text=$("reportText").value.trim(), name=$("reportName").value.trim();
  $("reportError").textContent="";
  if(!text){$("reportError").textContent="اكتب المشكلة الأول";return}
  if(!serverReady()||!nativeOnline()){$("reportError").textContent="لا يوجد اتصال بالسيرفر حالياً. اتصل بالإنترنت وحاول مرة أخرى.";return}
  const btn=$("sendReport");btn.disabled=true;btn.textContent="جاري الإرسال...";
  try{
    await apiFetch("/complaints",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({message:text,name,deviceId:getDeviceId(),appVersion:"X Gaming"})});
    $("reportText").value="";$("reportName").value="";$("reportModal").classList.remove("show");alert("تم إرسال المشكلة للمسؤول بنجاح ❤️");
  }catch(e){$("reportError").textContent="حصلت مشكلة أثناء الإرسال. حاول مرة تانية."}
  finally{btn.disabled=false;btn.textContent="إرسال المشكلة"}
}
async function loadComplaints(){
  const box=$("adminComplaints");if(!box)return;
  if(!serverReady()||!nativeOnline()){box.innerHTML='<div class="complaintEmpty">تعذر تحميل مشاكل المستخدمين حالياً.</div>';return}
  try{
    const result=await apiFetch("/complaints",{headers:{Authorization:"Bearer "+ADMIN_PASSWORD}});
    const list=Array.isArray(result)?result:(Array.isArray(result.complaints)?result.complaints:[]);
    const visibleList=list.filter(c=>!isDeleted(DELETED_COMPLAINTS_KEY,c.id));
    box.innerHTML='<h3>مشاكل المستخدمين</h3>'+ (visibleList.length?visibleList.map(c=>`<div class="complaintItem"><b>${esc(c.name||"مستخدم بدون اسم")}</b><br><small>${esc(c.created_at||c.createdAt||"")} · ${esc(c.deviceId||"")}</small><div class="complaintText">${esc(c.message||"")}</div><button type="button" class="del complaintDelete" data-complaint="${esc(c.id)}">حذف البلاغ</button></div>`).join(""):'<div class="complaintEmpty">مفيش مشاكل جديدة.</div>');
  box.querySelectorAll(".complaintDelete").forEach(btn=>btn.onclick=async()=>{
    if(!confirm("حذف البلاغ ده؟"))return;
    const id=String(btn.dataset.complaint||"").trim();
    if(!id){alert("رقم البلاغ غير موجود");return}
    btn.disabled=true; btn.textContent="جاري الحذف...";
    // أخفِ البلاغ فوراً واحفظ الحذف قبل الاتصال بالسيرفر حتى لا يعود عند التحديث.
    markDeleted(DELETED_COMPLAINTS_KEY,id);
    btn.closest(".complaintItem")?.remove();
    try{
      await apiFetch("/complaints/"+encodeURIComponent(id),{method:"DELETE",headers:{Authorization:"Bearer "+ADMIN_PASSWORD}});
      await loadComplaints();
      alert("تم حذف البلاغ من لوحة المسؤول.");
    }catch(e){
      markDeleted(DELETED_COMPLAINTS_KEY,id);
      btn.closest(".complaintItem")?.remove();
      alert("تم حذف البلاغ من التطبيق. تعذر حذف نسخة السيرفر حالياً، وسيظل مخفياً في التطبيق.");
    }
  });
  }catch(e){box.innerHTML='<div class="complaintEmpty">تعذر تحميل مشاكل المستخدمين من السيرفر.</div>'}
}
function normalizeUrl(value){
  let v=String(value||"").trim();
  if(!v)return "";
  if(/^tg:\/\//i.test(v))return v;
  if(/^https?:\/\//i.test(v))return v;
  if(/^www\./i.test(v)||/^[a-z0-9.-]+\.[a-z]{2,}(\/|$)/i.test(v))return "https://"+v;
  // لو تم إدخال رابط بحث/صفحة بدون البروتوكول، افتحه كرابط ويب مباشر.
  return "https://"+v.replace(/^\/+/,"");
}
function serverReady(){return !SERVER_API.includes("YOUR-SERVER-DOMAIN")}
function getDeviceId(){let id=localStorage.getItem("xg_device_id");if(!id){id="xg-"+Date.now().toString(36)+"-"+Math.random().toString(36).slice(2,10);localStorage.setItem("xg_device_id",id)}return id}
async function apiFetch(path, options={}){
  if(!serverReady())throw new Error("SERVER_NOT_CONFIGURED");
  const method=String(options.method||"GET").toUpperCase();
  let lastError;
  for(let attempt=0;attempt<(method==="GET"?4:2);attempt++){
    const controller=new AbortController();
    const timer=setTimeout(()=>controller.abort(),10000);
    try{
      const r=await fetch(SERVER_API+path,{...options,signal:controller.signal,cache:method==="GET"?"no-store":options.cache});
      if(!r.ok)throw new Error(await r.text());
      return await r.json();
    }catch(e){
      lastError=e;
      if(attempt<2)await new Promise(res=>setTimeout(res,350*(attempt+1)));
    }finally{clearTimeout(timer)}
  }
  throw lastError||new Error("SERVER_UNAVAILABLE");
}
async function purgeCurrentContentOnce(){
  const key="xg_initial_content_cleared_v1";
  if(localStorage.getItem(key)==="1")return;
  localStorage.removeItem("xg_games");
  localStorage.removeItem(DELETED_GAMES_KEY);
  localStorage.removeItem(DELETED_COMPLAINTS_KEY);
  games=[];
  if(!serverReady()||!nativeOnline()){localStorage.setItem(key,"1");return}
  try{
    const gamesResult=await apiFetch("/games",{headers:{Authorization:"Bearer "+ADMIN_PASSWORD}});
    const serverGames=Array.isArray(gamesResult)?gamesResult:(Array.isArray(gamesResult.games)?gamesResult.games:[]);
    for(const g of serverGames){if(g?.id!=null){try{await apiFetch("/games/"+encodeURIComponent(g.id),{method:"DELETE",headers:{Authorization:"Bearer "+ADMIN_PASSWORD}})}catch(e){console.warn("تعذر حذف لعبة قديمة",e)}}}
    const complaintsResult=await apiFetch("/complaints",{headers:{Authorization:"Bearer "+ADMIN_PASSWORD}});
    const serverComplaints=Array.isArray(complaintsResult)?complaintsResult:(Array.isArray(complaintsResult.complaints)?complaintsResult.complaints:[]);
    for(const c of serverComplaints){if(c?.id!=null){try{await apiFetch("/complaints/"+encodeURIComponent(c.id),{method:"DELETE",headers:{Authorization:"Bearer "+ADMIN_PASSWORD}})}catch(e){console.warn("تعذر حذف بلاغ قديم",e)}}}
  }catch(e){console.warn("تعذر تنظيف المحتوى القديم بالكامل",e)}
  localStorage.setItem(key,"1");
}

async function syncAnnouncements(){if(!serverReady()||!nativeOnline())return;try{const list=await apiFetch('/announcements');if(!Array.isArray(list))return;const seen=new Set(JSON.parse(localStorage.getItem('xg_seen_announcements')||'[]').map(String));const ids=[];list.forEach(a=>{ids.push(String(a.id));if(!seen.has(String(a.id)))nativeNotify(a.title||'إشعار',a.message||'')});localStorage.setItem('xg_seen_announcements',JSON.stringify(ids.slice(0,50)))}catch(e){}}
async function saveGameToServer(g){
  if(!serverReady()||!nativeOnline()) throw new Error("SERVER_UNAVAILABLE");
  return apiFetch("/games",{method:"POST",headers:{"Content-Type":"application/json",Authorization:"Bearer "+ADMIN_PASSWORD},body:JSON.stringify(g)});
}
async function loadServerGames(){
  if(!serverReady()||!nativeOnline())return;
  try{
    const result=await apiFetch("/games");
    const remoteGames=Array.isArray(result)?result:(Array.isArray(result.games)?result.games:[]);
    notifyNewGames(remoteGames);
    games=remoteGames.map(g=>({...g,cat:(g.cat||g.category)==="ألعاب المحاكيات"?"PPSSPP":(g.cat||g.category||"ألعاب خفيفة"),apk:gameLinkValue(g),obb:normalizeUrl(g.obb||g.obbUrl||g.links?.obb||g.obbLink),data:normalizeUrl(g.data||g.dataUrl||g.links?.data||g.dataLink),rating:Number(g.rating||0),size:g.size||"",hidden:Boolean(g.hidden)})).filter(g=>!isDeleted(DELETED_GAMES_KEY,g.id));
    save();
  }catch(e){console.warn("تعذر الاتصال بالسيرفر",e)}
}

$("openImagePicker")?.addEventListener("click",()=>$("gImages")?.click());

$("gImages").onchange=async()=>{
  const input=$("gImages");
  const files=[...(input?.files||[])];
  if(!files.length)return;
  let added=0;
  for(const file of files){
    if(!file.type || !file.type.startsWith("image/"))continue;
    try{
      const data=await new Promise((resolve,reject)=>{
        const fr=new FileReader();
        fr.onload=()=>resolve(fr.result);
        fr.onerror=()=>reject(fr.error||new Error("تعذر قراءة الصورة"));
        fr.readAsDataURL(file);
      });
      const id="img_"+Date.now()+"_"+Math.random().toString(36).slice(2);
      // الحفظ المحلي يتم أولاً، لذلك لا تضيع الصورة إذا انقطع السيرفر.
      await dbPut({id,name:file.name||"صورة اللعبة",data,created:Date.now()});
      added++;
      if(serverReady()){
        try{
          const fd=new FormData();
          fd.append("image",file,file.name||"game-image");
          await apiFetch("/images",{method:"POST",headers:{Authorization:"Bearer "+ADMIN_PASSWORD},body:fd});
        }catch(e){console.warn("تعذر رفع الصورة للسيرفر، تم حفظها محلياً",e)}
      }
    }catch(e){
      console.warn("تعذر إضافة الصورة",file?.name,e);
    }
  }
  input.value="";
  await loadImageLibrary();
  renderImageLibrary();
  if(added) alert(`تمت إضافة ${added} صورة بنجاح`);
};

let selectedImageId="";
function renderImageLibrary(){
  const box=$("imageLibrary");if(!box)return;
  if(!imageLibrary.length){box.innerHTML='<div class="emptyImages">لا توجد صور في المكتبة بعد.</div>';return}
  box.innerHTML=imageLibrary.map(img=>`<div class="libItem ${selectedImageId===img.id?"selected":""}" data-img="${esc(img.id)}"><img src="${esc(img.data)}"><div class="libName">${esc(img.name)}</div><button type="button" class="pickImg">${selectedImageId===img.id?"✓ مختارة":"اختيار"}</button><button type="button" class="deleteImg">حذف</button></div>`).join("");
  box.querySelectorAll(".libItem").forEach(el=>{const id=el.dataset.img;el.querySelector(".pickImg").onclick=()=>{selectedImageId=id;renderImageLibrary()};el.querySelector(".deleteImg").onclick=async()=>{if(!confirm("حذف الصورة من المكتبة؟"))return;await dbDelete(id);if(selectedImageId===id)selectedImageId="";imageLibrary=await dbGetAll();renderImageLibrary()}})
}

$("addGame").onclick=async()=>{
 const name=$("gName").value.trim(); if(!name){alert("اكتب اسم اللعبة");return}
 const safeId=String(name).toLowerCase().replace(/[^a-z0-9\u0600-\u06ff]+/g,"-").replace(/^-|-$/g,"")+"-"+Date.now().toString(36);
 if(!editingGameId && !selectedImageId && imageLibrary.length){alert("اختر صورة الغلاف للعبة");return}
 const picked=imageLibrary.find(x=>x.id===selectedImageId);
 const payload={id:editingGameId||safeId,name,version:$("gVersion").value||"1.0",size:$("gSize").value||"",hidden:$("gHidden").value==="true",cat:$("gCat").value,rating:Number($("gRating").value||0),desc:$("gDesc").value,imageId:selectedImageId,imageUrl:picked?.remote?picked.data:(picked?.data||""),apk:normalizeUrl($("gApk").value),obb:normalizeUrl($("gObb").value),data:normalizeUrl($("gData").value)};
 try{await saveGameToServer(payload);alert(editingGameId?"تم حفظ التعديلات":"تم نشر اللعبة");resetGameForm();await loadServerGames();await renderAdmin();await renderGames();}
 catch(e){games.unshift(payload);save();await renderGames();alert("تم حفظها محلياً؛ تأكد من اتصال السيرفر")}
}
$("resetGameForm")?.addEventListener("click",resetGameForm);

function userKey(base){const u=getCurrentUser();return u?.id?`${base}_${String(u.id)}`:base+"_guest"}
function getDownloads(){try{return JSON.parse(localStorage.getItem(userKey("xg_download_history"))||"[]")}catch(e){return []}}
function saveDownloads(list){localStorage.setItem(userKey("xg_download_history"),JSON.stringify(list.slice(0,50)));updateDownloadUI()}
function getFavorites(){try{return new Set(JSON.parse(localStorage.getItem(userKey("xg_favorites"))||"[]").map(String))}catch(e){return new Set()}}
function toggleFavorite(id){const s=getFavorites(),k=String(id);if(s.has(k))s.delete(k);else s.add(k);localStorage.setItem(userKey("xg_favorites"),JSON.stringify([...s]));return s.has(k)}
function getViewedGames(){try{return JSON.parse(localStorage.getItem(userKey("xg_view_history"))||"[]")}catch(e){return []}}
function recordViewedGame(game){if(!game?.id)return;const list=getViewedGames().filter(x=>String(x.id)!==String(game.id));list.unshift({id:String(game.id),name:game.name||"لعبة",imageUrl:game.imageUrl||game.image||"",cat:game.cat||game.category||"ألعاب",time:Date.now()});localStorage.setItem(userKey("xg_view_history"),JSON.stringify(list.slice(0,50)))}
function recordDownload(game,label,url){if(!url)return;const list=getDownloads().filter(x=>!(x.gameId===String(game.id)&&x.label===label));list.unshift({gameId:String(game.id),game:game.name,label,url,time:Date.now(),image:game.imageUrl||game.image||""});saveDownloads(list); if(serverReady()&&nativeOnline()) apiFetch("/downloads",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({gameId:String(game.id),gameName:game.name,label,url,deviceId:getDeviceId()})}).catch(()=>{});}
function updateDownloadUI(){const n=getDownloads().length;const c=$("downloadCount");if(c)c.textContent=n;renderDownloadHistory()}
function renderDownloadHistory(){const box=$("downloadHistory");if(!box)return;const list=getDownloads();box.innerHTML=list.length?list.map((x,i)=>`<div class="downloadItem"><div class="downloadThumb">↓</div><div class="downloadInfo"><b>${esc(x.game)}</b><small>${esc(x.label)} · ${new Date(x.time).toLocaleString("ar-EG")}</small></div><a class="downloadAgain" href="${esc(x.url)}" target="_blank" rel="noopener">تنزيل</a></div>`).join(""):'<div class="downloadEmpty">لسه مفيش تنزيلات في السجل.</div>';}
function recordDownloadById(id,label,url){const game=games.find(g=>String(g.id)===String(id))||{id,name:"لعبة"};recordDownload(game,label,url)}
function linkButton(url,label,game){
  if(!url)return "";
  return `<a class="fileLink" href="${esc(url)}" target="_blank" rel="noopener noreferrer" data-url="${esc(url)}" data-game="${esc(String(game.id))}" data-label="${esc(label)}">${label}</a>`
}
function bindDownloadButtons(root=document){
  root.querySelectorAll(".fileLink").forEach(btn=>btn.onclick=e=>{
    e.preventDefault(); e.stopPropagation();
    const url=btn.dataset.url,id=btn.dataset.game,label=btn.dataset.label;
    const game=games.find(g=>String(g.id)===String(id))||{id,name:"لعبة"};
    recordDownloadById(id,label,url);
    try{
      if(window.XGNetwork&&window.XGNetwork.startDownload){
        window.XGNetwork.startDownload(url,String(game.name||"لعبة"),String(label||"FILE"));
        return;
      }
    }catch(err){}
    openExternalDownload(e,url);
  })
}
async function renderAdminStats(){const box=$("adminStats");if(!box)return;try{const s=await apiFetch('/admin/stats',{headers:{Authorization:'Bearer '+ADMIN_PASSWORD}});box.innerHTML=`<div class="statsCards"><div><b>${s.games||0}</b><span>ألعاب</span></div><div><b>${s.downloads||0}</b><span>تنزيلات</span></div></div>`+(s.byGame||[]).map(x=>`<div class="statRow"><span>${esc(x.name||x.id)}</span><b>${x.downloads}</b></div>`).join('')}catch(e){box.innerHTML='<div class="empty">تعذر تحميل الإحصائيات.</div>'}}
async function renderAdminUsers(){const box=$("adminUsers");if(!box)return;try{const list=await apiFetch('/admin/users',{headers:{Authorization:'Bearer '+ADMIN_PASSWORD}});box.innerHTML='<div class="adminUsersHead"><h3>المستخدمون</h3><small>عدد المستخدمين: '+list.length+'</small></div>'+`<div class="adminUserList"><button class="adminUserRow selected" data-user="all"><span class="userAvatar">👥</span><span><b>كل المستخدمين</b><small>إرسال رسالة للجميع</small></span></button>`+(list.length?list.map(u=>`<button class="adminUserRow" data-user="${esc(u.id)}"><span class="userAvatar">${esc((u.name||'م').trim().slice(0,1))}</span><span><b>${esc(u.name||'بدون اسم')}</b><small>${esc(u.email||'')}</small></span></button>`).join(''):'<div class="empty">لا يوجد مستخدمون مسجلون.</div>')+'</div>';box.querySelectorAll('.adminUserRow').forEach(b=>b.onclick=()=>{const uid=b.dataset.user||'all';const title=prompt('عنوان الرسالة');if(!title)return;const message=prompt('اكتب رسالة للمستخدمين');if(!message)return;sendAdminMessage(uid,title,message)})}catch(e){box.innerHTML='<div class="empty">تعذر تحميل المستخدمين.</div>'}}
async function sendAdminMessage(userId,title,message){try{const r=await apiFetch('/admin/messages',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+ADMIN_PASSWORD},body:JSON.stringify({userId,title,message})});alert(`تم إرسال الرسالة إلى ${r.sent||0} مستخدم.`);await renderAdminUsers()}catch(e){alert('تعذر إرسال الرسالة حالياً')}}
async function syncUserMessages(){const token=localStorage.getItem('xg_auth_token');if(!token||!nativeOnline()||!serverReady())return;try{const list=await apiFetch('/messages',{headers:{Authorization:'Bearer '+token}});const seen=new Set(JSON.parse(localStorage.getItem('xg_seen_messages')||'[]').map(String));const ids=list.map(m=>String(m.id));for(const m of list){if(!seen.has(String(m.id)))nativeNotify(m.title||'رسالة من المسؤول',m.message||'')}localStorage.setItem('xg_seen_messages',JSON.stringify(ids.slice(0,50)));renderUserMessages(list)}catch(e){}}
function renderUserMessages(list){const box=$("userMessages");if(!box)return;if(!Array.isArray(list)||!list.length){box.innerHTML='<div class="empty">لا توجد رسائل من المسؤول حالياً.</div>';return}box.innerHTML=list.map(m=>`<article class="userMessageCard"><div><b>${esc(m.title||'رسالة')}</b><small>${esc(m.createdAt||'')}</small></div><p>${esc(m.message||'')}</p></article>`).join('')}
async function openUserMessages(){const box=$("userMessages");if(!box)return;const token=localStorage.getItem('xg_auth_token');if(!token){box.innerHTML='<div class="empty">سجّل الدخول أولاً لعرض رسائل المسؤول.</div>';return}try{const list=await apiFetch('/messages',{headers:{Authorization:'Bearer '+token}});renderUserMessages(list)}catch(e){box.innerHTML='<div class="empty">تعذر تحميل الرسائل حالياً.</div>'}}
async function sendAdminNotification(){const title=prompt('عنوان الإشعار');if(!title)return;const message=prompt('نص الإشعار');if(!message)return;try{await apiFetch('/admin/notify',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+ADMIN_PASSWORD},body:JSON.stringify({title,message})});nativeNotify(title,message);alert('تم تسجيل الإشعار وإرساله على هذا الجهاز. الأجهزة الأخرى ستستلمه عبر المزامنة عند توفر حدث جديد.')}catch(e){alert('تعذر إرسال الإشعار')}}
async function renderAdmin(){
  await renderAdminUsers();
  const box=$("adminGames"); if(!box)return;
  let list=games.filter(g=>!isDeleted(DELETED_GAMES_KEY,g.id));
  try{const all=await apiFetch('/admin/games',{headers:{Authorization:'Bearer '+ADMIN_PASSWORD}}); if(Array.isArray(all)){list=all.map(g=>({...g,desc:g.description||g.desc||'',imageUrl:g.image_url||g.imageUrl||'',cat:g.cat||'ألعاب خفيفة',rating:Number(g.rating||0),hidden:Boolean(g.hidden)}));}}catch(e){}
  box.innerHTML='<h3>إدارة الألعاب</h3>'+ (list.length?list.map(g=>`<div class="adminGameRow"><img src="${esc(g.imageUrl||placeholder(g.name))}"><div><b>${esc(g.name)}</b><small>الإصدار ${esc(g.version||"1.0")} · ${esc(g.size||"غير محدد")} · ${g.hidden?"مخفية":"منشورة"}</small></div><button class="secondary editGame" data-id="${esc(g.id)}">تعديل</button><button class="secondary hideGame" data-id="${esc(g.id)}">${g.hidden?"إظهار":"إخفاء"}</button><button class="secondary deleteGame" data-id="${esc(g.id)}">حذف</button></div>`).join(''):'<div class="empty">لا توجد ألعاب.</div>');
  box.querySelectorAll('.editGame').forEach(b=>b.onclick=()=>editGame(b.dataset.id));
  box.querySelectorAll('.hideGame').forEach(b=>b.onclick=()=>toggleGameHidden(b.dataset.id));
  box.querySelectorAll('.deleteGame').forEach(b=>b.onclick=()=>deleteGameRemote(b.dataset.id));
}
function resetGameForm(){editingGameId="";['gName','gVersion','gSize','gApk','gObb','gData','gDesc'].forEach(id=>{if($(id))$(id).value=''});if($("gHidden"))$("gHidden").value='false';selectedImageId="";$("addGame").textContent='＋ نشر اللعبة';renderImageLibrary()}
function editGame(id){const g=games.find(x=>String(x.id)===String(id));if(!g)return;editingGameId=String(g.id);$("gName").value=g.name||'';$("gVersion").value=g.version||'';$("gSize").value=g.size||'';$("gApk").value=g.apk||'';$("gObb").value=g.obb||'';$("gData").value=g.data||'';$("gDesc").value=g.desc||'';$("gCat").value=g.cat||'ألعاب خفيفة';$("gRating").value=String(g.rating||0);$("gHidden").value=String(!!g.hidden);selectedImageId=g.imageId||'';$("addGame").textContent='حفظ التعديلات';renderImageLibrary();window.scrollTo({top:0,behavior:'smooth'})}
async function toggleGameHidden(id){const g=games.find(x=>String(x.id)===String(id));if(!g)return;await saveGameToServer({...g,hidden:!g.hidden});await loadServerGames();await renderAdmin();await renderGames()}
async function deleteGameRemote(id){if(!confirm('حذف اللعبة نهائياً من السيرفر؟'))return;try{await apiFetch('/games/'+encodeURIComponent(id),{method:'DELETE',headers:{Authorization:'Bearer '+ADMIN_PASSWORD}});markDeleted(DELETED_GAMES_KEY,id);games=games.filter(g=>String(g.id)!==String(id));save();await renderGames();await renderAdmin()}catch(e){alert('تعذر حذف اللعبة')}}

function openTelegramSafe(){try{if(window.XGNetwork&&window.XGNetwork.openTelegram){window.XGNetwork.openTelegram();return}}catch(err){} try{window.open(TELEGRAM,"_blank")}catch(err){location.href=TELEGRAM}}
const telegramBtn=$("telegramBtn");
if(telegramBtn) telegramBtn.addEventListener("click",e=>{e.preventDefault();openTelegramSafe()});

function applyTheme(theme){
  const t=theme==="dark"?"dark":"light";
  document.body.dataset.theme=t;
  document.body.classList.toggle("light",t==="light");
  localStorage.setItem("xg_theme",t);
  const btn=$("themeToggle");
  if(btn){btn.setAttribute("aria-label",t==="dark"?"التبديل إلى الوضع الفاتح":"التبديل إلى الوضع الداكن");btn.title=t==="dark"?"الوضع الفاتح":"الوضع الداكن";}
}
const savedTheme=localStorage.getItem("xg_theme");
applyTheme(savedTheme||"light");
$("themeToggle")?.addEventListener("click",()=>applyTheme(document.body.dataset.theme==="dark"?"light":"dark"));
(async()=>{
  setNetworkUI(nativeOnline());
  renderCats();
  updateDownloadUI();
  if(nativeOnline()){
    await checkServer();
    await loadServerGames();
    await loadImageLibrary();
    await renderGames();
  } else {
    setServerUI(false,"لا يوجد إنترنت");
  }
  setInterval(()=>{if(nativeOnline()){refreshRemoteState().catch(()=>{});syncAnnouncements().catch(()=>{})}},15000);
// مزامنة خفيفة ومتكررة حتى تظهر الألعاب الجديدة لكل المستخدمين بسرعة.
let lastGamesFingerprint="";
async function syncGamesForEveryone(){
  if(!serverReady()||!nativeOnline())return;
  try{
    const result=await apiFetch("/games");
    const remote=Array.isArray(result)?result:(Array.isArray(result.games)?result.games:[]);
    notifyNewGames(remote);
    const fingerprint=JSON.stringify(remote.map(g=>[g.id,g.version,g.updatedAt,g.apk,g.obb,g.data]));
    if(Array.isArray(remote) && (remote.length>0 || games.length===0) && fingerprint!==lastGamesFingerprint){ lastGamesFingerprint=fingerprint; games=remote.map(g=>({...g,cat:(g.cat||g.category)==="ألعاب المحاكيات"?"PPSSPP":(g.cat||g.category||"ألعاب خفيفة"),apk:gameLinkValue(g),obb:normalizeUrl(g.obb||g.obbUrl||g.links?.obb||g.obbLink),data:normalizeUrl(g.data||g.dataUrl||g.links?.data||g.dataLink),rating:Number(g.rating||0),size:g.size||"",hidden:Boolean(g.hidden)})).filter(g=>!isDeleted(DELETED_GAMES_KEY,g.id)); save(); await renderGames(); }
  }catch(e){}
}
setInterval(syncGamesForEveryone,10000);
if(document.visibilityState!=="hidden") setTimeout(syncGamesForEveryone,1200);
})();

// حساب المستخدم: حسابات السيرفر عند توفره، مع وضع محلي احتياطي بدون سيرفر.
let authMode="login";
function getAccounts(){try{return JSON.parse(localStorage.getItem("xg_accounts")||"[]")}catch(e){return []}}
function getCurrentUser(){try{return JSON.parse(localStorage.getItem("xg_current_user")||"null")}catch(e){return null}}
function setAuthMode(mode){
  authMode=mode;
  $("loginTab").classList.toggle("active",mode==="login");
  $("registerTab").classList.toggle("active",mode==="register");
  $("authTitle").textContent=mode==="login"?"تسجيل الدخول":"إنشاء حساب";
  $("authSubtitle").textContent=mode==="login"?"سجّل دخولك للوصول إلى حسابك":"أنشئ حسابك في X Gaming في ثواني";
  $("authSubmit").textContent=mode==="login"?"دخول":"إنشاء الحساب";
  $("emailWrap").style.display=mode==="login"?"none":"block";
  $("confirmWrap").style.display=mode==="login"?"none":"block";
  $("authPass").autocomplete=mode==="login"?"current-password":"new-password";
  $("authError").textContent="";
}
function refreshAccountUI(){
  const u=getCurrentUser();
  $("accountName").textContent=u?.name||"زائر";
  $("accountEmail").textContent=u?.email||"لم يتم تسجيل الدخول";
  $("accountLogin").style.display=u?"none":"flex";
  $("accountRegister").style.display=u?"none":"flex";
  $("accountLogout").style.display=u?"flex":"none";
}
function openAuth(mode="login"){$("accountModal").classList.remove("show");$("authModal").classList.add("show");setAuthMode(mode);$("authName").focus()}
function getGameComments(id){try{const x=JSON.parse(localStorage.getItem("xg_game_comments")||"{}");return Array.isArray(x[String(id)])?x[String(id)]:[]}catch(e){return []}}
function saveGameComments(id,list){try{const x=JSON.parse(localStorage.getItem("xg_game_comments")||"{}");x[String(id)]=list;localStorage.setItem("xg_game_comments",JSON.stringify(x))}catch(e){}}
function getGameUserRating(id){try{const x=JSON.parse(localStorage.getItem("xg_game_user_ratings")||"{}");return Number(x[String(id)]||0)}catch(e){return 0}}
function saveGameUserRating(id,value){try{const x=JSON.parse(localStorage.getItem("xg_game_user_ratings")||"{}");x[String(id)]=Number(value);localStorage.setItem("xg_game_user_ratings",JSON.stringify(x))}catch(e){} }
function showGamePage(g){
  recordViewedGame(g);
  const view=$("pageView"),content=$("pageContent"); if(!view||!content)return;
  $("pageTitle").textContent=g.name||"اللعبة"; $("pageSubtitle").textContent=g.cat||g.category||"ألعاب";
  document.body.classList.add("page-open"); view.classList.add("show"); closeDrawer();
  Promise.resolve(imageDataForGame(g)).then(src=>{
    const comments=getGameComments(g.id), userRating=getGameUserRating(g.id);
    const downloadBox=`<section class="detailBox downloadBox"><h3>روابط التحميل</h3><div class="downloadGrid">${linkButton(g.apk,"APK",g)}${linkButton(g.obb,"OBB",g)}${linkButton(g.data,"DATA",g)}</div></section>`;
    const commentsHtml=comments.length?comments.map(c=>`<div class="gameComment"><b>${esc(c.name||"مستخدم")}</b><small>${esc(c.time||"")}</small><p>${esc(c.text||"")}</p></div>`).join(""):"<div class=\"commentsEmpty\">لسه مفيش تعليقات.</div>";
    content.innerHTML=`<div class="gameDetail"><img class="gameDetailCover" src="${esc(src)}" alt="${esc(g.name)}"><div class="gameDetailBody"><span class="tag">${esc(g.cat||g.category||"ألعاب")}</span><button type="button" class="favoriteBtn" id="favoriteGameBtn">${getFavorites().has(String(g.id))?"★ مفضلة":"☆ أضف للمفضلة"}</button><h2>${esc(g.name)}</h2><div class="gameDetailMeta">الإصدار ${esc(g.version||"1.0")} · الحجم ${esc(g.size||"غير محدد")}</div>${downloadBox}<section class="detailBox descriptionBox"><h3>الوصف</h3><p>${esc(g.desc||"لا يوجد وصف لهذه اللعبة.")}</p></section><section class="detailBox ratingBox"><h3>تقييم اللعبة</h3><div class="detailRating">${ratingStars(g.rating)}</div><div class="userStars">${[1,2,3,4,5].map(n=>`<button type="button" class="ratingStar ${n<=userRating?"selected":""}" data-rating="${n}">★</button>`).join("")}</div></section><section class="detailBox commentsBox"><h3>التعليقات</h3><div class="commentsList">${commentsHtml}</div><textarea class="commentInput" id="gameCommentInput" rows="4" placeholder="اكتب تعليقك هنا..."></textarea><button type="button" class="primary commentSend" id="sendGameComment">إضافة التعليق</button></section></div></div>`;
    bindDownloadButtons(content);
    $("favoriteGameBtn")?.addEventListener("click",()=>{const activeFav=toggleFavorite(g.id);$("favoriteGameBtn").textContent=activeFav?"★ مفضلة":"☆ أضف للمفضلة";});
    content.querySelectorAll(".ratingStar").forEach(btn=>btn.onclick=()=>{const value=Number(btn.dataset.rating);saveGameUserRating(g.id,value);content.querySelectorAll(".ratingStar").forEach(x=>x.classList.toggle("selected",Number(x.dataset.rating)<=value));});
    $("sendGameComment")?.addEventListener("click",()=>{const input=$("gameCommentInput"),text=input?.value.trim();if(!text)return;const list=getGameComments(g.id);list.push({name:getCurrentUser()?.name||"مستخدم",text,time:new Date().toLocaleString("ar-EG")});saveGameComments(g.id,list);showGamePage(g);});
  });
}
function showPage(type){
  const view=$("pageView"),content=$("pageContent"); if(!view||!content)return;
  $("pageTitle").textContent=type==="downloads"?"التنزيلات":"حسابي"; $("pageSubtitle").textContent=type==="downloads"?"سجل التنزيلات":"ملفك الشخصي";
  document.body.classList.add("page-open"); view.classList.add("show"); closeDrawer();
  if(type==="downloads"){
    const list=getDownloads();
    content.innerHTML='<div class="pageHero"><div class="pageHeroIcon">↓</div><div><h2>إدارة التنزيلات</h2><p>تابع الملفات والألعاب التي بدأت تنزيلها من التطبيق.</p></div></div>'+(list.length?'<div class="pageList">'+list.map(x=>`<div class="downloadItem"><div class="downloadThumb">↓</div><div class="downloadInfo"><b>${esc(x.game)}</b><small>${esc(x.label)} · ${new Date(x.time).toLocaleString("ar-EG")}</small></div><a class="downloadAgain" href="${esc(x.url)}" target="_blank" rel="noopener" onclick="openExternalDownload(event,${JSON.stringify(x.url)})">تنزيل</a></div>`).join('')+'</div>':'<div class="downloadEmpty">لسه مفيش تنزيلات في السجل.</div>')+'<button class="secondary pageClear" id="pageClearDownloads">مسح سجل التنزيلات</button>';
    $("pageClearDownloads").onclick=()=>{localStorage.removeItem(userKey("xg_download_history"));updateDownloadUI();showPage("downloads")};
  }else{
    const u=getCurrentUser(), fav=getFavorites(), viewed=getViewedGames(), downloads=getDownloads();
    const favGames=games.filter(g=>fav.has(String(g.id)));
    const seenGames=viewed.map(v=>games.find(g=>String(g.id)===String(v.id))||v).filter(Boolean);
    content.innerHTML=`<div class="profileHero"><div class="bigAvatar">◉</div><div><h2>${esc(u?.name||"زائر")}</h2><p>${esc(u?.email||"سجّل الدخول علشان تحفظ بيانات حسابك")}</p></div></div><div class="profileStats"><div><b>${downloads.length}</b><span>تنزيلات</span></div><div><b>${fav.size}</b><span>مفضلة</span></div><div><b>${viewed.length}</b><span>شاهدتها</span></div></div><div class="profileSections"><button class="profileSectionCard" id="profileFavorites"><span class="profileSectionIcon">♡</span><span><b>الألعاب المفضلة</b><small>${favGames.length} لعبة محفوظة</small></span><strong>›</strong></button><button class="profileSectionCard" id="profileDownloads"><span class="profileSectionIcon">↓</span><span><b>التنزيلات</b><small>${downloads.length} عملية محفوظة</small></span><strong>›</strong></button><button class="profileSectionCard" id="profileHistory"><span class="profileSectionIcon">◷</span><span><b>سجل الألعاب</b><small>${viewed.length} لعبة شاهدتها</small></span><strong>›</strong></button></div><div id="profileSectionContent" class="profileSectionContent"></div>${u?'<button class="primary" id="pageLogout">تسجيل الخروج</button>':'<div class="accountPageButtons"><button class="primary" id="pageLogin">تسجيل الدخول</button><button class="secondary" id="pageRegister">إنشاء حساب</button></div>'}`;
    const renderProfileList=(title,icon,list,empty)=>{const box=$("profileSectionContent");if(!box)return;box.innerHTML=`<div class="profileInnerTitle"><span class="profileSectionIcon">${icon}</span><h3>${title}</h3></div>`+(list.length?`<div class="profileGameList">${list.map(g=>`<button class="profileGameRow" data-game-id="${esc(String(g.id))}"><img src="${esc(g.imageUrl||placeholder(g.name))}" alt=""><span><b>${esc(g.name||"لعبة")}</b><small>${esc(g.cat||g.category||"")}</small></span><strong>›</strong></button>`).join('')}</div>`:`<div class="empty">${empty}</div>`);box.querySelectorAll('.profileGameRow').forEach(b=>b.onclick=()=>{const g=games.find(x=>String(x.id)===b.dataset.gameId);if(g)showGamePage(g)})};
    $("profileFavorites")?.addEventListener('click',()=>renderProfileList('الألعاب المفضلة','',favGames,'لسه مفيش ألعاب في المفضلة.'));
    $("profileDownloads")?.addEventListener('click',()=>{const box=$("profileSectionContent");box.innerHTML=downloads.length?`<div class="profileInnerTitle"><span class="profileSectionIcon">↓</span><h3>التنزيلات</h3></div><div class="profileGameList">${downloads.map(x=>`<div class="profileGameRow static"><span class="profileSectionIcon" aria-hidden="true"></span><span><b>${esc(x.game)}</b><small>${esc(x.label)} · ${new Date(x.time).toLocaleString('ar-EG')}</small></span></div>`).join('')}</div>`:'<div class="empty">لسه مفيش تنزيلات في السجل.</div>'});
    $("profileHistory")?.addEventListener('click',()=>renderProfileList('سجل الألعاب','',seenGames,'لسه مفيش ألعاب شاهدتها.'));
    if($("pageLogin"))$("pageLogin").onclick=()=>openAuth("login");if($("pageRegister"))$("pageRegister").onclick=()=>openAuth("register");if($("pageLogout"))$("pageLogout").onclick=()=>{localStorage.removeItem("xg_current_user");localStorage.removeItem("xg_auth_token");refreshAccountUI();showPage("account")};
  }
}
function openExternalDownload(e,url){e.preventDefault();e.stopPropagation();const clean=normalizeUrl(url);if(!clean)return;try{if(window.XGNetwork&&window.XGNetwork.startDownload){const game=games.find(g=>String(g.id)===String(e.currentTarget?.dataset?.game||""));window.XGNetwork.startDownload(clean,String(game?.name||"X Gaming"),String(e.currentTarget?.dataset?.label||"FILE"));return}}catch(err){}try{if(window.XGNetwork&&window.XGNetwork.openExternal){window.XGNetwork.openExternal(clean);return}}catch(err){}const w=window.open(clean,"_blank","noopener,noreferrer");if(!w){try{location.href=clean}catch(err){}}}
function closePage(){document.body.classList.remove("page-open");$("pageView")?.classList.remove("show")}
$("notificationsOpen")?.addEventListener("click",()=>{$("notificationsModal").classList.add("show");openUserMessages();}); $("requestNotifications")?.addEventListener("click",()=>{try{window.XGNetwork&&window.XGNetwork.requestNotificationPermission()}catch(e){}}); $("notificationsToggle")?.addEventListener("change",e=>localStorage.setItem("xg_notifications_enabled",e.target.checked?"1":"0")); $("adminStatsBtn")?.addEventListener("click",renderAdminStats); $("adminNotifyBtn")?.addEventListener("click",sendAdminNotification); $("adminMessagesBtn")?.addEventListener("click",renderAdminUsers); $("downloadsBtn").onclick=()=>showPage("downloads"); $("profileTopBtn").onclick=()=>showPage("account"); $("pageBack").onclick=closePage; $("downloadsOpen").onclick=()=>showPage("downloads"); $("clearDownloads").onclick=()=>{localStorage.removeItem(userKey("xg_download_history"));updateDownloadUI()};
$("accountLogin").onclick=()=>openAuth("login"); $("accountRegister").onclick=()=>openAuth("register"); $("loginTab").onclick=()=>setAuthMode("login"); $("registerTab").onclick=()=>setAuthMode("register");
$("accountLogout").onclick=()=>{localStorage.removeItem("xg_current_user");localStorage.removeItem("xg_auth_token");refreshAccountUI();alert("تم تسجيل الخروج")};
$("authSubmit").onclick=async()=>{
  const name=$("authName").value.trim(),email=$("authEmail").value.trim().toLowerCase(),pass=$("authPass").value;$("authError").textContent="";
  if(!name||!pass){$("authError").textContent="اكتب البيانات المطلوبة الأول";return}
  try{
    if(serverReady()&&nativeOnline()){
      const register=authMode==="register";
      if(register){const c=$("authConfirm").value;if(!email){$("authError").textContent="اكتب البريد الإلكتروني";return}if(pass.length<6){$("authError").textContent="كلمة المرور لازم تكون 6 أحرف على الأقل";return}if(pass!==c){$("authError").textContent="تأكيد كلمة المرور غير مطابق";return}}
      const result=await apiFetch(register?"/auth/register":"/auth/login",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(register?{name,email,password:pass}:{login:name,password:pass})});
      localStorage.setItem("xg_auth_token",result.token);localStorage.setItem("xg_current_user",JSON.stringify(result.user));$("authModal").classList.remove("show");refreshAccountUI();alert(register?"تم إنشاء الحساب بنجاح ❤️":"أهلاً بيك يا "+result.user.name+" 👋");return;
    }
    const accounts=getAccounts();
    if(authMode==="register"){const c=$("authConfirm").value;if(!email){$("authError").textContent="اكتب البريد الإلكتروني";return}if(pass.length<6){$("authError").textContent="كلمة المرور لازم تكون 6 أحرف على الأقل";return}if(pass!==c){$("authError").textContent="تأكيد كلمة المرور غير مطابق";return}if(accounts.some(a=>a.name.toLowerCase()===name.toLowerCase()||a.email===email)){ $("authError").textContent="الحساب موجود بالفعل";return }const user={id:"u_"+Date.now().toString(36),name,email,pass};accounts.push(user);localStorage.setItem("xg_accounts",JSON.stringify(accounts));localStorage.setItem("xg_current_user",JSON.stringify({id:user.id,name:user.name,email:user.email}));$("authModal").classList.remove("show");refreshAccountUI();alert("تم إنشاء الحساب بنجاح ❤️");}
    else{const found=accounts.find(a=>(a.name.toLowerCase()===name.toLowerCase()||a.email===name.toLowerCase())&&a.pass===pass);if(!found){$("authError").textContent="اسم المستخدم أو كلمة المرور غير صحيحة";return}localStorage.setItem("xg_current_user",JSON.stringify({id:found.id,name:found.name,email:found.email}));$("authModal").classList.remove("show");refreshAccountUI();alert("أهلاً بيك يا "+found.name+" 👋")}
  }catch(e){$("authError").textContent=authMode==="register"?"تعذر إنشاء الحساب حالياً":"اسم المستخدم أو كلمة المرور غير صحيحة"}
};
refreshAccountUI();
