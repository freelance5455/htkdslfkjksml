'use strict';
const $ = id => document.getElementById(id);
const DEFAULTS = {history:true,screen:false,explain:true,training:true,privacy:false,floating:false,voice:false,speak:false,autoNext:false,capture:false};
function readJSON(key,fallback){try{return JSON.parse(localStorage.getItem(key))??fallback}catch{return fallback}}
let settings = {...DEFAULTS,...readJSON('naurok_settings',{})};
let history = Array.isArray(readJSON('naurok_history',[])) ? readJSON('naurok_history',[]) : [];
let apiKey = localStorage.getItem('naurok_api_key') || ''; // Local prototype: readable by scripts with access to this origin.
let modelName = localStorage.getItem('naurok_model') || 'gemini-3.8-flash';
let quizStats=readJSON('naurok_quiz_stats',{attempts:0,correct:0});
let attachment = null;
let busy = false;
function saveSettings(){localStorage.setItem('naurok_settings',JSON.stringify(settings))}
function persistHistory(){if(settings.history&&!settings.privacy)localStorage.setItem('naurok_history',JSON.stringify(history.slice(-100)))}
function bubble(text,type='ai',save=true){const el=document.createElement('div');el.className='message '+type;el.textContent=text;$('messages').append(el);$('messages').scrollTop=$('messages').scrollHeight;if(save&&settings.history&&!settings.privacy){history.push({type,text,at:new Date().toISOString()});persistHistory()}return el}
function page(name){document.querySelectorAll('.page').forEach(x=>x.classList.toggle('active',x.id===name+'Page'));document.querySelectorAll('.tab').forEach(x=>x.classList.toggle('active',x.dataset.page===name))}
document.querySelectorAll('.tab').forEach(x=>x.onclick=()=>page(x.dataset.page));$('settingsBtn').onclick=()=>page('settings');
for(const box of document.querySelectorAll('[data-setting]')){const key=box.dataset.setting;box.checked=!!settings[key];box.onchange=()=>{settings[key]=box.checked;saveSettings();if(key==='privacy'&&box.checked){/* existing saved history is unchanged until manually cleared */}}}
$('saveKey').onclick=()=>{const k=$('apiKey').value.trim();if(k)apiKey=k;if(apiKey)localStorage.setItem('naurok_api_key',apiKey);$('apiKey').value='';$('keyStatus').textContent=apiKey?'Ключ запомнен на этом устройстве (не зашифрован)':'Ключ не введён'};
$('clearKey').onclick=()=>{apiKey='';localStorage.removeItem('naurok_api_key');$('apiKey').value='';$('keyStatus').textContent='Ключ удалён'};
$('keyStatus').textContent=apiKey?'Ключ сохранён на устройстве (не зашифрован)':'Ключ не введён';
$('modelName').value=modelName;
$('saveModel').onclick=()=>{const value=$('modelName').value.trim().replace(/^models\//,'');if(!/^[a-zA-Z0-9._-]+$/.test(value)){alert('Недопустимое имя модели');return}modelName=value;localStorage.setItem('naurok_model',value);alert('Модель сохранена')};
$('imageInput').onchange=async event=>{const file=event.target.files?.[0];if(!file)return;if(!file.type.startsWith('image/')){alert('Выбери изображение');return}if(file.size>4*1024*1024){alert('Выбери изображение меньше 4 МБ');return}attachment=file;$('attachmentName').textContent='📷 '+file.name;$('attachment').hidden=false};
$('removeAttachment').onclick=()=>{attachment=null;$('imageInput').value='';$('attachment').hidden=true};
function asBase64(file){return new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(String(reader.result).split(',')[1]);reader.onerror=reject;reader.readAsDataURL(file)})}
async function askGemini(question,file){if(!apiKey)throw Error('Сначала открой Настройки и введи новый Gemini API key.');if(file&&!settings.screen)throw Error('Включи анализ изображений в настройках.');const instruction=settings.explain?'Ты учебный помощник. Объясняй решение по шагам, помогай разобраться в теме.':'Ты учебный помощник. Отвечай кратко, с полезной подсказкой.';const parts=[{text:instruction+'\n\nВопрос: '+(question||'Объясни учебное задание на изображении')}];if(file)parts.push({inline_data:{mime_type:file.type,data:await asBase64(file)}});const controller=new AbortController();const timeout=setTimeout(()=>controller.abort(),30000);let response;try{response=await fetch('https://generativelanguage.googleapis.com/v1beta/models/'+encodeURIComponent(modelName)+':generateContent',{method:'POST',headers:{'Content-Type':'application/json','x-goog-api-key':apiKey},body:JSON.stringify({contents:[{parts}]}),signal:controller.signal})}finally{clearTimeout(timeout)}const data=await response.json();if(!response.ok)throw Error(data.error?.message||'HTTP '+response.status);return data.candidates?.[0]?.content?.parts?.map(p=>p.text||'').join('\n')||'Gemini не вернул текстовый ответ'}
$('send').onclick=async()=>{if(busy)return;const question=$('question').value.trim();const file=attachment;if(!question&&!file)return;busy=true;$('send').disabled=true;bubble(question||'[Изображение]','user');$('question').value='';$('removeAttachment').click();const reply=bubble('Gemini думает…','ai',false);try{const answer=await askGemini(question,file);reply.textContent=answer;if(settings.history&&!settings.privacy){history.push({type:'ai',text:answer,at:new Date().toISOString()});persistHistory()}if(settings.speak&&'speechSynthesis' in window){speechSynthesis.cancel();speechSynthesis.speak(new SpeechSynthesisUtterance(answer))}updateStats()}catch(err){reply.textContent='Ошибка: '+err.message;reply.classList.add('error')}finally{busy=false;$('send').disabled=false}};
$('clearHistory').onclick=()=>{if(!confirm('Удалить сохранённую историю и сообщения на экране?'))return;history=[];localStorage.removeItem('naurok_history');$('messages').replaceChildren();bubble('История очищена.','ai',false)};
$('exportHistory').onclick=()=>{const blob=new Blob([JSON.stringify(history,null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='naurok-history.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),2000)};
const quizzes=[{q:'Сколько будет 7 × 8?',options:['54','56','58','64'],correct:1,why:'7 × 8 = 56.'},{q:'Какой газ растения поглощают при фотосинтезе?',options:['Кислород','Азот','Углекислый газ','Гелий'],correct:2,why:'При фотосинтезе растения поглощают CO₂.'},{q:'Чему равна сумма углов треугольника?',options:['90°','180°','270°','360°'],correct:1,why:'Сумма внутренних углов треугольника равна 180°.'}];
let quizIndex=0;function renderQuiz(){const box=$('quiz');box.replaceChildren();if(!settings.training){box.textContent='Включи тренировочный режим в настройках.';return}const q=quizzes[quizIndex%quizzes.length];const heading=document.createElement('h3');heading.textContent=q.q;box.append(heading);const feedback=document.createElement('p');q.options.forEach((answer,index)=>{const btn=document.createElement('button');btn.className='quiz-option';btn.textContent=answer;btn.onclick=()=>{box.querySelectorAll('.quiz-option').forEach(b=>b.disabled=true);btn.classList.add(index===q.correct?'correct':'wrong');feedback.textContent=(index===q.correct?'Верно! ':'Попробуй разобраться: ')+q.why;quizStats.attempts++;if(index===q.correct)quizStats.correct++;localStorage.setItem('naurok_quiz_stats',JSON.stringify(quizStats));updateStats();if(settings.autoNext)setTimeout(()=>{quizIndex++;renderQuiz()},2200)};box.append(btn)});box.append(feedback)}$('newQuiz').onclick=()=>{quizIndex++;renderQuiz()};document.querySelector('[data-setting="training"]').addEventListener('change',renderQuiz);
if(settings.history&&!settings.privacy){history.slice(-100).forEach(item=>bubble(String(item.text||''),item.type==='user'?'user':'ai',false))}if(!$('messages').children.length)bubble('Привет! 👋 Я Naurok AI. Напиши учебный вопрос или выбери скриншот. Для подключения Gemini открой настройки.','ai',false);renderQuiz();

// Extra features: local library, training stats, voice, optional browser screen share.
let library=readJSON('naurok_library',[]);if(!Array.isArray(library))library=[];
function updateStats(){$('stats').textContent='Тренировок: '+quizStats.attempts+' · Верно: '+quizStats.correct+' · Сообщений: '+history.length+' · В библиотеке: '+library.length}
function renderLibrary(){const term=$('searchHistory').value.toLowerCase();const box=$('libraryItems');box.replaceChildren();const all=[...library.map(x=>({...x,source:'Избранное'})),...history.map(x=>({...x,source:'История'}))].filter(x=>String(x.text||'').toLowerCase().includes(term)).slice(-80).reverse();for(const item of all){const el=document.createElement('div');el.className='libraryItem';const title=document.createElement('small');title.textContent=item.source+' · '+(item.at||'');const content=document.createElement('p');content.textContent=String(item.text||'');el.append(title,content);box.append(el)}updateStats()}
$('searchHistory').oninput=renderLibrary;
$('saveLast').onclick=()=>{const last=history.filter(x=>x.type==='ai').at(-1);if(!last){alert('Сначала получи ответ Gemini');return}library.push({...last});library=library.slice(-100);localStorage.setItem('naurok_library',JSON.stringify(library));renderLibrary()};
function downloadJSON(name,value){const url=URL.createObjectURL(new Blob([JSON.stringify(value,null,2)],{type:'application/json'}));const a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1500)}
$('exportBackup').onclick=()=>downloadJSON('naurok-backup.json',{version:3,settings,history,library,quizStats,modelName});
$('importBackup').onchange=async e=>{const f=e.target.files?.[0];if(!f)return;try{if(f.size>2e6)throw Error('Слишком большой файл');const data=JSON.parse(await f.text());if(data.version!==3||!Array.isArray(data.history)||!Array.isArray(data.library))throw Error('Неверный формат');if(!confirm('Заменить историю, библиотеку и настройки из копии?'))return;history=data.history.slice(-100);library=data.library.slice(-100);settings={...DEFAULTS,...data.settings};quizStats=data.quizStats||{attempts:0,correct:0};localStorage.setItem('naurok_history',JSON.stringify(history));localStorage.setItem('naurok_library',JSON.stringify(library));localStorage.setItem('naurok_quiz_stats',JSON.stringify(quizStats));saveSettings();location.reload()}catch(err){alert('Не удалось восстановить: '+err.message)}};
$('miniBtn').onclick=()=>{if(!settings.floating){alert('Включи мини-окно в настройках');return}$('miniPanel').hidden=!$('miniPanel').hidden};
$('closeMini').onclick=()=>$('miniPanel').hidden=true;
$('openChat').onclick=()=>{page('chat');$('miniPanel').hidden=true};
$('voiceBtn').onclick=()=>{if(!settings.voice){alert('Включи голосовой ввод в настройках');return}const SR=window.SpeechRecognition||window.webkitSpeechRecognition;if(!SR){alert('Голосовой ввод недоступен в этом браузере');return}const r=new SR();r.lang='ru-RU';r.onresult=e=>{$('question').value=e.results[0][0].transcript};r.onerror=e=>alert('Ошибка распознавания: '+e.error);r.start()};
$('captureScreen').onclick=async()=>{if(!settings.capture){alert('Включи захват экрана в настройках');return}if(!navigator.mediaDevices?.getDisplayMedia){alert('Захват экрана недоступен в этом браузере. Используй кнопку 📷');return}let stream;try{stream=await navigator.mediaDevices.getDisplayMedia({video:true,audio:false});const video=document.createElement('video');video.srcObject=stream;await video.play();await new Promise(r=>setTimeout(r,500));const canvas=document.createElement('canvas');canvas.width=video.videoWidth;canvas.height=video.videoHeight;canvas.getContext('2d').drawImage(video,0,0);const blob=await new Promise(r=>canvas.toBlob(r,'image/jpeg',.8));if(!blob)throw Error('Не удалось создать снимок');attachment=new File([blob],'screen.jpg',{type:'image/jpeg'});$('attachmentName').textContent='📷 Снимок экрана';$('attachment').hidden=false;page('chat')}catch(err){alert('Захват не выполнен: '+err.message)}finally{stream?.getTracks().forEach(t=>t.stop())}};
const originalPage=page;page=function(name){originalPage(name);if(name==='library')renderLibrary()};
updateStats();

// Naurok AI 4.0: multiple chats, tools, themes and local planner.
const CHAT_KEY='naurok_chats_v4';
let chats=readJSON(CHAT_KEY,null);
if(!Array.isArray(chats)||!chats.length)chats=[{id:'main',name:'Основной чат',items:history.slice(-100)}];
let activeChat=localStorage.getItem('naurok_active_chat')||chats[0].id;
if(!chats.some(c=>c.id===activeChat))activeChat=chats[0].id;
function active(){return chats.find(c=>c.id===activeChat)}
function saveChats(){if(settings.history&&!settings.privacy)localStorage.setItem(CHAT_KEY,JSON.stringify(chats.slice(-25).map(c=>({...c,items:c.items.slice(-100)}))))}
function syncChat(){active().items=history.slice(-100);saveChats()}
function drawChats(){const sel=$('chatSelect');sel.replaceChildren();for(const c of chats){const o=document.createElement('option');o.value=c.id;o.textContent=c.name;sel.append(o)}sel.value=activeChat}
function switchChat(id){syncChat();activeChat=id;localStorage.setItem('naurok_active_chat',id);history=[...active().items];$('messages').replaceChildren();history.forEach(m=>bubble(m.text,m.type,false));drawChats()}
// Wrap existing message writer to persist each chat, without changing Gemini requests.
const originalBubble=bubble;
bubble=function(text,type='ai',save=true){const el=originalBubble(text,type,save);if(save)syncChat();return el};
// Keep AI replies in the selected chat even if Gemini is still processing.
const originalPersistHistory=persistHistory;
persistHistory=function(){originalPersistHistory();syncChat()};
$('chatSelect').onchange=e=>switchChat(e.target.value);
$('newChat').onclick=()=>{syncChat();const name=prompt('Название нового чата','Новый чат');if(name===null)return;const id='chat_'+Date.now();chats.push({id,name:name.trim().slice(0,45)||'Новый чат',items:[]});activeChat=id;history=[];$('messages').replaceChildren();drawChats();saveChats();localStorage.setItem('naurok_active_chat',id)};
$('deleteChat').onclick=()=>{if(chats.length===1){alert('Нужен хотя бы один чат');return}if(!confirm('Удалить этот чат?'))return;chats=chats.filter(c=>c.id!==activeChat);activeChat=chats[0].id;history=[...chats[0].items];$('messages').replaceChildren();history.forEach(m=>bubble(m.text,m.type,false));drawChats();saveChats()};
// Switch to saved chat history on startup.
history=[...active().items];$('messages').replaceChildren();history.forEach(m=>bubble(m.text,m.type,false));if(!history.length)bubble('Новый чат готов. Выбери инструмент или напиши вопрос.','ai',false);drawChats();
const defaultTheme=localStorage.getItem('naurok_theme')||'dark';
function theme(t){document.body.classList.remove('theme-dark','theme-light','theme-ocean');document.body.classList.add('theme-'+t);localStorage.setItem('naurok_theme',t)}
$('themeSelect').value=defaultTheme;theme(defaultTheme);$('themeSelect').onchange=e=>theme(e.target.value);
function draft(text){page('chat');$('question').value=text;$('question').focus()}
$('autoMode').onclick=()=>draft('Определи предмет и тип задачи, затем объясни решение по шагам: ');
$('mathMode').onclick=()=>draft('Реши математическую задачу с проверкой вычислений и объяснением: ');
$('translateMode').onclick=()=>draft('Переведи следующий текст на украинский и объясни сложные выражения: ');
$('openPhoto').onclick=()=>{page('chat');$('imageInput').click()};
$('documentInput').onchange=async e=>{const f=e.target.files?.[0];if(!f)return;if(f.size>150000){alert('Документ слишком большой (макс. 150 КБ)');return}try{const text=await f.text();draft('Помоги разобраться в документе «'+f.name+'». Кратко перескажи и выдели главное:\n\n'+text.slice(0,12000))}catch(err){alert('Не удалось прочитать документ: '+err.message)}};
const TASK_KEY='naurok_tasks_v4';let tasks=readJSON(TASK_KEY,[]);if(!Array.isArray(tasks))tasks=[];
function renderTasks(){const list=$('taskList');list.replaceChildren();tasks.sort((a,b)=>a.when.localeCompare(b.when));for(const task of tasks){const row=document.createElement('div');row.className='task'+(task.done?' done':'');const cb=document.createElement('input');cb.type='checkbox';cb.checked=!!task.done;cb.onchange=()=>{task.done=cb.checked;saveTasks()};const label=document.createElement('span');label.textContent=task.text+' · '+(task.when?new Date(task.when).toLocaleString('ru-RU'):'Без даты');const del=document.createElement('button');del.textContent='✕';del.onclick=()=>{tasks=tasks.filter(t=>t.id!==task.id);saveTasks()};row.append(cb,label,del);list.append(row)}}
function saveTasks(){localStorage.setItem(TASK_KEY,JSON.stringify(tasks.slice(-200)));renderTasks()}
$('addTask').onclick=()=>{const text=$('taskText').value.trim();if(!text)return;tasks.push({id:Date.now(),text:text.slice(0,180),when:$('taskDate').value||'',done:false});$('taskText').value='';saveTasks()};renderTasks();
function nativeCall(method){if(window.AndroidApp&&typeof window.AndroidApp[method]==='function'){window.AndroidApp[method]()}else alert('Для системной кнопки открой Android APK, а не TrebEdit.')} 
$('startOverlay').onclick=()=>nativeCall('startOverlay');$('stopOverlay').onclick=()=>nativeCall('stopOverlay');
