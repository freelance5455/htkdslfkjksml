const $ = (s, root=document) => root.querySelector(s);
const $$ = (s, root=document) => [...root.querySelectorAll(s)];
$('#year').textContent = new Date().getFullYear();

const nav = $('#nav'), menuToggle = $('#menuToggle');
menuToggle.addEventListener('click', () => {
  const opened = nav.classList.toggle('open');
  menuToggle.setAttribute('aria-expanded', String(opened));
  menuToggle.setAttribute('aria-label', opened ? 'Close navigation' : 'Open navigation');
});
$$('.nav a').forEach(a => a.addEventListener('click', () => {
  nav.classList.remove('open'); menuToggle.setAttribute('aria-expanded','false');
}));

let toastTimer;
function toast(message) {
  const el = $('#toast'); el.textContent = message; el.classList.add('show');
  clearTimeout(toastTimer); toastTimer = setTimeout(() => el.classList.remove('show'), 3000);
}
$$('[data-game]').forEach(button => button.addEventListener('click', () => {
  $('#gameNotice').textContent = `${button.dataset.game} selected — add your game links or detail pages here.`;
  toast(`${button.dataset.game} selected`);
}));
$('#viewGames').addEventListener('click', e => {
  e.preventDefault();
  $('#gameGrid').classList.toggle('expanded');
  toast('You are viewing the featured game collection.');
});
$$('[data-demo]').forEach(el => el.addEventListener('click', e => {
  if (el.tagName === 'A') e.preventDefault();
  toast(`${el.dataset.demo}: connect your stream/news source to show live content.`);
}));
$('#searchBtn').addEventListener('click', () => {
  const term = prompt('Search games on Yousuf4tix:');
  if (!term) return;
  const matches = $$('.game-card').filter(card => card.textContent.toLowerCase().includes(term.toLowerCase()));
  $$('.game-card').forEach(card => card.hidden = false);
  if (matches.length) {
    $$('.game-card').forEach(card => card.hidden = !matches.includes(card));
    toast(`${matches.length} matching game${matches.length===1?'':'s'} found.`);
  } else {
    toast(`No featured games found for “${term}”.`);
  }
});
const modal = $('#siteModal');
$$('[data-modal]').forEach(button => button.addEventListener('click', () => {
  const mode = button.dataset.modal;
  const titles = {login:'Welcome back, gamer!', signup:'Create your gamer account', community:'Join the Yousuf4tix community'};
  const descriptions = {
    login:'A real login needs a secure authentication service. This demo does not submit your details.',
    signup:'Sign-up is a visual demo for now. Connect an authentication provider to create real accounts.',
    community:'Add your Discord, WhatsApp, or other community invite link to make this button live.'
  };
  $('#modalTitle').textContent = titles[mode];
  $('#modalText').textContent = descriptions[mode];
  $('#emailLabel').hidden = mode === 'community';
  $('#passwordLabel').hidden = mode === 'community';
  $('#modalSubmit').textContent = mode === 'community' ? 'Got it' : 'Continue';
  modal.showModal();
}));
$('.modal-card').addEventListener('submit', e => {
  e.preventDefault();
  modal.close();
  toast('Demo only — connect a backend to enable this feature.');
});
