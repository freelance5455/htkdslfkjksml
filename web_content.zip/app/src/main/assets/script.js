
const canvas = document.getElementById("game");
const ctx = canvas.getContext("2d");

const scoreElement = document.getElementById("score");
const coinsElement = document.getElementById("coins");
const startScreen = document.getElementById("start-screen");
const gameOverScreen = document.getElementById("game-over");

let W = 0;
let H = 0;
let dpr = 1;
let groundY = 0;
let lastTime = 0;
let animationId = 0;

const game = {
  running: false,
  started: false,
  over: false,
  camera: 0,
  distance: 0,
  score: 0,
  coins: 0,
  speed: 190,
  gravity: 1500,
  jumpPower: 570,
  player: null,
  platforms: [],
  coinsList: [],
  hazards: [],
  clouds: [],
  nextX: 0
};

function resize() {
  const oldH = H;

  W = window.innerWidth;
  H = window.innerHeight;
  dpr = Math.min(window.devicePixelRatio || 1, 2);

  canvas.width = Math.round(W * dpr);
  canvas.height = Math.round(H * dpr);
  canvas.style.width = W + "px";
  canvas.style.height = H + "px";

  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

  groundY = H * 0.78;

  if (game.player && !game.running) {
    game.player.y += groundY - oldH * 0.78;
  }
}

window.addEventListener("resize", resize);
resize();

function random(min, max) {
  return min + Math.random() * (max - min);
}

function makeClouds() {
  game.clouds = [];

  for (let i = 0; i < 10; i++) {
    game.clouds.push({
      x: random(0, W + 100),
      y: random(45, H * 0.42),
      size: random(20, 43)
    });
  }
}

function resetGame() {
  game.camera = 0;
  game.distance = 0;
  game.score = 0;
  game.coins = 0;
  game.speed = 190;
  game.over = false;

  game.player = {
    x: 100,
    y: groundY - 48,
    w: 36,
    h: 48,
    vy: 0,
    grounded: true,
    invincible: false
  };

  game.platforms = [
    {
      x: -100,
      y: groundY,
      w: 650,
      h: H - groundY + 100
    }
  ];

  game.coinsList = [];
  game.hazards = [];
  game.nextX = 550;

  makeClouds();
  generateWorld();

  scoreElement.textContent = "0";
  coinsElement.textContent = "0";
}

function generateWorld() {
  while (game.nextX < game.camera + W + 900) {
    const gap = random(65, 125);
    const width = random(155, 260);
    const previous = game.platforms[game.platforms.length - 1];

    const heightChange = random(-65, 65);
    let y = previous.y + heightChange;

    y = Math.max(H * 0.42, Math.min(groundY + 25, y));

    const x = previous.x + previous.w + gap;

    const platform = {
      x,
      y,
      w: width,
      h: H - y + 120
    };

    game.platforms.push(platform);

    // العملات فوق المنصة
    const coinCount = Math.floor(random(3, 6));

    for (let i = 0; i < coinCount; i++) {
      game.coinsList.push({
        x: x + 30 + i * ((width - 60) / Math.max(1, coinCount - 1)),
        y: y - random(48, 85),
        r: 10,
        collected: false
      });
    }

    // عقبة تظهر أحيانًا فوق إحدى المنصات
    if (Math.random() < 0.32 && width > 180) {
      game.hazards.push({
        x: x + width * 0.65,
        y: y - 27,
        w: 25,
        h: 27
      });
    }

    game.nextX = x + width;
  }
}

function jump() {
  if (!game.running || game.over) return;

  if (game.player.grounded) {
    game.player.vy = -game.jumpPower;
    game.player.grounded = false;
  }
}

function startGame() {
  cancelAnimationFrame(animationId);

  resetGame();

  game.started = true;
  game.running = true;
  game.over = false;

  startScreen.classList.add("hidden");
  gameOverScreen.classList.add("hidden");

  lastTime = performance.now();
  animationId = requestAnimationFrame(loop);
}

function endGame() {
  if (game.over) return;

  game.over = true;
  game.running = false;

  document.getElementById("final-score").textContent =
    game.score;

  document.getElementById("final-coins").textContent =
    game.coins;

  gameOverScreen.classList.remove("hidden");
}

function overlaps(a, b) {
  return (
    a.x < b.x + b.w &&
    a.x + a.w > b.x &&
    a.y < b.y + b.h &&
    a.y + a.h > b.y
  );
}

function update(dt) {
  if (!game.running) return;

  const p = game.player;

  game.speed = Math.min(270, 190 + game.distance * 0.015);

  // تحريك العالم نحو اليسار
  game.distance += game.speed * dt;
  game.camera += game.speed * dt;

  // الشخصية تتحرك للأمام تلقائيًا
  p.x += game.speed * dt;

  // القفز والجاذبية
  const previousBottom = p.y + p.h;

  p.vy += game.gravity * dt;
  p.y += p.vy * dt;
  p.grounded = false;

  // الهبوط على المنصات من الأعلى فقط
  for (const platform of game.platforms) {
    const horizontal =
      p.x + p.w > platform.x &&
      p.x < platform.x + platform.w;

    const currentBottom = p.y + p.h;

    if (
      horizontal &&
      p.vy >= 0 &&
      previousBottom <= platform.y + 5 &&
      currentBottom >= platform.y &&
      p.y < platform.y
    ) {
      p.y = platform.y - p.h;
      p.vy = 0;
      p.grounded = true;
    }
  }

  // جمع العملات
  const playerBox = {
    x: p.x + 4,
    y: p.y + 4,
    w: p.w - 8,
    h: p.h - 8
  };

  for (const coin of game.coinsList) {
    if (coin.collected) continue;

    const coinBox = {
      x: coin.x - coin.r,
      y: coin.y - coin.r,
      w: coin.r * 2,
      h: coin.r * 2
    };

    if (overlaps(playerBox, coinBox)) {
      coin.collected = true;
      game.coins++;
      game.score += 10;
      coinsElement.textContent = game.coins;
      scoreElement.textContent = game.score;
    }
  }

  // الاصطدام بالعقبات
  for (const hazard of game.hazards) {
    if (overlaps(playerBox, hazard)) {
      endGame();
      return;
    }
  }

  // نقاط المسافة
  game.score = Math.max(
    game.score,
    Math.floor(game.distance / 20) * 5
  );

  scoreElement.textContent = game.score;

  // السقوط في الفراغ
  if (p.y > H + 100) {
    endGame();
    return;
  }

  // إنشاء منصات جديدة أمام اللاعب
  generateWorld();

  // حذف العناصر القديمة لتقليل استهلاك الذاكرة
  game.platforms = game.platforms.filter(
    item => item.x + item.w > game.camera - 150
  );

  game.coinsList = game.coinsList.filter(
    item => item.x > game.camera - 100 && !item.collected
  );

  game.hazards = game.hazards.filter(
    item => item.x + item.w > game.camera - 100
  );
}

function drawBackground() {
  const sky = ctx.createLinearGradient(0, 0, 0, H);

  sky.addColorStop(0, "#70d6ff");
  sky.addColorStop(1, "#d8f8ff");

  ctx.fillStyle = sky;
  ctx.fillRect(0, 0, W, H);

  // الشمس
  ctx.fillStyle = "#ffe66d";
  ctx.beginPath();
  ctx.arc(W - 65, 100, 35, 0, Math.PI * 2);
  ctx.fill();

  // الغيوم
  for (const cloud of game.clouds) {
    let x = (cloud.x - game.camera * 0.15) % (W + 120);

    if (x < -100) x += W + 120;

    const y = cloud.y;
    const s = cloud.size;

    ctx.fillStyle = "#ffffffdd";
    ctx.beginPath();
    ctx.arc(x, y, s * 0.55, 0, Math.PI * 2);
    ctx.arc(x + s * 0.55, y - s * 0.2, s * 0.7, 0, Math.PI * 2);
    ctx.arc(x + s * 1.1, y, s * 0.5, 0, Math.PI * 2);
    ctx.fill();
  }

  // تلال بعيدة
  ctx.fillStyle = "#a7e8a0";

  for (let i = 0; i < 7; i++) {
    const baseX = i * 180 - (game.camera * 0.25 % 180);

    ctx.beginPath();
    ctx.ellipse(
      baseX + 90,
      groundY + 20,
      125,
      85,
      0,
      Math.PI,
      Math.PI * 2
    );
    ctx.fill();
  }
}

function drawPlatform(platform) {
  const x = platform.x - game.camera;

  if (x > W || x + platform.w < 0) return;

  // التراب
  ctx.fillStyle = "#b87545";
  ctx.fillRect(x, platform.y, platform.w, platform.h);

  // العشب
  ctx.fillStyle = "#42c95b";
  ctx.fillRect(x, platform.y, platform.w, 12);

  ctx.fillStyle = "#239c47";
  ctx.fillRect(x, platform.y + 10, platform.w, 4);

  // بقع صغيرة كرتونية
  ctx.fillStyle = "#d99b61";

  for (let i = 18; i < platform.w - 10; i += 48) {
    ctx.fillRect(x + i, platform.y + 29, 9, 5);
  }
}

function drawCoin(coin, time) {
  if (coin.collected) return;

  const x = coin.x - game.camera;
  const y = coin.y + Math.sin(time / 180 + coin.x) * 3;

  if (x < -30 || x > W + 30) return;

  ctx.save();
  ctx.translate(x, y);

  ctx.fillStyle = "#ffb703";
  ctx.beginPath();
  ctx.ellipse(
    0, 0, 9, 12,
    0, 0, Math.PI * 2
  );
  ctx.fill();

  ctx.strokeStyle = "#fff0a3";
  ctx.lineWidth = 3;
  ctx.stroke();

  ctx.fillStyle = "#fff6bd";
  ctx.fillRect(-2, -6, 3, 12);

  ctx.restore();
}

function drawHazard(hazard) {
  const x = hazard.x - game.camera;

  if (x > W || x + hazard.w < 0) return;

  // شوكة حمراء
  ctx.fillStyle = "#f04f55";
  ctx.beginPath();
  ctx.moveTo(x, hazard.y + hazard.h);
  ctx.lineTo(x + hazard.w / 2, hazard.y);
  ctx.lineTo(x + hazard.w, hazard.y + hazard.h);
  ctx.closePath();
  ctx.fill();

  ctx.strokeStyle = "#b82f3b";
  ctx.lineWidth = 2;
  ctx.stroke();
}

function drawPlayer(time) {
  const p = game.player;

  // إبقاء الشخصية في موضع ثابت نسبيًا على الشاشة
  const screenX = p.x - game.camera;

  const bounce = p.grounded
    ? Math.sin(time / 90) * 1.5
    : 0;

  const x = screenX;
  const y = p.y + bounce;

  ctx.save();

  // الذيل
  ctx.fillStyle = "#f28c38";
  ctx.beginPath();
  ctx.ellipse(
    x - 2,
    y + 32,
    12,
    7,
    -0.35,
    0,
    Math.PI * 2
  );
  ctx.fill();

  // الجسم
  ctx.fillStyle = "#f28c38";
  ctx.beginPath();
  ctx.roundRect(x + 4, y + 19, 29, 27, 9);
  ctx.fill();

  // البطن
  ctx.fillStyle = "#fff0cf";
  ctx.beginPath();
  ctx.ellipse(x + 20, y + 34, 9, 11, 0, 0, Math.PI * 2);
  ctx.fill();

  // الرأس
  ctx.fillStyle = "#ffad4d";
  ctx.beginPath();
  ctx.arc(x + 20, y + 15, 16, 0, Math.PI * 2);
  ctx.fill();

  // الأذنان
  ctx.fillStyle = "#f28c38";

  ctx.beginPath();
  ctx.moveTo(x + 7, y + 7);
  ctx.lineTo(x + 8, y - 5);
  ctx.lineTo(x + 16, y + 3);
  ctx.fill();

  ctx.beginPath();
  ctx.moveTo(x + 23, y + 3);
  ctx.lineTo(x + 32, y - 5);
  ctx.lineTo(x + 33, y + 9);
  ctx.fill();

  // العين
  ctx.fillStyle = "#263238";
  ctx.beginPath();
  ctx.arc(x + 25, y + 13, 2.3, 0, Math.PI * 2);
  ctx.fill();

  // الخطم
  ctx.fillStyle = "#fff0cf";
  ctx.beginPath();
  ctx.ellipse(x + 31, y + 19, 6, 4, 0, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = "#263238";
  ctx.beginPath();
  ctx.arc(x + 35, y + 18, 1.8, 0, Math.PI * 2);
  ctx.fill();

  // القدمين
  ctx.fillStyle = "#a94d32";

  ctx.fillRect(
    x + 7,
    y + 43 + (p.grounded ? Math.abs(Math.sin(time / 90)) * 3 : 0),
    10, 5
  );

  ctx.fillRect(
    x + 23,
    y + 43 + (p.grounded ? Math.abs(Math.sin(time / 90 + 1)) * 3 : 0),
    10, 5
  );

  ctx.restore();
}

function draw(time) {
  drawBackground();

  // رسم العالم في إحداثياته الأصلية مع تحريك الكاميرا
  for (const platform of game.platforms) {
    drawPlatform(platform);
  }

  for (const coin of game.coinsList) {
    drawCoin(coin, time);
  }

  for (const hazard of game.hazards) {
    drawHazard(hazard);
  }

  if (game.player) {
    drawPlayer(time);
  }
}

function loop(time) {
  if (!game.running) return;

  // تقليل القفزات الكبيرة في الوقت بعد توقف المتصفح
  const dt = Math.min((time - lastTime) / 1000, 0.033);
  lastTime = time;

  update(dt);
  draw(time);

  if (game.running) {
    animationId = requestAnimationFrame(loop);
  }
}

// الضغط على مساحة اللعب للقفز
canvas.addEventListener("pointerdown", event => {
  event.preventDefault();
  jump();
});

document.getElementById("start-btn").addEventListener("click", startGame);
document.getElementById("restart-btn").addEventListener("click", startGame);

// عرض خلفية اللعبة قبل البدء
resetGame();
draw(0);
