const matches = [
 {team1:"ريال مدريد",team2:"برشلونة",time:"20:00",league:"مباراة ودية",status:"today"},
 {team1:"المغرب",team2:"مصر",time:"22:00",league:"مباراة دولية",status:"today"},
 {team1:"مانشستر سيتي",team2:"ليفربول",time:"18:30",league:"الدوري",status:"live"}
];

const list = document.getElementById("matches");
const empty = document.getElementById("empty");

function render(filter="all"){
  list.innerHTML="";
  const data = matches.filter(m => filter==="all" || m.status===filter);
  empty.hidden = data.length !== 0;

  data.forEach(m=>{
    const card=document.createElement("div");
    card.className="match";
    card.innerHTML=`
      <div class="league">🏆 ${m.league}</div>
      <div class="teams">
        <div class="team">⚽ ${m.team1}</div>
        <div class="time">
          <strong>${m.time}</strong>
          <span class="badge">${m.status==="live" ? "🔴 مباشر" : "لم تبدأ"}</span>
        </div>
        <div class="team">⚽ ${m.team2}</div>
      </div>
      <button class="watch" onclick="watchMatch('${m.team1} - ${m.team2}')">📺 المشاهدة الرسمية</button>
    `;
    list.appendChild(card);
  });
}

function filterMatches(filter, button){
  document.querySelectorAll(".tab").forEach(b=>b.classList.remove("active"));
  button.classList.add("active");
  render(filter);
}

function watchMatch(name){
  alert("المشاهدة: " + name + "\n\nأضف هنا رابط البث الرسمي والمرخّص عندما يكون متوفراً.");
}

render();
