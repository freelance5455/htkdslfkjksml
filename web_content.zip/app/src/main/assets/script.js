// ===== EDIT THESE 4 VALUES BEFORE DELIVERY =====
const CONFIG = {
  phone: "+919424206014",
  whatsapp: "919424206014",
  instagram: "https://www.instagram.com/", // replace with the shop's real Instagram URL
  maps: "https://www.google.com/maps/search/?api=1&query=Jai+Shree+Kapda+Dukan+Saraipali+Chhattisgarh"
};

document.querySelectorAll("[data-phone]").forEach(el => {
  el.textContent = CONFIG.phone.replace("+91","0");
  el.href = "tel:" + CONFIG.phone;
});
document.querySelectorAll("[data-call]").forEach(el => el.href = "tel:" + CONFIG.phone);
document.querySelectorAll("[data-whatsapp]").forEach(el => {
  el.href = "https://wa.me/" + CONFIG.whatsapp + "?text=" + encodeURIComponent("Namaste Jai Shree Kapda Dukan, mujhe aapke collection ke baare mein jaankari chahiye.");
  el.target = "_blank";
  el.rel = "noopener";
});
document.querySelectorAll("[data-instagram]").forEach(el => el.href = CONFIG.instagram);
document.querySelectorAll("[data-maps]").forEach(el => el.href = CONFIG.maps);
document.getElementById("year").textContent = new Date().getFullYear();

const header = document.querySelector(".site-header");
const menu = document.querySelector(".menu-btn");
menu.addEventListener("click", () => {
  const open = header.classList.toggle("open");
  menu.setAttribute("aria-expanded", open);
});
document.querySelectorAll(".nav a").forEach(a => a.addEventListener("click", () => header.classList.remove("open")));

const observer = new IntersectionObserver(entries => {
  entries.forEach(e => { if (e.isIntersecting) e.target.classList.add("visible"); });
}, {threshold:.12});
document.querySelectorAll(".reveal").forEach(el => observer.observe(el));

const topBtn = document.querySelector(".top");
window.addEventListener("scroll", () => topBtn.style.display = window.scrollY > 600 ? "block" : "none");
topBtn.addEventListener("click", () => window.scrollTo({top:0,behavior:"smooth"}));
