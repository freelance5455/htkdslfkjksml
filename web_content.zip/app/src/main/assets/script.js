const files = {
    "HAZA19": "haza19.jpg",
    "HAZE19": "haza19.jpg",
    "DINORIDER": "dinorider.jpg",
    "DINO RIDER": "dinorider.jpg"
};

const codeInput = document.getElementById("code");
const error = document.getElementById("error");

document.getElementById("showButton").onclick = function () {
    if (codeInput.type === "password") {
        codeInput.type = "text";
        this.innerText = "Hide";
    } else {
        codeInput.type = "password";
        this.innerText = "Show";
    }
};

function checkCode() {
    // Ignore spaces and capitalization.
    const enteredCode = codeInput.value.trim().toUpperCase().replace(/\s+/g, "");

    if (files[enteredCode]) {
        error.innerText = "";

        if (window.Android && typeof Android.openImage === "function") {
            Android.openImage(files[enteredCode], enteredCode);
        } else {
            window.open("files/" + files[enteredCode], "_blank");
        }
    } else {
        error.innerText = "Invalid access code.";
    }
}

document.getElementById("accessButton").onclick = checkCode;

codeInput.addEventListener("keydown", function (event) {
    if (event.key === "Enter") {
        checkCode();
    }
});
