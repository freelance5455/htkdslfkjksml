/**
 * ইসলামিক জমা-খরচ (Islamic Jama-Khoroch)
 * Vanilla JavaScript Engine
 * 100% Offline, LocalStorage Persistence, Mobile-First
 */

(function () {
    'use strict';

    // Storage Keys
    const STORAGE_KEY_TRANSACTIONS = 'islamic_transactions_v1';
    const STORAGE_KEY_PROFILE = 'islamic_profile_photo';

    // State Variables
    let transactions = [];
    let currentFilter = 'all'; // 'all', 'income', 'expense'
    let searchQuery = '';
    let pendingDeleteId = null;
    let activeModal = null;

    // Bengali Digits & Months Map
    const BENGALI_DIGITS = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
    const BENGALI_MONTHS = [
        'জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন',
        'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'
    ];

    // DOM Elements Cache
    const el = {
        profileImg: document.getElementById('profileImg'),
        profileAvatarBtn: document.getElementById('profileAvatarBtn'),
        profileFileInput: document.getElementById('profileFileInput'),
        importFileInput: document.getElementById('importFileInput'),
        exportBtn: document.getElementById('exportBtn'),
        importBtn: document.getElementById('importBtn'),
        resetAllBtn: document.getElementById('resetAllBtn'),
        todayDateDisplay: document.getElementById('todayDateDisplay'),

        // Dashboard Displays
        totalIncomeDisplay: document.getElementById('totalIncomeDisplay'),
        totalExpenseDisplay: document.getElementById('totalExpenseDisplay'),
        currentBalanceDisplay: document.getElementById('currentBalanceDisplay'),
        balanceStatusText: document.getElementById('balanceStatusText'),
        totalCountDisplay: document.getElementById('totalCountDisplay'),

        // Action Section
        openAddModalBtn: document.getElementById('openAddModalBtn'),

        // Search & Filter
        searchInput: document.getElementById('searchInput'),
        searchClearBtn: document.getElementById('searchClearBtn'),
        filterPills: document.querySelectorAll('.filter-pill'),

        // Transactions List
        recordCounter: document.getElementById('recordCounter'),
        transactionsList: document.getElementById('transactionsList'),
        emptyState: document.getElementById('emptyState'),
        emptyStateTitle: document.getElementById('emptyStateTitle'),
        emptyStateDesc: document.getElementById('emptyStateDesc'),

        // Modals
        transactionModal: document.getElementById('transactionModal'),
        modalHeading: document.getElementById('modalHeading'),
        transactionForm: document.getElementById('transactionForm'),
        editTransactionId: document.getElementById('editTransactionId'),
        typeIncomeBtn: document.getElementById('typeIncomeBtn'),
        typeExpenseBtn: document.getElementById('typeExpenseBtn'),
        transactionType: document.getElementById('transactionType'),
        transactionAmount: document.getElementById('transactionAmount'),
        transactionDate: document.getElementById('transactionDate'),
        transactionNote: document.getElementById('transactionNote'),
        amountError: document.getElementById('amountError'),
        dateError: document.getElementById('dateError'),
        noteError: document.getElementById('noteError'),
        closeTransactionModalBtn: document.getElementById('closeTransactionModalBtn'),
        cancelTransactionModalBtn: document.getElementById('cancelTransactionModalBtn'),
        quickChips: document.querySelectorAll('.quick-chip'),
        categoryTags: document.querySelectorAll('.category-tag'),

        // Delete Modal
        deleteModal: document.getElementById('deleteModal'),
        deletePreviewBox: document.getElementById('deletePreviewBox'),
        cancelDeleteBtn: document.getElementById('cancelDeleteBtn'),
        confirmDeleteBtn: document.getElementById('confirmDeleteBtn'),

        // Reset Modal
        resetModal: document.getElementById('resetModal'),
        cancelResetBtn: document.getElementById('cancelResetBtn'),
        confirmResetBtn: document.getElementById('confirmResetBtn'),

        // Profile Modal
        profileModal: document.getElementById('profileModal'),
        changePhotoBtn: document.getElementById('changePhotoBtn'),
        removePhotoBtn: document.getElementById('removePhotoBtn'),
        closeProfileModalBtn: document.getElementById('closeProfileModalBtn'),

        // Toast
        toastNotification: document.getElementById('toastNotification'),
        toastMessage: document.getElementById('toastMessage')
    };

    /* ===================================================
       Number & Date Formatting Utilities
       =================================================== */

    /**
     * Converts English numbers/strings to Bengali digits
     */
    function toBengaliNumber(number) {
        if (number === null || number === undefined || isNaN(number)) {
            return '০';
        }
        const numStr = number.toString();
        return numStr.replace(/\d/g, d => BENGALI_DIGITS[parseInt(d, 10)]);
    }

    /**
     * Formats currency with Taka symbol and 2 decimal points
     */
    function formatCurrency(amount) {
        const isNegative = amount < 0;
        const absVal = Math.abs(amount);
        const parts = absVal.toFixed(2).split('.');
        
        // Add thousands comma in western format first
        let integerPart = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',');
        let decimalPart = parts[1];

        // Convert to Bengali
        let bengaliFormatted = toBengaliNumber(integerPart) + '.' + toBengaliNumber(decimalPart);
        return (isNegative ? '- ৳ ' : '৳ ') + bengaliFormatted;
    }

    /**
     * Returns today's date in YYYY-MM-DD format
     */
    function getTodayDateString() {
        const now = new Date();
        const year = now.getFullYear();
        const month = String(now.getMonth() + 1).padStart(2, '0');
        const day = String(now.getDate()).padStart(2, '0');
        return `${year}-${month}-${day}`;
    }

    /**
     * Formats YYYY-MM-DD date into Bengali text (e.g. ১৪ সেপ্টেম্বর, ২০২৬)
     */
    function formatBengaliDate(dateStr) {
        if (!dateStr) return '';
        const parts = dateStr.split('-');
        if (parts.length !== 3) return dateStr;

        const year = parseInt(parts[0], 10);
        const monthIndex = parseInt(parts[1], 10) - 1;
        const day = parseInt(parts[2], 10);

        const monthName = BENGALI_MONTHS[monthIndex] || '';
        return `${toBengaliNumber(day)} ${monthName}, ${toBengaliNumber(year)}`;
    }

    /**
     * Set Header Bengali Date display
     */
    function initHeaderDate() {
        if (el.todayDateDisplay) {
            el.todayDateDisplay.textContent = 'আজ: ' + formatBengaliDate(getTodayDateString());
        }
    }

    /* ===================================================
       Toast Notification System
       =================================================== */
    let toastTimeout = null;
    function showToast(message) {
        if (!el.toastNotification || !el.toastMessage) return;
        el.toastMessage.textContent = message;
        el.toastNotification.classList.add('show');

        if (toastTimeout) clearTimeout(toastTimeout);
        toastTimeout = setTimeout(() => {
            el.toastNotification.classList.remove('show');
        }, 3200);
    }

    /* ===================================================
       Modal System with Android Back Button & History
       =================================================== */
    function openModal(modalElement) {
        if (!modalElement) return;
        modalElement.classList.add('active');
        modalElement.setAttribute('aria-hidden', 'false');
        activeModal = modalElement;

        // Push state for native Back-button closure support
        try {
            window.history.pushState({ modalOpen: true, modalId: modalElement.id }, '');
        } catch (e) {
            // Ignore if not supported in some web environments
        }
    }

    function closeModal(modalElement) {
        const target = modalElement || activeModal;
        if (!target) return;
        target.classList.remove('active');
        target.setAttribute('aria-hidden', 'true');
        if (activeModal === target) {
            activeModal = null;
        }
    }

    function closeActiveModal() {
        if (activeModal) {
            closeModal(activeModal);
            return true;
        }
        return false;
    }

    // Expose back button handler for Android WebView container
    window.handleAndroidBack = function () {
        if (activeModal) {
            closeActiveModal();
            return true;
        }
        return false;
    };

    // Listen to browser popstate (Back button in browser/PWA)
    window.addEventListener('popstate', function () {
        if (activeModal) {
            activeModal.classList.remove('active');
            activeModal.setAttribute('aria-hidden', 'true');
            activeModal = null;
        }
    });

    // Close modal on backdrop tap
    document.querySelectorAll('.modal-overlay').forEach(modal => {
        modal.addEventListener('click', function (e) {
            if (e.target === modal) {
                closeModal(modal);
            }
        });
    });

    /* ===================================================
       Local Storage Handlers
       =================================================== */
    function loadTransactionsFromStorage() {
        try {
            const raw = localStorage.getItem(STORAGE_KEY_TRANSACTIONS);
            if (raw) {
                const parsed = JSON.parse(raw);
                if (Array.isArray(parsed)) {
                    transactions = parsed;
                } else {
                    transactions = [];
                }
            } else {
                // If brand new, initialize with empty or sample if requested
                transactions = [];
            }
        } catch (e) {
            console.error('Error loading transactions from localStorage', e);
            transactions = [];
        }
    }

    function saveTransactionsToStorage() {
        try {
            localStorage.setItem(STORAGE_KEY_TRANSACTIONS, JSON.stringify(transactions));
        } catch (e) {
            console.error('Error saving transactions to localStorage', e);
            showToast('মেমোরিতে সেভ করতে সমস্যা হয়েছে!');
        }
    }

    /* ===================================================
       Profile Photo Management
       =================================================== */
    function loadProfilePhoto() {
        try {
            const photo = localStorage.getItem(STORAGE_KEY_PROFILE);
            if (photo && photo.startsWith('data:image')) {
                el.profileImg.src = photo;
            } else {
                el.profileImg.src = 'assets/default-profile.png';
            }
        } catch (e) {
            el.profileImg.src = 'assets/default-profile.png';
        }
    }

    function handleProfileFileUpload(file) {
        if (!file) return;
        if (!file.type.startsWith('image/')) {
            showToast('দয়া করে সঠিক ছবির ফাইল নির্বাচন করুন!');
            return;
        }

        const reader = new FileReader();
        reader.onload = function (e) {
            const img = new Image();
            img.onload = function () {
                // Compress image to sensible mobile avatar resolution (300x300)
                const canvas = document.createElement('canvas');
                const maxSize = 320;
                let width = img.width;
                let height = img.height;

                if (width > height) {
                    if (width > maxSize) {
                        height = Math.round((height * maxSize) / width);
                        width = maxSize;
                    }
                } else {
                    if (height > maxSize) {
                        width = Math.round((width * maxSize) / height);
                        height = maxSize;
                    }
                }

                canvas.width = width;
                canvas.height = height;
                const ctx = canvas.getContext('2d');
                ctx.drawImage(img, 0, 0, width, height);

                const compressedDataUrl = canvas.toDataURL('image/jpeg', 0.85);

                try {
                    localStorage.setItem(STORAGE_KEY_PROFILE, compressedDataUrl);
                    el.profileImg.src = compressedDataUrl;
                    showToast('প্রোফাইল ছবি সফলভাবে সংরক্ষণ করা হয়েছে');
                } catch (err) {
                    console.error(err);
                    showToast('ছবির সাইজ বেশি বড়, অনুগ্রহ করে ছোট ছবি দিন');
                }
                closeModal(el.profileModal);
            };
            img.src = e.target.result;
        };
        reader.readAsDataURL(file);
    }

    function removeProfilePhoto() {
        localStorage.removeItem(STORAGE_KEY_PROFILE);
        el.profileImg.src = 'assets/default-profile.png';
        closeModal(el.profileModal);
        showToast('প্রোফাইল ছবি সরানো হয়েছে');
    }

    /* ===================================================
       Dashboard & Calculations
       =================================================== */
    function updateDashboard() {
        let totalIncome = 0;
        let totalExpense = 0;

        transactions.forEach(t => {
            const amt = parseFloat(t.amount) || 0;
            if (t.type === 'income') {
                totalIncome += amt;
            } else if (t.type === 'expense') {
                totalExpense += amt;
            }
        });

        const currentBalance = totalIncome - totalExpense;
        const totalCount = transactions.length;

        // Render Totals
        el.totalIncomeDisplay.textContent = formatCurrency(totalIncome);
        el.totalExpenseDisplay.textContent = formatCurrency(totalExpense);
        el.currentBalanceDisplay.textContent = formatCurrency(currentBalance);
        el.totalCountDisplay.textContent = toBengaliNumber(totalCount) + ' টি';

        // Balance Color Logic
        if (currentBalance < 0) {
            el.currentBalanceDisplay.className = 'card-amount negative';
            el.balanceStatusText.textContent = 'খরচ জমার চেয়ে বেশি (ঘাটতি)';
            el.balanceStatusText.style.color = 'var(--color-expense)';
        } else if (currentBalance > 0) {
            el.currentBalanceDisplay.className = 'card-amount positive';
            el.balanceStatusText.textContent = 'উদ্বৃত্ত ব্যালেন্স';
            el.balanceStatusText.style.color = 'var(--color-income)';
        } else {
            el.currentBalanceDisplay.className = 'card-amount';
            el.balanceStatusText.textContent = 'মোট জমা - মোট খরচ';
            el.balanceStatusText.style.color = '#64748b';
        }
    }

    /* ===================================================
       Transactions List Rendering
       =================================================== */
    function renderTransactions() {
        el.transactionsList.innerHTML = '';

        // Filter by Type
        let filtered = transactions.filter(t => {
            if (currentFilter === 'all') return true;
            return t.type === currentFilter;
        });

        // Filter by Search Query
        if (searchQuery.trim() !== '') {
            const q = searchQuery.trim().toLowerCase();
            filtered = filtered.filter(t => {
                const note = (t.note || '').toLowerCase();
                const amount = (t.amount || '').toString();
                const date = (t.date || '');
                return note.includes(q) || amount.includes(q) || date.includes(q);
            });
        }

        // Sort descending by date, then id/time
        filtered.sort((a, b) => {
            if (a.date === b.date) {
                return (b.createdAt || 0) - (a.createdAt || 0);
            }
            return b.date.localeCompare(a.date);
        });

        // Update Record Counter
        el.recordCounter.textContent = toBengaliNumber(filtered.length) + ' টি হিসাব';

        // Check Empty State
        if (filtered.length === 0) {
            el.emptyState.style.display = 'flex';
            if (transactions.length === 0) {
                el.emptyStateTitle.textContent = 'এখনও কোনো হিসাব যোগ করা হয়নি';
                el.emptyStateDesc.textContent = 'নতুন জমা বা খরচের হিসাব যোগ করতে উপরের "＋ নতুন হিসাব" বাটনে চাপুন।';
            } else {
                el.emptyStateTitle.textContent = 'কোনো হিসাব খুঁজে পাওয়া যায়নি';
                el.emptyStateDesc.textContent = 'আপনার দেওয়া সার্চ বা ফিল্টারের সাথে মিল রয়েছে এমন কোনো হিসাব নেই।';
            }
            return;
        }

        el.emptyState.style.display = 'none';

        // Render items
        filtered.forEach(tx => {
            const isIncome = tx.type === 'income';
            const card = document.createElement('div');
            card.className = `tx-card ${isIncome ? 'tx-income' : 'tx-expense'}`;
            card.dataset.id = tx.id;

            // Arrow/Category Icon
            const iconSvg = isIncome
                ? `<svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M20 12l-1.41-1.41L13 16.17V4h-2v12.17l-5.58-5.59L4 12l8 8 8-8z"/></svg>`
                : `<svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M4 12l1.41 1.41L11 7.83V20h2V7.83l5.58 5.59L20 12l-8-8-8 8z"/></svg>`;

            const typeLabel = isIncome ? 'জমা' : 'খরচ';
            const typeClass = isIncome ? 'tag-income' : 'tag-expense';
            const amountPrefix = isIncome ? '+ ' : '- ';
            const amountClass = isIncome ? 'amount-income' : 'amount-expense';

            card.innerHTML = `
                <div class="tx-top-row">
                    <div class="tx-details">
                        <div class="tx-icon-badge" aria-hidden="true">${iconSvg}</div>
                        <div class="tx-info">
                            <span class="tx-note">${escapeHtml(tx.note || 'সাধারণ হিসাব')}</span>
                            <div class="tx-meta">
                                <span class="tx-type-tag ${typeClass}">${typeLabel}</span>
                                <span>•</span>
                                <span>${formatBengaliDate(tx.date)}</span>
                            </div>
                        </div>
                    </div>
                    <div class="tx-amount-col">
                        <div class="tx-amount ${amountClass}">
                            ${amountPrefix}${formatCurrency(tx.amount).replace(/^- /, '')}
                        </div>
                    </div>
                </div>
                <div class="tx-action-row">
                    <button class="btn-tx-action btn-tx-edit" data-action="edit" data-id="${tx.id}">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"/>
                        </svg>
                        <span>সম্পাদনা</span>
                    </button>
                    <button class="btn-tx-action btn-tx-delete" data-action="delete" data-id="${tx.id}">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/>
                        </svg>
                        <span>মুছে ফেলুন</span>
                    </button>
                </div>
            `;

            el.transactionsList.appendChild(card);
        });
    }

    function escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    /* ===================================================
       Form & Modal Operations (Add / Edit)
       =================================================== */
    function setFormType(type) {
        el.transactionType.value = type;
        if (type === 'income') {
            el.typeIncomeBtn.className = 'type-btn active-income';
            el.typeExpenseBtn.className = 'type-btn';
        } else {
            el.typeIncomeBtn.className = 'type-btn';
            el.typeExpenseBtn.className = 'type-btn active-expense';
        }
    }

    function resetFormErrors() {
        el.amountError.textContent = '';
        el.dateError.textContent = '';
        el.noteError.textContent = '';
    }

    function openAddModal() {
        el.editTransactionId.value = '';
        el.modalHeading.textContent = 'নতুন হিসাব';
        setFormType('income');
        el.transactionAmount.value = '';
        el.transactionDate.value = getTodayDateString();
        el.transactionNote.value = '';
        resetFormErrors();
        openModal(el.transactionModal);
        setTimeout(() => el.transactionAmount.focus(), 250);
    }

    function openEditModal(id) {
        const tx = transactions.find(t => t.id === id);
        if (!tx) return;

        el.editTransactionId.value = tx.id;
        el.modalHeading.textContent = 'হিসাব সম্পাদনা';
        setFormType(tx.type || 'income');
        el.transactionAmount.value = tx.amount;
        el.transactionDate.value = tx.date || getTodayDateString();
        el.transactionNote.value = tx.note || '';
        resetFormErrors();
        openModal(el.transactionModal);
    }

    function handleFormSubmit(e) {
        e.preventDefault();
        resetFormErrors();

        const type = el.transactionType.value;
        const amountStr = el.transactionAmount.value.trim();
        const date = el.transactionDate.value;
        const note = el.transactionNote.value.trim();
        const editId = el.editTransactionId.value;

        let hasError = false;

        // Validation
        const amount = parseFloat(amountStr);
        if (isNaN(amount) || amount <= 0) {
            el.amountError.textContent = 'সঠিক টাকার পরিমাণ লিখুন (০-এর বেশি হতে হবে)';
            hasError = true;
        }

        if (!date) {
            el.dateError.textContent = 'একটি সঠিক তারিখ নির্বাচন করুন';
            hasError = true;
        }

        if (!note) {
            el.noteError.textContent = 'হিসাবের বিবরণ লিখুন';
            hasError = true;
        }

        if (hasError) return;

        if (editId) {
            // Edit existing
            const index = transactions.findIndex(t => t.id === editId);
            if (index !== -1) {
                transactions[index] = {
                    ...transactions[index],
                    type: type,
                    amount: Math.round(amount * 100) / 100,
                    date: date,
                    note: note
                };
                showToast('হিসাবটি সফলভাবে আপডেট করা হয়েছে');
            }
        } else {
            // Create new
            const newTransaction = {
                id: 'tx_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
                type: type,
                amount: Math.round(amount * 100) / 100,
                date: date,
                note: note,
                createdAt: Date.now()
            };
            transactions.unshift(newTransaction);
            showToast('নতুন হিসাব সফলভাবে সংরক্ষণ করা হয়েছে');
        }

        saveTransactionsToStorage();
        updateDashboard();
        renderTransactions();
        closeModal(el.transactionModal);
    }

    /* ===================================================
       Delete Modal Handling
       =================================================== */
    function openDeleteModal(id) {
        const tx = transactions.find(t => t.id === id);
        if (!tx) return;

        pendingDeleteId = id;
        const isIncome = tx.type === 'income';
        const typeLabel = isIncome ? 'জমা' : 'খরচ';

        el.deletePreviewBox.innerHTML = `
            <strong>${escapeHtml(tx.note)}</strong><br>
            <span style="color: ${isIncome ? 'var(--color-income)' : 'var(--color-expense)'}; font-weight: 700;">
                ${typeLabel}: ${formatCurrency(tx.amount)}
            </span><br>
            <span style="font-size: 0.8rem; color: #64748b;">তারিখ: ${formatBengaliDate(tx.date)}</span>
        `;
        openModal(el.deleteModal);
    }

    function confirmDelete() {
        if (!pendingDeleteId) return;
        transactions = transactions.filter(t => t.id !== pendingDeleteId);
        pendingDeleteId = null;

        saveTransactionsToStorage();
        updateDashboard();
        renderTransactions();
        closeModal(el.deleteModal);
        showToast('হিসাবটি মুছে ফেলা হয়েছে');
    }

    /* ===================================================
       Reset All Transactions
       =================================================== */
    function confirmResetAll() {
        transactions = [];
        saveTransactionsToStorage();
        updateDashboard();
        renderTransactions();
        closeModal(el.resetModal);
        showToast('সকল হিসাব সফলভাবে মুছে ফেলা হয়েছে');
    }

    /* ===================================================
       Backup & Restore (Export & Import JSON)
       =================================================== */
    function exportData() {
        if (transactions.length === 0) {
            showToast('এক্সপোর্ট করার মতো কোনো হিসাব নেই!');
            return;
        }

        const profilePhoto = localStorage.getItem(STORAGE_KEY_PROFILE) || null;
        const backupObject = {
            app: 'IslamicJamaKhoroch',
            version: '1.0',
            exportedAt: new Date().toISOString(),
            profilePhoto: profilePhoto,
            transactions: transactions
        };

        const jsonString = JSON.stringify(backupObject, null, 2);
        const blob = new Blob([jsonString], { type: 'application/json' });
        const url = URL.createObjectURL(blob);

        const a = document.createElement('a');
        a.href = url;
        const today = getTodayDateString();
        a.download = `islamic-jama-khoroch-backup-${today}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);

        showToast('ডাটা ব্যাকআপ ফাইল সফলভাবে ডাউনলোড হয়েছে');
    }

    function importData(file) {
        if (!file) return;

        const reader = new FileReader();
        reader.onload = function (e) {
            try {
                const parsed = JSON.parse(e.target.result);

                // Validate structure
                if (!parsed || !Array.isArray(parsed.transactions)) {
                    showToast('ভুল ফরম্যাট! সঠিক ব্যাকআপ ফাইল নির্বাচন করুন।');
                    return;
                }

                // Restore Transactions
                transactions = parsed.transactions.filter(item => {
                    return item && item.id && item.type && !isNaN(item.amount) && item.date;
                });

                // Restore profile photo if available
                if (parsed.profilePhoto && typeof parsed.profilePhoto === 'string') {
                    localStorage.setItem(STORAGE_KEY_PROFILE, parsed.profilePhoto);
                    loadProfilePhoto();
                }

                saveTransactionsToStorage();
                updateDashboard();
                renderTransactions();
                showToast('ডাটা সফলভাবে রিস্টোর করা হয়েছে');
            } catch (err) {
                console.error('Import Error:', err);
                showToast('অকার্যকর ফাইল! সঠিক JSON ব্যাকআপ নির্বাচন করুন।');
            }
        };
        reader.readAsText(file);
    }

    /* ===================================================
       Event Listeners Registration
       =================================================== */
    function registerEvents() {
        // Profile Modal triggers
        el.profileAvatarBtn.addEventListener('click', () => openModal(el.profileModal));
        el.closeProfileModalBtn.addEventListener('click', () => closeModal(el.profileModal));
        el.changePhotoBtn.addEventListener('click', () => {
            el.profileFileInput.click();
        });
        el.profileFileInput.addEventListener('change', (e) => {
            if (e.target.files && e.target.files[0]) {
                handleProfileFileUpload(e.target.files[0]);
            }
            e.target.value = '';
        });
        el.removePhotoBtn.addEventListener('click', removeProfilePhoto);

        // Utility Buttons
        el.exportBtn.addEventListener('click', exportData);
        el.importBtn.addEventListener('click', () => el.importFileInput.click());
        el.importFileInput.addEventListener('change', (e) => {
            if (e.target.files && e.target.files[0]) {
                importData(e.target.files[0]);
            }
            e.target.value = '';
        });
        el.resetAllBtn.addEventListener('click', () => openModal(el.resetModal));

        // Reset Modal
        el.cancelResetBtn.addEventListener('click', () => closeModal(el.resetModal));
        el.confirmResetBtn.addEventListener('click', confirmResetAll);

        // Primary ＋ নতুন হিসাব
        el.openAddModalBtn.addEventListener('click', openAddModal);
        el.closeTransactionModalBtn.addEventListener('click', () => closeModal(el.transactionModal));
        el.cancelTransactionModalBtn.addEventListener('click', () => closeModal(el.transactionModal));
        el.transactionForm.addEventListener('submit', handleFormSubmit);

        // Type Buttons Toggle
        el.typeIncomeBtn.addEventListener('click', () => setFormType('income'));
        el.typeExpenseBtn.addEventListener('click', () => setFormType('expense'));

        // Quick Amount Chips
        el.quickChips.forEach(chip => {
            chip.addEventListener('click', () => {
                const addVal = parseFloat(chip.dataset.val) || 0;
                const currentVal = parseFloat(el.transactionAmount.value) || 0;
                el.transactionAmount.value = currentVal + addVal;
                el.amountError.textContent = '';
            });
        });

        // Category Tag Chips
        el.categoryTags.forEach(tag => {
            tag.addEventListener('click', () => {
                el.transactionNote.value = tag.textContent.trim();
                el.noteError.textContent = '';
            });
        });

        // Delete Modal
        el.cancelDeleteBtn.addEventListener('click', () => {
            pendingDeleteId = null;
            closeModal(el.deleteModal);
        });
        el.confirmDeleteBtn.addEventListener('click', confirmDelete);

        // Card Action Delegation (Edit & Delete buttons inside list)
        el.transactionsList.addEventListener('click', (e) => {
            const btn = e.target.closest('.btn-tx-action');
            if (!btn) return;

            const action = btn.dataset.action;
            const id = btn.dataset.id;

            if (action === 'edit') {
                openEditModal(id);
            } else if (action === 'delete') {
                openDeleteModal(id);
            }
        });

        // Search Input
        el.searchInput.addEventListener('input', (e) => {
            searchQuery = e.target.value;
            if (searchQuery.length > 0) {
                el.searchClearBtn.style.display = 'flex';
            } else {
                el.searchClearBtn.style.display = 'none';
            }
            renderTransactions();
        });

        el.searchClearBtn.addEventListener('click', () => {
            el.searchInput.value = '';
            searchQuery = '';
            el.searchClearBtn.style.display = 'none';
            renderTransactions();
            el.searchInput.focus();
        });

        // Filter Pills
        el.filterPills.forEach(pill => {
            pill.addEventListener('click', () => {
                el.filterPills.forEach(p => p.classList.remove('active'));
                pill.classList.add('active');
                currentFilter = pill.dataset.filter;
                renderTransactions();
            });
        });
    }

    /* ===================================================
       App Initialization
       =================================================== */
    function init() {
        initHeaderDate();
        loadProfilePhoto();
        loadTransactionsFromStorage();
        updateDashboard();
        renderTransactions();
        registerEvents();
    }

    // Run on DOM ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
