/**
 * আল কারীম পুকুর ম্যানেজমেন্ট - Master JavaScript Application
 * Full-featured cooperative fish farming & financial management system
 */

(function() {
  'use strict';

  // Master Store Key & Theme Key
  const STORAGE_KEY = 'alkarim_pond_management_v1';
  const THEME_KEY = 'alkarim_theme';
  const USER_KEY = 'alkarim_auth_user';

  // Bangladeshi currency formatter
  function formatMoney(amount) {
    const num = Math.round(Number(amount) || 0);
    return '৳ ' + num.toLocaleString('bn-BD');
  }

  function formatNumber(num, decimals = 1) {
    const val = Number(num) || 0;
    return val.toLocaleString('bn-BD', { minimumFractionDigits: 0, maximumFractionDigits: decimals });
  }

  function getTodayString() {
    const d = new Date();
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }

  // Pre-seed Initial Realistic Data
  function getInitialDataset() {
    // 30 Members with shares totaling exactly 8.00 shares
    const memberNames = [
      "হাজী মো: আব্দুল করিম", "মো: রফিকুল ইসলাম", "মো: আবুল কাশেম", "মাওলানা মো: ইউসুফ",
      "মো: জহিরুল হক", "মো: মিজানুর রহমান", "মো: নুরুল ইসলাম", "ডা: শামসুল আলম",
      "মো: ফারুক হোসেন", "মো: জাকির হোসেন", "মো: জাহাঙ্গীর আলম", "মো: সাইফুল ইসলাম",
      "মো: হারুনুর রশীদ", "মো: আক্তারুজ্জামান", "মো: মোশাররফ হোসেন", "মো: আনোয়ার হোসেন",
      "মো: দেলোয়ার হোসেন", "মো: কামাল উদ্দিন", "মো: বেলাল হোসেন", "মো: সেলিম রেজা",
      "মো: মাহফুজুর রহমান", "মো: শফিকুল ইসলাম", "মো: আশরাফুল ইসলাম", "মো: শাহজাহান মিয়া",
      "মো: ফজলুল হক", "মো: রুহুল আমিন", "মো: আব্দুল মান্নান", "মো: মোস্তফা কামাল",
      "মো: তৌহিদুল ইসলাম", "মাওলানা মো: ইব্রাহিম"
    ];

    // Share distribution totaling 8.0 shares:
    // 4 members with 0.50 share = 2.0
    // 12 members with 0.25 share = 3.0
    // 14 members with ~0.214 share (scaled to exactly 3.0: 10 with 0.22 and 4 with 0.20 = 3.0)
    const shareValues = [
      0.50, 0.50, 0.50, 0.50,
      0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25,
      0.22, 0.22, 0.22, 0.22, 0.22, 0.22, 0.22, 0.22, 0.22, 0.22,
      0.20, 0.20, 0.20, 0.20
    ];

    const members = memberNames.map((name, index) => {
      const id = index + 1;
      const shares = shareValues[index];
      const deposit = Math.round(shares * 50000); // ৳৫০,০০০ per full share
      return {
        id: `M-${String(id).padStart(3, '0')}`,
        code: `AK-${String(id).padStart(2, '0')}`,
        name: name,
        father: `মৃত মো: ${name.split(' ').slice(-1)[0]} পিতা`,
        phone: `0171${String(1000000 + id * 372).slice(0, 7)}`,
        shares: shares,
        deposit: deposit,
        joinDate: '2026-01-01',
        address: 'দক্ষিণ পুকুরপাড়, সদর',
        notes: 'প্রতিষ্ঠাতা সদস্য'
      };
    });

    const ponds = [
      {
        id: 'P-001',
        name: 'দক্ষিণ পুকুর (পুকুর-১)',
        location: 'দক্ষিণ পাড়া মোড়',
        area: 50.0,
        depth: 6.5,
        type: 'পালন পুকুর',
        ownership: 'নিজস্ব',
        fishSpecies: 'রুই, কাতলা, মৃগেল, পাঙ্গাশ',
        stockingDate: '2026-02-15',
        initialFishCount: 8000,
        initialFishWeight: 320,
        notes: 'প্রধান বাণিজ্যিক কার্প ও পাঙ্গাশ চাষ'
      },
      {
        id: 'P-002',
        name: 'উত্তর পুকুর (পুকুর-২)',
        location: 'উত্তর বিদ্যালয় সংলগ্ন',
        area: 40.0,
        depth: 5.5,
        type: 'পালন পুকুর',
        ownership: 'ইজারা',
        fishSpecies: 'তেলাপিয়া, সিলভার কার্প, শিং',
        stockingDate: '2026-03-01',
        initialFishCount: 6500,
        initialFishWeight: 240,
        notes: 'বাৎসরিক ইজারা ২০২৬-২০২৭'
      }
    ];

    const feedStock = [
      {
        id: 'FS-001',
        date: '2026-08-20',
        feedName: 'এনাম ফিড গ্রোয়ার',
        feedType: 'ভাসা ফিড',
        quantityKg: 800,
        pricePerKg: 68,
        totalCost: 54400,
        supplier: 'এনাম ফিডস লিমিটেড',
        invoice: 'INV-8821',
        notes: 'ভাসা ফিড ২৮% প্রোটিন'
      },
      {
        id: 'FS-002',
        date: '2026-08-25',
        feedName: 'এনাম ফিড স্টার্টার',
        feedType: 'ডুবন্ত ফিড',
        quantityKg: 500,
        pricePerKg: 62,
        totalCost: 31000,
        supplier: 'মেসার্স মতিন ট্রেডার্স',
        invoice: 'INV-8835',
        notes: 'ডুবন্ত ফিড ৩০% প্রোটিন'
      }
    ];

    const feed = [
      {
        id: 'FD-001',
        date: '2026-09-08',
        pondId: 'P-001',
        time: 'সকাল',
        feedType: 'ভাসা ফিড',
        feedBrand: 'এনাম ফিড',
        feedName: 'গ্রোয়ার ২.০ মিমি',
        amountKg: 35,
        pricePerKg: 68,
        totalCost: 2380,
        givenBy: 'শ্রমিক মফিজুল',
        notes: 'স্বাভাবিক বৃদ্ধি'
      },
      {
        id: 'FD-002',
        date: '2026-09-08',
        pondId: 'P-001',
        time: 'বিকাল',
        feedType: 'ভাসা ফিড',
        feedBrand: 'এনাম ফিড',
        feedName: 'গ্রোয়ার ২.০ মিমি',
        amountKg: 40,
        pricePerKg: 68,
        totalCost: 2720,
        givenBy: 'শ্রমিক মফিজুল',
        notes: ''
      },
      {
        id: 'FD-003',
        date: '2026-09-09',
        pondId: 'P-002',
        time: 'সকাল',
        feedType: 'ডুবন্ত ফিড',
        feedBrand: 'এনাম ফিড',
        feedName: 'স্টার্টার',
        amountKg: 25,
        pricePerKg: 62,
        totalCost: 1550,
        givenBy: 'শ্রমিক সামাদ',
        notes: ''
      },
      {
        id: 'FD-004',
        date: '2026-09-10',
        pondId: 'P-001',
        time: 'সকাল',
        feedType: 'ভাসা ফিড',
        feedBrand: 'এনাম ফিড',
        feedName: 'গ্রোয়ার',
        amountKg: 30,
        pricePerKg: 68,
        totalCost: 2040,
        givenBy: 'শ্রমিক মফিজুল',
        notes: 'আজকের সকালের খাদ্য'
      }
    ];

    const fishPurchases = [
      {
        id: 'FP-001',
        date: '2026-02-15',
        pondId: 'P-001',
        fishName: 'রুই ও কাতলা পোনা',
        type: 'আঙুলিপোনা',
        count: 8000,
        weightKg: 320,
        fishCost: 48000,
        transportCost: 3500,
        otherCost: 1000,
        totalCost: 52500,
        supplier: 'ময়মনসিংহ হ্যাচারি',
        notes: 'উন্নত জাতের পোনা'
      },
      {
        id: 'FP-002',
        date: '2026-03-01',
        pondId: 'P-002',
        fishName: 'তেলাপিয়া ও সিলভার কার্প',
        type: 'পোনা',
        count: 6500,
        weightKg: 240,
        fishCost: 32000,
        transportCost: 2500,
        otherCost: 500,
        totalCost: 35000,
        supplier: 'বগুড়া ফিশ সিড ফার্ম',
        notes: 'মোনোসেক্স তেলাপিয়া'
      }
    ];

    const fishSales = [
      {
        id: 'FS-001',
        date: '2026-08-15',
        pondId: 'P-001',
        fishName: 'বড় পাঙ্গাশ ও রুই',
        count: 450,
        weightKg: 680,
        pricePerKg: 190,
        totalSale: 129200,
        customerName: 'আলহাজ্ব কাশেম আড়তদার',
        customerPhone: '01819345678',
        paymentStatus: 'পরিশোধ',
        paidAmount: 129200,
        dueAmount: 0,
        notes: 'প্রথম দফা আংশিক বিক্রয়'
      },
      {
        id: 'FS-002',
        date: '2026-09-02',
        pondId: 'P-002',
        fishName: 'তেলাপিয়া',
        count: 600,
        weightKg: 420,
        pricePerKg: 175,
        totalSale: 73500,
        customerName: 'মেসার্স ভাই ভাই মৎস্য ভান্ডার',
        customerPhone: '01712987654',
        paymentStatus: 'পরিশোধ',
        paidAmount: 73500,
        dueAmount: 0,
        notes: 'বাজার দর ভালো পাওয়া গেছে'
      }
    ];

    const deadFish = [
      {
        id: 'DF-001',
        date: '2026-08-10',
        pondId: 'P-001',
        fishName: 'পাঙ্গাশ',
        count: 22,
        weightKg: 12.0,
        cause: 'অক্সিজেন স্বল্পতা',
        notes: 'বৃষ্টির পর রাতে অক্সিজেন কমেছিল, পরদিন ভোরে অ্যারেটর চালানো হয়'
      },
      {
        id: 'DF-002',
        date: '2026-09-05',
        pondId: 'P-002',
        fishName: 'তেলাপিয়া',
        count: 14,
        weightKg: 5.5,
        cause: 'পানি অতিরিক্ত গরম/ঠান্ডা',
        notes: 'চুন ও জিওলাইট প্রয়োগ করা হয়েছে'
      }
    ];

    const expenses = [
      {
        id: 'EX-001',
        date: '2026-08-01',
        pondId: 'P-001',
        category: 'চুন',
        desc: 'পুকুরের তলদেশ শোধনে কলিচুন',
        quantity: '৪ বস্তা',
        amount: 3200,
        paidBy: 'ক্যাশিয়ার রফিকুল',
        voucher: 'V-01',
        notes: 'পানি শোধনে'
      },
      {
        id: 'EX-002',
        date: '2026-08-12',
        pondId: 'P-001',
        category: 'শ্রমিক',
        desc: 'পুকুরপাড় পরিষ্কার ও জাল টানা মজুরি',
        quantity: '৩ জন শ্রমিক',
        amount: 2400,
        paidBy: 'ক্যাশিয়ার রফিকুল',
        voucher: 'V-02',
        notes: 'দৈনিক মজুরি'
      },
      {
        id: 'EX-003',
        date: '2026-08-28',
        pondId: 'P-002',
        category: 'ঔষধ',
        desc: 'অক্সিজেন ট্যাবলেট ও জিওলাইট পাউডার',
        quantity: '১ প্যাকেট',
        amount: 1850,
        paidBy: 'ম্যানেজার আব্দুল করিম',
        voucher: 'V-03',
        notes: 'জরুরি প্রতিরোধক'
      },
      {
        id: 'EX-004',
        date: '2026-09-01',
        pondId: 'P-001',
        category: 'বিদ্যুৎ',
        desc: 'পানির পাম্প ও মোটর বিদ্যুৎ বিল',
        quantity: 'আগস্ট মাসের বিল',
        amount: 4200,
        paidBy: 'কোষাধ্যক্ষ',
        voucher: 'V-04',
        notes: 'পল্লী বিদ্যুৎ বিল'
      }
    ];

    return {
      samity: {
        name: 'আল কারীম',
        fullName: 'আল কারীম বহুমুখী সমবায় সমিতি',
        totalShares: 8.0,
        address: 'দক্ষিণ পুকুরপাড়, সদর',
        regNo: 'AK-POND-2026-08'
      },
      ponds,
      members,
      feedStock,
      feed,
      fishPurchases,
      fishSales,
      deadFish,
      expenses,
      trash: [],
      user: {
        email: 'jubairahmad8000@gmail.com',
        role: 'admin',
        name: 'এডমিন (আল কারীম)'
      }
    };
  }

  // Application Controller
  class PondManagementApp {
    constructor() {
      this.data = this.loadData();
      this.currentView = 'dashboard';
      this.charts = {};
      this.pendingDelete = null;
    }

    loadData() {
      try {
        const raw = localStorage.getItem(STORAGE_KEY);
        if (raw) {
          const parsed = JSON.parse(raw);
          // Ensure necessary arrays exist
          if (!parsed.ponds) parsed.ponds = [];
          if (!parsed.members) parsed.members = [];
          if (!parsed.feed) parsed.feed = [];
          if (!parsed.feedStock) parsed.feedStock = [];
          if (!parsed.fishPurchases) parsed.fishPurchases = [];
          if (!parsed.fishSales) parsed.fishSales = [];
          if (!parsed.deadFish) parsed.deadFish = [];
          if (!parsed.expenses) parsed.expenses = [];
          if (!parsed.trash) parsed.trash = [];
          if (!parsed.samity) parsed.samity = { name: 'আল কারীম', totalShares: 8.0 };
          return parsed;
        }
      } catch (err) {
        console.error('Error loading data from localStorage:', err);
      }
      const initial = getInitialDataset();
      this.saveData(initial);
      return initial;
    }

    saveData(dataToSave = this.data) {
      this.data = dataToSave;
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(this.data));
      } catch (err) {
        console.error('Storage write error:', err);
      }
      this.updateSidebarBadges();
    }

    init() {
      this.initTheme();
      this.initUser();
      this.bindEvents();
      this.populateSelectDropdowns();
      this.renderCurrentView();
      this.updateSidebarBadges();
    }

    initTheme() {
      const savedTheme = localStorage.getItem(THEME_KEY) || 'light';
      document.documentElement.setAttribute('data-theme', savedTheme);
      const toggleBtn = document.getElementById('themeToggleBtn');
      if (toggleBtn) {
        toggleBtn.textContent = savedTheme === 'dark' ? '☀️' : '🌙';
      }
    }

    toggleTheme() {
      const current = document.documentElement.getAttribute('data-theme');
      const next = current === 'dark' ? 'light' : 'dark';
      document.documentElement.setAttribute('data-theme', next);
      localStorage.setItem(THEME_KEY, next);
      const toggleBtn = document.getElementById('themeToggleBtn');
      if (toggleBtn) {
        toggleBtn.textContent = next === 'dark' ? '☀️' : '🌙';
      }
      // Re-draw charts with theme colors
      this.drawCharts();
    }

    initUser() {
      if (!this.data.user) {
        this.data.user = {
          uid: "admin_user",
          email: "jubairahmad8000@gmail.com",
          name: "এডমিন (আল কারীম)",
          role: "admin"
        };
      }
      this.updateUserUI();
    }

    updateUserUI() {
      const roleBadge = document.getElementById("userRoleBadge");
      const userAvatarInitial = document.getElementById("userAvatarInitial");
      const userAvatarImg = document.getElementById("userAvatarImg");
      const settingsUserEmail = document.getElementById("settingsUserEmail");
      const settingRoleSelect = document.getElementById("settingUserRoleSelect");

      const profileModalName = document.getElementById("profileModalName");
      const profileModalEmail = document.getElementById("profileModalEmail");
      const profileModalRole = document.getElementById("profileModalRole");
      const profileModalInitial = document.getElementById("profileModalInitial");
      const profileModalImg = document.getElementById("profileModalImg");

      const isAdmin = !this.data.user || this.data.user.role === "admin";
      const displayName = (this.data.user && this.data.user.name) || "এডমিন (আল কারীম)";
      const email = (this.data.user && this.data.user.email) || "jubairahmad8000@gmail.com";
      const initial = "A";

      if (roleBadge) roleBadge.textContent = isAdmin ? "এডমিন" : "অপারেটর";
      if (settingsUserEmail) settingsUserEmail.textContent = email;
      if (settingRoleSelect && this.data.user) settingRoleSelect.value = this.data.user.role || "admin";

      if (userAvatarInitial) userAvatarInitial.textContent = initial;
      if (userAvatarImg) userAvatarImg.style.display = "none";
      if (userAvatarInitial) userAvatarInitial.style.display = "block";

      if (profileModalName) profileModalName.textContent = displayName;
      if (profileModalEmail) profileModalEmail.textContent = email;
      if (profileModalRole) profileModalRole.textContent = isAdmin ? "এডমিন প্রিভিলেজ (পূর্ণ ক্ষমতা)" : "অপারেটর মোড";
      if (profileModalInitial) profileModalInitial.textContent = initial;
      if (profileModalImg) profileModalImg.style.display = "none";
    }

    setUserRole(role) {
      if (!this.data.user) this.data.user = {};
      this.data.user.role = role;
      try {
        localStorage.setItem(USER_KEY, JSON.stringify(this.data.user));
      } catch (e) {}
      this.updateUserUI();
      this.showToast("রোল পরিবর্তন করা হয়েছে: " + (role === "admin" ? "এডমিন" : "অপারেটর"), "success");
    }

    updateCloudSyncBadge(text = "অটো-সেভ সক্রিয়", type = "success") {
      const badge = document.getElementById("cloudSyncBadge");
      const dot = document.getElementById("cloudSyncDot");
      const label = document.getElementById("cloudSyncText");
      if (!badge || !dot || !label) return;
      label.textContent = text;
      dot.style.background = "#198754";
    }

    updateSettingsSyncInfo() {}

    openFirebaseConfigModal() {}
    closeFirebaseConfigModal() {}
    logout() {
      this.showToast("সরাসরি ড্যাশবোর্ড মোড সক্রিয়। লগআউট করার প্রয়োজন নেই।", "info");
    }
    syncCloudNow() {
      this.showToast("লোকাল ডাটাবেজে ডাটা স্বয়ংক্রিয়ভাবে সংরক্ষিত রয়েছে।", "info");
    }

    checkAdminPermission(actionName = 'এই কাজ') {
      if (this.data.user && this.data.user.role === 'operator') {
        this.showToast(`অনুমতি নেই: শুধুমাত্র এডমিন ${actionName} করতে পারেন।`, 'danger');
        return false;
      }
      return true;
    }

    // Navigation & Views
    switchView(viewName) {
      this.currentView = viewName;
      document.querySelectorAll('.view-section').forEach(el => el.classList.remove('active'));
      const targetView = document.getElementById(`view-${viewName}`);
      if (targetView) targetView.classList.add('active');

      document.querySelectorAll('.sidebar-menu .menu-item').forEach(item => {
        item.classList.toggle('active', item.getAttribute('data-view') === viewName);
      });

      // Update Top Title
      const titles = {
        dashboard: '📊 ড্যাশবোর্ড',
        ponds: '🏞️ পুকুর ব্যবস্থাপনা',
        members: '👥 সদস্য ব্যবস্থাপনা',
        shares: '📈 শেয়ার ব্যবস্থাপনা',
        feed: '🌾 দৈনিক খাদ্য হিসাব',
        feedStock: '📦 খাদ্য স্টক',
        fishPurchase: '🛒 মাছ ও পোনা ক্রয়',
        fishSale: '💰 মাছ বিক্রয় ও আয়',
        deadFish: '⚠️ মৃত মাছের হিসাব',
        expenses: '📝 দৈনন্দিন খরচ',
        incomeExpense: '⚖️ সমন্বিত আয়-ব্যয়ের হিসাব',
        monthlyReport: '📅 মাসিক প্রতিবেদন',
        yearlyReport: '🗓️ বার্ষিক প্রতিবেদন',
        memberAccounts: '💳 সদস্যের বিস্তারিত লেজার',
        pondAccounts: '🌊 পুকুরের পারফরম্যান্স হিসাব',
        reports: '🖨️ প্রিন্ট ও রিপোর্ট হাব',
        trash: '🗑️ রিসাইকেল বিন / ট্র্যাশ',
        settings: '⚙️ সেটিংস ও ব্যাকআপ'
      };

      const titleEl = document.getElementById('currentPageTitle');
      if (titleEl) titleEl.textContent = titles[viewName] || 'আল কারীম পুকুর';

      // Close mobile sidebar if open
      this.toggleSidebar(false);

      this.renderCurrentView();
    }

    toggleSidebar(show) {
      const sidebar = document.getElementById('appSidebar');
      const overlay = document.getElementById('sidebarOverlay');
      if (typeof show === 'boolean') {
        sidebar.classList.toggle('open', show);
        overlay.classList.toggle('active', show);
      } else {
        sidebar.classList.toggle('open');
        overlay.classList.toggle('active');
      }
    }

    updateSidebarBadges() {
      const pondsCount = document.getElementById('sidebarPondsCount');
      const membersCount = document.getElementById('sidebarMembersCount');
      const sharesCount = document.getElementById('sidebarSharesCount');
      const trashCount = document.getElementById('sidebarTrashCount');

      if (pondsCount) pondsCount.textContent = (this.data.ponds || []).length;
      if (membersCount) membersCount.textContent = (this.data.members || []).length;
      if (sharesCount) sharesCount.textContent = (this.data.samity.totalShares || 8.0);
      if (trashCount) trashCount.textContent = (this.data.trash || []).length;
    }

    populateSelectDropdowns() {
      const pondSelects = [
        document.getElementById('feedPondId'),
        document.getElementById('fpPondId'),
        document.getElementById('fsPondId'),
        document.getElementById('dfPondId'),
        document.getElementById('expPondId'),
        document.getElementById('filterFeedPond'),
        document.getElementById('selectPondAccount')
      ];

      const ponds = this.data.ponds || [];
      pondSelects.forEach(select => {
        if (!select) return;
        const currentVal = select.value;
        const isFilter = select.id.startsWith('filter') || select.id === 'expPondId';
        select.innerHTML = isFilter ? '<option value="">সকল পুকুর</option>' : '';
        ponds.forEach(p => {
          const opt = document.createElement('option');
          opt.value = p.id;
          opt.textContent = `${p.name} (${p.area} শতক)`;
          select.appendChild(opt);
        });
        if (currentVal) select.value = currentVal;
      });

      // Member account selector
      const memberSelect = document.getElementById('selectMemberAccount');
      if (memberSelect) {
        memberSelect.innerHTML = '';
        (this.data.members || []).forEach(m => {
          const opt = document.createElement('option');
          opt.value = m.id;
          opt.textContent = `${m.code} - ${m.name} (${m.shares} শেয়ার)`;
          memberSelect.appendChild(opt);
        });
      }
    }

    // Calculations Engine
    calculateTotals() {
      const ponds = this.data.ponds || [];
      const members = this.data.members || [];
      const feed = this.data.feed || [];
      const feedStock = this.data.feedStock || [];
      const fishPurchases = this.data.fishPurchases || [];
      const fishSales = this.data.fishSales || [];
      const deadFish = this.data.deadFish || [];
      const expenses = this.data.expenses || [];

      // 1. Total Feed used
      let totalFeedKg = 0;
      let totalFeedCost = 0;
      let floatingFeedKg = 0;
      let sinkingFeedKg = 0;
      let morningFeedKg = 0;
      let eveningFeedKg = 0;

      const todayStr = getTodayString();
      let todayFeedKg = 0;
      let todayFeedCost = 0;

      feed.forEach(f => {
        const kg = Number(f.amountKg) || 0;
        const cost = Number(f.totalCost) || (kg * (Number(f.pricePerKg) || 0));
        totalFeedKg += kg;
        totalFeedCost += cost;

        if (f.feedType === 'ভাসা ফিড') floatingFeedKg += kg;
        else if (f.feedType === 'ডুবন্ত ফিড') sinkingFeedKg += kg;

        if (f.time === 'সকাল') morningFeedKg += kg;
        else if (f.time === 'বিকাল') eveningFeedKg += kg;

        if (f.date === todayStr) {
          todayFeedKg += kg;
          todayFeedCost += cost;
        }
      });

      // 2. Feed Stock Remaining
      let totalStockPurchasedKg = 0;
      feedStock.forEach(fs => {
        totalStockPurchasedKg += Number(fs.quantityKg) || 0;
      });
      const remainingFeedStockKg = Math.max(0, totalStockPurchasedKg - totalFeedKg);

      // 3. Fish Purchases
      let totalFishPurchaseCost = 0;
      let totalFishStockedCount = 0;
      fishPurchases.forEach(fp => {
        totalFishPurchaseCost += Number(fp.totalCost) || 0;
        totalFishStockedCount += Number(fp.count) || 0;
      });

      // 4. Fish Sales (Income)
      let totalFishSalesAmount = 0;
      let totalFishSoldKg = 0;
      let totalFishSoldCount = 0;
      let todayFishSale = 0;
      let fishSalesDue = 0;

      fishSales.forEach(fs => {
        const sale = Number(fs.totalSale) || 0;
        totalFishSalesAmount += sale;
        totalFishSoldKg += Number(fs.weightKg) || 0;
        totalFishSoldCount += Number(fs.count) || 0;
        fishSalesDue += Number(fs.dueAmount) || 0;
        if (fs.date === todayStr) todayFishSale += sale;
      });

      // 5. Dead Fish
      let totalDeadFishCount = 0;
      let totalDeadFishWeight = 0;
      let todayDeadFish = 0;

      deadFish.forEach(df => {
        const count = Number(df.count) || 0;
        totalDeadFishCount += count;
        totalDeadFishWeight += Number(df.weightKg) || 0;
        if (df.date === todayStr) todayDeadFish += count;
      });

      // 6. Expenses
      let totalOperatingExpense = 0;
      let todayExpense = 0;

      expenses.forEach(ex => {
        const amt = Number(ex.amount) || 0;
        totalOperatingExpense += amt;
        if (ex.date === todayStr) todayExpense += amt;
      });

      // Consolidated Financials
      // Total Expense = Fish Purchase + Feed Cost + Operating Expenses
      const grandTotalExpense = totalFishPurchaseCost + totalFeedCost + totalOperatingExpense;
      const grandTotalIncome = totalFishSalesAmount;
      const netProfitLoss = grandTotalIncome - grandTotalExpense;

      // Estimated Live Fish Count in ponds
      let initialStockCount = 0;
      ponds.forEach(p => { initialStockCount += Number(p.initialFishCount) || 0; });
      const currentLiveFishEst = Math.max(0, (initialStockCount + totalFishStockedCount) - (totalFishSoldCount + totalDeadFishCount));

      // Shares
      let totalSharesAllocated = 0;
      let totalMemberDeposits = 0;
      members.forEach(m => {
        totalSharesAllocated += Number(m.shares) || 0;
        totalMemberDeposits += Number(m.deposit) || 0;
      });
      const totalAuthorizedShares = Number(this.data.samity.totalShares) || 8.0;

      return {
        totalPonds: ponds.length,
        totalArea: ponds.reduce((sum, p) => sum + (Number(p.area) || 0), 0),
        totalMembers: members.length,
        totalSharesAllocated,
        totalAuthorizedShares,
        remainingShares: Math.max(0, totalAuthorizedShares - totalSharesAllocated),
        totalMemberDeposits,
        totalFeedKg,
        totalFeedCost,
        floatingFeedKg,
        sinkingFeedKg,
        morningFeedKg,
        eveningFeedKg,
        todayFeedKg,
        todayFeedCost,
        remainingFeedStockKg,
        totalFishPurchaseCost,
        totalFishStockedCount,
        totalFishSalesAmount,
        totalFishSoldKg,
        totalFishSoldCount,
        todayFishSale,
        fishSalesDue,
        totalDeadFishCount,
        totalDeadFishWeight,
        todayDeadFish,
        totalOperatingExpense,
        todayExpense: todayExpense + todayFeedCost, // including feed today
        grandTotalExpense,
        grandTotalIncome,
        netProfitLoss,
        currentLiveFishEst
      };
    }

    renderCurrentView() {
      switch (this.currentView) {
        case 'dashboard':
          this.renderDashboard();
          break;
        case 'ponds':
          this.renderPonds();
          break;
        case 'members':
          this.renderMembers();
          break;
        case 'shares':
          this.renderShares();
          break;
        case 'feed':
          this.renderFeed();
          break;
        case 'feedStock':
          this.renderFeedStock();
          break;
        case 'fishPurchase':
          this.renderFishPurchase();
          break;
        case 'fishSale':
          this.renderFishSale();
          break;
        case 'deadFish':
          this.renderDeadFish();
          break;
        case 'expenses':
          this.renderExpenses();
          break;
        case 'incomeExpense':
          this.renderIncomeExpense();
          break;
        case 'monthlyReport':
          this.generateMonthlyReport();
          break;
        case 'yearlyReport':
          this.generateYearlyReport();
          break;
        case 'memberAccounts':
          this.renderMemberAccount();
          break;
        case 'pondAccounts':
          this.renderPondAccount();
          break;
        case 'trash':
          this.renderTrash();
          break;
        case 'settings':
          this.renderSettings();
          break;
      }
    }

    // Dashboard View
    renderDashboard() {
      const t = this.calculateTotals();

      // Today Bar
      document.getElementById('todayDateStr').textContent = new Date().toLocaleDateString('bn-BD', { day: 'numeric', month: 'long', year: 'numeric' });
      document.getElementById('todayFeedKg').textContent = `${formatNumber(t.todayFeedKg)} কেজি`;
      document.getElementById('todayExpense').textContent = formatMoney(t.todayExpense);
      document.getElementById('todayFishSale').textContent = formatMoney(t.todayFishSale);
      document.getElementById('todayDeadFish').textContent = `${formatNumber(t.todayDeadFish)} টি`;

      // Low Stock Alert
      const alertBanner = document.getElementById('stockAlertBanner');
      if (alertBanner) {
        if (t.remainingFeedStockKg < 50) {
          alertBanner.style.display = 'flex';
          document.getElementById('stockAlertText').textContent = `সতর্কতা: বর্তমান খাদ্য স্টক মাত্র ${formatNumber(t.remainingFeedStockKg)} কেজি! অবিলম্বে নতুন খাদ্য ক্রয়ের পরামর্শ দেওয়া হচ্ছে।`;
        } else {
          alertBanner.style.display = 'none';
        }
      }

      // 11 Cards
      document.getElementById('cardTotalPonds').textContent = `${formatNumber(t.totalPonds)} টি`;
      document.getElementById('cardPondArea').textContent = `মোট আয়তন: ${formatNumber(t.totalArea)} শতাংশ`;
      document.getElementById('cardTotalMembers').textContent = `${formatNumber(t.totalMembers)} জন`;
      document.getElementById('cardTotalShares').textContent = `${formatNumber(t.totalAuthorizedShares, 2)}`;
      document.getElementById('cardShareAllocated').textContent = `বন্টিত: ${formatNumber(t.totalSharesAllocated, 2)} | অবণ্টিত: ${formatNumber(t.remainingShares, 2)}`;
      document.getElementById('cardTotalFishPurchase').textContent = formatMoney(t.totalFishPurchaseCost);
      document.getElementById('cardTotalFishStocked').textContent = `${formatNumber(t.totalFishStockedCount)} টি পোনা মজুদ`;
      document.getElementById('cardTotalFishSale').textContent = formatMoney(t.totalFishSalesAmount);
      document.getElementById('cardTotalFishSoldKg').textContent = `${formatNumber(t.totalFishSoldKg)} কেজি বিক্রিত`;
      document.getElementById('cardTotalFeedUsed').textContent = `${formatNumber(t.totalFeedKg)} কেজি`;
      document.getElementById('cardFeedCost').textContent = `মূল্য: ${formatMoney(t.totalFeedCost)}`;
      document.getElementById('cardTotalExpense').textContent = formatMoney(t.grandTotalExpense);
      document.getElementById('cardTotalIncome').textContent = formatMoney(t.grandTotalIncome);

      // Profit / Loss Box
      const pBox = document.getElementById('cardProfitLossBox');
      const pTitle = document.getElementById('cardProfitLossTitle');
      const pValue = document.getElementById('cardNetProfitLoss');
      const pMargin = document.getElementById('cardProfitMargin');
      const pIcon = document.getElementById('cardProfitLossIcon');

      const isProfit = t.netProfitLoss >= 0;
      pBox.className = `metric-card ${isProfit ? 'profit' : 'loss'}`;
      pTitle.textContent = isProfit ? 'নিট লাভ (Net Profit)' : 'নিট ক্ষতি (Net Loss)';
      pValue.textContent = formatMoney(Math.abs(t.netProfitLoss));
      pValue.style.color = isProfit ? 'var(--success)' : 'var(--danger)';
      pIcon.className = `metric-icon-box ${isProfit ? 'green' : 'red'}`;
      pIcon.textContent = isProfit ? '📈' : '📉';

      const marginPct = t.grandTotalIncome > 0 ? ((t.netProfitLoss / t.grandTotalIncome) * 100).toFixed(1) : '০.০';
      pMargin.textContent = `মার্জিন: ${marginPct}%`;

      document.getElementById('cardTotalDeadFish').textContent = `${formatNumber(t.totalDeadFishCount)} টি`;
      document.getElementById('cardDeadFishWeight').textContent = `আনুমানিক ${formatNumber(t.totalDeadFishWeight)} কেজি`;
      document.getElementById('cardLiveFishEst').textContent = `${formatNumber(t.currentLiveFishEst)} টি`;
      document.getElementById('cardLiveFishWeight').textContent = `বর্তমান জীবন্ত মাছ`;

      // Render Recent Activities
      this.renderRecentActivities();
      // Render Stock Summary List
      this.renderStockSummaryCards(t);
      // Draw Canvas Charts
      this.drawCharts();
    }

    renderRecentActivities() {
      const listEl = document.getElementById('dashboardRecentActivityList');
      if (!listEl) return;

      const items = [];
      (this.data.feed || []).slice(-5).forEach(f => {
        items.push({ date: f.date, type: 'খাদ্য', text: `${f.feedBrand} - ${f.amountKg} কেজি`, amt: formatMoney(f.totalCost), badge: 'badge-warning' });
      });
      (this.data.fishSales || []).slice(-5).forEach(s => {
        items.push({ date: s.date, type: 'মাছ বিক্রয়', text: `${s.fishName} (${s.weightKg} কেজি) - ${s.customerName}`, amt: `+ ${formatMoney(s.totalSale)}`, badge: 'badge-success' });
      });
      (this.data.expenses || []).slice(-5).forEach(e => {
        items.push({ date: e.date, type: 'খরচ', text: `${e.category}: ${e.desc}`, amt: `- ${formatMoney(e.amount)}`, badge: 'badge-danger' });
      });
      (this.data.deadFish || []).slice(-3).forEach(d => {
        items.push({ date: d.date, type: 'মৃত মাছ', text: `${d.count} টি ${d.fishName || 'মাছ'} (${d.cause})`, amt: `${d.weightKg} কেজি`, badge: 'badge-danger' });
      });

      items.sort((a, b) => new Date(b.date) - new Date(a.date));
      const display = items.slice(0, 6);

      if (display.length === 0) {
        listEl.innerHTML = '<tr><td colspan="4" style="text-align:center; color:var(--text-muted);">কোনো সাম্প্রতিক তথ্য নেই।</td></tr>';
        return;
      }

      listEl.innerHTML = display.map(it => `
        <tr>
          <td><small>${it.date}</small></td>
          <td><span class="badge ${it.badge}">${it.type}</span></td>
          <td>${it.text}</td>
          <td><strong>${it.amt}</strong></td>
        </tr>
      `).join('');
    }

    renderStockSummaryCards(t) {
      const container = document.getElementById('dashboardStockSummaryList');
      if (!container) return;

      const purchasedByName = {};
      (this.data.feedStock || []).forEach(fs => {
        const key = fs.feedName;
        purchasedByName[key] = (purchasedByName[key] || 0) + (Number(fs.quantityKg) || 0);
      });

      const usedByName = {};
      (this.data.feed || []).forEach(f => {
        const key = f.feedName || f.feedBrand;
        usedByName[key] = (usedByName[key] || 0) + (Number(f.amountKg) || 0);
      });

      const stockKeys = Object.keys(purchasedByName);
      if (stockKeys.length === 0) {
        container.innerHTML = '<div style="color:var(--text-muted); font-size:0.85rem;">স্টকে কোনো খাদ্য নেই। নতুন খাদ্য ক্রয় করুন।</div>';
        return;
      }

      container.innerHTML = stockKeys.map(name => {
        const total = purchasedByName[name] || 0;
        const used = usedByName[name] || 0;
        const rem = Math.max(0, total - used);
        const isLow = rem < 50;
        return `
          <div style="background:var(--bg-main); padding:0.75rem; border-radius:var(--radius-sm); border-left:4px solid ${isLow ? 'var(--danger)' : 'var(--success)'}; display:flex; justify-content:space-between; align-items:center;">
            <div>
              <strong style="font-size:0.9rem;">${name}</strong>
              <div style="font-size:0.75rem; color:var(--text-muted);">মোট ক্রয়: ${total} কেজি | ব্যবহার: ${used} কেজি</div>
            </div>
            <div style="text-align:right;">
              <span style="font-weight:700; font-size:1.1rem; color:${isLow ? 'var(--danger)' : 'var(--primary)'};">${rem} কেজি</span>
              <div style="font-size:0.7rem; font-weight:600; color:${isLow ? 'var(--danger)' : 'var(--success)'};">${isLow ? '⚠️ কম স্টক' : '✓ পর্যাপ্ত'}</div>
            </div>
          </div>
        `;
      }).join('');
    }

    // Canvas Chart Rendering (100% self-contained, lightweight, ultra-reliable offline)
    drawCharts() {
      this.drawIncomeExpenseChart();
      this.drawFeedTypeChart();
    }

    drawIncomeExpenseChart() {
      const canvas = document.getElementById('chartIncomeExpense');
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      const w = canvas.width = canvas.parentElement.clientWidth || 500;
      const h = canvas.height = 240;

      ctx.clearRect(0, 0, w, h);

      // Months Jan to Sep 2026
      const months = ['জানু', 'ফেব্রু', 'মার্চ', 'এপ্রিল', 'মে', 'জুন', 'জুলাই', 'আগস্ট', 'সেপ্টে'];
      const incomeData = [0, 0, 0, 0, 0, 0, 0, 129200, 73500];
      const expenseData = [0, 52500, 35000, 4500, 6200, 8900, 12400, 68000, 24000];

      const maxVal = Math.max(...incomeData, ...expenseData, 100000);
      const paddingLeft = 60;
      const paddingBottom = 30;
      const paddingTop = 20;
      const chartW = w - paddingLeft - 20;
      const chartH = h - paddingBottom - paddingTop;

      // Draw Grid Lines
      ctx.strokeStyle = '#e2e8f0';
      ctx.lineWidth = 1;
      for (let i = 0; i <= 4; i++) {
        const y = paddingTop + (chartH / 4) * i;
        ctx.beginPath();
        ctx.moveTo(paddingLeft, y);
        ctx.lineTo(w - 20, y);
        ctx.stroke();

        const labelVal = Math.round(maxVal - (maxVal / 4) * i);
        ctx.fillStyle = '#64748b';
        ctx.font = '10px system-ui';
        ctx.textAlign = 'right';
        ctx.fillText('৳ ' + (labelVal / 1000) + 'k', paddingLeft - 8, y + 3);
      }

      const barGroupW = chartW / months.length;
      const barW = barGroupW * 0.35;

      months.forEach((m, idx) => {
        const xCenter = paddingLeft + barGroupW * idx + barGroupW / 2;

        // Expense Bar (Red)
        const expH = (expenseData[idx] / maxVal) * chartH;
        ctx.fillStyle = '#ef4444';
        ctx.fillRect(xCenter - barW, paddingTop + chartH - expH, barW - 2, expH);

        // Income Bar (Green)
        const incH = (incomeData[idx] / maxVal) * chartH;
        ctx.fillStyle = '#10b981';
        ctx.fillRect(xCenter, paddingTop + chartH - incH, barW - 2, incH);

        // Month Label
        ctx.fillStyle = '#475569';
        ctx.font = '11px system-ui';
        ctx.textAlign = 'center';
        ctx.fillText(m, xCenter, h - 10);
      });
    }

    drawFeedTypeChart() {
      const canvas = document.getElementById('chartFeedType');
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      const w = canvas.width = 240;
      const h = canvas.height = 240;

      ctx.clearRect(0, 0, w, h);

      const t = this.calculateTotals();
      const floatKg = t.floatingFeedKg || 105;
      const sinkKg = t.sinkingFeedKg || 25;
      const total = floatKg + sinkKg || 1;

      const floatPct = floatKg / total;
      const sinkPct = sinkKg / total;

      const cx = w / 2;
      const cy = h / 2;
      const radius = 75;
      const innerRadius = 45;

      // Arc 1: Floating Feed (Green)
      const startAngle1 = -Math.PI / 2;
      const endAngle1 = startAngle1 + (floatPct * 2 * Math.PI);

      ctx.beginPath();
      ctx.arc(cx, cy, radius, startAngle1, endAngle1);
      ctx.arc(cx, cy, innerRadius, endAngle1, startAngle1, true);
      ctx.closePath();
      ctx.fillStyle = '#10b981';
      ctx.fill();

      // Arc 2: Sinking Feed (Gold)
      const startAngle2 = endAngle1;
      const endAngle2 = startAngle2 + (sinkPct * 2 * Math.PI);

      ctx.beginPath();
      ctx.arc(cx, cy, radius, startAngle2, endAngle2);
      ctx.arc(cx, cy, innerRadius, endAngle2, startAngle2, true);
      ctx.closePath();
      ctx.fillStyle = '#f59e0b';
      ctx.fill();

      // Center Text
      ctx.fillStyle = '#0f172a';
      ctx.font = 'bold 14px system-ui';
      ctx.textAlign = 'center';
      ctx.fillText(`${formatNumber(t.totalFeedKg)} কেজি`, cx, cy + 5);

      ctx.font = '10px system-ui';
      ctx.fillStyle = '#64748b';
      ctx.fillText('মোট খাদ্য', cx, cy - 14);
    }

    // Ponds Management
    renderPonds() {
      const tbody = document.getElementById('pondsTableBody');
      if (!tbody) return;

      const search = (document.getElementById('searchPonds')?.value || '').toLowerCase();
      const ponds = (this.data.ponds || []).filter(p => {
        return p.name.toLowerCase().includes(search) || p.location.toLowerCase().includes(search);
      });

      if (ponds.length === 0) {
        tbody.innerHTML = '<tr><td colspan="10" style="text-align:center; padding:2rem; color:var(--text-muted);">কোনো পুকুর পাওয়া যায়নি। "নতুন পুকুর যোগ" বাটনে চাপুন।</td></tr>';
        return;
      }

      tbody.innerHTML = ponds.map(p => {
        const feedKg = (this.data.feed || []).filter(f => f.pondId === p.id).reduce((sum, f) => sum + (Number(f.amountKg) || 0), 0);
        const expAmt = (this.data.expenses || []).filter(e => e.pondId === p.id).reduce((sum, e) => sum + (Number(e.amount) || 0), 0);
        return `
          <tr>
            <td><strong>${p.name}</strong></td>
            <td>${p.location}</td>
            <td>${formatNumber(p.area)} শতক</td>
            <td>${p.depth ? p.depth + ' ফুট' : '-'}</td>
            <td><span class="badge badge-info">${p.ownership}</span></td>
            <td>${p.fishSpecies || 'কার্প/পাঙ্গাশ'}</td>
            <td>${p.stockingDate || '-'}</td>
            <td><strong>${formatNumber(feedKg)} কেজি</strong></td>
            <td>${formatMoney(expAmt)}</td>
            <td>
              <div class="action-btn-group">
                <button class="btn-icon" title="এডিট" onclick="app.editPond('${p.id}')">✏️</button>
                <button class="btn-icon delete" title="ডিলিট" onclick="app.requestDelete('ponds', '${p.id}', '${p.name}')">🗑️</button>
              </div>
            </td>
          </tr>
        `;
      }).join('');
    }

    showAddPondModal() {
      document.getElementById('modalPondTitle').textContent = '➕ নতুন পুকুর যোগ করুন';
      document.getElementById('formPond').reset();
      document.getElementById('pondId').value = '';
      this.showModal('modalPond');
    }

    editPond(id) {
      const pond = (this.data.ponds || []).find(p => p.id === id);
      if (!pond) return;
      document.getElementById('modalPondTitle').textContent = '✏️ পুকুর তথ্য সম্পাদনা';
      document.getElementById('pondId').value = pond.id;
      document.getElementById('pondName').value = pond.name;
      document.getElementById('pondLocation').value = pond.location;
      document.getElementById('pondArea').value = pond.area;
      document.getElementById('pondDepth').value = pond.depth || '';
      document.getElementById('pondType').value = pond.type || 'পালন পুকুর';
      document.getElementById('pondOwnership').value = pond.ownership || 'নিজস্ব';
      document.getElementById('pondFishSpecies').value = pond.fishSpecies || '';
      document.getElementById('pondStockingDate').value = pond.stockingDate || '';
      document.getElementById('pondInitialFishCount').value = pond.initialFishCount || '';
      document.getElementById('pondInitialFishWeight').value = pond.initialFishWeight || '';
      document.getElementById('pondNotes').value = pond.notes || '';
      this.showModal('modalPond');
    }

    savePond(e) {
      e.preventDefault();
      const id = document.getElementById('pondId').value;
      const pondData = {
        id: id || `P-${Date.now()}`,
        name: document.getElementById('pondName').value.trim(),
        location: document.getElementById('pondLocation').value.trim(),
        area: Number(document.getElementById('pondArea').value) || 0,
        depth: Number(document.getElementById('pondDepth').value) || 0,
        type: document.getElementById('pondType').value,
        ownership: document.getElementById('pondOwnership').value,
        fishSpecies: document.getElementById('pondFishSpecies').value.trim(),
        stockingDate: document.getElementById('pondStockingDate').value,
        initialFishCount: Number(document.getElementById('pondInitialFishCount').value) || 0,
        initialFishWeight: Number(document.getElementById('pondInitialFishWeight').value) || 0,
        notes: document.getElementById('pondNotes').value.trim()
      };

      if (id) {
        const idx = this.data.ponds.findIndex(p => p.id === id);
        if (idx !== -1) this.data.ponds[idx] = pondData;
        this.showToast('পুকুরের তথ্য আপডেট করা হয়েছে।', 'success');
      } else {
        this.data.ponds.push(pondData);
        this.showToast('নতুন পুকুর সফলভাবে যুক্ত হয়েছে।', 'success');
      }

      this.saveData();
      this.closeModal('modalPond');
      this.populateSelectDropdowns();
      this.renderPonds();
    }

    // Members Management (30 Initial Members with 8.00 total shares)
    renderMembers() {
      const tbody = document.getElementById('membersTableBody');
      if (!tbody) return;

      const search = (document.getElementById('searchMembers')?.value || '').toLowerCase();
      const members = (this.data.members || []).filter(m => {
        return m.name.toLowerCase().includes(search) || m.code.toLowerCase().includes(search) || (m.phone && m.phone.includes(search));
      });

      const t = this.calculateTotals();
      const totalShares = t.totalAuthorizedShares || 8.0;

      document.getElementById('membersListCount').textContent = members.length;
      document.getElementById('membersTotalSharesSum').textContent = formatNumber(t.totalSharesAllocated, 2);

      if (members.length === 0) {
        tbody.innerHTML = '<tr><td colspan="11" style="text-align:center; padding:2rem; color:var(--text-muted);">কোনো সদস্য পাওয়া যায়নি।</td></tr>';
        return;
      }

      tbody.innerHTML = members.map(m => {
        const sharePct = ((m.shares / totalShares) * 100).toFixed(2);
        const expenseShare = Math.round(t.grandTotalExpense * (m.shares / totalShares));
        const profitShare = Math.round(t.grandTotalIncome * (m.shares / totalShares));
        // Net Balance = Deposit - Expense Portion + Profit Portion (or remaining balance)
        const netEquity = Math.round(m.deposit - expenseShare + (t.netProfitLoss > 0 ? (t.netProfitLoss * (m.shares / totalShares)) : 0));
        const isDue = netEquity < 0;

        return `
          <tr>
            <td><strong class="badge badge-primary">${m.code}</strong></td>
            <td><strong>${m.name}</strong></td>
            <td>${m.father || '-'}</td>
            <td>${m.phone}</td>
            <td><span class="badge badge-warning" style="font-size:0.85rem;">${m.shares} শেয়ার</span></td>
            <td>${sharePct}%</td>
            <td>${formatMoney(m.deposit)}</td>
            <td>${formatMoney(expenseShare)}</td>
            <td>${formatMoney(profitShare)}</td>
            <td><strong style="color:${isDue ? 'var(--danger)' : 'var(--success)'};">${formatMoney(netEquity)}</strong></td>
            <td>
              <div class="action-btn-group">
                <button class="btn-icon" title="স্টেটমেন্ট দেখুন" onclick="app.viewMemberStatement('${m.id}')">👁️</button>
                <button class="btn-icon" title="এডিট" onclick="app.editMember('${m.id}')">✏️</button>
                <button class="btn-icon delete" title="ডিলিট" onclick="app.requestDelete('members', '${m.id}', '${m.name}')">🗑️</button>
              </div>
            </td>
          </tr>
        `;
      }).join('');
    }

    showAddMemberModal() {
      document.getElementById('modalMemberTitle').textContent = '➕ নতুন সদস্য যোগ করুন';
      document.getElementById('formMember').reset();
      document.getElementById('memberDbId').value = '';
      const nextNum = (this.data.members || []).length + 1;
      document.getElementById('memberCode').value = `AK-${String(nextNum).padStart(2, '0')}`;
      document.getElementById('memberJoinDate').value = getTodayString();
      this.showModal('modalMember');
    }

    editMember(id) {
      const m = (this.data.members || []).find(mem => mem.id === id);
      if (!m) return;
      document.getElementById('modalMemberTitle').textContent = '✏️ সদস্য তথ্য সম্পাদনা';
      document.getElementById('memberDbId').value = m.id;
      document.getElementById('memberCode').value = m.code;
      document.getElementById('memberName').value = m.name;
      document.getElementById('memberFather').value = m.father || '';
      document.getElementById('memberPhone').value = m.phone;
      document.getElementById('memberShares').value = m.shares;
      document.getElementById('memberDeposit').value = m.deposit || 0;
      document.getElementById('memberJoinDate').value = m.joinDate || '';
      document.getElementById('memberAddress').value = m.address || '';
      document.getElementById('memberNotes').value = m.notes || '';
      this.showModal('modalMember');
    }

    saveMember(e) {
      e.preventDefault();
      const id = document.getElementById('memberDbId').value;
      const memberData = {
        id: id || `M-${Date.now()}`,
        code: document.getElementById('memberCode').value.trim(),
        name: document.getElementById('memberName').value.trim(),
        father: document.getElementById('memberFather').value.trim(),
        phone: document.getElementById('memberPhone').value.trim(),
        shares: Number(document.getElementById('memberShares').value) || 0,
        deposit: Number(document.getElementById('memberDeposit').value) || 0,
        joinDate: document.getElementById('memberJoinDate').value,
        address: document.getElementById('memberAddress').value.trim(),
        notes: document.getElementById('memberNotes').value.trim()
      };

      if (id) {
        const idx = this.data.members.findIndex(m => m.id === id);
        if (idx !== -1) this.data.members[idx] = memberData;
        this.showToast('সদস্যের তথ্য আপডেট করা হয়েছে।', 'success');
      } else {
        this.data.members.push(memberData);
        this.showToast('নতুন সদস্য সফলভাবে যোগ হয়েছে।', 'success');
      }

      this.saveData();
      this.closeModal('modalMember');
      this.populateSelectDropdowns();
      this.renderMembers();
    }

    // Shares Analysis View
    renderShares() {
      const tbody = document.getElementById('shareAnalysisTableBody');
      if (!tbody) return;

      const t = this.calculateTotals();
      const totalShares = t.totalAuthorizedShares || 8.0;

      document.getElementById('shareConfTotal').textContent = formatNumber(totalShares, 2);
      document.getElementById('shareConfAllocated').textContent = formatNumber(t.totalSharesAllocated, 2);
      document.getElementById('shareConfRemaining').textContent = formatNumber(t.remainingShares, 2);

      tbody.innerHTML = (this.data.members || []).map(m => {
        const shareRatio = m.shares / totalShares;
        const sharePct = (shareRatio * 100).toFixed(2);
        const expenseShare = Math.round(t.grandTotalExpense * shareRatio);
        const profitShare = Math.round(t.grandTotalIncome * shareRatio);
        const netShareProfit = Math.round(t.netProfitLoss * shareRatio);
        const netBalance = Math.round(m.deposit - expenseShare + netShareProfit);
        const isPayable = netBalance >= 0;

        return `
          <tr>
            <td><strong>${m.code} - ${m.name}</strong></td>
            <td><span class="badge badge-warning" style="font-size:0.85rem;">${m.shares} শেয়ার</span></td>
            <td><strong>${sharePct}%</strong></td>
            <td>${formatMoney(m.deposit)}</td>
            <td>${formatMoney(expenseShare)}</td>
            <td><strong style="color:${t.netProfitLoss >= 0 ? 'var(--success)' : 'var(--danger)'};">${formatMoney(netShareProfit)}</strong></td>
            <td><span class="badge ${isPayable ? 'badge-success' : 'badge-danger'}">${isPayable ? 'পাওনা: ' + formatMoney(netBalance) : 'বকেয়া: ' + formatMoney(Math.abs(netBalance))}</span></td>
            <td>
              <button class="btn btn-secondary" style="padding:0.25rem 0.5rem; font-size:0.75rem;" onclick="app.viewMemberStatement('${m.id}')">স্টেটমেন্ট</button>
            </td>
          </tr>
        `;
      }).join('');
    }

    // Daily Feed Entries
    renderFeed() {
      const tbody = document.getElementById('feedTableBody');
      if (!tbody) return;

      const search = (document.getElementById('searchFeed')?.value || '').toLowerCase();
      const pondFilter = document.getElementById('filterFeedPond')?.value || '';
      const typeFilter = document.getElementById('filterFeedType')?.value || '';

      const list = (this.data.feed || []).filter(f => {
        const matchSearch = (f.feedBrand || '').toLowerCase().includes(search) || (f.date || '').includes(search) || (f.feedName || '').toLowerCase().includes(search);
        const matchPond = !pondFilter || f.pondId === pondFilter;
        const matchType = !typeFilter || f.feedType === typeFilter;
        return matchSearch && matchPond && matchType;
      });

      // Update Top Stat Highlights
      const t = this.calculateTotals();
      document.getElementById('feedStatToday').textContent = `${formatNumber(t.todayFeedKg)} কেজি`;
      document.getElementById('feedStatTodayCost').textContent = `মূল্য: ${formatMoney(t.todayFeedCost)}`;
      document.getElementById('feedStat7Days').textContent = `${formatNumber(t.totalFeedKg)} কেজি`;
      document.getElementById('feedStatThisMonth').textContent = `${formatNumber(t.totalFeedKg)} কেজি`;
      document.getElementById('feedStatFloatingSinking').textContent = `${formatNumber(t.floatingFeedKg)} / ${formatNumber(t.sinkingFeedKg)} কেজি`;
      document.getElementById('feedStatMorningEvening').textContent = `সকাল: ${formatNumber(t.morningFeedKg)} | বিকাল: ${formatNumber(t.eveningFeedKg)} কেজি`;

      if (list.length === 0) {
        tbody.innerHTML = '<tr><td colspan="11" style="text-align:center; padding:2rem; color:var(--text-muted);">খাদ্য প্রদানের কোনো রেকর্ড পাওয়া যায়নি।</td></tr>';
        return;
      }

      list.sort((a, b) => new Date(b.date) - new Date(a.date));

      tbody.innerHTML = list.map(f => {
        const pond = (this.data.ponds || []).find(p => p.id === f.pondId);
        const pondName = pond ? pond.name : (f.pondId || 'পুকুর');
        return `
          <tr>
            <td>${f.date}</td>
            <td><strong>${pondName}</strong></td>
            <td><span class="badge badge-info">${f.time}</span></td>
            <td><span class="badge ${f.feedType === 'ভাসা ফিড' ? 'badge-success' : 'badge-warning'}">${f.feedType}</span></td>
            <td><strong>${f.feedBrand}</strong> ${f.feedName ? `(${f.feedName})` : ''}</td>
            <td><strong style="color:var(--primary);">${formatNumber(f.amountKg)} কেজি</strong></td>
            <td>${formatMoney(f.pricePerKg)}</td>
            <td><strong>${formatMoney(f.totalCost)}</strong></td>
            <td>${f.givenBy || '-'}</td>
            <td><small>${f.notes || '-'}</small></td>
            <td>
              <div class="action-btn-group">
                <button class="btn-icon delete" title="ডিলিট" onclick="app.requestDelete('feed', '${f.id}', '${f.date} - ${f.feedBrand}')">🗑️</button>
              </div>
            </td>
          </tr>
        `;
      }).join('');
    }

    showAddFeedModal() {
      document.getElementById('modalFeedTitle').textContent = '🌾 দৈনিক খাদ্য প্রদানের এন্ট্রি';
      document.getElementById('formFeed').reset();
      document.getElementById('feedId').value = '';
      document.getElementById('feedDate').value = getTodayString();
      document.getElementById('feedPricePerKg').value = '68';
      this.populateSelectDropdowns();
      this.showModal('modalFeed');
    }

    saveFeed(e) {
      e.preventDefault();
      const kg = Number(document.getElementById('feedAmountKg').value) || 0;
      const rate = Number(document.getElementById('feedPricePerKg').value) || 0;
      const feedData = {
        id: `FD-${Date.now()}`,
        date: document.getElementById('feedDate').value,
        pondId: document.getElementById('feedPondId').value,
        time: document.getElementById('feedTime').value,
        feedType: document.getElementById('feedTypeInput').value,
        feedBrand: document.getElementById('feedBrand').value.trim(),
        feedName: document.getElementById('feedName').value.trim(),
        amountKg: kg,
        pricePerKg: rate,
        totalCost: Math.round(kg * rate),
        givenBy: document.getElementById('feedGivenBy').value.trim(),
        notes: document.getElementById('feedNotes').value.trim()
      };

      this.data.feed.push(feedData);
      this.saveData();
      this.closeModal('modalFeed');
      this.showToast('খাদ্য প্রদানের তথ্য সফলভাবে রেকর্ড করা হয়েছে।', 'success');
      this.renderFeed();
    }

    // Feed Stock Management
    renderFeedStock() {
      const summaryTbody = document.getElementById('feedStockSummaryTableBody');
      const historyTbody = document.getElementById('feedStockHistoryTableBody');

      // Purchased aggregated by name
      const purchasedByName = {};
      (this.data.feedStock || []).forEach(fs => {
        const key = fs.feedName;
        if (!purchasedByName[key]) {
          purchasedByName[key] = {
            name: key,
            type: fs.feedType,
            totalKg: 0,
            totalCost: 0
          };
        }
        purchasedByName[key].totalKg += Number(fs.quantityKg) || 0;
        purchasedByName[key].totalCost += Number(fs.totalCost) || 0;
      });

      // Used aggregated by name
      const usedByName = {};
      (this.data.feed || []).forEach(f => {
        const key = f.feedName || f.feedBrand;
        usedByName[key] = (usedByName[key] || 0) + (Number(f.amountKg) || 0);
      });

      if (summaryTbody) {
        const names = Object.keys(purchasedByName);
        if (names.length === 0) {
          summaryTbody.innerHTML = '<tr><td colspan="7" style="text-align:center; padding:2rem; color:var(--text-muted);">খাদ্য স্টকে কোনো তথ্য নেই।</td></tr>';
        } else {
          summaryTbody.innerHTML = names.map(n => {
            const p = purchasedByName[n];
            const used = usedByName[n] || 0;
            const remaining = Math.max(0, p.totalKg - used);
            const avgRate = p.totalKg > 0 ? (p.totalCost / p.totalKg).toFixed(1) : 0;
            const isLow = remaining < 50;

            return `
              <tr>
                <td><strong>${p.name}</strong></td>
                <td><span class="badge ${p.type === 'ভাসা ফিড' ? 'badge-success' : 'badge-warning'}">${p.type}</span></td>
                <td>${formatNumber(p.totalKg)} কেজি</td>
                <td>${formatNumber(used)} কেজি</td>
                <td><strong style="color:${isLow ? 'var(--danger)' : 'var(--success)'}; font-size:1.05rem;">${formatNumber(remaining)} কেজি</strong></td>
                <td>${formatMoney(avgRate)}</td>
                <td><span class="badge ${isLow ? 'badge-danger' : 'badge-success'}">${isLow ? '⚠️ কম স্টক' : '✓ পর্যাপ্ত'}</span></td>
              </tr>
            `;
          }).join('');
        }
      }

      if (historyTbody) {
        const list = (this.data.feedStock || []).slice().reverse();
        if (list.length === 0) {
          historyTbody.innerHTML = '<tr><td colspan="9" style="text-align:center; padding:2rem; color:var(--text-muted);">ক্রয় ইতিহাস নেই।</td></tr>';
        } else {
          historyTbody.innerHTML = list.map(s => `
            <tr>
              <td>${s.date}</td>
              <td><strong>${s.feedName}</strong></td>
              <td><span class="badge badge-info">${s.feedType}</span></td>
              <td>${formatNumber(s.quantityKg)} কেজি</td>
              <td>${formatMoney(s.pricePerKg)}</td>
              <td><strong>${formatMoney(s.totalCost)}</strong></td>
              <td>${s.supplier || '-'}</td>
              <td>${s.invoice || '-'}</td>
              <td>
                <button class="btn-icon delete" title="ডিলিট" onclick="app.requestDelete('feedStock', '${s.id}', '${s.feedName}')">🗑️</button>
              </td>
            </tr>
          `).join('');
        }
      }
    }

    saveFeedStock(e) {
      e.preventDefault();
      const kg = Number(document.getElementById('stockQuantityKg').value) || 0;
      const rate = Number(document.getElementById('stockPricePerKg').value) || 0;

      const stockData = {
        id: `FS-${Date.now()}`,
        date: document.getElementById('stockDate').value,
        feedName: document.getElementById('stockFeedName').value.trim(),
        feedType: document.getElementById('stockFeedType').value,
        quantityKg: kg,
        pricePerKg: rate,
        totalCost: Math.round(kg * rate),
        supplier: document.getElementById('stockSupplier').value.trim(),
        invoice: document.getElementById('stockInvoice').value.trim(),
        notes: document.getElementById('stockNotes').value.trim()
      };

      this.data.feedStock.push(stockData);
      this.saveData();
      this.closeModal('modalFeedStock');
      this.showToast('খাদ্য স্টক সফলভাবে যুক্ত হয়েছে।', 'success');
      this.renderFeedStock();
    }

    // Fish Purchase
    renderFishPurchase() {
      const tbody = document.getElementById('fishPurchaseTableBody');
      if (!tbody) return;

      const search = (document.getElementById('searchFishPurchase')?.value || '').toLowerCase();
      const list = (this.data.fishPurchases || []).filter(fp => {
        return (fp.fishName || '').toLowerCase().includes(search) || (fp.supplier || '').toLowerCase().includes(search);
      });

      const total = list.reduce((sum, fp) => sum + (Number(fp.totalCost) || 0), 0);
      document.getElementById('fishPurchaseTotalSummary').textContent = `মোট ক্রয়: ${formatMoney(total)}`;

      if (list.length === 0) {
        tbody.innerHTML = '<tr><td colspan="12" style="text-align:center; padding:2rem; color:var(--text-muted);">মাছ ক্রয়ের কোনো তথ্য নেই।</td></tr>';
        return;
      }

      tbody.innerHTML = list.map(fp => {
        const pond = (this.data.ponds || []).find(p => p.id === fp.pondId);
        return `
          <tr>
            <td>${fp.date}</td>
            <td><strong>${pond ? pond.name : fp.pondId}</strong></td>
            <td><strong>${fp.fishName}</strong></td>
            <td><span class="badge badge-info">${fp.type}</span></td>
            <td>${formatNumber(fp.count)} টি</td>
            <td>${fp.weightKg ? formatNumber(fp.weightKg) + ' কেজি' : '-'}</td>
            <td>-</td>
            <td>${formatMoney(fp.fishCost)}</td>
            <td>${formatMoney(Number(fp.transportCost || 0) + Number(fp.otherCost || 0))}</td>
            <td><strong style="color:var(--danger);">${formatMoney(fp.totalCost)}</strong></td>
            <td>${fp.supplier || '-'}</td>
            <td>
              <button class="btn-icon delete" title="ডিলিট" onclick="app.requestDelete('fishPurchases', '${fp.id}', '${fp.fishName}')">🗑️</button>
            </td>
          </tr>
        `;
      }).join('');
    }

    showAddFishPurchaseModal() {
      document.getElementById('formFishPurchase').reset();
      document.getElementById('fishPurchaseId').value = '';
      document.getElementById('fpDate').value = getTodayString();
      this.populateSelectDropdowns();
      this.showModal('modalFishPurchase');
    }

    saveFishPurchase(e) {
      e.preventDefault();
      const cost = Number(document.getElementById('fpFishCost').value) || 0;
      const trans = Number(document.getElementById('fpTransportCost').value) || 0;
      const other = Number(document.getElementById('fpOtherCost').value) || 0;
      const total = cost + trans + other;

      const data = {
        id: `FP-${Date.now()}`,
        date: document.getElementById('fpDate').value,
        pondId: document.getElementById('fpPondId').value,
        fishName: document.getElementById('fpFishName').value.trim(),
        type: document.getElementById('fpType').value,
        count: Number(document.getElementById('fpCount').value) || 0,
        weightKg: Number(document.getElementById('fpWeightKg').value) || 0,
        fishCost: cost,
        transportCost: trans,
        otherCost: other,
        totalCost: total,
        supplier: document.getElementById('fpSupplier').value.trim(),
        notes: document.getElementById('fpNotes').value.trim()
      };

      this.data.fishPurchases.push(data);
      this.saveData();
      this.closeModal('modalFishPurchase');
      this.showToast('পোনা মাছ ক্রয় রেকর্ড সংরক্ষিত হয়েছে।', 'success');
      this.renderFishPurchase();
    }

    // Fish Sales
    renderFishSale() {
      const tbody = document.getElementById('fishSaleTableBody');
      if (!tbody) return;

      const search = (document.getElementById('searchFishSale')?.value || '').toLowerCase();
      const list = (this.data.fishSales || []).filter(fs => {
        return (fs.customerName || '').toLowerCase().includes(search) || (fs.fishName || '').toLowerCase().includes(search);
      });

      const totalSale = list.reduce((sum, fs) => sum + (Number(fs.totalSale) || 0), 0);
      const totalDue = list.reduce((sum, fs) => sum + (Number(fs.dueAmount) || 0), 0);
      document.getElementById('fishSaleTotalSummary').textContent = `মোট বিক্রয়: ${formatMoney(totalSale)} | বকেয়া: ${formatMoney(totalDue)}`;

      if (list.length === 0) {
        tbody.innerHTML = '<tr><td colspan="11" style="text-align:center; padding:2rem; color:var(--text-muted);">মাছ বিক্রয়ের কোনো রেকর্ড নেই।</td></tr>';
        return;
      }

      tbody.innerHTML = list.map(fs => {
        const pond = (this.data.ponds || []).find(p => p.id === fs.pondId);
        return `
          <tr>
            <td>${fs.date}</td>
            <td><strong>${pond ? pond.name : fs.pondId}</strong></td>
            <td><strong>${fs.fishName}</strong></td>
            <td>${fs.count ? formatNumber(fs.count) + ' পিস' : '-'}</td>
            <td><strong>${formatNumber(fs.weightKg)} কেজি</strong></td>
            <td>${formatMoney(fs.pricePerKg)}</td>
            <td><strong style="color:var(--success); font-size:1.05rem;">${formatMoney(fs.totalSale)}</strong></td>
            <td>${fs.customerName} <small>(${fs.customerPhone || '-'})</small></td>
            <td><span class="badge ${fs.paymentStatus === 'পরিশোধ' ? 'badge-success' : 'badge-warning'}">${fs.paymentStatus}</span></td>
            <td>${formatMoney(fs.paidAmount)} / ${formatMoney(fs.dueAmount)}</td>
            <td>
              <button class="btn-icon delete" title="ডিলিট" onclick="app.requestDelete('fishSales', '${fs.id}', '${fs.fishName}')">🗑️</button>
            </td>
          </tr>
        `;
      }).join('');
    }

    showAddFishSaleModal() {
      document.getElementById('formFishSale').reset();
      document.getElementById('fishSaleId').value = '';
      document.getElementById('fsDate').value = getTodayString();
      this.populateSelectDropdowns();
      this.showModal('modalFishSale');
    }

    saveFishSale(e) {
      e.preventDefault();
      const kg = Number(document.getElementById('fsWeightKg').value) || 0;
      const rate = Number(document.getElementById('fsPricePerKg').value) || 0;
      const total = Math.round(kg * rate);
      const paid = Number(document.getElementById('fsPaidAmount').value) || total;
      const due = Math.max(0, total - paid);

      const data = {
        id: `FSALE-${Date.now()}`,
        date: document.getElementById('fsDate').value,
        pondId: document.getElementById('fsPondId').value,
        fishName: document.getElementById('fsFishName').value.trim(),
        count: Number(document.getElementById('fsCount').value) || 0,
        weightKg: kg,
        pricePerKg: rate,
        totalSale: total,
        customerName: document.getElementById('fsCustomerName').value.trim(),
        customerPhone: document.getElementById('fsCustomerPhone').value.trim(),
        paymentStatus: due === 0 ? 'পরিশোধ' : (paid > 0 ? 'আংশিক' : 'বকেয়া'),
        paidAmount: paid,
        dueAmount: due,
        notes: document.getElementById('fsNotes').value.trim()
      };

      this.data.fishSales.push(data);
      this.saveData();
      this.closeModal('modalFishSale');
      this.showToast('মাছ বিক্রয় রেকর্ড সফলভাবে সংরক্ষিত হয়েছে।', 'success');
      this.renderFishSale();
    }

    // Dead Fish Log
    renderDeadFish() {
      const tbody = document.getElementById('deadFishTableBody');
      if (!tbody) return;

      const t = this.calculateTotals();
      document.getElementById('deadFishToday').textContent = `${formatNumber(t.todayDeadFish)} টি`;
      document.getElementById('deadFishThisMonth').textContent = `${formatNumber(t.totalDeadFishCount)} টি`;
      document.getElementById('deadFishTotal').textContent = `${formatNumber(t.totalDeadFishCount)} টি`;
      document.getElementById('deadFishTotalWeight').textContent = `ওজন: আনুমানিক ${formatNumber(t.totalDeadFishWeight)} কেজি`;

      const list = (this.data.deadFish || []).slice().reverse();
      if (list.length === 0) {
        tbody.innerHTML = '<tr><td colspan="8" style="text-align:center; padding:2rem; color:var(--text-muted);">মৃত মাছের কোনো রেকর্ড নেই। (আলহামদুলিল্লাহ)</td></tr>';
        return;
      }

      tbody.innerHTML = list.map(df => {
        const pond = (this.data.ponds || []).find(p => p.id === df.pondId);
        return `
          <tr>
            <td>${df.date}</td>
            <td><strong>${pond ? pond.name : df.pondId}</strong></td>
            <td>${df.fishName || 'মাছ'}</td>
            <td><strong style="color:var(--danger);">${formatNumber(df.count)} টি</strong></td>
            <td>${df.weightKg ? formatNumber(df.weightKg) + ' কেজি' : '-'}</td>
            <td><span class="badge badge-danger">${df.cause}</span></td>
            <td><small>${df.notes || '-'}</small></td>
            <td>
              <button class="btn-icon delete" title="ডিলিট" onclick="app.requestDelete('deadFish', '${df.id}', '${df.count} টি মাছ')">🗑️</button>
            </td>
          </tr>
        `;
      }).join('');
    }

    showAddDeadFishModal() {
      document.getElementById('formDeadFish').reset();
      document.getElementById('deadFishId').value = '';
      document.getElementById('dfDate').value = getTodayString();
      this.populateSelectDropdowns();
      this.showModal('modalDeadFish');
    }

    saveDeadFish(e) {
      e.preventDefault();
      const data = {
        id: `DF-${Date.now()}`,
        date: document.getElementById('dfDate').value,
        pondId: document.getElementById('dfPondId').value,
        fishName: document.getElementById('dfFishName').value.trim(),
        count: Number(document.getElementById('dfCount').value) || 0,
        weightKg: Number(document.getElementById('dfWeightKg').value) || 0,
        cause: document.getElementById('dfCause').value,
        notes: document.getElementById('dfNotes').value.trim()
      };

      this.data.deadFish.push(data);
      this.saveData();
      this.closeModal('modalDeadFish');
      this.showToast('মৃত মাছের রেকর্ড সংরক্ষণ করা হয়েছে।', 'success');
      this.renderDeadFish();
    }

    // Daily Expenses
    renderExpenses() {
      const tbody = document.getElementById('expensesTableBody');
      if (!tbody) return;

      const search = (document.getElementById('searchExpenses')?.value || '').toLowerCase();
      const cat = document.getElementById('filterExpenseCategory')?.value || '';

      const list = (this.data.expenses || []).filter(ex => {
        const matchSearch = (ex.desc || '').toLowerCase().includes(search) || (ex.paidBy || '').toLowerCase().includes(search);
        const matchCat = !cat || ex.category === cat;
        return matchSearch && matchCat;
      });

      const total = list.reduce((sum, ex) => sum + (Number(ex.amount) || 0), 0);
      document.getElementById('expensesTotalSumBadge').textContent = `মোট খরচ: ${formatMoney(total)}`;

      if (list.length === 0) {
        tbody.innerHTML = '<tr><td colspan="10" style="text-align:center; padding:2rem; color:var(--text-muted);">খরচের কোনো তথ্য নেই।</td></tr>';
        return;
      }

      tbody.innerHTML = list.map(ex => {
        const pond = (this.data.ponds || []).find(p => p.id === ex.pondId);
        return `
          <tr>
            <td>${ex.date}</td>
            <td><strong>${pond ? pond.name : (ex.pondId || 'সাধারণ')}</strong></td>
            <td><span class="badge badge-warning">${ex.category}</span></td>
            <td>${ex.desc}</td>
            <td>${ex.quantity || '-'}</td>
            <td><strong style="color:var(--danger);">${formatMoney(ex.amount)}</strong></td>
            <td>${ex.paidBy || '-'}</td>
            <td>${ex.voucher || '-'}</td>
            <td><small>${ex.notes || '-'}</small></td>
            <td>
              <button class="btn-icon delete" title="ডিলিট" onclick="app.requestDelete('expenses', '${ex.id}', '${ex.desc}')">🗑️</button>
            </td>
          </tr>
        `;
      }).join('');
    }

    showAddExpenseModal() {
      document.getElementById('formExpense').reset();
      document.getElementById('expenseId').value = '';
      document.getElementById('expDate').value = getTodayString();
      this.populateSelectDropdowns();
      this.showModal('modalExpense');
    }

    saveExpense(e) {
      e.preventDefault();
      const data = {
        id: `EX-${Date.now()}`,
        date: document.getElementById('expDate').value,
        pondId: document.getElementById('expPondId').value,
        category: document.getElementById('expCategory').value,
        desc: document.getElementById('expDesc').value.trim(),
        quantity: document.getElementById('expQuantity').value.trim(),
        amount: Number(document.getElementById('expAmount').value) || 0,
        paidBy: document.getElementById('expPaidBy').value.trim(),
        voucher: document.getElementById('expVoucher').value.trim(),
        notes: document.getElementById('expNotes').value.trim()
      };

      this.data.expenses.push(data);
      this.saveData();
      this.closeModal('modalExpense');
      this.showToast('খরচ সফলভাবে যুক্ত হয়েছে।', 'success');
      this.renderExpenses();
    }

    // Income & Expense Ledger
    renderIncomeExpense() {
      const tbody = document.getElementById('incomeExpenseLedgerBody');
      if (!tbody) return;

      const t = this.calculateTotals();
      document.getElementById('ledgerTotalIncome').textContent = formatMoney(t.grandTotalIncome);
      document.getElementById('ledgerTotalExpense').textContent = formatMoney(t.grandTotalExpense);

      const netBox = document.getElementById('ledgerNetBox');
      const isProfit = t.netProfitLoss >= 0;
      netBox.className = `metric-card ${isProfit ? 'profit' : 'loss'}`;
      document.getElementById('ledgerNetTitle').textContent = isProfit ? 'নিট লাভ (Net Profit)' : 'নিট ক্ষতি (Net Loss)';
      document.getElementById('ledgerNetProfitLoss').textContent = formatMoney(Math.abs(t.netProfitLoss));
      document.getElementById('ledgerNetProfitLoss').style.color = isProfit ? 'var(--success)' : 'var(--danger)';

      // Consolidate ledger lines
      const ledger = [];

      (this.data.fishSales || []).forEach(fs => {
        ledger.push({
          date: fs.date,
          type: 'আয় (মাছ বিক্রয়)',
          pond: fs.pondId,
          cat: 'মাছ বিক্রয়',
          desc: `${fs.fishName} বিক্রয় - ${fs.customerName}`,
          income: Number(fs.totalSale) || 0,
          expense: 0
        });
      });

      (this.data.fishPurchases || []).forEach(fp => {
        ledger.push({
          date: fp.date,
          type: 'ব্যয় (মাছ ক্রয়)',
          pond: fp.pondId,
          cat: 'মাছ ক্রয়',
          desc: `${fp.fishName} পোনা ক্রয় - ${fp.supplier}`,
          income: 0,
          expense: Number(fp.totalCost) || 0
        });
      });

      (this.data.feed || []).forEach(f => {
        ledger.push({
          date: f.date,
          type: 'ব্যয় (মাছের খাদ্য)',
          pond: f.pondId,
          cat: 'খাদ্য',
          desc: `${f.feedBrand} (${f.amountKg} কেজি)`,
          income: 0,
          expense: Number(f.totalCost) || 0
        });
      });

      (this.data.expenses || []).forEach(ex => {
        ledger.push({
          date: ex.date,
          type: 'ব্যয় (পরিচালন)',
          pond: ex.pondId,
          cat: ex.category,
          desc: ex.desc,
          income: 0,
          expense: Number(ex.amount) || 0
        });
      });

      ledger.sort((a, b) => new Date(a.date) - new Date(b.date));

      let runningBalance = 0;
      tbody.innerHTML = ledger.map(l => {
        runningBalance += (l.income - l.expense);
        return `
          <tr>
            <td>${l.date}</td>
            <td><span class="badge ${l.income > 0 ? 'badge-success' : 'badge-danger'}">${l.type}</span></td>
            <td>${l.pond || 'সাধারণ'}</td>
            <td>${l.cat}</td>
            <td>${l.desc}</td>
            <td style="color:var(--success); font-weight:700;">${l.income > 0 ? formatMoney(l.income) : '-'}</td>
            <td style="color:var(--danger); font-weight:700;">${l.expense > 0 ? formatMoney(l.expense) : '-'}</td>
            <td><strong style="color:${runningBalance >= 0 ? 'var(--success)' : 'var(--danger)'};">${formatMoney(runningBalance)}</strong></td>
          </tr>
        `;
      }).join('');
    }

    // Monthly Report Generator
    generateMonthlyReport() {
      const container = document.getElementById('monthlyReportContent');
      if (!container) return;

      const year = Number(document.getElementById('monthlyReportYear')?.value || 2026);
      const monthIdx = Number(document.getElementById('monthlyReportMonth')?.value || 8); // 8 is Sep
      const monthNames = ['জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন', 'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'];

      const prefix = `${year}-${String(monthIdx + 1).padStart(2, '0')}`;

      // Filter month items
      const mFeed = (this.data.feed || []).filter(f => f.date.startsWith(prefix));
      const mFeedStock = (this.data.feedStock || []).filter(fs => fs.date.startsWith(prefix));
      const mSales = (this.data.fishSales || []).filter(s => s.date.startsWith(prefix));
      const mPurchases = (this.data.fishPurchases || []).filter(p => p.date.startsWith(prefix));
      const mDead = (this.data.deadFish || []).filter(d => d.date.startsWith(prefix));
      const mExpenses = (this.data.expenses || []).filter(e => e.date.startsWith(prefix));

      const feedKg = mFeed.reduce((sum, f) => sum + (Number(f.amountKg) || 0), 0);
      const feedCost = mFeed.reduce((sum, f) => sum + (Number(f.totalCost) || 0), 0);
      const salesTotal = mSales.reduce((sum, s) => sum + (Number(s.totalSale) || 0), 0);
      const purchaseTotal = mPurchases.reduce((sum, p) => sum + (Number(p.totalCost) || 0), 0);
      const expTotal = mExpenses.reduce((sum, e) => sum + (Number(e.amount) || 0), 0);
      const deadCount = mDead.reduce((sum, d) => sum + (Number(d.count) || 0), 0);

      const totalMonthlyExp = feedCost + purchaseTotal + expTotal;
      const netMonthly = salesTotal - totalMonthlyExp;

      container.innerHTML = `
        <div style="border-bottom:2px solid var(--border); padding-bottom:1rem; margin-bottom:1.25rem;">
          <h2 style="color:var(--primary); font-size:1.4rem;">আল কারীম পুকুর ম্যানেজমেন্ট - মাসিক হিসাব প্রতিবেদন</h2>
          <div style="font-size:1rem; font-weight:700; color:var(--text-main);">মাস: ${monthNames[monthIdx]} ${year}</div>
        </div>

        <div class="metrics-grid" style="margin-bottom:1.5rem;">
          <div class="metric-card">
            <div class="metric-info">
              <h3>মোট খাদ্য প্রয়োগ</h3>
              <div class="metric-value">${formatNumber(feedKg)} কেজি</div>
              <div class="metric-sub">মূল্য: ${formatMoney(feedCost)}</div>
            </div>
          </div>
          <div class="metric-card info">
            <div class="metric-info">
              <h3>মাছ ক্রয় ব্যয়</h3>
              <div class="metric-value">${formatMoney(purchaseTotal)}</div>
            </div>
          </div>
          <div class="metric-card profit">
            <div class="metric-info">
              <h3>মাছ বিক্রয় আয়</h3>
              <div class="metric-value">${formatMoney(salesTotal)}</div>
            </div>
          </div>
          <div class="metric-card ${netMonthly >= 0 ? 'profit' : 'loss'}">
            <div class="metric-info">
              <h3>চলতি মাসের নিট লাভ/ক্ষতি</h3>
              <div class="metric-value">${formatMoney(Math.abs(netMonthly))}</div>
              <div class="metric-sub">${netMonthly >= 0 ? '✓ নিট লাভ' : '⚠️ নিট ক্ষতি'}</div>
            </div>
          </div>
        </div>

        <h4 style="margin-bottom:0.75rem; color:var(--primary);">মাসিক শেয়ারহোল্ডার ডিভিডেন্ড / ক্ষতির বন্টন বিবরণী (মোট ৮ শেয়ার):</h4>
        <div class="table-responsive">
          <table class="custom-table">
            <thead>
              <tr>
                <th>সদস্য আইডি</th>
                <th>সদস্যের নাম</th>
                <th>শেয়ার</th>
                <th>অংশ (%)</th>
                <th>মাসিক খরচের ভাগ (৳)</th>
                <th>মাসিক বিক্রয়ের ভাগ (৳)</th>
                <th>মাসিক নিট প্রাপ্তি / দেনা (৳)</th>
              </tr>
            </thead>
            <tbody>
              ${(this.data.members || []).map(m => {
                const ratio = m.shares / (this.data.samity.totalShares || 8.0);
                const expShare = Math.round(totalMonthlyExp * ratio);
                const saleShare = Math.round(salesTotal * ratio);
                const netShare = Math.round(netMonthly * ratio);
                return `
                  <tr>
                    <td><strong>${m.code}</strong></td>
                    <td>${m.name}</td>
                    <td>${m.shares}</td>
                    <td>${(ratio * 100).toFixed(2)}%</td>
                    <td>${formatMoney(expShare)}</td>
                    <td>${formatMoney(saleShare)}</td>
                    <td><strong style="color:${netShare >= 0 ? 'var(--success)' : 'var(--danger)'};">${formatMoney(netShare)}</strong></td>
                  </tr>
                `;
              }).join('')}
            </tbody>
          </table>
        </div>
      `;
    }

    // Yearly Report Generator
    generateYearlyReport() {
      const container = document.getElementById('yearlyReportContent');
      if (!container) return;

      const year = Number(document.getElementById('yearlyReportYear')?.value || 2026);
      const monthNames = ['জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন', 'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'];

      const rows = [];
      let grandYearExpense = 0;
      let grandYearIncome = 0;

      for (let m = 0; m < 12; m++) {
        const prefix = `${year}-${String(m + 1).padStart(2, '0')}`;
        const mFeed = (this.data.feed || []).filter(f => f.date.startsWith(prefix));
        const mSales = (this.data.fishSales || []).filter(s => s.date.startsWith(prefix));
        const mPurchases = (this.data.fishPurchases || []).filter(p => p.date.startsWith(prefix));
        const mExpenses = (this.data.expenses || []).filter(e => e.date.startsWith(prefix));

        const feedCost = mFeed.reduce((sum, f) => sum + (Number(f.totalCost) || 0), 0);
        const purchaseCost = mPurchases.reduce((sum, p) => sum + (Number(p.totalCost) || 0), 0);
        const opCost = mExpenses.reduce((sum, e) => sum + (Number(e.amount) || 0), 0);
        const salesAmt = mSales.reduce((sum, s) => sum + (Number(s.totalSale) || 0), 0);

        const totalCost = feedCost + purchaseCost + opCost;
        const net = salesAmt - totalCost;

        grandYearExpense += totalCost;
        grandYearIncome += salesAmt;

        rows.push({
          month: monthNames[m],
          feedCost,
          totalCost,
          salesAmt,
          net
        });
      }

      const grandYearNet = grandYearIncome - grandYearExpense;

      container.innerHTML = `
        <div style="border-bottom:2px solid var(--border); padding-bottom:1rem; margin-bottom:1.25rem;">
          <h2 style="color:var(--primary); font-size:1.4rem;">আল কারীম পুকুর ম্যানেজমেন্ট - বার্ষিক অডিট বিবরণী (${year})</h2>
          <div style="font-size:0.95rem; color:var(--text-muted);">১২ মাসের মাসভিত্তিক আয়, ব্যয় ও নিট মুনাফার তুলনামূলক চিত্র</div>
        </div>

        <div class="metrics-grid" style="margin-bottom:1.5rem;">
          <div class="metric-card loss">
            <div class="metric-info">
              <h3>বার্ষিক মোট ব্যয়</h3>
              <div class="metric-value">${formatMoney(grandYearExpense)}</div>
            </div>
          </div>
          <div class="metric-card profit">
            <div class="metric-info">
              <h3>বার্ষিক মোট আয়</h3>
              <div class="metric-value">${formatMoney(grandYearIncome)}</div>
            </div>
          </div>
          <div class="metric-card ${grandYearNet >= 0 ? 'profit' : 'loss'}">
            <div class="metric-info">
              <h3>বার্ষিক নিট লাভ/ক্ষতি</h3>
              <div class="metric-value">${formatMoney(Math.abs(grandYearNet))}</div>
              <div class="metric-sub">${grandYearNet >= 0 ? '✓ বার্ষিক লাভ' : '⚠️ বার্ষিক ক্ষতি'}</div>
            </div>
          </div>
        </div>

        <div class="table-responsive">
          <table class="custom-table">
            <thead>
              <tr>
                <th>মাস</th>
                <th>খাদ্য খরচ (৳)</th>
                <th>সর্বমোট ব্যয় (৳)</th>
                <th>মাছ বিক্রয় আয় (৳)</th>
                <th>নিট লাভ / ক্ষতি (৳)</th>
                <th>অবস্থা</th>
              </tr>
            </thead>
            <tbody>
              ${rows.map(r => `
                <tr>
                  <td><strong>${r.month}</strong></td>
                  <td>${formatMoney(r.feedCost)}</td>
                  <td><strong style="color:var(--danger);">${formatMoney(r.totalCost)}</strong></td>
                  <td><strong style="color:var(--success);">${formatMoney(r.salesAmt)}</strong></td>
                  <td><strong style="color:${r.net >= 0 ? 'var(--success)' : 'var(--danger)'};">${formatMoney(Math.abs(r.net))}</strong></td>
                  <td><span class="badge ${r.net >= 0 ? 'badge-success' : 'badge-danger'}">${r.net >= 0 ? 'লাভ' : 'ঘাটতি'}</span></td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      `;
    }

    // Individual Member Account Statement
    viewMemberStatement(id) {
      this.switchView('memberAccounts');
      const select = document.getElementById('selectMemberAccount');
      if (select) {
        select.value = id;
        this.renderMemberAccount();
      }
    }

    renderMemberAccount() {
      const container = document.getElementById('memberAccountStatementBox');
      if (!container) return;

      const memberId = document.getElementById('selectMemberAccount')?.value;
      const member = (this.data.members || []).find(m => m.id === memberId) || (this.data.members || [])[0];

      if (!member) {
        container.innerHTML = '<div style="padding:2rem; text-align:center;">সদস্য নির্বাচন করুন।</div>';
        return;
      }

      const t = this.calculateTotals();
      const ratio = member.shares / (this.data.samity.totalShares || 8.0);
      const sharePct = (ratio * 100).toFixed(2);
      const expenseShare = Math.round(t.grandTotalExpense * ratio);
      const profitShare = Math.round(t.grandTotalIncome * ratio);
      const netProfitShare = Math.round(t.netProfitLoss * ratio);
      const netEquity = Math.round(member.deposit - expenseShare + netProfitShare);

      container.innerHTML = `
        <div style="border-bottom:2px solid var(--border); padding-bottom:1rem; margin-bottom:1.5rem; display:flex; justify-content:space-between; align-items:flex-start;">
          <div>
            <h2 style="color:var(--primary); font-size:1.3rem;">সদস্য ব্যক্তিগত খতিয়ান ও হিসাব বিবরণী</h2>
            <div style="font-size:1.1rem; font-weight:700; margin-top:0.35rem;">${member.name} (${member.code})</div>
            <div style="font-size:0.85rem; color:var(--text-muted);">পিতা: ${member.father || '-'} | ফোন: ${member.phone}</div>
          </div>
          <div style="text-align:right;">
            <div class="badge badge-warning" style="font-size:1rem; padding:0.4rem 0.85rem;">মালিকানা: ${member.shares} শেয়ার (${sharePct}%)</div>
            <div style="font-size:0.8rem; color:var(--text-muted); margin-top:0.35rem;">যোগদান: ${member.joinDate || '২০২৬-০১-০১'}</div>
          </div>
        </div>

        <div class="metrics-grid" style="margin-bottom:1.5rem;">
          <div class="metric-card gold">
            <div class="metric-info">
              <h3>মোট জমা / বিনিয়োগ</h3>
              <div class="metric-value">${formatMoney(member.deposit)}</div>
            </div>
          </div>
          <div class="metric-card loss">
            <div class="metric-info">
              <h3>মোট খরচের দায়</h3>
              <div class="metric-value">${formatMoney(expenseShare)}</div>
            </div>
          </div>
          <div class="metric-card profit">
            <div class="metric-info">
              <h3>মোট আয়ের অংশ</h3>
              <div class="metric-value">${formatMoney(profitShare)}</div>
            </div>
          </div>
          <div class="metric-card ${netEquity >= 0 ? 'profit' : 'loss'}">
            <div class="metric-info">
              <h3>বর্তমান নিট ব্যালেন্স</h3>
              <div class="metric-value">${formatMoney(Math.abs(netEquity))}</div>
              <div class="metric-sub">${netEquity >= 0 ? '✓ সমিতির নিকট পাওনা' : '⚠️ সমিতির বকেয়া দায়'}</div>
            </div>
          </div>
        </div>

        <h4 style="margin-bottom:0.75rem; color:var(--primary);">আর্থিক লেনদেন সারসংক্ষেপ:</h4>
        <div class="table-responsive">
          <table class="custom-table">
            <thead>
              <tr>
                <th>হিসাবের খাত</th>
                <th>সমিতির মোট টাকা (৳)</th>
                <th>সদস্যের অংশ (%)</th>
                <th>সদস্যের প্রাপ্য / প্রদেয় টাকা (৳)</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>সদস্যের নিজস্ব মোট মূলধন জমা</td>
                <td>-</td>
                <td>-</td>
                <td style="color:var(--success); font-weight:700;">+ ${formatMoney(member.deposit)}</td>
              </tr>
              <tr>
                <td>মাছ ও পোনা ক্রয় খরচ অংশ</td>
                <td>${formatMoney(t.totalFishPurchaseCost)}</td>
                <td>${sharePct}%</td>
                <td style="color:var(--danger);">- ${formatMoney(Math.round(t.totalFishPurchaseCost * ratio))}</td>
              </tr>
              <tr>
                <td>মাছের খাদ্য বাবদ খরচ অংশ</td>
                <td>${formatMoney(t.totalFeedCost)}</td>
                <td>${sharePct}%</td>
                <td style="color:var(--danger);">- ${formatMoney(Math.round(t.totalFeedCost * ratio))}</td>
              </tr>
              <tr>
                <td>অন্যান্য পরিচালনা খরচ অংশ</td>
                <td>${formatMoney(t.totalOperatingExpense)}</td>
                <td>${sharePct}%</td>
                <td style="color:var(--danger);">- ${formatMoney(Math.round(t.totalOperatingExpense * ratio))}</td>
              </tr>
              <tr>
                <td>মাছ বিক্রয় লভ্যাংশ প্রাপ্তি</td>
                <td>${formatMoney(t.grandTotalIncome)}</td>
                <td>${sharePct}%</td>
                <td style="color:var(--success); font-weight:700;">+ ${formatMoney(profitShare)}</td>
              </tr>
              <tr style="background:var(--bg-main);">
                <td colspan="3"><strong>চূড়ান্ত নিট হিসাব ব্যালেন্স</strong></td>
                <td><strong style="font-size:1.1rem; color:${netEquity >= 0 ? 'var(--success)' : 'var(--danger)'};">${netEquity >= 0 ? 'পাওনা: ' + formatMoney(netEquity) : 'বকেয়া: ' + formatMoney(Math.abs(netEquity))}</strong></td>
              </tr>
            </tbody>
          </table>
        </div>
      `;
    }

    // Individual Pond Performance
    renderPondAccount() {
      const container = document.getElementById('pondAccountStatementBox');
      if (!container) return;

      const pondId = document.getElementById('selectPondAccount')?.value;
      const pond = (this.data.ponds || []).find(p => p.id === pondId) || (this.data.ponds || [])[0];

      if (!pond) {
        container.innerHTML = '<div style="padding:2rem; text-align:center;">পুকুর নির্বাচন করুন।</div>';
        return;
      }

      const pFeed = (this.data.feed || []).filter(f => f.pondId === pond.id);
      const pSales = (this.data.fishSales || []).filter(s => s.pondId === pond.id);
      const pPurchases = (this.data.fishPurchases || []).filter(p => p.pondId === pond.id);
      const pExpenses = (this.data.expenses || []).filter(e => e.pondId === pond.id);
      const pDead = (this.data.deadFish || []).filter(d => d.pondId === pond.id);

      const feedKg = pFeed.reduce((sum, f) => sum + (Number(f.amountKg) || 0), 0);
      const feedCost = pFeed.reduce((sum, f) => sum + (Number(f.totalCost) || 0), 0);
      const purchaseCost = pPurchases.reduce((sum, p) => sum + (Number(p.totalCost) || 0), 0);
      const expCost = pExpenses.reduce((sum, e) => sum + (Number(e.amount) || 0), 0);
      const salesAmt = pSales.reduce((sum, s) => sum + (Number(s.totalSale) || 0), 0);
      const deadCount = pDead.reduce((sum, d) => sum + (Number(d.count) || 0), 0);

      const totalPondExp = feedCost + purchaseCost + expCost;
      const pondProfit = salesAmt - totalPondExp;

      container.innerHTML = `
        <div style="border-bottom:2px solid var(--border); padding-bottom:1rem; margin-bottom:1.5rem;">
          <h2 style="color:var(--primary); font-size:1.3rem;">পুকুর পারফরম্যান্স ও হিসাব: ${pond.name}</h2>
          <div style="font-size:0.88rem; color:var(--text-muted);">আয়তন: ${pond.area} শতক | গভীরতা: ${pond.depth || '-'} ফুট | অবস্থান: ${pond.location}</div>
        </div>

        <div class="metrics-grid" style="margin-bottom:1.5rem;">
          <div class="metric-card">
            <div class="metric-info">
              <h3>মোট খাদ্য ব্যবহার</h3>
              <div class="metric-value">${formatNumber(feedKg)} কেজি</div>
              <div class="metric-sub">মূল্য: ${formatMoney(feedCost)}</div>
            </div>
          </div>
          <div class="metric-card info">
            <div class="metric-info">
              <h3>মাছ ক্রয় বাবদ ব্যয়</h3>
              <div class="metric-value">${formatMoney(purchaseCost)}</div>
            </div>
          </div>
          <div class="metric-card profit">
            <div class="metric-info">
              <h3>মাছ বিক্রয় আয়</h3>
              <div class="metric-value">${formatMoney(salesAmt)}</div>
            </div>
          </div>
          <div class="metric-card ${pondProfit >= 0 ? 'profit' : 'loss'}">
            <div class="metric-info">
              <h3>পুকুর নিট মুনাফা</h3>
              <div class="metric-value">${formatMoney(Math.abs(pondProfit))}</div>
              <div class="metric-sub">${pondProfit >= 0 ? '✓ লাভজনক' : '⚠️ ক্ষতি'}</div>
            </div>
          </div>
        </div>
      `;
    }

    // Printable Reports Section
    printSection(type) {
      if (type === 'members') this.switchView('members');
      else if (type === 'feed') this.switchView('feed');
      else if (type === 'fishSales') this.switchView('fishSale');
      else if (type === 'expenses') this.switchView('expenses');
      else if (type === 'profitLoss') this.switchView('incomeExpense');
      setTimeout(() => window.print(), 300);
    }

    // Trash & Recycle Bin
    requestDelete(entityType, id, title) {
      if (!this.checkAdminPermission('রেকর্ড ডিলিট')) return;

      this.pendingDelete = { entityType, id, title };
      document.getElementById('confirmTitle').textContent = 'আপনি কি নিশ্চিত?';
      document.getElementById('confirmMessage').textContent = `"${title}" রেকর্ডটি ট্র্যাশে সরানো হবে। প্রয়োজনে ট্র্যাশ থেকে রিস্টোর করতে পারবেন।`;
      this.showModal('modalConfirm');
    }

    executeDelete() {
      if (!this.pendingDelete) return;
      const { entityType, id, title } = this.pendingDelete;
      const list = this.data[entityType];
      if (!list) return;

      const idx = list.findIndex(item => item.id === id);
      if (idx !== -1) {
        const [removed] = list.splice(idx, 1);
        if (!this.data.trash) this.data.trash = [];
        this.data.trash.push({
          id: `TRASH-${Date.now()}`,
          entityType,
          originalItem: removed,
          title,
          deletedAt: new Date().toLocaleString('bn-BD')
        });
        this.saveData();
        this.showToast(`"${title}" ট্র্যাশে সরানো হয়েছে।`, 'warning');
        this.renderCurrentView();
      }
      this.closeModal('modalConfirm');
      this.pendingDelete = null;
    }

    renderTrash() {
      const tbody = document.getElementById('trashTableBody');
      if (!tbody) return;

      const trash = this.data.trash || [];
      if (trash.length === 0) {
        tbody.innerHTML = '<tr><td colspan="5" style="text-align:center; padding:2.5rem; color:var(--text-muted);">রিসাইকেল বিন সম্পূর্ণ খালি। কোনো মুছে ফেলা ডাটা নেই।</td></tr>';
        return;
      }

      tbody.innerHTML = trash.map((t, idx) => `
        <tr>
          <td>${t.originalItem.date || '-'}</td>
          <td><span class="badge badge-warning">${t.entityType}</span></td>
          <td><strong>${t.title}</strong></td>
          <td><small>${t.deletedAt}</small></td>
          <td>
            <div class="action-btn-group">
              <button class="btn btn-success" style="padding:0.25rem 0.5rem; font-size:0.75rem;" onclick="app.restoreTrashItem('${t.id}')">🔄 রিস্টোর</button>
              <button class="btn btn-danger" style="padding:0.25rem 0.5rem; font-size:0.75rem;" onclick="app.permanentDeleteTrashItem('${t.id}')">মুছে ফেলুন</button>
            </div>
          </td>
        </tr>
      `).join('');
    }

    restoreTrashItem(trashId) {
      const idx = this.data.trash.findIndex(t => t.id === trashId);
      if (idx === -1) return;

      const trashItem = this.data.trash[idx];
      const targetList = this.data[trashItem.entityType];
      if (targetList) {
        targetList.push(trashItem.originalItem);
        this.data.trash.splice(idx, 1);
        this.saveData();
        this.showToast(`"${trashItem.title}" সফলভাবে পুনরুদ্ধার (রিস্টোর) করা হয়েছে।`, 'success');
        this.renderTrash();
      }
    }

    permanentDeleteTrashItem(trashId) {
      if (!this.checkAdminPermission('স্থায়ীভাবে মুছে ফেলা')) return;
      this.data.trash = (this.data.trash || []).filter(t => t.id !== trashId);
      this.saveData();
      this.showToast('রেকর্ডটি স্থায়ীভাবে মুছে ফেলা হয়েছে।', 'danger');
      this.renderTrash();
    }

    emptyTrashPermanent() {
      if (!this.checkAdminPermission('ট্র্যাশ খালি করা')) return;
      if (confirm('আপনি কি ট্র্যাশের সমস্ত ডাটা স্থায়ীভাবে মুছে ফেলতে চান? এটি আর ফিরিয়ে আনা যাবে না!')) {
        this.data.trash = [];
        this.saveData();
        this.showToast('ট্র্যাশ সম্পূর্ণ খালি করা হয়েছে।', 'danger');
        this.renderTrash();
      }
    }

    // Settings & Backup/Restore
    renderSettings() {
      document.getElementById('settingSamityName').value = this.data.samity.name || 'আল কারীম';
      document.getElementById('settingTotalShares').value = this.data.samity.totalShares || 8.0;
      document.getElementById('settingAddress').value = this.data.samity.address || '';
      document.getElementById('settingRegNo').value = this.data.samity.regNo || '';
    }

    saveSamitySettings(e) {
      e.preventDefault();
      this.data.samity.name = document.getElementById('settingSamityName').value.trim();
      this.data.samity.totalShares = Number(document.getElementById('settingTotalShares').value) || 8.0;
      this.data.samity.address = document.getElementById('settingAddress').value.trim();
      this.data.samity.regNo = document.getElementById('settingRegNo').value.trim();

      document.getElementById('headerSamityName').textContent = `${this.data.samity.name} সমবায় সমিতি`;
      this.saveData();
      this.showToast('সমিতির তথ্য সফলভাবে সংরক্ষিত হয়েছে।', 'success');
    }

    downloadBackupJSON() {
      const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(this.data, null, 2));
      const downloadAnchor = document.createElement('a');
      const filename = `Al_Karim_Pond_Backup_${getTodayString()}.json`;
      downloadAnchor.setAttribute("href", dataStr);
      downloadAnchor.setAttribute("download", filename);
      document.body.appendChild(downloadAnchor);
      downloadAnchor.click();
      downloadAnchor.remove();
      this.showToast('সম্পূর্ণ ডাটা ব্যাকআপ ফাইল ডাউনলোড হয়েছে।', 'success');
    }

    restoreBackupJSON(event) {
      const file = event.target.files[0];
      if (!file) return;

      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const parsed = JSON.parse(e.target.result);
          if (parsed && parsed.ponds && parsed.members) {
            this.saveData(parsed);
            this.showToast('ব্যাকআপ সফলভাবে রিস্টোর করা হয়েছে!', 'success');
            setTimeout(() => location.reload(), 800);
          } else {
            this.showToast('অবৈধ ব্যাকআপ ফাইল ফরম্যাট!', 'danger');
          }
        } catch (err) {
          this.showToast('ফাইল পড়তে ত্রুটি হয়েছে।', 'danger');
        }
      };
      reader.readAsText(file);
    }

    exportMembersCSV() {
      const members = this.data.members || [];
      let csv = 'ID,Name,Phone,Shares,Deposit,JoinDate,Address\n';
      members.forEach(m => {
        csv += `"${m.code}","${m.name}","${m.phone}","${m.shares}","${m.deposit}","${m.joinDate || ''}","${m.address || ''}"\n`;
      });
      this.downloadBlob(csv, `Al_Karim_Members_${getTodayString()}.csv`, 'text/csv;charset=utf-8;');
    }

    exportAllExcelCSV() {
      this.exportMembersCSV();
      this.showToast('CSV ফাইল এক্সপোর্ট প্রস্তুত হয়েছে।', 'success');
    }

    downloadBlob(content, filename, mime) {
      const blob = new Blob(["\uFEFF" + content], { type: mime });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      a.remove();
    }

    confirmResetDemoData() {
      if (!this.checkAdminPermission('ডেমো ডাটা রিসেট')) return;
      if (confirm('আপনি কি সত্যিই প্রাথমিক ডেমো ডাটায় রিসেট করতে চান? বর্তমান সমস্ত পরিবর্তন মুছে যাবে!')) {
        const initial = getInitialDataset();
        this.saveData(initial);
        this.showToast('সফলভাবে প্রাথমিক ডাটায় রিসেট করা হয়েছে।', 'success');
        setTimeout(() => location.reload(), 600);
      }
    }

    // Modal Helpers
    showModal(modalId) {
      const modal = document.getElementById(modalId);
      if (modal) modal.classList.add('active');
    }

    closeModal(modalId) {
      const modal = document.getElementById(modalId);
      if (modal) modal.classList.remove('active');
    }

    // Toast Notifications
    showToast(message, type = 'info') {
      const container = document.getElementById('toastContainer');
      if (!container) return;

      const toast = document.createElement('div');
      toast.className = `toast toast-${type}`;
      const icons = { success: '✓', danger: '✕', warning: '⚠️', info: 'ℹ️' };
      toast.innerHTML = `<span>${icons[type] || 'ℹ️'}</span> <div>${message}</div>`;
      container.appendChild(toast);

      setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transition = 'opacity 0.3s';
        setTimeout(() => toast.remove(), 300);
      }, 3500);
    }

    // Event Bindings
    bindEvents() {
      // Sidebar Toggle
      document.getElementById('menuToggleBtn')?.addEventListener('click', () => this.toggleSidebar());
      document.getElementById('sidebarCloseBtn')?.addEventListener('click', () => this.toggleSidebar(false));
      document.getElementById('sidebarOverlay')?.addEventListener('click', () => this.toggleSidebar(false));

      // Theme toggle
      document.getElementById('themeToggleBtn')?.addEventListener('click', () => this.toggleTheme());

      // Quick Add Button
      document.getElementById('btnQuickAdd')?.addEventListener('click', () => this.showModal('modalQuickChooser'));

      // Sidebar Navigation
      document.querySelectorAll('.sidebar-menu .menu-item[data-view]').forEach(item => {
        item.addEventListener('click', (e) => {
          e.preventDefault();
          const view = item.getAttribute('data-view');
          this.switchView(view);
        });
      });

      // Logout & User Profile
      document.getElementById('userProfileBadge')?.addEventListener('click', () => this.showModal('modalUserProfile'));

      // Form Submissions
      document.getElementById('formPond')?.addEventListener('submit', (e) => this.savePond(e));
      document.getElementById('formMember')?.addEventListener('submit', (e) => this.saveMember(e));
      document.getElementById('formFeed')?.addEventListener('submit', (e) => this.saveFeed(e));
      document.getElementById('formFeedStock')?.addEventListener('submit', (e) => this.saveFeedStock(e));
      document.getElementById('formFishPurchase')?.addEventListener('submit', (e) => this.saveFishPurchase(e));
      document.getElementById('formFishSale')?.addEventListener('submit', (e) => this.saveFishSale(e));
      document.getElementById('formDeadFish')?.addEventListener('submit', (e) => this.saveDeadFish(e));
      document.getElementById('formExpense')?.addEventListener('submit', (e) => this.saveExpense(e));
      document.getElementById('formSamitySettings')?.addEventListener('submit', (e) => this.saveSamitySettings(e));

      // Confirm Delete Modal
      document.getElementById('confirmOkBtn')?.addEventListener('click', () => this.executeDelete());
      document.getElementById('confirmCancelBtn')?.addEventListener('click', () => {
        this.closeModal('modalConfirm');
        this.pendingDelete = null;
      });

      // Auto Calculations in Modals
      const feedKg = document.getElementById('feedAmountKg');
      const feedPrice = document.getElementById('feedPricePerKg');
      const feedTotal = document.getElementById('feedTotalCost');
      const calcFeedTotal = () => {
        if (feedKg && feedPrice && feedTotal) {
          feedTotal.value = Math.round((Number(feedKg.value) || 0) * (Number(feedPrice.value) || 0));
        }
      };
      feedKg?.addEventListener('input', calcFeedTotal);
      feedPrice?.addEventListener('input', calcFeedTotal);

      // Stock Cost Auto Calc
      const stockKg = document.getElementById('stockQuantityKg');
      const stockRate = document.getElementById('stockPricePerKg');
      const stockTotal = document.getElementById('stockTotalCost');
      const calcStockTotal = () => {
        if (stockKg && stockRate && stockTotal) {
          stockTotal.value = Math.round((Number(stockKg.value) || 0) * (Number(stockRate.value) || 0));
        }
      };
      stockKg?.addEventListener('input', calcStockTotal);
      stockRate?.addEventListener('input', calcStockTotal);

      // Fish Purchase Auto Calc
      const fpCost = document.getElementById('fpFishCost');
      const fpTrans = document.getElementById('fpTransportCost');
      const fpOther = document.getElementById('fpOtherCost');
      const fpTotal = document.getElementById('fpTotalCost');
      const calcFpTotal = () => {
        if (fpCost && fpTotal) {
          fpTotal.value = (Number(fpCost.value) || 0) + (Number(fpTrans?.value) || 0) + (Number(fpOther?.value) || 0);
        }
      };
      fpCost?.addEventListener('input', calcFpTotal);
      fpTrans?.addEventListener('input', calcFpTotal);
      fpOther?.addEventListener('input', calcFpTotal);

      // Fish Sale Auto Calc
      const fsKg = document.getElementById('fsWeightKg');
      const fsRate = document.getElementById('fsPricePerKg');
      const fsTotal = document.getElementById('fsTotalSale');
      const fsPaid = document.getElementById('fsPaidAmount');
      const fsDue = document.getElementById('fsDueAmount');
      const calcFs = () => {
        const total = Math.round((Number(fsKg?.value) || 0) * (Number(fsRate?.value) || 0));
        if (fsTotal) fsTotal.value = total;
        const paid = Number(fsPaid?.value) || 0;
        if (fsDue) fsDue.value = Math.max(0, total - paid);
      };
      fsKg?.addEventListener('input', calcFs);
      fsRate?.addEventListener('input', calcFs);
      fsPaid?.addEventListener('input', calcFs);

      // Search and Filter Listeners
      document.getElementById('searchPonds')?.addEventListener('input', () => this.renderPonds());
      document.getElementById('searchMembers')?.addEventListener('input', () => this.renderMembers());
      document.getElementById('searchFeed')?.addEventListener('input', () => this.renderFeed());
      document.getElementById('filterFeedPond')?.addEventListener('change', () => this.renderFeed());
      document.getElementById('filterFeedType')?.addEventListener('change', () => this.renderFeed());
      document.getElementById('searchFishPurchase')?.addEventListener('input', () => this.renderFishPurchase());
      document.getElementById('searchFishSale')?.addEventListener('input', () => this.renderFishSale());
      document.getElementById('searchDeadFish')?.addEventListener('input', () => this.renderDeadFish());
      document.getElementById('searchExpenses')?.addEventListener('input', () => this.renderExpenses());
      document.getElementById('filterExpenseCategory')?.addEventListener('change', () => this.renderExpenses());

      // Select member / pond accounts change
      document.getElementById('selectMemberAccount')?.addEventListener('change', () => this.renderMemberAccount());
      document.getElementById('selectPondAccount')?.addEventListener('change', () => this.renderPondAccount());

      // Window resize re-draws charts
      window.addEventListener('resize', () => {
        if (this.currentView === 'dashboard') this.drawCharts();
      });
    }
  }

  // Initialize App on DOM Ready or immediately if DOM is already parsed
  function startApplication() {
    if (!window.app) {
      window.app = new PondManagementApp();
      window.app.init();
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', startApplication);
  } else {
    startApplication();
  }

})();
