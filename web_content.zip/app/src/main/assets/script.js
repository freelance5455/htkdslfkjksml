/**
 * ইসলামিক জমা-খরচ (Islamic Jama-Khoroch)
 * Vanilla JavaScript - Complete Offline Engine
 * Storage Keys:
 * - islamicFinanceTransactions
 * - islamicFinanceProfileImage
 */

(function () {
    'use strict';

    // --- Local Storage Keys ---
    const STORAGE_KEY_TX = 'islamicFinanceTransactions';
    const STORAGE_KEY_PROFILE = 'islamicFinanceProfileImage';
    const DEFAULT_PROFILE_IMG = 'assets/default-profile.png';

    // --- Bengali Numerals & Months Mapping ---
    const BENGALI_DIGITS = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
    const BENGALI_MONTHS = [
        'জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন',
        'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'
    ];

    // Helper: Convert English digits to Bengali digits
    function toBengaliDigits(num) {
        if (num === null || num === undefined) return '';
        const str = String(num);
        return str.replace(/\d/g, d => BENGALI_DIGITS[parseInt(d, 10)]);
    }

    // Helper: Format Money in Bengali (with commas)
    function formatBengaliMoney(amount) {
        const num = Math.abs(Number(amount) || 0);
        // Format with thousands separator
        const parts = num.toLocaleString('en-IN', {
            maximumFractionDigits: 2,
            minimumFractionDigits: num % 1 === 0 ? 0 : 2
        });
        return '৳ ' + toBengaliDigits(parts);
    }

    // Helper: Format Date in Bengali (e.g. "১৫ সেপ্টেম্বর, ২০২৫")
    function formatBengaliDate(dateStr) {
        if (!dateStr) return '';
        try {
            const parts = dateStr.split('-');
            if (parts.length === 3) {
                const year = parseInt(parts[0], 10);
                const monthIdx = parseInt(parts[1], 10) - 1;
                const day = parseInt(parts[2], 10);
                const monthName = BENGALI_MONTHS[monthIdx] || '';
                return `${toBengaliDigits(day)} ${monthName}, ${toBengaliDigits(year)}`;
            }
        } catch (e) {
            console.error('Date parse error:', e);
        }
        return toBengaliDigits(dateStr);
    }

    // Helper: Format Today's Date for Header (e.g. "আজ: ১৫ সেপ্টেম্বর, ২০২৫")
    function getTodayFormattedBengali() {
        const now = new Date();
        const day = toBengaliDigits(now.getDate());
        const month = BENGALI_MONTHS[now.getMonth()];
        const year = toBengaliDigits(now.getFullYear());
        return `আজ: ${day} ${month}, ${year}`;
    }

    // Helper: Today YYYY-MM-DD for input
    function getTodayYMD() {
        const now = new Date();
        const y = now.getFullYear();
        const m = String(now.getMonth() + 1).padStart(2, '0');
        const d = String(now.getDate()).padStart(2, '0');
        return `${y}-${m}-${d}`;
    }

    // --- State Management ---
    let transactions = [];
    let currentFilter = 'all'; // 'all' | 'income' | 'expense'
    let currentSearchTerm = '';
    let pendingDeleteId = null;

    // --- DOM Elements Cache ---
    const headerTodayDate = document.getElementById('headerTodayDate');
    const profileImg = document.getElementById('profileImg');
    const profilePreviewModalImg = document.getElementById('profilePreviewModalImg');
    const profileImageInput = document.getElementById('profileImageInput');
    const importFileInput = document.getElementById('importFileInput');

    // Dashboard Display Elements
    const dashTotalIncome = document.getElementById('dashTotalIncome');
    const dashTotalExpense = document.getElementById('dashTotalExpense');
    const dashCurrentBalance = document.getElementById('dashCurrentBalance');
    const dashBalanceSubtitle = document.getElementById('dashBalanceSubtitle');
    const dashTotalCount = document.getElementById('dashTotalCount');

    // Action & Filters
    const btnOpenAddModal = document.getElementById('btnOpenAddModal');
    const searchInput = document.getElementById('searchInput');
    const searchClearBtn = document.getElementById('searchClearBtn');
    const pillFilterAll = document.getElementById('pillFilterAll');
    const pillFilterIncome = document.getElementById('pillFilterIncome');
    const pillFilterExpense = document.getElementById('pillFilterExpense');
    const transactionsList = document.getElementById('transactionsList');
    const emptyState = document.getElementById('emptyState');
    const btnEmptyAdd = document.getElementById('btnEmptyAdd');
    const btnSeeAll = document.getElementById('btnSeeAll');

    // Sub-Screen Views & Bottom Navigation
    const viewDashboard = document.getElementById('viewDashboard');
    const viewTransactions = document.getElementById('viewTransactions');
    const viewBalance = document.getElementById('viewBalance');
    const viewSettings = document.getElementById('viewSettings');

    const navTabHome = document.getElementById('navTabHome');
    const navTabTx = document.getElementById('navTabTx');
    const navFabAddBtn = document.getElementById('navFabAddBtn');
    const navTabBalance = document.getElementById('navTabBalance');
    const navTabSettings = document.getElementById('navTabSettings');

    // Full Transactions View Elements
    const btnBackFromTx = document.getElementById('btnBackFromTx');
    const txCountBadge = document.getElementById('txCountBadge');
    const txListSearchInput = document.getElementById('txListSearchInput');
    const fullTxListContainer = document.getElementById('fullTxListContainer');
    const emptyStateFull = document.getElementById('emptyStateFull');

    // Balance View Elements
    const btnBackFromBalance = document.getElementById('btnBackFromBalance');
    const balanceHeroAmount = document.getElementById('balanceHeroAmount');
    const balanceHeroStatus = document.getElementById('balanceHeroStatus');
    const ratioIncomeBar = document.getElementById('ratioIncomeBar');
    const ratioExpenseBar = document.getElementById('ratioExpenseBar');
    const ratioIncomeText = document.getElementById('ratioIncomeText');
    const ratioExpenseText = document.getElementById('ratioExpenseText');

    // Settings View Elements
    const btnBackFromSettings = document.getElementById('btnBackFromSettings');
    const headerSettingsBtn = document.getElementById('headerSettingsBtn');
    const btnSettingsExport = document.getElementById('btnSettingsExport');
    const btnSettingsImport = document.getElementById('btnSettingsImport');
    const btnSettingsReset = document.getElementById('btnSettingsReset');
    const btnSettingsProfile = document.getElementById('btnSettingsProfile');
    const btnSettingsAbout = document.getElementById('btnSettingsAbout');

    // Transaction Modal Elements
    const transactionModal = document.getElementById('transactionModal');
    const txModalHeading = document.getElementById('txModalHeading');
    const transactionForm = document.getElementById('transactionForm');
    const editTransactionId = document.getElementById('editTransactionId');
    const btnTypeIncome = document.getElementById('btnTypeIncome');
    const btnTypeExpense = document.getElementById('btnTypeExpense');
    const transactionType = document.getElementById('transactionType');
    const transactionAmount = document.getElementById('transactionAmount');
    const transactionDate = document.getElementById('transactionDate');
    const transactionNote = document.getElementById('transactionNote');
    const btnSubmitText = document.getElementById('btnSubmitText');
    const btnCloseTxModal = document.getElementById('btnCloseTxModal');
    const btnCancelTxModal = document.getElementById('btnCancelTxModal');
    const amountError = document.getElementById('amountError');
    const dateError = document.getElementById('dateError');
    const noteError = document.getElementById('noteError');

    // Profile Modal Elements
    const profileModal = document.getElementById('profileModal');
    const headerProfileBtn = document.getElementById('headerProfileBtn');
    const headerCameraBadge = document.getElementById('headerCameraBadge');
    const btnCloseProfileModal = document.getElementById('btnCloseProfileModal');
    const btnCancelProfileModal = document.getElementById('btnCancelProfileModal');
    const btnChoosePhoto = document.getElementById('btnChoosePhoto');
    const btnRemovePhoto = document.getElementById('btnRemovePhoto');

    // Delete Modal Elements
    const deleteModal = document.getElementById('deleteModal');
    const deleteItemPreview = document.getElementById('deleteItemPreview');
    const btnConfirmDelete = document.getElementById('btnConfirmDelete');
    const btnCancelDelete = document.getElementById('btnCancelDelete');

    // Reset Modal Elements
    const resetModal = document.getElementById('resetModal');
    const btnConfirmReset = document.getElementById('btnConfirmReset');
    const btnCancelReset = document.getElementById('btnCancelReset');

    // About Modal Elements
    const aboutModal = document.getElementById('aboutModal');
    const btnCloseAboutModal = document.getElementById('btnCloseAboutModal');

    // Toast Element
    const toastNotification = document.getElementById('toastNotification');
    const toastMessage = document.getElementById('toastMessage');
    let toastTimeout = null;

    // Show Toast Notification
    function showToast(msg) {
        if (!toastNotification || !toastMessage) return;
        toastMessage.textContent = msg;
        toastNotification.classList.add('show');
        if (toastTimeout) clearTimeout(toastTimeout);
        toastTimeout = setTimeout(() => {
            toastNotification.classList.remove('show');
        }, 2800);
    }

    // --- LocalStorage Operations ---
    function loadTransactions() {
        try {
            const raw = localStorage.getItem(STORAGE_KEY_TX);
            if (!raw) {
                transactions = [];
                return;
            }
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed)) {
                // Filter and sanitize
                transactions = parsed.filter(t => t && t.id && (t.type === 'income' || t.type === 'expense') && Number(t.amount) > 0);
            } else {
                transactions = [];
            }
        } catch (e) {
            console.error('Failed to load transactions:', e);
            transactions = [];
        }
    }

    function saveTransactions() {
        try {
            localStorage.setItem(STORAGE_KEY_TX, JSON.stringify(transactions));
        } catch (e) {
            console.error('Failed to save transactions:', e);
            showToast('মেমরি সমস্যা: তথ্য সংরক্ষণ করা যায়নি!');
        }
    }

    function loadProfilePhoto() {
        try {
            const savedPhoto = localStorage.getItem(STORAGE_KEY_PROFILE);
            if (savedPhoto && savedPhoto.startsWith('data:image/')) {
                profileImg.src = savedPhoto;
                profilePreviewModalImg.src = savedPhoto;
            } else {
                profileImg.src = DEFAULT_PROFILE_IMG;
                profilePreviewModalImg.src = DEFAULT_PROFILE_IMG;
            }
        } catch (e) {
            console.error('Failed to load profile photo:', e);
            profileImg.src = DEFAULT_PROFILE_IMG;
            profilePreviewModalImg.src = DEFAULT_PROFILE_IMG;
        }
    }

    function saveProfilePhoto(dataUrl) {
        try {
            if (dataUrl) {
                localStorage.setItem(STORAGE_KEY_PROFILE, dataUrl);
                profileImg.src = dataUrl;
                profilePreviewModalImg.src = dataUrl;
                showToast('✓ ছবি আপডেট হয়েছে');
            } else {
                localStorage.removeItem(STORAGE_KEY_PROFILE);
                profileImg.src = DEFAULT_PROFILE_IMG;
                profilePreviewModalImg.src = DEFAULT_PROFILE_IMG;
                showToast('✓ প্রোফাইল ছবি সরানো হয়েছে');
            }
        } catch (e) {
            console.error('Failed to save profile photo:', e);
            showToast('ছবির সাইজ বেশি বড়! অনুগ্রহ করে ছোট ছবি নির্বাচন করুন।');
        }
    }

    // Compress & Resize Image to DataURL before saving (Prevent localStorage quota exceeded)
    function processAndSaveImage(file) {
        if (!file || !file.type.startsWith('image/')) {
            showToast('অনুগ্রহ করে সঠিক ছবি ফাইল নির্বাচন করুন');
            return;
        }

        const reader = new FileReader();
        reader.onload = function (e) {
            const img = new Image();
            img.onload = function () {
                const canvas = document.createElement('canvas');
                const MAX_WIDTH = 400;
                const MAX_HEIGHT = 400;
                let width = img.width;
                let height = img.height;

                if (width > height) {
                    if (width > MAX_WIDTH) {
                        height = Math.round((height * MAX_WIDTH) / width);
                        width = MAX_WIDTH;
                    }
                } else {
                    if (height > MAX_HEIGHT) {
                        width = Math.round((width * MAX_HEIGHT) / height);
                        height = MAX_HEIGHT;
                    }
                }

                canvas.width = width;
                canvas.height = height;
                const ctx = canvas.getContext('2d');
                ctx.drawImage(img, 0, 0, width, height);

                const compressedDataUrl = canvas.toDataURL('image/jpeg', 0.82);
                saveProfilePhoto(compressedDataUrl);
                closeAllModals();
            };
            img.onerror = function () {
                showToast('ছবি লোড করতে সমস্যা হয়েছে!');
            };
            img.src = e.target.result;
        };
        reader.readAsDataURL(file);
    }

    // --- Dashboard & Analytics Recalculation ---
    function updateDashboard() {
        let totalIncome = 0;
        let totalExpense = 0;

        transactions.forEach(t => {
            const amt = Number(t.amount) || 0;
            if (t.type === 'income') {
                totalIncome += amt;
            } else if (t.type === 'expense') {
                totalExpense += amt;
            }
        });

        const balance = totalIncome - totalExpense;
        const totalCount = transactions.length;

        // 1. Dashboard 2x2 Cards
        dashTotalIncome.textContent = formatBengaliMoney(totalIncome);
        dashTotalExpense.textContent = formatBengaliMoney(totalExpense);
        dashTotalCount.textContent = `${toBengaliDigits(totalCount)} টি`;

        if (balance >= 0) {
            dashCurrentBalance.textContent = formatBengaliMoney(balance);
            dashBalanceSubtitle.textContent = 'উদ্বৃত্ত ব্যালেন্স';
            dashCurrentBalance.style.color = '#ffffff';
        } else {
            dashCurrentBalance.textContent = '-' + formatBengaliMoney(Math.abs(balance));
            dashBalanceSubtitle.textContent = 'ঘাটতি বা ঋণ';
            dashCurrentBalance.style.color = '#fee2e2';
        }

        // 2. Full List Count Badge
        if (txCountBadge) {
            txCountBadge.textContent = `${toBengaliDigits(totalCount)} টি`;
        }

        // 3. Balance Screen Analytics
        if (balanceHeroAmount) {
            if (balance >= 0) {
                balanceHeroAmount.textContent = formatBengaliMoney(balance);
                balanceHeroStatus.textContent = 'উদ্বৃত্ত ব্যালেন্স';
            } else {
                balanceHeroAmount.textContent = '-' + formatBengaliMoney(Math.abs(balance));
                balanceHeroStatus.textContent = 'ঘাটতি ব্যালেন্স';
            }
        }

        const totalVolume = totalIncome + totalExpense;
        if (totalVolume > 0) {
            const incomePct = Math.round((totalIncome / totalVolume) * 100);
            const expensePct = 100 - incomePct;
            if (ratioIncomeBar) ratioIncomeBar.style.width = `${incomePct}%`;
            if (ratioExpenseBar) ratioExpenseBar.style.width = `${expensePct}%`;
            if (ratioIncomeText) ratioIncomeText.textContent = `${formatBengaliMoney(totalIncome)} (${toBengaliDigits(incomePct)}%)`;
            if (ratioExpenseText) ratioExpenseText.textContent = `${formatBengaliMoney(totalExpense)} (${toBengaliDigits(expensePct)}%)`;
        } else {
            if (ratioIncomeBar) ratioIncomeBar.style.width = '50%';
            if (ratioExpenseBar) ratioExpenseBar.style.width = '50%';
            if (ratioIncomeText) ratioIncomeText.textContent = `${formatBengaliMoney(0)} (০%)`;
            if (ratioExpenseText) ratioExpenseText.textContent = `${formatBengaliMoney(0)} (০%)`;
        }

        // 4. Render Transaction Cards
        renderTransactionsList();
    }

    // Helper: Select appropriate icon based on category/note
    function getCategoryIcon(note, type) {
        const clean = (note || '').toLowerCase();
        if (clean.includes('বাজার') || clean.includes('কেনাকাটা') || clean.includes('মুদি')) {
            return `<svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor">
                <path d="M7 18c-1.1 0-1.99.9-1.99 2S5.9 22 7 22s2-.9 2-2-.9-2-2-2zM1 2v2h2l3.6 7.59-1.35 2.45c-.16.28-.25.61-.25.96 0 1.1.9 2 2 2h12v-2H7.42c-.14 0-.25-.11-.25-.25l.03-.12.9-1.63h7.45c.75 0 1.41-.41 1.75-1.03l3.58-6.49c.08-.14.12-.31.12-.48 0-.55-.45-1-1-1H5.21l-.94-2H1zm16 16c-1.1 0-1.99.9-1.99 2s.89 2 1.99 2 2-.9 2-2-.9-2-2-2z"/>
            </svg>`;
        }
        if (clean.includes('বেতন') || clean.includes('স্যালারি') || clean.includes('উপহার')) {
            return `<svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor">
                <path d="M21 18v1c0 1.1-.9 2-2 2H5c-1.11 0-2-.9-2-2V5c0-1.1.89-2 2-2h14c1.1 0 2 .9 2 2v1h-9c-1.11 0-2 .9-2 2v8c0 1.1.89 2 2 2h9zm-9-2h10V8H12v8zm4-2.5c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5z"/>
            </svg>`;
        }
        if (clean.includes('ব্যবসা') || clean.includes('মুনাফা') || clean.includes('বিক্রয়')) {
            return `<svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor">
                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 14h-2v-2h2v2zm0-4h-2V7h2v5z"/>
            </svg>`;
        }
        if (clean.includes('দান') || clean.includes('সদকা') || clean.includes('যাকাত')) {
            return `<svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor">
                <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/>
            </svg>`;
        }

        // Default Icons
        if (type === 'income') {
            return `<svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor">
                <path d="M21 18v1c0 1.1-.9 2-2 2H5c-1.11 0-2-.9-2-2V5c0-1.1.89-2 2-2h14c1.1 0 2 .9 2 2v1h-9c-1.11 0-2 .9-2 2v8c0 1.1.89 2 2 2h9zm-9-2h10V8H12v8zm4-2.5c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5z"/>
            </svg>`;
        } else {
            return `<svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor">
                <path d="M4 12l1.41 1.41L11 7.83V20h2V7.83l5.58 5.59L20 12l-8-8-8 8z"/>
            </svg>`;
        }
    }

    // Helper: Create HTML for a transaction card
    function createTransactionCardHTML(tx) {
        const isIncome = tx.type === 'income';
        const typeLabel = isIncome ? 'জমা' : 'খরচ';
        const typeClass = isIncome ? 'income' : 'expense';
        const sign = isIncome ? '+' : '-';
        const formattedAmount = `${sign} ${formatBengaliMoney(tx.amount)}`;
        const formattedDate = formatBengaliDate(tx.date);
        const iconSvg = getCategoryIcon(tx.description, tx.type);

        return `
            <div class="tx-item-card" data-id="${tx.id}">
                <div class="tx-left-side">
                    <div class="tx-type-icon-box ${typeClass}">
                        ${iconSvg}
                    </div>
                    <div class="tx-meta-info">
                        <span class="tx-title-text" title="${escapeHtml(tx.description)}">${escapeHtml(tx.description)}</span>
                        <div class="tx-sub-row">
                            <span class="tx-chip-badge ${typeClass}">${typeLabel}</span>
                            <span>| ${formattedDate}</span>
                        </div>
                    </div>
                </div>
                <div class="tx-right-side">
                    <div class="tx-amount-display">
                        <span class="tx-amount-val ${typeClass}">${formattedAmount}</span>
                    </div>
                    <div class="tx-btns-group">
                        <button type="button" class="btn-round-action btn-round-edit" data-action="edit" data-id="${tx.id}" title="সম্পাদনা">
                            <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor">
                                <path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"/>
                            </svg>
                        </button>
                        <button type="button" class="btn-round-action btn-round-delete" data-action="delete" data-id="${tx.id}" title="মুছে ফেলুন">
                            <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor">
                                <path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/>
                            </svg>
                        </button>
                    </div>
                </div>
            </div>
        `;
    }

    function escapeHtml(str) {
        if (!str) return '';
        return String(str)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }

    // Render Filtered Transactions
    function renderTransactionsList() {
        // Filter transactions based on current filter & search term
        const filtered = transactions.filter(t => {
            // Type filter
            if (currentFilter !== 'all' && t.type !== currentFilter) {
                return false;
            }
            // Search filter
            if (currentSearchTerm) {
                const term = currentSearchTerm.toLowerCase();
                const noteMatch = (t.description || '').toLowerCase().includes(term);
                const amountMatch = String(t.amount).includes(term) || toBengaliDigits(t.amount).includes(term);
                const dateMatch = (t.date || '').includes(term) || formatBengaliDate(t.date).includes(term);
                const typeMatch = (t.type === 'income' ? 'জমা' : 'খরচ').includes(term);
                if (!noteMatch && !amountMatch && !dateMatch && !typeMatch) {
                    return false;
                }
            }
            return true;
        });

        // 1. Render for Home Dashboard
        if (transactionsList) {
            if (filtered.length === 0) {
                transactionsList.innerHTML = '';
                if (emptyState) emptyState.style.display = 'block';
            } else {
                if (emptyState) emptyState.style.display = 'none';
                // Show up to 10 recent items on home dashboard
                const recentItems = filtered.slice(0, 10);
                transactionsList.innerHTML = recentItems.map(createTransactionCardHTML).join('');
            }
        }

        // 2. Render for Full Transactions View
        if (fullTxListContainer) {
            if (filtered.length === 0) {
                fullTxListContainer.innerHTML = '';
                if (emptyStateFull) emptyStateFull.style.display = 'block';
            } else {
                if (emptyStateFull) emptyStateFull.style.display = 'none';
                fullTxListContainer.innerHTML = filtered.map(createTransactionCardHTML).join('');
            }
        }

        attachCardActionListeners();
    }

    function attachCardActionListeners() {
        // Edit & Delete handlers via event delegation
        const containers = [transactionsList, fullTxListContainer];
        containers.forEach(container => {
            if (!container) return;
            container.querySelectorAll('[data-action="edit"]').forEach(btn => {
                btn.onclick = function (e) {
                    e.stopPropagation();
                    const id = this.getAttribute('data-id');
                    openEditModal(id);
                };
            });
            container.querySelectorAll('[data-action="delete"]').forEach(btn => {
                btn.onclick = function (e) {
                    e.stopPropagation();
                    const id = this.getAttribute('data-id');
                    openDeleteModal(id);
                };
            });
        });
    }

    // --- Modal Management ---
    function closeAllModals() {
        if (transactionModal) transactionModal.classList.remove('active');
        if (profileModal) profileModal.classList.remove('active');
        if (deleteModal) deleteModal.classList.remove('active');
        if (resetModal) resetModal.classList.remove('active');
        if (aboutModal) aboutModal.classList.remove('active');
        pendingDeleteId = null;
    }

    function openAddModal() {
        closeAllModals();
        editTransactionId.value = '';
        txModalHeading.textContent = 'নতুন হিসাব যোগ করুন';
        btnSubmitText.textContent = 'সংরক্ষণ করুন';

        // Reset fields
        transactionType.value = 'income';
        btnTypeIncome.classList.add('active-income');
        btnTypeExpense.classList.remove('active-expense');

        transactionAmount.value = '';
        transactionDate.value = getTodayYMD();
        transactionNote.value = '';

        clearValidationErrors();
        transactionModal.classList.add('active');
        setTimeout(() => {
            if (transactionAmount) transactionAmount.focus();
        }, 150);
    }

    function openEditModal(id) {
        const tx = transactions.find(t => t.id === id);
        if (!tx) return;

        closeAllModals();
        editTransactionId.value = tx.id;
        txModalHeading.textContent = 'এডিট হিসাব';
        btnSubmitText.textContent = 'আপডেট করুন';

        transactionType.value = tx.type;
        if (tx.type === 'income') {
            btnTypeIncome.classList.add('active-income');
            btnTypeExpense.classList.remove('active-expense');
        } else {
            btnTypeIncome.classList.remove('active-income');
            btnTypeExpense.classList.add('active-expense');
        }

        transactionAmount.value = tx.amount;
        transactionDate.value = tx.date || getTodayYMD();
        transactionNote.value = tx.description || '';

        clearValidationErrors();
        transactionModal.classList.add('active');
        setTimeout(() => {
            if (transactionAmount) transactionAmount.focus();
        }, 150);
    }

    function openDeleteModal(id) {
        const tx = transactions.find(t => t.id === id);
        if (!tx) return;

        pendingDeleteId = id;
        const sign = tx.type === 'income' ? '+' : '-';
        const typeLabel = tx.type === 'income' ? 'জমা' : 'খরচ';

        deleteItemPreview.innerHTML = `
            <strong>${escapeHtml(tx.description)}</strong> (${typeLabel})<br>
            পরিমাণ: <span style="font-weight:700; color:${tx.type === 'income' ? '#059669' : '#dc2626'}">${sign} ${formatBengaliMoney(tx.amount)}</span><br>
            তারিখ: ${formatBengaliDate(tx.date)}
        `;
        deleteModal.classList.add('active');
    }

    function openResetModal() {
        closeAllModals();
        resetModal.classList.add('active');
    }

    function openProfileModal() {
        closeAllModals();
        profileModal.classList.add('active');
    }

    function openAboutModal() {
        closeAllModals();
        aboutModal.classList.add('active');
    }

    function clearValidationErrors() {
        if (amountError) amountError.textContent = '';
        if (dateError) dateError.textContent = '';
        if (noteError) noteError.textContent = '';
    }

    // --- Form Submission & Validation ---
    function handleTransactionSubmit(e) {
        e.preventDefault();
        clearValidationErrors();

        const type = transactionType.value;
        const rawAmount = transactionAmount.value.trim();
        const date = transactionDate.value.trim();
        const note = transactionNote.value.trim();
        const id = editTransactionId.value;

        let hasError = false;

        // 1. Amount Validation
        const amountNum = parseFloat(rawAmount);
        if (!rawAmount || isNaN(amountNum) || amountNum <= 0) {
            amountError.textContent = 'সঠিক টাকার পরিমাণ লিখুন (০ এর বেশি হতে হবে)';
            hasError = true;
        }

        // 2. Date Validation
        if (!date) {
            dateError.textContent = 'তারিখ নির্বাচন করুন';
            hasError = true;
        }

        // 3. Note Validation
        if (!note) {
            noteError.textContent = 'বিবরণ লিখুন (যেমন: বাজার, বেতন, দান)';
            hasError = true;
        }

        if (hasError) return;

        const nowIso = new Date().toISOString();

        if (id) {
            // Edit existing transaction
            const idx = transactions.findIndex(t => t.id === id);
            if (idx !== -1) {
                transactions[idx] = {
                    ...transactions[idx],
                    type: type,
                    amount: amountNum,
                    date: date,
                    description: note,
                    updatedAt: nowIso
                };
                showToast('✓ হিসাব সফলভাবে আপডেট হয়েছে');
            }
        } else {
            // Add new transaction
            const newTx = {
                id: 'tx_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7),
                type: type,
                amount: amountNum,
                date: date,
                description: note,
                createdAt: nowIso,
                updatedAt: nowIso
            };
            // Add to beginning of list (chronological recent)
            transactions.unshift(newTx);
            showToast('✓ হিসাব সফলভাবে সংরক্ষণ হয়েছে');
        }

        saveTransactions();
        closeAllModals();
        updateDashboard();
    }

    // --- Switch Screen Views ---
    function switchView(targetId) {
        const views = [viewDashboard, viewTransactions, viewBalance, viewSettings];
        views.forEach(v => {
            if (v) v.classList.remove('active');
        });

        const targetView = document.getElementById(targetId);
        if (targetView) targetView.classList.add('active');

        // Update active tab in bottom bar
        const tabs = [navTabHome, navTabTx, navTabBalance, navTabSettings];
        tabs.forEach(tab => {
            if (tab) {
                if (tab.getAttribute('data-target') === targetId) {
                    tab.classList.add('active');
                } else {
                    tab.classList.remove('active');
                }
            }
        });

        window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    // --- JSON Backup Export & Import ---
    function exportDataJSON() {
        try {
            const dataToExport = {
                app: 'ইসলামিক জমা-খরচ',
                version: '1.0.0',
                exportedAt: new Date().toISOString(),
                transactions: transactions,
                profileImage: localStorage.getItem(STORAGE_KEY_PROFILE) || null
            };

            const jsonStr = JSON.stringify(dataToExport, null, 2);
            const blob = new Blob([jsonStr], { type: 'application/json' });
            const url = URL.createObjectURL(blob);

            const a = document.createElement('a');
            const fileNameDate = getTodayYMD();
            a.href = url;
            a.download = `islamic-jama-khoroch-backup-${fileNameDate}.json`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);

            showToast('✓ ডাটা সফলভাবে Export হয়েছে');
        } catch (e) {
            console.error('Export failed:', e);
            showToast('ডাটা Export করতে ব্যর্থ হয়েছে!');
        }
    }

    function importDataJSON(file) {
        if (!file) return;
        const reader = new FileReader();
        reader.onload = function (e) {
            try {
                const parsed = JSON.parse(e.target.result);
                if (!parsed || (!Array.isArray(parsed.transactions) && !Array.isArray(parsed))) {
                    throw new Error('Invalid backup schema');
                }

                const importedList = Array.isArray(parsed.transactions) ? parsed.transactions : parsed;

                // Validate imported list
                const validList = importedList.filter(t => t && t.id && (t.type === 'income' || t.type === 'expense') && Number(t.amount) > 0);

                transactions = validList;
                saveTransactions();

                // Restore profile image if available
                if (parsed.profileImage && parsed.profileImage.startsWith('data:image/')) {
                    localStorage.setItem(STORAGE_KEY_PROFILE, parsed.profileImage);
                }

                loadProfilePhoto();
                updateDashboard();
                showToast(`✓ সফলভাবে ${toBengaliDigits(transactions.length)} টি হিসাব রিস্টোর হয়েছে`);
                switchView('viewDashboard');
            } catch (err) {
                console.error('Import parse error:', err);
                showToast('ত্রুটিপূর্ণ ব্যাকআপ ফাইল! সঠিক JSON ফাইল নির্বাচন করুন।');
            }
        };
        reader.readAsText(file);
    }

    // --- Android System Back Button Handler ---
    window.handleAndroidBack = function () {
        // 1. If any modal is active, close it
        const activeModal = document.querySelector('.modal-overlay.active');
        if (activeModal) {
            closeAllModals();
            return true;
        }

        // 2. If viewing a sub-screen, return to dashboard
        if (!viewDashboard.classList.contains('active')) {
            switchView('viewDashboard');
            return true;
        }

        // 3. Main dashboard with no modals: return false to allow app minimization
        return false;
    };

    // Make openAddModal available globally
    window.openAddModal = openAddModal;

    // --- Attach Event Listeners ---
    function setupEventListeners() {
        // Today's Date in Header
        if (headerTodayDate) {
            headerTodayDate.textContent = getTodayFormattedBengali();
        }

        // Top Header Profile Button
        if (headerProfileBtn) {
            headerProfileBtn.addEventListener('click', openProfileModal);
        }
        if (headerCameraBadge) {
            headerCameraBadge.addEventListener('click', function (e) {
                e.stopPropagation();
                openProfileModal();
            });
        }

        // Top Header Settings Button
        if (headerSettingsBtn) {
            headerSettingsBtn.addEventListener('click', () => switchView('viewSettings'));
        }

        // Main 3D Action Button: "+ নতুন হিসাব"
        if (btnOpenAddModal) {
            btnOpenAddModal.addEventListener('click', openAddModal);
        }
        if (btnEmptyAdd) {
            btnEmptyAdd.addEventListener('click', openAddModal);
        }
        if (navFabAddBtn) {
            navFabAddBtn.addEventListener('click', openAddModal);
        }

        // See All Link
        if (btnSeeAll) {
            btnSeeAll.addEventListener('click', () => switchView('viewTransactions'));
        }

        // Bottom Navigation Tabs
        if (navTabHome) {
            navTabHome.addEventListener('click', () => switchView('viewDashboard'));
        }
        if (navTabTx) {
            navTabTx.addEventListener('click', () => switchView('viewTransactions'));
        }
        if (navTabBalance) {
            navTabBalance.addEventListener('click', () => switchView('viewBalance'));
        }
        if (navTabSettings) {
            navTabSettings.addEventListener('click', () => switchView('viewSettings'));
        }

        // Back Buttons in Sub-Views
        if (btnBackFromTx) {
            btnBackFromTx.addEventListener('click', () => switchView('viewDashboard'));
        }
        if (btnBackFromBalance) {
            btnBackFromBalance.addEventListener('click', () => switchView('viewDashboard'));
        }
        if (btnBackFromSettings) {
            btnBackFromSettings.addEventListener('click', () => switchView('viewDashboard'));
        }

        // Search Input (Dashboard)
        if (searchInput) {
            searchInput.addEventListener('input', function () {
                currentSearchTerm = this.value.trim();
                if (searchClearBtn) {
                    searchClearBtn.style.display = currentSearchTerm ? 'flex' : 'none';
                }
                renderTransactionsList();
            });
        }
        if (searchClearBtn) {
            searchClearBtn.addEventListener('click', function () {
                if (searchInput) searchInput.value = '';
                currentSearchTerm = '';
                this.style.display = 'none';
                renderTransactionsList();
            });
        }

        // Search Input (Full Transactions View)
        if (txListSearchInput) {
            txListSearchInput.addEventListener('input', function () {
                currentSearchTerm = this.value.trim();
                renderTransactionsList();
            });
        }

        // Filter Pills (Dashboard)
        const filterPills = [pillFilterAll, pillFilterIncome, pillFilterExpense];
        filterPills.forEach(pill => {
            if (!pill) return;
            pill.addEventListener('click', function () {
                filterPills.forEach(p => p.classList.remove('active'));
                this.classList.add('active');
                currentFilter = this.getAttribute('data-filter');
                renderTransactionsList();
            });
        });

        // Filter Pills (Full View)
        const txViewPills = document.querySelectorAll('[data-txview-filter]');
        txViewPills.forEach(pill => {
            pill.addEventListener('click', function () {
                txViewPills.forEach(p => p.classList.remove('active'));
                this.classList.add('active');
                currentFilter = this.getAttribute('data-txview-filter');
                renderTransactionsList();
            });
        });

        // Modal 1: Type Toggles
        if (btnTypeIncome) {
            btnTypeIncome.addEventListener('click', function () {
                transactionType.value = 'income';
                btnTypeIncome.classList.add('active-income');
                btnTypeExpense.classList.remove('active-expense');
            });
        }
        if (btnTypeExpense) {
            btnTypeExpense.addEventListener('click', function () {
                transactionType.value = 'expense';
                btnTypeExpense.classList.add('active-expense');
                btnTypeIncome.classList.remove('active-income');
            });
        }

        // Quick Amount Chips
        document.querySelectorAll('.quick-chip-btn').forEach(chip => {
            chip.addEventListener('click', function () {
                const addVal = parseFloat(this.getAttribute('data-val')) || 0;
                const currentVal = parseFloat(transactionAmount.value) || 0;
                transactionAmount.value = currentVal + addVal;
                clearValidationErrors();
            });
        });

        // Quick Category Tags
        document.querySelectorAll('.quick-tag-chip').forEach(tag => {
            tag.addEventListener('click', function () {
                transactionNote.value = this.textContent.trim();
                clearValidationErrors();
            });
        });

        // Modal Close / Cancel Buttons
        if (btnCloseTxModal) btnCloseTxModal.addEventListener('click', closeAllModals);
        if (btnCancelTxModal) btnCancelTxModal.addEventListener('click', closeAllModals);

        // Transaction Form Submit
        if (transactionForm) {
            transactionForm.addEventListener('submit', handleTransactionSubmit);
        }

        // Modal 2: Profile Photo Management
        if (btnCloseProfileModal) btnCloseProfileModal.addEventListener('click', closeAllModals);
        if (btnCancelProfileModal) btnCancelProfileModal.addEventListener('click', closeAllModals);

        if (btnChoosePhoto && profileImageInput) {
            btnChoosePhoto.addEventListener('click', () => profileImageInput.click());
        }
        if (profileImageInput) {
            profileImageInput.addEventListener('change', function () {
                if (this.files && this.files[0]) {
                    processAndSaveImage(this.files[0]);
                }
                this.value = '';
            });
        }
        if (btnRemovePhoto) {
            btnRemovePhoto.addEventListener('click', function () {
                saveProfilePhoto(null);
                closeAllModals();
            });
        }

        // Modal 3: Delete Confirmation
        if (btnCancelDelete) btnCancelDelete.addEventListener('click', closeAllModals);
        if (btnConfirmDelete) {
            btnConfirmDelete.addEventListener('click', function () {
                if (pendingDeleteId) {
                    transactions = transactions.filter(t => t.id !== pendingDeleteId);
                    saveTransactions();
                    updateDashboard();
                    showToast('✓ হিসাব মুছে ফেলা হয়েছে');
                }
                closeAllModals();
            });
        }

        // Modal 4: Reset All Confirmation
        if (btnCancelReset) btnCancelReset.addEventListener('click', closeAllModals);
        if (btnConfirmReset) {
            btnConfirmReset.addEventListener('click', function () {
                transactions = [];
                saveTransactions();
                updateDashboard();
                closeAllModals();
                showToast('✓ সকল হিসাব মুছে ফেলা হয়েছে');
                switchView('viewDashboard');
            });
        }

        // Modal 5: About App
        if (btnCloseAboutModal) btnCloseAboutModal.addEventListener('click', closeAllModals);

        // Settings View Actions
        if (btnSettingsExport) btnSettingsExport.addEventListener('click', exportDataJSON);
        if (btnSettingsImport && importFileInput) {
            btnSettingsImport.addEventListener('click', () => importFileInput.click());
        }
        if (importFileInput) {
            importFileInput.addEventListener('change', function () {
                if (this.files && this.files[0]) {
                    importDataJSON(this.files[0]);
                }
                this.value = '';
            });
        }
        if (btnSettingsReset) btnSettingsReset.addEventListener('click', openResetModal);
        if (btnSettingsProfile) btnSettingsProfile.addEventListener('click', openProfileModal);
        if (btnSettingsAbout) btnSettingsAbout.addEventListener('click', openAboutModal);

        // Close modal when tapping overlay background
        document.querySelectorAll('.modal-overlay').forEach(overlay => {
            overlay.addEventListener('click', function (e) {
                if (e.target === this) {
                    closeAllModals();
                }
            });
        });
    }

    // --- Application Initialization ---
    function initApp() {
        loadTransactions();
        loadProfilePhoto();
        setupEventListeners();
        updateDashboard();
    }

    // Run on DOM Ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initApp);
    } else {
        initApp();
    }
})();
