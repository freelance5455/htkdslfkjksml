const $=id=>document.getElementById(id);
function clock(){const d=new Date();$('time').textContent=d.toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'});$('date').textContent=d.toLocaleDateString([], {weekday:'long',day:'2-digit',month:'long'});}
setInterval(clock,1000);clock();

const names=["Phone","Messages","Camera","Gallery","Chrome","YouTube","Maps","Settings","Files","Music","Clock","Calculator"];
function render(q=""){const box=$('apps');box.innerHTML="";names.filter(x=>x.toLowerCase().includes(q.toLowerCase())).forEach(n=>{const b=document.createElement('button');b.className="app";b.textContent=n;b.onclick=()=>{if(n==="Settings") $('settings').click();};box.appendChild(b)});}
render();
$('openApps').onclick=()=>{$('drawer').classList.remove('hidden');render();setTimeout(()=>$('search').focus(),120)};
$('back').onclick=()=>{$('drawer').classList.add('hidden')};
$('search').oninput=e=>render(e.target.value);
$('theme').onclick=()=>document.body.classList.toggle('light');
$('settings').onclick=()=>{$('screenText').textContent=prompt("Home screen text:","Fast Launcher")||$('screenText').textContent};
document.addEventListener('keydown',e=>{if(e.key==="Escape")$('drawer').classList.add('hidden')});
