/**
 * pdf.js
 * PDF & Print Engine for Taghvim Sina (تقویم سینا)
 * Formats schedules for printing, PDF generation, and native sharing.
 */

class PDFPrintEngine {
  /**
   * Triggers native print dialog or Android Print Bridge for the current view or schedule
   */
  printCurrentSchedule() {
    // If Android Interface exists, send print signal
    if (window.AndroidShare && typeof window.AndroidShare.print === 'function') {
      window.AndroidShare.print();
    } else {
      window.print();
    }
  }

  /**
   * Shares textual summary of today's or selected month's shift schedule
   * @param {string} title
   * @param {string} text
   */
  shareScheduleText(title, text) {
    if (window.AndroidShare && typeof window.AndroidShare.shareText === 'function') {
      window.AndroidShare.shareText(title, text);
    } else if (navigator.share) {
      navigator.share({
        title: title,
        text: text
      }).catch(err => console.log('Share canceled or failed', err));
    } else {
      // Fallback copy to clipboard
      navigator.clipboard.writeText(`${title}\n${text}`).then(() => {
        alert('برنامه شیفت در حافظه موقت (Clipboard) کپی شد.');
      });
    }
  }

  /**
   * Generates a complete, beautiful printable HTML calendar and shift table for a given month and year
   * @param {number} jy Jalali Year
   * @param {number} jm Jalali Month
   * @param {number} [targetTeam=0] Optional specific team (0 = all teams)
   */
  generatePrintableMonthlyCalendar(jy, jm, targetTeam = 0) {
    const cal = window.calendarEngine;
    const shift = window.shiftCalculator;
    const notesMgr = window.notesManager;
    const monthName = cal.jalaliMonthNames[jm - 1];
    const daysInMonth = cal.getJalaliMonthDays(jy, jm);
    const count = shift.shiftsPer24h || 2;

    const dayStart = cal.toPersianDigits(shift.dayShiftStart || '07:00');
    const dayEnd = cal.toPersianDigits(shift.dayShiftEnd || (count === 3 ? '15:00' : '19:00'));
    const eveStart = cal.toPersianDigits(shift.eveningShiftStart || '15:00');
    const eveEnd = cal.toPersianDigits(shift.eveningShiftEnd || '23:00');
    const nightStart = cal.toPersianDigits(shift.nightShiftStart || (count === 3 ? '23:00' : '19:00'));
    const nightEnd = cal.toPersianDigits(shift.nightShiftEnd || '07:00');

    let teamTitle = targetTeam > 0 ? `برنامه اختصاصی تیم ${cal.toPersianDigits(targetTeam)}` : 'برنامه جامع شیفت کاری کلیه تیم‌ها';

    let html = `
      <div class="pdf-calendar-doc p-4" dir="rtl">
        <!-- PDF Document Header -->
        <div class="pdf-header d-flex justify-content-between align-items-center border-bottom border-2 border-primary pb-3 mb-4">
          <div class="d-flex align-items-center gap-3">
            <img src="dashboard_logo.jpg" alt="لوگو" class="pdf-logo rounded-circle border" style="width: 58px; height: 58px; object-fit: cover;" onerror="this.src='dashboard_logo.png'">
            <div>
              <h2 class="fw-black text-primary mb-0" style="font-size: 1.5rem;">ATC CALENDER - تقویم کنترلر ترافیک هوایی</h2>
              <div class="text-muted small fw-bold mt-1">${teamTitle} | ماه ${monthName} سال ${cal.toPersianDigits(jy)}</div>
            </div>
          </div>
          <div class="text-end">
            <div class="badge bg-primary fs-6 px-3 py-2 fw-bold mb-1">${monthName} ${cal.toPersianDigits(jy)}</div>
            <div class="small text-muted">تاریخ صدور: ${cal.toPersianDigits(new Date().toLocaleDateString('fa-IR'))}</div>
          </div>
        </div>

        <!-- Shift Working Hours Legend Banner -->
        <div class="pdf-legend-box p-2 mb-3 bg-light rounded border d-flex justify-content-around text-center small">
          <div><strong class="text-primary">☀️ شیفت روزکاری:</strong> ${dayStart} الی ${dayEnd}</div>
          ${count === 3 ? `<div><strong class="text-warning">🌤️ شیفت عصرکاری:</strong> ${eveStart} الی ${eveEnd}</div>` : ''}
          <div><strong class="text-dark">🌙 شیفت شبکاری:</strong> ${nightStart} الی ${nightEnd}</div>
        </div>

        <!-- Monthly Detailed Table -->
        <table class="table table-bordered table-striped text-center align-middle pdf-table mb-4">
          <thead class="table-primary border-primary">
            <tr>
              <th style="width: 7%;">روز</th>
              <th style="width: 14%;">تاریخ شمسی</th>
              <th style="width: 14%;">روز هفته</th>
              <th style="width: 14%;">تاریخ میلادی</th>
              ${count === 1 ? `
                <th style="width: 25%;">تیم روزکاری</th>
              ` : count === 3 ? `
                <th style="width: 14%;">تیم روزکاری</th>
                <th style="width: 14%;">تیم عصرکاری</th>
                <th style="width: 14%;">تیم شبکاری</th>
              ` : `
                <th style="width: 20%;">تیم روزکاری</th>
                <th style="width: 20%;">تیم شبکاری</th>
              `}
              <th style="width: 25%;">مناسبت و توضیحات</th>
            </tr>
          </thead>
          <tbody>
    `;

    for (let d = 1; d <= daysInMonth; d++) {
      const g = cal.jalaliToGregorian(jy, jm, d);
      const h = cal.gregorianToHijri(g.gy, g.gm, g.gd);
      const dateObj = new Date(g.gy, g.gm - 1, g.gd, 7, 0, 0);
      const dayOfWeekIndex = (dateObj.getDay() + 1) % 7;
      const weekDayName = cal.weekDayNames[dayOfWeekIndex];
      const isFriday = dayOfWeekIndex === 6;

      const teams = shift.getTeamsForDate(dateObj);
      const event = cal.getEventForDate(jm, d, jy, g.gm, g.gd, h.hm, h.hd);
      const dateStr = `${jy}-${String(jm).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
      const notes = notesMgr ? notesMgr.getNotesForDate(dateStr) : [];

      const isHoliday = isFriday || (event && event.isHoliday);
      const rowClass = isHoliday ? 'table-danger-light' : '';

      let eventAndNotes = '';
      if (event && event.title) {
        eventAndNotes += `<span class="${event.isHoliday ? 'text-danger fw-bold' : 'text-muted'}">${event.title}</span>`;
      }
      if (notes.length > 0) {
        const noteTitles = notes.map(n => n.title || n.text).join('، ');
        if (eventAndNotes) eventAndNotes += ' | ';
        eventAndNotes += `<span class="text-success fw-bold">یادداشت: ${noteTitles}</span>`;
      }
      if (!eventAndNotes) eventAndNotes = '-';

      const dGregStr = `${g.gy}/${String(g.gm).padStart(2, '0')}/${String(g.gd).padStart(2, '0')}`;
      const dJalaliStr = `${cal.toPersianDigits(jy)}/${cal.toPersianDigits(String(jm).padStart(2, '0'))}/${cal.toPersianDigits(String(d).padStart(2, '0'))}`;

      // Highlight if target team is on duty
      const isTargetDay = targetTeam > 0 && teams.dayTeam === targetTeam;
      const isTargetEve = targetTeam > 0 && teams.eveningTeam === targetTeam;
      const isTargetNight = targetTeam > 0 && teams.nightTeam === targetTeam;

      html += `
        <tr class="${rowClass}">
          <td class="fw-bold ${isHoliday ? 'text-danger' : ''}">${cal.toPersianDigits(d)}</td>
          <td>${dJalaliStr}</td>
          <td class="${isFriday ? 'text-danger fw-bold' : ''}">${weekDayName}</td>
          <td class="font-monospace small text-muted" dir="ltr">${dGregStr}</td>
          
          ${count === 1 ? `
            <td class="${isTargetDay ? 'bg-warning-subtle fw-black' : ''}">
              <strong>تیم ${cal.toPersianDigits(teams.dayTeam)}</strong>
            </td>
          ` : count === 3 ? `
            <td class="${isTargetDay ? 'bg-primary-subtle fw-black text-primary' : ''}">
              تیم ${cal.toPersianDigits(teams.dayTeam)}
            </td>
            <td class="${isTargetEve ? 'bg-warning-subtle fw-black text-warning' : ''}">
              تیم ${cal.toPersianDigits(teams.eveningTeam)}
            </td>
            <td class="${isTargetNight ? 'bg-dark-subtle fw-black text-dark' : ''}">
              تیم ${cal.toPersianDigits(teams.nightTeam)}
            </td>
          ` : `
            <td class="${isTargetDay ? 'bg-primary-subtle fw-black text-primary' : ''}">
              <strong>تیم ${cal.toPersianDigits(teams.dayTeam)}</strong>
            </td>
            <td class="${isTargetNight ? 'bg-warning-subtle fw-black text-dark' : ''}">
              <strong>تیم ${cal.toPersianDigits(teams.nightTeam)}</strong>
            </td>
          `}

          <td class="small text-start">${eventAndNotes}</td>
        </tr>
      `;
    }

    html += `
          </tbody>
        </table>

        <!-- Document Footer -->
        <div class="pdf-footer d-flex justify-content-between align-items-center text-muted small border-top pt-3">
          <div>سامانه تقویم نوبت‌کاری سینا (Taghvim Sina) - تهیه شده جهت پرینت و ذخیره PDF</div>
          <div>صفحه ۱ از ۱</div>
        </div>
      </div>
    `;

    const printContainer = document.getElementById('printableArea');
    if (printContainer) {
      printContainer.innerHTML = html;
      this.printCurrentSchedule();
    }
  }

  /**
   * Generates a printable HTML report container for a monthly team schedule (Legacy Compatibility)
   */
  generatePrintableMonthlyReport(teamNumber, jy, jm) {
    this.generatePrintableMonthlyCalendar(jy, jm, teamNumber);
  }
}

// Global instance
window.pdfPrintEngine = new PDFPrintEngine();

