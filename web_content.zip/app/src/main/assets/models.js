// =====================================================================
//  DEAD ZONE - textures procédurales, matériaux et modèles 3D
// =====================================================================
(function(){
"use strict";
THREE.ColorManagement.legacyMode=false;
const DZ=window.DZ=window.DZ||{};
const mulberry=DZW.mulberry;
const clamp=(v,a,b)=>v<a?a:v>b?b:v;
const allMats=[];
function reg(m){allMats.push(m);return m}

// ---------- textures ----------
function ctex(size,fn,o){
 o=o||{};const c=document.createElement('canvas');c.width=c.height=size;const g=c.getContext('2d');fn(g,size);
 const t=new THREE.CanvasTexture(c);t.wrapS=t.wrapT=THREE.RepeatWrapping;t.encoding=o.linear?THREE.LinearEncoding:THREE.sRGBEncoding;t.anisotropy=4;return t;
}
function speckle(g,S,amt,seed){
 const im=g.getImageData(0,0,S,S),d=im.data,rr=mulberry(seed);
 for(let i=0;i<d.length;i+=4){const n=(rr()-.5)*amt;d[i]+=n;d[i+1]+=n;d[i+2]+=n}
 g.putImageData(im,0,0);
}
function periodic(S,cells,oct,mean,amp,seed,tint,lin){
 // bruit périodique (se répète sans couture) en niveaux de gris teintés
 const rr=mulberry(seed),grids=[];
 for(let o=0;o<oct;o++){const n=cells<<o,gr=new Float32Array(n*n);for(let i=0;i<gr.length;i++)gr[i]=rr();grids.push({n,gr})}
 const c=document.createElement('canvas');c.width=c.height=S;const g=c.getContext('2d'),im=g.createImageData(S,S),d=im.data;
 for(let y=0;y<S;y++)for(let x=0;x<S;x++){
  let v=0,a=1,tot=0;
  for(let o=0;o<oct;o++){
   const {n,gr}=grids[o],fx=x/S*n,fy=y/S*n,ix=Math.floor(fx),iy=Math.floor(fy),tx=fx-ix,ty=fy-iy,sx=tx*tx*(3-2*tx),sy=ty*ty*(3-2*ty);
   const a0=gr[(iy%n)*n+(ix%n)],b0=gr[(iy%n)*n+((ix+1)%n)],c0=gr[((iy+1)%n)*n+(ix%n)],d0=gr[((iy+1)%n)*n+((ix+1)%n)];
   v+=(a0+(b0-a0)*sx+(c0-a0)*sy+(a0-b0-c0+d0)*sx*sy)*a;tot+=a;a*=0.55;
  }
  v=mean+(v/tot-0.5)*2*amp;const k=(y*S+x)*4;
  d[k]=clamp(v*tint[0],0,255);d[k+1]=clamp(v*tint[1],0,255);d[k+2]=clamp(v*tint[2],0,255);d[k+3]=255;
 }
 g.putImageData(im,0,0);
 const t=new THREE.CanvasTexture(c);t.wrapS=t.wrapT=THREE.RepeatWrapping;t.encoding=lin?THREE.LinearEncoding:THREE.sRGBEncoding;t.anisotropy=4;return t;
}
const TEX={};
function makeTextures(){
 const rr=mulberry(77);
 TEX.brick=ctex(256,(g,S)=>{
  g.fillStyle='#cfc5b2';g.fillRect(0,0,S,S);
  const rows=12,bh=S/rows,bw=S/6;
  for(let r=0;r<rows;r++){const off=(r%2)*bw/2;for(let c=-1;c<7;c++){
   const v=(rr()-.5)*34;g.fillStyle='rgb('+(168+v|0)+','+(84+v*.6|0)+','+(60+v*.5|0)+')';
   g.fillRect(c*bw+off+1.5,r*bh+1.5,bw-3,bh-3);
   g.fillStyle='rgba(255,255,255,.07)';g.fillRect(c*bw+off+1.5,r*bh+1.5,bw-3,2);
   g.fillStyle='rgba(0,0,0,.12)';g.fillRect(c*bw+off+1.5,r*bh+bh-3.5,bw-3,2);
  }}
  speckle(g,S,28,1);
 });
 TEX.concrete=ctex(256,(g,S)=>{
  g.fillStyle='#8f9091';g.fillRect(0,0,S,S);speckle(g,S,40,2);
  for(let i=0;i<14;i++){const x=rr()*S,y=rr()*S,r=20+rr()*60,gr=g.createRadialGradient(x,y,0,x,y,r);gr.addColorStop(0,'rgba(0,0,0,.10)');gr.addColorStop(1,'rgba(0,0,0,0)');g.fillStyle=gr;g.fillRect(x-r,y-r,r*2,r*2)}
  g.fillStyle='rgba(0,0,0,.28)';g.fillRect(0,0,S,2);g.fillRect(0,S/2,S,2);g.fillRect(0,0,2,S);g.fillRect(S/2,0,2,S);
  g.fillStyle='rgba(255,255,255,.08)';g.fillRect(0,2,S,2);g.fillRect(0,S/2+2,S,2);
 });
 TEX.plaster=ctex(256,(g,S)=>{
  g.fillStyle='#e0d6c2';g.fillRect(0,0,S,S);speckle(g,S,16,3);
  for(let i=0;i<10;i++){const x=rr()*S,y=rr()*S,r=30+rr()*70,gr=g.createRadialGradient(x,y,0,x,y,r);gr.addColorStop(0,'rgba(120,100,70,.10)');gr.addColorStop(1,'rgba(120,100,70,0)');g.fillStyle=gr;g.fillRect(x-r,y-r,r*2,r*2)}
  g.strokeStyle='rgba(60,50,40,.25)';g.lineWidth=1;for(let i=0;i<3;i++){g.beginPath();let x=rr()*S,y=rr()*S;g.moveTo(x,y);for(let k=0;k<6;k++){x+=(rr()-.5)*30;y+=rr()*22;g.lineTo(x,y)}g.stroke()}
 });
 TEX.wood=ctex(256,(g,S)=>{
  const n=8,ph=S/n;
  for(let r=0;r<n;r++){const v=(rr()-.5)*30;g.fillStyle='rgb('+(138+v|0)+','+(96+v*.8|0)+','+(58+v*.6|0)+')';g.fillRect(0,r*ph,S,ph);
   g.strokeStyle='rgba(60,35,15,.35)';g.lineWidth=1;for(let k=0;k<9;k++){const y=r*ph+3+rr()*(ph-6);g.beginPath();g.moveTo(0,y);g.bezierCurveTo(S*.3,y+(rr()-.5)*4,S*.6,y+(rr()-.5)*4,S,y);g.stroke()}
   g.fillStyle='rgba(30,15,5,.55)';g.fillRect(0,r*ph,S,1.5);
   if(rr()<.5){g.fillStyle='rgba(40,20,8,.5)';g.beginPath();g.ellipse(rr()*S,r*ph+ph/2,5,3,0,0,6.3);g.fill()}
  }
  speckle(g,S,18,4);
 });
 TEX.stone=ctex(256,(g,S)=>{
  g.fillStyle='#6f6c66';g.fillRect(0,0,S,S);
  let y=0;while(y<S){const h=34+rr()*26;let x=-rr()*40;while(x<S){const w=44+rr()*50,v=(rr()-.5)*34;g.fillStyle='rgb('+(130+v|0)+','+(126+v|0)+','+(118+v|0)+')';g.fillRect(x+2,y+2,w-4,h-4);g.fillStyle='rgba(255,255,255,.1)';g.fillRect(x+2,y+2,w-4,3);g.fillStyle='rgba(0,0,0,.18)';g.fillRect(x+2,y+h-5,w-4,3);x+=w}y+=h}
  speckle(g,S,30,5);
 });
 TEX.metal=ctex(256,(g,S)=>{
  for(let x=0;x<S;x+=16){const gr=g.createLinearGradient(x,0,x+16,0);gr.addColorStop(0,'#7d8a85');gr.addColorStop(.5,'#b4bfba');gr.addColorStop(1,'#6a7671');g.fillStyle=gr;g.fillRect(x,0,16,S)}
  for(let i=0;i<60;i++){g.fillStyle='rgba(120,60,30,'+(.08+rr()*.18)+')';g.fillRect(rr()*S,rr()*S,2+rr()*10,2+rr()*18)}
  speckle(g,S,22,6);
 });
 TEX.roofTile=ctex(256,(g,S)=>{
  g.fillStyle='#b9b9b9';g.fillRect(0,0,S,S);
  const rows=10,rh=S/rows,tw=S/8;
  for(let r=0;r<rows;r++){const off=(r%2)*tw/2;for(let c=-1;c<9;c++){const v=(rr()-.5)*24,x=c*tw+off;g.fillStyle='rgb('+(205+v|0)+','+(205+v|0)+','+(205+v|0)+')';g.fillRect(x+1,r*rh,tw-2,rh);g.fillStyle='rgba(0,0,0,.35)';g.fillRect(x,r*rh,1.5,rh);g.fillStyle='rgba(0,0,0,.3)';g.fillRect(x,r*rh+rh-3,tw,3)}}
  speckle(g,S,22,7);
 });
 TEX.roofMetal=ctex(256,(g,S)=>{
  for(let x=0;x<S;x+=32){const gr=g.createLinearGradient(x,0,x+32,0);gr.addColorStop(0,'#9a9a9a');gr.addColorStop(.5,'#e4e4e4');gr.addColorStop(1,'#8a8a8a');g.fillStyle=gr;g.fillRect(x,0,32,S)}
  speckle(g,S,18,8);
 });
 TEX.roofFlat=ctex(256,(g,S)=>{g.fillStyle='#6e6e6e';g.fillRect(0,0,S,S);speckle(g,S,60,9);for(let i=0;i<40;i++){g.fillStyle='rgba(255,255,255,.12)';g.fillRect(rr()*S,rr()*S,2,2)}});
 TEX.asphalt=ctex(256,(g,S)=>{g.fillStyle='#4b4c4f';g.fillRect(0,0,S,S);speckle(g,S,34,10);for(let i=0;i<5;i++){g.strokeStyle='rgba(15,15,15,.5)';g.lineWidth=1.2;g.beginPath();let x=rr()*S,y=rr()*S;g.moveTo(x,y);for(let k=0;k<8;k++){x+=(rr()-.5)*40;y+=(rr()-.5)*40;g.lineTo(x,y)}g.stroke()}});
 TEX.pave=ctex(256,(g,S)=>{g.fillStyle='#9b9a95';g.fillRect(0,0,S,S);speckle(g,S,34,11);g.fillStyle='rgba(0,0,0,.25)';for(let k=0;k<4;k++){g.fillRect(0,k*S/4,S,2);g.fillRect(k*S/4,0,2,S)}});
 TEX.floorWood=ctex(256,(g,S)=>{const n=6,pw=S/n;for(let r=0;r<n;r++){const v=(rr()-.5)*26;g.fillStyle='rgb('+(150+v|0)+','+(108+v*.8|0)+','+(66+v*.6|0)+')';g.fillRect(r*pw,0,pw,S);g.fillStyle='rgba(30,15,5,.5)';g.fillRect(r*pw,0,1.5,S);for(let k=0;k<5;k++){const y=rr()*S;g.fillStyle='rgba(30,15,5,.4)';g.fillRect(r*pw,y,pw,1.5)}}speckle(g,S,14,12)});
 TEX.floorTile=ctex(256,(g,S)=>{for(let y=0;y<4;y++)for(let x=0;x<4;x++){const v=(rr()-.5)*14,ch=(x+y)%2;g.fillStyle='rgb('+((ch?196:226)+v|0)+','+((ch?200:228)+v|0)+','+((ch?204:226)+v|0)+')';g.fillRect(x*64,y*64,64,64)}g.fillStyle='rgba(0,0,0,.25)';for(let k=0;k<4;k++){g.fillRect(0,k*64,S,1.5);g.fillRect(k*64,0,1.5,S)}speckle(g,S,12,13)});
 TEX.fence=ctex(128,(g,S)=>{g.clearRect(0,0,S,S);g.strokeStyle='rgba(200,205,210,1)';g.lineWidth=3;for(let k=-S;k<S*2;k+=16){g.beginPath();g.moveTo(k,0);g.lineTo(k+S,S);g.stroke();g.beginPath();g.moveTo(k,S);g.lineTo(k+S,0);g.stroke()}});
 TEX.groundDetail=periodic(256,8,4,170,70,21,[1,1,1],true);
 TEX.groundDetail2=periodic(256,3,3,175,55,22,[1,1,.98],true);
 TEX.water=periodic(256,6,3,175,70,23,[0.55,0.85,1.1]);
 for(const k in TEX){if(TEX[k])TEX[k].needsUpdate=true}
}

// ---------- matériaux ----------
const MAT={};
function makeMaterials(){
 const ph=(o)=>reg(new THREE.MeshPhongMaterial(Object.assign({shininess:6,specular:0x161616},o)));
 MAT.wall=[ph({map:TEX.wood}),ph({map:TEX.stone}),ph({map:TEX.brick}),ph({map:TEX.concrete}),ph({map:TEX.plaster}),ph({map:TEX.metal,shininess:30,specular:0x333333})];
 MAT.door=ph({map:TEX.wood});
 MAT.trim=ph({color:0xe9e4d8});
 MAT.glass=reg(new THREE.MeshPhongMaterial({color:0x8fb4c8,transparent:true,opacity:0.42,shininess:120,specular:0xffffff,side:THREE.DoubleSide,depthWrite:false}));
 MAT.floor=[null,ph({map:TEX.floorWood}),ph({map:TEX.pave}),ph({map:TEX.floorTile})];
 MAT.roofTile=ph({map:TEX.roofTile,side:THREE.DoubleSide});
 MAT.roofMetal=ph({map:TEX.roofMetal,side:THREE.DoubleSide,shininess:40,specular:0x444444});
 MAT.roofFlat=ph({map:TEX.roofFlat});
 MAT.vc=reg(new THREE.MeshPhongMaterial({vertexColors:true,shininess:8,specular:0x1a1a1a}));
 MAT.veg=reg(new THREE.MeshLambertMaterial({vertexColors:true}));
 MAT.glow=reg(new THREE.MeshBasicMaterial({color:0xffffff}));
 MAT.flame=reg(new THREE.MeshBasicMaterial({color:0xffffff}));
 MAT.fence=reg(new THREE.MeshLambertMaterial({map:TEX.fence,transparent:true,alphaTest:0.4,side:THREE.DoubleSide}));
 MAT.asphalt=reg(new THREE.MeshLambertMaterial({map:TEX.asphalt,polygonOffset:true,polygonOffsetFactor:-2,polygonOffsetUnits:-2}));
 MAT.pave=reg(new THREE.MeshLambertMaterial({map:TEX.pave,polygonOffset:true,polygonOffsetFactor:-2,polygonOffsetUnits:-2}));
 MAT.water=reg(new THREE.MeshPhongMaterial({color:0x3a7fae,map:TEX.water,transparent:true,opacity:0.8,shininess:100,specular:0xbbccdd}));
}

// ---------- fusion de géométries ----------
const ident=new THREE.Matrix4(),_q=new THREE.Quaternion(),_e=new THREE.Euler(),_p=new THREE.Vector3(),_s=new THREE.Vector3(),_c=new THREE.Color();
function T4(x,y,z,rx,ry,rz,sx,sy,sz){_e.set(rx||0,ry||0,rz||0);_q.setFromEuler(_e);_p.set(x||0,y||0,z||0);_s.set(sx==null?1:sx,sy==null?1:sy,sz==null?1:sz);return new THREE.Matrix4().compose(_p,_q,_s)}
function mergeGeo(items,o){
 o=o||{};const pos=[],nor=[],col=[],uv=[],idx=[];let off=0;
 for(const it of items){
  const g=it.g.clone();g.applyMatrix4(it.m||ident);
  const p=g.attributes.position,n=g.attributes.normal,u=g.attributes.uv;
  _c.setHex(it.c==null?0xffffff:it.c);
  for(let i=0;i<p.count;i++){
   pos.push(p.getX(i),p.getY(i),p.getZ(i));nor.push(n.getX(i),n.getY(i),n.getZ(i));uv.push(u?u.getX(i):0,u?u.getY(i):0);
   let f=1;
   if(o.jit){f*=1+((Math.sin(p.getX(i)*17.3+p.getZ(i)*9.1+p.getY(i)*5.7)*43758.5453)%1)*o.jit}
   if(o.aoH){f*=0.62+0.38*clamp(p.getY(i)/o.aoH,0,1)}
   col.push(_c.r*f,_c.g*f,_c.b*f);
  }
  if(g.index){const ia=g.index.array;for(let i=0;i<ia.length;i++)idx.push(ia[i]+off)}else{for(let i=0;i<p.count;i++)idx.push(i+off)}
  off+=p.count;g.dispose();
 }
 const out=new THREE.BufferGeometry();
 out.setAttribute('position',new THREE.Float32BufferAttribute(pos,3));out.setAttribute('normal',new THREE.Float32BufferAttribute(nor,3));
 out.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));out.setAttribute('color',new THREE.Float32BufferAttribute(col,3));
 out.setIndex(idx);return out;
}
function boxUV(w,h,d,y0){ // boîte ancrée en bas, UV en unités monde
 const g=new THREE.BoxGeometry(w,h,d);g.translate(0,(y0||0)+h/2,0);
 const uv=g.attributes.uv,dims=[[d,h],[d,h],[w,d],[w,d],[w,h],[w,h]];
 for(let f=0;f<6;f++)for(let v=0;v<4;v++){const k=f*4+v;uv.setXY(k,uv.getX(k)*dims[f][0],uv.getY(k)*dims[f][1])}
 return g;
}
function blobG(r,seed,k,ws,hs){
 const g=new THREE.SphereGeometry(r,ws||8,hs||6),p=g.attributes.position;
 for(let i=0;i<p.count;i++){const x=p.getX(i),y=p.getY(i),z=p.getZ(i);
  const n=Math.sin(x*4.1+seed)+Math.sin(y*3.7+seed*1.7+1)+Math.sin(z*4.9+seed*.6+2);
  const s=1+k*n/3;p.setXYZ(i,x*s,y*s,z*s)}
 g.computeVertexNormals();return g;
}
const C=(r,g,b)=>(r<<16)|(g<<8)|b;
const GREENS=[0x2c5a2a,0x356b2f,0x2a5226,0x3d7234,0x30602c];
const OLIVE=[0x4a5d2a,0x56692f,0x3f5226];

// ---------- géométries du monde ----------
const GEO={};
function makeGeos(){
 const cyl=(a,b,h,s)=>new THREE.CylinderGeometry(a,b,h,s||8),box=(w,h,d)=>new THREE.BoxGeometry(w,h,d),sph=(r)=>new THREE.SphereGeometry(r,8,6);
 // --- pins
 GEO.pine=[];
 for(let v=0;v<3;v++){
  const rr=mulberry(100+v),it=[];
  it.push({g:cyl(0.05,0.09,0.9,6),m:T4(0,0.45,0),c:0x4a3322});
  const layers=5+v%2;
  for(let k=0;k<layers;k++){const t=k/(layers-1),y=0.5+t*1.6,rad=(0.66-v*0.04)*(1-t*0.8)+0.05,h=0.78-0.12*t;
   it.push({g:new THREE.ConeGeometry(rad,h,8,1),m:T4((rr()-.5)*0.05,y+h*0.4,(rr()-.5)*0.05,0,rr()*6.28,0),c:GREENS[(rr()*GREENS.length)|0]})}
  GEO.pine.push(mergeGeo(it,{aoH:2.5,jit:0.18}));
 }
 // --- feuillus
 GEO.broad=[];
 for(let v=0;v<3;v++){
  const rr=mulberry(200+v),it=[];
  it.push({g:cyl(0.06,0.12,1.3,7),m:T4(0,0.65,0),c:0x5a4030});
  it.push({g:cyl(0.03,0.06,0.6,5),m:T4(0.18,1.25,0.0,0,0,-0.9),c:0x5a4030});
  it.push({g:cyl(0.03,0.06,0.6,5),m:T4(-0.16,1.3,0.08,0,0,0.9),c:0x5a4030});
  const n=4+(v%2);
  for(let k=0;k<n;k++){const a=k/n*6.28+rr(),rad=0.3+rr()*0.25;
   it.push({g:blobG(0.55+rr()*0.25,rr()*10,0.4,9,7),m:T4(Math.cos(a)*rad,1.75+rr()*0.5,Math.sin(a)*rad,0,0,0,1,0.85,1),c:(v===2&&rr()<.4)?0x8a8a2c:GREENS[(rr()*GREENS.length)|0]})}
  it.push({g:blobG(0.6,rr()*10,0.35,9,7),m:T4(0,2.15,0),c:GREENS[(rr()*GREENS.length)|0]});
  GEO.broad.push(mergeGeo(it,{aoH:2.9,jit:0.2}));
 }
 // --- arbre mort
 {const rr=mulberry(300),it=[];
  it.push({g:cyl(0.05,0.1,1.7,6),m:T4(0,0.85,0),c:0x6d6358});
  for(let k=0;k<4;k++){const a=rr()*6.28;it.push({g:cyl(0.015,0.04,0.7,4),m:T4(Math.cos(a)*0.12,1.1+k*0.22,Math.sin(a)*0.12,Math.sin(a)*0.9,0,-Math.cos(a)*0.9),c:0x6d6358})}
  GEO.dead=mergeGeo(it,{jit:0.15});}
 // --- buissons
 GEO.bush=[];
 for(let v=0;v<2;v++){
  const rr=mulberry(400+v),it=[];
  for(let k=0;k<4;k++){const a=k*1.7+rr();it.push({g:blobG(0.3+rr()*0.12,rr()*10,0.4,8,6),m:T4(Math.cos(a)*0.2,0.22+rr()*0.1,Math.sin(a)*0.2,0,0,0,1,0.8,1),c:OLIVE[(rr()*OLIVE.length)|0]})}
  if(v===1){for(let k=0;k<9;k++){const a=rr()*6.28,rad=0.12+rr()*0.28;it.push({g:new THREE.SphereGeometry(0.045,6,4),m:T4(Math.cos(a)*rad,0.2+rr()*0.28,Math.sin(a)*rad),c:0xc4242c})}}
  GEO.bush.push(mergeGeo(it,{aoH:0.6,jit:0.15}));
 }
 // --- rochers
 GEO.rock=[];
 for(let v=0;v<3;v++){
  const rr=mulberry(500+v),it=[];
  const g=new THREE.IcosahedronGeometry(0.5,1),p=g.attributes.position;
  for(let i=0;i<p.count;i++){const x=p.getX(i),y=p.getY(i),z=p.getZ(i),n=Math.sin(x*5+v)+Math.sin(y*6+v*2)+Math.sin(z*5.3+v*3);const s=1+0.28*n/3;p.setXYZ(i,x*s,y*s*0.72,z*s)}
  g.computeVertexNormals();
  it.push({g,m:T4(0,0.22,0,0,rr()*6,0,1+rr()*0.3,1,0.85+rr()*0.3),c:[0x8a8c8a,0x7d7f7c,0x908a80][v]});
  const g2=new THREE.IcosahedronGeometry(0.2,1);it.push({g:g2,m:T4(0.4,0.08,0.15,0,0,0,1,0.7,1),c:0x777977});
  GEO.rock.push(mergeGeo(it,{aoH:0.6,jit:0.18}));
 }
 // --- gravats
 {const rr=mulberry(600),it=[];
  for(let k=0;k<9;k++){const g=box(0.2+rr()*0.3,0.1+rr()*0.2,0.2+rr()*0.3);it.push({g,m:T4((rr()-.5)*0.7,0.08+rr()*0.2,(rr()-.5)*0.7,rr()*.5,rr()*6,rr()*.5),c:[0x7a7468,0x8d8478,0x666056,0x9a5a44][k%4]})}
  GEO.rubble=mergeGeo(it,{jit:0.2});}
 // --- caisse
 {const it=[];
  it.push({g:box(0.62,0.5,0.62),m:T4(0,0.25,0),c:0x9a6b35});
  it.push({g:box(0.66,0.05,0.66),m:T4(0,0.52,0),c:0x7d5527});
  it.push({g:box(0.65,0.05,0.65),m:T4(0,0.12,0),c:0x6d4a22});it.push({g:box(0.65,0.05,0.65),m:T4(0,0.38,0),c:0x6d4a22});
  it.push({g:box(0.06,0.5,0.66),m:T4(-0.29,0.25,0),c:0x7d5527});it.push({g:box(0.06,0.5,0.66),m:T4(0.29,0.25,0),c:0x7d5527});
  GEO.crate=mergeGeo(it,{jit:0.12});}
 // --- baril
 {const it=[];
  it.push({g:cyl(0.23,0.23,0.64,12),m:T4(0,0.32,0),c:0xffffff});
  it.push({g:cyl(0.245,0.245,0.04,12),m:T4(0,0.16,0),c:0x555555});it.push({g:cyl(0.245,0.245,0.04,12),m:T4(0,0.48,0),c:0x555555});
  it.push({g:cyl(0.2,0.2,0.02,12),m:T4(0,0.65,0),c:0x888888});
  GEO.barrel=mergeGeo(it);}
 // --- voiture
 {const it=[];
  it.push({g:box(1.9,0.4,0.86),m:T4(0,0.34,0),c:0xffffff});
  it.push({g:box(1.0,0.36,0.78),m:T4(-0.12,0.72,0),c:0xffffff});
  it.push({g:box(1.02,0.26,0.8),m:T4(-0.12,0.74,0),c:0x1c2630});
  it.push({g:box(0.3,0.04,0.8),m:T4(0.6,0.55,0),c:0xffffff});
  it.push({g:box(0.05,0.1,0.8),m:T4(0.96,0.36,0),c:0x333333});it.push({g:box(0.05,0.1,0.8),m:T4(-0.96,0.36,0),c:0x333333});
  for(const sx of [-0.6,0.62])for(const sz of [-0.43,0.43])it.push({g:cyl(0.17,0.17,0.14,12),m:T4(sx,0.17,sz,Math.PI/2,0,0),c:0x151515});
  it.push({g:box(0.04,0.08,0.18),m:T4(0.95,0.42,0.28),c:0xe8e0a0});it.push({g:box(0.04,0.08,0.18),m:T4(0.95,0.42,-0.28),c:0xe8e0a0});
  GEO.car=mergeGeo(it);}
 // --- table
 {const it=[];it.push({g:box(0.82,0.07,0.56),m:T4(0,0.46,0),c:0x8a5e32});
  for(const x of [-0.36,0.36])for(const z of [-0.23,0.23])it.push({g:box(0.06,0.46,0.06),m:T4(x,0.23,z),c:0x6e4a26});
  it.push({g:cyl(0.06,0.05,0.1,8),m:T4(0.1,0.55,0.05),c:0xd8d0c0});
  GEO.table=mergeGeo(it,{jit:0.1});}
 // --- lit
 {const it=[];it.push({g:box(1.0,0.16,0.56),m:T4(0,0.16,0),c:0x6e4a26});
  it.push({g:box(0.94,0.12,0.5),m:T4(0,0.3,0),c:0xcfd6e0});it.push({g:box(0.22,0.07,0.38),m:T4(-0.36,0.38,0),c:0xf2f2f2});
  it.push({g:box(0.06,0.5,0.58),m:T4(-0.5,0.3,0),c:0x6e4a26});it.push({g:box(0.55,0.05,0.5),m:T4(0.2,0.37,0),c:0x6b7a5a});
  GEO.bed=mergeGeo(it,{jit:0.08});}
 // --- armoire / étagère
 const cab=(open)=>{const it=[];it.push({g:box(0.74,1.0,0.36),m:T4(0,0.5,0),c:0x7d5a34});
  it.push({g:box(0.76,0.04,0.38),m:T4(0,1.0,0),c:0x6b4a28});
  if(!open){it.push({g:box(0.36,0.9,0.02),m:T4(-0.18,0.5,0.19),c:0x8d6a40});it.push({g:box(0.36,0.9,0.02),m:T4(0.18,0.5,0.19),c:0x8d6a40});
   it.push({g:sph(0.025),m:T4(-0.04,0.5,0.21),c:0xcccccc});it.push({g:sph(0.025),m:T4(0.04,0.5,0.21),c:0xcccccc})}
  else{it.push({g:box(0.6,0.9,0.02),m:T4(-0.35,0.5,0.35,0,1.2,0),c:0x8d6a40});it.push({g:box(0.6,0.9,0.02),m:T4(0.35,0.5,0.35,0,-1.2,0),c:0x8d6a40});it.push({g:box(0.66,0.04,0.26),m:T4(0,0.35,0),c:0x4a3620});it.push({g:box(0.66,0.04,0.26),m:T4(0,0.7,0),c:0x4a3620})}
  return mergeGeo(it,{jit:0.1})};
 GEO.cab=cab(false);GEO.cabo=cab(true);
 // --- établi
 {const it=[];it.push({g:box(0.98,0.1,0.62),m:T4(0,0.55,0),c:0xa5703a});
  for(const x of [-0.42,0.42])it.push({g:box(0.08,0.55,0.55),m:T4(x,0.27,0),c:0x6e4a26});
  it.push({g:box(0.86,0.06,0.5),m:T4(0,0.2,0),c:0x6e4a26});
  it.push({g:box(0.16,0.12,0.14),m:T4(0.32,0.66,0.1),c:0x9a9a9a});it.push({g:box(0.3,0.03,0.08),m:T4(-0.2,0.62,0.1,0,0.4,0),c:0xb5b5b5});
  GEO.bench=mergeGeo(it,{jit:0.1});}
 // --- four
 {const it=[];it.push({g:box(0.92,0.8,0.92),m:T4(0,0.4,0),c:0x6a6a68});
  it.push({g:cyl(0.14,0.17,0.55,8),m:T4(0.22,1.05,0.22),c:0x3a3a3a});
  it.push({g:box(0.48,0.34,0.06),m:T4(0,0.24,0.47),c:0x161616});it.push({g:box(0.92,0.06,0.92),m:T4(0,0.8,0),c:0x4a4a48});
  for(let k=0;k<6;k++)it.push({g:box(0.28,0.12,0.04),m:T4(-0.3+(k%3)*0.3,0.45+Math.floor(k/3)*0.2,0.47),c:0x7e7e7a});
  GEO.furn=mergeGeo(it,{jit:0.15});
  GEO.furnGlow=box(0.4,0.26,0.04).translate(0,0.24,0.5);}
 // --- feu de camp
 {const it=[];const rr=mulberry(700);
  for(let k=0;k<8;k++){const a=k/8*6.28;it.push({g:new THREE.IcosahedronGeometry(0.1,0),m:T4(Math.cos(a)*0.3,0.07,Math.sin(a)*0.3,rr(),rr(),rr(),1,0.8,1),c:0x777777})}
  for(let k=0;k<3;k++){const a=k*1.05;it.push({g:cyl(0.04,0.04,0.55,6),m:T4(0,0.1,0,0,a,Math.PI/2.3),c:0x4a3220})}
  it.push({g:cyl(0.22,0.25,0.03,10),m:T4(0,0.015,0),c:0x2a2420});
  GEO.fire=mergeGeo(it,{jit:0.1});
  GEO.flame=new THREE.ConeGeometry(0.16,0.5,7).translate(0,0.38,0);GEO.flame2=new THREE.ConeGeometry(0.09,0.34,6).translate(0,0.32,0);}
 // --- tourelle
 {const it=[];it.push({g:cyl(0.3,0.38,0.22,10),m:T4(0,0.11,0),c:0x4a4c4a});it.push({g:cyl(0.08,0.1,0.5,8),m:T4(0,0.45,0),c:0x303030});
  it.push({g:box(0.42,0.3,0.5),m:T4(0,0.78,0),c:0x5d6b62});it.push({g:cyl(0.04,0.04,0.55,8),m:T4(0.1,0.8,0.45,Math.PI/2,0,0),c:0x161616});it.push({g:cyl(0.04,0.04,0.55,8),m:T4(-0.1,0.8,0.45,Math.PI/2,0,0),c:0x161616});
  it.push({g:box(0.3,0.08,0.3),m:T4(0,0.97,-0.05),c:0x3c453f});
  GEO.turret=mergeGeo(it,{jit:0.1});GEO.redlight=new THREE.SphereGeometry(0.045,6,4).translate(0,1.03,-0.05);}
 // --- tour de guet
 {const it=[];const wc=0x6e5a3c;
  for(const sx of [-1,1])for(const sz of [-1,1]){it.push({g:cyl(0.06,0.08,3.1,6),m:T4(sx*0.62,1.55,sz*0.62,-sz*0.07,0,sx*0.07),c:wc})}
  for(let k=0;k<3;k++){const y=0.6+k*0.8;for(const s of [-1,1]){it.push({g:box(1.3,0.05,0.05),m:T4(0,y,s*0.62),c:wc});it.push({g:box(0.05,0.05,1.3),m:T4(s*0.62,y,0),c:wc})}
   it.push({g:box(1.7,0.04,0.04),m:T4(0,y+0.4,0.62,0,0,0.65),c:wc});it.push({g:box(1.7,0.04,0.04),m:T4(0,y+0.4,-0.62,0,0,-0.65),c:wc})}
  it.push({g:box(1.5,0.1,1.5),m:T4(0,3.05,0),c:0x5a4a32});
  for(const s of [-1,1]){it.push({g:box(1.5,0.5,0.06),m:T4(0,3.35,s*0.72),c:0x6e5a3c});it.push({g:box(0.06,0.5,1.5),m:T4(s*0.72,3.35,0),c:0x6e5a3c})}
  it.push({g:new THREE.ConeGeometry(1.25,0.55,4),m:T4(0,3.95,0,0,Math.PI/4,0),c:0x3d4a3c});
  for(const sx of [-1,1])for(const sz of [-1,1])it.push({g:cyl(0.03,0.03,0.9,5),m:T4(sx*0.7,3.55,sz*0.7),c:0x4a3c28});
  it.push({g:box(0.16,2.6,0.05),m:T4(0.35,1.4,0.66,0,0,0),c:0x4a3c28});
  GEO.tower=mergeGeo(it,{jit:0.1});}
 // --- clôtures
 {const it=[];it.push({g:cyl(0.025,0.03,0.95,6),m:T4(0,0.47,0),c:0x7a7e80});it.push({g:box(1.0,0.03,0.03),m:T4(0,0.93,0),c:0x7a7e80});it.push({g:box(1.0,0.03,0.03),m:T4(0,0.08,0),c:0x7a7e80});
  GEO.fpost=mergeGeo(it);GEO.fpanel=new THREE.PlaneGeometry(1,0.84).translate(0,0.5,0);}
 {const it=[];const rr=mulberry(800);
  for(let k=0;k<6;k++){const x=-0.42+k*0.168,h=0.8+rr()*0.18;it.push({g:cyl(0.05,0.055,h,6),m:T4(x,h/2,0),c:0x8a6a42});it.push({g:new THREE.ConeGeometry(0.05,0.14,6),m:T4(x,h+0.07,0),c:0x7a5a34})}
  it.push({g:box(1.0,0.05,0.04),m:T4(0,0.3,0.06),c:0x5a4228});it.push({g:box(1.0,0.05,0.04),m:T4(0,0.62,0.06),c:0x5a4228});
  GEO.palis=mergeGeo(it,{jit:0.18});}
 // --- pièces de murs (épaisseur t)
 const t=0.26,WH=1.5;
 GEO.t=t;GEO.WH=WH;
 GEO.wPlain=boxUV(1,WH,t);
 GEO.wCenter=boxUV(t,WH,t);
 GEO.wArm=boxUV(0.5-t/2,WH,t);
 GEO.wSill=boxUV(1,0.55,t);
 GEO.wTop=boxUV(1,WH-1.15,t,1.15);
 GEO.wSide=boxUV(0.23,0.6,t,0.55);
 GEO.dTop=boxUV(1,WH-1.2,t,1.2);
 GEO.dSide=boxUV(0.15,1.2,t);
 GEO.sillTrim=new THREE.BoxGeometry(0.66,0.05,t+0.1).translate(0,0.56,0);
 GEO.glass=new THREE.PlaneGeometry(0.54,0.6).translate(0,0.85,0);
 GEO.frameH=new THREE.BoxGeometry(0.58,0.04,0.05).translate(0,0.85,0);
 GEO.frameV=new THREE.BoxGeometry(0.03,0.6,0.05).translate(0,0.85,0);
 GEO.doorLeaf=new THREE.BoxGeometry(0.66,1.18,0.06);GEO.doorLeaf.translate(0.33,0.59,0);
 GEO.rubbleWall=GEO.rubble;
 GEO.slab=boxUV(1,0.25,1,-0.2);
 GEO.roofSlab=boxUV(1.06,0.1,1.06);
 GEO.roofSlope=(()=>{const a=Math.atan2(0.55,1),L=1/Math.cos(a);const g=new THREE.BoxGeometry(1.06,0.08,L+0.08);return g})();
 GEO.chimney=boxUV(0.3,0.8,0.3);
 // ===== v4 : escaliers, rambardes, meubles, établis, cultures, herbe =====
 {const it=[],wc=0xa5703a;const n=8,A=Math.atan2(WH,1),L=Math.hypot(WH,1);
  for(let k=0;k<n;k++){const h=(k+1)/n*WH;it.push({g:box(0.82,h,1/n+0.01),m:T4(0,h/2,0.5-(k+0.5)/n),c:k%2?0xb07a42:wc})}
  for(const s of [-1,1])it.push({g:box(0.07,0.2,L),m:T4(s*0.43,WH/2-0.02,0,A,0,0),c:0x6e4a26});
  GEO.stairs=mergeGeo(it,{jit:0.12});}
 {const it=[],wc=0x8a5e32;it.push({g:cyl(0.045,0.05,0.95,6),m:T4(0,0.47,0),c:wc});
  it.push({g:box(1.0,0.05,0.06),m:T4(0,0.93,0),c:0x9a6c3c});it.push({g:box(1.0,0.035,0.04),m:T4(0,0.5,0),c:wc});
  for(const x of [-0.33,-0.17,0.17,0.33])it.push({g:cyl(0.014,0.014,0.45,4),m:T4(x,0.24,0),c:wc});
  GEO.rail=mergeGeo(it,{jit:0.1});}
 {const it=[];it.push({g:box(0.34,0.05,0.34),m:T4(0,0.3,0),c:0x8a5e32});
  for(const x of [-0.14,0.14])for(const z of [-0.14,0.14])it.push({g:box(0.04,0.3,0.04),m:T4(x,0.15,z),c:0x6e4a26});
  it.push({g:box(0.34,0.36,0.04),m:T4(0,0.5,-0.15),c:0x8a5e32});it.push({g:box(0.26,0.03,0.06),m:T4(0,0.46,-0.13),c:0x6e4a26});
  GEO.chair=mergeGeo(it,{jit:0.1});}
 {const it=[];it.push({g:box(0.92,0.26,0.48),m:T4(0,0.2,0.02),c:0x5b6b7a});it.push({g:box(0.92,0.4,0.14),m:T4(0,0.45,-0.19),c:0x4d5c6a});
  for(const s of [-1,1])it.push({g:box(0.12,0.34,0.5),m:T4(s*0.5,0.3,0),c:0x4d5c6a});
  it.push({g:box(0.36,0.08,0.4),m:T4(-0.2,0.37,0.05),c:0x6d7e8e});it.push({g:box(0.36,0.08,0.4),m:T4(0.2,0.37,0.05),c:0x6d7e8e});
  for(const s of [-1,1])it.push({g:box(0.05,0.07,0.05),m:T4(s*0.46,0.035,0.2),c:0x2a2a2a});
  GEO.sofa=mergeGeo(it,{jit:0.08});}
 {const it=[],wc=0x7d5a34;for(const s of [-1,1])it.push({g:box(0.04,1.15,0.3),m:T4(s*0.4,0.575,0),c:wc});
  for(let k=0;k<5;k++)it.push({g:box(0.8,0.03,0.3),m:T4(0,0.02+k*0.28,0),c:0x8d6a40});
  it.push({g:box(0.8,1.1,0.02),m:T4(0,0.58,-0.14),c:0x6b4a28});
  const cc=[0xb04030,0x3a6a9a,0xd8c070,0x4a8a4a,0xc0c0c0];for(let k=0;k<4;k++)for(let j=0;j<3;j++)it.push({g:box(0.13,0.14,0.14),m:T4(-0.26+j*0.26,0.1+k*0.28,0.02),c:cc[(k*3+j)%5]});
  GEO.shelf=mergeGeo(it,{jit:0.1});}
 {const it=[];it.push({g:cyl(0.14,0.16,0.04,10),m:T4(0,0.02,0),c:0x2a2a2a});it.push({g:cyl(0.015,0.015,1.0,5),m:T4(0,0.5,0),c:0x3a3a3a});
  it.push({g:new THREE.CylinderGeometry(0.1,0.18,0.22,10,1,true),m:T4(0,1.02,0),c:0xe6d6a8});
  GEO.lamp=mergeGeo(it);GEO.lampGlow=new THREE.SphereGeometry(0.07,8,6).translate(0,0.98,0);}
 {const it=[];it.push({g:cyl(0.3,0.34,0.42,8),m:T4(0,0.21,0),c:0x6a4a2a});it.push({g:box(0.56,0.12,0.26),m:T4(0,0.5,0),c:0x3a3c40});
  it.push({g:new THREE.ConeGeometry(0.09,0.3,6),m:T4(0.38,0.5,0,0,0,-Math.PI/2),c:0x3a3c40});it.push({g:box(0.34,0.06,0.2),m:T4(0,0.59,0),c:0x4a4c50});
  it.push({g:box(0.4,0.28,0.3),m:T4(-0.35,0.14,0.5),c:0x7a7a76});it.push({g:box(0.3,0.04,0.18),m:T4(-0.35,0.3,0.5),c:0x2a2a2a});
  GEO.anvil=mergeGeo(it,{jit:0.12});GEO.anvilGlow=box(0.26,0.03,0.14).translate(-0.35,0.31,0.5);}
 {const it=[];it.push({g:box(1.0,0.1,0.62),m:T4(0,0.55,0),c:0x4a5056});
  for(const x of [-0.44,0.44])it.push({g:box(0.08,0.55,0.55),m:T4(x,0.27,0),c:0x2f3438});
  it.push({g:box(0.86,0.06,0.5),m:T4(0,0.2,0),c:0x2f3438});it.push({g:box(0.2,0.14,0.16),m:T4(0.34,0.67,0.08),c:0x9a9a9a});
  it.push({g:box(0.5,0.04,0.12),m:T4(-0.12,0.62,0.05,0,0.2,0),c:0x151515});it.push({g:box(0.14,0.1,0.1),m:T4(-0.38,0.65,-0.12),c:0xa02a24});
  it.push({g:box(0.7,0.12,0.04),m:T4(0,0.9,-0.28),c:0x6a6e72});
  GEO.gunb=mergeGeo(it,{jit:0.1});}
 {const it=[];it.push({g:box(0.82,0.8,0.62),m:T4(0,0.4,0),c:0x2c2c30});it.push({g:box(0.84,0.04,0.64),m:T4(0,0.82,0),c:0xd8d8d4});
  for(const x of [-0.2,0.2])for(const z of [-0.14,0.14])it.push({g:cyl(0.09,0.09,0.02,10),m:T4(x,0.85,z),c:0x161616});
  it.push({g:box(0.6,0.4,0.02),m:T4(0,0.38,0.32),c:0x0d0d0d});it.push({g:cyl(0.05,0.05,0.9,6),m:T4(0.3,1.25,-0.22),c:0x3a3a3a});
  GEO.stove=mergeGeo(it,{jit:0.08});}
 {const it=[];it.push({g:cyl(0.34,0.38,0.3,10),m:T4(0,0.15,0),c:0x84827c});it.push({g:cyl(0.3,0.3,0.14,10),m:T4(0,0.37,0),c:0x9a988f});
  it.push({g:cyl(0.02,0.02,0.4,5),m:T4(0.2,0.6,0),c:0x6e4a26});it.push({g:box(0.2,0.05,0.05),m:T4(0.2,0.8,0,0,0,0),c:0x6e4a26});
  it.push({g:sph(0.2),m:T4(-0.42,0.14,0.34,0,0,0,1,0.7,0.9),c:0xc9b98a});
  GEO.mill=mergeGeo(it,{jit:0.12});}
 GEO.crop=[];
 for(let st=0;st<3;st++){const it=[],rr=mulberry(900+st),nb=[7,9,11][st],hh=[0.14,0.38,0.66][st];
  for(let k=0;k<nb;k++){const a=rr()*6.28,r=0.08+rr()*0.3,h=hh*(0.75+rr()*0.5);
   it.push({g:new THREE.ConeGeometry(0.03+st*0.006,h,4),m:T4(Math.cos(a)*r,h/2,Math.sin(a)*r,(rr()-.5)*0.3,0,(rr()-.5)*0.3),c:0xffffff});
   if(st===2)it.push({g:box(0.05,0.13,0.05),m:T4(Math.cos(a)*r,h+0.02,Math.sin(a)*r),c:0xfff0b0})}
  GEO.crop.push(mergeGeo(it,{jit:0.2}));}
 {const it=[];it.push({g:box(0.96,0.07,0.96),m:T4(0,0,0),c:0x5e4430});
  for(let k=0;k<4;k++)it.push({g:box(0.9,0.05,0.14),m:T4(0,0.06,-0.36+k*0.24),c:0x7a5a3c});
  GEO.soil=mergeGeo(it,{jit:0.25});}
 {const it=[],rr=mulberry(950);
  for(let k=0;k<6;k++){const a=rr()*6.28,r=rr()*0.12,h=0.22+rr()*0.22;it.push({g:new THREE.ConeGeometry(0.028,h,3),m:T4(Math.cos(a)*r,h/2,Math.sin(a)*r,(rr()-.5)*0.5,0,(rr()-.5)*0.5),c:[0x6a9a3a,0x5a8a30,0x7aa844,0x4f7f2c][k%4]})}
  GEO.grass=mergeGeo(it);}
}

// ---------- toits (un maillage par bâtiment) ----------
function roofGeo(b){
 // renvoie {roof:Géométrie, gable:Géométrie|null, rise}
 const ov=0.34,x0=b.x+0.5-ov,x1=b.x+b.w-0.5+ov,z0=b.y+0.5-ov,z1=b.y+b.h-0.5+ov;
 const len=b.ridge===0?(x1-x0):(z1-z0),span=b.ridge===0?(z1-z0):(x1-x0);
 const rise=clamp(span*0.3,0.55,1.5);
 const pos=[],uv=[],idx=[],gp=[],gu=[];
 const quad=(a,bb,c,d,ua,ub,uc,ud)=>{const o=pos.length/3;pos.push(...a,...bb,...c,...d);uv.push(...ua,...ub,...uc,...ud);idx.push(o,o+1,o+2,o,o+2,o+3)};
 const sl=Math.hypot(span/2,rise);
 if(b.ridge===0){
  const zm=(z0+z1)/2;
  quad([x0,0,z0],[x1,0,z0],[x1,rise,zm],[x0,rise,zm],[0,0],[len,0],[len,sl],[0,sl]);
  quad([x1,0,z1],[x0,0,z1],[x0,rise,zm],[x1,rise,zm],[0,0],[len,0],[len,sl],[0,sl]);
  gp.push(x0+ov*0.7,0,z0+ov*0.7,x0+ov*0.7,0,z1-ov*0.7,x0+ov*0.7,rise,zm, x1-ov*0.7,0,z1-ov*0.7,x1-ov*0.7,0,z0+ov*0.7,x1-ov*0.7,rise,zm);
 }else{
  const xm=(x0+x1)/2;
  quad([x1,0,z0],[x1,0,z1],[xm,rise,z1],[xm,rise,z0],[0,0],[len,0],[len,sl],[0,sl]);
  quad([x0,0,z1],[x0,0,z0],[xm,rise,z0],[xm,rise,z1],[0,0],[len,0],[len,sl],[0,sl]);
  gp.push(x0+ov*0.7,0,z0+ov*0.7,x1-ov*0.7,0,z0+ov*0.7,xm,rise,z0+ov*0.7, x1-ov*0.7,0,z1-ov*0.7,x0+ov*0.7,0,z1-ov*0.7,xm,rise,z1-ov*0.7);
 }
 const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(pos,3));g.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));g.setIndex(idx);g.computeVertexNormals();
 const gg=new THREE.BufferGeometry();gg.setAttribute('position',new THREE.Float32BufferAttribute(gp,3));
 const guv=[];for(let i=0;i<6;i++)guv.push((gp[i*3+(b.ridge===0?2:0)])*1,gp[i*3+1]*1);
 gg.setAttribute('uv',new THREE.Float32BufferAttribute(guv,2));gg.setIndex([0,1,2,3,4,5]);gg.computeVertexNormals();
 return{roof:g,gable:gg,rise};
}
function flatRoofGeo(b){
 const ov=0.3,x0=b.x+0.5-ov,x1=b.x+b.w-0.5+ov,z0=b.y+0.5-ov,z1=b.y+b.h-0.5+ov;
 const g=new THREE.BoxGeometry(x1-x0,0.14,z1-z0);g.translate((x0+x1)/2,0.07,(z0+z1)/2);
 const uv=g.attributes.uv,w=x1-x0,d=z1-z0,dims=[[d,0.14],[d,0.14],[w,d],[w,d],[w,0.14],[w,0.14]];
 for(let f=0;f<6;f++)for(let v=0;v<4;v++){const k=f*4+v;uv.setXY(k,uv.getX(k)*dims[f][0],uv.getY(k)*dims[f][1])}
 // parapet
 const par=[];const pt=0.1,ph=0.2;
 par.push(new THREE.BoxGeometry(x1-x0,ph,pt).translate((x0+x1)/2,0.14+ph/2,z0+pt/2));
 par.push(new THREE.BoxGeometry(x1-x0,ph,pt).translate((x0+x1)/2,0.14+ph/2,z1-pt/2));
 par.push(new THREE.BoxGeometry(pt,ph,z1-z0-2*pt).translate(x0+pt/2,0.14+ph/2,(z0+z1)/2));
 par.push(new THREE.BoxGeometry(pt,ph,z1-z0-2*pt).translate(x1-pt/2,0.14+ph/2,(z0+z1)/2));
 return{slab:g,parapet:par};
}

DZ.models={TEX,MAT,GEO,makeTextures,makeMaterials,makeGeos,mergeGeo,T4,blobG,boxUV,roofGeo,flatRoofGeo,allMats,clamp,GREENS};
})();
