const $=s=>document.querySelector(s);
const keyToday=()=>{const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`};
const dateObj=k=>new Date(k+"T12:00:00");
const starter=[{id:1,name:"Morning routine",start:"06:30",end:"07:00",category:"Health",reminder:true},{id:2,name:"Study session",start:"09:00",end:"11:00",category:"Study",reminder:true},{id:3,name:"Lunch break",start:"13:00",end:"13:45",category:"Break",reminder:false},{id:4,name:"Focused study",start:"15:00",end:"16:30",category:"Study",reminder:true},{id:5,name:"Evening walk",start:"18:00",end:"18:30",category:"Health",reminder:true}];
let activeMobile=null;
const accountKey="dayflow-local-accounts-v1";
const emptyData=()=>({tasks:starter.map(t=>({...t})),completions:{},health:{water:0,sleep:7,exercise:0,mood:"Okay",energy:3},healthHistory:{},reminderLog:{},reminderEnabled:false});
function load(){try{const a=JSON.parse(localStorage.getItem(accountKey)||"{}");return a[activeMobile]?.data||emptyData()}catch{return emptyData()}}
let data=emptyData(),page="home";
function save(){const a=JSON.parse(localStorage.getItem(accountKey)||"{}");if(activeMobile&&a[activeMobile]){a[activeMobile].data=data;localStorage.setItem(accountKey,JSON.stringify(a))}}
async function pinDigest(pin,salt){const bytes=new TextEncoder().encode(salt+":"+pin);const hash=await crypto.subtle.digest("SHA-256",bytes);return Array.from(new Uint8Array(hash)).map(b=>b.toString(16).padStart(2,"0")).join("")}
let authMode="login";
function setAuthMode(mode){authMode=mode;$("#login-tab").classList.toggle("active",mode==="login");$("#create-tab").classList.toggle("active",mode==="create");$("#pin-submit").textContent=mode==="login"?"Login":"Create account";$("#login-message").textContent=mode==="create"?"Create a local profile using your mobile number and a 4-digit PIN.":"Enter the mobile number and PIN registered on this device."}
$("#login-tab").addEventListener("click",()=>setAuthMode("login"));
$("#create-tab").addEventListener("click",()=>setAuthMode("create"));
$("#pin-form").addEventListener("submit",async e=>{e.preventDefault();const mobile=$("#mobile-number").value.replace(/\D/g,"");const pin=$("#pin-code").value;if(mobile.length<10||mobile.length>15){$("#login-message").textContent="Enter a valid mobile number.";return}if(!/^[0-9]{4}$/.test(pin)){$("#login-message").textContent="PIN must be exactly 4 digits.";return}const accounts=JSON.parse(localStorage.getItem(accountKey)||"{}");const submit=$("#pin-submit");submit.disabled=true;try{if(authMode==="create"){if(accounts[mobile]){$("#login-message").textContent="This number already has an account on this device. Please login.";return}const salt=crypto.randomUUID?crypto.randomUUID():String(Date.now())+Math.random();accounts[mobile]={salt,pinHash:await pinDigest(pin,salt),failed:0,lockedUntil:0,data:emptyData()};localStorage.setItem(accountKey,JSON.stringify(accounts))}else{const record=accounts[mobile];if(!record){$("#login-message").textContent="Account not found on this device. Create an account first.";return}if(record.lockedUntil>Date.now()){$("#login-message").textContent="Too many attempts. Try again later.";return}const hash=await pinDigest(pin,record.salt);if(hash!==record.pinHash){record.failed=(record.failed||0)+1;if(record.failed>=5){record.lockedUntil=Date.now()+300000;record.failed=0}localStorage.setItem(accountKey,JSON.stringify(accounts));$("#login-message").textContent=record.lockedUntil>Date.now()?"Too many wrong attempts. Locked for 5 minutes.":"Incorrect PIN. Attempts remaining: "+(5-record.failed);return}record.failed=0;localStorage.setItem(accountKey,JSON.stringify(accounts))}activeMobile=mobile;data=load();$("#login-screen").hidden=true;$("#main-app").hidden=false;page="home";render();save();applyPendingNativeCompletions()}catch(err){$("#login-message").textContent="Secure PIN processing is unavailable in this app environment."}finally{submit.disabled=false}});

const doneIds=()=>data.completions[keyToday()]||[];
const isDone=id=>doneIds().includes(id);
function save(){
  const accounts=JSON.parse(localStorage.getItem(accountKey)||"{}");
  if(activeMobile && accounts[activeMobile]){
    accounts[activeMobile].data=data;
    localStorage.setItem(accountKey,JSON.stringify(accounts));
    try {
      if (window.DayFlowNative) {
        window.DayFlowNative.syncTasks(JSON.stringify({
          enabled: !!data.reminderEnabled,
          tasks: data.tasks.map(t => ({id:t.id, name:t.name, start:t.start, category:t.category, reminder:!!t.reminder}))
        }));
      }
    } catch(e) {}
  }
}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function pctFor(k){let ids=data.completions[k]||[];return data.tasks.length?Math.round(data.tasks.filter(t=>ids.includes(t.id)).length/data.tasks.length*100):0}
function pct(){return pctFor(keyToday())}
function sorted(){return [...data.tasks].sort((a,b)=>a.start.localeCompare(b.start))}
function dateLabel(){return new Intl.DateTimeFormat("en",{weekday:"long",month:"long",day:"numeric"}).format(new Date())}
function taskHTML(t){let done=isDone(t.id);return `<div class="task ${done?"done":""}"><div class="task-time">${t.start}</div><div class="task-info"><div class="task-name">${esc(t.name)}</div><div class="task-meta"><span class="category-dot"></span>${esc(t.category)} · ${t.start}–${t.end}</div></div><button class="check-btn" data-action="toggle" data-id="${t.id}" aria-label="Toggle ${esc(t.name)}">${done?"✓":""}</button></div>`}
function nextTask(){let now=new Date(),clock=`${String(now.getHours()).padStart(2,"0")}:${String(now.getMinutes()).padStart(2,"0")}`;return sorted().find(t=>!isDone(t.id)&&t.end>clock)}
function home(){let done=doneIds().length,next=nextTask(),past=sorted().filter(t=>!isDone(t.id)&&t.end<=`${String(new Date().getHours()).padStart(2,"0")}:${String(new Date().getMinutes()).padStart(2,"0")}`).length;return `<div class="eyebrow">${dateLabel().toUpperCase()}</div><h2 class="greeting">A calmer day starts here.</h2><p class="muted" style="font-size:13px;margin:5px 0 18px">Small steps, steady progress.</p><section class="card hero"><div class="hero-top"><div><div class="eyebrow" style="color:#766b5a">TODAY'S PROGRESS</div><strong>${pct()}%</strong></div><span class="pill">${done}/${data.tasks.length} completed</span></div><div class="progress-track"><div class="progress-fill" style="width:${pct()}%"></div></div></section><div class="stats"><div class="card"><div class="stat-label">Completed</div><div class="stat-value">${done}</div><div class="tiny muted">Tasks finished today</div></div><div class="card"><div class="stat-label">Remaining</div><div class="stat-value">${data.tasks.length-done}</div><div class="tiny muted">One step at a time</div></div></div><div class="section-head"><h2>Up next</h2><button class="text-btn" data-nav="routine">View routine →</button></div>${next?`<div class="card row"><div><div class="eyebrow">NEXT ACTIVITY · ${next.start}</div><div style="font-weight:750;margin-top:6px">${esc(next.name)}</div><div class="tiny muted">${esc(next.category)} · until ${next.end}</div></div><span class="pill">Upcoming</span></div>`:`<div class="card empty">${past?"No more upcoming activities. Review any unfinished tasks when you're ready.":"No upcoming activities. Your schedule is clear."}</div>`}<div class="section-head"><h2>Today's routine</h2><button class="text-btn" data-action="add">+ Add</button></div><div class="task-list">${sorted().map(taskHTML).join("")||'<div class="card empty">No activities yet. Add your first routine.</div>'}</div>`}
function routine(){return `<div class="eyebrow">YOUR DAILY PLAN</div><div class="row"><h2 class="greeting">My routine</h2><button class="primary-btn" data-action="add">+ Add activity</button></div><p class="muted" style="font-size:13px">Build a schedule that feels realistic and repeatable.</p><div class="task-list" style="margin-top:18px">${sorted().map(t=>`<div>${taskHTML(t)}<div class="actions" style="justify-content:flex-end;margin:5px 5px 8px"><button class="soft-btn" data-action="edit" data-id="${t.id}">Edit</button><button class="danger-btn" data-action="delete" data-id="${t.id}">Delete</button></div></div>`).join("")||'<div class="card empty">No activities scheduled.</div>'}</div><div class="insight"><b>Reminder note</b><br>Reminder preferences are saved. Native Android alarm integration is still required for reliable background alarms.</div>`}
function analytics(){let labels=["M","T","W","T","F","S","S"],today=dateObj(keyToday()),monday=new Date(today);monday.setDate(today.getDate()-((today.getDay()+6)%7));let keys=labels.map((_,i)=>{let d=new Date(monday);d.setDate(monday.getDate()+i);return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`});let vals=keys.map(pctFor),completed=doneIds().length,study=data.tasks.filter(t=>t.category==="Study"&&isDone(t.id)).length;return `<div class="eyebrow">YOUR PROGRESS</div><h2 class="greeting">Insights</h2><p class="muted" style="font-size:13px">Your recorded activity, day by day.</p><div class="stats"><div class="card"><div class="stat-label">Today's completion</div><div class="stat-value">${pct()}%</div></div><div class="card"><div class="stat-label">Study tasks done</div><div class="stat-value">${study}</div></div></div><div class="section-head"><h2>This week</h2><span class="pill">Live records</span></div><div class="card"><div class="bar-chart">${keys.map((k,i)=>`<div class="bar-wrap"><div class="bar-value">${vals[i]}%</div><div class="bar" style="height:${Math.max(vals[i],2)}%"></div><div class="bar-label">${labels[i]}</div></div>`).join("")}</div><p class="tiny muted">Only days with recorded completions contribute to the graph. Empty days remain at 0%.</p></div><div class="section-head"><h2>Today's breakdown</h2></div><div class="card"><div class="row"><span class="muted">Completed activities</span><b>${completed} / ${data.tasks.length}</b></div><div class="progress-track"><div class="progress-fill" style="width:${pct()}%"></div></div><div class="row" style="margin-top:14px"><span class="muted">Pending activities</span><b>${data.tasks.length-completed}</b></div></div><div class="insight"><b>DayFlow tip</b><br>${pct()>=80?"Great consistency today. Keep your schedule realistic and protect your rest time.":"Choose one manageable pending activity and start there. Consistency matters more than a perfect day."}</div>`}
function health(){let h=data.health;return `<div class="eyebrow">WELLBEING CHECK-IN</div><h2 class="greeting">Health & habits</h2><p class="muted" style="font-size:13px">Track simple daily signals. This is a wellness journal, not medical advice.</p><div class="field-grid" style="margin-top:18px"><div class="metric"><label>Water (glasses)<input type="number" min="0" max="30" id="water" value="${h.water}"></label></div><div class="metric"><label>Sleep (hours)<input type="number" min="0" max="24" step=".5" id="sleep" value="${h.sleep}"></label></div><div class="metric"><label>Exercise (minutes)<input type="number" min="0" max="600" id="exercise" value="${h.exercise}"></label></div><div class="metric"><label>Energy (1–5)<input type="number" min="1" max="5" id="energy" value="${h.energy}"></label></div></div><div class="card" style="margin-top:12px"><label>Mood today<select id="mood">${["Great","Good","Okay","Low","Stressed"].map(x=>`<option ${h.mood===x?"selected":""}>${x}</option>`).join("")}</select></label><button class="primary-btn full" data-action="save-health">Save today's check-in</button></div><div class="insight"><b>Gentle reminder</b><br>Look for patterns over time, not one-off numbers. Your daily check-ins are saved by date on this device.</div>`}

let reminderAudio=null,ringLoop=null,scheduledLoop=null;
function applyPendingNativeCompletions(){
  try {
    if (!window.DayFlowNative || !window.DayFlowNative.getPendingCompletions) return;
    const pending = JSON.parse(window.DayFlowNative.getPendingCompletions() || "[]");
    if (!Array.isArray(pending) || pending.length === 0) return;
    // Do not clear the native queue unless every action was applied to the
    // currently signed-in account. Unknown task IDs remain queued safely.
    const allApplied = pending.every(item => window.applyNotificationCompletion(item.id, item.day));
    if (allApplied && window.DayFlowNative.clearPendingCompletions) {
      window.DayFlowNative.clearPendingCompletions();
    }
  } catch (e) { /* Keep pending native actions for the next login if parsing fails. */ }
}
window.applyNotificationCompletion = function(taskId, dayKey) {
  const id = Number(taskId);
  if (!Number.isFinite(id) || !data || !Array.isArray(data.tasks) || !data.tasks.some(t => Number(t.id) === id)) return false;
  data.completions = data.completions || {};
  const key = dayKey || keyToday();
  data.completions[key] = data.completions[key] || [];
  if (!data.completions[key].includes(id)) data.completions[key].push(id);
  save();
  if (page) render();
  return true;
};
function reminderStatus(){
 const el=$("#reminder-status");if(!el)return;
 el.textContent=data.reminderEnabled?"Enabled (while app is open)":"Not enabled";
}
function reminderPrefs(){
 return {mode:data.reminderPrefs?.mode||"sound_vibrate",tone:data.reminderPrefs?.tone||"gentle"};
}
function beep(){
 const prefs=reminderPrefs();
 if(prefs.mode==="vibrate"||prefs.mode==="silent")return;
 const frequencies={gentle:660,chime:1046,classic:880,digital:1320};
 const freq=frequencies[prefs.tone]||660;
 try{
  reminderAudio=reminderAudio||new (window.AudioContext||window.webkitAudioContext)();
  if(reminderAudio.state==="suspended")reminderAudio.resume();
  const osc=reminderAudio.createOscillator(),gain=reminderAudio.createGain();
  osc.type=prefs.tone==="digital"?"square":"sine";osc.frequency.value=freq;
  gain.gain.setValueAtTime(0.001,reminderAudio.currentTime);
  gain.gain.exponentialRampToValueAtTime(.14,reminderAudio.currentTime+.04);
  gain.gain.exponentialRampToValueAtTime(.001,reminderAudio.currentTime+.55);
  osc.connect(gain);gain.connect(reminderAudio.destination);
  osc.start();osc.stop(reminderAudio.currentTime+.6);
 }catch(err){toast("Sound is blocked by this preview. Try the installed app.")}
}

function alarmPopup(task){
 let layer=$("#df-alarm");
 if(!layer){layer=document.createElement("div");layer.id="df-alarm";layer.className="df-alarm";document.body.appendChild(layer)}
 layer.innerHTML=`<div class="df-alarm-card"><div class="eyebrow">DAYFLOW REMINDER</div><h2>${esc(task.name)}</h2><p>${esc(task.start)} · ${esc(task.category||"Activity")}</p><p class="muted">It's time for your activity.</p><div class="df-alarm-actions"><button class="soft-btn" data-alarm="snooze">Snooze 5 min</button><button class="primary-btn" data-alarm="dismiss">Dismiss</button></div></div>`;
 layer.hidden=false;
 if(ringLoop)clearInterval(ringLoop);
 beep();ringLoop=setInterval(beep,1300);
 const prefs=reminderPrefs();
 if((prefs.mode==="vibrate"||prefs.mode==="sound_vibrate")&&navigator.vibrate)navigator.vibrate([350,150,350,150,500]);
 layer.onclick=e=>{
  const b=e.target.closest("[data-alarm]");if(!b)return;
  clearInterval(ringLoop);ringLoop=null;layer.hidden=true;
  if(b.dataset.alarm==="snooze"){
   setTimeout(()=>{if(activeMobile)alarmPopup(task)},5*60*1000);
  }
 };
}
function loadReminderPrefsIntoUI(){
 const prefs=reminderPrefs();
 const mode=$("#reminder-mode"),tone=$("#reminder-tone");
 if(mode)mode.value=prefs.mode;
 if(tone)tone.value=prefs.tone;
}
function saveReminderPrefs(){
 data.reminderPrefs={mode:$("#reminder-mode")?.value||"sound_vibrate",tone:$("#reminder-tone")?.value||"gentle"};
 save();toast("Reminder preferences saved");
}
async function enableReminders(){
 // A user tap unlocks audio on mobile browsers.
 try{reminderAudio=reminderAudio||new (window.AudioContext||window.webkitAudioContext)();await reminderAudio.resume()}catch{}
 if("Notification" in window){
  try{const permission=await Notification.requestPermission();data.notificationPermission=permission;}catch{}
 }
 data.reminderEnabled=true;
 try { if (window.DayFlowNative && window.DayFlowNative.requestExactAlarmAccess) window.DayFlowNative.requestExactAlarmAccess(); } catch(e) {}
 save();reminderStatus();
 toast("Reminders enabled. Allow exact alarms in Android settings if prompted.");
}
function runReminderCheck(){
 if(!activeMobile||!data.reminderEnabled||document.hidden)return;
 const now=new Date(),hm=String(now.getHours()).padStart(2,"0")+":"+String(now.getMinutes()).padStart(2,"0");
 data.reminderLog=data.reminderLog||{};
 for(const task of data.tasks){
  if(!task.reminder||task.start!==hm)continue;
  const key=keyToday()+":"+task.id;
  if(data.reminderLog[key])continue;
  data.reminderLog[key]=true;save();
  if("Notification" in window&&Notification.permission==="granted"){
   try{new Notification("DayFlow · "+task.name,{body:"Your scheduled activity starts now."})}catch{}
  }
  alarmPopup(task);
 }
}
if(!scheduledLoop)scheduledLoop=setInterval(runReminderCheck,10000);
document.addEventListener("visibilitychange",()=>{if(!document.hidden)runReminderCheck()});
function profile(){return `<div class="eyebrow">YOUR ACCOUNT</div><h2 class="greeting">Profile & settings</h2><div class="card" style="margin-top:18px"><div class="row"><div><b>+${esc(activeMobile||"")}</b><div class="tiny muted">This-device profile</div></div><span class="pill">PIN login</span></div></div><div class="section-head"><h2>App settings</h2></div><div class="card"><div class="profile-row row"><span>Theme</span><b>Warm cream</b></div><div class="profile-row row"><span>Data storage</span><b>This device only</b></div><div class="profile-row row"><span>Login</span><b>Mobile + 4-digit PIN</b></div><div class="profile-row row"><span>Cloud sync</span><b>Not connected</b></div><div class="profile-row row"><span>Alarm scheduling</span><b>Native integration needed</b></div><div class="profile-row row"><span>Reminder permission</span><b id="reminder-status">Not enabled</b></div>
<div class="section-head"><h2>Reminder preferences</h2></div>
<div class="preference-field"><label for="reminder-mode">Alert mode</label><select id="reminder-mode"><option value="sound_vibrate">Sound + vibration</option><option value="vibrate">Vibration only</option><option value="sound">Sound only</option><option value="silent">Silent</option></select></div>
<div class="preference-field"><label for="reminder-tone">Sound</label><select id="reminder-tone"><option value="gentle">Gentle Bell</option><option value="chime">Soft Chime</option><option value="classic">Classic Alarm</option><option value="digital">Digital Beep</option></select></div>
<p class="tiny muted">Choose how in-app alarms alert you. Sound selection applies to the in-app alarm tone.</p>
<button class="soft-btn full" data-action="save-reminder-prefs">Save reminder preferences</button><button class="soft-btn full" data-action="enable-reminders">Enable reminders & sound</button><button class="soft-btn full" data-action="test-alarm">Test alarm sound</button><button class="soft-btn full" data-action="change-pin">Change 4-digit PIN</button><button class="soft-btn full" data-action="export-backup">Export my backup</button><button class="soft-btn full" data-action="import-backup">Restore backup</button><input id="backup-file" type="file" accept="application/json,.json" hidden><button class="soft-btn full" data-action="logout">Log out</button><button class="soft-btn full" data-action="reset">Reset this account's data</button></div><p class="tiny muted">Your routines and check-ins are saved on this device. Export a backup before changing phones or reinstalling. Backup files contain personal routine and health information; keep them private. This is a local PIN prototype, not secure cloud authentication.</p>`}function render(){let views={home,routine,analytics,health,profile};$("#view").innerHTML=views[page]();document.querySelectorAll(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.nav===page));reminderStatus();loadReminderPrefsIntoUI()}
function toast(msg){let t=$("#toast");t.textContent=msg;t.classList.add("show");clearTimeout(window.toastTimer);window.toastTimer=setTimeout(()=>t.classList.remove("show"),2200)}
function openTask(id){let t=data.tasks.find(x=>x.id===Number(id));$("#dialog-title").textContent=t?"Edit activity":"New activity";$("#task-id").value=t?.id||"";$("#task-name").value=t?.name||"";$("#task-start").value=t?.start||"15:00";$("#task-end").value=t?.end||"16:00";$("#task-category").value=t?.category||"Study";$("#task-reminder").checked=t?.reminder??true;$("#task-dialog").showModal()}

async function changePin(){
  const oldPin=prompt("Enter your current 4-digit PIN");
  if(oldPin===null)return;
  if(!/^\d{4}$/.test(oldPin)){toast("PIN must be exactly 4 digits");return}
  const accounts=JSON.parse(localStorage.getItem(accountKey)||"{}");
  const record=accounts[activeMobile];
  if(!record || await pinDigest(oldPin,record.salt)!==record.pinHash){toast("Current PIN is incorrect");return}
  const next=prompt("Enter your new 4-digit PIN");
  if(next===null)return;
  if(!/^\d{4}$/.test(next)){toast("New PIN must be exactly 4 digits");return}
  const confirmPin=prompt("Confirm your new 4-digit PIN");
  if(confirmPin!==next){toast("PIN confirmation does not match");return}
  const salt=crypto.randomUUID?crypto.randomUUID():String(Date.now())+Math.random();
  record.salt=salt;record.pinHash=await pinDigest(next,salt);record.failed=0;record.lockedUntil=0;
  localStorage.setItem(accountKey,JSON.stringify(accounts));toast("PIN changed successfully");
}
function exportBackup(){
  const payload={app:"DayFlow",version:1,exportedAt:new Date().toISOString(),mobile:activeMobile,data};
  const blob=new Blob([JSON.stringify(payload,null,2)],{type:"application/json"});
  const url=URL.createObjectURL(blob);const a=document.createElement("a");
  a.href=url;a.download="dayflow-backup-"+activeMobile+"-"+keyToday()+".json";
  document.body.appendChild(a);a.click();a.remove();URL.revokeObjectURL(url);
  toast("Backup exported. Keep the file private.");
}
document.addEventListener("change",async e=>{
  if(e.target.id!=="backup-file")return;
  const file=e.target.files?.[0];if(!file)return;
  try{
    const parsed=JSON.parse(await file.text());
    if(parsed.app!=="DayFlow"||!parsed.data||!Array.isArray(parsed.data.tasks)||typeof parsed.data.completions!=="object"||typeof parsed.data.health!=="object")throw new Error("Invalid backup");
    if(parsed.mobile && parsed.mobile!==activeMobile && !confirm("This backup belongs to a different mobile number. Restore it into the currently signed-in account?")){e.target.value="";return}
    if(!confirm("Restore backup? This will replace the current account's routines and check-ins.")){e.target.value="";return}
    data={...emptyData(),...parsed.data};
    save();render();toast("Backup restored successfully");
  }catch(err){toast("Could not restore: invalid or damaged backup")}
  finally{e.target.value=""}
});
document.addEventListener("click",e=>{let nav=e.target.closest("[data-nav]");if(nav){page=nav.dataset.nav;render();return}let b=e.target.closest("[data-action]");if(!b)return;if(b.dataset.action==="logout"){activeMobile=null;data=emptyData();$("#main-app").hidden=true;$("#login-screen").hidden=false;$("#pin-code").value="";$("#login-message").textContent="You have been logged out.";return}
if(b.dataset.action==="change-pin"){changePin();return}
if(b.dataset.action==="enable-reminders"){enableReminders();return}
if(b.dataset.action==="save-reminder-prefs"){saveReminderPrefs();return}
if(b.dataset.action==="test-alarm"){alarmPopup({name:"DayFlow test alarm",start:"Now",category:"Test"});return}
if(b.dataset.action==="export-backup"){exportBackup();return}
if(b.dataset.action==="import-backup"){$("#backup-file").click();return}
let id=b.dataset.id,t=data.tasks.find(x=>x.id===Number(id));switch(b.dataset.action){case"add":openTask();break;case"edit":openTask(id);break;case"toggle":if(t){let ids=doneIds();data.completions[keyToday()]=ids.includes(t.id)?ids.filter(x=>x!==t.id):[...ids,t.id];save();render();toast(isDone(t.id)?"Activity completed":"Marked as pending")}break;case"delete":if(t&&confirm(`Delete "${t.name}"?`)){data.tasks=data.tasks.filter(x=>x.id!==t.id);save();render();toast("Activity deleted")}break;case"save-health":{let n=s=>Number($(s).value);data.health={water:n("#water"),sleep:n("#sleep"),exercise:n("#exercise"),energy:n("#energy"),mood:$("#mood").value};data.healthHistory[keyToday()]={...data.health};save();toast("Today's check-in saved");break}case"reset":if(confirm("Reset all demo routines and health data?")){data=emptyData();save();page="home";render();toast("Account data reset")}break}});
$("#task-form").addEventListener("submit",e=>{e.preventDefault();let id=Number($("#task-id").value),name=$("#task-name").value.trim(),start=$("#task-start").value,end=$("#task-end").value;if(!name||end<=start){toast("Please enter a name and valid time range");return}let obj={id:id||Date.now(),name,start,end,category:$("#task-category").value,reminder:$("#task-reminder").checked};if(id)data.tasks=data.tasks.map(t=>t.id===id?obj:t);else data.tasks.push(obj);save();$("#task-dialog").close();render();toast("Activity saved")});
$("#close-dialog").addEventListener("click",()=>$("#task-dialog").close());
$("#main-app").hidden=true;
