// Cosmic Orbit - Mobile HTML5 Canvas Game
const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
const scoreEl = document.getElementById('score');
const bestEl = document.getElementById('best');
const finalScoreEl = document.getElementById('final-score');
const startScreen = document.getElementById('start-screen');
const gameoverScreen = document.getElementById('gameover-screen');
const startBtn = document.getElementById('start-btn');
const restartBtn = document.getElementById('restart-btn');

let width, height;
function resize() {
  width = canvas.width = window.innerWidth;
  height = canvas.height = window.innerHeight;
}
window.addEventListener('resize', resize);
resize();

let state = 'start';
let score = 0;
let best = parseInt(localStorage.getItem('cosmic_best') || '0', 10);
bestEl.textContent = best;

let angle = 0;
let orbitRadius = 80;
let targetRadius = 80;
let isHolding = false;
let obstacles = [];
let particles = [];
let stars = [];

for (let i = 0; i < 60; i++) {
  stars.push({
    x: Math.random() * 800,
    y: Math.random() * 1000,
    size: Math.random() * 2,
    alpha: Math.random() * 0.7 + 0.3
  });
}

function spawnObstacle() {
  const isOuter = Math.random() > 0.5;
  obstacles.push({
    dist: Math.max(width, height) * 0.6,
    angle: Math.random() * Math.PI * 2,
    radius: isOuter ? 120 : 60,
    size: 14 + Math.random() * 8,
    speed: 1.8 + Math.min(score * 0.05, 3.5),
    color: isOuter ? '#f43f5e' : '#a855f7'
  });
}

let lastSpawn = 0;

function createExplosion(x, y, color) {
  for (let i = 0; i < 20; i++) {
    particles.push({
      x, y,
      vx: (Math.random() - 0.5) * 8,
      vy: (Math.random() - 0.5) * 8,
      life: 1,
      color
    });
  }
  if (navigator.vibrate) {
    navigator.vibrate(80);
  }
}

function startGame() {
  state = 'playing';
  score = 0;
  scoreEl.textContent = '0';
  obstacles = [];
  particles = [];
  orbitRadius = 80;
  targetRadius = 80;
  angle = 0;
  startScreen.classList.add('hidden');
  gameoverScreen.classList.add('hidden');
}

function gameOver() {
  state = 'gameover';
  finalScoreEl.textContent = score;
  if (score > best) {
    best = score;
    localStorage.setItem('cosmic_best', best);
    bestEl.textContent = best;
  }
  gameoverScreen.classList.remove('hidden');
}

startBtn.addEventListener('click', startGame);
restartBtn.addEventListener('click', startGame);

window.addEventListener('pointerdown', () => { isHolding = true; });
window.addEventListener('pointerup', () => { isHolding = false; });
window.addEventListener('pointercancel', () => { isHolding = false; });

let lastTime = performance.now();
function loop(now) {
  const dt = (now - lastTime) / 1000;
  lastTime = now;

  ctx.fillStyle = '#030712';
  ctx.fillRect(0, 0, width, height);

  // Draw background stars
  ctx.fillStyle = '#ffffff';
  stars.forEach(s => {
    ctx.globalAlpha = s.alpha;
    ctx.beginPath();
    ctx.arc(s.x % width, s.y % height, s.size, 0, Math.PI * 2);
    ctx.fill();
  });
  ctx.globalAlpha = 1;

  const cx = width / 2;
  const cy = height / 2;

  // Orbit center core
  ctx.beginPath();
  ctx.arc(cx, cy, 26, 0, Math.PI * 2);
  const coreGrad = ctx.createRadialGradient(cx, cy, 2, cx, cy, 26);
  coreGrad.addColorStop(0, '#38bdf8');
  coreGrad.addColorStop(1, '#0284c7');
  ctx.fillStyle = coreGrad;
  ctx.shadowColor = '#38bdf8';
  ctx.shadowBlur = 20;
  ctx.fill();
  ctx.shadowBlur = 0;

  // Orbit rings
  ctx.strokeStyle = 'rgba(56, 189, 248, 0.15)';
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.arc(cx, cy, 60, 0, Math.PI * 2);
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(cx, cy, 120, 0, Math.PI * 2);
  ctx.stroke();

  if (state === 'playing') {
    targetRadius = isHolding ? 120 : 60;
    orbitRadius += (targetRadius - orbitRadius) * 0.15;
    angle += 2.5 * dt;

    if (now - lastSpawn > Math.max(700, 1500 - score * 30)) {
      spawnObstacle();
      lastSpawn = now;
      score++;
      scoreEl.textContent = score;
    }
  }

  // Player position
  const px = cx + Math.cos(angle) * orbitRadius;
  const py = cy + Math.sin(angle) * orbitRadius;

  // Draw Player
  ctx.beginPath();
  ctx.arc(px, py, 9, 0, Math.PI * 2);
  ctx.fillStyle = '#34d399';
  ctx.shadowColor = '#34d399';
  ctx.shadowBlur = 12;
  ctx.fill();
  ctx.shadowBlur = 0;

  // Obstacles
  for (let i = obstacles.length - 1; i >= 0; i--) {
    const o = obstacles[i];
    if (state === 'playing') {
      o.dist -= o.speed;
    }
    const ox = cx + Math.cos(o.angle) * o.dist;
    const oy = cy + Math.sin(o.angle) * o.dist;

    ctx.beginPath();
    ctx.arc(ox, oy, o.size, 0, Math.PI * 2);
    ctx.fillStyle = o.color;
    ctx.fill();

    // Collision check
    if (state === 'playing' && Math.hypot(px - ox, py - oy) < (9 + o.size)) {
      createExplosion(px, py, '#f43f5e');
      gameOver();
    }

    if (o.dist < 10) {
      obstacles.splice(i, 1);
    }
  }

  // Particles
  for (let i = particles.length - 1; i >= 0; i--) {
    const p = particles[i];
    p.x += p.vx;
    p.y += p.vy;
    p.life -= dt * 2;
    if (p.life <= 0) {
      particles.splice(i, 1);
      continue;
    }
    ctx.beginPath();
    ctx.arc(p.x, p.y, 3 * p.life, 0, Math.PI * 2);
    ctx.fillStyle = p.color;
    ctx.globalAlpha = p.life;
    ctx.fill();
    ctx.globalAlpha = 1;
  }

  requestAnimationFrame(loop);
}
requestAnimationFrame(loop);
console.log("Cosmic Orbit Game initialized successfully.");