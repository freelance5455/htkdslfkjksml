const picker=document.getElementById('filePicker');
const openBtn=document.getElementById('openPdfBtn');
const list=document.getElementById('documentList');
const count=document.getElementById('fileCount');
const records=[];
openBtn.addEventListener('click',()=>picker.click());
picker.addEventListener('change',()=>{
  const file=picker.files?.[0]; if(!file)return;
  if(file.type!=='application/pdf'&&!file.name.toLowerCase().endsWith('.pdf')){alert('Selecciona un archivo PDF.');return;}
  records.unshift({name:file.name,size:file.size,lastOpened:new Date(),file});
  render();
});
function render(){
  count.textContent=`${records.length} documento${records.length===1?'':'s'}`;
  if(!records.length)return;
  list.className='';
  list.innerHTML='';
  records.forEach(r=>{
    const item=document.createElement('article');item.className='featured';item.style.marginBottom='10px';
    const mark=document.createElement('div');mark.className='pdf-mark';mark.textContent='PDF';
    const info=document.createElement('div');const name=document.createElement('strong');name.textContent=r.name;
    const meta=document.createElement('p');meta.textContent=`${(r.size/1024).toFixed(0)} KB · Añadido ahora`;
    info.append(name,meta);item.append(mark,info);list.append(item);
  });
  const last=document.getElementById('lastOpened');last.classList.remove('empty');
  last.querySelector('strong').textContent=records[0].name;
  last.querySelector('p').textContent='Último documento seleccionado';
}
const dialog=document.getElementById('settingsDialog');
document.getElementById('settingsBtn').onclick=()=>dialog.showModal();
document.getElementById('settingsNavBtn').onclick=()=>dialog.showModal();
document.getElementById('themeSelect').onchange=e=>document.body.classList.toggle('dark',e.target.value==='dark'||(e.target.value==='system'&&matchMedia('(prefers-color-scheme: dark)').matches));
document.getElementById('searchInput').oninput=e=>{
 const q=e.target.value.toLocaleLowerCase();
 [...list.children].forEach((el,i)=>el.hidden=!records[i].name.toLocaleLowerCase().includes(q));
};
if('serviceWorker' in navigator)window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}));
