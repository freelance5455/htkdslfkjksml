
(function() {
    "use strict";

    /* ═══════════════════════════════════════════════════════
       ⭐ CONFIGURATION & PASSWORD ⭐
       ═══════════════════════════════════════════════════════ */
    const OFFLINE_VIP_PASSWORD = "MEHEDIVAI115";
    const WIDGET_CARD_VIDEO = "https://files.catbox.moe/rvhgmu.mp4";
    const DEFAULT_GAME_URL = "https://dkwin15.com/#/register?invitationCode=81566119106";
    const PERIOD_DURATION_MS = 30000;
    const SCAN_DURATION_MS = 900;

    /* ═══════════════════════════════════════════════════════
       AUDIO SYNTHESIZER (WEB AUDIO API - ZERO EXTERNAL LAG)
       ═══════════════════════════════════════════════════════ */
    let audioCtx = null;
    let soundEnabled = true;

    function initAudio() {
        if (!audioCtx) {
            try {
                audioCtx = new (window.AudioContext || window.webkitAudioContext)();
            } catch(e) {}
        }
        if (audioCtx && audioCtx.state === "suspended") {
            audioCtx.resume();
        }
    }

    function playCyberBeep(freq = 880, type = "sine", duration = 0.08) {
        if (!soundEnabled) return;
        try {
            initAudio();
            if (!audioCtx) return;
            const osc = audioCtx.createOscillator();
            const gain = audioCtx.createGain();
            osc.type = type;
            osc.frequency.setValueAtTime(freq, audioCtx.currentTime);
            gain.gain.setValueAtTime(0.12, audioCtx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + duration);
            osc.connect(gain);
            gain.connect(audioCtx.destination);
            osc.start();
            osc.stop(audioCtx.currentTime + duration);
        } catch(e) {}
    }

    function playScanHum() {
        if (!soundEnabled) return;
        try {
            initAudio();
            if (!audioCtx) return;
            const osc = audioCtx.createOscillator();
            const gain = audioCtx.createGain();
            osc.type = "sawtooth";
            osc.frequency.setValueAtTime(220, audioCtx.currentTime);
            osc.frequency.exponentialRampToValueAtTime(660, audioCtx.currentTime + 0.9);
            gain.gain.setValueAtTime(0.08, audioCtx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.9);
            osc.connect(gain);
            gain.connect(audioCtx.destination);
            osc.start();
            osc.stop(audioCtx.currentTime + 0.9);
        } catch(e) {}
    }

    function playSuccessChime() {
        if (!soundEnabled) return;
        try {
            playCyberBeep(523.25, "triangle", 0.12);
            setTimeout(() => playCyberBeep(659.25, "triangle", 0.12), 100);
            setTimeout(() => playCyberBeep(783.99, "triangle", 0.15), 200);
            setTimeout(() => playCyberBeep(1046.50, "sine", 0.35), 300);
        } catch(e) {}
    }

    function playLockSound() {
        if (!soundEnabled) return;
        try {
            playCyberBeep(1200, "square", 0.06);
            setTimeout(() => playCyberBeep(1800, "square", 0.12), 70);
        } catch(e) {}
    }

    /* ═══════════════════════════════════════════════════════
       STATE
       ═══════════════════════════════════════════════════════ */
    let loggedIn = false;
    let curState = "login";
    let bypassRunning = false;
    let lastPeriod = null;
    let lockedPeriod = null;
    let lockedPrediction = null;
    let wingoHackDone = false;
    let latestMarketHistory = [];
    let activePrediction = null;
    let autoLoopActive = false;
    let periodCountdownTimer = null;
    let periodEndTime = 0;

    /* ═══════════════════════════════════════════════════════
       DOM REFS
       ═══════════════════════════════════════════════════════ */
    let mainPanel, cardOuter, orbEl, actionBtn, closeBtn;
    let statusOverlay, stageScanner, predDisplay, dregEyeRing;
    let statusMain, statusSub, statusHint, statusText, actionBtnLabel;
    let predBadge, predNumImg, predNumVal, predPeriodBox, predTimerFill, predTimerText;
    let accVal, patternVal, scanPctText, scanPhase, scanLogText, scanFlash;
    let pwInputWrap, pwInput, pwMsg, gameFrame, boxVid;
    let tagColor, tagRisk;

    /* ═══════════════════════════════════════════════════════
       NEW & EXISTING SIGNAL PREDICTION LOGIC ENGINE
       ═══════════════════════════════════════════════════════ */
    function getFallbackPeriod(now) {
        const y = now.getFullYear();
        const m = String(now.getMonth() + 1).padStart(2, "0");
        const d = String(now.getDate()).padStart(2, "0");
        const totalSec = (now.getHours() * 3600) + (now.getMinutes() * 60) + now.getSeconds();
        const issueToday = Math.floor(totalSec / 30) + 1;
        return `${y}${m}${d}1000${String(issueToday).padStart(4, "0")}`;
    }

    async function fetchRealPeriod() {
        const ts = Date.now();
        const directUrl = `https://draw.ar-lottery01.com/WinGo/WinGo_30S/GetHistoryIssuePage.json?ts=${ts}`;
        const fallbackUrl = `https://api.allorigins.win/raw?url=${encodeURIComponent(directUrl)}`;
        let res = null;
        try {
            res = await fetch(directUrl, { cache: "no-store" });
            if (!res.ok) throw new Error();
        } catch(e) {
            try { res = await fetch(fallbackUrl, { cache: "no-store" }); } catch(e2) { return null; }
        }
        try {
            if (!res || !res.ok) return null;
            const jsonData = await res.json();
            if (jsonData?.data?.list && Array.isArray(jsonData.data.list) && jsonData.data.list.length > 0) {
                latestMarketHistory = jsonData.data.list;
                const latest = jsonData.data.list[0];
                let rawIssue = latest.issueNumber || latest.issue || latest.period;
                if (!rawIssue) return null;
                let nextPeriod = (BigInt(rawIssue) + 1n).toString();
                let actualDrawn = null;
                if (latest.number !== undefined && latest.number !== null && latest.number !== "") {
                    actualDrawn = Number(latest.number);
                }
                return {
                    nextPeriod: nextPeriod,
                    completedIssue: String(rawIssue),
                    drawnNumber: actualDrawn
                };
            }
        } catch(err) {
            return null;
        }
        return null;
    }

    function getLuckyNumberForSignal(isBig) {
        if (isBig) {
            const bigs = [5, 6, 7, 8, 9];
            return bigs[Math.floor(Math.random() * bigs.length)];
        } else {
            const smalls = [0, 1, 2, 3, 4];
            return smalls[Math.floor(Math.random() * smalls.length)];
        }
    }

    function getColorForNumber(num) {
        if (num === 0 || num === 5) return { name: "VIOLET", cls: "violet" };
        if ([1, 3, 7, 9].includes(num)) return { name: "GREEN", cls: "green" };
        return { name: "RED", cls: "red" };
    }

    function generateSmartPrediction() {
        let isBig = true;
        let streakText = "MEHEDI APEX AI";
        let riskText = "1X SAFE";

        if (latestMarketHistory && latestMarketHistory.length >= 3) {
            const marketItems = latestMarketHistory.slice(0, 12).map(item => {
                const num = Number(item.number ?? item.actualDrawn ?? 0);
                const size = (item.size || (num >= 5 ? "BIG" : "SMALL")).toUpperCase();
                return { num, size };
            });

            const n = marketItems.length;
            const s = marketItems.map(m => m.size);
            const currentStreakSize = s[0];
            let streakCount = 1;
            for (let i = 1; i < s.length; i++) {
                if (s[i] === currentStreakSize) streakCount++;
                else break;
            }

            /* ── ALL ORIGINAL SIGNAL PATTERNS PRESERVED ── */
            const is_2_2_shift = (n >= 4 && streakCount === 2 &&
                                   s[0] === s[1] && s[2] === s[3] &&
                                   s[0] !== s[2]);

            const is_2_2_pairing = (n >= 3 && streakCount === 1 &&
                                     s[0] !== s[1] && s[1] === s[2] &&
                                     (n < 4 || s[3] !== s[1]));

            const isAlternating = (n >= 3 && s[0] !== s[1] && s[1] !== s[2]);

            /* ── NEW ADVANCED SIGNAL PATTERNS ADDED ── */
            // 1. Triple-Harmonic Cycle (3B-3S): 3 identical followed by switch or pairing
            const is_3_3_cycle = (n >= 6 && s[0] === s[1] && s[1] === s[2] &&
                                   s[3] === s[4] && s[4] === s[5] && s[0] !== s[3]);

            // 2. Quantum Break: Extreme streaks (6+) tend to reverse via Poisson distribution
            const is_quantum_break = (streakCount >= 6);

            // 3. Mirror Palindrome pattern: [B, S, B, B, S, B]
            const is_mirror = (n >= 6 && s[0] === s[5] && s[1] === s[4] && s[2] === s[3]);

            if (is_quantum_break) {
                // Quantum reversal on extended dragon
                isBig = (currentStreakSize === "SMALL");
                streakText = "QUANTUM BREAK (" + streakCount + "X)";
                riskText = "3X OFFENSIVE";
            } else if (is_3_3_cycle) {
                // 3B-3S Cycle shift
                isBig = (currentStreakSize === "SMALL");
                streakText = "3B-3S HARMONIC";
                riskText = "2X DEFENSE";
            } else if (is_mirror) {
                // Symmetry follow
                isBig = (s[0] === "BIG");
                streakText = "MIRROR SYMMETRY";
                riskText = "1X SAFE";
            } else if (is_2_2_shift) {
                isBig = (currentStreakSize === "SMALL");
                streakText = "2B-2S SHIFT";
                riskText = "1X SAFE";
            } else if (is_2_2_pairing) {
                isBig = (currentStreakSize === "BIG");
                streakText = "2B-2S PAIR";
                riskText = "1X SAFE";
            } else if (streakCount >= 3) {
                isBig = (currentStreakSize === "BIG");
                streakText = `${currentStreakSize} DRAGON (${streakCount})`;
                riskText = streakCount >= 4 ? "2X DEFENSE" : "1X SAFE";
            } else if (isAlternating) {
                isBig = (s[0] === "SMALL");
                streakText = "ZIG-ZAG CYCLE";
                riskText = "1X SAFE";
            } else if (streakCount === 2) {
                isBig = (currentStreakSize === "BIG");
                streakText = `${currentStreakSize} DRAGON`;
                riskText = "1X SAFE";
            } else {
                // Momentum Weighted Calculation
                let bigW = 0, smallW = 0;
                const weights = [5, 4, 3, 2, 1];
                for (let i = 0; i < Math.min(n, 5); i++) {
                    if (s[i] === "BIG") bigW += weights[i];
                    else smallW += weights[i];
                }
                isBig = bigW >= smallW;
                streakText = isBig ? "BIG MOMENTUM" : "SMALL MOMENTUM";
                riskText = "1X SAFE";
            }
        } else {
            const lastSig = activePrediction ? activePrediction.signal : "BIG";
            isBig = (lastSig === "SMALL");
            streakText = isBig ? "MEHEDI NEURAL B" : "MEHEDI NEURAL S";
            riskText = "1X SAFE";
        }

        const number = getLuckyNumberForSignal(isBig);
        const colorInfo = getColorForNumber(number);
        const acc = Math.floor(Math.random() * 5) + 95; // 95% - 99%

        return {
            isBig,
            signal: isBig ? "BIG" : "SMALL",
            number,
            colorInfo,
            acc,
            streakText,
            riskText
        };
    }

    function getCurrentPeriodEndMs() {
        const now = Date.now();
        const d = new Date(now);
        const sec = d.getSeconds();
        const ms = d.getMilliseconds();
        const secIntoPeriod = sec % 30;
        const msIntoPeriod = secIntoPeriod * 1000 + ms;
        const remainMs = PERIOD_DURATION_MS - msIntoPeriod;
        return now + remainMs;
    }

    /* ═══════════════════════════════════════════════════════
       AUTHENTICATION LOGIC (CHANGED TO: MEHEDIVAI115)
       ═══════════════════════════════════════════════════════ */
    function grantAccess() {
        loggedIn = true;
        pwMsg.textContent = "";
        pwInput.value = "";
        pwInputWrap.classList.remove("show");
        curState = "home";
        playSuccessChime();
        updateUI();
        startAutoLoop();
    }

    function attemptLogin() {
        const val = (pwInput.value || "").trim();
        if (!val) {
            pwMsg.style.color = "var(--red, #ff2a55)";
            pwMsg.textContent = "✕ ENTER VIP KEY";
            failShake();
            return;
        }
        // Accepts MEHEDIVAI115 (case-insensitive)
        if (val.toUpperCase() === OFFLINE_VIP_PASSWORD || val === OFFLINE_VIP_PASSWORD) {
            grantAccess();
        } else {
            pwMsg.style.color = "var(--red, #ff2a55)";
            pwMsg.textContent = "✕ INVALID VIP KEY";
            playCyberBeep(240, "sawtooth", 0.2);
            failShake();
        }
    }

    function failShake() {
        pwInput.value = "";
        pwInput.focus();
        pwInput.style.animation = "none";
        void pwInput.offsetWidth;
        pwInput.style.animation = "sxShake .4s";
        setActionLabel("LOGIN");
    }

    /* ═══════════════════════════════════════════════════════
       UI HELPERS & CONTROLS
       ═══════════════════════════════════════════════════════ */
    function setStatusUI(main, sub, hint) {
        statusMain.textContent = main;
        statusSub.textContent = sub;
        statusHint.textContent = hint;
    }

    function setActionLabel(label) {
        if (label === "EXECUTE" || label === "LOGIN") {
            actionBtnLabel.innerHTML = "▶ " + label;
        } else {
            actionBtnLabel.innerHTML = label;
        }
    }

    function showStatus() {
        statusOverlay.classList.add("show");
        statusOverlay.style.display = "flex";
        predDisplay.classList.remove("active", "reveal");
        stageScanner.classList.remove("active");
        stopScannerCanvas();
        if (dregEyeRing) dregEyeRing.style.opacity = ".35";
    }

    function showPrediction(predObj) {
        statusOverlay.classList.remove("show");
        statusOverlay.style.display = "none";
        pwInputWrap.classList.remove("show");
        stageScanner.classList.remove("active");
        stopScannerCanvas();
        if (dregEyeRing) dregEyeRing.style.opacity = ".05";

        predBadge.textContent = predObj.signal;
        predBadge.className = "pred-badge " + predObj.signal.toLowerCase();
        predNumVal.textContent = predObj.number;
        accVal.textContent = predObj.acc + "%";
        patternVal.textContent = predObj.streakText;
        predPeriodBox.textContent = "PERIOD: " + (lockedPeriod || "SYNCING...");

        if (tagColor) {
            tagColor.textContent = predObj.colorInfo.name;
            tagColor.className = "tag-pill tag-color " + predObj.colorInfo.cls;
        }
        if (tagRisk) {
            tagRisk.textContent = predObj.riskText;
        }

        predDisplay.classList.add("active", "reveal");
        playLockSound();
    }

    function startPeriodCountdown() {
        stopPeriodCountdown();
        periodCountdownTimer = setInterval(function() {
            const now = Date.now();
            const remainMs = Math.max(0, periodEndTime - now);
            const remainSec = Math.ceil(remainMs / 1000);
            const pct = (remainMs / PERIOD_DURATION_MS) * 100;

            if (predTimerFill) predTimerFill.style.width = pct + "%";
            if (predTimerText) predTimerText.textContent = remainSec + "s";

            if (remainMs <= 0) {
                stopPeriodCountdown();
                onPeriodEnd();
            }
        }, 150);
    }

    function stopPeriodCountdown() {
        if (periodCountdownTimer) {
            clearInterval(periodCountdownTimer);
            periodCountdownTimer = null;
        }
    }

    function startAutoLoop() {
        autoLoopActive = true;
    }

    function stopAutoLoop() {
        autoLoopActive = false;
        stopPeriodCountdown();
    }

    function onPeriodEnd() {
        if (!loggedIn) return;
        wingoHackDone = false;
        curState = "wingo";
        updateUI();
        runScanSequence();
    }

    /* ═══════════════════════════════════════════════════════
       SCANNER & BYPASS SEQUENCE
       ═══════════════════════════════════════════════════════ */
    let scanRAF = null;
    let scanProgress = 0;
    let scanCanvas, scanCtx;

    function resizeScannerCanvas() {
        if (!scanCanvas) return;
        scanCanvas.width = scanCanvas.offsetWidth || 280;
        scanCanvas.height = scanCanvas.offsetHeight || 160;
    }

    function renderScanner() {
        if (!scanCtx) return;
        const w = scanCanvas.width;
        const h = scanCanvas.height;
        scanCtx.clearRect(0, 0, w, h);

        // 3D wireframe cube
        scanCtx.save();
        scanCtx.translate(w / 2, h / 2);
        const t = Date.now() * 0.003;
        scanCtx.strokeStyle = "rgba(0, 240, 255, 0.6)";
        scanCtx.lineWidth = 1.5;
        scanCtx.shadowBlur = 8;
        scanCtx.shadowColor = "#00f0ff";

        const size = 32;
        const cos = Math.cos(t), sin = Math.sin(t);
        const cosY = Math.cos(t * 0.7), sinY = Math.sin(t * 0.7);

        const verts = [
            [-size, -size, -size], [size, -size, -size],
            [size, size, -size], [-size, size, -size],
            [-size, -size, size], [size, -size, size],
            [size, size, size], [-size, size, size]
        ];

        const proj = verts.map(([x, y, z]) => {
            let x1 = x * cos - z * sin;
            let z1 = z * cos + x * sin;
            let y2 = y * cosY - z1 * sinY;
            let z2 = z1 * cosY + y * sinY;
            const f = 200 / (200 + z2);
            return [x1 * f, y2 * f];
        });

        const edges = [
            [0,1],[1,2],[2,3],[3,0],
            [4,5],[5,6],[6,7],[7,4],
            [0,4],[1,5],[2,6],[3,7]
        ];

        scanCtx.beginPath();
        edges.forEach(([i, j]) => {
            scanCtx.moveTo(proj[i][0], proj[i][1]);
            scanCtx.lineTo(proj[j][0], proj[j][1]);
        });
        scanCtx.stroke();
        scanCtx.restore();

        scanRAF = requestAnimationFrame(renderScanner);
    }

    function stopScannerCanvas() {
        if (scanRAF) {
            cancelAnimationFrame(scanRAF);
            scanRAF = null;
        }
    }

    async function runScanSequence() {
        if (bypassRunning) return;
        bypassRunning = true;
        curState = "wingo";
        statusText.textContent = "DECRYPTING...";
        setActionLabel("SCANNING...");

        statusOverlay.classList.remove("show");
        statusOverlay.style.display = "none";
        predDisplay.classList.remove("active", "reveal");
        stageScanner.classList.add("active");

        resizeScannerCanvas();
        renderScanner();
        playScanHum();

        const logs = [
            "CONNECTING AR-LOTTERY LIVE SOCKET...",
            "DECRYPTING 30S PSEUDO-RANDOM SEED...",
            "ANALYZING 2B-2S & QUANTUM PATTERNS...",
            "CALCULATING MOMENTUM PROBABILITY...",
            "MEHEDI VAI 115 VIP SIGNAL LOCKED!"
        ];

        let start = Date.now();
        const duration = SCAN_DURATION_MS;

        const liveData = await fetchRealPeriod();
        if (liveData && liveData.nextPeriod) {
            lockedPeriod = liveData.nextPeriod;
        } else {
            lockedPeriod = getFallbackPeriod(new Date());
        }

        const scanTimer = setInterval(() => {
            const elapsed = Date.now() - start;
            const pct = Math.min(100, Math.floor((elapsed / duration) * 100));
            scanPctText.textContent = pct + "%";
            const logIdx = Math.min(logs.length - 1, Math.floor((pct / 100) * logs.length));
            scanLogText.innerHTML = "[kernel] <span>" + logs[logIdx] + "</span>";

            if (pct >= 100) {
                clearInterval(scanTimer);
                lockedPrediction = generateSmartPrediction();
                activePrediction = lockedPrediction;
                wingoHackDone = true;
                bypassRunning = false;

                periodEndTime = getCurrentPeriodEndMs();
                startPeriodCountdown();

                showPrediction(lockedPrediction);
                statusText.textContent = "ARMED";
                setActionLabel("NEXT");
            }
        }, 50);
    }

    /* ═══════════════════════════════════════════════════════
       DRAGGING SYSTEM FOR ORB & PANEL
       ═══════════════════════════════════════════════════════ */
    const PANEL_W = 320;
    const PANEL_H = 430;
    let orbPos = { x: 24, y: 120 };
    let panelPos = { x: 20, y: 90 };

    function setOrbPos(x, y) {
        orbPos.x = Math.max(10, Math.min(window.innerWidth - 68, x - 29));
        orbPos.y = Math.max(10, Math.min(window.innerHeight - 68, y - 29));
        orbEl.style.transform = "translate3d(" + orbPos.x + "px," + orbPos.y + "px,0)";
    }

    function setPanelPos(x, y) {
        const w = cardOuter.offsetWidth || PANEL_W;
        const h = cardOuter.offsetHeight || PANEL_H;
        panelPos.x = Math.max(8, Math.min(window.innerWidth - w - 8, x - w / 2));
        panelPos.y = Math.max(8, Math.min(window.innerHeight - h - 8, y - h / 2));
        mainPanel.style.transform = "translate3d(" + panelPos.x + "px," + panelPos.y + "px,0)";
    }

    function openPanel() {
        orbEl.classList.add("hidden");
        mainPanel.classList.add("visible");
        setPanelPos(window.innerWidth / 2, window.innerHeight / 2);
        updateUI();
        playCyberBeep(700, "sine", 0.08);
    }

    function closePanel() {
        mainPanel.classList.remove("visible");
        playCyberBeep(440, "sine", 0.08);
        setTimeout(function() {
            orbEl.classList.remove("hidden");
            setOrbPos(panelPos.x + PANEL_W / 2, panelPos.y + PANEL_H / 2);
        }, 200);
    }

    function updateUI() {
        if (bypassRunning) return;
        if (!loggedIn || curState === "login") {
            statusText.textContent = "LOCKED";
            showStatus();
            setStatusUI("MEHEDI VIP AUTH", "ACCESS LOCKED", "ENTER VIP KEY TO CONTINUE");
            pwInputWrap.classList.add("show");
            pwInputWrap.style.display = "block";
            setActionLabel("LOGIN");
            setTimeout(function() { try { pwInput.focus(); } catch(e) {} }, 300);
        } else if (curState === "home") {
            statusText.textContent = "ARMED";
            showStatus();
            pwInputWrap.classList.remove("show");
            pwInputWrap.style.display = "none";
            setStatusUI("SYSTEM READY", "VIP ACCESS OK", "CLICK EXECUTE TO SCAN");
            setActionLabel("EXECUTE");
        } else if (curState === "wingo") {
            pwInputWrap.classList.remove("show");
            pwInputWrap.style.display = "none";
            if (wingoHackDone && lockedPrediction) {
                statusText.textContent = "LOCKED";
                showPrediction(lockedPrediction);
                setActionLabel("NEXT");
            } else {
                statusText.textContent = "ARMED";
                showStatus();
                setStatusUI("TARGET ACQUIRED", "VIP ACTIVE", "PRESS EXECUTE TO SCAN");
                setActionLabel("EXECUTE");
            }
        }
    }

    /* ═══════════════════════════════════════════════════════
       HACKER INTRO ANIMATION CONTROLLER
       ═══════════════════════════════════════════════════════ */
    let matrixAnimId = null;

    function initMatrixIntro() {
        const overlay = document.getElementById("hackerIntroOverlay");
        const canvas = document.getElementById("matrixCanvas");
        const terminal = document.getElementById("introTerminal");
        const enterBtn = document.getElementById("introEnterBtn");
        if (!overlay || !canvas) return;

        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
        const ctx = canvas.getContext("2d");

        const chars = "MEHEDI115VIP01010101019876543210ABCDEF";
        const fontSize = 14;
        const cols = Math.floor(canvas.width / fontSize);
        const drops = Array(cols).fill(1);

        function drawMatrix() {
            ctx.fillStyle = "rgba(3, 3, 8, 0.08)";
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            ctx.fillStyle = "#00f0ff";
            ctx.font = fontSize + "px Share Tech Mono, monospace";

            for (let i = 0; i < drops.length; i++) {
                const text = chars.charAt(Math.floor(Math.random() * chars.length));
                ctx.fillText(text, i * fontSize, drops[i] * fontSize);
                if (drops[i] * fontSize > canvas.height && Math.random() > 0.975) {
                    drops[i] = 0;
                }
                drops[i]++;
            }
            matrixAnimId = requestAnimationFrame(drawMatrix);
        }
        drawMatrix();

        // Typing log simulation
        const lines = [
            "[!] INITIALIZING MEHEDI VAI 115 HACK KERNEL...",
            "[+] INJECTING LIVE AR-LOTTERY PROTOCOL FEED...",
            "[+] 2B-2S SHIFT & QUANTUM AI ENGINE ONLINE...",
            "[+] BYPASSING WIN-GO CIPHER SHIELD... 100%",
            "[✓] READY: ENTER VIP ACCESS KEY"
        ];

        let lineIdx = 0;
        const lineInterval = setInterval(() => {
            if (lineIdx < lines.length) {
                const p = document.createElement("div");
                p.textContent = lines[lineIdx];
                terminal.appendChild(p);
                terminal.scrollTop = terminal.scrollHeight;
                playCyberBeep(600 + lineIdx * 120, "sine", 0.04);
                lineIdx++;
            } else {
                clearInterval(lineInterval);
            }
        }, 400);

        function dismissIntro() {
            if (overlay.classList.contains("intro-dismissed")) return;
            overlay.classList.add("intro-dismissed");
            playSuccessChime();
            setTimeout(() => {
                if (matrixAnimId) cancelAnimationFrame(matrixAnimId);
                overlay.style.display = "none";
                openPanel();
            }, 800);
        }

        if (enterBtn) {
            enterBtn.addEventListener("click", dismissIntro);
        }
        overlay.addEventListener("click", (e) => {
            if (e.target === overlay || e.target === canvas) dismissIntro();
        });

        // Auto dismiss after 3.8s
        setTimeout(() => {
            dismissIntro();
        }, 3800);
    }

    function replayIntro() {
        const overlay = document.getElementById("hackerIntroOverlay");
        if (!overlay) return;
        overlay.style.display = "flex";
        overlay.classList.remove("intro-dismissed");
        initMatrixIntro();
    }

    /* ═══════════════════════════════════════════════════════
       BOOTSTRAP & EVENT LISTENERS
       ═══════════════════════════════════════════════════════ */
    window.addEventListener("DOMContentLoaded", function() {
        mainPanel = document.getElementById("dregWrap");
        cardOuter = document.getElementById("cardOuter");
        orbEl = document.getElementById("dregOrb");
        actionBtn = document.getElementById("actionBtn");
        closeBtn = document.getElementById("closeBtn");
        statusOverlay = document.getElementById("statusOverlay");
        stageScanner = document.getElementById("stageScanner");
        predDisplay = document.getElementById("predDisplay");
        dregEyeRing = document.getElementById("dregEyeRing");
        statusMain = document.getElementById("statusMain");
        statusSub = document.getElementById("statusSub");
        statusHint = document.getElementById("statusHint");
        statusText = document.getElementById("statusText");
        actionBtnLabel = actionBtn.querySelector(".btn-label");
        predBadge = document.getElementById("predBadge");
        predNumImg = document.getElementById("predNumImg");
        predNumVal = document.getElementById("predNumVal");
        predPeriodBox = document.getElementById("predPeriodBox");
        predTimerFill = document.getElementById("predTimerFill");
        predTimerText = document.getElementById("predTimerText");
        accVal = document.getElementById("accVal");
        patternVal = document.getElementById("patternVal");
        scanPctText = document.getElementById("scanPctText");
        scanPhase = document.getElementById("scanPhase");
        scanLogText = document.getElementById("scanLogText");
        scanFlash = document.getElementById("scanFlash");
        pwInputWrap = document.getElementById("pwInputWrap");
        pwInput = document.getElementById("pwInput");
        pwMsg = document.getElementById("pwMsg");
        gameFrame = document.getElementById("fullscreen-bg-frame");
        boxVid = document.getElementById("boxBgVideo");
        scanCanvas = document.getElementById("housingScanCanvas");
        if (scanCanvas) scanCtx = scanCanvas.getContext("2d");

        tagColor = document.getElementById("tagColor");
        tagRisk = document.getElementById("tagRisk");

        // Background video
        if (boxVid && WIDGET_CARD_VIDEO) {
            boxVid.src = WIDGET_CARD_VIDEO;
            boxVid.play().catch(() => {});
        }

        // Orb Dragging
        let orbDragging = false, orbMoved = false, orbStart = { x: 0, y: 0 };
        orbEl.addEventListener("pointerdown", function(e) {
            orbDragging = true;
            orbMoved = false;
            orbStart.x = e.clientX;
            orbStart.y = e.clientY;
            try { orbEl.setPointerCapture(e.pointerId); } catch(err) {}
            e.preventDefault();
        });
        orbEl.addEventListener("pointermove", function(e) {
            if (!orbDragging) return;
            const dx = e.clientX - orbStart.x;
            const dy = e.clientY - orbStart.y;
            if (Math.abs(dx) > 4 || Math.abs(dy) > 4) orbMoved = true;
            if (!orbMoved) return;
            orbPos.x += dx;
            orbPos.y += dy;
            orbStart.x = e.clientX;
            orbStart.y = e.clientY;
            setOrbPos(orbPos.x + 29, orbPos.y + 29);
        });
        function orbEnd(e) {
            if (!orbDragging) return;
            orbDragging = false;
            if (!orbMoved) openPanel();
            orbMoved = false;
            if (e) { try { orbEl.releasePointerCapture(e.pointerId); } catch(err) {} }
        }
        orbEl.addEventListener("pointerup", orbEnd);
        orbEl.addEventListener("pointercancel", orbEnd);

        // Panel Dragging
        let panelDragging = false, panelStart = { x: 0, y: 0 };
        mainPanel.addEventListener("pointerdown", function(e) {
            if (e.target.closest("button") || e.target.closest("input") || e.target.closest(".status-overlay")) return;
            panelDragging = true;
            mainPanel.classList.add("dragging");
            panelStart.x = e.clientX;
            panelStart.y = e.clientY;
            try { mainPanel.setPointerCapture(e.pointerId); } catch(err) {}
        });
        mainPanel.addEventListener("pointermove", function(e) {
            if (!panelDragging) return;
            panelPos.x += (e.clientX - panelStart.x);
            panelPos.y += (e.clientY - panelStart.y);
            panelStart.x = e.clientX;
            panelStart.y = e.clientY;
            setPanelPos(panelPos.x + (cardOuter.offsetWidth || PANEL_W) / 2, panelPos.y + (cardOuter.offsetHeight || PANEL_H) / 2);
        });
        function panelEnd(e) {
            panelDragging = false;
            mainPanel.classList.remove("dragging");
            if (e) { try { mainPanel.releasePointerCapture(e.pointerId); } catch(err) {} }
        }
        mainPanel.addEventListener("pointerup", panelEnd);
        mainPanel.addEventListener("pointercancel", panelEnd);

        closeBtn.addEventListener("click", closePanel);

        // Action button click
        actionBtn.addEventListener("click", function() {
            initAudio();
            if (!loggedIn) {
                attemptLogin();
            } else if (curState === "home" || curState === "wingo") {
                curState = "wingo";
                runScanSequence();
            }
        });

        // Enter key in input
        pwInput.addEventListener("keydown", function(e) {
            if (e.key === "Enter") {
                e.preventDefault();
                attemptLogin();
            }
        });
        pwInput.addEventListener("input", function() {
            if (pwMsg.textContent) pwMsg.textContent = "";
        });

        // Quick toolbar handlers
        const reloadBtn = document.getElementById("quickReloadBtn");
        if (reloadBtn) {
            reloadBtn.addEventListener("click", () => {
                if (gameFrame) {
                    gameFrame.src = gameFrame.src;
                    playCyberBeep(900, "triangle", 0.1);
                }
            });
        }
        const sfxBtn = document.getElementById("quickSfxBtn");
        if (sfxBtn) {
            sfxBtn.addEventListener("click", () => {
                soundEnabled = !soundEnabled;
                sfxBtn.textContent = soundEnabled ? "🔊 SFX" : "🔇 SFX";
                playCyberBeep(soundEnabled ? 1000 : 300, "sine", 0.08);
            });
        }
        const introBtn = document.getElementById("quickIntroBtn");
        if (introBtn) {
            introBtn.addEventListener("click", replayIntro);
        }

        // Boundary period timer watcher (every 30 seconds)
        let lastKnownSlot = -1;
        setInterval(function() {
            const d = new Date();
            const sec = d.getSeconds();
            const slot = Math.floor(sec / 30);
            const boundaryKey = d.getMinutes() * 2 + slot;
            if (lastKnownSlot === -1) {
                lastKnownSlot = boundaryKey;
                return;
            }
            if (boundaryKey !== lastKnownSlot) {
                lastKnownSlot = boundaryKey;
                if (autoLoopActive && loggedIn && wingoHackDone && !bypassRunning) {
                    onPeriodEnd();
                }
            }
        }, 250);

        setOrbPos(window.innerWidth - 80, 100);
        setPanelPos(window.innerWidth / 2, window.innerHeight / 2);

        // Start Hacker Matrix Intro
        initMatrixIntro();
        updateUI();
        fetchRealPeriod();
        setInterval(fetchRealPeriod, 4000);
    });

})();
