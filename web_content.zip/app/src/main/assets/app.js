const $ = id => document.getElementById(id);
$("botStatus").textContent = "OFFLINE";
$("botPhone").textContent = "Integrasi bot belum terhubung";
$("uptime").textContent = "Aplikasi aktif";
$("connectionTag").textContent = "BELUM TERHUBUNG";
$("connectionTag").className = "tag warn";
$("refresh").addEventListener("click", () => {
  $("saved").textContent = "Status diperbarui";
  setTimeout(() => $("saved").textContent = "", 2000);
});
$("settingsForm").addEventListener("submit", e => {
  e.preventDefault();
  $("saved").textContent = "Pengaturan tampilan tersimpan selama aplikasi dibuka";
  setTimeout(() => $("saved").textContent = "", 2500);
});
