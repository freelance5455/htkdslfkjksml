let games=JSON.parse(localStorage.getItem("gh_v4_demo")||"null")||[
{name:"Pixel Quest",genre:"Adventure",version:"1.0",url:"https://example.com/game",cover:""},
{name:"Space Runner",genre:"Arcade",version:"1.2",url:"https://example.com/game",cover:""},
{name:"Block Battle",genre:"Action",version:"0.9",url:"https://example.com/game",cover:""},
{name:"Street Racer",genre:"Racing",version:"2.0",url:"https://example.com/game",cover:""}];
let cat="All";const cats=["All","Action","Adventure","Arcade","Racing"];catsEl();
function catsEl(){cats.forEach(c=>{let b=document.createElement("button");b.textContent=c;b.className=c==="All"?"active":"";b.onclick=()=>{cat=c;document.querySelectorAll("#cats button").forEach(x=>x.classList.remove("active"));b.classList.add("active");render()};catsDiv.appendChild(b)})}
function render(){let q=(search.value||"").toLowerCase();let list=games.filter(g=>(cat==="All"||g.genre===cat)&&(g.name+" "+g.genre).toLowerCase().includes(q));gamesEl.innerHTML=list.map(g=>`<article class="card"><div class="cover">${g.cover?`<img src="${esc(g.cover)}" alt="">`:"🎮"}</div><span class="tag">${esc(g.genre)}</span><h3>${esc(g.name)}</h3><p>Version ${esc(g.version)}</p><a class="btn primary" href="${esc(g.url)}" target="_blank" rel="noopener">Download</a></article>`).join("")||"<p>No games found.</p>";status.textContent=GAMEHUB_CONFIG.supabaseUrl?"Online backend configured.":"Demo mode — connect Supabase to make uploads public."}
function openAdmin(){admin.classList.toggle("hidden")}
function login(){alert("Connect Supabase Auth in config.js to enable real admin login.")}
function logout(){alert("Signed out (demo).")}
function publish(){let g={name:name.value.trim(),genre:genre.value.trim()||"Arcade",version:version.value.trim()||"1.0",url:url.value.trim(),cover:cover.value.trim()};if(!g.name||!g.url)return alert("Enter game name and download URL.");games.push(g);localStorage.setItem("gh_v4_demo",JSON.stringify(games));render();alert("Added in demo mode. With Supabase connected, publish it online.");}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[c]))}
const $=id=>document.getElementById(id),gamesEl=$("games"),search=$("search"),admin=$("admin"),status=$("status"),catsDiv=$("cats"),name=$("name"),genre=$("genre"),version=$("version"),url=$("url"),cover=$("cover");render();