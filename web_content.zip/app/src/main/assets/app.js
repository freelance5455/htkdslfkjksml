const STORAGE = {
  students: "tm_students",
  events: "tm_events",
  transactions: "tm_transactions",
  attendance: "tm_attendance",
  theme: "tm_theme",
  profile: "tm_profile"
};

let students = loadData(STORAGE.students);
let events = loadData(STORAGE.events);
let transactions = loadData(STORAGE.transactions);
let attendance = loadData(STORAGE.attendance);
let profile = loadObject(STORAGE.profile);
let currentPDF = { html: "", filename: "Tuition-Manager", landscape: false };

const DAYS = [
  "Saturday",
  "Sunday",
  "Monday",
  "Tuesday",
  "Wednesday",
  "Thursday",
  "Friday"
];


/* =========================
   INITIALIZATION
========================= */

document.addEventListener("DOMContentLoaded", () => {

  const today = new Date();

  const dateText = today.toLocaleDateString("en-US", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric"
  });

  const shortDate = today.toLocaleDateString("en-US", {
    weekday: "long",
    month: "long",
    day: "numeric"
  });

  const todayDate = document.getElementById("todayDate");
  const dashboardDate = document.getElementById("dashboardDate");

  if (todayDate) todayDate.textContent = dateText;
  if (dashboardDate) dashboardDate.textContent = shortDate;

  loadTheme();
  setupTabs();
  setupModalClickOutside();
  renderAll();

});


/* =========================
   STORAGE
========================= */

function loadData(key) {

  try {

    const data = JSON.parse(
      localStorage.getItem(key) || "[]"
    );

    return Array.isArray(data) ? data : [];

  } catch {

    return [];

  }

}

function loadObject(key) {
  try {
    return JSON.parse(localStorage.getItem(key) || "{}") || {};
  } catch {
    return {};
  }
}

function saveProfileData() {
  localStorage.setItem(STORAGE.profile, JSON.stringify(profile));
}

function saveStudents() {
  localStorage.setItem(
    STORAGE.students,
    JSON.stringify(students)
  );
}

function saveEvents() {
  localStorage.setItem(
    STORAGE.events,
    JSON.stringify(events)
  );
}

function saveTransactions() {
  localStorage.setItem(
    STORAGE.transactions,
    JSON.stringify(transactions)
  );
}

function saveAttendance() {
  localStorage.setItem(
    STORAGE.attendance,
    JSON.stringify(attendance)
  );
}


/* =========================
   TABS
========================= */

function setupTabs() {

  document.querySelectorAll(".tab").forEach(tab => {

    tab.addEventListener("click", () => {

      document.querySelectorAll(".tab")
        .forEach(t => t.classList.remove("active"));

      document.querySelectorAll(".page")
        .forEach(p => p.classList.remove("active"));

      tab.classList.add("active");

      const page = document.getElementById(
        tab.dataset.page
      );

      if (page) {
        page.classList.add("active");
      }

    });

  });

}


/* =========================
   MODALS
========================= */

function openEventModal(eventId = null) {

  resetEventForm();

  const title = document.getElementById("eventModalTitle");
  const hidden = document.getElementById("editEventId");

  if (eventId !== null) {

    const event = events.find(
      e => String(e.id) === String(eventId)
    );

    if (!event) return;

    title.textContent = "Edit Event";
    hidden.value = event.id;

    document.getElementById("eventType").value =
      event.type || "regular";

    document.getElementById("eventName").value =
      event.name || "";

    document.getElementById("eventDay").value =
      event.day || "Saturday";

    document.getElementById("eventStart").value =
      event.start || "";

    document.getElementById("eventEnd").value =
      event.end || "";

    document.getElementById("eventLocation").value =
      event.location || "";

    document.getElementById("eventNotes").value =
      event.notes || "";

  } else {

    title.textContent = "Add Event";

  }

  document
    .getElementById("eventModal")
    .classList.add("show");

}


function openStudentModal(studentId = null) {

  resetStudentForm();

  const title =
    document.getElementById("studentModalTitle");

  const hidden =
    document.getElementById("editStudentId");

  if (studentId !== null) {

    const student = students.find(
      s => String(s.id) === String(studentId)
    );

    if (!student) return;

    title.textContent = "Edit Student";
    hidden.value = student.id;

    document.getElementById("studentName").value =
      student.name || "";

    document.getElementById("studentClass").value =
      student.className || "";

    document.getElementById("studentSubject").value =
      student.subject || "";

    document.getElementById("studentFee").value =
      student.fee || "";

    document.getElementById("studentLocation").value =
      student.location || "";

    document.getElementById("studentStart").value =
      student.start || "";

    document.getElementById("studentEnd").value =
      student.end || "";

    document
      .querySelectorAll(".day-selector input")
      .forEach(input => {
        input.checked =
          (student.days || []).includes(input.value);
      });

  } else {

    title.textContent = "Add Student";

  }

  document
    .getElementById("studentModal")
    .classList.add("show");

}


function openFinanceModal(type) {

  document.getElementById("financeType").value = type;

  document.getElementById("financeTitle").textContent =
    type === "income"
      ? "Add Income"
      : "Add Expense";

  document.getElementById("financeDate").value =
    localDateString();

  document
    .getElementById("financeModal")
    .classList.add("show");

}


function openPaymentModal(studentId = null) {

  const select =
    document.getElementById("paymentStudent");

  select.innerHTML = students.map(student => `
    <option value="${student.id}">
      ${escapeHTML(student.name)}
    </option>
  `).join("");

  if (!students.length) {

    alert("Please add a student first.");
    return;

  }

  if (studentId !== null) {
    select.value = String(studentId);
  }

  document.getElementById("paymentMonth").value =
    currentMonthString();

  document.getElementById("paymentDate").value =
    localDateString();

  document.getElementById("paymentAmount").value = "";

  document.getElementById("paymentNote").value = "";

  document
    .getElementById("paymentModal")
    .classList.add("show");

}


function openAttendanceModal(studentId = null) {

  const select =
    document.getElementById("attendanceStudent");

  select.innerHTML = students.map(student => `
    <option value="${student.id}">
      ${escapeHTML(student.name)}
    </option>
  `).join("");

  if (!students.length) {

    alert("Please add a student first.");
    return;

  }

  if (studentId !== null) {
    select.value = String(studentId);
  }

  document.getElementById("attendanceDate").value =
    localDateString();

  document.getElementById("attendanceStatus").value =
    "present";

  document
    .getElementById("attendanceModal")
    .classList.add("show");

  renderAttendanceHistory();

}


function closeModal(id) {

  const modal = document.getElementById(id);

  if (modal) {
    modal.classList.remove("show");
  }

}


function setupModalClickOutside() {

  document.querySelectorAll(".modal").forEach(modal => {

    modal.addEventListener("click", e => {

      if (e.target === modal) {
        modal.classList.remove("show");
      }

    });

  });

}


/* =========================
   EVENTS
========================= */

function saveEvent() {

  const name =
    document.getElementById("eventName").value.trim();

  const day =
    document.getElementById("eventDay").value;

  const start =
    document.getElementById("eventStart").value;

  const end =
    document.getElementById("eventEnd").value;

  if (!name || !start || !end) {

    alert(
      "Please enter event name, start time and end time."
    );

    return;

  }

  if (
    timeToMinutes(end) <=
    timeToMinutes(start)
  ) {

    alert("End time must be after start time.");
    return;

  }

  const editId =
    document.getElementById("editEventId").value;

  if (editId) {

    const event = events.find(
      e => String(e.id) === String(editId)
    );

    if (event) {

      event.type =
        document.getElementById("eventType").value;

      event.name = name;
      event.day = day;
      event.start = start;
      event.end = end;

      event.location =
        document.getElementById("eventLocation").value;

      event.notes =
        document.getElementById("eventNotes").value;

    }

  } else {

    events.push({

      id: Date.now() + Math.random(),

      type:
        document.getElementById("eventType").value,

      name,
      day,
      start,
      end,

      location:
        document.getElementById("eventLocation").value,

      notes:
        document.getElementById("eventNotes").value

    });

  }

  saveEvents();
  closeModal("eventModal");
  renderAll();

}


function deleteEvent(id) {

  if (!confirm("Delete this event?")) {
    return;
  }

  events = events.filter(
    e => String(e.id) !== String(id)
  );

  saveEvents();
  renderAll();

}


/* =========================
   STUDENTS
========================= */

function saveStudent() {

  const name =
    document.getElementById("studentName").value.trim();

  const subject =
    document.getElementById("studentSubject").value.trim();

  const start =
    document.getElementById("studentStart").value;

  const end =
    document.getElementById("studentEnd").value;

  if (!name || !subject) {

    alert("Please enter student name and subject.");
    return;

  }

  if (!start || !end) {

    alert("Please enter start and end time.");
    return;

  }

  if (
    timeToMinutes(end) <=
    timeToMinutes(start)
  ) {

    alert("End time must be after start time.");
    return;

  }

  const days = [];

  document
    .querySelectorAll(".day-selector input:checked")
    .forEach(input => {
      days.push(input.value);
    });

  if (!days.length) {

    alert("Please select at least one tuition day.");
    return;

  }

  const editId =
    document.getElementById("editStudentId").value;

  if (editId) {

    const student = students.find(
      s => String(s.id) === String(editId)
    );

    if (!student) return;

    student.name = name;

    student.className =
      document.getElementById("studentClass").value;

    student.subject = subject;

    student.fee =
      Number(
        document.getElementById("studentFee").value || 0
      );

    student.location =
      document.getElementById("studentLocation").value;

    student.days = days;
    student.start = start;
    student.end = end;

    events = events.filter(
      e => String(e.studentId) !== String(student.id)
    );

    createStudentEvents(student);

    saveStudents();

  } else {

    const student = {

      id: Date.now() + Math.random(),

      name,

      className:
        document.getElementById("studentClass").value,

      subject,

      fee:
        Number(
          document.getElementById("studentFee").value || 0
        ),

      location:
        document.getElementById("studentLocation").value,

      days,
      start,
      end,

      createdAt: localDateString()

    };

    students.push(student);

    saveStudents();

    createStudentEvents(student);

  }

  resetStudentForm();
  closeModal("studentModal");
  renderAll();

}


function createStudentEvents(student) {

  student.days.forEach((day, index) => {

    events.push({

      id:
        Date.now() +
        Math.random() +
        index,

      type: "tuition",

      name:
        `${student.name} — ${student.subject}`,

      day,

      start: student.start,
      end: student.end,

      location:
        student.location || "",

      studentId: student.id

    });

  });

  saveEvents();

}


function deleteStudent(id) {

  const student =
    students.find(
      s => String(s.id) === String(id)
    );

  if (!student) return;

  const confirmed = confirm(
    `Delete ${student.name}?\n\nThis will also remove their recurring tuition schedule.`
  );

  if (!confirmed) return;

  students = students.filter(
    s => String(s.id) !== String(id)
  );

  events = events.filter(
    e => String(e.studentId) !== String(id)
  );

  saveStudents();
  saveEvents();

  renderAll();

}


/* =========================
   STUDENT PAYMENT
========================= */

function savePayment() {

  const studentId =
    document.getElementById("paymentStudent").value;

  const month =
    document.getElementById("paymentMonth").value;

  const amount =
    Number(
      document.getElementById("paymentAmount").value
    );

  const date =
    document.getElementById("paymentDate").value;

  const note =
    document.getElementById("paymentNote").value.trim();

  if (!studentId || !month || !amount || amount <= 0) {

    alert("Please enter student, month and valid amount.");
    return;

  }

  const student =
    students.find(
      s => String(s.id) === String(studentId)
    );

  if (!student) return;

  transactions.push({

    id: Date.now() + Math.random(),

    type: "income",

    amount,

    category:
      `Tuition - ${student.name}`,

    description:
      note || `Tuition payment for ${month}`,

    date:
      date || localDateString(),

    studentId: student.id,

    month,

    tuitionPayment: true

  });

  saveTransactions();

  closeModal("paymentModal");

  renderAll();

}


/* =========================
   DUE CALCULATION
========================= */

function getStudentPaid(studentId, month) {

  return transactions
    .filter(t =>
      t.type === "income" &&
      String(t.studentId) === String(studentId) &&
      t.month === month
    )
    .reduce(
      (sum, t) =>
        sum + Number(t.amount || 0),
      0
    );

}


function getStudentDue(student) {

  const month =
    currentMonthString();

  const paid =
    getStudentPaid(student.id, month);

  return Math.max(
    0,
    Number(student.fee || 0) - paid
  );

}


function getTotalDue() {

  return students.reduce(
    (sum, student) =>
      sum + getStudentDue(student),
    0
  );

}


/* =========================
   ATTENDANCE
========================= */

function saveAttendance() {

  const studentId =
    document.getElementById("attendanceStudent").value;

  const date =
    document.getElementById("attendanceDate").value;

  const status =
    document.getElementById("attendanceStatus").value;

  if (!studentId || !date || !status) {

    alert("Please complete all attendance fields.");
    return;

  }

  const existing =
    attendance.find(
      a =>
        String(a.studentId) === String(studentId) &&
        a.date === date
    );

  if (existing) {

    existing.status = status;

  } else {

    attendance.push({

      id: Date.now() + Math.random(),

      studentId,
      date,
      status

    });

  }

  saveAttendance();
  renderAttendanceHistory();
  renderStudents();

}


function deleteAttendance(id) {

  if (!confirm("Delete this attendance record?")) {
    return;
  }

  attendance = attendance.filter(
    a => String(a.id) !== String(id)
  );

  saveAttendance();
  renderAttendanceHistory();
  renderStudents();

}


function renderAttendanceHistory() {

  const container =
    document.getElementById("attendanceHistory");

  if (!container) return;

  const studentId =
    document.getElementById("attendanceStudent").value;

  if (!studentId) {

    container.innerHTML = "";
    return;

  }

  const records =
    attendance
      .filter(
        a =>
          String(a.studentId) ===
          String(studentId)
      )
      .sort(
        (a, b) =>
          b.date.localeCompare(a.date)
      )
      .slice(0, 10);

  if (!records.length) {

    container.innerHTML =
      `<p class="empty-text">No attendance records yet.</p>`;

    return;

  }

  container.innerHTML = `

    <h3>Recent Attendance</h3>

    ${records.map(record => {

      const student =
        students.find(
          s =>
            String(s.id) ===
            String(record.studentId)
        );

      return `

        <div class="attendance-row">

          <div>
            <strong>
              ${escapeHTML(
                student?.name || "Student"
              )}
            </strong>

            <small>
              ${escapeHTML(record.date)}
            </small>
          </div>

          <span class="status ${record.status}">
            ${capitalize(record.status)}
          </span>

          <button
            class="icon-btn danger-icon"
            onclick="deleteAttendance('${record.id}')">
            ×
          </button>

        </div>

      `;

    }).join("")}

  `;

}


document.addEventListener("change", e => {

  if (
    e.target &&
    e.target.id === "attendanceStudent"
  ) {

    renderAttendanceHistory();

  }

});


/* =========================
   FINANCE
========================= */

function saveFinance() {

  const amount =
    Number(
      document.getElementById("financeAmount").value
    );

  if (!amount || amount <= 0) {

    alert("Please enter a valid amount.");
    return;

  }

  transactions.push({

    id: Date.now() + Math.random(),

    type:
      document.getElementById("financeType").value,

    amount,

    category:
      document.getElementById("financeCategory").value,

    description:
      document.getElementById("financeDescription").value,

    date:
      document.getElementById("financeDate").value ||
      localDateString()

  });

  saveTransactions();

  closeModal("financeModal");

  document.getElementById("financeAmount").value = "";
  document.getElementById("financeCategory").value = "";
  document.getElementById("financeDescription").value = "";

  renderAll();

}


function deleteTransaction(id) {

  if (!confirm("Delete this transaction?")) {
    return;
  }

  transactions = transactions.filter(
    t => String(t.id) !== String(id)
  );

  saveTransactions();
  renderAll();

}


/* =========================
   RENDER ALL
========================= */

function renderAll() {

  renderToday();
  renderStudents();
  renderFinance();
  renderWeeklySchedule();
  renderReports();
  renderProfile();
  renderDashboardStats();

}


/* =========================
   DASHBOARD
========================= */

function renderDashboardStats() {

  const today =
    localDateString();

  const todayTransactions =
    transactions.filter(
      t => t.date === today
    );

  const todayIncome =
    todayTransactions
      .filter(t => t.type === "income")
      .reduce(
        (sum, t) =>
          sum + Number(t.amount || 0),
        0
      );

  const todayExpense =
    todayTransactions
      .filter(t => t.type === "expense")
      .reduce(
        (sum, t) =>
          sum + Number(t.amount || 0),
        0
      );

  setText(
    "todayIncome",
    `৳${todayIncome.toLocaleString()}`
  );

  setText(
    "todayExpense",
    `৳${todayExpense.toLocaleString()}`
  );

  setText(
    "totalDue",
    `৳${getTotalDue().toLocaleString()}`
  );

  setText(
    "studentCount",
    students.length
  );

  const weeklyHours =
    events.reduce(
      (sum, event) =>
        sum +
        Math.max(
          0,
          duration(
            event.start,
            event.end
          )
        ),
      0
    );

  setText(
    "weeklyHours",
    `${weeklyHours.toFixed(1)}h`
  );

}


/* =========================
   TODAY
========================= */

function renderToday() {

  const day =
    new Date().toLocaleDateString(
      "en-US",
      { weekday: "long" }
    );

  const todayEvents =
    events
      .filter(
        event =>
          event.day === day
      )
      .sort(
        (a, b) =>
          timeToMinutes(a.start) -
          timeToMinutes(b.start)
      );

  const container =
    document.getElementById("todayEvents");

  if (!container) return;

  container.innerHTML = "";

  const tuitionHours =
    todayEvents
      .filter(e => e.type === "tuition")
      .reduce(
        (total, e) =>
          total +
          duration(
            e.start,
            e.end
          ),
        0
      );

  setText(
    "todayTuitionHours",
    `${tuitionHours.toFixed(1)}h`
  );

  const nowMinutes =
    new Date().getHours() * 60 +
    new Date().getMinutes();

  const next =
    todayEvents.find(
      e =>
        timeToMinutes(e.end) >=
        nowMinutes
    );

  const nextContainer =
    document.getElementById("nextEvent");

  if (nextContainer) {

    nextContainer.innerHTML =
      next
        ? `
          <div class="next-event">
            ⏰ Next: <strong>
              ${escapeHTML(next.name)}
            </strong>
            at ${formatTime(next.start)}
          </div>
        `
        : `<div class="next-event">No more events today.</div>`;

  }

  if (!todayEvents.length) {

    container.innerHTML =
      `
      <div class="event-card empty-card">
        <p>No events scheduled today.</p>
      </div>
      `;

    return;

  }

  todayEvents.forEach(event => {

    const div =
      document.createElement("div");

    div.className = "event-card";

    div.innerHTML = `

      <div>

        <h3>
          ${escapeHTML(event.name)}
        </h3>

        <p>
          ${escapeHTML(
            event.location ||
            "No location"
          )}
        </p>

      </div>

      <div class="event-actions">

        <div class="event-time">
          ${formatTime(event.start)}
          –
          ${formatTime(event.end)}
        </div>

        <button
          class="icon-btn"
          onclick="openEventModal('${event.id}')">
          ✏️
        </button>

        <button
          class="icon-btn danger-icon"
          onclick="deleteEvent('${event.id}')">
          🗑️
        </button>

      </div>

    `;

    container.appendChild(div);

  });

}


/* =========================
   STUDENTS
========================= */

function renderStudents() {

  const container =
    document.getElementById("studentList");

  if (!container) return;

  const search =
    (
      document.getElementById("studentSearch")
        ?.value || ""
    )
      .trim()
      .toLowerCase();

  const filtered =
    students.filter(student =>
      [
        student.name,
        student.className,
        student.subject,
        student.location
      ]
        .join(" ")
        .toLowerCase()
        .includes(search)
    );

  container.innerHTML = "";

  if (!filtered.length) {

    container.innerHTML =
      `
      <div class="student-card">
        <p>
          ${
            students.length
              ? "No matching student found."
              : "No students added yet."
          }
        </p>
      </div>
      `;

    return;

  }

  const month =
    currentMonthString();

  filtered.forEach(student => {

    const paid =
      getStudentPaid(
        student.id,
        month
      );

    const due =
      Math.max(
        0,
        Number(student.fee || 0) -
        paid
      );

    const attendanceCount =
      attendance.filter(
        a =>
          String(a.studentId) ===
          String(student.id) &&
          a.status === "present"
      ).length;

    const div =
      document.createElement("div");

    div.className =
      "student-card";

    div.innerHTML = `

      <div class="student-card-top">

        <div>

          <h3>
            👤 ${escapeHTML(student.name)}
          </h3>

          <p>
            ${escapeHTML(
              student.className ||
              "Class not specified"
            )}
            •
            ${escapeHTML(student.subject)}
          </p>

        </div>

        <div class="card-actions">

          <button
            class="icon-btn"
            onclick="openStudentModal('${student.id}')">
            ✏️
          </button>

          <button
            class="icon-btn danger-icon"
            onclick="deleteStudent('${student.id}')">
            🗑️
          </button>

        </div>

      </div>

      <p>
        🕐
        ${formatTime(student.start)}
        –
        ${formatTime(student.end)}
      </p>

      <p>
        📍
        ${escapeHTML(
          student.location ||
          "Not specified"
        )}
      </p>

      <p>
        Monthly Fee:
        <strong>
          ৳${Number(
            student.fee || 0
          ).toLocaleString()}
        </strong>
      </p>

      <div class="payment-summary">

        <div>
          <small>Paid</small>
          <strong class="paid-text">
            ৳${paid.toLocaleString()}
          </strong>
        </div>

        <div>
          <small>Due</small>
          <strong class="${
            due > 0
              ? "due-text"
              : "paid-text"
          }">
            ৳${due.toLocaleString()}
          </strong>
        </div>

      </div>

      <div class="student-days">

        ${(student.days || [])
          .map(day =>
            `<span>${day.slice(0, 3)}</span>`
          )
          .join("")}

      </div>

      <div class="student-footer">

        <span>
          ✓ ${attendanceCount} present
        </span>

        <div class="button-group">

          <button
            class="small-btn"
            onclick="openAttendanceModal('${student.id}')">
            Attendance
          </button>

          <button
            class="small-btn payment-btn"
            onclick="openPaymentModal('${student.id}')">
            + Payment
          </button>

        </div>

      </div>

    `;

    container.appendChild(div);

  });

}


/* =========================
   FINANCE RENDER
========================= */

function renderFinance() {

  let income = 0;
  let expense = 0;

  transactions.forEach(t => {

    if (t.type === "income") {

      income +=
        Number(t.amount) || 0;

    } else {

      expense +=
        Number(t.amount) || 0;

    }

  });

  setText(
    "totalIncome",
    `৳${income.toLocaleString()}`
  );

  setText(
    "totalExpense",
    `৳${expense.toLocaleString()}`
  );

  setText(
    "netBalance",
    `৳${(
      income - expense
    ).toLocaleString()}`
  );

  const list =
    document.getElementById("transactionList");

  if (!list) return;

  list.innerHTML = "";

  if (!transactions.length) {

    list.innerHTML =
      `
      <div class="event-card">
        <p>No transactions yet.</p>
      </div>
      `;

    return;

  }

  [...transactions]
    .sort(
      (a, b) =>
        (b.date || "").localeCompare(
          a.date || ""
        )
    )
    .forEach(t => {

      const div =
        document.createElement("div");

      div.className =
        "event-card";

      const isIncome =
        t.type === "income";

      const sign =
        isIncome ? "+" : "-";

      div.innerHTML = `

        <div>

          <h3>
            ${escapeHTML(
              t.category ||
              "Transaction"
            )}
          </h3>

          <p>
            ${escapeHTML(
              t.description || ""
            )}
            ${
              t.date
                ? ` • ${escapeHTML(t.date)}`
                : ""
            }
          </p>

        </div>

        <div class="event-actions">

          <strong class="${
            isIncome
              ? "income-text"
              : "expense-text"
          }">

            ${sign}
            ৳${Number(
              t.amount || 0
            ).toLocaleString()}

          </strong>

          <button
            class="icon-btn danger-icon"
            onclick="deleteTransaction('${t.id}')">
            🗑️
          </button>

        </div>

      `;

      list.appendChild(div);

    });

}


/* =========================
   WEEKLY SCHEDULE
========================= */

function renderWeeklySchedule() {

  const grid =
    document.getElementById("weeklyGrid");

  if (!grid) return;

  grid.innerHTML = "";

  DAYS.forEach(day => {

    const column =
      document.createElement("div");

    column.className =
      "day-column";

    column.innerHTML =
      `
      <div class="day-name">
        ${day.slice(0, 3)}
      </div>
      `;

    for (
      let hour = 6;
      hour <= 23;
      hour++
    ) {

      const cell =
        document.createElement("div");

      cell.className =
        "hour-cell";

      column.appendChild(cell);

    }

    events
      .filter(
        e => e.day === day
      )
      .forEach(event => {

        const start =
          timeToMinutes(event.start);

        const end =
          timeToMinutes(event.end);

        const top =
          55 +
          (
            (start - 360) /
            60
          ) * 55;

        const height =
          (
            (end - start) /
            60
          ) * 55;

        const eventBox =
          document.createElement("div");

        eventBox.className =
          "schedule-event";

        eventBox.style.top =
          `${Math.max(55, top)}px`;

        eventBox.style.height =
          `${Math.max(height, 30)}px`;

        eventBox.innerHTML = `
          <strong>
            ${escapeHTML(event.name)}
          </strong>

          <small>
            ${formatTime(event.start)}
            -
            ${formatTime(event.end)}
          </small>
        `;

        eventBox.onclick = () =>
          openEventModal(event.id);

        column.appendChild(eventBox);

      });

    grid.appendChild(column);

  });

}


/* =========================
   REPORTS
========================= */

function renderReports() {

  const tuitionHours =
    events
      .filter(e => e.type === "tuition")
      .reduce(
        (total, e) =>
          total +
          duration(
            e.start,
            e.end
          ),
        0
      );

  const income =
    transactions
      .filter(
        t => t.type === "income"
      )
      .reduce(
        (sum, t) =>
          sum +
          Number(t.amount || 0),
        0
      );

  const expense =
    transactions
      .filter(
        t => t.type === "expense"
      )
      .reduce(
        (sum, t) =>
          sum +
          Number(t.amount || 0),
        0
      );

  setText(
    "reportTuitionHours",
    `${tuitionHours.toFixed(1)}h`
  );

  setText(
    "reportIncome",
    `৳${income.toLocaleString()}`
  );

  setText(
    "reportExpense",
    `৳${expense.toLocaleString()}`
  );

  setText(
    "reportDue",
    `৳${getTotalDue().toLocaleString()}`
  );

  const progress =
    document.getElementById(
      "tuitionProgress"
    );

  if (progress) {

    progress.style.width =
      `${Math.min(
        tuitionHours * 5,
        100
      )}%`;

  }

}


/* =========================
   PDF REPORTS & PREVIEW
========================= */

function buildReportHTML(title, reportEvents, reportTransactions, tuitionHours, income, expense, due) {
  const p = profile || {};
  const profileLine = [p.name, p.university].filter(Boolean).map(escapeHTML).join(" • ");
  return `<!DOCTYPE html><html><head><meta charset="UTF-8"><title>${escapeHTML(title)}</title>
<style>
@page{size:A4 portrait;margin:12mm}body{font-family:Arial,sans-serif;padding:24px;color:#222;line-height:1.45}h1{color:#315efb;margin-bottom:4px}h2{margin-top:4px}.meta{color:#666;font-size:12px}.summary{padding:16px;background:#f4f6fa;border-radius:10px;margin-top:18px}.cards{display:grid;grid-template-columns:repeat(4,1fr);gap:8px}.card{border:1px solid #ddd;padding:10px;border-radius:8px}.card b{display:block;font-size:16px;margin-top:5px}table{width:100%;border-collapse:collapse;margin-top:18px}th,td{border:1px solid #ddd;padding:7px;text-align:left;font-size:11px}th{background:#eef1f7}.income{color:#159570}.expense{color:#e5484d}.footer{margin-top:20px;color:#777;font-size:10px}</style></head><body>
<h1>Tuition Manager</h1><h2>${escapeHTML(title)}</h2><p class="meta">${profileLine || "Personal Tuition Management"}<br>Generated: ${escapeHTML(new Date().toLocaleString())}</p>
<div class="summary"><div class="cards"><div class="card">Tuition Hours<b>${tuitionHours.toFixed(1)}h</b></div><div class="card income">Income<b>৳${income.toLocaleString()}</b></div><div class="card expense">Expense<b>৳${expense.toLocaleString()}</b></div><div class="card">Due<b>৳${due.toLocaleString()}</b></div></div></div>
<h3>Schedule</h3><table><tr><th>Day</th><th>Event</th><th>Time</th><th>Type</th></tr>${reportEvents.map(e=>`<tr><td>${escapeHTML(e.day||"")}</td><td>${escapeHTML(e.name||"")}</td><td>${formatTime(e.start)} - ${formatTime(e.end)}</td><td>${escapeHTML(e.type||"")}</td></tr>`).join("") || '<tr><td colspan="4">No events found.</td></tr>'}</table>
<h3>Transactions</h3><table><tr><th>Date</th><th>Category</th><th>Description</th><th>Type</th><th>Amount</th></tr>${reportTransactions.map(t=>`<tr><td>${escapeHTML(t.date||"")}</td><td>${escapeHTML(t.category||"")}</td><td>${escapeHTML(t.description||"")}</td><td>${escapeHTML(t.type||"")}</td><td>৳${Number(t.amount||0).toLocaleString()}</td></tr>`).join("") || '<tr><td colspan="5">No transactions found.</td></tr>'}</table>
<div class="footer">Generated by Tuition Manager</div></body></html>`;
}

function buildFinanceReportHTML(title, list) {
  const income = list.filter(t=>t.type==='income').reduce((s,t)=>s+Number(t.amount||0),0);
  const expense = list.filter(t=>t.type==='expense').reduce((s,t)=>s+Number(t.amount||0),0);
  return `<!DOCTYPE html><html><head><meta charset="UTF-8"><title>${escapeHTML(title)}</title><style>@page{size:A4 portrait;margin:12mm}body{font-family:Arial;padding:25px;color:#222}h1{color:#315efb}table{width:100%;border-collapse:collapse;margin-top:20px}th,td{border:1px solid #ddd;padding:8px;font-size:12px;text-align:left}th{background:#eef1f7}.income{color:#159570}.expense{color:#e5484d}.summary{padding:14px;background:#f4f6fa;border-radius:10px;margin-top:15px}</style></head><body><h1>Tuition Manager</h1><h2>${escapeHTML(title)}</h2><p>${escapeHTML(new Date().toLocaleString())}</p><div class="summary"><b>Total Income:</b> ৳${income.toLocaleString()} &nbsp;&nbsp; <b>Total Expense:</b> ৳${expense.toLocaleString()} &nbsp;&nbsp; <b>Net:</b> ৳${(income-expense).toLocaleString()}</div><table><tr><th>Date</th><th>Category</th><th>Description</th><th>Type</th><th>Amount</th></tr>${list.map(t=>`<tr><td>${escapeHTML(t.date||"")}</td><td>${escapeHTML(t.category||"")}</td><td>${escapeHTML(t.description||"")}</td><td class="${t.type==='income'?'income':'expense'}">${escapeHTML(t.type||"")}</td><td>৳${Number(t.amount||0).toLocaleString()}</td></tr>`).join("") || '<tr><td colspan="5">No transactions found.</td></tr>'}</table></body></html>`;
}

function openPdfPreview(html, filename, landscape=false) {
  currentPDF = {html, filename, landscape};
  document.getElementById('pdfPreviewTitle').textContent = filename.replaceAll('-', ' ');
  const frame = document.getElementById('pdfPreviewFrame');
  frame.srcdoc = html;
  document.getElementById('pdfPreviewModal').classList.add('show');
}

function printCurrentPDF() {
  openGeneratedPDF(currentPDF.html, currentPDF.filename, currentPDF.landscape);
}

function openGeneratedPDF(html, filename, landscape=false) {
  if (window.Android && typeof Android.printPdf === 'function') {
    Android.printPdf(html, filename, landscape);
    return;
  }
  const reportWindow = window.open('', '_blank');
  if (!reportWindow) { alert('Please allow pop-ups for this app.'); return; }
  reportWindow.document.write(html); reportWindow.document.close();
  setTimeout(()=>reportWindow.print(),500);
}

function generateReport(type) {
  const title = type==='daily' ? 'Daily Report' : type==='weekly' ? 'Weekly Report' : 'Monthly Report';
  const today = new Date();
  const todayDay = today.toLocaleDateString('en-US',{weekday:'long'});
  let reportEvents = type==='daily' ? events.filter(e=>e.day===todayDay) : [...events];
  let reportTransactions = [...transactions];
  if(type==='daily') reportTransactions=transactions.filter(t=>t.date===localDateString());
  else if(type==='weekly') reportTransactions=transactions.filter(t=>isDateInCurrentWeek(t.date));
  else reportTransactions=transactions.filter(t=>String(t.date||'').startsWith(currentMonthString()));
  const tuitionHours=reportEvents.filter(e=>e.type==='tuition').reduce((sum,e)=>sum+duration(e.start,e.end),0);
  const income=reportTransactions.filter(t=>t.type==='income').reduce((sum,t)=>sum+Number(t.amount||0),0);
  const expense=reportTransactions.filter(t=>t.type==='expense').reduce((sum,t)=>sum+Number(t.amount||0),0);
  const html=buildReportHTML(title,reportEvents,reportTransactions,tuitionHours,income,expense,getTotalDue());
  openPdfPreview(html,'Tuition-Manager-'+type,false);
}

function generateFinanceReport(kind) {
  let list = [...transactions];
  let title = 'Financial Transaction Report';
  if(kind==='income'){ list=list.filter(t=>t.type==='income'); title='Income Transaction Report'; }
  if(kind==='expense'){ list=list.filter(t=>t.type==='expense'); title='Expense Transaction Report'; }
  openPdfPreview(buildFinanceReportHTML(title,list),'Tuition-Manager-'+kind+'-transactions',false);
}

function generateRoutinePDF() {
  const days=['Saturday','Sunday','Monday','Tuesday','Wednesday','Thursday','Friday'];
  const sorted=[...events].sort((a,b)=>{const d=days.indexOf(a.day)-days.indexOf(b.day);return d!==0?d:String(a.start||'').localeCompare(String(b.start||''));});
  const colors={tuition:'#dbeafe',regular:'#dcfce7',sidework:'#fef3c7',personal:'#fce7f3'};
  const rows=sorted.map(e=>`<tr style="background:${colors[e.type]||'#f3f4f6'}"><td><b>${escapeHTML(e.day||'')}</b></td><td>${escapeHTML(e.name||'')}</td><td>${formatTime(e.start)} - ${formatTime(e.end)}</td><td>${escapeHTML(e.location||'')}</td><td>${escapeHTML(e.type||'')}</td></tr>`).join('');
  const html=`<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Tuition Routine</title><style>@page{size:A4 landscape;margin:10mm}body{font-family:Arial,sans-serif;color:#222}h1{text-align:center;color:#315efb;margin:0}p{text-align:center;color:#666}.legend{display:flex;gap:12px;justify-content:center;margin:12px 0;font-size:11px}.legend span{padding:5px 9px;border-radius:6px}table{width:100%;border-collapse:collapse;margin-top:12px}th,td{border:1px solid #bfc5d1;padding:9px;text-align:left;font-size:12px}th{background:#315efb;color:white}.tuition{background:#dbeafe}.regular{background:#dcfce7}.sidework{background:#fef3c7}.personal{background:#fce7f3}</style></head><body><h1>Tuition Routine</h1><p>Weekly Schedule • A4 Landscape</p><div class="legend"><span class="tuition">Tuition</span><span class="regular">Regular Work</span><span class="sidework">Side Work</span><span class="personal">Personal</span></div><table><tr><th>Day</th><th>Student / Event</th><th>Time</th><th>Location</th><th>Type</th></tr>${rows||'<tr><td colspan="5">No routine events found.</td></tr>'}</table></body></html>`;
  openPdfPreview(html,'Tuition-Routine',true);
}

/* =========================
   PROFILE
========================= */
function openProfileModal(){
  const p=profile||{};
  document.getElementById('profileName').value=p.name||'';
  document.getElementById('profileUniversity').value=p.university||'';
  document.getElementById('profileSchool').value=p.school||'';
  document.getElementById('profileCollege').value=p.college||'';
  document.getElementById('profileAddress').value=p.address||'';
  document.getElementById('profilePhone').value=p.phone||'';
  document.getElementById('profileEmail').value=p.email||'';
  document.getElementById('profileBlood').value=p.blood||'';
  document.getElementById('profileModal').classList.add('show');
}
function saveProfile(){
  profile={name:document.getElementById('profileName').value.trim(),university:document.getElementById('profileUniversity').value.trim(),school:document.getElementById('profileSchool').value.trim(),college:document.getElementById('profileCollege').value.trim(),address:document.getElementById('profileAddress').value.trim(),phone:document.getElementById('profilePhone').value.trim(),email:document.getElementById('profileEmail').value.trim(),blood:document.getElementById('profileBlood').value.trim()};
  saveProfileData(); renderProfile(); closeModal('profileModal');
}
function renderProfile(){
  const el=document.getElementById('profileCard'); if(!el)return;
  const p=profile||{};
  const rows=[['Full Name',p.name],['University',p.university],['School',p.school],['College',p.college],['Present Address',p.address],['Phone',p.phone],['Email',p.email],['Blood Group',p.blood]];
  el.innerHTML=rows.map(([k,v])=>`<div class="profile-row"><span>${k}</span><strong>${escapeHTML(v||'Not added')}</strong></div>`).join('');
}

/* =========================
   THEME
========================= */

function loadTheme() {

  if (
    localStorage.getItem(
      STORAGE.theme
    ) === "dark"
  ) {

    document.body.classList.add("dark");

  }

  const button =
    document.getElementById("themeBtn");

  if (button) {

    button.addEventListener(
      "click",
      toggleTheme
    );

  }

}


function toggleTheme() {

  document.body.classList.toggle("dark");

  localStorage.setItem(
    STORAGE.theme,
    document.body.classList.contains("dark")
      ? "dark"
      : "light"
  );

}


/* =========================
   FORM RESET
========================= */

function resetEventForm() {

  document.getElementById("editEventId").value = "";

  document.getElementById("eventName").value = "";
  document.getElementById("eventLocation").value = "";
  document.getElementById("eventNotes").value = "";

  document.getElementById("eventStart").value = "";
  document.getElementById("eventEnd").value = "";

  document.getElementById("eventType").value = "tuition";
  document.getElementById("eventDay").value = "Saturday";

}


function resetStudentForm() {

  document.getElementById("editStudentId").value = "";

  [
    "studentName",
    "studentClass",
    "studentSubject",
    "studentFee",
    "studentLocation",
    "studentStart",
    "studentEnd"
  ].forEach(id => {

    document.getElementById(id).value = "";

  });

  document
    .querySelectorAll(".day-selector input")
    .forEach(input => {
      input.checked = false;
    });

}


/* =========================
   DATE HELPERS
========================= */

function localDateString(date = new Date()) {

  const year =
    date.getFullYear();

  const month =
    String(
      date.getMonth() + 1
    ).padStart(2, "0");

  const day =
    String(
      date.getDate()
    ).padStart(2, "0");

  return `${year}-${month}-${day}`;

}


function currentMonthString() {

  const date =
    new Date();

  return `
    ${date.getFullYear()}-
    ${String(
      date.getMonth() + 1
    ).padStart(2, "0")}
  `.replace(/\s+/g, "");

}


function isDateInCurrentWeek(dateString) {

  if (!dateString) return false;

  const date =
    new Date(
      `${dateString}T00:00:00`
    );

  const today =
    new Date();

  const day =
    today.getDay();

  const daysSinceSaturday =
    (day + 1) % 7;

  const start =
    new Date(today);

  start.setHours(0, 0, 0, 0);

  start.setDate(
    today.getDate() -
    daysSinceSaturday
  );

  const end =
    new Date(start);

  end.setDate(
    start.getDate() + 6
  );

  end.setHours(
    23, 59, 59, 999
  );

  return (
    date >= start &&
    date <= end
  );

}


/* =========================
   GENERAL HELPERS
========================= */

function timeToMinutes(time) {

  if (!time) return 0;

  const parts =
    time.split(":").map(Number);

  return (
    (parts[0] || 0) * 60 +
    (parts[1] || 0)
  );

}


function duration(start, end) {

  return Math.max(
    0,
    (
      timeToMinutes(end) -
      timeToMinutes(start)
    ) / 60
  );

}


function formatTime(time) {

  if (!time) return "";

  const parts =
    time.split(":").map(Number);

  let hour =
    parts[0] || 0;

  const minute =
    parts[1] || 0;

  const suffix =
    hour >= 12
      ? "PM"
      : "AM";

  hour =
    hour % 12 || 12;

  return `${hour}:${String(
    minute
  ).padStart(2, "0")} ${suffix}`;

}


function setText(id, value) {

  const element =
    document.getElementById(id);

  if (element) {
    element.textContent = value;
  }

}


function capitalize(value) {

  if (!value) return "";

  return (
    value.charAt(0).toUpperCase() +
    value.slice(1)
  );

}


function escapeHTML(value) {

  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");

}