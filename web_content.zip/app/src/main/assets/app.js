const PRODUCTS=["Fillet","Maini","Makongoro"];
const KEY="ims_data_v1";
const fresh=()=>({suppliers:[],customers:[],purchases:[],sales:[],payments:[],expenses:[],stockAdjustments:[],statements:[]});
let db=load(), page="dashboard";
function load(){try{return {...fresh(),...JSON.parse(localStorage.getItem(KEY)||"{}")}}catch{return fresh()}}
function save(){localStorage.setItem(KEY,JSON.stringify(db))}
function id(prefix="IMS"){return prefix+"-"+Date.now().toString(36).toUpperCase()+"-"+Math.random().toString(36).slice(2,5).toUpperCase()}
function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function money(n){return new Intl.NumberFormat("en-TZ",{style:"currency",currency:"TZS",maximumFractionDigits:0}).format(Number(n)||0).replace("TZS","TSh")}
function num(n){return Number(n)||0}
function today(){return new Date().toISOString().slice(0,10)}
function monthStart(){return today().slice(0,7)+"-01"}
function sum(a,fn){return a.reduce((s,x)=>s+fn(x),0)}
function toast(s){let t=document.getElementById("toast");t.textContent=s;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2600)}
function entityName(type,idv){return (db[type]||[]).find(x=>x.id===idv)?.name||"Unknown"}
function balance(type,entityId,upto="9999-12-31"){
 const purchases=db.purchases.filter(x=>type==="suppliers"&&x.entityId===entityId&&x.date<=upto);
 const sales=db.sales.filter(x=>type==="customers"&&x.entityId===entityId&&x.date<=upto);
 const pay=db.payments.filter(x=>x.entityType===type&&x.entityId===entityId&&x.date<=upto);
 if(type==="suppliers")return sum(purchases,x=>x.total)-sum(pay,x=>x.direction==="to_entity"?x.amount:-x.amount);
 return sum(sales,x=>x.total)-sum(pay,x=>x.direction==="from_entity"?x.amount:-x.amount);
}
function fmtDate(d){if(!d)return "—";return new Date(d+"T00:00:00").toLocaleDateString("en-GB")}
function title(s){return s.charAt(0).toUpperCase()+s.slice(1)}
document.getElementById("today").textContent=new Date().toLocaleDateString("en-GB",{day:"2-digit",month:"short",year:"numeric"});
// Navigation history: Android/browser Back returns to the previous in-app page.
// If the mobile menu is open, Back closes the menu first and keeps the current page.
let menuHistoryEntry=false;
const sidebar=document.querySelector(".sidebar");
try { history.replaceState({imsPage:page}, "", location.href); } catch (_) {}
function setActiveNav(){document.querySelectorAll(".nav-item").forEach(x=>x.classList.toggle("active",x.dataset.page===page));}
function navigateTo(nextPage){
  if(!nextPage || nextPage===page){closeMenu();return;}
  const menuWasOpen=sidebar.classList.contains("open");
  page=nextPage;
  if(menuWasOpen){
    // Replace the temporary menu state with the destination; Back then returns
    // to the page that was open before this navigation, not to a stale menu.
    sidebar.classList.remove("open");menuHistoryEntry=false;
    try { history.replaceState({imsPage:page}, "", location.href); } catch (_) {}
  } else {
    try { history.pushState({imsPage:page}, "", location.href); } catch (_) {}
  }
  setActiveNav();render();
}
function openMenu(){
  if(sidebar.classList.contains("open")) return;
  sidebar.classList.add("open");
  try { history.pushState({imsMenuOpen:true,imsPage:page}, "", location.href); menuHistoryEntry=true; } catch (_) {}
}
function closeMenu(fromPopState=false){
  const wasOpen=sidebar.classList.contains("open");
  sidebar.classList.remove("open");
  if(!fromPopState && wasOpen && menuHistoryEntry){
    menuHistoryEntry=false;
    history.back();
  } else if(fromPopState){ menuHistoryEntry=false; }
}
document.getElementById("nav").addEventListener("click",e=>{let b=e.target.closest("[data-page]");if(!b)return;navigateTo(b.dataset.page)});
document.getElementById("mobileMenu").onclick=()=>sidebar.classList.contains("open")?closeMenu():openMenu();
window.addEventListener("popstate",e=>{
  if(sidebar.classList.contains("open")) { closeMenu(true); return; }
  const previousPage=e.state&&e.state.imsPage;
  if(previousPage && previousPage!==page){page=previousPage;setActiveNav();render();}
});
document.getElementById("exportBtn").onclick=()=>{downloadBlob(JSON.stringify({exportedAt:new Date().toISOString(),...db},null,2),"isack-meat-backup-"+today()+".json","application/json");toast("Backup downloaded")};
function downloadBlob(content,name,type){let a=document.createElement("a");a.href=URL.createObjectURL(new Blob([content],{type}));a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)}
function render(){document.getElementById("pageTitle").textContent=({dashboard:"Dashboard",suppliers:"Suppliers / Butchers",customers:"Company Customers",purchases:"Purchases",sales:"Sales",payments:"Payments",inventory:"Inventory",statements:"Statements & Tickets",reports:"Profit & Reports"})[page];let c=document.getElementById("content");c.innerHTML=({dashboard:dashboardPage,suppliers:()=>entityPage("suppliers"),customers:()=>entityPage("customers"),purchases:()=>transactionsPage("purchases"),sales:()=>transactionsPage("sales"),payments:paymentsPage,inventory:inventoryPage,statements:statementsPage,reports:reportsPage})[page]();bindPage()}
function dashboardPage(){
 const m=today().slice(0,7),p=db.purchases.filter(x=>x.date.startsWith(m)),s=db.sales.filter(x=>x.date.startsWith(m)),pa=db.payments.filter(x=>x.date.startsWith(m));
 const purchaseTotal=sum(p,x=>x.total),salesTotal=sum(s,x=>x.total),paidIn=sum(pa.filter(x=>x.entityType==="customers"&&x.direction==="from_entity"),x=>x.amount);
 const stock=stockSummary();
 return `<div class="notice"><strong>Welcome to Isack Meat Supply.</strong> Record purchases from butcher suppliers, sales to company customers, payments and monthly statements. This starter version stores records in this browser; export backups regularly.</div>
 <div class="grid stats">
 ${stat("Sales this month",money(salesTotal),"Recorded company sales")}
 ${stat("Purchases this month",money(purchaseTotal),"Recorded butcher purchases")}
 ${stat("Customer payments",money(paidIn),"Money received this month")}
 ${stat("Estimated gross difference",money(salesTotal-purchaseTotal),"Sales minus purchases recorded this month")}
 </div>
 <div class="grid two-col"><div class="card"><div class="section-head"><h2>Quick actions</h2></div><div class="quick-actions"><button class="button" data-action="add-purchases">＋ Record purchase</button><button class="button" data-action="add-sales">＋ Record sale</button><button class="button light" data-action="add-suppliers">＋ Add butcher</button><button class="button light" data-action="add-customers">＋ Add company</button><button class="button ghost" data-action="add-payments">＋ Record payment</button></div><div class="section-head"><h2>Current balances</h2></div>${balanceTable("suppliers",5)}<div style="height:12px"></div>${balanceTable("customers",5)}</div>
 <div class="card"><div class="section-head"><h2>Stock on hand (kg / pairs)</h2><span class="pill">Calculated records</span></div>${stockTable(stock)}<div class="section-head"><h2>Month-end reminder</h2></div><p style="font-size:12px;line-height:1.6;color:#6b7280">Check supplier balances, company balances, stock losses and expenses before sharing monthly statements. Gross difference is not final net profit until costs and stock changes are considered.</p><button class="button" data-goto="statements">Create statement →</button></div></div>`;
}
function stat(label,value,foot){return `<div class="card"><div class="stat-label">${label}</div><div class="stat-value">${value}</div><div class="stat-foot">${foot}</div></div>`}
function entityPage(type){let isS=type==="suppliers",arr=db[type];return `<div class="section-head"><div><h2>${isS?"Butcher suppliers":"Company customers"}</h2><div class="stat-foot" style="margin-top:5px">${arr.length} saved records</div></div><button class="button" data-action="add-${type}">＋ Add ${isS?"supplier":"company"}</button></div><div class="toolbar"><input id="entitySearch" placeholder="Search by name or phone…"></div><div id="entityTable">${entityTable(type,arr)}</div>`}
function entityTable(type,arr){if(!arr.length)return `<div class="card empty">No records yet. Use “Add ${type==="suppliers"?"supplier":"company"}” to get started.</div>`;return `<div class="table-wrap"><table><thead><tr><th>Name</th><th>Contact</th><th>Phone</th><th>Current balance</th><th>Notes</th><th>Action</th></tr></thead><tbody>${arr.map(x=>`<tr><td><strong>${esc(x.name)}</strong></td><td>${esc(x.contact||"—")}</td><td>${esc(x.phone||"—")}</td><td class="money">${money(balance(type,x.id))}</td><td>${esc(x.notes||"—")}</td><td><button class="button small light" data-edit="${type}|${x.id}">Edit</button> <button class="button small ghost" data-statement="${type}|${x.id}">Statement</button></td></tr>`).join("")}</tbody></table></div>`}
function transactionsPage(type){let isP=type==="purchases",arr=db[type].slice().sort((a,b)=>b.date.localeCompare(a.date));return `<div class="section-head"><div><h2>${isP?"Purchases from butchers":"Sales to companies"}</h2><div class="stat-foot" style="margin-top:5px">Record each product line with kilo and price per kilo.</div></div><button class="button" data-action="add-${type}">＋ Record ${isP?"purchase":"sale"}</button></div><div class="toolbar"><input id="txSearch" placeholder="Search supplier/customer or product…"><input id="txMonth" type="month" value="${today().slice(0,7)}"></div><div id="txTable">${txTable(type,arr)}</div>`}
function txTable(type,arr){let isP=type==="purchases";if(!arr.length)return `<div class="card empty">No ${isP?"purchases":"sales"} recorded yet.</div>`;return `<div class="table-wrap"><table><thead><tr><th>Date</th><th>${isP?"Supplier":"Company"}</th><th>Products</th><th>Total</th><th>Reference</th><th>Action</th></tr></thead><tbody>${arr.map(x=>`<tr><td>${fmtDate(x.date)}</td><td>${esc(entityName(isP?"suppliers":"customers",x.entityId))}</td><td>${x.items.map(i=>`${esc(i.product)} ${num(i.qty??i.kg)}${i.unit==="pair"||i.product==="Makongoro"?" pair":" kg"}`).join(", ")}</td><td class="money">${money(x.total)}</td><td>${esc(x.ref||"—")}</td><td><button class="button small light" data-edit="${type}|${x.id}">Edit</button></td></tr>`).join("")}</tbody></table></div>`}
function paymentsPage(){return `<div class="section-head"><div><h2>Payments</h2><div class="stat-foot" style="margin-top:5px">Record money paid to suppliers or received from companies.</div></div><button class="button" data-action="add-payments">＋ Record payment</button></div><div class="table-wrap"><table><thead><tr><th>Date</th><th>Account</th><th>Direction</th><th>Method</th><th>Amount</th><th>Reference / Note</th><th>Action</th></tr></thead><tbody>${db.payments.slice().sort((a,b)=>b.date.localeCompare(a.date)).map(p=>`<tr><td>${fmtDate(p.date)}</td><td>${esc(entityName(p.entityType,p.entityId))}</td><td>${p.direction==="to_entity"?"Paid to supplier":"Received from company"}</td><td>${esc(p.method||"—")}</td><td class="money">${money(p.amount)}</td><td>${esc(p.ref||"—")}</td><td><button class="button small light" data-edit="payments|${p.id}">Edit</button></td></tr>`).join("")||`<tr><td colspan="6" class="empty">No payments recorded yet.</td></tr>`}</tbody></table></div>`}
function stockSummary(){return PRODUCTS.map(product=>{const unit=product==="Makongoro"?"pair":"kg";let bought=sum(db.purchases,x=>sum(x.items.filter(i=>i.product===product),i=>i.qty??i.kg));let sold=sum(db.sales,x=>sum(x.items.filter(i=>i.product===product),i=>i.qty??i.kg));let adj=sum(db.stockAdjustments.filter(x=>x.product===product),x=>x.kg);return {product,unit,bought,sold,adj,onHand:bought-sold+adj}})}
function stockTable(stock){return `<div class="table-wrap"><table><thead><tr><th>Product</th><th>Purchased</th><th>Sold</th><th>Adjustments</th><th>On hand</th></tr></thead><tbody>${stock.map(x=>`<tr><td><strong>${x.product}</strong></td><td>${x.bought.toFixed(x.unit==="pair"?0:2)} ${x.unit}</td><td>${x.sold.toFixed(x.unit==="pair"?0:2)} ${x.unit}</td><td>${x.adj.toFixed(x.unit==="pair"?0:2)} ${x.unit}</td><td class="money ${x.onHand<0?"negative":""}">${x.onHand.toFixed(x.unit==="pair"?0:2)} ${x.unit}</td></tr>`).join("")}</tbody></table></div>`}
function inventoryPage(){return `<div class="notice">Stock is calculated from purchases minus sales plus manual adjustments. Record wastage or weight loss as a negative adjustment so the stock matches the physical amount.</div><div class="section-head"><h2>Stock on hand</h2><button class="button" data-action="add-adjustment">＋ Record stock loss / adjustment</button></div><div class="card">${stockTable(stockSummary())}</div><div class="section-head"><h2>Stock adjustments</h2></div><div class="table-wrap"><table><thead><tr><th>Date</th><th>Product</th><th>Adjustment</th><th>Reason</th><th>Action</th></tr></thead><tbody>${db.stockAdjustments.map(x=>`<tr><td>${fmtDate(x.date)}</td><td>${esc(x.product)}</td><td class="${x.kg<0?"negative":"positive"}">${x.kg>0?"+":""}${x.kg} kg</td><td>${esc(x.reason)}</td><td><button class="button small light" data-edit="adjustment|${x.id}">Edit</button></td></tr>`).join("")||`<tr><td colspan="5" class="empty">No adjustments recorded.</td></tr>`}</tbody></table></div>`}
function statementsPage(){return `<div class="notice"><strong>Month-end process:</strong> Choose a month and an account, review its statement, then share or download the ticket. Always verify the statement before sending it.</div><div class="card"><div class="form-grid"><div class="field"><label>Statement month</label><input type="month" id="stmtMonth" value="${today().slice(0,7)}"></div><div class="field"><label>Account type</label><select id="stmtType"><option value="customers">Company customer</option><option value="suppliers">Butcher supplier</option></select></div><div class="field full"><label>Account</label><select id="stmtEntity"></select></div></div><button class="button" id="previewStatement">Generate statement preview</button><div id="statementPreview" style="margin-top:18px"></div></div>`}
function reportsPage(){let m=today().slice(0,7),p=db.purchases.filter(x=>x.date.startsWith(m)),s=db.sales.filter(x=>x.date.startsWith(m)),e=db.expenses.filter(x=>x.date.startsWith(m));let pt=sum(p,x=>x.total),st=sum(s,x=>x.total),et=sum(e,x=>x.amount);return `<div class="section-head"><div><h2>Profit & loss overview</h2><div class="stat-foot" style="margin-top:5px">Current month: ${m}</div></div><button class="button ghost" id="downloadReport">Download CSV report</button></div><div class="grid stats">${stat("Sales",money(st),"Sales recorded this month")}${stat("Purchases",money(pt),"Purchases recorded this month")}${stat("Other expenses",money(et),"Expenses recorded this month")}${stat("Simple gross difference",money(st-pt-et),"Sales − purchases − expenses")}</div><div class="notice">This simple difference is a management estimate, not a full accrual profit calculation. For accurate accounting, stock remaining, wastage, transport costs, unpaid balances and opening stock must be reconciled.</div><div class="grid two-col"><div class="card"><h2 style="font-size:15px">Product summary</h2>${stockTable(stockSummary())}</div><div class="card"><h2 style="font-size:15px">Record other business expense</h2><p style="font-size:12px;color:#6b7280">Examples: transport, packaging, storage or other operating costs.</p><button class="button" data-action="add-expense">＋ Add expense</button><div style="margin-top:15px">${db.expenses.filter(x=>x.date.startsWith(m)).map(x=>`<p style="font-size:12px">${fmtDate(x.date)} · ${esc(x.description)} <strong style="float:right">${money(x.amount)}</strong> <button class="button small light" data-edit="expense|${x.id}">Edit</button></p>`).join("")||'<div class="empty">No expenses recorded this month.</div>'}</div></div></div>`}
function balanceTable(type,limit=10){let arr=db[type].map(x=>({x,b:balance(type,x.id)})).sort((a,b)=>Math.abs(b.b)-Math.abs(a.b)).slice(0,limit);return `<div style="font-size:12px;font-weight:800;margin:12px 0 8px">${type==="suppliers"?"Supplier balances payable":"Customer balances receivable"}</div><div class="table-wrap"><table><thead><tr><th>Name</th><th>Balance</th></tr></thead><tbody>${arr.map(({x,b})=>`<tr><td>${esc(x.name)}</td><td class="money">${money(b)}</td></tr>`).join("")||`<tr><td colspan="2" class="empty">No accounts yet.</td></tr>`}</tbody></table></div>`}
function bindPage(){
 document.querySelectorAll("[data-action]").forEach(b=>b.onclick=()=>openForm(b.dataset.action.replace("add-","")));
  document.querySelectorAll("[data-edit]").forEach(b=>b.onclick=()=>{const [t,i]=b.dataset.edit.split("|");openForm(t,i)});
 document.querySelectorAll("[data-goto]").forEach(b=>b.onclick=()=>navigateTo(b.dataset.goto));
 document.querySelectorAll("[data-statement]").forEach(b=>b.onclick=()=>{let [t,i]=b.dataset.statement.split("|");navigateTo("statements");document.getElementById("stmtType").value=t;populateStatementEntities();document.getElementById("stmtEntity").value=i;document.getElementById("previewStatement").click()});
 let es=document.getElementById("entitySearch");if(es)es.oninput=()=>{let type=page;document.getElementById("entityTable").innerHTML=entityTable(type,db[type].filter(x=>(x.name+" "+x.phone+" "+x.contact).toLowerCase().includes(es.value.toLowerCase())))};
 let ts=document.getElementById("txSearch"),tm=document.getElementById("txMonth");if(ts||tm){let update=()=>{let arr=db[page].slice().sort((a,b)=>b.date.localeCompare(a.date));if(tm.value)arr=arr.filter(x=>x.date.startsWith(tm.value));if(ts?.value)arr=arr.filter(x=>(entityName(page==="purchases"?"suppliers":"customers",x.entityId)+" "+x.items.map(i=>i.product).join(" ")).toLowerCase().includes(ts.value.toLowerCase()));document.getElementById("txTable").innerHTML=txTable(page,arr)};ts?.addEventListener("input",update);tm?.addEventListener("change",update)}
 if(document.getElementById("stmtType")){document.getElementById("stmtType").onchange=populateStatementEntities;populateStatementEntities();document.getElementById("previewStatement").onclick=()=>previewStatement()}
 if(document.getElementById("downloadReport"))document.getElementById("downloadReport").onclick=downloadCsvReport;
}
function populateStatementEntities(){let t=document.getElementById("stmtType")?.value;if(!t)return;let sel=document.getElementById("stmtEntity"),old=sel.value;sel.innerHTML=(db[t]||[]).map(x=>`<option value="${x.id}">${esc(x.name)}</option>`).join("")||'<option value="">No accounts available</option>';if(old)sel.value=old}
function openForm(type){
 const labels={suppliers:"butcher supplier",customers:"company customer",purchases:"purchase",sales:"sale",payments:"payment",adjustment:"stock adjustment",expense:"business expense"};
 let body="";
 if(type==="suppliers"||type==="customers")body=`<div class="form-grid"><div class="field full"><label>Name *</label><input name="name" value="${val("name")}" required></div><div class="field"><label>Contact person</label><input name="contact" value="${val("contact")}"></div><div class="field"><label>Phone</label><input name="phone" type="tel" value="${val("phone")}"></div><div class="field full"><label>Notes</label><input name="notes" value="${val("notes")}"></div></div>`;
 if(type==="purchases"||type==="sales")body=`<div class="form-grid"><div class="field"><label>${type==="purchases"?"Butcher supplier":"Company customer"} *</label><select name="entityId" required>${(db[type==="purchases"?"suppliers":"customers"]).map(x=>`<option value="${x.id}" ${existing?.entityId===x.id?"selected":""}>${esc(x.name)}</option>`).join("")}</select></div><div class="field"><label>Date *</label><input type="date" name="date" value="${val("date")||today()}" required></div><div class="field full"><label>Reference / delivery note</label><input name="ref" value="${val("ref")}" placeholder="Optional reference"></div></div><div class="section-head"><h2>Product lines</h2><button class="button small light" type="button" id="addLine">＋ Add product</button></div><div id="lineRows"></div><div style="text-align:right;font-size:14px;font-weight:800;padding:10px 0">Total: <span id="lineTotal">TSh 0</span></div>`;
 if(type==="payments")body=`<div class="form-grid"><div class="field"><label>Account type *</label><select name="entityType"><option value="customers" ${existing?.entityType==="customers"?"selected":""}>Company customer (money received)</option><option value="suppliers" ${existing?.entityType==="suppliers"?"selected":""}>Butcher supplier (money paid)</option></select></div><div class="field"><label>Account *</label><select name="entityId" id="paymentEntity"></select></div><div class="field"><label>Date *</label><input type="date" name="date" value="${val("date")||today()}" required></div><div class="field"><label>Amount (TSh) *</label><input type="number" name="amount" value="${val("amount")}" min="1" step="1" required></div><div class="field"><label>Method</label><select name="method"><option>Cash</option><option>Bank transfer</option><option>Mobile money</option><option>Cheque</option><option>Other</option></select></div><div class="field"><label>Reference / note</label><input name="ref" value="${val("ref")}"></div></div>`;
 if(type==="adjustment")body=`<div class="form-grid"><div class="field"><label>Product *</label><select name="product">${PRODUCTS.map(x=>`<option ${existing?.product===x?"selected":""}>${x}</option>`).join("")}</select></div><div class="field"><label>Date *</label><input type="date" name="date" value="${val("date")||today()}" required></div><div class="field"><label>Kg adjustment *</label><input type="number" name="kg" value="${val("kg")}" step="0.01" required placeholder="Use negative number for loss"></div><div class="field"><label>Reason *</label><input name="reason" value="${val("reason")}" required placeholder="e.g. wastage / weight loss"></div></div>`;
 if(type==="expense")body=`<div class="form-grid"><div class="field"><label>Date *</label><input type="date" name="date" value="${val("date")||today()}" required></div><div class="field"><label>Amount (TSh) *</label><input type="number" name="amount" value="${val("amount")}" min="1" required></div><div class="field full"><label>Description *</label><input name="description" value="${val("description")}" required placeholder="e.g. transport"></div></div>`;
 if(!labels[type])return;
 document.getElementById("modalRoot").innerHTML=`<div class="modal-backdrop"><div class="modal"><div class="modal-head"><h2>${existing?"Edit "+(labels[type]||type):labels[type]}</h2><button class="button small ghost" type="button" id="closeModal">✕</button></div><form id="recordForm" class="modal-body">${body}<div class="modal-actions"><button class="button ghost" type="button" id="cancelModal">Cancel</button><button class="button" type="submit">${existing?"Save changes":"Save record"}</button></div></form></div></div>`;
 const close=()=>document.getElementById("modalRoot").innerHTML="";document.getElementById("closeModal").onclick=close;document.getElementById("cancelModal").onclick=close;document.querySelector(".modal-backdrop").onclick=e=>{if(e.target.classList.contains("modal-backdrop"))close()};
 if(type==="purchases"||type==="sales"){if(existing?.items?.length)existing.items.forEach(it=>addProductLine(it));else addProductLine();document.getElementById("addLine").onclick=()=>addProductLine();document.getElementById("lineRows").addEventListener("input",calcLineTotal);document.getElementById("lineRows").addEventListener("change",calcLineTotal)}
 if(type==="payments"){let sel=document.querySelector('[name="entityType"]');sel.onchange=()=>populatePaymentEntities();populatePaymentEntities();if(existing){document.getElementById("paymentEntity").value=existing.entityId;document.querySelector("[name=method]").value=existing.method||"Cash"}}
 document.getElementById("recordForm").onsubmit=e=>{e.preventDefault();let f=new FormData(e.target),v=Object.fromEntries(f.entries());
 if(type==="suppliers"||type==="customers"){if(!v.name.trim())return;const rec={...(existing||{}),id:existing?.id||id(type==="suppliers"?"SUP":"CUS"),name:v.name.trim(),contact:v.contact,phone:v.phone,notes:v.notes,createdAt:existing?.createdAt||new Date().toISOString(),updatedAt:new Date().toISOString()};if(existing)db[type]=db[type].map(x=>x.id===existing.id?rec:x);else db[type].push(rec)}
 if(type==="purchases"||type==="sales"){let items=[...document.querySelectorAll(".product-line")].map(r=>({product:r.querySelector("[name=product]").value,qty:num(r.querySelector("[name=kg]").value),kg:r.querySelector("[name=product]").value==="Makongoro"?0:num(r.querySelector("[name=kg]").value),pairs:r.querySelector("[name=product]").value==="Makongoro"?num(r.querySelector("[name=kg]").value):0,unit:r.querySelector("[name=product]").value==="Makongoro"?"pair":"kg",price:num(r.querySelector("[name=price]").value)})).filter(x=>x.kg>0&&x.price>=0);if(!v.entityId||!items.length){toast("Choose an account and enter at least one product line.");return}let total=sum(items,x=>(x.qty??x.kg)*x.price);const rec={...(existing||{}),id:existing?.id||id(type==="purchases"?"PUR":"SAL"),entityId:v.entityId,date:v.date,ref:v.ref,items,total,createdAt:existing?.createdAt||new Date().toISOString(),updatedAt:new Date().toISOString()};if(existing)db[type]=db[type].map(x=>x.id===existing.id?rec:x);else db[type].push(rec)}
 if(type==="payments"){if(!v.entityId||num(v.amount)<=0){toast("Enter an account and valid amount.");return}const rec={...(existing||{}),id:existing?.id||id("PAY"),entityType:v.entityType,entityId:v.entityId,date:v.date,amount:num(v.amount),method:v.method,ref:v.ref,direction:v.entityType==="suppliers"?"to_entity":"from_entity",createdAt:existing?.createdAt||new Date().toISOString(),updatedAt:new Date().toISOString()};if(existing)db.payments=db.payments.map(x=>x.id===existing.id?rec:x);else db.payments.push(rec)}
 if(type==="adjustment"){if(!v.reason||!v.kg)return;const rec={...(existing||{}),id:existing?.id||id("ADJ"),product:v.product,date:v.date,kg:num(v.kg),reason:v.reason};if(existing)db.stockAdjustments=db.stockAdjustments.map(x=>x.id===existing.id?rec:x);else db.stockAdjustments.push(rec)}
 if(type==="expense"){if(!v.description||num(v.amount)<=0)return;const rec={...(existing||{}),id:existing?.id||id("EXP"),date:v.date,amount:num(v.amount),description:v.description};if(existing)db.expenses=db.expenses.map(x=>x.id===existing.id?rec:x);else db.expenses.push(rec)}
 save();close();render();toast("Record saved successfully");
 };
}
function populatePaymentEntities(){let t=document.querySelector('[name="entityType"]')?.value,sel=document.getElementById("paymentEntity");if(!sel)return;sel.innerHTML=(db[t]||[]).map(x=>`<option value="${x.id}">${esc(x.name)}</option>`).join("")||'<option value="">Add an account first</option>'}
function addProductLine(item=null){let d=document.createElement("div");d.className="product-line form-grid";d.style.cssText="border:1px solid #eee;padding:10px;border-radius:8px;margin-bottom:8px";d.innerHTML=`<div class="field"><label>Product</label><select name="product">${PRODUCTS.map(x=>`<option ${item?.product===x?"selected":""}>${x}</option>`).join("")}</select></div><div class="field"><label id="qtyLabel">Quantity</label><input name="kg" type="number" min="0" step="0.01" value="${item?.qty??item?.kg??""}" placeholder="0.00"></div><div class="field"><label id="priceLabel">Price per unit (TSh)</label><input name="price" type="number" min="0" step="1" value="${item?.price??""}" placeholder="0"></div><div class="field" style="align-content:end"><button type="button" class="button small ghost remove-line">Remove line</button></div>`;document.getElementById("lineRows").appendChild(d);const productSel=d.querySelector("[name=product]"),qtyLabel=d.querySelector("#qtyLabel"),priceLabel=d.querySelector("#priceLabel"),qty=d.querySelector("[name=kg]");const unit=()=>{const pair=productSel.value==="Makongoro";qty.step=pair?"1":"0.01";qty.min=pair?"1":"0";qty.placeholder=pair?"Number of pairs":"0.00";qtyLabel.textContent=pair?"Quantity (pairs)":"Quantity (kg)";priceLabel.textContent=pair?"Price per pair (TSh)":"Price per kg (TSh)";};productSel.addEventListener("change",unit);unit();d.querySelector(".remove-line").onclick=()=>{d.remove();calcLineTotal()}}
function calcLineTotal(){let total=0;document.querySelectorAll(".product-line").forEach(r=>total+=num(r.querySelector("[name=kg]").value)*num(r.querySelector("[name=price]").value));let el=document.getElementById("lineTotal");if(el)el.textContent=money(total)}
function previewStatement(){
 let type=document.getElementById("stmtType").value,entityId=document.getElementById("stmtEntity").value,m=document.getElementById("stmtMonth").value;if(!entityId||!m){toast("Add/select an account and month first.");return}
 let start=m+"-01",end=m+"-"+new Date(Number(m.slice(0,4)),Number(m.slice(5,7)),0).getDate().toString().padStart(2,"0"),isS=type==="suppliers",entity=entityName(type,entityId);
 let tx=db[isS?"purchases":"sales"].filter(x=>x.entityId===entityId&&x.date>=start&&x.date<=end);
 let payments=db.payments.filter(x=>x.entityType===type&&x.entityId===entityId&&x.date>=start&&x.date<=end);
 let prevBal=balance(type,entityId,prevDate(start));
 let purchases=sum(tx,x=>x.total),paid=sum(payments,x=>x.amount);
 let opening=prevBal, totalDue=isS?opening+purchases-paid:opening+purchases-paid;
 let items={};tx.forEach(t=>t.items.forEach(i=>{items[i.product]??={kg:0,pairs:0,amount:0};const q=i.qty??i.kg;if(i.unit==="pair"||i.product==="Makongoro")items[i.product].pairs+=q;else items[i.product].kg+=q;items[i.product].amount+=q*i.price}));
 let statementId=id("STM");db.statements.push({id:statementId,type,entityId,month:m,createdAt:new Date().toISOString(),opening,purchases,paid,closing:totalDue});save();
 let html=`<div id="ticket" class="ticket"><div class="ticket-brand"><h2>ISACK MEAT SUPPLY</h2><p>FRESH MEAT WHOLESALE · ACCOUNT STATEMENT</p></div><h3>${isS?"SUPPLIER STATEMENT":"CUSTOMER STATEMENT"}</h3><div class="ticket-meta"><div><b>${isS?"Butcher / Supplier":"Company / Customer"}:</b><br>${esc(entity)}</div><div><b>Period:</b><br>${esc(m)}</div><div><b>Statement No:</b><br>${esc(statementId)}</div><div><b>Issued:</b><br>${fmtDate(today())}</div></div><table><thead><tr><th>Product</th><th>Quantity</th><th>Amount</th></tr></thead><tbody>${PRODUCTS.map(p=>`<tr><td>${p}</td><td>${(items[p]?.kg||0).toFixed(2)} kg</td><td>${money(items[p]?.amount||0)}</td></tr>`).join("")}<tr class="total-row"><td colspan="2">Period ${isS?"purchases":"sales"}</td><td>${money(purchases)}</td></tr></tbody></table><table><tbody><tr><td>Opening balance</td><td style="text-align:right">${money(opening)}</td></tr><tr><td>${isS?"Purchases taken":"Sales supplied"}</td><td style="text-align:right">${money(purchases)}</td></tr><tr><td>${isS?"Payments made":"Payments received"}</td><td style="text-align:right">− ${money(paid)}</td></tr></tbody></table><div class="ticket-balance"><small>${isS?"BALANCE PAYABLE TO SUPPLIER":"CUSTOMER OUTSTANDING BALANCE"}</small><strong>${money(totalDue)}</strong></div><div class="ticket-foot">Please review this statement and contact Isack Meat Supply if any item needs reconciliation.<br>Generated from recorded transactions · ${esc(statementId)}</div></div><div class="ticket-actions"><button class="button" id="shareTicket">Share ticket</button><button class="button ghost" id="downloadTicket">Download image</button><button class="button ghost" id="printTicket">Print / Save PDF</button></div><p class="stat-foot">Note: This statement is based on records entered in the system. Verify opening balances and payments before sending.</p>`;
 document.getElementById("statementPreview").innerHTML=html;
 document.getElementById("shareTicket").onclick=async()=>{await shareTicket(entity,m,statementId)};
 document.getElementById("downloadTicket").onclick=()=>downloadTicketImage();
 document.getElementById("printTicket").onclick=()=>window.print();
}
function prevDate(start){let d=new Date(start+"T00:00:00");d.setDate(d.getDate()-1);return d.toISOString().slice(0,10)}
async function shareTicket(entity,m,statementId){
 const filename=`isack-meat-statement-${statementId}.png`;
 try{
  const blob=await ticketBlob();
  if(!blob||blob.size===0)throw new Error('The statement image is empty');
  const file=new File([blob],filename,{type:'image/png'});
  if(navigator.share){
   try{
    if(!navigator.canShare||navigator.canShare({files:[file]})){
     await navigator.share({title:'Isack Meat Supply Statement',text:`Account statement for ${entity} · ${m}`,files:[file]});
     toast('Statement image shared successfully.');return;
    }
   }catch(err){if(err&&err.name==='AbortError')return;}
  }
  await downloadBlob(blob,filename,'image/png');
  toast('Statement image saved. Open WhatsApp and attach the downloaded PNG image.');
 }catch(e){console.error('Share statement failed:',e);toast('Could not create the statement image. Please try Download image again.');}
}
async function ticketBlob(){
 const node=document.getElementById('ticket');
 if(!node)throw new Error('No statement ticket found');
 // Build the PNG directly from the ticket contents. This avoids depending on an external image library.
 return renderTicketCanvas(node);
}
function renderTicketCanvas(node){
 return new Promise((resolve,reject)=>{
  try{
   const canvas=document.createElement('canvas'),ctx=canvas.getContext('2d');
   if(!ctx)throw new Error('Canvas is not supported by this browser');
   const W=1000, pad=64, inner=W-pad*2, rowH=48;
   const brandTitle=node.querySelector('.ticket-brand h2')?.textContent?.trim()||'ISACK MEAT SUPPLY';
   const brandSub=node.querySelector('.ticket-brand p')?.textContent?.trim()||'FRESH MEAT WHOLESALE · ACCOUNT STATEMENT';
   const heading=node.querySelector('h3')?.textContent?.trim()||'ACCOUNT STATEMENT';
   const meta=[...(node.querySelectorAll('.ticket-meta > div'))].map(el=>el.innerText.split('\n').map(x=>x.trim()).filter(Boolean));
   const tables=[...node.querySelectorAll('table')];
   const productRows=tables[0]?[...tables[0].querySelectorAll('tr')].map(tr=>[...tr.children].map(td=>td.innerText.trim())):[];
   const summaryRows=tables[1]?[...tables[1].querySelectorAll('tr')].map(tr=>[...tr.children].map(td=>td.innerText.trim())):[];
   const balanceLabel=node.querySelector('.ticket-balance small')?.textContent?.trim()||'BALANCE';
   const balanceValue=node.querySelector('.ticket-balance strong')?.textContent?.trim()||'';
   const footer=node.querySelector('.ticket-foot')?.innerText?.trim()||'';
   const height=350+meta.length*76+Math.max(productRows.length,1)*rowH+summaryRows.length*rowH+190;
   canvas.width=W;canvas.height=height;
   // Keep output sharp on high-density screens; canvas dimensions themselves are the exported pixel dimensions.
   ctx.fillStyle='#f3f4f6';ctx.fillRect(0,0,W,height);
   ctx.fillStyle='#ffffff';ctx.fillRect(24,24,W-48,height-48);
   ctx.fillStyle='#7f1d1d';ctx.fillRect(24,24,W-48,18);
   let y=94;
   ctx.textAlign='center';ctx.fillStyle='#7f1d1d';ctx.font='bold 36px Arial';ctx.fillText(brandTitle,W/2,y);y+=34;
   ctx.fillStyle='#6b7280';ctx.font='18px Arial';ctx.fillText(brandSub,W/2,y);y+=28;
   ctx.strokeStyle='#9ca3af';ctx.setLineDash([8,7]);ctx.beginPath();ctx.moveTo(pad,y);ctx.lineTo(W-pad,y);ctx.stroke();ctx.setLineDash([]);y+=48;
   ctx.fillStyle='#111827';ctx.font='bold 22px Arial';ctx.fillText(heading,W/2,y);y+=38;
   ctx.textAlign='left';
   const metaColW=(inner-24)/2;
   meta.forEach((pair,i)=>{const col=i%2,row=Math.floor(i/2),x=pad+col*(metaColW+24),my=y+row*65;ctx.fillStyle='#6b7280';ctx.font='16px Arial';ctx.fillText(pair[0]||'',x,my);ctx.fillStyle='#111827';ctx.font='bold 19px Arial';ctx.fillText((pair.slice(1).join(' ')||'—').slice(0,42),x,my+26);});
   y+=Math.ceil(meta.length/2)*76;
   // Product table
   if(productRows.length){
    const col=[pad,pad+inner*.48,pad+inner*.70,pad+inner];
    ctx.fillStyle='#f3f4f6';ctx.fillRect(pad,y,inner,rowH);
    ctx.fillStyle='#4b5563';ctx.font='bold 15px Arial';
    const headers=productRows[0];
    ctx.textAlign='left';ctx.fillText(headers[0]||'PRODUCT',col[0]+12,y+30);
    ctx.textAlign='right';ctx.fillText(headers[1]||'QUANTITY',col[2]-12,y+30);ctx.fillText(headers[2]||'AMOUNT',col[3]-12,y+30);y+=rowH;
    productRows.slice(1).forEach((r,idx)=>{ctx.fillStyle=idx%2?'#ffffff':'#fafafa';ctx.fillRect(pad,y,inner,rowH);ctx.fillStyle='#111827';ctx.font=(r[0]&&r[0].toLowerCase().includes('period')?'bold 17px Arial':'18px Arial');ctx.textAlign='left';ctx.fillText((r[0]||'').slice(0,30),col[0]+12,y+30);ctx.textAlign='right';if(r.length>=3){ctx.fillText((r[1]||'').slice(0,22),col[2]-12,y+30);ctx.fillText((r[2]||'').slice(0,22),col[3]-12,y+30)}else{ctx.fillText((r[1]||'').slice(0,22),col[3]-12,y+30)}ctx.strokeStyle='#e5e7eb';ctx.beginPath();ctx.moveTo(pad,y+rowH);ctx.lineTo(W-pad,y+rowH);ctx.stroke();y+=rowH;});
   }
   y+=24;
   summaryRows.forEach((r,i)=>{ctx.fillStyle=i%2?'#ffffff':'#fafafa';ctx.fillRect(pad,y,inner,rowH);ctx.fillStyle='#374151';ctx.font='18px Arial';ctx.textAlign='left';ctx.fillText((r[0]||'').slice(0,54),pad+12,y+30);ctx.textAlign='right';ctx.font='bold 18px Arial';ctx.fillText((r.slice(1).join(' ')||'').slice(0,28),W-pad-12,y+30);y+=rowH;});
   y+=20;ctx.fillStyle='#7f1d1d';ctx.fillRect(pad,y,inner,110);ctx.textAlign='center';ctx.fillStyle='#fee2e2';ctx.font='bold 16px Arial';ctx.fillText(balanceLabel,W/2,y+35);ctx.fillStyle='#ffffff';ctx.font='bold 34px Arial';ctx.fillText(balanceValue,W/2,y+79);y+=132;
   ctx.strokeStyle='#9ca3af';ctx.setLineDash([7,6]);ctx.beginPath();ctx.moveTo(pad,y);ctx.lineTo(W-pad,y);ctx.stroke();ctx.setLineDash([]);
   ctx.fillStyle='#6b7280';ctx.font='15px Arial';const words=footer.split(/\s+/);let line='',fy=y+28;for(const word of words){const test=line?line+' '+word:word;if(ctx.measureText(test).width>inner-20){ctx.fillText(line,W/2,fy);line=word;fy+=23}else line=test;}if(line)ctx.fillText(line,W/2,fy);
   canvas.toBlob(blob=>blob?resolve(blob):reject(new Error('Browser failed to encode the PNG image')),'image/png');
  }catch(err){reject(err)}
 });
}
async function downloadBlob(content,name,type){
 const blob=content instanceof Blob?content:new Blob([content],{type});
 if(!blob.size)throw new Error('Nothing to download');
 const url=URL.createObjectURL(blob),a=document.createElement('a');
 a.href=url;a.download=name;a.style.display='none';document.body.appendChild(a);
 try{a.click();}finally{a.remove();}
 // Keep the object URL alive briefly so mobile browsers can begin the download.
 setTimeout(()=>URL.revokeObjectURL(url),15000);
 return true;
}
async function downloadTicketImage(){
 const btn=document.getElementById('downloadTicket');if(btn){btn.disabled=true;btn.textContent='Preparing image…'}
 try{const blob=await ticketBlob();await downloadBlob(blob,`isack-meat-statement-${today()}.png`,'image/png');toast('Statement PNG download started. Check Downloads.');}
 catch(e){console.error('Download statement failed:',e);toast('Image download failed. Please use Print / Save PDF as a temporary alternative.');}
 finally{if(btn){btn.disabled=false;btn.textContent='Download image'}}
}
function downloadCsvReport(){let rows=[["Type","Date","Account","Product","Kg","Price/kg","Amount","Reference"]];["purchases","sales"].forEach(t=>db[t].forEach(x=>x.items.forEach(i=>rows.push([t,x.date,entityName(t==="purchases"?"suppliers":"customers",x.entityId),i.product,i.kg,i.price,i.kg*i.price,x.ref||""]))));db.payments.forEach(x=>rows.push(["payment",x.date,entityName(x.entityType,x.entityId),"","", "",x.amount,x.ref||""]));let csv=rows.map(r=>r.map(v=>`"${String(v??"").replace(/"/g,'""')}"`).join(",")).join("\r\n");downloadBlob(csv,"isack-meat-report-"+today()+".csv","text/csv")}
render();