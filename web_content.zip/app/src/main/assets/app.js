const KEY="taqib_state_v1";
let state=JSON.parse(localStorage.getItem(KEY)||'{"password":"0000","appointments":[]}');
let currentAlerts=[];

function login(){
 const p=document.getElementById("password").value;
 if(p===state.password){sessionStorage.ok="1";showApp();}
 else alert("كلمة المرور غير صحيحة");
}
function logout(){sessionStorage.removeItem("ok");location.reload()}
function showApp(){document.getElementById("login").classList.add("hidden");document.getElementById("app").classList.remove("hidden");initTimeSelectors();renderAll();syncNative()}
if(sessionStorage.ok==="1") showApp();

function save(){localStorage.setItem(KEY,JSON.stringify(state));}
function pad(n){return String(n).padStart(2,"0")}
function to12(h,m){
 h=Number(h); return {hour:h%12||12,ampm:h>=12?"PM":"AM",minute:pad(m)}
}
function from12(h,ampm){h=Number(h)%12;return ampm==="PM"?h+12:h}

function initTimeSelectors(){
 const h=document.getElementById("hour"),m=document.getElementById("minute");
 if(!h||h.options.length)return;
 for(let i=1;i<=12;i++)h.add(new Option(i,i));
 for(let i=0;i<60;i++)m.add(new Option(pad(i),i));
}
function localTimestamp(date,hour,minute,ampm){
 const d=new Date(`${date}T00:00:00`);
 d.setHours(from12(hour,ampm),Number(minute),0,0);
 return d.getTime();
}
function formatTime(h,m,ampm){return `${Number(h)}:${pad(m)} ${ampm==="AM"?"صباحًا":"مساءً"}`}
function formatDateTime(ts){
 const d=new Date(ts), t=to12(d.getHours(),d.getMinutes());
 return `${d.toLocaleDateString("ar-IQ")} - ${formatTime(t.hour,t.minute,t.ampm)}`;
}

function openAppointment(id=null){
 initTimeSelectors();
 document.getElementById("modal").classList.remove("hidden");
 document.getElementById("editId").value=id||"";
 document.getElementById("modalTitle").textContent=id?"تعديل الموعد":"موعد جديد";
 currentAlerts=[];
 if(id){
  const a=state.appointments.find(x=>x.id===id);
  document.getElementById("title").value=a.title;
  document.getElementById("date").value=a.date;
  document.getElementById("place").value=a.place||"";
  document.getElementById("notes").value=a.notes||"";
  const t=to12(a.hour24,a.minute);
  document.getElementById("hour").value=t.hour;
  document.getElementById("minute").value=t.minute;
  document.getElementById("ampm").value=t.ampm;
  currentAlerts=structuredClone(a.alerts||[]);
 }else{
  const now=new Date(),t=to12(now.getHours(),now.getMinutes());
  document.getElementById("title").value="";
  document.getElementById("date").value=`${now.getFullYear()}-${pad(now.getMonth()+1)}-${pad(now.getDate())}`;
  document.getElementById("place").value="";
  document.getElementById("notes").value="";
  document.getElementById("hour").value=t.hour;
  document.getElementById("minute").value=pad(Math.ceil(now.getMinutes()/5)*5%60);
  document.getElementById("ampm").value=t.ampm;
 }
 renderAlertRows();
}
function closeModal(){document.getElementById("modal").classList.add("hidden")}

function renderAlertRows(){
 const box=document.getElementById("alerts");box.innerHTML="";
 currentAlerts.forEach((a,i)=>{
  const row=document.createElement("div");row.className="alertRow";
  row.innerHTML=`<input value="${escapeHtml(a.message||"تنبيه للموعد")}" onchange="currentAlerts[${i}].message=this.value">
  <select onchange="currentAlerts[${i}].minutes=Number(this.value)"><option value="0">وقت الموعد</option><option value="5">قبل 5 دقائق</option><option value="15">قبل 15 دقيقة</option><option value="30">قبل 30 دقيقة</option><option value="60">قبل ساعة</option><option value="1440">قبل يوم</option></select>
  <button class="secondary" onclick="currentAlerts.splice(${i},1);renderAlertRows()">حذف</button>`;
  row.querySelector("select").value=String(a.minutes||0);
  box.appendChild(row);
 });
}
function addAlert(){currentAlerts.push({id:crypto.randomUUID(),minutes:15,message:"تنبيه للموعد",enabled:true});renderAlertRows()}
function quickAlert(minutes){currentAlerts.push({id:crypto.randomUUID(),minutes,message:`تنبيه قبل ${minutes===1440?"يوم":minutes<60?minutes+" دقيقة": "ساعة"}`,enabled:true});renderAlertRows()}

function saveAppointment(){
 const id=document.getElementById("editId").value||crypto.randomUUID();
 const title=document.getElementById("title").value.trim();
 const date=document.getElementById("date").value;
 const hour=Number(document.getElementById("hour").value);
 const minute=Number(document.getElementById("minute").value);
 const ampm=document.getElementById("ampm").value;
 if(!title||!date){alert("أدخل عنوان الموعد والتاريخ");return}
 const hour24=from12(hour,ampm);
 const base=localTimestamp(date,hour,minute,ampm);
 const alerts=currentAlerts.map(a=>({
   id:a.id||crypto.randomUUID(),minutes:Number(a.minutes||0),message:a.message||"تنبيه للموعد",enabled:a.enabled!==false,
   timestamp:base-Number(a.minutes||0)*60000
 }));
 const old=state.appointments.find(x=>x.id===id);
 const obj={id,title,date,hour24,minute,place:document.getElementById("place").value.trim(),notes:document.getElementById("notes").value.trim(),alerts,status:old?.status||"pending",reason:old?.reason||""};
 const ix=state.appointments.findIndex(x=>x.id===id);
 if(ix>=0)state.appointments[ix]=obj;else state.appointments.push(obj);
 save();closeModal();renderAll();syncNative();
}
function deleteAppointment(id){
 if(confirm("هل تريد حذف الموعد؟")){state.appointments=state.appointments.filter(x=>x.id!==id);save();renderAll();syncNative()}
}
function setStatus(id,status){
 const a=state.appointments.find(x=>x.id===id);if(!a)return;
 if(status==="notdone"){const r=prompt("أدخل سبب عدم التنفيذ:");if(!r)return;a.reason=r}
 a.status=status;save();renderAll()
}

function renderAll(){updateStats();renderAppointments()}
function updateStats(){
 const n=state.appointments.length, d=state.appointments.filter(a=>a.status==="done").length, nd=state.appointments.filter(a=>a.status==="notdone").length;
 const now=Date.now();const u=state.appointments.filter(a=>localTimestamp(a.date,a.hour24%12||12,a.minute,a.hour24>=12?"PM":"AM")>now).length;
 total.textContent=n;done.textContent=d;notdone.textContent=nd;upcoming.textContent=u;
}
function renderAppointments(){
 const q=(document.getElementById("search").value||"").toLowerCase();
 const f=document.getElementById("filter").value;const now=new Date();
 let arr=state.appointments.filter(a=>{
  const text=(a.title+" "+a.place+" "+a.notes).toLowerCase();
  if(q&&!text.includes(q))return false;
  if(f==="today"&&a.date!==`${now.getFullYear()}-${pad(now.getMonth()+1)}-${pad(now.getDate())}`)return false;
  if(f==="done"&&a.status!=="done")return false;
  if(f==="notdone"&&a.status!=="notdone")return false;
  if(f==="upcoming"&&new Date(a.date+"T00:00:00")<new Date(now.getFullYear(),now.getMonth(),now.getDate()))return false;
  return true;
 }).sort((a,b)=>(a.date+a.hour24+pad(a.minute)).localeCompare(b.date+b.hour24+pad(b.minute)));
 const box=document.getElementById("appointments");box.innerHTML="";
 if(!arr.length){box.innerHTML="<p>لا توجد مواعيد.</p>";return}
 arr.forEach(a=>{
  const t=to12(a.hour24,a.minute);
  const status=a.status==="done"?'<span class="badge done">تم</span>':a.status==="notdone"?'<span class="badge no">لم يتم</span>':'<span class="badge">غير محدد</span>';
  const div=document.createElement("div");div.className="appointment";
  div.innerHTML=`<div class="appointmentHead"><div><h3>${escapeHtml(a.title)}</h3><div class="meta">📅 ${new Date(a.date+"T00:00:00").toLocaleDateString("ar-IQ")} &nbsp; ⏰ ${formatTime(t.hour,t.minute,t.ampm)}<br>${a.place?"📍 "+escapeHtml(a.place):""}</div></div><div>${status}</div></div>
  <div class="meta">${a.notes?escapeHtml(a.notes):""}</div>
  <div class="badges">${a.alerts.length?`<span class="badge">🔔 ${a.alerts.length} تنبيه</span>`:""}</div>
  <div class="actions"><button onclick="openAppointment('${a.id}')">تعديل</button><button onclick="setStatus('${a.id}','done')">تم</button><button onclick="setStatus('${a.id}','notdone')">لم يتم</button><button onclick="deleteAppointment('${a.id}')">حذف</button></div>`;
  box.appendChild(div);
 });
}
function renderReports(){
 const r=document.getElementById("reports");r.classList.remove("hidden");
 r.innerHTML=`<h2>التقارير</h2><p>إجمالي: ${state.appointments.length} | تم: ${state.appointments.filter(a=>a.status==="done").length} | لم يتم: ${state.appointments.filter(a=>a.status==="notdone").length}</p>`;
}
function backup(){
 const blob=new Blob([JSON.stringify(state,null,2)],{type:"application/json"}),a=document.createElement("a");
 a.href=URL.createObjectURL(blob);a.download="نسخة_احتياطية_تطبيق_المتابعة.json";a.click();URL.revokeObjectURL(a.href)
}
function restore(e){
 const f=e.target.files[0];if(!f)return;const r=new FileReader();
 r.onload=()=>{try{state=JSON.parse(r.result);save();renderAll();syncNative();alert("تمت الاستعادة")}catch(_){alert("الملف غير صالح")}};r.readAsText(f)
}
function escapeHtml(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]))}

function nativeAlarms(){
 const arr=[];const now=Date.now();
 state.appointments.forEach(a=>(a.alerts||[]).forEach(x=>{
  const ts=Number(x.timestamp||0);
  if(x.enabled!==false && ts>now)arr.push({id:a.id+"_"+x.id,appointmentId:a.id,timestamp:ts,title:a.title,message:x.message||"تنبيه للموعد",enabled:true})
 }));
 return arr;
}
function syncNative(){
 if(window.AndroidBridge?.syncAlarms){
   const ok=AndroidBridge.syncAlarms(JSON.stringify(nativeAlarms()));
   if(!ok) showExactAlarmHint();
 }
}
function showExactAlarmHint(){
 const n=window.AndroidBridge;
 if(n?.hasExactAlarmPermission&&!n.hasExactAlarmPermission()){
  setTimeout(()=>{if(confirm("لعمل المنبهات الدقيقة حتى عند إغلاق التطبيق، يجب السماح للتطبيق بإذن «المنبهات والتذكيرات». هل تريد فتح الإعدادات؟"))n.requestExactAlarmPermission()},500)
 }
}
window.onNativeResume=function(){syncNative()}
