M.Ayaz Business Manager - UI Prototype
Open index.html in a mobile browser.
Included clickable prototype screens: Home Dashboard, Customers, Credit/Collection.
This is the first UI prototype, not the final APK.
