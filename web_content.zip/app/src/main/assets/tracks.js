// Street Drift Legends - Track & Environment Generator
// Generates diverse 3D racing circuits with splines, scenery, ramps, tunnels, and lighting

const TRACK_CONFIGS = [
  {
    id: "neon_tokyo",
    name: "Neo Shinjuku Expressway",
    location: "Tokyo",
    difficulty: "Medium",
    defaultLaps: 2,
    lengthKm: "3.8 km",
    theme: "neon_city",
    skyColor: 0x050814,
    groundColor: 0x0a0c16,
    fogColor: 0x080b18,
    ambientLight: 0x223355,
    sunLight: 0x4488ff,
    roadColor: 0x181a24,
    accentColor: 0x00e5ff,
    description: "Wet asphalt glowing under neon skyscrapers. Multiple drift hairpins and elevated skybridge jumps."
  },
  {
    id: "desert_canyon",
    name: "Red Rock Speedway",
    location: "Mojave Desert",
    difficulty: "Hard",
    defaultLaps: 2,
    lengthKm: "4.4 km",
    theme: "desert",
    skyColor: 0x3d2016,
    groundColor: 0xc87d46,
    fogColor: 0xa45228,
    ambientLight: 0x553322,
    sunLight: 0xffaa44,
    roadColor: 0x2b2b2b,
    accentColor: 0xff9100,
    description: "High-speed sweeping turns through towering sandstone canyons with massive canyon gap jumps."
  },
  {
    id: "coastal_bay",
    name: "Azure Coastline Boulevard",
    location: "Miami Coast",
    difficulty: "Easy",
    defaultLaps: 2,
    lengthKm: "3.2 km",
    theme: "coastal",
    skyColor: 0x0a1a3a,
    groundColor: 0x112233,
    fogColor: 0x0e2444,
    ambientLight: 0x334466,
    sunLight: 0x00f0ff,
    roadColor: 0x1c1e24,
    accentColor: 0x00e676,
    description: "Wide beachside highways lined with illuminated palm trees, ocean bridges, and smooth drift arcs."
  },
  {
    id: "mountain_pass",
    name: "Mount Akina Downhill",
    location: "Gunma Pass",
    difficulty: "Expert",
    defaultLaps: 2,
    lengthKm: "4.8 km",
    theme: "mountain",
    skyColor: 0x080812,
    groundColor: 0x141820,
    fogColor: 0x0a0e1a,
    ambientLight: 0x2a2a3e,
    sunLight: 0xffffff,
    roadColor: 0x1a1a20,
    accentColor: 0xd500f9,
    description: "Steep downhill descent featuring technical hairpin series, cliff-edge drift gutters, and double tunnels."
  },
  {
    id: "cyber_metropolis",
    name: "Sector 7 Orbital Ring",
    location: "Future Metropolis",
    difficulty: "Master",
    defaultLaps: 3,
    lengthKm: "5.2 km",
    theme: "cyber",
    skyColor: 0x03030d,
    groundColor: 0x080815,
    fogColor: 0x060614,
    ambientLight: 0x441166,
    sunLight: 0xff00bb,
    roadColor: 0x151622,
    accentColor: 0xff007f,
    description: "Suspended magnetic highways above a glowing megacity with speed boost pads and 720 corkscrew ramps."
  }
];

class TrackBuilder {
  static generateControlPoints(trackId) {
    // Generate closed circuit spline nodes [x, y, z]
    switch (trackId) {
      case "desert_canyon":
        return [
          new THREE.Vector3(0, 0, 0),
          new THREE.Vector3(120, 5, 200),
          new THREE.Vector3(260, 15, 340),
          new THREE.Vector3(420, 20, 280),
          new THREE.Vector3(480, 8, 80),
          new THREE.Vector3(380, 2, -140),
          new THREE.Vector3(220, 10, -280),
          new THREE.Vector3(80, 18, -380),
          new THREE.Vector3(-140, 6, -320),
          new THREE.Vector3(-280, 0, -160),
          new THREE.Vector3(-220, -2, 80),
          new THREE.Vector3(-80, 0, 0)
        ];
      case "coastal_bay":
        return [
          new THREE.Vector3(0, 0, 0),
          new THREE.Vector3(80, 2, 180),
          new THREE.Vector3(180, 4, 300),
          new THREE.Vector3(320, 6, 260),
          new THREE.Vector3(360, 8, 100),
          new THREE.Vector3(280, 4, -80),
          new THREE.Vector3(160, 2, -220),
          new THREE.Vector3(0, 4, -300),
          new THREE.Vector3(-180, 6, -260),
          new THREE.Vector3(-260, 4, -100),
          new THREE.Vector3(-180, 2, 80),
          new THREE.Vector3(-60, 0, 20)
        ];
      case "mountain_pass":
        return [
          new THREE.Vector3(0, 0, 0),
          new THREE.Vector3(90, 8, 140),
          new THREE.Vector3(160, 18, 90),
          new THREE.Vector3(240, 28, 180),
          new THREE.Vector3(320, 36, 120),
          new THREE.Vector3(390, 42, 220),
          new THREE.Vector3(340, 30, 320),
          new THREE.Vector3(200, 22, 380),
          new THREE.Vector3(70, 14, 280),
          new THREE.Vector3(-60, 10, 320),
          new THREE.Vector3(-180, 6, 220),
          new THREE.Vector3(-240, 2, 90),
          new THREE.Vector3(-160, 0, -100),
          new THREE.Vector3(-40, 0, -40)
        ];
      case "cyber_metropolis":
        return [
          new THREE.Vector3(0, 5, 0),
          new THREE.Vector3(140, 12, 180),
          new THREE.Vector3(280, 22, 320),
          new THREE.Vector3(440, 25, 240),
          new THREE.Vector3(420, 18, 60),
          new THREE.Vector3(290, 14, -120),
          new THREE.Vector3(360, 26, -260),
          new THREE.Vector3(220, 32, -400),
          new THREE.Vector3(50, 20, -320),
          new THREE.Vector3(-120, 12, -220),
          new THREE.Vector3(-280, 6, -100),
          new THREE.Vector3(-320, 8, 120),
          new THREE.Vector3(-180, 6, 240),
          new THREE.Vector3(-60, 5, 40)
        ];
      case "neon_tokyo":
      default:
        return [
          new THREE.Vector3(0, 0, 0),
          new THREE.Vector3(100, 0, 150),
          new THREE.Vector3(220, 4, 260),
          new THREE.Vector3(340, 8, 220),
          new THREE.Vector3(400, 12, 80),
          new THREE.Vector3(320, 8, -80),
          new THREE.Vector3(200, 4, -200),
          new THREE.Vector3(80, 0, -300),
          new THREE.Vector3(-80, 4, -340),
          new THREE.Vector3(-220, 8, -240),
          new THREE.Vector3(-280, 4, -80),
          new THREE.Vector3(-200, 0, 80),
          new THREE.Vector3(-70, 0, 0)
        ];
    }
  }

  static buildTrack(trackConfig, scene) {
    const trackGroup = new THREE.Group();
    trackGroup.name = "trackEnvironment";

    const controlPoints = this.generateControlPoints(trackConfig.id);
    const curve = new THREE.CatmullRomCurve3(controlPoints, true, 'centripetal', 0.5);

    const roadWidth = 16.0;
    const segments = 240;
    const points = curve.getPoints(segments);
    const frenetFrames = curve.computeFrenetFrames(segments, true);

    // 1. Road Geometry
    const roadVertices = [];
    const roadUvs = [];
    const roadIndices = [];

    const curbVerticesL = [];
    const curbVerticesR = [];
    const curbIndices = [];

    const barrierVerticesL = [];
    const barrierVerticesR = [];
    const barrierIndices = [];

    for (let i = 0; i <= segments; i++) {
      const p = points[i % segments];
      const normal = frenetFrames.binormals[i % segments];
      const tangent = frenetFrames.tangents[i % segments];

      const halfW = roadWidth * 0.5;

      // Road edge points
      const leftP = new THREE.Vector3().copy(p).addScaledVector(normal, -halfW);
      const rightP = new THREE.Vector3().copy(p).addScaledVector(normal, halfW);

      roadVertices.push(leftP.x, leftP.y + 0.05, leftP.z);
      roadVertices.push(rightP.x, rightP.y + 0.05, rightP.z);

      const vU = (i / segments) * 45;
      roadUvs.push(0, vU);
      roadUvs.push(1, vU);

      // Curbs & barriers
      const curbW = 1.2;
      const curbH = 0.3;
      const curbLeftOuter = new THREE.Vector3().copy(leftP).addScaledVector(normal, -curbW);
      const curbRightOuter = new THREE.Vector3().copy(rightP).addScaledVector(normal, curbW);

      curbVerticesL.push(leftP.x, leftP.y + 0.05, leftP.z);
      curbVerticesL.push(curbLeftOuter.x, curbLeftOuter.y + curbH, curbLeftOuter.z);

      curbVerticesR.push(rightP.x, rightP.y + 0.05, rightP.z);
      curbVerticesR.push(curbRightOuter.x, curbRightOuter.y + curbH, curbRightOuter.z);

      // Guardrails
      const barH = 1.1;
      barrierVerticesL.push(curbLeftOuter.x, curbLeftOuter.y + curbH, curbLeftOuter.z);
      barrierVerticesL.push(curbLeftOuter.x, curbLeftOuter.y + curbH + barH, curbLeftOuter.z);

      barrierVerticesR.push(curbRightOuter.x, curbRightOuter.y + curbH, curbRightOuter.z);
      barrierVerticesR.push(curbRightOuter.x, curbRightOuter.y + curbH + barH, curbRightOuter.z);

      if (i < segments) {
        const baseIdx = i * 2;
        // Road triangles
        roadIndices.push(baseIdx, baseIdx + 1, baseIdx + 2);
        roadIndices.push(baseIdx + 1, baseIdx + 3, baseIdx + 2);

        // Curb triangles
        curbIndices.push(baseIdx, baseIdx + 1, baseIdx + 2);
        curbIndices.push(baseIdx + 1, baseIdx + 3, baseIdx + 2);

        // Barrier triangles
        barrierIndices.push(baseIdx, baseIdx + 1, baseIdx + 2);
        barrierIndices.push(baseIdx + 1, baseIdx + 3, baseIdx + 2);
      }
    }

    // Road Mesh
    const roadGeo = new THREE.BufferGeometry();
    roadGeo.setAttribute('position', new THREE.Float32BufferAttribute(roadVertices, 3));
    roadGeo.setAttribute('uv', new THREE.Float32BufferAttribute(roadUvs, 2));
    roadGeo.setIndex(roadIndices);
    roadGeo.computeVertexNormals();

    const roadMat = new THREE.MeshStandardMaterial({
      color: trackConfig.roadColor,
      roughness: 0.75,
      metalness: 0.15
    });
    const roadMesh = new THREE.Mesh(roadGeo, roadMat);
    roadMesh.receiveShadow = true;
    trackGroup.add(roadMesh);

    // Curbs Meshes (neon striping)
    const curbGeoL = new THREE.BufferGeometry();
    curbGeoL.setAttribute('position', new THREE.Float32BufferAttribute(curbVerticesL, 3));
    curbGeoL.setIndex(curbIndices);
    curbGeoL.computeVertexNormals();

    const curbMat = new THREE.MeshStandardMaterial({
      color: trackConfig.accentColor,
      roughness: 0.4,
      metalness: 0.5,
      emissive: trackConfig.accentColor,
      emissiveIntensity: 0.35
    });
    trackGroup.add(new THREE.Mesh(curbGeoL, curbMat));

    const curbGeoR = new THREE.BufferGeometry();
    curbGeoR.setAttribute('position', new THREE.Float32BufferAttribute(curbVerticesR, 3));
    curbGeoR.setIndex(curbIndices);
    curbGeoR.computeVertexNormals();
    trackGroup.add(new THREE.Mesh(curbGeoR, curbMat));

    // Barrier Meshes
    const barGeoL = new THREE.BufferGeometry();
    barGeoL.setAttribute('position', new THREE.Float32BufferAttribute(barrierVerticesL, 3));
    barGeoL.setIndex(barrierIndices);
    barGeoL.computeVertexNormals();

    const barMat = new THREE.MeshStandardMaterial({
      color: 0x444455,
      roughness: 0.3,
      metalness: 0.8
    });
    trackGroup.add(new THREE.Mesh(barGeoL, barMat));

    const barGeoR = new THREE.BufferGeometry();
    barGeoR.setAttribute('position', new THREE.Float32BufferAttribute(barrierVerticesR, 3));
    barGeoR.setIndex(barrierIndices);
    barGeoR.computeVertexNormals();
    trackGroup.add(new THREE.Mesh(barGeoR, barMat));

    // 2. Start/Finish Arch & Checkpoints
    const startPos = curve.getPointAt(0);
    const startTangent = curve.getTangentAt(0);
    const startNorm = new THREE.Vector3(-startTangent.z, 0, startTangent.x).normalize();

    const archGroup = new THREE.Group();
    archGroup.position.copy(startPos);
    archGroup.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), startTangent);

    // Pillars
    const pillarGeo = new THREE.BoxGeometry(0.8, 7.5, 0.8);
    const archMat = new THREE.MeshStandardMaterial({ color: 0x222222, metalness: 0.9, roughness: 0.2 });
    const pL = new THREE.Mesh(pillarGeo, archMat);
    pL.position.set(-roadWidth * 0.52, 3.75, 0);
    archGroup.add(pL);

    const pR = new THREE.Mesh(pillarGeo, archMat);
    pR.position.set(roadWidth * 0.52, 3.75, 0);
    archGroup.add(pR);

    // Overhead Beam
    const beamGeo = new THREE.BoxGeometry(roadWidth * 1.1, 1.2, 1.4);
    const beamMesh = new THREE.Mesh(beamGeo, archMat);
    beamMesh.position.set(0, 7.2, 0);
    archGroup.add(beamMesh);

    // Finish Banner
    const bannerGeo = new THREE.PlaneGeometry(roadWidth * 0.9, 1.5);
    const bannerMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
    const bannerMesh = new THREE.Mesh(bannerGeo, bannerMat);
    bannerMesh.position.set(0, 6.2, 0.72);
    archGroup.add(bannerMesh);

    trackGroup.add(archGroup);

    // 3. Stunt Ramps
    const rampLocations = [0.24, 0.55, 0.82];
    const ramps = [];

    rampLocations.forEach((tVal, idx) => {
      const rPos = curve.getPointAt(tVal);
      const rTangent = curve.getTangentAt(tVal);
      const rNorm = new THREE.Vector3(-rTangent.z, 0, rTangent.x).normalize();

      const rampGroup = new THREE.Group();
      rampGroup.position.copy(rPos);
      rampGroup.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), rTangent);

      // Wedge Ramp Geometry
      const rampW = 6.5;
      const rampL = 10.0;
      const rampH = 2.2;
      const rampGeo = new THREE.BoxGeometry(rampW, rampH, rampL);
      rampGeo.rotateX(0.22); // slope

      const rampMat = new THREE.MeshStandardMaterial({
        color: 0xffa500,
        roughness: 0.5,
        metalness: 0.6,
        emissive: 0xff6600,
        emissiveIntensity: 0.4
      });
      const rampMesh = new THREE.Mesh(rampGeo, rampMat);
      rampMesh.position.set(0, 0.6, 0);
      rampGroup.add(rampMesh);

      // Chevrons / Glowing arrows
      const arrowGeo = new THREE.ConeGeometry(0.8, 1.6, 3);
      arrowGeo.rotateZ(-Math.PI / 2);
      arrowGeo.rotateY(Math.PI / 2);
      const arrowMat = new THREE.MeshBasicMaterial({ color: 0x00ffff });
      const arrowMesh = new THREE.Mesh(arrowGeo, arrowMat);
      arrowMesh.position.set(0, rampH * 0.9, 0);
      rampGroup.add(arrowMesh);

      trackGroup.add(rampGroup);

      ramps.push({
        position: rPos,
        tangent: rTangent,
        height: rampH
      });
    });

    // 4. Scenery: City Skyscrapers, Palm Trees, or Desert Formations
    const sceneryGroup = new THREE.Group();
    sceneryGroup.name = "scenery";

    if (trackConfig.theme === "neon_city" || trackConfig.theme === "cyber") {
      // Procedural Instanced Skyscrapers
      const bldgCount = 70;
      const bldgMat = new THREE.MeshStandardMaterial({
        color: 0x0d111a,
        roughness: 0.3,
        metalness: 0.7
      });
      const neonSignMat = new THREE.MeshBasicMaterial({
        color: trackConfig.accentColor
      });

      for (let i = 0; i < bldgCount; i++) {
        const u = (i / bldgCount);
        const p = curve.getPointAt(u);
        const norm = new THREE.Vector3(-curve.getTangentAt(u).z, 0, curve.getTangentAt(u).x).normalize();
        const side = i % 2 === 0 ? 1 : -1;
        const dist = roadWidth * 0.5 + 14 + Math.random() * 45;

        const bH = 25 + Math.random() * 95;
        const bW = 12 + Math.random() * 18;
        const bD = 12 + Math.random() * 18;

        const bGeo = new THREE.BoxGeometry(bW, bH, bD);
        const bMesh = new THREE.Mesh(bGeo, bldgMat);
        bMesh.position.copy(p).addScaledVector(norm, side * dist);
        bMesh.position.y = bH * 0.5;
        sceneryGroup.add(bMesh);

        // Glowing billboard/neon strips on building front
        if (Math.random() > 0.4) {
          const signGeo = new THREE.PlaneGeometry(bW * 0.7, 4 + Math.random() * 8);
          const signMesh = new THREE.Mesh(signGeo, neonSignMat);
          signMesh.position.copy(bMesh.position);
          signMesh.position.y = bH * 0.7;
          signMesh.lookAt(p);
          sceneryGroup.add(signMesh);
        }
      }
    } else if (trackConfig.theme === "coastal") {
      // Water Plane & Palm Trees
      const waterGeo = new THREE.PlaneGeometry(1600, 1600);
      waterGeo.rotateX(-Math.PI / 2);
      const waterMat = new THREE.MeshStandardMaterial({
        color: 0x003366,
        roughness: 0.1,
        metalness: 0.9,
        transparent: true,
        opacity: 0.85
      });
      const waterMesh = new THREE.Mesh(waterGeo, waterMat);
      waterMesh.position.y = -2;
      sceneryGroup.add(waterMesh);

      // Palm trees along boulevard
      for (let i = 0; i < 60; i++) {
        const u = i / 60;
        const p = curve.getPointAt(u);
        const norm = new THREE.Vector3(-curve.getTangentAt(u).z, 0, curve.getTangentAt(u).x).normalize();
        const side = i % 2 === 0 ? 1 : -1;
        const treePos = new THREE.Vector3().copy(p).addScaledVector(norm, side * (roadWidth * 0.5 + 4));

        const trunkGeo = new THREE.CylinderGeometry(0.2, 0.4, 7, 6);
        const trunkMat = new THREE.MeshStandardMaterial({ color: 0x5c4033 });
        const trunk = new THREE.Mesh(trunkGeo, trunkMat);
        trunk.position.copy(treePos);
        trunk.position.y += 3.5;
        sceneryGroup.add(trunk);

        const frondGeo = new THREE.ConeGeometry(2.8, 2.5, 6);
        const frondMat = new THREE.MeshStandardMaterial({ color: 0x00a86b });
        const fronds = new THREE.Mesh(frondGeo, frondMat);
        fronds.position.copy(treePos);
        fronds.position.y += 7.2;
        sceneryGroup.add(fronds);
      }
    } else {
      // Desert / Mountain Rock Formations
      for (let i = 0; i < 50; i++) {
        const u = i / 50;
        const p = curve.getPointAt(u);
        const norm = new THREE.Vector3(-curve.getTangentAt(u).z, 0, curve.getTangentAt(u).x).normalize();
        const side = i % 2 === 0 ? 1 : -1;
        const dist = roadWidth * 0.5 + 12 + Math.random() * 35;

        const rockH = 15 + Math.random() * 55;
        const rockR = 10 + Math.random() * 20;
        const rockGeo = new THREE.DodecahedronGeometry(rockR, 1);
        const rockMat = new THREE.MeshStandardMaterial({
          color: trackConfig.theme === "desert" ? 0x9c4826 : 0x333842,
          roughness: 0.9,
          metalness: 0.1
        });
        const rockMesh = new THREE.Mesh(rockGeo, rockMat);
        rockMesh.position.copy(p).addScaledVector(norm, side * dist);
        rockMesh.position.y = rockH * 0.4;
        rockMesh.scale.set(1, 1.8, 1);
        sceneryGroup.add(rockMesh);
      }
    }

    trackGroup.add(sceneryGroup);

    // Ground Plane
    const terrainGeo = new THREE.PlaneGeometry(2400, 2400);
    terrainGeo.rotateX(-Math.PI / 2);
    const terrainMat = new THREE.MeshStandardMaterial({
      color: trackConfig.groundColor,
      roughness: 0.95,
      metalness: 0.05
    });
    const groundMesh = new THREE.Mesh(terrainGeo, terrainMat);
    groundMesh.position.y = -0.5;
    groundMesh.receiveShadow = true;
    trackGroup.add(groundMesh);

    scene.add(trackGroup);

    return {
      trackGroup,
      curve,
      roadWidth,
      ramps,
      lengthMeters: curve.getLength(),
      controlPoints
    };
  }
}

window.TRACK_CONFIGS = TRACK_CONFIGS;
window.TrackBuilder = TrackBuilder;
