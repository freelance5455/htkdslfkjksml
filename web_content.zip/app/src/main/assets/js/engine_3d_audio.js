// ============================================================================
// MASHA'S HAPPY HOME - WEB AUDIO SYNTHESIZER & 3D WEBGL SCENE ENGINE
// ============================================================================

class SoundEngine {
  constructor() {
    this.ctx = null;
    this.muted = false;
    this.sfxVolume = 0.75;
    this.musicVolume = 0.45;
    this.musicPlaying = false;
    this.musicTimer = null;
    this.melodyStep = 0;
  }

  init() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
  }

  playTone(freq, type = 'sine', duration = 0.15, vol = 0.3, slideFreq = null) {
    if (this.muted || this.sfxVolume <= 0) return;
    this.init();
    if (!this.ctx) return;
    try {
      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = type;
      osc.frequency.setValueAtTime(freq, now);
      if (slideFreq) {
        osc.frequency.exponentialRampToValueAtTime(slideFreq, now + duration);
      }
      const finalVol = Math.min(1, vol * this.sfxVolume);
      gain.gain.setValueAtTime(finalVol, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + duration);
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start(now);
      osc.stop(now + duration);
    } catch (e) {}
  }

  sfxClick() {
    this.playTone(580, 'triangle', 0.08, 0.25, 780);
  }

  sfxCoin() {
    this.playTone(987.77, 'sine', 0.09, 0.3);
    setTimeout(() => this.playTone(1318.51, 'sine', 0.22, 0.35), 75);
  }

  sfxEat() {
    this.playTone(340, 'triangle', 0.11, 0.3, 480);
    setTimeout(() => this.playTone(420, 'triangle', 0.12, 0.3, 590), 110);
  }

  sfxBath() {
    this.playTone(620, 'sine', 0.12, 0.22, 960);
    setTimeout(() => this.playTone(760, 'sine', 0.14, 0.22, 1120), 90);
  }

  sfxSleep() {
    this.playTone(440, 'sine', 0.28, 0.2, 330);
  }

  sfxSuccess() {
    const notes = [523.25, 659.25, 783.99, 1046.5];
    notes.forEach((n, i) => {
      setTimeout(() => this.playTone(n, 'triangle', 0.18, 0.32), i * 80);
    });
  }

  sfxBoing() {
    this.playTone(260, 'sine', 0.22, 0.32, 680);
  }

  sfxMiss() {
    this.playTone(240, 'sawtooth', 0.2, 0.22, 140);
  }

  startMusic() {
    if (this.musicTimer) return;
    // Cheerful folk-inspired woodland melody loop
    const melody = [
      523.25, 587.33, 659.25, 783.99, 659.25, 587.33, 523.25, 392.00,
      440.00, 523.25, 659.25, 587.33, 493.88, 392.00, 523.25, 523.25
    ];
    this.musicTimer = setInterval(() => {
      if (this.muted || this.musicVolume <= 0 || !this.ctx || this.ctx.state !== 'running') return;
      const note = melody[this.melodyStep % melody.length];
      this.melodyStep++;
      try {
        const now = this.ctx.currentTime;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(note, now);
        const v = 0.08 * this.musicVolume;
        gain.gain.setValueAtTime(v, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.34);
        osc.connect(gain);
        gain.connect(this.ctx.destination);
        osc.start(now);
        osc.stop(now + 0.35);
      } catch (e) {}
    }, 420);
  }

  stopMusic() {
    if (this.musicTimer) {
      clearInterval(this.musicTimer);
      this.musicTimer = null;
    }
  }
}

const sound = new SoundEngine();

// ============================================================================
// 3D WEBGL HOME & ARTICULATED TOY CHARACTER ENGINE (Three.js r128)
// ============================================================================

class Home3DEngine {
  constructor(canvasId) {
    this.canvas = document.getElementById(canvasId);
    this.scene = null;
    this.camera = null;
    this.renderer = null;
    this.raycaster = null;
    this.mouse = null;

    this.roomGroup = null;
    this.furnitureGroup = null;
    this.charactersGroup = null;
    this.weatherGroup = null;
    this.particlesGroup = null;

    this.characterMeshes = {};
    this.furnitureMeshes = [];
    this.particles = [];
    this.weatherParticles = [];

    this.ambientLight = null;
    this.dirLight = null;
    this.pointLight = null;

    this.cameraTargetOffset = { x: 0, y: 0 };
    this.isDraggingCamera = false;
    this.lastPointer = { x: 0, y: 0 };
    this.selectedFurnitureId = null;

    this.clock = new THREE.Clock();
  }

  init() {
    if (!window.THREE || !this.canvas) return;
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color('#87ceeb');
    this.scene.fog = new THREE.FogExp2('#87ceeb', 0.022);

    const w = this.canvas.clientWidth || window.innerWidth;
    const h = this.canvas.clientHeight || window.innerHeight;

    this.camera = new THREE.PerspectiveCamera(42, w / h, 0.1, 100);
    this.camera.position.set(0, 7.2, 11.2);
    this.camera.lookAt(0, 1.2, 0);

    this.renderer = new THREE.WebGLRenderer({
      canvas: this.canvas,
      antialias: true,
      powerPreference: 'high-performance'
    });
    this.renderer.setSize(w, h, false);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    this.raycaster = new THREE.Raycaster();
    this.mouse = new THREE.Vector2();

    // Lights
    this.ambientLight = new THREE.AmbientLight(0xffffff, 0.68);
    this.scene.add(this.ambientLight);

    this.dirLight = new THREE.DirectionalLight(0xfff5e4, 0.85);
    this.dirLight.position.set(6, 12, 8);
    this.dirLight.castShadow = true;
    this.dirLight.shadow.mapSize.width = 1024;
    this.dirLight.shadow.mapSize.height = 1024;
    this.dirLight.shadow.camera.near = 1;
    this.dirLight.shadow.camera.far = 30;
    const d = 8;
    this.dirLight.shadow.camera.left = -d;
    this.dirLight.shadow.camera.right = d;
    this.dirLight.shadow.camera.top = d;
    this.dirLight.shadow.camera.bottom = -d;
    this.scene.add(this.dirLight);

    this.pointLight = new THREE.PointLight(0xffca28, 0.45, 16);
    this.pointLight.position.set(0, 4.5, 1);
    this.scene.add(this.pointLight);

    this.roomGroup = new THREE.Group();
    this.furnitureGroup = new THREE.Group();
    this.charactersGroup = new THREE.Group();
    this.weatherGroup = new THREE.Group();
    this.particlesGroup = new THREE.Group();

    this.scene.add(this.roomGroup);
    this.scene.add(this.furnitureGroup);
    this.scene.add(this.charactersGroup);
    this.scene.add(this.weatherGroup);
    this.scene.add(this.particlesGroup);

    this.bindInputEvents();
    window.addEventListener('resize', () => this.onResize());
  }

  onResize() {
    if (!this.renderer || !this.camera || !this.canvas) return;
    const parent = this.canvas.parentElement;
    const w = parent ? parent.clientWidth : window.innerWidth;
    const h = parent ? parent.clientHeight : window.innerHeight;
    if (w === 0 || h === 0) return;
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h, false);
  }

  bindInputEvents() {
    let downTime = 0;
    let startPos = { x: 0, y: 0 };

    const getPos = (e) => {
      if (e.touches && e.touches.length > 0) {
        return { x: e.touches[0].clientX, y: e.touches[0].clientY };
      }
      if (e.changedTouches && e.changedTouches.length > 0) {
        return { x: e.changedTouches[0].clientX, y: e.changedTouches[0].clientY };
      }
      return { x: e.clientX, y: e.clientY };
    };

    const onDown = (e) => {
      const p = getPos(e);
      downTime = performance.now();
      startPos = { x: p.x, y: p.y };
      this.lastPointer = { x: p.x, y: p.y };
      this.isDraggingCamera = true;
    };

    const onMove = (e) => {
      if (!this.isDraggingCamera) return;
      const p = getPos(e);
      const dx = p.x - this.lastPointer.x;
      const dy = p.y - this.lastPointer.y;
      this.lastPointer = { x: p.x, y: p.y };

      if (window.gameApp && window.gameApp.state.decorEditMode && this.selectedFurnitureId) {
        // Move selected furniture in 3D room bounds
        const furnState = window.gameApp.state.furnitureLayout[this.selectedFurnitureId];
        if (furnState) {
          furnState.x = Math.max(-3.6, Math.min(3.6, furnState.x + dx * 0.018));
          furnState.z = Math.max(-3.2, Math.min(2.6, furnState.z + dy * 0.018));
          this.syncFurnitureTransform(this.selectedFurnitureId);
        }
      } else {
        this.cameraTargetOffset.x = Math.max(-2.2, Math.min(2.2, this.cameraTargetOffset.x - dx * 0.006));
        this.cameraTargetOffset.y = Math.max(-1.0, Math.min(1.2, this.cameraTargetOffset.y + dy * 0.005));
      }
    };

    const onUp = (e) => {
      this.isDraggingCamera = false;
      const p = getPos(e);
      const dist = Math.hypot(p.x - startPos.x, p.y - startPos.y);
      if (dist < 14 && performance.now() - downTime < 400) {
        this.handleTap(p.x, p.y);
      }
    };

    this.canvas.addEventListener('mousedown', onDown);
    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onUp);

    this.canvas.addEventListener('touchstart', onDown, { passive: true });
    window.addEventListener('touchmove', onMove, { passive: true });
    window.addEventListener('touchend', onUp);
  }

  handleTap(clientX, clientY) {
    if (!this.raycaster || !this.camera || !window.gameApp) return;
    const rect = this.canvas.getBoundingClientRect();
    this.mouse.x = ((clientX - rect.left) / rect.width) * 2 - 1;
    this.mouse.y = -((clientY - rect.top) / rect.height) * 2 + 1;

    this.raycaster.setFromCamera(this.mouse, this.camera);

    // Check characters first
    const charObjects = [];
    Object.values(this.characterMeshes).forEach((cm) => {
      if (cm && cm.root) charObjects.push(cm.root);
    });
    const charHits = this.raycaster.intersectObjects(charObjects, true);
    if (charHits.length > 0) {
      let obj = charHits[0].object;
      while (obj && !obj.userData.charId && obj.parent) {
        obj = obj.parent;
      }
      if (obj && obj.userData.charId) {
        window.gameApp.onCharacterTapped3D(obj.userData.charId);
        return;
      }
    }

    // Check furniture hits
    const furnHits = this.raycaster.intersectObjects(this.furnitureGroup.children, true);
    if (furnHits.length > 0) {
      let obj = furnHits[0].object;
      while (obj && !obj.userData.furnId && obj.parent) {
        obj = obj.parent;
      }
      if (obj && obj.userData.furnId) {
        window.gameApp.onFurnitureTapped3D(obj.userData.furnId);
      }
    }
  }

  clearGroup(group) {
    while (group.children.length > 0) {
      const child = group.children[0];
      group.remove(child);
    }
  }

  buildRoom(roomId, themeObj, timeOfDay, weatherType) {
    if (!this.scene) return;
    this.clearGroup(this.roomGroup);
    const roomDef = ROOM_DEFS[roomId] || ROOM_DEFS.living;

    const floorCol = roomDef.isOutdoor ? roomDef.floorColor : (themeObj ? themeObj.floorColor : roomDef.floorColor);
    const wallCol = roomDef.isOutdoor ? roomDef.wallColor : (themeObj ? themeObj.wallColor : roomDef.wallColor);

    // Base Floor Platform (Toy Diorama Style)
    const baseGeo = new THREE.BoxGeometry(10.4, 0.6, 8.6);
    const baseMat = new THREE.MeshStandardMaterial({ color: floorCol, roughness: 0.72 });
    const baseMesh = new THREE.Mesh(baseGeo, baseMat);
    baseMesh.position.set(0, -0.3, -0.2);
    baseMesh.receiveShadow = true;
    this.roomGroup.add(baseMesh);

    // Decorative Wooden Rim around Diorama
    const rimGeo = new THREE.BoxGeometry(10.7, 0.35, 8.9);
    const rimMat = new THREE.MeshStandardMaterial({ color: '#5d4037', roughness: 0.8 });
    const rimMesh = new THREE.Mesh(rimGeo, rimMat);
    rimMesh.position.set(0, -0.55, -0.2);
    this.roomGroup.add(rimMesh);

    if (!roomDef.isOutdoor) {
      // Back Wall
      const backWallGeo = new THREE.BoxGeometry(10.4, 5.2, 0.35);
      const wallMat = new THREE.MeshStandardMaterial({ color: wallCol, roughness: 0.65 });
      const backWall = new THREE.Mesh(backWallGeo, wallMat);
      backWall.position.set(0, 2.5, -4.35);
      backWall.receiveShadow = true;
      this.roomGroup.add(backWall);

      // Left & Right Cottage Side Walls
      const sideWallGeo = new THREE.BoxGeometry(0.35, 5.2, 8.6);
      const leftWall = new THREE.Mesh(sideWallGeo, wallMat);
      leftWall.position.set(-5.05, 2.5, -0.2);
      leftWall.receiveShadow = true;
      this.roomGroup.add(leftWall);

      const rightWall = new THREE.Mesh(sideWallGeo, wallMat);
      rightWall.position.set(5.05, 2.5, -0.2);
      rightWall.receiveShadow = true;
      this.roomGroup.add(rightWall);

      // Cozy Cottage Window on Back Wall
      const winFrame = new THREE.Mesh(
        new THREE.BoxGeometry(2.3, 2.1, 0.42),
        new THREE.MeshStandardMaterial({ color: '#6d4c41', roughness: 0.7 })
      );
      winFrame.position.set(0, 2.8, -4.3);
      this.roomGroup.add(winFrame);

      const skyWindowColor = timeOfDay === 'night' ? '#1a237e' : (timeOfDay === 'sunset' ? '#ff8a65' : '#81d4fa');
      const winGlass = new THREE.Mesh(
        new THREE.BoxGeometry(1.95, 1.75, 0.45),
        new THREE.MeshBasicMaterial({ color: skyWindowColor })
      );
      winGlass.position.set(0, 2.8, -4.29);
      this.roomGroup.add(winGlass);
    } else {
      // Outdoor Pine Trees & Wooden Fence around the meadow
      const treePositions = [
        [-4.5, -3.8], [-2.8, -4.1], [2.8, -4.1], [4.5, -3.8],
        [-4.8, -1.5], [4.8, -1.5]
      ];
      treePositions.forEach(([tx, tz]) => {
        const tree = this.createPineTreeMesh();
        tree.position.set(tx, 0, tz);
        this.roomGroup.add(tree);
      });

      if (roomId === 'playground') {
        // Sparkling River Strip on right side
        const riverMesh = new THREE.Mesh(
          new THREE.BoxGeometry(2.4, 0.08, 8.4),
          new THREE.MeshStandardMaterial({ color: '#29b6f6', roughness: 0.2, metalness: 0.1 })
        );
        riverMesh.position.set(3.6, 0.02, -0.2);
        this.roomGroup.add(riverMesh);
      }
    }

    this.updateAtmosphere(timeOfDay, weatherType);
  }

  createPineTreeMesh() {
    const g = new THREE.Group();
    const trunk = new THREE.Mesh(
      new THREE.CylinderGeometry(0.22, 0.3, 1.1, 8),
      new THREE.MeshStandardMaterial({ color: '#5d4037', roughness: 0.9 })
    );
    trunk.position.y = 0.55;
    trunk.castShadow = true;
    g.add(trunk);

    const coneMat = new THREE.MeshStandardMaterial({ color: '#2e7d32', roughness: 0.65 });
    [
      { r: 1.05, h: 1.5, y: 1.45 },
      { r: 0.85, h: 1.3, y: 2.25 },
      { r: 0.6, h: 1.1, y: 2.95 }
    ].forEach((layer) => {
      const cone = new THREE.Mesh(new THREE.ConeGeometry(layer.r, layer.h, 9), coneMat);
      cone.position.y = layer.y;
      cone.castShadow = true;
      g.add(cone);
    });
    return g;
  }

  buildRoomFurniture(roomId, unlockedIds, layoutMap, selectedId) {
    this.clearGroup(this.furnitureGroup);
    this.furnitureMeshes = [];

    const items = FURNITURE_CATALOG.filter(
      (f) => f.room === roomId && (f.defaultUnlocked || unlockedIds.includes(f.id))
    );

    items.forEach((item) => {
      const savedPos = layoutMap[item.id] || item.pos;
      const meshGroup = this.createFurnitureMesh(item, selectedId === item.id);
      meshGroup.position.set(savedPos.x, 0, savedPos.z);
      meshGroup.rotation.y = savedPos.rot || 0;
      meshGroup.userData.furnId = item.id;
      this.furnitureGroup.add(meshGroup);
      this.furnitureMeshes.push(meshGroup);
    });
  }

  syncFurnitureTransform(furnId) {
    if (!window.gameApp) return;
    const savedPos = window.gameApp.state.furnitureLayout[furnId];
    if (!savedPos) return;
    const target = this.furnitureMeshes.find((m) => m.userData.furnId === furnId);
    if (target) {
      target.position.set(savedPos.x, 0, savedPos.z);
      target.rotation.y = savedPos.rot || 0;
    }
  }

  createFurnitureMesh(item, isSelected) {
    const g = new THREE.Group();
    const matPrimary = new THREE.MeshStandardMaterial({ color: item.color || '#8d6e63', roughness: 0.6 });
    const matWood = new THREE.MeshStandardMaterial({ color: '#6d4c41', roughness: 0.75 });
    const matAccent = new THREE.MeshStandardMaterial({ color: '#ffd54f', roughness: 0.4 });

    switch (item.type) {
      case 'sofa': {
        const seat = new THREE.Mesh(new THREE.BoxGeometry(2.1, 0.55, 1.1), matPrimary);
        seat.position.y = 0.35;
        seat.castShadow = true;
        g.add(seat);
        const back = new THREE.Mesh(new THREE.BoxGeometry(2.1, 0.95, 0.35), matPrimary);
        back.position.set(0, 0.75, -0.4);
        back.castShadow = true;
        g.add(back);
        const armL = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.75, 1.15), matWood);
        armL.position.set(-0.95, 0.5, 0);
        g.add(armL);
        const armR = armL.clone();
        armR.position.x = 0.95;
        g.add(armR);
        break;
      }
      case 'fireplace': {
        const body = new THREE.Mesh(new THREE.BoxGeometry(2.3, 2.0, 0.8), matPrimary);
        body.position.y = 1.0;
        body.castShadow = true;
        g.add(body);
        const glow = new THREE.Mesh(
          new THREE.SphereGeometry(0.38, 10, 10),
          new THREE.MeshBasicMaterial({ color: '#ff6d00' })
        );
        glow.position.set(0, 0.45, 0.28);
        g.add(glow);
        break;
      }
      case 'tv': {
        const stand = new THREE.Mesh(new THREE.BoxGeometry(1.4, 0.6, 0.7), matWood);
        stand.position.y = 0.3;
        g.add(stand);
        const box = new THREE.Mesh(new THREE.BoxGeometry(1.3, 0.95, 0.55), matPrimary);
        box.position.y = 1.05;
        box.castShadow = true;
        g.add(box);
        const screen = new THREE.Mesh(
          new THREE.BoxGeometry(1.05, 0.72, 0.58),
          new THREE.MeshBasicMaterial({ color: '#4fc3f7' })
        );
        screen.position.y = 1.05;
        g.add(screen);
        break;
      }
      case 'tub': {
        const tub = new THREE.Mesh(new THREE.CylinderGeometry(1.1, 0.9, 0.85, 16), matPrimary);
        tub.scale.set(1.25, 1, 0.8);
        tub.position.y = 0.45;
        tub.castShadow = true;
        g.add(tub);
        // Foam bubbles on top
        for (let i = 0; i < 6; i++) {
          const b = new THREE.Mesh(
            new THREE.SphereGeometry(0.24, 10, 10),
            new THREE.MeshStandardMaterial({ color: '#e0f7fa', roughness: 0.2 })
          );
          b.position.set((i - 2.5) * 0.32, 0.88, (i % 2 === 0 ? 0.15 : -0.15));
          g.add(b);
        }
        break;
      }
      case 'bed': {
        const frame = new THREE.Mesh(new THREE.BoxGeometry(2.1, 0.45, 2.4), matWood);
        frame.position.y = 0.22;
        frame.castShadow = true;
        g.add(frame);
        const quilt = new THREE.Mesh(new THREE.BoxGeometry(1.95, 0.28, 1.8), matPrimary);
        quilt.position.set(0, 0.5, 0.2);
        g.add(quilt);
        const pillow = new THREE.Mesh(
          new THREE.BoxGeometry(1.5, 0.22, 0.5),
          new THREE.MeshStandardMaterial({ color: '#fff9c4' })
        );
        pillow.position.set(0, 0.56, -0.8);
        g.add(pillow);
        break;
      }
      case 'beehive': {
        for (let idx of [-0.65, 0.65]) {
          const hive = new THREE.Mesh(new THREE.CylinderGeometry(0.45, 0.55, 1.0, 10), matPrimary);
          hive.position.set(idx, 0.5, 0);
          hive.castShadow = true;
          g.add(hive);
          const roof = new THREE.Mesh(new THREE.ConeGeometry(0.62, 0.45, 10), matWood);
          roof.position.set(idx, 1.2, 0);
          g.add(roof);
        }
        break;
      }
      case 'flowers': {
        for (let i = -1; i <= 1; i++) {
          const stem = new THREE.Mesh(
            new THREE.CylinderGeometry(0.06, 0.08, 1.4, 6),
            new THREE.MeshStandardMaterial({ color: '#2e7d32' })
          );
          stem.position.set(i * 0.65, 0.7, 0);
          g.add(stem);
          const head = new THREE.Mesh(new THREE.CylinderGeometry(0.38, 0.38, 0.12, 12), matPrimary);
          head.rotation.x = Math.PI / 3;
          head.position.set(i * 0.65, 1.45, 0.1);
          g.add(head);
        }
        break;
      }
      default: {
        const pedestal = new THREE.Mesh(new THREE.BoxGeometry(1.4, 1.2, 1.1), matPrimary);
        pedestal.position.y = 0.6;
        pedestal.castShadow = true;
        g.add(pedestal);
        const top = new THREE.Mesh(new THREE.CylinderGeometry(0.45, 0.45, 0.3, 12), matAccent);
        top.position.y = 1.35;
        g.add(top);
        break;
      }
    }

    if (isSelected) {
      const ring = new THREE.Mesh(
        new THREE.RingGeometry(1.15, 1.35, 24),
        new THREE.MeshBasicMaterial({ color: '#00e676', side: THREE.DoubleSide })
      );
      ring.rotation.x = -Math.PI / 2;
      ring.position.y = 0.04;
      g.add(ring);
    }

    return g;
  }

  buildCharacters(activeCharId, allCharacterStates) {
    this.clearGroup(this.charactersGroup);
    this.characterMeshes = {};

    // Place the active selected character front-and-center, plus a companion friend nearby!
    const charIds = Object.keys(CHARACTER_DEFS);
    const companionId = charIds.find((id) => id !== activeCharId) || 'bear';

    const placements = [
      { id: activeCharId, x: -0.85, z: 1.25, rotY: 0.18, isPrimary: true },
      { id: companionId, x: 1.35, z: 0.75, rotY: -0.32, isPrimary: false }
    ];

    placements.forEach((slot) => {
      const def = CHARACTER_DEFS[slot.id];
      const state = allCharacterStates[slot.id];
      if (!def || !state) return;

      const charObj = this.createArticulatedCharacter(def, state, slot.isPrimary);
      charObj.root.position.set(slot.x, 0, slot.z);
      charObj.root.rotation.y = slot.rotY;
      charObj.root.userData.charId = slot.id;
      this.charactersGroup.add(charObj.root);
      this.characterMeshes[slot.id] = charObj;
    });
  }

  createArticulatedCharacter(def, charState, isPrimary) {
    const root = new THREE.Group();
    const s = def.scale || 1.0;
    root.scale.set(s, s, s);

    const outfit = charState.outfit || def.defaultOutfit;
    const dressColor = outfit.colorVariant || def.primaryColor;

    const matSkin = new THREE.MeshStandardMaterial({ color: def.skinColor, roughness: 0.55 });
    const matOutfit = new THREE.MeshStandardMaterial({ color: dressColor, roughness: 0.5 });
    const matDark = new THREE.MeshStandardMaterial({ color: '#263238', roughness: 0.3 });

    // Torso / Dress
    const bodyGroup = new THREE.Group();
    root.add(bodyGroup);

    const torsoGeo = def.id === 'bear'
      ? new THREE.SphereGeometry(0.75, 16, 14)
      : new THREE.CylinderGeometry(0.42, 0.65, 1.15, 16);
    const torso = new THREE.Mesh(torsoGeo, matOutfit);
    torso.position.y = 0.85;
    torso.castShadow = true;
    bodyGroup.add(torso);

    // Head
    const headGroup = new THREE.Group();
    headGroup.position.y = 1.75;
    bodyGroup.add(headGroup);

    const head = new THREE.Mesh(new THREE.SphereGeometry(0.56, 18, 16), matSkin);
    head.castShadow = true;
    headGroup.add(head);

    // Character-specific Ears / Snout
    if (def.id === 'bear' || def.id === 'panda') {
      const earMat = def.id === 'panda' ? matDark : matSkin;
      [-0.42, 0.42].forEach((ex) => {
        const ear = new THREE.Mesh(new THREE.SphereGeometry(0.22, 12, 12), earMat);
        ear.position.set(ex, 0.45, 0);
        headGroup.add(ear);
      });
    } else if (def.id === 'rosie') {
      [-0.38, 0.38].forEach((ex) => {
        const ear = new THREE.Mesh(new THREE.ConeGeometry(0.18, 0.32, 8), matSkin);
        ear.position.set(ex, 0.48, 0.05);
        headGroup.add(ear);
      });
      const snout = new THREE.Mesh(
        new THREE.CylinderGeometry(0.2, 0.22, 0.16, 12),
        new THREE.MeshStandardMaterial({ color: '#f48fb1' })
      );
      snout.rotation.x = Math.PI / 2;
      snout.position.set(0, -0.05, 0.52);
      headGroup.add(snout);
    }

    // Expressive Eyes
    const leftEye = new THREE.Mesh(new THREE.SphereGeometry(0.085, 10, 10), matDark);
    leftEye.position.set(-0.2, 0.08, 0.49);
    headGroup.add(leftEye);

    const rightEye = leftEye.clone();
    rightEye.position.x = 0.2;
    headGroup.add(rightEye);

    // Smile / Mouth
    const mouth = new THREE.Mesh(
      new THREE.TorusGeometry(0.12, 0.03, 8, 12, Math.PI),
      new THREE.MeshBasicMaterial({ color: '#b71c1c' })
    );
    mouth.rotation.x = Math.PI;
    mouth.position.set(0, -0.14, 0.51);
    headGroup.add(mouth);

    // Hat / Headwear from Wardrobe
    const hatItem = WARDROBE_ITEMS.hat.find((h) => h.id === outfit.hat);
    if (hatItem && hatItem.shape !== 'none') {
      const hatMat = new THREE.MeshStandardMaterial({ color: hatItem.color || dressColor, roughness: 0.45 });
      if (hatItem.shape === 'crown') {
        const crown = new THREE.Mesh(new THREE.CylinderGeometry(0.36, 0.3, 0.28, 8), hatMat);
        crown.position.y = 0.58;
        headGroup.add(crown);
      } else if (hatItem.shape === 'wizard' || hatItem.shape === 'nightcap') {
        const cone = new THREE.Mesh(new THREE.ConeGeometry(0.42, 0.75, 12), hatMat);
        cone.position.y = 0.72;
        headGroup.add(cone);
      } else {
        const cap = new THREE.Mesh(new THREE.SphereGeometry(0.58, 14, 12, 0, Math.PI * 2, 0, Math.PI * 0.55), hatMat);
        cap.position.y = 0.04;
        headGroup.add(cap);
      }
    }

    // Accessory (Wings, Bowtie, Scarf, Glasses)
    const accItem = WARDROBE_ITEMS.accessory.find((a) => a.id === outfit.accessory);
    if (accItem && accItem.type !== 'none') {
      const accMat = new THREE.MeshStandardMaterial({ color: accItem.color || '#ffd54f', roughness: 0.4 });
      if (accItem.type === 'wings') {
        [-0.38, 0.38].forEach((wx) => {
          const wing = new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.75, 0.08), accMat);
          wing.position.set(wx, 1.0, -0.45);
          wing.rotation.y = wx > 0 ? -0.35 : 0.35;
          bodyGroup.add(wing);
        });
      } else if (accItem.type === 'glasses') {
        const shades = new THREE.Mesh(new THREE.BoxGeometry(0.68, 0.18, 0.12), accMat);
        shades.position.set(0, 0.1, 0.54);
        headGroup.add(shades);
      } else {
        const ribbon = new THREE.Mesh(new THREE.BoxGeometry(0.45, 0.18, 0.2), accMat);
        ribbon.position.set(0, 1.32, 0.42);
        bodyGroup.add(ribbon);
      }
    }

    // Arms & Shoes
    const leftArm = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.12, 0.65, 8), matSkin);
    leftArm.position.set(-0.62, 0.95, 0);
    leftArm.rotation.z = 0.35;
    bodyGroup.add(leftArm);

    const rightArm = leftArm.clone();
    rightArm.position.x = 0.62;
    rightArm.rotation.z = -0.35;
    bodyGroup.add(rightArm);

    const shoeItem = WARDROBE_ITEMS.shoes.find((sh) => sh.id === outfit.shoes);
    const shoeMat = new THREE.MeshStandardMaterial({
      color: (shoeItem && shoeItem.color) ? shoeItem.color : '#4e342e',
      roughness: 0.6
    });
    [-0.24, 0.24].forEach((lx) => {
      const foot = new THREE.Mesh(new THREE.SphereGeometry(0.19, 10, 10), shoeMat);
      foot.scale.set(1, 0.7, 1.35);
      foot.position.set(lx, 0.14, 0.08);
      bodyGroup.add(foot);
    });

    // Selection Ring under active character
    if (isPrimary) {
      const activeRing = new THREE.Mesh(
        new THREE.RingGeometry(0.68, 0.82, 24),
        new THREE.MeshBasicMaterial({ color: '#ffca28', side: THREE.DoubleSide })
      );
      activeRing.rotation.x = -Math.PI / 2;
      activeRing.position.y = 0.03;
      root.add(activeRing);
    }

    return {
      root,
      bodyGroup,
      headGroup,
      leftEye,
      rightEye,
      leftArm,
      rightArm,
      mouth,
      animPhase: Math.random() * Math.PI * 2,
      jumpVelocity: 0,
      jumpY: 0
    };
  }

  triggerCharacterJump(charId) {
    const cm = this.characterMeshes[charId];
    if (cm) {
      cm.jumpVelocity = 0.16;
    }
    this.spawnBurstParticles(cm ? cm.root.position : { x: 0, y: 1, z: 0 }, '#ffca28', 14);
  }

  spawnBurstParticles(origin, colorHex = '#ffca28', count = 14) {
    if (!this.particlesGroup) return;
    if (window.gameApp && window.gameApp.state.settings.reducedMotion) return;
    const mat = new THREE.MeshBasicMaterial({ color: colorHex });
    for (let i = 0; i < count; i++) {
      const p = new THREE.Mesh(new THREE.SphereGeometry(0.09, 6, 6), mat);
      p.position.set(
        (origin.x || 0) + (Math.random() - 0.5) * 0.6,
        (origin.y || 1) + 1.0 + Math.random() * 0.6,
        (origin.z || 0) + (Math.random() - 0.5) * 0.6
      );
      p.userData = {
        vx: (Math.random() - 0.5) * 0.08,
        vy: 0.05 + Math.random() * 0.08,
        vz: (Math.random() - 0.5) * 0.08,
        life: 1.0
      };
      this.particlesGroup.add(p);
      this.particles.push(p);
    }
  }

  updateAtmosphere(timeOfDay, weatherType) {
    if (!this.scene || !this.ambientLight || !this.dirLight) return;

    const presets = {
      day: { bg: '#87ceeb', amb: 0.72, dir: 0.88, dirCol: '#fff8e1' },
      sunset: { bg: '#ff8a65', amb: 0.58, dir: 0.75, dirCol: '#ffcc80' },
      night: { bg: '#1a237e', amb: 0.38, dir: 0.35, dirCol: '#9fa8da' }
    };
    const p = presets[timeOfDay] || presets.day;
    this.scene.background = new THREE.Color(p.bg);
    this.scene.fog.color = new THREE.Color(p.bg);
    this.ambientLight.intensity = p.amb;
    this.dirLight.intensity = p.dir;
    this.dirLight.color = new THREE.Color(p.dirCol);

    // Rebuild Weather Particles
    this.clearGroup(this.weatherGroup);
    this.weatherParticles = [];

    if (weatherType === 'sunny') return;
    if (window.gameApp && window.gameApp.state.settings.reducedMotion) return;

    const colorMap = {
      rain: '#4fc3f7',
      snow: '#ffffff',
      fireflies: '#ffee58'
    };
    const mat = new THREE.MeshBasicMaterial({ color: colorMap[weatherType] || '#ffffff' });
    const count = 42;
    for (let i = 0; i < count; i++) {
      const geo = weatherType === 'rain'
        ? new THREE.BoxGeometry(0.04, 0.32, 0.04)
        : new THREE.SphereGeometry(0.08, 6, 6);
      const m = new THREE.Mesh(geo, mat);
      m.position.set(
        (Math.random() - 0.5) * 10,
        Math.random() * 6 + 0.5,
        (Math.random() - 0.5) * 8
      );
      m.userData = {
        speedY: weatherType === 'rain' ? -0.16 : (weatherType === 'snow' ? -0.04 : 0.015),
        phase: Math.random() * Math.PI * 2
      };
      this.weatherGroup.add(m);
      this.weatherParticles.push(m);
    }
  }

  updateFrame() {
    if (!this.renderer || !this.scene || !this.camera) return;
    const dt = Math.min(0.05, this.clock.getDelta());
    const elapsed = this.clock.getElapsedTime();
    const reduced = window.gameApp && window.gameApp.state.settings.reducedMotion;

    // Smooth camera orbit follow
    const roomId = window.gameApp ? window.gameApp.state.currentRoom : 'living';
    const baseCam = (ROOM_DEFS[roomId] || ROOM_DEFS.living).cameraPos;
    const tx = baseCam.x + this.cameraTargetOffset.x;
    const ty = baseCam.y + this.cameraTargetOffset.y;
    this.camera.position.x += (tx - this.camera.position.x) * 0.08;
    this.camera.position.y += (ty - this.camera.position.y) * 0.08;
    this.camera.lookAt(this.cameraTargetOffset.x * 0.35, 1.15, 0);

    // Animate 3D characters (breathing, blinking, waving, jumping)
    Object.entries(this.characterMeshes).forEach(([id, cm]) => {
      if (!cm || !cm.bodyGroup) return;
      cm.animPhase += dt * 3.2;

      if (!reduced) {
        cm.bodyGroup.position.y = Math.abs(Math.sin(cm.animPhase)) * 0.06 + cm.jumpY;
        cm.headGroup.rotation.z = Math.sin(cm.animPhase * 0.6) * 0.06;
        cm.leftArm.rotation.z = 0.35 + Math.sin(cm.animPhase * 1.4) * 0.15;
        cm.rightArm.rotation.z = -0.35 - Math.cos(cm.animPhase * 1.4) * 0.15;
      }

      if (cm.jumpVelocity !== 0 || cm.jumpY > 0) {
        cm.jumpY += cm.jumpVelocity;
        cm.jumpVelocity -= 0.014;
        if (cm.jumpY <= 0) {
          cm.jumpY = 0;
          cm.jumpVelocity = 0;
        }
      }

      // Periodic eye blink
      const blink = Math.sin(elapsed * 2.3 + cm.animPhase) > 0.96 ? 0.15 : 1.0;
      cm.leftEye.scale.y = blink;
      cm.rightEye.scale.y = blink;
    });

    // Update burst particles
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.position.x += p.userData.vx;
      p.position.y += p.userData.vy;
      p.position.z += p.userData.vz;
      p.userData.vy -= 0.004;
      p.userData.life -= 0.03;
      p.scale.setScalar(Math.max(0.01, p.userData.life));
      if (p.userData.life <= 0) {
        this.particlesGroup.remove(p);
        this.particles.splice(i, 1);
      }
    }

    // Update weather particles
    this.weatherParticles.forEach((wp) => {
      wp.position.y += wp.userData.speedY;
      wp.position.x += Math.sin(elapsed * 2 + wp.userData.phase) * 0.01;
      if (wp.position.y < 0.2) wp.position.y = 6.2;
      if (wp.position.y > 6.5) wp.position.y = 0.5;
    });

    this.renderer.render(this.scene, this.camera);
  }
}
