/**
 * আল-কারীম পুকুর ম্যানেজমেন্ট - লোকাল স্টোরেজ ডেটাবেস ইঞ্জিন
 * LocalStorage Persistence Engine with Soft-Delete / Recycle Bin
 */

const STORAGE_PREFIX = 'alkarim_pond_';

const initialDemoData = {
  farmSettings: {
    farmName: 'আল-কারীম ফিশারিজ ও মৎস্য খামার',
    tagline: 'সঠিক ব্যবস্থাপনায় সফল মৎস্য চাষ',
    ownerName: 'মাওলানা রফিকুল ইসলাম',
    mobile: '০১৭১১-২২৩৩৪৪',
    address: 'গ্রাম: চর-কালিদাসপুর, থানা: ঈশ্বরদী, জেলা: পাবনা',
    currencySymbol: '৳'
  },
  ponds: [
    {
      id: 'pond_1',
      name: 'পুকুর ১ - উত্তর দীঘি',
      number: 'P-101',
      area: 60,
      unit: 'শতাংশ',
      depth: 6.5,
      location: 'খামারের উত্তর প্রান্ত',
      manager: 'মোঃ শরিফুল ইসলাম',
      fishType: 'রুই, কাতলা, মৃগেল (কার্প মিশ্র)',
      releaseDate: '2026-06-10',
      fishCount: 4500,
      status: 'সক্রিয়',
      note: 'চুন ও সার দিয়ে ভালোভাবে প্রস্তুতকৃত পুকুর।'
    },
    {
      id: 'pond_2',
      name: 'পুকুর ২ - পূর্ব পুকুর',
      number: 'P-102',
      area: 45,
      unit: 'শতাংশ',
      depth: 5.0,
      location: 'প্রধান কার্যালয়ের পূর্ব পার্শ্ব',
      manager: 'আব্দুল করিম মিয়া',
      fishType: 'মনোসেক্স তেলাপিয়া ও গুলশা',
      releaseDate: '2026-07-01',
      fishCount: 6000,
      status: 'সক্রিয়',
      note: 'বাণিজ্যিক তেলাপিয়া প্রকল্প।'
    },
    {
      id: 'pond_3',
      name: 'পুকুর ৩ - দক্ষিণ নার্সারি',
      number: 'P-103',
      area: 25,
      unit: 'শতাংশ',
      depth: 4.0,
      location: 'দক্ষিণ গেটের পাশে',
      manager: 'আলহাজ্ব মো: কামরুল হাসান',
      fishType: 'পাঙ্গাস ও সিলভার কার্প',
      releaseDate: '2026-08-05',
      fishCount: 3500,
      status: 'সক্রিয়',
      note: 'পোনা লালন-পালন পুকুর।'
    }
  ],
  members: [
    {
      id: 'mem_1',
      memberId: 'AK-001',
      name: 'মাওলানা রফিকুল ইসলাম',
      fatherName: 'মরহুম আব্দুল খালেক',
      mobile: '০১৭১১-২২৩৩৪৪',
      address: 'ঈশ্বরদী, পাবনা',
      shareCount: 4,
      depositAmount: 400000,
      joinDate: '2026-01-15',
      note: 'মূল প্রতিষ্ঠাতা ও প্রধান পরিচালক।'
    },
    {
      id: 'mem_2',
      memberId: 'AK-002',
      name: 'আলহাজ্ব মো: কামরুল হাসান',
      fatherName: 'হাজী মোঃ মহসিন আলী',
      mobile: '০১৭২২-৩৩৪৪৫৫',
      address: 'পাবনা সদর',
      shareCount: 3,
      depositAmount: 300000,
      joinDate: '2026-01-20',
      note: 'শেয়ারহোল্ডার ও পরামর্শক।'
    },
    {
      id: 'mem_3',
      memberId: 'AK-003',
      name: 'আব্দুল করিম মিয়া',
      fatherName: 'মোঃ শফিউল্লাহ',
      mobile: '০১৮১২-৩৪৫৬৭৮',
      address: 'রূপপুর, পাবনা',
      shareCount: 2,
      depositAmount: 200000,
      joinDate: '2026-02-01',
      note: 'খামার তত্ত্বাবধায়ক ও সদস্য।'
    },
    {
      id: 'mem_4',
      memberId: 'AK-004',
      name: 'মোঃ শরিফুল ইসলাম',
      fatherName: 'মোঃ আব্দুল মান্নান',
      mobile: '০১৯১১-৮৮৭৭৬৬',
      address: 'পাকশী, পাবনা',
      shareCount: 1,
      depositAmount: 100000,
      joinDate: '2026-03-10',
      note: 'সদস্য ও ক্ষেত্র পরিদর্শক।'
    }
  ],
  feedStock: [
    {
      id: 'fs_1',
      date: '2026-09-01',
      feedName: 'মেগা ফ্লোটিং ফিড (ভাসা)',
      feedType: 'ভাসা',
      brand: 'মেগা ফিড লিমিটেড',
      totalKg: 1000,
      totalSacks: 20,
      kgPerSack: 50,
      ratePerKg: 78,
      totalPrice: 78000,
      supplier: 'পাবনা মৎস্য ফিড সেন্টার',
      invoiceNo: 'MF-8841',
      note: '২৮% প্রোটিন যুক্ত প্রিমিয়াম গ্রোয়ার খাবার।'
    },
    {
      id: 'fs_2',
      date: '2026-09-05',
      feedName: 'আফতাব কার্প স্টার্টার (ডুবন্ত)',
      feedType: 'ডুবন্ত',
      brand: 'আফতাব ফিড মিলস',
      totalKg: 750,
      totalSacks: 15,
      kgPerSack: 50,
      ratePerKg: 65,
      totalPrice: 48750,
      supplier: 'মেসার্স ভাই ভাই ট্রেডার্স',
      invoiceNo: 'AB-2039',
      note: 'কার্প ও মিশ্র মাছের জন্য দ্রুত বর্ধনশীল খাদ্য।'
    }
  ],
  dailyFeed: [
    {
      id: 'df_1',
      date: '2026-09-10',
      pondId: 'pond_1',
      pondName: 'পুকুর ১ - উত্তর দীঘি',
      time: 'সকাল',
      feedType: 'ভাসা',
      feedName: 'মেগা ফ্লোটিং ফিড',
      brand: 'মেগা ফিড',
      amountKg: 25,
      ratePerKg: 78,
      totalPrice: 1950,
      fedBy: 'মোঃ শরিফুল',
      note: 'মাছের স্বাভাবিক খাদ্য গ্রহণ দেখা গেছে।'
    },
    {
      id: 'df_2',
      date: '2026-09-10',
      pondId: 'pond_2',
      pondName: 'পুকুর ২ - পূর্ব পুকুর',
      time: 'সকাল',
      feedType: 'ভাসা',
      feedName: 'মেগা ফ্লোটিং ফিড',
      brand: 'মেগা ফিড',
      amountKg: 20,
      ratePerKg: 78,
      totalPrice: 1560,
      fedBy: 'আব্দুল করিম',
      note: 'সকাল ৭:৩০ মিনিটে খাদ্য দেওয়া হয়েছে।'
    },
    {
      id: 'df_3',
      date: '2026-09-10',
      pondId: 'pond_1',
      pondName: 'পুকুর ১ - উত্তর দীঘি',
      time: 'বিকাল',
      feedType: 'ডুবন্ত',
      feedName: 'আফতাব কার্প স্টার্টার',
      brand: 'আফতাব ফিড',
      amountKg: 20,
      ratePerKg: 65,
      totalPrice: 1300,
      fedBy: 'মোঃ শরিফুল',
      note: 'বিকাল ৫:০০ টায় ডুবন্ত ফিড।'
    },
    {
      id: 'df_4',
      date: '2026-09-11',
      pondId: 'pond_2',
      pondName: 'পুকুর ২ - পূর্ব পুকুর',
      time: 'সকাল',
      feedType: 'ভাসা',
      feedName: 'মেগা ফ্লোটিং ফিড',
      brand: 'মেগা ফিড',
      amountKg: 22,
      ratePerKg: 78,
      totalPrice: 1716,
      fedBy: 'আব্দুল করিম',
      note: 'তেলাপিয়া মাছের খাদ্য গ্রহণ চমৎকার।'
    },
    {
      id: 'df_5',
      date: '2026-09-11',
      pondId: 'pond_3',
      pondName: 'পুকুর ৩ - দক্ষিণ নার্সারি',
      time: 'সকাল',
      feedType: 'ভাসা',
      feedName: 'মেগা ফ্লোটিং ফিড',
      brand: 'মেগা ফিড',
      amountKg: 15,
      ratePerKg: 78,
      totalPrice: 1170,
      fedBy: 'কামরুল হাসান',
      note: 'পাঙ্গাস মাছের জন্য খাদ্য বিতরণ।'
    }
  ],
  expenses: [
    {
      id: 'exp_1',
      date: '2026-09-02',
      pondId: 'pond_1',
      pondName: 'পুকুর ১ - উত্তর দীঘি',
      category: 'শ্রমিক',
      description: 'পুকুর পাড় পরিষ্কার ও জাল টানা শ্রমিক মজুরি',
      amount: 4,
      totalMoney: 3200,
      payee: 'শ্রমিক সর্দার মোকাদ্দেস',
      voucherNo: 'V-101',
      note: '৪ জন শ্রমিক সারাদিন কাজ করেছে।'
    },
    {
      id: 'exp_2',
      date: '2026-09-04',
      pondId: 'pond_2',
      pondName: 'পুকুর ২ - পূর্ব পুকুর',
      category: 'ঔষধ',
      description: 'জীবাণুনাশক ও পটাশিয়াম পারম্যাঙ্গানেট প্রয়োগ',
      amount: 1,
      totalMoney: 2400,
      payee: 'কৃষি ও মৎস্য মেডিসিন ঘর',
      voucherNo: 'V-102',
      note: 'পানি শোধন ও রোগ প্রতিরোধক হিসেবে প্রয়োগ।'
    },
    {
      id: 'exp_3',
      date: '2026-09-06',
      pondId: 'all',
      pondName: 'সকল পুকুর (সাধারণ)',
      category: 'বিদ্যুৎ',
      description: 'খামারের পানির পাম্প ও নাইট লাইটের বিদ্যুৎ বিল',
      amount: 1,
      totalMoney: 5800,
      payee: 'পল্লী বিদ্যুৎ সমিতি ঈশ্বরদী',
      voucherNo: 'E-4501',
      note: 'আগস্ট মাসের বিদ্যুৎ বিল পরিশোধ।'
    },
    {
      id: 'exp_4',
      date: '2026-09-08',
      pondId: 'pond_3',
      pondName: 'পুকুর ৩ - দক্ষিণ নার্সারি',
      category: 'পুকুর সংস্কার',
      description: 'দক্ষিণ পাড় মাটি ফেলে মেরামত ও জাল স্থাপন',
      amount: 1,
      totalMoney: 4500,
      payee: 'হবিবুর রহমান',
      voucherNo: 'V-103',
      note: 'বৃষ্টির কারণে ভাঙা পাড় মেরামত করা হলো।'
    }
  ],
  fishBuy: [
    {
      id: 'fb_1',
      date: '2026-06-10',
      pondId: 'pond_1',
      pondName: 'পুকুর ১ - উত্তর দীঘি',
      fishType: 'রুই ও কাতলা পোনা',
      sizeAge: '৪-৫ ইঞ্চি',
      count: 4500,
      totalWeight: 350,
      ratePerKg: 280,
      totalPrice: 98000,
      seller: 'মায়ের দোয়া হ্যাচারি, নাটোর',
      note: 'উন্নত জাতের নিরোগ সবল পোনা।'
    },
    {
      id: 'fb_2',
      date: '2026-07-01',
      pondId: 'pond_2',
      pondName: 'পুকুর ২ - পূর্ব পুকুর',
      fishType: 'মনোসেক্স তেলাপিয়া পোনা',
      sizeAge: '২ ইঞ্চি',
      count: 6000,
      totalWeight: 120,
      ratePerKg: 350,
      totalPrice: 42000,
      seller: 'পদ্মা হ্যাচারি, ঈশ্বরদী',
      note: 'শতভাগ পুরুষ মনোসেক্স তেলাপিয়া পোনা।'
    },
    {
      id: 'fb_3',
      date: '2026-08-05',
      pondId: 'pond_3',
      pondName: 'পুকুর ৩ - দক্ষিণ নার্সারি',
      fishType: 'পাঙ্গাস পোনা',
      sizeAge: '৩ ইঞ্চি',
      count: 3500,
      totalWeight: 150,
      ratePerKg: 220,
      totalPrice: 33000,
      seller: 'যমুনা একোয়া সিড',
      note: 'থাই পাঙ্গাস জাত।'
    }
  ],
  fishSell: [
    {
      id: 'fsell_1',
      date: '2026-09-08',
      pondId: 'pond_2',
      pondName: 'পুকুর ২ - পূর্ব পুকুর',
      fishType: 'তেলাপিয়া মাছ (প্রথম লট)',
      count: 850,
      totalWeight: 420,
      ratePerKg: 190,
      totalPrice: 79800,
      buyerName: 'আলমগীর হোসেন (পাইকার)',
      buyerMobile: '০১৭৩৩-৯৯৮৮৭৭',
      note: 'পুকুর থেকে সরাসরি জ্যান্ত মাছ বিক্রি।'
    },
    {
      id: 'fsell_2',
      date: '2026-09-10',
      pondId: 'pond_1',
      pondName: 'পুকুর ১ - উত্তর দীঘি',
      fishType: 'বড় রুই ও কাতলা নমুনা বিক্রি',
      count: 120,
      totalWeight: 260,
      ratePerKg: 320,
      totalPrice: 83200,
      buyerName: 'মেসার্স মদিনা ফিশ আড়ৎ',
      buyerMobile: '০১৮১১-১২৩৪৫৬',
      note: 'বড় আকারের রুই মাছ পাইকারি বিক্রয়।'
    }
  ],
  deadFish: [
    {
      id: 'dfish_1',
      date: '2026-07-15',
      pondId: 'pond_1',
      pondName: 'পুকুর ১ - উত্তর দীঘি',
      fishType: 'রুই পোনা',
      count: 45,
      estimatedWeight: 4.5,
      cause: 'তীব্র গরম ও পরিবহন ক্লান্তি',
      note: 'পোনা ছাড়ার প্রাথমিক ধাক্কায় কিছু পোনা মারা যায়।'
    },
    {
      id: 'dfish_2',
      date: '2026-08-20',
      pondId: 'pond_2',
      pondName: 'পুকুর ২ - পূর্ব পুকুর',
      fishType: 'তেলাপিয়া',
      count: 30,
      estimatedWeight: 6.0,
      cause: 'রাতের বেলা সাময়িক অক্সিজেন স্বল্পতা',
      note: 'এয়ারেটর ও পানি পরিবর্তন করে সমস্যা সমাধান করা হয়।'
    }
  ],
  recycleBin: []
};

class PondDatabase {
  constructor() {
    this.init();
  }

  init() {
    // Check if db already initialized
    const isInitialized = localStorage.getItem(STORAGE_PREFIX + 'initialized');
    if (!isInitialized) {
      this.loadDemoData();
    } else {
      // Ensure all standard tables exist safely without crash
      this._ensureDefaultStructure();
    }
  }

  _canonicalTable(table) {
    if (table === 'fishPurchases') return 'fishBuy';
    if (table === 'fishSales') return 'fishSell';
    if (table === 'mortality') return 'deadFish';
    if (table === 'settings') return 'farmSettings';
    return table;
  }

  _altTable(table) {
    if (table === 'fishBuy') return 'fishPurchases';
    if (table === 'fishSell') return 'fishSales';
    if (table === 'deadFish') return 'mortality';
    if (table === 'farmSettings') return 'settings';
    return null;
  }

  _ensureDefaultStructure() {
    const requiredArrays = ['ponds', 'members', 'feedStock', 'dailyFeed', 'expenses', 'fishBuy', 'fishSell', 'deadFish', 'recycleBin'];
    requiredArrays.forEach(tbl => {
      try {
        const raw = localStorage.getItem(STORAGE_PREFIX + tbl);
        if (!raw) {
          localStorage.setItem(STORAGE_PREFIX + tbl, JSON.stringify([]));
        } else {
          const parsed = JSON.parse(raw);
          if (!Array.isArray(parsed)) {
            localStorage.setItem(STORAGE_PREFIX + tbl, JSON.stringify([]));
          }
        }
      } catch (e) {
        console.warn(`Recovered table ${tbl} due to parse error`, e);
        localStorage.setItem(STORAGE_PREFIX + tbl, JSON.stringify([]));
      }
    });

    // Also sync alias keys
    ['fishPurchases', 'fishSales', 'mortality'].forEach(alias => {
      const canonical = this._canonicalTable(alias);
      try {
        const raw = localStorage.getItem(STORAGE_PREFIX + canonical);
        if (raw) localStorage.setItem(STORAGE_PREFIX + alias, raw);
      } catch (e) {}
    });

    // Ensure settings
    try {
      const rawSettings = localStorage.getItem(STORAGE_PREFIX + 'farmSettings');
      if (!rawSettings) {
        localStorage.setItem(STORAGE_PREFIX + 'farmSettings', JSON.stringify(initialDemoData.farmSettings));
        localStorage.setItem(STORAGE_PREFIX + 'settings', JSON.stringify(initialDemoData.farmSettings));
      }
    } catch (e) {
      localStorage.setItem(STORAGE_PREFIX + 'farmSettings', JSON.stringify(initialDemoData.farmSettings));
      localStorage.setItem(STORAGE_PREFIX + 'settings', JSON.stringify(initialDemoData.farmSettings));
    }
  }

  loadDemoData() {
    Object.keys(initialDemoData).forEach(key => {
      localStorage.setItem(STORAGE_PREFIX + key, JSON.stringify(initialDemoData[key]));
    });
    // Write alias keys
    localStorage.setItem(STORAGE_PREFIX + 'fishPurchases', JSON.stringify(initialDemoData.fishBuy || []));
    localStorage.setItem(STORAGE_PREFIX + 'fishSales', JSON.stringify(initialDemoData.fishSell || []));
    localStorage.setItem(STORAGE_PREFIX + 'mortality', JSON.stringify(initialDemoData.deadFish || []));
    localStorage.setItem(STORAGE_PREFIX + 'settings', JSON.stringify(initialDemoData.farmSettings));
    localStorage.setItem(STORAGE_PREFIX + 'initialized', 'true');
  }

  resetData() {
    const emptyState = {
      farmSettings: {
        farmName: 'আল-কারীম ফিশারিজ ও মৎস্য খামার',
        tagline: 'সঠিক ব্যবস্থাপনায় সফল মৎস্য চাষ',
        ownerName: '',
        mobile: '',
        address: '',
        currencySymbol: '৳'
      },
      ponds: [],
      members: [],
      feedStock: [],
      dailyFeed: [],
      expenses: [],
      fishBuy: [],
      fishSell: [],
      deadFish: [],
      recycleBin: []
    };
    Object.keys(emptyState).forEach(key => {
      localStorage.setItem(STORAGE_PREFIX + key, JSON.stringify(emptyState[key]));
    });
    localStorage.setItem(STORAGE_PREFIX + 'fishPurchases', JSON.stringify([]));
    localStorage.setItem(STORAGE_PREFIX + 'fishSales', JSON.stringify([]));
    localStorage.setItem(STORAGE_PREFIX + 'mortality', JSON.stringify([]));
    localStorage.setItem(STORAGE_PREFIX + 'settings', JSON.stringify(emptyState.farmSettings));
    localStorage.setItem(STORAGE_PREFIX + 'initialized', 'true');
  }

  getAll(table) {
    try {
      const canonical = this._canonicalTable(table);
      let data = localStorage.getItem(STORAGE_PREFIX + canonical);
      if (!data && canonical !== table) {
        data = localStorage.getItem(STORAGE_PREFIX + table);
      }
      if (data) {
        const parsed = JSON.parse(data);
        if (Array.isArray(parsed)) return parsed;
      }
      // If table missing or invalid, initialize as empty array
      const emptyArr = [];
      localStorage.setItem(STORAGE_PREFIX + canonical, JSON.stringify(emptyArr));
      return emptyArr;
    } catch (e) {
      console.error('Error reading table ' + table, e);
      try {
        const canonical = this._canonicalTable(table);
        localStorage.setItem(STORAGE_PREFIX + canonical, JSON.stringify([]));
      } catch (err) {}
      return [];
    }
  }

  getById(table, id) {
    const items = this.getAll(table);
    return items.find(item => item.id === id) || null;
  }

  insert(table, item) {
    const canonical = this._canonicalTable(table);
    const alt = this._altTable(canonical);
    const items = this.getAll(canonical);
    if (!item.id) {
      const prefix = canonical.replace(/[^a-zA-Z]/g, '').substring(0, 3) || 'rec';
      item.id = prefix + '_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5);
    }
    item.createdAt = item.createdAt || new Date().toISOString();
    items.unshift(item);
    
    // Save to primary table
    localStorage.setItem(STORAGE_PREFIX + canonical, JSON.stringify(items));
    // Save to alt table
    if (alt) {
      localStorage.setItem(STORAGE_PREFIX + alt, JSON.stringify(items));
    }
    return item;
  }

  update(table, id, updatedFields) {
    const canonical = this._canonicalTable(table);
    const alt = this._altTable(canonical);
    const items = this.getAll(canonical);
    const index = items.findIndex(item => item.id === id);
    if (index !== -1) {
      items[index] = { ...items[index], ...updatedFields, updatedAt: new Date().toISOString() };
      localStorage.setItem(STORAGE_PREFIX + canonical, JSON.stringify(items));
      if (alt) {
        localStorage.setItem(STORAGE_PREFIX + alt, JSON.stringify(items));
      }
      return items[index];
    }
    return null;
  }

  // Soft delete into recycleBin
  softDelete(table, id) {
    const canonical = this._canonicalTable(table);
    const alt = this._altTable(canonical);
    const items = this.getAll(canonical);
    const index = items.findIndex(item => item.id === id);
    if (index === -1) return false;

    const itemToDelete = items[index];
    items.splice(index, 1);
    localStorage.setItem(STORAGE_PREFIX + canonical, JSON.stringify(items));
    if (alt) {
      localStorage.setItem(STORAGE_PREFIX + alt, JSON.stringify(items));
    }

    // Add to recycle bin
    const recycleBin = this.getAll('recycleBin');
    const binItem = {
      id: 'bin_' + Date.now(),
      originalTable: canonical,
      originalId: itemToDelete.id,
      title: itemToDelete.name || itemToDelete.feedName || itemToDelete.fishType || itemToDelete.description || 'আইটেম',
      summary: this._getItemSummary(canonical, itemToDelete),
      itemData: itemToDelete,
      deletedAt: new Date().toISOString()
    };
    recycleBin.unshift(binItem);
    localStorage.setItem(STORAGE_PREFIX + 'recycleBin', JSON.stringify(recycleBin));
    return true;
  }

  restoreFromBin(binId) {
    const binItems = this.getAll('recycleBin');
    const index = binItems.findIndex(i => i.id === binId);
    if (index === -1) return false;

    const binItem = binItems[index];
    const targetTable = binItem.originalTable;
    const itemData = binItem.itemData;

    // Restore to table
    const tableItems = this.getAll(targetTable);
    tableItems.unshift(itemData);
    localStorage.setItem(STORAGE_PREFIX + targetTable, JSON.stringify(tableItems));

    // Remove from bin
    binItems.splice(index, 1);
    localStorage.setItem(STORAGE_PREFIX + 'recycleBin', JSON.stringify(binItems));
    return true;
  }

  permanentDeleteFromBin(binId) {
    const binItems = this.getAll('recycleBin');
    const filtered = binItems.filter(i => i.id !== binId);
    localStorage.setItem(STORAGE_PREFIX + 'recycleBin', JSON.stringify(filtered));
    return true;
  }

  clearRecycleBin() {
    localStorage.setItem(STORAGE_PREFIX + 'recycleBin', JSON.stringify([]));
    return true;
  }

  _getItemSummary(table, item) {
    switch (table) {
      case 'ponds': return `আয়তন: ${item.area} ${item.unit} | পোনা: ${item.fishCount}`;
      case 'members': return `আইডি: ${item.memberId} | শেয়ার: ${item.shareCount}`;
      case 'feedStock': return `পরিমাণ: ${item.totalKg} কেজি (${item.totalSacks} বস্তা) | মূল্য: ৳${item.totalPrice}`;
      case 'dailyFeed': return `পুকুর: ${item.pondName} | খাদ্য: ${item.amountKg} কেজি | খরচ: ৳${item.totalPrice}`;
      case 'expenses': return `ধরন: ${item.category} | টাকা: ৳${item.totalMoney}`;
      case 'fishBuy': return `পোনা: ${item.count} টি | মোট দাম: ৳${item.totalPrice}`;
      case 'fishSell': return `ওজন: ${item.totalWeight} কেজি | বিক্রয় মূল্য: ৳${item.totalPrice}`;
      case 'deadFish': return `সংখ্যা: ${item.count} টি | কারণ: ${item.cause}`;
      default: return '';
    }
  }

  getSettings() {
    try {
      const data = localStorage.getItem(STORAGE_PREFIX + 'farmSettings');
      return data ? JSON.parse(data) : initialDemoData.farmSettings;
    } catch (e) {
      return initialDemoData.farmSettings;
    }
  }

  updateSettings(newSettings) {
    localStorage.setItem(STORAGE_PREFIX + 'farmSettings', JSON.stringify(newSettings));
    return newSettings;
  }

  exportData() {
    const exportObj = {
      version: '1.0',
      appName: 'আল-কারীম পুকুর ম্যানেজমেন্ট',
      exportedAt: new Date().toISOString(),
      farmSettings: this.getSettings(),
      ponds: this.getAll('ponds'),
      members: this.getAll('members'),
      feedStock: this.getAll('feedStock'),
      dailyFeed: this.getAll('dailyFeed'),
      expenses: this.getAll('expenses'),
      fishBuy: this.getAll('fishBuy'),
      fishSell: this.getAll('fishSell'),
      deadFish: this.getAll('deadFish'),
      recycleBin: this.getAll('recycleBin')
    };
    return JSON.stringify(exportObj, null, 2);
  }

  importData(jsonString) {
    try {
      const parsed = JSON.parse(jsonString);
      if (!parsed.version && !parsed.ponds) {
        throw new Error('অবৈধ ব্যাকআপ ফাইল ফরম্যাট।');
      }

      const tables = ['farmSettings', 'ponds', 'members', 'feedStock', 'dailyFeed', 'expenses', 'fishBuy', 'fishSell', 'deadFish', 'recycleBin'];
      tables.forEach(table => {
        if (parsed[table]) {
          localStorage.setItem(STORAGE_PREFIX + table, JSON.stringify(parsed[table]));
        }
      });
      localStorage.setItem(STORAGE_PREFIX + 'initialized', 'true');
      return true;
    } catch (err) {
      console.error('Import error:', err);
      return false;
    }
  }

  getDashboardStats() {
    const ponds = this.getAll('ponds');
    const members = this.getAll('members');
    const feedStock = this.getAll('feedStock');
    const dailyFeed = this.getAll('dailyFeed');
    const expenses = this.getAll('expenses');
    const fishBuy = this.getAll('fishBuy');
    const fishSell = this.getAll('fishSell');
    const deadFish = this.getAll('deadFish');

    // Feed Stock remaining calculation
    const totalPurchasedFeedKg = feedStock.reduce((acc, f) => acc + (parseFloat(f.totalKg) || 0), 0);
    const totalPurchasedFeedSacks = feedStock.reduce((acc, f) => acc + (parseFloat(f.totalSacks) || 0), 0);
    const totalFedKg = dailyFeed.reduce((acc, f) => acc + (parseFloat(f.amountKg) || 0), 0);
    const remainingFeedKg = Math.max(0, totalPurchasedFeedKg - totalFedKg);
    const remainingFeedSacks = Math.max(0, totalPurchasedFeedSacks - Math.floor(totalFedKg / 50));

    // Expenses: General expenses + Fish fingerling buy + Feed stock buy
    const generalExpensesTotal = expenses.reduce((acc, e) => acc + (parseFloat(e.totalMoney) || 0), 0);
    const fishBuyTotal = fishBuy.reduce((acc, fb) => acc + (parseFloat(fb.totalPrice) || 0), 0);
    const feedStockBuyTotal = feedStock.reduce((acc, fs) => acc + (parseFloat(fs.totalPrice) || 0), 0);
    const totalExpenses = generalExpensesTotal + fishBuyTotal + feedStockBuyTotal;

    // Income: Fish sales + other receipts
    const totalFishSales = fishSell.reduce((acc, s) => acc + (parseFloat(s.totalPrice) || 0), 0);
    const totalIncome = totalFishSales;

    // Profit / Loss
    const netProfit = totalIncome - totalExpenses;

    // Fish stock count
    const totalFishBought = fishBuy.reduce((acc, fb) => acc + (parseInt(fb.count) || 0), 0);
    const pondInitialFish = ponds.reduce((acc, p) => acc + (parseInt(p.fishCount) || 0), 0);
    const totalFishDead = deadFish.reduce((acc, df) => acc + (parseInt(df.count) || 0), 0);
    const totalFishSold = fishSell.reduce((acc, fs) => acc + (parseInt(fs.count) || 0), 0);
    const estimatedFishInPonds = Math.max(0, (pondInitialFish + totalFishBought) - (totalFishDead + totalFishSold));

    // Member deposits
    const totalMemberDeposits = members.reduce((acc, m) => acc + (parseFloat(m.depositAmount) || 0), 0);
    const totalShares = members.reduce((acc, m) => acc + (parseInt(m.shareCount) || 0), 0);

    return {
      totalPonds: ponds.length,
      totalMembers: members.length,
      remainingFeedKg,
      remainingFeedSacks,
      totalFedKg,
      totalExpenses,
      generalExpensesTotal,
      fishBuyTotal,
      feedStockBuyTotal,
      totalIncome,
      netProfit,
      estimatedFishInPonds,
      totalFishDead,
      totalFishSold,
      totalMemberDeposits,
      totalShares
    };
  }

  getRecentActivities(limit = 6) {
    const activities = [];

    this.getAll('ponds').forEach(p => {
      activities.push({
        title: `নতুন পুকুর যুক্ত হয়েছে: ${p.name}`,
        time: p.createdAt || p.releaseDate,
        date: p.releaseDate || p.createdAt,
        type: 'pond',
        icon: '🐟',
        badgeClass: 'success'
      });
    });

    this.getAll('members').forEach(m => {
      activities.push({
        title: `নতুন সদস্য যোগ হয়েছে: ${m.name} (${m.shareCount} শেয়ার)`,
        time: m.createdAt || m.joinDate,
        date: m.joinDate || m.createdAt,
        type: 'member',
        icon: '👥',
        badgeClass: 'info'
      });
    });

    this.getAll('feedStock').forEach(f => {
      activities.push({
        title: `খাদ্য স্টকে যোগ হয়েছে: ${f.feedName} (${f.totalKg} কেজি)`,
        time: f.createdAt || f.date,
        date: f.date,
        type: 'feed',
        icon: '🌾',
        badgeClass: 'warning'
      });
    });

    this.getAll('dailyFeed').forEach(df => {
      activities.push({
        title: `দৈনিক খাদ্য প্রদান: ${df.pondName}-এ ${df.amountKg} কেজি`,
        time: df.createdAt || df.date,
        date: df.date,
        type: 'daily_feed',
        icon: '🍚',
        badgeClass: 'primary'
      });
    });

    this.getAll('expenses').forEach(e => {
      activities.push({
        title: `খরচ লিপিবদ্ধ হয়েছে: ${e.category} (৳${e.totalMoney})`,
        time: e.createdAt || e.date,
        date: e.date,
        type: 'expense',
        icon: '💰',
        badgeClass: 'danger'
      });
    });

    this.getAll('fishSell').forEach(fs => {
      activities.push({
        title: `মাছ বিক্রি হয়েছে: ৳${fs.totalPrice} (${fs.totalWeight} কেজি)`,
        time: fs.createdAt || fs.date,
        date: fs.date,
        type: 'sale',
        icon: '💵',
        badgeClass: 'success'
      });
    });

    this.getAll('deadFish').forEach(df => {
      activities.push({
        title: `মৃত মাছ রেকর্ড: ${df.pondName}-এ ${df.count} টি`,
        time: df.createdAt || df.date,
        date: df.date,
        type: 'dead',
        icon: '☠️',
        badgeClass: 'danger'
      });
    });

    // Sort by date descending
    activities.sort((a, b) => new Date(b.date || b.time || 0) - new Date(a.date || a.time || 0));
    return activities.slice(0, limit);
  }

  getPondReport(pondId) {
    const pond = this.getById('ponds', pondId);
    if (!pond) return null;

    const feeds = this.getAll('dailyFeed').filter(f => f.pondId === pondId);
    const feedKg = feeds.reduce((acc, f) => acc + (parseFloat(f.amountKg) || 0), 0);
    const feedCost = feeds.reduce((acc, f) => acc + (parseFloat(f.totalPrice) || 0), 0);

    const fishBuys = this.getAll('fishBuy').filter(b => b.pondId === pondId);
    const fishBuyCost = fishBuys.reduce((acc, b) => acc + (parseFloat(b.totalPrice) || 0), 0);
    const fishBuyCount = fishBuys.reduce((acc, b) => acc + (parseInt(b.count) || 0), 0);

    const fishSells = this.getAll('fishSell').filter(s => s.pondId === pondId);
    const fishSaleIncome = fishSells.reduce((acc, s) => acc + (parseFloat(s.totalPrice) || 0), 0);
    const fishSaleWeight = fishSells.reduce((acc, s) => acc + (parseFloat(s.totalWeight) || 0), 0);
    const fishSaleCount = fishSells.reduce((acc, s) => acc + (parseInt(s.count) || 0), 0);

    const deadFishList = this.getAll('deadFish').filter(d => d.pondId === pondId);
    const deadCount = deadFishList.reduce((acc, d) => acc + (parseInt(d.count) || 0), 0);

    const otherExpenses = this.getAll('expenses').filter(e => e.pondId === pondId);
    const otherExpenseTotal = otherExpenses.reduce((acc, e) => acc + (parseFloat(e.totalMoney) || 0), 0);

    const totalPondExpense = feedCost + fishBuyCost + otherExpenseTotal;
    const pondNetProfit = fishSaleIncome - totalPondExpense;

    return {
      pond,
      feedKg,
      feedCost,
      fishBuyCount,
      fishBuyCost,
      fishSaleCount,
      fishSaleWeight,
      fishSaleIncome,
      deadCount,
      otherExpenseTotal,
      totalPondExpense,
      pondNetProfit
    };
  }
}

// Export singleton instance
window.db = new PondDatabase();
