// db.js - Complete IndexedDB Storage for School Management System
// Government Boys Primary School Sultan Matt Uchari (EMIS: 06994)

const DB_NAME = 'SchoolManagementDB';
const DB_VERSION = 1;

const DEFAULT_CLASSES = [
  { id: 1, name: 'Kachi', section: 'A', room: 'Room 1' },
  { id: 2, name: 'Pakki Class', section: 'A', room: 'Room 2' },
  { id: 3, name: 'Class 1', section: 'A', room: 'Room 3' },
  { id: 4, name: 'Class 2', section: 'A', room: 'Room 4' },
  { id: 5, name: 'Class 3', section: 'A', room: 'Room 5' },
  { id: 6, name: 'Class 4', section: 'A', room: 'Room 6' },
  { id: 7, name: 'Class 5', section: 'A', room: 'Room 7' }
];

const DEFAULT_SUBJECTS = [
  { id: 1, name: 'Urdu', totalMarks: 100 },
  { id: 2, name: 'English', totalMarks: 100 },
  { id: 3, name: 'Mathematics', totalMarks: 100 },
  { id: 4, name: 'General Science', totalMarks: 100 },
  { id: 5, name: 'Islamiyat', totalMarks: 100 },
  { id: 6, name: 'Social Studies', totalMarks: 100 },
  { id: 7, name: 'Drawing', totalMarks: 50 }
];

const DEFAULT_SCHOOL_SETTINGS = {
  schoolName: 'GOVERNMENT BOYS PRIMARY SCHOOL SULTAN MATT UCHARI',
  emis: '06994',
  location: 'District Barkhan, Balochistan, Pakistan',
  headTeacher: 'SHOUKAT ALI',
  academicYear: '2026-2027',
  admissionFee: 1000,
  monthlyFee: 2000,
  contactPhone: '+92 829 112233',
  establishedYear: '1988',
  headTeacherSignature: null
};

// Initial student seed for ready offline testing
const INITIAL_STUDENTS = [
  {
    name: 'Muhammad Tariq',
    fatherName: 'Abdul Ghafoor',
    gender: 'Male',
    dob: '2020-04-12',
    className: 'Kachi',
    rollNo: '01',
    admissionNo: '06994-101',
    parentContact: '0333-7821901',
    address: 'Village Sultan Matt Uchari, Barkhan',
    photo: ''
  },
  {
    name: 'Bilal Ahmed',
    fatherName: 'Noor Muhammad',
    gender: 'Male',
    dob: '2019-09-18',
    className: 'Pakki Class',
    rollNo: '01',
    admissionNo: '06994-102',
    parentContact: '0334-9012443',
    address: 'Uchari Road, Tehsil Barkhan',
    photo: ''
  },
  {
    name: 'Zubair Khan',
    fatherName: 'Mir Hazar Khan',
    gender: 'Male',
    dob: '2018-03-22',
    className: 'Class 1',
    rollNo: '01',
    admissionNo: '06994-103',
    parentContact: '0312-5543211',
    address: 'Post Office Sultan Matt, Barkhan',
    photo: ''
  },
  {
    name: 'Hamza Baloch',
    fatherName: 'Gulzar Ahmed',
    gender: 'Male',
    dob: '2017-06-15',
    className: 'Class 2',
    rollNo: '01',
    admissionNo: '06994-104',
    parentContact: '0335-8899001',
    address: 'Main Bazar Sultan Matt, Barkhan',
    photo: ''
  },
  {
    name: 'Rashid Ali',
    fatherName: 'Liaquat Ali',
    gender: 'Male',
    dob: '2016-08-10',
    className: 'Class 3',
    rollNo: '01',
    admissionNo: '06994-105',
    parentContact: '0336-1234567',
    address: 'Village Uchari Sharqi, Barkhan',
    photo: ''
  },
  {
    name: 'Javed Iqbal',
    fatherName: 'Muhammad Ishaq',
    gender: 'Male',
    dob: '2015-11-05',
    className: 'Class 4',
    rollNo: '01',
    admissionNo: '06994-106',
    parentContact: '0331-4455667',
    address: 'Sultan Matt Gharbi, Barkhan',
    photo: ''
  },
  {
    name: 'Kamran Shoukat',
    fatherName: 'Shoukat Ali',
    gender: 'Male',
    dob: '2014-02-14',
    className: 'Class 5',
    rollNo: '01',
    admissionNo: '06994-107',
    parentContact: '0332-9988776',
    address: 'School Colony, Sultan Matt Uchari, Barkhan',
    photo: ''
  },
  {
    name: 'Asim Raza',
    fatherName: 'Ghulam Rasool',
    gender: 'Male',
    dob: '2014-07-20',
    className: 'Class 5',
    rollNo: '02',
    admissionNo: '06994-108',
    parentContact: '0333-1122334',
    address: 'Basti Khetran, Barkhan',
    photo: ''
  }
];

let dbInstance = null;

function openDB() {
  return new Promise((resolve, reject) => {
    if (dbInstance) {
      return resolve(dbInstance);
    }
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event) => {
      const db = event.target.result;

      // 1. Students store
      if (!db.objectStoreNames.contains('students')) {
        const studentStore = db.createObjectStore('students', { keyPath: 'id', autoIncrement: true });
        studentStore.createIndex('by_class', 'className', { unique: false });
        studentStore.createIndex('by_rollNo', 'rollNo', { unique: false });
        studentStore.createIndex('by_admissionNo', 'admissionNo', { unique: false });
      }

      // 2. Classes store
      if (!db.objectStoreNames.contains('classes')) {
        db.createObjectStore('classes', { keyPath: 'id' });
      }

      // 3. Attendance store
      if (!db.objectStoreNames.contains('attendance')) {
        const attStore = db.createObjectStore('attendance', { keyPath: 'id', autoIncrement: true });
        attStore.createIndex('by_class_date', ['className', 'date'], { unique: false });
        attStore.createIndex('by_student_date', ['studentId', 'date'], { unique: false });
        attStore.createIndex('by_date', 'date', { unique: false });
      }

      // 4. Exams store
      if (!db.objectStoreNames.contains('exams')) {
        db.createObjectStore('exams', { keyPath: 'id', autoIncrement: true });
      }

      // 5. Subjects store
      if (!db.objectStoreNames.contains('subjects')) {
        db.createObjectStore('subjects', { keyPath: 'id', autoIncrement: true });
      }

      // 6. Results store
      if (!db.objectStoreNames.contains('results')) {
        const resultStore = db.createObjectStore('results', { keyPath: 'id', autoIncrement: true });
        resultStore.createIndex('by_exam_class', ['examId', 'className'], { unique: false });
        resultStore.createIndex('by_student', 'studentId', { unique: false });
      }

      // 7. Fees store
      if (!db.objectStoreNames.contains('fees')) {
        const feeStore = db.createObjectStore('fees', { keyPath: 'id', autoIncrement: true });
        feeStore.createIndex('by_class_month', ['className', 'month', 'year'], { unique: false });
        feeStore.createIndex('by_student', 'studentId', { unique: false });
      }

      // 8. Settings store
      if (!db.objectStoreNames.contains('settings')) {
        db.createObjectStore('settings', { keyPath: 'key' });
      }
    };

    request.onsuccess = async (event) => {
      dbInstance = event.target.result;
      await initDefaultData(dbInstance);
      resolve(dbInstance);
    };

    request.onerror = (event) => {
      console.error('IndexedDB open error:', event.target.error);
      reject(event.target.error);
    };
  });
}

// Ensure default data exists
async function initDefaultData(db) {
  // Check settings
  const settings = await getFromStore(db, 'settings', 'school_info');
  if (!settings) {
    await putToStore(db, 'settings', { key: 'school_info', ...DEFAULT_SCHOOL_SETTINGS });
  }

  // Check classes
  const classes = await getAllFromStore(db, 'classes');
  if (classes.length === 0) {
    for (const c of DEFAULT_CLASSES) {
      await putToStore(db, 'classes', c);
    }
  }

  // Check subjects
  const subjects = await getAllFromStore(db, 'subjects');
  if (subjects.length === 0) {
    for (const s of DEFAULT_SUBJECTS) {
      await putToStore(db, 'subjects', s);
    }
  }

  // Check exams
  const exams = await getAllFromStore(db, 'exams');
  if (exams.length === 0) {
    await putToStore(db, 'exams', {
      name: 'Final Term Examination 2026',
      academicYear: '2026-2027',
      date: '2026-03-15'
    });
    await putToStore(db, 'exams', {
      name: 'Mid Term Examination 2026',
      academicYear: '2026-2027',
      date: '2026-10-20'
    });
  }

  // Check students
  const students = await getAllFromStore(db, 'students');
  if (students.length === 0) {
    for (const st of INITIAL_STUDENTS) {
      await putToStore(db, 'students', {
        ...st,
        createdDate: new Date().toISOString()
      });
    }

    // Add initial attendance for today for demo students
    const today = new Date().toISOString().split('T')[0];
    const insertedStudents = await getAllFromStore(db, 'students');
    for (const s of insertedStudents) {
      await putToStore(db, 'attendance', {
        studentId: s.id,
        studentName: s.name,
        fatherName: s.fatherName,
        rollNo: s.rollNo,
        className: s.className,
        date: today,
        status: 'P',
        timestamp: Date.now()
      });

      // Add initial fee record
      await putToStore(db, 'fees', {
        studentId: s.id,
        studentName: s.name,
        fatherName: s.fatherName,
        className: s.className,
        rollNo: s.rollNo,
        feeType: 'Monthly Fee',
        month: 'September',
        year: 2026,
        academicYear: '2026-2027',
        requiredAmount: 2000,
        paidAmount: 2000,
        remainingAmount: 0,
        status: 'PAID',
        receiptNo: 'REC-' + (1000 + s.id),
        paymentDate: today,
        notes: 'Cash on counter',
        timestamp: Date.now()
      });
    }

    // Add sample results for Class 5 students
    const c5Students = insertedStudents.filter(s => s.className === 'Class 5');
    const examsList = await getAllFromStore(db, 'exams');
    if (examsList.length > 0 && c5Students.length > 0) {
      const exam = examsList[0];
      for (const st of c5Students) {
        const subMarks = [
          { subjectName: 'Urdu', totalMarks: 100, obtainedMarks: 85, grade: 'A+' },
          { subjectName: 'English', totalMarks: 100, obtainedMarks: 78, grade: 'A' },
          { subjectName: 'Mathematics', totalMarks: 100, obtainedMarks: 92, grade: 'A+' },
          { subjectName: 'General Science', totalMarks: 100, obtainedMarks: 84, grade: 'A+' },
          { subjectName: 'Islamiyat', totalMarks: 100, obtainedMarks: 95, grade: 'A+' },
          { subjectName: 'Social Studies', totalMarks: 100, obtainedMarks: 80, grade: 'A+' },
          { subjectName: 'Drawing', totalMarks: 50, obtainedMarks: 45, grade: 'A+' }
        ];
        const tot = subMarks.reduce((a, b) => a + b.totalMarks, 0);
        const obt = subMarks.reduce((a, b) => a + b.obtainedMarks, 0);
        const pct = ((obt / tot) * 100).toFixed(1);
        await putToStore(db, 'results', {
          examId: exam.id,
          examName: exam.name,
          academicYear: exam.academicYear,
          studentId: st.id,
          studentName: st.name,
          fatherName: st.fatherName,
          className: st.className,
          rollNo: st.rollNo,
          subjects: subMarks,
          totalMarks: tot,
          totalObtained: obt,
          percentage: parseFloat(pct),
          grade: 'A+',
          status: 'Pass',
          timestamp: Date.now()
        });
      }
    }
  }
}

// Low-level helper functions
function getFromStore(db, storeName, key) {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readonly');
    const store = tx.objectStore(storeName);
    const req = store.get(key);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

function getAllFromStore(db, storeName) {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readonly');
    const store = tx.objectStore(storeName);
    const req = store.getAll();
    req.onsuccess = () => resolve(req.result || []);
    req.onerror = () => reject(req.error);
  });
}

function putToStore(db, storeName, value) {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readwrite');
    const store = tx.objectStore(storeName);
    const req = store.put(value);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

function deleteFromStore(db, storeName, key) {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readwrite');
    const store = tx.objectStore(storeName);
    const req = store.delete(key);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

function clearStore(db, storeName) {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readwrite');
    const store = tx.objectStore(storeName);
    const req = store.clear();
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

// Standard Class Order Helper
const CLASS_ORDER = [
  'Kachi',
  'Pakki Class',
  'Class 1',
  'Class 2',
  'Class 3',
  'Class 4',
  'Class 5'
];

function sortClasses(classList) {
  return [...classList].sort((a, b) => {
    const nameA = typeof a === 'string' ? a : a.name;
    const nameB = typeof b === 'string' ? b : b.name;
    const indexA = CLASS_ORDER.indexOf(nameA);
    const indexB = CLASS_ORDER.indexOf(nameB);
    if (indexA !== -1 && indexB !== -1) return indexA - indexB;
    if (indexA !== -1) return -1;
    if (indexB !== -1) return 1;
    return nameA.localeCompare(nameB);
  });
}

// Exported high-level DB API
window.SchoolDB = {
  openDB,
  CLASS_ORDER,
  sortClasses,

  // Settings
  async getSettings() {
    const db = await openDB();
    const data = await getFromStore(db, 'settings', 'school_info');
    return data || { ...DEFAULT_SCHOOL_SETTINGS };
  },

  async saveSettings(settingsObj) {
    const db = await openDB();
    return putToStore(db, 'settings', { key: 'school_info', ...settingsObj });
  },

  async getSignature() {
    const db = await openDB();
    const res = await getFromStore(db, 'settings', 'head_teacher_signature');
    return res ? res.dataUrl : null;
  },

  async saveSignature(dataUrl) {
    const db = await openDB();
    return putToStore(db, 'settings', { key: 'head_teacher_signature', dataUrl });
  },

  // Classes
  async getClasses() {
    const db = await openDB();
    const classes = await getAllFromStore(db, 'classes');
    return sortClasses(classes);
  },

  async updateClass(cls) {
    const db = await openDB();
    return putToStore(db, 'classes', cls);
  },

  // Students
  async getAllStudents() {
    const db = await openDB();
    const list = await getAllFromStore(db, 'students');
    return list.sort((a, b) => {
      const cDiff = CLASS_ORDER.indexOf(a.className) - CLASS_ORDER.indexOf(b.className);
      if (cDiff !== 0) return cDiff;
      return (parseInt(a.rollNo, 10) || 0) - (parseInt(b.rollNo, 10) || 0);
    });
  },

  async getStudentsByClass(className) {
    const db = await openDB();
    const all = await getAllFromStore(db, 'students');
    return all
      .filter(s => s.className === className)
      .sort((a, b) => (parseInt(a.rollNo, 10) || 0) - (parseInt(b.rollNo, 10) || 0));
  },

  async getStudentById(id) {
    const db = await openDB();
    return getFromStore(db, 'students', Number(id));
  },

  async addStudent(student) {
    const db = await openDB();
    student.createdDate = new Date().toISOString();
    return putToStore(db, 'students', student);
  },

  async updateStudent(student) {
    const db = await openDB();
    student.id = Number(student.id);
    return putToStore(db, 'students', student);
  },

  async deleteStudent(id) {
    const db = await openDB();
    const sId = Number(id);
    // Delete student
    await deleteFromStore(db, 'students', sId);
    // Also clean up related attendance, results, fees
    const allAtt = await getAllFromStore(db, 'attendance');
    for (const a of allAtt) {
      if (a.studentId === sId) {
        await deleteFromStore(db, 'attendance', a.id);
      }
    }
    const allResults = await getAllFromStore(db, 'results');
    for (const r of allResults) {
      if (r.studentId === sId) {
        await deleteFromStore(db, 'results', r.id);
      }
    }
    const allFees = await getAllFromStore(db, 'fees');
    for (const f of allFees) {
      if (f.studentId === sId) {
        await deleteFromStore(db, 'fees', f.id);
      }
    }
    return true;
  },

  // Attendance
  async getAttendanceByClassAndDate(className, date) {
    const db = await openDB();
    const all = await getAllFromStore(db, 'attendance');
    return all.filter(a => a.className === className && a.date === date);
  },

  async getAttendanceByDate(date) {
    const db = await openDB();
    const all = await getAllFromStore(db, 'attendance');
    return all.filter(a => a.date === date);
  },

  async getAttendanceForMonth(className, monthStr, yearNum) {
    // monthStr can be '09' or 'September'
    const db = await openDB();
    const all = await getAllFromStore(db, 'attendance');
    return all.filter(a => {
      if (className && a.className !== className) return false;
      const [y, m] = a.date.split('-');
      const matchYear = parseInt(y, 10) === parseInt(yearNum, 10);
      const matchMonth = parseInt(m, 10) === parseInt(monthStr, 10);
      return matchYear && matchMonth;
    });
  },

  async getStudentAttendanceHistory(studentId) {
    const db = await openDB();
    const all = await getAllFromStore(db, 'attendance');
    return all
      .filter(a => a.studentId === Number(studentId))
      .sort((a, b) => b.date.localeCompare(a.date));
  },

  async saveAttendanceRecords(records) {
    const db = await openDB();
    const all = await getAllFromStore(db, 'attendance');
    for (const rec of records) {
      // check if existing record for this student and date
      const existing = all.find(a => a.studentId === rec.studentId && a.date === rec.date);
      if (existing) {
        rec.id = existing.id;
      }
      rec.timestamp = Date.now();
      await putToStore(db, 'attendance', rec);
    }
    return true;
  },

  // Exams & Subjects
  async getExams() {
    const db = await openDB();
    return getAllFromStore(db, 'exams');
  },

  async addExam(exam) {
    const db = await openDB();
    return putToStore(db, 'exams', exam);
  },

  async deleteExam(id) {
    const db = await openDB();
    return deleteFromStore(db, 'exams', Number(id));
  },

  async getSubjects() {
    const db = await openDB();
    return getAllFromStore(db, 'subjects');
  },

  async addSubject(subject) {
    const db = await openDB();
    return putToStore(db, 'subjects', subject);
  },

  async updateSubject(subject) {
    const db = await openDB();
    return putToStore(db, 'subjects', subject);
  },

  async deleteSubject(id) {
    const db = await openDB();
    return deleteFromStore(db, 'subjects', Number(id));
  },

  // Results
  async getResults(examId, className) {
    const db = await openDB();
    const all = await getAllFromStore(db, 'results');
    return all.filter(r => {
      const matchExam = !examId || r.examId === Number(examId);
      const matchClass = !className || r.className === className;
      return matchExam && matchClass;
    });
  },

  async getResultById(id) {
    const db = await openDB();
    return getFromStore(db, 'results', Number(id));
  },

  async saveResult(result) {
    const db = await openDB();
    result.timestamp = Date.now();
    return putToStore(db, 'results', result);
  },

  async deleteResult(id) {
    const db = await openDB();
    return deleteFromStore(db, 'results', Number(id));
  },

  // Fees
  async getFees(className, month, year, academicYear) {
    const db = await openDB();
    const all = await getAllFromStore(db, 'fees');
    return all.filter(f => {
      if (className && f.className !== className) return false;
      if (month && f.month !== month) return false;
      if (year && Number(f.year) !== Number(year)) return false;
      if (academicYear && f.academicYear !== academicYear) return false;
      return true;
    });
  },

  async getFeeById(id) {
    const db = await openDB();
    return getFromStore(db, 'fees', Number(id));
  },

  async getFeesByStudent(studentId) {
    const db = await openDB();
    const all = await getAllFromStore(db, 'fees');
    return all
      .filter(f => f.studentId === Number(studentId))
      .sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));
  },

  async saveFeeRecord(record) {
    const db = await openDB();
    record.timestamp = Date.now();
    return putToStore(db, 'fees', record);
  },

  async deleteFeeRecord(id) {
    const db = await openDB();
    return deleteFromStore(db, 'fees', Number(id));
  },

  // Dashboard Stats
  async getDashboardStats() {
    const db = await openDB();
    const students = await getAllFromStore(db, 'students');
    const classes = await getAllFromStore(db, 'classes');
    const results = await getAllFromStore(db, 'results');
    const fees = await getAllFromStore(db, 'fees');

    const today = new Date().toISOString().split('T')[0];
    const todayAtt = await getAllFromStore(db, 'attendance');
    const todayRecords = todayAtt.filter(a => a.date === today);

    const totalStudents = students.length;
    const totalClasses = classes.length;
    const presentToday = todayRecords.filter(a => a.status === 'P').length;
    const todayPct = todayRecords.length > 0 ? Math.round((presentToday / todayRecords.length) * 100) : 0;

    let totalFeesCollected = 0;
    let pendingFees = 0;
    for (const f of fees) {
      totalFeesCollected += Number(f.paidAmount || 0);
      pendingFees += Number(f.remainingAmount || 0);
    }

    return {
      totalStudents,
      totalClasses,
      todayMarked: todayRecords.length,
      presentToday,
      todayPct,
      totalResults: results.length,
      totalFeesCollected,
      pendingFees
    };
  },

  // Backup and Restore
  async exportBackup() {
    const db = await openDB();
    const backup = {
      meta: {
        app: 'GBPS Sultan Matt Uchari School Management',
        emis: '06994',
        exportDate: new Date().toISOString(),
        version: 1
      },
      settings: await getAllFromStore(db, 'settings'),
      classes: await getAllFromStore(db, 'classes'),
      students: await getAllFromStore(db, 'students'),
      attendance: await getAllFromStore(db, 'attendance'),
      exams: await getAllFromStore(db, 'exams'),
      subjects: await getAllFromStore(db, 'subjects'),
      results: await getAllFromStore(db, 'results'),
      fees: await getAllFromStore(db, 'fees')
    };
    return backup;
  },

  async importBackup(backupData, mode = 'replace') {
    const db = await openDB();
    if (!backupData || !backupData.meta) {
      throw new Error('Invalid backup file format.');
    }

    if (mode === 'replace') {
      await clearStore(db, 'students');
      await clearStore(db, 'attendance');
      await clearStore(db, 'results');
      await clearStore(db, 'fees');
      await clearStore(db, 'exams');
      await clearStore(db, 'subjects');
      await clearStore(db, 'classes');
      await clearStore(db, 'settings');
    }

    // Insert classes
    if (backupData.classes) {
      for (const c of backupData.classes) {
        await putToStore(db, 'classes', c);
      }
    }
    // Insert settings
    if (backupData.settings) {
      for (const s of backupData.settings) {
        await putToStore(db, 'settings', s);
      }
    }
    // Insert subjects
    if (backupData.subjects) {
      for (const sub of backupData.subjects) {
        await putToStore(db, 'subjects', sub);
      }
    }
    // Insert exams
    if (backupData.exams) {
      for (const ex of backupData.exams) {
        await putToStore(db, 'exams', ex);
      }
    }
    // Insert students
    if (backupData.students) {
      for (const st of backupData.students) {
        if (mode === 'merge') delete st.id; // allow new ID
        await putToStore(db, 'students', st);
      }
    }
    // Insert attendance
    if (backupData.attendance) {
      for (const att of backupData.attendance) {
        if (mode === 'merge') delete att.id;
        await putToStore(db, 'attendance', att);
      }
    }
    // Insert results
    if (backupData.results) {
      for (const r of backupData.results) {
        if (mode === 'merge') delete r.id;
        await putToStore(db, 'results', r);
      }
    }
    // Insert fees
    if (backupData.fees) {
      for (const f of backupData.fees) {
        if (mode === 'merge') delete f.id;
        await putToStore(db, 'fees', f);
      }
    }
    return true;
  }
};
