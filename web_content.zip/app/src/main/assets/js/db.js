/**
 * আল-কারীম পুকুর ম্যানেজমেন্ট - লোকাল স্টোরেজ ডেটাবেস ইঞ্জিন
 * LocalStorage Persistence Engine with Soft-Delete / Recycle Bin
 */

const STORAGE_PREFIX = 'alkarim_pond_';

const initialDemoData = {
  farmSettings: {
    farmName: 'আল-কারীম ফিশারিজ ও মৎস্য খামার',
    tagline: 'সঠিক ব্যবস্থাপনায় সফল মৎস্য চাষ',
    ownerName: '',
    mobile: '',
    address: '',
    currencySymbol: '৳'
  },
  ponds: [],
  members: [],
  feedStock: [],
  dailyFeed: [],
  expenses: [],
  fishBuy: [],
  fishSell: [],
  deadFish: [],
  recycleBin: []
};

// Known legacy demo IDs for safe identification & cleanup from localStorage
const DEMO_RECORD_IDS = new Set([
  'pond_1', 'pond_2', 'pond_3',
  'mem_1', 'mem_2', 'mem_3', 'mem_4',
  'fs_1', 'fs_2',
  'df_1', 'df_2', 'df_3', 'df_4', 'df_5',
  'exp_1', 'exp_2', 'exp_3', 'exp_4',
  'fb_1', 'fb_2', 'fb_3',
  'fsell_1', 'fsell_2',
  'dfish_1', 'dfish_2'
]);

function isDemoRecord(table, item) {
  if (!item || typeof item !== 'object') return false;
  // Explicitly marked user data is never demo
  if (item.isDemo === false) return false;
  // If explicitly flagged as demo
  if (item.isDemo === true) return true;

  // Only match legacy hardcoded items that lack a user createdAt timestamp
  // AND have explicit legacy demo IDs or legacy sample names
  if (item.createdAt && new Date(item.createdAt).getTime() > 1600000000000 && !item.isDemo) {
    return false;
  }

  if (item.id && DEMO_RECORD_IDS.has(String(item.id).trim()) && !item.createdAt) {
    return true;
  }

  // Specific legacy sample checks (only if no createdAt)
  if (!item.createdAt) {
    switch (table) {
      case 'ponds':
        if (['পুকুর ১ - উত্তর দীঘি', 'পুকুর ২ - পূর্ব পুকুর', 'পুকুর ৩ - দক্ষিণ নার্সারি'].includes(item.name)) return true;
        break;
      case 'members':
        if (['মাওলানা রফিকুল ইসলাম', 'আলহাজ্ব মো: কামরুল হাসান', 'আব্দুল করিম মিয়া', 'মোঃ শরিফুল ইসলাম'].includes(item.name) && item.mobile === '০১৭১১-২২৩৩৪৪') return true;
        break;
      case 'feedStock':
        if (['MF-8841', 'AB-2039'].includes(item.invoiceNo) && ['fs_1', 'fs_2'].includes(item.id)) return true;
        break;
      case 'dailyFeed':
        if (['df_1', 'df_2', 'df_3', 'df_4', 'df_5'].includes(item.id)) return true;
        break;
      case 'expenses':
        if (['exp_1', 'exp_2', 'exp_3', 'exp_4'].includes(item.id)) return true;
        break;
      case 'fishBuy':
      case 'fishPurchases':
        if (['fb_1', 'fb_2', 'fb_3'].includes(item.id)) return true;
        break;
      case 'fishSell':
      case 'fishSales':
        if (['fsell_1', 'fsell_2'].includes(item.id)) return true;
        break;
      case 'deadFish':
      case 'mortality':
        if (['dfish_1', 'dfish_2'].includes(item.id)) return true;
        break;
    }
  }

  return false;
}

class PondDatabase {
  constructor() {
    this.init();
  }

  init() {
    // 1. Purge legacy demo data from existing localStorage if present
    this.removeDemoDataOnly();

    // 2. Ensure all standard tables exist safely as empty arrays
    this._ensureDefaultStructure();
    localStorage.setItem(STORAGE_PREFIX + 'initialized', 'true');
  }

  _canonicalTable(table) {
    if (table === 'fishPurchases') return 'fishBuy';
    if (table === 'fishSales') return 'fishSell';
    if (table === 'mortality') return 'deadFish';
    if (table === 'settings') return 'farmSettings';
    return table;
  }

  _altTable(table) {
    if (table === 'fishBuy') return 'fishPurchases';
    if (table === 'fishSell') return 'fishSales';
    if (table === 'deadFish') return 'mortality';
    if (table === 'farmSettings') return 'settings';
    return null;
  }

  _ensureDefaultStructure() {
    const requiredArrays = ['ponds', 'members', 'feedStock', 'dailyFeed', 'expenses', 'fishBuy', 'fishSell', 'deadFish', 'recycleBin'];
    requiredArrays.forEach(tbl => {
      try {
        const raw = localStorage.getItem(STORAGE_PREFIX + tbl);
        if (!raw) {
          localStorage.setItem(STORAGE_PREFIX + tbl, JSON.stringify([]));
        } else {
          const parsed = JSON.parse(raw);
          if (!Array.isArray(parsed)) {
            localStorage.setItem(STORAGE_PREFIX + tbl, JSON.stringify([]));
          }
        }
      } catch (e) {
        console.warn(`Recovered table ${tbl} due to parse error`, e);
        localStorage.setItem(STORAGE_PREFIX + tbl, JSON.stringify([]));
      }
    });

    // Also sync alias keys
    ['fishPurchases', 'fishSales', 'mortality'].forEach(alias => {
      const canonical = this._canonicalTable(alias);
      try {
        const raw = localStorage.getItem(STORAGE_PREFIX + canonical);
        if (raw) localStorage.setItem(STORAGE_PREFIX + alias, raw);
        else localStorage.setItem(STORAGE_PREFIX + alias, JSON.stringify([]));
      } catch (e) {}
    });

    // Ensure settings
    try {
      const rawSettings = localStorage.getItem(STORAGE_PREFIX + 'farmSettings');
      if (!rawSettings) {
        localStorage.setItem(STORAGE_PREFIX + 'farmSettings', JSON.stringify(initialDemoData.farmSettings));
        localStorage.setItem(STORAGE_PREFIX + 'settings', JSON.stringify(initialDemoData.farmSettings));
      }
    } catch (e) {
      localStorage.setItem(STORAGE_PREFIX + 'farmSettings', JSON.stringify(initialDemoData.farmSettings));
      localStorage.setItem(STORAGE_PREFIX + 'settings', JSON.stringify(initialDemoData.farmSettings));
    }
  }

  // Remove demo data specifically from localStorage while keeping real user records intact
  removeDemoDataOnly() {
    if (localStorage.getItem(STORAGE_PREFIX + 'demo_purged_clean') === 'true') {
      return 0;
    }
    const tables = ['ponds', 'members', 'feedStock', 'dailyFeed', 'expenses', 'fishBuy', 'fishSell', 'deadFish', 'recycleBin'];
    let removedCount = 0;

    tables.forEach(table => {
      try {
        const raw = localStorage.getItem(STORAGE_PREFIX + table);
        if (!raw) return;
        const items = JSON.parse(raw);
        if (!Array.isArray(items)) return;

        const filtered = items.filter(item => {
          const isDemo = isDemoRecord(table, item);
          if (isDemo) removedCount++;
          return !isDemo;
        });

        localStorage.setItem(STORAGE_PREFIX + table, JSON.stringify(filtered));
        const alt = this._altTable(table);
        if (alt) {
          localStorage.setItem(STORAGE_PREFIX + alt, JSON.stringify(filtered));
        }
      } catch (e) {
        console.error('Error removing demo from ' + table, e);
      }
    });

    // Also clear sample owner if it matches demo
    try {
      const rawSettings = localStorage.getItem(STORAGE_PREFIX + 'farmSettings');
      if (rawSettings) {
        const s = JSON.parse(rawSettings);
        if (s.ownerName === 'মাওলানা রফিকুল ইসলাম' && s.mobile === '০১৭১১-২২৩৩৪৪') {
          s.ownerName = '';
          s.mobile = '';
          s.address = '';
          localStorage.setItem(STORAGE_PREFIX + 'farmSettings', JSON.stringify(s));
          localStorage.setItem(STORAGE_PREFIX + 'settings', JSON.stringify(s));
        }
      }
    } catch (e) {}

    localStorage.setItem(STORAGE_PREFIX + 'demo_purged_clean', 'true');
    return removedCount;
  }

  loadDemoData() {
    // Demo data disabled: completely empty state guaranteed
    this.resetData();
  }

  resetData() {
    const emptyState = {
      farmSettings: {
        farmName: 'আল-কারীম ফিশারিজ ও মৎস্য খামার',
        tagline: 'সঠিক ব্যবস্থাপনায় সফল মৎস্য চাষ',
        ownerName: '',
        mobile: '',
        address: '',
        currencySymbol: '৳'
      },
      ponds: [],
      members: [],
      feedStock: [],
      dailyFeed: [],
      expenses: [],
      fishBuy: [],
      fishSell: [],
      deadFish: [],
      recycleBin: []
    };
    Object.keys(emptyState).forEach(key => {
      localStorage.setItem(STORAGE_PREFIX + key, JSON.stringify(emptyState[key]));
    });
    localStorage.setItem(STORAGE_PREFIX + 'fishPurchases', JSON.stringify([]));
    localStorage.setItem(STORAGE_PREFIX + 'fishSales', JSON.stringify([]));
    localStorage.setItem(STORAGE_PREFIX + 'mortality', JSON.stringify([]));
    localStorage.setItem(STORAGE_PREFIX + 'settings', JSON.stringify(emptyState.farmSettings));
    localStorage.setItem(STORAGE_PREFIX + 'initialized', 'true');
    localStorage.setItem(STORAGE_PREFIX + 'demo_purged_clean', 'true');
  }

  getAll(table) {
    try {
      const canonical = this._canonicalTable(table);
      let data = localStorage.getItem(STORAGE_PREFIX + canonical);
      if (!data && canonical !== table) {
        data = localStorage.getItem(STORAGE_PREFIX + table);
      }
      if (data) {
        const parsed = JSON.parse(data);
        if (Array.isArray(parsed)) return parsed;
      }
      // If table missing or invalid, initialize as empty array
      const emptyArr = [];
      localStorage.setItem(STORAGE_PREFIX + canonical, JSON.stringify(emptyArr));
      return emptyArr;
    } catch (e) {
      console.error('Error reading table ' + table, e);
      try {
        const canonical = this._canonicalTable(table);
        localStorage.setItem(STORAGE_PREFIX + canonical, JSON.stringify([]));
      } catch (err) {}
      return [];
    }
  }

  getById(table, id) {
    if (id === null || id === undefined) return null;
    const items = this.getAll(table);
    const targetIdStr = String(id).trim();
    return items.find(item => item && String(item.id).trim() === targetIdStr) || null;
  }

  insert(table, item) {
    const canonical = this._canonicalTable(table);
    const alt = this._altTable(canonical);
    const items = this.getAll(canonical);
    if (!item.id) {
      const prefix = canonical.replace(/[^a-zA-Z]/g, '').substring(0, 3) || 'rec';
      item.id = prefix + '_' + Date.now() + '_' + Math.random().toString(36).substr(2, 6);
    } else {
      item.id = String(item.id);
    }
    item.isDemo = false;
    item.createdAt = item.createdAt || new Date().toISOString();
    items.unshift(item);
    
    // Save to primary table
    localStorage.setItem(STORAGE_PREFIX + canonical, JSON.stringify(items));
    // Save to alt table
    if (alt) {
      localStorage.setItem(STORAGE_PREFIX + alt, JSON.stringify(items));
    }
    return item;
  }

  update(table, id, updatedFields) {
    if (id === null || id === undefined) return null;
    const canonical = this._canonicalTable(table);
    const alt = this._altTable(canonical);
    const items = this.getAll(canonical);
    const targetIdStr = String(id).trim();
    const index = items.findIndex(item => item && String(item.id).trim() === targetIdStr);
    if (index !== -1) {
      items[index] = { ...items[index], ...updatedFields, updatedAt: new Date().toISOString() };
      localStorage.setItem(STORAGE_PREFIX + canonical, JSON.stringify(items));
      if (alt) {
        localStorage.setItem(STORAGE_PREFIX + alt, JSON.stringify(items));
      }
      return items[index];
    }
    return null;
  }

  // Direct safe delete using Array.filter
  delete(table, id) {
    if (id === null || id === undefined) return false;
    const canonical = this._canonicalTable(table);
    const alt = this._altTable(canonical);
    const items = this.getAll(canonical);
    const targetIdStr = String(id).trim();

    const newItems = items.filter(item => item && String(item.id).trim() !== targetIdStr);
    if (newItems.length === items.length) return false;

    localStorage.setItem(STORAGE_PREFIX + canonical, JSON.stringify(newItems));
    if (alt) {
      localStorage.setItem(STORAGE_PREFIX + alt, JSON.stringify(newItems));
    }
    return true;
  }

  // Soft delete into recycleBin with Array.filter
  softDelete(table, id) {
    if (id === null || id === undefined) return false;
    const canonical = this._canonicalTable(table);
    const alt = this._altTable(canonical);
    const items = this.getAll(canonical);
    const targetIdStr = String(id).trim();

    const itemToDelete = items.find(item => item && String(item.id).trim() === targetIdStr);
    if (!itemToDelete) return false;

    // Filter out item safely
    const newItems = items.filter(item => item && String(item.id).trim() !== targetIdStr);
    localStorage.setItem(STORAGE_PREFIX + canonical, JSON.stringify(newItems));
    if (alt) {
      localStorage.setItem(STORAGE_PREFIX + alt, JSON.stringify(newItems));
    }

    // Add to recycle bin
    const recycleBin = this.getAll('recycleBin');
    const binItem = {
      id: 'bin_' + Date.now() + '_' + Math.random().toString(36).substr(2, 6),
      originalTable: canonical,
      originalId: String(itemToDelete.id),
      title: itemToDelete.name || itemToDelete.feedName || itemToDelete.fishType || itemToDelete.description || 'রেকর্ড',
      summary: this._getItemSummary(canonical, itemToDelete),
      itemData: itemToDelete,
      deletedAt: new Date().toISOString()
    };
    recycleBin.unshift(binItem);
    localStorage.setItem(STORAGE_PREFIX + 'recycleBin', JSON.stringify(recycleBin));
    return true;
  }

  restoreFromBin(binId) {
    if (binId === null || binId === undefined) return false;
    const binItems = this.getAll('recycleBin');
    const targetBinIdStr = String(binId).trim();
    const binItem = binItems.find(i => i && String(i.id).trim() === targetBinIdStr);
    if (!binItem) return false;

    const targetTable = binItem.originalTable;
    const itemData = binItem.itemData;

    // Restore to table if not already present
    const tableItems = this.getAll(targetTable);
    const exists = tableItems.some(i => i && String(i.id).trim() === String(itemData.id).trim());
    if (!exists) {
      tableItems.unshift(itemData);
      localStorage.setItem(STORAGE_PREFIX + targetTable, JSON.stringify(tableItems));
      const alt = this._altTable(targetTable);
      if (alt) {
        localStorage.setItem(STORAGE_PREFIX + alt, JSON.stringify(tableItems));
      }
    }

    // Remove from bin safely with filter
    const newBinItems = binItems.filter(i => i && String(i.id).trim() !== targetBinIdStr);
    localStorage.setItem(STORAGE_PREFIX + 'recycleBin', JSON.stringify(newBinItems));
    return true;
  }

  permanentDeleteFromBin(binId) {
    if (binId === null || binId === undefined) return false;
    const binItems = this.getAll('recycleBin');
    const targetBinIdStr = String(binId).trim();
    const filtered = binItems.filter(i => i && String(i.id).trim() !== targetBinIdStr);
    localStorage.setItem(STORAGE_PREFIX + 'recycleBin', JSON.stringify(filtered));
    return true;
  }

  clearRecycleBin() {
    localStorage.setItem(STORAGE_PREFIX + 'recycleBin', JSON.stringify([]));
    return true;
  }

  _getItemSummary(table, item) {
    switch (table) {
      case 'ponds': return `আয়তন: ${item.area} ${item.unit} | পোনা: ${item.fishCount}`;
      case 'members': return `আইডি: ${item.memberId} | শেয়ার: ${item.shareCount}`;
      case 'feedStock': return `পরিমাণ: ${item.totalKg} কেজি (${item.totalSacks} বস্তা) | মূল্য: ৳${item.totalPrice}`;
      case 'dailyFeed': return `পুকুর: ${item.pondName} | খাদ্য: ${item.amountKg} কেজি | খরচ: ৳${item.totalPrice}`;
      case 'expenses': return `ধরন: ${item.category} | টাকা: ৳${item.totalMoney}`;
      case 'fishBuy': return `পোনা: ${item.count} টি | মোট দাম: ৳${item.totalPrice}`;
      case 'fishSell': return `ওজন: ${item.totalWeight} কেজি | বিক্রয় মূল্য: ৳${item.totalPrice}`;
      case 'deadFish': return `সংখ্যা: ${item.count} টি | কারণ: ${item.cause}`;
      default: return '';
    }
  }

  getSettings() {
    try {
      const data = localStorage.getItem(STORAGE_PREFIX + 'farmSettings');
      return data ? JSON.parse(data) : initialDemoData.farmSettings;
    } catch (e) {
      return initialDemoData.farmSettings;
    }
  }

  updateSettings(newSettings) {
    localStorage.setItem(STORAGE_PREFIX + 'farmSettings', JSON.stringify(newSettings));
    return newSettings;
  }

  exportData() {
    const exportObj = {
      version: '1.0',
      appName: 'আল-কারীম পুকুর ম্যানেজমেন্ট',
      exportedAt: new Date().toISOString(),
      farmSettings: this.getSettings(),
      ponds: this.getAll('ponds'),
      members: this.getAll('members'),
      feedStock: this.getAll('feedStock'),
      dailyFeed: this.getAll('dailyFeed'),
      expenses: this.getAll('expenses'),
      fishBuy: this.getAll('fishBuy'),
      fishSell: this.getAll('fishSell'),
      deadFish: this.getAll('deadFish'),
      recycleBin: this.getAll('recycleBin')
    };
    return JSON.stringify(exportObj, null, 2);
  }

  importData(jsonString) {
    try {
      const parsed = JSON.parse(jsonString);
      if (!parsed.version && !parsed.ponds) {
        throw new Error('অবৈধ ব্যাকআপ ফাইল ফরম্যাট।');
      }

      const tables = ['farmSettings', 'ponds', 'members', 'feedStock', 'dailyFeed', 'expenses', 'fishBuy', 'fishSell', 'deadFish', 'recycleBin'];
      tables.forEach(table => {
        if (parsed[table]) {
          localStorage.setItem(STORAGE_PREFIX + table, JSON.stringify(parsed[table]));
        }
      });
      localStorage.setItem(STORAGE_PREFIX + 'initialized', 'true');
      return true;
    } catch (err) {
      console.error('Import error:', err);
      return false;
    }
  }

  getDashboardStats() {
    const ponds = this.getAll('ponds');
    const members = this.getAll('members');
    const feedStock = this.getAll('feedStock');
    const dailyFeed = this.getAll('dailyFeed');
    const expenses = this.getAll('expenses');
    const fishBuy = this.getAll('fishBuy');
    const fishSell = this.getAll('fishSell');
    const deadFish = this.getAll('deadFish');

    // Feed Stock remaining calculation & Floating vs Sinking breakdown
    let floatingStockKg = 0;
    let floatingStockSacks = 0;
    let sinkingStockKg = 0;
    let sinkingStockSacks = 0;

    feedStock.forEach(f => {
      const kg = parseFloat(f.totalKg) || 0;
      const sacks = parseFloat(f.totalSacks) || (kg / (f.kgPerSack || 50));
      if (f.feedType === 'ডুবন্ত') {
        sinkingStockKg += kg;
        sinkingStockSacks += sacks;
      } else {
        floatingStockKg += kg;
        floatingStockSacks += sacks;
      }
    });

    let floatingFedKg = 0;
    let sinkingFedKg = 0;
    dailyFeed.forEach(df => {
      const kg = parseFloat(df.amountKg) || 0;
      if (df.feedType === 'ডুবন্ত') {
        sinkingFedKg += kg;
      } else {
        floatingFedKg += kg;
      }
    });

    const totalPurchasedFeedKg = floatingStockKg + sinkingStockKg;
    const totalPurchasedFeedSacks = Math.round(floatingStockSacks + sinkingStockSacks);
    const totalFedKg = floatingFedKg + sinkingFedKg;
    const totalFedSacks = +(totalFedKg / 50).toFixed(1);

    const remainingFeedKg = Math.max(0, totalPurchasedFeedKg - totalFedKg);
    const remainingFeedSacks = Math.max(0, totalPurchasedFeedSacks - Math.round(totalFedKg / 50));

    const floatingRemainingKg = Math.max(0, floatingStockKg - floatingFedKg);
    const floatingRemainingSacks = Math.max(0, Math.round(floatingRemainingKg / 50));
    const sinkingRemainingKg = Math.max(0, sinkingStockKg - sinkingFedKg);
    const sinkingRemainingSacks = Math.max(0, Math.round(sinkingRemainingKg / 50));

    // Expenses: General expenses + Fish fingerling buy + Feed stock buy
    const generalExpensesTotal = expenses.reduce((acc, e) => acc + (parseFloat(e.totalMoney) || 0), 0);
    const fishBuyTotal = fishBuy.reduce((acc, fb) => acc + (parseFloat(fb.totalPrice) || 0), 0);
    const feedStockBuyTotal = feedStock.reduce((acc, fs) => acc + (parseFloat(fs.totalPrice) || 0), 0);
    const totalExpenses = generalExpensesTotal + fishBuyTotal + feedStockBuyTotal;

    // Income: Fish sales
    const totalFishSales = fishSell.reduce((acc, s) => acc + (parseFloat(s.totalPrice) || 0), 0);
    const totalIncome = totalFishSales;

    // Fish sales in weight and maunds (1 maund = 40 kg)
    const totalFishSoldKg = fishSell.reduce((acc, fs) => acc + (parseFloat(fs.totalWeight) || 0), 0);
    const totalFishSoldMaund = +(totalFishSoldKg / 40).toFixed(2);

    // Profit / Loss
    const netProfit = totalIncome - totalExpenses;

    // Fish stock count
    const totalFishBought = fishBuy.reduce((acc, fb) => acc + (parseInt(fb.count) || 0), 0);
    const pondInitialFish = ponds.reduce((acc, p) => acc + (parseInt(p.fishCount) || 0), 0);
    const totalFishDead = deadFish.reduce((acc, df) => acc + (parseInt(df.count) || 0), 0);
    const totalFishSold = fishSell.reduce((acc, fs) => acc + (parseInt(fs.count) || 0), 0);
    const estimatedFishInPonds = Math.max(0, (pondInitialFish + totalFishBought) - (totalFishDead + totalFishSold));

    // Member deposits
    const totalMemberDeposits = members.reduce((acc, m) => acc + (parseFloat(m.depositAmount) || 0), 0);
    const totalShares = members.reduce((acc, m) => acc + (parseInt(m.shareCount) || 0), 0);

    return {
      totalPonds: ponds.length,
      totalMembers: members.length,
      // Feed Totals
      remainingFeedKg,
      remainingFeedSacks,
      totalPurchasedFeedKg,
      totalPurchasedFeedSacks,
      totalFedKg,
      totalFedSacks,
      // Feed Breakdown
      floatingStockKg,
      floatingStockSacks: Math.round(floatingStockSacks),
      sinkingStockKg,
      sinkingStockSacks: Math.round(sinkingStockSacks),
      floatingFedKg,
      floatingFedSacks: +(floatingFedKg / 50).toFixed(1),
      sinkingFedKg,
      sinkingFedSacks: +(sinkingFedKg / 50).toFixed(1),
      floatingRemainingKg,
      floatingRemainingSacks,
      sinkingRemainingKg,
      sinkingRemainingSacks,
      // Expenses & Income
      totalExpenses,
      generalExpensesTotal,
      fishBuyTotal,
      feedStockBuyTotal,
      totalIncome,
      netProfit,
      // Fish sales in maund and kg
      totalFishSoldKg,
      totalFishSoldMaund,
      // Stock counts
      estimatedFishInPonds,
      totalFishDead,
      totalFishSold,
      totalMemberDeposits,
      totalShares
    };
  }

  getMonthlySummary(yearMonth = null, pondId = 'all') {
    if (!yearMonth) {
      const now = new Date();
      yearMonth = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
    }

    const matchesMonth = (dateStr) => {
      if (!dateStr) return false;
      return String(dateStr).startsWith(yearMonth);
    };

    const matchesPond = (itemPondId) => {
      if (pondId === 'all' || !pondId) return true;
      return itemPondId === pondId;
    };

    // 1. Daily Feed in this month
    const dailyFeeds = this.getAll('dailyFeed').filter(df => matchesMonth(df.date) && matchesPond(df.pondId));
    let dailyFloatingKg = 0;
    let dailySinkingKg = 0;
    let dailyFeedCost = 0;

    dailyFeeds.forEach(df => {
      const kg = parseFloat(df.amountKg) || 0;
      const cost = parseFloat(df.totalPrice) || 0;
      dailyFeedCost += cost;
      if (df.feedType === 'ডুবন্ত') {
        dailySinkingKg += kg;
      } else {
        dailyFloatingKg += kg;
      }
    });
    const dailyTotalFeedKg = dailyFloatingKg + dailySinkingKg;
    const dailyFloatingSacks = +(dailyFloatingKg / 50).toFixed(1);
    const dailySinkingSacks = +(dailySinkingKg / 50).toFixed(1);
    const dailyTotalFeedSacks = +(dailyTotalFeedKg / 50).toFixed(1);

    // 2. Feed Stock purchased in this month
    const feedStockPurchases = this.getAll('feedStock').filter(fs => matchesMonth(fs.date));
    let stockFloatingKg = 0;
    let stockFloatingSacks = 0;
    let stockFloatingCost = 0;
    let stockSinkingKg = 0;
    let stockSinkingSacks = 0;
    let stockSinkingCost = 0;

    feedStockPurchases.forEach(fs => {
      const kg = parseFloat(fs.totalKg) || 0;
      const sacks = parseFloat(fs.totalSacks) || (kg / (fs.kgPerSack || 50));
      const cost = parseFloat(fs.totalPrice) || 0;
      if (fs.feedType === 'ডুবন্ত') {
        stockSinkingKg += kg;
        stockSinkingSacks += sacks;
        stockSinkingCost += cost;
      } else {
        stockFloatingKg += kg;
        stockFloatingSacks += sacks;
        stockFloatingCost += cost;
      }
    });
    const totalStockKg = stockFloatingKg + stockSinkingKg;
    const totalStockSacks = Math.round(stockFloatingSacks + stockSinkingSacks);
    const totalStockCost = stockFloatingCost + stockSinkingCost;

    // 3. Fish Sales in this month (1 maund = 40 kg)
    const fishSales = this.getAll('fishSell').filter(fs => matchesMonth(fs.date) && matchesPond(fs.pondId));
    let totalSalesKg = 0;
    let totalSalesMaund = 0;
    let totalSalesIncome = 0;
    let totalSalesCount = 0;

    fishSales.forEach(fs => {
      const kg = parseFloat(fs.totalWeight) || 0;
      const maund = fs.totalMaund !== undefined && fs.totalMaund !== null && fs.totalMaund !== ''
        ? (parseFloat(fs.totalMaund) || 0)
        : (kg / 40);
      const income = parseFloat(fs.totalPrice) || 0;
      const count = parseInt(fs.count) || 0;

      totalSalesKg += kg;
      totalSalesMaund += maund;
      totalSalesIncome += income;
      totalSalesCount += count;
    });
    totalSalesMaund = +(totalSalesMaund).toFixed(2);

    // 4. Expenses in this month
    const expenses = this.getAll('expenses').filter(e => matchesMonth(e.date) && (pondId === 'all' || e.pondId === pondId || e.pondId === 'all'));
    let generalExpensesTotal = 0;
    const categoryTotals = {};

    expenses.forEach(e => {
      const cost = parseFloat(e.totalMoney) || 0;
      generalExpensesTotal += cost;
      const cat = e.category || 'অন্যান্য';
      categoryTotals[cat] = (categoryTotals[cat] || 0) + cost;
    });

    const fishBuys = this.getAll('fishBuy').filter(fb => matchesMonth(fb.date) && matchesPond(fb.pondId));
    const fishBuyTotal = fishBuys.reduce((acc, fb) => acc + (parseFloat(fb.totalPrice) || 0), 0);

    const totalMonthExpenses = generalExpensesTotal + totalStockCost + fishBuyTotal;
    const netProfit = totalSalesIncome - totalMonthExpenses;

    return {
      yearMonth,
      // Feed
      dailyTotalFeedKg,
      dailyTotalFeedSacks,
      dailyFloatingKg,
      dailyFloatingSacks,
      dailySinkingKg,
      dailySinkingSacks,
      dailyFeedCost,
      stockFloatingKg,
      stockFloatingSacks,
      stockFloatingCost,
      stockSinkingKg,
      stockSinkingSacks,
      stockSinkingCost,
      totalStockKg,
      totalStockSacks,
      totalStockCost,
      dailyFeeds,
      feedStockPurchases,
      // Sales
      totalSalesKg,
      totalSalesMaund,
      totalSalesIncome,
      totalSalesCount,
      fishSales,
      // Expenses
      generalExpensesTotal,
      feedStockBuyTotal: totalStockCost,
      fishBuyTotal,
      totalExpenses: totalMonthExpenses,
      categoryTotals,
      expenses,
      // Profit / Loss
      totalIncome: totalSalesIncome,
      netProfit,
      isProfit: netProfit >= 0
    };
  }

  getRecentActivities(limit = 6) {
    const activities = [];

    this.getAll('ponds').forEach(p => {
      activities.push({
        title: `নতুন পুকুর যুক্ত হয়েছে: ${p.name}`,
        time: p.createdAt || p.releaseDate,
        date: p.releaseDate || p.createdAt,
        type: 'pond',
        icon: '🐟',
        badgeClass: 'success'
      });
    });

    this.getAll('members').forEach(m => {
      activities.push({
        title: `নতুন সদস্য যোগ হয়েছে: ${m.name} (${m.shareCount} শেয়ার)`,
        time: m.createdAt || m.joinDate,
        date: m.joinDate || m.createdAt,
        type: 'member',
        icon: '👥',
        badgeClass: 'info'
      });
    });

    this.getAll('feedStock').forEach(f => {
      activities.push({
        title: `খাদ্য স্টকে যোগ হয়েছে: ${f.feedName} (${f.totalKg} কেজি)`,
        time: f.createdAt || f.date,
        date: f.date,
        type: 'feed',
        icon: '🌾',
        badgeClass: 'warning'
      });
    });

    this.getAll('dailyFeed').forEach(df => {
      activities.push({
        title: `দৈনিক খাদ্য প্রদান: ${df.pondName}-এ ${df.amountKg} কেজি`,
        time: df.createdAt || df.date,
        date: df.date,
        type: 'daily_feed',
        icon: '🍚',
        badgeClass: 'primary'
      });
    });

    this.getAll('expenses').forEach(e => {
      activities.push({
        title: `খরচ লিপিবদ্ধ হয়েছে: ${e.category} (৳${e.totalMoney})`,
        time: e.createdAt || e.date,
        date: e.date,
        type: 'expense',
        icon: '💰',
        badgeClass: 'danger'
      });
    });

    this.getAll('fishSell').forEach(fs => {
      activities.push({
        title: `মাছ বিক্রি হয়েছে: ৳${fs.totalPrice} (${fs.totalWeight} কেজি)`,
        time: fs.createdAt || fs.date,
        date: fs.date,
        type: 'sale',
        icon: '💵',
        badgeClass: 'success'
      });
    });

    this.getAll('deadFish').forEach(df => {
      activities.push({
        title: `মৃত মাছ রেকর্ড: ${df.pondName}-এ ${df.count} টি`,
        time: df.createdAt || df.date,
        date: df.date,
        type: 'dead',
        icon: '☠️',
        badgeClass: 'danger'
      });
    });

    // Sort by date descending
    activities.sort((a, b) => new Date(b.date || b.time || 0) - new Date(a.date || a.time || 0));
    return activities.slice(0, limit);
  }

  getPondReport(pondId) {
    const pond = this.getById('ponds', pondId);
    if (!pond) return null;

    const feeds = this.getAll('dailyFeed').filter(f => f.pondId === pondId);
    const feedKg = feeds.reduce((acc, f) => acc + (parseFloat(f.amountKg) || 0), 0);
    const feedCost = feeds.reduce((acc, f) => acc + (parseFloat(f.totalPrice) || 0), 0);

    const fishBuys = this.getAll('fishBuy').filter(b => b.pondId === pondId);
    const fishBuyCost = fishBuys.reduce((acc, b) => acc + (parseFloat(b.totalPrice) || 0), 0);
    const fishBuyCount = fishBuys.reduce((acc, b) => acc + (parseInt(b.count) || 0), 0);

    const fishSells = this.getAll('fishSell').filter(s => s.pondId === pondId);
    const fishSaleIncome = fishSells.reduce((acc, s) => acc + (parseFloat(s.totalPrice) || 0), 0);
    const fishSaleWeight = fishSells.reduce((acc, s) => acc + (parseFloat(s.totalWeight) || 0), 0);
    const fishSaleCount = fishSells.reduce((acc, s) => acc + (parseInt(s.count) || 0), 0);

    const deadFishList = this.getAll('deadFish').filter(d => d.pondId === pondId);
    const deadCount = deadFishList.reduce((acc, d) => acc + (parseInt(d.count) || 0), 0);

    const otherExpenses = this.getAll('expenses').filter(e => e.pondId === pondId);
    const otherExpenseTotal = otherExpenses.reduce((acc, e) => acc + (parseFloat(e.totalMoney) || 0), 0);

    const totalPondExpense = feedCost + fishBuyCost + otherExpenseTotal;
    const pondNetProfit = fishSaleIncome - totalPondExpense;

    return {
      pond,
      feedKg,
      feedCost,
      fishBuyCount,
      fishBuyCost,
      fishSaleCount,
      fishSaleWeight,
      fishSaleIncome,
      deadCount,
      otherExpenseTotal,
      totalPondExpense,
      pondNetProfit
    };
  }
}

// Export singleton instance
window.db = new PondDatabase();
