// ============================================================================
// MASHA'S HAPPY HOME - 8 COMPLETE PLAYABLE MINI-GAMES ENGINE (2D CANVAS)
// ============================================================================

class MiniGameEngine {
  constructor(canvasId) {
    this.canvas = document.getElementById(canvasId);
    this.ctx = this.canvas ? this.canvas.getContext('2d') : null;
    this.activeGameId = null;
    this.isRunning = false;
    this.isPaused = false;
    this.rafId = null;

    this.score = 0;
    this.level = 1;
    this.timeLeft = 45;
    this.lastTick = 0;

    this.pointer = { x: 240, y: 200, isDown: false };
    this.keys = {};
    this.state = {};

    this.bindEvents();
  }

  bindEvents() {
    if (!this.canvas) return;

    const updateCoords = (e) => {
      const rect = this.canvas.getBoundingClientRect();
      let clientX = e.clientX;
      let clientY = e.clientY;
      if (e.touches && e.touches.length > 0) {
        clientX = e.touches[0].clientX;
        clientY = e.touches[0].clientY;
      } else if (e.changedTouches && e.changedTouches.length > 0) {
        clientX = e.changedTouches[0].clientX;
        clientY = e.changedTouches[0].clientY;
      }
      const scaleX = this.canvas.width / Math.max(1, rect.width);
      const scaleY = this.canvas.height / Math.max(1, rect.height);
      this.pointer.x = (clientX - rect.left) * scaleX;
      this.pointer.y = (clientY - rect.top) * scaleY;
    };

    this.canvas.addEventListener('mousedown', (e) => {
      updateCoords(e);
      this.pointer.isDown = true;
      this.onPointerDown(this.pointer.x, this.pointer.y);
    });
    this.canvas.addEventListener('mousemove', (e) => {
      updateCoords(e);
      if (this.pointer.isDown) this.onPointerDrag(this.pointer.x, this.pointer.y);
    });
    window.addEventListener('mouseup', () => {
      this.pointer.isDown = false;
    });

    this.canvas.addEventListener('touchstart', (e) => {
      updateCoords(e);
      this.pointer.isDown = true;
      this.onPointerDown(this.pointer.x, this.pointer.y);
    }, { passive: true });

    this.canvas.addEventListener('touchmove', (e) => {
      updateCoords(e);
      if (this.pointer.isDown) this.onPointerDrag(this.pointer.x, this.pointer.y);
    }, { passive: true });

    window.addEventListener('touchend', () => {
      this.pointer.isDown = false;
    });

    window.addEventListener('keydown', (e) => {
      this.keys[e.code] = true;
      if (this.isRunning && !this.isPaused && (e.code === 'Space' || e.code === 'ArrowUp')) {
        if (this.activeGameId === 'obstacle') this.jumpObstacleRunner();
      }
    });
    window.addEventListener('keyup', (e) => {
      this.keys[e.code] = false;
    });
  }

  start(gameId) {
    this.stop();
    this.activeGameId = gameId;
    this.isRunning = true;
    this.isPaused = false;
    this.score = 0;
    this.level = 1;
    this.timeLeft = gameId === 'painting' ? 90 : 45;
    this.lastTick = performance.now();

    this.initGameSpecificState(gameId);
    this.updateHUD();
    this.loop(performance.now());
  }

  stop() {
    this.isRunning = false;
    if (this.rafId) {
      cancelAnimationFrame(this.rafId);
      this.rafId = null;
    }
  }

  initGameSpecificState(gameId) {
    const w = this.canvas.width;
    const h = this.canvas.height;

    if (gameId === 'cooking') {
      // Masha's Jam Kitchen: Catch berries in boiling pot + stir meter
      this.state = {
        potX: w / 2,
        items: [],
        spawnTimer: 0,
        heatMeter: 50,
        combo: 0
      };
    } else if (gameId === 'gardening') {
      // Bear's Berry Garden: 6 interactive plots with stages (0=empty, 1=planted, 2=thirsty, 3=weedy, 4=ready)
      const plots = [];
      for (let r = 0; r < 2; r++) {
        for (let c = 0; c < 3; c++) {
          plots.push({
            x: 85 + c * 155,
            y: 115 + r * 125,
            stage: 0,
            timer: 0,
            hasWeed: false
          });
        }
      }
      this.state = { plots };
    } else if (gameId === 'painting') {
      // Forest Art Studio: 6x6 Pixel grid with target pattern + color palette
      const palette = ['#e53935', '#fdd835', '#43a047', '#29b6f6', '#8d6e63', '#ffffff'];
      const targetPattern = [
        [3, 3, 1, 1, 3, 3],
        [3, 2, 2, 2, 2, 3],
        [2, 2, 0, 0, 2, 2],
        [3, 2, 0, 0, 2, 3],
        [3, 3, 4, 4, 3, 3],
        [2, 2, 4, 4, 2, 2]
      ];
      const userGrid = Array.from({ length: 6 }, () => Array(6).fill(5));
      this.state = {
        palette,
        selectedColorIdx: 0,
        targetPattern,
        userGrid,
        freeMode: false
      };
    } else if (gameId === 'memory') {
      // Woodland Memory Match: 12 cards (6 pairs)
      const icons = ['👧', '🐻', '🐷', '🐼', '🍓', '🍯'];
      const deck = [...icons, ...icons]
        .sort(() => Math.random() - 0.5)
        .map((icon, idx) => ({
          idx,
          icon,
          flipped: false,
          matched: false
        }));
      this.state = {
        deck,
        flippedIndices: [],
        lockBoard: false,
        matchesFound: 0
      };
    } else if (gameId === 'obstacle') {
      // Log-Hop Obstacle Course
      this.state = {
        runnerY: 0,
        runnerVy: 0,
        jumpsUsed: 0,
        obstacles: [],
        coins: [],
        spawnTimer: 0,
        scrollX: 0
      };
    } else if (gameId === 'hideseek') {
      // Pinecone Hide-and-Seek: 4 bushes that show character then shuffle
      const bushes = [0, 1, 2, 3].map((i) => ({
        id: i,
        x: 90 + i * 120,
        y: 195,
        hasFriend: i === 1 || i === 2,
        revealed: true
      }));
      this.state = {
        bushes,
        phase: 'preview', // preview -> guessing
        phaseTimer: 2.0,
        foundCount: 0
      };
    } else if (gameId === 'fishing') {
      // Sunny River Fishing: Bear in boat casting hook down
      const fishes = [];
      for (let i = 0; i < 6; i++) {
        fishes.push({
          x: Math.random() * w,
          y: 135 + i * 35,
          vx: (i % 2 === 0 ? 1 : -1) * (65 + Math.random() * 55),
          icon: i === 5 ? '👑' : (i % 3 === 0 ? '🥾' : '🐟'),
          points: i === 5 ? 45 : (i % 3 === 0 ? -10 : 20)
        });
      }
      this.state = {
        boatX: w / 2,
        hookY: 75,
        hookState: 'idle', // idle, dropping, reeling
        caughtItem: null,
        fishes
      };
    } else if (gameId === 'collecting') {
      // Falling Acorn Collector
      this.state = {
        basketX: w / 2,
        falling: [],
        spawnTimer: 0
      };
    }
  }

  jumpObstacleRunner() {
    if (this.activeGameId !== 'obstacle') return;
    if (this.state.jumpsUsed < 2) {
      this.state.runnerVy = -390;
      this.state.jumpsUsed++;
      sound.sfxBoing();
    }
  }

  onPointerDown(x, y) {
    if (!this.isRunning || this.isPaused) return;
    const g = this.activeGameId;

    if (g === 'cooking') {
      // Check Stir Button on right side
      if (x > 420 && y > 250) {
        this.state.heatMeter = Math.max(15, this.state.heatMeter - 28);
        this.score += 15;
        sound.sfxBath();
      } else {
        this.state.potX = x;
      }
    } else if (g === 'gardening') {
      this.state.plots.forEach((p) => {
        if (Math.hypot(x - p.x, y - p.y) < 52) {
          if (p.hasWeed) {
            p.hasWeed = false;
            this.score += 12;
            sound.sfxClick();
          } else if (p.stage === 0) {
            p.stage = 1;
            p.timer = 0;
            this.score += 8;
            sound.sfxClick();
          } else if (p.stage === 2) {
            p.stage = 3;
            p.timer = 0;
            this.score += 15;
            sound.sfxBath();
          } else if (p.stage === 4) {
            p.stage = 0;
            p.timer = 0;
            this.score += 35;
            this.level = 1 + Math.floor(this.score / 120);
            sound.sfxCoin();
          }
        }
      });
    } else if (g === 'painting') {
      // Check Palette clicks at bottom
      const palY = 292;
      this.state.palette.forEach((col, idx) => {
        const px = 95 + idx * 58;
        if (Math.hypot(x - px, y - palY) < 24) {
          this.state.selectedColorIdx = idx;
          sound.sfxClick();
        }
      });
      this.paintCellAt(x, y);
    } else if (g === 'memory') {
      if (this.state.lockBoard) return;
      const cols = 4;
      this.state.deck.forEach((card, i) => {
        const r = Math.floor(i / cols);
        const c = i % cols;
        const cx = 105 + c * 110;
        const cy = 78 + r * 88;
        if (Math.abs(x - cx) < 44 && Math.abs(y - cy) < 36 && !card.flipped && !card.matched) {
          card.flipped = true;
          sound.sfxClick();
          this.state.flippedIndices.push(i);
          if (this.state.flippedIndices.length === 2) {
            this.checkMemoryMatch();
          }
        }
      });
    } else if (g === 'obstacle') {
      this.jumpObstacleRunner();
    } else if (g === 'hideseek') {
      if (this.state.phase !== 'guessing') return;
      this.state.bushes.forEach((b) => {
        if (Math.hypot(x - b.x, y - b.y) < 48 && !b.revealed) {
          b.revealed = true;
          if (b.hasFriend) {
            this.score += 40;
            this.state.foundCount++;
            sound.sfxCoin();
            if (this.state.foundCount >= 2) {
              this.level++;
              setTimeout(() => this.resetHideSeekRound(), 700);
            }
          } else {
            sound.sfxMiss();
          }
        }
      });
    } else if (g === 'fishing') {
      this.state.boatX = Math.max(60, Math.min(this.canvas.width - 60, x));
      if (this.state.hookState === 'idle') {
        this.state.hookState = 'dropping';
        sound.sfxClick();
      }
    } else if (g === 'collecting') {
      this.state.basketX = x;
    }
  }

  onPointerDrag(x, y) {
    if (!this.isRunning || this.isPaused) return;
    if (this.activeGameId === 'cooking') {
      this.state.potX = Math.max(50, Math.min(390, x));
    } else if (this.activeGameId === 'collecting') {
      this.state.basketX = Math.max(50, Math.min(this.canvas.width - 50, x));
    } else if (this.activeGameId === 'fishing' && this.state.hookState === 'idle') {
      this.state.boatX = Math.max(60, Math.min(this.canvas.width - 60, x));
    } else if (this.activeGameId === 'painting') {
      this.paintCellAt(x, y);
    }
  }

  paintCellAt(x, y) {
    const startX = 185;
    const startY = 42;
    const cell = 36;
    const c = Math.floor((x - startX) / cell);
    const r = Math.floor((y - startY) / cell);
    if (r >= 0 && r < 6 && c >= 0 && c < 6) {
      const prev = this.state.userGrid[r][c];
      const next = this.state.selectedColorIdx;
      if (prev !== next) {
        this.state.userGrid[r][c] = next;
        if (this.state.targetPattern[r][c] === next) {
          this.score += 10;
          sound.sfxCoin();
        }
      }
    }
  }

  checkMemoryMatch() {
    const [i1, i2] = this.state.flippedIndices;
    const c1 = this.state.deck[i1];
    const c2 = this.state.deck[i2];
    this.state.lockBoard = true;

    if (c1.icon === c2.icon) {
      c1.matched = true;
      c2.matched = true;
      this.state.flippedIndices = [];
      this.state.lockBoard = false;
      this.state.matchesFound++;
      this.score += 35;
      sound.sfxCoin();

      if (this.state.matchesFound >= 6) {
        this.level++;
        this.score += 50;
        sound.sfxSuccess();
        setTimeout(() => this.initGameSpecificState('memory'), 650);
      }
    } else {
      setTimeout(() => {
        c1.flipped = false;
        c2.flipped = false;
        this.state.flippedIndices = [];
        this.state.lockBoard = false;
      }, 650);
    }
  }

  resetHideSeekRound() {
    if (!this.state.bushes) return;
    const indices = [0, 1, 2, 3].sort(() => Math.random() - 0.5);
    this.state.bushes.forEach((b, i) => {
      b.hasFriend = i === indices[0] || i === indices[1];
      b.revealed = true;
    });
    this.state.phase = 'preview';
    this.state.phaseTimer = Math.max(0.9, 2.0 - this.level * 0.15);
    this.state.foundCount = 0;
  }

  loop(now) {
    if (!this.isRunning) return;
    const dt = Math.min(0.05, (now - this.lastTick) / 1000);
    this.lastTick = now;

    if (!this.isPaused) {
      this.timeLeft -= dt;
      if (this.timeLeft <= 0) {
        this.timeLeft = 0;
        this.finishMinigame();
        return;
      }
      this.updateGameLogic(dt);
      this.renderGame();
      this.updateHUD();
    }

    this.rafId = requestAnimationFrame((t) => this.loop(t));
  }

  updateGameLogic(dt) {
    const g = this.activeGameId;
    const w = this.canvas.width;
    const h = this.canvas.height;

    if (this.keys['ArrowLeft'] || this.keys['KeyA']) {
      if (g === 'cooking') this.state.potX = Math.max(50, this.state.potX - 280 * dt);
      if (g === 'collecting') this.state.basketX = Math.max(50, this.state.basketX - 300 * dt);
      if (g === 'fishing' && this.state.hookState === 'idle') this.state.boatX = Math.max(60, this.state.boatX - 240 * dt);
    }
    if (this.keys['ArrowRight'] || this.keys['KeyD']) {
      if (g === 'cooking') this.state.potX = Math.min(390, this.state.potX + 280 * dt);
      if (g === 'collecting') this.state.basketX = Math.min(w - 50, this.state.basketX + 300 * dt);
      if (g === 'fishing' && this.state.hookState === 'idle') this.state.boatX = Math.min(w - 60, this.state.boatX + 240 * dt);
    }

    if (g === 'cooking') {
      this.state.heatMeter = Math.min(100, this.state.heatMeter + 9 * dt);
      this.state.spawnTimer -= dt;
      if (this.state.spawnTimer <= 0) {
        this.state.spawnTimer = Math.max(0.35, 0.85 - this.level * 0.05);
        const bad = Math.random() < 0.24;
        const icons = ['🍓', '🍒', '🍯', '🍎'];
        this.state.items.push({
          x: 45 + Math.random() * 340,
          y: -20,
          vy: 120 + this.level * 22 + Math.random() * 45,
          bad,
          icon: bad ? '🌲' : icons[Math.floor(Math.random() * icons.length)]
        });
      }
      for (let i = this.state.items.length - 1; i >= 0; i--) {
        const it = this.state.items[i];
        it.y += it.vy * dt;
        if (Math.abs(it.y - 265) < 28 && Math.abs(it.x - this.state.potX) < 46) {
          if (it.bad) {
            this.score = Math.max(0, this.score - 10);
            sound.sfxMiss();
          } else {
            this.score += 18;
            this.level = 1 + Math.floor(this.score / 100);
            sound.sfxCoin();
          }
          this.state.items.splice(i, 1);
        } else if (it.y > h + 20) {
          this.state.items.splice(i, 1);
        }
      }
    } else if (g === 'gardening') {
      this.state.plots.forEach((p) => {
        if (p.stage === 1 || p.stage === 3) {
          p.timer += dt;
          if (Math.random() < 0.004 && !p.hasWeed) p.hasWeed = true;
          if (p.timer > 3.2 && !p.hasWeed) {
            p.stage = p.stage === 1 ? 2 : 4;
            p.timer = 0;
          }
        }
      });
    } else if (g === 'obstacle') {
      this.state.scrollX += 210 * dt;
      this.state.runnerY += this.state.runnerVy * dt;
      this.state.runnerVy += 920 * dt;
      if (this.state.runnerY >= 0) {
        this.state.runnerY = 0;
        this.state.runnerVy = 0;
        this.state.jumpsUsed = 0;
      }

      this.state.spawnTimer -= dt;
      if (this.state.spawnTimer <= 0) {
        this.state.spawnTimer = Math.max(0.75, 1.45 - this.level * 0.08);
        this.state.obstacles.push({ x: w + 30, icon: Math.random() > 0.5 ? '🪵' : '🪨' });
        this.state.coins.push({ x: w + 110, y: 155 - Math.random() * 55, icon: '🍯' });
      }

      for (let i = this.state.obstacles.length - 1; i >= 0; i--) {
        const ob = this.state.obstacles[i];
        ob.x -= (215 + this.level * 18) * dt;
        if (Math.abs(ob.x - 95) < 26 && this.state.runnerY > -32) {
          this.score = Math.max(0, this.score - 8);
          sound.sfxMiss();
          this.state.obstacles.splice(i, 1);
        } else if (ob.x < -30) {
          this.score += 12;
          this.state.obstacles.splice(i, 1);
        }
      }

      for (let i = this.state.coins.length - 1; i >= 0; i--) {
        const cn = this.state.coins[i];
        cn.x -= (215 + this.level * 18) * dt;
        const ry = 235 + this.state.runnerY;
        if (Math.hypot(cn.x - 95, cn.y - ry) < 34) {
          this.score += 22;
          this.level = 1 + Math.floor(this.score / 110);
          sound.sfxCoin();
          this.state.coins.splice(i, 1);
        } else if (cn.x < -30) {
          this.state.coins.splice(i, 1);
        }
      }
    } else if (g === 'hideseek') {
      if (this.state.phase === 'preview') {
        this.state.phaseTimer -= dt;
        if (this.state.phaseTimer <= 0) {
          this.state.bushes.forEach((b) => (b.revealed = false));
          this.state.phase = 'guessing';
        }
      }
    } else if (g === 'fishing') {
      this.state.fishes.forEach((f) => {
        f.x += f.vx * dt;
        if (f.x < 30 || f.x > w - 30) f.vx *= -1;
      });
      if (this.state.hookState === 'dropping') {
        this.state.hookY += 230 * dt;
        this.state.fishes.forEach((f) => {
          if (!this.state.caughtItem && Math.hypot(f.x - this.state.boatX, f.y - this.state.hookY) < 26) {
            this.state.caughtItem = f;
            this.state.hookState = 'reeling';
          }
        });
        if (this.state.hookY >= h - 25) {
          this.state.hookState = 'reeling';
        }
      } else if (this.state.hookState === 'reeling') {
        this.state.hookY -= 260 * dt;
        if (this.state.caughtItem) {
          this.state.caughtItem.x = this.state.boatX;
          this.state.caughtItem.y = this.state.hookY + 12;
        }
        if (this.state.hookY <= 75) {
          this.state.hookY = 75;
          this.state.hookState = 'idle';
          if (this.state.caughtItem) {
            this.score = Math.max(0, this.score + this.state.caughtItem.points);
            if (this.state.caughtItem.points > 0) sound.sfxCoin();
            else sound.sfxMiss();
            this.state.caughtItem.x = Math.random() * w;
            this.state.caughtItem.y = 135 + Math.random() * 160;
            this.state.caughtItem = null;
            this.level = 1 + Math.floor(this.score / 100);
          }
        }
      }
    } else if (g === 'collecting') {
      this.state.spawnTimer -= dt;
      if (this.state.spawnTimer <= 0) {
        this.state.spawnTimer = Math.max(0.32, 0.78 - this.level * 0.05);
        const bad = Math.random() < 0.22;
        const goods = ['🌰', '⭐', '🍓', '🍯'];
        this.state.falling.push({
          x: 40 + Math.random() * (w - 80),
          y: -20,
          vy: 130 + this.level * 24 + Math.random() * 40,
          bad,
          icon: bad ? '🌵' : goods[Math.floor(Math.random() * goods.length)]
        });
      }
      for (let i = this.state.falling.length - 1; i >= 0; i--) {
        const it = this.state.falling[i];
        it.y += it.vy * dt;
        if (Math.abs(it.y - 270) < 28 && Math.abs(it.x - this.state.basketX) < 46) {
          if (it.bad) {
            this.score = Math.max(0, this.score - 12);
            sound.sfxMiss();
          } else {
            this.score += 20;
            this.level = 1 + Math.floor(this.score / 100);
            sound.sfxCoin();
          }
          this.state.falling.splice(i, 1);
        } else if (it.y > h + 20) {
          this.state.falling.splice(i, 1);
        }
      }
    }
  }

  renderGame() {
    if (!this.ctx) return;
    const ctx = this.ctx;
    const w = this.canvas.width;
    const h = this.canvas.height;
    const g = this.activeGameId;

    ctx.clearRect(0, 0, w, h);

    if (g === 'cooking') {
      // Warm kitchen backdrop
      ctx.fillStyle = '#fff3e0';
      ctx.fillRect(0, 0, w, h);
      ctx.fillStyle = '#d7ccc8';
      ctx.fillRect(0, 285, w, 45);

      // Falling berries
      ctx.font = '28px sans-serif';
      ctx.textAlign = 'center';
      this.state.items.forEach((it) => {
        ctx.fillText(it.icon, it.x, it.y);
      });

      // Copper Jam Pot
      ctx.fillStyle = '#d81b60';
      ctx.beginPath();
      ctx.arc(this.state.potX, 265, 36, 0, Math.PI, false);
      ctx.fill();
      ctx.fillStyle = '#ff80ab';
      ctx.fillRect(this.state.potX - 38, 255, 76, 12);
      ctx.font = '24px sans-serif';
      ctx.fillText('🍲', this.state.potX, 275);

      // Stir Meter on Right
      ctx.fillStyle = '#4e342e';
      ctx.fillRect(435, 45, 75, 255);
      ctx.fillStyle = this.state.heatMeter > 75 ? '#e53935' : '#43a047';
      const mh = (this.state.heatMeter / 100) * 160;
      ctx.fillRect(455, 215 - mh, 35, mh);

      ctx.fillStyle = '#ffca28';
      ctx.fillRect(442, 232, 62, 52);
      ctx.fillStyle = '#3e2723';
      ctx.font = 'bold 13px Inter, sans-serif';
      ctx.fillText('STIR!', 473, 263);
    } else if (g === 'gardening') {
      ctx.fillStyle = '#a5d6a7';
      ctx.fillRect(0, 0, w, h);

      this.state.plots.forEach((p) => {
        ctx.fillStyle = '#6d4c41';
        ctx.beginPath();
        ctx.arc(p.x, p.y, 44, 0, Math.PI * 2);
        ctx.fill();

        ctx.font = '30px sans-serif';
        ctx.textAlign = 'center';
        const stageIcons = ['🕳️', '🌱', '💧', '🌿', '🍓'];
        ctx.fillText(p.hasWeed ? '🥀' : stageIcons[p.stage], p.x, p.y + 8);

        ctx.font = 'bold 11px Inter, sans-serif';
        ctx.fillStyle = '#ffffff';
        const labels = ['Tap: Plant', 'Growing...', 'Tap: Water!', 'Ripening...', 'Tap: Harvest!'];
        ctx.fillText(p.hasWeed ? 'Pull Weed!' : labels[p.stage], p.x, p.y + 36);
      });
    } else if (g === 'painting') {
      ctx.fillStyle = '#f3e5f5';
      ctx.fillRect(0, 0, w, h);

      // Left Reference Target Mini-Preview
      ctx.fillStyle = '#4a148c';
      ctx.font = 'bold 12px Inter, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('Target Art', 85, 38);

      for (let r = 0; r < 6; r++) {
        for (let c = 0; c < 6; c++) {
          ctx.fillStyle = this.state.palette[this.state.targetPattern[r][c]];
          ctx.fillRect(32 + c * 18, 48 + r * 18, 17, 17);
        }
      }

      // Main 6x6 Interactive Canvas
      const startX = 185;
      const startY = 42;
      const cell = 36;
      for (let r = 0; r < 6; r++) {
        for (let c = 0; c < 6; c++) {
          ctx.fillStyle = this.state.palette[this.state.userGrid[r][c]];
          ctx.fillRect(startX + c * cell, startY + r * cell, cell - 2, cell - 2);
        }
      }

      // Color Palette Selector
      this.state.palette.forEach((col, idx) => {
        const px = 95 + idx * 58;
        const py = 292;
        ctx.beginPath();
        ctx.arc(px, py, idx === this.state.selectedColorIdx ? 21 : 16, 0, Math.PI * 2);
        ctx.fillStyle = col;
        ctx.fill();
        ctx.lineWidth = idx === this.state.selectedColorIdx ? 4 : 2;
        ctx.strokeStyle = idx === this.state.selectedColorIdx ? '#111827' : '#9ca3af';
        ctx.stroke();
      });
    } else if (g === 'memory') {
      ctx.fillStyle = '#fff8e1';
      ctx.fillRect(0, 0, w, h);
      const cols = 4;
      this.state.deck.forEach((card, i) => {
        const r = Math.floor(i / cols);
        const c = i % cols;
        const cx = 105 + c * 110;
        const cy = 78 + r * 88;
        ctx.fillStyle = card.matched ? '#81c784' : (card.flipped ? '#ffffff' : '#ff8f00');
        ctx.fillRect(cx - 42, cy - 34, 84, 68);
        ctx.strokeStyle = '#5d4037';
        ctx.lineWidth = 3;
        ctx.strokeRect(cx - 42, cy - 34, 84, 68);

        ctx.font = '30px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(card.flipped || card.matched ? card.icon : '🐾', cx, cy + 10);
      });
    } else if (g === 'obstacle') {
      // Sky & Forest Trail
      ctx.fillStyle = '#b3e5fc';
      ctx.fillRect(0, 0, w, 255);
      ctx.fillStyle = '#66bb6a';
      ctx.fillRect(0, 255, w, 75);

      ctx.font = '34px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('👧', 95, 245 + this.state.runnerY);

      this.state.obstacles.forEach((ob) => {
        ctx.fillText(ob.icon, ob.x, 248);
      });
      this.state.coins.forEach((cn) => {
        ctx.fillText(cn.icon, cn.x, cn.y);
      });
    } else if (g === 'hideseek') {
      ctx.fillStyle = '#c8e6c9';
      ctx.fillRect(0, 0, w, h);

      ctx.fillStyle = '#1b5e20';
      ctx.font = 'bold 16px Inter, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(
        this.state.phase === 'preview' ? 'Watch closely where Masha & Panda hide!' : 'Tap the 2 bushes hiding your friends!',
        w / 2,
        55
      );

      this.state.bushes.forEach((b) => {
        ctx.font = '54px sans-serif';
        ctx.fillText('🌳', b.x, b.y);
        if (b.revealed && b.hasFriend) {
          ctx.font = '36px sans-serif';
          ctx.fillText('👧', b.x, b.y - 42);
        }
      });
    } else if (g === 'fishing') {
      ctx.fillStyle = '#e1f5fe';
      ctx.fillRect(0, 0, w, 90);
      ctx.fillStyle = '#0288d1';
      ctx.fillRect(0, 90, w, h - 90);

      // Bear's Boat
      ctx.font = '34px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('🐻🛶', this.state.boatX, 82);

      // Fishing Line
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(this.state.boatX, 75);
      ctx.lineTo(this.state.boatX, this.state.hookY);
      ctx.stroke();

      ctx.font = '20px sans-serif';
      ctx.fillText('🪝', this.state.boatX, this.state.hookY + 10);

      // Swimming Fish
      ctx.font = '28px sans-serif';
      this.state.fishes.forEach((f) => {
        ctx.fillText(f.icon, f.x, f.y);
      });
    } else if (g === 'collecting') {
      ctx.fillStyle = '#fff9c4';
      ctx.fillRect(0, 0, w, h);
      ctx.fillStyle = '#8d6e63';
      ctx.fillRect(0, 290, w, 40);

      ctx.font = '28px sans-serif';
      ctx.textAlign = 'center';
      this.state.falling.forEach((it) => {
        ctx.fillText(it.icon, it.x, it.y);
      });

      ctx.font = '38px sans-serif';
      ctx.fillText('🧺', this.state.basketX, 278);
    }
  }

  updateHUD() {
    const scoreEl = document.getElementById('mg-score-val');
    const levelEl = document.getElementById('mg-level-val');
    const timeEl = document.getElementById('mg-time-val');
    if (scoreEl) scoreEl.textContent = String(this.score);
    if (levelEl) levelEl.textContent = String(this.level);
    if (timeEl) timeEl.textContent = `${Math.ceil(this.timeLeft)}s`;
  }

  finishMinigame() {
    this.stop();
    if (window.gameApp) {
      window.gameApp.onMinigameCompleted(this.activeGameId, this.score, this.level);
    }
  }
}
