/**
 * Suesa AI - JavaScript Controller & Android Bridge Interface
 */

// Global State
const state = {
  isListening: false,
  isSpeaking: false,
  isGenerating: false,
  currentSessionId: null,
  attachedImage: null, // { base64: string, mimeType: string, name: string }
  preferences: {
    customApiKey: "",
    ttsAutoSpeak: false,
    speechRate: 1.0,
    webSearchEnabled: true
  }
};

// Check if native Android Bridge is available
const isNativeBridgeAvailable = () => typeof window.Suesa !== 'undefined';

// Safe Native Caller
const NativeBridge = {
  sendMessage: (text, imageBase64) => {
    if (isNativeBridgeAvailable()) {
      window.Suesa.sendMessage(text, imageBase64);
    } else {
      console.log("[Bridge Mock] sendMessage:", text);
      simulateAssistantResponse(text);
    }
  },
  startVoice: () => {
    if (isNativeBridgeAvailable()) {
      window.Suesa.startVoice();
    } else {
      console.log("[Bridge Mock] startVoice");
      state.isListening = true;
      updateVoiceStateUI(true, false);
      setTimeout(() => {
        window.onSpeechRecognized("Bugün hava nasıl?", true);
      }, 2500);
    }
  },
  stopVoice: () => {
    if (isNativeBridgeAvailable()) {
      window.Suesa.stopVoice();
    } else {
      console.log("[Bridge Mock] stopVoice");
      state.isListening = false;
      updateVoiceStateUI(false, false);
    }
  },
  speakText: (text) => {
    if (isNativeBridgeAvailable()) {
      window.Suesa.speakText(text);
    } else {
      console.log("[Bridge Mock] speakText:", text);
      state.isSpeaking = true;
      updateVoiceStateUI(false, true);
      setTimeout(() => {
        state.isSpeaking = false;
        updateVoiceStateUI(false, false);
      }, 3000);
    }
  },
  stopSpeaking: () => {
    if (isNativeBridgeAvailable()) {
      window.Suesa.stopSpeaking();
    } else {
      state.isSpeaking = false;
      updateVoiceStateUI(false, false);
    }
  },
  sendCommand: (cmd) => {
    if (isNativeBridgeAvailable()) {
      return window.Suesa.sendCommand(cmd);
    } else {
      console.log("[Bridge Mock] sendCommand:", cmd);
      return JSON.stringify({ success: true, message: cmd + " çalıştırıldı." });
    }
  },
  openCamera: () => {
    if (isNativeBridgeAvailable()) {
      window.Suesa.openCamera();
    } else {
      console.log("[Bridge Mock] openCamera");
      alert("Kamera başlatılıyor...");
    }
  },
  selectFile: () => {
    if (isNativeBridgeAvailable()) {
      window.Suesa.selectFile();
    } else {
      console.log("[Bridge Mock] selectFile");
      document.getElementById('hiddenFileInput').click();
    }
  },
  getPreferences: () => {
    if (isNativeBridgeAvailable()) {
      try {
        return JSON.parse(window.Suesa.getPreferences());
      } catch (e) {
        return state.preferences;
      }
    }
    return state.preferences;
  },
  savePreferences: (prefs) => {
    if (isNativeBridgeAvailable()) {
      return window.Suesa.savePreferences(JSON.stringify(prefs));
    }
    state.preferences = prefs;
    return true;
  },
  getSessions: () => {
    if (isNativeBridgeAvailable()) {
      try {
        return JSON.parse(window.Suesa.getSessions());
      } catch (e) {
        return [];
      }
    }
    return [{ id: 1, title: "Genel Sohbet", lastTimestamp: Date.now() }];
  },
  loadSession: (sessionId) => {
    if (isNativeBridgeAvailable()) {
      try {
        return JSON.parse(window.Suesa.loadSession(sessionId));
      } catch (e) {
        return [];
      }
    }
    return [];
  },
  createNewSession: () => {
    if (isNativeBridgeAvailable()) {
      try {
        return JSON.parse(window.Suesa.createNewSession());
      } catch (e) {
        return { id: Date.now(), title: "Yeni Sohbet" };
      }
    }
    return { id: Date.now(), title: "Yeni Sohbet" };
  },
  deleteSession: (id) => {
    if (isNativeBridgeAvailable()) {
      return window.Suesa.deleteSession(id);
    }
    return true;
  },
  clearAllHistory: () => {
    if (isNativeBridgeAvailable()) {
      return window.Suesa.clearAllHistory();
    }
    return true;
  },
  checkPermissions: () => {
    if (isNativeBridgeAvailable()) {
      try {
        return JSON.parse(window.Suesa.checkPermissions());
      } catch (e) {
        return {};
      }
    }
    return {
      "android.permission.RECORD_AUDIO": { granted: true, displayName: "Mikrofon", description: "Sesli iletişim için." },
      "android.permission.CAMERA": { granted: true, displayName: "Kamera", description: "Fotoğraf çekmek için." },
      "android.permission.READ_CONTACTS": { granted: true, displayName: "Rehber", description: "Kişi aramak için." },
      "android.permission.CALL_PHONE": { granted: true, displayName: "Telefon", description: "Arama yapmak için." }
    };
  },
  requestPermission: (permKey) => {
    if (isNativeBridgeAvailable()) {
      window.Suesa.requestPermission(permKey);
    } else {
      alert("İzin isteği gönderildi: " + permKey);
    }
  },
  testApiKey: (apiKey) => {
    if (isNativeBridgeAvailable()) {
      window.Suesa.testApiKey(apiKey);
    } else {
      alert("API anahtarı kaydedildi ve bağlantı başarılı.");
    }
  }
};

// UI Elements
const elements = {
  statusDot: document.getElementById('statusDot'),
  statusText: document.getElementById('statusText'),
  orbContainer: document.getElementById('orbContainer'),
  heroStage: document.getElementById('heroStage'),
  messagesStream: document.getElementById('messagesStream'),
  chatInput: document.getElementById('chatInput'),
  sendBtn: document.getElementById('sendBtn'),
  micBtn: document.getElementById('micBtn'),
  attachBtn: document.getElementById('attachBtn'),
  attachMenu: document.getElementById('attachMenu'),
  cameraOptionBtn: document.getElementById('cameraOptionBtn'),
  galleryOptionBtn: document.getElementById('galleryOptionBtn'),
  attachmentPreview: document.getElementById('attachmentPreview'),
  previewImage: document.getElementById('previewImage'),
  removeAttachmentBtn: document.getElementById('removeAttachmentBtn'),
  settingsBtn: document.getElementById('settingsBtn'),
  historyBtn: document.getElementById('historyBtn'),
  settingsModal: document.getElementById('settingsModal'),
  closeSettingsBtn: document.getElementById('closeSettingsBtn'),
  historyModal: document.getElementById('historyModal'),
  closeHistoryBtn: document.getElementById('closeHistoryBtn'),
  apiKeyInput: document.getElementById('apiKeyInput'),
  testApiBtn: document.getElementById('testApiBtn'),
  autoTtsSwitch: document.getElementById('autoTtsSwitch'),
  speechRateSelect: document.getElementById('speechRateSelect'),
  webSearchSwitch: document.getElementById('webSearchSwitch'),
  clearHistoryBtn: document.getElementById('clearHistoryBtn'),
  permissionsList: document.getElementById('permissionsList'),
  sessionsList: document.getElementById('sessionsList'),
  newChatBtn: document.getElementById('newChatBtn'),
  thinkingBox: document.getElementById('thinkingBox'),
  thinkingText: document.getElementById('thinkingText')
};

// Initialize App
document.addEventListener('DOMContentLoaded', () => {
  setupEventListeners();
  loadInitialData();
});

function setupEventListeners() {
  // Orb Click -> Toggles Voice Recognition
  elements.orbContainer.addEventListener('click', () => {
    if (state.isListening) {
      NativeBridge.stopVoice();
    } else {
      NativeBridge.startVoice();
    }
  });

  // Mic Button Click
  elements.micBtn.addEventListener('click', () => {
    if (state.isListening) {
      NativeBridge.stopVoice();
    } else {
      NativeBridge.startVoice();
    }
  });

  // Chat Input Auto-Resize & Submit on Enter (without Shift)
  elements.chatInput.addEventListener('input', () => {
    elements.chatInput.style.height = 'auto';
    elements.chatInput.style.height = Math.min(elements.chatInput.scrollHeight, 100) + 'px';
    elements.sendBtn.disabled = elements.chatInput.value.trim().length === 0 && !state.attachedImage;
  });

  elements.chatInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  });

  // Send Button
  elements.sendBtn.addEventListener('click', handleSend);

  // Attach Menu Toggle
  elements.attachBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    elements.attachMenu.classList.toggle('open');
  });

  document.addEventListener('click', (e) => {
    if (!elements.attachMenu.contains(e.target) && e.target !== elements.attachBtn) {
      elements.attachMenu.classList.remove('open');
    }
  });

  elements.cameraOptionBtn.addEventListener('click', () => {
    elements.attachMenu.classList.remove('open');
    NativeBridge.openCamera();
  });

  elements.galleryOptionBtn.addEventListener('click', () => {
    elements.attachMenu.classList.remove('open');
    NativeBridge.selectFile();
  });

  elements.removeAttachmentBtn.addEventListener('click', () => {
    state.attachedImage = null;
    elements.attachmentPreview.style.display = 'none';
    elements.previewImage.src = '';
    elements.sendBtn.disabled = elements.chatInput.value.trim().length === 0;
  });

  // Quick Chips
  document.querySelectorAll('.chip-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const prompt = btn.getAttribute('data-prompt');
      if (prompt) {
        elements.chatInput.value = prompt;
        handleSend();
      }
    });
  });

  // Settings Modal
  elements.settingsBtn.addEventListener('click', openSettings);
  elements.closeSettingsBtn.addEventListener('click', () => elements.settingsModal.classList.remove('open'));
  elements.settingsModal.addEventListener('click', (e) => {
    if (e.target === elements.settingsModal) elements.settingsModal.classList.remove('open');
  });

  // History Modal
  elements.historyBtn.addEventListener('click', openHistory);
  elements.closeHistoryBtn.addEventListener('click', () => elements.historyModal.classList.remove('open'));
  elements.historyModal.addEventListener('click', (e) => {
    if (e.target === elements.historyModal) elements.historyModal.classList.remove('open');
  });

  elements.newChatBtn.addEventListener('click', () => {
    elements.historyModal.classList.remove('open');
    const newSession = NativeBridge.createNewSession();
    state.currentSessionId = newSession.id;
    elements.messagesStream.innerHTML = '';
    elements.heroStage.classList.remove('collapsed');
    elements.heroStage.style.display = 'flex';
  });

  // Settings Actions
  elements.testApiBtn.addEventListener('click', () => {
    const key = elements.apiKeyInput.value.trim();
    saveCurrentSettings();
    NativeBridge.testApiKey(key);
  });

  elements.autoTtsSwitch.addEventListener('change', saveCurrentSettings);
  elements.speechRateSelect.addEventListener('change', saveCurrentSettings);
  elements.webSearchSwitch.addEventListener('change', saveCurrentSettings);

  elements.clearHistoryBtn.addEventListener('click', () => {
    if (confirm("Tüm sohbet geçmişini silmek istediğinize emin misiniz?")) {
      NativeBridge.clearAllHistory();
      elements.messagesStream.innerHTML = '';
      elements.heroStage.classList.remove('collapsed');
      elements.heroStage.style.display = 'flex';
      elements.settingsModal.classList.remove('open');
    }
  });

  const defaultAssistantBtn = document.getElementById('defaultAssistantBtn');
  if (defaultAssistantBtn) {
    defaultAssistantBtn.addEventListener('click', () => {
      NativeBridge.sendCommand('open_default_assistant_settings');
    });
  }

  // Handle mobile virtual keyboard via visualViewport API
  if (window.visualViewport) {
    const handleVpResize = () => {
      const vp = window.visualViewport;
      const appContainer = document.querySelector('.app-container');
      if (appContainer && vp) {
        appContainer.style.height = vp.height + 'px';
      }
    };
    window.visualViewport.addEventListener('resize', handleVpResize);
  }

  elements.chatInput.addEventListener('focus', () => {
    setTimeout(() => {
      elements.chatInput.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }, 250);
  });
}

function loadInitialData() {
  const prefs = NativeBridge.getPreferences();
  if (prefs) {
    state.preferences = { ...state.preferences, ...prefs };
    elements.apiKeyInput.value = state.preferences.customApiKey || '';
    elements.autoTtsSwitch.checked = !!state.preferences.ttsAutoSpeak;
    elements.speechRateSelect.value = state.preferences.speechRate || "1.0";
    elements.webSearchSwitch.checked = state.preferences.webSearchEnabled !== false;
  }

  // Load active sessions
  const sessions = NativeBridge.getSessions();
  if (sessions && sessions.length > 0) {
    state.currentSessionId = sessions[0].id;
    loadSessionMessages(sessions[0].id);
  }
}

function handleSend() {
  const text = elements.chatInput.value.trim();
  if (!text && !state.attachedImage) return;

  const imageBase64 = state.attachedImage ? state.attachedImage.base64 : null;
  const imagePreviewUrl = state.attachedImage ? state.previewImage.src : null;

  // Add User Message to UI
  renderMessage({
    role: 'user',
    content: text,
    imagePreview: imagePreviewUrl,
    timestamp: Date.now()
  });

  // Collapse Hero Stage to focus on chat
  elements.heroStage.classList.add('collapsed');

  // Clear Input
  elements.chatInput.value = '';
  elements.chatInput.style.height = 'auto';
  elements.attachmentPreview.style.display = 'none';
  elements.previewImage.src = '';
  elements.sendBtn.disabled = true;

  // Show thinking state
  showThinkingIndicator("Suesa düşünüyor...");

  // Send via Native Bridge
  NativeBridge.sendMessage(text, imageBase64);

  // Clear attached image
  state.attachedImage = null;
}

function renderMessage(msg) {
  const item = document.createElement('div');
  item.className = `message-item ${msg.role}`;

  let imageHtml = '';
  if (msg.imagePreview || msg.imageUri) {
    const src = msg.imagePreview || msg.imageUri;
    imageHtml = `<img src="${src}" class="message-image-preview" alt="Ekli Görsel" />`;
  }

  let formattedContent = formatMarkdown(msg.content);

  let sourceHtml = '';
  if (msg.sourceTitle) {
    const linkAttr = msg.sourceUrl ? `href="${msg.sourceUrl}" target="_blank"` : '';
    sourceHtml = `
      <a class="source-badge" ${linkAttr}>
        <span>🔍 Kaynak: ${msg.sourceTitle}</span>
      </a>
    `;
  }

  let actionsHtml = '';
  if (msg.role === 'assistant') {
    actionsHtml = `
      <div class="message-actions">
        <button class="msg-action-btn speak-msg-btn" data-text="${encodeURIComponent(msg.content)}">
          🔊 Dinle
        </button>
        <button class="msg-action-btn copy-msg-btn" data-text="${encodeURIComponent(msg.content)}">
          📋 Kopyala
        </button>
      </div>
    `;
  }

  item.innerHTML = `
    <div class="message-bubble">
      ${imageHtml}
      <div class="message-text">${formattedContent}</div>
      ${sourceHtml}
    </div>
    ${actionsHtml}
  `;

  elements.messagesStream.appendChild(item);
  scrollToBottom();

  // Attach Action Listeners
  if (msg.role === 'assistant') {
    const speakBtn = item.querySelector('.speak-msg-btn');
    const copyBtn = item.querySelector('.copy-msg-btn');

    if (speakBtn) {
      speakBtn.addEventListener('click', () => {
        const rawText = decodeURIComponent(speakBtn.getAttribute('data-text'));
        if (state.isSpeaking) {
          NativeBridge.stopSpeaking();
          speakBtn.innerHTML = '🔊 Dinle';
        } else {
          NativeBridge.speakText(rawText);
          speakBtn.innerHTML = '⏹️ Durdur';
        }
      });
    }

    if (copyBtn) {
      copyBtn.addEventListener('click', () => {
        const rawText = decodeURIComponent(copyBtn.getAttribute('data-text'));
        navigator.clipboard.writeText(rawText).then(() => {
          copyBtn.innerHTML = '✓ Kopyalandı';
          setTimeout(() => { copyBtn.innerHTML = '📋 Kopyala'; }, 2000);
        });
      });
    }
  }
}

function showThinkingIndicator(text) {
  elements.thinkingBox.style.display = 'flex';
  elements.thinkingText.innerText = text || "Düşünüyor...";
  elements.orbContainer.className = 'orb-container thinking';
  elements.statusDot.className = 'status-dot thinking';
  elements.statusText.innerText = text || "Düşünüyor";
  scrollToBottom();
}

function hideThinkingIndicator() {
  elements.thinkingBox.style.display = 'none';
  if (!state.isListening && !state.isSpeaking) {
    elements.orbContainer.className = 'orb-container';
    elements.statusDot.className = 'status-dot';
    elements.statusText.innerText = "Hazır";
  }
}

function updateVoiceStateUI(isListening, isSpeaking) {
  state.isListening = isListening;
  state.isSpeaking = isSpeaking;

  if (isListening) {
    elements.orbContainer.className = 'orb-container listening';
    elements.statusDot.className = 'status-dot listening';
    elements.statusText.innerText = "Dinliyor...";
    elements.micBtn.classList.add('active');
  } else if (isSpeaking) {
    elements.orbContainer.className = 'orb-container speaking';
    elements.statusDot.className = 'status-dot speaking';
    elements.statusText.innerText = "Suesa Konuşuyor";
    elements.micBtn.classList.remove('active');
  } else {
    elements.orbContainer.className = 'orb-container';
    elements.statusDot.className = 'status-dot';
    elements.statusText.innerText = "Hazır";
    elements.micBtn.classList.remove('active');
  }
}

function scrollToBottom() {
  setTimeout(() => {
    elements.messagesStream.scrollTop = elements.messagesStream.scrollHeight;
    window.scrollTo(0, document.body.scrollHeight);
  }, 50);
}

function formatMarkdown(text) {
  if (!text) return '';
  let escaped = text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");

  // Bold
  escaped = escaped.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
  // Italic
  escaped = escaped.replace(/\*(.*?)\*/g, '<em>$1</em>');
  // Code block
  escaped = escaped.replace(/```([\s\S]*?)```/g, '<pre><code>$1</code></pre>');
  // Inline code
  escaped = escaped.replace(/`([^`]+)`/g, '<code>$1</code>');
  // Line breaks
  escaped = escaped.replace(/\n/g, '<br/>');

  return escaped;
}

function openSettings() {
  const perms = NativeBridge.checkPermissions();
  renderPermissionsList(perms);
  elements.settingsModal.classList.add('open');
}

function openHistory() {
  const sessions = NativeBridge.getSessions();
  renderSessionsList(sessions);
  elements.historyModal.classList.add('open');
}

function saveCurrentSettings() {
  const updated = {
    customApiKey: elements.apiKeyInput.value.trim(),
    ttsAutoSpeak: elements.autoTtsSwitch.checked,
    speechRate: parseFloat(elements.speechRateSelect.value) || 1.0,
    webSearchEnabled: elements.webSearchSwitch.checked
  };
  NativeBridge.savePreferences(updated);
}

function renderPermissionsList(perms) {
  elements.permissionsList.innerHTML = '';
  if (!perms) return;

  for (const [key, item] of Object.entries(perms)) {
    const row = document.createElement('div');
    row.className = 'permission-item';
    row.innerHTML = `
      <div>
        <div style="font-weight:600; font-size:13.5px; color:#f5f5f7;">${item.displayName}</div>
        <div style="font-size:11.5px; color:#a1a1aa;">${item.description}</div>
      </div>
      <div>
        ${item.granted
          ? '<span class="perm-badge granted">✓ İzin Verildi</span>'
          : `<button class="btn-primary" style="padding:4px 10px; font-size:12px;" onclick="NativeBridge.requestPermission('${key}')">İzin Ver</button>`
        }
      </div>
    `;
    elements.permissionsList.appendChild(row);
  }
}

function renderSessionsList(sessions) {
  elements.sessionsList.innerHTML = '';
  if (!sessions || sessions.length === 0) {
    elements.sessionsList.innerHTML = '<div style="color:#71717a; font-size:13px; text-align:center; padding:12px;">Henüz sohbet geçmişi yok.</div>';
    return;
  }

  sessions.forEach(s => {
    const item = document.createElement('div');
    item.className = 'history-item';
    const dateStr = new Date(s.lastTimestamp || Date.now()).toLocaleDateString('tr-TR');
    item.innerHTML = `
      <div style="flex:1;" onclick="selectSession(${s.id})">
        <div class="history-item-title">${s.title || 'Sohbet'}</div>
        <div class="history-item-date">${dateStr}</div>
      </div>
      <button class="icon-btn" style="color:#ef4444;" onclick="event.stopPropagation(); deleteSessionItem(${s.id})">
        🗑️
      </button>
    `;
    elements.sessionsList.appendChild(item);
  });
}

window.selectSession = function(sessionId) {
  state.currentSessionId = sessionId;
  elements.historyModal.classList.remove('open');
  loadSessionMessages(sessionId);
};

window.deleteSessionItem = function(sessionId) {
  NativeBridge.deleteSession(sessionId);
  openHistory();
  if (state.currentSessionId === sessionId) {
    elements.messagesStream.innerHTML = '';
    elements.heroStage.classList.remove('collapsed');
    elements.heroStage.style.display = 'flex';
  }
};

function loadSessionMessages(sessionId) {
  const msgs = NativeBridge.loadSession(sessionId);
  elements.messagesStream.innerHTML = '';
  if (msgs && msgs.length > 0) {
    elements.heroStage.classList.add('collapsed');
    msgs.forEach(m => renderMessage(m));
  } else {
    elements.heroStage.classList.remove('collapsed');
    elements.heroStage.style.display = 'flex';
  }
}

// ----------------------------------------------------
// Global Bridge Callbacks invoked by Android MainActivity
// ----------------------------------------------------

window.onSuesaStateChanged = function(stateJson) {
  try {
    const data = typeof stateJson === 'string' ? JSON.parse(stateJson) : stateJson;
    if (data.status) {
      elements.statusText.innerText = data.status;
      if (data.status.includes("kontrol") || data.status.includes("Düşünüyor")) {
        showThinkingIndicator(data.status);
      }
    }
  } catch (e) {
    console.error("onSuesaStateChanged error", e);
  }
};

window.onSuesaMessageReceived = function(msgJson) {
  hideThinkingIndicator();
  try {
    const msg = typeof msgJson === 'string' ? JSON.parse(msgJson) : msgJson;
    renderMessage(msg);
  } catch (e) {
    console.error("onSuesaMessageReceived error", e);
  }
};

window.onSpeechRecognized = function(text, isFinal) {
  elements.chatInput.value = text;
  elements.chatInput.dispatchEvent(new Event('input'));
  if (isFinal && text.trim().length > 0) {
    handleSend();
  }
};

window.onVoiceListeningChanged = function(isListening) {
  updateVoiceStateUI(isListening, state.isSpeaking);
};

window.onVoiceSpeakingChanged = function(isSpeaking) {
  updateVoiceStateUI(state.isListening, isSpeaking);
};

window.onImageSelected = function(base64Data, mimeType, fileName) {
  state.attachedImage = {
    base64: base64Data,
    mimeType: mimeType || 'image/jpeg',
    name: fileName || 'Görsel'
  };
  elements.previewImage.src = `data:${mimeType || 'image/jpeg'};base64,${base64Data}`;
  elements.attachmentPreview.style.display = 'flex';
  elements.sendBtn.disabled = false;
};

window.onPermissionsUpdated = function(permsJson) {
  try {
    const perms = typeof permsJson === 'string' ? JSON.parse(permsJson) : permsJson;
    renderPermissionsList(perms);
  } catch (e) {
    console.error("onPermissionsUpdated error", e);
  }
};

// Simulation for browser testing without Android
function simulateAssistantResponse(userText) {
  setTimeout(() => {
    hideThinkingIndicator();
    let reply = "Merhaba! Ben Suesa AI. Android telefonunda sana yardımcı olmak için hazırım. Ne yapmak istersin?";
    const lower = userText.toLowerCase().trim();

    if (lower.includes("youtube")) {
      reply = "YouTube uygulamasını açıyorum.";
    } else if (lower.includes("kamera") || lower.includes("fotoğraf")) {
      reply = "Kamerayı açıyorum.";
    } else if (lower.includes("hava")) {
      reply = "Bulunduğun bölge için hava durumu kontrol ediliyor:\n• Durum: Güneşli ve Açık ☀️\n• Sıcaklık: 22°C\n• Nem: %45";
    } else if (lower === "merhaba" || lower.startsWith("merhaba ") || lower === "selam") {
      reply = "Merhaba! 👋 Nasıl yardımcı olabilirim?";
    } else if (lower.includes("sen kimsin") || lower.includes("adın ne") || lower.includes("ismin ne")) {
      reply = "Ben Suesa AI! 🌟 Android telefonun için tasarlanmış kişisel yapay zekâ asistanıyım. Telefonunda arama yapabilir, uygulamaları açabilir ve sorularını yanıtlayabilirim.";
    } else if (lower.includes("nasılsın") || lower.includes("naber")) {
      reply = "Harikayım, teşekkürler! Enerjim yerinde. Sen nasılsın, bugün senin için ne yapabilirim? 😊";
    } else if (lower.includes("2+2") || lower.includes("2 + 2")) {
      reply = "4";
    } else if (lower.includes("hikaye") || lower.includes("hikâye") || lower.includes("masal")) {
      reply = "**Yıldızların Ötesindeki Sır**\n\nKüçük bir köyde yaşayan genç bir saat ustası olan Eren, geceleri gökyüzünü izlemeyi çok severdi. Bir gün eski bir saatin çarklarını temizlerken kasanın içine gizlenmiş pirinç bir anahtar ve soluk bir harita buldu...\n\nEren gözlemevine gittiğinde teleskobun kilitli yuvasına anahtarı yerleştirdi. Kubbe yavaşça açıldı ve evrenin büyüleyici yıldız dansı gözlerinin önüne serildi.";
    } else if (lower.includes("fıkra")) {
      reply = "Temel bir gün uçağa binmiş. Yanındaki adama sormuş: 'Hemşerim bu uçak nereye gidiyor?' Adam: 'Ankara'ya,' demiş. Temel hayretle başını sallamış: 'Ula şu teknolojiye bak, ben arkada oturuyorum İstanbul'a gidiyorum, sen önde oturuyorsun Ankara'ya gidiyorsun!' 😄";
    } else if (lower.includes("minecraft")) {
      reply = "Minecraft'ta 1.18 ve sonraki sürümlerde elmaslar en yoğun olarak **Y: -58** katmanında bulunur! Netherit için ise Nether boyutunda Y: 15 seviyelerinde Antik Kalıntı arayabilirsin.";
    }

    renderMessage({
      role: 'assistant',
      content: reply,
      timestamp: Date.now()
    });
  }, 900);
}
