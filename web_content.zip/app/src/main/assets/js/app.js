// app.js - School Management Application Logic
// Government Boys Primary School Sultan Matt Uchari (EMIS: 06994)

const App = {
  currentView: 'dashboard',
  selectedStudentId: null,
  cachedSettings: null,
  cachedStudents: [],
  cachedClasses: [],
  cachedExams: [],
  cachedSubjects: [],
  tempBackupData: null,

  async init() {
    try {
      await SchoolDB.init();
      await this.loadInitialData();
      this.setupEventListeners();
      this.setupPwa();
      this.navigate('dashboard');
      console.log('App successfully initialized.');
    } catch (err) {
      console.error('Initialization error:', err);
      this.showToast('Error initializing database: ' + err.message, 'error');
    }
  },

  async loadInitialData() {
    this.cachedSettings = await SchoolDB.getSettings();
    this.cachedStudents = await SchoolDB.getAllStudents();
    this.cachedClasses = await SchoolDB.getAllClasses();
    this.cachedExams = await SchoolDB.getAllExams();
    this.cachedSubjects = await SchoolDB.getAllSubjects();

    this.populateStudentDropdowns();
    this.populateExamDropdowns();
    this.renderSettingsForm();
  },

  setupEventListeners() {
    // Navigation items
    document.querySelectorAll('.sidebar-nav .nav-item').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const view = btn.getAttribute('data-view');
        if (view) this.navigate(view);
      });
    });

    // Mobile menu toggle
    const toggleBtn = document.getElementById('menuToggleBtn');
    const sidebar = document.getElementById('appSidebar');
    const backdrop = document.getElementById('sidebarBackdrop');

    if (toggleBtn && sidebar && backdrop) {
      toggleBtn.addEventListener('click', () => {
        sidebar.classList.toggle('mobile-open');
        backdrop.classList.toggle('active');
      });

      backdrop.addEventListener('click', () => {
        sidebar.classList.remove('mobile-open');
        backdrop.classList.remove('active');
      });
    }

    // Default dates
    const todayStr = new Date().toISOString().split('T')[0];
    const attDatePicker = document.getElementById('attDatePicker');
    if (attDatePicker) {
      attDatePicker.value = todayStr;
      attDatePicker.addEventListener('change', () => this.loadAttendanceRoster());
    }

    const attClassSelect = document.getElementById('attClassSelect');
    if (attClassSelect) {
      attClassSelect.addEventListener('change', () => this.loadAttendanceRoster());
    }

    const btnMarkAllP = document.getElementById('btnMarkAllP');
    if (btnMarkAllP) btnMarkAllP.addEventListener('click', () => this.markAllAttendance('P'));

    const btnMarkAllA = document.getElementById('btnMarkAllA');
    if (btnMarkAllA) btnMarkAllA.addEventListener('click', () => this.markAllAttendance('A'));

    const btnSaveAtt = document.getElementById('btnSaveAttendance');
    if (btnSaveAtt) btnSaveAtt.addEventListener('click', () => this.saveAttendanceRoster());

    // Attendance Reports Sub-tabs
    document.querySelectorAll('.rep-subtab-pane').forEach(p => p.style.display = 'none');
    const defaultSubtab = document.getElementById('subtab-rep-daily');
    if (defaultSubtab) defaultSubtab.style.display = 'block';

    document.querySelectorAll('[data-subtab]').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('[data-subtab]').forEach(b => b.classList.remove('active-subtab'));
        btn.classList.add('active-subtab');
        const target = btn.getAttribute('data-subtab');
        document.querySelectorAll('.rep-subtab-pane').forEach(p => p.style.display = 'none');
        const pane = document.getElementById('subtab-' + target);
        if (pane) pane.style.display = 'block';
      });
    });

    // Setup dates for reports
    const repDailyDate = document.getElementById('repDailyDate');
    if (repDailyDate) repDailyDate.value = todayStr;

    const repAllDailyDate = document.getElementById('repAllDailyDate');
    if (repAllDailyDate) repAllDailyDate.value = todayStr;

    // Report buttons
    this.bindReportButtons();

    // Student filters
    const sSearch = document.getElementById('studentSearchInput');
    if (sSearch) sSearch.addEventListener('input', () => this.filterStudents());

    const sFilter = document.getElementById('studentClassFilter');
    if (sFilter) sFilter.addEventListener('change', () => this.filterStudents());

    // Fee filters
    const fClass = document.getElementById('feeClassFilter');
    if (fClass) fClass.addEventListener('change', () => this.renderFeesTable());

    const fMonth = document.getElementById('feeMonthFilter');
    if (fMonth) fMonth.addEventListener('change', () => this.renderFeesTable());

    const fYear = document.getElementById('feeYearFilter');
    if (fYear) fYear.addEventListener('input', () => this.renderFeesTable());

    // Results buttons & events
    const btnEnterMarks = document.getElementById('btnEnterMarksModal');
    if (btnEnterMarks) btnEnterMarks.addEventListener('click', () => this.openEnterMarksModal());

    const resClass = document.getElementById('resClassSelect');
    if (resClass) resClass.addEventListener('change', () => this.renderResultsTable());

    const resExam = document.getElementById('resExamSelect');
    if (resExam) resExam.addEventListener('change', () => this.renderResultsTable());
  },

  setupPwa() {
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('./sw.js').then(reg => {
        console.log('Offline ServiceWorker registered successfully:', reg.scope);
      }).catch(err => {
        console.warn('ServiceWorker registration error:', err);
      });
    }

    let deferredPrompt;
    window.addEventListener('beforeinstallprompt', (e) => {
      e.preventDefault();
      deferredPrompt = e;
      const installBtn = document.getElementById('btnInstallPwa');
      if (installBtn) {
        installBtn.style.display = 'inline-flex';
        installBtn.onclick = () => {
          installBtn.style.display = 'none';
          deferredPrompt.prompt();
          deferredPrompt.userChoice.then(() => {
            deferredPrompt = null;
          });
        };
      }
    });
  },

  navigate(viewId) {
    this.currentView = viewId;

    // Update sidebar nav active state
    document.querySelectorAll('.sidebar-nav .nav-item').forEach(btn => {
      btn.classList.toggle('active', btn.getAttribute('data-view') === viewId);
    });

    // Close mobile drawer
    const sidebar = document.getElementById('appSidebar');
    const backdrop = document.getElementById('sidebarBackdrop');
    if (sidebar) sidebar.classList.remove('mobile-open');
    if (backdrop) backdrop.classList.remove('active');

    // Switch view DOM
    document.querySelectorAll('.app-view').forEach(view => {
      view.style.display = 'none';
    });

    const activeView = document.getElementById('view-' + viewId);
    if (activeView) {
      activeView.style.display = 'block';
    }

    // Update Topbar Title
    const titleMap = {
      'dashboard': 'School Administration Dashboard',
      'students': 'Student Management',
      'classes': 'Class Hierarchy Management',
      'attendance': 'Daily Attendance Register',
      'attendance-reports': 'Attendance Reports Center',
      'results': 'Examinations & Student Results',
      'fees': 'School Fee Management',
      'documents': 'Official Student Documents',
      'certificates': 'Gender-Based Certificates',
      'settings': 'School Settings & Head Teacher Profile',
      'backup': 'Offline Backup & Disaster Recovery'
    };
    const titleEl = document.getElementById('topbarTitle');
    if (titleEl) titleEl.textContent = titleMap[viewId] || 'Dashboard';

    // Route specific load
    switch (viewId) {
      case 'dashboard':
        this.renderDashboard();
        break;
      case 'students':
        this.renderStudentsTable();
        break;
      case 'classes':
        this.renderClassesTable();
        break;
      case 'attendance':
        this.loadAttendanceRoster();
        break;
      case 'results':
        this.renderResultsTable();
        break;
      case 'fees':
        this.renderFeesTable();
        break;
      case 'documents':
      case 'certificates':
        this.populateStudentDropdowns();
        break;
      case 'settings':
        this.renderSettingsForm();
        break;
    }
  },

  // ================= 1. DASHBOARD =================
  async renderDashboard() {
    const stats = await SchoolDB.getDashboardStats();

    // Fill counter values
    document.getElementById('dashTotalStudents').textContent = stats.totalStudents;
    document.getElementById('dashTotalClasses').textContent = stats.totalClasses;
    document.getElementById('dashTodayAttendance').textContent = `${stats.attendancePercentage}%`;
    document.getElementById('dashAttendanceSub').textContent = `${stats.todayPresent} present / ${stats.todayAbsent} absent`;
    document.getElementById('dashTotalResults').textContent = stats.totalResults;
    document.getElementById('dashFeesCollected').textContent = `Rs. ${stats.feesCollected.toLocaleString()}`;
    document.getElementById('dashFeesPending').textContent = `Rs. ${stats.feesPending.toLocaleString()}`;

    // Fill Class-wise table
    const tbody = document.getElementById('dashClassSummaryBody');
    if (!tbody) return;
    tbody.innerHTML = '';

    const todayStr = new Date().toISOString().split('T')[0];
    const classes = await SchoolDB.getAllClasses();

    for (let i = 0; i < classes.length; i++) {
      const cls = classes[i];
      const students = await SchoolDB.getStudentsByClass(cls.name);
      const attData = await SchoolDB.getAttendanceByClassAndDate(cls.name, todayStr);

      const presentCount = attData.records.filter(r => r.status === 'P').length;
      const absentCount = attData.records.filter(r => r.status === 'A').length;
      const pct = students.length > 0 ? Math.round((presentCount / students.length) * 100) : 0;

      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td style="font-weight:700; color:var(--text-muted);">${i + 1}</td>
        <td style="font-weight:700; color:var(--primary);">${cls.name}</td>
        <td><strong>${students.length}</strong> Students</td>
        <td>${attData.records.length > 0 ? `<span class="badge badge-paid">Marked</span>` : `<span class="badge badge-unpaid">Pending</span>`}</td>
        <td style="color:#16a34a; font-weight:700;">${presentCount}</td>
        <td style="color:#dc2626; font-weight:700;">${absentCount}</td>
        <td>
          <div style="display:flex; align-items:center; gap:8px;">
            <strong style="width:38px;">${pct}%</strong>
            <div style="flex:1; height:6px; background:#e2e8f0; border-radius:3px; overflow:hidden;">
              <div style="width:${pct}%; height:100%; background:var(--primary);"></div>
            </div>
          </div>
        </td>
        <td>
          <button class="btn btn-outline btn-sm" onclick="App.openClassAttendance('${cls.name}')">Mark</button>
        </td>
      `;
      tbody.appendChild(tr);
    }
  },

  openClassAttendance(className) {
    const classSel = document.getElementById('attClassSelect');
    if (classSel) classSel.value = className;
    this.navigate('attendance');
  },

  // ================= 2. STUDENT MANAGEMENT =================
  async renderStudentsTable(list = null) {
    const students = list || await SchoolDB.getAllStudents();
    const tbody = document.getElementById('studentsTableBody');
    if (!tbody) return;
    tbody.innerHTML = '';

    if (students.length === 0) {
      tbody.innerHTML = `<tr><td colspan="9" style="text-align:center; padding:30px; color:var(--text-muted);">No student records found.</td></tr>`;
      return;
    }

    students.forEach(s => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td>
          ${s.photo ? `<img src="${s.photo}" class="student-avatar" alt="${s.name}">` : `<div class="student-avatar" style="display:flex; align-items:center; justify-content:center; color:var(--text-muted); font-size:10px;">No Photo</div>`}
        </td>
        <td style="font-weight:700;">${s.rollNo || '-'}</td>
        <td style="color:var(--text-muted);">${s.admissionNo || '-'}</td>
        <td style="font-weight:700; color:var(--primary);">${s.name}</td>
        <td>${s.fatherName}</td>
        <td><span class="badge" style="background:#e0f2fe; color:#0369a1;">${s.className}</span></td>
        <td>${s.gender || 'Male'}</td>
        <td>${s.parentContact || '-'}</td>
        <td class="actions-col" style="text-align:right;">
          <button class="btn btn-outline btn-sm" onclick="App.viewStudentProfile(${s.id})" title="View Profile">View</button>
          <button class="btn btn-outline btn-sm" onclick="App.openEditStudentModal(${s.id})" title="Edit Student">Edit</button>
          <button class="btn btn-outline btn-sm" onclick="App.openChangeClassModal(${s.id})" title="Change Class">Promote</button>
          <button class="btn btn-danger btn-sm" onclick="App.openDeleteConfirm(${s.id}, 'student', '${s.name}')" title="Delete">Delete</button>
        </td>
      `;
      tbody.appendChild(tr);
    });
  },

  async filterStudents() {
    const term = (document.getElementById('studentSearchInput')?.value || '').toLowerCase();
    const cls = document.getElementById('studentClassFilter')?.value || '';

    let list = await SchoolDB.getAllStudents();
    if (cls) {
      list = list.filter(s => s.className === cls);
    }
    if (term) {
      list = list.filter(s =>
        (s.name && s.name.toLowerCase().includes(term)) ||
        (s.fatherName && s.fatherName.toLowerCase().includes(term)) ||
        (s.rollNo && s.rollNo.toLowerCase().includes(term)) ||
        (s.admissionNo && s.admissionNo.toLowerCase().includes(term))
      );
    }
    this.renderStudentsTable(list);
  },

  openAddStudentModal() {
    document.getElementById('studentModalTitle').textContent = 'Add New Student';
    document.getElementById('studentForm').reset();
    document.getElementById('studId').value = '';
    document.getElementById('studPhotoData').value = '';
    document.getElementById('studPhotoImg').style.display = 'none';
    document.getElementById('studPhotoPlaceholder').style.display = 'block';
    this.openModal('studentModal');
  },

  async openEditStudentModal(id) {
    const s = await SchoolDB.getStudentById(id);
    if (!s) return;

    document.getElementById('studentModalTitle').textContent = 'Edit Student Record';
    document.getElementById('studId').value = s.id;
    document.getElementById('studName').value = s.name;
    document.getElementById('studFatherName').value = s.fatherName;
    document.getElementById('studGender').value = s.gender || 'Male';
    document.getElementById('studDob').value = s.dob || '';
    document.getElementById('studClass').value = s.className;
    document.getElementById('studRollNo').value = s.rollNo || '';
    document.getElementById('studAdmNo').value = s.admissionNo || '';
    document.getElementById('studContact').value = s.parentContact || '';
    document.getElementById('studAddress').value = s.address || '';

    const photoDataEl = document.getElementById('studPhotoData');
    const photoImg = document.getElementById('studPhotoImg');
    const placeholder = document.getElementById('studPhotoPlaceholder');

    if (s.photo) {
      photoDataEl.value = s.photo;
      photoImg.src = s.photo;
      photoImg.style.display = 'block';
      placeholder.style.display = 'none';
    } else {
      photoDataEl.value = '';
      photoImg.style.display = 'none';
      placeholder.style.display = 'block';
    }

    this.openModal('studentModal');
  },

  handleStudentPhotoUpload(event) {
    const file = event.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      // Resize image for optimal IndexedDB storage
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const maxW = 300;
        const scale = Math.min(1, maxW / img.width);
        canvas.width = img.width * scale;
        canvas.height = img.height * scale;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        const dataUrl = canvas.toDataURL('image/jpeg', 0.85);

        document.getElementById('studPhotoData').value = dataUrl;
        const photoImg = document.getElementById('studPhotoImg');
        photoImg.src = dataUrl;
        photoImg.style.display = 'block';
        document.getElementById('studPhotoPlaceholder').style.display = 'none';
      };
      img.src = e.target.result;
    };
    reader.readAsDataURL(file);
  },

  async saveStudent(event) {
    event.preventDefault();
    const idVal = document.getElementById('studId').value;
    const student = {
      name: document.getElementById('studName').value.trim(),
      fatherName: document.getElementById('studFatherName').value.trim(),
      gender: document.getElementById('studGender').value,
      dob: document.getElementById('studDob').value,
      className: document.getElementById('studClass').value,
      rollNo: document.getElementById('studRollNo').value.trim(),
      admissionNo: document.getElementById('studAdmNo').value.trim(),
      parentContact: document.getElementById('studContact').value.trim(),
      address: document.getElementById('studAddress').value.trim(),
      photo: document.getElementById('studPhotoData').value || null
    };

    if (idVal) {
      student.id = parseInt(idVal, 10);
    }

    await SchoolDB.saveStudent(student);
    this.closeModal('studentModal');
    this.showToast('Student record saved successfully', 'success');
    await this.loadInitialData();
    this.renderStudentsTable();
  },

  async viewStudentProfile(id) {
    const s = await SchoolDB.getStudentById(id);
    if (!s) return;

    const body = document.getElementById('viewStudentBody');
    body.innerHTML = `
      <div style="display:flex; gap:20px; align-items:flex-start; margin-bottom:20px; flex-wrap:wrap;">
        <div style="width:120px; height:150px; border:1px solid var(--border-strong); border-radius:8px; overflow:hidden; background:#f8fafc; flex-shrink:0;">
          ${s.photo ? `<img src="${s.photo}" style="width:100%; height:100%; object-fit:cover;">` : `<div style="display:flex; align-items:center; justify-content:center; height:100%; color:var(--text-muted); font-size:11px;">No Photo</div>`}
        </div>
        <div style="flex:1;">
          <h2 style="font-size:20px; color:var(--primary); font-weight:800; margin-bottom:4px;">${s.name}</h2>
          <div style="font-size:14px; color:var(--text-muted); margin-bottom:12px;">S/O ${s.fatherName}</div>
          <div class="stats-grid" style="grid-template-columns: repeat(2, 1fr); gap:8px;">
            <div style="background:#f8fafc; padding:8px 12px; border-radius:6px;"><strong>Class:</strong> ${s.className}</div>
            <div style="background:#f8fafc; padding:8px 12px; border-radius:6px;"><strong>Roll#:</strong> ${s.rollNo}</div>
            <div style="background:#f8fafc; padding:8px 12px; border-radius:6px;"><strong>Admission#:</strong> ${s.admissionNo || '-'}</div>
            <div style="background:#f8fafc; padding:8px 12px; border-radius:6px;"><strong>Gender:</strong> ${s.gender || 'Male'}</div>
            <div style="background:#f8fafc; padding:8px 12px; border-radius:6px;"><strong>DOB:</strong> ${s.dob || '-'}</div>
            <div style="background:#f8fafc; padding:8px 12px; border-radius:6px;"><strong>Contact:</strong> ${s.parentContact || '-'}</div>
          </div>
          <div style="margin-top:10px; background:#f8fafc; padding:8px 12px; border-radius:6px;">
            <strong>Address:</strong> ${s.address || 'Village Sultan Matt Uchari, Barkhan'}
          </div>
        </div>
      </div>
      <div style="display:flex; gap:10px; flex-wrap:wrap; border-top:1px solid var(--border); padding-top:16px;">
        <button class="btn btn-primary btn-sm" onclick="App.generateStudentQuickID(${s.id})">Generate ID Card</button>
        <button class="btn btn-outline btn-sm" onclick="App.generateStudentQuickSLC(${s.id})">Leaving Certificate</button>
        <button class="btn btn-outline btn-sm" onclick="App.generateStudentQuickCC(${s.id})">Character Certificate</button>
      </div>
    `;

    this.openModal('viewStudentModal');
  },

  async openChangeClassModal(id) {
    const s = await SchoolDB.getStudentById(id);
    if (!s) return;
    document.getElementById('changeClassStudentId').value = s.id;
    document.getElementById('changeClassStudentName').textContent = `${s.name} (${s.className})`;
    document.getElementById('newClassSelect').value = s.className;
    document.getElementById('newClassRollNo').value = s.rollNo;
    this.openModal('changeClassModal');
  },

  async confirmChangeClass() {
    const id = parseInt(document.getElementById('changeClassStudentId').value, 10);
    const newClass = document.getElementById('newClassSelect').value;
    const newRoll = document.getElementById('newClassRollNo').value.trim();

    await SchoolDB.updateStudentClass(id, newClass, newRoll);
    this.closeModal('changeClassModal');
    this.showToast('Student class updated successfully', 'success');
    await this.loadInitialData();
    this.renderStudentsTable();
  },

  openDeleteConfirm(id, type, name) {
    document.getElementById('deleteTargetId').value = id;
    document.getElementById('deleteTargetType').value = type;
    document.getElementById('deleteConfirmMsg').textContent = `Are you sure you want to permanently delete "${name}"?`;
    this.openModal('deleteConfirmModal');
  },

  async executeDelete() {
    const id = parseInt(document.getElementById('deleteTargetId').value, 10);
    const type = document.getElementById('deleteTargetType').value;

    if (type === 'student') {
      await SchoolDB.deleteStudent(id);
      this.showToast('Student deleted successfully', 'success');
      await this.loadInitialData();
      this.renderStudentsTable();
    } else if (type === 'fee') {
      await SchoolDB.deleteFee(id);
      this.showToast('Fee record deleted', 'success');
      this.renderFeesTable();
    } else if (type === 'result') {
      await SchoolDB.deleteResult(id);
      this.showToast('Result entry deleted', 'success');
      this.renderResultsTable();
    }
    this.closeModal('deleteConfirmModal');
  },

  // ================= 3. CLASS MANAGEMENT =================
  async renderClassesTable() {
    const classes = await SchoolDB.getAllClasses();
    const tbody = document.getElementById('classesTableBody');
    if (!tbody) return;
    tbody.innerHTML = '';

    for (let i = 0; i < classes.length; i++) {
      const cls = classes[i];
      const students = await SchoolDB.getStudentsByClass(cls.name);

      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td style="font-weight:800; color:var(--primary); font-size:15px;">${cls.order}</td>
        <td style="font-weight:700; color:var(--primary);">${cls.name}</td>
        <td>${cls.section || 'A'}</td>
        <td>${cls.room || 'Room ' + cls.order}</td>
        <td><strong>${students.length}</strong> Enrolled Students</td>
        <td>
          <button class="btn btn-outline btn-sm" onclick="App.viewClassStudents('${cls.name}')">View Students</button>
          <button class="btn btn-primary btn-sm" onclick="App.openClassAttendance('${cls.name}')">Attendance</button>
        </td>
      `;
      tbody.appendChild(tr);
    }
  },

  viewClassStudents(className) {
    const filter = document.getElementById('studentClassFilter');
    if (filter) filter.value = className;
    this.navigate('students');
    this.filterStudents();
  },

  // ================= 4. ATTENDANCE SYSTEM =================
  async loadAttendanceRoster() {
    const cls = document.getElementById('attClassSelect')?.value || 'Class 1';
    const date = document.getElementById('attDatePicker')?.value || new Date().toISOString().split('T')[0];

    const attData = await SchoolDB.getAttendanceByClassAndDate(cls, date);
    const tbody = document.getElementById('attRosterBody');
    if (!tbody) return;
    tbody.innerHTML = '';

    let pCount = 0, aCount = 0, lCount = 0;

    if (attData.records.length === 0) {
      tbody.innerHTML = `<tr><td colspan="4" style="text-align:center; padding:30px; color:var(--text-muted);">No students registered in ${cls}. Please add students first.</td></tr>`;
      document.getElementById('attCountTotal').textContent = '0';
      document.getElementById('attCountP').textContent = '0';
      document.getElementById('attCountA').textContent = '0';
      document.getElementById('attCountL').textContent = '0';
      return;
    }

    attData.records.forEach((r, idx) => {
      if (r.status === 'P') pCount++;
      else if (r.status === 'A') aCount++;
      else if (r.status === 'L') lCount++;

      const tr = document.createElement('tr');
      tr.setAttribute('data-student-id', r.studentId);
      tr.innerHTML = `
        <td style="font-weight:700;">${r.rollNo || (idx + 1)}</td>
        <td style="font-weight:700; color:var(--primary);">${r.studentName}</td>
        <td>${r.fatherName}</td>
        <td style="text-align:center;">
          <div class="att-btn-group">
            <button type="button" class="att-toggle ${r.status === 'P' ? 'selected-p' : ''}" onclick="App.setStudentAttStatus(this, 'P')">P</button>
            <button type="button" class="att-toggle ${r.status === 'A' ? 'selected-a' : ''}" onclick="App.setStudentAttStatus(this, 'A')">A</button>
            <button type="button" class="att-toggle ${r.status === 'L' ? 'selected-l' : ''}" onclick="App.setStudentAttStatus(this, 'L')">L</button>
          </div>
        </td>
      `;
      tbody.appendChild(tr);
    });

    document.getElementById('attCountTotal').textContent = attData.records.length;
    document.getElementById('attCountP').textContent = pCount;
    document.getElementById('attCountA').textContent = aCount;
    document.getElementById('attCountL').textContent = lCount;
  },

  setStudentAttStatus(btn, status) {
    const group = btn.closest('.att-btn-group');
    group.querySelectorAll('.att-toggle').forEach(b => {
      b.classList.remove('selected-p', 'selected-a', 'selected-l');
    });

    if (status === 'P') btn.classList.add('selected-p');
    else if (status === 'A') btn.classList.add('selected-a');
    else if (status === 'L') btn.classList.add('selected-l');

    this.updateAttendanceCounters();
  },

  markAllAttendance(status) {
    const tbody = document.getElementById('attRosterBody');
    if (!tbody) return;

    tbody.querySelectorAll('.att-btn-group').forEach(group => {
      group.querySelectorAll('.att-toggle').forEach(b => {
        b.classList.remove('selected-p', 'selected-a', 'selected-l');
      });
      const targetBtn = status === 'P' ? group.children[0] : status === 'A' ? group.children[1] : group.children[2];
      if (status === 'P') targetBtn.classList.add('selected-p');
      else if (status === 'A') targetBtn.classList.add('selected-a');
      else if (status === 'L') targetBtn.classList.add('selected-l');
    });

    this.updateAttendanceCounters();
  },

  updateAttendanceCounters() {
    let p = 0, a = 0, l = 0;
    document.querySelectorAll('#attRosterBody tr').forEach(row => {
      if (row.querySelector('.selected-p')) p++;
      else if (row.querySelector('.selected-a')) a++;
      else if (row.querySelector('.selected-l')) l++;
    });

    document.getElementById('attCountP').textContent = p;
    document.getElementById('attCountA').textContent = a;
    document.getElementById('attCountL').textContent = l;
  },

  async saveAttendanceRoster() {
    const cls = document.getElementById('attClassSelect').value;
    const date = document.getElementById('attDatePicker').value;
    const rows = document.querySelectorAll('#attRosterBody tr');

    const records = [];
    rows.forEach(row => {
      const studentId = parseInt(row.getAttribute('data-student-id'), 10);
      if (!studentId) return;

      let status = 'P';
      if (row.querySelector('.selected-a')) status = 'A';
      else if (row.querySelector('.selected-l')) status = 'L';

      const sName = row.children[1].textContent.trim();
      const fName = row.children[2].textContent.trim();
      const roll = row.children[0].textContent.trim();

      records.push({
        studentId,
        studentName: sName,
        fatherName: fName,
        rollNo: roll,
        status
      });
    });

    await SchoolDB.saveAttendance(cls, date, records);
    this.showToast(`Attendance for ${cls} on ${date} saved successfully`, 'success');
  },

  // ================= 5. ATTENDANCE REPORTS BINDINGS =================
  bindReportButtons() {
    // 1. Daily Report
    document.getElementById('btnGenDailyRep')?.addEventListener('click', () => this.generateDailyAttendanceView());
    document.getElementById('btnPrintDailyRep')?.addEventListener('click', () => window.print());
    document.getElementById('btnPdfDailyRep')?.addEventListener('click', () => this.downloadDailyAttendancePDF());

    // 2. Monthly Report
    document.getElementById('btnGenMonthlyRep')?.addEventListener('click', () => this.generateMonthlyAttendanceView());
    document.getElementById('btnPrintMonthlyRep')?.addEventListener('click', () => window.print());
    document.getElementById('btnPdfMonthlyRep')?.addEventListener('click', () => this.downloadMonthlyAttendancePDF());

    // 3. Individual History
    document.getElementById('repIndClassSelect')?.addEventListener('change', (e) => this.populateIndStudents(e.target.value));
    document.getElementById('btnGenIndRep')?.addEventListener('click', () => this.generateIndividualAttendanceView());
    document.getElementById('btnPrintIndRep')?.addEventListener('click', () => window.print());
    document.getElementById('btnPdfIndRep')?.addEventListener('click', () => this.downloadIndividualAttendancePDF());

    // 4. All Classes Daily
    document.getElementById('btnGenAllDailyRep')?.addEventListener('click', () => this.generateAllClassesDailyView());
    document.getElementById('btnPrintAllDailyRep')?.addEventListener('click', () => window.print());
    document.getElementById('btnPdfAllDailyRep')?.addEventListener('click', () => this.downloadAllClassesDailyPDF());

    // 5. All Classes Monthly
    document.getElementById('btnGenAllMonthlyRep')?.addEventListener('click', () => this.generateAllClassesMonthlyView());
    document.getElementById('btnPrintAllMonthlyRep')?.addEventListener('click', () => window.print());
    document.getElementById('btnPdfAllMonthlyRep')?.addEventListener('click', () => this.downloadAllClassesMonthlyPDF());

    this.populateIndStudents('Class 5');
  },

  async populateIndStudents(className) {
    const select = document.getElementById('repIndStudentSelect');
    if (!select) return;
    select.innerHTML = '';

    const students = await SchoolDB.getStudentsByClass(className);
    students.forEach(s => {
      const opt = document.createElement('option');
      opt.value = s.id;
      opt.textContent = `${s.rollNo ? '#' + s.rollNo + ' ' : ''}${s.name} (S/O ${s.fatherName})`;
      select.appendChild(opt);
    });
  },

  async generateDailyAttendanceView() {
    const cls = document.getElementById('repDailyClass').value;
    const date = document.getElementById('repDailyDate').value;
    const att = await SchoolDB.getAttendanceByClassAndDate(cls, date);

    const container = document.getElementById('repDailyContainer');
    container.innerHTML = `
      <div class="document-preview-box">
        <div style="text-align:center; margin-bottom:16px;">
          <h3 style="color:var(--primary); font-size:16px;">GOVERNMENT BOYS PRIMARY SCHOOL SULTAN MATT UCHARI</h3>
          <div style="font-size:12px; color:var(--text-muted);">EMIS: 06994  |  District Barkhan, Balochistan</div>
          <h4 style="margin-top:6px; font-size:14px;">DAILY ATTENDANCE REPORT - ${cls}</h4>
          <div style="font-size:12px; font-weight:600;">Date: ${date}</div>
        </div>

        <div style="display:flex; justify-content:space-around; background:#f8fafc; padding:10px; border-radius:6px; margin-bottom:14px; font-size:12.5px; font-weight:700;">
          <div>Total: ${att.summary.total}</div>
          <div style="color:#16a34a;">Present: ${att.summary.present}</div>
          <div style="color:#dc2626;">Absent: ${att.summary.absent}</div>
          <div style="color:#d97706;">Leave: ${att.summary.leave}</div>
          <div style="color:var(--primary);">Rate: ${att.summary.percentage}%</div>
        </div>

        <table class="data-table">
          <thead>
            <tr>
              <th style="width:40px;">#</th>
              <th>Roll#</th>
              <th>Student Name</th>
              <th>Father Name</th>
              <th style="text-align:center;">Status</th>
            </tr>
          </thead>
          <tbody>
            ${att.records.map((r, i) => `
              <tr>
                <td>${i + 1}</td>
                <td>${r.rollNo || '-'}</td>
                <td style="font-weight:700;">${r.studentName}</td>
                <td>${r.fatherName}</td>
                <td style="text-align:center;">
                  <span class="badge ${r.status === 'P' ? 'badge-present' : r.status === 'A' ? 'badge-absent' : 'badge-leave'}">
                    ${r.status === 'P' ? 'PRESENT' : r.status === 'A' ? 'ABSENT' : 'LEAVE'}
                  </span>
                </td>
              </tr>
            `).join('')}
          </tbody>
        </table>

        <div style="margin-top:30px; display:flex; justify-content:space-between; align-items:flex-end;">
          <div style="font-size:11px; color:var(--text-muted);">Generated on: ${new Date().toLocaleDateString()}</div>
          <div style="text-align:center;">
            <div style="border-top:1px solid #000; width:160px; padding-top:4px; font-weight:700; font-size:12px;">HEAD TEACHER</div>
            <div style="font-size:11px;">SHOUKAT ALI</div>
          </div>
        </div>
      </div>
    `;
  },

  async downloadDailyAttendancePDF() {
    const cls = document.getElementById('repDailyClass').value;
    const date = document.getElementById('repDailyDate').value;
    const att = await SchoolDB.getAttendanceByClassAndDate(cls, date);
    const settings = await SchoolDB.getSettings();

    await PDFGen.generateDailyAttendancePDF(cls, date, att.records, att.summary, settings);
    this.showToast('Daily Attendance PDF generated successfully', 'success');
  },

  async generateMonthlyAttendanceView() {
    const cls = document.getElementById('repMonthlyClass').value;
    const month = document.getElementById('repMonthlyMonth').value;
    const year = parseInt(document.getElementById('repMonthlyYear').value, 10);
    const rep = await SchoolDB.getMonthlyAttendanceReport(cls, month, year);

    const monthNames = ['', 'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    const monthName = monthNames[parseInt(month, 10)];

    const container = document.getElementById('repMonthlyContainer');
    container.innerHTML = `
      <div class="document-preview-box">
        <div style="text-align:center; margin-bottom:16px;">
          <h3 style="color:var(--primary); font-size:16px;">GOVERNMENT BOYS PRIMARY SCHOOL SULTAN MATT UCHARI</h3>
          <div style="font-size:12px; color:var(--text-muted);">EMIS: 06994  |  District Barkhan, Balochistan</div>
          <h4 style="margin-top:6px; font-size:14px;">MONTHLY ATTENDANCE REGISTER - ${cls}</h4>
          <div style="font-size:12px; font-weight:600;">Month: ${monthName} ${year}</div>
        </div>

        <table class="data-table">
          <thead>
            <tr>
              <th style="width:40px;">#</th>
              <th>Roll#</th>
              <th>Student Name</th>
              <th>Father Name</th>
              <th>Days</th>
              <th>P</th>
              <th>A</th>
              <th>L</th>
              <th>Att %</th>
            </tr>
          </thead>
          <tbody>
            ${rep.map((r, i) => `
              <tr>
                <td>${i + 1}</td>
                <td>${r.rollNo || '-'}</td>
                <td style="font-weight:700;">${r.studentName}</td>
                <td>${r.fatherName}</td>
                <td>${r.totalDays}</td>
                <td style="color:#16a34a; font-weight:700;">${r.present}</td>
                <td style="color:#dc2626; font-weight:700;">${r.absent}</td>
                <td style="color:#d97706; font-weight:700;">${r.leave}</td>
                <td><strong>${r.percentage}%</strong></td>
              </tr>
            `).join('')}
          </tbody>
        </table>

        <div style="margin-top:30px; display:flex; justify-content:space-between; align-items:flex-end;">
          <div style="font-size:11px; color:var(--text-muted);">Generated on: ${new Date().toLocaleDateString()}</div>
          <div style="text-align:center;">
            <div style="border-top:1px solid #000; width:160px; padding-top:4px; font-weight:700; font-size:12px;">HEAD TEACHER</div>
            <div style="font-size:11px;">SHOUKAT ALI</div>
          </div>
        </div>
      </div>
    `;
  },

  async downloadMonthlyAttendancePDF() {
    const cls = document.getElementById('repMonthlyClass').value;
    const month = document.getElementById('repMonthlyMonth').value;
    const year = parseInt(document.getElementById('repMonthlyYear').value, 10);
    const rep = await SchoolDB.getMonthlyAttendanceReport(cls, month, year);
    const settings = await SchoolDB.getSettings();

    const monthNames = ['', 'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    const monthName = monthNames[parseInt(month, 10)];

    await PDFGen.generateMonthlyAttendancePDF(cls, monthName, year, rep, settings);
    this.showToast('Monthly Attendance PDF generated successfully', 'success');
  },

  async generateIndividualAttendanceView() {
    const studentId = parseInt(document.getElementById('repIndStudentSelect').value, 10);
    if (!studentId) return;

    const student = await SchoolDB.getStudentById(studentId);
    const data = await SchoolDB.getStudentAttendanceHistory(studentId);

    const container = document.getElementById('repIndContainer');
    container.innerHTML = `
      <div class="document-preview-box">
        <div style="text-align:center; margin-bottom:16px;">
          <h3 style="color:var(--primary); font-size:16px;">GOVERNMENT BOYS PRIMARY SCHOOL SULTAN MATT UCHARI</h3>
          <div style="font-size:12px; color:var(--text-muted);">EMIS: 06994  |  District Barkhan, Balochistan</div>
          <h4 style="margin-top:6px; font-size:14px;">STUDENT ATTENDANCE INDIVIDUAL DOSSIER</h4>
        </div>

        <div style="background:#f8fafc; padding:14px; border-radius:6px; margin-bottom:14px; display:flex; justify-content:space-between; flex-wrap:wrap; gap:10px;">
          <div>
            <div><strong>Student Name:</strong> ${student.name}</div>
            <div><strong>Father Name:</strong> ${student.fatherName}</div>
          </div>
          <div>
            <div><strong>Class:</strong> ${student.className} (Roll# ${student.rollNo})</div>
            <div><strong>Admission#:</strong> ${student.admissionNo || '-'}</div>
          </div>
          <div style="text-align:right;">
            <div>Total Days: <strong>${data.summary.total}</strong></div>
            <div style="color:var(--primary); font-weight:700;">Overall Rate: ${data.summary.percentage}%</div>
          </div>
        </div>

        <table class="data-table">
          <thead>
            <tr>
              <th style="width:40px;">#</th>
              <th>Date</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            ${data.history.map((h, i) => `
              <tr>
                <td>${i + 1}</td>
                <td>${h.date}</td>
                <td>
                  <span class="badge ${h.status === 'P' ? 'badge-present' : h.status === 'A' ? 'badge-absent' : 'badge-leave'}">
                    ${h.status === 'P' ? 'PRESENT' : h.status === 'A' ? 'ABSENT' : 'LEAVE'}
                  </span>
                </td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    `;
  },

  async downloadIndividualAttendancePDF() {
    const studentId = parseInt(document.getElementById('repIndStudentSelect').value, 10);
    if (!studentId) return;

    const student = await SchoolDB.getStudentById(studentId);
    const data = await SchoolDB.getStudentAttendanceHistory(studentId);
    const settings = await SchoolDB.getSettings();

    await PDFGen.generateIndividualAttendancePDF(student, data.history, data.summary, settings);
    this.showToast('Student Attendance PDF downloaded', 'success');
  },

  async generateAllClassesDailyView() {
    const date = document.getElementById('repAllDailyDate').value;
    const classes = await SchoolDB.getAllClasses();
    const container = document.getElementById('repAllDailyContainer');

    let html = `
      <div class="document-preview-box">
        <div style="text-align:center; margin-bottom:16px;">
          <h3 style="color:var(--primary); font-size:16px;">GOVERNMENT BOYS PRIMARY SCHOOL SULTAN MATT UCHARI</h3>
          <div style="font-size:12px; color:var(--text-muted);">EMIS: 06994  |  District Barkhan, Balochistan</div>
          <h4 style="margin-top:6px; font-size:15px;">ALL CLASSES DAILY ATTENDANCE REPORT</h4>
          <div style="font-weight:700;">Date: ${date}</div>
        </div>
    `;

    for (let i = 0; i < classes.length; i++) {
      const cls = classes[i];
      const att = await SchoolDB.getAttendanceByClassAndDate(cls.name, date);

      html += `
        <div style="margin-top:20px; border-top:2px solid var(--primary); padding-top:12px;">
          <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;">
            <h5 style="color:var(--primary); font-size:14px;">${i + 1}. Class: ${cls.name}</h5>
            <div style="font-size:12px;">Present: <strong>${att.summary.present}</strong> | Absent: <strong>${att.summary.absent}</strong> | Rate: <strong>${att.summary.percentage}%</strong></div>
          </div>
          <table class="data-table">
            <thead>
              <tr>
                <th style="width:30px;">#</th>
                <th>Roll#</th>
                <th>Student Name</th>
                <th>Father Name</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              ${att.records.length > 0 ? att.records.map((r, idx) => `
                <tr>
                  <td>${idx + 1}</td>
                  <td>${r.rollNo || '-'}</td>
                  <td style="font-weight:700;">${r.studentName}</td>
                  <td>${r.fatherName}</td>
                  <td>
                    <span class="badge ${r.status === 'P' ? 'badge-present' : r.status === 'A' ? 'badge-absent' : 'badge-leave'}">
                      ${r.status === 'P' ? 'PRESENT' : r.status === 'A' ? 'ABSENT' : 'LEAVE'}
                    </span>
                  </td>
                </tr>
              `).join('') : `<tr><td colspan="5" style="text-align:center; color:var(--text-muted);">No students in this class</td></tr>`}
            </tbody>
          </table>
        </div>
      `;
    }

    html += `
        <div style="margin-top:30px; text-align:right;">
          <div style="display:inline-block; text-align:center;">
            <div style="border-top:1px solid #000; width:160px; padding-top:4px; font-weight:700; font-size:12px;">HEAD TEACHER</div>
            <div style="font-size:11px;">SHOUKAT ALI</div>
          </div>
        </div>
      </div>
    `;

    container.innerHTML = html;
  },

  async downloadAllClassesDailyPDF() {
    const date = document.getElementById('repAllDailyDate').value;
    const classes = await SchoolDB.getAllClasses();
    const settings = await SchoolDB.getSettings();

    const classGroups = [];
    for (let i = 0; i < classes.length; i++) {
      const cls = classes[i];
      const att = await SchoolDB.getAttendanceByClassAndDate(cls.name, date);
      classGroups.push({
        className: cls.name,
        records: att.records,
        summary: att.summary
      });
    }

    await PDFGen.generateAllClassesDailyPDF(date, classGroups, settings);
    this.showToast('All Classes Daily Attendance PDF generated', 'success');
  },

  async generateAllClassesMonthlyView() {
    const month = document.getElementById('repAllMonthlyMonth').value;
    const year = parseInt(document.getElementById('repAllMonthlyYear').value, 10);
    const classes = await SchoolDB.getAllClasses();
    const container = document.getElementById('repAllMonthlyContainer');

    const monthNames = ['', 'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    const monthName = monthNames[parseInt(month, 10)];

    let html = `
      <div class="document-preview-box">
        <div style="text-align:center; margin-bottom:16px;">
          <h3 style="color:var(--primary); font-size:16px;">GOVERNMENT BOYS PRIMARY SCHOOL SULTAN MATT UCHARI</h3>
          <div style="font-size:12px; color:var(--text-muted);">EMIS: 06994  |  District Barkhan, Balochistan</div>
          <h4 style="margin-top:6px; font-size:15px;">ALL CLASSES MONTHLY ATTENDANCE REGISTER</h4>
          <div style="font-weight:700;">Month: ${monthName} ${year}</div>
        </div>
    `;

    for (let i = 0; i < classes.length; i++) {
      const cls = classes[i];
      const rep = await SchoolDB.getMonthlyAttendanceReport(cls.name, month, year);

      html += `
        <div style="margin-top:20px; border-top:2px solid var(--primary); padding-top:12px;">
          <h5 style="color:var(--primary); font-size:14px; margin-bottom:8px;">${i + 1}. Class: ${cls.name}</h5>
          <table class="data-table">
            <thead>
              <tr>
                <th style="width:30px;">#</th>
                <th>Roll#</th>
                <th>Student Name</th>
                <th>Father Name</th>
                <th>Days</th>
                <th>P</th>
                <th>A</th>
                <th>L</th>
                <th>Att %</th>
              </tr>
            </thead>
            <tbody>
              ${rep.length > 0 ? rep.map((r, idx) => `
                <tr>
                  <td>${idx + 1}</td>
                  <td>${r.rollNo || '-'}</td>
                  <td style="font-weight:700;">${r.studentName}</td>
                  <td>${r.fatherName}</td>
                  <td>${r.totalDays}</td>
                  <td style="color:#16a34a; font-weight:700;">${r.present}</td>
                  <td style="color:#dc2626; font-weight:700;">${r.absent}</td>
                  <td style="color:#d97706; font-weight:700;">${r.leave}</td>
                  <td><strong>${r.percentage}%</strong></td>
                </tr>
              `).join('') : `<tr><td colspan="9" style="text-align:center; color:var(--text-muted);">No students enrolled</td></tr>`}
            </tbody>
          </table>
        </div>
      `;
    }

    html += `</div>`;
    container.innerHTML = html;
  },

  async downloadAllClassesMonthlyPDF() {
    const month = document.getElementById('repAllMonthlyMonth').value;
    const year = parseInt(document.getElementById('repAllMonthlyYear').value, 10);
    const classes = await SchoolDB.getAllClasses();
    const settings = await SchoolDB.getSettings();

    const monthNames = ['', 'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    const monthName = monthNames[parseInt(month, 10)];

    const classGroups = [];
    for (let i = 0; i < classes.length; i++) {
      const cls = classes[i];
      const dataList = await SchoolDB.getMonthlyAttendanceReport(cls.name, month, year);

      let totalP = 0, totalA = 0;
      dataList.forEach(d => {
        totalP += d.present;
        totalA += d.absent;
      });
      const avg = dataList.length > 0 ? Math.round(dataList.reduce((acc, c) => acc + c.percentage, 0) / dataList.length) : 0;

      classGroups.push({
        className: cls.name,
        dataList,
        summary: {
          totalStudents: dataList.length,
          totalPresent: totalP,
          totalAbsent: totalA,
          classAverage: avg
        }
      });
    }

    await PDFGen.generateAllClassesMonthlyPDF(monthName, year, classGroups, settings);
    this.showToast('All Classes Monthly Attendance PDF downloaded', 'success');
  },

  // ================= 6. EXAMS & RESULTS =================
  populateExamDropdowns() {
    const resExamSelect = document.getElementById('resExamSelect');
    if (!resExamSelect) return;
    resExamSelect.innerHTML = '';

    this.cachedExams.forEach(e => {
      const opt = document.createElement('option');
      opt.value = e.name;
      opt.textContent = `${e.name} (${e.academicYear})`;
      resExamSelect.appendChild(opt);
    });
  },

  async renderResultsTable() {
    const exam = document.getElementById('resExamSelect')?.value || 'Mid Term Exam 2026';
    const cls = document.getElementById('resClassSelect')?.value || 'Class 5';

    const results = await SchoolDB.getResultsByExamAndClass(exam, cls);
    const tbody = document.getElementById('resultsTableBody');
    if (!tbody) return;
    tbody.innerHTML = '';

    if (results.length === 0) {
      tbody.innerHTML = `<tr><td colspan="9" style="text-align:center; padding:30px; color:var(--text-muted);">No result records found for ${exam} in ${cls}.</td></tr>`;
      return;
    }

    results.forEach(r => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td style="font-weight:700;">${r.rollNo || '-'}</td>
        <td style="font-weight:700; color:var(--primary);">${r.studentName}</td>
        <td>${r.fatherName}</td>
        <td>${r.totalMarks}</td>
        <td style="font-weight:700;">${r.totalObtained}</td>
        <td><strong>${r.percentage}%</strong></td>
        <td><span class="badge" style="background:#f1f5f9; color:var(--primary); font-weight:800;">${r.grade}</span></td>
        <td><span class="badge ${r.status === 'Pass' ? 'badge-pass' : 'badge-fail'}">${r.status}</span></td>
        <td class="actions-col" style="text-align:right;">
          <button class="btn btn-outline btn-sm" onclick="App.previewStudentResultCard(${r.id})">Result Card</button>
          <button class="btn btn-secondary btn-sm" onclick="App.downloadResultCardPDF(${r.id})">PDF</button>
          <button class="btn btn-danger btn-sm" onclick="App.openDeleteConfirm(${r.id}, 'result', '${r.studentName}')">Del</button>
        </td>
      `;
      tbody.appendChild(tr);
    });
  },

  async openEnterMarksModal() {
    const exam = document.getElementById('resExamSelect').value;
    const cls = document.getElementById('resClassSelect').value;

    document.getElementById('resExamNameDisplay').value = exam;

    const studentSelect = document.getElementById('resStudentSelect');
    studentSelect.innerHTML = '';

    const students = await SchoolDB.getStudentsByClass(cls);
    students.forEach(s => {
      const opt = document.createElement('option');
      opt.value = s.id;
      opt.textContent = `${s.rollNo ? '#' + s.rollNo + ' ' : ''}${s.name} (S/O ${s.fatherName})`;
      studentSelect.appendChild(opt);
    });

    this.renderMarksSubjectsInput();
    this.openModal('marksModal');
  },

  renderMarksSubjectsInput() {
    const tbody = document.getElementById('resSubjectsTbody');
    tbody.innerHTML = '';

    const subjects = this.cachedSubjects;
    subjects.forEach((sub, idx) => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td style="font-weight:600;">${sub.name}</td>
        <td><input type="number" class="form-control sub-total-mark" value="${sub.totalMarks}" style="width:90px;" oninput="App.calculateMarksLive()"></td>
        <td><input type="number" class="form-control sub-obt-mark" value="0" style="width:100px;" oninput="App.calculateMarksLive()"></td>
        <td class="sub-grade-display" style="font-weight:700;">-</td>
      `;
      tbody.appendChild(tr);
    });

    this.calculateMarksLive();
  },

  calculateMarksLive() {
    let totMarks = 0;
    let obtMarks = 0;

    const rows = document.querySelectorAll('#resSubjectsTbody tr');
    rows.forEach(r => {
      const t = parseFloat(r.querySelector('.sub-total-mark').value) || 0;
      const o = parseFloat(r.querySelector('.sub-obt-mark').value) || 0;
      totMarks += t;
      obtMarks += o;

      const subPct = t > 0 ? (o / t) * 100 : 0;
      r.querySelector('.sub-grade-display').textContent = SchoolDB.calculateGrade(subPct);
    });

    const pct = totMarks > 0 ? Math.round((obtMarks / totMarks) * 100) : 0;
    const grade = SchoolDB.calculateGrade(pct);
    const status = pct >= 40 ? 'Pass' : 'Fail';

    document.getElementById('resCalcTotal').textContent = totMarks;
    document.getElementById('resCalcObt').textContent = obtMarks;
    document.getElementById('resCalcPct').textContent = `${pct}%`;
    document.getElementById('resCalcGrade').textContent = grade;
    document.getElementById('resCalcStatus').textContent = status;
  },

  async saveResultRecord(event) {
    event.preventDefault();
    const studentId = parseInt(document.getElementById('resStudentSelect').value, 10);
    const student = await SchoolDB.getStudentById(studentId);
    const exam = document.getElementById('resExamSelect').value;
    const settings = await SchoolDB.getSettings();

    const subjects = [];
    let totMarks = 0;
    let obtMarks = 0;

    const rows = document.querySelectorAll('#resSubjectsTbody tr');
    rows.forEach(r => {
      const name = r.children[0].textContent.trim();
      const t = parseFloat(r.querySelector('.sub-total-mark').value) || 0;
      const o = parseFloat(r.querySelector('.sub-obt-mark').value) || 0;
      const subPct = t > 0 ? (o / t) * 100 : 0;

      totMarks += t;
      obtMarks += o;

      subjects.push({
        subjectName: name,
        totalMarks: t,
        obtainedMarks: o,
        grade: SchoolDB.calculateGrade(subPct)
      });
    });

    const pct = totMarks > 0 ? Math.round((obtMarks / totMarks) * 100) : 0;
    const grade = SchoolDB.calculateGrade(pct);
    const status = pct >= 40 ? 'Pass' : 'Fail';

    const resultRecord = {
      studentId: student.id,
      studentName: student.name,
      fatherName: student.fatherName,
      className: student.className,
      rollNo: student.rollNo,
      examName: exam,
      academicYear: settings.academicYear || '2026-2027',
      subjects,
      totalMarks: totMarks,
      totalObtained: obtMarks,
      percentage: pct,
      grade,
      status
    };

    await SchoolDB.saveResult(resultRecord);
    this.closeModal('marksModal');
    this.showToast('Student examination result saved successfully', 'success');
    this.renderResultsTable();
  },

  async previewStudentResultCard(resultId) {
    const r = await SchoolDB.getResultById(resultId);
    const student = await SchoolDB.getStudentById(r.studentId);
    const settings = await SchoolDB.getSettings();

    const modalTitle = document.getElementById('previewModalTitle');
    modalTitle.textContent = `Result Card: ${r.studentName}`;

    const body = document.getElementById('previewModalBody');
    body.innerHTML = `
      <div class="document-preview-box" style="border:2px solid var(--primary); padding:24px;">
        <div style="background:var(--primary); color:#fff; padding:16px; text-align:center; border-radius:4px; margin-bottom:12px;">
          <h2 style="font-size:18px; font-weight:800;">${settings.schoolName}</h2>
          <div style="font-size:12px; color:#fef08a; font-weight:700;">EMIS: ${settings.emis} | ${settings.location}</div>
          <div style="font-size:13px; font-weight:700; margin-top:4px;">ACADEMIC RESULT CARD</div>
        </div>

        <div style="display:flex; gap:20px; align-items:center; margin:16px 0; background:#f8fafc; padding:14px; border-radius:6px;">
          <div style="width:90px; height:110px; border:1px solid var(--border-strong); background:#fff; display:flex; align-items:center; justify-content:center; overflow:hidden;">
            ${student?.photo ? `<img src="${student.photo}" style="width:100%; height:100%; object-fit:cover;">` : `<span style="font-size:10px; color:var(--text-muted);">Photo</span>`}
          </div>
          <div style="flex:1;">
            <div style="font-size:15px; margin-bottom:4px;">Student Name: <strong><u>${r.studentName.toUpperCase()}</u></strong></div>
            <div style="font-size:14px; margin-bottom:4px;">Father Name: <strong><u>${r.fatherName.toUpperCase()}</u></strong></div>
            <div style="display:flex; gap:24px; font-size:13px; color:var(--text-muted); margin-top:6px;">
              <div>Class: <strong>${r.className}</strong></div>
              <div>Roll No: <strong>${r.rollNo || '-'}</strong></div>
              <div>Exam: <strong>${r.examName}</strong></div>
              <div>Session: <strong>${r.academicYear}</strong></div>
            </div>
          </div>
        </div>

        <table class="data-table" style="margin-bottom:16px;">
          <thead>
            <tr>
              <th style="width:40px;">#</th>
              <th>Subject Name</th>
              <th>Total Marks</th>
              <th>Obtained Marks</th>
              <th>Grade</th>
              <th>Remarks</th>
            </tr>
          </thead>
          <tbody>
            ${r.subjects.map((s, i) => `
              <tr>
                <td>${i + 1}</td>
                <td style="font-weight:600;">${s.subjectName}</td>
                <td>${s.totalMarks}</td>
                <td style="font-weight:700;">${s.obtainedMarks}</td>
                <td><strong>${s.grade}</strong></td>
                <td>${s.obtainedMarks >= s.totalMarks * 0.4 ? `<span style="color:#16a34a; font-weight:700;">Pass</span>` : `<span style="color:#dc2626; font-weight:700;">Fail</span>`}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>

        <div style="background:#f8fafc; padding:14px; border-radius:6px; display:flex; justify-content:space-between; align-items:center; font-weight:800; font-size:14px;">
          <div>Total: ${r.totalMarks}</div>
          <div>Obtained: ${r.totalObtained}</div>
          <div>Percentage: ${r.percentage}%</div>
          <div>Grade: ${r.grade}</div>
          <div>Result: <span style="color:${r.status === 'Pass' ? '#16a34a' : '#dc2626'};">${r.status.toUpperCase()}</span></div>
        </div>

        <div style="margin-top:36px; display:flex; justify-content:space-between; align-items:flex-end;">
          <div style="border:2px solid var(--accent); border-radius:50%; width:70px; height:70px; display:flex; align-items:center; justify-content:center; text-align:center; font-size:9px; font-weight:700; color:var(--primary);">
            OFFICIAL<br>SEAL
          </div>
          <div style="text-align:center;">
            ${settings.signature ? `<img src="${settings.signature}" style="height:35px; margin-bottom:4px;"><br>` : ''}
            <div style="border-top:1px solid #000; width:180px; padding-top:4px; font-weight:700;">HEAD TEACHER</div>
            <div style="font-size:12px;">${settings.headTeacher}</div>
          </div>
        </div>
      </div>
    `;

    document.getElementById('btnPreviewPrint').onclick = () => window.print();
    document.getElementById('btnPreviewDownload').onclick = () => this.downloadResultCardPDF(resultId);

    this.openModal('documentPreviewModal');
  },

  async downloadResultCardPDF(resultId) {
    const r = await SchoolDB.getResultById(resultId);
    const student = await SchoolDB.getStudentById(r.studentId);
    const settings = await SchoolDB.getSettings();

    await PDFGen.generateResultCardPDF(r, student, settings, settings.signature);
    this.showToast('Result Card PDF downloaded successfully', 'success');
  },

  async downloadAllClassesResultPDF() {
    const exam = document.getElementById('resExamSelect')?.value || 'Mid Term Exam 2026';
    const settings = await SchoolDB.getSettings();
    const classes = await SchoolDB.getAllClasses();

    const classReports = [];
    for (let i = 0; i < classes.length; i++) {
      const cls = classes[i];
      const results = await SchoolDB.getResultsByExamAndClass(exam, cls.name);

      const passed = results.filter(r => r.status === 'Pass').length;
      const failed = results.filter(r => r.status === 'Fail').length;
      const avg = results.length > 0 ? Math.round(results.reduce((acc, c) => acc + c.percentage, 0) / results.length) : 0;
      const highest = results.length > 0 ? Math.max(...results.map(r => r.totalObtained)) : 0;

      classReports.push({
        className: cls.name,
        results,
        summary: {
          total: results.length,
          passed,
          failed,
          average: avg,
          highest
        }
      });
    }

    await PDFGen.generateAllClassesResultPDF(exam, settings.academicYear || '2026-2027', classReports, settings);
    this.showToast('All Classes Result Report PDF generated successfully', 'success');
  },

  // Manage Exams & Subjects
  async openManageExamsModal() {
    const tbody = document.getElementById('manageExamsTbody');
    tbody.innerHTML = '';
    const exams = await SchoolDB.getAllExams();
    exams.forEach(e => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td style="font-weight:700;">${e.name}</td>
        <td>${e.academicYear}</td>
        <td><button class="btn btn-danger btn-sm" onclick="App.deleteExam(${e.id})">Delete</button></td>
      `;
      tbody.appendChild(tr);
    });
    this.openModal('manageExamsModal');
  },

  async addNewExam() {
    const name = document.getElementById('newExamName').value.trim();
    const yr = document.getElementById('newExamYear').value.trim();
    if (!name) return;

    await SchoolDB.saveExam({ name, academicYear: yr });
    this.cachedExams = await SchoolDB.getAllExams();
    this.populateExamDropdowns();
    this.openManageExamsModal();
    this.showToast('New examination added', 'success');
  },

  async deleteExam(id) {
    await SchoolDB.deleteExam(id);
    this.cachedExams = await SchoolDB.getAllExams();
    this.populateExamDropdowns();
    this.openManageExamsModal();
  },

  async openManageSubjectsModal() {
    const tbody = document.getElementById('manageSubjectsTbody');
    tbody.innerHTML = '';
    const subjects = await SchoolDB.getAllSubjects();
    subjects.forEach(s => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td style="font-weight:700;">${s.name}</td>
        <td>${s.totalMarks}</td>
        <td><button class="btn btn-danger btn-sm" onclick="App.deleteSubject(${s.id})">Delete</button></td>
      `;
      tbody.appendChild(tr);
    });
    this.openModal('manageSubjectsModal');
  },

  async addNewSubject() {
    const name = document.getElementById('newSubjectName').value.trim();
    const marks = parseInt(document.getElementById('newSubjectMarks').value, 10) || 100;
    if (!name) return;

    await SchoolDB.saveSubject({ name, totalMarks: marks });
    this.cachedSubjects = await SchoolDB.getAllSubjects();
    this.openManageSubjectsModal();
    this.showToast('New subject added', 'success');
  },

  async deleteSubject(id) {
    await SchoolDB.deleteSubject(id);
    this.cachedSubjects = await SchoolDB.getAllSubjects();
    this.openManageSubjectsModal();
  },

  // ================= 7. FEE MANAGEMENT =================
  async renderFeesTable() {
    const cls = document.getElementById('feeClassFilter')?.value || '';
    const month = document.getElementById('feeMonthFilter')?.value || '';
    const year = parseInt(document.getElementById('feeYearFilter')?.value || '2026', 10);

    const fees = await SchoolDB.getFeesByFilter(cls, month, year);
    const tbody = document.getElementById('feesTableBody');
    if (!tbody) return;
    tbody.innerHTML = '';

    if (fees.length === 0) {
      tbody.innerHTML = `<tr><td colspan="11" style="text-align:center; padding:30px; color:var(--text-muted);">No fee records found for the selected period.</td></tr>`;
      return;
    }

    fees.forEach(f => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td style="font-weight:700; color:var(--primary);">${f.receiptNo || 'REC-' + f.id}</td>
        <td>${f.paymentDate}</td>
        <td style="font-weight:700;">${f.studentName}</td>
        <td>${f.fatherName}</td>
        <td><span class="badge" style="background:#e0f2fe; color:#0369a1;">${f.className}</span></td>
        <td>${f.feeType}</td>
        <td>Rs.${Number(f.requiredAmount).toLocaleString()}</td>
        <td style="font-weight:700; color:#16a34a;">Rs.${Number(f.paidAmount).toLocaleString()}</td>
        <td style="color:${f.remainingAmount > 0 ? '#dc2626' : '#16a34a'};">Rs.${Number(f.remainingAmount).toLocaleString()}</td>
        <td>
          <span class="badge ${f.status === 'PAID' ? 'badge-paid' : f.status === 'PARTIAL' ? 'badge-partial' : 'badge-unpaid'}">
            ${f.status}
          </span>
        </td>
        <td class="actions-col" style="text-align:right;">
          <button class="btn btn-outline btn-sm" onclick="App.previewFeeReceipt(${f.id})">Receipt</button>
          <button class="btn btn-secondary btn-sm" onclick="App.downloadFeeReceiptPDF(${f.id})">PDF</button>
          <button class="btn btn-danger btn-sm" onclick="App.openDeleteConfirm(${f.id}, 'fee', 'Receipt #${f.receiptNo}')">Del</button>
        </td>
      `;
      tbody.appendChild(tr);
    });
  },

  async openRecordFeeModal() {
    const studentSelect = document.getElementById('feeStudentSelect');
    studentSelect.innerHTML = '';

    const students = await SchoolDB.getAllStudents();
    students.forEach(s => {
      const opt = document.createElement('option');
      opt.value = s.id;
      opt.textContent = `${s.name} (${s.className} - Roll# ${s.rollNo})`;
      studentSelect.appendChild(opt);
    });

    const settings = await SchoolDB.getSettings();
    document.getElementById('feeRequiredAmt').value = settings.monthlyFee || 2000;
    document.getElementById('feePaidAmt').value = settings.monthlyFee || 2000;
    document.getElementById('feePaymentDate').value = new Date().toISOString().split('T')[0];
    document.getElementById('feeReceiptNo').value = `REC-${Math.floor(10000 + Math.random() * 90000)}`;

    this.calcFeeRemaining();
    this.openModal('recordFeeModal');
  },

  calcFeeRemaining() {
    const req = parseFloat(document.getElementById('feeRequiredAmt').value) || 0;
    const paid = parseFloat(document.getElementById('feePaidAmt').value) || 0;
    const rem = Math.max(0, req - paid);
    document.getElementById('feeRemainingAmt').value = rem;

    let st = 'UNPAID';
    if (paid >= req && req > 0) st = 'PAID';
    else if (paid > 0 && paid < req) st = 'PARTIAL';

    document.getElementById('feeStatusDisplay').value = st;
  },

  async saveFee(event) {
    event.preventDefault();
    const studentId = parseInt(document.getElementById('feeStudentSelect').value, 10);
    const student = await SchoolDB.getStudentById(studentId);

    const feeType = document.getElementById('feeTypeSelect').value;
    const month = document.getElementById('feeMonthSelect').value;
    const academicYear = document.getElementById('feeAcadYear').value;
    const requiredAmount = parseFloat(document.getElementById('feeRequiredAmt').value) || 0;
    const paidAmount = parseFloat(document.getElementById('feePaidAmt').value) || 0;
    const remainingAmount = parseFloat(document.getElementById('feeRemainingAmt').value) || 0;
    const status = document.getElementById('feeStatusDisplay').value;
    const paymentDate = document.getElementById('feePaymentDate').value;
    const receiptNo = document.getElementById('feeReceiptNo').value;
    const notes = document.getElementById('feeNotes').value;

    const feeRecord = {
      studentId: student.id,
      studentName: student.name,
      fatherName: student.fatherName,
      className: student.className,
      rollNo: student.rollNo,
      feeType,
      month,
      year: new Date(paymentDate).getFullYear(),
      academicYear,
      requiredAmount,
      paidAmount,
      remainingAmount,
      status,
      paymentDate,
      receiptNo,
      notes
    };

    const feeId = await SchoolDB.saveFee(feeRecord);
    this.closeModal('recordFeeModal');
    this.showToast('Fee payment recorded successfully', 'success');
    this.renderFeesTable();
    this.previewFeeReceipt(feeId);
  },

  async previewFeeReceipt(feeId) {
    const f = await SchoolDB.getFeeById(feeId);
    const settings = await SchoolDB.getSettings();

    const modalTitle = document.getElementById('previewModalTitle');
    modalTitle.textContent = `Fee Receipt: ${f.receiptNo}`;

    const body = document.getElementById('previewModalBody');
    body.innerHTML = `
      <div class="document-preview-box" style="border:1px solid var(--border-strong); max-width:550px; margin:0 auto; padding:24px;">
        <div style="background:var(--primary); color:#fff; padding:14px; text-align:center; border-radius:4px; margin-bottom:14px;">
          <h3 style="font-size:15px; font-weight:800;">${settings.schoolName}</h3>
          <div style="font-size:11px; color:#fef08a;">EMIS: ${settings.emis} | ${settings.location}</div>
          <div style="font-size:12px; font-weight:700; margin-top:4px;">OFFICIAL FEE RECEIPT</div>
        </div>

        <div style="display:flex; justify-content:space-between; font-size:12px; margin-bottom:12px;">
          <div>Receipt No: <strong>${f.receiptNo}</strong></div>
          <div>Date: <strong>${f.paymentDate}</strong></div>
        </div>

        <div style="background:#f8fafc; padding:12px; border-radius:6px; font-size:12.5px; margin-bottom:14px;">
          <div>Student: <strong>${f.studentName}</strong> (Roll# ${f.rollNo})</div>
          <div>Father: <strong>${f.fatherName}</strong></div>
          <div>Class: <strong>${f.className}</strong> | Fee: <strong>${f.feeType} (${f.month} ${f.year})</strong></div>
        </div>

        <table class="data-table" style="margin-bottom:14px;">
          <tr>
            <td>Required Fee Amount</td>
            <td style="text-align:right; font-weight:700;">Rs. ${Number(f.requiredAmount).toLocaleString()}</td>
          </tr>
          <tr>
            <td>Paid Amount</td>
            <td style="text-align:right; font-weight:700; color:#16a34a;">Rs. ${Number(f.paidAmount).toLocaleString()}</td>
          </tr>
          <tr>
            <td>Remaining Balance</td>
            <td style="text-align:right; font-weight:700; color:#dc2626;">Rs. ${Number(f.remainingAmount).toLocaleString()}</td>
          </tr>
          <tr>
            <td>Payment Status</td>
            <td style="text-align:right;">
              <span class="badge ${f.status === 'PAID' ? 'badge-paid' : 'badge-partial'}">${f.status}</span>
            </td>
          </tr>
        </table>

        <div style="margin-top:30px; display:flex; justify-content:space-between; align-items:flex-end;">
          <div style="font-size:11px; color:var(--text-muted);">Cashier / Office Stamp</div>
          <div style="text-align:center;">
            ${settings.signature ? `<img src="${settings.signature}" style="height:30px;"><br>` : ''}
            <div style="border-top:1px solid #000; width:140px; padding-top:2px; font-weight:700; font-size:11px;">AUTHORIZED SIGNATURE</div>
            <div style="font-size:10px;">${settings.headTeacher}</div>
          </div>
        </div>
      </div>
    `;

    document.getElementById('btnPreviewPrint').onclick = () => window.print();
    document.getElementById('btnPreviewDownload').onclick = () => this.downloadFeeReceiptPDF(feeId);

    this.openModal('documentPreviewModal');
  },

  async downloadFeeReceiptPDF(feeId) {
    const f = await SchoolDB.getFeeById(feeId);
    const settings = await SchoolDB.getSettings();

    await PDFGen.generateFeeReceiptPDF(f, settings, settings.signature);
    this.showToast('Fee Receipt PDF downloaded', 'success');
  },

  async exportClassFeeReportPDF() {
    const cls = document.getElementById('feeClassFilter')?.value || 'Class 5';
    const month = document.getElementById('feeMonthFilter')?.value || 'September';
    const year = parseInt(document.getElementById('feeYearFilter')?.value || '2026', 10);
    const settings = await SchoolDB.getSettings();

    const fees = await SchoolDB.getFeesByFilter(cls, month, year);
    let totExp = 0, totCol = 0, pCount = 0, partCount = 0, uCount = 0;

    fees.forEach(f => {
      totExp += f.requiredAmount;
      totCol += f.paidAmount;
      if (f.status === 'PAID') pCount++;
      else if (f.status === 'PARTIAL') partCount++;
      else uCount++;
    });

    const summary = {
      totalStudents: fees.length,
      paidStudents: pCount,
      partialStudents: partCount,
      unpaidStudents: uCount,
      totalExpected: totExp,
      totalCollected: totCol
    };

    await PDFGen.generateClassFeeReportPDF(cls || 'All Classes', month, year, fees, summary, settings);
    this.showToast('Class Fee Report PDF downloaded', 'success');
  },

  // ================= 8. DOCUMENTS & CERTIFICATES =================
  populateStudentDropdowns() {
    const selectors = ['docStudentSelect', 'certStudentSelect'];
    selectors.forEach(id => {
      const sel = document.getElementById(id);
      if (!sel) return;
      sel.innerHTML = '';
      this.cachedStudents.forEach(s => {
        const opt = document.createElement('option');
        opt.value = s.id;
        opt.textContent = `${s.name} (${s.className} - Roll# ${s.rollNo})`;
        sel.appendChild(opt);
      });
    });
  },

  async previewIDCard() {
    const sId = parseInt(document.getElementById('docStudentSelect').value, 10);
    const s = await SchoolDB.getStudentById(sId);
    const settings = await SchoolDB.getSettings();

    const modalTitle = document.getElementById('previewModalTitle');
    modalTitle.textContent = `Student ID Card: ${s.name}`;

    const body = document.getElementById('previewModalBody');
    body.innerHTML = `
      <div style="text-align:center; margin-bottom:12px; font-weight:700; color:var(--primary);">
        TWO-SIDED STUDENT IDENTITY CARD (CR80 Standard Size)
      </div>
      <div class="id-cards-preview-row">
        <!-- Front Side -->
        <div class="id-card-render">
          <div class="id-card-header">
            <div class="sch-title">${settings.schoolName}</div>
            <div class="sch-sub">EMIS: ${settings.emis} | ${settings.location}</div>
            <div class="id-tag">STUDENT IDENTITY CARD</div>
          </div>
          <div class="id-card-body-front">
            <div class="id-photo-box">
              ${s.photo ? `<img src="${s.photo}">` : `<div style="display:flex; align-items:center; justify-content:center; height:100%; font-size:10px; color:var(--text-muted);">Photo</div>`}
            </div>
            <div class="id-details-box">
              <div class="id-details-row"><span class="id-label">Name:</span><span class="id-val">${s.name.toUpperCase()}</span></div>
              <div class="id-details-row"><span class="id-label">Father:</span><span class="id-val">${s.fatherName.toUpperCase()}</span></div>
              <div class="id-details-row"><span class="id-label">Class:</span><span class="id-val">${s.className}</span></div>
              <div class="id-details-row"><span class="id-label">Roll No:</span><span class="id-val">${s.rollNo}</span></div>
              <div class="id-details-row"><span class="id-label">Adm No:</span><span class="id-val">${s.admissionNo || '-'}</span></div>
              <div class="id-details-row"><span class="id-label">Session:</span><span class="id-val">${settings.academicYear || '2026-2027'}</span></div>
            </div>
          </div>
        </div>

        <!-- Back Side -->
        <div class="id-card-render">
          <div class="id-card-header" style="background:#0c1a2e;">
            <div class="sch-title" style="font-size:10px;">INSTRUCTIONS & CONTACT</div>
          </div>
          <div class="id-card-body-back">
            <div>
              <div style="font-weight:700; color:var(--text-muted); font-size:9px;">Address:</div>
              <div style="font-size:10px; font-weight:600; margin-bottom:6px;">${s.address || 'Village Sultan Matt Uchari, Barkhan'}</div>
              <div style="font-weight:700; color:var(--text-muted); font-size:9px;">Emergency Phone:</div>
              <div style="font-size:10px; font-weight:600; margin-bottom:8px;">${s.parentContact || settings.contactPhone || '0829-XXXXXX'}</div>
              <div style="font-size:8.5px; color:var(--text-muted);">
                • Carry card daily during school hours.<br>
                • Property of Balochistan Education Department.<br>
                • If found, return to Head Teacher GBPS Uchari.
              </div>
            </div>
            <div style="text-align:right;">
              ${settings.signature ? `<img src="${settings.signature}" style="height:22px;"><br>` : ''}
              <div style="border-top:1px solid #000; width:110px; display:inline-block; font-size:8px; font-weight:700;">HEAD TEACHER</div>
              <div style="font-size:7.5px;">${settings.headTeacher}</div>
            </div>
          </div>
        </div>
      </div>
    `;

    document.getElementById('btnPreviewPrint').onclick = () => window.print();
    document.getElementById('btnPreviewDownload').onclick = () => this.downloadIDCardPDF();

    this.openModal('documentPreviewModal');
  },

  async downloadIDCardPDF() {
    const sId = parseInt(document.getElementById('docStudentSelect').value, 10);
    const s = await SchoolDB.getStudentById(sId);
    const settings = await SchoolDB.getSettings();

    await PDFGen.generateStudentIDCardPDF(s, settings, settings.signature);
    this.showToast('Student ID Card PDF downloaded', 'success');
  },

  async openLeavingCertModal() {
    const sId = parseInt(document.getElementById('docStudentSelect')?.value || document.getElementById('certStudentSelect')?.value, 10);
    const s = await SchoolDB.getStudentById(sId);
    if (!s) return;

    document.getElementById('slcStudentName').value = `${s.name} (${s.className} - Roll# ${s.rollNo})`;
    document.getElementById('slcDate').value = new Date().toISOString().split('T')[0];
    this.openModal('leavingCertModal');
  },

  async previewLeavingCert() {
    const sId = parseInt(document.getElementById('docStudentSelect')?.value || document.getElementById('certStudentSelect')?.value, 10);
    const s = await SchoolDB.getStudentById(sId);
    const settings = await SchoolDB.getSettings();

    const lDate = document.getElementById('slcDate')?.value || new Date().toISOString().split('T')[0];
    const reason = document.getElementById('slcReason')?.value || 'On parent request';
    const conduct = document.getElementById('slcConduct')?.value || 'Good and satisfactory';

    const isMale = (s.gender || 'Male').toLowerCase() === 'male';
    const title = isMale ? 'Mr.' : 'Miss.';
    const heShe = isMale ? 'He' : 'She';
    const hisHer = isMale ? 'His' : 'Her';
    const soDo = isMale ? 'S/O' : 'D/O';

    this.closeModal('leavingCertModal');

    const modalTitle = document.getElementById('previewModalTitle');
    modalTitle.textContent = `School Leaving Certificate: ${s.name}`;

    const body = document.getElementById('previewModalBody');
    body.innerHTML = `
      <div class="document-preview-box" style="border:3px double var(--primary); padding:36px; background:#fff;">
        <div style="text-align:center; border-bottom:2px solid var(--accent); padding-bottom:14px; margin-bottom:20px;">
          <h2 style="color:var(--primary); font-size:20px; font-weight:800;">${settings.schoolName}</h2>
          <div style="font-size:12px; color:var(--text-muted); font-weight:600;">EMIS: ${settings.emis} | ${settings.location}</div>
          <h3 style="color:var(--primary); font-size:16px; margin-top:8px; letter-spacing:1px;">SCHOOL LEAVING CERTIFICATE</h3>
        </div>

        <div style="display:flex; justify-content:space-between; font-size:12px; margin-bottom:24px;">
          <div>SLC No: <strong>SLC-06994-${s.id}</strong></div>
          <div>Date: <strong>${new Date().toLocaleDateString()}</strong></div>
        </div>

        <p style="font-size:15px; line-height:1.8; margin-bottom:20px;">
          This is to certify that <strong>${title} <u>${s.name.toUpperCase()}</u></strong>, ${soDo} <strong><u>${s.fatherName.toUpperCase()}</u></strong>, bearing Admission No. <strong>${s.admissionNo || '06994-' + s.id}</strong> and Roll No. <strong>${s.rollNo}</strong>, was a bona fide student of this institution in <strong>${s.className}</strong>.
        </p>

        <div style="background:#f8fafc; padding:18px; border-radius:6px; font-size:13.5px; line-height:1.8; margin-bottom:24px;">
          <div>• Date of Birth: <strong>${s.dob || 'As per official school record'}</strong></div>
          <div>• Date of Leaving: <strong>${lDate}</strong></div>
          <div>• Reason for Leaving: <strong>${reason}</strong></div>
          <div>• General Conduct & Moral Character: <strong>${conduct}</strong></div>
          <div>• Dues Paid: <strong>${heShe} has cleared all dues up to the date of leaving.</strong></div>
        </div>

        <p style="font-size:14px; margin-bottom:40px;">
          We wish ${isMale ? 'him' : 'her'} great success in ${hisHer.toLowerCase()} future academic endeavors.
        </p>

        <div style="display:flex; justify-content:space-between; align-items:flex-end;">
          <div style="border:2px solid var(--accent); border-radius:50%; width:75px; height:75px; display:flex; align-items:center; justify-content:center; text-align:center; font-size:9px; font-weight:700; color:var(--primary);">
            OFFICIAL<br>SEAL
          </div>
          <div style="text-align:center;">
            ${settings.signature ? `<img src="${settings.signature}" style="height:38px;"><br>` : ''}
            <div style="border-top:1px solid #000; width:180px; padding-top:4px; font-weight:700;">HEAD TEACHER</div>
            <div style="font-size:12px;">${settings.headTeacher}</div>
          </div>
        </div>
      </div>
    `;

    document.getElementById('btnPreviewPrint').onclick = () => window.print();
    document.getElementById('btnPreviewDownload').onclick = () => this.downloadLeavingCertPDF();

    this.openModal('documentPreviewModal');
  },

  async downloadLeavingCertPDF() {
    const sId = parseInt(document.getElementById('docStudentSelect')?.value || document.getElementById('certStudentSelect')?.value, 10);
    const s = await SchoolDB.getStudentById(sId);
    const settings = await SchoolDB.getSettings();

    const lDate = document.getElementById('slcDate')?.value || new Date().toISOString().split('T')[0];
    const reason = document.getElementById('slcReason')?.value || 'On parent request / Relocation';
    const conduct = document.getElementById('slcConduct')?.value || 'Satisfactory and obedient';

    await PDFGen.generateLeavingCertificatePDF(s, reason, conduct, lDate, settings, settings.signature);
    this.showToast('School Leaving Certificate PDF downloaded', 'success');
  },

  async previewCharacterCert() {
    const sId = parseInt(document.getElementById('docStudentSelect')?.value || document.getElementById('certStudentSelect')?.value, 10);
    const s = await SchoolDB.getStudentById(sId);
    const settings = await SchoolDB.getSettings();

    const isMale = (s.gender || 'Male').toLowerCase() === 'male';
    const title = isMale ? 'Mr.' : 'Miss.';
    const heShe = isMale ? 'He' : 'She';
    const hisHer = isMale ? 'His' : 'Her';
    const soDo = isMale ? 'S/O' : 'D/O';

    const modalTitle = document.getElementById('previewModalTitle');
    modalTitle.textContent = `Character Certificate: ${s.name}`;

    const body = document.getElementById('previewModalBody');
    body.innerHTML = `
      <div class="document-preview-box" style="border:3px double var(--secondary); padding:36px; background:#fff;">
        <div style="text-align:center; border-bottom:2px solid var(--accent); padding-bottom:14px; margin-bottom:20px;">
          <h2 style="color:var(--secondary); font-size:20px; font-weight:800;">${settings.schoolName}</h2>
          <div style="font-size:12px; color:var(--text-muted); font-weight:600;">EMIS: ${settings.emis} | ${settings.location}</div>
          <h3 style="color:var(--secondary); font-size:16px; margin-top:8px; letter-spacing:1px;">CHARACTER CERTIFICATE</h3>
        </div>

        <div style="display:flex; justify-content:space-between; font-size:12px; margin-bottom:24px;">
          <div>Ref No: <strong>CC-06994-${s.id}</strong></div>
          <div>Date: <strong>${new Date().toLocaleDateString()}</strong></div>
        </div>

        <p style="font-size:15px; line-height:1.8; margin-bottom:16px;">
          This is to certify that <strong>${title} <u>${s.name.toUpperCase()}</u></strong>, ${soDo} <strong><u>${s.fatherName.toUpperCase()}</u></strong> has been a regular student of this institution in <strong>${s.className}</strong>, bearing Roll No. <strong>${s.rollNo}</strong>.
        </p>

        <p style="font-size:14.5px; line-height:1.8; margin-bottom:16px;">
          During ${hisHer.toLowerCase()} period of stay in this institution, ${hisHer.toLowerCase()} conduct and behavior have been found thoroughly satisfactory, cooperative, and praiseworthy.
        </p>

        <p style="font-size:14.5px; line-height:1.8; margin-bottom:24px;">
          ${heShe} actively participated in classroom activities, observed school discipline, and showed respect towards teachers and peers. To the best of our knowledge and school records, ${heShe.toLowerCase()} bears an <strong>EXEMPLARY MORAL CHARACTER</strong>.
        </p>

        <div style="display:flex; justify-content:space-between; align-items:flex-end; margin-top:40px;">
          <div style="border:2px solid var(--accent); border-radius:50%; width:75px; height:75px; display:flex; align-items:center; justify-content:center; text-align:center; font-size:9px; font-weight:700; color:var(--secondary);">
            OFFICIAL<br>SEAL
          </div>
          <div style="text-align:center;">
            ${settings.signature ? `<img src="${settings.signature}" style="height:38px;"><br>` : ''}
            <div style="border-top:1px solid #000; width:180px; padding-top:4px; font-weight:700;">HEAD TEACHER</div>
            <div style="font-size:12px;">${settings.headTeacher}</div>
          </div>
        </div>
      </div>
    `;

    document.getElementById('btnPreviewPrint').onclick = () => window.print();
    document.getElementById('btnPreviewDownload').onclick = () => this.downloadCharacterCertPDF();

    this.openModal('documentPreviewModal');
  },

  async downloadCharacterCertPDF() {
    const sId = parseInt(document.getElementById('docStudentSelect')?.value || document.getElementById('certStudentSelect')?.value, 10);
    const s = await SchoolDB.getStudentById(sId);
    const settings = await SchoolDB.getSettings();

    await PDFGen.generateCharacterCertificatePDF(s, settings, settings.signature);
    this.showToast('Character Certificate PDF downloaded', 'success');
  },

  async exportStudentsListPDF() {
    const cls = document.getElementById('studentClassFilter')?.value || 'All';
    let students = await SchoolDB.getAllStudents();
    if (cls && cls !== 'All') {
      students = students.filter(s => s.className === cls);
    }
    const settings = await SchoolDB.getSettings();

    await PDFGen.generateStudentListPDF(cls, students, settings);
    this.showToast('Student List PDF downloaded', 'success');
  },

  async previewAdmissionForm() {
    const settings = await SchoolDB.getSettings();
    const modalTitle = document.getElementById('previewModalTitle');
    modalTitle.textContent = 'Printable Offline Admission Application Form';

    const body = document.getElementById('previewModalBody');
    body.innerHTML = `
      <div class="document-preview-box" style="border:2px solid var(--primary); padding:30px; background:#fff;">
        <div style="text-align:center; border-bottom:2px solid var(--primary); padding-bottom:12px; margin-bottom:18px;">
          <h2 style="color:var(--primary); font-size:18px; font-weight:800;">${settings.schoolName}</h2>
          <div style="font-size:12px; color:var(--text-muted); font-weight:600;">EMIS: ${settings.emis} | ${settings.location}</div>
          <h3 style="font-size:14px; font-weight:700; margin-top:6px;">OFFLINE ADMISSION APPLICATION FORM</h3>
        </div>

        <div style="display:flex; justify-content:space-between; margin-bottom:20px;">
          <div style="flex:1; font-size:12px; line-height:2.2;">
            <div>1. Student Full Name: _____________________________________________</div>
            <div>2. Father / Guardian Name: _______________________________________</div>
            <div>3. Gender: [  ] Male     [  ] Female &nbsp;&nbsp;&nbsp;&nbsp; 4. DOB: _________________</div>
            <div>5. Class Applying For: __________________ (Kachi to Class 5)</div>
            <div>6. Student B-Form / CNIC: _________________________________________</div>
            <div>7. Parent Contact Mobile: _________________________________________</div>
            <div>8. Village / Address: _____________________________________________</div>
          </div>
          <div style="width:110px; height:130px; border:1px solid #94a3b8; display:flex; align-items:center; justify-content:center; text-align:center; font-size:10px; color:var(--text-muted); padding:6px;">
            Affix Recent Passport Photo
          </div>
        </div>

        <div style="border:1px solid var(--border); padding:12px; background:#f8fafc; border-radius:6px; font-size:11.5px; margin-bottom:20px;">
          <strong>Parent Undertaking:</strong> I declare that all given information is true and accurate. I will ensure my child follows all school regulations.
          <div style="display:flex; justify-content:space-between; margin-top:16px;">
            <div>Date: _______________</div>
            <div>Parent Signature: _________________________</div>
          </div>
        </div>

        <div style="border:1px solid var(--primary); padding:12px; background:#eff6ff; border-radius:6px; font-size:11.5px;">
          <strong style="color:var(--primary);">For Office Use Only:</strong>
          <div style="display:flex; justify-content:space-between; margin-top:10px;">
            <div>Admitted To Class: ____________</div>
            <div>Allotted Roll No: ____________</div>
            <div>Head Teacher Signature: ____________</div>
          </div>
        </div>
      </div>
    `;

    document.getElementById('btnPreviewPrint').onclick = () => window.print();
    document.getElementById('btnPreviewDownload').onclick = () => this.downloadBlankAdmissionForm();

    this.openModal('documentPreviewModal');
  },

  async downloadBlankAdmissionForm() {
    const settings = await SchoolDB.getSettings();
    await PDFGen.generateAdmissionFormPDF(settings);
    this.showToast('Printable Admission Form PDF downloaded', 'success');
  },

  generateStudentQuickID(id) {
    this.closeModal('viewStudentModal');
    const sel = document.getElementById('docStudentSelect');
    if (sel) sel.value = id;
    this.navigate('documents');
    this.previewIDCard();
  },

  generateStudentQuickSLC(id) {
    this.closeModal('viewStudentModal');
    const sel = document.getElementById('docStudentSelect');
    if (sel) sel.value = id;
    this.navigate('documents');
    this.openLeavingCertModal();
  },

  generateStudentQuickCC(id) {
    this.closeModal('viewStudentModal');
    const sel = document.getElementById('docStudentSelect');
    if (sel) sel.value = id;
    this.navigate('documents');
    this.previewCharacterCert();
  },

  // ================= 9. SETTINGS =================
  renderSettingsForm() {
    const s = this.cachedSettings;
    if (!s) return;

    document.getElementById('setSchoolName').value = s.schoolName || '';
    document.getElementById('setEmis').value = s.emis || '';
    document.getElementById('setLocation').value = s.location || '';
    document.getElementById('setHeadTeacher').value = s.headTeacher || '';
    document.getElementById('setAcademicYear').value = s.academicYear || '2026-2027';
    document.getElementById('setContactPhone').value = s.contactPhone || '';
    document.getElementById('setAdmissionFee').value = s.admissionFee || 1000;
    document.getElementById('setMonthlyFee').value = s.monthlyFee || 2000;

    const previewBox = document.getElementById('signaturePreviewBox');
    if (s.signature) {
      previewBox.innerHTML = `<img src="${s.signature}" style="max-width:100%; max-height:100%; object-fit:contain;">`;
    } else {
      previewBox.innerHTML = `<span style="font-size:11px; color:var(--text-muted);">No signature uploaded</span>`;
    }
  },

  handleSignatureUpload(event) {
    const file = event.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (e) => {
      const dataUrl = e.target.result;
      const settings = await SchoolDB.getSettings();
      settings.signature = dataUrl;
      await SchoolDB.saveSettings(settings);
      this.cachedSettings = settings;
      this.renderSettingsForm();
      this.showToast('Head Teacher signature saved', 'success');
    };
    reader.readAsDataURL(file);
  },

  async removeSignature() {
    const settings = await SchoolDB.getSettings();
    settings.signature = null;
    await SchoolDB.saveSettings(settings);
    this.cachedSettings = settings;
    this.renderSettingsForm();
    this.showToast('Signature removed', 'success');
  },

  async saveSchoolSettings(event) {
    event.preventDefault();
    const settings = {
      schoolName: document.getElementById('setSchoolName').value.trim(),
      emis: document.getElementById('setEmis').value.trim(),
      location: document.getElementById('setLocation').value.trim(),
      headTeacher: document.getElementById('setHeadTeacher').value.trim(),
      academicYear: document.getElementById('setAcademicYear').value.trim(),
      contactPhone: document.getElementById('setContactPhone').value.trim(),
      admissionFee: parseFloat(document.getElementById('setAdmissionFee').value) || 1000,
      monthlyFee: parseFloat(document.getElementById('setMonthlyFee').value) || 2000,
      signature: this.cachedSettings.signature || null
    };

    await SchoolDB.saveSettings(settings);
    this.cachedSettings = settings;
    this.showToast('School settings updated successfully', 'success');
  },

  // ================= 10. BACKUP & RESTORE =================
  async exportBackupFile() {
    try {
      const data = await SchoolDB.exportCompleteBackup();
      const jsonStr = JSON.stringify(data, null, 2);
      const blob = new Blob([jsonStr], { type: 'application/json' });
      const url = URL.createObjectURL(blob);

      const a = document.createElement('a');
      const dateStr = new Date().toISOString().split('T')[0];
      a.href = url;
      a.download = `GBPS_Sultan_Matt_Uchari_Backup_${dateStr}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      this.showToast('Complete backup exported successfully', 'success');
    } catch (err) {
      console.error('Export error:', err);
      this.showToast('Failed to export backup: ' + err.message, 'error');
    }
  },

  handleBackupFileSelected(event) {
    const file = event.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const parsed = JSON.parse(e.target.result);
        if (!parsed.metadata && !parsed.students) {
          throw new Error('Invalid school backup file format');
        }
        this.tempBackupData = parsed;
        this.openModal('importBackupModal');
      } catch (err) {
        this.showToast('Error reading backup file: ' + err.message, 'error');
      }
    };
    reader.readAsText(file);
    event.target.value = ''; // Reset input
  },

  async executeBackupImport() {
    if (!this.tempBackupData) return;

    const mode = document.querySelector('input[name="importMode"]:checked')?.value || 'merge';
    try {
      await SchoolDB.importBackupData(this.tempBackupData, mode === 'replace');
      this.closeModal('importBackupModal');
      this.tempBackupData = null;
      this.showToast('School backup data restored successfully', 'success');
      await this.loadInitialData();
      this.navigate('dashboard');
    } catch (err) {
      console.error('Import error:', err);
      this.showToast('Restore failed: ' + err.message, 'error');
    }
  },

  async confirmResetDatabase() {
    if (confirm('CRITICAL WARNING: Are you sure you want to reset the school database? All local records will be deleted.')) {
      if (confirm('Please confirm again: This will reset data to initial school template.')) {
        await SchoolDB.resetDatabase();
        this.showToast('Database reset complete', 'success');
        await this.loadInitialData();
        this.navigate('dashboard');
      }
    }
  },

  // ================= UI HELPERS =================
  openModal(modalId) {
    const m = document.getElementById(modalId);
    if (m) m.classList.add('open');
  },

  closeModal(modalId) {
    const m = document.getElementById(modalId);
    if (m) m.classList.remove('open');
  },

  showToast(message, type = 'info') {
    const container = document.getElementById('toastContainer');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = `toast ${type === 'success' ? 'toast-success' : type === 'error' ? 'toast-error' : ''}`;
    toast.innerHTML = `
      <span>${type === 'success' ? '✓' : type === 'error' ? '✕' : 'ℹ'}</span>
      <span>${message}</span>
    `;
    container.appendChild(toast);

    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transition = 'opacity 0.3s ease';
      setTimeout(() => toast.remove(), 300);
    }, 3500);
  }
};

window.App = App;

// Bootstrap on DOM Ready
document.addEventListener('DOMContentLoaded', () => {
  App.init();
});
