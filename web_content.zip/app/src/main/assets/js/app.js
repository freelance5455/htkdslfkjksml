/**
 * আল-কারীম পুকুর ম্যানেজমেন্ট - মূল অ্যাপ্লিকেশন লজিক
 * Complete CRUD, Real-time calculations, Filters, Validation & Reports
 */

window.App = {
  activeReportType: 'daily',

  // Safe field getters
  getFieldValue(form, fieldName) {
    if (!fieldName) return '';
    const byId = document.getElementById(fieldName) || (form ? form.querySelector('#' + fieldName) : null);
    if (byId && byId.value !== undefined && byId.value !== null) return String(byId.value).trim();
    if (form) {
      if (form.elements && form.elements[fieldName] && form.elements[fieldName].value !== undefined && form.elements[fieldName].value !== null) {
        return String(form.elements[fieldName].value).trim();
      }
      const byName = form.querySelector(`[name="${fieldName}"]`);
      if (byName && byName.value !== undefined && byName.value !== null) return String(byName.value).trim();
    }
    const globalByName = document.querySelector(`[name="${fieldName}"]`);
    if (globalByName && globalByName.value !== undefined && globalByName.value !== null) {
      return String(globalByName.value).trim();
    }
    return '';
  },

  getFieldNumber(form, fieldName, defaultVal = 0) {
    const str = this.getFieldValue(form, fieldName);
    if (str === '') return defaultVal;
    const bnDigits = { '০': '0', '১': '1', '২': '2', '৩': '3', '৪': '4', '৫': '5', '৬': '6', '৭': '7', '৮': '8', '৯': '9' };
    const normalized = String(str).replace(/[০-৯]/g, d => bnDigits[d]).replace(/,/g, '').trim();
    const num = parseFloat(normalized);
    return isNaN(num) ? defaultVal : num;
  },

  // 1. SAVE POND
  savePond(event, explicitId = null) {
    if (event && typeof event.preventDefault === 'function') event.preventDefault();
    const form = document.getElementById('pond-form');
    if (!form) return false;
    if (!UI.validateForm(form)) return false;

    const id = explicitId || this.getFieldValue(form, 'pond-id') || this.getFieldValue(form, 'id') || null;
    const isEdit = !!id;

    const name = this.getFieldValue(form, 'pond-name') || this.getFieldValue(form, 'name');
    if (!name) {
      UI.showToast('পুকুরের নাম দেওয়া আবশ্যক।', 'error');
      return false;
    }

    const area = this.getFieldNumber(form, 'pond-area') || this.getFieldNumber(form, 'area', 0);
    if (area <= 0) {
      UI.showToast('পুকুরের সঠিক আয়তন প্রদান করুন।', 'error');
      return false;
    }

    let number = this.getFieldValue(form, 'pond-number') || this.getFieldValue(form, 'number');
    if (!number) {
      number = 'P-' + (db.getAll('ponds').length + 101);
    }

    const data = {
      name: name,
      number: number,
      area: area,
      unit: this.getFieldValue(form, 'pond-unit') || this.getFieldValue(form, 'unit') || 'শতাংশ',
      depth: this.getFieldNumber(form, 'pond-depth') || this.getFieldNumber(form, 'depth', 0),
      status: this.getFieldValue(form, 'pond-status') || this.getFieldValue(form, 'status') || 'সক্রিয়',
      location: this.getFieldValue(form, 'pond-location') || this.getFieldValue(form, 'location'),
      manager: this.getFieldValue(form, 'pond-manager') || this.getFieldValue(form, 'manager'),
      fishType: this.getFieldValue(form, 'pond-fish-type') || this.getFieldValue(form, 'fishType'),
      fishCount: this.getFieldNumber(form, 'pond-fish-count') || this.getFieldNumber(form, 'fishCount', 0),
      releaseDate: this.getFieldValue(form, 'pond-release-date') || this.getFieldValue(form, 'releaseDate') || new Date().toISOString().split('T')[0],
      note: this.getFieldValue(form, 'pond-note') || this.getFieldValue(form, 'note')
    };

    if (isEdit) {
      db.update('ponds', id, data);
      UI.showToast('পুকুরের তথ্য সফলভাবে আপডেট হয়েছে।', 'success');
    } else {
      db.insert('ponds', data);
      UI.showToast('সফলভাবে নতুন পুকুর সংরক্ষণ করা হয়েছে।', 'success');
    }

    try { form.reset(); } catch (e) {}
    UI.closeModal();
    this.renderPonds();
    this.renderDashboard();
    return true;
  },

  // 2. SAVE MEMBER
  saveMember(event, explicitId = null) {
    if (event && typeof event.preventDefault === 'function') event.preventDefault();
    const form = document.getElementById('member-form');
    if (!form) return false;
    if (!UI.validateForm(form)) return false;

    const id = explicitId || this.getFieldValue(form, 'member-id') || this.getFieldValue(form, 'id') || null;
    const isEdit = !!id;

    const name = this.getFieldValue(form, 'member-name') || this.getFieldValue(form, 'name');
    if (!name) {
      UI.showToast('সদস্যের নাম দেওয়া আবশ্যক।', 'error');
      return false;
    }

    const mobile = this.getFieldValue(form, 'member-mobile') || this.getFieldValue(form, 'mobile');
    if (!mobile) {
      UI.showToast('মোবাইল নম্বর দেওয়া আবশ্যক।', 'error');
      return false;
    }

    let memberId = this.getFieldValue(form, 'member-code') || this.getFieldValue(form, 'memberId');
    if (!memberId) {
      memberId = 'AK-' + String(db.getAll('members').length + 1).padStart(3, '0');
    }

    const shareCount = this.getFieldNumber(form, 'member-shares') || this.getFieldNumber(form, 'shareCount', 1);
    const depositAmount = this.getFieldNumber(form, 'member-deposit') || this.getFieldNumber(form, 'depositAmount', 0);

    const data = {
      name: name,
      memberId: memberId,
      fatherName: this.getFieldValue(form, 'member-father') || this.getFieldValue(form, 'fatherName'),
      mobile: mobile,
      shareCount: shareCount > 0 ? shareCount : 1,
      depositAmount: depositAmount,
      address: this.getFieldValue(form, 'member-address') || this.getFieldValue(form, 'address'),
      joinDate: this.getFieldValue(form, 'member-join-date') || this.getFieldValue(form, 'joinDate') || new Date().toISOString().split('T')[0],
      note: this.getFieldValue(form, 'member-note') || this.getFieldValue(form, 'note')
    };

    if (isEdit) {
      db.update('members', id, data);
      UI.showToast('সদস্যের তথ্য সফলভাবে আপডেট হয়েছে।', 'success');
    } else {
      db.insert('members', data);
      UI.showToast('সফলভাবে নতুন সদস্য সংরক্ষণ করা হয়েছে।', 'success');
    }

    try { form.reset(); } catch (e) {}
    UI.closeModal();
    this.renderMembers();
    this.renderDashboard();
    return true;
  },

  // 3. SAVE FEED STOCK
  saveFeedStock(event, explicitId = null) {
    if (event && typeof event.preventDefault === 'function') event.preventDefault();
    const form = document.getElementById('feed-stock-form');
    if (!form) return false;
    if (!UI.validateForm(form)) return false;

    const id = explicitId || this.getFieldValue(form, 'fs-id') || this.getFieldValue(form, 'id') || null;
    const isEdit = !!id;

    const feedName = this.getFieldValue(form, 'fs-name') || this.getFieldValue(form, 'feedName');
    if (!feedName) {
      UI.showToast('খাদ্যের নাম দেওয়া আবশ্যক।', 'error');
      return false;
    }

    let totalKg = this.getFieldNumber(form, 'fs-total-kg') || this.getFieldNumber(form, 'totalKg', 0);
    const totalSacks = this.getFieldNumber(form, 'fs-sacks') || this.getFieldNumber(form, 'totalSacks', 0);
    const kgPerSack = this.getFieldNumber(form, 'fs-kg-per-sack') || this.getFieldNumber(form, 'kgPerSack', 50);

    if (totalKg <= 0 && totalSacks > 0) {
      totalKg = totalSacks * (kgPerSack || 50);
    }

    if (totalKg <= 0) {
      UI.showToast('খাদ্যের সঠিক পরিমাণ (কেজি) প্রদান করুন।', 'error');
      return false;
    }

    const ratePerKg = this.getFieldNumber(form, 'fs-rate') || this.getFieldNumber(form, 'ratePerKg', 0);
    let totalPrice = this.getFieldNumber(form, 'fs-total-price') || this.getFieldNumber(form, 'totalPrice', 0);
    if (totalPrice <= 0 && ratePerKg > 0) {
      totalPrice = Math.round(totalKg * ratePerKg);
    }

    const sacksCalculated = totalSacks > 0 ? totalSacks : Math.max(1, Math.round(totalKg / (kgPerSack || 50)));

    const data = {
      date: this.getFieldValue(form, 'fs-date') || this.getFieldValue(form, 'date') || new Date().toISOString().split('T')[0],
      feedType: this.getFieldValue(form, 'fs-type') || this.getFieldValue(form, 'feedType') || 'ভাসা',
      feedName: feedName,
      brand: this.getFieldValue(form, 'fs-brand') || this.getFieldValue(form, 'brand'),
      totalSacks: sacksCalculated,
      kgPerSack: kgPerSack || 50,
      totalKg: totalKg,
      ratePerKg: ratePerKg,
      totalPrice: totalPrice,
      supplier: this.getFieldValue(form, 'fs-supplier') || this.getFieldValue(form, 'supplier'),
      invoiceNo: this.getFieldValue(form, 'fs-invoice') || this.getFieldValue(form, 'invoiceNo'),
      note: this.getFieldValue(form, 'fs-note') || this.getFieldValue(form, 'note')
    };

    if (isEdit) {
      db.update('feedStock', id, data);
      UI.showToast('খাদ্য স্টকের তথ্য সফলভাবে আপডেট হয়েছে।', 'success');
    } else {
      db.insert('feedStock', data);
      UI.showToast('সফলভাবে খাদ্য স্টক সংরক্ষণ করা হয়েছে।', 'success');
    }

    try { form.reset(); } catch (e) {}
    UI.closeModal();
    this.renderFeedStock();
    this.renderDashboard();
    return true;
  },

  // 4. SAVE DAILY FEED
  saveDailyFeed(event, explicitId = null) {
    if (event && typeof event.preventDefault === 'function') event.preventDefault();
    const form = document.getElementById('daily-feed-form');
    if (!form) return false;
    if (!UI.validateForm(form)) return false;

    const id = explicitId || this.getFieldValue(form, 'df-id') || this.getFieldValue(form, 'id') || null;
    const isEdit = !!id;

    const feedName = this.getFieldValue(form, 'df-name') || this.getFieldValue(form, 'feedName');
    if (!feedName) {
      UI.showToast('খাদ্যের নাম দেওয়া আবশ্যক।', 'error');
      return false;
    }

    const amountKg = this.getFieldNumber(form, 'df-amount') || this.getFieldNumber(form, 'amountKg', 0);
    if (amountKg <= 0) {
      UI.showToast('খাদ্যের পরিমাণ (কেজি) প্রদান করুন।', 'error');
      return false;
    }

    const pondId = this.getFieldValue(form, 'df-pond-select') || this.getFieldValue(form, 'pondId');
    let pondName = 'পুকুর-১';
    if (pondId) {
      const p = db.getById('ponds', pondId);
      if (p) pondName = p.name;
      else pondName = pondId;
    } else {
      const ponds = db.getAll('ponds');
      if (ponds.length > 0) pondName = ponds[0].name;
    }

    const ratePerKg = this.getFieldNumber(form, 'df-rate') || this.getFieldNumber(form, 'ratePerKg', 0);
    let totalPrice = this.getFieldNumber(form, 'df-total') || this.getFieldNumber(form, 'totalPrice', 0);
    if (totalPrice <= 0 && ratePerKg > 0) {
      totalPrice = Math.round(amountKg * ratePerKg);
    }

    const data = {
      date: this.getFieldValue(form, 'df-date') || this.getFieldValue(form, 'date') || new Date().toISOString().split('T')[0],
      pondId: pondId || 'pond_1',
      pondName: pondName,
      time: this.getFieldValue(form, 'df-time') || this.getFieldValue(form, 'time') || 'সকাল',
      feedType: this.getFieldValue(form, 'df-type') || this.getFieldValue(form, 'feedType') || 'ভাসা',
      feedName: feedName,
      brand: this.getFieldValue(form, 'df-brand') || this.getFieldValue(form, 'brand'),
      amountKg: amountKg,
      ratePerKg: ratePerKg,
      totalPrice: totalPrice,
      fedBy: this.getFieldValue(form, 'df-fed-by') || this.getFieldValue(form, 'fedBy'),
      note: this.getFieldValue(form, 'df-note') || this.getFieldValue(form, 'note')
    };

    if (isEdit) {
      db.update('dailyFeed', id, data);
      UI.showToast('দৈনিক খাদ্য হিসাব আপডেট হয়েছে।', 'success');
    } else {
      db.insert('dailyFeed', data);
      UI.showToast('সফলভাবে দৈনিক খাদ্য হিসাব সংরক্ষণ করা হয়েছে।', 'success');
    }

    try { form.reset(); } catch (e) {}
    UI.closeModal();
    this.renderDailyFeed();
    this.renderDashboard();
    return true;
  },

  // 5. SAVE EXPENSE
  saveExpense(event, explicitId = null) {
    if (event && typeof event.preventDefault === 'function') event.preventDefault();
    const form = document.getElementById('expense-form');
    if (!form) return false;
    if (!UI.validateForm(form)) return false;

    const id = explicitId || this.getFieldValue(form, 'exp-id') || this.getFieldValue(form, 'id') || null;
    const isEdit = !!id;

    const description = this.getFieldValue(form, 'exp-desc') || this.getFieldValue(form, 'description');
    if (!description) {
      UI.showToast('খরচের বিবরণ দেওয়া আবশ্যক।', 'error');
      return false;
    }

    const totalMoney = this.getFieldNumber(form, 'exp-money') || this.getFieldNumber(form, 'totalMoney', 0);
    if (totalMoney <= 0) {
      UI.showToast('খরচের সঠিক টাকার পরিমাণ প্রদান করুন।', 'error');
      return false;
    }

    const pondId = this.getFieldValue(form, 'exp-pond') || this.getFieldValue(form, 'pondId') || 'all';
    let pondName = 'সকল পুকুর (সাধারণ)';
    if (pondId !== 'all') {
      const p = db.getById('ponds', pondId);
      if (p) pondName = p.name;
    }

    const amount = this.getFieldNumber(form, 'exp-amount') || this.getFieldNumber(form, 'amount', 1);

    const data = {
      date: this.getFieldValue(form, 'exp-date') || this.getFieldValue(form, 'date') || new Date().toISOString().split('T')[0],
      pondId: pondId,
      pondName: pondName,
      category: this.getFieldValue(form, 'exp-cat') || this.getFieldValue(form, 'category') || 'শ্রমিক',
      description: description,
      amount: amount > 0 ? amount : 1,
      totalMoney: totalMoney,
      payee: this.getFieldValue(form, 'exp-payee') || this.getFieldValue(form, 'payee'),
      voucherNo: this.getFieldValue(form, 'exp-voucher') || this.getFieldValue(form, 'voucherNo'),
      note: this.getFieldValue(form, 'exp-note') || this.getFieldValue(form, 'note')
    };

    if (isEdit) {
      db.update('expenses', id, data);
      UI.showToast('খরচের তথ্য সফলভাবে আপডেট হয়েছে।', 'success');
    } else {
      db.insert('expenses', data);
      UI.showToast('সফলভাবে খরচ সংরক্ষণ করা হয়েছে।', 'success');
    }

    try { form.reset(); } catch (e) {}
    UI.closeModal();
    this.renderExpenses();
    this.renderDashboard();
    return true;
  },

  // 6. SAVE FISH PURCHASE / BUY
  saveFishPurchase(event, explicitId = null) {
    if (event && typeof event.preventDefault === 'function') event.preventDefault();
    const form = document.getElementById('fish-buy-form');
    if (!form) return false;
    if (!UI.validateForm(form)) return false;

    const id = explicitId || this.getFieldValue(form, 'fb-id') || this.getFieldValue(form, 'id') || null;
    const isEdit = !!id;

    const fishType = this.getFieldValue(form, 'fb-type') || this.getFieldValue(form, 'fishType');
    if (!fishType) {
      UI.showToast('মাছের ধরন/নাম প্রদান করুন।', 'error');
      return false;
    }

    const pondId = this.getFieldValue(form, 'fb-pond') || this.getFieldValue(form, 'pondId');
    const pondObj = pondId ? db.getById('ponds', pondId) : null;
    const pondName = pondObj ? pondObj.name : 'পুকুর-১';

    const count = this.getFieldNumber(form, 'fb-count') || this.getFieldNumber(form, 'count', 0);
    const totalWeight = this.getFieldNumber(form, 'fb-weight') || this.getFieldNumber(form, 'totalWeight', 0);
    const ratePerKg = this.getFieldNumber(form, 'fb-rate') || this.getFieldNumber(form, 'ratePerKg', 0);
    let totalPrice = this.getFieldNumber(form, 'fb-total') || this.getFieldNumber(form, 'totalPrice', 0);

    if (totalPrice <= 0) {
      if (totalWeight > 0 && ratePerKg > 0) {
        totalPrice = Math.round(totalWeight * ratePerKg);
      } else if (count > 0 && ratePerKg > 0) {
        totalPrice = Math.round(count * ratePerKg);
      }
    }

    const data = {
      date: this.getFieldValue(form, 'fb-date') || this.getFieldValue(form, 'date') || new Date().toISOString().split('T')[0],
      pondId: pondId || 'pond_1',
      pondName: pondName,
      fishType: fishType,
      sizeAge: this.getFieldValue(form, 'fb-size') || this.getFieldValue(form, 'sizeAge'),
      count: count,
      totalWeight: totalWeight,
      ratePerKg: ratePerKg,
      totalPrice: totalPrice,
      seller: this.getFieldValue(form, 'fb-seller') || this.getFieldValue(form, 'seller'),
      note: this.getFieldValue(form, 'fb-note') || this.getFieldValue(form, 'note')
    };

    if (isEdit) {
      db.update('fishBuy', id, data);
      UI.showToast('মাছ ক্রয়ের তথ্য সফলভাবে আপডেট হয়েছে।', 'success');
    } else {
      db.insert('fishBuy', data);
      UI.showToast('সফলভাবে মাছ/পোনা ক্রয় সংরক্ষণ করা হয়েছে।', 'success');
    }

    try { form.reset(); } catch (e) {}
    UI.closeModal();
    this.renderFishBuy();
    this.renderDashboard();
    return true;
  },

  saveFishBuy(e, id) {
    return this.saveFishPurchase(e, id);
  },

  // 7. SAVE FISH SALE
  saveFishSale(event, explicitId = null) {
    if (event && typeof event.preventDefault === 'function') event.preventDefault();
    const form = document.getElementById('fish-sell-form');
    if (!form) return false;
    if (!UI.validateForm(form)) return false;

    const id = explicitId || this.getFieldValue(form, 'fsell-id') || this.getFieldValue(form, 'id') || null;
    const isEdit = !!id;

    const fishType = this.getFieldValue(form, 'fsell-type') || this.getFieldValue(form, 'fishType');
    if (!fishType) {
      UI.showToast('মাছের ধরন প্রদান করুন।', 'error');
      return false;
    }

    const totalWeight = this.getFieldNumber(form, 'fsell-weight') || this.getFieldNumber(form, 'totalWeight', 0);
    if (totalWeight <= 0) {
      UI.showToast('মাছের মোট ওজন (কেজি) প্রদান করুন।', 'error');
      return false;
    }

    const ratePerKg = this.getFieldNumber(form, 'fsell-rate') || this.getFieldNumber(form, 'ratePerKg', 0);
    if (ratePerKg <= 0) {
      UI.showToast('প্রতি কেজির বিক্রয় মূল্য প্রদান করুন।', 'error');
      return false;
    }

    let totalPrice = this.getFieldNumber(form, 'fsell-total') || this.getFieldNumber(form, 'totalPrice', 0);
    if (totalPrice <= 0) {
      totalPrice = Math.round(totalWeight * ratePerKg);
    }

    const pondId = this.getFieldValue(form, 'fsell-pond') || this.getFieldValue(form, 'pondId');
    const pondObj = pondId ? db.getById('ponds', pondId) : null;
    const pondName = pondObj ? pondObj.name : 'পুকুর-১';

    const data = {
      date: this.getFieldValue(form, 'fsell-date') || this.getFieldValue(form, 'date') || new Date().toISOString().split('T')[0],
      pondId: pondId || 'pond_1',
      pondName: pondName,
      fishType: fishType,
      count: this.getFieldNumber(form, 'fsell-count') || this.getFieldNumber(form, 'count', 0),
      totalWeight: totalWeight,
      ratePerKg: ratePerKg,
      totalPrice: totalPrice,
      buyerName: this.getFieldValue(form, 'fsell-buyer') || this.getFieldValue(form, 'buyerName'),
      buyerMobile: this.getFieldValue(form, 'fsell-buyer-mobile') || this.getFieldValue(form, 'buyerMobile'),
      note: this.getFieldValue(form, 'fsell-note') || this.getFieldValue(form, 'note')
    };

    if (isEdit) {
      db.update('fishSell', id, data);
      UI.showToast('মাছ বিক্রয়ের তথ্য আপডেট হয়েছে।', 'success');
    } else {
      db.insert('fishSell', data);
      UI.showToast('মাছ বিক্রয় সফলভাবে সংরক্ষণ করা হয়েছে।', 'success');
    }

    try { form.reset(); } catch (e) {}
    UI.closeModal();
    this.renderFishSell();
    this.renderDashboard();
    return true;
  },

  saveFishSell(e, id) {
    return this.saveFishSale(e, id);
  },

  // 8. SAVE MORTALITY / DEAD FISH
  saveMortality(event, explicitId = null) {
    if (event && typeof event.preventDefault === 'function') event.preventDefault();
    const form = document.getElementById('dead-fish-form');
    if (!form) return false;
    if (!UI.validateForm(form)) return false;

    const id = explicitId || this.getFieldValue(form, 'dfish-id') || this.getFieldValue(form, 'id') || null;
    const isEdit = !!id;

    const fishType = this.getFieldValue(form, 'dfish-type') || this.getFieldValue(form, 'fishType');
    if (!fishType) {
      UI.showToast('মাছের ধরন প্রদান করুন।', 'error');
      return false;
    }

    const count = this.getFieldNumber(form, 'dfish-count') || this.getFieldNumber(form, 'count', 0);
    if (count <= 0) {
      UI.showToast('মৃত মাছের সঠিক সংখ্যা প্রদান করুন।', 'error');
      return false;
    }

    const pondId = this.getFieldValue(form, 'dfish-pond') || this.getFieldValue(form, 'pondId');
    const pondObj = pondId ? db.getById('ponds', pondId) : null;
    const pondName = pondObj ? pondObj.name : 'পুকুর-১';

    const data = {
      date: this.getFieldValue(form, 'dfish-date') || this.getFieldValue(form, 'date') || new Date().toISOString().split('T')[0],
      pondId: pondId || 'pond_1',
      pondName: pondName,
      fishType: fishType,
      count: count,
      estimatedWeight: this.getFieldNumber(form, 'dfish-weight') || this.getFieldNumber(form, 'estimatedWeight', 0),
      cause: this.getFieldValue(form, 'dfish-cause') || this.getFieldValue(form, 'cause') || 'অক্সিজেন স্বল্পতা',
      note: this.getFieldValue(form, 'dfish-note') || this.getFieldValue(form, 'note')
    };

    if (isEdit) {
      db.update('deadFish', id, data);
      UI.showToast('মৃত মাছের রেকর্ড আপডেট হয়েছে।', 'success');
    } else {
      db.insert('deadFish', data);
      UI.showToast('মৃত মাছের রেকর্ড সফলভাবে সংরক্ষণ করা হয়েছে।', 'success');
    }

    try { form.reset(); } catch (e) {}
    UI.closeModal();
    this.renderDeadFish();
    this.renderDashboard();
    return true;
  },

  saveDeadFish(e, id) {
    return this.saveMortality(e, id);
  },

  init() {
    UI.init();
    this.bindGlobalEvents();
    this.renderCurrentView();
  },

  onViewChanged(viewName) {
    this.renderCurrentView();
  },

  renderCurrentView() {
    const view = UI.currentView;
    switch (view) {
      case 'dashboard':
        this.renderDashboard();
        break;
      case 'ponds':
        this.renderPonds();
        break;
      case 'members':
        this.renderMembers();
        break;
      case 'feed-stock':
        this.renderFeedStock();
        break;
      case 'daily-feed':
        this.renderDailyFeed();
        break;
      case 'fish-buy':
        this.renderFishBuy();
        break;
      case 'fish-sell':
        this.renderFishSell();
        break;
      case 'dead-fish':
        this.renderDeadFish();
        break;
      case 'expenses':
        this.renderExpenses();
        break;
      case 'accounts':
        this.renderAccounts();
        break;
      case 'monthly-report':
        this.renderMonthlyReport();
        break;
      case 'yearly-report':
        this.renderYearlyReport();
        break;
      case 'member-calc':
        this.renderMemberCalc();
        break;
      case 'pond-calc':
        this.renderPondCalc();
        break;
      case 'recycle-bin':
        this.renderRecycleBin();
        break;
      case 'settings':
        this.renderSettings();
        break;
      default:
        this.renderDashboard();
    }
    UI.updateRecycleBinBadge();
  },

  bindGlobalEvents() {
    // Quick Add (+) floating / header button
    const quickAddBtn = document.getElementById('btn-quick-add');
    if (quickAddBtn) {
      quickAddBtn.addEventListener('click', () => {
        const view = UI.currentView;
        if (view === 'ponds') this.openPondModal();
        else if (view === 'members') this.openMemberModal();
        else if (view === 'feed-stock') this.openFeedStockModal();
        else if (view === 'daily-feed') this.openDailyFeedModal();
        else if (view === 'expenses') this.openExpenseModal();
        else if (view === 'fish-buy') this.openFishBuyModal();
        else if (view === 'fish-sell') this.openFishSellModal();
        else if (view === 'dead-fish') this.openDeadFishModal();
        else {
          // Default: open quick action chooser
          this.openQuickAddMenu();
        }
      });
    }

    // Window resize chart re-render
    window.addEventListener('resize', () => {
      if (UI.currentView === 'dashboard') {
        UI.renderDashboardCharts();
      }
    });
  },

  openQuickAddMenu() {
    const html = `
      <div style="display:grid; grid-template-columns: 1fr 1fr; gap:10px;">
        <button class="btn btn-secondary" style="justify-content:flex-start; padding:12px;" onclick="App.openDailyFeedModal();">
          <span>🍚</span> দৈনিক খাদ্য যোগ
        </button>
        <button class="btn btn-secondary" style="justify-content:flex-start; padding:12px;" onclick="App.openFeedStockModal();">
          <span>🌾</span> খাদ্য স্টক যোগ
        </button>
        <button class="btn btn-secondary" style="justify-content:flex-start; padding:12px;" onclick="App.openExpenseModal();">
          <span>💰</span> নতুন খরচ
        </button>
        <button class="btn btn-secondary" style="justify-content:flex-start; padding:12px;" onclick="App.openFishSellModal();">
          <span>🐟</span> মাছ বিক্রয়
        </button>
        <button class="btn btn-secondary" style="justify-content:flex-start; padding:12px;" onclick="App.openFishBuyModal();">
          <span>🐠</span> মাছ/পোনা ক্রয়
        </button>
        <button class="btn btn-secondary" style="justify-content:flex-start; padding:12px;" onclick="App.openDeadFishModal();">
          <span>☠️</span> মৃত মাছ
        </button>
        <button class="btn btn-secondary" style="justify-content:flex-start; padding:12px;" onclick="App.openPondModal();">
          <span>🌊</span> নতুন পুকুর
        </button>
        <button class="btn btn-secondary" style="justify-content:flex-start; padding:12px;" onclick="App.openMemberModal();">
          <span>👥</span> নতুন সদস্য
        </button>
      </div>
    `;
    UI.openDetailsModal('⚡ দ্রুত নতুন এন্ট্রি যোগ করুন', html);
  },

  // =========================================================================
  // 1. DASHBOARD
  // =========================================================================
  renderDashboard() {
    const stats = db.getDashboardStats();

    // Update Stat values
    const el = id => document.getElementById(id);
    if (el('stat-ponds')) el('stat-ponds').textContent = stats.totalPonds + ' টি';
    if (el('stat-members')) el('stat-members').textContent = stats.totalMembers + ' জন';
    if (el('stat-feed-stock')) el('stat-feed-stock').textContent = `${stats.remainingFeedKg} কেজি (${stats.remainingFeedSacks} বস্তা)`;
    if (el('stat-expenses')) el('stat-expenses').textContent = '৳ ' + stats.totalExpenses.toLocaleString('bn-BD');
    if (el('stat-income')) el('stat-income').textContent = '৳ ' + stats.totalIncome.toLocaleString('bn-BD');
    
    // Net profit / loss
    const profitEl = el('stat-profit');
    if (profitEl) {
      const isProfit = stats.netProfit >= 0;
      profitEl.textContent = (isProfit ? '+ ৳ ' : '- ৳ ') + Math.abs(stats.netProfit).toLocaleString('bn-BD');
      profitEl.style.color = isProfit ? 'var(--success)' : 'var(--danger)';
    }

    if (el('stat-fish-stock')) el('stat-fish-stock').textContent = stats.estimatedFishInPonds.toLocaleString('bn-BD') + ' টি';
    if (el('stat-feed-used')) el('stat-feed-used').textContent = stats.totalFedKg.toLocaleString('bn-BD') + ' কেজি';

    // Recent activities
    const actListEl = el('dashboard-activity-list');
    if (actListEl) {
      const activities = db.getRecentActivities(6);
      if (activities.length === 0) {
        actListEl.innerHTML = `
          <div style="text-align:center; padding: 20px; color:var(--text-muted); font-size:13px;">
            কোনো সাম্প্রতিক কার্যক্রম নেই।
          </div>
        `;
      } else {
        actListEl.innerHTML = activities.map(act => `
          <li class="activity-item">
            <div class="act-badge ${act.badgeClass}">${act.icon}</div>
            <div class="act-content">
              <div class="act-title">${act.title}</div>
              <div class="act-time">তারিখ: ${act.date || 'আজ'}</div>
            </div>
          </li>
        `).join('');
      }
    }

    // Render Canvas Charts
    setTimeout(() => {
      UI.renderDashboardCharts();
    }, 50);
  },

  // =========================================================================
  // 2. PONDS (পুকুর ব্যবস্থাপনা)
  // =========================================================================
  renderPonds() {
    const listEl = document.getElementById('ponds-list');
    const searchInput = document.getElementById('pond-search');
    const filterSelect = document.getElementById('pond-filter');

    if (!listEl) return;

    const searchTerm = (searchInput ? searchInput.value.toLowerCase().trim() : '');
    const filterStatus = (filterSelect ? filterSelect.value : 'all');

    let ponds = db.getAll('ponds');

    if (filterStatus !== 'all') {
      ponds = ponds.filter(p => p.status === filterStatus);
    }
    if (searchTerm) {
      ponds = ponds.filter(p =>
        (p.name && p.name.toLowerCase().includes(searchTerm)) ||
        (p.number && p.number.toLowerCase().includes(searchTerm)) ||
        (p.fishType && p.fishType.toLowerCase().includes(searchTerm)) ||
        (p.manager && p.manager.toLowerCase().includes(searchTerm))
      );
    }

    if (ponds.length === 0) {
      listEl.innerHTML = `
        <div class="empty-state">
          <div class="empty-icon">🐟</div>
          <div class="empty-title">কোনো পুকুর পাওয়া যায়নি</div>
          <div class="empty-desc">নতুন পুকুর যোগ করতে নিচের বাটনে চাপ দিন।</div>
          <button class="btn btn-primary" onclick="App.openPondModal()">
            <span>➕</span> নতুন পুকুর যোগ করুন
          </button>
        </div>
      `;
      return;
    }

    listEl.innerHTML = ponds.map(pond => `
      <div class="item-card">
        <div class="item-card-header">
          <div class="card-title-group">
            <h4>${pond.name}</h4>
            <div class="card-tag">পুকুর নং: ${pond.number} | দায়িত্ব: ${pond.manager || 'অনির্ধারিত'}</div>
          </div>
          <span class="badge ${pond.status === 'সক্রিয়' ? 'badge-success' : 'badge-warning'}">${pond.status}</span>
        </div>

        <div class="item-data-grid">
          <div class="data-row">
            <span class="data-label">আয়তন ও গভীরতা</span>
            <span class="data-val">${pond.area} ${pond.unit} (গভীরতা: ${pond.depth || '০'} ফুট)</span>
          </div>
          <div class="data-row">
            <span class="data-label">পোনা সংখ্যা ও ধরন</span>
            <span class="data-val">${(pond.fishCount || 0).toLocaleString('bn-BD')} টি (${pond.fishType || 'মিশ্র'})</span>
          </div>
          <div class="data-row">
            <span class="data-label">পোনা ছাড়ার তারিখ</span>
            <span class="data-val">${pond.releaseDate || 'লিপিবদ্ধ নেই'}</span>
          </div>
          <div class="data-row">
            <span class="data-label">অবস্থান</span>
            <span class="data-val">${pond.location || 'খামার প্রাঙ্গণ'}</span>
          </div>
        </div>

        <div class="card-actions">
          <button class="btn btn-outline btn-sm" onclick="App.viewPondDetails('${pond.id}')">
            <span>👁️</span> বিস্তারিত
          </button>
          <button class="btn btn-secondary btn-sm" onclick="App.openPondModal('${pond.id}')">
            <span>✏️</span> সম্পাদন
          </button>
          <button class="btn btn-danger btn-sm" onclick="App.deleteItem('ponds', '${pond.id}', '${pond.name}')">
            <span>🗑️</span> মুছুন
          </button>
        </div>
      </div>
    `).join('');
  },

  openPondModal(pondId = null) {
    const isEdit = !!pondId;
    const pond = isEdit ? db.getById('ponds', pondId) : {};

    const html = `
      <form id="pond-form">
        <input type="hidden" name="id" id="pond-id" value="${pond.id || ''}">
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">পুকুরের নাম <span class="required">*</span></label>
            <input type="text" class="form-control" name="name" id="pond-name" value="${pond.name || ''}" placeholder="যেমন: উত্তর দীঘি" required>
          </div>
          <div class="form-group">
            <label class="form-label">পুকুরের নম্বর/কোড</label>
            <input type="text" class="form-control" name="number" id="pond-number" value="${pond.number || 'P-' + (db.getAll('ponds').length + 101)}">
          </div>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label class="form-label">আয়তন <span class="required">*</span></label>
            <input type="number" step="0.01" class="form-control" name="area" id="pond-area" value="${pond.area || ''}" placeholder="যেমন: ৫০" required>
          </div>
          <div class="form-group">
            <label class="form-label">আয়তনের একক</label>
            <select class="form-control" name="unit" id="pond-unit">
              <option value="শতাংশ" ${pond.unit === 'শতাংশ' ? 'selected' : ''}>শতাংশ</option>
              <option value="বিঘা" ${pond.unit === 'বিঘা' ? 'selected' : ''}>বিঘা</option>
              <option value="একর" ${pond.unit === 'একর' ? 'selected' : ''}>একর</option>
              <option value="কাঠা" ${pond.unit === 'কাঠা' ? 'selected' : ''}>কাঠা</option>
              <option value="বর্গফুট" ${pond.unit === 'বর্গফুট' ? 'selected' : ''}>বর্গফুট</option>
            </select>
          </div>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label class="form-label">গভীরতা (ফুট)</label>
            <input type="number" step="0.1" class="form-control" name="depth" id="pond-depth" value="${pond.depth || ''}" placeholder="যেমন: ৬">
          </div>
          <div class="form-group">
            <label class="form-label">বর্তমান অবস্থা</label>
            <select class="form-control" name="status" id="pond-status">
              <option value="সক্রিয়" ${pond.status === 'সক্রিয়' ? 'selected' : ''}>সক্রিয়</option>
              <option value="প্রস্তুতি চলছে" ${pond.status === 'প্রস্তুতি চলছে' ? 'selected' : ''}>প্রস্তুতি চলছে</option>
              <option value="মাছ ধরা হচ্ছে" ${pond.status === 'মাছ ধরা হচ্ছে' ? 'selected' : ''}>মাছ ধরা হচ্ছে</option>
              <option value="সাময়িক বন্ধ" ${pond.status === 'সাময়িক বন্ধ' ? 'selected' : ''}>সাময়িক বন্ধ</option>
            </select>
          </div>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label class="form-label">পুকুরের অবস্থান</label>
            <input type="text" class="form-control" name="location" id="pond-location" value="${pond.location || ''}" placeholder="যেমন: খামারের উত্তর পাড়">
          </div>
          <div class="form-group">
            <label class="form-label">দায়িত্বপ্রাপ্ত ব্যক্তি/মালিক</label>
            <input type="text" class="form-control" name="manager" id="pond-manager" value="${pond.manager || ''}" placeholder="দায়িত্বপ্রাপ্ত ব্যক্তির নাম">
          </div>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label class="form-label">মাছের ধরন</label>
            <input type="text" class="form-control" name="fishType" id="pond-fish-type" value="${pond.fishType || ''}" placeholder="যেমন: রুই, কাতলা, পাঙ্গাস">
          </div>
          <div class="form-group">
            <label class="form-label">পোনা সংখ্যা</label>
            <input type="number" class="form-control" name="fishCount" id="pond-fish-count" value="${pond.fishCount || ''}" placeholder="যেমন: ৫০০০">
          </div>
        </div>

        <div class="form-group">
          <label class="form-label">পোনা ছাড়ার তারিখ</label>
          <input type="date" class="form-control" name="releaseDate" id="pond-release-date" value="${pond.releaseDate || new Date().toISOString().split('T')[0]}">
        </div>

        <div class="form-group">
          <label class="form-label">নোট / বিবরণ</label>
          <textarea class="form-control" name="note" id="pond-note" placeholder="পুকুর সংক্রান্ত কোনো বিশেষ তথ্য">${pond.note || ''}</textarea>
        </div>
      </form>
    `;

    UI.openFormModal(
      isEdit ? '✏️ পুকুর তথ্য সম্পাদন' : '🐟 নতুন পুকুর যোগ করুন',
      html,
      'সংরক্ষণ করুন',
      () => App.savePond(null, pondId)
    );
  },

  viewPondDetails(pondId) {
    const pondReport = db.getPondReport(pondId);
    if (!pondReport) return;
    const p = pondReport.pond;

    const html = `
      <div style="font-size:14px; line-height:1.6;">
        <div style="background:var(--primary-subtle); padding:12px; border-radius:8px; margin-bottom:14px; border:1px solid rgba(13,92,58,0.15)">
          <div style="font-size:16px; font-weight:700; color:var(--primary-dark);">${p.name} (${p.number})</div>
          <div style="color:var(--text-muted); font-size:12px;">অবস্থান: ${p.location || 'খামার প্রাঙ্গণ'} | অবস্থা: <strong>${p.status}</strong></div>
        </div>

        <table class="styled-table" style="min-width:100%; font-size:12px; margin-bottom:14px;">
          <tr><th>আয়তন ও একক</th><td>${p.area} ${p.unit} (গভীরতা: ${p.depth || 0} ফুট)</td></tr>
          <tr><th>দায়িত্বপ্রাপ্ত</th><td>${p.manager || 'অনির্ধারিত'}</td></tr>
          <tr><th>মাছের ধরন</th><td>${p.fishType || 'মিশ্র কার্প'}</td></tr>
          <tr><th>পোনা সংখ্যা</th><td>${(p.fishCount || 0).toLocaleString('bn-BD')} টি (তারিখ: ${p.releaseDate})</td></tr>
          <tr><th>মৃত মাছ সংখ্যা</th><td style="color:var(--danger)">${pondReport.deadCount} টি</td></tr>
          <tr><th>মোট খাদ্য প্রদান</th><td>${pondReport.feedKg} কেজি (খরচ: ৳ ${pondReport.feedCost.toLocaleString('bn-BD')})</td></tr>
          <tr><th>পোনা ক্রয় খরচ</th><td>৳ ${pondReport.fishBuyCost.toLocaleString('bn-BD')}</td></tr>
          <tr><th>অন্যান্য খরচ</th><td>৳ ${pondReport.otherExpenseTotal.toLocaleString('bn-BD')}</td></tr>
          <tr style="background:#f4f8f5;"><th>মোট পুকুর খরচ</th><td style="font-weight:700; color:var(--danger)">৳ ${pondReport.totalPondExpense.toLocaleString('bn-BD')}</td></tr>
          <tr><th>মোট মাছ বিক্রয় আয়</th><td style="font-weight:700; color:var(--success)">৳ ${pondReport.fishSaleIncome.toLocaleString('bn-BD')} (${pondReport.fishSaleWeight} কেজি)</td></tr>
          <tr style="background:var(--gold-subtle);">
            <th>নিট লাভ / ক্ষতি</th>
            <td style="font-weight:700; color:${pondReport.pondNetProfit >= 0 ? 'var(--success)' : 'var(--danger)'}">
              ${pondReport.pondNetProfit >= 0 ? '+ ৳ ' : '- ৳ '}${Math.abs(pondReport.pondNetProfit).toLocaleString('bn-BD')}
            </td>
          </tr>
        </table>
        ${p.note ? `<p style="font-size:12px; color:var(--text-muted);"><strong>নোট:</strong> ${p.note}</p>` : ''}
      </div>
    `;

    UI.openDetailsModal(`🐟 ${p.name} - বিস্তারিত বিবরণ`, html);
  },

  // =========================================================================
  // 3. MEMBERS (সদস্য ব্যবস্থাপনা)
  // =========================================================================
  renderMembers() {
    const listEl = document.getElementById('members-list');
    const searchInput = document.getElementById('member-search');
    if (!listEl) return;

    const searchTerm = (searchInput ? searchInput.value.toLowerCase().trim() : '');
    let members = db.getAll('members');

    if (searchTerm) {
      members = members.filter(m =>
        (m.name && m.name.toLowerCase().includes(searchTerm)) ||
        (m.memberId && m.memberId.toLowerCase().includes(searchTerm)) ||
        (m.mobile && m.mobile.toLowerCase().includes(searchTerm))
      );
    }

    if (members.length === 0) {
      listEl.innerHTML = `
        <div class="empty-state">
          <div class="empty-icon">👥</div>
          <div class="empty-title">কোনো সদস্য পাওয়া যায়নি</div>
          <div class="empty-desc">খামারের নতুন অংশীদার বা সদস্য যোগ করুন।</div>
          <button class="btn btn-primary" onclick="App.openMemberModal()">
            <span>➕</span> নতুন সদস্য যোগ করুন
          </button>
        </div>
      `;
      return;
    }

    listEl.innerHTML = members.map(m => `
      <div class="item-card">
        <div class="item-card-header">
          <div class="card-title-group">
            <h4>${m.name}</h4>
            <div class="card-tag">আইডি: ${m.memberId} | মোবাইল: ${m.mobile || 'নেই'}</div>
          </div>
          <span class="badge badge-primary">${m.shareCount} টি শেয়ার</span>
        </div>

        <div class="item-data-grid">
          <div class="data-row">
            <span class="data-label">মোট জমা টাকা</span>
            <span class="data-val" style="color:var(--primary-dark)">৳ ${(parseFloat(m.depositAmount) || 0).toLocaleString('bn-BD')}</span>
          </div>
          <div class="data-row">
            <span class="data-label">যোগদানের তারিখ</span>
            <span class="data-val">${m.joinDate || 'লিপিবদ্ধ নেই'}</span>
          </div>
          <div class="data-row">
            <span class="data-label">পিতার নাম</span>
            <span class="data-val">${m.fatherName || '-'}</span>
          </div>
          <div class="data-row">
            <span class="data-label">ঠিকানা</span>
            <span class="data-val">${m.address || '-'}</span>
          </div>
        </div>

        <div class="card-actions">
          <button class="btn btn-outline btn-sm" onclick="App.viewMemberDetails('${m.id}')">
            <span>👁️</span> বিবরণ
          </button>
          <button class="btn btn-secondary btn-sm" onclick="App.openMemberModal('${m.id}')">
            <span>✏️</span> সম্পাদন
          </button>
          <button class="btn btn-danger btn-sm" onclick="App.deleteItem('members', '${m.id}', '${m.name}')">
            <span>🗑️</span> মুছুন
          </button>
        </div>
      </div>
    `).join('');
  },

  openMemberModal(memberId = null) {
    const isEdit = !!memberId;
    const member = isEdit ? db.getById('members', memberId) : {};

    const html = `
      <form id="member-form">
        <input type="hidden" name="id" id="member-id" value="${member.id || ''}">
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">সদস্যের নাম <span class="required">*</span></label>
            <input type="text" class="form-control" name="name" id="member-name" value="${member.name || ''}" placeholder="সদস্যের পূর্ণ নাম" required>
          </div>
          <div class="form-group">
            <label class="form-label">সদস্য ID</label>
            <input type="text" class="form-control" name="memberId" id="member-code" value="${member.memberId || 'AK-' + String(db.getAll('members').length + 1).padStart(3, '0')}">
          </div>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label class="form-label">পিতার নাম</label>
            <input type="text" class="form-control" name="fatherName" id="member-father" value="${member.fatherName || ''}" placeholder="পিতার নাম">
          </div>
          <div class="form-group">
            <label class="form-label">মোবাইল নম্বর <span class="required">*</span></label>
            <input type="tel" class="form-control" name="mobile" id="member-mobile" value="${member.mobile || ''}" placeholder="০১৭০০-০০০০০০" required>
          </div>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label class="form-label">শেয়ার সংখ্যা</label>
            <input type="number" class="form-control" name="shareCount" id="member-shares" value="${member.shareCount || '1'}" min="1">
          </div>
          <div class="form-group">
            <label class="form-label">জমার পরিমাণ (টাকা)</label>
            <input type="number" class="form-control" name="depositAmount" id="member-deposit" value="${member.depositAmount !== undefined ? member.depositAmount : '0'}" placeholder="যেমন: ১০০০০০">
          </div>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label class="form-label">ঠিকানা</label>
            <input type="text" class="form-control" name="address" id="member-address" value="${member.address || ''}" placeholder="ঠিকানা">
          </div>
          <div class="form-group">
            <label class="form-label">যোগদানের তারিখ</label>
            <input type="date" class="form-control" name="joinDate" id="member-join-date" value="${member.joinDate || new Date().toISOString().split('T')[0]}">
          </div>
        </div>

        <div class="form-group">
          <label class="form-label">নোট</label>
          <textarea class="form-control" name="note" id="member-note" placeholder="সদস্য সংক্রান্ত মন্তব্য">${member.note || ''}</textarea>
        </div>
      </form>
    `;

    UI.openFormModal(
      isEdit ? '✏️ সদস্য তথ্য সম্পাদন' : '👥 নতুন সদস্য যোগ করুন',
      html,
      'সংরক্ষণ করুন',
      () => App.saveMember(null, memberId)
    );
  },

  viewMemberDetails(memberId) {
    const m = db.getById('members', memberId);
    if (!m) return;

    const stats = db.getDashboardStats();
    const totalShares = stats.totalShares || 1;
    const sharePercentage = ((m.shareCount / totalShares) * 100).toFixed(1);
    const estimatedProfitShare = ((stats.netProfit * m.shareCount) / totalShares).toFixed(0);

    const html = `
      <div style="font-size:14px; line-height:1.6;">
        <div style="background:var(--primary-subtle); padding:12px; border-radius:8px; margin-bottom:14px;">
          <div style="font-size:16px; font-weight:700; color:var(--primary-dark);">${m.name}</div>
          <div style="color:var(--text-muted); font-size:12px;">আইডি: ${m.memberId} | মোবাইল: ${m.mobile || 'নেই'}</div>
        </div>

        <table class="styled-table" style="min-width:100%; font-size:12px;">
          <tr><th>পিতার নাম</th><td>${m.fatherName || '-'}</td></tr>
          <tr><th>ঠিকানা</th><td>${m.address || '-'}</td></tr>
          <tr><th>যোগদানের তারিখ</th><td>${m.joinDate || '-'}</td></tr>
          <tr><th>শেয়ার সংখ্যা</th><td>${m.shareCount} টি (মোট শেয়ারের ${sharePercentage}%)</td></tr>
          <tr><th>জমার পরিমাণ</th><td style="font-weight:700; color:var(--primary)">৳ ${(parseFloat(m.depositAmount) || 0).toLocaleString('bn-BD')}</td></tr>
          <tr style="background:var(--gold-subtle)">
            <th>সম্ভাব্য লাভ বণ্টন</th>
            <td style="font-weight:700; color:${estimatedProfitShare >= 0 ? 'var(--success)' : 'var(--danger)'}">
              ${estimatedProfitShare >= 0 ? '+ ৳ ' : '- ৳ '}${Math.abs(estimatedProfitShare).toLocaleString('bn-BD')}
            </td>
          </tr>
        </table>
        ${m.note ? `<p style="font-size:12px; color:var(--text-muted); margin-top:10px;"><strong>নোট:</strong> ${m.note}</p>` : ''}
      </div>
    `;

    UI.openDetailsModal(`👤 ${m.name} - সদস্য প্রোফাইল`, html);
  },

  // =========================================================================
  // 4. FEED STOCK (খাদ্য স্টক ব্যবস্থাপনা)
  // =========================================================================
  renderFeedStock() {
    const listEl = document.getElementById('feed-stock-list');
    const searchInput = document.getElementById('feed-search');
    const filterSelect = document.getElementById('feed-filter');
    if (!listEl) return;

    const searchTerm = (searchInput ? searchInput.value.toLowerCase().trim() : '');
    const filterType = (filterSelect ? filterSelect.value : 'all');

    let feedStock = db.getAll('feedStock');

    if (filterType !== 'all') {
      feedStock = feedStock.filter(f => f.feedType === filterType);
    }
    if (searchTerm) {
      feedStock = feedStock.filter(f =>
        (f.feedName && f.feedName.toLowerCase().includes(searchTerm)) ||
        (f.brand && f.brand.toLowerCase().includes(searchTerm)) ||
        (f.supplier && f.supplier.toLowerCase().includes(searchTerm))
      );
    }

    if (feedStock.length === 0) {
      listEl.innerHTML = `
        <div class="empty-state">
          <div class="empty-icon">🌾</div>
          <div class="empty-title">খাদ্য স্টক খালি</div>
          <div class="empty-desc">নতুন খাদ্য ক্রয়ের তথ্য স্টকে যুক্ত করুন।</div>
          <button class="btn btn-primary" onclick="App.openFeedStockModal()">
            <span>➕</span> নতুন খাদ্য স্টক যোগ করুন
          </button>
        </div>
      `;
      return;
    }

    listEl.innerHTML = feedStock.map(f => `
      <div class="item-card">
        <div class="item-card-header">
          <div class="card-title-group">
            <h4>${f.feedName}</h4>
            <div class="card-tag">ব্র্যান্ড: ${f.brand || 'সাধারণ'} | তারিখ: ${f.date}</div>
          </div>
          <span class="badge ${f.feedType === 'ভাসা' ? 'badge-info' : 'badge-warning'}">${f.feedType}</span>
        </div>

        <div class="item-data-grid">
          <div class="data-row">
            <span class="data-label">মোট পরিমাণ</span>
            <span class="data-val">${f.totalKg} কেজি (${f.totalSacks} বস্তা)</span>
          </div>
          <div class="data-row">
            <span class="data-label">প্রতি কেজির দাম ও মোট মূল্য</span>
            <span class="data-val">৳ ${f.ratePerKg} | মোট: <strong>৳ ${f.totalPrice.toLocaleString('bn-BD')}</strong></span>
          </div>
          <div class="data-row">
            <span class="data-label">সরবরাহকারী</span>
            <span class="data-val">${f.supplier || 'লিপিবদ্ধ নেই'}</span>
          </div>
          <div class="data-row">
            <span class="data-label">চালান নম্বর</span>
            <span class="data-val">${f.invoiceNo || '-'}</span>
          </div>
        </div>

        <div class="card-actions">
          <button class="btn btn-secondary btn-sm" onclick="App.openFeedStockModal('${f.id}')">
            <span>✏️</span> সম্পাদন
          </button>
          <button class="btn btn-danger btn-sm" onclick="App.deleteItem('feedStock', '${f.id}', '${f.feedName}')">
            <span>🗑️</span> মুছুন
          </button>
        </div>
      </div>
    `).join('');
  },

  openFeedStockModal(feedId = null) {
    try {
      if (typeof feedId !== 'string' && typeof feedId !== 'number') {
        feedId = null;
      }
      const isEdit = !!feedId;
      const feed = (isEdit ? db.getById('feedStock', feedId) : null) || {};

      const html = `
        <form id="feed-stock-form">
          <input type="hidden" name="id" id="fs-id" value="${feed.id || ''}">
          <div class="form-row">
            <div class="form-group">
              <label class="form-label">তারিখ <span class="required">*</span></label>
              <input type="date" class="form-control" name="date" id="fs-date" value="${feed.date || new Date().toISOString().split('T')[0]}" required>
            </div>
            <div class="form-group">
              <label class="form-label">খাদ্যের ধরন <span class="required">*</span></label>
              <select class="form-control" name="feedType" id="fs-type">
                <option value="ভাসা" ${feed.feedType === 'ভাসা' || !feed.feedType ? 'selected' : ''}>ভাসা (Floating)</option>
                <option value="ডুবন্ত" ${feed.feedType === 'ডুবন্ত' ? 'selected' : ''}>ডুবন্ত (Sinking)</option>
                <option value="অন্যান্য" ${feed.feedType === 'অন্যান্য' ? 'selected' : ''}>অন্যান্য</option>
              </select>
            </div>
          </div>

          <div class="form-row">
            <div class="form-group">
              <label class="form-label">খাদ্যের নাম <span class="required">*</span></label>
              <input type="text" class="form-control" name="feedName" id="fs-name" value="${feed.feedName || ''}" placeholder="যেমন: মেগা গ্রোয়ার ফিড" required>
            </div>
            <div class="form-group">
              <label class="form-label">কোম্পানি / ব্র্যান্ড</label>
              <input type="text" class="form-control" name="brand" id="fs-brand" value="${feed.brand || ''}" placeholder="যেমন: মেগা, আফতাব, নারিশ">
            </div>
          </div>

          <div class="form-row">
            <div class="form-group">
              <label class="form-label">পরিমাণ (বস্তা)</label>
              <input type="number" id="fs-sacks" class="form-control" name="totalSacks" value="${feed.totalSacks || ''}" placeholder="বস্তা সংখ্যা">
            </div>
            <div class="form-group">
              <label class="form-label">প্রতি বস্তার কেজি</label>
              <input type="number" id="fs-kg-per-sack" class="form-control" name="kgPerSack" value="${feed.kgPerSack || 50}" placeholder="৫০">
            </div>
          </div>

          <div class="form-row">
            <div class="form-group">
              <label class="form-label">মোট পরিমাণ (কেজি) <span class="required">*</span></label>
              <input type="number" step="0.1" id="fs-total-kg" class="form-control" name="totalKg" value="${feed.totalKg || ''}" placeholder="যেমন: ১০০০" required>
            </div>
            <div class="form-group">
              <label class="form-label">প্রতি কেজির দাম (৳) <span class="required">*</span></label>
              <input type="number" step="0.1" id="fs-rate" class="form-control" name="ratePerKg" value="${feed.ratePerKg || ''}" placeholder="যেমন: ৭৮" required>
            </div>
          </div>

          <div class="form-group">
            <label class="form-label">মোট মূল্য (স্বয়ংক্রিয় হিসাব) (৳)</label>
            <input type="number" id="fs-total-price" class="form-control" name="totalPrice" value="${feed.totalPrice || ''}" readonly style="background:#f4f8f5; font-weight:700; color:var(--primary-dark);">
          </div>

          <div class="form-row">
            <div class="form-group">
              <label class="form-label">সরবরাহকারী</label>
              <input type="text" class="form-control" name="supplier" id="fs-supplier" value="${feed.supplier || ''}" placeholder="ডিলার বা দোকানের নাম">
            </div>
            <div class="form-group">
              <label class="form-label">চালান নম্বর</label>
              <input type="text" class="form-control" name="invoiceNo" id="fs-invoice" value="${feed.invoiceNo || ''}" placeholder="চালান / রসিদ নং">
            </div>
          </div>

          <div class="form-group">
            <label class="form-label">নোট</label>
            <textarea class="form-control" name="note" id="fs-note" placeholder="খাদ্যের গুণাগুণ বা বিশেষ নোট">${feed.note || ''}</textarea>
          </div>
        </form>
      `;

      UI.openFormModal(
        isEdit ? '✏️ খাদ্য স্টক সম্পাদন' : '🌾 নতুন খাদ্য স্টক যোগ',
        html,
        'সংরক্ষণ করুন',
        () => App.saveFeedStock(null, feedId)
      );

      // Setup auto-calc listeners
      setTimeout(() => {
        const sacks = document.getElementById('fs-sacks');
        const kgPerSack = document.getElementById('fs-kg-per-sack');
        const totalKg = document.getElementById('fs-total-kg');
        const rate = document.getElementById('fs-rate');
        const totalPrice = document.getElementById('fs-total-price');

        const calc = () => {
          const s = parseFloat(sacks ? sacks.value : 0) || 0;
          const kps = parseFloat(kgPerSack ? kgPerSack.value : 50) || 50;
          if (s > 0 && totalKg && !totalKg.dataset.manual) {
            totalKg.value = s * kps;
          }
          const kg = parseFloat(totalKg ? totalKg.value : 0) || 0;
          const r = parseFloat(rate ? rate.value : 0) || 0;
          if (totalPrice) totalPrice.value = (kg * r).toFixed(0);
        };

        if (sacks && kgPerSack && totalKg && rate) {
          sacks.addEventListener('input', () => { if (totalKg) delete totalKg.dataset.manual; calc(); });
          kgPerSack.addEventListener('input', calc);
          totalKg.addEventListener('input', () => { totalKg.dataset.manual = 'true'; calc(); });
          rate.addEventListener('input', calc);
          calc();
        }
      }, 50);
    } catch (err) {
      console.error('Error opening feed stock modal:', err);
      UI.showToast('খাদ্য স্টক ফরম খুলতে সমস্যা: ' + err.message, 'error');
    }
  },

  // =========================================================================
  // 5. DAILY FEED (দৈনিক খাদ্য হিসাব)
  // =========================================================================
  renderDailyFeed() {
    const listEl = document.getElementById('daily-feed-list');
    const filterPond = document.getElementById('daily-feed-pond-filter');
    const filterDate = document.getElementById('daily-feed-date-filter');
    if (!listEl) return;

    // Populate pond filter options
    if (filterPond && filterPond.children.length <= 1) {
      const ponds = db.getAll('ponds');
      filterPond.innerHTML = '<option value="all">সকল পুকুর</option>' +
        ponds.map(p => `<option value="${p.id}">${p.name}</option>`).join('');
    }

    const selectedPond = filterPond ? filterPond.value : 'all';
    const selectedDate = filterDate ? filterDate.value : '';

    let items = db.getAll('dailyFeed');

    if (selectedPond !== 'all') {
      items = items.filter(i => i.pondId === selectedPond);
    }
    if (selectedDate) {
      items = items.filter(i => i.date === selectedDate);
    }

    if (items.length === 0) {
      listEl.innerHTML = `
        <div class="empty-state">
          <div class="empty-icon">🍚</div>
          <div class="empty-title">কোনো খাদ্য হিসাব পাওয়া যায়নি</div>
          <div class="empty-desc">প্রতিদিনের খাদ্য বিতরণের হিসাব রাখুন।</div>
          <button class="btn btn-primary" onclick="App.openDailyFeedModal()">
            <span>➕</span> দৈনিক খাদ্য হিসাব যোগ করুন
          </button>
        </div>
      `;
      return;
    }

    const totalKg = items.reduce((acc, i) => acc + (parseFloat(i.amountKg) || 0), 0);
    const totalCost = items.reduce((acc, i) => acc + (parseFloat(i.totalPrice) || 0), 0);

    listEl.innerHTML = `
      <div style="background:var(--primary-subtle); padding:10px 14px; border-radius:8px; margin-bottom:12px; display:flex; justify-content:space-between; font-size:13px; font-weight:700; color:var(--primary-dark);">
        <span>মোট খাদ্য: ${totalKg} কেজি</span>
        <span>মোট খাদ্য খরচ: ৳ ${totalCost.toLocaleString('bn-BD')}</span>
      </div>

      <div class="card-list">
        ${items.map(item => `
          <div class="item-card">
            <div class="item-card-header">
              <div class="card-title-group">
                <h4>${item.pondName}</h4>
                <div class="card-tag">তারিখ: ${item.date} (${item.time || 'সকাল'}) | প্রদানকারী: ${item.fedBy || 'অজ্ঞাত'}</div>
              </div>
              <span class="badge badge-info">${item.feedType || 'ভাসা'}</span>
            </div>

            <div class="item-data-grid">
              <div class="data-row">
                <span class="data-label">খাদ্যের নাম</span>
                <span class="data-val">${item.feedName || 'ফিড'} (${item.brand || '-'})</span>
              </div>
              <div class="data-row">
                <span class="data-label">পরিমাণ ও দাম</span>
                <span class="data-val">${item.amountKg} কেজি @ ৳ ${item.ratePerKg || 0}</span>
              </div>
              <div class="data-row">
                <span class="data-label">মোট খরচ</span>
                <span class="data-val" style="color:var(--danger)">৳ ${(item.totalPrice || 0).toLocaleString('bn-BD')}</span>
              </div>
              <div class="data-row">
                <span class="data-label">মন্তব্য</span>
                <span class="data-val">${item.note || 'স্বাভাবিক'}</span>
              </div>
            </div>

            <div class="card-actions">
              <button class="btn btn-secondary btn-sm" onclick="App.openDailyFeedModal('${item.id}')">
                <span>✏️</span> সম্পাদন
              </button>
              <button class="btn btn-danger btn-sm" onclick="App.deleteItem('dailyFeed', '${item.id}', '${item.pondName} - ${item.amountKg} কেজি')">
                <span>🗑️</span> মুছুন
              </button>
            </div>
          </div>
        `).join('')}
      </div>
    `;
  },

  openDailyFeedModal(feedId = null) {
    try {
      if (typeof feedId !== 'string' && typeof feedId !== 'number') {
        feedId = null;
      }

      let ponds = db.getAll('ponds');
      if (!ponds || !Array.isArray(ponds) || ponds.length === 0) {
        const p = db.insert('ponds', {
          name: 'পুকুর ১',
          number: 'P-101',
          area: 50,
          unit: 'শতাংশ',
          status: 'সক্রিয়'
        });
        ponds = [p];
      }

      const isEdit = !!feedId;
      const item = (isEdit ? db.getById('dailyFeed', feedId) : null) || {};

      // Pull feed stocks to give user instant suggestions
      const feedStocks = db.getAll('feedStock') || [];
      const defaultFeedName = item.feedName || (feedStocks.length > 0 ? feedStocks[0].feedName : 'মেগা ফ্লোটিং ফিড');
      const defaultBrand = item.brand || (feedStocks.length > 0 ? (feedStocks[0].brand || '') : '');
      const defaultRate = item.ratePerKg || (feedStocks.length > 0 && feedStocks[0].ratePerKg ? feedStocks[0].ratePerKg : 78);
      const defaultType = item.feedType || (feedStocks.length > 0 ? (feedStocks[0].feedType || 'ভাসা') : 'ভাসা');

      const html = `
        <form id="daily-feed-form">
          <input type="hidden" name="id" id="df-id" value="${item.id || ''}">
          <div class="form-row">
            <div class="form-group">
              <label class="form-label">তারিখ <span class="required">*</span></label>
              <input type="date" class="form-control" name="date" id="df-date" value="${item.date || new Date().toISOString().split('T')[0]}" required>
            </div>
            <div class="form-group">
              <label class="form-label">পুকুর <span class="required">*</span></label>
              <select class="form-control" name="pondId" id="df-pond-select" required>
                ${ponds.map(p => `<option value="${p.id}" ${item.pondId === p.id ? 'selected' : ''}>${p.name}</option>`).join('')}
              </select>
            </div>
          </div>

          <div class="form-row">
            <div class="form-group">
              <label class="form-label">সময়</label>
              <select class="form-control" name="time" id="df-time">
                <option value="সকাল" ${item.time === 'সকাল' || !item.time ? 'selected' : ''}>সকাল</option>
                <option value="দুপুর" ${item.time === 'দুপুর' ? 'selected' : ''}>দুপুর</option>
                <option value="বিকাল" ${item.time === 'বিকাল' ? 'selected' : ''}>বিকাল</option>
                <option value="রাত" ${item.time === 'রাত' ? 'selected' : ''}>রাত</option>
              </select>
            </div>
            <div class="form-group">
              <label class="form-label">খাদ্যের ধরন</label>
              <select class="form-control" name="feedType" id="df-type">
                <option value="ভাসা" ${defaultType === 'ভাসা' ? 'selected' : ''}>ভাসা (Floating)</option>
                <option value="ডুবন্ত" ${defaultType === 'ডুবন্ত' ? 'selected' : ''}>ডুবন্ত (Sinking)</option>
                <option value="অন্যান্য" ${defaultType === 'অন্যান্য' ? 'selected' : ''}>অন্যান্য</option>
              </select>
            </div>
          </div>

          <div class="form-row">
            <div class="form-group">
              <label class="form-label">খাদ্যের নাম <span class="required">*</span></label>
              <input type="text" class="form-control" name="feedName" id="df-name" value="${defaultFeedName}" list="df-stock-datalist" placeholder="খাদ্যের নাম লিখুন বা বাছুন" required>
              <datalist id="df-stock-datalist">
                ${feedStocks.map(f => `<option value="${f.feedName}">মজুদ: ${f.totalKg || 0} কেজি, দর: ৳${f.ratePerKg || 0}</option>`).join('')}
              </datalist>
            </div>
            <div class="form-group">
              <label class="form-label">ব্র্যান্ড / কোম্পানি</label>
              <input type="text" class="form-control" name="brand" id="df-brand" value="${defaultBrand}" placeholder="ব্র্যান্ডের নাম">
            </div>
          </div>

          <div class="form-row">
            <div class="form-group">
              <label class="form-label">পরিমাণ (কেজি) <span class="required">*</span></label>
              <input type="number" step="0.1" id="df-amount" class="form-control" name="amountKg" value="${item.amountKg || ''}" placeholder="যেমন: ২৫" required>
            </div>
            <div class="form-group">
              <label class="form-label">প্রতি কেজির দাম (৳)</label>
              <input type="number" step="0.1" id="df-rate" class="form-control" name="ratePerKg" value="${defaultRate}">
            </div>
          </div>

          <div class="form-group">
            <label class="form-label">মোট খরচ (স্বয়ংক্রিয় হিসাব) (৳)</label>
            <input type="number" id="df-total" class="form-control" name="totalPrice" value="${item.totalPrice || ''}" readonly style="background:#f4f8f5; font-weight:700; color:var(--primary-dark);">
          </div>

          <div class="form-row">
            <div class="form-group">
              <label class="form-label">কে দিয়েছে (প্রদানকারী)</label>
              <input type="text" class="form-control" name="fedBy" id="df-fed-by" value="${item.fedBy || ''}" placeholder="কর্মচারী বা সদস্যের নাম">
            </div>
            <div class="form-group">
              <label class="form-label">মন্তব্য / নোট</label>
              <input type="text" class="form-control" name="note" id="df-note" value="${item.note || ''}" placeholder="মাছের স্বাস্থ্য বা খাবারের মন্তব্য">
            </div>
          </div>
        </form>
      `;

      UI.openFormModal(
        isEdit ? '✏️ দৈনিক খাদ্য হিসাব সম্পাদন' : '🍚 দৈনিক খাদ্য দেওয়া / বিতরণ যোগ',
        html,
        'সংরক্ষণ করুন',
        () => App.saveDailyFeed(null, feedId)
      );

      setTimeout(() => {
        const nameInput = document.getElementById('df-name');
        const brandInput = document.getElementById('df-brand');
        const typeSelect = document.getElementById('df-type');
        const amount = document.getElementById('df-amount');
        const rate = document.getElementById('df-rate');
        const total = document.getElementById('df-total');

        const calc = () => {
          const a = parseFloat(amount ? amount.value : 0) || 0;
          const r = parseFloat(rate ? rate.value : 0) || 0;
          if (total) total.value = (a * r).toFixed(0);
        };

        if (nameInput) {
          nameInput.addEventListener('change', () => {
            const val = nameInput.value.trim();
            const matched = feedStocks.find(f => f.feedName === val);
            if (matched) {
              if (brandInput && (!brandInput.value || brandInput.value === defaultBrand)) brandInput.value = matched.brand || '';
              if (typeSelect && matched.feedType) typeSelect.value = matched.feedType;
              if (rate && matched.ratePerKg) rate.value = matched.ratePerKg;
              calc();
            }
          });
        }

        if (amount && rate) {
          amount.addEventListener('input', calc);
          rate.addEventListener('input', calc);
          calc();
        }
      }, 50);
    } catch (err) {
      console.error('Error opening daily feed modal:', err);
      UI.showToast('খাদ্য ফরম খুলতে সমস্যা: ' + err.message, 'error');
    }
  },

  // =========================================================================
  // 6. FISH PURCHASE (মাছ/পোনা ক্রয়)
  // =========================================================================
  renderFishBuy() {
    const listEl = document.getElementById('fish-buy-list');
    if (!listEl) return;

    const items = db.getAll('fishBuy');
    if (items.length === 0) {
      listEl.innerHTML = `
        <div class="empty-state">
          <div class="empty-icon">🐠</div>
          <div class="empty-title">পোনা ক্রয়ের কোনো তথ্য নেই</div>
          <div class="empty-desc">নতুন পোনা ক্রয়ের হিসাব যোগ করুন।</div>
          <button class="btn btn-primary" onclick="App.openFishBuyModal()">
            <span>➕</span> মাছ/পোনা ক্রয় যোগ করুন
          </button>
        </div>
      `;
      return;
    }

    listEl.innerHTML = items.map(fb => `
      <div class="item-card">
        <div class="item-card-header">
          <div class="card-title-group">
            <h4>${fb.fishType}</h4>
            <div class="card-tag">পুকুর: ${fb.pondName} | তারিখ: ${fb.date}</div>
          </div>
          <span class="badge badge-info">${fb.count} টি পোনা</span>
        </div>

        <div class="item-data-grid">
          <div class="data-row">
            <span class="data-label">সাইজ / বয়স</span>
            <span class="data-val">${fb.sizeAge || '-'}</span>
          </div>
          <div class="data-row">
            <span class="data-label">মোট ওজন ও প্রতি কেজির দাম</span>
            <span class="data-val">${fb.totalWeight || 0} কেজি @ ৳ ${fb.ratePerKg || 0}</span>
          </div>
          <div class="data-row">
            <span class="data-label">মোট মূল্য</span>
            <span class="data-val" style="color:var(--danger)">৳ ${(fb.totalPrice || 0).toLocaleString('bn-BD')}</span>
          </div>
          <div class="data-row">
            <span class="data-label">বিক্রেতা</span>
            <span class="data-val">${fb.seller || '-'}</span>
          </div>
        </div>

        <div class="card-actions">
          <button class="btn btn-secondary btn-sm" onclick="App.openFishBuyModal('${fb.id}')">
            <span>✏️</span> সম্পাদন
          </button>
          <button class="btn btn-danger btn-sm" onclick="App.deleteItem('fishBuy', '${fb.id}', '${fb.fishType}')">
            <span>🗑️</span> মুছুন
          </button>
        </div>
      </div>
    `).join('');
  },

  openFishBuyModal(buyId = null) {
    let ponds = db.getAll('ponds');
    if (ponds.length === 0) {
      const p = db.insert('ponds', {
        name: 'পুকুর ১',
        number: 'P-101',
        area: 50,
        unit: 'শতাংশ',
        status: 'সক্রিয়'
      });
      ponds = [p];
    }
    const isEdit = !!buyId;
    const item = isEdit ? db.getById('fishBuy', buyId) : {};

    const html = `
      <form id="fish-buy-form">
        <input type="hidden" name="id" id="fb-id" value="${item.id || ''}">
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">তারিখ <span class="required">*</span></label>
            <input type="date" class="form-control" name="date" id="fb-date" value="${item.date || new Date().toISOString().split('T')[0]}" required>
          </div>
          <div class="form-group">
            <label class="form-label">পুকুর <span class="required">*</span></label>
            <select class="form-control" name="pondId" id="fb-pond" required>
              ${ponds.map(p => `<option value="${p.id}" ${item.pondId === p.id ? 'selected' : ''}>${p.name}</option>`).join('')}
            </select>
          </div>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label class="form-label">মাছের ধরন / নাম <span class="required">*</span></label>
            <input type="text" class="form-control" name="fishType" id="fb-type" value="${item.fishType || ''}" placeholder="যেমন: রুই ও কাতলা পোনা" required>
          </div>
          <div class="form-group">
            <label class="form-label">মাছের বয়স / সাইজ</label>
            <input type="text" class="form-control" name="sizeAge" id="fb-size" value="${item.sizeAge || ''}" placeholder="যেমন: ৩-৪ ইঞ্চি">
          </div>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label class="form-label">সংখ্যা (টি) <span class="required">*</span></label>
            <input type="number" class="form-control" name="count" id="fb-count" value="${item.count || ''}" placeholder="যেমন: ৫০০০" required>
          </div>
          <div class="form-group">
            <label class="form-label">মোট ওজন (কেজি)</label>
            <input type="number" step="0.1" id="fb-weight" class="form-control" name="totalWeight" value="${item.totalWeight || ''}" placeholder="যেমন: ২০০">
          </div>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label class="form-label">প্রতি কেজির দাম (৳)</label>
            <input type="number" step="0.1" id="fb-rate" class="form-control" name="ratePerKg" value="${item.ratePerKg || ''}" placeholder="যেমন: ৩০০">
          </div>
          <div class="form-group">
            <label class="form-label">মোট মূল্য (৳)</label>
            <input type="number" id="fb-total" class="form-control" name="totalPrice" value="${item.totalPrice || ''}">
          </div>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label class="form-label">বিক্রেতা / হ্যাচারি</label>
            <input type="text" class="form-control" name="seller" id="fb-seller" value="${item.seller || ''}" placeholder="হ্যাচারির নাম">
          </div>
          <div class="form-group">
            <label class="form-label">নোট</label>
            <input type="text" class="form-control" name="note" id="fb-note" value="${item.note || ''}">
          </div>
        </div>
      </form>
    `;

    UI.openFormModal(
      isEdit ? '✏️ মাছ/পোনা ক্রয় সম্পাদন' : '🐠 নতুন মাছ/পোনা ক্রয় যোগ',
      html,
      'সংরক্ষণ করুন',
      () => App.saveFishPurchase(null, buyId)
    );

    setTimeout(() => {
      const weight = document.getElementById('fb-weight');
      const rate = document.getElementById('fb-rate');
      const total = document.getElementById('fb-total');
      const calc = () => {
        const w = parseFloat(weight.value) || 0;
        const r = parseFloat(rate.value) || 0;
        if (w > 0 && r > 0) total.value = (w * r).toFixed(0);
      };
      if (weight && rate) {
        weight.addEventListener('input', calc);
        rate.addEventListener('input', calc);
      }
    }, 100);
  },

  // =========================================================================
  // 7. FISH SALE (মাছ বিক্রয়)
  // =========================================================================
  renderFishSell() {
    const listEl = document.getElementById('fish-sell-list');
    if (!listEl) return;

    const items = db.getAll('fishSell');
    if (items.length === 0) {
      listEl.innerHTML = `
        <div class="empty-state">
          <div class="empty-icon">🐟</div>
          <div class="empty-title">মাছ বিক্রয়ের কোনো হিসাব নেই</div>
          <div class="empty-desc">পুকুর থেকে মাছ বিক্রয় ও আয়ের হিসাব যুক্ত করুন।</div>
          <button class="btn btn-primary" onclick="App.openFishSellModal()">
            <span>➕</span> নতুন মাছ বিক্রয় যোগ করুন
          </button>
        </div>
      `;
      return;
    }

    listEl.innerHTML = items.map(fs => `
      <div class="item-card">
        <div class="item-card-header">
          <div class="card-title-group">
            <h4>${fs.fishType}</h4>
            <div class="card-tag">পুকুর: ${fs.pondName} | তারিখ: ${fs.date}</div>
          </div>
          <span class="badge badge-success">আয়: ৳ ${(fs.totalPrice || 0).toLocaleString('bn-BD')}</span>
        </div>

        <div class="item-data-grid">
          <div class="data-row">
            <span class="data-label">পরিমাণ ও মোট ওজন</span>
            <span class="data-val">${fs.count || 0} টি (${fs.totalWeight} কেজি)</span>
          </div>
          <div class="data-row">
            <span class="data-label">প্রতি কেজির বিক্রয় মূল্য</span>
            <span class="data-val">৳ ${fs.ratePerKg}</span>
          </div>
          <div class="data-row">
            <span class="data-label">ক্রেতার নাম</span>
            <span class="data-val">${fs.buyerName || 'সাধারণ পাইকার'}</span>
          </div>
          <div class="data-row">
            <span class="data-label">ক্রেতার মোবাইল</span>
            <span class="data-val">${fs.buyerMobile || '-'}</span>
          </div>
        </div>

        <div class="card-actions">
          <button class="btn btn-secondary btn-sm" onclick="App.openFishSellModal('${fs.id}')">
            <span>✏️</span> সম্পাদন
          </button>
          <button class="btn btn-danger btn-sm" onclick="App.deleteItem('fishSell', '${fs.id}', '${fs.fishType} - ৳ ${fs.totalPrice}')">
            <span>🗑️</span> মুছুন
          </button>
        </div>
      </div>
    `).join('');
  },

  openFishSellModal(sellId = null) {
    let ponds = db.getAll('ponds');
    if (ponds.length === 0) {
      const p = db.insert('ponds', {
        name: 'পুকুর ১',
        number: 'P-101',
        area: 50,
        unit: 'শতাংশ',
        status: 'সক্রিয়'
      });
      ponds = [p];
    }
    const isEdit = !!sellId;
    const item = isEdit ? db.getById('fishSell', sellId) : {};

    const html = `
      <form id="fish-sell-form">
        <input type="hidden" name="id" id="fsell-id" value="${item.id || ''}">
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">তারিখ <span class="required">*</span></label>
            <input type="date" class="form-control" name="date" id="fsell-date" value="${item.date || new Date().toISOString().split('T')[0]}" required>
          </div>
          <div class="form-group">
            <label class="form-label">পুকুর <span class="required">*</span></label>
            <select class="form-control" name="pondId" id="fsell-pond" required>
              ${ponds.map(p => `<option value="${p.id}" ${item.pondId === p.id ? 'selected' : ''}>${p.name}</option>`).join('')}
            </select>
          </div>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label class="form-label">মাছের ধরন <span class="required">*</span></label>
            <input type="text" class="form-control" name="fishType" id="fsell-type" value="${item.fishType || ''}" placeholder="যেমন: তেলাপিয়া বা রুই" required>
          </div>
          <div class="form-group">
            <label class="form-label">পরিমাণ (সংখ্যা)</label>
            <input type="number" class="form-control" name="count" id="fsell-count" value="${item.count || ''}" placeholder="মাছের সংখ্যা">
          </div>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label class="form-label">মোট ওজন (কেজি) <span class="required">*</span></label>
            <input type="number" step="0.1" id="fsell-weight" class="form-control" name="totalWeight" value="${item.totalWeight || ''}" placeholder="যেমন: ৩৫০" required>
          </div>
          <div class="form-group">
            <label class="form-label">প্রতি কেজির দাম (৳) <span class="required">*</span></label>
            <input type="number" step="0.1" id="fsell-rate" class="form-control" name="ratePerKg" value="${item.ratePerKg || ''}" placeholder="যেমন: ২০০" required>
          </div>
        </div>

        <div class="form-group">
          <label class="form-label">মোট বিক্রয় মূল্য (স্বয়ংক্রিয় হিসাব) (৳)</label>
          <input type="number" id="fsell-total" class="form-control" name="totalPrice" value="${item.totalPrice || ''}" readonly style="background:#f4f8f5; font-weight:700; color:var(--success);">
        </div>

        <div class="form-row">
          <div class="form-group">
            <label class="form-label">ক্রেতার নাম</label>
            <input type="text" class="form-control" name="buyerName" id="fsell-buyer" value="${item.buyerName || ''}" placeholder="ক্রেতার নাম">
          </div>
          <div class="form-group">
            <label class="form-label">ক্রেতার মোবাইল</label>
            <input type="tel" class="form-control" name="buyerMobile" id="fsell-buyer-mobile" value="${item.buyerMobile || ''}" placeholder="মোবাইল নম্বর">
          </div>
        </div>

        <div class="form-group">
          <label class="form-label">নোট</label>
          <textarea class="form-control" name="note" id="fsell-note" placeholder="বিক্রয় সংক্রান্ত তথ্য">${item.note || ''}</textarea>
        </div>
      </form>
    `;

    UI.openFormModal(
      isEdit ? '✏️ মাছ বিক্রয় তথ্য সম্পাদন' : '🐟 নতুন মাছ বিক্রয় এন্ট্রি',
      html,
      'সংরক্ষণ করুন',
      () => App.saveFishSale(null, sellId)
    );

    setTimeout(() => {
      const weight = document.getElementById('fsell-weight');
      const rate = document.getElementById('fsell-rate');
      const total = document.getElementById('fsell-total');
      const calc = () => {
        const w = parseFloat(weight.value) || 0;
        const r = parseFloat(rate.value) || 0;
        total.value = (w * r).toFixed(0);
      };
      if (weight && rate) {
        weight.addEventListener('input', calc);
        rate.addEventListener('input', calc);
        calc();
      }
    }, 100);
  },

  // =========================================================================
  // 8. DEAD FISH (মৃত মাছের হিসাব)
  // =========================================================================
  renderDeadFish() {
    const listEl = document.getElementById('dead-fish-list');
    if (!listEl) return;

    const items = db.getAll('deadFish');
    if (items.length === 0) {
      listEl.innerHTML = `
        <div class="empty-state">
          <div class="empty-icon">☠️</div>
          <div class="empty-title">মৃত মাছের কোনো রেকর্ড নেই</div>
          <div class="empty-desc">আল্লাহর রহমতে মাছের কোনো ক্ষতি রেকর্ড করা হয়নি।</div>
          <button class="btn btn-primary" onclick="App.openDeadFishModal()">
            <span>➕</span> নতুন মৃত মাছ রেকর্ড করুন
          </button>
        </div>
      `;
      return;
    }

    listEl.innerHTML = items.map(df => `
      <div class="item-card">
        <div class="item-card-header">
          <div class="card-title-group">
            <h4>${df.fishType} (${df.count} টি)</h4>
            <div class="card-tag">পুকুর: ${df.pondName} | তারিখ: ${df.date}</div>
          </div>
          <span class="badge badge-danger">মৃত: ${df.count} টি</span>
        </div>

        <div class="item-data-grid">
          <div class="data-row">
            <span class="data-label">আনুমানিক ওজন</span>
            <span class="data-val">${df.estimatedWeight || 0} কেজি</span>
          </div>
          <div class="data-row">
            <span class="data-label">কারণ</span>
            <span class="data-val" style="color:var(--danger)">${df.cause || 'অজ্ঞাত'}</span>
          </div>
          <div class="data-row" style="grid-column: span 2;">
            <span class="data-label">নোট ও গৃহীত ব্যবস্থা</span>
            <span class="data-val">${df.note || '-'}</span>
          </div>
        </div>

        <div class="card-actions">
          <button class="btn btn-secondary btn-sm" onclick="App.openDeadFishModal('${df.id}')">
            <span>✏️</span> সম্পাদন
          </button>
          <button class="btn btn-danger btn-sm" onclick="App.deleteItem('deadFish', '${df.id}', '${df.fishType} - ${df.count} টি')">
            <span>🗑️</span> মুছুন
          </button>
        </div>
      </div>
    `).join('');
  },

  openDeadFishModal(dfId = null) {
    let ponds = db.getAll('ponds');
    if (ponds.length === 0) {
      const p = db.insert('ponds', {
        name: 'পুকুর ১',
        number: 'P-101',
        area: 50,
        unit: 'শতাংশ',
        status: 'সক্রিয়'
      });
      ponds = [p];
    }
    const isEdit = !!dfId;
    const item = isEdit ? db.getById('deadFish', dfId) : {};

    const html = `
      <form id="dead-fish-form">
        <input type="hidden" name="id" id="dfish-id" value="${item.id || ''}">
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">তারিখ <span class="required">*</span></label>
            <input type="date" class="form-control" name="date" id="dfish-date" value="${item.date || new Date().toISOString().split('T')[0]}" required>
          </div>
          <div class="form-group">
            <label class="form-label">পুকুর <span class="required">*</span></label>
            <select class="form-control" name="pondId" id="dfish-pond" required>
              ${ponds.map(p => `<option value="${p.id}" ${item.pondId === p.id ? 'selected' : ''}>${p.name}</option>`).join('')}
            </select>
          </div>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label class="form-label">মাছের ধরন <span class="required">*</span></label>
            <input type="text" class="form-control" name="fishType" id="dfish-type" value="${item.fishType || ''}" placeholder="যেমন: রুই / তেলাপিয়া" required>
          </div>
          <div class="form-group">
            <label class="form-label">সংখ্যা (টি) <span class="required">*</span></label>
            <input type="number" class="form-control" name="count" id="dfish-count" value="${item.count || ''}" placeholder="মৃত মাছের সংখ্যা" required>
          </div>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label class="form-label">আনুমানিক মোট ওজন (কেজি)</label>
            <input type="number" step="0.1" class="form-control" name="estimatedWeight" id="dfish-weight" value="${item.estimatedWeight || ''}" placeholder="যেমন: ৫">
          </div>
          <div class="form-group">
            <label class="form-label">কারণ</label>
            <select class="form-control" name="cause" id="dfish-cause">
              <option value="অক্সিজেন স্বল্পতা" ${item.cause === 'অক্সিজেন স্বল্পতা' ? 'selected' : ''}>অক্সিজেন স্বল্পতা</option>
              <option value="রোগ বা ইনফেকশন" ${item.cause === 'রোগ বা ইনফেকশন' ? 'selected' : ''}>রোগ বা ইনফেকশন</option>
              <option value="বিষক্রিয়া / গ্যাস সমস্যা" ${item.cause === 'বিষক্রিয়া / গ্যাস সমস্যা' ? 'selected' : ''}>বিষক্রিয়া / গ্যাস সমস্যা</option>
              <option value="তীব্র ঠাণ্ডা বা গরম" ${item.cause === 'তীব্র ঠাণ্ডা বা গরম' ? 'selected' : ''}>তীব্র ঠাণ্ডা বা গরম</option>
              <option value="পরিবহন ক্লান্তি" ${item.cause === 'পরিবহন ক্লান্তি' ? 'selected' : ''}>পরিবহন ক্লান্তি</option>
              <option value="অন্যান্য" ${item.cause === 'অন্যান্য' ? 'selected' : ''}>অন্যান্য</option>
            </select>
          </div>
        </div>

        <div class="form-group">
          <label class="form-label">নোট ও গৃহীত প্রতিকার</label>
          <textarea class="form-control" name="note" id="dfish-note" placeholder="গৃহীত প্রতিকার বা মন্তব্য">${item.note || ''}</textarea>
        </div>
      </form>
    `;

    UI.openFormModal(
      isEdit ? '✏️ মৃত মাছ রেকর্ড সম্পাদন' : '☠️ মৃত মাছের হিসাব যোগ',
      html,
      'সংরক্ষণ করুন',
      () => App.saveMortality(null, dfId)
    );
  },

  // =========================================================================
  // 9. DAILY EXPENSES (দৈনিক খরচ)
  // =========================================================================
  renderExpenses() {
    const listEl = document.getElementById('expenses-list');
    const filterCat = document.getElementById('expense-cat-filter');
    if (!listEl) return;

    const selectedCat = filterCat ? filterCat.value : 'all';
    let expenses = db.getAll('expenses');

    if (selectedCat !== 'all') {
      expenses = expenses.filter(e => e.category === selectedCat);
    }

    if (expenses.length === 0) {
      listEl.innerHTML = `
        <div class="empty-state">
          <div class="empty-icon">💰</div>
          <div class="empty-title">কোনো খরচ পাওয়া যায়নি</div>
          <div class="empty-desc">খামারের দৈনিক খরচের হিসাব যুক্ত করুন।</div>
          <button class="btn btn-primary" onclick="App.openExpenseModal()">
            <span>➕</span> নতুন খরচ যোগ করুন
          </button>
        </div>
      `;
      return;
    }

    const totalMoney = expenses.reduce((acc, e) => acc + (parseFloat(e.totalMoney) || 0), 0);

    listEl.innerHTML = `
      <div style="background:#fff3f3; border:1px solid #f5c6cb; padding:10px 14px; border-radius:8px; margin-bottom:12px; font-weight:700; color:var(--danger); display:flex; justify-content:space-between;">
        <span>মোট ব্যয় এন্ট্রি: ${expenses.length} টি</span>
        <span>মোট টাকা: ৳ ${totalMoney.toLocaleString('bn-BD')}</span>
      </div>

      <div class="card-list">
        ${expenses.map(e => `
          <div class="item-card">
            <div class="item-card-header">
              <div class="card-title-group">
                <h4>${e.description}</h4>
                <div class="card-tag">পুকুর: ${e.pondName} | তারিখ: ${e.date}</div>
              </div>
              <span class="badge badge-danger">৳ ${(e.totalMoney || 0).toLocaleString('bn-BD')}</span>
            </div>

            <div class="item-data-grid">
              <div class="data-row">
                <span class="data-label">খরচের ক্যাটাগরি</span>
                <span class="data-val" style="color:var(--primary)">${e.category}</span>
              </div>
              <div class="data-row">
                <span class="data-label">প্রদানকারী / গ্রহীতা</span>
                <span class="data-val">${e.payee || 'লিপিবদ্ধ নেই'}</span>
              </div>
              <div class="data-row">
                <span class="data-label">ভাউচার নম্বর</span>
                <span class="data-val">${e.voucherNo || '-'}</span>
              </div>
              <div class="data-row">
                <span class="data-label">মন্তব্য</span>
                <span class="data-val">${e.note || '-'}</span>
              </div>
            </div>

            <div class="card-actions">
              <button class="btn btn-secondary btn-sm" onclick="App.openExpenseModal('${e.id}')">
                <span>✏️</span> সম্পাদন
              </button>
              <button class="btn btn-danger btn-sm" onclick="App.deleteItem('expenses', '${e.id}', '${e.description}')">
                <span>🗑️</span> মুছুন
              </button>
            </div>
          </div>
        `).join('')}
      </div>
    `;
  },

  openExpenseModal(expenseId = null) {
    const ponds = db.getAll('ponds');
    const isEdit = !!expenseId;
    const item = isEdit ? db.getById('expenses', expenseId) : {};

    const categories = ['খাদ্য', 'মাছ/পোনা', 'ঔষধ', 'শ্রমিক', 'বিদ্যুৎ', 'পরিবহন', 'পুকুর সংস্কার', 'অন্যান্য'];

    const html = `
      <form id="expense-form">
        <input type="hidden" name="id" id="exp-id" value="${item.id || ''}">
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">তারিখ <span class="required">*</span></label>
            <input type="date" class="form-control" name="date" id="exp-date" value="${item.date || new Date().toISOString().split('T')[0]}" required>
          </div>
          <div class="form-group">
            <label class="form-label">পুকুর <span class="required">*</span></label>
            <select class="form-control" name="pondId" id="exp-pond">
              <option value="all" ${item.pondId === 'all' ? 'selected' : ''}>সকল পুকুর (সাধারণ খরচ)</option>
              ${ponds.map(p => `<option value="${p.id}" ${item.pondId === p.id ? 'selected' : ''}>${p.name}</option>`).join('')}
            </select>
          </div>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label class="form-label">খরচের ধরন (ক্যাটাগরি) <span class="required">*</span></label>
            <select class="form-control" name="category" id="exp-category" required>
              ${categories.map(c => `<option value="${c}" ${item.category === c ? 'selected' : ''}>${c}</option>`).join('')}
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">মোট টাকা (৳) <span class="required">*</span></label>
            <input type="number" class="form-control" name="totalMoney" id="exp-money" value="${item.totalMoney || ''}" placeholder="যেমন: ৩০০০" required>
          </div>
        </div>

        <div class="form-group">
          <label class="form-label">বিবরণ <span class="required">*</span></label>
          <input type="text" class="form-control" name="description" id="exp-desc" value="${item.description || ''}" placeholder="যেমন: পুকুর পাড় মেরামত শ্রমিক মজুরি" required>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label class="form-label">প্রদানকারী / গ্রহীতা</label>
            <input type="text" class="form-control" name="payee" id="exp-payee" value="${item.payee || ''}" placeholder="কাকে দেওয়া হলো">
          </div>
          <div class="form-group">
            <label class="form-label">ভাউচার নম্বর</label>
            <input type="text" class="form-control" name="voucherNo" id="exp-voucher" value="${item.voucherNo || ''}" placeholder="ভাউচার বা রসিদ নং">
          </div>
        </div>

        <div class="form-group">
          <label class="form-label">নোট</label>
          <textarea class="form-control" name="note" id="exp-note" placeholder="খরচ সংক্রান্ত অতিরিক্ত মন্তব্য">${item.note || ''}</textarea>
        </div>
      </form>
    `;

    UI.openFormModal(
      isEdit ? '✏️ খরচ তথ্য সম্পাদন' : '💰 নতুন খরচ যোগ করুন',
      html,
      'সংরক্ষণ করুন',
      () => App.saveExpense(null, expenseId)
    );
  },

  // =========================================================================
  // 10. ACCOUNTS & PROFIT-LOSS (আয়-ব্যয় ও হিসাব)
  // =========================================================================
  renderAccounts() {
    const container = document.getElementById('accounts-container');
    if (!container) return;

    const stats = db.getDashboardStats();
    const isProfit = stats.netProfit >= 0;

    // Categorized expenses
    const expenses = db.getAll('expenses');
    const catTotals = {};
    expenses.forEach(e => {
      catTotals[e.category] = (catTotals[e.category] || 0) + (parseFloat(e.totalMoney) || 0);
    });

    container.innerHTML = `
      <div class="report-summary-bar" style="margin-top:0;">
        <div class="rep-box">
          <div class="rep-label">মোট আয়</div>
          <div class="rep-val green">৳ ${stats.totalIncome.toLocaleString('bn-BD')}</div>
        </div>
        <div class="rep-box">
          <div class="rep-label">মোট ব্যয়</div>
          <div class="rep-val red">৳ ${stats.totalExpenses.toLocaleString('bn-BD')}</div>
        </div>
        <div class="rep-box" style="border: 2px solid ${isProfit ? 'var(--success)' : 'var(--danger)'}">
          <div class="rep-label">নিট লাভ / ক্ষতি</div>
          <div class="rep-val ${isProfit ? 'green' : 'red'}">
            ${isProfit ? '+ ৳ ' : '- ৳ '}${Math.abs(stats.netProfit).toLocaleString('bn-BD')}
          </div>
        </div>
      </div>

      <div class="chart-card">
        <h3 class="section-subhead">ব্যয়ের খাতভিত্তিক বিবরণ</h3>
        <table class="styled-table" style="min-width:100%;">
          <thead>
            <tr>
              <th>খাতের নাম</th>
              <th style="text-align:right;">মোট টাকা</th>
              <th style="text-align:right;">শতাংশ</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>খাদ্য ক্রয় (স্টক)</td>
              <td style="text-align:right;">৳ ${stats.feedStockBuyTotal.toLocaleString('bn-BD')}</td>
              <td style="text-align:right;">${stats.totalExpenses ? ((stats.feedStockBuyTotal / stats.totalExpenses) * 100).toFixed(1) : 0}%</td>
            </tr>
            <tr>
              <td>মাছ / পোনা ক্রয়</td>
              <td style="text-align:right;">৳ ${stats.fishBuyTotal.toLocaleString('bn-BD')}</td>
              <td style="text-align:right;">${stats.totalExpenses ? ((stats.fishBuyTotal / stats.totalExpenses) * 100).toFixed(1) : 0}%</td>
            </tr>
            ${Object.keys(catTotals).map(cat => `
              <tr>
                <td>${cat}</td>
                <td style="text-align:right;">৳ ${catTotals[cat].toLocaleString('bn-BD')}</td>
                <td style="text-align:right;">${stats.totalExpenses ? ((catTotals[cat] / stats.totalExpenses) * 100).toFixed(1) : 0}%</td>
              </tr>
            `).join('')}
            <tr class="table-total-row">
              <td>সর্বমোট খরচ</td>
              <td style="text-align:right; color:var(--danger)">৳ ${stats.totalExpenses.toLocaleString('bn-BD')}</td>
              <td style="text-align:right;">100%</td>
            </tr>
          </tbody>
        </table>
      </div>

      <div class="chart-card">
        <h3 class="section-subhead">আয়ের বিবরণ (মাছ বিক্রয়)</h3>
        <table class="styled-table" style="min-width:100%;">
          <thead>
            <tr>
              <th>তারিখ</th>
              <th>পুকুর</th>
              <th>মাছ</th>
              <th>ওজন</th>
              <th style="text-align:right;">টাকা</th>
            </tr>
          </thead>
          <tbody>
            ${db.getAll('fishSell').map(s => `
              <tr>
                <td>${s.date}</td>
                <td>${s.pondName}</td>
                <td>${s.fishType}</td>
                <td>${s.totalWeight} কেজি</td>
                <td style="text-align:right; font-weight:700; color:var(--success)">৳ ${s.totalPrice.toLocaleString('bn-BD')}</td>
              </tr>
            `).join('')}
            <tr class="table-total-row">
              <td colspan="4">সর্বমোট বিক্রয় আয়</td>
              <td style="text-align:right; color:var(--success)">৳ ${stats.totalIncome.toLocaleString('bn-BD')}</td>
            </tr>
          </tbody>
        </table>
      </div>
    `;
  },

  // =========================================================================
  // 11. POND-WISE BREAKDOWN (পুকুরভিত্তিক হিসাব)
  // =========================================================================
  renderPondCalc() {
    const container = document.getElementById('pond-calc-container');
    if (!container) return;

    const ponds = db.getAll('ponds');
    if (ponds.length === 0) {
      container.innerHTML = `
        <div class="empty-state">
          <div class="empty-icon">🌊</div>
          <div class="empty-title">কোনো পুকুর নিবন্ধিত নেই</div>
        </div>
      `;
      return;
    }

    container.innerHTML = ponds.map(p => {
      const rep = db.getPondReport(p.id);
      const isProfit = rep.pondNetProfit >= 0;

      return `
        <div class="chart-card" style="margin-bottom:16px;">
          <div style="display:flex; justify-content:space-between; align-items:center; border-bottom:2px solid var(--border-color); padding-bottom:10px; margin-bottom:12px;">
            <div>
              <h3 style="font-size:17px; font-weight:700; color:var(--primary-dark);">${p.name}</h3>
              <div style="font-size:12px; color:var(--text-muted);">আয়তন: ${p.area} ${p.unit} | পোনা: ${p.fishCount} টি (${p.fishType})</div>
            </div>
            <span class="badge ${isProfit ? 'badge-success' : 'badge-danger'}" style="font-size:13px;">
              ${isProfit ? 'লাভ: ৳ ' : 'ক্ষতি: ৳ '}${Math.abs(rep.pondNetProfit).toLocaleString('bn-BD')}
            </span>
          </div>

          <div style="display:grid; grid-template-columns: repeat(2, 1fr); gap:8px 12px; font-size:13px;">
            <div>
              <span style="color:var(--text-muted);">খাদ্য প্রদান:</span>
              <strong>${rep.feedKg} কেজি (৳ ${rep.feedCost.toLocaleString('bn-BD')})</strong>
            </div>
            <div>
              <span style="color:var(--text-muted);">পোনা খরচ:</span>
              <strong>৳ ${rep.fishBuyCost.toLocaleString('bn-BD')}</strong>
            </div>
            <div>
              <span style="color:var(--text-muted);">অন্যান্য খরচ:</span>
              <strong>৳ ${rep.otherExpenseTotal.toLocaleString('bn-BD')}</strong>
            </div>
            <div>
              <span style="color:var(--text-muted);">মোট ব্যয়:</span>
              <strong style="color:var(--danger)">৳ ${rep.totalPondExpense.toLocaleString('bn-BD')}</strong>
            </div>
            <div>
              <span style="color:var(--text-muted);">মাছ বিক্রয় আয়:</span>
              <strong style="color:var(--success)">৳ ${rep.fishSaleIncome.toLocaleString('bn-BD')} (${rep.fishSaleWeight} কেজি)</strong>
            </div>
            <div>
              <span style="color:var(--text-muted);">মৃত মাছ:</span>
              <strong style="color:var(--warning)">${rep.deadCount} টি</strong>
            </div>
          </div>
        </div>
      `;
    }).join('');
  },

  // =========================================================================
  // 12. MEMBER ACCOUNTS (সদস্যের হিসাব ও শেয়ার বণ্টন)
  // =========================================================================
  renderMemberCalc() {
    const container = document.getElementById('member-calc-container');
    if (!container) return;

    const members = db.getAll('members');
    const stats = db.getDashboardStats();
    const totalShares = stats.totalShares || 1;

    container.innerHTML = `
      <div class="report-summary-bar" style="margin-top:0;">
        <div class="rep-box">
          <div class="rep-label">মোট সদস্য</div>
          <div class="rep-val">${stats.totalMembers} জন</div>
        </div>
        <div class="rep-box">
          <div class="rep-label">মোট শেয়ার</div>
          <div class="rep-val">${totalShares} টি</div>
        </div>
        <div class="rep-box">
          <div class="rep-label">মোট মূলধন জমা</div>
          <div class="rep-val green">৳ ${stats.totalMemberDeposits.toLocaleString('bn-BD')}</div>
        </div>
      </div>

      <div class="table-container">
        <table class="styled-table" style="min-width:650px;">
          <thead>
            <tr>
              <th>আইডি</th>
              <th>সদস্যের নাম</th>
              <th>মোবাইল</th>
              <th>শেয়ার</th>
              <th>অনুপাত (%)</th>
              <th>জমা টাকা</th>
              <th>সম্ভাব্য লাভ অংশ</th>
            </tr>
          </thead>
          <tbody>
            ${members.map(m => {
              const pct = ((m.shareCount / totalShares) * 100).toFixed(1);
              const profitShare = Math.round((stats.netProfit * m.shareCount) / totalShares);
              return `
                <tr>
                  <td>${m.memberId}</td>
                  <td><strong>${m.name}</strong></td>
                  <td>${m.mobile || '-'}</td>
                  <td>${m.shareCount}</td>
                  <td>${pct}%</td>
                  <td>৳ ${(m.depositAmount || 0).toLocaleString('bn-BD')}</td>
                  <td style="font-weight:700; color:${profitShare >= 0 ? 'var(--success)' : 'var(--danger)'}">
                    ${profitShare >= 0 ? '+ ৳ ' : '- ৳ '}${Math.abs(profitShare).toLocaleString('bn-BD')}
                  </td>
                </tr>
              `;
            }).join('')}
            <tr class="table-total-row">
              <td colspan="3">সর্বমোট</td>
              <td>${totalShares} টি</td>
              <td>100%</td>
              <td>৳ ${stats.totalMemberDeposits.toLocaleString('bn-BD')}</td>
              <td style="color:${stats.netProfit >= 0 ? 'var(--success)' : 'var(--danger)'}">
                ${stats.netProfit >= 0 ? '+ ৳ ' : '- ৳ '}${Math.abs(stats.netProfit).toLocaleString('bn-BD')}
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    `;
  },

  // =========================================================================
  // 13. MONTHLY & YEARLY REPORTS (রিপোর্টসমূহ)
  // =========================================================================
  renderMonthlyReport() {
    this.renderReportsUnified('monthly');
  },

  renderYearlyReport() {
    this.renderReportsUnified('yearly');
  },

  renderReportsUnified(defaultMode = 'daily') {
    const container = document.getElementById(defaultMode === 'yearly' ? 'yearly-report-container' : 'monthly-report-container');
    if (!container) return;

    const farm = db.getSettings();
    const stats = db.getDashboardStats();

    container.innerHTML = `
      <div class="report-filter-card">
        <div class="print-header">
          <h2>${farm.farmName}</h2>
          <p>${farm.tagline}</p>
          <p style="font-size:12px;">${farm.address} | মোবাইল: ${farm.mobile}</p>
          <hr style="margin:8px 0;">
        </div>

        <div class="form-row" style="margin-bottom:12px;">
          <div class="form-group">
            <label class="form-label">রিপোর্টের ধরন</label>
            <select class="form-control" id="rep-type-select" onchange="App.changeReportView(this.value)">
              <option value="daily">১. দৈনিক রিপোর্ট</option>
              <option value="monthly" ${defaultMode === 'monthly' ? 'selected' : ''}>২. মাসিক রিপোর্ট</option>
              <option value="yearly" ${defaultMode === 'yearly' ? 'selected' : ''}>৩. বার্ষিক রিপোর্ট</option>
              <option value="pond">৪. পুকুরভিত্তিক রিপোর্ট</option>
              <option value="member">৫. সদস্যভিত্তিক রিপোর্ট</option>
              <option value="feed">৬. খাদ্য রিপোর্ট</option>
              <option value="expense">৭. খরচ রিপোর্ট</option>
              <option value="income">৮. আয় রিপোর্ট</option>
              <option value="fishSell">৯. মাছ বিক্রয় রিপোর্ট</option>
              <option value="profitLoss">১০. লাভ-ক্ষতি রিপোর্ট</option>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">পুকুর ফিল্টার</label>
            <select class="form-control" id="rep-pond-filter" onchange="App.refreshReportData()">
              <option value="all">সকল পুকুর</option>
              ${db.getAll('ponds').map(p => `<option value="${p.id}">${p.name}</option>`).join('')}
            </select>
          </div>
        </div>

        <div style="display:flex; justify-content:flex-end; gap:8px;">
          <button class="btn btn-secondary btn-sm" onclick="App.exportCurrentReportCsv()">
            <span>📥</span> CSV ডাউনলোড
          </button>
          <button class="btn btn-primary btn-sm" onclick="UI.printPage()">
            <span>🖨️</span> রিপোর্ট প্রিন্ট
          </button>
        </div>
      </div>

      <div id="report-output-content">
        <!-- Output injected dynamically -->
      </div>
    `;

    this.changeReportView(defaultMode);
  },

  changeReportView(type) {
    this.activeReportType = type;
    this.refreshReportData();
  },

  refreshReportData() {
    const out = document.getElementById('report-output-content');
    if (!out) return;

    const type = this.activeReportType;
    const pondFilter = document.getElementById('rep-pond-filter')?.value || 'all';

    if (type === 'daily' || type === 'monthly' || type === 'yearly' || type === 'profitLoss') {
      const stats = db.getDashboardStats();
      const isProfit = stats.netProfit >= 0;

      out.innerHTML = `
        <div class="report-summary-bar">
          <div class="rep-box"><div class="rep-label">মোট আয়</div><div class="rep-val green">৳ ${stats.totalIncome.toLocaleString('bn-BD')}</div></div>
          <div class="rep-box"><div class="rep-label">মোট খরচ</div><div class="rep-val red">৳ ${stats.totalExpenses.toLocaleString('bn-BD')}</div></div>
          <div class="rep-box"><div class="rep-label">নিট লাভ</div><div class="rep-val ${isProfit ? 'green' : 'red'}">${isProfit ? '+ ৳ ' : '- ৳ '}${Math.abs(stats.netProfit).toLocaleString('bn-BD')}</div></div>
        </div>

        <div class="table-container">
          <table class="styled-table" id="report-table">
            <thead>
              <tr><th>খাত</th><th>বিবরণ</th><th style="text-align:right;">টাকা (৳)</th></tr>
            </thead>
            <tbody>
              <tr><td>আয়</td><td>মাছ বিক্রয় বাবদ মোট প্রাপ্তি</td><td style="text-align:right; color:var(--success)">+ ৳ ${stats.totalIncome.toLocaleString('bn-BD')}</td></tr>
              <tr><td>ব্যয়</td><td>খাদ্য ক্রয় স্টক</td><td style="text-align:right; color:var(--danger)">- ৳ ${stats.feedStockBuyTotal.toLocaleString('bn-BD')}</td></tr>
              <tr><td>ব্যয়</td><td>মাছ/পোনা ক্রয়</td><td style="text-align:right; color:var(--danger)">- ৳ ${stats.fishBuyTotal.toLocaleString('bn-BD')}</td></tr>
              <tr><td>ব্যয়</td><td>সাধারণ দৈনিক খরচাবলী (শ্রমিক, বিদ্যুৎ, ঔষধ ইত্যাদি)</td><td style="text-align:right; color:var(--danger)">- ৳ ${stats.generalExpensesTotal.toLocaleString('bn-BD')}</td></tr>
              <tr class="table-total-row">
                <td colspan="2">চূড়ান্ত নিট ব্যালেন্স (${isProfit ? 'লাভ' : 'ক্ষতি'})</td>
                <td style="text-align:right; color:${isProfit ? 'var(--success)' : 'var(--danger)'}">
                  ${isProfit ? '+ ৳ ' : '- ৳ '}${Math.abs(stats.netProfit).toLocaleString('bn-BD')}
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      `;
    } else if (type === 'feed') {
      let feeds = db.getAll('dailyFeed');
      if (pondFilter !== 'all') feeds = feeds.filter(f => f.pondId === pondFilter);

      out.innerHTML = `
        <div class="table-container">
          <table class="styled-table" id="report-table">
            <thead>
              <tr><th>তারিখ</th><th>পুকুর</th><th>খাদ্যের ধরন</th><th>পরিমাণ</th><th>দর</th><th style="text-align:right;">মোট খরচ</th></tr>
            </thead>
            <tbody>
              ${feeds.map(f => `
                <tr>
                  <td>${f.date}</td>
                  <td>${f.pondName}</td>
                  <td>${f.feedName} (${f.feedType})</td>
                  <td>${f.amountKg} কেজি</td>
                  <td>৳ ${f.ratePerKg}</td>
                  <td style="text-align:right; font-weight:700;">৳ ${f.totalPrice.toLocaleString('bn-BD')}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      `;
    } else if (type === 'expense') {
      let expenses = db.getAll('expenses');
      if (pondFilter !== 'all') expenses = expenses.filter(e => e.pondId === pondFilter);

      out.innerHTML = `
        <div class="table-container">
          <table class="styled-table" id="report-table">
            <thead>
              <tr><th>তারিখ</th><th>পুকুর</th><th>ক্যাটাগরি</th><th>বিবরণ</th><th style="text-align:right;">টাকা</th></tr>
            </thead>
            <tbody>
              ${expenses.map(e => `
                <tr>
                  <td>${e.date}</td>
                  <td>${e.pondName}</td>
                  <td>${e.category}</td>
                  <td>${e.description}</td>
                  <td style="text-align:right; font-weight:700; color:var(--danger)">৳ ${e.totalMoney.toLocaleString('bn-BD')}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      `;
    } else if (type === 'fishSell') {
      let sales = db.getAll('fishSell');
      if (pondFilter !== 'all') sales = sales.filter(s => s.pondId === pondFilter);

      out.innerHTML = `
        <div class="table-container">
          <table class="styled-table" id="report-table">
            <thead>
              <tr><th>তারিখ</th><th>পুকুর</th><th>মাছ</th><th>ওজন</th><th>দর</th><th>ক্রেতা</th><th style="text-align:right;">মোট বিক্রয়</th></tr>
            </thead>
            <tbody>
              ${sales.map(s => `
                <tr>
                  <td>${s.date}</td>
                  <td>${s.pondName}</td>
                  <td>${s.fishType}</td>
                  <td>${s.totalWeight} কেজি</td>
                  <td>৳ ${s.ratePerKg}</td>
                  <td>${s.buyerName || '-'}</td>
                  <td style="text-align:right; font-weight:700; color:var(--success)">৳ ${s.totalPrice.toLocaleString('bn-BD')}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      `;
    } else if (type === 'pond') {
      const ponds = db.getAll('ponds');
      out.innerHTML = `
        <div class="table-container">
          <table class="styled-table" id="report-table">
            <thead>
              <tr><th>পুকুর</th><th>আয়তন</th><th>পোনা সংখ্যা</th><th>খাদ্য খরচ</th><th>মাছ বিক্রয়</th><th style="text-align:right;">নিট লাভ/ক্ষতি</th></tr>
            </thead>
            <tbody>
              ${ponds.map(p => {
                const rep = db.getPondReport(p.id);
                return `
                  <tr>
                    <td><strong>${p.name}</strong></td>
                    <td>${p.area} ${p.unit}</td>
                    <td>${p.fishCount} টি</td>
                    <td>৳ ${rep.feedCost.toLocaleString('bn-BD')}</td>
                    <td>৳ ${rep.fishSaleIncome.toLocaleString('bn-BD')}</td>
                    <td style="text-align:right; font-weight:700; color:${rep.pondNetProfit >= 0 ? 'var(--success)' : 'var(--danger)'}">
                      ${rep.pondNetProfit >= 0 ? '+ ৳ ' : '- ৳ '}${Math.abs(rep.pondNetProfit).toLocaleString('bn-BD')}
                    </td>
                  </tr>
                `;
              }).join('')}
            </tbody>
          </table>
        </div>
      `;
    } else if (type === 'member') {
      const members = db.getAll('members');
      out.innerHTML = `
        <div class="table-container">
          <table class="styled-table" id="report-table">
            <thead>
              <tr><th>আইডি</th><th>নাম</th><th>মোবাইল</th><th>শেয়ার</th><th style="text-align:right;">জমা টাকা</th></tr>
            </thead>
            <tbody>
              ${members.map(m => `
                <tr>
                  <td>${m.memberId}</td>
                  <td>${m.name}</td>
                  <td>${m.mobile}</td>
                  <td>${m.shareCount}</td>
                  <td style="text-align:right;">৳ ${(m.depositAmount || 0).toLocaleString('bn-BD')}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      `;
    }
  },

  exportCurrentReportCsv() {
    const table = document.getElementById('report-table');
    if (!table) {
      UI.showToast('এক্সপোর্ট করার মতো কোনো ডেটা নেই।', 'warning');
      return;
    }

    const headers = [];
    table.querySelectorAll('thead th').forEach(th => headers.push(th.innerText.trim()));

    const rows = [];
    table.querySelectorAll('tbody tr').forEach(tr => {
      const row = [];
      tr.querySelectorAll('td').forEach(td => row.push(td.innerText.trim()));
      if (row.length > 0) rows.push(row);
    });

    UI.exportToCsv(`AlKarim_Report_${this.activeReportType}_${Date.now()}.csv`, headers, rows);
  },

  // =========================================================================
  // 14. RECYCLE BIN (রিসাইকেল বিন)
  // =========================================================================
  renderRecycleBin() {
    const listEl = document.getElementById('recycle-bin-list');
    if (!listEl) return;

    const items = db.getAll('recycleBin');

    if (items.length === 0) {
      listEl.innerHTML = `
        <div class="empty-state">
          <div class="empty-icon">🗑️</div>
          <div class="empty-title">রিসাইকেল বিন সম্পূর্ণ খালি</div>
          <div class="empty-desc">কোনো মুছে ফেলা আইটেম জমা নেই।</div>
        </div>
      `;
      return;
    }

    listEl.innerHTML = `
      <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:14px;">
        <span style="font-size:13px; font-weight:600; color:var(--text-muted);">${items.length} টি আইটেম বিনে আছে</span>
        <button class="btn btn-danger btn-sm" onclick="App.clearRecycleBinAll()">
          <span>⚠️</span> বিন সম্পূর্ণ খালি করুন
        </button>
      </div>

      <div class="card-list">
        ${items.map(item => `
          <div class="item-card">
            <div class="item-card-header">
              <div class="card-title-group">
                <h4>${item.title}</h4>
                <div class="card-tag">বিভাগ: ${this._getTableDisplayName(item.originalTable)} | মুছে ফেলার সময়: ${new Date(item.deletedAt).toLocaleString('bn-BD')}</div>
              </div>
            </div>
            <p style="font-size:13px; color:var(--text-muted); margin: 6px 0;">${item.summary || ''}</p>
            <div class="card-actions">
              <button class="btn btn-primary btn-sm" onclick="App.restoreFromRecycleBin('${item.id}')">
                <span>🔄</span> রিস্টোর করুন
              </button>
              <button class="btn btn-danger btn-sm" onclick="App.deleteFromBinPermanently('${item.id}')">
                <span>❌</span> স্থায়ীভাবে মুছুন
              </button>
            </div>
          </div>
        `).join('')}
      </div>
    `;
  },

  _getTableDisplayName(table) {
    switch (table) {
      case 'ponds': return 'পুকুর';
      case 'members': return 'সদস্য';
      case 'feedStock': return 'খাদ্য স্টক';
      case 'dailyFeed': return 'দৈনিক খাদ্য';
      case 'expenses': return 'খরচ';
      case 'fishBuy': return 'মাছ ক্রয়';
      case 'fishSell': return 'মাছ বিক্রয়';
      case 'deadFish': return 'মৃত মাছ';
      default: return 'অন্যান্য';
    }
  },

  deleteItem(table, id, name) {
    UI.showConfirm(
      'আইটেম মুছে ফেলুন',
      `"${name}" আইটেমটি কি রিসাইকেল বিনে পাঠাতে চান? পরবর্তীতে এটি রিস্টোর করতে পারবেন।`,
      () => {
        const ok = db.softDelete(table, id);
        if (ok) {
          UI.showToast('সফলভাবে রিসাইকেল বিনে পাঠানো হয়েছে।', 'success');
          App.renderCurrentView();
        }
      }
    );
  },

  restoreFromRecycleBin(binId) {
    const ok = db.restoreFromBin(binId);
    if (ok) {
      UI.showToast('আইটেমটি সফলভাবে রিস্টোর করা হয়েছে।', 'success');
      this.renderRecycleBin();
    }
  },

  deleteFromBinPermanently(binId) {
    UI.showConfirm(
      'স্থায়ীভাবে মুছে ফেলা',
      'এই আইটেমটি স্থায়ীভাবে মুছে ফেলা হবে এবং আর ফিরে পাওয়া যাবে না!',
      () => {
        db.permanentDeleteFromBin(binId);
        UI.showToast('স্থায়ীভাবে মুছে ফেলা হয়েছে।', 'success');
        App.renderRecycleBin();
      }
    );
  },

  clearRecycleBinAll() {
    UI.showConfirm(
      'রিসাইকেল বিন খালি করুন',
      'আপনি কি রিসাইকেল বিনের সকল আইটেম স্থায়ীভাবে মুছে ফেলতে চান?',
      () => {
        db.clearRecycleBin();
        UI.showToast('রিসাইকেল বিন খালি করা হয়েছে।', 'success');
        App.renderRecycleBin();
      }
    );
  },

  // =========================================================================
  // 15. SETTINGS & BACKUP / RESTORE
  // =========================================================================
  renderSettings() {
    const container = document.getElementById('settings-container');
    if (!container) return;

    const farm = db.getSettings();

    container.innerHTML = `
      <div class="chart-card">
        <h3 class="section-subhead">🏛️ খামার ও প্রতিষ্ঠানের তথ্য</h3>
        <form id="farm-settings-form" onsubmit="return false;">
          <div class="form-group">
            <label class="form-label">খামার / প্রজেক্টের নাম</label>
            <input type="text" class="form-control" name="farmName" value="${farm.farmName || ''}" required>
          </div>
          <div class="form-group">
            <label class="form-label">স্লোগান / ট্যাগলাইন</label>
            <input type="text" class="form-control" name="tagline" value="${farm.tagline || ''}">
          </div>
          <div class="form-row">
            <div class="form-group">
              <label class="form-label">মালিক / পরিচালকের নাম</label>
              <input type="text" class="form-control" name="ownerName" value="${farm.ownerName || ''}">
            </div>
            <div class="form-group">
              <label class="form-label">যোগাযোগের মোবাইল</label>
              <input type="tel" class="form-control" name="mobile" value="${farm.mobile || ''}">
            </div>
          </div>
          <div class="form-group">
            <label class="form-label">খামারের ঠিকানা</label>
            <input type="text" class="form-control" name="address" value="${farm.address || ''}">
          </div>
          <button class="btn btn-primary" onclick="App.saveFarmSettings()">
            <span>💾</span> খামারের তথ্য আপডেট করুন
          </button>
        </form>
      </div>

      <div class="chart-card">
        <h3 class="section-subhead">💾 ব্যাকআপ ও ডেটা রিস্টোর</h3>
        <p style="font-size:13px; color:var(--text-muted); margin-bottom:14px;">
          আপনার সমস্ত পুকুর, সদস্য, খাদ্য, হিসাব ও বিক্রয়ের তথ্য সুরক্ষিত রাখতে ব্যাকআপ ফাইল ডাউনলোড করে রাখুন।
        </p>
        
        <div style="display:flex; flex-direction:column; gap:10px;">
          <button class="btn btn-primary" onclick="App.downloadBackupFile()">
            <span>📥</span> এক্সপোর্ট ব্যাকআপ (JSON ডাউনলোড)
          </button>
          
          <label class="btn btn-secondary" style="cursor:pointer; text-align:center;">
            <span>📤</span> ইমপোর্ট ব্যাকআপ (ফাইল সিলেক্ট করুন)
            <input type="file" id="backup-file-input" accept=".json" style="display:none;" onchange="App.handleImportBackup(this)">
          </label>
        </div>
      </div>

      <div class="chart-card" style="border-color:#f5c6cb;">
        <h3 class="section-subhead" style="color:var(--danger)">⚠️ রিসেট ও ডেমো ডাটা</h3>
        <p style="font-size:13px; color:var(--text-muted); margin-bottom:14px;">
          ডেমো ডাটা লোড করে অ্যাপ্লিকেশনটি পরীক্ষা করতে পারেন অথবা সকল হিসাব রিসেট করতে পারেন।
        </p>
        <div style="display:flex; gap:10px;">
          <button class="btn btn-outline" onclick="App.reloadDemoDataPrompt()">
            <span>🔄</span> ডেমো ডাটা লোড
          </button>
          <button class="btn btn-danger" onclick="App.resetAllDataPrompt()">
            <span>🗑️</span> সকল ডাটা রিসেট
          </button>
        </div>
      </div>
    `;
  },

  saveFarmSettings() {
    const form = document.getElementById('farm-settings-form');
    if (!form || !UI.validateForm(form)) return;

    const farmName = this.getFieldValue(form, 'farmName');
    if (!farmName) {
      UI.showToast('খামার বা প্রজেক্টের নাম আবশ্যক।', 'error');
      return;
    }

    const newSettings = {
      farmName: farmName,
      tagline: this.getFieldValue(form, 'tagline'),
      ownerName: this.getFieldValue(form, 'ownerName'),
      mobile: this.getFieldValue(form, 'mobile'),
      address: this.getFieldValue(form, 'address'),
      currencySymbol: '৳'
    };

    db.updateSettings(newSettings);
    UI.showToast('খামারের তথ্য সফলভাবে সংরক্ষিত হয়েছে।', 'success');
  },

  downloadBackupFile() {
    const jsonStr = db.exportData();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `AlKarim_Pond_Backup_${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    UI.showToast('ব্যাকআপ ফাইল সফলভাবে ডাউনলোড হয়েছে।', 'success');
  },

  handleImportBackup(input) {
    if (!input.files || input.files.length === 0) return;
    const file = input.files[0];
    const reader = new FileReader();

    reader.onload = (e) => {
      const content = e.target.result;
      UI.showConfirm(
        'ব্যাকআপ রিস্টোর',
        'আপনি কি এই ব্যাকআপ ফাইলটি থেকে সকল ডাটা ফিরিয়ে আনতে চান? বর্তমান ডাটা প্রতিস্থাপিত হবে।',
        () => {
          const success = db.importData(content);
          if (success) {
            UI.showToast('ব্যাকআপ সফলভাবে রিস্টোর করা হয়েছে!', 'success');
            App.renderCurrentView();
          } else {
            UI.showToast('অবৈধ ফাইল! ব্যাকআপ রিস্টোর ব্যর্থ হয়েছে।', 'error');
          }
        }
      );
    };

    reader.readAsText(file);
    input.value = '';
  },

  reloadDemoDataPrompt() {
    UI.showConfirm(
      'ডেমো ডাটা লোড',
      'ডেমো পুকুর, সদস্য ও খাদ্য হিসাবের নমুনা তথ্য লোড করতে চান?',
      () => {
        db.loadDemoData();
        UI.showToast('ডেমো ডাটা সফলভাবে লোড হয়েছে।', 'success');
        App.renderCurrentView();
      }
    );
  },

  resetAllDataPrompt() {
    UI.showConfirm(
      'সকল ডাটা রিসেট',
      'সতর্কবার্তা: আপনার সমস্ত পুকুর, খাদ্য ও খরচের রেকর্ড সম্পূর্ণরূপে মুছে যাবে!',
      () => {
        db.resetData();
        UI.showToast('সকল ডাটা সফলভাবে রিসেট করা হয়েছে।', 'success');
        App.renderCurrentView();
      }
    );
  },

  // Direct alias for "খাদ্য যোগ"
  openFeedModal(id = null) {
    this.openDailyFeedModal(id);
  }
};

// Global aliases for rapid and fail-safe calling
window.App = App;
window.openDailyFeedModal = (id) => App.openDailyFeedModal(id);
window.openFeedStockModal = (id) => App.openFeedStockModal(id);
window.openFeedModal = (id) => App.openDailyFeedModal(id);

// Bootstrap application on DOM ready
document.addEventListener('DOMContentLoaded', () => {
  window.App.init();
});
