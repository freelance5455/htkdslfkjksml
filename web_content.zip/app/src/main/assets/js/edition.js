/* Edition settings, written by scripts/build-editions.mjs */
window.EA_EDITION = { id: "flutterwave", brand: "NOMIDMAN TRANS CO. LTD", shortBrand: "NOMIDMAN TRANS", paymentProvider: "flutterwave" };
