/* Latest wording (loaded last, so it overrides earlier text). */
(function () {
  const W = {
    en: {
      upgrade_title: "Upgrade to List",
      upgrade_desc: "Pay the registration fee first. Then verify your phone and email to start listing properties.",
      upgrade_btn: "Pay",
      upgrade_held: "Payment received. Now verify your phone and email to start listing.",
      reg_hold_btn: "Pay",
      reg_hold_note: "Your payment is refunded if your phone and email are not verified within 24 hours.",
      reg_refund_note: "Refunded if your phone and email are not verified within 24 hours.",
      reg_pay_held: "Payment received. Now verify your phone and email to complete registration.",
      reg_pay_first: "Pay the registration fee first. Verification codes are sent only after your payment.",
      gift_desc: "Entirely optional. Choose any amount between UGX {min} and UGX {max} (or its equivalent in another currency).",
      close_title: "Delete My Account !",
      close_btn: "Delete My Account !",
      close_confirm: "Yes, delete my account"
    },
    fr: {
      upgrade_title: "Passer à la publication",
      upgrade_desc: "Payez d'abord les frais d'inscription. Vérifiez ensuite votre téléphone et votre e-mail pour publier des biens.",
      upgrade_btn: "Payer",
      upgrade_held: "Paiement reçu. Vérifiez maintenant votre téléphone et votre e-mail pour publier.",
      reg_hold_btn: "Payer",
      reg_hold_note: "Votre paiement est remboursé si votre téléphone et votre e-mail ne sont pas vérifiés sous 24 heures.",
      reg_refund_note: "Remboursé si votre téléphone et votre e-mail ne sont pas vérifiés sous 24 heures.",
      reg_pay_held: "Paiement reçu. Vérifiez maintenant votre téléphone et votre e-mail pour finaliser l'inscription.",
      reg_pay_first: "Payez d'abord les frais d'inscription. Les codes de vérification sont envoyés seulement après votre paiement.",
      gift_desc: "Entièrement facultatif. Choisissez un montant entre {min} et {max} UGX (ou son équivalent dans une autre devise).",
      close_title: "Supprimer mon compte !",
      close_btn: "Supprimer mon compte !",
      close_confirm: "Oui, supprimer mon compte",
      verify_code: "Code de vérification"
    },
    ar: {
      upgrade_title: "الترقية للإدراج",
      upgrade_desc: "ادفع رسوم التسجيل أولاً، ثم تحقق من هاتفك وبريدك الإلكتروني لبدء نشر العقارات.",
      upgrade_btn: "ادفع",
      upgrade_held: "تم استلام الدفع. تحقق الآن من هاتفك وبريدك الإلكتروني لبدء النشر.",
      reg_hold_btn: "ادفع",
      reg_hold_note: "يُسترد دفعك إن لم يتم التحقق من هاتفك وبريدك الإلكتروني خلال 24 ساعة.",
      reg_refund_note: "يُسترد المبلغ إن لم يتم التحقق من هاتفك وبريدك الإلكتروني خلال 24 ساعة.",
      reg_pay_held: "تم استلام الدفع. تحقق الآن من هاتفك وبريدك الإلكتروني لإكمال التسجيل.",
      reg_pay_first: "ادفع رسوم التسجيل أولاً. لا تُرسل رموز التحقق إلا بعد الدفع.",
      gift_desc: "اختياري تماماً. اختر أي مبلغ بين {min} و {max} شلن أوغندي (أو ما يعادله بعملة أخرى).",
      close_title: "حذف حسابي !",
      close_btn: "حذف حسابي !",
      close_confirm: "نعم، احذف حسابي",
      verify_code: "رمز التحقق"
    }
  };
  W.en.listing_commodity = "Specify your list commodity";
  W.fr.listing_commodity = "Précisez l'objet de votre annonce";
  W.ar.listing_commodity = "حدد ما تعرضه في إعلانك";
  W.en.referral_title = "Referral Details"; W.fr.referral_title = "Détails du parrainage"; W.ar.referral_title = "تفاصيل الإحالة";
  W.en.completeness = "Listing completeness"; W.fr.completeness = "Complétude de l'annonce"; W.ar.completeness = "اكتمال الإعلان";
  W.en.tip_title = "Clear Listing Specifications (10+ characters)"; W.fr.tip_title = "Spécifications claires de l'annonce (10 caractères ou plus)"; W.ar.tip_title = "مواصفات واضحة للإعلان (10 أحرف فأكثر)";
  W.en.current_plan_title = "Your Current Subscription Plan"; W.fr.current_plan_title = "Votre formule d'abonnement actuelle"; W.ar.current_plan_title = "باقتك الحالية";
  W.en.tip_description = "Description of at least 80 characters"; W.fr.tip_description = "Description d'au moins 80 caractères"; W.ar.tip_description = "وصف من 80 حرفاً على الأقل";
  W.en.tip_price = "A price set"; W.fr.tip_price = "Un prix indiqué"; W.ar.tip_price = "تحديد السعر";
  W.en.tip_features = "At least two features selected"; W.fr.tip_features = "Au moins deux caractéristiques choisies"; W.ar.tip_features = "اختيار ميزتين على الأقل";
  W.en.tip_land = "Land type and dimensions entered"; W.fr.tip_land = "Type de terrain et dimensions saisis"; W.ar.tip_land = "إدخال نوع الأرض وأبعادها";
  W.en.tip_vehicle = "Engine, chassis and number plate entered"; W.fr.tip_vehicle = "Moteur, châssis et plaque saisis"; W.ar.tip_vehicle = "إدخال رقم المحرك والهيكل واللوحة";
  W.en.unit_acres = "acres"; W.fr.unit_acres = "acres"; W.ar.unit_acres = "فدان";
  W.en.unit_hectares = "hectares"; W.fr.unit_hectares = "hectares"; W.ar.unit_hectares = "هكتار";
  W.en.shop_view = "View this owner's other listings"; W.fr.shop_view = "Voir les autres annonces de ce propriétaire"; W.ar.shop_view = "عرض الإعلانات الأخرى لهذا المالك";
  W.en.shop_title = "Storefront"; W.fr.shop_title = "Vitrine"; W.ar.shop_title = "واجهة المتجر";
  W.en.shop_intro = "Live listings from this owner. Sign in to see contact details."; W.fr.shop_intro = "Annonces en ligne de ce propriétaire. Connectez-vous pour voir les coordonnées."; W.ar.shop_intro = "الإعلانات المنشورة لهذا المالك. سجّل الدخول لرؤية بيانات الاتصال.";
  W.en.shop_share_msg = "See this owner's listings on NOMIDMAN TRANS"; W.fr.shop_share_msg = "Voir les annonces de ce propriétaire sur NOMIDMAN TRANS"; W.ar.shop_share_msg = "شاهد إعلانات هذا المالك على NOMIDMAN TRANS";
  W.en.other_features_hint = "Describe the item in your own words (features, condition, extras)"; W.fr.other_features_hint = "Décrivez le bien avec vos mots (caractéristiques, état, équipements)"; W.ar.other_features_hint = "صف المنتج بكلماتك (المواصفات، الحالة، الإضافات)";
  W.en.tip_other_text = "Describe the item in at least 20 characters"; W.fr.tip_other_text = "Décrivez le bien en au moins 20 caractères"; W.ar.tip_other_text = "صف المنتج بـ 20 حرفاً على الأقل";
  W.en.more_info = "More information"; W.fr.more_info = "Plus d'informations"; W.ar.more_info = "معلومات إضافية";
  W.en.info_resident_landlord = "The Landlord or Landlady resides within the rental Courtyard"; W.fr.info_resident_landlord = "Le propriétaire ou la propriétaire réside dans la cour locative"; W.ar.info_resident_landlord = "يقيم المالك أو المالكة داخل فناء الإيجار";
  W.en.f_more_than_two_rooms = "More than 2 rooms"; W.fr.f_more_than_two_rooms = "Plus de 2 chambres"; W.ar.f_more_than_two_rooms = "أكثر من غرفتين";
  W.en.rooms_label = "Number of rooms"; W.fr.rooms_label = "Nombre de chambres"; W.ar.rooms_label = "عدد الغرف";
  W.en.rooms_count = "Rooms"; W.fr.rooms_count = "Chambres"; W.ar.rooms_count = "الغرف";
  W.en.rooms_invalid = "Enter the number of rooms: 3 or more."; W.fr.rooms_invalid = "Saisissez le nombre de chambres : 3 ou plus."; W.ar.rooms_invalid = "أدخل عدد الغرف: 3 أو أكثر.";
  W.en.link_copied = "Link copied"; W.fr.link_copied = "Lien copié"; W.ar.link_copied = "تم نسخ الرابط";
  Object.keys(W).forEach(l => Object.assign(window.EA_I18N[l], W[l]));
})();
