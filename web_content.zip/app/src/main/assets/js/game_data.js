// ============================================================================
// MASHA'S HAPPY HOME - DATA-DRIVEN CONTENT DEFINITIONS & AUDIO ENGINE
// ============================================================================

const GAME_VERSION = '2.4.0-AAA';

// 1. PLAYABLE CHARACTERS (Licensing-ready stylized 3D toy characters)
const CHARACTER_DEFS = {
  masha: {
    id: 'masha',
    name: 'Masha',
    title: 'Mischievous Explorer',
    emoji: '👧',
     unlockedByDefault: true,
    unlockCost: 0,
    currency: 'coins',
    primaryColor: '#d91b5c',
    secondaryColor: '#fce4ec',
    skinColor: '#ffdfc4',
    scale: 0.78,
    heightOffset: 0,
    favoriteFood: 'sweet_jam',
    favoriteActivity: 'hide_seek',
    personality: 'Energetic, curious, loves raspberry jam and games!',
    quotes: {
      idle: [
        "Bear! Let's play something fun!",
        "Ooh, what does this button do?",
        "La-la-la! Today is the best day ever!",
        "Who wants to make raspberry jam with me?"
      ],
      hungry: [
        "My tummy is rumbling louder than Bear!",
        "Is it jam time yet? Or porridge?",
        "Feed me yummy berries, please!"
      ],
      sleepy: [
        "*Yawn* Even super explorers need a nap...",
        "My eyelids feel like heavy pinecones...",
        "Where is my cozy pillow?"
      ],
      dirty: [
        "Oops! I jumped in a mud puddle again!",
        "Bubble bath time! Make lots of foam!",
        "Hehe, I'm covered in berry juice!"
      ],
      bored: [
        "I'm bored, bored, BORED! Let's play a mini-game!",
        "Can we go to the playground or paint a picture?",
        "Come on, let's do an obstacle course!"
      ],
      happy: [
        "Yay! Best friends forever!",
        "Hehehe! That tickles!",
        "You take the best care of our home!"
      ],
      social: [
        "Hey Bear, watch me do a cartwheel!",
        "Rosie, let's dress up in royal crowns!",
        "Panda, race you to the honey tree!"
      ]
    },
    defaultOutfit: {
      dress: 'dress_classic_magenta',
      hat: 'hat_kerchief_magenta',
      shoes: 'shoes_maryjanes',
      accessory: 'acc_none',
      colorVariant: '#d91b5c'
    }
  },
  bear: {
    id: 'bear',
    name: 'Bear',
    title: 'Gentle Chef & Beekeeper',
    emoji: '🐻',
    unlockedByDefault: true,
    unlockCost: 0,
    currency: 'coins',
    primaryColor: '#6d4c41',
    secondaryColor: '#d7ccc8',
    skinColor: '#8d6e63',
    scale: 1.25,
    heightOffset: 0,
    favoriteFood: 'golden_honey',
    favoriteActivity: 'fishing',
    personality: 'Warm-hearted, patient, loves gardening, tea, and quiet fishing.',
    quotes: {
      idle: [
        "*Happy bear hum* The garden looks lovely today.",
        "Time to check on the beehives and brew herbal tea.",
        "Nothing beats a peaceful afternoon in the cottage.",
        "I wonder what recipe I should cook next!"
      ],
      hungry: [
        "*Grrr-rumble* A jar of golden honey would hit the spot!",
        "Let's head to the kitchen for a warm pie.",
        "A bear needs a hearty meal!"
      ],
      sleepy: [
        "*Big bear yawn* Feels like winter hibernation already...",
        "A warm armchair or bed sounds wonderful right now.",
        "Time to rest these furry paws."
      ],
      dirty: [
        "Got sticky honey and garden soil all over my fur!",
        "A warm scrub in the tub will fix this right up.",
        "Better wash up before cooking!"
      ],
      bored: [
        "Let's go fishing by the sunny river or tend the berries!",
        "Maybe a game of woodland memory cards?",
        "I'd love to practice juggling or painting!"
      ],
      happy: [
        "*Warm bear hug!* Thank you, friend!",
        "Ho-ho! Everything is shipshape and cozy!",
        "That made my whole day brighter!"
      ],
      social: [
        "Careful with that vase, Masha! *chuckles*",
        "Panda, would you like some bamboo dumplings?",
        "Rosie, your garden flowers are blooming!"
      ]
    },
    defaultOutfit: {
      dress: 'outfit_bear_vest',
      hat: 'hat_none',
      shoes: 'shoes_none',
      accessory: 'acc_bowtie',
      colorVariant: '#6d4c41'
    }
  },
  rosie: {
    id: 'rosie',
    name: 'Rosie',
    title: 'Sunny Fashionista Friend',
    emoji: '🐷',
    unlockedByDefault: true,
    unlockCost: 0,
    currency: 'coins',
    primaryColor: '#f48fb1',
    secondaryColor: '#fce4ec',
    skinColor: '#f8bbd0',
    scale: 0.88,
    heightOffset: 0,
    favoriteFood: 'apple_pie',
    favoriteActivity: 'painting',
    personality: 'Creative, stylish, loves painting, dancing, and trying outfits!',
    quotes: {
      idle: [
        "Oink-la-la! How does my outfit look today?",
        "Let's paint a masterpiece in the art studio!",
        "Sunflowers and sparkles make every room prettier!",
        "Who wants to have a garden tea party?"
      ],
      hungry: [
        "Crispy apples or sweet berry tart, please!",
        "A fashionista needs snacks to stay fabulous!",
        "Let's visit the kitchen!"
      ],
      sleepy: [
        "Beauty sleep is calling my name...",
        "*Yawn* Let's put on cozy silk pajamas!",
        "I need a soft pink bed right away!"
      ],
      dirty: [
        "Eek! Mud on my hooves! Bathroom emergency!",
        "Quick, pass the lavender soap and bubbles!",
        "I need a spa wash to shine again!"
      ],
      bored: [
        "Let's paint, match cards, or try on new hats!",
        "Take me to the playground for some fun!",
        "Let's play together!"
      ],
      happy: [
        "Fabulous! Five stars! ✨",
        "You have the best sense of style!",
        "Yay! Dance party in the living room!"
      ],
      social: [
        "Masha, let's match our hats today!",
        "Bear, your honey cakes smell divine!",
        "Panda, teach me that cool flip!"
      ]
    },
    defaultOutfit: {
      dress: 'dress_sunny_frill',
      hat: 'hat_sunhat_flower',
      shoes: 'shoes_pink_boots',
      accessory: 'acc_sunglasses',
      colorVariant: '#f48fb1'
    }
  },
  panda: {
    id: 'panda',
    name: 'Panda',
    title: 'Playful Bamboo Acrobat',
    emoji: '🐼',
    unlockedByDefault: true,
    unlockCost: 0,
    currency: 'coins',
    primaryColor: '#37474f',
    secondaryColor: '#eceff1',
    skinColor: '#ffffff',
    scale: 0.92,
    heightOffset: 0,
    favoriteFood: 'bamboo_dumpling',
    favoriteActivity: 'obstacle_course',
    personality: 'Athletic, cheerful cousin who loves acrobatics, snacks, and friendly contests!',
    quotes: {
      idle: [
        "Hi-ya! Ready for an obstacle course run?",
        "Masha and I are practicing our synchronized jumps!",
        "Bear's house always has the tastiest snacks!",
        "Let's collect falling acorns in the forest!"
      ],
      hungry: [
        "Got any bamboo shoots, dumplings, or sweet buns?",
        "Acrobatics burn a lot of energy! Time to eat!",
        "My belly is ready for a feast!"
      ],
      sleepy: [
        "Pandas are world champions at napping... Zzz...",
        "Just five more hours of sleep, please!",
        "Let's curl up in the bedroom."
      ],
      dirty: [
        "Tumbled through the bushes! Need a scrub!",
        "My white fur is turning brown—bath time!",
        "Bring on the bubbly water!"
      ],
      bored: [
        "Let's jump logs in the obstacle course!",
        "Hide-and-seek in the forest! You're it!",
        "Let's play a mini-game!"
      ],
      happy: [
        "Awesome! Double backflip of joy!",
        "You're the coolest friend in the woods!",
        "High-five! 🐾"
      ],
      social: [
        "Masha, bet you can't catch me!",
        "Uncle Bear, can we have seconds?",
        "Rosie, paint a portrait of my ninja pose!"
      ]
    },
    defaultOutfit: {
      dress: 'outfit_sport_hoodie',
      hat: 'hat_baseball_cap',
      shoes: 'shoes_sneakers',
      accessory: 'acc_scarf_red',
      colorVariant: '#26a69a'
    }
  }
};

// 2. ROOMS & ENVIRONMENT DEFINITIONS
const ROOM_DEFS = {
  living: {
    id: 'living',
    name: 'Cozy Living Room',
    icon: '🛋️',
    primaryNeed: 'friendship',
    actionLabel: 'Chat & Hug Friends',
    actionIcon: '🤗',
    floorColor: '#c88a55',
    wallColor: '#f5deb3',
    ambientSky: '#87ceeb',
    cameraPos: { x: 0, y: 7.2, z: 11.2 },
    description: 'Warm fireplace, trophy shelves, and comfy sofa where friends hang out together.'
  },
  kitchen: {
    id: 'kitchen',
    name: 'Jam Kitchen',
    icon: '🍲',
    primaryNeed: 'hunger',
    actionLabel: 'Feed Tasty Meal',
    actionIcon: '🍓',
    floorColor: '#d7b377',
    wallColor: '#fff3e0',
    ambientSky: '#90caf9',
    cameraPos: { x: 0, y: 7.0, z: 11.0 },
    description: 'Stocked pantry, warm oven, and samovar tea table for delicious meals.'
  },
  bathroom: {
    id: 'bathroom',
    name: 'Bubble Spa Bath',
    icon: '🛁',
    primaryNeed: 'hygiene',
    actionLabel: 'Scrub & Bubble Bath',
    actionIcon: '🧼',
    floorColor: '#80deea',
    wallColor: '#e0f7fa',
    ambientSky: '#81d4fa',
    cameraPos: { x: 0, y: 7.0, z: 10.8 },
    description: 'Clawfoot tub with warm bubbles, rubber duckies, and wooden vanity.'
  },
  bedroom: {
    id: 'bedroom',
    name: 'Starlight Bedroom',
    icon: '🛏️',
    primaryNeed: 'energy',
    actionLabel: 'Tuck In for Nap',
    actionIcon: '💤',
    floorColor: '#a1887f',
    wallColor: '#ede7f6',
    ambientSky: '#7986cb',
    cameraPos: { x: 0, y: 7.2, z: 11.0 },
    description: 'Quilted beds, fairy lights, and plush pillows for restful dreams.'
  },
  garden: {
    id: 'garden',
    name: 'Sunflower Garden',
    icon: '🌻',
    primaryNeed: 'happiness',
    actionLabel: 'Smell Flowers & Beehives',
    actionIcon: '🐝',
    floorColor: '#66bb6a',
    wallColor: '#81c784',
    isOutdoor: true,
    cameraPos: { x: 0, y: 7.6, z: 12.0 },
    description: 'Bear’s prized beehives, berry patches, and tall golden sunflowers.'
  },
  playground: {
    id: 'playground',
    name: 'Forest Playground',
    icon: '🎠',
    primaryNeed: 'fun',
    actionLabel: 'Bounce & Play Together',
    actionIcon: '🎈',
    floorColor: '#4caf50',
    wallColor: '#66bb6a',
    isOutdoor: true,
    cameraPos: { x: 0, y: 7.8, z: 12.2 },
    description: 'Treehouse slide, fishing stream, easel, and obstacle logs!'
  }
};

// 3. FOOD & PANTRY ITEMS
const FOOD_ITEMS = [
  { id: 'sweet_jam', name: 'Raspberry Jam Jar', icon: '🍓', hunger: 32, happiness: 18, energy: 5, cost: 0, starter: true, desc: 'Masha’s signature homemade sweet raspberry jam!' },
  { id: 'golden_honey', name: 'Golden Beehive Honey', icon: '🍯', hunger: 35, happiness: 20, energy: 8, cost: 15, starter: true, desc: 'Pure organic woodland honey from Bear’s hives.' },
  { id: 'pink_porridge', name: 'Kasha Berry Porridge', icon: '🥣', hunger: 45, happiness: 14, energy: 12, cost: 20, starter: true, desc: 'Warm, filling pink porridge that fills every tummy!' },
  { id: 'apple_pie', name: 'Cinnamon Apple Pie', icon: '🥧', hunger: 42, happiness: 25, energy: 10, cost: 30, starter: false, desc: 'Freshly baked flaky crust stuffed with orchard apples.' },
  { id: 'bamboo_dumpling', name: 'Steamed Dumplings', icon: '🥟', hunger: 48, happiness: 22, energy: 15, cost: 35, starter: false, desc: 'Panda’s favorite savory steamed buns and bamboo shoots.' },
  { id: 'herbal_tea', name: 'Samovar Berry Tea', icon: '🍵', hunger: 18, happiness: 24, energy: 30, cost: 25, starter: true, desc: 'Restores energy and warms the soul.' },
  { id: 'forest_cake', name: 'Royal Forest Berry Cake', icon: '🎂', hunger: 60, happiness: 40, energy: 20, cost: 60, starter: false, desc: 'Three-tier celebration cake for all friends!' },
  { id: 'carrot_crunch', name: 'Crunchy Garden Carrots', icon: '🥕', hunger: 28, happiness: 12, energy: 10, cost: 10, starter: true, desc: 'Freshly pulled from the garden soil.' }
];

// 4. SCALABLE WARDROBE SYSTEM (5 Categories x Color Variants = 1,000+ Combinations)
const WARDROBE_ITEMS = {
  dress: [
    { id: 'dress_classic_magenta', name: 'Classic Folk Sarafan', icon: '👗', cost: 0, currency: 'coins', defaultUnlocked: true, style: 'sarafan', baseColor: '#d91b5c' },
    { id: 'outfit_bear_vest', name: 'Cozy Woodland Vest', icon: '🦺', cost: 0, currency: 'coins', defaultUnlocked: true, style: 'vest', baseColor: '#5d4037' },
    { id: 'dress_sunny_frill', name: 'Sunny Petal Dress', icon: '👚', cost: 0, currency: 'coins', defaultUnlocked: true, style: 'frill', baseColor: '#f48fb1' },
    { id: 'outfit_sport_hoodie', name: 'Acrobat Track Hoodie', icon: '🧥', cost: 0, currency: 'coins', defaultUnlocked: true, style: 'hoodie', baseColor: '#26a69a' },
    { id: 'dress_starlight_pajama', name: 'Starlight Cozy Pajamas', icon: '👚', cost: 80, currency: 'coins', defaultUnlocked: false, style: 'pajama', baseColor: '#7e57c2' },
    { id: 'dress_chef_apron', name: 'Master Jam Chef Tunic', icon: '🎽', cost: 110, currency: 'coins', defaultUnlocked: false, style: 'apron', baseColor: '#ef5350' },
    { id: 'dress_royal_gown', name: 'Woodland Fairy Gown', icon: '👑', cost: 180, currency: 'coins', defaultUnlocked: false, style: 'gown', baseColor: '#ab47bc' },
    { id: 'dress_superhero_cape', name: 'Super Explorer Suit', icon: '🦸', cost: 12, currency: 'gems', defaultUnlocked: false, style: 'hero', baseColor: '#1e88e5' },
    { id: 'dress_winter_coat', name: 'Snowflake Fur Coat', icon: '🧥', cost: 150, currency: 'coins', defaultUnlocked: false, style: 'coat', baseColor: '#29b6f6' },
    { id: 'dress_gardener_overalls', name: 'Sunflower Overalls', icon: '👖', cost: 95, currency: 'coins', defaultUnlocked: false, style: 'overalls', baseColor: '#66bb6a' }
  ],
  hat: [
    { id: 'hat_none', name: 'No Hat', icon: '✨', cost: 0, currency: 'coins', defaultUnlocked: true, shape: 'none', color: '#ffffff' },
    { id: 'hat_kerchief_magenta', name: 'Classic Headscarf', icon: '🧣', cost: 0, currency: 'coins', defaultUnlocked: true, shape: 'kerchief', color: '#d91b5c' },
    { id: 'hat_sunhat_flower', name: 'Daisy Sunhat', icon: '👒', cost: 0, currency: 'coins', defaultUnlocked: true, shape: 'sunhat', color: '#ffd54f' },
    { id: 'hat_baseball_cap', name: 'Sporty Visor Cap', icon: '🧢', cost: 0, currency: 'coins', defaultUnlocked: true, shape: 'cap', color: '#26a69a' },
    { id: 'hat_chef_toque', name: 'Tall Chef Toque', icon: '👩‍🍳', cost: 75, currency: 'coins', defaultUnlocked: false, shape: 'chef', color: '#ffffff' },
    { id: 'hat_royal_crown', name: 'Golden Berry Crown', icon: '👑', cost: 140, currency: 'coins', defaultUnlocked: false, shape: 'crown', color: '#ffca28' },
    { id: 'hat_nightcap', name: 'Dreamy Sleepy Cap', icon: '🌙', cost: 65, currency: 'coins', defaultUnlocked: false, shape: 'nightcap', color: '#5c6bc0' },
    { id: 'hat_wizard_cone', name: 'Starlight Wizard Hat', icon: '🧙', cost: 10, currency: 'gems', defaultUnlocked: false, shape: 'wizard', color: '#7b1fa2' },
    { id: 'hat_ushanka', name: 'Cozy Winter Ushanka', icon: '❄️', cost: 120, currency: 'coins', defaultUnlocked: false, shape: 'ushanka', color: '#8d6e63' }
  ],
  shoes: [
    { id: 'shoes_none', name: 'Bare Paws', icon: '🐾', cost: 0, currency: 'coins', defaultUnlocked: true, color: '#8d6e63' },
    { id: 'shoes_maryjanes', name: 'Classic Mary Janes', icon: '🥿', cost: 0, currency: 'coins', defaultUnlocked: true, color: '#ad1457' },
    { id: 'shoes_pink_boots', name: 'Sunny Rainboots', icon: '👢', cost: 0, currency: 'coins', defaultUnlocked: true, color: '#ec407a' },
    { id: 'shoes_sneakers', name: 'Turbo Jump Sneakers', icon: '👟', cost: 0, currency: 'coins', defaultUnlocked: true, color: '#00897b' },
    { id: 'shoes_slippers_bunny', name: 'Fluffy Bunny Slippers', icon: '🐰', cost: 60, currency: 'coins', defaultUnlocked: false, color: '#f8bbd0' },
    { id: 'shoes_gold_sandals', name: 'Royal Sparkle Shoes', icon: '✨', cost: 110, currency: 'coins', defaultUnlocked: false, color: '#ffd54f' },
    { id: 'shoes_snow_boots', name: 'Arctic Felt Valenki', icon: '🥾', cost: 90, currency: 'coins', defaultUnlocked: false, color: '#546e7a' }
  ],
  accessory: [
    { id: 'acc_none', name: 'None', icon: '➖', cost: 0, currency: 'coins', defaultUnlocked: true, type: 'none' },
    { id: 'acc_bowtie', name: 'Dapper Polka Bowtie', icon: '🎀', cost: 0, currency: 'coins', defaultUnlocked: true, type: 'bowtie', color: '#e53935' },
    { id: 'acc_sunglasses', name: 'Starry Shades', icon: '🕶️', cost: 0, currency: 'coins', defaultUnlocked: true, type: 'glasses', color: '#ec407a' },
    { id: 'acc_scarf_red', name: 'Cozy Knit Scarf', icon: '🧣', cost: 0, currency: 'coins', defaultUnlocked: true, type: 'scarf', color: '#d32f2f' },
    { id: 'acc_fairy_wings', name: 'Flutter Butterfly Wings', icon: '🦋', cost: 15, currency: 'gems', defaultUnlocked: false, type: 'wings', color: '#80deea' },
    { id: 'acc_magnifying', name: 'Detective Badge', icon: '🔍', cost: 85, currency: 'coins', defaultUnlocked: false, type: 'badge', color: '#ffb300' },
    { id: 'acc_flower_wreath', name: 'Chamomile Neck Garland', icon: '🌼', cost: 70, currency: 'coins', defaultUnlocked: false, type: 'garland', color: '#fff176' }
  ],
  colors: [
    { id: '#d91b5c', name: 'Raspberry Rose' },
    { id: '#e53935', name: 'Cranberry Red' },
    { id: '#fb8c00', name: 'Honey Amber' },
    { id: '#fdd835', name: 'Sunflower Gold' },
    { id: '#43a047', name: 'Pine Meadow' },
    { id: '#00acc1', name: 'River Aqua' },
    { id: '#1e88e5', name: 'Sky Cornflower' },
    { id: '#8e24aa', name: 'Plum Berry' },
    { id: '#f48fb1', name: 'Blossom Pink' },
    { id: '#5d4037', name: 'Chestnut Bark' }
  ]
};

// 5. FURNITURE, ROOM THEMES, & CUSTOMIZATION CATALOG
const FURNITURE_CATALOG = [
  // Living Room
  { id: 'furn_sofa_plush', room: 'living', name: 'Bear’s Plush Armchair', icon: '🛋️', cost: 0, currency: 'coins', defaultUnlocked: true, pos: { x: -2.2, z: -1.8, rot: 0.3 }, type: 'sofa', color: '#c62828' },
  { id: 'furn_fireplace', room: 'living', name: 'Warm Stone Fireplace', icon: '🔥', cost: 0, currency: 'coins', defaultUnlocked: true, pos: { x: 0, z: -3.4, rot: 0 }, type: 'fireplace', color: '#8d6e63' },
  { id: 'furn_tv_retro', room: 'living', name: 'Woodland Cartoon TV', icon: '📺', cost: 0, currency: 'coins', defaultUnlocked: true, pos: { x: 2.5, z: -2.0, rot: -0.4 }, type: 'tv', color: '#5d4037' },
  { id: 'furn_trophy_shelf', room: 'living', name: 'Circus Trophy Cabinet', icon: '🏆', cost: 120, currency: 'coins', defaultUnlocked: false, pos: { x: -3.4, z: 0.2, rot: 1.57 }, type: 'shelf', color: '#ffb300' },
  { id: 'furn_gramophone', room: 'living', name: 'Vintage Gramophone', icon: '📯', cost: 160, currency: 'coins', defaultUnlocked: false, pos: { x: 3.3, z: 0.6, rot: -1.2 }, type: 'gramophone', color: '#d4af37' },
  { id: 'furn_rug_sunflower', room: 'living', name: 'Woven Folk Rug', icon: '🧶', cost: 90, currency: 'coins', defaultUnlocked: false, pos: { x: 0, z: 0.5, rot: 0 }, type: 'rug', color: '#ef5350' },

  // Kitchen
  { id: 'furn_stove_hearth', room: 'kitchen', name: 'Country Bake Oven', icon: '🍳', cost: 0, currency: 'coins', defaultUnlocked: true, pos: { x: -2.4, z: -2.8, rot: 0 }, type: 'stove', color: '#d84315' },
  { id: 'furn_fridge_stocked', room: 'kitchen', name: 'Honey & Berry Fridge', icon: '🧊', cost: 0, currency: 'coins', defaultUnlocked: true, pos: { x: 2.6, z: -2.6, rot: -0.2 }, type: 'fridge', color: '#4dd0e1' },
  { id: 'furn_table_samovar', room: 'kitchen', name: 'Samovar Tea Table', icon: '🫖', cost: 0, currency: 'coins', defaultUnlocked: true, pos: { x: 0, z: -0.8, rot: 0 }, type: 'table', color: '#8d6e63' },
  { id: 'furn_jam_rack', room: 'kitchen', name: 'Jam Jar Pantry Rack', icon: '🍓', cost: 110, currency: 'coins', defaultUnlocked: false, pos: { x: -3.5, z: 0.2, rot: 1.57 }, type: 'shelf', color: '#ad1457' },
  { id: 'furn_cake_stand', room: 'kitchen', name: 'Royal Pastry Display', icon: '🎂', cost: 140, currency: 'coins', defaultUnlocked: false, pos: { x: 3.2, z: 0.5, rot: -1.57 }, type: 'stand', color: '#f48fb1' },

  // Bathroom
  { id: 'furn_tub_clawfoot', room: 'bathroom', name: 'Clawfoot Bubble Tub', icon: '🛁', cost: 0, currency: 'coins', defaultUnlocked: true, pos: { x: -1.8, z: -2.2, rot: 0.2 }, type: 'tub', color: '#ffffff' },
  { id: 'furn_sink_mirror', room: 'bathroom', name: 'Carved Oak Washbasin', icon: '🪞', cost: 0, currency: 'coins', defaultUnlocked: true, pos: { x: 2.2, z: -2.6, rot: -0.2 }, type: 'sink', color: '#26c6da' },
  { id: 'furn_ducky_tower', room: 'bathroom', name: 'Giant Rubber Ducky', icon: '🦆', cost: 85, currency: 'coins', defaultUnlocked: false, pos: { x: 0.4, z: -2.8, rot: 0 }, type: 'ducky', color: '#fdd835' },
  { id: 'furn_spa_plants', room: 'bathroom', name: 'Tropical Fern Corner', icon: '🌿', cost: 100, currency: 'coins', defaultUnlocked: false, pos: { x: -3.2, z: 0.8, rot: 0.8 }, type: 'plant', color: '#43a047' },

  // Bedroom
  { id: 'furn_bed_quilt', room: 'bedroom', name: 'Patchwork Cozy Bed', icon: '🛏️', cost: 0, currency: 'coins', defaultUnlocked: true, pos: { x: -2.0, z: -2.2, rot: 0 }, type: 'bed', color: '#ab47bc' },
  { id: 'furn_wardrobe_oak', room: 'bedroom', name: 'Carved Wardrobe Chest', icon: '🚪', cost: 0, currency: 'coins', defaultUnlocked: true, pos: { x: 2.5, z: -2.5, rot: -0.3 }, type: 'wardrobe', color: '#6d4c41' },
  { id: 'furn_night_lamp', room: 'bedroom', name: 'Starry Projector Lamp', icon: '🌟', cost: 95, currency: 'coins', defaultUnlocked: false, pos: { x: 0.3, z: -3.0, rot: 0 }, type: 'lamp', color: '#ffd54f' },
  { id: 'furn_rocking_horse', room: 'bedroom', name: 'Wooden Rocking Pony', icon: '🐴', cost: 130, currency: 'coins', defaultUnlocked: false, pos: { x: 2.8, z: 0.8, rot: -0.8 }, type: 'toy', color: '#e53935' },

  // Garden
  { id: 'furn_beehive_pair', room: 'garden', name: 'Golden Honey Beehives', icon: '🐝', cost: 0, currency: 'coins', defaultUnlocked: true, pos: { x: -2.6, z: -2.2, rot: 0.3 }, type: 'beehive', color: '#ffb300' },
  { id: 'furn_sunflower_bed', room: 'garden', name: 'Giant Sunflower Patch', icon: '🌻', cost: 0, currency: 'coins', defaultUnlocked: true, pos: { x: 2.5, z: -2.2, rot: -0.2 }, type: 'flowers', color: '#fdd835' },
  { id: 'furn_picnic_bench', room: 'garden', name: 'Checkered Picnic Table', icon: '🧺', cost: 115, currency: 'coins', defaultUnlocked: false, pos: { x: 0, z: -2.8, rot: 0 }, type: 'table', color: '#e53935' },
  { id: 'furn_fountain_frog', room: 'garden', name: 'Lilypad Frog Fountain', icon: '⛲', cost: 14, currency: 'gems', defaultUnlocked: false, pos: { x: 3.1, z: 0.7, rot: 0 }, type: 'fountain', color: '#26c6da' },

  // Playground
  { id: 'furn_slide_tree', room: 'playground', name: 'Acorn Treehouse Slide', icon: '🛝', cost: 0, currency: 'coins', defaultUnlocked: true, pos: { x: -2.4, z: -2.4, rot: 0.2 }, type: 'slide', color: '#fb8c00' },
  { id: 'furn_easel_art', room: 'playground', name: 'Woodland Paint Easel', icon: '🎨', cost: 0, currency: 'coins', defaultUnlocked: true, pos: { x: 2.4, z: -2.2, rot: -0.4 }, type: 'easel', color: '#8e24aa' },
  { id: 'furn_trampoline', room: 'playground', name: 'Bouncy Mushroom Pad', icon: '🍄', cost: 135, currency: 'coins', defaultUnlocked: false, pos: { x: 0.2, z: -2.8, rot: 0 }, type: 'trampoline', color: '#e53935' },
  { id: 'furn_merry_go', room: 'playground', name: 'Forest Carousel Spinner', icon: '🎠', cost: 16, currency: 'gems', defaultUnlocked: false, pos: { x: -3.0, z: 0.8, rot: 0 }, type: 'carousel', color: '#ec407a' }
];

const ROOM_THEMES = [
  { id: 'theme_classic', name: 'Classic Woodland Pine', wallColor: '#f5deb3', floorColor: '#c88a55', cost: 0, defaultUnlocked: true },
  { id: 'theme_berry_blossom', name: 'Raspberry Blossom', wallColor: '#fce4ec', floorColor: '#ad1457', cost: 70, defaultUnlocked: false },
  { id: 'theme_honey_meadow', name: 'Sunny Honey Meadow', wallColor: '#fff9c4', floorColor: '#8d6e63', cost: 70, defaultUnlocked: false },
  { id: 'theme_starlight_sky', name: 'Starlight Twilight', wallColor: '#d1c4e9', floorColor: '#4527a0', cost: 90, defaultUnlocked: false },
  { id: 'theme_emerald_moss', name: 'Emerald Forest Moss', wallColor: '#c8e6c9', floorColor: '#2e7d32', cost: 85, defaultUnlocked: false }
];

// 6. MINI-GAMES CATALOG (All 8 Required Playable Mini-Games)
const MINIGAME_DEFS = [
  {
    id: 'cooking',
    name: "Masha's Jam Kitchen",
    category: 'Cooking',
    icon: '🍓',
    bannerColor: 'from-pink-500 to-rose-600',
    description: 'Catch falling berries & honey into the boiling pot while dodging pinecones! Stir when the meter hits the golden zone!',
    controlsHint: 'Drag / Arrow Keys to move pot • Tap STIR when golden!'
  },
  {
    id: 'gardening',
    name: "Bear's Berry Garden",
    category: 'Gardening',
    icon: '🌻',
    bannerColor: 'from-emerald-500 to-green-700',
    description: 'Plant seeds in the 6 garden plots, water thirsty sprouts, pull sneaky weeds, and harvest golden berries!',
    controlsHint: 'Tap garden plots to Plant 🌱, Water 💧, Weed 🌿, or Harvest 🍓!'
  },
  {
    id: 'painting',
    name: 'Forest Art Studio',
    category: 'Painting',
    icon: '🎨',
    bannerColor: 'from-purple-500 to-indigo-600',
    description: 'Match the target woodland masterpiece on the pixel canvas or switch to Free Paint to create your own art!',
    controlsHint: 'Pick colors from the palette & drag/tap across the canvas!'
  },
  {
    id: 'memory',
    name: 'Woodland Memory Match',
    category: 'Memory Matching',
    icon: '🃏',
    bannerColor: 'from-amber-500 to-orange-600',
    description: 'Flip enchanted wooden cards to match Masha, Bear, honey pots, and friends across progressive difficulty levels!',
    controlsHint: 'Tap cards to flip pairs • Chain streaks for bonus coins!'
  },
  {
    id: 'obstacle',
    name: 'Log-Hop Obstacle Course',
    category: 'Obstacle Course',
    icon: '🏃',
    bannerColor: 'from-cyan-500 to-blue-600',
    description: 'Dash through the forest trail! Jump over rolling logs and puddles while collecting honey jars and gems!',
    controlsHint: 'Tap / Space / Up Arrow to Jump (Double-Jump supported!)'
  },
  {
    id: 'hideseek',
    name: 'Pinecone Hide & Seek',
    category: 'Hide-and-Seek',
    icon: '🙈',
    bannerColor: 'from-lime-500 to-teal-600',
    description: 'Watch where Masha and Panda hide before the bushes shuffle! Spot rustling leaves to find them all!',
    controlsHint: 'Watch the bushes shuffle closely, then tap where friends hid!'
  },
  {
    id: 'fishing',
    name: 'Sunny River Fishing',
    category: 'Fishing',
    icon: '🎣',
    bannerColor: 'from-sky-500 to-indigo-700',
    description: 'Aim and cast Bear’s hook into the sparkling river to reel in rainbow trout, golden fish, and sunken treasure chests!',
    controlsHint: 'Tap/Click to cast your hook along the river & avoid old boots!'
  },
  {
    id: 'collecting',
    name: 'Falling Acorn Collector',
    category: 'Collecting Objects',
    icon: '🧺',
    bannerColor: 'from-yellow-500 to-amber-700',
    description: 'Move Bear’s woven basket to catch falling golden acorns, stars, and berries while dodging prickly burrs!',
    controlsHint: 'Drag / Touch / Left-Right Arrows to catch falling treasures!'
  }
];

// 7. ACHIEVEMENTS & COLLECTION BOOK STICKERS
const ACHIEVEMENTS_LIST = [
  { id: 'ach_first_meal', name: 'Yummy in the Tummy', desc: 'Feed any character 3 times', icon: '🍓', target: 3, stat: 'mealsFed', rewardCoins: 50, rewardGems: 2 },
  { id: 'ach_squeaky_clean', name: 'Bubble Master', desc: 'Give 3 sparkling bubble baths', icon: '🛁', target: 3, stat: 'bathsGiven', rewardCoins: 50, rewardGems: 2 },
  { id: 'ach_sweet_dreams', name: 'Cozy Hibernation', desc: 'Tuck friends in for 3 naps', icon: '💤', target: 3, stat: 'napsTaken', rewardCoins: 50, rewardGems: 2 },
  { id: 'ach_fashion_star', name: 'Woodland Stylist', desc: 'Unlock 3 new wardrobe items', icon: '👗', target: 3, stat: 'outfitsUnlocked', rewardCoins: 80, rewardGems: 3 },
  { id: 'ach_interior_pro', name: 'Happy Home Decorator', desc: 'Unlock 3 furniture pieces or themes', icon: '🛋️', target: 3, stat: 'furnitureUnlocked', rewardCoins: 90, rewardGems: 4 },
  { id: 'ach_arcade_hero', name: 'Mini-Game Champion', desc: 'Play 5 mini-game sessions', icon: '🎮', target: 5, stat: 'minigamesPlayed', rewardCoins: 100, rewardGems: 5 },
  { id: 'ach_best_friends', name: 'Best Friends Forever', desc: 'Have 5 friendly social chats or hugs', icon: '🤗', target: 5, stat: 'socialInteractions', rewardCoins: 75, rewardGems: 3 },
  { id: 'ach_sticker_hunter', name: 'Sticker Collector', desc: 'Collect 8 stickers in your Collection Book', icon: '📖', target: 8, stat: 'stickersCollected', rewardCoins: 120, rewardGems: 6 }
];

const COLLECTION_STICKERS = [
  { id: 'stk_1', name: 'Masha’s Red Kerchief', icon: '🧣', rarity: 'Common' },
  { id: 'stk_2', name: 'Bear’s Golden Samovar', icon: '🫖', rarity: 'Common' },
  { id: 'stk_3', name: 'Jar of Raspberry Jam', icon: '🍓', rarity: 'Common' },
  { id: 'stk_4', name: 'Buzzing Beehive', icon: '🐝', rarity: 'Common' },
  { id: 'stk_5', name: 'Rosie’s Pink Sunglasses', icon: '🕶️', rarity: 'Rare' },
  { id: 'stk_6', name: 'Panda’s Bamboo Shoot', icon: '🎋', rarity: 'Rare' },
  { id: 'stk_7', name: 'Circus Unicycle', icon: '🎪', rarity: 'Rare' },
  { id: 'stk_8', name: 'Golden River Trout', icon: '🐟', rarity: 'Rare' },
  { id: 'stk_9', name: 'Forest Ambulance Wolves', icon: '🐺', rarity: 'Epic' },
  { id: 'stk_10', name: 'Squirrel Pinecones', icon: '🐿️', rarity: 'Common' },
  { id: 'stk_11', name: 'Hedgehog Berry Mushroom', icon: '🦔', rarity: 'Rare' },
  { id: 'stk_12', name: 'Royal Woodland Crown', icon: '👑', rarity: 'Legendary' }
];
