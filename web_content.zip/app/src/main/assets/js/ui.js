/**
 * আল-কারীম পুকুর ম্যানেজমেন্ট - UI Controller, Modals, Toasts & Chart Renderer
 */

window.UI = {
  currentView: 'dashboard',

  init() {
    this.setupNavigation();
    this.setupDrawer();
  },

  setupNavigation() {
    // Bottom nav links
    document.querySelectorAll('.bottom-nav-item').forEach(item => {
      item.addEventListener('click', (e) => {
        e.preventDefault();
        const view = item.getAttribute('data-view');
        if (view) {
          this.switchView(view);
        }
      });
    });

    // Drawer menu links
    document.querySelectorAll('.drawer-item').forEach(item => {
      item.addEventListener('click', (e) => {
        e.preventDefault();
        const view = item.getAttribute('data-view');
        if (view) {
          this.switchView(view);
          this.closeDrawer();
        }
      });
    });

    // Quick action clicks
    document.querySelectorAll('[data-quick-view]').forEach(item => {
      item.addEventListener('click', (e) => {
        e.preventDefault();
        const view = item.getAttribute('data-quick-view');
        if (view) this.switchView(view);
      });
    });
  },

  setupDrawer() {
    const hamburger = document.getElementById('btn-hamburger');
    const drawer = document.getElementById('drawer-menu');
    const backdrop = document.getElementById('drawer-backdrop');
    const closeBtn = document.getElementById('drawer-close-btn');

    if (hamburger && drawer && backdrop) {
      hamburger.addEventListener('click', () => this.openDrawer());
      backdrop.addEventListener('click', () => this.closeDrawer());
      if (closeBtn) closeBtn.addEventListener('click', () => this.closeDrawer());
    }
  },

  openDrawer() {
    const drawer = document.getElementById('drawer-menu');
    const backdrop = document.getElementById('drawer-backdrop');
    if (drawer && backdrop) {
      drawer.classList.add('active');
      backdrop.classList.add('active');
      this.updateRecycleBinBadge();
    }
  },

  closeDrawer() {
    const drawer = document.getElementById('drawer-menu');
    const backdrop = document.getElementById('drawer-backdrop');
    if (drawer && backdrop) {
      drawer.classList.remove('active');
      backdrop.classList.remove('active');
    }
  },

  updateRecycleBinBadge() {
    const count = window.db.getAll('recycleBin').length;
    const badge = document.getElementById('bin-badge-count');
    if (badge) {
      badge.textContent = count;
      badge.style.display = count > 0 ? 'inline-block' : 'none';
    }
  },

  switchView(viewName) {
    this.currentView = viewName;

    // Hide all view sections
    document.querySelectorAll('.view-section').forEach(sec => {
      sec.classList.remove('active');
    });

    // Show target view
    const targetSection = document.getElementById(`view-${viewName}`);
    if (targetSection) {
      targetSection.classList.add('active');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    // Sync Bottom nav active state
    document.querySelectorAll('.bottom-nav-item').forEach(btn => {
      if (btn.getAttribute('data-view') === viewName) {
        btn.classList.add('active');
      } else {
        btn.classList.remove('active');
      }
    });

    // Sync Drawer menu active state
    document.querySelectorAll('.drawer-item').forEach(item => {
      if (item.getAttribute('data-view') === viewName) {
        item.classList.add('active');
      } else {
        item.classList.remove('active');
      }
    });

    // Trigger view specific rendering
    if (window.App && typeof window.App.onViewChanged === 'function') {
      window.App.onViewChanged(viewName);
    }
  },

  showToast(message, type = 'success') {
    const container = document.getElementById('toast-container');
    if (!container) return;

    // Trigger Android native toast if running inside Android WebView
    if (window.AndroidApp && typeof window.AndroidApp.showToast === 'function') {
      window.AndroidApp.showToast(message);
    }

    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    
    let icon = '✅';
    if (type === 'error') icon = '⚠️';
    if (type === 'warning') icon = '🔔';
    if (type === 'info') icon = 'ℹ️';

    toast.innerHTML = `<span>${icon}</span> <span>${message}</span>`;
    container.appendChild(toast);

    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateY(10px)';
      toast.style.transition = 'all 0.3s ease';
      setTimeout(() => toast.remove(), 300);
    }, 3500);
  },

  showConfirm(title, message, onConfirm) {
    const modal = document.getElementById('generic-modal');
    const modalTitle = document.getElementById('modal-title');
    const modalBody = document.getElementById('modal-body');
    const modalFooter = document.getElementById('modal-footer');

    if (!modal) return;

    modalTitle.innerHTML = `<span style="color:var(--danger)">⚠️</span> ${title}`;
    modalBody.innerHTML = `
      <div style="text-align:center; padding: 10px 0;">
        <p style="font-size:15px; color:var(--text-main); margin-bottom: 8px;">${message}</p>
        <p style="font-size:12px; color:var(--text-muted);">আপনি কি নিশ্চিতভাবে এই পদক্ষেপটি নিতে চান?</p>
      </div>
    `;

    modalFooter.innerHTML = `
      <button class="btn btn-outline" id="confirm-cancel-btn">বাতিল</button>
      <button class="btn btn-danger" id="confirm-ok-btn">হ্যাঁ, নিশ্চিত</button>
    `;

    modal.style.display = 'flex';
    modal.classList.add('active');

    document.getElementById('confirm-cancel-btn').onclick = () => this.closeModal();
    document.getElementById('confirm-ok-btn').onclick = () => {
      this.closeModal();
      if (typeof onConfirm === 'function') onConfirm();
    };
  },

  openFormModal(title, bodyHtml, saveBtnText, onSave) {
    const modal = document.getElementById('generic-modal');
    const modalTitle = document.getElementById('modal-title');
    const modalBody = document.getElementById('modal-body');
    const modalFooter = document.getElementById('modal-footer');

    if (!modal) return;

    modalTitle.innerHTML = title;
    modalBody.innerHTML = bodyHtml;
    modalFooter.innerHTML = `
      <button class="btn btn-outline" id="modal-cancel-btn" type="button">বাতিল</button>
      <button class="btn btn-primary" id="modal-save-btn" type="button">
        <span>💾</span> ${saveBtnText || 'সংরক্ষণ করুন'}
      </button>
    `;

    modal.style.display = 'flex';
    modal.classList.add('active');

    const cancelBtn = document.getElementById('modal-cancel-btn');
    if (cancelBtn) {
      cancelBtn.onclick = (e) => {
        if (e && typeof e.preventDefault === 'function') e.preventDefault();
        this.closeModal();
      };
    }

    const saveBtn = document.getElementById('modal-save-btn');
    const form = modalBody.querySelector('form');

    // Remove any inline onsubmit that might have problematic references
    if (form) {
      form.removeAttribute('onsubmit');
      form.onsubmit = null;
    }

    const triggerSave = (evt) => {
      if (evt && typeof evt.preventDefault === 'function') {
        evt.preventDefault();
      }
      try {
        let isSaved = false;
        if (typeof onSave === 'function') {
          isSaved = onSave(evt);
        }
        if (isSaved) {
          this.closeModal();
        }
      } catch (err) {
        console.error('Modal save execution error:', err);
        UI.showToast('সংরক্ষণে সমস্যা: ' + (err.message || 'অপ্রত্যাশিত ত্রুটি'), 'error');
      }
      return false;
    };

    if (saveBtn) {
      saveBtn.onclick = triggerSave;
    }

    if (form) {
      form.addEventListener('submit', triggerSave);
    }

    // Auto-normalize Bengali numerals into standard digits in all inputs
    const bnDigits = { '০': '0', '১': '1', '২': '2', '৩': '3', '৪': '4', '৫': '5', '৬': '6', '৭': '7', '৮': '8', '৯': '9' };
    const inputs = modalBody.querySelectorAll('input, select, textarea');
    inputs.forEach(input => {
      input.addEventListener('input', () => {
        const group = input.closest('.form-group');
        if (group) group.classList.remove('has-error');
        const errorMsg = group ? group.querySelector('.form-error-msg') : null;
        if (errorMsg) errorMsg.textContent = '';
      });

      if (input.tagName === 'INPUT' && (input.type === 'number' || input.type === 'text' || input.type === 'tel')) {
        input.addEventListener('input', () => {
          if (/[০-৯]/.test(input.value)) {
            const start = input.selectionStart;
            const end = input.selectionEnd;
            input.value = input.value.replace(/[০-৯]/g, d => bnDigits[d]);
            try {
              if (start !== null) input.setSelectionRange(start, end);
            } catch (e) {}
          }
        });
      }
    });
  },

  openDetailsModal(title, bodyHtml) {
    const modal = document.getElementById('generic-modal');
    const modalTitle = document.getElementById('modal-title');
    const modalBody = document.getElementById('modal-body');
    const modalFooter = document.getElementById('modal-footer');

    if (!modal) return;

    modalTitle.innerHTML = title;
    modalBody.innerHTML = bodyHtml;
    modalFooter.innerHTML = `
      <button class="btn btn-primary" onclick="UI.closeModal()">ঠিক আছে</button>
    `;

    modal.style.display = 'flex';
    modal.classList.add('active');
  },

  closeModal() {
    const modal = document.getElementById('generic-modal');
    if (modal) {
      modal.classList.remove('active');
      modal.style.display = 'none';
    }
  },

  validateForm(formElement) {
    if (!formElement) return false;
    let isValid = true;
    let firstErrorField = null;
    const inputs = formElement.querySelectorAll('input, select, textarea');
    const bnDigits = { '০': '0', '১': '1', '২': '2', '৩': '3', '৪': '4', '৫': '5', '৬': '6', '৭': '7', '৮': '8', '৯': '9' };

    inputs.forEach(input => {
      const group = input.closest('.form-group');
      let errorMsgEl = group ? group.querySelector('.form-error-msg') : null;
      if (group && !errorMsgEl) {
        errorMsgEl = document.createElement('div');
        errorMsgEl.className = 'form-error-msg';
        group.appendChild(errorMsgEl);
      }

      const rawVal = (input.value !== undefined && input.value !== null) ? String(input.value).trim() : '';
      const val = rawVal.replace(/[০-৯]/g, d => bnDigits[d]);

      // Check required
      if (input.hasAttribute('required') && val === '') {
        if (group) group.classList.add('has-error');
        if (errorMsgEl) errorMsgEl.textContent = 'এই ঘরটি পূরণ করা আবশ্যক।';
        if (!firstErrorField) firstErrorField = input;
        isValid = false;
        return;
      }

      // Check numeric inputs for negative values
      if ((input.type === 'number' || input.getAttribute('inputmode') === 'numeric' || input.getAttribute('inputmode') === 'decimal') && val !== '') {
        const numVal = parseFloat(val);
        if (!isNaN(numVal) && numVal < 0) {
          if (group) group.classList.add('has-error');
          if (errorMsgEl) errorMsgEl.textContent = 'সংখ্যা ঋণাত্মক হতে পারে না।';
          if (!firstErrorField) firstErrorField = input;
          isValid = false;
          return;
        }
      }

      if (group) group.classList.remove('has-error');
      if (errorMsgEl) errorMsgEl.textContent = '';
    });

    if (!isValid) {
      this.showToast('অনুগ্রহ করে প্রয়োজনীয় তথ্যগুলো পূরণ করুন।', 'error');
      if (firstErrorField) {
        try { firstErrorField.focus(); } catch (e) {}
      }
    }

    return isValid;
  },

  // HTML5 Canvas Chart Renderers
  renderDashboardCharts() {
    this.renderIncomeExpenseChart();
    this.renderPondFeedingChart();
  },

  renderIncomeExpenseChart() {
    const canvas = document.getElementById('incomeExpenseChart');
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    if (!rect || rect.width <= 20 || rect.height <= 20) return;

    const ctx = canvas.getContext('2d');
    const dpr = window.devicePixelRatio || 1;

    canvas.width = rect.width * dpr;
    canvas.height = rect.height * dpr;
    ctx.scale(dpr, dpr);

    const width = rect.width;
    const height = rect.height;

    ctx.clearRect(0, 0, width, height);

    // Get data
    const stats = window.db.getDashboardStats();
    const income = stats.totalIncome || 0;
    const expense = stats.totalExpenses || 0;
    const profit = Math.max(0, stats.netProfit || 0);

    const maxVal = Math.max(income, expense, 10000) * 1.15;

    const barWidth = Math.min(60, width / 4.5);
    const startX = (width - (barWidth * 3 + 40)) / 2;
    const chartBottom = height - 40;
    const chartHeight = height - 60;

    // Draw baseline
    ctx.strokeStyle = '#dce7e0';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(20, chartBottom);
    ctx.lineTo(width - 20, chartBottom);
    ctx.stroke();

    // 1. Income Bar
    const incomeH = (income / maxVal) * chartHeight;
    const x1 = startX;
    const y1 = chartBottom - incomeH;

    ctx.fillStyle = '#198754';
    this._roundRect(ctx, x1, y1, barWidth, incomeH, 6);
    ctx.fill();

    // 2. Expense Bar
    const expenseH = (expense / maxVal) * chartHeight;
    const x2 = startX + barWidth + 20;
    const y2 = chartBottom - expenseH;

    ctx.fillStyle = '#dc3545';
    this._roundRect(ctx, x2, y2, barWidth, expenseH, 6);
    ctx.fill();

    // 3. Profit Bar
    const profitH = (profit / maxVal) * chartHeight;
    const x3 = startX + (barWidth + 20) * 2;
    const y3 = chartBottom - profitH;

    ctx.fillStyle = '#c59b27';
    this._roundRect(ctx, x3, y3, barWidth, profitH, 6);
    ctx.fill();

    // Labels and Values
    ctx.font = 'bold 12px ' + getComputedStyle(document.body).fontFamily;
    ctx.textAlign = 'center';

    // Values on top of bars
    ctx.fillStyle = '#11281c';
    ctx.fillText(`৳${Math.round(income / 1000)}k`, x1 + barWidth / 2, Math.max(16, y1 - 6));
    ctx.fillText(`৳${Math.round(expense / 1000)}k`, x2 + barWidth / 2, Math.max(16, y2 - 6));
    ctx.fillText(`৳${Math.round(profit / 1000)}k`, x3 + barWidth / 2, Math.max(16, y3 - 6));

    // Bottom labels
    ctx.font = '500 12px ' + getComputedStyle(document.body).fontFamily;
    ctx.fillStyle = '#4e695a';
    ctx.fillText('মোট আয়', x1 + barWidth / 2, chartBottom + 20);
    ctx.fillText('মোট ব্যয়', x2 + barWidth / 2, chartBottom + 20);
    ctx.fillText('নিট লাভ', x3 + barWidth / 2, chartBottom + 20);
  },

  renderPondFeedingChart() {
    const canvas = document.getElementById('pondFeedChart');
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    if (!rect || rect.width <= 20 || rect.height <= 20) return;

    const ctx = canvas.getContext('2d');
    const dpr = window.devicePixelRatio || 1;

    canvas.width = rect.width * dpr;
    canvas.height = rect.height * dpr;
    ctx.scale(dpr, dpr);

    const width = rect.width;
    const height = rect.height;

    ctx.clearRect(0, 0, width, height);

    const ponds = window.db.getAll('ponds');
    const feeds = window.db.getAll('dailyFeed');

    if (ponds.length === 0) {
      ctx.fillStyle = '#7c9486';
      ctx.textAlign = 'center';
      ctx.font = '13px ' + getComputedStyle(document.body).fontFamily;
      ctx.fillText('কোনো পুকুরের খাদ্য তথ্য পাওয়া যায়নি', width / 2, height / 2);
      return;
    }

    const data = ponds.map(p => {
      const pondFeeds = feeds.filter(f => f.pondId === p.id);
      const totalKg = pondFeeds.reduce((acc, f) => acc + (parseFloat(f.amountKg) || 0), 0);
      return {
        name: p.name.length > 8 ? p.name.substring(0, 8) + '..' : p.name,
        totalKg
      };
    });

    const maxKg = Math.max(...data.map(d => d.totalKg), 10) * 1.2;
    const barWidth = Math.min(45, (width - 40) / (data.length * 1.5));
    const step = (width - 40) / data.length;
    const chartBottom = height - 40;
    const chartHeight = height - 60;

    ctx.strokeStyle = '#dce7e0';
    ctx.beginPath();
    ctx.moveTo(20, chartBottom);
    ctx.lineTo(width - 20, chartBottom);
    ctx.stroke();

    const colors = ['#0d5c3a', '#198754', '#20c997', '#c59b27', '#0284c7'];

    data.forEach((item, idx) => {
      const barH = (item.totalKg / maxKg) * chartHeight;
      const x = 30 + idx * step;
      const y = chartBottom - barH;

      ctx.fillStyle = colors[idx % colors.length];
      this._roundRect(ctx, x, y, barWidth, barH, 4);
      ctx.fill();

      // Top value
      ctx.fillStyle = '#11281c';
      ctx.font = 'bold 11px ' + getComputedStyle(document.body).fontFamily;
      ctx.textAlign = 'center';
      ctx.fillText(`${item.totalKg} কেজি`, x + barWidth / 2, Math.max(15, y - 5));

      // Bottom label
      ctx.font = '500 11px ' + getComputedStyle(document.body).fontFamily;
      ctx.fillStyle = '#4e695a';
      ctx.fillText(item.name, x + barWidth / 2, chartBottom + 18);
    });
  },

  _roundRect(ctx, x, y, width, height, radius) {
    if (height < 2) height = 2;
    if (radius > height / 2) radius = height / 2;
    if (radius > width / 2) radius = width / 2;

    ctx.beginPath();
    ctx.moveTo(x + radius, y);
    ctx.lineTo(x + width - radius, y);
    ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
    ctx.lineTo(x + width, y + height);
    ctx.lineTo(x, y + height);
    ctx.lineTo(x, y + radius);
    ctx.quadraticCurveTo(x, y, x + radius, y);
    ctx.closePath();
  },

  // CSV Export with UTF-8 BOM
  exportToCsv(filename, headers, rows) {
    const BOM = '\uFEFF';
    let csvContent = BOM;
    
    // Header row
    csvContent += headers.map(h => `"${(h || '').toString().replace(/"/g, '""')}"`).join(',') + '\r\n';

    // Data rows
    rows.forEach(row => {
      csvContent += row.map(cell => `"${(cell || '').toString().replace(/"/g, '""')}"`).join(',') + '\r\n';
    });

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', filename);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    this.showToast('CSV ফাইল ডাউনলোড সম্পন্ন হয়েছে।', 'success');
  },

  printPage() {
    if (window.AndroidApp && typeof window.AndroidApp.printPage === 'function') {
      window.AndroidApp.printPage();
    } else {
      window.print();
    }
  }
};
