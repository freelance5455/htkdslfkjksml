// ============================================================================
// MASHA'S HAPPY HOME - MAIN GAME CONTROLLER, FSM, QUESTS, SAVE & UI MANAGER
// ============================================================================

const SAVE_STORAGE_KEY = 'mashas_happy_home_save_v2';

class MashaHappyHomeApp {
  constructor() {
    this.state = this.getDefaultState();
    this.engine3D = null;
    this.minigameEngine = null;
    this.selectedWardrobeCategory = 'dress';
    this.fsmTimer = null;
    this.rafId = null;
  }

  getDefaultState() {
    const characters = {};
    Object.keys(CHARACTER_DEFS).forEach((id) => {
      const def = CHARACTER_DEFS[id];
      characters[id] = {
        id,
        unlocked: def.unlockedByDefault,
        needs: {
          hunger: 78,
          happiness: 84,
          energy: 82,
          hygiene: 80,
          fun: 76,
          friendship: 80
        },
        fsmState: 'IDLE',
        outfit: { ...def.defaultOutfit }
      };
    });

    const furnitureLayout = {};
    FURNITURE_CATALOG.forEach((f) => {
      furnitureLayout[f.id] = { ...f.pos };
    });

    return {
      version: GAME_VERSION,
      coins: 350,
      gems: 25,
      xp: 0,
      level: 1,
      activeCharId: 'masha',
      currentRoom: 'living',
      timeOfDay: 'day', // day, sunset, night
      weather: 'sunny', // sunny, rain, fireflies, snow
      decorEditMode: false,
      characters,
      unlockedWardrobe: [
        'dress_classic_magenta', 'outfit_bear_vest', 'dress_sunny_frill', 'outfit_sport_hoodie',
        'hat_none', 'hat_kerchief_magenta', 'hat_sunhat_flower', 'hat_baseball_cap',
        'shoes_none', 'shoes_maryjanes', 'shoes_pink_boots', 'shoes_sneakers',
        'acc_none', 'acc_bowtie', 'acc_sunglasses', 'acc_scarf_red'
      ],
      savedOutfits: [],
      unlockedFurniture: FURNITURE_CATALOG.filter((f) => f.defaultUnlocked).map((f) => f.id),
      unlockedThemes: ['theme_classic'],
      roomThemes: {
        living: 'theme_classic',
        kitchen: 'theme_classic',
        bathroom: 'theme_classic',
        bedroom: 'theme_classic'
      },
      furnitureLayout,
      pantryInventory: {
        sweet_jam: 3,
        golden_honey: 2,
        pink_porridge: 2,
        herbal_tea: 2,
        carrot_crunch: 2
      },
      stats: {
        mealsFed: 0,
        bathsGiven: 0,
        napsTaken: 0,
        outfitsUnlocked: 0,
        furnitureUnlocked: 0,
        minigamesPlayed: 0,
        socialInteractions: 0,
        stickersCollected: 3
      },
      claimedAchievements: [],
      collectedStickers: ['stk_1', 'stk_2', 'stk_3'],
      dailyMissions: [
        { id: 'dm_feed', title: 'Feed Masha or friends 2 tasty meals', progress: 0, target: 2, rewardCoins: 45, claimed: false },
        { id: 'dm_game', title: 'Play any Mini-Game in the Arcade', progress: 0, target: 1, rewardCoins: 60, claimed: false },
        { id: 'dm_social', title: 'Hug or chat with friends in Living Room', progress: 0, target: 2, rewardCoins: 40, claimed: false }
      ],
      dailyStreakDay: 1,
      dailyRewardClaimedToday: false,
      tutorialCompleted: false,
      tutorialStep: 0,
      settings: {
        sfxVolume: 0.75,
        musicVolume: 0.45,
        muted: false,
        reducedMotion: false,
        uiScale: 'normal'
      },
      lastSavedAt: Date.now()
    };
  }

  init() {
    this.loadSave();
    this.applySettingsToDOM();

    this.engine3D = new Home3DEngine('webgl-room-canvas');
    this.engine3D.init();

    this.minigameEngine = new MiniGameEngine('minigame-canvas');

    this.rebuild3DScene();
    this.updateAllUI();
    this.startGameLoops();
  }

  loadSave() {
    try {
      const raw = localStorage.getItem(SAVE_STORAGE_KEY);
      if (!raw) return;
      const parsed = JSON.parse(raw);
      if (parsed && parsed.characters) {
        this.state = {
          ...this.getDefaultState(),
          ...parsed,
          settings: { ...this.getDefaultState().settings, ...(parsed.settings || {}) },
          stats: { ...this.getDefaultState().stats, ...(parsed.stats || {}) }
        };
        // Simulate mild offline need decay (capped so characters are never miserable on return)
        const elapsedMinutes = Math.min(120, Math.max(0, (Date.now() - (parsed.lastSavedAt || Date.now())) / 60000));
        if (elapsedMinutes > 2) {
          const decay = Math.min(18, Math.floor(elapsedMinutes * 0.25));
          Object.values(this.state.characters).forEach((c) => {
            Object.keys(c.needs).forEach((k) => {
              c.needs[k] = Math.max(35, c.needs[k] - decay);
            });
          });
        }
      }
    } catch (e) {}
  }

  saveGame(showFeedback = false) {
    try {
      this.state.lastSavedAt = Date.now();
      localStorage.setItem(SAVE_STORAGE_KEY, JSON.stringify(this.state));
      if (showFeedback) {
        this.showToast('Game progress saved locally! 💾');
      }
    } catch (e) {}
  }

  resetSaveData() {
    try {
      localStorage.removeItem(SAVE_STORAGE_KEY);
    } catch (e) {}
    this.state = this.getDefaultState();
    this.applySettingsToDOM();
    this.rebuild3DScene();
    this.updateAllUI();
    this.closeModal();
    this.showToast('Save data reset to a fresh start! 🌱');
  }

  startGameLoops() {
    // 3D Render loop
    const renderLoop = () => {
      if (this.engine3D) {
        this.engine3D.updateFrame();
      }
      this.rafId = requestAnimationFrame(renderLoop);
    };
    this.rafId = requestAnimationFrame(renderLoop);

    // Autonomous Character Needs & FSM Dialogue Tick
    if (this.fsmTimer) clearInterval(this.fsmTimer);
    this.fsmTimer = setInterval(() => {
      this.tickCharacterFSM();
    }, 6500);
  }

  tickCharacterFSM() {
    // Gentle need decay over time
    Object.values(this.state.characters).forEach((c) => {
      c.needs.hunger = Math.max(10, c.needs.hunger - 1);
      c.needs.energy = Math.max(10, c.needs.energy - 1);
      c.needs.hygiene = Math.max(10, c.needs.hygiene - 1);
      c.needs.fun = Math.max(10, c.needs.fun - 1);
      c.needs.friendship = Math.max(10, c.needs.friendship - 1);
      c.needs.happiness = Math.round(
        (c.needs.hunger + c.needs.energy + c.needs.hygiene + c.needs.fun + c.needs.friendship) / 5
      );
    });

    const activeChar = this.state.characters[this.state.activeCharId];
    const def = CHARACTER_DEFS[this.state.activeCharId];
    if (!activeChar || !def) return;

    // Determine FSM state from lowest need
    let pool = def.quotes.idle;
    if (activeChar.needs.hunger < 42) {
      activeChar.fsmState = 'HUNGRY';
      pool = def.quotes.hungry;
    } else if (activeChar.needs.energy < 42) {
      activeChar.fsmState = 'SLEEPY';
      pool = def.quotes.sleepy;
    } else if (activeChar.needs.hygiene < 42) {
      activeChar.fsmState = 'DIRTY';
      pool = def.quotes.dirty;
    } else if (activeChar.needs.fun < 45) {
      activeChar.fsmState = 'BORED';
      pool = def.quotes.bored;
    } else if (Math.random() < 0.38) {
      activeChar.fsmState = 'SOCIAL';
      pool = def.quotes.social;
    } else {
      activeChar.fsmState = 'HAPPY';
      pool = def.quotes.idle;
    }

    const line = pool[Math.floor(Math.random() * pool.length)];
    this.setDialogueBubble(`${def.emoji} ${def.name}: "${line}"`);
    this.updateNeedsHUD();
    this.saveGame(false);
  }

  setDialogueBubble(text) {
    const el = document.getElementById('speech-bubble-text');
    if (el) {
      el.textContent = text;
    }
  }

  showToast(msg) {
    const toast = document.getElementById('game-toast');
    const textEl = document.getElementById('game-toast-text');
    if (!toast || !textEl) return;
    textEl.textContent = msg;
    toast.classList.remove('hidden', 'opacity-0');
    toast.classList.add('opacity-100');
    clearTimeout(this._toastTimer);
    this._toastTimer = setTimeout(() => {
      toast.classList.add('opacity-0');
      setTimeout(() => toast.classList.add('hidden'), 250);
    }, 2600);
  }

  addRewards(coins = 0, gems = 0, xp = 0) {
    this.state.coins += coins;
    this.state.gems += gems;
    this.state.xp += xp;
    const newLevel = 1 + Math.floor(this.state.xp / 100);
    if (newLevel > this.state.level) {
      this.state.level = newLevel;
      this.state.coins += 50;
      this.state.gems += 3;
      sound.sfxSuccess();
      this.showToast(`🎉 Level Up! Welcome to Home Level ${newLevel}! (+50 🪙, +3 💎)`);
    }
    this.updateTopBarHUD();
    this.saveGame(false);
  }

  rebuild3DScene() {
    if (!this.engine3D) return;
    const rId = this.state.currentRoom;
    const themeId = this.state.roomThemes[rId] || 'theme_classic';
    const themeObj = ROOM_THEMES.find((t) => t.id === themeId) || ROOM_THEMES[0];

    this.engine3D.buildRoom(rId, themeObj, this.state.timeOfDay, this.state.weather);
    this.engine3D.buildRoomFurniture(
      rId,
      this.state.unlockedFurniture,
      this.state.furnitureLayout,
      this.engine3D.selectedFurnitureId
    );
    this.engine3D.buildCharacters(this.state.activeCharId, this.state.characters);
  }

  switchRoom(roomId) {
    if (!ROOM_DEFS[roomId]) return;
    sound.sfxClick();
    this.state.currentRoom = roomId;
    this.engine3D.selectedFurnitureId = null;
    this.rebuild3DScene();
    this.updateRoomHUD();
    this.closeModal();
  }

  selectCharacter(charId) {
    const c = this.state.characters[charId];
    const def = CHARACTER_DEFS[charId];
    if (!c || !def) return;
    sound.sfxClick();
    this.state.activeCharId = charId;
    this.rebuild3DScene();
    this.updateAllUI();
    const greet = def.quotes.happy[Math.floor(Math.random() * def.quotes.happy.length)];
    this.setDialogueBubble(`${def.emoji} ${def.name}: "${greet}"`);
    this.engine3D.triggerCharacterJump(charId);
  }

  onCharacterTapped3D(charId) {
    sound.sfxBoing();
    if (charId !== this.state.activeCharId) {
      this.selectCharacter(charId);
      return;
    }
    const c = this.state.characters[charId];
    const def = CHARACTER_DEFS[charId];
    c.needs.friendship = Math.min(100, c.needs.friendship + 8);
    c.needs.happiness = Math.min(100, c.needs.happiness + 6);
    this.state.stats.socialInteractions++;
    this.incrementMission('dm_social', 1);
    this.engine3D.triggerCharacterJump(charId);
    const quote = def.quotes.happy[Math.floor(Math.random() * def.quotes.happy.length)];
    this.setDialogueBubble(`${def.emoji} ${def.name}: "${quote}"`);
    this.addRewards(8, 0, 10);
    this.updateNeedsHUD();
  }

  onFurnitureTapped3D(furnId) {
    const item = FURNITURE_CATALOG.find((f) => f.id === furnId);
    if (!item) return;
    sound.sfxClick();

    if (this.state.decorEditMode) {
      this.engine3D.selectedFurnitureId = furnId;
      this.rebuild3DScene();
      this.updateDecorToolbarUI();
      this.showToast(`Selected ${item.name} — Drag on screen or tap Rotate!`);
      return;
    }

    // Interactive object reaction in normal play mode
    this.engine3D.triggerCharacterJump(this.state.activeCharId);
    this.showToast(`${CHARACTER_DEFS[this.state.activeCharId].name} interacted with ${item.icon} ${item.name}!`);
    this.performRoomCareAction();
  }

  performRoomCareAction() {
    const rId = this.state.currentRoom;
    const c = this.state.characters[this.state.activeCharId];
    const def = CHARACTER_DEFS[this.state.activeCharId];

    if (rId === 'kitchen') {
      this.openModal('modal-pantry');
      return;
    } else if (rId === 'bathroom') {
      sound.sfxBath();
      c.needs.hygiene = Math.min(100, c.needs.hygiene + 32);
      c.needs.happiness = Math.min(100, c.needs.happiness + 10);
      this.state.stats.bathsGiven++;
      this.setDialogueBubble(`${def.emoji} ${def.name}: "So many warm soapy bubbles! Squeaky clean!"`);
      this.showToast('Sparkling Bubble Bath complete! +15 🪙');
      this.addRewards(15, 0, 18);
    } else if (rId === 'bedroom') {
      sound.sfxSleep();
      c.needs.energy = Math.min(100, c.needs.energy + 36);
      c.needs.happiness = Math.min(100, c.needs.happiness + 10);
      this.state.stats.napsTaken++;
      this.setDialogueBubble(`${def.emoji} ${def.name}: "Zzz... Sweet woodland dreams! Feeling recharged!"`);
      this.showToast('Cozy nap complete! Energy restored! +15 🪙');
      this.addRewards(15, 0, 18);
    } else if (rId === 'living') {
      sound.sfxBoing();
      c.needs.friendship = Math.min(100, c.needs.friendship + 25);
      c.needs.happiness = Math.min(100, c.needs.happiness + 15);
      this.state.stats.socialInteractions++;
      this.incrementMission('dm_social', 1);
      this.setDialogueBubble(`${def.emoji} ${def.name}: "${def.quotes.social[0]}"`);
      this.showToast('Warm friendship hangout! +15 🪙');
      this.addRewards(15, 0, 15);
    } else if (rId === 'garden') {
      sound.sfxCoin();
      c.needs.happiness = Math.min(100, c.needs.happiness + 26);
      c.needs.fun = Math.min(100, c.needs.fun + 16);
      this.setDialogueBubble(`${def.emoji} ${def.name}: "The sunflowers and honeybees smell wonderful!"`);
      this.showToast('Garden stroll boosted Happiness! +15 🪙');
      this.addRewards(15, 0, 15);
    } else if (rId === 'playground') {
      sound.sfxBoing();
      c.needs.fun = Math.min(100, c.needs.fun + 28);
      c.needs.happiness = Math.min(100, c.needs.happiness + 16);
      this.setDialogueBubble(`${def.emoji} ${def.name}: "Wheee! The treehouse slide is super fast!"`);
      this.showToast('Playground fun! +15 🪙');
      this.addRewards(15, 0, 15);
    }

    this.engine3D.triggerCharacterJump(this.state.activeCharId);
    this.updateNeedsHUD();
  }

  feedCharacterItem(foodId) {
    const food = FOOD_ITEMS.find((f) => f.id === foodId);
    if (!food) return;
    const count = this.state.pantryInventory[foodId] || 0;

    if (count <= 0) {
      if (this.state.coins < food.cost) {
        sound.sfxMiss();
        this.showToast('Not enough coins! Play a mini-game to earn more! 🪙');
        return;
      }
      this.state.coins -= food.cost;
    } else {
      this.state.pantryInventory[foodId] = count - 1;
    }

    sound.sfxEat();
    const c = this.state.characters[this.state.activeCharId];
    const def = CHARACTER_DEFS[this.state.activeCharId];
    const isFav = def.favoriteFood === foodId;

    c.needs.hunger = Math.min(100, c.needs.hunger + food.hunger + (isFav ? 12 : 0));
    c.needs.happiness = Math.min(100, c.needs.happiness + food.happiness + (isFav ? 10 : 0));
    c.needs.energy = Math.min(100, c.needs.energy + food.energy);

    this.state.stats.mealsFed++;
    this.incrementMission('dm_feed', 1);

    this.setDialogueBubble(
      isFav
        ? `${def.emoji} ${def.name}: "YUM!! ${food.name} is my absolute favorite!! 😍"`
        : `${def.emoji} ${def.name}: "Mmm, delicious ${food.name}! Thank you!"`
    );

    this.engine3D.triggerCharacterJump(this.state.activeCharId);
    this.addRewards(12, 0, 16);
    this.renderPantryModal();
    this.updateNeedsHUD();
    this.showToast(`Fed ${food.icon} ${food.name} to ${def.name}!`);
  }

  incrementMission(missionId, amount) {
    const m = this.state.dailyMissions.find((x) => x.id === missionId);
    if (m && !m.claimed) {
      m.progress = Math.min(m.target, m.progress + amount);
    }
  }

  cycleTimeOfDay() {
    sound.sfxClick();
    const order = ['day', 'sunset', 'night'];
    const next = order[(order.indexOf(this.state.timeOfDay) + 1) % order.length];
    this.state.timeOfDay = next;
    this.rebuild3DScene();
    this.updateTopBarHUD();
    const names = { day: '☀️ Sunny Day', sunset: '🌅 Golden Sunset', night: '🌙 Starry Night' };
    this.showToast(`Time changed to ${names[next]}`);
  }

  cycleWeather() {
    sound.sfxClick();
    const order = ['sunny', 'rain', 'fireflies', 'snow'];
    const next = order[(order.indexOf(this.state.weather) + 1) % order.length];
    this.state.weather = next;
    this.rebuild3DScene();
    this.updateTopBarHUD();
    const names = { sunny: '🌤️ Clear Skies', rain: '🌧️ Gentle Rain', fireflies: '✨ Magic Fireflies', snow: '❄️ Cozy Snowfall' };
    this.showToast(`Weather changed to ${names[next]}`);
  }

  toggleDecorEditMode() {
    sound.sfxClick();
    this.state.decorEditMode = !this.state.decorEditMode;
    if (!this.state.decorEditMode) {
      this.engine3D.selectedFurnitureId = null;
    } else {
      const roomItems = FURNITURE_CATALOG.filter(
        (f) => f.room === this.state.currentRoom && this.state.unlockedFurniture.includes(f.id)
      );
      if (roomItems.length > 0) {
        this.engine3D.selectedFurnitureId = roomItems[0].id;
      }
    }
    this.rebuild3DScene();
    this.updateDecorToolbarUI();
    this.saveGame(false);
  }

  rotateSelectedFurniture(dir = 1) {
    const fId = this.engine3D.selectedFurnitureId;
    if (!fId) return;
    sound.sfxClick();
    const layout = this.state.furnitureLayout[fId];
    if (layout) {
      layout.rot = ((layout.rot || 0) + dir * (Math.PI / 4)) % (Math.PI * 2);
      this.engine3D.syncFurnitureTransform(fId);
      this.saveGame(false);
    }
  }

  nudgeSelectedFurniture(dx, dz) {
    const fId = this.engine3D.selectedFurnitureId;
    if (!fId) return;
    sound.sfxClick();
    const layout = this.state.furnitureLayout[fId];
    if (layout) {
      layout.x = Math.max(-3.6, Math.min(3.6, layout.x + dx));
      layout.z = Math.max(-3.2, Math.min(2.6, layout.z + dz));
      this.engine3D.syncFurnitureTransform(fId);
      this.saveGame(false);
    }
  }

  // ==========================================================================
  // MODALS & SUB-SCREENS
  // ==========================================================================

  openModal(modalId) {
    sound.sfxClick();
    document.querySelectorAll('.game-modal').forEach((m) => m.classList.add('hidden'));
    const target = document.getElementById(modalId);
    if (target) target.classList.remove('hidden');

    if (modalId === 'modal-wardrobe') this.renderWardrobeModal();
    if (modalId === 'modal-furniture') this.renderFurnitureShopModal();
    if (modalId === 'modal-arcade') this.renderArcadeModal();
    if (modalId === 'modal-quests') this.renderQuestsModal();
    if (modalId === 'modal-pantry') this.renderPantryModal();
    if (modalId === 'modal-map') this.renderMapModal();
    if (modalId === 'modal-settings') this.renderSettingsModal();
  }

  closeModal() {
    sound.sfxClick();
    document.querySelectorAll('.game-modal').forEach((m) => m.classList.add('hidden'));
    if (this.minigameEngine && this.minigameEngine.isRunning) {
      this.minigameEngine.stop();
    }
  }

  // Wardrobe System
  selectWardrobeTab(cat) {
    sound.sfxClick();
    this.selectedWardrobeCategory = cat;
    this.renderWardrobeModal();
  }

  equipOrBuyWardrobe(cat, itemId) {
    const c = this.state.characters[this.state.activeCharId];
    if (cat === 'colors') {
      sound.sfxClick();
      c.outfit.colorVariant = itemId;
      this.rebuild3DScene();
      this.renderWardrobeModal();
      this.saveGame(false);
      return;
    }

    const list = WARDROBE_ITEMS[cat] || [];
    const item = list.find((x) => x.id === itemId);
    if (!item) return;

    const isUnlocked = item.defaultUnlocked || this.state.unlockedWardrobe.includes(item.id);
    if (!isUnlocked) {
      if (item.currency === 'gems') {
        if (this.state.gems < item.cost) {
          sound.sfxMiss();
          this.showToast('Not enough Gems! Claim achievements or play mini-games! 💎');
          return;
        }
        this.state.gems -= item.cost;
      } else {
        if (this.state.coins < item.cost) {
          sound.sfxMiss();
          this.showToast('Not enough Coins! Play mini-games to earn more! 🪙');
          return;
        }
        this.state.coins -= item.cost;
      }
      this.state.unlockedWardrobe.push(item.id);
      this.state.stats.outfitsUnlocked++;
      sound.sfxSuccess();
      this.showToast(`Unlocked ${item.icon} ${item.name}!`);
    } else {
      sound.sfxClick();
    }

    c.outfit[cat] = item.id;
    this.rebuild3DScene();
    this.updateTopBarHUD();
    this.renderWardrobeModal();
    this.saveGame(false);
  }

  saveCurrentOutfitPreset() {
    sound.sfxCoin();
    const c = this.state.characters[this.state.activeCharId];
    const preset = {
      id: 'preset_' + Date.now(),
      charId: this.state.activeCharId,
      name: `${CHARACTER_DEFS[this.state.activeCharId].name} Look #${this.state.savedOutfits.length + 1}`,
      outfit: { ...c.outfit }
    };
    this.state.savedOutfits.unshift(preset);
    if (this.state.savedOutfits.length > 6) this.state.savedOutfits.pop();
    this.renderWardrobeModal();
    this.saveGame(false);
    this.showToast('Saved current outfit to your Lookbook! 📸');
  }

  applySavedOutfit(presetId) {
    const p = this.state.savedOutfits.find((x) => x.id === presetId);
    if (!p) return;
    sound.sfxClick();
    this.state.characters[this.state.activeCharId].outfit = { ...p.outfit };
    this.rebuild3DScene();
    this.renderWardrobeModal();
    this.showToast(`Applied ${p.name}! ✨`);
  }

  // Furniture & Room Themes Shop
  buyOrSelectFurniture(furnId) {
    const item = FURNITURE_CATALOG.find((f) => f.id === furnId);
    if (!item) return;

    const unlocked = item.defaultUnlocked || this.state.unlockedFurniture.includes(item.id);
    if (!unlocked) {
      if (item.currency === 'gems') {
        if (this.state.gems < item.cost) {
          sound.sfxMiss();
          this.showToast('Not enough Gems! 💎');
          return;
        }
        this.state.gems -= item.cost;
      } else {
        if (this.state.coins < item.cost) {
          sound.sfxMiss();
          this.showToast('Not enough Coins! 🪙');
          return;
        }
        this.state.coins -= item.cost;
      }
      this.state.unlockedFurniture.push(item.id);
      this.state.stats.furnitureUnlocked++;
      sound.sfxSuccess();
      this.showToast(`Unlocked & placed ${item.icon} ${item.name} in ${ROOM_DEFS[item.room].name}!`);
    } else {
      sound.sfxClick();
    }

    this.state.currentRoom = item.room;
    this.engine3D.selectedFurnitureId = item.id;
    this.rebuild3DScene();
    this.updateAllUI();
    this.renderFurnitureShopModal();
    this.saveGame(false);
  }

  buyOrApplyRoomTheme(themeId) {
    const t = ROOM_THEMES.find((x) => x.id === themeId);
    if (!t) return;
    const unlocked = t.defaultUnlocked || this.state.unlockedThemes.includes(t.id);
    if (!unlocked) {
      if (this.state.coins < t.cost) {
        sound.sfxMiss();
        this.showToast('Not enough Coins! 🪙');
        return;
      }
      this.state.coins -= t.cost;
      this.state.unlockedThemes.push(t.id);
      this.state.stats.furnitureUnlocked++;
      sound.sfxSuccess();
    } else {
      sound.sfxClick();
    }

    this.state.roomThemes[this.state.currentRoom] = t.id;
    this.rebuild3DScene();
    this.updateTopBarHUD();
    this.renderFurnitureShopModal();
    this.saveGame(false);
    this.showToast(`Applied ${t.name} theme! 🎨`);
  }

  // Mini-Games Launch & Completion
  launchMinigame(gameId) {
    const def = MINIGAME_DEFS.find((g) => g.id === gameId);
    if (!def) return;
    sound.sfxClick();
    document.querySelectorAll('.game-modal').forEach((m) => m.classList.add('hidden'));
    const playModal = document.getElementById('modal-minigame-play');
    if (playModal) playModal.classList.remove('hidden');

    const titleEl = document.getElementById('mg-active-title');
    const hintEl = document.getElementById('mg-active-hint');
    const summaryBox = document.getElementById('mg-result-overlay');
    if (titleEl) titleEl.textContent = `${def.icon} ${def.name}`;
    if (hintEl) hintEl.textContent = def.controlsHint;
    if (summaryBox) summaryBox.classList.add('hidden');

    this.minigameEngine.start(gameId);
  }

  onMinigameCompleted(gameId, score, levelReached) {
    sound.sfxSuccess();
    const coinsEarned = Math.max(20, Math.round(score * 0.65));
    const gemsEarned = score >= 140 ? 3 : (score >= 70 ? 1 : 0);
    const xpEarned = 35;

    const c = this.state.characters[this.state.activeCharId];
    c.needs.fun = Math.min(100, c.needs.fun + 35);
    c.needs.happiness = Math.min(100, c.needs.happiness + 20);

    this.state.stats.minigamesPlayed++;
    this.incrementMission('dm_game', 1);

    // Chance to unlock a new sticker in Collection Book!
    let newStickerMsg = '';
    const uncollected = COLLECTION_STICKERS.filter((s) => !this.state.collectedStickers.includes(s.id));
    if (uncollected.length > 0 && (score >= 50 || Math.random() < 0.65)) {
      const won = uncollected[Math.floor(Math.random() * uncollected.length)];
      this.state.collectedStickers.push(won.id);
      this.state.stats.stickersCollected = this.state.collectedStickers.length;
      newStickerMsg = `🎁 Bonus Sticker Discovered: ${won.icon} ${won.name}!`;
    }

    this.addRewards(coinsEarned, gemsEarned, xpEarned);
    this.updateNeedsHUD();

    const summaryBox = document.getElementById('mg-result-overlay');
    const summaryText = document.getElementById('mg-result-details');
    if (summaryBox && summaryText) {
      summaryText.innerHTML = `
        <div class="text-2xl font-extrabold text-amber-300 mb-1">Score: ${score} (Wave ${levelReached})</div>
        <div class="text-sm text-white mb-2">Rewards: <span class="font-bold text-yellow-300">+${coinsEarned} 🪙</span> ${gemsEarned > 0 ? `<span class="font-bold text-cyan-300">+${gemsEarned} 💎</span>` : ''} <span class="font-bold text-emerald-300">+35 XP</span></div>
        ${newStickerMsg ? `<div class="text-xs bg-amber-500/30 border border-amber-300 rounded-lg px-3 py-1.5 text-amber-100">${newStickerMsg}</div>` : ''}
      `;
      summaryBox.classList.remove('hidden');
    }
  }

  replayActiveMinigame() {
    if (!this.minigameEngine || !this.minigameEngine.activeGameId) return;
    this.launchMinigame(this.minigameEngine.activeGameId);
  }

  claimDailyMission(missionId) {
    const m = this.state.dailyMissions.find((x) => x.id === missionId);
    if (!m || m.claimed || m.progress < m.target) return;
    m.claimed = true;
    sound.sfxSuccess();
    this.addRewards(m.rewardCoins, 2, 25);
    this.renderQuestsModal();
    this.showToast(`Claimed Mission Reward: +${m.rewardCoins} 🪙 & +2 💎!`);
  }

  claimAchievement(achId) {
    const ach = ACHIEVEMENTS_LIST.find((a) => a.id === achId);
    if (!ach || this.state.claimedAchievements.includes(achId)) return;
    const val = this.state.stats[ach.stat] || 0;
    if (val < ach.target) return;
    this.state.claimedAchievements.push(achId);
    sound.sfxSuccess();
    this.addRewards(ach.rewardCoins, ach.rewardGems, 40);
    this.renderQuestsModal();
    this.showToast(`🏆 Achievement Claimed: +${ach.rewardCoins} 🪙 & +${ach.rewardGems} 💎!`);
  }

  claimDailyLoginGift() {
    if (this.state.dailyRewardClaimedToday) {
      this.showToast('You already claimed today’s Daily Gift! Come back tomorrow! 🎁');
      return;
    }
    this.state.dailyRewardClaimedToday = true;
    const bonusCoins = 75 + this.state.dailyStreakDay * 15;
    const bonusGems = 3;
    sound.sfxSuccess();
    this.addRewards(bonusCoins, bonusGems, 30);
    this.renderQuestsModal();
    this.showToast(`🎁 Day ${this.state.dailyStreakDay} Gift Claimed: +${bonusCoins} 🪙 & +${bonusGems} 💎!`);
  }

  // ==========================================================================
  // SETTINGS & TUTORIAL
  // ==========================================================================

  applySettingsToDOM() {
    const s = this.state.settings;
    sound.sfxVolume = s.sfxVolume;
    sound.musicVolume = s.musicVolume;
    sound.muted = s.muted;

    const rootEl = document.getElementById('app-root-container');
    if (rootEl) {
      rootEl.style.fontSize = s.uiScale === 'large' ? '110%' : '100%';
    }
  }

  toggleMuteAudio() {
    this.state.settings.muted = !this.state.settings.muted;
    this.applySettingsToDOM();
    this.updateTopBarHUD();
    this.renderSettingsModal();
    this.saveGame(false);
  }

  updateVolumeSetting(type, val) {
    const num = parseFloat(val);
    if (type === 'sfx') this.state.settings.sfxVolume = num;
    if (type === 'music') this.state.settings.musicVolume = num;
    this.applySettingsToDOM();
    this.saveGame(false);
  }

  toggleReducedMotion() {
    this.state.settings.reducedMotion = !this.state.settings.reducedMotion;
    this.rebuild3DScene();
    this.renderSettingsModal();
    this.saveGame(false);
  }

  toggleUIScale() {
    this.state.settings.uiScale = this.state.settings.uiScale === 'large' ? 'normal' : 'large';
    this.applySettingsToDOM();
    this.renderSettingsModal();
    this.saveGame(false);
  }

  startGameFromTitle() {
    sound.init();
    sound.sfxSuccess();
    sound.startMusic();
    const splash = document.getElementById('title-splash-screen');
    if (splash) splash.classList.add('hidden');
    if (this.engine3D) this.engine3D.onResize();

    if (!this.state.tutorialCompleted) {
      this.openTutorialStep(0);
    }
  }

  openTutorialStep(stepIdx) {
    const steps = [
      {
        title: "Welcome to Masha's Happy Home! 🏡",
        body: "Care for Masha, Bear, Rosie, and Panda in an interactive 3D woodland cottage! Tap any character in 3D to hug them, or switch friends using the portraits on the left."
      },
      {
        title: "6 Needs & Interactive Rooms 🍓🛁💤",
        body: "Each friend has 6 needs: Hunger, Happiness, Energy, Hygiene, Fun, and Friendship. Switch between all 6 rooms at the bottom and tap the big room action button to cook, bathe, or tuck them in!"
      },
      {
        title: "8 Mini-Games, Wardrobe & 3D Decor 🎨🎮",
        body: "Play 8 full mini-games in the Arcade to earn Coins, Gems, and Stickers! Customize hundreds of outfit combinations in the Wardrobe and drag-and-rotate 3D furniture in Decor Mode!"
      }
    ];
    this.state.tutorialStep = stepIdx;
    const modal = document.getElementById('modal-tutorial');
    const titleEl = document.getElementById('tut-step-title');
    const bodyEl = document.getElementById('tut-step-body');
    const btnEl = document.getElementById('tut-next-btn');
    if (!modal || !titleEl || !bodyEl || !btnEl) return;

    const current = steps[stepIdx];
    titleEl.textContent = current.title;
    bodyEl.textContent = current.body;
    btnEl.textContent = stepIdx < steps.length - 1 ? 'Next Tip ➡️' : "Let's Play! 🎉";
    modal.classList.remove('hidden');
  }

  advanceTutorial() {
    sound.sfxClick();
    if (this.state.tutorialStep < 2) {
      this.openTutorialStep(this.state.tutorialStep + 1);
    } else {
      this.state.tutorialCompleted = true;
      document.getElementById('modal-tutorial').classList.add('hidden');
      this.saveGame(false);
    }
  }

  // ==========================================================================
  // UI RENDERERS
  // ==========================================================================

  updateAllUI() {
    this.updateTopBarHUD();
    this.updateCharacterSelectorHUD();
    this.updateNeedsHUD();
    this.updateRoomHUD();
    this.updateDecorToolbarUI();
  }

  updateTopBarHUD() {
    const setTxt = (id, v) => {
      const el = document.getElementById(id);
      if (el) el.textContent = v;
    };
    setTxt('hud-coins', String(this.state.coins));
    setTxt('hud-gems', String(this.state.gems));
    setTxt('hud-level', `Lv.${this.state.level}`);

    const timeIcons = { day: '☀️ Day', sunset: '🌅 Sunset', night: '🌙 Night' };
    const weatherIcons = { sunny: '🌤️ Sunny', rain: '🌧️ Rain', fireflies: '✨ Fireflies', snow: '❄️ Snow' };
    setTxt('btn-time-cycle', timeIcons[this.state.timeOfDay] || '☀️ Day');
    setTxt('btn-weather-cycle', weatherIcons[this.state.weather] || '🌤️ Sunny');
    setTxt('btn-mute-toggle', this.state.settings.muted ? '🔇' : '🔊');
  }

  updateCharacterSelectorHUD() {
    const container = document.getElementById('char-selector-rail');
    if (!container) return;
    container.innerHTML = Object.values(CHARACTER_DEFS).map((def) => {
      const active = def.id === this.state.activeCharId;
      return `
        <button onclick="window.gameApp.selectCharacter('${def.id}')"
          class="flex items-center gap-1.5 px-2.5 py-1.5 rounded-2xl border-2 transition-all shadow-md ${
            active
              ? 'bg-amber-400 border-white text-slate-900 scale-105 font-extrabold'
              : 'bg-slate-900/75 border-amber-400/40 text-white hover:bg-slate-800'
          }">
          <span class="text-xl">${def.emoji}</span>
          <span class="text-xs hidden sm:inline">${def.name}</span>
        </button>
      `;
    }).join('');
  }

  updateNeedsHUD() {
    const c = this.state.characters[this.state.activeCharId];
    if (!c) return;
    const needsMeta = [
      { key: 'hunger', label: 'Hunger', icon: '🍓', color: 'bg-rose-500' },
      { key: 'happiness', label: 'Happy', icon: '😊', color: 'bg-amber-400' },
      { key: 'energy', label: 'Energy', icon: '⚡', color: 'bg-indigo-500' },
      { key: 'hygiene', label: 'Hygiene', icon: '🛁', color: 'bg-cyan-400' },
      { key: 'fun', label: 'Fun', icon: '🎈', color: 'bg-emerald-500' },
      { key: 'friendship', label: 'Friends', icon: '💖', color: 'bg-pink-500' }
    ];

    const barContainer = document.getElementById('needs-status-grid');
    if (!barContainer) return;
    barContainer.innerHTML = needsMeta.map((n) => {
      const val = Math.round(c.needs[n.key] || 0);
      return `
        <div class="bg-slate-900/80 backdrop-blur-md border border-white/15 rounded-xl px-2 py-1 flex flex-col gap-0.5">
          <div class="flex items-center justify-between text-[11px] font-bold text-white">
            <span>${n.icon} ${n.label}</span>
            <span class="${val < 40 ? 'text-rose-300 animate-pulse' : 'text-amber-200'}">${val}%</span>
          </div>
          <div class="w-full h-1.5 bg-slate-700 rounded-full overflow-hidden">
            <div class="${n.color} h-full rounded-full transition-all duration-300" style="width:${val}%"></div>
          </div>
        </div>
      `;
    }).join('');
  }

  updateRoomHUD() {
    const room = ROOM_DEFS[this.state.currentRoom] || ROOM_DEFS.living;
    const titleEl = document.getElementById('hud-room-name');
    if (titleEl) titleEl.textContent = `${room.icon} ${room.name}`;

    const careBtn = document.getElementById('btn-primary-care-action');
    if (careBtn) {
      careBtn.innerHTML = `<span class="text-xl">${room.actionIcon}</span> <span>${room.actionLabel}</span>`;
    }

    const tabsEl = document.getElementById('room-nav-tabs');
    if (tabsEl) {
      tabsEl.innerHTML = Object.values(ROOM_DEFS).map((r) => {
        const active = r.id === this.state.currentRoom;
        return `
          <button onclick="window.gameApp.switchRoom('${r.id}')"
            class="px-2.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1 transition-all ${
              active
                ? 'bg-gradient-to-r from-pink-600 to-amber-500 text-white shadow-lg scale-105 border border-white'
                : 'bg-slate-800/80 text-slate-200 hover:bg-slate-700 border border-white/10'
            }">
            <span>${r.icon}</span>
            <span class="hidden md:inline">${r.name.split(' ')[1] || r.name}</span>
          </button>
        `;
      }).join('');
    }
  }

  updateDecorToolbarUI() {
    const bar = document.getElementById('decor-edit-toolbar');
    const btn = document.getElementById('btn-toggle-decor');
    if (bar) {
      if (this.state.decorEditMode) bar.classList.remove('hidden');
      else bar.classList.add('hidden');
    }
    if (btn) {
      btn.className = this.state.decorEditMode
        ? 'px-3 py-1.5 rounded-xl bg-emerald-500 text-slate-950 font-extrabold text-xs shadow-lg border border-white'
        : 'px-3 py-1.5 rounded-xl bg-slate-900/80 text-white font-bold text-xs border border-white/20 hover:bg-slate-800';
      btn.textContent = this.state.decorEditMode ? '✅ Done Decorating' : '🪑 Move Decor';
    }
  }

  renderWardrobeModal() {
    const c = this.state.characters[this.state.activeCharId];
    const def = CHARACTER_DEFS[this.state.activeCharId];
    const cat = this.selectedWardrobeCategory;

    const tabsEl = document.getElementById('wardrobe-cat-tabs');
    if (tabsEl) {
      const cats = [
        { id: 'dress', label: '👗 Outfits' },
        { id: 'hat', label: '👒 Hats' },
        { id: 'shoes', label: '👟 Shoes' },
        { id: 'accessory', label: '🦋 Accessories' },
        { id: 'colors', label: '🎨 Colors' }
      ];
      tabsEl.innerHTML = cats.map((tab) => `
        <button onclick="window.gameApp.selectWardrobeTab('${tab.id}')"
          class="px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
            cat === tab.id ? 'bg-pink-600 text-white shadow' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
          }">${tab.label}</button>
      `).join('');
    }

    const gridEl = document.getElementById('wardrobe-items-grid');
    if (!gridEl) return;

    if (cat === 'colors') {
      gridEl.innerHTML = WARDROBE_ITEMS.colors.map((col) => {
        const equipped = c.outfit.colorVariant === col.id;
        return `
          <button onclick="window.gameApp.equipOrBuyWardrobe('colors', '${col.id}')"
            class="p-3 rounded-2xl border-2 flex flex-col items-center gap-2 ${
              equipped ? 'border-amber-400 bg-slate-800' : 'border-white/10 bg-slate-900/70 hover:bg-slate-800'
            }">
            <div class="w-10 h-10 rounded-full border-2 border-white shadow" style="background:${col.id}"></div>
            <div class="text-xs font-bold text-white">${col.name}</div>
            <div class="text-[11px] text-amber-300 font-semibold">${equipped ? 'Equipped ✨' : 'Tap to Dye'}</div>
          </button>
        `;
      }).join('');
    } else {
      const items = WARDROBE_ITEMS[cat] || [];
      gridEl.innerHTML = items.map((item) => {
        const unlocked = item.defaultUnlocked || this.state.unlockedWardrobe.includes(item.id);
        const equipped = c.outfit[cat] === item.id;
        return `
          <button onclick="window.gameApp.equipOrBuyWardrobe('${cat}', '${item.id}')"
            class="p-3 rounded-2xl border-2 flex flex-col items-center justify-between gap-1.5 text-center transition-all ${
              equipped
                ? 'border-amber-400 bg-amber-500/20'
                : 'border-white/10 bg-slate-900/70 hover:bg-slate-800'
            }">
            <div class="text-3xl">${item.icon}</div>
            <div class="text-xs font-bold text-white leading-tight">${item.name}</div>
            <div class="text-[11px] font-extrabold px-2 py-0.5 rounded-full ${
              equipped
                ? 'bg-emerald-500 text-slate-950'
                : (unlocked ? 'bg-slate-700 text-slate-200' : 'bg-amber-400 text-slate-950')
            }">
              ${equipped ? 'Wearing' : (unlocked ? 'Equip' : `${item.cost} ${item.currency === 'gems' ? '💎' : '🪙'}`)}
            </div>
          </button>
        `;
      }).join('');
    }

    const presetsEl = document.getElementById('wardrobe-saved-presets');
    if (presetsEl) {
      if (this.state.savedOutfits.length === 0) {
        presetsEl.innerHTML = `<span class="text-xs text-slate-400">No saved looks yet. Tap "Save Current Outfit" to store your favorite combinations for ${def.name}!</span>`;
      } else {
        presetsEl.innerHTML = this.state.savedOutfits.map((p) => `
          <button onclick="window.gameApp.applySavedOutfit('${p.id}')"
            class="px-3 py-1 rounded-xl bg-slate-800 hover:bg-pink-600 text-xs font-bold text-white border border-white/15">
            📸 ${p.name}
          </button>
        `).join('');
      }
    }
  }

  renderFurnitureShopModal() {
    const furnGrid = document.getElementById('furniture-catalog-grid');
    if (furnGrid) {
      furnGrid.innerHTML = FURNITURE_CATALOG.map((item) => {
        const unlocked = item.defaultUnlocked || this.state.unlockedFurniture.includes(item.id);
        const roomName = ROOM_DEFS[item.room] ? ROOM_DEFS[item.room].name : item.room;
        return `
          <div class="p-3 rounded-2xl bg-slate-900/80 border border-white/15 flex flex-col justify-between gap-2">
            <div class="flex items-center gap-2.5">
              <div class="text-3xl">${item.icon}</div>
              <div>
                <div class="text-xs font-bold text-white">${item.name}</div>
                <div class="text-[11px] text-amber-300">${roomName}</div>
              </div>
            </div>
            <button onclick="window.gameApp.buyOrSelectFurniture('${item.id}')"
              class="w-full py-1.5 rounded-xl text-xs font-extrabold ${
                unlocked
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-400/40 hover:bg-emerald-500/30'
                  : 'bg-amber-400 text-slate-950 hover:bg-amber-300'
              }">
              ${unlocked ? 'Go to Room & Select' : `Unlock (${item.cost} ${item.currency === 'gems' ? '💎' : '🪙'})`}
            </button>
          </div>
        `;
      }).join('');
    }

    const themeGrid = document.getElementById('room-themes-grid');
    if (themeGrid) {
      const activeTheme = this.state.roomThemes[this.state.currentRoom] || 'theme_classic';
      themeGrid.innerHTML = ROOM_THEMES.map((t) => {
        const unlocked = t.defaultUnlocked || this.state.unlockedThemes.includes(t.id);
        const isCurrent = activeTheme === t.id;
        return `
          <button onclick="window.gameApp.buyOrApplyRoomTheme('${t.id}')"
            class="p-2.5 rounded-xl border-2 flex items-center justify-between gap-2 ${
              isCurrent ? 'border-amber-400 bg-slate-800' : 'border-white/10 bg-slate-900/75'
            }">
            <div class="flex items-center gap-2">
              <span class="w-6 h-6 rounded-full border border-white" style="background:${t.wallColor}"></span>
              <span class="text-xs font-bold text-white">${t.name}</span>
            </div>
            <span class="text-[11px] font-extrabold text-amber-300">
              ${isCurrent ? 'Active' : (unlocked ? 'Apply' : `${t.cost} 🪙`)}
            </span>
          </button>
        `;
      }).join('');
    }
  }

  renderArcadeModal() {
    const grid = document.getElementById('arcade-games-grid');
    if (!grid) return;
    grid.innerHTML = MINIGAME_DEFS.map((g) => `
      <div class="rounded-2xl bg-gradient-to-br ${g.bannerColor} p-3.5 shadow-lg border border-white/25 flex flex-col justify-between gap-2">
        <div>
          <div class="flex items-center justify-between mb-1">
            <span class="text-3xl">${g.icon}</span>
            <span class="text-[10px] uppercase tracking-wider font-extrabold bg-black/30 px-2 py-0.5 rounded-full text-white">${g.category}</span>
          </div>
          <h4 class="text-sm font-extrabold text-white">${g.name}</h4>
          <p class="text-xs text-white/90 mt-1 leading-snug">${g.description}</p>
        </div>
        <button onclick="window.gameApp.launchMinigame('${g.id}')"
          class="w-full py-2 rounded-xl bg-amber-300 hover:bg-amber-200 text-slate-950 font-extrabold text-xs shadow">
          ▶️ Play Now
        </button>
      </div>
    `).join('');
  }

  renderPantryModal() {
    const grid = document.getElementById('pantry-items-grid');
    if (!grid) return;
    const def = CHARACTER_DEFS[this.state.activeCharId];
    grid.innerHTML = FOOD_ITEMS.map((f) => {
      const stock = this.state.pantryInventory[f.id] || 0;
      const isFav = def.favoriteFood === f.id;
      return `
        <div class="p-3 rounded-2xl bg-slate-900/85 border ${isFav ? 'border-pink-400' : 'border-white/15'} flex flex-col justify-between gap-2">
          <div class="flex items-start justify-between">
            <span class="text-3xl">${f.icon}</span>
            <span class="text-[11px] font-bold px-2 py-0.5 rounded-full bg-slate-800 text-amber-300">In Pantry: ${stock}</span>
          </div>
          <div>
            <div class="text-xs font-extrabold text-white">${f.name} ${isFav ? '💖' : ''}</div>
            <div class="text-[11px] text-slate-300 mt-0.5">+${f.hunger} Hunger • +${f.happiness} Happy</div>
          </div>
          <button onclick="window.gameApp.feedCharacterItem('${f.id}')"
            class="w-full py-1.5 rounded-xl font-extrabold text-xs ${
              stock > 0 || f.cost === 0
                ? 'bg-emerald-400 hover:bg-emerald-300 text-slate-950'
                : 'bg-amber-400 hover:bg-amber-300 text-slate-950'
            }">
            ${stock > 0 || f.cost === 0 ? `Feed ${def.name}` : `Buy & Feed (${f.cost} 🪙)`}
          </button>
        </div>
      `;
    }).join('');
  }

  renderQuestsModal() {
    const missionsEl = document.getElementById('quests-daily-list');
    if (missionsEl) {
      missionsEl.innerHTML = this.state.dailyMissions.map((m) => {
        const ready = m.progress >= m.target && !m.claimed;
        return `
          <div class="p-3 rounded-xl bg-slate-900/80 border border-white/15 flex items-center justify-between gap-2">
            <div>
              <div class="text-xs font-bold text-white">${m.title}</div>
              <div class="text-[11px] text-amber-300">Progress: ${m.progress}/${m.target} • Reward: +${m.rewardCoins} 🪙</div>
            </div>
            <button onclick="window.gameApp.claimDailyMission('${m.id}')"
              ${!ready ? 'disabled' : ''}
              class="px-3 py-1.5 rounded-xl text-xs font-extrabold ${
                m.claimed
                  ? 'bg-slate-700 text-slate-400'
                  : (ready ? 'bg-emerald-400 text-slate-950 animate-bounce' : 'bg-slate-800 text-slate-400')
              }">
              ${m.claimed ? 'Claimed ✅' : (ready ? 'Claim 🎁' : 'In Progress')}
            </button>
          </div>
        `;
      }).join('');
    }

    const achEl = document.getElementById('quests-achievements-list');
    if (achEl) {
      achEl.innerHTML = ACHIEVEMENTS_LIST.map((a) => {
        const val = this.state.stats[a.stat] || 0;
        const claimed = this.state.claimedAchievements.includes(a.id);
        const ready = val >= a.target && !claimed;
        return `
          <div class="p-3 rounded-xl bg-slate-900/80 border border-white/15 flex items-center justify-between gap-2">
            <div class="flex items-center gap-2.5">
              <span class="text-2xl">${a.icon}</span>
              <div>
                <div class="text-xs font-bold text-white">${a.name}</div>
                <div class="text-[11px] text-slate-300">${a.desc} (${Math.min(val, a.target)}/${a.target})</div>
              </div>
            </div>
            <button onclick="window.gameApp.claimAchievement('${a.id}')"
              ${!ready ? 'disabled' : ''}
              class="px-3 py-1.5 rounded-xl text-xs font-extrabold ${
                claimed
                  ? 'bg-slate-700 text-slate-400'
                  : (ready ? 'bg-amber-400 text-slate-950' : 'bg-slate-800 text-slate-400')
              }">
              ${claimed ? 'Done 🏆' : (ready ? `+${a.rewardCoins}🪙` : 'Locked')}
            </button>
          </div>
        `;
      }).join('');
    }

    const stickersEl = document.getElementById('collection-stickers-grid');
    if (stickersEl) {
      stickersEl.innerHTML = COLLECTION_STICKERS.map((s) => {
        const owned = this.state.collectedStickers.includes(s.id);
        return `
          <div class="p-2.5 rounded-xl border text-center ${
            owned ? 'bg-amber-500/20 border-amber-300' : 'bg-slate-900/50 border-white/10 opacity-50'
          }">
            <div class="text-2xl">${owned ? s.icon : '❓'}</div>
            <div class="text-[11px] font-bold text-white mt-1">${owned ? s.name : 'Mystery Sticker'}</div>
            <div class="text-[10px] text-amber-300">${s.rarity}</div>
          </div>
        `;
      }).join('');
    }
  }

  renderMapModal() {
    const grid = document.getElementById('world-map-grid');
    if (!grid) return;
    grid.innerHTML = Object.values(ROOM_DEFS).map((r) => {
      const active = r.id === this.state.currentRoom;
      return `
        <button onclick="window.gameApp.switchRoom('${r.id}')"
          class="p-4 rounded-2xl border-2 text-left transition-all flex flex-col justify-between gap-2 ${
            active ? 'border-amber-400 bg-amber-500/20' : 'border-white/15 bg-slate-900/80 hover:bg-slate-800'
          }">
          <div class="flex items-center justify-between">
            <span class="text-3xl">${r.icon}</span>
            <span class="text-[11px] font-bold px-2 py-0.5 rounded-full bg-white/10 text-amber-200">Boosts ${r.primaryNeed}</span>
          </div>
          <div>
            <div class="text-sm font-extrabold text-white">${r.name}</div>
            <div class="text-xs text-slate-300 mt-0.5">${r.description}</div>
          </div>
        </button>
      `;
    }).join('');
  }

  renderSettingsModal() {
    const s = this.state.settings;
    const sfxEl = document.getElementById('slider-sfx-vol');
    const musEl = document.getElementById('slider-music-vol');
    if (sfxEl) sfxEl.value = String(s.sfxVolume);
    if (musEl) musEl.value = String(s.musicVolume);

    const motionBtn = document.getElementById('btn-reduced-motion');
    if (motionBtn) {
      motionBtn.textContent = s.reducedMotion ? 'ON (Reduced Motion Active)' : 'OFF (Full 3D & Particles)';
    }

    const scaleBtn = document.getElementById('btn-ui-scale');
    if (scaleBtn) {
      scaleBtn.textContent = s.uiScale === 'large' ? 'Large Accessible Text (110%)' : 'Standard Mobile/Desktop (100%)';
    }
  }
}

window.addEventListener('load', () => {
  window.gameApp = new MashaHappyHomeApp();
  window.gameApp.init();
});
