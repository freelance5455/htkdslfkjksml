/* ==========================================================
   NOMIDMAN TRANS CO. LTD — site configuration
   ========================================================== */
window.EA_CONFIG = {
  businessName: "NOMIDMAN TRANS CO. LTD",
  supportEmail: "info@e-asset.co.ug",   // change to your real address
  supportPhone: "+256764502805",


  // Office hours (East Africa Time). Times are in hours; null = closed.
  hours: { timezone: "Africa/Kampala", mon_fri: [8.5, 17], sat: [9, 14], sun: null },

  // Main office (shown in the footer)
  office: {
    address: "Along Juba Rd, Jinja Camp, Lira City West, Lira City-UGANDA",
    poBox: "P.O Box 332567, LIRA (U)",
    phone: "+256764502805"
  },

  // One-time owner registration fee (UGX)
  registrationFee: 20000,

  // Currency the registration fee is DISPLAYED in, by country of registration.
  // The amount charged is always the UGX fee above. South Sudan stays in UGX.
  registrationDisplayCurrency: {
    "Uganda": "UGX", "Tanzania": "TZS", "Rwanda": "RWF",
    "DR Congo": "CDF", "Kenya": "KES", "South Sudan": "USD"
  },
  // Used for "Other" nationalities and any country not listed above
  displayCurrencyDefault: "USD",

  // Subscription plans: price in UGX per 91-day period, max listings
  plans: {
    budget:  { key: "budget",  name_key: "plan_budget",  price: 50000,  days: 91, limit: 2, photos: 3  },
    economy: { key: "economy", name_key: "plan_economy", price: 150000, days: 91, limit: 13, photos: 6 },
    premium: { key: "premium", name_key: "plan_premium", price: 300000, days: 91, limit: 25, photos: 10 }
  },

  // Listing photos: max size per file, accepted types, resize width and JPEG quality.
  // Max photos per listing comes from each plan's "photos" value above (3 / 6 / 10).
  photos: {
    maxBytes: 20 * 1024 * 1024,        // largest file accepted before resizing
    maxOutBytes: 4 * 1024 * 1024,      // every stored photo is resized to 4 MB or less
    types: ["image/jpeg", "image/png", "image/webp"],
    maxWidth: 1600,
    quality: 0.72
  },

  // Listing boost: pushes a listing to the top of search for a few days.
  // Price is a placeholder business decision: change it here.
  boost: { priceUGX: 10000, days: 7 },

  // Website address. Share and referral links use it, so they work from the website and from the app.
  siteUrl: "https://nomidtrans.shop",

  // Mobile app download (website copy). Leave androidUrl empty until the signed APK is published.
  app: { androidUrl: "", androidSha256: "", version: "" },

  // Legal details the admin can edit. "version" rises only for changes users must accept again.
  legal: { version: 1, lastUpdated: "2026-11-09", dpo: "", serverLocation: "", paymentYears: "", refundYears: "", log: [] },

  // Owner referral: credit given to the referrer, and how long unused credit lasts
  referral: { bonusUGX: 2000, expiryMonths: 12 },

  // Basic format rules for identity document numbers (letters and digits only).
  // These check the shape of a number, not whether it is genuine. Confirm the official
  // lengths for each country and document before launch and adjust here.
  // National ID rules by country of registration (digits = numbers only)
  idRules: {
    national_id: {
      "Uganda":       { min: 14, max: 14, digits: false },  // 14 characters, alphanumeric
      "Tanzania":     { min: 20, max: 20, digits: true },
      "Rwanda":       { min: 16, max: 16, digits: true },
      "DR Congo":     { min: 12, max: 12, digits: true },
      "South Sudan":  { min: 9,  max: 9,  digits: true },
      "Kenya":        { min: 8,  max: 9,  digits: true },
      "default":      { min: 8,  max: 20, digits: false }   // other nationalities
    },
    // Driving permits are alphanumeric in all six countries. Lengths are NOT the same as
    // National ID lengths. Replace "default" with per-country entries (same shape as
    // national_id) once the official lengths are confirmed.
    // Driving permit numbers are alphanumeric in all six countries.
    driving_permit: {
      "Uganda":      { min: 10, max: 12, digits: false },
      "Tanzania":    { min: 10, max: 14, digits: false },
      "Rwanda":      { min: 6,  max: 20, digits: false },  // lengths vary: general range
      "DR Congo":    { min: 6,  max: 20, digits: false },  // lengths vary: general range
      "South Sudan": { min: 11, max: 11, digits: false },
      "Kenya":       { min: 8,  max: 8,  digits: false },
      "default":     { min: 6,  max: 20, digits: false }   // other nationalities
    },
    // Passports: "letters" = number of leading letters required (rest are digits).
    // "lengths" = exact allowed lengths (when given, min/max are not used).
    passport: {
      "Uganda":      { lengths: [8, 9], letters: 2, digits: false },
      "Kenya":       { lengths: [7, 9], letters: 2, digits: false },
      "Tanzania":    { lengths: [8, 9], letters: 2, digits: false },
      "Rwanda":      { lengths: [8],    letters: 2, digits: false },
      "DR Congo":    { lengths: [9],    letters: 2, digits: false },
      "South Sudan": { lengths: [9],    letters: 0, digits: false },  // alphanumeric
      "default":     { min: 6, max: 9,  letters: 0, digits: false }
    },
    voter_id:       { min: 8, max: 20, digits: false }
  },

  // Voluntary appreciation gifts: allowed range in UGX equivalent
  gift: { minUGX: 1000, maxUGX: 50000 },

  // Days after expiry before an unrenewed listing is auto-deleted from the owner dashboard
  graceDays: 15,

  // Indicative FX rates (1 unit = X UGX). Update regularly or fetch live in production.
  // Used only for showing approximate equivalents.
  currencies: {
    UGX: { symbol: "UGX", label: "UGX — Ugandan Shilling", perUGX: 1 },
    USD: { symbol: "$",   label: "USD — US Dollar",        perUGX: 1 / 3800 },
    GBP: { symbol: "£",   label: "GBP — British Pound", perUGX: 1 / 4900 },
    EURO:{ symbol: "€",   label: "EUR — Euro",             perUGX: 1 / 4150 },
    KES: { symbol: "KSh", label: "KES — Kenyan Shilling",  perUGX: 1 / 29.4 },
    CDF: { symbol: "FC", label: "CDF — Congolese Franc", perUGX: 2800 / 3800 },
    RWF: { symbol: "RWF", label: "RWF — Rwandan Franc", perUGX: 1400 / 3800 },
    TZS: { symbol: "TSh", label: "TZS — Tanzanian Shilling", perUGX: 1 / 1.46 }
  },

  // Payment gateway integration.
  //  demoMode = true  -> payments and OTPs are simulated in the browser (for testing only)
  //  demoMode = false -> the frontend calls your backend, which verifies payments with Flutterwave (see README)
  demoMode: true,

  // Payment provider for live payments: "flutterwave" (this edition) or "pesapal"
  paymentProvider: (window.EA_EDITION && EA_EDITION.paymentProvider) || "pesapal",
  // Flutterwave: the PUBLIC key is safe in the browser. The SECRET key lives only on the server.
  flutterwave: {
    publicKey: "FLWPUBK_TEST-REPLACE-WITH-YOUR-PUBLIC-KEY",
    currency: "UGX",                                       // charged amounts are always UGX
    paymentOptions: "card,mobilemoney,banktransfer,ussd",
    verifyEndpoint: "/api/flutterwave/verify"               // server checks the transaction before any benefit is granted
  },
  paymentEndpoint: "/api/pesapal/submit-order",
  otpEndpoint: "/api/otp/send",
  otpVerifyEndpoint: "/api/otp/verify"
};
