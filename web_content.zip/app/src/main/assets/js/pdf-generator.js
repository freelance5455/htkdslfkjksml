// pdf-generator.js - Complete Offline PDF Generation System
// Government Boys Primary School Sultan Matt Uchari (EMIS: 06994)
// Powered by bundled jsPDF and AutoTable

const PDFGen = {
  getJsPDF() {
    const { jsPDF } = window.jspdf || {};
    if (!jsPDF) {
      throw new Error('jsPDF library is not loaded.');
    }
    return jsPDF;
  },

  // Color constants
  PRIMARY_COLOR: [26, 54, 93],    // Deep Navy
  SECONDARY_COLOR: [15, 81, 50],  // Emerald Green
  ACCENT_COLOR: [212, 175, 55],   // Gold
  TEXT_DARK: [30, 41, 59],
  MUTED_BG: [248, 250, 252],

  // Header helper for official reports
  addReportHeader(doc, title, subtitle = '', settings = null) {
    const sName = settings?.schoolName || 'GOVERNMENT BOYS PRIMARY SCHOOL SULTAN MATT UCHARI';
    const sEmis = settings?.emis || '06994';
    const sLoc = settings?.location || 'District Barkhan, Balochistan, Pakistan';

    doc.setFillColor(26, 54, 93);
    doc.rect(0, 0, 210, 26, 'F');

    // School Name
    doc.setTextColor(255, 255, 255);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(13);
    doc.text(sName, 105, 10, { align: 'center' });

    // EMIS & Location
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8.5);
    doc.text(`EMIS CODE: ${sEmis}  |  ${sLoc}`, 105, 17, { align: 'center' });

    // Gold accent line
    doc.setDrawColor(212, 175, 55);
    doc.setLineWidth(1);
    doc.line(10, 26, 200, 26);

    // Title banner
    doc.setTextColor(26, 54, 93);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.text(title.toUpperCase(), 105, 33, { align: 'center' });

    if (subtitle) {
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8.5);
      doc.setTextColor(71, 85, 105);
      doc.text(subtitle, 105, 38, { align: 'center' });
      return 43; // Y coordinate after header
    }

    return 38;
  },

  // Footer helper
  addReportFooter(doc, settings = null, pageNum = null, totalPages = null) {
    const ht = settings?.headTeacher || 'SHOUKAT ALI';
    const pageHeight = doc.internal.pageSize.getHeight();
    const pageWidth = doc.internal.pageSize.getWidth();

    // Footer divider
    doc.setDrawColor(203, 213, 225);
    doc.setLineWidth(0.5);
    doc.line(14, pageHeight - 20, pageWidth - 14, pageHeight - 20);

    // Signature text
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9);
    doc.setTextColor(26, 54, 93);
    doc.text('HEAD TEACHER', pageWidth - 20, pageHeight - 14, { align: 'right' });
    doc.setFont('helvetica', 'normal');
    doc.text(ht, pageWidth - 20, pageHeight - 9, { align: 'right' });

    // Generated timestamp
    const nowStr = new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
    doc.setFontSize(7.5);
    doc.setTextColor(148, 163, 184);
    doc.text(`Official School Document  |  Generated on ${nowStr}`, 14, pageHeight - 11);

    if (pageNum && totalPages) {
      doc.text(`Page ${pageNum} of ${totalPages}`, 105, pageHeight - 11, { align: 'center' });
    }
  },

  // Helper to safely add image to PDF
  addImageSafe(doc, imageData, x, y, w, h) {
    if (!imageData) return false;
    try {
      const format = imageData.includes('data:image/png') ? 'PNG' : 'JPEG';
      doc.addImage(imageData, format, x, y, w, h);
      return true;
    } catch (e) {
      console.warn('Could not render image in PDF:', e);
      return false;
    }
  },

  // 1. Daily Attendance Report PDF
  async generateDailyAttendancePDF(className, date, records, summary, settings) {
    const jsPDF = this.getJsPDF();
    const doc = new jsPDF('p', 'mm', 'a4');

    const startY = this.addReportHeader(
      doc,
      `Daily Attendance Report - ${className}`,
      `Date: ${date}  |  Academic Year: ${settings?.academicYear || '2026-2027'}`,
      settings
    );

    // Summary Box
    doc.setFillColor(241, 245, 249);
    doc.roundedRect(14, startY, 182, 14, 2, 2, 'F');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8.5);
    doc.setTextColor(30, 41, 59);

    const sY = startY + 9;
    doc.text(`Total Students: ${summary.total}`, 20, sY);
    doc.setTextColor(22, 101, 52);
    doc.text(`Present: ${summary.present}`, 65, sY);
    doc.setTextColor(185, 28, 28);
    doc.text(`Absent: ${summary.absent}`, 105, sY);
    doc.setTextColor(180, 83, 9);
    doc.text(`Leave: ${summary.leave}`, 140, sY);
    doc.setTextColor(26, 54, 93);
    doc.text(`Attendance: ${summary.percentage}%`, 175, sY, { align: 'right' });

    // Table
    const tableData = records.map((r, i) => [
      i + 1,
      r.rollNo || '-',
      r.studentName,
      r.fatherName,
      r.status === 'P' ? 'PRESENT' : r.status === 'A' ? 'ABSENT' : 'LEAVE'
    ]);

    doc.autoTable({
      startY: startY + 18,
      head: [['Sr#', 'Roll#', 'Student Name', 'Father Name', 'Status']],
      body: tableData,
      theme: 'grid',
      headStyles: {
        fillColor: [26, 54, 93],
        textColor: [255, 255, 255],
        fontStyle: 'bold',
        fontSize: 9,
        halign: 'center'
      },
      columnStyles: {
        0: { cellWidth: 14, halign: 'center' },
        1: { cellWidth: 20, halign: 'center' },
        2: { cellWidth: 60 },
        3: { cellWidth: 58 },
        4: { cellWidth: 30, halign: 'center', fontStyle: 'bold' }
      },
      styles: { fontSize: 8.5, cellPadding: 3 },
      didParseCell: function (data) {
        if (data.section === 'body' && data.column.index === 4) {
          if (data.cell.raw === 'PRESENT') {
            data.cell.styles.textColor = [22, 101, 52];
          } else if (data.cell.raw === 'ABSENT') {
            data.cell.styles.textColor = [185, 28, 28];
          } else {
            data.cell.styles.textColor = [180, 83, 9];
          }
        }
      },
      margin: { left: 14, right: 14, bottom: 25 }
    });

    this.addReportFooter(doc, settings, 1, 1);
    doc.save(`Attendance_${className.replace(/\s+/g, '_')}_${date}.pdf`);
  },

  // 2. Monthly Attendance Report PDF
  async generateMonthlyAttendancePDF(className, month, year, dataList, settings) {
    const jsPDF = this.getJsPDF();
    const doc = new jsPDF('p', 'mm', 'a4');

    const startY = this.addReportHeader(
      doc,
      `Monthly Attendance Report - ${className}`,
      `Month: ${month} ${year}  |  Class: ${className}`,
      settings
    );

    const tableData = dataList.map((d, i) => [
      i + 1,
      d.rollNo || '-',
      d.studentName,
      d.fatherName,
      d.totalDays,
      d.present,
      d.absent,
      d.leave,
      `${d.percentage}%`
    ]);

    doc.autoTable({
      startY: startY + 4,
      head: [['Sr#', 'Roll#', 'Student Name', 'Father Name', 'Days', 'P', 'A', 'L', '%']],
      body: tableData,
      theme: 'grid',
      headStyles: {
        fillColor: [26, 54, 93],
        textColor: [255, 255, 255],
        fontStyle: 'bold',
        fontSize: 8.5,
        halign: 'center'
      },
      columnStyles: {
        0: { cellWidth: 10, halign: 'center' },
        1: { cellWidth: 16, halign: 'center' },
        2: { cellWidth: 46 },
        3: { cellWidth: 46 },
        4: { cellWidth: 14, halign: 'center' },
        5: { cellWidth: 12, halign: 'center', textColor: [22, 101, 52] },
        6: { cellWidth: 12, halign: 'center', textColor: [185, 28, 28] },
        7: { cellWidth: 12, halign: 'center', textColor: [180, 83, 9] },
        8: { cellWidth: 14, halign: 'center', fontStyle: 'bold' }
      },
      styles: { fontSize: 8, cellPadding: 2.5 },
      margin: { left: 14, right: 14, bottom: 25 }
    });

    this.addReportFooter(doc, settings, 1, 1);
    doc.save(`Monthly_Attendance_${className.replace(/\s+/g, '_')}_${month}_${year}.pdf`);
  },

  // 3. Individual Student Attendance Report PDF
  async generateIndividualAttendancePDF(student, history, summary, settings) {
    const jsPDF = this.getJsPDF();
    const doc = new jsPDF('p', 'mm', 'a4');

    const startY = this.addReportHeader(
      doc,
      `Student Attendance History Report`,
      `Student: ${student.name}  |  Class: ${student.className}  |  Roll#: ${student.rollNo}`,
      settings
    );

    // Student summary box
    doc.setFillColor(241, 245, 249);
    doc.roundedRect(14, startY, 182, 18, 2, 2, 'F');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8.5);
    doc.setTextColor(30, 41, 59);

    doc.text(`Student Name: ${student.name}`, 18, startY + 6);
    doc.text(`Father Name: ${student.fatherName}`, 18, startY + 12);
    doc.text(`Admission#: ${student.admissionNo || '-'}`, 100, startY + 6);
    doc.text(`Class: ${student.className} (Roll# ${student.rollNo})`, 100, startY + 12);

    // Stats bar
    doc.setFillColor(26, 54, 93);
    doc.rect(14, startY + 22, 182, 9, 'F');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8);
    doc.setTextColor(255, 255, 255);
    doc.text(
      `Total Days: ${summary.total}   |   Present: ${summary.present}   |   Absent: ${summary.absent}   |   Leave: ${summary.leave}   |   Attendance: ${summary.percentage}%`,
      105,
      startY + 28,
      { align: 'center' }
    );

    // Days table
    const tableData = history.map((h, i) => {
      const d = new Date(h.date);
      const dayName = isNaN(d.getTime()) ? '-' : d.toLocaleDateString('en-US', { weekday: 'long' });
      return [
        i + 1,
        h.date,
        dayName,
        h.status === 'P' ? 'PRESENT' : h.status === 'A' ? 'ABSENT' : 'LEAVE'
      ];
    });

    doc.autoTable({
      startY: startY + 35,
      head: [['Sr#', 'Date', 'Day of Week', 'Status']],
      body: tableData,
      theme: 'grid',
      headStyles: {
        fillColor: [26, 54, 93],
        textColor: [255, 255, 255],
        fontStyle: 'bold',
        fontSize: 8.5,
        halign: 'center'
      },
      columnStyles: {
        0: { cellWidth: 15, halign: 'center' },
        1: { cellWidth: 45, halign: 'center' },
        2: { cellWidth: 60, halign: 'center' },
        3: { cellWidth: 62, halign: 'center', fontStyle: 'bold' }
      },
      styles: { fontSize: 8, cellPadding: 2.5 },
      didParseCell: function (data) {
        if (data.section === 'body' && data.column.index === 3) {
          if (data.cell.raw === 'PRESENT') data.cell.styles.textColor = [22, 101, 52];
          else if (data.cell.raw === 'ABSENT') data.cell.styles.textColor = [185, 28, 28];
          else data.cell.styles.textColor = [180, 83, 9];
        }
      },
      margin: { left: 14, right: 14, bottom: 25 }
    });

    this.addReportFooter(doc, settings, 1, 1);
    doc.save(`Attendance_${student.name.replace(/\s+/g, '_')}.pdf`);
  },

  // 4. All Classes Daily Attendance Report (ONE COMBINED PDF)
  async generateAllClassesDailyPDF(date, classGroups, settings) {
    const jsPDF = this.getJsPDF();
    const doc = new jsPDF('p', 'mm', 'a4');
    const totalPages = classGroups.length;

    classGroups.forEach((cg, idx) => {
      if (idx > 0) doc.addPage();

      const startY = this.addReportHeader(
        doc,
        `All Classes Daily Attendance - ${cg.className}`,
        `Date: ${date}  |  Class Section: ${cg.className} (Order ${idx + 1} of 7)`,
        settings
      );

      // Class Summary Box
      doc.setFillColor(241, 245, 249);
      doc.roundedRect(14, startY, 182, 13, 2, 2, 'F');
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(8.5);
      doc.setTextColor(30, 41, 59);

      const sY = startY + 8.5;
      doc.text(`Class: ${cg.className}`, 18, sY);
      doc.text(`Total: ${cg.summary.total}`, 60, sY);
      doc.setTextColor(22, 101, 52);
      doc.text(`Present: ${cg.summary.present}`, 95, sY);
      doc.setTextColor(185, 28, 28);
      doc.text(`Absent: ${cg.summary.absent}`, 130, sY);
      doc.setTextColor(26, 54, 93);
      doc.text(`Rate: ${cg.summary.percentage}%`, 175, sY, { align: 'right' });

      const tableData = cg.records.map((r, i) => [
        i + 1,
        r.rollNo || '-',
        r.studentName,
        r.fatherName,
        r.status === 'P' ? 'PRESENT' : r.status === 'A' ? 'ABSENT' : 'LEAVE'
      ]);

      doc.autoTable({
        startY: startY + 17,
        head: [['Sr#', 'Roll#', 'Student Name', 'Father Name', 'Status']],
        body: tableData.length > 0 ? tableData : [['-', '-', 'No students enrolled in this class', '-', '-']],
        theme: 'grid',
        headStyles: {
          fillColor: [26, 54, 93],
          textColor: [255, 255, 255],
          fontStyle: 'bold',
          fontSize: 8.5,
          halign: 'center'
        },
        columnStyles: {
          0: { cellWidth: 14, halign: 'center' },
          1: { cellWidth: 20, halign: 'center' },
          2: { cellWidth: 60 },
          3: { cellWidth: 58 },
          4: { cellWidth: 30, halign: 'center', fontStyle: 'bold' }
        },
        styles: { fontSize: 8, cellPadding: 2.5 },
        didParseCell: function (data) {
          if (data.section === 'body' && data.column.index === 4) {
            if (data.cell.raw === 'PRESENT') data.cell.styles.textColor = [22, 101, 52];
            else if (data.cell.raw === 'ABSENT') data.cell.styles.textColor = [185, 28, 28];
            else if (data.cell.raw === 'LEAVE') data.cell.styles.textColor = [180, 83, 9];
          }
        },
        margin: { left: 14, right: 14, bottom: 25 }
      });

      this.addReportFooter(doc, settings, idx + 1, totalPages);
    });

    doc.save(`All_Classes_Daily_Attendance_${date}.pdf`);
  },

  // 5. All Classes Monthly Attendance Report (ONE COMBINED PDF)
  async generateAllClassesMonthlyPDF(month, year, classGroups, settings) {
    const jsPDF = this.getJsPDF();
    const doc = new jsPDF('p', 'mm', 'a4');
    const totalPages = classGroups.length;

    classGroups.forEach((cg, idx) => {
      if (idx > 0) doc.addPage();

      const startY = this.addReportHeader(
        doc,
        `All Classes Monthly Attendance - ${cg.className}`,
        `Month: ${month} ${year}  |  Class ${idx + 1} of 7: ${cg.className}`,
        settings
      );

      // Class summary
      doc.setFillColor(241, 245, 249);
      doc.roundedRect(14, startY, 182, 12, 2, 2, 'F');
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(8.5);
      doc.setTextColor(30, 41, 59);
      const sY = startY + 8;
      doc.text(`Enrolled: ${cg.summary.totalStudents}`, 20, sY);
      doc.text(`Average Attendance: ${cg.summary.classAverage}%`, 70, sY);
      doc.text(`Total P: ${cg.summary.totalPresent}`, 125, sY);
      doc.text(`Total A: ${cg.summary.totalAbsent}`, 160, sY);

      const tableData = cg.dataList.map((d, i) => [
        i + 1,
        d.rollNo || '-',
        d.studentName,
        d.fatherName,
        d.totalDays,
        d.present,
        d.absent,
        d.leave,
        `${d.percentage}%`
      ]);

      doc.autoTable({
        startY: startY + 16,
        head: [['Sr#', 'Roll#', 'Student Name', 'Father Name', 'Days', 'P', 'A', 'L', '%']],
        body: tableData.length > 0 ? tableData : [['-', '-', 'No students enrolled in this class', '-', '-', '-', '-', '-', '-']],
        theme: 'grid',
        headStyles: {
          fillColor: [26, 54, 93],
          textColor: [255, 255, 255],
          fontStyle: 'bold',
          fontSize: 8,
          halign: 'center'
        },
        columnStyles: {
          0: { cellWidth: 10, halign: 'center' },
          1: { cellWidth: 16, halign: 'center' },
          2: { cellWidth: 46 },
          3: { cellWidth: 46 },
          4: { cellWidth: 14, halign: 'center' },
          5: { cellWidth: 12, halign: 'center', textColor: [22, 101, 52] },
          6: { cellWidth: 12, halign: 'center', textColor: [185, 28, 28] },
          7: { cellWidth: 12, halign: 'center', textColor: [180, 83, 9] },
          8: { cellWidth: 14, halign: 'center', fontStyle: 'bold' }
        },
        styles: { fontSize: 8, cellPadding: 2 },
        margin: { left: 14, right: 14, bottom: 25 }
      });

      this.addReportFooter(doc, settings, idx + 1, totalPages);
    });

    doc.save(`All_Classes_Monthly_Attendance_${month}_${year}.pdf`);
  },

  // 6. Professional Result Card PDF (with Photo on LEFT, BOLD + UNDERLINED names, Marks table)
  async generateResultCardPDF(result, student, settings, signatureImg) {
    const jsPDF = this.getJsPDF();
    const doc = new jsPDF('p', 'mm', 'a4');

    const sName = settings?.schoolName || 'GOVERNMENT BOYS PRIMARY SCHOOL SULTAN MATT UCHARI';
    const sEmis = settings?.emis || '06994';
    const sLoc = settings?.location || 'District Barkhan, Balochistan, Pakistan';
    const ht = settings?.headTeacher || 'SHOUKAT ALI';

    // Outer Decorative Border
    doc.setDrawColor(26, 54, 93);
    doc.setLineWidth(1.5);
    doc.rect(8, 8, 194, 281);
    doc.setDrawColor(212, 175, 55);
    doc.setLineWidth(0.6);
    doc.rect(10, 10, 190, 277);

    // School Header
    doc.setFillColor(26, 54, 93);
    doc.rect(10, 10, 190, 26, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(13);
    doc.text(sName, 105, 19, { align: 'center' });

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8.5);
    doc.text(`EMIS: ${sEmis}   |   ${sLoc}`, 105, 26, { align: 'center' });

    // Result Card Title Banner
    doc.setFillColor(212, 175, 55);
    doc.rect(10, 36, 190, 8, 'F');
    doc.setTextColor(26, 54, 93);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.text('OFFICIAL ACADEMIC RESULT CARD', 105, 42, { align: 'center' });

    // Student Info Section
    // STUDENT PHOTO ON LEFT SIDE
    const photoX = 16;
    const photoY = 48;
    const photoW = 28;
    const photoH = 34;

    doc.setDrawColor(203, 213, 225);
    doc.setLineWidth(0.5);
    doc.rect(photoX, photoY, photoW, photoH);

    let photoRendered = false;
    if (student?.photo) {
      photoRendered = this.addImageSafe(doc, student.photo, photoX + 0.5, photoY + 0.5, photoW - 1, photoH - 1);
    }
    if (!photoRendered) {
      doc.setFillColor(241, 245, 249);
      doc.rect(photoX + 0.5, photoY + 0.5, photoW - 1, photoH - 1, 'F');
      doc.setFontSize(7.5);
      doc.setTextColor(148, 163, 184);
      doc.text('STUDENT', photoX + photoW / 2, photoY + 15, { align: 'center' });
      doc.text('PHOTO', photoX + photoW / 2, photoY + 20, { align: 'center' });
    }

    // Student Details
    const infoX = 50;
    let currY = 53;

    // Student Name (BOLD + UNDERLINED as requested)
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10);
    doc.setTextColor(71, 85, 105);
    doc.text('Student Name:', infoX, currY);

    doc.setTextColor(15, 23, 42);
    doc.setFont('helvetica', 'bold');
    const sNameStr = (student?.name || result.studentName || '').toUpperCase();
    doc.text(sNameStr, infoX + 30, currY);
    // Draw underline
    const sWidth = doc.getTextWidth(sNameStr);
    doc.setDrawColor(15, 23, 42);
    doc.setLineWidth(0.6);
    doc.line(infoX + 30, currY + 1, infoX + 30 + sWidth, currY + 1);

    currY += 8;
    // Father Name (BOLD + UNDERLINED as requested)
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(71, 85, 105);
    doc.text('Father Name:', infoX, currY);

    doc.setTextColor(15, 23, 42);
    doc.setFont('helvetica', 'bold');
    const fNameStr = (student?.fatherName || result.fatherName || '').toUpperCase();
    doc.text(fNameStr, infoX + 30, currY);
    const fWidth = doc.getTextWidth(fNameStr);
    doc.line(infoX + 30, currY + 1, infoX + 30 + fWidth, currY + 1);

    currY += 8;
    // Class and Roll No
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9);
    doc.setTextColor(71, 85, 105);
    doc.text('Class:', infoX, currY);
    doc.setTextColor(15, 23, 42);
    doc.setFont('helvetica', 'bold');
    doc.text(result.className, infoX + 30, currY);

    doc.setFont('helvetica', 'normal');
    doc.setTextColor(71, 85, 105);
    doc.text('Roll Number:', infoX + 80, currY);
    doc.setTextColor(15, 23, 42);
    doc.setFont('helvetica', 'bold');
    doc.text(result.rollNo || '-', infoX + 105, currY);

    currY += 7;
    // Exam and Academic Year
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(71, 85, 105);
    doc.text('Examination:', infoX, currY);
    doc.setTextColor(15, 23, 42);
    doc.setFont('helvetica', 'bold');
    doc.text(result.examName, infoX + 30, currY);

    doc.setFont('helvetica', 'normal');
    doc.setTextColor(71, 85, 105);
    doc.text('Academic Year:', infoX + 80, currY);
    doc.setTextColor(15, 23, 42);
    doc.setFont('helvetica', 'bold');
    doc.text(result.academicYear || settings?.academicYear || '2026-2027', infoX + 105, currY);

    // Subject Marks Table
    const tableData = (result.subjects || []).map((sub, i) => [
      i + 1,
      sub.subjectName,
      sub.totalMarks,
      sub.obtainedMarks,
      sub.grade || '-',
      sub.obtainedMarks >= sub.totalMarks * 0.4 ? 'Pass' : 'Fail'
    ]);

    doc.autoTable({
      startY: 88,
      head: [['Sr#', 'Subject Name', 'Total Marks', 'Obtained Marks', 'Grade', 'Remarks']],
      body: tableData,
      theme: 'grid',
      headStyles: {
        fillColor: [26, 54, 93],
        textColor: [255, 255, 255],
        fontStyle: 'bold',
        fontSize: 9,
        halign: 'center'
      },
      columnStyles: {
        0: { cellWidth: 14, halign: 'center' },
        1: { cellWidth: 64 },
        2: { cellWidth: 26, halign: 'center' },
        3: { cellWidth: 28, halign: 'center', fontStyle: 'bold' },
        4: { cellWidth: 24, halign: 'center' },
        5: { cellWidth: 26, halign: 'center', fontStyle: 'bold' }
      },
      styles: { fontSize: 8.5, cellPadding: 3 },
      didParseCell: function (data) {
        if (data.section === 'body' && data.column.index === 5) {
          if (data.cell.raw === 'Pass') data.cell.styles.textColor = [22, 101, 52];
          else data.cell.styles.textColor = [185, 28, 28];
        }
      },
      margin: { left: 14, right: 14 }
    });

    const finalY = doc.lastAutoTable.finalY + 6;

    // Summary Card Box
    doc.setFillColor(248, 250, 252);
    doc.setDrawColor(203, 213, 225);
    doc.setLineWidth(0.5);
    doc.roundedRect(14, finalY, 182, 28, 2, 2, 'FD');

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9);
    doc.setTextColor(26, 54, 93);
    doc.text('TOTAL MARKS', 30, finalY + 8, { align: 'center' });
    doc.text('OBTAINED MARKS', 72, finalY + 8, { align: 'center' });
    doc.text('PERCENTAGE', 115, finalY + 8, { align: 'center' });
    doc.text('GRADE', 150, finalY + 8, { align: 'center' });
    doc.text('RESULT', 178, finalY + 8, { align: 'center' });

    doc.setFontSize(13);
    doc.setTextColor(15, 23, 42);
    doc.text(String(result.totalMarks), 30, finalY + 18, { align: 'center' });
    doc.text(String(result.totalObtained), 72, finalY + 18, { align: 'center' });
    doc.text(`${result.percentage}%`, 115, finalY + 18, { align: 'center' });
    doc.text(result.grade, 150, finalY + 18, { align: 'center' });

    if (result.status === 'Pass') {
      doc.setTextColor(22, 101, 52);
      doc.text('PASS', 178, finalY + 18, { align: 'center' });
    } else {
      doc.setTextColor(185, 28, 28);
      doc.text('FAIL', 178, finalY + 18, { align: 'center' });
    }

    // Grading Scale Note
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7);
    doc.setTextColor(100, 116, 139);
    doc.text('Grading Scale: A+ (>=80%) | A (>=70%) | B (>=60%) | C (>=50%) | D (>=40%) | F (Below 40%)', 105, finalY + 25, { align: 'center' });

    // Official Footer & Signatures
    const footY = 245;

    // School Seal circle
    doc.setDrawColor(212, 175, 55);
    doc.setLineWidth(1);
    doc.circle(40, footY + 12, 14);
    doc.setFontSize(6.5);
    doc.setTextColor(26, 54, 93);
    doc.setFont('helvetica', 'bold');
    doc.text('OFFICIAL SEAL', 40, footY + 11, { align: 'center' });
    doc.text('EMIS 06994', 40, footY + 15, { align: 'center' });

    // Head Teacher Signature
    if (signatureImg) {
      this.addImageSafe(doc, signatureImg, 140, footY - 2, 45, 16);
    } else {
      doc.setDrawColor(100, 116, 139);
      doc.setLineWidth(0.5);
      doc.line(135, footY + 12, 185, footY + 12);
    }

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9.5);
    doc.setTextColor(26, 54, 93);
    doc.text('HEAD TEACHER', 160, footY + 17, { align: 'center' });
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8.5);
    doc.text(ht, 160, footY + 22, { align: 'center' });

    // Date
    const todayStr = new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'long', year: 'numeric' });
    doc.setFontSize(8);
    doc.setTextColor(100, 116, 139);
    doc.text(`Date of Issue: ${todayStr}`, 14, 275);

    doc.save(`Result_Card_${result.studentName.replace(/\s+/g, '_')}_${result.className}.pdf`);
  },

  // 7. All Classes Result Report PDF (ONE COMBINED PDF)
  async generateAllClassesResultPDF(examName, academicYear, classReports, settings) {
    const jsPDF = this.getJsPDF();
    const doc = new jsPDF('p', 'mm', 'a4');
    const totalPages = classReports.length;

    classReports.forEach((cr, idx) => {
      if (idx > 0) doc.addPage();

      const startY = this.addReportHeader(
        doc,
        `All Classes Result Report - ${cr.className}`,
        `Exam: ${examName}  |  Academic Year: ${academicYear}  |  Class ${idx + 1} of 7: ${cr.className}`,
        settings
      );

      // Class Summary
      doc.setFillColor(241, 245, 249);
      doc.roundedRect(14, startY, 182, 14, 2, 2, 'F');
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(8.5);
      doc.setTextColor(30, 41, 59);

      const sY = startY + 9;
      doc.text(`Total: ${cr.summary.total}`, 20, sY);
      doc.setTextColor(22, 101, 52);
      doc.text(`Passed: ${cr.summary.passed}`, 55, sY);
      doc.setTextColor(185, 28, 28);
      doc.text(`Failed: ${cr.summary.failed}`, 90, sY);
      doc.setTextColor(26, 54, 93);
      doc.text(`Average: ${cr.summary.average}%`, 125, sY);
      doc.text(`Highest: ${cr.summary.highest}`, 165, sY);

      const tableData = cr.results.map((r, i) => [
        i + 1,
        r.rollNo || '-',
        r.studentName,
        r.fatherName,
        r.totalMarks,
        r.totalObtained,
        `${r.percentage}%`,
        r.grade,
        r.status
      ]);

      doc.autoTable({
        startY: startY + 18,
        head: [['Sr#', 'Roll#', 'Student Name', 'Father Name', 'Total', 'Obt', '%', 'Grade', 'Status']],
        body: tableData.length > 0 ? tableData : [['-', '-', 'No exam records logged for this class', '-', '-', '-', '-', '-', '-']],
        theme: 'grid',
        headStyles: {
          fillColor: [26, 54, 93],
          textColor: [255, 255, 255],
          fontStyle: 'bold',
          fontSize: 8.5,
          halign: 'center'
        },
        columnStyles: {
          0: { cellWidth: 10, halign: 'center' },
          1: { cellWidth: 16, halign: 'center' },
          2: { cellWidth: 46 },
          3: { cellWidth: 44 },
          4: { cellWidth: 14, halign: 'center' },
          5: { cellWidth: 14, halign: 'center', fontStyle: 'bold' },
          6: { cellWidth: 14, halign: 'center' },
          7: { cellWidth: 12, halign: 'center', fontStyle: 'bold' },
          8: { cellWidth: 12, halign: 'center', fontStyle: 'bold' }
        },
        styles: { fontSize: 8, cellPadding: 2.5 },
        didParseCell: function (data) {
          if (data.section === 'body' && data.column.index === 8) {
            if (data.cell.raw === 'Pass') data.cell.styles.textColor = [22, 101, 52];
            else if (data.cell.raw === 'Fail') data.cell.styles.textColor = [185, 28, 28];
          }
        },
        margin: { left: 14, right: 14, bottom: 25 }
      });

      this.addReportFooter(doc, settings, idx + 1, totalPages);
    });

    doc.save(`All_Classes_Result_Report_${examName.replace(/\s+/g, '_')}.pdf`);
  },

  // 8. Fee Receipt PDF
  async generateFeeReceiptPDF(fee, settings, signatureImg) {
    const jsPDF = this.getJsPDF();
    const doc = new jsPDF('p', 'mm', 'a5'); // Standard receipt format

    const sName = settings?.schoolName || 'GOVERNMENT BOYS PRIMARY SCHOOL SULTAN MATT UCHARI';
    const sEmis = settings?.emis || '06994';
    const sLoc = settings?.location || 'District Barkhan, Balochistan';
    const ht = settings?.headTeacher || 'SHOUKAT ALI';

    // Outer border
    doc.setDrawColor(26, 54, 93);
    doc.setLineWidth(1);
    doc.rect(6, 6, 136, 198);

    // Header
    doc.setFillColor(26, 54, 93);
    doc.rect(6, 6, 136, 20, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9.5);
    doc.text(sName, 74, 13, { align: 'center' });
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7.5);
    doc.text(`EMIS: ${sEmis}   |   ${sLoc}`, 74, 18, { align: 'center' });

    // Banner
    doc.setFillColor(212, 175, 55);
    doc.rect(6, 26, 136, 6.5, 'F');
    doc.setTextColor(26, 54, 93);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9);
    doc.text('OFFICIAL FEE PAYMENT RECEIPT', 74, 30.5, { align: 'center' });

    // Receipt Meta
    let y = 40;
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8);
    doc.setTextColor(71, 85, 105);
    doc.text('Receipt No:', 12, y);
    doc.setTextColor(15, 23, 42);
    doc.text(fee.receiptNo || 'REC-' + fee.id, 35, y);

    doc.setTextColor(71, 85, 105);
    doc.text('Date:', 90, y);
    doc.setTextColor(15, 23, 42);
    doc.text(fee.paymentDate || new Date().toISOString().split('T')[0], 102, y);

    y += 7;
    doc.setTextColor(71, 85, 105);
    doc.text('Student Name:', 12, y);
    doc.setTextColor(15, 23, 42);
    doc.text((fee.studentName || '').toUpperCase(), 35, y);

    doc.setTextColor(71, 85, 105);
    doc.text('Roll#:', 90, y);
    doc.setTextColor(15, 23, 42);
    doc.text(fee.rollNo || '-', 102, y);

    y += 7;
    doc.setTextColor(71, 85, 105);
    doc.text('Father Name:', 12, y);
    doc.setTextColor(15, 23, 42);
    doc.text((fee.fatherName || '').toUpperCase(), 35, y);

    doc.setTextColor(71, 85, 105);
    doc.text('Class:', 90, y);
    doc.setTextColor(15, 23, 42);
    doc.text(fee.className, 102, y);

    y += 7;
    doc.setTextColor(71, 85, 105);
    doc.text('Fee Type:', 12, y);
    doc.setTextColor(15, 23, 42);
    doc.text(fee.feeType, 35, y);

    doc.setTextColor(71, 85, 105);
    doc.text('Period:', 90, y);
    doc.setTextColor(15, 23, 42);
    doc.text(`${fee.month || ''} ${fee.year || ''}`, 102, y);

    // Fee breakdown table
    doc.autoTable({
      startY: y + 5,
      head: [['Description', 'Amount (PKR)']],
      body: [
        ['Total Required Fee Amount', `Rs. ${Number(fee.requiredAmount).toLocaleString()}`],
        ['Amount Paid by Parent/Guardian', `Rs. ${Number(fee.paidAmount).toLocaleString()}`],
        ['Remaining / Balance Due', `Rs. ${Number(fee.remainingAmount).toLocaleString()}`]
      ],
      theme: 'grid',
      headStyles: { fillColor: [26, 54, 93], textColor: [255, 255, 255], fontStyle: 'bold', fontSize: 8 },
      columnStyles: {
        0: { cellWidth: 80 },
        1: { cellWidth: 46, halign: 'right', fontStyle: 'bold' }
      },
      styles: { fontSize: 8, cellPadding: 2.5 },
      margin: { left: 11, right: 11 }
    });

    const afterTableY = doc.lastAutoTable.finalY + 6;

    // Status Badge
    doc.setFillColor(fee.status === 'PAID' ? 220 : fee.status === 'PARTIAL' ? 254 : 254, fee.status === 'PAID' ? 252 : fee.status === 'PARTIAL' ? 243 : 226, fee.status === 'PAID' ? 231 : fee.status === 'PARTIAL' ? 199 : 226);
    doc.roundedRect(12, afterTableY, 40, 9, 2, 2, 'F');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8.5);
    doc.setTextColor(fee.status === 'PAID' ? 22 : fee.status === 'PARTIAL' ? 180 : 185, fee.status === 'PAID' ? 101 : fee.status === 'PARTIAL' ? 83 : 28, fee.status === 'PAID' ? 52 : fee.status === 'PARTIAL' ? 9 : 28);
    doc.text(`STATUS: ${fee.status}`, 32, afterTableY + 6, { align: 'center' });

    if (fee.notes) {
      doc.setFont('helvetica', 'italic');
      doc.setFontSize(7.5);
      doc.setTextColor(100, 116, 139);
      doc.text(`Note: ${fee.notes}`, 56, afterTableY + 6);
    }

    // Signatures
    const sigY = 172;
    if (signatureImg) {
      this.addImageSafe(doc, signatureImg, 90, sigY - 10, 36, 12);
    } else {
      doc.setDrawColor(100, 116, 139);
      doc.setLineWidth(0.5);
      doc.line(90, sigY, 130, sigY);
    }

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7.5);
    doc.setTextColor(26, 54, 93);
    doc.text('AUTHORIZED SIGNATURE', 110, sigY + 4, { align: 'center' });
    doc.setFont('helvetica', 'normal');
    doc.text(ht, 110, sigY + 8, { align: 'center' });

    doc.text('Cashier / School Stamp', 30, sigY + 4, { align: 'center' });

    doc.save(`Fee_Receipt_${fee.receiptNo || fee.id}_${fee.studentName}.pdf`);
  },

  // 9. Class-wise Fee Report PDF
  async generateClassFeeReportPDF(className, month, year, dataList, summary, settings) {
    const jsPDF = this.getJsPDF();
    const doc = new jsPDF('p', 'mm', 'a4');

    const startY = this.addReportHeader(
      doc,
      `Class-wise Fee Collection Report - ${className}`,
      `Period: ${month} ${year}  |  Class: ${className}`,
      settings
    );

    // Summary Box
    doc.setFillColor(241, 245, 249);
    doc.roundedRect(14, startY, 182, 14, 2, 2, 'F');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8);
    doc.setTextColor(30, 41, 59);

    const sY = startY + 9;
    doc.text(`Total: ${summary.totalStudents}`, 18, sY);
    doc.setTextColor(22, 101, 52);
    doc.text(`Paid: ${summary.paidStudents}`, 45, sY);
    doc.setTextColor(180, 83, 9);
    doc.text(`Partial: ${summary.partialStudents}`, 70, sY);
    doc.setTextColor(185, 28, 28);
    doc.text(`Unpaid: ${summary.unpaidStudents}`, 98, sY);
    doc.setTextColor(26, 54, 93);
    doc.text(`Expected: Rs.${summary.totalExpected.toLocaleString()}`, 130, sY);
    doc.text(`Collected: Rs.${summary.totalCollected.toLocaleString()}`, 170, sY, { align: 'right' });

    const tableData = dataList.map((d, i) => [
      i + 1,
      d.rollNo || '-',
      d.studentName,
      d.fatherName,
      `Rs. ${Number(d.requiredAmount).toLocaleString()}`,
      `Rs. ${Number(d.paidAmount).toLocaleString()}`,
      `Rs. ${Number(d.remainingAmount).toLocaleString()}`,
      d.status
    ]);

    doc.autoTable({
      startY: startY + 18,
      head: [['Sr#', 'Roll#', 'Student Name', 'Father Name', 'Required', 'Paid', 'Remaining', 'Status']],
      body: tableData.length > 0 ? tableData : [['-', '-', 'No fee records found for this period', '-', '-', '-', '-', '-']],
      theme: 'grid',
      headStyles: {
        fillColor: [26, 54, 93],
        textColor: [255, 255, 255],
        fontStyle: 'bold',
        fontSize: 8.5,
        halign: 'center'
      },
      columnStyles: {
        0: { cellWidth: 10, halign: 'center' },
        1: { cellWidth: 16, halign: 'center' },
        2: { cellWidth: 46 },
        3: { cellWidth: 44 },
        4: { cellWidth: 18, halign: 'right' },
        5: { cellWidth: 18, halign: 'right' },
        6: { cellWidth: 18, halign: 'right' },
        7: { cellWidth: 16, halign: 'center', fontStyle: 'bold' }
      },
      styles: { fontSize: 8, cellPadding: 2.5 },
      didParseCell: function (data) {
        if (data.section === 'body' && data.column.index === 7) {
          if (data.cell.raw === 'PAID') data.cell.styles.textColor = [22, 101, 52];
          else if (data.cell.raw === 'PARTIAL') data.cell.styles.textColor = [180, 83, 9];
          else if (data.cell.raw === 'UNPAID') data.cell.styles.textColor = [185, 28, 28];
        }
      },
      margin: { left: 14, right: 14, bottom: 25 }
    });

    this.addReportFooter(doc, settings, 1, 1);
    doc.save(`Fee_Report_${className.replace(/\s+/g, '_')}_${month}_${year}.pdf`);
  },

  // 10. Student ID Card (TWO-SIDED: FRONT AND BACK SIDE)
  async generateStudentIDCardPDF(student, settings, signatureImg) {
    const jsPDF = this.getJsPDF();
    const doc = new jsPDF('p', 'mm', 'a4');

    const sName = settings?.schoolName || 'GOVERNMENT BOYS PRIMARY SCHOOL SULTAN MATT UCHARI';
    const sEmis = settings?.emis || '06994';
    const sLoc = settings?.location || 'District Barkhan, Balochistan, Pakistan';
    const ht = settings?.headTeacher || 'SHOUKAT ALI';
    const phone = settings?.contactPhone || '0829-XXXXXX';

    // Card dimensions: 86mm x 54mm (standard CR80 ID Card size)
    const cardW = 86;
    const cardH = 54;

    // --- FRONT SIDE ---
    const fX = 18;
    const fY = 30;

    // Card background & border
    doc.setFillColor(255, 255, 255);
    doc.roundedRect(fX, fY, cardW, cardH, 3, 3, 'FD');
    doc.setDrawColor(26, 54, 93);
    doc.setLineWidth(0.8);
    doc.roundedRect(fX, fY, cardW, cardH, 3, 3, 'S');

    // Header strip
    doc.setFillColor(26, 54, 93);
    doc.roundedRect(fX, fY, cardW, 14, 3, 3, 'F');
    doc.rect(fX, fY + 11, cardW, 3, 'F'); // square bottom of header

    doc.setTextColor(255, 255, 255);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(6.2);
    doc.text(sName, fX + cardW / 2, fY + 5, { align: 'center' });
    doc.setFontSize(5.2);
    doc.setFont('helvetica', 'normal');
    doc.text(`EMIS: ${sEmis}  |  ${sLoc}`, fX + cardW / 2, fY + 9, { align: 'center' });
    doc.setTextColor(212, 175, 55);
    doc.setFont('helvetica', 'bold');
    doc.text('STUDENT IDENTITY CARD', fX + cardW / 2, fY + 13, { align: 'center' });

    // Photo on Front
    const pX = fX + 4;
    const pY = fY + 17;
    const pW = 20;
    const pH = 25;
    doc.setDrawColor(203, 213, 225);
    doc.setLineWidth(0.5);
    doc.rect(pX, pY, pW, pH);

    let photoAdded = false;
    if (student.photo) {
      photoAdded = this.addImageSafe(doc, student.photo, pX + 0.5, pY + 0.5, pW - 1, pH - 1);
    }
    if (!photoAdded) {
      doc.setFillColor(241, 245, 249);
      doc.rect(pX + 0.5, pY + 0.5, pW - 1, pH - 1, 'F');
      doc.setFontSize(5);
      doc.setTextColor(148, 163, 184);
      doc.text('PHOTO', pX + pW / 2, pY + 13, { align: 'center' });
    }

    // Student ID Tag below photo
    doc.setFillColor(26, 54, 93);
    doc.rect(pX, pY + pH + 1, pW, 5, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(4.8);
    doc.setFont('helvetica', 'bold');
    doc.text(`ID: #${student.id}`, pX + pW / 2, pY + pH + 4.2, { align: 'center' });

    // Details on Right of photo
    const dX = fX + 27;
    let dY = fY + 19;
    doc.setFontSize(5.5);

    function printField(label, value) {
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(71, 85, 105);
      doc.text(label, dX, dY);
      doc.setTextColor(15, 23, 42);
      doc.text(String(value || '-'), dX + 18, dY);
      dY += 4.6;
    }

    printField('Name:', student.name.toUpperCase());
    printField('Father:', student.fatherName.toUpperCase());
    printField('Class:', student.className);
    printField('Roll No:', student.rollNo);
    printField('Adm No:', student.admissionNo || '-');
    printField('Session:', settings?.academicYear || '2026-2027');

    // Label Front
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9);
    doc.setTextColor(26, 54, 93);
    doc.text('FRONT SIDE', fX + cardW / 2, fY - 3, { align: 'center' });

    // --- BACK SIDE ---
    const bX = 110;
    const bY = 30;

    doc.setFillColor(255, 255, 255);
    doc.roundedRect(bX, bY, cardW, cardH, 3, 3, 'FD');
    doc.setDrawColor(26, 54, 93);
    doc.setLineWidth(0.8);
    doc.roundedRect(bX, bY, cardW, cardH, 3, 3, 'S');

    // Back Header
    doc.setFillColor(26, 54, 93);
    doc.roundedRect(bX, bY, cardW, 8, 3, 3, 'F');
    doc.rect(bX, bY + 5, cardW, 3, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(6.5);
    doc.text('SCHOOL INFORMATION & RULES', bX + cardW / 2, bY + 5.5, { align: 'center' });

    let bContentY = bY + 13;
    doc.setFontSize(5.2);
    doc.setTextColor(71, 85, 105);
    doc.setFont('helvetica', 'bold');
    doc.text('Student Address:', bX + 4, bContentY);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(15, 23, 42);
    doc.text(student.address || 'Village Sultan Matt Uchari, Barkhan', bX + 4, bContentY + 4, { maxWidth: cardW - 8 });

    bContentY += 9;
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(71, 85, 105);
    doc.text('Emergency Contact:', bX + 4, bContentY);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(15, 23, 42);
    doc.text(student.parentContact || phone, bX + 27, bContentY);

    bContentY += 5;
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(71, 85, 105);
    doc.text('Instructions:', bX + 4, bContentY);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(4.6);
    doc.setTextColor(100, 116, 139);
    doc.text('1. This card must be carried by student at all times.', bX + 4, bContentY + 3.5);
    doc.text('2. If found, please return to GBPS Sultan Matt Uchari.', bX + 4, bContentY + 6.8);
    doc.text('3. Non-transferable property of Balochistan Education Dept.', bX + 4, bContentY + 10.1);

    // Signature on Back
    const backSigY = bY + cardH - 12;
    if (signatureImg) {
      this.addImageSafe(doc, signatureImg, bX + cardW - 32, backSigY - 4, 28, 8);
    } else {
      doc.setDrawColor(100, 116, 139);
      doc.setLineWidth(0.4);
      doc.line(bX + cardW - 32, backSigY + 4, bX + cardW - 6, backSigY + 4);
    }

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(5.5);
    doc.setTextColor(26, 54, 93);
    doc.text('HEAD TEACHER', bX + cardW - 19, backSigY + 6.5, { align: 'center' });
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(4.8);
    doc.text(ht, bX + cardW - 19, backSigY + 9.5, { align: 'center' });

    // Label Back
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9);
    doc.setTextColor(26, 54, 93);
    doc.text('BACK SIDE', bX + cardW / 2, bY - 3, { align: 'center' });

    // Cut & Fold guides note
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(148, 163, 184);
    doc.text('Print on A4 or Heavy Cardstock. Cut along outer border and laminate.', 105, 95, { align: 'center' });

    doc.save(`ID_Card_${student.name.replace(/\s+/g, '_')}.pdf`);
  },

  // 11. School Leaving Certificate (SLC) PDF (with Gender Awareness)
  async generateLeavingCertificatePDF(student, reason, conduct, leavingDate, settings, signatureImg) {
    const jsPDF = this.getJsPDF();
    const doc = new jsPDF('p', 'mm', 'a4');

    const sName = settings?.schoolName || 'GOVERNMENT BOYS PRIMARY SCHOOL SULTAN MATT UCHARI';
    const sEmis = settings?.emis || '06994';
    const sLoc = settings?.location || 'District Barkhan, Balochistan, Pakistan';
    const ht = settings?.headTeacher || 'SHOUKAT ALI';

    // Gender terms
    const isMale = (student.gender || 'Male').toLowerCase() === 'male';
    const title = isMale ? 'Mr.' : 'Miss.';
    const heShe = isMale ? 'He' : 'She';
    const hisHer = isMale ? 'His' : 'Her';
    const soDo = isMale ? 'S/O' : 'D/O';

    // Decorative Borders
    doc.setDrawColor(26, 54, 93);
    doc.setLineWidth(2);
    doc.rect(10, 10, 190, 277);
    doc.setDrawColor(212, 175, 55);
    doc.setLineWidth(0.8);
    doc.rect(13, 13, 184, 271);

    // School Header
    doc.setFillColor(26, 54, 93);
    doc.rect(13, 13, 184, 28, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(14);
    doc.text(sName, 105, 24, { align: 'center' });
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9);
    doc.text(`EMIS CODE: ${sEmis}   |   ${sLoc}`, 105, 32, { align: 'center' });

    // Certificate Title
    doc.setFillColor(212, 175, 55);
    doc.rect(13, 41, 184, 10, 'F');
    doc.setTextColor(26, 54, 93);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(13);
    doc.text('SCHOOL LEAVING CERTIFICATE', 105, 48, { align: 'center' });

    // Certificate No & Date
    doc.setFontSize(9);
    doc.setTextColor(71, 85, 105);
    doc.text(`SLC No: SLC-06994-${student.id}`, 20, 60);
    const issueDate = new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'long', year: 'numeric' });
    doc.text(`Date of Issue: ${issueDate}`, 190, 60, { align: 'right' });

    // Certificate Body
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(11);
    doc.setTextColor(30, 41, 59);

    const bodyY = 78;
    const lineHeight = 11;

    const certText = `This is to certify that ${title} ${student.name.toUpperCase()} ${soDo} ${student.fatherName.toUpperCase()}, bearing Admission No. ${student.admissionNo || '06994-' + student.id} and Roll No. ${student.rollNo}, was a regular student of this institution in ${student.className}.`;

    const splitText1 = doc.splitTextToSize(certText, 170);
    doc.text(splitText1, 20, bodyY);

    const nextY = bodyY + (splitText1.length * lineHeight);

    const details = [
      `Date of Birth according to School Record: ${student.dob || 'As per official B-Form'}`,
      `Date of Leaving the School: ${leavingDate || issueDate}`,
      `Reason for Leaving Institution: ${reason || 'On parent request / Relocation'}`,
      `General Conduct & Behavior: ${conduct || 'Satisfactory and obedient'}`,
      `${heShe} has paid all school dues up to the date of leaving.`,
      `To the best of our knowledge and school records, ${hisHer.toLowerCase()} character has been GOOD.`
    ];

    let itemY = nextY + 6;
    details.forEach(line => {
      doc.text(`•  ${line}`, 24, itemY);
      itemY += 9;
    });

    const closing = `We wish ${isMale ? 'him' : 'her'} every success in ${hisHer.toLowerCase()} future academic endeavors.`;
    doc.setFont('helvetica', 'bold');
    doc.text(closing, 20, itemY + 8);

    // Signatures
    const sigY = 230;
    doc.setDrawColor(212, 175, 55);
    doc.setLineWidth(1);
    doc.circle(45, sigY + 10, 15);
    doc.setFontSize(7);
    doc.setTextColor(26, 54, 93);
    doc.text('OFFICIAL SCHOOL SEAL', 45, sigY + 9, { align: 'center' });
    doc.text('GOVT BOYS PRIMARY', 45, sigY + 13, { align: 'center' });

    if (signatureImg) {
      this.addImageSafe(doc, signatureImg, 135, sigY - 6, 45, 16);
    } else {
      doc.setDrawColor(100, 116, 139);
      doc.setLineWidth(0.5);
      doc.line(135, sigY + 10, 185, sigY + 10);
    }

    doc.setFontSize(10);
    doc.setTextColor(26, 54, 93);
    doc.text('HEAD TEACHER', 160, sigY + 15, { align: 'center' });
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9);
    doc.text(ht, 160, sigY + 20, { align: 'center' });
    doc.setFontSize(7.5);
    doc.setTextColor(100, 116, 139);
    doc.text('Govt Boys Primary School Sultan Matt Uchari', 160, sigY + 24, { align: 'center' });

    doc.save(`Leaving_Certificate_${student.name.replace(/\s+/g, '_')}.pdf`);
  },

  // 12. Character Certificate PDF (with Gender Awareness)
  async generateCharacterCertificatePDF(student, settings, signatureImg) {
    const jsPDF = this.getJsPDF();
    const doc = new jsPDF('p', 'mm', 'a4');

    const sName = settings?.schoolName || 'GOVERNMENT BOYS PRIMARY SCHOOL SULTAN MATT UCHARI';
    const sEmis = settings?.emis || '06994';
    const sLoc = settings?.location || 'District Barkhan, Balochistan, Pakistan';
    const ht = settings?.headTeacher || 'SHOUKAT ALI';

    const isMale = (student.gender || 'Male').toLowerCase() === 'male';
    const title = isMale ? 'Mr.' : 'Miss.';
    const heShe = isMale ? 'He' : 'She';
    const hisHer = isMale ? 'His' : 'Her';
    const soDo = isMale ? 'S/O' : 'D/O';

    // Outer Decorative Border
    doc.setDrawColor(15, 81, 50); // Emerald green for character
    doc.setLineWidth(2);
    doc.rect(10, 10, 190, 277);
    doc.setDrawColor(212, 175, 55);
    doc.setLineWidth(0.8);
    doc.rect(13, 13, 184, 271);

    // Header
    doc.setFillColor(15, 81, 50);
    doc.rect(13, 13, 184, 28, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(14);
    doc.text(sName, 105, 24, { align: 'center' });
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9);
    doc.text(`EMIS CODE: ${sEmis}   |   ${sLoc}`, 105, 32, { align: 'center' });

    // Banner
    doc.setFillColor(212, 175, 55);
    doc.rect(13, 41, 184, 10, 'F');
    doc.setTextColor(15, 81, 50);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(13);
    doc.text('CHARACTER CERTIFICATE', 105, 48, { align: 'center' });

    doc.setFontSize(9);
    doc.setTextColor(71, 85, 105);
    doc.text(`Ref No: CC-06994-${student.id}`, 20, 60);
    const issueDate = new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'long', year: 'numeric' });
    doc.text(`Date of Issue: ${issueDate}`, 190, 60, { align: 'right' });

    // Text
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(11);
    doc.setTextColor(30, 41, 59);

    let currY = 82;
    const p1 = `This is to certify that ${title} ${student.name.toUpperCase()} ${soDo} ${student.fatherName.toUpperCase()} has been a bona fide student of this school in ${student.className}, holding Roll No. ${student.rollNo} and Admission No. ${student.admissionNo || '06994-' + student.id}.`;

    const splitP1 = doc.splitTextToSize(p1, 170);
    doc.text(splitP1, 20, currY);

    currY += (splitP1.length * 9) + 8;
    const p2 = `During ${hisHer.toLowerCase()} period of stay in this institution, ${hisHer.toLowerCase()} conduct and behavior have been found thoroughly satisfactory, cooperative, and praiseworthy.`;
    const splitP2 = doc.splitTextToSize(p2, 170);
    doc.text(splitP2, 20, currY);

    currY += (splitP2.length * 9) + 8;
    const p3 = `${heShe} actively participated in curricular and co-curricular classroom activities, observed school discipline, and showed utmost respect towards teachers and fellow students.`;
    const splitP3 = doc.splitTextToSize(p3, 170);
    doc.text(splitP3, 20, currY);

    currY += (splitP3.length * 9) + 8;
    const p4 = `To the best of our knowledge and school records, ${heShe.toLowerCase()} bears an EXEMPLARY MORAL CHARACTER. We wish ${isMale ? 'him' : 'her'} every success in future studies and life.`;
    const splitP4 = doc.splitTextToSize(p4, 170);
    doc.setFont('helvetica', 'bold');
    doc.text(splitP4, 20, currY);

    // Signatures
    const sigY = 225;
    doc.setDrawColor(212, 175, 55);
    doc.setLineWidth(1);
    doc.circle(45, sigY + 10, 15);
    doc.setFontSize(7);
    doc.setTextColor(15, 81, 50);
    doc.text('OFFICIAL SCHOOL SEAL', 45, sigY + 9, { align: 'center' });
    doc.text('EMIS 06994', 45, sigY + 13, { align: 'center' });

    if (signatureImg) {
      this.addImageSafe(doc, signatureImg, 135, sigY - 6, 45, 16);
    } else {
      doc.setDrawColor(100, 116, 139);
      doc.setLineWidth(0.5);
      doc.line(135, sigY + 10, 185, sigY + 10);
    }

    doc.setFontSize(10);
    doc.setTextColor(15, 81, 50);
    doc.text('HEAD TEACHER', 160, sigY + 15, { align: 'center' });
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9);
    doc.text(ht, 160, sigY + 20, { align: 'center' });
    doc.setFontSize(7.5);
    doc.setTextColor(100, 116, 139);
    doc.text('Govt Boys Primary School Sultan Matt Uchari', 160, sigY + 24, { align: 'center' });

    doc.save(`Character_Certificate_${student.name.replace(/\s+/g, '_')}.pdf`);
  },

  // 13. Student List Report PDF
  async generateStudentListPDF(className, students, settings) {
    const jsPDF = this.getJsPDF();
    const doc = new jsPDF('p', 'mm', 'a4');

    const startY = this.addReportHeader(
      doc,
      className === 'All' ? 'Complete School Enrolled Student List' : `Student Enrollment List - ${className}`,
      `Total Students: ${students.length}  |  Session: ${settings?.academicYear || '2026-2027'}`,
      settings
    );

    const tableData = students.map((s, i) => [
      i + 1,
      s.rollNo || '-',
      s.admissionNo || '-',
      s.name,
      s.fatherName,
      s.className,
      s.parentContact || '-',
      s.dob || '-'
    ]);

    doc.autoTable({
      startY: startY + 4,
      head: [['Sr#', 'Roll#', 'Adm#', 'Student Name', 'Father Name', 'Class', 'Contact', 'DOB']],
      body: tableData,
      theme: 'grid',
      headStyles: {
        fillColor: [26, 54, 93],
        textColor: [255, 255, 255],
        fontStyle: 'bold',
        fontSize: 8,
        halign: 'center'
      },
      columnStyles: {
        0: { cellWidth: 10, halign: 'center' },
        1: { cellWidth: 14, halign: 'center' },
        2: { cellWidth: 20, halign: 'center' },
        3: { cellWidth: 38 },
        4: { cellWidth: 38 },
        5: { cellWidth: 22, halign: 'center' },
        6: { cellWidth: 22 },
        7: { cellWidth: 18, halign: 'center' }
      },
      styles: { fontSize: 7.5, cellPadding: 2 },
      margin: { left: 14, right: 14, bottom: 25 }
    });

    this.addReportFooter(doc, settings, 1, 1);
    doc.save(`Student_List_${className.replace(/\s+/g, '_')}.pdf`);
  },

  // 14. Blank Offline Admission Application Form PDF (NO ONLINE ADMISSION)
  async generateAdmissionFormPDF(settings) {
    const jsPDF = this.getJsPDF();
    const doc = new jsPDF('p', 'mm', 'a4');

    const sName = settings?.schoolName || 'GOVERNMENT BOYS PRIMARY SCHOOL SULTAN MATT UCHARI';
    const sEmis = settings?.emis || '06994';
    const sLoc = settings?.location || 'District Barkhan, Balochistan, Pakistan';
    const ht = settings?.headTeacher || 'SHOUKAT ALI';

    // Outer Border
    doc.setDrawColor(26, 54, 93);
    doc.setLineWidth(1.2);
    doc.rect(10, 10, 190, 277);

    // School Header
    doc.setFillColor(26, 54, 93);
    doc.rect(10, 10, 190, 24, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(13);
    doc.text(sName, 105, 19, { align: 'center' });
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8.5);
    doc.text(`EMIS: ${sEmis}   |   ${sLoc}`, 105, 27, { align: 'center' });

    // Title Banner
    doc.setFillColor(212, 175, 55);
    doc.rect(10, 34, 190, 8, 'F');
    doc.setTextColor(26, 54, 93);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.text('OFFLINE ADMISSION APPLICATION FORM', 105, 40, { align: 'center' });

    // Photo Box Space
    const pX = 160;
    const pY = 46;
    const pW = 32;
    const pH = 40;
    doc.setDrawColor(100, 116, 139);
    doc.setLineWidth(0.8);
    doc.rect(pX, pY, pW, pH);
    doc.setFontSize(7.5);
    doc.setTextColor(148, 163, 184);
    doc.text('AFFIX RECENT', pX + pW / 2, pY + 18, { align: 'center' });
    doc.text('STUDENT PASSPORT', pX + pW / 2, pY + 22, { align: 'center' });
    doc.text('PHOTOGRAPH', pX + pW / 2, pY + 26, { align: 'center' });

    // Form fields
    let fY = 52;
    const leftX = 16;
    const lineSpacing = 11;

    function renderBlankField(label, width = 135) {
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(9);
      doc.setTextColor(30, 41, 59);
      doc.text(label, leftX, fY);

      // Blank line for writing
      doc.setDrawColor(148, 163, 184);
      doc.setLineWidth(0.5);
      const labelW = doc.getTextWidth(label);
      doc.line(leftX + labelW + 4, fY, leftX + width, fY);
      fY += lineSpacing;
    }

    renderBlankField('1. Student Full Name (Block Letters):', 138);
    renderBlankField('2. Father / Guardian Full Name:', 138);
    renderBlankField('3. Gender:  [  ] Male     [  ] Female', 138);
    renderBlankField('4. Date of Birth (DD/MM/YYYY):', 138);
    renderBlankField('5. Class Applying For (Kachi to Class 5):', 184);
    renderBlankField('6. Previous School Attended (if any):', 184);
    renderBlankField('7. Student B-Form / CNIC Number:', 184);
    renderBlankField('8. Father CNIC Number:', 184);
    renderBlankField('9. Parent Primary Contact / Mobile No:', 184);
    renderBlankField('10. Emergency Contact Person & Number:', 184);
    renderBlankField('11. Permanent Village / Home Address:', 184);
    renderBlankField('12. Tehsil & District:', 184);

    // Parent Undertaking Box
    fY += 3;
    doc.setFillColor(248, 250, 252);
    doc.setDrawColor(203, 213, 225);
    doc.roundedRect(leftX, fY, 178, 26, 2, 2, 'FD');

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8.5);
    doc.setTextColor(26, 54, 93);
    doc.text('PARENT / GUARDIAN UNDERTAKING', leftX + 4, fY + 6);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7.5);
    doc.setTextColor(71, 85, 105);
    const underText = 'I hereby declare that all information furnished in this admission form is true and correct to the best of my knowledge. I agree to abide by all rules, regulations, and uniform code of Government Boys Primary School Sultan Matt Uchari.';
    doc.text(doc.splitTextToSize(underText, 170), leftX + 4, fY + 12);

    // Signatures in Undertaking
    doc.line(leftX + 8, fY + 22, leftX + 60, fY + 22);
    doc.text('Date', leftX + 30, fY + 25, { align: 'center' });

    doc.line(leftX + 115, fY + 22, leftX + 170, fY + 22);
    doc.text('Parent / Guardian Signature', leftX + 142, fY + 25, { align: 'center' });

    // Office Use Only Section
    fY += 31;
    doc.setFillColor(241, 245, 249);
    doc.roundedRect(leftX, fY, 178, 40, 2, 2, 'FD');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9);
    doc.setTextColor(26, 54, 93);
    doc.text('FOR OFFICIAL SCHOOL OFFICE USE ONLY', leftX + 4, fY + 6);

    let offY = fY + 14;
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8.5);
    doc.setTextColor(30, 41, 59);

    doc.text('Admission Granted To Class: ____________', leftX + 6, offY);
    doc.text('Allotted Roll No: ___________', leftX + 90, offY);

    offY += 9;
    doc.text('Admission Number Assigned: ___________', leftX + 6, offY);
    doc.text('Admission Date: ____________', leftX + 90, offY);

    offY += 12;
    doc.line(leftX + 110, offY, leftX + 170, offY);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8.5);
    doc.text(`HEAD TEACHER (${ht})`, leftX + 140, offY + 4, { align: 'center' });

    doc.save('Offline_Admission_Application_Form_GBPS_Uchari.pdf');
  }
};

window.PDFGen = PDFGen;
