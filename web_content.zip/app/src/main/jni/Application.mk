APP_PLATFORM := android-24
APP_CFLAGS := -O3 -DPKGNAME=hev/htproxy -DCLSNAME=TProxyService
APP_CPPFLAGS := -O3 -std=c++11
APP_LDFLAGS := -Wl,--build-id=none
