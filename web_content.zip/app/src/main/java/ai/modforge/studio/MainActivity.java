package ai.modforge.studio;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;

public class MainActivity extends Activity {
    WebView web;
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        setContentView(web);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(true);
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new Bridge(), "Android");
        web.loadUrl("file:///android_asset/index.html");
    }
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
    class Bridge {
        @JavascriptInterface
        public String listApps() {
            JSONArray out = new JSONArray();
            Intent i = new Intent(Intent.ACTION_MAIN, null);
            i.addCategory(Intent.CATEGORY_LAUNCHER);
            HashSet<String> seen = new HashSet<String>();
            ArrayList<JSONObject> list = new ArrayList<JSONObject>();
            for (ResolveInfo ri : getPackageManager().queryIntentActivities(i, 0)) {
                String p = ri.activityInfo.packageName;
                if (p.equals(getPackageName()) || !seen.add(p)) continue;
                try {
                    JSONObject o = new JSONObject();
                    o.put("n", ri.loadLabel(getPackageManager()).toString());
                    o.put("p", p);
                    list.add(o);
                } catch (Exception e) {}
            }
            Collections.sort(list, new Comparator<JSONObject>() {
                public int compare(JSONObject a, JSONObject b) {
                    return a.optString("n").compareToIgnoreCase(b.optString("n"));
                }
            });
            for (JSONObject o : list) out.put(o);
            return out.toString();
        }
        @JavascriptInterface
        public String extract(String pkg) {
            try {
                PackageInfo pi = getPackageManager().getPackageInfo(pkg, 0);
                ArrayList<String> src = new ArrayList<String>();
                if (pi.applicationInfo.sourceDir != null) src.add(pi.applicationInfo.sourceDir);
                if (pi.applicationInfo.splitSourceDirs != null) {
                    for (String s : pi.applicationInfo.splitSourceDirs) src.add(s);
                }
                File dir = new File(getExternalFilesDir(null), "apks");
                dir.mkdirs();
                String first = "";
                for (String s : src) {
                    File f = new File(s);
                    if (!f.canRead()) return "ERR:permission denied, root ya Shizuku chahiye";
                    File dst = new File(dir, pkg + "-" + f.getName());
                    InputStream in = new FileInputStream(f);
                    OutputStream os = new FileOutputStream(dst);
                    byte[] buf = new byte[8192];
                    int r;
                    while ((r = in.read(buf)) > 0) os.write(buf, 0, r);
                    in.close();
                    os.close();
                    if (first.isEmpty()) first = dst.getAbsolutePath();
                }
                return "OK:" + first;
            } catch (Exception e) {
                return "ERR:" + e.getMessage();
            }
        }
        @JavascriptInterface
        public void copy(String t) {
            ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("path", t));
        }
        @JavascriptInterface
        public void save(String name, String body) {
            try {
                File dir = new File(getExternalFilesDir(null), "kit");
                dir.mkdirs();
                FileOutputStream o = new FileOutputStream(new File(dir, name));
                o.write(body.getBytes());
                o.close();
            } catch (Exception e) {}
        }
    }
}
