package ai.boss.standalone

import android.app.Activity
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebChromeClient
import android.view.ViewGroup
import android.graphics.Color

class MainActivity : Activity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    window.statusBarColor = Color.rgb(15, 23, 42)
    window.navigationBarColor = Color.rgb(15, 23, 42)
    val web = WebView(this)
    web.layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
    web.settings.javaScriptEnabled = true
    web.settings.domStorageEnabled = true
    web.settings.allowFileAccess = false
    web.settings.allowContentAccess = false
    web.webViewClient = WebViewClient()
    web.webChromeClient = WebChromeClient()
    web.loadUrl("file:///android_asset/index.html")
    setContentView(web)
  }
  @Deprecated("Deprecated in Android API") override fun onBackPressed() {
    val view = (window.decorView.findViewById(android.R.id.content) as? ViewGroup)?.getChildAt(0) as? WebView
    if (view?.canGoBack() == true) view.goBack() else super.onBackPressed()
  }
}
