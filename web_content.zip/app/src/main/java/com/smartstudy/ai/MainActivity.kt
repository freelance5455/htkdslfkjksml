package com.smartstudy.ai
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
class MainActivity : ComponentActivity() {
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  val web = WebView(this)
  web.settings.javaScriptEnabled = true
  web.settings.domStorageEnabled = true
  web.webViewClient = WebViewClient()
  web.webChromeClient = WebChromeClient()
  web.loadUrl("file:///android_asset/index.html")
  setContentView(web)
 }
 override fun onBackPressed() {
  val web = (window.decorView.findViewById(android.R.id.content) as? android.view.ViewGroup)?.getChildAt(0) as? WebView
  if (web?.canGoBack() == true) web.goBack() else super.onBackPressed()
 }
}
