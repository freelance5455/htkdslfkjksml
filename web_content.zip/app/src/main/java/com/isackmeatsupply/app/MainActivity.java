package com.isackmeatsupply.app;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebResourceRequest;
import android.view.KeyEvent;
import android.webkit.ValueCallback;
import android.net.Uri;
import android.content.Intent;
import android.content.ActivityNotFoundException;
import android.webkit.DownloadListener;
import android.app.DownloadManager;
import android.os.Environment;
import android.content.Context;
import android.widget.Toast;
import android.webkit.JavascriptInterface;

public class MainActivity extends Activity {
  private WebView web;
  @Override public void onCreate(Bundle b) {
    super.onCreate(b);
    web = new WebView(this);
    setContentView(web);
    WebSettings s = web.getSettings();
    s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true);
    s.setAllowFileAccess(true); s.setAllowContentAccess(true); s.setJavaScriptCanOpenWindowsAutomatically(true);
    web.setWebViewClient(new WebViewClient());
    web.setWebChromeClient(new WebChromeClient());
    web.addJavascriptInterface(new ShareBridge(this), "AndroidBridge");
    web.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
      try {
        DownloadManager.Request req = new DownloadManager.Request(Uri.parse(url));
        req.setMimeType(mimeType); req.addRequestHeader("User-Agent", userAgent);
        req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
        req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "Isack-Meat-Statement.png");
        ((DownloadManager)getSystemService(DOWNLOAD_SERVICE)).enqueue(req);
        Toast.makeText(this,"Download started",Toast.LENGTH_SHORT).show();
      } catch(Exception e) { Toast.makeText(this,"Download failed",Toast.LENGTH_LONG).show(); }
    });
    web.loadUrl("file:///android_asset/index.html");
  }
  @Override public void onBackPressed() {
    if (web != null) web.evaluateJavascript("if(document.querySelector('.sidebar.open')){document.getElementById('mobileMenu').click();'menu'}else if(window.history.length>1){history.back();'history'}else{'exit'}", result -> {
      if ("\"exit\"".equals(result)) finish();
    });
  }
  static class ShareBridge {
    Activity a; ShareBridge(Activity x){a=x;}
    @JavascriptInterface public void shareText(String text) {
      a.runOnUiThread(() -> {
        Intent i=new Intent(Intent.ACTION_SEND); i.setType("text/plain"); i.putExtra(Intent.EXTRA_TEXT,text);
        a.startActivity(Intent.createChooser(i,"Share statement"));
      });
    }
  }
}