package com.mytrade.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        Intent s = new Intent(c, RingService.class);
        s.putExtras(i);
        c.startForegroundService(s);
        AlarmScheduler.scheduleNext(c);
    }
}
