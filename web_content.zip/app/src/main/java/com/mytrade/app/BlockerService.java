package com.mytrade.app;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;

public class BlockerService extends AccessibilityService {
    private String last = "";
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            check(false);
            h.postDelayed(this, 2000);
        }
    };

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        h.removeCallbacks(tick);
        h.post(tick);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent e) {
        if (e == null || e.getEventType() != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return;
        CharSequence p = e.getPackageName();
        if (p == null) return;
        String pkg = p.toString();
        if (pkg.equals("com.android.systemui") || pkg.contains("inputmethod")) return;
        last = pkg;
        check(true);
    }

    private void check(boolean fromEvent) {
        if (last.length() == 0 || last.equals(getPackageName())) return;
        if (!Blocker.isBlockedNow(this, last)) return;
        if (fromEvent) Blocker.bumpTries(this, last);
        Intent i = new Intent(this, BlockActivity.class);
        i.putExtra("pkg", last);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NO_ANIMATION);
        startActivity(i);
    }

    @Override
    public void onInterrupt() {
    }

    @Override
    public void onDestroy() {
        h.removeCallbacks(tick);
        super.onDestroy();
    }
}
