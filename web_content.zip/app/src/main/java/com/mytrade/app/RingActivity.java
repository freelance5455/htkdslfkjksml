package com.mytrade.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class RingActivity extends Activity {
    private static Activity cur;

    static void close() {
        if (cur != null) {
            cur.finish();
            cur = null;
        }
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        cur = this;
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD);

        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setGravity(Gravity.CENTER);
        l.setPadding(48, 48, 48, 48);
        l.setBackgroundColor(Color.parseColor("#1F1B2E"));

        TextView n = new TextView(this);
        n.setText(getIntent().getStringExtra("name"));
        n.setTextColor(Color.WHITE);
        n.setTextSize(26);
        n.setGravity(Gravity.CENTER);

        TextView t = new TextView(this);
        t.setText(getIntent().getStringExtra("time"));
        t.setTextColor(Color.parseColor("#7C5CFF"));
        t.setTextSize(64);
        t.setGravity(Gravity.CENTER);

        Button s = new Button(this);
        s.setText("Stop");
        s.setTextSize(20);
        s.setOnClickListener(v -> {
            Intent st = new Intent(this, RingService.class);
            st.setAction("STOP");
            startService(st);
            finish();
        });

        l.addView(n);
        l.addView(t);
        l.addView(s);
        setContentView(l);
    }

    @Override
    protected void onDestroy() {
        if (cur == this) cur = null;
        super.onDestroy();
    }
}
