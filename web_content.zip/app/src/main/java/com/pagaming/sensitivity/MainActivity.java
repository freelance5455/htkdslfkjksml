package com.pagaming.sensitivity;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.content.Intent;
import android.net.Uri;
public class MainActivity extends Activity {
 private WebView webView;
 @Override public void onCreate(Bundle savedInstanceState) {
  super.onCreate(savedInstanceState);
  webView=new WebView(this);
  WebSettings s=webView.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true);
  webView.setWebViewClient(new WebViewClient(){
   @Override public boolean shouldOverrideUrlLoading(WebView view,String url){
    if(url.startsWith("intent://")) { try { Intent i=Intent.parseUri(url,Intent.URI_INTENT_SCHEME); startActivity(i); } catch(Exception e){} return true; }
    if(url.startsWith("https://play.google.com/")) { try { startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url))); } catch(Exception e){} return true; }
    return false;
   }
  });
  webView.setWebChromeClient(new WebChromeClient()); setContentView(webView); webView.loadUrl("file:///android_asset/index.html");
 }
 @Override public void onBackPressed(){ if(webView!=null && webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }
}
