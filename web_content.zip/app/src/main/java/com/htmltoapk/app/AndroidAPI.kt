package com.htmltoapk.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.media.MediaRecorder
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.MediaStore
import android.util.Log
import android.webkit.JavascriptInterface
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.Locale

class AndroidAPI(
    private val activity: WebViewActivity,
    private val isPro: Boolean = false,
    private val adMobBridge: AdMobBridge? = null
) {

    companion object {
        private const val TAG = "AndroidAPI"
        const val INTERFACE_NAME = "AndroidAPI"
        private const val NOTIF_CHANNEL = "htmltoapk_channel"
    }

    private val context: Context get() = activity
    private val mainHandler = Handler(Looper.getMainLooper())

    private fun ensurePro(): Boolean {
        if (!isPro) {
            emit("proRequired", JSONObject().apply {
                put("error", "This API requires Pro")
            })
        }
        return isPro
    }

    // Sensors
    private val sensorManager by lazy { context.getSystemService(Context.SENSOR_SERVICE) as SensorManager }
    private val activeSensors = mutableMapOf<String, SensorHolder>()

    private data class SensorHolder(
        val type: Int,
        val listener: SensorEventListener,
        val callbackId: String
    )

    // Location
    private val locationManager by lazy { context.getSystemService(Context.LOCATION_SERVICE) as LocationManager }
    private var locationListener: LocationListener? = null

    // Audio recording
    private var mediaRecorder: MediaRecorder? = null
    private var audioRecordingFile: File? = null

    // Torch
    private var pendingTorchEnabled: Boolean? = null

    // Notification
    private var pendingNotification: Pair<String, String>? = null

    // Clipboard
    private val clipboard by lazy { context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager }

    @JavascriptInterface
    fun showToast(message: String) {
        runOnUiThread { Toast.makeText(context, message, Toast.LENGTH_SHORT).show() }
    }

    @JavascriptInterface
    fun vibrate(milliseconds: Int) {
        try {
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vm?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            } ?: return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createOneShot(milliseconds.coerceAtLeast(1).toLong(), VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(milliseconds.coerceAtLeast(1).toLong())
            }
        } catch (e: Exception) {
            Log.w(TAG, "vibrate failed: ${e.message}")
        }
    }

    @JavascriptInterface
    fun setTorch(enabled: Boolean) {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            pendingTorchEnabled = enabled
            runOnUiThread {
                activity.requestPermission(Manifest.permission.CAMERA, "torch")
            }
            return
        }
        applyTorch(enabled)
    }

    private fun applyTorch(enabled: Boolean) {
        val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
        if (cameraManager == null) {
            emitTorchResult(enabled, false, "CameraManager not available")
            return
        }
        try {
            val cameraId = findTorchCameraId(cameraManager)
            if (cameraId == null) {
                emitTorchResult(enabled, false, "No camera with flashlight found")
                return
            }
            cameraManager.setTorchMode(cameraId, enabled)
            emitTorchResult(enabled, true, null)
        } catch (e: CameraAccessException) {
            emitTorchResult(enabled, false, e.message)
        }
    }

    private fun findTorchCameraId(cameraManager: CameraManager): String? {
        return try {
            cameraManager.cameraIdList.find { id ->
                val characteristics = cameraManager.getCameraCharacteristics(id)
                val flashAvailable = characteristics.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) ?: false
                val facing = characteristics.get(CameraCharacteristics.LENS_FACING)
                flashAvailable && facing == CameraCharacteristics.LENS_FACING_BACK
            } ?: cameraManager.cameraIdList.find { id ->
                cameraManager.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun emitTorchResult(enabled: Boolean, success: Boolean, error: String?) {
        emit("torchResult", JSONObject().apply {
            put("enabled", enabled)
            put("success", success)
            put("error", error ?: JSONObject.NULL)
        })
    }

    @JavascriptInterface
    fun showNotification(title: String, message: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                pendingNotification = title to message
                runOnUiThread {
                    activity.requestPermission(Manifest.permission.POST_NOTIFICATIONS, "notification")
                }
                return
            }
        }
        postNotification(title, message)
    }

    @JavascriptInterface
    fun requestNotificationPermission(callbackId: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            runOnUiThread {
                activity.requestPermission(Manifest.permission.POST_NOTIFICATIONS, callbackId)
            }
        } else {
            emit("permissionResult", JSONObject().apply {
                put("callbackId", callbackId)
                put("permission", Manifest.permission.POST_NOTIFICATIONS)
                put("granted", true)
            })
        }
    }

    private fun postNotification(title: String, message: String) {
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                NOTIF_CHANNEL,
                "HTML to APK",
                NotificationManager.IMPORTANCE_DEFAULT
            )
            notificationManager.createNotificationChannel(channel)
        }
        val notification = NotificationCompat.Builder(context, NOTIF_CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(message)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .build()
        notificationManager.notify(System.currentTimeMillis().toInt(), notification)
    }

    @JavascriptInterface
    fun scheduleNotification(id: String, title: String, message: String, delayMs: Long) {
        scheduleNotification(id, title, message, delayMs, 0L)
    }

    @JavascriptInterface
    fun scheduleNotification(id: String, title: String, message: String, delayMs: Long, repeatIntervalMs: Long) {
        if (!ensurePro()) return
        val triggerAt = System.currentTimeMillis() + delayMs.coerceAtLeast(0)
        val success = AlarmReceiver.scheduleAlarm(context, id, title, message, triggerAt, repeatIntervalMs)
        emit("scheduledNotificationResult", JSONObject().apply {
            put("id", id)
            put("success", success)
            if (!success) put("error", "Failed to schedule alarm")
        })
    }

    @JavascriptInterface
    fun cancelScheduledNotification(id: String) {
        if (!ensurePro()) return
        AlarmReceiver.cancelAlarm(context, id)
    }

    @JavascriptInterface
    fun getLaunchDeepLink(): String {
        return activity.launchDeepLink ?: ""
    }

    @JavascriptInterface
    fun getDeviceInfo(): String {
        val json = JSONObject()
        json.put("model", Build.MODEL)
        json.put("manufacturer", Build.MANUFACTURER)
        json.put("androidVersion", Build.VERSION.RELEASE)
        json.put("sdk", Build.VERSION.SDK_INT)
        return json.toString()
    }

    @JavascriptInterface
    fun getBatteryLevel(): Int {
        val intent = context.registerReceiver(null, android.content.IntentFilter(android.content.Intent.ACTION_BATTERY_CHANGED))
        val level = intent?.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = intent?.getIntExtra(android.os.BatteryManager.EXTRA_SCALE, -1) ?: -1
        return if (level >= 0 && scale > 0) (level * 100 / scale) else -1
    }

    @JavascriptInterface
    fun hasPermission(permission: String): Boolean {
        return ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
    }

    @JavascriptInterface
    fun requestPermission(permission: String, callbackId: String) {
        runOnUiThread {
            activity.requestPermission(permission, callbackId)
        }
    }

    @JavascriptInterface
    fun requestPermissions(permissionsJson: String, callbackId: String) {
        val permissions = try {
            JSONArray(permissionsJson)
        } catch (_: Exception) {
            JSONArray()
        }
        val list = mutableListOf<String>()
        for (i in 0 until permissions.length()) {
            list.add(permissions.optString(i))
        }
        runOnUiThread {
            activity.requestPermissions(list.toTypedArray(), callbackId)
        }
    }

    @JavascriptInterface
    fun getScreenBrightness(): Int {
        return try {
            android.provider.Settings.System.getInt(context.contentResolver, android.provider.Settings.System.SCREEN_BRIGHTNESS)
        } catch (_: Exception) {
            -1
        }
    }

    // Location
    @JavascriptInterface
    fun getLocation(callbackId: String) {
        if (!ensurePro()) return
        if (!hasPermission(Manifest.permission.ACCESS_FINE_LOCATION) && !hasPermission(Manifest.permission.ACCESS_COARSE_LOCATION)) {
            emit("locationResult", JSONObject().apply {
                put("callbackId", callbackId)
                put("error", "Location permission not granted")
            })
            return
        }
        runOnUiThread {
            try {
                val provider = when {
                    locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) -> LocationManager.GPS_PROVIDER
                    locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER) -> LocationManager.NETWORK_PROVIDER
                    else -> null
                }
                if (provider == null) {
                    emit("locationResult", JSONObject().apply {
                        put("callbackId", callbackId)
                        put("error", "No location provider available")
                    })
                    return@runOnUiThread
                }
                val listener = object : LocationListener {
                    override fun onLocationChanged(location: Location) {
                        locationManager.removeUpdates(this)
                        emit("locationResult", JSONObject().apply {
                            put("callbackId", callbackId)
                            put("latitude", location.latitude)
                            put("longitude", location.longitude)
                            put("accuracy", location.accuracy.toDouble())
                            put("provider", location.provider)
                        })
                    }
                    override fun onProviderEnabled(provider: String) {}
                    override fun onProviderDisabled(provider: String) {}
                    @Deprecated("Deprecated in Java")
                    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
                }
                locationManager.requestSingleUpdate(provider, listener, null)
            } catch (e: SecurityException) {
                emit("locationResult", JSONObject().apply {
                    put("callbackId", callbackId)
                    put("error", e.message)
                })
            }
        }
    }

    @JavascriptInterface
    fun startLocationUpdates(callbackId: String) {
        if (!ensurePro()) return
        if (!hasPermission(Manifest.permission.ACCESS_FINE_LOCATION) && !hasPermission(Manifest.permission.ACCESS_COARSE_LOCATION)) {
            emit("locationUpdate", JSONObject().apply {
                put("callbackId", callbackId)
                put("error", "Location permission not granted")
            })
            return
        }
        runOnUiThread {
            try {
                stopLocationUpdates()
                val provider = when {
                    locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) -> LocationManager.GPS_PROVIDER
                    locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER) -> LocationManager.NETWORK_PROVIDER
                    else -> null
                }
                if (provider == null) {
                    emit("locationUpdate", JSONObject().apply {
                        put("callbackId", callbackId)
                        put("error", "No location provider available")
                    })
                    return@runOnUiThread
                }
                val listener = object : LocationListener {
                    override fun onLocationChanged(location: Location) {
                        emit("locationUpdate", JSONObject().apply {
                            put("callbackId", callbackId)
                            put("latitude", location.latitude)
                            put("longitude", location.longitude)
                            put("accuracy", location.accuracy.toDouble())
                            put("provider", location.provider)
                        })
                    }
                    override fun onProviderEnabled(provider: String) {}
                    override fun onProviderDisabled(provider: String) {}
                    @Deprecated("Deprecated in Java")
                    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
                }
                locationListener = listener
                locationManager.requestLocationUpdates(provider, 1000L, 1f, listener)
            } catch (e: SecurityException) {
                emit("locationUpdate", JSONObject().apply {
                    put("callbackId", callbackId)
                    put("error", e.message)
                })
            }
        }
    }

    @JavascriptInterface
    fun stopLocationUpdates() {
        if (!ensurePro()) return
        locationListener?.let {
            try {
                locationManager.removeUpdates(it)
            } catch (_: Exception) {
            }
            locationListener = null
        }
    }

    // Camera
    @JavascriptInterface
    fun capturePhoto(callbackId: String) {
        runOnUiThread {
            activity.capturePhoto(callbackId)
        }
    }

    @JavascriptInterface
    fun startCameraPreview() {
        if (!ensurePro()) return
        runOnUiThread {
            activity.startCameraPreview()
        }
    }

    @JavascriptInterface
    fun stopCameraPreview() {
        if (!ensurePro()) return
        runOnUiThread {
            activity.stopCameraPreview()
        }
    }

    // Audio
    @JavascriptInterface
    fun startAudioRecording(fileName: String) {
        if (!ensurePro()) return
        if (!hasPermission(Manifest.permission.RECORD_AUDIO)) {
            return
        }
        runOnUiThread {
            try {
                stopAudioRecording("ignored")
                val file = File(context.cacheDir, fileName).apply { parentFile?.mkdirs() }
                audioRecordingFile = file
                val recorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    MediaRecorder(context)
                } else {
                    @Suppress("DEPRECATION")
                    MediaRecorder()
                }
                recorder.apply {
                    setAudioSource(MediaRecorder.AudioSource.MIC)
                    setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                    setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                    setOutputFile(file.absolutePath)
                    try {
                        prepare()
                        start()
                        mediaRecorder = this
                    } catch (e: IOException) {
                        release()
                    }
                }
            } catch (_: Exception) {
            }
        }
    }

    @JavascriptInterface
    fun stopAudioRecording(callbackId: String) {
        if (!ensurePro()) return
        runOnUiThread {
            try {
                mediaRecorder?.apply {
                    stop()
                    release()
                }
                mediaRecorder = null
                val path = audioRecordingFile?.absolutePath
                audioRecordingFile = null
                emit("audioRecordingResult", JSONObject().apply {
                    put("callbackId", callbackId)
                    put("success", path != null)
                    put("path", path ?: "")
                })
            } catch (e: Exception) {
                emit("audioRecordingResult", JSONObject().apply {
                    put("callbackId", callbackId)
                    put("success", false)
                    put("error", e.message)
                })
            }
        }
    }

    // Clipboard
    @JavascriptInterface
    fun copyToClipboard(text: String) {
        runOnUiThread {
            try {
                clipboard.setPrimaryClip(ClipData.newPlainText("text", text))
            } catch (_: Exception) {
                // Clipboard service may be dead/unavailable on some devices.
            }
        }
    }

    @JavascriptInterface
    fun pasteFromClipboard(): String {
        return try {
            if (clipboard.hasPrimaryClip()) {
                val item = clipboard.primaryClip?.getItemAt(0)
                item?.text?.toString() ?: ""
            } else ""
        } catch (_: Exception) {
            ""
        }
    }

    // Share
    @JavascriptInterface
    fun shareText(text: String) {
        runOnUiThread {
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, text)
            }
            val chooser = Intent.createChooser(intent, "Share")
            context.startActivity(chooser)
        }
    }

    @JavascriptInterface
    fun shareFile(filePath: String, mimeType: String?) {
        runOnUiThread {
            try {
                val file = File(filePath)
                val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = mimeType ?: "*/*"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                context.startActivity(Intent.createChooser(intent, "Share"))
            } catch (_: Exception) {
            }
        }
    }

    // File I/O via SAF
    @JavascriptInterface
    fun pickFile(mimeType: String, callbackId: String) {
        if (!ensurePro()) return
        runOnUiThread {
            activity.pickFile(mimeType, callbackId)
        }
    }

    @JavascriptInterface
    fun writeFile(fileName: String, content: String, mimeType: String?, callbackId: String) {
        if (!ensurePro()) return
        runOnUiThread {
            activity.createFile(fileName, mimeType ?: "*/*", content, callbackId)
        }
    }

    @JavascriptInterface
    fun readAppFile(fileName: String): String {
        return try {
            File(context.filesDir, fileName).readText()
        } catch (_: Exception) {
            ""
        }
    }

    @JavascriptInterface
    fun writeAppFile(fileName: String, content: String): Boolean {
        return try {
            File(context.filesDir, fileName).writeText(content)
            true
        } catch (_: Exception) {
            false
        }
    }

    // Gallery
    @JavascriptInterface
    fun saveToGallery(fileName: String, base64Image: String, callbackId: String) {
        if (!ensurePro()) return
        runOnUiThread {
            try {
                val bitmap = base64ToBitmap(base64Image) ?: throw IllegalArgumentException("Invalid image data")
                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        put(MediaStore.Images.Media.IS_PENDING, 1)
                        put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES)
                    }
                }
                val resolver = context.contentResolver
                val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                if (uri != null) {
                    resolver.openOutputStream(uri)?.use { out ->
                        bitmap.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, out)
                    }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        values.clear()
                        values.put(MediaStore.Images.Media.IS_PENDING, 0)
                        resolver.update(uri, values, null, null)
                    }
                    emit("gallerySaveResult", JSONObject().apply {
                        put("callbackId", callbackId)
                        put("success", true)
                        put("uri", uri.toString())
                    })
                } else {
                    throw IOException("Failed to create MediaStore entry")
                }
            } catch (e: Exception) {
                emit("gallerySaveResult", JSONObject().apply {
                    put("callbackId", callbackId)
                    put("success", false)
                    put("error", e.message)
                })
            }
        }
    }

    // Sensors
    @JavascriptInterface
    fun startSensor(sensorType: String, callbackId: String) {
        if (!ensurePro()) return
        runOnUiThread {
            val type = sensorTypeToInt(sensorType)
            if (type == -1) {
                emit("sensorError", JSONObject().apply {
                    put("callbackId", callbackId)
                    put("sensor", sensorType)
                    put("error", "Unknown sensor type")
                })
                return@runOnUiThread
            }
            if (sensorType == "stepCounter" && !hasPermission(Manifest.permission.ACTIVITY_RECOGNITION)) {
                emit("sensorError", JSONObject().apply {
                    put("callbackId", callbackId)
                    put("sensor", sensorType)
                    put("error", "Activity recognition permission not granted")
                })
                return@runOnUiThread
            }
            stopSensor(sensorType)
            val sensor = sensorManager.getDefaultSensor(type)
            if (sensor == null) {
                emit("sensorError", JSONObject().apply {
                    put("callbackId", callbackId)
                    put("sensor", sensorType)
                    put("error", "Sensor not available on this device")
                })
                return@runOnUiThread
            }
            val listener = object : SensorEventListener {
                override fun onSensorChanged(event: SensorEvent) {
                    emit("sensorData", JSONObject().apply {
                        put("callbackId", callbackId)
                        put("sensor", sensorType)
                        put("values", JSONArray(event.values.map { it.toDouble() }))
                        put("timestamp", event.timestamp)
                        put("accuracy", event.accuracy)
                    })
                }
                override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
            }
            activeSensors[sensorType] = SensorHolder(type, listener, callbackId)
            sensorManager.registerListener(listener, sensor, SensorManager.SENSOR_DELAY_UI)
        }
    }

    @JavascriptInterface
    fun stopSensor(sensorType: String) {
        if (!ensurePro()) return
        activeSensors.remove(sensorType)?.let { holder ->
            sensorManager.unregisterListener(holder.listener)
        }
    }

    @JavascriptInterface
    fun stopAllSensors() {
        if (!ensurePro()) return
        activeSensors.values.forEach { holder ->
            sensorManager.unregisterListener(holder.listener)
        }
        activeSensors.clear()
    }

    // Called by WebViewActivity
    fun onPermissionResult(callbackId: String, permission: String, granted: Boolean) {
        if (callbackId == "torch" && granted) {
            pendingTorchEnabled?.let {
                applyTorch(it)
                pendingTorchEnabled = null
            }
        }
        if (callbackId == "notification" && granted) {
            pendingNotification?.let { (title, message) ->
                postNotification(title, message)
                pendingNotification = null
            }
        }
        emit("permissionResult", JSONObject().apply {
            put("callbackId", callbackId)
            put("permission", permission)
            put("granted", granted)
        })
    }

    fun onPermissionsResult(callbackId: String, results: Map<String, Boolean>) {
        val obj = JSONObject()
        results.forEach { (k, v) -> obj.put(k, v) }
        emit("permissionsResult", JSONObject().apply {
            put("callbackId", callbackId)
            put("results", obj)
        })
    }

    fun onCameraResult(callbackId: String, success: Boolean, base64: String?) {
        emit("cameraResult", JSONObject().apply {
            put("callbackId", callbackId)
            put("success", success)
            put("base64", base64 ?: "")
        })
    }

    fun onFilePicked(callbackId: String, content: String?, error: String?) {
        emit("filePicked", JSONObject().apply {
            put("callbackId", callbackId)
            put("success", content != null && error == null)
            put("content", content ?: "")
            put("error", error ?: "")
        })
    }

    fun onFileWritten(callbackId: String, success: Boolean, error: String?) {
        emit("fileWritten", JSONObject().apply {
            put("callbackId", callbackId)
            put("success", success)
            put("error", error ?: "")
        })
    }

    internal fun emit(event: String, data: JSONObject) {
        val jsonStr = data.toString()
        val quotedEvent = JSONObject.quote(event)
        val script = """
            (function() {
                try {
                    var eventName = $quotedEvent;
                    var payload = ${jsonStr};
                    if (window.onAndroidEvent) {
                        window.onAndroidEvent(eventName, payload);
                    }
                    window.dispatchEvent(new CustomEvent(eventName, { detail: payload }));
                } catch(e) {
                    console.error('Error dispatching Android event:', e);
                }
            })();
        """.trimIndent()
        mainHandler.post {
            activity.webView.evaluateJavascript(script, null)
        }
    }

    // --- Ads JS API ---

    @JavascriptInterface
    fun adsInitialize() {
        // AdMob is already initialized when the bridge is created if IDs are present.
        emit("adResult", JSONObject().apply {
            put("initialized", adMobBridge?.isEnabled == true)
        })
    }

    @JavascriptInterface
    fun adsLoadInterstitial() {
        adsLoadInterstitial("")
    }

    @JavascriptInterface
    fun adsLoadInterstitial(adUnitId: String) {
        val id = adUnitId.trim().ifBlank { adMobBridge?.interstitialId ?: "" }
        if (id.isNotBlank()) {
            adMobBridge?.loadInterstitial(id)
        } else {
            emit("adFailedToLoad", JSONObject().apply { put("message", "Interstitial Ad Unit ID not configured") })
        }
    }

    @JavascriptInterface
    fun loadInterstitialAd() {
        adsLoadInterstitial("")
    }

    @JavascriptInterface
    fun loadInterstitialAd(adUnitId: String) {
        adsLoadInterstitial(adUnitId)
    }

    @JavascriptInterface
    fun adsShowInterstitial() {
        adMobBridge?.showInterstitial()
            ?: emit("adFailedToShow", JSONObject().apply { put("message", "AdMob not configured") })
    }

    @JavascriptInterface
    fun showInterstitialAd() {
        adsShowInterstitial()
    }

    @JavascriptInterface
    fun isInterstitialAdLoaded(): Boolean {
        return adMobBridge?.isInterstitialLoaded() ?: false
    }

    @JavascriptInterface
    fun adsLoadRewarded() {
        adsLoadRewarded("")
    }

    @JavascriptInterface
    fun adsLoadRewarded(adUnitId: String) {
        val id = adUnitId.trim().ifBlank { adMobBridge?.rewardedId ?: "" }
        if (id.isNotBlank()) {
            adMobBridge?.loadRewarded(id)
        } else {
            emit("adFailedToLoad", JSONObject().apply { put("message", "Rewarded Ad Unit ID not configured") })
        }
    }

    @JavascriptInterface
    fun loadRewardedAd() {
        adsLoadRewarded("")
    }

    @JavascriptInterface
    fun loadRewardedAd(adUnitId: String) {
        adsLoadRewarded(adUnitId)
    }

    @JavascriptInterface
    fun adsShowRewarded() {
        adsShowRewarded("")
    }

    @JavascriptInterface
    fun adsShowRewarded(callbackName: String) {
        showRewardedAd(callbackName)
    }

    @JavascriptInterface
    fun showRewardedAd() {
        adsShowRewarded("")
    }

    @JavascriptInterface
    fun showRewardedAd(callbackName: String) {
        adMobBridge?.showRewarded(callbackName.trim().takeIf { it.isNotBlank() })
            ?: emit("adFailedToShow", JSONObject().apply { put("message", "AdMob not configured") })
    }

    @JavascriptInterface
    fun isRewardedAdLoaded(): Boolean {
        return adMobBridge?.isRewardedLoaded() ?: false
    }

    @JavascriptInterface
    fun adsLoadBanner() {
        adsLoadBanner("", "bottom")
    }

    @JavascriptInterface
    fun adsLoadBanner(adUnitId: String) {
        adsLoadBanner(adUnitId, "bottom")
    }

    @JavascriptInterface
    fun adsLoadBanner(adUnitId: String, position: String) {
        val id = adUnitId.trim().ifBlank { adMobBridge?.bannerId ?: "" }
        if (id.isNotBlank()) {
            adMobBridge?.loadBanner(id, position)
        } else {
            emit("adFailedToLoad", JSONObject().apply { put("message", "Banner Ad Unit ID not configured") })
        }
    }

    @JavascriptInterface
    fun loadBannerAd() {
        adsLoadBanner()
    }

    @JavascriptInterface
    fun loadBannerAd(adUnitId: String) {
        adsLoadBanner(adUnitId)
    }

    @JavascriptInterface
    fun loadBannerAd(adUnitId: String, position: String) {
        adsLoadBanner(adUnitId, position)
    }

    @JavascriptInterface
    fun adsShowBanner() {
        showBannerAd()
    }

    @JavascriptInterface
    fun adsShowBanner(position: String) {
        showBannerAd(position)
    }

    @JavascriptInterface
    fun showBannerAd() {
        adMobBridge?.showBanner()
    }

    @JavascriptInterface
    fun showBannerAd(position: String) {
        adMobBridge?.let {
            it.setBannerPosition(position)
            it.showBanner()
        }
    }

    @JavascriptInterface
    fun adsHideBanner() {
        adMobBridge?.hideBanner()
    }

    @JavascriptInterface
    fun hideBannerAd() {
        adsHideBanner()
    }

    @JavascriptInterface
    fun isBannerAdLoaded(): Boolean {
        return adMobBridge?.isBannerLoaded() ?: false
    }

    // --- HTTP Cleartext Bridge ---
    @JavascriptInterface
    fun httpGet(url: String, callbackId: String) {
        Thread {
            try {
                var currentUrl = url
                var redirects = 0
                var conn: java.net.HttpURLConnection
                while (true) {
                    val urlObj = java.net.URL(currentUrl)
                    conn = urlObj.openConnection() as java.net.HttpURLConnection
                    conn.instanceFollowRedirects = false
                    conn.connectTimeout = 15000
                    conn.readTimeout = 30000
                    try {
                        conn.setRequestProperty("User-Agent", activity.webView.settings.userAgentString)
                    } catch (_: Throwable) {}
                    conn.connect()
                    val code = conn.responseCode
                    if ((code in 301..303 || code == 307 || code == 308) && redirects < 5) {
                        val location = conn.getHeaderField("Location")
                        if (!location.isNullOrBlank()) {
                            currentUrl = java.net.URL(urlObj, location).toString()
                            redirects++
                            conn.disconnect()
                            continue
                        }
                    }
                    break
                }
                val stream = if (conn.responseCode in 200..299) conn.inputStream else (conn.errorStream ?: conn.inputStream)
                val body = stream?.bufferedReader()?.use { it.readText() } ?: ""
                emit("httpResult", JSONObject().apply {
                    put("callbackId", callbackId)
                    put("status", conn.responseCode)
                    put("body", body)
                    put("success", conn.responseCode in 200..299)
                })
            } catch (e: Exception) {
                emit("httpResult", JSONObject().apply {
                    put("callbackId", callbackId)
                    put("success", false)
                    put("error", e.message ?: "Network error")
                })
            }
        }.start()
    }

    private fun runOnUiThread(action: () -> Unit) {
        mainHandler.post(action)
    }

    private fun sensorTypeToInt(type: String): Int {
        return when (type.lowercase(Locale.ROOT)) {
            "accelerometer" -> Sensor.TYPE_ACCELEROMETER
            "gyroscope" -> Sensor.TYPE_GYROSCOPE
            "magnetometer" -> Sensor.TYPE_MAGNETIC_FIELD
            "stepcounter" -> Sensor.TYPE_STEP_COUNTER
            "orientation" -> Sensor.TYPE_ROTATION_VECTOR
            "light" -> Sensor.TYPE_LIGHT
            "proximity" -> Sensor.TYPE_PROXIMITY
            else -> -1
        }
    }

    private fun base64ToBitmap(base64: String): android.graphics.Bitmap? {
        return try {
            val clean = base64.substringAfter(",")
            val bytes = android.util.Base64.decode(clean, android.util.Base64.DEFAULT)
            android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
        } catch (_: Exception) {
            null
        }
    }

    // --- Blob downloads ---

    /**
     * Called from the injected click interceptor in WebViewActivity when the
     * user taps (or JS clicks) an <a download> element pointing to a blob: URL.
     * Fetches the blob via JS, converts it to a data URL and forwards it to
     * onBlobDownloaded(...) for persistence through MediaStore.
     */
    @JavascriptInterface
    fun downloadBlobUrl(blobUrl: String, fileName: String, mimeType: String) {
        if (blobUrl.startsWith("data:")) {
            activity.downloadDataUri(blobUrl, fileName, mimeType)
            return
        }
        val safeUrl = JSONObject.quote(blobUrl)
        val safeFileName = JSONObject.quote(fileName)
        val safeMimeType = JSONObject.quote(mimeType)
        val script = """
            (function() {
                const url = ${safeUrl};
                fetch(url)
                    .then(response => response.blob())
                    .then(blob => {
                        const reader = new FileReader();
                        reader.onloadend = function() {
                            if (typeof AndroidAPI !== 'undefined' && AndroidAPI.onBlobDownloaded) {
                                AndroidAPI.onBlobDownloaded(reader.result, ${safeFileName}, blob.type || ${safeMimeType});
                            }
                        };
                        reader.onerror = function() {
                            if (typeof AndroidAPI !== 'undefined' && AndroidAPI.onBlobDownloadError) {
                                AndroidAPI.onBlobDownloadError('Failed to read blob');
                            }
                        };
                        reader.readAsDataURL(blob);
                    })
                    .catch(error => {
                        if (typeof AndroidAPI !== 'undefined' && AndroidAPI.onBlobDownloadError) {
                            AndroidAPI.onBlobDownloadError(error.message || 'Failed to fetch blob');
                        }
                    });
            })();
        """.trimIndent()
        activity.runOnUiThread {
            activity.webView.evaluateJavascript(script, null)
        }
    }

    @JavascriptInterface
    fun downloadDataUri(dataUri: String, fileName: String, mimeType: String) {
        activity.downloadDataUri(dataUri, fileName, mimeType)
    }

    @JavascriptInterface
    fun onBlobDownloaded(dataUrl: String, fileName: String, mimeType: String) {
        activity.downloadDataUri(dataUrl, fileName, mimeType)
    }

    @JavascriptInterface
    fun onBlobDownloadError(message: String) {
        android.util.Log.e("AndroidAPI", "Blob download error: $message")
        emit("blobDownloadError", JSONObject().apply {
            put("message", message)
        })
    }
}
