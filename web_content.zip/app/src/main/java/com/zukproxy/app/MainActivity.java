package com.zukproxy.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.graphics.Color;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        window.setStatusBarColor(Color.rgb(8, 8, 8));
        window.setNavigationBarColor(Color.rgb(8, 8, 8));
        window.getDecorView().setSystemUiVisibility(0);

        WebView webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(8, 8, 8));
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(false);
        webView.loadUrl("file:///android_asset/index.html");
        setContentView(webView);
    }
}
