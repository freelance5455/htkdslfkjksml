package com.forgefps.ultra;

import android.Manifest;
import android.animation.ValueAnimator;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.*;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.*;
import android.widget.EditText;
import java.util.*;
import rikka.shizuku.Shizuku;

class MainActivityNative extends Activity {
    ForgeView view;
    android.content.SharedPreferences prefs;
    static final int REQ_SHIZUKU = 1001;
    final Shizuku.OnRequestPermissionResultListener shizukuPermissionListener = (requestCode, grantResult) -> runOnUiThread(() -> { if (view != null) view.invalidate(); });

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        prefs = getSharedPreferences("forge", MODE_PRIVATE);
        view = new ForgeView(this);
        setContentView(view);
        if (prefs.getBoolean("intro", true)) view.playIntro();
        Shizuku.addBinderReceivedListenerSticky(() -> runOnUiThread(view::invalidate));
        Shizuku.addBinderDeadListener(() -> runOnUiThread(view::invalidate));
        Shizuku.addRequestPermissionResultListener(shizukuPermissionListener);
    }

    @Override protected void onDestroy() {
        try { Shizuku.removeRequestPermissionResultListener(shizukuPermissionListener); } catch (Throwable ignored) {}
        super.onDestroy();
    }

    void requestShizuku() {
        try {
            if (!Shizuku.pingBinder()) return;
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) return;
            Shizuku.requestPermission(REQ_SHIZUKU);
        } catch (Throwable ignored) { }
    }

    void openBatterySettings() {
        try { startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)); }
        catch (Exception e) { startActivity(new Intent(Settings.ACTION_SETTINGS)); }
    }

    void openAppSettings() {
        Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()));
        startActivity(i);
    }

    void addGame() {
        final EditText input = new EditText(this);
        input.setSingleLine(true); input.setHint("Game name");
        AlertDialog d = new AlertDialog.Builder(this).setTitle("Add Game").setView(input)
                .setNegativeButton("Cancel", null).setPositiveButton("Add", null).create();
        d.setOnShowListener(x -> d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String n = input.getText().toString().trim(); if (n.isEmpty()) return;
            view.games.add(new GameProfile(n)); view.activeGame = view.games.size()-1; view.save(); d.dismiss(); view.invalidate();
        })); d.show();
    }

    class ForgeView extends View {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG); Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
        int screen=0; // 0 home, 1 booster, 2 profiles, 3 bubbles, 4 wall, 5 settings, 6 tools
        boolean intro=true; float introProgress=0f; ValueAnimator animator;
        boolean bubbles; int target=120; String mode="Performance"; int activeGame=0;
        ArrayList<GameProfile> games=new ArrayList<>(); ArrayList<String> bubbleNames=new ArrayList<>(); ArrayList<String> wall=new ArrayList<>();
        float downX,downY; int dragIndex=-1;

        ForgeView(Context c) { super(c); p.setTypeface(Typeface.create("sans", Typeface.NORMAL)); stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeWidth(2); load(); setFocusable(true); }
        void load(){
            bubbles=prefs.getBoolean("bubbles",true); target=prefs.getInt("target",120); mode=prefs.getString("mode","Performance");
            String gs=prefs.getString("games", "Minecraft Bedrock~120~Performance|Roblox~120~Performance");
            for(String g:gs.split("\\|")){String[] a=g.split("~",-1);if(a.length>=3){GameProfile gp=new GameProfile(a[0]);try{gp.target=Integer.parseInt(a[1]);}catch(Exception ignored){}gp.mode=a[2];games.add(gp);}}
            if (games.isEmpty()){ games.add(new GameProfile("Minecraft Bedrock")); games.add(new GameProfile("Roblox")); }
            String bs=prefs.getString("bubble_names","FPS|PERFORMANCE|DISPLAY|GAMING|SHIZUKU|TOOLS"); bubbleNames.addAll(Arrays.asList(bs.split("\\|")));
            String ws=prefs.getString("wall","FPS Booster|FPS Uncap|Game Profiles|Theme Bubbles|Organized Wall|Shizuku|Power Saving"); wall.addAll(Arrays.asList(ws.split("\\|")));
        }
        void save(){
            StringBuilder b=new StringBuilder(); for(String s:bubbleNames){if(b.length()>0)b.append('|');b.append(s);} StringBuilder w=new StringBuilder(); for(String s:wall){if(w.length()>0)w.append('|');w.append(s);}
            StringBuilder g=new StringBuilder(); for(GameProfile gp:games){if(g.length()>0)g.append('|');g.append(gp.name.replace("|"," ")).append("~").append(gp.target).append("~").append(gp.mode.replace("|"," "));}
            prefs.edit().putBoolean("bubbles",bubbles).putInt("target",target).putString("mode",mode).putString("bubble_names",b.toString()).putString("wall",w.toString()).putString("games",g.toString()).apply();
        }
        void playIntro(){ intro=true; screen=0; animator=ValueAnimator.ofFloat(0,1); animator.setDuration(1750); animator.addUpdateListener(a->{introProgress=(float)a.getAnimatedValue();invalidate();}); animator.addListener(new android.animation.AnimatorListenerAdapter(){public void onAnimationEnd(android.animation.Animator a){intro=false;invalidate();}}); animator.start(); }
        float sx(){return getWidth()/1080f;} float sy(){return getHeight()/1920f;} float u(){return Math.min(sx(),sy());}
        void txt(Canvas c,String s,float x,float y,float size,boolean bold){p.setStyle(Paint.Style.FILL);p.setColor(Color.WHITE);p.setTextSize(size*u());p.setTypeface(Typeface.create("sans",bold?Typeface.BOLD:Typeface.NORMAL));c.drawText(s,x*u(),y*u(),p);}
        void box(Canvas c,float l,float t,float r,float b,float rad){p.setStyle(Paint.Style.FILL);p.setColor(Color.rgb(18,18,18));c.drawRoundRect(l*u(),t*u(),r*u(),b*u(),rad*u(),rad*u(),p);stroke.setColor(Color.rgb(65,65,65));stroke.setStrokeWidth(2*u());c.drawRoundRect(l*u(),t*u(),r*u(),b*u(),rad*u(),rad*u(),stroke);}
        void button(Canvas c,String s,float l,float t,float r,float b){box(c,l,t,r,b,26); txt(c,s,l+28,t+47,30,true);}
        @Override protected void onDraw(Canvas c){super.onDraw(c);c.drawColor(Color.BLACK); if(intro){drawIntro(c);return;} drawMain(c);}
        void drawIntro(Canvas c){
            float W=getWidth(),H=getHeight(); float pr=introProgress; p.setColor(Color.WHITE);p.setStrokeWidth(Math.max(3,8*u()));p.setStyle(Paint.Style.STROKE);
            float cx=W/2,cy=H/2; RectF r=new RectF(cx-150*u(),cy-150*u(),cx+150*u(),cy+150*u()); c.drawArc(r,-90,Math.min(360,pr*440),false,p);
            if(pr>.18f){Path q=new Path();q.moveTo(cx-95*u(),cy+65*u());q.lineTo(cx-25*u(),cy-70*u());q.lineTo(cx+100*u(),cy-70*u());q.lineTo(cx+40*u(),cy-8*u());q.lineTo(cx-10*u(),cy-8*u());q.lineTo(cx-35*u(),cy+40*u());q.lineTo(cx+48*u(),cy+40*u());q.lineTo(cx-15*u(),cy+105*u());q.close();c.drawPath(q,p);}
            if(pr>.62f){txt(c,"ForgeFPS Ultra",cx/u()-205,cy/u()+250,54,true);} if(pr>.9f){p.setAlpha((int)(255*(pr-.9f)*10));c.drawColor(Color.BLACK);p.setAlpha(255);}
        }
        void header(Canvas c,String title){txt(c,title,64,92,44,true);txt(c,"ForgeFPS Ultra",64,140,24,false); if(screen!=0){txt(c,"‹",20,95,60,false);} }
        void drawMain(Canvas c){header(c,new String[]{"ForgeFPS Ultra","FPS Booster","Game Profiles","Theme Bubbles","Organized Wall","Settings","Game Tools"}[screen]);
            if(screen==0) home(c); else if(screen==1) booster(c); else if(screen==2) profiles(c); else if(screen==3) bubbles(c); else if(screen==4) wall(c); else if(screen==5) settings(c); else tools(c);
            if(screen==0){nav(c);}
        }
        void home(Canvas c){
            box(c,40,190,1040,680,34);txt(c,"FPS",90,270,28,false);txt(c,""+target,90,370,120,true);txt(c,"TARGET / REQUEST",94,415,23,false);txt(c,"Refresh rate: "+refresh()+" Hz",94,470,30,true);txt(c,"Mode: "+mode,94,520,26,false);button(c,"⚡ BOOST NOW",90,565,990,640);
            box(c,40,720,1040,1010,34);txt(c,"SHIZUKU",75,780,24,false);txt(c,shizukuState(),75,830,38,true);txt(c,"Performance: "+mode,75,885,28,false);txt(c,"Active: "+games.get(activeGame).name,75,935,28,false);
            button(c,"FPS BOOSTER",40,1060,520,1160);button(c,"GAME PROFILES",560,1060,1040,1160);button(c,"THEME BUBBLES",40,1190,520,1290);button(c,"ORGANIZED WALL",560,1190,1040,1290);
        }
        String shizukuState(){try{if(!Shizuku.pingBinder())return "Unavailable"; if(Shizuku.checkSelfPermission()!=PackageManager.PERMISSION_GRANTED)return "Permission Required";return "Connected";}catch(Throwable e){return "Unavailable";}}
        int refresh(){try{android.view.Display d=getDisplay(); if(d!=null)return Math.round(d.getRefreshRate());}catch(Exception ignored){}return 60;}
        void booster(Canvas c){
            txt(c,"FPS MODE",60,230,24,false); String[] ms={"Standard","Performance","Maximum FPS","Custom"}; for(int i=0;i<4;i++){float y=270+i*100;box(c,50,y,1030,y+82,22);txt(c,(mode.equals(ms[i])?"● ":"○ ")+ms[i],80,y+52,28,true);}
            txt(c,"FPS TARGET",60,720,24,false);String[] ts={"60","90","120","144","165","Device Maximum","Uncapped"}; for(int i=0;i<ts.length;i++){int col=i%3,row=i/3;float l=55+col*335,t=760+row*92;box(c,l,t,l+310,t+70,20);txt(c,(String.valueOf(target).equals(ts[i])?"● ":"○ ")+ts[i],l+22,t+46,25,true);}
            button(c,"APPLY",55,1010,1025,1095);box(c,55,1140,1025,1370,28);txt(c,"FPS UNCAP",85,1190,28,true);txt(c,"Requests the highest legitimate display refresh",85,1235,23,false);txt(c,"without disabling Power Saving automatically.",85,1270,23,false);button(c,"REQUEST MAX REFRESH",85,1300,995,1360);
        }
        void profiles(Canvas c){
            for(int i=0;i<games.size();i++){float y=220+i*155;box(c,50,y,1030,y+125,28);txt(c,(i==activeGame?"● ":"○ ")+games.get(i).name,80,y+50,30,true);txt(c,"Target: "+games.get(i).target+"  •  "+games.get(i).mode,80,y+90,23,false);}button(c,"＋ ADD GAME",50,220+games.size()*155,1030,300+games.size()*155);txt(c,"Profiles are local and user-controlled.",65,1450,23,false);
        }
        void bubbles(Canvas c){
            txt(c,"Theme Bubbles  "+(bubbles?"ON":"OFF"),60,220,30,true);button(c,bubbles?"TURN OFF":"TURN ON",760,180,1030,250);
            for(int i=0;i<bubbleNames.size();i++){int col=i%2,row=i/2;float l=55+col*500,t=280+row*155;box(c,l,t,l+470,t+120,40);txt(c,bubbleNames.get(i),l+28,t+52,30,true);txt(c,"Tap to rename",l+28,t+88,20,false);}button(c,"＋ NEW BUBBLE",55,1250,1030,1335);txt(c,"Saved organization is never deleted when bubbles are OFF.",60,1410,22,false);
        }
        void wall(Canvas c){txt(c,"Drag settings to reorder",60,205,24,false);for(int i=0;i<wall.size();i++){float y=245+i*105;box(c,55,y,1025,y+82,24);txt(c,(i+1)+"   "+wall.get(i),85,y+52,27,true);}button(c,"＋ ADD GROUP",55,245+wall.size()*105,1030,325+wall.size()*105);}
        void settings(Canvas c){
            box(c,50,205,1030,310,28);txt(c,"Startup Animation",80,255,28,true);txt(c,prefs.getBoolean("intro",true)?"ON":"OFF",840,255,25,true);
            button(c,"REPLAY INTRO",50,335,1030,420);button(c,"BATTERY OPTIMIZATION",50,450,1030,535);button(c,"APP PERMISSIONS",50,565,1030,650);button(c,"SHIZUKU",50,680,1030,765);button(c,"ABOUT / LIMITATIONS",50,795,1030,880);
            txt(c,"Offline-first • local profiles • no hidden system changes",60,950,21,false);
        }
        void tools(Canvas c){button(c,"FPS UNCAP",55,220,1025,320);button(c,"REFRESH RATE",55,345,1025,445);button(c,"POWER-SAVING COMPATIBILITY",55,470,1025,570);button(c,"SYSTEM APP SETTINGS",55,595,1025,695);box(c,55,750,1025,940,28);txt(c,"Device",85,800,24,false);txt(c,Build.MANUFACTURER+" "+Build.MODEL,85,845,28,true);txt(c,"Android "+Build.VERSION.RELEASE+" • API "+Build.VERSION.SDK_INT,85,890,22,false);}
        void nav(Canvas c){String[] n={"HOME","BOOST","TOOLS","SETTINGS"};for(int i=0;i<4;i++){float l=20+i*270;txt(c,n[i],l,1535,22,i==0);}}
        void renameBubble(int idx){final EditText e=new EditText(MainActivityNative.this);e.setText(bubbleNames.get(idx));e.setSingleLine(true);new AlertDialog.Builder(MainActivityNative.this).setTitle("Rename Bubble").setView(e).setNegativeButton("Cancel",null).setPositiveButton("Save",(d,w)->{String s=e.getText().toString().trim();if(!s.isEmpty()){bubbleNames.set(idx,s);save();invalidate();}}).show();}
        @Override public boolean onTouchEvent(android.view.MotionEvent ev){float x=ev.getX()/u(),y=ev.getY()/u(); if(ev.getAction()==MotionEvent.ACTION_DOWN){downX=x;downY=y;dragIndex=-1;return true;} if(ev.getAction()!=MotionEvent.ACTION_UP)return true;
            if(intro)return true;
            if(screen==0){if(y>560&&y<660){screen=1;}else if(y>1040&&y<1180&&x>540){screen=2;}else if(y>1180&&y<1320&&x<540){screen=3;}else if(y>1180&&y<1320){screen=4;}else if(y>1040&&y<1180&&x<540){screen=1;}else if(y>1480&&x>780){screen=5;} invalidate();return true;}
            if(screen>0&&x<120&&y<130){screen=0;invalidate();return true;}
            if(screen==1){if(y>270&&y<680){int i=(int)((y-270)/100);String[] ms={"Standard","Performance","Maximum FPS","Custom"};if(i>=0&&i<4)mode=ms[i];}
                if(y>760&&y<1040){int col=(int)((x-55)/335),row=(int)((y-760)/92);int i=row*3+col;String[] ts={"60","90","120","144","165","Device Maximum","Uncapped"};if(i>=0&&i<ts.length){target=(i<5?Integer.parseInt(ts[i]):refresh());}}
                if(y>1010&&y<1100){games.get(activeGame).target=target;games.get(activeGame).mode=mode;save();}
                if(y>1290&&y<1390){requestMaxRefresh();} invalidate();return true;}
            if(screen==2){for(int i=0;i<games.size();i++){float yy=220+i*155;if(y>yy&&y<yy+125){activeGame=i;save();invalidate();return true;}} if(y>220+games.size()*155){addGame();}return true;}
            if(screen==3){if(y>180&&y<270&&x>730){bubbles=!bubbles;save();invalidate();return true;}for(int i=0;i<bubbleNames.size();i++){int col=i%2,row=i/2;float l=55+col*500,t=280+row*155;if(x>l&&x<l+470&&y>t&&y<t+120){renameBubble(i);return true;}}if(y>1200){bubbleNames.add("NEW");save();invalidate();}return true;}
            if(screen==4){for(int i=0;i<wall.size();i++){float yy=245+i*105;if(y>yy&&y<yy+82){if(downY!=y){int to=Math.max(0,Math.min(wall.size()-1,(int)((y-245)/105)));String s=wall.remove(i);wall.add(to,s);save();invalidate();}return true;}}if(y>245+wall.size()*105){wall.add("New Setting");save();invalidate();}return true;}
            if(screen==5){if(y>330&&y<440){playIntro();}else if(y>440&&y<550){openBatterySettings();}else if(y>550&&y<670){openAppSettings();}else if(y>670&&y<780){requestShizuku();}else if(y>780&&y<900){new AlertDialog.Builder(MainActivityNative.this).setTitle("ForgeFPS Ultra").setMessage("1.0.0\n\nAndroid min 26 • target 35\n\nAndroid/game/thermal limits may prevent requested FPS. ForgeFPS Ultra does not fabricate in-game FPS or bypass permissions.").setPositiveButton("OK",null).show();}return true;}
            if(screen==6){if(y>210&&y<340)requestMaxRefresh();else if(y>450&&y<590)requestMaxRefresh();else if(y>570&&y<720)openAppSettings();return true;}return true; }
        void requestMaxRefresh(){try{Window w=getWindow();if(Build.VERSION.SDK_INT>=30){Display d=getDisplay();if(d!=null){android.view.Display.Mode[] ms=d.getSupportedModes();float best=0;for(android.view.Display.Mode m:ms)best=Math.max(best,m.getRefreshRate()); if(best>0)w.setPreferredDisplayModeId(Arrays.stream(ms).filter(m->Math.abs(m.getRefreshRate()-best)<0.5f).findFirst().get().getModeId());}}}catch(Exception ignored){}invalidate();}
    }
    static class GameProfile {String name,mode="Performance";int target=120;GameProfile(String n){name=n;}}
}
