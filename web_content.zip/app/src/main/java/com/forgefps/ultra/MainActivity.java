package com.forgefps.ultra;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Display;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.util.Arrays;
import rikka.shizuku.Shizuku;

/** ForgeFPS Ultra web/native hybrid shell. The UI lives in assets/index.html;
 * Android-only capabilities are exposed through the small, user-authorized bridge. */
public class MainActivity extends Activity {
    private WebView webView;
    private static final int REQ_SHIZUKU = 1001;

    private final Shizuku.OnRequestPermissionResultListener shizukuListener =
            (requestCode, grantResult) -> runOnUiThread(this::pushNativeState);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        Window w = getWindow();
        w.setStatusBarColor(Color.BLACK);
        w.setNavigationBarColor(Color.BLACK);

        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        webView.setBackgroundColor(Color.BLACK);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AndroidBridge(), "ForgeAndroid");
        setContentView(webView);
        Shizuku.addBinderReceivedListenerSticky(() -> runOnUiThread(this::pushNativeState));
        Shizuku.addBinderDeadListener(() -> runOnUiThread(this::pushNativeState));
        Shizuku.addRequestPermissionResultListener(shizukuListener);
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override protected void onResume() {
        super.onResume();
        pushNativeState();
    }

    @Override protected void onDestroy() {
        try { Shizuku.removeRequestPermissionResultListener(shizukuListener); } catch (Throwable ignored) {}
        if (webView != null) webView.destroy();
        super.onDestroy();
    }

    private void pushNativeState() {
        if (webView == null) return;
        String status = shizukuStatus();
        String device = Build.MANUFACTURER + " " + Build.MODEL;
        int hz = refreshRate();
        String js = "window.ForgeNativeState && window.ForgeNativeState(" +
                "'" + esc(status) + "','" + esc(device) + "'," + hz + ");";
        webView.post(() -> webView.evaluateJavascript(js, null));
    }

    private static String esc(String s) { return s.replace("\\", "\\\\").replace("'", "\\'"); }

    private String shizukuStatus() {
        try {
            if (!Shizuku.pingBinder()) return "Unavailable";
            return Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
                    ? "Connected" : "Permission Required";
        } catch (Throwable e) { return "Unavailable"; }
    }

    private int refreshRate() {
        try {
            Display d = getWindowManager().getDefaultDisplay();
            return Math.round(d.getRefreshRate());
        } catch (Throwable ignored) { return 60; }
    }

    private void requestShizuku() {
        try {
            if (!Shizuku.pingBinder()) { toast("Shizuku is unavailable"); return; }
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                toast("Shizuku already connected"); return;
            }
            Shizuku.requestPermission(REQ_SHIZUKU);
        } catch (Throwable e) { toast("Unable to request Shizuku permission"); }
    }

    private void openBatterySettings() {
        try { startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)); }
        catch (Exception e) { startActivity(new Intent(Settings.ACTION_SETTINGS)); }
    }

    private void openAppSettings() {
        startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.parse("package:" + getPackageName())));
    }

    private void requestMaxRefresh() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                Display d = getWindowManager().getDefaultDisplay();
                Display.Mode[] modes = d.getSupportedModes();
                Display.Mode best = Arrays.stream(modes)
                        .max((a,b) -> Float.compare(a.getRefreshRate(), b.getRefreshRate()))
                        .orElse(null);
                if (best != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    getWindow().setPreferredDisplayModeId(best.getModeId());
                }
                toast(best == null ? "Display limit unavailable" :
                        "Requested max refresh: " + Math.round(best.getRefreshRate()) + " Hz");
            }
        } catch (Throwable e) { toast("Maximum refresh request unsupported on this device"); }
        pushNativeState();
    }

    private void toast(String message) { Toast.makeText(this, message, Toast.LENGTH_SHORT).show(); }

    public class AndroidBridge {
        @JavascriptInterface public void requestShizuku() { runOnUiThread(MainActivity.this::requestShizuku); }
        @JavascriptInterface public void openBatterySettings() { runOnUiThread(MainActivity.this::openBatterySettings); }
        @JavascriptInterface public void openAppSettings() { runOnUiThread(MainActivity.this::openAppSettings); }
        @JavascriptInterface public void requestMaxRefresh() { runOnUiThread(MainActivity.this::requestMaxRefresh); }
        @JavascriptInterface public String shizukuStatus() { return MainActivity.this.shizukuStatus(); }
        @JavascriptInterface public int refreshRate() { return MainActivity.this.refreshRate(); }
        @JavascriptInterface public String deviceName() { return Build.MANUFACTURER + " " + Build.MODEL; }
    }
}
