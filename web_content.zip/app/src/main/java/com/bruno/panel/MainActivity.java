package com.bruno.panel;
import android.app.*; import android.os.*; import android.provider.Settings; import android.content.*; import android.net.Uri;
import android.webkit.*;
public class MainActivity extends Activity {
 WebView w;
 @Override public void onCreate(Bundle b){super.onCreate(b); w=new WebView(this); setContentView(w);
 w.getSettings().setJavaScriptEnabled(true); w.addJavascriptInterface(new Bridge(),"BrunoAndroid");
 w.loadUrl("file:///android_asset/index.html");}
 class Bridge {
  @JavascriptInterface public void requestOverlay(){
   if(!Settings.canDrawOverlays(MainActivity.this)){
    startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName())));
   } else startService(new Intent(MainActivity.this,FloatingService.class));
  }
  @JavascriptInterface public void stopOverlay(){stopService(new Intent(MainActivity.this,FloatingService.class));}
 }
 @Override protected void onResume(){super.onResume(); if(Settings.canDrawOverlays(this)) startService(new Intent(this,FloatingService.class));}
}