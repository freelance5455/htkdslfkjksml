package com.bruno.panel;
import android.app.*; import android.os.*; import android.content.*; import android.graphics.*; import android.graphics.PixelFormat; import android.provider.Settings; import android.view.*; import android.widget.*;
public class FloatingService extends Service {
 WindowManager wm; TextView v; WindowManager.LayoutParams p;
 public void onCreate(){super.onCreate(); if(!Settings.canDrawOverlays(this)){stopSelf();return;}
 wm=(WindowManager)getSystemService(WINDOW_SERVICE); v=new TextView(this); v.setText("BP");v.setTextColor(Color.WHITE);v.setTextSize(16);v.setGravity(Gravity.CENTER);v.setBackgroundColor(Color.DKGRAY);
 int type=Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;
 p=new WindowManager.LayoutParams(72,72,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT);p.gravity=Gravity.TOP|Gravity.START;p.x=30;p.y=180;
 v.setOnTouchListener(new View.OnTouchListener(){float dx,dy;int sx,sy;public boolean onTouch(View x,MotionEvent e){if(e.getAction()==0){dx=e.getRawX();dy=e.getRawY();sx=p.x;sy=p.y;return true;}if(e.getAction()==2){p.x=sx+(int)(e.getRawX()-dx);p.y=sy+(int)(e.getRawY()-dy);wm.updateViewLayout(v,p);return true;}if(e.getAction()==1&&Math.abs(e.getRawX()-dx)<15&&Math.abs(e.getRawY()-dy)<15){Intent i=new Intent(FloatingService.this,MainActivity.class);i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(i);return true;}return true;}});
 wm.addView(v,p);}
 public void onDestroy(){if(wm!=null&&v!=null)try{wm.removeView(v);}catch(Exception e){}super.onDestroy();}
 public IBinder onBind(Intent i){return null;}
}