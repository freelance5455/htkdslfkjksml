package com.naurokai.assistant;
import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.WindowManager;
import android.widget.TextView;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;

public class OverlayService extends Service {
    private WindowManager wm;
    private TextView button;
    private WindowManager.LayoutParams params;
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        if(button!=null)return START_STICKY;
        if(!Settings.canDrawOverlays(this)){stopSelf();return START_NOT_STICKY;}
        wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        button=new TextView(this);button.setText("✦ AI");button.setTextColor(Color.WHITE);button.setTextSize(16);button.setGravity(Gravity.CENTER);
        GradientDrawable bg=new GradientDrawable();bg.setColor(Color.rgb(49,92,222));bg.setCornerRadius(50);button.setBackground(bg);
        params=new WindowManager.LayoutParams(150,150,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT);
        params.gravity=Gravity.TOP|Gravity.START;params.x=25;params.y=250;
        button.setOnTouchListener(new android.view.View.OnTouchListener(){float downX,downY;int originX,originY;boolean moved;
            @Override public boolean onTouch(android.view.View v,MotionEvent e){switch(e.getAction()){
                case MotionEvent.ACTION_DOWN:downX=e.getRawX();downY=e.getRawY();originX=params.x;originY=params.y;moved=false;return true;
                case MotionEvent.ACTION_MOVE:if(Math.abs(e.getRawX()-downX)>12||Math.abs(e.getRawY()-downY)>12)moved=true;params.x=originX+(int)(e.getRawX()-downX);params.y=originY+(int)(e.getRawY()-downY);wm.updateViewLayout(button,params);return true;
                case MotionEvent.ACTION_UP:if(!moved){Intent open=new Intent(OverlayService.this,MainActivity.class);open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);startActivity(open);}return true;
            }return false;}});
        wm.addView(button,params);return START_STICKY;
    }
    @Override public void onDestroy(){if(wm!=null&&button!=null){wm.removeView(button);button=null;}super.onDestroy();}
    @Override public IBinder onBind(Intent i){return null;}
}
