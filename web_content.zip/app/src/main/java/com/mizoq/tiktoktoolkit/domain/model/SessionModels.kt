package com.mizoq.tiktoktoolkit.domain.model

import com.mizoq.tiktoktoolkit.config.MizoBrandConfig

/**
 * Primary automation queue states matching V5.0 + native Android lifecycle requirements.
 */
enum class QueueStatus(val wireValue: String, val displayLabel: String) {
    IDLE("idle", "Idle"),
    SCANNING("scanning", "Scanning TikTok List"),
    PROCESSING("processing", "Processing Queue"),
    PAUSED("paused", "Paused"),
    RECOVERING("recovering", "Recovering State"),
    RATE_LIMITED("rate_limited", "Rate Limited — Paused"),
    VERIFICATION_REQUIRED("verification_required", "Verification Required"),
    COMPLETED("completed", "Completed"),
    STOPPED("stopped", "Stopped"),
    FAILED("failed", "Failed");

    val isActiveRun: Boolean
        get() = this == SCANNING || this == PROCESSING

    val canResume: Boolean
        get() = this == PAUSED || this == RECOVERING || this == VERIFICATION_REQUIRED || this == RATE_LIMITED

    val canStop: Boolean
        get() = this == SCANNING || this == PROCESSING || this == PAUSED ||
            this == RECOVERING || this == VERIFICATION_REQUIRED || this == RATE_LIMITED

    companion object {
        fun fromWireValue(value: String?): QueueStatus =
            entries.firstOrNull { it.wireValue.equals(value, ignoreCase = true) } ?: IDLE
    }
}

/**
 * Native Android execution environment state.
 */
enum class ExecutionState(val wireValue: String, val badgeText: String) {
    STANDBY("standby", "Standby"),
    ACTIVELY_PROCESSING("actively_processing", "Actively Processing"),
    SUSPENDED_BY_OS("suspended_by_os", "TikTok Backgrounded / Paused"),
    AWAITING_VERIFICATION("awaiting_verification", "Awaiting Manual Verification");

    companion object {
        fun fromWireValue(value: String?): ExecutionState =
            entries.firstOrNull { it.wireValue.equals(value, ignoreCase = true) } ?: STANDBY
    }
}

enum class ExecutionMode(val wireValue: String, val displayLabel: String) {
    AUTO("auto", "Automated Verified Tap"),
    GUIDED("guided", "Guided Step-by-Step Assist")
}

enum class FollowerRemovalMethod(val wireValue: String, val displayLabel: String) {
    NATIVE_REMOVE("native_remove", "TikTok Native 'Remove this follower'"),
    GUIDED_BLOCK_UNBLOCK("guided_block_unblock", "Guided Manual / Block-Unblock Assist")
}

enum class ThemeVariant(val wireValue: String, val displayLabel: String) {
    MIDNIGHT_NEBULA("midnight_nebula", "Midnight Nebula (Default)"),
    CYBER_INDIGO("cyber_indigo", "Cyber Indigo"),
    OBSIDIAN_GLASS("obsidian_glass", "Obsidian Glass");

    companion object {
        fun fromWireValue(value: String?): ThemeVariant =
            entries.firstOrNull { it.wireValue.equals(value, ignoreCase = true) } ?: MIDNIGHT_NEBULA
    }
}

data class SessionCounts(
    val scanned: Int = 0,
    val queued: Int = 0,
    val completed: Int = 0,
    val skipped: Int = 0,
    val pending: Int = 0,
    val failed: Int = 0,
    val uncertain: Int = 0,
    val mutualProtected: Int = 0,
    val uncertainSkipped: Int = 0,
    val configuredLimit: Int = 100
) {
    val remaining: Int
        get() = (configuredLimit - completed).coerceAtLeast(0)

    val failedAndUncertain: Int
        get() = failed + uncertain

    val progressFraction: Float
        get() = if (configuredLimit <= 0) 0f else (completed.toFloat() / configuredLimit.toFloat()).coerceIn(0f, 1f)

    val progressPercent: Int
        get() = (progressFraction * 100f).toInt().coerceIn(0, 100)
}

data class SessionMetrics(
    val sessionStartEpochMs: Long? = null,
    val accumulatedElapsedMs: Long = 0L,
    val lastResumeEpochMs: Long? = null,
    val discoveredPerMin: Double = 0.0,
    val completedPerMin: Double = 0.0,
    val elapsedFormatted: String = "0s"
)

data class SessionSettings(
    val minDelayMs: Long = 2000L,
    val maxDelayMs: Long = 4000L,
    val maxActionsPerSession: Int = 100,
    val maxScanDurationSec: Int = 3600,
    val skipMutuals: Boolean = true,
    val autoOpenList: Boolean = true,
    val autoScan: Boolean = true,
    val autoScroll: Boolean = true,
    val autoExportCsv: Boolean = true,
    val notificationsEnabled: Boolean = true,
    val criticalNotificationsOnly: Boolean = false,
    val reducedMotion: Boolean = false,
    val ambientOrbs: Boolean = true,
    val themeVariant: ThemeVariant = ThemeVariant.MIDNIGHT_NEBULA,
    val confirmBulkActions: Boolean = true,
    val executionMode: ExecutionMode = ExecutionMode.AUTO,
    val followerRemovalMethod: FollowerRemovalMethod = FollowerRemovalMethod.NATIVE_REMOVE
) {
    fun validateAndSanitize(): Pair<SessionSettings, List<String>> {
        val errors = mutableListOf<String>()
        val safeMin = if (minDelayMs in 0L..60_000L) minDelayMs else {
            errors.add("Minimum delay must be between 0 ms and 60,000 ms.")
            minDelayMs.coerceIn(0L, 60_000L)
        }
        val safeMax = if (maxDelayMs in 0L..120_000L && maxDelayMs >= safeMin) maxDelayMs else {
            errors.add("Maximum delay must be between $safeMin ms and 120,000 ms.")
            maxDelayMs.coerceIn(safeMin, 120_000L)
        }
        val safeLimit = if (maxActionsPerSession in 1..MizoBrandConfig.MAX_SESSION_LIMIT) maxActionsPerSession else {
            errors.add("Session action limit must be between 1 and ${MizoBrandConfig.MAX_SESSION_LIMIT}.")
            maxActionsPerSession.coerceIn(1, MizoBrandConfig.MAX_SESSION_LIMIT)
        }
        val safeDuration = if (maxScanDurationSec in 10..86_400) maxScanDurationSec else {
            errors.add("Max scan duration must be between 10 and 86,400 seconds.")
            maxScanDurationSec.coerceIn(10, 86_400)
        }
        return copy(
            minDelayMs = safeMin,
            maxDelayMs = safeMax,
            maxActionsPerSession = safeLimit,
            maxScanDurationSec = safeDuration
        ) to errors
    }
}

data class SessionState(
    val sessionId: String? = null,
    val status: QueueStatus = QueueStatus.IDLE,
    val executionState: ExecutionState = ExecutionState.STANDBY,
    val workflowMode: WorkflowMode = WorkflowMode.FOLLOWING,
    val isSimulatedMode: Boolean = false,
    val activeTikTokPackage: String? = null,
    val profileUsername: String? = null,
    val inFlightUsername: String? = null,
    val hasUncertainActionInFlight: Boolean = false,
    val captchaResolvedReadyToResume: Boolean = false,
    val lastSuccessfulUsername: String? = null,
    val counts: SessionCounts = SessionCounts(),
    val metrics: SessionMetrics = SessionMetrics(),
    val consecutiveFailures: Int = 0,
    val interruptionReason: String? = null,
    val securityWarning: String? = null,
    val completionReport: String? = null,
    val lastExportFilename: String? = null,
    val lastExportStatus: String? = null
)
