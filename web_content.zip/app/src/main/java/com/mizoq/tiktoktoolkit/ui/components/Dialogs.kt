package com.mizoq.tiktoktoolkit.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mizoq.tiktoktoolkit.config.MizoBrandConfig
import com.mizoq.tiktoktoolkit.domain.model.SessionSettings
import com.mizoq.tiktoktoolkit.domain.model.WorkflowMode
import com.mizoq.tiktoktoolkit.ui.theme.MizoCyanHighlight
import com.mizoq.tiktoktoolkit.ui.theme.MizoMidnightSurface
import com.mizoq.tiktoktoolkit.ui.theme.MizoPurplePrimary
import com.mizoq.tiktoktoolkit.ui.theme.MizoRoseDanger
import com.mizoq.tiktoktoolkit.ui.theme.MizoTextPrimary
import com.mizoq.tiktoktoolkit.ui.theme.MizoTextSecondary

/**
 * Prominent disclosure dialog shown BEFORE sending the user to Android Overlay Settings.
 */
@Composable
fun OverlayPermissionExplanationDialog(
    onConfirmOpenSettings: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MizoMidnightSurface,
        title = {
            Text(
                text = "Why ${MizoBrandConfig.BRAND_NAME} Needs Overlay Permission",
                color = MizoCyanHighlight,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
        },
        text = {
            Column {
                Text(
                    text = "${MizoBrandConfig.PRODUCT_TITLE} uses Android's 'Display over other apps' permission solely to show the compact draggable Mizo_q control panel on top of TikTok.",
                    color = MizoTextPrimary,
                    fontSize = 13.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "• The floating panel uses FLAG_NOT_FOCUSABLE so it never secretly captures keyboard input or operates invisibly.\n" +
                        "• You can collapse or close the floating panel at any time using its visible Close (✕) button.",
                    color = MizoTextSecondary,
                    fontSize = 12.sp
                )
            }
        },
        confirmButton = {
            Button(
                onClick = onConfirmOpenSettings,
                colors = ButtonDefaults.buttonColors(containerColor = MizoPurplePrimary)
            ) {
                Text("Open Overlay Settings", color = Color.White)
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Not Now", color = MizoTextSecondary)
            }
        }
    )
}

/**
 * Prominent disclosure dialog shown BEFORE sending the user to Android Accessibility Settings.
 */
@Composable
fun AccessibilityPermissionExplanationDialog(
    onConfirmOpenSettings: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MizoMidnightSurface,
        title = {
            Text(
                text = "Prominent Disclosure: Accessibility Service",
                color = MizoCyanHighlight,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
        },
        text = {
            Column {
                Text(
                    text = "${MizoBrandConfig.PRODUCT_TITLE} uses Android's AccessibilityService API only when you explicitly start a session to:",
                    color = MizoTextPrimary,
                    fontSize = 13.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "1. Verify that the official TikTok Android app is in the foreground.\n" +
                        "2. Read visible @usernames, mutual badges ('Friends' / 'Follows you'), and button states in your open Following or Followers list.\n" +
                        "3. Perform sequential taps on verified row buttons and scroll the list.\n" +
                        "4. Detect CAPTCHA or verification dialogs so automation pauses immediately.",
                    color = MizoTextSecondary,
                    fontSize = 12.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Privacy Guarantee: Mizo_q never collects passwords, authentication tokens, cookies, or private messages, and never uploads account data off your device.",
                    color = MizoCyanHighlight,
                    fontSize = 11.5.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        },
        confirmButton = {
            Button(
                onClick = onConfirmOpenSettings,
                colors = ButtonDefaults.buttonColors(containerColor = MizoPurplePrimary)
            ) {
                Text("Open Accessibility Settings", color = Color.White)
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Cancel", color = MizoTextSecondary)
            }
        }
    )
}

/**
 * Pre-Session Confirmation Dialog for Bulk Unfollow or Follower Removal.
 */
@Composable
fun ConfirmStartSessionDialog(
    mode: WorkflowMode,
    settings: SessionSettings,
    isSimulated: Boolean,
    onConfirmStart: () -> Unit,
    onDismiss: () -> Unit
) {
    val isDestructiveFollowerRemove = mode == WorkflowMode.FOLLOWERS
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MizoMidnightSurface,
        title = {
            Text(
                text = "Confirm ${MizoBrandConfig.BRAND_NAME} Session — ${mode.displayTitle}",
                color = if (isDestructiveFollowerRemove) MizoRoseDanger else MizoCyanHighlight,
                fontWeight = FontWeight.Bold,
                fontSize = 15.5.sp
            )
        },
        text = {
            Column {
                Text(
                    text = "Review your V6.0 session parameters before starting:",
                    color = MizoTextPrimary,
                    fontSize = 13.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "• Target Mode: ${mode.displayTitle}${if (isSimulated) " (Simulated Test Run)" else ""}\n" +
                        "• Execution Mode: ${settings.executionMode.displayLabel}\n" +
                        "• Session Action Limit: Up to ${settings.maxActionsPerSession} actions\n" +
                        "• Skip Mutuals Protection: ${if (settings.skipMutuals) "ON (Protects Friends & Uncertain)" else "OFF"}\n" +
                        "• Action Pacing: ${settings.minDelayMs} ms – ${settings.maxDelayMs} ms\n" +
                        "• Auto CSV Export: ${if (settings.autoExportCsv) "Enabled on Stop & Completion" else "Manual"}",
                    color = MizoTextSecondary,
                    fontSize = 12.sp
                )
            }
        },
        confirmButton = {
            Button(
                onClick = onConfirmStart,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isDestructiveFollowerRemove) MizoRoseDanger else MizoPurplePrimary
                )
            ) {
                Text("Confirm & Start (Limit: ${settings.maxActionsPerSession})", color = Color.White)
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Cancel", color = MizoTextSecondary)
            }
        }
    )
}

/**
 * Confirmation dialog for Clear History and Reset Settings destructive operations.
 */
@Composable
fun ConfirmDestructiveActionDialog(
    title: String,
    message: String,
    confirmButtonLabel: String,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MizoMidnightSurface,
        title = {
            Text(
                text = title,
                color = MizoRoseDanger,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
        },
        text = {
            Text(text = message, color = MizoTextPrimary, fontSize = 13.sp)
        },
        confirmButton = {
            Button(
                onClick = onConfirm,
                colors = ButtonDefaults.buttonColors(containerColor = MizoRoseDanger)
            ) {
                Text(confirmButtonLabel, color = Color.White)
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Cancel", color = MizoTextSecondary)
            }
        }
    )
}
