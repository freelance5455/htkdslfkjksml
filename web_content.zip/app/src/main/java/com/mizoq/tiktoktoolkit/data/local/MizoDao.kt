package com.mizoq.tiktoktoolkit.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface MizoDao {

    // Queue Persistence (Supports up to 10,000 entries per session)
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertQueueItems(items: List<QueueItemEntity>): List<Long>

    @Query("SELECT * FROM queue_items WHERE sessionId = :sessionId ORDER BY id ASC")
    suspend fun getQueueItemsForSession(sessionId: String): List<QueueItemEntity>

    @Query("SELECT * FROM queue_items WHERE sessionId = :sessionId AND status = 'pending' ORDER BY id ASC LIMIT :limit")
    suspend fun getPendingQueueBatch(sessionId: String, limit: Int = 250): List<QueueItemEntity>

    @Query(
        """
        UPDATE queue_items
        SET status = :status, skipReason = :skipReason, errorDetails = :errorDetails
        WHERE sessionId = :sessionId AND normalizedUsername = :normalizedUsername
        """
    )
    suspend fun updateQueueItemStatus(
        sessionId: String,
        normalizedUsername: String,
        status: String,
        skipReason: String = "",
        errorDetails: String = ""
    )

    @Query("DELETE FROM queue_items WHERE sessionId = :sessionId")
    suspend fun clearQueueForSession(sessionId: String)

    // Action History Log (Idempotent via unique dedupeKey index)
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertHistoryEntryIdempotent(entry: ActionHistoryEntity): Long

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertHistoryBatchIdempotent(entries: List<ActionHistoryEntity>): List<Long>

    @Query("SELECT * FROM action_history ORDER BY createdAtEpochMs DESC LIMIT :limit")
    fun observeRecentHistory(limit: Int = 500): Flow<List<ActionHistoryEntity>>

    @Query("SELECT * FROM action_history WHERE sessionId = :sessionId ORDER BY createdAtEpochMs ASC")
    suspend fun getHistoryForSession(sessionId: String): List<ActionHistoryEntity>

    @Query("SELECT * FROM action_history ORDER BY createdAtEpochMs DESC LIMIT :limit")
    suspend fun getAllHistory(limit: Int = 20000): List<ActionHistoryEntity>

    @Query("DELETE FROM action_history")
    suspend fun clearAllHistory()

    // Session Summaries & Analytics
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertSessionSummary(summary: SessionSummaryEntity)

    @Query("SELECT * FROM session_summaries ORDER BY updatedAtEpochMs DESC LIMIT 100")
    fun observeSessionSummaries(): Flow<List<SessionSummaryEntity>>

    @Query("SELECT * FROM session_summaries ORDER BY updatedAtEpochMs DESC LIMIT 100")
    suspend fun getSessionSummaries(): List<SessionSummaryEntity>

    @Query("DELETE FROM session_summaries")
    suspend fun clearSessionSummaries()

    // Export Records
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertExportRecord(record: ExportRecordEntity)

    @Query("SELECT * FROM export_records ORDER BY createdAtEpochMs DESC LIMIT 100")
    fun observeExportRecords(): Flow<List<ExportRecordEntity>>

    @Query("SELECT * FROM export_records WHERE sessionId = :sessionId ORDER BY createdAtEpochMs DESC LIMIT 1")
    suspend fun getLatestExportForSession(sessionId: String): ExportRecordEntity?

    @Query("SELECT * FROM export_records ORDER BY createdAtEpochMs DESC LIMIT 1")
    suspend fun getMostRecentExport(): ExportRecordEntity?
}
