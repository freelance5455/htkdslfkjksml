package com.mizoq.tiktoktoolkit.domain.model

enum class ExportStatus(val wireValue: String, val displayLabel: String) {
    DOWNLOADED("downloaded", "Saved to Downloads"),
    SAVED_APP_STORAGE("saved_app_storage", "Saved to App Folder"),
    FAILED("failed", "Export Failed — Retry Available"),
    NOT_EXPORTED("not_exported", "Not Exported");

    companion object {
        fun fromWireValue(value: String?): ExportStatus =
            entries.firstOrNull { it.wireValue.equals(value, ignoreCase = true) } ?: NOT_EXPORTED
    }
}

data class ExportRecord(
    val id: String,
    val sessionId: String,
    val filename: String,
    val filePathOrUri: String,
    val recordCount: Int,
    val timestampIso: String,
    val triggerReason: String,
    val status: ExportStatus,
    val errorDetails: String = ""
)

data class SessionAnalyticsSummary(
    val sessionId: String,
    val startTimeIso: String,
    val endTimeIso: String,
    val durationFormatted: String,
    val requestedAction: String,
    val status: QueueStatus,
    val isIncomplete: Boolean,
    val scannedCount: Int,
    val successfulCount: Int,
    val skippedCount: Int,
    val failedCount: Int,
    val uncertainCount: Int,
    val exportStatus: ExportStatus,
    val exportFilename: String? = null
)

data class SecurityChallenge(
    val detected: Boolean,
    val challengeType: String? = null, // "verification_required" | "rate_limited"
    val message: String? = null
)
