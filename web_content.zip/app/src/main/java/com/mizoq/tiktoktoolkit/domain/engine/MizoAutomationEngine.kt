package com.mizoq.tiktoktoolkit.domain.engine

import android.content.Context
import com.mizoq.tiktoktoolkit.config.MizoBrandConfig
import com.mizoq.tiktoktoolkit.data.export.CsvExportManager
import com.mizoq.tiktoktoolkit.data.local.ActionHistoryEntity
import com.mizoq.tiktoktoolkit.data.local.MizoDao
import com.mizoq.tiktoktoolkit.data.local.QueueItemEntity
import com.mizoq.tiktoktoolkit.data.local.SessionSummaryEntity
import com.mizoq.tiktoktoolkit.data.preferences.SettingsRepository
import com.mizoq.tiktoktoolkit.domain.model.ActionResult
import com.mizoq.tiktoktoolkit.domain.model.DiscoveredAccount
import com.mizoq.tiktoktoolkit.domain.model.ExecutionState
import com.mizoq.tiktoktoolkit.domain.model.ExportRecord
import com.mizoq.tiktoktoolkit.domain.model.ExportStatus
import com.mizoq.tiktoktoolkit.domain.model.MutualStatus
import com.mizoq.tiktoktoolkit.domain.model.QueueStatus
import com.mizoq.tiktoktoolkit.domain.model.RelationshipState
import com.mizoq.tiktoktoolkit.domain.model.SecurityChallenge
import com.mizoq.tiktoktoolkit.domain.model.SessionAnalyticsSummary
import com.mizoq.tiktoktoolkit.domain.model.SessionCounts
import com.mizoq.tiktoktoolkit.domain.model.SessionMetrics
import com.mizoq.tiktoktoolkit.domain.model.SessionState
import com.mizoq.tiktoktoolkit.domain.model.WorkflowMode
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.Collections
import kotlin.random.Random

/**
 * Interface bridging MizoAutomationEngine to Android's MizoAccessibilityService
 * (or a simulated driver during unit/large-scale testing).
 */
interface TikTokActionDriver {
    fun isTikTokInForeground(): Boolean
    fun getForegroundPackageName(): String?
    fun detectSecurityChallenge(): SecurityChallenge
    suspend fun openProfileListIfPossible(mode: WorkflowMode): Boolean
    suspend fun scanVisibleAccounts(mode: WorkflowMode): List<DiscoveredAccount>
    suspend fun scrollAccountList(mode: WorkflowMode): Boolean
    suspend fun reacquireAccountInTree(username: String, mode: WorkflowMode): DiscoveredAccount?
    suspend fun performAccountAction(
        account: DiscoveredAccount,
        mode: WorkflowMode,
        skipMutuals: Boolean
    ): Pair<ActionResult, String>
}

/**
 * Central V6.0 Native Android Automation Orchestrator.
 * Owns session state independently of MainActivity so sessions continue while MainActivity
 * is minimized and TikTok is in the foreground with MizoOverlayService.
 */
class MizoAutomationEngine(
    private val appContext: Context,
    private val dao: MizoDao,
    private val settingsRepo: SettingsRepository
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var activeRunJob: Job? = null

    @Volatile
    var actionDriver: TikTokActionDriver? = null

    private val _sessionState = MutableStateFlow(settingsRepo.loadSessionCheckpoint())
    val sessionState: StateFlow<SessionState> = _sessionState.asStateFlow()

    private val _discoveredFollowing = MutableStateFlow<List<DiscoveredAccount>>(emptyList())
    val discoveredFollowing: StateFlow<List<DiscoveredAccount>> = _discoveredFollowing.asStateFlow()

    private val _discoveredFollowers = MutableStateFlow<List<DiscoveredAccount>>(emptyList())
    val discoveredFollowers: StateFlow<List<DiscoveredAccount>> = _discoveredFollowers.asStateFlow()

    private val _selectedFollowing = MutableStateFlow<Set<String>>(emptySet())
    val selectedFollowing: StateFlow<Set<String>> = _selectedFollowing.asStateFlow()

    private val _selectedFollowers = MutableStateFlow<Set<String>>(emptySet())
    val selectedFollowers: StateFlow<Set<String>> = _selectedFollowers.asStateFlow()

    private val discoveredSet = Collections.synchronizedSet(HashSet<String>())
    private val queuedSet = Collections.synchronizedSet(HashSet<String>())
    private val processedSet = Collections.synchronizedSet(HashSet<String>())
    private val exportedSessions = Collections.synchronizedSet(HashSet<String>())

    fun loadSamplePreviewAccounts(mode: WorkflowMode) {
        if (mode == WorkflowMode.FOLLOWING) {
            val samples = listOf(
                DiscoveredAccount("studio.kawaii", "Kawaii Art Studio", MutualStatus.NON_MUTUAL, RelationshipState.FOLLOWING, "Following"),
                DiscoveredAccount("luna.starlight", "Luna Starlight", MutualStatus.MUTUAL, RelationshipState.FRIENDS, "Friends", followsYouIndicator = true),
                DiscoveredAccount("daily.matcha.clips", "Daily Matcha", MutualStatus.NON_MUTUAL, RelationshipState.FOLLOWING, "Following"),
                DiscoveredAccount("pixel.cloud.99", "Pixel Cloud", MutualStatus.UNKNOWN, RelationshipState.UNKNOWN, "..."),
                DiscoveredAccount("tokyo.synthwave", "Tokyo Synthwave", MutualStatus.NON_MUTUAL, RelationshipState.FOLLOWING, "Following"),
                DiscoveredAccount("mina.bestie", "Mina (Mutual Friend)", MutualStatus.MUTUAL, RelationshipState.FRIENDS, "Friends", followsYouIndicator = true)
            )
            _discoveredFollowing.value = samples
            val skipMutuals = settingsRepo.getSettings().skipMutuals
            _selectedFollowing.value = samples
                .filter { EligibilityEvaluator.evaluate(it, skipMutuals).eligible }
                .map { it.normalizedUsername }
                .toSet()
        } else {
            val samples = listOf(
                DiscoveredAccount("bot.promo.acc", "Promo Runner", MutualStatus.NON_MUTUAL, RelationshipState.FOLLOWER_ONLY, "Follow back", hasMoreOptionsButton = true, followsYouIndicator = true),
                DiscoveredAccount("sara.chan", "Sara Chan", MutualStatus.MUTUAL, RelationshipState.FRIENDS, "Friends", hasMoreOptionsButton = true, followsYouIndicator = true),
                DiscoveredAccount("random.viewer.42", "Viewer 42", MutualStatus.NON_MUTUAL, RelationshipState.FOLLOWER_ONLY, "Follow back", hasMoreOptionsButton = true, followsYouIndicator = true),
                DiscoveredAccount("mystery.profile", "Mystery User", MutualStatus.UNKNOWN, RelationshipState.UNKNOWN, "Loading", hasMoreOptionsButton = false)
            )
            _discoveredFollowers.value = samples
            val skipMutuals = settingsRepo.getSettings().skipMutuals
            _selectedFollowers.value = samples
                .filter { EligibilityEvaluator.evaluate(it, skipMutuals).eligible }
                .map { it.normalizedUsername }
                .toSet()
        }
    }

    fun toggleAccountSelection(mode: WorkflowMode, normalizedUsername: String, selected: Boolean) {
        if (mode == WorkflowMode.FOLLOWING) {
            val mutable = _selectedFollowing.value.toMutableSet()
            if (selected) mutable.add(normalizedUsername) else mutable.remove(normalizedUsername)
            _selectedFollowing.value = mutable
        } else {
            val mutable = _selectedFollowers.value.toMutableSet()
            if (selected) mutable.add(normalizedUsername) else mutable.remove(normalizedUsername)
            _selectedFollowers.value = mutable
        }
    }

    fun selectAllEligible(mode: WorkflowMode) {
        val skipMutuals = settingsRepo.getSettings().skipMutuals
        if (mode == WorkflowMode.FOLLOWING) {
            _selectedFollowing.value = _discoveredFollowing.value
                .filter { EligibilityEvaluator.evaluate(it, skipMutuals).eligible }
                .map { it.normalizedUsername }
                .toSet()
        } else {
            _selectedFollowers.value = _discoveredFollowers.value
                .filter { EligibilityEvaluator.evaluate(it, skipMutuals).eligible }
                .map { it.normalizedUsername }
                .toSet()
        }
    }

    fun deselectAll(mode: WorkflowMode) {
        if (mode == WorkflowMode.FOLLOWING) {
            _selectedFollowing.value = emptySet()
        } else {
            _selectedFollowers.value = emptySet()
        }
    }

    /**
     * Starts a new automation session (either against live TikTok via AccessibilityService
     * or in simulated test mode for up to 10,000 entries).
     */
    fun startSession(
        mode: WorkflowMode,
        isSimulated: Boolean = false,
        simulatedTotalAccounts: Int = 200
    ) {
        if (_sessionState.value.status.isActiveRun) return
        activeRunJob?.cancel()

        val settings = settingsRepo.getSettings()
        val limit = settings.maxActionsPerSession.coerceIn(1, MizoBrandConfig.MAX_SESSION_LIMIT)
        val sessionId = "sess-${System.currentTimeMillis()}"
        val nowMs = System.currentTimeMillis()

        discoveredSet.clear()
        queuedSet.clear()
        processedSet.clear()

        val initialState = SessionState(
            sessionId = sessionId,
            status = QueueStatus.SCANNING,
            executionState = ExecutionState.ACTIVELY_PROCESSING,
            workflowMode = mode,
            isSimulatedMode = isSimulated,
            counts = SessionCounts(configuredLimit = limit),
            metrics = SessionMetrics(
                sessionStartEpochMs = nowMs,
                accumulatedElapsedMs = 0L,
                lastResumeEpochMs = nowMs,
                elapsedFormatted = "0s"
            )
        )
        checkpointState(initialState)

        activeRunJob = scope.launch {
            runOrchestratorLoop(
                sessionId = sessionId,
                mode = mode,
                isSimulated = isSimulated,
                simulatedTotalAvailable = simulatedTotalAccounts.coerceAtLeast(limit)
            )
        }
    }

    fun pauseSession(reason: String = "Paused by user.") {
        activeRunJob?.cancel()
        val cur = _sessionState.value
        if (!cur.status.isActiveRun && cur.status != QueueStatus.RECOVERING) return
        val now = System.currentTimeMillis()
        val addedMs = cur.metrics.lastResumeEpochMs?.let { (now - it).coerceAtLeast(0L) } ?: 0L
        val totalMs = cur.metrics.accumulatedElapsedMs + addedMs
        checkpointState(
            cur.copy(
                status = QueueStatus.PAUSED,
                executionState = ExecutionState.STANDBY,
                inFlightUsername = null,
                interruptionReason = reason,
                metrics = cur.metrics.copy(
                    accumulatedElapsedMs = totalMs,
                    lastResumeEpochMs = null,
                    elapsedFormatted = formatDurationMs(totalMs)
                )
            )
        )
    }

    /**
     * Reconciles any in-flight/uncertain actions against the current TikTok screen and resumes.
     */
    fun resumeSession() {
        val cur = _sessionState.value
        if (!cur.status.canResume && !cur.captchaResolvedReadyToResume) return
        activeRunJob?.cancel()

        val now = System.currentTimeMillis()
        val sessionId = cur.sessionId ?: "sess-$now"
        checkpointState(
            cur.copy(
                sessionId = sessionId,
                status = QueueStatus.PROCESSING,
                executionState = ExecutionState.ACTIVELY_PROCESSING,
                captchaResolvedReadyToResume = false,
                securityWarning = null,
                interruptionReason = null,
                metrics = cur.metrics.copy(lastResumeEpochMs = now)
            )
        )

        activeRunJob = scope.launch {
            reconcileInFlightAccountIfNeeded(sessionId)
            runOrchestratorLoop(
                sessionId = sessionId,
                mode = cur.workflowMode,
                isSimulated = cur.isSimulatedMode,
                simulatedTotalAvailable = cur.counts.configuredLimit * 2
            )
        }
    }

    /**
     * Immediately stops scheduling new actions, saves final session state, and triggers
     * automatic CSV export (preventing duplicate exports on repeated Stop taps).
     */
    fun stopSessionAndExport(onExportResult: ((ExportRecord) -> Unit)? = null) {
        activeRunJob?.cancel()
        val cur = _sessionState.value
        val sessionId = cur.sessionId ?: "sess-${System.currentTimeMillis()}"

        val now = System.currentTimeMillis()
        val addedMs = cur.metrics.lastResumeEpochMs?.let { (now - it).coerceAtLeast(0L) } ?: 0L
        val totalMs = cur.metrics.accumulatedElapsedMs + addedMs
        val elapsedStr = formatDurationMs(totalMs)
        val c = cur.counts

        val report = "Stopped by user after $elapsedStr. Scanned: ${c.scanned}, Queued: ${c.queued}, " +
            "Completed: ${c.completed}, Skipped: ${c.skipped} (${c.mutualProtected} mutuals protected), " +
            "Failed: ${c.failed}, Uncertain: ${c.uncertain}."

        val stoppedState = cur.copy(
            sessionId = sessionId,
            status = QueueStatus.STOPPED,
            executionState = ExecutionState.STANDBY,
            inFlightUsername = null,
            interruptionReason = "Stopped by user.",
            completionReport = report,
            metrics = cur.metrics.copy(
                accumulatedElapsedMs = totalMs,
                lastResumeEpochMs = null,
                elapsedFormatted = elapsedStr
            )
        )
        checkpointState(stoppedState)

        scope.launch {
            val record = CsvExportManager.exportSessionToAndroidStorage(
                context = appContext,
                dao = dao,
                sessionId = sessionId,
                requestedAction = cur.workflowMode.actionName,
                triggerReason = "stopped",
                forceRetry = false
            )
            exportedSessions.add(sessionId)
            checkpointState(
                _sessionState.value.copy(
                    lastExportFilename = record.filename,
                    lastExportStatus = record.status.displayLabel
                )
            )
            onExportResult?.invoke(record)
        }
    }

    fun onCaptchaDetected(challenge: SecurityChallenge) {
        activeRunJob?.cancel()
        val cur = _sessionState.value
        val targetStatus = if (challenge.challengeType == "rate_limited") {
            QueueStatus.RATE_LIMITED
        } else {
            QueueStatus.VERIFICATION_REQUIRED
        }
        checkpointState(
            cur.copy(
                status = targetStatus,
                executionState = ExecutionState.AWAITING_VERIFICATION,
                inFlightUsername = null,
                captchaResolvedReadyToResume = false,
                securityWarning = challenge.message
                    ?: "TikTok verification challenge detected. Complete verification manually in TikTok, then tap Resume."
            )
        )
    }

    fun checkVerificationResolved(): Boolean {
        val driver = actionDriver
        val challenge = driver?.detectSecurityChallenge() ?: SecurityChallenge(detected = false)
        if (!challenge.detected) {
            val cur = _sessionState.value
            checkpointState(
                cur.copy(
                    status = QueueStatus.PAUSED,
                    executionState = ExecutionState.STANDBY,
                    captchaResolvedReadyToResume = true,
                    securityWarning = null,
                    interruptionReason = "Verification resolved and TikTok screen revalidated. Tap Resume to continue."
                )
            )
            return true
        }
        return false
    }

    private suspend fun reconcileInFlightAccountIfNeeded(sessionId: String) {
        val cur = _sessionState.value
        val inFlight = cur.inFlightUsername ?: return
        val driver = actionDriver
        if (!cur.isSimulatedMode && driver != null && driver.isTikTokInForeground()) {
            val reacquired = driver.reacquireAccountInTree(inFlight, cur.workflowMode)
            val completedInUi = reacquired == null ||
                reacquired.relationshipState == RelationshipState.NOT_FOLLOWING ||
                reacquired.relationshipState == RelationshipState.REMOVED

            if (completedInUi && processedSet.add(inFlight.lowercase())) {
                dao.updateQueueItemStatus(sessionId, inFlight.lowercase(), ActionResult.SUCCESS.wireValue)
                logHistoryIdempotent(
                    sessionId = sessionId,
                    username = inFlight,
                    displayName = reacquired?.displayName ?: inFlight,
                    action = cur.workflowMode.actionName,
                    result = ActionResult.SUCCESS
                )
                val updatedCounts = cur.counts.copy(
                    completed = cur.counts.completed + 1,
                    pending = (cur.counts.pending - 1).coerceAtLeast(0)
                )
                checkpointState(
                    cur.copy(
                        inFlightUsername = null,
                        hasUncertainActionInFlight = false,
                        lastSuccessfulUsername = inFlight,
                        counts = updatedCounts
                    )
                )
                return
            }
        }
        checkpointState(cur.copy(inFlightUsername = null, hasUncertainActionInFlight = false))
    }

    private suspend fun runOrchestratorLoop(
        sessionId: String,
        mode: WorkflowMode,
        isSimulated: Boolean,
        simulatedTotalAvailable: Int
    ) {
        val settings = settingsRepo.getSettings()
        val configuredLimit = settings.maxActionsPerSession.coerceIn(1, MizoBrandConfig.MAX_SESSION_LIMIT)
        val driver = actionDriver
        var stalledScrolls = 0

        while (_sessionState.value.status.isActiveRun) {
            val cur = _sessionState.value
            if (cur.counts.completed >= configuredLimit) {
                completeSession(sessionId, mode, "limit_reached")
                return
            }

            if (!isSimulated) {
                if (driver == null || !driver.isTikTokInForeground()) {
                    checkpointState(
                        cur.copy(
                            status = QueueStatus.PAUSED,
                            executionState = ExecutionState.SUSPENDED_BY_OS,
                            interruptionReason = "TikTok is not in the foreground or AccessibilityService is disconnected. Open TikTok and tap Resume."
                        )
                    )
                    return
                }
                val security = driver.detectSecurityChallenge()
                if (security.detected) {
                    onCaptchaDetected(security)
                    return
                }
            }

            val pendingBatch = dao.getPendingQueueBatch(sessionId, limit = 250)
            if (pendingBatch.isEmpty()) {
                if (cur.counts.queued >= configuredLimit) {
                    completeSession(sessionId, mode, "limit_reached")
                    return
                }

                // Discover more accounts from TikTok Accessibility tree or simulation generator
                checkpointState(_sessionState.value.copy(status = QueueStatus.SCANNING))
                val newlyDiscovered = if (isSimulated) {
                    generateSimulatedBatch(
                        mode = mode,
                        startIndex = discoveredSet.size + 1,
                        maxTotal = simulatedTotalAvailable,
                        batchSize = 500
                    )
                } else {
                    val scanned = driver?.scanVisibleAccounts(mode) ?: emptyList()
                    if (scanned.isEmpty() && settings.autoScroll) {
                        driver?.scrollAccountList(mode)
                        delay(350L)
                        driver?.scanVisibleAccounts(mode) ?: emptyList()
                    } else {
                        scanned
                    }
                }

                val enqueuedNow = enqueueBatch(
                    sessionId = sessionId,
                    mode = mode,
                    accounts = newlyDiscovered,
                    skipMutuals = settings.skipMutuals,
                    configuredLimit = configuredLimit
                )

                if (enqueuedNow == 0) {
                    if (isSimulated) {
                        if (discoveredSet.size >= simulatedTotalAvailable) {
                            completeSession(sessionId, mode, "exhausted")
                            return
                        }
                    } else if (settings.autoScroll && driver != null) {
                        val scrolled = driver.scrollAccountList(mode)
                        if (!scrolled) stalledScrolls++ else stalledScrolls = 0
                        if (stalledScrolls >= 3) {
                            completeSession(sessionId, mode, "exhausted")
                            return
                        }
                        delay(350L)
                    } else {
                        completeSession(sessionId, mode, "completed")
                        return
                    }
                }
                continue
            }

            checkpointState(_sessionState.value.copy(status = QueueStatus.PROCESSING))

            for (qItem in pendingBatch) {
                val loopState = _sessionState.value
                if (!loopState.status.isActiveRun) return
                if (loopState.counts.completed >= configuredLimit) {
                    completeSession(sessionId, mode, "limit_reached")
                    return
                }

                val normUser = qItem.normalizedUsername
                if (!processedSet.add(normUser)) {
                    dao.updateQueueItemStatus(sessionId, normUser, ActionResult.SKIPPED.wireValue, skipReason = "duplicate_in_session")
                    continue
                }

                checkpointState(loopState.copy(inFlightUsername = qItem.username))

                val (outcome, detail) = if (isSimulated) {
                    if (settings.minDelayMs > 0L) {
                        delay(settings.minDelayMs.coerceAtMost(20L))
                    }
                    ActionResult.SUCCESS to ""
                } else {
                    val activeDriver = actionDriver
                    if (activeDriver == null || !activeDriver.isTikTokInForeground()) {
                        processedSet.remove(normUser)
                        checkpointState(
                            _sessionState.value.copy(
                                status = QueueStatus.PAUSED,
                                executionState = ExecutionState.SUSPENDED_BY_OS,
                                inFlightUsername = null,
                                interruptionReason = "TikTok left foreground during action. Progress saved."
                            )
                        )
                        return
                    }
                    val reacquired = activeDriver.reacquireAccountInTree(qItem.username, mode)
                    val preCheck = EligibilityEvaluator.verifyLiveTargetBeforeAction(
                        expectedUsername = qItem.username,
                        reacquiredAccount = reacquired,
                        skipMutuals = settings.skipMutuals
                    )
                    if (!preCheck.eligible || reacquired == null) {
                        ActionResult.SKIPPED to (preCheck.skipReason ?: "skipped_precheck")
                    } else {
                        activeDriver.performAccountAction(reacquired, mode, settings.skipMutuals)
                    }
                }

                val c = _sessionState.value.counts
                when (outcome) {
                    ActionResult.SUCCESS -> {
                        dao.updateQueueItemStatus(sessionId, normUser, ActionResult.SUCCESS.wireValue)
                        logHistoryIdempotent(sessionId, qItem.username, qItem.displayName, mode.actionName, ActionResult.SUCCESS)
                        val nextCounts = c.copy(
                            completed = c.completed + 1,
                            pending = (c.pending - 1).coerceAtLeast(0)
                        )
                        checkpointState(
                            _sessionState.value.copy(
                                inFlightUsername = null,
                                lastSuccessfulUsername = qItem.username,
                                consecutiveFailures = 0,
                                counts = nextCounts
                            ),
                            persistToPrefs = !isSimulated || nextCounts.completed % 250 == 0 || nextCounts.completed >= configuredLimit
                        )
                    }
                    ActionResult.SKIPPED -> {
                        dao.updateQueueItemStatus(sessionId, normUser, ActionResult.SKIPPED.wireValue, skipReason = detail)
                        logHistoryIdempotent(sessionId, qItem.username, qItem.displayName, mode.actionName, ActionResult.SKIPPED, skipReason = detail)
                        val nextCounts = c.copy(
                            skipped = c.skipped + 1,
                            pending = (c.pending - 1).coerceAtLeast(0)
                        )
                        checkpointState(_sessionState.value.copy(inFlightUsername = null, counts = nextCounts), persistToPrefs = !isSimulated)
                    }
                    ActionResult.UNCERTAIN -> {
                        dao.updateQueueItemStatus(sessionId, normUser, ActionResult.UNCERTAIN.wireValue, errorDetails = detail)
                        logHistoryIdempotent(sessionId, qItem.username, qItem.displayName, mode.actionName, ActionResult.UNCERTAIN, errorDetails = detail)
                        val nextCounts = c.copy(
                            uncertain = c.uncertain + 1,
                            pending = (c.pending - 1).coerceAtLeast(0)
                        )
                        checkpointState(
                            _sessionState.value.copy(
                                status = QueueStatus.RECOVERING,
                                executionState = ExecutionState.STANDBY,
                                hasUncertainActionInFlight = true,
                                counts = nextCounts,
                                interruptionReason = detail.ifEmpty { "Outcome for @${qItem.username} is uncertain. Verify TikTok screen before resuming." }
                            )
                        )
                        return
                    }
                    else -> {
                        dao.updateQueueItemStatus(sessionId, normUser, ActionResult.FAILED.wireValue, errorDetails = detail)
                        logHistoryIdempotent(sessionId, qItem.username, qItem.displayName, mode.actionName, ActionResult.FAILED, errorDetails = detail)
                        val fails = _sessionState.value.consecutiveFailures + 1
                        val nextCounts = c.copy(
                            failed = c.failed + 1,
                            pending = (c.pending - 1).coerceAtLeast(0)
                        )
                        if (fails >= 3) {
                            checkpointState(
                                _sessionState.value.copy(
                                    status = QueueStatus.PAUSED,
                                    executionState = ExecutionState.STANDBY,
                                    inFlightUsername = null,
                                    consecutiveFailures = fails,
                                    counts = nextCounts,
                                    interruptionReason = "Paused automatically after $fails consecutive failures: $detail"
                                )
                            )
                            return
                        } else {
                            checkpointState(_sessionState.value.copy(inFlightUsername = null, consecutiveFailures = fails, counts = nextCounts))
                        }
                    }
                }

                if (!isSimulated && settings.minDelayMs > 0L) {
                    val jitter = if (settings.maxDelayMs > settings.minDelayMs) {
                        Random.nextLong(settings.minDelayMs, settings.maxDelayMs + 1L)
                    } else {
                        settings.minDelayMs
                    }
                    delay(jitter)
                }
            }
        }
    }

    private suspend fun enqueueBatch(
        sessionId: String,
        mode: WorkflowMode,
        accounts: List<DiscoveredAccount>,
        skipMutuals: Boolean,
        configuredLimit: Int
    ): Int {
        val queueEntities = mutableListOf<QueueItemEntity>()
        val skippedHistoryEntities = mutableListOf<ActionHistoryEntity>()
        var mutualProtectedDelta = 0
        var uncertainSkippedDelta = 0
        var skippedDelta = 0
        var currentQueued = _sessionState.value.counts.queued
        val nowIso = CsvExportManager.formatIsoTimestamp()

        for (acc in accounts) {
            val key = acc.normalizedUsername
            if (key.isEmpty()) continue
            val isNewDiscovery = discoveredSet.add(key)

            if (queuedSet.contains(key) || processedSet.contains(key)) continue

            val elig = EligibilityEvaluator.evaluate(acc, skipMutuals)
            if (!elig.eligible) {
                if (isNewDiscovery && (elig.skipReason == "mutual_protected" || elig.skipReason == "mutual_status_uncertain")) {
                    processedSet.add(key)
                    skippedDelta++
                    if (elig.skipReason == "mutual_protected") mutualProtectedDelta++ else uncertainSkippedDelta++
                    skippedHistoryEntities.add(
                        ActionHistoryEntity(
                            id = "${sessionId}-${key}-skipped",
                            dedupeKey = "$sessionId:${mode.actionName}:$key:skipped",
                            sessionId = sessionId,
                            username = acc.username,
                            displayName = acc.displayName,
                            requestedAction = mode.actionName,
                            result = ActionResult.SKIPPED.wireValue,
                            timestampIso = nowIso,
                            skipReason = elig.skipReason
                        )
                    )
                }
                continue
            }

            if (currentQueued >= configuredLimit) continue

            queuedSet.add(key)
            currentQueued++
            queueEntities.add(
                QueueItemEntity(
                    sessionId = sessionId,
                    username = acc.username,
                    normalizedUsername = key,
                    displayName = acc.displayName,
                    mutualStatus = acc.mutualStatus.wireValue,
                    status = ActionResult.PENDING.wireValue
                )
            )
        }

        if (skippedHistoryEntities.isNotEmpty()) {
            dao.insertHistoryBatchIdempotent(skippedHistoryEntities)
        }
        if (queueEntities.isNotEmpty()) {
            dao.insertQueueItems(queueEntities)
        }

        val c = _sessionState.value.counts
        val updatedCounts = c.copy(
            scanned = discoveredSet.size,
            queued = currentQueued,
            pending = c.pending + queueEntities.size,
            skipped = c.skipped + skippedDelta,
            mutualProtected = c.mutualProtected + mutualProtectedDelta,
            uncertainSkipped = c.uncertainSkipped + uncertainSkippedDelta
        )
        checkpointState(_sessionState.value.copy(counts = updatedCounts), persistToPrefs = !_sessionState.value.isSimulatedMode)
        return queueEntities.size
    }

    private suspend fun completeSession(sessionId: String, mode: WorkflowMode, reason: String) {
        val cur = _sessionState.value
        val now = System.currentTimeMillis()
        val addedMs = cur.metrics.lastResumeEpochMs?.let { (now - it).coerceAtLeast(0L) } ?: 0L
        val totalMs = cur.metrics.accumulatedElapsedMs + addedMs
        val elapsedStr = formatDurationMs(totalMs)
        val c = cur.counts

        val report = "Session $reason (${c.completed} / ${c.configuredLimit} completed in $elapsedStr). " +
            "Scanned: ${c.scanned}, Queued: ${c.queued}, Skipped: ${c.skipped} (${c.mutualProtected} mutuals protected), " +
            "Failed: ${c.failed}, Uncertain: ${c.uncertain}."

        val doneState = cur.copy(
            status = QueueStatus.COMPLETED,
            executionState = ExecutionState.STANDBY,
            inFlightUsername = null,
            completionReport = report,
            metrics = cur.metrics.copy(
                accumulatedElapsedMs = totalMs,
                lastResumeEpochMs = null,
                elapsedFormatted = elapsedStr
            )
        )
        checkpointState(doneState, persistToPrefs = true)

        if (settingsRepo.getSettings().autoExportCsv) {
            val exp = CsvExportManager.exportSessionToAndroidStorage(
                context = appContext,
                dao = dao,
                sessionId = sessionId,
                requestedAction = mode.actionName,
                triggerReason = reason,
                forceRetry = false
            )
            exportedSessions.add(sessionId)
            checkpointState(
                _sessionState.value.copy(
                    lastExportFilename = exp.filename,
                    lastExportStatus = exp.status.displayLabel
                ),
                persistToPrefs = true
            )
        }
    }

    private suspend fun logHistoryIdempotent(
        sessionId: String,
        username: String,
        displayName: String,
        action: String,
        result: ActionResult,
        skipReason: String = "",
        errorDetails: String = ""
    ) {
        val cleanUser = username.trim().removePrefix("@")
        val key = cleanUser.lowercase()
        val entity = ActionHistoryEntity(
            id = "$sessionId-$key-${result.wireValue}",
            dedupeKey = "$sessionId:$action:$key:${result.wireValue}",
            sessionId = sessionId,
            username = cleanUser,
            displayName = displayName,
            requestedAction = action,
            result = result.wireValue,
            timestampIso = CsvExportManager.formatIsoTimestamp(),
            skipReason = skipReason,
            errorDetails = errorDetails
        )
        dao.insertHistoryEntryIdempotent(entity)
    }

    private fun generateSimulatedBatch(
        mode: WorkflowMode,
        startIndex: Int,
        maxTotal: Int,
        batchSize: Int
    ): List<DiscoveredAccount> {
        if (startIndex > maxTotal) return emptyList()
        val endIndex = (startIndex + batchSize - 1).coerceAtMost(maxTotal)
        val out = ArrayList<DiscoveredAccount>(endIndex - startIndex + 1)
        for (idx in startIndex..endIndex) {
            val isMutual = idx % 10 == 0
            val isUnknown = !isMutual && (idx % 25 == 0)
            val mutualStatus = when {
                isMutual -> MutualStatus.MUTUAL
                isUnknown -> MutualStatus.UNKNOWN
                else -> MutualStatus.NON_MUTUAL
            }
            val relState = when {
                isMutual -> RelationshipState.FRIENDS
                isUnknown -> RelationshipState.UNKNOWN
                mode == WorkflowMode.FOLLOWERS -> RelationshipState.FOLLOWER_ONLY
                else -> RelationshipState.FOLLOWING
            }
            out.add(
                DiscoveredAccount(
                    username = "sim.user.$idx",
                    displayName = "Simulated User $idx",
                    mutualStatus = mutualStatus,
                    relationshipState = relState,
                    actionButtonText = if (isMutual) "Friends" else if (isUnknown) "..." else "Following",
                    hasMoreOptionsButton = true,
                    followsYouIndicator = isMutual || mode == WorkflowMode.FOLLOWERS
                )
            )
        }
        return out
    }

    private fun checkpointState(newState: SessionState, persistToPrefs: Boolean = true) {
        _sessionState.value = newState
        if (persistToPrefs) {
            settingsRepo.saveSessionCheckpoint(newState)
            val sid = newState.sessionId
            if (sid != null) {
                scope.launch {
                    val nowIso = CsvExportManager.formatIsoTimestamp()
                    dao.upsertSessionSummary(
                        SessionSummaryEntity(
                            sessionId = sid,
                            startTimeIso = nowIso,
                            endTimeIso = nowIso,
                            durationFormatted = newState.metrics.elapsedFormatted,
                            requestedAction = newState.workflowMode.actionName,
                            status = newState.status.wireValue,
                            isIncomplete = newState.status != QueueStatus.COMPLETED && newState.status != QueueStatus.IDLE,
                            scannedCount = newState.counts.scanned,
                            exportStatus = newState.lastExportStatus ?: ExportStatus.NOT_EXPORTED.wireValue,
                            exportFilename = newState.lastExportFilename
                        )
                    )
                }
            }
        }
    }

    suspend fun computeRealSessionAnalytics(): List<SessionAnalyticsSummary> {
        val summaries = dao.getSessionSummaries()
        val out = mutableListOf<SessionAnalyticsSummary>()
        for (sum in summaries) {
            val history = dao.getHistoryForSession(sum.sessionId)
            val latestExport = dao.getLatestExportForSession(sum.sessionId)
            val successCount = history.count { it.result == ActionResult.SUCCESS.wireValue }
            val skippedCount = history.count { it.result == ActionResult.SKIPPED.wireValue }
            val failedCount = history.count { it.result == ActionResult.FAILED.wireValue }
            val uncertainCount = history.count { it.result == ActionResult.UNCERTAIN.wireValue }
            out.add(
                SessionAnalyticsSummary(
                    sessionId = sum.sessionId,
                    startTimeIso = sum.startTimeIso,
                    endTimeIso = sum.endTimeIso,
                    durationFormatted = sum.durationFormatted,
                    requestedAction = sum.requestedAction,
                    status = QueueStatus.fromWireValue(sum.status),
                    isIncomplete = sum.isIncomplete,
                    scannedCount = sum.scannedCount,
                    successfulCount = successCount,
                    skippedCount = skippedCount,
                    failedCount = failedCount,
                    uncertainCount = uncertainCount,
                    exportStatus = ExportStatus.fromWireValue(latestExport?.status ?: sum.exportStatus),
                    exportFilename = latestExport?.filename ?: sum.exportFilename
                )
            )
        }
        return out
    }

    private fun formatDurationMs(ms: Long): String {
        val totalSec = (ms / 1000L).coerceAtLeast(0L)
        val hrs = totalSec / 3600L
        val mins = (totalSec % 3600L) / 60L
        val secs = totalSec % 60L
        return when {
            hrs > 0L -> "${hrs}h ${mins}m ${secs}s"
            mins > 0L -> "${mins}m ${secs}s"
            else -> "${secs}s"
        }
    }
}
