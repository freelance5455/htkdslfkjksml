package com.mizoq.tiktoktoolkit.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mizoq.tiktoktoolkit.config.MizoBrandConfig
import com.mizoq.tiktoktoolkit.domain.model.SessionSettings
import com.mizoq.tiktoktoolkit.domain.model.SessionState
import com.mizoq.tiktoktoolkit.domain.model.WorkflowMode
import com.mizoq.tiktoktoolkit.ui.theme.MizoAmberWarning
import com.mizoq.tiktoktoolkit.ui.theme.MizoCyanHighlight
import com.mizoq.tiktoktoolkit.ui.theme.MizoLavenderAccent
import com.mizoq.tiktoktoolkit.ui.theme.MizoMidnightElevated
import com.mizoq.tiktoktoolkit.ui.theme.MizoMidnightSurface
import com.mizoq.tiktoktoolkit.ui.theme.MizoMintSuccess
import com.mizoq.tiktoktoolkit.ui.theme.MizoPurplePrimary
import com.mizoq.tiktoktoolkit.ui.theme.MizoRoseDanger
import com.mizoq.tiktoktoolkit.ui.theme.MizoTextMuted
import com.mizoq.tiktoktoolkit.ui.theme.MizoTextPrimary
import com.mizoq.tiktoktoolkit.ui.theme.MizoTextSecondary

@Composable
fun DashboardScreen(
    sessionState: SessionState,
    settings: SessionSettings,
    isOverlayGranted: Boolean,
    isOverlayVisible: Boolean,
    isAccessibilityConnected: Boolean,
    onRequestOverlayPermission: () -> Unit,
    onRequestAccessibilityPermission: () -> Unit,
    onToggleFloatingOverlay: (Boolean) -> Unit,
    onLaunchOfficialTikTok: () -> Unit,
    onStartLiveSession: (WorkflowMode) -> Unit,
    onStartSimulatedSession: (Int) -> Unit,
    onPauseSession: () -> Unit,
    onResumeSession: () -> Unit,
    onStopAndExportCsv: () -> Unit,
    onExportCsvManual: () -> Unit,
    onToggleSkipMutuals: (Boolean) -> Unit,
    onSelectLimitPreset: (Int) -> Unit
) {
    val c = sessionState.counts

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // 1. Permission & Floating Panel Readiness Card
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(MizoMidnightSurface.copy(alpha = 0.88f), RoundedCornerShape(14.dp))
                .border(1.dp, MizoCyanHighlight.copy(alpha = 0.3f), RoundedCornerShape(14.dp))
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = "1. Android Permissions & TikTok Launcher",
                color = MizoCyanHighlight,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Floating Overlay Permission",
                        color = MizoTextPrimary,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 12.sp
                    )
                    Text(
                        text = if (isOverlayGranted) "Granted — Ready to float over TikTok" else "Required for floating Mizo_q panel",
                        color = if (isOverlayGranted) MizoMintSuccess else MizoAmberWarning,
                        fontSize = 11.sp
                    )
                }
                Button(
                    onClick = {
                        if (isOverlayGranted) {
                            onToggleFloatingOverlay(!isOverlayVisible)
                        } else {
                            onRequestOverlayPermission()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isOverlayVisible) MizoRoseDanger else MizoPurplePrimary
                    )
                ) {
                    Text(
                        text = when {
                            !isOverlayGranted -> "Grant Overlay"
                            isOverlayVisible -> "Hide Panel"
                            else -> "Show Floating Panel"
                        },
                        color = Color.White,
                        fontSize = 11.sp
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "TikTok Accessibility Service",
                        color = MizoTextPrimary,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 12.sp
                    )
                    Text(
                        text = if (isAccessibilityConnected) "Connected — Visible UI Assistant Ready" else "Enable in Android Accessibility Settings",
                        color = if (isAccessibilityConnected) MizoMintSuccess else MizoAmberWarning,
                        fontSize = 11.sp
                    )
                }
                OutlinedButton(onClick = onRequestAccessibilityPermission) {
                    Text(
                        text = if (isAccessibilityConnected) "Manage Service" else "Enable Service",
                        color = MizoCyanHighlight,
                        fontSize = 11.sp
                    )
                }
            }

            Button(
                onClick = onLaunchOfficialTikTok,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0891B2))
            ) {
                Text(
                    text = "Open Official TikTok Android App",
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // 2. Main Task Card & Progress Indicator
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(MizoMidnightSurface.copy(alpha = 0.90f), RoundedCornerShape(14.dp))
                .border(1.dp, MizoLavenderAccent.copy(alpha = 0.25f), RoundedCornerShape(14.dp))
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${MizoBrandConfig.BRAND_NAME} Task Orchestrator",
                    color = MizoCyanHighlight,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
                Text(
                    text = "${sessionState.status.displayLabel} (${sessionState.executionState.badgeText})",
                    color = MizoLavenderAccent,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 11.sp
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                Text(
                    text = "${c.progressPercent}%",
                    color = MizoCyanHighlight,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 22.sp
                )
                Text(
                    text = "${c.completed} / ${c.configuredLimit} • Remaining: ${c.remaining} • Elapsed: ${sessionState.metrics.elapsedFormatted}",
                    color = MizoTextSecondary,
                    fontSize = 11.sp
                )
            }

            LinearProgressIndicator(
                progress = { c.progressFraction },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(10.dp),
                color = MizoCyanHighlight,
                trackColor = MizoMidnightElevated
            )

            // 6-Counter Telemetry Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                StatMetricBox("Scanned", c.scanned.toString(), MizoTextPrimary, Modifier.weight(1f))
                StatMetricBox("Queued", c.queued.toString(), MizoLavenderAccent, Modifier.weight(1f))
                StatMetricBox("Done", c.completed.toString(), MizoMintSuccess, Modifier.weight(1f))
                StatMetricBox("Skipped", c.skipped.toString(), MizoCyanHighlight, Modifier.weight(1f))
                StatMetricBox("Failed", c.failed.toString(), MizoRoseDanger, Modifier.weight(1f))
                StatMetricBox("Uncert.", c.uncertain.toString(), MizoAmberWarning, Modifier.weight(1f))
            }

            // Touch-Friendly Primary Controls: Start, Pause, Resume, Stop & CSV, Export CSV
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Button(
                    onClick = { onStartLiveSession(sessionState.workflowMode) },
                    enabled = !sessionState.status.isActiveRun,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = MizoPurplePrimary)
                ) {
                    Text("Start", color = Color.White, fontWeight = FontWeight.Bold)
                }
                Button(
                    onClick = onPauseSession,
                    enabled = sessionState.status.isActiveRun,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = MizoMidnightElevated)
                ) {
                    Text("Pause", color = MizoTextPrimary)
                }
                Button(
                    onClick = onResumeSession,
                    enabled = sessionState.status.canResume || sessionState.captchaResolvedReadyToResume,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0891B2))
                ) {
                    Text("Resume", color = Color.White)
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Button(
                    onClick = onStopAndExportCsv,
                    enabled = sessionState.status.canStop,
                    modifier = Modifier.weight(1.3f),
                    colors = ButtonDefaults.buttonColors(containerColor = MizoRoseDanger)
                ) {
                    Text("Stop & Export CSV", color = Color.White, fontWeight = FontWeight.Bold)
                }
                OutlinedButton(
                    onClick = onExportCsvManual,
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Export CSV", color = MizoCyanHighlight)
                }
            }

            // Quick Skip Mutuals & Limit Presets
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Skip Mutuals (Protect Friends & Uncertain)",
                    color = MizoTextPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Switch(
                    checked = settings.skipMutuals,
                    onCheckedChange = onToggleSkipMutuals
                )
            }

            Text(
                text = "Quick Session Limit Presets (App Limit — Max 10,000):",
                color = MizoTextMuted,
                fontSize = 11.sp
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                for (preset in listOf(20, 100, 500, 1000, 10000)) {
                    val selected = settings.maxActionsPerSession == preset
                    OutlinedButton(
                        onClick = { onSelectLimitPreset(preset) },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = if (selected) MizoPurplePrimary.copy(alpha = 0.35f) else Color.Transparent
                        )
                    ) {
                        Text(
                            text = if (preset == 10000) "10k" else if (preset == 1000) "1k" else preset.toString(),
                            color = if (selected) MizoCyanHighlight else MizoTextSecondary,
                            fontSize = 10.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(2.dp))
            OutlinedButton(
                onClick = { onStartSimulatedSession(settings.maxActionsPerSession) },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "Run Safe Simulated Queue (${settings.maxActionsPerSession} Accounts)",
                    color = MizoLavenderAccent,
                    fontSize = 11.5.sp
                )
            }
        }
    }
}

@Composable
private fun StatMetricBox(
    label: String,
    value: String,
    valueColor: Color,
    modifier: Modifier = Modifier
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
            .background(MizoMidnightElevated.copy(alpha = 0.7f), RoundedCornerShape(8.dp))
            .padding(vertical = 6.dp, horizontal = 2.dp)
    ) {
        Text(
            text = value,
            color = valueColor,
            fontWeight = FontWeight.ExtraBold,
            fontSize = 12.sp
        )
        Text(
            text = label,
            color = MizoTextMuted,
            fontSize = 9.sp
        )
    }
}
