package com.mizoq.tiktoktoolkit.domain.engine

import com.mizoq.tiktoktoolkit.domain.model.DiscoveredAccount
import com.mizoq.tiktoktoolkit.domain.model.EligibilityEvaluation
import com.mizoq.tiktoktoolkit.domain.model.MutualStatus
import com.mizoq.tiktoktoolkit.domain.model.RelationshipState

/**
 * Enforces Mizo_q V6.0 Mutual-Friend Protection and Identity Verification rules:
 * 1. Never identifies or processes an account by display name alone — requires a valid @username handle.
 * 2. Skips accounts already unfollowed or removed in the visible UI.
 * 3. When Skip Mutuals is enabled, skips both verified MUTUAL ("Friends" / "Follows you")
 *    and UNKNOWN relationship states ("mutual_status_uncertain") to prevent accidental unfollows.
 * 4. Verifies that the target action button belongs to the same row container as the username.
 */
object EligibilityEvaluator {

    fun evaluate(account: DiscoveredAccount?, skipMutuals: Boolean): EligibilityEvaluation {
        if (account == null) {
            return EligibilityEvaluation(eligible = false, skipReason = "invalid_account_null")
        }

        val cleanUsername = account.username.trim().removePrefix("@")
        if (cleanUsername.isEmpty()) {
            return EligibilityEvaluation(
                eligible = false,
                skipReason = "missing_username_display_name_only_rejected"
            )
        }

        if (!account.buttonOwnershipVerified) {
            return EligibilityEvaluation(
                eligible = false,
                skipReason = "action_button_ownership_unverified"
            )
        }

        if (account.relationshipState == RelationshipState.NOT_FOLLOWING ||
            account.relationshipState == RelationshipState.REMOVED
        ) {
            return EligibilityEvaluation(
                eligible = false,
                skipReason = "already_processed_in_ui"
            )
        }

        if (skipMutuals) {
            if (account.mutualStatus == MutualStatus.MUTUAL) {
                return EligibilityEvaluation(
                    eligible = false,
                    skipReason = "mutual_protected"
                )
            }
            if (account.mutualStatus == MutualStatus.UNKNOWN) {
                return EligibilityEvaluation(
                    eligible = false,
                    skipReason = "mutual_status_uncertain"
                )
            }
        }

        return EligibilityEvaluation(eligible = true, skipReason = null)
    }

    /**
     * Revalidates a candidate row found in the live TikTok Accessibility tree immediately
     * before clicking its action button.
     */
    fun verifyLiveTargetBeforeAction(
        expectedUsername: String,
        reacquiredAccount: DiscoveredAccount?,
        skipMutuals: Boolean
    ): EligibilityEvaluation {
        val targetKey = expectedUsername.trim().removePrefix("@").lowercase()
        if (targetKey.isEmpty()) {
            return EligibilityEvaluation(eligible = false, skipReason = "invalid_expected_username")
        }
        if (reacquiredAccount == null) {
            return EligibilityEvaluation(
                eligible = false,
                skipReason = "account_not_confidently_reacquired"
            )
        }
        if (reacquiredAccount.normalizedUsername != targetKey) {
            return EligibilityEvaluation(
                eligible = false,
                skipReason = "username_mismatch"
            )
        }
        return evaluate(reacquiredAccount, skipMutuals)
    }
}
