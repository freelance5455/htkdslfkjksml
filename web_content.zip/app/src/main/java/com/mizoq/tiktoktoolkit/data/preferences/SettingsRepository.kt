package com.mizoq.tiktoktoolkit.data.preferences

import android.content.Context
import android.content.SharedPreferences
import com.mizoq.tiktoktoolkit.domain.model.ExecutionMode
import com.mizoq.tiktoktoolkit.domain.model.ExecutionState
import com.mizoq.tiktoktoolkit.domain.model.FollowerRemovalMethod
import com.mizoq.tiktoktoolkit.domain.model.QueueStatus
import com.mizoq.tiktoktoolkit.domain.model.SessionCounts
import com.mizoq.tiktoktoolkit.domain.model.SessionMetrics
import com.mizoq.tiktoktoolkit.domain.model.SessionSettings
import com.mizoq.tiktoktoolkit.domain.model.SessionState
import com.mizoq.tiktoktoolkit.domain.model.ThemeVariant
import com.mizoq.tiktoktoolkit.domain.model.WorkflowMode
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Persists user settings, floating overlay coordinates, and active session checkpoints
 * so Mizo_q TikTok Toolkit V6.0 recovers seamlessly after activity recreation or process restart.
 */
class SettingsRepository(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences("mizo_q_v6_prefs", Context.MODE_PRIVATE)

    private val _settingsFlow = MutableStateFlow(loadSettingsFromPrefs())
    val settingsFlow: StateFlow<SessionSettings> = _settingsFlow.asStateFlow()

    fun getSettings(): SessionSettings = _settingsFlow.value

    fun saveSettings(newSettings: SessionSettings): Pair<SessionSettings, List<String>> {
        val (sanitized, errors) = newSettings.validateAndSanitize()
        prefs.edit()
            .putLong("minDelayMs", sanitized.minDelayMs)
            .putLong("maxDelayMs", sanitized.maxDelayMs)
            .putInt("maxActionsPerSession", sanitized.maxActionsPerSession)
            .putInt("maxScanDurationSec", sanitized.maxScanDurationSec)
            .putBoolean("skipMutuals", sanitized.skipMutuals)
            .putBoolean("autoOpenList", sanitized.autoOpenList)
            .putBoolean("autoScan", sanitized.autoScan)
            .putBoolean("autoScroll", sanitized.autoScroll)
            .putBoolean("autoExportCsv", sanitized.autoExportCsv)
            .putBoolean("notificationsEnabled", sanitized.notificationsEnabled)
            .putBoolean("criticalNotificationsOnly", sanitized.criticalNotificationsOnly)
            .putBoolean("reducedMotion", sanitized.reducedMotion)
            .putBoolean("ambientOrbs", sanitized.ambientOrbs)
            .putString("themeVariant", sanitized.themeVariant.wireValue)
            .putBoolean("confirmBulkActions", sanitized.confirmBulkActions)
            .putString("executionMode", sanitized.executionMode.wireValue)
            .putString("followerRemovalMethod", sanitized.followerRemovalMethod.wireValue)
            .apply()
        _settingsFlow.value = sanitized
        return sanitized to errors
    }

    fun resetSettingsToDefaults(): SessionSettings {
        val defaults = SessionSettings()
        saveSettings(defaults)
        return defaults
    }

    fun saveOverlayPosition(x: Int, y: Int) {
        prefs.edit()
            .putInt("overlay_x", x)
            .putInt("overlay_y", y)
            .apply()
    }

    fun getOverlayPosition(defaultX: Int = 24, defaultY: Int = 220): Pair<Int, Int> {
        return prefs.getInt("overlay_x", defaultX) to prefs.getInt("overlay_y", defaultY)
    }

    fun saveSessionCheckpoint(state: SessionState) {
        prefs.edit()
            .putString("cp_sessionId", state.sessionId)
            .putString("cp_status", state.status.wireValue)
            .putString("cp_execState", state.executionState.wireValue)
            .putString("cp_workflowMode", state.workflowMode.wireValue)
            .putBoolean("cp_isSimulated", state.isSimulatedMode)
            .putString("cp_inFlightUser", state.inFlightUsername)
            .putBoolean("cp_hasUncertainInFlight", state.hasUncertainActionInFlight)
            .putBoolean("cp_captchaResolved", state.captchaResolvedReadyToResume)
            .putString("cp_lastSuccessUser", state.lastSuccessfulUsername)
            .putInt("cp_scanned", state.counts.scanned)
            .putInt("cp_queued", state.counts.queued)
            .putInt("cp_completed", state.counts.completed)
            .putInt("cp_skipped", state.counts.skipped)
            .putInt("cp_pending", state.counts.pending)
            .putInt("cp_failed", state.counts.failed)
            .putInt("cp_uncertain", state.counts.uncertain)
            .putInt("cp_mutualProtected", state.counts.mutualProtected)
            .putInt("cp_uncertainSkipped", state.counts.uncertainSkipped)
            .putInt("cp_configuredLimit", state.counts.configuredLimit)
            .putLong("cp_accumulatedMs", state.metrics.accumulatedElapsedMs)
            .putString("cp_elapsedFormatted", state.metrics.elapsedFormatted)
            .putString("cp_interruptionReason", state.interruptionReason)
            .putString("cp_securityWarning", state.securityWarning)
            .putString("cp_completionReport", state.completionReport)
            .putString("cp_lastExportFilename", state.lastExportFilename)
            .putString("cp_lastExportStatus", state.lastExportStatus)
            .apply()
    }

    fun loadSessionCheckpoint(): SessionState {
        val limit = prefs.getInt("cp_configuredLimit", _settingsFlow.value.maxActionsPerSession)
        val rawStatus = QueueStatus.fromWireValue(prefs.getString("cp_status", "idle"))
        // If process died while actively scanning/processing, transition into RECOVERING so we reconcile first
        val recoveredStatus = if (rawStatus.isActiveRun) QueueStatus.RECOVERING else rawStatus
        val recoveredReason = if (rawStatus.isActiveRun) {
            "Session recovered after Android process or activity restart. Reconcile with TikTok screen before resuming."
        } else {
            prefs.getString("cp_interruptionReason", null)
        }

        return SessionState(
            sessionId = prefs.getString("cp_sessionId", null),
            status = recoveredStatus,
            executionState = ExecutionState.fromWireValue(prefs.getString("cp_execState", "standby")),
            workflowMode = WorkflowMode.fromWireValue(prefs.getString("cp_workflowMode", "following")),
            isSimulatedMode = prefs.getBoolean("cp_isSimulated", false),
            inFlightUsername = prefs.getString("cp_inFlightUser", null),
            hasUncertainActionInFlight = prefs.getBoolean("cp_hasUncertainInFlight", false),
            captchaResolvedReadyToResume = prefs.getBoolean("cp_captchaResolved", false),
            lastSuccessfulUsername = prefs.getString("cp_lastSuccessUser", null),
            counts = SessionCounts(
                scanned = prefs.getInt("cp_scanned", 0),
                queued = prefs.getInt("cp_queued", 0),
                completed = prefs.getInt("cp_completed", 0),
                skipped = prefs.getInt("cp_skipped", 0),
                pending = prefs.getInt("cp_pending", 0),
                failed = prefs.getInt("cp_failed", 0),
                uncertain = prefs.getInt("cp_uncertain", 0),
                mutualProtected = prefs.getInt("cp_mutualProtected", 0),
                uncertainSkipped = prefs.getInt("cp_uncertainSkipped", 0),
                configuredLimit = limit
            ),
            metrics = SessionMetrics(
                accumulatedElapsedMs = prefs.getLong("cp_accumulatedMs", 0L),
                elapsedFormatted = prefs.getString("cp_elapsedFormatted", "0s") ?: "0s"
            ),
            interruptionReason = recoveredReason,
            securityWarning = prefs.getString("cp_securityWarning", null),
            completionReport = prefs.getString("cp_completionReport", null),
            lastExportFilename = prefs.getString("cp_lastExportFilename", null),
            lastExportStatus = prefs.getString("cp_lastExportStatus", null)
        )
    }

    private fun loadSettingsFromPrefs(): SessionSettings {
        val raw = SessionSettings(
            minDelayMs = prefs.getLong("minDelayMs", 2000L),
            maxDelayMs = prefs.getLong("maxDelayMs", 4000L),
            maxActionsPerSession = prefs.getInt("maxActionsPerSession", 100),
            maxScanDurationSec = prefs.getInt("maxScanDurationSec", 3600),
            skipMutuals = prefs.getBoolean("skipMutuals", true),
            autoOpenList = prefs.getBoolean("autoOpenList", true),
            autoScan = prefs.getBoolean("autoScan", true),
            autoScroll = prefs.getBoolean("autoScroll", true),
            autoExportCsv = prefs.getBoolean("autoExportCsv", true),
            notificationsEnabled = prefs.getBoolean("notificationsEnabled", true),
            criticalNotificationsOnly = prefs.getBoolean("criticalNotificationsOnly", false),
            reducedMotion = prefs.getBoolean("reducedMotion", false),
            ambientOrbs = prefs.getBoolean("ambientOrbs", true),
            themeVariant = ThemeVariant.fromWireValue(prefs.getString("themeVariant", "midnight_nebula")),
            confirmBulkActions = prefs.getBoolean("confirmBulkActions", true),
            executionMode = if (prefs.getString("executionMode", "auto") == "guided") ExecutionMode.GUIDED else ExecutionMode.AUTO,
            followerRemovalMethod = if (prefs.getString("followerRemovalMethod", "native_remove") == "guided_block_unblock") {
                FollowerRemovalMethod.GUIDED_BLOCK_UNBLOCK
            } else {
                FollowerRemovalMethod.NATIVE_REMOVE
            }
        )
        return raw.validateAndSanitize().first
    }
}
