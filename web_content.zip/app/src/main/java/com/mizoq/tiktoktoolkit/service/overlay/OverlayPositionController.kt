package com.mizoq.tiktoktoolkit.service.overlay

import kotlin.math.abs

/**
 * Pure coordinate controller for the draggable Mizo_q Floating Control Panel.
 * Ensures the floating pill and expanded panel always remain within visible screen bounds
 * and away from Android status/navigation bars so important TikTok controls are not obstructed.
 */
object OverlayPositionController {

    data class ClampedPosition(val x: Int, val y: Int)

    fun clampCoordinates(
        desiredX: Int,
        desiredY: Int,
        overlayWidthPx: Int,
        overlayHeightPx: Int,
        screenWidthPx: Int,
        screenHeightPx: Int,
        topInsetPx: Int = 72,
        bottomInsetPx: Int = 120,
        horizontalMarginPx: Int = 12
    ): ClampedPosition {
        val minX = horizontalMarginPx
        val maxX = (screenWidthPx - overlayWidthPx - horizontalMarginPx).coerceAtLeast(minX)
        val minY = topInsetPx.coerceAtLeast(0)
        val maxY = (screenHeightPx - overlayHeightPx - bottomInsetPx).coerceAtLeast(minY)

        return ClampedPosition(
            x = desiredX.coerceIn(minX, maxX),
            y = desiredY.coerceIn(minY, maxY)
        )
    }

    fun isTapGesture(
        startX: Float,
        startY: Float,
        endX: Float,
        endY: Float,
        touchSlopPx: Int = 18
    ): Boolean {
        return abs(endX - startX) <= touchSlopPx && abs(endY - startY) <= touchSlopPx
    }
}
