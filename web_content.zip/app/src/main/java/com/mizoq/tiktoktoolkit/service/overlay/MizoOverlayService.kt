package com.mizoq.tiktoktoolkit.service.overlay

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.CheckBox
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.mizoq.tiktoktoolkit.MainActivity
import com.mizoq.tiktoktoolkit.MizoApplication
import com.mizoq.tiktoktoolkit.R
import com.mizoq.tiktoktoolkit.config.MizoBrandConfig
import com.mizoq.tiktoktoolkit.domain.model.SessionState
import com.mizoq.tiktoktoolkit.domain.model.WorkflowMode
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * Mizo_q V6.0 Floating Control Panel & Persistent Foreground Service.
 *
 * Features (Sections 3, 9, 11, 12):
 * - Checks Settings.canDrawOverlays(this) before attaching TYPE_APPLICATION_OVERLAY.
 * - Uses FLAG_NOT_FOCUSABLE so TikTok underneath receives normal touches and Mizo_q never
 *   secretly intercepts keyboard input or operates invisibly.
 * - Starts as a compact draggable Mizo_q ("MQ V6.0") pill button and expands on tap into a
 *   full touch-friendly control panel with:
 *   Start, Pause, Resume, Stop (high-contrast ruby button), Current Status, Completed, Scanned,
 *   Skipped, Failed, Remaining, Skip Mutuals toggle, Export CSV, Open Full Dashboard, Collapse, and Close.
 * - Displays a persistent foreground notification with Pause, Resume, and Stop actions.
 */
class MizoOverlayService : Service() {

    companion object {
        const val ACTION_SHOW_OVERLAY = "com.mizoq.tiktoktoolkit.action.SHOW_OVERLAY"
        const val ACTION_HIDE_OVERLAY = "com.mizoq.tiktoktoolkit.action.HIDE_OVERLAY"
        const val ACTION_START_SESSION = "com.mizoq.tiktoktoolkit.action.START_SESSION"
        const val ACTION_PAUSE_SESSION = "com.mizoq.tiktoktoolkit.action.PAUSE_SESSION"
        const val ACTION_RESUME_SESSION = "com.mizoq.tiktoktoolkit.action.RESUME_SESSION"
        const val ACTION_STOP_SESSION = "com.mizoq.tiktoktoolkit.action.STOP_SESSION"
        const val ACTION_EXPORT_CSV = "com.mizoq.tiktoktoolkit.action.EXPORT_CSV"

        private val _isOverlayVisibleFlow = MutableStateFlow(false)
        val isOverlayVisibleFlow: StateFlow<Boolean> = _isOverlayVisibleFlow.asStateFlow()

        private val _isExpandedFlow = MutableStateFlow(false)
        val isExpandedFlow: StateFlow<Boolean> = _isExpandedFlow.asStateFlow()
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var windowManager: WindowManager? = null
    private var rootOverlayContainer: FrameLayout? = null
    private var collapsedPillView: TextView? = null
    private var expandedCardView: LinearLayout? = null
    private var layoutParams: WindowManager.LayoutParams? = null

    // Live UI references inside Expanded Floating Panel
    private var tvStatusLine: TextView? = null
    private var tvCountersLine1: TextView? = null
    private var tvCountersLine2: TextView? = null
    private var cbSkipMutuals: CheckBox? = null
    private var btnStart: Button? = null
    private var btnPause: Button? = null
    private var btnResume: Button? = null
    private var btnStop: Button? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        val app = applicationContext as MizoApplication
        serviceScope.launch {
            app.automationEngine.sessionState.collect { state ->
                updateOverlayViews(state)
                updateForegroundNotification(state)
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val app = applicationContext as MizoApplication
        val engine = app.automationEngine

        when (intent?.action) {
            ACTION_HIDE_OVERLAY -> {
                removeOverlayWindow()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_START_SESSION -> {
                engine.startSession(mode = engine.sessionState.value.workflowMode, isSimulated = false)
            }
            ACTION_PAUSE_SESSION -> {
                engine.pauseSession("Paused from Mizo_q control.")
            }
            ACTION_RESUME_SESSION -> {
                engine.resumeSession()
            }
            ACTION_STOP_SESSION -> {
                engine.stopSessionAndExport()
            }
            ACTION_EXPORT_CSV -> {
                engine.stopSessionAndExport()
            }
        }

        // Android 15 (API 35) order-of-operations compliance: attach visible overlay before starting FGS
        if (Settings.canDrawOverlays(this)) {
            ensureOverlayAttached()
        }

        startForegroundSafely(engine.sessionState.value)
        return START_STICKY
    }

    override fun onDestroy() {
        removeOverlayWindow()
        serviceScope.cancel()
        super.onDestroy()
    }

    private fun startForegroundSafely(state: SessionState) {
        val notification = buildPersistentNotification(state)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                startForeground(
                    MizoBrandConfig.FOREGROUND_NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                )
            } else {
                startForeground(MizoBrandConfig.FOREGROUND_NOTIFICATION_ID, notification)
            }
        } catch (_: Exception) {
            // Respect Android background FGS restrictions without crashing
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun ensureOverlayAttached() {
        if (rootOverlayContainer != null) return
        val wm = windowManager ?: return
        val app = applicationContext as MizoApplication
        val (savedX, savedY) = app.settingsRepository.getOverlayPosition()

        val windowType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            windowType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = savedX
            y = savedY
        }
        layoutParams = params

        val container = FrameLayout(this)

        // 1. Collapsed Draggable Mizo_q Pill Button
        val pill = TextView(this).apply {
            text = "${MizoBrandConfig.MONOGRAM} • ${MizoBrandConfig.VERSION_BADGE}"
            setTextColor(Color.parseColor("#F8FAFC"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.parseColor("#0B1021"), Color.parseColor("#4C1D95"), Color.parseColor("#0891B2"))
            ).apply {
                cornerRadius = dp(24).toFloat()
                setStroke(dp(2), Color.parseColor("#22D3EE"))
            }
        }

        // 2. Expanded Compact Floating Control Panel
        val card = buildExpandedPanelView(app)
        card.visibility = View.GONE

        var downRawX = 0f
        var downRawY = 0f
        var initialParamX = 0
        var initialParamY = 0

        val dragTouchListener = View.OnTouchListener { _, event ->
            val lp = layoutParams ?: return@OnTouchListener false
            val metrics = resources.displayMetrics
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = event.rawX
                    downRawY = event.rawY
                    initialParamX = lp.x
                    initialParamY = lp.y
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val desiredX = initialParamX + (event.rawX - downRawX).toInt()
                    val desiredY = initialParamY + (event.rawY - downRawY).toInt()
                    val clamped = OverlayPositionController.clampCoordinates(
                        desiredX = desiredX,
                        desiredY = desiredY,
                        overlayWidthPx = container.width.coerceAtLeast(dp(120)),
                        overlayHeightPx = container.height.coerceAtLeast(dp(48)),
                        screenWidthPx = metrics.widthPixels,
                        screenHeightPx = metrics.heightPixels
                    )
                    lp.x = clamped.x
                    lp.y = clamped.y
                    wm.updateViewLayout(container, lp)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    app.settingsRepository.saveOverlayPosition(lp.x, lp.y)
                    if (OverlayPositionController.isTapGesture(downRawX, downRawY, event.rawX, event.rawY)) {
                        setPanelExpanded(true)
                    }
                    true
                }
                else -> false
            }
        }

        pill.setOnTouchListener(dragTouchListener)

        container.addView(pill)
        container.addView(card)

        wm.addView(container, params)
        rootOverlayContainer = container
        collapsedPillView = pill
        expandedCardView = card
        _isOverlayVisibleFlow.value = true
        updateOverlayViews(app.automationEngine.sessionState.value)
    }

    private fun buildExpandedPanelView(app: MizoApplication): LinearLayout {
        val engine = app.automationEngine
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.parseColor("#EE0B1021"), Color.parseColor("#F2131C38"))
            ).apply {
                cornerRadius = dp(16).toFloat()
                setStroke(dp(1), Color.parseColor("#22D3EE"))
            }
        }

        // Top Header Row: Title + Collapse (_) + Close (X)
        val headerRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val titleTv = TextView(this).apply {
            text = "${MizoBrandConfig.BRAND_NAME} ${MizoBrandConfig.VERSION_BADGE}"
            setTextColor(Color.parseColor("#67E8F9"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            typeface = Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val btnCollapse = createCompactButton("—", "#334155") {
            setPanelExpanded(false)
        }
        val btnClose = createCompactButton("✕", "#991B1B") {
            startService(Intent(this, MizoOverlayService::class.java).apply { action = ACTION_HIDE_OVERLAY })
        }
        headerRow.addView(titleTv)
        headerRow.addView(btnCollapse)
        headerRow.addView(btnClose)
        panel.addView(headerRow)

        // Status & Live Counters
        tvStatusLine = TextView(this).apply {
            setTextColor(Color.parseColor("#F8FAFC"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
            setPadding(0, dp(4), 0, dp(2))
        }
        tvCountersLine1 = TextView(this).apply {
            setTextColor(Color.parseColor("#CBD5E1"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f)
        }
        tvCountersLine2 = TextView(this).apply {
            setTextColor(Color.parseColor("#C4B5FD"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f)
            setPadding(0, 0, 0, dp(4))
        }
        panel.addView(tvStatusLine)
        panel.addView(tvCountersLine1)
        panel.addView(tvCountersLine2)

        // Skip Mutuals CheckBox
        cbSkipMutuals = CheckBox(this).apply {
            text = "Skip Mutuals (Friends & Uncertain)"
            setTextColor(Color.parseColor("#F8FAFC"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            isChecked = app.settingsRepository.getSettings().skipMutuals
            setOnCheckedChangeListener { _, checked ->
                val curSettings = app.settingsRepository.getSettings()
                app.settingsRepository.saveSettings(curSettings.copy(skipMutuals = checked))
            }
        }
        panel.addView(cbSkipMutuals)

        // Primary Controls Row 1: Start, Pause, Resume
        val controlsRow1 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(4), 0, dp(4))
        }
        btnStart = createTouchActionButton("Start", "#7C3AED") {
            engine.startSession(mode = engine.sessionState.value.workflowMode, isSimulated = false)
        }
        btnPause = createTouchActionButton("Pause", "#334155") {
            engine.pauseSession("Paused from floating panel.")
        }
        btnResume = createTouchActionButton("Resume", "#0891B2") {
            engine.resumeSession()
        }
        controlsRow1.addView(btnStart)
        controlsRow1.addView(btnPause)
        controlsRow1.addView(btnResume)
        panel.addView(controlsRow1)

        // Primary Controls Row 2: Prominent Stop & CSV, Export CSV, Open Dashboard
        val controlsRow2 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        btnStop = createTouchActionButton("Stop & CSV", "#DC2626") {
            engine.stopSessionAndExport()
        }
        val btnExport = createTouchActionButton("Export CSV", "#0E7490") {
            engine.stopSessionAndExport()
        }
        val btnDashboard = createTouchActionButton("Dashboard", "#4F46E5") {
            val dashIntent = Intent(this, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            }
            startActivity(dashIntent)
        }
        controlsRow2.addView(btnStop)
        controlsRow2.addView(btnExport)
        controlsRow2.addView(btnDashboard)
        panel.addView(controlsRow2)

        return panel
    }

    private fun setPanelExpanded(expanded: Boolean) {
        _isExpandedFlow.value = expanded
        collapsedPillView?.visibility = if (expanded) View.GONE else View.VISIBLE
        expandedCardView?.visibility = if (expanded) View.VISIBLE else View.GONE
    }

    private fun updateOverlayViews(state: SessionState) {
        val c = state.counts
        tvStatusLine?.text = "State: ${state.status.displayLabel} (${state.executionState.badgeText})"
        tvCountersLine1?.text = "Done: ${c.completed} | Scan: ${c.scanned} | Skip: ${c.skipped}"
        tvCountersLine2?.text = "Fail: ${c.failedAndUncertain} | Remaining: ${c.remaining} / ${c.configuredLimit}"

        val isRunning = state.status.isActiveRun
        btnStart?.isEnabled = !isRunning
        btnPause?.isEnabled = isRunning
        btnResume?.isEnabled = state.status.canResume || state.captchaResolvedReadyToResume
        btnStop?.isEnabled = state.status.canStop
    }

    private fun buildPersistentNotification(state: SessionState): Notification {
        val openAppPending = PendingIntent.getActivity(
            this,
            100,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val pausePending = PendingIntent.getService(
            this,
            101,
            Intent(this, MizoOverlayService::class.java).apply { action = ACTION_PAUSE_SESSION },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val resumePending = PendingIntent.getService(
            this,
            102,
            Intent(this, MizoOverlayService::class.java).apply { action = ACTION_RESUME_SESSION },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopPending = PendingIntent.getService(
            this,
            103,
            Intent(this, MizoOverlayService::class.java).apply { action = ACTION_STOP_SESSION },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val c = state.counts
        val contentText = "${state.status.displayLabel} • Done: ${c.completed}/${c.configuredLimit} • Left: ${c.remaining}"

        return NotificationCompat.Builder(this, MizoBrandConfig.OVERLAY_NOTIFICATION_CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("${MizoBrandConfig.PRODUCT_TITLE} (${MizoBrandConfig.VERSION_BADGE})")
            .setContentText(contentText)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openAppPending)
            .addAction(0, "Pause", pausePending)
            .addAction(0, "Resume", resumePending)
            .addAction(0, "Stop & CSV", stopPending)
            .build()
    }

    private fun updateForegroundNotification(state: SessionState) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(MizoBrandConfig.FOREGROUND_NOTIFICATION_ID, buildPersistentNotification(state))
    }

    private fun removeOverlayWindow() {
        val container = rootOverlayContainer ?: return
        try {
            windowManager?.removeView(container)
        } catch (_: Exception) {
        }
        rootOverlayContainer = null
        collapsedPillView = null
        expandedCardView = null
        _isOverlayVisibleFlow.value = false
        _isExpandedFlow.value = false
    }

    private fun createCompactButton(label: String, bgHex: String, onClick: () -> Unit): Button {
        return Button(this).apply {
            text = label
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            minWidth = dp(36)
            minimumWidth = dp(36)
            minHeight = dp(36)
            minimumHeight = dp(36)
            setPadding(dp(8), dp(4), dp(8), dp(4))
            background = GradientDrawable().apply {
                setColor(Color.parseColor(bgHex))
                cornerRadius = dp(8).toFloat()
            }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                marginStart = dp(4)
            }
            setOnClickListener { onClick() }
        }
    }

    private fun createTouchActionButton(label: String, bgHex: String, onClick: () -> Unit): Button {
        return Button(this).apply {
            text = label
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            typeface = Typeface.DEFAULT_BOLD
            minHeight = dp(44)
            minimumHeight = dp(44)
            setPadding(dp(10), dp(8), dp(10), dp(8))
            background = GradientDrawable().apply {
                setColor(Color.parseColor(bgHex))
                cornerRadius = dp(10).toFloat()
            }
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginEnd = dp(4)
            }
            setOnClickListener { onClick() }
        }
    }

    private fun dp(value: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value.toFloat(),
            resources.displayMetrics
        ).toInt()
    }
}
