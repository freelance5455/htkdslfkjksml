package com.mizoq.tiktoktoolkit.config

/**
 * Single centralized branding & platform configuration for Mizo_q TikTok Toolkit V6.0.
 * Shared across Jetpack Compose screens, Floating Overlay Panel, Foreground Notifications,
 * AccessibilityService descriptions, and CSV Session Exports.
 */
object MizoBrandConfig {
    const val BRAND_NAME: String = "Mizo_q"
    const val PRODUCT_TITLE: String = "Mizo_q TikTok Toolkit"
    const val PRODUCT_SUBTITLE: String = "Unfollow Manager V6.0"
    const val FULL_DISPLAY_TITLE: String = "Mizo_q TikTok Toolkit — Unfollow Manager V6.0"
    const val VERSION_NAME: String = "6.0.0"
    const val VERSION_BADGE: String = "V6.0"
    const val MONOGRAM: String = "MQ"
    const val CSV_FILE_PREFIX: String = "tiktok-unfollower-session"

    /**
     * Official TikTok Android application package names:
     * - com.zhiliaoapp.musically: Global / Americas / Europe release
     * - com.ss.android.ugc.trill: Asia / East & Southeast Asia release
     * - com.zhiliaoapp.musically.go: TikTok Lite release
     */
    val OFFICIAL_TIKTOK_PACKAGES: Set<String> = setOf(
        "com.zhiliaoapp.musically",
        "com.ss.android.ugc.trill",
        "com.zhiliaoapp.musically.go"
    )

    const val MAX_SESSION_LIMIT: Int = 10_000
    val SESSION_LIMIT_PRESETS: List<Int> = listOf(20, 50, 100, 500, 1_000, 5_000, 10_000)

    const val OVERLAY_NOTIFICATION_CHANNEL_ID: String = "mizo_q_overlay_session_channel"
    const val ALERTS_NOTIFICATION_CHANNEL_ID: String = "mizo_q_critical_alerts_channel"
    const val FOREGROUND_NOTIFICATION_ID: Int = 6001
}
