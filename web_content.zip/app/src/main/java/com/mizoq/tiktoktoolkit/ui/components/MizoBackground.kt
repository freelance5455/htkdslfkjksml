package com.mizoq.tiktoktoolkit.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import com.mizoq.tiktoktoolkit.R
import com.mizoq.tiktoktoolkit.ui.theme.LocalReducedMotion
import com.mizoq.tiktoktoolkit.ui.theme.MizoCyanHighlight
import com.mizoq.tiktoktoolkit.ui.theme.MizoLavenderAccent
import com.mizoq.tiktoktoolkit.ui.theme.MizoPurplePrimary

/**
 * Renders the locally bundled Mizo_q nebula vector drawable (`R.drawable.bg_mizo_nebula`)
 * layered with subtle ambient radial lighting orbs that respect `reducedMotion` and `ambientOrbs`.
 */
@Composable
fun MizoBackground(
    ambientOrbsEnabled: Boolean,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    val reducedMotion = LocalReducedMotion.current
    val transition = rememberInfiniteTransition(label = "mizo_ambient_orbs")
    val drift by transition.animateFloat(
        initialValue = 0f,
        targetValue = if (reducedMotion) 0f else 28f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 12_000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "orb_drift"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Bundled Vector Drawable Background Illustration
        Image(
            painter = painterResource(id = R.drawable.bg_mizo_nebula),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        if (ambientOrbsEnabled) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height

                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(MizoPurplePrimary.copy(alpha = 0.22f), Color.Transparent),
                        center = Offset(w * 0.18f + drift, h * 0.14f + drift),
                        radius = w * 0.55f
                    ),
                    radius = w * 0.55f,
                    center = Offset(w * 0.18f + drift, h * 0.14f + drift)
                )

                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(MizoCyanHighlight.copy(alpha = 0.16f), Color.Transparent),
                        center = Offset(w * 0.85f - drift, h * 0.30f + drift * 0.5f),
                        radius = w * 0.48f
                    ),
                    radius = w * 0.48f,
                    center = Offset(w * 0.85f - drift, h * 0.30f + drift * 0.5f)
                )

                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(MizoLavenderAccent.copy(alpha = 0.14f), Color.Transparent),
                        center = Offset(w * 0.50f, h * 0.88f - drift),
                        radius = w * 0.52f
                    ),
                    radius = w * 0.52f,
                    center = Offset(w * 0.50f, h * 0.88f - drift)
                )
            }
        }

        content()
    }
}
