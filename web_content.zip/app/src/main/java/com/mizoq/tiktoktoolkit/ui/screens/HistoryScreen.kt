package com.mizoq.tiktoktoolkit.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mizoq.tiktoktoolkit.data.local.ActionHistoryEntity
import com.mizoq.tiktoktoolkit.data.local.ExportRecordEntity
import com.mizoq.tiktoktoolkit.domain.model.SessionAnalyticsSummary
import com.mizoq.tiktoktoolkit.ui.theme.MizoAmberWarning
import com.mizoq.tiktoktoolkit.ui.theme.MizoCyanHighlight
import com.mizoq.tiktoktoolkit.ui.theme.MizoMidnightElevated
import com.mizoq.tiktoktoolkit.ui.theme.MizoMidnightSurface
import com.mizoq.tiktoktoolkit.ui.theme.MizoMintSuccess
import com.mizoq.tiktoktoolkit.ui.theme.MizoPurplePrimary
import com.mizoq.tiktoktoolkit.ui.theme.MizoRoseDanger
import com.mizoq.tiktoktoolkit.ui.theme.MizoTextMuted
import com.mizoq.tiktoktoolkit.ui.theme.MizoTextPrimary
import com.mizoq.tiktoktoolkit.ui.theme.MizoTextSecondary

@Composable
fun HistoryScreen(
    sessionAnalytics: List<SessionAnalyticsSummary>,
    exportRecords: List<ExportRecordEntity>,
    historyItems: List<ActionHistoryEntity>,
    onRetryOrManualExport: () -> Unit,
    onRequestClearHistory: () -> Unit
) {
    var resultFilter by remember { mutableStateOf("all") }
    var actionFilter by remember { mutableStateOf("all") }
    var searchQuery by remember { mutableStateOf("") }

    val filteredHistory = remember(historyItems, resultFilter, actionFilter, searchQuery) {
        val q = searchQuery.trim().lowercase()
        historyItems.filter { item ->
            (resultFilter == "all" || item.result.equals(resultFilter, ignoreCase = true)) &&
                (actionFilter == "all" || item.requestedAction.equals(actionFilter, ignoreCase = true)) &&
                (q.isEmpty() || item.username.lowercase().contains(q) ||
                    item.skipReason.lowercase().contains(q) ||
                    item.errorDetails.lowercase().contains(q))
        }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // 1. Real Calculated Session Analytics Card
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(MizoMidnightSurface.copy(alpha = 0.9f), RoundedCornerShape(14.dp))
                .border(1.dp, MizoCyanHighlight.copy(alpha = 0.25f), RoundedCornerShape(14.dp))
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(
                text = "Session Analytics (${sessionAnalytics.size} sessions)",
                color = MizoCyanHighlight,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp
            )

            if (sessionAnalytics.isEmpty()) {
                Text(
                    text = "Session statistics are calculated automatically from recorded Room events.",
                    color = MizoTextMuted,
                    fontSize = 11.5.sp
                )
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 130.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(sessionAnalytics, key = { it.sessionId }) { sess ->
                        val statusBadge = if (sess.isIncomplete) "INCOMPLETE (${sess.status.displayLabel})" else "COMPLETED"
                        val statusColor = if (sess.isIncomplete) MizoAmberWarning else MizoMintSuccess
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(MizoMidnightElevated.copy(alpha = 0.75f), RoundedCornerShape(8.dp))
                                .padding(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "${sess.requestedAction} • Dur: ${sess.durationFormatted}",
                                    color = MizoTextPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.5.sp
                                )
                                Text(
                                    text = statusBadge,
                                    color = statusColor,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp
                                )
                            }
                            Text(
                                text = "OK: ${sess.successfulCount} | Skip: ${sess.skippedCount} | Fail: ${sess.failedCount} | Unc: ${sess.uncertainCount} • ${sess.exportStatus.displayLabel}",
                                color = MizoTextSecondary,
                                fontSize = 10.5.sp
                            )
                        }
                    }
                }
            }
        }

        // 2. CSV Export History & Retry Card
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(MizoMidnightSurface.copy(alpha = 0.9f), RoundedCornerShape(14.dp))
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "CSV Export History (${exportRecords.size})",
                    color = MizoTextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.5.sp
                )
                Button(
                    onClick = onRetryOrManualExport,
                    colors = ButtonDefaults.buttonColors(containerColor = MizoPurplePrimary)
                ) {
                    Text("Export / Retry CSV", color = Color.White, fontSize = 11.sp)
                }
            }

            for (exp in exportRecords.take(3)) {
                Text(
                    text = "• ${exp.filename} (${exp.recordCount} rows) — ${exp.status.uppercase()}",
                    color = MizoTextSecondary,
                    fontSize = 11.sp
                )
            }
        }

        // 3. Filtered Local Action Log
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(MizoMidnightSurface.copy(alpha = 0.9f), RoundedCornerShape(14.dp))
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Action History (${filteredHistory.size} records)",
                    color = MizoTextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.5.sp
                )
                OutlinedButton(onClick = onRequestClearHistory) {
                    Text("Clear History", color = MizoRoseDanger, fontSize = 11.sp)
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                for (resOpt in listOf("all", "success", "skipped", "failed", "uncertain")) {
                    OutlinedButton(
                        onClick = { resultFilter = resOpt },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = resOpt.replaceFirstChar { it.uppercase() },
                            color = if (resultFilter == resOpt) MizoCyanHighlight else MizoTextSecondary,
                            fontSize = 9.5.sp
                        )
                    }
                }
            }

            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                label = { Text("Search @username, skip reason, or error") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 220.dp),
                verticalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                items(filteredHistory, key = { it.id }) { item ->
                    val badgeColor = when (item.result) {
                        "success" -> MizoMintSuccess
                        "skipped" -> MizoCyanHighlight
                        "uncertain" -> MizoAmberWarning
                        else -> MizoRoseDanger
                    }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MizoMidnightElevated.copy(alpha = 0.75f), RoundedCornerShape(8.dp))
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "@${item.username} (${item.displayName})",
                                color = MizoTextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.5.sp
                            )
                            val detail = item.skipReason.ifEmpty { item.errorDetails.ifEmpty { item.requestedAction } }
                            Text(
                                text = detail,
                                color = MizoTextSecondary,
                                fontSize = 10.5.sp
                            )
                        }
                        Text(
                            text = item.result.uppercase(),
                            color = badgeColor,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp
                        )
                    }
                }
            }
        }
    }
}
