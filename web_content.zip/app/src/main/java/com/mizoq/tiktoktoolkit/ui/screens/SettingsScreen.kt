package com.mizoq.tiktoktoolkit.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mizoq.tiktoktoolkit.domain.model.ExecutionMode
import com.mizoq.tiktoktoolkit.domain.model.SessionSettings
import com.mizoq.tiktoktoolkit.domain.model.ThemeVariant
import com.mizoq.tiktoktoolkit.ui.theme.MizoCyanHighlight
import com.mizoq.tiktoktoolkit.ui.theme.MizoMidnightSurface
import com.mizoq.tiktoktoolkit.ui.theme.MizoPurplePrimary
import com.mizoq.tiktoktoolkit.ui.theme.MizoRoseDanger
import com.mizoq.tiktoktoolkit.ui.theme.MizoTextPrimary
import com.mizoq.tiktoktoolkit.ui.theme.MizoTextSecondary

@Composable
fun SettingsScreen(
    settings: SessionSettings,
    onSaveSettings: (SessionSettings) -> Unit,
    onRequestResetSettings: () -> Unit,
    onRequestClearHistory: () -> Unit,
    onDisableAccessibilityService: () -> Unit,
    onHideFloatingOverlay: () -> Unit
) {
    var limitInput by remember(settings.maxActionsPerSession) { mutableStateOf(settings.maxActionsPerSession.toString()) }
    var minDelayInput by remember(settings.minDelayMs) { mutableStateOf(settings.minDelayMs.toString()) }
    var maxDelayInput by remember(settings.maxDelayMs) { mutableStateOf(settings.maxDelayMs.toString()) }
    var skipMutuals by remember(settings.skipMutuals) { mutableStateOf(settings.skipMutuals) }
    var autoScroll by remember(settings.autoScroll) { mutableStateOf(settings.autoScroll) }
    var autoExportCsv by remember(settings.autoExportCsv) { mutableStateOf(settings.autoExportCsv) }
    var notificationsEnabled by remember(settings.notificationsEnabled) { mutableStateOf(settings.notificationsEnabled) }
    var criticalOnly by remember(settings.criticalNotificationsOnly) { mutableStateOf(settings.criticalNotificationsOnly) }
    var reducedMotion by remember(settings.reducedMotion) { mutableStateOf(settings.reducedMotion) }
    var ambientOrbs by remember(settings.ambientOrbs) { mutableStateOf(settings.ambientOrbs) }
    var confirmBulk by remember(settings.confirmBulkActions) { mutableStateOf(settings.confirmBulkActions) }
    var guidedMode by remember(settings.executionMode) { mutableStateOf(settings.executionMode == ExecutionMode.GUIDED) }
    var themeVariant by remember(settings.themeVariant) { mutableStateOf(settings.themeVariant) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(MizoMidnightSurface.copy(alpha = 0.92f), RoundedCornerShape(14.dp))
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = "Session Limits & Pacing",
                color = MizoCyanHighlight,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp
            )

            OutlinedTextField(
                value = limitInput,
                onValueChange = { limitInput = it },
                label = { Text("Session Action Limit (1 – 10,000)") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = minDelayInput,
                    onValueChange = { minDelayInput = it },
                    label = { Text("Min Delay (ms)") },
                    modifier = Modifier.weight(1f),
                    singleLine = true
                )
                OutlinedTextField(
                    value = maxDelayInput,
                    onValueChange = { maxDelayInput = it },
                    label = { Text("Max Delay (ms)") },
                    modifier = Modifier.weight(1f),
                    singleLine = true
                )
            }

            SettingToggleRow("Skip Mutuals (Protect Friends & Uncertain)", skipMutuals) { skipMutuals = it }
            SettingToggleRow("Automatic List Scrolling", autoScroll) { autoScroll = it }
            SettingToggleRow("Automatic CSV Export on Stop & Finish", autoExportCsv) { autoExportCsv = it }
            SettingToggleRow("Guided Step-by-Step Assist Mode", guidedMode) { guidedMode = it }
            SettingToggleRow("Require Confirmation Before Run", confirmBulk) { confirmBulk = it }
            SettingToggleRow("Enable Persistent & Alert Notifications", notificationsEnabled) { notificationsEnabled = it }
            SettingToggleRow("Critical Notifications Only", criticalOnly) { criticalOnly = it }
            SettingToggleRow("Reduced Motion (Disable Animations)", reducedMotion) { reducedMotion = it }
            SettingToggleRow("Show Ambient Background Orbs", ambientOrbs) { ambientOrbs = it }

            Text(
                text = "Theme & Background Variant:",
                color = MizoTextPrimary,
                fontWeight = FontWeight.SemiBold,
                fontSize = 12.sp
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                for (variant in ThemeVariant.entries) {
                    OutlinedButton(
                        onClick = { themeVariant = variant },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = variant.displayLabel.substringBefore(" "),
                            color = if (themeVariant == variant) MizoCyanHighlight else MizoTextSecondary,
                            fontSize = 10.5.sp
                        )
                    }
                }
            }

            Button(
                onClick = {
                    onSaveSettings(
                        settings.copy(
                            maxActionsPerSession = limitInput.toIntOrNull() ?: settings.maxActionsPerSession,
                            minDelayMs = minDelayInput.toLongOrNull() ?: settings.minDelayMs,
                            maxDelayMs = maxDelayInput.toLongOrNull() ?: settings.maxDelayMs,
                            skipMutuals = skipMutuals,
                            autoScroll = autoScroll,
                            autoExportCsv = autoExportCsv,
                            notificationsEnabled = notificationsEnabled,
                            criticalNotificationsOnly = criticalOnly,
                            reducedMotion = reducedMotion,
                            ambientOrbs = ambientOrbs,
                            confirmBulkActions = confirmBulk,
                            executionMode = if (guidedMode) ExecutionMode.GUIDED else ExecutionMode.AUTO,
                            themeVariant = themeVariant
                        )
                    )
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = MizoPurplePrimary)
            ) {
                Text("Save Settings", color = Color.White, fontWeight = FontWeight.Bold)
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onHideFloatingOverlay,
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Disable Overlay", color = MizoTextSecondary, fontSize = 11.sp)
                }
                OutlinedButton(
                    onClick = onDisableAccessibilityService,
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Disable A11y Service", color = MizoTextSecondary, fontSize = 11.sp)
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onRequestClearHistory,
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Clear History", color = MizoRoseDanger, fontSize = 11.sp)
                }
                OutlinedButton(
                    onClick = onRequestResetSettings,
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Reset Settings", color = MizoRoseDanger, fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
private fun SettingToggleRow(
    label: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            color = MizoTextPrimary,
            fontSize = 12.sp,
            modifier = Modifier.weight(1f)
        )
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
