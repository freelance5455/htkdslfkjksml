package com.mizoq.tiktoktoolkit.data.export

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.mizoq.tiktoktoolkit.config.MizoBrandConfig
import com.mizoq.tiktoktoolkit.data.local.ActionHistoryEntity
import com.mizoq.tiktoktoolkit.data.local.ExportRecordEntity
import com.mizoq.tiktoktoolkit.data.local.MizoDao
import com.mizoq.tiktoktoolkit.data.local.QueueItemEntity
import com.mizoq.tiktoktoolkit.domain.model.ExportRecord
import com.mizoq.tiktoktoolkit.domain.model.ExportStatus
import java.io.File
import java.io.FileOutputStream
import java.nio.charset.StandardCharsets
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Generates RFC 4180 compliant UTF-8 BOM CSV files and saves them to Android's Downloads
 * collection (via MediaStore.Downloads on Android 10+ or external Downloads/app storage fallback).
 * Never claims a successful export unless the file bytes were confirmed written and flushed.
 */
object CsvExportManager {

    private val CSV_HEADERS = listOf(
        "Username",
        "Display Name",
        "Requested Action",
        "Result",
        "Timestamp",
        "Session ID",
        "Skip Reason",
        "Error Details"
    )

    private val FORMULA_PREFIX_REGEX = Regex("^[=+\\-@]")
    private val HANDLE_PREFIX_REGEX = Regex("^@[a-zA-Z0-9_.]")

    /**
     * Escapes a single CSV cell per RFC 4180 and neutralizes spreadsheet formula injection.
     */
    fun escapeCsvCell(value: String?): String {
        if (value.isNullOrEmpty()) return ""
        var str = value
        if (FORMULA_PREFIX_REGEX.containsMatchIn(str) && !HANDLE_PREFIX_REGEX.containsMatchIn(str)) {
            str = "'$str"
        }
        val needsQuotes = str.contains(',') || str.contains('"') || str.contains('\r') || str.contains('\n')
        return if (needsQuotes) {
            "\"${str.replace("\"", "\"\"")}\""
        } else {
            str
        }
    }

    fun formatFilenameTimestamp(date: Date = Date()): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd-HH-mm-ss", Locale.US)
        return sdf.format(date)
    }

    fun formatIsoTimestamp(date: Date = Date()): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US)
        return sdf.format(date)
    }

    /**
     * Builds the complete UTF-8 BOM CSV content combining recorded session history and any
     * remaining pending/uncertain queue items (never labeling unverified items as 'success').
     */
    fun buildSessionCsvString(
        sessionId: String,
        requestedAction: String,
        historyItems: List<ActionHistoryEntity>,
        remainingQueueItems: List<QueueItemEntity> = emptyList()
    ): Pair<String, Int> {
        val sb = StringBuilder("\uFEFF")
        sb.append(CSV_HEADERS.joinToString(",") { escapeCsvCell(it) }).append("\r\n")

        val loggedUsers = HashSet<String>(historyItems.size + remainingQueueItems.size)
        var totalRows = 0

        for (item in historyItems) {
            val cleanUser = item.username.trim().removePrefix("@")
            loggedUsers.add(cleanUser.lowercase())
            val row = listOf(
                if (cleanUser.isNotEmpty()) "@$cleanUser" else "",
                item.displayName,
                item.requestedAction,
                item.result,
                item.timestampIso,
                item.sessionId,
                item.skipReason,
                item.errorDetails
            )
            sb.append(row.joinToString(",") { escapeCsvCell(it) }).append("\r\n")
            totalRows++
        }

        val nowIso = formatIsoTimestamp()
        for (qItem in remainingQueueItems) {
            val cleanUser = qItem.username.trim().removePrefix("@")
            if (cleanUser.isEmpty() || !loggedUsers.add(cleanUser.lowercase())) continue

            val accurateResult = when (qItem.status.lowercase()) {
                "uncertain" -> "uncertain"
                "skipped" -> "skipped"
                "failed" -> "failed"
                else -> "pending" // Never mark unexecuted/unverified items as success
            }
            val skipReason = if (accurateResult == "pending" && qItem.skipReason.isEmpty()) {
                "unprocessed_at_session_end"
            } else {
                qItem.skipReason
            }
            val row = listOf(
                "@$cleanUser",
                qItem.displayName,
                requestedAction,
                accurateResult,
                nowIso,
                sessionId,
                skipReason,
                qItem.errorDetails
            )
            sb.append(row.joinToString(",") { escapeCsvCell(it) }).append("\r\n")
            totalRows++
        }

        return sb.toString() to totalRows
    }

    /**
     * Finalizes and exports a session CSV to Android storage with duplicate-export prevention
     * and full local Room backup for one-tap retry if storage write fails.
     */
    suspend fun exportSessionToAndroidStorage(
        context: Context,
        dao: MizoDao,
        sessionId: String,
        requestedAction: String,
        triggerReason: String,
        forceRetry: Boolean = false,
        simulateWriteFailureForTest: Boolean = false
    ): ExportRecord {
        if (!forceRetry) {
            val existing = dao.getLatestExportForSession(sessionId)
            if (existing != null && (existing.status == ExportStatus.DOWNLOADED.wireValue ||
                    existing.status == ExportStatus.SAVED_APP_STORAGE.wireValue)
            ) {
                return ExportRecord(
                    id = existing.id,
                    sessionId = existing.sessionId,
                    filename = existing.filename,
                    filePathOrUri = existing.filePathOrUri,
                    recordCount = existing.recordCount,
                    timestampIso = existing.timestampIso,
                    triggerReason = existing.triggerReason,
                    status = ExportStatus.fromWireValue(existing.status),
                    errorDetails = existing.errorDetails
                )
            }
        }

        val history = dao.getHistoryForSession(sessionId)
        val queue = dao.getQueueItemsForSession(sessionId)
        val (csvContent, rowCount) = buildSessionCsvString(sessionId, requestedAction, history, queue)

        val now = Date()
        val filename = "${MizoBrandConfig.CSV_FILE_PREFIX}-${formatFilenameTimestamp(now)}.csv"
        val nowIso = formatIsoTimestamp(now)

        val writeOutcome = if (simulateWriteFailureForTest) {
            Triple(ExportStatus.FAILED, "", "Simulated storage failure — CSV preserved in Room database for Retry.")
        } else {
            writeCsvBytesToDevice(context, filename, csvContent)
        }

        val entity = ExportRecordEntity(
            id = "exp-${System.currentTimeMillis()}",
            sessionId = sessionId,
            filename = filename,
            filePathOrUri = writeOutcome.second,
            recordCount = rowCount,
            timestampIso = nowIso,
            triggerReason = triggerReason,
            status = writeOutcome.first.wireValue,
            errorDetails = writeOutcome.third,
            csvBackupContent = csvContent
        )
        dao.upsertExportRecord(entity)

        return ExportRecord(
            id = entity.id,
            sessionId = entity.sessionId,
            filename = entity.filename,
            filePathOrUri = entity.filePathOrUri,
            recordCount = entity.recordCount,
            timestampIso = entity.timestampIso,
            triggerReason = entity.triggerReason,
            status = writeOutcome.first,
            errorDetails = entity.errorDetails
        )
    }

    private fun writeCsvBytesToDevice(
        context: Context,
        filename: String,
        csvContent: String
    ): Triple<ExportStatus, String, String> {
        val bytes = csvContent.toByteArray(StandardCharsets.UTF_8)

        // Tier 1: Android 10+ (API 29+) Scoped Storage MediaStore.Downloads
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            try {
                val resolver = context.contentResolver
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, filename)
                    put(MediaStore.Downloads.MIME_TYPE, "text/csv")
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Mizo_q")
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }
                val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                if (uri != null) {
                    resolver.openOutputStream(uri)?.use { out ->
                        out.write(bytes)
                        out.flush()
                    }
                    values.clear()
                    values.put(MediaStore.Downloads.IS_PENDING, 0)
                    resolver.update(uri, values, null, null)
                    return Triple(ExportStatus.DOWNLOADED, uri.toString(), "")
                }
            } catch (_: Exception) {
                // Fall through to Tier 2 app-specific Downloads/Exports folder
            }
        }

        // Tier 2: App-Specific External Storage or Internal Exports folder
        return try {
            val baseDir = context.getExternalFilesDir("Exports")
                ?: File(context.filesDir, "exports")
            if (!baseDir.exists()) {
                baseDir.mkdirs()
            }
            val outFile = File(baseDir, filename)
            FileOutputStream(outFile).use { fos ->
                fos.write(bytes)
                fos.fd.sync()
            }
            if (outFile.exists() && outFile.length() > 0L) {
                Triple(ExportStatus.SAVED_APP_STORAGE, outFile.absolutePath, "")
            } else {
                Triple(ExportStatus.FAILED, "", "CSV file verification failed (0 bytes written).")
            }
        } catch (e: Exception) {
            Triple(
                ExportStatus.FAILED,
                "",
                e.message ?: "Unable to write CSV to storage. Preserved in local database for retry."
            )
        }
    }
}
