package com.mizoq.tiktoktoolkit.service.accessibility

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Build
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.mizoq.tiktoktoolkit.MizoApplication
import com.mizoq.tiktoktoolkit.domain.engine.EligibilityEvaluator
import com.mizoq.tiktoktoolkit.domain.engine.TikTokActionDriver
import com.mizoq.tiktoktoolkit.domain.model.ActionResult
import com.mizoq.tiktoktoolkit.domain.model.DiscoveredAccount
import com.mizoq.tiktoktoolkit.domain.model.ExecutionMode
import com.mizoq.tiktoktoolkit.domain.model.RelationshipState
import com.mizoq.tiktoktoolkit.domain.model.SecurityChallenge
import com.mizoq.tiktoktoolkit.domain.model.WorkflowMode
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Authorized Android AccessibilityService that inspects visible TikTok Following/Followers lists
 * and performs verified sequential actions only when the user explicitly starts a Mizo_q session.
 *
 * Privacy & Safety Guarantees:
 * - Strictly checks that the foreground package is an official TikTok app package.
 * - Never reads passwords, private messages, authentication tokens, or unrelated apps.
 * - Immediately pauses if a CAPTCHA or verification prompt appears.
 * - Can be disabled immediately from Settings or via requestDisableService().
 */
class MizoAccessibilityService : AccessibilityService(), TikTokActionDriver {

    companion object {
        @Volatile
        var instance: MizoAccessibilityService? = null
            private set

        private val _isConnectedFlow = MutableStateFlow(false)
        val isConnectedFlow: StateFlow<Boolean> = _isConnectedFlow.asStateFlow()

        private val _foregroundPackageFlow = MutableStateFlow<String?>(null)
        val foregroundPackageFlow: StateFlow<String?> = _foregroundPackageFlow.asStateFlow()
    }

    private var lastListFingerprint: String = ""
    private var cachedVisibleAccounts: List<DiscoveredAccount> = emptyList()

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        _isConnectedFlow.value = true
        (applicationContext as? MizoApplication)?.automationEngine?.actionDriver = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString() ?: rootInActiveWindow?.packageName?.toString()
        if (!pkg.isNullOrBlank()) {
            _foregroundPackageFlow.value = pkg
        }
    }

    override fun onInterrupt() {
        // Pause active automation safely on system accessibility interruption
        (applicationContext as? MizoApplication)?.automationEngine?.pauseSession(
            "Accessibility service interrupted by Android system."
        )
    }

    override fun onUnbind(intent: Intent?): Boolean {
        _isConnectedFlow.value = false
        instance = null
        val app = applicationContext as? MizoApplication
        if (app?.automationEngine?.actionDriver === this) {
            app.automationEngine.actionDriver = null
        }
        return super.onUnbind(intent)
    }

    fun requestDisableServiceSafely() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            disableSelf()
        }
    }

    override fun isTikTokInForeground(): Boolean {
        val pkg = getForegroundPackageName()
        return TikTokNodeScanner.isOfficialTikTokPackage(pkg)
    }

    override fun getForegroundPackageName(): String? {
        return rootInActiveWindow?.packageName?.toString() ?: _foregroundPackageFlow.value
    }

    override fun detectSecurityChallenge(): SecurityChallenge {
        val virtualRoot = TikTokNodeScanner.toVirtualTree(rootInActiveWindow)
        return TikTokNodeScanner.detectSecurityChallenge(virtualRoot)
    }

    override suspend fun openProfileListIfPossible(mode: WorkflowMode): Boolean {
        val root = rootInActiveWindow ?: return false
        if (!TikTokNodeScanner.isOfficialTikTokPackage(root.packageName?.toString())) return false

        val targetLabel = if (mode == WorkflowMode.FOLLOWERS) "Followers" else "Following"
        val matches = root.findAccessibilityNodeInfosByText(targetLabel) ?: emptyList()
        for (node in matches) {
            if (!node.isVisibleToUser) continue
            val clickableTarget = findClickableSelfOrParent(node)
            if (clickableTarget != null && clickableTarget.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                delay(550L)
                lastListFingerprint = ""
                return true
            }
        }
        return false
    }

    override suspend fun scanVisibleAccounts(mode: WorkflowMode): List<DiscoveredAccount> {
        val root = rootInActiveWindow ?: return emptyList()
        val virtualRoot = TikTokNodeScanner.toVirtualTree(root) ?: return emptyList()
        val scanned = TikTokNodeScanner.scanAccountRows(virtualRoot, mode)
        val fingerprint = TikTokNodeScanner.computeVisibleListFingerprint(scanned, mode)
        if (fingerprint == lastListFingerprint && cachedVisibleAccounts.isNotEmpty()) {
            return cachedVisibleAccounts
        }
        lastListFingerprint = fingerprint
        cachedVisibleAccounts = scanned
        return scanned
    }

    override suspend fun scrollAccountList(mode: WorkflowMode): Boolean {
        val root = rootInActiveWindow ?: return false
        val scrollable = findScrollableListNode(root) ?: return false
        val scrolled = scrollable.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)
        if (scrolled) {
            lastListFingerprint = ""
            delay(380L)
        }
        return scrolled
    }

    override suspend fun reacquireAccountInTree(
        username: String,
        mode: WorkflowMode
    ): DiscoveredAccount? {
        val targetKey = username.trim().removePrefix("@").lowercase()
        val accounts = scanVisibleAccounts(mode)
        return accounts.firstOrNull { it.normalizedUsername == targetKey }
    }

    override suspend fun performAccountAction(
        account: DiscoveredAccount,
        mode: WorkflowMode,
        skipMutuals: Boolean
    ): Pair<ActionResult, String> {
        val app = applicationContext as? MizoApplication
        val settings = app?.settingsRepository?.getSettings()

        // Guided Mode Assist: never auto-clicks if user selected Guided Mode
        if (settings?.executionMode == ExecutionMode.GUIDED) {
            for (attempt in 1..25) {
                delay(300L)
                val updated = reacquireAccountInTree(account.username, mode)
                if (updated == null ||
                    updated.relationshipState == RelationshipState.NOT_FOLLOWING ||
                    updated.relationshipState == RelationshipState.REMOVED
                ) {
                    return ActionResult.SUCCESS to ""
                }
            }
            return ActionResult.FAILED to "Guided mode timed out waiting for manual tap on @${account.username}."
        }

        val root = rootInActiveWindow
            ?: return ActionResult.FAILED to "TikTok window is no longer active."

        val reacquired = reacquireAccountInTree(account.username, mode)
        val eligibility = EligibilityEvaluator.verifyLiveTargetBeforeAction(
            expectedUsername = account.username,
            reacquiredAccount = reacquired,
            skipMutuals = skipMutuals
        )
        if (!eligibility.eligible) {
            return ActionResult.SKIPPED to (eligibility.skipReason ?: "skipped_revalidation")
        }

        val rowNode = findRowAccessibilityNodeForUsername(root, account.username)
            ?: return ActionResult.SKIPPED to "account_row_not_confidently_reacquired"

        if (mode == WorkflowMode.FOLLOWING) {
            val actionButton = findOwnedActionButtonInRow(rowNode, listOf("Following", "Requested"))
                ?: return ActionResult.SKIPPED to "action_button_ownership_unverified"

            if (!actionButton.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                return ActionResult.FAILED to "Android Accessibility click was rejected on @${account.username}."
            }

            delay(180L)
            clickConfirmationDialogIfPresent(listOf("Unfollow", "Confirm"))

            // Post-action verification loop
            for (i in 1..10) {
                delay(160L)
                val security = detectSecurityChallenge()
                if (security.detected) {
                    return ActionResult.FAILED to (security.message ?: "Security challenge detected")
                }

                val postCheck = reacquireAccountInTree(account.username, mode)
                if (postCheck != null && postCheck.relationshipState == RelationshipState.NOT_FOLLOWING) {
                    lastListFingerprint = ""
                    return ActionResult.SUCCESS to ""
                }
            }
            return ActionResult.UNCERTAIN to "Clicked Following on @${account.username}, but button state did not confirm 'Follow' yet."
        } else {
            // Followers workflow: click "..." more options button owned by the follower row
            val moreBtn = findOwnedMoreButtonInRow(rowNode)
                ?: return ActionResult.FAILED to "Follower options ('...') button is not exposed in TikTok's accessibility tree for @${account.username}. Switch to Guided Mode."

            if (!moreBtn.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                return ActionResult.FAILED to "Could not open follower menu for @${account.username}."
            }

            delay(250L)
            val removeClicked = clickConfirmationDialogIfPresent(
                listOf("Remove this follower", "Remove follower", "Remove")
            )
            if (!removeClicked) {
                return ActionResult.FAILED to "'Remove this follower' menu option was not found for @${account.username}."
            }

            delay(200L)
            clickConfirmationDialogIfPresent(listOf("Remove", "Confirm"))

            for (i in 1..10) {
                delay(160L)
                val postCheck = reacquireAccountInTree(account.username, mode)
                if (postCheck == null || postCheck.relationshipState == RelationshipState.REMOVED) {
                    lastListFingerprint = ""
                    return ActionResult.SUCCESS to ""
                }
            }
            return ActionResult.UNCERTAIN to "Follower removal state for @${account.username} could not be confirmed."
        }
    }

    private fun findRowAccessibilityNodeForUsername(
        root: AccessibilityNodeInfo,
        username: String
    ): AccessibilityNodeInfo? {
        val cleanHandle = username.trim().removePrefix("@")
        val candidates = mutableListOf<AccessibilityNodeInfo>()
        candidates.addAll(root.findAccessibilityNodeInfosByText("@$cleanHandle") ?: emptyList())
        candidates.addAll(root.findAccessibilityNodeInfosByText(cleanHandle) ?: emptyList())

        for (node in candidates) {
            if (!node.isVisibleToUser) continue
            var parent = node.parent
            var depth = 0
            while (parent != null && depth < 4) {
                if (parent.childCount >= 2) {
                    return parent
                }
                parent = parent.parent
                depth++
            }
        }
        return null
    }

    private fun findOwnedActionButtonInRow(
        rowNode: AccessibilityNodeInfo,
        labels: List<String>
    ): AccessibilityNodeInfo? {
        for (label in labels) {
            val matches = rowNode.findAccessibilityNodeInfosByText(label) ?: continue
            for (m in matches) {
                if (!m.isVisibleToUser) continue
                val clickable = findClickableSelfOrParent(m, stopBoundary = rowNode)
                if (clickable != null) return clickable
            }
        }
        return null
    }

    private fun findOwnedMoreButtonInRow(rowNode: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        for (i in 0 until rowNode.childCount) {
            val child = rowNode.getChild(i) ?: continue
            val desc = (child.contentDescription ?: child.text ?: "").toString().lowercase()
            if (child.isClickable && (desc.contains("more") || desc == "..." || desc == "⋯")) {
                return child
            }
        }
        return null
    }

    private fun clickConfirmationDialogIfPresent(labels: List<String>): Boolean {
        val root = rootInActiveWindow ?: return false
        for (label in labels) {
            val matches = root.findAccessibilityNodeInfosByText(label) ?: continue
            for (node in matches) {
                if (!node.isVisibleToUser) continue
                val clickable = findClickableSelfOrParent(node)
                if (clickable != null && clickable.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                    return true
                }
            }
        }
        return false
    }

    private fun findClickableSelfOrParent(
        node: AccessibilityNodeInfo?,
        stopBoundary: AccessibilityNodeInfo? = null
    ): AccessibilityNodeInfo? {
        var cur = node
        var depth = 0
        while (cur != null && depth < 5) {
            if (cur.isClickable) return cur
            if (stopBoundary != null && cur == stopBoundary) break
            cur = cur.parent
            depth++
        }
        return null
    }

    private fun findScrollableListNode(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (node == null || !node.isVisibleToUser) return null
        if (node.isScrollable) return node
        for (i in 0 until node.childCount) {
            val found = findScrollableListNode(node.getChild(i))
            if (found != null) return found
        }
        return null
    }
}
