package com.mizoq.tiktoktoolkit

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mizoq.tiktoktoolkit.config.MizoBrandConfig
import com.mizoq.tiktoktoolkit.domain.model.WorkflowMode
import com.mizoq.tiktoktoolkit.service.accessibility.MizoAccessibilityService
import com.mizoq.tiktoktoolkit.service.overlay.MizoOverlayService
import com.mizoq.tiktoktoolkit.ui.MainTab
import com.mizoq.tiktoktoolkit.ui.MainViewModel
import com.mizoq.tiktoktoolkit.ui.components.AccessibilityPermissionExplanationDialog
import com.mizoq.tiktoktoolkit.ui.components.ConfirmDestructiveActionDialog
import com.mizoq.tiktoktoolkit.ui.components.ConfirmStartSessionDialog
import com.mizoq.tiktoktoolkit.ui.components.MizoBackground
import com.mizoq.tiktoktoolkit.ui.components.MizoHeader
import com.mizoq.tiktoktoolkit.ui.components.OverlayPermissionExplanationDialog
import com.mizoq.tiktoktoolkit.ui.screens.AccountListScreen
import com.mizoq.tiktoktoolkit.ui.screens.DashboardScreen
import com.mizoq.tiktoktoolkit.ui.screens.HistoryScreen
import com.mizoq.tiktoktoolkit.ui.screens.SettingsScreen
import com.mizoq.tiktoktoolkit.ui.theme.MizoCyanHighlight
import com.mizoq.tiktoktoolkit.ui.theme.MizoMidnightSurface
import com.mizoq.tiktoktoolkit.ui.theme.MizoPurplePrimary
import com.mizoq.tiktoktoolkit.ui.theme.MizoTextPrimary
import com.mizoq.tiktoktoolkit.ui.theme.MizoTextSecondary
import com.mizoq.tiktoktoolkit.ui.theme.MizoTheme

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            val settings by viewModel.settingsFlow.collectAsState()
            val sessionState by viewModel.sessionStateFlow.collectAsState()
            val activeTab by viewModel.activeTab.collectAsState()
            val isAccessibilityConnected by viewModel.isAccessibilityConnectedFlow.collectAsState()
            val isOverlayVisible by viewModel.isOverlayVisibleFlow.collectAsState()
            val followingAccounts by viewModel.discoveredFollowingFlow.collectAsState()
            val followersAccounts by viewModel.discoveredFollowersFlow.collectAsState()
            val selectedFollowing by viewModel.selectedFollowingFlow.collectAsState()
            val selectedFollowers by viewModel.selectedFollowersFlow.collectAsState()
            val recentHistory by viewModel.recentHistoryFlow.collectAsState()
            val exportRecords by viewModel.exportHistoryFlow.collectAsState()
            val sessionAnalytics by viewModel.sessionAnalyticsFlow.collectAsState()
            val feedbackMessage by viewModel.feedbackMessage.collectAsState()

            var showOverlayExplanation by remember { mutableStateOf(false) }
            var showAccessibilityExplanation by remember { mutableStateOf(false) }
            var pendingStartMode by remember { mutableStateOf<Pair<WorkflowMode, Boolean>?>(null) }
            var showConfirmClearHistory by remember { mutableStateOf(false) }
            var showConfirmResetSettings by remember { mutableStateOf(false) }

            MizoTheme(
                themeVariant = settings.themeVariant,
                reducedMotion = settings.reducedMotion
            ) {
                MizoBackground(ambientOrbsEnabled = settings.ambientOrbs) {
                    Scaffold(
                        containerColor = Color.Transparent,
                        topBar = {
                            Column {
                                MizoHeader(
                                    isAccessibilityEnabled = isAccessibilityConnected,
                                    isOverlayGranted = viewModel.canDrawOverlays(),
                                    onOpenSettingsTab = { viewModel.selectTab(MainTab.SETTINGS) }
                                )
                                // 5-Tab Touch-Friendly Navigation Bar
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(MizoMidnightSurface.copy(alpha = 0.88f))
                                        .padding(horizontal = 8.dp, vertical = 4.dp),
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    for (tab in MainTab.entries) {
                                        val selected = activeTab == tab
                                        Button(
                                            onClick = { viewModel.selectTab(tab) },
                                            modifier = Modifier.weight(1f),
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = if (selected) MizoPurplePrimary else Color.Transparent
                                            )
                                        ) {
                                            Text(
                                                text = tab.title,
                                                color = if (selected) Color.White else MizoTextSecondary,
                                                fontSize = 10.sp,
                                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                                                maxLines = 1
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    ) { innerPadding ->
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(innerPadding)
                        ) {
                            // Feedback / Security / Recovery Banner
                            val bannerText = sessionState.securityWarning
                                ?: sessionState.interruptionReason
                                ?: sessionState.completionReport
                                ?: feedbackMessage

                            if (!bannerText.isNullOrBlank()) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 12.dp, vertical = 4.dp)
                                        .background(MizoMidnightSurface, RoundedCornerShape(10.dp))
                                        .padding(10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = bannerText,
                                        color = MizoTextPrimary,
                                        fontSize = 11.5.sp,
                                        modifier = Modifier.weight(1f)
                                    )
                                    TextButton(onClick = { viewModel.setFeedbackMessage(null) }) {
                                        Text("Dismiss", color = MizoCyanHighlight, fontSize = 11.sp)
                                    }
                                }
                            }

                            when (activeTab) {
                                MainTab.DASHBOARD -> DashboardScreen(
                                    sessionState = sessionState,
                                    settings = settings,
                                    isOverlayGranted = viewModel.canDrawOverlays(),
                                    isOverlayVisible = isOverlayVisible,
                                    isAccessibilityConnected = isAccessibilityConnected,
                                    onRequestOverlayPermission = { showOverlayExplanation = true },
                                    onRequestAccessibilityPermission = { showAccessibilityExplanation = true },
                                    onToggleFloatingOverlay = { show -> toggleOverlayService(show) },
                                    onLaunchOfficialTikTok = { launchOfficialTikTokApp() },
                                    onStartLiveSession = { mode ->
                                        if (settings.confirmBulkActions || mode == WorkflowMode.FOLLOWERS) {
                                            pendingStartMode = mode to false
                                        } else {
                                            viewModel.engine.startSession(mode, isSimulated = false)
                                        }
                                    },
                                    onStartSimulatedSession = { limit ->
                                        if (settings.confirmBulkActions) {
                                            pendingStartMode = sessionState.workflowMode to true
                                        } else {
                                            viewModel.engine.startSession(
                                                mode = sessionState.workflowMode,
                                                isSimulated = true,
                                                simulatedTotalAccounts = limit * 2
                                            )
                                        }
                                    },
                                    onPauseSession = { viewModel.engine.pauseSession() },
                                    onResumeSession = { viewModel.engine.resumeSession() },
                                    onStopAndExportCsv = {
                                        viewModel.engine.stopSessionAndExport { rec ->
                                            viewModel.setFeedbackMessage("Exported CSV: ${rec.filename} (${rec.recordCount} rows)")
                                        }
                                    },
                                    onExportCsvManual = { viewModel.triggerManualOrRetryCsvExport(forceRetry = false) },
                                    onToggleSkipMutuals = { checked ->
                                        viewModel.updateSettings(settings.copy(skipMutuals = checked))
                                    },
                                    onSelectLimitPreset = { preset ->
                                        viewModel.updateSettings(settings.copy(maxActionsPerSession = preset))
                                    }
                                )

                                MainTab.FOLLOWING -> AccountListScreen(
                                    mode = WorkflowMode.FOLLOWING,
                                    accounts = followingAccounts,
                                    selectedSet = selectedFollowing,
                                    skipMutuals = settings.skipMutuals,
                                    onScanTikTokList = { viewModel.scanVisibleTikTokList(WorkflowMode.FOLLOWING) },
                                    onLoadSamplePreview = { viewModel.engine.loadSamplePreviewAccounts(WorkflowMode.FOLLOWING) },
                                    onToggleSkipMutuals = { viewModel.updateSettings(settings.copy(skipMutuals = it)) },
                                    onSelectAll = { viewModel.engine.selectAllEligible(WorkflowMode.FOLLOWING) },
                                    onDeselectAll = { viewModel.engine.deselectAll(WorkflowMode.FOLLOWING) },
                                    onToggleAccountSelection = { user, sel ->
                                        viewModel.engine.toggleAccountSelection(WorkflowMode.FOLLOWING, user, sel)
                                    },
                                    onStartSessionForMode = {
                                        pendingStartMode = WorkflowMode.FOLLOWING to false
                                    }
                                )

                                MainTab.FOLLOWERS -> AccountListScreen(
                                    mode = WorkflowMode.FOLLOWERS,
                                    accounts = followersAccounts,
                                    selectedSet = selectedFollowers,
                                    skipMutuals = settings.skipMutuals,
                                    onScanTikTokList = { viewModel.scanVisibleTikTokList(WorkflowMode.FOLLOWERS) },
                                    onLoadSamplePreview = { viewModel.engine.loadSamplePreviewAccounts(WorkflowMode.FOLLOWERS) },
                                    onToggleSkipMutuals = { viewModel.updateSettings(settings.copy(skipMutuals = it)) },
                                    onSelectAll = { viewModel.engine.selectAllEligible(WorkflowMode.FOLLOWERS) },
                                    onDeselectAll = { viewModel.engine.deselectAll(WorkflowMode.FOLLOWERS) },
                                    onToggleAccountSelection = { user, sel ->
                                        viewModel.engine.toggleAccountSelection(WorkflowMode.FOLLOWERS, user, sel)
                                    },
                                    onStartSessionForMode = {
                                        pendingStartMode = WorkflowMode.FOLLOWERS to false
                                    }
                                )

                                MainTab.HISTORY -> HistoryScreen(
                                    sessionAnalytics = sessionAnalytics,
                                    exportRecords = exportRecords,
                                    historyItems = recentHistory,
                                    onRetryOrManualExport = { viewModel.triggerManualOrRetryCsvExport(forceRetry = true) },
                                    onRequestClearHistory = { showConfirmClearHistory = true }
                                )

                                MainTab.SETTINGS -> SettingsScreen(
                                    settings = settings,
                                    onSaveSettings = { viewModel.updateSettings(it) },
                                    onRequestResetSettings = { showConfirmResetSettings = true },
                                    onRequestClearHistory = { showConfirmClearHistory = true },
                                    onDisableAccessibilityService = {
                                        MizoAccessibilityService.instance?.requestDisableServiceSafely()
                                            ?: openAccessibilitySettings()
                                    },
                                    onHideFloatingOverlay = { toggleOverlayService(false) }
                                )
                            }
                        }
                    }

                    if (showOverlayExplanation) {
                        OverlayPermissionExplanationDialog(
                            onConfirmOpenSettings = {
                                showOverlayExplanation = false
                                openOverlayPermissionSettings()
                            },
                            onDismiss = { showOverlayExplanation = false }
                        )
                    }

                    if (showAccessibilityExplanation) {
                        AccessibilityPermissionExplanationDialog(
                            onConfirmOpenSettings = {
                                showAccessibilityExplanation = false
                                openAccessibilitySettings()
                            },
                            onDismiss = { showAccessibilityExplanation = false }
                        )
                    }

                    pendingStartMode?.let { (mode, isSimulated) ->
                        ConfirmStartSessionDialog(
                            mode = mode,
                            settings = settings,
                            isSimulated = isSimulated,
                            onConfirmStart = {
                                pendingStartMode = null
                                viewModel.engine.startSession(
                                    mode = mode,
                                    isSimulated = isSimulated,
                                    simulatedTotalAccounts = settings.maxActionsPerSession * 2
                                )
                            },
                            onDismiss = { pendingStartMode = null }
                        )
                    }

                    if (showConfirmClearHistory) {
                        ConfirmDestructiveActionDialog(
                            title = "Clear All Action & Session History?",
                            message = "This will permanently delete all recorded session analytics and local action history on this device.",
                            confirmButtonLabel = "Clear All History",
                            onConfirm = {
                                showConfirmClearHistory = false
                                viewModel.clearAllHistory()
                            },
                            onDismiss = { showConfirmClearHistory = false }
                        )
                    }

                    if (showConfirmResetSettings) {
                        ConfirmDestructiveActionDialog(
                            title = "Reset Mizo_q Settings to Default?",
                            message = "This will restore session limits (100), pacing delays (2000–4000 ms), Skip Mutuals, and Midnight Nebula theme to their V6.0 defaults.",
                            confirmButtonLabel = "Reset Settings",
                            onConfirm = {
                                showConfirmResetSettings = false
                                viewModel.resetSettingsToDefault()
                            },
                            onDismiss = { showConfirmResetSettings = false }
                        )
                    }
                }
            }
        }
    }

    private fun openOverlayPermissionSettings() {
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:$packageName")
        )
        startActivity(intent)
    }

    private fun openAccessibilitySettings() {
        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
        startActivity(intent)
    }

    private fun toggleOverlayService(show: Boolean) {
        if (show && !Settings.canDrawOverlays(this)) {
            openOverlayPermissionSettings()
            return
        }
        val intent = Intent(this, MizoOverlayService::class.java).apply {
            action = if (show) MizoOverlayService.ACTION_SHOW_OVERLAY else MizoOverlayService.ACTION_HIDE_OVERLAY
        }
        startService(intent)
    }

    private fun launchOfficialTikTokApp() {
        for (pkg in MizoBrandConfig.OFFICIAL_TIKTOK_PACKAGES) {
            val launchIntent = packageManager.getLaunchIntentForPackage(pkg)
            if (launchIntent != null) {
                startActivity(launchIntent)
                return
            }
        }
        viewModel.setFeedbackMessage("Official TikTok Android app was not found on this device. Install TikTok from Google Play.")
    }
}
