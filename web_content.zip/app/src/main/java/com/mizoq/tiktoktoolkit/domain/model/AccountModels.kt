package com.mizoq.tiktoktoolkit.domain.model

/**
 * Verified mutual relationship classification from visible TikTok UI signals.
 */
enum class MutualStatus(val wireValue: String, val displayLabel: String) {
    MUTUAL("mutual", "Mutual Friend"),
    NON_MUTUAL("non_mutual", "Non-Mutual"),
    UNKNOWN("unknown", "Status Uncertain");

    companion object {
        fun fromWireValue(value: String?): MutualStatus =
            entries.firstOrNull { it.wireValue.equals(value, ignoreCase = true) } ?: UNKNOWN
    }
}

/**
 * Current visible relationship state of an account row on TikTok.
 */
enum class RelationshipState(val wireValue: String) {
    FOLLOWING("following"),
    FRIENDS("friends"),
    FOLLOWER_ONLY("follower_only"),
    NOT_FOLLOWING("not_following"),
    REMOVED("removed"),
    UNKNOWN("unknown");

    companion object {
        fun fromWireValue(value: String?): RelationshipState =
            entries.firstOrNull { it.wireValue.equals(value, ignoreCase = true) } ?: UNKNOWN
    }
}

/**
 * Supported workflow modes (Following unfollow vs Followers management).
 */
enum class WorkflowMode(val wireValue: String, val actionName: String, val displayTitle: String) {
    FOLLOWING("following", "unfollow", "Bulk Unfollow (Following)"),
    FOLLOWERS("followers", "remove_follower", "Remove Followers");

    companion object {
        fun fromWireValue(value: String?): WorkflowMode =
            if (value.equals("followers", ignoreCase = true)) FOLLOWERS else FOLLOWING
    }
}

/**
 * Outcome of an individual account action or queue item.
 */
enum class ActionResult(val wireValue: String, val badgeLabel: String) {
    PENDING("pending", "PENDING"),
    SUCCESS("success", "SUCCESS"),
    SKIPPED("skipped", "SKIPPED"),
    FAILED("failed", "FAILED"),
    UNCERTAIN("uncertain", "UNCERTAIN");

    companion object {
        fun fromWireValue(value: String?): ActionResult =
            entries.firstOrNull { it.wireValue.equals(value, ignoreCase = true) } ?: FAILED
    }
}

/**
 * Represents a TikTok account row discovered from the visible AccessibilityNodeInfo tree
 * or loaded into sample preview mode for safe testing.
 */
data class DiscoveredAccount(
    val username: String,
    val displayName: String,
    val mutualStatus: MutualStatus,
    val relationshipState: RelationshipState,
    val actionButtonText: String,
    val hasMoreOptionsButton: Boolean = false,
    val followsYouIndicator: Boolean = false,
    val rowBoundsSignature: String = "",
    val buttonOwnershipVerified: Boolean = true
) {
    val normalizedUsername: String
        get() = username.trim().removePrefix("@").lowercase()
}

/**
 * Result of checking whether an account is eligible to be queued or processed.
 */
data class EligibilityEvaluation(
    val eligible: Boolean,
    val skipReason: String? = null
)
