package com.mizoq.tiktoktoolkit.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import com.mizoq.tiktoktoolkit.domain.model.ThemeVariant

val MizoNavyBase = Color(0xFF0B1021)
val MizoMidnightSurface = Color(0xFF131C38)
val MizoMidnightElevated = Color(0xFF1A254A)
val MizoPurplePrimary = Color(0xFF7C3AED)
val MizoLavenderAccent = Color(0xFFC4B5FD)
val MizoCyanHighlight = Color(0xFF22D3EE)
val MizoMintSuccess = Color(0xFF10B981)
val MizoAmberWarning = Color(0xFFF59E0B)
val MizoRoseDanger = Color(0xFFEF4444)
val MizoTextPrimary = Color(0xFFF8FAFC)
val MizoTextSecondary = Color(0xFFCBD5E1)
val MizoTextMuted = Color(0xFF94A3B8)

val LocalReducedMotion = staticCompositionLocalOf { false }

private val MidnightNebulaScheme = darkColorScheme(
    primary = MizoPurplePrimary,
    onPrimary = Color.White,
    secondary = MizoCyanHighlight,
    onSecondary = MizoNavyBase,
    tertiary = MizoLavenderAccent,
    background = MizoNavyBase,
    onBackground = MizoTextPrimary,
    surface = MizoMidnightSurface,
    onSurface = MizoTextPrimary,
    surfaceVariant = MizoMidnightElevated,
    onSurfaceVariant = MizoTextSecondary,
    error = MizoRoseDanger,
    onError = Color.White
)

private val CyberIndigoScheme = MidnightNebulaScheme.copy(
    primary = Color(0xFF6366F1),
    secondary = Color(0xFF38BDF8),
    background = Color(0xFF090D1F),
    surface = Color(0xFF17153A)
)

private val ObsidianGlassScheme = MidnightNebulaScheme.copy(
    primary = Color(0xFF8B5CF6),
    secondary = Color(0xFF2DD4BF),
    background = Color(0xFF070A14),
    surface = Color(0xFF0F1424)
)

@Composable
fun MizoTheme(
    themeVariant: ThemeVariant = ThemeVariant.MIDNIGHT_NEBULA,
    reducedMotion: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = when (themeVariant) {
        ThemeVariant.MIDNIGHT_NEBULA -> MidnightNebulaScheme
        ThemeVariant.CYBER_INDIGO -> CyberIndigoScheme
        ThemeVariant.OBSIDIAN_GLASS -> ObsidianGlassScheme
    }

    CompositionLocalProvider(LocalReducedMotion provides reducedMotion) {
        MaterialTheme(
            colorScheme = colorScheme,
            content = content
        )
    }
}
