package com.mizoq.tiktoktoolkit

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.mizoq.tiktoktoolkit.config.MizoBrandConfig
import com.mizoq.tiktoktoolkit.data.local.MizoDatabase
import com.mizoq.tiktoktoolkit.data.preferences.SettingsRepository
import com.mizoq.tiktoktoolkit.domain.engine.MizoAutomationEngine

/**
 * Application singleton initializing Room persistence, SettingsRepository,
 * MizoAutomationEngine, and Android O+ notification channels.
 */
class MizoApplication : Application() {

    lateinit var database: MizoDatabase
        private set

    lateinit var settingsRepository: SettingsRepository
        private set

    lateinit var automationEngine: MizoAutomationEngine
        private set

    override fun onCreate() {
        super.onCreate()
        database = MizoDatabase.getInstance(this)
        settingsRepository = SettingsRepository(this)
        automationEngine = MizoAutomationEngine(
            appContext = this,
            dao = database.mizoDao(),
            settingsRepo = settingsRepository
        )
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java) ?: return

            val overlayChannel = NotificationChannel(
                MizoBrandConfig.OVERLAY_NOTIFICATION_CHANNEL_ID,
                getString(R.string.overlay_notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.overlay_notification_channel_desc)
                setShowBadge(false)
            }

            val alertsChannel = NotificationChannel(
                MizoBrandConfig.ALERTS_NOTIFICATION_CHANNEL_ID,
                getString(R.string.alerts_notification_channel_name),
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = getString(R.string.alerts_notification_channel_desc)
            }

            nm.createNotificationChannel(overlayChannel)
            nm.createNotificationChannel(alertsChannel)
        }
    }
}
