package com.mizoq.tiktoktoolkit.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "queue_items",
    indices = [
        Index(value = ["sessionId", "normalizedUsername"], unique = true),
        Index(value = ["sessionId", "status"])
    ]
)
data class QueueItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val sessionId: String,
    val username: String,
    val normalizedUsername: String,
    val displayName: String,
    val mutualStatus: String,
    val status: String, // "pending" | "success" | "skipped" | "failed" | "uncertain"
    val skipReason: String = "",
    val errorDetails: String = "",
    val createdAtEpochMs: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "action_history",
    indices = [
        Index(value = ["dedupeKey"], unique = true),
        Index(value = ["sessionId"]),
        Index(value = ["result"])
    ]
)
data class ActionHistoryEntity(
    @PrimaryKey val id: String,
    val dedupeKey: String,
    val sessionId: String,
    val username: String,
    val displayName: String,
    val requestedAction: String, // "unfollow" | "remove_follower"
    val result: String,          // "success" | "skipped" | "failed" | "uncertain" | "pending"
    val timestampIso: String,
    val skipReason: String = "",
    val errorDetails: String = "",
    val createdAtEpochMs: Long = System.currentTimeMillis()
)

@Entity(tableName = "session_summaries")
data class SessionSummaryEntity(
    @PrimaryKey val sessionId: String,
    val startTimeIso: String,
    val endTimeIso: String,
    val durationFormatted: String,
    val requestedAction: String,
    val status: String,
    val isIncomplete: Boolean,
    val scannedCount: Int,
    val exportStatus: String = "not_exported",
    val exportFilename: String? = null,
    val updatedAtEpochMs: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "export_records",
    indices = [Index(value = ["sessionId"])]
)
data class ExportRecordEntity(
    @PrimaryKey val id: String,
    val sessionId: String,
    val filename: String,
    val filePathOrUri: String,
    val recordCount: Int,
    val timestampIso: String,
    val triggerReason: String,
    val status: String, // "downloaded" | "saved_app_storage" | "failed"
    val errorDetails: String = "",
    val csvBackupContent: String = "",
    val createdAtEpochMs: Long = System.currentTimeMillis()
)
