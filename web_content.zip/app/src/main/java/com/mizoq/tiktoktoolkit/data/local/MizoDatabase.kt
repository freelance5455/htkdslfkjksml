package com.mizoq.tiktoktoolkit.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        QueueItemEntity::class,
        ActionHistoryEntity::class,
        SessionSummaryEntity::class,
        ExportRecordEntity::class
    ],
    version = 6,
    exportSchema = false
)
abstract class MizoDatabase : RoomDatabase() {
    abstract fun mizoDao(): MizoDao

    companion object {
        @Volatile
        private var INSTANCE: MizoDatabase? = null

        fun getInstance(context: Context): MizoDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    MizoDatabase::class.java,
                    "mizo_q_tiktok_toolkit_v6.db"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
