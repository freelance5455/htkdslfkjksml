package com.mizoq.tiktoktoolkit.ui

import android.app.Application
import android.provider.Settings
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mizoq.tiktoktoolkit.MizoApplication
import com.mizoq.tiktoktoolkit.data.export.CsvExportManager
import com.mizoq.tiktoktoolkit.data.local.ActionHistoryEntity
import com.mizoq.tiktoktoolkit.data.local.ExportRecordEntity
import com.mizoq.tiktoktoolkit.domain.model.DiscoveredAccount
import com.mizoq.tiktoktoolkit.domain.model.SessionAnalyticsSummary
import com.mizoq.tiktoktoolkit.domain.model.SessionSettings
import com.mizoq.tiktoktoolkit.domain.model.SessionState
import com.mizoq.tiktoktoolkit.domain.model.WorkflowMode
import com.mizoq.tiktoktoolkit.service.accessibility.MizoAccessibilityService
import com.mizoq.tiktoktoolkit.service.overlay.MizoOverlayService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class MainTab(val title: String) {
    DASHBOARD("Dashboard"),
    FOLLOWING("Following"),
    FOLLOWERS("Followers"),
    HISTORY("History"),
    SETTINGS("Settings")
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val mizoApp = application as MizoApplication
    private val dao = mizoApp.database.mizoDao()
    val settingsRepo = mizoApp.settingsRepository
    val engine = mizoApp.automationEngine

    val settingsFlow: StateFlow<SessionSettings> = settingsRepo.settingsFlow
    val sessionStateFlow: StateFlow<SessionState> = engine.sessionState
    val discoveredFollowingFlow: StateFlow<List<DiscoveredAccount>> = engine.discoveredFollowing
    val discoveredFollowersFlow: StateFlow<List<DiscoveredAccount>> = engine.discoveredFollowers
    val selectedFollowingFlow: StateFlow<Set<String>> = engine.selectedFollowing
    val selectedFollowersFlow: StateFlow<Set<String>> = engine.selectedFollowers

    val isAccessibilityConnectedFlow: StateFlow<Boolean> = MizoAccessibilityService.isConnectedFlow
    val isOverlayVisibleFlow: StateFlow<Boolean> = MizoOverlayService.isOverlayVisibleFlow

    val recentHistoryFlow: StateFlow<List<ActionHistoryEntity>> =
        dao.observeRecentHistory(limit = 500)
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val exportHistoryFlow: StateFlow<List<ExportRecordEntity>> =
        dao.observeExportRecords()
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    private val _sessionAnalyticsFlow = MutableStateFlow<List<SessionAnalyticsSummary>>(emptyList())
    val sessionAnalyticsFlow: StateFlow<List<SessionAnalyticsSummary>> = _sessionAnalyticsFlow.asStateFlow()

    private val _activeTab = MutableStateFlow(MainTab.DASHBOARD)
    val activeTab: StateFlow<MainTab> = _activeTab.asStateFlow()

    private val _feedbackMessage = MutableStateFlow<String?>(null)
    val feedbackMessage: StateFlow<String?> = _feedbackMessage.asStateFlow()

    init {
        refreshAnalytics()
    }

    fun selectTab(tab: MainTab) {
        _activeTab.value = tab
        if (tab == MainTab.HISTORY) {
            refreshAnalytics()
        }
    }

    fun setFeedbackMessage(message: String?) {
        _feedbackMessage.value = message
    }

    fun canDrawOverlays(): Boolean {
        return Settings.canDrawOverlays(getApplication())
    }

    fun updateSettings(newSettings: SessionSettings) {
        val (_, errors) = settingsRepo.saveSettings(newSettings)
        if (errors.isEmpty()) {
            _feedbackMessage.value = "Settings saved (Limit: ${newSettings.maxActionsPerSession} actions)."
        } else {
            _feedbackMessage.value = errors.joinToString(" ")
        }
    }

    fun resetSettingsToDefault() {
        settingsRepo.resetSettingsToDefaults()
        _feedbackMessage.value = "Settings restored to V6.0 defaults."
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            dao.clearAllHistory()
            dao.clearSessionSummaries()
            _sessionAnalyticsFlow.value = emptyList()
            _feedbackMessage.value = "Local session and action history cleared."
        }
    }

    fun refreshAnalytics() {
        viewModelScope.launch {
            _sessionAnalyticsFlow.value = engine.computeRealSessionAnalytics()
        }
    }

    fun triggerManualOrRetryCsvExport(forceRetry: Boolean = true) {
        viewModelScope.launch {
            val cur = engine.sessionState.value
            val sid = cur.sessionId ?: "manual-${System.currentTimeMillis()}"
            val record = CsvExportManager.exportSessionToAndroidStorage(
                context = getApplication(),
                dao = dao,
                sessionId = sid,
                requestedAction = cur.workflowMode.actionName,
                triggerReason = if (forceRetry) "manual_retry" else "manual_export",
                forceRetry = forceRetry
            )
            _feedbackMessage.value = "${record.status.displayLabel}: ${record.filename} (${record.recordCount} rows)"
            refreshAnalytics()
        }
    }

    fun scanVisibleTikTokList(mode: WorkflowMode) {
        viewModelScope.launch {
            val driver = engine.actionDriver
            if (driver == null || !driver.isTikTokInForeground()) {
                _feedbackMessage.value = "Open TikTok first or tap 'Load Sample Preview' to test in-app."
                return@launch
            }
            val list = driver.scanVisibleAccounts(mode)
            _feedbackMessage.value = "Scanned ${list.size} visible accounts from TikTok."
        }
    }
}
