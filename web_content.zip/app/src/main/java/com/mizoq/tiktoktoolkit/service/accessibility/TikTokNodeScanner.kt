package com.mizoq.tiktoktoolkit.service.accessibility

import android.graphics.Rect
import android.view.accessibility.AccessibilityNodeInfo
import com.mizoq.tiktoktoolkit.config.MizoBrandConfig
import com.mizoq.tiktoktoolkit.domain.model.DiscoveredAccount
import com.mizoq.tiktoktoolkit.domain.model.MutualStatus
import com.mizoq.tiktoktoolkit.domain.model.RelationshipState
import com.mizoq.tiktoktoolkit.domain.model.SecurityChallenge
import com.mizoq.tiktoktoolkit.domain.model.WorkflowMode

/**
 * Lightweight, testable representation of an Android AccessibilityNodeInfo node.
 * Allows identical parsing logic to run against live AccessibilityNodeInfo trees on Android
 * and deterministic node trees in automated JUnit / QA verification suites.
 */
data class VirtualAccessibilityNode(
    val className: String = "",
    val packageName: String = "",
    val viewIdResourceName: String? = null,
    val text: String? = null,
    val contentDescription: String? = null,
    val isVisibleToUser: Boolean = true,
    val isClickable: Boolean = false,
    val isScrollable: Boolean = false,
    val boundsInScreen: String = "",
    val children: List<VirtualAccessibilityNode> = emptyList()
)

object TikTokNodeScanner {

    private val USERNAME_HANDLE_REGEX = Regex("^@[a-zA-Z0-9_.]{2,32}$")
    private val BARE_HANDLE_REGEX = Regex("^[a-zA-Z0-9_.]{2,32}$")

    private val CAPTCHA_PATTERNS = listOf(
        Regex("verify\\s+to\\s+continue", RegexOption.IGNORE_CASE),
        Regex("drag\\s+the\\s+puzzle", RegexOption.IGNORE_CASE),
        Regex("fit\\s+the\\s+puzzle", RegexOption.IGNORE_CASE),
        Regex("security\\s+verification", RegexOption.IGNORE_CASE),
        Regex("select\\s+2\\s+objects", RegexOption.IGNORE_CASE)
    )

    private val RATE_LIMIT_PATTERNS = listOf(
        Regex("following\\s+too\\s+fast", RegexOption.IGNORE_CASE),
        Regex("unfollowing\\s+too\\s+fast", RegexOption.IGNORE_CASE),
        Regex("operating\\s+too\\s+frequently", RegexOption.IGNORE_CASE),
        Regex("too\\s+many\\s+requests", RegexOption.IGNORE_CASE),
        Regex("try\\s+again\\s+later", RegexOption.IGNORE_CASE)
    )

    fun isOfficialTikTokPackage(packageName: String?): Boolean {
        if (packageName.isNullOrBlank()) return false
        return MizoBrandConfig.OFFICIAL_TIKTOK_PACKAGES.contains(packageName.trim())
    }

    fun toVirtualTree(root: AccessibilityNodeInfo?): VirtualAccessibilityNode? {
        if (root == null) return null
        val rect = Rect()
        root.getBoundsInScreen(rect)
        val childList = mutableListOf<VirtualAccessibilityNode>()
        for (i in 0 until root.childCount) {
            val child = root.getChild(i)
            if (child != null) {
                toVirtualTree(child)?.let { childList.add(it) }
            }
        }
        return VirtualAccessibilityNode(
            className = root.className?.toString() ?: "",
            packageName = root.packageName?.toString() ?: "",
            viewIdResourceName = root.viewIdResourceName,
            text = root.text?.toString(),
            contentDescription = root.contentDescription?.toString(),
            isVisibleToUser = root.isVisibleToUser,
            isClickable = root.isClickable,
            isScrollable = root.isScrollable,
            boundsInScreen = "${rect.left},${rect.top},${rect.right},${rect.bottom}",
            children = childList
        )
    }

    /**
     * Inspects the visible tree for TikTok CAPTCHA puzzles, security verification dialogs,
     * or rate-limit toast alerts.
     */
    fun detectSecurityChallenge(root: VirtualAccessibilityNode?): SecurityChallenge {
        if (root == null || !root.isVisibleToUser) {
            return SecurityChallenge(detected = false)
        }
        val texts = mutableListOf<String>()
        collectVisibleTexts(root, texts)
        val combined = texts.joinToString(" | ")

        for (pat in RATE_LIMIT_PATTERNS) {
            if (pat.containsMatchIn(combined)) {
                return SecurityChallenge(
                    detected = true,
                    challengeType = "rate_limited",
                    message = "TikTok rate limit detected on screen. Automation paused immediately."
                )
            }
        }

        for (pat in CAPTCHA_PATTERNS) {
            if (pat.containsMatchIn(combined)) {
                return SecurityChallenge(
                    detected = true,
                    challengeType = "verification_required",
                    message = "TikTok verification challenge (CAPTCHA) detected. Complete verification manually in TikTok, then tap Resume."
                )
            }
        }

        return SecurityChallenge(detected = false)
    }

    /**
     * Scans visible account rows in the TikTok Following or Followers list.
     * Enforces strict row-button ownership and never identifies an account by display name alone.
     */
    fun scanAccountRows(
        root: VirtualAccessibilityNode?,
        mode: WorkflowMode
    ): List<DiscoveredAccount> {
        if (root == null || !root.isVisibleToUser) return emptyList()
        if (root.packageName.isNotEmpty() && !isOfficialTikTokPackage(root.packageName)) {
            return emptyList()
        }

        val candidateRows = mutableListOf<VirtualAccessibilityNode>()
        collectCandidateRowContainers(root, candidateRows)

        val discovered = LinkedHashMap<String, DiscoveredAccount>()
        for (rowNode in candidateRows) {
            val parsed = parseSingleRowNode(rowNode, mode) ?: continue
            val key = parsed.normalizedUsername
            if (key.isNotEmpty() && !discovered.containsKey(key)) {
                discovered[key] = parsed
            }
        }
        return discovered.values.toList()
    }

    /**
     * Computes a compact fingerprint of the currently visible rows so the scanner skips
     * redundant full-screen processing when the list has not scrolled or changed.
     */
    fun computeVisibleListFingerprint(accounts: List<DiscoveredAccount>, mode: WorkflowMode): String {
        if (accounts.isEmpty()) return "${mode.wireValue}:0"
        val first = accounts.first()
        val last = accounts.last()
        return "${mode.wireValue}:${accounts.size}:${first.normalizedUsername}:${first.relationshipState.wireValue}:${last.normalizedUsername}:${last.relationshipState.wireValue}"
    }

    fun parseSingleRowNode(
        rowNode: VirtualAccessibilityNode,
        mode: WorkflowMode
    ): DiscoveredAccount? {
        if (!rowNode.isVisibleToUser || rowNode.children.isEmpty()) return null

        val allNodes = mutableListOf<VirtualAccessibilityNode>()
        flattenVisibleSubtree(rowNode, allNodes)

        // 1. Identify username handle — never fall back to display name alone
        var username: String? = null
        var displayName: String? = null

        for (node in allNodes) {
            val txt = node.text?.trim() ?: ""
            val viewId = node.viewIdResourceName?.lowercase() ?: ""
            if (txt.isEmpty()) continue

            if (USERNAME_HANDLE_REGEX.matches(txt)) {
                username = txt.removePrefix("@")
            } else if ((viewId.contains("username") || viewId.contains("unique_id") || viewId.contains("handle")) &&
                BARE_HANDLE_REGEX.matches(txt)
            ) {
                username = txt
            } else if (displayName == null && !isActionLabel(txt) && !isMutualBadgeText(txt)) {
                displayName = txt
            }
        }

        if (username.isNullOrBlank()) {
            return null
        }

        // 2. Identify action button and "..." more options button owned by this exact rowNode
        var primaryButtonText: String? = null
        var hasMoreButton = false
        var mutualBadgeDetected = false

        for (node in allNodes) {
            val txt = (node.text ?: node.contentDescription ?: "").trim()
            val lower = txt.lowercase()
            val viewId = node.viewIdResourceName?.lowercase() ?: ""

            if (isMutualBadgeText(lower)) {
                mutualBadgeDetected = true
            }

            val looksLikeButton = node.isClickable ||
                node.className.contains("Button", ignoreCase = true) ||
                viewId.contains("btn") ||
                viewId.contains("button") ||
                isActionLabel(lower)

            if (looksLikeButton) {
                if (lower == "..." || lower == "⋯" || lower.contains("more options") || viewId.contains("more")) {
                    hasMoreButton = true
                } else if (primaryButtonText == null && isActionLabel(lower)) {
                    primaryButtonText = txt
                }
            }
        }

        // Must own a verifiable action control inside the same row subtree
        val ownsActionControl = primaryButtonText != null || (mode == WorkflowMode.FOLLOWERS && hasMoreButton)
        if (!ownsActionControl) {
            return null
        }

        val btnLower = (primaryButtonText ?: "").lowercase()
        val hasExplicitMutualSignal = mutualBadgeDetected ||
            btnLower == "friends" ||
            btnLower == "mutual" ||
            btnLower == "each other"

        val (mutualStatus, relState) = if (mode == WorkflowMode.FOLLOWING) {
            when {
                hasExplicitMutualSignal -> MutualStatus.MUTUAL to RelationshipState.FRIENDS
                btnLower == "following" || btnLower == "requested" -> MutualStatus.NON_MUTUAL to RelationshipState.FOLLOWING
                btnLower == "follow" || btnLower == "follow back" -> MutualStatus.NON_MUTUAL to RelationshipState.NOT_FOLLOWING
                else -> MutualStatus.UNKNOWN to RelationshipState.UNKNOWN
            }
        } else {
            when {
                hasExplicitMutualSignal || btnLower == "following" -> MutualStatus.MUTUAL to RelationshipState.FRIENDS
                btnLower == "follow back" || btnLower == "follow" -> MutualStatus.NON_MUTUAL to RelationshipState.FOLLOWER_ONLY
                btnLower == "removed" || btnLower == "unblock" -> MutualStatus.NON_MUTUAL to RelationshipState.REMOVED
                else -> MutualStatus.UNKNOWN to RelationshipState.UNKNOWN
            }
        }

        return DiscoveredAccount(
            username = username,
            displayName = displayName ?: username,
            mutualStatus = mutualStatus,
            relationshipState = relState,
            actionButtonText = primaryButtonText ?: "...",
            hasMoreOptionsButton = hasMoreButton,
            followsYouIndicator = hasExplicitMutualSignal || mode == WorkflowMode.FOLLOWERS,
            rowBoundsSignature = rowNode.boundsInScreen,
            buttonOwnershipVerified = true
        )
    }

    private fun isActionLabel(text: String): Boolean {
        val t = text.trim().lowercase()
        return t == "following" ||
            t == "friends" ||
            t == "follow" ||
            t == "follow back" ||
            t == "requested" ||
            t == "remove" ||
            t == "removed"
    }

    private fun isMutualBadgeText(text: String): Boolean {
        val t = text.trim().lowercase()
        return t == "friends" || t == "follows you" || t == "mutual" || t == "each other"
    }

    private fun collectCandidateRowContainers(
        node: VirtualAccessibilityNode,
        out: MutableList<VirtualAccessibilityNode>
    ) {
        if (!node.isVisibleToUser) return
        if (node.children.size >= 2) {
            out.add(node)
        }
        for (child in node.children) {
            collectCandidateRowContainers(child, out)
        }
    }

    private fun flattenVisibleSubtree(
        node: VirtualAccessibilityNode,
        out: MutableList<VirtualAccessibilityNode>
    ) {
        if (!node.isVisibleToUser) return
        out.add(node)
        for (child in node.children) {
            flattenVisibleSubtree(child, out)
        }
    }

    private fun collectVisibleTexts(node: VirtualAccessibilityNode, out: MutableList<String>) {
        if (!node.isVisibleToUser) return
        node.text?.takeIf { it.isNotBlank() }?.let { out.add(it) }
        node.contentDescription?.takeIf { it.isNotBlank() }?.let { out.add(it) }
        for (child in node.children) {
            collectVisibleTexts(child, out)
        }
    }
}
