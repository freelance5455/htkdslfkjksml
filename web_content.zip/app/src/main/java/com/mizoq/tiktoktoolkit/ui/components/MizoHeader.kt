package com.mizoq.tiktoktoolkit.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mizoq.tiktoktoolkit.config.MizoBrandConfig
import com.mizoq.tiktoktoolkit.ui.theme.MizoAmberWarning
import com.mizoq.tiktoktoolkit.ui.theme.MizoCyanHighlight
import com.mizoq.tiktoktoolkit.ui.theme.MizoLavenderAccent
import com.mizoq.tiktoktoolkit.ui.theme.MizoMidnightSurface
import com.mizoq.tiktoktoolkit.ui.theme.MizoMintSuccess
import com.mizoq.tiktoktoolkit.ui.theme.MizoPurplePrimary
import com.mizoq.tiktoktoolkit.ui.theme.MizoTextPrimary

@Composable
fun MizoHeader(
    isAccessibilityEnabled: Boolean,
    isOverlayGranted: Boolean,
    onOpenSettingsTab: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = MizoMidnightSurface.copy(alpha = 0.92f),
        modifier = modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                // Custom Mizo_q Monogram Badge ("MQ")
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(38.dp)
                        .background(
                            brush = Brush.linearGradient(
                                colors = listOf(Color(0xFF0F172A), MizoPurplePrimary, Color(0xFF0891B2))
                            ),
                            shape = RoundedCornerShape(10.dp)
                        )
                        .border(1.5.dp, MizoCyanHighlight, RoundedCornerShape(10.dp))
                ) {
                    Text(
                        text = MizoBrandConfig.MONOGRAM,
                        color = MizoTextPrimary,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 13.sp
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = MizoBrandConfig.PRODUCT_TITLE,
                            color = MizoTextPrimary,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 14.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .background(
                                    color = MizoCyanHighlight.copy(alpha = 0.16f),
                                    shape = RoundedCornerShape(999.dp)
                                )
                                .border(1.dp, MizoCyanHighlight.copy(alpha = 0.45f), RoundedCornerShape(999.dp))
                                .padding(horizontal = 6.dp, vertical = 1.dp)
                        ) {
                            Text(
                                text = MizoBrandConfig.VERSION_BADGE,
                                color = MizoCyanHighlight,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp
                            )
                        }
                    }
                    Text(
                        text = MizoBrandConfig.PRODUCT_SUBTITLE,
                        color = MizoLavenderAccent,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 11.sp
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                val ready = isAccessibilityEnabled && isOverlayGranted
                val statusColor = if (ready) MizoMintSuccess else MizoAmberWarning
                val statusText = when {
                    ready -> "Ready"
                    isOverlayGranted -> "Need A11y"
                    else -> "Setup Perm"
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .background(statusColor.copy(alpha = 0.16f), RoundedCornerShape(999.dp))
                        .border(1.dp, statusColor.copy(alpha = 0.45f), RoundedCornerShape(999.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .background(statusColor, CircleShape)
                    )
                    Spacer(modifier = Modifier.width(5.dp))
                    Text(
                        text = statusText,
                        color = statusColor,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.5.sp
                    )
                }

                IconButton(onClick = onOpenSettingsTab) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = "Open Settings Tab",
                        tint = MizoLavenderAccent
                    )
                }
            }
        }
    }
}
