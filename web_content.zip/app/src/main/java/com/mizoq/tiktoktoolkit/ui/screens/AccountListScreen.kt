package com.mizoq.tiktoktoolkit.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mizoq.tiktoktoolkit.domain.engine.EligibilityEvaluator
import com.mizoq.tiktoktoolkit.domain.model.DiscoveredAccount
import com.mizoq.tiktoktoolkit.domain.model.MutualStatus
import com.mizoq.tiktoktoolkit.domain.model.WorkflowMode
import com.mizoq.tiktoktoolkit.ui.theme.MizoAmberWarning
import com.mizoq.tiktoktoolkit.ui.theme.MizoCyanHighlight
import com.mizoq.tiktoktoolkit.ui.theme.MizoMidnightElevated
import com.mizoq.tiktoktoolkit.ui.theme.MizoMidnightSurface
import com.mizoq.tiktoktoolkit.ui.theme.MizoMintSuccess
import com.mizoq.tiktoktoolkit.ui.theme.MizoPurplePrimary
import com.mizoq.tiktoktoolkit.ui.theme.MizoTextMuted
import com.mizoq.tiktoktoolkit.ui.theme.MizoTextPrimary
import com.mizoq.tiktoktoolkit.ui.theme.MizoTextSecondary

@Composable
fun AccountListScreen(
    mode: WorkflowMode,
    accounts: List<DiscoveredAccount>,
    selectedSet: Set<String>,
    skipMutuals: Boolean,
    onScanTikTokList: () -> Unit,
    onLoadSamplePreview: () -> Unit,
    onToggleSkipMutuals: (Boolean) -> Unit,
    onSelectAll: () -> Unit,
    onDeselectAll: () -> Unit,
    onToggleAccountSelection: (String, Boolean) -> Unit,
    onStartSessionForMode: () -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    val filtered = remember(accounts, searchQuery) {
        val q = searchQuery.trim().lowercase()
        if (q.isEmpty()) accounts else accounts.filter {
            it.username.lowercase().contains(q) || it.displayName.lowercase().contains(q)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        if (mode == WorkflowMode.FOLLOWERS) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MizoMidnightElevated.copy(alpha = 0.85f), RoundedCornerShape(10.dp))
                    .border(1.dp, MizoCyanHighlight.copy(alpha = 0.35f), RoundedCornerShape(10.dp))
                    .padding(10.dp)
            ) {
                Text(
                    text = "Followers Management & Guided Assist",
                    color = MizoCyanHighlight,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
                Text(
                    text = "Uses TikTok's native 'Remove this follower' menu option via '...' on each follower row when exposed in the Accessibility tree, or Guided Assist if manual confirmation is required.",
                    color = MizoTextSecondary,
                    fontSize = 11.sp
                )
            }
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(MizoMidnightSurface.copy(alpha = 0.9f), RoundedCornerShape(14.dp))
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${mode.displayTitle} (${accounts.size} detected, ${selectedSet.size} selected)",
                    color = MizoTextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.5.sp
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Button(
                    onClick = onScanTikTokList,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = MizoPurplePrimary)
                ) {
                    Text("Scan TikTok", color = Color.White, fontSize = 11.sp)
                }
                OutlinedButton(
                    onClick = onLoadSamplePreview,
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Sample Preview", color = MizoCyanHighlight, fontSize = 11.sp)
                }
                Button(
                    onClick = onStartSessionForMode,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0891B2))
                ) {
                    Text("Start Run", color = Color.White, fontSize = 11.sp)
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Skip Mutuals (Friends & Uncertain)",
                    color = MizoTextPrimary,
                    fontSize = 12.sp
                )
                Switch(
                    checked = skipMutuals,
                    onCheckedChange = onToggleSkipMutuals
                )
            }

            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                label = { Text("Filter @username or display name") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(onClick = onSelectAll, modifier = Modifier.weight(1f)) {
                    Text("Select All Eligible", color = MizoTextPrimary, fontSize = 11.sp)
                }
                OutlinedButton(onClick = onDeselectAll, modifier = Modifier.weight(1f)) {
                    Text("Deselect All", color = MizoTextSecondary, fontSize = 11.sp)
                }
            }

            if (filtered.isEmpty()) {
                Text(
                    text = "No accounts loaded yet. Open TikTok's ${mode.wireValue} list and tap 'Scan TikTok', or tap 'Sample Preview'.",
                    color = MizoTextMuted,
                    fontSize = 11.5.sp,
                    modifier = Modifier.padding(vertical = 12.dp)
                )
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(filtered, key = { it.normalizedUsername }) { acc ->
                        val elig = EligibilityEvaluator.evaluate(acc, skipMutuals)
                        val isChecked = selectedSet.contains(acc.normalizedUsername)
                        val badgeColor = when (acc.mutualStatus) {
                            MutualStatus.MUTUAL -> MizoMintSuccess
                            MutualStatus.UNKNOWN -> MizoAmberWarning
                            MutualStatus.NON_MUTUAL -> MizoCyanHighlight
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(MizoMidnightElevated.copy(alpha = 0.75f), RoundedCornerShape(10.dp))
                                .padding(horizontal = 8.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Checkbox(
                                    checked = isChecked,
                                    enabled = elig.eligible,
                                    onCheckedChange = { checked ->
                                        onToggleAccountSelection(acc.normalizedUsername, checked)
                                    }
                                )
                                Column {
                                    Text(
                                        text = "@${acc.username}",
                                        color = MizoTextPrimary,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp
                                    )
                                    Text(
                                        text = acc.displayName,
                                        color = MizoTextSecondary,
                                        fontSize = 11.sp
                                    )
                                }
                            }
                            Text(
                                text = acc.mutualStatus.displayLabel,
                                color = badgeColor,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.5.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
