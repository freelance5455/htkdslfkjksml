package com.elisei.vpn;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.net.VpnService;
import android.os.Build;
import android.os.ParcelFileDescriptor;
import java.io.*;
import java.net.*;
import java.nio.ByteBuffer;
import java.util.*;

public class EliseiVpnService extends VpnService {
    public static final String ACTION_START = "com.elisei.vpn.START";
    public static final String ACTION_STOP = "com.elisei.vpn.STOP";
    private static final String CHANNEL = "elisei_vpn";
    private ParcelFileDescriptor tun;
    private Thread worker;
    private volatile boolean running;
    private final Set<String> blocked = new HashSet<>(Arrays.asList(
        "doubleclick.net","googleadservices.com","googlesyndication.com",
        "adservice.google.com","adsystem.com","ads-twitter.com",
        "facebook.net","connect.facebook.net","app-measurement.com",
        "analytics.google.com","googletagmanager.com","scorecardresearch.com"
    ));

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopVpn();
            return START_NOT_STICKY;
        }
        if (!running) startVpn();
        return START_STICKY;
    }

    private void startVpn() {
        try {
            createNotificationChannel();
            startForeground(7, notification());

            Builder b = new Builder()
                .setSession("Elisei VPN")
                .setMtu(1500)
                .addAddress("10.7.0.2", 32)
                .addDnsServer("10.7.0.1")
                // Only the synthetic DNS endpoint is routed through the TUN.
                // Normal internet traffic is not captured by this minimal DNS VPN.
                .addRoute("10.7.0.1", 32)
                .setBlocking(true);

            tun = b.establish();
            if (tun == null) throw new IOException("VPN interface could not be established");
            running = true;
            worker = new Thread(this::loop, "EliseDnsVpn");
            worker.start();
        } catch (Exception e) {
            stopVpn();
        }
    }

    private void loop() {
        byte[] packet = new byte[32767];
        try (FileInputStream in = new FileInputStream(tun.getFileDescriptor());
             FileOutputStream out = new FileOutputStream(tun.getFileDescriptor())) {

            while (running) {
                int n = in.read(packet);
                if (n <= 0) continue;
                DnsPacket p = DnsPacket.parse(packet, n);
                if (p == null || p.protocol != 17 || p.dstPort != 53) continue;

                String q = p.queryName;
                if (q != null && isBlocked(q)) {
                    byte[] response = DnsPacket.blockedResponse(packet, n, p);
                    out.write(response);
                } else {
                    byte[] response = forwardDns(packet, n, p);
                    if (response != null) out.write(response);
                }
            }
        } catch (Exception ignored) {
        }
    }

    private boolean isBlocked(String name) {
        String d = name.toLowerCase(Locale.US);
        for (String x : blocked) if (d.equals(x) || d.endsWith("." + x)) return true;
        return false;
    }

    private byte[] forwardDns(byte[] original, int len, DnsPacket p) {
        try {
            DatagramSocket s = new DatagramSocket();
            protect(s);
            s.setSoTimeout(2500);
            // Cloudflare public DNS is used as the upstream resolver.
            DatagramPacket q = new DatagramPacket(original, p.udpPayloadOffset,
                    p.dnsLength, InetAddress.getByName("1.1.1.1"), 53);
            s.send(q);
            byte[] buf = new byte[4096];
            DatagramPacket r = new DatagramPacket(buf, buf.length);
            s.receive(r);
            byte[] dns = Arrays.copyOf(r.getData(), r.getLength());
            return DnsPacket.wrapResponse(original, len, p, dns);
        } catch (Exception e) {
            return null;
        }
    }

    private void stopVpn() {
        running = false;
        if (tun != null) try { tun.close(); } catch (Exception ignored) {}
        tun = null;
        if (worker != null) worker.interrupt();
        worker = null;
        stopForeground(true);
        stopSelf();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = getSystemService(NotificationManager.class);
            nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Elisei VPN", NotificationManager.IMPORTANCE_LOW));
        }
    }

    private Notification notification() {
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
            ? new Notification.Builder(this, CHANNEL)
            : new Notification.Builder(this);
        return b.setContentTitle("Elisei VPN")
            .setContentText("Локальная DNS-фильтрация активна")
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setOngoing(true).build();
    }
}
