package com.elisei.vpn;

import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.util.Arrays;

final class DnsPacket {
    int protocol, srcPort, dstPort, udpPayloadOffset, dnsLength;
    String queryName;
    int ipHeaderLen, ipTotalLen, dnsId;
    byte[] srcIp = new byte[4], dstIp = new byte[4];

    static DnsPacket parse(byte[] p, int len) {
        if (len < 28 || (p[0] & 0xF0) != 0x40) return null;
        DnsPacket x = new DnsPacket();
        x.ipHeaderLen = (p[0] & 0x0F) * 4;
        x.ipTotalLen = u16(p,2);
        x.protocol = p[9] & 255;
        System.arraycopy(p,12,x.srcIp,0,4);
        System.arraycopy(p,16,x.dstIp,0,4);
        if (x.protocol != 17 || len < x.ipHeaderLen + 8) return x;
        int u=x.ipHeaderLen;
        x.srcPort=u16(p,u); x.dstPort=u16(p,u+2);
        int udpLen=u16(p,u+4);
        x.udpPayloadOffset=u+8;
        x.dnsLength=Math.max(0, Math.min(udpLen-8, len-x.udpPayloadOffset));
        if (x.dstPort == 53 && x.dnsLength >= 12) {
            x.dnsId=u16(p,x.udpPayloadOffset);
            x.queryName=name(p,x.udpPayloadOffset+12,len);
        }
        return x;
    }

    static byte[] blockedResponse(byte[] req, int len, DnsPacket x) {
        byte[] r = Arrays.copyOf(req, x.udpPayloadOffset + 12 + 5);
        // Swap IPv4 addresses and UDP ports.
        System.arraycopy(req,12,r,16,4);
        System.arraycopy(req,16,r,12,4);
        put16(r,x.ipHeaderLen,x.dstPort); put16(r,x.ipHeaderLen+2,x.srcPort);
        int d=x.udpPayloadOffset;
        put16(r,d+2,0x8182); // NXDOMAIN
        put16(r,d+4,1); put16(r,d+6,0); put16(r,d+8,0); put16(r,d+10,0);
        // Preserve question name/type/class from original.
        int qEnd=findQuestionEnd(req,d+12,len);
        int qLen=qEnd-(d+12)+4;
        r=Arrays.copyOf(req,d+12+qLen);
        put16(r,d+2,0x8182);
        put16(r,d+4,1); put16(r,d+6,0); put16(r,d+8,0); put16(r,d+10,0);
        System.arraycopy(req,12,r,16,4); System.arraycopy(req,16,r,12,4);
        put16(r,x.ipHeaderLen,x.dstPort); put16(r,x.ipHeaderLen+2,x.srcPort);
        fixLengths(r,d+qLen+12);
        return r;
    }

    static byte[] wrapResponse(byte[] req,int len,DnsPacket x,byte[] dns) {
        int total=x.ipHeaderLen+8+dns.length;
        byte[] r=new byte[total];
        System.arraycopy(req,0,r,0,x.ipHeaderLen);
        r[8]=64; r[9]=17;
        System.arraycopy(req,16,r,12,4); System.arraycopy(req,12,r,16,4);
        put16(r,2,total);
        put16(r,x.ipHeaderLen,x.dstPort); put16(r,x.ipHeaderLen+2,x.srcPort);
        put16(r,x.ipHeaderLen+4,8+dns.length); put16(r,x.ipHeaderLen+6,0);
        System.arraycopy(dns,0,r,x.ipHeaderLen+8,dns.length);
        fixLengths(r,total);
        return r;
    }

    private static void fixLengths(byte[] p,int total) {
        put16(p,2,total); put16(p,10,0); put16(p,10,checksum(p,0,(p[0]&15)*4));
        int h=(p[0]&15)*4; put16(p,h+6,0); put16(p,h+6,checksum(p,h,total-h));
    }

    private static int checksum(byte[] b,int off,int n) {
        long s=0; for(int i=off;i<off+n;i+=2){s+=(b[i]&255)<<8; if(i+1<off+n)s+=b[i+1]&255;}
        while((s>>>16)!=0)s=(s&65535)+(s>>>16); return (int)(~s)&65535;
    }
    private static int u16(byte[] b,int i){return ((b[i]&255)<<8)|(b[i+1]&255);}
    private static void put16(byte[] b,int i,int v){b[i]=(byte)(v>>8);b[i+1]=(byte)v;}

    private static String name(byte[] p,int i,int end){
        StringBuilder s=new StringBuilder();
        while(i<end){int n=p[i++]&255;if(n==0)break;if((n&0xC0)!=0)break;if(i+n>end)break;
            if(s.length()>0)s.append('.');s.append(new String(p,i,n));i+=n;}
        return s.toString();
    }
    private static int findQuestionEnd(byte[] p,int i,int end){
        while(i<end){int n=p[i++]&255;if(n==0)return i;if((n&0xC0)!=0)return i+1;i+=n;}
        return i;
    }
}
