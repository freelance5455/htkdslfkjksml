package com.elisei.vpn;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.VpnService;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private static final int VPN_REQUEST = 1001;
    private static final String ACTION_STATUS = "com.elisei.vpn.STATUS";
    private WebView web;

    private final BroadcastReceiver statusReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            boolean ok = intent.getBooleanExtra("ok", false);
            String message = intent.getStringExtra("message");
            String js = "window.eliseiNativeState && window.eliseiNativeState(" + ok + ");";
            if (message != null) {
                js += "window.eliseiNativeError && window.eliseiNativeError(" + quote(message) + ");";
            }
            if (web != null) web.evaluateJavascript(js, null);
        }
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new Bridge(), "Elisei");
        web.loadUrl("file:///android_asset/www/index.html");
        setContentView(web);

        IntentFilter f = new IntentFilter(ACTION_STATUS);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(statusReceiver, f, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(statusReceiver, f);
    }

    private void prepareVpn() {
        try {
            Intent i = VpnService.prepare(this);
            if (i != null) startActivityForResult(i, VPN_REQUEST);
            else startVpn();
        } catch (Exception e) {
            showError("Не удалось запросить разрешение VPN: " + errorText(e));
        }
    }

    private void startVpn() {
        try {
            Intent i = new Intent(this, EliseiVpnService.class);
            i.setAction(EliseiVpnService.ACTION_START);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
            else startService(i);
        } catch (Exception e) {
            showError("Не удалось запустить VPN: " + errorText(e));
        }
    }

    public void stopVpn() {
        try {
            Intent i = new Intent(this, EliseiVpnService.class);
            i.setAction(EliseiVpnService.ACTION_STOP);
            startService(i);
        } catch (Exception e) {
            showError("Не удалось остановить VPN: " + errorText(e));
        }
    }

    @Override protected void onActivityResult(int r, int c, Intent d) {
        super.onActivityResult(r, c, d);
        if (r == VPN_REQUEST) {
            if (c == RESULT_OK) startVpn();
            else showError("Разрешение VPN не предоставлено");
        }
    }

    private void showError(String message) {
        if (web != null) web.evaluateJavascript(
            "window.eliseiNativeState && window.eliseiNativeState(false);" +
            "window.eliseiNativeError && window.eliseiNativeError(" + quote(message) + ");", null);
    }

    private static String quote(String s) {
        return "'" + s.replace("\\", "\\\\").replace("'", "\\'")
            .replace("\n", "\\n").replace("\r", "\\r") + "'";
    }

    private static String errorText(Exception e) {
        return e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
    }

    @Override protected void onDestroy() {
        try { unregisterReceiver(statusReceiver); } catch (Exception ignored) {}
        if (web != null) web.destroy();
        super.onDestroy();
    }

    private class Bridge {
        @JavascriptInterface public void start() { runOnUiThread(() -> prepareVpn()); }
        @JavascriptInterface public void stop() { runOnUiThread(() -> stopVpn()); }
        @JavascriptInterface public boolean isNativeAvailable() { return true; }
    }
}
