package com.elisei.vpn;

import android.app.Activity;
import android.content.Intent;
import android.net.VpnService;
import android.os.Bundle;
import android.widget.Toast;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private static final int VPN_REQUEST = 1001;
    private WebView web;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new Bridge(), "Elisei");
        web.loadUrl("file:///android_asset/www/index.html");
        setContentView(web);
    }

    private void prepareVpn() {
        Intent i = VpnService.prepare(this);
        if (i != null) startActivityForResult(i, VPN_REQUEST);
        else startVpn();
    }

    private void startVpn() {
        Intent i = new Intent(this, EliseiVpnService.class);
        i.setAction(EliseiVpnService.ACTION_START);
        try {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                startForegroundService(i);
            } else {
                startService(i);
            }
            web.evaluateJavascript("window.eliseiNativeState && window.eliseiNativeState(true)", null);
        } catch (Exception e) {
            web.evaluateJavascript("window.eliseiNativeState && window.eliseiNativeState(false)", null);
            Toast.makeText(this, "Не удалось запустить VPN: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    public void stopVpn() {
        Intent i = new Intent(this, EliseiVpnService.class);
        i.setAction(EliseiVpnService.ACTION_STOP);
        try {
            startService(i);
        } catch (Exception ignored) {
        }
        web.evaluateJavascript("window.eliseiNativeState && window.eliseiNativeState(false)", null);
    }

    @Override protected void onActivityResult(int r, int c, Intent d) {
        super.onActivityResult(r, c, d);
        if (r == VPN_REQUEST) {
            if (c == RESULT_OK) {
                startVpn();
            } else {
                web.evaluateJavascript("window.eliseiNativeState && window.eliseiNativeState(false)", null);
                Toast.makeText(this, "Разрешение VPN не предоставлено", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private class Bridge {
        @JavascriptInterface public void start() { runOnUiThread(() -> prepareVpn()); }
        @JavascriptInterface public void stop() { runOnUiThread(() -> stopVpn()); }
        @JavascriptInterface public boolean isNativeAvailable() { return true; }
    }
}
