package com.rmreformas.app;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;

public class MainActivity extends Activity {
    WebView w;
    ValueCallback<Uri[]> cb;

    /** Puente JS <-> Android: PDF, compartir, copias y guardado en archivo. */
    class Bridge {
        @JavascriptInterface
        public void printPage(final String name) {
            runOnUiThread(new Runnable() {
                public void run() {
                    try {
                        PrintManager pm = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                        String n = (name == null || name.length() == 0) ? "Presupuesto_RM" : name;
                        PrintDocumentAdapter a = w.createPrintDocumentAdapter(n);
                        pm.print(n, a, new PrintAttributes.Builder()
                                .setMediaSize(PrintAttributes.MediaSize.ISO_A4).build());
                    } catch (Exception e) {
                        toast("No se pudo abrir la impresión / PDF");
                    }
                }
            });
        }

        @JavascriptInterface
        public void shareText(final String t) {
            runOnUiThread(new Runnable() {
                public void run() {
                    Intent i = new Intent(Intent.ACTION_SEND);
                    i.setType("text/plain");
                    i.putExtra(Intent.EXTRA_TEXT, t);
                    startActivity(Intent.createChooser(i, "Compartir"));
                }
            });
        }

        @JavascriptInterface
        public void saveData(String json) {
            try {
                File dir = getFilesDir();
                File tmp = new File(dir, "rm_data.tmp");
                FileOutputStream o = new FileOutputStream(tmp);
                o.write(json.getBytes("UTF-8"));
                o.getFD().sync();
                o.close();
                File dst = new File(dir, "rm_data.json");
                if (dst.exists()) dst.delete();
                tmp.renameTo(dst);
            } catch (Exception e) { }
        }

        @JavascriptInterface
        public String loadData() {
            try {
                File f = new File(getFilesDir(), "rm_data.json");
                if (!f.exists()) return "";
                FileInputStream in = new FileInputStream(f);
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
                in.close();
                return bo.toString("UTF-8");
            } catch (Exception e) { return ""; }
        }

        @JavascriptInterface
        public String saveFile(String name, String mime, String b64) {
            try {
                byte[] bytes = Base64.decode(b64, Base64.DEFAULT);
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues v = new ContentValues();
                    v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                    v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                    v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/RM Reformas");
                    Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                    if (u == null) return "";
                    OutputStream o = getContentResolver().openOutputStream(u);
                    o.write(bytes);
                    o.close();
                    return "Descargas/RM Reformas/" + name;
                } else {
                    File d = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                    d.mkdirs();
                    File f = new File(d, name);
                    FileOutputStream o = new FileOutputStream(f);
                    o.write(bytes);
                    o.close();
                    return f.getAbsolutePath();
                }
            } catch (Exception e) { return ""; }
        }
    }

    void toast(final String m) {
        runOnUiThread(new Runnable() {
            public void run() { Toast.makeText(MainActivity.this, m, Toast.LENGTH_LONG).show(); }
        });
    }

    boolean openExternal(String u) {
        if (u.startsWith("file:")) return false;
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(u))); } catch (Exception e) { }
        return true;
    }

    @Override
    public void onCreate(Bundle b) {
        super.onCreate(b);
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.CAMERA}, 10);
        w = new WebView(this);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        w.addJavascriptInterface(new Bridge(), "AndroidBridge");
        w.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                return openExternal(r.getUrl().toString());
            }
            @Override
            @SuppressWarnings("deprecation")
            public boolean shouldOverrideUrlLoading(WebView v, String url) {
                return openExternal(url);
            }
        });
        w.setWebChromeClient(new WebChromeClient() {
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> c, FileChooserParams p) {
                cb = c;
                try { startActivityForResult(p.createIntent(), 20); }
                catch (Exception e) { cb = null; return false; }
                return true;
            }
            public void onPermissionRequest(final PermissionRequest r) {
                runOnUiThread(new Runnable() { public void run() { r.grant(r.getResources()); } });
            }
        });
        w.loadUrl("file:///android_asset/RM_Reformas.html");
        setContentView(w);
    }

    @Override
    protected void onPause() {
        // Guarda todo al salir de la app o al cambiar a otra
        if (w != null) w.evaluateJavascript("window.rmFlush&&window.rmFlush()", null);
        super.onPause();
    }

    @Override
    protected void onActivityResult(int q, int r, Intent d) {
        if (q == 20 && cb != null) {
            cb.onReceiveValue(r == RESULT_OK && d != null ? WebChromeClient.FileChooserParams.parseResult(r, d) : null);
            cb = null;
        }
        super.onActivityResult(q, r, d);
    }

    @Override
    public void onBackPressed() {
        if (w.canGoBack()) w.goBack(); else super.onBackPressed();
    }
}
