package com.lami.link;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.MimeTypeMap;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLDecoder;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {
    private WebView web;
    private volatile boolean cancelled;
    private volatile HttpURLConnection conn;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#1B1E2B"));
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        web.addJavascriptInterface(new Bridge(), "LamiNative");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if ("http".equals(u.getScheme()) || "https".equals(u.getScheme())) {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                    return true;
                }
                return false;
            }
        });
        web.loadUrl("file:///android_asset/index.html");
        setContentView(web);
        if (Build.VERSION.SDK_INT < 29
                && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
        }
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("(window.__back&&window.__back())===true", r -> {
            if (!"true".equals(r)) finish();
        });
    }

    private void event(String type, String url, String name, String mime, long bytes, long total, String dest, String msg, boolean net) {
        try {
            JSONObject o = new JSONObject();
            o.put("type", type).put("url", url).put("name", name).put("mime", mime)
                    .put("bytes", bytes).put("total", total).put("dest", dest).put("msg", msg).put("net", net);
            final String js = "window.__lami&&window.__lami(" + o.toString() + ")";
            runOnUiThread(() -> web.evaluateJavascript(js, null));
        } catch (Exception ignored) { }
    }

    class Bridge {
        @JavascriptInterface
        public String clip() {
            try {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                ClipData d = cm.getPrimaryClip();
                if (d == null || d.getItemCount() == 0) return "";
                CharSequence t = d.getItemAt(0).coerceToText(MainActivity.this);
                return t == null ? "" : t.toString();
            } catch (Exception e) { return ""; }
        }

        @JavascriptInterface
        public void start(final String url) {
            new Thread(() -> download(url)).start();
        }

        @JavascriptInterface
        public void cancel() {
            cancelled = true;
            final HttpURLConnection c = conn;
            if (c != null) new Thread(c::disconnect).start();
        }
    }

    private String nameFrom(String disp, String url, String mime) {
        String n = "";
        if (disp != null) {
            Matcher m = Pattern.compile("filename\\*?=(?:UTF-8'')?\"?([^\";]+)\"?", Pattern.CASE_INSENSITIVE).matcher(disp);
            if (m.find()) {
                try { n = URLDecoder.decode(m.group(1).replace("+", "%2B"), "UTF-8"); } catch (Exception e) { n = m.group(1); }
            }
        }
        if (n.isEmpty()) {
            try {
                String p = new URL(url).getPath();
                n = URLDecoder.decode(p.substring(p.lastIndexOf('/') + 1).replace("+", "%2B"), "UTF-8");
            } catch (Exception ignored) { }
        }
        n = n.replaceAll("[\\\\/:*?\"<>|\\x00-\\x1f]", "_").trim();
        if (n.length() > 120) n = n.substring(0, 120);
        if (n.isEmpty()) n = "download";
        if (!n.matches(".*\\.[A-Za-z0-9]{1,5}$")) {
            String e = MimeTypeMap.getSingleton().getExtensionFromMimeType(mime);
            if (e != null) n += "." + e;
        }
        return n;
    }

    private File unique(File dir, String name) {
        File f = new File(dir, name);
        int i = 1;
        int dot = name.lastIndexOf('.');
        String base = dot > 0 ? name.substring(0, dot) : name;
        String ext = dot > 0 ? name.substring(dot) : "";
        while (f.exists()) f = new File(dir, base + " (" + (i++) + ")" + ext);
        return f;
    }

    private void download(String raw) {
        cancelled = false;
        String name = nameFrom(null, raw, "");
        String mime = "application/octet-stream";
        long bytes = 0, total = 0;
        OutputStream out = null;
        Uri uri = null;
        File file = null;
        try {
            String cur = raw;
            int hops = 0;
            HttpURLConnection c;
            while (true) {
                URL u = new URL(cur);
                c = (HttpURLConnection) u.openConnection();
                conn = c;
                c.setInstanceFollowRedirects(false);
                c.setConnectTimeout(15000);
                c.setReadTimeout(20000);
                c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) LAMILINK/1.0");
                c.setRequestProperty("Accept", "*/*");
                int rc = c.getResponseCode();
                String loc = c.getHeaderField("Location");
                if (rc >= 300 && rc < 400 && loc != null && hops++ < 8) {
                    cur = new URL(u, loc).toString();
                    c.disconnect();
                    continue;
                }
                break;
            }
            int code = c.getResponseCode();
            if (code < 200 || code >= 300) {
                event("error", raw, name, mime, 0, 0, "", "The server answered HTTP " + code + ". The link may be expired, private or not a direct file.", false);
                return;
            }
            String ct = c.getContentType();
            if (ct != null) mime = ct.split(";")[0].trim().toLowerCase();
            name = nameFrom(c.getHeaderField("Content-Disposition"), cur, mime);
            if ((mime.equals("text/html") || mime.equals("application/xhtml+xml"))
                    && !name.toLowerCase().matches(".*\\.(html?|xhtml)$")) {
                event("error", raw, name, mime, 0, 0, "", "This link returns a web page, not a file. Use a direct file link.", false);
                return;
            }
            total = Math.max(0, c.getContentLengthLong());
            String dest = "Downloads/LAMILINK";
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues v = new ContentValues();
                v.put(MediaStore.Downloads.DISPLAY_NAME, name);
                v.put(MediaStore.Downloads.MIME_TYPE, mime);
                v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/LAMILINK");
                v.put(MediaStore.Downloads.IS_PENDING, 1);
                uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                out = getContentResolver().openOutputStream(uri);
            } else {
                File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "LAMILINK");
                if (!(dir.exists() || dir.mkdirs()) || !dir.canWrite()) {
                    dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                    dest = dir.getAbsolutePath();
                }
                file = unique(dir, name);
                out = new FileOutputStream(file);
            }
            InputStream in = c.getInputStream();
            byte[] buf = new byte[65536];
            long last = 0;
            int n;
            while ((n = in.read(buf)) != -1) {
                if (cancelled) throw new java.io.IOException("cancelled");
                out.write(buf, 0, n);
                bytes += n;
                long now = System.currentTimeMillis();
                if (now - last > 150) {
                    last = now;
                    event("progress", raw, name, mime, bytes, total, "", "", false);
                }
            }
            out.flush();
            out.close();
            out = null;
            if (total > 0 && bytes != total) throw new java.io.IOException("Connection ended early (" + bytes + " of " + total + " bytes).");
            if (bytes == 0) throw new IllegalStateException("The server returned an empty file.");
            if (uri != null) {
                ContentValues v = new ContentValues();
                v.put(MediaStore.Downloads.IS_PENDING, 0);
                getContentResolver().update(uri, v, null, null);
            } else if (file != null) {
                MediaScannerConnection.scanFile(this, new String[]{file.getPath()}, null, null);
            }
            event("done", raw, name, mime, bytes, total, dest, "", false);
        } catch (java.io.IOException e) {
            cleanup(out, uri, file);
            if (cancelled) event("cancelled", raw, name, mime, bytes, total, "", "", false);
            else event("error", raw, name, mime, bytes, total, "", "Connection problem: " + e.getMessage(), true);
        } catch (Exception e) {
            cleanup(out, uri, file);
            event("error", raw, name, mime, bytes, total, "", String.valueOf(e.getMessage()), false);
        } finally {
            HttpURLConnection c2 = conn;
            conn = null;
            if (c2 != null) c2.disconnect();
        }
    }

    private void cleanup(OutputStream out, Uri uri, File file) {
        try { if (out != null) out.close(); } catch (Exception ignored) { }
        try { if (uri != null) getContentResolver().delete(uri, null, null); } catch (Exception ignored) { }
        try { if (file != null) file.delete(); } catch (Exception ignored) { }
    }
}
