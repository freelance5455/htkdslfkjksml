package com.fellah.agriculture

import android.app.Activity
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebSettings

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        web.settings.cacheMode = WebSettings.LOAD_DEFAULT
        web.webViewClient = WebViewClient()

        // تحميل Fellah من assets بدل appassets.androidplatform.net
        web.loadUrl("file:///android_asset/index.html")

        setContentView(web)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        val web = findViewById<WebView>(android.R.id.content)?.findViewById<WebView>(0)
        if (web != null && web.canGoBack()) web.goBack()
        else super.onBackPressed()
    }
}
