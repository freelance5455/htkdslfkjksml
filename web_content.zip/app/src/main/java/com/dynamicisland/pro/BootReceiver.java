package com.dynamicisland.pro;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction()) ||
            Intent.ACTION_LOCKED_BOOT_COMPLETED.equals(intent.getAction())) {
            // AccessibilityService akan dihidupkan ulang otomatis oleh sistem Android jika sudah diaktifkan pengguna
            Intent serviceIntent = new Intent(context, DynamicIslandService.class);
            context.startService(serviceIntent);
        }
    }
}
