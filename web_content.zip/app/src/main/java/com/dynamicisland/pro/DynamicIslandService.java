package com.dynamicisland.pro;

import android.accessibilityservice.AccessibilityService;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.BatteryManager;
import android.os.Build;
import android.view.Gravity;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.LinearLayout;
import android.widget.TextView;

public class DynamicIslandService extends AccessibilityService {

    private WindowManager windowManager;
    private LinearLayout islandView;
    private TextView statusText;
    private WindowManager.LayoutParams params;
    private boolean isExpanded = false;
    private BroadcastReceiver systemReceiver;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);

        islandView = new LinearLayout(this);
        islandView.setOrientation(LinearLayout.HORIZONTAL);
        islandView.setGravity(Gravity.CENTER);

        statusText = new TextView(this);
        statusText.setText("● Dynamic Island Pro");
        statusText.setTextColor(Color.WHITE);
        statusText.setTextSize(12f);
        islandView.addView(statusText);

        params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT
        );

        params.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        params.y = 14; // Pas menutupi takik kamera depan Infinix Hot 30i

        applySavedStyle();

        islandView.setOnClickListener(v -> {
            isExpanded = !isExpanded;
            if (isExpanded) {
                islandView.setPadding(68, 30, 68, 30);
                statusText.setText("🎵 Musik  •  🔔 Notifikasi  •  🔋 Cas  •  🚀 Pintasan");
            } else {
                islandView.setPadding(36, 14, 36, 14);
                statusText.setText("● Dynamic Island Pro");
            }
            windowManager.updateViewLayout(islandView, params);
        });

        windowManager.addView(islandView, params);

        // Mendengarkan status pengisian daya & pembaruan pengaturan secara real-time
        systemReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                if (Intent.ACTION_POWER_CONNECTED.equals(action)) {
                    BatteryManager bm = (BatteryManager) getSystemService(BATTERY_SERVICE);
                    int level = bm != null ? bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) : 0;
                    statusText.setText("⚡ Mengisi Daya (" + level + "%)");
                } else if (Intent.ACTION_POWER_DISCONNECTED.equals(action)) {
                    statusText.setText("● Dynamic Island Pro");
                } else if ("com.dynamicisland.pro.UPDATE_STYLE".equals(action)) {
                    applySavedStyle();
                    windowManager.updateViewLayout(islandView, params);
                }
            }
        };

        IntentFilter filter = new IntentFilter();
        filter.addAction(Intent.ACTION_POWER_CONNECTED);
        filter.addAction(Intent.ACTION_POWER_DISCONNECTED);
        filter.addAction("com.dynamicisland.pro.UPDATE_STYLE");

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(systemReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(systemReceiver, filter);
        }
    }

    private void applySavedStyle() {
        SharedPreferences prefs = getSharedPreferences("DynamicIslandPrefs", Context.MODE_PRIVATE);
        int widthDp = prefs.getInt("widthDp", 150);
        String glowColor = prefs.getString("glowColor", "#38bdf8");

        float density = getResources().getDisplayMetrics().density;
        islandView.setMinimumWidth((int) (widthDp * density));
        islandView.setPadding(36, 14, 36, 14);

        GradientDrawable shape = new GradientDrawable();
        shape.setColor(Color.BLACK);
        shape.setCornerRadius(100f);
        try {
            shape.setStroke(3, Color.parseColor(glowColor));
        } catch (Exception e) {
            shape.setStroke(3, Color.parseColor("#38bdf8"));
        }
        islandView.setBackground(shape);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event.getEventType() == AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED) {
            if (event.getPackageName() != null && !event.getText().isEmpty()) {
                String notif = event.getText().get(0).toString();
                statusText.setText("🔔 " + (notif.length() > 26 ? notif.substring(0, 26) + "..." : notif));
            }
        }
    }

    @Override
    public void onInterrupt() {}

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (systemReceiver != null) unregisterReceiver(systemReceiver);
        if (islandView != null && windowManager != null) windowManager.removeView(islandView);
    }
}
