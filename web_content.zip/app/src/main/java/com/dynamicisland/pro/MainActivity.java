package com.dynamicisland.pro;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private WebView webView;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AndroidBridge(this), "AndroidNative");

        webView.loadUrl("file:///android_asset/index.html");
    }

    public class AndroidBridge {
        Context mContext;
        SharedPreferences prefs;

        AndroidBridge(Context c) {
            mContext = c;
            prefs = c.getSharedPreferences("DynamicIslandPrefs", Context.MODE_PRIVATE);
        }

        @JavascriptInterface
        public void openAccessibilitySettings() {
            Toast.makeText(mContext, "Aktifkan 'Dynamic Island Pro' agar permanen di layar!", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
        }

        @JavascriptInterface
        public void requestOverlayPermission() {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(mContext)) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivity(intent);
            } else {
                Toast.makeText(mContext, "Izin Overlay sudah aktif permanen!", Toast.LENGTH_SHORT).show();
            }
        }

        @JavascriptInterface
        public void disableBatteryOptimization() {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
                if (!pm.isIgnoringBatteryOptimizations(getPackageName())) {
                    @SuppressLint("BatteryLife")
                    Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                            Uri.parse("package:" + getPackageName()));
                    startActivity(intent);
                } else {
                    Toast.makeText(mContext, "Anti-Kill Baterai Infinix sudah aktif!", Toast.LENGTH_SHORT).show();
                }
            }
        }

        @JavascriptInterface
        public void saveIslandStyle(int widthDp, String glowColorHex, boolean alwaysVisible) {
            prefs.edit()
                .putInt("widthDp", widthDp)
                .putString("glowColor", glowColorHex)
                .putBoolean("alwaysVisible", alwaysVisible)
                .apply();

            // Kirim siaran pembaruan langsung ke layanan overlay yang sedang berjalan
            Intent updateIntent = new Intent("com.dynamicisland.pro.UPDATE_STYLE");
            updateIntent.setPackage(getPackageName());
            sendBroadcast(updateIntent);

            Toast.makeText(mContext, "Tampilan disimpan permanen!", Toast.LENGTH_SHORT).show();
        }
    }
}
