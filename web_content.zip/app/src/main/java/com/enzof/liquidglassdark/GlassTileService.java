package com.enzof.liquidglassdark;

import android.app.PendingIntent;
import android.content.Intent;
import android.os.Build;
import android.service.quicksettings.Tile;
import android.service.quicksettings.TileService;

public class GlassTileService extends TileService {
    private static final String PREFS = "glass_preview";
    private static final String KEY = "enabled";

    @Override
    public void onStartListening() {
        super.onStartListening();
        updateTile();
    }

    @Override
    public void onClick() {
        super.onClick();
        boolean enabled = !getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean(KEY, false);
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY, enabled).apply();
        updateTile();
        Intent intent = new Intent(this, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        if (Build.VERSION.SDK_INT >= 34) {
            PendingIntent pi = PendingIntent.getActivity(
                    this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            startActivityAndCollapse(pi);
        } else {
            startActivityAndCollapse(intent);
        }
    }

    private void updateTile() {
        Tile tile = getQsTile();
        if (tile == null) return;
        boolean enabled = getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean(KEY, false);
        tile.setState(enabled ? Tile.STATE_ACTIVE : Tile.STATE_INACTIVE);
        tile.setLabel(enabled ? "Glass Preview ON" : "Glass Preview");
        tile.setContentDescription(enabled
                ? "Previa Liquid Glass ativa no aplicativo"
                : "Ativar previa Liquid Glass no aplicativo");
        tile.updateTile();
    }
}