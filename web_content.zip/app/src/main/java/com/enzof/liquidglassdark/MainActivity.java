package com.enzof.liquidglassdark;

import android.app.Activity;
import android.app.StatusBarManager;
import android.content.ComponentName;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable shape(int fill, int stroke, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(radius));
        d.setStroke(dp(1), stroke);
        return d;
    }

    private TextView label(String s, int size, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(size);
        v.setTextColor(color);
        if (bold) v.setTypeface(null, android.graphics.Typeface.BOLD);
        return v;
    }

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(8, 12, 22));
        getWindow().setNavigationBarColor(Color.rgb(8, 12, 22));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Color.rgb(7, 12, 24), Color.rgb(26, 37, 61), Color.rgb(9, 14, 26)}));
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(24), dp(34), dp(24), dp(30));
        scroll.addView(page);

        page.addView(label("PERSONALIZACAO ANDROID", 12, 0xFFA0BEEB, true));
        TextView title = label("Liquid Glass\nDark", 34, Color.WHITE, true);
        title.setPadding(0, dp(12), 0, dp(8));
        page.addView(title);
        TextView sub = label("Previa escura com camadas translúcidas e um bloco próprio para Configuracoes Rapidas.", 15, 0xFFCDD8EC, false);
        sub.setLineSpacing(dp(3), 1f);
        page.addView(sub);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(18), dp(18), dp(18));
        card.setBackground(shape(0xCC18243A, 0x668FB8F4, 24));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.topMargin = dp(26);
        page.addView(card, cp);
        card.addView(label("PREVIA DO BLOCO", 11, 0xFF9BBEF5, true));
        TextView cardTitle = label("Glass Preview", 22, Color.WHITE, true);
        cardTitle.setPadding(0, dp(12), 0, dp(4));
        card.addView(cardTitle);
        card.addView(label("O bloco alterna a previa Liquid Glass dentro deste aplicativo.", 14, 0xFFD1DCEE, false));

        Button add = new Button(this);
        add.setText("Adicionar bloco ao painel");
        add.setTextColor(Color.WHITE);
        add.setAllCaps(false);
        add.setBackground(shape(0xFF496FAF, 0x88D6E5FF, 20));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, dp(56));
        bp.topMargin = dp(20);
        page.addView(add, bp);
        add.setOnClickListener(v -> requestTile());

        TextView info = label(
                "Este APK cria um bloco Glass Preview e uma tela Liquid Glass Dark no proprio app. Apps comuns nao conseguem redesenhar o painel inteiro da Samsung. Para personalizar o painel do sistema, use Good Lock/Theme Park ou QuickStar, se estiverem disponiveis para seu modelo, regiao e versao.",
                14, 0xFFC6D3EA, false);
        info.setLineSpacing(dp(4), 1f);
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(-1, -2);
        ip.topMargin = dp(26);
        page.addView(info, ip);
        setContentView(scroll);
    }

    private void requestTile() {
        if (Build.VERSION.SDK_INT < 33) {
            Toast.makeText(this, "Abra Editar no painel e adicione Glass Preview.", Toast.LENGTH_LONG).show();
            return;
        }
        try {
            StatusBarManager manager = getSystemService(StatusBarManager.class);
            if (manager == null) throw new IllegalStateException("StatusBarManager indisponivel");
            manager.requestAddTileService(
                    new ComponentName(this, GlassTileService.class),
                    "Glass Preview",
                    Icon.createWithResource(this, R.drawable.ic_glass),
                    getMainExecutor(),
                    result -> runOnUiThread(() -> Toast.makeText(this,
                            result == StatusBarManager.TILE_ADD_REQUEST_RESULT_TILE_ADDED
                                    ? "Bloco adicionado."
                                    : result == StatusBarManager.TILE_ADD_REQUEST_RESULT_TILE_ALREADY_ADDED
                                    ? "O bloco ja esta no painel."
                                    : "O bloco nao foi adicionado.",
                            Toast.LENGTH_LONG).show()));
        } catch (RuntimeException ex) {
            Toast.makeText(this, "Nao foi possivel solicitar o bloco: " + ex.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}