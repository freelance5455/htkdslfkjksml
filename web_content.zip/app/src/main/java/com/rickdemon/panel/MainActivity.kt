package com.rickdemon.panel
import android.app.*; import android.content.*; import android.net.Uri; import android.os.*; import android.provider.Settings
import android.webkit.WebView; import android.webkit.WebViewClient; import android.widget.*; import android.view.*
class MainActivity:Activity(){
 lateinit var web:WebView
 override fun onCreate(b:Bundle?){super.onCreate(b);setContentView(R.layout.main)
  web=findViewById(R.id.web); web.settings.javaScriptEnabled=true; web.settings.domStorageEnabled=true; web.webViewClient=WebViewClient()
  web.loadUrl("file:///android_asset/index.html")
  findViewById<Button>(R.id.activate).setOnClickListener{requestOverlay()}
 }
 fun requestOverlay(){
  if(!Settings.canDrawOverlays(this)){
   startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:$packageName"))); return
  }
  startBubble()
 }
 fun startBubble(){
  val i=Intent(this,OverlayService::class.java)
  if(Build.VERSION.SDK_INT>=26) startForegroundService(i) else startService(i)
  Toast.makeText(this,"Bolha RICK.demon ativada",Toast.LENGTH_SHORT).show()
 }
 override fun onResume(){super.onResume(); if(::web.isInitialized) web.loadUrl("file:///android_asset/index.html")
  if(Settings.canDrawOverlays(this) && intent.getBooleanExtra("auto_start",false)) startBubble()
 }
}