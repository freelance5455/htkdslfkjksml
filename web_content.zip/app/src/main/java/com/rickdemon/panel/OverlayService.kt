package com.rickdemon.panel
import android.app.*; import android.content.*; import android.graphics.PixelFormat; import android.os.*; import android.provider.Settings
import android.view.*; import android.widget.ImageButton
class OverlayService:Service(){
 var wm:WindowManager?=null; var bubble:ImageButton?=null
 override fun onCreate(){super.onCreate();channel();startForeground(77,notification());Handler(Looper.getMainLooper()).post{if(Settings.canDrawOverlays(this))show()}}
 fun show(){if(bubble!=null)return; wm=getSystemService(WINDOW_SERVICE) as WindowManager
  val b=ImageButton(this); b.setImageResource(R.drawable.rick_demon_bubble); b.setBackgroundColor(0x00000000); b.scaleType=ImageButton.ScaleType.CENTER_CROP
  val type=if(Build.VERSION.SDK_INT>=26)WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
  val p=WindowManager.LayoutParams(dp(72),dp(72),type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,PixelFormat.TRANSLUCENT)
  p.gravity=Gravity.TOP or Gravity.END;p.x=dp(10);p.y=dp(180)
  b.setOnClickListener{val i=Intent(this,MainActivity::class.java);i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(i)}
  b.setOnTouchListener(object:View.OnTouchListener{var sx=0f;var sy=0f;var px=0;var py=0;var move=false
   override fun onTouch(v:View,e:MotionEvent):Boolean{when(e.actionMasked){
    MotionEvent.ACTION_DOWN->{sx=e.rawX;sy=e.rawY;px=p.x;py=p.y;move=false;return true}
    MotionEvent.ACTION_MOVE->{val dx=(e.rawX-sx).toInt();val dy=(e.rawY-sy).toInt();if(kotlin.math.abs(dx)>8||kotlin.math.abs(dy)>8)move=true;p.x=px-dx;p.y=py+dy;wm?.updateViewLayout(v,p);return true}
    MotionEvent.ACTION_UP->{if(!move)v.performClick();return true}};return true}})
  wm?.addView(b,p);bubble=b
 }
 fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
 fun channel(){if(Build.VERSION.SDK_INT>=26)getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("rick","RICK.demon",NotificationManager.IMPORTANCE_LOW))}
 fun notification():Notification{val n=if(Build.VERSION.SDK_INT>=26)Notification.Builder(this,"rick") else Notification.Builder(this);return n.setContentTitle("RICK.demon").setContentText("Bolha flutuante ativa").setSmallIcon(R.drawable.rick_demon_bubble).setOngoing(true).build()}
 override fun onBind(i:Intent?)=null
 override fun onDestroy(){bubble?.let{try{wm?.removeView(it)}catch(_:Exception){}};bubble=null;super.onDestroy()}
}