package com.ziyaul.editing

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.*

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var callback: ValueCallback<Array<Uri>>? = null
    private val PICK=7001
    override fun onCreate(b: Bundle?) { super.onCreate(b); setContentView(R.layout.activity_main); web=findViewById(R.id.webView)
        web.settings.javaScriptEnabled=true; web.settings.domStorageEnabled=true; web.settings.allowFileAccess=true; web.settings.allowContentAccess=true
        web.webViewClient=WebViewClient()
        web.webChromeClient=object: WebChromeClient(){ override fun onShowFileChooser(v:WebView?, c:ValueCallback<Array<Uri>>?, p:FileChooserParams?):Boolean{
            callback?.onReceiveValue(null); callback=c
            val i=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="*/*";putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);putExtra(Intent.EXTRA_MIME_TYPES,arrayOf("video/*","image/*","audio/*"))}
            startActivityForResult(i,PICK);return true } }
        web.loadUrl("file:///android_asset/index.html")
    }
    override fun onActivityResult(r:Int,code:Int,data:Intent?){ if(r==PICK){val out=if(code==RESULT_OK&&data!=null){val c=data.clipData;if(c!=null)Array(c.itemCount){c.getItemAt(it).uri}else data.data?.let{arrayOf(it)}}else null;callback?.onReceiveValue(out);callback=null};super.onActivityResult(r,code,data)}
}
