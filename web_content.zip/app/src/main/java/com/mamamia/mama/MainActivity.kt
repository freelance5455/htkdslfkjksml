package com.mamamia.mama

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.view.View
import android.widget.FrameLayout

class MainActivity : Activity() {
    private val requestCode = 41
    private lateinit var popupWebView: WebView
    private lateinit var controls: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        controls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 56, 36, 36)
            addView(TextView(this@MainActivity).apply {
                text = "FAIZ SPOOKY FACE"
                textSize = 26f
            })
            addView(TextView(this@MainActivity).apply {
                text = "Optional repeating test notifications. Minimum interval: 60 seconds."
                textSize = 16f
                setPadding(0, 20, 0, 24)
            })
            addView(Button(this@MainActivity).apply {
                text = "START NOTIFICATIONS"
                setOnClickListener { requestPermissionThenStart() }
            })
            addView(Button(this@MainActivity).apply {
                text = "STOP NOTIFICATIONS"
                setOnClickListener {
                    stopService(Intent(this@MainActivity, ReminderService::class.java))
                    Toast.makeText(this@MainActivity, "Notifications stopped", Toast.LENGTH_SHORT).show()
                }
            })
        }

        popupWebView = WebView(this).apply {
            settings.javaScriptEnabled = true
            webChromeClient = WebChromeClient()
            webViewClient = WebViewClient()
            addJavascriptInterface(PopupBridge(), "AndroidApp")
            loadUrl("file:///android_asset/index.html")
        }

        val root = FrameLayout(this)
        root.addView(controls, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ))
        root.addView(popupWebView, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ))
        setContentView(root)
    }

    inner class PopupBridge {
        @JavascriptInterface
        fun closePopup() {
            runOnUiThread { popupWebView.visibility = View.GONE }
        }
    }

    private fun requestPermissionThenStart() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), requestCode)
        } else {
            startReminder()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == this.requestCode &&
            grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startReminder()
        } else {
            Toast.makeText(this, "Notification permission is needed.", Toast.LENGTH_LONG).show()
        }
    }

    private fun startReminder() {
        val intent = Intent(this, ReminderService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
        Toast.makeText(this, "Started. Use STOP to end it.", Toast.LENGTH_SHORT).show()
    }
}
