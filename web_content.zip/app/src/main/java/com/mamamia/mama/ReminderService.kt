package com.mamamia.mama

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper

class ReminderService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var manager: NotificationManager
    private val channelId = "mamamia_notifications"
    private val foregroundId = 900
    private var count = 0

    private val repeatTask = object : Runnable {
        override fun run() {
            count++
            val notification = Notification.Builder(this@ReminderService, channelId)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("MAMAMIA MAMA")
                .setContentText("MAMAMIAA MAMAMIA")
                .setAutoCancel(true)
                .build()
            manager.notify(1000 + (count % 1000), notification)
            handler.postDelayed(this, 60_000L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        manager = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(
                NotificationChannel(channelId, "MAMAMIA reminders", NotificationManager.IMPORTANCE_DEFAULT)
            )
        }
        val ongoing = Notification.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("MAMAMIA MAMA is running")
            .setContentText("Repeating test notifications every 60 seconds")
            .setOngoing(true)
            .build()
        startForeground(foregroundId, ongoing)
        handler.post(repeatTask)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_NOT_STICKY

    override fun onDestroy() {
        handler.removeCallbacks(repeatTask)
        manager.cancel(foregroundId)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
