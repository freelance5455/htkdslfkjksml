package com.exnessgoldbot.api;

/**
 * Direct Exness integration boundary.
 *
 * This interface intentionally contains no fake endpoint or MT5-password login.
 * Wire the implementation to an Exness-authorized API only after the account/API
 * access and authentication method have been confirmed.
 */
public interface ExnessTradingApi {
    void getAccountStatus(Callback<AccountStatus> callback);
    void placeMarketOrder(OrderRequest request, Callback<OrderResult> callback);
    void closePosition(String positionId, Callback<OrderResult> callback);

    interface Callback<T> {
        void onSuccess(T value);
        void onError(Throwable error);
    }

    final class AccountStatus {
        public final String accountId;
        public final double equity;
        public final String currency;
        public AccountStatus(String accountId, double equity, String currency) {
            this.accountId = accountId;
            this.equity = equity;
            this.currency = currency;
        }
    }

    final class OrderRequest {
        public final String symbol;
        public final String side;
        public final double volume;
        public final Double stopLoss;
        public final Double takeProfit;
        public OrderRequest(String symbol, String side, double volume,
                            Double stopLoss, Double takeProfit) {
            this.symbol = symbol;
            this.side = side;
            this.volume = volume;
            this.stopLoss = stopLoss;
            this.takeProfit = takeProfit;
        }
    }

    final class OrderResult {
        public final boolean accepted;
        public final String orderId;
        public final String message;
        public OrderResult(boolean accepted, String orderId, String message) {
            this.accepted = accepted;
            this.orderId = orderId;
            this.message = message;
        }
    }
}
