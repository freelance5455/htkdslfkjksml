package com.islamiyat.app;
import android.content.Context;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;
import java.util.concurrent.TimeUnit;
public class DhikrScheduler {
 public static void schedule(Context c,int minutes){
   minutes=Math.max(15,Math.min(minutes,24*60));
   PeriodicWorkRequest r=new PeriodicWorkRequest.Builder(DhikrWorker.class,minutes,TimeUnit.MINUTES).build();
   WorkManager.getInstance(c).enqueueUniquePeriodicWork("dhikr_reminders",ExistingPeriodicWorkPolicy.UPDATE,r);
 }
 public static void cancel(Context c){WorkManager.getInstance(c).cancelUniqueWork("dhikr_reminders");}
}
