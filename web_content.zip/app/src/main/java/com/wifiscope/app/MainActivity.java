package com.wifiscope.app;

import android.app.Activity;
import android.os.Bundle;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.LinkProperties;
import android.net.Network;
import android.net.LinkAddress;
import android.net.RouteInfo;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.JavascriptInterface;
import android.graphics.Color;
import android.text.TextUtils;

import org.json.JSONArray;
import org.json.JSONObject;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;
import java.text.SimpleDateFormat;

public class MainActivity extends Activity {
    private WebView web;
    private final ExecutorService pool = Executors.newFixedThreadPool(32);
    private final List<String> history = new ArrayList<>();
    private volatile boolean scanning = false;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(7,17,15));
        getWindow().setNavigationBarColor(Color.rgb(7,17,15));
        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(7,17,15));
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(false);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Bridge(), "WifiScope");
        setContentView(web);
        showHistory();
        web.loadUrl("file:///android_asset/index.html");
    }

    private class Bridge {
        @JavascriptInterface public String getNetworkInfo() {
            NetworkDetails d = getNetworkDetails();
            if (d == null) return "Belum terhubung ke jaringan Wi-Fi atau detail jaringan tidak tersedia.";
            return "IP perangkat: " + d.ip + "\nGateway: " + d.gateway + "\nSubnet: " + d.cidr;
        }
        @JavascriptInterface public String getHistory() {
            return TextUtils.join("\n", history);
        }
        @JavascriptInterface public void scan() {
            runOnUiThread(() -> startScan());
        }
    }

    private void js(String script) {
        runOnUiThread(() -> { if (web != null) web.evaluateJavascript(script, null); });
    }

    private void startScan() {
        if (scanning) return;
        NetworkDetails details = getNetworkDetails();
        if (details == null) { js("setStatus('Tidak dapat membaca jaringan lokal. Sambungkan ke Wi-Fi lalu coba lagi.');setScanning(false)"); return; }
        if (details.prefix < 16 || details.prefix > 29) { js("setStatus('Rentang jaringan tidak didukung untuk pemindaian otomatis.');setScanning(false)"); return; }
        final int hostCount = (1 << (32-details.prefix)) - 2;
        if (hostCount > 1022) { js("setStatus('Jaringan terlalu besar untuk dipindai dari aplikasi ini.');setScanning(false)"); return; }
        scanning = true;
        js("setNetwork(" + JSONObject.quote("IP perangkat: " + details.ip + "\nGateway: " + details.gateway + "\nSubnet: " + details.cidr) + ");setScanning(true);setStatus(" + JSONObject.quote("Memindai " + hostCount + " alamat di " + details.cidr + "…") + ")");
        final CountDownLatch latch = new CountDownLatch(hostCount);
        final List<Device> devices = Collections.synchronizedList(new ArrayList<>());
        final long started = System.currentTimeMillis();
        for (long h = details.network + 1; h < details.broadcast; h++) {
            final String ip = toIp(h);
            pool.execute(() -> {
                try {
                    String method = probe(ip);
                    if (method != null) {
                        String host = ip;
                        try { String n = InetAddress.getByName(ip).getCanonicalHostName(); if (n != null && !n.equals(ip)) host = n; } catch (Exception ignored) { }
                        devices.add(new Device(ip, host, method));
                    }
                } finally { latch.countDown(); }
            });
        }
        new Thread(() -> {
            try { latch.await(35, TimeUnit.SECONDS); } catch (InterruptedException ignored) { Thread.currentThread().interrupt(); }
            devices.sort((a,b) -> Long.compare(ipToLong(a.ip), ipToLong(b.ip)));
            JSONArray arr = new JSONArray();
            for (Device d : devices) {
                JSONObject o = new JSONObject();
                try { o.put("ip", d.ip); o.put("host", d.host); o.put("method", d.method); arr.put(o); } catch (Exception ignored) { }
            }
            long secs = (System.currentTimeMillis() - started) / 1000;
            String stamp = new SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault()).format(new Date());
            history.add(0, stamp + " — " + devices.size() + " perangkat (" + details.cidr + ")");
            if (history.size() > 10) history.remove(history.size()-1);
            getSharedPreferences("wifi_scope", MODE_PRIVATE).edit().putString("history", TextUtils.join("\n", history)).apply();
            js("setResults(" + arr.toString() + ");setHistory(" + JSONObject.quote(TextUtils.join("\n", history)) + ");setStatus(" + JSONObject.quote("Selesai dalam " + secs + " detik. Hasil bergantung pada perangkat yang merespons probe.") + ");setScanning(false)");
            scanning = false;
        }).start();
    }

    private String probe(String ip) {
        try { if (InetAddress.getByName(ip).isReachable(450)) return "ICMP / reachability"; } catch (Exception ignored) { }
        int[] ports = {80,443,22,445,8080,5555};
        for (int p : ports) try (Socket s = new Socket()) {
            s.connect(new InetSocketAddress(ip,p),180); return "TCP port " + p;
        } catch (Exception ignored) { }
        return null;
    }

    private NetworkDetails getNetworkDetails() {
        try {
            ConnectivityManager cm = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
            Network n = cm.getActiveNetwork(); if (n == null) return null;
            LinkProperties lp = cm.getLinkProperties(n); if (lp == null) return null;
            String gateway = "Tidak diketahui";
            for (RouteInfo r : lp.getRoutes()) if (r.isDefaultRoute() && r.getGateway() != null) { gateway = r.getGateway().getHostAddress(); break; }
            for (LinkAddress la : lp.getLinkAddresses()) {
                InetAddress a = la.getAddress();
                if (a instanceof Inet4Address && !a.isLoopbackAddress()) {
                    int prefix = la.getPrefixLength(); long ip = ipToLong(a.getHostAddress());
                    long mask = (prefix == 0) ? 0 : (0xffffffffL << (32-prefix)) & 0xffffffffL;
                    long net = ip & mask, broad = net | (~mask & 0xffffffffL);
                    return new NetworkDetails(a.getHostAddress(),prefix,net,broad,gateway,toIp(net)+"/"+prefix);
                }
            }
        } catch (Exception ignored) { }
        return null;
    }
    private void showHistory() {
        String saved = getSharedPreferences("wifi_scope", MODE_PRIVATE).getString("history", "");
        if (saved != null && !saved.isEmpty()) history.addAll(Arrays.asList(saved.split("\n")));
    }
    @Override public void onBackPressed() { if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed(); }
    @Override protected void onDestroy() { if (web != null) { web.removeJavascriptInterface("WifiScope"); web.destroy(); } pool.shutdownNow(); super.onDestroy(); }

    private static long ipToLong(String s) { try { String[] p=s.split("\\."); long v=0; for(String x:p) v=(v<<8)|Integer.parseInt(x); return v&0xffffffffL; } catch(Exception e) { return 0; } }
    private static String toIp(long v) { return ((v>>24)&255)+"."+((v>>16)&255)+"."+((v>>8)&255)+"."+(v&255); }
    private static class Device { String ip,host,method; Device(String i,String h,String m){ip=i;host=h;method=m;} }
    private static class NetworkDetails { String ip,gateway,cidr; int prefix; long network,broadcast; NetworkDetails(String i,int p,long n,long b,String g,String c){ip=i;prefix=p;network=n;broadcast=b;gateway=g;cidr=c;} }
}
