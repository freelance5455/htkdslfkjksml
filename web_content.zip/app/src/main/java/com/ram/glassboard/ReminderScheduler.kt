package com.ram.glassboard

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import org.json.JSONObject

object ReminderScheduler {
    private const val PREFS = "glassboard_reminders"
    private const val KEY_DATA = "data"

    fun schedule(context: Context, key: String, title: String, dueMillis: Long, intervalMinutes: Long, taskId: String, subtaskId: String) {
        if (dueMillis <= System.currentTimeMillis() || intervalMinutes <= 0) {
            cancel(context, key)
            return
        }
        val data = load(context)
        val entry = JSONObject().apply {
            put("key", key)
            put("title", title)
            put("dueMillis", dueMillis)
            put("intervalMinutes", intervalMinutes)
            put("taskId", taskId)
            put("subtaskId", subtaskId)
        }
        data.put(key, entry)
        save(context, data)
        scheduleNext(context, entry)
    }

    fun cancel(context: Context, key: String) {
        val data = load(context)
        data.remove(key)
        save(context, data)
        val pi = pendingIntent(context, key, null, PendingIntent.FLAG_NO_CREATE)
        if (pi != null) {
            alarmManager(context).cancel(pi)
            pi.cancel()
        }
    }

    fun rescheduleAll(context: Context) {
        val data = load(context)
        val iterator = data.keys()
        val now = System.currentTimeMillis()
        val toRemove = mutableListOf<String>()
        while (iterator.hasNext()) {
            val key = iterator.next()
            val entry = data.optJSONObject(key) ?: continue
            val due = entry.optLong("dueMillis", 0L)
            if (due <= now) toRemove.add(key) else scheduleNext(context, entry)
        }
        toRemove.forEach { data.remove(it) }
        save(context, data)
    }

    fun get(key: String, context: Context): JSONObject? = load(context).optJSONObject(key)

    fun scheduleNext(context: Context, entry: JSONObject) {
        val key = entry.optString("key")
        val due = entry.optLong("dueMillis", 0L)
        val interval = entry.optLong("intervalMinutes", 0L) * 60_000L
        if (key.isEmpty() || due <= 0L || interval <= 0L) return
        val now = System.currentTimeMillis()
        var trigger = due - interval
        if (trigger <= now) trigger = now + 1_000L
        if (trigger > due) trigger = due
        val pi = pendingIntent(context, key, null, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val alarm = alarmManager(context)
        alarm.cancel(pi)
        alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi)
    }

    fun alarmManager(context: Context) = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    fun pendingIntent(context: Context, key: String, extras: JSONObject?, flags: Int): PendingIntent {
        val intent = Intent(context, ReminderReceiver::class.java).apply {
            putExtra("key", key)
        }
        return PendingIntent.getBroadcast(context, stableRequestCode(key), intent, flags)
    }

    private fun stableRequestCode(key: String): Int = (key.hashCode() and 0x7fffffff)

    private fun load(context: Context): JSONObject {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_DATA, "{}") ?: "{}"
        return try { JSONObject(raw) } catch (_: Exception) { JSONObject() }
    }

    private fun save(context: Context, data: JSONObject) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_DATA, data.toString()).apply()
    }
}
