package com.ram.glassboard

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import org.json.JSONObject

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val key = intent.getStringExtra("key") ?: return
        val entry = ReminderScheduler.get(key, context) ?: return
        val due = entry.optLong("dueMillis", 0L)
        val now = System.currentTimeMillis()
        val taskId = entry.optString("taskId")
        val subtaskId = entry.optString("subtaskId")
        val title = entry.optString("title", "Glassboard reminder")

        val openIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra("taskId", taskId)
            putExtra("subtaskId", subtaskId)
        }
        val contentIntent = PendingIntent.getActivity(
            context,
            (key.hashCode() and 0x7fffffff),
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val text = if (now >= due) "Due now" else "Reminder to work on this task"
        if (android.os.Build.VERSION.SDK_INT < 33 || context.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            val notification = NotificationCompat.Builder(context, MainActivity.CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title)
                .setContentText(text)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setContentIntent(contentIntent)
                .build()
            NotificationManagerCompat.from(context).notify((key.hashCode() and 0x7fffffff), notification)
        }

        if (now >= due) {
            ReminderScheduler.cancel(context, key)
        } else {
            ReminderScheduler.scheduleNext(context, entry)
        }
    }
}
