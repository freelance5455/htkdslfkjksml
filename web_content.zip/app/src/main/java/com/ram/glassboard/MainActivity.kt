package com.ram.glassboard

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import java.util.UUID

class MainActivity : ComponentActivity() {
    private lateinit var webView: WebView
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private var pendingTaskId: String? = null
    private var pendingSubtaskId: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createNotificationChannel()
        captureNotificationIntent(intent)

        webView = WebView(this)
        setContentView(webView)
        configureWebView()
        webView.loadUrl("file:///android_asset/index.html")
    }

    private fun configureWebView() {
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = true
        webView.settings.mediaPlaybackRequiresUserGesture = false
        webView.settings.javaScriptCanOpenWindowsAutomatically = true
        webView.addJavascriptInterface(GlassboardBridge(this), "GlassboardNative")

        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePath: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                this@MainActivity.filePathCallback?.onReceiveValue(null)
                this@MainActivity.filePathCallback = filePath
                return try {
                    val intent = fileChooserParams?.createIntent() ?: Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "*/*"
                    }
                    intent.addCategory(Intent.CATEGORY_OPENABLE)
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST)
                    true
                } catch (e: Exception) {
                    this@MainActivity.filePathCallback?.onReceiveValue(null)
                    this@MainActivity.filePathCallback = null
                    false
                }
            }
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val url = request.url.toString()
                if (url.startsWith("https://") || url.startsWith("http://")) {
                    view.loadUrl(url)
                    return true
                }
                return false
            }

            override fun onPageFinished(view: WebView, url: String) {
                super.onPageFinished(view, url)
                val taskId = pendingTaskId
                if (!taskId.isNullOrEmpty()) {
                    val task = taskId.replace("'", "\\'")
                    val sub = (pendingSubtaskId ?: "").replace("'", "\\'")
                    view.evaluateJavascript("window.openTaskFromNotification('$task','$sub');", null)
                    pendingTaskId = null
                    pendingSubtaskId = null
                }
            }
        }
    }

    private fun captureNotificationIntent(intent: Intent?) {
        pendingTaskId = intent?.getStringExtra("taskId")
        pendingSubtaskId = intent?.getStringExtra("subtaskId")
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        captureNotificationIntent(intent)
        if (::webView.isInitialized && !pendingTaskId.isNullOrEmpty()) {
            val task = pendingTaskId!!.replace("'", "\\'")
            val sub = (pendingSubtaskId ?: "").replace("'", "\\'")
            webView.evaluateJavascript("window.openTaskFromNotification('$task','$sub');", null)
            pendingTaskId = null
            pendingSubtaskId = null
        }
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != FILE_CHOOSER_REQUEST) return
        val callback = filePathCallback ?: return
        val results = if (resultCode == RESULT_OK && data != null) {
            val clip = data.clipData
            if (clip != null) Array(clip.itemCount) { i -> clip.getItemAt(i).uri }
            else data.data?.let { arrayOf(it) }
        } else null
        callback.onReceiveValue(results)
        filePathCallback = null
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Glassboard reminders",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Task and sub-task reminders"
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    fun requestNotificationPermissionFromBridge() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), NOTIFICATION_PERMISSION_REQUEST)
        }
    }

    class GlassboardBridge(private val activity: MainActivity) {
        @JavascriptInterface
        fun requestNotificationPermission() = activity.requestNotificationPermissionFromBridge()

        @JavascriptInterface
        fun scheduleReminder(key: String, title: String, dueMillisString: String, intervalMinutesString: String, taskId: String, subtaskId: String) {
            ReminderScheduler.schedule(activity, key, title, dueMillisString.toLongOrNull() ?: return, intervalMinutesString.toLongOrNull() ?: return, taskId, subtaskId)
        }

        @JavascriptInterface
        fun cancelReminder(key: String) = ReminderScheduler.cancel(activity, key)
    }

    companion object {
        const val CHANNEL_ID = "glassboard_reminders"
        const val FILE_CHOOSER_REQUEST = 4101
        const val NOTIFICATION_PERMISSION_REQUEST = 4102
    }
}
