package com.bmstore.dailychecklist;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.content.FileProvider;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.webkit.WebViewAssetLoader;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public final class MainActivity extends Activity {
    private static final int PICK_PHOTOS = 101;
    private static final int CAMERA_PHOTO = 102;
    private WebView webView;
    private android.webkit.ValueCallback<Uri[]> uploadCallback;
    private Uri pendingCameraUri;

    private final Object shareLock = new Object();
    private final ArrayList<Uri> sharingUris = new ArrayList<>();
    private String sharingText = "";
    private File sharingFolder;
    private String shareError = null;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(16,42,59));
        getWindow().setNavigationBarColor(Color.rgb(16,42,59));
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.WHITE);
        ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(bars.left,bars.top,bars.right,bars.bottom);
            return insets;
        });
        webView = new WebView(this);
        root.addView(webView, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        webView.addJavascriptInterface(new NativeStoreBridge(), "NativeStore");
        final WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
        webView.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return !"appassets.androidplatform.net".equals(request.getUrl().getHost());
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view,
                    android.webkit.ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (uploadCallback != null) uploadCallback.onReceiveValue(null);
                uploadCallback = callback;
                boolean capture = params.isCaptureEnabled();
                try {
                    if (capture) {
                        File dir = new File(getCacheDir(), "captures");
                        if (!dir.exists() && !dir.mkdirs()) throw new IOException("Cannot create camera cache");
                        File photo = new File(dir,"capture_"+UUID.randomUUID()+".jpg");
                        pendingCameraUri = FileProvider.getUriForFile(MainActivity.this,
                            getPackageName()+".fileprovider",photo);
                        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                        intent.putExtra(MediaStore.EXTRA_OUTPUT, pendingCameraUri);
                        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                        intent.setClipData(ClipData.newUri(getContentResolver(),"Photo",pendingCameraUri));
                        startActivityForResult(intent,CAMERA_PHOTO);
                    } else {
                        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                        intent.setType("image/*");
                        intent.addCategory(Intent.CATEGORY_OPENABLE);
                        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);
                        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        startActivityForResult(Intent.createChooser(intent,"Pilih foto"), PICK_PHOTOS);
                    }
                    return true;
                } catch (Exception err) {
                    uploadCallback.onReceiveValue(null);
                    uploadCallback = null;
                    Toast.makeText(MainActivity.this,"Kamera/Galeri tidak tersedia",Toast.LENGTH_LONG).show();
                    return true;
                }
            }
        });
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html");
    }

    @Override protected void onActivityResult(int req, int result, Intent data) {
        super.onActivityResult(req,result,data);
        if (uploadCallback == null) return;
        Uri[] resultUris = null;
        if (result == RESULT_OK) {
            if (req == CAMERA_PHOTO && pendingCameraUri != null) {
                resultUris = new Uri[]{pendingCameraUri};
            } else if (req == PICK_PHOTOS && data != null) {
                ArrayList<Uri> list = new ArrayList<>();
                if (data.getClipData() != null) {
                    ClipData clip = data.getClipData();
                    for(int i=0;i<clip.getItemCount();i++) {
                        Uri u=clip.getItemAt(i).getUri();
                        if (u != null) list.add(u);
                    }
                } else if (data.getData() != null) list.add(data.getData());
                if (!list.isEmpty()) resultUris = list.toArray(new Uri[0]);
            }
        }
        uploadCallback.onReceiveValue(resultUris);
        uploadCallback = null;
        pendingCameraUri = null;
    }

    @Override public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    public class NativeStoreBridge {
        @JavascriptInterface public void copyText(String text) {
            runOnUiThread(() -> {
                ClipboardManager cm = (ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("Daily Store Checklist",text));
            });
        }
        @JavascriptInterface public void startShare(String reportText) {
            synchronized (shareLock) {
                sharingUris.clear();
                sharingText = reportText == null ? "" : reportText;
                sharingFolder = new File(new File(getCacheDir(),"share"), UUID.randomUUID().toString());
                shareError = null;
                if (!sharingFolder.mkdirs()) shareError = "Tidak dapat menyimpan foto sementara";
            }
        }
        @JavascriptInterface public void addPhoto(String base64,String filename) {
            synchronized (shareLock) {
                if (shareError != null) return;
                if (sharingUris.size() >= 30) return;
                if (base64 == null || base64.length()>8_000_000) { shareError="Ukuran foto terlalu besar"; return; }
                try {
                    byte[] bytes = android.util.Base64.decode(base64,android.util.Base64.DEFAULT);
                    File file = new File(sharingFolder,"photo_"+(sharingUris.size()+1)+".jpg");
                    try (FileOutputStream fos = new FileOutputStream(file)) { fos.write(bytes); }
                    Uri uri=FileProvider.getUriForFile(MainActivity.this,getPackageName()+".fileprovider",file);
                    sharingUris.add(uri);
                } catch(Exception e){shareError="Gagal memproses foto";}
            }
        }
        @JavascriptInterface public void finishShare() {
            final ArrayList<Uri> uris;
            final String text;
            final String error;
            synchronized (shareLock) {
                uris=new ArrayList<>(sharingUris);
                text=sharingText;
                error=shareError;
            }
            runOnUiThread(()->{
                if(error != null){Toast.makeText(MainActivity.this,error,Toast.LENGTH_LONG).show();return;}
                Intent outgoing;
                if(uris.isEmpty()) {
                    outgoing=new Intent(Intent.ACTION_SEND);
                    outgoing.setType("text/plain");
                } else if(uris.size()==1){
                    outgoing=new Intent(Intent.ACTION_SEND);
                    outgoing.setType("image/jpeg");
                    outgoing.putExtra(Intent.EXTRA_STREAM,uris.get(0));
                } else {
                    outgoing=new Intent(Intent.ACTION_SEND_MULTIPLE);
                    outgoing.setType("image/*");
                    outgoing.putParcelableArrayListExtra(Intent.EXTRA_STREAM,uris);
                }
                outgoing.putExtra(Intent.EXTRA_TEXT,text);
                if (!uris.isEmpty()) {
                    ClipData clip=ClipData.newUri(getContentResolver(),"Store evidence",uris.get(0));
                    for(int i=1;i<uris.size();i++)clip.addItem(new ClipData.Item(uris.get(i)));
                    outgoing.setClipData(clip);
                    outgoing.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                }
                try{startActivity(Intent.createChooser(outgoing,"Bagikan laporan"));}
                catch(Exception e){Toast.makeText(MainActivity.this,"Aplikasi berbagi tidak tersedia",Toast.LENGTH_LONG).show();}
            });
        }
    }
}
