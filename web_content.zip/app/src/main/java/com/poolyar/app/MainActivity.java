package com.poolyar.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.webkit.JavascriptInterface;
import android.content.Intent;
import android.net.Uri;
import android.database.Cursor;
import android.provider.OpenableColumns;
import android.content.ContentValues;
import android.os.Environment;
import android.widget.Toast;
import android.util.Base64;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient.FileChooserParams;
import android.view.Window;
import android.view.WindowManager;
import android.graphics.Color;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private static final int FILE_CHOOSER = 2201;
    private static final int DRIVE_CREATE = 2202;
    private static final int DRIVE_FOLDER = 2203;
    private static final String PREFS = "poolyar_backup_prefs";
    private static final String FOLDER_URI = "backup_folder_uri";
    private byte[] pendingDriveBytes;
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(16,75,61));
        getWindow().setNavigationBarColor(Color.rgb(16,75,61));
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(243,246,244));
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setDatabaseEnabled(true);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                try { startActivityForResult(intent, FILE_CHOOSER); return true; }
                catch (Exception ex) { fileCallback = null; return false; }
            }
        });
        webView.addJavascriptInterface(new Object() {
            @JavascriptInterface public void saveToDrive(String filename, String mime, String base64) {
                runOnUiThread(() -> {
                    try {
                        if (base64 == null || base64.trim().isEmpty()) throw new IllegalArgumentException("empty backup");
                        pendingDriveBytes = Base64.decode(base64, Base64.DEFAULT);
                        if (pendingDriveBytes.length == 0) throw new IllegalArgumentException("empty backup");
                        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                        intent.addCategory(Intent.CATEGORY_OPENABLE);
                        intent.setType((mime == null || mime.isEmpty()) ? "application/json" : mime);
                        intent.putExtra(Intent.EXTRA_TITLE, (filename == null || filename.isEmpty()) ? "poolyar-backup.json" : filename);
                        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                        startActivityForResult(Intent.createChooser(intent, "انتخاب محل ذخیرهٔ نسخهٔ پشتیبان"), DRIVE_CREATE);
                    } catch (Exception ex) {
                        pendingDriveBytes = null;
                        Toast.makeText(MainActivity.this, "بازکردن پنجرهٔ ذخیره ناموفق بود: " + ex.getMessage(), Toast.LENGTH_LONG).show();
                        if (webView != null) webView.evaluateJavascript("if(window.poolyarDriveResult)window.poolyarDriveResult(false,'بازکردن محل ذخیره ناموفق بود')", null);
                    }
                });
            }
            @JavascriptInterface public void chooseBackupFolder() {
                runOnUiThread(() -> {
                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                    try { startActivityForResult(intent, DRIVE_FOLDER); }
                    catch (Exception ex) { Toast.makeText(MainActivity.this, "انتخاب پوشه پشتیبان در دسترس نیست", Toast.LENGTH_LONG).show(); }
                });
            }
            @JavascriptInterface public void restoreBackupFromSelectedFolder() {
                runOnUiThread(() -> restoreLatestFromSelectedFolder());
            }
            @JavascriptInterface public void saveLocalBackup(String json) {
                try {
                    if (json == null || json.trim().isEmpty()) return;
                    byte[] bytes = json.getBytes(java.nio.charset.StandardCharsets.UTF_8);
                    if (bytes.length > 10 * 1024 * 1024) throw new IllegalArgumentException("backup too large");
                    java.io.File dir = new java.io.File(getFilesDir(), "backups");
                    if (!dir.exists() && !dir.mkdirs()) throw new java.io.IOException("cannot create backup directory");
                    java.io.File target = new java.io.File(dir, "poolyar-latest.json");
                    java.io.File temp = new java.io.File(dir, "poolyar-latest.tmp");
                    try (java.io.FileOutputStream out = new java.io.FileOutputStream(temp)) {
                        out.write(bytes);
                        out.getFD().sync();
                    }
                    if (target.exists() && !target.delete()) throw new java.io.IOException("cannot replace backup");
                    if (!temp.renameTo(target)) throw new java.io.IOException("cannot finalize backup");
                    // Keep up to 10 dated snapshots for recovery from accidental changes.
                    String stamp = new java.text.SimpleDateFormat("yyyyMMdd-HHmmss", java.util.Locale.US).format(new java.util.Date());
                    java.io.File snapshot = new java.io.File(dir, "poolyar-" + stamp + ".json");
                    try (java.io.FileOutputStream out = new java.io.FileOutputStream(snapshot)) {
                        out.write(bytes);
                        out.getFD().sync();
                    }
                    java.io.File[] files = dir.listFiles((d, name) -> name.startsWith("poolyar-") && name.endsWith(".json") && !name.equals("poolyar-latest.json"));
                    if (files != null && files.length > 10) {
                        java.util.Arrays.sort(files, (a, b) -> Long.compare(a.lastModified(), b.lastModified()));
                        for (int i = 0; i < files.length - 10; i++) files[i].delete();
                    }
                    writeBackupToSelectedFolder(bytes);
                } catch (Exception ex) {
                    android.util.Log.e("PoolYarBackup", "Local backup failed", ex);
                }
            }

            @JavascriptInterface public void saveFile(String filename, String mime, String base64) {
                runOnUiThread(() -> {
                    try {
                        byte[] data = Base64.decode(base64, Base64.DEFAULT);
                        android.content.ContentResolver resolver = getContentResolver();
                        ContentValues values = new ContentValues();
                        values.put(android.provider.MediaStore.Downloads.DISPLAY_NAME, filename);
                        values.put(android.provider.MediaStore.Downloads.MIME_TYPE, mime);
                        if (android.os.Build.VERSION.SDK_INT >= 29) {
                            values.put(android.provider.MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                            Uri uri = resolver.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                            if (uri != null) {
                                try (java.io.OutputStream out = resolver.openOutputStream(uri)) {
                                    if (out == null) throw new java.io.IOException("Cannot open output stream");
                                    out.write(data);
                                    out.flush();
                                }
                                Toast.makeText(MainActivity.this, "نسخه پشتیبان در پوشه دانلود ذخیره شد", Toast.LENGTH_LONG).show();
                            } else {
                                Toast.makeText(MainActivity.this, "ساخت فایل پشتیبان ناموفق بود", Toast.LENGTH_LONG).show();
                            }
                        } else {
                            Toast.makeText(MainActivity.this, "ذخیرهٔ پشتیبان در این نسخهٔ اندروید پشتیبانی نمی‌شود", Toast.LENGTH_LONG).show();
                        }
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this, "ذخیره فایل انجام نشد", Toast.LENGTH_LONG).show();
                    }
                });
            }
        }, "PoolYarAndroid");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }
    private void restoreLatestFromSelectedFolder() {
        String saved = getSharedPreferences(PREFS, MODE_PRIVATE).getString(FOLDER_URI, null);
        if (saved == null) {
            Toast.makeText(this, "ابتدا پوشهٔ PoolYar Backups را انتخاب کن.", Toast.LENGTH_LONG).show();
            return;
        }
        try {
            Uri tree = Uri.parse(saved);
            String treeId = android.provider.DocumentsContract.getTreeDocumentId(tree);
            Uri children = android.provider.DocumentsContract.buildChildDocumentsUriUsingTree(tree, treeId);
            String[] projection = { android.provider.DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                    android.provider.DocumentsContract.Document.COLUMN_DISPLAY_NAME };
            Uri latest = null;
            Uri newestDated = null;
            long newestModified = Long.MIN_VALUE;
            try (Cursor cursor = getContentResolver().query(children, projection, null, null, null)) {
                if (cursor != null) {
                    int idCol = cursor.getColumnIndex(android.provider.DocumentsContract.Document.COLUMN_DOCUMENT_ID);
                    int nameCol = cursor.getColumnIndex(android.provider.DocumentsContract.Document.COLUMN_DISPLAY_NAME);
                    while (cursor.moveToNext()) {
                        String name = cursor.getString(nameCol);
                        String id = cursor.getString(idCol);
                        Uri doc = android.provider.DocumentsContract.buildDocumentUriUsingTree(tree, id);
                        if ("poolyar-latest.json".equals(name)) { latest = doc; break; }
                        if (name != null && name.matches("poolyar-\\d{8}\\.json")) {
                            long modified = 0;
                            try (Cursor meta = getContentResolver().query(doc,
                                    new String[]{android.provider.DocumentsContract.Document.COLUMN_LAST_MODIFIED}, null, null, null)) {
                                if (meta != null && meta.moveToFirst()) modified = meta.getLong(0);
                            }
                            if (modified > newestModified) { newestModified = modified; newestDated = doc; }
                        }
                    }
                }
            }
            Uri selected = latest != null ? latest : newestDated;
            if (selected == null) throw new java.io.FileNotFoundException("No PoolYar backup found");
            byte[] bytes;
            try (java.io.InputStream in = getContentResolver().openInputStream(selected);
                 java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream()) {
                if (in == null) throw new java.io.IOException("Cannot open backup");
                byte[] buffer = new byte[8192]; int count; int total = 0;
                while ((count = in.read(buffer)) != -1) {
                    total += count; if (total > 10 * 1024 * 1024) throw new java.io.IOException("Backup too large");
                    out.write(buffer, 0, count);
                }
                bytes = out.toByteArray();
            }
            String encoded = Base64.encodeToString(bytes, Base64.NO_WRAP);
            webView.evaluateJavascript("if(window.poolyarReceiveBackup)window.poolyarReceiveBackup('" + encoded + "')", null);
        } catch (Exception e) {
            android.util.Log.e("PoolYarBackup", "Restore from selected folder failed", e);
            Toast.makeText(this, "خواندن پشتیبان از پوشه ناموفق بود. دسترسی پوشه را دوباره بررسی کن.", Toast.LENGTH_LONG).show();
        }
    }

    private void writeBackupToSelectedFolder(byte[] bytes) {
        String saved = getSharedPreferences(PREFS, MODE_PRIVATE).getString(FOLDER_URI, null);
        if (saved == null) return;
        Uri tree = Uri.parse(saved);
        try {
            String documentId = android.provider.DocumentsContract.getTreeDocumentId(tree);
            Uri parent = android.provider.DocumentsContract.buildDocumentUriUsingTree(tree, documentId);
            // Keep one continuously updated latest file instead of creating a new cloud file
            // after every small edit. Also keep one dated snapshot per day.
            writeNamedBackup(parent, "poolyar-latest.json", bytes);
            String day = new java.text.SimpleDateFormat("yyyyMMdd", java.util.Locale.US).format(new java.util.Date());
            writeNamedBackup(parent, "poolyar-" + day + ".json", bytes);
        } catch (Exception e) {
            android.util.Log.e("PoolYarBackup", "Selected-folder backup failed", e);
            runOnUiThread(() -> Toast.makeText(this, "پشتیبان محلی ذخیره شد؛ ذخیره در پوشهٔ انتخاب‌شده ناموفق بود. پوشه را دوباره انتخاب کن.", Toast.LENGTH_LONG).show());
        }
    }

    private void writeNamedBackup(Uri parent, String name, byte[] bytes) throws Exception {
        android.net.Uri existing = null;
        Uri children = android.provider.DocumentsContract.buildChildDocumentsUriUsingTree(
                Uri.parse(getSharedPreferences(PREFS, MODE_PRIVATE).getString(FOLDER_URI, "")),
                android.provider.DocumentsContract.getDocumentId(parent));
        String[] projection = { android.provider.DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                android.provider.DocumentsContract.Document.COLUMN_DISPLAY_NAME };
        try (android.database.Cursor cursor = getContentResolver().query(children, projection, null, null, null)) {
            if (cursor != null) {
                int idCol = cursor.getColumnIndex(android.provider.DocumentsContract.Document.COLUMN_DOCUMENT_ID);
                int nameCol = cursor.getColumnIndex(android.provider.DocumentsContract.Document.COLUMN_DISPLAY_NAME);
                while (cursor.moveToNext()) {
                    if (name.equals(cursor.getString(nameCol))) {
                        existing = android.provider.DocumentsContract.buildDocumentUriUsingTree(
                                Uri.parse(getSharedPreferences(PREFS, MODE_PRIVATE).getString(FOLDER_URI, "")), cursor.getString(idCol));
                        break;
                    }
                }
            }
        }
        if (existing != null) android.provider.DocumentsContract.deleteDocument(getContentResolver(), existing);
        Uri created = android.provider.DocumentsContract.createDocument(getContentResolver(), parent, "application/json", name);
        if (created == null) throw new java.io.IOException("Cannot create " + name);
        try (java.io.OutputStream out = getContentResolver().openOutputStream(created, "w")) {
            if (out == null) throw new java.io.IOException("Cannot open " + name);
            out.write(bytes);
            out.flush();
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == DRIVE_FOLDER) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                Uri tree = data.getData();
                try {
                    int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                    getContentResolver().takePersistableUriPermission(tree, flags);
                    getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(FOLDER_URI, tree.toString()).apply();
                    Toast.makeText(this, "پوشهٔ پشتیبان انتخاب شد. از این پس نسخه‌های پشتیبان جدید در آن ذخیره می‌شوند.", Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    Toast.makeText(this, "ذخیرهٔ دسترسی پوشه ناموفق بود؛ دوباره انتخاب کن.", Toast.LENGTH_LONG).show();
                }
            }
        }
        if (requestCode == FILE_CHOOSER && fileCallback != null) {
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null) results = new Uri[]{data.getData()};
            fileCallback.onReceiveValue(results);
            fileCallback = null;
        }
        if (requestCode == DRIVE_CREATE) {
            boolean saved = false;
            String message = "ذخیرهٔ نسخهٔ پشتیبان لغو شد";
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingDriveBytes != null) {
                try (java.io.OutputStream out = getContentResolver().openOutputStream(data.getData(), "w")) {
                    if (out == null) throw new java.io.IOException("Cannot open destination");
                    out.write(pendingDriveBytes);
                    out.flush();
                    saved = true;
                    message = "نسخهٔ پشتیبان با موفقیت ذخیره شد";
                    Toast.makeText(this, message, Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    message = "ذخیرهٔ نسخهٔ پشتیبان ناموفق بود: " + e.getMessage();
                    Toast.makeText(this, message, Toast.LENGTH_LONG).show();
                }
            } else {
                Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
            }
            pendingDriveBytes = null;
            final boolean result = saved;
            final String resultMessage = message;
            if (webView != null) webView.post(() -> webView.evaluateJavascript(
                "if(window.poolyarDriveResult)window.poolyarDriveResult(" + result + "," + org.json.JSONObject.quote(resultMessage) + ")", null));
        }
    }
    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
