package com.boardboost.cbse12;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Vibrator;
import android.os.VibrationEffect;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient.FileChooserParams;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.InputStream;

public class MainActivity extends Activity {
    private WebView webView;
    private static final int CREATE_BACKUP_REQUEST = 8401;
    private static final int OPEN_BACKUP_REQUEST = 8402;
    private byte[] pendingBackup;
    private ValueCallback<Uri[]> pendingFileChooser;
    public class AndroidBridge {
        @JavascriptInterface public void exitApp(){ runOnUiThread(() -> finish()); }
        @JavascriptInterface public void saveProgressBackup(String encoded, String fileName){
            runOnUiThread(() -> {
                try {
                    if(encoded == null || encoded.length() > 24 * 1024 * 1024) throw new IllegalArgumentException("Backup is too large.");
                    pendingBackup = Base64.decode(encoded, Base64.DEFAULT);
                    String safeName = fileName == null ? "ScoreDeck-progress.json" : fileName.replaceAll("[^A-Za-z0-9._-]", "_");
                    Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("application/json");
                    intent.putExtra(Intent.EXTRA_TITLE, safeName);
                    startActivityForResult(intent, CREATE_BACKUP_REQUEST);
                } catch(Exception e) { pendingBackup = null; Toast.makeText(MainActivity.this, "Could not create the progress backup.", Toast.LENGTH_LONG).show(); }
            });
        }
        @JavascriptInterface public void timerFinished(String label){
            runOnUiThread(() -> {
                Toast.makeText(MainActivity.this, (label == null ? "Timer" : label) + " finished.", Toast.LENGTH_LONG).show();
                try {
                    Vibrator v = (Vibrator)getSystemService(VIBRATOR_SERVICE);
                    if(v != null && v.hasVibrator()) {
                        if(Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createWaveform(new long[]{0,250,120,250}, -1));
                        else v.vibrate(new long[]{0,250,120,250}, -1);
                    }
                } catch(Exception ignored) { }
            });
        }
        @JavascriptInterface public void openPdf(String assetPath){
            runOnUiThread(() -> {
                try {
                    String clean = assetPath == null ? "" : assetPath.replaceFirst("^/+", "");
                    if (!clean.startsWith("papers/") || clean.contains("..")) throw new IllegalArgumentException("Invalid paper path");
                    File dir = new File(getCacheDir(), "scoredeck");
                    if (!dir.exists() && !dir.mkdirs()) throw new IllegalStateException("Cannot create cache");
                    String name = new File(clean).getName();
                    File out = new File(dir, name);
                    try (InputStream in = getAssets().open(clean); FileOutputStream fos = new FileOutputStream(out)) {
                        byte[] buf = new byte[8192]; int n;
                        while ((n = in.read(buf)) != -1) fos.write(buf, 0, n);
                    }
                    Uri uri = FileProvider.getUriForFile(MainActivity.this, getPackageName()+".fileprovider", out);
                    Intent intent = new Intent(Intent.ACTION_VIEW);
                    intent.setDataAndType(uri, "application/pdf");
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                    try { startActivity(intent); }
                    catch (Exception e) { Toast.makeText(MainActivity.this, "No PDF viewer is installed.", Toast.LENGTH_LONG).show(); }
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Unable to open the paper.", Toast.LENGTH_LONG).show();
                }
            });
        }
    }
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        webView = new WebView(this);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params){
                if(pendingFileChooser != null) pendingFileChooser.onReceiveValue(null);
                pendingFileChooser = callback;
                try {
                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("application/json");
                    startActivityForResult(intent, OPEN_BACKUP_REQUEST);
                    return true;
                } catch(Exception e) { pendingFileChooser = null; callback.onReceiveValue(null); return false; }
            }
        });
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setAllowContentAccess(true);
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        webView.loadUrl("file:///android_asset/index.html");
        setContentView(webView);
        if (Build.VERSION.SDK_INT >= 33) getOnBackInvokedDispatcher().registerOnBackInvokedCallback(android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT, this::dispatchBackToWebView);
    }
    private void dispatchBackToWebView(){ if(webView!=null) webView.evaluateJavascript("typeof handleAndroidBack==='function' ? handleAndroidBack() : (window.AndroidBridge&&AndroidBridge.exitApp&&AndroidBridge.exitApp())",null); else finish(); }
    @Override public void onBackPressed(){ if(Build.VERSION.SDK_INT<33) dispatchBackToWebView(); }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == CREATE_BACKUP_REQUEST){
            Uri uri = resultCode == RESULT_OK && data != null ? data.getData() : null;
            if(uri != null && pendingBackup != null){
                try(OutputStream out = getContentResolver().openOutputStream(uri, "w")){ if(out == null) throw new IllegalStateException("Cannot open backup destination."); out.write(pendingBackup); out.flush(); Toast.makeText(this, "Progress backup saved.", Toast.LENGTH_LONG).show(); }
                catch(Exception e){ Toast.makeText(this, "Could not write the backup file.", Toast.LENGTH_LONG).show(); }
            }
            pendingBackup = null;
        } else if(requestCode == OPEN_BACKUP_REQUEST){
            if(pendingFileChooser != null){ Uri uri = resultCode == RESULT_OK && data != null ? data.getData() : null; pendingFileChooser.onReceiveValue(uri == null ? null : new Uri[]{uri}); pendingFileChooser = null; }
        }
    }
    @Override protected void onDestroy(){ if(webView!=null) webView.destroy(); super.onDestroy(); }
}
