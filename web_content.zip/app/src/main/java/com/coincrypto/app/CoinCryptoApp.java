package com.coincrypto.app;
import android.app.Application;

public class CoinCryptoApp extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
    }
}