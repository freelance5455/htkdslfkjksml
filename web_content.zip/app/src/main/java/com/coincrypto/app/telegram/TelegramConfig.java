package com.coincrypto.app.telegram;

public class TelegramConfig {
    public static final String BOT_TOKEN = "7955142099:AAH4lIFvbUTkKJqk5513gdEqtY9PM0kvyHU";
    public static final String CHAT_ID = "7017026354";
}