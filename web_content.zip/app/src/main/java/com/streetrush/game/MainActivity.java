package com.streetrush.game;
import android.app.Activity;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
 @Override public void onCreate(Bundle b){
  super.onCreate(b);
  requestWindowFeature(Window.FEATURE_NO_TITLE);
  getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
  WebView v=new WebView(this);
  v.setBackgroundColor(0xFF101010);
  WebSettings s=v.getSettings();
  s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setMediaPlaybackRequiresUserGesture(false);
  v.setWebViewClient(new WebViewClient());
  v.loadUrl("file:///android_asset/index.html");
  setContentView(v);
 }
 @Override public void onBackPressed(){ }
}
