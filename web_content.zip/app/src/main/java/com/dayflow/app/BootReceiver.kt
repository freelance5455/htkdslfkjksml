package com.dayflow.app

import android.content.*

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val json = context.getSharedPreferences("dayflow", Context.MODE_PRIVATE).getString("latest_schedule", null) ?: return
        try { AlarmScheduler.sync(context, org.json.JSONObject(json)) } catch (_: Exception) {}
    }
}
