package com.dayflow.app

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getIntExtra("id", -1)
        if (id < 0) return
        val name = intent.getStringExtra("name") ?: "Your activity"
        val day = intent.getStringExtra("day") ?: ""
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(NotificationChannel("dayflow_reminders", "DayFlow reminders", NotificationManager.IMPORTANCE_HIGH))
        }
        fun action(action: String, request: Int): PendingIntent {
            val i = Intent(context, ActionReceiver::class.java).setAction(action)
                .putExtra("id", id).putExtra("day", day).putExtra("name", name)
            return PendingIntent.getBroadcast(context, request, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        }
        val notification = NotificationCompat.Builder(context, "dayflow_reminders")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("It's time: $name")
            .setContentText("DayFlow · It's study time")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .addAction(0, "Complete", action("COMPLETE", id * 10 + 1))
            .addAction(0, "Snooze 5 min", action("SNOOZE", id * 10 + 3))
            .addAction(0, "Dismiss", action("DISMISS", id * 10 + 2))
            .build()
        manager.notify(id, notification)
        // Rebuild the next daily occurrence after this reminder fires.
        val saved = context.getSharedPreferences("dayflow", Context.MODE_PRIVATE)
            .getString("latest_schedule", null)
        if (saved != null) {
            try { AlarmScheduler.sync(context, org.json.JSONObject(saved)) } catch (_: Exception) { }
        }
    }
}
