package com.dayflow.app

import android.app.AlarmManager
import android.app.BroadcastReceiver
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject

class ActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getIntExtra("id", -1)
        if (id < 0) return
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.cancel(id)
        when (intent.action) {
            "COMPLETE" -> {
                val prefs = context.getSharedPreferences("dayflow", Context.MODE_PRIVATE)
                val queue = try { JSONArray(prefs.getString("pending_completions", "[]")) } catch (_: Exception) { JSONArray() }
                queue.put(JSONObject().put("id", id).put("day", intent.getStringExtra("day") ?: ""))
                prefs.edit().putString("pending_completions", queue.toString()).apply()
            }
            "SNOOZE" -> {
                val i = Intent(context, AlarmReceiver::class.java)
                    .putExtra("id", id)
                    .putExtra("name", intent.getStringExtra("name") ?: "Your activity")
                    .putExtra("day", intent.getStringExtra("day") ?: "")
                val pi = PendingIntent.getBroadcast(context, id, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
                val at = System.currentTimeMillis() + 5 * 60 * 1000L
                if (Build.VERSION.SDK_INT >= 23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
                else am.setExact(AlarmManager.RTC_WAKEUP, at, pi)
            }
        }
    }
}
