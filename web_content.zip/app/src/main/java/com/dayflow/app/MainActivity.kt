package com.dayflow.app

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.core.app.ActivityCompat
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var web: WebView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 41)
        }
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(NativeBridge(this), "DayFlowNative")
        web.webViewClient = WebViewClient()
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    inner class NativeBridge(private val activity: Activity) {
        @JavascriptInterface fun syncTasks(payload: String) {
            try { AlarmScheduler.sync(activity, JSONObject(payload)) } catch (_: Exception) { }
        }
        @JavascriptInterface fun getPendingCompletions(): String {
            val prefs = activity.getSharedPreferences("dayflow", MODE_PRIVATE)
            return prefs.getString("pending_completions", "[]") ?: "[]"
        }
        @JavascriptInterface fun clearPendingCompletions() {
            activity.getSharedPreferences("dayflow", MODE_PRIVATE).edit().remove("pending_completions").apply()
        }
        @JavascriptInterface fun requestExactAlarmAccess() {
            if (Build.VERSION.SDK_INT >= 31) {
                val manager = activity.getSystemService(ALARM_SERVICE) as android.app.AlarmManager
                if (!manager.canScheduleExactAlarms()) {
                    val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                        Uri.parse("package:" + activity.packageName))
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    activity.startActivity(intent)
                }
            }
        }
    }
}
