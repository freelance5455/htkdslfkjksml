package com.dayflow.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

object AlarmScheduler {
    fun sync(ctx: Context, data: JSONObject) {
        val manager = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val prefs = ctx.getSharedPreferences("dayflow", Context.MODE_PRIVATE)
        val oldIds = try { prefs.getString("scheduled_ids", "")!!.split(",").filter { it.isNotBlank() }.map { it.toInt() } } catch (_: Exception) { emptyList() }
        oldIds.forEach { id ->
            val oldIntent = Intent(ctx, AlarmReceiver::class.java)
            val oldPi = PendingIntent.getBroadcast(ctx, id, oldIntent, PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE)
            if (oldPi != null) manager.cancel(oldPi)
        }

        val tasks = data.optJSONArray("tasks") ?: return
        val newIds = mutableListOf<Int>()
        prefs.edit().putString("latest_schedule", data.toString()).apply()
        if (!data.optBoolean("enabled")) {
            prefs.edit().putString("scheduled_ids", "").apply()
            return
        }
        if (Build.VERSION.SDK_INT >= 31 && !manager.canScheduleExactAlarms()) return

        for (i in 0 until tasks.length()) {
            val task = tasks.optJSONObject(i) ?: continue
            if (!task.optBoolean("reminder")) continue
            val id = task.optInt("id", -1)
            if (id < 0) continue
            val parts = task.optString("start").split(":")
            if (parts.size != 2) continue
            val hour = parts[0].toIntOrNull() ?: continue
            val minute = parts[1].toIntOrNull() ?: continue
            if (hour !in 0..23 || minute !in 0..59) continue
            val cal = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, hour)
                set(Calendar.MINUTE, minute)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
                if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
            }
            val day = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time)
            val alarmIntent = Intent(ctx, AlarmReceiver::class.java)
                .putExtra("id", id).putExtra("name", task.optString("name", "Your activity"))
                .putExtra("day", day)
            val pi = PendingIntent.getBroadcast(ctx, id, alarmIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            try {
                if (Build.VERSION.SDK_INT >= 23) manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
                else manager.setExact(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
                newIds.add(id)
            } catch (_: SecurityException) { }
        }
        prefs.edit().putString("scheduled_ids", newIds.joinToString(",")).apply()
    }
}
