package com.vitorio.jarvis
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class SettingsActivity:androidx.appcompat.app.AppCompatActivity(){
    override fun onCreate(b:Bundle?){
        super.onCreate(b)
        val l=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(25,30,25,20)}
        l.addView(TextView(this).apply{text="JARVIS • Configurações";textSize=25f})
        l.addView(TextView(this).apply{text="\nPermissões e módulos";textSize=18f})
        val a=Button(this).apply{text="🖱 Ativar controle de interface";setOnClickListener{startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))}}
        val d=Button(this).apply{text="🎨 Abrir desenho";setOnClickListener{startActivity(Intent(this@SettingsActivity,DrawingActivity::class.java))}}
        val n=Button(this).apply{text="🔔 Configurações de notificações";setOnClickListener{startActivity(Intent("android.settings.APP_NOTIFICATION_SETTINGS").putExtra("android.provider.extra.APP_PACKAGE",packageName))}}
        val info=TextView(this).apply{
            text="\nSegurança:\n• Ações potencialmente sensíveis devem pedir confirmação.\n• O JARVIS não deve esconder atividades do usuário.\n• Chaves de APIs nunca devem ficar hardcoded no APK.\n• Acessibilidade só funciona depois de você conceder o acesso nas configurações do Android."
            textSize=15f
        }
        l.addView(a);l.addView(d);l.addView(n);l.addView(info)
        setContentView(l)
    }
}
