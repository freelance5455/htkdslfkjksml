package com.vitorio.jarvis
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class JarvisMemory(ctx: Context) {
    private val prefs=ctx.getSharedPreferences("jarvis_memory",Context.MODE_PRIVATE)
    fun add(role:String,text:String) {
        val a=JSONArray(prefs.getString("history","[]"))
        a.put(JSONObject().put("role",role).put("text",text).put("time",System.currentTimeMillis()))
        while(a.length()>200) a.remove(0)
        prefs.edit().putString("history",a.toString()).apply()
    }
    fun history(): List<String> {
        val a=JSONArray(prefs.getString("history","[]"))
        return (0 until a.length()).map { "${a.getJSONObject(it).optString("role")}: ${a.getJSONObject(it).optString("text")}" }
    }
    fun clear(){prefs.edit().remove("history").apply()}
}
