package com.vitorio.jarvis

import android.content.*
import android.net.Uri
import android.provider.Settings
import java.util.Locale

class JarvisEngine(private val activity:MainActivity, private val memory:JarvisMemory) {
    data class Result(val text:String,val speak:Boolean=true)

    fun execute(raw:String):Result {
        val cmd=raw.trim()
        if(cmd.isEmpty()) return Result("Diga um comando.")
        memory.add("Você",cmd)
        val c=cmd.lowercase(Locale.getDefault())

        val result=when {
            c=="ajuda" || c.contains("o que você pode fazer") ->
                Result("Posso abrir aplicativos, pesquisar na web, preparar e-mail, abrir configurações, controlar a navegação, falar respostas, guardar histórico, desenhar e executar plugins. Ações sensíveis pedem confirmação.")

            c=="voltar" -> { JarvisAccessibilityService.instance?.back(); Result("Voltando.") }
            c=="ir para tela inicial" || c=="home" -> { JarvisAccessibilityService.instance?.home(); Result("Tela inicial.") }
            c=="aplicativos recentes" -> { JarvisAccessibilityService.instance?.recent(); Result("Abrindo aplicativos recentes.") }

            c.startsWith("abrir ") -> openApp(c.removePrefix("abrir ").trim())
            c.startsWith("pesquisar ") -> webSearch(cmd.removePrefix("pesquisar ").trim())
            c.startsWith("buscar ") -> webSearch(cmd.removePrefix("buscar ").trim())
            c.contains("configurações") || c.contains("configuracoes") -> {
                activity.startActivity(Intent(Settings.ACTION_SETTINGS)); Result("Abrindo as configurações.")
            }
            c.contains("acessibilidade") -> {
                activity.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                Result("Abra o serviço JARVIS e conceda a permissão.")
            }
            c.contains("desenhar") -> {
                activity.startActivity(Intent(activity,DrawingActivity::class.java)); Result("Abrindo o quadro.")
            }
            c.contains("enviar email") || c.contains("enviar e-mail") || c.contains("mandar email") -> {
                activity.startActivity(Intent.createChooser(Intent(Intent.ACTION_SENDTO,Uri.parse("mailto:")),"Escolha o app de e-mail"))
                Result("Preparei a abertura do seu aplicativo de e-mail. O envio final fica sob seu controle.")
            }
            c.startsWith("clicar ") -> {
                val target=c.removePrefix("clicar ").trim()
                val ok=JarvisAccessibilityService.instance?.clickText(target)==true
                Result(if(ok)"Cliquei em \"$target\"." else "Não encontrei \"$target\" na tela atual.")
            }
            c.contains("limpar memória") -> {memory.clear();Result("Histórico local apagado.")}
            c=="status" -> Result("Núcleo online. Acessibilidade: ${if(JarvisAccessibilityService.instance!=null)"ativa" else "inativa"}. Memória local disponível.")
            else -> Result("Entendi: \"$cmd\". Para respostas de conhecimento realmente generativas, conecte um modelo de IA ao AI Gateway deste projeto. Eu não vou fingir que tenho uma IA remota embutida quando ela não está conectada.")
        }
        memory.add("JARVIS",result.text)
        return result
    }

    private fun webSearch(q:String):Result {
        activity.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://www.google.com/search?q="+Uri.encode(q))))
        return Result("Pesquisando \"$q\".")
    }

    private fun openApp(name:String):Result {
        val pm=activity.packageManager
        val apps=pm.getInstalledApplications(0)
        val match=apps.firstOrNull{
            val label=pm.getApplicationLabel(it).toString().lowercase()
            label==name || label.contains(name)
        }
        if(match!=null){
            val i=pm.getLaunchIntentForPackage(match.packageName)
            if(i!=null){activity.startActivity(i);return Result("Abrindo ${pm.getApplicationLabel(match)}.")}
        }
        return Result("Não encontrei um aplicativo instalado chamado \"$name\".")
    }
}
