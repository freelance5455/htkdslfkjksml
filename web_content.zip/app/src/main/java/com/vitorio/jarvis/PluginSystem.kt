package com.vitorio.jarvis

interface JarvisPlugin {
    val id:String
    val name:String
    fun canHandle(command:String):Boolean
    fun execute(command:String):String
}

class CalculatorPlugin:JarvisPlugin {
    override val id="calculator"
    override val name="Calculadora"
    override fun canHandle(command:String)=command.lowercase().startsWith("calcular ")
    override fun execute(command:String):String {
        val e=command.substringAfter("calcular ").replace(" ","")
        return try {
            val parts=e.split("+","-","*","/")
            if(parts.size==2){
                val a=parts[0].toDouble();val b=parts[1].toDouble()
                when{
                    e.contains("+")->"${a+b}"
                    e.contains("-")->"${a-b}"
                    e.contains("*")->"${a*b}"
                    e.contains("/")->if(b!=0.0)"${a/b}" else "Divisão por zero."
                    else->"Não entendi."
                }
            } else "Use: calcular 12+5"
        } catch(_:Exception){"Não consegui interpretar a conta."}
    }
}
