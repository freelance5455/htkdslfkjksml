package com.vitorio.jarvis
import android.graphics.*
import android.os.Bundle
import android.view.*
import android.widget.*
import java.io.File

class DrawingActivity:androidx.appcompat.app.AppCompatActivity(){
    override fun onCreate(b:Bundle?){
        super.onCreate(b)
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        val bar=LinearLayout(this)
        val clear=Button(this).apply{text="Limpar"}
        val save=Button(this).apply{text="Salvar"}
        val view=CanvasView()
        clear.setOnClickListener{view.clear()}
        save.setOnClickListener{view.save()}
        bar.addView(clear);bar.addView(save)
        box.addView(bar);box.addView(view,LinearLayout.LayoutParams(-1,0,1f))
        setContentView(box)
    }
    inner class CanvasView:View(this){
        private var bmp:Bitmap?=null
        private var canvas:Canvas?=null
        private val paint=Paint().apply{color=Color.WHITE;strokeWidth=8f;style=Paint.Style.STROKE;strokeCap=Paint.Cap.ROUND}
        private var x=0f;private var y=0f
        override fun onSizeChanged(w:Int,h:Int,ow:Int,oh:Int){
            bmp=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888)
            canvas=Canvas(bmp!!);canvas!!.drawColor(Color.BLACK)
        }
        override fun onDraw(c:Canvas){bmp?.let{c.drawBitmap(it,0f,0f,null)}}
        override fun onTouchEvent(e:MotionEvent):Boolean{
            when(e.action){
                MotionEvent.ACTION_DOWN->{x=e.x;y=e.y;return true}
                MotionEvent.ACTION_MOVE->{canvas?.drawLine(x,y,e.x,e.y,paint);x=e.x;y=e.y;invalidate()}
            };return true
        }
        fun clear(){canvas?.drawColor(Color.BLACK);invalidate()}
        fun save(){
            bmp?.let{
                val f=File(getExternalFilesDir(null),"jarvis_desenho_${System.currentTimeMillis()}.png")
                f.outputStream().use{out->it.compress(Bitmap.CompressFormat.PNG,100,out)}
                Toast.makeText(this@DrawingActivity,"Salvo em ${f.name}",Toast.LENGTH_SHORT).show()
            }
        }
    }
}
