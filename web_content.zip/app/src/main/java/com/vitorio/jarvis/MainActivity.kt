package com.vitorio.jarvis

import android.app.*
import android.content.*
import android.os.*
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.*
import android.widget.*
import java.util.Locale

class MainActivity:androidx.appcompat.app.AppCompatActivity(),TextToSpeech.OnInitListener {
    private lateinit var chat:LinearLayout
    private lateinit var input:EditText
    private lateinit var memory:JarvisMemory
    private lateinit var engine:JarvisEngine
    private lateinit var tts:TextToSpeech
    private val VOICE=7

    override fun onCreate(b:Bundle?){
        super.onCreate(b)
        memory=JarvisMemory(this)
        engine=JarvisEngine(this,memory)
        tts=TextToSpeech(this,this)
        build()
    }

    private fun build(){
        val main=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(18,25,18,15)}
        val title=TextView(this).apply{text="◉ JARVIS";textSize=28f}
        val sub=TextView(this).apply{text="Personal Android Intelligence Core";textSize=13f}
        chat=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        val scroll=ScrollView(this).apply{addView(chat);setPadding(0,20,0,10)}
        input=EditText(this).apply{hint="Comando...";singleLine=true}
        val row=LinearLayout(this)
        val send=Button(this).apply{text="EXECUTAR";setOnClickListener{runCmd()}}
        val voice=Button(this).apply{text="🎙";setOnClickListener{voice()}}
        val more=Button(this).apply{text="⚙";setOnClickListener{startActivity(Intent(this@MainActivity,SettingsActivity::class.java))}}
        row.addView(send,LinearLayout.LayoutParams(0,55,2f))
        row.addView(voice,LinearLayout.LayoutParams(0,55,1f))
        row.addView(more,LinearLayout.LayoutParams(0,55,1f))
        main.addView(title);main.addView(sub)
        main.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        main.addView(input);main.addView(row)
        setContentView(main)
        say("JARVIS online. Núcleo local carregado. Digite “ajuda” para ver comandos.")
    }

    private fun runCmd(){
        val s=input.text.toString(); if(s.isBlank())return
        input.text.clear(); user(s)
        val r=engine.execute(s); say(r.text); if(r.speak)speak(r.text)
    }
    private fun user(s:String){addBubble("Você: $s")}
    private fun say(s:String){addBubble("JARVIS: $s")}
    private fun addBubble(s:String){
        chat.addView(TextView(this).apply{text=s;textSize=16f;setPadding(10,12,10,12)})
        (chat.parent as? ScrollView)?.post{(chat.parent as ScrollView).fullScroll(View.FOCUS_DOWN)}
    }
    private fun voice(){
        val i=Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply{
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE,"pt-BR")
            putExtra(RecognizerIntent.EXTRA_PROMPT,"Diga o comando")
        }
        startActivityForResult(i,VOICE)
    }
    override fun onActivityResult(r:Int,c:Int,d:Intent?){
        super.onActivityResult(r,c,d)
        if(r==VOICE && c==RESULT_OK){
            d?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let{
                input.setText(it);runCmd()
            }
        }
    }
    override fun onInit(status:Int){if(status==TextToSpeech.SUCCESS)tts.language=Locale("pt","BR")}
    private fun speak(s:String){tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"jarvis")}
    override fun onDestroy(){tts.shutdown();super.onDestroy()}
}
