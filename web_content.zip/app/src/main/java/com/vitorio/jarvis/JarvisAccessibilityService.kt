package com.vitorio.jarvis
import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityNodeInfo

class JarvisAccessibilityService: AccessibilityService() {
    companion object { var instance: JarvisAccessibilityService?=null }
    override fun onServiceConnected(){super.onServiceConnected();instance=this}
    override fun onAccessibilityEvent(event: android.view.accessibility.AccessibilityEvent?){}
    override fun onInterrupt(){}
    override fun onDestroy(){instance=null;super.onDestroy()}

    fun clickText(target:String):Boolean {
        val root=rootInActiveWindow ?: return false
        return walk(root,target.lowercase())
    }
    private fun walk(n:AccessibilityNodeInfo,target:String):Boolean{
        val t=n.text?.toString()?.lowercase()
        val d=n.contentDescription?.toString()?.lowercase()
        if ((t==target || t?.contains(target)==true || d?.contains(target)==true) && n.isClickable)
            return n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        for(i in 0 until n.childCount) n.getChild(i)?.let{if(walk(it,target))return true}
        return false
    }
    fun back(){performGlobalAction(GLOBAL_ACTION_BACK)}
    fun home(){performGlobalAction(GLOBAL_ACTION_HOME)}
    fun recent(){performGlobalAction(GLOBAL_ACTION_RECENTS)}
}
