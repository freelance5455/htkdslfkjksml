package com.hammadikhlaq.zubaan;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;

public class SplashActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_splash);
        View logo = findViewById(R.id.logo), powered = findViewById(R.id.powered);
        logo.setScaleX(0.85f); logo.setScaleY(0.85f);
        logo.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(700).start();
        powered.animate().alpha(1f).setStartDelay(500).setDuration(600).start();
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            startActivity(new Intent(this, MainActivity.class));
            finish();
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        }, 2300);
    }
}
