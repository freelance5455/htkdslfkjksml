package com.hammadikhlaq.zubaan;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.webkit.WebViewAssetLoader;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    private WebView web;
    private TextToSpeech tts;
    private boolean ttsReady = false;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
        web.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return loader.shouldInterceptRequest(r.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if ("appassets.androidplatform.net".equals(u.getHost())) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception e) { }
                return true;
            }
        });
        tts = new TextToSpeech(this, st -> ttsReady = (st == TextToSpeech.SUCCESS));
        web.addJavascriptInterface(new Object() {
            @JavascriptInterface public void speak(String text, String tag) { say(text, tag); }
        }, "AndroidTTS");
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html");
    }

    private boolean tryLang(String tag) {
        int r = tts.setLanguage(Locale.forLanguageTag(tag));
        return r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED;
    }

    private void say(String text, String tag) {
        if (!ttsReady) return;
        String p = tag.split("-")[0];
        String[] fb = p.equals("ps") ? new String[]{"fa", "ur", "hi"} : p.equals("sd") ? new String[]{"ur", "hi"}
            : (p.equals("or") || p.equals("as")) ? new String[]{"bn", "hi"} : new String[]{p, "hi"};
        boolean ok = tryLang(tag);
        for (int i = 0; !ok && i < fb.length; i++) ok = tryLang(fb[i]);
        if (!ok) {
            runOnUiThread(() -> Toast.makeText(this, "No voice installed for this language. Add one in Settings > Text-to-speech.", Toast.LENGTH_LONG).show());
            return;
        }
        tts.setSpeechRate(0.85f);
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "zubaan");
    }

    @Override protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }
}
