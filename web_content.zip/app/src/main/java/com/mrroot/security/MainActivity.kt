package com.mrroot.security

import android.app.Activity
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL
import java.util.concurrent.Executors
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val worker = Executors.newSingleThreadExecutor()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webViewClient = WebViewClient()
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(Bridge(), "MRROOT")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    inner class Bridge {
        @JavascriptInterface
        fun run(command: String, target: String) {
            worker.execute {
                val result = try {
                    execute(command.trim().lowercase(), target.trim())
                } catch (e: Exception) {
                    "ERROR: ${e.message ?: "تعذر تنفيذ الفحص"}"
                }
                runOnUiThread {
                    val safe = JSONObject.quote(result)
                    web.evaluateJavascript("window.onNativeResult($safe)", null)
                }
            }
        }

        private fun cleanHost(input: String): String {
            require(input.isNotBlank()) { "أدخل اسم نطاق أو عنوان IP." }
            val raw = if (input.contains("://")) URL(input).host else input.substringBefore("/").substringBefore(":")
            require(raw.isNotBlank() && raw.matches(Regex("[A-Za-z0-9.-]{1,253}"))) {
                "صيغة الهدف غير صالحة."
            }
            return raw
        }

        private fun execute(cmd: String, input: String): String {
            if (cmd == "help") return """
MRROOT COMMANDS
help                 عرض الأوامر
dns <host>           استعلام DNS
ports <host>         اختبار منافذ شائعة محدودة (80,443,8080,8443)
tls <host>           قراءة معلومات شهادة TLS
about                معلومات التطبيق

استخدم الفحوصات فقط على أنظمة تملكها أو لديك تصريح باختبارها.
""".trimIndent()

            if (cmd == "about") return "MRROOT Mobile Security 1.0\nمحرك محلي لفحوصات اتصال أساسية ومحدودة."
            val host = cleanHost(input)
            return when (cmd) {
                "dns" -> {
                    val addresses = InetAddress.getAllByName(host).map { it.hostAddress }.distinct()
                    "DNS RESULT\nHost: $host\n" + addresses.joinToString("\n")
                }
                "ports" -> {
                    val ports = listOf(80, 443, 8080, 8443)
                    val lines = ports.map { port ->
                        val socket = Socket()
                        try {
                            socket.connect(InetSocketAddress(host, port), 1800)
                            "$port/tcp : OPEN (connection accepted)"
                        } catch (_: Exception) {
                            "$port/tcp : CLOSED or FILTERED (not confirmed)"
                        } finally {
                            try { socket.close() } catch (_: Exception) {}
                        }
                    }
                    "LIMITED TCP CONNECTIVITY CHECK\nTarget: $host\n" +
                        lines.joinToString("\n") +
                        "\n\nهذا اختبار اتصال محدود، وليس فحص ثغرات."
                }
                "tls" -> {
                    val factory = SSLSocketFactory.getDefault() as SSLSocketFactory
                    val socket = factory.createSocket() as SSLSocket
                    try {
                        socket.connect(InetSocketAddress(host, 443), 3500)
                        socket.soTimeout = 3500
                        socket.startHandshake()
                        val cert = socket.session.peerCertificates.first()
                        val x509 = cert as java.security.cert.X509Certificate
                        "TLS HANDSHAKE SUCCESS\nHost: $host\nProtocol: ${socket.session.protocol}\nCipher: ${socket.session.cipherSuite}\nSubject: ${x509.subjectX500Principal.name}\nIssuer: ${x509.issuerX500Principal.name}\nValid until: ${x509.notAfter}"
                    } finally { socket.close() }
                }
                else -> "أمر غير معروف: $cmd\nاكتب help لعرض الأوامر."
            }
        }
    }

    override fun onDestroy() {
        worker.shutdownNow()
        web.destroy()
        super.onDestroy()
    }
}
