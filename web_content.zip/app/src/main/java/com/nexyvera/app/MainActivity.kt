package com.nexyvera.app

import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.lifecycle.lifecycleScope
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.PermissionController
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.HeartRateRecord
import androidx.health.connect.client.records.SleepSessionRecord
import androidx.health.connect.client.records.StepsRecord
import androidx.health.connect.client.request.ReadRecordsRequest
import androidx.health.connect.client.time.TimeRangeFilter
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.time.Instant
import java.time.temporal.ChronoUnit

class MainActivity : ComponentActivity() {
    private lateinit var webView: WebView
    private var healthClient: HealthConnectClient? = null

    private val permissions = setOf(
        HealthPermission.getReadPermission(StepsRecord::class),
        HealthPermission.getReadPermission(HeartRateRecord::class),
        HealthPermission.getReadPermission(SleepSessionRecord::class)
    )

    private val requestPermissions = registerForActivityResult(
        PermissionController.createRequestPermissionResultContract()
    ) { granted ->
        if (granted.containsAll(permissions)) readHealthData()
        else sendToWeb(JSONObject().put("ok", false)
            .put("message", "Health Connect permissions were not all granted."))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = WebViewClient()
        webView.addJavascriptInterface(NexyveraBridge(), "NexyveraHealth")
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
        try {
            val status = HealthConnectClient.getSdkStatus(this)
            if (status == HealthConnectClient.SDK_UNAVAILABLE) {
                sendToWeb(JSONObject().put("ok", false)
                    .put("message", "Health Connect is not available on this device."))
            } else {
                healthClient = HealthConnectClient.getOrCreate(this)
            }
        } catch (e: Exception) {
            sendToWeb(JSONObject().put("ok", false)
                .put("message", "Could not initialize Health Connect: ${e.message}"))
        }
    }

    inner class NexyveraBridge {
        @JavascriptInterface
        fun readHealthData() {
            runOnUiThread {
                val client = healthClient
                if (client == null) {
                    sendToWeb(JSONObject().put("ok", false)
                        .put("message", "Health Connect is unavailable."))
                } else {
                    lifecycleScope.launch {
                        try {
                            val granted = client.permissionController.getGrantedPermissions()
                            if (!granted.containsAll(permissions)) {
                                requestPermissions.launch(permissions)
                            } else {
                                this@MainActivity.readHealthData()
                            }
                        } catch (e: Exception) {
                            sendToWeb(JSONObject().put("ok", false)
                                .put("message", "Permission check failed: ${e.message}"))
                        }
                    }
                }
            }
        }
    }

    private fun readHealthData() {
        val client = healthClient ?: return
        lifecycleScope.launch {
            try {
                val end = Instant.now()
                val start = end.minus(7, ChronoUnit.DAYS)
                val range = TimeRangeFilter.between(start, end)
                val result = JSONObject().put("ok", true)
                    .put("source", "Health Connect")
                    .put("range", "Last 7 days")

                val steps = client.readRecords(
                    ReadRecordsRequest(StepsRecord::class, timeRangeFilter = range)
                ).records
                result.put("stepsRecords", steps.size)
                result.put("stepsTotal", steps.sumOf { it.count })

                val heart = client.readRecords(
                    ReadRecordsRequest(HeartRateRecord::class, timeRangeFilter = range)
                ).records
                val latestHeart = heart.flatMap { record ->
                    record.samples.map { sample -> sample.time to sample.beatsPerMinute }
                }.maxByOrNull { it.first }
                result.put("heartRateRecords", heart.size)
                if (latestHeart != null) {
                    result.put("latestHeartRateBpm", latestHeart.second)
                    result.put("heartRateTime", latestHeart.first.toString())
                } else {
                    result.put("latestHeartRateBpm", JSONObject.NULL)
                }

                val sleep = client.readRecords(
                    ReadRecordsRequest(SleepSessionRecord::class, timeRangeFilter = range)
                ).records
                result.put("sleepSessions", sleep.size)
                sendToWeb(result)
            } catch (e: Exception) {
                sendToWeb(JSONObject().put("ok", false)
                    .put("message", "Could not read health data: ${e.message}"))
            }
        }
    }

    private fun sendToWeb(data: JSONObject) {
        runOnUiThread {
            val safe = data.toString()
            webView.evaluateJavascript(
                "if (window.showNexyveraHealthData) window.showNexyveraHealthData($safe); else if (window.showHealthData) window.showHealthData($safe);",
                null
            )
        }
    }
}
