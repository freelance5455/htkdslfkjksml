package com.hebrew.worksite;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.speech.tts.TextToSpeech;
import android.widget.Toast;
import java.util.Locale;

public class MainActivity extends Activity implements TextToSpeech.OnInitListener {
  private TextToSpeech tts;
  private boolean ready = false;
  private WebView web;
  @Override public void onCreate(Bundle b){
    super.onCreate(b);
    tts=new TextToSpeech(this,this);
    web=new WebView(this);
    web.getSettings().setJavaScriptEnabled(true);
    web.getSettings().setDomStorageEnabled(true);
    web.getSettings().setAllowFileAccess(true);
    web.setWebViewClient(new WebViewClient());
    web.addJavascriptInterface(new VoiceBridge(),"AndroidTTS");
    setContentView(web);
    web.loadUrl("file:///android_asset/index.html");
  }
  @Override public void onInit(int status){
    if(status==TextToSpeech.SUCCESS){
      int result=tts.setLanguage(new Locale("he","IL"));
      ready=(result!=TextToSpeech.LANG_MISSING_DATA && result!=TextToSpeech.LANG_NOT_SUPPORTED);
      tts.setSpeechRate(0.85f);
      if(!ready) runOnUiThread(()->Toast.makeText(this,"请在系统文字转语音设置中安装希伯来语语音",Toast.LENGTH_LONG).show());
    }else runOnUiThread(()->Toast.makeText(this,"手机语音引擎初始化失败",Toast.LENGTH_LONG).show());
  }
  private class VoiceBridge {
    @JavascriptInterface public void speak(String text){
      runOnUiThread(()->{
        if(!ready){Toast.makeText(MainActivity.this,"缺少希伯来语语音，请安装希伯来语 TTS",Toast.LENGTH_LONG).show();return;}
        tts.speak(text,TextToSpeech.QUEUE_FLUSH,null,"hebrew");
      });
    }
  }
  @Override protected void onDestroy(){if(tts!=null){tts.stop();tts.shutdown();} if(web!=null)web.destroy();super.onDestroy();}
}
