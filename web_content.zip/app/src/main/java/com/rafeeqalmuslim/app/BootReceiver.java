package com.rafeeqalmuslim.app;
import android.content.*;
public class BootReceiver extends BroadcastReceiver { @Override public void onReceive(Context c,Intent i){AdhanScheduler.scheduleNext(c); DhikrScheduler.schedule(c);} }
