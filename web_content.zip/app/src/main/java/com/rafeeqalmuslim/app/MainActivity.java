package com.rafeeqalmuslim.app;
import android.Manifest;import android.app.*;import android.content.*;import android.content.pm.PackageManager;import android.os.*;import android.webkit.*;import android.view.*;import android.widget.*;
public class MainActivity extends Activity {
 WebView web;
 @Override public void onCreate(Bundle b){super.onCreate(b);NotificationHelper.create(this);web=new WebView(this);web.setBackgroundColor(0xFF06131F);WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setMediaPlaybackRequiresUserGesture(false);s.setAllowFileAccess(true);s.setAllowContentAccess(true);web.addJavascriptInterface(new AndroidBridge(this),"AndroidAdhan");web.loadUrl("file:///android_asset/www/index.html");setContentView(web);requestNativePermissions();requestExactAlarmAccess();AdhanScheduler.scheduleNext(this); DhikrScheduler.schedule(this);StatsManager.start(this);}
 void requestExactAlarmAccess(){if(Build.VERSION.SDK_INT>=31){android.app.AlarmManager am=(android.app.AlarmManager)getSystemService(ALARM_SERVICE);if(am!=null&&!am.canScheduleExactAlarms()){try{Intent i=new Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,android.net.Uri.parse("package:"+getPackageName()));startActivity(i);}catch(Exception ignored){}}}}
 void requestNativePermissions(){if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},77);}
 @Override protected void onResume(){super.onResume();AdhanScheduler.scheduleNext(this); DhikrScheduler.schedule(this);StatsManager.start(this);}
 @Override protected void onDestroy(){StatsManager.stop();super.onDestroy();}
 @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
}
