package com.rafeeqalmuslim.app;

import android.content.*;

public class DhikrReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent i) {
        Intent s = new Intent(c, DhikrPlaybackService.class);
        try {
            if (android.os.Build.VERSION.SDK_INT >= 26) c.startForegroundService(s);
            else c.startService(s);
        } catch (Exception ignored) {}
        DhikrScheduler.schedule(c);
    }
}
