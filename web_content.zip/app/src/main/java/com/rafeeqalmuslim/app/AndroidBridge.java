package com.rafeeqalmuslim.app;
import android.app.*;import android.content.*;import android.net.*;import android.os.*;import android.provider.Settings;import android.webkit.JavascriptInterface;
public class AndroidBridge {
 private final Context c; public AndroidBridge(Context c){this.c=c;}
 @JavascriptInterface public void schedulePrayer(String name,int hour,int minute,int preMinutes,boolean enabled){AdhanScheduler.saveAndSchedule(c,name,hour,minute,preMinutes,enabled,c.getSharedPreferences("adhan_prefs",0).getInt("voice",0));}
 @JavascriptInterface public void setAdhanVoice(int voice){AdhanScheduler.setVoice(c,voice);}
 @JavascriptInterface public void setAdhanVolume(double v){AdhanScheduler.setVolume(c,(float)v);}
 @JavascriptInterface public void playAdhan(int voice){AdhanScheduler.setVoice(c,voice);Intent s=new Intent(c,AdhanPlaybackService.class).putExtra("voice",voice);try{if(Build.VERSION.SDK_INT>=26)c.startForegroundService(s);else c.startService(s);}catch(Exception ignored){}}
 @JavascriptInterface public void requestExactAlarmPermission(){if(Build.VERSION.SDK_INT>=31){try{Intent i=new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:"+c.getPackageName()));i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);c.startActivity(i);}catch(Exception ignored){}}}
 @JavascriptInterface public void requestPermissions(){if(c instanceof MainActivity)((MainActivity)c).requestNativePermissions();}
}
