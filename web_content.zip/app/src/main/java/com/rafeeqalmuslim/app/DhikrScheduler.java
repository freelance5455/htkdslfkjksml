package com.rafeeqalmuslim.app;

import android.app.*;
import android.content.*;
import android.os.Build;
import java.util.*;

public final class DhikrScheduler {
    private static final int REQUEST = 78121;
    private static final String PREF = "dhikr_prefs";
    private static final String ACTION = "RAFEQ_DHIKR";

    public static void schedule(Context c) {
        SharedPreferences p = c.getSharedPreferences(PREF, 0);
        if (!p.getBoolean("enabled", true)) return;
        int minutes = Math.max(5, Math.min(180, p.getInt("interval", 30)));
        AlarmManager am = (AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        cancel(c);
        long at = System.currentTimeMillis() + minutes * 60_000L;
        Intent in = new Intent(c, DhikrReceiver.class).setAction(ACTION);
        PendingIntent pi = PendingIntent.getBroadcast(c, REQUEST, in, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
        } else if (Build.VERSION.SDK_INT >= 23) {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
        } else {
            am.setExact(AlarmManager.RTC_WAKEUP, at, pi);
        }
    }

    public static void setEnabled(Context c, boolean enabled) {
        c.getSharedPreferences(PREF,0).edit().putBoolean("enabled", enabled).apply();
        if (enabled) schedule(c); else cancel(c);
    }
    public static void setInterval(Context c, int minutes) {
        c.getSharedPreferences(PREF,0).edit().putInt("interval", minutes).apply();
        schedule(c);
    }
    private static void cancel(Context c) {
        Intent in = new Intent(c, DhikrReceiver.class).setAction(ACTION);
        PendingIntent pi = PendingIntent.getBroadcast(c, REQUEST, in, PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
        if (pi != null) ((AlarmManager)c.getSystemService(Context.ALARM_SERVICE)).cancel(pi);
    }
    public static void cancelPublic(Context c) { cancel(c); }
    private DhikrScheduler() {}
}
