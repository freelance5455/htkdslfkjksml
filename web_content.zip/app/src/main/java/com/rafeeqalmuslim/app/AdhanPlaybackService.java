package com.rafeeqalmuslim.app;

import android.app.*;import android.content.*;import android.media.*;import android.os.*;

public class AdhanPlaybackService extends Service {
  private MediaPlayer player;
  private int voice=0;
  @Override public void onCreate(){super.onCreate();NotificationHelper.create(this);}
  @Override public int onStartCommand(Intent intent,int flags,int startId){
    voice=intent!=null?intent.getIntExtra("voice",0):0;
    startForeground(2401, buildNotification());
    play(); return START_NOT_STICKY;
  }
  private Notification buildNotification(){
    String[] names={"الأذان ١","الأذان ٢","الأذان ٣"};
    Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,NotificationHelper.PLAYBACK):new Notification.Builder(this);
    return b.setSmallIcon(android.R.drawable.ic_lock_silent_mode_off).setContentTitle("رفيق المسلم").setContentText("حان وقت الصلاة • "+names[Math.max(0,Math.min(voice,2))]).setOngoing(true).build();
  }
  private int res(){switch(Math.max(0,Math.min(voice,2))){case 1:return R.raw.adhan_2;case 2:return R.raw.adhan_3;default:return R.raw.adhan_1;}}
  private void play(){
    try{if(player!=null){player.release();player=null;} AudioManager am=(AudioManager)getSystemService(AUDIO_SERVICE);AudioAttributes aa=new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build();
      player=MediaPlayer.create(this,res()); if(player==null){stopSelf();return;} player.setAudioAttributes(aa); float vol=getSharedPreferences("adhan_prefs",0).getFloat("volume",1f); player.setVolume(vol,vol); player.setOnCompletionListener(mp->{mp.release();player=null;stopSelf();}); player.setOnErrorListener((mp,w,e)->{stopSelf();return true;}); player.start();
    }catch(Exception e){stopSelf();}
  }
  @Override public void onDestroy(){if(player!=null){try{player.stop();}catch(Exception ignored){}player.release();player=null;}super.onDestroy();}
  @Override public android.os.IBinder onBind(Intent intent){return null;}
}
