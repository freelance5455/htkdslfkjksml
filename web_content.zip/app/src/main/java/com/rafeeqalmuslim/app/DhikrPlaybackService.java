package com.rafeeqalmuslim.app;

import android.app.*;
import android.content.*;
import android.media.AudioAttributes;
import android.os.*;
import android.speech.tts.TextToSpeech;
import java.util.*;

public class DhikrPlaybackService extends Service {
    private TextToSpeech tts;
    private boolean finished = false;
    private final String[] adhkar = {
        "أستغفر الله",
        "سبحان الله",
        "الحمد لله",
        "الله أكبر",
        "لا إله إلا الله",
        "اللهم صل وسلم على نبينا محمد",
        "سبحان الله وبحمده، سبحان الله العظيم"
    };

    @Override public void onCreate() {
        super.onCreate();
        NotificationHelper.create(this);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        startForeground(2402, buildNotification());
        speakRandom();
        return START_NOT_STICKY;
    }

    private Notification buildNotification() {
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
            ? new Notification.Builder(this, NotificationHelper.PLAYBACK)
            : new Notification.Builder(this);
        return b.setSmallIcon(android.R.drawable.ic_lock_silent_mode_off)
            .setContentTitle("رفيق المسلم")
            .setContentText("ذكر الله")
            .setOngoing(false)
            .build();
    }

    private void speakRandom() {
        final String phrase = adhkar[new Random().nextInt(adhkar.length)];
        tts = new TextToSpeech(getApplicationContext(), status -> {
            if (status != TextToSpeech.SUCCESS) { stopSelf(); return; }
            try {
                tts.setLanguage(new Locale("ar"));
                tts.setSpeechRate(0.9f);
                tts.setPitch(1.0f);
                if (Build.VERSION.SDK_INT >= 21) {
                    tts.setAudioAttributes(new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build());
                    tts.speak(phrase, TextToSpeech.QUEUE_FLUSH, null, "dhikr");
                } else tts.speak(phrase, TextToSpeech.QUEUE_FLUSH, null);
                new Handler(Looper.getMainLooper()).postDelayed(this::stopSelf, 7000);
            } catch (Exception e) { stopSelf(); }
        });
    }

    @Override public void onDestroy() {
        if (tts != null) { try { tts.stop(); tts.shutdown(); } catch (Exception ignored) {} tts = null; }
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
