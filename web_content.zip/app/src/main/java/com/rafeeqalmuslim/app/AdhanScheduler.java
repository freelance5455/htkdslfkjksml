package com.rafeeqalmuslim.app;

import android.app.*;import android.content.*;import android.os.*;import java.util.*;

public final class AdhanScheduler {
 static final String PREF="adhan_prefs";
 static final String[] KEYS={"Fajr","Dhuhr","Asr","Maghrib","Isha"};
 static final String[] NAMES={"الفجر","الظهر","العصر","المغرب","العشاء"};
 public static void saveAndSchedule(Context c,String name,int h,int m,int pre,boolean enabled,int voice){
   c.getSharedPreferences(PREF,0).edit().putString(name,String.format(Locale.US,"%02d:%02d",h,m)).putBoolean(name+"_enabled",enabled).putInt("voice",voice).putInt("pre",Math.max(0,pre)).apply(); scheduleNext(c);
 }
 public static void setVolume(Context c,float v){c.getSharedPreferences(PREF,0).edit().putFloat("volume",Math.max(0,Math.min(1,v))).apply();}
 public static void setVoice(Context c,int v){c.getSharedPreferences(PREF,0).edit().putInt("voice",Math.max(0,Math.min(2,v))).apply();}
 public static void scheduleNext(Context c){
   AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE); if(am==null)return;
   for(int i=0;i<KEYS.length;i++){cancel(c,KEYS[i],false);cancel(c,KEYS[i],true);}
   android.content.SharedPreferences p=c.getSharedPreferences(PREF,0); long now=System.currentTimeMillis(); int pre=Math.max(0,p.getInt("pre",10)); int voice=p.getInt("voice",0);
   for(int i=0;i<KEYS.length;i++){
     if(!p.getBoolean(KEYS[i]+"_enabled",true))continue; String t=p.getString(KEYS[i],null); if(t==null)continue; String[] z=t.split(":"); if(z.length<2)continue; Calendar cal=Calendar.getInstance();cal.set(Calendar.HOUR_OF_DAY,Integer.parseInt(z[0]));cal.set(Calendar.MINUTE,Integer.parseInt(z[1]));cal.set(Calendar.SECOND,0);cal.set(Calendar.MILLISECOND,0);if(cal.getTimeInMillis()<=now)cal.add(Calendar.DAY_OF_YEAR,1);
     schedule(c,am,KEYS[i],NAMES[i],cal.getTimeInMillis(),false,voice);
     if(pre>0){Calendar pc=(Calendar)cal.clone();pc.add(Calendar.MINUTE,-pre);if(pc.getTimeInMillis()>now)schedule(c,am,KEYS[i],NAMES[i],pc.getTimeInMillis(),true,voice);}
   }
 }
 private static void schedule(Context c,AlarmManager am,String key,String name,long at,boolean pre,int voice){
   Intent in=new Intent(c,AdhanReceiver.class).setAction("RAFEeq_"+key+"_"+(pre?"PRE":"ADHAN"));in.putExtra("type",pre?"PRE_ADHAN":"ADHAN").putExtra("name",name).putExtra("voice",voice);
   int id=(key+"_"+(pre?"p":"a")).hashCode();PendingIntent pi=PendingIntent.getBroadcast(c,id,in,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
   if(Build.VERSION.SDK_INT>=31 && !am.canScheduleExactAlarms()){
     // Fallback: keep a real alarm even when the user has not granted exact-alarm access.
     // The UI/native layer can request the exact-alarm permission for minute-accurate timing.
     if(Build.VERSION.SDK_INT>=23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi);
     else am.set(AlarmManager.RTC_WAKEUP,at,pi);
     return;
   }
   if(Build.VERSION.SDK_INT>=23)am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi);else am.setExact(AlarmManager.RTC_WAKEUP,at,pi);
 }
 private static void cancel(Context c,String key,boolean pre){Intent in=new Intent(c,AdhanReceiver.class);int id=(key+"_"+(pre?"p":"a")).hashCode();PendingIntent pi=PendingIntent.getBroadcast(c,id,in,PendingIntent.FLAG_NO_CREATE|PendingIntent.FLAG_IMMUTABLE);if(pi!=null)((AlarmManager)c.getSystemService(Context.ALARM_SERVICE)).cancel(pi);}
 private AdhanScheduler(){}
}
