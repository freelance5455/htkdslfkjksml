package com.rafeeqalmuslim.app;

import android.content.*;import android.app.*;import android.os.*;

public class AdhanReceiver extends BroadcastReceiver {
 @Override public void onReceive(Context c,Intent i){
   NotificationHelper.create(c); boolean pre=i!=null&&"PRE_ADHAN".equals(i.getStringExtra("type")); String name=i!=null?i.getStringExtra("name"):"الصلاة";
   NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
   Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,NotificationHelper.ALERTS):new Notification.Builder(c);
   b.setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle(pre?"تنبيه الصلاة":"حان وقت صلاة "+name).setContentText(pre?"اقترب موعد صلاة "+name:"حان الآن وقت الصلاة • رفيق المسلم").setAutoCancel(true).setPriority(Notification.PRIORITY_HIGH);
   nm.notify((int)(System.currentTimeMillis()%1000000),b.build());
   if(!pre){Intent s=new Intent(c,AdhanPlaybackService.class);s.putExtra("voice",i!=null?i.getIntExtra("voice",0):0);try{if(Build.VERSION.SDK_INT>=26)c.startForegroundService(s);else c.startService(s);}catch(Exception ignored){} AdhanScheduler.scheduleNext(c);}
 }
}
