package com.rafeeqalmuslim.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Central usage statistics: first install, sessions and a 60-second heartbeat. */
public final class StatsManager {
    private static final String PREFS = "rafeeq_stats";
    private static final String KEY_DEVICE_ID = "device_id";
    private static final long HEARTBEAT_MS = 60_000L;
    private static Handler handler;
    private static Runnable heartbeat;

    private StatsManager() {}

    public static void start(Context context) {
        Context app = context.getApplicationContext();
        SharedPreferences p = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String deviceId = p.getString(KEY_DEVICE_ID, null);
        FirebaseAnalytics analytics = FirebaseAnalytics.getInstance(app);

        if (deviceId == null) {
            deviceId = UUID.randomUUID().toString();
            p.edit().putString(KEY_DEVICE_ID, deviceId).apply();
            analytics.logEvent("first_open_local", null);
        }

        BundleHelper.logSession(analytics);
        FirebaseAuth auth = FirebaseAuth.getInstance();
        if (auth.getCurrentUser() != null) {
            heartbeat(app, deviceId);
        } else {
            auth.signInAnonymously().addOnCompleteListener(task -> heartbeat(app, deviceId));
        }
    }

    private static void heartbeat(Context context, String deviceId) {
        try {
            FirebaseDatabase db = FirebaseDatabase.getInstance("https://rafeeq-al-muslim-b5e77-default-rtdb.firebaseio.com");
            DatabaseReference ref = db.getReference("stats/presence/" + deviceId);
            Map<String, Object> data = new HashMap<>();
            data.put("lastSeen", com.google.firebase.database.ServerValue.TIMESTAMP);
            data.put("appVersion", "1.4.0");
            data.put("platform", "android");
            ref.updateChildren(data);
            ref.child("lastSeen").onDisconnect().setValue(0);

            if (handler == null) handler = new Handler(Looper.getMainLooper());
            if (heartbeat != null) handler.removeCallbacks(heartbeat);
            final Context app = context.getApplicationContext();
            heartbeat = () -> heartbeat(app, deviceId);
            handler.postDelayed(heartbeat, HEARTBEAT_MS);
        } catch (Exception ignored) {
            if (handler == null) handler = new Handler(Looper.getMainLooper());
            final Context app = context.getApplicationContext();
            if (heartbeat != null) handler.removeCallbacks(heartbeat);
            heartbeat = () -> heartbeat(app, deviceId);
            handler.postDelayed(heartbeat, HEARTBEAT_MS);
        }
    }

    public static void stop() {
        if (handler != null && heartbeat != null) handler.removeCallbacks(heartbeat);
    }

    static final class BundleHelper {
        static void logSession(FirebaseAnalytics analytics) {
            analytics.logEvent(FirebaseAnalytics.Event.APP_OPEN, null);
        }
    }
}
