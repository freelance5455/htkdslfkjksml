package com.rafeeqalmuslim.app;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Build;

public final class NotificationHelper {
  public static final String ALERTS="prayer_alerts";
  public static final String PLAYBACK="adhan_playback";
  public static void create(Context c){
    if(Build.VERSION.SDK_INT>=26){
      NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
      nm.createNotificationChannel(new NotificationChannel(ALERTS,"تنبيهات الصلاة",NotificationManager.IMPORTANCE_HIGH));
      nm.createNotificationChannel(new NotificationChannel(PLAYBACK,"الأذان",NotificationManager.IMPORTANCE_LOW));
    }
  }
  private NotificationHelper(){}
}
