package com.mycalendar.app

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.IBinder
import androidx.core.app.NotificationCompat

class AlarmService : Service() {
    private var player: MediaPlayer? = null

    override fun onCreate() {
        super.onCreate()
        startForeground(NOTIFICATION_ID, buildNotification("Pengingat kalender"))
        player = MediaPlayer.create(this, com.mycalendar.app.R.raw.alarm)
        player?.isLooping = true
        player?.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build()
        )
        player?.start()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val name = intent?.getStringExtra("name") ?: "Pengingat kalender"
        updateNotification(name)
        return START_STICKY
    }

    private fun buildNotification(name: String): Notification {
        val stopIntent = Intent(this, StopAlarmReceiver::class.java)
        val stopPending = PendingIntent.getBroadcast(
            this, 999,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("🔔 WAKTUNYA!")
            .setContentText(name)
            .setStyle(NotificationCompat.BigTextStyle().bigText("$name\nTekan MATIKAN ALARM untuk menghentikan suara."))
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setOngoing(true)
            .setAutoCancel(false)
            .addAction(android.R.drawable.ic_media_pause, "🔕 MATIKAN ALARM", stopPending)
            .build()
    }

    private fun updateNotification(name: String) {
        val manager = getSystemService(NOTIFICATION_SERVICE) as android.app.NotificationManager
        manager.notify(NOTIFICATION_ID, buildNotification(name))
    }

    override fun onDestroy() {
        player?.stop()
        player?.release()
        player = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val CHANNEL_ID = "calendar_alarm"
        const val NOTIFICATION_ID = 2001
    }
}
