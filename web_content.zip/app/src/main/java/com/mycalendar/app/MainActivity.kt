package com.mycalendar.app

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    private lateinit var webView: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        createNotificationChannel()
        requestNotificationPermission()
        requestExactAlarmPermission()

        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.webViewClient = WebViewClient()
        webView.addJavascriptInterface(CalendarBridge(this), "AndroidCalendar")
        webView.loadUrl("file:///android_asset/index.html")
        setContentView(webView)
    }

    private fun createNotificationChannel() {
        val manager = getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(
            AlarmService.CHANNEL_ID,
            "Pengingat Kalender",
            NotificationManager.IMPORTANCE_HIGH
        )
        channel.description = "Notifikasi alarm My Calendar"
        channel.setSound(null, null)
        manager.createNotificationChannel(channel)
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }
    }

    private fun requestExactAlarmPermission() {
        if (Build.VERSION.SDK_INT >= 31) {
            val alarmManager = getSystemService(AlarmManager::class.java)
            if (!alarmManager.canScheduleExactAlarms()) {
                try {
                    startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                        data = Uri.parse("package:$packageName")
                    })
                } catch (_: Exception) {}
            }
        }
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}

class CalendarBridge(private val context: Context) {
    @JavascriptInterface
    fun scheduleAlarm(id: String, name: String, date: String, time: String) {
        AlarmScheduler.schedule(context, id, name, date, time)
    }

    @JavascriptInterface
    fun cancelAlarm(id: String) {
        AlarmScheduler.cancel(context, id)
    }
}

object AlarmScheduler {
    private const val ACTION = "com.mycalendar.app.CALENDAR_ALARM"

    fun schedule(context: Context, id: String, name: String, date: String, time: String) {
        val partsDate = date.split("-")
        val partsTime = time.split(":")
        if (partsDate.size != 3 || partsTime.size < 2) return

        val cal = java.util.Calendar.getInstance().apply {
            set(java.util.Calendar.YEAR, partsDate[0].toInt())
            set(java.util.Calendar.MONTH, partsDate[1].toInt() - 1)
            set(java.util.Calendar.DAY_OF_MONTH, partsDate[2].toInt())
            set(java.util.Calendar.HOUR_OF_DAY, partsTime[0].toInt())
            set(java.util.Calendar.MINUTE, partsTime[1].toInt())
            set(java.util.Calendar.SECOND, 0)
            set(java.util.Calendar.MILLISECOND, 0)
        }

        if (cal.timeInMillis <= System.currentTimeMillis()) return

        val intent = Intent(context, AlarmReceiver::class.java).apply {
            action = ACTION
            putExtra("id", id)
            putExtra("name", name)
        }
        val pending = PendingIntent.getBroadcast(
            context, id.hashCode(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val alarmManager = context.getSystemService(AlarmManager::class.java)

        if (Build.VERSION.SDK_INT >= 31 && !alarmManager.canScheduleExactAlarms()) return
        alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pending)
    }

    fun cancel(context: Context, id: String) {
        val intent = Intent(context, AlarmReceiver::class.java).apply { action = ACTION }
        val pending = PendingIntent.getBroadcast(
            context, id.hashCode(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        context.getSystemService(AlarmManager::class.java).cancel(pending)
    }
}
