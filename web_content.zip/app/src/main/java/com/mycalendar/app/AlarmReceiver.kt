package com.mycalendar.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val serviceIntent = Intent(context, AlarmService::class.java).apply {
            putExtra("id", intent.getStringExtra("id") ?: "")
            putExtra("name", intent.getStringExtra("name") ?: "Pengingat")
        }
        ContextCompat.startForegroundService(context, serviceIntent)
    }
}
