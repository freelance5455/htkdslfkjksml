package com.mygroupd.study;
import android.app.*;
import android.os.*;
import android.webkit.*;
import android.content.*;
import android.widget.*;
import java.security.*;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import java.io.*;

public class MainActivity extends Activity {
 WebView web;
 final int RESTORE_REQUEST=1826;
 class BackupBridge {
  @JavascriptInterface public void setUpdateUrl(String url){if(url!=null && url.startsWith("https://"))getSharedPreferences("updates",0).edit().putString("url",url).apply();}
  @JavascriptInterface public String getUpdateUrl(){return getSharedPreferences("updates",0).getString("url","");}
  @JavascriptInterface public String getUpdateFeed(){return getSharedPreferences("updates",0).getString("feed","{}");}

  @JavascriptInterface public void share(String json){runOnUiThread(()->{try{Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_TEXT,json);startActivity(Intent.createChooser(i,"V26 बैकअप सेव / शेयर करें"));}catch(Exception e){Toast.makeText(MainActivity.this,"बैकअप शेयर नहीं हुआ",Toast.LENGTH_LONG).show();}});}
  @JavascriptInterface public void pick(){runOnUiThread(()->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/json");startActivityForResult(i,RESTORE_REQUEST);});}
 }
 @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(request==RESTORE_REQUEST&&result==RESULT_OK&&data!=null){try(InputStream in=getContentResolver().openInputStream(data.getData())){ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[8192];int n;while((n=in.read(buf))!=-1){out.write(buf,0,n);if(out.size()>10000000)throw new IOException("File too large");}String raw=out.toString("UTF-8");String encoded=Base64.encodeToString(raw.getBytes("UTF-8"),Base64.NO_WRAP);web.evaluateJavascript("V26Restore(decodeURIComponent(escape(atob(\""+encoded+"\"))))",null);}catch(Exception e){Toast.makeText(this,"बैकअप पढ़ नहीं सके",Toast.LENGTH_LONG).show();}}}

 String hash(String pass,String salt){
  try { byte[] s=Base64.decode(salt,Base64.NO_WRAP); PBEKeySpec spec=new PBEKeySpec(pass.toCharArray(),s,120000,256);
   byte[] h=SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
   return Base64.encodeToString(h,Base64.NO_WRAP);
  }catch(Exception e){return "";}
 }
 @Override public void onCreate(Bundle b){super.onCreate(b);authenticate();}
 void authenticate(){
  android.content.SharedPreferences pref=getSharedPreferences("lock",MODE_PRIVATE);
  boolean setup=!pref.contains("hash");
  EditText input=new EditText(this);input.setInputType(129);input.setHint(setup?"नया पासवर्ड (कम से कम 8 अक्षर)":"पासवर्ड दर्ज करें");
  LinearLayout layout=new LinearLayout(this);layout.setPadding(36,12,36,0);layout.addView(input);
  AlertDialog dialog=new AlertDialog.Builder(this).setTitle(setup?"🔒 पहली बार पासवर्ड बनाएँ":"🔒 My Group D Study V26").setView(layout).setCancelable(false)
   .setNegativeButton("बंद करें",(d,w)->finish()).setPositiveButton(setup?"सेव करें":"खोलें",null).create();
  dialog.setOnShowListener(d->dialog.getButton(-1).setOnClickListener(v->{String p=input.getText().toString();
   if(setup){if(p.length()<8){input.setError("कम से कम 8 अक्षर");return;}
    byte[] salt=new byte[16];new SecureRandom().nextBytes(salt);String s=Base64.encodeToString(salt,Base64.NO_WRAP);
    pref.edit().putString("salt",s).putString("hash",hash(p,s)).apply();dialog.dismiss();showSite();
   }else if(MessageDigest.isEqual(hash(p,pref.getString("salt","")).getBytes(),pref.getString("hash","").getBytes())){dialog.dismiss();showSite();}
   else {input.setText("");input.setError("गलत पासवर्ड");}
  }));dialog.show();
 }

 void showSite(){if(android.os.Build.VERSION.SDK_INT>=33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=android.content.pm.PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},2602);UpdateJob.schedule(this);web=new WebView(this);web.getSettings().setJavaScriptEnabled(true);web.getSettings().setDomStorageEnabled(true);
  web.getSettings().setAllowFileAccess(true);web.getSettings().setAllowFileAccessFromFileURLs(false);web.getSettings().setAllowUniversalAccessFromFileURLs(false);
  web.setWebChromeClient(new WebChromeClient());
  web.addJavascriptInterface(new BackupBridge(),"AndroidBackup");
  web.setWebViewClient(new WebViewClient(){@Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest request){String u=request.getUrl().toString();
   if(u.startsWith("file:///android_asset/"))return false;
   if(request.isForMainFrame() && (u.startsWith("https://www.youtube.com/embed/") || u.startsWith("https://www.youtube-nocookie.com/embed/"))) return false;
   if(request.isForMainFrame() && (u.startsWith("https://") || u.startsWith("http://"))){
    try{startActivity(new Intent(Intent.ACTION_VIEW,android.net.Uri.parse(u)));}catch(Exception ignored){}
    return true;
   }
   return false;}});
  setContentView(web);web.loadUrl("file:///android_asset/index.html");}
 @Override public void onBackPressed(){if(web!=null&&web.canGoBack())web.goBack();else super.onBackPressed();}
}
