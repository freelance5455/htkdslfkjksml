package com.hasanjassim.appointments;

import android.app.*;
import android.content.*;
import android.os.Build;
import java.text.*;
import java.util.*;

public class ReminderScheduler {
    public static void schedule(Context c,long id,String date,String time,String title) {
        try {
            String[] d=date.split("-");
            String[] t=time.replace("صباحًا","AM").replace("مساءً","PM").trim().split(":");
            String hour=t[0].replaceAll("[^0-9]","");
            String min=t.length>1?t[1].replaceAll("[^0-9]",""):"0";
            int h=Integer.parseInt(hour), m=Integer.parseInt(min);
            boolean pm=time.contains("مساء");
            if(pm && h<12) h+=12; if(!pm && h==12) h=0;
            Calendar cal=Calendar.getInstance();
            cal.set(Integer.parseInt(d[0]),Integer.parseInt(d[1])-1,Integer.parseInt(d[2]),h,m,0);
            if(cal.getTimeInMillis()<=System.currentTimeMillis()) return;

            AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
            Intent in=new Intent(c,ReminderReceiver.class);
            in.putExtra("id",id); in.putExtra("title",title); in.putExtra("time",time);
            PendingIntent pi=PendingIntent.getBroadcast(c,(int)(id%1000000000L),in,
                    PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);

            if(Build.VERSION.SDK_INT>=31 && !am.canScheduleExactAlarms()) return;
            if(Build.VERSION.SDK_INT>=23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,cal.getTimeInMillis(),pi);
            else am.setExact(AlarmManager.RTC_WAKEUP,cal.getTimeInMillis(),pi);
        } catch(Exception ignored){}
    }

    public static void rescheduleAll(Context c) {
        try {
            org.json.JSONArray a=AppointmentStore.all(c);
            for(int i=0;i<a.length();i++){
                org.json.JSONObject o=a.getJSONObject(i);
                schedule(c,o.optLong("id"),o.optString("date"),o.optString("time"),o.optString("title"));
            }
        } catch(Exception ignored){}
    }
}
