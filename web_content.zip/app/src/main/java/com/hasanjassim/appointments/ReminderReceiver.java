package com.hasanjassim.appointments;

import android.app.*;
import android.content.*;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;

public class ReminderReceiver extends BroadcastReceiver {
    public void onReceive(Context c, Intent in) {
        String title=in.getStringExtra("title");
        String time=in.getStringExtra("time");
        String channel="appointments_alarm";
        NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26){
            Uri sound=RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
            NotificationChannel ch=new NotificationChannel(channel,"تنبيهات المواعيد",NotificationManager.IMPORTANCE_HIGH);
            ch.setSound(sound,null); ch.enableVibration(true); nm.createNotificationChannel(ch);
        }
        Intent open=new Intent(c,MainActivity.class);
        PendingIntent pi=PendingIntent.getActivity(c,0,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b=Build.VERSION.SDK_INT>=26 ? new Notification.Builder(c,channel) : new Notification.Builder(c);
        b.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
         .setContentTitle("تنبيه موعد")
         .setContentText((title==null?"موعد":title)+" — "+(time==null?"":time))
         .setAutoCancel(true).setContentIntent(pi).setPriority(Notification.PRIORITY_MAX)
         .setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM));
        nm.notify((int)(System.currentTimeMillis()%1000000),b.build());
    }
}
