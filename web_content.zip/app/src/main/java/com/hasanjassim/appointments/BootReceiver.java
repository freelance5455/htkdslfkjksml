package com.hasanjassim.appointments;
import android.content.*;
public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent i) {
        ReminderScheduler.rescheduleAll(c);
    }
}
