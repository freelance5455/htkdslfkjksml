package com.hasanjassim.appointments;

import android.content.*;
import org.json.*;
import java.util.*;

public class AppointmentStore {
    private static final String PREF="appointments";
    private static final String KEY="items";
    public static JSONArray all(Context c) {
        try { return new JSONArray(c.getSharedPreferences(PREF,0).getString(KEY,"[]")); }
        catch(Exception e){ return new JSONArray(); }
    }
    public static long add(Context c, String date,String time,String title,String person,String details) {
        long id=System.currentTimeMillis();
        try {
            JSONArray a=all(c); JSONObject o=new JSONObject();
            o.put("id",id); o.put("date",date); o.put("time",time); o.put("title",title);
            o.put("person",person); o.put("details",details); a.put(o); save(c,a);
        } catch(Exception ignored){}
        return id;
    }
    public static void save(Context c, JSONArray a) {
        c.getSharedPreferences(PREF,0).edit().putString(KEY,a.toString()).apply();
    }
    public static void delete(Context c,long id) {
        JSONArray old=all(c), n=new JSONArray();
        try { for(int i=0;i<old.length();i++){ JSONObject o=old.getJSONObject(i); if(o.optLong("id")!=id)n.put(o); } save(c,n); } catch(Exception ignored){}
    }
}
