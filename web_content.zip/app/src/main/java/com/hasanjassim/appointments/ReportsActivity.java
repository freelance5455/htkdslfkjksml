package com.hasanjassim.appointments;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import org.json.*;

public class ReportsActivity extends Activity {
    TableLayout table;
    public void onCreate(Bundle b){super.onCreate(b); LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(10,10,10,10);
        TextView h=new TextView(this);h.setText("📊 تقرير المواعيد");h.setTextSize(25);h.setTextColor(Color.rgb(36,59,100));root.addView(h);
        table=new TableLayout(this);table.setStretchAllColumns(true);root.addView(table,new LinearLayout.LayoutParams(-1,-1));load();setContentView(new ScrollView(this){{addView(root);}});}
    void load(){ addRow("م","التاريخ","الوقت","عنوان الموعد","الجهة/الشخص","الحالة","سبب عدم التنفيذ",true);
        try{JSONArray a=AppointmentStore.all(this);for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);addRow(""+(i+1),o.optString("date"),o.optString("time"),o.optString("title"),o.optString("person"),"—","—",false);}}catch(Exception ignored){}
    }
    void addRow(String...x){ addRow(x[0],x[1],x[2],x[3],x[4],x[5],x[6],false);}
    void addRow(String a,String b,String c,String d,String e,String f,String g,boolean head){
        TableRow r=new TableRow(this);String[] vals={a,b,c,d,e,f,g};
        for(String s:vals){TextView v=new TextView(this);v.setText(s);v.setTextSize(head?14:13);v.setPadding(8,12,8,12);v.setBackgroundResource(android.R.drawable.editbox_background);r.addView(v);}
        table.addView(r);
    }
}
