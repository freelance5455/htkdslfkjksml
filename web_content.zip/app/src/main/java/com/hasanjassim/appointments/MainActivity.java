package com.hasanjassim.appointments;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import org.json.*;

public class MainActivity extends Activity {
    LinearLayout box; EditText date,time,title,person,details;
    public void onCreate(Bundle b){
        super.onCreate(b); build();
        if(Build.VERSION.SDK_INT>=33) requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},100);
    }
    TextView tv(String s){ TextView v=new TextView(this); v.setText(s); v.setTextSize(18); v.setPadding(16,18,16,18); return v; }
    EditText ed(String hint){ EditText e=new EditText(this); e.setHint(hint); e.setTextSize(17); e.setPadding(18,12,18,12); return e; }
    Button btn(String s){ Button b=new Button(this); b.setText(s); b.setTextSize(17); return b; }
    void build(){
        ScrollView sc=new ScrollView(this); box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(20,20,20,20);
        TextView head=tv("تطبيق المواعيد الاحترافي"); head.setTextSize(26); head.setTextColor(Color.rgb(36,59,100)); box.addView(head);
        box.addView(tv("إضافة موعد جديد"));
        date=ed("التاريخ YYYY-MM-DD"); time=ed("الوقت (مثال: 08:30 صباحًا)"); title=ed("عنوان الموعد");
        person=ed("الجهة / الشخص"); details=ed("تفاصيل الموعد");
        box.addView(date); box.addView(time); box.addView(title); box.addView(person); box.addView(details);
        Button add=btn("حفظ الموعد + ضبط المنبه"); box.addView(add);
        Button preview=btn("📅 معاينة المواعيد"); box.addView(preview);
        Button reports=btn("📊 التقارير"); box.addView(reports);
        box.addView(tv("تم إعداد التطبيق بواسطة المهندس حسن جاسم"));
        add.setOnClickListener(v->{
            if(date.getText().toString().trim().isEmpty() || time.getText().toString().trim().isEmpty() || title.getText().toString().trim().isEmpty()){
                Toast.makeText(this,"أدخل التاريخ والوقت وعنوان الموعد",Toast.LENGTH_LONG).show(); return;
            }
            long id=AppointmentStore.add(this,date.getText().toString(),time.getText().toString(),title.getText().toString(),person.getText().toString(),details.getText().toString());
            ReminderScheduler.schedule(this,id,date.getText().toString(),time.getText().toString(),title.getText().toString());
            Toast.makeText(this,"تم حفظ الموعد وضبط المنبه",Toast.LENGTH_LONG).show();
        });
        preview.setOnClickListener(v->startActivity(new Intent(this,PreviewActivity.class)));
        reports.setOnClickListener(v->startActivity(new Intent(this,ReportsActivity.class)));
        sc.addView(box); setContentView(sc);
    }
}
