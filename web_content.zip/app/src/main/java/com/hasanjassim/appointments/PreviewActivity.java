package com.hasanjassim.appointments;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import org.json.*;

public class PreviewActivity extends Activity {
    LinearLayout list;
    public void onCreate(Bundle b){ super.onCreate(b); list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); list.setPadding(18,18,18,18); TextView h=new TextView(this); h.setText("معاينة المواعيد"); h.setTextSize(26); h.setTextColor(Color.rgb(36,59,100)); list.addView(h); load(); setContentView(new ScrollView(this){{addView(list);}}); }
    void load(){
        try{
            JSONArray a=AppointmentStore.all(this);
            if(a.length()==0){list.addView(text("لا توجد مواعيد محفوظة."));return;}
            for(int i=0;i<a.length();i++){
                JSONObject o=a.getJSONObject(i);
                LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(15,15,15,15);
                card.addView(text("📅 "+o.optString("date")+"   ⏰ "+o.optString("time")));
                card.addView(text("الموعد: "+o.optString("title")));
                card.addView(text("الجهة / الشخص: "+o.optString("person")));
                card.addView(text("التفاصيل: "+o.optString("details")));
                Button del=new Button(this); del.setText("حذف الموعد"); long id=o.optLong("id");
                del.setOnClickListener(v->{ AppointmentStore.delete(this,id); ReminderScheduler.rescheduleAll(this); recreate();});
                card.addView(del); list.addView(card);
            }
        }catch(Exception ignored){}
    }
    TextView text(String s){TextView v=new TextView(this);v.setText(s);v.setTextSize(17);v.setPadding(8,8,8,8);return v;}
}
