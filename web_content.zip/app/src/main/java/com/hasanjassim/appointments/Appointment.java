package com.hasanjassim.appointments;

public class Appointment {
    public long id;
    public String date, time, title, person, details;
    public Appointment(long id, String date, String time, String title, String person, String details) {
        this.id=id; this.date=date; this.time=time; this.title=title; this.person=person; this.details=details;
    }
}
