package com.spidersystem.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.View
import android.view.WindowManager
import android.webkit.GeolocationPermissions
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private lateinit var assetLoader: WebViewAssetLoader
    private var pendingMediaRequest: PermissionRequest? = null
    private var pendingGeoOrigin: String? = null
    private var pendingGeoCallback: GeolocationPermissions.Callback? = null
    private var pendingVoiceStart = false
    private var speechRecognizer: SpeechRecognizer? = null
    private var speechIntent: Intent? = null
    private var textToSpeech: TextToSpeech? = null
    private var ttsReady = false
    private var voiceSessionRequested = false

    private val mediaRequestCode = 601
    private val geoRequestCode = 602
    private val voiceRequestCode = 603
    private val mainHandler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = android.graphics.Color.rgb(3, 9, 17)
        window.navigationBarColor = android.graphics.Color.rgb(3, 9, 17)
        applyImmersiveMode()

        textToSpeech = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                var languageResult = textToSpeech?.setLanguage(Locale("es", "ES")) ?: TextToSpeech.LANG_NOT_SUPPORTED
                if (languageResult < TextToSpeech.LANG_AVAILABLE) {
                    languageResult = textToSpeech?.setLanguage(Locale("es")) ?: TextToSpeech.LANG_NOT_SUPPORTED
                }
                ttsReady = languageResult >= TextToSpeech.LANG_AVAILABLE
                textToSpeech?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) = Unit
                    override fun onDone(utteranceId: String?) = jsCall("onNativeSpeechDone")
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) = jsCall("onNativeSpeechDone")
                    override fun onError(utteranceId: String?, errorCode: Int) = jsCall("onNativeSpeechDone")
                })
            }
        }

        assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView = WebView(this).apply {
            setBackgroundColor(android.graphics.Color.rgb(3, 9, 17))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.setGeolocationEnabled(true)
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            settings.loadsImagesAutomatically = true
            settings.loadWithOverviewMode = true
            settings.useWideViewPort = true
            settings.builtInZoomControls = false
            settings.displayZoomControls = false
            addJavascriptInterface(SpiderBridge(), "SpiderNative")
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                    return assetLoader.shouldInterceptRequest(request.url)
                }
            }
            webChromeClient = object : WebChromeClient() {
                override fun onPermissionRequest(request: PermissionRequest) {
                    runOnUiThread {
                        if (request.origin.host != "appassets.androidplatform.net") {
                            request.deny()
                            return@runOnUiThread
                        }
                        val missing = mutableListOf<String>()
                        if (request.resources.contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE) &&
                            !hasPermission(Manifest.permission.CAMERA)) missing.add(Manifest.permission.CAMERA)
                        if (request.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE) &&
                            !hasPermission(Manifest.permission.RECORD_AUDIO)) missing.add(Manifest.permission.RECORD_AUDIO)

                        if (missing.isEmpty()) {
                            request.grant(request.resources)
                        } else {
                            pendingMediaRequest?.deny()
                            pendingMediaRequest = request
                            requestPermissions(missing.distinct().toTypedArray(), mediaRequestCode)
                        }
                    }
                }

                override fun onPermissionRequestCanceled(request: PermissionRequest) {
                    if (pendingMediaRequest == request) pendingMediaRequest = null
                }

                override fun onGeolocationPermissionsShowPrompt(
                    origin: String,
                    callback: GeolocationPermissions.Callback
                ) {
                    runOnUiThread {
                        if (hasLocationPermission()) {
                            callback.invoke(origin, true, false)
                        } else {
                            pendingGeoOrigin = origin
                            pendingGeoCallback = callback
                            requestPermissions(
                                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION),
                                geoRequestCode
                            )
                        }
                    }
                }
            }
        }

        setContentView(webView)
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    private fun applyImmersiveMode() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            window.setDecorFitsSystemWindows(false)
            window.insetsController?.let { controller ->
                controller.hide(android.view.WindowInsets.Type.systemBars())
                controller.systemBarsBehavior = android.view.WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                    View.SYSTEM_UI_FLAG_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                )
        }
    }

    private fun hasPermission(permission: String): Boolean =
        checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED

    private fun hasLocationPermission(): Boolean =
        hasPermission(Manifest.permission.ACCESS_FINE_LOCATION) ||
            hasPermission(Manifest.permission.ACCESS_COARSE_LOCATION)

    private fun jsCall(function: String, value: String? = null) {
        val argument = JSONObject.quote(value ?: "")
        runOnUiThread {
            if (::webView.isInitialized) webView.evaluateJavascript("window.$function($argument)", null)
        }
    }

    private fun buildSpeechIntent(): Intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-ES")
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "es-ES")
        putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, false)
        putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
    }

    private fun startNativeListening() {
        if (!voiceSessionRequested) return
        if (!hasPermission(Manifest.permission.RECORD_AUDIO)) {
            pendingVoiceStart = true
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), voiceRequestCode)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            jsCall("onNativeVoiceError", "UNAVAILABLE")
            return
        }
        try {
            if (speechRecognizer == null) {
                speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).also { recognizer ->
                    recognizer.setRecognitionListener(object : RecognitionListener {
                        override fun onReadyForSpeech(params: Bundle?) = jsCall("onNativeVoiceState", "LISTENING")
                        override fun onBeginningOfSpeech() = jsCall("onNativeVoiceState", "HEARING")
                        override fun onRmsChanged(rmsdB: Float) = Unit
                        override fun onBufferReceived(buffer: ByteArray?) = Unit
                        override fun onEndOfSpeech() = jsCall("onNativeVoiceState", "PROCESSING")
                        override fun onError(error: Int) {
                            jsCall("onNativeVoiceError", error.toString())
                        }
                        override fun onResults(results: Bundle?) {
                            val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            val spoken = matches?.firstOrNull().orEmpty()
                            if (spoken.isNotBlank()) jsCall("onNativeVoiceResult", spoken)
                            else jsCall("onNativeVoiceError", "NO_MATCH")
                        }
                        override fun onPartialResults(partialResults: Bundle?) {
                            val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            matches?.firstOrNull()?.let { jsCall("onNativeVoicePartial", it) }
                        }
                        override fun onEvent(eventType: Int, params: Bundle?) = Unit
                    })
                }
            }
            if (speechIntent == null) speechIntent = buildSpeechIntent()
            speechRecognizer?.startListening(speechIntent)
        } catch (error: Exception) {
            jsCall("onNativeVoiceError", error.javaClass.simpleName)
        }
    }

    private fun stopNativeListening() {
        voiceSessionRequested = false
        pendingVoiceStart = false
        try { speechRecognizer?.cancel() } catch (_: Exception) { }
        jsCall("onNativeVoiceState", "OFF")
    }

    private inner class SpiderBridge {
        @JavascriptInterface
        fun startVoiceListening() {
            runOnUiThread {
                voiceSessionRequested = true
                startNativeListening()
            }
        }

        @JavascriptInterface
        fun stopVoiceListening() {
            runOnUiThread { stopNativeListening() }
        }

        @JavascriptInterface
        fun speak(message: String) {
            val safeMessage = message.take(500)
            runOnUiThread {
                if (!ttsReady || safeMessage.isBlank()) {
                    jsCall("onNativeSpeechDone")
                    return@runOnUiThread
                }
                val params = Bundle().apply { putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 1.0f) }
                textToSpeech?.speak(safeMessage, TextToSpeech.QUEUE_FLUSH, params, "spider-${System.currentTimeMillis()}")
            }
        }

        @JavascriptInterface
        fun stopSpeaking() {
            runOnUiThread { textToSpeech?.stop() }
        }

        @JavascriptInterface
        fun isAvailable(): Boolean = true
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            mediaRequestCode -> {
                val request = pendingMediaRequest
                if (request != null) {
                    val allowed = request.resources.filter { resource ->
                        when (resource) {
                            PermissionRequest.RESOURCE_VIDEO_CAPTURE -> hasPermission(Manifest.permission.CAMERA)
                            PermissionRequest.RESOURCE_AUDIO_CAPTURE -> hasPermission(Manifest.permission.RECORD_AUDIO)
                            else -> false
                        }
                    }
                    if (allowed.isNotEmpty()) request.grant(allowed.toTypedArray()) else request.deny()
                    pendingMediaRequest = null
                }
            }
            geoRequestCode -> {
                val origin = pendingGeoOrigin
                val callback = pendingGeoCallback
                if (origin != null && callback != null) callback.invoke(origin, hasLocationPermission(), false)
                pendingGeoOrigin = null
                pendingGeoCallback = null
            }
            voiceRequestCode -> {
                if (hasPermission(Manifest.permission.RECORD_AUDIO) && pendingVoiceStart) {
                    pendingVoiceStart = false
                    startNativeListening()
                } else {
                    pendingVoiceStart = false
                    voiceSessionRequested = false
                    jsCall("onNativeVoiceError", "PERMISSION_DENIED")
                }
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onResume() {
        super.onResume()
        applyImmersiveMode()
    }

    override fun onDestroy() {
        stopNativeListening()
        try { speechRecognizer?.destroy() } catch (_: Exception) { }
        speechRecognizer = null
        textToSpeech?.stop()
        textToSpeech?.shutdown()
        if (::webView.isInitialized) {
            webView.evaluateJavascript("window.spiderCleanup && window.spiderCleanup()", null)
            webView.destroy()
        }
        super.onDestroy()
    }
}
