package com.spidersystem.app

import android.Manifest
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.View
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import java.text.Normalizer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var hud: WebView
    private var tts: TextToSpeech? = null
    private var recognizer: SpeechRecognizer? = null
    private var listening = false
    private var muted = false
    private var ttsReady = false
    private var pageReady = false
    private var recognitionBusy = false
    private val handler = Handler(Looper.getMainLooper())

    private val restartRecognition = Runnable {
        if (listening && !isFinishing && !recognitionBusy) startRecognition()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = Color.rgb(2, 7, 17)
        window.navigationBarColor = Color.rgb(2, 7, 17)
        applyImmersiveMode()

        tts = TextToSpeech(this, this)

        hud = WebView(this).apply {
            setBackgroundColor(Color.rgb(2, 7, 17))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = false
            settings.javaScriptCanOpenWindowsAutomatically = false
            webChromeClient = WebChromeClient()
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    pageReady = true
                    pushState("INICIANDO", "Preparando los sistemas de voz.")
                }
            }
            addJavascriptInterface(VoiceBridge(), "Android")
        }
        setContentView(hud)
        hud.loadUrl("file:///android_asset/index.html")

        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            beginListening()
        } else {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQUEST_AUDIO)
        }
    }

    private fun applyImmersiveMode() {
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility =
            (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) applyImmersiveMode()
    }

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) {
            pushState("VOZ NO DISPONIBLE", "El motor de voz del dispositivo no pudo iniciarse.")
            return
        }
        val engine = tts
        val candidates = listOf(Locale("es", "PY"), Locale("es", "ES"), Locale("es"))
        ttsReady = candidates.any { locale ->
            val result = engine?.setLanguage(locale) ?: TextToSpeech.LANG_NOT_SUPPORTED
            result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED
        }
        if (ttsReady) speak("KAREN en línea. Sistemas principales activos.")
        else pushState("VOZ NO CONFIGURADA", "Instala datos de voz en español desde los ajustes del dispositivo.")
    }

    private fun beginListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            pushState("RECONOCIMIENTO NO DISPONIBLE", "Android no tiene un servicio de reconocimiento de voz disponible.")
            speak("No encuentro un servicio de reconocimiento de voz.")
            return
        }
        listening = true
        try {
            if (recognizer == null) recognizer = SpeechRecognizer.createSpeechRecognizer(this)
            recognizer?.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    recognitionBusy = true
                    pushState("ESCUCHANDO", "KAREN está escuchando.")
                }
                override fun onBeginningOfSpeech() {
                    pushState("TE ESCUCHO", "Procesando entrada de voz.")
                }
                override fun onRmsChanged(rmsdB: Float) { pushLevel(rmsdB) }
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {
                    pushState("PROCESANDO", "Interpretando instrucción.")
                }
                override fun onError(error: Int) {
                    recognitionBusy = false
                    if (listening) {
                        pushState("ESCUCHA EN ESPERA", errorMessage(error))
                        scheduleRestart(if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1200 else 700)
                    }
                }
                override fun onResults(results: Bundle?) {
                    recognitionBusy = false
                    val phrase = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull().orEmpty()
                    if (phrase.isNotBlank()) handleCommand(phrase)
                    scheduleRestart(550)
                }
                override fun onPartialResults(partialResults: Bundle?) {
                    val phrase = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()
                    if (!phrase.isNullOrBlank()) pushState("TE ESCUCHO", phrase)
                }
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            startRecognition()
        } catch (_: Exception) {
            pushState("ERROR DE VOZ", "No se pudo iniciar el reconocimiento.")
            scheduleRestart(1500)
        }
    }

    private fun startRecognition() {
        if (!listening || isFinishing || recognitionBusy) return
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-PY")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "es-PY")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, false)
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            }
            recognizer?.startListening(intent)
        } catch (_: Exception) {
            recognitionBusy = false
            scheduleRestart(1300)
        }
    }

    private fun scheduleRestart(delay: Long) {
        handler.removeCallbacks(restartRecognition)
        if (listening) handler.postDelayed(restartRecognition, delay)
    }

    private fun normalize(input: String): String {
        return Normalizer.normalize(input.lowercase(Locale.ROOT), Normalizer.Form.NFD)
            .replace(Regex("\\p{Mn}+"), "")
            .replace(Regex("[^a-z0-9 ]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    private fun handleCommand(raw: String) {
        val command = normalize(raw)
        val clean = command
            .removePrefix("oye karen").removePrefix("hey karen")
            .removePrefix("karen").trim()

        pushCommand(raw)
        if (clean.isBlank()) {
            speak("Dime, Peter.")
            return
        }

        when {
            containsAny(clean, "silencio", "callate", "modo silencio", "deja de hablar") -> {
                muted = true
                tts?.stop()
                pushState("MODO SILENCIO", "El reconocimiento sigue activo. Di KAREN, habla para reactivar mi voz.")
            }
            containsAny(clean, "reactiva voz", "karen habla", "vuelve a hablar", "habla") -> {
                muted = false
                speak("Voz reactivada. Te escucho.")
            }
            containsAny(clean, "ayuda", "lista de comandos", "que puedes hacer", "comandos") -> {
                speak("Puedo decirte la hora, la fecha y el estado del sistema. También puedo abrir la cámara y los ajustes. Di KAREN antes de una orden.")
            }
            containsAny(clean, "hora", "que hora es") -> {
                speak("Son las ${SimpleDateFormat("HH:mm", Locale("es", "PY")).format(Date())}.")
            }
            containsAny(clean, "fecha", "que dia es", "dia de hoy") -> {
                speak("Hoy es ${SimpleDateFormat("EEEE d 'de' MMMM", Locale("es", "PY")).format(Date())}.")
            }
            containsAny(clean, "estado", "como estas", "diagnostico", "sistemas") -> {
                speak("SPIDER SYSTEM operativo. Interfaz activa. Reconocimiento de voz conectado.")
            }
            containsAny(clean, "camara", "abre la camara") -> openCamera()
            containsAny(clean, "ajustes", "configuracion del telefono", "abre configuracion") -> openSettings()
            containsAny(clean, "reinicia escucha", "reanuda escucha", "vuelve a escuchar") -> {
                listening = true
                speak("Reconocimiento de voz activo.")
                scheduleRestart(300)
            }
            containsAny(clean, "hola", "buenos dias", "buenas tardes", "buenas noches") -> {
                speak("Hola, Peter. Estoy en línea.")
            }
            containsAny(clean, "quien eres", "identificate") -> {
                speak("Soy KAREN, el asistente de SPIDER SYSTEM. Estoy aquí para ayudarte.")
            }
            else -> speak("No reconocí esa orden. Di KAREN, ayuda, para consultar los comandos disponibles.")
        }
    }

    private fun containsAny(text: String, vararg values: String): Boolean = values.any { text.contains(it) }

    private fun pushCommand(raw: String) {
        val safe = org.json.JSONObject.quote(raw)
        runOnUiThread { if (::hud.isInitialized && pageReady) hud.evaluateJavascript("window.setCommand($safe)", null) }
    }

    private fun pushLevel(level: Float) {
        val value = ((level + 2f) / 12f).coerceIn(0f, 1f)
        runOnUiThread { if (::hud.isInitialized && pageReady) hud.evaluateJavascript("window.setVoiceLevel($value)", null) }
    }

    private fun pushState(state: String, message: String) {
        if (!::hud.isInitialized) return
        val s = org.json.JSONObject.quote(state)
        val m = org.json.JSONObject.quote(message)
        runOnUiThread { if (pageReady) hud.evaluateJavascript("window.setSystemState($s,$m)", null) }
    }

    private fun speak(message: String) {
        pushState("KAREN", message)
        if (!muted && ttsReady) {
            tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "karen-${System.currentTimeMillis()}")
        }
    }

    private fun openCamera() {
        try {
            startActivity(Intent("android.media.action.IMAGE_CAPTURE"))
            speak("Abriendo cámara.")
        } catch (_: ActivityNotFoundException) {
            speak("No encuentro una aplicación de cámara.")
        }
    }

    private fun openSettings() {
        try {
            startActivity(Intent(android.provider.Settings.ACTION_SETTINGS))
            speak("Abriendo ajustes.")
        } catch (_: Exception) {
            speak("No pude abrir los ajustes.")
        }
    }

    private fun errorMessage(error: Int): String = when (error) {
        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "No hay conexión con el servicio de voz."
        SpeechRecognizer.ERROR_AUDIO -> "No se pudo procesar el audio."
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Falta permiso de micrófono."
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "El servicio de voz está ocupado."
        SpeechRecognizer.ERROR_NO_MATCH -> "No detecté una frase clara."
        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No recibí voz."
        else -> "El reconocimiento se interrumpió."
    }

    inner class VoiceBridge {
        @JavascriptInterface fun ready() {
            runOnUiThread {
                pushState("SISTEMA INICIADO", "HUD cargado. KAREN está preparando la escucha.")
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_AUDIO && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            beginListening()
        } else {
            pushState("MICRÓFONO BLOQUEADO", "Activa el permiso de micrófono para usar comandos de voz.")
        }
    }

    override fun onPause() {
        super.onPause()
        recognitionBusy = false
        try { recognizer?.cancel() } catch (_: Exception) {}
    }

    override fun onResume() {
        super.onResume()
        applyImmersiveMode()
        if (listening && recognizer != null) scheduleRestart(700)
    }

    override fun onDestroy() {
        listening = false
        handler.removeCallbacksAndMessages(null)
        try { recognizer?.destroy() } catch (_: Exception) {}
        recognizer = null
        tts?.stop()
        tts?.shutdown()
        tts = null
        if (::hud.isInitialized) hud.destroy()
        super.onDestroy()
    }

    companion object {
        private const val REQUEST_AUDIO = 41
    }
}
