package com.celtickingdoms.app;

import android.app.Activity;
import android.os.Bundle;
import android.view.Window;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        WebView w = new WebView(this);
        w.setWebViewClient(new WebViewClient());
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setLoadWithOverviewMode(false);
        w.setOverScrollMode(WebView.OVER_SCROLL_NEVER);
        setContentView(w);
        w.loadUrl("file:///android_asset/index.html");
    }
    @Override public void onBackPressed() {
        WebView w=(WebView)findViewById(android.R.id.content).getRootView();
        super.onBackPressed();
    }
}