package com.aiko.assistente;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.AlarmClock;
import android.provider.CalendarContract;
import android.provider.Settings;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.webkit.WebViewAssetLoader;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.FutureTask;
import java.util.concurrent.TimeUnit;

/**
 * Aiko: hospeda a página da assistente num WebView e expõe a ponte "AikoAndroid".
 * Cada método da ponte devolve uma String: "ok", "ok:texto" ou "err:motivo".
 */
public class MainActivity extends Activity {

    private static final String HOST = "appassets.androidplatform.net";
    private static final String API_PREFIX = "https://api.anthropic.com/";
    private static final int REQ_MIC = 11;
    private static final int REQ_FILE = 12;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private WebView web;

    private TextToSpeech tts;
    private boolean ttsReady = false;

    private SpeechRecognizer recognizer;
    private boolean srEnded = true;

    private ValueCallback<Uri[]> fileCallback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        web = new WebView(this);
        web.setBackgroundColor(0xFFEAF1F3);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .setDomain(HOST)
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (HOST.equals(u.getHost())) return false;
                openExternal(u);
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
                pick.addCategory(Intent.CATEGORY_OPENABLE);
                pick.setType("*/*");
                try {
                    startActivityForResult(Intent.createChooser(pick, "Escolher arquivo"), REQ_FILE);
                } catch (Exception e) {
                    fileCallback = null;
                    callback.onReceiveValue(null);
                }
                return true;
            }
        });

        web.addJavascriptInterface(new Bridge(), "AikoAndroid");
        initTts();
        web.loadUrl("https://" + HOST + "/assets/index.html");
    }

    @Override
    protected void onDestroy() {
        try {
            if (recognizer != null) recognizer.destroy();
        } catch (Exception ignored) {
        }
        try {
            if (tts != null) {
                tts.stop();
                tts.shutdown();
            }
        } catch (Exception ignored) {
        }
        if (web != null) web.destroy();
        super.onDestroy();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_FILE && fileCallback != null) {
            Uri[] result = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            fileCallback.onReceiveValue(result);
            fileCallback = null;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_MIC) {
            boolean ok = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            if (ok) {
                startRecognizer();
            } else {
                jsSr("error", "perm");
                jsSr("end", "");
            }
        }
    }

    /* ------------------------------------------------------------ helpers */

    private void js(final String code) {
        ui.post(new Runnable() {
            @Override
            public void run() {
                if (web != null) web.evaluateJavascript(code, null);
            }
        });
    }

    private void jsSr(String kind, String text) {
        js("window.__aikoSR&&window.__aikoSR(" + JSONObject.quote(kind) + "," + JSONObject.quote(text) + ")");
    }

    private void jsTts(String id, String kind) {
        js("window.__aikoTTS&&window.__aikoTTS(" + JSONObject.quote(id) + "," + JSONObject.quote(kind) + ")");
    }

    /** Roda na thread principal e espera o resultado (a ponte do WebView roda em outra thread). */
    private String onUi(Callable<String> job) {
        FutureTask<String> task = new FutureTask<String>(job);
        ui.post(task);
        try {
            return task.get(6, TimeUnit.SECONDS);
        } catch (Exception e) {
            return "err:" + e.getClass().getSimpleName();
        }
    }

    private static String norm(String s) {
        if (s == null) return "";
        String n = Normalizer.normalize(s, Normalizer.Form.NFD).replaceAll("\\p{M}+", "");
        return n.toLowerCase(Locale.ROOT).trim();
    }

    private String launch(Intent intent) {
        try {
            startActivity(intent);
            return "ok";
        } catch (ActivityNotFoundException e) {
            return "err:noapp";
        } catch (SecurityException e) {
            return "err:perm";
        } catch (Exception e) {
            return "err:" + e.getClass().getSimpleName();
        }
    }

    private void openExternal(Uri u) {
        String sc = u.getScheme() == null ? "" : u.getScheme().toLowerCase(Locale.ROOT);
        if (sc.equals("http") || sc.equals("https") || sc.equals("tel")
                || sc.equals("sms") || sc.equals("smsto") || sc.equals("mailto") || sc.equals("geo")) {
            launch(new Intent(Intent.ACTION_VIEW, u));
        }
    }

    /* ---------------------------------------------------------------- TTS */

    private void initTts() {
        tts = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status != TextToSpeech.SUCCESS) return;
                ttsReady = true;
                try {
                    tts.setLanguage(new Locale("pt", "BR"));
                } catch (Exception ignored) {
                }
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override
                    public void onStart(String utteranceId) {
                        jsTts(utteranceId, "start");
                    }

                    @Override
                    public void onDone(String utteranceId) {
                        jsTts(utteranceId, "done");
                    }

                    @Override
                    public void onError(String utteranceId) {
                        jsTts(utteranceId, "error");
                    }

                    @Override
                    public void onError(String utteranceId, int errorCode) {
                        jsTts(utteranceId, "error");
                    }
                });
            }
        });
    }

    /* ----------------------------------------------------------------- SR */

    private void endSr() {
        if (!srEnded) {
            srEnded = true;
            jsSr("end", "");
        }
    }

    private static String firstResult(Bundle b) {
        if (b == null) return "";
        ArrayList<String> list = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        return (list == null || list.isEmpty()) ? "" : list.get(0);
    }

    private void startRecognizer() {
        if (recognizer != null) {
            srEnded = true;
            try {
                recognizer.destroy();
            } catch (Exception ignored) {
            }
            recognizer = null;
        }
        recognizer = SpeechRecognizer.createSpeechRecognizer(this);
        srEnded = false;
        recognizer.setRecognitionListener(new RecognitionListener() {
            @Override
            public void onReadyForSpeech(Bundle params) {
                jsSr("start", "");
            }

            @Override
            public void onBeginningOfSpeech() {
            }

            @Override
            public void onRmsChanged(float rmsdB) {
            }

            @Override
            public void onBufferReceived(byte[] buffer) {
            }

            @Override
            public void onEndOfSpeech() {
            }

            @Override
            public void onError(int error) {
                if (error == SpeechRecognizer.ERROR_NETWORK
                        || error == SpeechRecognizer.ERROR_NETWORK_TIMEOUT
                        || error == SpeechRecognizer.ERROR_SERVER) {
                    jsSr("error", "network");
                } else if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                    jsSr("error", "perm");
                }
                endSr();
            }

            @Override
            public void onResults(Bundle results) {
                String t = firstResult(results);
                if (!t.isEmpty()) jsSr("final", t);
                endSr();
            }

            @Override
            public void onPartialResults(Bundle partialResults) {
                String t = firstResult(partialResults);
                if (!t.isEmpty()) jsSr("partial", t);
            }

            @Override
            public void onEvent(int eventType, Bundle params) {
            }
        });

        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR");
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getPackageName());
        recognizer.startListening(i);
    }

    /* ------------------------------------------------------------- bridge */

    public final class Bridge {

        /* ---- voz: falar ---- */

        @JavascriptInterface
        public String ttsSpeak(final String id, final String text, final double pitch,
                               final double rate, final String voiceName) {
            return onUi(new Callable<String>() {
                @Override
                public String call() {
                    if (!ttsReady) return "err:notready";
                    try {
                        tts.setLanguage(new Locale("pt", "BR"));
                        if (voiceName != null && !voiceName.isEmpty()) {
                            Set<Voice> voices = tts.getVoices();
                            if (voices != null) {
                                for (Voice v : voices) {
                                    if (voiceName.equals(v.getName())) {
                                        tts.setVoice(v);
                                        break;
                                    }
                                }
                            }
                        }
                        tts.setPitch((float) pitch);
                        tts.setSpeechRate((float) rate);
                        int r = tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, id);
                        return r == TextToSpeech.SUCCESS ? "ok" : "err:speak";
                    } catch (Exception e) {
                        return "err:" + e.getClass().getSimpleName();
                    }
                }
            });
        }

        @JavascriptInterface
        public String ttsStop() {
            return onUi(new Callable<String>() {
                @Override
                public String call() {
                    try {
                        if (tts != null) tts.stop();
                    } catch (Exception ignored) {
                    }
                    return "ok";
                }
            });
        }

        @JavascriptInterface
        public String ttsVoices() {
            JSONArray out = new JSONArray();
            try {
                if (!ttsReady) return "[]";
                Set<Voice> voices = tts.getVoices();
                if (voices == null) return "[]";
                List<Voice> pt = new ArrayList<Voice>();
                for (Voice v : voices) {
                    if ("pt".equals(v.getLocale().getLanguage())) pt.add(v);
                }
                java.util.Collections.sort(pt, new java.util.Comparator<Voice>() {
                    @Override
                    public int compare(Voice a, Voice b) {
                        boolean ab = "BR".equals(a.getLocale().getCountry());
                        boolean bb = "BR".equals(b.getLocale().getCountry());
                        if (ab != bb) return ab ? -1 : 1;
                        return a.getName().compareTo(b.getName());
                    }
                });
                for (Voice v : pt) {
                    JSONObject o = new JSONObject();
                    o.put("name", v.getName());
                    o.put("lang", v.getLocale().toLanguageTag());
                    out.put(o);
                }
            } catch (Exception e) {
                return "[]";
            }
            return out.toString();
        }

        /* ---- voz: ouvir ---- */

        @JavascriptInterface
        public String srStart() {
            return onUi(new Callable<String>() {
                @Override
                public String call() {
                    if (!SpeechRecognizer.isRecognitionAvailable(MainActivity.this)) {
                        jsSr("error", "unavailable");
                        return "ok:unavailable";
                    }
                    if (Build.VERSION.SDK_INT >= 23
                            && checkSelfPermission(Manifest.permission.RECORD_AUDIO)
                            != PackageManager.PERMISSION_GRANTED) {
                        requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
                        return "ok:perm";
                    }
                    try {
                        startRecognizer();
                        return "ok";
                    } catch (Exception e) {
                        return "err:" + e.getClass().getSimpleName();
                    }
                }
            });
        }

        @JavascriptInterface
        public String srStop() {
            return onUi(new Callable<String>() {
                @Override
                public String call() {
                    try {
                        if (recognizer != null) recognizer.stopListening();
                    } catch (Exception ignored) {
                    }
                    return "ok";
                }
            });
        }

        /* ---- alarme, timer, agenda ---- */

        @JavascriptInterface
        public String setAlarm(final int hour, final int minute, final String label) {
            return onUi(new Callable<String>() {
                @Override
                public String call() {
                    Intent i = new Intent(AlarmClock.ACTION_SET_ALARM);
                    i.putExtra(AlarmClock.EXTRA_HOUR, hour);
                    i.putExtra(AlarmClock.EXTRA_MINUTES, minute);
                    i.putExtra(AlarmClock.EXTRA_MESSAGE, (label == null || label.isEmpty()) ? "Aiko" : label);
                    i.putExtra(AlarmClock.EXTRA_SKIP_UI, true);
                    return launch(i);
                }
            });
        }

        @JavascriptInterface
        public String setTimer(final int seconds, final String label) {
            return onUi(new Callable<String>() {
                @Override
                public String call() {
                    Intent i = new Intent(AlarmClock.ACTION_SET_TIMER);
                    i.putExtra(AlarmClock.EXTRA_LENGTH, seconds);
                    i.putExtra(AlarmClock.EXTRA_MESSAGE, (label == null || label.isEmpty()) ? "Timer" : label);
                    i.putExtra(AlarmClock.EXTRA_SKIP_UI, true);
                    return launch(i);
                }
            });
        }

        @JavascriptInterface
        public String addEvent(final String title, final String startMs, final String endMs, final String place) {
            return onUi(new Callable<String>() {
                @Override
                public String call() {
                    long start;
                    long end;
                    try {
                        start = Long.parseLong(startMs);
                        end = Long.parseLong(endMs);
                    } catch (NumberFormatException e) {
                        return "err:args";
                    }
                    Intent i = new Intent(Intent.ACTION_INSERT);
                    i.setData(CalendarContract.Events.CONTENT_URI);
                    i.putExtra(CalendarContract.Events.TITLE, title == null ? "" : title);
                    i.putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, start);
                    i.putExtra(CalendarContract.EXTRA_EVENT_END_TIME, end);
                    if (place != null && !place.isEmpty()) {
                        i.putExtra(CalendarContract.Events.EVENT_LOCATION, place);
                    }
                    return launch(i);
                }
            });
        }

        /* ---- apps, links, mapas ---- */

        @JavascriptInterface
        public String openApp(final String name) {
            return onUi(new Callable<String>() {
                @Override
                public String call() {
                    PackageManager pm = getPackageManager();
                    Intent q = new Intent(Intent.ACTION_MAIN);
                    q.addCategory(Intent.CATEGORY_LAUNCHER);
                    List<ResolveInfo> apps = pm.queryIntentActivities(q, 0);
                    String key = norm(name);
                    if (key.isEmpty()) return "err:notfound";
                    ResolveInfo best = null;
                    int bestScore = 0;
                    for (ResolveInfo r : apps) {
                        String label = norm(String.valueOf(r.loadLabel(pm)));
                        int score = 0;
                        if (label.equals(key)) score = 3;
                        else if (label.startsWith(key)) score = 2;
                        else if (label.contains(key) || (label.length() >= 3 && key.contains(label))) score = 1;
                        if (score > bestScore) {
                            bestScore = score;
                            best = r;
                        }
                    }
                    if (best == null) return "err:notfound";
                    Intent li = pm.getLaunchIntentForPackage(best.activityInfo.packageName);
                    if (li == null) return "err:notfound";
                    String shown = String.valueOf(best.loadLabel(pm));
                    String r = launch(li);
                    return "ok".equals(r) ? "ok:" + shown : r;
                }
            });
        }

        @JavascriptInterface
        public String openUrl(final String url) {
            return onUi(new Callable<String>() {
                @Override
                public String call() {
                    Uri u = Uri.parse(url == null ? "" : url);
                    String sc = u.getScheme() == null ? "" : u.getScheme().toLowerCase(Locale.ROOT);
                    if (!(sc.equals("http") || sc.equals("https") || sc.equals("geo"))) return "err:scheme";
                    return launch(new Intent(Intent.ACTION_VIEW, u));
                }
            });
        }

        @JavascriptInterface
        public String navigate(final String place) {
            return onUi(new Callable<String>() {
                @Override
                public String call() {
                    Uri u = Uri.parse("https://www.google.com/maps/dir/?api=1&destination=" + Uri.encode(place == null ? "" : place));
                    return launch(new Intent(Intent.ACTION_VIEW, u));
                }
            });
        }

        /* ---- ligação e SMS: só abrem a tela, quem confirma é a pessoa ---- */

        @JavascriptInterface
        public String dial(final String number) {
            return onUi(new Callable<String>() {
                @Override
                public String call() {
                    String n = number == null ? "" : number.replaceAll("[^0-9+]", "");
                    if (n.isEmpty()) return "err:args";
                    return launch(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(n))));
                }
            });
        }

        @JavascriptInterface
        public String sms(final String number, final String body) {
            return onUi(new Callable<String>() {
                @Override
                public String call() {
                    String n = number == null ? "" : number.replaceAll("[^0-9+]", "");
                    if (n.isEmpty()) return "err:args";
                    Intent i = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(n)));
                    i.putExtra("sms_body", body == null ? "" : body);
                    return launch(i);
                }
            });
        }

        /* ---- lanterna e configurações ---- */

        @JavascriptInterface
        public String flashlight(final boolean on) {
            return onUi(new Callable<String>() {
                @Override
                public String call() {
                    try {
                        CameraManager cm = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
                        for (String id : cm.getCameraIdList()) {
                            CameraCharacteristics c = cm.getCameraCharacteristics(id);
                            Boolean flash = c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                            Integer facing = c.get(CameraCharacteristics.LENS_FACING);
                            if (Boolean.TRUE.equals(flash) && facing != null
                                    && facing == CameraCharacteristics.LENS_FACING_BACK) {
                                cm.setTorchMode(id, on);
                                return "ok";
                            }
                        }
                        return "err:noflash";
                    } catch (Exception e) {
                        return "err:" + e.getClass().getSimpleName();
                    }
                }
            });
        }

        @JavascriptInterface
        public String settings(final String what) {
            return onUi(new Callable<String>() {
                @Override
                public String call() {
                    String w = what == null ? "" : what;
                    String action;
                    if (w.equals("wifi")) action = Settings.ACTION_WIFI_SETTINGS;
                    else if (w.equals("bluetooth")) action = Settings.ACTION_BLUETOOTH_SETTINGS;
                    else if (w.equals("aviao")) action = Settings.ACTION_AIRPLANE_MODE_SETTINGS;
                    else if (w.equals("bateria")) action = Settings.ACTION_BATTERY_SAVER_SETTINGS;
                    else if (w.equals("localizacao")) action = Settings.ACTION_LOCATION_SOURCE_SETTINGS;
                    else if (w.equals("som")) action = Settings.ACTION_SOUND_SETTINGS;
                    else if (w.equals("brilho") || w.equals("tela")) action = Settings.ACTION_DISPLAY_SETTINGS;
                    else action = Settings.ACTION_SETTINGS;
                    return launch(new Intent(action));
                }
            });
        }

        /* ---- rede: só para a API da Anthropic, para a conversa por IA ---- */

        @JavascriptInterface
        public String httpPost(final String id, final String url, final String headersJson, final String body) {
            if (url == null || !url.startsWith(API_PREFIX)) return "err:host";
            new Thread(new Runnable() {
                @Override
                public void run() {
                    int status = 0;
                    String text;
                    HttpURLConnection c = null;
                    try {
                        c = (HttpURLConnection) new URL(url).openConnection();
                        c.setRequestMethod("POST");
                        c.setConnectTimeout(15000);
                        c.setReadTimeout(90000);
                        c.setDoOutput(true);
                        JSONObject h = new JSONObject(headersJson == null ? "{}" : headersJson);
                        Iterator<String> keys = h.keys();
                        while (keys.hasNext()) {
                            String k = keys.next();
                            c.setRequestProperty(k, h.getString(k));
                        }
                        OutputStream os = c.getOutputStream();
                        os.write((body == null ? "" : body).getBytes(StandardCharsets.UTF_8));
                        os.close();
                        status = c.getResponseCode();
                        InputStream is = status >= 400 ? c.getErrorStream() : c.getInputStream();
                        ByteArrayOutputStream bo = new ByteArrayOutputStream();
                        if (is != null) {
                            byte[] buf = new byte[4096];
                            int n;
                            while ((n = is.read(buf)) > 0) bo.write(buf, 0, n);
                            is.close();
                        }
                        text = new String(bo.toByteArray(), StandardCharsets.UTF_8);
                    } catch (JSONException e) {
                        status = 0;
                        text = "cabecalhos invalidos";
                    } catch (Exception e) {
                        status = 0;
                        text = String.valueOf(e.getMessage());
                    } finally {
                        if (c != null) c.disconnect();
                    }
                    js("window.__aikoNet&&window.__aikoNet(" + JSONObject.quote(id) + "," + status
                            + "," + JSONObject.quote(text) + ")");
                }
            }).start();
            return "ok";
        }
    }
}
