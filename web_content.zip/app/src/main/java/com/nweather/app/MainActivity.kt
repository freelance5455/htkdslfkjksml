package com.nweather.app

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.os.Bundle
import android.webkit.GeolocationPermissions
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import org.json.JSONObject

/** Full N Weather UI (assets/index.html) inside a WebView; pushes weather to the home-screen widget. */
class MainActivity : Activity() {
    private lateinit var web: WebView

    class Bridge(private val c: Context) {
        @JavascriptInterface fun save(json: String) {
            val o = JSONObject(json); val p = WeatherRepo.prefs(c)
            val name = o.getString("name"); val tc = o.getDouble("tc").toFloat(); val code = o.getInt("code"); val day = o.getInt("day")
            val hi = o.getDouble("hi").toFloat(); val lo = o.getDouble("lo").toFloat(); val unit = o.getString("unit")
            val same = p.getString("name", "") == name && p.getFloat("tc", -999f) == tc && p.getInt("code", -1) == code &&
                p.getInt("day", -1) == day && p.getFloat("hi", -999f) == hi && p.getFloat("lo", -999f) == lo && p.getString("unit", "") == unit
            p.edit().putString("name", name).putFloat("lat", o.getDouble("lat").toFloat()).putFloat("lon", o.getDouble("lon").toFloat())
                .putFloat("tc", tc).putInt("code", code).putInt("day", day).putFloat("hi", hi).putFloat("lo", lo)
                .putString("unit", unit).putLong("t", System.currentTimeMillis()).apply()
            if (!same) WeatherWidget.refresh(c)   // no widget redraw when nothing changed
        }
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.statusBarColor = 0xFF071A3A.toInt()
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(applicationContext), "NWBridge")
        web.webChromeClient = object : WebChromeClient() {
            override fun onGeolocationPermissionsShowPrompt(o: String?, cb: GeolocationPermissions.Callback?) {
                val ok = checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
                if (!ok) requestPermissions(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION), 1)
                cb?.invoke(o, ok, false)
            }
        }
        web.loadUrl("file:///android_asset/index.html")
        WeatherWorker.schedule(this)
    }

    // WebView does nothing while the app is in the background: no timers, no animation, no CPU.
    override fun onPause() { web.onPause(); web.pauseTimers(); super.onPause() }
    override fun onResume() { super.onResume(); web.onResume(); web.resumeTimers() }
    override fun onDestroy() { web.destroy(); super.onDestroy() }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (web.canGoBack()) web.goBack() else super.onBackPressed() }
}
