package com.nweather.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.widget.RemoteViews

class WeatherWidget : AppWidgetProvider() {
    override fun onEnabled(c: Context) { WeatherWorker.schedule(c) }
    override fun onDisabled(c: Context) { WeatherWorker.cancel(c) }
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) { draw(c, m, ids) }

    companion object {
        fun refresh(c: Context) {
            val m = AppWidgetManager.getInstance(c)
            draw(c, m, m.getAppWidgetIds(ComponentName(c, WeatherWidget::class.java)))
        }

        private fun deg(p: SharedPreferences, k: String): String {
            val v = p.getFloat(k, 0f)
            return "${Math.round(if (p.getString("unit", "c") == "f") v * 9 / 5 + 32 else v)}°"
        }

        private fun icon(code: Int, day: Boolean) = when {
            code == 0 -> if (day) R.drawable.ic_w_sun else R.drawable.ic_w_moon
            code < 3 -> if (day) R.drawable.ic_w_pcd else R.drawable.ic_w_pcn
            code == 3 -> R.drawable.ic_w_cloud
            code < 50 -> R.drawable.ic_w_fog
            code < 58 -> R.drawable.ic_w_drizzle
            code < 68 || code in 80..82 -> R.drawable.ic_w_rain
            code < 78 || code == 85 || code == 86 -> R.drawable.ic_w_snow
            code >= 95 -> R.drawable.ic_w_storm
            else -> R.drawable.ic_w_cloud
        }

        private fun draw(c: Context, m: AppWidgetManager, ids: IntArray) {
            val p = WeatherRepo.prefs(c)
            val v = RemoteViews(c.packageName, R.layout.widget_weather)
            if (p.contains("tc")) {
                val day = p.getInt("day", 1) == 1
                v.setTextViewText(R.id.city, p.getString("name", "N Weather"))
                v.setImageViewResource(R.id.icon, icon(p.getInt("code", 2), day))
                v.setTextViewText(R.id.temp, deg(p, "tc"))
                v.setTextViewText(R.id.hl, "H ${deg(p, "hi")}  L ${deg(p, "lo")}")
                v.setInt(R.id.root, "setBackgroundResource", if (day) R.drawable.widget_bg_day else R.drawable.widget_bg_night)
            }
            val pi = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            v.setOnClickPendingIntent(R.id.root, pi)
            ids.forEach { m.updateAppWidget(it, v) }
        }
    }
}
