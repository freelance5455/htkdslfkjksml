package com.nweather.app

import android.content.Context
import androidx.work.*
import java.util.concurrent.TimeUnit

class WeatherWorker(c: Context, p: WorkerParameters) : CoroutineWorker(c, p) {
    override suspend fun doWork(): Result {
        val c = applicationContext
        if (!WeatherRepo.shouldFetch(c)) return Result.success()   // fresh / night / Data Saver: no network at all
        val ok = WeatherRepo.fetch(c)
        if (ok) WeatherWidget.refresh(c)
        return if (ok || runAttemptCount >= 2) Result.success() else Result.retry()
    }

    companion object {
        /** ~Every 90 min (flex window lets Android batch it with other jobs), only with network and OK battery. */
        fun schedule(c: Context) {
            val cons = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .setRequiresBatteryNotLow(true).build()
            val req = PeriodicWorkRequestBuilder<WeatherWorker>(90, TimeUnit.MINUTES, 30, TimeUnit.MINUTES)
                .setConstraints(cons)
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 15, TimeUnit.MINUTES).build()
            WorkManager.getInstance(c).enqueueUniquePeriodicWork("nw_refresh", ExistingPeriodicWorkPolicy.UPDATE, req)
        }
        fun cancel(c: Context) = WorkManager.getInstance(c).cancelUniqueWork("nw_refresh")
    }
}
