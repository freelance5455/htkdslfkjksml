package com.nweather.app

import android.content.Context
import android.net.ConnectivityManager
import java.util.Calendar
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object WeatherRepo {
    fun prefs(c: Context) = c.getSharedPreferences("nw", Context.MODE_PRIVATE)

    /** Skip the network when data is fresh, at night (00-05h), or when Data Saver restricts background use. */
    fun shouldFetch(c: Context): Boolean {
        val age = System.currentTimeMillis() - prefs(c).getLong("t", 0L)
        if (age < 45 * 60_000L) return false
        if (Calendar.getInstance().get(Calendar.HOUR_OF_DAY) in 0..4 && age < 4 * 3600_000L) return false
        val cm = c.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        if (cm.isActiveNetworkMetered && cm.restrictBackgroundStatus == ConnectivityManager.RESTRICT_BACKGROUND_STATUS_ENABLED) return false
        return true
    }

    /** One tiny request (~1 KB), uses the place chosen inside the app. */
    fun fetch(c: Context): Boolean = try {
        val p = prefs(c)
        val lat = p.getFloat("lat", 23.81f); val lon = p.getFloat("lon", 90.41f)
        val u = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
            "&current=temperature_2m,weather_code,is_day&daily=temperature_2m_max,temperature_2m_min&forecast_days=1&timezone=auto"
        val con = URL(u).openConnection() as HttpURLConnection
        con.connectTimeout = 10000; con.readTimeout = 10000
        val j = JSONObject(con.inputStream.bufferedReader().use { it.readText() })
        val cur = j.getJSONObject("current"); val d = j.getJSONObject("daily")
        p.edit().putFloat("tc", cur.getDouble("temperature_2m").toFloat())
            .putInt("code", cur.getInt("weather_code")).putInt("day", cur.getInt("is_day"))
            .putFloat("hi", d.getJSONArray("temperature_2m_max").getDouble(0).toFloat())
            .putFloat("lo", d.getJSONArray("temperature_2m_min").getDouble(0).toFloat())
            .putLong("t", System.currentTimeMillis()).apply()
        true
    } catch (e: Exception) { false }
}
