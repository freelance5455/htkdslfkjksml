package com.aura.music

import android.app.PendingIntent
import android.content.Intent
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

@UnstableApi
class PlaybackService : MediaSessionService() {
    private var player: ExoPlayer? = null
    private var session: MediaSession? = null

    override fun onCreate() {
        super.onCreate()
        MainActivity.PlaybackHolder.service = this
        createPlayer(emptyMap())
    }

    private fun createPlayer(headers: Map<String,String>) {
        session?.release(); player?.release()
        val http = DefaultHttpDataSource.Factory().setAllowCrossProtocolRedirects(true)
        if (headers.isNotEmpty()) http.setDefaultRequestProperties(headers)
        val p = ExoPlayer.Builder(this).setMediaSourceFactory(DefaultMediaSourceFactory(http)).build()
        player = p
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        session = MediaSession.Builder(this, p).setSessionActivity(pi).build()
    }

    fun playResolved(url: String, title: String, artist: String, artwork: String, headers: Map<String,String>) {
        createPlayer(headers)
        val metadata = MediaMetadata.Builder().setTitle(title).setArtist(artist).setArtworkUri(if (artwork.isBlank()) null else android.net.Uri.parse(artwork)).build()
        player!!.setMediaItem(MediaItem.Builder().setUri(url).setMediaMetadata(metadata).build())
        player!!.prepare(); player!!.play()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session
    override fun onDestroy() { MainActivity.PlaybackHolder.service = null; session?.release(); player?.release(); super.onDestroy() }
}
