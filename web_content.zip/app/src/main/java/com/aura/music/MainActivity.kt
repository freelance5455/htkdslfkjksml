package com.aura.music

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import org.json.JSONObject

@UnstableApi
class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private var controller: MediaController? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!Python.isStarted()) Python.start(AndroidPlatform(this))
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.webViewClient = WebViewClient()
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(NativeBridge(), "AuraNative")
        web.loadUrl("file:///android_asset/index.html")
        setContentView(web)
        val token = SessionToken(this, android.content.ComponentName(this, PlaybackService::class.java))
        val future = MediaController.Builder(this, token).buildAsync()
        future.addListener({ controller = future.get() }, androidx.core.content.ContextCompat.getMainExecutor(this))
    }

    inner class NativeBridge {
        private val py get() = Python.getInstance().getModule("aura_backend")

        @JavascriptInterface fun search(q: String): String = try { py.callAttr("search", q, 25).toString() } catch (e: Exception) { JSONObject().put("error", e.message ?: "Error").toString() }

        @JavascriptInterface fun lyrics(videoId: String): String = try { py.callAttr("lyrics", videoId).toString() } catch (e: Exception) { JSONObject().put("error", e.message ?: "Error").toString() }

        @JavascriptInterface fun play(videoId: String, title: String, artist: String, artwork: String): String {
            return try {
                val obj = JSONObject(py.callAttr("resolve", videoId).toString())
                val headers = mutableMapOf<String,String>()
                val h = obj.optJSONObject("headers")
                if (h != null) h.keys().forEach { k -> headers[k] = h.optString(k) }
                val svc = PlaybackHolder.service
                if (svc != null) svc.playResolved(obj.getString("url"), title, artist, artwork, headers)
                else {
                    // The service is started on demand so playback survives the Activity.
                    val intent = android.content.Intent(this@MainActivity, PlaybackService::class.java)
                    androidx.core.content.ContextCompat.startForegroundService(this@MainActivity, intent)
                    web.postDelayed({ PlaybackHolder.service?.playResolved(obj.getString("url"), title, artist, artwork, headers) }, 500)
                }
                JSONObject().put("ok", true).toString()
            } catch (e: Exception) { JSONObject().put("ok", false).put("error", e.message ?: "No se pudo reproducir").toString() }
        }
        @JavascriptInterface fun pause() { controller?.pause() }
        @JavascriptInterface fun resume() { controller?.play() }
        @JavascriptInterface fun seek(ms: Long) { controller?.seekTo(ms) }
    }

    override fun onDestroy() { controller?.release(); super.onDestroy() }

    object PlaybackHolder { var service: PlaybackService? = null }
}
