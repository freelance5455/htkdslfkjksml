package com.capri.mobile;
import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.*;
import android.view.*;
import android.widget.*;
import android.graphics.drawable.GradientDrawable;
import android.content.Context;
import android.os.*;
import android.graphics.*;
import android.provider.MediaStore;
import android.content.ContentValues;
import java.io.OutputStream;
public class CapriAccessibilityService extends AccessibilityService {
 public static CapriAccessibilityService live;
 WindowManager wm; View floater; WindowManager.LayoutParams floaterParams;
 public void onServiceConnected(){live=this;showCapriFloater();}
 void showCapriFloater(){
  try{
   wm=(WindowManager)getSystemService(WINDOW_SERVICE);
   TextView face=new TextView(this);face.setText("✦");face.setTextColor(Color.BLACK);face.setTextSize(29);face.setGravity(Gravity.CENTER);
   GradientDrawable bg=new GradientDrawable();bg.setShape(GradientDrawable.OVAL);bg.setColor(0xfffff329);bg.setStroke(dp(3),0xffff174f);face.setBackground(bg);
   face.setElevation(dp(12));face.setContentDescription("Capri floating assistant — drag to move, tap to open");
   floaterParams=new WindowManager.LayoutParams(dp(62),dp(62),WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN|WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
    PixelFormat.TRANSLUCENT);
   floaterParams.gravity=Gravity.TOP|Gravity.END;floaterParams.x=dp(12);floaterParams.y=dp(190);
   face.setOnTouchListener(new View.OnTouchListener(){float sx,sy;int ox,oy;boolean moved;
    public boolean onTouch(View v,MotionEvent e){switch(e.getAction()){
     case MotionEvent.ACTION_DOWN:sx=e.getRawX();sy=e.getRawY();ox=floaterParams.x;oy=floaterParams.y;moved=false;return true;
     case MotionEvent.ACTION_MOVE:float dx=e.getRawX()-sx,dy=e.getRawY()-sy;if(Math.abs(dx)+Math.abs(dy)>dp(6))moved=true;floaterParams.x=Math.max(0,ox-(int)dx);floaterParams.y=Math.max(0,oy+(int)dy);wm.updateViewLayout(floater,floaterParams);return true;
     case MotionEvent.ACTION_UP:if(!moved){Intent i=new Intent(CapriAccessibilityService.this,MainActivity.class);i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);startActivity(i);}return true;
    }return true;}
   });
   floater=face;wm.addView(floater,floaterParams);
  }catch(Exception ignored){}
 }
 int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
 public void onAccessibilityEvent(AccessibilityEvent e){} public void onInterrupt(){}
 public void onDestroy(){try{if(wm!=null&&floater!=null)wm.removeView(floater);}catch(Exception ignored){}if(live==this)live=null;super.onDestroy();}
 public boolean typeText(String s){AccessibilityNodeInfo r=getRootInActiveWindow();if(r==null)return false;AccessibilityNodeInfo n=r.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);boolean ok=false;if(n!=null&&n.isEditable()){Bundle b=new Bundle();b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,s);ok=n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT,b);n.recycle();}r.recycle();return ok;}
 public void global(String s){if("back".equals(s))performGlobalAction(GLOBAL_ACTION_BACK);else if("home".equals(s))performGlobalAction(GLOBAL_ACTION_HOME);else if("recents".equals(s))performGlobalAction(GLOBAL_ACTION_RECENTS);}
 public void screenshot(){if(Build.VERSION.SDK_INT<30){MainActivity.result("Screenshots need Android 11+.");return;}takeScreenshot(0,getMainExecutor(),new TakeScreenshotCallback(){public void onFailure(int e){MainActivity.result("Screenshot failed. Check Accessibility permission.");}public void onSuccess(ScreenshotResult r){try{Bitmap b=Bitmap.wrapHardwareBuffer(r.getHardwareBuffer(),r.getColorSpace());ContentValues v=new ContentValues();v.put(MediaStore.Images.Media.DISPLAY_NAME,"Capri-"+System.currentTimeMillis()+".png");v.put(MediaStore.Images.Media.MIME_TYPE,"image/png");v.put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/Capri");android.net.Uri u=getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,v);OutputStream o=getContentResolver().openOutputStream(u);b.compress(Bitmap.CompressFormat.PNG,100,o);o.close();b.recycle();r.getHardwareBuffer().close();MainActivity.result("Screenshot saved in Pictures/Capri.");}catch(Exception e){MainActivity.result("Could not save screenshot.");}}});}
}