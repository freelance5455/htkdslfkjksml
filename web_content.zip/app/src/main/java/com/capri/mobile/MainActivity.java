package com.capri.mobile;
import android.app.*;import android.os.*;import android.content.*;import android.content.pm.*;import android.webkit.*;import android.speech.*;import android.speech.tts.TextToSpeech;import java.util.*;import org.json.*;
public class MainActivity extends Activity {
 static MainActivity self; WebView web; SpeechRecognizer sr; TextToSpeech tts;
 public void onCreate(Bundle b){super.onCreate(b);self=this;getWindow().setStatusBarColor(0xff08050b);getWindow().setNavigationBarColor(0xff08050b);web=new WebView(this);web.setBackgroundColor(0xff08050b);web.getSettings().setJavaScriptEnabled(true);web.getSettings().setDomStorageEnabled(true);web.addJavascriptInterface(new Bridge(),"Capri");web.setWebViewClient(new WebViewClient());web.setWebChromeClient(chrome());web.getSettings().setMediaPlaybackRequiresUserGesture(false);setContentView(web);web.loadUrl("file:///android_asset/index.html");tts=new TextToSpeech(this,s->{if(s==TextToSpeech.SUCCESS)tts.setLanguage(Locale.getDefault());});}
 class Bridge {
 @JavascriptInterface public boolean openApp(String n){return launch(n);}
 @JavascriptInterface public boolean openPackage(String p){try{Intent i=getPackageManager().getLaunchIntentForPackage(p);if(i==null)return false;startActivity(i);return true;}catch(Exception e){return false;}}
 boolean launch(String n){Intent q=new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);for(ResolveInfo x:getPackageManager().queryIntentActivities(q,0)){String l=x.loadLabel(getPackageManager()).toString();if(l.equalsIgnoreCase(n)||l.toLowerCase().contains(n.toLowerCase())){Intent i=getPackageManager().getLaunchIntentForPackage(x.activityInfo.packageName);if(i!=null){startActivity(i);return true;}}}return false;}
 @JavascriptInterface public void listApps(){runOnUiThread(()->{try{JSONArray a=new JSONArray();Intent q=new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);for(ResolveInfo x:getPackageManager().queryIntentActivities(q,0)){JSONObject o=new JSONObject();o.put("label",x.loadLabel(getPackageManager()).toString());o.put("packageName",x.activityInfo.packageName);a.put(o);}web.evaluateJavascript("capriAppsResult("+JSONObject.quote(a.toString())+")",null);}catch(Exception e){result("Unable to list apps.");}});}
 @JavascriptInterface public boolean typeText(String s){return CapriAccessibilityService.live!=null&&CapriAccessibilityService.live.typeText(s);}
 @JavascriptInterface public void globalAction(String s){if(CapriAccessibilityService.live!=null)CapriAccessibilityService.live.global(s);else result("Enable Capri App Control in Accessibility settings.");}
 @JavascriptInterface public void takeScreenshot(){if(CapriAccessibilityService.live!=null)CapriAccessibilityService.live.screenshot();else result("Enable Capri App Control in Accessibility settings.");}
 @JavascriptInterface public void speak(String s){runOnUiThread(()->{if(tts!=null)tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"capri");});}
 @JavascriptInterface public void listen(){runOnUiThread(()->startSpeech());}
 }
 void startSpeech(){if(checkSelfPermission("android.permission.RECORD_AUDIO")!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{"android.permission.RECORD_AUDIO"},7);result("Allow microphone permission, then tap the mic again.");return;}if(!SpeechRecognizer.isRecognitionAvailable(this)){result("Speech recognition is unavailable.");return;}if(sr!=null)sr.destroy();sr=SpeechRecognizer.createSpeechRecognizer(this);sr.setRecognitionListener(new RecognitionListener(){public void onReadyForSpeech(Bundle b){}public void onBeginningOfSpeech(){}public void onRmsChanged(float f){}public void onBufferReceived(byte[]b){}public void onEndOfSpeech(){}public void onError(int e){result("Speech ended. Try again.");}public void onResults(Bundle b){ArrayList<String>a=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);if(a!=null&&!a.isEmpty())web.evaluateJavascript("capriVoiceResult("+JSONObject.quote(a.get(0))+")",null);}public void onPartialResults(Bundle b){}public void onEvent(int e,Bundle b){}});Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,Locale.getDefault());sr.startListening(i);}
 static void result(String s){if(self!=null)self.runOnUiThread(()->self.web.evaluateJavascript("capriActionResult("+JSONObject.quote(s)+")",null));}
 PermissionRequest pendingPerm;
 WebChromeClient chrome(){return new WebChromeClient(){
  @Override public void onPermissionRequest(final PermissionRequest r){runOnUiThread(()->handlePerm(r));}
  @Override public void onPermissionRequestCanceled(PermissionRequest r){if(pendingPerm==r)pendingPerm=null;}
 };}
 void handlePerm(PermissionRequest r){
  ArrayList<String> need=new ArrayList<>();
  for(String res:r.getResources()){
   if(PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(res)&&checkSelfPermission("android.permission.CAMERA")!=PackageManager.PERMISSION_GRANTED)need.add("android.permission.CAMERA");
   if(PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(res)&&checkSelfPermission("android.permission.RECORD_AUDIO")!=PackageManager.PERMISSION_GRANTED)need.add("android.permission.RECORD_AUDIO");
  }
  if(need.isEmpty()){r.grant(r.getResources());return;}
  if(pendingPerm!=null)pendingPerm.deny();
  pendingPerm=r;requestPermissions(need.toArray(new String[0]),8);
 }
 public void onRequestPermissionsResult(int code,String[] p,int[] g){
  super.onRequestPermissionsResult(code,p,g);
  if(code==8&&pendingPerm!=null){PermissionRequest r=pendingPerm;pendingPerm=null;boolean ok=g.length>0;for(int x:g)if(x!=PackageManager.PERMISSION_GRANTED)ok=false;if(ok)r.grant(r.getResources());else r.deny();}
 }
 public void onBackPressed(){web.evaluateJavascript("(window.capriBack?window.capriBack():false)",v->{if("true".equals(v))return;if(web.canGoBack())web.goBack();else MainActivity.super.onBackPressed();});}
 protected void onDestroy(){if(sr!=null)sr.destroy();if(tts!=null)tts.shutdown();super.onDestroy();}
}