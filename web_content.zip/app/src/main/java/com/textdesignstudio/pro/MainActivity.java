package com.textdesignstudio.pro;

import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.JavascriptInterface;
import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.provider.MediaStore;
import android.os.Environment;
import android.util.Base64;
import android.widget.Toast;
import java.io.OutputStream;
import java.io.IOException;
import java.util.Locale;

public class MainActivity extends Activity {
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        webView.setBackgroundColor(0xFF0B0E19);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setAllowContentAccess(true);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AndroidBridge(this), "AndroidBridge");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/www/index.html");
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    public class AndroidBridge {
        private final Context context;
        AndroidBridge(Context context) { this.context = context.getApplicationContext(); }

        @JavascriptInterface
        public void savePngBase64(String base64, String fileName) {
            // Do file decoding/writing off the UI thread so large PNGs don't freeze the app.
            new Thread(() -> {
                String result;
                try {
                    byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                    String safeName = fileName == null ? "text-design.png" : fileName.replaceAll("[^a-zA-Z0-9._-]", "_");
                    if (!safeName.toLowerCase(Locale.ROOT).endsWith(".png")) safeName += ".png";
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.MediaColumns.DISPLAY_NAME, safeName);
                    values.put(MediaStore.MediaColumns.MIME_TYPE, "image/png");
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/Text Design Studio");
                        values.put(MediaStore.MediaColumns.IS_PENDING, 1);
                    }
                    Uri collection = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q
                        ? MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                        : MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                    Uri item = context.getContentResolver().insert(collection, values);
                    if (item == null) throw new IOException("Could not create image entry");
                    try (OutputStream out = context.getContentResolver().openOutputStream(item)) {
                        if (out == null) throw new IOException("Could not open image file");
                        out.write(bytes);
                        out.flush();
                    }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        ContentValues done = new ContentValues();
                        done.put(MediaStore.MediaColumns.IS_PENDING, 0);
                        context.getContentResolver().update(item, done, null, null);
                    }
                    result = "PNG saved to Pictures/Text Design Studio";
                } catch (Exception e) {
                    result = "PNG save failed: " + e.getMessage();
                }
                final String message = result;
                runOnUiThread(() -> {
                    Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show();
                    if (webView != null) {
                        String js = "window.onNativeSaveResult && window.onNativeSaveResult(" +
                            org.json.JSONObject.quote(message) + ");";
                        webView.evaluateJavascript(js, null);
                    }
                });
            }).start();
        }
    }
}