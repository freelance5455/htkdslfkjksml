package com.qada.prayers;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private WebView webView;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webView);

        WebSettings webSettings = webView.getSettings();
        // تفعيل الجافاسكربت
        webSettings.setJavaScriptEnabled(true);
        // تفعيل حفظ البيانات محلياً (DOM Storage / localStorage) حتى لا تضيع البيانات عند إغلاق التطبيق
        webSettings.setDomStorageEnabled(true);
        webSettings.setDatabaseEnabled(true);
        // السماح بالوصول لملفات assets
        webSettings.setAllowFileAccess(true);
        webSettings.setAllowContentAccess(true);
        // تحسين العرض على الهاتف
        webSettings.setUseWideViewPort(true);
        webSettings.setLoadWithOverviewMode(true);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());

        // تحميل ملف HTML مباشرة من مجلد assets المحلي بدون إنترنت
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
