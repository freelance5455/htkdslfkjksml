package com.atc.simulator;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import android.util.Base64;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;

public class MainActivity extends Activity {

    private static final String ENTRY_URL = "file:///android_asset/www/index.html";
    private WebView webView;
    private TextToSpeech tts;
    private volatile boolean ttsReady = false;
    private long lastBackPressMs = 0L;

    private final Map<String, File> pendingWavFiles = new ConcurrentHashMap<>();
    private final Map<String, PendingSpeech> fallbackPayloads = new ConcurrentHashMap<>();
    private final Set<String> activeFallbackIds = ConcurrentHashMap.newKeySet();

    private static final Pattern MALE_VOICE_RE = Pattern.compile(
        "(\\bmale\\b|\\bman\\b|guy|david|mark|george|daniel|alex|oliver|arthur|ryan|steffan|andrew|brian|christopher|eric|roger|tony|jason|davis|aaron|rishi|lee|james|gordon|thomas|liam|william|connor|sam|prabhat|wayne|luke|adam|benjamin|charles|edward|frank|harry|henry|jack|jacob|john|joseph|joshua|kenneth|kevin|matthew|michael|nathan|nicholas|noah|patrick|paul|peter|richard|robert|samuel|sean|stephen|steven|timothy|tyler|victor|walter|en-us-x-iol|en-us-x-iom|en-us-x-tpd|en-us-x-tpc|en-gb-x-gbd|en-gb-x-rjs|en-au-x-aub|en-au-x-aud|en-in-x-end|en-in-x-ene|en_us_m|en_gb_m)",
        Pattern.CASE_INSENSITIVE
    );
    private static final Pattern FEMALE_VOICE_RE = Pattern.compile(
        "(\\bfemale\\b|\\bwoman\\b|girl|zira|susan|hazel|samantha|karen|ava|zoe|serena|tessa|moira|aria|jenny|sonia|libby|maisie|michelle|ana|emma|clara|neerja|natasha|fiona|victoria|kate|nicky|allison|veena|hannah|claire|chloe|emily|grace|laura|linda|mary|nancy|olivia|patricia|rachel|sarah|sophia|stephanie|tiffany|vanessa|wendy|kalpana|heera|priya|kanya|leena|en-us-x-sfg|en-us-x-tpf|en-gb-x-gba|en-gb-x-gbc|en-gb-x-gbg|en-au-x-aua|en-au-x-auc|en-in-x-ena|en-in-x-enc)",
        Pattern.CASE_INSENSITIVE
    );

    private static final class PendingSpeech {
        final String text;
        final String voiceName;
        final float pitch;
        final float rate;
        final float volume;

        PendingSpeech(String text, String voiceName, float pitch, float rate, float volume) {
            this.text = text;
            this.voiceName = voiceName;
            this.pitch = pitch;
            this.rate = rate;
            this.volume = volume;
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        applyImmersiveFullscreen();

        initOfflineTts();

        webView = new WebView(this);
        webView.setBackgroundColor(Color.parseColor("#040810"));
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setHorizontalScrollBarEnabled(false);
        webView.setVerticalScrollBarEnabled(false);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setAllowFileAccessFromFileURLs(true);
        settings.setAllowUniversalAccessFromFileURLs(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setCacheMode(WebSettings.LOAD_NO_CACHE);

        webView.addJavascriptInterface(new AndroidTtsBridge(), "AndroidTts");
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String url = request.getUrl() != null ? request.getUrl().toString() : "";
                return !url.startsWith("file:///android_asset/");
            }
        });

        setContentView(webView);
        webView.loadUrl(ENTRY_URL);
    }

    private void initOfflineTts() {
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS && tts != null) {
                int langRes = tts.setLanguage(Locale.US);
                if (langRes == TextToSpeech.LANG_MISSING_DATA || langRes == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts.setLanguage(Locale.ENGLISH);
                }
                ttsReady = true;
                evalJs("if (window.__onAndroidTtsReady) window.__onAndroidTtsReady();");
            } else {
                ttsReady = false;
            }
        });

        tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            @Override
            public void onStart(String utteranceId) {
                if (activeFallbackIds.contains(utteranceId)) {
                    evalJs("if (window.__onAndroidTtsFallbackStart) window.__onAndroidTtsFallbackStart(" + JSONObject.quote(utteranceId) + ");");
                }
            }

            @Override
            public void onDone(String utteranceId) {
                if (activeFallbackIds.remove(utteranceId)) {
                    evalJs("if (window.__onAndroidTtsFallbackDone) window.__onAndroidTtsFallbackDone(" + JSONObject.quote(utteranceId) + ");");
                    return;
                }
                File wavFile = pendingWavFiles.remove(utteranceId);
                PendingSpeech speech = fallbackPayloads.remove(utteranceId);
                if (wavFile != null && wavFile.exists() && wavFile.length() > 44) {
                    byte[] bytes = readAndDeleteFile(wavFile);
                    if (bytes != null && bytes.length > 44) {
                        String b64 = Base64.encodeToString(bytes, Base64.NO_WRAP);
                        evalJs("if (window.__onAndroidTtsWav) window.__onAndroidTtsWav(" + JSONObject.quote(utteranceId) + ", " + JSONObject.quote(b64) + ");");
                        return;
                    }
                }
                if (wavFile != null && wavFile.exists()) {
                    wavFile.delete();
                }
                if (speech != null) {
                    speakDirectFallback(utteranceId, speech);
                } else {
                    evalJs("if (window.__onAndroidTtsError) window.__onAndroidTtsError(" + JSONObject.quote(utteranceId) + ");");
                }
            }

            @Override
            public void onError(String utteranceId) {
                handleTtsError(utteranceId);
            }

            @Override
            public void onError(String utteranceId, int errorCode) {
                handleTtsError(utteranceId);
            }
        });
    }

    private void handleTtsError(String utteranceId) {
        if (activeFallbackIds.remove(utteranceId)) {
            evalJs("if (window.__onAndroidTtsError) window.__onAndroidTtsError(" + JSONObject.quote(utteranceId) + ");");
            return;
        }
        File wavFile = pendingWavFiles.remove(utteranceId);
        if (wavFile != null && wavFile.exists()) {
            wavFile.delete();
        }
        PendingSpeech speech = fallbackPayloads.remove(utteranceId);
        if (speech != null) {
            speakDirectFallback(utteranceId, speech);
        } else {
            evalJs("if (window.__onAndroidTtsError) window.__onAndroidTtsError(" + JSONObject.quote(utteranceId) + ");");
        }
    }

    private void speakDirectFallback(String utteranceId, PendingSpeech s) {
        if (!ttsReady || tts == null) {
            evalJs("if (window.__onAndroidTtsError) window.__onAndroidTtsError(" + JSONObject.quote(utteranceId) + ");");
            return;
        }
        activeFallbackIds.add(utteranceId);
        applyVoiceSettings(s.voiceName, s.pitch, s.rate);
        Bundle params = new Bundle();
        params.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, Math.max(0.05f, Math.min(1.0f, s.volume)));
        int res = tts.speak(s.text, TextToSpeech.QUEUE_FLUSH, params, utteranceId);
        if (res != TextToSpeech.SUCCESS) {
            activeFallbackIds.remove(utteranceId);
            evalJs("if (window.__onAndroidTtsError) window.__onAndroidTtsError(" + JSONObject.quote(utteranceId) + ");");
        }
    }

    private void applyVoiceSettings(String voiceName, float pitch, float rate) {
        if (tts == null) return;
        tts.setPitch(Math.max(0.45f, Math.min(1.1f, pitch)));
        tts.setSpeechRate(Math.max(0.75f, Math.min(1.35f, rate)));
        if (voiceName != null && !voiceName.isEmpty()) {
            try {
                Set<Voice> voices = tts.getVoices();
                if (voices != null) {
                    for (Voice v : voices) {
                        if (voiceName.equals(v.getName())) {
                            tts.setVoice(v);
                            break;
                        }
                    }
                }
            } catch (Exception ignored) {}
        }
    }

    private byte[] readAndDeleteFile(File f) {
        try (FileInputStream fis = new FileInputStream(f);
             ByteArrayOutputStream bos = new ByteArrayOutputStream()) {
            byte[] buf = new byte[8192];
            int n;
            while ((n = fis.read(buf)) != -1) {
                bos.write(buf, 0, n);
            }
            return bos.toByteArray();
        } catch (Exception e) {
            return null;
        } finally {
            try { f.delete(); } catch (Exception ignored) {}
        }
    }

    private void evalJs(String script) {
        runOnUiThread(() -> {
            if (webView != null) {
                webView.evaluateJavascript(script, null);
            }
        });
    }

    public final class AndroidTtsBridge {
        @JavascriptInterface
        public boolean isAvailable() {
            return ttsReady && tts != null;
        }

        @JavascriptInterface
        public String getVoicesJson() {
            JSONArray arr = new JSONArray();
            if (!ttsReady || tts == null) return arr.toString();
            try {
                Set<Voice> voiceSet = tts.getVoices();
                if (voiceSet == null) return arr.toString();
                List<Voice> offlineEn = new ArrayList<>();
                List<Voice> allEn = new ArrayList<>();
                for (Voice v : voiceSet) {
                    if (v == null || v.getLocale() == null) continue;
                    String lang = v.getLocale().toLanguageTag();
                    if (!lang.toLowerCase(Locale.US).startsWith("en")) continue;
                    allEn.add(v);
                    if (!v.isNetworkConnectionRequired()) {
                        offlineEn.add(v);
                    }
                }
                List<Voice> pool = offlineEn.isEmpty() ? allEn : offlineEn;
                pool.sort(Comparator.comparingInt((Voice v) -> {
                    String n = v.getName() != null ? v.getName() : "";
                    boolean m = MALE_VOICE_RE.matcher(n).find();
                    boolean f = !m && FEMALE_VOICE_RE.matcher(n).find();
                    return m ? 0 : (f ? 2 : 1);
                }));
                for (Voice v : pool) {
                    JSONObject obj = new JSONObject();
                    obj.put("name", v.getName());
                    obj.put("lang", v.getLocale().toLanguageTag());
                    obj.put("localService", !v.isNetworkConnectionRequired());
                    arr.put(obj);
                }
            } catch (Exception ignored) {}
            return arr.toString();
        }

        @JavascriptInterface
        public boolean speakWav(String utteranceId, String text, String voiceName, float pitch, float rate, float volume) {
            if (!ttsReady || tts == null || text == null || text.trim().isEmpty()) {
                return false;
            }
            try {
                applyVoiceSettings(voiceName, pitch, rate);
                File wavFile = new File(getCacheDir(), "atc_tts_" + utteranceId.replaceAll("[^A-Za-z0-9_]", "") + ".wav");
                if (wavFile.exists()) wavFile.delete();
                pendingWavFiles.put(utteranceId, wavFile);
                fallbackPayloads.put(utteranceId, new PendingSpeech(text, voiceName, pitch, rate, volume));
                Bundle params = new Bundle();
                int res = tts.synthesizeToFile(text, params, wavFile, utteranceId);
                if (res != TextToSpeech.SUCCESS) {
                    pendingWavFiles.remove(utteranceId);
                    PendingSpeech speech = fallbackPayloads.remove(utteranceId);
                    if (speech != null) {
                        speakDirectFallback(utteranceId, speech);
                        return true;
                    }
                    return false;
                }
                return true;
            } catch (Exception e) {
                pendingWavFiles.remove(utteranceId);
                fallbackPayloads.remove(utteranceId);
                return false;
            }
        }

        @JavascriptInterface
        public void stop() {
            pendingWavFiles.clear();
            fallbackPayloads.clear();
            activeFallbackIds.clear();
            if (tts != null) {
                try { tts.stop(); } catch (Exception ignored) {}
            }
        }
    }

    private void applyImmersiveFullscreen() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            getWindow().setDecorFitsSystemWindows(false);
            WindowInsetsController controller = getWindow().getInsetsController();
            if (controller != null) {
                controller.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                controller.setSystemBarsBehavior(
                    WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                );
            }
        } else {
            @SuppressWarnings("deprecation")
            int flags = View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN;
            getWindow().getDecorView().setSystemUiVisibility(flags);
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            applyImmersiveFullscreen();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) {
            webView.onResume();
            webView.resumeTimers();
        }
    }

    @Override
    protected void onPause() {
        if (webView != null) {
            webView.onPause();
            webView.pauseTimers();
        }
        super.onPause();
    }

    @SuppressWarnings("deprecation")
    @Override
    public void onBackPressed() {
        long now = System.currentTimeMillis();
        if (now - lastBackPressMs < 2000L) {
            super.onBackPressed();
        } else {
            lastBackPressMs = now;
            Toast.makeText(this, "Press Back again to exit ATC Tower", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onDestroy() {
        if (tts != null) {
            try {
                tts.stop();
                tts.shutdown();
            } catch (Exception ignored) {}
            tts = null;
        }
        if (webView != null) {
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
