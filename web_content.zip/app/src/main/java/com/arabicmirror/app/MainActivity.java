package com.arabicmirror.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.os.Handler;
import android.os.Looper;
import android.content.SharedPreferences;

import com.google.mlkit.nl.translate.TranslateLanguage;
import com.google.mlkit.nl.translate.Translation;
import com.google.mlkit.nl.translate.Translator;
import com.google.mlkit.nl.translate.TranslatorOptions;
import com.google.mlkit.nl.translate.DownloadConditions;
import com.google.mlkit.nl.languageid.LanguageIdentification;
import com.google.mlkit.nl.languageid.LanguageIdentifier;

import org.json.JSONObject;
import java.util.Locale;

public class MainActivity extends Activity {
    private WebView webView;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private SharedPreferences packs;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        packs = getSharedPreferences("offline_translation_packs", MODE_PRIVATE);
        webView = new WebView(this);
        webView.setBackgroundColor(0xFF0C0C1C);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        webView.addJavascriptInterface(new TranslationBridge(), "AndroidBridge");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private String pairKey(String source, String target) { return source + "_to_" + target; }
    private void send(String callbackName, JSONObject data) {
        String callback = (callbackName != null && callbackName.matches("[A-Za-z0-9_]+")) ? callbackName : "onNativeTranslation";
        final String payload = JSONObject.quote(data.toString());
        mainHandler.post(() -> webView.evaluateJavascript("window." + callback + "(" + payload + ")", null));
    }
    private JSONObject response(boolean ok, String text, String error, String target) {
        JSONObject obj = new JSONObject();
        try { obj.put("ok", ok); if (text != null) obj.put("text", text); if (error != null) obj.put("error", error); if (target != null) obj.put("target", target); }
        catch (Exception ignored) { }
        return obj;
    }
    private boolean supported(String code) { return TranslateLanguage.getAllLanguages().contains(code); }

    private class TranslationBridge {
        @JavascriptInterface public void downloadTranslationPack(String source, String target, String callbackName) {
            if (source == null || target == null || source.equals("auto") || source.equals(target) || !supported(source) || !supported(target)) {
                send(callbackName, response(false, null, "اختر لغتين مدعومتين ومختلفتين قبل تنزيل الحزمة.", target)); return;
            }
            TranslatorOptions options = new TranslatorOptions.Builder().setSourceLanguage(source).setTargetLanguage(target).build();
            Translator translator = Translation.getClient(options);
            DownloadConditions conditions = new DownloadConditions.Builder().build(); // Wi-Fi أو بيانات الهاتف
            translator.downloadModelIfNeeded(conditions)
                .addOnSuccessListener(unused -> {
                    packs.edit().putBoolean(pairKey(source, target), true).apply();
                    translator.close();
                    send(callbackName, response(true, "تم تنزيل حزمة الترجمة وحفظها على الجهاز. يمكنك الترجمة دون إنترنت.", null, target));
                })
                .addOnFailureListener(e -> {
                    translator.close();
                    String message = e.getLocalizedMessage();
                    send(callbackName, response(false, null, "فشل تنزيل الحزمة. تحقق من الإنترنت والمساحة ثم أعد المحاولة. " + (message == null ? "" : message), target));
                });
        }

        @JavascriptInterface public void translate(String text, String source, String target, String callbackName) {
            if (text == null || text.trim().isEmpty()) { send(callbackName, response(false, null, "اكتب نصاً أولاً.", target)); return; }
            if (target == null || !supported(target)) { send(callbackName, response(false, null, "لغة الهدف غير مدعومة في الترجمة دون إنترنت.", target)); return; }
            if (source == null || source.equals("auto")) {
                LanguageIdentifier identifier = LanguageIdentification.getClient();
                identifier.identifyLanguage(text).addOnSuccessListener(detected -> {
                    identifier.close();
                    if (detected == null || "und".equals(detected) || !supported(detected)) {
                        send(callbackName, response(false, null, "تعذر تحديد لغة النص. اختر لغة المصدر يدوياً.", target));
                    } else translateKnown(text, detected, target, callbackName);
                }).addOnFailureListener(e -> {
                    identifier.close(); send(callbackName, response(false, null, "تعذر تحديد اللغة. اختر لغة المصدر يدوياً.", target));
                });
            } else translateKnown(text, source, target, callbackName);
        }

        private void translateKnown(String text, String source, String target, String callbackName) {
            if (!supported(source)) { send(callbackName, response(false, null, "لغة المصدر غير مدعومة. اختر لغة أخرى.", target)); return; }
            if (source.equals(target)) { send(callbackName, response(true, text, null, target)); return; }
            if (!packs.getBoolean(pairKey(source, target), false)) {
                send(callbackName, response(false, null, "حزمة هذه اللغتين غير منزّلة. اتصل بالإنترنت واضغط «تنزيل حزمة الترجمة» أولاً.", target)); return;
            }
            TranslatorOptions options = new TranslatorOptions.Builder().setSourceLanguage(source).setTargetLanguage(target).build();
            Translator translator = Translation.getClient(options);
            translator.translate(text).addOnSuccessListener(result -> {
                translator.close(); send(callbackName, response(true, result, null, target));
            }).addOnFailureListener(e -> {
                translator.close(); send(callbackName, response(false, null, "تعذرت الترجمة. إذا حذفت بيانات التطبيق فأعد تنزيل حزمة اللغتين.", target));
            });
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
