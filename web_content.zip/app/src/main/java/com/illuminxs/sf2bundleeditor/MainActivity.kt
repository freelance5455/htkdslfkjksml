package com.illuminxs.sf2bundleeditor

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.JsPromptResult
import android.webkit.JsResult
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.documentfile.provider.DocumentFile
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private var pendingFileCallback: ValueCallback<Array<Uri>>? = null
    private var folderTargetMode: String = "repack"

    private val filePickerLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val cb = pendingFileCallback
            pendingFileCallback = null
            if (cb == null) return@registerForActivityResult

            if (result.resultCode != Activity.RESULT_OK || result.data == null) {
                cb.onReceiveValue(null)
                return@registerForActivityResult
            }

            val data = result.data!!
            val uris = mutableListOf<Uri>()
            val clip = data.clipData
            if (clip != null) {
                for (i in 0 until clip.itemCount) {
                    clip.getItemAt(i).uri?.let { uris.add(it) }
                }
            } else {
                data.data?.let { uris.add(it) }
            }
            cb.onReceiveValue(if (uris.isEmpty()) null else uris.toTypedArray())
        }

    private val folderPickerLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { treeUri ->
            if (treeUri != null) {
                importFolderTree(treeUri, folderTargetMode)
            }
        }

    private data class ExportSession(
        val tempFile: File,
        val finalFile: File,
        val outputStream: FileOutputStream
    )

    private val exportSessions = ConcurrentHashMap<String, ExportSession>()

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        webView = WebView(this)
        setContentView(webView)

        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            cacheMode = WebSettings.LOAD_DEFAULT
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            useWideViewPort = true
            loadWithOverviewMode = true
        }

        webView.addJavascriptInterface(AndroidExportBridge(), "AndroidExport")

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? {
                return assetLoader.shouldInterceptRequest(request.url)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                view?.evaluateJavascript(
                    "if(typeof window.sf2RefreshExportBar==='function')window.sf2RefreshExportBar();",
                    null
                )
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                pendingFileCallback?.onReceiveValue(null)
                pendingFileCallback = filePathCallback

                val allowMultiple =
                    fileChooserParams?.mode == FileChooserParams.MODE_OPEN_MULTIPLE
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                    putExtra(Intent.EXTRA_ALLOW_MULTIPLE, allowMultiple)
                }
                return try {
                    filePickerLauncher.launch(intent)
                    true
                } catch (_: Exception) {
                    pendingFileCallback?.onReceiveValue(null)
                    pendingFileCallback = null
                    false
                }
            }

            override fun onJsAlert(
                view: WebView?,
                url: String?,
                message: String?,
                result: JsResult?
            ): Boolean {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle(getString(R.string.app_name))
                    .setMessage(message ?: "")
                    .setPositiveButton(android.R.string.ok) { _, _ -> result?.confirm() }
                    .setOnCancelListener { result?.cancel() }
                    .show()
                return true
            }

            override fun onJsConfirm(
                view: WebView?,
                url: String?,
                message: String?,
                result: JsResult?
            ): Boolean {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle(getString(R.string.app_name))
                    .setMessage(message ?: "")
                    .setPositiveButton(android.R.string.ok) { _, _ -> result?.confirm() }
                    .setNegativeButton(android.R.string.cancel) { _, _ -> result?.cancel() }
                    .setOnCancelListener { result?.cancel() }
                    .show()
                return true
            }

            override fun onJsPrompt(
                view: WebView?,
                url: String?,
                message: String?,
                defaultValue: String?,
                result: JsPromptResult?
            ): Boolean {
                val input = EditText(this@MainActivity).apply {
                    setText(defaultValue ?: "")
                }
                AlertDialog.Builder(this@MainActivity)
                    .setTitle(getString(R.string.app_name))
                    .setMessage(message ?: "")
                    .setView(input)
                    .setPositiveButton(android.R.string.ok) { _, _ ->
                        result?.confirm(input.text.toString())
                    }
                    .setNegativeButton(android.R.string.cancel) { _, _ ->
                        result?.cancel()
                    }
                    .setOnCancelListener { result?.cancel() }
                    .show()
                return true
            }
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })

        webView.loadUrl("https://appassets.androidplatform.net/assets/www/index.html")
    }

    private fun getMediaExportDir(): File {
        val primary = externalMediaDirs.firstOrNull { it != null }
        val dir = primary ?: File(
            Environment.getExternalStorageDirectory(),
            "Android/media/$packageName"
        )
        if (!dir.exists()) {
            dir.mkdirs()
        }
        return dir
    }

    private fun sanitizeFileName(raw: String): String {
        val cleaned = raw
            .replace("\\", "/")
            .split("/")
            .filter { it.isNotBlank() && it != "." && it != ".." }
            .joinToString("_")
            .replace(Regex("[:*?\"<>|]+"), "_")
        return if (cleaned.isBlank()) "export.bin" else cleaned
    }

    private fun importFolderTree(treeUri: Uri, mode: String) {
        val rootDoc = DocumentFile.fromTreeUri(this, treeUri) ?: return
        val rootName = rootDoc.name ?: "folder"

        Thread {
            runOnUiThread {
                webView.evaluateJavascript("window.__sf2ResetFolderQueue();", null)
            }

            fun walk(dir: DocumentFile, prefix: String) {
                for (child in dir.listFiles()) {
                    val name = child.name ?: continue
                    val rel = if (prefix.isEmpty()) name else "$prefix/$name"
                    if (child.isDirectory) {
                        walk(child, rel)
                    } else if (child.isFile) {
                        val bytes = contentResolver.openInputStream(child.uri)?.use { it.readBytes() }
                            ?: continue
                        val b64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
                        val json = JSONObject().apply {
                            put("name", name)
                            put("size", bytes.size)
                            put("relPath", rel)
                            put("b64", b64)
                        }.toString()
                        runOnUiThread {
                            webView.evaluateJavascript("window.__sf2PushFolderItem($json);", null)
                        }
                    }
                }
            }

            val startPrefix = if (mode == "repack") rootName else ""
            walk(rootDoc, startPrefix)

            runOnUiThread {
                if (mode == "repack") {
                    webView.evaluateJavascript("window.__sf2FlushRepackFolder();", null)
                } else {
                    val quotedRoot = JSONObject.quote(rootName)
                    webView.evaluateJavascript("window.__sf2FlushInnerFolder($quotedRoot);", null)
                }
            }
        }.start()
    }

    inner class AndroidExportBridge {
        @JavascriptInterface
        fun beginExport(rawFileName: String, @Suppress("UNUSED_PARAMETER") totalBytes: Long): String {
            return try {
                val dir = getMediaExportDir()
                val safeName = sanitizeFileName(rawFileName)
                val finalFile = File(dir, safeName)
                val tempFile = File(dir, ".$safeName.${System.currentTimeMillis()}.part")
                val transferId = UUID.randomUUID().toString()
                exportSessions[transferId] = ExportSession(
                    tempFile = tempFile,
                    finalFile = finalFile,
                    outputStream = FileOutputStream(tempFile)
                )
                transferId
            } catch (_: Exception) {
                ""
            }
        }

        @JavascriptInterface
        fun appendExportChunk(transferId: String, base64Chunk: String): Boolean {
            val session = exportSessions[transferId] ?: return false
            return try {
                val bytes = Base64.decode(base64Chunk, Base64.DEFAULT)
                session.outputStream.write(bytes)
                true
            } catch (_: Exception) {
                false
            }
        }

        @JavascriptInterface
        fun finishExport(transferId: String): String {
            val session = exportSessions.remove(transferId) ?: return ""
            return try {
                session.outputStream.flush()
                session.outputStream.close()
                if (session.finalFile.exists()) {
                    session.finalFile.delete()
                }
                if (!session.tempFile.renameTo(session.finalFile)) {
                    session.tempFile.copyTo(session.finalFile, overwrite = true)
                    session.tempFile.delete()
                }
                MediaScannerConnection.scanFile(
                    this@MainActivity,
                    arrayOf(session.finalFile.absolutePath),
                    null,
                    null
                )
                val displayPath = "Android/media/$packageName/${session.finalFile.name}"
                runOnUiThread {
                    Toast.makeText(
                        this@MainActivity,
                        "Saved to $displayPath",
                        Toast.LENGTH_SHORT
                    ).show()
                }
                displayPath
            } catch (_: Exception) {
                session.tempFile.delete()
                ""
            }
        }

        @JavascriptInterface
        fun cancelExport(transferId: String) {
            val session = exportSessions.remove(transferId) ?: return
            try {
                session.outputStream.close()
            } catch (_: Exception) {
            }
            session.tempFile.delete()
        }

        @JavascriptInterface
        fun pickRepackFolder() {
            folderTargetMode = "repack"
            runOnUiThread {
                folderPickerLauncher.launch(null)
            }
        }

        @JavascriptInterface
        fun pickInnerFolder() {
            folderTargetMode = "inner"
            runOnUiThread {
                folderPickerLauncher.launch(null)
            }
        }
    }
}
