package com.class9.datewisetracker;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;

public class MainActivity extends Activity {
  public class AndroidBridge {
    @JavascriptInterface public boolean isNativeApp(){ return true; }
  }
  @Override public void onCreate(Bundle b){
    super.onCreate(b);
    WebView w=new WebView(this);
    w.setWebViewClient(new WebViewClient());
    WebSettings s=w.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
    w.addJavascriptInterface(new AndroidBridge(), "AndroidApp");
    w.loadUrl("file:///android_asset/index.html");
    setContentView(w);
  }
}
