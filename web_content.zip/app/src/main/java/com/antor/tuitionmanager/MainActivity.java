package com.antor.tuitionmanager;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.Window;
import android.widget.Toast;

public class MainActivity extends Activity {
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setLoadWithOverviewMode(false);
        settings.setUseWideViewPort(false);

        webView.addJavascriptInterface(new PdfBridge(this), "Android");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.loadUrl("file:///android_asset/index.html");
    }

    public static class PdfBridge {
        private final Activity activity;

        PdfBridge(Activity activity) {
            this.activity = activity;
        }

        @JavascriptInterface
        public void printPdf(final String html, final String filename, final boolean landscape) {
            activity.runOnUiThread(() -> {
                final WebView printWebView = new WebView(activity);
                WebSettings settings = printWebView.getSettings();
                settings.setJavaScriptEnabled(true);
                settings.setDomStorageEnabled(true);
                printWebView.setWebViewClient(new WebViewClient() {
                    @Override
                    public void onPageFinished(WebView view, String url) {
                        PrintManager printManager =
                                (PrintManager) activity.getSystemService(Context.PRINT_SERVICE);
                        String jobName = (filename == null || filename.trim().isEmpty())
                                ? "Tuition Manager PDF" : filename;
                        PrintDocumentAdapter adapter = printWebView.createPrintDocumentAdapter(jobName);
                        printManager.print(jobName, adapter,
                                new PrintAttributes.Builder()
                                        .setMediaSize(landscape ? PrintAttributes.MediaSize.ISO_A4_LANDSCAPE : PrintAttributes.MediaSize.ISO_A4)
                                        .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                                        .build());
                        Toast.makeText(activity, "Choose 'Save as PDF' to save the file.", Toast.LENGTH_LONG).show();
                    }
                });
                printWebView.loadDataWithBaseURL("file:///android_asset/", html,
                        "text/html", "UTF-8", null);
            });
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
