package com.jaslaundry.app;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.JsResult;
import android.webkit.JsPromptResult;
import android.webkit.ConsoleMessage;
import android.app.AlertDialog;
import android.widget.Toast;

import android.app.Activity;

import java.io.ByteArrayInputStream;
import java.io.OutputStream;
import java.util.Base64;

public class MainActivity extends Activity {
    private WebView webView;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        webView.setWebViewClient(new WebViewClient());
        // Handle JavaScript alert/confirm dialogs in the Android WebView.
        // Without this, the Price List delete confirmation can appear to do nothing.
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onJsAlert(WebView view, String url, String message, JsResult result) {
                new AlertDialog.Builder(MainActivity.this)
                    .setTitle("JAS Laundry")
                    .setMessage(message)
                    .setPositiveButton("OK", (dialog, which) -> result.confirm())
                    .setOnCancelListener(dialog -> result.cancel())
                    .show();
                return true;
            }
            @Override public boolean onJsConfirm(WebView view, String url, String message, JsResult result) {
                new AlertDialog.Builder(MainActivity.this)
                    .setTitle("Confirm")
                    .setMessage(message)
                    .setPositiveButton("Delete / Yes", (dialog, which) -> result.confirm())
                    .setNegativeButton("Cancel", (dialog, which) -> result.cancel())
                    .setOnCancelListener(dialog -> result.cancel())
                    .show();
                return true;
            }
            @Override public boolean onJsPrompt(WebView view, String url, String message, String defaultValue, JsPromptResult result) {
                return super.onJsPrompt(view, url, message, defaultValue, result);
            }
        });
        webView.addJavascriptInterface(new AndroidBridge(this), "AndroidBridge");
        webView.loadUrl("file:///android_asset/index.html");
    }

    public static class AndroidBridge {
        private final Context context;
        AndroidBridge(Context c) { context = c.getApplicationContext(); }

        private byte[] decode(String base64) {
            if (Build.VERSION.SDK_INT >= 26) return Base64.getDecoder().decode(base64);
            return android.util.Base64.decode(base64, android.util.Base64.DEFAULT);
        }

        @JavascriptInterface
        public boolean saveImage(String base64, String filename) {
            try {
                byte[] bytes = decode(base64);
                ContentResolver cr = context.getContentResolver();
                ContentValues values = new ContentValues();
                values.put(MediaStore.Images.Media.DISPLAY_NAME, filename);
                values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
                if (Build.VERSION.SDK_INT >= 29) {
                    values.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/JAS Laundry");
                    values.put(MediaStore.Images.Media.IS_PENDING, 1);
                }
                Uri uri = cr.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                if (uri == null) throw new Exception("MediaStore insert failed");
                try (OutputStream out = cr.openOutputStream(uri)) {
                    if (out == null) throw new Exception("Output stream unavailable");
                    out.write(bytes);
                }
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues done = new ContentValues();
                    done.put(MediaStore.Images.Media.IS_PENDING, 0);
                    cr.update(uri, done, null, null);
                }
                Toast.makeText(context, "Bill JPG saved to Gallery → JAS Laundry", Toast.LENGTH_SHORT).show();
                return true;
            } catch (Exception e) {
                Toast.makeText(context, "Could not save JPG: " + e.getMessage(), Toast.LENGTH_LONG).show();
                return false;
            }
        }

        @JavascriptInterface
        public boolean shareImage(String base64, String filename, String message) {
            try {
                byte[] bytes = decode(base64);
                ContentResolver cr = context.getContentResolver();
                ContentValues values = new ContentValues();
                values.put(MediaStore.Images.Media.DISPLAY_NAME, filename);
                values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
                if (Build.VERSION.SDK_INT >= 29) values.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/JAS Laundry");
                Uri uri = cr.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                if (uri == null) throw new Exception("MediaStore insert failed");
                try (OutputStream out = cr.openOutputStream(uri)) {
                    if (out == null) throw new Exception("Output stream unavailable");
                    out.write(bytes);
                }

                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType("image/jpeg");
                send.putExtra(Intent.EXTRA_STREAM, uri);
                send.putExtra(Intent.EXTRA_TEXT, message);
                send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

                Intent chooser = Intent.createChooser(send, "Send Bill");
                // Prefer WhatsApp Business when it is installed.
                try {
                    send.setPackage("com.whatsapp.w4b");
                    if (send.resolveActivity(context.getPackageManager()) != null) {
                        context.startActivity(send);
                        return true;
                    }
                } catch (Exception ignored) {}
                context.startActivity(chooser);
                return true;
            } catch (Exception e) {
                Toast.makeText(context, "Could not share bill: " + e.getMessage(), Toast.LENGTH_LONG).show();
                return false;
            }
        }
    }
}
