package com.miorganizador.app;

import android.app.*;
import android.content.*;
import android.os.Build;

public class ReminderReceiver extends BroadcastReceiver {
    private static final String CHANNEL = "mi_organizador_recordatorios";
    @Override public void onReceive(Context context, Intent intent) {
        NotificationManager nm=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel ch=new NotificationChannel(CHANNEL,"Recordatorios de MI ORGANIZADOR",NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription("Tareas, vencimientos y recordatorios por proyecto");nm.createNotificationChannel(ch);
        }
        String title=intent.getStringExtra("title"); String project=intent.getStringExtra("project");
        String body=(project==null?"MI ORGANIZADOR":project)+" · "+(title==null?"Recordatorio":title);
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(context,CHANNEL):new Notification.Builder(context);
        b.setSmallIcon(com.miorganizador.app.R.drawable.ic_launcher).setContentTitle("🔔 "+(project==null?"MI ORGANIZADOR":project)).setContentText(body).setAutoCancel(true);
        if(Build.VERSION.SDK_INT<33 || context.checkSelfPermission("android.permission.POST_NOTIFICATIONS")==0) nm.notify(Math.abs((intent.getStringExtra("tag")+").hashCode())),b.build());
    }
}
