package com.miorganizador.app;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.webkit.*;
import android.widget.*;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.*;
import java.util.*;

public class MainActivity extends Activity {
    private static final int REQ_FILES = 4101;
    private static final int REQ_MEDIA = 4104;
    private static final int REQ_CAMERA = 4102;
    private static final int REQ_NOTIFY = 4103;
    private static final String FILE_SCHEME = "https://mi-organizador.local/file/";
    private static final String PREFS = "mi_org_native";
    private WebView web;
    private Uri cameraUri;
    private String cameraNativeId;
    private File storeDir;
    private String pendingSharedPayload;
    private final ArrayList<String> pendingJsEvents = new ArrayList<>();
    private boolean pageReady = false;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(255,248,242));
        getWindow().setNavigationBarColor(Color.rgb(255,248,242));
        storeDir = new File(getFilesDir(), "native_store");
        if (!storeDir.exists()) storeDir.mkdirs();
        pendingSharedPayload = getSharedPreferences(PREFS, MODE_PRIVATE).getString("pending_shared", null);
        buildWebView();
        handleIntent(getIntent());
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            // Ask after the UI has loaded; the settings button can also request it explicitly.
        }
    }

    private void buildWebView() {
        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setDefaultTextEncodingName("utf-8");
        web.setBackgroundColor(Color.rgb(255,248,242));
        web.addJavascriptInterface(new AndroidBridge(), "Android");
        web.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, String url) {
                if (url != null && url.startsWith(FILE_SCHEME)) return serveNativeFile(url);
                return super.shouldInterceptRequest(view, url);
            }
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                pageReady = true;
                if (pendingSharedPayload != null) {
                    String p = pendingSharedPayload;
                    pendingSharedPayload = null;
                    getSharedPreferences(PREFS, MODE_PRIVATE).edit().remove("pending_shared").apply();
                    enqueueJs("window.onNativeSharedFiles(" + JSONObject.quote(p) + ");");
                }
                flushJsEvents();
            }
        });
        web.loadUrl("file:///android_asset/index.html");
    }

    private WebResourceResponse serveNativeFile(String url) {
        try {
            String id = url.substring(FILE_SCHEME.length());
            File f = new File(storeDir, safeId(id));
            if (!f.exists()) return null;
            String mime = guessMime(f.getName());
            WebResourceResponse r = new WebResourceResponse(mime, "UTF-8", new FileInputStream(f));
            Map<String,String> headers = new HashMap<>();
            headers.put("Access-Control-Allow-Origin", "*");
            headers.put("Cache-Control", "no-cache");
            r.setResponseHeaders(headers);
            return r;
        } catch (Exception e) { return null; }
    }

    private String safeId(String id) { return id.replaceAll("[^A-Za-z0-9._-]", "_"); }

    private void sendJs(String code) {
        runOnUiThread(() -> {
            if (!pageReady || web == null) { pendingJsEvents.add(code); return; }
            web.evaluateJavascript(code, null);
        });
    }

    private void enqueueJs(String code) {
        runOnUiThread(() -> {
            if (!pageReady || web == null) { pendingJsEvents.add(code); return; }
            web.evaluateJavascript(code, null);
        });
    }

    private void flushJsEvents() {
        if (web == null || !pageReady) return;
        for (String code : new ArrayList<>(pendingJsEvents)) web.evaluateJavascript(code, null);
        pendingJsEvents.clear();
    }

    private String guessMime(String name) {
        String n = name.toLowerCase(Locale.ROOT);
        if (n.endsWith(".jpg") || n.endsWith(".jpeg")) return "image/jpeg";
        if (n.endsWith(".png")) return "image/png";
        if (n.endsWith(".webp")) return "image/webp";
        if (n.endsWith(".gif")) return "image/gif";
        if (n.endsWith(".pdf")) return "application/pdf";
        if (n.endsWith(".doc")) return "application/msword";
        if (n.endsWith(".docx")) return "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
        if (n.endsWith(".xls")) return "application/vnd.ms-excel";
        if (n.endsWith(".xlsx")) return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
        if (n.endsWith(".ppt")) return "application/vnd.ms-powerpoint";
        if (n.endsWith(".pptx")) return "application/vnd.openxmlformats-officedocument.presentationml.presentation";
        if (n.endsWith(".txt")) return "text/plain";
        if (n.endsWith(".mp4")) return "video/mp4";
        if (n.endsWith(".mov")) return "video/quicktime";
        if (n.endsWith(".mp3")) return "audio/mpeg";
        return "application/octet-stream";
    }

    private JSONArray copyUrisToNative(List<Uri> uris) {
        JSONArray out = new JSONArray();
        for (Uri uri : uris) {
            try {
                String name = displayName(uri);
                String mime = getContentResolver().getType(uri);
                if (mime == null) mime = guessMime(name);
                String id = UUID.randomUUID().toString();
                File dest = new File(storeDir, safeId(id));
                try (InputStream in = getContentResolver().openInputStream(uri); OutputStream os = new FileOutputStream(dest)) {
                    if (in == null) continue;
                    byte[] buf = new byte[1024 * 64]; int len; while ((len=in.read(buf))!=-1) os.write(buf,0,len);
                }
                JSONObject o = new JSONObject();
                o.put("id", id); o.put("name", name); o.put("type", mime); o.put("size", dest.length());
                o.put("url", FILE_SCHEME + id);
                out.put(o);
            } catch (Exception ignored) {}
        }
        return out;
    }

    private String displayName(Uri uri) {
        Cursor c = null;
        try {
            c = getContentResolver().query(uri, new String[]{MediaStore.MediaColumns.DISPLAY_NAME}, null, null, null);
            if (c != null && c.moveToFirst()) { String n = c.getString(0); if (n != null && !n.isEmpty()) return n; }
        } catch (Exception ignored) {} finally { if (c != null) c.close(); }
        String p = uri.getLastPathSegment();
        return p == null ? "Archivo" : p;
    }

    private void openPicker() {
        // Real Android chooser: media uses the system Photo Picker when available;
        // documents use the Storage Access Framework. This is intentionally native,
        // not an HTML <input type=file>.
        new AlertDialog.Builder(this)
            .setTitle("Agregar contenido")
            .setItems(new String[]{"🖼️ Fotos y videos", "📄 Documentos y otros archivos"}, (d, which) -> {
                if (which == 0) openMediaPicker(); else openDocumentPicker();
            })
            .setNegativeButton("Cancelar", null)
            .show();
    }

    private void openMediaPicker() {
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                Intent i = new Intent("android.provider.action.PICK_IMAGES");
                i.setType("image/*");
                i.putExtra("android.provider.extra.PICK_IMAGES_MAX", 50);
                startActivityForResult(i, REQ_MEDIA);
                return;
            }
        } catch (Exception ignored) {}
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("image/*");
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        startActivityForResult(i, REQ_FILES);
    }

    private void openDocumentPicker() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        try { startActivityForResult(i, REQ_FILES); }
        catch (Exception e) { i.setAction(Intent.ACTION_GET_CONTENT); startActivityForResult(i, REQ_FILES); }
    }

    private void openCamera() {
        // Android's system camera intent is the preferred route for basic capture.
        // No CAMERA runtime permission is required for this flow.
        try {
            String id = UUID.randomUUID().toString() + ".jpg";
            File temp = new File(storeDir, safeId(id));
            cameraNativeId = id;
            cameraUri = FileProvider.getUriForFile(this, getString(R.string.file_provider_authority), temp);
            Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            i.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri);
            i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivityForResult(i, REQ_CAMERA);
        } catch (ActivityNotFoundException e) { toast("Este teléfono no tiene una aplicación de cámara disponible."); } catch (Exception e) { toast("No se pudo abrir la cámara: " + e.getMessage()); }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_CAMERA && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            openCamera();
        } else if (requestCode == REQ_NOTIFY && Build.VERSION.SDK_INT >= 33 && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            toast("🔔 Notificaciones activadas.");
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK) return;
        if (requestCode == REQ_MEDIA) {
            ArrayList<Uri> uris = new ArrayList<>();
            if (data != null && data.getClipData() != null) {
                for (int i=0;i<data.getClipData().getItemCount();i++) uris.add(data.getClipData().getItemAt(i).getUri());
            } else if (data != null && data.getData() != null) uris.add(data.getData());
            JSONArray rows = copyUrisToNative(uris);
            if (rows.length() > 0) sendJs("window.onNativeFiles(" + JSONObject.quote(rows.toString()) + ");");
            else toast("No se pudo leer ningún contenido seleccionado.");
        } else if (requestCode == REQ_FILES) {
            ArrayList<Uri> uris = new ArrayList<>();
            if (data != null && data.getClipData() != null) {
                for (int i=0;i<data.getClipData().getItemCount();i++) uris.add(data.getClipData().getItemAt(i).getUri());
            } else if (data != null && data.getData() != null) uris.add(data.getData());
            JSONArray rows = copyUrisToNative(uris);
            if (rows.length() > 0) sendJs("window.onNativeFiles(" + JSONObject.quote(rows.toString()) + ");");
            else toast("No se pudo leer ningún archivo seleccionado.");
        } else if (requestCode == REQ_CAMERA && cameraNativeId != null) {
            File f = new File(storeDir, safeId(cameraNativeId));
            if (f.exists() && f.length() > 0) {
                JSONArray a = new JSONArray();
                try { JSONObject o = new JSONObject(); o.put("id",cameraNativeId);o.put("name","Foto_"+System.currentTimeMillis()+".jpg");o.put("type","image/jpeg");o.put("size",f.length());o.put("url",FILE_SCHEME+cameraNativeId);a.put(o); } catch(Exception ignored){}
                sendJs("window.onNativeFiles(" + JSONObject.quote(a.toString()) + ");");
            } else toast("La cámara no devolvió una fotografía.");
            cameraNativeId=null;cameraUri=null;
        }
    }

    private void handleIntent(Intent intent) {
        if (intent == null) return;
        String action = intent.getAction();
        if (Intent.ACTION_SEND.equals(action) || Intent.ACTION_SEND_MULTIPLE.equals(action)) {
            ArrayList<Uri> uris = new ArrayList<>();
            if (Intent.ACTION_SEND_MULTIPLE.equals(action)) {
                ArrayList<Uri> x = intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM);
                if (x != null) uris.addAll(x);
            } else {
                Uri u = intent.getParcelableExtra(Intent.EXTRA_STREAM); if (u != null) uris.add(u);
            }
            if (!uris.isEmpty()) {
                JSONArray rows = copyUrisToNative(uris);
                String payload = rows.toString();
                if (pageReady && web != null) sendJs("window.onNativeSharedFiles(" + JSONObject.quote(payload) + ");");
                else { pendingSharedPayload = payload; getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString("pending_shared", payload).apply(); }
            }
        }
    }

    @Override public void onNewIntent(Intent intent) { super.onNewIntent(intent); setIntent(intent); handleIntent(intent); }

    private void shareStoredFile(String id, String name, String mime) {
        try {
            File f = new File(storeDir, safeId(id));
            if (!f.exists()) { toast("No se encontró el archivo guardado."); return; }
            Uri uri = FileProvider.getUriForFile(this, getString(R.string.file_provider_authority), f);
            Intent i = new Intent(Intent.ACTION_SEND); i.setType(mime == null ? guessMime(name) : mime); i.putExtra(Intent.EXTRA_STREAM, uri); i.putExtra(Intent.EXTRA_TEXT, "Archivo de MI ORGANIZADOR");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(i, "Compartir archivo"));
        } catch(Exception e) { toast("No se pudo compartir el archivo."); }
    }

    private void requestNotifications() {
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFY);
        else toast("Las notificaciones están disponibles en Android.");
    }

    private void scheduleReminder(String title, String project, long when, String tag) {
        if (when <= System.currentTimeMillis()) return;
        Intent i = new Intent(this, ReminderReceiver.class);
        i.putExtra("title", title); i.putExtra("project", project); i.putExtra("tag", tag);
        int request = Math.abs(tag.hashCode());
        PendingIntent pi = PendingIntent.getBroadcast(this, request, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        AlarmManager am = (AlarmManager)getSystemService(ALARM_SERVICE);
        if (Build.VERSION.SDK_INT >= 23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi); else am.setExact(AlarmManager.RTC_WAKEUP, when, pi);
    }

    private void toast(String s) { runOnUiThread(() -> Toast.makeText(this,s,Toast.LENGTH_LONG).show()); }

    public class AndroidBridge {
        @JavascriptInterface public void openFilePicker() { runOnUiThread(MainActivity.this::openPicker); }
        @JavascriptInterface public void openCamera() { runOnUiThread(MainActivity.this::openCamera); }
        @JavascriptInterface public void requestNotifications() { runOnUiThread(MainActivity.this::requestNotifications); }
        @JavascriptInterface public void scheduleReminder(String title,String project,long when,String tag) { MainActivity.this.scheduleReminder(title,project,when,tag); }
        @JavascriptInterface public void shareStoredFile(String id,String name,String mime) { runOnUiThread(() -> MainActivity.this.shareStoredFile(id,name,mime)); }
        @JavascriptInterface public String getPlatformInfo() { return "Android nativo · selector Photo Picker/Sistema · archivos · cámara · compartir · notificaciones"; }
        @JavascriptInterface public void showNativeDiagnostic() { runOnUiThread(() -> new AlertDialog.Builder(MainActivity.this).setTitle("MI ORGANIZADOR").setMessage("Puente Android nativo activo.

Cámara: disponible por Intent del sistema.
Archivos: selector Android activo.
Compartir: FileProvider activo.
Notificaciones: API Android activa.").setPositiveButton("OK", null).show()); }
    }
}
