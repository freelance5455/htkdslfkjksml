package com.spiderx.auxilio

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.content.pm.PackageManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var web: WebView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.webViewClient = WebViewClient()
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(AppBridge(), "Android")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }
    inner class AppBridge {
        @JavascriptInterface fun openFreeFire() { runOnUiThread {
            val launch = packageManager.getLaunchIntentForPackage("com.dts.freefireth")
            if (launch != null) startActivity(launch) else Toast.makeText(this@MainActivity, "Free Fire no está instalado", Toast.LENGTH_SHORT).show()
        } }
        @JavascriptInterface fun showMessage(message: String) { runOnUiThread { Toast.makeText(this@MainActivity, message, Toast.LENGTH_SHORT).show() } }
    }
    @Suppress("DEPRECATION") override fun onBackPressed() {
        if (::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
