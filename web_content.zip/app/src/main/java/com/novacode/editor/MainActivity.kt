package com.novacode.editor

import android.app.Activity
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import android.content.ActivityNotFoundException

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val OPEN_FILE = 101
    private val SAVE_FILE = 102
    private var pendingSaveText = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webChromeClient = WebChromeClient()
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(Bridge(), "AndroidBridge")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    inner class Bridge {
        @JavascriptInterface fun openFile() { runOnUiThread {
            try {
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                }
                startActivityForResult(i, OPEN_FILE)
            } catch (_: ActivityNotFoundException) {
                Toast.makeText(this@MainActivity, "لا يوجد تطبيق لاختيار الملفات", Toast.LENGTH_LONG).show()
            }
        } }
        @JavascriptInterface fun saveFile(text: String, filename: String) { runOnUiThread {
            pendingSaveText = text
            val i = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "text/plain"
                putExtra(Intent.EXTRA_TITLE, if (filename.isBlank()) "code.txt" else filename)
            }
            startActivityForResult(i, SAVE_FILE)
        } }
        @JavascriptInterface fun toast(message: String) {
            runOnUiThread { Toast.makeText(this@MainActivity, message, Toast.LENGTH_SHORT).show() }
        }
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data?.data == null) return
        val uri: Uri = data.data!!
        try {
            when (requestCode) {
                OPEN_FILE -> {
                    val text = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: ""
                    val encoded = android.util.Base64.encodeToString(text.toByteArray(Charsets.UTF_8), android.util.Base64.NO_WRAP)
                    web.evaluateJavascript("window.receiveOpenedFile('$encoded', '${uri.lastPathSegment?.replace("'", "") ?: "file.txt"}')", null)
                }
                SAVE_FILE -> {
                    contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(pendingSaveText) }
                    Toast.makeText(this, "تم حفظ الملف", Toast.LENGTH_SHORT).show()
                }
            }
        } catch (e: Exception) {
            Toast.makeText(this, "تعذّر التعامل مع الملف: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    override fun onBackPressed() {
        if (::web.isInitialized) web.evaluateJavascript("window.handleBack && window.handleBack()", null)
        else super.onBackPressed()
    }
}
