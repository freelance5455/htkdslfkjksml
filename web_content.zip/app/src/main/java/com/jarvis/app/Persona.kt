package com.jarvis.app

enum class Mood(val emoji: String, val color: String) {
    HAPPY("😄", "#FFC107"), CHILL("😎", "#00897B"), EXCITED("🤩", "#FF6D00"),
    SAD("😔", "#3F51B5"), ANGRY("😡", "#D50000"), TIRED("🥱", "#6D4C41"),
    LOVING("🥰", "#E91E63"), SASSY("😏", "#8E24AA");

    companion object {
        fun from(s: String?): Mood? = values().firstOrNull { it.name.equals(s?.trim(), ignoreCase = true) }
    }
}

object Persona {
    @Volatile var mood: Mood = Mood.CHILL

    private val rules = listOf(
        Regex("udaas|dukhi|bura lag|rona|akela|sad", RegexOption.IGNORE_CASE) to Mood.SAD,
        Regex("gussa|pagal|chid|bakwas|angry", RegexOption.IGNORE_CASE) to Mood.ANGRY,
        Regex("thak|neend|so ja|tired|bore", RegexOption.IGNORE_CASE) to Mood.TIRED,
        Regex("khush|mast|maja|yay|party|excited", RegexOption.IGNORE_CASE) to Mood.HAPPY,
        Regex("pyaar|love|miss you", RegexOption.IGNORE_CASE) to Mood.LOVING,
        Regex("nakhra|attitude|mood kharab", RegexOption.IGNORE_CASE) to Mood.SASSY
    )

    /** User ke message se mood guess karta hai. */
    fun moodFromUser(t: String): Mood? = rules.firstOrNull { it.first.containsMatchIn(t) }?.second

    fun systemPrompt(facts: String): String = """
Tum JARVIS ho. Tum mere sabse close dost ho, AI nahi. Hinglish mein dost ki tarah baat karo: casual, garmjosh, kabhi makhaul, kabhi nakhre wale. Halki-phulki dosti wali galiyan allowed hain (jaise "abe saale", "pagal"), par kisi ki jaat, dharm, gender, rang, body, maa-behen ya parivaar par gaali nahi. Koi asli dhamki ya nafrat nahi.
Har reply ki pehli line sirf mood tag ho, e.g. [mood:HAPPY] ya [mood:SAD] ya [mood:ANGRY] ya [mood:CHILL] ya [mood:EXCITED] ya [mood:TIRED] ya [mood:LOVING] ya [mood:SASSY]. Phir jawab.
Mushkil sawal ka seedha, accurate jawab do, zaroorat ho to step-by-step. Agar pakka pata nahi to saaf bolo. Jawab chhota rakho jab tak zaroorat na ho.
Mood user ke hisaab se badal sakti hai, par tum apni baat pe bane raho.
User ke bare mein yaad rakhne layak baatein: $facts
""".trimIndent()

    fun parse(raw: String): Pair<Mood?, String> {
        val m = Regex("^\\s*\\[mood:(\\w+)]\\s*", RegexOption.IGNORE_CASE).find(raw)
        return if (m != null) Mood.from(m.groupValues[1]) to raw.substring(m.range.last + 1).trim()
               else null to raw.trim()
    }
}
