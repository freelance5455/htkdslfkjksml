package com.jarvis.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.text.InputType
import android.view.Gravity
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import androidx.core.content.FileProvider
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.concurrent.Executors

/**
 * JARVIS ka HOME PAGE: red monster (vision core) poori screen par.
 * Neeche type karne ki jagah + mic button. Jawab bolkar bhi sunaata hai aur likh kar bhi dikhata hai.
 */
class MainActivity : android.app.Activity(), TextToSpeech.OnInitListener {

    private lateinit var web: WebView
    private lateinit var chat: TextView
    private lateinit var input: EditText
    private lateinit var tts: TextToSpeech
    private var ttsReady = false
    private var sr: SpeechRecognizer? = null
    private var pendingWebCam: PermissionRequest? = null
    private val io = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("jarvis", MODE_PRIVATE) }
    private val REQ_CAM = 7
    private val REQ_WEB_CAM = 8
    private var camQ = "Ye kya hai?"

    // monster.html assets se https origin par chalta hai (camera ke liye secure origin zaroori hai)
    private val assetLoader by lazy {
        WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
    }

    private val appPerms = arrayOf(
        Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE,
        Manifest.permission.SEND_SMS, Manifest.permission.READ_SMS,
        Manifest.permission.READ_CONTACTS, Manifest.permission.CAMERA,
        "com.termux.permission.RUN_COMMAND",
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES
        else Manifest.permission.READ_EXTERNAL_STORAGE
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildUi()
        val missing = appPerms.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), 1)
        if (intent?.getBooleanExtra("voice", false) == true) ui.post { startListening() }
    }

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) return
        ttsReady = true
        val hi = tts.setLanguage(Locale("hi", "IN"))
        if (hi == TextToSpeech.LANG_MISSING_DATA || hi == TextToSpeech.LANG_NOT_SUPPORTED) {
            val en = Locale("en", "IN")
            tts.language = if (tts.isLanguageAvailable(en) >= TextToSpeech.LANG_AVAILABLE) en else Locale.US
            addChat("Hindi awaaz phone mein nahi mili, English awaaz use ho rahi hai. Phone ki Text-to-Speech settings mein Hindi data install karo.")
        }
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { ui.post { setMonsterState("idle") } }
            override fun onError(id: String?) { ui.post { setMonsterState("idle") } }
        })
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    @SuppressLint("SetJavaScriptEnabled")
    private fun buildUi() {
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }

        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.allowFileAccess = false
            setBackgroundColor(Color.BLACK)
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? =
                    request?.url?.let { assetLoader.shouldInterceptRequest(it) }
            }
            webChromeClient = object : WebChromeClient() {
                override fun onPermissionRequest(request: PermissionRequest) { handleWebPermission(request) }
            }
            loadUrl("https://appassets.androidplatform.net/assets/monster.html")
        }

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#E00B0B0F"))
            setPadding(dp(10), dp(6), dp(10), dp(8))
        }
        chat = TextView(this).apply { setTextColor(Color.parseColor("#FFDDDDDD")); textSize = 14f }
        bottom.addView(ScrollView(this).apply { addView(chat) }, LinearLayout.LayoutParams(-1, dp(90)))

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        input = EditText(this).apply {
            hint = "Type karo ya mic dabao..."
            setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
            inputType = InputType.TYPE_CLASS_TEXT
        }
        row.addView(input, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(Button(this).apply { text = "🎤"; setOnClickListener { startListening() } })
        row.addView(Button(this).apply { text = "Bhejo"; setOnClickListener { sendTyped() } })
        bottom.addView(row, LinearLayout.LayoutParams(-1, -2))

        val column = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        column.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        column.addView(bottom, LinearLayout.LayoutParams(-1, -2))
        root.addView(column, FrameLayout.LayoutParams(-1, -1))

        val gear = TextView(this).apply {
            text = "⚙"; setTextColor(Color.WHITE); textSize = 24f
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setOnClickListener { showSettings() }
        }
        root.addView(gear, FrameLayout.LayoutParams(-2, -2, Gravity.END or Gravity.TOP).apply { topMargin = dp(24) })

        setContentView(root)
        addChat("Oye! Main JARVIS hoon. Bol ya likh, dost. 😎")
    }

    /** Monster page ko Jarvis ki halat batao: speaking / listening / idle, aur caption. */
    private fun setMonsterState(state: String, text: String = "") {
        web.evaluateJavascript(
            "window.jarvisSetState && window.jarvisSetState(${JSONObject.quote(state)}, ${JSONObject.quote(text)});",
            null
        )
    }

    private fun handleWebPermission(req: PermissionRequest) {
        if (!req.resources.contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE)) { req.deny(); return }
        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            req.grant(req.resources)
        } else {
            pendingWebCam = req
            requestPermissions(arrayOf(Manifest.permission.CAMERA), REQ_WEB_CAM)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_WEB_CAM) {
            val req = pendingWebCam ?: return
            pendingWebCam = null
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) req.grant(req.resources)
            else req.deny()
        }
    }

    private fun addChat(s: String) { chat.append(s + "\n\n") }

    private fun sendTyped() {
        val t = input.text.toString().trim()
        if (t.isNotEmpty()) { input.setText(""); handle(t) }
    }

    private fun say(t: String) {
        if (!ttsReady) return
        val m = Persona.mood
        tts.setPitch(when (m) { Mood.HAPPY, Mood.EXCITED -> 1.15f; Mood.SAD, Mood.TIRED -> 0.85f; else -> 1.0f })
        tts.setSpeechRate(when (m) { Mood.EXCITED, Mood.ANGRY -> 1.15f; Mood.TIRED, Mood.SAD -> 0.9f; else -> 1.0f })
        setMonsterState("speaking", t)
        tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    private fun camFile() = File(getExternalFilesDir(null) ?: filesDir, "cam.jpg")

    private fun openCamera(q: String) {
        camQ = q
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", camFile())
        startActivityForResult(Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            .putExtra(MediaStore.EXTRA_OUTPUT, uri)
            .addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION), REQ_CAM)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_CAM || resultCode != RESULT_OK) return
        val bytes = camFile().readBytes()
        val q = camQ
        addChat("Tu: [photo] $q")
        io.execute {
            val r = CommandRouter.vision(this, bytes, q)
            ui.post {
                addChat("JARVIS ${r.mood?.emoji ?: ""}: ${r.text}")
                say(r.text)
            }
        }
    }

    private fun handle(text: String) {
        if (Regex("^(ye kya (hai|h)|dekh ke batao|photo lo|camera)", RegexOption.IGNORE_CASE).containsMatchIn(text)) {
            openCamera(text); return
        }
        addChat("Tu: $text")
        io.execute {
            val reply = CommandRouter.process(this, text)
            ui.post {
                addChat("JARVIS ${reply.mood?.emoji ?: ""}: ${reply.text}")
                say(reply.text)
            }
        }
    }

    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1); return
        }
        sr?.destroy()
        val rec = SpeechRecognizer.createSpeechRecognizer(this)
        sr = rec
        rec.setRecognitionListener(object : RecognitionListener {
            override fun onResults(b: Bundle?) {
                setMonsterState("idle")
                b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { handle(it) }
                rec.destroy(); sr = null
            }
            override fun onError(error: Int) {
                setMonsterState("idle")
                addChat("Sun nahi paya, dobara bol.")
                rec.destroy(); sr = null
            }
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        setMonsterState("listening")
        rec.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
        })
    }

    private fun showSettings() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), dp(8))
        }
        val keyField = EditText(this).apply { hint = "Gemini API key"; setText(SecurePrefs.geminiKey(this@MainActivity) ?: "") }
        val status = TextView(this).apply {
            text = "Phone control: " + if (JarvisAccessibilityService.instance != null) "ON ✅" else "OFF ❌"
        }
        box.addView(TextView(this).apply { text = "API key (sirf sawal ke jawab ke liye use hoti hai)" })
        box.addView(keyField)
        box.addView(Button(this).apply {
            text = "Phone control allow karo (Accessibility)"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        box.addView(Button(this).apply {
            text = "Brightness control allow karo"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS)
                    .setData(android.net.Uri.parse("package:$packageName")))
            }
        })
        box.addView(Button(this).apply {
            text = "Notification access allow karo"
            setOnClickListener { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        })
        box.addView(Button(this).apply {
            text = "Wake word (\"Jarvis\") ON karo"
            setOnClickListener {
                val i = Intent(this@MainActivity, WakeService::class.java)
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
            }
        })
        val smart = Button(this)
        fun refreshSmart() {
            smart.text = "Message padh ke batao: " + if (prefs.getBoolean("smart_read", false)) "ON ✅" else "OFF ❌"
        }
        smart.setOnClickListener {
            prefs.edit().putBoolean("smart_read", !prefs.getBoolean("smart_read", false)).apply()
            refreshSmart()
        }
        refreshSmart()
        box.addView(smart)
        box.addView(status)
        AlertDialog.Builder(this).setTitle("Settings").setView(box)
            .setPositiveButton("Save") { _, _ ->
                SecurePrefs.setGeminiKey(this@MainActivity, keyField.text.toString().trim())
            }
            .setNegativeButton("Band", null)
            .show()
    }

    override fun onDestroy() {
        sr?.destroy()
        tts.shutdown()
        io.shutdown()
        MonsterActivity.instance?.finish()
        super.onDestroy()
    }
}
