package com.jarvis.app

import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.MediaStore
import android.content.pm.PackageManager
import android.Manifest
import android.os.Build
import android.widget.Toast

/**
 * Phone ke kaam jo Jarvis safe tareeke se karta hai:
 * - Play Store mein search (install user khud tap karega)
 * - Google par APK ka search (download user khud chunega)
 * - Photos list, delete (Android ka system confirmation popup aayega)
 * - Photo WhatsApp par share (contact user khud chunega)
 */
object PhoneTools {
    /** Last baar mili photos. */
    @Volatile var lastPhotos: List<Uri> = emptyList()

    private fun enc(s: String) = Uri.encode(s)

    fun playStore(ctx: Context, query: String): String {
        val market = Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=${enc(query)}&c=apps"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            ctx.startActivity(market)
            "Play Store mein \"$query\" khol diya. Install button aap khud dabayein."
        } catch (e: Exception) {
            val web = Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/search?q=${enc(query)}&c=apps"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try { ctx.startActivity(web); "Browser mein Play Store search khol diya." }
            catch (e2: Exception) { "Play Store khul nahi paya." }
        }
    }

    /** Google par search khol deta hai. Download aap khud official source se karein. */
    fun googleApk(ctx: Context, app: String): String {
        val url = "https://www.google.com/search?q=${enc("$app apk official download")}"
        return try {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            "Google par \"$app\" ka official APK search khol diya. Sirf official ya trusted site se download karein."
        } catch (e: Exception) { "Browser khul nahi paya." }
    }

    fun hasPhotoPermission(ctx: Context): Boolean {
        val p = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES
                else Manifest.permission.READ_EXTERNAL_STORAGE
        return ctx.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED
    }

    fun loadRecentPhotos(ctx: Context, n: Int): List<Uri> {
        if (!hasPhotoPermission(ctx)) return emptyList()
        val list = mutableListOf<Uri>()
        val base = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        ctx.contentResolver.query(
            base, arrayOf(MediaStore.Images.Media._ID), null, null,
            "${MediaStore.Images.Media.DATE_ADDED} DESC"
        )?.use { c ->
            val idCol = c.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
            while (c.moveToNext() && list.size < n) {
                list.add(ContentUris.withAppendedId(base, c.getLong(idCol)))
            }
        }
        lastPhotos = list
        return list
    }

    fun listPhotos(ctx: Context): String {
        val photos = loadRecentPhotos(ctx, 5)
        if (!hasPhotoPermission(ctx)) return "Photos dekhne ke liye Storage/Photos permission do."
        if (photos.isEmpty()) return "Koi photo nahi mili."
        return "Aapki latest ${photos.size} photos mil gayi. 'photo delete karo' ya 'photo WhatsApp par bhejo' bolo."
    }

    /** Delete se pehle "haan" lo. Phir Android ka apna popup bhi confirm karega. */
    fun askDelete(ctx: Context, count: Int): String {
        val photos = loadRecentPhotos(ctx, count)
        if (!hasPhotoPermission(ctx)) return "Photos ke liye permission chahiye."
        if (photos.isEmpty()) return "Delete karne ke liye photo nahi mili."
        Pending.set("delete") {
            launch(ctx, "delete", photos)
            "Delete ki request khol di. Phone ke popup par confirm karein."
        }
        return "Ye ${photos.size} photo delete karun? 'haan' ya 'nahi' bolo. Phone bhi ek alag confirmation dikhayega."
    }

    /** Latest photo WhatsApp ke share screen mein khulegi. Contact aap khud chunenge. */
    fun shareLatestToWhatsApp(ctx: Context): String {
        val photos = loadRecentPhotos(ctx, 1)
        if (!hasPhotoPermission(ctx)) return "Photos ke liye permission chahiye."
        if (photos.isEmpty()) return "Bhejne ke liye photo nahi mili."
        launch(ctx, "share", photos)
        return "WhatsApp khol raha hoon. Contact aap khud chunkar bhejiye."
    }

    fun openCameraForPhoto(ctx: Context): String {
        val i = Intent("android.media.action.IMAGE_CAPTURE").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return if (i.resolveActivity(ctx.packageManager) != null) {
            ctx.startActivity(i); "Camera khol diya. Photo aap khud click karein."
        } else "Camera app nahi mili."
    }

    private fun launch(ctx: Context, action: String, uris: List<Uri>) {
        ctx.startActivity(
            Intent(ctx, PhotoActionActivity::class.java)
                .putExtra("action", action)
                .putParcelableArrayListExtra("uris", ArrayList(uris))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }
}
