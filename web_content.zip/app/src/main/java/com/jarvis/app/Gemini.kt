package com.jarvis.app

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class GeminiException(val code: Int, detail: String) : Exception(friendly(code, detail)) {
    companion object {
        fun friendly(code: Int, detail: String): String = when (code) {
            400 -> "Request galat hai (400)."
            401, 403 -> "Gemini key galat ya band hai. Settings (⚙) mein dobara daalo."
            404 -> "Model abhi uplabdh nahi (404)."
            429 -> "Gemini ki limit khatam ho gayi, thodi der baad try karo (429)."
            in 500..599 -> "Gemini server busy hai ($code). Thodi der baad try karo."
            else -> "Gemini error $code: ${detail.take(120)}"
        }
    }
}

/**
 * Ek hi jagah saare Gemini calls.
 *  - Key URL mein nahi, header (x-goog-api-key) mein jaati hai, taaki log/history mein na aaye.
 *  - Model band ho (404) to agla model try hota hai.
 *  - Non-2xx jawab par saaf error message milta hai.
 */
object Gemini {
    val TEXT_MODELS = listOf("gemini-2.0-flash", "gemini-1.5-flash")
    const val IMAGE_MODEL = "gemini-2.0-flash-preview-image-generation"
    private const val BASE = "https://generativelanguage.googleapis.com/v1beta/models/"

    private fun call(key: String, model: String, body: JSONObject): JSONObject {
        val conn = URL(BASE + model + ":generateContent").openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("x-goog-api-key", key)
            conn.doOutput = true
            conn.connectTimeout = 15000
            conn.readTimeout = 90000
            conn.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) throw GeminiException(code, text)
            return JSONObject(text)
        } finally {
            conn.disconnect()
        }
    }

    /** Models ko ek-ek karke try karta hai. 404 ho to agla model; baaki errors seedha upar. */
    fun run(key: String, body: JSONObject, models: List<String> = TEXT_MODELS): JSONObject {
        var last: Exception? = null
        for (m in models) {
            try {
                return call(key, m, body)
            } catch (e: GeminiException) {
                if (e.code != 404) throw e
                last = e
            }
        }
        throw last ?: Exception("Gemini: koi model nahi chala")
    }

    private fun parts(j: JSONObject): JSONArray =
        j.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts")

    /** Sirf text parts jodta hai (thinking parts chhod kar). */
    fun textFrom(j: JSONObject): String {
        val ps = parts(j)
        val sb = StringBuilder()
        for (i in 0 until ps.length()) {
            val p = ps.getJSONObject(i)
            if (p.has("text") && !p.optBoolean("thought")) sb.append(p.getString("text"))
        }
        return sb.toString().trim()
    }

    private fun userParts(vararg p: JSONObject) = JSONObject().put(
        "contents", JSONArray().put(JSONObject().put("parts", JSONArray().apply { p.forEach { put(it) } }))
    )

    fun text(key: String, prompt: String): String =
        textFrom(run(key, userParts(JSONObject().put("text", prompt))))

    /** Photo + sawal. jpg = JPEG bytes. */
    fun vision(key: String, prompt: String, jpg: ByteArray): String {
        val img = JSONObject().put("inlineData", JSONObject()
            .put("mimeType", "image/jpeg")
            .put("data", Base64.encodeToString(jpg, Base64.NO_WRAP)))
        return textFrom(run(key, userParts(JSONObject().put("text", prompt), img)))
    }

    fun image(key: String, prompt: String): ByteArray {
        val body = userParts(JSONObject().put("text", prompt)).put("generationConfig",
            JSONObject().put("responseModalities", JSONArray().put("TEXT").put("IMAGE")))
        val ps = parts(run(key, body, listOf(IMAGE_MODEL)))
        for (i in 0 until ps.length()) {
            val p = ps.getJSONObject(i)
            if (p.has("inlineData"))
                return Base64.decode(p.getJSONObject("inlineData").getString("data"), Base64.DEFAULT)
        }
        throw Exception("Image nahi bani, dobara try karo")
    }
}
