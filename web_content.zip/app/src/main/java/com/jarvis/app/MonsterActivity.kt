package com.jarvis.app

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.webkit.WebView

/**
 * Monster / hologram page. Ye tab band hota hai:
 *  1) "monster band karo" ya "jarvis band karo" bolne par
 *  2) phone screen off hone par
 *  3) JARVIS app band hone par (MainActivity.onDestroy se)
 */
class MonsterActivity : Activity() {
    companion object {
        @Volatile var instance: MonsterActivity? = null
    }

    private val screenOff = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) { finish() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        instance = this
        registerReceiver(screenOff, IntentFilter(Intent.ACTION_SCREEN_OFF))
        val wv = WebView(this)
        wv.settings.javaScriptEnabled = true
        wv.loadUrl("file:///android_asset/monster.html")
        setContentView(wv)
    }

    override fun onDestroy() {
        instance = null
        try { unregisterReceiver(screenOff) } catch (e: Exception) { }
        super.onDestroy()
    }
}
