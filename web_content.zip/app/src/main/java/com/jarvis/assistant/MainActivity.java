package com.jarvis.assistant;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.RecognitionListener;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import org.json.JSONObject;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Set;

/**
 * Android host for the JARVIS offline chat UI.
 * Requires the project's existing OfflineLlm class and assets/index.html.
 */
public class MainActivity extends Activity {
    private static final int REQ_AUDIO = 100;
    private static final String MODEL_NAME = "Qwen3-0.6B.litertlm";
    // Used only for progress display/storage estimates. Do not use this as the sole
    // validity test: a repository may change the file size without changing its name.
    private static final long MODEL_SIZE_ESTIMATE = 613722264L;
    private static final long MIN_PLAUSIBLE_MODEL_SIZE = 100_000_000L;
    private static final String MODEL_URL =
            "https://huggingface.co/litert-community/Qwen3-0.6B/resolve/main/Qwen3-0.6B.litertlm?download=true";

    private WebView webView;
    private TextToSpeech tts;
    private SpeechRecognizer recognizer;
    private OfflineLlm offlineLlm;
    private volatile boolean downloadingModel = false;
    private volatile boolean pageLoaded = false;
    private volatile boolean offlineTtsReady = false;

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(7, 17, 15));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(7, 17, 15));

        offlineLlm = new OfflineLlm(this);
        webView = new WebView(this);
        webView.setBackgroundColor(android.graphics.Color.rgb(7, 17, 15));
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                pageLoaded = true;
                publishModelStatus();
                if (isModelFilePlausible(modelFile())) {
                    loadLocalModel();
                }
            }
        });
        webView.addJavascriptInterface(new Bridge(), "JarvisNative");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
        initializeTextToSpeech();
    }

    private void initializeTextToSpeech() {
        tts = new TextToSpeech(this, status -> {
            if (status != TextToSpeech.SUCCESS || tts == null) return;
            try {
                Set<Voice> voices = tts.getVoices();
                Voice selected = null;
                if (voices != null) {
                    String language = Locale.getDefault().getLanguage();
                    for (Voice voice : voices) {
                        if (!voice.isNetworkConnectionRequired()
                                && voice.getLocale() != null
                                && voice.getLocale().getLanguage().equals(language)) {
                            selected = voice;
                            break;
                        }
                    }
                    if (selected == null) {
                        for (Voice voice : voices) {
                            if (!voice.isNetworkConnectionRequired()) {
                                selected = voice;
                                break;
                            }
                        }
                    }
                }
                if (selected != null && tts.setVoice(selected) == TextToSpeech.SUCCESS) {
                    offlineTtsReady = true;
                }
            } catch (Exception ignored) {
                offlineTtsReady = false;
            }
        });
    }

    private File modelFile() {
        return new File(getFilesDir(), MODEL_NAME);
    }

    private boolean isModelFilePlausible(File file) {
        return file != null && file.isFile() && file.length() >= MIN_PLAUSIBLE_MODEL_SIZE;
    }

    private void runJs(String javascript) {
        runOnUiThread(() -> {
            WebView current = webView;
            if (current != null && pageLoaded) {
                current.evaluateJavascript(javascript, null);
            }
        });
    }

    private void publishModelStatus() {
        File file = modelFile();
        boolean downloaded = isModelFilePlausible(file);
        String message;
        boolean ready = offlineLlm != null && offlineLlm.isReady();
        if (downloadingModel) {
            message = "Downloading the model…";
        } else if (ready) {
            message = "Offline AI model is loaded and ready.";
        } else if (offlineLlm != null && offlineLlm.isLoading()) {
            message = "Model downloaded; loading into memory…";
        } else if (downloaded) {
            message = "Model file is present. Tap Load model to initialize offline AI.";
        } else {
            message = "Model not downloaded. Connect to Wi-Fi and download the model first.";
        }
        runJs("if (typeof window.localModelStatus === 'function') window.localModelStatus(" +
                ready + "," + JSONObject.quote(message) + ");");
    }

    private void loadLocalModel() {
        if (offlineLlm == null) {
            runJs("if (typeof window.localModelStatus === 'function') window.localModelStatus(false," +
                    JSONObject.quote("Offline inference engine is not initialized. Check OfflineLlm and its dependencies.") + ");");
            return;
        }
        if (offlineLlm.isReady()) {
            publishModelStatus();
            return;
        }
        if (offlineLlm.isLoading()) {
            publishModelStatus();
            return;
        }
        File file = modelFile();
        if (!isModelFilePlausible(file)) {
            runJs("if (typeof window.localModelStatus === 'function') window.localModelStatus(false," +
                    JSONObject.quote("Model file is missing or too small. Download it again from AI Settings.") + ");");
            return;
        }
        try {
            offlineLlm.load(file.getAbsolutePath(), (ready, message) -> {
                String safeMessage = message == null ? (ready ? "Offline AI model is ready." : "Model failed to load.") : message;
                runJs("if (typeof window.localModelStatus === 'function') window.localModelStatus(" +
                        ready + "," + JSONObject.quote(safeMessage) + ");");
            });
        } catch (Exception e) {
            String message = e.getMessage() == null ? "Could not initialize the offline model." : e.getMessage();
            runJs("if (typeof window.localModelStatus === 'function') window.localModelStatus(false," +
                    JSONObject.quote(message) + ");");
        }
    }

    public class Bridge {
        @JavascriptInterface
        public void speak(String text) {
            runOnUiThread(() -> {
                if (tts != null && offlineTtsReady && text != null && !text.trim().isEmpty()) {
                    tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply");
                }
            });
        }

        @JavascriptInterface
        public void listen() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= 23
                        && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
                    return;
                }
                startListening();
            });
        }

        @JavascriptInterface
        public String appVersion() {
            return "2.1 · Offline on-device language model";
        }

        @JavascriptInterface
        public String modelStatus() {
            if (downloadingModel) return "Downloading the model…";
            if (offlineLlm != null && offlineLlm.isReady()) return "Offline AI model is loaded and ready.";
            if (offlineLlm != null && offlineLlm.isLoading()) return "Model downloaded; loading into memory…";
            if (isModelFilePlausible(modelFile())) return "Model file is present. Tap Load model.";
            return "Model not downloaded. Download once using Wi-Fi (about 586 MB).";
        }

        @JavascriptInterface
        public boolean isModelDownloaded() {
            return isModelFilePlausible(modelFile());
        }

        @JavascriptInterface
        public void loadModel() {
            loadLocalModel();
        }

        @JavascriptInterface
        public void askAI(String prompt, String history, String requestId) {
            // Normalize the user's input first so null or whitespace-only prompts are rejected.
            final String userText = prompt == null ? "" : prompt.trim();
            final String context = history == null ? "" : history;
            final String rid = requestId == null ? "" : requestId;
            if (userText.isEmpty()) {
                runJs("if (typeof window.aiResult === 'function') window.aiResult(" +
                        JSONObject.quote(rid) + "," + JSONObject.quote("Please enter a question first.") + ");");
                return;
            }
            // A general assistant persona supports the user's requested language, not C alone.
            final String question = "You are a helpful, accurate AI assistant. Answer the user's actual question directly. For programming requests, provide code in the language requested by the user and explain it briefly when useful. Do not assume every question is about C.\n\nUser Question: " + userText;
            if (offlineLlm == null || !offlineLlm.isReady()) {
                runJs("if (typeof window.aiResult === 'function') window.aiResult(" +
                        JSONObject.quote(rid) + "," + JSONObject.quote("Offline AI is not ready. Open Menu → AI Settings, download the model if needed, then tap Load model. If it still fails, check the model loading error in AI Settings.") + ");");
                return;
            }
            try {
                offlineLlm.generate(question, context, answer -> {
                    String result = answer == null || answer.trim().isEmpty()
                            ? "The local model returned an empty answer. Try a shorter prompt or check the model/runtime compatibility."
                            : answer;
                    runJs("if (typeof window.aiResult === 'function') window.aiResult(" +
                            JSONObject.quote(rid) + "," + JSONObject.quote(result) + ");");
                });
            } catch (Exception e) {
                String message = e.getMessage() == null ? "Local inference failed." : e.getMessage();
                runJs("if (typeof window.aiResult === 'function') window.aiResult(" +
                        JSONObject.quote(rid) + "," + JSONObject.quote("Local AI error: " + message) + ");");
            }
        }

        @JavascriptInterface
        public void downloadModel() {
            if (downloadingModel) return;
            if (offlineLlm != null && offlineLlm.isReady()) {
                runJs("if (typeof window.modelDownloadFinished === 'function') window.modelDownloadFinished(true," +
                        JSONObject.quote("The model is already loaded and ready.") + ");");
                return;
            }
            File existing = modelFile();
            if (isModelFilePlausible(existing)) {
                runJs("if (typeof window.modelDownloadFinished === 'function') window.modelDownloadFinished(true," +
                        JSONObject.quote("The model file is already downloaded. Tap Load model.") + ");");
                return;
            }

            downloadingModel = true;
            publishModelStatus();
            new Thread(() -> downloadModelInBackground(), "jarvis-model-download").start();
        }
    }

    private void downloadModelInBackground() {
        HttpURLConnection connection = null;
        File temp = new File(getFilesDir(), MODEL_NAME + ".download");
        String failure = null;
        try {
            long requiredSpace = MODEL_SIZE_ESTIMATE + 250_000_000L;
            if (getFilesDir().getUsableSpace() < requiredSpace) {
                throw new Exception("Not enough free storage. Please free about 850 MB and try again.");
            }
            URL url = new URL(MODEL_URL);
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setConnectTimeout(25000);
            connection.setReadTimeout(60000);
            connection.setInstanceFollowRedirects(true);
            connection.setRequestProperty("User-Agent", "JARVIS-Offline-Android/2.1");
            int responseCode = connection.getResponseCode();
            if (responseCode != HttpURLConnection.HTTP_OK) {
                throw new Exception("Model download failed (HTTP " + responseCode + "). Check the connection and retry.");
            }
            long expectedLength = connection.getContentLengthLong();
            long downloaded = 0;
            byte[] buffer = new byte[64 * 1024];
            try (InputStream input = connection.getInputStream();
                 FileOutputStream output = new FileOutputStream(temp, false)) {
                int count;
                while ((count = input.read(buffer)) != -1) {
                    output.write(buffer, 0, count);
                    downloaded += count;
                    long denominator = expectedLength > 0 ? expectedLength : MODEL_SIZE_ESTIMATE;
                    int percent = (int) Math.max(0, Math.min(99, (downloaded * 100L) / denominator));
                    final int progress = percent;
                    runJs("if (typeof window.modelDownloadProgress === 'function') window.modelDownloadProgress(" + progress + ");");
                }
                output.getFD().sync();
            }
            if (downloaded < MIN_PLAUSIBLE_MODEL_SIZE) {
                throw new Exception("The downloaded file is unexpectedly small and may not be a valid model. Please retry.");
            }
            if (expectedLength > 0 && downloaded != expectedLength) {
                throw new Exception("Download was incomplete (received " + downloaded + " of " + expectedLength + " bytes). Please retry.");
            }
            File target = modelFile();
            if (target.exists() && !target.delete()) {
                throw new Exception("Could not replace the previous model file.");
            }
            if (!temp.renameTo(target)) {
                // renameTo can fail across filesystems; copy within app storage as fallback.
                try (InputStream input = new java.io.FileInputStream(temp);
                     FileOutputStream output = new FileOutputStream(target, false)) {
                    byte[] copyBuffer = new byte[64 * 1024];
                    int count;
                    while ((count = input.read(copyBuffer)) != -1) output.write(copyBuffer, 0, count);
                    output.getFD().sync();
                }
                if (target.length() != downloaded) {
                    //noinspection ResultOfMethodCallIgnored
                    target.delete();
                    throw new Exception("Could not save the complete model file.");
                }
                //noinspection ResultOfMethodCallIgnored
                temp.delete();
            }
        } catch (Exception e) {
            failure = e.getMessage() == null ? "Model download failed." : e.getMessage();
            //noinspection ResultOfMethodCallIgnored
            temp.delete();
        } finally {
            if (connection != null) connection.disconnect();
            downloadingModel = false;
        }

        final boolean success = failure == null;
        final String resultMessage = success
                ? "Model downloaded. Tap Load model to initialize it; then test chat before switching off the internet."
                : failure;
        runJs("if (typeof window.modelDownloadFinished === 'function') window.modelDownloadFinished(" +
                success + "," + JSONObject.quote(resultMessage) + ");");
        publishModelStatus();
    }

    private void startListening() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S
                || !SpeechRecognizer.isOnDeviceRecognitionAvailable(this)) {
            runJs("if (typeof window.voiceError === 'function') window.voiceError(" +
                    JSONObject.quote("Offline voice recognition is not installed on this device. You can type instead.") + ");");
            return;
        }
        try {
            if (recognizer != null) recognizer.destroy();
            recognizer = SpeechRecognizer.createOnDeviceSpeechRecognizer(this);
            recognizer.setRecognitionListener(new RecognitionListener() {
                @Override public void onReadyForSpeech(Bundle params) { }
                @Override public void onBeginningOfSpeech() { }
                @Override public void onRmsChanged(float rmsdB) { }
                @Override public void onBufferReceived(byte[] buffer) { }
                @Override public void onEndOfSpeech() { }
                @Override public void onError(int error) {
                    runJs("if (typeof window.voiceError === 'function') window.voiceError(" +
                            JSONObject.quote("Voice input failed. Try typing or install an offline speech language pack.") + ");");
                }
                @Override public void onResults(Bundle results) {
                    ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (matches != null && !matches.isEmpty()) {
                        runJs("if (typeof window.voiceResult === 'function') window.voiceResult(" +
                                JSONObject.quote(matches.get(0)) + ");");
                    }
                }
                @Override public void onPartialResults(Bundle partialResults) { }
                @Override public void onEvent(int eventType, Bundle params) { }
            });
            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag());
            intent.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true);
            recognizer.startListening(intent);
        } catch (Exception e) {
            runJs("if (typeof window.voiceError === 'function') window.voiceError(" +
                    JSONObject.quote("Could not start offline voice recognition: " +
                            (e.getMessage() == null ? "unknown error" : e.getMessage())) + ");");
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_AUDIO && grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startListening();
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        pageLoaded = false;
        if (recognizer != null) recognizer.destroy();
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        if (offlineLlm != null) offlineLlm.close();
        if (webView != null) {
            webView.removeJavascriptInterface("JarvisNative");
            webView.destroy();
        }
        super.onDestroy();
    }
}
