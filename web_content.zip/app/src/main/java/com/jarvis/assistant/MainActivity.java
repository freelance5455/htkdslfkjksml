package com.jarvis.assistant;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Build;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.RecognitionListener;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import org.json.JSONObject;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Set;

public class MainActivity extends Activity {
    private WebView webView;
    private TextToSpeech tts;
    private SpeechRecognizer recognizer;
    private OfflineLlm offlineLlm;
    private volatile boolean downloadingModel = false;
    private volatile boolean offlineTtsReady = false;
    private static final int REQ_AUDIO = 100;
    private static final String MODEL_NAME = "Qwen3-0.6B.litertlm";
    private static final long MODEL_SIZE = 613722264L;
    private static final String MODEL_URL = "https://huggingface.co/litert-community/Qwen3-0.6B/resolve/main/Qwen3-0.6B.litertlm?download=true";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(7, 17, 15));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(7, 17, 15));
        offlineLlm = new OfflineLlm(this);
        webView = new WebView(this);
        webView.setBackgroundColor(android.graphics.Color.rgb(7, 17, 15));
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (modelFile().isFile() && modelFile().length() == MODEL_SIZE) loadLocalModel();
            }
        });
        webView.addJavascriptInterface(new Bridge(), "JarvisNative");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
        tts = new TextToSpeech(this, status -> {
            if (status != TextToSpeech.SUCCESS || tts == null) return;
            try {
                Set<Voice> voices = tts.getVoices();
                Voice selected = null;
                if (voices != null) {
                    String language = Locale.getDefault().getLanguage();
                    for (Voice voice : voices) {
                        if (!voice.isNetworkConnectionRequired() && voice.getLocale().getLanguage().equals(language)) { selected = voice; break; }
                    }
                    if (selected == null) for (Voice voice : voices) { if (!voice.isNetworkConnectionRequired()) { selected = voice; break; } }
                }
                if (selected != null) { tts.setVoice(selected); offlineTtsReady = true; }
            } catch (Exception ignored) { offlineTtsReady = false; }
        });
    }

    private File modelFile() { return new File(getFilesDir(), MODEL_NAME); }

    private void loadLocalModel() {
        File file = modelFile();
        if (!file.isFile() || file.length() != MODEL_SIZE) {
            if (webView != null) webView.post(() -> webView.evaluateJavascript("window.localModelStatus(false," + JSONObject.quote("Model not downloaded yet.") + ")", null));
            return;
        }
        offlineLlm.load(file.getAbsolutePath(), new OfflineLlm.StatusCallback() {
            @Override public void onStatus(boolean ready, String message) {
                runOnUiThread(() -> {
                    if (webView != null) webView.evaluateJavascript("window.localModelStatus(" + ready + "," + JSONObject.quote(message) + ")", null);
                });
            }
        });
    }

    private class Bridge {
        @JavascriptInterface public void speak(String text) {
            runOnUiThread(() -> { if (tts != null && offlineTtsReady) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply"); });
        }
        @JavascriptInterface public void listen() {
            runOnUiThread(() -> {
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO); return;
                }
                startListening();
            });
        }
        @JavascriptInterface public String appVersion() { return "2.0 · Offline on-device language model"; }
        @JavascriptInterface public String modelStatus() {
            File f = modelFile();
            if (downloadingModel) return "Downloading the model…";
            if (!f.isFile() || f.length() != MODEL_SIZE) return "Model not downloaded. Download once using Wi-Fi (about 586 MB).";
            if (offlineLlm != null && offlineLlm.isReady()) return "Offline AI model is loaded and ready.";
            if (offlineLlm != null && offlineLlm.isLoading()) return "Model downloaded; loading into memory…";
            return "Model downloaded (586 MB). Tap Load model.";
        }
        @JavascriptInterface public boolean isModelDownloaded() {
            File f = modelFile(); return f.isFile() && f.length() == MODEL_SIZE;
        }
        @JavascriptInterface public void loadModel() { loadLocalModel(); }
        @JavascriptInterface public void downloadModel() {
            if (downloadingModel) return;
            File existing = modelFile();
            if (existing.isFile() && existing.length() == MODEL_SIZE) {
                runOnUiThread(() -> webView.evaluateJavascript("window.modelDownloadFinished(true," + JSONObject.quote("The model is already downloaded. Tap Load model.") + ")", null));
                return;
            }
            if (offlineLlm != null && offlineLlm.isReady()) {
                runOnUiThread(() -> webView.evaluateJavascript("window.modelDownloadFinished(false," + JSONObject.quote("The model is already loaded.") + ")", null));
                return;
            }
            downloadingModel = true;
            new Thread(() -> {
                HttpURLConnection conn = null;
                File temp = new File(getFilesDir(), MODEL_NAME + ".download");
                String failure = null;
                try {
                    if (getFilesDir().getFreeSpace() < MODEL_SIZE + 250_000_000L) throw new Exception("Not enough free phone storage. Please free at least 850 MB and try again.");
                    URL url = new URL(MODEL_URL);
                    conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("GET");
                    conn.setConnectTimeout(25000);
                    conn.setReadTimeout(60000);
                    conn.setInstanceFollowRedirects(true);
                    conn.setRequestProperty("User-Agent", "JARVIS-Offline-Android/2.0");
                    int code = conn.getResponseCode();
                    if (code != HttpURLConnection.HTTP_OK) throw new Exception("Model download failed (HTTP " + code + "). Check the connection and retry.");
                    long total = 0;
                    byte[] buffer = new byte[64 * 1024];
                    try (InputStream in = conn.getInputStream(); FileOutputStream out = new FileOutputStream(temp, false)) {
                        int n;
                        while ((n = in.read(buffer)) != -1) {
                            out.write(buffer, 0, n);
                            total += n;
                            final int percent = (int)Math.min(99, (total * 100L) / MODEL_SIZE);
                            runOnUiThread(() -> { if (webView != null) webView.evaluateJavascript("window.modelDownloadProgress(" + percent + ")", null); });
                        }
                        out.getFD().sync();
                    }
                    if (total != MODEL_SIZE) throw new Exception("Downloaded file size did not match the official model file. Delete the partial download and retry.");
                    File target = modelFile();
                    if (target.exists() && !target.delete()) throw new Exception("Could not replace the old model file.");
                    if (!temp.renameTo(target)) throw new Exception("Could not save the model in app storage.");
                } catch (Exception e) {
                    failure = e.getMessage() == null ? "Download failed." : e.getMessage();
                    // Keep storage tidy after an incomplete or failed download.
                    // A completed model is only renamed into place after size validation.
                    //noinspection ResultOfMethodCallIgnored
                    temp.delete();
                } finally {
                    if (conn != null) conn.disconnect();
                    downloadingModel = false;
                }
                final String message = failure == null ? "Model downloaded successfully. Tap Load model; after it loads, you can switch off the internet." : failure;
                final boolean ok = failure == null;
                runOnUiThread(() -> {
                    if (webView != null) webView.evaluateJavascript("window.modelDownloadFinished(" + ok + "," + JSONObject.quote(message) + ")", null);
                });
            }, "jarvis-model-download").start();
        }
        @JavascriptInterface public void askAI(String prompt, String history, String requestId) {
            final String question = prompt == null ? "" : prompt;
            final String context = history == null ? "" : history;
            final String rid = requestId == null ? "" : requestId;
            if (offlineLlm == null || !offlineLlm.isReady()) {
                runOnUiThread(() -> webView.evaluateJavascript("window.aiResult(" + JSONObject.quote(rid) + "," + JSONObject.quote("Offline AI is not loaded. Open Menu → AI Settings and tap Load model. If the model is missing, download it first.") + ")", null));
                return;
            }
            offlineLlm.generate(question, context, answer -> runOnUiThread(() -> {
                if (webView != null) webView.evaluateJavascript("window.aiResult(" + JSONObject.quote(rid) + "," + JSONObject.quote(answer) + ")", null);
            }));
        }
    }

    private void startListening() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S || !SpeechRecognizer.isOnDeviceRecognitionAvailable(this)) {
            webView.evaluateJavascript("window.voiceError('Offline voice recognition is not installed on this device. You can type instead.')", null); return;
        }
        if (recognizer != null) recognizer.destroy();
        recognizer = SpeechRecognizer.createOnDeviceSpeechRecognizer(this);
        recognizer.setRecognitionListener(new RecognitionListener() {
            public void onReadyForSpeech(Bundle p) { }
            public void onBeginningOfSpeech() { }
            public void onRmsChanged(float r) { }
            public void onBufferReceived(byte[] b) { }
            public void onEndOfSpeech() { }
            public void onError(int e) { webView.evaluateJavascript("window.voiceError('Voice input failed. Try typing, or check whether offline speech is installed.')", null); }
            public void onResults(Bundle b) {
                ArrayList<String> r = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (r != null && !r.isEmpty()) webView.evaluateJavascript("window.voiceResult(" + JSONObject.quote(r.get(0)) + ")", null);
            }
            public void onPartialResults(Bundle b) { }
            public void onEvent(int t, Bundle p) { }
        });
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        intent.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true);
        recognizer.startListening(intent);
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == REQ_AUDIO && results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) startListening();
    }
    @Override public void onBackPressed() { if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }
    @Override protected void onDestroy() {
        if (recognizer != null) recognizer.destroy();
        if (tts != null) { tts.stop(); tts.shutdown(); }
        if (offlineLlm != null) offlineLlm.close();
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
