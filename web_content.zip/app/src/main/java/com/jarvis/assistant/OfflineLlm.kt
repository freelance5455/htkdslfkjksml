package com.jarvis.assistant

import android.content.Context
import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Contents
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import java.io.Closeable
import java.util.concurrent.Executors

/** Local-only language-model runner. All model inference runs on-device. */
class OfflineLlm(context: Context) : Closeable {
    interface StatusCallback { fun onStatus(ready: Boolean, message: String) }
    interface AnswerCallback { fun onAnswer(answer: String) }

    private val appContext = context.applicationContext
    private val executor = Executors.newSingleThreadExecutor()
    @Volatile private var engine: Engine? = null
    @Volatile private var ready = false
    @Volatile private var loading = false

    fun isReady(): Boolean = ready
    fun isLoading(): Boolean = loading

    fun load(modelPath: String, callback: StatusCallback) {
        executor.execute {
            if (ready && engine != null) {
                callback.onStatus(true, "Local AI model is ready.")
                return@execute
            }
            if (loading) {
                callback.onStatus(false, "The local AI model is already loading.")
                return@execute
            }
            loading = true
            var candidate: Engine? = null
            try {
                callback.onStatus(false, "Loading the AI model into memory. This may take a little while the first time.")
                candidate = Engine(
                    EngineConfig(
                        modelPath = modelPath,
                        backend = Backend.CPU(),
                        cacheDir = appContext.cacheDir.absolutePath
                    )
                )
                candidate.initialize()
                engine = candidate
                ready = true
                callback.onStatus(true, "Offline AI is ready. You can now turn off the internet.")
            } catch (e: Exception) {
                ready = false
                engine = null
                callback.onStatus(false, "Could not load the local model: ${e.message ?: "unknown model error"}")
            } finally {
                loading = false
            }
        }
    }

    fun generate(prompt: String, history: String, callback: AnswerCallback) {
        executor.execute {
            val activeEngine = engine
            if (!ready || activeEngine == null) {
                callback.onAnswer("JARVIS local AI is not loaded yet. Open Menu → AI Settings, download the model if needed, then tap Load model.")
                return@execute
            }
            var conversation: com.google.ai.edge.litertlm.Conversation? = null
            try {
                conversation = activeEngine.createConversation(
                    ConversationConfig(
                        systemInstruction = Contents.of(
                            "You are JARVIS, an offline AI assistant running entirely on the user's Android phone. " +
                            "Answer general questions helpfully and accurately. Support English and, when asked, Marathi and Hindi. " +
                            "Help with education, explanations, writing, mathematics, and programming including C, C++, C#, Python, Java, JavaScript, HTML, CSS, SQL, Kotlin, Swift, Go and Rust. " +
                            "For code, provide runnable examples and explain them simply. For cybersecurity, focus on legal defensive learning. " +
                            "Be honest about uncertainty. Do not claim you searched the internet. Keep the answer clear and useful."
                        ),
                        maxOutputToken = 1024
                    )
                )
                val fullPrompt = buildString {
                    if (history.isNotBlank()) append("Recent conversation:\n").append(history).append("\n\n")
                    append("Current user message:\n").append(prompt)
                }
                val result = conversation.sendMessage(fullPrompt).text.trim()
                callback.onAnswer(if (result.isBlank()) "The local model returned an empty answer. Please try asking in a different way." else result)
            } catch (e: Exception) {
                callback.onAnswer("The offline model could not answer this request: ${e.message ?: "unknown inference error"}")
            } finally {
                try { conversation?.close() } catch (_: Exception) { }
            }
        }
    }

    override fun close() {
        executor.execute {
            ready = false
            try { engine?.close() } catch (_: Exception) { }
            engine = null
            executor.shutdown()
        }
    }
}
