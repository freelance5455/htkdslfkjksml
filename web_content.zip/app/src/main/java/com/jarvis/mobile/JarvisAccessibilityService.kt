package com.jarvis.mobile

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

class JarvisAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    companion object {
        var instance: JarvisAccessibilityService? = null
            private set

        fun back() { instance?.performGlobalAction(GLOBAL_ACTION_BACK) }
        fun home() { instance?.performGlobalAction(GLOBAL_ACTION_HOME) }
        fun recents() { instance?.performGlobalAction(GLOBAL_ACTION_RECENTS) }
        fun notifications() { instance?.performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS) }
        fun quickSettings() { instance?.performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS) }
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }
}
