package com.jarvis.mobile

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.media.AudioManager
import android.os.Bundle
import android.provider.Settings
import android.speech.*
import android.view.View
import android.webkit.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private lateinit var audio: AudioManager
    private var recognizer: SpeechRecognizer? = null
    private var listening = false
    private var flashlight = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        audio = getSystemService(AUDIO_SERVICE) as AudioManager
        web = WebView(this)
        setContentView(web)

        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = false
        web.addJavascriptInterface(JarvisBridge(this), "AndroidJarvis")
        web.loadUrl("file:///android_asset/jarvis.html")

        requestAudioPermission()
    }

    private fun requestAudioPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 10)
        }
    }

    fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            speakToJs("Speech recognition is not available on this phone.")
            return
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            requestAudioPermission()
            return
        }

        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer!!.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { speakToJs("Listening for Hey Jarvis.") }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
            override fun onError(error: Int) {
                if (listening) startListening()
            }
            override fun onResults(results: Bundle?) {
                val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val heard = list?.firstOrNull() ?: ""
                if (heard.isNotBlank()) {
                    speakToJs("HEARD:" + heard.replace(""", "\""))
                    handleVoice(heard)
                }
                if (listening) startListening()
            }
        })

        listening = true
        startRecognizer()
    }

    private fun startRecognizer() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }
        recognizer?.startListening(i)
    }

    fun stopListening() {
        listening = false
        recognizer?.stopListening()
        recognizer?.destroy()
        recognizer = null
        speakToJs("Listening stopped.")
    }

    private fun handleVoice(raw: String) {
        val c = raw.lowercase(Locale.getDefault()).trim()
        val command = c.replaceFirst(Regex("^((hey|ok|okay)\\s+)?jarvis\\s*"), "").trim()

        when {
            command == "home" || command == "go home" -> JarvisAccessibilityService.home()
            command == "back" -> JarvisAccessibilityService.back()
            command == "recent apps" || command == "recents" -> JarvisAccessibilityService.recents()
            command.contains("notifications") -> JarvisAccessibilityService.notifications()
            command.contains("quick settings") -> JarvisAccessibilityService.quickSettings()

            command.contains("flashlight") || command.contains("torch") -> toggleFlashlight()
            command.contains("volume up") -> changeVolume(AudioManager.ADJUST_RAISE)
            command.contains("volume down") -> changeVolume(AudioManager.ADJUST_LOWER)
            command.contains("mute") -> audio.adjustVolume(AudioManager.ADJUST_MUTE, 0)

            command.startsWith("open ") -> {
                val app = command.removePrefix("open ").trim()
                openApp(app)
            }

            command.contains("settings") -> startActivity(Intent(Settings.ACTION_SETTINGS))
            command.contains("wifi") -> startActivity(Intent(Settings.ACTION_WIFI_SETTINGS))
            command.contains("bluetooth") -> startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
            command.contains("accessibility") -> startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            else -> speakToJs("AI:" + command.replace(""", "\""))
        }
    }

    private fun changeVolume(direction: Int) {
        audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, AudioManager.FLAG_SHOW_UI)
        speakToJs("Volume changed.")
    }

    private fun toggleFlashlight() {
        val camera = getSystemService(Context.CAMERA_SERVICE) as android.hardware.camera2.CameraManager
        val id = camera.cameraIdList.firstOrNull() ?: return
        flashlight = !flashlight
        try { camera.setTorchMode(id, flashlight); speakToJs(if (flashlight) "Flashlight on." else "Flashlight off.") }
        catch (_: Exception) { speakToJs("Flashlight control is unavailable.") }
    }

    private fun openApp(name: String) {
        val pm = packageManager
        val candidates = mapOf(
            "youtube" to "com.google.android.youtube",
            "chrome" to "com.android.chrome",
            "gmail" to "com.google.android.gm",
            "maps" to "com.google.android.apps.maps",
            "whatsapp" to "com.whatsapp",
            "instagram" to "com.instagram.android"
        )
        val pkg = candidates.entries.firstOrNull { name.contains(it.key) }?.value
        if (pkg != null) {
            val intent = pm.getLaunchIntentForPackage(pkg)
            if (intent != null) { startActivity(intent); return }
        }
        speakToJs("I couldn't find that app.")
    }

    fun speakToJs(text: String) {
        web.post {
            web.evaluateJavascript("window.jarvisNativeMessage(${JSONObjectQuote.quote(text)});", null)
        }
    }

    override fun onDestroy() {
        stopListening()
        super.onDestroy()
    }
}

object JSONObjectQuote {
    fun quote(s: String): String {
        return """ + s.replace("\", "\\").replace(""", "\"")
            .replace("
", "\n").replace("", "\r") + """
    }
}

class JarvisBridge(private val activity: MainActivity) {
    @android.webkit.JavascriptInterface
    fun startVoice() = activity.startListening()

    @android.webkit.JavascriptInterface
    fun stopVoice() = activity.stopListening()

    @android.webkit.JavascriptInterface
    fun openAccessibilitySettings() {
        activity.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
    }
}
