package com.smartstudyai.app;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.graphics.Color;

public class MainActivity extends Activity {
 @Override public void onCreate(Bundle b) {
  super.onCreate(b);
  getWindow().setStatusBarColor(Color.rgb(16,16,42));
  getWindow().setNavigationBarColor(Color.rgb(16,16,42));
  WebView w = new WebView(this);
  w.setBackgroundColor(Color.rgb(16,16,42));
  WebSettings s=w.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
  s.setAllowFileAccess(true); s.setAllowContentAccess(true);
  w.loadUrl("file:///android_asset/index.html"); setContentView(w);
 }
 @Override public void onBackPressed() { super.onBackPressed(); }
}
