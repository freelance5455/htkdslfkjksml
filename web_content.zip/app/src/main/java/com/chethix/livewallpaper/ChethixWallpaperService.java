package com.chethix.livewallpaper;

import android.media.MediaPlayer;
import android.service.wallpaper.WallpaperService;
import android.view.SurfaceHolder;

import java.io.File;

public class ChethixWallpaperService extends WallpaperService {

    @Override
    public Engine onCreateEngine() {
        return new VideoEngine();
    }

    private class VideoEngine extends Engine {
        private MediaPlayer mediaPlayer;
        private boolean visible;

        @Override
        public void onVisibilityChanged(boolean isVisible) {
            visible = isVisible;
            if (isVisible) {
                startVideo();
            } else {
                stopVideo();
            }
        }

        @Override
        public void onSurfaceCreated(SurfaceHolder holder) {
            super.onSurfaceCreated(holder);
            if (visible) startVideo();
        }

        @Override
        public void onSurfaceDestroyed(SurfaceHolder holder) {
            stopVideo();
            super.onSurfaceDestroyed(holder);
        }

        @Override
        public void onDestroy() {
            stopVideo();
            super.onDestroy();
        }

        private void startVideo() {
            stopVideo();

            File video = new File(getFilesDir(), "wallpaper.mp4");
            if (!video.exists()) return;

            try {
                mediaPlayer = new MediaPlayer();
                mediaPlayer.setDataSource(video.getAbsolutePath());
                mediaPlayer.setSurface(getSurfaceHolder().getSurface());
                mediaPlayer.setLooping(true);
                mediaPlayer.setVolume(0f, 0f);
                mediaPlayer.setOnPreparedListener(mp -> {
                    if (visible) mp.start();
                });
                mediaPlayer.prepareAsync();
            } catch (Exception e) {
                stopVideo();
            }
        }

        private void stopVideo() {
            if (mediaPlayer != null) {
                try {
                    if (mediaPlayer.isPlaying()) mediaPlayer.stop();
                } catch (Exception ignored) {}
                mediaPlayer.release();
                mediaPlayer = null;
            }
        }
    }
}
