package com.medicalstudyhub.app;

import android.app.Activity;
import android.os.Bundle;
import android.util.Base64;
import android.webkit.*;
import java.io.*;

public class MainActivity extends Activity {
    WebView webView;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        webView=new WebView(this); setContentView(webView);
        WebSettings s=webView.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true); s.setAllowContentAccess(true);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new Storage(), "AndroidStorage");
        webView.loadUrl("file:///android_asset/index.html");
    }
    class Storage {
        @JavascriptInterface public void savePdf(String subject,String name,String base64) {
            try {
                File dir=new File(getFilesDir(),"pdfs/"+safe(subject));
                if(!dir.exists()) dir.mkdirs();
                File out=new File(dir,System.currentTimeMillis()+"_"+safe(name));
                FileOutputStream f=new FileOutputStream(out);
                f.write(Base64.decode(base64,Base64.DEFAULT)); f.close();
                final String n=name.replace("\\","\\\\").replace("'","\\'");
                final String u=("file://"+out.getAbsolutePath()).replace("'","\\'");
                runOnUiThread(()->webView.evaluateJavascript("addPersistentPdf('"+n+"','"+u+"')",null));
            } catch(Exception ignored) {}
        }
    }
    String safe(String s){return s==null?"file":s.replaceAll("[^a-zA-Z0-9._-]","_");}
    @Override public void onBackPressed(){if(webView.canGoBack())webView.goBack();else super.onBackPressed();}
}