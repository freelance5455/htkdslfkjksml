package com.medicalstudyhub.app;

import android.app.Activity;
import android.os.Bundle;
import android.util.Base64;
import android.webkit.*;
import android.net.Uri;
import android.content.Intent;
import java.io.*;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        webView=new WebView(this);
        setContentView(webView);
        WebSettings s=webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback=callback;
                Intent intent=params.createIntent();
                try { startActivityForResult(intent, 1001); }
                catch(Exception e) { fileCallback=null; callback.onReceiveValue(null); }
                return true;
            }
        });
        webView.addJavascriptInterface(new Storage(), "AndroidStorage");
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==1001 && fileCallback!=null) {
            Uri[] result=null;
            if(resultCode==RESULT_OK && data!=null) {
                if(data.getClipData()!=null) {
                    int n=data.getClipData().getItemCount();
                    result=new Uri[n];
                    for(int i=0;i<n;i++) result[i]=data.getClipData().getItemAt(i).getUri();
                } else if(data.getData()!=null) result=new Uri[]{data.getData()};
            }
            fileCallback.onReceiveValue(result);
            fileCallback=null;
        }
    }

    class Storage {
        @JavascriptInterface public void savePdf(String subject,String name,String base64) {
            try {
                File dir=new File(getFilesDir(),"pdfs/"+safe(subject));
                if(!dir.exists()) dir.mkdirs();
                File out=new File(dir,System.currentTimeMillis()+"_"+safe(name));
                FileOutputStream f=new FileOutputStream(out);
                f.write(Base64.decode(base64,Base64.DEFAULT)); f.close();
                final String n=name.replace("\\","\\\\").replace("'","\\'");
                final String u=("file://"+out.getAbsolutePath()).replace("'","\\'");
                runOnUiThread(()->webView.evaluateJavascript("addPersistentPdf('"+n+"','"+u+"')",null));
            } catch(Exception ignored) {}
        }
    }
    String safe(String s){return s==null?"file":s.replaceAll("[^a-zA-Z0-9._-]","_");}
    @Override public void onBackPressed(){if(webView.canGoBack())webView.goBack();else super.onBackPressed();}
}
