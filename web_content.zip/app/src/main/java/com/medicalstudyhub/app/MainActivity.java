package com.medicalstudyhub.app;

import android.app.Activity;
import android.os.Bundle;
import android.util.Base64;
import android.webkit.*;
import android.net.Uri;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import java.io.*;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private static final int FILE_PICKER = 1001;
    private static final int STORAGE_PERMISSION = 1002;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        webView=new WebView(this);
        setContentView(webView);
        WebSettings s=webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;

                if (Build.VERSION.SDK_INT >= 33) {
                    boolean image = false;
                    String[] accepted = params.getAcceptTypes();
                    if (accepted != null) for (String t : accepted) {
                        if (t != null && t.toLowerCase().startsWith("image/")) image = true;
                    }
                    if (image && checkSelfPermission("android.permission.READ_MEDIA_IMAGES") != PackageManager.PERMISSION_GRANTED) {
                        requestPermissions(new String[]{"android.permission.READ_MEDIA_IMAGES"}, STORAGE_PERMISSION);
                    }
                } else if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission("android.permission.READ_EXTERNAL_STORAGE") != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{"android.permission.READ_EXTERNAL_STORAGE"}, STORAGE_PERMISSION);
                }

                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                String type = "*/*";
                String[] types = params.getAcceptTypes();
                if (types != null) for (String t : types) {
                    if (t != null && !t.trim().isEmpty()) { type = t; break; }
                }
                intent.setType(type);
                if (params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE) intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                try { startActivityForResult(intent, FILE_PICKER); }
                catch(Exception e) { fileCallback=null; callback.onReceiveValue(null); }
                return true;
            }
        });
        webView.addJavascriptInterface(new Storage(), "AndroidStorage");
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==FILE_PICKER && fileCallback!=null) {
            Uri[] result=null;
            if(resultCode==RESULT_OK && data!=null) {
                if(data.getData()!=null) {
                    try { getContentResolver().takePersistableUriPermission(data.getData(), Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch(Exception ignored) {}
                }
                if(data.getClipData()!=null) {
                    int n=data.getClipData().getItemCount();
                    result=new Uri[n];
                    for(int i=0;i<n;i++) result[i]=data.getClipData().getItemAt(i).getUri();
                } else if(data.getData()!=null) result=new Uri[]{data.getData()};
            }
            fileCallback.onReceiveValue(result);
            fileCallback=null;
        }
    }

    class Storage {
        @JavascriptInterface public void savePdf(String subject,String name,String base64) {
            try {
                File dir=new File(getFilesDir(),"pdfs/"+safe(subject));
                if(!dir.exists()) dir.mkdirs();
                File out=new File(dir,System.currentTimeMillis()+"_"+safe(name));
                FileOutputStream f=new FileOutputStream(out);
                f.write(Base64.decode(base64,Base64.DEFAULT)); f.close();
                final String n=name.replace("\\","\\\\").replace("'","\\'");
                final String u=("file://"+out.getAbsolutePath()).replace("'","\\'");
                runOnUiThread(()->webView.evaluateJavascript("addPersistentPdf('"+n+"','"+u+"')",null));
            } catch(Exception ignored) {}
        }
    }
    String safe(String s){return s==null?"file":s.replaceAll("[^a-zA-Z0-9._-]","_");}
    @Override public void onBackPressed(){if(webView.canGoBack())webView.goBack();else super.onBackPressed();}
}
