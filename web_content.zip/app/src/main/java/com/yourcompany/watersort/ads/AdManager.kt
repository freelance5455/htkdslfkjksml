package com.yourcompany.watersort.ads

import android.app.Activity
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import com.unity3d.ads.IUnityAdsInitializationListener
import com.unity3d.ads.IUnityAdsLoadListener
import com.unity3d.ads.IUnityAdsShowListener
import com.unity3d.ads.UnityAds
import com.unity3d.ads.UnityAdsShowOptions
import com.unity3d.services.banners.BannerErrorInfo
import com.unity3d.services.banners.BannerView
import com.unity3d.services.banners.UnityBannerSize

/** Unity Ads ONLY. Every method is a no-op when ADS_ENABLED = false. */
class AdManager(
    private val act: Activity,
    private val bannerHost: FrameLayout,
    private val sendToJs: (String) -> Unit
) {
    private val tag = "AdManager"
    private val ui = Handler(Looper.getMainLooper())
    val consent = ConsentManager(act)
    private var state = 0                    // 0 idle, 1 initialising, 2 ready (prevents double init)
    private var interReady = false; private var interLoading = false
    private var rewReady = false; private var rewLoading = false
    private var banner: BannerView? = null
    private var wantBanner = false

    fun start() {
        if (!AdsConfig.ADS_ENABLED || state != 0) return
        state = 1
        consent.ensure { initUnity() }
    }

    private fun initUnity() {
        consent.apply()                       // consent first, then init
        UnityAds.initialize(act.applicationContext, AdsConfig.GAME_ID, AdsConfig.TEST_MODE,
            object : IUnityAdsInitializationListener {
                override fun onInitializationComplete() { ui.post {
                    state = 2; loadInter(); loadReward(); if (wantBanner) showBanner() }
                }
                override fun onInitializationFailed(error: UnityAds.UnityAdsInitializationError?, message: String?) {
                    Log.w(tag, "init failed: $error $message")
                    ui.post { state = 0; ui.postDelayed({ start() }, AdsConfig.RETRY_LOAD_MS) }
                }
            })
    }

    fun isReady(type: String) = AdsConfig.ADS_ENABLED && state == 2 && when (type) {
        "interstitial" -> interReady
        "rewarded" -> rewReady
        else -> false
    }

    fun showBanner() = ui.post {
        if (!AdsConfig.ADS_ENABLED) return@post
        start()
        if (state != 2) { wantBanner = true; return@post }
        if (banner == null) {
            banner = BannerView(act, AdsConfig.BANNER_ID, UnityBannerSize(320, 50)).also { b ->
                b.setListener(object : BannerView.IListener {
                    override fun onBannerLoaded(v: BannerView?) {}
                    override fun onBannerShown(v: BannerView?) {}
                    override fun onBannerClick(v: BannerView?) {}
                    override fun onBannerLeftApplication(v: BannerView?) {}
                    override fun onBannerFailedToLoad(v: BannerView?, e: BannerErrorInfo?) {
                        Log.w(tag, "banner failed: ${e?.errorMessage}")
                        ui.postDelayed({ v?.load() }, AdsConfig.RETRY_LOAD_MS)
                    }
                })
                bannerHost.addView(b, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER_HORIZONTAL))
                b.load()
            }
        }
        banner?.visibility = View.VISIBLE
    }

    fun hideBanner() = ui.post { wantBanner = false; banner?.visibility = View.GONE }

    fun show(type: String, id: Int) = ui.post {
        val rewarded = type == "rewarded"
        val placement = if (rewarded) AdsConfig.REWARDED_ID else AdsConfig.INTERSTITIAL_ID
        if (!isReady(type)) { emit(id, "failed"); return@post }
        if (rewarded) rewReady = false else interReady = false
        UnityAds.show(act, placement, UnityAdsShowOptions(), object : IUnityAdsShowListener {
            override fun onUnityAdsShowFailure(p: String?, e: UnityAds.UnityAdsShowError?, m: String?) {
                Log.w(tag, "show failed: $e $m"); ui.post { reload(rewarded); emit(id, "failed") }
            }
            override fun onUnityAdsShowStart(p: String?) {}
            override fun onUnityAdsShowClick(p: String?) {}
            override fun onUnityAdsShowComplete(p: String?, s: UnityAds.UnityAdsShowCompletionState?) {
                // Reward ONLY when the ad was fully watched. SKIPPED or closed early = no reward.
                val ok = rewarded && s == UnityAds.UnityAdsShowCompletionState.COMPLETED
                ui.post { reload(rewarded); emit(id, if (ok) "rewarded" else "closed") }
            }
        })
    }

    private fun reload(rewarded: Boolean) = if (rewarded) loadReward() else loadInter()

    private fun loadInter() {
        if (state != 2 || interLoading || interReady) return   // never load the same placement twice
        interLoading = true
        UnityAds.load(AdsConfig.INTERSTITIAL_ID, object : IUnityAdsLoadListener {
            override fun onUnityAdsAdLoaded(p: String?) { ui.post { interLoading = false; interReady = true } }
            override fun onUnityAdsFailedToLoad(p: String?, e: UnityAds.UnityAdsLoadError?, m: String?) {
                Log.w(tag, "interstitial load: $e $m")
                ui.post { interLoading = false; ui.postDelayed({ loadInter() }, AdsConfig.RETRY_LOAD_MS) }
            }
        })
    }

    private fun loadReward() {
        if (state != 2 || rewLoading || rewReady) return
        rewLoading = true
        UnityAds.load(AdsConfig.REWARDED_ID, object : IUnityAdsLoadListener {
            override fun onUnityAdsAdLoaded(p: String?) { ui.post { rewLoading = false; rewReady = true } }
            override fun onUnityAdsFailedToLoad(p: String?, e: UnityAds.UnityAdsLoadError?, m: String?) {
                Log.w(tag, "rewarded load: $e $m")
                ui.post { rewLoading = false; ui.postDelayed({ loadReward() }, AdsConfig.RETRY_LOAD_MS) }
            }
        })
    }

    private fun emit(id: Int, r: String) = sendToJs("window.onAdEvent($id,'$r')")
    fun pause() {}
    fun resume() {}
    fun destroy() { banner?.destroy(); banner = null }
}
