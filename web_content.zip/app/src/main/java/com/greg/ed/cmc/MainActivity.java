package com.greg.ed.cmc;

import android.app.Activity;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.graphics.Color;
import android.provider.MediaStore;
import android.util.Base64;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.webkit.JavascriptInterface;
import android.webkit.JsResult;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.content.pm.ApplicationInfo;
import android.provider.Settings;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Locale;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

/**
 * CMC Moyennes : l'application web (assets/www) affichee dans une WebView.
 * Le pont "Android" permet d'enregistrer un fichier, de choisir un fichier et d'imprimer.
 */
public class MainActivity extends Activity {

    // Empreinte SHA-256 du certificat qui a servi a signer la version officielle de l'application.
    // Un outil comme Lucky Patcher modifie puis RE-SIGNE l'APK avec un autre certificat : la
    // verification ci-dessous echoue alors, et l'application affiche un ecran bloquant au lieu
    // de fonctionner normalement.
    private static final String EXPECTED_SIGNATURE =
            "35B536FDCBA71707DC483D2BEDC500D0901D6FA827246528802288D03C2786CC";

    private static final int REQ_FILE = 1002;
    private static final int REQ_STORAGE_PERM = 1003;

    // Applications de piratage/modification connues (Lucky Patcher et variantes). Leur presence
    // n'empeche pas forcement l'appli de fonctionner, mais elle rend la version Pro indisponible.
    private static final String[] PATCHER_PACKAGES = {
        "com.dimonvideo.luckypatcher", "com.chelpus.lackypatch", "com.forpda.lp",
        "com.android.vending.billing.InAppBillingService.LUCK",
        "com.android.vending.billing.InAppBillingService.LACK",
        "com.android.vending.billing.InAppBillingService.CLON",
        "cc.madkite.freedom", "org.creeplays.hack", "cn.maibaapp.lemonclover"
    };

    // Secret de la licence Pro, brouille (XOR) pour ne pas apparaitre en texte lisible si
    // quelqu'un ouvre le fichier .apk avec un outil comme "strings". Ce n'est pas un chiffrement
    // fort, mais combine a la verification de signature ci-dessus et a l'obscurcissement du code
    // (R8), cela decourage la grande majorite des outils de modification automatiques.
    private static final int[] LIC_XOR = {
        0x3E,0x5B,0x0C,0x71,0x26,0x4D,0x18,0x6F,0x3A,0x51,0x05,0x78,0x2D,0x40,0x13,0x6C,
        0x37,0x5E,0x08,0x75,0x22,0x49,0x1C,0x63,0x3E,0x51,0x05,0x78
    };
    private static String licenseSecret() {
        byte[] key = "CMC-Moyennes-Pro".getBytes(StandardCharsets.US_ASCII);
        byte[] out = new byte[LIC_XOR.length];
        for (int i = 0; i < out.length; i++) {
            out[i] = (byte) (LIC_XOR[i] ^ key[i % key.length]);
        }
        return new String(out, StandardCharsets.US_ASCII);
    }

    /** Code a 10 lettres/chiffres attendu pour une cle d'appareil donnee (HMAC-SHA256 tronque). */
    private static String expectedCodeFor(String deviceKey) {
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(licenseSecret().getBytes(StandardCharsets.US_ASCII), "HmacSHA256"));
            byte[] out = mac.doFinal(deviceKey.trim().toUpperCase(Locale.US).getBytes(StandardCharsets.US_ASCII));
            StringBuilder hex = new StringBuilder();
            for (byte b : out) {
                hex.append(String.format(Locale.US, "%02X", b));
            }
            String code = hex.toString().replaceAll("[^0-9A-F]", "").substring(0, 10);
            return code.substring(0, 5) + "-" + code.substring(5);
        } catch (Exception e) {
            return "";
        }
    }

    private WebView web;
    private WebView printView;                       // garde la page d'impression en vie
    private ValueCallback<Uri[]> fileCallback;

    // Fichier en attente d'enregistrement direct dans Téléchargements, le temps d'obtenir
    // (si besoin) l'autorisation de stockage sur les anciennes versions d'Android.
    private String pendingName;
    private byte[] pendingBytes;
    private String pendingMime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (!signatureIsValid()) {
            showTamperedScreen();
            return;
        }

        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);                // localStorage : les notes y sont enregistrees
        s.setAllowFileAccess(true);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setUserAgentString(s.getUserAgentString() + " CMCApk");

        web.addJavascriptInterface(new Bridge(), "Android");
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {

            @Override
            public boolean onJsConfirm(WebView view, String url, String message, final JsResult result) {
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setCancelable(false)
                        .setPositiveButton("Oui", (d, w) -> result.confirm())
                        .setNegativeButton("Non", (d, w) -> result.cancel())
                        .show();
                return true;
            }

            @Override
            public boolean onJsAlert(WebView view, String url, String message, final JsResult result) {
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setCancelable(false)
                        .setPositiveButton("OK", (d, w) -> result.confirm())
                        .show();
                return true;
            }

            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (fileCallback != null) {
                    fileCallback.onReceiveValue(null);
                }
                fileCallback = callback;
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                try {
                    startActivityForResult(Intent.createChooser(intent, "Choisir un fichier"), REQ_FILE);
                } catch (Exception e) {
                    fileCallback = null;
                    callback.onReceiveValue(null);
                    return false;
                }
                return true;
            }
        });

        web.loadUrl("file:///android_asset/www/index.html");
    }

    /** Fonctions appelables depuis la page : Android.saveText, Android.saveBase64, Android.printHtml,
      * Android.getDeviceKey, Android.checkLicense. */
    private class Bridge {

        @JavascriptInterface
        public String getDeviceKey() {
            return deviceKey();
        }

        @JavascriptInterface
        public boolean checkLicense(String code) {
            if (patcherDetected() || code == null) {
                return false;
            }
            String norm = code.trim().toUpperCase(Locale.US).replace(" ", "");
            String expected = expectedCodeFor(deviceKey());
            return !expected.isEmpty() && expected.equals(norm);
        }

        @JavascriptInterface
        public void saveText(final String name, final String text, final String mime) {
            runOnUiThread(() -> saveToDownloads(name, text == null ? new byte[0] : text.getBytes(StandardCharsets.UTF_8), mime));
        }

        @JavascriptInterface
        public void saveBase64(final String name, final String data, final String mime) {
            runOnUiThread(() -> {
                try {
                    saveToDownloads(name, Base64.decode(data, Base64.DEFAULT), mime);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Fichier illisible.", Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public void printHtml(final String html, final String jobName, final boolean landscape) {
            runOnUiThread(() -> doPrint(html, jobName, landscape));
        }
    }

    /**
     * Écrit directement le fichier dans le dossier Téléchargements de l'appareil : aucune
     * fenêtre de sélection, aucune imprimante. Sur Android 10 et plus, cela ne demande aucune
     * autorisation particulière. Sur les versions plus anciennes, une autorisation de stockage
     * est demandée une seule fois ; le fichier est réessayé automatiquement une fois accordée.
     */
    private void saveToDownloads(String name, byte[] bytes, String mime) {
        String safeMime = (mime == null || mime.isEmpty()) ? "application/octet-stream" : mime;

        if (Build.VERSION.SDK_INT < 29) {
            if (checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {
                pendingName = name;
                pendingBytes = bytes;
                pendingMime = safeMime;
                requestPermissions(new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_STORAGE_PERM);
                return;
            }
            try {
                File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                if (!dir.exists()) {
                    dir.mkdirs();
                }
                File out = new File(dir, name);
                try (FileOutputStream os = new FileOutputStream(out)) {
                    os.write(bytes);
                }
                MediaScannerConnection.scanFile(this, new String[]{out.getAbsolutePath()}, new String[]{safeMime}, null);
                Toast.makeText(this, "Enregistré dans Téléchargements : " + name, Toast.LENGTH_LONG).show();
            } catch (Exception e) {
                Toast.makeText(this, "Échec de l'enregistrement dans Téléchargements.", Toast.LENGTH_LONG).show();
            }
            return;
        }

        try {
            ContentValues values = new ContentValues();
            values.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
            values.put(MediaStore.MediaColumns.MIME_TYPE, safeMime);
            values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
            Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            if (uri == null) {
                throw new java.io.IOException("insertion refusée");
            }
            try (OutputStream os = getContentResolver().openOutputStream(uri)) {
                os.write(bytes);
            }
            Toast.makeText(this, "Enregistré dans Téléchargements : " + name, Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "Échec de l'enregistrement dans Téléchargements.", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_STORAGE_PERM) {
            boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            String name = pendingName;
            byte[] bytes = pendingBytes;
            String mime = pendingMime;
            pendingName = null;
            pendingBytes = null;
            pendingMime = null;
            if (granted && name != null && bytes != null) {
                saveToDownloads(name, bytes, mime);
            } else {
                Toast.makeText(this, "Autorisation refusée : impossible d'enregistrer dans Téléchargements.", Toast.LENGTH_LONG).show();
            }
        }
    }

    /** Identifiant court et stable de cet appareil, a communiquer pour obtenir un code Pro. */
    @SuppressWarnings("HardwareIds")
    private String deviceKey() {
        try {
            String id = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] h = md.digest((id == null ? "" : id).getBytes(StandardCharsets.US_ASCII));
            StringBuilder hex = new StringBuilder();
            for (byte b : h) {
                hex.append(String.format(Locale.US, "%02X", b));
            }
            String k = hex.toString().substring(0, 8);
            return k.substring(0, 4) + "-" + k.substring(4);
        } catch (Exception e) {
            return "0000-0000";
        }
    }

    /** Vrai si un outil de piratage/modification connu est installe sur l'appareil. */
    private boolean patcherDetected() {
        try {
            for (ApplicationInfo app : getPackageManager().getInstalledApplications(0)) {
                for (String pkg : PATCHER_PACKAGES) {
                    if (pkg.equalsIgnoreCase(app.packageName)) {
                        return true;
                    }
                }
            }
        } catch (Exception e) {
            // liste illisible : on ignore, ce controle n'est qu'une securite supplementaire.
        }
        return false;
    }

    /** Vrai seulement si l'APK installé porte le certificat officiel, inchangé depuis sa signature. */
    private boolean signatureIsValid() {
        try {
            Signature[] sigs;
            if (Build.VERSION.SDK_INT >= 28) {
                PackageInfo info = getPackageManager().getPackageInfo(getPackageName(), PackageManager.GET_SIGNING_CERTIFICATES);
                sigs = info.signingInfo.hasMultipleSigners()
                        ? info.signingInfo.getApkContentsSigners()
                        : info.signingInfo.getSigningCertificateHistory();
            } else {
                PackageInfo info = getPackageManager().getPackageInfo(getPackageName(), PackageManager.GET_SIGNATURES);
                sigs = info.signatures;
            }
            if (sigs == null || sigs.length != 1) {
                return false;
            }
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(sigs[0].toByteArray());
            StringBuilder hex = new StringBuilder();
            for (byte b : hash) {
                hex.append(String.format("%02X", b));
            }
            return EXPECTED_SIGNATURE.equals(hex.toString());
        } catch (Exception e) {
            return false;
        }
    }

    /** Affiche un ecran simple et bloquant : aucun contenu de l'application ne se charge. */
    private void showTamperedScreen() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(android.view.Gravity.CENTER);
        layout.setPadding(64, 64, 64, 64);
        layout.setBackgroundColor(Color.parseColor("#13231B"));

        TextView tv = new TextView(this);
        tv.setText("Application modifiee" + "\n\n"
                + "Cette copie de CMC Moyennes ne correspond pas a la version officielle et ne peut pas fonctionner." + "\n\n"
                + "Reinstallez l'application a partir du fichier APK fourni par Professeur Gregoire EDAH.");
        tv.setTextColor(Color.WHITE);
        tv.setTextSize(16);
        tv.setGravity(android.view.Gravity.CENTER);
        layout.addView(tv);

        setContentView(layout);
    }

    private void doPrint(String html, final String jobName, final boolean landscape) {
        final boolean[] started = {false};
        WebView w = new WebView(this);
        w.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                if (started[0]) {
                    return;
                }
                started[0] = true;
                PrintManager pm = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                if (pm == null) {
                    return;
                }
                PrintDocumentAdapter adapter = view.createPrintDocumentAdapter(jobName);
                PrintAttributes.MediaSize size = landscape
                        ? PrintAttributes.MediaSize.ISO_A4.asLandscape()
                        : PrintAttributes.MediaSize.ISO_A4.asPortrait();
                PrintAttributes attrs = new PrintAttributes.Builder()
                        .setMediaSize(size)
                        .setMinMargins(new PrintAttributes.Margins(591, 591, 591, 591))   // 1,5 cm de chaque cote
                        .build();
                pm.print(jobName, adapter, attrs);
            }
        });
        w.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null);
        printView = w;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQ_FILE) {
            if (fileCallback != null) {
                Uri[] result = null;
                if (resultCode == RESULT_OK) {
                    result = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
                }
                fileCallback.onReceiveValue(result);
                fileCallback = null;
            }
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        // Demande a la page d'enregistrer immediatement (au cas ou l'application est fermee).
        if (web != null) {
            web.evaluateJavascript("window.dispatchEvent(new Event('pagehide'))", null);
        }
    }

    @Override
    protected void onDestroy() {
        if (web != null) {
            web.destroy();
        }
        super.onDestroy();
    }
}
