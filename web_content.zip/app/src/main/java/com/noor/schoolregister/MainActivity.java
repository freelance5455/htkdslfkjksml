package com.noor.schoolregister;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ContentValues;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.KeyEvent;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

public class MainActivity extends Activity {

    private WebView web;
    private WebView printWeb;

    /* This script runs after the page loads.
       It makes the app save files through Android and print through Android. */
    private static final String SHIM =
        "(function(){" +
        "window.DL=function(b,n){var r=new FileReader();" +
        "r.onload=function(){ANDROIDAPP.saveFile(n,String(r.result));};" +
        "r.onerror=function(){ANDROIDAPP.toast('Could not read file');};" +
        "r.readAsDataURL(b);};" +
        "window.open=function(){var buf='';return{" +
        "document:{open:function(){buf='';},write:function(h){buf+=h;},close:function(){}}," +
        "focus:function(){},close:function(){}," +
        "print:function(){ANDROIDAPP.printHtml(buf);}};};" +
        "})();";

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        web = new WebView(this);
        setContentView(web);

        WebSettings st = web.getSettings();
        st.setJavaScriptEnabled(true);
        st.setDomStorageEnabled(true);
        st.setDatabaseEnabled(true);
        st.setAllowFileAccess(true);
        st.setAllowContentAccess(true);
        st.setUseWideViewPort(true);
        st.setLoadWithOverviewMode(true);
        st.setBuiltInZoomControls(false);

        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Bridge(), "ANDROIDAPP");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView v, String url) {
                v.evaluateJavascript(SHIM, null);
            }
        });

        web.loadUrl("file:///android_asset/index.html");
    }

    /* back button goes back inside the app first */
    @Override
    public boolean onKeyDown(int code, KeyEvent e) {
        if (code == KeyEvent.KEYCODE_BACK && web != null && web.canGoBack()) {
            web.goBack();
            return true;
        }
        return super.onKeyDown(code, e);
    }

    private class Bridge {

        @JavascriptInterface
        public void toast(final String msg) {
            runOnUiThread(new Runnable() {
                public void run() {
                    Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show();
                }
            });
        }

        /* dataUrl looks like data:application/pdf;base64,XXXX */
        @JavascriptInterface
        public void saveFile(final String name, final String dataUrl) {
            runOnUiThread(new Runnable() {
                public void run() {
                    try {
                        int cut = dataUrl.indexOf(",");
                        if (cut < 0) { toast("Save failed"); return; }
                        String head = dataUrl.substring(0, cut);
                        byte[] bytes = Base64.decode(dataUrl.substring(cut + 1), Base64.DEFAULT);
                        String mime = "application/octet-stream";
                        if (head.startsWith("data:") && head.contains(";")) {
                            mime = head.substring(5, head.indexOf(";"));
                        }
                        writeToDownloads(name, mime, bytes);
                        toast("Saved in Downloads: " + name);
                    } catch (Exception ex) {
                        toast("Save failed: " + ex.getMessage());
                    }
                }
            });
        }

        @JavascriptInterface
        public void printHtml(final String html) {
            runOnUiThread(new Runnable() {
                public void run() {
                    printWeb = new WebView(MainActivity.this);
                    printWeb.getSettings().setJavaScriptEnabled(false);
                    printWeb.setWebViewClient(new WebViewClient() {
                        @Override
                        public void onPageFinished(WebView v, String url) {
                            PrintManager pm = (PrintManager) getSystemService(PRINT_SERVICE);
                            if (pm == null) return;
                            pm.print("School Register",
                                     v.createPrintDocumentAdapter("School Register"),
                                     new PrintAttributes.Builder().build());
                            printWeb = null;
                        }
                    });
                    printWeb.loadDataWithBaseURL(null, html, "text/html", "utf-8", null);
                }
            });
        }
    }

    private void writeToDownloads(String name, String mime, byte[] bytes) throws Exception {
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues cv = new ContentValues();
            cv.put(MediaStore.Downloads.DISPLAY_NAME, name);
            cv.put(MediaStore.Downloads.MIME_TYPE, mime);
            cv.put(MediaStore.Downloads.IS_PENDING, 1);
            Uri uri = getContentResolver()
                    .insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
            if (uri == null) throw new Exception("no space");
            OutputStream os = getContentResolver().openOutputStream(uri);
            os.write(bytes);
            os.close();
            cv.clear();
            cv.put(MediaStore.Downloads.IS_PENDING, 0);
            getContentResolver().update(uri, cv, null, null);
        } else {
            File dir = Environment.getExternalStoragePublicDirectory(
                    Environment.DIRECTORY_DOWNLOADS);
            if (!dir.exists()) dir.mkdirs();
            FileOutputStream fo = new FileOutputStream(new File(dir, name));
            fo.write(bytes);
            fo.close();
        }
    }
}
