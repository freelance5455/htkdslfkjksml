package com.asd.videoplayer

import android.Manifest
import android.app.Activity
import android.content.ContentUris
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Build
import android.media.MediaScannerConnection
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import android.util.Size
import android.view.View
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

class MainActivity : Activity() {
    private lateinit var wv: WebView
    private val pool = Executors.newFixedThreadPool(2)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        wv = WebView(this)
        wv.setBackgroundColor(0xFF202125.toInt())
        setContentView(wv)
        with(wv.settings) {
            javaScriptEnabled = true; domStorageEnabled = true
            allowFileAccess = true; allowContentAccess = true
            mediaPlaybackRequiresUserGesture = false
        }
        wv.webChromeClient = WebChromeClient()
        wv.addJavascriptInterface(Bridge(), "Android")
        wv.loadUrl("file:///android_asset/index.html")
    }

    private fun has(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        wv.evaluateJavascript("onPerm()", null)
    }

    @Deprecated("back")
    override fun onBackPressed() {
        wv.evaluateJavascript("nativeBack()") { if (it != "true") finish() }
    }

    inner class Bridge {
        @JavascriptInterface fun perm(): String = when {
            Build.VERSION.SDK_INT >= 33 && has(Manifest.permission.READ_MEDIA_VIDEO) -> "full"
            Build.VERSION.SDK_INT >= 34 && has(Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED) -> "partial"
            Build.VERSION.SDK_INT < 33 && has(Manifest.permission.READ_EXTERNAL_STORAGE) -> "full"
            else -> "none"
        }

        @JavascriptInterface fun request() {
            runOnUiThread {
                val p = when {
                    Build.VERSION.SDK_INT >= 34 -> arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED)
                    Build.VERSION.SDK_INT >= 33 -> arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO)
                    else -> arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
                }
                requestPermissions(p, 1)
            }
        }

        @JavascriptInterface fun scan(): String {
            val arr = JSONArray()
            val uri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            val proj = arrayOf(MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME, MediaStore.Video.Media.SIZE, MediaStore.Video.Media.DURATION, MediaStore.Video.Media.BUCKET_DISPLAY_NAME, MediaStore.Video.Media.DATE_MODIFIED)
            contentResolver.query(uri, proj, null, null, MediaStore.Video.Media.DATE_ADDED + " DESC")?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getLong(0)
                    arr.put(JSONObject().apply {
                        put("id", id.toString()); put("name", c.getString(1) ?: "video")
                        put("size", c.getLong(2)); put("dur", c.getLong(3))
                        put("folder", c.getString(4) ?: "Movies"); put("date", c.getLong(5) * 1000)
                        put("src", ContentUris.withAppendedId(uri, id).toString())
                    })
                }
            }
            return arr.toString()
        }

        @JavascriptInterface fun thumb(id: String) {
            pool.execute {
                try {
                    val u = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id.toLong())
                    val bmp: Bitmap = if (Build.VERSION.SDK_INT >= 29) contentResolver.loadThumbnail(u, Size(320, 180), null)
                    else @Suppress("DEPRECATION") MediaStore.Video.Thumbnails.getThumbnail(contentResolver, id.toLong(), MediaStore.Video.Thumbnails.MINI_KIND, null)
                    val o = ByteArrayOutputStream(); bmp.compress(Bitmap.CompressFormat.JPEG, 75, o)
                    val d = "data:image/jpeg;base64," + Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP)
                    runOnUiThread { wv.evaluateJavascript("onThumb('$id','$d')", null) }
                } catch (e: Exception) {}
            }
        }

        @JavascriptInterface fun player(on: Boolean) {
            runOnUiThread {
                if (!on) requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                @Suppress("DEPRECATION")
                window.decorView.systemUiVisibility = if (on) (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE) else 0
                if (on) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
        }

        @JavascriptInterface fun orient(portrait: Boolean) {
            runOnUiThread {
                requestedOrientation = if (portrait) ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT else ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            }
        }

        @JavascriptInterface fun rescan() {
            pool.execute {
                val exts = setOf("mp4", "mkv", "avi", "mov", "webm", "3gp", "ts", "flv", "wmv", "m4v")
                val found = ArrayList<String>()
                fun walk(d: File, depth: Int) {
                    if (depth > 6 || found.size > 5000) return
                    d.listFiles()?.forEach { f ->
                        if (f.isDirectory) { if (!f.name.startsWith(".") && f.name != "Android") walk(f, depth + 1) }
                        else if (f.extension.lowercase() in exts) found.add(f.absolutePath)
                    }
                }
                try { walk(Environment.getExternalStorageDirectory(), 0) } catch (e: Exception) {}
                if (found.isEmpty()) { runOnUiThread { wv.evaluateJavascript("onScanDone()", null) }; return@execute }
                val n = AtomicInteger(found.size)
                MediaScannerConnection.scanFile(this@MainActivity, found.toTypedArray(), null) { _, _ ->
                    if (n.decrementAndGet() == 0) runOnUiThread { wv.evaluateJavascript("onScanDone()", null) }
                }
            }
        }
    }
}
