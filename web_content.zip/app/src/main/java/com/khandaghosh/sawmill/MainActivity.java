package com.khandaghosh.sawmill;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.ValueCallback;
import android.webkit.JavascriptInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import org.json.JSONObject;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import android.content.Intent;
import android.net.Uri;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private static final int FILE_CHOOSER_REQUEST = 1001;
    private final ExecutorService ocrExecutor = Executors.newSingleThreadExecutor();
    private TextRecognizer textRecognizer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(true);

        webView.setWebViewClient(new WebViewClient());
        textRecognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        webView.addJavascriptInterface(new OfflineOcrBridge(), "OfflineOCR");
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                    FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                try {
                    Intent intent = params.createIntent();
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                    return true;
                } catch (Exception e) {
                    fileCallback = null;
                    return false;
                }
            }
        });
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class OfflineOcrBridge {
        @JavascriptInterface
        public void scanImage(String dataUrl) {
            ocrExecutor.execute(() -> {
                try {
                    String encoded = dataUrl.substring(dataUrl.indexOf(',') + 1);
                    byte[] bytes = Base64.decode(encoded, Base64.DEFAULT);
                    BitmapFactory.Options bounds = new BitmapFactory.Options();
                    bounds.inJustDecodeBounds = true;
                    BitmapFactory.decodeByteArray(bytes, 0, bytes.length, bounds);
                    int sample = 1;
                    while (bounds.outWidth / sample > 2200 || bounds.outHeight / sample > 3000) sample *= 2;
                    BitmapFactory.Options opts = new BitmapFactory.Options();
                    opts.inSampleSize = sample;
                    Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length, opts);
                    if (bitmap == null) throw new IllegalArgumentException("Could not open this image.");
                    InputImage image = InputImage.fromBitmap(bitmap, 0);
                    textRecognizer.process(image)
                        .addOnSuccessListener(text -> {
                            bitmap.recycle();
                            sendOcrResult(text.getText());
                        })
                        .addOnFailureListener(error -> {
                            bitmap.recycle();
                            sendOcrResult("__OCR_ERROR__" + (error.getMessage() == null ? "Could not read photo" : error.getMessage()));
                        });
                } catch (Exception e) {
                    sendOcrResult("__OCR_ERROR__" + (e.getMessage() == null ? "Could not read photo" : e.getMessage()));
                }
            });
        }
    }

    private void sendOcrResult(String resultText) {
        final String safeText = resultText;
        runOnUiThread(() -> {
            if (webView != null) webView.evaluateJavascript(
                "window.onOfflineOcrResult && window.onOfflineOcrResult(" + JSONObject.quote(safeText) + ")", null);
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST && fileCallback != null) {
            Uri[] result = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            fileCallback.onReceiveValue(result);
            fileCallback = null;
        }
    }

    @Override
    protected void onDestroy() {
        if (textRecognizer != null) textRecognizer.close();
        ocrExecutor.shutdown();
        if (webView != null) webView.destroy();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
