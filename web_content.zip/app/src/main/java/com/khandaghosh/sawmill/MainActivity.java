package com.khandaghosh.sawmill;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.ValueCallback;
import android.webkit.JavascriptInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import androidx.exifinterface.media.ExifInterface;
import java.io.ByteArrayInputStream;
import android.util.Base64;
import org.json.JSONObject;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import android.content.Intent;
import android.net.Uri;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private static final int FILE_CHOOSER_REQUEST = 1001;
    private final ExecutorService ocrExecutor = Executors.newSingleThreadExecutor();
    private TextRecognizer textRecognizer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(true);

        webView.setWebViewClient(new WebViewClient());
        textRecognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        webView.addJavascriptInterface(new OfflineOcrBridge(), "OfflineOCR");
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                    FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                try {
                    Intent intent = params.createIntent();
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                    return true;
                } catch (Exception e) {
                    fileCallback = null;
                    return false;
                }
            }
        });
        webView.loadUrl("file:///android_asset/index.html");
    }

    public final class OfflineOcrBridge {
        @JavascriptInterface
        public void scanImage(String dataUrl) {
            if (dataUrl == null || !dataUrl.startsWith("data:image/")) {
                sendOcrResult("__OCR_ERROR__Invalid image data. Please choose the photo again.");
                return;
            }
            try {
                ocrExecutor.execute(() -> {
                try {
                    String encoded = dataUrl.substring(dataUrl.indexOf(',') + 1);
                    byte[] bytes = Base64.decode(encoded, Base64.DEFAULT);
                    BitmapFactory.Options bounds = new BitmapFactory.Options();
                    bounds.inJustDecodeBounds = true;
                    BitmapFactory.decodeByteArray(bytes, 0, bytes.length, bounds);
                    int sample = 1;
                    while (bounds.outWidth / sample > 2200 || bounds.outHeight / sample > 3000) sample *= 2;
                    BitmapFactory.Options opts = new BitmapFactory.Options();
                    opts.inSampleSize = sample;
                    Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length, opts);
                    if (bitmap == null) throw new IllegalArgumentException("Could not open this image.");
                    // Respect phone-camera EXIF orientation so portrait photos are read upright.
                    ExifInterface exif = new ExifInterface(new ByteArrayInputStream(bytes));
                    int orientation = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
                    Matrix matrix = new Matrix();
                    if (orientation == ExifInterface.ORIENTATION_ROTATE_90) matrix.postRotate(90);
                    else if (orientation == ExifInterface.ORIENTATION_ROTATE_180) matrix.postRotate(180);
                    else if (orientation == ExifInterface.ORIENTATION_ROTATE_270) matrix.postRotate(270);
                    else if (orientation == ExifInterface.ORIENTATION_FLIP_HORIZONTAL) matrix.postScale(-1, 1);
                    else if (orientation == ExifInterface.ORIENTATION_FLIP_VERTICAL) matrix.postScale(1, -1);
                    if (!matrix.isIdentity()) {
                        Bitmap upright = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
                        if (upright != bitmap) { bitmap.recycle(); bitmap = upright; }
                    }
                    final Bitmap processedBitmap = bitmap;
                    InputImage image = InputImage.fromBitmap(processedBitmap, 0);
                    textRecognizer.process(image)
                        .addOnSuccessListener(text -> {
                            processedBitmap.recycle();
                            sendOcrResult(text.getText());
                        })
                        .addOnFailureListener(error -> {
                            processedBitmap.recycle();
                            sendOcrResult("__OCR_ERROR__" + (error.getMessage() == null ? "Could not read photo" : error.getMessage()));
                        });
                } catch (Exception e) {
                    sendOcrResult("__OCR_ERROR__" + (e.getMessage() == null ? "Could not read photo" : e.getMessage()));
                }
                });
            } catch (Exception e) {
                sendOcrResult("__OCR_ERROR__Scanner could not start: " +
                    (e.getMessage() == null ? "Please reopen the app and try again." : e.getMessage()));
            }
        }
    }

    private void sendOcrResult(String resultText) {
        final String safeText = resultText;
        runOnUiThread(() -> {
            if (webView != null) webView.evaluateJavascript(
                "window.onOfflineOcrResult && window.onOfflineOcrResult(" + JSONObject.quote(safeText) + ")", null);
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST && fileCallback != null) {
            Uri[] result = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            fileCallback.onReceiveValue(result);
            fileCallback = null;
        }
    }

    @Override
    protected void onDestroy() {
        if (textRecognizer != null) textRecognizer.close();
        ocrExecutor.shutdown();
        if (webView != null) webView.destroy();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
