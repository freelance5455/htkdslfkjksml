package com.darkos.launcher

import android.app.Activity
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.*
import android.text.Editable
import android.text.TextWatcher
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val bg = Color.rgb(8, 9, 14)
    private val panel = Color.argb(150, 30, 32, 42)
    private val line = Color.argb(60, 255, 255, 255)
    private val white = Color.rgb(245, 246, 250)
    private val muted = Color.rgb(155, 160, 177)
    private lateinit var root: LinearLayout
    private lateinit var appGrid: GridLayout
    private lateinit var search: EditText
    private lateinit var allApps: List<AppEntry>
    private var showDrawer = false

    data class AppEntry(val label: String, val packageName: String, val icon: android.graphics.drawable.Drawable)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(8, 9, 14)
        window.navigationBarColor = Color.rgb(8, 9, 14)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING)
        allApps = loadApps()
        renderHome()
    }

    private fun loadApps(): List<AppEntry> {
        val intent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(intent, 0)
            .mapNotNull {
                val info = it.activityInfo ?: return@mapNotNull null
                AppEntry(it.loadLabel(packageManager).toString(), info.packageName, it.loadIcon(packageManager))
            }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase(Locale.getDefault()) }
    }

    private fun rounded(color: Int, radius: Float, stroke: Int = line): GradientDrawable {
        return GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius
            setStroke(dp(1), stroke)
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun text(value: String, size: Float, color: Int = white, bold: Boolean = false): TextView {
        return TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER_VERTICAL
            includeFontPadding = false
        }
    }

    private fun pad(view: View, l: Int, t: Int, r: Int, b: Int) {
        view.setPadding(dp(l), dp(t), dp(r), dp(b))
    }

    private fun renderHome() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            pad(this, 20, 16, 20, 14)
        }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        brand.addView(text("D A R K   O S", 12f, muted, true))
        val clock = text(SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()), 38f, white, true)
        brand.addView(clock)
        brand.addView(text(SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date()).replaceFirstChar { it.uppercase() }, 13f, muted))
        top.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        val settings = text("⚙", 25f, white).apply {
            gravity = Gravity.CENTER
            background = rounded(panel, dp(20).toFloat())
            setOnClickListener { showSettings() }
        }
        top.addView(settings, LinearLayout.LayoutParams(dp(48), dp(48)))
        root.addView(top)

        val spacer = View(this)
        root.addView(spacer, LinearLayout.LayoutParams(1, dp(22)))

        val widget = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Color.argb(155, 34, 36, 48), dp(26).toFloat(), Color.argb(90, 255, 255, 255))
            pad(this, 18, 16, 18, 16)
        }
        widget.addView(text("LIQUID GLASS  /  HOME", 10f, muted, true))
        val greeting = text("Your space. Your rules.", 22f, white, true)
        widget.addView(greeting)
        val sub = text("Long press an icon in the app drawer to pin it here.", 12f, muted)
        val subParams = LinearLayout.LayoutParams(-1, -2)
        subParams.topMargin = dp(8)
        widget.addView(sub, subParams)
        root.addView(widget)

        val quickTitle = text("FAVOURITES", 11f, muted, true)
        val titleParams = LinearLayout.LayoutParams(-1, dp(32))
        titleParams.topMargin = dp(14)
        root.addView(quickTitle, titleParams)
        val favourites = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        val picks = listOf("Telegram", "Chrome", "Camera", "Settings")
        picks.forEach { label ->
            val entry = allApps.firstOrNull { it.label.equals(label, true) ||
                (label == "Settings" && it.packageName == "com.android.settings") }
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                background = rounded(Color.argb(105, 35, 37, 49), dp(22).toFloat())
                pad(this, 4, 10, 4, 10)
                setOnClickListener { entry?.let { launch(it) } ?: showDrawer() }
            }
            val icon = ImageView(this).apply {
                if (entry != null) setImageDrawable(entry.icon) else setImageResource(android.R.drawable.sym_def_app_icon)
                scaleType = ImageView.ScaleType.FIT_CENTER
            }
            item.addView(icon, LinearLayout.LayoutParams(dp(32), dp(32)))
            val labelView = text(label, 10f, muted).apply { gravity = Gravity.CENTER }
            val lp = LinearLayout.LayoutParams(-1, dp(20)); lp.topMargin = dp(4)
            item.addView(labelView, lp)
            val params = LinearLayout.LayoutParams(0, dp(78), 1f)
            params.marginEnd = dp(7)
            favourites.addView(item, params)
        }
        root.addView(favourites)

        val bottomSpacer = View(this)
        root.addView(bottomSpacer, LinearLayout.LayoutParams(1, 0, 1f))
        val dock = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = rounded(Color.argb(155, 28, 30, 40), dp(28).toFloat(), Color.argb(80, 255, 255, 255))
            pad(this, 8, 8, 8, 8)
        }
        val appsBtn = text("⌕   Apps", 15f, white, true).apply {
            gravity = Gravity.CENTER
            setOnClickListener { showDrawer() }
        }
        dock.addView(appsBtn, LinearLayout.LayoutParams(0, dp(48), 1f))
        val wallpaperBtn = text("◐", 21f, white).apply {
            gravity = Gravity.CENTER
            setOnClickListener {
                try {
                    startActivity(Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER))
                } catch (_: Exception) {
                    try { startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER)) } catch (_: Exception) {}
                }
            }
        }
        dock.addView(wallpaperBtn, LinearLayout.LayoutParams(dp(52), dp(48)))
        val settingsBtn = text("⚙", 20f, white).apply {
            gravity = Gravity.CENTER
            setOnClickListener { showSettings() }
        }
        dock.addView(settingsBtn, LinearLayout.LayoutParams(dp(52), dp(48)))
        root.addView(dock)
        setContentView(root)

        clock.postDelayed(object : Runnable {
            override fun run() {
                if (isFinishing) return
                clock.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
                clock.postDelayed(this, 30_000)
            }
        }, 30_000)
    }

    private fun showDrawer() {
        showDrawer = true
        val screen = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            pad(this, 18, 14, 18, 12)
        }
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val back = text("‹", 34f, white).apply {
            gravity = Gravity.CENTER
            setOnClickListener { showDrawer = false; renderHome() }
        }
        head.addView(back, LinearLayout.LayoutParams(dp(42), dp(46)))
        head.addView(text("Applications", 24f, white, true), LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(text("${allApps.size}", 13f, muted))
        screen.addView(head)
        search = EditText(this).apply {
            hint = "Search apps"
            setHintTextColor(muted)
            setTextColor(white)
            textSize = 15f
            singleLine = true
            background = rounded(panel, dp(18).toFloat())
            pad(this, 14, 0, 14, 0)
        }
        val searchParams = LinearLayout.LayoutParams(-1, dp(48)); searchParams.topMargin = dp(10)
        screen.addView(search, searchParams)
        val scroll = ScrollView(this)
        appGrid = GridLayout(this).apply { columnCount = 4; alignmentMode = GridLayout.ALIGN_BOUNDS }
        scroll.addView(appGrid)
        val scrollParams = LinearLayout.LayoutParams(-1, 0, 1f); scrollParams.topMargin = dp(12)
        screen.addView(scroll, scrollParams)
        setContentView(screen)
        renderApps("")
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { renderApps(s?.toString() ?: "") }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    private fun renderApps(filter: String) {
        appGrid.removeAllViews()
        val matches = allApps.filter { it.label.contains(filter, true) }.take(300)
        matches.forEach { entry ->
            val tile = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                pad(this, 2, 8, 2, 8)
                setOnClickListener { launch(entry) }
                setOnLongClickListener {
                    Toast.makeText(this@MainActivity, "${entry.label}: pinning is coming in a later build", Toast.LENGTH_SHORT).show()
                    true
                }
            }
            val icon = ImageView(this).apply { setImageDrawable(entry.icon); scaleType = ImageView.ScaleType.FIT_CENTER }
            tile.addView(icon, LinearLayout.LayoutParams(dp(42), dp(42)))
            val name = text(entry.label, 10.5f, white).apply { gravity = Gravity.CENTER; maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END }
            val lp = LinearLayout.LayoutParams(-1, dp(34)); lp.topMargin = dp(5)
            tile.addView(name, lp)
            val p = GridLayout.LayoutParams()
            p.width = 0
            p.height = dp(92)
            p.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
            appGrid.addView(tile, p)
        }
        if (matches.isEmpty()) {
            val empty = text("No apps found", 14f, muted)
            appGrid.addView(empty)
        }
    }

    private fun launch(entry: AppEntry) {
        val launchIntent = packageManager.getLaunchIntentForPackage(entry.packageName)
        if (launchIntent != null) {
            try { startActivity(launchIntent) } catch (_: Exception) {
                Toast.makeText(this, "Could not open ${entry.label}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun showSettings() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            pad(this, 20, 18, 20, 18)
        }
        val back = text("‹   DARK OS Settings", 23f, white, true).apply {
            setOnClickListener { renderHome() }
        }
        box.addView(back, LinearLayout.LayoutParams(-1, dp(54)))
        box.addView(text("APPEARANCE", 11f, muted, true))
        val info = text("Liquid Glass panels are enabled. This build uses translucent surfaces, fine borders and soft rounded corners.", 15f, white)
        info.background = rounded(panel, dp(22).toFloat())
        pad(info, 16, 16, 16, 16)
        val p = LinearLayout.LayoutParams(-1, -2); p.topMargin = dp(10); p.bottomMargin = dp(18)
        box.addView(info, p)
        val button = text("Open Android wallpaper settings  ↗", 15f, white, true).apply {
            background = rounded(panel, dp(18).toFloat())
            pad(this, 16, 15, 16, 15)
            setOnClickListener {
                try { startActivity(Intent(Intent.ACTION_SET_WALLPAPER)) } catch (_: Exception) {}
            }
        }
        box.addView(button)
        val about = text("DARK OS  •  Prototype 0.1.0\nNative Android launcher foundation. More customization and icon packs planned.", 12f, muted)
        val ap = LinearLayout.LayoutParams(-1, -2); ap.topMargin = dp(20)
        box.addView(about, ap)
        setContentView(box)
    }
}
