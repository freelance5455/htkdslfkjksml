package com.basra.game;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONArray;

import java.io.OutputStream;

public class MainActivity extends Activity {

    static final int REQ_FILE = 11;
    static final int REQ_BT = 12;

    private WebView web;
    private ValueCallback<Uri[]> fileCb;
    private Uri camUri;
    private BtBridge bt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        web = new WebView(this);
        web.setBackgroundColor(0xFF042A19);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);

        bt = new BtBridge(this, web);
        web.addJavascriptInterface(new Bridge(), "Android");
        web.addJavascriptInterface(bt, "AndroidBT");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if ("file".equals(u.getScheme())) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (Exception ignored) {
                }
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                camUri = null;
                try {
                    Intent i;
                    if (params.isCaptureEnabled()) {
                        ContentValues v = new ContentValues();
                        v.put(MediaStore.Images.Media.DISPLAY_NAME, "basra_" + System.currentTimeMillis() + ".jpg");
                        v.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
                        camUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
                        i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                        i.putExtra(MediaStore.EXTRA_OUTPUT, camUri);
                        i.putExtra("android.intent.extras.CAMERA_FACING", 1);
                    } else {
                        i = params.createIntent();
                    }
                    startActivityForResult(i, REQ_FILE);
                } catch (Exception e) {
                    fileCb.onReceiveValue(null);
                    fileCb = null;
                    return false;
                }
                return true;
            }
        });

        web.loadUrl("file:///android_asset/www/index.html");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_FILE || fileCb == null) return;
        Uri[] res = null;
        if (resultCode == RESULT_OK) {
            if (camUri != null && (data == null || data.getData() == null)) {
                res = new Uri[]{camUri};
            } else {
                res = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            }
        } else if (camUri != null) {
            try {
                getContentResolver().delete(camUri, null, null);
            } catch (Exception ignored) {
            }
        }
        fileCb.onReceiveValue(res);
        fileCb = null;
        camUri = null;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    /** زر الرجوع في الجوال: اللعبة تقرر (تغلق نافذة / تسأل قبل الخروج / ضغطتين للخروج). */
    @Override
    public void onBackPressed() {
        web.evaluateJavascript(
                "(function(){try{return window.__appBack?window.__appBack():false}catch(e){return false}})()",
                new ValueCallback<String>() {
                    @Override
                    public void onReceiveValue(String v) {
                        if (!"true".equals(v)) finish();
                    }
                });
    }

    @Override
    protected void onDestroy() {
        if (bt != null) bt.close();
        if (web != null) web.destroy();
        super.onDestroy();
    }

    // ===== جسر بين اللعبة (جافاسكربت) والنظام =====
    class Bridge {
        @JavascriptInterface
        public void exit() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    finish();
                }
            });
        }

        @JavascriptInterface
        public void vibrate(String json) {
            try {
                JSONArray a = new JSONArray(json);
                long[] p = new long[a.length() + 1];
                p[0] = 0;
                for (int i = 0; i < a.length(); i++) p[i + 1] = a.optLong(i);
                Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                if (v != null && v.hasVibrator()) v.vibrate(VibrationEffect.createWaveform(p, -1));
            } catch (Exception ignored) {
            }
        }

        @JavascriptInterface
        public void saveImage(String dataUrl) {
            Uri u = store(dataUrl);
            toast(u != null ? "تم حفظ الصورة في المعرض ✅" : "تعذّر حفظ الصورة");
        }

        @JavascriptInterface
        public void shareImage(String dataUrl) {
            final Uri u = store(dataUrl);
            if (u == null) {
                toast("تعذّرت المشاركة");
                return;
            }
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Intent send = new Intent(Intent.ACTION_SEND);
                        send.setType("image/png");
                        send.putExtra(Intent.EXTRA_STREAM, u);
                        send.putExtra(Intent.EXTRA_TEXT, "العب معي لعبة الباصرة 🃏");
                        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        startActivity(Intent.createChooser(send, "مشاركة"));
                    } catch (ActivityNotFoundException ignored) {
                    }
                }
            });
        }
    }

    private void toast(final String t) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(MainActivity.this, t, Toast.LENGTH_SHORT).show();
            }
        });
    }

    /** يحفظ صورة (data:image/png;base64,...) في معرض الصور ويرجع رابطها. */
    private Uri store(String dataUrl) {
        try {
            int c = dataUrl.indexOf(',');
            byte[] bytes = Base64.decode(dataUrl.substring(c + 1), Base64.DEFAULT);
            ContentValues v = new ContentValues();
            v.put(MediaStore.Images.Media.DISPLAY_NAME, "basra_" + System.currentTimeMillis() + ".png");
            v.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
            v.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Basra");
            Uri u = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
            if (u == null) return null;
            OutputStream os = getContentResolver().openOutputStream(u);
            if (os == null) return null;
            os.write(bytes);
            os.close();
            return u;
        } catch (Exception e) {
            return null;
        }
    }
}
