package com.basra.game;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * بلوتوث كلاسيكي (RFCOMM) بين جوالين مقترنين.
 * اللعبة تتعامل معه عبر نفس أسماء الإضافة: init / listen / paired / connect / send.
 * كل رسالة تُرسل بطول (4 بايت) ثم النص.
 */
public class BtBridge {

    private static final UUID APP_UUID = UUID.fromString("8e4b1c52-5a6d-4f3e-9d0a-2b7c1f6e9a10");

    private static class Conn {
        BluetoothSocket socket;
        DataOutputStream out;
    }

    private final Activity act;
    private final WebView web;
    private final Map<Integer, Conn> conns = new ConcurrentHashMap<Integer, Conn>();
    private int nextId = 1;
    private BluetoothAdapter adapter;
    private BluetoothServerSocket server;
    private volatile boolean listening = false;

    public BtBridge(Activity act, WebView web) {
        this.act = act;
        this.web = web;
    }

    @JavascriptInterface
    public void call(final String method, final String args, final int cid) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    handle(method, new JSONObject(args), cid);
                } catch (Exception e) {
                    reject(cid, e.getMessage() == null ? "خطأ" : e.getMessage());
                }
            }
        }).start();
    }

    private void handle(String method, JSONObject a, int cid) throws Exception {
        if ("init".equals(method)) {
            ensurePermission();
            resolve(cid, "{}");
        } else if ("listen".equals(method)) {
            ensureReady();
            startServer();
            resolve(cid, "{}");
        } else if ("paired".equals(method)) {
            ensureReady();
            JSONArray list = new JSONArray();
            Set<BluetoothDevice> bonded = adapter.getBondedDevices();
            for (BluetoothDevice d : bonded) {
                JSONObject o = new JSONObject();
                o.put("name", d.getName() == null ? d.getAddress() : d.getName());
                o.put("address", d.getAddress());
                list.put(o);
            }
            JSONObject res = new JSONObject();
            res.put("devices", list);
            resolve(cid, res.toString());
        } else if ("connect".equals(method)) {
            ensureReady();
            BluetoothDevice d = adapter.getRemoteDevice(a.getString("address"));
            adapter.cancelDiscovery();
            BluetoothSocket s = d.createRfcommSocketToServiceRecord(APP_UUID);
            s.connect();
            int id = register(s);
            JSONObject res = new JSONObject();
            res.put("id", id);
            resolve(cid, res.toString());
        } else if ("send".equals(method)) {
            Conn c = conns.get(a.getInt("id"));
            if (c == null) throw new IOException("الاتصال مغلق");
            byte[] b = a.getString("data").getBytes(StandardCharsets.UTF_8);
            synchronized (c.out) {
                c.out.writeInt(b.length);
                c.out.write(b);
                c.out.flush();
            }
            resolve(cid, "{}");
        } else {
            throw new IllegalArgumentException("أمر غير معروف");
        }
    }

    private boolean hasPermission() {
        return Build.VERSION.SDK_INT < 31
                || act.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
    }

    private void ensurePermission() throws Exception {
        if (hasPermission()) return;
        act.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                act.requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT}, MainActivity.REQ_BT);
            }
        });
        for (int i = 0; i < 100 && !hasPermission(); i++) Thread.sleep(300);
        if (!hasPermission()) throw new SecurityException("لازم تسمح للتطبيق بصلاحية البلوتوث");
    }

    private void ensureReady() throws Exception {
        ensurePermission();
        BluetoothManager bm = (BluetoothManager) act.getSystemService(Context.BLUETOOTH_SERVICE);
        adapter = bm == null ? null : bm.getAdapter();
        if (adapter == null) throw new IllegalStateException("هذا الجهاز ما يدعم البلوتوث");
        if (!adapter.isEnabled()) throw new IllegalStateException("شغّل البلوتوث أولًا");
    }

    private synchronized void startServer() throws IOException {
        if (listening) return;
        server = adapter.listenUsingRfcommWithServiceRecord("Basra", APP_UUID);
        listening = true;
        new Thread(new Runnable() {
            @Override
            public void run() {
                while (listening) {
                    try {
                        BluetoothSocket s = server.accept();
                        int id = register(s);
                        JSONObject o = new JSONObject();
                        String name = s.getRemoteDevice().getName();
                        o.put("id", id);
                        o.put("name", name == null ? "" : name);
                        emit("connected", o);
                    } catch (Exception e) {
                        break;
                    }
                }
                listening = false;
            }
        }).start();
    }

    private int register(final BluetoothSocket s) throws IOException {
        final int id;
        synchronized (this) {
            id = nextId++;
        }
        final Conn c = new Conn();
        c.socket = s;
        c.out = new DataOutputStream(s.getOutputStream());
        conns.put(id, c);
        final DataInputStream in = new DataInputStream(s.getInputStream());
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    while (true) {
                        int len = in.readInt();
                        if (len < 0 || len > 5000000) break;
                        byte[] b = new byte[len];
                        in.readFully(b);
                        JSONObject o = new JSONObject();
                        o.put("id", id);
                        o.put("data", new String(b, StandardCharsets.UTF_8));
                        emit("data", o);
                    }
                } catch (Exception ignored) {
                }
                conns.remove(id);
                try {
                    s.close();
                } catch (IOException ignored) {
                }
                try {
                    JSONObject o = new JSONObject();
                    o.put("id", id);
                    emit("closed", o);
                } catch (Exception ignored) {
                }
            }
        }).start();
        return id;
    }

    public void close() {
        listening = false;
        try {
            if (server != null) server.close();
        } catch (IOException ignored) {
        }
        for (Conn c : conns.values()) {
            try {
                c.socket.close();
            } catch (IOException ignored) {
            }
        }
        conns.clear();
    }

    // ---- إرسال النتائج إلى اللعبة ----
    private void emit(String event, JSONObject o) {
        run("window.__btEmit&&window.__btEmit(" + JSONObject.quote(event) + "," + JSONObject.quote(o.toString()) + ")");
    }

    private void resolve(int cid, String json) {
        run("window.__btResolve(" + cid + ",true," + JSONObject.quote(json) + ")");
    }

    private void reject(int cid, String msg) {
        run("window.__btResolve(" + cid + ",false," + JSONObject.quote(msg) + ")");
    }

    private void run(final String js) {
        web.post(new Runnable() {
            @Override
            public void run() {
                web.evaluateJavascript(js, null);
            }
        });
    }
}
