package com.rktechhub.snakegamepromax

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.util.Log
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import android.widget.Toast
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.rewardedinterstitial.RewardedInterstitialAd
import com.google.android.gms.ads.rewardedinterstitial.RewardedInterstitialAdLoadCallback

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private lateinit var adView: AdView
    private lateinit var adContainer: LinearLayout
    private var rewardedAd: RewardedInterstitialAd? = null
    private var sdkReady = false
    private var adLoading = false
    private var adShowing = false
    private var pageReady = false

    companion object { private const val TAG = "SnakeGameAdMob" }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(android.graphics.Color.rgb(11, 16, 32))
        }
        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = false
            settings.javaScriptCanOpenWindowsAutomatically = false
            webChromeClient = WebChromeClient()
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val url = request?.url?.toString() ?: return true
                    return !url.startsWith("file:///android_asset/")
                }
                override fun onPageFinished(view: WebView?, url: String?) {
                    if (url == "file:///android_asset/index.html") pageReady = true
                }
            }
            addJavascriptInterface(SnakeAdsBridge(), "snakeAds")
        }
        root.addView(webView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        adContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = android.view.Gravity.CENTER
        }
        adView = AdView(this)
        adView.adUnitId = BuildConfig.BANNER_AD_UNIT_ID
        adView.adListener = object : AdListener() {
            override fun onAdFailedToLoad(error: LoadAdError) {
                if (BuildConfig.DEBUG) Log.w(TAG, "Banner failed: ${error.message}")
                adContainer.removeView(adView)
            }
            override fun onAdLoaded() {
                if (adView.parent == null) adContainer.addView(adView)
            }
        }
        adContainer.addView(adView)
        root.addView(adContainer, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(root)
        webView.loadUrl("file:///android_asset/index.html")

        // Initialize once per Activity process, then request ads asynchronously.
        MobileAds.initialize(this) {
            runOnUiThread {
                sdkReady = true
                loadAdaptiveBanner()
                loadRewardedInterstitial()
            }
        }
    }

    private fun loadAdaptiveBanner() {
        if (!sdkReady || isFinishing) return
        val widthPx = resources.displayMetrics.widthPixels
        val density = resources.displayMetrics.density
        val widthDp = (widthPx / density).toInt().coerceAtLeast(1)
        adView.setAdSize(AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(this, widthDp))
        adView.loadAd(AdRequest.Builder().build())
    }

    private fun loadRewardedInterstitial() {
        if (!sdkReady || adLoading || rewardedAd != null || isFinishing) return
        adLoading = true
        RewardedInterstitialAd.load(
            this, BuildConfig.REWARDED_INTERSTITIAL_AD_UNIT_ID, AdRequest.Builder().build(),
            object : RewardedInterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedInterstitialAd) {
                    adLoading = false
                    rewardedAd = ad
                    if (BuildConfig.DEBUG) Log.d(TAG, "Rewarded interstitial loaded")
                }
                override fun onAdFailedToLoad(error: LoadAdError) {
                    adLoading = false
                    rewardedAd = null
                    if (BuildConfig.DEBUG) Log.w(TAG, "Rewarded interstitial failed: ${error.message}")
                }
            }
        )
    }

    private fun showRewardedInterstitial() {
        if (adShowing) return
        val ad = rewardedAd
        if (ad == null) {
            Toast.makeText(this, "Ad अभी तैयार नहीं है। थोड़ी देर बाद कोशिश करें।", Toast.LENGTH_SHORT).show()
            resolveReward(false)
            loadRewardedInterstitial()
            return
        }
        // Required intro: clearly states the reward and gives the user a chance to decline.
        AlertDialog.Builder(this)
            .setTitle("Optional reward")
            .setMessage("वीडियो विज्ञापन देखने के बाद आपको 50 coins मिलेंगे। आप चाहें तो Skip कर सकते हैं।")
            .setNegativeButton("Skip") { _, _ -> resolveReward(false) }
            .setPositiveButton("Continue") { _, _ -> presentRewarded(ad) }
            .setOnCancelListener { resolveReward(false) }
            .show()
    }

    private fun presentRewarded(ad: RewardedInterstitialAd) {
        if (adShowing || rewardedAd !== ad || isFinishing) { resolveReward(false); return }
        adShowing = true
        rewardedAd = null
        var rewardEarned = false
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdShowedFullScreenContent() { if (BuildConfig.DEBUG) Log.d(TAG, "Ad shown") }
            override fun onAdDismissedFullScreenContent() {
                adShowing = false
                resolveReward(rewardEarned)
                loadRewardedInterstitial()
            }
            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                adShowing = false
                if (BuildConfig.DEBUG) Log.w(TAG, "Ad failed to show: ${error.message}")
                resolveReward(false)
                loadRewardedInterstitial()
            }
        }
        ad.show(this) { rewardItem ->
            // Only this SDK reward callback authorizes the reward.
            rewardEarned = true
            if (BuildConfig.DEBUG) Log.d(TAG, "Reward earned: ${rewardItem.amount} ${rewardItem.type}")
        }
    }

    private fun resolveReward(earned: Boolean) {
        if (!::webView.isInitialized || !pageReady) return
        val js = "window.__snakeRewardResolve && window.__snakeRewardResolve(${if (earned) "true" else "false"})"
        runOnUiThread { if (!isFinishing) webView.evaluateJavascript(js, null) }
    }

    private inner class SnakeAdsBridge {
        @JavascriptInterface fun showRewarded() {
            runOnUiThread {
                if (!pageReady || adShowing) { resolveReward(false); return@runOnUiThread }
                showRewardedInterstitial()
            }
        }
        @JavascriptInterface fun onScreenChanged(screen: String) {
            // Intentionally informational only; JavaScript cannot grant rewards through this method.
            if (BuildConfig.DEBUG) Log.d(TAG, "Game screen: ${screen.take(32)}")
        }
    }

    override fun onResume() {
        super.onResume()
        if (::adView.isInitialized) adView.resume()
    }
    override fun onPause() {
        if (::adView.isInitialized) adView.pause()
        super.onPause()
    }
    override fun onDestroy() {
        if (::adView.isInitialized) { adContainer.removeView(adView); adView.destroy() }
        if (::webView.isInitialized) { webView.removeJavascriptInterface("snakeAds"); webView.stopLoading(); webView.destroy() }
        super.onDestroy()
    }
}
