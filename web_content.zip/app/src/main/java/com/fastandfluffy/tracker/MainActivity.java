package com.fastandfluffy.tracker;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
  private WebView web;
  @Override public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
      requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 33);
    web = new WebView(this);
    web.getSettings().setJavaScriptEnabled(true);
    web.getSettings().setDomStorageEnabled(true);
    web.setWebViewClient(new WebViewClient());
    web.setWebChromeClient(new WebChromeClient());
    web.addJavascriptInterface(new Object() {
      @JavascriptInterface public void updateFast(long start, long end) {
        if (start > 0 && end > System.currentTimeMillis()) {
          Intent intent = new Intent(MainActivity.this, FastingTimerService.class);
          intent.setAction(FastingTimerService.START);
          intent.putExtra("end", end);
          try { startForegroundService(intent); } catch (Exception ignored) { }
        } else if (start == 0) {
          Intent intent = new Intent(MainActivity.this, FastingTimerService.class);
          intent.setAction(FastingTimerService.STOP);
          startService(intent);
        }
      }
    }, "AndroidFasting");
    setContentView(web);
    web.loadUrl("file:///android_asset/index.html");
  }
  @Override public void onBackPressed() {
    if (web.canGoBack()) web.goBack(); else super.onBackPressed();
  }
}
