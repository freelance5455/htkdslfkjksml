package com.fastandfluffy.tracker;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.Context;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;

public class FastingTimerService extends Service {
  public static final String START="com.fastandfluffy.START";
  public static final String STOP="com.fastandfluffy.STOP";
  private static final String CHANNEL="fast_timer";
  private static final String FINISHED="fast_done";
  private static final int ONGOING_ID=101;
  private static final int DONE_ID=102;
  private final Handler handler=new Handler(Looper.getMainLooper());
  private long endTime;
  private final Runnable tick=new Runnable() { @Override public void run() {
    if(endTime==0)return;
    if(System.currentTimeMillis()>=endTime) {
      NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
      nm.notify(DONE_ID, new Notification.Builder(FastingTimerService.this, FINISHED)
          .setContentTitle("Fast complete! 🦙").setContentText("You reached your fasting goal.")
          .setSmallIcon(android.R.drawable.ic_popup_reminder).setAutoCancel(true)
          .setContentIntent(openApp()).build());
      stopForeground(STOP_FOREGROUND_REMOVE); stopSelf(); endTime=0;
    } else handler.postDelayed(this,10000);
  }};
  @Override public void onCreate(){super.onCreate();
    NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
    nm.createNotificationChannel(new NotificationChannel(CHANNEL,"Ongoing fasting timer",NotificationManager.IMPORTANCE_LOW));
    nm.createNotificationChannel(new NotificationChannel(FINISHED,"Fasting completion",NotificationManager.IMPORTANCE_DEFAULT));
  }
  private PendingIntent openApp() {
    Intent i=new Intent(this,MainActivity.class); i.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP|Intent.FLAG_ACTIVITY_CLEAR_TOP);
    return PendingIntent.getActivity(this,0,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
  }
  @Override public int onStartCommand(Intent intent,int flags,int startId){
    if(intent==null)return START_NOT_STICKY;
    if(STOP.equals(intent.getAction())){endTime=0;handler.removeCallbacks(tick);stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();return START_NOT_STICKY;}
    long end=intent.getLongExtra("end",0);
    if(end<=System.currentTimeMillis()){stopSelf();return START_NOT_STICKY;}
    endTime=end;
    long remaining=end-System.currentTimeMillis();
    Notification notification=new Notification.Builder(this,CHANNEL)
      .setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle("🦙 Fast & Fluffy — fasting")
      .setContentText("Time remaining · tap to open")
      .setWhen(System.currentTimeMillis()+remaining).setUsesChronometer(true).setChronometerCountDown(true)
      .setShowWhen(true).setOngoing(true).setOnlyAlertOnce(true).setContentIntent(openApp()).build();
    startForeground(ONGOING_ID,notification);
    handler.removeCallbacks(tick);handler.postDelayed(tick,1000);
    return START_STICKY;
  }
  @Override public void onDestroy(){handler.removeCallbacks(tick);super.onDestroy();}
  @Override public IBinder onBind(Intent intent){return null;}
}
