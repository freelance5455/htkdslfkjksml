package com.xgaming.app

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL

class XGamingSyncWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    companion object {
        const val API = "https://xgaming-api-1scl-production.up.railway.app/api"
        const val CHANNEL = "xgaming_updates"
    }

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        try {
            val conn = URL("$API/games").openConnection() as HttpURLConnection
            conn.connectTimeout = 8000; conn.readTimeout = 10000; conn.requestMethod = "GET"
            if (conn.responseCode !in 200..299) return@withContext Result.retry()
            val raw = conn.inputStream.bufferedReader().use { it.readText() }
            val arr = try { JSONArray(raw) } catch (_: Exception) {
                val obj = org.json.JSONObject(raw); obj.optJSONArray("games") ?: JSONArray()
            }
            val current = buildMap<String, String> {
                for (i in 0 until arr.length()) {
                    val g = arr.optJSONObject(i) ?: continue
                    val id = g.optString("id")
                    if (id.isNotBlank()) put(id, g.optString("version") + "|" + g.optString("updatedAt"))
                }
            }
            val prefs = applicationContext.getSharedPreferences("xgaming_sync", Context.MODE_PRIVATE)
            val old = prefs.getStringSet("games", emptySet())!!.associate { it.substringBefore("=") to it.substringAfter("=") }
            if (old.isNotEmpty()) {
                current.forEach { (id, value) ->
                    val name = arr.findName(id)
                    when {
                        !old.containsKey(id) -> notify("🎮 لعبة جديدة", "تمت إضافة $name إلى X Gaming")
                        old[id] != value -> notify("🔄 تحديث لعبة", "تم تحديث $name")
                    }
                }
            }
            prefs.edit().putStringSet("games", current.map { "${it.key}=${it.value}" }.toSet()).apply()
            // Broadcast administrator announcements to Android notifications.
            try {
                val ac = URL("$API/announcements").openConnection() as HttpURLConnection
                ac.connectTimeout = 7000; ac.readTimeout = 10000; ac.requestMethod = "GET"
                if (ac.responseCode in 200..299) {
                    val announcements = JSONArray(ac.inputStream.bufferedReader().use { it.readText() })
                    val seenA = prefs.getStringSet("announcements", emptySet())!!.toMutableSet()
                    val nextA = mutableSetOf<String>()
                    for (i in 0 until announcements.length()) {
                        val a = announcements.optJSONObject(i) ?: continue
                        val id = a.optString("id")
                        if (id.isBlank()) continue
                        nextA.add(id)
                        if (!seenA.contains(id)) notify(a.optString("title", "إشعار"), a.optString("message", ""))
                    }
                    prefs.edit().putStringSet("announcements", nextA).apply()
                }
            } catch (_: Exception) { }
            Result.success()
        } catch (_: Exception) { Result.retry() }
    }

    private fun JSONArray.findName(id: String): String {
        for (i in 0 until length()) {
            val g = optJSONObject(i) ?: continue
            if (g.optString("id") == id) return g.optString("name", "لعبة جديدة")
        }
        return "لعبة"
    }

    private fun notify(title: String, text: String) {
        if (android.os.Build.VERSION.SDK_INT >= 33 && applicationContext.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val n = NotificationCompat.Builder(applicationContext, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title).setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setAutoCancel(true).setPriority(NotificationCompat.PRIORITY_DEFAULT).build()
        NotificationManagerCompat.from(applicationContext).notify((System.currentTimeMillis() % Int.MAX_VALUE).toInt(), n)
    }
}
