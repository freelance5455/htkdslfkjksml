package com.xgaming.app

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.net.*
import android.os.*
import android.provider.Settings
import android.webkit.*
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var chooser: ValueCallback<Array<Uri>>? = null
    private val PICK = 4001
    private val NOTIFICATION_PERMISSION_REQUEST = 4003
    private val IMAGE_PERMISSION_REQUEST = 4004

    // Put your update.json URL here. Example JSON is in assets/update.json.
    private val UPDATE_JSON_URL = "https://xgaming-api-1scl-production.up.railway.app/api/app-update"

    private val connectivityReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) = updateNetworkState()
    }

    private fun hasInternet(): Boolean {
        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }

    private fun updateNetworkState() {
        if (::web.isInitialized) web.evaluateJavascript("window.nativeNetworkState && window.nativeNetworkState(${hasInternet()});", null)
    }

    private fun openTelegram() {
        val httpsUri = Uri.parse("https://t.me/XGamesMods")
        listOf("org.telegram.messenger", "org.thunderdog.challegram").forEach { pkg ->
            try {
                val intent = Intent(Intent.ACTION_VIEW, httpsUri).setPackage(pkg)
                if (intent.resolveActivity(packageManager) != null) { startActivity(intent); return }
            } catch (_: Exception) { }
        }
        try { startActivity(Intent(Intent.ACTION_VIEW, httpsUri)) }
        catch (_: Exception) { Toast.makeText(this, "مش لاقي تطبيق يفتح رابط تيليجرام", Toast.LENGTH_LONG).show() }
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), NOTIFICATION_PERMISSION_REQUEST)
    }

    private fun hasImagePermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= 33) {
            checkSelfPermission(Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED
        } else {
            checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
        }
    }

    private fun requestImagePermissionIfNeeded(onReady: () -> Unit) {
        if (hasImagePermission()) { onReady(); return }
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.READ_MEDIA_IMAGES), IMAGE_PERMISSION_REQUEST)
        } else {
            requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE), IMAGE_PERMISSION_REQUEST)
        }
    }

    private fun openImageChooser(callback: ValueCallback<Array<Uri>>?, params: WebChromeClient.FileChooserParams?) {
        chooser?.onReceiveValue(null)
        chooser = callback
        requestImagePermissionIfNeeded {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "image/*"
                putExtra(Intent.EXTRA_ALLOW_MULTIPLE, params?.mode == WebChromeClient.FileChooserParams.MODE_OPEN_MULTIPLE)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            }
            try { startActivityForResult(intent, PICK) } catch (_: Exception) {
                chooser = null
                Toast.makeText(this, "تعذر فتح صور الجهاز", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == IMAGE_PERMISSION_REQUEST && grantResults.isNotEmpty() && grantResults[0] != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "يمكنك اختيار الصور من نافذة النظام حتى بدون السماح الدائم", Toast.LENGTH_SHORT).show()
        }
    }

    private fun checkForUpdate() {
        Thread {
            try {
                val conn = URL(UPDATE_JSON_URL).openConnection() as HttpURLConnection
                conn.connectTimeout = 7000; conn.readTimeout = 7000; conn.requestMethod = "GET"
                if (conn.responseCode !in 200..299) return@Thread
                val json = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
                val latestCode = json.optInt("versionCode", 1)
                val latestName = json.optString("versionName", "")
                val apkUrl = json.optString("apkUrl", "")
                val notes = json.optString("notes", "في تحديث جديد للتطبيق")
                val currentCode = packageManager.getPackageInfo(packageName, 0).longVersionCode.toInt()
                if (latestCode > currentCode && apkUrl.isNotBlank()) {
                    runOnUiThread { showUpdateDialog(latestName, notes, apkUrl) }
                }
            } catch (_: Exception) { }
        }.start()
    }

    private fun showUpdateDialog(versionName: String, notes: String, apkUrl: String) {
        AlertDialog.Builder(this)
            .setTitle("🚀 تحديث جديد متاح")
            .setMessage("الإصدار الجديد: $versionName\n\n$notes\n\nهيتم تنزيل التحديث وبعدها Android هيطلب تأكيد التثبيت.")
            .setPositiveButton("تحديث الآن") { _, _ -> downloadAndInstall(apkUrl) }
            .setNegativeButton("لاحقًا", null)
            .setCancelable(false)
            .show()
    }

    private fun downloadAndInstall(apkUrl: String) {
        Toast.makeText(this, "جاري تنزيل التحديث...", Toast.LENGTH_SHORT).show()
        Thread {
            try {
                val conn = URL(apkUrl).openConnection() as HttpURLConnection
                conn.connectTimeout = 15000; conn.readTimeout = 30000
                conn.connect()
                if (conn.responseCode !in 200..299) throw Exception("HTTP ${conn.responseCode}")
                val file = File(cacheDir, "updates/xgaming-update.apk")
                file.parentFile?.mkdirs()
                conn.inputStream.use { input -> FileOutputStream(file).use { output -> input.copyTo(output) } }
                runOnUiThread { installApk(file) }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, "فشل تنزيل التحديث", Toast.LENGTH_LONG).show() }
            }
        }.start()
    }

    private fun installApk(file: File) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !packageManager.canRequestPackageInstalls()) {
            Toast.makeText(this, "اسمح للتطبيق بتثبيت التحديثات ثم ارجع للتطبيق", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName")))
            return
        }
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try { startActivity(intent) } catch (_: Exception) { Toast.makeText(this, "تعذر بدء تثبيت التحديث", Toast.LENGTH_LONG).show() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        web.settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE

        web.addJavascriptInterface(object {
            @JavascriptInterface fun isOnline(): Boolean = hasInternet()
            @JavascriptInterface fun requestNotificationPermission() = runOnUiThread { requestNotificationPermission() }
            @JavascriptInterface fun openTelegram() = runOnUiThread { openTelegram() }
            @JavascriptInterface fun openExternal(url: String) = runOnUiThread { try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: Exception) { Toast.makeText(this@MainActivity, "تعذر فتح الرابط", Toast.LENGTH_SHORT).show() } }
        }, "XGNetwork")

        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(view: WebView?, callback: ValueCallback<Array<Uri>>?, params: FileChooserParams?): Boolean {
                val accepts = params?.acceptTypes?.filter { it.isNotBlank() } ?: emptyList()
                if (accepts.isEmpty() || accepts.any { it.startsWith("image/") }) {
                    openImageChooser(callback, params)
                } else {
                    chooser?.onReceiveValue(null); chooser = callback
                    val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "*/*"
                        putExtra(Intent.EXTRA_ALLOW_MULTIPLE, params?.mode == FileChooserParams.MODE_OPEN_MULTIPLE)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
                    }
                    try { startActivityForResult(intent, PICK) } catch (_: Exception) { chooser = null; Toast.makeText(this@MainActivity, "تعذر فتح الملفات", Toast.LENGTH_SHORT).show() }
                }
                return true
            }
        }

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val raw = request?.url?.toString() ?: return false
                val url = try { Uri.decode(raw) } catch (_: Exception) { raw }
                val lower = url.lowercase()
                if (lower.startsWith("https://t.me/") || lower.startsWith("http://t.me/") || lower.startsWith("tg://") || lower.startsWith("tg:")) { openTelegram(); return true }
                if (lower.startsWith("http://") || lower.startsWith("https://")) { try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: Exception) {} ; return true }
                return false
            }
        }
        web.loadUrl("file:///android_asset/index.html")
        setContentView(web)
        registerReceiver(connectivityReceiver, IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION))
        web.postDelayed({ updateNetworkState() }, 300)
        web.postDelayed({ requestNotificationPermission() }, 900)
        web.postDelayed({ checkForUpdate() }, 1800)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK) {
            val results = if (resultCode == RESULT_OK && data != null) {
                val clip = data.clipData
                if (clip != null) Array(clip.itemCount) { clip.getItemAt(it).uri } else data.data?.let { arrayOf(it) }
            } else null
            chooser?.onReceiveValue(results); chooser = null
        }
    }

    override fun onDestroy() { try { unregisterReceiver(connectivityReceiver) } catch (_: Exception) {}; web.destroy(); super.onDestroy() }
    override fun onResume() {
        super.onResume()
        // إعادة فحص التحديث عند كل رجوع للتطبيق حتى يصل التحديث لكل المستخدمين.
        window.decorView.postDelayed({ checkForUpdate() }, 900)
    }

    @Deprecated("Deprecated in Android API 33") override fun onBackPressed() { if (web.canGoBack()) web.goBack() else super.onBackPressed() }
}
