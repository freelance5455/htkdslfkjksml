package com.xgaming.app

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.net.*
import android.os.*
import android.provider.Settings
import android.webkit.*
import android.widget.Toast
import android.os.Environment
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.FileProvider
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.WorkManager
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var chooser: ValueCallback<Array<Uri>>? = null
    private val PICK = 4001
    private val NOTIFICATION_PERMISSION_REQUEST = 4003
    private val STORAGE_PERMISSION_REQUEST = 4005
    private var pendingDownload: Triple<String,String,String>? = null
    private val NOTIFICATION_CHANNEL_ID = "xgaming_updates"

    // Put your update.json URL here. Example JSON is in assets/update.json.
    private val UPDATE_JSON_URL = "https://xgaming-api-1scl-production.up.railway.app/api/app-update"

    private val connectivityReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) = updateNetworkState()
    }

    private fun hasInternet(): Boolean {
        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }

    private fun updateNetworkState() {
        if (::web.isInitialized) web.evaluateJavascript("window.nativeNetworkState && window.nativeNetworkState(${hasInternet()});", null)
    }

    private fun openTelegram() {
        val httpsUri = Uri.parse("https://t.me/XGamesMods")
        listOf("org.telegram.messenger", "org.thunderdog.challegram").forEach { pkg ->
            try {
                val intent = Intent(Intent.ACTION_VIEW, httpsUri).setPackage(pkg)
                if (intent.resolveActivity(packageManager) != null) { startActivity(intent); return }
            } catch (_: Exception) { }
        }
        try { startActivity(Intent(Intent.ACTION_VIEW, httpsUri)) }
        catch (_: Exception) { Toast.makeText(this, "مش لاقي تطبيق يفتح رابط تيليجرام", Toast.LENGTH_LONG).show() }
    }

    private fun scheduleBackgroundSync() {
        val request = PeriodicWorkRequestBuilder<XGamingSyncWorker>(15, java.util.concurrent.TimeUnit.MINUTES)
            .setConstraints(androidx.work.Constraints.Builder().setRequiredNetworkType(androidx.work.NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork("xgaming_game_sync", ExistingPeriodicWorkPolicy.UPDATE, request)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                NOTIFICATION_CHANNEL_ID,
                "تحديثات X Gaming",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "إشعارات الألعاب والتحديثات الجديدة في X Gaming"
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun showUpdateNotification(title: String, message: String) {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val builder = NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
        try { NotificationManagerCompat.from(this).notify((System.currentTimeMillis() % Int.MAX_VALUE).toInt(), builder.build()) } catch (_: Exception) { }
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), NOTIFICATION_PERMISSION_REQUEST)
    }

    // الصور تُختار من واجهة Android الرسمية عبر Storage Access Framework.
    // لا نطلب READ_MEDIA_IMAGES لأن اختيار صورة محددة لا يحتاج صلاحية مكتبة الصور كاملة.
    private fun openImageChooser(callback: ValueCallback<Array<Uri>>?, params: WebChromeClient.FileChooserParams?) {
        chooser?.onReceiveValue(null)
        chooser = callback
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, params?.mode == WebChromeClient.FileChooserParams.MODE_OPEN_MULTIPLE)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        try {
            startActivityForResult(intent, PICK)
        } catch (_: Exception) {
            chooser = null
            Toast.makeText(this, "تعذر فتح صور الجهاز", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == STORAGE_PERMISSION_REQUEST) {
            val pending = pendingDownload
            pendingDownload = null
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED && pending != null) {
                startNativeDownload(pending.first, pending.second, pending.third)
            } else if (pending != null) {
                Toast.makeText(this, "لازم تسمح بحفظ الملفات لبدء التحميل", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun checkForUpdate() {
        Thread {
            try {
                val conn = URL(UPDATE_JSON_URL).openConnection() as HttpURLConnection
                conn.connectTimeout = 7000; conn.readTimeout = 7000; conn.requestMethod = "GET"
                if (conn.responseCode !in 200..299) return@Thread
                val json = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
                val latestCode = json.optInt("versionCode", 1)
                val latestName = json.optString("versionName", "")
                val apkUrl = json.optString("apkUrl", "")
                val notes = json.optString("notes", "في تحديث جديد للتطبيق")
                val currentCode = packageManager.getPackageInfo(packageName, 0).longVersionCode.toInt()
                if (latestCode > currentCode && apkUrl.isNotBlank()) {
                    val seenKey = "xgaming_notified_app_update_$latestCode"
                    if (getPreferences(MODE_PRIVATE).getBoolean(seenKey, false).not()) {
                        getPreferences(MODE_PRIVATE).edit().putBoolean(seenKey, true).apply()
                        runOnUiThread { showUpdateNotification("🚀 تحديث جديد لـ X Gaming", "الإصدار $latestName متاح الآن") }
                    }
                    runOnUiThread { showUpdateDialog(latestName, notes, apkUrl) }
                }
            } catch (_: Exception) { }
        }.start()
    }

    private fun showUpdateDialog(versionName: String, notes: String, apkUrl: String) {
        AlertDialog.Builder(this)
            .setTitle("🚀 تحديث جديد متاح")
            .setMessage("الإصدار الجديد: $versionName\n\n$notes\n\nهيتم تنزيل التحديث وبعدها Android هيطلب تأكيد التثبيت.")
            .setPositiveButton("تحديث الآن") { _, _ -> downloadAndInstall(apkUrl) }
            .setNegativeButton("لاحقًا", null)
            .setCancelable(false)
            .show()
    }

    private fun downloadAndInstall(apkUrl: String) {
        Toast.makeText(this, "جاري تنزيل التحديث...", Toast.LENGTH_SHORT).show()
        Thread {
            try {
                val conn = URL(apkUrl).openConnection() as HttpURLConnection
                conn.connectTimeout = 15000; conn.readTimeout = 30000
                conn.connect()
                if (conn.responseCode !in 200..299) throw Exception("HTTP ${conn.responseCode}")
                val file = File(cacheDir, "updates/xgaming-update.apk")
                file.parentFile?.mkdirs()
                conn.inputStream.use { input -> FileOutputStream(file).use { output -> input.copyTo(output) } }
                runOnUiThread { installApk(file) }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, "فشل تنزيل التحديث", Toast.LENGTH_LONG).show() }
            }
        }.start()
    }

    private fun installApk(file: File) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !packageManager.canRequestPackageInstalls()) {
            Toast.makeText(this, "اسمح للتطبيق بتثبيت التحديثات ثم ارجع للتطبيق", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName")))
            return
        }
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try { startActivity(intent) } catch (_: Exception) { Toast.makeText(this, "تعذر بدء تثبيت التحديث", Toast.LENGTH_LONG).show() }
    }

    private fun requestStoragePermissionIfNeeded(onReady: () -> Unit) {
        if (Build.VERSION.SDK_INT <= 28 && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), STORAGE_PERMISSION_REQUEST)
        } else onReady()
    }

    private fun safeFileName(name: String, label: String, url: String): String {
        val clean = (name + "_" + label).replace(Regex("[^A-Za-z0-9_\\-.\\u0600-\\u06FF]"), "_").take(70)
        val ext = when {
            url.lowercase().contains(".apk") || label.equals("APK", true) -> ".apk"
            url.lowercase().contains(".obb") || label.equals("OBB", true) -> ".obb"
            url.lowercase().contains(".zip") -> ".zip"
            else -> ".bin"
        }
        return if (clean.lowercase().endsWith(ext)) clean else clean + ext
    }

    private fun startNativeDownload(url: String, gameName: String, label: String) {
        val clean = try { Uri.decode(url.trim()) } catch (_: Exception) { url.trim() }
        if (!clean.startsWith("http://") && !clean.startsWith("https://")) {
            Toast.makeText(this, "رابط التحميل غير صالح", Toast.LENGTH_SHORT).show(); return
        }
        pendingDownload = Triple(clean, gameName, label)
        requestStoragePermissionIfNeeded {
            pendingDownload = null
            try {
                val fileName = safeFileName(gameName, label, clean)
                val request = DownloadManager.Request(Uri.parse(clean)).apply {
                    setTitle("X Gaming • $gameName")
                    setDescription("جاري تنزيل $label")
                    setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    setAllowedOverMetered(true)
                    setAllowedOverRoaming(true)
                    setMimeType(when (label.uppercase()) { "APK" -> "application/vnd.android.package-archive"; "OBB" -> "application/octet-stream"; else -> "application/octet-stream" })
                    setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "XGaming/$fileName")
                }
                val dm = getSystemService(DOWNLOAD_SERVICE) as DownloadManager
                dm.enqueue(request)
                showUpdateNotification("⬇️ بدأ التحميل", "$gameName • $label")
                Toast.makeText(this, "بدأ تنزيل $label في مجلد Downloads/XGaming", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                Toast.makeText(this, "تعذر بدء التحميل", Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        web.settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE

        createNotificationChannel()
        scheduleBackgroundSync()

        web.addJavascriptInterface(object {
            @JavascriptInterface fun isOnline(): Boolean = hasInternet()
            @JavascriptInterface fun requestNotificationPermission() = runOnUiThread { requestNotificationPermission() }
            @JavascriptInterface fun showUpdateNotification(title: String, message: String) = runOnUiThread { showUpdateNotification(title, message) }
            @JavascriptInterface fun openTelegram() = runOnUiThread { openTelegram() }
            @JavascriptInterface fun startDownload(url: String, gameName: String, label: String) = runOnUiThread { startNativeDownload(url, gameName, label) }
            @JavascriptInterface fun openExternal(url: String) = runOnUiThread { try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: Exception) { Toast.makeText(this@MainActivity, "تعذر فتح الرابط", Toast.LENGTH_SHORT).show() } }
        }, "XGNetwork")

        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(view: WebView?, callback: ValueCallback<Array<Uri>>?, params: FileChooserParams?): Boolean {
                val accepts = params?.acceptTypes?.filter { it.isNotBlank() } ?: emptyList()
                if (accepts.isEmpty() || accepts.any { it.startsWith("image/") }) {
                    openImageChooser(callback, params)
                } else {
                    chooser?.onReceiveValue(null); chooser = callback
                    val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "*/*"
                        putExtra(Intent.EXTRA_ALLOW_MULTIPLE, params?.mode == FileChooserParams.MODE_OPEN_MULTIPLE)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
                    }
                    try { startActivityForResult(intent, PICK) } catch (_: Exception) { chooser = null; Toast.makeText(this@MainActivity, "تعذر فتح الملفات", Toast.LENGTH_SHORT).show() }
                }
                return true
            }
        }

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val raw = request?.url?.toString() ?: return false
                val url = try { Uri.decode(raw) } catch (_: Exception) { raw }
                val lower = url.lowercase()
                if (lower.startsWith("https://t.me/") || lower.startsWith("http://t.me/") || lower.startsWith("tg://") || lower.startsWith("tg:")) { openTelegram(); return true }
                if (lower.startsWith("http://") || lower.startsWith("https://")) { try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: Exception) {} ; return true }
                return false
            }
        }
        web.loadUrl("file:///android_asset/index.html")
        setContentView(web)
        registerReceiver(connectivityReceiver, IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION))
        web.postDelayed({ updateNetworkState() }, 300)
        web.postDelayed({ requestNotificationPermission() }, 900)
        web.postDelayed({ checkForUpdate() }, 1800)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK) {
            val results = if (resultCode == RESULT_OK && data != null) {
                val clip = data.clipData
                if (clip != null) {
                    Array(clip.itemCount) { index ->
                        val uri = clip.getItemAt(index).uri
                        try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
                        uri
                    }
                } else {
                    data.data?.let { uri ->
                        try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
                        arrayOf(uri)
                    }
                }
            } else null
            chooser?.onReceiveValue(results)
            chooser = null
        }
    }

    override fun onDestroy() { try { unregisterReceiver(connectivityReceiver) } catch (_: Exception) {}; web.destroy(); super.onDestroy() }
    override fun onResume() {
        super.onResume()
        // إعادة فحص التحديث عند كل رجوع للتطبيق حتى يصل التحديث لكل المستخدمين.
        window.decorView.postDelayed({ checkForUpdate() }, 900)
    }

    @Deprecated("Deprecated in Android API 33") override fun onBackPressed() { if (web.canGoBack()) web.goBack() else super.onBackPressed() }
}
