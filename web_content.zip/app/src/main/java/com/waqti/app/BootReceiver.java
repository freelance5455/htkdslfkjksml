package com.waqti.app;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
public class BootReceiver extends BroadcastReceiver { @Override public void onReceive(Context c, Intent i) { if(c.getSharedPreferences("waqti",0).getBoolean("reminders",false)) ReminderReceiver.schedule(c); } }
