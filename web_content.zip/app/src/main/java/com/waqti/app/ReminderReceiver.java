package com.waqti.app;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.SystemClock;
import androidx.core.app.NotificationCompat;

public class ReminderReceiver extends BroadcastReceiver {
  static final String CHANNEL="waqti_reminders"; static final int ID=8101; static final long INTERVAL=10*60*1000L;
  public static void createChannel(Context c) { if(Build.VERSION.SDK_INT>=26) { NotificationChannel ch=new NotificationChannel(CHANNEL,"تذكيرات وقتي",NotificationManager.IMPORTANCE_HIGH); ch.setDescription("تذكير لمراجعة المهام كل عشر دقائق"); ch.enableVibration(true); ch.setVibrationPattern(new long[]{0,350,150,350}); ((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).createNotificationChannel(ch); } }
  static PendingIntent pi(Context c) { Intent i=new Intent(c,ReminderReceiver.class); return PendingIntent.getBroadcast(c,ID,i,PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT>=23?PendingIntent.FLAG_IMMUTABLE:0)); }
  public static void schedule(Context c) { createChannel(c); ((android.app.AlarmManager)c.getSystemService(Context.ALARM_SERVICE)).setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP,SystemClock.elapsedRealtime()+INTERVAL,pi(c)); c.getSharedPreferences("waqti",0).edit().putBoolean("reminders",true).apply(); }
  public static void cancel(Context c) { ((AlarmManager)c.getSystemService(Context.ALARM_SERVICE)).cancel(pi(c)); c.getSharedPreferences("waqti",0).edit().putBoolean("reminders",false).apply(); }
  @Override public void onReceive(Context c,Intent i) { if(Intent.ACTION_BOOT_COMPLETED.equals(i.getAction())) { if(c.getSharedPreferences("waqti",0).getBoolean("reminders",false)) schedule(c); return; }
    createChannel(c); Intent open=new Intent(c,MainActivity.class); PendingIntent content=PendingIntent.getActivity(c,ID,open,PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT>=23?PendingIntent.FLAG_IMMUTABLE:0));
    NotificationCompat.Builder n=new NotificationCompat.Builder(c,CHANNEL).setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle("وقتي — تذكير").setContentText("راجع مهامك وابدأ الخطوة التالية.").setPriority(NotificationCompat.PRIORITY_HIGH).setVibrate(new long[]{0,350,150,350}).setAutoCancel(true).setContentIntent(content);
    ((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).notify(ID,n.build()); schedule(c);
  }
}
