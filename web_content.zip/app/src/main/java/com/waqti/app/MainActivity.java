package com.waqti.app;

import android.Manifest;
import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.content.pm.PackageManager;
import android.widget.Toast;

public class MainActivity extends Activity {
  WebView web;
  @Override public void onCreate(Bundle b) { super.onCreate(b);
    ReminderReceiver.createChannel(this);
    if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 10);
    web = new WebView(this); setContentView(web);
    WebSettings settings=web.getSettings(); settings.setJavaScriptEnabled(true); settings.setDomStorageEnabled(true);
    web.setWebViewClient(new WebViewClient()); web.addJavascriptInterface(new Bridge(), "WaqtiAndroid");
    web.loadUrl("file:///android_asset/index.html");
  }
  public class Bridge {
    @JavascriptInterface public void enableReminders() { runOnUiThread(() -> { ReminderReceiver.schedule(MainActivity.this); Toast.makeText(MainActivity.this,"تم تفعيل تذكير وقتي كل 10 دقائق",Toast.LENGTH_SHORT).show(); }); }
    @JavascriptInterface public void disableReminders() { runOnUiThread(() -> ReminderReceiver.cancel(MainActivity.this)); }
  }
  @Override public void onBackPressed() { if(web!=null && web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
