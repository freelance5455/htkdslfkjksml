package com.fourstyle.sensi;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.widget.Toast;

public class MainActivity extends Activity {
  private WebView web;
  @Override public void onCreate(Bundle state) {
    super.onCreate(state);
    web = new WebView(this);
    web.getSettings().setJavaScriptEnabled(true);
    web.getSettings().setDomStorageEnabled(true);
    web.setWebViewClient(new WebViewClient());
    web.addJavascriptInterface(new GameBridge(), "AndroidGame");
    setContentView(web);
    web.loadUrl("file:///android_asset/index.html");
  }
  public class GameBridge {
    @JavascriptInterface public void openFreeFire() {
      runOnUiThread(() -> {
        try {
          Intent launch = getPackageManager().getLaunchIntentForPackage("com.dts.freefireth");
          if (launch != null) { startActivity(launch); }
          else { Toast.makeText(MainActivity.this, "Free Fire is not installed or not visible", Toast.LENGTH_LONG).show(); }
        } catch (Exception ex) {
          Toast.makeText(MainActivity.this, "Unable to open Free Fire", Toast.LENGTH_LONG).show();
        }
      });
    }
  }
  @Override public void onBackPressed() { if(web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
