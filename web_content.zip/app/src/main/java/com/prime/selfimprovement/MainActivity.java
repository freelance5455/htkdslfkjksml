package com.prime.selfimprovement;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private WebView web;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        web.addJavascriptInterface(new SupportBridge(), "PrimeSupport");
        web.setBackgroundColor(0xFF080808);
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    private final class SupportBridge {
        @JavascriptInterface
        public void openInstagram() {
            runOnUiThread(() -> {
                Uri profile = Uri.parse("https://www.instagram.com/noctiq14/");
                Intent chromeIntent = new Intent(Intent.ACTION_VIEW, profile);
                chromeIntent.setPackage("com.android.chrome");
                try {
                    startActivity(chromeIntent);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(MainActivity.this,
                        "Google Chrome is not installed. Please install Chrome to open PRIME Support.",
                        Toast.LENGTH_LONG).show();
                }
            });
        }
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) {
            web.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
