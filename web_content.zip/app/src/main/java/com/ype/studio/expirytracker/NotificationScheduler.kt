package com.ype.studio.expirytracker

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import org.json.JSONArray
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZonedDateTime

object NotificationScheduler {
    private const val PREFS = "ype_native_notifications"
    private const val ITEMS_JSON = "items_json"
    private const val HOUR = 9
    private const val MINUTE = 0
    private const val CHANNEL_ID = "expiry_reminders"

    fun saveAndSchedule(context: Context, itemsJson: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(ITEMS_JSON, itemsJson).apply()
        scheduleAll(context, itemsJson)
    }

    fun scheduleFromSaved(context: Context) {
        val json = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(ITEMS_JSON, "[]") ?: "[]"
        scheduleAll(context, json)
    }

    fun cancelAll(context: Context) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val json = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(ITEMS_JSON, "[]") ?: "[]"
        runCatching {
            val arr = JSONArray(json)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                val id = obj.optString("id")
                for (offset in intArrayOf(30, 7, 3, 1, 0)) cancelOne(context, alarmManager, id, offset)
            }
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(ITEMS_JSON, "[]").apply()
    }

    private fun scheduleAll(context: Context, itemsJson: String) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        runCatching {
            val arr = JSONArray(itemsJson)
            for (i in 0 until arr.length()) {
                val item = arr.getJSONObject(i)
                val id = item.optString("id")
                val name = item.optString("name", "Item")
                val expiry = item.optString("expiry")
                if (id.isBlank() || expiry.isBlank()) continue
                for (offset in intArrayOf(30, 7, 3, 1, 0)) {
                    cancelOne(context, alarmManager, id, offset)
                    val trigger = reminderTime(expiry, offset) ?: continue
                    if (trigger.isAfter(ZonedDateTime.now())) {
                        scheduleOne(context, alarmManager, id, name, expiry, offset, trigger)
                    }
                }
            }
        }
    }

    private fun reminderTime(expiry: String, daysBefore: Int): ZonedDateTime? = runCatching {
        val date = LocalDate.parse(expiry).minusDays(daysBefore.toLong())
        ZonedDateTime.of(LocalDateTime.of(date, LocalTime.of(HOUR, MINUTE)), ZoneId.systemDefault())
    }.getOrNull()

    private fun requestCode(id: String, offset: Int): Int = ("$id:$offset").hashCode()

    private fun scheduleOne(context: Context, alarmManager: AlarmManager, id: String, name: String, expiry: String, offset: Int, trigger: ZonedDateTime) {
        val intent = Intent(context, ExpiryAlarmReceiver::class.java).apply {
            putExtra("item_id", id)
            putExtra("item_name", name)
            putExtra("expiry", expiry)
            putExtra("offset", offset)
        }
        val pending = PendingIntent.getBroadcast(
            context,
            requestCode(id, offset),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val millis = trigger.toInstant().toEpochMilli()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && alarmManager.canScheduleExactAlarms()) {
            alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, millis, pending)
        } else {
            alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, millis, pending)
        }
    }

    private fun cancelOne(context: Context, alarmManager: AlarmManager, id: String, offset: Int) {
        val intent = Intent(context, ExpiryAlarmReceiver::class.java)
        val pending = PendingIntent.getBroadcast(
            context,
            requestCode(id, offset),
            intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pending != null) {
            alarmManager.cancel(pending)
            pending.cancel()
        }
    }

    const val CHANNEL = CHANNEL_ID
}
