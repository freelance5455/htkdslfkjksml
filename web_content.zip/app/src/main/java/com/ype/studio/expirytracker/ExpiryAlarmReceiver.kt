package com.ype.studio.expirytracker

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

class ExpiryAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val itemName = intent.getStringExtra("item_name") ?: "Item"
        val expiry = intent.getStringExtra("expiry") ?: ""
        val offset = intent.getIntExtra("offset", 0)
        createChannel(context)
        if (android.os.Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return

        val language = context.getSharedPreferences("ype_native_notifications", Context.MODE_PRIVATE).getString("language", "en") ?: "en"
        val title = when (offset) {
            0 -> when(language) { "es" -> "Caducado hoy: $itemName"; "hi" -> "आज समाप्त: $itemName"; "zh" -> "今天到期：$itemName"; "ar" -> "ينتهي اليوم: $itemName"; else -> "Expired today: $itemName" }
            else -> when(language) { "es" -> "Recordatorio de caducidad: $itemName"; "hi" -> "समाप्ति रिमाइंडर: $itemName"; "zh" -> "到期提醒：$itemName"; "ar" -> "تذكير بانتهاء الصلاحية: $itemName"; else -> "Expiry reminder: $itemName" }
        }
        val body = when (offset) {
            30 -> when(language) { "es" -> "$itemName caduca en 30 días ($expiry)."; "hi" -> "$itemName 30 दिनों में समाप्त होगा ($expiry)।"; "zh" -> "$itemName 将在30天后到期（$expiry）。"; "ar" -> "$itemName ينتهي خلال 30 يوماً ($expiry)."; else -> "$itemName expires in 30 days ($expiry)." }
            1 -> when(language) { "es" -> "$itemName caduca mañana ($expiry)."; "hi" -> "$itemName कल समाप्त होगा ($expiry)।"; "zh" -> "$itemName 明天到期（$expiry）。"; "ar" -> "$itemName ينتهي غداً ($expiry)."; else -> "$itemName expires tomorrow ($expiry)." }
            3 -> when(language) { "es" -> "$itemName caduca en 3 días ($expiry)."; "hi" -> "$itemName 3 दिनों में समाप्त होगा ($expiry)।"; "zh" -> "$itemName 将在3天后到期（$expiry）。"; "ar" -> "$itemName ينتهي خلال 3 أيام ($expiry)."; else -> "$itemName expires in 3 days ($expiry)." }
            7 -> when(language) { "es" -> "$itemName caduca en 7 días ($expiry)."; "hi" -> "$itemName 7 दिनों में समाप्त होगा ($expiry)।"; "zh" -> "$itemName 将在7天后到期（$expiry）。"; "ar" -> "$itemName ينتهي خلال 7 أيام ($expiry)."; else -> "$itemName expires in 7 days ($expiry)." }
            else -> when(language) { "es" -> "$itemName caduca hoy ($expiry)."; "hi" -> "$itemName आज समाप्त होगा ($expiry)।"; "zh" -> "$itemName 今天到期（$expiry）。"; "ar" -> "$itemName ينتهي اليوم ($expiry)."; else -> "$itemName expires today ($expiry)." }
        }
        val openIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openPending = android.app.PendingIntent.getActivity(
            context, itemName.hashCode(), openIntent,
            android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(context, NotificationScheduler.CHANNEL)
            .setSmallIcon(com.ype.studio.expirytracker.R.drawable.ic_stat_expiry)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(if (offset == 0) NotificationCompat.PRIORITY_HIGH else NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .setContentIntent(openPending)
            .build()
        NotificationManagerCompat.from(context).notify((itemName + expiry + offset).hashCode(), notification)
    }

    private fun createChannel(context: Context) {
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val channel = NotificationChannel(
                NotificationScheduler.CHANNEL,
                context.getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_HIGH
            ).apply { description = context.getString(R.string.notification_channel_description) }
            manager.createNotificationChannel(channel)
        }
    }
}
