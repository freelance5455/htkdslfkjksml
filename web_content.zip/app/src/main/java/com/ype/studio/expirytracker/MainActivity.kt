package com.ype.studio.expirytracker

import android.Manifest
import android.app.AlarmManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var webView: WebView

    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildWebView())
        createNotificationChannel()
    }

    private fun buildWebView(): WebView {
        webView = WebView(this)
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            cacheMode = WebSettings.LOAD_DEFAULT
            allowFileAccess = true
            allowContentAccess = true
            builtInZoomControls = false
            displayZoomControls = false
        }
        webView.webViewClient = WebViewClient()
        webView.addJavascriptInterface(AndroidBridge(), "AndroidExpiry")
        webView.loadUrl("file:///android_asset/index.html")
        return webView
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(NOTIFICATION_SERVICE) as android.app.NotificationManager
            manager.createNotificationChannel(
                android.app.NotificationChannel(
                    NotificationScheduler.CHANNEL,
                    getString(R.string.notification_channel_name),
                    android.app.NotificationManager.IMPORTANCE_HIGH
                ).apply { description = getString(R.string.notification_channel_description) }
            )
        }
    }

    private fun requestNotificationPermissionInternal() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (Build.VERSION.SDK_INT >= 31) {
            val alarm = getSystemService(ALARM_SERVICE) as AlarmManager
            if (!alarm.canScheduleExactAlarms()) {
                runCatching {
                    startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
                }
            }
        }
    }

    inner class AndroidBridge {
        @JavascriptInterface
        fun syncItems(json: String) {
            NotificationScheduler.saveAndSchedule(this@MainActivity, json)
        }

        @JavascriptInterface
        fun cancelAll() {
            NotificationScheduler.cancelAll(this@MainActivity)
        }

        @JavascriptInterface
        fun requestNotificationPermission() {
            runOnUiThread { requestNotificationPermissionInternal() }
        }

        @JavascriptInterface
        fun setLanguage(language: String) {
            getSharedPreferences("ype_native_notifications", MODE_PRIVATE).edit().putString("language", language).apply()
        }

        @JavascriptInterface
        fun isNative(): Boolean = true
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
