package com.dahbi.musculation

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.app.Activity

class MainActivity : Activity() {
    private lateinit var page: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        page = WebView(this).apply {
            settings.javaScriptEnabled = false
            settings.domStorageEnabled = false
            settings.allowFileAccess = true
            settings.allowContentAccess = false
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
            setBackgroundColor(android.graphics.Color.rgb(16, 26, 24))
            loadUrl("file:///android_asset/index.html")
        }
        setContentView(page)

    }

    @Deprecated("Deprecated in Android, retained for compatibility without extra libraries")
    override fun onBackPressed() {
        if (::page.isInitialized && page.canGoBack()) page.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        if (::page.isInitialized) page.destroy()
        super.onDestroy()
    }
}
