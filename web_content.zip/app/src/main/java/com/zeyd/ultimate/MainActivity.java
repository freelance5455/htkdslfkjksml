package com.zeyd.ultimate;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.content.Intent;
import android.net.Uri;

public class MainActivity extends Activity {
    private WebView webView;

    private class BrowserBridge {
        @JavascriptInterface
        public void open(String url, String browser) {
            runOnUiThread(() -> openInBrowser(url, browser));
        }
    }

    private void openInBrowser(String url, String browser) {
        Uri uri = Uri.parse(url);
        String packageName = null;
        if ("chrome".equals(browser)) packageName = "com.android.chrome";
        else if ("firefox".equals(browser)) packageName = "org.mozilla.firefox";
        else if ("edge".equals(browser)) packageName = "com.microsoft.emmx";
        else if ("samsung".equals(browser)) packageName = "com.sec.android.app.sbrowser";
        else if ("brave".equals(browser)) packageName = "com.brave.browser";
        else if ("opera".equals(browser)) packageName = "com.opera.browser";

        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
        if (packageName != null) intent.setPackage(packageName);

        try {
            if ("default".equals(browser)) {
                startActivity(Intent.createChooser(new Intent(Intent.ACTION_VIEW, uri), "Choose your browser"));
            } else {
                startActivity(intent);
            }
        } catch (Exception e) {
            Intent chooser = Intent.createChooser(new Intent(Intent.ACTION_VIEW, uri), "Choose an installed browser");
            try { startActivity(chooser); } catch (Exception ignored) { }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        webView.setBackgroundColor(0xFF0B1020);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.addJavascriptInterface(new BrowserBridge(), "AndroidBrowser");
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme();
                if ("https".equalsIgnoreCase(scheme) || "http".equalsIgnoreCase(scheme)) {
                    openInBrowser(uri.toString(), "default");
                    return true;
                }
                return false;
            }
        });
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
