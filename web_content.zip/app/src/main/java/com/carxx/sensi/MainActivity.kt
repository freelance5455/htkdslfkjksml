package com.carxx.sensi

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Build
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient

class MainActivity : Activity() {
    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = false
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(DeviceInfoBridge(), "AndroidDeviceInfo")
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
    }

    inner class DeviceInfoBridge {
        @JavascriptInterface
        fun hasOverlayPermission(): Boolean = Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this@MainActivity)

        @JavascriptInterface
        fun requestOverlayPermission() {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this@MainActivity)) {
                runOnUiThread {
                    val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                    startActivity(intent)
                }
            }
        }

        @JavascriptInterface
        fun showCrosshair() {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this@MainActivity)) return
            startService(Intent(this@MainActivity, CrosshairService::class.java).setAction(CrosshairService.ACTION_SHOW))
        }

        @JavascriptInterface
        fun hideCrosshair() {
            startService(Intent(this@MainActivity, CrosshairService::class.java).setAction(CrosshairService.ACTION_HIDE))
        }

        @JavascriptInterface
        fun setCrosshairLocked(locked: Boolean) {
            startService(Intent(this@MainActivity, CrosshairService::class.java)
                .setAction(CrosshairService.ACTION_LOCK).putExtra(CrosshairService.EXTRA_LOCKED, locked))
        }

        @JavascriptInterface
        fun getDeviceModel(): String {
            val manufacturer = Build.MANUFACTURER.orEmpty().trim()
            val model = Build.MODEL.orEmpty().trim()
            return listOf(manufacturer, model).filter { it.isNotBlank() }
                .distinct().joinToString(" ").ifBlank { "Unknown Android device" }
        }

        @JavascriptInterface
        fun getModel(): String = getDeviceModel()

        @JavascriptInterface
        fun getDeviceDetails(): String {
            return "brand=${Build.BRAND};manufacturer=${Build.MANUFACTURER};model=${Build.MODEL};device=${Build.DEVICE};product=${Build.PRODUCT};android=${Build.VERSION.RELEASE}"
        }
    }

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        val webView = (window.decorView.rootView as? WebView)
        if (webView?.canGoBack() == true) webView.goBack() else super.onBackPressed()
    }
}
