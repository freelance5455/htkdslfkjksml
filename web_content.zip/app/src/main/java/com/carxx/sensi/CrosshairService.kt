package com.carxx.sensi

import android.app.Service
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager

class CrosshairService : Service() {
    companion object {
        const val ACTION_SHOW = "com.carxx.sensi.CROSSHAIR_SHOW"
        const val ACTION_HIDE = "com.carxx.sensi.CROSSHAIR_HIDE"
        const val ACTION_LOCK = "com.carxx.sensi.CROSSHAIR_LOCK"
        const val EXTRA_LOCKED = "locked"
    }

    private lateinit var windowManager: WindowManager
    private var crosshairView: CrosshairView? = null
    private var params: WindowManager.LayoutParams? = null
    private var locked = true

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val channelId = "carxx_crosshair_overlay"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, "Crosshair overlay", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val notification = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, channelId)
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentTitle("CARXX crosshair is active")
                .setContentText("Use CARXX SENSI to turn off or lock the crosshair")
                .setOngoing(true).build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this).setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentTitle("CARXX crosshair is active")
                .setContentText("Use CARXX SENSI to control the crosshair")
                .setOngoing(true).build()
        }
        startForeground(4107, notification)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_HIDE -> { removeCrosshair(); stopForeground(true); stopSelf() }
            ACTION_LOCK -> {
                locked = intent.getBooleanExtra(EXTRA_LOCKED, true)
                updateTouchMode()
            }
            else -> showCrosshair()
        }
        return START_NOT_STICKY
    }

    private fun showCrosshair() {
        if (crosshairView != null) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !android.provider.Settings.canDrawOverlays(this)) {
            stopSelf(); return
        }
        val view = CrosshairView()
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val p = WindowManager.LayoutParams(
            dp(64), dp(64), type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                if (locked) WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE else 0,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.TOP or Gravity.START
        p.x = (resources.displayMetrics.widthPixels - dp(64)) / 2
        p.y = (resources.displayMetrics.heightPixels - dp(64)) / 2
        view.onMoved = { x, y -> p.x = x; p.y = y; try { windowManager.updateViewLayout(view, p) } catch (_: Exception) {} }
        try {
            windowManager.addView(view, p)
            crosshairView = view
            params = p
        } catch (_: Exception) { stopSelf() }
    }

    private fun updateTouchMode() {
        val view = crosshairView ?: return
        val p = params ?: return
        p.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            if (locked) WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE else 0
        try { windowManager.updateViewLayout(view, p) } catch (_: Exception) {}
    }

    private fun removeCrosshair() {
        crosshairView?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        crosshairView = null; params = null
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    override fun onDestroy() { removeCrosshair(); stopForeground(true); super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null

    private inner class CrosshairView : View(this@CrosshairService) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.RED; strokeWidth = dp(2).toFloat(); style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
        var onMoved: ((Int, Int) -> Unit)? = null
        private var downX = 0f; private var downY = 0f; private var startX = 0; private var startY = 0
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val c = width / 2f; val r = dp(17).toFloat(); val gap = dp(5).toFloat(); val arm = dp(12).toFloat()
            canvas.drawLine(c, c-r-arm, c, c-r-gap, paint)
            canvas.drawLine(c, c+r+gap, c, c+r+arm, paint)
            canvas.drawLine(c-r-arm, c, c-r-gap, c, paint)
            canvas.drawLine(c+r+gap, c, c+r+arm, c, paint)
            paint.style = Paint.Style.FILL; canvas.drawCircle(c, c, dp(2).toFloat(), paint); paint.style = Paint.Style.STROKE
        }
        override fun onTouchEvent(event: MotionEvent): Boolean {
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { downX = event.rawX; downY = event.rawY; startX = params?.x ?: 0; startY = params?.y ?: 0; return true }
                MotionEvent.ACTION_MOVE -> { onMoved?.invoke(startX + (event.rawX-downX).toInt(), startY + (event.rawY-downY).toInt()); return true }
            }
            return true
        }
    }
}
