package com.mhc.cashbook;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import java.io.OutputStream;
import java.util.Base64;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> uploadCallback;
    private static final int FILE_PICKER = 1001;
    private static final int CAMERA = 1002;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new StorageBridge(), "AndroidStorage");
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (uploadCallback != null) uploadCallback.onReceiveValue(null);
                uploadCallback = cb;
                try {
                    Intent intent = params.createIntent();
                    startActivityForResult(intent, FILE_PICKER);
                } catch (Exception e) {
                    uploadCallback = null;
                    Toast.makeText(MainActivity.this, "Unable to open file picker", Toast.LENGTH_SHORT).show();
                    return false;
                }
                return true;
            }
        });
        if (android.os.Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.CAMERA}, CAMERA);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class StorageBridge {
        @JavascriptInterface
        public String saveBase64Image(String base64, String relativeFolder, String fileName) {
            try {
                if (android.os.Build.VERSION.SDK_INT < 29) return "";
                String safeFolder = relativeFolder == null ? "" : relativeFolder.replace("\\", "/").replaceAll("/+", "/");
                if (safeFolder.startsWith("/")) safeFolder = safeFolder.substring(1);
                if (!safeFolder.isEmpty() && !safeFolder.endsWith("/")) safeFolder += "/";
                if (!safeFolder.startsWith("Documents/MHC Cashbook/")) safeFolder = "Documents/MHC Cashbook/" + safeFolder;
                String safeName = (fileName == null || fileName.trim().isEmpty()) ? ("image_" + System.currentTimeMillis() + ".jpg") : fileName.replaceAll("[^A-Za-z0-9._-]", "_");
                String payload = base64 == null ? "" : base64;
                int comma = payload.indexOf(',');
                if (comma >= 0) payload = payload.substring(comma + 1);
                byte[] bytes = Base64.getDecoder().decode(payload);
                ContentValues values = new ContentValues();
                values.put(MediaStore.Files.FileColumns.DISPLAY_NAME, safeName);
                values.put(MediaStore.Files.FileColumns.MIME_TYPE, "image/jpeg");
                values.put(MediaStore.Files.FileColumns.RELATIVE_PATH, safeFolder);
                Uri uri = getContentResolver().insert(MediaStore.Files.getContentUri("external"), values);
                if (uri == null) return "";
                try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                    if (out == null) throw new Exception("Unable to open storage");
                    out.write(bytes);
                }
                return uri.toString();
            } catch (Exception e) {
                return "";
            }
        }

        @JavascriptInterface
        public String shareBase64File(String base64, String fileName, String message) {
            try {
                if (android.os.Build.VERSION.SDK_INT < 29) return "";
                String payload = base64 == null ? "" : base64;
                int comma = payload.indexOf(',');
                String mime = "application/pdf";
                if (comma >= 0) {
                    String header = payload.substring(0, comma).toLowerCase();
                    if (header.contains("image/")) mime = header.replace("data:", "").replace(";base64", "");
                    payload = payload.substring(comma + 1);
                }
                byte[] bytes = Base64.getDecoder().decode(payload);
                String safeName = (fileName == null || fileName.trim().isEmpty()) ? ("MHC_" + System.currentTimeMillis() + ".pdf") : fileName.replaceAll("[^A-Za-z0-9._-]", "_");
                ContentValues values = new ContentValues();
                values.put(MediaStore.Files.FileColumns.DISPLAY_NAME, safeName);
                values.put(MediaStore.Files.FileColumns.MIME_TYPE, mime);
                values.put(MediaStore.Files.FileColumns.RELATIVE_PATH, "Documents/MHC Cashbook/Shared/");
                values.put(MediaStore.Files.FileColumns.IS_PENDING, 1);
                Uri uri = getContentResolver().insert(MediaStore.Files.getContentUri("external"), values);
                if (uri == null) return "";
                try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                    if (out == null) throw new Exception("Unable to open share file");
                    out.write(bytes);
                }
                ContentValues done = new ContentValues();
                done.put(MediaStore.Files.FileColumns.IS_PENDING, 0);
                getContentResolver().update(uri, done, null, null);

                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType(mime);
                send.putExtra(Intent.EXTRA_STREAM, uri);
                send.putExtra(Intent.EXTRA_TEXT, message == null ? "" : message);
                send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try {
                    Intent wa = new Intent(send);
                    wa.setPackage("com.whatsapp");
                    startActivity(wa);
                } catch (Exception whatsappMissing) {
                    startActivity(Intent.createChooser(send, "Share with"));
                }
                return uri.toString();
            } catch (Exception e) {
                return "";
            }
        }

        @JavascriptInterface
        public boolean createFolderMarker(String relativeFolder) {
            try {
                if (android.os.Build.VERSION.SDK_INT < 29) return false;
                String safeFolder = relativeFolder == null ? "" : relativeFolder.replace("\\", "/").replaceAll("/+", "/");
                if (safeFolder.startsWith("/")) safeFolder = safeFolder.substring(1);
                if (!safeFolder.endsWith("/")) safeFolder += "/";
                if (!safeFolder.startsWith("Documents/MHC Cashbook/")) safeFolder = "Documents/MHC Cashbook/" + safeFolder;
                ContentValues values = new ContentValues();
                values.put(MediaStore.Files.FileColumns.DISPLAY_NAME, ".nomedia");
                values.put(MediaStore.Files.FileColumns.MIME_TYPE, "application/octet-stream");
                values.put(MediaStore.Files.FileColumns.RELATIVE_PATH, safeFolder);
                Uri uri = getContentResolver().insert(MediaStore.Files.getContentUri("external"), values);
                if (uri != null) { getContentResolver().delete(uri, null, null); return true; }
            } catch (Exception ignored) {}
            return false;
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_PICKER && uploadCallback != null) {
            Uri[] result = null;
            if (resultCode == RESULT_OK && data != null) {
                Uri uri = data.getData();
                if (uri != null) result = new Uri[]{uri};
                else if (data.getClipData() != null) {
                    int n = data.getClipData().getItemCount(); result = new Uri[n];
                    for (int i=0;i<n;i++) result[i] = data.getClipData().getItemAt(i).getUri();
                }
            }
            uploadCallback.onReceiveValue(result); uploadCallback = null;
        }
    }

    @Override public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
