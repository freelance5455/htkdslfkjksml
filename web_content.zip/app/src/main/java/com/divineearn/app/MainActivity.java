package com.divineearn.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;
import com.google.android.gms.ads.LoadAdError;

public class MainActivity extends Activity {
    private WebView webView;
    private RewardedAd rewardedAd;

    // Google's official Android rewarded test ad unit. Replace with YOUR production
    // rewarded ad unit ID only after testing is complete.
    private static final String REWARDED_AD_UNIT_ID =
            "ca-app-pub-7488584845894444/1410660258";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        MobileAds.initialize(this, status -> loadRewardedAd());

        webView = new WebView(this);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new AdBridge(), "DivineAds");
        webView.loadUrl("file:///android_asset/index.html");
        setContentView(webView);
    }

    private void loadRewardedAd() {
        AdRequest request = new AdRequest.Builder().build();
        RewardedAd.load(this, REWARDED_AD_UNIT_ID, request,
            new RewardedAdLoadCallback() {
                @Override public void onAdLoaded(RewardedAd ad) {
                    rewardedAd = ad;
                }
                @Override public void onAdFailedToLoad(LoadAdError error) {
                    rewardedAd = null;
                }
            });
    }

    private class AdBridge {
        @JavascriptInterface
        public void showRewardedAd() {
            runOnUiThread(() -> {
                if (rewardedAd == null) {
                    webView.evaluateJavascript(
                        "window.adResult(false,'Ad not ready yet. Please try again.')", null);
                    loadRewardedAd();
                    return;
                }
                RewardedAd ad = rewardedAd;
                rewardedAd = null;
                ad.setFullScreenContentCallback(new com.google.android.gms.ads.FullScreenContentCallback() {
                    @Override public void onAdDismissedFullScreenContent() {
                        loadRewardedAd();
                    }
                });
                ad.show(MainActivity.this, rewardItem ->
                    webView.evaluateJavascript(
                        "window.adResult(true," + rewardItem.getAmount() + ")", null));
            });
        }
    }
}
