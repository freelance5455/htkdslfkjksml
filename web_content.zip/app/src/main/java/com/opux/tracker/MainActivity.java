package com.opux.tracker;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.JsResult;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.Window;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int REQ_PICK = 1, REQ_SAVE = 2;
    private WebView webView;
    private ValueCallback<Uri[]> chooser;
    private byte[] pendingBytes;

    /** Exposed to JS as window.OpuxAndroid. WebView ignores blob: downloads, so export goes through the system file saver. */
    private class Bridge {
        @JavascriptInterface public void saveFile(String name, String text) {
            save(name, "application/json", text.getBytes(StandardCharsets.UTF_8));
        }
        @JavascriptInterface public void saveData(String name, String mime, String b64) {
            try { save(name, mime, android.util.Base64.decode(b64, android.util.Base64.DEFAULT)); } catch (Exception ignored) { }
        }
        @JavascriptInterface public void haptic() {
            runOnUiThread(new Runnable() { public void run() {
                if (webView != null) webView.performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP);
            }});
        }
        /** Copies text to the system clipboard (used by ChatGPT prompt workflows). */
        @JavascriptInterface public void copyText(final String text) {
            runOnUiThread(new Runnable() { public void run() {
                android.content.ClipboardManager cm = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                if (cm != null) cm.setPrimaryClip(android.content.ClipData.newPlainText("OPUX prompt", text));
            }});
        }
        /** Opens the system share sheet with plain text. */
        @JavascriptInterface public void shareText(final String text) {
            runOnUiThread(new Runnable() { public void run() {
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType("text/plain");
                send.putExtra(Intent.EXTRA_TEXT, text);
                try { startActivity(Intent.createChooser(send, "Share prompt")); } catch (Exception ignored) { }
            }});
        }
        /** Opens an https link outside the WebView (browser or the app that handles it). */
        @JavascriptInterface public void openUrl(final String url) {
            if (url == null || !url.startsWith("https://")) return;
            runOnUiThread(new Runnable() { public void run() {
                try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch (Exception ignored) { }
            }});
        }
        private void save(final String name, final String mime, byte[] bytes) {
            pendingBytes = bytes;
            runOnUiThread(new Runnable() { public void run() {
                Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType(mime == null || mime.isEmpty() ? "application/octet-stream" : mime);
                i.putExtra(Intent.EXTRA_TITLE, name);
                startActivityForResult(i, REQ_SAVE);
            }});
        }
    }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window w = getWindow();
        w.setStatusBarColor(0xFF080D18);
        w.setNavigationBarColor(0xFF101827);
        webView = new WebView(this);
        webView.setBackgroundColor(0xFF080D18);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        webView.addJavascriptInterface(new Bridge(), "OpuxAndroid");
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, android.webkit.WebResourceRequest r) {
                Uri u = r.getUrl();
                if ("file".equals(u.getScheme())) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) { }
                return true;
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            // OPUX 2.3: branded native dialogs. The default WebView dialog shows the page URL as its title.
            @Override public boolean onJsAlert(WebView view, String url, String message, final JsResult result) {
                new AlertDialog.Builder(MainActivity.this).setTitle("OPUX").setMessage(message)
                    .setPositiveButton("OK", new DialogInterface.OnClickListener() { public void onClick(DialogInterface d, int w) { result.confirm(); } })
                    .setOnCancelListener(new DialogInterface.OnCancelListener() { public void onCancel(DialogInterface d) { result.cancel(); } }).show();
                return true;
            }
            @Override public boolean onJsConfirm(WebView view, String url, String message, final JsResult result) {
                new AlertDialog.Builder(MainActivity.this).setTitle("OPUX").setMessage(message)
                    .setPositiveButton("OK", new DialogInterface.OnClickListener() { public void onClick(DialogInterface d, int w) { result.confirm(); } })
                    .setNegativeButton("Cancel", new DialogInterface.OnClickListener() { public void onClick(DialogInterface d, int w) { result.cancel(); } })
                    .setOnCancelListener(new DialogInterface.OnCancelListener() { public void onCancel(DialogInterface d) { result.cancel(); } }).show();
                return true;
            }
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (chooser != null) chooser.onReceiveValue(null);
                chooser = cb;
                try { startActivityForResult(p.createIntent(), REQ_PICK); }
                catch (Exception e) { chooser = null; return false; }
                return true;
            }
        });
        setContentView(webView);
        if (savedInstanceState == null) webView.loadUrl("file:///android_asset/index.html");
        else webView.restoreState(savedInstanceState);
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_PICK && chooser != null) {
            chooser.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
            chooser = null;
        } else if (req == REQ_SAVE) {
            boolean ok = false;
            if (res == RESULT_OK && data != null && data.getData() != null && pendingBytes != null) {
                try (OutputStream o = getContentResolver().openOutputStream(data.getData())) {
                    o.write(pendingBytes);
                    ok = true;
                } catch (Exception ignored) { }
            }
            pendingBytes = null;
            if (webView != null) webView.evaluateJavascript("opuxSaved(" + ok + ")", null);
        }
    }

    @Override protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (webView != null) webView.saveState(outState);
    }

    /** App-level Back: JS closes dialogs / pops nested pages; if it has nothing to handle (at Home), exit. */
    @Override public void onBackPressed() {
        if (webView == null) { finish(); return; }
        webView.evaluateJavascript("(window.opuxBack?opuxBack():false)", new ValueCallback<String>() {
            public void onReceiveValue(String v) { if (!"true".equals(v)) finish(); }
        });
    }

    @Override protected void onDestroy() {
        if (webView != null) { webView.destroy(); webView = null; }
        super.onDestroy();
    }
}
