package com.qxai.app;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.WindowManager;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private WebView web;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#070A14"));
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);

        web.addJavascriptInterface(new NetBridge(), "AndroidNet");
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onResume() { super.onResume(); web.onResume(); }

    @Override
    protected void onPause() { web.onPause(); super.onPause(); }

    @Override
    protected void onDestroy() { web.destroy(); super.onDestroy(); }

    /* Only lets the page request prices from Twelve Data. Nothing else. */
    private class NetBridge {
        @JavascriptInterface
        public void get(final int id, final String url) {
            if (url == null || !url.startsWith("https://api.twelvedata.com/")) {
                deliver(id, "{\"status\":\"error\",\"code\":400,\"message\":\"blocked\"}", 400);
                return;
            }
            new Thread(new Runnable() {
                @Override public void run() {
                    String body; int status = 0;
                    try {
                        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
                        c.setConnectTimeout(15000);
                        c.setReadTimeout(15000);
                        c.setRequestMethod("GET");
                        status = c.getResponseCode();
                        InputStream in = status >= 400 ? c.getErrorStream() : c.getInputStream();
                        StringBuilder sb = new StringBuilder();
                        if (in != null) {
                            BufferedReader r = new BufferedReader(new InputStreamReader(in, "UTF-8"));
                            String line;
                            while ((line = r.readLine()) != null) sb.append(line);
                            r.close();
                        }
                        body = sb.toString();
                        c.disconnect();
                    } catch (Exception e) {
                        body = "{\"status\":\"error\",\"code\":0,\"message\":\"network error\"}";
                    }
                    deliver(id, body, status);
                }
            }).start();
        }
    }

    private void deliver(final int id, final String body, final int status) {
        runOnUiThread(new Runnable() {
            @Override public void run() {
                web.evaluateJavascript("window.__netCb(" + id + "," + JSONObject.quote(body) + "," + status + ")", null);
            }
        });
    }
}
