package com.chickenclaxywar;
import android.app.Activity;import android.os.Bundle;import android.webkit.WebView;import android.webkit.WebSettings;import android.view.View;
public class MainActivity extends Activity { public void onCreate(Bundle b){super.onCreate(b);getWindow().getDecorView().setSystemUiVisibility(5894|1024|512);WebView w=new WebView(this);WebSettings s=w.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);w.setOverScrollMode(View.OVER_SCROLL_NEVER);setContentView(w);w.loadUrl("file:///android_asset/index.html");}}
