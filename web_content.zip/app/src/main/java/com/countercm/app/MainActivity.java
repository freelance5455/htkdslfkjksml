package com.countercm.app;

import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    EditText baikSekarang, baikSebelumnya, jelekSekarang, jelekSebelumnya;
    TextView hasilBaik, hasilJelek, hasilTotal, persenBaik, persenJelek;

    int bg = Color.rgb(5, 19, 31);
    int card = Color.rgb(13, 35, 54);
    int green = Color.rgb(45, 225, 125);
    int red = Color.rgb(255, 90, 90);
    int blue = Color.rgb(25, 145, 245);
    int white = Color.WHITE;
    int muted = Color.rgb(165, 185, 205);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUI();
    }

    TextView tv(String text, float size, int color) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);
        return t;
    }

    LinearLayout cardLayout() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(24, 20, 24, 20);
        GradientDrawableCompat.background(l, card, 22);
        return l;
    }

    EditText input(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(Color.rgb(100,130,155));
        e.setTextColor(white);
        e.setTextSize(16);
        e.setSingleLine(true);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        e.setPadding(18, 0, 18, 0);
        GradientDrawableCompat.background(e, Color.rgb(18, 34, 49), 14);
        return e;
    }

    LinearLayout row(String label, EditText input) {
        LinearLayout r = new LinearLayout(this);
        r.setGravity(Gravity.CENTER_VERTICAL);
        TextView l = tv(label, 15, white);
        r.addView(l, new LinearLayout.LayoutParams(0, 58, 1));
        r.addView(input, new LinearLayout.LayoutParams(dp(145), 58));
        r.setPadding(0, 5, 0, 5);
        return r;
    }

    void addResultRow(LinearLayout parent, String label, TextView value) {
        LinearLayout r = new LinearLayout(this);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.addView(tv(label, 15, white), new LinearLayout.LayoutParams(0, 48, 1));
        value.setGravity(Gravity.CENTER_VERTICAL | Gravity.RIGHT);
        value.setTextSize(17);
        r.addView(value, new LinearLayout.LayoutParams(dp(130), 48));
        parent.addView(r);
    }

    void buildUI() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(bg);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(20, 18, 20, 28);

        LinearLayout title = new LinearLayout(this);
        title.setGravity(Gravity.CENTER_VERTICAL);
        TextView icon = tv("▮▮▮", 26, blue);
        title.addView(icon, new LinearLayout.LayoutParams(dp(60), 70));
        LinearLayout titleText = new LinearLayout(this);
        titleText.setOrientation(LinearLayout.VERTICAL);
        titleText.addView(tv("Counter CM", 28, white), new LinearLayout.LayoutParams(-1, 38));
        titleText.addView(tv("Hitung hasil dan persentase dengan mudah", 13, muted), new LinearLayout.LayoutParams(-1, 28));
        title.addView(titleText, new LinearLayout.LayoutParams(0, 70, 1));
        root.addView(title);

        // Data Baik
        LinearLayout good = cardLayout();
        TextView gh = tv("👍  Data Baik", 20, green);
        gh.setTypeface(null, 1);
        good.addView(gh, new LinearLayout.LayoutParams(-1, 34));
        good.addView(tv("Masukkan jumlah data baik", 13, muted));
        baikSekarang = input("Masukkan angka");
        baikSebelumnya = input("Masukkan angka");
        good.addView(row("Baik Sekarang", baikSekarang));
        good.addView(row("Baik Sebelumnya", baikSebelumnya));
        root.addView(good, new LinearLayout.LayoutParams(-1, -2));

        Space sp1 = new Space(this);
        root.addView(sp1, new LinearLayout.LayoutParams(1, 12));

        // Data Jelek
        LinearLayout bad = cardLayout();
        TextView bh = tv("👎  Data Jelek", 20, red);
        bh.setTypeface(null, 1);
        bad.addView(bh, new LinearLayout.LayoutParams(-1, 34));
        bad.addView(tv("Masukkan jumlah data jelek", 13, muted));
        jelekSekarang = input("Masukkan angka");
        jelekSebelumnya = input("Masukkan angka");
        bad.addView(row("Jelek Sekarang", jelekSekarang));
        bad.addView(row("Jelek Sebelumnya", jelekSebelumnya));
        root.addView(bad, new LinearLayout.LayoutParams(-1, -2));

        Space sp2 = new Space(this);
        root.addView(sp2, new LinearLayout.LayoutParams(1, 16));

        Button jumlah = new Button(this);
        jumlah.setText("▣  JUMLAH");
        jumlah.setTextSize(17);
        jumlah.setTextColor(white);
        jumlah.setAllCaps(false);
        jumlah.setBackground(GradientDrawableCompat.drawable(blue, 18));
        jumlah.setOnClickListener(v -> calculate());
        root.addView(jumlah, new LinearLayout.LayoutParams(-1, 62));

        Space sp3 = new Space(this);
        root.addView(sp3, new LinearLayout.LayoutParams(1, 16));

        // Results
        LinearLayout result = cardLayout();
        TextView rh = tv("◔  Hasil Perhitungan", 19, Color.rgb(80, 210, 250));
        rh.setTypeface(null, 1);
        result.addView(rh, new LinearLayout.LayoutParams(-1, 38));

        hasilBaik = tv("-", 17, green);
        hasilJelek = tv("-", 17, red);
        hasilTotal = tv("-", 17, white);
        persenBaik = tv("-", 17, green);
        persenJelek = tv("-", 17, red);

        addResultRow(result, "Hasil Baik", hasilBaik);
        addResultRow(result, "Hasil Jelek", hasilJelek);
        addResultRow(result, "Hasil", hasilTotal);
        View divider = new View(this);
        divider.setBackgroundColor(Color.rgb(60, 105, 135));
        result.addView(divider, new LinearLayout.LayoutParams(-1, 1));
        addResultRow(result, "Persentase Baik", persenBaik);
        addResultRow(result, "Persentase Jelek", persenJelek);
        root.addView(result, new LinearLayout.LayoutParams(-1, -2));

        Space sp4 = new Space(this);
        root.addView(sp4, new LinearLayout.LayoutParams(1, 14));

        Button reset = new Button(this);
        reset.setText("↻  RESET");
        reset.setTextSize(16);
        reset.setTextColor(white);
        reset.setAllCaps(false);
        reset.setBackground(GradientDrawableCompat.drawable(Color.rgb(90, 112, 138), 18));
        reset.setOnClickListener(v -> reset());
        root.addView(reset, new LinearLayout.LayoutParams(-1, 58));

        scroll.addView(root);
        setContentView(scroll);
    }

    void calculate() {
        Double bs = number(baikSekarang);
        Double bb = number(baikSebelumnya);
        Double js = number(jelekSekarang);
        Double jb = number(jelekSebelumnya);

        if (bs == null || bb == null || js == null || jb == null) {
            Toast.makeText(this, "Lengkapi semua data terlebih dahulu.", Toast.LENGTH_SHORT).show();
            return;
        }

        double cb = bs - bb;
        double cj = js - jb;
        double total = cb + cj;

        hasilBaik.setText(formatNumber(cb));
        hasilJelek.setText(formatNumber(cj));
        hasilTotal.setText(formatNumber(total));

        if (Math.abs(total) < 1e-12) {
            persenBaik.setText("0,00%");
            persenJelek.setText("0,00%");
        } else {
            persenBaik.setText(formatPercent(cb / total * 100));
            persenJelek.setText(formatPercent(cj / total * 100));
        }
    }

    Double number(EditText e) {
        try {
            String s = e.getText().toString().trim().replace(",", ".");
            if (s.isEmpty()) return null;
            return Double.parseDouble(s);
        } catch (Exception ex) {
            return null;
        }
    }

    String formatNumber(double n) {
        if (Math.abs(n - Math.rint(n)) < 1e-9)
            return String.format(Locale.US, "%.0f", n);
        return String.format(Locale.US, "%.2f", n).replace(".", ",");
    }

    String formatPercent(double n) {
        return String.format(Locale.US, "%.2f%%", n).replace(".", ",");
    }

    void reset() {
        baikSekarang.setText("");
        baikSebelumnya.setText("");
        jelekSekarang.setText("");
        jelekSebelumnya.setText("");
        hasilBaik.setText("-");
        hasilJelek.setText("-");
        hasilTotal.setText("-");
        persenBaik.setText("-");
        persenJelek.setText("-");
    }

    int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    static class GradientDrawableCompat {
        static android.graphics.drawable.GradientDrawable drawable(int color, float radius) {
            android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable();
            d.setColor(color);
            d.setCornerRadius(radius);
            return d;
        }
        static void background(View v, int color, float radius) {
            v.setBackground(drawable(color, radius));
        }
    }
}
