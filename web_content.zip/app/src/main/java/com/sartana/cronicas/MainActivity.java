package com.sartana.cronicas;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.webkit.JavascriptInterface;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.net.Uri;
import android.content.Intent;
import android.provider.OpenableColumns;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.util.Base64;
import java.io.*;
import java.net.*;
import java.util.concurrent.*;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private WebView web;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private static final int PICK_IMAGE = 501;
    private android.webkit.ValueCallback<Uri[]> fileCallback;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        web = new WebView(this);
        setContentView(web);
        WebSettings st = web.getSettings();
        st.setJavaScriptEnabled(true);
        st.setDomStorageEnabled(true);
        st.setAllowFileAccess(true);
        st.setAllowContentAccess(true);
        st.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView v, android.webkit.ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = cb;
                Intent i = params.createIntent();
                try { startActivityForResult(i, PICK_IMAGE); }
                catch(Exception e) { fileCallback = null; return false; }
                return true;
            }
        });
        web.addJavascriptInterface(new XaiBridge(), "NativeXai");
        web.loadUrl("file:///android_asset/index.html");
    }

    private class XaiBridge {
        @JavascriptInterface public void request(String id, String path, String body, String apiKey) {
            executor.execute(() -> {
                String result;
                try {
                    URL url = new URL("https://api.x.ai/v1/" + path);
                    HttpURLConnection c = (HttpURLConnection)url.openConnection();
                    c.setRequestMethod("POST");
                    c.setConnectTimeout(30000); c.setReadTimeout(180000);
                    c.setRequestProperty("Authorization", "Bearer " + apiKey);
                    c.setRequestProperty("Content-Type", "application/json");
                    c.setDoOutput(true);
                    try(OutputStream os=c.getOutputStream()){os.write(body.getBytes("UTF-8"));}
                    int code=c.getResponseCode();
                    InputStream is=(code>=200 && code<300)?c.getInputStream():c.getErrorStream();
                    ByteArrayOutputStream out=new ByteArrayOutputStream();
                    byte[] buf=new byte[8192]; int n;
                    while((n=is.read(buf))!=-1) out.write(buf,0,n);
                    JSONObject response=new JSONObject();
                    response.put("ok", code>=200 && code<300);
                    response.put("status",code);
                    response.put("body",new String(out.toByteArray(),"UTF-8"));
                    result=response.toString();
                    c.disconnect();
                } catch(Exception e) {
                    try { JSONObject x=new JSONObject(); x.put("ok",false); x.put("status",0); x.put("body",new JSONObject().put("error",new JSONObject().put("message",e.toString())).toString()); result=x.toString(); }
                    catch(Exception ignored){result="{\"ok\":false,\"status\":0,\"body\":\"network error\"}";}
                }
                final String js = "window.__xaiResolve(" + JSONObject.quote(id) + "," + JSONObject.quote(result) + ");";
                runOnUiThread(() -> web.evaluateJavascript(js, null));
            });
        }
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req,res,data);
        if(req==PICK_IMAGE && fileCallback!=null) {
            Uri[] results=null;
            if(res==RESULT_OK && data!=null) {
                Uri u=data.getData();
                if(u!=null) results=new Uri[]{u};
            }
            fileCallback.onReceiveValue(results); fileCallback=null;
        }
    }
    @Override public void onBackPressed() {
        if(web!=null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
    @Override protected void onDestroy() { executor.shutdownNow(); if(web!=null) web.destroy(); super.onDestroy(); }
}
