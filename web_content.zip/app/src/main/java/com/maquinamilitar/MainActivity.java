package com.maquinamilitar;

import android.app.*;import android.os.*;import android.webkit.*;import android.view.*;import android.graphics.Color;import android.content.*;import android.content.pm.PackageManager;import org.json.*;

public class MainActivity extends Activity {
    WebView web; static final String PREF="MM_NATIVE";
    @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(Color.rgb(255,106,0)); web=new WebView(this); web.getSettings().setJavaScriptEnabled(true); web.getSettings().setDomStorageEnabled(true); web.setBackgroundColor(Color.BLACK); web.addJavascriptInterface(new NativeBridge(this,web),"AndroidMM"); web.loadUrl("file:///android_asset/index.html"); setContentView(web); AlarmEngine.init(this); AlarmEngine.ensureChannels(this); if(Build.VERSION.SDK_INT>=33&&checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},33); AlarmEngine.reconcile(this);}
    @Override protected void onResume(){super.onResume();AlarmEngine.reconcile(this);}
}
