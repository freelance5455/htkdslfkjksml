package com.maquinamilitar;

import android.content.*;import android.os.*;import android.webkit.WebView;import org.json.*;

public class NativeBridge {
 private final Context c; private final WebView w; public NativeBridge(Context c,WebView w){this.c=c.getApplicationContext();this.w=w;}
 private void persist(JSONObject x){c.getSharedPreferences(MainActivity.PREF,0).edit().putString("state",x.toString()).apply();}
 @android.webkit.JavascriptInterface public String setEnabled(String s){try{JSONObject x=new JSONObject(s);persist(x);AlarmEngine.reconcile(c);return "OK";}catch(Exception e){return "FAILED: "+e.getMessage();}}
 @android.webkit.JavascriptInterface public String setCategory(String s){try{JSONObject x=new JSONObject(s);JSONObject st=x.optJSONObject("state");if(st!=null)persist(st);AlarmEngine.reconcile(c);return "OK";}catch(Exception e){return "FAILED: "+e.getMessage();}}
 @android.webkit.JavascriptInterface public String saveState(String s){try{persist(new JSONObject(s));return "OK";}catch(Exception e){return "FAILED: "+e.getMessage();}}
 @android.webkit.JavascriptInterface public String restoreState(String s){return saveState(s);}
 @android.webkit.JavascriptInterface public String syncSchedule(String s){try{JSONObject x=new JSONObject(s);persistStateFromSchedule(x);AlarmEngine.reconcile(c);return "native scheduled";}catch(Exception e){return "FAILED: "+e.getMessage();}}
 private void persistStateFromSchedule(JSONObject x){try{SharedPreferences p=c.getSharedPreferences(MainActivity.PREF,0);String old=p.getString("state","{}");JSONObject st=new JSONObject(old);if(x.has("permanent"))st.put("permanent",x.getString("permanent"));if(x.has("temporary"))st.put("temporary",x.isNull("temporary")?JSONObject.NULL:x.getString("temporary"));if(x.has("tempActivatedAt"))st.put("tempActivatedAt",x.isNull("tempActivatedAt")?JSONObject.NULL:x.getString("tempActivatedAt"));st.put("enabled",x.optBoolean("enabled",true));persist(st);}catch(Exception ignored){}}
 @android.webkit.JavascriptInterface public String scheduleOne(String s){try{JSONObject x=new JSONObject(s);AlarmEngine.scheduleOne(c,x);return "programado";}catch(Exception e){return "FAILED: "+e.getMessage();}}
 @android.webkit.JavascriptInterface public String getDiagnostics(){return AlarmEngine.diagnostics(c).toString();}
 @android.webkit.JavascriptInterface public String explanationEnded(String s){return "OK";}
 @android.webkit.JavascriptInterface public String eventDecision(String s){return "OK";}
 @android.webkit.JavascriptInterface public String setUiReady(String s){return "OK";}
}
