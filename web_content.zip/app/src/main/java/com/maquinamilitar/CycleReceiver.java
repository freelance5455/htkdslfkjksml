package com.maquinamilitar;import android.content.*;public class CycleReceiver extends BroadcastReceiver{public void onReceive(Context c,Intent i){AlarmEngine.reconcile(c);}}
