package com.titan.v8;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends AppCompatActivity {
    private WebView webView; private TextToSpeech tts; private final ExecutorService exec=Executors.newSingleThreadExecutor();
    private static final int MIC_REQUEST=901, VOICE_REQUEST=902;

    @Override protected void onCreate(@Nullable Bundle b){
        super.onCreate(b); setContentView(R.layout.activity_main); webView=findViewById(R.id.webview);
        WebSettings s=webView.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); s.setAllowContentAccess(true);
        webView.setWebViewClient(new WebViewClient()); webView.addJavascriptInterface(new Bridge(),"TitanAndroid"); webView.loadUrl("file:///android_asset/index.html");
        tts=new TextToSpeech(this,status->{if(status==TextToSpeech.SUCCESS){tts.setLanguage(Locale.US);tts.setPitch(.72f);tts.setSpeechRate(1.02f);}});
    }
    public class Bridge {
        @JavascriptInterface public String listApps(){
            try{
                Intent i=new Intent(Intent.ACTION_MAIN,null); i.addCategory(Intent.CATEGORY_LAUNCHER);
                List<android.content.pm.ResolveInfo> list=getPackageManager().queryIntentActivities(i,PackageManager.MATCH_ALL);
                list.sort((a,b)->a.loadLabel(getPackageManager()).toString().compareToIgnoreCase(b.loadLabel(getPackageManager()).toString()));
                JSONArray out=new JSONArray(); for(android.content.pm.ResolveInfo r:list){JSONObject o=new JSONObject();o.put("name",r.loadLabel(getPackageManager()).toString());o.put("package",r.activityInfo.packageName);out.put(o);} return out.toString();
            }catch(Exception e){return "[]";}
        }
        @JavascriptInterface public boolean launchApp(String pkg){try{Intent i=getPackageManager().getLaunchIntentForPackage(pkg);if(i==null)return false;i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(i);return true;}catch(Exception e){return false;}}
        @JavascriptInterface public void speak(String text){if(tts!=null)tts.speak(text,TextToSpeech.QUEUE_FLUSH,null,"TITAN");}
        @JavascriptInterface public void requestMic(){if(ContextCompat.checkSelfPermission(MainActivity.this,Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED)ActivityCompat.requestPermissions(MainActivity.this,new String[]{Manifest.permission.RECORD_AUDIO},MIC_REQUEST);else startVoice();}
        @JavascriptInterface public void wiki(String q){final String query=q==null?"":q.trim();if(query.isEmpty())return;exec.execute(()->{String r=fetchWiki(query);String js="window.receiveWiki("+JSONObject.quote(r)+");";runOnUiThread(()->webView.evaluateJavascript(js,null));});}
    }
    private void startVoice(){try{Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,Locale.getDefault());startActivityForResult(i,VOICE_REQUEST);}catch(Exception ignored){}}
    private String fetchWiki(String q){HttpURLConnection c=null;try{
        String enc=URLEncoder.encode(q,"UTF-8").replace("+","%20"); URL u=new URL("https://en.wikipedia.org/w/rest.php/v1/search/page?q="+enc+"&limit=1"); c=(HttpURLConnection)u.openConnection();c.setConnectTimeout(8000);c.setReadTimeout(8000);c.setRequestProperty("Accept","application/json");
        if(c.getResponseCode()!=200)return "Wikipedia could not be reached right now, sir."; JSONObject s=new JSONObject(read(c.getInputStream())); JSONArray p=s.optJSONArray("pages"); if(p==null||p.length()==0)return "No matching Wikipedia article was found, sir."; String title=p.getJSONObject(0).optString("key",p.getJSONObject(0).optString("title",q)); c.disconnect();
        String et=URLEncoder.encode(title,"UTF-8").replace("+","%20"); u=new URL("https://en.wikipedia.org/api/rest_v1/page/summary/"+et); c=(HttpURLConnection)u.openConnection();c.setConnectTimeout(8000);c.setReadTimeout(8000);c.setRequestProperty("Accept","application/json"); if(c.getResponseCode()!=200)return "Wikipedia found the topic but could not load its summary, sir."; JSONObject d=new JSONObject(read(c.getInputStream())); String ex=d.optString("extract",""); return ex.isEmpty()?"Wikipedia returned no summary, sir.":ex+"\n\nSource: Wikipedia, sir.";
    }catch(Exception e){return "Wikipedia is unavailable right now. Check your internet connection, sir.";}finally{if(c!=null)c.disconnect();}}
    private String read(InputStream in)throws Exception{BufferedReader r=new BufferedReader(new InputStreamReader(in));StringBuilder s=new StringBuilder();String l;while((l=r.readLine())!=null)s.append(l);r.close();return s.toString();}
    @Override protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data);if(req==VOICE_REQUEST&&res==Activity.RESULT_OK&&data!=null){ArrayList<String> m=data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);if(m!=null&&!m.isEmpty())webView.evaluateJavascript("window.receiveVoice("+JSONObject.quote(m.get(0))+");",null);}}
    @Override public void onRequestPermissionsResult(int req,String[] p,int[] g){super.onRequestPermissionsResult(req,p,g);if(req==MIC_REQUEST&&g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED){webView.evaluateJavascript("window.onMicGranted();",null);startVoice();}}
    @Override protected void onDestroy(){if(tts!=null)tts.shutdown();exec.shutdownNow();super.onDestroy();}
}
