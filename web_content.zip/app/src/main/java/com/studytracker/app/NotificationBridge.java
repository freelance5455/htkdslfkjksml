package com.studytracker.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.webkit.JavascriptInterface;

public class NotificationBridge {
    private final Context context;
    private static final String PREF="study_tracker_native";

    public NotificationBridge(Context c){ context=c.getApplicationContext(); }

    @JavascriptInterface
    public void syncState(String json){
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .edit().putString("state", json).apply();
        NotificationScheduler.scheduleFromState(context, json);
    }

    public static String getState(Context c){
        return c.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .getString("state", null);
    }
}
