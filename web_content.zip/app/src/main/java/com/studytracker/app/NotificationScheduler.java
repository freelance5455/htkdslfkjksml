package com.studytracker.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import java.util.*;
import org.json.*;

public class NotificationScheduler {
    static final int BASE=42000;

    public static void scheduleFromState(Context c, String json){
        cancelAll(c);
        if(json==null || json.trim().isEmpty()) return;
        try{
            JSONObject state=new JSONObject(json);
            JSONArray recurring=state.optJSONArray("recurring");
            JSONObject overrides=state.optJSONObject("overrides");
            Calendar now=Calendar.getInstance();
            for(int d=0; d<60; d++){
                Calendar day=(Calendar)now.clone();
                day.add(Calendar.DAY_OF_YEAR,d);
                String date=String.format(Locale.US,"%04d-%02d-%02d",
                    day.get(Calendar.YEAR),day.get(Calendar.MONTH)+1,day.get(Calendar.DAY_OF_MONTH));

                if(recurring!=null){
                    for(int i=0;i<recurring.length();i++){
                        JSONObject a=recurring.optJSONObject(i);
                        if(a==null) continue;
                        if(a.optBoolean("systemSleep",false)) continue;
                        JSONArray days=a.optJSONArray("days");
                        if(days!=null && containsDay(days, day.get(Calendar.DAY_OF_WEEK)-1))
                            scheduleActivity(c,a,date,BASE+i*10000+d*10);
                    }
                }
                if(overrides!=null){
                    JSONArray arr=overrides.optJSONArray(date);
                    if(arr!=null){
                        for(int i=0;i<arr.length();i++){
                            JSONObject o=arr.optJSONObject(i);
                            if(o==null) continue;
                            if("delete".equals(o.optString("action"))) continue;
                            JSONObject a=o.optJSONObject("activity");
                            if(a!=null) scheduleActivity(c,a,date,BASE+500000+i*10000+d*10);
                        }
                    }
                }
            }
        }catch(Exception ignored){}
    }

    static boolean containsDay(JSONArray ar,int day){
        for(int i=0;i<ar.length();i++) if(ar.optInt(i,-99)==day) return true;
        return false;
    }

    static void scheduleActivity(Context c, JSONObject a, String date, int seed){
        try{
            String start=a.optString("start","");
            String end=a.optString("end","");
            if(start.length()<4 || end.length()<4) return;
            int sm=minutes(start), em=minutes(end);
            Calendar base=Calendar.getInstance();
            String[] p=date.split("-");
            base.set(Integer.parseInt(p[0]),Integer.parseInt(p[1])-1,Integer.parseInt(p[2]),sm/60,sm%60,0);
            base.set(Calendar.MILLISECOND,0);

            // Four local reminders: 15 min before, start, attendance window closing, end.
            add(c,base.getTimeInMillis()-15*60*1000,seed,
                "Upcoming: "+label(a), "Starts in 15 minutes.");
            add(c,base.getTimeInMillis(),seed+1,
                "Started: "+label(a), "Mark Present or Absent.");
            add(c,base.getTimeInMillis()+10*60*1000,seed+2,
                "Attendance window closing", label(a)+" attendance is now locking.");
            Calendar finish=(Calendar)base.clone();
            finish.set(Calendar.HOUR_OF_DAY,em/60); finish.set(Calendar.MINUTE,em%60);
            add(c,finish.getTimeInMillis(),seed+3,
                "Finished: "+label(a), "Your planned activity time has ended.");
        }catch(Exception ignored){}
    }

    static int minutes(String s){
        String[] p=s.split(":");
        return Integer.parseInt(p[0])*60+Integer.parseInt(p[1]);
    }
    static String label(JSONObject a){
        String sub=a.optString("subject","Activity");
        String type=a.optString("type","");
        return type.isEmpty()?sub:type+" · "+sub;
    }

    static void add(Context c,long when,int id,String title,String text){
        if(when<=System.currentTimeMillis()) return;
        AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        Intent i=new Intent(c,NotificationReceiver.class);
        i.putExtra("title",title); i.putExtra("text",text);
        PendingIntent pi=PendingIntent.getBroadcast(c,idSafe(id),i,
            PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        if(Build.VERSION.SDK_INT>=31 && !am.canScheduleExactAlarms()){
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pi);
        }else if(Build.VERSION.SDK_INT>=23){
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pi);
        }else{
            am.setExact(AlarmManager.RTC_WAKEUP,when,pi);
        }
    }

    static int idSafe(int x){ return Math.abs(x%1000000000); }

    static void cancelAll(Context c){
        AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        for(int id=BASE;id<BASE+900000;id+=1){
            // no-op: exact IDs are sparse and we cannot enumerate PendingIntents cheaply
        }
        // Existing notifications naturally expire; new schedules use unique IDs.
    }
}
