package com.studytracker.app;

import android.content.*;

public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent in){
        String s=NotificationBridge.getState(c);
        if(s!=null) NotificationScheduler.scheduleFromState(c,s);
    }
}
