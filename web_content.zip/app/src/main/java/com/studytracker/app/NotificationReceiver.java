package com.studytracker.app;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.*;
import android.os.Build;
import androidx.core.app.NotificationCompat;

public class NotificationReceiver extends BroadcastReceiver {
    static final String CH="study_tracker_activity";

    @Override public void onReceive(Context c, Intent in){
        String title=in.getStringExtra("title");
        String text=in.getStringExtra("text");
        NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel ch=new NotificationChannel(CH,"Study Tracker reminders",
                NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription("Timetable and attendance reminders");
            nm.createNotificationChannel(ch);
        }
        Intent launch=c.getPackageManager().getLaunchIntentForPackage(c.getPackageName());
        PendingIntent pi=null;
        if(launch!=null) pi=PendingIntent.getActivity(c,1,launch,
            PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        NotificationCompat.Builder b=new NotificationCompat.Builder(c,CH)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle(title==null?"Study Tracker":title)
            .setContentText(text==null?"Reminder":text)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true);
        if(pi!=null)b.setContentIntent(pi);
        nm.notify((int)(System.currentTimeMillis()%1000000),b.build());
    }
}
