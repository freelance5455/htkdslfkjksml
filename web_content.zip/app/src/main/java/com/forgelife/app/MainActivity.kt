package com.forgelife.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.lifecycleScope
import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : androidx.activity.ComponentActivity() {
    private lateinit var web: WebView
    @Volatile private var engine: Engine? = null
    @Volatile private var conversation: com.google.ai.edge.litertlm.Conversation? = null

    private val modelPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) importAndLoadModel(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        web.webViewClient = WebViewClient()
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(ForgeBridge(), "ForgeNativeAI")
        setContentView(web)
        web.loadUrl("file:///android_asset/www/index.html")
        // First launch downloads the model once into private app storage. After that,
        // startup is fully offline and loads the cached local model.
        val model = File(filesDir, MODEL_FILE)
        if (model.exists() && model.length() >= MODEL_MIN_BYTES) {
            loadModel(model)
        } else {
            downloadAndLoadModel()
        }
    }

    companion object {
        private const val MODEL_FILE = "forge_model.litertlm"
        private const val MODEL_MIN_BYTES = 300_000_000L
        private const val MODEL_URL = "https://huggingface.co/litert-community/Qwen3-0.6B-int4/resolve/main/qwen3_0.6b_nothink_q4_block32_ekv1280.litertlm"
    }

    private fun downloadAndLoadModel() {
        lifecycleScope.launch(Dispatchers.IO) {
            val target = File(filesDir, MODEL_FILE)
            val temp = File(filesDir, "$MODEL_FILE.part")
            try {
                callback("model_progress", "Forge AI model download starting…", "")
                val connection = (java.net.URL(MODEL_URL).openConnection() as java.net.HttpURLConnection).apply {
                    connectTimeout = 30000
                    readTimeout = 120000
                    instanceFollowRedirects = true
                    setRequestProperty("User-Agent", "ForgeLife/2.9 Android")
                }
                try {
                    connection.connect()
                    check(connection.responseCode in 200..299) { "Model download failed: HTTP ${connection.responseCode}" }
                    val expected = connection.contentLengthLong
                    connection.inputStream.use { input ->
                        temp.outputStream().buffered().use { output ->
                            val buffer = ByteArray(1024 * 1024)
                            var total = 0L
                            var lastUpdate = 0L
                            while (true) {
                                val count = input.read(buffer)
                                if (count < 0) break
                                output.write(buffer, 0, count)
                                total += count
                                if (total - lastUpdate >= 5L * 1024 * 1024) {
                                    val pct = if (expected > 0) (total * 100 / expected).toInt() else -1
                                    callback("model_progress", if (pct >= 0) "Downloading Forge AI model… $pct%" else "Downloading Forge AI model… ${(total / 1_000_000)} MB", "")
                                    lastUpdate = total
                                }
                            }
                        }
                    }
                    check(temp.length() >= MODEL_MIN_BYTES) { "Downloaded model is incomplete (${temp.length()} bytes). Please retry." }
                    if (target.exists()) target.delete()
                    check(temp.renameTo(target)) { "Could not save downloaded model" }
                    callback("model_progress", "Download complete. Initializing Forge AI…", "")
                    loadModel(target)
                } finally { connection.disconnect() }
            } catch (e: Exception) {
                temp.delete()
                callback("model_setup", "", "Forge AI model download failed: ${e.message ?: "network error"}. Connect to the internet and reopen ForgeLife to retry, or import a compatible .litertlm file.")
            }
        }
    }

    inner class ForgeBridge {
        @JavascriptInterface fun isReady(): Boolean = engine != null && conversation != null
        @JavascriptInterface fun selectModel() { runOnUiThread { modelPicker.launch(arrayOf("*/*")) } }
        @JavascriptInterface fun sendMessage(id: String, prompt: String) {
            val conv = conversation
            if (conv == null) { callback(id, "", "No local model loaded. Choose a compatible .litertlm model first."); return }
            lifecycleScope.launch {
                try {
                    val output = StringBuilder()
                    conv.sendMessageAsync(prompt).collect { message -> output.append(message.text) }
                    callback(id, output.toString(), "")
                } catch (e: Exception) { callback(id, "", e.message ?: "Local inference failed") }
            }
        }
    }

    private fun importAndLoadModel(uri: Uri) {
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val dest = File(filesDir, MODEL_FILE)
                contentResolver.openInputStream(uri).use { input ->
                    requireNotNull(input) { "Cannot read selected file" }.use { src -> dest.outputStream().use { dst -> src.copyTo(dst) } }
                }
                withContext(Dispatchers.Main) { Toast.makeText(this@MainActivity, "Model copied. Loading locally…", Toast.LENGTH_LONG).show() }
                loadModel(dest)
            } catch (e: Exception) { callback("model_setup", "", e.message ?: "Could not import model") }
        }
    }

    private fun loadModel(file: File) {
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                // Close resources in dependency order before replacing the active model.
                try { conversation?.close() } catch (_: Exception) {}
                conversation = null
                try { engine?.close() } catch (_: Exception) {}
                engine = null

                val newEngine = Engine(EngineConfig(modelPath = file.absolutePath, backend = Backend.CPU()))
                try {
                    newEngine.initialize()
                    val newConversation = newEngine.createConversation()
                    engine = newEngine
                    conversation = newConversation
                    callback("model_setup", "Local AI model loaded successfully.", "")
                } catch (e: Exception) {
                    try { newEngine.close() } catch (_: Exception) {}
                    throw e
                }
            } catch (e: Exception) { callback("model_setup", "", "Model load failed: ${e.message ?: "unsupported model"}") }
        }
    }

    private fun callback(id: String, response: String, error: String) {
        val js = "window.onForgeAIResponse && window.onForgeAIResponse(${org.json.JSONObject.quote(id)},${org.json.JSONObject.quote(response)},${org.json.JSONObject.quote(error)});"
        runOnUiThread { if (::web.isInitialized) web.evaluateJavascript(js, null) }
    }

    override fun onDestroy() {
        try { conversation?.close() } catch (_: Exception) {}
        try { engine?.close() } catch (_: Exception) {}
        if (::web.isInitialized) web.destroy()
        super.onDestroy()
    }
}
