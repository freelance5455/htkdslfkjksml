package com.worldnations.game;

import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.content.res.Configuration;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private WebView gameView;
    private FrameLayout root;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        );
        enterImmersiveMode();

        gameView = new WebView(this);
        gameView.setLayoutParams(new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ));
        gameView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        gameView.setVerticalScrollBarEnabled(false);
        gameView.setHorizontalScrollBarEnabled(false);
        gameView.setBackgroundColor(0xFF020B13);
        gameView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        gameView.setFocusable(true);
        gameView.setFocusableInTouchMode(true);
        gameView.setWebViewClient(new WebViewClient());
        gameView.setWebChromeClient(new WebChromeClient());

        WebSettings settings = gameView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setLoadWithOverviewMode(false);
        settings.setUseWideViewPort(true);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);

        root = new FrameLayout(this);
        root.setBackgroundColor(0xFF020B13);
        root.addView(gameView);
        setContentView(root);

        root.post(new Runnable() {
            @Override public void run() {
                fitGameToWindow();
            }
        });

        if (savedInstanceState == null) {
            gameView.loadUrl("file:///android_asset/index.html");
        } else {
            gameView.restoreState(savedInstanceState);
        }
    }

    private void fitGameToWindow() {
        if (root == null || gameView == null) return;
        int width = root.getWidth();
        int height = root.getHeight();
        if (width <= 0 || height <= 0) return;

        // Nunca rotacionar o WebView por transformacao: isso desloca as coordenadas
        // de toque em alguns aparelhos. A Activity e o Manifest controlam a orientacao.
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        );
        gameView.setLayoutParams(params);
        gameView.setRotation(0f);
        gameView.setX(0f);
        gameView.setY(0f);
        gameView.requestLayout();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (root != null) root.post(new Runnable() {
            @Override public void run() { fitGameToWindow(); }
        });
    }

    private void enterImmersiveMode() {
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        );
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            enterImmersiveMode();
            if (root != null) root.post(new Runnable() {
                @Override public void run() { fitGameToWindow(); }
            });
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
        enterImmersiveMode();
        if (gameView != null) gameView.onResume();
        if (root != null) root.post(new Runnable() {
            @Override public void run() { fitGameToWindow(); }
        });
    }

    @Override
    protected void onPause() {
        if (gameView != null) {
            gameView.evaluateJavascript("window.dispatchEvent(new Event('wn:native-pause'))", null);
            gameView.onPause();
        }
        super.onPause();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        if (gameView != null) gameView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    public void onBackPressed() {
        if (gameView != null) {
            gameView.evaluateJavascript(
                "window.WN263 ? WN263.closeTopPanel() : false",
                value -> { if (!"true".equals(value)) moveTaskToBack(true); }
            );
        } else super.onBackPressed();
    }
}
