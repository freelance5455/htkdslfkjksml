package com.worldnations.game;

import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.content.res.Configuration;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.Gravity;
import android.graphics.Color;
import android.util.Log;
import android.webkit.ConsoleMessage;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceError;
import android.widget.TextView;
import android.widget.FrameLayout;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private WebView gameView;
    private FrameLayout root;
    private TextView loadingOverlay;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        );
        enterImmersiveMode();

        gameView = new WebView(this);
        gameView.setLayoutParams(new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ));
        gameView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        gameView.setVerticalScrollBarEnabled(false);
        gameView.setHorizontalScrollBarEnabled(false);
        gameView.setBackgroundColor(0xFF020B13);
        gameView.setFocusable(true);
        gameView.setFocusableInTouchMode(true);
        gameView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (root != null && loadingOverlay != null) root.removeView(loadingOverlay);
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                super.onReceivedError(view, request, error);
                if (request != null && request.isForMainFrame()) {
                    String detail = error == null ? "Não foi possível abrir o jogo." : error.getDescription().toString();
                    Log.e("WorldNations", "Falha ao carregar tela principal: " + detail);
                    showNativeError("Não foi possível abrir o jogo", detail);
                }
            }

            @Override
            public boolean onRenderProcessGone(WebView view, android.webkit.RenderProcessGoneDetail detail) {
                Log.e("WorldNations", "Processo gráfico do WebView foi encerrado. Crashed=" + (detail != null && detail.didCrash()));
                showNativeError("O mapa parou de responder", "Feche e abra o jogo novamente. Se continuar, envie esta tela junto com a captura do erro.");
                return true;
            }
        });
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            gameView.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, false);
        }
        gameView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onConsoleMessage(ConsoleMessage message) {
                if (message != null && message.messageLevel() == ConsoleMessage.MessageLevel.ERROR) {
                    Log.e("WorldNations-JS", message.message() + " (linha " + message.lineNumber() + ")");
                }
                return true;
            }
        });

        WebSettings settings = gameView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setLoadWithOverviewMode(false);
        settings.setUseWideViewPort(true);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);

        root = new FrameLayout(this);
        root.setBackgroundColor(0xFF020B13);
        root.addView(gameView);
        loadingOverlay = new TextView(this);
        loadingOverlay.setText("WORLD NATIONS\nCarregando o mapa…");
        loadingOverlay.setTextColor(Color.WHITE);
        loadingOverlay.setTextSize(18);
        loadingOverlay.setGravity(Gravity.CENTER);
        loadingOverlay.setBackgroundColor(0xFF020B13);
        root.addView(loadingOverlay, new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ));
        setContentView(root);

        root.post(new Runnable() {
            @Override public void run() {
                fitGameToWindow();
            }
        });

        if (savedInstanceState == null) {
            gameView.loadUrl("file:///android_asset/index.html");
        } else {
            gameView.restoreState(savedInstanceState);
        }
        gameView.postDelayed(() -> gameView.evaluateJavascript(
            "document.querySelectorAll('#world .country').length",
            value -> {
                if ("0".equals(value) || value == null) {
                    showNativeError("O mapa não terminou de abrir", "O WebView abriu o aplicativo, mas não conseguiu desenhar os países. Envie esta tela para identificar a falha.");
                }
            }
        ), 12000);
    }


    private void showNativeError(String title, String detail) {
        if (root == null) return;
        runOnUiThread(() -> {
            TextView message = new TextView(this);
            message.setText(title + "\n\n" + detail + "\n\nFeche esta tela e tente abrir novamente.");
            message.setTextColor(Color.WHITE);
            message.setTextSize(17);
            message.setGravity(Gravity.CENTER);
            message.setPadding(32, 32, 32, 32);
            message.setBackgroundColor(0xFF020B13);
            root.removeAllViews();
            root.addView(message, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            ));
        });
    }

    private void fitGameToWindow() {
        if (root == null || gameView == null) return;
        int width = root.getWidth();
        int height = root.getHeight();
        if (width <= 0 || height <= 0) return;

        // Nunca rotacionar o WebView por transformacao: isso desloca as coordenadas
        // de toque em alguns aparelhos. A Activity e o Manifest controlam a orientacao.
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        );
        gameView.setLayoutParams(params);
        gameView.setRotation(0f);
        gameView.setX(0f);
        gameView.setY(0f);
        gameView.requestLayout();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (root != null) root.post(new Runnable() {
            @Override public void run() { fitGameToWindow(); }
        });
    }

    private void enterImmersiveMode() {
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        );
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            enterImmersiveMode();
            if (root != null) root.post(new Runnable() {
                @Override public void run() { fitGameToWindow(); }
            });
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
        enterImmersiveMode();
        if (gameView != null) gameView.onResume();
        if (root != null) root.post(new Runnable() {
            @Override public void run() { fitGameToWindow(); }
        });
    }

    @Override
    protected void onPause() {
        if (gameView != null) {
            gameView.evaluateJavascript("window.dispatchEvent(new Event('wn:native-pause'))", null);
            gameView.onPause();
        }
        super.onPause();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        if (gameView != null) gameView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    public void onBackPressed() {
        if (gameView != null) {
            gameView.evaluateJavascript(
                "window.WN263 ? WN263.closeTopPanel() : false",
                value -> { if (!"true".equals(value)) moveTaskToBack(true); }
            );
        } else super.onBackPressed();
    }
}
