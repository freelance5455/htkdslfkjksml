package com.notifystyle.app

import android.content.ComponentName
import android.content.Context
import android.provider.Settings

object NotificationAccess {
    fun isEnabled(context: Context): Boolean {
        val enabled = Settings.Secure.getString(context.contentResolver, "enabled_notification_listeners") ?: return false
        return enabled.split(":").mapNotNull { ComponentName.unflattenFromString(it) }.any { it.packageName == context.packageName }
    }
}
