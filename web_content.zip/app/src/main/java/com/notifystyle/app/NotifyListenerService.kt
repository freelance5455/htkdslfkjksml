package com.notifystyle.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.core.app.NotificationCompat

class NotifyListenerService : NotificationListenerService() {
    companion object {
        const val ACTION_NOTIFICATION_RECEIVED = "com.notifystyle.app.NOTIFICATION_RECEIVED"
        private const val CHANNEL_ID = "notifystyle_custom_notifications"
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val notification = sbn.notification ?: return
        val extras = notification.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        val text = (extras.getCharSequence(Notification.EXTRA_BIG_TEXT)
            ?: extras.getCharSequence(Notification.EXTRA_TEXT))?.toString()?.trim().orEmpty()
        if (title.isBlank() && text.isBlank()) return

        val appName = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString()
        } catch (_: Exception) { sbn.packageName }
        NotificationStore.add(this, appName, sbn.packageName, title.ifBlank { appName }, text)

        sendBroadcast(Intent(ACTION_NOTIFICATION_RECEIVED).apply {
            setPackage(packageName)
            putExtra("app", appName)
            putExtra("packageName", sbn.packageName)
            putExtra("title", title.ifBlank { appName })
            putExtra("body", text)
        })
        showStyledCopy(appName, title.ifBlank { appName }, text)
    }

    private fun showStyledCopy(appName: String, title: String, text: String) {
        val intent = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
        val pendingFlags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        val pending = PendingIntent.getActivity(this, 1001, intent, pendingFlags)
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("$appName · NotifyStyle")
            .setContentText(text.ifBlank { title })
            .setStyle(NotificationCompat.BigTextStyle().bigText(text.ifBlank { title }))
            .setContentIntent(pending)
            .setAutoCancel(true)
            .setOnlyAlertOnce(true)
            .setColor(0xFFA7F3D0.toInt())
            .build()
        getSystemService(NotificationManager::class.java).notify((System.currentTimeMillis() % Int.MAX_VALUE).toInt(), notification)
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "NotifyStyle Custom", NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = "إشعارات NotifyStyle المعاد عرضها"
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
}
