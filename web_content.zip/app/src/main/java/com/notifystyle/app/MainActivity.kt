package com.notifystyle.app

import android.Manifest
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.core.app.ActivityCompat
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != NotifyListenerService.ACTION_NOTIFICATION_RECEIVED) return
            val payload = JSONObject().apply {
                put("app", intent.getStringExtra("app") ?: "تطبيق")
                put("title", intent.getStringExtra("title") ?: "إشعار جديد")
                put("body", intent.getStringExtra("body") ?: "")
                put("time", "الآن")
                put("unread", true)
                put("icon", "🔔")
            }
            webView.post { webView.evaluateJavascript("window.__nativeNotification(${payload});", null) }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this).apply {
            setBackgroundColor(0xFF071A21.toInt())
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = true
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
            addJavascriptInterface(WebBridge(this@MainActivity), "AndroidNotifyStyle")
            loadUrl("file:///android_asset/index.html")
        }
        setContentView(webView)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 77)
        registerReceiver(receiver, IntentFilter(NotifyListenerService.ACTION_NOTIFICATION_RECEIVED), RECEIVER_NOT_EXPORTED)
    }

    override fun onDestroy() {
        unregisterReceiver(receiver)
        webView.destroy()
        super.onDestroy()
    }

    inner class WebBridge(private val context: Context) {
        @JavascriptInterface fun getCapturedNotifications(): String = NotificationStore.getJson(context)
        @JavascriptInterface fun openNotificationAccessSettings() { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        @JavascriptInterface fun isNotificationAccessEnabled(): Boolean = NotificationAccess.isEnabled(context)
    }
}
