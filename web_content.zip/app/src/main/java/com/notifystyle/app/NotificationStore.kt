package com.notifystyle.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object NotificationStore {
    private const val PREFS = "notifystyle_store"
    private const val KEY = "captured_notifications"
    private const val MAX_ITEMS = 80

    fun add(context: Context, app: String, packageName: String, title: String, body: String) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val old = runCatching { JSONArray(prefs.getString(KEY, "[]") ?: "[]") }.getOrDefault(JSONArray())
        val next = JSONArray()
        next.put(JSONObject().apply {
            put("app", app)
            put("packageName", packageName)
            put("title", title)
            put("body", body)
            put("time", "الآن")
            put("unread", true)
            put("icon", "🔔")
        })
        for (i in 0 until minOf(old.length(), MAX_ITEMS - 1)) next.put(old.getJSONObject(i))
        prefs.edit().putString(KEY, next.toString()).apply()
    }

    fun getJson(context: Context): String = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]"
}
