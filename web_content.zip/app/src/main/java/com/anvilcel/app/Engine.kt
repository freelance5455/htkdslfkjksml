package com.anvilcel.app

import android.content.Context
import android.content.Intent
import org.json.JSONArray
import org.json.JSONObject
import org.tukaani.xz.XZInputStream
import java.io.File
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.URL
import java.nio.file.Files
import java.util.UUID
import java.util.zip.GZIPInputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Mini "Termux" dentro do app: proot (dos pacotes oficiais do Termux) + Ubuntu arm64 (rootfs oficial)
 * + Java 21 (apt) + PowerNukkitX + tunel playit.gg. Tudo baixado na 1a vez.
 */
object Engine {
    private lateinit var ctx: Context
    private val procs = HashMap<String, Proc>()
    private val lock = Any()
    private val setupLock = Any()
    private const val TREPO = "https://packages.termux.dev/apt/termux-main/"

    class Proc { @Volatile var p: Process? = null; @Volatile var busy = true; val lines = ArrayList<String>(); var off = 0 }

    fun init(c: Context) { ctx = c.applicationContext; root().mkdirs() }

    private fun root() = File(ctx.filesDir, "servers")
    private fun tx() = File(ctx.filesDir, "tx")
    private fun rootfs() = File(ctx.filesDir, "ubuntu")
    private fun sdir(i: String) = File(root(), i)
    private fun metaF(i: String) = File(sdir(i), "anvil.json")
    private fun load(i: String) = JSONObject(metaF(i).readText())
    private fun alive(k: String) = procs[k]?.p?.isAlive == true
    private fun msg(s: String) = JSONObject().put("msg", s).toString()
    private fun clean(s: String) = s.replace(Regex("\u001B\\[[0-9;?]*[A-Za-z]"), "")
    private fun say(pr: Proc, l: String) = synchronized(lock) {
        pr.lines.add(l)
        if (pr.lines.size > 3000) { repeat(1000) { pr.lines.removeAt(0) }; pr.off += 1000 }
    }

    // ------------------------------------------------------------ API
    fun call(full: String, bodyStr: String): String {
        val path = full.substringBefore("?")
        val q = full.substringAfter("?", "")
        val d = try { JSONObject(bodyStr) } catch (e: Exception) { JSONObject() }
        val id = path.substringAfterLast("/")
        return try {
            when {
                path == "/api/servers" -> servers().toString()
                path == "/api/net" -> net().toString()
                path == "/api/playit" -> playitInfo().toString()
                path == "/api/playit/start" -> msg(startPlayit())
                path == "/api/playit/stop" -> { procs["playit"]?.p?.destroy(); msg("ok") }
                path.startsWith("/api/log/") -> log(id, q.substringAfter("from=", "0").toIntOrNull() ?: 0).toString()
                path == "/api/create" -> JSONObject().put("id", create(d)).toString()
                path.startsWith("/api/start/") -> msg(startServer(id))
                path.startsWith("/api/stop/") -> msg(stop(id))
                path.startsWith("/api/backup/") -> msg(backup(id))
                path.startsWith("/api/delete/") -> { stop(id); Thread.sleep(1500); sdir(id).deleteRecursively(); msg("ok") }
                path.startsWith("/api/cmd/") -> {
                    procs[id]?.p?.takeIf { it.isAlive }?.outputStream?.let { it.write((d.optString("cmd") + "\n").toByteArray()); it.flush() }
                    msg("ok")
                }
                else -> msg("rota desconhecida")
            }
        } catch (e: Exception) { msg("erro: " + e.message) }
    }

    private fun servers(): JSONArray {
        val a = JSONArray()
        root().listFiles()?.sortedBy { it.name }?.forEach { f ->
            if (File(f, "anvil.json").exists()) a.put(load(f.name).put("id", f.name).put("running", alive(f.name)))
        }
        return a
    }

    private fun create(d: JSONObject): String {
        val i = UUID.randomUUID().toString().substring(0, 8)
        sdir(i).mkdirs()
        val m = JSONObject()
            .put("name", d.optString("name").ifBlank { "Survival World" })
            .put("software", "pnx")
            .put("port", d.optString("port").toIntOrNull() ?: 19132)
            .put("maxPlayers", d.optString("maxPlayers").toIntOrNull() ?: 10)
            .put("gamemode", d.optString("gamemode", "survival"))
            .put("difficulty", d.optString("difficulty", "normal"))
            .put("ram", 1024)
            .put("offline", d.optBoolean("offline", true))
            .put("whitelist", d.optBoolean("whitelist", false))
        metaF(i).writeText(m.toString()); writeProps(i, m)
        return i
    }

    private fun writeProps(i: String, m: JSONObject) {
        val gm = when (m.optString("gamemode")) { "creative" -> 1; "adventure" -> 2; else -> 0 }
        val df = when (m.optString("difficulty")) { "peaceful" -> 0; "easy" -> 1; "hard" -> 3; else -> 2 }
        val new = mapOf(
            "motd" to m.optString("name"), "server-name" to m.optString("name"),
            "server-port" to m.optInt("port", 19132).toString(),
            "max-players" to m.optInt("maxPlayers", 10).toString(),
            "gamemode" to gm.toString(), "difficulty" to df.toString(),
            "xbox-auth" to (if (m.optBoolean("offline", true)) "off" else "on"),
            "white-list" to (if (m.optBoolean("whitelist")) "on" else "off")
        )
        val f = File(sdir(i), "server.properties")
        val cur = LinkedHashMap<String, String>()
        if (f.exists()) f.readLines().forEach { if (it.contains("=") && !it.startsWith("#")) cur[it.substringBefore("=")] = it.substringAfter("=") }
        cur.putAll(new)
        f.writeText(cur.entries.joinToString("\n") { "${it.key}=${it.value}" } + "\n")
        val nk = File(sdir(i), "nukkit.yml")
        if (!nk.exists()) nk.writeText("settings:\n  language: eng\n")
    }

    // ------------------------------------------------------------ downloads / arquivos
    private fun download(url: String, dest: File) {
        var u = url
        for (n in 0 until 8) {
            val c = URL(u).openConnection() as HttpURLConnection
            c.instanceFollowRedirects = false
            c.connectTimeout = 15000; c.readTimeout = 60000
            c.setRequestProperty("User-Agent", "BedrockServersFree")
            val code = c.responseCode
            if (code in 300..399) { u = c.getHeaderField("Location"); c.disconnect(); continue }
            if (code != 200) throw Exception("HTTP $code em $u")
            c.inputStream.use { i -> dest.outputStream().use { i.copyTo(it) } }
            return
        }
        throw Exception("redirecionamentos demais")
    }

    private fun getText(url: String): String {
        val f = File(ctx.cacheDir, "dl.tmp"); download(url, f)
        val t = f.readText(); f.delete(); return t
    }

    private fun readFully(i: InputStream, b: ByteArray): Int {
        var n = 0
        while (n < b.size) { val r = i.read(b, n, b.size - n); if (r < 0) break; n += r }
        return n
    }

    private fun skipN(i: InputStream, n: Long) {
        var left = n; val buf = ByteArray(8192)
        while (left > 0) { val r = i.read(buf, 0, minOf(buf.size.toLong(), left).toInt()); if (r < 0) break; left -= r }
    }

    private fun cstr(h: ByteArray, off: Int, len: Int) = String(h, off, len, Charsets.UTF_8).trim('\u0000', ' ')

    private fun untar(ins: InputStream, out: File, strip: String? = null) {
        val h = ByteArray(512)
        var longName: String? = null
        val outP = out.toPath().normalize()
        while (true) {
            if (readFully(ins, h) < 512 || h.all { it == 0.toByte() }) break
            val name0 = cstr(h, 0, 100)
            val mode = cstr(h, 100, 8).let { if (it.isEmpty()) 0 else it.toInt(8) }
            val sz = cstr(h, 124, 12).let { if (it.isEmpty()) 0L else it.toLong(8) }
            val type = h[156].toInt().toChar()
            val link = cstr(h, 157, 100)
            val prefix = cstr(h, 345, 155)
            val pad = (512 - sz % 512) % 512
            if (type == 'L' || type == 'x' || type == 'g') {
                val b = ByteArray(sz.toInt()); readFully(ins, b); skipN(ins, pad)
                val txt = String(b, Charsets.UTF_8)
                if (type == 'L') longName = txt.trim('\u0000')
                else if (type == 'x') Regex("\\d+ path=([^\\n]*)\\n").find(txt)?.let { longName = it.groupValues[1] }
                continue
            }
            var full = (longName ?: (if (prefix.isNotEmpty()) "$prefix/$name0" else name0)).removePrefix("./").trimStart('/')
            longName = null
            if (strip != null) {
                if (!full.startsWith(strip)) { skipN(ins, sz + pad); continue }
                full = full.removePrefix(strip)
            }
            if (full.isEmpty()) { skipN(ins, sz + pad); continue }
            val f = File(out, full)
            if (!f.toPath().normalize().startsWith(outP)) { skipN(ins, sz + pad); continue }
            when (type) {
                '5' -> { f.mkdirs(); f.setReadable(true, true); f.setWritable(true, true); f.setExecutable(true, true) }
                '0', '\u0000' -> {
                    f.parentFile?.mkdirs()
                    if (f.exists() || Files.isSymbolicLink(f.toPath())) f.delete()
                    f.outputStream().use { o ->
                        var left = sz; val buf = ByteArray(8192)
                        while (left > 0) { val r = ins.read(buf, 0, minOf(buf.size.toLong(), left).toInt()); if (r < 0) break; o.write(buf, 0, r); left -= r }
                    }
                    f.setReadable(true, false); f.setWritable(true, true)
                    if (mode and 73 != 0) f.setExecutable(true, false)
                    skipN(ins, pad)
                }
                '2' -> {
                    f.parentFile?.mkdirs()
                    try { if (f.exists() || Files.isSymbolicLink(f.toPath())) f.delete(); Files.createSymbolicLink(f.toPath(), java.nio.file.Paths.get(link)) } catch (e: Exception) { }
                }
                '1' -> {
                    f.parentFile?.mkdirs()
                    var l = link.removePrefix("./").trimStart('/')
                    if (strip != null) l = l.removePrefix(strip)
                    val t = File(out, l)
                    try { if (f.exists()) f.delete(); Files.createLink(f.toPath(), t.toPath()) } catch (e: Exception) { try { t.copyTo(f, true) } catch (e2: Exception) { } }
                }
                else -> skipN(ins, sz + pad)
            }
        }
    }

    // ------------------------------------------------------------ passo 1: proot (pacotes do Termux)
    private fun termuxIndex(): Map<String, Map<String, String>> {
        val res = HashMap<String, Map<String, String>>()
        var cur = HashMap<String, String>()
        fun flush() { if (cur.containsKey("Package") && cur.containsKey("Filename")) res[cur["Package"]!!] = cur; cur = HashMap() }
        fun feed(line: String) {
            if (line.isBlank()) flush()
            else if (!line.startsWith(" ") && line.contains(": ")) {
                val k = line.substringBefore(": ")
                if (k == "Package" || k == "Filename" || k == "Depends") cur[k] = line.substringAfter(": ")
            }
        }
        val f = File(ctx.cacheDir, "Packages.xz")
        try {
            download(TREPO + "dists/stable/main/binary-aarch64/Packages.xz", f)
            XZInputStream(f.inputStream().buffered()).bufferedReader().forEachLine { feed(it) }
        } catch (e: Exception) {
            res.clear(); cur = HashMap()
            val p = File(ctx.cacheDir, "Packages"); download(TREPO + "dists/stable/main/binary-aarch64/Packages", p)
            p.forEachLine { feed(it) }; p.delete()
        }
        flush(); f.delete()
        return res
    }

    private fun installDeb(path: String) {
        val deb = File(ctx.cacheDir, "pkg.deb"); download(TREPO + path, deb)
        deb.inputStream().buffered().use { ins ->
            skipN(ins, 8)
            val hdr = ByteArray(60)
            while (readFully(ins, hdr) == 60) {
                val name = String(hdr, 0, 16).trim()
                val size = String(hdr, 48, 10).trim().toLong()
                if (name.startsWith("data.tar")) {
                    val tmp = File(ctx.cacheDir, "data.part")
                    tmp.outputStream().use { o ->
                        var left = size; val buf = ByteArray(8192)
                        while (left > 0) { val r = ins.read(buf, 0, minOf(buf.size.toLong(), left).toInt()); if (r < 0) break; o.write(buf, 0, r); left -= r }
                    }
                    val raw = tmp.inputStream().buffered()
                    val dec: InputStream = when {
                        name.contains(".xz") -> XZInputStream(raw)
                        name.contains(".gz") -> GZIPInputStream(raw)
                        name.endsWith(".tar") -> raw
                        else -> throw Exception("formato de pacote nao suportado: $name")
                    }
                    dec.use { untar(it, tx(), "data/data/com.termux/files/usr/") }
                    tmp.delete(); deb.delete(); return
                } else skipN(ins, size + (size % 2))
            }
        }
        throw Exception("data.tar nao encontrado no pacote")
    }

    private fun installProot(say: (String) -> Unit) {
        say("[Setup 1/5] Baixando o proot (pacotes oficiais do Termux)...")
        val idx = termuxIndex()
        val skip = setOf("termux-exec", "termux-core", "termux-tools", "bash", "coreutils", "dash", "busybox")
        val want = ArrayDeque<String>(); want.add("proot")
        val done = HashSet<String>()
        while (want.isNotEmpty()) {
            val n = want.removeFirst()
            if (!done.add(n) || n in skip) continue
            val st = idx[n] ?: continue
            say("[Setup 1/5]   pacote $n")
            installDeb(st["Filename"]!!)
            st["Depends"]?.split(",")?.forEach { d -> want.add(d.trim().substringBefore("|").trim().substringBefore(" ").trim()) }
        }
        val pr = File(tx(), "bin/proot")
        if (!pr.exists()) throw Exception("proot nao foi instalado")
        pr.setExecutable(true, false)
        File(tx(), "libexec/proot").listFiles()?.forEach { it.setExecutable(true, false) }
    }

    private fun prootBuilder(binds: List<String>, cwd: String, vararg inner: String): ProcessBuilder {
        val args = ArrayList<String>()
        args += File(tx(), "bin/proot").path
        args += listOf("-0", "-r", rootfs().path, "--link2symlink", "--kill-on-exit", "-b", "/dev", "-b", "/proc", "-b", "/sys", "-w", cwd)
        for (b in binds) { args += "-b"; args += b }
        args += listOf("/usr/bin/env", "-i", "HOME=/root", "TERM=dumb", "LANG=C.UTF-8", "TMPDIR=/tmp",
            "PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin")
        args += inner
        val pb = ProcessBuilder(args); pb.redirectErrorStream(true)
        val e = pb.environment()
        e["LD_LIBRARY_PATH"] = File(tx(), "lib").path
        e["PROOT_LOADER"] = File(tx(), "libexec/proot/loader").path
        e["PROOT_TMP_DIR"] = ctx.cacheDir.path
        e["PROOT_NO_SECCOMP"] = "1"
        return pb
    }

    private fun runLogged(pb: ProcessBuilder, say: (String) -> Unit, tag: String): Int {
        val p = pb.start()
        p.inputStream.bufferedReader().forEachLine { say(tag + clean(it)) }
        return p.waitFor()
    }

    // ------------------------------------------------------------ passo 2: Ubuntu
    private fun installRootfs(say: (String) -> Unit) {
        say("[Setup 2/5] Procurando o Ubuntu arm64...")
        val base = "https://cdimage.ubuntu.com/ubuntu-base/releases/24.04/release/"
        val name = Regex("ubuntu-base-24\\.04[0-9.]*-base-arm64\\.tar\\.gz").findAll(getText(base)).map { it.value }.distinct().sortedDescending().firstOrNull()
            ?: throw Exception("nao achei o rootfs do Ubuntu")
        say("[Setup 2/5] Baixando $name (~30 MB)...")
        val tgz = File(ctx.cacheDir, "ubuntu.tar.gz"); download(base + name, tgz)
        say("[Setup 2/5] Extraindo Ubuntu (demora)...")
        rootfs().deleteRecursively(); rootfs().mkdirs()
        GZIPInputStream(tgz.inputStream().buffered()).use { untar(it, rootfs()) }
        tgz.delete()
        val rc = File(rootfs(), "etc/resolv.conf")
        try { Files.deleteIfExists(rc.toPath()) } catch (e: Exception) { }
        rc.parentFile?.mkdirs(); rc.writeText("nameserver 8.8.8.8\nnameserver 1.1.1.1\n")
        File(rootfs(), "etc/apt/apt.conf.d").mkdirs()
        File(rootfs(), "etc/apt/apt.conf.d/99proot").writeText("APT::Sandbox::User \"root\";\nDpkg::Use-Pty \"0\";\n")
        File(rootfs(), ".base-ok").writeText("ok")
    }

    // ------------------------------------------------------------ passo 3: Java
    private fun installJava(say: (String) -> Unit) {
        say("[Setup 3/5] Instalando Java 21 no Ubuntu (apt, vai demorar)...")
        val pb = prootBuilder(emptyList(), "/root", "bash", "-lc",
            "export DEBIAN_FRONTEND=noninteractive; apt-get update && apt-get install -y --no-install-recommends openjdk-21-jre-headless ca-certificates && java -version")
        val rc = runLogged(pb, say, "[apt] ")
        if (rc != 0) throw Exception("apt/java terminou com codigo $rc")
        File(rootfs(), ".java-ok").writeText("ok")
    }

    private fun findJar(assets: JSONArray): String? {
        var best: String? = null; var rank = 99
        for (k in 0 until assets.length()) {
            val a = assets.getJSONObject(k); val n = a.getString("name").lowercase()
            if (!n.endsWith(".jar") || n.contains("sources") || n.contains("javadoc")) continue
            val r = when { n == "powernukkitx.jar" -> 0; n.contains("shaded") -> 1; n.startsWith("powernukkitx") -> 2; else -> 3 }
            if (r < rank) { rank = r; best = a.getString("browser_download_url") }
        }
        return best
    }

    // ------------------------------------------------------------ tudo junto
    private fun ensureRuntime(say: (String) -> Unit): Boolean = synchronized(setupLock) {
        try {
            if (!File(tx(), "bin/proot").exists()) installProot(say)
            val t = prootBuilder(emptyList(), "/", "/bin/true")
            if (!File(rootfs(), ".base-ok").exists()) installRootfs(say)
            if (!File(rootfs(), ".java-ok").exists()) installJava(say)
            val jar = File(rootfs(), "opt/pnx/powernukkitx.jar")
            if (!jar.exists()) {
                say("[Setup 4/5] Baixando PowerNukkitX (ultima versao)...")
                val rel = JSONObject(getText("https://api.github.com/repos/PowerNukkitX/PowerNukkitX/releases/latest"))
                val url = findJar(rel.getJSONArray("assets")) ?: throw Exception("jar do PowerNukkitX nao encontrado")
                jar.parentFile?.mkdirs(); download(url, jar)
                say("[Setup 4/5] PowerNukkitX " + rel.optString("tag_name") + " ok")
            }
            val pl = File(rootfs(), "opt/playit")
            if (!pl.exists()) {
                say("[Setup 5/5] Baixando playit.gg...")
                val rel = JSONObject(getText("https://api.github.com/repos/playit-cloud/playit-agent/releases/latest"))
                val assets = rel.getJSONArray("assets"); var url: String? = null
                for (k in 0 until assets.length()) {
                    val a = assets.getJSONObject(k); val n = a.getString("name").lowercase()
                    if (n.contains("linux") && (n.contains("aarch64") || n.contains("arm64")) && !n.endsWith(".sha256") && !n.endsWith(".deb") && !n.endsWith(".rpm") && !n.endsWith(".sig")) { url = a.getString("browser_download_url"); break }
                }
                if (url == null) throw Exception("playit aarch64 nao encontrado")
                download(url, pl); pl.setExecutable(true, false)
            }
            true
        } catch (e: Throwable) {
            say("[Setup] ERRO: " + e.message); false
        }
    }

    private fun launch(key: String, build: () -> ProcessBuilder): String {
        val old = procs[key]
        if (old != null && (old.busy || old.p?.isAlive == true)) return "ja esta iniciando/rodando"
        val pr = Proc(); pr.lines.add("[AnvilCel] Iniciando..."); procs[key] = pr
        ctx.startForegroundService(Intent(ctx, ServerService::class.java))
        Thread {
            try {
                if (!ensureRuntime { say(pr, it) }) { pr.busy = false; stopServiceIfIdle(); return@Thread }
                val p = build().start(); pr.p = p; pr.busy = false
                p.inputStream.bufferedReader().forEachLine { say(pr, clean(it)) }
                say(pr, "[AnvilCel] Processo encerrado.")
            } catch (e: Throwable) { say(pr, "[AnvilCel] Falha: " + e.message) }
            pr.busy = false; stopServiceIfIdle()
        }.start()
        return "ok"
    }

    private fun startServer(i: String): String {
        val m = load(i); writeProps(i, m)
        val ram = m.optInt("ram", 1024)
        return launch(i) {
            prootBuilder(listOf(sdir(i).path + ":/srv"), "/srv", "bash", "-lc",
                "exec java -Xmx${ram}M -Dfile.encoding=UTF-8 --add-opens java.base/java.lang=ALL-UNNAMED --add-opens java.base/java.io=ALL-UNNAMED -jar /opt/pnx/powernukkitx.jar")
        }
    }

    private fun startPlayit(): String = launch("playit") { prootBuilder(emptyList(), "/root", "/opt/playit", "--stdout") }

    private fun playitInfo(): JSONObject {
        val pr = procs["playit"]
        val lines = synchronized(lock) { pr?.lines?.toList() ?: emptyList() }
        val txt = lines.joinToString("\n")
        val claim = Regex("https://playit\\.gg/claim/[A-Za-z0-9_\\-]+").findAll(txt).lastOrNull()?.value ?: ""
        val addrs = Regex("\\b[a-z0-9\\-]+(?:\\.[a-z0-9\\-]+)*\\.(?:ply\\.gg|joinmc\\.link|playit\\.plus|playit\\.gg)(?::\\d+)?\\b")
            .findAll(txt).map { it.value }.filter { !it.startsWith("playit.gg") }.distinct().toList().takeLast(6)
        return JSONObject().put("running", pr != null && (pr.busy || pr.p?.isAlive == true))
            .put("claim", claim).put("addrs", JSONArray(addrs)).put("tail", JSONArray(lines.takeLast(8)))
    }

    private fun stopServiceIfIdle() {
        if (procs.values.none { it.busy || it.p?.isAlive == true }) ctx.stopService(Intent(ctx, ServerService::class.java))
    }

    private fun stop(i: String): String {
        val p = procs[i]?.p ?: return "ok"
        if (!p.isAlive) return "ok"
        try { p.outputStream.write("stop\n".toByteArray()); p.outputStream.flush() } catch (e: Exception) { }
        Thread { try { Thread.sleep(25000) } catch (e: Exception) { }; if (p.isAlive) p.destroy() }.start()
        return "ok"
    }

    private fun log(i: String, from: Int): JSONObject {
        val r = procs[i] ?: return JSONObject().put("lines", JSONArray()).put("next", 0).put("running", false)
        synchronized(lock) {
            val start = maxOf(0, from - r.off)
            val a = JSONArray(); for (k in start until r.lines.size) a.put(r.lines[k])
            return JSONObject().put("lines", a).put("next", r.off + r.lines.size).put("running", r.p?.isAlive == true)
        }
    }

    private fun net(): JSONObject {
        var local: String? = null
        try {
            for (ni in NetworkInterface.getNetworkInterfaces()) {
                if (ni.isLoopback || !ni.isUp) continue
                for (a in ni.inetAddresses) if (a is Inet4Address && !a.isLoopbackAddress) { local = a.hostAddress; break }
                if (local != null) break
            }
        } catch (e: Exception) { }
        var pub: String? = null
        try {
            val c = URL("https://api.ipify.org").openConnection(); c.connectTimeout = 5000; c.readTimeout = 5000
            pub = c.getInputStream().bufferedReader().readText()
        } catch (e: Exception) { }
        return JSONObject().put("local", local ?: JSONObject.NULL).put("public", pub ?: JSONObject.NULL)
    }

    private fun backup(i: String): String {
        val out = File(ctx.getExternalFilesDir(null), "backups"); out.mkdirs()
        val z = File(out, "$i-${System.currentTimeMillis() / 1000}.zip")
        val base = sdir(i)
        ZipOutputStream(z.outputStream()).use { zo ->
            base.walkTopDown().filter { it.isFile }.forEach { f ->
                zo.putNextEntry(ZipEntry(f.relativeTo(base).path)); f.inputStream().use { it.copyTo(zo) }; zo.closeEntry()
            }
        }
        return "salvo em Android/data/com.bedrock.play/files/backups/" + z.name
    }
}
