package com.anvilcel.app

import android.app.*
import android.content.Intent
import android.os.IBinder
import android.os.PowerManager

class ServerService : Service() {
    private var wl: PowerManager.WakeLock? = null
    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("anvilcel", "Servidor", NotificationManager.IMPORTANCE_LOW))
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "anvilcel")
            .setContentTitle("BEDROCK SERVERS FREE")
            .setContentText("Servidor Minecraft rodando em segundo plano")
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .setContentIntent(pi).build()
        startForeground(1, n)
        if (wl == null) {
            wl = (getSystemService(POWER_SERVICE) as PowerManager).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "anvilcel:srv")
            wl?.acquire()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() { wl?.let { if (it.isHeld) it.release() }; super.onDestroy() }
}
