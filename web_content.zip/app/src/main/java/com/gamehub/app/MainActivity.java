package com.gamehub.app;
import android.app.Activity; import android.os.Bundle; import android.webkit.WebView; import android.webkit.WebViewClient;
public class MainActivity extends Activity {
 public void onCreate(Bundle b){super.onCreate(b); setContentView(R.layout.activity_main);
 WebView w=findViewById(R.id.webview); w.setWebViewClient(new WebViewClient()); w.getSettings().setJavaScriptEnabled(true);
 w.getSettings().setDomStorageEnabled(true); w.loadUrl("file:///android_asset/index.html");}
}
