package com.agri.pro;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.FileProvider;
import androidx.core.content.ContextCompat;

import com.journeyapps.barcodescanner.ScanContract;
import com.journeyapps.barcodescanner.ScanOptions;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

public class MainActivity extends AppCompatActivity {
    private static final int REQ_CAMERA = 2001;
    private static final int REQ_FILE_CHOOSER = 2002;
    private static final int REQ_NATIVE_CAMERA = 2003;

    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private String pendingNativeImageId = null;
    private Uri cameraOutputUri = null;

    private final androidx.activity.result.ActivityResultLauncher<ScanOptions> barcodeLauncher =
            registerForActivityResult(new ScanContract(), result -> {
                if (result.getContents() != null) {
                    sendJs("handleBarcode(" + jsString(result.getContents()) + ")");
                }
            });

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        setContentView(webView);
        configureWebView();
        webView.addJavascriptInterface(new AgriBridge(), "AndroidAgri");
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void configureWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);

        CookieManager.getInstance().setAcceptCookie(true);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return false;
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> {
                    String[] resources = request.getResources();
                    for (String r : resources) {
                        if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r)) {
                            if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.CAMERA)
                                    == PackageManager.PERMISSION_GRANTED) {
                                request.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
                            } else {
                                request.deny();
                                ActivityCompat.requestPermissions(MainActivity.this,
                                        new String[]{Manifest.permission.CAMERA}, REQ_CAMERA);
                            }
                        } else {
                            request.grant(new String[]{r});
                        }
                    }
                });
            }

            @Override
            public boolean onShowFileChooser(WebView webView,
                                             ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;

                Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                pick.addCategory(Intent.CATEGORY_OPENABLE);
                String[] accept = params.getAcceptTypes();
                String mime = "*/*";
                if (accept != null) for (String a : accept) if (a != null && !a.trim().isEmpty()) { mime = a; break; }
                pick.setType(mime);
                pick.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, false);

                try {
                    startActivityForResult(pick, REQ_FILE_CHOOSER);
                } catch (Exception e) {
                    fileCallback = null;
                    Toast.makeText(MainActivity.this, "تعذر فتح الملفات", Toast.LENGTH_SHORT).show();
                    return false;
                }
                return true;
            }
        });
    }

    private void ensureCameraThen(Runnable action) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED) {
            action.run();
        } else {
            pendingAction = action;
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.CAMERA}, REQ_CAMERA);
        }
    }

    private Runnable pendingAction;

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_CAMERA) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                if (pendingAction != null) {
                    Runnable r = pendingAction;
                    pendingAction = null;
                    r.run();
                }
                sendJs("window.dispatchEvent(new Event('androidCameraReady'))");
            } else {
                sendJs("alert('يجب السماح بصلاحية الكاميرا حتى يعمل التصوير وقراءة الباركود.')");
            }
        }
    }

    private void openNativeCamera(String inputId) {
        ensureCameraThen(() -> {
            try {
                File dir = new File(getCacheDir(), "agri_camera");
                if (!dir.exists()) dir.mkdirs();
                File out = new File(dir, "capture_" + System.currentTimeMillis() + ".jpg");
                cameraOutputUri = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".fileprovider", out);
                pendingNativeImageId = inputId;
                Intent camera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                camera.putExtra(MediaStore.EXTRA_OUTPUT, cameraOutputUri);
                camera.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivityForResult(camera, REQ_NATIVE_CAMERA);
            } catch (Exception e) {
                pendingNativeImageId = null;
                Toast.makeText(this, "تعذر فتح الكاميرا", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void startNativeBarcode() {
        ensureCameraThen(() -> {
            ScanOptions options = new ScanOptions();
            options.setPrompt("وجّه الكاميرا إلى الباركود");
            options.setBeepEnabled(true);
            options.setOrientationLocked(true);
            options.setCaptureActivity(com.journeyapps.barcodescanner.CaptureActivity.class);
            options.setDesiredBarcodeFormats(ScanOptions.ALL_CODE_TYPES);
            barcodeLauncher.launch(options);
        });
    }

    private void sendJs(String js) {
        runOnUiThread(() -> webView.evaluateJavascript(
                "(function(){try{" + js + "}catch(e){console.error(e)}})();", null));
    }

    private String jsString(String s) {
        if (s == null) return "null";
        return "'" + s.replace("\\", "\\\\")
                .replace("'", "\\'")
                .replace("\r", "\\r")
                .replace("\n", "\\n") + "'";
    }

    private String bitmapToDataUrl(Bitmap bitmap) {
        int max = 1600;
        int w = bitmap.getWidth(), h = bitmap.getHeight();
        float scale = Math.min(1f, max / (float)Math.max(w, h));
        if (scale < 1f) {
            bitmap = Bitmap.createScaledBitmap(bitmap, Math.round(w * scale), Math.round(h * scale), true);
        }
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 85, out);
        return "data:image/jpeg;base64," +
                Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
    }

    private void deliverNativeCameraResult(Intent data) {
        if (pendingNativeImageId == null) return;
        Bitmap bitmap = null;
        try {
            if (cameraOutputUri != null) {
                try (InputStream in = getContentResolver().openInputStream(cameraOutputUri)) {
                    bitmap = BitmapFactory.decodeStream(in);
                }
            }
            if (bitmap == null && data != null && data.getExtras() != null) {
                Object o = data.getExtras().get("data");
                if (o instanceof Bitmap) bitmap = (Bitmap)o;
            }
            if (bitmap != null) {
                String dataUrl = bitmapToDataUrl(bitmap);
                sendJs("handleNativeImage(" + jsString(pendingNativeImageId) + "," + jsString(dataUrl) + ")");
            } else Toast.makeText(this, "لم تُلتقط صورة", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "تعذر قراءة الصورة", Toast.LENGTH_SHORT).show();
        } finally {
            cameraOutputUri = null;
            pendingNativeImageId = null;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQ_FILE_CHOOSER) {
            if (fileCallback != null) {
                Uri[] results = null;
                if (resultCode == Activity.RESULT_OK && data != null) {
                    Uri uri = data.getData();
                    if (uri != null) results = new Uri[]{uri};
                }
                fileCallback.onReceiveValue(results);
                fileCallback = null;
            }
            return;
        }

        if (requestCode == REQ_NATIVE_CAMERA) {
            if (resultCode == Activity.RESULT_OK) deliverNativeCameraResult(data);
            else pendingNativeImageId = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    public class AgriBridge {
        @android.webkit.JavascriptInterface
        public void scanBarcode() {
            runOnUiThread(MainActivity.this::startNativeBarcode);
        }

        @android.webkit.JavascriptInterface
        public void openCameraFor(String inputId) {
            runOnUiThread(() -> openNativeCamera(inputId));
        }

        @android.webkit.JavascriptInterface
        public void testCamera() { runOnUiThread(() -> ensureCameraThen(() -> sendJs("setNativeCameraStatus(true,'الكاميرا تعمل والصلاحية مفعّلة.')"))); }

        @android.webkit.JavascriptInterface
        public void openFiles() {
            runOnUiThread(() -> {
                Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                pick.addCategory(Intent.CATEGORY_OPENABLE);
                pick.setType("*/*");
                startActivity(pick);
            });
        }
    }
}
