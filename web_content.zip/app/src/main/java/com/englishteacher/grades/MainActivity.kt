package com.englishteacher.grades

import android.app.Activity
import android.os.Bundle
import android.webkit.*
import android.content.Intent
import android.net.Uri
import android.print.PrintAttributes
import android.print.PrintManager
import android.content.Context
import android.webkit.JavascriptInterface
import java.io.BufferedReader
import java.io.InputStreamReader

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var pendingImport: ValueCallback<Array<Uri>>? = null
    private val PICK_FILE = 41

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.addJavascriptInterface(Bridge(), "AndroidBridge")
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(v: WebView?, callback: ValueCallback<Array<Uri>>?, params: FileChooserParams?): Boolean {
                pendingImport = callback
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                    putExtra(Intent.EXTRA_MIME_TYPES, arrayOf(
                        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                        "application/msword", "text/plain", "text/csv"
                    ))
                }
                startActivityForResult(i, PICK_FILE)
                return true
            }
        }
        web.loadUrl("file:///android_asset/index.html")
        setContentView(web)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_FILE) {
            val uri = if (resultCode == RESULT_OK) data?.data else null
            pendingImport?.onReceiveValue(if (uri != null) arrayOf(uri) else null)
            pendingImport = null
            if (uri != null) {
                val name = uri.lastPathSegment ?: "students"
                val ext = name.substringAfterLast('.', "").lowercase()
                if (ext == "txt" || ext == "csv") {
                    val text = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: ""
                    web.evaluateJavascript("window.importPlainText(${org.json.JSONObject.quote(text)})", null)
                } else {
                    web.evaluateJavascript("window.showWordImportHelp()", null)
                }
            }
        }
    }

    inner class Bridge {
        @JavascriptInterface fun printPdf() {
            runOnUiThread {
                val pm = getSystemService(Context.PRINT_SERVICE) as PrintManager
                val adapter = web.createPrintDocumentAdapter("English Teacher Results")
                pm.print("English Teacher Results", adapter, PrintAttributes.Builder().build())
            }
        }
    }
}
