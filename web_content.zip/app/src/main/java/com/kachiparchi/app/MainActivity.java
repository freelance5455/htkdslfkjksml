package com.kachiparchi.app;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class MainActivity extends Activity {
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);

        webView.addJavascriptInterface(new AndroidBridge(), "Android");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class AndroidBridge {
        @JavascriptInterface
        public void printPage(String ignoredBillText) {
            runOnUiThread(() -> {
                try {
                    // Use Android's WebView print adapter so the actual bill layout
                    // (including the @media print CSS) is printed, rather than a
                    // manually reconstructed text-only PDF.
                    PrintManager printManager = (PrintManager) getSystemService(PRINT_SERVICE);
                    if (printManager == null) {
                        Toast.makeText(MainActivity.this, "Print service available nahi hai.", Toast.LENGTH_LONG).show();
                        return;
                    }

                    String jobName = "Kachi Parchi Bill";
                    android.print.PrintDocumentAdapter adapter =
                            webView.createPrintDocumentAdapter(jobName);

                    PrintAttributes attributes = new PrintAttributes.Builder()
                            .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                            .setColorMode(PrintAttributes.COLOR_MODE_COLOR)
                            .setMinMargins(new PrintAttributes.Margins(0, 0, 0, 0))
                            .build();

                    printManager.print(jobName, adapter, attributes);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this,
                            "Print start nahi ho saka: " + e.getClass().getSimpleName() + " - " + e.getMessage(),
                            Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public void shareBill(String text) {
            runOnUiThread(() -> {
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType("text/plain");
                send.putExtra(Intent.EXTRA_TEXT, text);
                try {
                    startActivity(Intent.createChooser(send, "Bill Share Karein"));
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this,
                            "Share app available nahi hai.", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
