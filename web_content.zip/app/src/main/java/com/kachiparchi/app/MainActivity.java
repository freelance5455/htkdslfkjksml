package com.kachiparchi.app;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentInfo;
import android.print.PrintManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class MainActivity extends Activity {
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);

        webView.addJavascriptInterface(new AndroidBridge(), "Android");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());

        webView.loadUrl("file:///android_asset/index.html");
    }

    private class AndroidBridge {
        @JavascriptInterface
        public void printPage(String billText) {
            runOnUiThread(() -> {
                try {
                    PrintManager printManager = (PrintManager) getSystemService(PRINT_SERVICE);
                    printManager.print("Kachi Parchi Bill", new BillPrintAdapter(billText),
                            new PrintAttributes.Builder()
                                    .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                                    .setColorMode(PrintAttributes.COLOR_MODE_COLOR)
                                    .setMinMargins(new PrintAttributes.Margins(36,36,36,36))
                                    .build());
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this,
                            "Print start nahi ho saka: " + e.getMessage(),
                            Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public void shareBill(String text) {
            runOnUiThread(() -> {
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType("text/plain");
                send.putExtra(Intent.EXTRA_TEXT, text);
                try {
                    startActivity(Intent.createChooser(send, "Bill Share Karein"));
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this,
                            "Share app available nahi hai.", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    private class BillPrintAdapter extends PrintDocumentAdapter {
        private final String billText;
        private int pageWidth;
        private int pageHeight;

        BillPrintAdapter(String billText) { this.billText = billText == null ? "" : billText; }

        @Override
        public void onLayout(PrintAttributes oldAttributes, PrintAttributes newAttributes,
                              CancellationSignal cancellationSignal, LayoutResultCallback callback,
                              android.os.Bundle extras) {
            pageWidth = newAttributes.getMediaSize().getWidthMils() * 72 / 1000;
            pageHeight = newAttributes.getMediaSize().getHeightMils() * 72 / 1000;
            PrintDocumentInfo info = new PrintDocumentInfo.Builder("Kachi_Parchi_Bill.pdf")
                    .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                    .setPageCount(1)
                    .build();
            callback.onLayoutFinished(info, true);
        }

        @Override
        public void onWrite(PageRange[] pages, ParcelFileDescriptor destination,
                            CancellationSignal cancellationSignal, WriteResultCallback callback) {
            android.graphics.pdf.PdfDocument pdf = new android.graphics.pdf.PdfDocument();
            Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
            paint.setColor(android.graphics.Color.BLACK);
            paint.setTextSize(11);
            Paint title = new Paint(Paint.ANTI_ALIAS_FLAG);
            title.setColor(android.graphics.Color.BLACK);
            title.setTextSize(20);
            title.setTypeface(Typeface.DEFAULT_BOLD);
            android.graphics.pdf.PdfDocument.Page page = null;
            try {
                page = pdf.startPage(new android.graphics.pdf.PdfDocument.PageInfo.Builder(
                        pageWidth, pageHeight, 1).create());
                Canvas c = page.getCanvas();
                float x = 36, y = 45;
                c.drawText("KACHI PARCHI", x, y, title);
                y += 28;
                String[] lines = billText.split("\\n", -1);
                for (String line : lines) {
                    if (y > pageHeight - 45) break;
                    c.drawText(line, x, y, paint);
                    y += 17;
                }
                pdf.finishPage(page);
                if (cancellationSignal.isCanceled()) {
                    callback.onWriteCancelled();
                    return;
                }
                pdf.writeTo(new java.io.FileOutputStream(destination.getFileDescriptor()));
                callback.onWriteFinished(new PageRange[]{PageRange.ALL_PAGES});
            } catch (Exception e) {
                callback.onWriteFailed(e.getMessage());
            } finally {
                pdf.close();
                try { destination.close(); } catch (Exception ignored) {}
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
