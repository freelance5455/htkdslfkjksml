package com.nishant.livechats;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.DownloadListener;
import android.webkit.URLUtil;
import android.Manifest;
import android.app.DownloadManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Environment;
import java.util.ArrayList;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private WebView web;
    private ValueCallback<Uri[]> pending;
    private static final int PICK = 11;
    private static final int GSIGN = 12;
    private static final int PERM_ALL = 13;
    private static final int PERM_WEB = 14;
    private PermissionRequest webPerm;

    private boolean has(String p) {
        return Build.VERSION.SDK_INT < 23 || checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED;
    }

    /** Mic, Camera, Files/Storage: app khulte hi permission maango */
    private void askAllPermissions() {
        if (Build.VERSION.SDK_INT < 23) return;
        ArrayList<String> need = new ArrayList<String>();
        String[] base = { Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA };
        for (String p : base) if (!has(p)) need.add(p);
        if (Build.VERSION.SDK_INT >= 33) {
            String[] m = { "android.permission.READ_MEDIA_IMAGES", "android.permission.READ_MEDIA_VIDEO", "android.permission.READ_MEDIA_AUDIO" };
            for (String p : m) if (!has(p)) need.add(p);
        } else {
            if (!has(Manifest.permission.READ_EXTERNAL_STORAGE)) need.add(Manifest.permission.READ_EXTERNAL_STORAGE);
            if (Build.VERSION.SDK_INT <= 28 && !has(Manifest.permission.WRITE_EXTERNAL_STORAGE)) need.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        }
        if (!need.isEmpty()) requestPermissions(need.toArray(new String[0]), PERM_ALL);
    }

    @Override
    public void onRequestPermissionsResult(int rq, String[] perms, int[] res) {
        super.onRequestPermissionsResult(rq, perms, res);
        if (rq == PERM_WEB && webPerm != null) {
            PermissionRequest r = webPerm; webPerm = null;
            ArrayList<String> ok = new ArrayList<String>();
            for (String x : r.getResources()) {
                if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(x) && has(Manifest.permission.RECORD_AUDIO)) ok.add(x);
                else if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(x) && has(Manifest.permission.CAMERA)) ok.add(x);
            }
            if (ok.isEmpty()) r.deny(); else r.grant(ok.toArray(new String[0]));
        }
    }
    private GoogleSignInClient gClient;

    private void jsCall(final String fn, final String arg) {
        final String js = fn + "(" + JSONObject.quote(arg) + ")";
        runOnUiThread(new Runnable() { public void run() { web.evaluateJavascript(js, null); } });
    }

    private GoogleSignInClient gClient() {
        if (gClient == null) {
            GoogleSignInOptions o = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.google_web_client_id))
                .requestEmail()
                .requestProfile()
                .build();
            gClient = GoogleSignIn.getClient(this, o);
        }
        return gClient;
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        askAllPermissions();
        web.setDownloadListener(new DownloadListener() {
            public void onDownloadStart(String url, String ua, String cd, String mime, long len) {
                try {
                    DownloadManager.Request q = new DownloadManager.Request(Uri.parse(url));
                    q.setMimeType(mime);
                    q.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    q.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, URLUtil.guessFileName(url, cd, mime));
                    ((DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE)).enqueue(q);
                } catch (Exception e) { }
            }
        });
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if ("file".equals(u.getScheme())) return false;
                String cur = v.getUrl();
                if (cur != null && !cur.startsWith("file:")) return false; // inside live server: stay in app
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception e) { }
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest req) {
                runOnUiThread(new Runnable() { public void run() {
                    ArrayList<String> need = new ArrayList<String>();
                    for (String x : req.getResources()) {
                        if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(x) && !has(Manifest.permission.RECORD_AUDIO)) need.add(Manifest.permission.RECORD_AUDIO);
                        if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(x) && !has(Manifest.permission.CAMERA)) need.add(Manifest.permission.CAMERA);
                    }
                    if (need.isEmpty()) { req.grant(req.getResources()); return; }
                    if (webPerm != null) webPerm.deny();
                    webPerm = req;
                    requestPermissions(need.toArray(new String[0]), PERM_WEB);
                } });
            }
            @Override
            public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (pending != null) pending.onReceiveValue(null);
                pending = cb;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                String[] acc = p.getAcceptTypes();
                String t = (acc != null && acc.length > 0 && acc[0] != null && acc[0].length() > 0) ? acc[0] : "*/*";
                i.setType(t);
                if (acc != null && acc.length > 1) i.putExtra(Intent.EXTRA_MIME_TYPES, acc);
                i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                try {
                    startActivityForResult(Intent.createChooser(i, "Choose file"), PICK);
                } catch (Exception e) {
                    pending = null;
                    return false;
                }
                return true;
            }
        });
        web.addJavascriptInterface(new Object() {
            @JavascriptInterface
            public void openServer(final String url) {
                runOnUiThread(new Runnable() { public void run() { web.loadUrl(url); } });
            }
            @JavascriptInterface
            public String defaultBackend() { return getString(R.string.default_backend_url); }
            @JavascriptInterface
            public void googleSignIn() {
                runOnUiThread(new Runnable() { public void run() {
                    try {
                        if (getString(R.string.google_web_client_id).startsWith("PASTE_")) {
                            jsCall("onGoogleError", "Web client ID set nahi hai (strings.xml)");
                            return;
                        }
                        // purana account yaad na rahe: har baar account chooser dikhe
                        gClient().signOut().addOnCompleteListener(new com.google.android.gms.tasks.OnCompleteListener<Void>() {
                            public void onComplete(Task<Void> t) {
                                startActivityForResult(gClient().getSignInIntent(), GSIGN);
                            }
                        });
                    } catch (Exception e) { jsCall("onGoogleError", String.valueOf(e.getMessage())); }
                } });
            }
            @JavascriptInterface
            public void googleSignOut() {
                runOnUiThread(new Runnable() { public void run() { try { gClient().signOut(); } catch (Exception e) { } } });
            }
        }, "Native");
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onActivityResult(int rq, int rs, Intent d) {
        if (rq == GSIGN) {
            Task<GoogleSignInAccount> t = GoogleSignIn.getSignedInAccountFromIntent(d);
            try {
                GoogleSignInAccount a = t.getResult(ApiException.class);
                String tok = a.getIdToken();
                if (tok == null) jsCall("onGoogleError", "Google ne token nahi diya");
                else jsCall("onGoogleToken", tok);
            } catch (ApiException e) {
                // 12501 = user ne cancel kiya, 10 = SHA-1/client ID galat
                jsCall("onGoogleError", e.getStatusCode() == 12501 ? "cancelled" : "Google sign-in error " + e.getStatusCode());
            }
        } else if (rq == PICK && pending != null) {
            Uri[] r = null;
            if (rs == RESULT_OK && d != null) {
                if (d.getClipData() != null) {
                    int n = d.getClipData().getItemCount();
                    r = new Uri[n];
                    for (int i = 0; i < n; i++) r[i] = d.getClipData().getItemAt(i).getUri();
                } else if (d.getData() != null) {
                    r = new Uri[]{d.getData()};
                }
            }
            pending.onReceiveValue(r);
            pending = null;
        } else {
            super.onActivityResult(rq, rs, d);
        }
    }

    @Override
    public void onBackPressed() {
        String cur = web.getUrl();
        if (cur != null && !cur.startsWith("file:")) {
            if (web.canGoBack()) web.goBack(); else web.loadUrl("file:///android_asset/index.html");
            return;
        }
        web.evaluateJavascript(
            "(function(){var p=document.getElementById('pg');if(p&&p.classList.contains('on')){hp();return 1}var s=document.getElementById('store');if(s&&s.classList.contains('on')){closeOv('store');return 1}return 0})()",
            new ValueCallback<String>() {
                @Override
                public void onReceiveValue(String v) {
                    if (!"1".equals(v)) finish();
                }
            });
    }
}
