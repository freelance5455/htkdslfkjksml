package com.droidstick.mouse

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.MotionEvent
import android.view.accessibility.AccessibilityManager
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var statusText: TextView
    private lateinit var btnEnableService: Button
    private lateinit var btnOverlayPermission: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        btnEnableService = findViewById(R.id.btnEnableAccessibility)
        btnOverlayPermission = findViewById(R.id.btnOverlayPermission)

        btnEnableService.setOnClickListener {
            // Open Android Accessibility Settings
            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            startActivity(intent)
        }

        btnOverlayPermission.setOnClickListener {
            // Open Display Over Other Apps Settings
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivity(intent)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        updatePermissionStates()
    }

    private fun updatePermissionStates() {
        val isServiceActive = isAccessibilityServiceEnabled(GamepadMouseService::class.java)
        val hasOverlay = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(this)
        } else {
            true
        }

        statusText.text = when {
            isServiceActive && hasOverlay -> "READY: Gamepad Mouse is ACTIVE! Use Left Stick to move cursor, Right Stick to scroll, X to select."
            !hasOverlay -> "ATTENTION: 'Display over other apps' permission required."
            else -> "ATTENTION: Enable 'DroidStick Gamepad Mouse' in Accessibility Services."
        }
    }

    private fun isAccessibilityServiceEnabled(serviceClass: Class<*>): Boolean {
        val am = getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
        val enabledServices = am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
        for (service in enabledServices) {
            if (service.resolveInfo.serviceInfo.name == serviceClass.name) {
                return true
            }
        }
        return false
    }

    /**
     * Forward joystick motion events to the active service instance
     */
    override fun onGenericMotionEvent(event: MotionEvent): Boolean {
        // Broadcast or pass directly to active service instance
        return super.onGenericMotionEvent(event)
    }
}