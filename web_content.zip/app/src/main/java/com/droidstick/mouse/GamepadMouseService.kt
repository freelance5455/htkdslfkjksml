package com.droidstick.mouse

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.*
import android.widget.ImageView
import kotlin.math.abs
import kotlin.math.pow

/**
 * DroidStick Gamepad Mouse Accessibility Service
 * Requires Android 7.0 (API Level 24) or higher for dispatchGesture support.
 */
class GamepadMouseService : AccessibilityService() {

    private lateinit var windowManager: WindowManager
    private var cursorView: ImageView? = null
    private lateinit var cursorParams: WindowManager.LayoutParams

    private var screenWidth = 1080
    private var screenHeight = 2400

    // Cursor position in screen pixels
    private var cursorX = 540f
    private var cursorY = 1200f

    // Configurable parameters
    private var cursorSpeed = 22f
    private var deadzone = 0.15f
    private var scrollSpeed = 16f

    // Polling & loop handler
    private val mainHandler = Handler(Looper.getMainLooper())
    private var isDragging = false
    private var lastScrollTime = 0L

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        updateScreenDimensions()
        createFloatingCursor()
    }

    private fun updateScreenDimensions() {
        val display = windowManager.defaultDisplay
        val metrics = DisplayMetrics()
        display.getRealMetrics(metrics)
        screenWidth = metrics.widthPixels
        screenHeight = metrics.heightPixels
    }

    private fun createFloatingCursor() {
        // Overlay type for Android 7.0+ (API 24/26)
        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
        }

        cursorParams = WindowManager.LayoutParams(
            48, 48,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = cursorX.toInt()
            y = cursorY.toInt()
        }

        cursorView = ImageView(this).apply {
            // Distinct modern teardrop mouse pointer with ring
            val shape = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#4F46E5"))
                setStroke(4, Color.WHITE)
            }
            background = shape
            elevation = 16f
        }

        try {
            windowManager.addView(cursorView, cursorParams)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * Intercepts Generic Motion Events from Bluetooth Controllers
     * (Left Stick = Axis X/Y, Right Stick = Axis Z/RZ)
     */
    fun handleControllerMotion(event: MotionEvent): Boolean {
        if (event.source and InputDevice.SOURCE_JOYSTICK != InputDevice.SOURCE_JOYSTICK &&
            event.source and InputDevice.SOURCE_GAMEPAD != InputDevice.SOURCE_GAMEPAD) {
            return false
        }

        // 1. LEFT STICK: Cursor Movement
        val rawLeftX = event.getAxisValue(MotionEvent.AXIS_X)
        val rawLeftY = event.getAxisValue(MotionEvent.AXIS_Y)

        val leftX = applyDeadzoneAndCurve(rawLeftX)
        val leftY = applyDeadzoneAndCurve(rawLeftY)

        if (leftX != 0f || leftY != 0f) {
            cursorX = (cursorX + leftX * cursorSpeed).coerceIn(0f, screenWidth.toFloat())
            cursorY = (cursorY + leftY * cursorSpeed).coerceIn(0f, screenHeight.toFloat())

            cursorParams.x = cursorX.toInt()
            cursorParams.y = cursorY.toInt()

            cursorView?.let {
                windowManager.updateViewLayout(it, cursorParams)
            }
        }

        // 2. RIGHT STICK: Scrolling (Vertical & Horizontal)
        var rawRightX = event.getAxisValue(MotionEvent.AXIS_Z)
        var rawRightY = event.getAxisValue(MotionEvent.AXIS_RZ)

        // Fallback for some HID controllers using RX/RY
        if (rawRightX == 0f && rawRightY == 0f) {
            rawRightX = event.getAxisValue(MotionEvent.AXIS_RX)
            rawRightY = event.getAxisValue(MotionEvent.AXIS_RY)
        }

        val rightX = applyDeadzoneAndCurve(rawRightX)
        val rightY = applyDeadzoneAndCurve(rawRightY)

        val now = System.currentTimeMillis()
        if ((rightX != 0f || rightY != 0f) && now - lastScrollTime > 75) {
            lastScrollTime = now
            dispatchScrollGesture(-rightX * scrollSpeed * 10f, -rightY * scrollSpeed * 10f)
        }

        return true
    }

    /**
     * Intercepts Key Events from Bluetooth Controllers
     * (Button X / A = Select Tap, Button B = Back, Button Y = Home)
     */
    override fun onKeyEvent(event: KeyEvent): Boolean {
        val keyCode = event.keyCode
        val action = event.action

        // X Button or A Button (KEYCODE_BUTTON_A = 96, KEYCODE_BUTTON_X = 99)
        if (keyCode == KeyEvent.KEYCODE_BUTTON_A || keyCode == KeyEvent.KEYCODE_BUTTON_X) {
            if (action == KeyEvent.ACTION_DOWN && !isDragging) {
                isDragging = true
                dispatchTapGesture(cursorX, cursorY)
                highlightCursor(true)
                return true
            } else if (action == KeyEvent.ACTION_UP) {
                isDragging = false
                highlightCursor(false)
                return true
            }
        }

        // B Button (Back)
        if (keyCode == KeyEvent.KEYCODE_BUTTON_B && action == KeyEvent.ACTION_DOWN) {
            performGlobalAction(GLOBAL_ACTION_BACK)
            return true
        }

        // Y Button (Home)
        if (keyCode == KeyEvent.KEYCODE_BUTTON_Y && action == KeyEvent.ACTION_DOWN) {
            performGlobalAction(GLOBAL_ACTION_HOME)
            return true
        }

        return super.onKeyEvent(event)
    }

    /**
     * Injects a tap gesture at the current cursor coordinates.
     * Uses AccessibilityService.dispatchGesture (Introduced in Android 7.0 / API 24).
     */
    private fun dispatchTapGesture(x: Float, y: Float) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return

        val path = Path().apply {
            moveTo(x, y)
        }

        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 50))
            .build()

        dispatchGesture(gesture, null, null)
    }

    /**
     * Injects a smooth scroll swipe gesture originating near the cursor.
     */
    private fun dispatchScrollGesture(deltaX: Float, deltaY: Float) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return

        val startX = cursorX
        val startY = cursorY
        val endX = (cursorX + deltaX).coerceIn(50f, (screenWidth - 50).toFloat())
        val endY = (cursorY + deltaY).coerceIn(50f, (screenHeight - 50).toFloat())

        val path = Path().apply {
            moveTo(startX, startY)
            lineTo(endX, endY)
        }

        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 100))
            .build()

        dispatchGesture(gesture, null, null)
    }

    private fun highlightCursor(active: Boolean) {
        cursorView?.scaleX = if (active) 0.8f else 1.0f
        cursorView?.scaleY = if (active) 0.8f else 1.0f
    }

    private fun applyDeadzoneAndCurve(value: Float): Float {
        val absVal = abs(value)
        if (absVal < deadzone) return 0f
        val scaled = (absVal - deadzone) / (1f - deadzone)
        val curved = scaled.pow(1.8f) // Subtle exponential curve for high accuracy
        return if (value < 0) -curved else curved
    }

    override fun onAccessibilityEvent(event: android.view.accessibility.AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        super.onDestroy()
        cursorView?.let {
            try {
                windowManager.removeView(it)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}