package com.phierri.panel;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.TextView;

public class FloatingPanelService extends Service {
    private WindowManager wm;
    private LinearLayout panel;
    private WindowManager.LayoutParams params;
    private float downX, downY;
    private int startX, startY;
    private int touchSlop = 8;
    private boolean moved = false;

    @Override public void onCreate() {
        super.onCreate();
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return; }
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        int type = android.os.Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
        params = new WindowManager.LayoutParams(
            (int)(280 * getResources().getDisplayMetrics().density),
            (int)(360 * getResources().getDisplayMetrics().density),
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 8; params.y = 70;

        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.rgb(21,21,25)); bg.setCornerRadius(24); bg.setStroke(2, Color.rgb(200,16,46));
        panel.setBackground(bg);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(12,6,8,6);
        bar.setBackgroundColor(Color.rgb(33,14,19));
        TextView title = new TextView(this);
        title.setText("PHIERRI PANEL  ↕");
        title.setTextColor(Color.rgb(255,51,75)); title.setTypeface(Typeface.DEFAULT_BOLD); title.setTextSize(15);
        bar.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        TextView close = new TextView(this);
        close.setText("×"); close.setTextSize(26); close.setTextColor(Color.WHITE); close.setGravity(Gravity.CENTER);
        bar.addView(close, new LinearLayout.LayoutParams(38, 42));
        panel.addView(bar, new LinearLayout.LayoutParams(-1, -2));

        WebView web = new WebView(this);
        web.setBackgroundColor(Color.rgb(21,21,25));
        web.getSettings().setJavaScriptEnabled(true);
        web.setWebViewClient(new WebViewClient());
        panel.addView(web, new LinearLayout.LayoutParams(-1, 0, 1));
        web.loadUrl("file:///android_asset/index.html");

        bar.setOnTouchListener((v,e) -> {
            switch(e.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    downX=e.getRawX(); downY=e.getRawY(); startX=params.x; startY=params.y; moved=false; return true;
                case MotionEvent.ACTION_MOVE:
                    int dx=(int)(e.getRawX()-downX), dy=(int)(e.getRawY()-downY);
                    if (Math.abs(dx)>touchSlop || Math.abs(dy)>touchSlop) moved=true;
                    if (moved) { params.x=Math.max(0,startX+dx); params.y=Math.max(0,startY+dy); try { wm.updateViewLayout(panel,params); } catch(Exception ignored) {} }
                    return true;
                case MotionEvent.ACTION_UP: return true;
            }
            return true;
        });
        close.setOnClickListener(v -> stopSelf());
        try { wm.addView(panel, params); } catch(Exception ex) { stopSelf(); }
    }
    @Override public int onStartCommand(Intent i,int f,int id) { return START_STICKY; }
    @Override public void onDestroy() { if(wm!=null && panel!=null) try { wm.removeView(panel); } catch(Exception ignored) {} super.onDestroy(); }
    @Override public IBinder onBind(Intent i) { return null; }
}
