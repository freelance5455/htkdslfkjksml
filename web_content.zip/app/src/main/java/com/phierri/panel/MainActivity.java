package com.phierri.panel;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int REQ = 500;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(8,8,11));
        getWindow().setNavigationBarColor(Color.rgb(8,8,11));
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL); l.setPadding(28,42,28,28);
        l.setBackgroundColor(Color.rgb(12,12,16));
        TextView t = new TextView(this); t.setText("PHIERRI PANEL"); t.setTextColor(Color.rgb(255,51,75)); t.setTextSize(26);
        l.addView(t);
        TextView d = new TextView(this); d.setText("Ative a permissão para mostrar o painel completo sobre outros aplicativos. Depois, arraste a barra superior para mover e use o botão × para fechar."); d.setTextColor(Color.LTGRAY); d.setTextSize(16); d.setPadding(0,24,0,24); l.addView(d);
        Button start = new Button(this); start.setText("ATIVAR PAINEL FLUTUANTE"); l.addView(start);
        Button stop = new Button(this); stop.setText("FECHAR PAINEL FLUTUANTE"); l.addView(stop);
        setContentView(l);
        start.setOnClickListener(v -> {
            if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
                startActivityForResult(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName())), REQ);
            } else { startService(new Intent(this, FloatingPanelService.class)); finish(); }
        });
        stop.setOnClickListener(v -> { stopService(new Intent(this, FloatingPanelService.class)); });
    }
    @Override protected void onActivityResult(int r, int c, Intent d) {
        super.onActivityResult(r,c,d);
        if (r == REQ && (Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this))) {
            startService(new Intent(this, FloatingPanelService.class)); finish();
        }
    }
}
