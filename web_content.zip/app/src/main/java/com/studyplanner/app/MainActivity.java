package com.studyplanner.app;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.*;
import android.widget.Toast;
import java.io.OutputStream;

public class MainActivity extends Activity {
    private WebView web;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_REQ = 1001;

    private static final String HOOK =
        "(function(){if(window.__hooked)return;window.__hooked=true;" +
        "var m={},o=URL.createObjectURL.bind(URL);" +
        "URL.createObjectURL=function(b){var u=o(b);m[u]=b;return u;};" +
        "document.addEventListener(\"click\",function(e){var a=e.target.closest&&e.target.closest(\"a[download]\");" +
        "if(!a||!m[a.href])return;e.preventDefault();var b=m[a.href],n=a.getAttribute(\"download\")||\"file\",r=new FileReader();" +
        "r.onloadend=function(){AndroidSave.save(n,b.type||\"application/octet-stream\",String(r.result).split(\",\")[1]||\"\");};" +
        "r.readAsDataURL(b);},true);})();";

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        setContentView(web);
        web.setBackgroundColor(0xFF12151C);
        web.setLayerType(android.view.View.LAYER_TYPE_HARDWARE, null);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setBlockNetworkLoads(true);
        s.setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
        s.setSafeBrowsingEnabled(false);
        s.setGeolocationEnabled(false);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setSupportZoom(false);
        web.addJavascriptInterface(new Object() {
            @JavascriptInterface
            public void save(String name, String mime, String b64) {
                try {
                    ContentValues v = new ContentValues();
                    v.put(MediaStore.Downloads.DISPLAY_NAME, name);
                    v.put(MediaStore.Downloads.MIME_TYPE, mime);
                    v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                    Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                    try (OutputStream o = getContentResolver().openOutputStream(u)) {
                        o.write(Base64.decode(b64, Base64.DEFAULT));
                    }
                    toast("ذخیره شد در پوشه Download: " + name);
                } catch (Exception e) {
                    toast("خطا در ذخیره فایل");
                }
            }
        }, "AndroidSave");
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView v, String url) { v.evaluateJavascript(HOOK, null); }
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if ("file".equals(u.getScheme())) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) {}
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = cb;
                try { startActivityForResult(p.createIntent(), FILE_REQ); }
                catch (Exception e) { filePathCallback = null; return false; }
                return true;
            }
            @Override public boolean onJsAlert(WebView v, String url, String msg, JsResult r) {
                new android.app.AlertDialog.Builder(MainActivity.this).setMessage(msg)
                    .setPositiveButton("باشه", (d, i) -> r.confirm()).setOnCancelListener(d -> r.cancel()).show();
                return true;
            }
            @Override public boolean onJsConfirm(WebView v, String url, String msg, JsResult r) {
                new android.app.AlertDialog.Builder(MainActivity.this).setMessage(msg)
                    .setPositiveButton("تایید", (d, i) -> r.confirm())
                    .setNegativeButton("انصراف", (d, i) -> r.cancel())
                    .setOnCancelListener(d -> r.cancel()).show();
                return true;
            }
        });
        if (b == null) web.loadUrl("file:///android_asset/index.html"); else web.restoreState(b);
    }

    private void toast(String m) { runOnUiThread(() -> Toast.makeText(this, m, Toast.LENGTH_LONG).show()); }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        if (req == FILE_REQ && filePathCallback != null) {
            filePathCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
            filePathCallback = null;
        } else super.onActivityResult(req, res, data);
    }

    @Override protected void onSaveInstanceState(Bundle o) { super.onSaveInstanceState(o); web.saveState(o); }
    @Override public void onBackPressed() { if (web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
