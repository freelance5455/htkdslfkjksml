package com.fixmaster.obd2

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.launch

class MainActivity:ComponentActivity(){
    private val obd=Obd2Manager()
    private val bt by lazy{BluetoothAdapter.getDefaultAdapter()}
    private val req=registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()){}
    override fun onCreate(b:Bundle?){super.onCreate(b)
        if(android.os.Build.VERSION.SDK_INT>=31) req.launch(arrayOf(Manifest.permission.BLUETOOTH_CONNECT,Manifest.permission.BLUETOOTH_SCAN))
        setContent{App()}
    }

    @SuppressLint("MissingPermission")
    @Composable fun App(){
        val scope=rememberCoroutineScope()
        var status by remember{mutableStateOf("Pair your Bluetooth OBD2 adapter in Android settings, then connect it here.")}
        var vehicle by remember{mutableStateOf(Vehicle(2015,"Hyundai","Elantra","1.8L"))}
        var year by remember{mutableStateOf("2015")}; var make by remember{mutableStateOf("Hyundai")}
        var model by remember{mutableStateOf("Elantra")}; var engine by remember{mutableStateOf("1.8L")}
        var codes by remember{mutableStateOf(listOf<String>())}
        var pending by remember{mutableStateOf(listOf<String>())}
        var selectedSymptoms by remember{mutableStateOf(setOf<String>())}
        var expandedCode by remember{mutableStateOf<String?>(null)}

        MaterialTheme{Scaffold(topBar={TopAppBar(title={Text("OBD2 FixMaster v3")})}){pad->
            LazyColumn(Modifier.padding(pad).padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
                item{
                    Text("VEHICLE PROFILE",style=MaterialTheme.typography.titleMedium)
                    Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){field(year,"Year"){year=it};field(make,"Make"){make=it}}
                    Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){field(model,"Model"){model=it};field(engine,"Engine"){engine=it}}
                    Button(onClick={vehicle=Vehicle(year.toIntOrNull()?:2015,make,model,engine)},modifier=Modifier.fillMaxWidth()){Text("USE THIS VEHICLE")}
                }
                item{
                    Text("SYMPTOMS — select everything that applies",style=MaterialTheme.typography.titleMedium)
                    DiagnosticEngine.symptoms.forEach{s->
                        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){
                            Text(s.name,Modifier.weight(1f))
                            Checkbox(selectedSymptoms.contains(s.id),onCheckedChange={checked->
                                selectedSymptoms=if(checked) selectedSymptoms+s.id else selectedSymptoms-s.id
                            })
                        }
                    }
                }
                item{
                    Text("BLUETOOTH OBD2",style=MaterialTheme.typography.titleMedium)
                    val paired=try{bt?.bondedDevices?.toList()?:emptyList()}catch(_:Exception){emptyList()}
                    paired.forEach{d->
                        Button(onClick={scope.launch{status="Connecting…";try{status=obd.connect(d)}catch(e:Exception){status="Connection failed: ${e.message}"}}},modifier=Modifier.fillMaxWidth()){
                            Text("Connect ${d.name?:d.address}")
                        }
                    }
                    Text(status)
                }
                item{
                    Text("SCAN",style=MaterialTheme.typography.titleMedium)
                    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
                        Button(onClick={scope.launch{try{codes=obd.scanCodes();pending=obd.pendingCodes();status="Scan complete"}catch(e:Exception){status="Scan failed: ${e.message}"}}}){Text("SCAN")}
                        OutlinedButton(onClick={scope.launch{try{obd.clearCodes();codes=emptyList();pending=emptyList();status="Clear command sent"}catch(e:Exception){status="Clear failed: ${e.message}"}}}){Text("CLEAR")}
                    }
                    if(pending.isNotEmpty())Text("Pending: ${pending.joinToString()}")
                }
                items(codes){code->
                    val plan=DiagnosticEngine.plan(vehicle,code,selectedSymptoms)
                    Card{Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
                        Text(code,style=MaterialTheme.typography.headlineSmall);Text(plan.headline,style=MaterialTheme.typography.titleMedium)
                        Text(plan.confidenceNote)
                        Text("Likely areas:")
                        plan.likelyCauses.forEach{Text("• $it")}
                        Button(onClick={expandedCode=if(expandedCode==code)null else code}){Text(if(expandedCode==code)"HIDE DIAGNOSTIC PLAN" else "START GUIDED DIAGNOSIS")}
                        if(expandedCode==code)plan.steps.forEach{step->
                            HorizontalDivider()
                            Text(step.title,style=MaterialTheme.typography.titleMedium)
                            Text("Why: ${step.why}")
                            Text("Do: ${step.action}")
                            Text("PASS → ${step.pass}")
                            Text("FAIL → ${step.fail}")
                            Button(onClick={
                                val q=Uri.encode(step.videoQuery)
                                startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://www.youtube.com/results?search_query=$q")))
                            }){Text("▶ FIND REPAIR VIDEO")}
                        }
                    }}
                }
                item{Text("The app uses standard generic OBD-II services where available; manufacturer-specific modules and exact test specifications may require additional vehicle-specific interfaces/service information. SAE J1979 defines the standardized diagnostic services and notes that applicability varies by vehicle, engine and model year.")}
            }
        }}
    }
    @Composable private fun field(v:String,label:String,on:(String)->Unit){
        OutlinedTextField(v,on,label= {Text(label)},modifier=Modifier.weight(1f))
    }
    override fun onDestroy(){obd.close();super.onDestroy()}
}
