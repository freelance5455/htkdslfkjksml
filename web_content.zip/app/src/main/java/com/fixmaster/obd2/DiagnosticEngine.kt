package com.fixmaster.obd2

data class Vehicle(
    val year: Int,
    val make: String,
    val model: String,
    val engine: String
)

data class Symptom(val id: String, val name: String)

data class DiagnosticStep(
    val title: String,
    val why: String,
    val action: String,
    val pass: String,
    val fail: String,
    val videoQuery: String
)

data class DiagnosticPlan(
    val headline: String,
    val confidenceNote: String,
    val likelyCauses: List<String>,
    val steps: List<DiagnosticStep>
)

object DiagnosticEngine {
    val symptoms = listOf(
        Symptom("long_crank", "Long crank / takes several seconds to start"),
        Symptom("rough_idle", "Rough or unstable idle"),
        Symptom("no_power", "Weak / no power under load"),
        Symptom("stalling", "Stalls or dies"),
        Symptom("hard_start", "Hard starting"),
        Symptom("misfire", "Misfire / shaking"),
        Symptom("poor_mpg", "Poor fuel economy"),
        Symptom("rattle", "Engine rattle / timing noise"),
        Symptom("no_start", "Cranks but will not start"),
        Symptom("other", "Other / symptom not listed")
    )

    fun plan(v: Vehicle, code: String, selectedSymptoms: Set<String>): DiagnosticPlan {
        val isElantra18 = v.year == 2015 &&
            v.make.equals("Hyundai", true) &&
            v.model.equals("Elantra", true) &&
            v.engine.contains("1.8", true)

        if (isElantra18) {
            when (code.uppercase()) {
                "P0340" -> return elantraP0340(selectedSymptoms)
                "P0017" -> return elantraP0017(selectedSymptoms)
                "P0014" -> return elantraP0014(selectedSymptoms)
            }
        }

        return generic(code, v, selectedSymptoms)
    }

    private fun elantraP0340(s: Set<String>): DiagnosticPlan {
        val crank = "long_crank" in s || "hard_start" in s || "no_start" in s
        return DiagnosticPlan(
            "2015 Hyundai Elantra 1.8L — P0340 diagnostic path",
            if (crank) "The starting symptom increases the importance of checking the cam signal during cranking, but P0340 does not by itself prove the sensor is bad."
            else "P0340 identifies a camshaft-position circuit problem; the sensor, wiring, power/ground, signal, or related timing issue can be responsible.",
            listOf(
                "Camshaft position sensor or connector",
                "Open/shorted wiring or poor terminal contact",
                "Sensor power/ground problem",
                "Cam/crank signal or mechanical timing issue"
            ),
            listOf(
                DiagnosticStep(
                    "1. Inspect the cam sensor connector and harness",
                    "Intermittent wiring faults can create the same code as a failed sensor.",
                    "With ignition off, inspect pins, oil intrusion, broken insulation and harness routing near the sensor.",
                    "Connector is clean, tight and wiring is intact → continue.",
                    "Damaged/corroded/loose wiring → repair it and rescan before buying a sensor.",
                    "2015 Hyundai Elantra 1.8 camshaft sensor wiring inspection"
                ),
                DiagnosticStep(
                    "2. Verify sensor power and ground",
                    "A good sensor cannot produce a correct signal without its required electrical supply and ground.",
                    "Use the vehicle wiring diagram and a multimeter. Verify the expected supply and ground with ignition on.",
                    "Power/ground are correct → continue.",
                    "Missing supply/ground → trace fuse, wiring, connector and ECU-side circuit.",
                    "Hyundai Elantra camshaft position sensor power ground test"
                ),
                DiagnosticStep(
                    "3. Check the cam signal while cranking",
                    "A sensor can have correct power yet fail to produce a usable switching signal.",
                    "Back-probe the signal using the appropriate meter/scope procedure for the engine and compare the signal while cranking.",
                    "Stable signal → investigate correlation/timing and intermittent faults.",
                    "No/incorrect signal → sensor or signal wiring becomes the primary suspect.",
                    "Hyundai Elantra camshaft sensor signal test oscilloscope"
                ),
                DiagnosticStep(
                    "4. If the signal is good, investigate cam/crank correlation",
                    "A timing/correlation problem can produce sensor-related codes even when the sensor itself works.",
                    "Check related timing/VVT data and mechanical timing if the electrical tests pass.",
                    "Correlation is correct → look for intermittent wiring/ECU-side faults.",
                    "Correlation is incorrect → diagnose timing/VVT/mechanical causes.",
                    "2015 Hyundai Elantra 1.8 cam crank correlation timing diagnosis"
                )
            )
        )
    }

    private fun elantraP0017(s: Set<String>): DiagnosticPlan {
        return DiagnosticPlan(
            "2015 Hyundai Elantra 1.8L — P0017 diagnostic path",
            "P0017 is a correlation code. Do not automatically replace a cam or crank sensor.",
            listOf("Mechanical timing/correlation issue","VVT system problem","Cam/crank sensor signal issue","Wiring or connector fault"),
            listOf(
                DiagnosticStep("1. Record freeze-frame and related codes",
                    "Related timing or sensor codes can change the diagnostic direction.",
                    "Save all stored/pending codes and freeze-frame information before clearing anything.",
                    "Complete data available → continue.",
                    "No data → continue with live data and inspection.",
                    "P0017 freeze frame diagnostic explanation"),
                DiagnosticStep("2. Check oil condition and VVT basics",
                    "VVT operation depends on the correct oil condition and functioning control system.",
                    "Verify correct oil level/condition and inspect the VVT solenoid/connectors.",
                    "Oil/VVT basics check out → continue.",
                    "Low/dirty oil or damaged VVT components → correct the issue and retest.",
                    "Hyundai Elantra 1.8 VVT P0017 diagnosis"),
                DiagnosticStep("3. Compare cam/crank signals",
                    "The code is fundamentally about correlation between these signals.",
                    "Use supported scan data or a scope procedure to compare the signals during crank/run conditions.",
                    "Signals correlate → investigate intermittent electrical issues.",
                    "Signals do not correlate → investigate timing/VVT/mechanical causes.",
                    "Hyundai cam crank correlation scope test"),
                DiagnosticStep("4. Verify mechanical timing if correlation remains wrong",
                    "A mechanical timing issue can mimic a sensor failure.",
                    "Follow the manufacturer's timing inspection procedure before condemning sensors.",
                    "Timing correct → return to electrical/VVT diagnosis.",
                    "Timing incorrect → repair timing issue and recheck.",
                    "Hyundai Elantra 1.8 timing chain timing marks")
            )
        )
    }

    private fun elantraP0014(s: Set<String>) = DiagnosticPlan(
        "2015 Hyundai Elantra 1.8L — P0014 diagnostic path",
        "P0014 points toward exhaust-cam timing/VVT performance. A sensor is only one possible cause.",
        listOf("VVT solenoid/control issue","Oil flow/condition problem","Cam position signal issue","Mechanical timing problem"),
        listOf(
            DiagnosticStep("1. Check oil level and condition",
                "VVT systems rely on oil pressure and clean oil passages.",
                "Verify level, correct specification and condition.",
                "Oil is correct → continue.",
                "Oil issue found → correct it and retest.",
                "Hyundai Elantra 1.8 VVT oil P0014 diagnosis"),
            DiagnosticStep("2. Inspect/test exhaust VVT control",
                "A sticking or electrically faulty control valve can prevent commanded cam movement.",
                "Inspect connector and test the valve according to the service procedure.",
                "Control system responds correctly → continue.",
                "Control fault found → repair/test and rescan.",
                "2015 Hyundai Elantra 1.8 exhaust VVT solenoid test"),
            DiagnosticStep("3. Verify cam position feedback",
                "The ECU needs a trustworthy cam signal to determine actual position.",
                "Check cam sensor wiring/signal and compare commanded versus actual cam position when supported.",
                "Feedback is credible → continue.",
                "Feedback is faulty → diagnose sensor/circuit.",
                "Hyundai Elantra camshaft sensor test"),
            DiagnosticStep("4. Investigate mechanical timing",
                "Mechanical timing problems can prevent the commanded cam position from being achieved.",
                "Follow the manufacturer timing inspection procedure.",
                "Timing correct → investigate remaining VVT/control causes.",
                "Timing incorrect → repair mechanical timing and retest.",
                "Hyundai Elantra 1.8 timing chain inspection")
        )
    )

    private fun generic(code: String, v: Vehicle, s: Set<String>): DiagnosticPlan {
        val symptomText = if (s.isEmpty()) "No symptoms selected." else s.joinToString(", ")
        return DiagnosticPlan(
            "${v.year} ${v.make} ${v.model} ${v.engine} — $code",
            "Generic OBD-II guidance. Manufacturer-specific service information should be used for exact test values and wiring.",
            listOf("Sensor/actuator fault","Power/ground or wiring fault","Connector problem","Mechanical/system fault"),
            listOf(
                DiagnosticStep("1. Save all codes and freeze-frame data",
                    "Codes often need context from the conditions under which they set.",
                    "Record stored, pending and available freeze-frame information before clearing codes.",
                    "Data captured → continue.",
                    "Data unavailable → continue with live data.",
                    "$code freeze frame diagnosis"),
                DiagnosticStep("2. Inspect the related circuit",
                    "Many diagnostic codes are caused by wiring, connectors, power or ground rather than the named component.",
                    "Inspect connector condition, harness damage, grounds and relevant fuses.",
                    "Circuit looks correct → continue.",
                    "Circuit fault found → repair and retest.",
                    "${v.year} ${v.make} ${v.model} $code wiring diagnosis"),
                DiagnosticStep("3. Compare the code with symptoms",
                    "The symptom pattern helps prioritize the diagnostic path.",
                    "Selected symptoms: $symptomText. Check whether live data supports the suspected system.",
                    "Data supports the suspected system → continue targeted testing.",
                    "Data contradicts it → broaden the diagnosis.",
                    "${v.year} ${v.make} ${v.model} $code symptoms"),
                DiagnosticStep("4. Test before replacing parts",
                    "A trouble code identifies a monitored fault, not necessarily a failed part.",
                    "Use the manufacturer's test procedure and specifications for the exact vehicle.",
                    "Test confirms component fault → replace/repair and verify.",
                    "Test passes → continue circuit/system diagnosis.",
                    "${v.year} ${v.make} ${v.model} $code repair diagnosis")
            )
        )
    }
}
