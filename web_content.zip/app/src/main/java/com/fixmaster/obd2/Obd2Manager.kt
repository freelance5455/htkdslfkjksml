package com.fixmaster.obd2

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID

class Obd2Manager {
    private val uuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private var socket: BluetoothSocket? = null
    private var input: InputStream? = null
    private var output: OutputStream? = null

    @SuppressLint("MissingPermission")
    suspend fun connect(device: BluetoothDevice): String = withContext(Dispatchers.IO) {
        close()
        socket = device.createRfcommSocketToServiceRecord(uuid)
        socket!!.connect()
        input = socket!!.inputStream
        output = socket!!.outputStream
        listOf("ATZ","ATE0","ATL0","ATS0","ATH0","ATSP0").forEach { command(it,1500) }
        "Connected: ${device.name ?: "OBD adapter"}"
    }

    suspend fun scanCodes(): List<String> = withContext(Dispatchers.IO) { parseDtc(command("03",5000)) }
    suspend fun pendingCodes(): List<String> = withContext(Dispatchers.IO) { parseDtc(command("07",5000)) }
    suspend fun freezeFrame(): String = withContext(Dispatchers.IO) { command("02",5000).trim() }
    suspend fun clearCodes(): String = withContext(Dispatchers.IO) { command("04",5000).trim() }
    suspend fun pid(pid: String): String = withContext(Dispatchers.IO) { command(pid,2500).trim() }

    private fun command(cmd:String, timeout:Long):String {
        val out=output ?: error("Not connected"); val ins=input ?: error("Not connected")
        while(ins.available()>0) ins.read()
        out.write((cmd+"\r").toByteArray()); out.flush()
        val end=System.currentTimeMillis()+timeout; val sb=StringBuilder()
        while(System.currentTimeMillis()<end) {
            while(ins.available()>0) { val c=ins.read().toChar(); sb.append(c); if(c=='>') return sb.toString() }
            Thread.sleep(20)
        }
        return sb.toString()
    }

    private fun parseDtc(raw:String):List<String> {
        val clean=raw.uppercase().replace("SEARCHING...","").replace("43"," ").replace("47"," ")
            .replace(">"," ").replace("\r"," ").replace("\n"," ")
        return clean.split(Regex("\\s+")).filter { it.matches(Regex("[0-9A-F]{4}")) }.mapNotNull {
            val n=it.toIntOrNull(16) ?: return@mapNotNull null
            if(n==0) null else String.format("%c%04d","PCBU"[(n shr 14) and 3],n and 0x3FFF)
        }.distinct()
    }
    fun close(){try{socket?.close()}catch(_:Exception){};socket=null;input=null;output=null}
}
