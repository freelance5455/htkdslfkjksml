package com.harshai.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import android.graphics.Color;
import android.view.View;
import java.util.Locale;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
  private WebView web; private TextToSpeech tts; private boolean ready=false;
  @Override public void onCreate(Bundle b){ super.onCreate(b); getWindow().setStatusBarColor(Color.rgb(11,16,32)); getWindow().setNavigationBarColor(Color.rgb(11,16,32));
    web=new WebView(this); web.setBackgroundColor(Color.rgb(11,16,32)); web.getSettings().setJavaScriptEnabled(true); web.getSettings().setDomStorageEnabled(true); web.setWebViewClient(new WebViewClient()); web.addJavascriptInterface(new Bridge(),"HarshAndroid"); setContentView(web);
    tts=new TextToSpeech(this,status->{ ready=status==TextToSpeech.SUCCESS; if(ready){ tts.setOnUtteranceProgressListener(new UtteranceProgressListener(){
      @Override public void onStart(String id){}
      @Override public void onDone(String id){ callback("harshNativeDone",id,""); }
      @Override public void onError(String id){ callback("harshNativeDone",id,"TTS_ERROR"); }
      @Override public void onRangeStart(String id,int start,int end,int frame){ callback("harshNativeBoundary",id,Integer.toString(start)); }
    }); runOnUiThread(()->web.evaluateJavascript("if(window.fillNativeVoices){window.fillNativeVoices();}",null)); }});
    web.loadUrl("file:///android_asset/index.html");
  }
  private void callback(String fn,String id,String value){ runOnUiThread(()->{ try { String js="window."+fn+" && window."+fn+"("+JSONObject.quote(id)+","+JSONObject.quote(value)+")"; web.evaluateJavascript(js,null); } catch(Exception ignored){} }); }
  private class Bridge {
    @JavascriptInterface public String getVoices(){ JSONArray a=new JSONArray(); if(ready){ Set<Voice> vs=tts.getVoices(); if(vs!=null) for(Voice v:vs){ try{ JSONObject o=new JSONObject(); o.put("name",v.getName()); o.put("lang",v.getLocale().toLanguageTag()); o.put("native",true); a.put(o); }catch(Exception ignored){} } } return a.toString(); }
    @JavascriptInterface public void speak(String text,String lang,float rate,String voiceName,String id){ runOnUiThread(()->{ if(!ready){callback("harshNativeDone",id,"NOT_READY");return;} try{ if(voiceName!=null&&!voiceName.isEmpty()){ Set<Voice> vs=tts.getVoices(); if(vs!=null) for(Voice v:vs) if(v.getName().equals(voiceName)){tts.setVoice(v);break;} } else if(lang!=null&&!lang.isEmpty()){ Locale l=Locale.forLanguageTag(lang); if(!l.getLanguage().isEmpty()) tts.setLanguage(l); } tts.setSpeechRate(Math.max(0.5f,Math.min(2f,rate))); tts.speak(text,TextToSpeech.QUEUE_FLUSH,null,id); }catch(Exception e){callback("harshNativeDone",id,"TTS_ERROR");} }); }
    @JavascriptInterface public void stop(){ runOnUiThread(()->{if(ready)tts.stop();}); }
  }
  @Override public void onBackPressed(){ if(web!=null&&web.canGoBack())web.goBack(); else super.onBackPressed(); }
  @Override protected void onDestroy(){ if(tts!=null){tts.stop();tts.shutdown();} if(web!=null)web.destroy(); super.onDestroy(); }
}
