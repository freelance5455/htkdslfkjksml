package com.qubex.party

import android.Manifest
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.*
import org.json.JSONObject
import java.nio.charset.StandardCharsets
import java.util.UUID

class MainActivity : ComponentActivity() {
    private lateinit var web: WebView
    private val connections by lazy { Nearby.getConnectionsClient(this) }
    private val serviceId = "com.qubex.party"
    private val strategy = Strategy.P2P_STAR
    private val endpointNames = mutableMapOf<String, String>()
    private var isHost = false

    private val lifecycle = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(endpointId: String, info: ConnectionInfo) {
            endpointNames[endpointId] = info.endpointName
            emit(mapOf("t" to "incoming", "id" to endpointId, "name" to info.endpointName))
            // The player has already chosen this peer in the lobby; accept and
            // attach the receive callback on both endpoints.
            connections.acceptConnection(endpointId, payloadCallback)
        }

        override fun onConnectionResult(endpointId: String, result: ConnectionResolution) {
            if (result.status.isSuccess) {
                endpointNames[endpointId] = endpointNames[endpointId] ?: endpointId.take(6)
                emit(mapOf("t" to "connected", "id" to endpointId, "name" to endpointNames[endpointId]!!))
            } else {
                emit(mapOf("t" to "error", "message" to "فشل الاتصال: ${result.status.statusMessage}"))
            }
        }

        override fun onDisconnected(endpointId: String) {
            val n = endpointNames.remove(endpointId) ?: endpointId.take(6)
            emit(mapOf("t" to "disconnected", "id" to endpointId, "name" to n))
        }
    }

    private val payloadCallback = object : PayloadCallback() {
        override fun onPayloadReceived(endpointId: String, payload: Payload) {
            val data = payload.asBytes()?.toString(StandardCharsets.UTF_8) ?: return
            emit(mapOf("t" to "data", "id" to endpointId, "data" to data))
        }
        override fun onPayloadTransferUpdate(endpointId: String, update: PayloadTransferUpdate) {}
    }

    private val discovery = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(endpointId: String, info: DiscoveredEndpointInfo) {
            endpointNames[endpointId] = info.endpointName
            emit(mapOf("t" to "found", "id" to endpointId, "name" to info.endpointName))
        }
        override fun onEndpointLost(endpointId: String) {
            endpointNames.remove(endpointId)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestNearbyPermissions()
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        web.webChromeClient = WebChromeClient()
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(Bridge(), "QubeNative")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    private fun requestNearbyPermissions() {
        val permissions = mutableListOf<String>()
        if (android.os.Build.VERSION.SDK_INT >= 31) {
            permissions += Manifest.permission.BLUETOOTH_SCAN
            permissions += Manifest.permission.BLUETOOTH_CONNECT
            permissions += Manifest.permission.BLUETOOTH_ADVERTISE
        }
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            permissions += Manifest.permission.NEARBY_WIFI_DEVICES
        } else if (android.os.Build.VERSION.SDK_INT >= 23) {
            permissions += Manifest.permission.ACCESS_FINE_LOCATION
        }
        val missing = permissions.filter { ContextCompat.checkSelfPermission(this, it) != android.content.pm.PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) ActivityCompat.requestPermissions(this, missing.toTypedArray(), 9001)
    }

    private fun emit(map: Map<String, String>) {
        val obj = JSONObject()
        map.forEach { (k,v) -> obj.put(k,v) }
        runOnUiThread {
            web.evaluateJavascript("window.onNativeEvent(${JSONObject.quote(obj.toString())})", null)
        }
    }

    private fun broadcastText(text: String) {
        val payload = Payload.fromBytes(text.toByteArray(StandardCharsets.UTF_8))
        connections.sendPayload(endpointNames.keys.toList(), payload)
    }

    inner class Bridge {
        @JavascriptInterface fun startHost(name: String) {
            isHost = true
            val opts = AdvertisingOptions.Builder().setStrategy(strategy).build()
            connections.startAdvertising(name, serviceId, lifecycle, opts)
                .addOnSuccessListener { emit(mapOf("t" to "state", "state" to "HOSTING", "room" to "QX-"+UUID.randomUUID().toString().take(4).uppercase())) }
                .addOnFailureListener { emit(mapOf("t" to "error", "message" to (it.message ?: "تعذر إنشاء الغرفة"))) }
        }

        @JavascriptInterface fun startDiscover() {
            isHost = false
            val opts = DiscoveryOptions.Builder().setStrategy(strategy).build()
            connections.startDiscovery(serviceId, discovery, opts)
                .addOnSuccessListener { emit(mapOf("t" to "state", "state" to "SEARCHING")) }
                .addOnFailureListener { emit(mapOf("t" to "error", "message" to (it.message ?: "تعذر البحث"))) }
        }

        @JavascriptInterface fun requestConnection(endpointId: String, name: String) {
            connections.requestConnection(name, endpointId, lifecycle)
                .addOnFailureListener { emit(mapOf("t" to "error", "message" to (it.message ?: "تعذر طلب الاتصال"))) }
        }

        @JavascriptInterface fun acceptConnection(endpointId: String) {
            connections.acceptConnection(endpointId, payloadCallback)
            endpointNames.putIfAbsent(endpointId, endpointId.take(6))
        }

        @JavascriptInterface fun broadcast(text: String) {
            broadcastText(text)
        }

        @JavascriptInterface fun stop() {
            connections.stopAdvertising()
            connections.stopDiscovery()
            connections.stopAllEndpoints()
            endpointNames.clear()
            emit(mapOf("t" to "state", "state" to "OFFLINE"))
        }
    }

    override fun onBackPressed() {
        if (::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
