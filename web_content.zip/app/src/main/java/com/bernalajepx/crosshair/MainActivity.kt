package com.bernalajepx.crosshair

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private val green = 0xFF39FF14.toInt()
    private val prefs by lazy { getSharedPreferences("jepx_panel", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (prefs.getBoolean("welcome_shown", false)) {
            showPanel()
        } else {
            showWelcome()
        }
    }

    private fun makeRoot(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        setPadding(28, 36, 28, 36)
        setBackgroundColor(0xFF080D09.toInt())
    }

    private fun makeButton(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            setOnClickListener { action() }
        }

    private fun showWelcome() {
        val root = makeRoot()
        val title = TextView(this).apply {
            text = "WELCOME TO\\nJEPX PANEL"
            textSize = 30f
            gravity = Gravity.CENTER
            setTextColor(green)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        val subtitle = TextView(this).apply {
            text = "Selamat datang!\\nPanel crosshair hijau neon siap digunakan."
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(0xFFE5EDE5.toInt())
            setPadding(0, 20, 0, 30)
        }
        root.addView(title, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(subtitle)
        root.addView(makeButton("MASUK KE JEPX PANEL") {
            prefs.edit().putBoolean("welcome_shown", true).apply()
            showPanel()
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(root)
    }

    private fun showPanel() {
        val root = makeRoot()
        val title = TextView(this).apply {
            text = "JEPX PANEL"
            textSize = 28f
            gravity = Gravity.CENTER
            setTextColor(green)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        val info = TextView(this).apply {
            text = "Crosshair hijau neon yang dapat dipindahkan dan tampil di atas aplikasi lain."
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(0xFFE5EDE5.toInt())
            setPadding(0, 18, 0, 26)
        }
        root.addView(title, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(info)
        root.addView(makeButton("AKTIFKAN CROSSHAIR") { enableOverlay() },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(makeButton("MATIKAN CROSSHAIR") {
            stopService(Intent(this@MainActivity, CrosshairService::class.java))
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = 12 })
        setContentView(root)
    }

    private fun enableOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            startActivity(intent)
            return
        }
        val intent = Intent(this, CrosshairService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
    }
}
