package com.bernalajepx.crosshair

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager

class CrosshairService : Service() {
    private lateinit var windowManager: WindowManager
    private var crosshairView: CrosshairView? = null
    private var layoutParams: WindowManager.LayoutParams? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        val notification = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("Bernala JepX Crosshair aktif")
                .setContentText("Crosshair mengambang sedang berjalan")
                .setSmallIcon(android.R.drawable.ic_menu_compass)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setContentTitle("Bernala JepX Crosshair aktif")
                .setContentText("Crosshair mengambang sedang berjalan")
                .setSmallIcon(android.R.drawable.ic_menu_compass)
                .build()
        }
        startForeground(1, notification)
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        showCrosshair()
    }

    private fun showCrosshair() {
        if (crosshairView != null) return
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            100, 100, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 450
            y = 700
        }
        val view = CrosshairView(this)
        try {
            windowManager.addView(view, params)
            crosshairView = view
            layoutParams = params
        } catch (_: Exception) {
            stopSelf()
        }
    }

    override fun onDestroy() {
        crosshairView?.let {
            try { windowManager.removeView(it) } catch (_: Exception) {}
        }
        crosshairView = null
        stopForeground(true)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Crosshair overlay", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private inner class CrosshairView(context: android.content.Context) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFF39FF14.toInt()
            strokeWidth = 5f
            style = Paint.Style.STROKE
            setShadowLayer(12f, 0f, 0f, 0xFF39FF14.toInt())
        }
        private var downX = 0f
        private var downY = 0f
        private var startX = 0
        private var startY = 0

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val cx = width / 2f
            val cy = height / 2f
            canvas.drawCircle(cx, cy, 8f, paint)
            canvas.drawLine(cx - 27, cy, cx - 13, cy, paint)
            canvas.drawLine(cx + 13, cy, cx + 27, cy, paint)
            canvas.drawLine(cx, cy - 27, cx, cy - 13, paint)
            canvas.drawLine(cx, cy + 13, cx, cy + 27, paint)
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            val params = layoutParams ?: return true
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX
                    downY = event.rawY
                    startX = params.x
                    startY = params.y
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX + (event.rawX - downX).toInt()
                    params.y = startY + (event.rawY - downY).toInt()
                    try { windowManager.updateViewLayout(this, params) } catch (_: Exception) {}
                    return true
                }
            }
            return true
        }
    }

    companion object { private const val CHANNEL_ID = "bernalajepx_crosshair" }
}
