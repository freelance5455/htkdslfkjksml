package com.sublimapro.app

import android.content.Intent
import android.database.Cursor
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import org.json.JSONObject
import java.io.ByteArrayOutputStream

class MainActivity : ComponentActivity() {

    private lateinit var webView: WebView
    private var pendingFileCallback: ValueCallback<Array<Uri>>? = null
    private var pendingNativeTarget: String? = null

    private val filePickerLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val uri = if (result.resultCode == RESULT_OK) {
                result.data?.data ?: result.data?.clipData?.let { clip ->
                    if (clip.itemCount > 0) clip.getItemAt(0).uri else null
                }
            } else null

            val htmlCallback = pendingFileCallback
            pendingFileCallback = null
            if (htmlCallback != null) {
                if (uri == null) htmlCallback.onReceiveValue(null)
                else htmlCallback.onReceiveValue(arrayOf(uri))
                return@registerForActivityResult
            }

            val target = pendingNativeTarget
            pendingNativeTarget = null
            if (target != null) {
                if (uri == null) {
                    Toast.makeText(this, "No se seleccionó ningún archivo.", Toast.LENGTH_SHORT).show()
                } else {
                    deliverImageToPage(uri, target)
                }
            }
        }

    inner class FilePickerBridge {
        @JavascriptInterface
        fun openImagePicker(target: String) {
            runOnUiThread {
                // Cancelar cualquier selección anterior que haya quedado pendiente.
                pendingFileCallback?.onReceiveValue(null)
                pendingFileCallback = null
                pendingNativeTarget = if (target == "onboarding") "onboarding" else "business"

                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "image/*"
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                try {
                    filePickerLauncher.launch(intent)
                } catch (e: Exception) {
                    pendingNativeTarget = null
                    Toast.makeText(
                        this@MainActivity,
                        "No se pudo abrir Archivos: ${e.message ?: "error"}",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        setContentView(webView)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(false)
            allowFileAccessFromFileURLs = false
            allowUniversalAccessFromFileURLs = false
        }

        // El puente solo se expone a la página local incluida dentro de este APK.
        webView.addJavascriptInterface(FilePickerBridge(), "AndroidFilePicker")

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(
                view: WebView?,
                request: WebResourceRequest?
            ): Boolean = false
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                pendingFileCallback?.onReceiveValue(null)
                pendingFileCallback = filePathCallback
                pendingNativeTarget = null
                return try {
                    val intent = fileChooserParams?.createIntent()
                        ?: Intent(Intent.ACTION_GET_CONTENT).apply {
                            addCategory(Intent.CATEGORY_OPENABLE)
                            type = "*/*"
                        }
                    filePickerLauncher.launch(intent)
                    true
                } catch (e: Exception) {
                    pendingFileCallback?.onReceiveValue(null)
                    pendingFileCallback = null
                    Toast.makeText(
                        this@MainActivity,
                        "No se pudo abrir el selector: ${e.message ?: "error"}",
                        Toast.LENGTH_LONG
                    ).show()
                    true
                }
            }
        }

        if (savedInstanceState == null) {
            webView.loadUrl("file:///android_asset/index.html")
        } else {
            webView.restoreState(savedInstanceState)
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) webView.goBack() else finish()
            }
        })
    }

    private fun deliverImageToPage(uri: Uri, target: String) {
        Thread {
            try {
                val displayName = queryDisplayName(uri)
                val dataUrl = makeImageDataUrl(uri)
                runOnUiThread {
                    val js = "window.onNativeImageSelected(" +
                        JSONObject.quote(dataUrl) + "," +
                        JSONObject.quote(displayName) + "," +
                        JSONObject.quote(target) + ");"
                    webView.evaluateJavascript(js, null)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(
                        this,
                        "No se pudo leer la imagen: ${e.message ?: "error"}",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }.start()
    }

    private fun queryDisplayName(uri: Uri): String {
        var name = "logo.png"
        val cursor: Cursor? = contentResolver.query(uri, null, null, null, null)
        cursor?.use {
            val column = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (column >= 0 && it.moveToFirst()) name = it.getString(column) ?: name
        }
        return name
    }

    private fun makeImageDataUrl(uri: Uri): String {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri).use { stream ->
            requireNotNull(stream) { "No se pudo abrir el archivo." }
            BitmapFactory.decodeStream(stream, null, bounds)
        }
        require(bounds.outWidth > 0 && bounds.outHeight > 0) {
            "El archivo seleccionado no es una imagen compatible."
        }

        var sample = 1
        while (bounds.outWidth / sample > 1200 || bounds.outHeight / sample > 1200) sample *= 2
        val options = BitmapFactory.Options().apply { inSampleSize = sample }
        val bitmap: Bitmap = contentResolver.openInputStream(uri).use { stream ->
            requireNotNull(stream) { "No se pudo volver a leer la imagen." }
            BitmapFactory.decodeStream(stream, null, options)
        } ?: throw IllegalArgumentException("Android no pudo decodificar la imagen.")

        val output = ByteArrayOutputStream()
        try {
            // PNG conserva el fondo transparente de los logos.
            if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, output)) {
                throw IllegalStateException("No se pudo preparar la imagen.")
            }
        } finally {
            bitmap.recycle()
        }
        val encoded = Base64.encodeToString(output.toByteArray(), Base64.NO_WRAP)
        return "data:image/png;base64,$encoded"
    }

    override fun onSaveInstanceState(outState: Bundle) {
        webView.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    override fun onDestroy() {
        pendingFileCallback?.onReceiveValue(null)
        pendingFileCallback = null
        pendingNativeTarget = null
        webView.destroy()
        super.onDestroy()
    }
}
