package com.rota.gayrimenkul;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.webkit.WebViewAssetLoader;

import java.io.OutputStream;

public class MainActivity extends Activity {
    private static final int FILE_REQ = 1;
    private static final String HOST = "appassets.androidplatform.net";
    private static final String HOME = "https://" + HOST + "/assets/index.html";

    private WebView web;
    private ValueCallback<Uri[]> filePathCallback;
    private OutputStream saveOut;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);

        web.addJavascriptInterface(new Bridge(), "AndroidBridge");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (HOST.equals(u.getHost())) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (Exception ignored) { }
                return true;
            }
        });

        // Fotoğraf / video seçici (APK'da eksik olan kısım)
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                try {
                    startActivityForResult(params.createIntent(), FILE_REQ);
                } catch (Exception e) {
                    filePathCallback = null;
                    return false;
                }
                return true;
            }
        });

        // Yedekle düğmesi (blob indirme) için
        web.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            if (!url.startsWith("blob:")) return;
            String name = URLUtil.guessFileName(url, contentDisposition, mimeType);
            if (name == null || name.endsWith(".bin")) name = "rota-gayrimenkul-yedek.json";
            name = name.replaceAll("[^A-Za-z0-9._-]", "_");
            String mime = (mimeType == null || mimeType.isEmpty()) ? "application/json" : mimeType.replaceAll("[^A-Za-z0-9./+-]", "");
            String js = "(function(){var x=new XMLHttpRequest();x.open('GET','" + url + "',true);x.responseType='blob';"
                    + "x.onload=function(){var r=new FileReader();r.onloadend=function(){"
                    + "var d=r.result;var b=d.substring(d.indexOf(',')+1);"
                    + "AndroidBridge.begin('" + name + "','" + mime + "');"
                    + "for(var i=0;i<b.length;i+=1048576){AndroidBridge.chunk(b.substring(i,i+1048576));}"
                    + "AndroidBridge.end();};r.readAsDataURL(x.response);};x.send();})();";
            web.evaluateJavascript(js, null);
        });

        if (savedInstanceState != null) {
            web.restoreState(savedInstanceState);
        } else {
            web.loadUrl(HOME);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_REQ && filePathCallback != null) {
            filePathCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data));
            filePathCallback = null;
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        web.saveState(outState);
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    private void toast(final String msg) {
        runOnUiThread(() -> Toast.makeText(MainActivity.this, msg, Toast.LENGTH_LONG).show());
    }

    private class Bridge {
        @JavascriptInterface
        public void begin(String name, String mime) {
            try {
                ContentValues cv = new ContentValues();
                cv.put(MediaStore.Downloads.DISPLAY_NAME, name);
                cv.put(MediaStore.Downloads.MIME_TYPE, mime);
                cv.put(MediaStore.Downloads.RELATIVE_PATH, "Download");
                Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                saveOut = getContentResolver().openOutputStream(uri);
            } catch (Exception e) {
                saveOut = null;
                toast("Yedek kaydedilemedi: " + e.getMessage());
            }
        }

        @JavascriptInterface
        public void chunk(String b64) {
            try {
                if (saveOut != null) saveOut.write(Base64.decode(b64, Base64.DEFAULT));
            } catch (Exception e) {
                toast("Yedek yazılamadı: " + e.getMessage());
            }
        }

        @JavascriptInterface
        public void end() {
            try {
                if (saveOut != null) {
                    saveOut.close();
                    saveOut = null;
                    toast("Yedek İndirilenler klasörüne kaydedildi");
                }
            } catch (Exception ignored) { }
        }
    }
}
