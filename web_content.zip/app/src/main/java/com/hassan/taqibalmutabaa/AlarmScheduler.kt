package com.hassan.taqibalmutabaa

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import org.json.JSONArray
import kotlin.math.abs

object AlarmScheduler {
    private fun requestCode(id: String): Int = abs(id.hashCode()).coerceAtLeast(1)

    fun exactPermission(context: Context): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true
        return context.getSystemService(AlarmManager::class.java).canScheduleExactAlarms()
    }

    private fun pendingIntent(context: Context, id: String, title: String, message: String): PendingIntent {
        val intent = Intent(context, AlarmReceiver::class.java).apply {
            putExtra("alarm_id", id)
            putExtra("title", title)
            putExtra("message", message)
        }
        return PendingIntent.getBroadcast(
            context, requestCode(id), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun cancelAll(context: Context, json: String = AlarmStore.load(context)) {
        val am = context.getSystemService(AlarmManager::class.java)
        val arr = try { JSONArray(json) } catch (_: Exception) { JSONArray() }
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val id = o.optString("id")
            if (id.isNotBlank()) {
                am.cancel(pendingIntent(context, id, "", ""))
            }
        }
    }

    fun sync(context: Context, json: String): Boolean {
        cancelAll(context)
        AlarmStore.save(context, json)

        if (!exactPermission(context)) return false

        val am = context.getSystemService(AlarmManager::class.java)
        val now = System.currentTimeMillis()
        val arr = try { JSONArray(json) } catch (_: Exception) { JSONArray() }

        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            if (!o.optBoolean("enabled", true)) continue
            val timestamp = o.optLong("timestamp", 0L)
            if (timestamp <= now) continue

            val id = o.optString("id")
            if (id.isBlank()) continue
            val title = o.optString("title", "تذكير بالموعد")
            val message = o.optString("message", "لديك موعد قادم")
            val pi = pendingIntent(context, id, title, message)

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, timestamp, pi)
            } else {
                am.setExact(AlarmManager.RTC_WAKEUP, timestamp, pi)
            }
        }
        return true
    }

    fun reschedule(context: Context) {
        sync(context, AlarmStore.load(context))
    }
}
