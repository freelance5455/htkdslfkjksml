package com.hassan.taqibalmutabaa

import android.content.Context

object AlarmStore {
    private const val PREFS = "native_alarm_store"
    private const val KEY = "alarms"

    fun save(context: Context, json: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY, json).apply()
    }

    fun load(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY, "[]") ?: "[]"
}
