package com.hassan.taqibalmutabaa

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebView

class NativeBridge(
    private val activity: Activity,
    private val webView: WebView
) {
    @JavascriptInterface
    fun syncAlarms(json: String): Boolean =
        AlarmScheduler.sync(activity, json)

    @JavascriptInterface
    fun hasExactAlarmPermission(): Boolean =
        AlarmScheduler.exactPermission(activity)

    @JavascriptInterface
    fun requestExactAlarmPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val intent = Intent(
                Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                Uri.parse("package:${activity.packageName}")
            )
            activity.startActivity(intent)
        }
    }

    @JavascriptInterface
    fun openNotificationSettings() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val intent = Intent(
                Settings.ACTION_APP_NOTIFICATION_SETTINGS
            ).apply {
                putExtra(Settings.EXTRA_APP_PACKAGE, activity.packageName)
            }
            activity.startActivity(intent)
        }
    }

    @JavascriptInterface
    fun resync() {
        AlarmScheduler.reschedule(activity)
    }
}
