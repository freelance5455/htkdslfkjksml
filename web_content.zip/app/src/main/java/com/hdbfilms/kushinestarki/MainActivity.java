package com.hdbfilms.kushinestarki;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.graphics.Color;
import android.net.Uri;
import android.util.Base64;
import android.widget.Toast;
import java.io.OutputStream;

public final class MainActivity extends Activity {
    private WebView webView;
    private byte[] pendingPdf;
    private static final int SAVE_PDF_REQUEST = 4107;

    public final class PdfBridge {
        @JavascriptInterface
        public void savePdf(String base64Data, String filename) {
            try {
                byte[] data = Base64.decode(base64Data, Base64.DEFAULT);
                if (data.length < 50 || data.length > 6000000 || !new String(data, 0, 5, java.nio.charset.StandardCharsets.US_ASCII).equals("%PDF-")) return;
                runOnUiThread(() -> {
                    pendingPdf = data;
                    Intent save = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    save.addCategory(Intent.CATEGORY_OPENABLE);
                    save.setType("application/pdf");
                    save.putExtra(Intent.EXTRA_TITLE, filename.replaceAll("[^A-Za-z0-9._-]", "_"));
                    startActivityForResult(save, SAVE_PDF_REQUEST);
                });
            } catch (Exception ignored) { runOnUiThread(() -> Toast.makeText(MainActivity.this, "Unable to prepare PDF", Toast.LENGTH_SHORT).show()); }
        }
    }

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(19, 38, 45));
        getWindow().setNavigationBarColor(Color.rgb(19, 38, 45));
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(255, 248, 239));
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        webView.addJavascriptInterface(new PdfBridge(), "KushiAndroid");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == SAVE_PDF_REQUEST) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingPdf != null) {
                try (OutputStream stream = getContentResolver().openOutputStream(data.getData())) {
                    if (stream == null) throw new Exception("Could not open chosen file");
                    stream.write(pendingPdf);
                    stream.flush();
                    Toast.makeText(this, "Daily Reading PDF saved", Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    Toast.makeText(this, "PDF save failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            }
            pendingPdf = null;
        }
    }
    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
    @Override protected void onDestroy() {
        if (webView != null) { webView.destroy(); webView = null; }
        super.onDestroy();
    }
}
