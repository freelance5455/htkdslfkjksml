package com.suraj.airtouch

import android.content.Context
import com.google.mediapipe.tasks.core.BaseOptions
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * The hand model is either bundled in assets (if the build machine had internet)
 * or downloaded once into the app's private storage.
 */
object ModelStore {
    const val FILE = "hand_landmarker.task"
    private const val MODEL_URL =
        "https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task"

    private fun inAssets(c: Context): Boolean =
        try { c.assets.list("")?.contains(FILE) == true } catch (e: Exception) { false }

    private fun localFile(c: Context) = File(c.filesDir, FILE)

    fun ready(c: Context): Boolean =
        inAssets(c) || localFile(c).let { it.exists() && it.length() > 1_000_000 }

    /** Blocking download – call from a background thread. */
    fun download(c: Context, onProgress: (Int) -> Unit) {
        val dest = localFile(c)
        val tmp = File(c.filesDir, "$FILE.part")
        val conn = URL(MODEL_URL).openConnection() as HttpURLConnection
        conn.connectTimeout = 15000
        conn.readTimeout = 30000
        try {
            if (conn.responseCode != 200) throw IOException("HTTP ${conn.responseCode}")
            val total = conn.contentLength
            conn.inputStream.use { input ->
                tmp.outputStream().use { output ->
                    val buf = ByteArray(32768)
                    var done = 0L
                    var last = -1
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        output.write(buf, 0, n)
                        done += n
                        if (total > 0) {
                            val p = (done * 100 / total).toInt()
                            if (p != last) { last = p; onProgress(p) }
                        }
                    }
                }
            }
            if (tmp.length() < 1_000_000) throw IOException("downloaded file is too small")
            if (!tmp.renameTo(dest)) throw IOException("could not save model")
        } finally {
            conn.disconnect()
            if (tmp.exists()) tmp.delete()
        }
    }

    fun baseOptions(c: Context): BaseOptions {
        if (inAssets(c)) return BaseOptions.builder().setModelAssetPath(FILE).build()
        val bytes = localFile(c).readBytes()
        val buf = ByteBuffer.allocateDirect(bytes.size).order(ByteOrder.nativeOrder())
        buf.put(bytes)
        buf.rewind()
        return BaseOptions.builder().setModelAssetBuffer(buf).build()
    }
}
