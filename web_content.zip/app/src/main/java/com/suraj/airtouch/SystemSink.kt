package com.suraj.airtouch

import android.os.Handler
import android.os.Looper
import android.os.SystemClock

/** Turns engine events into real gestures over ANY app via the AccessibilityService. */
class SystemSink : GestureSink {
    private val main = Handler(Looper.getMainLooper())
    private var x0 = 0f
    private var y0 = 0f
    private var t0 = 0L
    private var moved = false

    private fun svc() = GestureAccessibilityService.instance

    override fun cursor(x: Float, y: Float, visible: Boolean, state: Int) {
        main.post { svc()?.showCursor(x, y, visible, state) }
    }

    override fun touchDown(x: Float, y: Float) {
        main.post { x0 = x; y0 = y; t0 = SystemClock.uptimeMillis(); moved = false }
    }

    override fun touchMove(x: Float, y: Float) {
        main.post { moved = true }
    }

    override fun touchUp(x: Float, y: Float) {
        main.post {
            val s = svc() ?: return@post
            val dur = SystemClock.uptimeMillis() - t0
            if (!moved) {
                if (dur >= 550) s.longPress(x0, y0) else s.tap(x0, y0)
            } else {
                s.swipe(x0, y0, x, y, dur.coerceIn(120L, 700L))
            }
        }
    }

    override fun doubleTap(x: Float, y: Float) { main.post { svc()?.doubleTap(x, y) } }
    override fun nav(kind: Nav) { main.post { svc()?.nav(kind) } }
}
