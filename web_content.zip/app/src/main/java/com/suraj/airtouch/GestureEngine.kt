package com.suraj.airtouch

import com.google.mediapipe.tasks.components.containers.NormalizedLandmark
import kotlin.math.hypot
import kotlin.math.max

/** Which finger touched the thumb for a navigation pinch. */
enum class Nav { MIDDLE, RING, PINKY }

object CursorState { const val HOVER = 0; const val PINCH = 1; const val SCROLL = 2 }

/**
 * Receives what the engine detects. Two implementations exist:
 *  - InAppSink  : injects real touch events into the browser window (no special permission)
 *  - SystemSink : performs taps / swipes over any app through the AccessibilityService
 * All coordinates are in pixels of the target window / screen.
 */
interface GestureSink {
    fun cursor(x: Float, y: Float, visible: Boolean, state: Int)
    fun touchDown(x: Float, y: Float)
    fun touchMove(x: Float, y: Float)
    fun touchUp(x: Float, y: Float)
    fun doubleTap(x: Float, y: Float)
    fun nav(kind: Nav)
    /** Where a scroll drag should start (the in-app browser keeps it inside the web page). */
    fun scrollAnchor(x: Float, y: Float): FloatArray = floatArrayOf(x, y)
}

/**
 * Hand landmarks -> pointer + gestures.
 *
 *  palm moves ................ pointer moves
 *  thumb + index pinch ....... finger touches the screen (tap, long-press, drag, select)
 *  two quick pinches ......... double tap
 *  ✌ index+middle up, move ... smooth scroll (up/down/left/right), like dragging the page
 *  thumb + middle pinch ...... Nav.MIDDLE   (Back)
 *  thumb + ring pinch ........ Nav.RING     (Forward / Home)
 *  thumb + little pinch ...... Nav.PINKY    (Home page / Recents)
 */
class GestureEngine(private val out: GestureSink) {

    private enum class S { IDLE, PINCH, SCROLL }

    private val fx = OneEuro()
    private val fy = OneEuro()
    private var s = S.IDLE
    private var lastSeen = 0L
    private var x = 0f
    private var y = 0f
    private var visible = false

    // pinch
    private var pinchStart = 0L
    private var sx = 0f
    private var sy = 0f
    private var moved = false
    private var downSent = false
    private var dbl = false
    private var lastTapT = 0L
    private var lastTapX = 0f
    private var lastTapY = 0f

    // scroll
    private var scrollSince = 0L
    private var scrollLostSince = 0L
    private var ax = 0f
    private var ay = 0f
    private var x0 = 0f
    private var y0 = 0f
    private var fingerX = 0f
    private var fingerY = 0f

    // navigation pinches
    private var navFinger = -1
    private var navSince = 0L
    private var navFired = false
    private var navCooldown = 0L

    private val slop = 36f

    @Synchronized
    fun reset() { lost() }

    @Synchronized
    fun onHand(lm: List<NormalizedLandmark>?, now: Long, imgW: Int, imgH: Int, w: Int, h: Int) {
        if (w <= 0 || h <= 0) return
        if (lm == null || lm.size < 21) {
            if (now - lastSeen > 350) lost()
            return
        }
        lastSeen = now

        val asp = imgW.toFloat() / imgH.toFloat()
        fun d(a: Int, b: Int) = hypot((lm[a].x() - lm[b].x()) * asp, lm[a].y() - lm[b].y())
        val size = max(d(0, 9), 1e-4f)
        // thumb tip to index / middle / ring / little tip, relative to hand size
        val r = floatArrayOf(d(4, 8) / size, d(4, 12) / size, d(4, 16) / size, d(4, 20) / size)
        fun ext(tip: Int, pip: Int) = d(tip, 0) > d(pip, 0) * 1.1f      // finger straight?

        val on = Prefs.pinch
        val off = on + 0.12f
        val scrollPose = ext(8, 6) && ext(12, 10) && !ext(16, 14) && !ext(20, 18) && r[0] > off && r[1] > off

        // ---- pointer (palm centre, mirrored like a selfie) ----
        val ids = intArrayOf(0, 5, 9, 13, 17)
        val rx = 1f - ids.map { lm[it].x() }.average().toFloat()
        val ry = ids.map { lm[it].y() }.average().toFloat()
        val area = Prefs.area
        val m = (1f - area) / 2f
        val nx = ((rx - m) / area).coerceIn(0f, 1f)
        val ny = ((ry - m) / area).coerceIn(0f, 1f)
        val minCut = 0.4f + (1f - Prefs.smooth) * 2.6f
        x = fx.filter(nx * w, now, minCut, 0.01f)
        y = fy.filter(ny * h, now, minCut, 0.01f)
        visible = true

        when (s) {
            S.IDLE -> {
                if (scrollPose) {
                    if (scrollSince == 0L) scrollSince = now
                    if (now - scrollSince > 200) startScroll()
                } else {
                    scrollSince = 0L
                    idle(r, on, now)
                }
                if (s == S.IDLE) out.cursor(x, y, true, CursorState.HOVER)
            }
            S.PINCH -> pinchStep(r, off, now)
            S.SCROLL -> scrollStep(scrollPose, now, w, h)
        }
        if (r.all { it > off }) { navFinger = -1; navFired = false }
    }

    // ---------------- idle: start pinch or navigation pinch ----------------
    private fun idle(r: FloatArray, on: Float, now: Long) {
        val close = r.indices.filter { r[it] < on }
        if (close.size == 1 && close[0] == 0 && navFinger == -1) { beginPinch(now); return }
        if (close.size == 1 && close[0] > 0) {
            val f = close[0]
            if (navFinger != f) { navFinger = f; navSince = now; navFired = false }
            if (!navFired && now - navSince > 200 && now > navCooldown) {
                navFired = true
                navCooldown = now + 900
                out.nav(when (f) { 1 -> Nav.MIDDLE; 2 -> Nav.RING; else -> Nav.PINKY })
            }
        }
    }

    // ---------------- pinch = finger on the screen ----------------
    private fun beginPinch(now: Long) {
        s = S.PINCH
        pinchStart = now; sx = x; sy = y; moved = false
        dbl = lastTapT != 0L && now - lastTapT < 550 && hypot(x - lastTapX, y - lastTapY) < 120f
        downSent = false
        if (!dbl) { out.touchDown(sx, sy); downSent = true }
        out.cursor(x, y, true, CursorState.PINCH)
    }

    private fun pinchStep(r: FloatArray, off: Float, now: Long) {
        if (!moved && hypot(x - sx, y - sy) > slop) moved = true
        if (dbl && !downSent && (moved || now - pinchStart > 350)) {   // it is not a double tap after all
            out.touchDown(sx, sy); downSent = true; dbl = false
        }
        if (moved && downSent) out.touchMove(x, y)
        out.cursor(x, y, true, CursorState.PINCH)

        if (r[0] > off) {                                              // released
            s = S.IDLE
            val held = now - pinchStart
            if (dbl && !downSent) {
                out.doubleTap(sx, sy); lastTapT = 0L
            } else {
                if (moved) out.touchUp(x, y) else out.touchUp(sx, sy)
                if (!moved && held < 350) { lastTapT = now; lastTapX = sx; lastTapY = sy } else lastTapT = 0L
            }
            out.cursor(x, y, true, CursorState.HOVER)
        }
    }

    // ---------------- two-finger scroll ----------------
    private fun startScroll() {
        s = S.SCROLL
        val a = out.scrollAnchor(x, y)
        ax = a[0]; ay = a[1]; x0 = x; y0 = y
        fingerX = ax; fingerY = ay
        scrollLostSince = 0L
        out.touchDown(ax, ay)
        out.cursor(x, y, true, CursorState.SCROLL)
    }

    private fun scrollStep(pose: Boolean, now: Long, w: Int, h: Int) {
        if (!pose) {
            if (scrollLostSince == 0L) scrollLostSince = now
            if (now - scrollLostSince > 150) {
                out.touchUp(fingerX, fingerY)
                s = S.IDLE; scrollSince = 0L; scrollLostSince = 0L
            }
            return
        }
        scrollLostSince = 0L
        val g = Prefs.scroll
        fingerX = ax + (x - x0) * g
        fingerY = ay + (y - y0) * g
        if (fingerX < w * 0.05f || fingerX > w * 0.95f || fingerY < h * 0.1f || fingerY > h * 0.9f) {
            out.touchUp(fingerX.coerceIn(0f, w.toFloat()), fingerY.coerceIn(0f, h.toFloat()))
            x0 = x; y0 = y; fingerX = ax; fingerY = ay          // re-grab in the middle and keep going
            out.touchDown(ax, ay)
        } else {
            out.touchMove(fingerX, fingerY)
        }
        out.cursor(x, y, true, CursorState.SCROLL)
    }

    private fun lost() {
        if (s == S.PINCH && downSent) out.touchUp(x, y)
        if (s == S.SCROLL) out.touchUp(fingerX, fingerY)
        s = S.IDLE
        scrollSince = 0L; scrollLostSince = 0L
        navFinger = -1; navFired = false
        if (visible) { out.cursor(0f, 0f, false, CursorState.HOVER); visible = false }
        fx.reset(); fy.reset()
    }
}
