package com.suraj.airtouch

import com.google.mediapipe.tasks.components.containers.NormalizedLandmark
import kotlin.math.hypot
import kotlin.math.max

enum class Nav { BACK, HOME, RECENTS }

/** What the engine wants to happen. Implemented by HandTrackingService. */
interface GestureOutput {
    fun cursor(x: Float, y: Float, visible: Boolean, pinching: Boolean)
    fun tap(x: Float, y: Float)
    fun doubleTap(x: Float, y: Float)
    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long)
    fun nav(kind: Nav)
}

/**
 * Turns 21 hand landmarks into a pointer + gestures.
 *  - palm moves            -> dot moves
 *  - thumb+index pinch     -> tap (two quick pinches = double tap)
 *  - pinch, hold, move     -> swipe / scroll (executed on release)
 *  - thumb+middle pinch    -> BACK
 *  - thumb+ring pinch      -> HOME
 *  - thumb+pinky pinch     -> RECENTS
 */
class GestureEngine(private val out: GestureOutput) {
    private val fx = OneEuro()
    private val fy = OneEuro()
    private var lastSeen = 0L
    private var x = 0f
    private var y = 0f
    private var visible = false

    private var pinching = false
    private var pinchStart = 0L
    private var sx = 0f
    private var sy = 0f
    private var moved = false

    private var lastTapT = 0L
    private var lastTapX = 0f
    private var lastTapY = 0f

    private var navFinger = -1
    private var navSince = 0L
    private var navFired = false
    private var navCooldown = 0L

    fun onHand(lm: List<NormalizedLandmark>?, now: Long, imgW: Int, imgH: Int, screenW: Int, screenH: Int) {
        if (lm == null || lm.size < 21) {
            if (now - lastSeen > 350) lost()
            return
        }
        lastSeen = now

        val asp = imgW.toFloat() / imgH.toFloat()
        fun d(a: Int, b: Int) = hypot((lm[a].x() - lm[b].x()) * asp, lm[a].y() - lm[b].y())
        val size = max(d(0, 9), 1e-4f)
        // thumb tip to index / middle / ring / pinky tip, relative to hand size
        val r = floatArrayOf(d(4, 8) / size, d(4, 12) / size, d(4, 16) / size, d(4, 20) / size)

        // ---- pointer position (mirrored like a selfie) ----
        val ids = intArrayOf(0, 5, 9, 13, 17)
        var rx = ids.map { lm[it].x() }.average().toFloat()
        var ry = ids.map { lm[it].y() }.average().toFloat()
        rx = 1f - rx
        val area = Prefs.area
        val m = (1f - area) / 2f
        val nx = ((rx - m) / area).coerceIn(0f, 1f)
        val ny = ((ry - m) / area).coerceIn(0f, 1f)
        val minCut = 0.4f + (1f - Prefs.smooth) * 2.6f
        x = fx.filter(nx * screenW, now, minCut, 0.01f)
        y = fy.filter(ny * screenH, now, minCut, 0.01f)
        visible = true
        out.cursor(x, y, true, pinching)

        // ---- pinch detection (hysteresis) ----
        val on = Prefs.pinch
        val off = on + 0.12f
        val close = r.indices.filter { r[it] < on }

        if (!pinching) {
            if (close.size == 1 && close[0] == 0 && navFinger == -1) {
                pinching = true; pinchStart = now; sx = x; sy = y; moved = false
                out.cursor(x, y, true, true)
            }
        } else {
            if (hypot(x - sx, y - sy) > 60f) moved = true
            if (r[0] > off) {
                pinching = false
                out.cursor(x, y, true, false)
                onRelease(now, screenW, screenH)
            }
        }

        // ---- navigation pinches (middle / ring / pinky) ----
        if (!pinching) {
            if (close.size == 1 && close[0] > 0) {
                val f = close[0]
                if (navFinger != f) { navFinger = f; navSince = now; navFired = false }
                if (!navFired && now - navSince > 200 && now > navCooldown) {
                    navFired = true
                    navCooldown = now + 900
                    out.nav(when (f) { 1 -> Nav.BACK; 2 -> Nav.HOME; else -> Nav.RECENTS })
                }
            }
        }
        if (r.all { it > off }) { navFinger = -1; navFired = false }
    }

    private fun onRelease(now: Long, w: Int, h: Int) {
        val held = now - pinchStart
        if (moved) {
            val dur = held.coerceIn(150L, 600L)
            out.swipe(sx, sy, x.coerceIn(0f, w.toFloat()), y.coerceIn(0f, h.toFloat()), dur)
        } else if (held < 700) {
            if (lastTapT != 0L && now - lastTapT < 550 && hypot(sx - lastTapX, sy - lastTapY) < 120f) {
                out.doubleTap(sx, sy); lastTapT = 0L
            } else {
                out.tap(sx, sy); lastTapT = now; lastTapX = sx; lastTapY = sy
            }
        }
    }

    private fun lost() {
        if (visible) { out.cursor(0f, 0f, false, false); visible = false }
        pinching = false; navFinger = -1; navFired = false
        fx.reset(); fy.reset()
    }
}
