package com.suraj.airtouch

import kotlin.math.abs

/** One-Euro filter: smooth when the hand is slow, responsive when it is fast. */
class OneEuro {
    private var x = Float.NaN
    private var dx = 0f
    private var t = 0L

    fun reset() { x = Float.NaN; dx = 0f }

    private fun alpha(rate: Float, cut: Float): Float {
        val tau = 1f / (2f * Math.PI.toFloat() * cut)
        return 1f / (1f + tau * rate)
    }

    fun filter(v: Float, nowMs: Long, minCut: Float, beta: Float): Float {
        if (x.isNaN()) { x = v; t = nowMs; return v }
        val dt = ((nowMs - t) / 1000f).coerceAtLeast(0.001f)
        t = nowMs
        val rate = 1f / dt
        dx += alpha(rate, 1f) * ((v - x) / dt - dx)
        val cut = minCut + beta * abs(dx)
        x += alpha(rate, cut) * (v - x)
        return x
    }
}
