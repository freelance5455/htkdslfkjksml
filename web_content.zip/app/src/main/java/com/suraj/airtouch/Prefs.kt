package com.suraj.airtouch

import android.content.Context

/** Tunable settings shared by the UI and the tracking service (same process). */
object Prefs {
    @Volatile var area = 0.7f      // fraction of the camera frame that maps to the whole screen (smaller = more sensitive)
    @Volatile var smooth = 0.6f    // 0..1, higher = steadier dot
    @Volatile var pinch = 0.28f    // pinch threshold, higher = easier to pinch

    fun load(c: Context) {
        val p = c.getSharedPreferences("airtouch", Context.MODE_PRIVATE)
        area = p.getFloat("area", 0.7f)
        smooth = p.getFloat("smooth", 0.6f)
        pinch = p.getFloat("pinch", 0.28f)
    }

    fun save(c: Context) {
        c.getSharedPreferences("airtouch", Context.MODE_PRIVATE).edit()
            .putFloat("area", area).putFloat("smooth", smooth).putFloat("pinch", pinch).apply()
    }
}
