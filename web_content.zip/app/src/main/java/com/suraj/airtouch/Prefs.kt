package com.suraj.airtouch

import android.content.Context

/** Tunable settings shared by all screens (same process). */
object Prefs {
    @Volatile var area = 0.7f      // part of the camera frame mapped to the whole screen (smaller = more sensitive)
    @Volatile var smooth = 0.6f    // 0..1, higher = steadier dot
    @Volatile var pinch = 0.28f    // pinch threshold, higher = easier to pinch
    @Volatile var scroll = 1.0f    // scroll speed multiplier for the two-finger scroll gesture

    fun load(c: Context) {
        val p = c.getSharedPreferences("airtouch", Context.MODE_PRIVATE)
        area = p.getFloat("area", 0.7f)
        smooth = p.getFloat("smooth", 0.6f)
        pinch = p.getFloat("pinch", 0.28f)
        scroll = p.getFloat("scroll", 1.0f)
    }

    fun save(c: Context) {
        c.getSharedPreferences("airtouch", Context.MODE_PRIVATE).edit()
            .putFloat("area", area).putFloat("smooth", smooth)
            .putFloat("pinch", pinch).putFloat("scroll", scroll).apply()
    }
}
