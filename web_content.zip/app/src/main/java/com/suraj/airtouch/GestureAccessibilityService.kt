package com.suraj.airtouch

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Build
import android.util.DisplayMetrics
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent

/**
 * The part that works over ANY app: draws the pointer in an accessibility overlay
 * and injects taps, swipes and global actions (Back / Home / Recents).
 */
class GestureAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance: GestureAccessibilityService? = null
    }

    private lateinit var wm: WindowManager
    private var dot: DotView? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val v = DotView(this)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        wm.addView(v, lp)
        dot = v
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        try { dot?.let { wm.removeView(it) } } catch (_: Exception) {}
        dot = null
        return super.onUnbind(intent)
    }

    /** Real screen size in pixels (same coordinate space as dispatchGesture). */
    fun screenSize(): IntArray {
        return if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds
            intArrayOf(b.width(), b.height())
        } else {
            val dm = DisplayMetrics()
            @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(dm)
            intArrayOf(dm.widthPixels, dm.heightPixels)
        }
    }

    fun showCursor(x: Float, y: Float, visible: Boolean, pinching: Boolean) {
        dot?.update(x, y, visible, pinching)
    }

    fun hideCursor() { dot?.update(0f, 0f, false, false) }

    fun tap(x: Float, y: Float) {
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(point(x, y), 0, 60)).build()
        dispatchGesture(g, null, null)
    }

    fun doubleTap(x: Float, y: Float) {
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(point(x, y), 0, 50))
            .addStroke(GestureDescription.StrokeDescription(point(x, y), 130, 50)).build()
        dispatchGesture(g, null, null)
    }

    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long) {
        val p = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, durationMs)).build()
        dispatchGesture(g, null, null)
    }

    fun nav(kind: Nav) {
        val action = when (kind) {
            Nav.BACK -> GLOBAL_ACTION_BACK
            Nav.HOME -> GLOBAL_ACTION_HOME
            Nav.RECENTS -> GLOBAL_ACTION_RECENTS
        }
        performGlobalAction(action)
        dot?.flash(kind.name)
    }

    private fun point(x: Float, y: Float) = Path().apply { moveTo(x, y) }
}
