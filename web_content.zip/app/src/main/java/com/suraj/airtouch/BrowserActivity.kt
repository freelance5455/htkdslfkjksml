package com.suraj.airtouch

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.speech.RecognizerIntent
import android.text.InputType
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.google.mediapipe.tasks.components.containers.NormalizedLandmark

/**
 * Gesture browser. The start page is HTML (assets/www/home.html).
 * Hand tracking runs inside this screen and injects real touches into the window,
 * so everything – toolbar, tiles, YouTube, scrolling, fullscreen video – works by gestures.
 */
class BrowserActivity : AppCompatActivity() {

    private val home = "file:///android_asset/www/home.html"
    private val main = Handler(Looper.getMainLooper())

    private lateinit var root: FrameLayout
    private lateinit var content: LinearLayout
    private lateinit var web: WebView
    private lateinit var urlBox: EditText
    private lateinit var progress: ProgressBar
    private lateinit var handBtn: Button
    private lateinit var dot: DotView
    private lateinit var sink: InAppSink
    private lateinit var engine: GestureEngine
    private lateinit var tracker: HandTracker

    private var handOn = true
    private var customView: View? = null
    private var customCb: WebChromeClient.CustomViewCallback? = null

    private val voice = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val text = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!text.isNullOrBlank()) go(text)
    }
    private val camPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) startTracking() else toast("Camera permission denied – gestures are off, touch still works")
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()

    private fun toolButton(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        textSize = 18f
        isAllCaps = false
        setTextColor(Color.WHITE)
        setBackgroundColor(0xFF1C2545.toInt())
        minHeight = dp(56); minimumHeight = dp(56)
        minWidth = 0; minimumWidth = 0
        setPadding(0, 0, 0, 0)
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            .apply { setMargins(dp(2), dp(3), dp(2), dp(3)) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.load(this)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        root = FrameLayout(this).apply { setBackgroundColor(0xFF0B1020.toInt()) }
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row1.addView(toolButton("◀") { goBack() })
        row1.addView(toolButton("▶") { if (web.canGoForward()) web.goForward() })
        row1.addView(toolButton("⟳") { web.reload() })
        row1.addView(toolButton("⌂") { web.loadUrl(home) })
        row1.addView(toolButton("🎤") { speak() })
        handBtn = toolButton("✋") { setHand(!handOn) }
        row1.addView(handBtn)
        row1.addView(toolButton("✕") { finish() })
        content.addView(row1)

        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        urlBox = EditText(this).apply {
            hint = "Search or type a website"
            setHintTextColor(0xFF9AA6C7.toInt())
            setTextColor(Color.WHITE)
            textSize = 16f
            isSingleLine = true
            imeOptions = EditorInfo.IME_ACTION_GO
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            setBackgroundColor(0xFF151C33.toInt())
            setPadding(dp(12), dp(10), dp(12), dp(10))
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                .apply { setMargins(dp(3), dp(3), dp(3), dp(3)) }
            setOnEditorActionListener { _, actionId, event ->
                if (actionId == EditorInfo.IME_ACTION_GO ||
                    (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN)) {
                    go(text.toString()); true
                } else false
            }
        }
        row2.addView(urlBox)
        row2.addView(Button(this).apply {
            text = "Go"; isAllCaps = false; textSize = 18f
            setTextColor(Color.WHITE); setBackgroundColor(0xFF5B8CFF.toInt())
            minHeight = dp(52); minimumHeight = dp(52)
            setOnClickListener { go(urlBox.text.toString()) }
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { setMargins(dp(3), dp(3), dp(3), dp(3)) }
        })
        content.addView(row2)

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100; visibility = View.GONE
        }
        content.addView(progress, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(3)))

        web = WebView(this)
        setupWebView()
        content.addView(web, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        root.addView(content, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)

        // pointer dot on top of everything, inside this window
        dot = DotView(this)
        val decor = window.decorView as ViewGroup
        decor.addView(dot, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        sink = InAppSink(decor, dot, { web }) { kind -> onNav(kind) }
        engine = GestureEngine(sink)
        tracker = HandTracker(this, this,
            onHand = { lm, w, h -> onHand(lm, w, h) },
            onError = { msg -> toast(msg) })

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    customView != null -> customCb?.onCustomViewHidden()
                    web.canGoBack() -> web.goBack()
                    else -> finish()
                }
            }
        })

        val start = intent?.dataString
        if (savedInstanceState != null) web.restoreState(savedInstanceState)
        else web.loadUrl(if (!start.isNullOrBlank()) start else home)
    }

    // ---------------- hand control ----------------
    private fun onHand(lm: List<NormalizedLandmark>?, w: Int, h: Int) {
        val d = window.decorView
        engine.onHand(lm, SystemClock.uptimeMillis(), w, h, d.width, d.height)
    }

    private fun camGranted() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    private fun startTracking() {
        if (!handOn) return
        if (!camGranted()) { camPerm.launch(Manifest.permission.CAMERA); return }
        if (!ModelStore.ready(this)) {
            toast("Hand model missing – open the AirTouch main screen and tap \"Download hand model\"")
            return
        }
        tracker.start()
    }

    private fun setHand(on: Boolean) {
        handOn = on
        handBtn.alpha = if (on) 1f else 0.4f
        if (on) startTracking() else { tracker.stop(); engine.reset() }
    }

    private fun onNav(kind: Nav) {
        when (kind) {
            Nav.MIDDLE -> { goBack(); dot.flash("BACK") }
            Nav.RING -> { if (web.canGoForward()) web.goForward(); dot.flash("FORWARD") }
            Nav.PINKY -> { web.loadUrl(home); dot.flash("HOME") }
        }
    }

    private fun goBack() { if (web.canGoBack()) web.goBack() }

    override fun onResume() {
        super.onResume()
        if (HandTrackingService.running) {          // system-wide mode owns the camera: hand it over
            startService(Intent(this, HandTrackingService::class.java).setAction(HandTrackingService.ACTION_STOP))
            main.postDelayed({ startTracking() }, 900)
        } else startTracking()
    }

    override fun onPause() {
        super.onPause()
        tracker.stop()
        engine.reset()
    }

    // ---------------- web ----------------
    private fun setupWebView() {
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            loadWithOverviewMode = true
            useWideViewPort = true
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(false)
            allowFileAccessFromFileURLs = false
            allowUniversalAccessFromFileURLs = false
            allowContentAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        }
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url.toString()
                return !(u.startsWith("http://") || u.startsWith("https://") || u.startsWith("file:///android_asset/"))
            }
            override fun onPageStarted(view: WebView, url: String, favicon: android.graphics.Bitmap?) {
                if (!urlBox.hasFocus()) urlBox.setText(if (url.startsWith("file:")) "" else url)
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                progress.progress = newProgress
                progress.visibility = if (newProgress in 1..99) View.VISIBLE else View.GONE
            }
            override fun onShowCustomView(view: View, callback: CustomViewCallback) {
                if (customView != null) { callback.onCustomViewHidden(); return }
                customView = view; customCb = callback
                root.addView(view, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
                content.visibility = View.GONE
                systemBars(false)
            }
            override fun onHideCustomView() {
                customView?.let { root.removeView(it) }
                customView = null; customCb = null
                content.visibility = View.VISIBLE
                systemBars(true)
            }
        }
    }

    private fun systemBars(show: Boolean) {
        WindowCompat.setDecorFitsSystemWindows(window, show)
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        if (show) c.show(WindowInsetsCompat.Type.systemBars()) else c.hide(WindowInsetsCompat.Type.systemBars())
    }

    private fun go(input: String) {
        val t = input.trim()
        if (t.isEmpty()) return
        val url = when {
            t.startsWith("http://") || t.startsWith("https://") -> t
            !t.contains(' ') && t.contains('.') -> "https://$t"
            else -> "https://www.google.com/search?q=" + Uri.encode(t)
        }
        urlBox.clearFocus()
        web.loadUrl(url)
    }

    private fun speak() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_PROMPT, "Say what to search")
        try { voice.launch(i) } catch (e: Exception) { toast("Voice search is not available on this phone") }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        web.saveState(outState)
    }

    override fun onDestroy() {
        main.removeCallbacksAndMessages(null)
        tracker.release()
        root.removeAllViews()
        web.destroy()
        super.onDestroy()
    }
}
