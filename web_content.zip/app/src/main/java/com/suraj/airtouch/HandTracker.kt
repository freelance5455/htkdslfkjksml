package com.suraj.airtouch

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import android.util.Size
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.components.containers.NormalizedLandmark
import com.google.mediapipe.tasks.vision.core.ImageProcessingOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import java.util.concurrent.Executors

/**
 * Front camera + MediaPipe hand model. Used by the browser screen (owner = activity)
 * and by the background service (owner = service).
 * [onHand] is called on a background thread for every processed frame (landmarks == null when no hand).
 */
class HandTracker(
    private val ctx: Context,
    private val owner: LifecycleOwner,
    private val onHand: (landmarks: List<NormalizedLandmark>?, imgW: Int, imgH: Int) -> Unit,
    private val onError: (String) -> Unit
) {
    private val tag = "AirTouch"
    private val exec = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private var landmarker: HandLandmarker? = null
    private var provider: ProcessCameraProvider? = null
    @Volatile private var active = false
    @Volatile private var imgW = 480
    @Volatile private var imgH = 640

    fun start() {
        if (active) return
        active = true
        exec.execute {
            try {
                if (landmarker == null) landmarker = create()
                main.post { if (active) bindCamera() }
            } catch (e: Exception) {
                Log.e(tag, "model load failed", e)
                active = false
                main.post { onError("Hand model could not be loaded: ${e.message}") }
            }
        }
    }

    fun stop() {
        active = false
        main.post { try { provider?.unbindAll() } catch (_: Exception) {} }
    }

    fun release() {
        active = false
        try { provider?.unbindAll() } catch (_: Exception) {}
        exec.execute { try { landmarker?.close() } catch (_: Exception) {}; landmarker = null }
        exec.shutdown()
    }

    private fun create(): HandLandmarker {
        val opts = HandLandmarker.HandLandmarkerOptions.builder()
            .setBaseOptions(ModelStore.baseOptions(ctx))
            .setRunningMode(RunningMode.LIVE_STREAM)
            .setNumHands(1)
            .setMinHandDetectionConfidence(0.5f)
            .setMinHandPresenceConfidence(0.5f)
            .setMinTrackingConfidence(0.5f)
            .setResultListener { result, _ ->
                if (active) onHand(result.landmarks().firstOrNull(), imgW, imgH)
            }
            .setErrorListener { e -> Log.e(tag, "mediapipe error", e) }
            .build()
        return HandLandmarker.createFromOptions(ctx, opts)
    }

    private fun bindCamera() {
        if (!active) return
        val future = ProcessCameraProvider.getInstance(ctx)
        future.addListener({
            try {
                val p = future.get()
                provider = p
                val analysis = ImageAnalysis.Builder()
                    .setTargetResolution(Size(480, 640))
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                    .build()
                analysis.setAnalyzer(exec) { proxy -> analyze(proxy) }
                p.unbindAll()
                if (active) p.bindToLifecycle(owner, CameraSelector.DEFAULT_FRONT_CAMERA, analysis)
            } catch (e: Exception) {
                Log.e(tag, "camera bind failed", e)
                active = false
                onError("Camera could not be started: ${e.message}")
            }
        }, ContextCompat.getMainExecutor(ctx))
    }

    private fun analyze(proxy: ImageProxy) {
        val lm = landmarker
        if (!active || lm == null) { proxy.close(); return }
        try {
            val rot = proxy.imageInfo.rotationDegrees
            val bmp = proxy.toBitmap()
            if (rot % 180 == 0) { imgW = bmp.width; imgH = bmp.height } else { imgW = bmp.height; imgH = bmp.width }
            val mp = BitmapImageBuilder(bmp).build()
            val o = ImageProcessingOptions.builder().setRotationDegrees(rot).build()
            lm.detectAsync(mp, o, SystemClock.uptimeMillis())
        } catch (e: Exception) {
            Log.e(tag, "analyze failed", e)
        } finally {
            proxy.close()
        }
    }
}
