package com.suraj.airtouch

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.lifecycle.LifecycleService

/** Foreground service (type camera): keeps hand tracking alive while you use other apps. */
class HandTrackingService : LifecycleService() {

    companion object {
        @Volatile var running = false
        const val ACTION_STOP = "com.suraj.airtouch.STOP"
    }

    private val sink = SystemSink()
    private val engine = GestureEngine(sink)
    private var tracker: HandTracker? = null
    private var started = false

    override fun onCreate() {
        super.onCreate()
        ServiceCompat.startForeground(
            this, 1, buildNotification(),
            if (Build.VERSION.SDK_INT >= 30) ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA else 0
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        if (!started) {
            started = true
            Prefs.load(this)
            try {
                val t = HandTracker(this, this,
                    onHand = { lm, w, h ->
                        val svc = GestureAccessibilityService.instance
                        if (svc != null) {
                            val s = svc.screenSize()
                            engine.onHand(lm, SystemClock.uptimeMillis(), w, h, s[0], s[1])
                        }
                    },
                    onError = { msg -> Log.e("AirTouch", msg); stopSelf() })
                tracker = t
                t.start()
                running = true
            } catch (e: Exception) {
                Log.e("AirTouch", "start failed", e)
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    private fun buildNotification(): Notification {
        val ch = "airtouch"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(ch, "AirTouch", NotificationManager.IMPORTANCE_LOW))
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val stop = PendingIntent.getService(this, 1, Intent(this, HandTrackingService::class.java).setAction(ACTION_STOP), flags)
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), flags)
        return NotificationCompat.Builder(this, ch)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("AirTouch is active")
            .setContentText("System-wide hand control is running. The front camera is in use.")
            .setContentIntent(open)
            .addAction(0, "Stop", stop)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        running = false
        engine.reset()
        tracker?.release()
        Handler(Looper.getMainLooper()).post { GestureAccessibilityService.instance?.hideCursor() }
        super.onDestroy()
    }
}
