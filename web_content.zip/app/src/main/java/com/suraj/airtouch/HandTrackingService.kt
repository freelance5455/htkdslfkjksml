package com.suraj.airtouch

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import android.util.Size
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.framework.image.MPImage
import com.google.mediapipe.tasks.vision.core.ImageProcessingOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerResult
import java.util.concurrent.Executors

/**
 * Foreground service (type "camera"): keeps the FRONT camera + hand model running
 * while you use other apps, and feeds landmarks to the GestureEngine.
 */
class HandTrackingService : LifecycleService(), GestureOutput {

    companion object {
        @Volatile var running = false
        const val ACTION_STOP = "com.suraj.airtouch.STOP"
        private const val TAG = "AirTouch"
    }

    private val exec = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private val engine = GestureEngine(this)
    private var landmarker: HandLandmarker? = null
    private var provider: ProcessCameraProvider? = null
    private var started = false
    @Volatile private var imgW = 480
    @Volatile private var imgH = 640

    override fun onCreate() {
        super.onCreate()
        ServiceCompat.startForeground(
            this, 1, buildNotification(),
            if (Build.VERSION.SDK_INT >= 30) ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA else 0
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        if (!started) {
            started = true
            Prefs.load(this)
            try {
                initLandmarker()
                bindCamera()
                running = true
            } catch (e: Exception) {
                Log.e(TAG, "start failed", e)
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    private fun initLandmarker() {
        val base = ModelStore.baseOptions(this)
        val opts = HandLandmarker.HandLandmarkerOptions.builder()
            .setBaseOptions(base)
            .setRunningMode(RunningMode.LIVE_STREAM)
            .setNumHands(1)
            .setMinHandDetectionConfidence(0.5f)
            .setMinHandPresenceConfidence(0.5f)
            .setMinTrackingConfidence(0.5f)
            .setResultListener { result, input -> onResult(result, input) }
            .setErrorListener { e -> Log.e(TAG, "mediapipe error", e) }
            .build()
        landmarker = HandLandmarker.createFromOptions(this, opts)
    }

    private fun bindCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                val p = future.get()
                provider = p
                val analysis = ImageAnalysis.Builder()
                    .setTargetResolution(Size(480, 640))
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                    .build()
                analysis.setAnalyzer(exec) { proxy -> analyze(proxy) }
                p.unbindAll()
                p.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, analysis)
            } catch (e: Exception) {
                Log.e(TAG, "camera bind failed", e)
                stopSelf()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun analyze(proxy: ImageProxy) {
        val lm = landmarker
        if (lm == null) { proxy.close(); return }
        try {
            val rot = proxy.imageInfo.rotationDegrees
            val bmp = proxy.toBitmap()
            if (rot % 180 == 0) { imgW = bmp.width; imgH = bmp.height } else { imgW = bmp.height; imgH = bmp.width }
            val mp = BitmapImageBuilder(bmp).build()
            val opts = ImageProcessingOptions.builder().setRotationDegrees(rot).build()
            lm.detectAsync(mp, opts, SystemClock.uptimeMillis())
        } catch (e: Exception) {
            Log.e(TAG, "analyze failed", e)
        } finally {
            proxy.close()
        }
    }

    private fun onResult(result: HandLandmarkerResult, input: MPImage) {
        val svc = GestureAccessibilityService.instance ?: return
        val s = svc.screenSize()
        engine.onHand(result.landmarks().firstOrNull(), SystemClock.uptimeMillis(), imgW, imgH, s[0], s[1])
    }

    // ---- GestureOutput -> accessibility service (always on the main thread) ----
    override fun cursor(x: Float, y: Float, visible: Boolean, pinching: Boolean) {
        main.post { GestureAccessibilityService.instance?.showCursor(x, y, visible, pinching) }
    }
    override fun tap(x: Float, y: Float) { main.post { GestureAccessibilityService.instance?.tap(x, y) } }
    override fun doubleTap(x: Float, y: Float) { main.post { GestureAccessibilityService.instance?.doubleTap(x, y) } }
    override fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long) {
        main.post { GestureAccessibilityService.instance?.swipe(x1, y1, x2, y2, durationMs) }
    }
    override fun nav(kind: Nav) { main.post { GestureAccessibilityService.instance?.nav(kind) } }

    private fun buildNotification(): Notification {
        val ch = "airtouch"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(ch, "AirTouch", NotificationManager.IMPORTANCE_LOW))
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val stop = PendingIntent.getService(this, 1, Intent(this, HandTrackingService::class.java).setAction(ACTION_STOP), flags)
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), flags)
        return NotificationCompat.Builder(this, ch)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("AirTouch is active")
            .setContentText("Hand control is running. The front camera is in use.")
            .setContentIntent(open)
            .addAction(0, "Stop", stop)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        running = false
        try { provider?.unbindAll() } catch (_: Exception) {}
        try { landmarker?.close() } catch (_: Exception) {}
        exec.shutdown()
        main.post { GestureAccessibilityService.instance?.hideCursor() }
        super.onDestroy()
    }
}
