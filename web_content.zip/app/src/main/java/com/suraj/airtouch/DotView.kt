package com.suraj.airtouch

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.SystemClock
import android.view.View

/** Full-screen, untouchable overlay that draws the hand pointer. */
class DotView(ctx: Context) : View(ctx) {
    private var cx = 0f
    private var cy = 0f
    private var vis = false
    private var pin = false
    private var label: String? = null
    private var labelUntil = 0L

    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 6f }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 56f; textAlign = Paint.Align.CENTER
        setShadowLayer(8f, 0f, 0f, Color.BLACK)
    }

    fun update(x: Float, y: Float, visible: Boolean, pinching: Boolean) {
        cx = x; cy = y; vis = visible; pin = pinching
        invalidate()
    }

    fun flash(text: String) {
        label = text
        labelUntil = SystemClock.uptimeMillis() + 900
        invalidate()
        postInvalidateDelayed(950)
    }

    override fun onDraw(c: Canvas) {
        if (vis) {
            val rr = if (pin) 26f else 58f
            ring.color = Color.parseColor(if (pin) "#2EE59D" else "#5B8CFF")
            fill.color = Color.parseColor(if (pin) "#552EE59D" else "#225B8CFF")
            c.drawCircle(cx, cy, rr, fill)
            c.drawCircle(cx, cy, rr, ring)
            fill.color = Color.WHITE
            c.drawCircle(cx, cy, 13f, fill)
        }
        val l = label
        if (l != null && SystemClock.uptimeMillis() < labelUntil) {
            c.drawText(l, width / 2f, height * 0.12f, txt)
        }
    }
}
