package com.suraj.airtouch

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.SystemClock
import android.view.View

/** Transparent, untouchable view that draws the hand pointer (and short labels like BACK). */
class DotView(ctx: Context) : View(ctx) {
    private var cx = 0f
    private var cy = 0f
    private var vis = false
    private var state = CursorState.HOVER
    private var label: String? = null
    private var labelUntil = 0L

    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 6f }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 56f; textAlign = Paint.Align.CENTER
        setShadowLayer(8f, 0f, 0f, Color.BLACK)
    }

    init { isClickable = false; isFocusable = false }

    fun update(x: Float, y: Float, visible: Boolean, st: Int) {
        cx = x; cy = y; vis = visible; state = st
        invalidate()
    }

    fun flash(text: String) {
        label = text
        labelUntil = SystemClock.uptimeMillis() + 900
        invalidate()
        postInvalidateDelayed(950)
    }

    override fun onDraw(c: Canvas) {
        if (vis) {
            val col: String; val bg: String; val rr: Float
            when (state) {
                CursorState.PINCH -> { col = "#2EE59D"; bg = "#552EE59D"; rr = 26f }
                CursorState.SCROLL -> { col = "#FFB020"; bg = "#33FFB020"; rr = 70f }
                else -> { col = "#5B8CFF"; bg = "#225B8CFF"; rr = 58f }
            }
            ring.color = Color.parseColor(col)
            fill.color = Color.parseColor(bg)
            c.drawCircle(cx, cy, rr, fill)
            c.drawCircle(cx, cy, rr, ring)
            fill.color = Color.WHITE
            c.drawCircle(cx, cy, 13f, fill)
        }
        val l = label
        if (l != null && SystemClock.uptimeMillis() < labelUntil) {
            c.drawText(l, width / 2f, height * 0.14f, txt)
        }
    }
}
