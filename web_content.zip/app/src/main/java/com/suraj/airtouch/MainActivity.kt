package com.suraj.airtouch

import android.Manifest
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var tvCam: TextView
    private lateinit var tvModel: TextView
    private lateinit var btnModel: Button
    private lateinit var tvA11y: TextView
    private lateinit var btnSystem: Button
    private var downloading = false

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { refresh() }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(t: String, size: Float = 15f, color: Int = 0xFFD7DEFA.toInt(), bold: Boolean = false) =
        TextView(this).apply {
            text = t; textSize = size; setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(6), 0, dp(6))
        }

    private fun button(t: String, onClick: () -> Unit) =
        Button(this).apply { text = t; isAllCaps = false; setOnClickListener { onClick() } }

    private fun slider(title: String, max: Int, start: Int, fmt: (Int) -> String, onChange: (Int) -> Unit): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val tv = label("$title: ${fmt(start)}")
        val sb = SeekBar(this)
        sb.max = max
        sb.progress = start
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                tv.text = "$title: ${fmt(p)}"
                onChange(p)
                Prefs.save(this@MainActivity)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        box.addView(tv); box.addView(sb)
        return box
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.load(this)
        val blue = 0xFF5B8CFF.toInt()
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(20), dp(28))
        }
        col.addView(label("✋ AirTouch", 28f, 0xFFFFFFFF.toInt(), true))
        col.addView(label("Control a browser – or your whole phone – with hand gestures."))

        // ---- setup ----
        col.addView(label("1 · Camera", 16f, blue, true))
        tvCam = label(""); col.addView(tvCam)
        col.addView(button("Allow camera & notifications") { askPermissions() })
        col.addView(label("2 · Hand model (one-time, ~8 MB)", 16f, blue, true))
        tvModel = label(""); col.addView(tvModel)
        btnModel = button("Download hand model") { downloadModel() }
        col.addView(btnModel)

        // ---- browser mode ----
        col.addView(label("3 · Gesture browser (no special permission)", 16f, blue, true))
        col.addView(label("YouTube, Google, Instagram… everything inside the app is controlled by your hand."))
        col.addView(button("🌐 Open AirTouch Browser") { openBrowser() })

        // ---- system mode ----
        col.addView(label("Optional · Control ALL apps (system-wide)", 16f, blue, true))
        tvA11y = label(""); col.addView(tvA11y)
        col.addView(button("Open Accessibility settings") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            Toast.makeText(this, "Find AirTouch → turn it ON", Toast.LENGTH_LONG).show()
        })
        col.addView(label("If the switch is greyed out: App info → ⋮ → \"Allow restricted settings\", then try again.", 12f, 0xFF9AA6C7.toInt()))
        btnSystem = button("") { toggleSystem() }
        col.addView(btnSystem)

        // ---- tuning ----
        col.addView(label("Tuning", 16f, blue, true))
        col.addView(slider("Hand reach (lower = less arm movement)", 50, ((Prefs.area - 0.5f) * 100).toInt(),
            { "${50 + it}%" }) { Prefs.area = 0.5f + it / 100f })
        col.addView(slider("Smoothness", 10, (Prefs.smooth * 10).toInt(),
            { "$it/10" }) { Prefs.smooth = it / 10f })
        col.addView(slider("Pinch sensitivity (higher = easier)", 26, ((Prefs.pinch - 0.16f) * 100).toInt(),
            { "$it/26" }) { Prefs.pinch = 0.16f + it / 100f })
        col.addView(slider("Scroll speed", 15, ((Prefs.scroll - 0.5f) * 10).toInt(),
            { "${0.5f + it / 10f}×" }) { Prefs.scroll = 0.5f + it / 10f })

        // ---- guide ----
        col.addView(label("Gestures", 16f, blue, true))
        col.addView(label(
            "• Move your palm → the dot moves\n" +
            "• Thumb + index pinch → touch (tap, hold = long-press, pinch-and-move = drag)\n" +
            "• Two quick pinches → double tap (YouTube: seek ±10 s)\n" +
            "• ✌ Index + middle fingers up, other fingers folded, move hand → scroll (orange ring)\n" +
            "• Thumb + middle finger → Back\n" +
            "• Thumb + ring finger → Forward (browser) / Home (system mode)\n" +
            "• Thumb + little finger → Home page (browser) / Recents (system mode)\n\n" +
            "Hold the phone ~30–50 cm away with your hand in front of the FRONT camera, in good light."
        ))

        setContentView(ScrollView(this).apply { setBackgroundColor(0xFF0B1020.toInt()); addView(col) })
        refresh()
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun camGranted() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    private fun a11yEnabled(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        val me = ComponentName(this, GestureAccessibilityService::class.java).flattenToString()
        return s.split(':').any { it.equals(me, ignoreCase = true) }
    }

    private fun refresh() {
        tvCam.text = if (camGranted()) "✅ Camera allowed" else "❌ Camera not allowed yet"
        val ready = ModelStore.ready(this)
        if (!downloading) tvModel.text = if (ready) "✅ Hand model ready" else "❌ Hand model not downloaded yet"
        btnModel.visibility = if (ready) View.GONE else View.VISIBLE
        tvA11y.text = if (a11yEnabled()) "✅ Accessibility service is ON" else "❌ Accessibility service is OFF"
        btnSystem.text = if (HandTrackingService.running) "■ Stop system-wide control" else "▶ Start system-wide control"
    }

    private fun askPermissions() {
        val list = mutableListOf(Manifest.permission.CAMERA)
        if (Build.VERSION.SDK_INT >= 33) list.add(Manifest.permission.POST_NOTIFICATIONS)
        permLauncher.launch(list.toTypedArray())
    }

    private fun downloadModel() {
        if (downloading) return
        downloading = true
        btnModel.isEnabled = false
        tvModel.text = "⏳ Downloading hand model…"
        Thread {
            try {
                ModelStore.download(this) { pct -> runOnUiThread { tvModel.text = "⏳ Downloading hand model… $pct%" } }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this, "Download failed: ${e.message}. Check internet and try again.", Toast.LENGTH_LONG).show()
                }
            } finally {
                downloading = false
                runOnUiThread { btnModel.isEnabled = true; refresh() }
            }
        }.start()
    }

    private fun openBrowser() {
        if (!camGranted()) { askPermissions(); return }
        if (!ModelStore.ready(this)) { downloadModel(); return }
        startActivity(Intent(this, BrowserActivity::class.java))
    }

    private fun toggleSystem() {
        if (HandTrackingService.running) {
            startService(Intent(this, HandTrackingService::class.java).setAction(HandTrackingService.ACTION_STOP))
        } else {
            if (!camGranted()) { askPermissions(); return }
            if (!ModelStore.ready(this)) { downloadModel(); return }
            if (!a11yEnabled()) {
                Toast.makeText(this, "Turn on the AirTouch accessibility service first", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); return
            }
            ContextCompat.startForegroundService(this, Intent(this, HandTrackingService::class.java))
            Toast.makeText(this, "Started – open any app and show your hand", Toast.LENGTH_LONG).show()
        }
        Handler(Looper.getMainLooper()).postDelayed({ refresh() }, 700)
    }
}
