package com.suraj.airtouch

import android.Manifest
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var tvCam: TextView
    private lateinit var tvA11y: TextView
    private lateinit var btnStart: Button
    private lateinit var tvModel: TextView
    private lateinit var btnModel: Button
    private var downloading = false

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { refresh() }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(t: String, size: Float = 15f, color: Int = 0xFFD7DEFA.toInt(), bold: Boolean = false) =
        TextView(this).apply {
            text = t; textSize = size; setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(6), 0, dp(6))
        }

    private fun button(t: String, onClick: () -> Unit) =
        Button(this).apply { text = t; setOnClickListener { onClick() } }

    private fun slider(title: String, max: Int, start: Int, fmt: (Int) -> String, onChange: (Int) -> Unit): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val tv = label("$title: ${fmt(start)}")
        val sb = SeekBar(this)
        sb.max = max
        sb.progress = start
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                tv.text = "$title: ${fmt(p)}"
                onChange(p)
                Prefs.save(this@MainActivity)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        box.addView(tv); box.addView(sb)
        return box
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.load(this)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(20), dp(28))
        }
        col.addView(label("✋ AirTouch", 28f, 0xFFFFFFFF.toInt(), true))
        col.addView(label("Control your phone with hand gestures – in any app, even in the background."))

        tvCam = label("")
        tvA11y = label("")
        col.addView(label("Step 1 – Camera", 16f, 0xFF5B8CFF.toInt(), true))
        col.addView(tvCam)
        col.addView(button("Allow camera & notifications") { askPermissions() })
        col.addView(label("Step 1b – Hand model (one-time download, ~8 MB)", 16f, 0xFF5B8CFF.toInt(), true))
        tvModel = label("")
        col.addView(tvModel)
        btnModel = button("Download hand model") { downloadModel() }
        col.addView(btnModel)
        col.addView(label("Step 2 – Accessibility (pointer, taps, swipes over all apps)", 16f, 0xFF5B8CFF.toInt(), true))
        col.addView(tvA11y)
        col.addView(button("Open Accessibility settings") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            Toast.makeText(this, "Find AirTouch → turn it ON", Toast.LENGTH_LONG).show()
        })
        col.addView(label("If the switch is greyed out: App info → ⋮ menu → \"Allow restricted settings\", then try again.", 12f, 0xFF9AA6C7.toInt()))
        col.addView(label("Step 3 – Start", 16f, 0xFF5B8CFF.toInt(), true))
        btnStart = button("Start") { toggle() }
        col.addView(btnStart)
        col.addView(button("🌐 Open AirTouch Browser (YouTube, Google…)") { openBrowser() })

        col.addView(label("Tuning", 16f, 0xFF5B8CFF.toInt(), true))
        col.addView(slider("Hand reach (lower = less arm movement)", 50, ((Prefs.area - 0.5f) * 100).toInt(),
            { "${50 + it}%" }) { Prefs.area = 0.5f + it / 100f })
        col.addView(slider("Smoothness", 10, (Prefs.smooth * 10).toInt(),
            { "$it/10" }) { Prefs.smooth = it / 10f })
        col.addView(slider("Pinch sensitivity (higher = easier)", 26, ((Prefs.pinch - 0.16f) * 100).toInt(),
            { "${it}/26" }) { Prefs.pinch = 0.16f + it / 100f })

        col.addView(label("Gestures", 16f, 0xFF5B8CFF.toInt(), true))
        col.addView(label(
            "• Move palm → dot moves\n" +
            "• Thumb + index pinch → tap\n" +
            "• Two quick pinches → double tap\n" +
            "• Pinch, hold, move, release → swipe / scroll\n" +
            "• Thumb + middle finger → Back\n" +
            "• Thumb + ring finger → Home\n" +
            "• Thumb + little finger → Recents\n\n" +
            "Hold the phone ~30–50 cm from your face with the hand in front of the front camera. " +
            "Stop from the notification or this screen."
        ))

        val sv = ScrollView(this).apply { setBackgroundColor(0xFF0B1020.toInt()); addView(col) }
        setContentView(sv)
        refresh()
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun camGranted() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    private fun a11yEnabled(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        val me = ComponentName(this, GestureAccessibilityService::class.java).flattenToString()
        return s.split(':').any { it.equals(me, ignoreCase = true) }
    }

    private fun refresh() {
        tvCam.text = if (camGranted()) "✅ Camera allowed" else "❌ Camera not allowed yet"
        tvA11y.text = if (a11yEnabled()) "✅ Accessibility service is ON" else "❌ Accessibility service is OFF"
        val ready = ModelStore.ready(this)
        if (!downloading) tvModel.text = if (ready) "✅ Hand model ready" else "❌ Hand model not downloaded yet"
        btnModel.visibility = if (ready) View.GONE else View.VISIBLE
        btnStart.text = if (HandTrackingService.running) "■ Stop AirTouch" else "▶ Start AirTouch"
    }

    private fun downloadModel() {
        if (downloading) return
        downloading = true
        btnModel.isEnabled = false
        tvModel.text = "⏳ Downloading hand model…"
        Thread {
            try {
                ModelStore.download(this) { pct -> runOnUiThread { tvModel.text = "⏳ Downloading hand model… $pct%" } }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this, "Download failed: ${e.message}. Check internet and try again.", Toast.LENGTH_LONG).show()
                }
            } finally {
                downloading = false
                runOnUiThread { btnModel.isEnabled = true; refresh() }
            }
        }.start()
    }

    private fun openBrowser() {
        if (!HandTrackingService.running) {
            if (camGranted() && a11yEnabled() && ModelStore.ready(this)) {
                ContextCompat.startForegroundService(this, Intent(this, HandTrackingService::class.java))
            } else {
                Toast.makeText(this, "Hand control is not running yet – finish steps 1–2 to use gestures in the browser", Toast.LENGTH_LONG).show()
            }
        }
        startActivity(Intent(this, BrowserActivity::class.java))
    }

    private fun askPermissions() {
        val list = mutableListOf(Manifest.permission.CAMERA)
        if (Build.VERSION.SDK_INT >= 33) list.add(Manifest.permission.POST_NOTIFICATIONS)
        permLauncher.launch(list.toTypedArray())
    }

    private fun toggle() {
        if (HandTrackingService.running) {
            startService(Intent(this, HandTrackingService::class.java).setAction(HandTrackingService.ACTION_STOP))
        } else {
            if (!ModelStore.ready(this)) { downloadModel(); return }
            if (!camGranted()) { askPermissions(); return }
            if (!a11yEnabled()) {
                Toast.makeText(this, "Turn on the AirTouch accessibility service first", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); return
            }
            ContextCompat.startForegroundService(this, Intent(this, HandTrackingService::class.java))
            Toast.makeText(this, "Started – now open any app and show your hand", Toast.LENGTH_LONG).show()
        }
        Handler(Looper.getMainLooper()).postDelayed({ refresh() }, 700)
    }
}
