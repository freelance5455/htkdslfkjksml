package com.suraj.airtouch

import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.InputDevice
import android.view.MotionEvent
import android.view.View

/**
 * Injects real touch events into [decor] (the activity's whole window), so the toolbar,
 * the start page, YouTube, text selection, scrolling… react exactly like to a finger.
 * No accessibility permission needed.
 */
class InAppSink(
    private val decor: View,
    private val dot: DotView,
    private val webProvider: () -> View?,
    private val onNav: (Nav) -> Unit
) : GestureSink {

    private val main = Handler(Looper.getMainLooper())
    private var downTime = 0L

    private fun dispatch(action: Int, down: Long, t: Long, x: Float, y: Float) {
        val e = MotionEvent.obtain(down, t, action, x, y, 0)
        e.source = InputDevice.SOURCE_TOUCHSCREEN
        decor.dispatchTouchEvent(e)
        e.recycle()
    }

    override fun cursor(x: Float, y: Float, visible: Boolean, state: Int) {
        main.post { dot.update(x, y, visible, state) }
    }

    override fun touchDown(x: Float, y: Float) {
        main.post {
            downTime = SystemClock.uptimeMillis()
            dispatch(MotionEvent.ACTION_DOWN, downTime, downTime, x, y)
        }
    }

    override fun touchMove(x: Float, y: Float) {
        main.post { dispatch(MotionEvent.ACTION_MOVE, downTime, SystemClock.uptimeMillis(), x, y) }
    }

    override fun touchUp(x: Float, y: Float) {
        main.post { dispatch(MotionEvent.ACTION_UP, downTime, SystemClock.uptimeMillis(), x, y) }
    }

    override fun doubleTap(x: Float, y: Float) {
        main.post {
            tapOnce(x, y)
            main.postDelayed({ tapOnce(x, y) }, 120)
        }
    }

    private fun tapOnce(x: Float, y: Float) {
        val t = SystemClock.uptimeMillis()
        dispatch(MotionEvent.ACTION_DOWN, t, t, x, y)
        main.postDelayed({ dispatch(MotionEvent.ACTION_UP, t, SystemClock.uptimeMillis(), x, y) }, 45)
    }

    override fun nav(kind: Nav) { main.post { onNav(kind) } }

    override fun scrollAnchor(x: Float, y: Float): FloatArray {
        val w = webProvider() ?: return floatArrayOf(x, y)
        val loc = IntArray(2)
        w.getLocationInWindow(loc)
        val inside = x >= loc[0] && x <= loc[0] + w.width && y >= loc[1] && y <= loc[1] + w.height
        return if (inside) floatArrayOf(x, y) else floatArrayOf(loc[0] + w.width / 2f, loc[1] + w.height / 2f)
    }
}
