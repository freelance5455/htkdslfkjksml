package com.cryptopulse.pro;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewClientCompat;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.graphics.Color;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.zip.GZIPInputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class MainActivity extends Activity {
    private static final String BUILD_ID = "CP-MARKET-CORE-1226-WEBVIEW-ASSET-LOADER";
    private static final String VERSION = "12.9.3";
    private static final String SPOT_BASE = "https://api.ourbit.com";
    // Ourbit Android APK uses the first-party global host for its live market UI.
    // Keep public V3 as a fallback, but prefer the same internal market transport.
    private static final String OURBIT_APP_BASE = "https://www.seebestfirst.com";
    private static final String FUTURES_BASE = "https://contract.ourbit.com";

    private WebView web;
    private final CryptoPulseBridge bridge = new CryptoPulseBridge();
    private final ScheduledExecutorService io = Executors.newScheduledThreadPool(12);
    private final ConcurrentHashMap<String, JSONObject> futuresLast = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String, Boolean> futuresRunning = new ConcurrentHashMap<>();

    private WebViewAssetLoader assetLoader;


    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        new android.os.Handler(getMainLooper()).postDelayed(() -> {
            if (isFinishing()) return;
            new android.app.AlertDialog.Builder(MainActivity.this)
                    .setTitle("CryptoPulse — APK IDENTITY")
                    .setMessage("BUILD: " + BUILD_ID + "\nVERSION: " + VERSION + "\nVERSION CODE: 155\n\nWebViewAssetLoader is active. Local page is bundled inside the APK.")
                    .setPositiveButton("تأیید", null)
                    .setCancelable(false)
                    .show();
        }, 250);
        getWindow().setStatusBarColor(android.graphics.Color.WHITE);
        getWindow().setNavigationBarColor(android.graphics.Color.WHITE);

        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setCacheMode(WebSettings.LOAD_NO_CACHE);

        assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/web/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        web.setWebViewClient(new WebViewClientCompat() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                WebResourceResponse local = assetLoader.shouldInterceptRequest(request.getUrl());
                return local != null ? local : super.shouldInterceptRequest(view, request);
            }

            @Override public WebResourceResponse shouldInterceptRequest(WebView view, String url) {
                WebResourceResponse local = assetLoader.shouldInterceptRequest(android.net.Uri.parse(url));
                return local != null ? local : super.shouldInterceptRequest(view, url);
            }

            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url != null && url.startsWith("cryptopulse://bridge/")) { handleBridgeFallbackUrl(url); return true; }
                return false;
            }

            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                if (request != null && request.getUrl() != null) {
                    String u=request.getUrl().toString();
                    if(u.startsWith("cryptopulse://bridge/")){handleBridgeFallbackUrl(u);return true;}
                }
                return super.shouldOverrideUrlLoading(view, request);
            }

            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                view.evaluateJavascript("window.__cpNativeBridgeSingle=!!window.CryptoPulseNative;window.__cpBuildId='" + BUILD_ID + "';window.__cpLocalPageUrl='" + url + "';", null);
            }

            @Override public void onReceivedError(WebView view, WebResourceRequest request, android.webkit.WebResourceError error) {
                if (request != null && request.isForMainFrame()) {
                    showLocalLoadFailure(view, request.getUrl() == null ? "" : request.getUrl().toString(), error == null ? "unknown" : String.valueOf(error.getErrorCode()));
                }
                super.onReceivedError(view, request, error);
            }
        });

        // SINGLE native bridge: expose the real Android JavascriptInterface once, before loading the document.
        web.addJavascriptInterface(bridge, "CryptoPulseNative");

        // Native-visible build probe: this is intentionally outside the WebView.
        // If this label appears, the installed APK is definitely Stage 1216.
        FrameLayout root = new FrameLayout(this);
        root.addView(web, new FrameLayout.LayoutParams(-1, -1));
        TextView probe = new TextView(this);
        probe.setText("CP 1226 • WEBVIEW ASSET LOADER");
        probe.setTextSize(11f);
        probe.setTextColor(Color.WHITE);
        probe.setBackgroundColor(Color.rgb(20,20,20));
        probe.setPadding(18, 8, 18, 8);
        FrameLayout.LayoutParams pp = new FrameLayout.LayoutParams(-2, -2);
        pp.gravity = android.view.Gravity.TOP | android.view.Gravity.CENTER_HORIZONTAL;
        root.addView(probe, pp);
        setContentView(root);
        // Android recommends WebViewAssetLoader for bundled WebView content instead of file:// URLs.
        web.loadUrl("https://appassets.androidplatform.net/web/index.html");

        // Native probe + home guard. The probe calls the actual WebView object and reports
        // whether the JavaScript document can see the same bridge name.
        web.postDelayed(() -> {
            if (web == null) return;
            String js = "(function(){try{" +
                    "var b=window.CryptoPulseNative;" +
                    "var v=!!b;" +
                    "var gb=v&&typeof b.getBuildId==='function'?String(b.getBuildId()):'';" +
                    "var gv=v&&typeof b.getBridgeVersion==='function'?String(b.getBridgeVersion()):'';" +
                    "window.__cpNativeProbeFromAndroid={build:'" + BUILD_ID + "',version:'12.9.3',visible:v,buildFromBridge:gb,bridgeVersion:gv,methodBuild:typeof b.getBuildId==='function',methodVersion:typeof b.getBridgeVersion==='function'};" +
                    "}catch(e){window.__cpNativeProbeFromAndroid={build:'" + BUILD_ID + "',version:'12.9.3',visible:false,error:String(e)}}})();";
            web.evaluateJavascript(js, value -> {
                final String out = value == null ? "null" : value;
                runOnUiThread(() -> {
                    View parent = web.getParent();
                    if (parent instanceof FrameLayout) {
                        FrameLayout root2=(FrameLayout)parent;
                        if(root2.getChildCount()>1 && root2.getChildAt(1) instanceof TextView){
                            ((TextView)root2.getChildAt(1)).setText("CP 1226 • JS=" + out);
                        }
                    }
                });
            });
        }, 800);
    }


    private void showLocalLoadFailure(WebView view, String url, String code) {
        runOnUiThread(() -> {
            String html = "<html><body style='font-family:sans-serif;padding:28px'>" +
                    "<h2>CryptoPulse WebView</h2>" +
                    "<p><b>BUILD:</b> " + BUILD_ID + "</p>" +
                    "<p><b>VERSION:</b> " + VERSION + "</p>" +
                    "<p><b>LOCAL PAGE:</b> " + url + "</p>" +
                    "<p><b>LOAD ERROR:</b> " + code + "</p>" +
                    "<p>Bundled WebViewAssetLoader is active. This page is inside the APK.</p>" +
                    "</body></html>";
            view.loadDataWithBaseURL("https://appassets.androidplatform.net/web/", html, "text/html", "UTF-8", null);
        });
    }

    private void push(String fn, String requestId, String payload) {
        if (web == null) return;
        final String rid = JSONObject.quote(requestId == null ? "" : requestId);
        final String body = JSONObject.quote(payload == null ? "" : payload);
        web.post(() -> {
            try { web.evaluateJavascript("window." + fn + "&&window." + fn + "(" + rid + "," + body + ");", null); }
            catch (Exception ignored) {}
        });
    }

    private String httpGet(String url) throws Exception {
        Exception last = null;
        for (int attempt = 0; attempt < 2; attempt++) {
            HttpURLConnection c = null;
            try {
                c = (HttpURLConnection) new URL(url).openConnection();
                c.setConnectTimeout(7000 + attempt * 2500);
                c.setReadTimeout(9000 + attempt * 3000);
                c.setUseCaches(false);
                c.setInstanceFollowRedirects(true);
                c.setRequestProperty("Accept", "application/json");
                c.setRequestProperty("Cache-Control", "no-cache");
                c.setRequestProperty("Pragma", "no-cache");
                c.setRequestProperty("Connection", "close");
                c.setRequestProperty("User-Agent", "Mozilla/5.0 (Android) CryptoPulse");
                c.setRequestProperty("Accept-Encoding", "identity");
                int code = c.getResponseCode();
                InputStream in = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
                String enc = c.getHeaderField("Content-Encoding");
                if (in != null && enc != null && enc.toLowerCase(Locale.US).contains("gzip")) {
                    try { in = new GZIPInputStream(in); }
                    catch (java.util.zip.ZipException gz) {
                        try { in.close(); } catch (Exception ignored) {}
                        // Some Android HTTP stacks already transparently decompress gzip.
                        c.disconnect();
                        c = (HttpURLConnection) new URL(url).openConnection();
                        c.setConnectTimeout(7000 + attempt * 2500);
                        c.setReadTimeout(9000 + attempt * 3000);
                        c.setUseCaches(false);
                        c.setInstanceFollowRedirects(true);
                        c.setRequestProperty("Accept", "application/json");
                        c.setRequestProperty("Cache-Control", "no-cache");
                        c.setRequestProperty("Pragma", "no-cache");
                        c.setRequestProperty("Connection", "close");
                        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Android) CryptoPulse");
                        c.setRequestProperty("Accept-Encoding", "identity");
                        code = c.getResponseCode();
                        in = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
                    }
                }
                StringBuilder b = new StringBuilder();
                if (in != null) {
                    try (BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
                        char[] buf = new char[8192]; int n;
                        while ((n = r.read(buf)) > 0) {
                            if (b.length() + n > 5000000) throw new Exception("HTTP payload too large");
                            b.append(buf, 0, n);
                        }
                    }
                }
                if (code < 200 || code >= 300) throw new Exception("HTTP " + code + " " + b);
                return b.toString();
            } catch (Exception e) {
                last = e;
                if (attempt == 0) try { Thread.sleep(250L); } catch (InterruptedException ie) { Thread.currentThread().interrupt(); break; }
            } finally { if (c != null) c.disconnect(); }
        }
        throw last != null ? last : new Exception("HTTP request failed");
    }

    private static String cleanSymbol(String s) {
        String x = s == null ? "BTC" : s.trim().toUpperCase(Locale.US).replaceAll("[^A-Z0-9]", "");
        if (x.endsWith("USDT")) x = x.substring(0, x.length() - 4);
        return x.isEmpty() ? "BTC" : x;
    }
    private static String spotSymbol(String s) { return cleanSymbol(s) + "USDT"; }
    private static String futuresSymbol(String s) { return cleanSymbol(s) + "_USDT"; }

    private static String spotTf(String tf) {
        String x = tf == null ? "1m" : tf.trim();
        if ("1h".equals(x)) return "60m";
        if ("1w".equals(x)) return "1W";
        return x;
    }
    private static String futuresTf(String tf) {
        String x = tf == null ? "Min1" : tf.trim();
        if (x.equals("1m")) return "Min1"; if (x.equals("5m")) return "Min5";
        if (x.equals("15m")) return "Min15"; if (x.equals("30m")) return "Min30";
        if (x.equals("1h") || x.equals("60m")) return "Min60";
        if (x.equals("4h")) return "Hour4"; if (x.equals("8h")) return "Hour8";
        if (x.equals("1d")) return "Day1"; if (x.equals("1w")) return "Week1";
        if (x.equals("1M")) return "Month1";
        return x;
    }
    private static long tfMs(String tf) {
        String x = futuresTf(tf);
        if (x.equals("Min5")) return 300000L; if (x.equals("Min15")) return 900000L;
        if (x.equals("Min30")) return 1800000L; if (x.equals("Min60")) return 3600000L;
        if (x.equals("Hour4")) return 14400000L; if (x.equals("Hour8")) return 28800000L;
        if (x.equals("Day1")) return 86400000L; if (x.equals("Week1")) return 604800000L;
        if (x.equals("Month1")) return 2592000000L; return 60000L;
    }

    /** Convert every known Ourbit kline response shape to one canonical array:
     * [[time,open,high,low,close,volume,...], ...]. This keeps parsing out of
     * the WebView and prevents chart pages from silently falling back to flat lines.
     */
    private String canonicalKlines(String raw) throws Exception {
        Object root = new org.json.JSONTokener(raw == null ? "" : raw).nextValue();
        return canonicalKlinesObject(root).toString();
    }

    private JSONArray canonicalKlinesObject(Object root) throws Exception {
        Object data = root;
        if (root instanceof JSONObject) {
            JSONObject o=(JSONObject)root;
            if (o.has("data")) data=o.opt("data");
            else if (o.has("result")) data=o.opt("result");
            else if (o.has("rows")) data=o.opt("rows");
            else if (o.has("list")) data=o.opt("list");
        }
        JSONArray out=new JSONArray();
        if (data instanceof JSONArray) {
            JSONArray a=(JSONArray)data;
            // Array-of-candles form.
            for(int i=0;i<a.length();i++) {
                Object item=a.opt(i);
                if(item instanceof JSONArray) {
                    JSONArray k=(JSONArray)item;
                    if(k.length()<5) continue;
                    long t=numberLong(k.opt(0));
                    double o=number(k.opt(1)), h=number(k.opt(2)), l=number(k.opt(3)), c=number(k.opt(4)), v=k.length()>5?number(k.opt(5)):0;
                    if(t>0&&o>0&&h>0&&l>0&&c>0) {
                        JSONArray r=new JSONArray(); r.put(t<100000000000L?t*1000L:t).put(o).put(h).put(l).put(c).put(v); out.put(r);
                    }
                } else if(item instanceof JSONObject) {
                    JSONObject k=(JSONObject)item;
                    long t=numberLong(first(k,"timestamp","t","openTime","time","ts"));
                    double o=number(first(k,"open","o")), h=number(first(k,"high","h")), l=number(first(k,"low","l")), c=number(first(k,"close","c")), v=number(first(k,"volume","v","vol"));
                    if(t>0&&o>0&&h>0&&l>0&&c>0) { JSONArray r=new JSONArray(); r.put(t<100000000000L?t*1000L:t).put(o).put(h).put(l).put(c).put(v); out.put(r); }
                }
            }
        } else if(data instanceof JSONObject) {
            JSONObject o=(JSONObject)data;
            // Columnar form: time/open/high/low/close/volume arrays.
            JSONArray ts=array(o,"time","times","timestamp","timestamps","openTime","openTimes","t");
            JSONArray os=array(o,"open","opens","o");
            JSONArray hs=array(o,"high","highs","h");
            JSONArray ls=array(o,"low","lows","l");
            JSONArray cs=array(o,"close","closes","c");
            JSONArray vs=array(o,"volume","vol","vols","v");
            if(ts!=null&&os!=null) {
                int n=Math.min(ts.length(),os.length());
                for(int i=0;i<n;i++) {
                    long t=numberLong(ts.opt(i)); double op=number(os.opt(i));
                    double hi=hs!=null&&i<hs.length()?number(hs.opt(i)):op;
                    double lo=ls!=null&&i<ls.length()?number(ls.opt(i)):op;
                    double cl=cs!=null&&i<cs.length()?number(cs.opt(i)):op;
                    double vol=vs!=null&&i<vs.length()?number(vs.opt(i)):0;
                    if(t>0&&op>0&&hi>0&&lo>0&&cl>0){JSONArray r=new JSONArray();r.put(t<100000000000L?t*1000L:t).put(op).put(hi).put(lo).put(cl).put(vol);out.put(r);}
                }
            } else {
                // Some responses wrap rows/list one level deeper.
                Object nested=o.opt("data"); if(nested==null) nested=o.opt("rows"); if(nested==null) nested=o.opt("list");
                if(nested instanceof JSONArray) return canonicalKlinesObject(nested);
            }
        }
        return out;
    }
    private static Object first(JSONObject o,String... keys){for(String k:keys)if(o.has(k)&&!o.isNull(k))return o.opt(k);return null;}
    private static JSONArray array(JSONObject o,String... keys){for(String k:keys){Object v=o.opt(k);if(v instanceof JSONArray)return (JSONArray)v;}return null;}
    private static double number(Object v){if(v==null||v==JSONObject.NULL)return Double.NaN;try{return Double.parseDouble(String.valueOf(v));}catch(Exception e){return Double.NaN;}}
    private static long numberLong(Object v){double n=number(v);return Double.isFinite(n)?(long)n:0L;}

    private void startFuturesPolling(final String symbol) {
        final String sym = cleanSymbol(symbol);
        if (futuresRunning.putIfAbsent(sym, true) != null) return;
        io.execute(() -> {
            try {
                String tf=futuresTf("1m"); int n=240; long end=System.currentTimeMillis(), start=end-tfMs(tf)*n;
                String hist=canonicalKlines(httpGet(FUTURES_BASE+"/api/v1/contract/kline/"+URLEncoder.encode(futuresSymbol(sym),"UTF-8")+"?interval="+tf+"&start="+start+"&end="+end));
                if (hist != null && hist.length() > 2) pushFuturesEvent(sym,"history",hist);
                else { JSONObject e=new JSONObject(); e.put("ok",false); e.put("error","empty futures kline"); pushFuturesEvent(sym,"status",e.toString()); }
            } catch(Exception ex) { try { JSONObject e=new JSONObject(); e.put("ok",false); e.put("error","KLINE: "+String.valueOf(ex.getMessage())); pushFuturesEvent(sym,"status",e.toString()); } catch(Exception ignored) {} }
            while (web != null && futuresRunning.getOrDefault(sym, false)) {
                try {
                    java.util.concurrent.Future<String> marketFuture = io.submit(() -> httpGet(FUTURES_BASE + "/api/v1/contract/ticker?symbol=" + URLEncoder.encode(futuresSymbol(sym), "UTF-8")));
                    java.util.concurrent.Future<String> depthFuture = io.submit(() -> httpGet(FUTURES_BASE + "/api/v1/contract/depth_commits/" + URLEncoder.encode(futuresSymbol(sym), "UTF-8") + "/20"));
                    JSONObject market = new JSONObject(marketFuture.get(8, TimeUnit.SECONDS));
                    JSONObject depth = new JSONObject(depthFuture.get(8, TimeUnit.SECONDS));
                    JSONObject m = market.optJSONObject("data");
                    if (m == null) m = market;
                    JSONObject d = depth.optJSONObject("data");
                    if (d == null) d = depth;
                    JSONObject pack = new JSONObject();
                    pack.put("market", m);
                    pack.put("depth", d);
                    futuresLast.put(sym, pack);
                    // The WebView handler expects (symbol,type,payload), so send the two events explicitly below.
                    pushFuturesEvent(sym, "market", m.toString());
                    pushFuturesEvent(sym, "depth", d.toString());
                } catch (Exception e) {
                    JSONObject err = new JSONObject();
                    try { err.put("ok", false); err.put("error", String.valueOf(e.getMessage())); } catch (Exception ignored) {}
                    pushFuturesEvent(sym, "status", err.toString());
                }
                try { Thread.sleep(1800L); } catch (InterruptedException e) { break; }
            }
        });
    }
    private void pushFuturesEvent(String symbol, String type, String payload) {
        if (web == null) return;
        final String a = JSONObject.quote(symbol), b = JSONObject.quote(type), c = JSONObject.quote(payload == null ? "" : payload);
        web.post(() -> { try { web.evaluateJavascript("window.cpNativeFuturesEvent&&window.cpNativeFuturesEvent("+a+","+b+","+c+");", null); } catch(Exception ignored){} });
    }

    public class CryptoPulseBridge {
        @JavascriptInterface public String getBuildId() { return BUILD_ID; }
        @JavascriptInterface public String getBridgeVersion() { return "NativeBridge-1217-REALITY-PROBE"; }
        @JavascriptInterface public String getLocalPage(String name) {
            try {
                if (name == null || !name.matches("[A-Za-z0-9_-]+\\.html")) return "";
                try (InputStream in = getAssets().open("web/" + name)) {
                    ByteArrayOutputStream out = new ByteArrayOutputStream(); byte[] buf = new byte[8192]; int n;
                    while ((n = in.read(buf)) >= 0) out.write(buf, 0, n);
                    return out.toString("UTF-8");
                }
            } catch (Exception e) { return ""; }
        }

        @JavascriptInterface public void fetchOurbitSpotKlines(String symbol, String interval, int limit, String requestId) {
            io.execute(() -> { String p=""; try { String tf=spotTf(interval); int n=Math.max(20,Math.min(1000,limit<=0?240:limit)); p=canonicalKlines(httpGet(SPOT_BASE+"/api/v3/klines?symbol="+URLEncoder.encode(spotSymbol(symbol),"UTF-8")+"&interval="+URLEncoder.encode(tf,"UTF-8")+"&limit="+n)); } catch(Exception e){p=errorJson(e);} push("cpNativeOurbitKlines",requestId,p); });
        }
        @JavascriptInterface public void fetchOurbitSpotTicker(String symbol, String requestId) {
            io.execute(() -> { String p=""; try {
                String ss=spotSymbol(symbol);
                String cur=cleanSymbol(symbol);
                try { p=httpGet(OURBIT_APP_BASE+"/platform/spot/market/price/"+URLEncoder.encode(cur,"UTF-8")); }
                catch(Exception first) {
                    try { p=httpGet(SPOT_BASE+"/api/v3/ticker/24hr?symbol="+URLEncoder.encode(ss,"UTF-8")); }
                    catch(Exception second) { p=httpGet(SPOT_BASE+"/api/v3/ticker/price?symbol="+URLEncoder.encode(ss,"UTF-8")); }
                }
            } catch(Exception e){p=errorJson(e);} push("cpNativeOurbitTicker",requestId,p);});
        }
        @JavascriptInterface public void fetchOurbitSpotDepth(String symbol, int limit, String requestId) {
            io.execute(() -> {String p="";try{int n=Math.max(5,Math.min(100,limit<=0?20:limit));p=httpGet(SPOT_BASE+"/api/v3/depth?symbol="+URLEncoder.encode(spotSymbol(symbol),"UTF-8")+"&limit="+n);}catch(Exception e){p=errorJson(e);}push("cpNativeOurbitDepth",requestId,p);});
        }
        @JavascriptInterface public void fetchOurbitSpotTickers(String requestId) {
            io.execute(() -> {
                String p=""; Exception last=null;
                // First-party Ourbit Android market transport discovered from the
                // supplied Ourbit APK: /platform/spot/market/v2/tickers.
                // This is the same market route used by the native Ourbit client.
                String[] urls={
                    OURBIT_APP_BASE+"/platform/spot/market/v2/tickers",
                    OURBIT_APP_BASE+"/platform/spot/market/v2/tickers?type=USDT",
                    SPOT_BASE+"/api/v3/ticker/24hr",
                    SPOT_BASE+"/api/v3/ticker/price"
                };
                for(String u:urls){
                    try{
                        p=httpGet(u);
                        if(p!=null&&p.trim().length()>2){
                            // Do not accept an HTML/error document as market data.
                            String q=p.trim().toLowerCase(Locale.US);
                            if(!q.startsWith("<html")&&!q.startsWith("<!doctype")) break;
                        }
                    }catch(Exception e){last=e;}
                }
                if((p==null||p.trim().length()<=2)&&last!=null)p=errorJson(last);
                push("cpNativeOurbitTickers",requestId,p);
            });
        }
        @JavascriptInterface public void fetchOurbitFuturesTicker(String symbol, String requestId) {
            io.execute(() -> {String p="";try{p=httpGet(FUTURES_BASE+"/api/v1/contract/ticker?symbol="+URLEncoder.encode(futuresSymbol(symbol),"UTF-8"));}catch(Exception e){p=errorJson(e);}push("cpNativeOurbitFuturesTicker",requestId,p);});
        }
        @JavascriptInterface public void fetchOurbitFuturesDepth(String symbol, int limit, String requestId) {
            io.execute(() -> {String p="";try{int n=Math.max(5,Math.min(100,limit<=0?20:limit));p=httpGet(FUTURES_BASE+"/api/v1/contract/depth_commits/"+URLEncoder.encode(futuresSymbol(symbol),"UTF-8")+"/"+n);}catch(Exception e){p=errorJson(e);}push("cpNativeOurbitFuturesDepth",requestId,p);});
        }
        @JavascriptInterface public void fetchOurbitFuturesKlines(String symbol, String interval, int limit, String requestId) {
            io.execute(() -> {String p="";try{String tf=futuresTf(interval);int n=Math.max(20,Math.min(1000,limit<=0?240:limit));long end=System.currentTimeMillis(),start=end-tfMs(tf)*n;p=canonicalKlines(httpGet(FUTURES_BASE+"/api/v1/contract/kline/"+URLEncoder.encode(futuresSymbol(symbol),"UTF-8")+"?interval="+URLEncoder.encode(tf,"UTF-8")+"&start="+start+"&end="+end));}catch(Exception e){p=errorJson(e);}push("cpNativeOurbitFuturesKlines",requestId,p);});
        }

        // Compatibility names used by the existing Home router. They now all point to Ourbit.
        @JavascriptInterface public void fetchTickers() { fetchOurbitSpotTickers("home"); }
        @JavascriptInterface public void fetchMarketUniverse() { fetchOurbitSpotTickers("universe"); }
        @JavascriptInterface public void restoreMarketCache() { fetchOurbitSpotTickers("restore"); }
        @JavascriptInterface public void startFuturesFeed(String symbol) { startFuturesPolling(symbol); }
        @JavascriptInterface public String getFuturesSnapshot(String symbol) { JSONObject x=futuresLast.get(cleanSymbol(symbol)); return x==null?"":x.toString(); }
        @JavascriptInterface public void runOurbitDiagnostics(String requestId) {
            io.execute(() -> {
                JSONArray a = new JSONArray();
                diagProbe(a, "spot_ping", SPOT_BASE + "/api/v3/ping", false);
                diagProbe(a, "spot_price", SPOT_BASE + "/api/v3/ticker/price?symbol=BTCUSDT", true);
                diagProbe(a, "spot_kline", SPOT_BASE + "/api/v3/klines?symbol=BTCUSDT&interval=1m&limit=3", true);
                diagProbe(a, "futures_ticker", FUTURES_BASE + "/api/v1/contract/ticker?symbol=BTC_USDT", true);
                long end = System.currentTimeMillis(), start = end - 15L * 60L * 1000L;
                diagProbe(a, "futures_kline", FUTURES_BASE + "/api/v1/contract/kline/BTC_USDT?interval=Min1&start=" + start + "&end=" + end, true);
                JSONObject out = new JSONObject();
                try { out.put("ok", true); out.put("build", BUILD_ID); out.put("timestamp", System.currentTimeMillis()); out.put("tests", a); }
                catch (Exception ignored) {}
                push("cpNativeDiagnostics", requestId, out.toString());
            });
        }

        @JavascriptInterface public String getNativeDiagnosticsMeta() {
            try { JSONObject o=new JSONObject(); o.put("build",BUILD_ID); o.put("version",VERSION); o.put("bridge","NativeBridge-1217-REALITY-PROBE"); return o.toString(); }
            catch(Exception e){ return "{}"; }
        }

        private void diagProbe(JSONArray a, String name, String url, boolean inspectBody) {
            long t = System.currentTimeMillis();
            HttpURLConnection c = null;
            JSONObject o = new JSONObject();
            try {
                c = (HttpURLConnection)new URL(url).openConnection();
                c.setConnectTimeout(7000); c.setReadTimeout(9000); c.setUseCaches(false); c.setInstanceFollowRedirects(true);
                c.setRequestProperty("Accept","application/json"); c.setRequestProperty("Cache-Control","no-cache"); c.setRequestProperty("Pragma","no-cache");
                c.setRequestProperty("Connection","close"); c.setRequestProperty("User-Agent","Mozilla/5.0 (Android) CryptoPulse-Diagnostics"); c.setRequestProperty("Accept-Encoding","identity");
                int code=c.getResponseCode(); InputStream in=(code>=200&&code<300)?c.getInputStream():c.getErrorStream();
                String body=""; if(in!=null){BufferedReader r=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8)); StringBuilder b=new StringBuilder(); String line; int total=0; while((line=r.readLine())!=null&&total<12000){b.append(line);total+=line.length();} body=b.toString(); try{r.close();}catch(Exception ignored){}}
                o.put("name",name); o.put("url",url); o.put("http",code); o.put("ms",System.currentTimeMillis()-t); o.put("bytes",body.length()); o.put("ok",code>=200&&code<300);
                if(inspectBody){ try { Object parsed=new org.json.JSONTokener(body).nextValue(); o.put("json",true); o.put("shape",parsed instanceof JSONArray?"array":parsed instanceof JSONObject?"object":"scalar"); } catch(Exception e){o.put("json",false);o.put("parseError",String.valueOf(e.getMessage()));} }
                if(code<200||code>=300){String clean=body; if(clean.length()>300)clean=clean.substring(0,300); o.put("errorBody",clean);}
            } catch(Exception e){
                try { o.put("name",name); o.put("url",url); o.put("http",-1); o.put("ms",System.currentTimeMillis()-t); o.put("ok",false); o.put("exception",e.getClass().getSimpleName()); o.put("error",String.valueOf(e.getMessage())); } catch(Exception ignored) {}
            } finally { if(c!=null)c.disconnect(); }
            a.put(o);
        }

        @JavascriptInterface public void enterChartFullscreen(){setFullscreen(true);}
        @JavascriptInterface public void exitChartFullscreen(){setFullscreen(false);}
    }

    private static String errorJson(Exception e) {
        try { JSONObject o=new JSONObject();o.put("error",String.valueOf(e.getMessage()));return o.toString(); } catch(Exception ignored){return "{\"error\":\"network\"}";}
    }
    private void setFullscreen(boolean full) {
        try {
            Window w=getWindow();
            if(Build.VERSION.SDK_INT>=30){WindowInsetsController c=w.getInsetsController();if(c!=null){if(full)c.hide(WindowInsets.Type.statusBars()|WindowInsets.Type.navigationBars());else c.show(WindowInsets.Type.statusBars()|WindowInsets.Type.navigationBars());}}
            else {w.getDecorView().setSystemUiVisibility(full?(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY):View.SYSTEM_UI_FLAG_VISIBLE);}
        }catch(Exception ignored){}
    }

    @Override protected void onDestroy(){
        futuresRunning.clear(); io.shutdownNow();
        if(web!=null){web.loadUrl("about:blank");web.stopLoading();web.destroy();web=null;}
        super.onDestroy();
    }
    @Override public void onBackPressed(){if(web!=null&&web.canGoBack())web.goBack();else super.onBackPressed();}
}
