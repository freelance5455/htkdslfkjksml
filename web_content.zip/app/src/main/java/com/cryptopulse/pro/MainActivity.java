package com.cryptopulse.pro;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.webkit.JavascriptInterface;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.io.OutputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import android.net.Uri;
import java.util.Locale;
import android.view.View;
import android.graphics.Color;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.os.Build;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import java.security.KeyStore;
import java.security.MessageDigest;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.Signature;
import javax.crypto.KeyGenerator;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;

public class MainActivity extends Activity {
    private MarketBridge cryptoPulseBridge;
    private WebView web;
    private final ExecutorService networkExecutor = Executors.newFixedThreadPool(8);
    // Dedicated priority lane for visible/missing market rows. These requests must
    // never wait behind the large secondary-feed downloads.
    private final ExecutorService priorityMarketExecutor = Executors.newFixedThreadPool(4);
    // REBUILD40: dedicated K-Line executor. Do not route chart history through the
    // general market network pool; a busy ticker/universe feed must never starve
    // the visible BTC/USDT chart request.
    private final ExecutorService klinePriorityExecutor = Executors.newFixedThreadPool(2);
    // Keeps market data alive while the WebView navigates between Home/Markets/Asset pages.
    // The WebView may reload an HTML page, but this native cache and feeder stay alive.
    private final ScheduledExecutorService marketBackgroundExecutor = Executors.newSingleThreadScheduledExecutor();
    private final ConcurrentHashMap<String, String> nativeMarketCache = new ConcurrentHashMap<>();
    // Symbols that were missing from bulk data are kept alive natively so their
    // prices continue updating even while the WebView is on another page.
    private final java.util.Set<String> backgroundMissingSymbols = java.util.concurrent.ConcurrentHashMap.newKeySet();
    // Prevents repeated retry storms while keeping missing symbols hot.
    private final ConcurrentHashMap<String, Long> missingLastAttempt = new ConcurrentHashMap<>();
    private volatile long lastBulkSuccessAt = 0L;
    private volatile long lastLegacyBulkAt = 0L;
    private volatile String nativeUniverseSnapshot = null;
    private volatile String diagLastUrl = "";
    private volatile String diagLastHttp = "";
    private volatile String diagLastError = "";
    private volatile long diagSuccessCount = 0L;
    private volatile long diagErrorCount = 0L;
    private volatile String diagKlineState = "idle";
    private volatile String diagKlineSymbol = "";
    private volatile String diagKlineInterval = "";
    private volatile int diagKlineAttempts = 0;
    private volatile int diagKlineRows = 0;
    private volatile String diagKlineResponse = "";
    private final java.util.Set<String> nativeSupportedPairs = java.util.concurrent.ConcurrentHashMap.newKeySet();
    private final AtomicBoolean bulkInFlight = new AtomicBoolean(false);
    private final AtomicBoolean universeInFlight = new AtomicBoolean(false);

    // REBUILD03: LBank market WebSocket is native Android (OkHttp), not WebView JS.
    // This avoids WebView/TLS/network-policy differences that can leave the UI OFFLINE
    // while native REST is already receiving prices.
    private final OkHttpClient lbankWsClient = new OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(0, TimeUnit.MILLISECONDS)
            .writeTimeout(10, TimeUnit.SECONDS)
            .pingInterval(20, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .build();
    private volatile WebSocket lbankNativeSocket;
    private final AtomicBoolean lbankSocketConnecting = new AtomicBoolean(false);
    private volatile long lbankWsLastMessage = 0L;
    private volatile long lbankWsLastOpen = 0L;
    private volatile long lbankWsLastPong = 0L;
    private volatile long lbankWsAttempts = 0L;
    private volatile long lbankWsMessages = 0L;
    private volatile long lbankWsErrors = 0L;
    private volatile int lbankWsCloseCode = 0;
    private volatile String lbankWsLastError = "";
    private volatile int lbankWsRetry = 0;
    private final java.util.concurrent.ScheduledExecutorService lbankWsScheduler = Executors.newSingleThreadScheduledExecutor();
    private volatile boolean lbankWsManualClose = false;
    // REBUILD05: keep the native socket subscribed to the current LBank USDT universe.
    // The previous build subscribed to only eight hard-coded symbols, so the socket
    // could be OPEN while most of Home/Markets never received live ticks.
    private final java.util.Set<String> lbankWsSubscribedPairs = java.util.concurrent.ConcurrentHashMap.newKeySet();
    private final AtomicBoolean lbankWsSubscriptionQueueRunning = new AtomicBoolean(false);

    // Persistent Futures background feed.  It lives outside the WebView so changing
    // screens never tears down the Futures connection/cache.
    private final ScheduledExecutorService futuresBackgroundExecutor = Executors.newSingleThreadScheduledExecutor();
    private final java.util.concurrent.atomic.AtomicBoolean futuresFeedStarted = new java.util.concurrent.atomic.AtomicBoolean(false);
    private final java.util.Set<String> futuresFeedSymbols = java.util.concurrent.ConcurrentHashMap.newKeySet();
    private final java.util.Set<String> futuresMarketInFlight = java.util.concurrent.ConcurrentHashMap.newKeySet();
    private final java.util.Set<String> futuresDepthInFlight = java.util.concurrent.ConcurrentHashMap.newKeySet();
    private final ConcurrentHashMap<String, JSONObject> futuresMarketCache = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String, JSONObject> futuresMarketRowsCache = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String, Long> futuresMarketRowsAt = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String, JSONObject> futuresDepthCache = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String, Long> futuresDepthAt = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String, Long> futuresBackoffUntil = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String, Integer> futuresFailureCount = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String, Integer> futuresMarketFailureCount = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String, Integer> futuresDepthFailureCount = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String, Long> futuresMarketBackoffUntil = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String, Long> futuresDepthBackoffUntil = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String, java.util.List<JSONObject>> futuresSamplesCache = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String, String> futuresErrorCache = new ConcurrentHashMap<>();
    private volatile long futuresLastTickAt = 0L;
    private final ConcurrentHashMap<String, Long> futuresGlobalNextPollAt = new ConcurrentHashMap<>();
    private static final long FUTURES_POLL_MS = 1800L;
    private static final long FUTURES_CACHE_TTL_MS = 1400L;
    // STAGE1157: backend-ready feed abstraction. The app remains public-API-first
    // today, but all downstream consumers can now identify the source contract.
    private static final String FEED_API_MODE = "PUBLIC_DIRECT";
    // STAGE1161: wallet security boundary. No private key/seed is exposed to WebView.
    private static final String WALLET_KEY_ALIAS = "CryptoPulseWalletBoundaryV1";
    private static final String WALLET_NETWORK = "SEPOLIA";
    private static final int WALLET_CHAIN_ID = 11155111;
    // STAGE1169: centralized production safety gate. This build is Sepolia-only;
    // any non-Sepolia chain is rejected before network/contract actions are prepared.
    private static final boolean MAINNET_ENABLED = false;
    private static final int MAINNET_CHAIN_ID = 1;
    // STAGE1163: Sepolia RPC is configuration-only. Keep the source free of API keys.
    // Empty by default until a trusted RPC endpoint is supplied at build/deployment time.
    private static final String SEPOLIA_RPC_URL = "";
    // STAGE1164: read-only CPLS contract interface. Address stays empty until the
    // real Sepolia deployment is independently verified. No mint/admin methods exist.
    private static final String CPLS_CONTRACT_ADDRESS = "";
    private static final String CPLS_CONTRACT_INTERFACE_VERSION = "1";
    private static final String CPLS_READ_BALANCE_OF_SELECTOR = "0x70a08231";
    private static final String CPLS_READ_DECIMALS_SELECTOR = "0x313ce567";
    private static final String CPLS_READ_NAME_SELECTOR = "0x06fdde03";
    private static final String CPLS_READ_SYMBOL_SELECTOR = "0x95d89b41";
    // STAGE1165: backend-authoritative reward claim boundary. The client can only
    // prepare a claim intent; it never chooses an authoritative amount or signs it.
    private static final String REWARD_CLAIM_PROTOCOL_VERSION = "1";
    private static final long REWARD_CLAIM_MAX_TTL_MS = 10 * 60 * 1000L;
    private static final String REWARD_CLAIM_STATUS = "BACKEND_REQUIRED";
    // STAGE1166: replay protection is backend-authoritative. The client keeps a
    // small local idempotency cache only to prevent accidental duplicate submits.
    private static final long REWARD_CLAIM_IDEMPOTENCY_TTL_MS = 15 * 60 * 1000L;
    // STAGE1167: app/device integrity boundary. These are local signals only;
    // they are never treated as proof of device integrity by the client. A future
    // backend may verify an official attestation token (for example Play Integrity)
    // independently. No Play Integrity claim is made by this stage.
    private static final String INTEGRITY_BOUNDARY_VERSION = "1";
    private final ConcurrentHashMap<String, Long> rewardClaimIdempotency = new ConcurrentHashMap<>();
    private static final String FEED_SCHEMA_VERSION = "1";
    private static final java.util.concurrent.atomic.AtomicLong feedRequestSeq = new java.util.concurrent.atomic.AtomicLong();
    // STAGE1158-1160: client-side safety telemetry only. Security decisions and
    // reward authorization must ultimately be enforced by a trusted backend.
    private final ConcurrentHashMap<String, Long> rewardActionWindow = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String, Integer> rewardActionCount = new ConcurrentHashMap<>();
    private static final long REWARD_ACTION_WINDOW_MS = 60_000L;
    private static final int REWARD_ACTION_LIMIT = 30;
    // STAGE1119: Futures WebSocket diagnostic channel.
    // IMPORTANT: do not invent a subscription payload. We only verify the official
    // endpoint, keep the socket alive, answer ping/pong, and expose connection
    // diagnostics to the UI. Real Futures data continues to come from the public
    // Contract REST feed until LBank documents a reliable public subscription shape.
    private volatile WebSocket futuresDiagnosticSocket;
    private final AtomicBoolean futuresDiagnosticConnecting = new AtomicBoolean(false);
    private volatile long futuresWsOpenedAt = 0L;
    private volatile long futuresWsLastMessageAt = 0L;
    private volatile long futuresWsMessages = 0L;
    private volatile int futuresWsCloseCode = 0;
    private volatile String futuresWsLastError = "";
    private volatile int futuresWsRetry = 0;

    // TV92: one tolerant parser for every LBank ticker envelope. Some LBank
    // responses put the ticker under data/ticker/result/item, while others return
    // the ticker object directly. Never let one envelope shape break the market feed.
    private static JSONObject firstTickerObject(Object node) {
        if (node == null || node == JSONObject.NULL) return null;
        if (node instanceof JSONObject) {
            JSONObject o=(JSONObject)node;
            String[] priceKeys={"latest","lastPrice","last","price","close","closePrice","lastTradedPrice"};
            for(String k:priceKeys){ if(o.has(k) && !o.isNull(k)) return o; }
            String[] nested={"ticker","data","result","resultData","payload","item","market","tick"};
            for(String k:nested){ Object v=o.opt(k); JSONObject hit=firstTickerObject(v); if(hit!=null) return hit; }
            java.util.Iterator<String> it=o.keys();
            while(it.hasNext()){
                Object v=o.opt(it.next());
                JSONObject hit=firstTickerObject(v); if(hit!=null) return hit;
            }
            return null;
        }
        if(node instanceof org.json.JSONArray){
            org.json.JSONArray a=(org.json.JSONArray)node;
            for(int i=0;i<a.length();i++){ JSONObject hit=firstTickerObject(a.opt(i)); if(hit!=null)return hit; }
        }
        return null;
    }
    private static double tickerNumber(JSONObject o, String... keys) {
        if(o==null)return Double.NaN;
        for(String k:keys){
            Object v=o.opt(k);
            if(v instanceof Number){ double d=((Number)v).doubleValue(); if(!Double.isNaN(d)&&!Double.isInfinite(d))return d; }
            if(v!=null){ try{ double d=Double.parseDouble(String.valueOf(v).trim().replace(",","")); if(!Double.isNaN(d)&&!Double.isInfinite(d))return d; }catch(Exception ignored){} }
        }
        return Double.NaN;
    }

    private void cacheBulkMarketPayload(String payload) {
        if (payload == null || payload.isEmpty()) return;
        try {
            // LBank V2 /v2/ticker/24hr.do?symbol=all returns a TOP-LEVEL JSON
            // ARRAY in the official response shape. Older code assumed an object
            // envelope ({data:[...]}) and silently discarded the valid array,
            // leaving the UI OFFLINE even though Android had received the data.
            org.json.JSONArray rows = null;
            String trimmed = payload.trim();
            if (trimmed.startsWith("[")) {
                rows = new org.json.JSONArray(trimmed);
            } else {
                JSONObject q = new JSONObject(trimmed);
                rows = q.optJSONArray("data");
                if (rows == null) {
                    Object dataObj = q.opt("data");
                    if (dataObj instanceof JSONObject) {
                        rows = new org.json.JSONArray();
                        JSONObject dm = (JSONObject)dataObj;
                        java.util.Iterator<String> it = dm.keys();
                        while (it.hasNext()) {
                            String k = it.next();
                            Object v = dm.opt(k);
                            if (k != null && k.toLowerCase(Locale.US).endsWith("_usdt") && v instanceof JSONObject) {
                                JSONObject r = new JSONObject();
                                r.put("symbol", k.toLowerCase(Locale.US));
                                r.put("ticker", v);
                                rows.put(r);
                            }
                        }
                    }
                }
            }
            if (rows == null) return;
            long now = System.currentTimeMillis();
            for (int i = 0; i < rows.length(); i++) {
                JSONObject r = rows.optJSONObject(i);
                if (r == null) continue;
                String rawSym = r.optString("symbol", "");
                String sym = normPair(rawSym).toUpperCase(Locale.US);
                if (!sym.endsWith("_USDT")) continue;
                String key = sym.substring(0, sym.length() - 5);
                JSONObject t = firstTickerObject(r);
                if (t == null) t = r;
                double price = tickerNumber(t, "latest","lastPrice","last","price","close","closePrice","lastTradedPrice");
                if (Double.isNaN(price) || price <= 0) continue;
                double change = tickerNumber(t, "change","changeRate","changePercent","priceChangePercent","increase","riseRate");
                double volume = tickerNumber(t, "vol","volume","quoteVolume","amount","turnover");
                JSONObject out = new JSONObject();
                out.put("symbol", key);
                out.put("price", price);
                out.put("change", Double.isNaN(change) ? 0 : change);
                out.put("volume", Double.isNaN(volume) ? 0 : volume);
                out.put("lastUpdate", now);
                out.put("provider", "LBank Native Background");
                nativeMarketCache.put(key, out.toString());
                if ("POL".equals(key)) {
                    try { JSONObject alias = new JSONObject(out.toString()); alias.put("symbol", "MATIC"); nativeMarketCache.put("MATIC", alias.toString()); } catch (Exception ignored) {}
                } else if ("S".equals(key)) {
                    try { JSONObject alias = new JSONObject(out.toString()); alias.put("symbol", "FTM"); nativeMarketCache.put("FTM", alias.toString()); } catch (Exception ignored) {}
                }
            }
        } catch (Exception ignored) {}
    }

    /** Merge ticker rows discovered by the current LBank market-center snapshot into
     * the same native live cache used by the legacy /v2/ticker/24hr.do?symbol=all feed.
     * The market-center response can arrive first; without this merge its prices were
     * visible only as universe metadata and lower rows could remain stale/blank. */
    private void cacheSnapshotTickers(org.json.JSONArray tickers) {
        if (tickers == null) return;
        final long now = System.currentTimeMillis();
        for (int i = 0; i < tickers.length(); i++) {
            try {
                JSONObject row = tickers.optJSONObject(i);
                if (row == null) continue;
                String sym = normPair(row.optString("symbol", "")).toUpperCase(Locale.US);
                if (!sym.endsWith("_USDT")) continue;
                String key = sym.substring(0, sym.length() - 5);
                JSONObject t = firstTickerObject(row);
                if (t == null) continue;
                double price = tickerNumber(t,"latest","close","lastPrice","last","price","closePrice","lastTradedPrice");
                if (Double.isNaN(price) || price <= 0) continue;
                double change = tickerNumber(t,"change","changeRate","changePercent","priceChangePercent","increase","riseRate");
                double volume = tickerNumber(t,"vol","volume","quoteVolume","amount","turnover");
                JSONObject out = new JSONObject();
                out.put("symbol", key); out.put("price", price);
                out.put("change", Double.isNaN(change) ? 0 : change);
                out.put("volume", Double.isNaN(volume) ? 0 : volume);
                out.put("lastUpdate", now); out.put("provider", "LBank MarketCenter Live");
                nativeMarketCache.put(key, out.toString());
                if ("POL".equals(key)) {
                    JSONObject alias = new JSONObject(out.toString()); alias.put("symbol","MATIC"); nativeMarketCache.put("MATIC",alias.toString());
                } else if ("S".equals(key)) {
                    JSONObject alias = new JSONObject(out.toString()); alias.put("symbol","FTM"); nativeMarketCache.put("FTM",alias.toString());
                }
            } catch (Exception ignored) {}
        }
    }

    private String getNativeMarketCachePayload() {
        org.json.JSONArray arr = new org.json.JSONArray();
        for (String value : nativeMarketCache.values()) {
            try { arr.put(new JSONObject(value)); } catch (Exception ignored) {}
        }
        return arr.toString();
    }

    private void pushNativeCacheToWeb() {
        if (web == null || nativeMarketCache.isEmpty()) return;
        final String payload = getNativeMarketCachePayload();
        // The native background poller is our reliable Android-side feed. A page
        // reload/navigation must not show CONNECTING merely because the last bulk
        // request timestamp crossed the 10s UI threshold. Treat a fresh cached row
        // as live data and let the next poll refresh it.
        boolean fresh = false;
        long now = System.currentTimeMillis();
        for (String value : nativeMarketCache.values()) {
            try {
                JSONObject r = new JSONObject(value);
                long at = r.optLong("lastUpdate", 0L);
                double price = r.optDouble("price", Double.NaN);
                if (at > 0L && now - at < 12000L && !Double.isNaN(price) && price > 0) { fresh = true; break; }
            } catch (Exception ignored) {}
        }
        final boolean live = fresh || (lastBulkSuccessAt > 0L && (now - lastBulkSuccessAt) < 12000L);
        web.post(() -> {
            if (web == null) return;
            web.evaluateJavascript("window.cpNativeRestoreMarketCache && window.cpNativeRestoreMarketCache(" + JSONObject.quote(payload) + ");", null);
            web.evaluateJavascript("window.cpNativeFeedStatus && window.cpNativeFeedStatus(" + (live ? "true" : "false") + ");", null);
        });
    }

    private void pushNativeUniverseToWeb() {
        if (web == null || nativeUniverseSnapshot == null || nativeUniverseSnapshot.isEmpty()) return;
        final String payload = nativeUniverseSnapshot;
        web.post(() -> {
            if (web == null) return;
            web.evaluateJavascript("window.cpNativeMarketUniverse && window.cpNativeMarketUniverse(" + JSONObject.quote(payload) + ");", null);
        });
    }

    private void cacheBinanceBulkMarketPayload(String payload) {
        if (payload == null || payload.isEmpty()) return;
        try {
            org.json.JSONArray rows = new org.json.JSONArray(payload);
            long now = System.currentTimeMillis();
            for (int i = 0; i < rows.length(); i++) {
                JSONObject r = rows.optJSONObject(i);
                if (r == null) continue;
                String sym = r.optString("symbol", "").toUpperCase(Locale.US);
                if (!sym.endsWith("USDT") || sym.length() <= 4) continue;
                String key = sym.substring(0, sym.length() - 4);
                double price = r.optDouble("lastPrice", Double.NaN);
                if (Double.isNaN(price) || price <= 0) continue;
                JSONObject out = new JSONObject();
                out.put("symbol", key);
                out.put("price", price);
                out.put("change", r.optDouble("priceChangePercent", 0));
                out.put("volume", r.optDouble("quoteVolume", 0));
                out.put("lastUpdate", now);
                out.put("provider", "Secondary Live");
                nativeMarketCache.put(key, out.toString());
            }
        } catch (Exception ignored) {}
    }

    // TV61: the supplied official LBank APK contains a current spot-instrument
    // catalogue in its bundled market configuration. Use that catalogue as the
    // initial universe so Markets is never empty while the live Market Center is
    // warming up. Prices are still required to come from live feeds; this is only
    // symbol discovery and never invents a price.
    private void loadBundledLbankSpotUniverse() {
        try {
            InputStream in = getAssets().open("web/lbank_spot_usdt_universe.json");
            StringBuilder b = new StringBuilder();
            try (BufferedReader br = new BufferedReader(new InputStreamReader(in, "UTF-8"))) {
                String line; while ((line = br.readLine()) != null) b.append(line);
            }
            org.json.JSONArray rows = new org.json.JSONArray(b.toString());
            org.json.JSONArray pairs = new org.json.JSONArray();
            org.json.JSONArray catalog = new org.json.JSONArray();
            for (int i=0;i<rows.length();i++) {
                JSONObject r=rows.optJSONObject(i); if(r==null) continue;
                String sym=r.optString("symbol","").toLowerCase(Locale.US);
                if(sym.endsWith("_usdt")) { pairs.put(sym); catalog.put(r); }
            }
            if(pairs.length()==0) return;
            JSONObject out=new JSONObject();
            out.put("pairs",pairs);
            out.put("tickers",new org.json.JSONArray());
            out.put("cache",new org.json.JSONArray());
            out.put("catalog",catalog);
            out.put("source","LBank APK bundled spot catalogue");
            nativeUniverseSnapshot=out.toString();
            nativeSupportedPairs.clear();
            for(int i=0;i<pairs.length();i++) nativeSupportedPairs.add(pairs.optString(i).toLowerCase(Locale.US));
            pushNativeUniverseToWeb();
        } catch(Exception ignored) {}
    }

    // CLEAN MARKET ENGINE v1: one native REST source of truth. WebSocket is
    // deliberately disabled until the REST path is proven stable on Android.
    private final AtomicBoolean cleanFeedInFlight = new AtomicBoolean(false);
    private final java.util.concurrent.atomic.AtomicInteger cleanCursor = new java.util.concurrent.atomic.AtomicInteger(0);

    private void startBackgroundMarketFeed() {
        // Do not start any legacy parallel market loops. This is the clean engine:
        // one official LBank bulk snapshot every 2s + a small direct-symbol repair lane.
        // REST is intentionally the primary Android transport while the WebSocket
        // path remains optional; the UI must not depend on socket OPEN state.
        marketBackgroundExecutor.scheduleWithFixedDelay(() -> {
            if (!cleanFeedInFlight.compareAndSet(false, true)) return;
            networkExecutor.execute(() -> {
                try {
                    String payload = null;
                    String[] bases = {
                        "https://api.lbkex.com",
                        "https://www.lbkex.net"
                    };
                    for (String base : bases) {
                        try {
                            payload = httpGet(base + "/v2/ticker/24hr.do?symbol=all");
                            if (payload != null && payload.length() > 20) {
                                diagLastUrl = base + "/v2/ticker/24hr.do?symbol=all";
                                break;
                            }
                        } catch (Exception ignored) {}
                    }
                    if (payload != null) {
                        cacheBulkMarketPayload(payload);
                        lastBulkSuccessAt = System.currentTimeMillis();
                        pushNativeCacheToWeb();
                    }
                    // Keep the authoritative universe separate from price transport.
                    // It is metadata only and never fabricates a price.
                    if (nativeUniverseSnapshot == null || System.currentTimeMillis() % 15000L < 5000L) {
                        fetchNativeMarketUniverse();
                    }
                } catch (Exception e) {
                    diagLastError = String.valueOf(e.getMessage());
                } finally {
                    cleanFeedInFlight.set(false);
                }
            });
        }, 0, 2, TimeUnit.SECONDS);

        // Direct repair lane: only symbols that still have no fresh LBank price.
        marketBackgroundExecutor.scheduleWithFixedDelay(() -> {
            try { refreshBackgroundMissingSymbols(); } catch (Exception ignored) {}
        }, 2, 3, TimeUnit.SECONDS);
    }


    // TV58: the installed LBank APK does not build the Markets page from the old
    // public v2 currencyPairs endpoint. Its current market module uses the newer
    // uuapi backend, especially /spot-market-center/edge/symbolList and
    // /spot-market-center/v2/ticker/24hr/intact. Parse those responses generically
    // because their envelope has changed between app releases.
    private static String normPair(String raw) {
        if (raw == null) return "";
        String x = raw.trim().toLowerCase(Locale.US).replace('-', '_').replace('/', '_').replace(':', '_').replace(" ", '_');
        if (x.endsWith("_usdt")) return x;
        if (x.endsWith("usdt") && x.length() > 4) return x.substring(0, x.length()-4) + "_usdt";
        return x;
    }

    private void collectNewLbankMarketData(Object node, org.json.JSONArray pairs, org.json.JSONArray tickers, java.util.HashSet<String> seen) {
        if (node == null || node == JSONObject.NULL) return;
        if (node instanceof org.json.JSONArray) {
            org.json.JSONArray a=(org.json.JSONArray)node;
            for(int i=0;i<a.length();i++) collectNewLbankMarketData(a.opt(i), pairs, tickers, seen);
            return;
        }
        if (!(node instanceof JSONObject)) return;
        JSONObject o=(JSONObject)node;
        String sym="";
        String[] symKeys={"symbol","pair","instrumentID","instrumentId","currencyPair","symbolName","symbolId","symbolNameEn","market"};
        for(String k:symKeys){ String v=o.optString(k,""); String n=normPair(v); if(n.endsWith("_usdt")){sym=n;break;} }
        if(sym.length()==0){
            String base="", quote="";
            String[] baseKeys={"baseCoin","base","baseCurrency","baseAsset","coin"};
            String[] quoteKeys={"quoteCoin","quote","quoteCurrency","quoteAsset"};
            for(String k:baseKeys){String v=o.optString(k,"").trim();if(v.length()>0){base=v;break;}}
            for(String k:quoteKeys){String v=o.optString(k,"").trim();if(v.length()>0){quote=v;break;}}
            if(base.length()>0 && quote.equalsIgnoreCase("usdt")) sym=normPair(base+"_usdt");
        }
        if(sym.length()>0 && seen.add(sym)) pairs.put(sym);
        if(sym.length()>0){
            JSONObject t=new JSONObject();
            try {
                String[] priceKeys={"latest","lastPrice","last","price","close","closePrice","lastTradedPrice"};
                String[] changeKeys={"change","changeRate","changePercent","priceChangePercent","increase","riseRate"};
                String[] volKeys={"vol","volume","quoteVolume","amount","turnover"};
                String price="", change="0", vol="0";
                for(String k:priceKeys){String v=o.optString(k,"");if(v.length()>0){price=v;break;}}
                for(String k:changeKeys){String v=o.optString(k,"");if(v.length()>0){change=v;break;}}
                for(String k:volKeys){String v=o.optString(k,"");if(v.length()>0){vol=v;break;}}
                t.put("latest",price); t.put("change",change); t.put("vol",vol);
                t.put("raw",o);
                tickers.put(new JSONObject().put("symbol",sym).put("ticker",t));
            } catch(Exception ignored) {}
        }
        java.util.Iterator<String> it=o.keys();
        while(it.hasNext()){
            String k=it.next(); Object v=o.opt(k);
            if(v instanceof JSONObject || v instanceof org.json.JSONArray) collectNewLbankMarketData(v,pairs,tickers,seen);
            else {
                String n=normPair(k);
                if(n.endsWith("_usdt") && seen.add(n)) pairs.put(n);
            }
        }
    }

    private JSONObject fetchNewLbankSnapshot() {
        // TV60: mirror the LBank APK's Market Center routes, not only symbolList.
        // The APK contains several market feeds; any one of these can seed the
        // complete/large USDT universe when a particular endpoint is partial.
        String[] hosts={
            "https://uuapi.lbk.world",
            "https://uuapi.lbktech.com",
            "https://uuapi.api4basic.com"
        };
        String[] paths={
            "/spot-market-center/edge/symbolList",
            "/spot-market-center/v2/ticker/24hr/intact",
            "/spot-market-center/tick/globalFirst",
            "/spot-market-center/tick/increaseRank",
            "/spot-market-center/edge/increaseRank",
            "/spot-market-center/tick/new-symbol-rank/spot",
            "/spot-market-center/edge/newSymbolRank"
        };
        for(String host:hosts){
            try{
                org.json.JSONArray pairs=new org.json.JSONArray();
                org.json.JSONArray tickers=new org.json.JSONArray();
                java.util.HashSet<String> seen=new java.util.HashSet<>();
                int successful=0;
                for(String path:paths){
                    try{
                        String raw=httpGet(host+path);
                        if(raw==null||raw.trim().isEmpty()) continue;
                        successful++;
                        Object r; String z=raw.trim();
                        if(z.startsWith("[")) r=new org.json.JSONArray(z); else r=new JSONObject(z);
                        collectNewLbankMarketData(r,pairs,tickers,seen);
                    }catch(Exception ignored){}
                }
                // The APK's market entities use symbol/close/change/volume.
                // Keep cache rows in the same atomic payload as the discovered universe.
                if(pairs.length()>0){
                    JSONObject out=new JSONObject();
                    out.put("pairs",pairs);
                    out.put("tickers",tickers);
                    out.put("cache",new org.json.JSONArray(getNativeMarketCachePayload()));
                    out.put("source","LBank-APK-MarketCenter:"+host);
                    out.put("routesOk",successful);
                    return out;
                }
            }catch(Exception ignored){}
        }
        return null;
    }

    private void cacheOurbitBulkTickerPayload(org.json.JSONArray rows) {
        if(rows==null)return;
        long now=System.currentTimeMillis();
        for(int i=0;i<rows.length();i++){
            try{
                JSONObject r=rows.optJSONObject(i); if(r==null)continue;
                String raw=r.optString("symbol",r.optString("pair","")).trim().toUpperCase(Locale.US).replace("/","").replace("_","");
                if(!raw.endsWith("USDT")||raw.length()<=4)continue;
                String base=raw.substring(0,raw.length()-4);
                double price=tickerNumber(r,"lastPrice","last","price","close");
                if(Double.isNaN(price)||price<=0)continue;
                JSONObject out=new JSONObject(); out.put("symbol",base); out.put("price",price); out.put("change",Double.isNaN(tickerNumber(r,"priceChangePercent","changePercent","change"))?0:tickerNumber(r,"priceChangePercent","changePercent","change")); out.put("volume",Double.isNaN(tickerNumber(r,"quoteVolume","volume","amount"))?0:tickerNumber(r,"quoteVolume","volume","amount")); out.put("lastUpdate",now); out.put("provider","Ourbit Native Universe");
                nativeMarketCache.put(base,out.toString());
            }catch(Exception ignored){}
        }
    }

    // Stage 1179: Ourbit is the authoritative Home/Market universe when reachable.
    // This prevents the Home page from rendering stale LBank/CoinPaprika symbols that
    // Ourbit does not quote (which previously left entire alphabetic sections as "—").
    private JSONObject fetchNativeOurbitUniverseSnapshot() {
        try {
            String raw = httpGet("https://api.ourbit.com/api/v3/ticker/24hr");
            if (raw == null || raw.trim().isEmpty()) return null;
            Object root = raw.trim().startsWith("[") ? new org.json.JSONArray(raw) : new JSONObject(raw);
            org.json.JSONArray rows = new org.json.JSONArray();
            if (root instanceof org.json.JSONArray) rows=(org.json.JSONArray)root;
            else {
                JSONObject o=(JSONObject)root;
                Object d=o.opt("data");
                if (d instanceof org.json.JSONArray) rows=(org.json.JSONArray)d;
                else if (d instanceof JSONObject) {
                    JSONObject m=(JSONObject)d; java.util.Iterator<String> it=m.keys();
                    while(it.hasNext()) { String k=it.next(); Object v=m.opt(k); if(v instanceof JSONObject){ JSONObject r=(JSONObject)v; if(!r.has("symbol")) r.put("symbol",k); rows.put(r);} }
                }
            }
            if (rows.length() == 0) return null;
            org.json.JSONArray pairs=new org.json.JSONArray(), tickers=new org.json.JSONArray();
            java.util.HashSet<String> seen=new java.util.HashSet<>();
            for(int i=0;i<rows.length();i++){
                JSONObject r=rows.optJSONObject(i); if(r==null) continue;
                String rawSym=r.optString("symbol",r.optString("pair","")).trim().toUpperCase(Locale.US).replace("/","").replace("_","");
                if(!rawSym.endsWith("USDT")||rawSym.length()<=4) continue;
                String base=rawSym.substring(0,rawSym.length()-4), pair=base.toLowerCase(Locale.US)+"_usdt";
                if(!seen.add(base)) continue;
                double price=tickerNumber(r,"lastPrice","last","price","close");
                double change=tickerNumber(r,"priceChangePercent","changePercent","change","priceChange");
                double vol=tickerNumber(r,"quoteVolume","volume","amount");
                JSONObject t=new JSONObject(); t.put("symbol",pair); t.put("ticker",new JSONObject().put("latest",Double.isNaN(price)?0:price).put("change",Double.isNaN(change)?0:change).put("vol",Double.isNaN(vol)?0:vol));
                pairs.put(pair); tickers.put(t);
            }
            if(pairs.length()==0) return null;
            JSONObject out=new JSONObject(); out.put("pairs",pairs); out.put("tickers",tickers); out.put("source","Ourbit-Native-24hr"); out.put("pairsCount",pairs.length()); out.put("tickerCount",tickers.length()); out.put("cache",new org.json.JSONArray());
            return out;
        } catch(Exception ignored){ return null; }
    }

    private void fetchNativeMarketUniverse() {
        if (!universeInFlight.compareAndSet(false, true)) return;
        networkExecutor.execute(() -> {
            try {
                // Stage 1179: Ourbit-first universe. If it succeeds, Home receives only
                // symbols that actually have a live Ourbit 24h ticker. LBank remains a
                // fallback for network/provider outages.
                JSONObject ourbitSnapshot = fetchNativeOurbitUniverseSnapshot();
                if (ourbitSnapshot != null && ourbitSnapshot.optJSONArray("pairs") != null && ourbitSnapshot.optJSONArray("pairs").length() >= 10) {
                    org.json.JSONArray ot=ourbitSnapshot.optJSONArray("tickers");
                    cacheOurbitBulkTickerPayload(ot);
                    nativeUniverseSnapshot=ourbitSnapshot.toString();
                    lastBulkSuccessAt=System.currentTimeMillis();
                    pushNativeUniverseToWeb();
                    pushNativeCacheToWeb();
                    return;
                }
                // Provider fallback: use existing LBank universe path if Ourbit is
                // unavailable on the device/network.
                // TV58: use the same newer market backend discovered inside the
                // supplied LBank APK before touching the legacy v2 endpoints.
                JSONObject newSnapshot = fetchNewLbankSnapshot();
                // TV93: the Market Center routes are a discovery source, not the final
                // price source. They can contain a very large symbol catalogue with
                // sparse/empty ticker fields. Never return early here. Seed the legacy
                // LBank bulk merge below with the new snapshot, then merge the official
                // bulk ticker on top so every symbol gets the strongest available live
                // price before Home is rebuilt.
                org.json.JSONArray seededPairs = new org.json.JSONArray();
                org.json.JSONArray seededTickers = new org.json.JSONArray();
                if (newSnapshot != null && newSnapshot.optJSONArray("pairs") != null && newSnapshot.optJSONArray("pairs").length() > 0) {
                    org.json.JSONArray np = newSnapshot.optJSONArray("pairs");
                    org.json.JSONArray nt = newSnapshot.optJSONArray("tickers");
                    for (int i=0;i<np.length();i++) seededPairs.put(np.optString(i));
                    if (nt != null) for (int i=0;i<nt.length();i++) seededTickers.put(nt.opt(i));
                    cacheSnapshotTickers(nt);
                }

                // Legacy public API remains a second official LBank source. It is
                // intentionally merged even when Market Center succeeded.
                // current LBank app backend is temporarily unavailable.
                // TV46: currencyPairs.do is the authoritative universe. The old
                // implementation derived the universe only from ticker/24hr?symbol=all,
                // which can be a partial list on some LBank responses.
                String pairsRaw = null;
                try { pairsRaw = httpGet("https://api.lbkex.com/v2/currencyPairs.do"); }
                catch (Exception e1) {
                    try { pairsRaw = httpGet("https://www.lbkex.net/v2/currencyPairs.do"); }
                    catch (Exception e2) { try { pairsRaw = httpGet("https://api.lbank.info/v2/currencyPairs.do"); } catch (Exception e3) {} }
                }

                org.json.JSONArray usdtPairs = seededPairs;
                org.json.JSONArray tickerRows = seededTickers;
                if (pairsRaw != null) {
                    try {
                        // LBank has returned this endpoint in more than one public JSON
                        // shape over time: {data:["btc_usdt",...]}, a bare array, and
                        // object rows containing symbol/pair. Accept all of them.
                        java.util.HashSet<String> seenPairParse = new java.util.HashSet<>();
                        Object root;
                        String trimmed = pairsRaw.trim();
                        if (trimmed.startsWith("[")) root = new org.json.JSONArray(trimmed);
                        else root = new JSONObject(trimmed);
                        java.util.ArrayDeque<Object> stack = new java.util.ArrayDeque<>();
                        stack.push(root);
                        while (!stack.isEmpty()) {
                            Object node = stack.pop();
                            if (node instanceof org.json.JSONArray) {
                                org.json.JSONArray a=(org.json.JSONArray)node;
                                for(int i=0;i<a.length();i++){ Object v=a.opt(i); if(v!=null) stack.push(v); }
                            } else if (node instanceof JSONObject) {
                                JSONObject o=(JSONObject)node;
                                String[] keys={"symbol","pair","name","market","currencyPair"};
                                for(String key:keys){ String v=o.optString(key,"").trim().toLowerCase(Locale.US); if(v.endsWith("_usdt") && seenPairParse.add(v)) usdtPairs.put(v); }
                                java.util.Iterator<String> it=o.keys();
                                while(it.hasNext()){ String k=it.next(); Object v=o.opt(k);
                                    // Some LBank responses are maps keyed by the pair itself.
                                    String kl=k==null?"":k.trim().toLowerCase(Locale.US);
                                    if(kl.endsWith("_usdt") && seenPairParse.add(kl)) usdtPairs.put(kl);
                                    if(v instanceof JSONObject || v instanceof org.json.JSONArray) stack.push(v);
                                }
                            } else if (node != null) {
                                String v=String.valueOf(node).trim().toLowerCase(Locale.US);
                                if(v.endsWith("_usdt") && seenPairParse.add(v)) usdtPairs.put(v);
                            }
                        }
                    } catch (Exception ignored) {}
                }

                // TV53: LBank's accuracy endpoint is a second authoritative
                // all-pairs catalogue. It returns objects containing `symbol`
                // and is useful when currencyPairs/ticker=all is partial on
                // a mobile route. Merge it with currencyPairs instead of
                // replacing either source.
                String accuracyRaw = null;
                try { accuracyRaw = httpGet("https://api.lbkex.com/v2/accuracy.do"); }
                catch (Exception e1) {
                    try { accuracyRaw = httpGet("https://www.lbkex.net/v2/accuracy.do"); }
                    catch (Exception e2) { try { accuracyRaw = httpGet("https://api.lbank.info/v2/accuracy.do"); } catch (Exception e3) {} }
                }
                if (accuracyRaw != null) {
                    try {
                        Object rootA; String ta=accuracyRaw.trim();
                        if (ta.startsWith("[")) rootA=new org.json.JSONArray(ta); else rootA=new JSONObject(ta);
                        java.util.ArrayDeque<Object> stA=new java.util.ArrayDeque<>(); stA.push(rootA);
                        java.util.HashSet<String> seenA=new java.util.HashSet<>();
                        for(int i=0;i<usdtPairs.length();i++) seenA.add(usdtPairs.optString(i).toLowerCase(Locale.US));
                        while(!stA.isEmpty()){
                            Object node=stA.pop();
                            if(node instanceof org.json.JSONArray){org.json.JSONArray a=(org.json.JSONArray)node;for(int i=0;i<a.length();i++){Object v=a.opt(i);if(v!=null)stA.push(v);}}
                            else if(node instanceof JSONObject){JSONObject o=(JSONObject)node;String v=o.optString("symbol","").trim().toLowerCase(Locale.US);if(v.endsWith("_usdt")&&seenA.add(v))usdtPairs.put(v);java.util.Iterator<String> it=o.keys();while(it.hasNext()){String k=it.next();Object x=o.opt(k);String kl=k==null?"":k.trim().toLowerCase(Locale.US);if(kl.endsWith("_usdt")&&seenA.add(kl))usdtPairs.put(kl);if(x instanceof JSONObject||x instanceof org.json.JSONArray)stA.push(x);}}
                        }
                    } catch(Exception ignored){}
                }

                String tickerRaw = null;
                try { tickerRaw = httpGet("https://api.lbkex.com/v2/ticker/24hr.do?symbol=all"); }
                catch (Exception e1) {
                    try { tickerRaw = httpGet("https://www.lbkex.net/v2/ticker/24hr.do?symbol=all"); }
                    catch (Exception e2) { try { tickerRaw = httpGet("https://api.lbank.info/v2/ticker/24hr.do?symbol=all"); } catch (Exception e3) {} }
                }

                if (tickerRaw != null) {
                    try {
                        JSONObject tq = new JSONObject(tickerRaw);
                        tickerRows = tq.optJSONArray("data");
                        if (tickerRows == null) {
                            Object dataObj = tq.opt("data");
                            if (dataObj instanceof JSONObject) {
                                JSONObject dm=(JSONObject)dataObj;
                                java.util.Iterator<String> it=dm.keys();
                                while(it.hasNext()){
                                    String k=it.next(); Object v=dm.opt(k);
                                    if(k!=null && k.toLowerCase(Locale.US).endsWith("_usdt") && v instanceof JSONObject){
                                        JSONObject row=new JSONObject(); row.put("symbol",k.toLowerCase(Locale.US));
                                        row.put("ticker",v); tickerRows.put(row);
                                    }
                                }
                            }
                        }
                        if (tickerRows == null) tickerRows = new org.json.JSONArray();
                        if (tickerRows.length()==0) { try { tickerRows = new org.json.JSONArray(tickerRaw); } catch (Exception ignored2) {} }
                    } catch (Exception ignored) {
                        try { tickerRows = new org.json.JSONArray(tickerRaw); } catch (Exception ignored2) {}
                    }
                }

                // The bulk ticker cache is also an authoritative LBank market source.
                // If the pair catalogue endpoint is delayed/blocked, keep every USDT
                // symbol already parsed from the LBank ticker cache instead of showing
                // an empty market screen.
                try {
                    java.util.HashSet<String> seenCachePairs=new java.util.HashSet<>();
                    for(int i=0;i<usdtPairs.length();i++) seenCachePairs.add(usdtPairs.optString(i).toLowerCase(Locale.US));
                    for(String ck:nativeMarketCache.keySet()){ String base=String.valueOf(ck).toLowerCase(Locale.US); if(base.length()>0){ String pair=base.endsWith("_usdt")?base:base+"_usdt"; if(seenCachePairs.add(pair)) usdtPairs.put(pair); } }
                } catch(Exception ignored) {}

                // Build the universe from BOTH official LBank public endpoints.
                // If the device/network receives an unusually short LBank universe,
                // use Binance only as a SYMBOL DISCOVERY fallback. Prices are still
                // requested from LBank for those symbols, so the market data source
                // remains LBank rather than silently replacing prices with Binance.
                // Do not manufacture the LBank universe from another exchange.
                // If LBank returns fewer pairs, retain the previously verified LBank
                // universe below and expose the actual count for diagnostics.
                // Either response can be partial/transient; unioning prevents a
                // short response from making the app look like it only has ~30 coins.
                if (tickerRows.length() > 0) {
                    java.util.HashSet<String> seen = new java.util.HashSet<>();
                    for (int i = 0; i < usdtPairs.length(); i++) seen.add(usdtPairs.optString(i).toLowerCase(Locale.US));
                    for (int i = 0; i < tickerRows.length(); i++) {
                        JSONObject row = tickerRows.optJSONObject(i);
                        if (row == null) continue;
                        String pair = row.optString("symbol", "").toLowerCase(Locale.US);
                        if (pair.endsWith("_usdt") && seen.add(pair)) usdtPairs.put(pair);
                    }
                }

                if (usdtPairs.length() > 0) {
                    // Keep the largest known LBank USDT universe. A transient/partial
                    // response must never shrink the market list on the phone.
                    // TV78: the current LBank market-center/public snapshot is
                    // authoritative. Do not resurrect symbols from a previous
                    // in-memory snapshot; stale pairs were causing rows with
                    // correct-looking names but no current price.
                    nativeSupportedPairs.clear();
                    for (int i = 0; i < usdtPairs.length(); i++) {
                        nativeSupportedPairs.add(usdtPairs.optString(i).toLowerCase(Locale.US));
                    }
                    if (tickerRaw != null) cacheBulkMarketPayload(tickerRaw);
                    lastBulkSuccessAt = System.currentTimeMillis();
                    JSONObject payload = new JSONObject();
                    payload.put("pairs", usdtPairs);
                    payload.put("tickers", tickerRows);
                    payload.put("pairsCount", usdtPairs.length());
                    payload.put("tickerCount", tickerRows.length());
                    payload.put("accuracyCount", accuracyRaw == null ? 0 : 1);
                    // Include the already parsed native cache in the same atomic
                    // payload. This removes any race between the bulk ticker poll
                    // and the universe callback after a WebView page recreation.
                    try { payload.put("cache", new org.json.JSONArray(getNativeMarketCachePayload())); } catch (Exception ignored) {}
                    nativeUniverseSnapshot = payload.toString();
                    pushNativeUniverseToWeb();
                    pushNativeCacheToWeb();
                    // The socket may have opened before REST discovery completed.
                    // Re-run subscription expansion now that the authoritative pair
                    // set is known.
                    subscribeNativeUniverseAsync();
                    return;
                }

                // If LBank is unreachable on the device/network, keep the app live
                // with a public secondary universe. LBank remains first choice.
                String fallbackRaw = null;
                try { fallbackRaw = httpGet("https://api.binance.com/api/v3/ticker/24hr"); } catch (Exception ignored) {}
                org.json.JSONArray rows = fallbackRaw == null ? new org.json.JSONArray() : new org.json.JSONArray(fallbackRaw);
                // Last-resort symbol discovery only. Prices are NOT taken from CoinCap
                // here; the existing LBank per-symbol fetch path will fill them.
                if (rows.length() == 0) {
                    try {
                        String cc = httpGet("https://api.coincap.io/v2/assets?limit=2000");
                        JSONObject cq = new JSONObject(cc);
                        org.json.JSONArray assets = cq.optJSONArray("data");
                        if (assets != null) {
                            for (int i=0;i<assets.length();i++) {
                                JSONObject a=assets.optJSONObject(i); if(a==null) continue;
                                String sym=a.optString("symbol","").trim().toUpperCase(Locale.US);
                                if(sym.matches("[A-Z0-9]{2,20}")) {
                                    JSONObject r=new JSONObject(); r.put("symbol",sym+"USDT"); r.put("lastPrice",a.optString("priceUsd","0")); r.put("priceChangePercent","0"); r.put("quoteVolume","0"); rows.put(r);
                                }
                            }
                        }
                    } catch (Exception ignored) {}
                }
                org.json.JSONArray pairs = new org.json.JSONArray();
                org.json.JSONArray tickers = new org.json.JSONArray();
                nativeSupportedPairs.clear();
                for (int i = 0; i < rows.length(); i++) {
                    JSONObject r = rows.optJSONObject(i); if (r == null) continue;
                    String sym = r.optString("symbol", "").toUpperCase(Locale.US);
                    if (!sym.endsWith("USDT") || sym.length() <= 4) continue;
                    String base = sym.substring(0, sym.length()-4);
                    String pair = base.toLowerCase(Locale.US) + "_usdt";
                    pairs.put(pair); tickers.put(new JSONObject().put("symbol", pair).put("ticker", new JSONObject().put("latest", r.optString("lastPrice", "0")).put("change", r.optString("priceChangePercent", "0")).put("vol", r.optString("quoteVolume", "0"))));
                    nativeSupportedPairs.add(pair);
                }
                if (fallbackRaw != null) cacheBinanceBulkMarketPayload(fallbackRaw);
                JSONObject payload = new JSONObject(); payload.put("pairs", pairs); payload.put("tickers", tickers);
                nativeUniverseSnapshot = payload.toString();
                lastBulkSuccessAt = System.currentTimeMillis();
                pushNativeUniverseToWeb(); pushNativeCacheToWeb();
            } catch (Exception ignored) {
            } finally { universeInFlight.set(false); }
        });
    }

    private void refreshBackgroundMissingSymbols() {
        if (backgroundMissingSymbols.isEmpty()) return;
        final long now = System.currentTimeMillis();
        int count = 0;
        for (String sym : backgroundMissingSymbols) {
            if (count >= 12) break;
            Long last = missingLastAttempt.get(sym);
            if (last != null && now - last < 2500L) continue;
            missingLastAttempt.put(sym, now);
            count++;
            priorityMarketExecutor.execute(() -> fetchAndCacheOneSymbol(sym));
        }
    }

    private JSONObject fetchAndCacheOneSymbol(String sym) {
        if (sym == null || sym.isEmpty()) return null;
        String requestSym = sym.toUpperCase(Locale.US);
        if ("MATIC".equals(requestSym)) requestSym = "POL";
        if ("FTM".equals(requestSym)) requestSym = "S";
        JSONObject one = null;
        // Stage 1177: Ourbit is the primary public market-data source. LBank remains
        // only as a fallback so existing installations do not lose connectivity.
        try {
            String ourbitSym = requestSym + "USDT";
            String or = httpGet("https://api.ourbit.com/api/v3/ticker/24hr?symbol=" + ourbitSym);
            JSONObject oq = new JSONObject(or);
            JSONObject tick = oq;
            if (oq.opt("data") instanceof org.json.JSONArray) tick = ((org.json.JSONArray)oq.opt("data")).optJSONObject(0);
            if (tick == null && oq.opt("result") instanceof org.json.JSONArray) tick = ((org.json.JSONArray)oq.opt("result")).optJSONObject(0);
            double price = tickerNumber(tick, "lastPrice","last","price","close");
            double change = tickerNumber(tick, "priceChangePercent","changePercent","change");
            double volume = tickerNumber(tick, "quoteVolume","volume","vol");
            if (!Double.isNaN(price) && price > 0) {
                one = new JSONObject(); one.put("symbol", sym); one.put("price", price);
                one.put("change", Double.isNaN(change)?0:change); one.put("volume", Double.isNaN(volume)?0:volume);
                one.put("lastUpdate", System.currentTimeMillis()); one.put("provider", "Ourbit Native Background Single");
            }
        } catch (Exception ignoredOurbit) {}
        // The discovery catalogue can be partial. Never use it as a gate for a
        // price request: always give the official LBank pair a chance first.
        final String requiredPair = requestSym.toLowerCase(Locale.US) + "_usdt";
        try {
            String pair = requiredPair;
            String tr = null;
            String[] lbankBases = {"https://api.lbank.info", "https://api.lbkex.com", "https://www.lbkex.net"};
            for (String base : lbankBases) {
                try {
                    tr = httpGet(base + "/v2/ticker/24hr.do?symbol=" + pair);
                    if (tr != null && !tr.isEmpty()) break;
                } catch (Exception ignoredBase) {}
            }
            if (tr == null || tr.isEmpty()) throw new Exception("LBank single ticker unavailable");
            JSONObject tq = new JSONObject(tr);
            JSONObject tick = firstTickerObject(tq);
            if (tick != null) {
                double price = tickerNumber(tick, "latest","lastPrice","last","price","close","closePrice","lastTradedPrice");
                double change = tickerNumber(tick, "change","changeRate","changePercent","priceChangePercent","increase","riseRate");
                double volume = tickerNumber(tick, "vol","volume","quoteVolume","amount","turnover");
                if (!Double.isNaN(price) && price > 0) {
                    one = new JSONObject();
                    one.put("symbol", sym);
                    one.put("price", price);
                    one.put("change", Double.isNaN(change) ? 0 : change);
                    one.put("volume", Double.isNaN(volume) ? 0 : volume);
                    one.put("lastUpdate", System.currentTimeMillis());
                    one.put("provider", "LBank Native Background Single");
                }
            }
        } catch (Exception ignored) {}
        if (one == null) {
            try {
                String binanceSym = requestSym + "USDT";
                String br = httpGet("https://api.binance.com/api/v3/ticker/24hr?symbol=" + binanceSym);
                JSONObject b = new JSONObject(br);
                double price = b.optDouble("lastPrice", Double.NaN);
                if (!Double.isNaN(price) && price > 0) {
                    one = new JSONObject();
                    one.put("symbol", sym);
                    one.put("price", price);
                    one.put("change", b.optDouble("priceChangePercent", 0));
                    one.put("volume", b.optDouble("volume", 0));
                    one.put("lastUpdate", System.currentTimeMillis());
                    one.put("provider", "Secondary Native Background");
                }
            } catch (Exception ignored) {}
        }
        if (one != null) {
            nativeMarketCache.put(sym.toUpperCase(Locale.US), one.toString());
            pushNativeCacheToWeb();
        }
        return one;
    }

    /** Native network bridge: avoids WebView CORS/network restrictions for public market data. */
    private void pushNativeSocketEvent(String type, String extra) {
        try {
            JSONObject o = new JSONObject();
            o.put("type", type);
            o.put("state", lbankNativeSocket != null ? "OPEN" : "CLOSED");
            o.put("attempts", lbankWsAttempts);
            o.put("messages", lbankWsMessages);
            o.put("errors", lbankWsErrors);
            o.put("closeCode", lbankWsCloseCode);
            o.put("lastMessage", lbankWsLastMessage);
            o.put("lastOpen", lbankWsLastOpen);
            o.put("lastPong", lbankWsLastPong);
            o.put("retry", lbankWsRetry);
            o.put("error", lbankWsLastError);
            if (extra != null) o.put("extra", extra);
            final String payload = JSONObject.quote(o.toString());
            if (web != null) web.post(() -> web.evaluateJavascript("window.cpNativeSocketEvent && window.cpNativeSocketEvent(" + payload + ");", null));
        } catch (Exception ignored) {}
    }

    private void scheduleNativeLbankReconnect() {
        if (lbankWsManualClose || lbankSocketConnecting.get()) return;
        int attempt = Math.min(lbankWsRetry++, 8);
        long delay = Math.min(30000L, 1000L * (1L << Math.min(attempt, 5))) + (long)(Math.random() * 700L);
        lbankWsScheduler.schedule(this::startNativeLbankSocket, delay, TimeUnit.MILLISECONDS);
    }

    private void sendNativeWsJson(WebSocket ws, JSONObject obj) {
        try { ws.send(obj.toString()); } catch (Exception ignored) {}
    }

    private void subscribeNativeTicker(WebSocket ws, String pair) {
        if (ws == null || pair == null) return;
        String p = pair.trim().toLowerCase(Locale.US);
        if (!p.endsWith("_usdt")) return;
        if (!lbankWsSubscribedPairs.add(p)) return;
        try {
            JSONObject sub = new JSONObject();
            sub.put("action", "subscribe");
            sub.put("subscribe", "tick");
            sub.put("pair", p);
            sendNativeWsJson(ws, sub);
        } catch (Exception ignored) {
            lbankWsSubscribedPairs.remove(p);
        }
    }

    /**
     * Subscribe the current LBank USDT universe gradually. LBank documents a
     * 200 requests/10s public endpoint limit; pacing subscription messages avoids
     * turning a reconnect into a burst while still bringing the whole market online.
     */
    private void subscribeNativeUniverseAsync() {
        if (lbankWsSubscriptionQueueRunning.getAndSet(true)) return;
        marketBackgroundExecutor.execute(() -> {
            try {
                WebSocket ws = lbankNativeSocket;
                if (ws == null) return;
                java.util.ArrayList<String> pairs = new java.util.ArrayList<>(nativeSupportedPairs);
                java.util.Collections.sort(pairs);
                // Prioritize the common/high-visibility pairs, then subscribe the rest.
                String[] priority = {"btc_usdt","eth_usdt","bnb_usdt","sol_usdt","xrp_usdt","doge_usdt","ada_usdt","trx_usdt"};
                java.util.HashSet<String> ordered = new java.util.HashSet<>();
                for (String p : priority) {
                    if (nativeSupportedPairs.contains(p)) {
                        subscribeNativeTicker(ws, p);
                        ordered.add(p);
                    }
                }
                for (String p : pairs) {
                    if (ordered.contains(p)) continue;
                    if (lbankNativeSocket != ws || lbankWsManualClose) break;
                    subscribeNativeTicker(ws, p);
                    try { Thread.sleep(60L); } catch (InterruptedException e) { Thread.currentThread().interrupt(); break; }
                }
                pushNativeSocketEvent("subscribed", "pairs=" + lbankWsSubscribedPairs.size());
            } finally {
                lbankWsSubscriptionQueueRunning.set(false);
            }
        });
    }

    private void handleNativeLbankWsMessage(String raw) {
        if (raw == null || raw.trim().isEmpty()) return;
        lbankWsLastMessage = System.currentTimeMillis();
        lbankWsMessages++;
        try {
            JSONObject m = new JSONObject(raw);
            String action = m.optString("action", "").toLowerCase(Locale.US);
            if ("pong".equals(action)) { lbankWsLastPong = System.currentTimeMillis(); pushNativeSocketEvent("pong", ""); return; }
            if ("ping".equals(action)) {
                JSONObject pong = new JSONObject(); pong.put("action", "pong"); pong.put("pong", m.optString("ping", String.valueOf(System.currentTimeMillis())));
                WebSocket ws = lbankNativeSocket; if (ws != null) sendNativeWsJson(ws, pong);
                lbankWsLastPong = System.currentTimeMillis(); pushNativeSocketEvent("ping", ""); return;
            }
            if (m.has("code") && m.optInt("code", 0) != 0 && m.optInt("code", 0) != 200) {
                lbankWsLastError = "WS " + m.optString("code") + " " + m.optString("msg", m.optString("message", ""));
            }
            JSONObject t = null;
            Object[] candidates = {m.opt("tick"), m.opt("ticker"), m.opt("data"), m.opt("result"), m.opt("payload")};
            for (Object c : candidates) { t = findWsTicker(c); if (t != null) break; }
            if (t == null) return;
            double price = firstNumber(t, "latest", "lastPrice", "last", "price", "close", "closePrice");
            if (!(price > 0) || Double.isNaN(price)) return;
            String pair = m.optString("pair", m.optString("symbol", ""));
            if (pair.isEmpty() && t != null) pair = t.optString("pair", t.optString("symbol", ""));
            if (pair.isEmpty() && m.optJSONObject("data") != null) pair = m.optJSONObject("data").optString("pair", m.optJSONObject("data").optString("symbol", ""));
            pair = pair.toUpperCase(Locale.US);
            String sym = pair;
            if (sym.endsWith("_USDT")) sym = sym.substring(0, sym.length() - 5);
            sym = sym.replace("USDT", "");
            if (sym.isEmpty()) sym = "BTC";
            JSONObject row = new JSONObject();
            row.put("symbol", sym); row.put("price", price);
            row.put("change", firstNumber(t, "change", "changeRate", "changePercent", "rose"));
            row.put("volume", firstNumber(t, "vol", "volume", "amount"));
            row.put("lastUpdate", System.currentTimeMillis()); row.put("provider", "LBank Native WebSocket"); row.put("connected", true);
            nativeMarketCache.put(sym, row.toString());
            lbankWsLastError = "";
            pushNativeCacheToWeb();
            pushNativeSocketEvent("tick", sym + "=" + price);
        } catch (Exception e) {
            lbankWsErrors++; lbankWsLastError = "WS parse " + e.getMessage(); pushNativeSocketEvent("parse_error", "");
        }
    }

    private static JSONObject findWsTicker(Object node) {
        if (node == null || node == JSONObject.NULL) return null;
        if (node instanceof JSONObject) {
            JSONObject o = (JSONObject) node;
            String[] keys = {"latest","lastPrice","last","price","close","closePrice"};
            for (String k : keys) if (o.has(k) && !o.isNull(k)) return o;
            String[] nested = {"tick","ticker","data","result","payload","item"};
            for (String k : nested) { JSONObject x = findWsTicker(o.opt(k)); if (x != null) return x; }
            return null;
        }
        if (node instanceof org.json.JSONArray) {
            org.json.JSONArray a = (org.json.JSONArray) node;
            for (int i=0;i<a.length();i++) { JSONObject x = findWsTicker(a.opt(i)); if (x != null) return x; }
        }
        return null;
    }

    private static double firstNumber(JSONObject o, String... keys) {
        if (o == null) return Double.NaN;
        for (String k : keys) {
            Object v = o.opt(k); if (v == null || v == JSONObject.NULL) continue;
            try { double d = Double.parseDouble(String.valueOf(v)); if (!Double.isNaN(d)) return d; } catch (Exception ignored) {}
        }
        return Double.NaN;
    }

    public synchronized void startNativeLbankSocket() {
        lbankWsManualClose = false;
        if (lbankNativeSocket != null || lbankSocketConnecting.get()) return;
        lbankSocketConnecting.set(true); lbankWsAttempts++;
        String[] wsHosts = new String[]{"wss://www.lbkex.net/ws/V2/", "wss://api.lbank.info/ws/V2/"};
        String wsHost = wsHosts[Math.abs(lbankWsAttempts - 1) % wsHosts.length];
        Request request = new Request.Builder().url(wsHost).header("User-Agent", "CryptoPulse/Android-LBankWS").build();
        try {
            lbankNativeSocket = lbankWsClient.newWebSocket(request, new WebSocketListener() {
                @Override public void onOpen(WebSocket ws, Response response) {
                    lbankSocketConnecting.set(false);
                    lbankWsRetry=0;
                    lbankWsLastOpen=System.currentTimeMillis();
                    lbankWsLastError="";
                    lbankWsSubscribedPairs.clear();
                    // Always bring the eight priority markets online immediately,
                    // then expand to the complete discovered USDT universe.
                    for (String p : new String[]{"btc_usdt","eth_usdt","bnb_usdt","sol_usdt","xrp_usdt","doge_usdt","ada_usdt","trx_usdt"}) {
                        subscribeNativeTicker(ws, p);
                    }
                    pushNativeSocketEvent("open", "LBank native WebSocket OPEN: " + wsHost);
                    subscribeNativeUniverseAsync();
                }
                @Override public void onMessage(WebSocket ws, String text) { handleNativeLbankWsMessage(text); }
                @Override public void onClosing(WebSocket ws, int code, String reason) { lbankWsCloseCode=code; pushNativeSocketEvent("closing", reason); }
                @Override public void onClosed(WebSocket ws, int code, String reason) {
                    if (lbankNativeSocket == ws) lbankNativeSocket=null;
                    lbankSocketConnecting.set(false);
                    lbankWsCloseCode=code;
                    lbankWsSubscribedPairs.clear();
                    pushNativeSocketEvent("closed", reason);
                    scheduleNativeLbankReconnect();
                }
                @Override public void onFailure(WebSocket ws, Throwable t, Response response) {
                    if (lbankNativeSocket == ws) lbankNativeSocket=null;
                    lbankSocketConnecting.set(false);
                    lbankWsSubscribedPairs.clear();
                    lbankWsErrors++;
                    lbankWsLastError=String.valueOf(t.getMessage());
                    pushNativeSocketEvent("failure", lbankWsLastError);
                    scheduleNativeLbankReconnect();
                }
            });
        } catch (Exception e) {
            lbankNativeSocket=null; lbankSocketConnecting.set(false); lbankWsErrors++; lbankWsLastError=String.valueOf(e.getMessage()); pushNativeSocketEvent("failure", lbankWsLastError); scheduleNativeLbankReconnect();
        }
    }

    public synchronized void stopNativeLbankSocket() {
        lbankWsManualClose=true;
        WebSocket ws=lbankNativeSocket; lbankNativeSocket=null; lbankSocketConnecting.set(false);
        if(ws!=null) try{ws.close(1000,"app-stop");}catch(Exception ignored){}
    }

    private String getNativeSocketDiagnostic() {
        try {
            JSONObject o=new JSONObject();
            o.put("state", lbankNativeSocket!=null?"OPEN":"CLOSED"); o.put("attempts",lbankWsAttempts); o.put("messages",lbankWsMessages); o.put("errors",lbankWsErrors); o.put("closeCode",lbankWsCloseCode); o.put("lastMessage",lbankWsLastMessage); o.put("lastOpen",lbankWsLastOpen); o.put("lastPong",lbankWsLastPong); o.put("retry",lbankWsRetry); o.put("error",lbankWsLastError); return o.toString();
        } catch(Exception e){return "{}";}
    }

    private String normalizeFutureFeedSymbol(String symbol) {
        String s = symbol == null ? "BTC" : symbol.trim().toUpperCase(Locale.US);
        s = s.replaceAll("[^A-Z0-9]", "");
        if (s.endsWith("USDT") && s.length() > 4) s = s.substring(0, s.length()-4);
        return s;
    }

    private JSONObject futuresMarketRequest(String productGroup) throws Exception {
        final String g=productGroup==null?"SwapU":productGroup;
        final long now=System.currentTimeMillis();
        final Long at=futuresMarketRowsAt.get(g);
        final JSONObject cached=futuresMarketRowsCache.get(g);
        // The contract API is public and the documented REST host is lbkperp.lbank.com.
        // Keep the cache short so a 1.5s feed tick cannot accidentally reuse a 10s-old quote.
        if(cached!=null && at!=null && now-at<FUTURES_CACHE_TTL_MS)return cached;
        try{
            String url="https://lbkperp.lbank.com/cfd/openApi/v1/pub/marketData?productGroup="+URLEncoder.encode(g,"UTF-8");
            String raw=httpGet(url);
            Object parsed=new org.json.JSONTokener(raw).nextValue();
            org.json.JSONArray arr=null;
            if(parsed instanceof org.json.JSONArray)arr=(org.json.JSONArray)parsed;
            else if(parsed instanceof JSONObject){
                JSONObject o=(JSONObject)parsed;
                if(o.has("success") && !o.optBoolean("success",true)) throw new Exception("LBank "+o.optString("error_code")+" "+o.optString("msg"));
                Object d=o.opt("data");
                if(d instanceof org.json.JSONArray)arr=(org.json.JSONArray)d;
                else if(d instanceof JSONObject && ((JSONObject)d).opt("data") instanceof org.json.JSONArray)arr=((JSONObject)d).optJSONArray("data");
            }
            if(arr==null || arr.length()==0)throw new Exception("No futures market list");
            JSONObject out=new JSONObject().put("rows",arr).put("updatedAt",now);
            futuresMarketRowsCache.put(g,out); futuresMarketRowsAt.put(g,now);
            return out;
        }catch(Exception e){
            if(cached!=null)return cached;
            throw e;
        }
    }

    private JSONObject findFutureMarket(String symbol) throws Exception {
        String key = normalizeFutureFeedSymbol(symbol);
        // Current Contract API examples use the SwapU product group. Avoid trying
        // undocumented group names in series; that created long blank-screen delays.
        for (String group : new String[]{"SwapU"}) {
            try {
                JSONObject pack = futuresMarketRequest(group);
                org.json.JSONArray arr = pack.optJSONArray("rows");
                if (arr == null) continue;
                for (int i=0;i<arr.length();i++) {
                    JSONObject x = arr.optJSONObject(i); if (x == null) continue;
                    String xs = x.optString("symbol", "").toUpperCase(Locale.US).replaceAll("[^A-Z0-9]", "");
                    if (!xs.equals(key+"USDT") && !xs.equals(key)) continue;
                    double last = x.optDouble("lastPrice", Double.NaN);
                    if (!(last > 0)) last = x.optDouble("markedPrice", Double.NaN);
                    if (!(last > 0)) continue;
                    JSONObject out = new JSONObject();
                    out.put("symbol", x.optString("symbol", key+"USDT"));
                    out.put("lastPrice", last);
                    out.put("markedPrice", x.optDouble("markedPrice", last));
                    out.put("openPrice", x.optDouble("openPrice", last));
                    out.put("high", x.optDouble("highestPrice", last));
                    out.put("low", x.optDouble("lowestPrice", last));
                    out.put("volume", x.optDouble("volume", 0));
                    out.put("turnover", x.optDouble("turnover", 0));
                    out.put("funding", x.optDouble("prePositionFeeRate", 0));
                    out.put("source", "lbank-contract");
                    out.put("candleSource", "sampled");
                    out.put("candleExact", false);
                    out.put("updatedAt", System.currentTimeMillis());
                    return out;
                }
            } catch (Exception ignored) {}
        }
        throw new Exception("Futures symbol unavailable in SwapU");
    }

    private JSONObject futuresDepthRequest(String symbol, int depth) throws Exception {
        String key = normalizeFutureFeedSymbol(symbol)+"USDT";
        String cacheKey = normalizeFutureFeedSymbol(symbol);
        long now = System.currentTimeMillis();
        Long cachedAt = futuresDepthAt.get(cacheKey);
        JSONObject cached = futuresDepthCache.get(cacheKey);
        if (cached != null && cachedAt != null && now - cachedAt < FUTURES_CACHE_TTL_MS) return cached;
        Exception last = null;
        try {
                String raw = httpGet("https://lbkperp.lbank.com/cfd/openApi/v1/pub/marketOrder?symbol=" + URLEncoder.encode(key,"UTF-8") + "&depth=" + Math.min(50, Math.max(1, depth)));
                Object parsed = new org.json.JSONTokener(raw).nextValue();
                JSONObject o = parsed instanceof JSONObject ? (JSONObject)parsed : null;
                if (o == null) throw new Exception("Invalid futures orderbook response");
                Object d = o.opt("data");
                JSONObject src = d instanceof JSONObject ? (JSONObject)d : o;
                org.json.JSONArray asksIn = src.optJSONArray("asks"), bidsIn = src.optJSONArray("bids");
                if (asksIn == null && bidsIn == null) continue;
                JSONObject out = new JSONObject();
                out.put("asks", asksIn == null ? new org.json.JSONArray() : asksIn);
                out.put("bids", bidsIn == null ? new org.json.JSONArray() : bidsIn);
                out.put("updatedAt", System.currentTimeMillis());
                futuresDepthAt.put(cacheKey, System.currentTimeMillis());
                return out;
        } catch (Exception e) { last=e; }
        throw last == null ? new Exception("Futures orderbook unavailable") : last;
    }

    private void addFutureSample(String symbol, JSONObject m) {
        String key = normalizeFutureFeedSymbol(symbol);
        double p = m.optDouble("lastPrice", Double.NaN);
        if (!(p > 0)) return;
        long ts = System.currentTimeMillis();
        java.util.List<JSONObject> list = futuresSamplesCache.computeIfAbsent(key, k -> java.util.Collections.synchronizedList(new java.util.ArrayList<>()));
        synchronized (list) {
            JSONObject s = new JSONObject();
            try { s.put("t", ts); s.put("p", p); } catch (Exception ignored) {}
            list.add(s);
            long cutoff = ts - 3L*24L*60L*60L*1000L;
            int drop=0; while (drop<list.size() && list.get(drop).optLong("t",0)<cutoff) drop++;
            if (drop>0) list.subList(0,drop).clear();
            if (list.size()>5000) list.subList(0,list.size()-5000).clear();
        }
        futuresLastTickAt = ts;
    }

    private void pushFuturesWsDiagnostic(String state, String detail) {
        try {
            JSONObject o = new JSONObject();
            o.put("state", state);
            o.put("detail", detail == null ? "" : detail);
            o.put("openedAt", futuresWsOpenedAt);
            o.put("lastMessageAt", futuresWsLastMessageAt);
            o.put("messages", futuresWsMessages);
            o.put("closeCode", futuresWsCloseCode);
            o.put("retry", futuresWsRetry);
            o.put("url", "wss://lbkperpws.lbank.com/ws");
            o.put("now", System.currentTimeMillis());
            final String payload = o.toString();
            if (web != null) web.post(() -> web.evaluateJavascript("window.cpNativeFuturesWsDiag&&window.cpNativeFuturesWsDiag(" + JSONObject.quote(payload) + ");", null));
        } catch (Exception ignored) {}
    }

    private void startFuturesWebSocketDiagnostic() {
        if (futuresDiagnosticConnecting.getAndSet(true)) return;
        try {
            Request req = new Request.Builder().url("wss://lbkperpws.lbank.com/ws").build();
            futuresDiagnosticSocket = lbankWsClient.newWebSocket(req, new WebSocketListener() {
                @Override public void onOpen(WebSocket ws, Response response) {
                    futuresDiagnosticConnecting.set(false);
                    futuresWsOpenedAt = System.currentTimeMillis();
                    futuresWsLastMessageAt = 0L;
                    futuresWsMessages = 0L;
                    futuresWsCloseCode = 0;
                    futuresWsLastError = "";
                    futuresWsRetry = 0;
                    pushFuturesWsDiagnostic("OPEN", "Official Futures WebSocket connected; no guessed subscription sent.");
                }
                @Override public void onMessage(WebSocket ws, String text) {
                    futuresWsLastMessageAt = System.currentTimeMillis();
                    futuresWsMessages++;
                    String t = text == null ? "" : text.trim();
                    // Be conservative: only answer explicit ping envelopes.
                    try {
                        JSONObject o = new JSONObject(t);
                        if ("ping".equalsIgnoreCase(o.optString("action"))) {
                            JSONObject pong = new JSONObject();
                            pong.put("action", "pong");
                            if (o.has("ping")) pong.put("pong", o.optString("ping"));
                            ws.send(pong.toString());
                        }
                    } catch (Exception ignored) {}
                    pushFuturesWsDiagnostic("MESSAGE", t.length() > 220 ? t.substring(0,220) : t);
                }
                @Override public void onFailure(WebSocket ws, Throwable t, Response response) {
                    futuresDiagnosticConnecting.set(false);
                    futuresWsLastError = t == null ? "unknown" : String.valueOf(t.getMessage());
                    pushFuturesWsDiagnostic("ERROR", futuresWsLastError);
                    scheduleFuturesWebSocketDiagnosticRetry();
                }
                @Override public void onClosing(WebSocket ws, int code, String reason) {
                    futuresWsCloseCode = code;
                    pushFuturesWsDiagnostic("CLOSING", code + " " + (reason == null ? "" : reason));
                    ws.close(code, reason);
                }
                @Override public void onClosed(WebSocket ws, int code, String reason) {
                    futuresDiagnosticConnecting.set(false);
                    futuresWsCloseCode = code;
                    pushFuturesWsDiagnostic("CLOSED", code + " " + (reason == null ? "" : reason));
                    scheduleFuturesWebSocketDiagnosticRetry();
                }
            });
        } catch (Exception e) {
            futuresDiagnosticConnecting.set(false);
            futuresWsLastError = String.valueOf(e.getMessage());
            pushFuturesWsDiagnostic("ERROR", futuresWsLastError);
            scheduleFuturesWebSocketDiagnosticRetry();
        }
    }

    private void scheduleFuturesWebSocketDiagnosticRetry() {
        int n = Math.min(5, ++futuresWsRetry);
        long delay = Math.min(30000L, 3000L * (1L << Math.max(0, n-1)));
        try {
            if (!futuresBackgroundExecutor.isShutdown()) futuresBackgroundExecutor.schedule(this::startFuturesWebSocketDiagnostic, delay, TimeUnit.MILLISECONDS);
        } catch (Exception ignored) {}
    }

    private void startPersistentFuturesFeed(String symbol) {
        String key = normalizeFutureFeedSymbol(symbol);
        if (key.isEmpty()) return;
        futuresFeedSymbols.add(key);
        // Do not enqueue a new immediate poll on every WebView snapshot request.
        // The single fixed-rate scheduler below is the only owner of the Futures
        // polling cadence; this prevents duplicate queued requests after page
        // recreation and keeps LBank rate limits predictable.
        if (futuresFeedStarted.compareAndSet(false, true)) {
            try {
                if (!futuresBackgroundExecutor.isShutdown()) {
                    futuresBackgroundExecutor.scheduleAtFixedRate(this::pollPersistentFutures, 0, FUTURES_POLL_MS, TimeUnit.MILLISECONDS);
                }
            } catch (Exception ignored) {}
        }
    }

    private void pollPersistentFutures() {
        final long now = System.currentTimeMillis();
        for (String key : futuresFeedSymbols) {
            Long nextPoll = futuresGlobalNextPollAt.get(key);
            if (nextPoll != null && now < nextPoll) continue;
            futuresGlobalNextPollAt.put(key, now + FUTURES_POLL_MS);
            Long marketUntil = futuresMarketBackoffUntil.get(key);
            if (marketUntil == null || now >= marketUntil) {
                if (futuresMarketInFlight.add(key)) networkExecutor.execute(() -> {
                    try { JSONObject m=findFutureMarket(key); futuresMarketCache.put(key,m); futuresMarketFailureCount.remove(key); futuresMarketBackoffUntil.remove(key); addFutureSample(key,m); futuresLastTickAt=System.currentTimeMillis(); pushFuturesEvent(key,"market",m); }
                    catch(Exception e){ int n=futuresMarketFailureCount.merge(key,1,Integer::sum); long d=Math.min(30000L,1500L*(1L<<Math.min(5,Math.max(0,n-1)))); futuresMarketBackoffUntil.put(key,System.currentTimeMillis()+d); pushFuturesStatus(key,"market",String.valueOf(e.getMessage()),d); }
                    finally { futuresMarketInFlight.remove(key); }
                });
            }
            Long depthUntil = futuresDepthBackoffUntil.get(key);
            if (depthUntil == null || now >= depthUntil) {
                if (futuresDepthInFlight.add(key)) networkExecutor.execute(() -> {
                    try { JSONObject d=futuresDepthRequest(key,20); futuresDepthCache.put(key,d); futuresDepthAt.put(key,System.currentTimeMillis()); futuresDepthFailureCount.remove(key); futuresDepthBackoffUntil.remove(key); pushFuturesEvent(key,"depth",d); }
                    catch(Exception e){ int n=futuresDepthFailureCount.merge(key,1,Integer::sum); long dly=Math.min(30000L,1500L*(1L<<Math.min(5,Math.max(0,n-1)))); futuresDepthBackoffUntil.put(key,System.currentTimeMillis()+dly); pushFuturesStatus(key,"depth",String.valueOf(e.getMessage()),dly); }
                    finally { futuresDepthInFlight.remove(key); }
                });
            }
        }
    }

    // STAGE1161: initialize a non-exportable Android Keystore capability marker.
    // This is not a CPLS wallet key and does not create/import a seed phrase.
    private boolean ensureWalletKeystoreBoundary() {
        try {
            KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
            ks.load(null);
            if (ks.containsAlias(WALLET_KEY_ALIAS)) return true;
            KeyGenerator kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
            KeyGenParameterSpec spec = new KeyGenParameterSpec.Builder(WALLET_KEY_ALIAS,
                    KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setUserAuthenticationRequired(false)
                    .build();
            kg.init(spec);
            kg.generateKey();
            return true;
        } catch (Exception ignored) { return false; }
    }

    // Safe wallet state only; key bytes and seed material never leave native code.
    private JSONObject getWalletSecurityState() {
        JSONObject out = new JSONObject();
        try {
            out.put("walletBoundary", "ANDROID_KEYSTORE");
            out.put("keystoreReady", ensureWalletKeystoreBoundary());
            out.put("privateKeyExport", false);
            out.put("seedExport", false);
            out.put("webViewPrivateKeyAccess", false);
            out.put("network", WALLET_NETWORK);
            out.put("chainId", WALLET_CHAIN_ID);
            out.put("mainnetEnabled", false);
            out.put("signingEnabled", false);
            out.put("publicAddressAvailable", false);
            out.put("publicAddress", JSONObject.NULL);
            out.put("walletReadyForSigning", false);
        } catch (Exception ignored) {}
        return out;
    }

    // STAGE1162: capability boundary. The WebView may learn what the wallet can
    // safely expose, but it can never request seed/private-key bytes. A public
    // address is exposed only after a future native wallet implementation has
    // actually created/loaded a compatible key; this stage does not fabricate
    // an address or silently derive one from the boundary marker key.
    private JSONObject getWalletCapabilityState() {
        JSONObject out = new JSONObject();
        try {
            out.put("schemaVersion", "1");
            out.put("network", WALLET_NETWORK);
            out.put("chainId", WALLET_CHAIN_ID);
            out.put("readOnly", true);
            out.put("publicAddressAvailable", false);
            out.put("publicAddress", JSONObject.NULL);
            out.put("privateKeyExport", false);
            out.put("seedExport", false);
            out.put("webViewSigning", false);
            out.put("broadcast", false);
            out.put("reason", "WALLET_KEY_NOT_CREATED");
        } catch (Exception ignored) {}
        return out;
    }

    // STAGE1169: single source of truth for chain policy. No caller may opt into
    // Ethereum Mainnet or another network through a runtime parameter.
    private boolean isSepoliaOnlyChain(int chainId) {
        return !MAINNET_ENABLED && chainId == WALLET_CHAIN_ID && chainId != MAINNET_CHAIN_ID;
    }

    private JSONObject getMainnetLockState() {
        JSONObject out = new JSONObject();
        try {
            out.put("mainnetEnabled", MAINNET_ENABLED);
            out.put("mainnetChainId", MAINNET_CHAIN_ID);
            out.put("activeNetwork", WALLET_NETWORK);
            out.put("activeChainId", WALLET_CHAIN_ID);
            out.put("sepoliaOnly", isSepoliaOnlyChain(WALLET_CHAIN_ID));
            out.put("runtimeOverrideAllowed", false);
            out.put("status", MAINNET_ENABLED ? "UNLOCKED" : "LOCKED");
        } catch (Exception ignored) {}
        return out;
    }

    private boolean enforceSepoliaOnly(int requestedChainId) {
        return isSepoliaOnlyChain(requestedChainId);
    }

    // STAGE1163: read-only Sepolia network boundary. No signing, private-key access,
    // transaction broadcast, or mainnet fallback is permitted here.
    private JSONObject getSepoliaNetworkState() {
        JSONObject out = new JSONObject();
        try {
            out.put("network", WALLET_NETWORK);
            out.put("chainId", WALLET_CHAIN_ID);
            out.put("chainIdHex", "0xAA36A7");
            out.put("rpcConfigured", !SEPOLIA_RPC_URL.trim().isEmpty());
            out.put("readOnly", true);
            out.put("signing", false);
            out.put("broadcast", false);
            out.put("mainnetEnabled", false);
            out.put("rpcUrlExposedToWebView", false);
        } catch (Exception ignored) {}
        return out;
    }

    // STAGE1163: strict allow-list for the only RPC reads permitted by this layer.
    private boolean isAllowedSepoliaRpcMethod(String method) {
        return "eth_chainId".equals(method) || "net_version".equals(method);
    }

    private void fetchSepoliaChainState() {
        final String configured = SEPOLIA_RPC_URL.trim();
        if (configured.isEmpty()) {
            pushWalletNetworkEvent(getSepoliaNetworkState());
            return;
        }
        networkExecutor.execute(() -> {
            JSONObject out = getSepoliaNetworkState();
            try {
                JSONObject req = new JSONObject();
                req.put("jsonrpc", "2.0");
                req.put("id", 1);
                req.put("method", "eth_chainId");
                req.put("params", new org.json.JSONArray());
                HttpURLConnection c = (HttpURLConnection) new URL(configured).openConnection();
                c.setRequestMethod("POST"); c.setConnectTimeout(8000); c.setReadTimeout(8000);
                c.setDoOutput(true); c.setRequestProperty("Content-Type", "application/json");
                byte[] body = req.toString().getBytes("UTF-8");
                try (OutputStream os = c.getOutputStream()) { os.write(body); }
                StringBuilder b = new StringBuilder();
                try (BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream()))) {
                    String line; while ((line = r.readLine()) != null) b.append(line);
                }
                JSONObject resp = new JSONObject(b.toString());
                String chainHex = resp.optString("result", "");
                out.put("rpcReachable", true); out.put("rpcChainId", chainHex);
                out.put("chainMatch", "0xAA36A7".equalsIgnoreCase(chainHex));
            } catch (Exception e) {
                try { out.put("rpcReachable", false); out.put("error", e.getClass().getSimpleName()); } catch (Exception ignored) {}
            }
            pushWalletNetworkEvent(out);
        });
    }

    private void pushWalletNetworkEvent(JSONObject payload) {
        final String p = payload == null ? "{}" : payload.toString();
        if (web != null) web.post(() -> {
            if (web != null) web.evaluateJavascript("window.cpNativeSepoliaNetwork && window.cpNativeSepoliaNetwork(" + JSONObject.quote(p) + ");", null);
        });
    }

    // STAGE1164: contract metadata and read-only capability boundary.
    // The app may prepare standard ERC-20 read calls, but it never signs or
    // broadcasts transactions and never exposes a private/admin capability.
    private JSONObject getCplsContractState() {
        JSONObject out = new JSONObject();
        try {
            out.put("interfaceVersion", CPLS_CONTRACT_INTERFACE_VERSION);
            out.put("standard", "ERC-20");
            out.put("network", WALLET_NETWORK);
            out.put("chainId", WALLET_CHAIN_ID);
            out.put("contractConfigured", !CPLS_CONTRACT_ADDRESS.trim().isEmpty());
            out.put("contractAddress", CPLS_CONTRACT_ADDRESS.trim().isEmpty() ? JSONObject.NULL : CPLS_CONTRACT_ADDRESS);
            out.put("readOnly", true);
            out.put("balanceOf", true);
            out.put("decimals", true);
            out.put("name", true);
            out.put("symbol", true);
            out.put("transfer", false);
            out.put("approve", false);
            out.put("mint", false);
            out.put("burn", false);
            out.put("signing", false);
            out.put("broadcast", false);
            out.put("mainnetEnabled", false);
        } catch (Exception ignored) {}
        return out;
    }

    private boolean isValidEvmAddress(String address) {
        if (address == null) return false;
        return address.matches("^0x[0-9a-fA-F]{40}$");
    }

    // Returns a standard eth_call payload for a read-only ERC-20 method.
    // It does not execute the call here and never accepts arbitrary methods.
    private JSONObject buildCplsReadCall(String method, String address) {
        JSONObject out = new JSONObject();
        try {
            out.put("ok", false);
            if (!isValidEvmAddress(address) || CPLS_CONTRACT_ADDRESS.trim().isEmpty()) {
                out.put("error", "CONTRACT_NOT_CONFIGURED");
                return out;
            }
            String data = null;
            if ("decimals".equals(method)) data = CPLS_READ_DECIMALS_SELECTOR;
            else if ("name".equals(method)) data = CPLS_READ_NAME_SELECTOR;
            else if ("symbol".equals(method)) data = CPLS_READ_SYMBOL_SELECTOR;
            else if ("balanceOf".equals(method)) data = CPLS_READ_BALANCE_OF_SELECTOR + String.format(Locale.US, "%064x", new java.math.BigInteger(address.substring(2), 16));
            else { out.put("error", "METHOD_NOT_ALLOWED"); return out; }
            out.put("ok", true);
            out.put("chainId", WALLET_CHAIN_ID);
            out.put("to", CPLS_CONTRACT_ADDRESS);
            out.put("data", data);
            out.put("ethCall", true);
            out.put("readOnly", true);
        } catch (Exception e) {
            try { out.put("error", "INVALID_INPUT"); } catch (Exception ignored) {}
        }
        return out;
    }

    // STAGE1165: build a non-authoritative reward claim intent.
    // Amount/reward eligibility must come from a trusted backend.
    private JSONObject buildRewardClaimIntent(String accountRef, String walletAddress, String clientNonce, long expiresAt) {
        JSONObject out = new JSONObject();
        try {
            out.put("ok", false);
            out.put("protocolVersion", REWARD_CLAIM_PROTOCOL_VERSION);
            out.put("status", REWARD_CLAIM_STATUS);
            out.put("network", WALLET_NETWORK);
            out.put("chainId", WALLET_CHAIN_ID);
            out.put("authoritativeAmount", JSONObject.NULL);
            out.put("signature", JSONObject.NULL);
            if (accountRef == null || accountRef.trim().isEmpty()) { out.put("error", "ACCOUNT_REQUIRED"); return out; }
            if (!isValidEvmAddress(walletAddress)) { out.put("error", "INVALID_WALLET_ADDRESS"); return out; }
            if (clientNonce == null || clientNonce.trim().isEmpty() || clientNonce.length() > 128) { out.put("error", "INVALID_NONCE"); return out; }
            long now = System.currentTimeMillis();
            if (expiresAt <= now || expiresAt > now + REWARD_CLAIM_MAX_TTL_MS) { out.put("error", "INVALID_EXPIRY"); return out; }
            out.put("ok", true);
            out.put("accountRef", accountRef.trim());
            out.put("walletAddress", walletAddress);
            JSONObject replay = checkRewardClaimIdempotency(clientNonce);
            if (!replay.optBoolean("ok", false)) {
                out.put("error", replay.optString("error", "DUPLICATE_CLAIM_NONCE"));
                out.put("replayProtected", true);
                return out;
            }
            out.put("clientNonce", clientNonce.trim());
            out.put("idempotencyKey", clientNonce.trim());
            out.put("issuedAt", now);
            out.put("expiresAt", expiresAt);
            out.put("requiresBackendAuthorization", true);
            out.put("signingInClient", false);
            out.put("broadcastInClient", false);
        } catch (Exception e) {
            try { out.put("error", "INVALID_INPUT"); } catch (Exception ignored) {}
        }
        return out;
    }

    // STAGE1166: local duplicate-submit guard. This is not a security boundary;
    // the backend must persist nonce/claim identifiers and reject replays atomically.
    private JSONObject checkRewardClaimIdempotency(String clientNonce) {
        JSONObject out = new JSONObject();
        try {
            out.put("ok", false);
            if (clientNonce == null || clientNonce.trim().isEmpty() || clientNonce.length() > 128) {
                out.put("error", "INVALID_NONCE");
                return out;
            }
            final String key = clientNonce.trim();
            final long now = System.currentTimeMillis();
            Long seenAt = rewardClaimIdempotency.get(key);
            if (seenAt != null && now - seenAt < REWARD_CLAIM_IDEMPOTENCY_TTL_MS) {
                out.put("error", "DUPLICATE_CLAIM_NONCE");
                out.put("replayProtected", true);
                out.put("firstSeenAt", seenAt);
                return out;
            }
            rewardClaimIdempotency.put(key, now);
            out.put("ok", true);
            out.put("replayProtected", true);
            out.put("recordedAt", now);
            out.put("idempotencyTtlMs", REWARD_CLAIM_IDEMPOTENCY_TTL_MS);
        } catch (Exception e) {
            try { out.put("error", "INVALID_INPUT"); } catch (Exception ignored) {}
        }
        return out;
    }

    // STAGE1168: deterministic security policy self-test harness. These checks
    // validate client-side invariants only; they are not a substitute for backend
    // authorization, cryptographic attestation, or an external penetration test.
    private JSONObject runSecurityTestHarness() {
        JSONObject out = new JSONObject();
        int passed = 0;
        int failed = 0;
        try {
            JSONObject claim = buildRewardClaimIntent("test-account", "0x1111111111111111111111111111111111111111",
                    "harness-nonce-1", System.currentTimeMillis() + 60_000L);
            boolean claimPolicy = claim.optBoolean("ok", false)
                    && claim.optInt("chainId", 0) == WALLET_CHAIN_ID
                    && claim.optBoolean("requiresBackendAuthorization", false)
                    && !claim.optBoolean("signingInClient", true)
                    && !claim.optBoolean("broadcastInClient", true)
                    && claim.optString("authoritativeAmount", "x").equals("null");
            if (claimPolicy) passed++; else failed++;

            JSONObject duplicate = checkRewardClaimIdempotency("harness-duplicate");
            JSONObject duplicateAgain = checkRewardClaimIdempotency("harness-duplicate");
            boolean replayPolicy = duplicate.optBoolean("ok", false)
                    && !duplicateAgain.optBoolean("ok", true)
                    && "DUPLICATE_CLAIM_NONCE".equals(duplicateAgain.optString("error"));
            if (replayPolicy) passed++; else failed++;

            boolean addressPolicy = isValidEvmAddress("0x1111111111111111111111111111111111111111")
                    && !isValidEvmAddress("0x1234");
            if (addressPolicy) passed++; else failed++;

            JSONObject contractState = getCplsContractState();
            boolean contractPolicy = contractState.optInt("chainId", 0) == WALLET_CHAIN_ID
                    && contractState.optBoolean("readOnly", false)
                    && !contractState.optBoolean("transfer", true)
                    && !contractState.optBoolean("approve", true)
                    && !contractState.optBoolean("mint", true)
                    && !contractState.optBoolean("burn", true)
                    && !contractState.optBoolean("signing", true)
                    && !contractState.optBoolean("broadcast", true);
            if (contractPolicy) passed++; else failed++;

            out.put("schemaVersion", "1");
            out.put("stage", 1168);
            out.put("status", failed == 0 ? "PASS" : "FAIL");
            out.put("passed", passed);
            out.put("failed", failed);
            out.put("backendRequired", true);
            out.put("network", WALLET_NETWORK);
            out.put("chainId", WALLET_CHAIN_ID);
            out.put("mainnetEnabled", false);
            out.put("cryptographicAttestationVerified", false);
            out.put("note", "Client self-tests validate policy invariants only; backend and external security testing remain authoritative.");
        } catch (Exception e) {
            try {
                out.put("schemaVersion", "1");
                out.put("stage", 1168);
                out.put("status", "ERROR");
                out.put("passed", passed);
                out.put("failed", failed + 1);
                out.put("error", "HARNESS_EXCEPTION");
            } catch (Exception ignored) {}
        }
        return out;
    }

    // STAGE1167: collect non-secret local integrity signals for backend telemetry.
    // The values are advisory and must not authorize rewards by themselves.
    private JSONObject getAppIntegrityBoundaryState() {
        JSONObject out = new JSONObject();
        try {
            out.put("schemaVersion", INTEGRITY_BOUNDARY_VERSION);
            out.put("packageName", getPackageName());
            boolean debuggable = (getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0;
            out.put("debuggable", debuggable);
            out.put("playIntegrityIntegrated", false);
            out.put("attestationVerified", false);
            out.put("serverAuthoritative", false);
            out.put("rewardAuthorizationAllowed", false);
            try {
                PackageInfo pi;
                if (Build.VERSION.SDK_INT >= 28) {
                    pi = getPackageManager().getPackageInfo(getPackageName(), android.content.pm.PackageManager.GET_SIGNING_CERTIFICATES);
                    if (pi.signingInfo != null) {
                        Signature[] sigs = pi.signingInfo.hasPastSigningCertificates()
                                ? pi.signingInfo.getApkContentsSigners() : pi.signingInfo.getApkContentsSigners();
                        out.put("signerDigestSha256", digestSignatures(sigs));
                    }
                } else {
                    pi = getPackageManager().getPackageInfo(getPackageName(), android.content.pm.PackageManager.GET_SIGNATURES);
                    out.put("signerDigestSha256", digestSignatures(pi.signatures));
                }
                out.put("versionName", pi.versionName == null ? "" : pi.versionName);
                out.put("versionCode", Build.VERSION.SDK_INT >= 28 ? pi.getLongVersionCode() : pi.versionCode);
            } catch (Exception ignored) {
                out.put("signerDigestSha256", JSONObject.NULL);
            }
            out.put("network", WALLET_NETWORK);
            out.put("chainId", WALLET_CHAIN_ID);
            out.put("note", "LOCAL_SIGNALS_ONLY_BACKEND_ATTESTATION_REQUIRED");
        } catch (Exception e) {
            try { out.put("error", "INTEGRITY_SIGNAL_UNAVAILABLE"); } catch (Exception ignored) {}
        }
        return out;
    }

    private String digestSignatures(Signature[] signatures) {
        try {
            if (signatures == null || signatures.length == 0) return "";
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            return bytesToHex(md.digest(signatures[0].toByteArray()));
        } catch (Exception e) { return ""; }
    }

    private String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder(bytes.length * 2);
        for (byte b : bytes) sb.append(String.format(Locale.US, "%02x", b));
        return sb.toString();
    }

    // STAGE1157: stable feed envelope for a future API gateway/backend.
    private JSONObject buildFeedEnvelope(String symbol, JSONObject market, JSONObject depth) {
        JSONObject out = new JSONObject();
        try {
            out.put("schemaVersion", FEED_SCHEMA_VERSION);
            out.put("requestId", feedRequestSeq.incrementAndGet());
            out.put("source", "lbank-contract");
            out.put("mode", FEED_API_MODE);
            out.put("symbol", normalizeFutureFeedSymbol(symbol) + "USDT");
            out.put("serverTime", System.currentTimeMillis());
            out.put("market", market == null ? JSONObject.NULL : market);
            out.put("depth", depth == null ? JSONObject.NULL : depth);
        } catch (Exception ignored) {}
        return out;
    }

    // STAGE1158: cheap local abuse telemetry. This is deliberately NOT the source
    // of truth for rewards; it only prevents accidental request storms in the app.
    private boolean allowRewardAction(String actionKey) {
        final String key = actionKey == null ? "unknown" : actionKey;
        final long now = System.currentTimeMillis();
        Long started = rewardActionWindow.get(key);
        if (started == null || now - started >= REWARD_ACTION_WINDOW_MS) {
            rewardActionWindow.put(key, now);
            rewardActionCount.put(key, 1);
            return true;
        }
        int n = rewardActionCount.merge(key, 1, Integer::sum);
        return n <= REWARD_ACTION_LIMIT;
    }

    // STAGE1159/1160: expose a safe diagnostic payload; no private key, seed,
    // signing secret, or authoritative reward balance is ever returned here.
    private JSONObject getSecurityTelemetry() {
        JSONObject out = new JSONObject();
        try {
            out.put("clientRewardGuard", "rate-limit-only");
            out.put("backendRequiredForRewardAuthorization", true);
            out.put("privateKeyInBackend", false);
            out.put("mainnetEnabled", false);
            out.put("testnetTarget", "Ethereum Sepolia");
            out.put("chainId", 11155111);
            out.put("schemaVersion", FEED_SCHEMA_VERSION);
        } catch (Exception ignored) {}
        return out;
    }

    private void pushFuturesStatus(String key,String channel,String error,long retryMs){ try { JSONObject st=new JSONObject(); st.put("ok",false); st.put("channel",channel); st.put("error",error==null?"unknown":error); st.put("retryMs",retryMs); st.put("updatedAt",System.currentTimeMillis()); pushFuturesEvent(key,"status",st); } catch(Exception ignored){} }

    private String getPersistentFuturesSnapshot(String symbol) {
        String key = normalizeFutureFeedSymbol(symbol);
        JSONObject out = new JSONObject();
        try {
            JSONObject m = futuresMarketCache.get(key);
            JSONObject d = futuresDepthCache.get(key);
            out.put("symbol", key+"USDT");
            out.put("market", m == null ? JSONObject.NULL : m);
            out.put("depth", d == null ? JSONObject.NULL : d);
            org.json.JSONArray samples = new org.json.JSONArray();
            java.util.List<JSONObject> list = futuresSamplesCache.get(key);
            if (list != null) synchronized(list) { int start=Math.max(0,list.size()-1200); for(int i=start;i<list.size();i++) samples.put(list.get(i)); }
            out.put("samples", samples);
            out.put("updatedAt", futuresLastTickAt);
            out.put("feedSource", "lbank-contract");
            out.put("feedMode", FEED_API_MODE);
            out.put("schemaVersion", FEED_SCHEMA_VERSION);
            out.put("requestId", feedRequestSeq.incrementAndGet());
            out.put("candleSource", "sampled");
            out.put("candleExact", false);
            out.put("pollIntervalMs", FUTURES_POLL_MS);
            out.put("error", futuresErrorCache.containsKey(key) ? futuresErrorCache.get(key) : JSONObject.NULL);
        } catch (Exception ignored) {}
        return out.toString();
    }

    private void pushFuturesEvent(String symbol, String type, JSONObject data) {
        if (web == null || data == null) return;
        final String key = normalizeFutureFeedSymbol(symbol);
        final String payload = data.toString();
        try {
            web.post(() -> {
                if (web == null) return;
                String js = "window.cpNativeFuturesEvent&&window.cpNativeFuturesEvent(" + JSONObject.quote(key) + "," + JSONObject.quote(type) + "," + JSONObject.quote(payload) + ");";
                web.evaluateJavascript(js, null);
            });
        } catch (Exception ignored) {}
    }

    private void pushAllHotFuturesSnapshots() {
        if (web == null) return;
        for (String key : futuresFeedSymbols) {
            JSONObject m=futuresMarketCache.get(key); if(m!=null) pushFuturesEvent(key,"market",m);
            JSONObject d=futuresDepthCache.get(key); if(d!=null) pushFuturesEvent(key,"depth",d);
        }
    }

    public class MarketBridge {
        @JavascriptInterface
        public String getMarketSnapshot() { return getNativeMarketCachePayload(); }

        /** Returns one of the bundled local HTML pages without navigating the WebView.
         * This keeps the single WebView/JS context alive so the LBank WebSocket and
         * shared market cache survive Home <-> Markets navigation. */
        @JavascriptInterface
        public String getLocalPage(String name) {
            try {
                if (name == null || !name.matches("[A-Za-z0-9_-]+\\.html")) return "";
                java.io.InputStream in = getAssets().open("web/" + name);
                java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
                byte[] buf = new byte[8192]; int n;
                while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
                in.close();
                return out.toString("UTF-8");
            } catch (Exception e) { return ""; }
        }

        @JavascriptInterface
        public void fetchMarketUniverse() {
            fetchNativeMarketUniverse();
        }

        @JavascriptInterface
        public void startLBankSocket() { startNativeLbankSocket(); }

        @JavascriptInterface
        public void startFuturesFeed(String symbol) { startPersistentFuturesFeed(symbol); }

        @JavascriptInterface
        public String getFuturesSnapshot(String symbol) { startPersistentFuturesFeed(symbol); return getPersistentFuturesSnapshot(symbol); }

        /** Native immersive mode for the chart pseudo-fullscreen.
         * HTML fullscreen is not reliably supported by Android WebView wrappers,
         * so the chart asks the Activity to hide system bars directly.
         */
        @JavascriptInterface
        public void enterChartFullscreen() {
            runOnUiThread(() -> {
                try {
                    Window w = getWindow();
                    if (Build.VERSION.SDK_INT >= 30) {
                        WindowInsetsController c = w.getInsetsController();
                        if (c != null) {
                            c.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                            c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                        }
                        w.setDecorFitsSystemWindows(false);
                    } else {
                        int flags = View.SYSTEM_UI_FLAG_FULLSCREEN
                                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE;
                        w.getDecorView().setSystemUiVisibility(flags);
                    }
                } catch (Exception ignored) {}
            });
        }

        @JavascriptInterface
        public void exitChartFullscreen() {
            runOnUiThread(() -> {
                try {
                    Window w = getWindow();
                    if (Build.VERSION.SDK_INT >= 30) {
                        WindowInsetsController c = w.getInsetsController();
                        if (c != null) c.show(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                        w.setDecorFitsSystemWindows(true);
                        w.getDecorView().setSystemUiVisibility(0);
                    } else {
                        w.getDecorView().setSystemUiVisibility(0);
                    }
                } catch (Exception ignored) {}
            });
        }

        @JavascriptInterface
        public String getLBankSocketDiagnostic() { return getNativeSocketDiagnostic(); }

        @JavascriptInterface
        public String getLiveDiagnostic() {
            try {
                JSONObject o = new JSONObject();
                o.put("lastUrl", diagLastUrl);
                o.put("lastHttp", diagLastHttp);
                o.put("lastError", diagLastError);
                o.put("successCount", diagSuccessCount);
                o.put("errorCount", diagErrorCount);
                o.put("cacheCount", nativeMarketCache.size());
                o.put("klineState", diagKlineState);
                o.put("klineSymbol", diagKlineSymbol);
                o.put("klineInterval", diagKlineInterval);
                o.put("klineAttempts", diagKlineAttempts);
                o.put("klineRows", diagKlineRows);
                o.put("klineResponse", diagKlineResponse);
                return o.toString();
            } catch (Exception e) { return "{}"; }
        }

        @JavascriptInterface
        public void testLBankBTC() {
            networkExecutor.execute(() -> {
                final String[] bases = {"https://api.lbkex.com", "https://api.lbank.info", "https://www.lbkex.net"};
                String[] paths = {"/v2/ticker/24hr.do?symbol=btc_usdt", "/v2/supplement/ticker/price.do?symbol=btc_usdt"};
                String result = null;
                for (String base : bases) {
                    for (String path : paths) {
                        String u = base + path;
                        try {
                            result = httpGet(u);
                            JSONObject q = new JSONObject(result);
                            JSONObject t = firstTickerObject(q);
                            double price = tickerNumber(t, "latest","lastPrice","last","price","close","closePrice");
                            if (Double.isNaN(price) && q.has("data")) price = tickerNumber(q.optJSONObject("data"), "price","latest","lastPrice","last","close");
                            if (!Double.isNaN(price) && price > 0) {
                                diagLastUrl = u; diagLastHttp = "200 OK / BTC=" + price; diagLastError = ""; diagSuccessCount++;
                                JSONObject row = new JSONObject(); row.put("symbol","BTC"); row.put("price",price); row.put("change",0); row.put("volume",0); row.put("lastUpdate",System.currentTimeMillis()); row.put("provider","LBank Diagnostic"); nativeMarketCache.put("BTC",row.toString());
                                pushNativeCacheToWeb();
                                return;
                            }
                            diagLastUrl = u; diagLastHttp = "200 but no price";
                        } catch (Exception e) {
                            diagLastUrl = u; diagLastError = String.valueOf(e.getMessage()); diagErrorCount++;
                        }
                    }
                }
                if (web != null) web.post(() -> pushNativeCacheToWeb());
            });
        }

        // REBUILD42: dedicated native OkHttp WebSocket history path. This bypasses
        // WebView WebSocket/TLS quirks and the unreliable JS-interface lookup.
        private void fetchLBankKlinesViaNativeWebSocket(String symbol, String interval, int limit) {
            fetchLBankKlinesViaNativeWebSocket(symbol, interval, limit, "");
        }

        private void fetchLBankKlinesViaNativeWebSocket(String symbol, String interval, int limit, String requestId) {
            final String sym = symbol == null ? "btc" : symbol.trim().toLowerCase(Locale.US);
            final String pair = sym.endsWith("_usdt") ? sym : sym + "_usdt";
            final String slot; final long stepSec;
            if ("5m".equals(interval)) { slot="5min"; stepSec=300L; }
            else if ("15m".equals(interval)) { slot="15min"; stepSec=900L; }
            else if ("1h".equals(interval)) { slot="1hr"; stepSec=3600L; }
            else if ("4h".equals(interval)) { slot="4hr"; stepSec=14400L; }
            else if ("1d".equals(interval)) { slot="day"; stepSec=86400L; }
            else if ("1w".equals(interval)) { slot="week"; stepSec=604800L; }
            else { slot="1min"; stepSec=60L; }
            final int size=Math.max(20,Math.min(240,limit<=0?240:limit));
            final long nowSec=System.currentTimeMillis()/1000L;
            final java.util.Map<Long,org.json.JSONArray> rows=new java.util.TreeMap<>();
            final java.util.concurrent.atomic.AtomicBoolean done=new java.util.concurrent.atomic.AtomicBoolean(false);
            final java.util.concurrent.atomic.AtomicInteger retries=new java.util.concurrent.atomic.AtomicInteger(0);
            final WebSocket[] socket=new WebSocket[1];
            try{if(web!=null)web.post(()->web.evaluateJavascript("window.cpNativeAutoStatus&&window.cpNativeAutoStatus('RUNNING');",null));}catch(Exception ignored){}
            final Runnable[] launch=new Runnable[1];
            launch[0]=()->{
                if(done.get())return;
                Request req=new Request.Builder().url("wss://api.lbank.info/ws/V2/").header("User-Agent","CryptoPulse/Android-KLineWS").build();
                try{
                    socket[0]=lbankWsClient.newWebSocket(req,new WebSocketListener(){
                        final java.util.concurrent.atomic.AtomicBoolean opened=new java.util.concurrent.atomic.AtomicBoolean(false);
                        final java.util.concurrent.ScheduledFuture<?>[] timer=new java.util.concurrent.ScheduledFuture<?>[1];
                        private void fail(){if(done.get())return;try{if(socket[0]!=null)socket[0].close(1000,"kline-retry");}catch(Exception ignored){};if(retries.incrementAndGet()>=3){done.set(true);try{if(web!=null)web.post(()->web.evaluateJavascript("window.cpNativeAutoStatus&&window.cpNativeAutoStatus(\'JAVA_ERROR\');",null));}catch(Exception ignored){}}else{lbankWsScheduler.schedule(()->{if(!done.get())launch[0].run();},250L,TimeUnit.MILLISECONDS);}}
                        private void finish(){if(!done.compareAndSet(false,true))return;if(timer[0]!=null)timer[0].cancel(false);try{if(socket[0]!=null)socket[0].close(1000,"kline-done");}catch(Exception ignored){};org.json.JSONArray out=new org.json.JSONArray();for(org.json.JSONArray r:rows.values())out.put(r);final String raw=out.toString();
                                                        final String payload=JSONObject.quote(raw);
                                                        final int count=rows.size();
                                                        try{
                                                            if(web!=null)web.post(()->{
                                                                try{
                                                                    web.evaluateJavascript("window.cpNativeAutoKlines&&window.cpNativeAutoKlines("+payload+");",null);
                                                                    if(requestId!=null&&!requestId.isEmpty()){
                                                                        String ridJs=JSONObject.quote(requestId);
                                                                        web.evaluateJavascript("window.cpNativeKlines&&window.cpNativeKlines("+ridJs+","+payload+");",null);
                                                                    }
                                                                }catch(Exception ignored){}
                                                            });
                                                        }catch(Exception ignored){}
                                                        try{if(web!=null)web.post(()->web.evaluateJavascript("window.cpNativeAutoStatus&&window.cpNativeAutoStatus('RECEIVED');",null));}catch(Exception ignored){}
                                                        try{if(web!=null)web.post(()->web.evaluateJavascript("window.__cpChartDiag&&(window.__cpChartDiag.nativeRows="+count+",window.__cpChartDiag.nativeWsRows="+count+");",null));}catch(Exception ignored){} }
                        @Override public void onOpen(WebSocket ws,Response response){opened.set(true);try{JSONObject q=new JSONObject();q.put("action","request");q.put("request","kbar");q.put("kbar",slot);q.put("pair",pair);q.put("start",String.valueOf(nowSec-stepSec*(long)size));q.put("end",String.valueOf(nowSec));q.put("size",String.valueOf(size));ws.send(q.toString());timer[0]=lbankWsScheduler.schedule(()->{if(rows.size()>=10)finish();else fail();},9000L,TimeUnit.MILLISECONDS);}catch(Exception e){fail();}}
                        @Override public void onMessage(WebSocket ws,String text){if(done.get()||text==null)return;try{JSONObject m=new JSONObject(text);if(m.has("ping")||"ping".equalsIgnoreCase(m.optString("action",""))){JSONObject p=new JSONObject();p.put("action","pong");p.put("pong",m.optString("ping",String.valueOf(System.currentTimeMillis())));ws.send(p.toString());return;}collectNativeKlineRows(m,rows);if(rows.size()>=10)finish();}catch(Exception ignored){}}
                        @Override public void onFailure(WebSocket ws,Throwable t,Response response){fail();}
                        @Override public void onClosed(WebSocket ws,int code,String reason){if(!done.get()&&rows.size()>=10)finish();else if(!done.get()&&!opened.get())fail();}
                    });
                }catch(Exception e){lbankWsScheduler.schedule(()->{if(!done.get())launch[0].run();},250L,TimeUnit.MILLISECONDS);}
            };
            launch[0].run();
        }

        private void collectNativeKlineRows(JSONObject m,java.util.Map<Long,org.json.JSONArray> out){
            if(m==null||out==null)return;
            collectNativeKlineNode(m,out);
        }
        private void collectNativeKlineNode(Object n,java.util.Map<Long,org.json.JSONArray> out){
            if(n==null||n==JSONObject.NULL)return;
            if(n instanceof String){
                String text=((String)n).trim();
                if(text.isEmpty())return;
                try{Object parsed=new org.json.JSONTokener(text).nextValue();collectNativeKlineNode(parsed,out);}catch(Exception ignored){}
                return;
            }
            if(n instanceof JSONObject){
                JSONObject o=(JSONObject)n;
                if(o.has("o")||o.has("open")||o.has("c")||o.has("close"))addNativeKlineObject(o,out);
                java.util.Iterator<String>it=o.keys();
                while(it.hasNext())collectNativeKlineNode(o.opt(it.next()),out);
            } else if(n instanceof org.json.JSONArray){
                org.json.JSONArray a=(org.json.JSONArray)n;
                if(a.length()>=5 && !(a.opt(0) instanceof org.json.JSONArray) && !(a.opt(0) instanceof JSONObject)){
                    addNativeKlineArray(a,out);
                } else {
                    for(int i=0;i<a.length();i++)collectNativeKlineNode(a.opt(i),out);
                }
            }
        }
        private void addNativeKlineObject(JSONObject k,java.util.Map<Long,org.json.JSONArray> out){try{double o=firstNumber(k,"o","open"),h=firstNumber(k,"h","high"),l=firstNumber(k,"l","low"),c=firstNumber(k,"c","close"),v=firstNumber(k,"v","volume");if(!(o>0&&h>0&&l>0&&c>0))return;String raw=String.valueOf(k.opt("t"));long ts;try{ts=Long.parseLong(raw);}catch(Exception e){ts=Date.parse(raw);}if(ts<100000000000L)ts*=1000L;org.json.JSONArray r=new org.json.JSONArray();r.put(ts);r.put(o);r.put(h);r.put(l);r.put(c);r.put(Double.isNaN(v)?0:v);out.put(ts,r);}catch(Exception ignored){}}
        private void addNativeKlineArray(org.json.JSONArray a,java.util.Map<Long,org.json.JSONArray> out){try{long ts=a.optLong(0,0L);if(ts<100000000000L)ts*=1000L;double o=a.optDouble(1,Double.NaN),h=a.optDouble(2,Double.NaN),l=a.optDouble(3,Double.NaN),c=a.optDouble(4,Double.NaN),v=a.optDouble(5,0);if(!(ts>0&&o>0&&h>0&&l>0&&c>0))return;org.json.JSONArray r=new org.json.JSONArray();r.put(ts);r.put(o);r.put(h);r.put(l);r.put(c);r.put(v);out.put(ts,r);}catch(Exception ignored){}}

        // Stage 1178: Native Ourbit market bridge. WebView fetch() can be blocked by CORS,
        // so all public Ourbit market-data requests used by the Android app run natively.
        private void pushOurbitCallback(String fn, String requestId, String payload) {
            if (web == null) return;
            final String rid = requestId == null ? "" : requestId.replace("\\", "\\\\").replace("'", "\\'");
            final String arg = payload == null ? "" : JSONObject.quote(payload);
            web.post(() -> { try { if (web != null) { String js = "window." + fn + "&&window." + fn + "('" + rid + "'," + arg + ");"; web.evaluateJavascript(js, null); } } catch (Exception ignored) {} });
        }

        // Stage 1180: deterministic Ourbit root-cause diagnostics. This does not
        // fabricate data and does not require an API key. It tests the exact native
        // HTTP path used by Home/Trade/Futures and returns status, body size, a short
        // response sample and parsed row counts to the WebView.
        private JSONObject diagnosticHttp(String url) {
            JSONObject o = new JSONObject();
            HttpURLConnection c = null;
            long started = System.currentTimeMillis();
            try {
                c = (HttpURLConnection) new URL(url).openConnection();
                c.setRequestMethod("GET");
                c.setConnectTimeout(5000);
                c.setReadTimeout(7000);
                c.setUseCaches(false);
                c.setRequestProperty("Accept", "application/json");
                c.setRequestProperty("User-Agent", "CryptoPulse/Android-Diagnostic");
                c.setRequestProperty("Accept-Encoding", "identity");
                int code = c.getResponseCode();
                InputStream in = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
                StringBuilder body = new StringBuilder();
                if (in != null) {
                    try (BufferedReader br = new BufferedReader(new InputStreamReader(in, "UTF-8"))) {
                        String line;
                        while ((line = br.readLine()) != null && body.length() < 200000) body.append(line);
                    }
                }
                String raw = body.toString();
                String snippet = raw.replace("\\", "\\\\").replace("\r", " ").replace("\n", " ");
                if (snippet.length() > 420) snippet = snippet.substring(0, 420) + "…";
                o.put("ok", code >= 200 && code < 300);
                o.put("status", code);
                o.put("length", raw.length());
                o.put("ms", System.currentTimeMillis() - started);
                o.put("snippet", snippet);
                o.put("error", code >= 200 && code < 300 ? "" : "HTTP " + code);
                if (code >= 200 && code < 300) {
                    try {
                        Object root = raw.trim().startsWith("[") ? new org.json.JSONArray(raw) : new JSONObject(raw);
                        int arrays = 0;
                        int objects = 0;
                        if (root instanceof org.json.JSONArray) { arrays = ((org.json.JSONArray)root).length(); }
                        else if (root instanceof JSONObject) {
                            JSONObject jo=(JSONObject)root;
                            Object d=jo.opt("data");
                            if (d instanceof org.json.JSONArray) arrays=((org.json.JSONArray)d).length();
                            else if (d instanceof JSONObject) objects=((JSONObject)d).length();
                        }
                        o.put("arrayCount", arrays);
                        o.put("objectCount", objects);
                    } catch (Exception parse) { o.put("parseError", parse.toString()); }
                }
            } catch (Exception e) {
                try {
                    o.put("ok", false); o.put("status", 0); o.put("length", 0);
                    o.put("ms", System.currentTimeMillis() - started);
                    o.put("snippet", ""); o.put("error", e.getClass().getSimpleName() + ": " + String.valueOf(e.getMessage()));
                } catch (Exception ignored) {}
            } finally { if (c != null) c.disconnect(); }
            try { o.put("url", url); } catch (Exception ignored) {}
            return o;
        }

        private JSONObject diagnosticParsed(String name, JSONObject raw) {
            JSONObject o = raw == null ? new JSONObject() : raw;
            try { o.put("name", name); } catch (Exception ignored) {}
            return o;
        }

        @JavascriptInterface
        public String ourbitDiagnosticProbe() {
            return "Android Bridge OK / Stage 1184";
        }

        @JavascriptInterface
        public void runOurbitDiagnostics(String requestId) {
            final String rid = requestId == null ? "" : requestId;
            networkExecutor.execute(() -> {
                JSONObject out = new JSONObject();
                try {
                    out.put("stage", "1185");
                    out.put("timestamp", System.currentTimeMillis());
                    out.put("bridge", true);
                    org.json.JSONArray tests = new org.json.JSONArray();
                    // Keep this diagnostic bounded: the old sequential 7-call version could exceed
                    // the WebView's 25s promise timeout even when the bridge itself was healthy.
                    String[][] reqs = new String[][] {
                        {"SPOT PING", "https://api.ourbit.com/api/v3/ping"},
                        {"SPOT TICKER BTCUSDT", "https://api.ourbit.com/api/v3/ticker/24hr?symbol=BTCUSDT"},
                        {"SPOT KLINE BTCUSDT", "https://api.ourbit.com/api/v3/klines?symbol=BTCUSDT&interval=1m&limit=20"},
                        {"SPOT DEPTH BTCUSDT", "https://api.ourbit.com/api/v3/depth?symbol=BTCUSDT&limit=20"},
                        {"FUTURES TICKER BTC_USDT", "https://contract.ourbit.com/api/v1/contract/ticker?symbol=BTC_USDT"},
                        {"FUTURES DEPTH BTC_USDT", "https://contract.ourbit.com/api/v1/contract/depth_commits/BTC_USDT/20"},
                        {"FUTURES KLINE BTC_USDT", "https://contract.ourbit.com/api/v1/contract/kline/BTC_USDT?interval=Min1&start="+(System.currentTimeMillis()-20L*60000L)+"&end="+System.currentTimeMillis()}
                    };
                    java.util.concurrent.ExecutorService pool = java.util.concurrent.Executors.newFixedThreadPool(7);
                    java.util.concurrent.Future<?>[] jobs = new java.util.concurrent.Future<?>[reqs.length];
                    JSONObject[] results = new JSONObject[reqs.length];
                    for (int i=0;i<reqs.length;i++) {
                        final int idx=i;
                        jobs[i]=pool.submit(() -> results[idx]=diagnosticParsed(reqs[idx][0], diagnosticHttp(reqs[idx][1])));
                    }
                    for (int i=0;i<jobs.length;i++) {
                        try { jobs[i].get(13, java.util.concurrent.TimeUnit.SECONDS); }
                        catch (Exception e) { JSONObject x=new JSONObject(); x.put("name",reqs[i][0]); x.put("ok",false); x.put("status",0); x.put("length",0); x.put("ms",0); x.put("snippet",""); x.put("error","Diagnostic timeout/error: "+e.getClass().getSimpleName()); results[i]=x; }
                    }
                    pool.shutdownNow();
                    for (JSONObject r: results) tests.put(r==null?new JSONObject():r);
                    out.put("tests", tests);
                    out.put("summary", "Stage 1182: bounded parallel Native HTTP diagnostics; no synthetic market data used.");
                } catch (Exception e) {
                    try { out.put("error", e.toString()); } catch (Exception ignored) {}
                }
                pushOurbitCallback("cpNativeOurbitDiagnostics", rid, out.toString());
                try { final String pld=out.toString(); final String rr=rid.replace("\\","\\\\").replace("'","\\'"); web.post(() -> { try { if(web!=null) web.evaluateJavascript("window.__cpDiag1183&&window.__cpDiag1183['"+rr+"']&&window.__cpDiag1183['"+rr+"']("+JSONObject.quote(pld)+");",null); } catch(Exception ignored){} }); } catch(Exception ignored) {}
            });
        }

        @JavascriptInterface
        public void fetchOurbitSpotKlines(String symbol, String interval, int limit, String requestId) {
            final String sym = symbol == null ? "BTC" : symbol.trim().toUpperCase(Locale.US).replaceAll("[^A-Z0-9]", "");
            final String tf = interval == null ? "1m" : interval.trim();
            if ("1h".equals(tf)) tf="60m"; else if ("1w".equals(tf)) tf="1W";
            final int size = Math.max(20, Math.min(1000, limit <= 0 ? 240 : limit));
            networkExecutor.execute(() -> {
                String payload = "";
                try { payload = httpGet("https://api.ourbit.com/api/v3/klines?symbol=" + URLEncoder.encode(sym + "USDT", "UTF-8") + "&interval=" + URLEncoder.encode(tf, "UTF-8") + "&limit=" + size); } catch (Exception ignored) {}
                pushOurbitCallback("cpNativeOurbitKlines", requestId, payload);
            });
        }

        @JavascriptInterface
        public void fetchOurbitSpotTicker(String symbol, String requestId) {
            final String sym = symbol == null ? "BTC" : symbol.trim().toUpperCase(Locale.US).replaceAll("[^A-Z0-9]", "");
            networkExecutor.execute(() -> {
                String payload = "";
                try { payload = httpGet("https://api.ourbit.com/api/v3/ticker/24hr?symbol=" + URLEncoder.encode(sym + "USDT", "UTF-8")); } catch (Exception ignored) {}
                pushOurbitCallback("cpNativeOurbitTicker", requestId, payload);
            });
        }

        @JavascriptInterface
        public void fetchOurbitSpotDepth(String symbol, int limit, String requestId) {
            final String sym = symbol == null ? "BTC" : symbol.trim().toUpperCase(Locale.US).replaceAll("[^A-Z0-9]", "");
            final int size = Math.max(5, Math.min(100, limit <= 0 ? 20 : limit));
            networkExecutor.execute(() -> {
                String payload = "";
                try { payload = httpGet("https://api.ourbit.com/api/v3/depth?symbol=" + URLEncoder.encode(sym + "USDT", "UTF-8") + "&limit=" + size); } catch (Exception ignored) {}
                pushOurbitCallback("cpNativeOurbitDepth", requestId, payload);
            });
        }

        @JavascriptInterface
        public void fetchOurbitSpotTickers(String requestId) {
            networkExecutor.execute(() -> {
                String payload = "";
                try { payload = httpGet("https://api.ourbit.com/api/v3/ticker/24hr"); } catch (Exception ignored) {}
                pushOurbitCallback("cpNativeOurbitTickers", requestId, payload);
            });
        }

        @JavascriptInterface
        public void fetchOurbitFuturesTicker(String symbol, String requestId) {
            final String pair = (symbol == null ? "BTC" : symbol.trim().toUpperCase(Locale.US).replaceAll("[^A-Z0-9]", "").replaceAll("USDT$", "")) + "_USDT";
            networkExecutor.execute(() -> {
                String payload = "";
                try { payload = httpGet("https://contract.ourbit.com/api/v1/contract/ticker?symbol=" + URLEncoder.encode(pair, "UTF-8")); } catch (Exception ignored) {}
                pushOurbitCallback("cpNativeOurbitFuturesTicker", requestId, payload);
            });
        }

        @JavascriptInterface
        public void fetchOurbitFuturesDepth(String symbol, int limit, String requestId) {
            final String pair = (symbol == null ? "BTC" : symbol.trim().toUpperCase(Locale.US).replaceAll("[^A-Z0-9]", "").replaceAll("USDT$", "")) + "_USDT";
            final int size = Math.max(5, Math.min(100, limit <= 0 ? 20 : limit));
            networkExecutor.execute(() -> {
                String payload = "";
                try { payload = httpGet("https://contract.ourbit.com/api/v1/contract/depth_commits/" + URLEncoder.encode(pair, "UTF-8") + "/" + size); } catch (Exception ignored) {}
                pushOurbitCallback("cpNativeOurbitFuturesDepth", requestId, payload);
            });
        }

        @JavascriptInterface
        public void fetchOurbitFuturesKlines(String symbol, String interval, int limit, String requestId) {
            final String pair = (symbol == null ? "BTC" : symbol.trim().toUpperCase(Locale.US).replaceAll("[^A-Z0-9]", "").replaceAll("USDT$", "")) + "_USDT";
            final String tf = interval == null ? "Min1" : interval.trim();
            final int size = Math.max(20, Math.min(1000, limit <= 0 ? 240 : limit));
            networkExecutor.execute(() -> {
                String payload = "";
                try {
                    long end = System.currentTimeMillis(), step = "Min5".equals(tf) ? 300000L : "Min15".equals(tf) ? 900000L : "Min30".equals(tf) ? 1800000L : "Min60".equals(tf) ? 3600000L : "Hour4".equals(tf) ? 14400000L : "Day1".equals(tf) ? 86400000L : 60000L;
                    long start = end - step * size;
                    String url = "https://contract.ourbit.com/api/v1/contract/kline/" + URLEncoder.encode(pair, "UTF-8") + "?interval=" + URLEncoder.encode(tf, "UTF-8") + "&start=" + start + "&end=" + end;
                    payload = httpGet(url);
                } catch (Exception ignored) {}
                pushOurbitCallback("cpNativeOurbitFuturesKlines", requestId, payload);
            });
        }

        @JavascriptInterface
        public void fetchLBankKlinesWebSocket(String symbol, String interval, int limit, String requestId) {
            final String sym = symbol == null ? "btc" : symbol.trim().toLowerCase(Locale.US);
            final int size = Math.max(20, Math.min(240, limit <= 0 ? 240 : limit));
            try {
                priorityMarketExecutor.execute(() -> fetchLBankKlinesViaNativeWebSocket(sym, interval == null ? "1m" : interval, size, requestId));
            } catch (Exception ignored) {}
        }

        @JavascriptInterface
        public void fetchLBankKlines(String symbol, String interval, int limit, String requestId) {
            final String sym = symbol == null ? "BTC" : symbol.trim().toLowerCase(Locale.US);
            diagKlineState = "starting";
            diagKlineSymbol = sym;
            diagKlineInterval = interval == null ? "" : interval;
            diagKlineAttempts = 0;
            diagKlineRows = 0;
            diagKlineResponse = "";
            // Keep a visible diagnostic breadcrumb so we can distinguish JS bridge
            // lookup failures from a native request that actually started.
            try { if (web != null) web.post(() -> web.evaluateJavascript(
                    "window.cpNativeAutoStatus&&window.cpNativeAutoStatus(\'RUNNING\');", null)); } catch (Exception ignored) {}
            final String type;
            if ("5m".equals(interval)) type = "minute5";
            else if ("15m".equals(interval)) type = "minute15";
            else if ("1h".equals(interval)) type = "hour1";
            else if ("4h".equals(interval)) type = "hour4";
            else if ("1d".equals(interval)) type = "day1";
            else if ("1w".equals(interval)) type = "week1";
            else type = "minute1";
            final int size = Math.max(20, Math.min(1000, limit <= 0 ? 240 : limit));
            klinePriorityExecutor.execute(() -> {
                String result = null;
                final String pair = sym.endsWith("_usdt") ? sym : sym + "_usdt";
                final String[] bases = {"https://api.lbkex.com", "https://api.lbank.info", "https://www.lbkex.net"};
                // LBank documents `time` as a required Unix timestamp in seconds.
                // Gateways have differed in whether a timestamp exactly at "now"
                // returns the latest completed bars, so try a small set of sensible
                // reference points: now, one requested window back, and two windows back.
                final long nowSec = System.currentTimeMillis() / 1000L;
                long stepSec;
                if ("minute5".equals(type)) stepSec = 300L;
                else if ("minute15".equals(type)) stepSec = 900L;
                else if ("hour1".equals(type)) stepSec = 3600L;
                else if ("hour4".equals(type)) stepSec = 14400L;
                else if ("day1".equals(type)) stepSec = 86400L;
                else if ("week1".equals(type)) stepSec = 604800L;
                else stepSec = 60L;
                final long windowSec = stepSec * (long) size;
                final long[] timeCandidates = {nowSec, nowSec - windowSec, nowSec - (windowSec * 2L)};
                boolean success = false;
                for (String base : bases) {
                    for (long timeSec : timeCandidates) {
                        diagKlineAttempts++;
                        try {
                            String url = base + "/v2/kline.do?symbol=" + URLEncoder.encode(pair, "UTF-8")
                                    + "&type=" + type + "&size=" + size + "&time=" + timeSec;
                            result = httpGet(url);
                            int rowCount = 0;
                            try {
                                String tr = result == null ? "" : result.trim();
                                if (tr.startsWith("[")) {
                                    rowCount = new org.json.JSONArray(tr).length();
                                } else {
                                    org.json.JSONObject probe = new org.json.JSONObject(tr);
                                    Object data = probe.opt("data");
                                    if (data instanceof org.json.JSONArray) rowCount = ((org.json.JSONArray)data).length();
                                    if (rowCount == 0) {
                                        Object resultObj = probe.opt("result");
                                        if (resultObj instanceof org.json.JSONArray) rowCount = ((org.json.JSONArray)resultObj).length();
                                    }
                                }
                            } catch (Exception ignored) {}
                            diagKlineRows = rowCount;
                            diagKlineResponse = result == null ? "" : result.substring(0, Math.min(260, result.length()));
                            try {
                                if (result != null && result.trim().startsWith("{")) {
                                    JSONObject probe = new JSONObject(result);
                                    if (probe.has("result") && !probe.optBoolean("result", true)) {
                                        diagLastError = "LBank result=false code=" + probe.opt("error_code") + " msg=" + probe.optString("msg", "");
                                    }
                                }
                            } catch (Exception ignored) {}
                            if (rowCount >= 10) {
                                diagLastUrl = url;
                                diagLastHttp = "200 / KLINE=" + rowCount;
                                diagLastError = "";
                                diagKlineState = "success";
                                success = true;
                                break;
                            } else {
                                diagLastUrl = url;
                                diagLastHttp = "200 / KLINE rows=" + rowCount;
                                diagLastError = "LBank response has no usable 10+ candles";
                            }
                        } catch (Exception ex) {
                            diagLastError = String.valueOf(ex.getMessage());
                            diagKlineResponse = result == null ? "" : result.substring(0, Math.min(260, result.length()));
                        }
                    }
                    if (success) break;
                }
                if (!success) diagKlineState = "failed";
                final String payload = result;
                if (web != null) web.post(() -> {
                    if (web == null) return;
                    String rid = requestId == null ? "" : requestId.replace("\\", "\\\\").replace("'", "\\'");
                    String arg = payload == null ? "" : JSONObject.quote(payload);
                    web.evaluateJavascript("window.cpNativeKlines && window.cpNativeKlines('" + rid + "'," + arg + ");window.cpNativeAutoKlines && window.cpNativeAutoKlines(" + arg + ");window.cpNativeAutoStatus&&window.cpNativeAutoStatus(\'RECEIVED\');", null);
                });
            });
        }

        @JavascriptInterface
        public void fetchTickers() {
            // If the native background feed succeeded moments ago, do not create another
            // connection just because a WebView page was recreated. Restore the hot cache.
            if (System.currentTimeMillis() - lastBulkSuccessAt < 7000L) {
                pushNativeCacheToWeb();
                return;
            }
            networkExecutor.execute(() -> {
                String result = null;
                try {
                    result = httpGet("https://api.lbkex.com/v2/ticker/24hr.do?symbol=all");
                } catch (Exception first) {
                    try { result = httpGet("https://api.lbank.info/v2/ticker/24hr.do?symbol=all"); } catch (Exception second) {}
                }
                final String payload = result;
                cacheBulkMarketPayload(payload);
                if (web == null) return;
                web.post(() -> {
                    if (web == null) return;
                    String arg = payload == null ? "" : JSONObject.quote(payload);
                    web.evaluateJavascript("window.cpNativeMarketData && window.cpNativeMarketData(" + arg + ");", null);
                });
            });
        }

        @JavascriptInterface
        public void restoreMarketCache() {
            pushNativeCacheToWeb();
        }

        @JavascriptInterface
        public void fetchLBankAssetTicker(String symbol, String requestId) {
            final String sym = symbol == null ? "" : symbol.trim().toUpperCase(Locale.US);
            if (sym.isEmpty()) return;
            networkExecutor.execute(() -> {
                String pair = sym.toLowerCase(Locale.US) + "_usdt";
                String result = null;
                try {
                    result = httpGet("https://api.lbkex.com/v2/ticker/24hr.do?symbol=" + pair);
                } catch (Exception e1) {
                    try { result = httpGet("https://api.lbank.info/v2/ticker/24hr.do?symbol=" + pair); }
                    catch (Exception e2) { try { result = httpGet("https://www.lbkex.net/v2/ticker/24hr.do?symbol=" + pair); } catch (Exception ignored) {} }
                }
                final String payload = result == null ? "" : result;
                if (web != null) web.post(() -> web.evaluateJavascript(
                        "window.cpNativeAssetTicker && window.cpNativeAssetTicker(" + JSONObject.quote(requestId == null ? "" : requestId) + "," + JSONObject.quote(payload) + ");", null));
            });
        }

        @JavascriptInterface
        public void fetchLBankAssetDepth(String symbol, int limit, String requestId) {
            final String sym = symbol == null ? "" : symbol.trim().toUpperCase(Locale.US);
            if (sym.isEmpty()) return;
            final int size = Math.max(10, Math.min(60, limit));
            networkExecutor.execute(() -> {
                String pair = sym.toLowerCase(Locale.US) + "_usdt";
                String result = null;
                String[] bases = {"https://api.lbkex.com", "https://api.lbank.info", "https://www.lbkex.net"};
                for (String base : bases) {
                    try { result = httpGet(base + "/v2/depth.do?symbol=" + pair + "&size=" + size); if (result != null && !result.isEmpty()) break; }
                    catch (Exception ignored) {}
                }
                final String payload = result == null ? "" : result;
                if (web != null) web.post(() -> web.evaluateJavascript(
                        "window.cpNativeAssetDepth && window.cpNativeAssetDepth(" + JSONObject.quote(requestId == null ? "" : requestId) + "," + JSONObject.quote(payload) + ");", null));
            });
        }


        /** Fetch individual missing symbols directly from LBank. This is used when the
         *  bulk ticker endpoint omits a symbol or the bulk response is incomplete. */
        @JavascriptInterface
        public void fetchMissingLBankTickers(String symbols) {
            if (symbols == null || symbols.trim().isEmpty()) return;
            final java.util.ArrayList<String> list = new java.util.ArrayList<>();
            final java.util.HashSet<String> seen = new java.util.HashSet<>();
            for (String item : symbols.split(",")) {
                String sym = item == null ? "" : item.trim().toUpperCase(Locale.US);
                if (sym.isEmpty() || !seen.add(sym)) continue;
                list.add(sym);
                if (list.size() >= 20) break;
            }
            if (list.isEmpty()) return;
            backgroundMissingSymbols.addAll(list);
            // Root fix: do NOT hammer the bulk endpoint for every missing batch.
            // Request the exact LBank pair directly, with only four concurrent
            // requests. LBank documents /v2/ticker/24hr.do?symbol=<pair> as the
            // canonical current ticker endpoint; this avoids partial bulk envelopes,
            // parser ambiguity, and request bursts that previously left most rows blank.
            for (String sym : list) {
                Long last = missingLastAttempt.get(sym);
                long now = System.currentTimeMillis();
                if (last != null && now-last < 2500L) continue;
                missingLastAttempt.put(sym, now);
                priorityMarketExecutor.execute(() -> {
                    JSONObject one = fetchAndCacheOneSymbol(sym);
                    if (one != null) pushNativeMissingRow(one);
                });
            }
        }

        private java.util.HashMap<String, JSONObject> parseBulkTickerRows(String payload) {
            java.util.HashMap<String, JSONObject> out = new java.util.HashMap<>();
            if (payload == null || payload.trim().isEmpty()) return out;
            try {
                Object root = payload.trim().startsWith("[")
                        ? new org.json.JSONArray(payload) : new JSONObject(payload);
                java.util.ArrayDeque<Object> stack = new java.util.ArrayDeque<>();
                stack.push(root);
                while (!stack.isEmpty()) {
                    Object node = stack.pop();
                    if (node instanceof org.json.JSONArray) {
                        org.json.JSONArray a=(org.json.JSONArray)node;
                        for(int i=0;i<a.length();i++){ Object v=a.opt(i); if(v!=null) stack.push(v); }
                        continue;
                    }
                    if (!(node instanceof JSONObject)) continue;
                    JSONObject o=(JSONObject)node;
                    String raw=o.optString("symbol",o.optString("pair",o.optString("currencyPair","")));
                    String sym=normPair(raw).toUpperCase(Locale.US);
                    JSONObject t=firstTickerObject(o);
                    if (sym.endsWith("_USDT") && t!=null) {
                        double price=tickerNumber(t,"latest","lastPrice","last","price","close","closePrice","lastTradedPrice");
                        if(!Double.isNaN(price)&&price>0){
                            JSONObject row=new JSONObject();
                            String key=sym.substring(0,sym.length()-5);
                            row.put("symbol",key);
                            row.put("price",price);
                            double ch=tickerNumber(t,"change","changeRate","changePercent","priceChangePercent","increase","riseRate");
                            double vol=tickerNumber(t,"vol","volume","quoteVolume","amount","turnover");
                            row.put("change",Double.isNaN(ch)?0:ch);
                            row.put("volume",Double.isNaN(vol)?0:vol);
                            row.put("provider","LBank Native Bulk Retry");
                            out.put(key,row);
                        }
                    }
                    java.util.Iterator<String> it=o.keys();
                    while(it.hasNext()){
                        String k=it.next(); Object v=o.opt(k);
                        String kk=k==null?"":k.trim().toLowerCase(Locale.US);
                        if(kk.endsWith("_usdt") && v instanceof JSONObject){
                            String key=kk.substring(0,kk.length()-5).toUpperCase(Locale.US);
                            JSONObject t2=firstTickerObject(v);
                            if(t2!=null){
                                double price=tickerNumber(t2,"latest","lastPrice","last","price","close","closePrice","lastTradedPrice");
                                if(!Double.isNaN(price)&&price>0){
                                    JSONObject row=new JSONObject(); row.put("symbol",key); row.put("price",price);
                                    double ch=tickerNumber(t2,"change","changeRate","changePercent","priceChangePercent","increase","riseRate");
                                    double vol=tickerNumber(t2,"vol","volume","quoteVolume","amount","turnover");
                                    row.put("change",Double.isNaN(ch)?0:ch); row.put("volume",Double.isNaN(vol)?0:vol);
                                    row.put("provider","LBank Native Bulk Retry"); out.put(key,row);
                                }
                            }
                        }
                        if(v instanceof JSONObject || v instanceof org.json.JSONArray) stack.push(v);
                    }
                }
            } catch(Exception ignored) {}
            return out;
        }

        private void pushNativeMissingRow(JSONObject row) {
            if(row==null) return;
            try {
                String sym=row.optString("symbol","").toUpperCase(Locale.US);
                double price=row.optDouble("price",Double.NaN);
                if(sym.isEmpty()||Double.isNaN(price)||price<=0)return;
                row.put("lastUpdate",System.currentTimeMillis());
                nativeMarketCache.put(sym,row.toString());
                final String payload=row.toString();
                if(web!=null) web.post(()->{
                    if(web==null)return;
                    web.evaluateJavascript("window.cpNativeMissingLBankMarketRow && window.cpNativeMissingLBankMarketRow("+JSONObject.quote(payload)+");",null);
                });
            }catch(Exception ignored){}
        }

        // STAGE1161: expose policy/state only; never expose key material.
        @JavascriptInterface
        public String getWalletSecurityState() {
            return MainActivity.this.getWalletSecurityState().toString();
        }

        // STAGE1162: public capability/state only. Never returns seed/private-key bytes.
        @JavascriptInterface
        public String getWalletCapabilityState() {
            return MainActivity.this.getWalletCapabilityState().toString();
        }

        // STAGE1163: read-only Sepolia network state; no RPC secret is exposed.
        @JavascriptInterface
        public String getSepoliaNetworkState() {
            return MainActivity.this.getSepoliaNetworkState().toString();
        }

        @JavascriptInterface
        public String getMainnetLockState() {
            return MainActivity.this.getMainnetLockState().toString();
        }

        @JavascriptInterface
        public void refreshSepoliaNetworkState() {
            MainActivity.this.fetchSepoliaChainState();
        }

        // STAGE1164: read-only CPLS ERC-20 interface. No signing or transaction methods.
        @JavascriptInterface
        public String getCplsContractState() {
            return MainActivity.this.getCplsContractState().toString();
        }

        @JavascriptInterface
        public String buildCplsReadCall(String method, String walletAddress) {
            return MainActivity.this.buildCplsReadCall(method, walletAddress).toString();
        }

        @JavascriptInterface
        public String buildRewardClaimIntent(String accountRef, String walletAddress, String clientNonce, long expiresAt) {
            return MainActivity.this.buildRewardClaimIntent(accountRef, walletAddress, clientNonce, expiresAt).toString();
        }

        // STAGE1167: advisory app-integrity telemetry. No attestation or reward authorization.
        @JavascriptInterface
        public String getAppIntegrityBoundaryState() {
            return MainActivity.this.getAppIntegrityBoundaryState().toString();
        }
        public String runSecurityTestHarness() {
            return MainActivity.this.runSecurityTestHarness().toString();
        }

        /** Broad secondary feed to fill symbols missing from LBank. */
        @JavascriptInterface
        public void fetchCoinCapTickers() {
            networkExecutor.execute(() -> {
                String result = null;
                try {
                    result = httpGet("https://api.coincap.io/v2/assets?limit=2000");
                } catch (Exception ignored) {}
                final String payload = result;
                if (web == null) return;
                web.post(() -> {
                    if (web == null) return;
                    String arg = payload == null ? "" : JSONObject.quote(payload);
                    web.evaluateJavascript("window.cpNativeCoinCapMarketData && window.cpNativeCoinCapMarketData(" + arg + ");", null);
                });
            });
        }

        /** Third public feed used to fill any symbols still missing after LBank/Binance/CoinCap. */
        @JavascriptInterface
        public void fetchCoinPaprikaTickers() {
            networkExecutor.execute(() -> {
                String result = null;
                try {
                    result = httpGet("https://api.coinpaprika.com/v1/tickers?quotes=USD&limit=2000");
                } catch (Exception ignored) {}
                final String payload = result;
                if (web == null) return;
                web.post(() -> {
                    if (web == null) return;
                    String arg = payload == null ? "" : JSONObject.quote(payload);
                    web.evaluateJavascript("window.cpNativeCoinPaprikaMarketData && window.cpNativeCoinPaprikaMarketData(" + arg + ");", null);
                });
            });
        }

        /** Secondary public feed used only to fill symbols that LBank does not return. */
        @JavascriptInterface
        public void fetchFallbackTickers() {
            networkExecutor.execute(() -> {
                String result = null;
                try {
                    result = httpGet("https://api.binance.com/api/v3/ticker/24hr");
                } catch (Exception ignored) {}
                final String payload = result;
                if (web == null) return;
                web.post(() -> {
                    if (web == null) return;
                    String arg = payload == null ? "" : JSONObject.quote(payload);
                    web.evaluateJavascript("window.cpNativeBinanceMarketData && window.cpNativeBinanceMarketData(" + arg + ");", null);
                });
            });
        }

        private String httpGet(String urlString) throws Exception {
            HttpURLConnection c = (HttpURLConnection) new URL(urlString).openConnection();
            c.setRequestMethod("GET");
            // Short fail-fast timeouts make a bad route fail quickly so a fallback
            // provider/retry can take over instead of freezing the UI for 7-9 seconds.
            c.setConnectTimeout(2500);
            c.setReadTimeout(4500);
            c.setUseCaches(false);
            c.setRequestProperty("Accept", "application/json");
            c.setRequestProperty("User-Agent", "CryptoPulse/Android");
            c.setRequestProperty("Accept-Encoding", "identity");
            int code = c.getResponseCode();
            diagLastHttp = String.valueOf(code);
            diagLastUrl = urlString;
            InputStream in = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
            if (in == null) { diagErrorCount++; diagLastError = "HTTP " + code; throw new Exception("HTTP " + code); }
            StringBuilder out = new StringBuilder();
            try (BufferedReader br = new BufferedReader(new InputStreamReader(in, "UTF-8"))) {
                String line;
                while ((line = br.readLine()) != null) out.append(line);
            } finally { c.disconnect(); }
            if (code < 200 || code >= 300) { diagErrorCount++; diagLastError = "HTTP " + code; throw new Exception("HTTP " + code); }
            diagSuccessCount++; diagLastError = "";
            return out.toString();
        }
    }
    @Override public void onDestroy() {
        try { stopNativeLbankSocket(); } catch (Exception ignored) {}
        try { lbankWsScheduler.shutdownNow(); } catch (Exception ignored) {}
        try { futuresBackgroundExecutor.shutdownNow(); } catch (Exception ignored) {}
        try { klinePriorityExecutor.shutdownNow(); } catch (Exception ignored) {}
        try { priorityMarketExecutor.shutdownNow(); } catch (Exception ignored) {}
        try { networkExecutor.shutdownNow(); } catch (Exception ignored) {}
        try { lbankWsSubscribedPairs.clear(); } catch (Exception ignored) {}
        try { lbankWsClient.dispatcher().executorService().shutdown(); } catch (Exception ignored) {}
        try { lbankWsClient.connectionPool().evictAll(); } catch (Exception ignored) {}
        super.onDestroy();
    }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        window.setStatusBarColor(Color.rgb(5,11,18));
        window.setNavigationBarColor(Color.rgb(5,11,18));
        if (Build.VERSION.SDK_INT >= 23) window.getDecorView().setSystemUiVisibility(0);
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(5,11,18));
        WebSettings s = web.getSettings();
        // Stage 1186: initialize JavaScript before installing the native bridge.
        // Some Android WebView providers are stricter about the order and can
        // otherwise render the page while window.CryptoPulseNative is absent.
        s.setJavaScriptEnabled(true);
        cryptoPulseBridge = new MarketBridge();
        web.addJavascriptInterface(cryptoPulseBridge, "CryptoPulseNative");
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setLoadWithOverviewMode(false);
        s.setUseWideViewPort(false);
        s.setTextZoom(100);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setSupportMultipleWindows(false);
        s.setMediaPlaybackRequiresUserGesture(true);
        if (Build.VERSION.SDK_INT >= 29) s.setForceDark(WebSettings.FORCE_DARK_OFF);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        web.setVerticalScrollBarEnabled(false);
        web.setHorizontalScrollBarEnabled(false);
        web.setOverScrollMode(WebView.OVER_SCROLL_NEVER);
        web.setLayerType(WebView.LAYER_TYPE_HARDWARE, null);
        web.setWebViewClient(new WebViewClient() {
            private boolean openInsideCryptoPulse(String url) {
                if (url == null) return false;
                try {
                    Uri u = Uri.parse(url);
                    String host = u.getHost();
                    String path = u.getPath();
                    if (host == null) return false;
                    host = host.toLowerCase(Locale.US);
                    if (!host.contains("tradingview.com") || path == null) return false;

                    // TradingView screener symbol links look like /symbols/BTCUSD/
                    // or may carry tvwidgetsymbol=BINANCE%3ABTCUSDT.
                    String ticker = null;
                    String q = u.getQueryParameter("tvwidgetsymbol");
                    if (q != null && !q.trim().isEmpty()) {
                        int colon = q.lastIndexOf(':');
                        ticker = colon >= 0 ? q.substring(colon + 1) : q;
                    }
                    if (ticker == null && path.toLowerCase(Locale.US).startsWith("/symbols/")) {
                        String[] parts = path.split("/");
                        if (parts.length > 2) ticker = parts[2];
                    }
                    if (ticker == null) return false;

                    ticker = ticker.toUpperCase(Locale.US).replaceAll("[^A-Z0-9._-]", "");
                    ticker = ticker.replace("-", "").replace("_", "");
                    // CryptoPulse's internal chart uses the coin symbol and adds USDT
                    // for the LBank pair. Remove common quote currencies from TV's ticker.
                    String[] quotes = {"USDT", "USDC", "BUSD", "FDUSD", "USD", "EUR", "BTC", "ETH"};
                    for (String quote : quotes) {
                        if (ticker.length() > quote.length() + 1 && ticker.endsWith(quote)) {
                            ticker = ticker.substring(0, ticker.length() - quote.length());
                            break;
                        }
                    }
                    if (ticker.isEmpty()) return false;

                    view.loadUrl("file:///android_asset/web/asset.html?symbol=" + Uri.encode(ticker));
                    return true;
                } catch (Exception ignored) {
                    return false;
                }
            }

            @Override public void onPageFinished(WebView view, String url) {
                // Stage 1186: re-install the bridge on every document/page finish.
                // Internal CryptoPulse routing keeps one WebView alive, while some
                // WebView implementations can lose/recreate the JS interface context.
                try { view.addJavascriptInterface(cryptoPulseBridge != null ? cryptoPulseBridge : (cryptoPulseBridge = new MarketBridge()), "CryptoPulseNative"); } catch (Exception ignored) {}
                super.onPageFinished(view, url);
                // A page change must not create a new market connection. Restore the
                // already-running native feed snapshot immediately into the new document.
                // Restore hot native Futures data immediately after every internal page render.
                try { pushAllHotFuturesSnapshots(); } catch (Exception ignored) {}
                // REBUILD90: every fresh app launch must visibly start on the complete Home
                // screen. Re-run Home hydration after the document is fully ready and reset
                // its scroll position so a restored WebView cannot leave a partial/offset Home.
                try {
                    Uri pageUri = Uri.parse(url);
                    String pagePath = pageUri.getPath();
                    if (pagePath != null && pagePath.endsWith("/index.html")) {
                        web.postDelayed(() -> {
                            try {
                                web.evaluateJavascript("window.__cpCurrentPage='index';window.scrollTo(0,0);if(typeof initHomePage==='function'){initHomePage();}if(typeof bindBottomNav==='function'){bindBottomNav();}", null);
                            } catch (Exception ignored) {}
                        }, 80L);
                    }
                } catch (Exception ignored) {}
                pushNativeCacheToWeb();
                pushNativeUniverseToWeb();
                // TV80: explicitly re-run authoritative LBank universe discovery
                // after the document is ready. This fixes the startup race where
                // the background request completed before JavaScript was available.
                marketBackgroundExecutor.execute(() -> fetchNativeMarketUniverse());
                // REBUILD38: some HTML-to-APK WebViews expose the bridge object but
                // intermittently omit a newly-added method from JavaScript. For asset
                // pages, request K-Line from Java directly after the document is ready
                // and push the result into the page, bypassing that JS->Java call path.
                try {
                    Uri u = Uri.parse(url);
                    if (u.getPath() != null && u.getPath().endsWith("/asset.html")) {
                        String ticker = u.getQueryParameter("symbol");
                        if (ticker != null && !ticker.trim().isEmpty()) {
                            final String nativeSym = ticker.trim().toLowerCase(Locale.US);
                            // REBUILD39: never queue visible chart history behind the
                            // single-thread market background scheduler. That scheduler
                            // also handles universe/subscription work and can legitimately
                            // stay busy for a while. K-Line history gets its own priority lane.
                            try {
                                web.post(() -> web.evaluateJavascript(
                                        "window.cpNativeAutoStatus&&window.cpNativeAutoStatus('STARTED');", null));
                            } catch (Exception ignored) {}
                            priorityMarketExecutor.execute(() -> {
                                try { new MarketBridge().fetchLBankKlinesViaNativeWebSocket(nativeSym, "live", 240); }
                                catch (Exception ignored) {
                                    try { web.post(() -> web.evaluateJavascript(
                                            "window.cpNativeAutoStatus&&window.cpNativeAutoStatus('JAVA_ERROR');", null)); } catch (Exception ignored2) {}
                                }
                            });
                        }
                    }
                } catch (Exception ignored) {}
            }

            @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                // Stage 1186: also bind before page scripts execute.
                try { view.addJavascriptInterface(cryptoPulseBridge != null ? cryptoPulseBridge : (cryptoPulseBridge = new MarketBridge()), "CryptoPulseNative"); } catch (Exception ignored) {}
                // Extra safety: TradingView may navigate via a target/_blank or JS route.
                // If the main WebView ever reaches a TradingView symbol page, immediately
                // convert it to CryptoPulse's internal asset/chart route.
                if (openInsideCryptoPulse(url)) return;
                super.onPageStarted(view, url, favicon);
            }

            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                if (Build.VERSION.SDK_INT >= 21 && request != null) {
                    if (openInsideCryptoPulse(request.getUrl().toString())) return true;
                }
                return false;
            }

            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (openInsideCryptoPulse(url)) return true;
                return false;
            }
        });
        web.setFocusable(true);
        web.setFocusableInTouchMode(true);
        web.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
        // Start the native market feeder before the first page load so the first
        // HTML document can immediately consume the same persistent cache.
        // TV79: never seed Markets from a bundled/stale catalogue.
        // The live LBank pair universe is the only market source of truth.
        // TV87: seed Home immediately from the bundled LBank spot catalogue.
        // This is only a startup/offline safety net; a successful live LBank
        // universe replaces it as soon as the native market discovery returns.
        loadBundledLbankSpotUniverse();
        startBackgroundMarketFeed();
        // REBUILD04: actually start the native socket at app startup. REBUILD03
        // exposed the native socket bridge but never invoked it automatically,
        // leaving the app permanently OFFLINE.
        startNativeLbankSocket();
        // Prime a tiny REST lane as an independent safety net while the socket
        // performs its handshake/subscriptions.
        marketBackgroundExecutor.schedule(() -> fetchAndCacheOneSymbol("BTC"), 1200, TimeUnit.MILLISECONDS);
        marketBackgroundExecutor.schedule(() -> fetchAndCacheOneSymbol("ETH"), 1800, TimeUnit.MILLISECONDS);
        // REBUILD90: always enter the app on Home, never on a previously-restored chart/page.
        try { web.clearHistory(); } catch (Exception ignored) {}
        // Pre-warm the most-used Futures contract before the user opens the page.
        startPersistentFuturesFeed("BTC");
        startFuturesWebSocketDiagnostic();
        if (futuresFeedStarted.compareAndSet(false, true)) {
            futuresBackgroundExecutor.scheduleAtFixedRate(this::pollPersistentFutures, 500, 1500, TimeUnit.MILLISECONDS);
        }
        web.loadUrl("file:///android_asset/web/index.html");
        // MOBILE FIX 1171: cold-start route guard. A restored WebView/history state
        // must never surface Settings/Profile as the first screen. This is one-shot
        // and does not interfere with later in-app navigation.
        web.postDelayed(() -> {
            try {
                web.evaluateJavascript("(function(){try{var p=(location.pathname.split('/').pop()||'index.html').toLowerCase();if(p!=='index.html'){location.replace('index.html');}else{window.__cpCurrentPage='index';window.scrollTo(0,0);if(typeof initHomePage==='function')initHomePage();}}catch(e){}})();", null);
            } catch (Exception ignored) {}
        }, 350L);
        // Push any hot Futures cache into a newly ready WebView without reopening the feed.
        web.postDelayed(this::pushAllHotFuturesSnapshots, 450);
        web.postDelayed(this::pushAllHotFuturesSnapshots, 1200);
        web.postDelayed(this::pushAllHotFuturesSnapshots, 2400);
        setContentView(web);
        // Stage 1188: final bridge attach after the WebView is attached to the window.
        // Keep one persistent bridge instance for the entire Activity lifetime.
        web.post(() -> {
            try {
                if (cryptoPulseBridge == null) cryptoPulseBridge = new MarketBridge();
                web.addJavascriptInterface(cryptoPulseBridge, "CryptoPulseNative");
                web.evaluateJavascript("(function(){window.__cpBridgeProbe=(typeof window.CryptoPulseNative!==\"undefined\")?\"VISIBLE\":\"MISSING\";})();", null);
            } catch (Exception ignored) {}
        });
    }
    @Override protected void onPause() {
        if (web != null) web.onPause();
        super.onPause();
    }
    @Override protected void onResume() {
        super.onResume();
        if (web != null) {
            web.onResume();
            pushNativeCacheToWeb();
        }
    }
    @Override protected void onDestroy() {
        try { if (futuresDiagnosticSocket != null) futuresDiagnosticSocket.close(1000, "activity-destroy"); } catch (Exception ignored) {}
        marketBackgroundExecutor.shutdownNow();
        priorityMarketExecutor.shutdownNow();
        networkExecutor.shutdownNow();
        if (web != null) { web.loadUrl("about:blank"); web.stopLoading(); web.destroy(); web = null; }
        super.onDestroy();
    }
    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
