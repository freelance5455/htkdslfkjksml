package com.cybermh.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebSettings;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        WebView w = new WebView(this);
        w.setBackgroundColor(0xFF05080D);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        w.loadUrl("file:///android_asset/index.html");
        setContentView(w);
    }
    @Override public void onBackPressed() {
        WebView w = (WebView)findViewById(android.R.id.content).findViewWithTag("web");
        super.onBackPressed();
    }
}
