package com.samarthai.app

import android.app.Activity
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebSettings
import android.speech.tts.TextToSpeech
import android.webkit.JavascriptInterface
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var web: WebView
    private lateinit var tts: TextToSpeech

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.cacheMode = WebSettings.LOAD_DEFAULT
        web.webViewClient = WebViewClient()
        tts = TextToSpeech(this, this)
        web.addJavascriptInterface(VoiceBridge(), "SamarthVoice")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts.language = Locale.getDefault()
    }

    inner class VoiceBridge {
        @JavascriptInterface
        fun speak(text: String, gender: String, rate: Float) {
            val voice = tts.voices?.firstOrNull {
                val n = it.name.lowercase()
                if (gender == "female") n.contains("female") else n.contains("male")
            }
            if (voice != null) tts.voice = voice
            tts.setSpeechRate(rate.coerceIn(0.5f, 1.5f))
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "samarth")
        }
        @JavascriptInterface
        fun stop() { tts.stop() }
    }

    override fun onDestroy() {
        tts.stop()
        tts.shutdown()
        super.onDestroy()
    }
}
