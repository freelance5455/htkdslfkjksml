package com.nexuseffect.app;
import android.app.*;import android.os.*;import android.content.*;import android.net.*;import android.database.Cursor;import android.provider.OpenableColumns;import android.graphics.Color;import android.view.Gravity;import android.widget.*;import java.io.*;import com.arthenica.ffmpegkit.FFmpegKit;import com.arthenica.ffmpegkit.ReturnCode;
public class MainActivity extends Activity {
 static final int PICK=1; File source; EditText prompt; TextView status,chosen; Button go;
 public void onCreate(Bundle b){super.onCreate(b); LinearLayout l=new LinearLayout(this);l.setOrientation(1);l.setPadding(22,25,22,20);l.setBackgroundColor(Color.rgb(12,16,30));
 TextView t=new TextView(this);t.setText("NEXUS EFFECT");t.setTextColor(Color.rgb(255,190,65));t.setTextSize(28);t.setGravity(Gravity.CENTER);l.addView(t);
 TextView sub=new TextView(this);sub.setText("Escolhe um clipe e escreve os efeitos que queres.");sub.setTextColor(-1);l.addView(sub);
 Button pick=new Button(this);pick.setText("Escolher clipe");pick.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("video/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,PICK);});l.addView(pick);
 chosen=new TextView(this);chosen.setText("Nenhum clipe selecionado");chosen.setTextColor(-1);l.addView(chosen);
 prompt=new EditText(this);prompt.setTextColor(-1);prompt.setHintTextColor(0xffbbbbbb);prompt.setHint("Ex.: reverso com zoom e shake");prompt.setMinLines(3);l.addView(prompt,new LinearLayout.LayoutParams(-1,130));
 TextView ex=new TextView(this);ex.setText("Palavras: reverso, zoom, shake");ex.setTextColor(0xffc5d0e8);l.addView(ex);
 go=new Button(this);go.setText("GERAR VÍDEO");go.setOnClickListener(v->process());l.addView(go);
 status=new TextView(this);status.setTextColor(-1);l.addView(status);setContentView(l);}
 protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==PICK&&c==RESULT_OK&&d!=null)try{Uri u=d.getData();source=new File(getCacheDir(),"source.mp4");try(InputStream in=getContentResolver().openInputStream(u);FileOutputStream out=new FileOutputStream(source)){byte[] buf=new byte[8192];int n;while((n=in.read(buf))>0)out.write(buf,0,n);}chosen.setText("Clipe pronto: "+name(u));status.setText("Pronto para processar.");}catch(Exception e){status.setText("Erro ao abrir o vídeo.");}}
 String name(Uri u){try(Cursor c=getContentResolver().query(u,null,null,null,null)){if(c!=null&&c.moveToFirst()){int i=c.getColumnIndex(OpenableColumns.DISPLAY_NAME);if(i>=0)return c.getString(i);}}catch(Exception e){}return "vídeo selecionado";}
 void process(){if(source==null){status.setText("Escolhe primeiro um clipe.");return;}String p=prompt.getText().toString().toLowerCase();boolean rev=p.contains("reverso")||p.contains("reverse"),zoom=p.contains("zoom"),shake=p.contains("shake")||p.contains("tremid");if(!rev&&!zoom&&!shake){status.setText("Escreve reverso, zoom ou shake.");return;}
 StringBuilder f=new StringBuilder();if(rev)f.append("reverse,setpts=PTS-STARTPTS");if(zoom){if(f.length()>0)f.append(",");f.append("scale=iw*1.15:ih*1.15,crop=iw/1.15:ih/1.15");}if(shake){if(f.length()>0)f.append(",");f.append("crop=iw-20:ih-20:x='10+8*sin(25*t)':y='10+8*cos(22*t)'");}
 File out=new File(getExternalFilesDir(null),"NexusEffect.mp4");String cmd="-y -i \""+source.getAbsolutePath()+"\" -vf \""+f+"\" -c:v mpeg4 -q:v 4 -c:a aac \""+out.getAbsolutePath()+"\"";go.setEnabled(false);status.setText("A processar…");
 FFmpegKit.executeAsync(cmd,s->runOnUiThread(()->{go.setEnabled(true);if(ReturnCode.isSuccess(s.getReturnCode()))status.setText("Feito! Guardado em Android/data/com.nexuseffect.app/files/NexusEffect.mp4");else status.setText("Falhou. Tenta outro clipe. Código: "+s.getReturnCode());}));}
}
