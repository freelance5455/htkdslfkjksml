package com.fixsis.app;

import android.app.Activity;
import android.os.Bundle;
import android.telecom.Call;
import android.telecom.DisconnectCause;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Locale;

public class InCallActivity extends Activity {
    private LinearLayout root;
    private TextView stateText;
    private Call call;
    private final Call.Callback callback = new Call.Callback() {
        @Override public void onStateChanged(Call c, int state) { runOnUiThread(() -> refresh()); }
        @Override public void onDetailsChanged(Call c, Call.Details details) { runOnUiThread(() -> refresh()); }
    };
    @Override protected void onCreate(Bundle state) { super.onCreate(state); getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); call = FixSisInCallService.activeCall; build(); refresh(); }
    @Override protected void onNewIntent(android.content.Intent intent) { super.onNewIntent(intent); setIntent(intent); call = FixSisInCallService.activeCall; refresh(); }
    @Override protected void onResume() { super.onResume(); call = FixSisInCallService.activeCall; if (call != null) call.registerCallback(callback); refresh(); }
    @Override protected void onPause() { if (call != null) call.unregisterCallback(callback); super.onPause(); }
    private void build() {
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(28,42,28,28); root.setGravity(Gravity.CENTER_HORIZONTAL); root.setBackgroundColor(0xff0f172a);
        scroll.addView(root); setContentView(scroll);
        TextView title = text("FixSis Arama", 25, 0xffffffff); root.addView(title);
        stateText = text("Arama bilgileri yükleniyor…", 18, 0xff34d399); stateText.setPadding(0,24,0,12); root.addView(stateText);
    }
    private TextView text(String value, int size, int color) { TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color); t.setGravity(Gravity.CENTER); t.setPadding(0,8,0,8); return t; }
    private void addButton(String label, int color, Runnable action) { Button b = new Button(this); b.setText(label); b.setTextColor(0xffffffff); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(color)); b.setOnClickListener(v -> action.run()); root.addView(b, new LinearLayout.LayoutParams(-1,-2)); }
    private void refresh() {
        if (root == null) return;
        while (root.getChildCount() > 2) root.removeViewAt(2);
        call = FixSisInCallService.activeCall;
        String number = "Bilinmeyen numara";
        if (call != null && call.getDetails() != null && call.getDetails().getHandle() != null) number = call.getDetails().getHandle().getSchemeSpecificPart();
        JSONObject customer = CallDirectory.find(this, number);
        String stateLabel = call == null ? "Arama sona erdi" : stateName(call.getState());
        stateText.setText(stateLabel + "\n" + number);
        if (customer.optBoolean("found", false)) {
            root.addView(text(customer.optString("name", "Müşteri"), 23, 0xffffffff));
            root.addView(text(customer.optString("phone", number), 15, 0xff94a3b8));
            root.addView(text(customer.optString("district", "") + "\n" + customer.optString("address", "Adres yok"), 16, 0xffe2e8f0));
            root.addView(text("Veresiye toplamı: " + String.format(Locale.forLanguageTag("tr-TR"), "%.2f TL", customer.optDouble("debt",0)), 18, 0xfffbbf24));
            JSONArray orders = customer.optJSONArray("orders");
            if (orders != null) {
                root.addView(text("Önceki siparişler", 18, 0xff34d399));
                for (int i=Math.max(0,orders.length()-5); i<orders.length(); i++) {
                    JSONObject o = orders.optJSONObject(i); if (o == null) continue;
                    root.addView(text(o.optString("orderNo") + " · " + o.optString("status") + " · " + String.format(Locale.forLanguageTag("tr-TR"), "%.2f TL", o.optDouble("totalPrice",0)), 14, 0xffcbd5e1));
                }
            }
        } else root.addView(text("Bu numara FixSis müşteri kayıtlarında bulunamadı.", 16, 0xffcbd5e1));
        if (call != null) {
            if (call.getState() == Call.STATE_RINGING) addButton("Cevapla", 0xff059669, () -> call.answer(android.telecom.VideoProfile.STATE_AUDIO_ONLY));
            addButton("Aramayı Bitir", 0xffdc2626, () -> call.disconnect());
        }
        addButton("Kapat", 0xff334155, this::finish);
    }
    private String stateName(int state) {
        switch (state) {
            case Call.STATE_RINGING: return "Gelen arama";
            case Call.STATE_DIALING: return "Aranıyor";
            case Call.STATE_ACTIVE: return "Görüşme sürüyor";
            case Call.STATE_HOLDING: return "Beklemede";
            case Call.STATE_CONNECTING: return "Bağlanıyor";
            case Call.STATE_DISCONNECTED: return "Arama sona erdi";
            default: return "Arama";
        }
    }
}
