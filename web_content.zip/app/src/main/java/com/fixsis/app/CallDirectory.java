package com.fixsis.app;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;

final class CallDirectory {
    private CallDirectory() {}
    static void save(Context context, String customers, String orders) {
        context.getSharedPreferences("fixsis_call_directory", Context.MODE_PRIVATE)
                .edit().putString("customers", customers == null ? "[]" : customers)
                .putString("orders", orders == null ? "[]" : orders).apply();
    }
    static JSONObject find(Context context, String number) {
        SharedPreferences prefs = context.getSharedPreferences("fixsis_call_directory", Context.MODE_PRIVATE);
        JSONArray customers = parse(prefs.getString("customers", "[]"));
        JSONArray orders = parse(prefs.getString("orders", "[]"));
        String target = digits(number);
        if (target.isEmpty()) return new JSONObject();
        JSONObject found = null;
        for (int i=0; i<customers.length(); i++) {
            JSONObject c = customers.optJSONObject(i);
            if (c == null) continue;
            String phone = digits(c.optString("phone", ""));
            if (!phone.isEmpty() && (target.endsWith(phone) || phone.endsWith(target))) { found = c; break; }
        }
        JSONObject result = new JSONObject();
        if (found == null) {
            try { result.put("found", false); result.put("number", number == null ? "" : number); }
            catch (Exception ignored) {}
            return result;
        }
        try {
            result.put("found", true);
            result.put("name", found.optString("name", "Kayıtlı müşteri"));
            result.put("phone", found.optString("phone", ""));
            result.put("address", found.optString("address", "Adres yok"));
            result.put("district", found.optString("district", ""));
            String customerId = found.optString("id", "");
            JSONArray matched = new JSONArray();
            double debt = 0;
            for (int i=0; i<orders.length(); i++) {
                JSONObject o = orders.optJSONObject(i);
                if (o == null || !customerId.equals(o.optString("customerId", "")) || o.optBoolean("isDeleted", false)) continue;
                JSONObject row = new JSONObject();
                row.put("orderNo", o.optString("orderNo", "Sipariş"));
                row.put("status", o.optString("status", ""));
                row.put("totalPrice", o.optDouble("totalPrice", 0));
                row.put("paymentStatus", o.optString("paymentStatus", ""));
                matched.put(row);
                if ("Veresiye".equalsIgnoreCase(o.optString("paymentStatus", ""))) debt += o.optDouble("totalPrice", 0);
            }
            result.put("orders", matched);
            result.put("debt", debt);
        } catch (Exception ignored) {}
        return result;
    }
    private static JSONArray parse(String raw) { try { return new JSONArray(raw); } catch (Exception e) { return new JSONArray(); } }
    private static String digits(String value) { return value == null ? "" : value.replaceAll("[^0-9]", ""); }
}
