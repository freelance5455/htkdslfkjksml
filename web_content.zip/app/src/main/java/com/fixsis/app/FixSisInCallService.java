package com.fixsis.app;

import android.content.Intent;
import android.telecom.Call;
import android.telecom.InCallService;

public class FixSisInCallService extends InCallService {
    static volatile Call activeCall;
    @Override public void onCallAdded(Call call) {
        super.onCallAdded(call);
        activeCall = call;
        Intent intent = new Intent(this, InCallActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
    }
    @Override public void onCallRemoved(Call call) {
        if (activeCall == call) activeCall = null;
        super.onCallRemoved(call);
    }
}
