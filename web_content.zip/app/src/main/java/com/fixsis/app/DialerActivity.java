package com.fixsis.app;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.telecom.TelecomManager;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;

public class DialerActivity extends Activity {
    private EditText number;
    @Override protected void onCreate(Bundle state) { super.onCreate(state);
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(24,48,24,24); box.setGravity(Gravity.CENTER); box.setBackgroundColor(0xff0f172a);
        number = new EditText(this); number.setTextColor(0xffffffff); number.setHintTextColor(0xff94a3b8); number.setHint("Telefon numarası"); number.setInputType(3);
        String initial = getDialedNumber(getIntent()); number.setText(initial); box.addView(number, new LinearLayout.LayoutParams(-1,-2));
        Button call = new Button(this); call.setText("Ara"); call.setOnClickListener(v -> placeCall()); box.addView(call, new LinearLayout.LayoutParams(-1,-2));
        Button back = new Button(this); back.setText("FixSis'e Dön"); back.setOnClickListener(v -> finish()); box.addView(back, new LinearLayout.LayoutParams(-1,-2)); setContentView(box);
    }
    private String getDialedNumber(android.content.Intent intent) {
        Uri data = intent == null ? null : intent.getData();
        return data == null ? "" : data.getSchemeSpecificPart();
    }
    @Override protected void onNewIntent(android.content.Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (number != null) number.setText(getDialedNumber(intent));
    }
    private void placeCall() { String value = number.getText().toString().trim(); if (value.isEmpty()) return;
        if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) { requestPermissions(new String[]{Manifest.permission.CALL_PHONE}, 301); return; }
        try { ((TelecomManager)getSystemService(TELECOM_SERVICE)).placeCall(Uri.fromParts("tel", value, null), new Bundle()); finish(); } catch (Exception e) { }
    }
    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) { super.onRequestPermissionsResult(requestCode, permissions, results); if (requestCode==301 && results.length>0 && results[0]==PackageManager.PERMISSION_GRANTED) placeCall(); }
}
