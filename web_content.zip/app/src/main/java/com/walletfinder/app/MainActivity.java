package com.walletfinder.app;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.webkit.CookieManager;
import android.graphics.Color;
import android.view.Window;

import androidx.webkit.WebViewAssetLoader;

public class MainActivity extends Activity {
    private static final int REQ_CAMERA = 1001;
    private WebView webView;
    private PermissionRequest pendingPermissionRequest;
    private WebViewAssetLoader assetLoader;


    /** Opens web links outside the WebView, preferably in Google Chrome.
     *  The activity is closed after the external browser is launched.
     */
    public class BrowserBridge {
        @JavascriptInterface
        public void openExternal(String url) {
            openInExternalBrowser(url);
        }
    }

    public class NetworkBridge {
        @JavascriptInterface
        public boolean isInternetAvailable() {
            try {
                ConnectivityManager cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
                if (cm == null) return false;
                // Check every available network. This is more reliable on devices
                // using VPNs, dual-SIM data, Wi-Fi + mobile data, or carrier-specific
                // routing. No country/region is inspected or blocked here.
                for (Network network : cm.getAllNetworks()) {
                    NetworkCapabilities caps = cm.getNetworkCapabilities(network);
                    if (caps == null || !caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) {
                        continue;
                    }
                    // VALIDATED means Android has confirmed actual Internet access.
                    if (caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)) {
                        return true;
                    }
                }
                return false;
            } catch (Exception e) {
                return false;
            }
        }
    }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        webView = new WebView(this);
        webView.setBackgroundColor(Color.BLACK);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);

        CookieManager.getInstance().setAcceptCookie(true);

        webView.addJavascriptInterface(new NetworkBridge(), "WalletFinderNative");
        webView.addJavascriptInterface(new BrowserBridge(), "WalletFinderBrowser");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleExternalUrl(url);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, android.webkit.WebResourceRequest request) {
                if (request == null) return false;
                return handleExternalUrl(request.getUrl().toString());
            }

            @Override
            public android.webkit.WebResourceResponse shouldInterceptRequest(WebView view, String url) {
                return assetLoader.shouldInterceptRequest(android.net.Uri.parse(url));
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        boolean wantsCamera = false;
                        for (String resource : request.getResources()) {
                            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource)) {
                                wantsCamera = true;
                                break;
                            }
                        }

                        if (!wantsCamera) {
                            request.deny();
                            return;
                        }

                        if (android.os.Build.VERSION.SDK_INT >= 23 &&
                                checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                            pendingPermissionRequest = request;
                            requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAMERA);
                        } else {
                            request.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
                        }
                    }
                });
            }
        });

        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html");
    }

    @Override protected void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == REQ_CAMERA) {
            PermissionRequest request = pendingPermissionRequest;
            pendingPermissionRequest = null;

            if (request == null) return;

            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                request.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
            } else {
                request.deny();
            }
        }
    }

    private boolean handleExternalUrl(String url) {
        try {
            if (url != null && url.startsWith("intent://")) {
                // Allow intent:// links from the HTML to launch the requested
                // external app/browser instead of trying to render them in WebView.
                Intent intent = Intent.parseUri(url, Intent.URI_INTENT_SCHEME);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                try {
                    startActivity(intent);
                    finishAndRemoveTask();
                } catch (Exception ignored) {
                    // If the requested package is unavailable, fall back to the
                    // ordinary HTTPS URL in an external browser.
                    openInExternalBrowser("https://t.me/Arinabediir");
                }
                return true;
            }

            Uri uri = Uri.parse(url);
            String scheme = uri.getScheme();
            // Keep the app's own local WebView page inside the app.
            if ("https".equalsIgnoreCase(scheme) || "http".equalsIgnoreCase(scheme)) {
                String host = uri.getHost();
                if (host != null && host.equalsIgnoreCase("appassets.androidplatform.net")) {
                    return false;
                }
                openInExternalBrowser(url);
                return true;
            }
        } catch (Exception ignored) {
        }
        return false;
    }

    private void openInExternalBrowser(String url) {
        if (url == null || url.trim().isEmpty()) return;
        try {
            Uri uri = Uri.parse(url.trim());
            String scheme = uri.getScheme();
            if (!"https".equalsIgnoreCase(scheme) && !"http".equalsIgnoreCase(scheme)) return;

            // Explicitly hand the URL to Chrome. This prevents the WebView from
            // rendering the page and makes Chrome receive the exact URL directly.
            Intent chrome = new Intent(Intent.ACTION_VIEW, uri);
            chrome.addCategory(Intent.CATEGORY_BROWSABLE);
            chrome.setPackage("com.android.chrome");

            boolean launched = false;
            try {
                startActivity(chrome);
                launched = true;
            } catch (Exception chromeUnavailable) {
                // Try other real browser apps, but never this WebView/activity.
                String[] browsers = new String[] {
                        "org.mozilla.firefox",
                        "com.microsoft.emmx",
                        "com.sec.android.app.sbrowser"
                };
                for (String pkg : browsers) {
                    try {
                        Intent browser = new Intent(Intent.ACTION_VIEW, uri);
                        browser.addCategory(Intent.CATEGORY_BROWSABLE);
                        browser.setPackage(pkg);
                        startActivity(browser);
                        launched = true;
                        break;
                    } catch (Exception ignored) { }
                }
            }

            if (launched) {
                // Remove Wallet Finder from the foreground/task immediately after
                // handing the exact URL to the external browser.
                if (android.os.Build.VERSION.SDK_INT >= 21) {
                    finishAndRemoveTask();
                } else {
                    finish();
                }
            }
        } catch (Exception ignored) {
            // No external browser available: keep the app intact.
        }
    }

    @Override public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (pendingPermissionRequest != null) {
            try { pendingPermissionRequest.deny(); } catch (Exception ignored) {}
            pendingPermissionRequest = null;
        }
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
