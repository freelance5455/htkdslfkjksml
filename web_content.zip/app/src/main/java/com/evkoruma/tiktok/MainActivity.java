package com.evkoruma.tiktok;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.JavascriptInterface;
import android.content.Intent;
import android.net.Uri;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.widget.Toast;

public class MainActivity extends Activity {
    private WebView web;
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Bridge(), "Android");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }
    public class Bridge {
        @JavascriptInterface public void openRouter() {
            runOnUiThread(() -> {
                try {
                    Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("http://192.168.1.1"));
                    startActivity(i);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Modem sayfası açılamadı", Toast.LENGTH_SHORT).show();
                }
            });
        }
        @JavascriptInterface public void copyDomains() {
            runOnUiThread(() -> {
                String domains = "tiktok.com\nwww.tiktok.com\nm.tiktok.com\ntiktokv.com\ntiktokcdn.com\nbyteoversea.com\nibytedtos.com\nmusical.ly";
                ClipboardManager cm = (ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
                cm.setPrimaryClip(ClipData.newPlainText("TikTok engel listesi", domains));
                Toast.makeText(MainActivity.this, "Adres listesi kopyalandı", Toast.LENGTH_SHORT).show();
            });
        }
    }
}
