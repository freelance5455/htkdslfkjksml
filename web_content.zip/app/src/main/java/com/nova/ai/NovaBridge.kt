package com.nova.ai

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.widget.Toast
import org.json.JSONObject
import java.util.Locale

class NovaBridge(private val activity: Activity) {
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var pendingText: String? = null
    private var recognizer: SpeechRecognizer? = null

    // JavascriptInterface methods run on a background thread, so everything
    // that touches UI, Toast, SpeechRecognizer or TTS goes through the main thread.
    private fun js(code: String) {
        activity.runOnUiThread {
            activity.findViewById<WebView>(R.id.webView)?.evaluateJavascript(code, null)
        }
    }

    private fun toast(msg: String) {
        activity.runOnUiThread { Toast.makeText(activity, msg, Toast.LENGTH_SHORT).show() }
    }

    private fun speakNow(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "nova")
    }

    @JavascriptInterface
    fun speakText(text: String) {
        activity.runOnUiThread {
            if (tts == null) {
                pendingText = text
                tts = TextToSpeech(activity) { status ->
                    if (status == TextToSpeech.SUCCESS) {
                        val r = tts?.setLanguage(Locale("bn", "BD"))
                        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                            tts?.language = Locale.US
                        }
                        tts?.setPitch(1.15f)
                        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                            override fun onStart(utteranceId: String?) {}
                            override fun onDone(utteranceId: String?) {
                                js("window.onSpeakDone && window.onSpeakDone()")
                            }
                            @Deprecated("Deprecated in Java")
                            override fun onError(utteranceId: String?) {
                                js("window.onSpeakDone && window.onSpeakDone()")
                            }
                        })
                        ttsReady = true
                        pendingText?.let { speakNow(it) }
                        pendingText = null
                    } else {
                        js("window.onSpeakDone && window.onSpeakDone()")
                    }
                }
            } else if (ttsReady) {
                speakNow(text)
            } else {
                pendingText = text
            }
        }
    }

    @JavascriptInterface
    fun stopSpeaking() {
        activity.runOnUiThread { tts?.stop() }
    }

    @JavascriptInterface
    fun openCamera() {
        activity.runOnUiThread {
            try {
                activity.startActivity(Intent(MediaStore.ACTION_IMAGE_CAPTURE))
            } catch (_: Exception) {
                toast("Camera unavailable")
            }
        }
    }

    @JavascriptInterface
    fun openSettings() {
        activity.runOnUiThread { activity.startActivity(Intent(Settings.ACTION_SETTINGS)) }
    }

    @JavascriptInterface
    fun dial(number: String) {
        activity.runOnUiThread {
            activity.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number")))
        }
    }

    @JavascriptInterface
    fun openUrl(url: String) {
        activity.runOnUiThread {
            try {
                activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            } catch (_: Exception) {
                toast("Cannot open")
            }
        }
    }

    @JavascriptInterface
    fun openApp(packageName: String) {
        activity.runOnUiThread {
            try {
                val intent = activity.packageManager.getLaunchIntentForPackage(packageName)
                if (intent != null) {
                    activity.startActivity(intent)
                } else {
                    activity.startActivity(
                        Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$packageName"))
                    )
                }
            } catch (_: Exception) {
                toast("App not installed")
            }
        }
    }

    // Opens ANY installed app by its name (as shown on the phone), e.g. "Calculator".
    @JavascriptInterface
    fun openAppByName(name: String) {
        activity.runOnUiThread {
            val pm = activity.packageManager
            val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val q = name.trim().lowercase()
            val hit = pm.queryIntentActivities(main, 0)
                .firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) }
            val launch = hit?.let { pm.getLaunchIntentForPackage(it.activityInfo.packageName) }
            if (launch != null) activity.startActivity(launch) else toast("App not found: $name")
        }
    }

    @JavascriptInterface
    fun startListening(lang: String) {
        activity.runOnUiThread {
            if (!SpeechRecognizer.isRecognitionAvailable(activity)) {
                toast("Speech recognition not available")
                js("window.onVoiceError && window.onVoiceError(-1)")
                return@runOnUiThread
            }

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            }

            recognizer?.destroy()
            recognizer = SpeechRecognizer.createSpeechRecognizer(activity)
            recognizer?.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onEvent(eventType: Int, params: Bundle?) {}

                override fun onError(error: Int) {
                    js("window.onVoiceError && window.onVoiceError($error)")
                }

                override fun onResults(results: Bundle?) {
                    val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull() ?: ""
                    js("window.onVoiceResult && window.onVoiceResult(${JSONObject.quote(text)})")
                }

                override fun onPartialResults(partialResults: Bundle?) {
                    val text = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull() ?: ""
                    js("window.onVoicePartial && window.onVoicePartial(${JSONObject.quote(text)})")
                }
            })
            recognizer?.startListening(intent)
        }
    }

    @JavascriptInterface
    fun stopListening() {
        activity.runOnUiThread { recognizer?.cancel() }
    }

    fun release() {
        tts?.shutdown()
        recognizer?.destroy()
    }
}
