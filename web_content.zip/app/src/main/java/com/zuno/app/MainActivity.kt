package com.zuno.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.*
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var web: WebView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        web = WebView(this)
        setContentView(web)
        web.settings.apply {
            javaScriptEnabled = true; domStorageEnabled = true; allowFileAccess = true
            mediaPlaybackRequiresUserGesture = false
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(r: PermissionRequest) { runOnUiThread { r.grant(r.resources) } }
        }
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(Bridge(), "Android")
        web.loadUrl("file:///android_asset/index.html")
        val need = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) need.add(Manifest.permission.POST_NOTIFICATIONS)
        requestPermissions(need.toTypedArray(), 1)
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Izinkan Zuno tampil di atas aplikasi lain agar bola Zuno muncul", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
    }

    // Saat Zuno dibuka lagi, bola dihapus. Saat Zuno ditinggalkan, bola muncul.
    override fun onStart() { super.onStart(); stopService(Intent(this, FloatingZunoService::class.java)) }
    override fun onStop() {
        super.onStop()
        if (!isChangingConfigurations && Settings.canDrawOverlays(this))
            startForegroundService(Intent(this, FloatingZunoService::class.java))
    }
    override fun onBackPressed() { if (web.canGoBack()) web.goBack() else super.onBackPressed() }

    inner class Bridge {
        @JavascriptInterface fun openApp(pkg: String) {
            val i = packageManager.getLaunchIntentForPackage(pkg)
            if (i != null) startActivity(i) else runOnUiThread { Toast.makeText(this@MainActivity, "Aplikasi belum terpasang", Toast.LENGTH_SHORT).show() }
        }
        @JavascriptInterface fun openInFloat(url: String) {
            if (Settings.canDrawOverlays(this@MainActivity))
                startForegroundService(Intent(this@MainActivity, FloatingZunoService::class.java).putExtra("url", url))
        }
    }
}
