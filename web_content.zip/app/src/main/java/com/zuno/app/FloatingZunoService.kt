package com.zuno.app

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.*
import android.webkit.*
import android.widget.*

const val ZUNO_URL = "file:///android_asset/index.html?mini=1"

class FloatingZunoService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var panel: LinearLayout? = null
    private var web: WebView? = null
    private val tabs = listOf("Zuno" to ZUNO_URL, "ChatGPT" to "https://chatgpt.com/", "Claude" to "https://claude.ai/", "Gemini" to "https://gemini.google.com/")

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val ch = "zuno_float"
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(ch, "Zuno mengambang", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, ch).setContentTitle("Zuno aktif").setSmallIcon(android.R.drawable.ic_dialog_info).build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) else startForeground(1, n)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        if (bubble == null) addBubble()
        val u = i?.getStringExtra("url")
        if (u != null) { if (panel == null) togglePanel(u) else web?.loadUrl(u) }
        return START_STICKY
    }

    private fun lp(w: Int, h: Int, focus: Boolean) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        if (focus) 0 else WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START; softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE }

    private fun addBubble() {
        val p = lp(150, 150, false).apply { x = 20; y = 400 }
        val b = TextView(this)
        b.text = "Z"; b.textSize = 22f; b.setTextColor(Color.WHITE); b.gravity = Gravity.CENTER
        b.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xFF5B7BFF.toInt()) }
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        b.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = p.x; sy = p.y; tx = e.rawX; ty = e.rawY; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    if (Math.abs(e.rawX - tx) > 12 || Math.abs(e.rawY - ty) > 12) moved = true
                    p.x = sx + (e.rawX - tx).toInt(); p.y = sy + (e.rawY - ty).toInt(); wm.updateViewLayout(v, p)
                }
                MotionEvent.ACTION_UP -> if (!moved) togglePanel(ZUNO_URL)
            }
            true
        }
        bubble = b; wm.addView(b, p)
    }

    inner class FloatBridge { @JavascriptInterface fun openInFloat(u: String) { web?.post { web?.loadUrl(u) } } }

    private fun togglePanel(start: String) {
        panel?.let { wm.removeView(it); panel = null; web?.destroy(); web = null; return }
        val m = resources.displayMetrics
        val col = LinearLayout(this); col.orientation = LinearLayout.VERTICAL; col.setBackgroundColor(0xFF0B0D12.toInt())
        val w = WebView(this)
        w.settings.javaScriptEnabled = true; w.settings.domStorageEnabled = true; w.settings.allowFileAccess = true
        w.settings.mediaPlaybackRequiresUserGesture = false
        w.settings.userAgentString = w.settings.userAgentString.replace("; wv", "")
        w.webViewClient = WebViewClient(); w.webChromeClient = WebChromeClient()
        w.addJavascriptInterface(FloatBridge(), "Android")
        w.loadUrl(start); web = w
        val bar = LinearLayout(this); bar.setBackgroundColor(0xFF151A25.toInt())
        tabs.forEach { (name, url) ->
            val t = TextView(this); t.text = name; t.setTextColor(Color.WHITE); t.textSize = 13f; t.setPadding(22, 18, 22, 18)
            t.setOnClickListener { w.loadUrl(url) }; bar.addView(t)
        }
        bar.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        val x = TextView(this); x.text = "✕"; x.setTextColor(Color.WHITE); x.textSize = 18f; x.setPadding(26, 12, 26, 12)
        x.setOnClickListener { togglePanel(ZUNO_URL) }; bar.addView(x)
        col.addView(bar, LinearLayout.LayoutParams(-1, -2))
        col.addView(w, LinearLayout.LayoutParams(-1, 0, 1f))
        val p = lp((m.widthPixels * 0.92).toInt(), (m.heightPixels * 0.6).toInt(), true).apply { x = (m.widthPixels * 0.04).toInt(); y = 120 }
        panel = col; wm.addView(col, p)
    }

    override fun onDestroy() {
        panel?.let { wm.removeView(it) }; bubble?.let { wm.removeView(it) }
        web?.destroy(); panel = null; bubble = null; web = null; super.onDestroy()
    }
}
