package com.stargullak.v4;

import android.app.Activity;
import android.os.Bundle;
import android.Manifest;
import android.webkit.*;

public class MainActivity extends Activity {
    WebView w;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        w = new WebView(this);
        setContentView(w);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        w.setWebViewClient(new WebViewClient());
        w.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(PermissionRequest r) {
                r.grant(r.getResources());
            }
        });
        requestPermissions(new String[]{Manifest.permission.CAMERA}, 100);
        w.loadUrl("file:///android_asset/index.html");
    }
    @Override public void onBackPressed() {
        if (w.canGoBack()) w.goBack(); else super.onBackPressed();
    }
}
