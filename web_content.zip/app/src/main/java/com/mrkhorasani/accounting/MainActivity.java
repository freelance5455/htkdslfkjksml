package com.mrkhorasani.accounting;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.util.Base64;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import androidx.annotation.Nullable;
import androidx.core.content.FileProvider;
import androidx.webkit.ServiceWorkerClientCompat;
import androidx.webkit.ServiceWorkerControllerCompat;
import androidx.webkit.ServiceWorkerWebSettingsCompat;
import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewClientCompat;
import androidx.webkit.WebViewFeature;

import org.json.JSONObject;

import java.io.OutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * Native Android shell for the existing MR, KHORASANI 2.11.3 web application.
 * The accounting application itself is served from packaged assets over the
 * HTTPS-like WebViewAssetLoader origin so local storage and service workers work.
 */
public final class MainActivity extends Activity {
    private static final String ASSET_HOST = "appassets.androidplatform.net";
    private static final String START_URL = "https://" + ASSET_HOST + "/assets/www/index.html";
    private static final int REQUEST_OPEN_FILE = 7101;
    private static final int REQUEST_SAVE_FILE = 7102;
    private static final long MAX_EXPORT_BYTES = 50L * 1024L * 1024L;

    private WebView webView;
    private WebViewAssetLoader assetLoader;
    private ValueCallback<Uri[]> fileChooserCallback;
    private PendingSave pendingSave;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        applySystemBars();

        assetLoader = new WebViewAssetLoader.Builder()
                .setDomain(ASSET_HOST)
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        // Register the service-worker client before creating/loading any WebView.
        configureServiceWorker();

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(7, 19, 38));

        webView = new WebView(this);
        root.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);
        applyEdgeToEdgeInsets(root);

        configureWebView();
        webView.loadUrl(START_URL);
    }

    private void applySystemBars() {
        Window window = getWindow();
        window.setStatusBarColor(Color.rgb(8, 26, 53));
        window.setNavigationBarColor(Color.rgb(7, 19, 38));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            window.setNavigationBarContrastEnforced(false);
            window.setStatusBarContrastEnforced(false);
        }
    }

    private void applyEdgeToEdgeInsets(View root) {
        // Android 15+ enforces edge-to-edge for apps targeting API 35+.
        if (Build.VERSION.SDK_INT >= 35) {
            root.setOnApplyWindowInsetsListener((view, insets) -> {
                android.graphics.Insets bars = insets.getInsets(
                        WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                view.setPadding(bars.left, bars.top, bars.right, bars.bottom);
                return insets;
            });
            root.requestApplyInsets();
        }
    }

    private void configureServiceWorker() {
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.SERVICE_WORKER_BASIC_USAGE)) {
            return;
        }

        ServiceWorkerControllerCompat controller = ServiceWorkerControllerCompat.getInstance();
        ServiceWorkerWebSettingsCompat settings = controller.getServiceWorkerWebSettings();
        if (WebViewFeature.isFeatureSupported(WebViewFeature.SERVICE_WORKER_FILE_ACCESS)) {
            settings.setAllowFileAccess(false);
        }
        if (WebViewFeature.isFeatureSupported(WebViewFeature.SERVICE_WORKER_CONTENT_ACCESS)) {
            settings.setAllowContentAccess(false);
        }
        if (WebViewFeature.isFeatureSupported(WebViewFeature.SERVICE_WORKER_BLOCK_NETWORK_LOADS)) {
            settings.setBlockNetworkLoads(false);
        }

        if (WebViewFeature.isFeatureSupported(WebViewFeature.SERVICE_WORKER_SHOULD_INTERCEPT_REQUEST)) {
            controller.setServiceWorkerClient(new ServiceWorkerClientCompat() {
                @Override
                public WebResourceResponse shouldInterceptRequest(WebResourceRequest request) {
                    return assetLoader.shouldInterceptRequest(request.getUrl());
                }
            });
        }
    }

    @SuppressWarnings("SetJavaScriptEnabled")
    private void configureWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setLoadsImagesAutomatically(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setTextZoom(100);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);

        CookieManager.getInstance().setAcceptCookie(true);
        webView.setBackgroundColor(Color.rgb(7, 19, 38));
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");

        webView.setWebViewClient(new WebViewClientCompat() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleNavigation(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleNavigation(Uri.parse(url));
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                installNativePrintHook(view);
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view,
                                             ValueCallback<Uri[]> filePathCallback,
                                             FileChooserParams fileChooserParams) {
                if (fileChooserCallback != null) {
                    fileChooserCallback.onReceiveValue(null);
                }
                fileChooserCallback = filePathCallback;

                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,
                        fileChooserParams != null && fileChooserParams.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE);
                try {
                    startActivityForResult(intent, REQUEST_OPEN_FILE);
                    return true;
                } catch (ActivityNotFoundException error) {
                    fileChooserCallback = null;
                    filePathCallback.onReceiveValue(null);
                    return false;
                }
            }
        });
    }

    private boolean handleNavigation(Uri uri) {
        if (uri == null) return true;
        if ("https".equalsIgnoreCase(uri.getScheme())
                && ASSET_HOST.equalsIgnoreCase(uri.getHost())
                && uri.getPath() != null
                && uri.getPath().startsWith("/assets/")) {
            return false;
        }

        // Keep remote pages outside the trusted local WebView origin.
        String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase();
        if ("https".equals(scheme) || "http".equals(scheme)
                || "tel".equals(scheme) || "mailto".equals(scheme)) {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, uri));
            } catch (ActivityNotFoundException ignored) {
                // No compatible external application is installed.
            }
        }
        return true;
    }

    private void installNativePrintHook(WebView view) {
        String js = "(function(){"
                + "if(window.__mrkNativePrintInstalled)return;"
                + "window.__mrkNativePrintInstalled=true;"
                + "window.print=function(){if(window.AndroidBridge&&window.AndroidBridge.printPage){window.AndroidBridge.printPage();}};"
                + "})();";
        view.evaluateJavascript(js, null);
    }

    private final class AndroidBridge {
        @JavascriptInterface
        public void saveFile(String requestId, String name, String mime, String base64Data) {
            if (requestId == null || base64Data == null || base64Data.length() > 70_000_000) {
                notifySaveResult(requestId, false, "حجم یا اطلاعات فایل خروجی معتبر نیست.");
                return;
            }

            final byte[] bytes;
            try {
                bytes = Base64.decode(base64Data, Base64.DEFAULT);
            } catch (IllegalArgumentException error) {
                notifySaveResult(requestId, false, "رمزگشایی فایل خروجی ناموفق بود.");
                return;
            }

            if (bytes.length > MAX_EXPORT_BYTES) {
                notifySaveResult(requestId, false, "حجم فایل از سقف مجاز ۵۰ مگابایت بیشتر است.");
                return;
            }

            runOnUiThread(() -> beginSaveDocument(requestId, name, mime, bytes));
        }

        @JavascriptInterface
        public void shareFile(String requestId, String name, String mime, String base64Data,
                              String subject, String recipient) {
            if (base64Data == null || base64Data.length() > 70_000_000) return;
            final byte[] bytes;
            try {
                bytes = Base64.decode(base64Data, Base64.DEFAULT);
            } catch (IllegalArgumentException error) {
                return;
            }
            if (bytes.length > MAX_EXPORT_BYTES) return;
            runOnUiThread(() -> beginShareFile(name, mime, subject, recipient, bytes));
        }

        @JavascriptInterface
        public void printPage() {
            runOnUiThread(() -> {
                if (webView == null || isFinishing()) return;
                PrintManager printManager = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                if (printManager == null) return;
                String jobName = "MR, KHORASANI";
                printManager.print(jobName, webView.createPrintDocumentAdapter(jobName),
                        new PrintAttributes.Builder().build());
            });
        }
    }

    private void beginShareFile(String name, String mime, String subject, String recipient, byte[] bytes) {
        if (isFinishing()) return;
        try {
            File folder = new File(getCacheDir(), "shared");
            if (!folder.exists() && !folder.mkdirs()) throw new IllegalStateException("پوشه موقت پیوست ساخته نشد.");
            File target = new File(folder, sanitizeFileName(name));
            try (FileOutputStream output = new FileOutputStream(target)) {
                output.write(bytes);
                output.flush();
            }
            Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", target);
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType((mime == null || mime.trim().isEmpty()) ? "application/octet-stream" : mime.trim());
            send.putExtra(Intent.EXTRA_EMAIL, new String[]{"mrkhorasani8888@gmail.com"});
            send.putExtra(Intent.EXTRA_SUBJECT, subject == null || subject.trim().isEmpty() ? "پشتیبان MR,KHORASANI" : subject);
            send.putExtra(Intent.EXTRA_TEXT, "فایل پشتیبان سامانه MR,KHORASANI");
            send.putExtra(Intent.EXTRA_STREAM, uri);
            send.setClipData(ClipData.newUri(getContentResolver(), "پیوست پشتیبان MR,KHORASANI", uri));
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(send, "ارسال پشتیبان با ایمیل"));
        } catch (Exception error) {
            android.widget.Toast.makeText(this, "آماده‌سازی پیوست ناموفق بود: " + error.getMessage(), android.widget.Toast.LENGTH_LONG).show();
        }
    }

    private void beginSaveDocument(String requestId, String name, String mime, byte[] bytes) {
        if (pendingSave != null) {
            notifySaveResult(requestId, false, "یک عملیات ذخیره‌سازی دیگر هنوز باز است.");
            return;
        }

        String safeName = sanitizeFileName(name);
        String safeMime = (mime == null || mime.trim().isEmpty())
                ? "application/octet-stream" : mime.trim();
        pendingSave = new PendingSave(requestId, safeName, safeMime, bytes);

        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType(safeMime);
        intent.putExtra(Intent.EXTRA_TITLE, safeName);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        try {
            startActivityForResult(intent, REQUEST_SAVE_FILE);
        } catch (ActivityNotFoundException error) {
            pendingSave = null;
            notifySaveResult(requestId, false, "ابزار انتخاب محل ذخیره فایل در گوشی پیدا نشد.");
        }
    }

    private String sanitizeFileName(String input) {
        String name = input == null ? "MR-KHORASANI-export" : input;
        name = name.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]", "_").trim();
        if (name.isEmpty()) name = "MR-KHORASANI-export";
        return name.length() > 140 ? name.substring(0, 140) : name;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_OPEN_FILE) {
            if (fileChooserCallback != null) {
                Uri[] results = null;
                if (resultCode == RESULT_OK && data != null) {
                    if (data.getClipData() != null) {
                        int count = data.getClipData().getItemCount();
                        List<Uri> picked = new ArrayList<>(count);
                        for (int i = 0; i < count; i++) {
                            Uri uri = data.getClipData().getItemAt(i).getUri();
                            if (uri != null) picked.add(uri);
                        }
                        results = picked.toArray(new Uri[0]);
                    } else if (data.getData() != null) {
                        results = new Uri[]{data.getData()};
                    }
                }
                fileChooserCallback.onReceiveValue(results);
                fileChooserCallback = null;
            }
            return;
        }

        if (requestCode == REQUEST_SAVE_FILE) {
            PendingSave save = pendingSave;
            pendingSave = null;
            if (save == null) return;

            if (resultCode != RESULT_OK || data == null || data.getData() == null) {
                notifySaveResult(save.requestId, false, "ذخیره فایل لغو شد.");
                return;
            }

            try (OutputStream output = getContentResolver().openOutputStream(data.getData(), "w")) {
                if (output == null) throw new IllegalStateException("مسیر ذخیره‌سازی باز نشد.");
                output.write(save.bytes);
                output.flush();
                notifySaveResult(save.requestId, true, "فایل در مسیر انتخاب‌شده ذخیره شد.");
            } catch (Exception error) {
                notifySaveResult(save.requestId, false, "ذخیره فایل ناموفق بود: " + error.getMessage());
            }
        }
    }

    private void notifySaveResult(String requestId, boolean success, String message) {
        if (requestId == null || webView == null) return;
        String js = "if(window.MRKNativeFileResult){window.MRKNativeFileResult("
                + JSONObject.quote(requestId) + "," + success + "," + JSONObject.quote(message) + ");}";
        webView.post(() -> webView.evaluateJavascript(js, null));
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (fileChooserCallback != null) {
            fileChooserCallback.onReceiveValue(null);
            fileChooserCallback = null;
        }
        if (webView != null) {
            webView.removeJavascriptInterface("AndroidBridge");
            webView.stopLoading();
            webView.loadUrl("about:blank");
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }

    private static final class PendingSave {
        final String requestId;
        final String name;
        final String mime;
        final byte[] bytes;

        PendingSave(String requestId, String name, String mime, byte[] bytes) {
            this.requestId = requestId;
            this.name = name;
            this.mime = mime;
            this.bytes = bytes;
        }
    }
}
