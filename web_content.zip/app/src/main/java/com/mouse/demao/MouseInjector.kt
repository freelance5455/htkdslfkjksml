package com.mouse.demao

import android.content.pm.PackageManager
import android.os.IBinder
import android.os.SystemClock
import android.view.InputDevice
import android.view.InputEvent
import android.view.MotionEvent
import org.lsposed.hiddenapibypass.HiddenApiBypass
import rikka.shizuku.Shizuku
import rikka.shizuku.ShizukuBinderWrapper
import rikka.shizuku.SystemServiceHelper
import java.lang.reflect.Method
import java.util.concurrent.Executors

/** Injeta eventos de mouse REAIS no sistema Android (via Shizuku), como se houvesse um mouse conectado. */
object MouseInjector {
    const val PRIMARY = MotionEvent.BUTTON_PRIMARY
    const val SECONDARY = MotionEvent.BUTTON_SECONDARY

    private var im: Any? = null
    private var inject: Method? = null
    private var cached = false
    private var lastCheck = 0L
    private var downTime = 0L
    private val ex = Executors.newSingleThreadExecutor()

    fun refresh(): Boolean { lastCheck = 0; return isReady() }

    fun isReady(): Boolean {
        val t = SystemClock.uptimeMillis()
        if (t - lastCheck > 2000) {
            lastCheck = t
            cached = try {
                Shizuku.pingBinder() &&
                    Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED &&
                    init()
            } catch (e: Throwable) { im = null; false }
        }
        return cached
    }

    private fun init(): Boolean {
        if (im != null) return true
        HiddenApiBypass.addHiddenApiExemptions("L")
        val binder = ShizukuBinderWrapper(SystemServiceHelper.getSystemService("input"))
        val stub = Class.forName("android.hardware.input.IInputManager\$Stub")
        im = stub.getMethod("asInterface", IBinder::class.java).invoke(null, binder)
        inject = Class.forName("android.hardware.input.IInputManager")
            .getMethod("injectInputEvent", InputEvent::class.java, Int::class.javaPrimitiveType)
        return true
    }

    fun hover(x: Float, y: Float) = send(MotionEvent.ACTION_HOVER_MOVE, x, y, 0)
    fun down(x: Float, y: Float, button: Int) = send(MotionEvent.ACTION_DOWN, x, y, button)
    fun move(x: Float, y: Float, button: Int) = send(MotionEvent.ACTION_MOVE, x, y, button)
    fun up(x: Float, y: Float) = send(MotionEvent.ACTION_UP, x, y, 0)

    private fun send(action: Int, x: Float, y: Float, buttons: Int) {
        ex.execute {
            try {
                val now = SystemClock.uptimeMillis()
                if (action == MotionEvent.ACTION_DOWN) downTime = now
                val dt = if (action == MotionEvent.ACTION_HOVER_MOVE) now else downTime
                val props = arrayOf(MotionEvent.PointerProperties().apply {
                    id = 0; toolType = MotionEvent.TOOL_TYPE_MOUSE
                })
                val coords = arrayOf(MotionEvent.PointerCoords().apply {
                    this.x = x; this.y = y; pressure = if (buttons != 0) 1f else 0f; size = 1f
                })
                val ev = MotionEvent.obtain(
                    dt, now, action, 1, props, coords, 0, buttons, 1f, 1f, 0, 0,
                    InputDevice.SOURCE_MOUSE, 0
                )
                inject!!.invoke(im, ev, 0)
                ev.recycle()
            } catch (e: Throwable) { im = null; cached = false }
        }
    }
}
