package com.mouse.demao

import android.content.Context

/** Ajustes do usuário (sensibilidade e suavização), compartilhados entre a tela e o serviço. */
object Prefs {
    @Volatile var sens = 1.7f     // 1.0 .. 3.0  (quanto maior, menos precisa mexer a mão)
    @Volatile var smooth = 0.4f   // 0 .. 1      (quanto maior, mais suave e mais lento)

    fun load(c: Context) {
        val p = c.getSharedPreferences("mao", Context.MODE_PRIVATE)
        sens = p.getFloat("sens", 1.7f)
        smooth = p.getFloat("smooth", 0.4f)
    }

    fun save(c: Context) {
        c.getSharedPreferences("mao", Context.MODE_PRIVATE).edit()
            .putFloat("sens", sens).putFloat("smooth", smooth).apply()
    }
}
