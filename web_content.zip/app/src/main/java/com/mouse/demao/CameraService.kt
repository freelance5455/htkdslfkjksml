package com.mouse.demao

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.SystemClock
import android.util.Size
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import java.io.File
import java.net.URL
import java.nio.ByteBuffer
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/** Serviço em primeiro plano: mantém a câmera e o rastreamento rodando com outros apps abertos. */
class CameraService : LifecycleService() {

    companion object {
        @Volatile var running = false
        private const val MODEL_NAME = "hand_landmarker.task"
        private const val MODEL_URL =
            "https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task"
    }

    private lateinit var executor: ExecutorService
    private var landmarker: HandLandmarker? = null
    private var lastTs = 0L

    override fun onCreate() {
        super.onCreate()
        running = true
        startAsForeground()
        executor = Executors.newSingleThreadExecutor()
        Thread {
            try {
                val options = HandLandmarker.HandLandmarkerOptions.builder()
                    .setBaseOptions(BaseOptions.builder().setModelAssetBuffer(loadModel()).build())
                    .setRunningMode(RunningMode.LIVE_STREAM)   // assíncrono: bem menos atraso
                    .setNumHands(1)
                    .setMinHandDetectionConfidence(0.5f)
                    .setMinHandPresenceConfidence(0.5f)
                    .setMinTrackingConfidence(0.5f)
                    .setResultListener { result, _ ->
                        val hand = result.landmarks().firstOrNull()?.map { floatArrayOf(it.x(), it.y()) }
                        HandMouseService.instance?.onHand(hand)
                    }
                    .setErrorListener { }
                    .build()
                landmarker = HandLandmarker.createFromOptions(this, options)
                ContextCompat.getMainExecutor(this).execute { startCamera() }
            } catch (e: Exception) {
                stopSelf()
            }
        }.start()
    }

    /** Usa o modelo embutido no app, ou baixa uma vez (precisa de internet na primeira vez). */
    private fun loadModel(): ByteBuffer {
        val bytes: ByteArray = if (assets.list("")?.contains(MODEL_NAME) == true) {
            assets.open(MODEL_NAME).use { it.readBytes() }
        } else {
            val f = File(filesDir, MODEL_NAME)
            if (!f.exists() || f.length() < 1_000_000) {
                val tmp = File(filesDir, "model.tmp")
                URL(MODEL_URL).openStream().use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
                tmp.renameTo(f)
            }
            f.readBytes()
        }
        return ByteBuffer.allocateDirect(bytes.size).put(bytes).also { it.rewind() }
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val analysis = ImageAnalysis.Builder()
                .setTargetResolution(Size(480, 640))           // imagem menor = processa mais rápido
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                .build()
            analysis.setAnalyzer(executor) { analyze(it) }
            provider.unbindAll()
            provider.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, analysis)
        }, ContextCompat.getMainExecutor(this))
    }

    private fun analyze(proxy: ImageProxy) {
        try {
            val ts = SystemClock.uptimeMillis()
            if (ts <= lastTs) return
            lastTs = ts
            val bmp = proxy.toBitmap()
            val m = android.graphics.Matrix().apply { postRotate(proxy.imageInfo.rotationDegrees.toFloat()) }
            val upright = android.graphics.Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            landmarker?.detectAsync(BitmapImageBuilder(upright).build(), ts)
        } catch (_: Exception) {
        } finally {
            proxy.close()
        }
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("mao", "Mouse de Mão", NotificationManager.IMPORTANCE_LOW))
        val n: Notification = NotificationCompat.Builder(this, "mao")
            .setContentTitle("Mouse de Mão ativo")
            .setContentText("Rastreando sua mão")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA)
        } else {
            startForeground(1, n)
        }
    }

    override fun onDestroy() {
        running = false
        HandMouseService.instance?.onHand(null)
        landmarker?.close()
        executor.shutdown()
        super.onDestroy()
    }
}
