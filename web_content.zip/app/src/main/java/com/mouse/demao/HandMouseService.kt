package com.mouse.demao

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import kotlin.math.hypot

/** Desenha o cursor por cima de tudo e executa cliques/arrastos no sistema. */
class HandMouseService : AccessibilityService() {

    companion object {
        @Volatile var instance: HandMouseService? = null
        private const val ON = 0.25f        // pinça fechada
        private const val OFF = 0.33f       // pinça aberta
        private const val DRAG_PX = 35f     // quanto mover com a pinça fechada para virar arrasto
        private const val DRAG_MS = 350L    // quanto tempo segurar para virar arrasto/toque longo
    }

    private val main = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private lateinit var cursor: View
    private lateinit var bg: GradientDrawable
    private lateinit var lp: WindowManager.LayoutParams
    private var sw = 0; private var sh = 0; private var size = 0

    private var x = 0f; private var y = 0f
    private var pinching = false
    private var rightHeld = false
    private var pinchT = 0L
    private var startX = 0f; private var startY = 0f
    private var realPress = false
    private var realRight = false
    private var dragActive = false

    override fun onServiceConnected() {
        instance = this
        Prefs.load(this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val dm = resources.displayMetrics
        sw = dm.widthPixels; sh = dm.heightPixels
        size = (34 * dm.density).toInt()
        x = sw / 2f; y = sh / 2f
        bg = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setStroke((3 * dm.density).toInt(), Color.WHITE)
            setColor(0x663EA6FF)
        }
        cursor = View(this).apply { background = bg; visibility = View.GONE }
        lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        wm.addView(cursor, lp)
    }

    /** Chamado pela câmera. Pontos normalizados (0..1) ou null se não há mão. */
    fun onHand(h: List<FloatArray>?) {
        main.post { handle(h) }
    }

    private fun setCursorState(state: Int) {
        val (color, scale) = when (state) {
            1 -> 0xCC3DDC84.toInt() to 0.75f   // botão esquerdo apertado
            2 -> 0xCCFF6B6B.toInt() to 0.75f   // botão direito apertado
            else -> 0x663EA6FF to 1f
        }
        bg.setColor(color)
        cursor.animate().scaleX(scale).scaleY(scale).setDuration(70).start()
    }

    private fun releaseAll() {
        if (pinching) {
            if (realPress) MouseInjector.up(x, y) else if (dragActive) endDrag()
        }
        if (rightHeld && realRight) MouseInjector.up(x, y)
        pinching = false; rightHeld = false
        realPress = false; realRight = false; dragActive = false
        setCursorState(0)
    }

    private fun handle(h: List<FloatArray>?) {
        if (!::cursor.isInitialized) return
        if (h == null || h.size < 21) {
            cursor.visibility = View.GONE
            releaseAll()
            return
        }
        cursor.visibility = View.VISIBLE

        val handSize = dist(h[0], h[9])
        val pl = dist(h[4], h[8]) / handSize   // polegar–indicador
        val pr = dist(h[4], h[12]) / handSize  // polegar–médio

        // alvo do cursor = base do indicador (ponto 5), espelhado
        val p = h[5]
        val tx = (sw * (0.5f + (0.5f - p[0]) * Prefs.sens)).coerceIn(0f, sw.toFloat())
        val ty = (sh * (0.5f + (p[1] - 0.5f) * Prefs.sens)).coerceIn(0f, sh.toFloat())

        val gap = hypot(tx - x, ty - y)
        val a = (0.85f - 0.6f * Prefs.smooth + gap / 400f).coerceAtMost(0.95f)
        x += (tx - x) * a
        y += (ty - y) * a
        lp.x = (x - size / 2).toInt(); lp.y = (y - size / 2).toInt()
        wm.updateViewLayout(cursor, lp)

        val now = SystemClock.uptimeMillis()

        // ---- botão esquerdo ----
        if (!pinching && !stroking && !rightHeld && pl < ON && pr > OFF) {
            pinching = true; pinchT = now; startX = x; startY = y; dragActive = false
            setCursorState(1)
            if (MouseInjector.isReady()) { realPress = true; MouseInjector.down(x, y, MouseInjector.PRIMARY) }
        } else if (pinching && pl > OFF) {
            pinching = false
            setCursorState(0)
            if (realPress) { realPress = false; MouseInjector.up(x, y) }
            else if (dragActive) { dragActive = false; endDrag() }
            else tap(startX, startY)                       // pinça rápida = clique
        } else if (pinching && !realPress && !dragActive &&
            (now - pinchT > DRAG_MS || hypot(x - startX, y - startY) > DRAG_PX)) {
            dragActive = true                               // segurou ou moveu = arrastar
            beginDrag(startX, startY)
        }

        // ---- botão direito ----
        if (!rightHeld && !pinching && pr < ON && pl > OFF) {
            rightHeld = true
            setCursorState(2)
            if (MouseInjector.isReady()) { realRight = true; MouseInjector.down(x, y, MouseInjector.SECONDARY) }
            else performGlobalAction(GLOBAL_ACTION_BACK)
        } else if (rightHeld && pr > OFF) {
            rightHeld = false
            setCursorState(0)
            if (realRight) { realRight = false; MouseInjector.up(x, y) }
        }

        // ---- modo mouse real: posição o tempo todo (hover quando nenhum botão está apertado) ----
        if (MouseInjector.isReady()) {
            when {
                realPress -> MouseInjector.move(x, y, MouseInjector.PRIMARY)
                realRight -> MouseInjector.move(x, y, MouseInjector.SECONDARY)
                else -> MouseInjector.hover(x, y)
            }
        }
    }

    private fun dist(a: FloatArray, b: FloatArray) = hypot(a[0] - b[0], a[1] - b[1]).coerceAtLeast(0.0001f)

    // ---- clique rápido ----
    private fun tap(px: Float, py: Float) {
        val path = Path().apply { moveTo(px, py) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 40)).build()
        dispatchGesture(g, null, null)
    }

    // ---- arrasto em tempo real: dedo "virtual" desce, acompanha o cursor e sobe ao soltar ----
    private var stroking = false
    private var endRequested = false
    private var inFlight = false
    private var lastStroke: GestureDescription.StrokeDescription? = null
    private var lastX = 0f
    private var lastY = 0f

    private fun send(stroke: GestureDescription.StrokeDescription, onDone: () -> Unit): Boolean {
        val g = GestureDescription.Builder().addStroke(stroke).build()
        return dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { onDone() }
            override fun onCancelled(d: GestureDescription?) { stroking = false; inFlight = false }
        }, main)
    }

    private fun beginDrag(x0: Float, y0: Float) {
        stroking = true; endRequested = false; inFlight = true
        lastX = x0; lastY = y0
        val s = GestureDescription.StrokeDescription(Path().apply { moveTo(lastX, lastY) }, 0, 10, true)
        val ok = send(s) { lastStroke = s; inFlight = false; pump() }
        if (!ok) { stroking = false; inFlight = false }
    }

    private fun endDrag() {
        endRequested = true
        if (!inFlight) pump()
    }

    private fun pump() {
        val prev = lastStroke ?: return
        if (!stroking || inFlight) return
        val tx = x; val ty = y
        val last = endRequested
        val path = Path().apply { moveTo(lastX, lastY); if (tx != lastX || ty != lastY) lineTo(tx, ty) }
        val next = prev.continueStroke(path, 0, 30, !last)
        inFlight = true
        val ok = send(next) {
            lastStroke = next; lastX = tx; lastY = ty; inFlight = false
            if (last) stroking = false else pump()
        }
        if (!ok) { stroking = false; inFlight = false }
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        instance = null
        if (::cursor.isInitialized) try { wm.removeView(cursor) } catch (_: Exception) {}
        return super.onUnbind(intent)
    }
}
