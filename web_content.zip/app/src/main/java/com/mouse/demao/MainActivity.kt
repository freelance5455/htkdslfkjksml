package com.mouse.demao

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import rikka.shizuku.Shizuku

class MainActivity : ComponentActivity() {

    private val cBg = 0xFF0B0F14.toInt()
    private val cCard = 0xFF151C25.toInt()
    private val cFg = 0xFFE8EEF5.toInt()
    private val cMuted = 0xFF8A97A8.toInt()
    private val cAccent = 0xFF3EA6FF.toInt()
    private val cOk = 0xFF3DDC84.toInt()
    private val cOff = 0xFF5B6675.toInt()
    private val cDanger = 0xFFFF6B6B.toInt()
    private val cBtn2 = 0xFF1E2833.toInt()
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    class Row(val dot: View, val value: TextView)

    private lateinit var rowAcc: Row
    private lateinit var rowReal: Row
    private lateinit var rowCam: Row
    private lateinit var toggle: Button
    private val ui = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() { updateStatus(); ui.postDelayed(this, 800) }
    }

    private val askPerms = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { granted ->
        if (granted[Manifest.permission.CAMERA] == true) {
            ContextCompat.startForegroundService(this, Intent(this, CameraService::class.java))
        }
    }

    private val shizukuListener = Shizuku.OnRequestPermissionResultListener { _, _ -> runOnUiThread { updateStatus() } }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, r: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(r).toFloat()
    }

    private fun text(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun card(parent: LinearLayout, title: String): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(16))
            background = rounded(cCard, 22)
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(14) }
        }
        c.addView(text(title, 13f, cMuted, true).apply { setPadding(0, 0, 0, dp(6)) })
        parent.addView(c)
        return c
    }

    private fun row(parent: LinearLayout, label: String): Row {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(7), 0, dp(7))
        }
        val dot = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(10), dp(10)).apply { rightMargin = dp(12) }
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(cOff) }
        }
        val name = text(label, 15f, cFg).apply { layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f) }
        val value = text("", 14f, cMuted)
        r.addView(dot); r.addView(name); r.addView(value)
        parent.addView(r)
        return Row(dot, value)
    }

    private fun setRow(r: Row, on: Boolean, onText: String, offText: String) {
        (r.dot.background as GradientDrawable).setColor(if (on) cOk else cOff)
        r.value.text = if (on) onText else offText
        r.value.setTextColor(if (on) cOk else cMuted)
    }

    private fun btn(label: String, primary: Boolean, click: () -> Unit) = Button(this).apply {
        text = label; isAllCaps = false; textSize = 16f
        setTextColor(if (primary) 0xFF001018.toInt() else cFg)
        stateListAnimator = null
        background = rounded(if (primary) cAccent else cBtn2, 16)
        layoutParams = LinearLayout.LayoutParams(MATCH, dp(54)).apply { topMargin = dp(10) }
        setOnClickListener { click() }
    }

    private fun slider(parent: LinearLayout, title: String, hint: String, start: Int, onChange: (Int) -> Unit) {
        parent.addView(text(title, 15f, cFg, true).apply { setPadding(0, dp(8), 0, 0) })
        parent.addView(text(hint, 12f, cMuted))
        parent.addView(SeekBar(this).apply {
            max = 100; progress = start
            progressTintList = ColorStateList.valueOf(cAccent)
            thumbTintList = ColorStateList.valueOf(cAccent)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { if (fromUser) onChange(p) }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) { Prefs.save(this@MainActivity) }
            })
        })
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.load(this)
        Shizuku.addRequestPermissionResultListener(shizukuListener)
        window.statusBarColor = cBg
        window.navigationBarColor = cBg

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(28))
        }

        // cabeçalho
        root.addView(text("🖐️  Mouse de Mão", 28f, cFg, true))
        root.addView(text("Controle o celular só com a sua mão", 14f, cMuted).apply { setPadding(0, dp(4), 0, 0) })

        // status
        val st = card(root, "STATUS")
        rowAcc = row(st, "Acessibilidade")
        rowReal = row(st, "Mouse real (Shizuku)")
        rowCam = row(st, "Câmera")

        // ações
        toggle = btn("▶  Iniciar", true) { toggleCamera() }
        root.addView(toggle.apply { (layoutParams as LinearLayout.LayoutParams).topMargin = dp(16) })
        root.addView(btn("Ativar acessibilidade", false) { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        root.addView(btn("Ativar mouse real (Shizuku)", false) { askShizuku() })

        // ajustes
        val adj = card(root, "AJUSTES")
        slider(adj, "Sensibilidade", "Quanto mais alta, menos você precisa mexer a mão",
            ((Prefs.sens - 1f) / 2f * 100).toInt()) { Prefs.sens = 1f + it / 100f * 2f }
        slider(adj, "Suavização", "Mais suave treme menos, mas responde mais devagar",
            (Prefs.smooth * 100).toInt()) { Prefs.smooth = it / 100f }

        // gestos
        val g = card(root, "GESTOS")
        g.addView(text("👆  Base do indicador: move o cursor", 14f, cFg).apply { setPadding(0, dp(4), 0, dp(4)) })
        g.addView(text("🤏  Indicador + polegar: clique esquerdo (segure para arrastar)", 14f, cFg).apply { setPadding(0, dp(4), 0, dp(4)) })
        g.addView(text("🤌  Médio + polegar: clique direito", 14f, cFg).apply { setPadding(0, dp(4), 0, dp(4)) })

        setContentView(ScrollView(this).apply {
            setBackgroundColor(cBg)
            isFillViewport = true
            addView(root)
        })
    }

    private fun toggleCamera() {
        if (CameraService.running) {
            stopService(Intent(this, CameraService::class.java))
        } else {
            val perms = mutableListOf(Manifest.permission.CAMERA)
            if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
            askPerms.launch(perms.toTypedArray())
        }
        ui.postDelayed({ updateStatus() }, 400)
    }

    private fun askShizuku() {
        try {
            if (!Shizuku.pingBinder()) {
                packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")?.let { startActivity(it) }
            } else if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                Shizuku.requestPermission(100)
            }
        } catch (_: Throwable) {}
        updateStatus()
    }

    private fun updateStatus() {
        setRow(rowAcc, HandMouseService.instance != null, "Ativa", "Desativada")
        setRow(rowReal, MouseInjector.refresh(), "Ativo", "Inativo")
        val cam = CameraService.running
        setRow(rowCam, cam, "Rodando", "Parada")
        toggle.text = if (cam) "■  Parar" else "▶  Iniciar"
        toggle.background = rounded(if (cam) cDanger else cAccent, 16)
    }

    override fun onResume() { super.onResume(); ui.post(ticker) }
    override fun onPause() { ui.removeCallbacks(ticker); super.onPause() }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(shizukuListener)
        super.onDestroy()
    }
}
