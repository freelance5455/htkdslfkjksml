package com.fuego.bruno;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
public class MainActivity extends Activity {
 protected void onCreate(Bundle b){super.onCreate(b); WebView w=new WebView(this); WebSettings s=w.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); w.setVerticalScrollBarEnabled(false); w.setHorizontalScrollBarEnabled(false); w.loadUrl("file:///android_asset/index.html"); setContentView(w);}
}