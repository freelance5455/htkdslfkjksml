package com.fanradar.app;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Iterator;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Puente JS -> Android: HTTPS sin restricciones CORS, portapapeles y abrir el navegador. Solo hosts de Google, Reddit y Meta. */
public class NativeBridge {
    private static final int MAX_BYTES = 8 * 1024 * 1024;
    /** Páginas que la app puede abrir en el navegador (inicios de sesión, perfiles y búsquedas de redes). */
    private static final java.util.Set<String> OPENABLE_HOSTS = new java.util.HashSet<>(java.util.Arrays.asList(
            "accounts.google.com", "www.google.com", "google.com",
            "www.reddit.com", "reddit.com",
            "developers.facebook.com", "www.facebook.com", "m.facebook.com", "facebook.com",
            "www.instagram.com", "instagram.com",
            "www.tiktok.com", "tiktok.com",
            "www.youtube.com", "m.youtube.com", "youtube.com"));
    private final Context context;
    private final WebView web;
    /** Enlace de retorno OAuth pendiente de entregar a la página. */
    public volatile String pendingOAuth = null;
    private final ExecutorService pool = Executors.newFixedThreadPool(4);

    public NativeBridge(Context context, WebView web) {
        this.context = context;
        this.web = web;
    }

    private static boolean allowed(URL u) {
        if (!"https".equals(u.getProtocol())) return false;
        String h = u.getHost().toLowerCase();
        return h.equals("www.googleapis.com") || h.equals("oauth2.googleapis.com")
                || h.equals("www.reddit.com") || h.equals("oauth.reddit.com")
                || h.equals("graph.facebook.com");
    }

    private static boolean openable(Uri u) {
        if (u == null || !"https".equals(u.getScheme()) || u.getHost() == null) return false;
        String h = u.getHost().toLowerCase();
        return OPENABLE_HOSTS.contains(h);
    }

    /** Abre en el navegador solo páginas de la lista OPENABLE_HOSTS. */
    @JavascriptInterface
    public void open(String url) {
        Uri u = Uri.parse(url);
        if (!openable(u)) return;
        Intent i = new Intent(Intent.ACTION_VIEW, u);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            context.startActivity(i);
        } catch (Exception ignored) {
        }
    }

    /** Entrega (una sola vez) el enlace fanradar://reddit?code=... recibido por la app. */
    @JavascriptInterface
    public String takePendingOAuth() {
        String p = pendingOAuth;
        pendingOAuth = null;
        return p == null ? "" : p;
    }

    @JavascriptInterface
    public void copy(String text) {
        ClipboardManager cm = (ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("FanRadar", text));
    }

    @JavascriptInterface
    public void request(final String id, final String method, final String url, final String headersJson, final String body) {
        pool.execute(() -> {
            int status = 0;
            String resp = "";
            String err = null;
            HttpURLConnection c = null;
            try {
                URL u = new URL(url);
                if (!allowed(u)) throw new SecurityException("Host no permitido: " + u.getHost());
                c = (HttpURLConnection) u.openConnection();
                c.setRequestMethod(method);
                c.setConnectTimeout(20000);
                c.setReadTimeout(30000);
                c.setRequestProperty("User-Agent", "fanradar/1.0 (android; fan discovery for independent bands)");
                JSONObject h = new JSONObject(headersJson);
                Iterator<String> keys = h.keys();
                while (keys.hasNext()) {
                    String k = keys.next();
                    c.setRequestProperty(k, h.getString(k));
                }
                if (body != null && !body.isEmpty()) {
                    c.setDoOutput(true);
                    try (OutputStream os = c.getOutputStream()) {
                        os.write(body.getBytes(StandardCharsets.UTF_8));
                    }
                }
                status = c.getResponseCode();
                InputStream is = status >= 400 ? c.getErrorStream() : c.getInputStream();
                if (is != null) {
                    ByteArrayOutputStream bo = new ByteArrayOutputStream();
                    byte[] buf = new byte[8192];
                    int n;
                    while ((n = is.read(buf)) > 0) {
                        bo.write(buf, 0, n);
                        if (bo.size() > MAX_BYTES) throw new java.io.IOException("Respuesta demasiado grande");
                    }
                    is.close();
                    resp = new String(bo.toByteArray(), StandardCharsets.UTF_8);
                }
            } catch (Exception e) {
                err = e.toString();
            } finally {
                if (c != null) c.disconnect();
            }
            final String js = "window.__nativeHttpDone(" + JSONObject.quote(id) + "," + status + ","
                    + JSONObject.quote(resp) + "," + (err == null ? "null" : JSONObject.quote(err)) + ")";
            web.post(() -> web.evaluateJavascript(js, null));
        });
    }
}
