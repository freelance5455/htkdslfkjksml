package com.streamfetcher.app

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

object EasyplexApi {

    private const val BASE = "http://144.91.94.164:8007/sources"

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    /**
     * Fetch streaming sources from Easyplex API.
     * Only returns videos where resolved == true (playable links).
     */
    suspend fun getSources(
        tmdbId: Int,
        title: String,
        type: String,
        season: Int = 0,
        episode: Int = 0
    ): List<JSONObject> = withContext(Dispatchers.IO) {
        try {
            val encodedTitle = URLEncoder.encode(title, "UTF-8")
            val url = buildString {
                append(BASE)
                if (type == "tv") {
                    append("/tv?tmdb_id=$tmdbId&title=$encodedTitle&season=$season&episode=$episode")
                } else {
                    append("/movie?tmdb_id=$tmdbId&title=$encodedTitle")
                }
            }

            Log.d("EasyplexApi", "GET $url")

            val request = Request.Builder()
                .url(url)
                .get()
                .addHeader("Accept", "application/json")
                .addHeader("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36")
                .build()

            val response = client.newCall(request).execute()
            val body = response.body?.string()

            Log.d("EasyplexApi", "HTTP ${response.code}: ${body?.take(200)}")

            if (body.isNullOrEmpty()) return@withContext emptyList()

            val json = JSONObject(body)
            if (!json.optBoolean("success", false)) {
                Log.w("EasyplexApi", "API returned success=false")
                return@withContext emptyList()
            }

            val videos = json.optJSONArray("videos") ?: return@withContext emptyList()
            val out = mutableListOf<JSONObject>()

            for (i in 0 until videos.length()) {
                val v = videos.getJSONObject(i)
                // Only include resolved playable links
                if (v.optBoolean("resolved", false)) {
                    out.add(v)
                }
            }

            Log.d("EasyplexApi", "found ${out.size} resolved videos")
            out
        } catch (e: Exception) {
            Log.e("EasyplexApi", "error: ${e.message}", e)
            emptyList()
        }
    }
}
