package com.streamfetcher.app

data class SrtCue(val start: Long, val end: Long, val text: String)

object SrtParser {

    fun parse(rawText: String): List<SrtCue> {
        val cues = mutableListOf<SrtCue>()
        val normalized = rawText.replace("\r\n", "\n").replace("\r", "\n")
        val blocks = normalized.split("\n\n")
        for (block in blocks) {
            val lines = block.split("\n").filter { it.isNotBlank() }
            if (lines.size < 2) continue
            var timingIndex = -1
            for (i in lines.indices) {
                if (lines[i].contains("-->")) { timingIndex = i; break }
            }
            if (timingIndex < 0) continue
            val timing = parseTiming(lines[timingIndex]) ?: continue
            val sb = StringBuilder()
            for (i in timingIndex + 1 until lines.size) {
                if (sb.isNotEmpty()) sb.append("\n")
                sb.append(cleanLine(lines[i]))
            }
            // ✅ collapse any double/multi line breaks -> tight lines
            val text = sb.toString().trim().replace(Regex("\\n{2,}"), "\n")
            if (text.isNotEmpty()) cues.add(SrtCue(timing.first, timing.second, text))
        }
        return cues
    }

    private fun parseTiming(line: String): Pair<Long, Long>? {
        val parts = line.split("-->")
        if (parts.size != 2) return null
        val s = parseTime(parts[0].trim()) ?: return null
        val e = parseTime(parts[1].trim()) ?: return null
        return s to e
    }

    private fun parseTime(t: String): Long? {
        val m = Regex("(\\d+):(\\d+):(\\d+)[,.](\\d+)").find(t) ?: return null
        val (h, mi, s, ms) = m.destructured
        return h.toLong() * 3600_000 +
                mi.toLong() * 60_000 +
                s.toLong() * 1000 +
                ms.padEnd(3, '0').take(3).toLong()
    }

    private fun cleanLine(s: String): String = s
        .replace(Regex("<[^>]+>"), "")
        .replace(Regex("\\{\\\\[^}]*\\}"), "")
}
