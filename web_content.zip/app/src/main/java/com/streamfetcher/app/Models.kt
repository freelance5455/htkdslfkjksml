package com.streamfetcher.app

data class MediaItem(
    val id: Int,
    val title: String,
    val year: String,
    val posterPath: String?,
    val backdropPath: String?,
    val type: String,
    val rating: Double = 0.0,
    val aoneroomId: String? = null
)

data class StreamOption(
    val quality: String,
    val format: String,
    val url: String,
    val cookie: String,
    val label: String,
    val referer: String = "",
    val useragent: String = ""
)

data class Episode(val number: Int, val name: String)
