package com.streamfetcher.app

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object VidLinkApi {
    
    private const val ENC_URL = "https://enc-dec.app/api/enc-vidlink"
    private const val API_BASE = "https://vidlink.pro/api/b"
    private const val USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    private const val REFERER = "https://vidlink.pro/"
    private const val ORIGIN = "https://vidlink.pro"
    
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()
    
    private suspend fun getEncryptedToken(tmdbId: Int): String? = withContext(Dispatchers.IO) {
        try {
            val url = "$ENC_URL?text=$tmdbId"
            Log.d("VidLinkApi", "Fetching token from: $url")
            
            val request = Request.Builder()
                .url(url)
                .get()
                .addHeader("User-Agent", USER_AGENT)
                .build()
            
            val response = client.newCall(request).execute()
            val body = response.body?.string() ?: return@withContext null
            
            Log.d("VidLinkApi", "Token response code: ${response.code}")
            
            if (!response.isSuccessful) {
                Log.e("VidLinkApi", "Token request failed: ${response.code}")
                return@withContext null
            }
            
            val json = JSONObject(body)
            val token = json.optString("result", "")
            if (token.isEmpty()) {
                Log.e("VidLinkApi", "Empty token in response")
                return@withContext null
            }
            
            Log.d("VidLinkApi", "Got token (${token.length} chars)")
            token
        } catch (e: Exception) {
            Log.e("VidLinkApi", "Token error: ${e.message}", e)
            null
        }
    }
    
    suspend fun getStreams(
        tmdbId: Int,
        type: String,
        season: Int = 0,
        episode: Int = 0
    ): List<StreamOption> = withContext(Dispatchers.IO) {
        val out = mutableListOf<StreamOption>()
        try {
            Log.d("VidLinkApi", "=== Fetching $type streams: tmdb=$tmdbId, s=$season, e=$episode ===")
            
            val token = getEncryptedToken(tmdbId) ?: run {
                Log.e("VidLinkApi", "Failed to get token")
                return@withContext out
            }
            
            val apiUrl = if (type == "tv") {
                "$API_BASE/tv/$token/$season/$episode?multiLang=0"
            } else {
                "$API_BASE/movie/$token?multiLang=0"
            }
            
            Log.d("VidLinkApi", "API URL: $apiUrl")
            
            // Add x-playback-environment header to get DASH streams
            val apiRequest = Request.Builder()
                .url(apiUrl)
                .get()
                .addHeader("User-Agent", USER_AGENT)
                .addHeader("Referer", REFERER)
                .addHeader("Origin", ORIGIN)
                .addHeader("x-playback-environment", "dash-hevc")
                .build()
            
            val apiResponse = client.newCall(apiRequest).execute()
            val apiBody = apiResponse.body?.string()
            
            Log.d("VidLinkApi", "API response code: ${apiResponse.code}")
            
            if (!apiResponse.isSuccessful || apiBody.isNullOrEmpty()) {
                Log.e("VidLinkApi", "API request failed: ${apiResponse.code}")
                return@withContext out
            }
            
            Log.d("VidLinkApi", "API body (first 500): ${apiBody.take(500)}")
            
            val json = JSONObject(apiBody)
            val stream = json.optJSONObject("stream") ?: run {
                Log.e("VidLinkApi", "No 'stream' object in response")
                return@withContext out
            }
            
            // ✅ CORRECT APPROACH: Use playlist (DASH/HLS) with CloudFront cookies
            val streamType = stream.optString("type", "").lowercase()
            val playlistUrl = stream.optString("playlist", "")
            val playlistHeaders = stream.optJSONObject("playlistHeaders")
            val cookie = playlistHeaders?.optString("Cookie", "") ?: ""
            
            Log.d("VidLinkApi", "Stream type: $streamType")
            Log.d("VidLinkApi", "Playlist URL: $playlistUrl")
            Log.d("VidLinkApi", "Has cookie: ${cookie.isNotEmpty()}")
            
            if (playlistUrl.isNotEmpty()) {
                val format = when (streamType) {
                    "dash" -> "DASH"
                    "hls" -> "HLS"
                    else -> streamType.uppercase()
                }
                
                // Get available resolutions from metadata
                val metadata = stream.optJSONObject("playbackMetadata")
                val resolutions = metadata?.optJSONArray("resolutions")
                
                if (resolutions != null && resolutions.length() > 0) {
                    // Add each resolution as a separate option
                    for (i in 0 until resolutions.length()) {
                        val quality = resolutions.optString(i, "Auto")
                        out.add(StreamOption(
                            quality = quality,
                            format = format,
                            url = playlistUrl,
                            cookie = cookie,
                            label = "VidLink",
                            referer = REFERER,
                            useragent = USER_AGENT
                        ))
                        Log.d("VidLinkApi", "✓ Added $format $quality with CloudFront cookie")
                    }
                } else {
                    // Single quality option
                    out.add(StreamOption(
                        quality = "Auto",
                        format = format,
                        url = playlistUrl,
                        cookie = cookie,
                        label = "VidLink",
                        referer = REFERER,
                        useragent = USER_AGENT
                    ))
                    Log.d("VidLinkApi", "✓ Added $format Auto with CloudFront cookie")
                }
            } else {
                Log.w("VidLinkApi", "No playlist URL found in response")
            }
            
            // Log subtitle availability
            val captions = stream.optJSONArray("captions")
            val subCount = captions?.length() ?: 0
            if (subCount > 0) {
                Log.d("VidLinkApi", "Subtitles available: $subCount")
            }
            
            Log.d("VidLinkApi", "=== Total streams: ${out.size} ===")
        } catch (e: Exception) {
            Log.e("VidLinkApi", "Error: ${e.message}", e)
        }
        out
    }
}
