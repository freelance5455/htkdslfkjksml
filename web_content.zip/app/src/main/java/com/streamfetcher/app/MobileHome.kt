package com.streamfetcher.app

import android.app.Activity
import android.view.Gravity
import android.view.View
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/** Phone-only behavior. Edit this file for mobile changes — TV never touches it. */
object MobileHome {

    fun setup(a: Activity, openSearch: () -> Unit) {
        if (DeviceDetect.isTvDevice(a)) return
        try {
            a.findViewById<View>(R.id.tvClock)?.visibility = View.GONE
            a.findViewById<View>(R.id.btnSearchOpen)?.setOnClickListener { openSearch() }
            overlayTopBar(a)
            buildBottomNav(a)
        } catch (t: Throwable) {
            android.util.Log.e("MobileHome", "setup failed", t)
        }
    }

    /** Netflix-style bottom nav: centered icon over label, active = white */
    /** Phone: topBar becomes a transparent overlay so the hero image fills the whole top */
    private fun overlayTopBar(a: Activity) {
        val topBar = a.findViewById<View>(R.id.topBar) ?: return
        val column = topBar.parent as? LinearLayout ?: return
        val homeWrap = a.findViewById<View>(R.id.homeWrap) ?: return
        val frame = homeWrap.parent as? android.widget.FrameLayout ?: return
        column.removeView(topBar)
        topBar.background = a.getDrawable(R.drawable.bg_top_scrim)
        val lp = android.widget.FrameLayout.LayoutParams(
            android.widget.FrameLayout.LayoutParams.MATCH_PARENT,
            android.widget.FrameLayout.LayoutParams.WRAP_CONTENT)
        lp.gravity = Gravity.TOP
        frame.addView(topBar, lp)
    }

    private fun buildBottomNav(a: Activity) {
        val tabs = a.findViewById<HorizontalScrollView>(R.id.tabsBar) ?: return
        val parent = tabs.parent as? LinearLayout ?: return
        tabs.visibility = View.GONE

        val dp = a.resources.displayMetrics.density
        val bar = LinearLayout(a)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.setBackgroundColor(0xFF141414.toInt())
        bar.elevation = 16f
        bar.setPadding(0, (10 * dp).toInt(), 0, (12 * dp).toInt())
        bar.layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)

        val items = listOf(
            Triple(R.id.tabHome, R.drawable.ic_home, "Home"),
            Triple(R.id.tabMovies, R.drawable.ic_movies, "Movies"),
            Triple(R.id.tabSeries, R.drawable.ic_tv, "Series"),
            Triple(R.id.tabMyList, R.drawable.ic_bookmark, "My List")
        )
        val refs = mutableListOf<Pair<ImageView, TextView>>()
        for ((i, t) in items.withIndex()) {
            val item = LinearLayout(a)
            item.orientation = LinearLayout.VERTICAL
            item.gravity = Gravity.CENTER
            item.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)

            val iv = ImageView(a)
            iv.setImageResource(t.second)
            iv.layoutParams = LinearLayout.LayoutParams((22 * dp).toInt(), (22 * dp).toInt())

            val tv = TextView(a)
            tv.text = t.third
            tv.textSize = 11f
            tv.gravity = Gravity.CENTER
            tv.layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            tv.setPadding(0, (5 * dp).toInt(), 0, 0)

            item.addView(iv)
            item.addView(tv)
            item.setOnClickListener {
                a.findViewById<View>(t.first)?.performClick()
                select(refs, i)
            }
            refs.add(iv to tv)
            bar.addView(item)
        }
        parent.addView(bar)
        select(refs, 0)
    }

    private fun select(refs: List<Pair<ImageView, TextView>>, idx: Int) {
        for ((i, r) in refs.withIndex()) {
            val active = i == idx
            r.first.setColorFilter(if (active) 0xFFFFFFFF.toInt() else 0xFF8A8A93.toInt())
            r.second.setTextColor(if (active) 0xFFFFFFFF.toInt() else 0xFF8A8A93.toInt())
        }
    }
}
