package com.streamfetcher.app

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Cache
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

object Api {
    const val TMDB_KEY = "31a4368cdaeeb5625ba280be4e445e3c"
    const val IMG = "https://image.tmdb.org/t/p/"
    const val PRIME = "https://primeott.sytes.net/engine/engine.php"
    const val BASE = "https://api.themoviedb.org/3"

    private var client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    fun init(ctx: Context) {
        client = OkHttpClient.Builder()
            .cache(Cache(ctx.cacheDir, 20L * 1024 * 1024))
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .build()
    }

    suspend fun get(url: String, prime: Boolean = false): JSONObject? = withContext(Dispatchers.IO) {
        try {
            val b = Request.Builder().url(url)
            if (prime) b.header("user-agent", "okhttp/4.12.0")
            val res = client.newCall(b.build()).execute()
            if (res.isSuccessful) JSONObject(res.body?.string() ?: "{}") else null
        } catch (e: Exception) { null }
    }

    fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun str(o: JSONObject, k: String): String? {
        val v = o.opt(k) ?: return null
        if (v == JSONObject.NULL) return null
        val s = v.toString()
        return if (s.isEmpty() || s == "null") null else s
    }

    fun parseResults(json: JSONObject?, type: String): List<MediaItem> {
        val out = mutableListOf<MediaItem>()
        val arr = json?.optJSONArray("results") ?: return out
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val date = if (type == "movie") o.optString("release_date") else o.optString("first_air_date")
            out.add(MediaItem(
                id = o.optInt("id"),
                title = if (type == "movie") o.optString("title") else o.optString("name"),
                year = if (date.length >= 4) date.substring(0, 4) else "—",
                posterPath = str(o, "poster_path"),
                backdropPath = str(o, "backdrop_path"),
                type = type,
                rating = o.optDouble("vote_average", 0.0)
            ))
        }
        return out
    }

    // NEW: Search movies and TV shows
    suspend fun search(query: String): List<MediaItem> = withContext(Dispatchers.IO) {
        val movies = parseResults(
            get("$BASE/search/movie?api_key=$TMDB_KEY&query=${enc(query)}"),
            "movie"
        )
        val tv = parseResults(
            get("$BASE/search/tv?api_key=$TMDB_KEY&query=${enc(query)}"),
            "tv"
        )
        movies + tv
    }

    // NEW: Get popular movies and TV shows
    suspend fun getPopular(): List<MediaItem> = withContext(Dispatchers.IO) {
        val movies = parseResults(
            get("$BASE/movie/popular?api_key=$TMDB_KEY"),
            "movie"
        )
        val tv = parseResults(
            get("$BASE/tv/popular?api_key=$TMDB_KEY"),
            "tv"
        )
        (movies + tv).shuffled()
    }
}
