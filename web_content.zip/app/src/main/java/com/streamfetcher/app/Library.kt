package com.streamfetcher.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object Library {

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("library", Context.MODE_PRIVATE)

    fun myList(ctx: Context): MutableList<MediaItem> {
        val arr = JSONArray(prefs(ctx).getString("mylist", "[]") ?: "[]")
        val out = mutableListOf<MediaItem>()
        for (i in 0 until arr.length()) {
            val e = arr.getJSONObject(i)
            out.add(MediaItem(e.optInt("id"), e.optString("title"), e.optString("year"),
                e.optString("poster"), e.optString("backdrop"), e.optString("type"), e.optDouble("rating")))
        }
        return out
    }

    fun inMyList(ctx: Context, item: MediaItem): Boolean =
        myList(ctx).any { it.id == item.id && it.type == item.type }

    fun toggleMyList(ctx: Context, item: MediaItem): Boolean {
        val list = myList(ctx)
        val existed = list.removeAll { it.id == item.id && it.type == item.type }
        if (!existed) list.add(0, item)
        val arr = JSONArray()
        list.forEach { m ->
            arr.put(JSONObject().put("id", m.id).put("title", m.title).put("year", m.year)
                .put("poster", m.posterPath ?: "").put("backdrop", m.backdropPath ?: "")
                .put("type", m.type).put("rating", m.rating))
        }
        prefs(ctx).edit().putString("mylist", arr.toString()).apply()
        return !existed
    }

    data class ContinueItem(val type: String, val id: Int, val season: Int, val episode: Int,
                            val title: String, val pos: Long, val dur: Long, val time: Long)

    fun continueList(ctx: Context): List<ContinueItem> {
        val all = JSONObject(prefs(ctx).getString("continue", "{}") ?: "{}")
        val out = mutableListOf<ContinueItem>()
        val keys = all.keys()
        while (keys.hasNext()) {
            val e = all.getJSONObject(keys.next())
            out.add(ContinueItem(e.optString("type"), e.optInt("id"), e.optInt("season"),
                e.optInt("episode"), e.optString("title"), e.optLong("pos"), e.optLong("dur"), e.optLong("time")))
        }
        return out.sortedByDescending { it.time }
    }

    fun removeContinue(ctx: Context, id: Int) {
        val all = JSONObject(prefs(ctx).getString("continue", "{}") ?: "{}")
        val keyToRemove = all.keys().asSequence().find { all.optJSONObject(it)?.optInt("id") == id }
        if (keyToRemove != null) {
            all.remove(keyToRemove)
            prefs(ctx).edit().putString("continue", all.toString()).apply()
        }
    }
}
