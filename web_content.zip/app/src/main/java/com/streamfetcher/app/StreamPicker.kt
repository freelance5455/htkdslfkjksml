package com.streamfetcher.app

import android.app.Dialog
import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

object StreamPicker {

    private const val ACCENT = 0xFFE50914.toInt()
    private const val CARD_BG = 0xFF14141C.toInt()
    private const val TEXT_PRIMARY = 0xFFFFFFFF.toInt()
    private const val TEXT_DIM = 0xFFB7BCC9.toInt()
    private const val TEXT_MUTED = 0xFF8A8F9C.toInt()

    fun qualityValue(q: String?): Int {
        if (q == null) return 0
        val num = q.replace(Regex("[^0-9]"), "").toIntOrNull() ?: 0
        if (num > 0) return num * 100  // 1080p = 108000, 480p = 48000
        return when {
            q.contains("4k", true) || q.contains("uhd", true) -> 216000
            q.contains("2160", true) -> 216000
            q.contains("1440", true) -> 144000
            q.contains("1080", true) -> 108000
            q.contains("720", true) -> 72000
            q.contains("hd", true) -> 72000
            q.contains("480", true) || q.contains("sd", true) -> 48000
            q.contains("360", true) -> 36000
            else -> 0
        }
    }

    fun qualityTag(q: String): String {
        if (q.isEmpty() || q == "?" || q == "Auto") return "HD"
        val s = q.lowercase().replace("p", "")
        if (s.contains("4k") || s.contains("uhd") || s.contains("2160")) return "4K"
        if (s.contains("1440") || s.contains("qhd")) return "QHD"
        if (s.contains("1080") || s.contains("fhd")) return "FHD"
        if (s.contains("720") || s.contains("hd")) return "HD"
        if (s.contains("480") || s.contains("sd")) return "SD"
        val num = q.replace(Regex("[^0-9]"), "").toIntOrNull() ?: 0
        return when {
            num >= 2160 -> "4K"
            num >= 1440 -> "QHD"
            num >= 1080 -> "FHD"
            num >= 720 -> "HD"
            else -> "SD"
        }
    }

    data class SubRow(val key: String, val label: String, val sub: String)

    /* ================= SOURCES DIALOG (before playback) ================= */
    fun showSources(
        context: Context,
        options: List<StreamOption>,
        currentLabel: String?,
        onPick: (String) -> Unit
    ) {
        if (options.isEmpty()) return

        val grouped = LinkedHashMap<String, Int>()
        options.forEach { o -> grouped[o.label] = (grouped[o.label] ?: 0) + 1 }

        var firstFocus: View? = null
        val dialog = Dialog(context, android.R.style.Theme_Translucent_NoTitleBar)

        val root = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(context, CARD_BG, 20)
            setPadding(dp(context, 18), dp(context, 16), dp(context, 18), dp(context, 12))
        }

        root.addView(TextView(context).apply {
            text = "SELECT SOURCE"
            textSize = 12f
            letterSpacing = 0.12f
            setTextColor(TEXT_MUTED)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(context, 4), 0, dp(context, 4), dp(context, 10))
        })

        val list = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        root.addView(ScrollView(context).apply {
            isVerticalScrollBarEnabled = false
            addView(list)
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        for ((label, count) in grouped) {
            val selected = label == currentLabel
            val row = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(context, 14), dp(context, 12), dp(context, 14), dp(context, 12))
                background = if (selected) solidRed(context) else context.getDrawable(R.drawable.bg_row_selector)
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    bottomMargin = dp(context, 8)
                }
                isFocusable = true

                addView(TextView(context).apply {
                    text = label
                    textSize = 15f
                    maxLines = 1
                    ellipsize = TextUtils.TruncateAt.END
                    setTextColor(TEXT_PRIMARY)
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                })
                addView(TextView(context).apply {
                    text = "$count"
                    textSize = 11f
                    setTextColor(TEXT_DIM)
                    background = rounded(context, 0x33FFFFFF, 8)
                    setPadding(dp(context, 8), dp(context, 2), dp(context, 8), dp(context, 2))
                })
            }
            if (firstFocus == null) firstFocus = row
            row.setOnClickListener {
                dialog.dismiss()
                onPick(label)
            }
            list.addView(row)
        }

        dialog.setContentView(root)
        dialog.window?.apply {
            setBackgroundDrawableResource(android.R.color.transparent)
            setLayout((context.resources.displayMetrics.widthPixels * 0.86).toInt(),
                WindowManager.LayoutParams.WRAP_CONTENT)
            setGravity(Gravity.CENTER)
        }
        dialog.show()
        dialog.window?.decorView?.post { firstFocus?.requestFocus() }
    }

    /* ================= PLAYER PANEL (source + quality, auto-hide) ================= */
    fun show(
        context: Context,
        options: List<StreamOption>,
        currentIndex: Int,
        onPick: (Int) -> Unit
    ) {
        if (options.isEmpty()) return
        val safe = currentIndex.coerceIn(0, options.size - 1)

        val grouped = LinkedHashMap<String, MutableList<Pair<Int, StreamOption>>>()
        options.forEachIndexed { i, o -> grouped.getOrPut(o.label) { mutableListOf() }.add(i to o) }

        var selectedSource = options[safe].label
        var selectedIndex = safe

        var firstFocus: View? = null
        val handler = Handler(Looper.getMainLooper())
        var hideRunnable: Runnable? = null
        val dialog = object : Dialog(context, android.R.style.Theme_Translucent_NoTitleBar) {
            override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
                hideRunnable?.let {
                    handler.removeCallbacks(it)
                    handler.postDelayed(it, 4000)
                }
                return super.dispatchTouchEvent(ev)
            }
        }
        hideRunnable = Runnable { if (dialog.isShowing) dialog.dismiss() }
        dialog.setOnDismissListener { hideRunnable?.let { handler.removeCallbacks(it) } }

        val wrapper = FrameLayout(context)
        val panelWidth = minOf(
            (context.resources.displayMetrics.widthPixels * 0.46).toInt(),
            dp(context, 470)
        ).coerceAtLeast(dp(context, 320))

        val root = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            background = panelBackground(context)
            setPadding(dp(context, 18), dp(context, 16), dp(context, 18), dp(context, 16))
            layoutParams = FrameLayout.LayoutParams(panelWidth, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.END)
        }
        wrapper.addView(root)

        root.addView(TextView(context).apply {
            text = "PREFERENCES"
            textSize = 11f
            letterSpacing = 0.12f
            setTextColor(TEXT_MUTED)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(context, 4), 0, dp(context, 4), dp(context, 12))
        })

        val columns = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }
        root.addView(columns)

        val leftCol = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f).apply {
                marginEnd = dp(context, 10)
            }
        }
        columns.addView(leftCol)
        leftCol.addView(header(context, "SOURCE"))
        val sourceList = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        leftCol.addView(ScrollView(context).apply {
            isVerticalScrollBarEnabled = false
            addView(sourceList)
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val rightCol = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f).apply {
                marginStart = dp(context, 10)
            }
        }
        columns.addView(rightCol)
        rightCol.addView(header(context, "QUALITY"))
        val qualityList = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        rightCol.addView(ScrollView(context).apply {
            isVerticalScrollBarEnabled = false
            addView(qualityList)
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        var renderQualities: () -> Unit = {}
        var renderSources: () -> Unit = {}

        renderQualities = renderQualities@{
            qualityList.removeAllViews()
            val streams = grouped[selectedSource] ?: return@renderQualities
            val sorted = streams.sortedByDescending { qualityValue(it.second.quality) }
            for ((idx, opt) in sorted) {
                val btn = pill(context, qualityText(opt), idx == selectedIndex)
                btn.setOnClickListener {
                    dialog.dismiss()
                    onPick(idx)
                }
                qualityList.addView(btn)
            }
            Unit
        }

        renderSources = renderSources@{
            sourceList.removeAllViews()
            for ((label, streams) in grouped) {
                val selected = label == selectedSource
                val btn = pill(context, label, selected)
                if (selected && firstFocus == null) firstFocus = btn
                btn.setOnClickListener {
                    val best = streams.maxByOrNull { qualityValue(it.second.quality) }?.first
                        ?: streams.first().first
                    dialog.dismiss()
                    onPick(best)
                }
                sourceList.addView(btn)
            }
            Unit
        }

        renderSources()
        renderQualities()

        dialog.setContentView(wrapper)
        dialog.window?.apply {
            setBackgroundDrawableResource(android.R.color.transparent)
            setDimAmount(0f)
            setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }
        dialog.show()
        handler.postDelayed(hideRunnable!!, 4000)
        dialog.window?.decorView?.post { firstFocus?.requestFocus() }
    }

    /* ================= SUBTITLES PANEL ================= */
    fun showSubtitlePanel(
        context: Context,
        sources: List<String>,
        initialSource: String,
        load: (String, (List<SubRow>) -> Unit) -> Unit,
        onPick: (String, SubRow) -> Unit
    ) {
        var firstFocus: View? = null
        val dialog = Dialog(context, android.R.style.Theme_Translucent_NoTitleBar)

        val wrapper = FrameLayout(context)
        val panelWidth = minOf(
            (context.resources.displayMetrics.widthPixels * 0.46).toInt(),
            dp(context, 470)
        ).coerceAtLeast(dp(context, 320))

        val root = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            background = panelBackground(context)
            setPadding(dp(context, 18), dp(context, 16), dp(context, 18), dp(context, 16))
            layoutParams = FrameLayout.LayoutParams(panelWidth, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.END)
        }
        wrapper.addView(root)

        root.addView(TextView(context).apply {
            text = "SUBTITLES"
            textSize = 11f
            letterSpacing = 0.12f
            setTextColor(TEXT_MUTED)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(context, 4), 0, dp(context, 4), dp(context, 12))
        })

        val columns = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }
        root.addView(columns)

        val leftCol = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f).apply {
                marginEnd = dp(context, 10)
            }
        }
        columns.addView(leftCol)
        leftCol.addView(header(context, "SOURCE"))
        val sourceList = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        leftCol.addView(ScrollView(context).apply {
            isVerticalScrollBarEnabled = false
            addView(sourceList)
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val rightCol = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1.2f).apply {
                marginStart = dp(context, 10)
            }
        }
        columns.addView(rightCol)
        rightCol.addView(header(context, "AVAILABLE"))
        val subList = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        rightCol.addView(ScrollView(context).apply {
            isVerticalScrollBarEnabled = false
            addView(subList)
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        var selectedSource = initialSource

        var loadSubs: () -> Unit = {}
        var renderSources: () -> Unit = {}

        loadSubs = loadSubs@{
            subList.removeAllViews()
            subList.addView(pill(context, "Loading…", false))
            load(selectedSource) { rows ->
                subList.removeAllViews()
                if (rows.isEmpty()) {
                    subList.addView(pill(context, "Not available", false))
                } else {
                    for (row in rows) {
                        val text = if (row.sub.isEmpty()) row.label else row.label + "  ·  " + row.sub
                        val btn = pill(context, text, false, true)
                        btn.setOnClickListener {
                            dialog.dismiss()
                            onPick(selectedSource, row)
                        }
                        subList.addView(btn)
                    }
                }
                Unit
            }
        }

        renderSources = renderSources@{
            sourceList.removeAllViews()
            for (src in sources) {
                val selected = src == selectedSource
                val btn = pill(context, src, selected)
                if (selected && firstFocus == null) firstFocus = btn
                btn.setOnClickListener {
                    if (selectedSource != src) {
                        selectedSource = src
                        renderSources()
                        loadSubs()
                    }
                }
                sourceList.addView(btn)
            }
            Unit
        }

        renderSources()
        loadSubs()

        dialog.setContentView(wrapper)
        dialog.window?.apply {
            setBackgroundDrawableResource(android.R.color.transparent)
            setDimAmount(0f)
            setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }
        dialog.show()
        dialog.window?.decorView?.post { firstFocus?.requestFocus() }
    }

    /* ================= shared pieces ================= */

    private fun qualityNum(q: String?): Int {
        if (q == null) return 0
        val s = q.lowercase().replace("p", "")
        if (s.contains("4k") || s.contains("uhd") || s.contains("2160")) return 2160
        if (s.contains("1440") || s.contains("qhd")) return 1440
        if (s.contains("1080") || s.contains("fhd")) return 1080
        if (s.contains("720") || s.contains("hd")) return 720
        if (s.contains("480") || s.contains("sd")) return 480
        if (s.contains("360")) return 360
        return q.replace(Regex("[^0-9]"), "").toIntOrNull() ?: 0
    }

    private fun qualityText(o: StreamOption): String {
        val q = o.quality
        if (q.isEmpty() || q == "?" || q == "Auto") return "Auto"
        val n = qualityNum(q)
        if (n <= 0) return q
        return "${n}p · ${qualityTag(n.toString())}"
    }

    private fun pill(context: Context, text: String, selected: Boolean, wrap: Boolean = false): TextView =
        TextView(context).apply {
            this.text = if (selected) "✓  $text" else text
            textSize = if (wrap) 12f else 14f
            if (wrap) {
                gravity = Gravity.CENTER_VERTICAL or Gravity.START
            } else {
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                gravity = Gravity.CENTER
            }
            setTextColor(TEXT_PRIMARY)
            typeface = if (selected) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            setPadding(dp(context, 12), dp(context, 11), dp(context, 12), dp(context, 11))
            background = if (selected) solidRed(context) else context.getDrawable(R.drawable.bg_row_selector)
            if (selected) {
                setOnFocusChangeListener { v, focused ->
                    (v.background as? GradientDrawable)?.setStroke(
                        if (focused) dp(context, 3) else 0, 0xFFFFFFFF.toInt())
                }
            }
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(context, 7)
            }
            isFocusable = true
        }

    private fun solidRed(context: Context): GradientDrawable =
        rounded(context, ACCENT, 12)

    private fun header(context: Context, text: String): TextView =
        TextView(context).apply {
            this.text = text
            textSize = 10f
            letterSpacing = 0.12f
            setTextColor(TEXT_MUTED)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(context, 4), 0, dp(context, 4), dp(context, 8))
        }

    private fun panelBackground(context: Context): GradientDrawable {
        val r = 16 * context.resources.displayMetrics.density
        return GradientDrawable().apply {
            setColor(0xFF14141C.toInt())
            cornerRadii = floatArrayOf(r, r, 0f, 0f, 0f, 0f, r, r)
        }
    }

    private fun rounded(context: Context, color: Int, radiusDp: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radiusDp * context.resources.displayMetrics.density
        }

    private fun dp(context: Context, v: Int): Int =
        (v * context.resources.displayMetrics.density).toInt()
}
