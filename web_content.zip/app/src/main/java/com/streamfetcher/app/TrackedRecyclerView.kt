package com.streamfetcher.app

class TrackedRecyclerView @JvmOverloads constructor(
    context: android.content.Context,
    attrs: android.util.AttributeSet? = null
) : androidx.recyclerview.widget.RecyclerView(context, attrs) {

    private fun trace(tag: String) {
        android.util.Log.d("JUMP_TRACE", "$tag caller=" +
            Thread.currentThread().stackTrace.drop(4).take(18).joinToString("/") {
                it.className.substringAfterLast('.') + "." + it.methodName
            })
    }

    override fun smoothScrollBy(dx: Int, dy: Int) { trace("smoothScrollBy dx=$dx"); super.smoothScrollBy(dx, dy) }
    override fun scrollBy(dx: Int, dy: Int) { trace("scrollBy dx=$dx"); super.scrollBy(dx, dy) }
    override fun scrollTo(x: Int, y: Int) { trace("scrollTo x=$x"); super.scrollTo(x, y) }
    override fun smoothScrollToPosition(position: Int) { trace("smoothScrollToPosition pos=$position"); super.smoothScrollToPosition(position) }
    override fun scrollToPosition(position: Int) { trace("scrollToPosition pos=$position"); super.scrollToPosition(position) }
    override fun fling(velX: Int, velY: Int): Boolean { trace("fling velX=$velX"); return super.fling(velX, velY) }
}
