package com.streamfetcher.app

import android.content.Context

data class ProgressItem(
    val id: Int, val type: String, val title: String,
    val season: Int, val episode: Int,
    val position: Long, val duration: Long, val time: Long
)

object ProgressStore {

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("reezn_progress", 0)
    private fun key(type: String, id: Int, season: Int, episode: Int) =
        "${type}_${id}_${season}_${episode}"

    fun saveProgress(ctx: Context, id: Int, type: String, title: String,
                     season: Int, episode: Int, position: Long, duration: Long) {
        val k = key(type, id, season, episode)
        prefs(ctx).edit()
            .putLong(k + "_pos", position)
            .putLong(k + "_dur", duration)
            .putString(k + "_title", title)
            .putString(k + "_type", type)
            .putInt(k + "_id", id)
            .putInt(k + "_season", season)
            .putInt(k + "_episode", episode)
            .putLong(k + "_time", System.currentTimeMillis())
            .apply()
    }

    fun getProgress(ctx: Context, type: String, id: Int, season: Int, episode: Int): Long =
        prefs(ctx).getLong(key(type, id, season, episode) + "_pos", 0L)

    fun clearProgress(ctx: Context, type: String, id: Int, season: Int, episode: Int) {
        val k = key(type, id, season, episode)
        prefs(ctx).edit()
            .remove(k + "_pos").remove(k + "_dur").remove(k + "_title")
            .remove(k + "_type").remove(k + "_id").remove(k + "_season")
            .remove(k + "_episode").remove(k + "_time").apply()
    }

    fun getContinueList(ctx: Context): List<ProgressItem> {
        val p = prefs(ctx)
        val out = mutableListOf<ProgressItem>()
        for ((k, _) in p.all) {
            if (!k.endsWith("_time")) continue
            val base = k.removeSuffix("_time")
            val pos = p.getLong(base + "_pos", 0)
            val dur = p.getLong(base + "_dur", 0)
            if (dur <= 0 || pos < 30000) continue
            if (pos > dur * 0.95) continue
            out.add(ProgressItem(
                p.getInt(base + "_id", 0),
                p.getString(base + "_type", "movie") ?: "movie",
                p.getString(base + "_title", "") ?: "",
                p.getInt(base + "_season", 0),
                p.getInt(base + "_episode", 0),
                pos, dur, p.getLong(base + "_time", 0)))
        }
        return out.sortedByDescending { it.time }.distinctBy { "${it.type}_${it.id}" }.take(10)
    }
}
