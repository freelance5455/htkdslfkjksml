package com.streamfetcher.app

import android.app.Dialog
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

object VipSubtitleDialog {

    fun show(
        ctx: Context,
        subs: List<VipSubtitleItem>,
        selectedId: String?,
        loading: Boolean,
        onPick: (VipSubtitleItem?) -> Unit,
        onAttach: (RecyclerView, VipSubtitleAdapter) -> Unit
    ): Dialog {
        val dialog = Dialog(ctx)
        dialog.setContentView(R.layout.dialog_subtitles)
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.window?.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)

        val items: List<VipSubtitleItem?> = listOf(null) + subs
        val rv = dialog.findViewById<RecyclerView>(R.id.rvSubs)
        val empty = dialog.findViewById<TextView>(R.id.tvEmpty)
        val pb = dialog.findViewById<ProgressBar>(R.id.pbLoading)

        rv.layoutManager = LinearLayoutManager(ctx)
        val adapter = VipSubtitleAdapter(items, selectedId) { item -> onPick(item) }
        rv.adapter = adapter
        onAttach(rv, adapter)

        if (loading) {
            pb.visibility = View.VISIBLE
            empty.visibility = View.GONE
        } else if (subs.isEmpty()) {
            empty.visibility = View.VISIBLE
            rv.visibility = View.GONE
        }
        dialog.show()
        return dialog
    }

    class VipSubtitleAdapter(
        private val items: List<VipSubtitleItem?>,
        private var selectedId: String?,
        private val onPick: (VipSubtitleItem?) -> Unit
    ) : RecyclerView.Adapter<VipSubtitleAdapter.VH>() {

        class VH(v: View) : RecyclerView.ViewHolder(v) {
            val lang: TextView = v.findViewById(R.id.tvLang)
            val name: TextView = v.findViewById(R.id.tvName)
            val dl: TextView = v.findViewById(R.id.tvDownloads)
            val check: ImageView = v.findViewById(R.id.ivCheck)
        }

        fun setSelected(id: String?) {
            selectedId = id
            notifyDataSetChanged()
        }

        override fun onCreateViewHolder(p: ViewGroup, t: Int): VH {
            val v = LayoutInflater.from(p.context).inflate(R.layout.item_subtitle, p, false)
            v.setOnFocusChangeListener { view, focused ->
                view.animate()
                    .scaleX(if (focused) 1.03f else 1f)
                    .scaleY(if (focused) 1.03f else 1f)
                    .setDuration(220).start()
            }
            return VH(v)
        }

        override fun getItemCount() = items.size

        override fun onBindViewHolder(h: VH, pos: Int) {
            val item = items[pos]
            if (item == null) {
                h.lang.text = "🚫"
                h.name.text = "None / بدون ترجمة"
                h.dl.text = "Turn off subtitles"
                h.check.visibility = if (selectedId == null) View.VISIBLE else View.GONE
            } else {
                val hdBadge = if (item.hd) " 💎" else ""
                val aiBadge = if (item.aiTranslated) " 🤖" else ""
                val totalDl = item.downloadCount + item.newDownloadCount
                
                h.lang.text = "💎"
                h.name.text = item.release.takeIf { it.isNotEmpty() } ?: "VIP Subtitle ${item.subtitleId.take(8)}"
                h.dl.text = "⬇ ${VipSubtitleManager.formatDownloads(totalDl)}$hdBadge$aiBadge • ${item.uploaderName}"
                h.check.visibility = if (selectedId == item.subtitleId) View.VISIBLE else View.GONE
            }
            h.itemView.setOnClickListener { onPick(item) }
        }
    }
}
