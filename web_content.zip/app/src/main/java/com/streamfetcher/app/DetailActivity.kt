package com.streamfetcher.app

import android.content.Intent
import android.util.Log
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import coil.load
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

class DetailActivity : AppCompatActivity() {

    private val scope = CoroutineScope(Dispatchers.Main)
    private lateinit var item: MediaItem
    private var currentSeason = 1
    private var currentEpisode = 1
    private var aoneroomOnly = false
    private var aoneroomSubjectId = ""
    private val errorMessages = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)
        loadArabicOverview()
        setupModernButtons()
val rawId = intent.getIntExtra("id", 0)
        aoneroomSubjectId = intent.getStringExtra("aoneroom_id") ?: ""
        aoneroomOnly = aoneroomSubjectId.isNotEmpty()

        item = MediaItem(
            if (aoneroomOnly) 0 else rawId,
            intent.getStringExtra("title") ?: "",
            intent.getStringExtra("year") ?: "",
            intent.getStringExtra("poster"),
            intent.getStringExtra("backdrop"),
            intent.getStringExtra("type") ?: "movie",
            intent.getDoubleExtra("rating", 0.0)
        )

        findViewById<ImageView>(R.id.btnBack)?.setOnClickListener { finish() }

        findViewById<View>(R.id.btnPlayBig).setOnClickListener { sourceIndex = 0; startPlayback() }
        listOf(R.id.btnPlayBig, R.id.btnTrailer, R.id.btnListCircle).forEach { id ->
            findViewById<View>(id)?.setOnFocusChangeListener { v, f ->
                v.animate().scaleX(if (f) 1.05f else 1f).scaleY(if (f) 1.05f else 1f).setDuration(180).start()
                val dp = resources.displayMetrics.density
                when (id) {
                    R.id.btnPlayBig -> {
                        val bg = android.graphics.drawable.GradientDrawable()
                        bg.cornerRadius = 8 * dp
                        bg.setColor(if (f) 0xFFFFFFFF.toInt() else 0xFF4D4D4D.toInt())
                        v.background = bg
                        val ll = v as android.widget.LinearLayout
                        (ll.getChildAt(0) as android.widget.ImageView).setColorFilter(if (f) 0xFF000000.toInt() else 0xFFFFFFFF.toInt())
                        (ll.getChildAt(1) as android.widget.TextView).setTextColor(if (f) 0xFF000000.toInt() else 0xFFFFFFFF.toInt())
                    }
                    R.id.btnTrailer -> {
                        val bg = android.graphics.drawable.GradientDrawable()
                        bg.shape = android.graphics.drawable.GradientDrawable.OVAL
                        bg.setColor(if (f) 0xFFFFFFFF.toInt() else 0xFF4D4D4D.toInt())
                        v.background = bg
                    }
                    R.id.btnListCircle -> {
                        val bg = android.graphics.drawable.GradientDrawable()
                        bg.shape = android.graphics.drawable.GradientDrawable.OVAL
                        bg.setColor(if (f) 0xFFFFFFFF.toInt() else 0xFF4D4D4D.toInt())
                        v.background = bg
                        (v as android.widget.ImageView).setColorFilter(if (f) 0xFF000000.toInt() else 0xFFFFFFFF.toInt())
                    }
                }
                v.invalidate()  // Force redraw to ensure visual update
            }
        }
        findViewById<View>(R.id.btnTrailer).setOnClickListener {
            if (trailerKey.isNotEmpty()) {
                try {
                    startActivity(Intent(Intent.ACTION_VIEW,
                        android.net.Uri.parse("https://www.youtube.com/watch?v=$trailerKey")))
                } catch (t: Throwable) {
                    Toast.makeText(this, "Cannot open trailer", Toast.LENGTH_SHORT).show()
                }
            } else Toast.makeText(this, "No trailer available", Toast.LENGTH_SHORT).show()
        }
        
        // Ensure PLAY button gets focus after layout
        findViewById<View>(R.id.btnPlayBig).postDelayed({
            findViewById<View>(R.id.btnPlayBig)?.requestFocus()
        }, 300)

        findViewById<View>(R.id.btnListCircle).setOnClickListener {
            val added = Library.toggleMyList(this, item)
            Toast.makeText(this, if (added) "✓ Added to My List" else "Removed from My List",
                Toast.LENGTH_SHORT).show()
        }

        // hideRemoveBtn: only show if item has progress in Continue Watching
        val progressItems = ProgressStore.getContinueList(this)
        val inContinue = progressItems.any { it.id == item.id }
        android.util.Log.d("RemoveBtn", "item.id=${item.id}, progressIds=${progressItems.map { it.id }}, inContinue=$inContinue")
        findViewById<View>(R.id.btnRemoveContinue)?.visibility = if (inContinue) View.VISIBLE else View.GONE
        if (!inContinue) findViewById<View>(R.id.btnRemoveContinue)?.isFocusable = false

        val removeBtn = findViewById<View>(R.id.btnRemoveContinue)
        android.util.Log.d("RemoveBtn", "removeBtn=$removeBtn")
        
        fun doRemove() {
            android.util.Log.d("RemoveBtn", "CLICKED! item.id=${item.id}")
            val prog = ProgressStore.getContinueList(this).find { it.id == item.id }
            if (prog != null) {
                ProgressStore.clearProgress(this, prog.type, prog.id, prog.season, prog.episode)
                android.util.Log.d("RemoveBtn", "cleared: ${prog.type}_${prog.id}")
            }
            Toast.makeText(this, "Removed from Continue Watching", Toast.LENGTH_SHORT).show()
            findViewById<View>(R.id.btnRemoveContinue)?.visibility = View.GONE
            findViewById<View>(R.id.btnRemoveContinue)?.isFocusable = false
        }
        
        removeBtn?.setOnClickListener { 
            android.util.Log.d("RemoveBtn", "onTouchEvent CLICKED")
            doRemove() 
        }
        removeBtn?.setOnKeyListener { _, keyCode, event ->
            if (keyCode == android.view.KeyEvent.KEYCODE_DPAD_CENTER || keyCode == android.view.KeyEvent.KEYCODE_ENTER) {
                if (event.action == android.view.KeyEvent.ACTION_UP) {
                    doRemove()
                    return@setOnKeyListener true
                }
            }
            false
        }
        findViewById<View>(R.id.btnRemoveContinue)?.setOnFocusChangeListener { v, f ->
            v.animate().scaleX(if (f) 1.05f else 1f).scaleY(if (f) 1.05f else 1f).setDuration(180).start()
            val dp = resources.displayMetrics.density
            val bg = android.graphics.drawable.GradientDrawable()
            bg.shape = android.graphics.drawable.GradientDrawable.OVAL
            bg.setColor(if (f) 0xFFFFFFFF.toInt() else 0xFF4D4D4D.toInt())
            v.background = bg
            (v as android.widget.ImageView).setColorFilter(if (f) 0xFF000000.toInt() else 0xFFFFFFFF.toInt())
            v.invalidate()
        }

        findViewById<TextView>(R.id.tvTitle).text = item.title
        val ratingTxt = if (item.rating > 0)
            "  •  ★ ${String.format(Locale.US, "%.1f", item.rating)}" else ""
        findViewById<TextView>(R.id.tvMeta).text =
            "${item.year}  •  ${if (item.type == "movie") "MOVIE" else "TV SERIES"}$ratingTxt"

        findViewById<ImageView>(R.id.ivPoster).load(posterUrl(item.posterPath)) {
            crossfade(true)
            placeholder(R.drawable.placeholder)
        }

        findViewById<ImageView>(R.id.ivBackdrop).load(
            posterUrl(item.backdropPath) ?: posterUrl(item.posterPath)
        ) {
            crossfade(true)
            placeholder(R.drawable.placeholder)
        }

        // pull backdrop slightly right so the subject/face avoids the text panel
        findViewById<ImageView>(R.id.ivBackdrop).translationX =
            resources.displayMetrics.widthPixels * 0.12f

        val toggleList = View.OnLongClickListener {
            val added = Library.toggleMyList(this, item)
            Toast.makeText(this, if (added) "✓ Added to My List" else "Removed from My List",
                Toast.LENGTH_SHORT).show()
            true
        }
        findViewById<ImageView>(R.id.ivPoster).setOnLongClickListener(toggleList)
        findViewById<ImageView>(R.id.ivBackdrop).setOnLongClickListener(toggleList)


        listOf(R.id.ivPoster, R.id.ivBackdrop).forEach { id ->
            val iv = findViewById<ImageView>(id)
            iv.isFocusable = true
            iv.setOnFocusChangeListener { v, focused ->
                v.animate().scaleX(if (focused) 1.05f else 1f)
                    .scaleY(if (focused) 1.05f else 1f).setDuration(250).start()
            }
        }



        val myListBtn = findViewById<Button>(R.id.btnMyList)
        myListBtn.text = if (Library.inMyList(this, item)) "✓ In My List" else "+ My List"
        myListBtn.setOnClickListener {
            val added = Library.toggleMyList(this, item)
            myListBtn.text = if (added) "✓ In My List" else "+ My List"
            Toast.makeText(this, if (added) "✓ Added to My List" else "Removed from My List",
                Toast.LENGTH_SHORT).show()
        }





        if (item.type == "tv") {
            findViewById<LinearLayout>(R.id.llTv).visibility = View.VISIBLE
        }

        scope.launch {
            if (aoneroomOnly) {
                setOverview("Available on Aoneroom")

                if (item.type == "tv") setupSeasons(1)
            } else {
                val json = withContext(Dispatchers.IO) {
                    Api.get("${Api.BASE}/${item.type}/${item.id}?api_key=${Api.TMDB_KEY}&append_to_response=release_dates,content_ratings,videos&language=ar-SA")
                }
                setOverview(json?.optString("overview", "")?.takeIf { it.isNotBlank() }
                    ?: "No description available.")
                fillInfoBadges(json)
                if (json != null && item.type == "tv") setupSeasons(json.optInt("number_of_seasons", 1))
            }
        }

        if (!aoneroomOnly) {
            loadRecommendations()
            loadCast()
        }
    }
private fun posterUrl(p: String?): String? = when {
        p.isNullOrEmpty() -> null
        p.startsWith("http") -> p
        else -> Api.IMG + "w500" + p
    }

    private fun updateNowWatching(epName: String? = null) {
        if (item.type != "tv") return
        findViewById<TextView>(R.id.tvNowWatching).text =
            "📍 Now: S${currentSeason} • E${currentEpisode}" +
                (if (epName != null) " — $epName" else "")
        findViewById<Button>(R.id.btnPlay).text =
            "▶  PLAY  •  S${currentSeason}E${currentEpisode}"
    }


    private fun loadCast() {
        if (item.id == 0) return
        scope.launch {
            val json = withContext(Dispatchers.IO) {
                Api.get("${Api.BASE}/${item.type}/${item.id}/credits?api_key=${Api.TMDB_KEY}")
            }
            val arr = json?.optJSONArray("cast") ?: return@launch
            val cast = mutableListOf<CastMember>()
            val n = minOf(arr.length(), 20)
            for (i in 0 until n) {
                val e = arr.getJSONObject(i)
                cast.add(CastMember(
                    e.optInt("id", 0),
                    e.optString("name", ""),
                    e.optString("character", ""),
                    e.optString("profile_path", "")
                ))
            }
            if (cast.isEmpty()) return@launch
            findViewById<TextView>(R.id.tvCastHeader).visibility = View.VISIBLE
            val rv = findViewById<RecyclerView>(R.id.rvCast)
            rv.visibility = View.VISIBLE
            rv.layoutManager = LinearLayoutManager(this@DetailActivity, RecyclerView.HORIZONTAL, false)
            rv.adapter = CastAdapter(cast) { c ->
                startActivity(Intent(this@DetailActivity, PersonActivity::class.java)
                    .putExtra("person_id", c.id)
                    .putExtra("person_name", c.name))
            }
        }
    }

    private fun loadRecommendations() {
        scope.launch {
            val recs = withContext(Dispatchers.IO) {
                Api.parseResults(
                    Api.get("${Api.BASE}/${item.type}/${item.id}/recommendations?api_key=${Api.TMDB_KEY}"),
                    item.type
                )
            }
            if (recs.isNotEmpty()) {
                findViewById<TextView>(R.id.tvRecsHeader).visibility = View.VISIBLE
                val rv = findViewById<RecyclerView>(R.id.rvRecs)
                rv.visibility = View.VISIBLE
                rv.layoutManager = LinearLayoutManager(this@DetailActivity, RecyclerView.HORIZONTAL, false)
                rv.adapter = PosterAdapter(recs, R.layout.item_poster) { openRec(it) }
            }
            loadSimilar()
        }
    }

    private fun loadSimilar() {
        scope.launch {
            val similar = withContext(Dispatchers.IO) {
                Api.parseResults(
                    Api.get("${Api.BASE}/${item.type}/${item.id}/similar?api_key=${Api.TMDB_KEY}"),
                    item.type
                )
            }
            if (similar.isNotEmpty()) {
                findViewById<TextView>(R.id.tvSimilarHeader).visibility = View.VISIBLE
                val rv = findViewById<RecyclerView>(R.id.rvSimilar)
                rv.visibility = View.VISIBLE
                rv.layoutManager = LinearLayoutManager(this@DetailActivity, RecyclerView.HORIZONTAL, false)
                rv.adapter = PosterAdapter(similar, R.layout.item_poster) { openRec(it) }
            }
        }
    }


    private fun openRec(m: MediaItem) {
        startActivity(Intent(this, DetailActivity::class.java)
            .putExtra("id", m.id)
            .putExtra("type", m.type)
            .putExtra("title", m.title)
            .putExtra("year", m.year)
            .putExtra("poster", m.posterPath)
            .putExtra("backdrop", m.backdropPath)
            .putExtra("rating", m.rating))
    }

    override fun dispatchKeyEvent(ev: android.view.KeyEvent): Boolean {
        if (ev.action == android.view.KeyEvent.ACTION_DOWN) {
            val right = ev.keyCode == android.view.KeyEvent.KEYCODE_DPAD_RIGHT || ev.keyCode == 93
            val left  = ev.keyCode == android.view.KeyEvent.KEYCODE_DPAD_LEFT  || ev.keyCode == 92
            val down = ev.keyCode == android.view.KeyEvent.KEYCODE_DPAD_DOWN
            if (down && item.type == "tv") {
                val cur = currentFocus?.id
                // On a TV show, DOWN from the buttons must NEVER escape to cast,
                // even if the season row hasn't loaded yet.
                if (cur == null || cur == R.id.btnPlayBig || cur == R.id.btnTrailer || cur == R.id.btnListCircle) {
                    val row = findViewById<LinearLayout>(R.id.seasonRow)
                    if (row != null && row.childCount > 0) {
                        row.getChildAt(0).requestFocus()
                    }
                    return true   // always swallow for TV shows
                }
            }
            when (currentFocus?.id) {
                R.id.btnPlayBig -> if (right) { findViewById<View>(R.id.btnTrailer)?.requestFocus(); return true }
                R.id.btnTrailer -> {
                    if (right) { findViewById<View>(R.id.btnListCircle)?.requestFocus(); return true }
                    if (left)  { findViewById<View>(R.id.btnPlayBig)?.requestFocus(); return true }
                }
                R.id.btnListCircle -> if (left) { findViewById<View>(R.id.btnTrailer)?.requestFocus(); return true }
            }
        }
        return super.dispatchKeyEvent(ev)
    }

    private fun setOverview(t: String) {
        val v = findViewById<TextView>(R.id.tvOverview) ?: return
        v.text = t
        v.textDirection = if (t.any { it.toInt() in 0x0600..0x06FF })
            View.TEXT_DIRECTION_RTL else View.TEXT_DIRECTION_LTR
    }

    private fun fillInfoBadges(json: JSONObject?) {
        if (json == null) return
        val age = findViewById<TextView>(R.id.tvBadgeAge)
        val cert = if (item.type == "movie") {
            var c = ""
            val rds = json.optJSONObject("release_dates")?.optJSONArray("results")
            if (rds != null) for (i in 0 until rds.length()) {
                val r = rds.getJSONObject(i)
                if (r.optString("iso_3166_1") == "US") {
                    val rd = r.optJSONArray("release_dates")
                    if (rd != null && rd.length() > 0) c = rd.getJSONObject(0).optString("certification", "")
                }
            }
            c
        } else {
            var c = ""
            val crs = json.optJSONObject("content_ratings")?.optJSONArray("results")
            if (crs != null) for (i in 0 until crs.length()) {
                val r = crs.getJSONObject(i)
                if (r.optString("iso_3166_1") == "US") c = r.optString("rating", "")
            }
            c
        }
        if (cert.isNotBlank()) { age.text = cert; age.visibility = View.VISIBLE } else age.visibility = View.GONE
        findViewById<TextView>(R.id.tvYear).text = item.year
        val rt = json.optInt("runtime", 0)
        val seasons = json.optInt("number_of_seasons", 0)
        val dur = findViewById<TextView>(R.id.tvRuntime)
        if (item.type == "movie" && rt > 0) { dur.text = "${rt / 60}h ${rt % 60}m"; dur.visibility = View.VISIBLE }
        else if (item.type == "tv" && seasons > 0) { dur.text = "$seasons season" + (if (seasons > 1) "s" else ""); dur.visibility = View.VISIBLE }
        else dur.visibility = View.GONE
        val gs = StringBuilder()
        val g = json.optJSONArray("genres")
        if (g != null) for (i in 0 until g.length()) { if (i > 0) gs.append(", "); gs.append(g.getJSONObject(i).optString("name")) }
        findViewById<TextView>(R.id.tvGenres).text = gs.toString()
        findViewById<TextView>(R.id.tvType).text = if (item.type == "movie") "Film" else "Series"
        findViewById<TextView>(R.id.tvQuality).text = "HD"
        findViewById<TextView>(R.id.tvRatingStar).text =
            if (item.rating > 0) String.format(java.util.Locale.US, "★ %.1f", item.rating) else ""
        // Fetch videos separately without language restriction (Arabic may not have videos)
        scope.launch(Dispatchers.IO) {
            val videosJson = Api.get("${Api.BASE}/${item.type}/${item.id}/videos?api_key=${Api.TMDB_KEY}")
            val vids = videosJson?.optJSONArray("results") ?: json.optJSONObject("videos")?.optJSONArray("results")
            var foundKey = ""
            if (vids != null) for (i in 0 until vids.length()) {
                val v = vids.getJSONObject(i)
                val site = v.optString("site")
                val type = v.optString("type")
                val key = v.optString("key")
                if (site == "YouTube") {
                    if (type == "Trailer") { foundKey = key; break }
                    if (foundKey.isEmpty()) foundKey = key
                }
            }
            withContext(Dispatchers.Main) {
                trailerKey = foundKey
                android.util.Log.d("Trailer", "item=${item.title}, trailerKey=$trailerKey, vidsCount=${vids?.length()}")
            }
        }
    }

                private fun setupSeasons(count: Int) {
        findViewById<LinearLayout>(R.id.llTv).visibility = View.VISIBLE
        val row = findViewById<LinearLayout>(R.id.seasonRow) ?: return
        row.removeAllViews()
        val dp = resources.displayMetrics.density
        for (i in 1..count) {
            val t = TextView(this)
            t.text = "Season $i"
            t.textSize = 13f
            t.setTypeface(null, android.graphics.Typeface.BOLD)
            val gd = android.graphics.drawable.GradientDrawable()
            gd.cornerRadius = 8 * dp
            gd.setColor(0xFF4D4D4D.toInt())
            t.background = gd
            t.setTextColor(0xFFFFFFFF.toInt())
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, (42 * dp).toInt())
            lp.setMargins(0, 0, (10 * dp).toInt(), 0)
            t.layoutParams = lp
            t.gravity = android.view.Gravity.CENTER
            t.setPadding((18 * dp).toInt(), 0, (18 * dp).toInt(), 0)
            t.isFocusable = true
            val si = i
            t.setOnFocusChangeListener { v, f ->
                v.animate().scaleX(if (f) 1.05f else 1f).scaleY(if (f) 1.05f else 1f).setDuration(150).start()
                val tv = v as TextView
                val g = android.graphics.drawable.GradientDrawable()
                g.cornerRadius = 8 * dp
                if (f) {
                    g.setColor(0xFFFFFFFF.toInt())
                    tv.background = g
                    tv.setTextColor(0xFF000000.toInt())
                } else {
                    g.setColor(if (si == currentSeason) 0xFFE50914.toInt() else 0xFF4D4D4D.toInt())
                    tv.background = g
                    tv.setTextColor(0xFFFFFFFF.toInt())
                }
            }
            t.setOnClickListener { selectSeason(si) }
            row.addView(t)
        }
        selectSeason(1)
    }

    private fun selectSeason(n: Int) {
        currentSeason = n
        val row = findViewById<LinearLayout>(R.id.seasonRow) ?: return
        for (i in 0 until row.childCount) {
            val c = row.getChildAt(i) as TextView
            val active = i == n - 1
            val g = android.graphics.drawable.GradientDrawable()
            g.cornerRadius = 8 * resources.displayMetrics.density
            g.setColor(if (active) 0xFFE50914.toInt() else 0xFF4D4D4D.toInt())
            c.background = g
            c.setTextColor(0xFFFFFFFF.toInt())
        }
        loadEpisodes(n)
    }
            private fun loadEpisodes(season: Int) {
        if (aoneroomOnly) {
            val rows = (1..10).map { EpRow(it, "Episode $it", "", "", null) }
            bindEpisodes(rows)
            return
        }
        scope.launch {
            val json = withContext(Dispatchers.IO) {
                Api.get("${Api.BASE}/tv/${item.id}/season/$season?api_key=${Api.TMDB_KEY}")
            }
            val arr = json?.optJSONArray("episodes")
            val rows = mutableListOf<EpRow>()
            if (arr != null) for (i in 0 until arr.length()) {
                val e = arr.getJSONObject(i)
                val rt = e.optInt("runtime", 0)
                rows.add(EpRow(e.optInt("episode_number", i + 1),
                    e.optString("name", "Episode ${i + 1}"),
                    if (rt > 0) rt.toString() + "m" else "",
                    e.optString("overview", ""),
                    e.optString("still_path", "")))
            }
            bindEpisodes(rows)
        }
    }

            private fun bindEpisodes(rows: List<EpRow>) {
        epRows.clear(); epRows.addAll(rows); epIndex = 0
        showEpisode()
        updateNowWatching(null)
    }

    private fun showEpisode() {
        val box = findViewById<LinearLayout>(R.id.epContainer) ?: return
        val counter = findViewById<TextView>(R.id.tvEpCounter)
        if (epRows.isEmpty()) { box.visibility = View.GONE; counter?.visibility = View.GONE; return }
        box.visibility = View.VISIBLE
        counter?.visibility = View.VISIBLE
        counter?.text = "Episodes  ·  " + (epIndex + 1) + " / " + epRows.size
        box.removeAllViews()
        val e = epRows[epIndex]
        val v = layoutInflater.inflate(R.layout.item_episode_row, box, false)
        v.findViewById<TextView>(R.id.tvEpTitle).text = "E" + e.number + "  ·  " + e.name
        val meta = v.findViewById<TextView>(R.id.tvEpMeta)
        meta.text = e.runtime
        meta.visibility = if (e.runtime.isEmpty()) View.GONE else View.VISIBLE
        val desc = v.findViewById<TextView>(R.id.tvEpDesc)
        desc.text = e.overview
        desc.visibility = if (e.overview.isEmpty()) View.GONE else View.VISIBLE
        val thumb = v.findViewById<ImageView>(R.id.ivEpThumb)
        if (e.still.isNullOrEmpty()) thumb.load(null) { placeholder(R.drawable.placeholder) }
        else thumb.load(Api.IMG + "w300" + e.still) { crossfade(true); placeholder(R.drawable.placeholder) }
        v.setOnFocusChangeListener { vv, f ->
            vv.animate().scaleX(if (f) 1.04f else 1f).scaleY(if (f) 1.04f else 1f).setDuration(180).start()
            vv.background = if (f) {
                val g = android.graphics.drawable.GradientDrawable()
                g.cornerRadius = 10 * resources.displayMetrics.density
                g.setColor(0x33FFFFFF.toInt())
                g.setStroke((3 * resources.displayMetrics.density).toInt(), 0xFFFFFFFF.toInt())
                g
            } else getDrawable(R.drawable.bg_episode_row)
        }
        v.setOnKeyListener { _, kc, ev ->
            if (ev.action == android.view.KeyEvent.ACTION_DOWN) {
                val next = kc == android.view.KeyEvent.KEYCODE_DPAD_DOWN || kc == android.view.KeyEvent.KEYCODE_DPAD_RIGHT
                val prev = kc == android.view.KeyEvent.KEYCODE_DPAD_UP || kc == android.view.KeyEvent.KEYCODE_DPAD_LEFT
                when {
                    next && epIndex < epRows.size - 1 -> {
                        epIndex++; showEpisode()
                        findViewById<LinearLayout>(R.id.epContainer).getChildAt(0)?.requestFocus()
                        true
                    }
                    prev && epIndex > 0 -> {
                        epIndex--; showEpisode()
                        findViewById<LinearLayout>(R.id.epContainer).getChildAt(0)?.requestFocus()
                        true
                    }
                    else -> false
                }
            } else false
        }
        v.setOnClickListener {
            currentEpisode = e.number
            updateNowWatching(e.name)
            startPlayback()
        }
        box.addView(v)
    }

    private fun setupEpisodeSpinner(eps: List<Episode>) {
        val spEp = findViewById<Spinner>(R.id.spEpisodes) ?: return
        if (eps.isEmpty()) return
        val names = eps.map { "E" + it.number + "  " + it.name }
        val epAd = ArrayAdapter(this, android.R.layout.simple_spinner_item, names)
        epAd.setDropDownViewResource(R.layout.item_spinner_dark)
        spEp.adapter = epAd
        spEp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(a: AdapterView<*>?, v: android.view.View?, pos: Int, l: Long) {
                currentEpisode = eps.getOrNull(pos)?.number ?: (pos + 1)
                findViewById<TextView>(R.id.tvNowWatching)?.text =
                    "Now: S" + currentSeason + " E" + currentEpisode
            }
            override fun onNothingSelected(a: AdapterView<*>?) {}
        }
        spEp.setSelection((currentEpisode - 1).coerceIn(0, names.size - 1))
    }

    private fun continueLabel() {
        val type = intent.getStringExtra("type") ?: "movie"
        val mid = intent.getIntExtra("id", 0)
        val btnId = listOf("btnMyList", "btnMylist", "btnList", "btnAddList")
            .firstNotNullOfOrNull { resources.getIdentifier(it, "id", packageName).takeIf { v -> v != 0 } } ?: 0
        if (btnId == 0) return
        val b = findViewById<android.widget.Button>(btnId)
        val pr = ProgressStore.getContinueList(this@DetailActivity).firstOrNull { it.type == type && it.id == mid }
        if (pr == null) { b.visibility = android.view.View.GONE; return }
        b.visibility = android.view.View.VISIBLE
        // Modern button style
        b.background = getDrawable(R.drawable.bg_btn_modern)
        b.setTextColor(0xFFFFFFFF.toInt())
        b.textSize = 15f
        val dp = resources.displayMetrics.density
        b.setPadding((24 * dp).toInt(), (14 * dp).toInt(), (24 * dp).toInt(), (14 * dp).toInt())
        b.setOnFocusChangeListener { v, focused ->
            v.animate().scaleX(if (focused) 1.05f else 1f)
                .scaleY(if (focused) 1.05f else 1f).setDuration(250).start()
        }
        b.text = if (type == "tv")
            "▶ Continue S" + pr.season + " E" + pr.episode
        else {
            "▶ " + (pr.position / 60000) + "m / " + (pr.duration / 60000) + "m"
        }
        b.setOnClickListener {
            // Pre-set season/episode before collecting streams
            if (type == "tv" && pr.season > 0) {
                currentSeason = pr.season
                currentEpisode = pr.episode
                findViewById<Spinner>(R.id.spSeasons).setSelection(pr.season - 1)
                loadEpisodes(pr.season)
                // Delay to let episodes load, then play
                b.postDelayed({ startPlayback() }, 800)
            } else {
                startPlayback()
            }
        }
    }


    private var sourceIndex = 0
    private var trailerKey = ""
    private val epRows = mutableListOf<EpRow>()
    private var epIndex = 0


    private fun setupModernButtons() {
        try {
            val btnPlayM = findViewById<android.widget.FrameLayout>(R.id.btnPlayContainer)
            if (btnPlayM != null) {
                btnPlayM.visibility = android.view.View.VISIBLE
                btnPlayM.setOnClickListener { sourceIndex = 0; startPlayback() }
                btnPlayM.setOnFocusChangeListener { v, focused ->
                    v.animate().scaleX(if (focused) 1.05f else 1f)
                        .scaleY(if (focused) 1.05f else 1f).setDuration(250).start()
                }
                btnPlayM.requestFocus()
            }
            val btnCont = findViewById<android.widget.FrameLayout>(R.id.btnContinueContainer)
            val tvCont = findViewById<android.widget.TextView>(R.id.tvContinueText)
            if (btnCont != null) {
                val mType = intent.getStringExtra("type") ?: "movie"
                val mId = intent.getIntExtra("id", 0)
                val pr = ProgressStore.getContinueList(this@DetailActivity).firstOrNull { it.type == mType && it.id == mId }
                if (pr != null) {
                    btnCont.visibility = android.view.View.VISIBLE
                    tvCont?.text = if (mType == "tv") "Resume S" + pr.season + " E" + pr.episode
                        else ((pr.duration - pr.position) / 60000).toString() + "m left"
                    btnCont.setOnClickListener {
                        if (mType == "tv" && pr.season > 0) {
                            currentSeason = pr.season
                            currentEpisode = pr.episode
                            findViewById<Spinner>(R.id.spSeasons)?.setSelection(pr.season - 1)
                            loadEpisodes(pr.season)
                            btnCont.postDelayed({ startPlayback() }, 800)
                        } else startPlayback()
                    }
                    btnCont.setOnFocusChangeListener { v, focused ->
                        v.animate().scaleX(if (focused) 1.05f else 1f)
                            .scaleY(if (focused) 1.05f else 1f).setDuration(250).start()
                    }
                } else btnCont.visibility = android.view.View.GONE
            }
        } catch (t: Throwable) { android.util.Log.e("Reezn", "buttons", t) }
    }

    private fun startPlayback() {
        android.widget.Toast.makeText(this, "Loading streams...", android.widget.Toast.LENGTH_SHORT).show()
        val btn = findViewById<Button>(R.id.btnPlay)
        btn.text = "Loading..."
        findViewById<TextView>(R.id.tvPlayText)?.text = "LOADING..."
        findViewById<TextView>(R.id.tvPlayText)?.text = "LOADING..."
        scope.launch {
            val collectors: List<suspend () -> List<StreamOption>> = listOf(
                { collectAoneroomStreams() },
                { collectPrimeStreams() },
                { collectVidLinkStreams() },
                { collectEasyplexStreams() }
            )
            var options = emptyList<StreamOption>()
            while (sourceIndex < collectors.size) {
                android.widget.Toast.makeText(this@DetailActivity, "Trying source " + (sourceIndex + 1) + "/" + collectors.size, android.widget.Toast.LENGTH_SHORT).show()
                android.widget.Toast.makeText(this@DetailActivity, "Trying source " + (sourceIndex + 1) + "/" + collectors.size, android.widget.Toast.LENGTH_SHORT).show()
                try {
                    options = kotlinx.coroutines.withTimeout(8000) { kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) { collectors[sourceIndex]() } }
                } catch (t: Throwable) {
                    android.util.Log.e("Reezn", "source $sourceIndex failed", t)
                    options = emptyList()
                }
                if (options.isNotEmpty()) break
                sourceIndex++
            }
            btn.text = "▶ PLAY"
            findViewById<TextView>(R.id.tvPlayText)?.text = "PLAY"
            findViewById<TextView>(R.id.tvPlayText)?.text = "PLAY"
            if (options.isEmpty()) {
                sourceIndex = 0
                ModernDialog.show(this@DetailActivity,
                    icon = android.R.drawable.ic_dialog_alert,
                    title = "Playback Unavailable",
                    message = "No streams available for this title.",
                    okText = "OK")
                return@launch
            }
            val used = sourceIndex
            StreamBus.extra = emptyList()
            scope.launch {
                val rest = mutableListOf<StreamOption>()
                for (i in collectors.indices) {
                    if (i == used) continue
                    try { rest.addAll(kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) { collectors[i]() }) } catch (t: Throwable) { }
                }
                StreamBus.extra = rest
                android.util.Log.d("Reezn", "background sources ready: " + rest.size)
            }
            openPlayer(options, 0)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: android.content.Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 777) {
            if (resultCode == 998) {          // player exhausted -> next source
                sourceIndex++
                startPlayback()
            } else if (resultCode == 997) {  // played fine -> reset chain
                sourceIndex = 0
            }
        }
    }

    private suspend fun collectStreams(): List<StreamOption> {
        val out = mutableListOf<StreamOption>()

        if (aoneroomOnly) {
            out.addAll(collectAoneroomStreams())
        } else {
            out.addAll(collectPrimeStreams())
            out.addAll(collectAoneroomStreams())
            out.addAll(collectEasyplexStreams())
            out.addAll(collectVidLinkStreams())
        }
        return out
    }

    private suspend fun collectPrimeStreams(): List<StreamOption> {
        val out = mutableListOf<StreamOption>()

        val imdbId = try {
            val details = Api.get("${Api.BASE}/${item.type}/${item.id}?api_key=${Api.TMDB_KEY}")
            details?.optString("imdb_id", "") ?: ""
        } catch (e: Exception) { "" }

        var url = "${Api.PRIME}?action=play&tmdb=${item.id}&imdb=$imdbId&type=${item.type}&title=${Api.enc(item.title)}&year=${item.year}"
        if (item.type == "tv") url += "&se=$currentSeason&ep=$currentEpisode"
        val play = Api.get(url, prime = true)
        if (play == null) {
            errorMessages.add("PrimeOTT: connection failed")
            return out
        }
        if (!play.optBoolean("success", false)) {
            val code = play.optString("code", "")
            val message = play.optString("message", "no reason given").take(120)
            errorMessages.add("PrimeOTT: ${if (code.isNotEmpty()) "$code — " else ""}$message")
            return out
        }

        val mbox = play.optString("mbox_id", "")
        if (mbox.isNotEmpty()) {
            val detail = Api.get("${Api.PRIME}?action=detail&id=$mbox", prime = true)
            val variants = detail?.optJSONObject("detail")?.optJSONArray("variants")
            if (variants != null) {
                for (i in 0 until variants.length()) {
                    val v = variants.getJSONObject(i)
                    val sid = v.optString("subjectId", "")
                    if (sid.isEmpty()) continue
                    val name = v.optString("name", "")
                    val code = v.optString("code", "")
                    val isOriginal = v.optBoolean("original", false) || name.contains("Original", true)
                    val isArabic = name.contains("Arabic", true) || code == "ar"
                    if (!isOriginal && !isArabic) continue
                    var vurl = "${Api.PRIME}?action=play&id=$sid"
                    if (item.type == "tv") vurl += "&se=$currentSeason&ep=$currentEpisode"
                    val vp = Api.get(vurl, prime = true) ?: continue
                    addPrimeStreams(vp, name, out)
                }
            }
        }
        return out
    }

    private fun addPrimeStreams(json: JSONObject, label: String, out: MutableList<StreamOption>) {
        val arr = json.optJSONArray("streams") ?: return
        for (i in 0 until arr.length()) {
            val s = arr.getJSONObject(i)
            out.add(StreamOption(
                quality = s.optString("quality", "?"),
                format = s.optString("format", "?"),
                url = s.optString("url", ""),
                cookie = s.optString("cookie", ""),
                label = label
            ))
        }
    }

    private suspend fun collectAoneroomStreams(): List<StreamOption> {
        val out = mutableListOf<StreamOption>()
        try {
            val subjects = if (aoneroomOnly && aoneroomSubjectId.isNotEmpty()) {
                listOf(JSONObject()
                    .put("subjectId", aoneroomSubjectId)
                    .put("title", item.title)
                    .put("subjectType", if (item.type == "tv") 2 else 1))
            } else {
                AoneroomApi.search(item.title)
            }
            if (subjects.isEmpty()) {
                errorMessages.add("Aoneroom: no results for '${item.title}'")
                return out
            }

            val match = if (item.type == "tv") {
                subjects.firstOrNull { s ->
                    s.optInt("subjectType", 0) == 2 && s.optInt("season", 0) == currentSeason
                } ?: subjects.firstOrNull { s ->
                    s.optInt("subjectType", 0) == 2 &&
                    s.optString("title", "").contains(item.title, ignoreCase = true)
                }
            } else {
                subjects.firstOrNull { s ->
                    s.optInt("subjectType", 0) == 1 &&
                    s.optString("title", "").equals(item.title, ignoreCase = true)
                } ?: subjects.firstOrNull { s ->
                    s.optInt("subjectType", 0) == 1 &&
                    s.optString("title", "").contains(item.title, ignoreCase = true)
                }
            }

            if (match == null) {
                errorMessages.add("Aoneroom: '${item.title}' not found in catalog")
                return out
            }

            val subjectId = match.optString("subjectId", "")
            if (subjectId.isEmpty()) return out

            val resources = AoneroomApi.getResource(subjectId, currentSeason, currentEpisode)
            for (res in resources) {
                val resolution = res.optInt("resolution", 0)
                val resourceLink = res.optString("resourceLink", "")
                if (resourceLink.isNotEmpty() && resolution > 0) {
                    out.add(StreamOption(
                        quality = resolution.toString(),
                        format = "MP4",
                        url = resourceLink,
                        cookie = "",
                        label = "Aoneroom"
                    ))
                }
            }

            val streams = AoneroomApi.getPlayInfo(subjectId, currentSeason, currentEpisode)
            for (stream in streams) {
                val url = stream.optString("url", "")
                val resolutions = stream.optString("resolutions", "")
                val cookie = stream.optString("signCookie", "")
                if (url.isNotEmpty()) {
                    val resList = resolutions.split(",").mapNotNull { it.toIntOrNull() }
                    if (resList.isEmpty()) {
                        out.add(StreamOption("Auto", stream.optString("format", "DASH"), url, cookie, "Aoneroom"))
                    } else {
                        for (res in resList) {
                            out.add(StreamOption(res.toString(), stream.optString("format", "DASH"), url, cookie, "Aoneroom"))
                        }
                    }
                }
            }

            if (out.isEmpty()) {
                errorMessages.add("Aoneroom: matched '${match.optString("title")}' but no playable streams")
            }
        } catch (e: Exception) {
            Log.e("DetailActivity", "Aoneroom error: ${e.message}", e)
            errorMessages.add("Aoneroom: ${e.message ?: "unknown error"}")
        }
        return out
    }

    private suspend fun collectEasyplexStreams(): List<StreamOption> {
        val out = mutableListOf<StreamOption>()
        try {
            if (item.id == 0) {
                errorMessages.add("Easyplex: no TMDB ID")
                return out
            }

            val videos = EasyplexApi.getSources(
                tmdbId = item.id,
                title = item.title,
                type = item.type,
                season = if (item.type == "tv") currentSeason else 0,
                episode = if (item.type == "tv") currentEpisode else 0
            )

            if (videos.isEmpty()) {
                errorMessages.add("Easyplex: no resolved sources for '${item.title}'")
                return out
            }

            for (v in videos) {
                val link = v.optString("link", "")
                if (link.isEmpty()) continue

                val server = v.optString("server", "Unknown")
                val lang = v.optString("lang", "")
                val header = v.optString("header", "")
                val ua = v.optString("useragent", "")
                val hd = v.optInt("hd", 0)

                val quality = when {
                    server.contains("1080") -> "1080"
                    server.contains("720") -> "720"
                    server.contains("480") -> "480"
                    server.contains("360") -> "360"
                    hd == 1 -> "HD"
                    else -> "?"
                }

                val format = when {
                    link.contains(".m3u8") -> "HLS"
                    link.contains(".mp4") -> "MP4"
                    link.contains(".mpd") -> "DASH"
                    else -> "Video"
                }

                val langTag = if (lang.isNotEmpty()) " ($lang)" else ""
                val label = "Easyplex - $server$langTag"

                out.add(StreamOption(
                    quality = quality,
                    format = format,
                    url = link,
                    cookie = "",
                    label = label,
                    referer = header,
                    useragent = ua
                ))
            }

            Log.d("DetailActivity", "Easyplex: ${out.size} sources added")
        } catch (e: Exception) {
            Log.e("DetailActivity", "Easyplex error: ${e.message}", e)
            errorMessages.add("Easyplex: ${e.message ?: "unknown error"}")
        }
        return out
    }

    private suspend fun collectVidLinkStreams(): List<StreamOption> {
        val out = mutableListOf<StreamOption>()
        try {
            if (item.id == 0) {
                errorMessages.add("VidLink: no TMDB ID")
                return out
            }

            val streams = VidLinkApi.getStreams(
                tmdbId = item.id,
                type = item.type,
                season = if (item.type == "tv") currentSeason else 0,
                episode = if (item.type == "tv") currentEpisode else 0
            )

            if (streams.isEmpty()) {
                errorMessages.add("VidLink: no streams available")
                return out
            }

            out.addAll(streams)
            Log.d("DetailActivity", "VidLink: ${streams.size} streams added")
        } catch (e: Exception) {
            Log.e("DetailActivity", "VidLink error: ${e.message}", e)
            errorMessages.add("VidLink: ${e.message ?: "unknown error"}")
        }
        return out
    }

    private fun openPlayer(options: List<StreamOption>, index: Int) {
        val arr = JSONArray()
        options.forEach { o ->
            arr.put(JSONObject()
                .put("quality", o.quality)
                .put("format", o.format)
                .put("url", o.url)
                .put("cookie", o.cookie)
                .put("label", o.label)
                .put("referer", o.referer)
                .put("useragent", o.useragent))
        }
        val label = if (item.type == "tv") "${item.title} • S${currentSeason}E${currentEpisode}" else item.title

        scope.launch {
            val imdb = if (!aoneroomOnly) {
                withContext(Dispatchers.IO) {
                    if (item.type == "tv")
                        SubtitleManager.fetchImdbId("tv", item.id, currentSeason, currentEpisode)
                    else
                        SubtitleManager.fetchImdbId("movie", item.id)
                }
            } else null

            startActivityForResult(Intent(this@DetailActivity, PlayerActivity::class.java)
                .putExtra("streams", arr.toString())
                .putExtra("index", index)
                .putExtra("title", label)
                .putExtra("imdb_id", imdb)
                .putExtra("tmdb_id", item.id)
                .putExtra("show_title", item.title)
                .putExtra("season", currentSeason)
                .putExtra("episode", currentEpisode)
                .putExtra("media_type", item.type), 777)
        }
    }

    private fun loadArabicOverview() {
        val type = intent.getStringExtra("type") ?: "movie"
        val id = intent.getIntExtra("id", 0)
        if (id == 0) return
        scope.launch {
            try {
                val j = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                    Api.get("${Api.BASE}/" + type + "/" + id + "?api_key=${Api.TMDB_KEY}&language=ar-SA")
                }
                val ov = j?.optString("overview", "") ?: ""
                if (ov.isNotBlank()) setOverview(ov)
            } catch (t: Throwable) { }
        }
    }
}
