package com.streamfetcher.app

import android.util.Base64
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.net.URLDecoder
import java.security.MessageDigest
import java.util.concurrent.TimeUnit
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

object AoneroomApi {
    
    private const val BASE_URL = "https://api6.aoneroom.com"
    private const val AUTH_TOKEN = "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1aWQiOjcyMDE5Nzk3MDUzMzQ0MjIyNzIsImV4cCI6MTc5Mzg4NDI2NywiaWF0IjoxNzg2MTA3OTY3fQ.UwK2R0mT_c806Jfajh2zZExVrmAI4-XKTCZQtamQ8Ao"
    private const val GATEWAY_SECRET = "76iRl07s0xSN9jqmEWAt79EBJZulIQIsV64FZr2O"
    private const val CLIENT_BUILD = "1786139801159119980.54df31bb309ad9e1e64e974bbe7c9df4-1786133481475075564.ba69e007c0f48164f9b7fe7aa7382405"
    
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()
    
    private fun getClientInfo(): String {
        return """{"package_name":"com.community.oneroom","version_name":"3.0.16.0727.03","version_code":50020116,"os":"android","os_version":"13","install_ch":"google-play","device_id":"6e8f88a1a81fdbedbdde391a9e9bf4c0","install_store":"gp","gaid":"c3e04f03f3aeb547","brand":"Xiaomi","model":"2107113SG","system_language":"en","net":"NETWORK_WIFI","region":"US","timezone":"Africa/Algiers","sp_code":"63906","X-Child-UID":"","X-Client-Build":"$CLIENT_BUILD","X-Play-Mode":"2","X-Idle-Data":"1","X-Family-Mode":"0","X-Content-Mode":"0"}"""
    }
    
    private fun formatQueryForSignature(query: String?): String {
        if (query.isNullOrEmpty()) return ""
        val params = mutableMapOf<String, String>()
        query.split("&").forEach { pair ->
            val idx = pair.indexOf("=")
            if (idx > 0) {
                try {
                    val key = URLDecoder.decode(pair.substring(0, idx), "UTF-8")
                    val value = URLDecoder.decode(pair.substring(idx + 1), "UTF-8")
                    params[key] = value
                } catch (e: Exception) {}
            }
        }
        return params.toSortedMap().entries.joinToString("&") { "${it.key}=${it.value}" }
    }
    
    private fun generateSignature(
        method: String,
        path: String,
        query: String?,
        contentType: String?,
        body: String?
    ): String {
        val timestamp = System.currentTimeMillis()
        
        val bodyMd5 = if (body.isNullOrEmpty()) {
            ""
        } else {
            val md5 = MessageDigest.getInstance("MD5")
            val digest = md5.digest(body.toByteArray(Charsets.UTF_8))
            digest.joinToString("") { "%02x".format(it) }
        }
        
        val contentLength = if (body.isNullOrEmpty()) "" else body.length.toString()
        val formattedQuery = formatQueryForSignature(query)
        
        val signatureString = buildString {
            append(method.uppercase()).append("\n")
            append("\n")
            append(contentType ?: "").append("\n")
            append(contentLength).append("\n")
            append(timestamp).append("\n")
            append(bodyMd5).append("\n")
            append(path)
            if (formattedQuery.isNotEmpty()) {
                append("?").append(formattedQuery)
            }
        }
        
        val secretBytes = Base64.decode(GATEWAY_SECRET, Base64.DEFAULT)
        val mac = Mac.getInstance("HmacMD5")
        val secretKeySpec = SecretKeySpec(secretBytes, "HmacMD5")
        mac.init(secretKeySpec)
        val signatureBytes = mac.doFinal(signatureString.toByteArray(Charsets.UTF_8))
        val signature = Base64.encodeToString(signatureBytes, Base64.NO_WRAP).trim()
        
        return "$timestamp|2|$signature"
    }
    
    private fun addHeaders(builder: Request.Builder, signature: String, contentType: String? = null) {
        builder.addHeader("host", "api6.aoneroom.com")
            .addHeader("x-child-uid", "")
            .addHeader("x-client-build", CLIENT_BUILD)
            .addHeader("x-play-mode", "2")
            .addHeader("x-idle-data", "1")
            .addHeader("x-family-mode", "0")
            .addHeader("x-content-mode", "0")
            .addHeader("x-client-info", getClientInfo())
            .addHeader("x-client-status", "0")
            .addHeader("x-tr-signature", signature)
            .addHeader("authorization", AUTH_TOKEN)
            .addHeader("user-agent", "com.community.oneroom/50020116 (Linux; U; Android 13; en_US; 2107113SG; Build/TKQ1.220829.002; Cronet/149.0.7827.159)")
            .addHeader("priority", "u=1, i")
            // REMOVED: accept-encoding to avoid compression issues
        if (contentType != null) {
            builder.addHeader("content-type", contentType)
        }
    }
    
    suspend fun search(keyword: String): List<JSONObject> = withContext(Dispatchers.IO) {
        try {
            val path = "/wefeed-mobile-bff/subject-api/search/v2"
            val body = """{"page":1,"perPage":10,"keyword":"$keyword"}"""
            val contentType = "application/json; charset=utf-8"
            val signature = generateSignature("POST", path, null, contentType, body)
            
            val request = Request.Builder()
                .url("$BASE_URL$path")
                .post(body.toRequestBody(contentType.toMediaType()))
                .apply { addHeaders(this, signature, contentType) }
                .build()
            
            val response = client.newCall(request).execute()
            val responseBody = response.body?.string()
            
            Log.d("AoneroomApi", "Search HTTP ${response.code}: ${responseBody?.take(200)}")
            
            if (responseBody.isNullOrEmpty()) {
                Log.e("AoneroomApi", "Empty response body")
                return@withContext emptyList()
            }
            
            val json = JSONObject(responseBody)
            if (json.optInt("code", -1) != 0) {
                Log.e("AoneroomApi", "API error: ${json.optString("reason")}")
                return@withContext emptyList()
            }
            
            val data = json.optJSONObject("data") ?: return@withContext emptyList()
            val results = data.optJSONArray("results") ?: return@withContext emptyList()
            
            val subjects = mutableListOf<JSONObject>()
            for (i in 0 until results.length()) {
                val item = results.getJSONObject(i)
                if (item.optString("topicType") != "SUBJECT") continue
                val subjectsArray = item.optJSONArray("subjects") ?: continue
                for (j in 0 until subjectsArray.length()) {
                    val subject = subjectsArray.getJSONObject(j)
                    val subjectType = subject.optInt("subjectType", 0)
                    if (subjectType == 1 || subjectType == 2) {
                        subjects.add(subject)
                    }
                }
            }
            
            Log.d("AoneroomApi", "Found ${subjects.size} subjects")
            subjects
        } catch (e: Exception) {
            Log.e("AoneroomApi", "Search error: ${e.message}", e)
            emptyList()
        }
    }
    
    suspend fun getResource(subjectId: String, season: Int, episode: Int): List<JSONObject> = withContext(Dispatchers.IO) {
        try {
            val path = "/wefeed-mobile-bff/subject-api/resource"
            val se = if (season > 0) season else 1
            val epFrom = if (episode > 0) episode else 1
            val epTo = epFrom
            val query = "subjectId=$subjectId&page=1&perPage=10&all=0&startPosition=1&endPosition=1&pagerMode=0&resolution=0&se=$se&epFrom=$epFrom&epTo=$epTo"
            val signature = generateSignature("GET", path, query, null, null)
            
            val request = Request.Builder()
                .url("$BASE_URL$path?$query")
                .get()
                .apply { addHeaders(this, signature) }
                .build()
            
            val response = client.newCall(request).execute()
            val responseBody = response.body?.string()
            
            if (responseBody.isNullOrEmpty()) return@withContext emptyList()
            
            val json = JSONObject(responseBody)
            if (json.optInt("code", -1) != 0) return@withContext emptyList()
            
            val data = json.optJSONObject("data") ?: return@withContext emptyList()
            val list = data.optJSONArray("list") ?: return@withContext emptyList()
            
            val resources = mutableListOf<JSONObject>()
            for (i in 0 until list.length()) {
                resources.add(list.getJSONObject(i))
            }
            
            resources
        } catch (e: Exception) {
            Log.e("AoneroomApi", "Resource error: ${e.message}", e)
            emptyList()
        }
    }
    
    suspend fun getPlayInfo(subjectId: String, season: Int, episode: Int): List<JSONObject> = withContext(Dispatchers.IO) {
        try {
            val path = "/wefeed-mobile-bff/subject-api/play-info"
            val se = if (season > 0) season else 0
            val ep = if (episode > 0) episode else 0
            val query = "subjectId=$subjectId&se=$se&ep=$ep"
            val signature = generateSignature("GET", path, query, null, null)
            
            val request = Request.Builder()
                .url("$BASE_URL$path?$query")
                .get()
                .apply { addHeaders(this, signature) }
                .build()
            
            val response = client.newCall(request).execute()
            val responseBody = response.body?.string()
            
            if (responseBody.isNullOrEmpty()) return@withContext emptyList()
            
            val json = JSONObject(responseBody)
            if (json.optInt("code", -1) != 0) return@withContext emptyList()
            
            val data = json.optJSONObject("data") ?: return@withContext emptyList()
            val streamsArray = data.optJSONArray("streams") ?: return@withContext emptyList()
            
            val streams = mutableListOf<JSONObject>()
            for (i in 0 until streamsArray.length()) {
                streams.add(streamsArray.getJSONObject(i))
            }
            
            streams
        } catch (e: Exception) {
            Log.e("AoneroomApi", "PlayInfo error: ${e.message}", e)
            emptyList()
        }
    }
}
