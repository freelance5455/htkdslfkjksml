package com.streamfetcher.app

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.LinearSnapHelper
import androidx.recyclerview.widget.LinearSmoothScroller
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    private val scope = CoroutineScope(Dispatchers.Main + kotlinx.coroutines.SupervisorJob() + kotlinx.coroutines.CoroutineExceptionHandler { _, _ -> })
    private val searchHandler = Handler(Looper.getMainLooper())
    private var currentGridPage = 1
    private var currentGridUrl = ""
    private var isLoadingMore = false
    private var hasMorePages = true
    private val gridItems = mutableListOf<MediaItem>()
    private var gridAdapter: PosterAdapter? = null
    private var paginationAttached = false
    private var currentTab = "home"
    private var isSidebarOpen = false
    private var homeRowId = -1
    private var homePos = 0
    private var activeSide = R.id.sideHome
    private var lastFocusedRowId: Int = -1
    private var lastFocusedPosition: Int = 0

    private var firstLoad = true
    private var searchRunnable: Runnable? = null
    private var isTv = false
    private val rowItems = android.util.SparseArray<List<MediaItem>>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Thread.setDefaultUncaughtExceptionHandler { _, e ->
            try {
                val dir = getExternalFilesDir(null) ?: cacheDir
                java.io.File(dir, "crash.txt").writeText(android.util.Log.getStackTraceString(e))
            } catch (t: Throwable) { }
            android.os.Process.killProcess(android.os.Process.myPid())
        }
        try {
            setContentView(R.layout.activity_main)
        DeviceDetect.announceMode(this)
            // setupRowCentering()
            disableClipping(findViewById(R.id.homeScroll))
         run {
             val clock = findViewById<TextView>(R.id.tvClock)
             val fmt = java.text.SimpleDateFormat("h:mm a", java.util.Locale.getDefault())
             object : Runnable {
                 override fun run() {
                     if (clock == null) return
                     clock.text = fmt.format(java.util.Date())
                     clock.postDelayed(this, 1000)
                 }
             }.also { clock.post(it) }
         }
        findViewById<View>(R.id.sideSearch)?.setOnClickListener { enterSearchMode() }
        MobileHome.setup(this) { enterSearchMode() }
        findViewById<View>(R.id.btnSearchBack)?.setOnClickListener { exitSearchMode() }
        findViewById<View>(R.id.btnSearchClear)?.setOnClickListener { findViewById<EditText>(R.id.etSearch).text.clear() }
        findViewById<EditText>(R.id.etSearch)?.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {
                findViewById<View>(R.id.btnSearchClear).visibility = if (s.isNullOrEmpty()) View.GONE else View.VISIBLE
            }
            override fun afterTextChanged(s: android.text.Editable?) { if (!s.isNullOrEmpty()) doSearch(s.toString()) }
        })
            val uiTv = (resources.configuration.uiMode and
                    android.content.res.Configuration.UI_MODE_TYPE_MASK) ==
                    android.content.res.Configuration.UI_MODE_TYPE_TELEVISION
            val pm = packageManager
            isTv = uiTv
                || pm.hasSystemFeature(android.content.pm.PackageManager.FEATURE_LEANBACK)
                || pm.hasSystemFeature(android.content.pm.PackageManager.FEATURE_TELEVISION)
                || !pm.hasSystemFeature(android.content.pm.PackageManager.FEATURE_TOUCHSCREEN)
            HeroCarousel.setup(this, scope, !isTv)
        // standaloneHeroSync: update hero when focused movie changes (DEBOUNCED 500ms)
        var heroUpdateJob: kotlinx.coroutines.Job? = null
        findViewById<ScrollView>(R.id.homeScroll)?.let { scroll ->
            scroll.viewTreeObserver.addOnGlobalFocusChangeListener { _: View?, newFocus: View? ->
                // Don't update hero during active scrolling to prevent focus stealing
                if (isScrolling) return@addOnGlobalFocusChangeListener
                heroUpdateJob?.cancel()
                heroUpdateJob = scope.launch {
                    // Save all row scroll positions before hero update
                    val rowIds = listOf(R.id.rvContinue, R.id.rvNow, R.id.rvPopularTv, R.id.rvTop, R.id.rvKids, R.id.rvMovieCats, R.id.rvSeriesCats)
                    rowIds.forEach { rvId ->
                        findViewById<RecyclerView>(rvId)?.let { rv ->
                            rowScrollPositions[rvId] = rv.computeHorizontalScrollOffset()
                        }
                    }
                    
                    kotlinx.coroutines.delay(500) // Wait 500ms after last focus change
                    try {
                        val nf = newFocus ?: return@launch
                        var row: RecyclerView? = null
                        var current: View? = nf
                        while (current != null && current !== scroll) {
                            val curr = current
                            if (curr is RecyclerView) { row = curr; break }
                            current = curr.parent as? View
                        }
                        val r = row ?: return@launch
                        val pos = r.getChildAdapterPosition(nf)
                        val item = rowItems[r.id]?.getOrNull(pos)
                        val iid = item?.id?.toString() ?: ""
                        // Only update hero when user is idle (not scrolling)
                        val isAnyRowScrolling = homeRowIds.any { rvId ->
                            findViewById<RecyclerView>(rvId)?.scrollState != RecyclerView.SCROLL_STATE_IDLE
                        }
                        if (!isAnyRowScrolling && item != null && iid.isNotEmpty() && iid != lastFeaturedId) {
                            lastFeaturedId = iid
                            try { HeroCarousel.feature(this@MainActivity, scope, item) } catch (_: Exception) {}
                        }
                    } catch (_: Exception) {}
                }
            }
        } // standaloneHeroSync// standaloneHeroSync
            setupSidebar()
            if (isTv) findViewById<View>(R.id.sideBar)?.visibility = View.VISIBLE
            // Block sidebar focus at startup so content gets focus first
            if (isTv) {
                val sideIds = listOf(R.id.sideSearch, R.id.sideHome, R.id.sideMovies,
                                     R.id.sideSeries, R.id.sideMyList, R.id.sideExit)
                sideIds.forEach { findViewById<View>(it)?.isFocusable = false }
                window.decorView.postDelayed({
                    sideIds.forEach { findViewById<View>(it)?.isFocusable = true }
                }, 1500)
            }

            // Track home row position whenever focus moves on home
            window.decorView.viewTreeObserver.addOnGlobalFocusChangeListener { _, nf ->
                try {
                    val nm = if (nf == null) "null" else nf.javaClass.simpleName + ":" + (if (nf.id == View.NO_ID) "NO_ID" else resources.getResourceEntryName(nf.id))
                    var rvInfo = ""
                    var pv: View? = nf
                    while (pv != null) {
                        if (pv is RecyclerView) { rvInfo = " in rv pos=" + pv.getChildAdapterPosition(nf); break }
                        pv = pv.parent as? View
                    }
                    android.util.Log.d("ROW_DEBUG", "FOCUS -> $nm$rvInfo")
                } catch (_: Exception) {}

                // Netflix-style: scroll so the selected row (with its title) is shown
                try {
                    val rowIds = listOf(R.id.rvContinue, R.id.rvNow, R.id.rvPopularTv, R.id.rvTop, R.id.rvKids, R.id.rvMovieCats, R.id.rvSeriesCats)
                    var pv: View? = nf
                    var rowId = -1
                    while (pv != null) {
                        if (rowIds.contains(pv.id)) { rowId = pv.id; break }
                        pv = pv.parent as? View
                    }
                    if (rowId == -1) {
                        lastAutoRow = -1
                    } else if (rowId != lastAutoRow) {
                        lastAutoRow = rowId
                        val rec = findViewById<RecyclerView>(rowId)
                        val hs = findViewById<android.widget.ScrollView>(R.id.homeScroll)
                        if (rec != null && hs != null) {
                            hs.post {
                                val inner = rec.parent as? android.view.ViewGroup
                                val idx = inner?.indexOfChild(rec) ?: -1
                                val header = if (inner != null && idx > 0) inner.getChildAt(idx - 1) else null
                                val target = header?.top ?: rec.top
                                hs.smoothScrollTo(0, target)
                            }
                        }
                    }
                } catch (_: Exception) {}

                if (currentTab == "home") {
                    var vv: View? = nf
                    while (vv != null) {
                        if (vv is RecyclerView) {
                            val rid = vv.id
                            if (rid == R.id.rvContinue || rid == R.id.rvNow || rid == R.id.rvPopularTv || rid == R.id.rvTop || rid == R.id.rvKids) {
                                val p2 = vv.getChildAdapterPosition(nf)
                                if (p2 >= 0) { homeRowId = rid; homePos = p2 }
                            }
                            break
                        }
                        vv = vv.parent as? View
                    }
                }
            }
            // Prevent focus from going to the hero carousel
                        (findViewById<View>(R.id.heroContainer) as? android.view.ViewGroup)?.descendantFocusability = android.view.ViewGroup.FOCUS_BLOCK_DESCENDANTS
            if (isTv) {
                findViewById<View>(R.id.topBar)?.visibility = View.GONE
                findViewById<View>(R.id.tabsBar)?.visibility = View.GONE
                findViewById<View>(R.id.tvClock)?.visibility = View.GONE
                for (n in listOf("topBar", "tvLogo", "ivLogo", "logo", "btnSearch", "searchBtn",
                                 "topSearch", "headerBar", "logoBar", "homeHeader", "topHeader", "tvClock")) {
                    val rid = resources.getIdentifier(n, "id", packageName)
                    if (rid != 0) findViewById<View>(rid)?.visibility = View.GONE
                }
            }
            if (isTv) {
                findViewById<View>(R.id.topBar)?.visibility = View.GONE
                for (n in listOf("topBar", "tvLogo", "ivLogo", "logo", "btnSearch", "searchBtn",
                                 "topSearch", "headerBar", "logoBar", "homeHeader", "topHeader",
                                 "searchTopRow", "tvClock")) {
                    val rid = resources.getIdentifier(n, "id", packageName)
                    if (rid != 0) findViewById<View>(rid)?.visibility = View.GONE
                }
                findViewById<View>(R.id.tabsBar)?.visibility = View.GONE
            }
            listOf(R.id.tabHome to "home", R.id.tabMovies to "movies",
                   R.id.tabSeries to "series", R.id.tabMyList to "mylist").forEach { (id, tab) ->
                findViewById<TextView>(id)?.setOnClickListener { selectTab(tab) }
            }
            findViewById<TextView>(R.id.btnSeeNow).setOnClickListener { openBrowse("now_playing", 0, "Now Playing Movies") }
            findViewById<TextView>(R.id.btnSeeTv).setOnClickListener { openBrowse("tv_popular", 0, "Popular TV Shows") }
            findViewById<TextView>(R.id.btnSeeTop).setOnClickListener { openBrowse("top_rated", 0, "Top Rated") }
            findViewById<TextView>(R.id.btnSeeKids).setOnClickListener { openBrowse("kids", 0, "Films For Kids & Family") }
            listOf(R.id.btnSeeNow, R.id.btnSeeTv, R.id.btnSeeTop, R.id.btnSeeKids).forEach { id ->
                val v = findViewById<TextView>(id)
                val d = resources.displayMetrics.density
                v.setPadding((10 * d).toInt(), (6 * d).toInt(), (10 * d).toInt(), (6 * d).toInt())
                v.setOnFocusChangeListener { view, focused ->
                    view.background = if (focused) getDrawable(R.drawable.focus_modern) else null
                    v.setTextColor(if (focused) 0xFFFFFFFF.toInt() else 0xFFE50914.toInt())
                    view.animate().scaleX(if (focused) 1.06f else 1f)
                        .scaleY(if (focused) 1.06f else 1f).setDuration(150).start()
                }
            }
            
            // Load home content on startup
            selectTab("home")
            
            val search = findViewById<EditText>(R.id.etSearch)
            search.addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {
                    searchRunnable?.let { searchHandler.removeCallbacks(it) }
                    val q = s?.toString() ?: ""
                    if (q.isBlank()) { selectTab("home"); return }
                    searchRunnable = Runnable { doSearch(q) }
                    searchHandler.postDelayed(searchRunnable!!, 500)
                }
                override fun afterTextChanged(s: android.text.Editable?) {}
            })
            findViewById<View>(R.id.btnBackBrand).setOnClickListener { selectTab(currentTab) }
            selectTab("home")
            loadContinueRow()
        } catch (t: Throwable) { t.printStackTrace() }
    }

    override fun onKeyDown(keyCode: Int, event: android.view.KeyEvent?): Boolean {
        if (currentTab == "home" && TvHome.tryRowJump(this, keyCode)) return true
        // LEFT at real left edge -> jump to Search button in sidebar
        if (isTv && keyCode == android.view.KeyEvent.KEYCODE_DPAD_LEFT) {
            val f = currentFocus

            // Do not intercept if focus is already inside sidebar
            var check: View? = f
            var inSidebar = false
            while (check != null) {
                if (check.id == R.id.sideBar) {
                    inSidebar = true
                    break
                }
                check = check.parent as? View
            }

            if (!inSidebar && f != null) {
                val p = f.parent
                val atEdge = if (p is RecyclerView) {
                    val pos = p.getChildAdapterPosition(f)
                    val lm = p.layoutManager

                    when (lm) {
                        is GridLayoutManager -> {
                            val span = lm.spanCount.coerceAtLeast(1)
                            pos >= 0 && pos % span == 0
                        }
                        is LinearLayoutManager -> {
                            // Horizontal home rows: only item 0 opens sidebar
                            if (lm.orientation == RecyclerView.HORIZONTAL) {
                                pos == 0
                            } else {
                                pos <= 0
                            }
                        }
                        else -> false
                    }
                } else {
                    false
                }

                if (atEdge) {
                    findViewById<View>(R.id.sideSearch)?.requestFocus()
                    return true
                }
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun openTvSearch() {
        val input = EditText(this)
        input.hint = "Search movies & TV…"
        input.setTextColor(-0x1)
        val d = resources.displayMetrics.density
        input.setPadding((16 * d).toInt(), (50 * d).toInt(), (16 * d).toInt(), (50 * d).toInt())
        val bg = android.graphics.drawable.GradientDrawable()
        bg.setColor(0xFF1E1E24.toInt())
        bg.cornerRadius = 10 * d
        input.background = bg
        android.app.AlertDialog.Builder(this)
            .setTitle("Search")
            .setView(input)
            .setPositiveButton("Search") { _, _ ->
                val q = input.text.toString()
                if (q.isNotBlank()) doSearch(q)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private val MOVIE_BRANDS = listOf(
        Brand("Netflix", 0xFFE50914.toInt(), 0, logo = "https://assets.nflxext.com/ffe/siteui/common/icons/nficon2016.ico", provider = 8),
        Brand("Marvel", 0xFFE62429.toInt(), 420, logo = "https://upload.wikimedia.org/wikipedia/commons/thumb/b/b9/Marvel_Logo.svg/320px-Marvel_Logo.svg.png"),
        Brand("DC", 0xFF0476F2.toInt(), 9993, logo = "https://upload.wikimedia.org/wikipedia/commons/thumb/6/69/DC_Comics_logo.svg/320px-DC_Comics_logo.svg.png"),
        Brand("Warner Bros", 0xFF00A8E0.toInt(), 174, logo = "https://upload.wikimedia.org/wikipedia/commons/thumb/1/1e/Warner_Bros._Pictures_logo.svg/320px-Warner_Bros._Pictures_logo.svg.png"),
        Brand("Universal", 0xFFF5C518.toInt(), 33, logo = "https://upload.wikimedia.org/wikipedia/commons/thumb/8/8b/Universal_Pictures_Logo.svg/320px-Universal_Pictures_Logo.svg.png"),
        Brand("Paramount", 0xFF0064FF.toInt(), 4, logo = "https://upload.wikimedia.org/wikipedia/commons/thumb/a/a3/Paramount_Pictures_corporate_logo.svg/320px-Paramount_Pictures_corporate_logo.svg.png"),
        Brand("Disney", 0xFF113CCF.toInt(), 2, logo = "https://upload.wikimedia.org/wikipedia/commons/thumb/3/3e/Disney%2B_logo.svg/200px-Disney%2B_logo.svg.png"),
        Brand("Sony", 0xFF9932CC.toInt(), 34, logo = "https://upload.wikimedia.org/wikipedia/commons/thumb/7/7f/Sony_Pictures_logo.svg/320px-Sony_Pictures_logo.svg.png"),
        Brand("A24", 0xFF00FFAA.toInt(), 41077, logo = "https://upload.wikimedia.org/wikipedia/commons/thumb/2/2e/A24_logo.svg/200px-A24_logo.svg.png")
    )

    private val TV_BRANDS = listOf(
        Brand("Netflix", 0xFFE50914.toInt(), 213, logo = "https://assets.nflxext.com/ffe/siteui/common/icons/nficon2016.ico"),
        Brand("HBO", 0xFF8A2BE2.toInt(), 49, logo = "https://upload.wikimedia.org/wikipedia/commons/thumb/1/17/HBO_Max_Logo.svg/320px-HBO_Max_Logo.svg.png"),
        Brand("Disney+", 0xFF113CCF.toInt(), 2739, logo = "https://upload.wikimedia.org/wikipedia/commons/thumb/3/3e/Disney%2B_logo.svg/200px-Disney%2B_logo.svg.png"),
        Brand("Prime Video", 0xFF00A8E0.toInt(), 1024, logo = "https://upload.wikimedia.org/wikipedia/commons/thumb/1/11/Amazon_Prime_Video_logo.svg/200px-Amazon_Prime_Video_logo.svg.png"),
        Brand("Apple TV+", 0xFFA0A0A0.toInt(), 2552, logo = "https://upload.wikimedia.org/wikipedia/commons/thumb/8/8c/Apple_TV_Plus_Logo.svg/200px-Apple_TV_Plus_Logo.svg.png"),
        Brand("AMC", 0xFF00FFAA.toInt(), 1740, logo = "https://upload.wikimedia.org/wikipedia/commons/thumb/8/8c/AMC_Networks_logo.svg/320px-AMC_Networks_logo.svg.png"),
        Brand("FX", 0xFFF5C518.toInt(), 88, logo = "https://upload.wikimedia.org/wikipedia/commons/thumb/5/52/FX_Networks_logo.svg/320px-FX_Networks_logo.svg.png"),
        Brand("CBS", 0xFF0064FF.toInt(), 16, logo = "https://upload.wikimedia.org/wikipedia/commons/thumb/6/61/CBS_logo.svg/320px-CBS_logo.svg.png")
    )

    private fun brandUrl(tab: String, b: Brand): String {
        val key = Api.TMDB_KEY
        return when {
            tab == "series" ->
                "${Api.BASE}/discover/tv?api_key=$key&include_adult=false&with_networks=${b.id}&include_video=false&language=en-US&sort_by=popularity.desc"
            b.provider != null ->
                "${Api.BASE}/discover/movie?api_key=$key&include_adult=false&with_watch_providers=${b.provider}&watch_region=US&include_video=false&language=en-US&sort_by=popularity.desc"
            else ->
                "${Api.BASE}/discover/movie?api_key=$key&include_adult=false&with_companies=${b.id}&include_video=false&language=en-US&sort_by=popularity.desc"
        }
    }

    private fun selectTab(tab: String) {
        // Remember home row position when leaving home
        if (currentTab == "home" && tab != "home") {
            val foc = currentFocus
            val p = foc?.parent
            if (p is RecyclerView) {
                val pos = p.getChildAdapterPosition(foc)
                if (pos >= 0) { homeRowId = p.id; homePos = pos }
            }
        }
        currentTab = tab
                firstLoad = false
        listOf(R.id.tabHome to "home", R.id.tabMovies to "movies",
               R.id.tabSeries to "series", R.id.tabMyList to "mylist").forEach { (id, t) ->
            val v = findViewById<TextView>(id)
            val active = t == tab
            v.isSelected = active
            v.setTextColor(if (active) 0xFFFFFFFF.toInt() else 0xFF9E9E9E.toInt())
        }
        if (tab == "home") {
            findViewById<View>(R.id.gridContainer)?.visibility = View.GONE
            findViewById<View>(R.id.brandHeader)?.visibility = View.GONE
            findViewById<RecyclerView>(R.id.rvGrid)?.visibility = View.GONE
            findViewById<View>(R.id.homeScroll)?.visibility = View.VISIBLE
            // Park focus ONLY if nothing is focused in a row (prevents stealing browse focus)
            val hs = findViewById<View>(R.id.homeScroll)
            if (!focusInRow() && !focusPlaced) {
                hs?.isFocusable = true
                hs?.requestFocus()
            }
            if (!isTv) {
                findViewById<View>(R.id.topBar)?.visibility = View.VISIBLE
                findViewById<View>(R.id.tabsBar)?.visibility = View.GONE
            }
            loadHome()
            // Return to saved home row, or first item if none
            if (homeRowId != -1 || lastFocusedRowId != -1) {
                val hs = findViewById<View>(R.id.homeScroll)
                hs?.alpha = 0f   // hide during focus shuffle so no flash is visible
                val rowId = if (homeRowId != -1) homeRowId else lastFocusedRowId
                val pos = if (homeRowId != -1) homePos else lastFocusedPosition
                restoreFocusTo(rowId, pos, 300)
                restoreFocusTo(rowId, pos, 1200)
                hs?.postDelayed({
                    hs.animate().alpha(1f).setDuration(150).start()
                }, 450)
            } else {
                findViewById<View>(R.id.homeScroll)?.postDelayed({ focusFirstHomeItem() }, 800)
            }
        } else {
            findViewById<View>(R.id.homeScroll)?.visibility = View.GONE
            findViewById<View>(R.id.gridContainer)?.visibility = View.VISIBLE
            findViewById<View>(R.id.brandHeader)?.visibility = View.GONE
            if (!isTv) {
                findViewById<View>(R.id.topBar)?.visibility = View.VISIBLE
                findViewById<View>(R.id.tabsBar)?.visibility = View.GONE
            }
            val grid = findViewById<RecyclerView>(R.id.rvGrid)
            grid.layoutManager = GridLayoutManager(this, 3)
            val brandsRv = findViewById<RecyclerView>(R.id.rvBrands)
            if (tab == "mylist") {
                brandsRv?.visibility = View.GONE
                grid?.visibility = View.VISIBLE
                findViewById<TextView>(R.id.gridEmpty)?.text = "Your My List is empty.\nLong-press any movie to add it."
                findViewById<TextView>(R.id.gridEmpty)?.visibility = View.GONE
                findViewById<ProgressBar>(R.id.gridProgress)?.visibility = View.GONE
                val myItems = Library.myList(this)
                if (myItems.isEmpty()) {
                    grid?.visibility = View.GONE
                    findViewById<TextView>(R.id.gridEmpty)?.visibility = View.VISIBLE
                } else {
                    grid.adapter = GridAdapter(myItems, { openDetail(it) }, true)
                    grid.postDelayed({
                        grid.layoutManager?.findViewByPosition(0)?.requestFocus()
                    }, 300)
                }
            } else {
                brandsRv?.visibility = View.VISIBLE
                brandsRv?.layoutManager = LinearLayoutManager(this, RecyclerView.HORIZONTAL, false)
                brandsRv?.adapter = BrandAdapter(if (tab == "movies") MOVIE_BRANDS else TV_BRANDS) { b ->
                    loadGrid(brandUrl(tab, b))
                }
                loadGrid(if (tab == "movies")
                    "${Api.BASE}/movie/popular?api_key=${Api.TMDB_KEY}"
                else
                    "${Api.BASE}/tv/popular?api_key=${Api.TMDB_KEY}")
            }
        }
    }
    
    private fun setFocusOnGrid(grid: RecyclerView, position: Int) {
        grid.postDelayed({
            val item = grid.layoutManager?.findViewByPosition(position)
            if (item != null) {
                item.requestFocus()
                item.animate().scaleX(1.05f).scaleY(1.05f).setDuration(200).start()
                val cardPoster = item.findViewById<View>(R.id.cardPoster)
                if (cardPoster != null) {
                    val drawable = cardPoster.foreground
                    if (drawable is android.graphics.drawable.StateListDrawable) {
                        drawable.state = intArrayOf(android.R.attr.state_focused)
                        drawable.invalidateSelf()
                    }
                }
            }
        }, 400)
    }

    private fun doSearch(q: String) {
        if (q.isBlank()) return
        val grid = findViewById<RecyclerView>(R.id.rvGrid)
        val prog = findViewById<View>(R.id.gridProgress)
        val empty = findViewById<View>(R.id.gridEmpty)
        prog?.visibility = View.VISIBLE
        empty?.visibility = View.GONE
        scope.launch {
            try {
                val j = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                    Api.get("${Api.BASE}/search/multi?api_key=${Api.TMDB_KEY}&include_adult=false&query=" + android.net.Uri.encode(q))
                }
                val arr = j?.optJSONArray("results")
                val items = mutableListOf<MediaItem>()
                if (arr != null) for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val t = o.optString("media_type")
                    if (t != "movie" && t != "tv") continue
                    if (o.optString("poster_path").isEmpty()) continue
                    items.add(MediaItem(o.optInt("id"),
                        if (t == "tv") o.optString("name") else o.optString("title"),
                        o.optString(if (t == "tv") "first_air_date" else "release_date", "").take(4),
                        o.optString("poster_path"), o.optString("backdrop_path"), t,
                        o.optDouble("vote_average")))
                }
                prog?.visibility = View.GONE
                empty?.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
                grid?.visibility = View.VISIBLE
            grid?.layoutManager = androidx.recyclerview.widget.GridLayoutManager(this@MainActivity, if (isTv) 6 else 3)
                grid?.adapter = PosterAdapter(items, R.layout.item_poster) { openDetail(it) }
            if (grid != null && grid.itemDecorationCount == 0) {
                val sp = (12 * resources.displayMetrics.density).toInt()
                grid.addItemDecoration(object : androidx.recyclerview.widget.RecyclerView.ItemDecoration() {
                    override fun getItemOffsets(outRect: android.graphics.Rect, view: View, parent: androidx.recyclerview.widget.RecyclerView, state: androidx.recyclerview.widget.RecyclerView.State) {
                        outRect.set(sp / 2, sp / 2, sp / 2, sp)
                    }
                })
            }
            } catch (t: Throwable) {
                prog?.visibility = View.GONE
                android.widget.Toast.makeText(this@MainActivity, "ERR " + t, android.widget.Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun loadGrid(url: String, append: Boolean = false) {
        if (isLoadingMore) return
        isLoadingMore = true
        scope.launch {
            try {
                val pageUrl = if (append) url + "&page=" + currentGridPage else url + "&page=1"
                val json = withContext(Dispatchers.IO) { Api.get(pageUrl) }
                val newItems = parseMulti(json)
                val grid = findViewById<RecyclerView>(R.id.rvGrid)
                val progress = findViewById<ProgressBar>(R.id.gridProgress)
                val empty = findViewById<TextView>(R.id.gridEmpty)
                if (!append) {
                    grid?.layoutManager = GridLayoutManager(this@MainActivity, if (isTv) 6 else 3)
                    gridItems.clear()
                    gridItems.addAll(newItems)
                    gridAdapter = PosterAdapter(gridItems, R.layout.item_grid_poster) { openDetail(it) }
                    grid?.adapter = gridAdapter
                    grid?.postDelayed({
                        grid.layoutManager?.findViewByPosition(0)?.requestFocus()
                    }, 300)
                    currentGridUrl = url
                    currentGridPage = 1
                    if (grid != null) setupPagination(grid)
                } else {
                    val start = gridItems.size
                    gridItems.addAll(newItems)
                    gridAdapter?.notifyItemRangeInserted(start, newItems.size)
                }
                hasMorePages = newItems.size >= 20
                if (newItems.isNotEmpty()) currentGridPage++
                progress?.visibility = View.GONE
                isLoadingMore = false
                if (!append && newItems.isEmpty()) {
                    grid?.visibility = View.GONE
                    empty?.visibility = View.VISIBLE
                    empty?.text = when {
                        json == null -> "Network error"
                        json.has("status_message") -> json.optString("status_message")
                        else -> "No results for this brand"
                    }
                } else {
                    grid?.visibility = View.VISIBLE
                    empty?.visibility = View.GONE
                }
            } catch (t: Throwable) {
                isLoadingMore = false
                if (!append) {
                    findViewById<ProgressBar>(R.id.gridProgress)?.visibility = View.GONE
                    findViewById<TextView>(R.id.gridEmpty)?.visibility = View.VISIBLE
                    findViewById<TextView>(R.id.gridEmpty)?.text = "Error: " + t.message
                    findViewById<RecyclerView>(R.id.rvGrid)?.visibility = View.GONE
                }
            }
        }
    }

    private fun setupPagination(grid: RecyclerView) {
        if (paginationAttached) return
        paginationAttached = true
        grid.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(rv: RecyclerView, dx: Int, dy: Int) {
                super.onScrolled(rv, dx, dy)
                if (!hasMorePages || isLoadingMore) return
                val lm = rv.layoutManager as GridLayoutManager
                if (lm.childCount + lm.findFirstVisibleItemPosition() >= lm.itemCount - 10)
                    loadGrid(currentGridUrl, true)
            }
        })
    }

    private fun row(rv: Int, items: List<MediaItem>) {
        rowItems.put(rv, items)
        val rec = findViewById<RecyclerView>(rv) ?: return
        if (!loggedScrollRows.contains(rv)) {
            rec.adapter?.registerAdapterDataObserver(object : RecyclerView.AdapterDataObserver() {
                private fun log(msg: String) {
                    android.util.Log.d("JUMP_TRACE", "ADAPTER rv=$rv $msg caller=" +
                        Thread.currentThread().stackTrace.drop(4).take(14).joinToString("/") {
                            it.className.substringAfterLast('.') + "." + it.methodName
                        })
                }
                override fun onChanged() { log("onChanged") }
                override fun onItemRangeChanged(a: Int, b: Int) { log("rangeChanged $a+$b") }
                override fun onItemRangeInserted(a: Int, b: Int) { log("inserted $a+$b") }
                override fun onItemRangeRemoved(a: Int, b: Int) { log("removed $a+$b") }
                override fun onItemRangeMoved(a: Int, b: Int, c: Int) { log("moved") }
            })
            loggedScrollRows.add(rv)
            rec.addOnScrollListener(object : RecyclerView.OnScrollListener() {
                override fun onScrollStateChanged(rv2: RecyclerView, st: Int) {
                    if (st == RecyclerView.SCROLL_STATE_SETTLING) {
                        android.util.Log.d("ROW_SCROLL", "id=${rv2.id} SETTLING! caller=" +
                            Thread.currentThread().stackTrace.drop(4).take(12).joinToString("/") { it.methodName })
                    }
                }
                override fun onScrolled(rv2: RecyclerView, dx: Int, dy: Int) {
                    android.util.Log.d("ROW_SCROLL", "id=${rv2.id} offset=${rv2.computeHorizontalScrollOffset()} dx=$dx")
                    if (kotlin.math.abs(dx) > 200) {
                        android.util.Log.d("ROW_SCROLL", " BIG JUMP dx=$dx caller=" +
                            Thread.currentThread().stackTrace.drop(3).take(16).joinToString("/") {
                                it.className.substringAfterLast('.') + "." + it.methodName
                            })
                    }
                }
            })
        }
        
        // Only setup layout/adapter once (first time)
        if (rec.layoutManager == null) {
            rec.layoutManager = CenterLayoutManager(this@MainActivity)
            rec.adapter = PosterAdapter(items, R.layout.item_poster) { openDetail(it) }
        } else {
            // SKIP update if data is identical (prevents focus destroy + jump)
            val old = rowItems.get(rv)
            if (old != null && old.size == items.size && old.indices.all { old[it].id == items[it].id }) {
                android.util.Log.d("ROW_DEBUG", "Same data for id=$rv -> SKIP update (no jump)")
                return
            }
            android.util.Log.d("ROW_DEBUG", "Data changed for id=$rv -> update with focus save")
            val lm = rec.layoutManager as? androidx.recyclerview.widget.LinearLayoutManager
            val hadFocus = rec.hasFocus()
            val pos = lm?.findFirstVisibleItemPosition() ?: 0
            (rec.adapter as? PosterAdapter)?.updateItems(items)
            rec.post {
                android.util.Log.d("JUMP_TRACE", "row() update jump pos=$pos")
                (rec.layoutManager as? androidx.recyclerview.widget.LinearLayoutManager)?.scrollToPositionWithOffset(pos, 100)
                if (hadFocus) rec.layoutManager?.findViewByPosition(pos)?.requestFocus()
            }
        }
        
    }

    private fun loadContinueRow() {
        val rvId = resources.getIdentifier("rvContinue", "id", packageName)
        if (rvId == 0) return
        val rv = findViewById<RecyclerView>(rvId) ?: return
        val list = ProgressStore.getContinueList(this)
        if (list.isEmpty()) { rv.visibility = View.GONE; findViewById<View>(R.id.hdrContinue)?.visibility = View.GONE; return }
        findViewById<View>(R.id.hdrContinue)?.visibility = View.VISIBLE
        rv.visibility = View.VISIBLE
        rv.layoutManager = CenterLayoutManager(this)
        scope.launch {
            val media = mutableListOf<MediaItem>()
            for (pr in list) {
                val url = if (pr.type == "movie")
                    "${Api.BASE}/movie/${pr.id}?api_key=${Api.TMDB_KEY}"
                else "${Api.BASE}/tv/${pr.id}?api_key=${Api.TMDB_KEY}"
                val j = withContext(Dispatchers.IO) { Api.get(url) }
                media.add(MediaItem(pr.id, pr.title, "",
                    j?.optString("poster_path") ?: "", j?.optString("backdrop_path") ?: "",
                    pr.type, 0.0))
            }
            rv.adapter = ContinueAdapter2(media, list) { m, _ -> openDetail(m) }
        }
    }

    private fun loadHome() {
        // HARD THROTTLE: max once per 60s
        val now = android.os.SystemClock.elapsedRealtime()
        if (rowItems.get(R.id.rvNow) != null && (now - lastHomeLoad) < 60000) {
            android.util.Log.d("ROW_DEBUG", "loadHome BLOCKED (${now - lastHomeLoad}ms since last)")
            return
        }
        lastHomeLoad = now
        android.util.Log.d("ROW_DEBUG", "loadHome running")
        // Throttle: don't reload home more than once per 60s
        if (rowItems.get(R.id.rvNow) != null && (android.os.SystemClock.elapsedRealtime() - lastHomeLoad) < 60000) {
            android.util.Log.d("ROW_DEBUG", "loadHome throttled (loaded ${android.os.SystemClock.elapsedRealtime() - lastHomeLoad}ms ago)")
            return
        }
        lastHomeLoad = android.os.SystemClock.elapsedRealtime()
        // NEVER refresh while user is browsing rows (prevents jump to first)
        var cf: View? = currentFocus
        while (cf != null) {
            val cid = cf.id
            if (cid == R.id.rvContinue || cid == R.id.rvNow || cid == R.id.rvPopularTv || cid == R.id.rvTop || cid == R.id.rvKids) return
            cf = cf.parent as? View
        }
        scope.launch {
            val hero = withContext(Dispatchers.IO) { Api.get("${Api.BASE}/trending/movie/week?api_key=${Api.TMDB_KEY}") }
            val now = withContext(Dispatchers.IO) { Api.get("${Api.BASE}/movie/now_playing?api_key=${Api.TMDB_KEY}") }
            val tv = withContext(Dispatchers.IO) { Api.get("${Api.BASE}/tv/popular?api_key=${Api.TMDB_KEY}") }
            val top = withContext(Dispatchers.IO) { Api.get("${Api.BASE}/movie/top_rated?api_key=${Api.TMDB_KEY}") }
            val kids = withContext(Dispatchers.IO) { Api.get("${Api.BASE}/discover/movie?api_key=${Api.TMDB_KEY}&with_genres=10751&sort_by=popularity.desc") }
            row(R.id.rvNow, parseMulti(now))
            row(R.id.rvPopularTv, parseMulti(tv))
            row(R.id.rvTop, parseMulti(top))
            row(R.id.rvKids, parseMulti(kids))
                        if (!focusInRow()) (rowItems.get(R.id.rvNow)?.firstOrNull())?.let { try { HeroCarousel.feature(this@MainActivity, scope, it) } catch (t: Throwable) { } }
            val cont = withContext(Dispatchers.IO) { Library.continueList(this@MainActivity) }
            if (cont.isNotEmpty()) {
                findViewById<View>(R.id.hdrContinue)?.visibility = View.VISIBLE
                val entries = mutableListOf<Pair<Library.ContinueItem, String?>>()
                withContext(Dispatchers.IO) {
                    for (c in cont.take(10)) {
                        val d = Api.get("${Api.BASE}/${c.type}/${c.id}?api_key=${Api.TMDB_KEY}")
                        entries.add(c to d?.optString("poster_path"))
                    }
                }
                findViewById<RecyclerView>(R.id.rvContinue).apply {
                    if (layoutManager == null) layoutManager = CenterLayoutManager(this@MainActivity)
                    if (adapter == null) adapter = ContinueAdapter(entries) { c ->
                        openDetail(MediaItem(c.id, c.title, "", null, null, c.type, 0.0))
                    }
                }
            }
            val movieCats = listOf("Action" to 28, "Adventure" to 12, "Animation" to 16,
                "Comedy" to 35, "Crime" to 80, "Drama" to 18, "Fantasy" to 14,
                "Horror" to 27, "Romance" to 10749, "Sci-Fi" to 878, "Thriller" to 53)
            val tvCats = listOf("Action & Adventure" to 10759, "Animation" to 16,
                "Comedy" to 35, "Crime" to 80, "Drama" to 18, "Family" to 10751,
                "Kids" to 10762, "Mystery" to 9648, "Sci-Fi & Fantasy" to 10765)
            findViewById<RecyclerView>(R.id.rvMovieCats).apply {
                if (layoutManager == null) layoutManager = CenterLayoutManager(this@MainActivity)
                if (adapter == null) adapter = ChipAdapter(movieCats) { g -> openBrowse("genre_movie", g.second, g.first + " Movies") }
            }
            findViewById<View>(R.id.homeScroll).post {
            }
            findViewById<RecyclerView>(R.id.rvSeriesCats).apply {
                if (layoutManager == null) layoutManager = CenterLayoutManager(this@MainActivity)
                if (adapter == null) adapter = ChipAdapter(tvCats) { g -> openBrowse("genre_tv", g.second, g.first + " Series") }
            }
            
            // All home data loaded - restore saved position or first item
            findViewById<View>(R.id.homeScroll)?.post {
                // Only place focus at startup (when focus is nowhere). Never steal.
                val inRow = focusInRow()
                val unset = focusIsUnset()
                android.util.Log.d("ROW_DEBUG", "Post block: focusInRow=$inRow unset=$unset")
                if (inRow || userNavigated) return@post
                
                if (homeRowId != -1) {
                    restoreFocusTo(homeRowId, homePos, 100)
                } else {
                    focusFirstHomeItem()
                }
            }
        }
    
            }

    override fun dispatchKeyEvent(event: android.view.KeyEvent): Boolean {
        if (event.action == android.view.KeyEvent.ACTION_DOWN) userNavigated = true
        return super.dispatchKeyEvent(event)
    }

    private fun disableClipping(v: View) {
        if (v.id == R.id.heroRoot) return
        if (v is android.view.ViewGroup) {
            v.clipChildren = false
            v.clipToPadding = false
            for (i in 0 until v.childCount) disableClipping(v.getChildAt(i))
        }
    }





    private fun setupSidebar() {
        val items = listOf(
            R.id.sideHome to "home",
            R.id.sideMovies to "movies",
            R.id.sideSeries to "series",
            R.id.sideMyList to "mylist"
        )
        items.forEach { (id, tab) ->
            val v = findViewById<ImageView>(id)
            v?.setOnFocusChangeListener { view, focused ->
                view.animate().scaleX(if (focused) 1.05f else 1f)
                    .scaleY(if (focused) 1.05f else 1f).setDuration(150).start()
                (view as ImageView).setColorFilter(if (focused) 0xFFFFFFFF.toInt() else 0xFF9E9E9E.toInt())
            }
            v?.setOnClickListener {
                activeSide = id
                updateSideHighlight()
                selectTab(tab)
                hideSidebar()
            }
        }
        findViewById<ImageView>(R.id.sideSearch)?.setOnClickListener {
            enterSearchMode()
            hideSidebar()
        }
        findViewById<ImageView>(R.id.sideExit)?.setOnClickListener {
            android.app.AlertDialog.Builder(this)
                .setTitle("Exit PrimeFlix?")
                .setMessage("Do you want to exit the app?")
                .setPositiveButton("Exit") { _, _ -> finish() }
                .setNegativeButton("Cancel", null)
                .show()
        }
        updateSideHighlight()
    }


    private fun updateSideHighlight() {
        listOf(R.id.sideHome, R.id.sideMovies, R.id.sideSeries, R.id.sideMyList).forEach { id ->
            findViewById<ImageView>(id)?.setColorFilter(if (id == activeSide) 0xFFFFFFFF.toInt() else 0xFF9E9E9E.toInt())
        }
    }







    private fun focusFirstHomeItem() {
        android.util.Log.d("ROW_DEBUG", "focusFirstHomeItem called, focusInRow=${focusInRow()} unset=${focusIsUnset()}")
        var cf: View? = currentFocus
        while (cf != null) {
            val cid = cf.id
            if (cid == R.id.rvContinue || cid == R.id.rvNow || cid == R.id.rvPopularTv || cid == R.id.rvTop || cid == R.id.rvKids) return
            cf = cf.parent as? View
        }
        if (focusPlaced) return  // already placed once -> never again
        if (userNavigated) return  // user pressed keys -> never steal focus
        val rows = listOf(R.id.rvContinue, R.id.rvNow, R.id.rvPopularTv, R.id.rvTop, R.id.rvKids)
        for (rid in rows) {
            val rv = findViewById<RecyclerView>(rid)
            if (rv != null && rv.visibility == View.VISIBLE && (rv.adapter?.itemCount ?: 0) > 0) {
                rv.layoutManager?.findViewByPosition(0)?.requestFocus()
                focusPlaced = true
                return
            }
        }
    }

    private fun restoreFocusTo(rowId: Int, pos: Int, delay: Long) {
        android.util.Log.d("ROW_DEBUG", "restoreFocusTo called: rowId=$rowId pos=$pos delay=$delay focusInRow=${focusInRow()}")
        if (rowId == -1) return
        val rv = findViewById<RecyclerView>(rowId) ?: return
        if (rv.visibility != View.VISIBLE) return
        rv.postDelayed({
            val lm = rv.layoutManager
            if (lm is androidx.recyclerview.widget.LinearLayoutManager) {
                android.util.Log.d("JUMP_TRACE", "restoreFocusTo jump row=$rowId pos=$pos")
                lm.scrollToPositionWithOffset(pos, 100)
            } else {
                lm?.scrollToPosition(pos)
            }
            rv.postDelayed({
                lm?.findViewByPosition(pos)?.requestFocus()
            }, 250)
        }, delay)
    }

    private fun restoreSavedFocus(delay: Long) {
        if (lastFocusedRowId == -1) return
        val rv = findViewById<RecyclerView>(lastFocusedRowId) ?: return
        if (rv.visibility != View.VISIBLE) return
        rv.postDelayed({
            val lm = rv.layoutManager
            if (lm is androidx.recyclerview.widget.LinearLayoutManager) {
                android.util.Log.d("JUMP_TRACE", "restoreSavedFocus jump pos=$lastFocusedPosition")
                lm.scrollToPositionWithOffset(lastFocusedPosition, 100)
            } else {
                lm?.scrollToPosition(lastFocusedPosition)
            }
            rv.postDelayed({
                val child = lm?.findViewByPosition(lastFocusedPosition)
                if (child != null) {
                    child.requestFocus()
                }
            }, 250)
        }, delay)
    }

    private fun hideSidebar() {
        // Sidebar is always visible on TV - nothing to hide
        findViewById<View>(R.id.mainContent)?.alpha = 1f
    }

    private fun openBrowse(mode: String, genreId: Int, title: String) {
        // Save current home position before leaving
        val foc = currentFocus
        if (foc != null) {
            var v: View? = foc
            while (v != null) {
                if (v is RecyclerView && (v.id == R.id.rvContinue || v.id == R.id.rvNow ||
                    v.id == R.id.rvPopularTv || v.id == R.id.rvTop || v.id == R.id.rvKids)) {
                    val pos = v.getChildAdapterPosition(foc)
                    if (pos >= 0) { homeRowId = v.id; homePos = pos }
                    break
                }
                v = v.parent as? View
            }
        }
        if (homeRowId != -1) {
            lastFocusedRowId = homeRowId
            lastFocusedPosition = homePos
        }
        startActivity(Intent(this, BrowseActivity::class.java)
            .putExtra("mode", mode).putExtra("genre_id", genreId).putExtra("title", title))
    }

    private fun openDetail(m: MediaItem) {
        val focused = currentFocus
        if (focused != null) {
            var v: View? = focused
            while (v != null) {
                val id = v.id
                if (id == R.id.rvContinue || id == R.id.rvNow || id == R.id.rvPopularTv ||
                    id == R.id.rvKids || id == R.id.rvTop || id == R.id.rvMovieCats || id == R.id.rvSeriesCats ||
                    id == R.id.rvGrid) {
                    val rv = v as? RecyclerView
                    if (rv != null) {
                        lastFocusedRowId = id
                        lastFocusedPosition = rv.getChildAdapterPosition(focused).coerceAtLeast(0)
                    }
                    break
                }
                v = v.parent as? View
            }
        }
        startActivity(Intent(this@MainActivity, DetailActivity::class.java)
            .putExtra("id", m.id).putExtra("type", m.type).putExtra("title", m.title)
            .putExtra("year", m.year).putExtra("poster", m.posterPath)
            .putExtra("backdrop", m.backdropPath).putExtra("rating", m.rating))
    }

    private fun parseMulti(json: JSONObject?): List<MediaItem> {
        val out = mutableListOf<MediaItem>()
        if (json == null) return out
        val arr = json.optJSONArray("results") ?: return out
        for (i in 0 until arr.length()) {
            try {
                val e = arr.getJSONObject(i)
                val type = e.optString("media_type", if (e.has("title")) "movie" else "tv")
                if (type != "movie" && type != "tv") continue
                if (e.optString("poster_path", "").isEmpty()) continue
                out.add(MediaItem(e.optInt("id"),
                    e.optString(if (type == "movie") "title" else "name", ""),
                    e.optString(if (type == "movie") "release_date" else "first_air_date", "").take(4),
                    e.optString("poster_path", ""), e.optString("backdrop_path", ""),
                    type, e.optDouble("vote_average", 0.0)))
            } catch (t: Throwable) { }
        }
        return out
    }

    override fun onPause() {
        super.onPause()
        val foc = currentFocus
        val p = foc?.parent
        if (p is RecyclerView) {
            val pos = p.getChildAdapterPosition(foc)
            if (pos >= 0) {
                lastFocusedRowId = p.id
                lastFocusedPosition = pos
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (isSidebarOpen) hideSidebar()
        if (currentTab == "home") loadContinueRow()
        if (!isTv) return
        if (lastFocusedRowId != -1) {
            restoreSavedFocus(400)
            restoreSavedFocus(1300)
        } else if (homeRowId != -1) {
            restoreFocusTo(homeRowId, homePos, 600)
        } else {
            findViewById<View>(R.id.homeScroll)?.postDelayed({ focusFirstHomeItem() }, 600)
        }
    }


    


    private var searchType = "movie"

    private fun enterSearchMode() {
        findViewById<View>(R.id.gridContainer)?.visibility = View.VISIBLE
        findViewById<View>(R.id.searchTopRow)?.visibility = View.VISIBLE
        findViewById<View>(R.id.topBar)?.visibility = View.GONE
        findViewById<View>(R.id.homeWrap)?.visibility = View.GONE
        findViewById<EditText>(R.id.etSearch)?.requestFocus()
        findViewById<View>(R.id.tvClock)?.visibility = View.GONE
    }

    private fun exitSearchMode() {
        findViewById<View>(R.id.gridContainer)?.visibility = View.GONE
        findViewById<View>(R.id.searchTopRow)?.visibility = View.GONE
        findViewById<View>(R.id.topBar)?.visibility = if (isTv) View.GONE else View.VISIBLE
        findViewById<View>(R.id.homeWrap)?.visibility = View.VISIBLE
        findViewById<View>(R.id.tvClock)?.visibility = View.VISIBLE
        // Restore focus to home content after exiting search
        val continueRv = findViewById<RecyclerView>(R.id.rvContinue)
        continueRv?.post {
            continueRv.layoutManager?.findViewByPosition(0)?.requestFocus()
        }
    }


    override fun onBackPressed() {
        if (isSidebarOpen) { hideSidebar(); return }
        if (findViewById<View>(R.id.searchTopRow)?.visibility == View.VISIBLE) { exitSearchMode(); return }
        if (currentTab == "home") {
            android.app.AlertDialog.Builder(this)
                .setTitle("Exit PrimeFlix?")
                .setMessage("Do you want to exit the app?")
                .setPositiveButton("Exit") { _, _ -> finish() }
                .setNegativeButton("Cancel", null)
                .show()
        } else {
            selectTab("home")
        }
    }
    private var lastFeaturedId = ""
    private var savedScrollPositions = mutableMapOf<Int, Int>()
    private val homeRowIds = listOf(R.id.rvContinue, R.id.rvNow, R.id.rvPopularTv, R.id.rvTop, R.id.rvKids, R.id.rvMovieCats, R.id.rvSeriesCats)
    private var lastHomeLoad = 0L
    private var userNavigated = false
    private var focusPlaced = false

    // Custom LayoutManager that keeps focused item centered (Netflix TV style)
    inner class CenterLayoutManager(context: android.content.Context) :
        LinearLayoutManager(context, RecyclerView.HORIZONTAL, false) {
        var rowId: Int = 0
        private var lastOffset = 0
        private var scrolledSinceLayout = false

        override fun scrollHorizontallyBy(dx: Int, recycler: RecyclerView.Recycler, state: RecyclerView.State): Int {
            val moved = super.scrollHorizontallyBy(dx, recycler, state)
            scrolledSinceLayout = true
            lastOffset = computeHorizontalScrollOffset(state)
            return moved
        }

        override fun onLayoutCompleted(state: RecyclerView.State) {
            super.onLayoutCompleted(state)
            val off = computeHorizontalScrollOffset(state)
            if (!scrolledSinceLayout && kotlin.math.abs(off - lastOffset) > 300) {
                android.util.Log.d("JUMP_TRACE", "RE-ANCHOR row=$rowId $lastOffset -> $off")
            }
            lastOffset = off
            scrolledSinceLayout = false
        }

        // ANTI-TELEPORT: block silent layout re-anchors > 300px
        override fun onLayoutChildren(recycler: RecyclerView.Recycler, state: RecyclerView.State) {
            val savedPos = findFirstVisibleItemPosition()
            val savedLeft = if (childCount > 0) getDecoratedLeft(getChildAt(0)!!) else 0
            super.onLayoutChildren(recycler, state)
            if (!isSmoothScrolling && !state.isPreLayout && savedPos >= 0 && childCount > 0) {
                val newPos = findFirstVisibleItemPosition()
                val newLeft = getDecoratedLeft(getChildAt(0)!!)
                val jump = kotlin.math.abs(newLeft - savedLeft) + kotlin.math.abs(newPos - savedPos) * 288
                if (jump > 300) {
                    android.util.Log.d("JUMP_TRACE", "CLAMPED silent re-anchor row=$rowId jump=$jump")
                    scrollToPositionWithOffset(savedPos, savedLeft)
                }
            }
        }

        override fun requestChildRectangleOnScreen(parent: RecyclerView, child: View,
                                                    rect: android.graphics.Rect, immediate: Boolean,
                                                    focusedChildVisible: Boolean): Boolean {
            val childCenter = (child.left + child.right) / 2
            val parentCenter = parent.width / 2
            val dx = childCenter - parentCenter
            val pos = getPosition(child)
            android.util.Log.d("CENTER_LM", "requestChild pos=$pos dx=$dx immediate=$immediate")
            // Log caller
            android.util.Log.d("CENTER_LM", "Caller: ${Thread.currentThread().stackTrace.take(5).joinToString { "${it.methodName}" }}")
            if (dx != 0) {
                // ALWAYS use smooth scroll to prevent teleport effect
                // (ignore the 'immediate' flag from Android)
                parent.stopScroll()
                android.util.Log.d("CENTER_LM", "smooth center dx=$dx")
                parent.smoothScrollBy(dx, 0)
            }
            return true
        }

        override fun smoothScrollToPosition(recyclerView: RecyclerView, state: RecyclerView.State, position: Int) {
            val rvWidth = recyclerView.width
            val scroller = object : androidx.recyclerview.widget.LinearSmoothScroller(recyclerView.context) {
                override fun calculateDxToMakeVisible(view: View, snapPreference: Int): Int {
                    val childCenter = (view.left + view.right) / 2
                    return childCenter - rvWidth / 2
                }
            }
            scroller.targetPosition = position
            startSmoothScroll(scroller)
        }
    }

    private var lastAutoRow = -1
    private val loggedScrollRows = mutableSetOf<Int>()
    private var isScrolling = false
    private var rowScrollPositions = mutableMapOf<Int, Int>()

    private fun focusIsUnset(): Boolean {
        val cf = currentFocus ?: return true
        return cf.id == View.NO_ID
    }

    private fun focusInRow(): Boolean {
        var cf: View? = currentFocus
        while (cf != null) {
            val cid = cf.id
            if (cid == R.id.rvContinue || cid == R.id.rvNow || cid == R.id.rvPopularTv || cid == R.id.rvTop || cid == R.id.rvKids) return true
            cf = cf.parent as? View
        }
        return false
    }

    private fun getTopOffset(v: View, root: View): Int {
        var y = 0
        var cur: View = v
        while (cur !== root) {
            y += cur.top
            cur = cur.parent as? View ?: return y
        }
        return y
    }



}
