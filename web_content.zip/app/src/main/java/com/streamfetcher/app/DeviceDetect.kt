package com.streamfetcher.app

import android.app.Activity
import android.app.UiModeManager
import android.content.Context
import android.content.res.Configuration
import android.widget.Toast

object DeviceDetect {
    fun isTvDevice(c: Context): Boolean {
        val um = c.getSystemService(Context.UI_MODE_SERVICE) as? UiModeManager
        if (um?.currentModeType == Configuration.UI_MODE_TYPE_TELEVISION) return true
        return c.packageManager.hasSystemFeature("android.software.leanback") ||
                !c.packageManager.hasSystemFeature("android.hardware.touchscreen")
    }

    /** Shows the mode toast ONLY on first launch, remembers it forever. */
    fun announceMode(a: Activity) {
        val prefs = a.getSharedPreferences("device_mode", Context.MODE_PRIVATE)
        val mode = if (isTvDevice(a)) "tv" else "phone"
        val first = prefs.getBoolean("first_launch", true)
        prefs.edit().putString("mode", mode).putBoolean("first_launch", false).apply()
        if (first) {
            Toast.makeText(a,
                if (mode == "tv") "📺 TV MODE detected" else "📱 PHONE MODE detected",
                Toast.LENGTH_LONG).show()
        }
    }
}
