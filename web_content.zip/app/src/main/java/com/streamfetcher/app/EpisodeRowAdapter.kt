package com.streamfetcher.app

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import coil.load
import coil.transform.RoundedCornersTransformation

data class EpRow(val number: Int, val name: String, val runtime: String, val overview: String, val still: String?)

class EpisodeRowAdapter(val rows: List<EpRow>, val onClick: (EpRow) -> Unit) :
    RecyclerView.Adapter<EpisodeRowAdapter.VH>() {
    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val thumb: ImageView = v.findViewById(R.id.ivEpThumb)
        val title: TextView = v.findViewById(R.id.tvEpTitle)
        val meta: TextView = v.findViewById(R.id.tvEpMeta)
        val desc: TextView = v.findViewById(R.id.tvEpDesc)
    }
    override fun onCreateViewHolder(p: ViewGroup, t: Int): VH =
        VH(LayoutInflater.from(p.context).inflate(R.layout.item_episode_row, p, false))
    override fun getItemCount() = rows.size
    override fun onBindViewHolder(h: VH, pos: Int) {
        val e = rows[pos]
        h.title.text = "E" + e.number + "  ·  " + e.name
        h.meta.text = e.runtime
        h.meta.visibility = if (e.runtime.isEmpty()) View.GONE else View.VISIBLE
        h.desc.text = e.overview
        h.desc.visibility = if (e.overview.isEmpty()) View.GONE else View.VISIBLE
        if (e.still.isNullOrEmpty()) h.thumb.load(null) { placeholder(R.drawable.placeholder) }
        else h.thumb.load(Api.IMG + "w300" + e.still) {
            crossfade(true)
            placeholder(R.drawable.placeholder)
            transformations(RoundedCornersTransformation(8f * h.itemView.context.resources.displayMetrics.density))
        }
        h.itemView.setOnFocusChangeListener { v, f ->
            v.animate().scaleX(if (f) 1.02f else 1f).scaleY(if (f) 1.02f else 1f).setDuration(200).start()
        }
        h.itemView.setOnClickListener { onClick(e) }
    }
}
