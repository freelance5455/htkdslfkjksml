package com.streamfetcher.app

import android.content.Context
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.net.URLEncoder
import java.nio.charset.Charset
import java.nio.charset.StandardCharsets
import java.util.concurrent.TimeUnit

data class VipSubtitleItem(
    val subtitleId: String,
    val fileId: Int,
    val language: String,
    val downloadCount: Long,
    val newDownloadCount: Long,
    val release: String,
    val hd: Boolean,
    val aiTranslated: Boolean,
    val machineTranslated: Boolean,
    val uploaderName: String,
    val uploaderRank: String
)

object VipSubtitleManager {
    
    private const val BASE_URL = "https://api.opensubtitles.com/api/v1"
    private const val API_KEY = "FGTv0mrQbYgEOp4HeGwbI5ROyPH7CduT"
    
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    fun formatDownloads(n: Long): String = when {
        n >= 1_000_000 -> String.format("%.1fM", n / 1_000_000.0)
        n >= 1_000 -> String.format("%.0fK", n / 1_000.0)
        else -> n.toString()
    }

    /**
     * Search VIP subtitles
     * - Movies: use tmdb_id
     * - TV: use query + season_number + episode_number
     */
    suspend fun search(
        tmdbId: Int,
        title: String,
        season: Int?,
        episode: Int?,
        mediaType: String,
        languages: String = "ar"
    ): List<VipSubtitleItem> = withContext(Dispatchers.IO) {
        val out = mutableListOf<VipSubtitleItem>()
        try {
            // 🔑 KEY FIX: Only use season/episode for TV shows
            val url = if (mediaType == "tv" && season != null && episode != null) {
                val q = URLEncoder.encode(title, "UTF-8")
                "$BASE_URL/subtitles?query=$q&season_number=$season&episode_number=$episode&languages=$languages"
            } else {
                "$BASE_URL/subtitles?tmdb_id=$tmdbId&languages=$languages"
            }
            
            Log.d("VipSubtitleManager", "Search URL: $url")
            
            val request = Request.Builder()
                .url(url)
                .get()
                .addHeader("api-key", API_KEY)
                .addHeader("Content-Type", "application/json")
                .addHeader("Accept", "*/*")
                .addHeader("User-Agent", "iMPlayer")
                .build()
            
            val response = client.newCall(request).execute()
            val responseBody = response.body?.string()
            
            Log.d("VipSubtitleManager", "VIP search response: $responseBody")
            
            if (!response.isSuccessful || responseBody == null) {
                return@withContext emptyList()
            }
            
            val json = JSONObject(responseBody)
            val data = json.optJSONArray("data") ?: return@withContext emptyList()
            
            for (i in 0 until data.length()) {
                val item = data.getJSONObject(i)
                val attrs = item.getJSONObject("attributes")
                val files = attrs.optJSONArray("files") ?: continue
                if (files.length() == 0) continue
                
                val file = files.getJSONObject(0)
                val uploader = attrs.optJSONObject("uploader")
                
                out.add(VipSubtitleItem(
                    subtitleId = attrs.optString("subtitle_id"),
                    fileId = file.optInt("file_id"),
                    language = attrs.optString("language"),
                    downloadCount = attrs.optLong("download_count", 0),
                    newDownloadCount = attrs.optLong("new_download_count", 0),
                    release = attrs.optString("release", ""),
                    hd = attrs.optBoolean("hd", false),
                    aiTranslated = attrs.optBoolean("ai_translated", false),
                    machineTranslated = attrs.optBoolean("machine_translated", false),
                    uploaderName = uploader?.optString("name", "") ?: "",
                    uploaderRank = uploader?.optString("rank", "") ?: ""
                ))
            }
            
            out.sortByDescending { it.downloadCount + it.newDownloadCount }
            Log.d("VipSubtitleManager", "found ${out.size} VIP subs")
            out
        } catch (e: Exception) {
            Log.e("VipSubtitleManager", "search error: ${e.message}", e)
            emptyList()
        }
    }

    suspend fun downloadSubtitle(fileId: Int, ctx: Context): File? = withContext(Dispatchers.IO) {
        try {
            val url = "$BASE_URL/download"
            val body = """{"file_id":$fileId}"""
            
            val request = Request.Builder()
                .url(url)
                .post(body.toRequestBody("application/json".toMediaType()))
                .addHeader("api-key", API_KEY)
                .addHeader("Content-Type", "application/json")
                .addHeader("Accept", "*/*")
                .addHeader("User-Agent", "iMPlayer")
                .build()
            
            val response = client.newCall(request).execute()
            val responseBody = response.body?.string()
            
            Log.d("VipSubtitleManager", "Download response: $responseBody")
            
            if (!response.isSuccessful || responseBody == null) return@withContext null
            
            val json = JSONObject(responseBody)
            val link = json.optString("link", "")
            if (link.isEmpty()) return@withContext null
            
            // Download the actual SRT file
            val downloadRequest = Request.Builder()
                .url(link)
                .get()
                .addHeader("User-Agent", "iMPlayer")
                .build()
            
            val downloadResponse = client.newCall(downloadRequest).execute()
            if (!downloadResponse.isSuccessful) return@withContext null
            
            val text = downloadResponse.body?.string() ?: return@withContext null
            
            // Apply RTL wrapping (same as other sources)
            val REPLACEMENT_CHAR = Char(0xFFFD)
            val BOM_CHAR = Char(0xFEFF)
            val RLM = Char(0x200F).toString()
            val ARABIC_REGEX = Regex("[" + Char(0x0600) + "-" + Char(0x06FF) + "]")
            
            var processed = text
            if (processed.indexOf(REPLACEMENT_CHAR) >= 0) {
                processed = String(processed.toByteArray(), Charset.forName("windows-1256"))
            }
            if (processed.isNotEmpty() && processed[0] == BOM_CHAR) processed = processed.substring(1)
            
            processed = processed.split("\n").joinToString("\n") { line ->
                if (ARABIC_REGEX.containsMatchIn(line)) RLM + line + RLM else line
            }
            
            val outFile = File(ctx.cacheDir, "vip_sub_$fileId.srt")
            outFile.writeText(processed, StandardCharsets.UTF_8)
            Log.d("VipSubtitleManager", "VIP SRT saved: ${processed.length} chars")
            outFile
        } catch (e: Exception) {
            Log.e("VipSubtitleManager", "download error: ${e.message}", e)
            null
        }
    }
}
