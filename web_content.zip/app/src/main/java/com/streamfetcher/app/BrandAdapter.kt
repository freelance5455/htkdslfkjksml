package com.streamfetcher.app

import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

data class Brand(val name: String, val color: Int, val id: Int, val logo: String? = null, val provider: Int? = null)

class BrandAdapter(
    private val brands: List<Brand>,
    private val onClick: (Brand) -> Unit
) : RecyclerView.Adapter<BrandAdapter.VH>() {

    /** brand-name keyword -> your logo drawable */
    private val LOGOS = listOf(
        "disney" to "net_disney", "sony" to "net_sony", "a24" to "net_a24",
        "universal" to "net_universal", "warner" to "net_warner", "dc" to "net_dc",
        "netflix" to "net_netflix", "prime" to "net_prime", "apple" to "net_appletvplus",
        "hbo" to "net_hbomax", "hulu" to "net_hulu", "paramount" to "net_paramount",
        "peacock" to "net_peacock", "showtime" to "net_showtime_image", "starz" to "net_starz",
        "syfy" to "net_syfy_image", "amc" to "net_amc_image", "abc" to "net_abc_image",
        "cbs" to "net_cbs_image", "brit" to "net_brit_box", "marvel" to "net_marvel",
        "imdb" to "net_imdb", "bollywood" to "net_bollywood", "drama" to "net_drama",
        "mission" to "net_mission", "meta" to "net_meta", "play" to "net_play",
        "progress" to "net_progress_image", "tmdb" to "net_tmdb_logo", "rd" to "net_rd_logo"
    )

    class VH(val root: LinearLayout, val logo: ImageView, val label: TextView) :
        RecyclerView.ViewHolder(root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val ctx = parent.context
        val dp = ctx.resources.displayMetrics.density

        val root = LinearLayout(ctx)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER
        val lp = RecyclerView.LayoutParams((150 * dp).toInt(), (86 * dp).toInt())
        lp.setMargins((6 * dp).toInt(), 0, (6 * dp).toInt(), 0)
        root.layoutParams = lp
        val gd = android.graphics.drawable.GradientDrawable()
        gd.setColor(0xFFFFFFFF.toInt())
        gd.cornerRadius = 14 * dp
        root.background = gd
        root.isFocusable = true
        root.isClickable = true

        val logo = ImageView(ctx)
        logo.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
        logo.scaleType = ImageView.ScaleType.FIT_CENTER
        logo.setPadding((14 * dp).toInt(), (10 * dp).toInt(), (14 * dp).toInt(), (2 * dp).toInt())

        val label = TextView(ctx)
        label.layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        label.gravity = Gravity.CENTER
        label.textSize = 11f
        label.setTextColor(0xFFB9B9C0.toInt())
        label.setPadding(0, 0, 0, (8 * dp).toInt())

        root.addView(logo)
        root.addView(label)

        root.setOnFocusChangeListener { v, f ->
            v.animate().scaleX(if (f) 1.05f else 1f).scaleY(if (f) 1.05f else 1f).setDuration(200).start()
            (v.background as android.graphics.drawable.GradientDrawable)
                .setColor(if (f) 0xFFE4E4E4.toInt() else 0xFFFFFFFF.toInt())
        }
        return VH(root, logo, label)
    }

    override fun onBindViewHolder(h: VH, pos: Int) {
        val b = brands[pos]
        val n = b.name.lowercase()
        var res = 0
        for ((k, v) in LOGOS) if (n.contains(k)) {
            res = h.logo.context.resources.getIdentifier(v, "drawable", h.logo.context.packageName)
            if (res != 0) break
        }
        val dp = h.root.context.resources.displayMetrics.density
        if (res != 0) {
            h.logo.setImageResource(res); h.logo.visibility = View.VISIBLE
            h.label.visibility = View.GONE
        } else {
            h.logo.visibility = View.GONE
            val wm = wordmarkFor(b.name)
            if (wm != null) {
                h.label.visibility = View.VISIBLE
                h.label.text = wm.first
                h.label.setTextColor(wm.second)
                h.label.textSize = 18f
                h.label.setTypeface(null, android.graphics.Typeface.BOLD)
                if (wm.third != 0) {
                    val sh = android.graphics.drawable.ShapeDrawable(android.graphics.drawable.shapes.OvalShape())
                    sh.paint.color = wm.third
                    h.label.background = sh
                    h.label.setPadding((18 * dp).toInt(), (8 * dp).toInt(), (18 * dp).toInt(), (8 * dp).toInt())
                } else h.label.background = null
            } else {
                h.label.visibility = View.VISIBLE
                h.label.text = b.name
                h.label.setTextColor(0xFF8A8A93.toInt())
                h.label.textSize = 11f
                h.label.setTypeface(null, android.graphics.Typeface.NORMAL)
                h.label.background = null
            }
        }
        h.root.setOnClickListener { onClick(b) }
    }

    /** built-in wordmark logos (no image files needed) */
    private fun wordmarkFor(name: String): Triple<String, Int, Int>? {
        val n = name.lowercase()
        return when {
            n.contains("sony") -> Triple("SONY", 0xFF000000.toInt(), 0)
            n.contains("a24") -> Triple("A24", 0xFF000000.toInt(), 0)
            n.contains("universal") -> Triple("UNIVERSAL", 0xFF5E6B7A.toInt(), 0)
            n.contains("warner") -> Triple("WB", 0xFFB49347.toInt(), 0)
            n.contains("dc") -> Triple("DC", 0xFFFFFFFF.toInt(), 0xFF0078F0.toInt())
            else -> null
        }
    }

    override fun getItemCount() = brands.size
}
