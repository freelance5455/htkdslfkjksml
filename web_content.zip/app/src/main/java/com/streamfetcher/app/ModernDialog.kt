package com.streamfetcher.app

import android.app.Activity
import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.ImageView
import android.widget.TextView

object ModernDialog {

    fun show(
        activity: Activity,
        icon: Int? = null,
        title: String,
        message: String,
        okText: String = "OK",
        cancelText: String? = null,
        onOk: () -> Unit = {},
        onCancel: () -> Unit = {}
    ): Dialog {
        val d = Dialog(activity)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        d.setContentView(R.layout.dialog_modern)
        d.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        d.window?.setLayout(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        d.window?.setGravity(Gravity.CENTER)
        d.window?.setDimAmount(0.75f)

        icon?.let { d.findViewById<ImageView>(R.id.dIcon).setImageResource(it) }
            ?: run { d.findViewById<ImageView>(R.id.dIcon).visibility = View.GONE }

        d.findViewById<TextView>(R.id.dTitle).text = title
        d.findViewById<TextView>(R.id.dMessage).text = message

        val ok = d.findViewById<TextView>(R.id.dOk)
        ok.text = okText
        ok.setOnClickListener { onOk(); d.dismiss() }

        val cancel = d.findViewById<TextView>(R.id.dCancel)
        if (cancelText != null) {
            cancel.text = cancelText
            cancel.setOnClickListener { onCancel(); d.dismiss() }
        } else {
            cancel.visibility = View.GONE
        }

        // Auto-focus OK for TV
        ok.requestFocus()

        d.show()
        return d
    }
}
