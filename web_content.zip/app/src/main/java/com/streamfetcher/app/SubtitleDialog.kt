package com.streamfetcher.app

import android.app.Dialog
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

object SubtitleDialog {

    // null in list = "None / بدون ترجمة" row
    fun show(
        ctx: Context,
        subs: List<SubtitleItem>,
        selectedId: String?,
        loading: Boolean,
        onPick: (SubtitleItem?) -> Unit,
        onAttach: (RecyclerView, SubtitleAdapter) -> Unit
    ): Dialog {
        val dialog = Dialog(ctx)
        dialog.setContentView(R.layout.dialog_subtitles)
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.window?.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)

        val items: List<SubtitleItem?> = listOf(null) + subs
        val rv = dialog.findViewById<RecyclerView>(R.id.rvSubs)
        val empty = dialog.findViewById<TextView>(R.id.tvEmpty)
        val pb = dialog.findViewById<ProgressBar>(R.id.pbLoading)

        rv.layoutManager = LinearLayoutManager(ctx)
        val adapter = SubtitleAdapter(items, selectedId) { item ->
            onPick(item)
        }
        rv.adapter = adapter
        onAttach(rv, adapter)

        if (loading) {
            pb.visibility = View.VISIBLE
            empty.visibility = View.GONE
        } else if (subs.isEmpty()) {
            empty.visibility = View.VISIBLE
            rv.visibility = View.GONE
        }
        dialog.show()
        return dialog
    }

    class SubtitleAdapter(
        private val items: List<SubtitleItem?>,
        private var selectedId: String?,
        private val onPick: (SubtitleItem?) -> Unit
    ) : RecyclerView.Adapter<SubtitleAdapter.VH>() {

        class VH(v: View) : RecyclerView.ViewHolder(v) {
            val lang: TextView = v.findViewById(R.id.tvLang)
            val name: TextView = v.findViewById(R.id.tvName)
            val dl: TextView = v.findViewById(R.id.tvDownloads)
            val check: ImageView = v.findViewById(R.id.ivCheck)
        }

        fun setSelected(id: String?) {
            selectedId = id
            notifyDataSetChanged()
        }

        override fun onCreateViewHolder(p: ViewGroup, t: Int): VH {
            val v = LayoutInflater.from(p.context).inflate(R.layout.item_subtitle, p, false)
            v.setOnFocusChangeListener { view, focused ->
                view.animate()
                    .scaleX(if (focused) 1.03f else 1f)
                    .scaleY(if (focused) 1.03f else 1f)
                    .setDuration(220).start()
            }
            return VH(v)
        }

        override fun getItemCount() = items.size

        override fun onBindViewHolder(h: VH, pos: Int) {
            val item = items[pos]
            if (item == null) {
                h.lang.text = "🚫"
                h.name.text = "None / بدون ترجمة"
                h.dl.text = "Turn off subtitles"
                h.check.visibility = if (selectedId == null) View.VISIBLE else View.GONE
            } else {
                h.lang.text = "🇸🇦"
                h.name.text = item.fileName
                h.dl.text = "⬇ ${SubtitleManager.formatDownloads(item.downloadCount)} downloads"
                h.check.visibility = if (selectedId == item.id) View.VISIBLE else View.GONE
            }
            h.itemView.setOnClickListener { onPick(item) }
        }
    }
}
