package com.streamfetcher.app

import android.content.Context
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.nio.charset.StandardCharsets
import java.nio.charset.Charset
import java.util.concurrent.TimeUnit

data class CloudSubtitleItem(
    val fileId: String,
    val language: String,
    val downloadCount: Long,
    val aiTranslated: Boolean,
    val machineTranslated: Boolean
)

object CloudSubtitleManager {
    
    private const val BASE_URL = "https://subtitles-api-700498303838.us-central1.run.app"
    private const val CLIENT = "9b2d344849de7b59"
    private const val MODEL = "2107113SG"
    private const val AUTH = "eloufir@2021"
    
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    fun formatDownloads(n: Long): String = when {
        n >= 1_000_000 -> String.format("%.1fM", n / 1_000_000.0)
        n >= 1_000 -> String.format("%.0fK", n / 1_000.0)
        else -> n.toString()
    }

    suspend fun searchSubtitles(tmdbId: Int): List<CloudSubtitleItem> = withContext(Dispatchers.IO) {
        val out = mutableListOf<CloudSubtitleItem>()
        try {
            val url = "$BASE_URL/v1/player/tmdb_id/$tmdbId?client=$CLIENT&model=$MODEL&languages="
            val req = Request.Builder()
                .url(url)
                .header("User-Agent", "Dart/3.8 (dart:io)")
                .header("Content-Type", "application/json")
                .header("Authorization", AUTH)
                .build()

            val res = client.newCall(req).execute()
            if (!res.isSuccessful) {
                Log.e("CloudSubtitleManager", "search HTTP ${res.code}")
                return@withContext emptyList()
            }

            val body = res.body?.string() ?: return@withContext emptyList()
            val arr = JSONArray(body)

            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(CloudSubtitleItem(
                    fileId = o.optString("file_id"),
                    language = o.optString("language"),
                    downloadCount = o.optLong("download_count", 0),
                    aiTranslated = o.optBoolean("ai_translated", false),
                    machineTranslated = o.optBoolean("machine_translated", false)
                ))
            }
            
            // Filter to Arabic only and sort by download count
            val arabicOnly = out.filter { it.language == "AR" }
                .sortedByDescending { it.downloadCount }
            
            Log.d("CloudSubtitleManager", "found ${arabicOnly.size} Arabic cloud subs")
            arabicOnly
        } catch (e: Exception) {
            Log.e("CloudSubtitleManager", "search error: ${e.message}", e)
            emptyList()
        }
    }

    suspend fun downloadSubtitle(fileId: String, ctx: Context): File? = withContext(Dispatchers.IO) {
        try {
            val url = "$BASE_URL/v1/download/$fileId?format=SRT&authorization=$AUTH&client=$CLIENT&model=$MODEL"
            val req = Request.Builder()
                .url(url)
                .header("User-Agent", "Dalvik/2.1.0 (Linux; U; Android 13; 2107113SG Build/TKQ1.220829.002)")
                .header("Icy-MetaData", "1")
                .header("Accept-Encoding", "identity")
                .build()

            val res = client.newCall(req).execute()
            if (!res.isSuccessful) return@withContext null
            
            val text = res.body?.string() ?: return@withContext null

            // Apply same RTL wrapping as OpenSubtitles
            val REPLACEMENT_CHAR = Char(0xFFFD)
            val BOM_CHAR = Char(0xFEFF)
            val RLM = Char(0x200F).toString()
            val ARABIC_REGEX = Regex("[" + Char(0x0600) + "-" + Char(0x06FF) + "]")
            
            var processed = text
            if (processed.indexOf(REPLACEMENT_CHAR) >= 0) {
                processed = String(processed.toByteArray(), Charset.forName("windows-1256"))
            }
            if (processed.isNotEmpty() && processed[0] == BOM_CHAR) {
                processed = processed.substring(1)
            }
            
            processed = processed.split("\n").joinToString("\n") { line ->
                if (ARABIC_REGEX.containsMatchIn(line)) RLM + line + RLM else line
            }

            val outFile = File(ctx.cacheDir, "cloud_sub_$fileId.srt")
            outFile.writeText(processed, StandardCharsets.UTF_8)
            Log.d("CloudSubtitleManager", "Cloud SRT saved: ${processed.length} chars")
            outFile
        } catch (e: Exception) {
            Log.e("CloudSubtitleManager", "download error: ${e.message}", e)
            null
        }
    }
}
