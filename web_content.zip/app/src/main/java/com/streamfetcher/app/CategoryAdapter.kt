package com.streamfetcher.app

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class CategoryAdapter(
    private val items: List<Pair<Int, String>>,
    private val onClick: (Int, String) -> Unit
) : RecyclerView.Adapter<CategoryAdapter.VH>() {

    class VH(v: TextView) : RecyclerView.ViewHolder(v)

    override fun onCreateViewHolder(p: ViewGroup, t: Int): VH {
        val v = LayoutInflater.from(p.context).inflate(R.layout.item_category, p, false) as TextView
        v.setOnFocusChangeListener { view, focused ->
            view.animate()
                .scaleX(if (focused) 1.05f else 1f)
                .scaleY(if (focused) 1.05f else 1f)
                .setDuration(220).start()
        }
        return VH(v)
    }

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, pos: Int) {
        val (id, name) = items[pos]
        (h.itemView as TextView).text = name
        h.itemView.setOnClickListener { onClick(id, name) }
    }
}
