package com.streamfetcher.app

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView

class EpisodeAdapter(
    private val items: List<Episode>,
    private val onClick: (Episode) -> Unit
) : RecyclerView.Adapter<EpisodeAdapter.VH>() {

    var selectedNumber: Int = -1

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val num: TextView = v.findViewById(R.id.tvEpNumber)
        val name: TextView = v.findViewById(R.id.tvEpName)
        val card: CardView = v as CardView
    }

    override fun onCreateViewHolder(p: ViewGroup, t: Int): VH {
        val v = LayoutInflater.from(p.context).inflate(R.layout.item_episode, p, false)
        v.setOnFocusChangeListener { view, focused ->
            view.animate()
                .scaleX(if (focused) 1.05f else 1f)
                .scaleY(if (focused) 1.05f else 1f)
                .setDuration(250)
                .start()
        }
        return VH(v)
    }

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, pos: Int) {
        val ep = items[pos]
        val sel = ep.number == selectedNumber
        // ✅ Selected episode = RED card + ▶ marker (always visible)
        h.num.text = if (sel) "▶ E${ep.number}" else "E${ep.number}"
        h.name.text = ep.name
        h.card.setCardBackgroundColor(if (sel) Color.parseColor("#B0060F") else Color.parseColor("#1F1F1F"))
        h.num.setTextColor(if (sel) Color.WHITE else Color.parseColor("#E50914"))
        h.itemView.setOnClickListener {
            selectedNumber = ep.number
            notifyDataSetChanged()
            onClick(ep)
        }
    }
}
