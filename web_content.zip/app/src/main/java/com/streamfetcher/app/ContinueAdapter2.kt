package com.streamfetcher.app

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import coil.load

class ContinueAdapter2(
    private val items: List<MediaItem>,
    private val progress: List<ProgressItem>,
    private val onClick: (MediaItem, ProgressItem) -> Unit
) : RecyclerView.Adapter<ContinueAdapter2.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val poster: ImageView? = v.findViewById(R.id.ivPoster)
        val title: TextView? = v.findViewById(R.id.tvTitle)
        val bar: ProgressBar? = v.findViewById(
            v.resources.getIdentifier("progress", "id", v.context.packageName))
    }

    override fun onCreateViewHolder(p: ViewGroup, t: Int): VH =
        VH(LayoutInflater.from(p.context).inflate(R.layout.item_continue, p, false))

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(h: VH, pos: Int) {
        val m = items[pos]
        val pr = progress[pos]
        val clean = m.title.replace(Regex("[\\s•]*S\\d+E\\d+"), "").trim()
        h.title?.text = if (m.type == "tv" && pr.season > 0)
            "$clean  S${pr.season}E${pr.episode}" else clean
        h.poster?.load(if (m.posterPath.isNullOrEmpty()) null else Api.IMG + "w342" + m.posterPath) {
            crossfade(true)
            placeholder(R.drawable.placeholder)
        }
        h.bar?.max = 100
        h.bar?.progress = ((pr.position * 100) / maxOf(1L, pr.duration)).toInt()
        val card = h.itemView.findViewById<View>(R.id.cardPoster) ?: h.itemView
        card.foreground = h.itemView.context.getDrawable(R.drawable.focus_red)
        h.itemView.setOnFocusChangeListener { _, focused ->
            card.animate().scaleX(if (focused) 1.05f else 1f)
                .scaleY(if (focused) 1.05f else 1f).setDuration(250).start()
        }
        h.itemView.setOnClickListener { onClick(m, pr) }
    }
}
