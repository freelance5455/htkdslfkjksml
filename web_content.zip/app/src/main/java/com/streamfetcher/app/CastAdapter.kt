package com.streamfetcher.app

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import coil.load
import coil.transform.CircleCropTransformation

data class CastMember(
    val id: Int,
    val name: String,
    val character: String,
    val profilePath: String?
)

class CastAdapter(
    private val items: List<CastMember>,
    private val onClick: (CastMember) -> Unit
) : RecyclerView.Adapter<CastAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val iv: ImageView = v.findViewById(R.id.ivProfile)
        val name: TextView = v.findViewById(R.id.tvName)
        val character: TextView = v.findViewById(R.id.tvCharacter)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_cast, parent, false))

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val item = items[position]
        h.name.text = item.name
        h.character.text = item.character
        val url = if (item.profilePath.isNullOrEmpty()) null else Api.IMG + "w185" + item.profilePath
        h.iv.load(url) {
            crossfade(true)
            placeholder(R.drawable.placeholder)
            transformations(CircleCropTransformation())
        }
        h.itemView.setOnClickListener { onClick(item) }
    }
}
