package com.streamfetcher.app

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import coil.load
import coil.transform.CircleCropTransformation
import coil.transform.RoundedCornersTransformation
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class PersonActivity : AppCompatActivity() {

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var personId = 0
    private val all = mutableListOf<MediaItem>()
    private var typeFilter = 0   // 0=all 1=movies 2=series
    private var dateSort = 0     // 0=default 1=newest 2=oldest

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_person)
        // focus scale
        findViewById<View>(R.id.tvStatsMovies)?.setOnFocusChangeListener { v, has ->
            v.animate().scaleX(if (has) 1.05f else 1f).scaleY(if (has) 1.05f else 1f).setDuration(250).start()
        }
        findViewById<View>(R.id.tvStatsSeries)?.setOnFocusChangeListener { v, has ->
            v.animate().scaleX(if (has) 1.05f else 1f).scaleY(if (has) 1.05f else 1f).setDuration(250).start()
        }
        findViewById<View>(R.id.btnFilter)?.setOnFocusChangeListener { v, has ->
            v.animate().scaleX(if (has) 1.05f else 1f).scaleY(if (has) 1.05f else 1f).setDuration(250).start()
        }

        personId = intent.getIntExtra("person_id", 0)


        // ===== filter button = DATE ONLY =====
        findViewById<ImageView>(R.id.btnFilter).setOnClickListener {
            dateSort = (dateSort + 1) % 3
            android.widget.Toast.makeText(this,
                when (dateSort) { 1 -> "Newest first"; 2 -> "Oldest first"; else -> "Default order" },
                android.widget.Toast.LENGTH_SHORT).show()
            applyFilter()
        }

        // ===== Movies button = show movies only =====
        findViewById<TextView>(R.id.tvStatsMovies).setOnClickListener {
            typeFilter = if (typeFilter == 1) 0 else 1
            updateTypeUi(); applyFilter()
        }
        // ===== Series button = show series only =====
        findViewById<TextView>(R.id.tvStatsSeries).setOnClickListener {
            typeFilter = if (typeFilter == 2) 0 else 2
            updateTypeUi(); applyFilter()
        }

        val uiMode = resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_TYPE_MASK
        val isTv = uiMode == android.content.res.Configuration.UI_MODE_TYPE_TELEVISION
        findViewById<RecyclerView>(R.id.rvWorks).layoutManager =
            GridLayoutManager(this, if (isTv) 6 else 3)
        load()
    }

    private fun updateTypeUi() {
        val m = findViewById<TextView>(R.id.tvStatsMovies)
        val s = findViewById<TextView>(R.id.tvStatsSeries)
        m.setTextColor(if (typeFilter == 1) 0xFFFFFFFF.toInt() else 0xFFB0B0B8.toInt())
        s.setTextColor(if (typeFilter == 2) 0xFFFFFFFF.toInt() else 0xFFB0B0B8.toInt())
        m.paint.isFakeBoldText = typeFilter == 1
        s.paint.isFakeBoldText = typeFilter == 2
    }

    private fun applyFilter() {
        var list: List<MediaItem> = when (typeFilter) {
            1 -> all.filter { it.type == "movie" }
            2 -> all.filter { it.type == "tv" }
            else -> all.toList()
        }
        list = when (dateSort) {
            1 -> list.sortedByDescending { it.year.toIntOrNull() ?: 0 }
            2 -> list.sortedBy { it.year.toIntOrNull() ?: 9999 }
            else -> list
        }
        findViewById<RecyclerView>(R.id.rvWorks).adapter = WorksAdapter(list) { mm ->
            startActivity(Intent(this, DetailActivity::class.java)
                .putExtra("id", mm.id)
                .putExtra("type", mm.type)
                .putExtra("title", mm.title)
                .putExtra("year", mm.year)
                .putExtra("poster", mm.posterPath)
                .putExtra("backdrop", mm.backdropPath)
                .putExtra("rating", mm.rating))
        }
    }

    private fun load() {
        scope.launch {
            val (dj, cj) = withContext(Dispatchers.IO) {
                Pair(
                    Api.get("${Api.BASE}/person/$personId?api_key=${Api.TMDB_KEY}"),
                    Api.get("${Api.BASE}/person/$personId/combined_credits?api_key=${Api.TMDB_KEY}")
                )
            }
            findViewById<TextView>(R.id.tvPersonName).text = dj?.optString("name") ?: ""
            findViewById<ImageView>(R.id.ivPerson).load(
                Api.IMG + "w342" + (dj?.optString("profile_path") ?: "")) {
                transformations(CircleCropTransformation())
                crossfade(true)
                placeholder(R.drawable.bg_circle_dark)
            }
            val cast = cj?.optJSONArray("cast")
            var movies = 0; var series = 0
            all.clear()
            if (cast != null) for (i in 0 until cast.length()) {
                val o = cast.getJSONObject(i)
                val type = o.optString("media_type")
                if (type == "movie") movies++ else if (type == "tv") series++
                val poster = o.optString("poster_path")
                if (poster.isEmpty()) continue
                all.add(MediaItem(o.optInt("id"),
                    if (type == "movie") o.optString("title") else o.optString("name"),
                    (if (type == "movie") o.optString("release_date")
                        else o.optString("first_air_date")).take(4),
                    poster, "", type, o.optDouble("vote_average")))
            }
            findViewById<TextView>(R.id.tvStatsMovies).text = "Movies · $movies"
            findViewById<TextView>(R.id.tvStatsSeries).text = "Series · $series"
            updateTypeUi()
            applyFilter()
        }
    }

    private class WorksAdapter(val items: List<MediaItem>, val onClick: (MediaItem) -> Unit) :
        RecyclerView.Adapter<WorksAdapter.VH>() {
        class VH(v: View) : RecyclerView.ViewHolder(v) {
            val poster: ImageView = v.findViewById(R.id.ivPoster)
            val title: TextView = v.findViewById(R.id.tvTitle)
            val year: TextView = v.findViewById(R.id.tvYear)
            val badge: TextView = v.findViewById(R.id.tvBadge)
        }
        override fun onCreateViewHolder(p: ViewGroup, t: Int): VH =
            VH(LayoutInflater.from(p.context).inflate(R.layout.item_work, p, false))
        override fun getItemCount() = items.size
        override fun onBindViewHolder(h: VH, pos: Int) {
            val m = items[pos]
            val ctx = h.itemView.context
            val radius = 14 * ctx.resources.displayMetrics.density
            h.title.text = m.title
            h.year.text = m.year
            if (m.rating > 0) {
                h.badge.text = "★ " + String.format("%.1f", m.rating)
                h.badge.visibility = View.VISIBLE
                h.badge.background = null
                h.badge.setTextColor(0xFFFFFFFF.toInt())
                h.badge.setShadowLayer(6f, 0f, 2f, 0xFF000000.toInt())
            } else h.badge.visibility = View.GONE
            h.poster.load(Api.IMG + "w342" + m.posterPath) {
                crossfade(true)
                placeholder(R.drawable.placeholder)
                transformations(RoundedCornersTransformation(radius))
            }
            h.itemView.isFocusable = true
            h.itemView.setOnFocusChangeListener { v, f ->
                v.animate().scaleX(if (f) 1.05f else 1f)
                    .scaleY(if (f) 1.05f else 1f).setDuration(250).start()
                h.poster.foreground = if (f) ctx.getDrawable(R.drawable.focus_white) else null
            }
            h.itemView.setOnClickListener { onClick(m) }
            h.itemView.setOnLongClickListener {
                val added = Library.toggleMyList(ctx, m)
                android.widget.Toast.makeText(ctx,
                    if (added) "✓ Added to My List" else "Removed from My List",
                    android.widget.Toast.LENGTH_SHORT).show()
                true
            }
        }
    }
}
