package com.streamfetcher.app

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

class BrowseActivity : AppCompatActivity() {

    private val scope = CoroutineScope(Dispatchers.Main)
    private val items = mutableListOf<MediaItem>()
    private var adapter: GridAdapter? = null
    private var page = 1
    private var isLoading = false
    private var hasMore = true
    private var baseUrl = ""

    private val isTv by lazy {
        (resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_TYPE_MASK) ==
                android.content.res.Configuration.UI_MODE_TYPE_TELEVISION
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_browse)

        findViewById<TextView>(R.id.tvTitle).text = intent.getStringExtra("title") ?: ""
        findViewById<TextView>(R.id.btnBack).setOnClickListener { finish() }
        if (isTv) {
            findViewById<TextView>(R.id.btnBack)?.apply {
                visibility = View.GONE
                isFocusable = false
            }
        }

        val grid = findViewById<RecyclerView>(R.id.rvGrid)
        grid.layoutManager = GridLayoutManager(this, if (isTv) 5 else 3)

        baseUrl = buildUrl()
        disableClipping(window.decorView)
        load(false)

        grid.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(rv: RecyclerView, dx: Int, dy: Int) {
                super.onScrolled(rv, dx, dy)
                if (!hasMore || isLoading) return
                val lm = rv.layoutManager as GridLayoutManager
                val visible = lm.childCount
                val total = lm.itemCount
                val first = lm.findFirstVisibleItemPosition()
                if (visible + first >= total - 10) load(true)
            }
        })
    }

    private fun disableClipping(v: View) {
        if (v is android.view.ViewGroup) {
            v.clipChildren = false
            v.clipToPadding = false
            for (i in 0 until v.childCount) disableClipping(v.getChildAt(i))
        }
    }

    private fun buildUrl(): String {
        val mode = intent.getStringExtra("mode") ?: "movie_popular"
        val genre = intent.getIntExtra("genre_id", 0)
        val key = Api.TMDB_KEY
        return when (mode) {
            "now_playing" -> "${Api.BASE}/movie/now_playing?api_key=$key"
            "top_rated" -> "${Api.BASE}/movie/top_rated?api_key=$key"
            "kids" -> "${Api.BASE}/discover/movie?api_key=$key&with_genres=10751&sort_by=popularity.desc"
            "genre_movie" -> "${Api.BASE}/discover/movie?api_key=$key&with_genres=$genre&sort_by=popularity.desc"
            "genre_tv" -> "${Api.BASE}/discover/tv?api_key=$key&with_genres=$genre&sort_by=popularity.desc"
            "company" -> "${Api.BASE}/discover/movie?api_key=$key&with_companies=$genre&sort_by=popularity.desc"
        "network" -> "${Api.BASE}/discover/tv?api_key=$key&with_networks=$genre&sort_by=popularity.desc"
        "provider" -> "${Api.BASE}/discover/movie?api_key=$key&with_watch_providers=$genre&watch_region=US&sort_by=popularity.desc"
        "tv_popular" -> "${Api.BASE}/tv/popular?api_key=$key"
            else -> "${Api.BASE}/movie/popular?api_key=$key"
        }
    }

    private fun load(append: Boolean) {
        if (isLoading) return
        isLoading = true
        scope.launch {
            try {
                val p = if (append) page else 1
                val sep = if (baseUrl.contains("?")) "&" else "?"
                val json = withContext(Dispatchers.IO) { Api.get("$baseUrl${sep}page=$p") }
                val newItems = parseList(json)

                val grid = findViewById<RecyclerView>(R.id.rvGrid)
                if (!append) {
                    items.clear()
                    items.addAll(newItems)
                    adapter = GridAdapter(items, { openDetail(it) }, false)
                    grid.adapter = adapter
                    page = 1
                      grid.postDelayed({
                          if (browseSavedPos < 0) {
                              grid.layoutManager?.findViewByPosition(0)?.requestFocus()
                          }
                      }, 300)
                } else {
                    val start = items.size
                    items.addAll(newItems)
                    adapter?.notifyItemRangeInserted(start, newItems.size)
                }
                hasMore = newItems.size >= 20
                if (newItems.isNotEmpty()) page++
            } catch (t: Throwable) {
            }
            findViewById<ProgressBar>(R.id.progress).visibility = View.GONE
            isLoading = false
        }
    }

    private fun parseList(json: JSONObject?): List<MediaItem> {
        val out = mutableListOf<MediaItem>()
        val arr = json?.optJSONArray("results") ?: return out
        for (i in 0 until arr.length()) {
            try {
                val e = arr.getJSONObject(i)
                val type = e.optString("media_type", if (e.has("title")) "movie" else "tv")
                if (type != "movie" && type != "tv") continue
                out.add(MediaItem(e.optInt("id"),
                    e.optString(if (type == "movie") "title" else "name", ""),
                    e.optString(if (type == "movie") "release_date" else "first_air_date", "").take(4),
                    e.optString("poster_path", ""), e.optString("backdrop_path", ""),
                    type, e.optDouble("vote_average", 0.0)))
            } catch (t: Throwable) { }
        }
        return out
    }

    private var browseSavedPos: Int = -1
    private var browseSavedOffset: Int = 0

    private fun openDetail(m: MediaItem) {
        // Save scroll state before leaving
        val grid = findViewById<RecyclerView>(R.id.rvGrid)
        val lm = grid?.layoutManager as? GridLayoutManager
        if (lm != null) {
            // Get exact clicked movie position from the items list (works with pointer remotes too)
            val clicked = items.indexOf(m)
            browseSavedPos = if (clicked >= 0) clicked else lm.findFirstVisibleItemPosition()
            val firstVisible = lm.findFirstVisibleItemPosition()
            val firstChild = grid.findViewHolderForAdapterPosition(firstVisible)?.itemView
            browseSavedOffset = firstChild?.top ?: 0
        }
        startActivity(Intent(this, DetailActivity::class.java)
            .putExtra("id", m.id).putExtra("type", m.type).putExtra("title", m.title)
            .putExtra("year", m.year).putExtra("poster", m.posterPath)
            .putExtra("backdrop", m.backdropPath).putExtra("rating", m.rating))
    }

    override fun onResume() {
        super.onResume()
        if (browseSavedPos < 0) return
        val grid = findViewById<RecyclerView>(R.id.rvGrid) ?: return
        val lm = grid.layoutManager as? GridLayoutManager ?: return
        
        grid.postDelayed({
            lm.scrollToPositionWithOffset(browseSavedPos, browseSavedOffset)
            grid.postDelayed({
                val child = lm.findViewByPosition(browseSavedPos)
                if (child != null) {
                    child.requestFocus()
                    child.animate().scaleX(1.05f).scaleY(1.05f).setDuration(200).start()
                }
                browseSavedPos = -1  // Clear after restore
            }, 200)
        }, 300)
    }
}
