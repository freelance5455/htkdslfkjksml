package com.streamfetcher.app

import android.content.Context
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.File
import java.nio.charset.Charset
import java.nio.charset.StandardCharsets
import java.util.concurrent.TimeUnit
import java.util.zip.GZIPInputStream

data class SubtitleItem(
    val id: String,
    val fileName: String,
    val downloadCount: Long,
    val score: Double,
    val downloadUrl: String
)

object SubtitleManager {

    // ✅ Hex char codes — pure ASCII source, can NEVER be corrupted by copy/paste
    private val REPLACEMENT_CHAR = Char(0xFFFD)   // invalid-UTF8 marker
    private val BOM_CHAR = Char(0xFEFF)           // byte order mark
    private val RLM = Char(0x200F).toString()     // right-to-left mark
    private val ARABIC_REGEX = Regex("[" + Char(0x0600) + "-" + Char(0x06FF) + "]")

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()

    fun formatDownloads(n: Long): String = when {
        n >= 1_000_000 -> String.format("%.1fM", n / 1_000_000.0)
        n >= 1_000 -> String.format("%.0fK", n / 1_000.0)
        else -> n.toString()
    }

    suspend fun fetchImdbId(
        type: String,
        tmdbId: Int,
        season: Int? = null,
        episode: Int? = null
    ): String? = withContext(Dispatchers.IO) {
        try {
            val url = if (type == "tv" && season != null && episode != null) {
                "${Api.BASE}/tv/$tmdbId/season/$season/episode/$episode/external_ids?api_key=${Api.TMDB_KEY}"
            } else {
                "${Api.BASE}/movie/$tmdbId/external_ids?api_key=${Api.TMDB_KEY}"
            }
            val req = Request.Builder().url(url).build()
            val res = client.newCall(req).execute()
            if (!res.isSuccessful) return@withContext null
            val json = JSONObject(res.body?.string() ?: "{}")
            val imdb = json.optString("imdb_id", "")
            if (imdb.startsWith("tt")) imdb.substring(2) else null
        } catch (e: Exception) {
            Log.e("SubtitleManager", "imdb fetch error", e)
            null
        }
    }

    suspend fun searchArabic(numericImdbId: String): List<SubtitleItem> = withContext(Dispatchers.IO) {
        val out = mutableListOf<SubtitleItem>()
        try {
            val url = "https://rest.opensubtitles.org/search/imdbid-$numericImdbId/sublanguageid-ara"
            val req = Request.Builder()
                .url(url)
                .header("User-Agent", "primetv.ott v1.0")
                .header("x-user-agent", "primetv.ott v1.0")
                .build()

            val res = client.newCall(req).execute()
            if (!res.isSuccessful) {
                Log.e("SubtitleManager", "search HTTP ${res.code}")
                return@withContext emptyList()
            }

            val body = res.body?.string() ?: return@withContext emptyList()
            val arr = JSONArray(body)

            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                if (o.optString("SubLanguageID") != "ara") continue

                out.add(SubtitleItem(
                    id = o.optString("IDSubtitleFile"),
                    fileName = o.optString("SubFileName"),
                    downloadCount = o.optString("SubDownloadsCnt", "0").toLongOrNull() ?: 0L,
                    score = o.optDouble("Score", 0.0),
                    downloadUrl = o.optString("SubDownloadLink")
                ))
            }
            out.sortByDescending { it.score }
            Log.d("SubtitleManager", "found ${out.size} arabic subs")
        } catch (e: Exception) {
            Log.e("SubtitleManager", "search error: ${e.message}", e)
        }
        out
    }

    suspend fun downloadSubtitle(url: String, ctx: Context, id: String): File? = withContext(Dispatchers.IO) {
        try {
            val req = Request.Builder()
                .url(url)
                .header("User-Agent", "Mozilla/5.0")
                .build()

            val res = client.newCall(req).execute()
            if (!res.isSuccessful) return@withContext null
            val raw = res.body?.bytes() ?: return@withContext null

            val decoded = if (raw.size > 2 && raw[0] == 0x1F.toByte() && raw[1] == 0x8B.toByte()) {
                GZIPInputStream(ByteArrayInputStream(raw)).use { it.readBytes() }
            } else {
                raw
            }

            // ✅ CP1256 detection (fixes scrambled Arabic like The Mentalist)
            var text = String(decoded, StandardCharsets.UTF_8)
            if (text.indexOf(REPLACEMENT_CHAR) >= 0) {
                text = String(decoded, Charset.forName("windows-1256"))
            }
            if (text.isNotEmpty() && text[0] == BOM_CHAR) text = text.substring(1)

            // ✅ RTL bidi wrap per Arabic line
            text = text.split("\n").joinToString("\n") { line ->
                if (ARABIC_REGEX.containsMatchIn(line)) RLM + line + RLM else line
            }

            if (!text.contains("-->")) {
                Log.e("SubtitleManager", "NOT a valid SRT!")
                return@withContext null
            }

            val outFile = File(ctx.cacheDir, "sub_$id.srt")
            outFile.writeText(text, StandardCharsets.UTF_8)
            Log.d("SubtitleManager", "SRT saved: ${text.length} chars")
            outFile
        } catch (e: Exception) {
            Log.e("SubtitleManager", "download error: ${e.message}", e)
            null
        }
    }
}
