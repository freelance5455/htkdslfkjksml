package com.streamfetcher.app
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import coil.load
import coil.transform.RoundedCornersTransformation

class Top10Adapter(val items: List<MediaItem>, private val onClick: (MediaItem) -> Unit) :
    RecyclerView.Adapter<Top10Adapter.VH>() {
    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val num: TextView = v.findViewById(R.id.tvNum)
        val img: ImageView = v.findViewById(R.id.ivPoster)
    }
    override fun onCreateViewHolder(p: ViewGroup, t: Int): VH =
        VH(LayoutInflater.from(p.context).inflate(R.layout.item_top10, p, false))
    override fun getItemCount() = items.size
    override fun onBindViewHolder(h: VH, pos: Int) {
        val m = items[pos]
        h.num.text = (pos + 1).toString()
        h.img.load(if (m.posterPath.isNullOrEmpty()) null else Api.IMG + "w342" + m.posterPath) {
            crossfade(true)
            transformations(RoundedCornersTransformation(8f * h.itemView.resources.displayMetrics.density))
            placeholder(R.drawable.placeholder)
        }
        h.itemView.setOnFocusChangeListener { v, f ->
            v.animate().scaleX(if (f) 1.05f else 1f).scaleY(if (f) 1.05f else 1f).setDuration(250).start()
        }
        h.itemView.setOnClickListener { onClick(m) }
    }
}
