package com.streamfetcher.app

import org.json.JSONObject

sealed class HomeItem {
    data class Shelf(val key: String, val title: String, val endpoint: String, val type: String) : HomeItem()
    data class Pills(val title: String, val isTv: Boolean) : HomeItem()
}

object HomeApi {
    fun parse(json: JSONObject?, type: String): List<MediaItem> {
        val out = mutableListOf<MediaItem>()
        val arr = json?.optJSONArray("results") ?: return out
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val t = if (type == "all") o.optString("media_type", "movie") else type
            val date = if (t == "movie") o.optString("release_date") else o.optString("first_air_date")
            out.add(MediaItem(
                id = o.optInt("id"),
                title = if (t == "movie") o.optString("title") else o.optString("name"),
                year = if (date.length >= 4) date.substring(0, 4) else "—",
                posterPath = str(o, "poster_path"),
                backdropPath = str(o, "backdrop_path"),
                type = t,
                rating = o.optDouble("vote_average", 0.0)
            ))
        }
        return out
    }

    private fun str(o: JSONObject, k: String): String? {
        val v = o.opt(k) ?: return null
        if (v == JSONObject.NULL) return null
        val s = v.toString()
        return if (s.isEmpty() || s == "null") null else s
    }
}
