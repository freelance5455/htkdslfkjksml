package com.streamfetcher.app

import android.app.Activity
import android.content.Intent
import android.text.SpannableString
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import coil.load
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

object HeroCarousel {
    private var currentId = 0
    private var current: MediaItem? = null
    private val trending = mutableListOf<MediaItem>()
    private var idx = 0
    
    private var lastFeatureTime = 0L

    fun setup(a: Activity, s: CoroutineScope, autoRotate: Boolean = false) {
        val container = a.findViewById<android.widget.FrameLayout>(R.id.heroContainer) ?: return
        if (container.childCount == 0) {
            android.view.LayoutInflater.from(a).inflate(
                if (autoRotate) R.layout.hero_mobile else R.layout.hero_tv, container, true)
        }
        val root = a.findViewById<View>(R.id.heroRoot) ?: return
        root.setOnClickListener {
            current?.let { m ->
                a.startActivity(Intent(a, DetailActivity::class.java)
                    .putExtra("id", m.id).putExtra("type", m.type).putExtra("title", m.title)
                    .putExtra("year", m.year).putExtra("poster", m.posterPath)
                    .putExtra("backdrop", m.backdropPath).putExtra("rating", m.rating))
            }
        }
        s.launch {
            val j = withContext(Dispatchers.IO) {
                Api.get("${Api.BASE}/trending/all/week?api_key=${Api.TMDB_KEY}")
            }
            val arr = j?.optJSONArray("results") ?: return@launch
            trending.clear()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val type = o.optString("media_type", "movie")
                if (type != "movie" && type != "tv") continue
                if (o.optString("backdrop_path").isEmpty()) continue
                trending.add(MediaItem(o.optInt("id"),
                    if (type == "movie") o.optString("title") else o.optString("name"),
                    o.optString(if (type == "movie") "release_date" else "first_air_date", "").take(4),
                    o.optString("poster_path"), o.optString("backdrop_path"), type,
                    o.optDouble("vote_average")))
                if (trending.size >= 10) break
            }
            if (trending.isEmpty()) return@launch
            idx = 0
            feature(a, s, trending[0])
            if (autoRotate) {
                s.launch {
                    while (true) {
                        delay(7000)
                        idx = (idx + 1) % trending.size
                        feature(a, s, trending[idx])
                    }
                }
            }
        }
    }

    fun feature(a: Activity, s: CoroutineScope, item: MediaItem) {
        if (item.id == 0 || item.id == currentId) return
        currentId = item.id
        current = item
        

        
        s.launch {
            // Fetch details
            val d = withContext(Dispatchers.IO) {
                Api.get("${Api.BASE}/${item.type}/${item.id}?api_key=${Api.TMDB_KEY}")
            }
            val genres = StringBuilder()
            val g = d?.optJSONArray("genres")
            if (g != null) for (i in 0 until minOf(2, g.length())) {
                if (i > 0) genres.append(" · ")
                genres.append(g.getJSONObject(i).optString("name"))
            }
            val dAr = withContext(Dispatchers.IO) {
                Api.get("${Api.BASE}/${item.type}/${item.id}?api_key=${Api.TMDB_KEY}&language=ar-SA")
            }
            val ovAr = dAr?.optString("overview", "") ?: ""
            val overview = if (ovAr.isNotBlank()) ovAr else (d?.optString("overview") ?: "")
            val backdrop = d?.optString("backdrop_path") ?: item.backdropPath ?: ""
            
            apply(a, item, genres.toString(), overview, backdrop)
        }
    }

    private fun apply(a: Activity, m: MediaItem, genres: String, overview: String, backdrop: String) {
        val bd = a.findViewById<ImageView>(R.id.heroBackdrop) ?: return
        val url = when {
            backdrop.isEmpty() -> null
            backdrop.startsWith("http") -> backdrop
            else -> Api.IMG + "w1280" + backdrop
        }
        bd.load(url) {
            crossfade(true)
            listener(
                onStart = { _ ->
                    // Freeze parent layout during image load
                    (bd.parent?.parent as? android.view.View)?.requestLayout()
                }
            )
        }
        a.findViewById<TextView>(R.id.heroTitle)?.text = m.title

        val typeLabel = if (m.type == "movie") "Film" else "Series"

        a.findViewById<TextView>(R.id.heroMeta)?.text = genres

        val descTv = a.findViewById<TextView>(R.id.heroDesc)
        descTv?.text = overview
        descTv?.textDirection = if (overview.any { it.toInt() in 0x0600..0x06FF })
            android.view.View.TEXT_DIRECTION_RTL else android.view.View.TEXT_DIRECTION_LTR
    }
}
