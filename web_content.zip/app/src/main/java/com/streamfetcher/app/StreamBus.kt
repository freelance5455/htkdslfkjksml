package com.streamfetcher.app

object StreamBus {
    var extra: List<StreamOption> = emptyList()
}
