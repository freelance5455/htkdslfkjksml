package com.streamfetcher.app

import android.app.Dialog
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.Tracks
import androidx.media3.common.VideoSize
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class PlayerActivity : AppCompatActivity() {

    private val scope = CoroutineScope(Dispatchers.Main)
    private val clockHandler = Handler(Looper.getMainLooper())
    private val subHandler = Handler(Looper.getMainLooper())
    private var clockRunnable: Runnable? = null
    private var subRunnable: Runnable? = null
    private var player: ExoPlayer? = null
    private var options: List<StreamOption> = emptyList()
    private var current = 0
    private var imdbId: String? = null
    private var tmdbId: Int = 0
    private var mediaType: String = ""
    private var showTitle: String = ""
    private var season: Int = 0
    private var episode: Int = 0
    private var currentSubtitleId: String? = null
    private var currentCloudSubtitleId: String? = null
    private var currentVipSubtitleId: String? = null
    private var subDialog: Dialog? = null
    private var cues: List<SrtCue> = emptyList()
    private var lastCueText: String? = null
    private var controllerVisible = true
    private var resReady = false
    private var resumePos = 0L
    private val saveHandler = Handler(Looper.getMainLooper())
    private val saveRunnable = object : Runnable {
        override fun run() {
            saveProgressNow()
            saveHandler.postDelayed(this, 5000)
        }
    }
    private var fpsReady = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player)

        val arr = JSONArray(intent.getStringExtra("streams") ?: "[]")
        current = intent.getIntExtra("index", 0)
        imdbId = intent.getStringExtra("imdb_id")
        tmdbId = intent.getIntExtra("tmdb_id", 0)
        mediaType = intent.getStringExtra("media_type") ?: ""
        showTitle = intent.getStringExtra("show_title") ?: ""
        season = intent.getIntExtra("season", 0)
        episode = intent.getIntExtra("episode", 0)
        options = (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            StreamOption(
                o.optString("quality"), o.optString("format"),
                o.optString("url"), o.optString("cookie"), o.optString("label"),
                o.optString("referer", ""), o.optString("useragent", "")
            )
        }

        resumePos = ProgressStore.getProgress(this, mediaType, tmdbId, season, episode)
        // Resume diagnostic toast
        if (resumePos > 0) {
            val mins = resumePos / 60000
            android.widget.Toast.makeText(this, "Resume: " + mins + "m (id=" + tmdbId + " S" + season + "E" + episode + ")", android.widget.Toast.LENGTH_LONG).show()
        }
        saveHandler.postDelayed(saveRunnable, 5000)
        // delayed resume safety net (if STATE_READY hook missed)
        saveHandler.postDelayed({
            if (resumePos > 0 && (player?.currentPosition ?: 0L) < 5000L) {
                player?.seekTo(resumePos)
                resumePos = 0
            }
        }, 2500)

        // Always start with highest quality + real format labels
        options = options.map { it.copy(quality = it.quality.replace("· 4K", "").replace("4K", "").trim()) }
            .sortedByDescending { qval(it.quality) }
            .map { it.copy(format = fmtFrom(it.quality)) }
        current = 0

        findViewById<ImageView>(R.id.btnBack).setOnClickListener { finish() }
        findViewById<TextView>(R.id.tvPlayerTitle).text = intent.getStringExtra("title") ?: ""
        findViewById<View>(R.id.btnFormats).setOnClickListener { mergeExtra(); showFormats() }

        // One subtitles button -> modern side panel (VIP first)
        findViewById<ImageView>(R.id.btnCloudSubs).visibility = View.GONE
        findViewById<ImageView>(R.id.btnVipSubs).visibility = View.GONE
        findViewById<ImageView>(R.id.btnSubs).setOnClickListener { openSubtitlePanel() }

        listOf(R.id.btnBack, R.id.btnFormats, R.id.btnSubs).forEach { id ->
            focusScale(findViewById(id))
        }

        clockRunnable = object : Runnable {
            override fun run() {
                findViewById<TextView>(R.id.tvClock).text =
                    SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
                clockHandler.postDelayed(this, 1000)
            }
        }
        clockHandler.post(clockRunnable!!)

        subRunnable = object : Runnable {
            override fun run() {
                val pos = player?.currentPosition ?: -1L
                val tv = findViewById<TextView>(R.id.tvSubOverlay)
                if (pos >= 0 && cues.isNotEmpty()) {
                    val cue = cues.firstOrNull { pos in it.start..it.end }
                    val t = cue?.text
                    if (t != lastCueText) {
                        lastCueText = t
                        if (t.isNullOrEmpty()) tv.visibility = View.GONE
                        else { tv.visibility = View.VISIBLE; tv.text = t }
                    }
                } else if (lastCueText != null) {
                    lastCueText = null; tv.visibility = View.GONE
                }
                subHandler.postDelayed(this, 200)
            }
        }
        subHandler.post(subRunnable!!)

        val topBar = findViewById<View>(R.id.topBar)
        findViewById<PlayerView>(R.id.playerView)
            .setControllerVisibilityListener(object : PlayerView.ControllerVisibilityListener {
                override fun onVisibilityChanged(visibility: Int) {
                    controllerVisible = visibility == View.VISIBLE
                    topBar.visibility = visibility
                    updateHud()
                }
            })

        if (options.isNotEmpty()) play(current, 0L)
    }

    private fun updateHud() {
        findViewById<TextView>(R.id.tvRes).visibility =
            if (controllerVisible && resReady) View.VISIBLE else View.GONE
        findViewById<TextView>(R.id.tvFps).visibility =
            if (controllerVisible && fpsReady) View.VISIBLE else View.GONE
    }

    private fun play(index: Int, resume: Long) {
        current = index
        val opt = options[index]
        (findViewById<View>(R.id.btnFormats) as? TextView)?.text = StreamPicker.qualityTag(opt.quality)
        player?.release()

        try {
            val httpFactory = DefaultHttpDataSource.Factory()
                .setUserAgent("okhttp/4.12.0")
                .setAllowCrossProtocolRedirects(true)
            // Apply referer, useragent, and cookie headers
            val extraHeaders = mutableMapOf<String, String>()
            if (opt.referer.isNotEmpty()) {
                extraHeaders["Referer"] = opt.referer
                extraHeaders["Origin"] = opt.referer.trimEnd('/')
            }
            if (opt.useragent.isNotEmpty()) {
                httpFactory.setUserAgent(opt.useragent)
            }
            if (opt.cookie.isNotEmpty()) {
                extraHeaders["Cookie"] = opt.cookie
            }
            if (extraHeaders.isNotEmpty()) {
                httpFactory.setDefaultRequestProperties(extraHeaders)
            }

            val dataSourceFactory = DefaultDataSource.Factory(this, httpFactory)
            val mediaSourceFactory = DefaultMediaSourceFactory(this)
                .setDataSourceFactory(dataSourceFactory)

            player = ExoPlayer.Builder(this)
                .setMediaSourceFactory(mediaSourceFactory)
                .build()

        player?.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY) setResult(997)
                if (state == Player.STATE_READY && resumePos > 0) {
                    player?.seekTo(resumePos)
                    resumePos = 0
                    Toast.makeText(this@PlayerActivity, "Resumed", Toast.LENGTH_SHORT).show()
                }
            }
        })

            player?.trackSelectionParameters = player!!.trackSelectionParameters.buildUpon()
                .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                .build()

            player?.addListener(object : Player.Listener {
                override fun onPlayerError(error: PlaybackException) {
                    Log.e("PlayerActivity", "Playback error: ${error.message}")
                    Toast.makeText(this@PlayerActivity, "❌ Error: ${error.errorCodeName}", Toast.LENGTH_LONG).show()
                    player?.stop()
                }

                override fun onVideoSizeChanged(size: VideoSize) {
                    if (size.width > 0 && size.height > 0) {
                        resReady = true
                        findViewById<TextView>(R.id.tvRes).text = "${size.width}x${size.height}"
                        updateHud()
                    }
                }

                override fun onTracksChanged(tracks: Tracks) {
                    val p = player ?: return
                    val fr = p.videoFormat?.frameRate ?: 0f
                    if (fr > 0f) {
                        fpsReady = true
                        findViewById<TextView>(R.id.tvFps).text = "${Math.round(fr)} fps"
                        updateHud()
                    }
                }
            })

            val playerView = findViewById<PlayerView>(R.id.playerView)
            playerView.player = player
            playerView.subtitleView?.visibility = View.GONE

            player?.setMediaItem(MediaItem.fromUri(opt.url))
            player?.prepare()

        // Auto-fallback: if stream fails, try next one
        player?.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                val total = options.size
                val nx = nextSourceIndex()
                if (nx >= 0) { current = nx
                                        Toast.makeText(this@PlayerActivity,
                        "Server failed. Trying " + (current + 1) + "/" + total + "...",
                        Toast.LENGTH_SHORT).show()
                    playStream(current)
                } else {
                    Toast.makeText(this@PlayerActivity,
                        "Switching source...", Toast.LENGTH_SHORT).show()
                    setResult(998)
                    finish()
                }
            }
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                if (isPlaying) {
                    Toast.makeText(this@PlayerActivity,
                        "Playing: " + options[current].label, Toast.LENGTH_SHORT).show()
                }
            }
        })
            if (resume > 0) player?.seekTo(resume)
            player?.playWhenReady = true
        } catch (e: Exception) {
            Log.e("PlayerActivity", "Setup error: ${e.message}")
            Toast.makeText(this, "❌ Failed to start player.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showFormats() {
        if (options.isEmpty()) return
        val pos = player?.currentPosition ?: 0L
        StreamPicker.show(this, options, current) { i -> play(i, pos) }
    }







    private var vipSubCache: List<VipSubtitleItem> = emptyList()
    private var cloudSubCache: List<CloudSubtitleItem> = emptyList()
    private var openSubCache: List<SubtitleItem> = emptyList()

    private fun openSubtitlePanel() {
        StreamPicker.showSubtitlePanel(
            this,
            listOf("VIP Subtitles", "Cloud Subtitles", "OpenSubtitles"),
            "VIP Subtitles",
            load = { source, cb ->
                scope.launch {
                    val rows = mutableListOf<StreamPicker.SubRow>()
                    when (source) {
                        "VIP Subtitles" -> if (tmdbId != 0) {
                            val ss = if (mediaType == "tv" && season > 0) season else null
                            val ee = if (mediaType == "tv" && episode > 0) episode else null
                            val subs = withContext(Dispatchers.IO) {
                                VipSubtitleManager.search(tmdbId, showTitle, ss, ee, mediaType)
                            }
                            vipSubCache = subs
                            subs.forEachIndexed { i, it ->
                                rows.add(StreamPicker.SubRow(i.toString(), it.release, langName(it.language)))
                            }
                        }
                        "Cloud Subtitles" -> if (tmdbId != 0) {
                            val subs = withContext(Dispatchers.IO) { CloudSubtitleManager.searchSubtitles(tmdbId) }
                            cloudSubCache = subs
                            subs.forEachIndexed { i, it ->
                                rows.add(StreamPicker.SubRow(i.toString(), langName(it.language), langName(it.language)))
                            }
                        }
                        else -> {
                            val im = imdbId
                            if (!im.isNullOrEmpty()) {
                                val subs = withContext(Dispatchers.IO) { SubtitleManager.searchArabic(im) }
                                openSubCache = subs
                                subs.forEachIndexed { i, it ->
                                    rows.add(StreamPicker.SubRow(i.toString(), it.fileName, ""))
                                }
                            }
                        }
                    }
                    cb(rows)
                }
            },
            onPick = { source, row ->
                when (source) {
                    "VIP Subtitles" -> pickVipSubtitle(vipSubCache.getOrNull(row.key.toInt()))
                    "Cloud Subtitles" -> pickCloudSubtitle(cloudSubCache.getOrNull(row.key.toInt()))
                    else -> pickSubtitle(openSubCache.getOrNull(row.key.toInt()))
                }
            }
        )
    }


    private fun langName(code: String): String = when (code.lowercase()) {
        "ar" -> "Arabic"
        "en" -> "English"
        "fr" -> "French"
        "es" -> "Spanish"
        "de" -> "German"
        "it" -> "Italian"
        "ru" -> "Russian"
        "tr" -> "Turkish"
        "ur" -> "Urdu"
        "hi" -> "Hindi"
        "id" -> "Indonesian"
        "ms" -> "Malay"
        "pt" -> "Portuguese"
        "bn" -> "Bengali"
        "fil", "tl" -> "Filipino"
        "zh" -> "Chinese"
        "ja" -> "Japanese"
        "ko" -> "Korean"
        else -> code.replaceFirstChar { c -> if (c.isLowerCase()) c.titlecase() else c.toString() }
    }

    private fun openSubtitleDialog() {
        val imdb = imdbId ?: return
        subDialog?.dismiss()
        subDialog = SubtitleDialog.show(this, emptyList(), currentSubtitleId, true, {}, { _, _ -> })

        scope.launch {
            val subs = withContext(Dispatchers.IO) { SubtitleManager.searchArabic(imdb) }
            subDialog?.dismiss()
            if (subs.isEmpty()) {
                Toast.makeText(this@PlayerActivity, "❌ No Arabic subtitles found (OpenSubtitles)", Toast.LENGTH_LONG).show()
            }
            subDialog = SubtitleDialog.show(
                this@PlayerActivity, subs, currentSubtitleId, false,
                onPick = { item -> subDialog?.dismiss(); pickSubtitle(item) },
                onAttach = { _, _ -> }
            )
        }
    }

    private fun openCloudSubtitleDialog() {
        if (tmdbId == 0) return
        subDialog?.dismiss()
        subDialog = CloudSubtitleDialog.show(this, emptyList(), currentCloudSubtitleId, true, {}, { _, _ -> })

        scope.launch {
            val subs = withContext(Dispatchers.IO) { CloudSubtitleManager.searchSubtitles(tmdbId) }
            subDialog?.dismiss()
            if (subs.isEmpty()) {
                Toast.makeText(this@PlayerActivity, "❌ No Arabic cloud subtitles found", Toast.LENGTH_LONG).show()
            }
            subDialog = CloudSubtitleDialog.show(
                this@PlayerActivity, subs, currentCloudSubtitleId, false,
                onPick = { item -> subDialog?.dismiss(); pickCloudSubtitle(item) },
                onAttach = { _, _ -> }
            )
        }
    }

    private fun openVipSubtitleDialog() {
        if (tmdbId == 0) return
        subDialog?.dismiss()
        subDialog = VipSubtitleDialog.show(this, emptyList(), currentVipSubtitleId, true, {}, { _, _ -> })

        scope.launch {
            val s = if (mediaType == "tv" && season > 0) season else null
            val e = if (mediaType == "tv" && episode > 0) episode else null
            val subs = withContext(Dispatchers.IO) {
                VipSubtitleManager.search(tmdbId, showTitle, s, e, mediaType)
            }
            subDialog?.dismiss()
            if (subs.isEmpty()) {
                Toast.makeText(this@PlayerActivity, "❌ No VIP subtitles found", Toast.LENGTH_LONG).show()
            }
            subDialog = VipSubtitleDialog.show(
                this@PlayerActivity, subs, currentVipSubtitleId, false,
                onPick = { item -> subDialog?.dismiss(); pickVipSubtitle(item) },
                onAttach = { _, _ -> }
            )
        }
    }

    private fun pickSubtitle(item: SubtitleItem?) {
        if (item == null) {
            currentSubtitleId = null; cues = emptyList(); lastCueText = null
            findViewById<TextView>(R.id.tvSubOverlay).visibility = View.GONE
            Toast.makeText(this, "OpenSubtitles off", Toast.LENGTH_SHORT).show()
            return
        }
        Toast.makeText(this, "⬇ Downloading ${item.fileName}...", Toast.LENGTH_SHORT).show()
        scope.launch {
            val file = withContext(Dispatchers.IO) {
                SubtitleManager.downloadSubtitle(item.downloadUrl, this@PlayerActivity, item.id)
            }
            if (file != null && file.exists() && file.length() > 0) {
                val parsed = withContext(Dispatchers.IO) { SrtParser.parse(file.readText()) }
                if (parsed.isNotEmpty()) {
                    currentSubtitleId = item.id; currentCloudSubtitleId = null; currentVipSubtitleId = null
                    cues = parsed; lastCueText = null
                    Toast.makeText(this@PlayerActivity, "✓ ${parsed.size} subtitle lines loaded", Toast.LENGTH_SHORT).show()
                } else Toast.makeText(this@PlayerActivity, "❌ Could not parse subtitle file", Toast.LENGTH_LONG).show()
            } else Toast.makeText(this@PlayerActivity, "❌ Subtitle download failed", Toast.LENGTH_LONG).show()
        }
    }

    private fun pickCloudSubtitle(item: CloudSubtitleItem?) {
        if (item == null) {
            currentCloudSubtitleId = null; cues = emptyList(); lastCueText = null
            findViewById<TextView>(R.id.tvSubOverlay).visibility = View.GONE
            Toast.makeText(this, "Cloud subtitles off", Toast.LENGTH_SHORT).show()
            return
        }
        Toast.makeText(this, "⬇ Downloading cloud subtitle...", Toast.LENGTH_SHORT).show()
        scope.launch {
            val file = withContext(Dispatchers.IO) {
                CloudSubtitleManager.downloadSubtitle(item.fileId, this@PlayerActivity)
            }
            if (file != null && file.exists() && file.length() > 0) {
                val parsed = withContext(Dispatchers.IO) { SrtParser.parse(file.readText()) }
                if (parsed.isNotEmpty()) {
                    currentCloudSubtitleId = item.fileId; currentSubtitleId = null; currentVipSubtitleId = null
                    cues = parsed; lastCueText = null
                    Toast.makeText(this@PlayerActivity, "✓ ${parsed.size} cloud subtitle lines loaded", Toast.LENGTH_SHORT).show()
                } else Toast.makeText(this@PlayerActivity, "❌ Could not parse cloud subtitle", Toast.LENGTH_LONG).show()
            } else Toast.makeText(this@PlayerActivity, "❌ Cloud subtitle download failed", Toast.LENGTH_LONG).show()
        }
    }

    private fun pickVipSubtitle(item: VipSubtitleItem?) {
        if (item == null) {
            currentVipSubtitleId = null; cues = emptyList(); lastCueText = null
            findViewById<TextView>(R.id.tvSubOverlay).visibility = View.GONE
            Toast.makeText(this, "VIP subtitles off", Toast.LENGTH_SHORT).show()
            return
        }
        Toast.makeText(this, "⬇ Downloading VIP subtitle...", Toast.LENGTH_SHORT).show()
        scope.launch {
            val file = withContext(Dispatchers.IO) {
                VipSubtitleManager.downloadSubtitle(item.fileId, this@PlayerActivity)
            }
            if (file != null && file.exists() && file.length() > 0) {
                val parsed = withContext(Dispatchers.IO) { SrtParser.parse(file.readText()) }
                if (parsed.isNotEmpty()) {
                    currentVipSubtitleId = item.subtitleId; currentSubtitleId = null; currentCloudSubtitleId = null
                    cues = parsed; lastCueText = null
                    Toast.makeText(this@PlayerActivity, "✓ ${parsed.size} VIP subtitle lines loaded", Toast.LENGTH_SHORT).show()
                } else Toast.makeText(this@PlayerActivity, "❌ Could not parse VIP subtitle", Toast.LENGTH_LONG).show()
            } else Toast.makeText(this@PlayerActivity, "❌ VIP subtitle download failed", Toast.LENGTH_LONG).show()
        }
    }


    override fun onPause() {
        saveWatchProgress()
        super.onPause()
    }

    private fun saveWatchProgress() {
        val p = player ?: return
        ProgressStore.saveProgress(ctx = this, id = tmdbId, type = mediaType, title = showTitle.replace(Regex("[\\s•]*S\\d+E\\d+"), "").trim(), season = season, episode = episode, position = p.currentPosition, duration = p.duration)
    }

    override fun onDestroy() {
        clockRunnable?.let { clockHandler.removeCallbacks(it) }
        subRunnable?.let { subHandler.removeCallbacks(it) }
        subDialog?.dismiss()
        player?.release()
        super.onDestroy()
    }


    private fun saveProgressNow() {
        val p = player ?: return
        val dur = p.duration
        val pos = p.currentPosition
        if (dur <= 0 || pos <= 0) return
        if (pos > dur * 0.95) {
            ProgressStore.clearProgress(this, mediaType, tmdbId, season, episode)
            return
        }
        ProgressStore.saveProgress(ctx = this, id = tmdbId, type = mediaType,
            intent.getStringExtra("title") ?: showTitle,
            season, episode, pos, dur)
    }


    private fun mergeExtra() {
        val ex = StreamBus.extra
        if (ex.isNotEmpty()) {
            val merged = options.toMutableList()
            for (o in ex) if (merged.none { it.url == o.url }) merged.add(o)
            options = merged
            StreamBus.extra = emptyList()
            Toast.makeText(this, "All sources loaded: " + options.size, Toast.LENGTH_SHORT).show()
        }
    }



    private fun fmtFrom(q: String?): String = when {
        qval(q) >= 2160 -> "4K"
        qval(q) >= 1080 -> "FHD"
        qval(q) >= 720 -> "HD"
        else -> "SD"
    }


    private fun nextSourceIndex(): Int {
        val curLabel = options.getOrNull(current)?.label
        for (i in current + 1 until options.size) {
            if (options[i].label != curLabel) return i
        }
        return -1
    }

    private fun qval(q: String?): Int {
        if (q == null) return 0
        val n = q.replace(Regex("[^0-9]"), "").toIntOrNull() ?: 0
        if (n > 0) return n
        return when {
            q.contains("4k", true) || q.contains("uhd", true) -> 2160
            q.contains("fhd", true) -> 1080
            q.contains("hd", true) -> 720
            q.contains("sd", true) -> 480
            else -> 0
        }
    }

    private fun playStream(idx: Int) {
        if (idx < 0 || idx >= options.size) return
        val opt = options[idx]
        try {
            val factory = DefaultHttpDataSource.Factory()
                .setAllowCrossProtocolRedirects(true)
                .setConnectTimeoutMs(15000)
                .setReadTimeoutMs(15000)
            val headers = mutableMapOf<String, String>()
            try {
                val r = StreamOption::class.java.getDeclaredField("referer").get(opt) as? String
                if (!r.isNullOrEmpty()) headers["Referer"] = r
            } catch (t: Throwable) {}
            try {
                val c = StreamOption::class.java.getDeclaredField("cookie").get(opt) as? String
                if (!c.isNullOrEmpty()) headers["Cookie"] = c
            } catch (t: Throwable) {}
            try {
                val u = StreamOption::class.java.getDeclaredField("userAgent").get(opt) as? String
                if (!u.isNullOrEmpty()) factory.setUserAgent(u)
            } catch (t: Throwable) {}
            if (headers.isNotEmpty()) factory.setDefaultRequestProperties(headers)
            val dataSource = DefaultDataSource.Factory(this, factory)
            val source = DefaultMediaSourceFactory(dataSource).createMediaSource(MediaItem.fromUri(opt.url))
            player?.setMediaSource(source)
            player?.prepare()
            if (resumePos > 0) player?.seekTo(resumePos)
            player?.playWhenReady = true
        } catch (t: Throwable) {
            Log.e("Player", "playStream failed", t)
        }
    }

    private fun buildMediaSource(opt: StreamOption): androidx.media3.exoplayer.source.MediaSource {
        val factory = DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15000)
            .setReadTimeoutMs(15000)
        if (opt.useragent.isNotEmpty()) factory.setUserAgent(opt.useragent)
        if (opt.referer.isNotEmpty()) factory.setDefaultRequestProperties(mapOf("Referer" to opt.referer))
        if (opt.cookie.isNotEmpty()) factory.setDefaultRequestProperties(mapOf("Cookie" to opt.cookie))
        val dataSource = DefaultDataSource.Factory(this, factory)
        return DefaultMediaSourceFactory(dataSource).createMediaSource(MediaItem.fromUri(opt.url))
    }


    private fun focusScale(v: View?) {
        v ?: return
        v.setOnFocusChangeListener { view, focused ->
            view.animate().scaleX(if (focused) 1.05f else 1f)
                .scaleY(if (focused) 1.05f else 1f).setDuration(180).start()
        }
    }

}
