package com.streamfetcher.app

import android.app.Activity
import android.view.KeyEvent
import android.view.View
import android.widget.ScrollView
import androidx.recyclerview.widget.RecyclerView

/** TV-only behavior. Edit this file for TV changes — phone never touches it. */
object TvHome {

    /** 1 press = jump whole row. Returns true when consumed. */
    fun tryRowJump(a: Activity, keyCode: Int): Boolean {
        if (keyCode != KeyEvent.KEYCODE_DPAD_DOWN && keyCode != KeyEvent.KEYCODE_DPAD_UP) return false
        val ids = mutableListOf<Int>()
        if (a.findViewById<View>(R.id.rvContinue).visibility == View.VISIBLE) ids.add(R.id.rvContinue)
        ids.add(R.id.rvNow); ids.add(R.id.rvPopularTv); ids.add(R.id.rvTop); ids.add(R.id.rvKids)
        val f = a.currentFocus
        var cur = -1
        for ((i, id) in ids.withIndex()) {
            val rv = a.findViewById<RecyclerView>(id)
            var p: Any? = f?.parent
            while (p != null) { if (p === rv) { cur = i; break }; p = (p as? View)?.parent }
            if (cur == i) break
        }
        if (cur < 0) return false
        val next = if (keyCode == KeyEvent.KEYCODE_DPAD_DOWN) cur + 1 else cur - 1
        if (next !in 0 until ids.size) return false
        val target = a.findViewById<RecyclerView>(ids[next])
        if (target.childCount == 0) return false
        val src = a.findViewById<RecyclerView>(ids[cur])
        val pos = f?.let { src.getChildAdapterPosition(it) } ?: -1
        val idx = if (pos < 0) 0 else minOf(pos, target.childCount - 1)
        target.getChildAt(idx)?.requestFocus()
        return true
    }

    /** Positions the focused row 50dp below scroll top (title always visible). */
    fun centerRow(scroll: ScrollView, row: View) {
        var top = 0
        var v: View? = row
        while (v != null && v !== scroll) { top += v.top; v = v.parent as? View }
        val d = row.resources.displayMetrics.density
        val target = top - (50 * d).toInt()
        scroll.smoothScrollTo(0, target.coerceAtLeast(0))
    }
}
