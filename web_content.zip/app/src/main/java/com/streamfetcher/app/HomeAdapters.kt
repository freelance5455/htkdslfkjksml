package com.streamfetcher.app

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import coil.load
import coil.transform.RoundedCornersTransformation

class PosterAdapter(
    private var items: List<MediaItem>,
    private val layoutRes: Int,
    private val onClick: (MediaItem) -> Unit
) : RecyclerView.Adapter<PosterAdapter.VH>() {

    fun updateItems(newItems: List<MediaItem>) {
        android.util.Log.d("ROW_DEBUG", "PosterAdapter.updateItems called: ${newItems.size} items")
        val diffResult = androidx.recyclerview.widget.DiffUtil.calculateDiff(object : androidx.recyclerview.widget.DiffUtil.Callback() {
            override fun getOldListSize() = items.size
            override fun getNewListSize() = newItems.size
            override fun areItemsTheSame(oldPos: Int, newPos: Int) = items[oldPos].id == newItems[newPos].id
            override fun areContentsTheSame(oldPos: Int, newPos: Int) = items[oldPos] == newItems[newPos]
        })
        items = newItems
        diffResult.dispatchUpdatesTo(this)
    }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val img: ImageView = v.findViewById(R.id.ivPoster)
        val badge: TextView? = v.findViewById(R.id.tvRating)
        val title: TextView? = v.findViewById(R.id.tvTitle)
    }
    override fun onCreateViewHolder(p: ViewGroup, t: Int): VH =
        VH(LayoutInflater.from(p.context).inflate(layoutRes, p, false))
    override fun getItemCount() = items.size
    override fun onBindViewHolder(h: VH, pos: Int) {
        val m = items[pos]
        h.title?.text = m.title
        if (h.badge != null) {
            if (m.rating > 0) {
                h.badge.text = "★ " + String.format("%.1f", m.rating)
                h.badge.visibility = View.VISIBLE
            } else h.badge.visibility = View.GONE
        }
        val url = if (m.posterPath.isNullOrEmpty()) null else Api.IMG + "w342" + m.posterPath
        h.img.load(url) {
            crossfade(true)
            transformations(RoundedCornersTransformation(12f * h.itemView.resources.displayMetrics.density))
            placeholder(R.drawable.placeholder)
        }
        h.itemView.setOnFocusChangeListener { _, focused ->
            h.itemView.animate().scaleX(if (focused) 1.05f else 1f)
                .scaleY(if (focused) 1.05f else 1f).setDuration(200).start()
        }
        h.itemView.setOnClickListener { onClick(m) }
        h.itemView.setOnLongClickListener {
            val added = Library.toggleMyList(h.itemView.context, m)
            android.widget.Toast.makeText(h.itemView.context,
                if (added) "✓ Added to My List" else "Removed from My List",
                android.widget.Toast.LENGTH_SHORT).show()
            true
        }
    }
}

class RowAdapter(
    private val title: String,
    private val items: List<MediaItem>,
    private val onClick: (MediaItem) -> Unit
) : RecyclerView.Adapter<RowAdapter.VH>() {
    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val img: ImageView = v.findViewById(R.id.ivPoster)
        val badge: TextView? = v.findViewById(R.id.tvRating)
        val title: TextView? = v.findViewById(R.id.tvTitle)
    }
    override fun onCreateViewHolder(p: ViewGroup, t: Int): VH =
        VH(LayoutInflater.from(p.context).inflate(R.layout.item_poster, p, false))
    override fun getItemCount() = items.size
    override fun onBindViewHolder(h: VH, pos: Int) {
        val m = items[pos]
        h.title?.text = m.title
        if (h.badge != null) {
            if (m.rating > 0) {
                h.badge.text = "★ " + String.format("%.1f", m.rating)
                h.badge.visibility = View.VISIBLE
            } else h.badge.visibility = View.GONE
        }
        val url = if (m.posterPath.isNullOrEmpty()) null else Api.IMG + "w342" + m.posterPath
        h.img.load(url) {
            crossfade(true)
            transformations(RoundedCornersTransformation(12f * h.itemView.resources.displayMetrics.density))
            placeholder(R.drawable.placeholder)
        }
        h.itemView.setOnFocusChangeListener { _, focused ->
            h.itemView.animate().scaleX(if (focused) 1.05f else 1f)
                .scaleY(if (focused) 1.05f else 1f).setDuration(200).start()
        }
        h.itemView.setOnClickListener { onClick(m) }
        h.itemView.setOnLongClickListener {
            val added = Library.toggleMyList(h.itemView.context, m)
            android.widget.Toast.makeText(h.itemView.context,
                if (added) "✓ Added to My List" else "Removed from My List",
                android.widget.Toast.LENGTH_SHORT).show()
            true
        }
    }
}

class GridAdapter(
    private val items: List<MediaItem>,
    private val onClick: (MediaItem) -> Unit,
    private val refreshOnRemove: Boolean = false
) : RecyclerView.Adapter<GridAdapter.VH>() {
    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val img: ImageView = v.findViewById(R.id.ivPoster)
        val title: TextView? = v.findViewById(R.id.tvTitle)
        val rating: TextView? = v.findViewById(R.id.tvRating)
    }
    override fun onCreateViewHolder(p: ViewGroup, t: Int): VH =
        VH(LayoutInflater.from(p.context).inflate(R.layout.item_grid, p, false))
    override fun getItemCount() = items.size
    override fun onBindViewHolder(h: VH, pos: Int) {
        val m = items[pos]
        h.title?.text = m.title
        if (m.rating > 0) {
            h.rating?.visibility = View.VISIBLE
            h.rating?.text = "★ ${String.format("%.1f", m.rating)}"
        } else {
            h.rating?.visibility = View.GONE
        }
        val url = if (m.posterPath.isNullOrEmpty()) null else Api.IMG + "w342" + m.posterPath
        h.img.load(url) {
            crossfade(true)
            transformations(RoundedCornersTransformation(12f * h.itemView.resources.displayMetrics.density))
            placeholder(R.drawable.placeholder)
        }
        val card = h.itemView.findViewById<View>(R.id.cardPoster) ?: h.itemView
        card.foreground = h.itemView.context.getDrawable(R.drawable.focus_red)
        h.itemView.setOnFocusChangeListener { _, focused ->
            card.animate().scaleX(if (focused) 1.05f else 1f)
                .scaleY(if (focused) 1.05f else 1f).setDuration(200).start()
        }
        h.itemView.setOnClickListener { onClick(m) }
        h.itemView.setOnLongClickListener {
            val added = Library.toggleMyList(h.itemView.context, m)
            if (!added && refreshOnRemove) {
                (items as? MutableList<MediaItem>)?.let { lst ->
                    val idx = lst.indexOfFirst { it.id == m.id && it.type == m.type }
                    if (idx >= 0) {
                        lst.removeAt(idx)
                        notifyItemRemoved(idx)
                    }
                }
            }
            android.widget.Toast.makeText(
                h.itemView.context,
                if (added) "✓ Added to My List" else "Removed from My List",
                android.widget.Toast.LENGTH_SHORT
            ).show()
            true
        }
    }
}

class ChildAdapter(
    private val items: List<MediaItem>,
    private val onClick: (MediaItem) -> Unit
) : RecyclerView.Adapter<ChildAdapter.VH>() {
    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val img: ImageView = v.findViewById(R.id.ivPoster)
        val badge: TextView? = v.findViewById(R.id.tvRating)
    }
    override fun onCreateViewHolder(p: ViewGroup, t: Int): VH =
        VH(LayoutInflater.from(p.context).inflate(R.layout.item_poster, p, false))
    override fun getItemCount() = items.size
    override fun onBindViewHolder(h: VH, pos: Int) {
        val m = items[pos]
        if (h.badge != null) {
            if (m.rating > 0) {
                h.badge.text = "★ " + String.format("%.1f", m.rating)
                h.badge.visibility = View.VISIBLE
            } else h.badge.visibility = View.GONE
        }
        val url = if (m.posterPath.isNullOrEmpty()) null else Api.IMG + "w342" + m.posterPath
        h.img.load(url) {
            crossfade(true)
            transformations(RoundedCornersTransformation(12f * h.itemView.resources.displayMetrics.density))
            placeholder(R.drawable.placeholder)
        }
        h.itemView.setOnClickListener { onClick(m) }
        h.itemView.setOnLongClickListener {
            val added = Library.toggleMyList(h.itemView.context, m)
            android.widget.Toast.makeText(h.itemView.context,
                if (added) "✓ Added to My List" else "Removed from My List",
                android.widget.Toast.LENGTH_SHORT).show()
            true
        }
    }
}

class ContinueAdapter(
    private val items: List<Pair<Library.ContinueItem, String?>>,
    private val onClick: (Library.ContinueItem) -> Unit
) : RecyclerView.Adapter<ContinueAdapter.VH>() {
    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val img: ImageView = v.findViewById(R.id.ivPoster)
        val title: TextView = v.findViewById(R.id.tvTitle)
        val progress: android.widget.ProgressBar? = v.findViewById(R.id.progress)
    }
    override fun onCreateViewHolder(p: ViewGroup, t: Int): VH =
        VH(LayoutInflater.from(p.context).inflate(R.layout.item_continue, p, false))
    override fun getItemCount() = items.size
    override fun onBindViewHolder(h: VH, pos: Int) {
        val pair = items[pos]
        val m = pair.first
        val poster = pair.second
        val cleanTitle = m.title.replace(Regex("[\\s•]*S\\d+E\\d+"), "").trim()
        h.title.text = if (m.type == "tv") "$cleanTitle  S${m.season}E${m.episode}" else cleanTitle
        if (h.progress != null && m.dur > 0) {
            h.progress.max = m.dur.toInt()
            h.progress.progress = m.pos.toInt()
            h.progress.visibility = View.VISIBLE
        } else h.progress?.visibility = View.GONE
        val url = if (poster.isNullOrEmpty()) null else Api.IMG + "w342" + poster
        h.img.load(url) {
            crossfade(true)
            transformations(RoundedCornersTransformation(8f * h.itemView.resources.displayMetrics.density))
            placeholder(R.drawable.placeholder)
        }
        val card = h.itemView.findViewById<View>(R.id.cardPoster) ?: h.itemView
        card.foreground = h.itemView.context.getDrawable(R.drawable.focus_red)
        h.itemView.setOnFocusChangeListener { _, focused ->
            card.animate().scaleX(if (focused) 1.05f else 1f)
                .scaleY(if (focused) 1.05f else 1f).setDuration(200).start()
        }
        h.itemView.setOnClickListener { onClick(m) }
    }
}

class ChipAdapter(
    private val items: List<Pair<String, Int>>,
    private val onPick: (Pair<String, Int>) -> Unit
) : RecyclerView.Adapter<ChipAdapter.VH>() {
    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val tv: TextView = v as TextView
    }
    override fun onCreateViewHolder(p: ViewGroup, t: Int): VH =
        VH(LayoutInflater.from(p.context).inflate(R.layout.item_chip, p, false) as TextView)
    override fun getItemCount() = items.size
    override fun onBindViewHolder(h: VH, pos: Int) {
        val item = items[pos]
        h.tv.text = item.first
        h.tv.setOnFocusChangeListener { v, focused ->
            (v as TextView).setTextColor(if (focused) 0xFF000000.toInt() else 0xFFFFFFFF.toInt())
            v.animate().scaleX(if (focused) 1.05f else 1f)
                .scaleY(if (focused) 1.05f else 1f).setDuration(180).start()
        }
        h.itemView.setOnClickListener { onPick(item) }
    }
}
