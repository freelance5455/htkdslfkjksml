package com.fc.ziptoapk

import android.app.Activity
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.net.Uri
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipInputStream

class MainActivity : Activity() {
    // ---- palette
    private val BG1 = Color.parseColor("#0B0F1E")
    private val BG2 = Color.parseColor("#1B1245")
    private val VIOLET = Color.parseColor("#7C5CFF")
    private val CYAN = Color.parseColor("#22D3EE")
    private val GREEN = Color.parseColor("#34D399")
    private val AMBER = Color.parseColor("#FBBF24")
    private val RED = Color.parseColor("#F87171")
    private val TEXT = Color.parseColor("#F4F6FF")
    private val MUTED = Color.parseColor("#A3ABC8")
    private val GLASS = Color.parseColor("#14FFFFFF")
    private val STROKE = Color.parseColor("#26FFFFFF")

    private lateinit var status: TextView
    private lateinit var details: TextView
    private lateinit var dot: View
    private lateinit var progress: ProgressBar
    private lateinit var pickButton: Button
    private lateinit var scanButton: Button
    private lateinit var previewButton: Button
    private var selectedUri: Uri? = null
    private var extractedDir: File? = null
    private var htmlFile: File? = null
    private var inPreview = false
    private var curStatus = "READY"
    private var curColor = MUTED
    private var curDetails = "ZIP ফাইল নির্বাচন করে Scan চাপুন।"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildHome()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (inPreview) buildHome() else super.onBackPressed()
    }

    // ---- small UI helpers
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun shape(
        fill: Int, radius: Int, stroke: Int = 0, colors: IntArray? = null,
        o: GradientDrawable.Orientation = GradientDrawable.Orientation.LEFT_RIGHT
    ) = GradientDrawable().apply {
        if (colors != null) { orientation = o; setColors(colors) } else setColor(fill)
        cornerRadius = dp(radius).toFloat()
        if (stroke != 0) setStroke(dp(1), stroke)
    }

    private fun tv(t: String, size: Float, color: Int, bold: Boolean = false, grav: Int = Gravity.START) =
        TextView(this).apply {
            text = t; setTextSize(TypedValue.COMPLEX_UNIT_SP, size); setTextColor(color); gravity = grav
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun lp(top: Int = 0, w: Int = -1, h: Int = -2) =
        LinearLayout.LayoutParams(w, h).apply { topMargin = dp(top) }

    private fun card(accent: Int = STROKE) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = shape(GLASS, 24, accent)
        setPadding(dp(18), dp(18), dp(18), dp(18))
    }

    private fun btn(label: String, gradient: IntArray?, textColor: Int = Color.WHITE) = Button(this).apply {
        text = label; isAllCaps = false; setTextColor(textColor)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f); typeface = Typeface.DEFAULT_BOLD
        stateListAnimator = null; minHeight = dp(54); minimumHeight = dp(54)
        val base = if (gradient != null) shape(0, 16, 0, gradient) else shape(GLASS, 16, STROKE)
        background = RippleDrawable(ColorStateList.valueOf(Color.parseColor("#33FFFFFF")), base, null)
    }

    private fun setBtn(b: Button, on: Boolean) { b.isEnabled = on; b.alpha = if (on) 1f else 0.4f }

    private fun setStatus(t: String, c: Int, d: String? = null) {
        curStatus = t; curColor = c; if (d != null) curDetails = d
        status.text = t; details.text = curDetails
        (dot.background as GradientDrawable).setColor(c)
    }

    @Suppress("DEPRECATION")
    private fun withInsets(root: View) {
        root.setOnApplyWindowInsetsListener { v, ins ->
            v.setPadding(ins.systemWindowInsetLeft, ins.systemWindowInsetTop, ins.systemWindowInsetRight, ins.systemWindowInsetBottom)
            ins
        }
    }

    private fun chip(t: String) = tv(t, 12f, TEXT, true, Gravity.CENTER).apply {
        background = shape(GLASS, 50, STROKE); setPadding(dp(6), dp(9), dp(6), dp(9))
        layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(4); marginEnd = dp(4) }
    }

    // ---- home screen
    private fun buildHome() {
        inPreview = false
        window.statusBarColor = BG1; window.navigationBarColor = BG2
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(BG1, BG2, BG1))
        }
        withInsets(root)
        val scroll = ScrollView(this).apply { isFillViewport = true; overScrollMode = View.OVER_SCROLL_NEVER }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(12), dp(20), dp(28))
        }

        // top pill
        val top = tv("v1.0  •  OFFLINE", 11f, MUTED, true).apply {
            background = shape(GLASS, 50, STROKE); setPadding(dp(12), dp(6), dp(12), dp(6))
            layoutParams = LinearLayout.LayoutParams(-2, -2).apply { gravity = Gravity.END }
        }
        // hero
        val badge = tv("▣", 36f, Color.WHITE, true, Gravity.CENTER).apply {
            background = shape(0, 26, 0, intArrayOf(VIOLET, CYAN), GradientDrawable.Orientation.TL_BR)
            layoutParams = LinearLayout.LayoutParams(dp(80), dp(80)).apply { gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(22) }
        }
        val title = tv("ZIP → APK STUDIO", 26f, TEXT, true, Gravity.CENTER).apply { letterSpacing = 0.04f }
        val sub = tv("PROJECT CHECKER  •  NO ADS  •  PRIVATE", 11f, MUTED, false, Gravity.CENTER).apply { letterSpacing = 0.1f }
        val chips = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(chip("✓ Offline")); addView(chip("✓ No Ads")); addView(chip("✓ Safe Scan"))
        }

        // main card
        pickButton = btn("＋   ZIP FILE SELECT করুন", intArrayOf(VIOLET, CYAN)).apply { setOnClickListener { pickZip() } }
        scanButton = btn("SCAN ZIP PROJECT", null).apply { setOnClickListener { selectedUri?.let { scanZip(it) } } }
        previewButton = btn("HTML WEBSITE PREVIEW", intArrayOf(Color.parseColor("#10B981"), CYAN)).apply {
            setOnClickListener { htmlFile?.let { showPreview(it) } }
        }
        setBtn(scanButton, selectedUri != null)
        previewButton.visibility = if (htmlFile != null) View.VISIBLE else View.GONE
        val main = card().apply {
            addView(tv("আপনার ZIP ফাইল পরীক্ষা করুন", 18f, TEXT, true))
            addView(tv("Android project বা HTML website আছে কি না দেখুন।", 13f, MUTED).apply { setPadding(0, dp(4), 0, dp(16)) })
            addView(pickButton, lp()); addView(scanButton, lp(10)); addView(previewButton, lp(10))
        }

        // status card
        dot = View(this).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(curColor) }
            layoutParams = LinearLayout.LayoutParams(dp(10), dp(10)).apply { marginEnd = dp(10) }
        }
        status = tv(curStatus, 15f, TEXT, true)
        val statusRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            addView(dot); addView(status)
        }
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            isIndeterminate = true; visibility = View.GONE
            indeterminateTintList = ColorStateList.valueOf(VIOLET)
        }
        details = tv(curDetails, 12.5f, MUTED).apply { typeface = Typeface.MONOSPACE; setLineSpacing(0f, 1.15f) }
        val statusCard = card().apply {
            addView(tv("RESULT", 11f, MUTED, true).apply { letterSpacing = 0.15f; setPadding(0, 0, 0, dp(10)) })
            addView(statusRow)
            addView(progress, lp(10, -1, dp(6)))
            addView(details, lp(12))
        }

        // note card
        val note = card(Color.parseColor("#55FBBF24")).apply {
            addView(tv("ⓘ  গুরুত্বপূর্ণ নোট", 13f, AMBER, true))
            addView(tv("ZIP কোনো APK ফাইল নয়। APK বানাতে উপযুক্ত Android source project ও Android SDK/Gradle build system প্রয়োজন।", 12.5f, MUTED).apply { setPadding(0, dp(6), 0, 0) })
        }

        content.addView(top); content.addView(badge); content.addView(title, lp(14)); content.addView(sub, lp(6))
        content.addView(chips, lp(18)); content.addView(main, lp(22)); content.addView(statusCard, lp(14)); content.addView(note, lp(14))
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, -1))
        setContentView(root)
    }

    private fun pickZip() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/zip"
        }
        @Suppress("DEPRECATION")
        startActivityForResult(intent, 100)
    }

    @Deprecated("Legacy API used for compatibility with older Android versions")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == RESULT_OK) {
            selectedUri = data?.data
            htmlFile = null
            setBtn(scanButton, selectedUri != null)
            previewButton.visibility = View.GONE
            setStatus("ZIP SELECTED ✓", VIOLET, selectedUri?.lastPathSegment ?: "ফাইল প্রস্তুত")
        }
    }

    private fun scanZip(uri: Uri) {
        setBtn(scanButton, false)
        progress.visibility = View.VISIBLE
        setStatus("SCANNING…", AMBER)
        Thread {
            try {
                val out = File(cacheDir, "project_extract").apply {
                    deleteRecursively()
                    mkdirs()
                }
                val names = mutableListOf<String>()
                var totalBytes = 0L
                var entryCount = 0
                ZipInputStream(contentResolver.openInputStream(uri) ?: error("ZIP খোলা যায়নি")).use { zip ->
                    var entry = zip.nextEntry
                    while (entry != null) {
                        entryCount++
                        require(entryCount <= 3000) { "ZIP-এ অতিরিক্ত ফাইল রয়েছে (সীমা ৩০০০)।" }
                        val normalized = entry.name.replace('\\', '/')
                        require(!normalized.startsWith("/") && !normalized.split('/').contains("..")) {
                            "নিরাপত্তার কারণে ZIP path প্রত্যাখ্যান করা হয়েছে।"
                        }
                        val target = File(out, normalized).canonicalFile
                        require(target.path.startsWith(out.canonicalPath + File.separator) || target == out)
                        if (names.size < 3000) names.add(normalized)
                        if (entry.isDirectory) {
                            target.mkdirs()
                        } else {
                            target.parentFile?.mkdirs()
                            FileOutputStream(target).use { dest ->
                                val buffer = ByteArray(8192)
                                while (true) {
                                    val n = zip.read(buffer)
                                    if (n < 0) break
                                    totalBytes += n
                                    require(totalBytes <= 100L * 1024L * 1024L) {
                                        "নিরাপত্তার জন্য ZIP extraction ১০০ MB-এ সীমাবদ্ধ।"
                                    }
                                    dest.write(buffer, 0, n)
                                }
                            }
                        }
                        zip.closeEntry()
                        entry = zip.nextEntry
                    }
                }
                val gradle = names.any {
                    it.endsWith("settings.gradle") || it.endsWith("settings.gradle.kts")
                } || names.any { it.endsWith("build.gradle") || it.endsWith("build.gradle.kts") }
                val htmlCandidates = names.filter {
                    it.substringAfterLast('/').equals("index.html", true)
                }
                val existingApk = names.filter { it.endsWith(".apk", true) }
                val chosenHtml = htmlCandidates.firstOrNull()?.let { File(out, it) }
                extractedDir = out
                htmlFile = chosenHtml
                val report = buildString {
                    append("ফাইল: $entryCount\nExtracted size: ${totalBytes / 1024} KB\n")
                    append("Android Gradle project: ${if (gradle) "YES" else "NO"}\n")
                    append("HTML index.html: ${if (chosenHtml != null) "YES" else "NO"}\n")
                    append("ZIP-এর ভেতরে APK: ${if (existingApk.isNotEmpty()) "YES" else "NO"}\n\n")
                    append("ফাইল তালিকা (সর্বোচ্চ ৪০টি):\n")
                    names.take(40).forEach { append("• $it\n") }
                    append("\n")
                    when {
                        existingApk.isNotEmpty() -> append("ZIP-এ আগে থেকেই APK আছে। সেটি আলাদা করে extract করা হয়নি।")
                        gradle -> append("Android project শনাক্ত হয়েছে। APK build করতে Android Studio, Android SDK ও Gradle দরকার।")
                        chosenHtml != null -> append("HTML website পাওয়া গেছে। নিচের Preview বাটনে অফলাইনে দেখতে পারবেন। এটিকে APK করতে WebView wrapper project build করতে হবে।")
                        else -> append("সমর্থিত Android/HTML project পাওয়া যায়নি। ZIP-এর সব ধরনের ফাইল APK করা সম্ভব নয়।")
                    }
                }
                runOnUiThread {
                    val (label, color) = when {
                        gradle -> "ANDROID PROJECT FOUND" to GREEN
                        chosenHtml != null -> "HTML PROJECT FOUND" to CYAN
                        existingApk.isNotEmpty() -> "APK FOUND IN ZIP" to GREEN
                        else -> "SCAN COMPLETE" to AMBER
                    }
                    progress.visibility = View.GONE
                    setStatus(label, color, report)
                    previewButton.visibility = if (chosenHtml != null) View.VISIBLE else View.GONE
                    setBtn(scanButton, true)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    progress.visibility = View.GONE
                    setStatus("SCAN FAILED", RED, e.message ?: "অজানা সমস্যা")
                    setBtn(scanButton, true)
                }
            }
        }.start()
    }

    // ---- preview screen
    private fun showPreview(file: File) {
        inPreview = true
        val web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = false
            webChromeClient = WebChromeClient()
            webViewClient = WebViewClient()
            loadUrl(Uri.fromFile(file).toString())
        }
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(BG1) }
        withInsets(layout)
        val back = tv("‹  Back", 14f, Color.WHITE, true, Gravity.CENTER).apply {
            background = RippleDrawable(ColorStateList.valueOf(Color.parseColor("#33FFFFFF")), shape(0, 14, 0, intArrayOf(VIOLET, CYAN)), null)
            setPadding(dp(16), dp(9), dp(16), dp(9)); setOnClickListener { buildHome() }
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10)); setBackgroundColor(BG2)
            addView(back)
            addView(tv("Offline HTML Preview", 15f, TEXT, true).apply { setPadding(dp(14), 0, 0, 0) })
        }
        layout.addView(bar, LinearLayout.LayoutParams(-1, -2))
        layout.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(layout)
    }
}
