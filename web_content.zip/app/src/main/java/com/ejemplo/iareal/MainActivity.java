package com.ejemplo.iareal;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends Activity {
    private WebView web;
    private SharedPreferences prefs;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("nova_settings", MODE_PRIVATE);
        web = new WebView(this);
        web.setBackgroundColor(0xFF080D1B);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.addJavascriptInterface(new AIBridge(), "AndroidAI");
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    private class AIBridge {
        @JavascriptInterface public void saveApiKey(String key) {
            prefs.edit().putString("api_key", key).apply();
        }

        @JavascriptInterface public void askAI(String historyJson) {
            new Thread(() -> {
                String result;
                try {
                    String key = prefs.getString("api_key", "");
                    if (key.isEmpty()) throw new Exception("Primero tocá «Configurar conexión» e ingresá tu clave API.");
                    JSONArray messages = new JSONArray(historyJson);
                    JSONObject body = new JSONObject();
                    body.put("model", "openrouter/free");
                    body.put("messages", messages);
                    body.put("max_tokens", 700);
                    URL url = new URL("https://openrouter.ai/api/v1/chat/completions");
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("POST");
                    conn.setConnectTimeout(20000);
                    conn.setReadTimeout(45000);
                    conn.setDoOutput(true);
                    conn.setRequestProperty("Authorization", "Bearer " + key);
                    conn.setRequestProperty("Content-Type", "application/json");
                    conn.setRequestProperty("HTTP-Referer", "https://openrouter.ai/");
                    conn.setRequestProperty("X-Title", "Nova AI Android");
                    try (OutputStream os = conn.getOutputStream()) {
                        os.write(body.toString().getBytes("UTF-8"));
                    }
                    int code = conn.getResponseCode();
                    InputStream stream = (code >= 200 && code < 300) ? conn.getInputStream() : conn.getErrorStream();
                    StringBuilder sb = new StringBuilder();
                    try (BufferedReader br = new BufferedReader(new InputStreamReader(stream, "UTF-8"))) {
                        String line;
                        while ((line = br.readLine()) != null) sb.append(line);
                    }
                    if (code < 200 || code >= 300) {
                        String detail = "Error HTTP " + code;
                        try { detail = new JSONObject(sb.toString()).optJSONObject("error").optString("message", detail); } catch (Exception ignored) {}
                        throw new Exception(detail);
                    }
                    JSONObject response = new JSONObject(sb.toString());
                    String answer = response.getJSONArray("choices").getJSONObject(0).getJSONObject("message").optString("content", "");
                    JSONObject out = new JSONObject();
                    out.put("text", answer);
                    result = out.toString();
                    conn.disconnect();
                } catch (Exception e) {
                    try { JSONObject err = new JSONObject(); err.put("error", e.getMessage() == null ? "Error de conexión." : e.getMessage()); result = err.toString(); }
                    catch (Exception ignored) { result = "{\"error\":\"Error de conexión.\"}"; }
                }
                final String jsArg = JSONObject.quote(result);
                runOnUiThread(() -> web.evaluateJavascript("window.onAIResponse(" + jsArg + ")", null));
            }).start();
        }
    }
}