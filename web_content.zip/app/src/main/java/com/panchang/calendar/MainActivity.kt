package com.panchang.calendar

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.MotionEvent
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.LinearLayout
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback

class MainActivity : Activity() {

    private lateinit var web: WebView
    private lateinit var bannerHolder: FrameLayout
    private var interstitial: InterstitialAd? = null

    // Zoom wala interstitial: sirf PEHLE zoom par, ek baar. Dikhne ke baad is app-session me dobara kabhi nahi.
    private var zoomAdDone = false
    private var zoomPending = false
    private var touching = false
    private val ui = Handler(Looper.getMainLooper())

    @SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        web = WebView(this)
        bannerHolder = FrameLayout(this)
        root.addView(web, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(bannerHolder, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(root)

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            useWideViewPort = true
        }
        // ungli screen par hai ya nahi (ad tabhi dikhayein jab pinch khatam ho jaye)
        web.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> touching = true
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> touching = false
            }
            false
        }
        web.addJavascriptInterface(object {
            @JavascriptInterface
            fun onZoom() { ui.post { requestZoomAd() } }
        }, "AndroidAds")
        web.webViewClient = WebViewClient()
        web.loadUrl("file:///android_asset/index.html")

        MobileAds.initialize(this) {}
        loadBanner()
        loadInterstitial()
    }

    // ---- Banner: har samay neeche chalta hai ----
    private fun loadBanner() {
        val dm = resources.displayMetrics
        val widthDp = (dm.widthPixels / dm.density).toInt()
        val ad = AdView(this)
        ad.adUnitId = BuildConfig.BANNER_ID
        ad.setAdSize(AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(this, widthDp))
        bannerHolder.addView(ad)
        ad.loadAd(AdRequest.Builder().build())
    }

    // ---- Interstitial: pehle se load karke rakhte hain ----
    private fun loadInterstitial() {
        InterstitialAd.load(this, BuildConfig.INTERSTITIAL_ID, AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) { interstitial = ad }
                override fun onAdFailedToLoad(error: LoadAdError) { interstitial = null }
            })
    }

    private fun requestZoomAd() {
        if (zoomAdDone || zoomPending) return
        zoomPending = true
        ui.postDelayed({ tryShowZoomAd() }, 1500)   // pinch khatam hone ka intezaar
    }

    private fun tryShowZoomAd() {
        if (zoomAdDone) { zoomPending = false; return }
        if (touching) { ui.postDelayed({ tryShowZoomAd() }, 500); return }   // ungli abhi screen par hai
        val ad = interstitial
        zoomPending = false
        if (ad == null) return          // abhi load nahi hua: agle zoom par dobara koshish
        zoomAdDone = true               // yahin lock: ab is session me zoom ad dobara nahi
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() { interstitial = null }
        }
        ad.show(this)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        web.evaluateJavascript("document.getElementById('back').style.display!=='none'") { r ->
            if (r == "true") web.evaluateJavascript("home()", null) else finish()
        }
    }

    override fun onDestroy() {
        web.destroy()
        super.onDestroy()
    }
}
