package com.phantom.tools // ganti sesuai package kamu

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.os.Bundle
import android.webkit.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private val PERM_REQ = 100

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        webView = WebView(this)
        setContentView(webView)

        // Setup WebView
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            mediaPlaybackRequiresUserGesture = false // Biar video autoplay
            geolocationEnabled = true
        }

        // Daftarkan Bridge buat IR Remote
        webView.addJavascriptInterface(IrBridge(this), "PhantomNative")

        // Handle Izin GPS dari WebView
        webView.webChromeClient = object : WebChromeClient() {
            override fun onGeolocationPermissionsShowPrompt(
                origin: String?,
                callback: GeolocationPermissions.Callback?
            ) {
                // Cek izin lokasi, kalau belum minta
                if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.ACCESS_FINE_LOCATION) 
                    == PackageManager.PERMISSION_GRANTED) {
                    callback?.invoke(origin, true, false)
                } else {
                    ActivityCompat.requestPermissions(
                        this@MainActivity,
                        arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                        PERM_REQ
                    )
                    callback?.invoke(origin, true, false) // Tetap izinkan prompt JS
                }
            }

            // Handle Izin Kamera (buat Senter)
            override fun onPermissionRequest(request: PermissionRequest?) {
                request?.grant(request.resources)
            }
        }

        // Load file HTML dari folder assets
        webView.loadUrl("file:///android_asset/index.html")
    }

    // Minta izin pas aplikasi pertama kali dibuka
    private fun requestAppPermissions() {
        val perms = arrayOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.CAMERA
        )
        ActivityCompat.requestPermissions(this, perms, PERM_REQ)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERM_REQ) {
            // Reload web kalau izin baru dikasih
            webView.reload()
        }
    }

    // Panggil request izin di awal
    init {
        // Sebenarnya onCreate lebih tepat, tapi ini trigger awal
    }
    
    override fun onResume() {
        super.onResume()
        // Minta izin pas resume kalau belum ada
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) 
            != PackageManager.PERMISSION_GRANTED) {
            requestAppPermissions()
        }
    }
}