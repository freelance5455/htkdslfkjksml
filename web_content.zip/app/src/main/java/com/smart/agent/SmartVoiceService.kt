package com.smart.agent

import android.app.*
import android.content.*
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.*
import android.provider.Settings
import android.speech.*
import android.view.*
import android.widget.*
import android.speech.tts.TextToSpeech
import java.util.Locale

class SmartVoiceService : Service(), RecognitionListener, TextToSpeech.OnInitListener {
    companion object {
        const val PREFS = "smart_voice_state"
        const val PREF_ACTIVE = "active"
        const val ACTION_RESPONSE = "com.smart.agent.VOICE_RESPONSE"
        const val EXTRA_RESPONSE = "response"
        const val ACTION_STATE = "com.smart.agent.VOICE_STATE"
        const val EXTRA_ACTIVE = "active"
        private const val CHANNEL_ID = "smart_voice"
        private const val NOTIFICATION_ID = 7101
    }

    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var listening = false
    private var restarting = false
    private var bubble: View? = null
    private var wm: WindowManager? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        tts = TextToSpeech(this, this)
        startForeground(NOTIFICATION_ID, notification(), if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else 0)
        if (Settings.canDrawOverlays(this)) showBubble()
        setupRecognizer()
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(PREF_ACTIVE, true).apply()
        broadcastState(true)
        startListeningSoon()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") {
            stopSelf()
            return START_NOT_STICKY
        }
        if (intent?.action == "LISTEN_NOW") startListeningSoon()
        if (bubble == null && Settings.canDrawOverlays(this)) showBubble()
        return START_STICKY
    }

    private fun setupRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            speak("Voice recognition is not available on this phone.")
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(this)
    }

    private fun startListeningSoon() {
        if (restarting) return
        restarting = true
        Handler(Looper.getMainLooper()).postDelayed({
            restarting = false
            startListening()
        }, 450)
    }

    private fun startListening() {
        val r = recognizer ?: return
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        try {
            listening = true
            r.startListening(intent)
            updateNotification("Listening for “Hey Smart”")
        } catch (_: Exception) {
            listening = false
            startListeningSoon()
        }
    }

    private fun stopListening() {
        try { recognizer?.stopListening() } catch (_: Exception) {}
        listening = false
    }

    private fun commandFromSpeech(spoken: String): String? {
        val normalized = spoken.trim().replace(Regex("\\s+"), " ")
        val lower = normalized.lowercase(Locale.getDefault())
        val keys = listOf("hey smart", "hey, smart", "smart")
        val key = keys.firstOrNull { lower.contains(it) } ?: return null
        val index = lower.indexOf(key)
        var command = normalized.substring(index + key.length).trim(' ', ',', '.', ':', ';')
        if (command.isBlank()) {
            speak("Yes, I'm listening.")
            return null
        }
        return command
    }

    private fun execute(spoken: String) {
        val command = commandFromSpeech(spoken) ?: return
        sendResponse("I heard: $command")
        SmartCommandEngine(this) { response ->
            sendResponse(response)
            speak(response)
        }.run(command)
    }

    private fun sendResponse(value: String) {
        sendBroadcast(Intent(ACTION_RESPONSE).setPackage(packageName).putExtra(EXTRA_RESPONSE, value))
    }

    private fun speak(value: String) {
        if (value.isBlank()) return
        tts?.speak(value, TextToSpeech.QUEUE_FLUSH, null, "smart_${System.currentTimeMillis()}")
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL_ID, "Smart Voice", NotificationManager.IMPORTANCE_LOW)
            channel.description = "Smart background voice assistant"
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun notification(): Notification {
        val launch = PendingIntent.getActivity(this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 2, Intent(this, SmartVoiceService::class.java).setAction("STOP"), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Smart Voice is active")
            .setContentText("Say “Hey Smart” while you use other apps")
            .setContentIntent(launch)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(android.graphics.drawable.Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Stop", stop).build())
            .build()
    }

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, notification().let { n ->
            Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("Smart Voice is active")
                .setContentText(text)
                .setOngoing(true)
                .setContentIntent(PendingIntent.getActivity(this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
                .build()
        })
    }

    private fun showBubble() {
        if (bubble != null || !Settings.canDrawOverlays(this)) return
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val tv = TextView(this).apply {
            text = "S"
            textSize = 20f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setBackgroundColor(Color.rgb(103, 92, 255))
            elevation = 12f
            setOnClickListener {
                try {
                    startActivity(Intent(this@SmartVoiceService, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    startListeningSoon()
                } catch (_: Exception) {}
            }
            setOnLongClickListener {
                stopSelf()
                true
            }
        }
        bubble = tv
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val p = WindowManager.LayoutParams(62, 62, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT)
        p.gravity = Gravity.END or Gravity.CENTER_VERTICAL
        p.x = 12
        p.y = 0
        try { wm?.addView(tv, p) } catch (_: Exception) { bubble = null }
    }

    private fun removeBubble() {
        try { bubble?.let { wm?.removeView(it) } } catch (_: Exception) {}
        bubble = null
    }

    private fun broadcastState(active: Boolean) {
        sendBroadcast(Intent(ACTION_STATE).setPackage(packageName).putExtra(EXTRA_ACTIVE, active))
    }

    override fun onDestroy() {
        stopListening()
        recognizer?.destroy()
        recognizer = null
        tts?.stop()
        tts?.shutdown()
        tts = null
        removeBubble()
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(PREF_ACTIVE, false).apply()
        broadcastState(false)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null
    override fun onInit(status: Int) { if (status == TextToSpeech.SUCCESS) tts?.language = Locale.getDefault() }

    override fun onReadyForSpeech(params: Bundle?) {}
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(rmsdB: Float) {}
    override fun onBufferReceived(buffer: ByteArray?) {}
    override fun onEndOfSpeech() { startListeningSoon() }
    override fun onError(error: Int) { listening = false; startListeningSoon() }
    override fun onResults(results: Bundle?) {
        val texts = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
        texts.firstOrNull()?.let { execute(it) }
        startListeningSoon()
    }
    override fun onPartialResults(partialResults: Bundle?) {
        val text = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: return
        if (text.lowercase(Locale.getDefault()).contains("hey smart")) {
            // Wait for final results so Smart does not execute a half-spoken command.
        }
    }
    override fun onEvent(eventType: Int, params: Bundle?) {}
}
