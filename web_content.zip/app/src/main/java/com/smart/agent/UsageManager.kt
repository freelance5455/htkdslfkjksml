package com.smart.agent
import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
class UsageManager(c: Context){
 companion object{const val LIMIT=10}
 private val p=c.getSharedPreferences("smart_usage",0)
 private fun day()=SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date())
 private fun reset(){if(p.getString("day",null)!=day())p.edit().putString("day",day()).putInt("count",0).apply()}
 fun remaining():Int{reset();return (LIMIT-p.getInt("count",0)).coerceAtLeast(0)}
 fun consume(){reset();p.edit().putInt("count",p.getInt("count",0)+1).apply()}
}