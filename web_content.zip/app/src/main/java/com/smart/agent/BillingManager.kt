package com.smart.agent

import android.app.Activity
import android.content.Context
import com.android.billingclient.api.*

class BillingManager(
    context: Context,
    private val onStatus: (String) -> Unit
) {
    companion object {
        const val MONTHLY_ID = "smart_pro_monthly"
        const val YEARLY_ID = "smart_pro_yearly"
    }

    private val client = BillingClient.newBuilder(context)
        .setListener { result, purchases ->
            if (result.responseCode == BillingClient.BillingResponseCode.OK && purchases != null) {
                purchases.forEach { purchase ->
                    if (purchase.purchaseState == Purchase.PurchaseState.PURCHASED) {
                        acknowledge(purchase)
                        onStatus("Purchase received. Smart must confirm your Pro entitlement with the secure server.")
                    }
                }
            } else if (result.responseCode != BillingClient.BillingResponseCode.USER_CANCELED) {
                onStatus("Billing error: ${result.debugMessage}")
            }
        }
        .enablePendingPurchases(
            PendingPurchasesParams.newBuilder()
                .enableOneTimeProducts()
                .build()
        )
        .enableAutoServiceReconnection()
        .build()

    private var products: Map<String, ProductDetails> = emptyMap()

    fun connect() {
        client.startConnection(object : BillingClientStateListener {
            override fun onBillingSetupFinished(result: BillingResult) {
                if (result.responseCode == BillingClient.BillingResponseCode.OK) {
                    queryProducts()
                } else {
                    onStatus("Google Play Billing is unavailable: ${result.debugMessage}")
                }
            }

            override fun onBillingServiceDisconnected() {
                onStatus("Google Play Billing disconnected. Please try again.")
            }
        })
    }

    private fun queryProducts() {
        val params = QueryProductDetailsParams.newBuilder()
            .setProductList(
                listOf(MONTHLY_ID, YEARLY_ID).map {
                    QueryProductDetailsParams.Product.newBuilder()
                        .setProductId(it)
                        .setProductType(BillingClient.ProductType.SUBS)
                        .build()
                }
            )
            .build()

        client.queryProductDetailsAsync(params) { result, detailsResult ->
            if (result.responseCode == BillingClient.BillingResponseCode.OK) {
                products = detailsResult.productDetailsList.associateBy { it.productId }
                if (products.isEmpty()) {
                    onStatus("No Pro plans are configured in Google Play Console yet.")
                } else {
                    onStatus("Pro plans loaded.")
                }
            } else {
                onStatus("Unable to load Pro plans: ${result.debugMessage}")
            }
        }
    }

    fun buy(activity: Activity, productId: String) {
        val details = products[productId]
        if (details == null) {
            onStatus("That Pro plan is not available yet. Configure it in Play Console first.")
            return
        }

        val offer = details.subscriptionOfferDetails?.firstOrNull()
        if (offer == null) {
            onStatus("No subscription offer is configured for this plan.")
            return
        }

        val productParams = BillingFlowParams.ProductDetailsParams.newBuilder()
            .setProductDetails(details)
            .setOfferToken(offer.offerToken)
            .build()

        val flow = BillingFlowParams.newBuilder()
            .setProductDetailsParamsList(listOf(productParams))
            .build()

        client.launchBillingFlow(activity, flow)
    }

    private fun acknowledge(purchase: Purchase) {
        if (!purchase.isAcknowledged) {
            client.acknowledgePurchase(
                AcknowledgePurchaseParams.newBuilder()
                    .setPurchaseToken(purchase.purchaseToken)
                    .build()
            ) { result ->
                if (result.responseCode != BillingClient.BillingResponseCode.OK) {
                    onStatus("Purchase acknowledgement failed: ${result.debugMessage}")
                }
            }
        }
    }

    fun close() {
        client.endConnection()
    }
}
