package com.smart.agent
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

object SmartNotifications {
    val items=mutableListOf<String>()
}

class SmartNotificationListener: NotificationListenerService(){
    override fun onNotificationPosted(s:StatusBarNotification){
        synchronized(SmartNotifications.items){
            SmartNotifications.items.add(
                0,
                s.notification.extras.getString("android.title").orEmpty() +
                ": " +
                s.notification.extras.getCharSequence("android.text").orEmpty()
            )
            if(SmartNotifications.items.size>50) SmartNotifications.items.removeLast()
        }
    }
}
