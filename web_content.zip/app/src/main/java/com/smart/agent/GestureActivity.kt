package com.smart.agent
import android.app.Activity
import android.os.Bundle
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.widget.TextView
import android.accessibilityservice.AccessibilityService

class GestureActivity:Activity(),SensorEventListener{
    private var sm:SensorManager?=null
    private var last=0L

    override fun onCreate(b:Bundle?){
        super.onCreate(b)
        setContentView(TextView(this).apply{
            text="Smart Gesture Mode\nMove your phone left/right to navigate.\nCamera hand recognition is a future ML module."
            textSize=18f
            setPadding(30,50,30,30)
        })
        sm=getSystemService(SENSOR_SERVICE) as SensorManager
    }
    override fun onResume(){super.onResume();sm?.registerListener(this,sm?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER),SensorManager.SENSOR_DELAY_UI)}
    override fun onPause(){sm?.unregisterListener(this);super.onPause()}
    override fun onSensorChanged(e:SensorEvent){
        if(System.currentTimeMillis()-last<700)return
        val x=e.values[0]
        if(kotlin.math.abs(x)>7){
            last=System.currentTimeMillis()
            if(x>0) SmartAccessibilityService.instance?.global(AccessibilityService.GLOBAL_ACTION_BACK)
            else SmartAccessibilityService.instance?.global(AccessibilityService.GLOBAL_ACTION_RECENTS)
        }
    }
    override fun onAccuracyChanged(s:Sensor?,a:Int){}
}
