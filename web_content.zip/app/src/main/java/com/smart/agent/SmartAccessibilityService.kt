package com.smart.agent

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityService.TakeScreenshotCallback
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Path
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.Executors

class SmartAccessibilityService : AccessibilityService() {
    companion object { var instance: SmartAccessibilityService? = null }
    private val screenshotExecutor = Executors.newSingleThreadExecutor()

    override fun onServiceConnected(){ instance=this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy(){ instance=null; screenshotExecutor.shutdownNow(); super.onDestroy() }

    fun global(action:Int)=performGlobalAction(action)

    fun tap(x:Float,y:Float){
        val p=Path(); p.moveTo(x,y)
        val g=GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p,0,50)).build()
        dispatchGesture(g,null,null)
    }

    fun scroll(down:Boolean){
        val dm = resources.displayMetrics
        val x=dm.widthPixels/2f
        val top=dm.heightPixels*0.28f
        val bottom=dm.heightPixels*0.78f
        val p=Path()
        if(down){p.moveTo(x,bottom);p.lineTo(x,top)} else {p.moveTo(x,top);p.lineTo(x,bottom)}
        val g=GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p,0,450)).build()
        dispatchGesture(g,null,null)
    }

    fun findText(text:String):AccessibilityNodeInfo? {
        fun walk(n:AccessibilityNodeInfo?):AccessibilityNodeInfo?{
            if(n==null)return null
            if(n.text?.toString()?.contains(text,true)==true || n.contentDescription?.toString()?.contains(text,true)==true)return n
            for(i in 0 until n.childCount){ val r=walk(n.getChild(i)); if(r!=null)return r }
            return null
        }
        return walk(rootInActiveWindow)
    }

    fun takeScreenshotToGallery(callback: (String) -> Unit) {
        if (Build.VERSION.SDK_INT < 30) { callback("Screenshot needs Android 11 or newer."); return }
        takeScreenshot(Display.DEFAULT_DISPLAY, screenshotExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(result: AccessibilityService.ScreenshotResult) {
                val bitmap = Bitmap.wrapHardwareBuffer(result.hardwareBuffer, result.colorSpace)
                result.hardwareBuffer.close()
                if (bitmap == null) { callback("Android could not capture the screen."); return }
                val name = "Smart_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.png"
                val values = android.content.ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, name)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                    put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/Smart")
                    put(MediaStore.Images.Media.IS_PENDING, 1)
                }
                val resolver = contentResolver
                val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                if (uri == null) { callback("I could not save the screenshot."); return }
                try {
                    resolver.openOutputStream(uri).use { out: OutputStream? -> bitmap.compress(Bitmap.CompressFormat.PNG, 100, out) }
                    values.clear(); values.put(MediaStore.Images.Media.IS_PENDING, 0); resolver.update(uri, values, null, null)
                    callback("Screenshot saved to Pictures/Smart.")
                } catch (_: Exception) {
                    resolver.delete(uri, null, null)
                    callback("I could not save the screenshot.")
                } finally { bitmap.recycle() }
            }
            override fun onFailure(errorCode: Int) { callback("Android could not take the screenshot. Please keep Smart Accessibility enabled.") }
        })
    }
}
