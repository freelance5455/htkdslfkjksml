package com.smart.agent
import android.content.Context
class EntitlementManager(c:Context){
 private val p=c.getSharedPreferences("smart_entitlement",0)
 fun isPro()=p.getBoolean("pro_verified",false)
 fun setVerifiedPro(v:Boolean){p.edit().putBoolean("pro_verified",v).apply()}
}