package com.vsmusicalstudio.liveloops;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.*;
import android.content.Intent;
import android.net.Uri;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import java.io.*;
import java.util.*;

public class MainActivity extends Activity {
    private WebView webView;
    private static final int AUDIO_PICKER_REQUEST = 2001;
    private File loopDir;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        loopDir = new File(getFilesDir(), "loops");
        if (!loopDir.exists()) loopDir.mkdirs();

        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        if (android.os.Build.VERSION.SDK_INT >= 16) {
            s.setAllowFileAccessFromFileURLs(true);
            s.setAllowUniversalAccessFromFileURLs(true);
        }
        webView.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, String url) {
                return serveLoop(url);
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, android.webkit.WebResourceRequest req) {
                return serveLoop(req.getUrl().toString());
            }
        });
        webView.addJavascriptInterface(new AndroidAudioBridge(), "AndroidAudio");
        webView.loadUrl("file:///android_asset/index.html");
    }

    private WebResourceResponse serveLoop(String url) {
        try {
            if (!url.startsWith("https://loops.local/")) return null;
            String name = Uri.parse(url).getPath();
            if (name == null) return null;
            name = name.replaceFirst("^/", "");
            if (name.contains("/") || name.contains("\\") || name.contains("..")) return null;
            File f = new File(loopDir, name);
            if (!f.isFile()) return null;
            String mime = guessMime(name);
            WebResourceResponse r = new WebResourceResponse(mime, "binary", new FileInputStream(f));
            if (android.os.Build.VERSION.SDK_INT >= 21) {
                Map<String,String> headers = new HashMap<>();
                headers.put("Access-Control-Allow-Origin", "*");
                headers.put("Cache-Control", "no-store");
                r.setResponseHeaders(headers);
            }
            return r;
        } catch (Exception e) { return null; }
    }

    private String guessMime(String name) {
        String n=name.toLowerCase(Locale.US);
        if(n.endsWith(".wav")) return "audio/wav";
        if(n.endsWith(".m4a")) return "audio/mp4";
        if(n.endsWith(".aac")) return "audio/aac";
        if(n.endsWith(".ogg") || n.endsWith(".opus")) return "audio/ogg";
        if(n.endsWith(".flac")) return "audio/flac";
        if(n.endsWith(".aiff") || n.endsWith(".aif")) return "audio/aiff";
        return "audio/mpeg";
    }

    private class AndroidAudioBridge {
        @JavascriptInterface public void openAudioPicker() {
            runOnUiThread(() -> {
                try {
                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("audio/*");
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                    startActivityForResult(intent, AUDIO_PICKER_REQUEST);
                } catch (Exception e) {
                    webView.evaluateJavascript("window.nativePickerError('Audio picker नहीं खुला');", null);
                }
            });
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != AUDIO_PICKER_REQUEST) return;
        if (resultCode != RESULT_OK || data == null || data.getData() == null) {
            webView.evaluateJavascript("window.nativePickerCancelled();", null);
            return;
        }
        Uri uri = data.getData();
        try {
            if (android.os.Build.VERSION.SDK_INT >= 19 && (data.getFlags() & Intent.FLAG_GRANT_READ_URI_PERMISSION) != 0) {
                try { getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) {}
            }
            String name = getDisplayName(uri);
            String ext = "";
            int dot=name.lastIndexOf('.');
            if(dot>=0) ext=name.substring(dot).replaceAll("[^A-Za-z0-9.]", "");
            if(ext.length()>8) ext="";
            String stored = "loop_" + System.currentTimeMillis() + "_" + UUID.randomUUID().toString().replace("-", "") + ext;
            File out = new File(loopDir, stored);
            try (InputStream in = getContentResolver().openInputStream(uri); OutputStream os = new FileOutputStream(out)) {
                if (in == null) throw new IOException("Cannot open audio");
                byte[] buf = new byte[64 * 1024]; int len;
                while ((len = in.read(buf)) != -1) os.write(buf, 0, len);
            }
            String fileUrl = "https://loops.local/" + stored;
            String js = "window.nativeAudioSelected(" + quote(fileUrl) + "," + quote(name) + ");";
            webView.evaluateJavascript(js, null);
        } catch (Exception e) {
            webView.evaluateJavascript("window.nativePickerError('Audio file पढ़ी नहीं जा सकी');", null);
        }
    }

    private String getDisplayName(Uri uri) {
        android.database.Cursor c = getContentResolver().query(uri, new String[]{"_display_name"}, null, null, null);
        if (c != null) {
            try { if (c.moveToFirst()) return c.getString(0); } finally { c.close(); }
        }
        String p = uri.getLastPathSegment();
        return p == null ? "audio" : p;
    }

    private String quote(String s) {
        return "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "\\r") + "\"";
    }

    @Override public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
