package com.prahaar.neet

import android.app.Activity
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.JavascriptInterface
import android.content.Intent
import android.net.Uri
import android.graphics.Bitmap
import android.graphics.Matrix
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.google.android.gms.tasks.Tasks
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private val pickerRequest = 101
    private val worker = Executors.newSingleThreadExecutor()
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = true
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(PrahaarBridge(), "PrahaarNative")
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
    }

    inner class PrahaarBridge {
        @JavascriptInterface
        fun pickSource() {
            runOnUiThread {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                    putExtra(Intent.EXTRA_MIME_TYPES, arrayOf(
                        "application/pdf", "image/jpeg", "image/png", "image/webp", "image/heic"
                    ))
                }
                startActivityForResult(intent, pickerRequest)
            }
        }
        @JavascriptInterface
        fun platformName(): String = "Android"
    }

    @Deprecated("Deprecated in Android SDK")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != pickerRequest || resultCode != RESULT_OK || data?.data == null) return
        val uri = data.data!!
        contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        val name = displayName(uri)
        webView.evaluateJavascript("window.prahaarImportStarted(${JSONObject.quote(name)})", null)
        worker.execute {
            try {
                val extracted = if (name.lowercase().endsWith(".pdf") || contentResolver.getType(uri) == "application/pdf") {
                    extractPdfWithOcr(uri)
                } else {
                    extractImageWithOcr(uri)
                }
                runOnUiThread {
                    webView.evaluateJavascript(
                        "window.prahaarImportFinished(${JSONObject.quote(name)}, ${JSONObject.quote(extracted)}, null)", null
                    )
                }
            } catch (e: Exception) {
                runOnUiThread {
                    webView.evaluateJavascript(
                        "window.prahaarImportFinished(${JSONObject.quote(name)}, '', ${JSONObject.quote(e.message ?: "Could not read file")})", null
                    )
                }
            }
        }
    }

    private fun displayName(uri: Uri): String {
        var name = "imported-file"
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) name = c.getString(0) ?: name
        }
        return name
    }

    private fun extractImageWithOcr(uri: Uri): String {
        val bitmap = contentResolver.openInputStream(uri).use { input ->
            android.graphics.BitmapFactory.decodeStream(input)
        } ?: throw IllegalArgumentException("Image could not be decoded.")
        return recognize(bitmap)
    }

    private fun extractPdfWithOcr(uri: Uri): String {
        val pfd = contentResolver.openFileDescriptor(uri, "r")
            ?: throw IllegalArgumentException("Could not open this PDF.")
        pfd.use { descriptor ->
            PdfRenderer(descriptor).use { renderer ->
                if (renderer.pageCount == 0) return ""
                if (renderer.pageCount > 80) throw IllegalArgumentException("This first version supports up to 80 PDF pages per import. Split the PDF and import it in parts.")
                val result = StringBuilder()
                for (i in 0 until renderer.pageCount) {
                    renderer.openPage(i).use { page ->
                        val scale = minOf(2.0f, 1800f / maxOf(page.width, page.height))
                        val width = (page.width * scale).toInt().coerceAtLeast(1)
                        val height = (page.height * scale).toInt().coerceAtLeast(1)
                        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                        bitmap.eraseColor(android.graphics.Color.WHITE)
                        page.render(bitmap, null, Matrix().apply { setScale(scale, scale) }, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        result.append("\n\n--- Page ").append(i + 1).append(" ---\n")
                        result.append(recognize(bitmap)).append("\n")
                        bitmap.recycle()
                    }
                }
                return result.toString()
            }
        }
    }

    private fun recognize(bitmap: Bitmap): String {
        val image = InputImage.fromBitmap(bitmap, 0)
        return try {
            recognizer.process(image).getResultText()
        } catch (e: Exception) {
            throw IllegalArgumentException("OCR failed: ${e.message ?: "unknown error"}")
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        worker.shutdown()
        if (::webView.isInitialized) webView.destroy()
    }
}
