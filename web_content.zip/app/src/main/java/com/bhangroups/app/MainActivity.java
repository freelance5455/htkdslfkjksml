package com.bhangroups.app;

import android.Manifest;
import android.app.Activity;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.wifi.p2p.*;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.*;
import android.webkit.*;
import android.widget.Toast;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class MainActivity extends Activity {
    private WebView webView;
    private WifiP2pManager manager;
    private WifiP2pManager.Channel channel;
    private BroadcastReceiver receiver;
    private boolean registered = false;
    private static final int REQ = 77;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private ServerSocket serverSocket;
    private Socket socket;
    private Thread ioThread;
    private final List<WifiP2pDevice> peers = new ArrayList<>();

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        webView = new WebView(this); setContentView(webView);
        WebSettings s=webView.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true); s.setAllowContentAccess(true);
        webView.setWebViewClient(new WebViewClient()); webView.addJavascriptInterface(new Bridge(),"Android");
        webView.loadUrl("file:///android_asset/index.html");
        setupP2P();
    }

    private void setupP2P() {
        manager=(WifiP2pManager)getSystemService(WIFI_P2P_SERVICE);
        if(manager==null){notifyJs("p2pStatus","Wi-Fi Direct is not supported on this phone");return;}
        channel=manager.initialize(this,getMainLooper(),()->notifyJs("p2pStatus","Wi-Fi Direct channel lost"));
        receiver=new P2PReceiver();
        if(Build.VERSION.SDK_INT>=33) requestPermissions(new String[]{Manifest.permission.NEARBY_WIFI_DEVICES},REQ);
        else requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION},REQ);
    }
    private boolean allowed(){
        if(Build.VERSION.SDK_INT>=33) return checkSelfPermission(Manifest.permission.NEARBY_WIFI_DEVICES)==PackageManager.PERMISSION_GRANTED;
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED;
    }
    private void registerP2P(){ if(registered)return; IntentFilter f=new IntentFilter();
        f.addAction(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION); f.addAction(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION);
        f.addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION); f.addAction(WifiP2pManager.WIFI_P2P_THIS_DEVICE_CHANGED_ACTION);
        registerReceiver(receiver,f); registered=true; }
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g); if(r==REQ&&allowed()){registerP2P();}else notifyJs("p2pStatus","Nearby-device permission is required");}

    private void discover(){
        if(!allowed()){notifyJs("p2pStatus","Allow Nearby devices permission first");return;}
        manager.discoverPeers(channel,new WifiP2pManager.ActionListener(){public void onSuccess(){notifyJs("p2pStatus","Searching for nearby ZYNKO devices…");}public void onFailure(int x){notifyJs("p2pStatus","Discovery failed: "+x);}});
    }
    private void connect(String address){
        if(!allowed())return;
        WifiP2pConfig c=new WifiP2pConfig(); c.deviceAddress=address; c.wps.setup=WpsInfo.PBC;
        manager.connect(channel,c,new WifiP2pManager.ActionListener(){public void onSuccess(){notifyJs("p2pStatus","Connecting…");}public void onFailure(int x){notifyJs("p2pStatus","Connect failed: "+x);}});
    }
    private void onPeers(WifiP2pDeviceList list){
        peers.clear(); peers.addAll(list.getDeviceList());
        StringBuilder j=new StringBuilder("[");
        for(int i=0;i<peers.size();i++){WifiP2pDevice d=peers.get(i); if(i>0)j.append(',');j.append("{\"name\":\"").append(js(d.deviceName)).append("\",\"address\":\"").append(js(d.deviceAddress)).append("\",\"status\":\"").append(js(status(d.status))).append("\"}");}j.append(']');
        notifyJs("p2pPeers",j.toString());
    }
    private String status(int s){switch(s){case WifiP2pDevice.CONNECTED:return "Connected";case WifiP2pDevice.INVITED:return "Invited";case WifiP2pDevice.FAILED:return "Failed";case WifiP2pDevice.AVAILABLE:return "Available";default:return "Unavailable";}}
    private String js(String s){return s==null?"":s.replace("\\","\\\\").replace("\"","\\\"").replace("\n"," ");}

    private void connectionChanged(NetworkInfoHolder n){
        if(n.connected){
            manager.requestConnectionInfo(channel, info->{
                if(info.groupFormed){ notifyJs("p2pStatus", info.isGroupOwner?"Connected — this phone is the group owner":"Connected to nearby phone");
                    if(info.isGroupOwner) startServer(); else if(info.groupOwnerAddress!=null) connectClient(info.groupOwnerAddress.getHostAddress());
                }
            });
        } else { closeSockets(); notifyJs("p2pStatus","Disconnected"); }
    }
    private static class NetworkInfoHolder { boolean connected; NetworkInfoHolder(boolean c){connected=c;} }

    private void startServer(){
        closeSockets(); ioThread=new Thread(()->{try{serverSocket=new ServerSocket(8988); socket=serverSocket.accept(); startReader(socket);}catch(Exception e){handler.post(()->notifyJs("p2pStatus","Waiting for nearby phone…"));}});ioThread.start(); notifyJs("p2pStatus","Connected. Waiting for another phone…");}
    private void connectClient(String host){
        closeSockets(); ioThread=new Thread(()->{try{socket=new Socket();socket.connect(new InetSocketAddress(host,8988),7000);startReader(socket);handler.post(()->notifyJs("p2pStatus","Connected to nearby phone"));}catch(Exception e){handler.post(()->notifyJs("p2pStatus","Could not open local connection"));}});ioThread.start();}
    private void startReader(Socket s){
        try{BufferedReader r=new BufferedReader(new InputStreamReader(s.getInputStream(),StandardCharsets.UTF_8));String line;while((line=r.readLine())!=null){String msg=line;handler.post(()->notifyJs("p2pMessage",msg));}}catch(Exception ignored){}
    }
    private void sendLocal(String text){new Thread(()->{try{if(socket==null||socket.isClosed())return;BufferedWriter w=new BufferedWriter(new OutputStreamWriter(socket.getOutputStream(),StandardCharsets.UTF_8));w.write(text.replace("\n"," "));w.newLine();w.flush();}catch(Exception ignored){}}).start();}
    private void closeSockets(){try{if(socket!=null)socket.close();}catch(Exception ignored){} try{if(serverSocket!=null)serverSocket.close();}catch(Exception ignored){} socket=null;serverSocket=null;}
    private void notifyJs(String fn,String arg){handler.post(()->{if(webView!=null)webView.evaluateJavascript("window."+fn+"("+toJson(arg)+")",null);});}
    private String toJson(String x){return "\""+js(x)+"\"";}

    private class P2PReceiver extends BroadcastReceiver{
        public void onReceive(Context c,Intent i){String a=i.getAction();
            if(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION.equals(a)){int state=i.getIntExtra(WifiP2pManager.EXTRA_WIFI_STATE,-1);notifyJs("p2pStatus",state==WifiP2pManager.WIFI_P2P_STATE_ENABLED?"Wi-Fi Direct ready":"Turn on Wi-Fi to use nearby connection");}
            else if(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION.equals(a)&&allowed()) manager.requestPeers(channel, list->onPeers(list));
            else if(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION.equals(a)){android.net.NetworkInfo ni=i.getParcelableExtra(WifiP2pManager.EXTRA_NETWORK_INFO);connectionChanged(new NetworkInfoHolder(ni!=null&&ni.isConnected()));}
        }
    }

    public class Bridge{
        @JavascriptInterface public void startNearby(){discover();}
        @JavascriptInterface public void connectNearby(String address){connect(address);}
        @JavascriptInterface public void sendNearby(String text){sendLocal(text);}
        @JavascriptInterface public void shareText(String text){Intent s=new Intent(Intent.ACTION_SEND);s.setType("text/plain");s.putExtra(Intent.EXTRA_TEXT,text);startActivity(Intent.createChooser(s,"Share with…"));}
        @JavascriptInterface public void openUrl(String url){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}catch(Exception e){Toast.makeText(MainActivity.this,"Unable to open link",Toast.LENGTH_SHORT).show();}}
    }
    @Override protected void onDestroy(){super.onDestroy();closeSockets();if(registered){unregisterReceiver(receiver);registered=false;}}
    @Override public void onBackPressed(){if(webView!=null&&webView.canGoBack())webView.goBack();else super.onBackPressed();}
}
