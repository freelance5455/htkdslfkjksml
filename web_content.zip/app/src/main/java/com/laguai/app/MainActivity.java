package com.laguai.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URLEncoder;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {
    private WebView webView;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings s=webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new GoogleBridge(), "AndroidGoogle");
        webView.getSettings().setUserAgentString("Mozilla/5.0 (Linux; Android 11) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36");
        webView.loadUrl("file:///android_asset/web/index.html");
    }

    private class GoogleBridge {
        @JavascriptInterface
        public boolean isAvailable() { return true; }

        @JavascriptInterface
        public void search(final String query) {
            new Thread(() -> {
                String result;
                try {
                    result = googleSearch(query);
                } catch (Exception e) {
                    result = "Não consegui consultar o Google agora. Verifique sua conexão com a internet.";
                }
                final String safe = jsonEscape(result);
                runOnUiThread(() -> webView.evaluateJavascript("window.receberPesquisaGoogle(" + safe + ")", null));
            }).start();
        }
    }

    private String googleSearch(String query) throws Exception {
        String urlText = "https://www.google.com/search?gbv=1&hl=pt-BR&gl=br&num=5&q=" + URLEncoder.encode(query, "UTF-8");
        HttpURLConnection c = (HttpURLConnection)new URL(urlText).openConnection();
        c.setRequestMethod("GET");
        c.setConnectTimeout(10000);
        c.setReadTimeout(10000);
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36");
        c.setRequestProperty("Accept-Language", "pt-BR,pt;q=0.9");
        int code=c.getResponseCode();
        if(code < 200 || code >= 400) throw new Exception("HTTP " + code);
        BufferedReader r=new BufferedReader(new InputStreamReader(c.getInputStream(), StandardCharsets.UTF_8));
        StringBuilder html=new StringBuilder(); String line;
        while((line=r.readLine())!=null) html.append(line).append('\n');
        r.close(); c.disconnect();
        String text=html.toString();
        text=text.replaceAll("(?is)<script.*?</script>", " ").replaceAll("(?is)<style.*?</style>", " ");
        StringBuilder out=new StringBuilder();
        Pattern p=Pattern.compile("(?is)<div[^>]*>(.*?)</div>");
        Matcher m=p.matcher(text);
        int count=0;
        while(m.find() && count<20){
            String s=stripTags(m.group(1));
            s=decodeEntities(s).replaceAll("\\s+"," ").trim();
            if(s.length()>=45 && !looksLikeNoise(s) && !out.toString().contains(s)){
                if(out.length()>0) out.append("\n\n");
                out.append("• ").append(s.length()>500?s.substring(0,500)+"…":s);
                count++;
            }
        }
        if(out.length()==0) return "O Google não retornou trechos legíveis para esta pesquisa. Tente reformular a pergunta.";
        return "Resultados encontrados no Google para: " + query + "\n\n" + out;
    }

    private boolean looksLikeNoise(String s){
        String x=s.toLowerCase();
        return x.equals("imagens") || x.equals("vídeos") || x.equals("notícias") || x.contains("fazer login") || x.contains("termos") || x.contains("privacidade");
    }
    private String stripTags(String s){ return s.replaceAll("(?is)<br\\s*/?>", "\\n").replaceAll("(?is)<[^>]+>", " "); }
    private String decodeEntities(String s){
        return s.replace("&amp;","&").replace("&quot;","\"").replace("&#39;","'").replace("&lt;","<").replace("&gt;",">").replace("&nbsp;"," ");
    }
    private String jsonEscape(String s){
        return "\"" + s.replace("\\","\\\\").replace("\"","\\\"").replace("\r","\\r").replace("\n","\\n") + "\"";
    }
}
