package com.example.converter

import java.math.BigDecimal
import java.math.MathContext
import kotlin.math.PI

enum class ConverterCategory(
  val title: String,
  val isCurrency: Boolean = false,
) {
  LENGTH("Length"),
  WEIGHT("Weight / Mass"),
  TEMPERATURE("Temperature"),
  AREA("Area"),
  VOLUME("Volume"),
  SPEED("Speed"),
  TIME("Time"),
  DATA_STORAGE("Data Storage"),
  PRESSURE("Pressure"),
  ENERGY("Energy"),
  POWER("Power"),
  FORCE("Force"),
  ANGLE("Angle"),
  FREQUENCY("Frequency"),
  FUEL_ECONOMY("Fuel Economy"),
  CURRENCY("Currency (Offline)", isCurrency = true),
}

data class ConversionUnit(
  val id: String,
  val name: String,
  val symbol: String,
  val toBaseFactor: Double = 1.0,
)

object UnitConverter {

  fun unitsFor(category: ConverterCategory): List<ConversionUnit> {
    return when (category) {
      ConverterCategory.LENGTH ->
        listOf(
          ConversionUnit("mm", "Millimeter", "mm", 0.001),
          ConversionUnit("cm", "Centimeter", "cm", 0.01),
          ConversionUnit("m", "Meter", "m", 1.0),
          ConversionUnit("km", "Kilometer", "km", 1000.0),
          ConversionUnit("in", "Inch", "in", 0.0254),
          ConversionUnit("ft", "Foot", "ft", 0.3048),
          ConversionUnit("yd", "Yard", "yd", 0.9144),
          ConversionUnit("mi", "Mile", "mi", 1609.344),
          ConversionUnit("nmi", "Nautical Mile", "nmi", 1852.0),
        )
      ConverterCategory.WEIGHT ->
        listOf(
          ConversionUnit("mg", "Milligram", "mg", 1e-6),
          ConversionUnit("g", "Gram", "g", 0.001),
          ConversionUnit("kg", "Kilogram", "kg", 1.0),
          ConversionUnit("t", "Metric Ton", "t", 1000.0),
          ConversionUnit("oz", "Ounce", "oz", 0.028349523125),
          ConversionUnit("lb", "Pound", "lb", 0.45359237),
          ConversionUnit("st", "Stone", "st", 6.35029318),
        )
      ConverterCategory.TEMPERATURE ->
        listOf(
          ConversionUnit("c", "Celsius", "°C"),
          ConversionUnit("f", "Fahrenheit", "°F"),
          ConversionUnit("k", "Kelvin", "K"),
        )
      ConverterCategory.AREA ->
        listOf(
          ConversionUnit("mm2", "Square Millimeter", "mm²", 1e-6),
          ConversionUnit("cm2", "Square Centimeter", "cm²", 1e-4),
          ConversionUnit("m2", "Square Meter", "m²", 1.0),
          ConversionUnit("ha", "Hectare", "ha", 10000.0),
          ConversionUnit("km2", "Square Kilometer", "km²", 1e6),
          ConversionUnit("in2", "Square Inch", "in²", 0.00064516),
          ConversionUnit("ft2", "Square Foot", "ft²", 0.09290304),
          ConversionUnit("yd2", "Square Yard", "yd²", 0.83612736),
          ConversionUnit("ac", "Acre", "ac", 4046.8564224),
          ConversionUnit("mi2", "Square Mile", "mi²", 2589988.110336),
        )
      ConverterCategory.VOLUME ->
        listOf(
          ConversionUnit("ml", "Milliliter", "mL", 0.001),
          ConversionUnit("l", "Liter", "L", 1.0),
          ConversionUnit("m3", "Cubic Meter", "m³", 1000.0),
          ConversionUnit("tsp", "Teaspoon (US)", "tsp", 0.00492892159375),
          ConversionUnit("tbsp", "Tablespoon (US)", "tbsp", 0.01478676478125),
          ConversionUnit("floz", "Fluid Ounce (US)", "fl oz", 0.0295735295625),
          ConversionUnit("cup", "Cup (US)", "cup", 0.2365882365),
          ConversionUnit("pt", "Pint (US)", "pt", 0.473176473),
          ConversionUnit("qt", "Quart (US)", "qt", 0.946352946),
          ConversionUnit("gal", "Gallon (US)", "gal", 3.785411784),
        )
      ConverterCategory.SPEED ->
        listOf(
          ConversionUnit("ms", "Meters / second", "m/s", 1.0),
          ConversionUnit("kmh", "Kilometers / hour", "km/h", 1.0 / 3.6),
          ConversionUnit("mph", "Miles / hour", "mph", 0.44704),
          ConversionUnit("kn", "Knot", "kn", 1852.0 / 3600.0),
          ConversionUnit("fts", "Feet / second", "ft/s", 0.3048),
        )
      ConverterCategory.TIME ->
        listOf(
          ConversionUnit("ms", "Millisecond", "ms", 0.001),
          ConversionUnit("s", "Second", "s", 1.0),
          ConversionUnit("min", "Minute", "min", 60.0),
          ConversionUnit("h", "Hour", "h", 3600.0),
          ConversionUnit("d", "Day", "d", 86400.0),
          ConversionUnit("wk", "Week", "wk", 604800.0),
          ConversionUnit("mo", "Month (avg)", "mo", 2629800.0),
          ConversionUnit("yr", "Year (Julian)", "yr", 31557600.0),
        )
      ConverterCategory.DATA_STORAGE ->
        listOf(
          ConversionUnit("bit", "Bit", "bit", 0.125),
          ConversionUnit("b", "Byte", "B", 1.0),
          ConversionUnit("kb", "Kilobyte (10³)", "KB", 1000.0),
          ConversionUnit("mb", "Megabyte (10⁶)", "MB", 1e6),
          ConversionUnit("gb", "Gigabyte (10⁹)", "GB", 1e9),
          ConversionUnit("tb", "Terabyte (10¹²)", "TB", 1e12),
          ConversionUnit("kib", "Kibibyte (2¹⁰)", "KiB", 1024.0),
          ConversionUnit("mib", "Mebibyte (2²⁰)", "MiB", 1048576.0),
          ConversionUnit("gib", "Gibibyte (2³⁰)", "GiB", 1073741824.0),
          ConversionUnit("tib", "Tebibyte (2⁴⁰)", "TiB", 1099511627776.0),
        )
      ConverterCategory.PRESSURE ->
        listOf(
          ConversionUnit("pa", "Pascal", "Pa", 1.0),
          ConversionUnit("kpa", "Kilopascal", "kPa", 1000.0),
          ConversionUnit("mpa", "Megapascal", "MPa", 1e6),
          ConversionUnit("bar", "Bar", "bar", 100000.0),
          ConversionUnit("atm", "Atmosphere", "atm", 101325.0),
          ConversionUnit("psi", "Pounds / sq inch", "psi", 6894.757293168),
          ConversionUnit("mmhg", "Millimeter of Hg", "mmHg", 133.322387415),
        )
      ConverterCategory.ENERGY ->
        listOf(
          ConversionUnit("j", "Joule", "J", 1.0),
          ConversionUnit("kj", "Kilojoule", "kJ", 1000.0),
          ConversionUnit("cal", "Calorie", "cal", 4.184),
          ConversionUnit("kcal", "Kilocalorie", "kcal", 4184.0),
          ConversionUnit("wh", "Watt-hour", "Wh", 3600.0),
          ConversionUnit("kwh", "Kilowatt-hour", "kWh", 3.6e6),
          ConversionUnit("btu", "British Thermal Unit", "BTU", 1055.05585262),
          ConversionUnit("ev", "Electronvolt", "eV", 1.602176634e-19),
        )
      ConverterCategory.POWER ->
        listOf(
          ConversionUnit("w", "Watt", "W", 1.0),
          ConversionUnit("kw", "Kilowatt", "kW", 1000.0),
          ConversionUnit("mw", "Megawatt", "MW", 1e6),
          ConversionUnit("hp", "Horsepower (mech)", "hp", 745.6998715822702),
          ConversionUnit("btuh", "BTU / hour", "BTU/h", 0.2930710701722222),
        )
      ConverterCategory.FORCE ->
        listOf(
          ConversionUnit("n", "Newton", "N", 1.0),
          ConversionUnit("kn", "Kilonewton", "kN", 1000.0),
          ConversionUnit("lbf", "Pound-force", "lbf", 4.4482216152605),
          ConversionUnit("kgf", "Kilogram-force", "kgf", 9.80665),
          ConversionUnit("dyn", "Dyne", "dyn", 1e-5),
        )
      ConverterCategory.ANGLE ->
        listOf(
          ConversionUnit("deg", "Degree", "°", 1.0),
          ConversionUnit("rad", "Radian", "rad", 180.0 / PI),
          ConversionUnit("grad", "Gradian", "grad", 0.9),
          ConversionUnit("arcmin", "Arcminute", "′", 1.0 / 60.0),
          ConversionUnit("arcsec", "Arcsecond", "″", 1.0 / 3600.0),
          ConversionUnit("rev", "Revolution", "rev", 360.0),
        )
      ConverterCategory.FREQUENCY ->
        listOf(
          ConversionUnit("hz", "Hertz", "Hz", 1.0),
          ConversionUnit("khz", "Kilohertz", "kHz", 1000.0),
          ConversionUnit("mhz", "Megahertz", "MHz", 1e6),
          ConversionUnit("ghz", "Gigahertz", "GHz", 1e9),
        )
      ConverterCategory.FUEL_ECONOMY ->
        listOf(
          ConversionUnit("kml", "Kilometers / Liter", "km/L"),
          ConversionUnit("l100km", "Liters / 100 km", "L/100km"),
          ConversionUnit("mpg_us", "Miles / Gallon (US)", "mpg US"),
          ConversionUnit("mpg_uk", "Miles / Gallon (UK)", "mpg UK"),
        )
      ConverterCategory.CURRENCY ->
        // Static offline reference baselines relative to 1 USD (not live rates).
        listOf(
          ConversionUnit("usd", "US Dollar (Ref)", "USD", 1.0),
          ConversionUnit("eur", "Euro (Ref)", "EUR", 1.08),
          ConversionUnit("gbp", "British Pound (Ref)", "GBP", 1.27),
          ConversionUnit("inr", "Indian Rupee (Ref)", "INR", 0.012),
          ConversionUnit("jpy", "Japanese Yen (Ref)", "JPY", 0.0065),
          ConversionUnit("cad", "Canadian Dollar (Ref)", "CAD", 0.72),
          ConversionUnit("aud", "Australian Dollar (Ref)", "AUD", 0.65),
          ConversionUnit("chf", "Swiss Franc (Ref)", "CHF", 1.13),
        )
    }
  }

  fun convert(
    value: Double,
    from: ConversionUnit,
    to: ConversionUnit,
    category: ConverterCategory,
    customCurrencyRate: Double? = null,
  ): Double? {
    if (!value.isFinite()) return null
    if (from.id == to.id) return value

    if (category == ConverterCategory.CURRENCY && customCurrencyRate != null) {
      if (!customCurrencyRate.isFinite() || customCurrencyRate <= 0.0) return null
      val res = value * customCurrencyRate
      return if (res.isFinite()) res else null
    }

    val result =
      when (category) {
        ConverterCategory.TEMPERATURE -> convertTemperature(value, from.id, to.id)
        ConverterCategory.FUEL_ECONOMY -> convertFuelEconomy(value, from.id, to.id)
        else -> {
          BigDecimal.valueOf(value)
            .multiply(BigDecimal.valueOf(from.toBaseFactor))
            .divide(BigDecimal.valueOf(to.toBaseFactor), MathContext.DECIMAL128)
            .toDouble()
        }
      }
    return if (result != null && result.isFinite()) result else null
  }

  fun defaultRateBetween(from: ConversionUnit, to: ConversionUnit): Double {
    return from.toBaseFactor / to.toBaseFactor
  }

  private fun convertTemperature(value: Double, fromId: String, toId: String): Double {
    val celsius =
      when (fromId) {
        "c" -> value
        "f" -> (value - 32.0) * 5.0 / 9.0
        "k" -> value - 273.15
        else -> value
      }
    return when (toId) {
      "c" -> celsius
      "f" -> celsius * 9.0 / 5.0 + 32.0
      "k" -> celsius + 273.15
      else -> celsius
    }
  }

  private fun convertFuelEconomy(value: Double, fromId: String, toId: String): Double? {
    if (value < 0.0) return null
    if (value == 0.0) {
      return if (fromId == "l100km" || toId == "l100km") null else 0.0
    }
    val kmPerLiter =
      when (fromId) {
        "kml" -> value
        "l100km" -> 100.0 / value
        "mpg_us" -> value * (1.609344 / 3.785411784)
        "mpg_uk" -> value * (1.609344 / 4.54609)
        else -> return null
      }
    return when (toId) {
      "kml" -> kmPerLiter
      "l100km" -> if (kmPerLiter == 0.0) null else 100.0 / kmPerLiter
      "mpg_us" -> kmPerLiter / (1.609344 / 3.785411784)
      "mpg_uk" -> kmPerLiter / (1.609344 / 4.54609)
      else -> null
    }
  }
}
