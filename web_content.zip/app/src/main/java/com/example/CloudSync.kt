package com.example

import android.content.Context
import androidx.compose.ui.graphics.Color
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

// ==========================================
// CLOUD SYNCHRONIZATION CLIENT
// Connects all users & downloaders worldwide
// ==========================================

object MtxCloudSync {
  val CLOUD_DEV_URL = "https://ais-dev-favujoqaycbqytu7c7peu4-51913299496.asia-east1.run.app"
  val CLOUD_BASE_URL = "https://ais-pre-favujoqaycbqytu7c7peu4-51913299496.asia-east1.run.app"
  private const val EMULATOR_LOOPBACK_URL = "http://10.0.2.2:3000"

  // Ordered candidate URLs:
  // Live verified Cloud Run dev route first
  private val CANDIDATE_URLS = listOf(CLOUD_DEV_URL, CLOUD_BASE_URL, EMULATOR_LOOPBACK_URL)

  private inline fun <T> executeWithFallback(block: (String) -> T?): T? {
    for (base in CANDIDATE_URLS) {
      try {
        val result = block(base)
        if (result != null) return result
      } catch (_: Exception) {}
    }
    return null
  }

  // 1. Fetch all shared videos from cloud server
  suspend fun fetchVideos(context: Context): List<VideoItem>? = withContext(Dispatchers.IO) {
    executeWithFallback { baseUrl ->
      try {
        val url = URL("$baseUrl/api/videos")
        val conn = (url.openConnection() as HttpURLConnection).apply {
          requestMethod = "GET"
          connectTimeout = 6000
          readTimeout = 8000
          instanceFollowRedirects = false
        }
        if (conn.responseCode == 200) {
          val jsonStr = conn.inputStream.bufferedReader().use { it.readText() }
          val array = JSONArray(jsonStr)
          val list = mutableListOf<VideoItem>()
          for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            val colorHex = obj.optLong("accentColor", 0xFF3B82F6L)
            var uri = obj.getString("videoUri")
            if (uri.startsWith("/")) {
              uri = "$baseUrl$uri"
            }
            val isDarkVal = obj.optBoolean("isDark", false) ||
              obj.optString("isDark").equals("true", ignoreCase = true) ||
              obj.optInt("isDark", 0) == 1

            list.add(
              VideoItem(
                id = obj.getInt("id"),
                title = obj.getString("title"),
                category = obj.getString("category"),
                duration = obj.optString("duration", "05:00"),
                views = obj.optString("views", "1"),
                description = obj.optString("description", ""),
                videoUri = resolveMediaUri(uri),
                isLocalFile = false,
                accentColor = Color(colorHex.toULong()),
                isPublished = obj.optBoolean("isPublished", true),
                isDark = isDarkVal
              )
            )
          }

          // Merge with any local videos to guarantee videos never disappear
          val localList = VideoStorage.loadVideos(context)
          val merged = list.toMutableList()
          for (local in localList) {
            if (!merged.any { it.id == local.id || (it.title == local.title && it.isDark == local.isDark) }) {
              merged.add(local)
            }
          }
          VideoStorage.saveVideos(context, merged)
          merged
        } else null
      } catch (_: Exception) {
        null
      }
    }
  }

  // 2. Fetch all shared photos from cloud server
  suspend fun fetchPhotos(context: Context): List<PhotoItem>? = withContext(Dispatchers.IO) {
    executeWithFallback { baseUrl ->
      try {
        val url = URL("$baseUrl/api/photos")
        val conn = (url.openConnection() as HttpURLConnection).apply {
          requestMethod = "GET"
          connectTimeout = 6000
          readTimeout = 8000
          instanceFollowRedirects = false
        }
        if (conn.responseCode == 200) {
          val jsonStr = conn.inputStream.bufferedReader().use { it.readText() }
          val array = JSONArray(jsonStr)
          val list = mutableListOf<PhotoItem>()
          for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            var uri = obj.getString("imageUri")
            if (uri.startsWith("/")) {
              uri = "$baseUrl$uri"
            }
            val isDarkVal = obj.optBoolean("isDark", false) ||
              obj.optString("isDark").equals("true", ignoreCase = true) ||
              obj.optInt("isDark", 0) == 1

            list.add(
              PhotoItem(
                id = obj.getInt("id"),
                title = obj.getString("title"),
                category = obj.getString("category"),
                imageUri = resolveMediaUri(uri),
                isLocalFile = false,
                uploadDate = obj.optString("uploadDate", "Recent"),
                likes = obj.optInt("likes", 14),
                isPublished = obj.optBoolean("isPublished", true),
                isDark = isDarkVal
              )
            )
          }

          val localPhotos = PhotoStorage.loadPhotos(context)
          val merged = list.toMutableList()
          for (local in localPhotos) {
            if (!merged.any { it.id == local.id || (it.title == local.title && it.isDark == local.isDark) }) {
              merged.add(local)
            }
          }
          PhotoStorage.savePhotos(context, merged)
          merged
        } else null
      } catch (_: Exception) {
        null
      }
    }
  }

  // 3. Upload media in small chunks to avoid cloud proxy request-size limits.
  suspend fun uploadMediaFile(file: File, mimeType: String): String? = withContext(Dispatchers.IO) {
    if (!file.exists() || !file.isFile || file.length() <= 0L) return@withContext null

    executeWithFallback { baseUrl ->
      val uploadId = java.util.UUID.randomUUID().toString()
      val chunkSize = 4 * 1024 * 1024
      val totalChunks = ((file.length() + chunkSize - 1) / chunkSize).toInt()
      var resultUrl: String? = null

      try {
        file.inputStream().buffered().use { input ->
          val buffer = ByteArray(chunkSize)
          for (index in 0 until totalChunks) {
            var count = 0
            while (count < chunkSize) {
              val read = input.read(buffer, count, chunkSize - count)
              if (read <= 0) break
              count += read
            }
            if (count <= 0) throw java.io.IOException("Empty upload chunk")

            val url = URL("$baseUrl/api/upload/chunk")
            val conn = (url.openConnection() as HttpURLConnection).apply {
              requestMethod = "POST"
              doOutput = true
              connectTimeout = 30000
              readTimeout = 90000
              setFixedLengthStreamingMode(count)
              setRequestProperty("Content-Type", mimeType)
              setRequestProperty("X-Upload-Id", uploadId)
              setRequestProperty("X-Chunk-Index", index.toString())
              setRequestProperty("X-Chunk-Count", totalChunks.toString())
              setRequestProperty("X-File-Name", file.name)
            }

            try {
              conn.outputStream.use { output -> output.write(buffer, 0, count); output.flush() }
              val responseCode = conn.responseCode
              val responseStream = if (responseCode in 200..299) conn.inputStream else conn.errorStream
              val responseText = responseStream?.bufferedReader()?.use { it.readText() }.orEmpty()
              if (responseCode !in 200..299) {
                throw java.io.IOException("Upload server returned HTTP $responseCode: ${responseText.take(300)}")
              }
              if (index == totalChunks - 1) {
                val json = JSONObject(responseText)
                if (!json.optBoolean("success") || !json.optBoolean("complete")) {
                  throw java.io.IOException("Server did not confirm completed upload")
                }
                val relativeUrl = json.optString("relativeUrl")
                val rawUrl = if (relativeUrl.isNotBlank()) "$baseUrl$relativeUrl" else json.optString("url")
                if (rawUrl.isBlank()) throw java.io.IOException("Server returned no media URL")
                resultUrl = resolveMediaUri(rawUrl)
              }
            } finally {
              conn.disconnect()
            }
          }
        }
        resultUrl
      } catch (e: Exception) {
        android.util.Log.e("MtxCloudSync", "Chunked media upload failed on $baseUrl", e)
        null
      }
    }
  }

  // 4. Save/Publish video to cloud server
  suspend fun syncVideoToCloud(video: VideoItem): Boolean = withContext(Dispatchers.IO) {
    val success = executeWithFallback { baseUrl ->
      try {
        val url = URL("$baseUrl/api/videos")
        val conn = (url.openConnection() as HttpURLConnection).apply {
          requestMethod = "POST"
          doOutput = true
          setRequestProperty("Content-Type", "application/json")
          connectTimeout = 15000
          readTimeout = 15000
        }
        val obj = JSONObject().apply {
          put("id", video.id)
          put("title", video.title)
          put("category", video.category)
          put("duration", video.duration)
          put("views", video.views)
          put("description", video.description)
          put("videoUri", video.videoUri)
          put("isLocalFile", false)
          put("accentColor", video.accentColor.value.toLong())
          put("isPublished", video.isPublished)
          put("isDark", video.isDark)
        }
        conn.outputStream.use { it.write(obj.toString().toByteArray(Charsets.UTF_8)) }
        if (conn.responseCode == 200) true else null
      } catch (_: Exception) {
        null
      }
    }
    success ?: false
  }

  // 5. Save/Publish photo to cloud server
  suspend fun syncPhotoToCloud(photo: PhotoItem): Boolean = withContext(Dispatchers.IO) {
    val success = executeWithFallback { baseUrl ->
      try {
        val url = URL("$baseUrl/api/photos")
        val conn = (url.openConnection() as HttpURLConnection).apply {
          requestMethod = "POST"
          doOutput = true
          setRequestProperty("Content-Type", "application/json")
          connectTimeout = 15000
          readTimeout = 15000
        }
        val obj = JSONObject().apply {
          put("id", photo.id)
          put("title", photo.title)
          put("category", photo.category)
          put("imageUri", photo.imageUri)
          put("isLocalFile", false)
          put("uploadDate", photo.uploadDate)
          put("likes", photo.likes)
          put("isPublished", photo.isPublished)
          put("isDark", photo.isDark)
        }
        conn.outputStream.use { it.write(obj.toString().toByteArray(Charsets.UTF_8)) }
        if (conn.responseCode == 200) true else null
      } catch (_: Exception) {
        null
      }
    }
    success ?: false
  }

  // 6. Delete video from cloud
  suspend fun deleteVideoFromCloud(videoId: Int) = withContext(Dispatchers.IO) {
    executeWithFallback { baseUrl ->
      try {
        val url = URL("$baseUrl/api/videos/$videoId")
        val conn = (url.openConnection() as HttpURLConnection).apply {
          requestMethod = "DELETE"
          connectTimeout = 3000
          readTimeout = 3000
        }
        conn.responseCode
      } catch (_: Exception) { null }
    }
  }

  // 7. Delete photo from cloud
  suspend fun deletePhotoFromCloud(photoId: Int) = withContext(Dispatchers.IO) {
    executeWithFallback { baseUrl ->
      try {
        val url = URL("$baseUrl/api/photos/$photoId")
        val conn = (url.openConnection() as HttpURLConnection).apply {
          requestMethod = "DELETE"
          connectTimeout = 3000
          readTimeout = 3000
        }
        conn.responseCode
      } catch (_: Exception) { null }
    }
  }

  // 8. Dark User: Submit face photo application
  suspend fun submitDarkUserApplication(userId: String, userName: String, facePhotoUri: String): Boolean = withContext(Dispatchers.IO) {
    val success = executeWithFallback { baseUrl ->
      try {
        val url = URL("$baseUrl/api/dark-users/apply")
        val conn = (url.openConnection() as HttpURLConnection).apply {
          requestMethod = "POST"
          doOutput = true
          setRequestProperty("Content-Type", "application/json")
          connectTimeout = 15000
          readTimeout = 15000
        }
        val obj = JSONObject().apply {
          put("userId", userId)
          put("userName", userName)
          put("facePhotoUri", facePhotoUri)
        }
        conn.outputStream.use { it.write(obj.toString().toByteArray(Charsets.UTF_8)) }
        if (conn.responseCode == 200) true else null
      } catch (_: Exception) {
        null
      }
    }
    success ?: false
  }

  // 9. Dark User: Check status
  suspend fun checkDarkUserStatus(userId: String): Pair<Boolean, String> = withContext(Dispatchers.IO) {
    val result = executeWithFallback { baseUrl ->
      try {
        val url = URL("$baseUrl/api/dark-users/status?userId=$userId")
        val conn = (url.openConnection() as HttpURLConnection).apply {
          requestMethod = "GET"
          connectTimeout = 3000
          readTimeout = 3000
          instanceFollowRedirects = false
        }
        if (conn.responseCode == 200) {
          val json = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
          val isApproved = json.optBoolean("isApproved", false)
          val status = json.optString("status", "not_applied")
          Pair(isApproved, status)
        } else null
      } catch (_: Exception) {
        null
      }
    }
    result ?: Pair(false, "not_applied")
  }

  // 10. Dark User: Admin fetch list of applications from cloud
  suspend fun fetchDarkUsersList(): List<DarkUserApplication>? = withContext(Dispatchers.IO) {
    executeWithFallback { baseUrl ->
      try {
        val url = URL("$baseUrl/api/dark-users/list")
        val conn = (url.openConnection() as HttpURLConnection).apply {
          requestMethod = "GET"
          connectTimeout = 15000
          readTimeout = 15000
          instanceFollowRedirects = false
        }
        if (conn.responseCode == 200) {
          val array = JSONArray(conn.inputStream.bufferedReader().use { it.readText() })
          val list = mutableListOf<DarkUserApplication>()
          for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            var faceUri = obj.optString("facePhotoUri", "")
            if (faceUri.startsWith("/")) {
              faceUri = "$baseUrl$faceUri"
            }
            list.add(
              DarkUserApplication(
                userId = obj.getString("userId"),
                userName = obj.optString("userName", "Applicant"),
                facePhotoUri = faceUri,
                status = obj.optString("status", "pending"),
                appliedAt = obj.optString("appliedAt", "")
              )
            )
          }
          list
        } else null
      } catch (_: Exception) {
        null
      }
    }
  }

  // 11. Dark User: Admin approve
  suspend fun approveDarkUser(userId: String): Boolean = withContext(Dispatchers.IO) {
    val success = executeWithFallback { baseUrl ->
      try {
        val url = URL("$baseUrl/api/dark-users/approve")
        val conn = (url.openConnection() as HttpURLConnection).apply {
          requestMethod = "POST"
          doOutput = true
          setRequestProperty("Content-Type", "application/json")
          connectTimeout = 3000
          readTimeout = 3000
        }
        val payload = JSONObject().apply { put("userId", userId) }
        conn.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
        if (conn.responseCode == 200) true else null
      } catch (_: Exception) {
        null
      }
    }
    success ?: false
  }

  // 12. Dark User: Admin reject
  suspend fun rejectDarkUser(userId: String): Boolean = withContext(Dispatchers.IO) {
    val success = executeWithFallback { baseUrl ->
      try {
        val url = URL("$baseUrl/api/dark-users/reject")
        val conn = (url.openConnection() as HttpURLConnection).apply {
          requestMethod = "POST"
          doOutput = true
          setRequestProperty("Content-Type", "application/json")
          connectTimeout = 3000
          readTimeout = 3000
        }
        val payload = JSONObject().apply { put("userId", userId) }
        conn.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
        if (conn.responseCode == 200) true else null
      } catch (_: Exception) {
        null
      }
    }
    success ?: false
  }

  // 13. Dark User: Admin remove / revoke dark user access at any time!
  suspend fun revokeDarkUser(userId: String): Boolean = withContext(Dispatchers.IO) {
    val success = executeWithFallback { baseUrl ->
      try {
        val url = URL("$baseUrl/api/dark-users/remove")
        val conn = (url.openConnection() as HttpURLConnection).apply {
          requestMethod = "POST"
          doOutput = true
          setRequestProperty("Content-Type", "application/json")
          connectTimeout = 3000
          readTimeout = 3000
        }
        val payload = JSONObject().apply { put("userId", userId) }
        conn.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
        if (conn.responseCode == 200) true else null
      } catch (_: Exception) {
        null
      }
    }
    success ?: false
  }

  // 14. Normal User: Register app device on server
  suspend fun registerNormalUser(userId: String, userName: String): Boolean = withContext(Dispatchers.IO) {
    val success = executeWithFallback { baseUrl ->
      try {
        val url = URL("$baseUrl/api/users/register")
        val conn = (url.openConnection() as HttpURLConnection).apply {
          requestMethod = "POST"
          doOutput = true
          setRequestProperty("Content-Type", "application/json")
          connectTimeout = 3000
          readTimeout = 3000
        }
        val payload = JSONObject().apply {
          put("userId", userId)
          put("userName", userName)
          put("deviceModel", android.os.Build.MODEL ?: "Android Device")
        }
        conn.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
        if (conn.responseCode == 200) true else null
      } catch (_: Exception) {
        null
      }
    }
    success ?: false
  }

  // 15. Admin: Fetch list of users in dark and normal
  suspend fun fetchUsersSummary(): UsersSummary? = withContext(Dispatchers.IO) {
    executeWithFallback { baseUrl ->
      try {
        val url = URL("$baseUrl/api/users/all")
        val conn = (url.openConnection() as HttpURLConnection).apply {
          requestMethod = "GET"
          connectTimeout = 15000
          readTimeout = 15000
          instanceFollowRedirects = false
        }
        if (conn.responseCode == 200) {
          val json = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })

          val normalArray = json.optJSONArray("normalUsers") ?: JSONArray()
          val normalList = mutableListOf<NormalUser>()
          for (i in 0 until normalArray.length()) {
            val obj = normalArray.getJSONObject(i)
            normalList.add(
              NormalUser(
                userId = obj.getString("userId"),
                userName = obj.optString("userName", "User"),
                deviceModel = obj.optString("deviceModel", "Android Device"),
                joinedAt = obj.optString("joinedAt", "Recent"),
                lastSeen = obj.optString("lastSeen", "Active")
              )
            )
          }

          val approvedArray = json.optJSONArray("approvedDarkUsers") ?: JSONArray()
          val approvedList = mutableListOf<DarkUserApplication>()
          for (i in 0 until approvedArray.length()) {
            val obj = approvedArray.getJSONObject(i)
            var faceUri = obj.optString("facePhotoUri", "")
            if (faceUri.startsWith("/")) faceUri = "$baseUrl$faceUri"
            approvedList.add(
              DarkUserApplication(
                userId = obj.getString("userId"),
                userName = obj.optString("userName", "Member"),
                facePhotoUri = faceUri,
                status = obj.optString("status", "approved"),
                appliedAt = obj.optString("appliedAt", "")
              )
            )
          }

          val pendingArray = json.optJSONArray("pendingDarkUsers") ?: JSONArray()
          val pendingList = mutableListOf<DarkUserApplication>()
          for (i in 0 until pendingArray.length()) {
            val obj = pendingArray.getJSONObject(i)
            var faceUri = obj.optString("facePhotoUri", "")
            if (faceUri.startsWith("/")) faceUri = "$baseUrl$faceUri"
            pendingList.add(
              DarkUserApplication(
                userId = obj.getString("userId"),
                userName = obj.optString("userName", "Applicant"),
                facePhotoUri = faceUri,
                status = obj.optString("status", "pending"),
                appliedAt = obj.optString("appliedAt", "")
              )
            )
          }

          val allArray = json.optJSONArray("allDarkApplications") ?: JSONArray()
          val allList = mutableListOf<DarkUserApplication>()
          for (i in 0 until allArray.length()) {
            val obj = allArray.getJSONObject(i)
            var faceUri = obj.optString("facePhotoUri", "")
            if (faceUri.startsWith("/")) faceUri = "$baseUrl$faceUri"
            allList.add(
              DarkUserApplication(
                userId = obj.getString("userId"),
                userName = obj.optString("userName", "User"),
                facePhotoUri = faceUri,
                status = obj.optString("status", "not_applied"),
                appliedAt = obj.optString("appliedAt", "")
              )
            )
          }

          UsersSummary(
            normalUsers = normalList,
            approvedDarkUsers = approvedList,
            pendingDarkUsers = pendingList,
            allDarkApplications = allList
          )
        } else null
      } catch (_: Exception) {
        null
      }
    }
  }
}
