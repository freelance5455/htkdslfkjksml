package com.example

import android.app.Application
import com.example.data.database.AppDatabase
import com.example.data.repository.AuthRepository
import com.example.data.repository.ExamRepository
import com.example.data.repository.NoteRepository
import com.example.data.repository.ProfileRepository
import com.example.data.repository.SettingsRepository
import com.example.data.repository.StudySessionRepository
import com.example.data.repository.SubjectRepository

class DailyStudyApplication : Application() {

    lateinit var database: AppDatabase
        private set

    lateinit var authRepository: AuthRepository
        private set

    lateinit var profileRepository: ProfileRepository
        private set

    lateinit var settingsRepository: SettingsRepository
        private set

    lateinit var subjectRepository: SubjectRepository
        private set

    lateinit var studySessionRepository: StudySessionRepository
        private set

    lateinit var examRepository: ExamRepository
        private set

    lateinit var noteRepository: NoteRepository
        private set

    lateinit var backupManager: com.example.data.backup.BackupManager
        private set

    override fun onCreate() {
        super.onCreate()
        database = AppDatabase.getDatabase(this)
        authRepository = AuthRepository(
            userDao = database.userDao(),
            profileDao = database.profileDao(),
            appSettingsDao = database.appSettingsDao(),
            subjectDao = database.subjectDao(),
            sessionDao = database.studySessionDao(),
            examDao = database.examDao(),
            noteDao = database.noteDao(),
            internalFilesDir = filesDir
        )
        profileRepository = ProfileRepository(
            profileDao = database.profileDao(),
            internalFilesDir = filesDir
        )
        settingsRepository = SettingsRepository(
            appSettingsDao = database.appSettingsDao()
        )
        subjectRepository = SubjectRepository(
            subjectDao = database.subjectDao()
        )
        studySessionRepository = StudySessionRepository(
            sessionDao = database.studySessionDao()
        )
        examRepository = ExamRepository(
            examDao = database.examDao()
        )
        noteRepository = NoteRepository(
            noteDao = database.noteDao()
        )
        backupManager = com.example.data.backup.BackupManager(database)
    }
}
