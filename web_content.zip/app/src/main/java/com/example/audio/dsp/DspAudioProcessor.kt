package com.example.audio.dsp

import com.example.model.AudioEffectsConfig
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sqrt
import kotlin.math.tanh

/**
 * Real-time Audio DSP Processor.
 * Processes audio sample buffers applying real-time Echo Delay, Feedback damping,
 * Hall/Studio Reverb, Dry/Wet mixing, soft saturation limiter, and VU metering.
 */
class DspAudioProcessor(private val sampleRate: Int = 44100) {

    private val delayLine = DelayLine(maxDelaySeconds = 1.5f, sampleRate = sampleRate)
    private val reverb = SchroederReverb(sampleRate = sampleRate)

    @Volatile
    var config: AudioEffectsConfig = AudioEffectsConfig()

    // Level metering (0.0 .. 1.0) updated continuously
    @Volatile
    var currentRmsLevel: Float = 0f
        private set

    @Volatile
    var currentPeakLevel: Float = 0f
        private set

    fun reset() {
        delayLine.clear()
        reverb.clear()
        currentRmsLevel = 0f
        currentPeakLevel = 0f
    }

    /**
     * In-place DSP processing of float audio samples.
     * Takes dry input samples in `buffer`, processes them, and leaves the mixed processed audio in `buffer`.
     * Also records amplitude and peak for visualization.
     */
    fun process(buffer: FloatArray, count: Int) {
        val currentConfig = config
        val echoLvl = currentConfig.echoLevel
        val delayMs = currentConfig.delayTimeMs
        val fb = currentConfig.feedback
        val tone = currentConfig.toneDamp
        val revType = currentConfig.reverbType
        val revLvl = currentConfig.reverbLevel
        val revDecay = currentConfig.reverbDecay
        val dryLvl = currentConfig.dryLevel
        val wetLvl = currentConfig.wetLevel
        val gain = currentConfig.masterGain

        var sumSquares = 0.0
        var maxPeak = 0f

        for (i in 0 until count) {
            val drySample = buffer[i]

            // 1. Process Delay Line (DD-3 Echo)
            val echoSample = delayLine.process(drySample, delayMs, fb, tone)

            // 2. Process Reverb (feed dry + mild echo into spatial reverb)
            val reverbInput = drySample + (echoSample * 0.4f)
            val reverbSample = reverb.process(reverbInput, revType, revDecay)

            // 3. Dry / Wet Summing
            val wetCombined = (echoSample * echoLvl) + (reverbSample * revLvl)
            var mixed = (drySample * dryLvl) + (wetCombined * wetLvl)

            // Apply Master Gain
            mixed *= gain

            // 4. Studio Soft-Knee Saturation Limiter (prevent harsh digital overs)
            val processedSample = if (abs(mixed) > 0.85f) {
                // Tanh soft compression above 0.85
                val sign = if (mixed >= 0) 1f else -1f
                val excess = abs(mixed) - 0.85f
                val compressed = 0.85f + (0.15f * tanh(excess * 2.0f))
                (sign * compressed).coerceIn(-1.0f, 1.0f)
            } else {
                mixed
            }

            buffer[i] = processedSample

            val absSample = abs(processedSample)
            if (absSample > maxPeak) maxPeak = absSample
            sumSquares += (processedSample * processedSample)
        }

        val rms = if (count > 0) sqrt((sumSquares / count).toFloat()) else 0f
        // Smooth peak & rms decay
        currentRmsLevel = (currentRmsLevel * 0.7f) + (rms * 0.3f)
        currentPeakLevel = max(maxPeak, currentPeakLevel * 0.85f)
    }
}
