package com.example.audio.engine

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.os.Build
import android.os.Process
import com.example.audio.dsp.DspAudioProcessor
import com.example.audio.dsp.WavAudioWriter
import com.example.model.AudioEffectsConfig
import com.example.model.BitDepth
import com.example.model.RecordingState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Real-time Audio Engine.
 * Runs a dedicated urgent-priority audio thread that ingests microphone audio,
 * processes it through DspAudioProcessor, streams low-latency monitor audio to AudioTrack,
 * streams high-quality WAV to disk, and broadcasts real-time levels and waveforms.
 */
class RealtimeAudioEngine(private val context: Context) {

    private val sampleRate = 44100
    private val channelInConfig = AudioFormat.CHANNEL_IN_MONO
    private val channelOutConfig = AudioFormat.CHANNEL_OUT_MONO
    private val audioFormat = AudioFormat.ENCODING_PCM_16BIT

    val dspProcessor = DspAudioProcessor(sampleRate)

    private var audioRecord: AudioRecord? = null
    private var audioTrack: AudioTrack? = null
    private var processingThread: Thread? = null

    private val isEngineRunning = AtomicBoolean(false)
    private val isRecordingActive = AtomicBoolean(false)
    private val isRecordingPaused = AtomicBoolean(false)

    private var wavWriter: WavAudioWriter? = null
    private var currentRecordingFile: File? = null
    private var recordingStartTimeMs: Long = 0
    private var recordingDurationAccMs: Long = 0

    // Observable states for UI
    private val _recordingState = MutableStateFlow(RecordingState.IDLE)
    val recordingState: StateFlow<RecordingState> = _recordingState.asStateFlow()

    private val _liveRmsLevel = MutableStateFlow(0f)
    val liveRmsLevel: StateFlow<Float> = _liveRmsLevel.asStateFlow()

    private val _livePeakLevel = MutableStateFlow(0f)
    val livePeakLevel: StateFlow<Float> = _livePeakLevel.asStateFlow()

    // 64-point live normalized waveform slice for the oscilloscope display
    private val _liveWaveform = MutableStateFlow(FloatArray(64))
    val liveWaveform: StateFlow<FloatArray> = _liveWaveform.asStateFlow()

    private val _recordingDurationMs = MutableStateFlow(0L)
    val recordingDurationMs: StateFlow<Long> = _recordingDurationMs.asStateFlow()

    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    fun isHeadsetConnected(): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val devices = audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
            for (device in devices) {
                val type = device.type
                if (type == AudioDeviceInfo.TYPE_WIRED_HEADSET ||
                    type == AudioDeviceInfo.TYPE_WIRED_HEADPHONES ||
                    type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP ||
                    type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO ||
                    type == AudioDeviceInfo.TYPE_USB_HEADSET
                ) {
                    return true
                }
            }
            return false
        } else {
            @Suppress("DEPRECATION")
            return audioManager.isWiredHeadsetOn || audioManager.isBluetoothA2dpOn
        }
    }

    fun updateConfig(config: AudioEffectsConfig) {
        dspProcessor.config = config
    }

    @Synchronized
    fun startEngine(): Boolean {
        if (isEngineRunning.get()) return true

        val minInBuf = AudioRecord.getMinBufferSize(sampleRate, channelInConfig, audioFormat)
        val inBufSize = (minInBuf * 2).coerceAtLeast(4096)

        try {
            audioRecord = AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION,
                sampleRate,
                channelInConfig,
                audioFormat,
                inBufSize
            )

            if (audioRecord?.state != AudioRecord.STATE_INITIALIZED) {
                // Fallback to standard MIC
                audioRecord?.release()
                audioRecord = AudioRecord(
                    MediaRecorder.AudioSource.MIC,
                    sampleRate,
                    channelInConfig,
                    audioFormat,
                    inBufSize
                )
            }

            val minOutBuf = AudioTrack.getMinBufferSize(sampleRate, channelOutConfig, audioFormat)
            val outBufSize = (minOutBuf * 2).coerceAtLeast(4096)

            audioTrack = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(audioFormat)
                            .setSampleRate(sampleRate)
                            .setChannelMask(channelOutConfig)
                            .build()
                    )
                    .setBufferSizeInBytes(outBufSize)
                    .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build()
            } else {
                @Suppress("DEPRECATION")
                AudioTrack(
                    AudioManager.STREAM_MUSIC,
                    sampleRate,
                    channelOutConfig,
                    audioFormat,
                    outBufSize,
                    AudioTrack.MODE_STREAM
                )
            }

            audioRecord?.startRecording()
            audioTrack?.play()
            isEngineRunning.set(true)

            startProcessingThread(inBufSize / 2)
            return true
        } catch (e: Exception) {
            e.printStackTrace()
            stopEngine()
            return false
        }
    }

    private fun startProcessingThread(chunkSize: Int) {
        val bufferLength = chunkSize.coerceIn(512, 1024)
        val shortInBuffer = ShortArray(bufferLength)
        val floatBuffer = FloatArray(bufferLength)
        val shortOutBuffer = ShortArray(bufferLength)
        val waveSnapshot = FloatArray(64)

        processingThread = Thread {
            Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)

            var frameCounter = 0

            while (isEngineRunning.get()) {
                val record = audioRecord ?: break
                val read = record.read(shortInBuffer, 0, bufferLength)
                if (read <= 0) continue

                // 1. Convert 16-bit PCM shorts to normalized float [-1.0f .. 1.0f]
                for (i in 0 until read) {
                    floatBuffer[i] = shortInBuffer[i] / 32768.0f
                }

                // 2. Process real-time DSP
                dspProcessor.process(floatBuffer, read)

                // 3. Write to WAV recorder if actively recording
                if (isRecordingActive.get() && !isRecordingPaused.get()) {
                    wavWriter?.writeSamples(floatBuffer, read)
                    val currentDuration = recordingDurationAccMs + (System.currentTimeMillis() - recordingStartTimeMs)
                    _recordingDurationMs.value = currentDuration
                }

                // 4. Low-latency monitoring to headphones
                val isMonitoring = dspProcessor.config.isMonitorEnabled
                val track = audioTrack
                if (isMonitoring && track != null && track.playState == AudioTrack.PLAYSTATE_PLAYING) {
                    for (i in 0 until read) {
                        val s = (floatBuffer[i] * 32767f).toInt().coerceIn(-32768, 32767)
                        shortOutBuffer[i] = s.toShort()
                    }
                    track.write(shortOutBuffer, 0, read)
                }

                // 5. Update UI meters and waveform downsampled (~60 fps)
                frameCounter++
                if (frameCounter % 4 == 0) {
                    _liveRmsLevel.value = dspProcessor.currentRmsLevel
                    _livePeakLevel.value = dspProcessor.currentPeakLevel

                    val step = (read / 64).coerceAtLeast(1)
                    for (w in 0 until 64) {
                        val idx = (w * step).coerceAtMost(read - 1)
                        waveSnapshot[w] = floatBuffer[idx]
                    }
                    _liveWaveform.value = waveSnapshot.copyOf()
                }
            }
        }.apply {
            name = "DD3-AudioDspThread"
            start()
        }
    }

    @Synchronized
    fun startRecording(file: File, bitDepth: BitDepth): Boolean {
        if (!isEngineRunning.get()) {
            if (!startEngine()) return false
        }
        try {
            currentRecordingFile = file
            wavWriter = WavAudioWriter(
                outputFile = file,
                sampleRate = sampleRate,
                bitDepth = bitDepth,
                channels = 1
            )
            recordingStartTimeMs = System.currentTimeMillis()
            recordingDurationAccMs = 0L
            _recordingDurationMs.value = 0L
            isRecordingPaused.set(false)
            isRecordingActive.set(true)
            _recordingState.value = RecordingState.RECORDING
            return true
        } catch (e: Exception) {
            e.printStackTrace()
            return false
        }
    }

    @Synchronized
    fun pauseRecording() {
        if (isRecordingActive.get() && !isRecordingPaused.get()) {
            recordingDurationAccMs += (System.currentTimeMillis() - recordingStartTimeMs)
            isRecordingPaused.set(true)
            _recordingState.value = RecordingState.PAUSED
        }
    }

    @Synchronized
    fun resumeRecording() {
        if (isRecordingActive.get() && isRecordingPaused.get()) {
            recordingStartTimeMs = System.currentTimeMillis()
            isRecordingPaused.set(false)
            _recordingState.value = RecordingState.RECORDING
        }
    }

    @Synchronized
    fun stopRecording(): Long {
        if (!isRecordingActive.get()) return 0L
        isRecordingActive.set(false)
        isRecordingPaused.set(false)
        _recordingState.value = RecordingState.IDLE

        val finalDuration = wavWriter?.close() ?: 0L
        wavWriter = null
        currentRecordingFile = null
        _recordingDurationMs.value = 0L
        return finalDuration
    }

    @Synchronized
    fun stopEngine() {
        isEngineRunning.set(false)
        if (isRecordingActive.get()) {
            stopRecording()
        }
        try {
            processingThread?.join(500)
        } catch (_: InterruptedException) {}
        processingThread = null

        try {
            audioRecord?.stop()
            audioRecord?.release()
        } catch (_: Exception) {}
        audioRecord = null

        try {
            audioTrack?.stop()
            audioTrack?.release()
        } catch (_: Exception) {}
        audioTrack = null

        dspProcessor.reset()
        _liveRmsLevel.value = 0f
        _livePeakLevel.value = 0f
    }
}
