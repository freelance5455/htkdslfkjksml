package com.example.audio.dsp

import com.example.model.BitDepth
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * High-fidelity streaming WAV audio writer supporting 16-bit and 24-bit PCM exports.
 */
class WavAudioWriter(
    private val outputFile: File,
    private val sampleRate: Int = 44100,
    private val bitDepth: BitDepth = BitDepth.BIT_16,
    private val channels: Int = 1
) {
    private var outputStream: BufferedOutputStream? = null
    private var totalBytesWritten: Long = 0
    private var isClosed = false

    init {
        outputStream = BufferedOutputStream(FileOutputStream(outputFile), 64 * 1024)
        writePlaceholderHeader()
    }

    private fun writePlaceholderHeader() {
        val stream = outputStream ?: return
        // 44-byte standard RIFF header with placeholder sizes
        val header = ByteArray(44)
        stream.write(header)
    }

    /**
     * Write normalized float samples [-1.0f .. 1.0f] to WAV file.
     */
    fun writeSamples(samples: FloatArray, count: Int) {
        if (isClosed) return
        val stream = outputStream ?: return

        when (bitDepth) {
            BitDepth.BIT_16 -> {
                val byteBuffer = ByteBuffer.allocate(count * 2).order(ByteOrder.LITTLE_ENDIAN)
                for (i in 0 until count) {
                    val s = (samples[i] * 32767f).toInt().coerceIn(-32768, 32767)
                    byteBuffer.putShort(s.toShort())
                }
                val bytes = byteBuffer.array()
                stream.write(bytes)
                totalBytesWritten += bytes.size
            }

            BitDepth.BIT_24 -> {
                val byteBuffer = ByteBuffer.allocate(count * 3)
                for (i in 0 until count) {
                    val s = (samples[i] * 8388607f).toInt().coerceIn(-8388608, 8388607)
                    // 24-bit PCM Little Endian: 3 bytes
                    byteBuffer.put((s and 0xFF).toByte())
                    byteBuffer.put(((s shr 8) and 0xFF).toByte())
                    byteBuffer.put(((s shr 16) and 0xFF).toByte())
                }
                val bytes = byteBuffer.array()
                stream.write(bytes)
                totalBytesWritten += bytes.size
            }
        }
    }

    /**
     * Finalize WAV header with accurate RIFF data sizes and close streams.
     * @return Duration of recording in milliseconds
     */
    fun close(): Long {
        if (isClosed) return 0L
        isClosed = true

        outputStream?.flush()
        outputStream?.close()
        outputStream = null

        // Update 44-byte WAV header via RandomAccessFile
        val bytesPerSample = bitDepth.bytesPerSample
        val byteRate = sampleRate * channels * bytesPerSample
        val blockAlign = channels * bytesPerSample

        RandomAccessFile(outputFile, "rw").use { raf ->
            raf.seek(0)
            val headerBuffer = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)

            // "RIFF"
            headerBuffer.put('R'.code.toByte())
            headerBuffer.put('I'.code.toByte())
            headerBuffer.put('F'.code.toByte())
            headerBuffer.put('F'.code.toByte())

            // Overall file size - 8
            val overallSize = (totalBytesWritten + 36).toInt()
            headerBuffer.putInt(overallSize)

            // "WAVE"
            headerBuffer.put('W'.code.toByte())
            headerBuffer.put('A'.code.toByte())
            headerBuffer.put('V'.code.toByte())
            headerBuffer.put('E'.code.toByte())

            // "fmt "
            headerBuffer.put('f'.code.toByte())
            headerBuffer.put('m'.code.toByte())
            headerBuffer.put('t'.code.toByte())
            headerBuffer.put(' '.code.toByte())

            // Subchunk1Size = 16 (PCM)
            headerBuffer.putInt(16)
            // AudioFormat = 1 (PCM)
            headerBuffer.putShort(1.toShort())
            // NumChannels
            headerBuffer.putShort(channels.toShort())
            // SampleRate
            headerBuffer.putInt(sampleRate)
            // ByteRate
            headerBuffer.putInt(byteRate)
            // BlockAlign
            headerBuffer.putShort(blockAlign.toShort())
            // BitsPerSample
            headerBuffer.putShort(bitDepth.bits.toShort())

            // "data"
            headerBuffer.put('d'.code.toByte())
            headerBuffer.put('a'.code.toByte())
            headerBuffer.put('t'.code.toByte())
            headerBuffer.put('a'.code.toByte())

            // Subchunk2Size
            headerBuffer.putInt(totalBytesWritten.toInt())

            raf.write(headerBuffer.array())
        }

        val totalSamples = totalBytesWritten / (channels * bytesPerSample)
        return (totalSamples * 1000L) / sampleRate
    }
}
