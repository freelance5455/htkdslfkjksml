package com.example.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Build
import android.os.CombinedVibration
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlin.math.sin

enum class SoundType {
    DIGIT_CLICK,
    OPERATOR_CLICK,
    DIAL_SPIN,
    EQUALS_HERO_TIME,
    CLEAR_RESET,
    ULTIMATE_EVOLVE,
    ERROR_BUZZ
}

class AlienSoundManager(private val context: Context) {
    private val scope = CoroutineScope(Dispatchers.Default)

    private val vibrator: Vibrator? = try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
            vibratorManager?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
    } catch (e: Exception) {
        null
    }

    fun playSoundAndHaptic(soundType: SoundType, soundEnabled: Boolean, hapticEnabled: Boolean) {
        if (hapticEnabled) {
            triggerHaptic(soundType)
        }
        if (soundEnabled) {
            scope.launch {
                synthesizeSound(soundType)
            }
        }
    }

    private fun triggerHaptic(soundType: SoundType) {
        try {
            if (vibrator?.hasVibrator() == true) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    val effect = when (soundType) {
                        SoundType.DIGIT_CLICK -> VibrationEffect.createOneShot(18, 120)
                        SoundType.OPERATOR_CLICK -> VibrationEffect.createOneShot(30, 180)
                        SoundType.DIAL_SPIN -> VibrationEffect.createOneShot(24, 150)
                        SoundType.EQUALS_HERO_TIME -> VibrationEffect.createWaveform(
                            longArrayOf(0, 35, 40, 70),
                            intArrayOf(0, 200, 0, 255),
                            -1
                        )
                        SoundType.ULTIMATE_EVOLVE -> VibrationEffect.createWaveform(
                            longArrayOf(0, 45, 30, 60, 30, 100),
                            intArrayOf(0, 180, 0, 220, 0, 255),
                            -1
                        )
                        SoundType.CLEAR_RESET -> VibrationEffect.createOneShot(45, 160)
                        SoundType.ERROR_BUZZ -> VibrationEffect.createWaveform(
                            longArrayOf(0, 50, 40, 50),
                            intArrayOf(0, 255, 0, 255),
                            -1
                        )
                    }
                    vibrator.vibrate(effect)
                } else {
                    @Suppress("DEPRECATION")
                    vibrator.vibrate(25)
                }
            }
        } catch (_: Exception) {}
    }

    private fun synthesizeSound(soundType: SoundType) {
        try {
            val sampleRate = 22050
            val durationMs = when (soundType) {
                SoundType.DIGIT_CLICK -> 38
                SoundType.OPERATOR_CLICK -> 50
                SoundType.DIAL_SPIN -> 40
                SoundType.EQUALS_HERO_TIME -> 170
                SoundType.ULTIMATE_EVOLVE -> 240
                SoundType.CLEAR_RESET -> 90
                SoundType.ERROR_BUZZ -> 110
            }

            val numSamples = (sampleRate * (durationMs / 1000.0)).toInt().coerceAtLeast(1)
            val audioData = ShortArray(numSamples)

            when (soundType) {
                SoundType.DIGIT_CLICK -> {
                    // Alien digital chirp (rising pitch)
                    for (i in 0 until numSamples) {
                        val progress = i.toDouble() / numSamples
                        val freq = 900.0 + progress * 800.0
                        val angle = 2.0 * Math.PI * i * (freq / sampleRate)
                        val env = (1.0 - progress) * (1.0 - progress)
                        audioData[i] = (sin(angle) * Short.MAX_VALUE * 0.45 * env).toInt().toShort()
                    }
                }
                SoundType.OPERATOR_CLICK -> {
                    // Galvanic metallic blip
                    for (i in 0 until numSamples) {
                        val progress = i.toDouble() / numSamples
                        val freq = 650.0 + sin(progress * Math.PI * 4) * 150.0
                        val angle = 2.0 * Math.PI * i * (freq / sampleRate)
                        val env = (1.0 - progress)
                        audioData[i] = (sin(angle) * Short.MAX_VALUE * 0.55 * env).toInt().toShort()
                    }
                }
                SoundType.DIAL_SPIN -> {
                    // Mechanical ratchet click
                    for (i in 0 until numSamples) {
                        val progress = i.toDouble() / numSamples
                        val freq = 400.0 - progress * 150.0
                        val angle = 2.0 * Math.PI * i * (freq / sampleRate)
                        val env = (1.0 - progress) * 0.8
                        audioData[i] = (sin(angle) * Short.MAX_VALUE * 0.5 * env).toInt().toShort()
                    }
                }
                SoundType.EQUALS_HERO_TIME -> {
                    // Omnitrix Hero Time Laser Zap & Charge (400 -> 1800 -> 900 Hz)
                    for (i in 0 until numSamples) {
                        val progress = i.toDouble() / numSamples
                        val freq = if (progress < 0.6) {
                            400.0 + progress * 2200.0
                        } else {
                            1800.0 - (progress - 0.6) * 1600.0
                        }
                        val angle = 2.0 * Math.PI * i * (freq / sampleRate)
                        val harmonics = sin(angle) * 0.7 + sin(angle * 2.0) * 0.3
                        val env = if (progress < 0.2) progress / 0.2 else (1.0 - progress)
                        audioData[i] = (harmonics * Short.MAX_VALUE * 0.6 * env).toInt().toShort()
                    }
                }
                SoundType.ULTIMATE_EVOLVE -> {
                    // Dramatic Ultimate Alien evolution power-up siren
                    for (i in 0 until numSamples) {
                        val progress = i.toDouble() / numSamples
                        val freq = 320.0 + (progress * progress) * 2400.0
                        val angle = 2.0 * Math.PI * i * (freq / sampleRate)
                        val distortion = if (sin(angle) > 0) 1.0 else -1.0
                        val mixed = sin(angle) * 0.6 + distortion * 0.2
                        val env = if (progress < 0.1) progress / 0.1 else (1.0 - progress)
                        audioData[i] = (mixed * Short.MAX_VALUE * 0.65 * env).toInt().toShort()
                    }
                }
                SoundType.CLEAR_RESET -> {
                    // Descending power down
                    for (i in 0 until numSamples) {
                        val progress = i.toDouble() / numSamples
                        val freq = 750.0 - progress * 500.0
                        val angle = 2.0 * Math.PI * i * (freq / sampleRate)
                        val env = (1.0 - progress)
                        audioData[i] = (sin(angle) * Short.MAX_VALUE * 0.5 * env).toInt().toShort()
                    }
                }
                SoundType.ERROR_BUZZ -> {
                    // Harsh Galvanic overload buzz
                    for (i in 0 until numSamples) {
                        val progress = i.toDouble() / numSamples
                        val freq = 180.0
                        val angle = 2.0 * Math.PI * i * (freq / sampleRate)
                        val square = if (sin(angle) > 0) 1.0 else -1.0
                        val env = (1.0 - progress)
                        audioData[i] = (square * Short.MAX_VALUE * 0.5 * env).toInt().toShort()
                    }
                }
            }

            val bufferSize = AudioTrack.getMinBufferSize(
                sampleRate,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            ).coerceAtLeast(numSamples * 2)

            val audioTrack = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(bufferSize)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()

            audioTrack.write(audioData, 0, audioData.size)
            audioTrack.play()
            // Release after playback
            scope.launch {
                kotlinx.coroutines.delay(durationMs + 50L)
                audioTrack.release()
            }
        } catch (_: Exception) {}
    }
}
