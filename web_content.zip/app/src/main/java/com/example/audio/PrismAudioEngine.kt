package com.example.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.MediaPlayer
import android.media.PlaybackParams
import android.net.Uri
import android.os.Build
import android.util.Log
import com.example.model.EqualizerPreset
import com.example.model.Song
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.sin
import kotlin.random.Random

data class AudioSpectrumData(
    val bands5: FloatArray = FloatArray(5) { 0.5f },
    val bands10: FloatArray = FloatArray(10) { 0.5f },
    val spectrum32: FloatArray = FloatArray(32) { 0.3f },
    val waveform64: FloatArray = FloatArray(64) { 0.0f },
    val beatEnergy: Float = 0f,
    val bassImpact: Float = 0f,
    val trebleSparkle: Float = 0f,
    val phase: Float = 0f,
    val rmsLevel: Float = 0.5f
)

class PrismAudioEngine(private val context: Context) {

    private val scope = CoroutineScope(Dispatchers.Default)

    private var mediaPlayer: MediaPlayer? = null
    private var synthTrack: AudioTrack? = null
    private var synthJob: Job? = null
    private var telemetryJob: Job? = null

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying = _isPlaying.asStateFlow()

    private val _currentPositionSec = MutableStateFlow(0f)
    val currentPositionSec = _currentPositionSec.asStateFlow()

    private val _spectrumData = MutableStateFlow(AudioSpectrumData())
    val spectrumData = _spectrumData.asStateFlow()

    private var currentSong: Song? = null
    private var currentEq: EqualizerPreset? = null

    private var sampleRate = 44100
    private var timeSeconds = 0.0
    private var beatPhase = 0.0

    init {
        startTelemetryLoop()
    }

    fun playSong(song: Song, eq: EqualizerPreset) {
        currentSong = song
        currentEq = eq
        timeSeconds = 0.0
        _currentPositionSec.value = 0f
        stopCurrentPlayback()

        if (song.audioUri != null) {
            playFromUri(song.audioUri)
        } else {
            playProceduralTrack(song)
        }
        _isPlaying.value = true
    }

    fun pause() {
        _isPlaying.value = false
        mediaPlayer?.let {
            if (it.isPlaying) it.pause()
        }
        try {
            synthTrack?.pause()
        } catch (e: Exception) {}
    }

    fun resume() {
        if (currentSong == null) return
        _isPlaying.value = true
        mediaPlayer?.let {
            it.start()
        } ?: run {
            if (synthTrack != null && synthJob?.isActive == true) {
                try {
                    synthTrack?.play()
                } catch (e: Exception) {}
            } else {
                currentSong?.let { playProceduralTrack(it) }
            }
        }
    }

    fun seekTo(seconds: Float) {
        val songDuration = (currentSong?.durationSec ?: 240).toFloat()
        val targetSec = seconds.coerceIn(0f, songDuration)
        _currentPositionSec.value = targetSec
        timeSeconds = targetSec.toDouble()

        if (mediaPlayer != null) {
            try {
                mediaPlayer?.seekTo((targetSec * 1000).toInt())
            } catch (e: Exception) {
                Log.e("AudioEngine", "Error seeking", e)
            }
        } else {
            try {
                synthTrack?.pause()
                synthTrack?.flush()
                if (_isPlaying.value) {
                    synthTrack?.play()
                }
            } catch (e: Exception) {}
        }
    }

    fun seekTo(seconds: Int) {
        seekTo(seconds.toFloat())
    }

    fun updateEqualizer(eq: EqualizerPreset) {
        currentEq = eq
        applyTempo(eq.tempo)
    }

    private fun applyTempo(tempo: Float) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            mediaPlayer?.let {
                try {
                    val safeTempo = tempo.coerceIn(0.5f, 2.0f)
                    val params = it.playbackParams
                    params.speed = safeTempo
                    it.playbackParams = params
                } catch (e: Exception) {
                    Log.w("AudioEngine", "Unable to set playback tempo", e)
                }
            }
        }
    }

    private fun playFromUri(uriString: String) {
        try {
            val uri = Uri.parse(uriString)
            mediaPlayer = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .build()
                )
                setDataSource(context, uri)
                prepare()
                start()
                setOnCompletionListener {
                    _isPlaying.value = false
                }
            }
            currentEq?.let { applyTempo(it.tempo) }
        } catch (e: Exception) {
            Log.e("AudioEngine", "Failed to play URI $uriString, falling back to synth", e)
            currentSong?.let { playProceduralTrack(it) }
        }
    }

    private fun playProceduralTrack(song: Song) {
        stopSynthAudio()
        val minBufferSize = AudioTrack.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        val bufferSize = minBufferSize.coerceAtLeast(4096)

        try {
            synthTrack = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(bufferSize)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()

            synthTrack?.play()
        } catch (e: Exception) {
            Log.e("AudioEngine", "AudioTrack init error", e)
            return
        }

        val baseFrequencies = when (song.genre.lowercase()) {
            "synthwave", "electronic" -> doubleArrayOf(110.0, 220.0, 330.0, 440.0) // A minor chords
            "jazz", "lo-fi" -> doubleArrayOf(130.81, 164.81, 196.0, 246.94) // Cmaj7
            "rock", "metal" -> doubleArrayOf(82.41, 123.47, 164.81, 329.63) // E power chords
            "classical" -> doubleArrayOf(146.83, 174.61, 220.0, 293.66) // D minor
            else -> doubleArrayOf(130.81, 164.81, 196.0, 261.63) // C major
        }

        synthJob = scope.launch {
            val audioBuffer = ShortArray(1024)
            val bpm = song.bpm.toDouble().coerceIn(60.0, 160.0)
            val beatIntervalSec = 60.0 / bpm
            val songDuration = song.durationSec.toDouble().coerceAtLeast(10.0)

            while (isActive) {
                if (!_isPlaying.value) {
                    delay(30)
                    continue
                }

                if (timeSeconds >= songDuration) {
                    timeSeconds = 0.0
                }
                val eq = currentEq
                // Compute Poweramp DSP factors: 10 bands + Tone Knobs + Preamp
                val preampMultiplier = Math.pow(10.0, ((eq?.preampDb ?: 0f) / 20.0).toDouble())
                val bassKnobBoost = (eq?.bassTone ?: 0f) / 10.0 * 0.4
                val trebleKnobBoost = (eq?.trebleTone ?: 0f) / 10.0 * 0.4

                val subBassGain = (1.0 + (eq?.band31Hz ?: 0f) / 12.0 * 0.4 + (eq?.band62Hz ?: 0f) / 12.0 * 0.3 + (eq?.bassBoost ?: 0f) / 100.0 * 0.3 + bassKnobBoost).coerceAtLeast(0.1)
                val trebleGain = (1.0 + (eq?.band8kHz ?: 0f) / 12.0 * 0.3 + (eq?.band16kHz ?: 0f) / 12.0 * 0.4 + trebleKnobBoost).coerceAtLeast(0.1)

                val tempoFactor = (eq?.tempo ?: 1.0f).toDouble().coerceIn(0.5, 2.0)
                val effectiveBeatInterval = beatIntervalSec / tempoFactor

                val beatTime = timeSeconds % effectiveBeatInterval
                val isKick = beatTime < (0.12 / tempoFactor)
                val isSnare = (timeSeconds % (effectiveBeatInterval * 2)) in (effectiveBeatInterval * 0.95)..(effectiveBeatInterval * 1.15)

                for (i in audioBuffer.indices) {
                    val t = timeSeconds + (i.toDouble() / sampleRate) * tempoFactor

                    val chordStep = ((t / (effectiveBeatInterval * 2)).toInt()) % baseFrequencies.size
                    val baseFreq = baseFrequencies[chordStep]

                    // Sub-bass sine
                    val bassWave = sin(2.0 * PI * (baseFreq * 0.5) * t) * 0.35 * subBassGain

                    // Arp melodic synth
                    val arpOctave = if (((t * 4) % 1.0) > 0.5) 2.0 else 1.0
                    val melodyFreq = baseFreq * arpOctave
                    val melodyWave = (sin(2.0 * PI * melodyFreq * t) + 0.3 * sin(4.0 * PI * melodyFreq * t)) * 0.22

                    // Kick drum thud
                    val kick = if (isKick) {
                        val env = (1.0 - (beatTime / (0.12 / tempoFactor))).coerceIn(0.0, 1.0)
                        sin(2.0 * PI * (55.0 + 80.0 * env) * t) * env * 0.5 * subBassGain
                    } else 0.0

                    // Hi-hat/snare noise burst
                    val snare = if (isSnare) {
                        (Random.nextDouble() * 2.0 - 1.0) * 0.15 * trebleGain
                    } else if ((t % (effectiveBeatInterval / 2.0)) < 0.03) {
                        (Random.nextDouble() * 2.0 - 1.0) * 0.07 * trebleGain
                    } else 0.0

                    var sampleSum = (bassWave + melodyWave + kick + snare) * preampMultiplier

                    // Poweramp Limiter protection
                    if (eq?.limiterEnabled != false) {
                        sampleSum = sampleSum.coerceIn(-0.95, 0.95)
                    } else {
                        // Soft saturation
                        sampleSum = Math.tanh(sampleSum)
                    }

                    audioBuffer[i] = (sampleSum * 32767.0).toInt().toShort()
                }

                timeSeconds += (audioBuffer.size.toDouble() / sampleRate) * tempoFactor
                try {
                    synthTrack?.write(audioBuffer, 0, audioBuffer.size)
                } catch (e: Exception) {
                    break
                }
            }
        }
    }

    private fun startTelemetryLoop() {
        telemetryJob = scope.launch {
            var simTime = 0.0
            while (isActive) {
                if (_isPlaying.value) {
                    simTime += 0.02
                    beatPhase += 0.08

                    val songDuration = currentSong?.durationSec ?: 240
                    if (mediaPlayer != null) {
                        try {
                            _currentPositionSec.value = (mediaPlayer!!.currentPosition / 1000f).coerceAtMost(songDuration.toFloat())
                        } catch (e: Exception) {}
                    } else {
                        // In procedural synthesis, timeSeconds tracks exact audio stream progression
                        val elapsed = (timeSeconds % songDuration.toDouble()).toFloat()
                        _currentPositionSec.value = elapsed
                    }

                    val eq = currentEq
                    val b31 = (eq?.band31Hz ?: 0f)
                    val b62 = (eq?.band62Hz ?: 0f)
                    val b125 = (eq?.band125Hz ?: 0f)
                    val b250 = (eq?.band250Hz ?: 0f)
                    val b500 = (eq?.band500Hz ?: 0f)
                    val b1k = (eq?.band1kHz ?: 0f)
                    val b2k = (eq?.band2kHz ?: 0f)
                    val b4k = (eq?.band4kHz ?: 0f)
                    val b8k = (eq?.band8kHz ?: 0f)
                    val b16k = (eq?.band16kHz ?: 0f)
                    val bassKnob = (eq?.bassTone ?: 0f) / 10f
                    val trebleKnob = (eq?.trebleTone ?: 0f) / 10f
                    val bassBoost = (eq?.bassBoost ?: 0f) / 100f

                    val kickImpact = ((sin(beatPhase * 1.5) + 1.0) * 0.5).toFloat()
                    val bassVal = ((0.4f + 0.5f * kickImpact) * (1f + (b31 + b62) / 48f + bassBoost * 0.4f + bassKnob * 0.3f)).coerceIn(0.05f, 1f)
                    val lowMid = ((0.35f + 0.3f * sin(simTime * 2.3).toFloat()) * (1f + (b125 + b250) / 48f)).coerceIn(0.05f, 1f)
                    val mid = ((0.45f + 0.35f * sin(simTime * 3.7 + 1.0).toFloat()) * (1f + (b500 + b1k) / 48f)).coerceIn(0.05f, 1f)
                    val highMid = ((0.4f + 0.3f * sin(simTime * 5.1 + 2.0).toFloat()) * (1f + (b2k + b4k) / 48f)).coerceIn(0.05f, 1f)
                    val treble = ((0.3f + 0.4f * sin(simTime * 7.5 + 3.0).toFloat()) * (1f + (b8k + b16k) / 48f + trebleKnob * 0.3f)).coerceIn(0.05f, 1f)

                    val bands5 = floatArrayOf(bassVal, lowMid, mid, highMid, treble)

                    // 10 bands normalized
                    val bands10 = FloatArray(10) { idx ->
                        val base = when (idx) {
                            0 -> bassVal * 1.05f + (b31 / 24f)
                            1 -> bassVal + (b62 / 24f)
                            2 -> lowMid * 1.1f + (b125 / 24f)
                            3 -> lowMid + (b250 / 24f)
                            4 -> mid * 0.95f + (b500 / 24f)
                            5 -> mid + (b1k / 24f)
                            6 -> highMid * 0.95f + (b2k / 24f)
                            7 -> highMid + (b4k / 24f)
                            8 -> treble * 0.95f + (b8k / 24f)
                            else -> treble + (b16k / 24f)
                        }
                        base.coerceIn(0.05f, 1.0f)
                    }

                    val spectrum32 = FloatArray(32) { i ->
                        val freqFactor = when {
                            i < 6 -> bassVal * (1.1f - i * 0.05f)
                            i < 14 -> lowMid * 0.9f + mid * 0.3f
                            i < 22 -> mid * 0.8f + highMid * 0.4f
                            else -> treble * 0.9f
                        }
                        val noise = (sin(simTime * 4.0 + i * 0.6).toFloat() * 0.15f)
                        (freqFactor + noise).coerceIn(0.03f, 1.0f)
                    }

                    val waveform64 = FloatArray(64) { i ->
                        val phase = (i.toFloat() / 64f) * 4f * PI.toFloat() + simTime.toFloat() * 3f
                        val wave = (sin(phase) * 0.5f + sin(phase * 2f + 1f) * 0.25f + sin(phase * 3.5f) * 0.15f) * (bassVal * 0.7f + mid * 0.3f)
                        wave.coerceIn(-1f, 1f)
                    }

                    val rms = ((bassVal * 0.4f + mid * 0.4f + treble * 0.2f)).coerceIn(0.1f, 1.0f)

                    _spectrumData.value = AudioSpectrumData(
                        bands5 = bands5,
                        bands10 = bands10,
                        spectrum32 = spectrum32,
                        waveform64 = waveform64,
                        beatEnergy = kickImpact,
                        bassImpact = bassVal,
                        trebleSparkle = treble,
                        phase = (simTime % (2.0 * PI)).toFloat(),
                        rmsLevel = rms
                    )
                } else {
                    val current = _spectrumData.value
                    _spectrumData.value = current.copy(
                        bands5 = FloatArray(5) { (current.bands5[it] * 0.9f).coerceAtLeast(0.02f) },
                        bands10 = FloatArray(10) { (current.bands10[it] * 0.9f).coerceAtLeast(0.02f) },
                        spectrum32 = FloatArray(32) { (current.spectrum32[it] * 0.9f).coerceAtLeast(0.02f) },
                        waveform64 = FloatArray(64) { (current.waveform64[it] * 0.85f) },
                        beatEnergy = current.beatEnergy * 0.85f,
                        bassImpact = current.bassImpact * 0.85f,
                        trebleSparkle = current.trebleSparkle * 0.85f,
                        rmsLevel = current.rmsLevel * 0.85f
                    )
                }
                delay(16)
            }
        }
    }

    private fun stopCurrentPlayback() {
        try {
            mediaPlayer?.let {
                if (it.isPlaying) it.stop()
                it.release()
            }
            mediaPlayer = null
        } catch (e: Exception) {}
        stopSynthAudio()
    }

    private fun stopSynthAudio() {
        synthJob?.cancel()
        synthJob = null
        try {
            synthTrack?.stop()
            synthTrack?.release()
            synthTrack = null
        } catch (e: Exception) {}
    }

    fun release() {
        stopCurrentPlayback()
        telemetryJob?.cancel()
    }
}
