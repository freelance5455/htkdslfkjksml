package com.example.audio.dsp

import com.example.model.ReverbType

/**
 * High-quality algorithmic reverb using tuned comb filters and all-pass diffusers
 * inspired by the Freeverb/Schroeder architecture, tailored for vocal acoustics.
 */
class SchroederReverb(sampleRate: Int = 44100) {

    // Base delay lengths in samples for 44100Hz
    private val scale = sampleRate / 44100f
    private val combLengths = intArrayOf(
        (1116 * scale).toInt(),
        (1188 * scale).toInt(),
        (1277 * scale).toInt(),
        (1356 * scale).toInt(),
        (1422 * scale).toInt(),
        (1491 * scale).toInt(),
        (1557 * scale).toInt(),
        (1617 * scale).toInt()
    )

    private val allpassLengths = intArrayOf(
        (556 * scale).toInt(),
        (441 * scale).toInt(),
        (341 * scale).toInt(),
        (225 * scale).toInt()
    )

    private class CombFilter(val size: Int) {
        val buffer = FloatArray(size)
        var index = 0
        var filterStore = 0f

        fun process(input: Float, feedback: Float, damp: Float): Float {
            val output = buffer[index]
            filterStore = (output * (1f - damp)) + (filterStore * damp)
            buffer[index] = input + (filterStore * feedback)
            index = (index + 1) % size
            return output
        }

        fun clear() {
            buffer.fill(0f)
            index = 0
            filterStore = 0f
        }
    }

    private class AllPassFilter(val size: Int) {
        val buffer = FloatArray(size)
        var index = 0
        val feedback = 0.5f

        fun process(input: Float): Float {
            val bufOut = buffer[index]
            val output = -input + bufOut
            buffer[index] = input + (bufOut * feedback)
            index = (index + 1) % size
            return output
        }

        fun clear() {
            buffer.fill(0f)
            index = 0
        }
    }

    private val combs = combLengths.map { CombFilter(it) }
    private val allpasses = allpassLengths.map { AllPassFilter(it) }

    fun clear() {
        combs.forEach { it.clear() }
        allpasses.forEach { it.clear() }
    }

    /**
     * Process a single audio sample through the reverb network.
     */
    fun process(input: Float, type: ReverbType, decay: Float): Float {
        if (type == ReverbType.OFF) return 0f

        val (roomSize, damp) = when (type) {
            ReverbType.OFF -> Pair(0f, 0f)
            ReverbType.STUDIO_ROOM -> Pair(0.65f * decay, 0.40f)
            ReverbType.SACRED_HALL -> Pair(0.82f * decay, 0.28f)
            ReverbType.GRAND_MASJID -> Pair(0.92f * decay, 0.20f)
        }

        val feedback = roomSize.coerceIn(0.1f, 0.94f)
        val damping = damp.coerceIn(0.1f, 0.8f)

        // Sum parallel comb outputs
        var sum = 0f
        for (comb in combs) {
            sum += comb.process(input, feedback, damping)
        }
        sum *= 0.125f // Scale down

        // Pass through series allpass diffusers
        var out = sum
        for (allpass in allpasses) {
            out = allpass.process(out)
        }

        return out
    }
}
