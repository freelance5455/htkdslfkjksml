package com.example.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.MediaPlayer
import android.util.Log
import com.example.R
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

/**
 * SufiSoundManager:
 * 1. Looping Ambient Sufi Vocal & Ney Meditation Music (Autoplays on app launch)
 *    Plays the contemplative Sufi ambient piece from R.raw.sufi_ambient via MediaPlayer.
 * 2. Pure In-Memory PCM Low-Latency Sound Effects (AudioTrack Static Buffers):
 *    - Mystical glittering / twinkling shimmer when clicking "SUFI SAYS"
 *    - Qalam reed pen whispering across ancient parchment
 *    - Soft button click
 *    - Meditative singing bowl / chime
 *    - Tasbeeh prayer bead click
 *
 * Using direct in-memory AudioTrack static buffers avoids OMX/MediaCodec hardware interface
 * queries and eliminates disk I/O completely.
 */
class SufiSoundManager(private val context: Context) {

    private val scope = CoroutineScope(Dispatchers.Default + Job())

    private val _isMuted = MutableStateFlow(false)
    val isMuted: StateFlow<Boolean> = _isMuted.asStateFlow()

    private val prefs = context.getSharedPreferences("sufi_sound_prefs", Context.MODE_PRIVATE)

    // In-memory AudioTrack static buffer players
    @Volatile private var trackTwinkle: AudioTrack? = null
    @Volatile private var trackPenGlide: AudioTrack? = null
    @Volatile private var trackSoftClick: AudioTrack? = null
    @Volatile private var trackChime: AudioTrack? = null
    @Volatile private var trackBead: AudioTrack? = null

    // Ambient loop player using MediaPlayer for optimal hardware decoding and seamless looping
    @Volatile
    private var mediaPlayer: MediaPlayer? = null
    @Volatile
    private var isAmbientPlaying = false

    init {
        _isMuted.value = prefs.getBoolean("is_muted", false)

        initSoundEffects()

        // Autoplay looping ambient background music on app launch
        if (!_isMuted.value) {
            startAmbientLoop()
        }
    }

    private fun initSoundEffects() {
        scope.launch {
            try {
                val sampleRate = 44100

                // Precompute all sound effects in memory
                val pcmTwinkle = generateTwinklePcm(sampleRate, durationMs = 1200)
                val pcmPen = generatePenGlidePcm(sampleRate, durationMs = 1000)
                val pcmClick = generateSoftClickPcm(sampleRate, durationMs = 120)
                val pcmChime = generateChimePcm(sampleRate, durationMs = 1400)
                val pcmBead = generateBeadPcm(sampleRate, durationMs = 120)

                trackTwinkle = createStaticTrack(pcmTwinkle, sampleRate, volume = 0.85f)
                trackPenGlide = createStaticTrack(pcmPen, sampleRate, volume = 0.70f)
                trackSoftClick = createStaticTrack(pcmClick, sampleRate, volume = 0.50f)
                trackChime = createStaticTrack(pcmChime, sampleRate, volume = 0.75f)
                trackBead = createStaticTrack(pcmBead, sampleRate, volume = 0.65f)
            } catch (e: CancellationException) {
                // Ignore normal cancellation
            } catch (e: Exception) {
                Log.e("SufiSoundManager", "Error initializing audio effects", e)
            }
        }
    }

    private fun createStaticTrack(pcmData: ByteArray, sampleRate: Int, volume: Float): AudioTrack? {
        return try {
            val audioAttributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()

            val audioFormat = AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(sampleRate)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                .build()

            val track = AudioTrack.Builder()
                .setAudioAttributes(audioAttributes)
                .setAudioFormat(audioFormat)
                .setBufferSizeInBytes(pcmData.size)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()

            track.setVolume(volume)
            val written = track.write(pcmData, 0, pcmData.size)
            if (written >= 0) track else null
        } catch (e: Exception) {
            Log.e("SufiSoundManager", "Failed to create static AudioTrack", e)
            null
        }
    }

    private fun playStaticTrack(track: AudioTrack?) {
        if (_isMuted.value || track == null) return
        try {
            if (track.state == AudioTrack.STATE_INITIALIZED) {
                track.stop()
                track.reloadStaticData()
                track.play()
            }
        } catch (e: Exception) {
            // ignore
        }
    }

    fun playTwinkle() {
        playStaticTrack(trackTwinkle)
    }

    fun playPenGlide() {
        playStaticTrack(trackPenGlide)
    }

    fun playSoftClick() {
        playStaticTrack(trackSoftClick)
    }

    fun playWisdomChime() {
        playStaticTrack(trackChime)
    }

    fun playTasbeehBead() {
        playStaticTrack(trackBead)
    }

    fun toggleMute() {
        val newMute = !_isMuted.value
        _isMuted.value = newMute
        prefs.edit().putBoolean("is_muted", newMute).apply()
        if (newMute) {
            stopAmbient()
        } else {
            startAmbientLoop()
        }
    }

    @Synchronized
    fun startAmbientLoop() {
        if (_isMuted.value) return
        try {
            if (mediaPlayer == null) {
                val mp = MediaPlayer.create(context, R.raw.sufi_ambient)
                if (mp != null) {
                    mp.isLooping = true
                    mp.setVolume(0.85f, 0.85f)
                    mp.setOnErrorListener { _, what, extra ->
                        Log.w("SufiSoundManager", "MediaPlayer error: what=$what extra=$extra")
                        true
                    }
                    mediaPlayer = mp
                }
            }
            mediaPlayer?.let { mp ->
                if (!mp.isPlaying) {
                    mp.start()
                    isAmbientPlaying = true
                }
            }
        } catch (e: Exception) {
            Log.e("SufiSoundManager", "Error starting ambient media player", e)
        }
    }

    @Synchronized
    fun stopAmbient() {
        isAmbientPlaying = false
        try {
            mediaPlayer?.let { mp ->
                if (mp.isPlaying) {
                    mp.pause()
                }
            }
        } catch (e: Exception) {
            Log.e("SufiSoundManager", "Error stopping ambient player", e)
        }
    }

    fun release() {
        stopAmbient()
        try {
            mediaPlayer?.release()
            mediaPlayer = null
        } catch (e: Exception) {
            // ignore
        }
        
        listOf(trackTwinkle, trackPenGlide, trackSoftClick, trackChime, trackBead).forEach { track ->
            try {
                track?.stop()
                track?.release()
            } catch (e: Exception) {
                // ignore
            }
        }
        trackTwinkle = null
        trackPenGlide = null
        trackSoftClick = null
        trackChime = null
        trackBead = null
    }

    // --- PCM Sound Synthesizers (Fast In-Memory Math) ---

    private fun generateTwinklePcm(sampleRate: Int, durationMs: Int): ByteArray {
        val totalSamples = (sampleRate * (durationMs / 1000.0)).toInt()
        val pcm = ShortArray(totalSamples)
        val frequencies = doubleArrayOf(587.33, 659.25, 783.99, 880.0, 1046.50, 1174.66, 1318.51, 1567.98)

        for (i in 0 until totalSamples) {
            val t = i.toDouble() / sampleRate
            var sample = 0.0

            for ((idx, freq) in frequencies.withIndex()) {
                val delaySec = idx * 0.08
                if (t >= delaySec) {
                    val noteT = t - delaySec
                    val env = exp(-noteT * 6.0)
                    val shimmer = 1.0 + 0.15 * sin(2 * PI * 18.0 * noteT)
                    sample += sin(2 * PI * freq * noteT) * env * shimmer * 0.18
                }
            }

            pcm[i] = (sample.coerceIn(-1.0, 1.0) * Short.MAX_VALUE).toInt().toShort()
        }
        return shortArrayToByteArray(pcm)
    }

    private fun generatePenGlidePcm(sampleRate: Int, durationMs: Int): ByteArray {
        val totalSamples = (sampleRate * (durationMs / 1000.0)).toInt()
        val pcm = ShortArray(totalSamples)
        var lastRandom = 0.0

        for (i in 0 until totalSamples) {
            val t = i.toDouble() / sampleRate
            val envelope = sin(PI * (t / (durationMs / 1000.0))).coerceIn(0.0, 1.0)
            val whiteNoise = (Math.random() * 2.0 - 1.0)
            lastRandom = lastRandom * 0.85 + whiteNoise * 0.15
            val woodResonance = sin(2 * PI * 340.0 * t) * 0.12
            val sample = (lastRandom * 0.65 + woodResonance) * envelope * 0.35
            pcm[i] = (sample.coerceIn(-1.0, 1.0) * Short.MAX_VALUE).toInt().toShort()
        }
        return shortArrayToByteArray(pcm)
    }

    private fun generateSoftClickPcm(sampleRate: Int, durationMs: Int): ByteArray {
        val totalSamples = (sampleRate * (durationMs / 1000.0)).toInt()
        val pcm = ShortArray(totalSamples)

        for (i in 0 until totalSamples) {
            val t = i.toDouble() / sampleRate
            val env = exp(-t * 35.0)
            val sample = sin(2 * PI * 220.0 * t) * env * 0.45
            pcm[i] = (sample.coerceIn(-1.0, 1.0) * Short.MAX_VALUE).toInt().toShort()
        }
        return shortArrayToByteArray(pcm)
    }

    private fun generateChimePcm(sampleRate: Int, durationMs: Int): ByteArray {
        val totalSamples = (sampleRate * (durationMs / 1000.0)).toInt()
        val pcm = ShortArray(totalSamples)
        val f0 = 528.0

        for (i in 0 until totalSamples) {
            val t = i.toDouble() / sampleRate
            val env = exp(-t * 2.8)
            val harmonic1 = sin(2 * PI * f0 * t)
            val harmonic2 = sin(2 * PI * f0 * 2.02 * t) * 0.3
            val harmonic3 = sin(2 * PI * f0 * 3.01 * t) * 0.15

            val sample = (harmonic1 + harmonic2 + harmonic3) * env * 0.45
            pcm[i] = (sample.coerceIn(-1.0, 1.0) * Short.MAX_VALUE).toInt().toShort()
        }
        return shortArrayToByteArray(pcm)
    }

    private fun generateBeadPcm(sampleRate: Int, durationMs: Int): ByteArray {
        val totalSamples = (sampleRate * (durationMs / 1000.0)).toInt()
        val pcm = ShortArray(totalSamples)
        for (i in 0 until totalSamples) {
            val t = i.toDouble() / sampleRate
            val env = exp(-t * 40.0)
            val tone = sin(2 * PI * 480.0 * t) + 0.3 * sin(2 * PI * 960.0 * t)
            val sample = tone * env * 0.40
            pcm[i] = (sample.coerceIn(-1.0, 1.0) * Short.MAX_VALUE).toInt().toShort()
        }
        return shortArrayToByteArray(pcm)
    }

    private fun shortArrayToByteArray(shortArray: ShortArray): ByteArray {
        val byteArray = ByteArray(shortArray.size * 2)
        for (i in shortArray.indices) {
            val short = shortArray[i].toInt()
            byteArray[i * 2] = (short and 0x00FF).toByte()
            byteArray[i * 2 + 1] = ((short shr 8) and 0x00FF).toByte()
        }
        return byteArray
    }
}
