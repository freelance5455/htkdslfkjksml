package com.example.audio.dsp

import kotlin.math.floor

/**
 * High-performance circular delay line with fractional interpolation
 * and one-pole low-pass feedback damping for classic analog warmth.
 */
class DelayLine(maxDelaySeconds: Float = 1.5f, private val sampleRate: Int = 44100) {
    private val bufferSize: Int = (maxDelaySeconds * sampleRate).toInt() + 1024
    private val buffer: FloatArray = FloatArray(bufferSize)
    private var writeIndex: Int = 0

    // Filter memory for feedback loop damping
    private var filterMemory: Float = 0f

    fun clear() {
        buffer.fill(0f)
        writeIndex = 0
        filterMemory = 0f
    }

    /**
     * Process a single audio sample with delay, feedback, and tone damping.
     * @param input Direct input sample
     * @param delayMs Current delay time in milliseconds
     * @param feedback Feedback ratio (0.0 .. 0.92)
     * @param toneDamp 0.0 (maximum warmth/low-pass) .. 1.0 (bright)
     * @return The delayed wet echo sample
     */
    fun process(input: Float, delayMs: Int, feedback: Float, toneDamp: Float): Float {
        val delaySamples = (delayMs * sampleRate / 1000f).coerceIn(1f, (bufferSize - 10).toFloat())

        // Fractional delay calculation
        var readPos = writeIndex - delaySamples
        while (readPos < 0) {
            readPos += bufferSize
        }

        val i1 = floor(readPos).toInt() % bufferSize
        val i2 = (i1 + 1) % bufferSize
        val frac = readPos - floor(readPos)

        // Linear interpolation for smooth delay transitions
        val delayedSample = buffer[i1] * (1f - frac) + buffer[i2] * frac

        // One-pole low-pass filter on feedback path
        // High toneDamp = higher cutoff (brighter), low toneDamp = warmer, soft decay
        val alpha = (0.15f + 0.75f * toneDamp.coerceIn(0f, 1f))
        filterMemory = filterMemory + alpha * (delayedSample - filterMemory)
        val filteredFeedback = filterMemory * feedback.coerceIn(0f, 0.95f)

        // Write input + dampened feedback into circular buffer
        buffer[writeIndex] = input + filteredFeedback

        writeIndex = (writeIndex + 1) % bufferSize
        return delayedSample
    }
}
