package com.example.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.sin
import kotlin.random.Random

enum class AmbientSound(val label: String, val icon: String) {
    NONE("Silent", "🔇"),
    WHITE_NOISE("Soft Rain", "🌧️"),
    FOCUS_DRONE("Alpha Waves", "🧘"),
    CAFE_BUZZ("Cafe Ambience", "☕")
}

class SoundAndHapticsHelper(private val context: Context) {

    private val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
        vibratorManager?.defaultVibrator
    } else {
        @Suppress("DEPRECATION")
        context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    }

    private var ambientTrack: AudioTrack? = null
    private var ambientJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Default)

    /**
     * Gentle celebration vibration pattern for Pomodoro or break completion
     */
    fun triggerCompletionVibration() {
        try {
            if (vibrator?.hasVibrator() == true) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    val timings = longArrayOf(0, 200, 150, 300)
                    val amplitudes = intArrayOf(0, 180, 0, 255)
                    vibrator.vibrate(VibrationEffect.createWaveform(timings, amplitudes, -1))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator.vibrate(longArrayOf(0, 200, 150, 300), -1)
                }
            }
        } catch (_: Exception) {
            // Ignore on devices without vibrator or restricted
        }
    }

    /**
     * Subtle tap haptic for start/pause/button clicks
     */
    fun triggerTickHaptic() {
        try {
            if (vibrator?.hasVibrator() == true) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator.vibrate(VibrationEffect.createOneShot(25, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator.vibrate(25)
                }
            }
        } catch (_: Exception) {
            // Ignore
        }
    }

    /**
     * Plays a pleasant harmonic completion chime (A5 chord: 880Hz + 1100Hz + 1320Hz with decay)
     */
    fun playCompletionChime() {
        scope.launch {
            try {
                val sampleRate = 44100
                val durationMs = 1200
                val numSamples = (durationMs * sampleRate) / 1000
                val samples = ShortArray(numSamples)

                val freq1 = 880.0
                val freq2 = 1108.73 // C#6
                val freq3 = 1318.51 // E6

                for (i in 0 until numSamples) {
                    val t = i.toDouble() / sampleRate
                    // Exponential decay envelope
                    val envelope = kotlin.math.exp(-3.5 * (i.toDouble() / numSamples))
                    val wave = 0.5 * sin(2 * Math.PI * freq1 * t) +
                            0.3 * sin(2 * Math.PI * freq2 * t) +
                            0.2 * sin(2 * Math.PI * freq3 * t)
                    samples[i] = (wave * envelope * Short.MAX_VALUE * 0.7).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
                }

                val track = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(samples.size * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()

                track.write(samples, 0, samples.size)
                track.play()
                delay(durationMs.toLong() + 200)
                track.release()
            } catch (_: Exception) {
                // Ignore audio play errors
            }
        }
    }

    /**
     * Start ambient study focus sound
     */
    fun setAmbientSound(ambient: AmbientSound) {
        stopAmbientSound()
        if (ambient == AmbientSound.NONE) return

        ambientJob = scope.launch {
            try {
                val sampleRate = 22050
                val bufferSize = AudioTrack.getMinBufferSize(
                    sampleRate,
                    AudioFormat.CHANNEL_OUT_MONO,
                    AudioFormat.ENCODING_PCM_16BIT
                ) * 2

                val track = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(bufferSize)
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build()

                ambientTrack = track
                track.play()

                val buffer = ShortArray(bufferSize / 2)
                var phase1 = 0.0
                var phase2 = 0.0
                var lastVal = 0.0

                while (isActive) {
                    when (ambient) {
                        AmbientSound.WHITE_NOISE -> {
                            // Pink / Brown gentle rain filter
                            for (i in buffer.indices) {
                                val white = Random.nextDouble(-1.0, 1.0)
                                lastVal = (lastVal + (0.04 * white)) / 1.04
                                val rainDrop = if (Random.nextDouble() < 0.003) Random.nextDouble(-0.3, 0.3) else 0.0
                                val sample = ((lastVal * 2.5 + rainDrop) * Short.MAX_VALUE * 0.15).toInt()
                                buffer[i] = sample.coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
                            }
                        }
                        AmbientSound.FOCUS_DRONE -> {
                            // Binaural alpha focus drone (216Hz + 226Hz, 10Hz beat)
                            val step1 = 2 * Math.PI * 216.0 / sampleRate
                            val step2 = 2 * Math.PI * 226.0 / sampleRate
                            for (i in buffer.indices) {
                                phase1 += step1
                                phase2 += step2
                                val wave = (0.5 * sin(phase1) + 0.5 * sin(phase2))
                                val sample = (wave * Short.MAX_VALUE * 0.12).toInt()
                                buffer[i] = sample.coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
                            }
                        }
                        AmbientSound.CAFE_BUZZ -> {
                            // Warm filtered brown noise with gentle hum
                            val humStep = 2 * Math.PI * 120.0 / sampleRate
                            for (i in buffer.indices) {
                                phase1 += humStep
                                val white = Random.nextDouble(-1.0, 1.0)
                                lastVal = (lastVal + (0.02 * white)) / 1.02
                                val sample = ((lastVal * 2.0 + 0.15 * sin(phase1)) * Short.MAX_VALUE * 0.14).toInt()
                                buffer[i] = sample.coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
                            }
                        }
                        AmbientSound.NONE -> break
                    }

                    track.write(buffer, 0, buffer.size)
                }
            } catch (_: Exception) {
                // Ignore audio loop error
            } finally {
                try {
                    ambientTrack?.stop()
                    ambientTrack?.release()
                    ambientTrack = null
                } catch (_: Exception) {}
            }
        }
    }

    fun stopAmbientSound() {
        ambientJob?.cancel()
        ambientJob = null
        try {
            ambientTrack?.stop()
            ambientTrack?.release()
            ambientTrack = null
        } catch (_: Exception) {}
    }
}
