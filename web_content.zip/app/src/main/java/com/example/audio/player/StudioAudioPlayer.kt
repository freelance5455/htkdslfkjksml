package com.example.audio.player

import android.content.Context
import android.media.MediaPlayer
import android.net.Uri
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs

/**
 * High-performance audio player for studio recordings with waveform visualization support.
 */
class StudioAudioPlayer(private val context: Context) {

    private var mediaPlayer: MediaPlayer? = null
    private var progressJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Main)

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _currentPositionMs = MutableStateFlow(0)
    val currentPositionMs: StateFlow<Int> = _currentPositionMs.asStateFlow()

    private val _durationMs = MutableStateFlow(0)
    val durationMs: StateFlow<Int> = _durationMs.asStateFlow()

    private val _currentPlayingId = MutableStateFlow<String?>(null)
    val currentPlayingId: StateFlow<String?> = _currentPlayingId.asStateFlow()

    fun play(recordingId: String, file: File, onCompletion: () -> Unit = {}) {
        stop()

        try {
            val player = MediaPlayer()
            player.setDataSource(context, Uri.fromFile(file))
            player.prepare()
            val totalDuration = player.duration
            _durationMs.value = totalDuration
            _currentPositionMs.value = 0
            _currentPlayingId.value = recordingId

            player.setOnCompletionListener {
                _isPlaying.value = false
                _currentPositionMs.value = 0
                stopProgressTracking()
                onCompletion()
            }

            player.start()
            _isPlaying.value = true
            mediaPlayer = player
            startProgressTracking()
        } catch (e: Exception) {
            e.printStackTrace()
            _isPlaying.value = false
            _currentPlayingId.value = null
        }
    }

    fun pause() {
        mediaPlayer?.let {
            if (it.isPlaying) {
                it.pause()
                _isPlaying.value = false
                stopProgressTracking()
            }
        }
    }

    fun resume() {
        mediaPlayer?.let {
            if (!it.isPlaying) {
                it.start()
                _isPlaying.value = true
                startProgressTracking()
            }
        }
    }

    fun seekTo(positionMs: Int) {
        mediaPlayer?.let {
            it.seekTo(positionMs)
            _currentPositionMs.value = positionMs
        }
    }

    fun stop() {
        stopProgressTracking()
        mediaPlayer?.let {
            try {
                if (it.isPlaying) it.stop()
                it.reset()
                it.release()
            } catch (_: Exception) {}
        }
        mediaPlayer = null
        _isPlaying.value = false
        _currentPositionMs.value = 0
        _currentPlayingId.value = null
    }

    private fun startProgressTracking() {
        stopProgressTracking()
        progressJob = scope.launch {
            while (isActive && mediaPlayer?.isPlaying == true) {
                mediaPlayer?.let {
                    _currentPositionMs.value = it.currentPosition
                }
                delay(50)
            }
        }
    }

    private fun stopProgressTracking() {
        progressJob?.cancel()
        progressJob = null
    }

    companion object {
        /**
         * Extracts normalized amplitude points [0.0 .. 1.0] from a WAV file
         * for rich visual waveform rendering.
         */
        suspend fun extractWaveformPeaks(file: File, sampleCount: Int = 60): List<Float> =
            withContext(Dispatchers.IO) {
                if (!file.exists() || file.length() < 44) {
                    return@withContext List(sampleCount) { 0.1f }
                }

                try {
                    val peaks = mutableListOf<Float>()
                    val fileSize = file.length()
                    val dataSize = fileSize - 44
                    val bytesPerBucket = (dataSize / sampleCount).coerceAtLeast(2).toInt()

                    FileInputStream(file).use { stream ->
                        // Skip 44 bytes header
                        stream.skip(44)
                        val buffer = ByteArray(bytesPerBucket)

                        var count = 0
                        while (count < sampleCount) {
                            val bytesRead = stream.read(buffer)
                            if (bytesRead <= 0) break
                            var maxSample = 0
                            val bb = ByteBuffer.wrap(buffer, 0, bytesRead).order(ByteOrder.LITTLE_ENDIAN)
                            while (bb.remaining() >= 2) {
                                val s = abs(bb.short.toInt())
                                if (s > maxSample) maxSample = s
                            }
                            val normalized = (maxSample / 32768f).coerceIn(0.05f, 1f)
                            peaks.add(normalized)
                            count++
                        }
                    }

                    while (peaks.size < sampleCount) {
                        peaks.add(0.1f)
                    }
                    peaks
                } catch (e: Exception) {
                    e.printStackTrace()
                    List(sampleCount) { 0.15f }
                }
            }
    }
}
