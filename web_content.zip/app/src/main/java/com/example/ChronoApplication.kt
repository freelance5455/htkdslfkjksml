package com.example

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.example.receiver.AlarmReceiver

class ChronoApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                val channel = NotificationChannel(
                    AlarmReceiver.CHANNEL_ID,
                    "Chrono Alarms & Reminders",
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "High priority alarms and schedule alerts"
                    enableVibration(true)
                }
                val nm = getSystemService(NotificationManager::class.java)
                nm?.createNotificationChannel(channel)
            } catch (e: Throwable) {
                e.printStackTrace()
            }
        }
    }
}
