package com.example.calculator

import java.text.DecimalFormat
import kotlin.math.*

object CalculatorEngine {
    private val format = DecimalFormat("#,##0.########")

    fun evaluate(expression: String, isRad: Boolean): Result<Double> {
        return try {
            val sanitized = sanitize(expression)
            if (sanitized.isBlank()) return Result.failure(IllegalArgumentException("Empty"))
            val tokens = tokenize(sanitized)
            val rpn = shuntingYard(tokens)
            val result = evaluateRpn(rpn, isRad)
            if (result.isNaN() || result.isInfinite()) {
                Result.failure(ArithmeticException("Galvanic Overflow"))
            } else {
                Result.success(result)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun formatResult(value: Double): String {
        return if (abs(value) >= 1e12 || (abs(value) < 1e-6 && value != 0.0)) {
            String.format("%.6e", value)
        } else if (value == value.toLong().toDouble() && !value.toString().contains("E")) {
            value.toLong().toString()
        } else {
            format.format(value)
        }
    }

    private fun sanitize(expr: String): String {
        return expr
            .replace("×", "*")
            .replace("÷", "/")
            .replace("−", "-")
            .replace("π", "3.141592653589793")
            .replace("e", "2.718281828459045")
    }

    private fun tokenize(expr: String): List<String> {
        val tokens = mutableListOf<String>()
        var i = 0
        while (i < expr.length) {
            val c = expr[i]
            when {
                c.isWhitespace() -> i++
                c.isDigit() || c == '.' -> {
                    val sb = StringBuilder()
                    while (i < expr.length && (expr[i].isDigit() || expr[i] == '.')) {
                        sb.append(expr[i])
                        i++
                    }
                    tokens.add(sb.toString())
                }
                c == '+' || c == '-' || c == '*' || c == '/' || c == '%' || c == '^' || c == '!' || c == '(' || c == ')' -> {
                    // Check if '-' is a unary negative sign
                    if (c == '-' && (tokens.isEmpty() || tokens.last() in listOf("+", "-", "*", "/", "%", "^", "("))) {
                        tokens.add("neg")
                    } else {
                        tokens.add(c.toString())
                    }
                    i++
                }
                c == '√' -> {
                    tokens.add("sqrt")
                    i++
                }
                c.isLetter() -> {
                    val sb = StringBuilder()
                    while (i < expr.length && expr[i].isLetter()) {
                        sb.append(expr[i])
                        i++
                    }
                    tokens.add(sb.toString())
                }
                else -> i++
            }
        }
        return tokens
    }

    private fun precedence(op: String): Int = when (op) {
        "+", "-" -> 1
        "*", "/", "%" -> 2
        "^" -> 3
        "neg" -> 4
        "sin", "cos", "tan", "sqrt", "log", "ln", "!" -> 5
        else -> 0
    }

    private fun isOperator(t: String): Boolean =
        t in listOf("+", "-", "*", "/", "%", "^", "neg", "sin", "cos", "tan", "sqrt", "log", "ln", "!")

    private fun isFunction(t: String): Boolean =
        t in listOf("sin", "cos", "tan", "sqrt", "log", "ln")

    private fun shuntingYard(tokens: List<String>): List<String> {
        val output = mutableListOf<String>()
        val stack = ArrayDeque<String>()

        for (token in tokens) {
            when {
                token.toDoubleOrNull() != null -> output.add(token)
                isFunction(token) -> stack.addLast(token)
                token == "(" -> stack.addLast(token)
                token == ")" -> {
                    while (stack.isNotEmpty() && stack.last() != "(") {
                        output.add(stack.removeLast())
                    }
                    if (stack.isNotEmpty() && stack.last() == "(") {
                        stack.removeLast()
                    }
                    if (stack.isNotEmpty() && isFunction(stack.last())) {
                        output.add(stack.removeLast())
                    }
                }
                isOperator(token) -> {
                    while (stack.isNotEmpty() && stack.last() != "(" &&
                        ((precedence(stack.last()) > precedence(token)) ||
                                (precedence(stack.last()) == precedence(token) && token != "^" && token != "neg"))
                    ) {
                        output.add(stack.removeLast())
                    }
                    stack.addLast(token)
                }
            }
        }

        while (stack.isNotEmpty()) {
            val op = stack.removeLast()
            if (op != "(" && op != ")") {
                output.add(op)
            }
        }

        return output
    }

    private fun evaluateRpn(rpn: List<String>, isRad: Boolean): Double {
        val stack = ArrayDeque<Double>()

        for (token in rpn) {
            val num = token.toDoubleOrNull()
            if (num != null) {
                stack.addLast(num)
            } else {
                when (token) {
                    "+" -> {
                        val b = stack.removeLast()
                        val a = stack.removeLast()
                        stack.addLast(a + b)
                    }
                    "-" -> {
                        val b = stack.removeLast()
                        val a = stack.removeLast()
                        stack.addLast(a - b)
                    }
                    "*" -> {
                        val b = stack.removeLast()
                        val a = stack.removeLast()
                        stack.addLast(a * b)
                    }
                    "/" -> {
                        val b = stack.removeLast()
                        val a = stack.removeLast()
                        if (b == 0.0) throw ArithmeticException("Division by zero")
                        stack.addLast(a / b)
                    }
                    "%" -> {
                        val b = stack.removeLast()
                        val a = stack.removeLast()
                        stack.addLast(a % b)
                    }
                    "^" -> {
                        val b = stack.removeLast()
                        val a = stack.removeLast()
                        stack.addLast(a.pow(b))
                    }
                    "neg" -> {
                        val a = stack.removeLast()
                        stack.addLast(-a)
                    }
                    "sqrt" -> {
                        val a = stack.removeLast()
                        if (a < 0) throw ArithmeticException("Negative square root")
                        stack.addLast(sqrt(a))
                    }
                    "sin" -> {
                        val a = stack.removeLast()
                        val rad = if (isRad) a else Math.toRadians(a)
                        stack.addLast(sin(rad))
                    }
                    "cos" -> {
                        val a = stack.removeLast()
                        val rad = if (isRad) a else Math.toRadians(a)
                        stack.addLast(cos(rad))
                    }
                    "tan" -> {
                        val a = stack.removeLast()
                        val rad = if (isRad) a else Math.toRadians(a)
                        stack.addLast(tan(rad))
                    }
                    "log" -> {
                        val a = stack.removeLast()
                        if (a <= 0) throw ArithmeticException("Log domain error")
                        stack.addLast(log10(a))
                    }
                    "ln" -> {
                        val a = stack.removeLast()
                        if (a <= 0) throw ArithmeticException("Ln domain error")
                        stack.addLast(ln(a))
                    }
                    "!" -> {
                        val a = stack.removeLast()
                        val n = a.toInt()
                        if (n < 0 || n > 170) throw ArithmeticException("Factorial overflow")
                        var res = 1.0
                        for (i in 2..n) res *= i
                        stack.addLast(res)
                    }
                }
            }
        }

        return stack.singleOrNull() ?: throw IllegalArgumentException("Invalid syntax")
    }
}
