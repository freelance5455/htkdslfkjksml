package com.example.ui.components

import android.os.SystemClock
import android.view.KeyEvent
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.theme.BlackPure
import com.example.ui.theme.SilverBorder
import com.example.ui.theme.SilverDark
import com.example.ui.theme.SilverLight
import com.example.ui.theme.SilverSurface
import com.example.ui.theme.SilverSurfaceVariant
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

@Composable
fun PasswordProtectionDialog(
    targetSectionName: String,
    onSuccess: () -> Unit,
    onDismiss: () -> Unit
) {
    var enteredPin by remember { mutableStateOf("") }
    var isError by remember { mutableStateOf(false) }
    var isPasswordVisible by remember { mutableStateOf(false) }
    var lastEnteredDigit by remember { mutableStateOf<String?>(null) }
    var lastActionTime by remember { mutableLongStateOf(0L) }
    val shakeOffset = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    val focusRequester = remember { FocusRequester() }

    fun checkAndSubmit(pin: String) {
        if (pin.length == 6) {
            if (pin == "012078") {
                onSuccess()
            } else {
                isError = true
                scope.launch {
                    for (i in 0..3) {
                        shakeOffset.animateTo(16f, tween(40, easing = LinearEasing))
                        shakeOffset.animateTo(-16f, tween(40, easing = LinearEasing))
                    }
                    shakeOffset.animateTo(0f, tween(40))
                    delay(300)
                    enteredPin = ""
                    lastEnteredDigit = null
                }
            }
        }
    }

    fun handleDigit(d: String) {
        val now = SystemClock.elapsedRealtime()
        // Prevent duplicate character entry from web emulator double-clicking or IME duplicate signals
        if (d == lastEnteredDigit && (now - lastActionTime) < 450L) {
            return
        }
        if ((now - lastActionTime) < 140L) {
            return
        }
        lastActionTime = now
        lastEnteredDigit = d

        if (enteredPin.length < 6) {
            val updated = enteredPin + d
            enteredPin = updated
            isError = false
            checkAndSubmit(updated)
        }
    }

    fun handleBackspace() {
        val now = SystemClock.elapsedRealtime()
        if (now - lastActionTime < 160L) {
            return
        }
        lastActionTime = now
        lastEnteredDigit = null

        if (enteredPin.isNotEmpty()) {
            enteredPin = enteredPin.dropLast(1)
            isError = false
        }
    }

    LaunchedEffect(Unit) {
        try {
            focusRequester.requestFocus()
        } catch (_: Exception) {}
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.65f))
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null
                ) { onDismiss() },
            contentAlignment = Alignment.Center
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth(0.92f)
                    .offset { IntOffset(shakeOffset.value.roundToInt(), 0) }
                    .clip(SlantedShape)
                    .border(BorderStroke(2.dp, BlackPure), SlantedShape)
                    .focusRequester(focusRequester)
                    .focusable()
                    .onPreviewKeyEvent { keyEvent ->
                        if (keyEvent.type == KeyEventType.KeyDown) {
                            val code = keyEvent.nativeKeyEvent.keyCode
                            when {
                                code in KeyEvent.KEYCODE_0..KeyEvent.KEYCODE_9 -> {
                                    val digit = (code - KeyEvent.KEYCODE_0).toString()
                                    handleDigit(digit)
                                    true
                                }
                                code in KeyEvent.KEYCODE_NUMPAD_0..KeyEvent.KEYCODE_NUMPAD_9 -> {
                                    val digit = (code - KeyEvent.KEYCODE_NUMPAD_0).toString()
                                    handleDigit(digit)
                                    true
                                }
                                code == KeyEvent.KEYCODE_DEL -> {
                                    handleBackspace()
                                    true
                                }
                                code == KeyEvent.KEYCODE_ESCAPE -> {
                                    onDismiss()
                                    true
                                }
                                code == KeyEvent.KEYCODE_ENTER || code == KeyEvent.KEYCODE_NUMPAD_ENTER -> {
                                    checkAndSubmit(enteredPin)
                                    true
                                }
                                else -> false
                            }
                        } else {
                            false
                        }
                    }
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null
                    ) { /* prevent click-through */ },
                color = SilverLight,
                shadowElevation = 16.dp
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Header with close button
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = "Vault Locked",
                                tint = BlackPure,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "VAULT SECURITY",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = BlackPure,
                                letterSpacing = 2.sp
                            )
                        }

                        Box(
                            modifier = Modifier
                                .testTag("password_dialog_close")
                                .size(32.dp)
                                .clip(SlantedShape)
                                .background(SilverSurface)
                                .border(BorderStroke(1.dp, BlackPure), SlantedShape)
                                .clickable { onDismiss() },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Cancel",
                                tint = BlackPure,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "Enter Passcode for \"$targetSectionName\"",
                        style = MaterialTheme.typography.bodyMedium,
                        color = SilverDark,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // 6 Display Slots for PIN with optional visibility
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        for (i in 0 until 6) {
                            val isFilled = i < enteredPin.length
                            val digitChar = if (isFilled) enteredPin[i] else null

                            Box(
                                modifier = Modifier
                                    .size(width = 38.dp, height = 44.dp)
                                    .clip(SlantedShape)
                                    .background(
                                        when {
                                            isError -> Color(0xFFFEE2E2)
                                            isFilled -> SilverSurfaceVariant
                                            else -> SilverSurface.copy(alpha = 0.5f)
                                        }
                                    )
                                    .border(
                                        BorderStroke(
                                            1.5.dp,
                                            when {
                                                isError -> Color(0xFFB91C1C)
                                                isFilled -> BlackPure
                                                else -> SilverBorder
                                            }
                                        ),
                                        SlantedShape
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                if (digitChar != null) {
                                    Text(
                                        text = if (isPasswordVisible) digitChar.toString() else "●",
                                        style = MaterialTheme.typography.titleLarge,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isError) Color(0xFFB91C1C) else BlackPure
                                    )
                                } else {
                                    Text(
                                        text = "-",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = SilverDark.copy(alpha = 0.5f)
                                    )
                                }
                            }
                        }

                        // Toggle Visibility Icon
                        IconButton(
                            onClick = { isPasswordVisible = !isPasswordVisible },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                imageVector = if (isPasswordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                contentDescription = if (isPasswordVisible) "Hide password" else "Show password",
                                tint = BlackPure,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = if (isError) "Incorrect passcode (012078). Try again." else " ",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color(0xFFB91C1C),
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Numeric Keypad
                    val keypad = listOf(
                        listOf("1", "2", "3"),
                        listOf("4", "5", "6"),
                        listOf("7", "8", "9"),
                        listOf("C", "0", "DEL")
                    )

                    Column(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        for (row in keypad) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                for (key in row) {
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(50.dp)
                                            .clip(SlantedShape)
                                            .background(
                                                when (key) {
                                                    "C", "DEL" -> SilverSurfaceVariant
                                                    else -> SilverSurface
                                                }
                                            )
                                            .border(BorderStroke(1.5.dp, BlackPure), SlantedShape)
                                            .clickable {
                                                when (key) {
                                                    "C" -> {
                                                        val now = SystemClock.elapsedRealtime()
                                                        if (now - lastActionTime >= 150L) {
                                                            lastActionTime = now
                                                            enteredPin = ""
                                                            isError = false
                                                        }
                                                    }
                                                    "DEL" -> handleBackspace()
                                                    else -> handleDigit(key)
                                                }
                                            },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        if (key == "DEL") {
                                            Icon(
                                                imageVector = Icons.AutoMirrored.Filled.Backspace,
                                                contentDescription = "Backspace",
                                                tint = BlackPure,
                                                modifier = Modifier.size(20.dp)
                                            )
                                        } else {
                                            Text(
                                                text = key,
                                                style = MaterialTheme.typography.titleLarge,
                                                fontWeight = FontWeight.Bold,
                                                color = BlackPure
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
