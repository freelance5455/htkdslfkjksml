package com.example.ui.components

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.data.local.CareLogEntity
import com.example.data.local.CycleLogEntity
import com.example.data.local.DiaryEntryEntity
import com.example.data.local.EmergencyContactEntity
import com.example.data.local.HormoneCheckEntity
import com.example.data.local.VitalityLogEntity
import com.example.data.model.CareCategory
import com.example.data.model.HavenAward
import com.example.data.model.UserProfile
import java.io.File
import java.io.FileOutputStream
import java.util.Locale

@Composable
fun ProfileAvatarImage(
    photoPath: String,
    displayName: String,
    size: Dp = 56.dp,
    modifier: Modifier = Modifier
) {
    val bitmap = remember(photoPath) {
        if (photoPath.isNotBlank()) {
            try {
                val file = File(photoPath)
                if (file.exists()) BitmapFactory.decodeFile(file.absolutePath) else null
            } catch (_: Exception) {
                null
            }
        } else {
            null
        }
    }

    Box(
        modifier = modifier
            .size(size)
            .clip(CircleShape)
            .background(MaterialTheme.colorScheme.primaryContainer)
            .border(2.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.45f), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        if (bitmap != null) {
            Image(
                bitmap = bitmap.asImageBitmap(),
                contentDescription = "Profile photo of $displayName",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            val initial = displayName.trim().firstOrNull()?.uppercaseChar()?.toString() ?: "H"
            Text(
                text = initial,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onPrimaryContainer
            )
        }
    }
}

fun savePickedPhotoToInternalStorage(context: Context, uri: Uri): String? {
    return try {
        val input = context.contentResolver.openInputStream(uri) ?: return null
        val decoded = BitmapFactory.decodeStream(input)
        input.close()
        if (decoded == null) return null

        // Downscale neatly so storage stays compact and fast
        val maxDim = 512
        val scale = minOf(1f, maxDim.toFloat() / maxOf(decoded.width, decoded.height))
        val targetW = (decoded.width * scale).toInt().coerceAtLeast(1)
        val targetH = (decoded.height * scale).toInt().coerceAtLeast(1)
        val scaled = if (scale < 1f) Bitmap.createScaledBitmap(decoded, targetW, targetH, true) else decoded

        val destFile = File(context.filesDir, "haven_profile_avatar.jpg")
        FileOutputStream(destFile).use { out ->
            scaled.compress(Bitmap.CompressFormat.JPEG, 88, out)
        }
        destFile.absolutePath
    } catch (_: Exception) {
        null
    }
}

@Suppress("DEPRECATION")
fun detectFriendlyLocation(context: Context): String {
    val hasFine = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
    val hasCoarse = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
    if (!hasFine && !hasCoarse) {
        return "Location permission needed"
    }
    return try {
        val lm = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
            ?: return "Location service unavailable"
        val providers = lm.getProviders(true)
        var best: Location? = null
        for (p in providers) {
            val loc = try { lm.getLastKnownLocation(p) } catch (_: SecurityException) { null }
            if (loc != null && (best == null || loc.accuracy < best.accuracy)) {
                best = loc
            }
        }
        if (best == null) {
            "GPS signal waiting — enter city manually"
        } else {
            val lat = "%.4f".format(Locale.US, best.latitude)
            val lon = "%.4f".format(Locale.US, best.longitude)
            val cityLabel = try {
                val geocoder = Geocoder(context, Locale.getDefault())
                val list = geocoder.getFromLocation(best.latitude, best.longitude, 1)
                val addr = list?.firstOrNull()
                listOfNotNull(addr?.locality ?: addr?.subAdminArea, addr?.adminArea, addr?.countryName)
                    .filter { it.isNotBlank() }
                    .distinct()
                    .joinToString(", ")
            } catch (_: Exception) {
                ""
            }
            if (cityLabel.isNotBlank()) "$cityLabel ($lat, $lon)" else "GPS: $lat, $lon"
        }
    } catch (_: Exception) {
        "Unable to read GPS location"
    }
}

fun computeHavenAwards(
    profile: UserProfile,
    todayCareLogs: List<CareLogEntity>,
    diaryEntries: List<DiaryEntryEntity>,
    hormoneChecks: List<HormoneCheckEntity>,
    cycleLogs: List<CycleLogEntity>,
    vitalityLogs: List<VitalityLogEntity>,
    contacts: List<EmergencyContactEntity>,
    learnedFactsCount: Int,
    quizStreak: Int
): List<HavenAward> {
    val distinctCareToday = todayCareLogs.map { it.categoryKey }.toSet()
    return listOf(
        HavenAward(
            id = "human_otp",
            title = "Verified & Ready",
            description = "Completed Human Check & Email OTP Sign-In",
            points = 100,
            unlocked = profile.humanVerified && profile.emailOtpVerified
        ),
        HavenAward(
            id = "avatar_pic",
            title = "Picture Perfect",
            description = "Added your personal profile picture",
            points = 50,
            unlocked = profile.profilePhotoPath.isNotBlank()
        ),
        HavenAward(
            id = "identity_roots",
            title = "Identity & Roots",
            description = "Saved Birthday, Location & ID (including underage ID)",
            points = 75,
            unlocked = profile.birthday.isNotBlank() && profile.locationText.isNotBlank() && profile.idNumber.isNotBlank()
        ),
        HavenAward(
            id = "student_star",
            title = "Dedicated Student",
            description = "Added Student status & Grade level",
            points = 75,
            unlocked = profile.gradeLevel.isNotBlank()
        ),
        HavenAward(
            id = "hydration_hero",
            title = "Hydration Hero",
            description = "Logged Drink Water in Daily Care",
            points = 50,
            unlocked = CareCategory.DRINK_WATER.key in distinctCareToday
        ),
        HavenAward(
            id = "daily_champ",
            title = "Daily Care Champion",
            description = "Logged 5 or more daily care categories today",
            points = 150,
            unlocked = distinctCareToday.size >= 5
        ),
        HavenAward(
            id = "voice_courage",
            title = "Voice of Courage",
            description = "Saved a Voice or Text Diary reflection",
            points = 100,
            unlocked = diaryEntries.isNotEmpty()
        ),
        HavenAward(
            id = "faith_wisdom",
            title = "Faith & Wisdom",
            description = "Learned a new daily fact or answered Daily Quick Question",
            points = 100,
            unlocked = learnedFactsCount > 0 || quizStreak > 0
        ),
        HavenAward(
            id = "wellness_harmony",
            title = "Body & Hormone Harmony",
            description = "Completed a Cycle, Vitality, or Hormone Check-In",
            points = 100,
            unlocked = hormoneChecks.isNotEmpty() || cycleLogs.isNotEmpty() || vitalityLogs.isNotEmpty()
        ),
        HavenAward(
            id = "safety_guardian",
            title = "Safety Guardian",
            description = "Added at least 1 Trusted Emergency Contact",
            points = 100,
            unlocked = contacts.isNotEmpty()
        )
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AwardsShowcaseCard(
    awards: List<HavenAward>,
    modifier: Modifier = Modifier
) {
    val unlockedCount = awards.count { it.unlocked }
    val earnedPoints = awards.filter { it.unlocked }.sumOf { it.points }
    val totalPoints = awards.sumOf { it.points }.coerceAtLeast(1)
    val progress = (earnedPoints.toFloat() / totalPoints.toFloat()).coerceIn(0f, 1f)

    Card(
        modifier = modifier.fillMaxWidth().testTag("awards_showcase_card"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.55f))
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Filled.EmojiEvents,
                        contentDescription = "Awards Trophy",
                        tint = MaterialTheme.colorScheme.secondary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "Your Earned Awards",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "$unlockedCount / ${awards.size} unlocked • $earnedPoints pts",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp))
            )

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                awards.forEach { award ->
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = if (award.unlocked) {
                            MaterialTheme.colorScheme.primaryContainer
                        } else {
                            MaterialTheme.colorScheme.surface.copy(alpha = 0.72f)
                        },
                        tonalElevation = if (award.unlocked) 2.dp else 0.dp
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (award.unlocked) Icons.Filled.Verified else Icons.Filled.Lock,
                                contentDescription = null,
                                tint = if (award.unlocked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Column {
                                Text(
                                    text = "${award.title} (+${award.points})",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = if (award.unlocked) FontWeight.Bold else FontWeight.Medium
                                )
                                Text(
                                    text = award.description,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
