package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Brightness5
import androidx.compose.material.icons.filled.Brightness6
import androidx.compose.material.icons.filled.Brightness7
import androidx.compose.material.icons.filled.NightlightRound
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material.icons.filled.WbTwilight
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PrayerTimeItemData
import com.example.data.model.PrayerType
import com.example.ui.theme.AmberGlow
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.GoldPrimary

@Composable
fun PrayerTimeItem(
    prayerItem: PrayerTimeItemData,
    onAdjustOffset: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val isNext = prayerItem.isNext
    val isPassed = prayerItem.isPassed && !isNext

    val prayerIcon: ImageVector = when (prayerItem.type) {
        PrayerType.FAJR -> Icons.Default.WbTwilight
        PrayerType.SUNRISE -> Icons.Default.Brightness5
        PrayerType.DHUHR -> Icons.Default.WbSunny
        PrayerType.ASR -> Icons.Default.Brightness7
        PrayerType.MAGHRIB -> Icons.Default.Brightness6
        PrayerType.ISHA -> Icons.Default.NightlightRound
    }

    val iconColor = if (isNext) AmberGlow else if (isPassed) MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f) else GoldPrimary

    val cardBorder = if (isNext) {
        BorderStrokeInfo(1.8.dp, Brush.horizontalGradient(listOf(AmberGlow, GoldPrimary)))
    } else {
        BorderStrokeInfo(1.dp, Brush.horizontalGradient(listOf(MaterialTheme.colorScheme.outline.copy(alpha = 0.25f), MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))))
    }

    val containerColor by animateColorAsState(
        targetValue = when {
            isNext -> MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
            isPassed -> MaterialTheme.colorScheme.surface.copy(alpha = 0.7f)
            else -> MaterialTheme.colorScheme.surface
        },
        label = "containerColor"
    )

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("prayer_item_${prayerItem.type.key}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = containerColor),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isNext) 4.dp else 1.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .border(
                    width = cardBorder.width,
                    brush = cardBorder.brush,
                    shape = RoundedCornerShape(14.dp)
                )
                .padding(horizontal = 14.dp, vertical = 12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Left side: Icon + Prayer Name + Tag
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(
                                if (isNext) AmberGlow.copy(alpha = 0.2f)
                                else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.8f)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = prayerIcon,
                            contentDescription = prayerItem.type.arabicName,
                            tint = iconColor,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = prayerItem.type.arabicName,
                                fontSize = 17.sp,
                                fontWeight = if (isNext) FontWeight.ExtraBold else FontWeight.Bold,
                                color = if (isNext) AmberGlow else MaterialTheme.colorScheme.onSurface
                            )
                            if (isNext) {
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = AmberGlow.copy(alpha = 0.25f),
                                    modifier = Modifier.padding(2.dp)
                                ) {
                                    Text(
                                        text = "التالية",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = AmberGlow,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                        Text(
                            text = prayerItem.type.englishName,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                        )
                    }
                }

                // Right side: Adjusted Time + Offset buttons
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.End
                ) {
                    Text(
                        text = prayerItem.formattedTime,
                        fontSize = 19.sp,
                        fontWeight = FontWeight.ExtraBold,
                        fontFamily = FontFamily.Monospace,
                        color = if (isNext) AmberGlow else MaterialTheme.colorScheme.primary,
                        modifier = Modifier.testTag("prayer_time_${prayerItem.type.key}")
                    )

                    Spacer(modifier = Modifier.width(10.dp))

                    // Offset controls matching HTML prototype: [-] [offset] [+]
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                            .border(
                                0.8.dp,
                                MaterialTheme.colorScheme.outline.copy(alpha = 0.2f),
                                RoundedCornerShape(8.dp)
                            )
                            .padding(2.dp)
                    ) {
                        IconButton(
                            onClick = { onAdjustOffset(-1) },
                            modifier = Modifier
                                .size(32.dp)
                                .testTag("btn_offset_minus_${prayerItem.type.key}")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Remove,
                                contentDescription = "إنقاص دقيقة",
                                modifier = Modifier.size(14.dp),
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        val offsetPrefix = if (prayerItem.offsetMinutes > 0) "+" else ""
                        Text(
                            text = "$offsetPrefix${prayerItem.offsetMinutes}د",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = if (prayerItem.offsetMinutes != 0) AmberGlow else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 4.dp)
                        )

                        IconButton(
                            onClick = { onAdjustOffset(1) },
                            modifier = Modifier
                                .size(32.dp)
                                .testTag("btn_offset_plus_${prayerItem.type.key}")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = "زيادة دقيقة",
                                modifier = Modifier.size(14.dp),
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}

private data class BorderStrokeInfo(
    val width: androidx.compose.ui.unit.Dp,
    val brush: Brush
)
