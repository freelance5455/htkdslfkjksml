package com.example.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.ArkChallenge
import com.example.data.model.ArkGameType
import com.example.data.model.ArkGroup
import com.example.data.model.BlockedUser
import com.example.data.model.ChallengeProgress
import com.example.data.model.FriendEdge
import com.example.data.model.FriendRequest
import com.example.data.model.GameRoom
import com.example.data.model.GroupEvent
import com.example.data.model.GroupMedia
import com.example.data.model.GroupMessage
import com.example.data.model.ModerationReport
import com.example.data.model.NotificationItem
import com.example.data.model.UserPrivateSettings
import com.example.data.model.UserProfile
import com.example.data.repository.AdminRepository
import com.example.data.repository.ArkPreferencesRepository
import com.example.data.repository.ChallengeRepository
import com.example.data.repository.DirectMessageRepository
import com.example.data.repository.FeedRepository
import com.example.data.repository.FollowRepository
import com.example.data.repository.GameRepository
import com.example.data.repository.GroupRepository
import com.example.data.repository.SocialRepository
import com.example.data.repository.StoryRepository
import com.example.data.repository.UserRepository
import com.example.data.repository.unwrapFirestoreException
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}

class ArkAppViewModel(
    val currentUserId: String,
    val userEmail: String,
    private val userRepo: UserRepository,
    private val socialRepo: SocialRepository,
    private val groupRepo: GroupRepository,
    private val gameRepo: GameRepository,
    private val challengeRepo: ChallengeRepository,
    private val adminRepo: AdminRepository,
    private val prefsRepo: ArkPreferencesRepository,
    feedRepo: FeedRepository,
    storyRepo: StoryRepository,
    followRepo: FollowRepository,
    dmRepo: DirectMessageRepository
) : ViewModel() {

    val socialAndChat: SocialAndChatDelegate by lazy {
        SocialAndChatDelegate(
            currentUserId = currentUserId,
            scope = viewModelScope,
            userRepo = userRepo,
            followRepo = followRepo,
            feedRepo = feedRepo,
            storyRepo = storyRepo,
            dmRepo = dmRepo,
            blockedUsersFlow = blockedUsersState,
            postMessage = ::postMessage
        )
    }

    val feed: FeedViewModelDelegate by lazy {
        FeedViewModelDelegate(
            currentUserId = currentUserId,
            scope = viewModelScope,
            feedRepo = feedRepo,
            storyRepo = storyRepo,
            userRepo = userRepo,
            groupRepo = groupRepo,
            blockedUsersFlow = blockedUsersState,
            followersFlow = socialAndChat.followers,
            postMessage = ::postMessage
        )
    }

    private fun <T> Flow<T>.toUiState(tag: String): StateFlow<UiState<T>> =
        this.map<T, UiState<T>> { UiState.Success(it) }
            .catch { error ->
                val firestoreError = error.unwrapFirestoreException()
                if (firestoreError == null && error is CancellationException) throw error
                val root = firestoreError ?: error
                Log.w(tag, "Stream error", root)
                emit(UiState.Error(root.message ?: "Unable to load data"))
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000L),
                initialValue = UiState.Loading
            )

    val profileState: StateFlow<UiState<UserProfile?>> =
        userRepo.observeUserProfile(currentUserId).toUiState("ProfileVM")

    val privateSettingsState: StateFlow<UiState<UserPrivateSettings?>> =
        userRepo.observePrivateSettings(currentUserId).toUiState("SettingsVM")

    val notificationsState: StateFlow<UiState<List<NotificationItem>>> =
        userRepo.observeNotifications(currentUserId).toUiState("NotifVM")

    val leaderboardState: StateFlow<UiState<List<UserProfile>>> =
        userRepo.observeLeaderboard().toUiState("LeaderboardVM")

    val friendsState: StateFlow<UiState<List<FriendEdge>>> =
        socialRepo.observeFriends(currentUserId).toUiState("FriendsVM")

    val incomingRequestsState: StateFlow<UiState<List<FriendRequest>>> =
        socialRepo.observeIncomingRequests(currentUserId).toUiState("IncomingReqVM")

    val outgoingRequestsState: StateFlow<UiState<List<FriendRequest>>> =
        socialRepo.observeOutgoingRequests(currentUserId).toUiState("OutgoingReqVM")

    val blockedUsersState: StateFlow<UiState<List<BlockedUser>>> =
        socialRepo.observeBlockedUsers(currentUserId).toUiState("BlockedVM")

    val myGroupsState: StateFlow<UiState<List<ArkGroup>>> =
        groupRepo.observeMyGroups(currentUserId).toUiState("MyGroupsVM")

    val publicCommunitiesState: StateFlow<UiState<List<ArkGroup>>> =
        groupRepo.observePublicCommunities().toUiState("CommunitiesVM")

    val publicLobbiesState: StateFlow<UiState<List<GameRoom>>> =
        gameRepo.observePublicLobbies().toUiState("LobbiesVM")

    val myGameRoomsState: StateFlow<UiState<List<GameRoom>>> =
        gameRepo.observeMyGameRooms(currentUserId).toUiState("MyRoomsVM")

    val challengesState: StateFlow<UiState<List<ArkChallenge>>> =
        challengeRepo.observeActiveChallenges().toUiState("ChallengesVM")

    val challengeProgressState: StateFlow<UiState<Map<String, ChallengeProgress>>> =
        challengeRepo.observeUserProgress(currentUserId).toUiState("ChallengeProgVM")

    val eventsState: StateFlow<UiState<List<GroupEvent>>> =
        challengeRepo.observeUpcomingEvents(currentUserId).toUiState("EventsVM")

    val themeMode: StateFlow<String> = prefsRepo.themeModeFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), "system")

    private val _selectedGroupId = MutableStateFlow<String?>(null)
    val selectedGroupId = _selectedGroupId.asStateFlow()

    private val _selectedRoomId = MutableStateFlow<String?>(null)
    val selectedRoomId = _selectedRoomId.asStateFlow()

    private val _searchResults = MutableStateFlow<List<UserProfile>>(emptyList())
    val searchResults = _searchResults.asStateFlow()

    private val _isAdmin = MutableStateFlow(false)
    val isAdmin = _isAdmin.asStateFlow()

    private val _reports = MutableStateFlow<List<ModerationReport>>(emptyList())
    val reports = _reports.asStateFlow()

    private val _allUsersModeration = MutableStateFlow<List<UserProfile>>(emptyList())
    val allUsersModeration = _allUsersModeration.asStateFlow()

    private val _snackbarMessage = MutableStateFlow<String?>(null)
    val snackbarMessage = _snackbarMessage.asStateFlow()

    @OptIn(ExperimentalCoroutinesApi::class)
    val selectedGroupState: StateFlow<ArkGroup?> = _selectedGroupId.flatMapLatest { gid ->
        if (gid == null) flowOf(null) else groupRepo.observeGroup(gid)
    }.catch { emit(null) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), null)

    @OptIn(ExperimentalCoroutinesApi::class)
    val selectedGroupMessages: StateFlow<List<GroupMessage>> = _selectedGroupId.flatMapLatest { gid ->
        if (gid == null) flowOf(emptyList()) else groupRepo.observeMessages(gid, currentUserId)
    }.catch { emit(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    @OptIn(ExperimentalCoroutinesApi::class)
    val selectedGroupMedia: StateFlow<List<GroupMedia>> = _selectedGroupId.flatMapLatest { gid ->
        if (gid == null) flowOf(emptyList()) else groupRepo.observeGroupMedia(gid, currentUserId)
    }.catch { emit(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    @OptIn(ExperimentalCoroutinesApi::class)
    val selectedRoomState: StateFlow<GameRoom?> = _selectedRoomId.flatMapLatest { rid ->
        if (rid == null) flowOf(null) else gameRepo.observeRoom(rid)
    }.catch { emit(null) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), null)

    init {
        viewModelScope.launch {
            challengeRepo.ensureSafeChallengesSeeded()
            val admin = adminRepo.checkIsAdmin()
            _isAdmin.value = admin
            if (admin) {
                launch {
                    adminRepo.observeReports().catch { }.collect { _reports.value = it }
                }
                launch {
                    adminRepo.observeAllUsersForModeration().catch { }.collect { _allUsersModeration.value = it }
                }
            }
        }
    }

    fun clearMessage() {
        _snackbarMessage.value = null
    }

    private fun postMessage(msg: String) {
        _snackbarMessage.value = msg
    }

    fun setThemeMode(mode: String) {
        viewModelScope.launch { prefsRepo.setThemeMode(mode) }
    }

    fun selectGroup(groupId: String?) {
        _selectedGroupId.value = groupId
    }

    fun selectRoom(roomId: String?) {
        _selectedRoomId.value = roomId
    }

    fun createProfile(
        username: String,
        displayTag: String,
        bio: String,
        avatarPreset: String,
        ageBracket: String,
        parentalConsentApproved: Boolean,
        parentEmailHint: String
    ) {
        viewModelScope.launch {
            userRepo.createProfile(
                username = username,
                displayTag = displayTag,
                bio = bio,
                avatarPreset = avatarPreset,
                ageBracket = ageBracket,
                parentalConsentApproved = parentalConsentApproved,
                email = userEmail,
                parentEmailHint = parentEmailHint
            ).onSuccess {
                postMessage("Welcome to ARK! +50 starter points unlocked.")
            }.onFailure {
                postMessage(it.message ?: "Failed to create profile.")
            }
        }
    }

    fun updateProfileCustomization(
        displayTag: String,
        bio: String,
        avatarPreset: String,
        profileTheme: String,
        avatarImageBase64: String? = null
    ) {
        viewModelScope.launch {
            userRepo.updateProfileCustomization(displayTag, bio, avatarPreset, profileTheme, avatarImageBase64)
                .onSuccess { postMessage("Profile updated!") }
                .onFailure { postMessage(it.message ?: "Update failed.") }
        }
    }

    suspend fun checkUsernameAvailable(username: String): Result<Boolean> =
        userRepo.checkUsernameAvailable(username, currentUserId)

    fun updateProfileDetails(
        username: String,
        fullName: String,
        displayTag: String,
        bio: String,
        website: String,
        avatarPreset: String,
        profileTheme: String,
        avatarImageBase64: String? = null
    ) {
        viewModelScope.launch {
            userRepo.updateProfileDetails(
                username = username,
                fullName = fullName,
                displayTag = displayTag,
                bio = bio,
                website = website,
                avatarPreset = avatarPreset,
                profileTheme = profileTheme,
                avatarImageBase64 = avatarImageBase64
            ).onSuccess { postMessage("Profile saved.") }
                .onFailure { postMessage(it.message ?: "Could not update profile.") }
        }
    }

    fun updatePrivacy(
        isPrivateAccount: Boolean,
        allowFriendRequests: String,
        showOnlineStatus: Boolean,
        optOutLeaderboard: Boolean,
        allowMessagesFrom: String = "followers",
        requireTagApproval: Boolean = false,
        hiddenStoryFromUids: List<String> = emptyList()
    ) {
        viewModelScope.launch {
            userRepo.updatePrivacyPreferences(
                isPrivateAccount = isPrivateAccount,
                allowFriendRequests = allowFriendRequests,
                showOnlineStatus = showOnlineStatus,
                optOutLeaderboard = optOutLeaderboard,
                allowMessagesFrom = allowMessagesFrom,
                requireTagApproval = requireTagApproval,
                hiddenStoryFromUids = hiddenStoryFromUids
            ).onSuccess { postMessage("Privacy settings saved.") }
                .onFailure { postMessage(it.message ?: "Failed to save privacy.") }
        }
    }

    fun updateNotificationPrefs(settings: UserPrivateSettings) {
        viewModelScope.launch {
            userRepo.updateNotificationPreferences(settings)
                .onSuccess { postMessage("Notification preferences saved.") }
                .onFailure { postMessage(it.message ?: "Failed to save preferences.") }
        }
    }

    fun markNotificationRead(notificationId: String) {
        viewModelScope.launch { userRepo.markNotificationRead(notificationId) }
    }

    fun markAllNotificationsRead() {
        viewModelScope.launch { userRepo.markAllNotificationsRead(currentUserId) }
    }

    fun searchUsers(query: String) {
        viewModelScope.launch {
            socialRepo.searchUserByUsername(query)
                .onSuccess { _searchResults.value = it }
                .onFailure { postMessage(it.message ?: "Search failed.") }
        }
    }

    fun sendFriendRequest(fromUser: UserProfile, toUser: UserProfile) {
        val alreadyPending = (outgoingRequestsState.value as? UiState.Success)?.data
            ?.any { it.toUid == toUser.userId } == true
        if (alreadyPending) {
            postMessage("Friend request already pending for @${toUser.username}.")
            return
        }
        viewModelScope.launch {
            socialRepo.sendFriendRequest(fromUser, toUser)
                .onSuccess {
                    userRepo.sendNotification(
                        recipientUid = toUser.userId,
                        senderUsername = fromUser.username,
                        type = "friend_request",
                        title = "New Friend Request",
                        body = "@${fromUser.username} wants to connect on ARK!"
                    )
                    postMessage("Friend request sent to @${toUser.username}")
                }
                .onFailure { err ->
                    val fsErr = err.unwrapFirestoreException()
                    val msg = if (fsErr?.code == FirebaseFirestoreException.Code.PERMISSION_DENIED) {
                        "Unable to send friend request to @${toUser.username}. Check privacy or block settings."
                    } else {
                        err.message ?: "Could not send request."
                    }
                    postMessage(msg)
                }
        }
    }

    fun acceptFriendRequest(request: FriendRequest, currentUser: UserProfile) {
        viewModelScope.launch {
            socialRepo.acceptFriendRequest(request, currentUser)
                .onSuccess {
                    userRepo.sendNotification(
                        recipientUid = request.fromUid,
                        senderUsername = currentUser.username,
                        type = "friend_request",
                        title = "Friend Request Accepted",
                        body = "@${currentUser.username} is now your friend on ARK!"
                    )
                    postMessage("You and @${request.fromUsername} are now friends!")
                }
                .onFailure { err ->
                    val fsErr = err.unwrapFirestoreException()
                    val msg = if (fsErr?.code == FirebaseFirestoreException.Code.PERMISSION_DENIED) {
                        "Could not accept request due to block or account restrictions."
                    } else {
                        err.message ?: "Failed to accept request."
                    }
                    postMessage(msg)
                }
        }
    }

    fun rejectFriendRequest(requestId: String) {
        viewModelScope.launch {
            socialRepo.rejectFriendRequest(requestId)
                .onSuccess { postMessage("Request declined.") }
                .onFailure { postMessage(it.message ?: "Failed to decline request.") }
        }
    }

    fun cancelFriendRequest(requestId: String) {
        viewModelScope.launch {
            socialRepo.cancelFriendRequest(requestId)
                .onSuccess { postMessage("Friend request cancelled.") }
                .onFailure { postMessage(it.message ?: "Failed to cancel request.") }
        }
    }

    fun removeFriend(friendUid: String) {
        viewModelScope.launch {
            socialRepo.removeFriend(friendUid)
                .onSuccess { postMessage("Friend removed.") }
        }
    }

    fun blockUser(targetUid: String, targetUsername: String) {
        viewModelScope.launch {
            socialRepo.blockUser(targetUid, targetUsername)
                .onSuccess { postMessage("Blocked @$targetUsername.") }
        }
    }

    fun unblockUser(targetUid: String) {
        viewModelScope.launch {
            socialRepo.unblockUser(targetUid)
                .onSuccess { postMessage("User unblocked.") }
        }
    }

    fun submitReport(targetType: String, targetId: String, reason: String, details: String) {
        viewModelScope.launch {
            socialRepo.submitReport(targetType, targetId, reason, details)
                .onSuccess { postMessage("Report submitted to ARK safety team.") }
                .onFailure { postMessage(it.message ?: "Report failed.") }
        }
    }

    fun createGroup(
        name: String,
        description: String,
        theme: String,
        isPrivate: Boolean,
        allowMediaDownloads: Boolean,
        onCreated: (String) -> Unit
    ) {
        viewModelScope.launch {
            groupRepo.createGroup(name, description, theme, isPrivate, allowMediaDownloads)
                .onSuccess {
                    postMessage("Group '${it.name}' created! Code: ${it.inviteCode}")
                    onCreated(it.id)
                }
                .onFailure { postMessage(it.message ?: "Could not create group.") }
        }
    }

    fun joinGroupByCode(code: String, onJoined: (String) -> Unit) {
        viewModelScope.launch {
            groupRepo.joinGroupByInviteCode(code)
                .onSuccess { gid ->
                    postMessage("Joined group!")
                    onJoined(gid)
                }
                .onFailure { postMessage(it.message ?: "Invalid invite code.") }
        }
    }

    fun joinPublicGroup(groupId: String, onJoined: (String) -> Unit) {
        viewModelScope.launch {
            groupRepo.joinPublicGroup(groupId)
                .onSuccess {
                    postMessage("Joined community!")
                    onJoined(groupId)
                }
                .onFailure { postMessage(it.message ?: "Could not join community.") }
        }
    }

    fun updateGroupSettings(
        groupId: String,
        name: String,
        description: String,
        theme: String,
        allowMediaDownloads: Boolean
    ) {
        viewModelScope.launch {
            groupRepo.updateGroupSettings(groupId, name, description, theme, allowMediaDownloads)
                .onSuccess { postMessage("Group settings updated.") }
                .onFailure { postMessage(it.message ?: "Failed to update group.") }
        }
    }

    fun promoteMemberToAdmin(group: ArkGroup, targetUid: String) {
        viewModelScope.launch {
            groupRepo.promoteMemberToAdmin(group, targetUid)
                .onSuccess { postMessage("Admin role assigned.") }
                .onFailure { postMessage(it.message ?: "Failed to promote member.") }
        }
    }

    fun removeGroupMember(group: ArkGroup, targetUid: String) {
        viewModelScope.launch {
            groupRepo.removeMember(group, targetUid)
                .onSuccess { postMessage("Member removed.") }
                .onFailure { postMessage(it.message ?: "Could not remove member.") }
        }
    }

    fun leaveGroup(group: ArkGroup, onLeft: () -> Unit) {
        viewModelScope.launch {
            groupRepo.leaveGroup(group)
                .onSuccess {
                    postMessage("Left ${group.name}")
                    onLeft()
                }
                .onFailure { postMessage(it.message ?: "Cannot leave group.") }
        }
    }

    fun deleteGroup(group: ArkGroup, onDeleted: () -> Unit) {
        viewModelScope.launch {
            groupRepo.deleteGroup(group)
                .onSuccess {
                    postMessage("Group deleted.")
                    onDeleted()
                }
                .onFailure { postMessage(it.message ?: "Failed to delete group.") }
        }
    }

    fun sendGroupMessage(
        group: ArkGroup,
        sender: UserProfile,
        text: String,
        imageBase64: String? = null,
        replyToId: String? = null,
        replyToPreview: String? = null
    ) {
        viewModelScope.launch {
            groupRepo.sendMessage(group, sender, text, imageBase64, replyToId, replyToPreview)
                .onFailure { postMessage(it.message ?: "Failed to send message.") }
        }
    }

    fun reactToMessage(groupId: String, message: GroupMessage, emoji: String) {
        viewModelScope.launch { groupRepo.addReaction(groupId, message, emoji) }
    }

    fun deleteGroupMessage(groupId: String, messageId: String) {
        viewModelScope.launch { groupRepo.deleteMessage(groupId, messageId) }
    }

    fun uploadGroupMedia(
        group: ArkGroup,
        uploader: UserProfile,
        albumName: String,
        caption: String,
        imageBase64: String
    ) {
        viewModelScope.launch {
            groupRepo.uploadGroupMedia(group, uploader, albumName, caption, imageBase64)
                .onSuccess { postMessage("Shared to $albumName album!") }
                .onFailure { postMessage(it.message ?: "Upload failed.") }
        }
    }

    fun createGameRoom(
        host: UserProfile,
        gameType: ArkGameType,
        isPrivate: Boolean,
        groupId: String? = null,
        onRoomReady: (String) -> Unit
    ) {
        viewModelScope.launch {
            gameRepo.createGameRoom(host, gameType, isPrivate, groupId)
                .onSuccess { roomId ->
                    onRoomReady(roomId)
                }
                .onFailure { postMessage(it.message ?: "Failed to create room.") }
        }
    }

    fun joinRoomByCode(code: String, player: UserProfile, onRoomReady: (String) -> Unit) {
        viewModelScope.launch {
            gameRepo.joinRoomByCode(code, player)
                .onSuccess { onRoomReady(it) }
                .onFailure { postMessage(it.message ?: "Room not found.") }
        }
    }

    fun joinPublicRoom(roomId: String, player: UserProfile, onRoomReady: (String) -> Unit) {
        viewModelScope.launch {
            gameRepo.joinRoomById(roomId, player)
                .onSuccess { onRoomReady(roomId) }
                .onFailure { postMessage(it.message ?: "Could not join room.") }
        }
    }

    fun toggleReady(room: GameRoom) {
        viewModelScope.launch { gameRepo.toggleReady(room) }
    }

    fun startOrAdvanceGame(room: GameRoom) {
        viewModelScope.launch {
            val next = room.roundNumber + 1L
            gameRepo.startOrAdvanceRound(room, next).onSuccess {
                if (next > room.maxRounds) {
                    val myScore = room.scores[currentUserId] ?: 0L
                    val reward = (20L + (myScore / 5L)).coerceIn(20L, 120L)
                    userRepo.awardProgress(
                        userId = currentUserId,
                        pointsDelta = reward,
                        xpDelta = reward,
                        incrementGames = true,
                        newBadge = "Party Gamer"
                    )
                }
            }.onFailure {
                postMessage(it.message ?: "Failed to advance game.")
            }
        }
    }

    fun submitGameMove(room: GameRoom, choice: String, pointsEarned: Long, nextWordChain: String? = null) {
        viewModelScope.launch {
            gameRepo.submitMoveOrVote(room, choice, pointsEarned, nextWordChain)
                .onFailure { postMessage(it.message ?: "Move failed.") }
        }
    }

    fun requestRematch(room: GameRoom) {
        viewModelScope.launch {
            gameRepo.requestRematch(room)
                .onFailure { postMessage(it.message ?: "Could not start rematch.") }
        }
    }

    fun completeChallenge(challenge: ArkChallenge, reflectionNote: String) {
        viewModelScope.launch {
            challengeRepo.completeChallenge(challenge, reflectionNote, userRepo)
                .onSuccess { postMessage("Challenge completed! +${challenge.rewardPoints} PTS earned!") }
                .onFailure { postMessage(it.message ?: "Could not complete challenge.") }
        }
    }

    fun skipChallenge(challengeId: String) {
        viewModelScope.launch {
            challengeRepo.skipChallenge(challengeId)
                .onSuccess { postMessage("Challenge skipped. Pick another anytime!") }
        }
    }

    fun resolveReport(reportId: String, status: String) {
        viewModelScope.launch {
            adminRepo.resolveReport(reportId, status)
                .onSuccess { postMessage("Report marked $status.") }
        }
    }

    fun toggleUserRestriction(targetUid: String, restrict: Boolean) {
        viewModelScope.launch {
            adminRepo.toggleUserRestriction(targetUid, restrict)
                .onSuccess { postMessage(if (restrict) "User restricted." else "Restriction lifted.") }
        }
    }

    fun adminCreateChallenge(
        title: String,
        description: String,
        category: String,
        difficulty: String,
        frequency: String,
        rewardPoints: Long
    ) {
        viewModelScope.launch {
            adminRepo.createSafeChallenge(title, description, category, difficulty, frequency, rewardPoints)
                .onSuccess { postMessage("Challenge published!") }
                .onFailure { postMessage(it.message ?: "Failed to publish challenge.") }
        }
    }

    fun deleteAccount(onDeleted: () -> Unit) {
        viewModelScope.launch {
            userRepo.deleteAccountAndUserData()
                .onSuccess {
                    postMessage("Account data deleted.")
                    onDeleted()
                }
                .onFailure { postMessage(it.message ?: "Could not delete account.") }
        }
    }
}
