package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Poll
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.outlined.AddReaction
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ArkFeedIds
import com.example.data.model.ArkPost
import com.example.ui.theme.ArkThemeTokens
import com.example.util.rememberDecodedImageBitmap
import com.google.firebase.Timestamp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Locale

fun formatPostTimestamp(ts: Timestamp?): String {
    if (ts == null) return "Just now"
    val diffSec = ((System.currentTimeMillis() - ts.seconds * 1000L) / 1000L).coerceAtLeast(0L)
    return when {
        diffSec < 60L -> "Just now"
        diffSec < 3600L -> "${diffSec / 60L}m ago"
        diffSec < 86400L -> "${diffSec / 3600L}h ago"
        diffSec < 604800L -> "${diffSec / 86400L}d ago"
        else -> SimpleDateFormat("MMM d", Locale.getDefault()).format(ts.toDate())
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun FeedPostCard(
    post: ArkPost,
    currentUserId: String,
    myReaction: String?,
    myPollVote: Int?,
    isBookmarked: Boolean,
    onReaction: (String) -> Unit,
    onOpenComments: () -> Unit,
    onShare: () -> Unit,
    onToggleBookmark: () -> Unit,
    onVotePoll: (Int) -> Unit,
    onEditCaption: () -> Unit,
    onToggleCommentsDisabled: () -> Unit,
    onDeletePost: () -> Unit,
    onHidePost: () -> Unit,
    onMuteAuthor: () -> Unit,
    onReportPost: () -> Unit,
    onOpenMedia: (initialPage: Int) -> Unit,
    modifier: Modifier = Modifier,
    onOpenUserProfile: (String) -> Unit = {},
    onHashtagClick: (String) -> Unit = {},
    onOpenLikers: () -> Unit = {}
) {
    val colors = ArkThemeTokens.colors
    val isOwner = post.authorId == currentUserId
    var menuExpanded by remember { mutableStateOf(false) }
    var showReactionBar by remember { mutableStateOf(false) }
    var showHeartBurst by remember { mutableStateOf(false) }
    var showAltOverlay by remember { mutableStateOf(false) }

    LaunchedEffect(showHeartBurst) {
        if (showHeartBurst) {
            delay(650L)
            showHeartBurst = false
        }
    }

    val likeScale by animateFloatAsState(
        targetValue = if (myReaction != null) 1.18f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "like_scale"
    )

    val cardAccent = when (post.postType) {
        "game_result" -> colors.violet
        "challenge_result" -> colors.emerald
        "group_memory" -> colors.gold
        "poll" -> colors.accent
        else -> null
    }

    LiquidGlassCard(
        modifier = modifier.fillMaxWidth().testTag("post_card_${post.id}"),
        accentColor = cardAccent,
        useGlass = false,
        contentPadding = PaddingValues(14.dp)
    ) {
        // Post Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .weight(1f)
                    .clickable(enabled = post.authorId.isNotBlank()) { onOpenUserProfile(post.authorId) }
            ) {
                ArkAvatarBadge(
                    avatarPreset = post.authorAvatar,
                    username = post.authorUsername,
                    imageBase64 = post.authorAvatarBase64,
                    size = 40.dp
                )
                Spacer(Modifier.width(10.dp))
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "@${post.authorUsername}",
                            style = MaterialTheme.typography.titleSmall,
                            color = colors.ink,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(Modifier.width(6.dp))
                        Icon(
                            imageVector = when (post.visibility) {
                                "public" -> Icons.Default.Public
                                "group" -> Icons.Default.Groups
                                "followers" -> Icons.Default.Person
                                else -> Icons.Default.Lock
                            },
                            contentDescription = "Visibility: ${post.visibility}",
                            tint = colors.accent,
                            modifier = Modifier.size(13.dp)
                        )
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (!post.locationLabel.isNullOrBlank()) {
                            Icon(
                                Icons.Default.LocationOn,
                                contentDescription = null,
                                tint = colors.ink3,
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(Modifier.width(2.dp))
                            Text(
                                text = "${post.locationLabel} • ",
                                style = MaterialTheme.typography.bodySmall,
                                color = colors.ink2,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        Text(
                            text = "${formatPostTimestamp(post.createdAt)} • ${post.category}" +
                                if (post.groupNames.isNotEmpty()) " • ${post.groupNames.first()}" else "",
                            style = MaterialTheme.typography.bodySmall,
                            color = colors.ink2,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            Box {
                IconButton(
                    onClick = { menuExpanded = true },
                    modifier = Modifier.testTag("post_more_${post.id}")
                ) {
                    Icon(Icons.Default.MoreVert, contentDescription = "More post options", tint = colors.ink2)
                }
                DropdownMenu(expanded = menuExpanded, onDismissRequest = { menuExpanded = false }) {
                    if (isOwner) {
                        DropdownMenuItem(
                            text = { Text("Edit Caption") },
                            leadingIcon = { Icon(Icons.Default.Edit, contentDescription = null) },
                            onClick = { menuExpanded = false; onEditCaption() }
                        )
                        DropdownMenuItem(
                            text = { Text(if (post.commentsDisabled) "Enable Comments" else "Disable Comments") },
                            leadingIcon = { Icon(Icons.Outlined.ChatBubbleOutline, contentDescription = null) },
                            onClick = { menuExpanded = false; onToggleCommentsDisabled() }
                        )
                        DropdownMenuItem(
                            text = { Text("Delete Post", color = colors.coral) },
                            leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = colors.coral) },
                            onClick = { menuExpanded = false; onDeletePost() }
                        )
                    } else {
                        DropdownMenuItem(
                            text = { Text("Hide Post") },
                            leadingIcon = { Icon(Icons.Default.VisibilityOff, contentDescription = null) },
                            onClick = { menuExpanded = false; onHidePost() }
                        )
                        DropdownMenuItem(
                            text = { Text("Mute @${post.authorUsername}") },
                            leadingIcon = { Icon(Icons.AutoMirrored.Filled.VolumeOff, contentDescription = null) },
                            onClick = { menuExpanded = false; onMuteAuthor() }
                        )
                        DropdownMenuItem(
                            text = { Text("Report Post", color = colors.coral) },
                            leadingIcon = { Icon(Icons.Default.Flag, contentDescription = null, tint = colors.coral) },
                            onClick = { menuExpanded = false; onReportPost() }
                        )
                    }
                }
            }
        }

        // Special ARK Post Type Banner (Game / Challenge / Group Memory)
        when (post.postType) {
            "game_result" -> {
                Spacer(Modifier.height(10.dp))
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = colors.violet.copy(alpha = 0.16f),
                    border = BorderStroke(1.dp, colors.violet.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.SportsEsports, contentDescription = null, tint = colors.violet, modifier = Modifier.size(28.dp))
                        Spacer(Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(post.metaGameName ?: "ARK Party Game", style = MaterialTheme.typography.titleSmall, color = colors.textPrimary)
                            if (!post.metaWinner.isNullOrBlank()) {
                                Text("Winner: ${post.metaWinner}", style = MaterialTheme.typography.labelMedium, color = colors.gold)
                            }
                            if (!post.metaScoreLabel.isNullOrBlank()) {
                                Text(post.metaScoreLabel, style = MaterialTheme.typography.bodySmall, color = colors.textSecondary)
                            }
                        }
                        if (!post.metaBadge.isNullOrBlank()) {
                            UserBadgeChip(label = post.metaBadge, accent = colors.gold)
                        }
                    }
                }
            }

            "challenge_result" -> {
                Spacer(Modifier.height(10.dp))
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = colors.emerald.copy(alpha = 0.15f),
                    border = BorderStroke(1.dp, colors.emerald.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = colors.emerald, modifier = Modifier.size(28.dp))
                        Spacer(Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(post.metaGameName ?: "IRL Challenge Completed", style = MaterialTheme.typography.titleSmall, color = colors.textPrimary)
                            if (!post.metaScoreLabel.isNullOrBlank()) {
                                Text(post.metaScoreLabel, style = MaterialTheme.typography.labelMedium, color = colors.emerald)
                            }
                        }
                        if (!post.metaBadge.isNullOrBlank()) {
                            UserBadgeChip(label = post.metaBadge, accent = colors.gold)
                        }
                    }
                }
            }

            "group_memory" -> {
                Spacer(Modifier.height(8.dp))
                UserBadgeChip(
                    label = "Squad Memory${post.groupNames.firstOrNull()?.let { " • $it" } ?: ""}",
                    accent = colors.gold
                )
            }
        }

        // Caption + Hashtags + Tagged pill
        if (post.caption.isNotBlank()) {
            Spacer(Modifier.height(10.dp))
            Text(
                text = post.caption,
                style = if (post.postType == "text" && post.imageBase64List.isEmpty()) {
                    MaterialTheme.typography.titleMedium
                } else {
                    MaterialTheme.typography.bodyLarge
                },
                color = colors.ink
            )
        }
        if (post.hashtags.isNotEmpty()) {
            Spacer(Modifier.height(6.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                post.hashtags.take(6).forEach { tag ->
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = colors.accentSoft,
                        modifier = Modifier.clickable { onHashtagClick(tag) }
                    ) {
                        Text(
                            text = "#$tag",
                            style = MaterialTheme.typography.labelMedium,
                            color = colors.accent,
                            modifier = Modifier.padding(horizontal = 9.dp, vertical = 3.dp)
                        )
                    }
                }
            }
        }
        if (post.approvedTagUids.isNotEmpty()) {
            Spacer(Modifier.height(6.dp))
            Surface(
                shape = RoundedCornerShape(50),
                color = colors.surfaceSecondary,
                modifier = Modifier.clickable {
                    post.approvedTagUids.firstOrNull()?.let { onOpenUserProfile(it) }
                }
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Person, contentDescription = null, tint = colors.ink2, modifier = Modifier.size(13.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(
                        text = "${post.approvedTagUids.size} friend${if (post.approvedTagUids.size == 1) "" else "s"} tagged",
                        style = MaterialTheme.typography.labelSmall,
                        color = colors.ink2
                    )
                }
            }
        }

        // Photo Carousel with Double-Tap Like + ALT text badge
        if (post.imageBase64List.isNotEmpty()) {
            Spacer(Modifier.height(10.dp))
            val pagerState = rememberPagerState(pageCount = { post.imageBase64List.size })
            val currentAlt = post.altTexts.getOrNull(pagerState.currentPage)?.takeIf { it.isNotBlank() }
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1.18f)
                    .clip(RoundedCornerShape(16.dp))
                    .background(colors.surfaceSecondary)
                    .pointerInput(post.id) {
                        detectTapGestures(
                            onDoubleTap = {
                                showHeartBurst = true
                                if (myReaction == null) onReaction("love")
                            },
                            onTap = { onOpenMedia(pagerState.currentPage) }
                        )
                    }
            ) {
                HorizontalPager(
                    state = pagerState,
                    modifier = Modifier.fillMaxSize()
                ) { page ->
                    val b64 = post.imageBase64List[page]
                    val bmp = rememberDecodedImageBitmap(b64)
                    if (bmp != null) {
                        Image(
                            bitmap = bmp,
                            contentDescription = post.altTexts.getOrNull(page)?.takeIf { it.isNotBlank() }
                                ?: "Post photo ${page + 1}",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    }
                }

                if (post.imageBase64List.size > 1) {
                    Surface(
                        color = Color.Black.copy(alpha = 0.58f),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(10.dp)
                    ) {
                        Text(
                            text = "${pagerState.currentPage + 1}/${post.imageBase64List.size}",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }

                if (currentAlt != null) {
                    Surface(
                        color = Color.Black.copy(alpha = 0.65f),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(10.dp)
                            .clickable { showAltOverlay = !showAltOverlay }
                    ) {
                        Text(
                            text = if (showAltOverlay) "ALT: $currentAlt" else "ALT",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }

                androidx.compose.animation.AnimatedVisibility(
                    visible = showHeartBurst,
                    enter = fadeIn() + scaleIn(initialScale = 0.4f),
                    exit = fadeOut() + scaleOut(targetScale = 1.4f),
                    modifier = Modifier.align(Alignment.Center)
                ) {
                    Icon(
                        imageVector = Icons.Default.Favorite,
                        contentDescription = null,
                        tint = colors.coral,
                        modifier = Modifier.size(84.dp)
                    )
                }
            }
            if (post.imageBase64List.size > 1) {
                Spacer(Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center
                ) {
                    repeat(post.imageBase64List.size) { idx ->
                        val active = idx == pagerState.currentPage
                        Box(
                            modifier = Modifier
                                .padding(horizontal = 3.dp)
                                .size(if (active) 7.dp else 5.dp)
                                .clip(CircleShape)
                                .background(if (active) colors.accent else colors.ink3.copy(alpha = 0.4f))
                        )
                    }
                }
            }
        }

        // Video Thumbnail & Play Trigger
        if (post.postType == "video" && !post.videoThumbnailBase64.isNullOrBlank()) {
            Spacer(Modifier.height(10.dp))
            val thumbBmp = rememberDecodedImageBitmap(post.videoThumbnailBase64)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1.33f)
                    .clip(RoundedCornerShape(18.dp))
                    .background(Color.Black)
                    .clickable { onOpenMedia(0) },
                contentAlignment = Alignment.Center
            ) {
                if (thumbBmp != null) {
                    Image(
                        bitmap = thumbBmp,
                        contentDescription = "Play post video",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                }
                Box(
                    modifier = Modifier
                        .size(62.dp)
                        .clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.62f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = "Play Video", tint = Color.White, modifier = Modifier.size(36.dp))
                }
                if (post.videoDurationMs > 0L) {
                    Surface(
                        color = Color.Black.copy(alpha = 0.65f),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.align(Alignment.BottomEnd).padding(10.dp)
                    ) {
                        Text(
                            text = "${(post.videoDurationMs / 1000L).coerceAtLeast(1L)}s",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        }

        // Live Poll Post UI
        if (post.postType == "poll" && !post.pollOptions.isNullOrEmpty()) {
            Spacer(Modifier.height(10.dp))
            val voteCounts = post.pollVoteCounts ?: emptyMap()
            val totalVotes = voteCounts.values.sum()
            val expired = post.pollExpiresAt != null && post.pollExpiresAt.seconds * 1000L < System.currentTimeMillis()
            val showResults = myPollVote != null || expired || post.authorId == currentUserId

            Surface(
                shape = RoundedCornerShape(16.dp),
                color = colors.glassSurfaceElevated,
                border = BorderStroke(1.dp, colors.cyan.copy(alpha = 0.35f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Poll, contentDescription = null, tint = colors.cyan, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(post.pollQuestion ?: "Community Poll", style = MaterialTheme.typography.titleSmall, color = colors.textPrimary)
                    }
                    post.pollOptions.forEachIndexed { idx, optLabel ->
                        val count = voteCounts[idx.toString()] ?: 0L
                        val pct = if (totalVotes > 0L) ((count * 100L) / totalVotes).toInt() else 0
                        val picked = myPollVote == idx
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .clickable(enabled = myPollVote == null && !expired) { onVotePoll(idx) },
                            shape = RoundedCornerShape(12.dp),
                            color = if (picked) colors.cyan.copy(alpha = 0.18f) else Color.Transparent,
                            border = BorderStroke(1.dp, if (picked) colors.cyan else colors.glassBorder)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(optLabel, style = MaterialTheme.typography.bodyMedium, color = colors.textPrimary, modifier = Modifier.weight(1f))
                                    if (showResults) {
                                        Text("$pct%", style = MaterialTheme.typography.labelLarge, color = colors.cyan)
                                    }
                                }
                                if (showResults) {
                                    Spacer(Modifier.height(5.dp))
                                    LinearProgressIndicator(
                                        progress = { (pct / 100f).coerceIn(0f, 1f) },
                                        modifier = Modifier.fillMaxWidth().height(5.dp).clip(RoundedCornerShape(3.dp)),
                                        color = if (picked) colors.cyan else colors.violet
                                    )
                                }
                            }
                        }
                    }
                    Text(
                        text = "$totalVotes vote${if (totalVotes == 1L) "" else "s"}" + if (expired) " • Poll ended" else "",
                        style = MaterialTheme.typography.labelSmall,
                        color = colors.textSecondary
                    )
                }
            }
        }

        // Reaction Summary Pills (clickable for Likers List)
        if (post.reactionCounts.isNotEmpty()) {
            Spacer(Modifier.height(8.dp))
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.clickable { onOpenLikers() }
            ) {
                post.reactionCounts.entries.filter { it.value > 0L }.take(4).forEach { (key, count) ->
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = colors.surfaceSecondary,
                        border = BorderStroke(1.dp, colors.hairline)
                    ) {
                        Text(
                            text = "${ArkFeedIds.reactionEmoji(key)} $count",
                            style = MaterialTheme.typography.labelSmall,
                            color = colors.ink,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }
            }
        }

        // Reaction Picker Bar (toggleable)
        AnimatedVisibility(visible = showReactionBar) {
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = colors.glass,
                border = BorderStroke(1.dp, colors.glassLine),
                modifier = Modifier.padding(top = 8.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    ArkFeedIds.reactionOptions.forEach { (key, emoji) ->
                        val active = myReaction == key
                        Surface(
                            shape = CircleShape,
                            color = if (active) colors.accentSoft else Color.Transparent,
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .clickable {
                                    showReactionBar = false
                                    onReaction(key)
                                }
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(emoji, fontSize = 18.sp)
                            }
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(8.dp))

        // Interaction Action Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = { onReaction(myReaction ?: "love") },
                    modifier = Modifier.testTag("like_button_${post.id}")
                ) {
                    Icon(
                        imageVector = if (myReaction != null) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                        contentDescription = "Like post",
                        tint = if (myReaction != null) colors.coral else colors.ink,
                        modifier = Modifier.scale(likeScale)
                    )
                }
                Text(
                    text = post.likeCount.toString(),
                    style = MaterialTheme.typography.labelLarge,
                    color = colors.ink,
                    modifier = Modifier
                        .clickable { onOpenLikers() }
                        .padding(horizontal = 4.dp, vertical = 6.dp)
                )

                IconButton(
                    onClick = { showReactionBar = !showReactionBar },
                    modifier = Modifier.testTag("react_picker_${post.id}")
                ) {
                    Icon(
                        Icons.Outlined.AddReaction,
                        contentDescription = "Choose reaction",
                        tint = colors.textSecondary
                    )
                }

                IconButton(
                    onClick = onOpenComments,
                    modifier = Modifier.testTag("comment_button_${post.id}")
                ) {
                    Icon(
                        Icons.Outlined.ChatBubbleOutline,
                        contentDescription = "Comments",
                        tint = if (post.commentsDisabled) colors.textSecondary.copy(alpha = 0.4f) else colors.textPrimary
                    )
                }
                Text(
                    text = post.commentCount.toString(),
                    style = MaterialTheme.typography.labelLarge,
                    color = colors.textPrimary
                )

                IconButton(
                    onClick = onShare,
                    modifier = Modifier.testTag("share_button_${post.id}")
                ) {
                    Icon(
                        Icons.AutoMirrored.Filled.Send,
                        contentDescription = "Share post",
                        tint = colors.textPrimary
                    )
                }
            }

            IconButton(
                onClick = onToggleBookmark,
                modifier = Modifier.testTag("bookmark_button_${post.id}")
            ) {
                Icon(
                    imageVector = if (isBookmarked) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder,
                    contentDescription = if (isBookmarked) "Remove bookmark" else "Save post",
                    tint = if (isBookmarked) colors.gold else colors.textSecondary
                )
            }
        }
    }
}

@Composable
fun PostSkeletonCard(modifier: Modifier = Modifier) {
    val colors = ArkThemeTokens.colors
    LiquidGlassCard(modifier = modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(colors.glassBorder.copy(alpha = 0.3f))
            )
            Spacer(Modifier.width(10.dp))
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Box(
                    modifier = Modifier
                        .width(120.dp)
                        .height(12.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(colors.glassBorder.copy(alpha = 0.3f))
                )
                Box(
                    modifier = Modifier
                        .width(80.dp)
                        .height(10.dp)
                        .clip(RoundedCornerShape(5.dp))
                        .background(colors.glassBorder.copy(alpha = 0.2f))
                )
            }
        }
        Spacer(Modifier.height(12.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(160.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(
                    Brush.linearGradient(
                        listOf(
                            colors.glassBorder.copy(alpha = 0.22f),
                            colors.glassHighlight.copy(alpha = 0.14f)
                        )
                    )
                )
        )
    }
}
