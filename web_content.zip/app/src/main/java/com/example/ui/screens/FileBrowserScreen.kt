package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.DriveFileMove
import androidx.compose.material.icons.automirrored.filled.ViewList
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.NoteAdd
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.SwipeToDismissBox
import androidx.compose.material3.SwipeToDismissBoxValue
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.material3.rememberSwipeToDismissBoxState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.core.ByteSizeFormatter
import com.example.data.local.UserSettingsState
import com.example.data.model.BreadcrumbSegment
import com.example.data.model.BrowserViewMode
import com.example.data.model.FileKind
import com.example.data.model.FileNode
import com.example.data.model.SortField
import com.example.ui.components.FileDetailsBottomSheet
import com.example.ui.components.FileList
import com.example.ui.components.FileTypeThumbnail
import com.example.ui.components.TextPromptDialog
import com.example.ui.theme.LocalAnimationSpecs
import com.example.ui.viewmodel.ClipboardState

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun FileBrowserScreen(
    titleOverride: String? = null,
    breadcrumbs: List<BreadcrumbSegment>,
    items: List<FileNode>,
    selectedPaths: Set<String>,
    clipboard: ClipboardState?,
    settings: UserSettingsState,
    isRefreshing: Boolean,
    onBack: () -> Unit,
    onNavigateBreadcrumb: (String) -> Unit,
    onRefresh: () -> Unit,
    onOpenNode: (FileNode) -> Unit,
    onToggleSelect: (String) -> Unit,
    onSelectAll: () -> Unit,
    onClearSelection: () -> Unit,
    onChangeViewMode: (BrowserViewMode) -> Unit,
    onChangeSort: (SortField, Boolean) -> Unit,
    onToggleShowHidden: (Boolean) -> Unit,
    onCreateFolder: (String) -> Unit,
    onCreateTextNote: (String, String) -> Unit,
    onOpenCameraHere: () -> Unit,
    onOpenSearch: () -> Unit,
    onShareSelected: () -> Unit,
    onCopySelected: () -> Unit,
    onMoveSelected: () -> Unit,
    onPasteHere: () -> Unit,
    onCancelClipboard: () -> Unit,
    onDeleteSelected: () -> Unit,
    onSwipeDeleteSingle: (FileNode) -> Unit,
    onRenameNode: (FileNode, String) -> Unit,
    onCompressSelected: (String) -> Unit,
    onExtractZip: (FileNode) -> Unit,
    onToggleFavorite: (FileNode) -> Unit,
    onToggleHideNode: (FileNode) -> Unit,
    onAddShortcut: (FileNode) -> Unit
) {
    BackHandler(onBack = onBack)
    val animSpecs = LocalAnimationSpecs.current
    val inSelectionMode = selectedPaths.isNotEmpty()

    var showTopMenu by remember { mutableStateOf(false) }
    var showSortSheet by remember { mutableStateOf(false) }
    var showCreateMenu by remember { mutableStateOf(false) }
    var showNewFolderDialog by remember { mutableStateOf(false) }
    var showNewNoteDialog by remember { mutableStateOf(false) }
    var renameTarget by remember { mutableStateOf<FileNode?>(null) }
    var showZipDialog by remember { mutableStateOf(false) }
    var detailsTarget by remember { mutableStateOf<FileNode?>(null) }
    var showBottomMoreMenu by remember { mutableStateOf(false) }

    val folderCount = items.count { it.isDirectory }
    val fileCount = items.count { !it.isDirectory }
    val singleSelectedNode = if (selectedPaths.size == 1) {
        items.find { it.path == selectedPaths.first() }
    } else null

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    if (inSelectionMode) {
                        Text(
                            "${selectedPaths.size} selected",
                            fontWeight = FontWeight.Bold
                        )
                    } else {
                        Column {
                            Text(
                                text = titleOverride ?: breadcrumbs.lastOrNull()?.label ?: "Browser",
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "$folderCount folder(s), $fileCount file(s)",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                navigationIcon = {
                    if (inSelectionMode) {
                        IconButton(onClick = onClearSelection) {
                            Icon(Icons.Filled.Close, contentDescription = "Cancel selection")
                        }
                    } else {
                        IconButton(onClick = onBack, modifier = Modifier.testTag("browser_back_button")) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                        }
                    }
                },
                actions = {
                    if (inSelectionMode) {
                        IconButton(
                            onClick = onSelectAll,
                            modifier = Modifier.testTag("browser_select_all_button")
                        ) {
                            Icon(Icons.Filled.DoneAll, contentDescription = "Select all")
                        }
                    } else {
                        IconButton(onClick = onOpenSearch) {
                            Icon(Icons.Filled.Search, contentDescription = "Search")
                        }
                        IconButton(onClick = { showSortSheet = true }) {
                            Icon(Icons.Filled.Sort, contentDescription = "Sort options")
                        }
                        Box {
                            IconButton(
                                onClick = { showTopMenu = true },
                                modifier = Modifier.testTag("browser_more_button")
                            ) {
                                Icon(Icons.Filled.MoreVert, contentDescription = "More options")
                            }
                            DropdownMenu(
                                expanded = showTopMenu,
                                onDismissRequest = { showTopMenu = false }
                            ) {
                                DropdownMenuItem(
                                    text = { Text("Create folder") },
                                    leadingIcon = { Icon(Icons.Filled.CreateNewFolder, contentDescription = null) },
                                    onClick = {
                                        showTopMenu = false
                                        showNewFolderDialog = true
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("View: List") },
                                    leadingIcon = { Icon(Icons.AutoMirrored.Filled.ViewList, contentDescription = null) },
                                    onClick = {
                                        showTopMenu = false
                                        onChangeViewMode(BrowserViewMode.LIST)
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("View: Grid") },
                                    leadingIcon = { Icon(Icons.Filled.GridView, contentDescription = null) },
                                    onClick = {
                                        showTopMenu = false
                                        onChangeViewMode(BrowserViewMode.GRID)
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("View: Detail") },
                                    leadingIcon = { Icon(Icons.Filled.Info, contentDescription = null) },
                                    onClick = {
                                        showTopMenu = false
                                        onChangeViewMode(BrowserViewMode.DETAIL)
                                    }
                                )
                                DropdownMenuItem(
                                    text = {
                                        Text(if (settings.showHiddenFiles) "Hide hidden files" else "Show hidden files")
                                    },
                                    leadingIcon = {
                                        Icon(
                                            if (settings.showHiddenFiles) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                                            contentDescription = null
                                        )
                                    },
                                    onClick = {
                                        showTopMenu = false
                                        onToggleShowHidden(!settings.showHiddenFiles)
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("Refresh") },
                                    leadingIcon = { Icon(Icons.Filled.Refresh, contentDescription = null) },
                                    onClick = {
                                        showTopMenu = false
                                        onRefresh()
                                    }
                                )
                            }
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        floatingActionButton = {
            if (!inSelectionMode && titleOverride == null) {
                Box {
                    FloatingActionButton(
                        onClick = { showCreateMenu = true },
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary,
                        modifier = Modifier.testTag("browser_fab_add")
                    ) {
                        Icon(Icons.Filled.Add, contentDescription = "Create or capture")
                    }
                    DropdownMenu(
                        expanded = showCreateMenu,
                        onDismissRequest = { showCreateMenu = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("Create folder") },
                            leadingIcon = { Icon(Icons.Filled.CreateNewFolder, contentDescription = null) },
                            onClick = {
                                showCreateMenu = false
                                showNewFolderDialog = true
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("New text document") },
                            leadingIcon = { Icon(Icons.Filled.NoteAdd, contentDescription = null) },
                            onClick = {
                                showCreateMenu = false
                                showNewNoteDialog = true
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Capture photo / video here") },
                            leadingIcon = { Icon(Icons.Filled.CameraAlt, contentDescription = null) },
                            onClick = {
                                showCreateMenu = false
                                onOpenCameraHere()
                            }
                        )
                    }
                }
            }
        },
        bottomBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .windowInsetsPadding(WindowInsets.navigationBars)
            ) {
                // Copy/Move "Paste here" Floating Bar
                AnimatedVisibility(
                    visible = clipboard != null && !inSelectionMode && titleOverride == null,
                    enter = animSpecs.bottomBarEnter(),
                    exit = animSpecs.bottomBarExit()
                ) {
                    if (clipboard != null) {
                        Surface(
                            color = MaterialTheme.colorScheme.primaryContainer,
                            shape = RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp),
                            tonalElevation = 6.dp,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 18.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "${clipboard.sourcePaths.size} item(s) to ${if (clipboard.isMove) "move" else "copy"}",
                                    style = MaterialTheme.typography.titleSmall
                                )
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    TextButton(onClick = onCancelClipboard) {
                                        Text("Cancel")
                                    }
                                    Button(
                                        onClick = onPasteHere,
                                        modifier = Modifier.testTag("paste_here_button")
                                    ) {
                                        Icon(Icons.Filled.ContentPaste, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text(if (clipboard.isMove) "Move here" else "Copy here")
                                    }
                                }
                            }
                        }
                    }
                }

                // Multi-Select One UI Bottom Action Bar
                AnimatedVisibility(
                    visible = inSelectionMode,
                    enter = animSpecs.bottomBarEnter(),
                    exit = animSpecs.bottomBarExit()
                ) {
                    Surface(
                        color = MaterialTheme.colorScheme.surface,
                        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
                        tonalElevation = 8.dp,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 8.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceEvenly,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            BottomActionItem(Icons.Filled.Share, "Share", "action_share", onShareSelected)
                            BottomActionItem(Icons.Filled.ContentCopy, "Copy", "action_copy", onCopySelected)
                            BottomActionItem(Icons.AutoMirrored.Filled.DriveFileMove, "Move", "action_move", onMoveSelected)
                            BottomActionItem(Icons.Filled.Delete, "Delete", "action_delete", onDeleteSelected)
                            if (singleSelectedNode != null) {
                                BottomActionItem(
                                    Icons.Filled.Edit,
                                    "Rename",
                                    "action_rename"
                                ) { renameTarget = singleSelectedNode }
                            }
                            Box {
                                BottomActionItem(
                                    Icons.Filled.MoreVert,
                                    "More",
                                    "action_more"
                                ) { showBottomMoreMenu = true }
                                DropdownMenu(
                                    expanded = showBottomMoreMenu,
                                    onDismissRequest = { showBottomMoreMenu = false }
                                ) {
                                    DropdownMenuItem(
                                        text = { Text("Compress to ZIP") },
                                        leadingIcon = { Icon(Icons.Filled.FolderZip, contentDescription = null) },
                                        onClick = {
                                            showBottomMoreMenu = false
                                            showZipDialog = true
                                        }
                                    )
                                    if (singleSelectedNode?.kind == FileKind.ZIP) {
                                        DropdownMenuItem(
                                            text = { Text("Extract ZIP here") },
                                            leadingIcon = { Icon(Icons.Filled.FolderOpen, contentDescription = null) },
                                            onClick = {
                                                showBottomMoreMenu = false
                                                onExtractZip(singleSelectedNode)
                                            }
                                        )
                                    }
                                    if (singleSelectedNode != null) {
                                        DropdownMenuItem(
                                            text = { Text("Details") },
                                            leadingIcon = { Icon(Icons.Filled.Info, contentDescription = null) },
                                            onClick = {
                                                showBottomMoreMenu = false
                                                detailsTarget = singleSelectedNode
                                            }
                                        )
                                        DropdownMenuItem(
                                            text = {
                                                Text(if (singleSelectedNode.isFavorite) "Remove from Favorites" else "Add to Favorites")
                                            },
                                            leadingIcon = { Icon(Icons.Filled.Star, contentDescription = null) },
                                            onClick = {
                                                showBottomMoreMenu = false
                                                onToggleFavorite(singleSelectedNode)
                                            }
                                        )
                                        DropdownMenuItem(
                                            text = { Text("Add shortcut") },
                                            onClick = {
                                                showBottomMoreMenu = false
                                                onAddShortcut(singleSelectedNode)
                                            }
                                        )
                                        DropdownMenuItem(
                                            text = { Text(if (singleSelectedNode.isHidden) "Unhide item" else "Hide item") },
                                            onClick = {
                                                showBottomMoreMenu = false
                                                onToggleHideNode(singleSelectedNode)
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Breadcrumb Path Bar
            if (titleOverride == null && breadcrumbs.isNotEmpty()) {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    items(breadcrumbs.size) { index ->
                        val seg = breadcrumbs[index]
                        val isLast = index == breadcrumbs.lastIndex
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = seg.label,
                                style = MaterialTheme.typography.labelLarge,
                                color = if (isLast) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                fontWeight = if (isLast) FontWeight.Bold else FontWeight.Medium,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable { onNavigateBreadcrumb(seg.path) }
                                    .padding(horizontal = 6.dp, vertical = 4.dp)
                            )
                            if (!isLast) {
                                Icon(
                                    Icons.Filled.ChevronRight,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }
            }

            PullToRefreshBox(
                isRefreshing = isRefreshing,
                onRefresh = onRefresh,
                modifier = Modifier.fillMaxSize()
            ) {
                if (items.isEmpty() && !isRefreshing) {
                    EmptyFolderPlaceholder(
                        showActions = titleOverride == null,
                        onCreateFolder = { showNewFolderDialog = true },
                        onOpenCamera = onOpenCameraHere
                    )
                } else if (settings.viewMode == BrowserViewMode.GRID) {
                    LazyVerticalGrid(
                        columns = GridCells.Adaptive(minSize = 112.dp),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(items, key = { it.path }) { node ->
                            val selected = node.path in selectedPaths
                            GridFileItem(
                                node = node,
                                selected = selected,
                                inSelectionMode = inSelectionMode,
                                showExtensions = settings.showFileExtensions,
                                onClick = {
                                    if (inSelectionMode) onToggleSelect(node.path) else onOpenNode(node)
                                },
                                onLongClick = { onToggleSelect(node.path) },
                                modifier = Modifier.animateItem(placementSpec = animSpecs.placementSpec())
                            )
                        }
                    }
                } else {
                    FileList(
                        items = items,
                        selectedPaths = selectedPaths,
                        inSelectionMode = inSelectionMode,
                        isDetailMode = settings.viewMode == BrowserViewMode.DETAIL,
                        showExtensions = settings.showFileExtensions,
                        onItemClick = { node ->
                            if (inSelectionMode) onToggleSelect(node.path) else onOpenNode(node)
                        },
                        onItemLongClick = { node -> onToggleSelect(node.path) },
                        onShowDetails = { node -> detailsTarget = node },
                        onSwipeDelete = { node -> onSwipeDeleteSingle(node) },
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }
        }
    }

    if (showNewFolderDialog) {
        TextPromptDialog(
            title = "Create folder",
            initialValue = "",
            placeholder = "Folder name",
            confirmLabel = "Create",
            onConfirm = {
                showNewFolderDialog = false
                onCreateFolder(it)
            },
            onDismiss = { showNewFolderDialog = false }
        )
    }

    if (showNewNoteDialog) {
        NewTextDocumentDialog(
            onSave = { name, body ->
                showNewNoteDialog = false
                onCreateTextNote(name, body)
            },
            onDismiss = { showNewNoteDialog = false }
        )
    }

    if (renameTarget != null) {
        val target = renameTarget!!
        TextPromptDialog(
            title = "Rename item",
            initialValue = target.name,
            placeholder = "New name",
            confirmLabel = "Rename",
            onConfirm = { newName ->
                renameTarget = null
                onRenameNode(target, newName)
            },
            onDismiss = { renameTarget = null }
        )
    }

    if (showZipDialog) {
        val defaultName = singleSelectedNode?.name?.substringBeforeLast('.') ?: "Archive"
        TextPromptDialog(
            title = "Compress to ZIP",
            initialValue = "$defaultName.zip",
            placeholder = "Archive.zip",
            confirmLabel = "Compress",
            onConfirm = { zipName ->
                showZipDialog = false
                onCompressSelected(zipName)
            },
            onDismiss = { showZipDialog = false }
        )
    }

    if (detailsTarget != null) {
        FileDetailsBottomSheet(
            node = detailsTarget!!,
            onDismiss = { detailsTarget = null }
        )
    }

    if (showSortSheet) {
        SortOptionsBottomSheet(
            currentField = settings.sortField,
            ascending = settings.sortAscending,
            onApply = { field, asc ->
                showSortSheet = false
                onChangeSort(field, asc)
            },
            onDismiss = { showSortSheet = false }
        )
    }
}



@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun GridFileItem(
    node: FileNode,
    selected: Boolean,
    inSelectionMode: Boolean,
    showExtensions: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val bg = if (selected) {
        MaterialTheme.colorScheme.primaryContainer
    } else {
        MaterialTheme.colorScheme.surface
    }

    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = bg),
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
    ) {
        Box(modifier = Modifier.padding(12.dp)) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                FileTypeThumbnail(node = node, size = 64.dp)
                Spacer(Modifier.height(8.dp))
                Text(
                    text = node.displayName(showExtensions),
                    style = MaterialTheme.typography.labelLarge,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = if (node.isDirectory) "Folder" else ByteSizeFormatter.format(node.sizeBytes),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            if (inSelectionMode) {
                Icon(
                    imageVector = if (selected) Icons.Filled.CheckCircle else Icons.Filled.RadioButtonUnchecked,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .size(20.dp)
                )
            }
        }
    }
}

@Composable
private fun BottomActionItem(
    icon: ImageVector,
    label: String,
    testTag: String,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 6.dp)
            .testTag(testTag)
    ) {
        Icon(icon, contentDescription = label, modifier = Modifier.size(22.dp))
        Spacer(Modifier.height(2.dp))
        Text(label, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun EmptyFolderPlaceholder(
    showActions: Boolean,
    onCreateFolder: () -> Unit,
    onOpenCamera: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Surface(
            color = MaterialTheme.colorScheme.surfaceVariant,
            shape = RoundedCornerShape(28.dp),
            modifier = Modifier.size(80.dp)
        ) {
            Icon(
                Icons.Filled.FolderOpen,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(20.dp)
            )
        }
        Spacer(Modifier.height(16.dp))
        Text("No files", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(4.dp))
        Text(
            "This folder is currently empty.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        if (showActions) {
            Spacer(Modifier.height(18.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = onCreateFolder) {
                    Icon(Icons.Filled.CreateNewFolder, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("New folder")
                }
                TextButton(onClick = onOpenCamera) {
                    Icon(Icons.Filled.CameraAlt, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Camera")
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SortOptionsBottomSheet(
    currentField: SortField,
    ascending: Boolean,
    onApply: (SortField, Boolean) -> Unit,
    onDismiss: () -> Unit
) {
    var field by remember { mutableStateOf(currentField) }
    var asc by remember { mutableStateOf(ascending) }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("Sort by", style = MaterialTheme.typography.titleLarge)
            SortField.entries.forEach { option ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { field = option }
                        .padding(vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(selected = field == option, onClick = { field = option })
                    Spacer(Modifier.width(8.dp))
                    Text(option.label, style = MaterialTheme.typography.bodyLarge)
                }
            }
            HorizontalDivider()
            Text("Order", style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.clickable { asc = true }
                ) {
                    RadioButton(selected = asc, onClick = { asc = true })
                    Text("Ascending")
                }
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.clickable { asc = false }
                ) {
                    RadioButton(selected = !asc, onClick = { asc = false })
                    Text("Descending")
                }
            }
            Button(
                onClick = { onApply(field, asc) },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp, bottom = 16.dp)
            ) {
                Text("Done")
            }
        }
    }
}

@Composable
private fun NewTextDocumentDialog(
    onSave: (String, String) -> Unit,
    onDismiss: () -> Unit
) {
    var name by remember { mutableStateOf("Note.txt") }
    var content by remember { mutableStateOf("") }

    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New text document") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                androidx.compose.material3.OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("File name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                androidx.compose.material3.OutlinedTextField(
                    value = content,
                    onValueChange = { content = it },
                    label = { Text("Document contents") },
                    minLines = 4,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { if (name.isNotBlank()) onSave(name.trim(), content) },
                enabled = name.isNotBlank()
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
