package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.localization.AppLang
import com.example.localization.SjsStrings
import com.example.model.*
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.viewmodel.SearchFilters
import com.example.viewmodel.UiState
import java.util.Locale

@Composable
fun CustomerHomeScreen(
    lang: AppLang,
    filters: SearchFilters,
    providersState: UiState<List<SecurityProvider>>,
    servicesState: UiState<List<SecurityServiceListing>>,
    filteredProviders: List<SecurityProvider>,
    filteredServices: List<SecurityServiceListing>,
    isAdminUser: Boolean,
    onUpdateFilters: ((SearchFilters) -> SearchFilters) -> Unit,
    onSelectProvider: (SecurityProvider) -> Unit,
    onBookService: (SecurityProvider, SecurityServiceListing) -> Unit,
    onOpenSupportComplaint: () -> Unit,
    onBootstrapCatalog: () -> Unit
) {
    var showFilterSheet by remember { mutableStateOf(false) }

    val allProviders = (providersState as? UiState.Success)?.data ?: emptyList()
    val verifiedFeatured = remember(filteredProviders) {
        filteredProviders.filter { it.verifiedBadge }.sortedByDescending { it.featured }
    }
    val recentOffers = remember(filteredServices) {
        filteredServices.filter { it.discountPercent > 0 || !it.offerBadge.isNullOrBlank() }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(OffWhite),
        contentPadding = PaddingValues(bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Hero Banner + Search Bar
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(NavyDeep)
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(155.dp)
                        .clip(RoundedCornerShape(18.dp))
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.img_hero_banner),
                        contentDescription = "Smart Jones Security Hero Banner",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.horizontalGradient(
                                    colors = listOf(NavyDeep.copy(alpha = 0.88f), NavyDeep.copy(alpha = 0.2f))
                                )
                            )
                    )
                    Column(
                        modifier = Modifier
                            .align(Alignment.CenterStart)
                            .padding(16.dp)
                            .fillMaxWidth(0.78f),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Surface(color = OrangeBrand, shape = RoundedCornerShape(6.dp)) {
                            Text(
                                text = "AIRTEL MONEY • 0788016987",
                                style = MaterialTheme.typography.labelSmall,
                                color = PureWhite,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                        Text(
                            text = SjsStrings.t(
                                lang,
                                "Ulinzi wa Uhakika Popote Tanzania",
                                "Trusted Security Services Across Tanzania"
                            ),
                            style = MaterialTheme.typography.titleLarge,
                            color = PureWhite
                        )
                        Text(
                            text = SjsStrings.t(
                                lang,
                                "Linganisha bei, omba nukuu na lipa kwa usalama.",
                                "Compare prices, get quotes & pay securely."
                            ),
                            style = MaterialTheme.typography.bodySmall,
                            color = BorderGrey
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = filters.query,
                        onValueChange = { q -> onUpdateFilters { it.copy(query = q) } },
                        placeholder = {
                            Text(
                                SjsStrings.t(lang, "Tafuta kampuni, CCTV, Dar es Salaam...", "Search provider, CCTV, region..."),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        },
                        leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null, tint = OrangeBrand) },
                        trailingIcon = {
                            if (filters.query.isNotBlank()) {
                                IconButton(onClick = { onUpdateFilters { it.copy(query = "") } }) {
                                    Icon(Icons.Filled.Clear, contentDescription = "Clear search")
                                }
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = PureWhite,
                            unfocusedContainerColor = PureWhite,
                            focusedBorderColor = OrangeBrand,
                            unfocusedBorderColor = BorderGrey
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("home_search_input")
                    )

                    FilledTonalIconButton(
                        onClick = { showFilterSheet = true },
                        colors = IconButtonDefaults.filledTonalIconButtonColors(
                            containerColor = OrangeBrand,
                            contentColor = PureWhite
                        ),
                        modifier = Modifier
                            .size(54.dp)
                            .testTag("open_filters_button")
                    ) {
                        Icon(Icons.Filled.Tune, contentDescription = "Filters")
                    }
                }

                // Active filter pills
                val hasActiveFilters = filters.category != null || filters.location != null ||
                    filters.maxPriceTzs != null || filters.minRating > 0.0
                if (hasActiveFilters) {
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        filters.category?.let { cat ->
                            FilterChip(
                                selected = true,
                                onClick = { onUpdateFilters { it.copy(category = null) } },
                                label = { Text(SjsStrings.categoryLabel(cat, lang)) },
                                trailingIcon = { Icon(Icons.Filled.Close, null, Modifier.size(14.dp)) }
                            )
                        }
                        filters.location?.let { loc ->
                            FilterChip(
                                selected = true,
                                onClick = { onUpdateFilters { it.copy(location = null) } },
                                label = { Text(loc) },
                                trailingIcon = { Icon(Icons.Filled.Close, null, Modifier.size(14.dp)) }
                            )
                        }
                        filters.maxPriceTzs?.let { maxP ->
                            FilterChip(
                                selected = true,
                                onClick = { onUpdateFilters { it.copy(maxPriceTzs = null) } },
                                label = { Text("<= ${TzsFormatter.format(maxP)}") },
                                trailingIcon = { Icon(Icons.Filled.Close, null, Modifier.size(14.dp)) }
                            )
                        }
                        if (filters.minRating > 0.0) {
                            FilterChip(
                                selected = true,
                                onClick = { onUpdateFilters { it.copy(minRating = 0.0) } },
                                label = { Text("${filters.minRating}+ ★") },
                                trailingIcon = { Icon(Icons.Filled.Close, null, Modifier.size(14.dp)) }
                            )
                        }
                    }
                }
            }
        }

        // Admin quick bootstrap banner if empty catalog
        if (providersState is UiState.Success && allProviders.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.padding(horizontal = 16.dp),
                    colors = CardDefaults.cardColors(containerColor = OrangeContainer)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = SjsStrings.t(
                                lang,
                                "Soko linaanza! Bado hakuna makampuni yaliyosajiliwa.",
                                "Marketplace is ready! No security companies registered yet."
                            ),
                            style = MaterialTheme.typography.titleMedium,
                            color = NavyDeep
                        )
                        Text(
                            text = SjsStrings.t(
                                lang,
                                "Makampuni yanaweza kujisajili kwenye Akaunti ya Kampuni, au Admin anaweza kuweka makampuni ya awali.",
                                "Providers can register in Provider Console, or Admin can bootstrap verified Tanzania starter providers."
                            ),
                            style = MaterialTheme.typography.bodySmall,
                            color = CharcoalGrey
                        )
                        if (isAdminUser) {
                            Button(
                                onClick = onBootstrapCatalog,
                                colors = ButtonDefaults.buttonColors(containerColor = NavyDeep),
                                modifier = Modifier.testTag("home_bootstrap_catalog_button")
                            ) {
                                Text(SjsStrings.t(lang, "Weka Makampuni ya Mwanzo (Admin)", "Bootstrap Verified Catalog (Admin)"))
                            }
                        }
                    }
                }
            }
        }

        // 2. Security Service Categories (All 10)
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                SectionHeader(
                    title = SjsStrings.t(lang, "Huduma za Usalama (10)", "Security Service Categories"),
                    subtitle = SjsStrings.t(lang, "Chagua aina ya huduma unayohitaji", "Tap a category to filter providers")
                )
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(ServiceCategory.entries) { cat ->
                        val selected = filters.category == cat
                        Surface(
                            color = if (selected) NavyDeep else PureWhite,
                            contentColor = if (selected) PureWhite else DarkGrey,
                            shape = RoundedCornerShape(16.dp),
                            shadowElevation = 2.dp,
                            modifier = Modifier
                                .width(138.dp)
                                .clickable {
                                    onUpdateFilters {
                                        it.copy(category = if (selected) null else cat)
                                    }
                                }
                                .testTag("category_card_${cat.name}")
                        ) {
                            Column(
                                modifier = Modifier.padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Surface(
                                    color = if (selected) OrangeBrand else OrangeContainer,
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.size(38.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = categoryIcon(cat),
                                            contentDescription = null,
                                            tint = if (selected) PureWhite else OrangeBrand,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }
                                Text(
                                    text = SjsStrings.categoryLabel(cat, lang),
                                    style = MaterialTheme.typography.labelMedium,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }
        }

        // 3. Featured Verified Companies
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                SectionHeader(
                    title = SjsStrings.t(lang, "Kampuni Zilizothibitishwa", "Featured Verified Companies"),
                    subtitle = SjsStrings.t(lang, "Zimekaguliwa leseni na BRELA", "Verified PSRA & BRELA providers")
                )
                if (providersState is UiState.Loading) {
                    Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = OrangeBrand)
                    }
                } else if (verifiedFeatured.isEmpty()) {
                    EmptyStateCard(
                        icon = Icons.Filled.VerifiedUser,
                        message = SjsStrings.t(
                            lang,
                            "Hakuna kampuni zilizothibitishwa zinazolingana na utafutaji wako.",
                            "No verified companies match your current filters."
                        )
                    )
                } else {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(verifiedFeatured, key = { it.id }) { provider ->
                            ProviderFeaturedCard(
                                provider = provider,
                                lang = lang,
                                onClick = { onSelectProvider(provider) }
                            )
                        }
                    }
                }
            }
        }

        // 4. Recent Offers
        if (recentOffers.isNotEmpty()) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    SectionHeader(
                        title = SjsStrings.t(lang, "Ofa za Hivi Karibuni", "Recent Offers"),
                        subtitle = SjsStrings.t(lang, "Punguzo maalum kwa wateja", "Special discounts from verified companies")
                    )
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(recentOffers, key = { it.id }) { service ->
                            OfferCard(
                                service = service,
                                lang = lang,
                                onBook = {
                                    allProviders.firstOrNull { it.id == service.providerId }?.let { prov ->
                                        onBookService(prov, service)
                                    }
                                }
                            )
                        }
                    }
                }
            }
        }

        // 5. Popular Services
        item {
            SectionHeader(
                title = SjsStrings.t(lang, "Huduma Maarufu", "Popular Services"),
                subtitle = SjsStrings.t(lang, "Bofya kuomba nukuu au kuweka oda", "Tap to request quotation or book")
            )
        }

        if (filteredServices.isEmpty()) {
            item {
                EmptyStateCard(
                    icon = Icons.Filled.Security,
                    message = SjsStrings.t(
                        lang,
                        "Hakuna huduma zinazoonekana kwa vichujio ulivyochagua.",
                        "No services match the selected filters."
                    )
                )
            }
        } else {
            items(filteredServices, key = { it.id }) { service ->
                val provider = allProviders.firstOrNull { it.id == service.providerId }
                ServiceListingRowCard(
                    service = service,
                    lang = lang,
                    onClick = {
                        if (provider != null) onBookService(provider, service)
                    }
                )
            }
        }

        // All registered companies (including pending if searched)
        if (filteredProviders.any { !it.verifiedBadge }) {
            item {
                SectionHeader(
                    title = SjsStrings.t(lang, "Kampuni Nyingine Zinazosubiri Uhakiki", "Companies Pending Verification"),
                    subtitle = SjsStrings.t(lang, "Hazina beji ya uhakiki bado", "Awaiting Admin license verification")
                )
            }
            items(filteredProviders.filter { !it.verifiedBadge }, key = { "unv_${it.id}" }) { prov ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                        .clickable { onSelectProvider(prov) },
                    colors = CardDefaults.cardColors(containerColor = PureWhite)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(prov.companyName, style = MaterialTheme.typography.titleMedium, color = NavyDeep)
                            Text(prov.locations.joinToString(", "), style = MaterialTheme.typography.bodySmall, color = SlateGrey)
                        }
                        VerifiedBadgeChip(lang, verified = false)
                    }
                }
            }
        }

        // 6. Customer Support Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                colors = CardDefaults.cardColors(containerColor = NavyDeep),
                shape = RoundedCornerShape(18.dp)
            ) {
                Row(
                    modifier = Modifier.padding(18.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Surface(
                        color = OrangeBrand,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.size(48.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Filled.SupportAgent, contentDescription = null, tint = PureWhite)
                        }
                    }
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = SjsStrings.t(lang, "Huduma kwa Wateja (24/7)", "Customer Support (24/7)"),
                            style = MaterialTheme.typography.titleMedium,
                            color = PureWhite
                        )
                        Text(
                            text = SjsStrings.t(
                                lang,
                                "Una swali, malalamiko au msaada wa Airtel Money (${MarketplaceConstants.ADMIN_AIRTEL_NUMBER})?",
                                "Need help, dispute support, or Airtel Money (${MarketplaceConstants.ADMIN_AIRTEL_NUMBER}) assistance?"
                            ),
                            style = MaterialTheme.typography.bodySmall,
                            color = BorderGrey
                        )
                        Spacer(Modifier.height(4.dp))
                        Button(
                            onClick = onOpenSupportComplaint,
                            colors = ButtonDefaults.buttonColors(containerColor = OrangeBrand),
                            modifier = Modifier.testTag("home_customer_support_button")
                        ) {
                            Text(SjsStrings.t(lang, "Wasilisha Malalamiko / Msaada", "Submit Complaint / Support"))
                        }
                    }
                }
            }
        }
    }

    if (showFilterSheet) {
        SearchFilterDialog(
            lang = lang,
            current = filters,
            onApply = { updated ->
                onUpdateFilters { updated }
                showFilterSheet = false
            },
            onDismiss = { showFilterSheet = false }
        )
    }
}

@Composable
private fun SectionHeader(title: String, subtitle: String) {
    Column(modifier = Modifier.padding(horizontal = 16.dp)) {
        Text(text = title, style = MaterialTheme.typography.titleLarge, color = NavyDeep)
        Text(text = subtitle, style = MaterialTheme.typography.bodySmall, color = SlateGrey)
    }
}

@Composable
private fun EmptyStateCard(icon: androidx.compose.ui.graphics.vector.ImageVector, message: String) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        colors = CardDefaults.cardColors(containerColor = PureWhite)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Icon(icon, contentDescription = null, tint = SlateGrey)
            Text(text = message, style = MaterialTheme.typography.bodyMedium, color = CharcoalGrey)
        }
    }
}

@Composable
private fun ProviderFeaturedCard(
    provider: SecurityProvider,
    lang: AppLang,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .width(268.dp)
            .clickable(onClick = onClick)
            .testTag("provider_card_${provider.id}"),
        colors = CardDefaults.cardColors(containerColor = PureWhite),
        shape = RoundedCornerShape(18.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) {
        Column {
            Box(modifier = Modifier.fillMaxWidth().height(112.dp)) {
                Base64Image(
                    base64 = provider.logoBase64,
                    contentDescription = provider.companyName,
                    modifier = Modifier.fillMaxSize(),
                    fallbackResId = R.drawable.img_security_ops
                )
                Box(modifier = Modifier.padding(10.dp).align(Alignment.TopStart)) {
                    VerifiedBadgeChip(lang = lang, verified = provider.verifiedBadge)
                }
            }
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = provider.companyName,
                    style = MaterialTheme.typography.titleMedium,
                    color = NavyDeep,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Star, contentDescription = null, tint = OrangeBrand, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(
                        text = String.format(Locale.US, "%.1f (%d)", provider.ratingAvg, provider.ratingCount),
                        style = MaterialTheme.typography.labelMedium,
                        color = DarkGrey
                    )
                    Spacer(Modifier.width(8.dp))
                    Icon(Icons.Filled.LocationOn, contentDescription = null, tint = SlateGrey, modifier = Modifier.size(14.dp))
                    Text(
                        text = provider.locations.firstOrNull() ?: "Tanzania",
                        style = MaterialTheme.typography.bodySmall,
                        color = SlateGrey,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Text(
                    text = "${SjsStrings.t(lang, "Kuanzia", "From")} ${TzsFormatter.format(provider.startingPriceTzs)}",
                    style = MaterialTheme.typography.labelLarge,
                    color = OrangeBrand
                )
            }
        }
    }
}

@Composable
private fun OfferCard(service: SecurityServiceListing, lang: AppLang, onBook: () -> Unit) {
    Card(
        modifier = Modifier
            .width(240.dp)
            .clickable(onClick = onBook),
        colors = CardDefaults.cardColors(containerColor = NavyElevated),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Surface(color = OrangeBrand, shape = RoundedCornerShape(6.dp)) {
                Text(
                    text = service.offerBadge ?: "-${service.discountPercent}%",
                    style = MaterialTheme.typography.labelSmall,
                    color = PureWhite,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                )
            }
            Text(
                text = service.title,
                style = MaterialTheme.typography.titleSmall,
                color = PureWhite,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = "${service.companyName} • ${service.location}",
                style = MaterialTheme.typography.bodySmall,
                color = BorderGrey,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = "${TzsFormatter.format(service.priceTzs)} / ${service.priceUnit}",
                style = MaterialTheme.typography.labelLarge,
                color = OrangeBright
            )
        }
    }
}

@Composable
private fun ServiceListingRowCard(
    service: SecurityServiceListing,
    lang: AppLang,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .clickable(onClick = onClick)
            .testTag("service_card_${service.id}"),
        colors = CardDefaults.cardColors(containerColor = PureWhite),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Surface(
                color = NavyContainer,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.size(50.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = categoryIcon(service.categoryEnum()),
                        contentDescription = null,
                        tint = NavyDeep
                    )
                }
            }
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = service.title,
                        style = MaterialTheme.typography.titleSmall,
                        color = NavyDeep,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    if (service.providerVerified) {
                        Icon(Icons.Filled.Verified, contentDescription = "Verified", tint = VerifiedGreen, modifier = Modifier.size(16.dp))
                    }
                }
                Text(
                    text = "${service.companyName} • ${service.location}",
                    style = MaterialTheme.typography.bodySmall,
                    color = SlateGrey
                )
                Text(
                    text = "${TzsFormatter.format(service.priceTzs)} (${service.priceUnit})",
                    style = MaterialTheme.typography.labelLarge,
                    color = OrangeBrand
                )
            }
            Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = SlateGrey)
        }
    }
}

@Composable
private fun SearchFilterDialog(
    lang: AppLang,
    current: SearchFilters,
    onApply: (SearchFilters) -> Unit,
    onDismiss: () -> Unit
) {
    var selectedLoc by remember { mutableStateOf(current.location) }
    var selectedMaxPrice by remember { mutableStateOf(current.maxPriceTzs) }
    var selectedMinRating by remember { mutableStateOf(current.minRating) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(SjsStrings.t(lang, "Chuja Matokeo", "Filter Providers & Services")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(SjsStrings.t(lang, "Mkoa / Eneo (Tanzania)", "Location"), style = MaterialTheme.typography.labelMedium)
                Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(
                        selected = selectedLoc == null,
                        onClick = { selectedLoc = null },
                        label = { Text(SjsStrings.t(lang, "Yote", "All")) }
                    )
                    MarketplaceConstants.TANZANIA_LOCATIONS.forEach { loc ->
                        FilterChip(
                            selected = selectedLoc == loc,
                            onClick = { selectedLoc = loc },
                            label = { Text(loc) }
                        )
                    }
                }

                Text(SjsStrings.t(lang, "Kiwango cha Juu cha Bei (TZS)", "Max Price (TZS)"), style = MaterialTheme.typography.labelMedium)
                Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(null to SjsStrings.t(lang, "Yoyote", "Any"), 300_000L to "300k", 700_000L to "700k", 1_500_000L to "1.5M").forEach { (limit, label) ->
                        FilterChip(
                            selected = selectedMaxPrice == limit,
                            onClick = { selectedMaxPrice = limit },
                            label = { Text(label) }
                        )
                    }
                }

                Text(SjsStrings.t(lang, "Kiwango cha Nyota (Rating)", "Minimum Rating"), style = MaterialTheme.typography.labelMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(0.0 to "All", 4.0 to "4.0+ ★", 4.5 to "4.5+ ★").forEach { (r, label) ->
                        FilterChip(
                            selected = selectedMinRating == r,
                            onClick = { selectedMinRating = r },
                            label = { Text(label) }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onApply(current.copy(location = selectedLoc, maxPriceTzs = selectedMaxPrice, minRating = selectedMinRating))
                },
                colors = ButtonDefaults.buttonColors(containerColor = OrangeBrand)
            ) {
                Text(SjsStrings.t(lang, "Tumia Vichujio", "Apply"))
            }
        },
        dismissButton = {
            TextButton(onClick = { onApply(SearchFilters()) }) {
                Text(SjsStrings.t(lang, "Safisha", "Reset"))
            }
        }
    )
}
