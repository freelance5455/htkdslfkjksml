package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Groups
import androidx.compose.material.icons.rounded.Phone
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.model.SchoolClass
import com.example.model.Subject
import com.example.model.TeacherAssignment
import com.example.model.TeacherRole
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.KpiStatTile
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.GoldContainer
import com.example.ui.theme.GoldSecondary
import com.example.viewmodel.SchoolDashboardData
import com.example.viewmodel.SchoolViewModel

@Composable
fun TeachersScreen(
    data: SchoolDashboardData,
    viewModel: SchoolViewModel,
) {
    var roleFilter by remember { mutableStateOf<TeacherRole?>(null) }
    var editingAssignment by remember { mutableStateOf<TeacherAssignment?>(null) }
    var showDialog by remember { mutableStateOf(false) }

    val filtered = data.teacherAssignments.filter { item ->
        roleFilter == null || item.roleType == roleFilter?.name
    }
    val uniqueTeachers = data.teacherAssignments.map { it.teacherName.trim().lowercase() }.distinct().size
    val totalWeeklyHours = data.teacherAssignments.sumOf { it.weeklyHours }

    if (showDialog) {
        TeacherAssignmentDialog(
            existing = editingAssignment,
            classes = data.classes,
            allSubjects = data.allSubjects,
            defaultClass = data.activeClass,
            onDismiss = {
                showDialog = false
                editingAssignment = null
            },
            onSave = { assignment ->
                viewModel.upsertTeacherAssignment(assignment)
                showDialog = false
                editingAssignment = null
            },
        )
    }

    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 88.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item(key = "teacher_summary") {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        KpiStatTile(
                            label = "Teachers",
                            value = uniqueTeachers.toString(),
                            accentColor = MaterialTheme.colorScheme.primary,
                            containerColor = MaterialTheme.colorScheme.primaryContainer,
                            modifier = Modifier.weight(1f),
                        )
                        KpiStatTile(
                            label = "Assignments",
                            value = data.teacherAssignments.size.toString(),
                            accentColor = EmeraldSuccess,
                            containerColor = EmeraldContainer,
                            modifier = Modifier.weight(1f),
                        )
                        KpiStatTile(
                            label = "Weekly Hrs",
                            value = "${totalWeeklyHours}h",
                            accentColor = GoldSecondary,
                            containerColor = GoldContainer,
                            modifier = Modifier.weight(1f),
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        FilterChip(
                            selected = roleFilter == null,
                            onClick = { roleFilter = null },
                            label = { Text("All (${data.teacherAssignments.size})") },
                        )
                        TeacherRole.entries.forEach { role ->
                            FilterChip(
                                selected = roleFilter == role,
                                onClick = { roleFilter = if (roleFilter == role) null else role },
                                label = { Text(role.label) },
                            )
                        }
                    }
                }
            }

            if (filtered.isEmpty()) {
                item(key = "empty_teachers") {
                    EmptyStateCard(
                        icon = Icons.Rounded.Groups,
                        title = "No Teacher Assignments",
                        subtitle = "Assign teachers to classes and subjects with weekly teaching hours and schedule notes.",
                        actionLabel = "+ Assign Teacher",
                        onAction = {
                            editingAssignment = null
                            showDialog = true
                        },
                    )
                }
            } else {
                items(filtered, key = { it.id }) { assignment ->
                    TeacherAssignmentCard(
                        assignment = assignment,
                        onEdit = {
                            editingAssignment = assignment
                            showDialog = true
                        },
                        onDelete = { viewModel.deleteTeacherAssignment(assignment.id) },
                    )
                }
            }
        }

        FloatingActionButton(
            onClick = {
                editingAssignment = null
                showDialog = true
            },
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp)
                .testTag("add_teacher_assignment_fab"),
        ) {
            Icon(Icons.Rounded.Add, contentDescription = "Assign Teacher")
        }
    }
}

@Composable
private fun TeacherAssignmentCard(
    assignment: TeacherAssignment,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
) {
    val role = TeacherRole.fromRaw(assignment.roleType)
    val (badgeBg, badgeFg) = when (role) {
        TeacherRole.CLASS_TEACHER -> MaterialTheme.colorScheme.primaryContainer to MaterialTheme.colorScheme.primary
        TeacherRole.HEAD_TEACHER -> GoldContainer to GoldSecondary
        TeacherRole.SUBJECT_TEACHER -> EmeraldContainer to EmeraldSuccess
    }

    Surface(
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top,
            ) {
                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Surface(color = badgeBg, shape = RoundedCornerShape(8.dp)) {
                        Text(
                            text = role.label.uppercase(),
                            style = MaterialTheme.typography.labelSmall,
                            color = badgeFg,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                        )
                    }
                    Text(
                        text = assignment.teacherName,
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        text = buildString {
                            append("Class ${assignment.className}")
                            if (assignment.subjectName.isNotBlank()) {
                                append(" • ${assignment.subjectName}")
                            }
                        },
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                    )
                }

                Row {
                    IconButton(onClick = onEdit, modifier = Modifier.size(48.dp)) {
                        Icon(Icons.Rounded.Edit, contentDescription = "Edit assignment")
                    }
                    IconButton(onClick = onDelete, modifier = Modifier.size(48.dp)) {
                        Icon(
                            Icons.Rounded.DeleteOutline,
                            contentDescription = "Delete assignment",
                            tint = MaterialTheme.colorScheme.error,
                        )
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Rounded.Schedule,
                        contentDescription = null,
                        modifier = Modifier.size(15.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(Modifier.width(4.dp))
                    Text(
                        text = "${assignment.weeklyHours} hrs/wk",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                if (assignment.teacherPhone.isNotBlank()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Rounded.Phone,
                            contentDescription = null,
                            modifier = Modifier.size(15.dp),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Spacer(Modifier.width(4.dp))
                        Text(
                            text = assignment.teacherPhone,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }

            if (assignment.scheduleNote.isNotBlank()) {
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Text(
                        text = assignment.scheduleNote,
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                    )
                }
            }
        }
    }
}

@Composable
private fun TeacherAssignmentDialog(
    existing: TeacherAssignment?,
    classes: List<SchoolClass>,
    allSubjects: List<Subject>,
    defaultClass: SchoolClass?,
    onDismiss: () -> Unit,
    onSave: (TeacherAssignment) -> Unit,
) {
    var teacherName by remember { mutableStateOf(existing?.teacherName.orEmpty()) }
    var teacherPhone by remember { mutableStateOf(existing?.teacherPhone.orEmpty()) }
    var teacherEmail by remember { mutableStateOf(existing?.teacherEmail.orEmpty()) }
    var selectedClass by remember {
        mutableStateOf(
            classes.firstOrNull { it.id == existing?.classId } ?: defaultClass ?: classes.firstOrNull()
        )
    }
    val classSubjects = allSubjects.filter { it.classId == selectedClass?.id }
    var selectedSubject by remember(selectedClass?.id) {
        mutableStateOf(classSubjects.firstOrNull { it.id == existing?.subjectId } ?: classSubjects.firstOrNull())
    }
    var selectedRole by remember {
        mutableStateOf(TeacherRole.fromRaw(existing?.roleType ?: TeacherRole.SUBJECT_TEACHER.name))
    }
    var weeklyHoursText by remember { mutableStateOf((existing?.weeklyHours ?: 6L).toString()) }
    var scheduleNote by remember { mutableStateOf(existing?.scheduleNote.orEmpty()) }

    var classMenuOpen by remember { mutableStateOf(false) }
    var subjectMenuOpen by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                if (existing == null) "Assign Teacher" else "Edit Assignment",
                style = MaterialTheme.typography.titleMedium,
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = teacherName,
                    onValueChange = { teacherName = it },
                    label = { Text("Teacher Name") },
                    placeholder = { Text("e.g. Tr. Jean Bosco") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("teacher_name_input"),
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = teacherPhone,
                        onValueChange = { teacherPhone = it },
                        label = { Text("Phone") },
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                    )
                    OutlinedTextField(
                        value = weeklyHoursText,
                        onValueChange = { weeklyHoursText = it.filter { c -> c.isDigit() } },
                        label = { Text("Hrs/Wk") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(0.6f),
                    )
                }
                OutlinedTextField(
                    value = teacherEmail,
                    onValueChange = { teacherEmail = it },
                    label = { Text("Email (Optional)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(modifier = Modifier.weight(1f)) {
                        OutlinedButton(
                            onClick = { classMenuOpen = true },
                            modifier = Modifier.fillMaxWidth().height(46.dp),
                        ) {
                            Text(selectedClass?.name ?: "Class", maxLines = 1)
                        }
                        DropdownMenu(expanded = classMenuOpen, onDismissRequest = { classMenuOpen = false }) {
                            classes.forEach { c ->
                                DropdownMenuItem(
                                    text = { Text(c.name) },
                                    onClick = {
                                        selectedClass = c
                                        classMenuOpen = false
                                    },
                                )
                            }
                        }
                    }

                    Box(modifier = Modifier.weight(1.3f)) {
                        OutlinedButton(
                            onClick = { subjectMenuOpen = true },
                            modifier = Modifier.fillMaxWidth().height(46.dp),
                        ) {
                            Text(
                                text = selectedSubject?.name ?: "Homeroom / All",
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                        DropdownMenu(expanded = subjectMenuOpen, onDismissRequest = { subjectMenuOpen = false }) {
                            DropdownMenuItem(
                                text = { Text("All / Homeroom") },
                                onClick = {
                                    selectedSubject = null
                                    subjectMenuOpen = false
                                },
                            )
                            classSubjects.forEach { s ->
                                DropdownMenuItem(
                                    text = { Text(s.name) },
                                    onClick = {
                                        selectedSubject = s
                                        subjectMenuOpen = false
                                    },
                                )
                            }
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    TeacherRole.entries.forEach { role ->
                        FilterChip(
                            selected = selectedRole == role,
                            onClick = { selectedRole = role },
                            label = { Text(role.label, style = MaterialTheme.typography.labelSmall) },
                        )
                    }
                }

                OutlinedTextField(
                    value = scheduleNote,
                    onValueChange = { scheduleNote = it },
                    label = { Text("Schedule / Notes") },
                    placeholder = { Text("e.g. Mon-Fri 08:00-09:30") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val cls = selectedClass ?: return@Button
                    if (teacherName.isNotBlank()) {
                        onSave(
                            TeacherAssignment(
                                id = existing?.id.orEmpty(),
                                teacherName = teacherName,
                                teacherEmail = teacherEmail,
                                teacherPhone = teacherPhone,
                                classId = cls.id,
                                className = cls.name,
                                subjectId = selectedSubject?.id.orEmpty(),
                                subjectName = selectedSubject?.name.orEmpty(),
                                roleType = selectedRole.name,
                                weeklyHours = (weeklyHoursText.toLongOrNull() ?: 4L).coerceIn(0L, 80L),
                                scheduleNote = scheduleNote,
                            )
                        )
                    }
                },
                enabled = teacherName.isNotBlank() && selectedClass != null,
                modifier = Modifier.testTag("save_teacher_assignment_button"),
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        },
    )
}
