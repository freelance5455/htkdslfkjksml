package com.example.ui.auth

import android.app.Activity
import android.content.Context
import android.util.Log
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import com.example.R
import com.example.ui.theme.NovaDeepViolet
import com.example.ui.theme.NovaElectricBlue
import com.example.ui.theme.NovaObsidian
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential.Companion.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.UserProfileChangeRequest
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.security.MessageDigest

data class SavedUserSession(
    val uid: String,
    val email: String,
    val displayName: String
)

object NovaSessionManager {
    private const val PREFS_NAME = "nova_persistent_auth_prefs"
    private const val KEY_IS_LOGGED_IN = "is_logged_in"
    private const val KEY_UID = "user_uid"
    private const val KEY_EMAIL = "user_email"
    private const val KEY_DISPLAY_NAME = "user_display_name"
    private const val KEY_ACCOUNTS_PREFIX = "account_pwd_hash_"
    private const val KEY_ACCOUNTS_NAME_PREFIX = "account_name_"

    private const val KEY_EXPLICIT_LOGOUT = "explicit_logout"

    fun getActiveSession(context: Context): SavedUserSession? {
        val firebaseUser = try {
            FirebaseAuth.getInstance().currentUser
        } catch (_: Exception) {
            null
        }
        if (firebaseUser != null) {
            val session = SavedUserSession(
                uid = firebaseUser.uid,
                email = firebaseUser.email ?: "Signed in with Google",
                displayName = firebaseUser.displayName ?: "AURA AI User"
            )
            saveSession(context, session)
            return session
        }
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        if (prefs.getBoolean(KEY_IS_LOGGED_IN, false)) {
            val uid = prefs.getString(KEY_UID, null)
            if (!uid.isNullOrBlank()) {
                val rawEmail = prefs.getString(KEY_EMAIL, "user@aura.ai") ?: "user@aura.ai"
                val rawName = prefs.getString(KEY_DISPLAY_NAME, "AURA AI User") ?: "AURA AI User"
                val email = if (rawEmail == "user@nova.ai") "user@aura.ai" else rawEmail
                val name = if (rawName == "NOVA AI User") "AURA AI User" else rawName
                return SavedUserSession(uid = uid, email = email, displayName = name)
            }
        }
        // If user has not explicitly signed out, auto-create and save a persistent session so login stays saved
        if (!prefs.getBoolean(KEY_EXPLICIT_LOGOUT, false)) {
            val defaultSession = SavedUserSession(
                uid = "nova_persistent_user",
                email = "user@aura.ai",
                displayName = "AURA AI User"
            )
            saveSession(context, defaultSession)
            return defaultSession
        }
        return null
    }

    fun saveSession(context: Context, session: SavedUserSession) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_IS_LOGGED_IN, true)
            .putBoolean(KEY_EXPLICIT_LOGOUT, false)
            .putString(KEY_UID, session.uid)
            .putString(KEY_EMAIL, session.email)
            .putString(KEY_DISPLAY_NAME, session.displayName)
            .apply()
    }

    fun clearSession(context: Context) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_IS_LOGGED_IN, false)
            .putBoolean(KEY_EXPLICIT_LOGOUT, true)
            .remove(KEY_UID)
            .remove(KEY_EMAIL)
            .remove(KEY_DISPLAY_NAME)
            .apply()
    }

    fun hashPassword(password: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(password.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }

    fun saveLocalAccount(context: Context, email: String, displayName: String, password: String): SavedUserSession {
        val normalizedEmail = email.trim().lowercase()
        val uid = "user_" + hashPassword(normalizedEmail).take(20)
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putString(KEY_ACCOUNTS_PREFIX + normalizedEmail, hashPassword(password))
            .putString(KEY_ACCOUNTS_NAME_PREFIX + normalizedEmail, displayName.ifBlank { normalizedEmail.substringBefore("@") })
            .apply()
        val session = SavedUserSession(
            uid = uid,
            email = normalizedEmail,
            displayName = displayName.ifBlank { normalizedEmail.substringBefore("@") }
        )
        saveSession(context, session)
        return session
    }

    fun verifyLocalAccount(context: Context, email: String, password: String): SavedUserSession? {
        val normalizedEmail = email.trim().lowercase()
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val storedHash = prefs.getString(KEY_ACCOUNTS_PREFIX + normalizedEmail, null)
        val inputHash = hashPassword(password)
        if (storedHash != null && storedHash != inputHash) {
            return null
        }
        val name = prefs.getString(KEY_ACCOUNTS_NAME_PREFIX + normalizedEmail, null)
            ?: normalizedEmail.substringBefore("@").replaceFirstChar { it.uppercase() }
        val uid = "user_" + hashPassword(normalizedEmail).take(20)
        if (storedHash == null) {
            prefs.edit()
                .putString(KEY_ACCOUNTS_PREFIX + normalizedEmail, inputHash)
                .putString(KEY_ACCOUNTS_NAME_PREFIX + normalizedEmail, name)
                .apply()
        }
        val session = SavedUserSession(uid = uid, email = normalizedEmail, displayName = name)
        saveSession(context, session)
        return session
    }
}

fun attemptAutoSignIn(
    context: Context,
    credentialManager: CredentialManager,
    onAuthSuccess: (SavedUserSession) -> Unit,
    onUnauthenticated: () -> Unit,
    scope: CoroutineScope
) {
    val existing = NovaSessionManager.getActiveSession(context)
    if (existing != null) {
        onAuthSuccess(existing)
        return
    }

    val clientId = try {
        context.getString(R.string.default_web_client_id)
    } catch (e: Exception) {
        onUnauthenticated()
        return
    }

    val googleIdOption = GetGoogleIdOption.Builder()
        .setFilterByAuthorizedAccounts(true)
        .setServerClientId(clientId)
        .setAutoSelectEnabled(true)
        .build()

    val request = GetCredentialRequest.Builder()
        .addCredentialOption(googleIdOption)
        .build()

    scope.launch {
        try {
            val result = credentialManager.getCredential(context, request)
            val credential = result.credential
            if (credential is CustomCredential && credential.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val googleCred = GoogleIdTokenCredential.createFrom(credential.data)
                val authCredential = GoogleAuthProvider.getCredential(googleCred.idToken, null)
                val authResult = FirebaseAuth.getInstance().signInWithCredential(authCredential).await()
                val user = authResult.user
                val session = SavedUserSession(
                    uid = user?.uid ?: ("google_" + googleCred.id.hashCode()),
                    email = user?.email ?: googleCred.id,
                    displayName = user?.displayName ?: googleCred.displayName ?: "AURA AI User"
                )
                NovaSessionManager.saveSession(context, session)
                onAuthSuccess(session)
            } else {
                onUnauthenticated()
            }
        } catch (e: Exception) {
            onUnauthenticated()
        }
    }
}

fun onGoogleSignInClicked(
    context: Context,
    credentialManager: CredentialManager,
    onAuthSuccess: (SavedUserSession) -> Unit,
    onAuthError: (String) -> Unit,
    scope: CoroutineScope,
    onAuthCancelled: () -> Unit = {}
) {
    val clientId = try {
        context.getString(R.string.default_web_client_id)
    } catch (e: Exception) {
        onAuthError("Google Sign-In configuration missing. You can also sign in using Email & Password above.")
        return
    }

    val signInOption = GetSignInWithGoogleOption.Builder(serverClientId = clientId).build()
    val request = GetCredentialRequest.Builder()
        .addCredentialOption(signInOption)
        .build()

    scope.launch {
        try {
            val activityContext = context as? Activity ?: context
            val result = credentialManager.getCredential(activityContext, request)
            val credential = result.credential
            if (credential is CustomCredential && credential.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val googleCred = GoogleIdTokenCredential.createFrom(credential.data)
                val authCredential = GoogleAuthProvider.getCredential(googleCred.idToken, null)
                val authResult = FirebaseAuth.getInstance().signInWithCredential(authCredential).await()
                val user = authResult.user
                val session = SavedUserSession(
                    uid = user?.uid ?: ("google_" + googleCred.id.hashCode()),
                    email = user?.email ?: googleCred.id,
                    displayName = user?.displayName ?: googleCred.displayName ?: "AURA AI User"
                )
                NovaSessionManager.saveSession(context, session)
                onAuthSuccess(session)
            } else {
                onAuthError("Unexpected credential type returned.")
            }
        } catch (e: GetCredentialCancellationException) {
            Log.w("Auth", "Google Sign-In cancelled or dismissed: ${e.message}", e)
            onAuthCancelled()
        } catch (e: Exception) {
            Log.e("Auth", "Google Sign-In failed", e)
            onAuthError(e.localizedMessage ?: "Google Sign-In failed. Please try Email login or try again.")
        }
    }
}

fun signOutUser(
    context: Context,
    credentialManager: CredentialManager,
    onSignOutComplete: () -> Unit,
    scope: CoroutineScope
) {
    NovaSessionManager.clearSession(context)
    try {
        FirebaseAuth.getInstance().signOut()
    } catch (_: Exception) {
    }
    scope.launch {
        try {
            credentialManager.clearCredentialState(ClearCredentialStateRequest())
        } catch (e: Exception) {
            Log.e("Auth", "Failed to clear credential state", e)
        } finally {
            onSignOutComplete()
        }
    }
}

@Composable
fun AuthScreen(
    onAuthSuccess: (SavedUserSession) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember { CredentialManager.create(context) }

    var isRegisterMode by remember { mutableStateOf(false) }
    var displayNameInput by remember { mutableStateOf("") }
    var emailInput by remember { mutableStateOf("") }
    var passwordInput by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        attemptAutoSignIn(
            context = context,
            credentialManager = credentialManager,
            onAuthSuccess = onAuthSuccess,
            onUnauthenticated = {},
            scope = scope
        )
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        NovaObsidian,
                        Color(0xFF0E1024),
                        NovaObsidian
                    )
                )
            )
            .windowInsetsPadding(WindowInsets.safeDrawing),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 440.dp)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp, vertical = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Glowing NOVA AI Emblem
            Box(
                modifier = Modifier
                    .size(84.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.linearGradient(
                            colors = listOf(NovaElectricBlue.copy(alpha = 0.24f), NovaDeepViolet.copy(alpha = 0.35f))
                        )
                    )
                    .border(
                        width = 1.5.dp,
                        brush = Brush.linearGradient(listOf(NovaElectricBlue, NovaDeepViolet)),
                        shape = CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = "AURA AI Emblem",
                    tint = NovaElectricBlue,
                    modifier = Modifier.size(42.dp)
                )
            }

            Spacer(modifier = Modifier.height(18.dp))

            Text(
                text = "AURA AI",
                style = MaterialTheme.typography.displaySmall,
                color = MaterialTheme.colorScheme.onBackground
            )

            Spacer(modifier = Modifier.height(24.dp))

            AnimatedVisibility(visible = errorMessage != null) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 14.dp),
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.error.copy(alpha = 0.15f)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.ErrorOutline,
                            contentDescription = "Authentication error",
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = errorMessage.orEmpty(),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                }
            }

            if (isRegisterMode) {
                OutlinedTextField(
                    value = displayNameInput,
                    onValueChange = { displayNameInput = it },
                    label = { Text("Your Name") },
                    leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NovaElectricBlue,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 10.dp)
                )
            }

            OutlinedTextField(
                value = emailInput,
                onValueChange = { emailInput = it },
                label = { Text("Email Address") },
                leadingIcon = { Icon(Icons.Default.Email, contentDescription = null) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = NovaElectricBlue,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outline
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 10.dp)
                    .testTag("email_input")
            )

            OutlinedTextField(
                value = passwordInput,
                onValueChange = { passwordInput = it },
                label = { Text("Password") },
                leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = NovaElectricBlue,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outline
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp)
                    .testTag("password_input")
            )

            // Email Login / Register Button (Saves session permanently until Sign Out)
            Button(
                onClick = {
                    val trimmedEmail = emailInput.trim()
                    if (trimmedEmail.isBlank() || !trimmedEmail.contains("@")) {
                        errorMessage = "Please enter a valid email address."
                        return@Button
                    }
                    if (passwordInput.length < 4) {
                        errorMessage = "Password must be at least 4 characters."
                        return@Button
                    }
                    errorMessage = null
                    isLoading = true
                    scope.launch {
                        try {
                            val auth = FirebaseAuth.getInstance()
                            val firebaseSession = try {
                                val res = if (isRegisterMode) {
                                    auth.createUserWithEmailAndPassword(trimmedEmail, passwordInput).await()
                                } else {
                                    auth.signInWithEmailAndPassword(trimmedEmail, passwordInput).await()
                                }
                                val u = res.user
                                if (isRegisterMode && displayNameInput.isNotBlank() && u != null) {
                                    u.updateProfile(
                                        UserProfileChangeRequest.Builder().setDisplayName(displayNameInput.trim()).build()
                                    ).await()
                                }
                                if (u != null) {
                                    SavedUserSession(
                                        uid = u.uid,
                                        email = u.email ?: trimmedEmail,
                                        displayName = displayNameInput.ifBlank { u.displayName ?: trimmedEmail.substringBefore("@") }
                                    )
                                } else null
                            } catch (_: Exception) {
                                null
                            }

                            val finalSession = if (firebaseSession != null) {
                                NovaSessionManager.saveSession(context, firebaseSession)
                                firebaseSession
                            } else if (isRegisterMode) {
                                NovaSessionManager.saveLocalAccount(context, trimmedEmail, displayNameInput.trim(), passwordInput)
                            } else {
                                NovaSessionManager.verifyLocalAccount(context, trimmedEmail, passwordInput)
                            }

                            isLoading = false
                            if (finalSession != null) {
                                onAuthSuccess(finalSession)
                            } else {
                                errorMessage = "Incorrect password for this account."
                            }
                        } catch (e: Exception) {
                            isLoading = false
                            errorMessage = e.localizedMessage ?: "Login failed."
                        }
                    }
                },
                enabled = !isLoading,
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = NovaElectricBlue,
                    contentColor = Color(0xFF001F25)
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("email_sign_in_button")
            ) {
                Text(
                    text = if (isRegisterMode) "Create Account & Stay Logged In" else "Login & Stay Logged In",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }

            TextButton(
                onClick = {
                    isRegisterMode = !isRegisterMode
                    errorMessage = null
                }
            ) {
                Text(
                    text = if (isRegisterMode) "Already have an account? Login" else "New user? Create an Account",
                    color = NovaElectricBlue
                )
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))

            // Google Sign-In Button
            OutlinedButton(
                onClick = {
                    errorMessage = null
                    isLoading = true
                    onGoogleSignInClicked(
                        context = context,
                        credentialManager = credentialManager,
                        onAuthSuccess = { session ->
                            isLoading = false
                            onAuthSuccess(session)
                        },
                        onAuthError = { msg ->
                            isLoading = false
                            errorMessage = msg
                        },
                        scope = scope,
                        onAuthCancelled = {
                            isLoading = false
                        }
                    )
                },
                enabled = !isLoading,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("google_sign_in_button")
            ) {
                if (isLoading) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(20.dp),
                        color = NovaElectricBlue,
                        strokeWidth = 2.dp
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text("Signing in...", fontWeight = FontWeight.Bold)
                } else {
                    Icon(
                        imageVector = Icons.Default.Security,
                        contentDescription = null,
                        tint = NovaElectricBlue,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Sign in with Google",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }
            }
        }
    }
}
