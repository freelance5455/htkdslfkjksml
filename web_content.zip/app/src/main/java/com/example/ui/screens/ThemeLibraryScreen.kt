package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bedtime
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Spa
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CustomThemePreset
import com.example.data.DarkModeOption
import com.example.data.KeyboardFontId
import com.example.data.KeycapStyle
import com.example.data.UnicodeOutputFont
import com.example.data.VelvetSettings
import com.example.keyboard.BuiltInThemeLibrary
import com.example.keyboard.KeyboardPalette
import com.example.keyboard.resolveKeyboardFontFamily
import com.example.keyboard.resolveKeyboardPalette
import com.example.keyboard.ui.KeyboardThemeBackground
import com.example.ui.VelvetMainViewModel
import kotlinx.coroutines.launch
import java.util.UUID

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ThemeLibraryScreen(
    viewModel: VelvetMainViewModel,
    settings: VelvetSettings,
    modifier: Modifier = Modifier
) {
    val scope = rememberCoroutineScope()
    val systemDark = isSystemInDarkTheme()
    val previewFont = remember(settings.fontId) { resolveKeyboardFontFamily(settings.fontId) }

    // Custom Theme Maker state
    var builderName by remember { mutableStateOf("") }
    var builderDarkBase by remember { mutableStateOf(true) }
    var builderBgArgb by remember { mutableLongStateOf(0xFF0E1412) }
    var builderKeyArgb by remember { mutableLongStateOf(0xFF1A2521) }
    var builderAccentArgb by remember { mutableLongStateOf(0xFF34D399) }
    var builderKeycapStyle by remember { mutableStateOf(KeycapStyle.ROUNDED) }
    var builderRadiusDp by remember { mutableFloatStateOf(12f) }
    var builderKeyOpacity by remember { mutableFloatStateOf(0.88f) }
    var builderAliveLeaf by remember { mutableStateOf(true) }
    var builderImgPath by remember { mutableStateOf<String?>(null) }
    var builderVidPath by remember { mutableStateOf<String?>(null) }
    var mediaStatus by remember { mutableStateOf<String?>(null) }

    val mediaPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                val imported = viewModel.importThemeMedia(uri)
                if (imported != null) {
                    if (imported.isVideo) {
                        builderVidPath = imported.filePath
                        builderImgPath = null
                        builderKeyOpacity = 0.62f
                        mediaStatus = "Looping video background loaded!"
                    } else {
                        builderImgPath = imported.filePath
                        builderVidPath = null
                        builderKeyOpacity = 0.68f
                        mediaStatus = "Custom image background loaded!"
                    }
                } else {
                    mediaStatus = "Could not import selected media."
                }
            }
        }
    }

    val activePalette = remember(settings, systemDark) {
        resolveKeyboardPalette(settings, systemDark)
    }

    val builderPreviewPalette = remember(
        builderBgArgb, builderKeyArgb, builderAccentArgb, builderDarkBase,
        builderKeycapStyle, builderRadiusDp, builderKeyOpacity,
        builderImgPath, builderVidPath, builderAliveLeaf
    ) {
        val textCol = if (builderDarkBase) Color(0xFFF8FAFC) else Color(0xFF0F172A)
        val accentCol = Color(builderAccentArgb)
        KeyboardPalette(
            themeId = "builder_preview",
            themeName = builderName.ifBlank { "My Custom Theme" },
            isDark = builderDarkBase,
            background = Color(builderBgArgb),
            toolbarBg = Color(builderBgArgb).copy(alpha = 0.72f),
            keyBg = Color(builderKeyArgb).copy(alpha = builderKeyOpacity),
            keyPressedBg = accentCol.copy(alpha = 0.35f),
            keyShadow = if (builderKeycapStyle == KeycapStyle.BORDERLESS) Color.Transparent else Color.Black.copy(alpha = 0.3f),
            keyBorder = textCol.copy(alpha = if (builderKeycapStyle == KeycapStyle.BORDERLESS) 0f else 0.25f),
            keyText = textCol,
            specialKeyBg = Color(builderKeyArgb).copy(alpha = (builderKeyOpacity * 0.8f).coerceIn(0.2f, 1f)),
            specialKeyText = textCol.copy(alpha = 0.85f),
            accent = accentCol,
            onAccent = Color.White,
            predictionPillBg = Color(builderKeyArgb).copy(alpha = 0.65f),
            predictionActiveBg = Color(builderKeyArgb),
            swipeTrail = accentCol,
            mutedText = textCol.copy(alpha = 0.6f),
            popupBg = Color(builderKeyArgb),
            keycapStyle = builderKeycapStyle,
            cornerRadiusDp = builderRadiusDp,
            keyOpacity = builderKeyOpacity,
            backgroundImagePath = builderImgPath,
            backgroundVideoPath = builderVidPath,
            aliveLeafEffect = builderAliveLeaf
        )
    }

    val accentSwatches = remember {
        listOf(
            0xFF34D399L, // Alive Leaf Emerald
            0xFF38BDF8L, // Electric Cyan
            0xFFFB7185L, // Warm Coral
            0xFFA78BFAL, // Soft Violet
            0xFFFBBF24L, // Golden Amber
            0xFF007AFFL  // iOS Blue
        )
    }

    val bgSwatches = remember {
        listOf(
            Triple(0xFF0C1411L, 0xFF172520L, true),  // Leaf Night
            Triple(0xFF080A10L, 0xFF141824L, true),  // OLED Midnight
            Triple(0xFF1A1014L, 0xFF2E1B22L, true),  // Clay Espresso
            Triple(0xFFF2F4F8L, 0xFFFFFFFFL, false), // Minimalist Light
            Triple(0xFFE4ECE4L, 0xFFFAFCF9L, false)  // Matcha Sage
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        Text(
            text = "Theme Library & Studio",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold
        )

        // Active Theme Live Preview Card
        Card(
            shape = RoundedCornerShape(22.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, activePalette.keyBorder, RoundedCornerShape(22.dp))
        ) {
            KeyboardThemeBackground(
                palette = activePalette,
                aliveMotionEnabled = settings.aliveMotionEnabled,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Active: ${activePalette.themeName}",
                            color = activePalette.keyText,
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                        Text(
                            text = "${activePalette.keycapStyle.label} • ${settings.fontId.label}",
                            color = activePalette.accent,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    KeycapPreviewRow(palette = activePalette, fontFamily = previewFont)
                }
            }
        }

        // Theme Library (User Custom + Built-In)
        val allThemes = settings.customThemes + BuiltInThemeLibrary
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Palette,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "Theme Library (${allThemes.size})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                allThemes.forEach { preset ->
                    val selected = settings.activeThemeId == preset.id
                    Card(
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        modifier = Modifier
                            .width(172.dp)
                            .border(
                                width = if (selected) 2.dp else 1.dp,
                                color = if (selected) MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.outline.copy(alpha = 0.35f),
                                shape = RoundedCornerShape(18.dp)
                            )
                            .clickable { viewModel.setActiveThemeId(preset.id) }
                            .testTag("theme_card_${preset.id}")
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Box(
                                        modifier = Modifier
                                            .size(16.dp)
                                            .clip(CircleShape)
                                            .background(Color(preset.bgColorArgb))
                                            .border(0.5.dp, Color.Gray, CircleShape)
                                    )
                                    Box(
                                        modifier = Modifier
                                            .size(16.dp)
                                            .clip(CircleShape)
                                            .background(Color(preset.keyColorArgb))
                                            .border(0.5.dp, Color.Gray, CircleShape)
                                    )
                                    Box(
                                        modifier = Modifier
                                            .size(16.dp)
                                            .clip(CircleShape)
                                            .background(Color(preset.accentColorArgb))
                                    )
                                }
                                if (selected) {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = "Active",
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                } else if (!preset.isBuiltIn) {
                                    IconButton(
                                        onClick = { viewModel.deleteCustomTheme(preset.id) },
                                        modifier = Modifier.size(22.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.DeleteOutline,
                                            contentDescription = "Delete custom theme",
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                            Text(
                                text = preset.name,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1
                            )
                            Text(
                                text = when {
                                    preset.backgroundVideoPath != null -> "Video • ${preset.keycapStyle.label}"
                                    preset.backgroundImagePath != null -> "Photo • ${preset.keycapStyle.label}"
                                    else -> preset.tagline
                                },
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                minLines = 2,
                                maxLines = 2
                            )
                        }
                    }
                }
            }
        }

        // Custom Theme Creator Studio (Import Image/Video + Keycap Styles + Roundedness)
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(22.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Create Custom Theme",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )

                // Live Builder Preview (shows imported image or looping video!)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .clipToBounds()
                        .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f), RoundedCornerShape(16.dp))
                ) {
                    KeyboardThemeBackground(
                        palette = builderPreviewPalette,
                        aliveMotionEnabled = builderAliveLeaf,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(10.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = "Preview • ${builderKeycapStyle.label}",
                                color = builderPreviewPalette.keyText,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            KeycapPreviewRow(palette = builderPreviewPalette, fontFamily = previewFont)
                        }
                    }
                }

                // Import Own Photo or Looping Video
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilledTonalButton(
                        onClick = {
                            mediaPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        contentPadding = PaddingValues(horizontal = 10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 48.dp)
                            .testTag("import_image_theme_button")
                    ) {
                        Icon(Icons.Default.Image, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Import Photo", maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    FilledTonalButton(
                        onClick = {
                            mediaPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                            )
                        },
                        contentPadding = PaddingValues(horizontal = 10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 48.dp)
                            .testTag("import_video_theme_button")
                    ) {
                        Icon(Icons.Default.Videocam, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Import Video", maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }

                if (builderImgPath != null || builderVidPath != null) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = mediaStatus ?: "Media background attached",
                            color = MaterialTheme.colorScheme.primary,
                            style = MaterialTheme.typography.bodyMedium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(
                            onClick = {
                                builderImgPath = null
                                builderVidPath = null
                                mediaStatus = null
                            }
                        ) {
                            Icon(Icons.Default.Close, contentDescription = "Remove media")
                        }
                    }
                }

                // Keycap Shape & Style
                Text("Keycap Style", style = MaterialTheme.typography.labelLarge)
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    KeycapStyle.entries.forEach { style ->
                        FilterChip(
                            selected = builderKeycapStyle == style,
                            onClick = {
                                builderKeycapStyle = style
                                if (style == KeycapStyle.PILL) builderRadiusDp = 22f
                            },
                            label = { Text(style.label) }
                        )
                    }
                }

                // Surface & Accent Color Swatches (stacked cleanly in FlowRows so mobile never overflows)
                Text("Base Surface Colors", style = MaterialTheme.typography.labelLarge)
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    bgSwatches.forEach { (bg, key, isDark) ->
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(Color(bg))
                                .border(
                                    width = if (builderBgArgb == bg) 2.5.dp else 1.dp,
                                    color = if (builderBgArgb == bg) MaterialTheme.colorScheme.primary else Color.Gray,
                                    shape = CircleShape
                                )
                                .clickable {
                                    builderBgArgb = bg
                                    builderKeyArgb = key
                                    builderDarkBase = isDark
                                }
                        )
                    }
                }

                Text("Accent Color", style = MaterialTheme.typography.labelLarge)
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    accentSwatches.forEach { acc ->
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(Color(acc))
                                .border(
                                    width = if (builderAccentArgb == acc) 2.5.dp else 0.dp,
                                    color = Color.White,
                                    shape = CircleShape
                                )
                                .clickable { builderAccentArgb = acc }
                        )
                    }
                }

                // Corner Roundness & Key Opacity Sliders
                Column {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Keycap Roundness", style = MaterialTheme.typography.bodyMedium)
                        Text("${builderRadiusDp.toInt()} dp", color = MaterialTheme.colorScheme.primary)
                    }
                    Slider(
                        value = builderRadiusDp,
                        onValueChange = { builderRadiusDp = it },
                        valueRange = 2f..22f
                    )
                }

                Column {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Keycap Transparency", style = MaterialTheme.typography.bodyMedium)
                        Text("${(builderKeyOpacity * 100).toInt()}%", color = MaterialTheme.colorScheme.primary)
                    }
                    Slider(
                        value = builderKeyOpacity,
                        onValueChange = { builderKeyOpacity = it },
                        valueRange = 0.25f..1.0f
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier
                            .weight(1f)
                            .padding(end = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.Spa, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Text(
                            text = "Alive Leaf Ambient Motion",
                            style = MaterialTheme.typography.bodyLarge
                        )
                    }
                    Switch(
                        checked = builderAliveLeaf,
                        onCheckedChange = { builderAliveLeaf = it }
                    )
                }

                OutlinedTextField(
                    value = builderName,
                    onValueChange = { builderName = it },
                    label = { Text("Theme Name") },
                    placeholder = { Text("e.g. Neon Rain or Minimalist Leaf") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                Button(
                    onClick = {
                        val finalName = builderName.trim().ifEmpty {
                            "Custom ${(settings.customThemes.size + 1)}"
                        }
                        val preset = CustomThemePreset(
                            id = "custom_${UUID.randomUUID()}",
                            name = finalName,
                            tagline = "Created in VelvetKey Studio",
                            isBuiltIn = false,
                            isDarkBase = builderDarkBase,
                            bgColorArgb = builderBgArgb,
                            keyColorArgb = builderKeyArgb,
                            specialKeyColorArgb = builderKeyArgb,
                            textColorArgb = if (builderDarkBase) 0xFFF8FAFC else 0xFF0F172A,
                            accentColorArgb = builderAccentArgb,
                            keycapStyle = builderKeycapStyle,
                            cornerRadiusDp = builderRadiusDp,
                            keyOpacity = builderKeyOpacity,
                            backgroundImagePath = builderImgPath,
                            backgroundVideoPath = builderVidPath,
                            aliveLeafEffect = builderAliveLeaf
                        )
                        viewModel.saveCustomTheme(preset)
                        builderName = ""
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("save_custom_theme_button")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Save & Apply to Library")
                }
            }
        }

        // Late-Night Dark Mode Selector
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(Icons.Default.Bedtime, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Text("Late-Night Dark Mode", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                }
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    DarkModeOption.entries.forEach { option ->
                        FilterChip(
                            selected = settings.darkModeOption == option,
                            onClick = { viewModel.setDarkMode(option) },
                            label = { Text(option.label, maxLines = 1, softWrap = false) }
                        )
                    }
                }
            }
        }

        // Multiple Fonts + Stylized Unicode Output
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(Icons.Default.TextFields, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Text("Keycap Fonts & Unicode Output", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                }
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    KeyboardFontId.entries.forEach { font ->
                        val fam = resolveKeyboardFontFamily(font)
                        FilterChip(
                            selected = settings.fontId == font,
                            onClick = { viewModel.setFont(font) },
                            label = { Text(font.label, fontFamily = fam) }
                        )
                    }
                }
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    UnicodeOutputFont.entries.forEach { uFont ->
                        FilterChip(
                            selected = settings.unicodeOutputFont == uFont,
                            onClick = { viewModel.setUnicodeOutputFont(uFont) },
                            label = { Text("${uFont.label}: ${uFont.preview}") }
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))
    }
}

@Composable
private fun KeycapPreviewRow(
    palette: KeyboardPalette,
    fontFamily: androidx.compose.ui.text.font.FontFamily
) {
    val shape = if (palette.keycapStyle == KeycapStyle.PILL) {
        RoundedCornerShape(50)
    } else {
        RoundedCornerShape(palette.cornerRadiusDp.dp)
    }
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        listOf("Q", "W", "E", "R", "T", "Y", "U").forEach { k ->
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(40.dp)
                    .shadow(if (palette.keycapStyle == KeycapStyle.BORDERLESS) 0.dp else 1.5.dp, shape)
                    .clip(shape)
                    .background(palette.keyBg)
                    .border(0.6.dp, palette.keyBorder, shape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = k,
                    color = palette.keyText,
                    fontFamily = fontFamily,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}
