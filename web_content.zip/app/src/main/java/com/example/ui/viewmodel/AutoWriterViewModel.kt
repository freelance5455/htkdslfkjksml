package com.example.ui.viewmodel

import android.app.Application
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.EngineState
import com.example.data.model.SlotItem
import com.example.data.model.TargetFieldType
import com.example.data.model.TypingConfig
import com.example.data.model.TypingTelemetry
import com.example.data.model.WordItem
import com.example.data.repository.WordRepository
import com.example.service.FloatingBridge
import com.example.service.FloatingCommand
import com.example.sound.TypewriterSoundPlayer
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlin.random.Random

/**
 * Main ViewModel coordinating the automated typing engine, random non-repeating
 * sequence generation, target arenas, audio/haptic feedback, and floating overlay bridge.
 */
class AutoWriterViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = WordRepository(application)
    private val soundPlayer = TypewriterSoundPlayer(application)

    val words: StateFlow<List<WordItem>> = repository.words.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        WordRepository.getDefaultWordBank()
    )

    private val _config = MutableStateFlow(TypingConfig())
    val config: StateFlow<TypingConfig> = _config.asStateFlow()

    private val _engineState = MutableStateFlow(EngineState.IDLE)
    val engineState: StateFlow<EngineState> = _engineState.asStateFlow()

    private val _telemetry = MutableStateFlow(TypingTelemetry())
    val telemetry: StateFlow<TypingTelemetry> = _telemetry.asStateFlow()

    // Designated target fields
    private val _singleLineText = MutableStateFlow("")
    val singleLineText: StateFlow<String> = _singleLineText.asStateFlow()

    private val _multiLineText = MutableStateFlow("")
    val multiLineText: StateFlow<String> = _multiLineText.asStateFlow()

    private val _slotItems = MutableStateFlow(List(16) { index -> SlotItem(index = index) })
    val slotItems: StateFlow<List<SlotItem>> = _slotItems.asStateFlow()

    private val _activeSlotIndex = MutableStateFlow(0)
    val activeSlotIndex: StateFlow<Int> = _activeSlotIndex.asStateFlow()

    private val _inAppFloatingDialogVisible = MutableStateFlow(false)
    val inAppFloatingDialogVisible: StateFlow<Boolean> = _inAppFloatingDialogVisible.asStateFlow()

    private val _userFeedbackMessage = MutableStateFlow<String?>(null)
    val userFeedbackMessage: StateFlow<String?> = _userFeedbackMessage.asStateFlow()

    private var typingJob: Job? = null
    private var isPaused = false
    private var startTimeMillis: Long = 0L

    init {
        listenToFloatingBridge()
    }

    private fun listenToFloatingBridge() {
        viewModelScope.launch {
            FloatingBridge.commands.collect { command ->
                when (command) {
                    is FloatingCommand.Start -> startTyping()
                    is FloatingCommand.Pause -> pauseTyping()
                    is FloatingCommand.Stop -> stopTyping()
                    is FloatingCommand.ManualRepeat -> manualRepeat()
                    is FloatingCommand.NextWord -> triggerNextWordImmediate()
                    is FloatingCommand.UpdateSpeed -> updateCharSpeed(command.speedMs)
                    is FloatingCommand.SetRandomMode -> updateRandomMode(command.enabled)
                }
            }
        }
    }

    fun startTyping() {
        if (_engineState.value == EngineState.PAUSED && isPaused) {
            resumeTyping()
            return
        }

        typingJob?.cancel()
        isPaused = false
        _engineState.value = EngineState.TYPING

        typingJob = viewModelScope.launch {
            val sequence = repository.generateSequence(
                count = _config.value.randomWordCount,
                isRandom = _config.value.isRandomMode
            )

            if (sequence.isEmpty()) {
                _userFeedbackMessage.value = "يرجى تحديد أو تفعيل كلمة واحدة على الأقل من بنك الكلمات"
                _engineState.value = EngineState.IDLE
                return@launch
            }

            startTimeMillis = System.currentTimeMillis()
            _telemetry.value = _telemetry.value.copy(
                targetWordsCount = sequence.size,
                currentCycleWordsTyped = 0,
                progress = 0f
            )

            FloatingBridge.updateStatus("جارِ الكتابة...", sequence.first().text, true)

            for (wIndex in sequence.indices) {
                while (isPaused) {
                    delay(80)
                }

                val word = sequence[wIndex]
                _telemetry.value = _telemetry.value.copy(
                    currentWordText = word.text,
                    currentCycleWordsTyped = wIndex,
                    progress = wIndex.toFloat() / sequence.size.toFloat()
                )
                FloatingBridge.updateStatus("كتابة: ${word.text} (${wIndex + 1}/${sequence.size})", word.text, true)

                // Type character by character into the designated target
                for (cIndex in word.text.indices) {
                    while (isPaused) {
                        delay(80)
                    }

                    val char = word.text[cIndex]
                    typeCharacterIntoTarget(char)

                    soundPlayer.playKeyClick(
                        enableSound = _config.value.isSoundEnabled,
                        enableHaptics = _config.value.isHapticsEnabled
                    )

                    _telemetry.value = _telemetry.value.copy(
                        charsTypedTotal = _telemetry.value.charsTypedTotal + 1,
                        currentCharIndex = cIndex
                    )

                    // Calculate typing delay with optional human jitter
                    val baseSpeed = _config.value.charSpeedMs
                    val actualDelay = if (_config.value.isHumanJitter) {
                        (baseSpeed + Random.nextLong(-baseSpeed / 5, (baseSpeed / 4).coerceAtLeast(1))).coerceAtLeast(10L)
                    } else {
                        baseSpeed
                    }
                    delay(actualDelay)
                }

                // Word finished
                repository.incrementUsage(word.text)
                soundPlayer.playWordBell(
                    enableSound = _config.value.isSoundEnabled,
                    enableHaptics = _config.value.isHapticsEnabled
                )

                _telemetry.value = _telemetry.value.copy(
                    wordsTypedTotal = _telemetry.value.wordsTypedTotal + 1,
                    currentCycleWordsTyped = wIndex + 1,
                    progress = (wIndex + 1).toFloat() / sequence.size.toFloat()
                )

                // Append space or delimiter to target
                appendDelimiterToTarget()

                // Inter-word delay
                if (wIndex < sequence.size - 1) {
                    delay(_config.value.wordDelayMs)
                }
            }

            // Cycle Finished
            _telemetry.value = _telemetry.value.copy(
                progress = 1.0f,
                cycleNumber = _telemetry.value.cycleNumber + 1
            )

            if (_config.value.isAutoRepeat) {
                FloatingBridge.updateStatus("إعادة تكرار أوتوماتيكية...", "", true)
                delay(600)
                startTyping()
            } else {
                _engineState.value = EngineState.COMPLETED
                FloatingBridge.updateStatus("اكتملت الدورة! اضغط تكرار", "", false)
            }
        }
    }

    private fun typeCharacterIntoTarget(char: Char) {
        when (_config.value.targetField) {
            TargetFieldType.SINGLE_LINE -> {
                _singleLineText.value = _singleLineText.value + char
            }
            TargetFieldType.MULTI_LINE -> {
                _multiLineText.value = _multiLineText.value + char
            }
            TargetFieldType.LETTER_SLOTS -> {
                val currentSlots = _slotItems.value.toMutableList()
                val targetIndex = _activeSlotIndex.value
                if (targetIndex < currentSlots.size) {
                    currentSlots[targetIndex] = currentSlots[targetIndex].copy(
                        charValue = char,
                        isFilled = true,
                        isActive = false
                    )
                    val nextIndex = (targetIndex + 1).coerceAtMost(currentSlots.size - 1)
                    _activeSlotIndex.value = nextIndex
                    if (nextIndex < currentSlots.size) {
                        currentSlots[nextIndex] = currentSlots[nextIndex].copy(isActive = true)
                    }
                    _slotItems.value = currentSlots
                }
            }
        }

        // Also inject into external accessibility focus if connected
        FloatingBridge.activeAccessibilityService?.let { service ->
            val currentFull = when (_config.value.targetField) {
                TargetFieldType.SINGLE_LINE -> _singleLineText.value
                TargetFieldType.MULTI_LINE -> _multiLineText.value
                TargetFieldType.LETTER_SLOTS -> _slotItems.value.mapNotNull { it.charValue }.joinToString("")
            }
            service.injectTextIntoFocusedField(currentFull)
        }
    }

    private fun appendDelimiterToTarget() {
        when (_config.value.targetField) {
            TargetFieldType.SINGLE_LINE -> {
                _singleLineText.value = _singleLineText.value + " "
            }
            TargetFieldType.MULTI_LINE -> {
                _multiLineText.value = _multiLineText.value + " "
            }
            TargetFieldType.LETTER_SLOTS -> {
                // In slot mode, advance slot space
                val currentSlots = _slotItems.value.toMutableList()
                val targetIndex = _activeSlotIndex.value
                if (targetIndex < currentSlots.size - 1) {
                    val nextIndex = targetIndex + 1
                    _activeSlotIndex.value = nextIndex
                    currentSlots[nextIndex] = currentSlots[nextIndex].copy(isActive = true)
                    _slotItems.value = currentSlots
                }
            }
        }
    }

    fun pauseTyping() {
        if (_engineState.value == EngineState.TYPING) {
            isPaused = true
            _engineState.value = EngineState.PAUSED
            FloatingBridge.updateStatus("متوقف مؤقتاً ⏸", _telemetry.value.currentWordText, false)
        }
    }

    fun resumeTyping() {
        if (_engineState.value == EngineState.PAUSED) {
            isPaused = false
            _engineState.value = EngineState.TYPING
            FloatingBridge.updateStatus("جارِ استئناف الكتابة...", _telemetry.value.currentWordText, true)
        }
    }

    fun stopTyping() {
        typingJob?.cancel()
        typingJob = null
        isPaused = false
        _engineState.value = EngineState.IDLE
        FloatingBridge.updateStatus("تم إيقاف الكتابة ⏹", "", false)
    }

    /**
     * Manual repeat button: restarts the typing run or triggers the next cycle manually on tap.
     */
    fun manualRepeat() {
        stopTyping()
        startTyping()
    }

    /**
     * Triggers typing of the next single word directly.
     */
    fun triggerNextWordImmediate() {
        viewModelScope.launch {
            val wordsList = repository.generateSequence(count = 1, isRandom = _config.value.isRandomMode)
            if (wordsList.isNotEmpty()) {
                val word = wordsList.first()
                for (char in word.text) {
                    typeCharacterIntoTarget(char)
                    soundPlayer.playKeyClick(_config.value.isSoundEnabled, _config.value.isHapticsEnabled)
                    delay(_config.value.charSpeedMs.coerceAtLeast(15L))
                }
                appendDelimiterToTarget()
                soundPlayer.playWordBell(_config.value.isSoundEnabled, _config.value.isHapticsEnabled)
            }
        }
    }

    fun updateCharSpeed(speedMs: Long) {
        _config.value = _config.value.copy(charSpeedMs = speedMs.coerceIn(10L, 500L))
    }

    fun updateWordDelay(delayMs: Long) {
        _config.value = _config.value.copy(wordDelayMs = delayMs.coerceIn(0L, 1500L))
    }

    fun updateRandomMode(enabled: Boolean) {
        _config.value = _config.value.copy(isRandomMode = enabled)
    }

    fun updateRandomWordCount(count: Int) {
        _config.value = _config.value.copy(randomWordCount = count.coerceIn(1, 30))
    }

    fun toggleAutoRepeat(enabled: Boolean) {
        _config.value = _config.value.copy(isAutoRepeat = enabled)
    }

    fun toggleSound(enabled: Boolean) {
        _config.value = _config.value.copy(isSoundEnabled = enabled)
    }

    fun toggleHaptics(enabled: Boolean) {
        _config.value = _config.value.copy(isHapticsEnabled = enabled)
    }

    fun toggleHumanJitter(enabled: Boolean) {
        _config.value = _config.value.copy(isHumanJitter = enabled)
    }

    fun setTargetField(field: TargetFieldType) {
        _config.value = _config.value.copy(targetField = field)
    }

    fun selectSlot(index: Int) {
        _activeSlotIndex.value = index.coerceIn(0, _slotItems.value.size - 1)
        val updated = _slotItems.value.mapIndexed { idx, slot ->
            slot.copy(isActive = (idx == index))
        }
        _slotItems.value = updated
    }

    fun clearTarget() {
        when (_config.value.targetField) {
            TargetFieldType.SINGLE_LINE -> _singleLineText.value = ""
            TargetFieldType.MULTI_LINE -> _multiLineText.value = ""
            TargetFieldType.LETTER_SLOTS -> {
                _slotItems.value = List(16) { index -> SlotItem(index = index, isActive = (index == 0)) }
                _activeSlotIndex.value = 0
            }
        }
        _userFeedbackMessage.value = "تم مسح الخانة المحددة"
    }

    fun copyTargetToClipboard(context: Context) {
        val textToCopy = when (_config.value.targetField) {
            TargetFieldType.SINGLE_LINE -> _singleLineText.value
            TargetFieldType.MULTI_LINE -> _multiLineText.value
            TargetFieldType.LETTER_SLOTS -> _slotItems.value.mapNotNull { it.charValue }.joinToString("")
        }

        if (textToCopy.isNotEmpty()) {
            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("AutoWriter Text", textToCopy))
            _userFeedbackMessage.value = "تم نسخ النص إلى الحافظة بنجاح"
        } else {
            _userFeedbackMessage.value = "الخانة فارغة حالياً"
        }
    }

    fun toggleInAppFloatingDialog(visible: Boolean) {
        _inAppFloatingDialogVisible.value = visible
    }

    fun clearFeedbackMessage() {
        _userFeedbackMessage.value = null
    }

    // Word Bank delegate actions
    fun addCustomWord(text: String, category: String) {
        repository.addWord(text, category)
        _userFeedbackMessage.value = "تمت إضافة الكلمة بنجاح"
    }

    fun bulkAddWords(rawText: String, category: String) {
        val count = repository.bulkAddWords(rawText, category)
        _userFeedbackMessage.value = "تم استيراد $count كلمة بنجاح"
    }

    fun deleteWord(id: String) {
        repository.deleteWord(id)
    }

    fun toggleWord(id: String) {
        repository.toggleWord(id)
    }

    fun selectAllWords(select: Boolean) {
        repository.selectAll(select)
    }

    fun resetWordsToDefaults() {
        repository.resetToDefaults()
        _userFeedbackMessage.value = "تمت استعادة الكلمات الافتراضية"
    }

    override fun onCleared() {
        super.onCleared()
        typingJob?.cancel()
        soundPlayer.release()
    }
}
