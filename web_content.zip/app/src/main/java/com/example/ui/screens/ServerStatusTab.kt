package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.ui.MainUiState

@Composable
fun ServerStatusTab(
    state: MainUiState,
    onRefresh: () -> Unit,
    onAction: (String) -> Unit,
    onSendCommand: (String) -> Unit,
    onOpenAdmin: () -> Unit,
    modifier: Modifier = Modifier
) {
    var commandInput by remember { mutableStateOf("") }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // TARJETA DE ESTADO Y MÉTRICAS
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1B2028)),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF2C3442)),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("server_status_card")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    // Header de la tarjeta
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = state.serverStatus.host,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFFFB703)
                            )
                            Text(
                                text = state.serverStatus.motd,
                                fontSize = 12.sp,
                                color = Color(0xFFA0AEC0)
                            )
                        }

                        // Badge de estado online/offline
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .background(
                                    if (state.serverStatus.online) Color(0x332ECC71) else Color(0x33E74C3C)
                                )
                                .border(
                                    1.dp,
                                    if (state.serverStatus.online) Color(0xFF2ECC71) else Color(0xFFE74C3C),
                                    RoundedCornerShape(20.dp)
                                )
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = state.serverStatus.statusText,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (state.serverStatus.online) Color(0xFF2ECC71) else Color(0xFFE74C3C)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Rejilla de métricas: TPS, RAM, Jugadores, CPU
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        MetricBox(
                            label = "TPS",
                            value = "${state.serverStatus.tps}",
                            color = Color(0xFFFFB703),
                            modifier = Modifier.weight(1f)
                        )
                        MetricBox(
                            label = "RAM",
                            value = state.serverStatus.ramUsed,
                            color = Color(0xFF2ECC71),
                            modifier = Modifier.weight(1f)
                        )
                        MetricBox(
                            label = "JUGADORES",
                            value = "${state.serverStatus.playersCount}/${state.serverStatus.maxPlayers}",
                            color = Color(0xFF3498DB),
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Botones de acción Exaroton
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { onAction("start") },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF27AE60)),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f).testTag("btn_server_start")
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = "Iniciar", modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Iniciar", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = { onAction("restart") },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD35400)),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f).testTag("btn_server_restart")
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = "Reiniciar", modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Reiniciar", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = { onAction("stop") },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC0392B)),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f).testTag("btn_server_stop")
                        ) {
                            Icon(Icons.Default.Stop, contentDescription = "Detener", modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Detener", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    if (state.config.exarotonApiToken.isBlank() && state.config.activeServerType == "exaroton") {
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "💡 Para controlar el servidor enciende el Panel Admin con la clave JuancitoChen23.",
                            fontSize = 11.sp,
                            color = Color(0xFFFFC107)
                        )
                    }
                }
            }
        }

        // LISTA DE JUGADORES CONECTADOS REALES
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1B2028)),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF2C3442)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "JUGADORES EN LÍNEA (${state.serverStatus.playersCount})",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFA0AEC0)
                        )
                        IconButton(onClick = onRefresh, modifier = Modifier.size(32.dp)) {
                            if (state.isLoading) {
                                CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color(0xFFFFB703), strokeWidth = 2.dp)
                            } else {
                                Icon(Icons.Default.Refresh, contentDescription = "Recargar", tint = Color(0xFFA0AEC0))
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    if (state.serverStatus.playerList.isEmpty()) {
                        Text(
                            text = "No hay jugadores conectados en este momento.",
                            fontSize = 12.sp,
                            color = Color(0xFF718096),
                            modifier = Modifier.padding(vertical = 8.dp)
                        )
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            state.serverStatus.playerList.forEach { playerName ->
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(Color(0xFF23272E))
                                        .padding(8.dp)
                                ) {
                                    AsyncImage(
                                        model = "https://minotar.net/avatar/$playerName/64.png",
                                        contentDescription = playerName,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier
                                            .size(28.dp)
                                            .clip(RoundedCornerShape(4.dp))
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Text(
                                        text = playerName,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = Color.White
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // CONSOLA DEL SERVIDOR
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1B2028)),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF2C3442)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "CONSOLA DEL SERVIDOR",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFA0AEC0)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Pantalla de terminal
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(120.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color.Black)
                            .border(1.dp, Color(0xFF333333), RoundedCornerShape(8.dp))
                            .padding(8.dp)
                    ) {
                        LazyColumn {
                            items(state.consoleLogs) { log ->
                                Text(
                                    text = log,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 11.sp,
                                    color = Color(0xFF00FF66)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Input de comando
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = commandInput,
                            onValueChange = { commandInput = it },
                            placeholder = { Text("Comando (ej: list, time set day)...", fontSize = 12.sp) },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Color(0xFFFFB703),
                                unfocusedBorderColor = Color(0xFF333A47),
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("console_command_input")
                        )

                        Spacer(modifier = Modifier.width(8.dp))

                        IconButton(
                            onClick = {
                                if (commandInput.isNotBlank()) {
                                    onSendCommand(commandInput.trim())
                                    commandInput = ""
                                }
                            },
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF5E81AC))
                                .testTag("btn_send_command")
                        ) {
                            Icon(Icons.Default.Send, contentDescription = "Enviar", tint = Color.White)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MetricBox(
    label: String,
    value: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0x66000000))
            .border(1.dp, Color(0x1AFFFFFF), RoundedCornerShape(8.dp))
            .padding(vertical = 10.dp, horizontal = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = value,
                fontSize = 15.sp,
                fontWeight = FontWeight.ExtraBold,
                color = color
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = label,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF718096)
            )
        }
    }
}
