package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.R
import com.example.data.local.DownloadedEntity
import com.example.data.local.UserCommentEntity
import com.example.data.model.MediaItem
import com.example.data.model.MediaSource
import com.example.data.model.MediaType
import com.example.data.preferences.UserPreferences
import com.example.ui.theme.YiffyPrimary
import com.example.ui.theme.YiffySecondary
import com.example.ui.theme.YiffySurface
import com.example.ui.theme.YiffySurfaceVariant
import com.example.ui.viewmodel.ProfileSubTab
import com.example.ui.viewmodel.ProfileUiState
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ProfileView(
    uiState: ProfileUiState,
    userPrefs: UserPreferences,
    onSelectSubTab: (ProfileSubTab) -> Unit,
    onToggleDropdown: (Boolean) -> Unit,
    onSelectPlatformFilter: (MediaSource?) -> Unit,
    onSelectMediaTypeFilter: (MediaType?) -> Unit,
    onSelectGenderFilter: (com.example.data.model.GenderFilter?) -> Unit,
    onOpenSettings: () -> Unit,
    onOpenEditProfile: () -> Unit,
    onSaveProfile: (String, String) -> Unit,
    onDeleteDownloaded: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var editName by remember { mutableStateOf(userPrefs.userName) }
    var editBio by remember { mutableStateOf(userPrefs.userBio) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0A0B0E))
    ) {
        // Profile Header with Customizable Banner & Profile Picture
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
        ) {
            // Banner (uses default generated synthwave banner from drawable)
            AsyncImage(
                model = R.drawable.profile_banner_default,
                contentDescription = "Profile Banner",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp)
            )

            // Top-right Settings Gear Icon
            IconButton(
                onClick = onOpenSettings,
                modifier = Modifier
                    .statusBarsPadding()
                    .padding(end = 12.dp, top = 4.dp)
                    .align(Alignment.TopEnd)
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = 0.5f))
                    .testTag("profile_settings_gear_btn")
            ) {
                Icon(
                    Icons.Default.Settings,
                    contentDescription = "Settings",
                    tint = Color.White,
                    modifier = Modifier.size(22.dp)
                )
            }

            // Edit Profile Button on Banner
            IconButton(
                onClick = onOpenEditProfile,
                modifier = Modifier
                    .statusBarsPadding()
                    .padding(end = 60.dp, top = 4.dp)
                    .align(Alignment.TopEnd)
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = 0.5f))
                    .testTag("edit_profile_btn")
            ) {
                Icon(
                    Icons.Default.Edit,
                    contentDescription = "Edit Profile",
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                )
            }

            // Circular Profile Picture (with neon border)
            Box(
                modifier = Modifier
                    .padding(start = 20.dp)
                    .size(86.dp)
                    .align(Alignment.BottomStart)
                    .clip(CircleShape)
                    .border(3.dp, YiffyPrimary, CircleShape)
                    .background(Color(0xFF13151B))
            ) {
                AsyncImage(
                    model = R.drawable.profile_avatar_default,
                    contentDescription = "User Avatar",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }

        // Profile Details (TikTok inspired user handle & bio)
        Column(modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp)) {
            Text(
                text = userPrefs.userName,
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                color = Color.White
            )
            Text(
                text = "@${userPrefs.userName.lowercase().replace(" ", "")} • Yiffy Member",
                style = MaterialTheme.typography.bodySmall,
                color = YiffySecondary
            )
            Spacer(Modifier.height(4.dp))
            Text(
                text = userPrefs.userBio,
                style = MaterialTheme.typography.bodyMedium,
                color = Color.LightGray,
                fontSize = 13.sp
            )
        }

        // Stats Counter Row: Favourites | Likes | Comments (Requested in prompt)
        Surface(
            color = YiffySurfaceVariant,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 8.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                StatCounterItem(
                    count = uiState.favoritesCount,
                    label = "Favourites",
                    tint = Color(0xFFFFB300)
                )
                Box(modifier = Modifier.width(1.dp).height(24.dp).background(Color.DarkGray))
                StatCounterItem(
                    count = uiState.likesCount,
                    label = "Likes",
                    tint = YiffyPrimary
                )
                Box(modifier = Modifier.width(1.dp).height(24.dp).background(Color.DarkGray))
                StatCounterItem(
                    count = uiState.commentsCount,
                    label = "Comments",
                    tint = YiffySecondary
                )
            }
        }

        // Interactive Tab Sliders with Arrow Icon Dropdown Trigger
        val tabs = listOf(
            ProfileSubTab.FAVORITES to "Favourites",
            ProfileSubTab.LIKES to "Likes",
            ProfileSubTab.COMMENTS to "Comments",
            ProfileSubTab.DOWNLOADED to "Downloaded"
        )

        val selectedIndex = tabs.indexOfFirst { it.first == uiState.selectedSubTab }.coerceAtLeast(0)

        Box(modifier = Modifier.fillMaxWidth()) {
            TabRow(
                selectedTabIndex = selectedIndex,
                containerColor = Color(0xFF0F1117),
                contentColor = YiffyPrimary,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[selectedIndex]),
                        color = YiffyPrimary
                    )
                }
            ) {
                tabs.forEachIndexed { index, (tab, title) ->
                    val isSelected = uiState.selectedSubTab == tab
                    Tab(
                        selected = isSelected,
                        onClick = { onSelectSubTab(tab) },
                        modifier = Modifier.testTag("profile_subtab_${tab.name.lowercase()}"),
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                // Requirement: "Make an arrow icon replace the specific tab slider icon
                                // when you click any of these tab sliders, that then shows a drop down menu..."
                                if (isSelected) {
                                    Icon(
                                        if (uiState.isDropdownMenuOpen) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                                        contentDescription = "Filter Options",
                                        tint = YiffyPrimary,
                                        modifier = Modifier.size(16.dp)
                                    )
                                } else {
                                    val icon = when (tab) {
                                        ProfileSubTab.FAVORITES -> Icons.Default.Bookmark
                                        ProfileSubTab.LIKES -> Icons.Default.Favorite
                                        ProfileSubTab.COMMENTS -> Icons.Default.ChatBubble
                                        ProfileSubTab.DOWNLOADED -> Icons.Default.Download
                                    }
                                    Icon(icon, contentDescription = null, modifier = Modifier.size(15.dp))
                                }
                                Spacer(Modifier.width(4.dp))
                                Text(
                                    text = title,
                                    fontSize = 12.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            }
                        }
                    )
                }
            }

            // Dropdown Menu: "choose where your media came from (what website) and what form to scroll the tab in (misc, comics, pictures, videos.)"
            DropdownMenu(
                expanded = uiState.isDropdownMenuOpen,
                onDismissRequest = { onToggleDropdown(false) },
                modifier = Modifier
                    .background(YiffySurface)
                    .border(1.dp, Color(0xFF2B2F3D), RoundedCornerShape(8.dp))
            ) {
                Text(
                    text = "FILTER MEDIA FORMAT",
                    color = YiffyPrimary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                )

                DropdownMenuItem(
                    text = { Text("All Forms", color = if (uiState.selectedMediaTypeFilter == null) YiffyPrimary else Color.White) },
                    onClick = { onSelectMediaTypeFilter(null) }
                )
                MediaType.entries.forEach { type ->
                    DropdownMenuItem(
                        text = { Text(type.label, color = if (uiState.selectedMediaTypeFilter == type) YiffyPrimary else Color.White) },
                        onClick = { onSelectMediaTypeFilter(type) }
                    )
                }

                HorizontalDivider(color = Color.DarkGray, modifier = Modifier.padding(vertical = 4.dp))

                Text(
                    text = "FILTER SOURCE WEBSITE",
                    color = YiffyPrimary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                )

                DropdownMenuItem(
                    text = { Text("All Websites", color = if (uiState.selectedPlatformFilter == null) YiffyPrimary else Color.White) },
                    onClick = { onSelectPlatformFilter(null) }
                )
                MediaSource.entries.forEach { source ->
                    DropdownMenuItem(
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(Color(source.badgeColorHex)))
                                Spacer(Modifier.width(8.dp))
                                Text(source.displayName, color = if (uiState.selectedPlatformFilter == source) YiffyPrimary else Color.White)
                            }
                        },
                        onClick = { onSelectPlatformFilter(source) }
                    )
                }

                HorizontalDivider(color = Color.DarkGray, modifier = Modifier.padding(vertical = 4.dp))

                Text(
                    text = "FILTER GENDER",
                    color = YiffyPrimary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                )

                DropdownMenuItem(
                    text = { Text("Any Gender", color = if (uiState.selectedGenderFilter == null) YiffyPrimary else Color.White) },
                    onClick = { onSelectGenderFilter(null) }
                )
                com.example.data.model.GenderFilter.entries.forEach { filter ->
                    DropdownMenuItem(
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(Color(filter.badgeColorHex)))
                                Spacer(Modifier.width(8.dp))
                                Text(filter.label, color = if (uiState.selectedGenderFilter == filter) YiffyPrimary else Color.White)
                            }
                        },
                        onClick = { onSelectGenderFilter(filter) }
                    )
                }
            }
        }

        // Active filter indicator badge if filters applied
        if (uiState.selectedPlatformFilter != null || uiState.selectedMediaTypeFilter != null || uiState.selectedGenderFilter != null) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Active filter: ", color = Color.Gray, fontSize = 11.sp)
                uiState.selectedMediaTypeFilter?.let {
                    Surface(color = YiffyPrimary.copy(alpha = 0.2f), shape = RoundedCornerShape(4.dp)) {
                        Text(it.label, color = YiffyPrimary, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                    }
                    Spacer(Modifier.width(6.dp))
                }
                uiState.selectedPlatformFilter?.let {
                    Surface(color = Color(it.badgeColorHex).copy(alpha = 0.25f), shape = RoundedCornerShape(4.dp)) {
                        Text(it.displayName, color = Color(it.badgeColorHex), fontSize = 11.sp, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                    }
                    Spacer(Modifier.width(6.dp))
                }
                uiState.selectedGenderFilter?.let {
                    Surface(color = Color(it.badgeColorHex).copy(alpha = 0.25f), shape = RoundedCornerShape(4.dp)) {
                        Text(it.label, color = Color(it.badgeColorHex), fontSize = 11.sp, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                    }
                }
            }
        }

        // Subtab Content Render
        Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
            when (uiState.selectedSubTab) {
                ProfileSubTab.FAVORITES -> {
                    val filtered = remember(uiState.favoritesList, uiState.selectedPlatformFilter, uiState.selectedMediaTypeFilter) {
                        uiState.favoritesList.filter {
                            (uiState.selectedPlatformFilter == null || it.source == uiState.selectedPlatformFilter) &&
                            (uiState.selectedMediaTypeFilter == null || it.type == uiState.selectedMediaTypeFilter)
                        }
                    }
                    MediaGridContent(items = filtered, emptyText = "No favorites recorded for this filter.")
                }
                ProfileSubTab.LIKES -> {
                    val filtered = remember(uiState.likesList, uiState.selectedPlatformFilter, uiState.selectedMediaTypeFilter) {
                        uiState.likesList.filter {
                            (uiState.selectedPlatformFilter == null || it.source == uiState.selectedPlatformFilter) &&
                            (uiState.selectedMediaTypeFilter == null || it.type == uiState.selectedMediaTypeFilter)
                        }
                    }
                    MediaGridContent(items = filtered, emptyText = "No liked media recorded.")
                }
                ProfileSubTab.COMMENTS -> {
                    if (uiState.commentsList.isEmpty()) {
                        EmptyPlaceholder("No comments posted yet.")
                    } else {
                        LazyColumn(
                            contentPadding = PaddingValues(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            items(uiState.commentsList, key = { it.id }) { comment ->
                                UserCommentCard(comment)
                            }
                        }
                    }
                }
                ProfileSubTab.DOWNLOADED -> {
                    // Downloaded Tab: Keeps all comics, videos, and pictures together in hidden folder
                    val filtered = remember(uiState.downloadedList, uiState.selectedPlatformFilter, uiState.selectedMediaTypeFilter) {
                        uiState.downloadedList.filter {
                            (uiState.selectedPlatformFilter == null || it.source == uiState.selectedPlatformFilter?.name) &&
                            (uiState.selectedMediaTypeFilter == null || it.type == uiState.selectedMediaTypeFilter?.name)
                        }
                    }
                    DownloadedContentList(
                        downloads = filtered,
                        folderPath = userPrefs.downloadFolder,
                        onDelete = onDeleteDownloaded
                    )
                }
            }
        }
    }

    // Edit Profile Dialog
    if (uiState.isEditProfileOpen) {
        AlertDialog(
            onDismissRequest = onOpenEditProfile,
            containerColor = YiffySurface,
            title = { Text("Customise Profile", color = Color.White, fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    OutlinedTextField(
                        value = editName,
                        onValueChange = { editName = it },
                        label = { Text("Display Name") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = YiffyPrimary,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(
                        value = editBio,
                        onValueChange = { editBio = it },
                        label = { Text("Bio") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = YiffyPrimary,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 3
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { onSaveProfile(editName, editBio) }) {
                    Text("Save", color = YiffyPrimary, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = onOpenEditProfile) {
                    Text("Cancel", color = Color.Gray)
                }
            }
        )
    }
}

@Composable
fun StatCounterItem(count: Int, label: String, tint: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = count.toString(),
            color = tint,
            fontWeight = FontWeight.Bold,
            fontSize = 17.sp
        )
        Text(
            text = label,
            color = Color.LightGray,
            fontSize = 12.sp
        )
    }
}

@Composable
fun MediaGridContent(items: List<MediaItem>, emptyText: String) {
    if (items.isEmpty()) {
        EmptyPlaceholder(emptyText)
    } else {
        LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            contentPadding = PaddingValues(8.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(items, key = { it.id }) { item ->
                Box(
                    modifier = Modifier
                        .aspectRatio(0.85f)
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0xFF1E212B))
                ) {
                    AsyncImage(
                        model = item.previewUrl.ifBlank { item.mediaUrl },
                        contentDescription = item.title,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )

                    // Platform Tag Badge
                    Surface(
                        color = Color(item.source.badgeColorHex),
                        shape = RoundedCornerShape(bottomEnd = 6.dp),
                        modifier = Modifier.align(Alignment.TopStart)
                    ) {
                        Text(
                            text = item.source.displayName.take(3),
                            color = Color.White,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun DownloadedContentList(
    downloads: List<DownloadedEntity>,
    folderPath: String,
    onDelete: (String) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        // Location path header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF141620))
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Folder, contentDescription = null, tint = YiffyPrimary, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(8.dp))
            Text(
                text = "Hidden storage path: $folderPath",
                color = Color.LightGray,
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        if (downloads.isEmpty()) {
            EmptyPlaceholder("No downloaded media in hidden folder yet.")
        } else {
            LazyColumn(
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(downloads, key = { it.id }) { item ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = YiffySurfaceVariant),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(54.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color.DarkGray)
                            ) {
                                AsyncImage(
                                    model = item.previewUrl,
                                    contentDescription = item.title,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }

                            Spacer(Modifier.width(12.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = item.title,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    maxLines = 1
                                )
                                Text(
                                    text = "${item.source} • ${item.type} • by ${item.author}",
                                    color = Color.Gray,
                                    fontSize = 11.sp
                                )
                                Text(
                                    text = item.localFilePath,
                                    color = Color.DarkGray,
                                    fontSize = 10.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }

                            IconButton(onClick = { onDelete(item.id) }) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Gray)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun UserCommentCard(comment: UserCommentEntity) {
    val dateStr = remember(comment.createdTimestamp) {
        val df = SimpleDateFormat("MMM d, yyyy HH:mm", Locale.getDefault())
        df.format(Date(comment.createdTimestamp))
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = YiffySurfaceVariant),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "On: ${comment.postTitle}",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    maxLines = 1
                )
                Surface(
                    color = YiffySecondary.copy(alpha = 0.2f),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(
                        text = comment.source,
                        color = YiffySecondary,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(Modifier.height(6.dp))

            Text(
                text = "\"${comment.commentText}\"",
                color = Color(0xFFD8DCE8),
                fontSize = 13.sp
            )

            Spacer(Modifier.height(4.dp))

            Text(
                text = dateStr,
                color = Color.Gray,
                fontSize = 10.sp
            )
        }
    }
}

@Composable
fun EmptyPlaceholder(message: String) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = message,
            color = Color.Gray,
            fontSize = 13.sp
        )
    }
}
