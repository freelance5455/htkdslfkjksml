package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FileOpen
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import coil.compose.AsyncImage
import com.example.data.db.VaultFile
import com.example.data.repository.VaultRepository
import com.example.ui.components.SilverButton
import com.example.ui.components.SlantedShape
import com.example.ui.components.TopBarWithClose
import com.example.ui.components.YmTextField
import com.example.ui.theme.AccentRed
import com.example.ui.theme.BlackCharcoal
import com.example.ui.theme.BlackPure
import com.example.ui.theme.SilverDark
import com.example.ui.theme.SilverLight
import com.example.ui.theme.SilverMuted
import com.example.ui.theme.SilverSurface
import com.example.ui.theme.SilverSurfaceVariant
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun FileRecordingScreen(
    repository: VaultRepository,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val categories = listOf(
        "Photos",
        "Videos",
        "Audio",
        "Documents",
        "APKS",
        "Archives",
        "Downloads"
    )

    var selectedCategory by remember { mutableStateOf(categories.first()) }
    val filesFlow = remember(selectedCategory) { repository.getFilesByCategory(selectedCategory) }
    val files by filesFlow.collectAsState(initial = emptyList())

    // Rename dialog state
    var fileToRename by remember { mutableStateOf<VaultFile?>(null) }
    var newFileName by remember { mutableStateOf("") }

    // Delete confirmation state
    var fileToDelete by remember { mutableStateOf<VaultFile?>(null) }

    // File picker launcher
    val filePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris: List<Uri>? ->
        if (!uris.isNullOrEmpty()) {
            scope.launch {
                try {
                    var successCount = 0
                    for (uri in uris) {
                        repository.importFile(uri, selectedCategory)
                        successCount++
                    }
                    Toast.makeText(
                        context,
                        "Successfully imported $successCount file(s) into $selectedCategory",
                        Toast.LENGTH_SHORT
                    ).show()
                } catch (e: Exception) {
                    Toast.makeText(context, "Error importing: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    fun openFile(vaultFile: VaultFile) {
        val file = File(vaultFile.filePath)
        if (!file.exists()) {
            Toast.makeText(context, "File does not exist on disk", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, vaultFile.mimeType.ifEmpty { "*/*" })
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, "Open with"))
        } catch (e: Exception) {
            Toast.makeText(context, "No app found to open this file format", Toast.LENGTH_SHORT).show()
        }
    }

    fun shareFile(vaultFile: VaultFile) {
        val file = File(vaultFile.filePath)
        if (!file.exists()) {
            Toast.makeText(context, "File does not exist", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = vaultFile.mimeType.ifEmpty { "*/*" }
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, "Share file"))
        } catch (e: Exception) {
            Toast.makeText(context, "Error sharing file: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SilverLight)
    ) {
        // Mandatory X button at top
        TopBarWithClose(
            title = "File Recording",
            subtitle = "Offline Secure Vault Storage",
            onCloseClick = onBack
        )

        // Horizontal Category Tabs
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            for (category in categories) {
                val isSelected = category == selectedCategory
                val catIcon = getCategoryIcon(category)

                Box(
                    modifier = Modifier
                        .clip(SlantedShape)
                        .background(if (isSelected) BlackPure else SilverSurface)
                        .border(
                            BorderStroke(1.2.dp, BlackPure),
                            SlantedShape
                        )
                        .clickable { selectedCategory = category }
                        .padding(horizontal = 14.dp, vertical = 9.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = catIcon,
                            contentDescription = category,
                            tint = if (isSelected) SilverLight else BlackPure,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = category,
                            style = MaterialTheme.typography.titleMedium.copy(fontSize = 13.sp),
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = if (isSelected) SilverLight else BlackPure
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Import Button Bar
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp)
        ) {
            SilverButton(
                text = "Import to $selectedCategory",
                icon = Icons.Default.Add,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("btn_import_file"),
                onClick = {
                    val mimeFilter = when (selectedCategory) {
                        "Photos" -> arrayOf("image/*")
                        "Videos" -> arrayOf("video/*")
                        "Audio" -> arrayOf("audio/*")
                        "Documents" -> arrayOf(
                            "application/pdf",
                            "application/msword",
                            "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                            "text/*"
                        )
                        "APKS" -> arrayOf("application/vnd.android.package-archive", "*/*")
                        "Archives" -> arrayOf("application/zip", "application/x-rar-compressed", "*/*")
                        else -> arrayOf("*/*")
                    }
                    filePicker.launch(mimeFilter)
                }
            )
        }

        // File List or Empty State
        if (files.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .clip(SlantedShape)
                            .background(SilverSurface)
                            .border(BorderStroke(1.5.dp, BlackPure), SlantedShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = getCategoryIcon(selectedCategory),
                            contentDescription = null,
                            tint = BlackPure,
                            modifier = Modifier.size(36.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "No $selectedCategory Saved",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = BlackPure
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Files saved into the application are copied into private local storage and remain available even if deleted from the device.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = SilverDark,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 32.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(files, key = { it.id }) { vaultFile ->
                    VaultFileCard(
                        vaultFile = vaultFile,
                        onOpen = { openFile(vaultFile) },
                        onShare = { shareFile(vaultFile) },
                        onRename = {
                            fileToRename = vaultFile
                            newFileName = vaultFile.fileName.substringBeforeLast('.')
                        },
                        onDelete = { fileToDelete = vaultFile }
                    )
                }
            }
        }
    }

    // Rename Dialog
    fileToRename?.let { file ->
        AlertDialog(
            onDismissRequest = { fileToRename = null },
            title = {
                Text(
                    text = "Rename File",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = BlackPure
                )
            },
            text = {
                Column {
                    YmTextField(
                        value = newFileName,
                        onValueChange = { newFileName = it },
                        label = "File Name",
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        val clean = newFileName.trim()
                        if (clean.isNotEmpty()) {
                            scope.launch {
                                repository.renameVaultFile(file, clean)
                                fileToRename = null
                            }
                        }
                    }
                ) {
                    Text("Save", color = BlackPure, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { fileToRename = null }) {
                    Text("Cancel", color = SilverDark)
                }
            },
            containerColor = SilverLight,
            shape = SlantedShape
        )
    }

    // Delete Confirmation Dialog
    fileToDelete?.let { file ->
        AlertDialog(
            onDismissRequest = { fileToDelete = null },
            title = {
                Text(
                    text = "Delete File?",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = BlackPure
                )
            },
            text = {
                Text(
                    text = "Are you sure you want to permanently remove \"${file.fileName}\" from YM Secret vault?",
                    style = MaterialTheme.typography.bodyMedium,
                    color = BlackCharcoal
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        scope.launch {
                            repository.deleteVaultFile(file)
                            fileToDelete = null
                        }
                    }
                ) {
                    Text("Delete", color = AccentRed, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { fileToDelete = null }) {
                    Text("Cancel", color = SilverDark)
                }
            },
            containerColor = SilverLight,
            shape = SlantedShape
        )
    }
}

@Composable
fun VaultFileCard(
    vaultFile: VaultFile,
    onOpen: () -> Unit,
    onShare: () -> Unit,
    onRename: () -> Unit,
    onDelete: () -> Unit
) {
    var menuExpanded by remember { mutableStateOf(false) }
    val formattedDate = remember(vaultFile.createdAt) {
        val sdf = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())
        sdf.format(Date(vaultFile.createdAt))
    }
    val formattedSize = remember(vaultFile.sizeBytes) {
        formatBytes(vaultFile.sizeBytes)
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(SlantedShape)
            .background(SilverSurface)
            .border(BorderStroke(1.2.dp, BlackPure), SlantedShape)
            .clickable { onOpen() }
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Thumbnail or Category Icon
            if (vaultFile.category == "Photos") {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(SlantedShape)
                        .border(BorderStroke(1.dp, BlackPure), SlantedShape)
                ) {
                    AsyncImage(
                        model = File(vaultFile.filePath),
                        contentDescription = vaultFile.fileName,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            } else {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(SlantedShape)
                        .background(SilverSurfaceVariant)
                        .border(BorderStroke(1.dp, BlackPure), SlantedShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = getCategoryIcon(vaultFile.category),
                        contentDescription = vaultFile.category,
                        tint = BlackPure,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            // File Info
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = vaultFile.fileName,
                    style = MaterialTheme.typography.titleMedium.copy(fontSize = 14.sp),
                    fontWeight = FontWeight.Bold,
                    color = BlackPure,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(2.dp))
                Row {
                    Text(
                        text = formattedSize,
                        style = MaterialTheme.typography.labelSmall,
                        color = SilverDark
                    )
                    Text(
                        text = " • $formattedDate",
                        style = MaterialTheme.typography.labelSmall,
                        color = SilverDark
                    )
                }
            }

            // More Options Menu
            Box {
                IconButton(onClick = { menuExpanded = true }) {
                    Icon(
                        imageVector = Icons.Default.MoreVert,
                        contentDescription = "Options",
                        tint = BlackPure
                    )
                }

                DropdownMenu(
                    expanded = menuExpanded,
                    onDismissRequest = { menuExpanded = false },
                    modifier = Modifier.background(SilverLight)
                ) {
                    DropdownMenuItem(
                        text = { Text("Open / View", color = BlackPure) },
                        leadingIcon = { Icon(Icons.Default.FileOpen, contentDescription = null, tint = BlackPure) },
                        onClick = {
                            menuExpanded = false
                            onOpen()
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Share", color = BlackPure) },
                        leadingIcon = { Icon(Icons.Default.Share, contentDescription = null, tint = BlackPure) },
                        onClick = {
                            menuExpanded = false
                            onShare()
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Rename", color = BlackPure) },
                        leadingIcon = { Icon(Icons.Default.Edit, contentDescription = null, tint = BlackPure) },
                        onClick = {
                            menuExpanded = false
                            onRename()
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Delete", color = AccentRed) },
                        leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = AccentRed) },
                        onClick = {
                            menuExpanded = false
                            onDelete()
                        }
                    )
                }
            }
        }
    }
}

fun getCategoryIcon(category: String): ImageVector {
    return when (category) {
        "Photos" -> Icons.Default.Image
        "Videos" -> Icons.Default.Videocam
        "Audio" -> Icons.Default.Audiotrack
        "Documents" -> Icons.Default.Description
        "APKS" -> Icons.Default.Android
        "Archives" -> Icons.Default.FolderZip
        "Downloads" -> Icons.Default.Download
        else -> Icons.Default.Description
    }
}

fun formatBytes(bytes: Long): String {
    if (bytes <= 0) return "0 B"
    val units = arrayOf("B", "KB", "MB", "GB", "TB")
    val digitGroups = (Math.log10(bytes.toDouble()) / Math.log10(1024.0)).toInt().coerceIn(0, units.size - 1)
    return String.format(Locale.getDefault(), "%.1f %s", bytes / Math.pow(1024.0, digitGroups.toDouble()), units[digitGroups])
}
