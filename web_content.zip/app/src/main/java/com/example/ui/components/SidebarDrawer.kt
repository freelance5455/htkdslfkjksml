package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Public
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.GenderFilter
import com.example.data.model.MediaSource
import com.example.ui.theme.YiffyPrimary
import com.example.ui.theme.YiffySecondary
import com.example.ui.theme.YiffySurface
import com.example.ui.theme.YiffySurfaceVariant
import com.example.ui.viewmodel.MainNavigationTab

@Composable
fun SidebarDrawer(
    currentTab: MainNavigationTab,
    selectedSource: MediaSource?,
    genderFilter: GenderFilter,
    isGoogleConnected: Boolean,
    onSelectTab: (MainNavigationTab) -> Unit,
    onSelectSource: (MediaSource?) -> Unit,
    onSelectGenderFilter: (GenderFilter) -> Unit,
    onClose: () -> Unit
) {
    val scrollState = rememberScrollState()

    ModalDrawerSheet(
        drawerContainerColor = YiffySurface,
        modifier = Modifier
            .width(310.dp)
            .fillMaxHeight()
            .testTag("sidebar_drawer_sheet")
    ) {
        Column(
            modifier = Modifier
                .fillMaxHeight()
                .verticalScroll(scrollState)
                .padding(16.dp)
                .statusBarsPadding()
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(YiffyPrimary),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("Y", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                    Spacer(Modifier.width(10.dp))
                    Text(
                        text = "Yiffy Hub",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                        color = Color.White
                    )
                }

                IconButton(onClick = onClose) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.LightGray)
                }
            }

            Spacer(Modifier.height(16.dp))

            // Navigation Tabs Section
            Text(
                text = "NAVIGATE TABS",
                color = YiffySecondary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
            )

            val tabs = listOf(
                MainNavigationTab.PROFILE to ("Profile" to Icons.Default.AccountCircle),
                MainNavigationTab.VIDEOS to ("Videos" to Icons.Default.Movie),
                MainNavigationTab.PICTURES to ("Pictures" to Icons.Default.Image),
                MainNavigationTab.COMICS to ("Comics" to Icons.Default.Book),
                MainNavigationTab.MISC to ("Miscellaneous" to Icons.Default.Public)
            )

            tabs.forEach { (tab, info) ->
                val (label, icon) = info
                NavigationDrawerItem(
                    label = { Text(label, fontWeight = FontWeight.SemiBold) },
                    icon = { Icon(icon, contentDescription = null) },
                    selected = currentTab == tab,
                    onClick = {
                        onSelectTab(tab)
                        onClose()
                    },
                    colors = NavigationDrawerItemDefaults.colors(
                        selectedContainerColor = YiffyPrimary.copy(alpha = 0.2f),
                        selectedTextColor = YiffyPrimary,
                        selectedIconColor = YiffyPrimary,
                        unselectedTextColor = Color.LightGray,
                        unselectedIconColor = Color.LightGray
                    ),
                    modifier = Modifier.padding(vertical = 2.dp)
                )
            }

            HorizontalDivider(color = Color(0xFF232734), modifier = Modifier.padding(vertical = 12.dp))

            // Gender Filter Section (Requested by user)
            Text(
                text = "GENDER FILTERING",
                color = YiffySecondary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
            )

            GenderFilter.entries.forEach { filter ->
                val isSelected = genderFilter == filter
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .clickable {
                            onSelectGenderFilter(filter)
                            onClose()
                        }
                        .padding(horizontal = 12.dp, vertical = 7.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(Color(filter.badgeColorHex))
                        )
                        Spacer(Modifier.width(10.dp))
                        Text(
                            text = filter.label,
                            color = if (isSelected) YiffyPrimary else Color.White,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 13.sp
                        )
                    }

                    if (isSelected) {
                        Icon(Icons.Default.Check, contentDescription = null, tint = YiffyPrimary, modifier = Modifier.size(16.dp))
                    }
                }
            }

            HorizontalDivider(color = Color(0xFF232734), modifier = Modifier.padding(vertical = 12.dp))

            // Source Filter Section
            Text(
                text = "FILTER SOURCE PLATFORM",
                color = YiffySecondary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .clickable {
                        onSelectSource(null)
                        onClose()
                    }
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "All Platforms",
                    color = if (selectedSource == null) YiffyPrimary else Color.White,
                    fontWeight = FontWeight.Medium,
                    fontSize = 13.sp
                )
                if (selectedSource == null) {
                    Icon(Icons.Default.Check, contentDescription = null, tint = YiffyPrimary, modifier = Modifier.size(16.dp))
                }
            }

            MediaSource.entries.forEach { source ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .clickable {
                            onSelectSource(source)
                            onClose()
                        }
                        .padding(horizontal = 12.dp, vertical = 7.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(Color(source.badgeColorHex))
                        )
                        Spacer(Modifier.width(10.dp))
                        Text(
                            text = source.displayName,
                            color = if (selectedSource == source) YiffyPrimary else Color.White,
                            fontSize = 13.sp
                        )
                    }

                    if (selectedSource == source) {
                        Icon(Icons.Default.Check, contentDescription = null, tint = YiffyPrimary, modifier = Modifier.size(16.dp))
                    }
                }
            }

            Spacer(Modifier.height(16.dp))

            // Bottom Status Card
            Surface(
                color = YiffySurfaceVariant,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Default.CloudDone,
                        contentDescription = null,
                        tint = if (isGoogleConnected) Color(0xFF4CAF50) else Color.Gray,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.width(8.dp))
                    Column {
                        Text(
                            text = if (isGoogleConnected) "Google Drive Synced" else "Drive Sync Inactive",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Filter: ${genderFilter.label}",
                            color = Color(genderFilter.badgeColorHex),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }
    }
}
