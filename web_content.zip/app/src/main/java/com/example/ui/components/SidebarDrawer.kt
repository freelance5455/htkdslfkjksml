package com.example.ui.components

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.ChatSession
import com.example.ui.AppScreen
import com.example.ui.theme.AccentError
import com.example.ui.theme.PurpleDark
import com.example.ui.theme.PurpleLight
import com.example.ui.theme.PurplePrimary
import com.example.ui.theme.SuesaBackground
import com.example.ui.theme.SuesaCardBorder
import com.example.ui.theme.SuesaSurface
import com.example.ui.theme.SuesaSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun SidebarDrawer(
    sessions: List<ChatSession>,
    activeSessionId: Long?,
    currentScreen: AppScreen,
    onSelectSession: (ChatSession) -> Unit,
    onNewChatClick: () -> Unit,
    onNavigate: (AppScreen) -> Unit,
    sessionToDelete: ChatSession?,
    onRequestDeleteSession: (ChatSession) -> Unit,
    onConfirmDeleteSession: () -> Unit,
    onDismissDeleteDialog: () -> Unit,
    onCloseDrawer: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxHeight()
            .width(300.dp)
            .background(Color(0xFF141416))
            .statusBarsPadding()
            .padding(16.dp)
    ) {
        // App Brand Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.linearGradient(
                            listOf(PurplePrimary, PurpleDark)
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "S",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column {
                Text(
                    text = "Suesa AI",
                    color = TextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Akıllı Asistan",
                    color = PurpleLight,
                    fontSize = 12.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // New Chat Button
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(
                    Brush.linearGradient(
                        listOf(PurpleDark, PurplePrimary)
                    )
                )
                .combinedClickable(
                    onClick = {
                        onNewChatClick()
                        onCloseDrawer()
                    }
                )
                .padding(vertical = 12.dp, horizontal = 16.dp)
                .testTag("new_chat_drawer_button"),
            contentAlignment = Alignment.Center
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Yeni Sohbet",
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Yeni Sohbet",
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Section Title: Sohbet Geçmişi
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 4.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "SOHBET GEÇMİŞİ",
                color = TextMuted,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
        }

        // Sessions List
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            if (sessions.isEmpty()) {
                item {
                    Text(
                        text = "Henüz kayıtlı sohbet yok.",
                        color = TextMuted,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(8.dp)
                    )
                }
            } else {
                items(sessions, key = { it.id }) { session ->
                    val isActive = session.id == activeSessionId && currentScreen == AppScreen.CHAT
                    val dateFormatted = remember(session.updatedAt) {
                        val sdf = SimpleDateFormat("dd MMM, HH:mm", Locale.forLanguageTag("tr-TR"))
                        sdf.format(Date(session.updatedAt))
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (isActive) Color(0xFF261F33) else Color.Transparent)
                            .border(
                                1.dp,
                                if (isActive) PurplePrimary.copy(alpha = 0.5f) else Color.Transparent,
                                RoundedCornerShape(10.dp)
                            )
                            .combinedClickable(
                                onClick = {
                                    onSelectSession(session)
                                    onCloseDrawer()
                                },
                                onLongClick = {
                                    onRequestDeleteSession(session)
                                }
                            )
                            .padding(horizontal = 10.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.ChatBubbleOutline,
                            contentDescription = "Sohbet",
                            tint = if (isActive) PurplePrimary else TextMuted,
                            modifier = Modifier.size(18.dp)
                        )

                        Spacer(modifier = Modifier.width(10.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = session.title,
                                color = if (isActive) TextPrimary else TextSecondary,
                                fontSize = 14.sp,
                                fontWeight = if (isActive) FontWeight.SemiBold else FontWeight.Normal,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = dateFormatted,
                                color = TextMuted,
                                fontSize = 11.sp
                            )
                        }

                        // Delete icon button
                        IconButton(
                            onClick = { onRequestDeleteSession(session) },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.DeleteOutline,
                                contentDescription = "Sohbeti Sil",
                                tint = TextMuted,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        }

        HorizontalDivider(
            color = SuesaCardBorder,
            modifier = Modifier.padding(vertical = 12.dp)
        )

        // Bottom Navigation Items
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            DrawerNavItem(
                icon = Icons.Default.ChatBubbleOutline,
                title = "Sohbet",
                isSelected = currentScreen == AppScreen.CHAT,
                onClick = {
                    onNavigate(AppScreen.CHAT)
                    onCloseDrawer()
                }
            )

            DrawerNavItem(
                icon = Icons.Default.AutoAwesome,
                title = "Oluştur (Görsel & Video)",
                isSelected = currentScreen == AppScreen.CREATION,
                onClick = {
                    onNavigate(AppScreen.CREATION)
                    onCloseDrawer()
                }
            )

            DrawerNavItem(
                icon = Icons.Default.Settings,
                title = "Ayarlar",
                isSelected = currentScreen == AppScreen.SETTINGS,
                onClick = {
                    onNavigate(AppScreen.SETTINGS)
                    onCloseDrawer()
                }
            )
        }
    }

    // Delete Confirmation Dialog
    if (sessionToDelete != null) {
        AlertDialog(
            onDismissRequest = onDismissDeleteDialog,
            title = {
                Text(
                    text = "Sohbeti Sil",
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            },
            text = {
                Text(
                    text = "Bu sohbeti silmek istediğine emin misin?\n(\"${sessionToDelete.title}\")",
                    color = TextSecondary,
                    fontSize = 14.sp
                )
            },
            confirmButton = {
                TextButton(
                    onClick = onConfirmDeleteSession,
                    colors = ButtonDefaults.textButtonColors(contentColor = AccentError),
                    modifier = Modifier.testTag("confirm_delete_button")
                ) {
                    Text("Sil", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = onDismissDeleteDialog,
                    colors = ButtonDefaults.textButtonColors(contentColor = TextSecondary),
                    modifier = Modifier.testTag("cancel_delete_button")
                ) {
                    Text("İptal")
                }
            },
            containerColor = SuesaSurface,
            shape = RoundedCornerShape(16.dp)
        )
    }
}

@Composable
fun DrawerNavItem(
    icon: ImageVector,
    title: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(if (isSelected) Color(0xFF261F33) else Color.Transparent)
            .border(
                1.dp,
                if (isSelected) PurplePrimary.copy(alpha = 0.5f) else Color.Transparent,
                RoundedCornerShape(10.dp)
            )
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = title,
            tint = if (isSelected) PurplePrimary else TextMuted,
            modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.width(12.dp))
        Text(
            text = title,
            color = if (isSelected) TextPrimary else TextSecondary,
            fontSize = 14.sp,
            fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal
        )
    }
}
