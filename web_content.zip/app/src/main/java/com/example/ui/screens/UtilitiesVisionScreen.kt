package com.example.ui.screens

import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.DocumentScanner
import androidx.compose.material.icons.filled.HourglassBottom
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.XtraCardBorder
import com.example.ui.theme.XtraCardDark
import com.example.ui.theme.XtraCyanGlow
import com.example.ui.theme.XtraCyanPrimary
import com.example.ui.theme.XtraDarkNavyBg
import com.example.ui.theme.XtraElectricBlue
import com.example.ui.theme.XtraNeonGreen
import com.example.ui.theme.XtraSurfaceDark
import com.example.ui.theme.XtraTextHigh
import com.example.ui.theme.XtraTextMed
import com.example.ui.theme.XtraWarningGold
import com.example.viewmodel.MainViewModel
import kotlinx.coroutines.delay

@Composable
fun UtilitiesVisionScreen(viewModel: MainViewModel) {
    val weather by viewModel.weather.collectAsState()
    val visionResult by viewModel.visionResult.collectAsState()
    val isAnalyzing by viewModel.isAnalyzingVision.collectAsState()

    val context = LocalContext.current
    val scrollState = rememberScrollState()

    var analyzedBitmap by remember { mutableStateOf<Bitmap?>(null) }

    // Photo Picker
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                val bitmap = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    val source = ImageDecoder.createSource(context.contentResolver, uri)
                    ImageDecoder.decodeBitmap(source)
                } else {
                    @Suppress("DEPRECATION")
                    MediaStore.Images.Media.getBitmap(context.contentResolver, uri)
                }
                analyzedBitmap = bitmap
                viewModel.handleUserQuery("Analyze this photo thoroughly, extract any text, and explain key objects", bitmap)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    // Camera Capture
    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicturePreview()
    ) { bitmap: Bitmap? ->
        if (bitmap != null) {
            analyzedBitmap = bitmap
            viewModel.handleUserQuery("Perform AI vision diagnosis on this camera capture", bitmap)
        }
    }

    // In-app interactive calculator state
    var calcInput by remember { mutableStateOf("25 * 40 + 150") }
    var calcOutput by remember { mutableStateOf("1150") }

    // In-app interactive timer state
    var timerSeconds by remember { mutableIntStateOf(0) }
    var isTimerRunning by remember { mutableStateOf(false) }

    LaunchedEffect(isTimerRunning) {
        while (isTimerRunning && timerSeconds > 0) {
            delay(1000L)
            timerSeconds--
            if (timerSeconds == 0) {
                isTimerRunning = false
                viewModel.voiceManager.speak("Timer complete, Sir.")
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(XtraDarkNavyBg)
            .verticalScroll(scrollState)
            .padding(16.dp)
            .testTag("utilities_vision_screen")
    ) {
        // Screen Header
        Column {
            Text(
                text = "COGNITIVE SENSORS & UTILITIES",
                color = XtraCyanGlow,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 1.sp
            )
            Text(
                text = "Vision & Utilities",
                color = XtraTextHigh,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 1. AI Vision Analyzer Section
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = XtraCardDark),
            border = androidx.compose.foundation.BorderStroke(1.dp, XtraCyanPrimary.copy(alpha = 0.5f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Visibility,
                            contentDescription = null,
                            tint = XtraCyanPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "AI VISION & OCR ANALYZER",
                            color = XtraCyanPrimary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    if (isAnalyzing) {
                        CircularProgressIndicator(
                            color = XtraCyanPrimary,
                            modifier = Modifier.size(18.dp),
                            strokeWidth = 2.dp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "Capture photos or pick gallery images to detect text (OCR), identify objects, and analyze documents.",
                    color = XtraTextMed,
                    fontSize = 12.sp
                )

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Button(
                        onClick = { cameraLauncher.launch(null) },
                        colors = ButtonDefaults.buttonColors(containerColor = XtraCyanPrimary),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("vision_camera_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.CameraAlt,
                            contentDescription = "Camera",
                            tint = Color(0xFF00363D),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Scan Camera", color = Color(0xFF00363D), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }

                    OutlinedButton(
                        onClick = {
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        border = androidx.compose.foundation.BorderStroke(1.dp, XtraCardBorder),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("vision_gallery_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.PhotoLibrary,
                            contentDescription = "Gallery",
                            tint = XtraCyanPrimary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("From Gallery", color = XtraTextHigh, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                    }
                }

                // Vision analysis result display
                analyzedBitmap?.let { bitmap ->
                    Spacer(modifier = Modifier.height(12.dp))
                    Image(
                        bitmap = bitmap.asImageBitmap(),
                        contentDescription = "Analyzed target",
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(160.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .border(1.dp, XtraCardBorder, RoundedCornerShape(10.dp))
                    )
                }

                visionResult?.let { result ->
                    Spacer(modifier = Modifier.height(12.dp))
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = XtraSurfaceDark,
                        border = androidx.compose.foundation.BorderStroke(1.dp, XtraCardBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = result.summary,
                                color = XtraTextHigh,
                                fontSize = 13.sp,
                                lineHeight = 19.sp
                            )
                            if (result.detectedText.isNotBlank()) {
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "📄 OCR Output: ${result.detectedText}",
                                    color = XtraCyanGlow,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 2. Weather Live Widget
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = XtraCardDark),
            border = androidx.compose.foundation.BorderStroke(1.dp, XtraCardBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Cloud,
                            contentDescription = null,
                            tint = XtraCyanPrimary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "ATMOSPHERIC METRICS",
                            color = XtraCyanPrimary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    IconButton(onClick = { viewModel.loadWeather() }) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Refresh Weather",
                            tint = XtraTextMed,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column {
                        Text(
                            text = "${weather.tempC.toInt()}°C",
                            color = XtraTextHigh,
                            fontSize = 36.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = weather.condition,
                            color = XtraCyanGlow,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(text = "Humidity: ${weather.humidityPercent}%", color = XtraTextMed, fontSize = 12.sp)
                        Text(text = "Wind: ${weather.windSpeedKmh} km/h", color = XtraTextMed, fontSize = 12.sp)
                        Text(text = "High / Low: ${weather.highTemp.toInt()}° / ${weather.lowTemp.toInt()}°", color = XtraTextMed, fontSize = 12.sp)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 3. Calculator & Alarm Quick Card
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = XtraCardDark),
            border = androidx.compose.foundation.BorderStroke(1.dp, XtraCardBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Calculate,
                        contentDescription = null,
                        tint = XtraCyanPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "SMART CALCULATOR & CONVERTER",
                        color = XtraCyanPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedTextField(
                        value = calcInput,
                        onValueChange = {
                            calcInput = it
                            try {
                                val clean = it.replace(" ", "").replace("x", "*")
                                when {
                                    clean.contains("+") -> {
                                        val p = clean.split("+")
                                        calcOutput = (p[0].toDouble() + p[1].toDouble()).toString()
                                    }
                                    clean.contains("-") -> {
                                        val p = clean.split("-")
                                        calcOutput = (p[0].toDouble() - p[1].toDouble()).toString()
                                    }
                                    clean.contains("*") -> {
                                        val p = clean.split("*")
                                        calcOutput = (p[0].toDouble() * p[1].toDouble()).toString()
                                    }
                                    clean.contains("/") -> {
                                        val p = clean.split("/")
                                        calcOutput = (p[0].toDouble() / p[1].toDouble()).toString()
                                    }
                                    else -> {}
                                }
                            } catch (e: Exception) {}
                        },
                        label = { Text("Expression") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = XtraTextHigh,
                            unfocusedTextColor = XtraTextHigh,
                            focusedBorderColor = XtraCyanPrimary,
                            unfocusedBorderColor = XtraCardBorder
                        ),
                        modifier = Modifier.weight(1f)
                    )

                    Spacer(modifier = Modifier.width(10.dp))

                    Column(horizontalAlignment = Alignment.End) {
                        Text(text = "= $calcOutput", color = XtraNeonGreen, fontSize = 18.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 4. Timer & Alarm
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = XtraCardDark),
            border = androidx.compose.foundation.BorderStroke(1.dp, XtraCardBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.HourglassBottom,
                            contentDescription = null,
                            tint = XtraCyanPrimary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "TIMER & ALARM PROTOCOL",
                            color = XtraCyanPrimary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Text(
                        text = String.format("%02d:%02d", timerSeconds / 60, timerSeconds % 60),
                        color = XtraWarningGold,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedButton(
                        onClick = {
                            timerSeconds = 300 // 5 min
                            isTimerRunning = true
                        },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("5 Min", color = XtraTextHigh, fontSize = 11.sp)
                    }

                    OutlinedButton(
                        onClick = {
                            timerSeconds = 600 // 10 min
                            isTimerRunning = true
                        },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("10 Min", color = XtraTextHigh, fontSize = 11.sp)
                    }

                    Button(
                        onClick = {
                            isTimerRunning = !isTimerRunning
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isTimerRunning) XtraWarningGold else XtraCyanPrimary
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1.2f)
                    ) {
                        Icon(
                            imageVector = if (isTimerRunning) Icons.Default.Stop else Icons.Default.PlayArrow,
                            contentDescription = null,
                            tint = Color.Black,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(if (isTimerRunning) "Stop" else "Start", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }

                    OutlinedButton(
                        onClick = {
                            viewModel.deviceManager.setAlarm(7, 0, "Morning Alert by XTRA")
                        },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1.2f)
                    ) {
                        Icon(imageVector = Icons.Default.Alarm, contentDescription = null, tint = XtraCyanPrimary, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Alarm 7AM", color = XtraTextHigh, fontSize = 11.sp)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}
