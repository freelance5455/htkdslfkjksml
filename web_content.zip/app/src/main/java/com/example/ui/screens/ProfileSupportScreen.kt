package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.localization.AppLang
import com.example.localization.SjsStrings
import com.example.model.*
import com.example.ui.components.DigitalReceiptDialog
import com.example.ui.theme.*
import com.example.viewmodel.UiState

@Composable
fun ProfileSupportScreen(
    lang: AppLang,
    currentUserEmail: String,
    isAdminUser: Boolean,
    activeRole: ActiveAppRole,
    userProfileState: UiState<UserProfile?>,
    payments: List<PaymentTransaction>,
    complaints: List<Complaint>,
    isBusy: Boolean,
    onSwitchRole: (ActiveAppRole) -> Unit,
    onSetLanguage: (AppLang) -> Unit,
    onUpdateProfile: (String, String, String, String) -> Unit,
    onSubmitComplaint: (String, String) -> Unit,
    onSignOut: () -> Unit
) {
    val profile = (userProfileState as? UiState.Success)?.data
    var fullName by remember(profile?.fullName) { mutableStateOf(profile?.fullName ?: "") }
    var phone by remember(profile?.phone) { mutableStateOf(profile?.phone ?: "") }
    var region by remember(profile?.region) { mutableStateOf(profile?.region ?: "Dar es Salaam") }
    var address by remember(profile?.address) { mutableStateOf(profile?.address ?: "") }

    var showComplaintDialog by remember { mutableStateOf(false) }
    var receiptToView by remember { mutableStateOf<PaymentTransaction?>(null) }

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(OffWhite),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Role Switcher & Language
        item {
            Card(colors = CardDefaults.cardColors(containerColor = NavyDeep), shape = RoundedCornerShape(18.dp)) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = profile?.fullName?.ifBlank { currentUserEmail } ?: currentUserEmail,
                        style = MaterialTheme.typography.titleLarge,
                        color = PureWhite
                    )
                    Text(currentUserEmail, style = MaterialTheme.typography.bodySmall, color = BorderGrey)

                    Text(SjsStrings.t(lang, "Badili Muonekano / Akaunti", "Switch Workspace"), style = MaterialTheme.typography.labelMedium, color = OrangeBright)
                    Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = activeRole == ActiveAppRole.CUSTOMER,
                            onClick = { onSwitchRole(ActiveAppRole.CUSTOMER) },
                            label = { Text(SjsStrings.t(lang, "Mteja (Customer)", "Customer")) }
                        )
                        FilterChip(
                            selected = activeRole == ActiveAppRole.PROVIDER,
                            onClick = { onSwitchRole(ActiveAppRole.PROVIDER) },
                            label = { Text(SjsStrings.t(lang, "Kampuni (Provider)", "Provider")) }
                        )
                        if (isAdminUser) {
                            FilterChip(
                                selected = activeRole == ActiveAppRole.ADMIN,
                                onClick = { onSwitchRole(ActiveAppRole.ADMIN) },
                                label = { Text("Admin Dashboard") }
                            )
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(SjsStrings.t(lang, "Lugha:", "Language:"), style = MaterialTheme.typography.labelMedium, color = PureWhite)
                        FilterChip(selected = lang == AppLang.SW, onClick = { onSetLanguage(AppLang.SW) }, label = { Text("Kiswahili") })
                        FilterChip(selected = lang == AppLang.EN, onClick = { onSetLanguage(AppLang.EN) }, label = { Text("English") })
                    }
                }
            }
        }

        // 2. Profile Form
        item {
            Card(colors = CardDefaults.cardColors(containerColor = PureWhite), shape = RoundedCornerShape(18.dp)) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(SjsStrings.t(lang, "Wasifu Wangu", "My Profile"), style = MaterialTheme.typography.titleMedium, color = NavyDeep)
                    OutlinedTextField(value = fullName, onValueChange = { fullName = it }, label = { Text(SjsStrings.t(lang, "Jina Kamili", "Full Name")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text(SjsStrings.t(lang, "Namba ya Simu", "Phone Number")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = region, onValueChange = { region = it }, label = { Text(SjsStrings.t(lang, "Mkoa", "Region")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = address, onValueChange = { address = it }, label = { Text(SjsStrings.t(lang, "Anwani / Mtaa", "Street Address")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Button(
                        onClick = { onUpdateProfile(fullName, phone, region, address) },
                        enabled = !isBusy && fullName.isNotBlank(),
                        colors = ButtonDefaults.buttonColors(containerColor = OrangeBrand),
                        modifier = Modifier.fillMaxWidth().testTag("save_profile_button")
                    ) {
                        Text(SjsStrings.t(lang, "Hifadhi Wasifu", "Save Profile"))
                    }
                }
            }
        }

        // 3. Payment History & Digital Receipts
        item {
            Text(
                text = SjsStrings.t(lang, "Historia ya Malipo (${payments.size})", "Payment History & Receipts (${payments.size})"),
                style = MaterialTheme.typography.titleMedium,
                color = NavyDeep
            )
        }

        if (payments.isEmpty()) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = PureWhite), modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = SjsStrings.t(lang, "Hakuna miamala ya malipo bado.", "No payment history yet."),
                        style = MaterialTheme.typography.bodySmall,
                        color = SlateGrey,
                        modifier = Modifier.padding(14.dp)
                    )
                }
            }
        } else {
            items(payments, key = { it.id }) { tx ->
                Card(colors = CardDefaults.cardColors(containerColor = PureWhite), shape = RoundedCornerShape(14.dp)) {
                    Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("${tx.receiptNumber} • ${TzsFormatter.format(tx.amountTzs)}", style = MaterialTheme.typography.titleSmall, color = NavyDeep)
                            Text("${tx.status} (${tx.mode}) -> ${tx.recipientNumber}", style = MaterialTheme.typography.bodySmall, color = SlateGrey)
                        }
                        TextButton(onClick = { receiptToView = tx }) {
                            Text(SjsStrings.t(lang, "Risiti", "Receipt"))
                        }
                    }
                }
            }
        }

        // 4. Customer Complaints
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = SjsStrings.t(lang, "Malalamiko Yangu (${complaints.size})", "My Complaints (${complaints.size})"),
                    style = MaterialTheme.typography.titleMedium,
                    color = NavyDeep
                )
                Button(
                    onClick = { showComplaintDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = NavyDeep),
                    modifier = Modifier.testTag("open_complaint_dialog_button")
                ) {
                    Text(SjsStrings.t(lang, "Wasilisha", "New Complaint"))
                }
            }
        }

        items(complaints, key = { it.id }) { cmp ->
            Card(colors = CardDefaults.cardColors(containerColor = PureWhite), shape = RoundedCornerShape(14.dp)) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(cmp.subject, style = MaterialTheme.typography.titleSmall, color = NavyDeep)
                        Text(cmp.status, style = MaterialTheme.typography.labelMedium, color = OrangeBrand)
                    }
                    Text(cmp.description, style = MaterialTheme.typography.bodySmall, color = CharcoalGrey)
                    if (!cmp.adminNotes.isNullOrBlank()) {
                        Text("Admin: ${cmp.adminNotes}", style = MaterialTheme.typography.labelSmall, color = VerifiedGreen)
                    }
                }
            }
        }

        // 5. Sign Out
        item {
            OutlinedButton(
                onClick = onSignOut,
                colors = ButtonDefaults.outlinedButtonColors(contentColor = ErrorRed),
                modifier = Modifier.fillMaxWidth().height(50.dp).testTag("sign_out_button")
            ) {
                Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text(SjsStrings.t(lang, "Toka (Sign Out)", "Sign Out"))
            }
        }
    }

    if (showComplaintDialog) {
        var subject by remember { mutableStateOf("") }
        var desc by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showComplaintDialog = false },
            title = { Text(SjsStrings.t(lang, "Wasilisha Lalamiko / Msaada", "Submit Complaint")) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(value = subject, onValueChange = { subject = it }, label = { Text(SjsStrings.t(lang, "Kichwa (min 3 chars)", "Subject")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = desc, onValueChange = { desc = it }, label = { Text(SjsStrings.t(lang, "Maelezo (min 10 chars)", "Details")) }, minLines = 3, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onSubmitComplaint(subject, desc)
                        showComplaintDialog = false
                    },
                    enabled = !isBusy && subject.trim().length >= 3 && desc.trim().length >= 10,
                    colors = ButtonDefaults.buttonColors(containerColor = OrangeBrand)
                ) {
                    Text(SjsStrings.t(lang, "Tuma", "Submit"))
                }
            },
            dismissButton = { TextButton(onClick = { showComplaintDialog = false }) { Text(SjsStrings.t(lang, "Ghairi", "Cancel")) } }
        )
    }

    receiptToView?.let { tx ->
        DigitalReceiptDialog(payment = tx, lang = lang, onDismiss = { receiptToView = null })
    }
}
