package com.example.ui

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.net.Uri
import android.util.Log
import android.view.ViewGroup
import android.webkit.ConsoleMessage
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Logout
import androidx.compose.material.icons.rounded.AccessibilityNew
import androidx.compose.material.icons.rounded.AccountCircle
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.Fullscreen
import androidx.compose.material.icons.rounded.FullscreenExit
import androidx.compose.material.icons.rounded.PersonOutline
import androidx.compose.material.icons.rounded.Wallpaper
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.R
import com.example.bridge.IchimatsuWebBridge
import com.example.data.CompanionRepository
import com.example.data.StageBackground
import kotlinx.coroutines.launch
import java.io.ByteArrayInputStream
import java.nio.charset.StandardCharsets

private const val TAG = "IchimatsuScreen"
private const val ASSET_HOST = "appassets.androidplatform.net"
private const val CHARACTER_HTML_URL =
    "https://$ASSET_HOST/assets/Ichimatsu___3D_AI_Character_8e94a799.html"

private const val STAGE_TRANSPARENT_CSS =
    "<style>html,body,#wrap{background:transparent !important;}#bubble{backdrop-filter:blur(10px);}</style>"

private const val API_EXPOSURE_SNIPPET = """
window.__suppressDressSync = false;
window.__ichimatsuApi = {
  play: play,
  setCustom: setCustom,
  setFace: setFace,
  setDress: function(hex, silent){
    window.__suppressDressSync = !!silent;
    try{ setDress(hex); }finally{ window.__suppressDressSync = false; }
  },
  aiDress: aiDress,
  setMode: setMode,
  setJpMode: function(v){
    jpMode = !!v;
    jpBtn.classList.toggle("on", jpMode);
    jpBtn.textContent = jpMode ? "日本語" : "EN";
  },
  registerLearned: registerLearned,
  ask: ask,
  stop: function(){ queue = []; next(); },
  getMoves: function(){ return Object.keys(MOVES); },
  getLearned: function(){ return Object.assign({}, learned); },
  setAuto: function(v){ autoOn = !!v; }
};
var _origNext = next;
next = function(){
  _origNext();
  try{ window.AndroidBridge && window.AndroidBridge.onStageUpdate(curMove, JSON.stringify(Object.keys(learned))); }catch(e){}
};
var _origSetDress = setDress;
setDress = function(hex){
  _origSetDress(hex);
  if (!window.__suppressDressSync) {
    try{ window.AndroidBridge && window.AndroidBridge.onDressChanged(String(hex || "orig")); }catch(e){}
  }
};
var _origJpClick = jpBtn.onclick;
jpBtn.onclick = function(){
  if (_origJpClick) _origJpClick();
  try{ window.AndroidBridge && window.AndroidBridge.onJpModeChanged(!!jpMode); }catch(e){}
};
var _origLearn = learnFromTag;
learnFromTag = function(v){
  var prevKeys = new Set(Object.keys(learned));
  _origLearn(v);
  try{
    for (var k of Object.keys(learned)) {
      if (!prevKeys.has(k) || String(v).toLowerCase().indexOf(k) >= 0) {
        window.AndroidBridge && window.AndroidBridge.onMoveLearned(k, JSON.stringify(learned[k]));
      }
    }
    window.AndroidBridge && window.AndroidBridge.onStageUpdate(curMove, JSON.stringify(Object.keys(learned)));
  }catch(e){}
};
"""

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IchimatsuScreen(
    currentUserId: String,
    displayName: String,
    email: String?,
    isGuest: Boolean = false,
    onSignOut: () -> Unit
) {
    val context = LocalContext.current
    val factory = remember(currentUserId, displayName, isGuest, context) {
        val appContext = context.applicationContext
        object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                return IchimatsuViewModel(
                    currentUserId = currentUserId,
                    displayName = displayName,
                    companionRepository = if (isGuest) null else CompanionRepository(appContext),
                    isGuest = isGuest
                ) as T
            }
        }
    }
    val viewModel: IchimatsuViewModel = viewModel(
        key = currentUserId,
        factory = factory
    )

    val aiState by viewModel.uiState.collectAsStateWithLifecycle()
    val stageState by viewModel.stageState.collectAsStateWithLifecycle()
    val isDark = isSystemInDarkTheme()
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    var pendingFileCallback by remember { mutableStateOf<ValueCallback<Array<Uri>>?>(null) }
    var pendingPermissionRequest by remember { mutableStateOf<PermissionRequest?>(null) }
    var pendingMicCallback by remember { mutableStateOf<((Boolean) -> Unit)?>(null) }
    var showAccountMenu by remember { mutableStateOf(false) }

    val micDeniedMsg = stringResource(R.string.error_mic_denied)
    val camDeniedMsg = stringResource(R.string.error_cam_denied)

    val audioPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        pendingFileCallback?.onReceiveValue(if (uri != null) arrayOf(uri) else null)
        pendingFileCallback = null
    }

    val singlePermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        val micCb = pendingMicCallback
        if (micCb != null) {
            pendingMicCallback = null
            micCb(granted)
            if (!granted) {
                scope.launch { snackbarHostState.showSnackbar(micDeniedMsg) }
            }
            return@rememberLauncherForActivityResult
        }

        val webPerm = pendingPermissionRequest
        if (webPerm != null) {
            pendingPermissionRequest = null
            if (granted) {
                webPerm.grant(webPerm.resources)
            } else {
                webPerm.deny()
                scope.launch { snackbarHostState.showSnackbar(camDeniedMsg) }
            }
        }
    }

    val multiPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val webPerm = pendingPermissionRequest ?: return@rememberLauncherForActivityResult
        pendingPermissionRequest = null
        val grantedResources = mutableListOf<String>()
        if (PermissionRequest.RESOURCE_VIDEO_CAPTURE in webPerm.resources &&
            results[Manifest.permission.CAMERA] == true
        ) {
            grantedResources.add(PermissionRequest.RESOURCE_VIDEO_CAPTURE)
        }
        if (PermissionRequest.RESOURCE_AUDIO_CAPTURE in webPerm.resources &&
            results[Manifest.permission.RECORD_AUDIO] == true
        ) {
            grantedResources.add(PermissionRequest.RESOURCE_AUDIO_CAPTURE)
        }
        if (grantedResources.isNotEmpty()) {
            webPerm.grant(grantedResources.toTypedArray())
        } else {
            webPerm.deny()
        }
    }

    val bridge = remember(context, viewModel) {
        IchimatsuWebBridge(
            context = context,
            viewModel = viewModel,
            evalJs = { script ->
                webViewRef?.post { webViewRef?.evaluateJavascript(script, null) }
            },
            requestMicPermission = { callback ->
                pendingMicCallback = callback
                singlePermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            }
        )
    }

    DisposableEffect(bridge) {
        onDispose {
            bridge.release()
            webViewRef?.destroy()
            webViewRef = null
        }
    }

    LaunchedEffect(viewModel, webViewRef) {
        viewModel.jsCommands.collect { script ->
            webViewRef?.post { webViewRef?.evaluateJavascript(script, null) }
        }
    }

    LaunchedEffect(isDark, webViewRef) {
        val themeValue = if (isDark) "dark" else "light"
        webViewRef?.post {
            webViewRef?.evaluateJavascript(
                "document.documentElement.setAttribute('data-theme', '$themeValue');",
                null
            )
        }
    }

    BackHandler(enabled = stageState.isMoveStudioOpen || stageState.isFullscreen) {
        when {
            stageState.isMoveStudioOpen -> viewModel.closeMoveStudio()
            stageState.isFullscreen -> viewModel.setFullscreen(false)
        }
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .imePadding(),
        contentWindowInsets = WindowInsets.safeDrawing,
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        topBar = {
            if (!stageState.isFullscreen) {
                TopAppBar(
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.94f)
                    ),
                    title = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = MaterialTheme.colorScheme.primaryContainer,
                                modifier = Modifier.size(34.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Rounded.AutoAwesome,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                            Column {
                                Text(
                                    text = stringResource(R.string.app_name),
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                AiStatusLabel(aiState = aiState, currentMove = stageState.currentMove)
                            }
                        }
                    },
                    actions = {
                        IconButton(
                            onClick = { viewModel.openMoveStudio(initialTab = 2) },
                            modifier = Modifier.testTag("change_background_button")
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Wallpaper,
                                contentDescription = stringResource(R.string.cd_change_background)
                            )
                        }
                        IconButton(
                            onClick = { viewModel.openMoveStudio(initialTab = 0) },
                            modifier = Modifier.testTag("open_move_studio_button")
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.AccessibilityNew,
                                contentDescription = stringResource(R.string.cd_move_studio)
                            )
                        }
                        IconButton(
                            onClick = { viewModel.setFullscreen(true) },
                            modifier = Modifier.testTag("toggle_fullscreen_button")
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Fullscreen,
                                contentDescription = stringResource(R.string.cd_toggle_fullscreen)
                            )
                        }
                        Box {
                            IconButton(
                                onClick = { showAccountMenu = true },
                                modifier = Modifier.testTag("account_menu_button")
                            ) {
                                Icon(
                                    imageVector = if (isGuest) Icons.Rounded.PersonOutline else Icons.Rounded.AccountCircle,
                                    contentDescription = stringResource(R.string.cd_account_menu)
                                )
                            }
                            DropdownMenu(
                                expanded = showAccountMenu,
                                onDismissRequest = { showAccountMenu = false }
                            ) {
                                Column(
                                    modifier = Modifier
                                        .widthIn(max = 240.dp)
                                        .padding(horizontal = 16.dp, vertical = 10.dp)
                                ) {
                                    Text(
                                        text = if (isGuest) stringResource(R.string.guest_mode_label) else displayName,
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.SemiBold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    if (isGuest) {
                                        Text(
                                            text = stringResource(R.string.guest_mode_note),
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    } else if (!email.isNullOrBlank()) {
                                        Text(
                                            text = email,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                                HorizontalDivider()
                                if (isGuest) {
                                    DropdownMenuItem(
                                        text = { Text(stringResource(R.string.action_switch_to_google)) },
                                        leadingIcon = {
                                            Icon(
                                                imageVector = Icons.Rounded.AccountCircle,
                                                contentDescription = null
                                            )
                                        },
                                        onClick = {
                                            showAccountMenu = false
                                            onSignOut()
                                        },
                                        modifier = Modifier.testTag("guest_sign_in_button")
                                    )
                                } else {
                                    DropdownMenuItem(
                                        text = { Text(stringResource(R.string.action_sign_out)) },
                                        leadingIcon = {
                                            Icon(
                                                imageVector = Icons.AutoMirrored.Rounded.Logout,
                                                contentDescription = null
                                            )
                                        },
                                        onClick = {
                                            showAccountMenu = false
                                            onSignOut()
                                        },
                                        modifier = Modifier.testTag("sign_out_button")
                                    )
                                }
                            }
                        }
                    }
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            StageBackdrop(
                background = stageState.background,
                modifier = Modifier.fillMaxSize()
            )

            AndroidView(
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("ichimatsu_3d_webview"),
                factory = { ctx ->
                    createIchimatsuWebView(
                        context = ctx,
                        bridge = bridge,
                        isDark = isDark,
                        onOpenAudioPicker = { callback ->
                            pendingFileCallback?.onReceiveValue(null)
                            pendingFileCallback = callback
                            audioPickerLauncher.launch(arrayOf("audio/*"))
                        },
                        onWebPermissionRequest = { request ->
                            val needed = mutableListOf<String>()
                            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE in request.resources &&
                                ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED
                            ) {
                                needed.add(Manifest.permission.CAMERA)
                            }
                            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE in request.resources &&
                                ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED
                            ) {
                                needed.add(Manifest.permission.RECORD_AUDIO)
                            }
                            if (needed.isEmpty()) {
                                request.grant(request.resources)
                            } else if (needed.size == 1) {
                                pendingPermissionRequest = request
                                singlePermissionLauncher.launch(needed.first())
                            } else {
                                pendingPermissionRequest = request
                                multiPermissionLauncher.launch(needed.toTypedArray())
                            }
                        }
                    ).also { wv ->
                        webViewRef = wv
                        wv.loadUrl(CHARACTER_HTML_URL)
                    }
                }
            )

            AnimatedVisibility(
                visible = aiState is UiState.Error,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                val errorText = (aiState as? UiState.Error)?.message.orEmpty()
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.errorContainer,
                    tonalElevation = 4.dp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("error_banner")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.ErrorOutline,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onErrorContainer
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = errorText,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            modifier = Modifier.weight(1f),
                            maxLines = 3,
                            overflow = TextOverflow.Ellipsis
                        )
                        if (stageState.lastFailedPrompt != null) {
                            TextButton(
                                onClick = { viewModel.retryLastPrompt() },
                                modifier = Modifier.testTag("retry_button")
                            ) {
                                Text(stringResource(R.string.action_retry))
                            }
                        }
                        IconButton(
                            onClick = { viewModel.dismissError() },
                            modifier = Modifier.testTag("dismiss_error_button")
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Close,
                                contentDescription = stringResource(R.string.cd_dismiss_error),
                                tint = MaterialTheme.colorScheme.onErrorContainer
                            )
                        }
                    }
                }
            }

            if (stageState.isFullscreen) {
                Surface(
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.85f),
                    tonalElevation = 3.dp,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(top = 12.dp, end = 12.dp)
                ) {
                    IconButton(
                        onClick = { viewModel.setFullscreen(false) },
                        modifier = Modifier.testTag("exit_fullscreen_button")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.FullscreenExit,
                            contentDescription = stringResource(R.string.cd_exit_fullscreen)
                        )
                    }
                }
            }
        }
    }

    if (stageState.isMoveStudioOpen) {
        MoveStudioSheet(
            stageState = stageState,
            onDismiss = { viewModel.closeMoveStudio() },
            onPlayMoves = { moves -> viewModel.playMoves(moves) },
            onApplyPose = { spec, mood -> viewModel.applyCustomPose(spec, mood) },
            onStopMotion = { viewModel.stopMotion() },
            onSelectBackground = { bg -> viewModel.selectBackground(bg) },
            onSelectDress = { color -> viewModel.setDressColor(color) },
            onAskAi = { prompt -> viewModel.askCharacter(prompt) }
        )
    }
}

@Composable
private fun StageBackdrop(
    background: StageBackground,
    modifier: Modifier = Modifier
) {
    Crossfade(
        targetState = background,
        label = "stage_backdrop",
        modifier = modifier.testTag("stage_backdrop_${background.id}")
    ) { bg ->
        when (bg) {
            StageBackground.SAKURA_SHRINE -> {
                Box(modifier = Modifier.fillMaxSize()) {
                    Image(
                        painter = painterResource(id = R.drawable.img_bg_sakura_shrine_1795001136789),
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(
                                        Color.Black.copy(alpha = 0.14f),
                                        Color.Transparent,
                                        Color.Black.copy(alpha = 0.24f)
                                    )
                                )
                            )
                    )
                }
            }
            StageBackground.STARLIGHT_STUDIO -> {
                Box(modifier = Modifier.fillMaxSize()) {
                    Image(
                        painter = painterResource(id = R.drawable.img_bg_starlight_studio_1795001137053),
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(
                                        Color.Black.copy(alpha = 0.16f),
                                        Color.Transparent,
                                        Color.Black.copy(alpha = 0.28f)
                                    )
                                )
                            )
                    )
                }
            }
            StageBackground.LAVENDER_GLOW -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.radialGradient(
                                colors = listOf(
                                    MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.72f),
                                    MaterialTheme.colorScheme.background
                                )
                            )
                        )
                )
            }
        }
    }
}

@Composable
private fun AiStatusLabel(aiState: UiState, currentMove: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        when (aiState) {
            is UiState.Loading -> {
                CircularProgressIndicator(
                    modifier = Modifier.size(10.dp),
                    strokeWidth = 1.5.dp
                )
                Spacer(Modifier.width(6.dp))
                Text(
                    text = stringResource(R.string.status_thinking),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            is UiState.Streaming -> {
                CircularProgressIndicator(
                    modifier = Modifier.size(10.dp),
                    strokeWidth = 1.5.dp
                )
                Spacer(Modifier.width(6.dp))
                Text(
                    text = stringResource(R.string.status_streaming),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            is UiState.Error -> {
                Text(
                    text = stringResource(R.string.status_error),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.error
                )
            }
            else -> {
                Text(
                    text = "${stringResource(R.string.status_ready)} · $currentMove",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
private fun createIchimatsuWebView(
    context: android.content.Context,
    bridge: IchimatsuWebBridge,
    isDark: Boolean,
    onOpenAudioPicker: (ValueCallback<Array<Uri>>) -> Unit,
    onWebPermissionRequest: (PermissionRequest) -> Unit
): WebView {
    return WebView(context).apply {
        layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
        setBackgroundColor(android.graphics.Color.TRANSPARENT)

        settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = false
            allowContentAccess = true
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            useWideViewPort = true
            loadWithOverviewMode = true
        }

        addJavascriptInterface(bridge, "AndroidBridge")

        webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView?,
                request: WebResourceRequest?
            ): WebResourceResponse? {
                val url = request?.url ?: return null
                if (url.host != ASSET_HOST) return null
                val path = url.path?.removePrefix("/assets/") ?: return null

                return try {
                    when (path) {
                        "Ichimatsu___3D_AI_Character_8e94a799.html" -> {
                            val rawHtml = context.assets.open(path)
                                .bufferedReader(StandardCharsets.UTF_8)
                                .use { it.readText() }
                            val patchedHtml = patchHtmlForAndroid(rawHtml, isDark)
                            WebResourceResponse(
                                "text/html",
                                "utf-8",
                                ByteArrayInputStream(patchedHtml.toByteArray(StandardCharsets.UTF_8))
                            )
                        }
                        "ichimatsu_bridge.js" -> {
                            val stream = context.assets.open(path)
                            WebResourceResponse("application/javascript", "utf-8", stream)
                        }
                        else -> {
                            val mime = when {
                                path.endsWith(".js") -> "application/javascript"
                                path.endsWith(".css") -> "text/css"
                                path.endsWith(".html") -> "text/html"
                                else -> "application/octet-stream"
                            }
                            WebResourceResponse(mime, "utf-8", context.assets.open(path))
                        }
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Failed to serve asset $path", e)
                    null
                }
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                val themeValue = if (isDark) "dark" else "light"
                view?.evaluateJavascript(
                    "document.documentElement.setAttribute('data-theme', '$themeValue');",
                    null
                )
            }
        }

        webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest?) {
                if (request == null) return
                onWebPermissionRequest(request)
            }

            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                if (filePathCallback == null) return false
                onOpenAudioPicker(filePathCallback)
                return true
            }

            override fun onConsoleMessage(consoleMessage: ConsoleMessage?): Boolean {
                if (consoleMessage?.messageLevel() == ConsoleMessage.MessageLevel.ERROR) {
                    Log.e(TAG, "WebView JS error: ${consoleMessage.message()} (${consoleMessage.lineNumber()})")
                }
                return super.onConsoleMessage(consoleMessage)
            }
        }
    }
}

private fun patchHtmlForAndroid(rawHtml: String, isDark: Boolean): String {
    val themeAttr = if (isDark) "dark" else "light"
    val bridgeHeadTag =
        """$STAGE_TRANSPARENT_CSS<script src="https://$ASSET_HOST/assets/ichimatsu_bridge.js"></script></head>"""
    var result = rawHtml.replaceFirst("<html lang=\"en\">", "<html lang=\"en\" data-theme=\"$themeAttr\">")
    result = result.replaceFirst("</head>", bridgeHeadTag)

    result = result.replaceFirst(
        "msg.remove();",
        "msg.remove(); try{ window.AndroidBridge && window.AndroidBridge.onModelLoaded(); }catch(e){}"
    )

    val anchor = "document.querySelectorAll(\".chips button\")"
    if (result.contains(anchor)) {
        result = result.replaceFirst(anchor, "$API_EXPOSURE_SNIPPET\n$anchor")
    }
    return result
}
