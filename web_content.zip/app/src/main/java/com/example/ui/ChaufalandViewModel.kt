package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.AdminConfig
import com.example.data.model.BedrockPlayer
import com.example.data.model.ServerStatusData
import com.example.data.model.VoiceChannel
import com.example.data.model.VoiceUser
import com.example.data.repository.ChaufalandRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

enum class AppTab(val title: String, val icon: String) {
  SERVER("Servidor", "🖥️"),
  VOICE("Voz", "🎙️"),
  RADAR("Radar", "🧭"),
  GUIDE("Guía Addon", "📜"),
  ADMIN("Admin", "🛡️")
}

data class UiNotification(
  val message: String,
  val isError: Boolean = false
)

class ChaufalandViewModel(application: Application) : AndroidViewModel(application) {

  private val repository = ChaufalandRepository(application)

  private val _gamerTag = MutableStateFlow(repository.getGamerTag())
  val gamerTag: StateFlow<String> = _gamerTag.asStateFlow()

  private val _showGamerTagDialog = MutableStateFlow(_gamerTag.value.isBlank())
  val showGamerTagDialog: StateFlow<Boolean> = _showGamerTagDialog.asStateFlow()

  private val _currentTab = MutableStateFlow(AppTab.SERVER)
  val currentTab: StateFlow<AppTab> = _currentTab.asStateFlow()

  private val _serverStatus = MutableStateFlow(ServerStatusData())
  val serverStatus: StateFlow<ServerStatusData> = _serverStatus.asStateFlow()

  private val _isRefreshingServer = MutableStateFlow(false)
  val isRefreshingServer: StateFlow<Boolean> = _isRefreshingServer.asStateFlow()

  private val _adminConfig = MutableStateFlow(repository.getAdminConfig())
  val adminConfig: StateFlow<AdminConfig> = _adminConfig.asStateFlow()

  private val _isAdminUnlocked = MutableStateFlow(false)
  val isAdminUnlocked: StateFlow<Boolean> = _isAdminUnlocked.asStateFlow()

  private val _adminPasswordInput = MutableStateFlow("")
  val adminPasswordInput: StateFlow<String> = _adminPasswordInput.asStateFlow()

  private val _consoleLogs = MutableStateFlow<List<String>>(
    listOf(
      "[CHAUFALAND] Sistema de control inicializado.",
      "[CHAUFALAND] Conectando a endpoints de Minecraft..."
    )
  )
  val consoleLogs: StateFlow<List<String>> = _consoleLogs.asStateFlow()

  // CANALES DE VOZ
  val voiceChannels = listOf(
    VoiceChannel("spawn", "General / Spawn", "🌲"),
    VoiceChannel("afk", "AFK / Ausente", "☕"),
    VoiceChannel("caves", "Cueva & Minería", "⛏️"),
    VoiceChannel("base", "Base Principal", "🏰"),
    VoiceChannel("nether", "Expedición Nether", "🔥")
  )

  private val _currentVoiceChannel = MutableStateFlow<VoiceChannel?>(null)
  val currentVoiceChannel: StateFlow<VoiceChannel?> = _currentVoiceChannel.asStateFlow()

  private val _isMuted = MutableStateFlow(false)
  val isMuted: StateFlow<Boolean> = _isMuted.asStateFlow()

  private val _isSpeaking = MutableStateFlow(false)
  val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

  private val _voiceUsers = MutableStateFlow<List<VoiceUser>>(emptyList())
  val voiceUsers: StateFlow<List<VoiceUser>> = _voiceUsers.asStateFlow()

  // TELEMETRÍA BEDROCK
  private val _bedrockPlayers = MutableStateFlow<List<BedrockPlayer>>(emptyList())
  val bedrockPlayers: StateFlow<List<BedrockPlayer>> = _bedrockPlayers.asStateFlow()

  private val _notification = MutableStateFlow<UiNotification?>(null)
  val notification: StateFlow<UiNotification?> = _notification.asStateFlow()

  private var serverPollingJob: Job? = null
  private var speakingSimJob: Job? = null

  init {
    startServerPolling()
  }

  fun setTab(tab: AppTab) {
    _currentTab.value = tab
  }

  fun saveGamerTag(tag: String) {
    if (tag.isBlank()) {
      showNotice("El GamerTag no puede estar vacío", isError = true)
      return
    }
    repository.saveGamerTag(tag)
    _gamerTag.value = tag
    _showGamerTagDialog.value = false
    showNotice("¡Bienvenido a CHAUFALAND, $tag!")
  }

  fun openGamerTagDialog() {
    _showGamerTagDialog.value = true
  }

  fun closeGamerTagDialog() {
    if (_gamerTag.value.isNotBlank()) {
      _showGamerTagDialog.value = false
    }
  }

  fun setAdminPasswordInput(pw: String) {
    _adminPasswordInput.value = pw
  }

  fun submitAdminLogin() {
    if (_adminPasswordInput.value == "JuancitoChen23") {
      _isAdminUnlocked.value = true
      _adminPasswordInput.value = ""
      showNotice("Panel de Administrador desbloqueado")
    } else {
      showNotice("Contraseña de administrador incorrecta", isError = true)
    }
  }

  fun lockAdmin() {
    _isAdminUnlocked.value = false
  }

  fun updateAdminConfig(newConfig: AdminConfig) {
    repository.saveAdminConfig(newConfig)
    _adminConfig.value = newConfig
    showNotice("Configuración del servidor guardada")
    refreshServerStatus()
  }

  fun refreshServerStatus() {
    viewModelScope.launch {
      _isRefreshingServer.value = true
      val cfg = _adminConfig.value
      if (cfg.serverType == "exaroton" && cfg.exarotonToken.isNotBlank() && cfg.exarotonServerId.isNotBlank()) {
        val result = repository.fetchExarotonServerStatus(cfg.exarotonToken, cfg.exarotonServerId)
        result.onSuccess { data ->
          _serverStatus.value = data
        }.onFailure { err ->
          addConsoleLog("[ERROR EXAROTON] ${err.localizedMessage}")
        }
      } else {
        // Aternos o fallback con mcsrvstat.us
        val result = repository.fetchMcsrvstatStatus(cfg.secondaryServerIp, cfg.isSecondaryBedrock)
        result.onSuccess { data ->
          _serverStatus.value = data
        }.onFailure { err ->
          addConsoleLog("[ERROR SERVIDOR] ${err.localizedMessage}")
        }
      }

      // Consultar telemetría de jugadores del bridge
      val bridgeResult = repository.fetchBedrockBridgePlayers(cfg.wsBridgeUrl)
      bridgeResult.onSuccess { players ->
        if (players.isNotEmpty()) {
          _bedrockPlayers.value = players
        }
      }

      _isRefreshingServer.value = false
    }
  }

  private fun startServerPolling() {
    serverPollingJob?.cancel()
    serverPollingJob = viewModelScope.launch {
      while (isActive) {
        refreshServerStatus()
        delay(15000)
      }
    }
  }

  fun executeExarotonAction(action: String) {
    viewModelScope.launch {
      val cfg = _adminConfig.value
      if (cfg.exarotonToken.isBlank() || cfg.exarotonServerId.isBlank()) {
        showNotice("Debes configurar el Token y Server ID de Exaroton en Admin", isError = true)
        return@launch
      }

      addConsoleLog("[ACCIÓN] Enviando orden '$action' al servidor...")
      val result = repository.executeExarotonAction(cfg.exarotonToken, cfg.exarotonServerId, action)
      result.onSuccess { msg ->
        showNotice(msg)
        addConsoleLog("[RESPUESTA] $msg")
        delay(2000)
        refreshServerStatus()
      }.onFailure { err ->
        showNotice(err.localizedMessage ?: "Error ejecutando acción", isError = true)
        addConsoleLog("[ERROR] ${err.localizedMessage}")
      }
    }
  }

  fun sendConsoleCommand(cmd: String) {
    if (cmd.isBlank()) return
    val clean = cmd.trim()
    viewModelScope.launch {
      val cfg = _adminConfig.value
      addConsoleLog("> $clean")
      if (cfg.serverType == "exaroton" && cfg.exarotonToken.isNotBlank()) {
        val res = repository.sendExarotonCommand(cfg.exarotonToken, cfg.exarotonServerId, clean)
        res.onSuccess {
          addConsoleLog("[OK] Comando enviado a la consola de Exaroton")
        }.onFailure { err ->
          addConsoleLog("[ERROR] ${err.localizedMessage}")
        }
      } else {
        addConsoleLog("[INFO] Comando registrado. Para ejecución remota configura Exaroton Token en Admin.")
      }
    }
  }

  private fun addConsoleLog(line: String) {
    val current = _consoleLogs.value.toMutableList()
    current.add(line)
    if (current.size > 80) current.removeAt(0)
    _consoleLogs.value = current
  }

  fun clearConsoleLogs() {
    _consoleLogs.value = listOf("[CHAUFALAND] Consola limpiada.")
  }

  // VOZ
  fun joinVoiceChannel(channel: VoiceChannel) {
    val myTag = _gamerTag.value
    if (myTag.isBlank()) {
      _showGamerTagDialog.value = true
      return
    }

    _currentVoiceChannel.value = channel
    showNotice("Conectado a la voz en '${channel.name}'")

    // Actualizar lista de participantes del canal
    val currentUsers = _voiceUsers.value.filter { it.gamerTag != myTag }.toMutableList()
    currentUsers.add(
      VoiceUser(
        gamerTag = myTag,
        channelId = channel.id,
        isMuted = _isMuted.value,
        isSpeaking = _isSpeaking.value
      )
    )
    _voiceUsers.value = currentUsers

    startSpeakingIndicatorLoop()
  }

  fun leaveVoiceChannel() {
    val myTag = _gamerTag.value
    _currentVoiceChannel.value = null
    _voiceUsers.value = _voiceUsers.value.filter { it.gamerTag != myTag }
    speakingSimJob?.cancel()
    _isSpeaking.value = false
    showNotice("Desconectado de la llamada de voz")
  }

  fun toggleMute() {
    val newMute = !_isMuted.value
    _isMuted.value = newMute
    if (newMute) {
      _isSpeaking.value = false
    }

    val myTag = _gamerTag.value
    _voiceUsers.value = _voiceUsers.value.map {
      if (it.gamerTag == myTag) it.copy(isMuted = newMute, isSpeaking = if (newMute) false else it.isSpeaking)
      else it
    }

    showNotice(if (newMute) "Micrófono muteado 🔇" else "Micrófono activo 🎙️")
  }

  private fun startSpeakingIndicatorLoop() {
    speakingSimJob?.cancel()
    speakingSimJob = viewModelScope.launch {
      while (isActive) {
        if (!_isMuted.value && _currentVoiceChannel.value != null) {
          // Si el micro está abierto, emite actividad de voz dinámica
          _isSpeaking.value = !_isSpeaking.value
          val myTag = _gamerTag.value
          _voiceUsers.value = _voiceUsers.value.map {
            if (it.gamerTag == myTag) it.copy(isSpeaking = _isSpeaking.value) else it
          }
        } else {
          _isSpeaking.value = false
        }
        delay(1200)
      }
    }
  }

  private fun showNotice(msg: String, isError: Boolean = false) {
    _notification.value = UiNotification(msg, isError)
  }

  fun dismissNotice() {
    _notification.value = null
  }
}
