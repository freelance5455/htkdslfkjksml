package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.SandboxSpec
import com.example.data.model.SandboxWidget
import com.example.data.model.StudioProject
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.util.ArchiveExportSummary
import com.example.util.CodeComplianceAuditor
import com.example.util.ProjectArchiveExporter
import com.example.util.SandboxScenarioSnapshot
import java.util.Locale
import kotlin.math.pow
import kotlin.math.roundToInt

private enum class SandboxViewMode(val label: String) {
    INTERACTIVE_PREVIEW("Live UI Sandbox"),
    SOURCE_CODE("Source & Audit"),
    EXPORT_ARCHIVE("Export & Share")
}

private enum class SourceFileTab(val fileName: String) {
    MAIN_ACTIVITY("MainActivity.kt"),
    MANIFEST("AndroidManifest.xml"),
    BUILD_GRADLE("app/build.gradle.kts"),
    SANDBOX_JSON("sandbox-spec.json")
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun LiveSandboxExportScreen(
    activeProject: StudioProject?,
    isRefiningProject: Boolean,
    includeFullGradleScaffold: Boolean,
    scenarioSnapshots: List<SandboxScenarioSnapshot>,
    exportBanner: ArchiveExportSummary?,
    onDismissExportBanner: () -> Unit,
    onRefineProject: (String) -> Unit,
    onAddCustomWidget: (SandboxWidget, String, String, String) -> Unit,
    onSaveEditedSource: (String, String, String, String) -> Unit,
    onCaptureSnapshot: (String, String, String, Map<String, Float>, Map<String, Boolean>, Map<String, String>) -> Unit,
    onDeleteSnapshot: (String) -> Unit,
    onExportToUri: (StudioProject, android.net.Uri) -> Unit,
    onExportToWorkspace: (StudioProject) -> Unit,
    onNavigateBackToStudio: () -> Unit
) {
    BackHandler {
        onNavigateBackToStudio()
    }

    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    var viewMode by remember { mutableStateOf(SandboxViewMode.INTERACTIVE_PREVIEW) }
    var selectedSourceTab by remember { mutableStateOf(SourceFileTab.MAIN_ACTIVITY) }
    var isEditingSource by remember { mutableStateOf(false) }
    var copiedNotice by remember { mutableStateOf<String?>(null) }

    val createZipLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/zip")
    ) { uri ->
        if (uri != null && activeProject != null) {
            onExportToUri(activeProject, uri)
        }
    }

    if (activeProject == null) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            contentAlignment = Alignment.Center
        ) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("empty_sandbox_card"),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                shape = RoundedCornerShape(18.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Widgets,
                        contentDescription = "Empty Sandbox",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(40.dp)
                    )
                    Text(
                        text = "Live Sandbox & Export Hub",
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = stringResource(R.string.empty_sandbox_message),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Button(
                        onClick = onNavigateBackToStudio,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("return_to_studio_button"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Go to Prompt Studio")
                    }
                }
            }
        }
        return
    }

    val sandboxSpec = remember(activeProject.id, activeProject.sandboxSpecJson) {
        SandboxSpec.fromJsonString(activeProject.sandboxSpecJson, activeProject.title)
    }

    var editableKotlin by remember(activeProject.id, activeProject.kotlinCode) {
        mutableStateOf(activeProject.kotlinCode)
    }
    var editableManifest by remember(activeProject.id, activeProject.manifestXml) {
        mutableStateOf(activeProject.manifestXml)
    }
    var editableGradle by remember(activeProject.id, activeProject.buildGradleKts) {
        mutableStateOf(activeProject.buildGradleKts)
    }
    var editableSandboxJson by remember(activeProject.id, activeProject.sandboxSpecJson) {
        mutableStateOf(activeProject.sandboxSpecJson)
    }

    val auditReport = remember(
        activeProject.id,
        editableKotlin,
        editableManifest,
        editableGradle,
        editableSandboxJson
    ) {
        CodeComplianceAuditor.auditProject(
            activeProject.copy(
                kotlinCode = editableKotlin,
                manifestXml = editableManifest,
                buildGradleKts = editableGradle,
                sandboxSpecJson = editableSandboxJson
            )
        )
    }

    // Dynamic interactive state map for all widgets inside the Live Sandbox
    val numericValues = remember(activeProject.id) { mutableStateMapOf<String, Float>() }
    val textValues = remember(activeProject.id) { mutableStateMapOf<String, String>() }
    val toggleValues = remember(activeProject.id) { mutableStateMapOf<String, Boolean>() }
    val checklistStates = remember(activeProject.id) { mutableStateMapOf<String, Boolean>() }
    var newChecklistEntry by remember(activeProject.id) { mutableStateOf("") }
    val customChecklistItems = remember(activeProject.id) { mutableStateOf(listOf<String>()) }

    LaunchedEffect(activeProject.id, sandboxSpec) {
        sandboxSpec.widgets.forEach { w ->
            when (w.type.uppercase()) {
                "SLIDER", "NUMBER_INPUT", "METRIC_CARD" -> {
                    if (!numericValues.containsKey(w.id)) {
                        val parsed = w.defaultValue.replace(Regex("[^0-9.-]"), "").toFloatOrNull()
                            ?: ((w.minValue + w.maxValue) / 2f).coerceAtLeast(1f)
                        numericValues[w.id] = parsed
                    }
                }
                "TOGGLE" -> {
                    if (!toggleValues.containsKey(w.id)) {
                        toggleValues[w.id] = w.defaultValue.equals("true", ignoreCase = true)
                    }
                }
                "SEGMENTED", "TEXT_INPUT" -> {
                    if (!textValues.containsKey(w.id)) {
                        textValues[w.id] = w.defaultValue.ifBlank {
                            w.options.firstOrNull().orEmpty()
                        }
                    }
                }
                "CHECKLIST" -> {
                    w.options.forEachIndexed { index, _ ->
                        val k = "${w.id}_$index"
                        if (!checklistStates.containsKey(k)) {
                            checklistStates[k] = index == 0
                        }
                    }
                }
            }
        }
    }

    val computedFormulaOutput = remember(
        numericValues.toMap(),
        toggleValues.toMap(),
        sandboxSpec.formulaMode
    ) {
        val nums = numericValues.values.toList().ifEmpty { listOf(1f) }
        val activeToggleMultiplier = if (toggleValues.values.any { it }) 1.15f else 1.0f
        val raw = when (sandboxSpec.formulaMode.uppercase()) {
            "ADD" -> nums.sum() * activeToggleMultiplier
            "RATIO" -> {
                val first = nums.firstOrNull() ?: 1f
                val second = nums.getOrNull(1)?.takeIf { it != 0f } ?: 1f
                (first / second) * 100f * activeToggleMultiplier
            }
            "COMPOUND" -> {
                val principal = nums.getOrNull(0) ?: 1000f
                val rate = (nums.getOrNull(1) ?: 7f) / 100f
                val years = (nums.getOrNull(2) ?: 5f).coerceIn(1f, 50f)
                (principal * (1f + rate).pow(years)) * activeToggleMultiplier
            }
            "CUSTOM_SCORE" -> {
                (nums.average().toFloat() * 1.25f) * activeToggleMultiplier
            }
            else -> {
                val product = nums.fold(1.0) { acc, v -> acc * v.coerceAtLeast(0.1f) }
                (product / 10.0.pow((nums.size - 1).coerceAtLeast(0))).toFloat() * activeToggleMultiplier
            }
        }
        String.format(Locale.US, "%.2f", raw)
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("live_sandbox_list"),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Project Header & Mode Selector
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            color = MaterialTheme.colorScheme.primaryContainer,
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "${activeProject.provider} • ${activeProject.modelId}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                        Text(
                            text = "LIVE SANDBOX",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    Text(
                        text = activeProject.title,
                        style = MaterialTheme.typography.headlineSmall,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Text(
                        text = activeProject.summary,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.fillMaxWidth()
                    )

                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        SandboxViewMode.entries.forEach { mode ->
                            FilterChip(
                                selected = viewMode == mode,
                                onClick = { viewMode = mode },
                                label = {
                                    Text(
                                        text = mode.label,
                                        style = MaterialTheme.typography.labelLarge
                                    )
                                },
                                leadingIcon = {
                                    Icon(
                                        imageVector = when (mode) {
                                            SandboxViewMode.INTERACTIVE_PREVIEW -> Icons.Default.PlayArrow
                                            SandboxViewMode.SOURCE_CODE -> Icons.Default.Code
                                            SandboxViewMode.EXPORT_ARCHIVE -> Icons.Default.FolderZip
                                        },
                                        contentDescription = mode.label,
                                        modifier = Modifier.size(16.dp)
                                    )
                                },
                                modifier = Modifier.testTag("sandbox_mode_${mode.name.lowercase()}")
                            )
                        }
                    }
                }
            }
        }

        // Export Confirmation Banner
        if (exportBanner != null) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("export_success_banner"),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.tertiaryContainer
                    ),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = "Archive Packaged",
                                    tint = MaterialTheme.colorScheme.tertiary,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Project Archive Packaged (${exportBanner.totalBytes} bytes)",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = MaterialTheme.colorScheme.onTertiaryContainer
                                )
                            }
                            Text(
                                text = "Dismiss",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.tertiary,
                                modifier = Modifier
                                    .clickable { onDismissExportBanner() }
                                    .padding(4.dp)
                            )
                        }
                        Text(
                            text = "Destination: ${exportBanner.destinationDescription}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onTertiaryContainer,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Text(
                            text = "Files included: ${exportBanner.packagedFiles.joinToString(", ")}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onTertiaryContainer,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        }

        when (viewMode) {
            SandboxViewMode.INTERACTIVE_PREVIEW -> {
                // Live Computed Output Card
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(
                                width = 1.dp,
                                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.45f),
                                shape = RoundedCornerShape(16.dp)
                            )
                            .testTag("sandbox_live_output_card"),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
                        ),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "${sandboxSpec.primaryFormulaLabel.uppercase()} (${sandboxSpec.formulaMode})",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.weight(1f)
                                )
                                IconButton(
                                    onClick = {
                                        sandboxSpec.widgets.forEach { w ->
                                            val def = w.defaultValue.replace(Regex("[^0-9.-]"), "").toFloatOrNull()
                                            if (def != null) numericValues[w.id] = def
                                        }
                                    },
                                    modifier = Modifier.testTag("reset_sandbox_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Refresh,
                                        contentDescription = "Reset sandbox values",
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }

                            Text(
                                text = "$computedFormulaOutput ${sandboxSpec.primaryFormulaUnit}",
                                style = MaterialTheme.typography.displaySmall,
                                color = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.fillMaxWidth()
                            )

                            Text(
                                text = sandboxSpec.tagline,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }

                // Render each interactive widget in the SandboxSpec
                items(
                    count = sandboxSpec.widgets.size,
                    key = { index -> sandboxSpec.widgets[index].id + "_$index" }
                ) { index ->
                    val widget = sandboxSpec.widgets[index]
                    InteractiveSandboxWidgetCard(
                        widget = widget,
                        numericValue = numericValues[widget.id] ?: widget.minValue,
                        onNumericChange = { numericValues[widget.id] = it },
                        textValue = textValues[widget.id].orEmpty(),
                        onTextChange = { textValues[widget.id] = it },
                        toggleValue = toggleValues[widget.id] ?: false,
                        onToggleChange = { toggleValues[widget.id] = it },
                        checklistStates = checklistStates,
                        customChecklistItems = customChecklistItems.value,
                        newChecklistEntry = newChecklistEntry,
                        onNewChecklistEntryChange = { newChecklistEntry = it },
                        onAddChecklistItem = {
                            if (newChecklistEntry.isNotBlank()) {
                                customChecklistItems.value = customChecklistItems.value + newChecklistEntry.trim()
                                newChecklistEntry = ""
                            }
                        }
                    )
                }

                // Feature 5: Custom Sandbox Widget & Formula Composer
                item {
                    CustomSandboxWidgetBuilderCard(
                        currentSpec = sandboxSpec,
                        onAddWidgetAndFormula = onAddCustomWidget
                    )
                }

                // Feature 6: Sandbox Scenario Snapshots & Comparison
                item {
                    ScenarioSnapshotsCard(
                        snapshots = scenarioSnapshots,
                        currentResult = computedFormulaOutput,
                        currentUnit = sandboxSpec.primaryFormulaUnit,
                        onCaptureSnapshot = { name ->
                            onCaptureSnapshot(
                                name,
                                computedFormulaOutput,
                                sandboxSpec.primaryFormulaUnit,
                                numericValues.toMap(),
                                toggleValues.toMap(),
                                textValues.toMap()
                            )
                        },
                        onRestoreSnapshot = { snap ->
                            snap.numericSnapshot.forEach { (k, v) -> numericValues[k] = v }
                            snap.toggleSnapshot.forEach { (k, v) -> toggleValues[k] = v }
                            snap.textSnapshot.forEach { (k, v) -> textValues[k] = v }
                        },
                        onDeleteSnapshot = onDeleteSnapshot
                    )
                }

                // Feature 4: Iterative AI Project Refinement
                item {
                    IterativeAiRefinementCard(
                        isRefining = isRefiningProject,
                        onRefineSubmit = onRefineProject
                    )
                }
            }

            SandboxViewMode.SOURCE_CODE -> {
                // Feature 7: Automated Code Quality & Layout Compliance Auditor
                item {
                    CodeComplianceAuditCard(
                        auditReport = auditReport,
                        isRefining = isRefiningProject,
                        onAutoHardenClick = {
                            onRefineProject(
                                "Harden Jetpack Compose code for Material 3 compliance, strict Modifier.fillMaxWidth() viewport safety, accessibility contentDescriptions, and clean state hoisting."
                            )
                        }
                    )
                }

                // Feature 8: Inline Source Code Editor & Wrapped Viewer
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        ),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            FlowRow(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                SourceFileTab.entries.forEach { tab ->
                                    FilterChip(
                                        selected = selectedSourceTab == tab,
                                        onClick = { selectedSourceTab = tab },
                                        label = {
                                            Text(
                                                text = tab.fileName,
                                                style = MaterialTheme.typography.labelMedium
                                            )
                                        },
                                        modifier = Modifier.testTag("source_tab_${tab.name.lowercase()}")
                                    )
                                }
                            }

                            val activeCodeContent = when (selectedSourceTab) {
                                SourceFileTab.MAIN_ACTIVITY -> editableKotlin
                                SourceFileTab.MANIFEST -> editableManifest
                                SourceFileTab.BUILD_GRADLE -> editableGradle
                                SourceFileTab.SANDBOX_JSON -> editableSandboxJson
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = selectedSourceTab.fileName,
                                    style = MaterialTheme.typography.titleSmall,
                                    color = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.weight(1f)
                                )
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedButton(
                                        onClick = { isEditingSource = !isEditingSource },
                                        modifier = Modifier.testTag("toggle_inline_editor_button"),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Edit,
                                            contentDescription = "Toggle Inline Editor",
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = if (isEditingSource) "Preview" else "Edit",
                                            style = MaterialTheme.typography.labelMedium
                                        )
                                    }
                                    OutlinedButton(
                                        onClick = {
                                            clipboardManager.setText(AnnotatedString(activeCodeContent))
                                            copiedNotice = "Copied ${selectedSourceTab.fileName} to clipboard."
                                        },
                                        modifier = Modifier.testTag("copy_source_code_button"),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.ContentCopy,
                                            contentDescription = "Copy source file",
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Copy", style = MaterialTheme.typography.labelMedium)
                                    }
                                }
                            }

                            AnimatedVisibility(visible = copiedNotice != null) {
                                Text(
                                    text = copiedNotice.orEmpty(),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.tertiary
                                )
                            }

                            if (isEditingSource) {
                                OutlinedTextField(
                                    value = activeCodeContent,
                                    onValueChange = { updatedText ->
                                        when (selectedSourceTab) {
                                            SourceFileTab.MAIN_ACTIVITY -> editableKotlin = updatedText
                                            SourceFileTab.MANIFEST -> editableManifest = updatedText
                                            SourceFileTab.BUILD_GRADLE -> editableGradle = updatedText
                                            SourceFileTab.SANDBOX_JSON -> editableSandboxJson = updatedText
                                        }
                                    },
                                    textStyle = MaterialTheme.typography.bodySmall.copy(
                                        fontFamily = JetBrainsMonoFontFamily
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(320.dp)
                                        .testTag("inline_source_editor_input"),
                                    shape = RoundedCornerShape(12.dp)
                                )

                                Button(
                                    onClick = {
                                        onSaveEditedSource(
                                            editableKotlin,
                                            editableManifest,
                                            editableGradle,
                                            editableSandboxJson
                                        )
                                        isEditingSource = false
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("save_inline_source_button"),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Save,
                                        contentDescription = "Save Source Edits",
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Save Source Edits to Cloud Workspace")
                                }
                            } else {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(Color(0xFF070A12))
                                        .border(
                                            width = 1.dp,
                                            color = MaterialTheme.colorScheme.outline,
                                            shape = RoundedCornerShape(12.dp)
                                        )
                                        .padding(12.dp)
                                ) {
                                    Text(
                                        text = activeCodeContent,
                                        fontFamily = JetBrainsMonoFontFamily,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color(0xFFE2E8F0),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("wrapped_source_code_text")
                                    )
                                }
                            }
                        }
                    }
                }
            }

            SandboxViewMode.EXPORT_ARCHIVE -> {
                val archiveFiles = ProjectArchiveExporter.buildArchiveEntries(
                    activeProject,
                    includeFullGradleScaffold
                )
                val suggestedName = ProjectArchiveExporter.suggestedArchiveFileName(activeProject)

                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        ),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Archive,
                                    contentDescription = "Export Hub",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(22.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Project Configuration Archive (.zip)",
                                        style = MaterialTheme.typography.titleMedium,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = "Archive Name: $suggestedName",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            Text(
                                text = "Packages the synthesized Jetpack Compose Kotlin source, AndroidManifest.xml, Gradle build script, and Live Sandbox specification into a downloadable ZIP archive.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.fillMaxWidth()
                            )

                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                                    .padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = "Archive Manifest (${archiveFiles.size} files):",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                archiveFiles.forEach { (path, content) ->
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = path,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurface,
                                            modifier = Modifier.weight(1f)
                                        )
                                        Text(
                                            text = "${content.toByteArray().size} B",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }

                            Button(
                                onClick = { createZipLauncher.launch(suggestedName) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(50.dp)
                                    .testTag("export_archive_button"),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Download,
                                    contentDescription = "Save ZIP Archive to Device",
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Download Project Archive (.zip)",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            OutlinedButton(
                                onClick = { onExportToWorkspace(activeProject) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("workspace_export_button"),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.FolderZip,
                                    contentDescription = "Package in App Workspace",
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Package Archive to Studio Storage",
                                    style = MaterialTheme.typography.titleSmall
                                )
                            }

                            // Feature 9: Native Android Share Sheet Integration
                            OutlinedButton(
                                onClick = {
                                    ProjectArchiveExporter.shareProjectBlueprint(context, activeProject)
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("share_project_blueprint_button"),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Share,
                                    contentDescription = "Share Project Blueprint",
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Share Project Specification & Kotlin Code",
                                    style = MaterialTheme.typography.titleSmall
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun InteractiveSandboxWidgetCard(
    widget: SandboxWidget,
    numericValue: Float,
    onNumericChange: (Float) -> Unit,
    textValue: String,
    onTextChange: (String) -> Unit,
    toggleValue: Boolean,
    onToggleChange: (Boolean) -> Unit,
    checklistStates: MutableMap<String, Boolean>,
    customChecklistItems: List<String>,
    newChecklistEntry: String,
    onNewChecklistEntryChange: (String) -> Unit,
    onAddChecklistItem: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("sandbox_widget_${widget.id}"),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            when (widget.type.uppercase()) {
                "SLIDER" -> {
                    val safeMin = widget.minValue
                    val safeMax = if (widget.maxValue > safeMin) widget.maxValue else safeMin + 100f
                    val coerced = numericValue.coerceIn(safeMin, safeMax)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = widget.label,
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.weight(1f)
                        )
                        Text(
                            text = "${coerced.roundToInt()} ${widget.unit}".trim(),
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    if (widget.subtitle.isNotBlank()) {
                        Text(
                            text = widget.subtitle,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    Slider(
                        value = coerced,
                        onValueChange = onNumericChange,
                        valueRange = safeMin..safeMax,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                "NUMBER_INPUT" -> {
                    Text(
                        text = widget.label,
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    if (widget.subtitle.isNotBlank()) {
                        Text(
                            text = widget.subtitle,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    OutlinedTextField(
                        value = numericValue.toString(),
                        onValueChange = { str ->
                            str.toFloatOrNull()?.let { onNumericChange(it) }
                        },
                        suffix = {
                            if (widget.unit.isNotBlank()) {
                                Text(widget.unit, style = MaterialTheme.typography.labelMedium)
                            }
                        },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    )
                }

                "TOGGLE" -> {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = widget.label,
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            if (widget.subtitle.isNotBlank()) {
                                Text(
                                    text = widget.subtitle,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Switch(
                            checked = toggleValue,
                            onCheckedChange = onToggleChange
                        )
                    }
                }

                "SEGMENTED" -> {
                    Text(
                        text = widget.label,
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    if (widget.subtitle.isNotBlank()) {
                        Text(
                            text = widget.subtitle,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    val opts = widget.options.ifEmpty { listOf("Standard", "Optimized", "Strict") }
                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        opts.forEach { option ->
                            FilterChip(
                                selected = textValue == option,
                                onClick = { onTextChange(option) },
                                label = { Text(option, style = MaterialTheme.typography.bodySmall) }
                            )
                        }
                    }
                }

                "CHECKLIST" -> {
                    Text(
                        text = widget.label,
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    val allItems = widget.options + customChecklistItems
                    allItems.forEachIndexed { idx, itemText ->
                        val key = "${widget.id}_$idx"
                        val isChecked = checklistStates[key] ?: false
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { checklistStates[key] = !isChecked }
                                .padding(vertical = 2.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = isChecked,
                                onCheckedChange = { checklistStates[key] = it }
                            )
                            Text(
                                text = itemText,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = newChecklistEntry,
                            onValueChange = onNewChecklistEntryChange,
                            placeholder = { Text("Add checklist item...", style = MaterialTheme.typography.bodySmall) },
                            singleLine = true,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        )
                        Button(
                            onClick = onAddChecklistItem,
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("Add")
                        }
                    }
                }

                "METRIC_CARD" -> {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = widget.label,
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            if (widget.subtitle.isNotBlank()) {
                                Text(
                                    text = widget.subtitle,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        Text(
                            text = "${widget.defaultValue} ${widget.unit}".trim(),
                            style = MaterialTheme.typography.headlineSmall,
                            color = MaterialTheme.colorScheme.secondary
                        )
                    }
                }

                else -> {
                    Text(
                        text = widget.label,
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    if (widget.subtitle.isNotBlank()) {
                        Text(
                            text = widget.subtitle,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    OutlinedTextField(
                        value = textValue,
                        onValueChange = onTextChange,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    )
                }
            }
        }
    }
}
