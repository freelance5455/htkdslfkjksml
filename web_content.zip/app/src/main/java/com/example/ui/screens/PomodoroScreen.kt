package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Coffee
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.DopingAmber
import com.example.ui.theme.DopingGreen
import com.example.ui.theme.DopingPrimary
import com.example.ui.viewmodel.PomodoroState

@Composable
fun PomodoroScreen(
  pomodoroState: PomodoroState,
  onToggleTimer: () -> Unit,
  onResetTimer: () -> Unit,
  onSwitchMode: (Boolean) -> Unit,
  modifier: Modifier = Modifier
) {
  val minutes = pomodoroState.secondsRemaining / 60
  val seconds = pomodoroState.secondsRemaining % 60
  val progress = if (pomodoroState.totalDurationSeconds > 0) {
    pomodoroState.secondsRemaining.toFloat() / pomodoroState.totalDurationSeconds
  } else 1f

  val activeColor = if (pomodoroState.isBreak) DopingGreen else DopingPrimary

  Column(
    modifier = modifier
      .fillMaxSize()
      .padding(20.dp)
      .testTag("pomodoro_screen"),
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.SpaceBetween
  ) {
    // Mode Switcher Pills
    Row(
      horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
      FilterChip(
        selected = !pomodoroState.isBreak,
        onClick = { onSwitchMode(false) },
        label = { Text("⚡ 25 Dk Odaklanma", fontWeight = FontWeight.Bold) },
        colors = FilterChipDefaults.filterChipColors(
          selectedContainerColor = DopingPrimary,
          selectedLabelColor = Color.White
        ),
        modifier = Modifier.testTag("pomodoro_focus_chip")
      )

      FilterChip(
        selected = pomodoroState.isBreak,
        onClick = { onSwitchMode(true) },
        label = { Text("☕ 5 Dk Mola", fontWeight = FontWeight.Bold) },
        colors = FilterChipDefaults.filterChipColors(
          selectedContainerColor = DopingGreen,
          selectedLabelColor = Color.White
        ),
        modifier = Modifier.testTag("pomodoro_break_chip")
      )
    }

    // Circular Countdown Timer
    Box(
      modifier = Modifier
        .size(240.dp)
        .testTag("pomodoro_circular_timer"),
      contentAlignment = Alignment.Center
    ) {
      Canvas(modifier = Modifier.fillMaxSize()) {
        val strokeWidth = 14.dp.toPx()
        // Background track
        drawCircle(
          color = Color.LightGray.copy(alpha = 0.3f),
          style = Stroke(width = strokeWidth)
        )
        // Active arc
        drawArc(
          color = activeColor,
          startAngle = -90f,
          sweepAngle = 360f * progress,
          useCenter = false,
          style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
        )
      }

      Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(
          imageVector = if (pomodoroState.isBreak) Icons.Default.Coffee else Icons.Default.Psychology,
          contentDescription = null,
          tint = activeColor,
          modifier = Modifier.size(36.dp)
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
          text = String.format("%02d:%02d", minutes, seconds),
          fontSize = 44.sp,
          fontWeight = FontWeight.Black,
          color = MaterialTheme.colorScheme.onSurface
        )
        Text(
          text = if (pomodoroState.isBreak) "Dinlenme Zamanı" else "Derin Odaklanma",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }
    }

    // Control Buttons
    Row(
      horizontalArrangement = Arrangement.spacedBy(16.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      OutlinedButton(
        onClick = onResetTimer,
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.size(54.dp),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)
      ) {
        Icon(imageVector = Icons.Default.Refresh, contentDescription = "Sıfırla")
      }

      Button(
        onClick = onToggleTimer,
        shape = RoundedCornerShape(20.dp),
        colors = ButtonDefaults.buttonColors(containerColor = activeColor),
        modifier = Modifier
          .height(54.dp)
          .width(170.dp)
          .testTag("pomodoro_toggle_btn")
      ) {
        Icon(
          imageVector = if (pomodoroState.isRunning) Icons.Default.Pause else Icons.Default.PlayArrow,
          contentDescription = null,
          modifier = Modifier.size(24.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = if (pomodoroState.isRunning) "Duraklat" else "Başlat",
          fontSize = 16.sp,
          fontWeight = FontWeight.Bold
        )
      }
    }

    // Motivation Quote & Cycles Card
    Card(
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(16.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
      elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Box(
          modifier = Modifier
            .size(42.dp)
            .clip(CircleShape)
            .background(Color(0xFFFEF3C7)),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = Icons.Default.AutoAwesome,
            contentDescription = null,
            tint = Color(0xFFD97706),
            modifier = Modifier.size(22.dp)
          )
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column {
          Text(
            text = "Bugün ${pomodoroState.completedCycles} Döngü Tamamlandı 🔥",
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurface
          )
          Text(
            text = "Hafıza Teknikleri Kuralı: 25 dakika odaklı çalıştıktan sonra 5 dakika zihnini dinlendirmek öğrenilen bilgilerin kalıcı belleğe geçmesini sağlar.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }
    }
  }
}
