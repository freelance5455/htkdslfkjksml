package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Casino
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Diamond
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ad.RewardedAdManager
import com.example.ui.theme.DangerRed
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkCard
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.GemCyan
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.SuccessGreen
import kotlinx.coroutines.delay
import kotlin.random.Random

private val GAME_ICONS = listOf(
    Icons.Default.Diamond,
    Icons.Default.MonetizationOn,
    Icons.Default.Star,
    Icons.Default.Shield,
    Icons.Default.EmojiEvents,
    Icons.Default.WorkspacePremium,
    Icons.Default.Favorite,
    Icons.Default.LocalFireDepartment,
    Icons.Default.Key,
    Icons.Default.Casino
)

private val ICON_NAMES = mapOf(
    Icons.Default.Diamond to "Diamond Gem",
    Icons.Default.MonetizationOn to "Gold Coin",
    Icons.Default.Star to "Lucky Star",
    Icons.Default.Shield to "Golden Shield",
    Icons.Default.EmojiEvents to "Champion Trophy",
    Icons.Default.WorkspacePremium to "Royal Badge",
    Icons.Default.Favorite to "Heart Ruby",
    Icons.Default.LocalFireDepartment to "Fire Flame",
    Icons.Default.Key to "Mystery Key",
    Icons.Default.Casino to "Magic Die"
)

@Composable
fun ImageFinderGameDialog(
    onDismiss: () -> Unit,
    onGemEarned: () -> Unit
) {
    var roundNumber by remember { mutableIntStateOf(1) }
    var secondsLeft by remember { mutableIntStateOf(15) }
    var isGameOver by remember { mutableStateOf(false) }
    var hasWon by remember { mutableStateOf(false) }
    var wrongSelectionIndex by remember { mutableIntStateOf(-1) }

    // Pick target icon and generate 16 tiles (with target placed randomly)
    val targetIcon = remember(roundNumber) { GAME_ICONS.random() }
    val gridIcons = remember(roundNumber) {
        val list = MutableList(16) {
            val otherIcons = GAME_ICONS.filter { it != targetIcon }
            otherIcons.random()
        }
        val targetIndex = Random.nextInt(16)
        list[targetIndex] = targetIcon
        list
    }

    // 15-second countdown timer
    LaunchedEffect(roundNumber, isGameOver) {
        if (!isGameOver) {
            secondsLeft = 15
            while (secondsLeft > 0 && !hasWon) {
                delay(1000)
                secondsLeft--
            }
            if (secondsLeft == 0 && !hasWon) {
                isGameOver = true
            }
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .clip(RoundedCornerShape(24.dp))
                .background(DarkSurface)
                .border(1.5.dp, GoldPrimary.copy(alpha = 0.5f), RoundedCornerShape(24.dp))
                .padding(20.dp)
                .testTag("image_finder_game_dialog")
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                // Header with round and close
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = "Round $roundNumber",
                            color = GoldPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(DarkCard)
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                        Text(
                            text = "Reward: +1 💎",
                            color = GemCyan,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(DarkCard)
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }

                    IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = Color.Gray)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = "Find the Hidden Target!",
                    color = Color.White,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 20.sp
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Target Banner
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(
                            Brush.horizontalGradient(
                                listOf(DarkCard, DarkCard.copy(alpha = 0.8f))
                            )
                        )
                        .border(1.dp, GemCyan.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
                        .padding(vertical = 10.dp, horizontal = 16.dp)
                ) {
                    Text(
                        text = "TARGET: ",
                        color = Color.Gray,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    Icon(
                        imageVector = targetIcon,
                        contentDescription = "Target Icon",
                        tint = GemCyan,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = ICON_NAMES[targetIcon] ?: "Target",
                        color = Color.White,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 15.sp
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Countdown Timer Bar
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Icon(
                            imageVector = Icons.Default.Timer,
                            contentDescription = null,
                            tint = if (secondsLeft <= 5) DangerRed else GoldPrimary,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "${secondsLeft}s",
                            color = if (secondsLeft <= 5) DangerRed else GoldPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                    Text(
                        text = "15-second timer",
                        color = Color.Gray,
                        fontSize = 11.sp
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                LinearProgressIndicator(
                    progress = { (secondsLeft / 15f).coerceIn(0f, 1f) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp)),
                    color = if (secondsLeft <= 5) DangerRed else GoldPrimary,
                    trackColor = DarkBorder
                )

                Spacer(modifier = Modifier.height(16.dp))

                // 4x4 Grid of Tiles
                LazyVerticalGrid(
                    columns = GridCells.Fixed(4),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(1f)
                ) {
                    items(16) { index ->
                        val icon = gridIcons[index]
                        val isTarget = icon == targetIcon
                        val isWrong = wrongSelectionIndex == index

                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .aspectRatio(1f)
                                .clip(RoundedCornerShape(12.dp))
                                .background(
                                    when {
                                        hasWon && isTarget -> SuccessGreen.copy(alpha = 0.3f)
                                        isWrong -> DangerRed.copy(alpha = 0.3f)
                                        else -> DarkCard
                                    }
                                )
                                .border(
                                    width = if ((hasWon && isTarget) || isWrong) 2.dp else 1.dp,
                                    color = when {
                                        hasWon && isTarget -> SuccessGreen
                                        isWrong -> DangerRed
                                        else -> DarkBorder
                                    },
                                    shape = RoundedCornerShape(12.dp)
                                )
                                .clickable(enabled = !isGameOver && !hasWon) {
                                    if (isTarget) {
                                        hasWon = true
                                        // Award Gem and trigger AdMob Rewarded Video Ad
                                        RewardedAdManager.showRewardedAd(
                                            adTitle = "Image Finder Victory Ad",
                                            sponsorName = "Quest Rewards Partner",
                                            onRewardEarned = {
                                                onGemEarned()
                                            }
                                        )
                                    } else {
                                        wrongSelectionIndex = index
                                    }
                                }
                        ) {
                            Icon(
                                imageVector = icon,
                                contentDescription = null,
                                tint = if (hasWon && isTarget) GoldPrimary else Color.White.copy(alpha = 0.9f),
                                modifier = Modifier.size(30.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Status & Controls
                when {
                    hasWon -> {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "🎉 TARGET FOUND! +1 Gem Earned!",
                                color = SuccessGreen,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                textAlign = TextAlign.Center
                            )
                            Text(
                                text = "Rewarded video ad has completed. Unlimited rounds available!",
                                color = Color.Gray,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(top = 4.dp)
                            )
                            Spacer(modifier = Modifier.height(14.dp))
                            Button(
                                onClick = {
                                    hasWon = false
                                    isGameOver = false
                                    wrongSelectionIndex = -1
                                    roundNumber++
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                            ) {
                                Text(
                                    text = "Play Next Round ➔",
                                    color = Color.Black,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                            }
                        }
                    }
                    isGameOver -> {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "⏰ Time's up! Don't worry, try again!",
                                color = DangerRed,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                            Spacer(modifier = Modifier.height(14.dp))
                            Button(
                                onClick = {
                                    hasWon = false
                                    isGameOver = false
                                    wrongSelectionIndex = -1
                                    roundNumber++
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                            ) {
                                Text(
                                    text = "Try Again",
                                    color = Color.Black,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                            }
                        }
                    }
                    else -> {
                        Text(
                            text = "Tap the tile matching the target before timer runs out!",
                            color = Color.Gray,
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }
    }
}
