package com.example.ui.screens

import android.graphics.BitmapFactory
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.ui.graphics.Color
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.VaultRepository
import com.example.ui.components.SilverButton
import com.example.ui.components.SlantedShape
import com.example.ui.components.TopBarWithClose
import com.example.ui.components.YmTextField
import com.example.ui.theme.AccentRed
import com.example.ui.theme.BlackCharcoal
import com.example.ui.theme.BlackPure
import com.example.ui.theme.SilverDark
import com.example.ui.theme.SilverLight
import com.example.ui.theme.SilverSurface
import com.example.ui.theme.SilverSurfaceVariant
import com.example.util.PdfElement
import com.example.util.PdfGenerator
import com.example.util.TextStyle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

sealed class DraftBlock {
    data class TextDraft(
        var id: Long = System.currentTimeMillis() + (0..1000).random(),
        var content: String = "",
        var style: TextStyle = TextStyle.BODY
    ) : DraftBlock()

    data class ImageDraft(
        var id: Long = System.currentTimeMillis() + (0..1000).random(),
        val uri: Uri,
        val bitmap: android.graphics.Bitmap,
        var caption: String = ""
    ) : DraftBlock()
}

@Composable
fun CreatePdfScreen(
    repository: VaultRepository,
    onBack: () -> Unit,
    onPdfCreated: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var docTitle by remember { mutableStateOf("YM Secret Document") }
    val blocks = remember { mutableStateListOf<DraftBlock>() }
    var isGenerating by remember { mutableStateOf(false) }

    // Image Picker
    val imagePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetMultipleContents()
    ) { uris: List<Uri>? ->
        if (!uris.isNullOrEmpty()) {
            scope.launch {
                for (uri in uris) {
                    try {
                        val bmp = withContext(Dispatchers.IO) {
                            context.contentResolver.openInputStream(uri)?.use { stream ->
                                BitmapFactory.decodeStream(stream)
                            }
                        }
                        if (bmp != null) {
                            blocks.add(DraftBlock.ImageDraft(uri = uri, bitmap = bmp))
                        }
                    } catch (e: Exception) {
                        Toast.makeText(context, "Error reading image: ${e.message}", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SilverLight)
    ) {
        // Mandatory X button at top
        TopBarWithClose(
            title = "Create a PDF File",
            subtitle = "Text & Image Arranger",
            onCloseClick = onBack
        )

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(4.dp))
                // Document Title
                YmTextField(
                    value = docTitle,
                    onValueChange = { docTitle = it },
                    label = "PDF Document Title",
                    singleLine = true,
                    testTag = "input_pdf_title",
                    modifier = Modifier.fillMaxWidth()
                )
            }

            item {
                // Add Buttons Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    SilverButton(
                        text = "Add Text",
                        icon = Icons.Default.TextFields,
                        modifier = Modifier.weight(1f),
                        onClick = {
                            blocks.add(DraftBlock.TextDraft(content = ""))
                        }
                    )

                    SilverButton(
                        text = "Add Images",
                        icon = Icons.Default.Image,
                        modifier = Modifier.weight(1f),
                        onClick = {
                            imagePicker.launch("image/*")
                        }
                    )
                }
            }

            if (blocks.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 40.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.PictureAsPdf,
                                contentDescription = null,
                                tint = SilverDark,
                                modifier = Modifier.size(54.dp)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "Document is empty",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = BlackPure
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Tap 'Add Text' or 'Add Images' above to build your PDF.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = SilverDark
                            )
                        }
                    }
                }
            } else {
                itemsIndexed(blocks, key = { _, block ->
                    when (block) {
                        is DraftBlock.TextDraft -> block.id
                        is DraftBlock.ImageDraft -> block.id
                    }
                }) { index, block ->
                    DraftBlockItem(
                        block = block,
                        index = index,
                        totalCount = blocks.size,
                        onMoveUp = {
                            if (index > 0) {
                                val item = blocks.removeAt(index)
                                blocks.add(index - 1, item)
                            }
                        },
                        onMoveDown = {
                            if (index < blocks.size - 1) {
                                val item = blocks.removeAt(index)
                                blocks.add(index + 1, item)
                            }
                        },
                        onDelete = {
                            blocks.removeAt(index)
                        },
                        onTextChange = { newText ->
                            if (block is DraftBlock.TextDraft) {
                                block.content = newText
                            }
                        },
                        onStyleChange = { newStyle ->
                            if (block is DraftBlock.TextDraft) {
                                block.style = newStyle
                            }
                        },
                        onCaptionChange = { newCaption ->
                            if (block is DraftBlock.ImageDraft) {
                                block.caption = newCaption
                            }
                        }
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(16.dp))
            }
        }

        // Bottom Save / Create PDF bar
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(SilverSurface)
                .border(BorderStroke(1.dp, BlackPure))
                .padding(16.dp)
        ) {
            SilverButton(
                text = if (isGenerating) "Generating PDF..." else "Save / Create PDF",
                icon = Icons.Default.PictureAsPdf,
                isDark = true,
                enabled = !isGenerating && blocks.isNotEmpty(),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("btn_save_pdf"),
                onClick = {
                    if (blocks.isEmpty()) {
                        Toast.makeText(context, "Add at least one text or image block", Toast.LENGTH_SHORT).show()
                        return@SilverButton
                    }

                    isGenerating = true
                    scope.launch {
                        try {
                            val elements = blocks.map { block ->
                                when (block) {
                                    is DraftBlock.TextDraft -> PdfElement.TextElement(
                                        text = block.content.ifEmpty { " " },
                                        style = block.style
                                    )
                                    is DraftBlock.ImageDraft -> PdfElement.ImageElement(
                                        bitmap = block.bitmap,
                                        caption = block.caption
                                    )
                                }
                            }

                            val (pdfFile, pageCount) = PdfGenerator.createCustomPdf(
                                context = context,
                                documentTitle = docTitle,
                                elements = elements
                            )

                            repository.registerPdf(
                                title = docTitle.ifEmpty { "YM Secret Document" },
                                file = pdfFile,
                                pageCount = pageCount
                            )

                            Toast.makeText(
                                context,
                                "PDF created and saved locally ($pageCount pages)!",
                                Toast.LENGTH_LONG
                            ).show()

                            onPdfCreated()
                        } catch (e: Exception) {
                            Toast.makeText(context, "Error creating PDF: ${e.message}", Toast.LENGTH_LONG).show()
                        } finally {
                            isGenerating = false
                        }
                    }
                }
            )
        }
    }
}

@Composable
fun DraftBlockItem(
    block: DraftBlock,
    index: Int,
    totalCount: Int,
    onMoveUp: () -> Unit,
    onMoveDown: () -> Unit,
    onDelete: () -> Unit,
    onTextChange: (String) -> Unit,
    onStyleChange: (TextStyle) -> Unit,
    onCaptionChange: (String) -> Unit
) {
    var textValue by remember(block) {
        mutableStateOf(
            if (block is DraftBlock.TextDraft) block.content else ""
        )
    }
    var selectedStyle by remember(block) {
        mutableStateOf(
            if (block is DraftBlock.TextDraft) block.style else TextStyle.BODY
        )
    }
    var captionValue by remember(block) {
        mutableStateOf(
            if (block is DraftBlock.ImageDraft) block.caption else ""
        )
    }
    var styleMenuExpanded by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(SlantedShape)
            .background(SilverSurface)
            .border(BorderStroke(1.2.dp, BlackPure), SlantedShape)
            .padding(12.dp)
    ) {
        Column {
            // Block Header with Position & Controls
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "#${index + 1} ",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = BlackPure
                    )
                    Text(
                        text = if (block is DraftBlock.TextDraft) "Text Block" else "Image Block",
                        style = MaterialTheme.typography.labelSmall,
                        color = SilverDark,
                        fontWeight = FontWeight.Bold
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onMoveUp,
                        enabled = index > 0,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ArrowUpward,
                            contentDescription = "Move Up",
                            tint = if (index > 0) BlackPure else SilverDark.copy(alpha = 0.4f),
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    IconButton(
                        onClick = onMoveDown,
                        enabled = index < totalCount - 1,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ArrowDownward,
                            contentDescription = "Move Down",
                            tint = if (index < totalCount - 1) BlackPure else SilverDark.copy(alpha = 0.4f),
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Delete",
                            tint = AccentRed,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            when (block) {
                is DraftBlock.TextDraft -> {
                    // Style Selector
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Style: ${selectedStyle.name}",
                            style = MaterialTheme.typography.labelSmall,
                            color = BlackPure,
                            fontWeight = FontWeight.Bold
                        )

                        Box {
                            TextButton(onClick = { styleMenuExpanded = true }) {
                                Text("Change Style", color = BlackPure, fontWeight = FontWeight.Bold)
                            }
                            DropdownMenu(
                                expanded = styleMenuExpanded,
                                onDismissRequest = { styleMenuExpanded = false },
                                modifier = Modifier.background(SilverLight)
                            ) {
                                TextStyle.entries.forEach { style ->
                                    DropdownMenuItem(
                                        text = { Text(style.name, color = BlackPure) },
                                        onClick = {
                                            selectedStyle = style
                                            onStyleChange(style)
                                            styleMenuExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }

                    YmTextField(
                        value = textValue,
                        onValueChange = {
                            textValue = it
                            onTextChange(it)
                        },
                        placeholder = "Enter text content here...",
                        singleLine = false,
                        minLines = 3,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                is DraftBlock.ImageDraft -> {
                    // Image Preview
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                            .clip(SlantedShape)
                            .border(BorderStroke(1.dp, BlackPure), SlantedShape)
                    ) {
                        Image(
                            bitmap = block.bitmap.asImageBitmap(),
                            contentDescription = "Image preview",
                            contentScale = ContentScale.Fit,
                            modifier = Modifier
                                .fillMaxSize()
                                .background(Color.White)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    YmTextField(
                        value = captionValue,
                        onValueChange = {
                            captionValue = it
                            onCaptionChange(it)
                        },
                        label = "Optional Caption",
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
    }
}
