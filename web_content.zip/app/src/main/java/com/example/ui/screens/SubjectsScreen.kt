package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.StudySession
import com.example.data.model.Subject
import com.example.ui.components.AddEditSubjectDialog
import com.example.ui.theme.AestheticBlack
import com.example.ui.theme.BorderGrey
import com.example.ui.theme.CardGrey
import com.example.ui.theme.DeepPink
import com.example.ui.theme.KawaiiPink
import com.example.ui.theme.PastelPinkBg
import com.example.ui.theme.PastelPinkContainer
import com.example.ui.theme.PureWhite
import com.example.ui.theme.TextGrey
import java.util.Calendar

@Composable
fun SubjectsScreen(
    subjects: List<Subject>,
    sessions: List<StudySession>,
    onAddSubject: (String, String, String, Int) -> Unit,
    onUpdateSubject: (Subject) -> Unit,
    onDeleteSubject: (Subject) -> Unit,
    onStartFocusSubject: (Subject) -> Unit,
    modifier: Modifier = Modifier
) {
    var editingSubject by remember { mutableStateOf<Subject?>(null) }
    var showAddDialog by remember { mutableStateOf(false) }

    val calendar = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, 0)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }
    val startOfDay = calendar.timeInMillis

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = AestheticBlack,
                contentColor = PureWhite,
                shape = CircleShape,
                modifier = Modifier.testTag("add_subject_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Subject")
            }
        },
        containerColor = PastelPinkBg,
        modifier = modifier.fillMaxSize()
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 20.dp, vertical = 12.dp)
        ) {
            // Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "📚 Study Subjects",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = (-0.5).sp
                        ),
                        color = AestheticBlack
                    )
                    Text(
                        text = "${subjects.size} subjects tracking focus",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextGrey
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (subjects.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("📖", fontSize = 48.sp)
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "No subjects yet",
                            style = MaterialTheme.typography.titleMedium,
                            color = AestheticBlack
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Add your school courses, skills, or projects to organize your Pomodoros.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextGrey,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(subjects, key = { it.id }) { subject ->
                        val subjectSessions = sessions.filter { it.subjectId == subject.id && it.sessionType == "FOCUS" }
                        val todayMinutes = subjectSessions
                            .filter { it.timestamp >= startOfDay }
                            .sumOf { it.durationSeconds } / 60
                        val allTimeMinutes = subjectSessions.sumOf { it.durationSeconds } / 60
                        val allTimeHours = allTimeMinutes / 60
                        val allTimeRemainMin = allTimeMinutes % 60

                        val subjectColor = try {
                            Color(android.graphics.Color.parseColor(subject.colorHex))
                        } catch (_: Exception) {
                            DeepPink
                        }

                        val progress = (todayMinutes.toFloat() / subject.dailyGoalMinutes.coerceAtLeast(1).toFloat()).coerceIn(0f, 1f)

                        Card(
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(containerColor = PureWhite),
                            border = androidx.compose.foundation.BorderStroke(1.dp, BorderGrey),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("subject_card_${subject.id}")
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                // Subject Header Row
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .size(46.dp)
                                                .clip(CircleShape)
                                                .background(PastelPinkBg)
                                                .border(1.dp, BorderGrey, CircleShape),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(text = subject.icon, fontSize = 22.sp)
                                        }

                                        Spacer(modifier = Modifier.width(12.dp))

                                        Column {
                                            Text(
                                                text = subject.name,
                                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                                color = AestheticBlack
                                            )
                                            Text(
                                                text = "All time: ${allTimeHours}h ${allTimeRemainMin}m",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = TextGrey
                                            )
                                        }
                                    }

                                    IconButton(
                                        onClick = { editingSubject = subject },
                                        modifier = Modifier.size(36.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.Edit,
                                            contentDescription = "Edit subject",
                                            tint = TextGrey,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(14.dp))

                                // Daily Target Progress
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "Today's Focus: ${todayMinutes}m / ${subject.dailyGoalMinutes}m",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TextGrey
                                    )
                                    Text(
                                        text = "${(progress * 100).toInt()}%",
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                        color = DeepPink
                                    )
                                }

                                Spacer(modifier = Modifier.height(6.dp))

                                LinearProgressIndicator(
                                    progress = { progress },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(8.dp)
                                        .clip(RoundedCornerShape(4.dp)),
                                    color = DeepPink,
                                    trackColor = CardGrey,
                                    strokeCap = StrokeCap.Round
                                )

                                Spacer(modifier = Modifier.height(14.dp))

                                // Action Row
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.End
                                ) {
                                    Button(
                                        onClick = { onStartFocusSubject(subject) },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = PastelPinkContainer,
                                            contentColor = DeepPink
                                        ),
                                        shape = RoundedCornerShape(12.dp),
                                        border = androidx.compose.foundation.BorderStroke(1.dp, DeepPink.copy(alpha = 0.4f)),
                                        modifier = Modifier.height(36.dp)
                                    ) {
                                        Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "Start Focus",
                                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    item {
                        Spacer(modifier = Modifier.height(64.dp))
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        AddEditSubjectDialog(
            initialSubject = null,
            onSave = { name, icon, color, goal ->
                onAddSubject(name, icon, color, goal)
            },
            onDismiss = { showAddDialog = false }
        )
    }

    if (editingSubject != null) {
        val currentEdit = editingSubject!!
        AddEditSubjectDialog(
            initialSubject = currentEdit,
            onSave = { name, icon, color, goal ->
                onUpdateSubject(
                    currentEdit.copy(
                        name = name,
                        icon = icon,
                        colorHex = color,
                        dailyGoalMinutes = goal
                    )
                )
            },
            onDelete = {
                onDeleteSubject(currentEdit)
            },
            onDismiss = { editingSubject = null }
        )
    }
}
