package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.Collections
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.ChatLanguage
import com.example.data.models.ChatSession
import com.example.data.models.ScreenDestination
import com.example.data.models.UserAccount
import com.example.ui.theme.HazimCyan
import com.example.ui.theme.HazimCyanGlow
import com.example.ui.theme.HazimDarkBackground
import com.example.ui.theme.HazimDarkBorder
import com.example.ui.theme.HazimDarkSurface
import com.example.ui.theme.HazimDarkSurfaceVariant
import com.example.ui.theme.HazimPurple
import com.example.ui.theme.TextPrimaryDark
import com.example.ui.theme.TextSecondaryDark
import com.example.ui.theme.TextTertiaryDark

@Composable
fun DrawerContent(
    currentScreen: ScreenDestination,
    chatSessions: List<ChatSession>,
    currentSessionId: String,
    currentLanguage: ChatLanguage,
    userAccount: UserAccount,
    onNavigate: (ScreenDestination) -> Unit,
    onNewChat: () -> Unit,
    onSelectChatSession: (String) -> Unit,
    onDeleteChatSession: (String) -> Unit,
    onSelectLanguage: (ChatLanguage) -> Unit,
    onOpenAuth: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxHeight()
            .width(310.dp)
            .background(HazimDarkBackground)
            .padding(16.dp)
    ) {
        // App Branding Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(
                        Brush.linearGradient(
                            listOf(HazimCyan, HazimPurple)
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = "HAZIM AI",
                    tint = Color.Black,
                    modifier = Modifier.size(22.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "HAZIM AI",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = TextPrimaryDark,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(HazimCyan.copy(alpha = 0.2f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "PRO 3.5",
                            color = HazimCyan,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
                Text(
                    text = "Multimodal AI Studio",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondaryDark,
                    fontSize = 11.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // New Chat Button (ChatGPT / Claude style)
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .height(44.dp)
                .clip(RoundedCornerShape(12.dp))
                .border(1.dp, HazimCyan.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
                .clickable {
                    onNewChat()
                    onNavigate(ScreenDestination.CHAT)
                }
                .testTag("drawer_new_chat_button"),
            color = HazimDarkSurfaceVariant
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "New Chat",
                    tint = HazimCyan,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "New Chat",
                    color = TextPrimaryDark,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 14.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Main Navigation Hub
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            DrawerNavItem(
                icon = Icons.Default.ChatBubbleOutline,
                title = "Chat Studio",
                subtitle = "Multilingual ChatGPT / Claude",
                isSelected = currentScreen == ScreenDestination.CHAT,
                badge = currentLanguage.name,
                testTag = "nav_chat_studio",
                onClick = { onNavigate(ScreenDestination.CHAT) }
            )

            DrawerNavItem(
                icon = Icons.Default.Image,
                title = "Text to Image (TTI)",
                subtitle = "Generate 8K Artwork",
                isSelected = currentScreen == ScreenDestination.TEXT_TO_IMAGE,
                badge = "TTI",
                testTag = "nav_text_to_image",
                onClick = { onNavigate(ScreenDestination.TEXT_TO_IMAGE) }
            )

            DrawerNavItem(
                icon = Icons.Default.Movie,
                title = "Image to Video (ITV)",
                subtitle = "60 FPS Motion Studio",
                isSelected = currentScreen == ScreenDestination.IMAGE_TO_VIDEO,
                badge = "ITV",
                testTag = "nav_image_to_video",
                onClick = { onNavigate(ScreenDestination.IMAGE_TO_VIDEO) }
            )

            DrawerNavItem(
                icon = Icons.Default.GraphicEq,
                title = "Speech to Voice (STV)",
                subtitle = "Hindi, English, Kashmiri",
                isSelected = currentScreen == ScreenDestination.SPEECH_TO_VOICE,
                badge = "STV",
                testTag = "nav_speech_to_voice",
                onClick = { onNavigate(ScreenDestination.SPEECH_TO_VOICE) }
            )

            DrawerNavItem(
                icon = Icons.Default.Collections,
                title = "My Gallery",
                subtitle = "Saved Media Vault",
                isSelected = currentScreen == ScreenDestination.GALLERY,
                testTag = "nav_gallery",
                onClick = { onNavigate(ScreenDestination.GALLERY) }
            )
        }

        Spacer(modifier = Modifier.height(12.dp))
        Divider(color = HazimDarkBorder, thickness = 1.dp)
        Spacer(modifier = Modifier.height(8.dp))

        // Language quick bar
        Text(
            text = "CHATBOT LANGUAGE",
            style = MaterialTheme.typography.labelSmall,
            color = TextTertiaryDark,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 4.dp, vertical = 4.dp)
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            ChatLanguage.values().forEach { lang ->
                val isSelected = currentLanguage == lang
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) HazimCyan.copy(alpha = 0.2f) else HazimDarkSurfaceVariant)
                        .border(
                            1.dp,
                            if (isSelected) HazimCyan else Color.Transparent,
                            RoundedCornerShape(8.dp)
                        )
                        .clickable { onSelectLanguage(lang) }
                        .padding(vertical = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = when (lang) {
                            ChatLanguage.ENGLISH -> "EN"
                            ChatLanguage.HINDI -> "HI"
                            ChatLanguage.HINGLISH -> "HING"
                            ChatLanguage.KASHMIRI -> "KS"
                        },
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        color = if (isSelected) HazimCyan else TextSecondaryDark
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))
        Divider(color = HazimDarkBorder, thickness = 1.dp)

        // Chat History Section
        Text(
            text = "RECENT CHATS",
            style = MaterialTheme.typography.labelSmall,
            color = TextTertiaryDark,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 4.dp, vertical = 8.dp)
        )

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            items(chatSessions) { session ->
                val isSelected = session.id == currentSessionId
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) HazimDarkSurfaceVariant else Color.Transparent)
                        .clickable {
                            onSelectChatSession(session.id)
                            onNavigate(ScreenDestination.CHAT)
                        }
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.ChatBubbleOutline,
                            contentDescription = null,
                            tint = if (isSelected) HazimCyan else TextSecondaryDark,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = session.title,
                            color = if (isSelected) TextPrimaryDark else TextSecondaryDark,
                            fontSize = 13.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    if (chatSessions.size > 1) {
                        IconButton(
                            onClick = { onDeleteChatSession(session.id) },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = "Delete Chat",
                                tint = TextTertiaryDark,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                }
            }
        }

        Divider(color = HazimDarkBorder, thickness = 1.dp)
        Spacer(modifier = Modifier.height(10.dp))

        // User Account / Profile Footer (ChatGPT / Claude style)
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .clickable { onOpenAuth() }
                .testTag("drawer_user_profile_footer"),
            color = HazimDarkSurface
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(Brush.linearGradient(listOf(HazimPurple, HazimCyan))),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = userAccount.name.take(1).uppercase(),
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 16.sp
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = userAccount.name,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = TextPrimaryDark,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = if (userAccount.isLoggedIn) "Via ${userAccount.authProvider}" else "Tap to Sign In",
                        style = MaterialTheme.typography.bodySmall,
                        color = if (userAccount.isLoggedIn) HazimCyanGlow else TextSecondaryDark,
                        fontSize = 11.sp
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(HazimCyan.copy(alpha = 0.15f))
                        .padding(horizontal = 6.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = "PRO",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = HazimCyan
                    )
                }
            }
        }
    }
}

@Composable
private fun DrawerNavItem(
    icon: ImageVector,
    title: String,
    subtitle: String,
    isSelected: Boolean,
    badge: String? = null,
    testTag: String,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .clickable { onClick() }
            .testTag(testTag),
        color = if (isSelected) HazimDarkSurfaceVariant else Color.Transparent
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = if (isSelected) HazimCyan else TextSecondaryDark,
                modifier = Modifier.size(20.dp)
            )

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
                    color = if (isSelected) TextPrimaryDark else TextSecondaryDark
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextTertiaryDark,
                    fontSize = 10.sp
                )
            }

            if (badge != null) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (isSelected) HazimCyan.copy(alpha = 0.2f) else HazimDarkSurface)
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = badge,
                        color = if (isSelected) HazimCyan else TextSecondaryDark,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
