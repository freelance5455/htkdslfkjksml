package com.example.ui.util

import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object BanglaHelper {

    val BANGLA_MONTHS = listOf(
        "জানুয়ারি",
        "ফেব্রুয়ারি",
        "মার্চ",
        "এপ্রিল",
        "মে",
        "জুন",
        "জুলাই",
        "আগস্ট",
        "সেপ্টেম্বর",
        "অক্টোবর",
        "নভেম্বর",
        "ডিসেম্বর"
    )

    private val banglaDigits = charArrayOf('০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯')
    private val englishDigits = charArrayOf('0', '1', '2', '3', '4', '5', '6', '7', '8', '9')

    fun toBanglaDigits(input: Any?): String {
        if (input == null) return "০"
        val str = input.toString()
        val sb = StringBuilder()
        for (ch in str) {
            when (ch) {
                in '0'..'9' -> sb.append(banglaDigits[ch - '0'])
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }

    fun toEnglishDigits(input: String): String {
        val sb = StringBuilder()
        for (ch in input) {
            var found = false
            for (i in banglaDigits.indices) {
                if (ch == banglaDigits[i]) {
                    sb.append(englishDigits[i])
                    found = true
                    break
                }
            }
            if (!found) {
                sb.append(ch)
            }
        }
        return sb.toString()
    }

    fun parseAmount(input: String): Double? {
        val cleaned = toEnglishDigits(input.trim().replace(",", ""))
        return try {
            val amt = cleaned.toDouble()
            if (amt < 0.0 || amt.isNaN() || amt.isInfinite()) null else amt
        } catch (_: Exception) {
            null
        }
    }

    fun formatCurrency(amount: Double): String {
        val safeAmount = if (amount.isNaN() || amount.isInfinite()) 0.0 else amount
        val isNegative = safeAmount < 0
        val absAmount = kotlin.math.abs(safeAmount)
        val formatted = if (absAmount % 1.0 == 0.0) {
            String.format(Locale.US, "%,d", absAmount.toLong())
        } else {
            String.format(Locale.US, "%,.2f", absAmount)
        }
        val banglaFormatted = toBanglaDigits(formatted)
        return if (isNegative) "- ৳ $banglaFormatted" else "৳ $banglaFormatted"
    }

    fun getTodayIso(): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        return sdf.format(Date())
    }

    fun getCurrentYear(): Int {
        return Calendar.getInstance().get(Calendar.YEAR)
    }

    fun getCurrentMonthIndex(): Int {
        // 1 to 12
        return Calendar.getInstance().get(Calendar.MONTH) + 1
    }

    fun formatBanglaDate(isoDate: String): String {
        return try {
            val parts = isoDate.split("-")
            if (parts.size == 3) {
                val year = parts[0].toInt()
                val month = parts[1].toInt()
                val day = parts[2].toInt()
                val monthName = if (month in 1..12) BANGLA_MONTHS[month - 1] else parts[1]
                "${toBanglaDigits(day)} $monthName, ${toBanglaDigits(year)}"
            } else {
                toBanglaDigits(isoDate)
            }
        } catch (_: Exception) {
            toBanglaDigits(isoDate)
        }
    }

    fun getMonthNameFromIso(isoDate: String): String {
        return try {
            val parts = isoDate.split("-")
            if (parts.size >= 2) {
                val month = parts[1].toInt()
                if (month in 1..12) BANGLA_MONTHS[month - 1] else ""
            } else ""
        } catch (_: Exception) {
            ""
        }
    }
}
