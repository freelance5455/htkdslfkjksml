package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.localization.AppLang
import com.example.localization.SjsStrings
import com.example.model.*
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.viewmodel.UiState
import kotlinx.coroutines.flow.Flow

@Composable
fun OrdersAndChatScreen(
    lang: AppLang,
    isProviderMode: Boolean,
    currentUserId: String,
    userProfile: UserProfile?,
    ordersState: UiState<List<SecurityOrder>>,
    payments: List<PaymentTransaction>,
    providers: List<SecurityProvider>,
    isBusy: Boolean,
    observeMessages: (String) -> Flow<List<OrderMessage>>,
    onMarkReceived: (String) -> Unit,
    onSubmitQuotation: (String, Long, String) -> Unit,
    onAcceptQuotation: (String) -> Unit,
    onInitiatePayment: (SecurityOrder, String, (PaymentTransaction) -> Unit) -> Unit,
    onVerifyPaymentCallback: (PaymentTransaction) -> Unit,
    onMarkDelivered: (String) -> Unit,
    onConfirmCompletion: (SecurityOrder) -> Unit,
    onCancelOrder: (String, String) -> Unit,
    onDisputeOrder: (String, String) -> Unit,
    onRateOrder: (SecurityOrder, SecurityProvider?, Int, String) -> Unit,
    onSendMessage: (SecurityOrder, String) -> Unit
) {
    var activeChatOrder by remember { mutableStateOf<SecurityOrder?>(null) }
    var quoteTargetOrder by remember { mutableStateOf<SecurityOrder?>(null) }
    var paymentOrder by remember { mutableStateOf<SecurityOrder?>(null) }
    var pendingPaymentTx by remember { mutableStateOf<PaymentTransaction?>(null) }
    var receiptToShow by remember { mutableStateOf<PaymentTransaction?>(null) }
    var ratingTargetOrder by remember { mutableStateOf<SecurityOrder?>(null) }
    var cancelOrDisputeTarget by remember { mutableStateOf<Pair<SecurityOrder, Boolean>?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(OffWhite)
    ) {
        Surface(color = PureWhite, shadowElevation = 1.dp, modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = if (isProviderMode) {
                        SjsStrings.t(lang, "Maombi na Oda za Wateja", "Incoming Provider Orders")
                    } else {
                        SjsStrings.t(lang, "Oda Zangu & Ufuatiliaji", "My Security Orders & Tracking")
                    },
                    style = MaterialTheme.typography.titleLarge,
                    color = NavyDeep
                )
                Text(
                    text = SjsStrings.t(
                        lang,
                        "Hatua 10 za mzunguko wa oda hadi kukamilika na kamisheni (5%)",
                        "10-step order lifecycle from quotation & Airtel Money to completion"
                    ),
                    style = MaterialTheme.typography.bodySmall,
                    color = SlateGrey
                )
            }
        }

        when (ordersState) {
            is UiState.Loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = OrangeBrand)
            }
            is UiState.Error -> Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                Text(ordersState.message, color = ErrorRed)
            }
            is UiState.Success -> {
                val orders = ordersState.data
                if (orders.isEmpty()) {
                    Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Filled.Assignment, contentDescription = null, tint = SlateGrey, modifier = Modifier.size(48.dp))
                            Text(
                                text = SjsStrings.t(lang, "Bado hakuna oda zozote.", "No orders yet."),
                                style = MaterialTheme.typography.titleMedium,
                                color = CharcoalGrey
                            )
                        }
                    }
                } else {
                    LazyColumn(
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(orders, key = { it.id }) { order ->
                            val matchingPayment = payments.firstOrNull { it.orderId == order.id }
                            OrderCard(
                                order = order,
                                lang = lang,
                                isProviderView = isProviderMode && order.providerOwnerId == currentUserId,
                                matchingPayment = matchingPayment,
                                isBusy = isBusy,
                                onChat = { activeChatOrder = order },
                                onMarkReceived = { onMarkReceived(order.id) },
                                onOpenQuoteDialog = { quoteTargetOrder = order },
                                onAcceptQuote = { onAcceptQuotation(order.id) },
                                onOpenPayment = {
                                    pendingPaymentTx = matchingPayment?.takeIf { it.statusEnum() == PaymentStatus.PENDING_CALLBACK }
                                    paymentOrder = order
                                },
                                onViewReceipt = { matchingPayment?.let { receiptToShow = it } },
                                onMarkDelivered = { onMarkDelivered(order.id) },
                                onConfirmCompletion = { onConfirmCompletion(order) },
                                onOpenRate = { ratingTargetOrder = order },
                                onOpenCancel = { cancelOrDisputeTarget = order to false },
                                onOpenDispute = { cancelOrDisputeTarget = order to true }
                            )
                        }
                    }
                }
            }
        }
    }

    activeChatOrder?.let { order ->
        OrderChatDialog(
            order = order,
            lang = lang,
            currentUserId = currentUserId,
            messagesFlow = observeMessages(order.id),
            onSend = { text -> onSendMessage(order, text) },
            onDismiss = { activeChatOrder = null }
        )
    }

    quoteTargetOrder?.let { order ->
        QuotationSubmitDialog(
            lang = lang,
            order = order,
            isBusy = isBusy,
            onSubmit = { amount, notes ->
                onSubmitQuotation(order.id, amount, notes)
                quoteTargetOrder = null
            },
            onDismiss = { quoteTargetOrder = null }
        )
    }

    paymentOrder?.let { order ->
        AirtelPaymentDialog(
            lang = lang,
            title = SjsStrings.t(lang, "Lipa kwa Airtel Money", "Pay via Airtel Money"),
            amountTzs = order.quotedAmountTzs,
            defaultPhone = userProfile?.phone ?: order.customerPhone,
            pendingPayment = pendingPaymentTx,
            isBusy = isBusy,
            onInitiate = { phone ->
                onInitiatePayment(order, phone) { createdTx ->
                    pendingPaymentTx = createdTx
                }
            },
            onVerifySandboxCallback = { tx ->
                onVerifyPaymentCallback(tx)
                paymentOrder = null
                pendingPaymentTx = null
            },
            onDismiss = {
                paymentOrder = null
                pendingPaymentTx = null
            }
        )
    }

    receiptToShow?.let { tx ->
        DigitalReceiptDialog(payment = tx, lang = lang, onDismiss = { receiptToShow = null })
    }

    ratingTargetOrder?.let { order ->
        val prov = providers.firstOrNull { it.id == order.providerId }
        RateOrderDialog(
            lang = lang,
            onSubmit = { stars, comment ->
                onRateOrder(order, prov, stars, comment)
                ratingTargetOrder = null
            },
            onDismiss = { ratingTargetOrder = null }
        )
    }

    cancelOrDisputeTarget?.let { (order, isDispute) ->
        ReasonInputDialog(
            title = if (isDispute) SjsStrings.t(lang, "Fungua Mgogoro", "Open Dispute") else SjsStrings.t(lang, "Ghairi Oda", "Cancel Order"),
            label = SjsStrings.t(lang, "Sababu", "Reason"),
            onConfirm = { reason ->
                if (isDispute) onDisputeOrder(order.id, reason) else onCancelOrder(order.id, reason)
                cancelOrDisputeTarget = null
            },
            onDismiss = { cancelOrDisputeTarget = null }
        )
    }
}

@Composable
private fun OrderCard(
    order: SecurityOrder,
    lang: AppLang,
    isProviderView: Boolean,
    matchingPayment: PaymentTransaction?,
    isBusy: Boolean,
    onChat: () -> Unit,
    onMarkReceived: () -> Unit,
    onOpenQuoteDialog: () -> Unit,
    onAcceptQuote: () -> Unit,
    onOpenPayment: () -> Unit,
    onViewReceipt: () -> Unit,
    onMarkDelivered: () -> Unit,
    onConfirmCompletion: () -> Unit,
    onOpenRate: () -> Unit,
    onOpenCancel: () -> Unit,
    onOpenDispute: () -> Unit
) {
    val st = order.statusEnum()
    Card(
        colors = CardDefaults.cardColors(containerColor = PureWhite),
        shape = RoundedCornerShape(18.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth().testTag("order_card_${order.id}")
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(order.serviceTitle, style = MaterialTheme.typography.titleMedium, color = NavyDeep)
                    Text(
                        text = if (isProviderView) "${order.customerName} • ${order.location}" else "${order.providerName} • ${order.location}",
                        style = MaterialTheme.typography.bodySmall,
                        color = SlateGrey
                    )
                }
                if (order.quotedAmountTzs > 0L) {
                    Text(TzsFormatter.format(order.quotedAmountTzs), style = MaterialTheme.typography.titleSmall, color = OrangeBrand)
                }
            }

            OrderLifecycleStepper(status = st, lang = lang)

            Text(order.requirementDescription, style = MaterialTheme.typography.bodySmall, color = CharcoalGrey)

            if (!order.quotationNotes.isNullOrBlank()) {
                Surface(color = SurfaceVariantLight, shape = RoundedCornerShape(8.dp)) {
                    Text(
                        text = "${SjsStrings.t(lang, "Maelezo ya Nukuu", "Quote Notes")}: ${order.quotationNotes}",
                        style = MaterialTheme.typography.bodySmall,
                        color = NavyDeep,
                        modifier = Modifier.padding(8.dp)
                    )
                }
            }

            if (order.attachmentPreviews.isNotEmpty()) {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(order.attachmentPreviews) { img ->
                        Base64Image(
                            base64 = img,
                            contentDescription = "Requirement photo",
                            modifier = Modifier.size(64.dp).clip(RoundedCornerShape(8.dp))
                        )
                    }
                }
            }

            if (order.commissionAmountTzs > 0L) {
                Text(
                    text = "${SjsStrings.t(lang, "Kamisheni ya Smart Jones (5%)", "Platform Commission (5%)")}: ${TzsFormatter.format(order.commissionAmountTzs)}",
                    style = MaterialTheme.typography.labelSmall,
                    color = VerifiedGreen
                )
            }

            // Action bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(onClick = onChat) {
                    Icon(Icons.AutoMirrored.Filled.Chat, null, Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(SjsStrings.t(lang, "Chati", "Chat"))
                }

                if (isProviderView) {
                    when (st) {
                        OrderStatus.REQUESTED -> {
                            Button(onClick = onMarkReceived, enabled = !isBusy, colors = ButtonDefaults.buttonColors(containerColor = NavyDeep)) {
                                Text(SjsStrings.t(lang, "Pokea", "Accept Request"))
                            }
                            Button(onClick = onOpenQuoteDialog, enabled = !isBusy, colors = ButtonDefaults.buttonColors(containerColor = OrangeBrand)) {
                                Text(SjsStrings.t(lang, "Tuma Nukuu", "Quote"))
                            }
                        }
                        OrderStatus.PROVIDER_RECEIVED -> {
                            Button(onClick = onOpenQuoteDialog, enabled = !isBusy, colors = ButtonDefaults.buttonColors(containerColor = OrangeBrand)) {
                                Text(SjsStrings.t(lang, "Tuma Nukuu (TZS)", "Submit Quote"))
                            }
                        }
                        OrderStatus.PAYMENT_CONFIRMED -> {
                            Button(onClick = onMarkDelivered, enabled = !isBusy, colors = ButtonDefaults.buttonColors(containerColor = VerifiedGreen)) {
                                Text(SjsStrings.t(lang, "Kamilisha Huduma", "Mark Delivered"))
                            }
                        }
                        else -> {}
                    }
                } else {
                    when (st) {
                        OrderStatus.QUOTATION_SUBMITTED -> {
                            Button(onClick = onAcceptQuote, enabled = !isBusy, colors = ButtonDefaults.buttonColors(containerColor = OrangeBrand)) {
                                Text(SjsStrings.t(lang, "Kubali Nukuu", "Accept Quote"))
                            }
                        }
                        OrderStatus.QUOTATION_ACCEPTED, OrderStatus.PAYMENT_INITIATED -> {
                            Button(onClick = onOpenPayment, enabled = !isBusy, colors = ButtonDefaults.buttonColors(containerColor = OrangeBrand)) {
                                Text(
                                    if (st == OrderStatus.PAYMENT_INITIATED)
                                        SjsStrings.t(lang, "Thibitisha Malipo", "Verify Payment")
                                    else
                                        SjsStrings.t(lang, "Lipa Airtel Money", "Pay Airtel Money")
                                )
                            }
                        }
                        OrderStatus.SERVICE_DELIVERED -> {
                            Button(onClick = onConfirmCompletion, enabled = !isBusy, colors = ButtonDefaults.buttonColors(containerColor = VerifiedGreen)) {
                                Text(SjsStrings.t(lang, "Thibitisha Kukamilika", "Confirm Completion"))
                            }
                        }
                        OrderStatus.CLOSED -> {
                            if (order.ratingStars == null) {
                                Button(onClick = onOpenRate, colors = ButtonDefaults.buttonColors(containerColor = OrangeBrand)) {
                                    Text(SjsStrings.t(lang, "Toa Nyota", "Rate"))
                                }
                            }
                        }
                        else -> {}
                    }
                }

                if (matchingPayment?.statusEnum() == PaymentStatus.VERIFIED) {
                    TextButton(onClick = onViewReceipt) {
                        Text(SjsStrings.t(lang, "Risiti", "Receipt"))
                    }
                }
            }

            if (st != OrderStatus.CLOSED && st != OrderStatus.CANCELLED && st != OrderStatus.DISPUTED) {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    if (st.stepIndex < OrderStatus.PAYMENT_CONFIRMED.stepIndex) {
                        TextButton(onClick = onOpenCancel) {
                            Text(SjsStrings.t(lang, "Ghairi Oda", "Cancel"), color = ErrorRed)
                        }
                    } else if (!isProviderView) {
                        TextButton(onClick = onOpenDispute) {
                            Text(SjsStrings.t(lang, "Fungua Mgogoro", "Open Dispute"), color = WarningAmber)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun QuotationSubmitDialog(
    lang: AppLang,
    order: SecurityOrder,
    isBusy: Boolean,
    onSubmit: (Long, String) -> Unit,
    onDismiss: () -> Unit
) {
    var amountStr by remember { mutableStateOf(if (order.quotedAmountTzs > 0) order.quotedAmountTzs.toString() else "") }
    var notes by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(SjsStrings.t(lang, "Tuma Nukuu ya Bei (TZS)", "Submit Quotation (TZS)")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = amountStr,
                    onValueChange = { amountStr = it.filter { ch -> ch.isDigit() } },
                    label = { Text("Bei (TZS)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text(SjsStrings.t(lang, "Maelezo ya Nukuu", "Breakdown Notes")) },
                    minLines = 2,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            val amount = amountStr.toLongOrNull() ?: 0L
            Button(
                onClick = { onSubmit(amount, notes) },
                enabled = !isBusy && amount >= 1000L,
                colors = ButtonDefaults.buttonColors(containerColor = OrangeBrand)
            ) {
                Text(SjsStrings.t(lang, "Tuma", "Send"))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(SjsStrings.t(lang, "Funga", "Close")) }
        }
    )
}

@Composable
private fun OrderChatDialog(
    order: SecurityOrder,
    lang: AppLang,
    currentUserId: String,
    messagesFlow: Flow<List<OrderMessage>>,
    onSend: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val messages by messagesFlow.collectAsStateWithLifecycle(initialValue = emptyList())
    var input by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("${SjsStrings.t(lang, "Chati", "Chat")} • ${order.serviceTitle}") },
        text = {
            Column(modifier = Modifier.fillMaxWidth().heightIn(min = 240.dp, max = 360.dp)) {
                LazyColumn(
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    if (messages.isEmpty()) {
                        item {
                            Text(
                                text = SjsStrings.t(lang, "Anza mazungumzo kuhusu oda hii.", "Start chatting about this security order."),
                                style = MaterialTheme.typography.bodySmall,
                                color = SlateGrey
                            )
                        }
                    } else {
                        items(messages, key = { it.id }) { msg ->
                            val mine = msg.senderId == currentUserId
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start
                            ) {
                                Surface(
                                    color = if (mine) NavyDeep else SurfaceVariantLight,
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Text(
                                            msg.senderName,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = if (mine) OrangeBright else SlateGrey
                                        )
                                        Text(
                                            msg.text,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = if (mine) PureWhite else DarkGrey
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(
                        value = input,
                        onValueChange = { input = it },
                        placeholder = { Text(SjsStrings.t(lang, "Andika ujumbe...", "Type message...")) },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(
                        onClick = {
                            if (input.isNotBlank()) {
                                onSend(input)
                                input = ""
                            }
                        }
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send", tint = OrangeBrand)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text(SjsStrings.t(lang, "Funga", "Close")) }
        }
    )
}

@Composable
private fun RateOrderDialog(
    lang: AppLang,
    onSubmit: (Int, String) -> Unit,
    onDismiss: () -> Unit
) {
    var stars by remember { mutableIntStateOf(5) }
    var comment by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(SjsStrings.t(lang, "Kadiria Huduma", "Rate Completed Service")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    (1..5).forEach { s ->
                        IconButton(onClick = { stars = s }) {
                            Icon(
                                imageVector = if (s <= stars) Icons.Filled.Star else Icons.Filled.StarBorder,
                                contentDescription = "$s stars",
                                tint = OrangeBrand
                            )
                        }
                    }
                }
                OutlinedTextField(
                    value = comment,
                    onValueChange = { comment = it },
                    label = { Text(SjsStrings.t(lang, "Maoni yako", "Your feedback")) },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(onClick = { onSubmit(stars, comment) }, colors = ButtonDefaults.buttonColors(containerColor = OrangeBrand)) {
                Text(SjsStrings.t(lang, "Tuma", "Submit"))
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(SjsStrings.t(lang, "Ghairi", "Cancel")) } }
    )
}

@Composable
private fun ReasonInputDialog(
    title: String,
    label: String,
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var reason by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = reason,
                onValueChange = { reason = it },
                label = { Text(label) },
                minLines = 2,
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = {
            Button(onClick = { onConfirm(reason) }, colors = ButtonDefaults.buttonColors(containerColor = ErrorRed)) {
                Text("OK")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
