package com.example.ui.screens

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.local.BookingEntity
import com.example.data.local.ClientEntity
import com.example.data.local.PaymentEntity
import com.example.data.model.BookingStatus
import com.example.data.model.PaymentMethod
import com.example.data.model.TripType
import com.example.ui.components.DatePickerTextField
import com.example.ui.theme.GoldSecondary
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.StatusCancelledFg
import com.example.utils.DateFormatters

@Composable
fun EditClientDialog(
    client: ClientEntity,
    errorMessage: String?,
    onSave: (ClientEntity) -> Unit,
    onDismiss: () -> Unit,
) {
    var code by remember { mutableStateOf(client.clientCode) }
    var fullName by remember { mutableStateOf(client.fullName) }
    var phone by remember { mutableStateOf(client.phone) }
    var whatsapp by remember { mutableStateOf(client.whatsapp) }
    var nationalId by remember { mutableStateOf(client.nationalId) }
    var passport by remember { mutableStateOf(client.passportNumber) }
    var birthDate by remember { mutableStateOf(client.birthDate) }
    var notes by remember { mutableStateOf(client.notes) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تعديل بيانات العميل", style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                if (!errorMessage.isNullOrBlank()) {
                    Text(
                        text = errorMessage,
                        color = StatusCancelledFg,
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Bold,
                    )
                }
                OutlinedTextField(
                    value = code,
                    onValueChange = { code = it },
                    label = { Text("كود العميل (يتحقق من عدم التكرار)") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("edit_client_code_input"),
                )
                OutlinedTextField(
                    value = fullName,
                    onValueChange = { fullName = it },
                    label = { Text("اسم العميل بالكامل") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("رقم الهاتف") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = whatsapp,
                    onValueChange = { whatsapp = it },
                    label = { Text("رقم الواتساب") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = nationalId,
                    onValueChange = { nationalId = it },
                    label = { Text("رقم البطاقة الشخصية") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = passport,
                    onValueChange = { passport = it },
                    label = { Text("رقم جواز السفر") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                DatePickerTextField(
                    label = "تاريخ الميلاد",
                    value = birthDate,
                    onValueSelected = { birthDate = it },
                )
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("ملاحظات العميل") },
                    minLines = 2,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSave(
                        client.copy(
                            clientCode = code.trim(),
                            fullName = fullName.trim(),
                            phone = phone.trim(),
                            whatsapp = whatsapp.trim(),
                            nationalId = nationalId.trim(),
                            passportNumber = passport.trim(),
                            birthDate = birthDate.trim(),
                            notes = notes.trim(),
                        )
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary),
                modifier = Modifier.testTag("save_edit_client_button"),
            ) {
                Text("حفظ التعديلات")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        },
    )
}

@Composable
fun EditBookingDialog(
    booking: BookingEntity,
    onSave: (BookingEntity) -> Unit,
    onDismiss: () -> Unit,
) {
    var tripDate by remember { mutableStateOf(booking.tripDate) }
    var returnDate by remember { mutableStateOf(booking.returnDate) }
    var tripType by remember { mutableStateOf(booking.tripType) }
    var customLabel by remember { mutableStateOf(booking.customTripLabel) }
    var company by remember { mutableStateOf(booking.companyName) }
    var makkah by remember { mutableStateOf(booking.makkahHotel) }
    var madinah by remember { mutableStateOf(booking.madinahHotel) }
    var totalPrice by remember { mutableStateOf(booking.totalPrice.toString()) }
    var extraAmount by remember { mutableStateOf(booking.extraAmount.toString()) }
    var costAmount by remember { mutableStateOf(booking.costAmount.toString()) }
    var status by remember { mutableStateOf(booking.status) }
    var notes by remember { mutableStateOf(booking.notes) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تعديل بيانات الرحلة والحجز", style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                DatePickerTextField("تاريخ الرحلة", tripDate, { tripDate = it })
                DatePickerTextField("تاريخ العودة", returnDate, { returnDate = it })

                Text("نوع البرنامج:", style = MaterialTheme.typography.labelMedium)
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    TripType.entries.forEach { t ->
                        FilterChip(
                            selected = tripType == t,
                            onClick = { tripType = t },
                            label = { Text(t.arabicLabel) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = NavyPrimary,
                                selectedLabelColor = GoldSecondary,
                            ),
                        )
                    }
                }
                if (tripType == TripType.CUSTOM) {
                    OutlinedTextField(
                        value = customLabel,
                        onValueChange = { customLabel = it },
                        label = { Text("وصف البرنامج المخصص") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }

                OutlinedTextField(
                    value = company,
                    onValueChange = { company = it },
                    label = { Text("اسم شركة السياحة") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = makkah,
                    onValueChange = { makkah = it },
                    label = { Text("فندق مكة") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = madinah,
                    onValueChange = { madinah = it },
                    label = { Text("فندق المدينة") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = totalPrice,
                    onValueChange = { totalPrice = it },
                    label = { Text("سعر الرحلة الإجمالي") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = extraAmount,
                    onValueChange = { extraAmount = it },
                    label = { Text("المبالغ الإضافية") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = costAmount,
                    onValueChange = { costAmount = it },
                    label = { Text("التكلفة الفعلية (اختياري)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )

                Text("حالة الحجز:", style = MaterialTheme.typography.labelMedium)
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    BookingStatus.entries.forEach { st ->
                        FilterChip(
                            selected = status == st,
                            onClick = { status = st },
                            label = { Text(st.arabicLabel) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = NavyPrimary,
                                selectedLabelColor = GoldSecondary,
                            ),
                        )
                    }
                }
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("ملاحظات") },
                    minLines = 2,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSave(
                        booking.copy(
                            tripDate = tripDate.trim(),
                            returnDate = returnDate.trim(),
                            tripType = tripType,
                            customTripLabel = if (tripType == TripType.CUSTOM) customLabel.trim() else "",
                            companyName = company.trim(),
                            makkahHotel = makkah.trim(),
                            madinahHotel = madinah.trim(),
                            totalPrice = totalPrice.toDoubleOrNull() ?: booking.totalPrice,
                            extraAmount = extraAmount.toDoubleOrNull() ?: 0.0,
                            costAmount = costAmount.toDoubleOrNull() ?: 0.0,
                            status = status,
                            notes = notes.trim(),
                        )
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary),
            ) {
                Text("حفظ التعديلات")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        },
    )
}

@Composable
fun PaymentEditorDialog(
    bookingId: Long,
    existingPayment: PaymentEntity?,
    onSave: (PaymentEntity) -> Unit,
    onDismiss: () -> Unit,
) {
    var amountStr by remember { mutableStateOf(existingPayment?.amount?.toString() ?: "") }
    var dateStr by remember { mutableStateOf(existingPayment?.paymentDate ?: DateFormatters.todayIso()) }
    var method by remember { mutableStateOf(existingPayment?.paymentMethod ?: PaymentMethod.CASH) }
    var notes by remember { mutableStateOf(existingPayment?.notes ?: "") }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (existingPayment == null) "إضافة دفعة جديدة" else "تعديل الدفعة",
                style = MaterialTheme.typography.titleLarge,
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (errorMsg != null) {
                    Text(errorMsg!!, color = StatusCancelledFg, style = MaterialTheme.typography.bodySmall)
                }
                OutlinedTextField(
                    value = amountStr,
                    onValueChange = { amountStr = it },
                    label = { Text("قيمة الدفعة *") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("payment_amount_input"),
                )
                DatePickerTextField(
                    label = "تاريخ الدفعة",
                    value = dateStr,
                    onValueSelected = { dateStr = it },
                    testTag = "payment_date_input",
                )
                Text("طريقة الدفع:", style = MaterialTheme.typography.labelMedium)
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    PaymentMethod.entries.forEach { pm ->
                        FilterChip(
                            selected = method == pm,
                            onClick = { method = pm },
                            label = { Text(pm.arabicLabel) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = NavyPrimary,
                                selectedLabelColor = GoldSecondary,
                            ),
                            modifier = Modifier.testTag("payment_method_${pm.name}"),
                        )
                    }
                }
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("ملاحظات الدفعة") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("payment_notes_input"),
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amount = amountStr.toDoubleOrNull()
                    if (amount == null || amount <= 0.0) {
                        errorMsg = "يرجى إدخال مبلغ صحيح أكبر من صفر"
                        return@Button
                    }
                    val payment = existingPayment?.copy(
                        amount = amount,
                        paymentDate = dateStr.trim(),
                        paymentMethod = method,
                        notes = notes.trim(),
                    ) ?: PaymentEntity(
                        bookingId = bookingId,
                        amount = amount,
                        paymentDate = dateStr.trim(),
                        paymentMethod = method,
                        isDeposit = false,
                        notes = notes.trim(),
                    )
                    onSave(payment)
                },
                colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary),
                modifier = Modifier.testTag("save_payment_button"),
            ) {
                Text("حفظ الدفعة")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        },
    )
}
