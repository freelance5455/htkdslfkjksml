package com.example.ui.screens

import android.content.ActivityNotFoundException
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.data.model.SubscriptionTier
import com.example.data.model.UserSubscription
import com.example.data.remote.CardCheckoutSession
import com.example.data.remote.StripeCheckoutSessionResult
import com.example.data.remote.UpiCheckoutSession
import com.example.data.remote.UpiHandleOption
import com.example.data.remote.UpiPaymentService

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DirectStripeSubscriptionCard(
    subscription: UserSubscription,
    configuredStripeKey: String,
    isProcessingBilling: Boolean,
    activeCheckoutSession: StripeCheckoutSessionResult?,
    activeUpiSession: UpiCheckoutSession?,
    activeCardSession: CardCheckoutSession?,
    onSaveStripeKey: (String) -> Unit,
    onStartUpiCheckout: (SubscriptionTier) -> Unit,
    onSelectUpiHandle: (UpiHandleOption) -> Unit,
    onUpiIntentResponse: (String?) -> Unit,
    onVerifyUpiUtr: (String, SubscriptionTier) -> Unit,
    onDismissUpiModal: () -> Unit,
    onStartCardCheckout: (SubscriptionTier) -> Unit,
    onSelectCardSettlementHandle: (UpiHandleOption) -> Unit,
    onAuthorizeCardDetails: (String, String, String, String) -> Boolean,
    onCardSettlementIntentResponse: (String?) -> Unit,
    onVerifyCardOtpOrRrn: (String, SubscriptionTier) -> Unit,
    onDismissCardModal: () -> Unit,
    onStartStripeCheckout: (SubscriptionTier) -> Unit,
    onVerifyCheckoutSession: (String, SubscriptionTier) -> Unit,
    onCancelSubscription: () -> Unit,
    onDismissCheckoutModal: () -> Unit
) {
    val clipboardManager = LocalClipboardManager.current

    // UPI Transaction ID fallback state (shown when automatic UPI verification fails)
    var modalUpiTxnIdInput by rememberSaveable { mutableStateOf("") }
    var showCardFallbackTxnBox by rememberSaveable { mutableStateOf(false) }
    var quickUnlockTxnIdInput by rememberSaveable { mutableStateOf("") }
    var quickUnlockSelectedTierId by rememberSaveable { mutableStateOf(SubscriptionTier.PRO_MONTHLY.planId) }

    // Card Payment state
    var cardholderName by rememberSaveable { mutableStateOf("") }
    var cardNumberDigits by rememberSaveable { mutableStateOf("") }
    var cardExpiryDigits by rememberSaveable { mutableStateOf("") }
    var cardCvvDigits by rememberSaveable { mutableStateOf("") }
    var cardSettlementNote by rememberSaveable { mutableStateOf<String?>(null) }

    val upiIntentLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val responseStr = result.data?.getStringExtra("response")
            ?: result.data?.dataString
        onUpiIntentResponse(responseStr)
    }

    val cardSettlementLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val responseStr = result.data?.getStringExtra("response")
            ?: result.data?.dataString
        onCardSettlementIntentResponse(responseStr)
    }

    val progressFraction = remember(subscription.monthlyGenerationsUsed, subscription.monthlyGenerationLimit) {
        val limit = subscription.monthlyGenerationLimit.coerceAtLeast(1)
        (subscription.monthlyGenerationsUsed.toFloat() / limit.toFloat()).coerceIn(0f, 1f)
    }

    // 1. Direct Card Payment Modal (Instant Unlock or RuPay Card-on-UPI — Never Shows Phone Number)
    if (activeCardSession != null) {
        val detectedNetwork = remember(cardNumberDigits) {
            UpiPaymentService.detectCardNetwork(cardNumberDigits)
        }
        AlertDialog(
            onDismissRequest = onDismissCardModal,
            icon = {
                Icon(
                    imageVector = Icons.Default.CreditCard,
                    contentDescription = "Direct Card Payment",
                    tint = MaterialTheme.colorScheme.primary
                )
            },
            title = {
                Text(
                    text = "Card Checkout — ${activeCardSession.tier.inrPriceDisplay}",
                    style = MaterialTheme.typography.titleMedium
                )
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Lock,
                                    contentDescription = "Protected Merchant Settlement",
                                    tint = MaterialTheme.colorScheme.tertiary,
                                    modifier = Modifier.size(15.dp)
                                )
                                Text(
                                    text = "Merchant: OmniPrompt Studio Official Billing",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                            Text(
                                text = "Settlement: Protected Merchant Account (Hidden Recipient ID)",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "Plan: ${activeCardSession.tier.displayName} (${activeCardSession.tier.monthlyGenerationLimit} syntheses/mo)",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = "Order ID: ${activeCardSession.orderId}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Text(
                        text = "Enter Debit / Credit Card Details ($detectedNetwork):",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    OutlinedTextField(
                        value = cardholderName,
                        onValueChange = { cardholderName = it.take(60) },
                        label = { Text("Cardholder Name") },
                        placeholder = { Text("Name on Card") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("cardholder_name_input"),
                        shape = RoundedCornerShape(10.dp)
                    )

                    OutlinedTextField(
                        value = cardNumberDigits,
                        onValueChange = { input ->
                            cardNumberDigits = input.filter { it.isDigit() }.take(19)
                        },
                        label = { Text("Card Number ($detectedNetwork)") },
                        placeholder = { Text("16-digit RuPay, Visa, or Mastercard number") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("card_number_input"),
                        shape = RoundedCornerShape(10.dp)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = cardExpiryDigits,
                            onValueChange = { input ->
                                cardExpiryDigits = input.filter { it.isDigit() }.take(4)
                            },
                            label = { Text("Expiry (MMYY)") },
                            placeholder = { Text("0829") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("card_expiry_input"),
                            shape = RoundedCornerShape(10.dp)
                        )

                        OutlinedTextField(
                            value = cardCvvDigits,
                            onValueChange = { input ->
                                cardCvvDigits = input.filter { it.isDigit() }.take(4)
                            },
                            label = { Text("CVV") },
                            placeholder = { Text("•••") },
                            singleLine = true,
                            visualTransformation = PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("card_cvv_input"),
                            shape = RoundedCornerShape(10.dp)
                        )
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.25f))

                    Text(
                        text = "Optional: Pay with RuPay Card via UPI App",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        UpiHandleOption.entries.forEach { handle ->
                            FilterChip(
                                selected = activeCardSession.selectedHandle == handle,
                                onClick = { onSelectCardSettlementHandle(handle) },
                                label = {
                                    Text(
                                        text = handle.displayLabel,
                                        style = MaterialTheme.typography.labelSmall
                                    )
                                },
                                modifier = Modifier.testTag("card_handle_chip_${handle.id.lowercase()}")
                            )
                        }
                    }

                    OutlinedButton(
                        onClick = {
                            try {
                                val settlementIntent = UpiPaymentService.buildProtectedCardToMerchantIntent(
                                    session = activeCardSession,
                                    handle = activeCardSession.selectedHandle
                                )
                                cardSettlementLauncher.launch(settlementIntent)
                            } catch (_: ActivityNotFoundException) {
                                cardSettlementNote = "No external RuPay UPI app found. Tap 'Pay & Unlock Premium Now' below to authorize your card directly."
                            } catch (_: Exception) {
                                cardSettlementNote = "Tap 'Pay & Unlock Premium Now' below to authorize your card directly."
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("launch_rupay_card_app_button"),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AccountBalanceWallet,
                            contentDescription = "RuPay Card on UPI App",
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Open RuPay Card in UPI App")
                    }

                    if (!cardSettlementNote.isNullOrBlank()) {
                        Text(
                            text = cardSettlementNote.orEmpty(),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onAuthorizeCardDetails(
                            cardholderName,
                            cardNumberDigits,
                            cardExpiryDigits,
                            cardCvvDigits
                        )
                    },
                    enabled = !isProcessingBilling,
                    modifier = Modifier.testTag("authorize_card_button")
                ) {
                    if (isProcessingBilling) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(16.dp),
                            strokeWidth = 2.dp,
                            color = MaterialTheme.colorScheme.onPrimary
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                    } else {
                        Icon(
                            imageVector = Icons.Default.LockOpen,
                            contentDescription = "Pay and Unlock Premium",
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                    }
                    Text("Pay & Unlock Premium Now")
                }
            },
            dismissButton = {
                TextButton(onClick = onDismissCardModal) {
                    Text("Close")
                }
            }
        )
    }

    // 2. UPI Instant Checkout Modal (Attempts Auto-Verification First; Shows Paste Transaction ID When Verification Fails)
    if (activeUpiSession != null) {
        AlertDialog(
            onDismissRequest = onDismissUpiModal,
            icon = {
                Icon(
                    imageVector = Icons.Default.AccountBalanceWallet,
                    contentDescription = "UPI Instant Checkout",
                    tint = MaterialTheme.colorScheme.primary
                )
            },
            title = {
                Text(
                    text = "UPI Payment — ${activeUpiSession.tier.inrPriceDisplay}",
                    style = MaterialTheme.typography.titleMedium
                )
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Lock,
                                    contentDescription = "Protected Merchant",
                                    tint = MaterialTheme.colorScheme.tertiary,
                                    modifier = Modifier.size(15.dp)
                                )
                                Text(
                                    text = "Merchant: OmniPrompt Studio Official Billing",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                            Text(
                                text = "Recipient ID: Protected Merchant Account (Number Hidden)",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "Plan: ${activeUpiSession.tier.displayName} (${activeUpiSession.tier.monthlyGenerationLimit} syntheses/mo)",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = "Order ID: ${activeUpiSession.orderId}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Text(
                        text = "Select UPI App Routing & Pay ${activeUpiSession.tier.inrPriceDisplay}:",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        UpiHandleOption.entries.forEach { handle ->
                            FilterChip(
                                selected = activeUpiSession.selectedHandle == handle,
                                onClick = { onSelectUpiHandle(handle) },
                                label = {
                                    Text(
                                        text = handle.displayLabel,
                                        style = MaterialTheme.typography.labelSmall
                                    )
                                },
                                modifier = Modifier.testTag("upi_handle_chip_${handle.id.lowercase()}")
                            )
                        }
                    }

                    Button(
                        onClick = {
                            try {
                                val upiIntent = UpiPaymentService.buildProtectedUpiPaymentIntent(
                                    session = activeUpiSession,
                                    handle = activeUpiSession.selectedHandle
                                )
                                upiIntentLauncher.launch(upiIntent)
                            } catch (_: ActivityNotFoundException) {
                                // Trigger automatic verification failure so the Paste Transaction ID box appears
                                onUpiIntentResponse(null)
                            } catch (_: Exception) {
                                onUpiIntentResponse(null)
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("launch_upi_app_button"),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AccountBalanceWallet,
                            contentDescription = "Open UPI App",
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Pay via UPI App (${activeUpiSession.tier.inrPriceDisplay})")
                    }

                    if (!activeUpiSession.verificationFailed) {
                        TextButton(
                            onClick = { onUpiIntentResponse(null) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("trigger_upi_manual_fallback_button")
                        ) {
                            Text(
                                text = "App failed to verify payment? Paste Transaction ID",
                                style = MaterialTheme.typography.labelSmall
                            )
                        }
                    }

                    // Shown ONLY when automatic UPI verification fails
                    if (activeUpiSession.verificationFailed) {
                        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.25f))

                        Surface(
                            color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.45f),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(10.dp),
                                verticalAlignment = Alignment.Top,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ErrorOutline,
                                    contentDescription = "Auto-Verification Failed",
                                    tint = MaterialTheme.colorScheme.error,
                                    modifier = Modifier.size(18.dp)
                                )
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Automatic Payment Verification Failed",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = MaterialTheme.colorScheme.onErrorContainer,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = activeUpiSession.verificationErrorMessage.ifBlank {
                                            "Could not auto-verify payment from UPI app. Paste your UPI Transaction ID / 12-digit UTR below to unlock Premium Features."
                                        },
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onErrorContainer
                                    )
                                }
                            }
                        }

                        OutlinedTextField(
                            value = modalUpiTxnIdInput,
                            onValueChange = { input ->
                                modalUpiTxnIdInput = input.filter { it.isLetterOrDigit() || it == '-' }.take(45)
                            },
                            label = { Text("Paste UPI Transaction ID / 12-Digit UTR") },
                            placeholder = { Text("e.g. 430512345678 or T241101...") },
                            singleLine = true,
                            trailingIcon = {
                                IconButton(
                                    onClick = {
                                        val clip = clipboardManager.getText()?.text.orEmpty().trim()
                                        if (clip.isNotEmpty()) {
                                            modalUpiTxnIdInput = clip.filter { it.isLetterOrDigit() || it == '-' }.take(45)
                                        }
                                    },
                                    modifier = Modifier.testTag("paste_modal_upi_txn_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ContentPaste,
                                        contentDescription = "Paste Transaction ID",
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("upi_utr_input"),
                            shape = RoundedCornerShape(10.dp)
                        )
                    }
                }
            },
            confirmButton = {
                if (activeUpiSession.verificationFailed) {
                    Button(
                        onClick = {
                            onVerifyUpiUtr(modalUpiTxnIdInput, activeUpiSession.tier)
                        },
                        enabled = !isProcessingBilling && modalUpiTxnIdInput.trim().length >= 10,
                        modifier = Modifier.testTag("verify_upi_utr_button")
                    ) {
                        if (isProcessingBilling) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                strokeWidth = 2.dp,
                                color = MaterialTheme.colorScheme.onPrimary
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                        } else {
                            Icon(
                                imageVector = Icons.Default.LockOpen,
                                contentDescription = "Unlock Premium",
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                        }
                        Text("Verify Transaction ID & Unlock")
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = onDismissUpiModal) {
                    Text("Close")
                }
            }
        )
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = 1.dp,
                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.35f),
                shape = RoundedCornerShape(18.dp)
            )
            .testTag("direct_stripe_subscription_card"),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Default.AccountBalanceWallet,
                        contentDescription = "UPI & Card Subscription Models",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "Subscription Models (UPI & Card)",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Direct UPI & Card Settlement • Protected Merchant Account",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Surface(
                    color = if (subscription.isPaidActive) {
                        MaterialTheme.colorScheme.tertiary.copy(alpha = 0.16f)
                    } else {
                        MaterialTheme.colorScheme.primaryContainer
                    },
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = "${subscription.tier.displayName} • ${subscription.status}",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (subscription.isPaidActive) {
                            MaterialTheme.colorScheme.tertiary
                        } else {
                            MaterialTheme.colorScheme.primary
                        },
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            // Monthly Synthesis Quota Progress
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Monthly AI Synthesis Quota",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "${subscription.monthlyGenerationsUsed} / ${subscription.monthlyGenerationLimit} used",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    LinearProgressIndicator(
                        progress = { progressFraction },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp))
                    )
                    if (subscription.stripeSubscriptionId.isNotBlank()) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = "Unlocked Reference",
                                tint = MaterialTheme.colorScheme.tertiary,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = "Unlocked Ref: ${subscription.stripeSubscriptionId}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.tertiary
                            )
                        }
                    }
                }
            }

            // Subscription Tier Cards
            SubscriptionTier.entries.forEach { tier ->
                val isCurrentTier = subscription.planId == tier.planId &&
                    (tier == SubscriptionTier.FREE || subscription.isPaidActive)

                Surface(
                    color = if (isCurrentTier) {
                        MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
                    } else {
                        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
                    },
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(
                            width = 1.dp,
                            color = if (isCurrentTier) {
                                MaterialTheme.colorScheme.primary
                            } else {
                                MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)
                            },
                            shape = RoundedCornerShape(14.dp)
                        )
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = tier.displayName,
                                    style = MaterialTheme.typography.titleSmall,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${tier.inrPriceDisplay} (Direct UPI or Debit / Credit Card)",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            if (isCurrentTier) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Verified,
                                        contentDescription = "Active Plan",
                                        tint = MaterialTheme.colorScheme.tertiary,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "Active Plan",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.tertiary
                                    )
                                }
                            }
                        }

                        tier.features.forEach { feat ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.Top
                            ) {
                                Box(
                                    modifier = Modifier
                                        .padding(top = 6.dp)
                                        .size(6.dp)
                                        .clip(CircleShape)
                                        .background(MaterialTheme.colorScheme.primary)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = feat,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }

                        if (tier != SubscriptionTier.FREE && !isCurrentTier) {
                            // 1. Primary Action: UPI Payment (Auto-verifies; falls back to pasting Transaction ID on failure)
                            Button(
                                onClick = {
                                    onStartUpiCheckout(tier)
                                },
                                enabled = !isProcessingBilling,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("subscribe_upi_button_${tier.planId.lowercase()}"),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AccountBalanceWallet,
                                    contentDescription = "Pay via UPI",
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Pay via UPI App (${tier.inrPriceDisplay})")
                            }

                            // 2. Direct Debit / Credit Card Payment (Instant Unlock)
                            OutlinedButton(
                                onClick = {
                                    onStartCardCheckout(tier)
                                },
                                enabled = !isProcessingBilling,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("subscribe_card_button_${tier.planId.lowercase()}"),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CreditCard,
                                    contentDescription = "Pay with Debit or Credit Card",
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Pay with Debit / Credit Card (${tier.inrPriceDisplay})")
                            }
                        }
                    }
                }
            }

            // Fallback toggle for when UPI app fails to verify payment automatically
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "App failed to verify UPI payment?",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                TextButton(
                    onClick = { showCardFallbackTxnBox = !showCardFallbackTxnBox },
                    modifier = Modifier.testTag("toggle_upi_fallback_txn_button")
                ) {
                    Text(
                        text = if (showCardFallbackTxnBox) "Hide Fallback" else "Paste Transaction ID",
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            }

            if (showCardFallbackTxnBox) {
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.22f),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(
                            width = 1.dp,
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.35f),
                            shape = RoundedCornerShape(14.dp)
                        )
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.LockOpen,
                                contentDescription = "Fallback UPI Verification",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp)
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Fallback UPI Verification (Paste Transaction ID)",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "If the app failed to verify your UPI payment automatically, select your plan and paste your UPI Transaction ID / 12-digit UTR below.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        FlowRow(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            listOf(SubscriptionTier.PRO_MONTHLY, SubscriptionTier.ENTERPRISE_ANNUAL).forEach { paidTier ->
                                FilterChip(
                                    selected = quickUnlockSelectedTierId == paidTier.planId,
                                    onClick = { quickUnlockSelectedTierId = paidTier.planId },
                                    label = {
                                        Text(
                                            text = "${paidTier.displayName} (${paidTier.inrPriceDisplay})",
                                            style = MaterialTheme.typography.labelSmall
                                        )
                                    },
                                    modifier = Modifier.testTag("quick_unlock_tier_chip_${paidTier.planId.lowercase()}")
                                )
                            }
                        }

                        OutlinedTextField(
                            value = quickUnlockTxnIdInput,
                            onValueChange = { input ->
                                quickUnlockTxnIdInput = input.filter { it.isLetterOrDigit() || it == '-' }.take(45)
                            },
                            label = { Text("Paste UPI Transaction ID / 12-Digit UTR") },
                            placeholder = { Text("Tap paste icon or enter Transaction ID") },
                            singleLine = true,
                            trailingIcon = {
                                IconButton(
                                    onClick = {
                                        val clip = clipboardManager.getText()?.text.orEmpty().trim()
                                        if (clip.isNotEmpty()) {
                                            quickUnlockTxnIdInput = clip.filter { it.isLetterOrDigit() || it == '-' }.take(45)
                                        }
                                    },
                                    modifier = Modifier.testTag("quick_paste_upi_txn_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ContentPaste,
                                        contentDescription = "Paste from Clipboard",
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("quick_upi_txn_input"),
                            shape = RoundedCornerShape(10.dp)
                        )

                        Button(
                            onClick = {
                                val targetTier = SubscriptionTier.fromPlanId(quickUnlockSelectedTierId)
                                onVerifyUpiUtr(quickUnlockTxnIdInput, targetTier)
                            },
                            enabled = !isProcessingBilling && quickUnlockTxnIdInput.trim().length >= 10,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("quick_unlock_upi_button"),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.LockOpen,
                                contentDescription = "Unlock Premium Features",
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Verify Transaction ID & Unlock")
                        }
                    }
                }
            }
        }
    }
}
