package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.SecurityLabData
import com.example.model.AppLanguage
import com.example.ui.components.CyberCard
import com.example.ui.components.SafeLabDisclaimer
import com.example.ui.theme.CyberBackground
import com.example.ui.theme.CyberSurfaceCard
import com.example.ui.theme.CyberSurfaceElevated
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonMagenta
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.NeonRed
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun FakeLoginLabScreen(
    currentLanguage: AppLanguage,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    var dummyUsername by remember { mutableStateOf("demo.employee@cybercorp.com") }
    var dummyPassword by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }
    var selectedUrlIndex by remember { mutableIntStateOf(0) }
    var isPhishIntercepted by remember { mutableStateOf(false) }
    var interceptedCharsCount by remember { mutableIntStateOf(0) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CyberBackground)
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Safe Lab Disclaimer
        SafeLabDisclaimer(currentLanguage = currentLanguage)

        // Header
        CyberCard(borderColor = NeonMagenta.copy(alpha = 0.5f)) {
            Text(
                text = if (currentLanguage == AppLanguage.EN) "LAB 02: FAKE LOGIN & CREDENTIAL HARVESTING" else "ল্যাব ০২: নকল লগইন ও ফিশিং সচেতনতা",
                color = NeonMagenta,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 16.sp,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = if (currentLanguage == AppLanguage.EN)
                    "Interactive simulation of a deceptive corporate login portal. Enter dummy text to inspect how keyloggers, reverse proxies, and spoofed domains steal credentials."
                else
                    "একটি নকল কর্পোরেট লগইন পোর্টাল। ডামি তথ্য প্রবেশ করিয়ে দেখুন কীভাবে কি-লগার ও ক্লোন করা ওয়েবসাইটের মাধ্যমে পাসওয়ার্ড চুরি করা হয়।",
                color = TextSecondary,
                fontSize = 12.sp,
                lineHeight = 16.sp
            )
        }

        // Section: URL Spoofing Inspector
        CyberCard(borderColor = NeonAmber.copy(alpha = 0.4f)) {
            Text(
                text = if (currentLanguage == AppLanguage.EN) "Deceptive Address Bar & Domain Spoofing" else "প্রতারণামূলক অ্যাড্রেস বার ও ডোমেন স্পুফিং",
                color = NeonAmber,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = if (currentLanguage == AppLanguage.EN)
                    "Attackers register domains that look nearly identical to legitimate services. Select a technique to test the mock address bar:"
                else
                    "আক্রমণকারীরা প্রায় একই রকম দেখতে বিভ্রান্তিকর ডোমেন ব্যবহার করে। নিচের কৌশলগুলো পরীক্ষা করে দেখুন:",
                color = TextSecondary,
                fontSize = 11.sp
            )
            Spacer(modifier = Modifier.height(10.dp))

            // URL Technique Selector Pills
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                SecurityLabData.phishingUrlChecks.forEachIndexed { index, item ->
                    val isSelected = selectedUrlIndex == index
                    Surface(
                        color = if (isSelected) NeonAmber.copy(alpha = 0.2f) else CyberSurfaceElevated,
                        shape = RoundedCornerShape(8.dp),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (isSelected) NeonAmber else Color.Transparent
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { selectedUrlIndex = index }
                    ) {
                        Box(
                            modifier = Modifier.padding(vertical = 8.dp, horizontal = 4.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "Technique #${index + 1}",
                                color = if (isSelected) NeonAmber else TextSecondary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            val activeCheck = SecurityLabData.phishingUrlChecks[selectedUrlIndex]

            // Simulated Browser URL Bar
            Surface(
                color = Color(0xFF090E1A),
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF23304E)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "SSL Padlock",
                        tint = NeonGreen,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = activeCheck.fakeUrl,
                        color = NeonRed,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Legitimate comparison
            Surface(
                color = Color(0xFF14241B),
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, NeonGreen.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Legit URL",
                        tint = NeonGreen,
                        modifier = Modifier.size(16.dp)
                    )
                    Column {
                        Text(
                            text = if (currentLanguage == AppLanguage.EN) "Real Legit URL:" else "আসল বৈধ ইউআরএল:",
                            color = NeonGreen,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = activeCheck.legitUrl,
                            color = TextPrimary,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = if (currentLanguage == AppLanguage.EN) "Technique: ${activeCheck.techniqueEn}" else "কৌশল: ${activeCheck.techniqueBn}",
                color = TextSecondary,
                fontSize = 11.sp
            )
        }

        // Section: The Mock Phishing Login Portal
        CyberCard(borderColor = NeonCyan.copy(alpha = 0.4f)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(NeonCyan.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Key,
                            contentDescription = "Key",
                            tint = NeonCyan,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Text(
                        text = "TK-Secure Cloud SSO Portal",
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
                Surface(
                    color = NeonRed.copy(alpha = 0.15f),
                    shape = RoundedCornerShape(4.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, NeonRed)
                ) {
                    Text(
                        text = "MOCK PHISH",
                        color = NeonRed,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.ExtraBold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Work Email field
            Text(
                text = if (currentLanguage == AppLanguage.EN) "Work Email Address" else "কর্পোরেট ইমেইল",
                color = TextSecondary,
                fontSize = 11.sp
            )
            Spacer(modifier = Modifier.height(4.dp))
            OutlinedTextField(
                value = dummyUsername,
                onValueChange = { dummyUsername = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("dummy_username_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = NeonCyan,
                    unfocusedBorderColor = Color(0xFF283856),
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Dummy Password field with live keystroke feedback
            Text(
                text = if (currentLanguage == AppLanguage.EN) "Password (Enter DUMMY test string only)" else "পাসওয়ার্ড (শুধুমাত্র ডামি টেক্সট দিন)",
                color = TextSecondary,
                fontSize = 11.sp
            )
            Spacer(modifier = Modifier.height(4.dp))
            OutlinedTextField(
                value = dummyPassword,
                onValueChange = {
                    dummyPassword = it
                    interceptedCharsCount = it.length
                    isPhishIntercepted = false
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("dummy_password_input"),
                visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                trailingIcon = {
                    IconButton(onClick = { passwordVisible = !passwordVisible }) {
                        Icon(
                            imageVector = if (passwordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                            contentDescription = "Toggle password visibility",
                            tint = TextSecondary
                        )
                    }
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = NeonMagenta,
                    unfocusedBorderColor = Color(0xFF283856),
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                singleLine = true
            )

            // Live Keylogger Warning Bar
            Spacer(modifier = Modifier.height(8.dp))
            Surface(
                color = Color(0xFF20162B),
                shape = RoundedCornerShape(6.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, NeonPurple.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = "Keylogger Notice",
                        tint = NeonAmber,
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = if (currentLanguage == AppLanguage.EN)
                            "Live Keylogging: ${dummyPassword.length} characters tracked before submit"
                        else
                            "লাইভ কি-লগার: সাবমিট করার আগেই ${dummyPassword.length} টি অক্ষর ট্র্যাকিং সম্পন্ন",
                        color = NeonAmber,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Action Button: Intercept Phish
            Button(
                onClick = {
                    isPhishIntercepted = true
                    if (dummyPassword.isEmpty()) {
                        dummyPassword = "TestDummyPassword123!"
                        interceptedCharsCount = 22
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = NeonMagenta),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("intercept_phish_button")
            ) {
                Text(
                    text = if (currentLanguage == AppLanguage.EN) "⚡ Sign In & Intercept Phish" else "⚡ সাইন ইন ও আক্রমণ বিশ্লেষণ",
                    color = Color.Black,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 13.sp
                )
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = if (currentLanguage == AppLanguage.EN)
                    "🛡️ Zero credentials saved. Educational defense demonstration."
                else
                    "🛡️ কোনো পাসওয়ার্ড সংরক্ষণ হয় না। সম্পূর্ণ শিক্ষামূলক প্রতিরক্ষা ডেমো।",
                color = TextSecondary,
                fontSize = 10.sp,
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )
        }

        // Section: Intercepted Phishing Attack Analysis Report
        AnimatedVisibility(visible = isPhishIntercepted) {
            CyberCard(borderColor = NeonRed) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = "Phish Intercepted",
                        tint = NeonRed,
                        modifier = Modifier.size(24.dp)
                    )
                    Text(
                        text = if (currentLanguage == AppLanguage.EN) "🚨 PHISHING INTERCEPTION REPORT" else "🚨 ফিশিং আক্রমণ বিশ্লেষণ রিপোর্ট",
                        color = NeonRed,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 14.sp
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Surface(
                    color = Color(0xFF1B0F15),
                    shape = RoundedCornerShape(8.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, NeonRed.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = if (currentLanguage == AppLanguage.EN)
                                "ATTACK VECTOR EXECUTED:"
                            else
                                "যে আক্রমণটি সংঘটিত হলো:",
                            color = NeonAmber,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Target Account: $dummyUsername\nSecret Intercepted: ${"•".repeat(interceptedCharsCount.coerceAtLeast(8))} (${interceptedCharsCount} chars)\nDestination: https://evil-c2-collector.darknet/harvest.php\nHTTP Referrer: Spoofed OAuth2 Redirect",
                            color = Color(0xFFFFB4AB),
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            lineHeight = 16.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = if (currentLanguage == AppLanguage.EN) "How This Attack Works in the Real World:" else "বাস্তব জগতে এই আক্রমণ কীভাবে ঘটে:",
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
                Spacer(modifier = Modifier.height(6.dp))

                AttackExplanationItem(
                    title = if (currentLanguage == AppLanguage.EN) "1. Reverse-Proxy Phishing (AitM)" else "১. রিভার্স-প্রক্সি ফিশিং (AitM)",
                    desc = if (currentLanguage == AppLanguage.EN)
                        "Modern phishing tools (like Evilginx) proxy real traffic to the authentic server. Even if you use SMS or Google Authenticator 2FA, the attacker intercepts the session cookie and logs in without your password!"
                    else
                        "আধুনিক ফিশিং কিটগুলো ব্যবহারকারী ও আসল সার্ভারের মাঝে বসে ওটিপি ও সেশন কুকি চুরি করে সরাসরি লগইন করে ফেলে।"
                )

                AttackExplanationItem(
                    title = if (currentLanguage == AppLanguage.EN) "2. The False 'Padlock' Fallacy" else "২. ব্রাউজারের তালার চিহ্নের ভুল ধারণা",
                    desc = if (currentLanguage == AppLanguage.EN)
                        "The green padlock only proves that your connection to the site is encrypted—it DOES NOT prove the site owner is trustworthy! Free SSL certificates allow phishing sites to show valid padlocks."
                    else
                        "ব্রাউজারে তালার চিহ্ন থাকার অর্থ এই নয় যে ওয়েবসাইটটি আসল। ফ্রি এসএসএল সার্টিফিকেট দিয়ে প্রতারক সাইটগুলোতেও সবুজ তালা দেখানো যায়।"
                )

                AttackExplanationItem(
                    title = if (currentLanguage == AppLanguage.EN) "3. Unbeatable Defense: FIDO2 Passkeys" else "৩. অভেদ্য সুরক্ষা: FIDO2 পাস-কি",
                    desc = if (currentLanguage == AppLanguage.EN)
                        "FIDO2 hardware keys (YubiKey) and Passkeys are cryptographically bound to the real domain name. They mathematically refuse to send credentials to spoofed URLs!"
                    else
                        "পাস-কি (Passkeys) এবং হার্ডওয়্যার সিকিউরিটি কি সরাসরি আসল ডোমেনের সাথে আবদ্ধ থাকে, ফলে ভুয়া সাইটে এগুলো কখনোই কোড পাঠায় না।"
                )
            }
        }

        // Section: Golden Rules to Spot a Fake Login
        CyberCard(borderColor = NeonGreen.copy(alpha = 0.4f)) {
            Text(
                text = if (currentLanguage == AppLanguage.EN) "🛡️ Anti-Phishing Defense Protocol" else "🛡️ ফিশিং থেকে বাঁচার উপায়",
                color = NeonGreen,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = if (currentLanguage == AppLanguage.EN)
                    "• Always use a Password Manager (e.g. Bitwarden, 1Password, Google Password Manager). If it does not auto-fill, the domain is FAKE!\n• Never approve push notifications (2FA fatigue) that you did not trigger yourself.\n• Bookmark critical login portals and never open them from unsolicited emails or SMS links.\n• Upgrade accounts to Passkeys or Hardware Security Keys (WebAuthn)."
                else
                    "• পাসওয়ার্ড ম্যানেজার ব্যবহার করুন। ডোমেন ভুয়া হলে এটি কোনো তথ্য অটোফিল করবে না!\n• অপ্রত্যাশিত কোনো ২-ফ্যাক্টর নোটিফিকেশন আসলে কখনোই 'Yes' বা 'Approve' চাপবেন না।\n• গুরুত্বপূর্ণ ব্যাংক বা ইমেইল লগইন পেজ বুকমার্ক করে রাখুন; এসএমএসের লিংকে ক্লিক করবেন না।\n• সম্ভব হলে পাস-কি (Passkey) ব্যবহার করুন।",
                color = TextSecondary,
                fontSize = 11.sp,
                lineHeight = 17.sp
            )
        }
    }
}

@Composable
private fun AttackExplanationItem(
    title: String,
    desc: String
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        Text(
            text = title,
            color = NeonCyan,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = desc,
            color = TextSecondary,
            fontSize = 11.sp,
            lineHeight = 15.sp
        )
    }
}
