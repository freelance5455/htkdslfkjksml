package com.example.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.chess.AVAILABLE_BOARD_THEMES
import com.example.chess.BoardArrow
import com.example.chess.BoardTheme
import com.example.chess.ChessBoardState
import com.example.chess.ChessEngineCore
import com.example.chess.ChessPiece
import com.example.chess.PieceColor
import com.example.chess.PieceType
import com.example.chess.Square
import com.example.pdf.SampleChessPdfGenerator
import com.example.ui.theme.BoardArrowGray
import com.example.ui.theme.BoardSelectedHighlight
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sin

@Composable
fun ChessboardComposable(
    boardState: ChessBoardState,
    theme: BoardTheme,
    engineArrows: List<BoardArrow>,
    onMove: (Square, Square, PieceType?) -> Unit,
    modifier: Modifier = Modifier
) {
    val position = remember(boardState.fen) {
        ChessEngineCore.parseFen(boardState.fen)
    }
    val allLegalMoves = remember(position) {
        position?.generateLegalMoves().orEmpty()
    }

    var selectedSquare by remember(boardState.fen) { mutableStateOf<Square?>(null) }
    var dragFromSquare by remember { mutableStateOf<Square?>(null) }
    var dragCurrentOffset by remember { mutableStateOf<Offset?>(null) }
    var pendingPromotion by remember { mutableStateOf<Pair<Square, Square>?>(null) }

    val legalDestForSelected = remember(selectedSquare, allLegalMoves) {
        val sel = selectedSquare
        if (sel == null) emptySet()
        else allLegalMoves.filter { it.from == sel }.map { it.to }.toSet()
    }

    val isFlipped = boardState.orientation == PieceColor.BLACK

    fun offsetToSquare(offset: Offset, boardPx: Float): Square? {
        if (boardPx <= 0f) return null
        val cell = boardPx / 8f
        val visualCol = floor(offset.x / cell).toInt()
        val visualRow = floor(offset.y / cell).toInt()
        if (visualCol !in 0..7 || visualRow !in 0..7) return null
        val row = if (isFlipped) 7 - visualRow else visualRow
        val col = if (isFlipped) 7 - visualCol else visualCol
        return Square(row, col)
    }

    fun squareToCenterOffset(sq: Square, boardPx: Float): Offset {
        val cell = boardPx / 8f
        val vRow = if (isFlipped) 7 - sq.row else sq.row
        val vCol = if (isFlipped) 7 - sq.col else sq.col
        return Offset((vCol + 0.5f) * cell, (vRow + 0.5f) * cell)
    }

    fun tryExecuteMove(from: Square, to: Square) {
        val matching = allLegalMoves.filter { it.from == from && it.to == to }
        if (matching.isEmpty()) return
        if (matching.any { it.promotion != null }) {
            pendingPromotion = from to to
        } else {
            onMove(from, to, null)
        }
        selectedSquare = null
    }

    Box(
        modifier = modifier
            .aspectRatio(1f)
            .testTag("interactive_chessboard")
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .testTag("chessboard_canvas")
                .pointerInput(boardState.fen, isFlipped) {
                    detectTapGestures { tapOffset ->
                        val tappedSq = offsetToSquare(tapOffset, size.width.toFloat()) ?: return@detectTapGestures
                        val currentSel = selectedSquare
                        if (currentSel != null && tappedSq in legalDestForSelected) {
                            tryExecuteMove(currentSel, tappedSq)
                        } else {
                            val clickedPiece = position?.pieceAt(tappedSq)
                            if (clickedPiece != null && clickedPiece.color == position.turn) {
                                selectedSquare = if (currentSel == tappedSq) null else tappedSq
                            } else {
                                selectedSquare = null
                            }
                        }
                    }
                }
                .pointerInput(boardState.fen, isFlipped) {
                    detectDragGestures(
                        onDragStart = { startOffset ->
                            val sq = offsetToSquare(startOffset, size.width.toFloat())
                            val p = sq?.let { position?.pieceAt(it) }
                            if (sq != null && p != null && p.color == position?.turn) {
                                dragFromSquare = sq
                                selectedSquare = sq
                                dragCurrentOffset = startOffset
                            }
                        },
                        onDrag = { change, _ ->
                            if (dragFromSquare != null) {
                                change.consume()
                                dragCurrentOffset = change.position
                            }
                        },
                        onDragEnd = {
                            val from = dragFromSquare
                            val endOff = dragCurrentOffset
                            if (from != null && endOff != null) {
                                val target = offsetToSquare(endOff, size.width.toFloat())
                                if (target != null && target != from) {
                                    tryExecuteMove(from, target)
                                }
                            }
                            dragFromSquare = null
                            dragCurrentOffset = null
                        },
                        onDragCancel = {
                            dragFromSquare = null
                            dragCurrentOffset = null
                        }
                    )
                }
        ) {
            val boardPx = size.width
            val cell = boardPx / 8f
            val lastFrom = boardState.currentNode.lastFrom?.let { Square.fromAlgebraic(it) }
            val lastTo = boardState.currentNode.lastTo?.let { Square.fromAlgebraic(it) }
            val inCheckKingSq = if (position?.isInCheck() == true) position.findKing(position.turn) else null

            // 1. Draw 64 squares & highlights
            for (vRow in 0..7) {
                for (vCol in 0..7) {
                    val row = if (isFlipped) 7 - vRow else vRow
                    val col = if (isFlipped) 7 - vCol else vCol
                    val sq = Square(row, col)
                    val isDark = (row + col) % 2 == 1
                    val topLeft = Offset(vCol * cell, vRow * cell)
                    drawRect(
                        color = if (isDark) theme.darkSquare else theme.lightSquare,
                        topLeft = topLeft,
                        size = Size(cell, cell)
                    )
                    if (sq == lastFrom || sq == lastTo) {
                        drawRect(color = theme.highlight, topLeft = topLeft, size = Size(cell, cell))
                    }
                    if (sq == selectedSquare) {
                        drawRect(color = BoardSelectedHighlight, topLeft = topLeft, size = Size(cell, cell))
                    }
                    if (sq == inCheckKingSq) {
                        drawRect(color = Color(0x99DC2626), topLeft = topLeft, size = Size(cell, cell))
                    }
                }
            }

            // 2. Draw rank (right edge 8..1) & file (bottom edge a..h) coordinates matching screenshot
            drawIntoCanvas { canvas ->
                val native = canvas.nativeCanvas
                val coordPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                    textSize = cell * 0.25f
                    typeface = android.graphics.Typeface.DEFAULT_BOLD
                }
                for (vRow in 0..7) {
                    val row = if (isFlipped) 7 - vRow else vRow
                    val col = if (isFlipped) 0 else 7
                    val isDark = (row + col) % 2 == 1
                    val c = if (isDark) theme.coordOnDark else theme.coordOnLight
                    coordPaint.color = android.graphics.Color.argb(
                        (c.alpha * 255).toInt(),
                        (c.red * 255).toInt(),
                        (c.green * 255).toInt(),
                        (c.blue * 255).toInt()
                    )
                    coordPaint.textAlign = android.graphics.Paint.Align.RIGHT
                    val rankLabel = "${8 - row}"
                    native.drawText(
                        rankLabel,
                        boardPx - cell * 0.07f,
                        vRow * cell + cell * 0.27f,
                        coordPaint
                    )
                }
                for (vCol in 0..7) {
                    val row = if (isFlipped) 0 else 7
                    val col = if (isFlipped) 7 - vCol else vCol
                    val isDark = (row + col) % 2 == 1
                    val c = if (isDark) theme.coordOnDark else theme.coordOnLight
                    coordPaint.color = android.graphics.Color.argb(
                        (c.alpha * 255).toInt(),
                        (c.red * 255).toInt(),
                        (c.green * 255).toInt(),
                        (c.blue * 255).toInt()
                    )
                    coordPaint.textAlign = android.graphics.Paint.Align.LEFT
                    val fileLabel = "${('a'.code + col).toChar()}"
                    native.drawText(
                        fileLabel,
                        vCol * cell + cell * 0.08f,
                        boardPx - cell * 0.08f,
                        coordPaint
                    )
                }

                // 3. Draw non-dragged Staunton chess pieces
                if (position != null) {
                    for (vRow in 0..7) {
                        for (vCol in 0..7) {
                            val row = if (isFlipped) 7 - vRow else vRow
                            val col = if (isFlipped) 7 - vCol else vCol
                            val sq = Square(row, col)
                            if (sq == dragFromSquare) continue
                            val piece = position.board[row][col] ?: continue
                            SampleChessPdfGenerator.drawStauntonPieceOnCanvas(
                                canvas = native,
                                piece = piece,
                                left = vCol * cell,
                                top = vRow * cell,
                                cellSize = cell
                            )
                        }
                    }
                }
            }

            // 4. Draw legal move target dots / capture rings
            for (dest in legalDestForSelected) {
                val center = squareToCenterOffset(dest, boardPx)
                val hasEnemy = position?.pieceAt(dest) != null
                if (hasEnemy) {
                    drawCircle(
                        color = Color(0x7714532D),
                        radius = cell * 0.43f,
                        center = center,
                        style = Stroke(width = cell * 0.09f)
                    )
                } else {
                    drawCircle(
                        color = Color(0x6614532D),
                        radius = cell * 0.16f,
                        center = center
                    )
                }
            }

            // 5. Draw translucent arrows (matching screenshot gray-slate arrow style)
            val allArrows = engineArrows + boardState.currentNode.userArrows
            for ((idx, arrow) in allArrows.withIndex()) {
                val fromSq = Square.fromAlgebraic(arrow.from) ?: continue
                val toSq = Square.fromAlgebraic(arrow.to) ?: continue
                val start = squareToCenterOffset(fromSq, boardPx)
                val end = squareToCenterOffset(toSq, boardPx)
                val arrowColor = if (idx == 0) Color(0x8C57534E) else BoardArrowGray
                drawBoardArrow(start, end, cell, arrowColor)
            }

            // 6. Draw floating dragged piece on top
            val draggingSq = dragFromSquare
            val draggingOff = dragCurrentOffset
            if (draggingSq != null && draggingOff != null && position != null) {
                val piece = position.pieceAt(draggingSq)
                if (piece != null) {
                    drawIntoCanvas { canvas ->
                        SampleChessPdfGenerator.drawStauntonPieceOnCanvas(
                            canvas = canvas.nativeCanvas,
                            piece = piece,
                            left = draggingOff.x - cell * 0.5f,
                            top = draggingOff.y - cell * 0.5f,
                            cellSize = cell * 1.1f
                        )
                    }
                }
            }
        }
    }

    // Promotion Chooser Dialog
    pendingPromotion?.let { (from, to) ->
        val usColor = position?.turn ?: PieceColor.WHITE
        AlertDialog(
            onDismissRequest = { pendingPromotion = null },
            title = { Text("Promote Pawn") },
            text = {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    for (pt in listOf(PieceType.QUEEN, PieceType.ROOK, PieceType.BISHOP, PieceType.KNIGHT)) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = theme.lightSquare,
                            modifier = Modifier
                                .size(56.dp)
                                .clickable {
                                    pendingPromotion = null
                                    onMove(from, to, pt)
                                }
                        ) {
                            PieceGlyphIcon(piece = ChessPiece(usColor, pt), modifier = Modifier.padding(4.dp))
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { pendingPromotion = null }) { Text("Cancel") }
            }
        )
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawBoardArrow(
    start: Offset,
    end: Offset,
    cell: Float,
    color: Color
) {
    val angle = atan2(end.y - start.y, end.x - start.x)
    val headLen = cell * 0.42f
    val shaftEnd = Offset(
        end.x - cos(angle) * (headLen * 0.65f),
        end.y - sin(angle) * (headLen * 0.65f)
    )
    drawLine(
        color = color,
        start = start,
        end = shaftEnd,
        strokeWidth = cell * 0.22f,
        cap = StrokeCap.Butt
    )
    val wingAngle = 0.58f
    val p1 = Offset(
        end.x - headLen * cos(angle - wingAngle),
        end.y - headLen * sin(angle - wingAngle)
    )
    val p2 = Offset(
        end.x - headLen * cos(angle + wingAngle),
        end.y - headLen * sin(angle + wingAngle)
    )
    val headPath = Path().apply {
        moveTo(end.x, end.y)
        lineTo(p1.x, p1.y)
        lineTo(p2.x, p2.y)
        close()
    }
    drawPath(path = headPath, color = color)
}

@Composable
fun PieceGlyphIcon(piece: ChessPiece, modifier: Modifier = Modifier) {
    Canvas(modifier = modifier.aspectRatio(1f)) {
        drawIntoCanvas { canvas ->
            SampleChessPdfGenerator.drawStauntonPieceOnCanvas(
                canvas = canvas.nativeCanvas,
                piece = piece,
                left = 0f,
                top = 0f,
                cellSize = size.width
            )
        }
    }
}

@Composable
fun MiniChessboardPreview(
    fen: String,
    modifier: Modifier = Modifier,
    theme: BoardTheme = AVAILABLE_BOARD_THEMES.first()
) {
    val pos = remember(fen) { ChessEngineCore.parseFen(fen) }
    Canvas(modifier = modifier.aspectRatio(1f).background(theme.lightSquare)) {
        val cell = size.width / 8f
        for (r in 0..7) {
            for (c in 0..7) {
                val isDark = (r + c) % 2 == 1
                drawRect(
                    color = if (isDark) theme.darkSquare else theme.lightSquare,
                    topLeft = Offset(c * cell, r * cell),
                    size = Size(cell, cell)
                )
            }
        }
        if (pos != null) {
            drawIntoCanvas { canvas ->
                for (r in 0..7) {
                    for (c in 0..7) {
                        val p = pos.board[r][c] ?: continue
                        SampleChessPdfGenerator.drawStauntonPieceOnCanvas(
                            canvas = canvas.nativeCanvas,
                            piece = p,
                            left = c * cell,
                            top = r * cell,
                            cellSize = cell
                        )
                    }
                }
            }
        }
    }
}
