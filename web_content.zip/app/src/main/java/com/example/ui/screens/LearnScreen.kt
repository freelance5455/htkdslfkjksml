package com.example.ui.screens

import android.app.Activity
import android.content.Intent
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.LearnContentProvider
import com.example.data.model.ChatMessage
import com.example.ui.components.AiFirebaseNoticeBanner
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun LearnScreen(
    tutorMessages: List<ChatMessage>,
    isAiThinking: Boolean,
    learnedCount: Int,
    quizStreak: Int,
    onMarkFactLearned: () -> Unit,
    onQuizAnswered: (Boolean) -> Unit,
    onAskTutor: (question: String, subject: String) -> Unit
) {
    var bibleIndex by remember { mutableIntStateOf(0) }
    var factIndex by remember { mutableIntStateOf(0) }
    var quizIndex by remember { mutableIntStateOf(0) }
    var selectedOption by remember { mutableStateOf<Int?>(null) }

    var selectedSubject by remember { mutableStateOf("Math") }
    var tutorInput by remember { mutableStateOf("") }

    val voiceTutorLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spoken.isNullOrBlank()) {
                tutorInput = spoken
                onAskTutor(spoken, selectedSubject)
                tutorInput = ""
            }
        }
    }

    val passage = LearnContentProvider.biblePassages[bibleIndex % LearnContentProvider.biblePassages.size]
    val fact = LearnContentProvider.dailyFacts[factIndex % LearnContentProvider.dailyFacts.size]
    val question = LearnContentProvider.dailyQuestions[quizIndex % LearnContentProvider.dailyQuestions.size]

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Bible Section
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.MenuBook, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimaryContainer)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Bible & Daily Scripture", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        }
                        AssistChip(onClick = { bibleIndex++ }, label = { Text("Next Verse") })
                    }
                    Text(
                        text = "${passage.reference} • ${passage.theme}",
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(text = "\"${passage.text}\"", style = MaterialTheme.typography.bodyMedium)
                    Text(
                        text = "Reflection: ${passage.teenReflection}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }
        }

        // Daily Quick Question
        item {
            Card {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Quiz, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Daily Quick Question", style = MaterialTheme.typography.titleLarge)
                        }
                        Text("Score: $quizStreak", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.secondary)
                    }
                    Text(question.category, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                    Text(question.question, style = MaterialTheme.typography.titleMedium)

                    question.options.forEachIndexed { idx, opt ->
                        val isSelected = selectedOption == idx
                        val isCorrect = idx == question.correctIndex
                        OutlinedButton(
                            onClick = {
                                if (selectedOption == null) {
                                    selectedOption = idx
                                    onQuizAnswered(isCorrect)
                                }
                            },
                            modifier = Modifier.fillMaxWidth().testTag("quiz_option_$idx")
                        ) {
                            Text(
                                text = when {
                                    selectedOption == null -> opt
                                    isCorrect -> "✓ $opt"
                                    isSelected -> "✕ $opt"
                                    else -> opt
                                }
                            )
                        }
                    }

                    if (selectedOption != null) {
                        Text(
                            text = question.explanation,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Button(
                            onClick = {
                                selectedOption = null
                                quizIndex++
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Next Quick Question")
                        }
                    }
                }
            }
        }

        // Learn Something New Everyday
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = MaterialTheme.colorScheme.onSecondaryContainer)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Learn Something New Everyday", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        }
                        Text("$learnedCount learned", style = MaterialTheme.typography.labelMedium)
                    }
                    Text(fact.topic, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.secondary)
                    Text(fact.title, style = MaterialTheme.typography.titleMedium)
                    Text(fact.summary, style = MaterialTheme.typography.bodyMedium)
                    Text("Takeaway: ${fact.takeaway}", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                    Button(
                        onClick = {
                            onMarkFactLearned()
                            factIndex++
                        },
                        modifier = Modifier.fillMaxWidth().testTag("mark_learned_button")
                    ) {
                        Icon(Icons.Filled.CheckCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Got It! Show Next Discovery")
                    }
                }
            }
        }

        // 24-Hour Tutor: Tshenolo Maseko
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.School, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text("Tshenolo Maseko • 24hr Personal Tutor", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text("Available 24 hours a day for homework, science, math, Bible & life skills", style = MaterialTheme.typography.bodySmall)
                    }
                }
                AiFirebaseNoticeBanner()
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("Math", "Science", "English", "Study Tips", "Bible Study", "Life Skills").forEach { sub ->
                        FilterChip(
                            selected = selectedSubject == sub,
                            onClick = { selectedSubject = sub },
                            label = { Text(sub) }
                        )
                    }
                }
            }
        }

        items(tutorMessages, key = { it.id }) { msg ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = if (msg.isFromUser) Arrangement.End else Arrangement.Start
            ) {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (msg.isFromUser) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
                    ),
                    modifier = Modifier.fillMaxWidth(0.9f)
                ) {
                    Text(msg.text, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(12.dp))
                }
            }
        }

        if (isAiThinking) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                    Text("Tshenolo Maseko is preparing your lesson...", style = MaterialTheme.typography.bodySmall)
                }
            }
        }

        item {
            OutlinedTextField(
                value = tutorInput,
                onValueChange = { tutorInput = it },
                placeholder = { Text("Ask Tshenolo Maseko anything ($selectedSubject)...") },
                modifier = Modifier.fillMaxWidth().testTag("tutor_input"),
                trailingIcon = {
                    Row {
                        IconButton(onClick = {
                            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                                putExtra(RecognizerIntent.EXTRA_PROMPT, "Ask Tshenolo Maseko...")
                            }
                            try {
                                voiceTutorLauncher.launch(intent)
                            } catch (_: Exception) {
                            }
                        }) {
                            Icon(Icons.Filled.Mic, contentDescription = "Voice ask tutor")
                        }
                        IconButton(
                            onClick = {
                                onAskTutor(tutorInput, selectedSubject)
                                tutorInput = ""
                            },
                            modifier = Modifier.testTag("ask_tutor_button")
                        ) {
                            Icon(Icons.Filled.Send, contentDescription = "Ask Tshenolo Maseko")
                        }
                    }
                }
            )
        }
    }
}
