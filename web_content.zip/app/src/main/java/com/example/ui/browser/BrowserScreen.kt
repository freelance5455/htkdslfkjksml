package com.example.ui.browser

import android.annotation.SuppressLint
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.BookmarkAdd
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Public
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.model.BrowserTab
import com.example.ui.theme.AlabasterSurface
import com.example.ui.theme.DeepInk
import com.example.ui.theme.GeminiBlue
import com.example.ui.theme.GeminiBorder
import com.example.ui.theme.GeminiSoftBg
import com.example.ui.theme.HairlineBorder
import com.example.ui.theme.MutedSlate
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SlateSecondary
import com.example.ui.theme.VaultEmerald
import org.json.JSONObject

private class BeyazJavaScriptBridge(
    private val mainHandler: Handler,
    private val onSearchTriggered: (String) -> Unit,
    private val onSearchAndGeminiTriggered: (String) -> Unit,
    private val onNavigateUrlTriggered: (String, String) -> Unit,
    private val onSaveToVaultTriggered: (String, String) -> Unit
) {
    @JavascriptInterface
    fun onSearch(query: String) {
        mainHandler.post { onSearchTriggered(query) }
    }

    @JavascriptInterface
    fun onSearchAndOpenGemini(query: String) {
        mainHandler.post { onSearchAndGeminiTriggered(query) }
    }

    @JavascriptInterface
    fun onNavigateUrl(url: String, title: String) {
        mainHandler.post { onNavigateUrlTriggered(url, title) }
    }

    @JavascriptInterface
    fun onSaveToVault(title: String, body: String) {
        mainHandler.post { onSaveToVaultTriggered(title, body) }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun BrowserScreen(
    viewModel: BrowserViewModel,
    userEmail: String?,
    onSignOut: () -> Unit
) {
    val tabsState by viewModel.tabsState.collectAsStateWithLifecycle()
    val bookmarksState by viewModel.bookmarksState.collectAsStateWithLifecycle()
    val historyState by viewModel.historyState.collectAsStateWithLifecycle()
    val selectedTabId by viewModel.selectedTabId.collectAsStateWithLifecycle()
    val isGeminiTabActive by viewModel.isGeminiTabActive.collectAsStateWithLifecycle()
    val bottomDestination by viewModel.bottomDestination.collectAsStateWithLifecycle()
    val lastSearchedQuery by viewModel.lastSearchedQuery.collectAsStateWithLifecycle()
    val geminiState by viewModel.geminiState.collectAsStateWithLifecycle()
    val bannerMessage by viewModel.statusBannerMessage.collectAsStateWithLifecycle()

    val focusManager = LocalFocusManager.current
    val tabs = (tabsState as? DataUiState.Success)?.data.orEmpty()
    val activeTab = tabs.firstOrNull { it.id == selectedTabId } ?: tabs.firstOrNull()

    var addressInput by remember(activeTab?.id, activeTab?.url, lastSearchedQuery) {
        val currentUrl = activeTab?.url.orEmpty()
        val displayVal = when {
            currentUrl == "beyaz://index.html" && lastSearchedQuery.isNotBlank() -> lastSearchedQuery
            currentUrl == "beyaz://index.html" || currentUrl.isBlank() -> "index.html"
            else -> currentUrl
        }
        mutableStateOf(displayVal)
    }

    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    var pageProgress by remember { mutableIntStateOf(100) }
    val mainHandler = remember { Handler(Looper.getMainLooper()) }

    BackHandler(enabled = bottomDestination != BrowserBottomDestination.BROWSER || isGeminiTabActive) {
        viewModel.selectBottomDestination(BrowserBottomDestination.BROWSER)
    }

    Scaffold(
        contentWindowInsets = WindowInsets.safeDrawing,
        containerColor = PureWhite,
        bottomBar = {
            Column {
                HorizontalDivider(color = HairlineBorder, thickness = 1.dp)
                NavigationBar(
                    containerColor = PureWhite,
                    tonalElevation = 0.dp
                ) {
                    NavigationBarItem(
                        selected = bottomDestination == BrowserBottomDestination.BROWSER && !isGeminiTabActive,
                        onClick = { viewModel.selectBottomDestination(BrowserBottomDestination.BROWSER) },
                        icon = {
                            Icon(
                                imageVector = if (bottomDestination == BrowserBottomDestination.BROWSER && !isGeminiTabActive) {
                                    Icons.Filled.Public
                                } else {
                                    Icons.Outlined.Public
                                },
                                contentDescription = stringResource(id = R.string.nav_browser)
                            )
                        },
                        label = { Text(stringResource(id = R.string.nav_browser)) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = DeepInk,
                            selectedTextColor = DeepInk,
                            indicatorColor = AlabasterSurface,
                            unselectedIconColor = SlateSecondary,
                            unselectedTextColor = SlateSecondary
                        ),
                        modifier = Modifier.testTag("nav_browser_tab")
                    )

                    NavigationBarItem(
                        selected = bottomDestination == BrowserBottomDestination.GEMINI || isGeminiTabActive,
                        onClick = { viewModel.activateGeminiTabAndAutoQuery() },
                        icon = {
                            Icon(
                                imageVector = if (bottomDestination == BrowserBottomDestination.GEMINI || isGeminiTabActive) {
                                    Icons.Filled.AutoAwesome
                                } else {
                                    Icons.Outlined.AutoAwesome
                                },
                                contentDescription = stringResource(id = R.string.nav_gemini)
                            )
                        },
                        label = { Text(stringResource(id = R.string.nav_gemini)) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = GeminiBlue,
                            selectedTextColor = GeminiBlue,
                            indicatorColor = GeminiSoftBg,
                            unselectedIconColor = SlateSecondary,
                            unselectedTextColor = SlateSecondary
                        ),
                        modifier = Modifier.testTag("nav_gemini_tab")
                    )

                    NavigationBarItem(
                        selected = bottomDestination == BrowserBottomDestination.VAULT,
                        onClick = { viewModel.selectBottomDestination(BrowserBottomDestination.VAULT) },
                        icon = {
                            Icon(
                                imageVector = if (bottomDestination == BrowserBottomDestination.VAULT) {
                                    Icons.Filled.Bookmark
                                } else {
                                    Icons.Outlined.BookmarkBorder
                                },
                                contentDescription = stringResource(id = R.string.nav_vault)
                            )
                        },
                        label = { Text(stringResource(id = R.string.nav_vault)) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = DeepInk,
                            selectedTextColor = DeepInk,
                            indicatorColor = AlabasterSurface,
                            unselectedIconColor = SlateSecondary,
                            unselectedTextColor = SlateSecondary
                        ),
                        modifier = Modifier.testTag("nav_vault_tab")
                    )

                    NavigationBarItem(
                        selected = bottomDestination == BrowserBottomDestination.HISTORY,
                        onClick = { viewModel.selectBottomDestination(BrowserBottomDestination.HISTORY) },
                        icon = {
                            Icon(
                                imageVector = if (bottomDestination == BrowserBottomDestination.HISTORY) {
                                    Icons.Filled.History
                                } else {
                                    Icons.Outlined.History
                                },
                                contentDescription = stringResource(id = R.string.nav_history)
                            )
                        },
                        label = { Text(stringResource(id = R.string.nav_history)) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = DeepInk,
                            selectedTextColor = DeepInk,
                            indicatorColor = AlabasterSurface,
                            unselectedIconColor = SlateSecondary,
                            unselectedTextColor = SlateSecondary
                        ),
                        modifier = Modifier.testTag("nav_history_tab")
                    )
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(PureWhite)
        ) {
            // 1. TOP TAB BAR: Open Browser Tabs + index.html + Prominent "✦ Gemini" Tab Next to Them
            TopBrowserAndGeminiTabBar(
                tabs = tabs,
                selectedTabId = activeTab?.id.orEmpty(),
                isIndexHtmlActive = !isGeminiTabActive &&
                    bottomDestination == BrowserBottomDestination.BROWSER &&
                    (activeTab?.url == "beyaz://index.html" || activeTab == null),
                isGeminiSelected = isGeminiTabActive || bottomDestination == BrowserBottomDestination.GEMINI,
                lastSearchedQuery = lastSearchedQuery,
                onSelectTab = { tab -> viewModel.selectBrowserTab(tab) },
                onCloseTab = { tab -> viewModel.closeTab(tab) },
                onNewTab = { viewModel.createNewTab() },
                onOpenIndexHtml = {
                    focusManager.clearFocus()
                    addressInput = "index.html"
                    viewModel.submitSearchOrUrl("index.html", openGeminiImmediately = false)
                    webViewRef?.loadUrl("file:///android_asset/index.html")
                },
                onSelectGeminiTab = { viewModel.activateGeminiTabAndAutoQuery() }
            )

            // 2. MINIMALIST SEARCH & URL OMNIBOX BAR
            MinimalistOmniboxBar(
                addressInput = addressInput,
                onAddressChange = { addressInput = it },
                onSubmitSearch = {
                    focusManager.clearFocus()
                    viewModel.submitSearchOrUrl(addressInput, openGeminiImmediately = false)
                },
                onGoHomeIndexHtml = {
                    focusManager.clearFocus()
                    addressInput = "index.html"
                    viewModel.submitSearchOrUrl("beyaz://index.html", openGeminiImmediately = false)
                    webViewRef?.loadUrl("file:///android_asset/index.html")
                },
                onQuickSaveBookmark = {
                    val title = activeTab?.title ?: "Kayıtlı Sayfa"
                    val url = activeTab?.url ?: "beyaz://index.html"
                    viewModel.saveBookmarkToVault(
                        title = title,
                        url = url,
                        category = "Genel",
                        note = lastSearchedQuery
                    )
                },
                onReload = { webViewRef?.reload() }
            )

            if (pageProgress in 1..99 && bottomDestination == BrowserBottomDestination.BROWSER && !isGeminiTabActive) {
                LinearProgressIndicator(
                    progress = { pageProgress / 100f },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(2.dp),
                    color = GeminiBlue,
                    trackColor = AlabasterSurface
                )
            } else {
                HorizontalDivider(color = HairlineBorder, thickness = 1.dp)
            }

            // Optional transient status banner
            AnimatedVisibility(visible = !bannerMessage.isNullOrBlank()) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                        .clickable { viewModel.dismissBanner() },
                    shape = RoundedCornerShape(12.dp),
                    color = AlabasterSurface,
                    border = BorderStroke(1.dp, HairlineBorder)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = bannerMessage.orEmpty(),
                            style = MaterialTheme.typography.bodyMedium,
                            color = DeepInk,
                            modifier = Modifier.weight(1f)
                        )
                        Icon(
                            imageVector = Icons.Outlined.Close,
                            contentDescription = "Kapat",
                            tint = SlateSecondary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            // 3. MAIN CONTENT AREA
            Box(modifier = Modifier.weight(1f)) {
                when {
                    isGeminiTabActive || bottomDestination == BrowserBottomDestination.GEMINI -> {
                        GeminiWorkspaceSection(
                            lastSearchedQuery = lastSearchedQuery,
                            geminiState = geminiState,
                            onAskGemini = { query -> viewModel.askGeminiStream(query) },
                            onGenerateInteractiveHtml = { query ->
                                viewModel.generateInteractiveIndexHtmlForQuery(query)
                            },
                            onSaveToVault = { title, url, cat, note ->
                                viewModel.saveBookmarkToVault(title, url, cat, note)
                            }
                        )
                    }

                    bottomDestination == BrowserBottomDestination.VAULT -> {
                        VaultSection(
                            bookmarksState = bookmarksState,
                            onOpenUrl = { url, title ->
                                viewModel.submitSearchOrUrl(url, openGeminiImmediately = false)
                            },
                            onAddBookmark = { title, url, cat, note ->
                                viewModel.saveBookmarkToVault(title, url, cat, note)
                            },
                            onDeleteBookmark = { id -> viewModel.deleteBookmark(id) }
                        )
                    }

                    bottomDestination == BrowserBottomDestination.HISTORY -> {
                        HistoryAndPrivacySection(
                            historyState = historyState,
                            userEmail = userEmail,
                            onReopenQuery = { query ->
                                addressInput = query
                                viewModel.submitSearchOrUrl(query, openGeminiImmediately = false)
                            },
                            onSendQueryToGemini = { query ->
                                addressInput = query
                                viewModel.activateGeminiTabAndAutoQuery(query)
                            },
                            onDeleteHistoryItem = { id -> viewModel.deleteHistoryItem(id) },
                            onClearAllCloudData = { viewModel.clearAllCloudData() },
                            onSignOut = onSignOut
                        )
                    }

                    else -> {
                        // Standard Web & index.html Browser Viewport
                        val targetUrl = remember(activeTab?.url) {
                            val raw = activeTab?.url ?: "beyaz://index.html"
                            if (raw == "beyaz://index.html" || raw.isBlank()) {
                                "file:///android_asset/index.html"
                            } else {
                                raw
                            }
                        }

                        AndroidView(
                            modifier = Modifier
                                .fillMaxSize()
                                .testTag("browser_webview"),
                            factory = { ctx ->
                                WebView(ctx).apply {
                                    settings.javaScriptEnabled = true
                                    settings.domStorageEnabled = true
                                    settings.loadsImagesAutomatically = true

                                    addJavascriptInterface(
                                        BeyazJavaScriptBridge(
                                            mainHandler = mainHandler,
                                            onSearchTriggered = { q ->
                                                addressInput = q
                                                viewModel.submitSearchOrUrl(q, openGeminiImmediately = false)
                                            },
                                            onSearchAndGeminiTriggered = { q ->
                                                addressInput = q
                                                viewModel.submitSearchOrUrl(q, openGeminiImmediately = true)
                                            },
                                            onNavigateUrlTriggered = { url, _ ->
                                                addressInput = url
                                                viewModel.submitSearchOrUrl(url, openGeminiImmediately = false)
                                            },
                                            onSaveToVaultTriggered = { title, body ->
                                                viewModel.saveBookmarkToVault(
                                                    title = title,
                                                    url = "beyaz://index.html",
                                                    category = "Gemini Özeti",
                                                    note = body
                                                )
                                            }
                                        ),
                                        "BeyazBridge"
                                    )

                                    webChromeClient = object : WebChromeClient() {
                                        override fun onProgressChanged(view: WebView?, newProgress: Int) {
                                            pageProgress = newProgress
                                        }
                                    }

                                    webViewClient = object : WebViewClient() {
                                        override fun onPageFinished(view: WebView?, url: String?) {
                                            super.onPageFinished(view, url)
                                            if (url != null) {
                                                viewModel.updateActiveTabPageMetadata(url, view?.title)
                                                if (url.startsWith("file:///android_asset/index.html")) {
                                                    val q = lastSearchedQuery
                                                    val ans = (geminiState as? GeminiUiState.Success)?.responseText
                                                        ?: (geminiState as? GeminiUiState.Streaming)?.partialText
                                                        ?: ""
                                                    if (q.isNotBlank() || ans.isNotBlank()) {
                                                        val qEsc = JSONObject.quote(q)
                                                        val aEsc = JSONObject.quote(ans)
                                                        view?.evaluateJavascript(
                                                            "if(window.updateIndexGeminiState){window.updateIndexGeminiState($qEsc, $aEsc, 'Hazır');}",
                                                            null
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }

                                    loadUrl(targetUrl)
                                    webViewRef = this
                                }
                            },
                            update = { webView ->
                                webViewRef = webView
                                val currentLoaded = webView.url.orEmpty()
                                if (currentLoaded != targetUrl &&
                                    !(targetUrl == "file:///android_asset/index.html" && currentLoaded.startsWith("file:///android_asset/index.html"))
                                ) {
                                    webView.loadUrl(targetUrl)
                                }
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun TopBrowserAndGeminiTabBar(
    tabs: List<BrowserTab>,
    selectedTabId: String,
    isIndexHtmlActive: Boolean,
    isGeminiSelected: Boolean,
    lastSearchedQuery: String,
    onSelectTab: (BrowserTab) -> Unit,
    onCloseTab: (BrowserTab) -> Unit,
    onNewTab: () -> Unit,
    onOpenIndexHtml: () -> Unit,
    onSelectGeminiTab: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(PureWhite)
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Explicit "📄 index.html" tab button so index.html is always 1-tap accessible
        Surface(
            modifier = Modifier
                .height(38.dp)
                .clip(RoundedCornerShape(12.dp))
                .clickable(onClick = onOpenIndexHtml)
                .testTag("open_index_html_tab_button"),
            shape = RoundedCornerShape(12.dp),
            color = if (isIndexHtmlActive) DeepInk else AlabasterSurface,
            border = BorderStroke(1.dp, if (isIndexHtmlActive) DeepInk else HairlineBorder)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                Text(
                    text = "📄 index.html",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.SemiBold,
                    color = if (isIndexHtmlActive) PureWhite else DeepInk
                )
            }
        }

        // Open Browser Tabs
        tabs.forEach { tab ->
            val isSelected = !isGeminiSelected && tab.id == selectedTabId
            Surface(
                modifier = Modifier
                    .widthIn(min = 110.dp, max = 190.dp)
                    .height(38.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .clickable { onSelectTab(tab) }
                    .testTag("browser_tab_${tab.id}"),
                shape = RoundedCornerShape(12.dp),
                color = if (isSelected) DeepInk else AlabasterSurface,
                border = BorderStroke(
                    width = 1.dp,
                    color = if (isSelected) DeepInk else HairlineBorder
                )
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = tab.title.ifBlank { "index.html" },
                        style = MaterialTheme.typography.labelLarge,
                        color = if (isSelected) PureWhite else DeepInk,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Icon(
                        imageVector = Icons.Outlined.Close,
                        contentDescription = "Sekmeyi Kapat",
                        tint = if (isSelected) PureWhite.copy(alpha = 0.8f) else SlateSecondary,
                        modifier = Modifier
                            .size(15.dp)
                            .clickable { onCloseTab(tab) }
                    )
                }
            }
        }

        // New Tab (+) button
        Surface(
            modifier = Modifier
                .size(38.dp)
                .clip(RoundedCornerShape(12.dp))
                .clickable(onClick = onNewTab)
                .testTag("new_tab_button"),
            shape = RoundedCornerShape(12.dp),
            color = AlabasterSurface,
            border = BorderStroke(1.dp, HairlineBorder)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = Icons.Outlined.Add,
                    contentDescription = stringResource(id = R.string.new_tab),
                    tint = DeepInk,
                    modifier = Modifier.size(18.dp)
                )
            }
        }

        // PROMINENT TOP "✦ Gemini" TAB NEXT TO OTHER TABS
        Surface(
            modifier = Modifier
                .height(38.dp)
                .clip(RoundedCornerShape(12.dp))
                .clickable(onClick = onSelectGeminiTab)
                .testTag("top_gemini_tab"),
            shape = RoundedCornerShape(12.dp),
            color = if (isGeminiSelected) GeminiBlue else GeminiSoftBg,
            border = BorderStroke(1.dp, if (isGeminiSelected) GeminiBlue else GeminiBorder)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = Icons.Outlined.AutoAwesome,
                    contentDescription = "Gemini Sekmesi",
                    tint = if (isGeminiSelected) PureWhite else GeminiBlue,
                    modifier = Modifier.size(15.dp)
                )
                Text(
                    text = if (lastSearchedQuery.isNotBlank()) {
                        "✦ Gemini: ${lastSearchedQuery.take(16)}"
                    } else {
                        stringResource(id = R.string.tab_gemini)
                    },
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    color = if (isGeminiSelected) PureWhite else GeminiBlue,
                    maxLines = 1
                )
            }
        }
    }
}

@Composable
private fun MinimalistOmniboxBar(
    addressInput: String,
    onAddressChange: (String) -> Unit,
    onSubmitSearch: () -> Unit,
    onGoHomeIndexHtml: () -> Unit,
    onQuickSaveBookmark: () -> Unit,
    onReload: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(PureWhite)
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(
            onClick = onGoHomeIndexHtml,
            modifier = Modifier
                .size(42.dp)
                .testTag("home_index_html_button")
        ) {
            Icon(
                imageVector = Icons.Outlined.Home,
                contentDescription = "Ana Sayfa (index.html)",
                tint = DeepInk
            )
        }

        OutlinedTextField(
            value = addressInput,
            onValueChange = onAddressChange,
            placeholder = {
                Text(
                    text = stringResource(id = R.string.search_hint),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MutedSlate,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            },
            leadingIcon = {
                Icon(
                    imageVector = if (addressInput.startsWith("https://") || addressInput.startsWith("beyaz://")) {
                        Icons.Outlined.Lock
                    } else {
                        Icons.Outlined.Search
                    },
                    contentDescription = "Güvenli Arama",
                    tint = if (addressInput.startsWith("https://") || addressInput.startsWith("beyaz://")) {
                        VaultEmerald
                    } else {
                        SlateSecondary
                    },
                    modifier = Modifier.size(18.dp)
                )
            },
            trailingIcon = {
                if (addressInput.isNotEmpty()) {
                    IconButton(
                        onClick = { onAddressChange("") },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Close,
                            contentDescription = "Temizle",
                            tint = MutedSlate,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            },
            singleLine = true,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { onSubmitSearch() }),
            shape = CircleShape,
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = AlabasterSurface,
                unfocusedContainerColor = AlabasterSurface,
                focusedBorderColor = DeepInk,
                unfocusedBorderColor = HairlineBorder
            ),
            textStyle = MaterialTheme.typography.bodyMedium.copy(color = DeepInk),
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 4.dp)
                .testTag("search_url_input")
        )

        IconButton(
            onClick = onQuickSaveBookmark,
            modifier = Modifier
                .size(42.dp)
                .testTag("quick_bookmark_button")
        ) {
            Icon(
                imageVector = Icons.Outlined.BookmarkAdd,
                contentDescription = "Güvenli Kasaya Ekle",
                tint = DeepInk
            )
        }

        IconButton(
            onClick = onReload,
            modifier = Modifier
                .size(42.dp)
                .testTag("reload_page_button")
        ) {
            Icon(
                imageVector = Icons.Outlined.Refresh,
                contentDescription = "Yenile",
                tint = SlateSecondary
            )
        }
    }
}
