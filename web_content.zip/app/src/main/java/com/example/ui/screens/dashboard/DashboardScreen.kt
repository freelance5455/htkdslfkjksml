package com.example.ui.screens.dashboard

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CurrencyRupee
import androidx.compose.material.icons.filled.DeliveryDining
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.DeliveryViewModel
import com.example.ui.components.CycleCard
import com.example.ui.theme.DexterCyanPrimary
import com.example.ui.theme.DexterEmeraldSecondary
import com.example.ui.theme.DexterSurface
import com.example.ui.theme.DexterSurfaceVariant
import com.example.ui.theme.KamaiGreenGlow
import com.example.ui.theme.PendingOrange
import com.example.ui.theme.SettledGreen

@Composable
fun DashboardScreen(
    viewModel: DeliveryViewModel,
    onOpenAddEntry: () -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val summary by viewModel.dashboardSummary.collectAsStateWithLifecycle()
    val profile by viewModel.userProfile.collectAsStateWithLifecycle()

    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Welcome & Quick Rate Header
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = profile.agentName,
                        fontSize = 19.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Box(
                        modifier = Modifier
                            .size(7.dp)
                            .clip(CircleShape)
                            .background(DexterEmeraldSecondary)
                    )
                }
                Text(
                    text = "Tri-Monthly Invoice Cycles (1-10, 11-20, 21-31)",
                    fontSize = 12.sp,
                    color = Color(0xFF94A3B8)
                )
            }

            Surface(
                shape = RoundedCornerShape(20.dp),
                color = DexterCyanPrimary.copy(alpha = 0.15f),
                border = BorderStroke(1.dp, DexterCyanPrimary.copy(alpha = 0.4f)),
                modifier = Modifier
                    .clickable { onOpenSettings() }
                    .testTag("rate_setting_chip")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Icon(
                        Icons.Default.CurrencyRupee,
                        contentDescription = null,
                        modifier = Modifier.size(13.dp),
                        tint = DexterCyanPrimary
                    )
                    Text(
                        text = "₹${profile.defaultRate.toInt()}/drop",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = DexterCyanPrimary
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(
                        Icons.Default.Edit,
                        contentDescription = "Edit rate",
                        modifier = Modifier.size(12.dp),
                        tint = DexterCyanPrimary
                    )
                }
            }
        }

        // Dexter Hero Card: Today's Delivery Entry & Total Daily Kamai (50 * 18 = 900)
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("today_kamai_card"),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = DexterSurface),
            border = BorderStroke(1.5.dp, DexterEmeraldSecondary.copy(alpha = 0.5f)),
            elevation = CardDefaults.cardElevation(8.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color(0xFF0C243B),
                                Color(0xFF091424),
                                Color(0xFF080C14)
                            )
                        )
                    )
                    .padding(20.dp)
            ) {
                Column {
                    // Card Top Bar
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(CircleShape)
                                    .background(DexterEmeraldSecondary.copy(alpha = 0.18f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    Icons.Default.DeliveryDining,
                                    contentDescription = null,
                                    tint = DexterEmeraldSecondary,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "TODAY'S DELIVERIES",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color(0xFF94A3B8),
                                    letterSpacing = 1.sp
                                )
                                Text(
                                    text = viewModel.todayDateString,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = Color(0xFFCBD5E1)
                                )
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = DexterCyanPrimary.copy(alpha = 0.15f),
                            border = BorderStroke(1.dp, DexterCyanPrimary.copy(alpha = 0.3f))
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .clip(CircleShape)
                                        .background(DexterCyanPrimary)
                                )
                                Spacer(modifier = Modifier.width(5.dp))
                                Text(
                                    text = "Active Cycle ${summary.currentCycleNumber}",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = DexterCyanPrimary
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    // Big Financial Calculation: 50 Deliveries × ₹18 = ₹900
                    Row(
                        verticalAlignment = Alignment.Bottom,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column {
                            Text(
                                text = "${summary.todayDeliveries} Deliveries × ₹${summary.todayRate.toInt()}",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF94A3B8)
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "₹${summary.todayEarnings.toInt()}",
                                fontSize = 42.sp,
                                fontWeight = FontWeight.Black,
                                color = KamaiGreenGlow,
                                letterSpacing = (-0.5).sp
                            )
                        }

                        // Quick +/- Controls with Dexter Neon Feel
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            IconButton(
                                onClick = { viewModel.quickIncrementToday(-1) },
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF1E293B))
                            ) {
                                Icon(Icons.Default.Remove, contentDescription = "Minus 1", tint = Color.White)
                            }
                            IconButton(
                                onClick = { viewModel.quickIncrementToday(1) },
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(DexterEmeraldSecondary)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = "Plus 1", tint = Color(0xFF003822))
                            }
                            Surface(
                                shape = RoundedCornerShape(18.dp),
                                color = Color(0xFF1E293B),
                                border = BorderStroke(1.dp, Color(0xFF334155)),
                                modifier = Modifier
                                    .clickable { viewModel.quickIncrementToday(5) }
                            ) {
                                Text(
                                    text = "+5",
                                    color = DexterCyanPrimary,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 12.sp,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Progress towards 50 deliveries benchmark
                    val progress = (summary.todayDeliveries / 50f).coerceIn(0f, 1f)
                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(5.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = DexterEmeraldSecondary,
                        trackColor = Color(0xFF1E293B)
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Primary Update / Entry Button
                    Button(
                        onClick = onOpenAddEntry,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = DexterEmeraldSecondary,
                            contentColor = Color(0xFF003822)
                        ),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("log_deliveries_button")
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(17.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (summary.todayDeliveries > 0) "Update Today's Deliveries / Rate" else "Enter Today's Deliveries",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 14.sp
                        )
                    }
                }
            }
        }

        // Monthly Payouts Summary Banner (Dexter Dark Slate Card)
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = DexterSurface),
            border = BorderStroke(1.dp, Color(0xFF2E3F5E)),
            elevation = CardDefaults.cardElevation(3.dp)
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.TrendingUp,
                            contentDescription = null,
                            tint = DexterCyanPrimary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "MONTH TOTAL PAYOUTS SUMMARY",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF94A3B8),
                            letterSpacing = 0.7.sp
                        )
                    }

                    Text(
                        text = summary.monthKey,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = DexterCyanPrimary
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column {
                        Text(
                            text = "Month Deliveries",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF64748B)
                        )
                        Text(
                            text = "${summary.monthDeliveries}",
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.White
                        )
                    }

                    Column {
                        Text(
                            text = "Pending Payout",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF64748B)
                        )
                        Text(
                            text = "₹${summary.pendingPayoutTotal.toInt()}",
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Black,
                            color = PendingOrange
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "Settled (Paid)",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF64748B)
                        )
                        Text(
                            text = "₹${summary.settledPayoutTotal.toInt()}",
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Black,
                            color = SettledGreen
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Highlighted Net Month Kamai Strip
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF0B192C))
                        .border(BorderStroke(1.dp, DexterCyanPrimary.copy(alpha = 0.3f)), RoundedCornerShape(12.dp))
                        .padding(horizontal = 14.dp, vertical = 10.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.Payments,
                                contentDescription = null,
                                tint = DexterCyanPrimary,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Net Total Month Kamai",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }

                        Text(
                            text = "₹${summary.monthTotalEarnings.toInt()}",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Black,
                            color = DexterCyanPrimary
                        )
                    }
                }
            }
        }

        // Section Title: Tri-Monthly Invoice Cycles
        Column {
            Text(
                text = "3-TIME MONTHLY INVOICE CYCLES",
                fontSize = 13.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color(0xFF94A3B8),
                letterSpacing = 0.8.sp
            )
            Text(
                text = "Auto-calculated cycles: 1 to 10, 11 to 20, and 21 to 31",
                fontSize = 11.sp,
                color = Color(0xFF64748B)
            )
        }

        // 3 Cycles
        CycleCard(
            cycle = summary.cycle1Summary,
            onStatusChange = { newStatus -> viewModel.updateCycleStatus(1, newStatus) },
            modifier = Modifier.testTag("cycle_1_card")
        )

        CycleCard(
            cycle = summary.cycle2Summary,
            onStatusChange = { newStatus -> viewModel.updateCycleStatus(2, newStatus) },
            modifier = Modifier.testTag("cycle_2_card")
        )

        CycleCard(
            cycle = summary.cycle3Summary,
            onStatusChange = { newStatus -> viewModel.updateCycleStatus(3, newStatus) },
            modifier = Modifier.testTag("cycle_3_card")
        )

        Spacer(modifier = Modifier.height(20.dp))
    }
}
