package com.example.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.firebase.AuctionRepository
import com.example.data.firebase.extractFirestoreMessage
import com.example.data.model.Auction
import com.example.data.model.Bid
import com.example.data.model.UiState
import com.example.data.model.UserProfile
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class AuctionDetailViewModel(
    private val auctionRepo: AuctionRepository,
    private val auctionId: String,
    private val currentUserId: String
) : ViewModel() {

    private val _actionMessage = MutableStateFlow<String?>(null)
    val actionMessage: StateFlow<String?> = _actionMessage.asStateFlow()

    private val _isSubmitting = MutableStateFlow(false)
    val isSubmitting: StateFlow<Boolean> = _isSubmitting.asStateFlow()

    val auctionState: StateFlow<UiState<Auction?>> =
        auctionRepo.observeAuction(auctionId)
            .map<Auction?, UiState<Auction?>> { UiState.Success(it) }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                val root = firestoreError ?: error
                Log.w(TAG, "Error observing auction $auctionId", root)
                emit(UiState.Error(extractFirestoreMessage(root, "Failed to load auction details.")))
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000L),
                initialValue = UiState.Loading
            )

    val bidsState: StateFlow<UiState<List<Bid>>> =
        auctionRepo.observeAuctionBids(auctionId)
            .map<List<Bid>, UiState<List<Bid>>> { UiState.Success(it) }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                val root = firestoreError ?: error
                Log.w(TAG, "Error observing bids for $auctionId", root)
                emit(UiState.Error(extractFirestoreMessage(root, "Failed to load live bid ledger.")))
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000L),
                initialValue = UiState.Loading
            )

    fun clearMessage() {
        _actionMessage.value = null
    }

    fun placeBid(profile: UserProfile, amount: Long) {
        viewModelScope.launch {
            _isSubmitting.value = true
            val res = auctionRepo.placeBid(auctionId, profile, amount)
            _isSubmitting.value = false
            res.onSuccess {
                _actionMessage.value = "Bid of ₦$amount placed as ${profile.bidderNumber}!"
            }.onFailure { err ->
                _actionMessage.value = extractFirestoreMessage(err, "Bid rejected.")
            }
        }
    }

    fun settleAuction() {
        viewModelScope.launch {
            _isSubmitting.value = true
            val res = auctionRepo.settleWonAuction(currentUserId, auctionId)
            _isSubmitting.value = false
            res.onSuccess {
                _actionMessage.value = "Payment settled! Seller credited net of 3% True A commission."
            }.onFailure { err ->
                _actionMessage.value = extractFirestoreMessage(err, "Settlement failed.")
            }
        }
    }

    fun upgradeToFeatured(title: String) {
        viewModelScope.launch {
            _isSubmitting.value = true
            val res = auctionRepo.upgradeAuctionToFeatured(currentUserId, auctionId, title)
            _isSubmitting.value = false
            res.onSuccess {
                _actionMessage.value = "Listing promoted to Featured (₦2,000 fee)."
            }.onFailure { err ->
                _actionMessage.value = extractFirestoreMessage(err, "Could not feature listing.")
            }
        }
    }

    fun cancelBeforeBids() {
        viewModelScope.launch {
            _isSubmitting.value = true
            val res = auctionRepo.cancelAuctionBeforeBids(currentUserId, auctionId)
            _isSubmitting.value = false
            res.onSuccess {
                _actionMessage.value = "Auction listing cancelled."
            }.onFailure { err ->
                _actionMessage.value = extractFirestoreMessage(err, "Could not cancel listing.")
            }
        }
    }

    private companion object {
        const val TAG = "AuctionDetailVM"
    }
}
