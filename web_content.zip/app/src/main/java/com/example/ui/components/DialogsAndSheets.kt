package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.RadioButtonUnchecked
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import com.example.data.model.ProjectCategory
import com.example.data.model.ProjectEntity
import com.example.data.model.ProjectTemplateType
import com.example.data.model.ProjectWithStats
import com.example.data.model.SubtaskEntity
import com.example.data.model.TaskEntity
import com.example.data.model.TaskPriority
import com.example.data.model.TaskStatus
import com.example.data.model.TaskWithMeta
import com.example.ui.theme.ProjectAccentColors
import com.example.ui.theme.StatusDoneColor
import com.example.util.formatDurationPersian
import com.example.util.formatRelativeDateFa
import com.example.util.toPersianDigits

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun CreateEditProjectSheet(
    existingProject: ProjectEntity? = null,
    onDismiss: () -> Unit,
    onSave: (
        title: String,
        description: String,
        notes: String,
        budgetLabel: String,
        category: ProjectCategory,
        colorIndex: Int,
        targetDateMillis: Long?
    ) -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var title by remember { mutableStateOf(existingProject?.title ?: "") }
    var description by remember { mutableStateOf(existingProject?.description ?: "") }
    var notes by remember { mutableStateOf(existingProject?.notes ?: "") }
    var budgetLabel by remember { mutableStateOf(existingProject?.budgetLabel ?: "") }
    var category by remember {
        mutableStateOf(
            existingProject?.let { ProjectCategory.fromName(it.category) } ?: ProjectCategory.DEVELOPMENT
        )
    }
    var colorIndex by remember { mutableIntStateOf(existingProject?.colorIndex ?: 0) }
    var targetDateMillis by remember { mutableStateOf(existingProject?.targetDateMillis) }
    var showDatePicker by remember { mutableStateOf(false) }

    val now = remember { System.currentTimeMillis() }
    val dayMs = 86_400_000L

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                text = if (existingProject == null) "ساخت پروژه جدید" else "ویرایش پروژه",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )

            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("نام پروژه") },
                placeholder = { Text("مثلاً: طراحی وب‌سایت فروشگاهی") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("project_title_input")
            )

            OutlinedTextField(
                value = description,
                onValueChange = { description = it },
                label = { Text("خلاصه و هدف پروژه (اختیاری)") },
                placeholder = { Text("هدف و محدوده پروژه را بنویسید...") },
                minLines = 2,
                maxLines = 3,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("project_description_input")
            )

            OutlinedTextField(
                value = budgetLabel,
                onValueChange = { budgetLabel = it },
                label = { Text("بودجه / هدف کلیدی (اختیاری)") },
                placeholder = { Text("مثلاً: ۲۵ میلیون تومان یا ۵۰۰ کاربر فعال") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text("یادداشت‌های فنی یا اجرایی") },
                minLines = 2,
                maxLines = 4,
                modifier = Modifier.fillMaxWidth()
            )

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(text = "دسته‌بندی", style = MaterialTheme.typography.labelLarge)
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ProjectCategory.entries.forEach { item ->
                        FilterChip(
                            selected = category == item,
                            onClick = { category = item },
                            label = { Text(item.labelFa) },
                            leadingIcon = {
                                Icon(
                                    imageVector = item.icon(),
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        )
                    }
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(text = "رنگ اختصاصی پروژه", style = MaterialTheme.typography.labelLarge)
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    ProjectAccentColors.forEachIndexed { idx, color ->
                        val selected = colorIndex == idx
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(color)
                                .border(
                                    width = if (selected) 3.dp else 0.dp,
                                    color = if (selected) MaterialTheme.colorScheme.onSurface else Color.Transparent,
                                    shape = CircleShape
                                )
                                .clickable { colorIndex = idx },
                            contentAlignment = Alignment.Center
                        ) {
                            if (selected) {
                                Icon(
                                    imageVector = Icons.Rounded.Check,
                                    contentDescription = "انتخاب شده",
                                    tint = Color.White,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "موعد تحویل: ${formatRelativeDateFa(targetDateMillis)}",
                    style = MaterialTheme.typography.labelLarge
                )
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = targetDateMillis == null,
                        onClick = { targetDateMillis = null },
                        label = { Text("بدون تاریخ") }
                    )
                    FilterChip(
                        selected = false,
                        onClick = { targetDateMillis = now + 7 * dayMs },
                        label = { Text("۱ هفته دیگر") }
                    )
                    FilterChip(
                        selected = false,
                        onClick = { targetDateMillis = now + 14 * dayMs },
                        label = { Text("۲ هفته دیگر") }
                    )
                    FilterChip(
                        selected = false,
                        onClick = { targetDateMillis = now + 30 * dayMs },
                        label = { Text("۱ ماه دیگر") }
                    )
                    OutlinedButton(
                        onClick = { showDatePicker = true },
                        modifier = Modifier.minimumInteractiveComponentSize()
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.CalendarMonth,
                            contentDescription = "انتخاب تاریخ",
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("تقویم")
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = onDismiss,
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                ) {
                    Text("انصراف")
                }
                Button(
                    onClick = {
                        onSave(title, description, notes, budgetLabel, category, colorIndex, targetDateMillis)
                    },
                    enabled = title.isNotBlank(),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("save_project_button")
                ) {
                    Text(if (existingProject == null) "ایجاد پروژه" else "ذخیره تغییرات")
                }
            }
        }
    }

    if (showDatePicker) {
        val datePickerState = rememberDatePickerState(initialSelectedDateMillis = targetDateMillis ?: now)
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        targetDateMillis = datePickerState.selectedDateMillis
                        showDatePicker = false
                    }
                ) { Text("تأیید") }
            },
            dismissButton = {
                TextButton(onClick = { showDatePicker = false }) { Text("بستن") }
            }
        ) {
            DatePicker(state = datePickerState)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun CreateEditTaskSheet(
    projects: List<ProjectWithStats>,
    initialProjectId: Long?,
    initialStatus: TaskStatus = TaskStatus.TODO,
    existingTask: TaskEntity? = null,
    onDismiss: () -> Unit,
    onSave: (
        projectId: Long,
        title: String,
        description: String,
        priority: TaskPriority,
        status: TaskStatus,
        dueDateMillis: Long?,
        estimatedMinutes: Int,
        storyPoints: Int,
        assigneeName: String,
        tag: String
    ) -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var selectedProjectId by remember {
        mutableStateOf(
            existingTask?.projectId ?: initialProjectId ?: projects.firstOrNull()?.project?.id ?: 0L
        )
    }
    var title by remember { mutableStateOf(existingTask?.title ?: "") }
    var description by remember { mutableStateOf(existingTask?.description ?: "") }
    var priority by remember {
        mutableStateOf(existingTask?.let { TaskPriority.fromName(it.priority) } ?: TaskPriority.MEDIUM)
    }
    var status by remember {
        mutableStateOf(existingTask?.let { TaskStatus.fromName(it.status) } ?: initialStatus)
    }
    var dueDateMillis by remember { mutableStateOf(existingTask?.dueDateMillis) }
    var estimatedMinutes by remember { mutableIntStateOf(existingTask?.estimatedMinutes ?: 45) }
    var storyPoints by remember { mutableIntStateOf(existingTask?.storyPoints ?: 3) }
    var assigneeName by remember { mutableStateOf(existingTask?.assigneeName ?: "") }
    var tag by remember { mutableStateOf(existingTask?.tag ?: "") }
    var showDatePicker by remember { mutableStateOf(false) }

    val now = remember { System.currentTimeMillis() }
    val dayMs = 86_400_000L

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                text = if (existingTask == null) "افزودن تسک جدید" else "ویرایش تسک",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )

            if (projects.isNotEmpty() && existingTask == null) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("پروژه مرتبط", style = MaterialTheme.typography.labelLarge)
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        projects.forEach { proj ->
                            FilterChip(
                                selected = selectedProjectId == proj.project.id,
                                onClick = { selectedProjectId = proj.project.id },
                                label = { Text(proj.project.title) }
                            )
                        }
                    }
                }
            }

            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("عنوان تسک") },
                placeholder = { Text("چه کاری باید انجام شود؟") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("task_title_input")
            )

            OutlinedTextField(
                value = description,
                onValueChange = { description = it },
                label = { Text("جزئیات یا یادداشت") },
                minLines = 2,
                maxLines = 4,
                modifier = Modifier.fillMaxWidth()
            )

            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("وضعیت در کانبان", style = MaterialTheme.typography.labelLarge)
                SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                    TaskStatus.entries.forEachIndexed { idx, item ->
                        SegmentedButton(
                            selected = status == item,
                            onClick = { status = item },
                            shape = SegmentedButtonDefaults.itemShape(idx, TaskStatus.entries.size)
                        ) {
                            Text(item.labelFa, style = MaterialTheme.typography.labelMedium)
                        }
                    }
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("اولویت", style = MaterialTheme.typography.labelLarge)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TaskPriority.entries.forEach { item ->
                        FilterChip(
                            selected = priority == item,
                            onClick = { priority = item },
                            label = { Text(item.labelFa) }
                        )
                    }
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("امتیاز پیچیدگی (Story Points)", style = MaterialTheme.typography.labelLarge)
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(1, 2, 3, 5, 8, 13).forEach { pts ->
                        FilterChip(
                            selected = storyPoints == pts,
                            onClick = { storyPoints = pts },
                            label = { Text("${pts.toPersianDigits()} امتیاز") }
                        )
                    }
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("مسئول انجام", style = MaterialTheme.typography.labelLarge)
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf("خودم", "تیم فنی", "تیم طراحی", "تیم محتوا").forEach { preset ->
                        FilterChip(
                            selected = assigneeName == preset,
                            onClick = { assigneeName = if (assigneeName == preset) "" else preset },
                            label = { Text(preset) },
                            leadingIcon = {
                                Icon(Icons.Rounded.Person, contentDescription = null, modifier = Modifier.size(14.dp))
                            }
                        )
                    }
                }
                OutlinedTextField(
                    value = assigneeName,
                    onValueChange = { assigneeName = it },
                    placeholder = { Text("یا نام مسئول را بنویسید...") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = tag,
                    onValueChange = { tag = it },
                    label = { Text("برچسب (تگ)") },
                    placeholder = { Text("مثلاً: طراحی") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text("زمان تخمینی", style = MaterialTheme.typography.labelMedium)
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(25, 45, 90, 120).forEach { mins ->
                            FilterChip(
                                selected = estimatedMinutes == mins,
                                onClick = { estimatedMinutes = mins },
                                label = { Text("${mins.toPersianDigits()}د") }
                            )
                        }
                    }
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = "سررسید: ${formatRelativeDateFa(dueDateMillis)}",
                    style = MaterialTheme.typography.labelLarge
                )
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = dueDateMillis == null,
                        onClick = { dueDateMillis = null },
                        label = { Text("بدون تاریخ") }
                    )
                    FilterChip(
                        selected = false,
                        onClick = { dueDateMillis = now },
                        label = { Text("امروز") }
                    )
                    FilterChip(
                        selected = false,
                        onClick = { dueDateMillis = now + dayMs },
                        label = { Text("فردا") }
                    )
                    FilterChip(
                        selected = false,
                        onClick = { dueDateMillis = now + 3 * dayMs },
                        label = { Text("۳ روز دیگر") }
                    )
                    OutlinedButton(onClick = { showDatePicker = true }) {
                        Icon(Icons.Rounded.CalendarMonth, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("تقویم")
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = onDismiss,
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                ) {
                    Text("انصراف")
                }
                Button(
                    onClick = {
                        onSave(
                            selectedProjectId,
                            title,
                            description,
                            priority,
                            status,
                            dueDateMillis,
                            estimatedMinutes,
                            storyPoints,
                            assigneeName,
                            tag
                        )
                    },
                    enabled = title.isNotBlank() && selectedProjectId != 0L,
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("save_task_button")
                ) {
                    Text(if (existingTask == null) "ثبت تسک" else "ذخیره تغییرات")
                }
            }
        }
    }

    if (showDatePicker) {
        val datePickerState = rememberDatePickerState(initialSelectedDateMillis = dueDateMillis ?: now)
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        dueDateMillis = datePickerState.selectedDateMillis
                        showDatePicker = false
                    }
                ) { Text("تأیید") }
            },
            dismissButton = {
                TextButton(onClick = { showDatePicker = false }) { Text("بستن") }
            }
        ) {
            DatePicker(state = datePickerState)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TaskDetailSheet(
    taskMeta: TaskWithMeta,
    onDismiss: () -> Unit,
    onMoveStatus: (TaskStatus) -> Unit,
    onEditTask: () -> Unit,
    onDuplicateTask: () -> Unit,
    onDeleteTask: () -> Unit,
    onStartFocus: () -> Unit,
    onAddSubtask: (String) -> Unit,
    onToggleSubtask: (SubtaskEntity) -> Unit,
    onDeleteSubtask: (SubtaskEntity) -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val task = taskMeta.task
    val status = TaskStatus.fromName(task.status)
    val priority = TaskPriority.fromName(task.priority)
    var newSubtaskTitle by remember { mutableStateOf("") }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    PriorityPill(priority = priority)
                    Surface(
                        color = projectAccentColor(taskMeta.projectColorIndex).copy(alpha = 0.14f),
                        shape = RoundedCornerShape(50)
                    ) {
                        Text(
                            text = taskMeta.projectTitle,
                            style = MaterialTheme.typography.labelSmall,
                            color = projectAccentColor(taskMeta.projectColorIndex),
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }

                Row {
                    IconButton(
                        onClick = onDuplicateTask,
                        modifier = Modifier.testTag("detail_duplicate_task_button")
                    ) {
                        Icon(Icons.Rounded.ContentCopy, contentDescription = "تکثیر تسک")
                    }
                    IconButton(
                        onClick = onEditTask,
                        modifier = Modifier.testTag("detail_edit_task_button")
                    ) {
                        Icon(Icons.Rounded.Edit, contentDescription = "ویرایش تسک")
                    }
                    IconButton(
                        onClick = onDeleteTask,
                        modifier = Modifier.testTag("detail_delete_task_button")
                    ) {
                        Icon(
                            Icons.Rounded.DeleteOutline,
                            contentDescription = "حذف تسک",
                            tint = MaterialTheme.colorScheme.error
                        )
                    }
                }
            }

            Text(
                text = task.title,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )

            if (task.description.isNotBlank()) {
                Text(
                    text = task.description,
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                shape = MaterialTheme.shapes.medium
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("سررسید", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(formatRelativeDateFa(task.dueDateMillis), style = MaterialTheme.typography.labelLarge)
                    }
                    Column {
                        Text("امتیاز", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("${task.storyPoints.toPersianDigits()} امتیاز", style = MaterialTheme.typography.labelLarge)
                    }
                    Column {
                        Text("مسئول", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(task.assigneeName.ifBlank { "تعیین‌نشده" }, style = MaterialTheme.typography.labelLarge)
                    }
                    Column {
                        Text("تمرکز", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(formatDurationPersian(task.focusMinutesSpent), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.secondary)
                    }
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("تغییر وضعیت در کانبان", style = MaterialTheme.typography.labelLarge)
                SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                    TaskStatus.entries.forEachIndexed { idx, item ->
                        SegmentedButton(
                            selected = status == item,
                            onClick = { onMoveStatus(item) },
                            shape = SegmentedButtonDefaults.itemShape(idx, TaskStatus.entries.size)
                        ) {
                            Text(item.labelFa, style = MaterialTheme.typography.labelMedium)
                        }
                    }
                }
            }

            Button(
                onClick = onStartFocus,
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.secondary,
                    contentColor = MaterialTheme.colorScheme.onSecondary
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("start_focus_for_task_button")
            ) {
                Icon(Icons.Rounded.PlayArrow, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("شروع جلسه تمرکز برای این تسک")
            }

            HorizontalDivider()

            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "زیرتسک‌ها (${taskMeta.completedSubtasksCount.toPersianDigits()}/${taskMeta.subtasks.size.toPersianDigits()})",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = newSubtaskTitle,
                        onValueChange = { newSubtaskTitle = it },
                        placeholder = { Text("افزودن مرحله جدید...") },
                        singleLine = true,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("subtask_input")
                    )
                    Surface(
                        onClick = {
                            if (newSubtaskTitle.isNotBlank()) {
                                onAddSubtask(newSubtaskTitle)
                                newSubtaskTitle = ""
                            }
                        },
                        color = MaterialTheme.colorScheme.primary,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .size(52.dp)
                            .testTag("add_subtask_button")
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Rounded.Add,
                                contentDescription = "افزودن زیرتسک",
                                tint = MaterialTheme.colorScheme.onPrimary
                            )
                        }
                    }
                }

                if (taskMeta.subtasks.isEmpty()) {
                    Text(
                        text = "هنوز زیرتسکی تعریف نشده است.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    taskMeta.subtasks.forEach { sub ->
                        Surface(
                            color = MaterialTheme.colorScheme.surface,
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onToggleSubtask(sub) }
                                    .padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = if (sub.isCompleted) Icons.Rounded.CheckCircle else Icons.Rounded.RadioButtonUnchecked,
                                    contentDescription = if (sub.isCompleted) "تکمیل شده" else "انجام نشده",
                                    tint = if (sub.isCompleted) StatusDoneColor else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = sub.title,
                                    style = MaterialTheme.typography.bodyMedium,
                                    textDecoration = if (sub.isCompleted) TextDecoration.LineThrough else TextDecoration.None,
                                    color = if (sub.isCompleted) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.weight(1f)
                                )
                                IconButton(
                                    onClick = { onDeleteSubtask(sub) },
                                    modifier = Modifier.minimumInteractiveComponentSize()
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.Close,
                                        contentDescription = "حذف زیرتسک",
                                        modifier = Modifier.size(18.dp),
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TemplatesBottomSheet(
    onDismiss: () -> Unit,
    onSelectTemplate: (ProjectTemplateType) -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(Icons.Rounded.AutoAwesome, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Text(
                    text = "گالری قالب‌های آماده پروژه",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold
                )
            }
            Text(
                text = "با یک لمس، پروژه کامل به همراه مایلستون‌ها و تسک‌های استاندارد ساخته می‌شود.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            ProjectTemplateType.entries.forEach { template ->
                val accent = projectAccentColor(template.colorIndex)
                Card(
                    onClick = { onSelectTemplate(template) },
                    shape = MaterialTheme.shapes.large,
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("template_${template.name.lowercase()}")
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Surface(
                            color = accent.copy(alpha = 0.16f),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.size(46.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = template.category.icon(),
                                    contentDescription = template.titleFa,
                                    tint = accent,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }
                        Column(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = template.titleFa,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = template.subtitleFa,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun EditWorkspaceProfileDialog(
    currentOwnerName: String,
    onDismiss: () -> Unit,
    onSave: (String) -> Unit
) {
    var nameInput by remember { mutableStateOf(currentOwnerName) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("پروفایل فضای کاری شخصی") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "نام خود یا عنوان فضای کاری شخصی روی موبایل را وارد کنید. تمام پروژه‌ها و تسک‌ها به‌صورت امن و آفلاین روی همین گوشی ذخیره می‌شوند.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                OutlinedTextField(
                    value = nameInput,
                    onValueChange = { nameInput = it },
                    label = { Text("نام مالک یا فضای کاری") },
                    placeholder = { Text("مثلاً: فضای کاری علی") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("owner_name_input")
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(nameInput) },
                enabled = nameInput.isNotBlank(),
                modifier = Modifier.testTag("save_owner_name_button")
            ) {
                Text("ذخیره")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("انصراف")
            }
        }
    )
}
