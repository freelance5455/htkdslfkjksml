package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.PrimaryTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.R
import com.example.data.NoteEntity
import com.example.data.PrincipleEntity
import com.example.data.PrinciplePhase

@Composable
fun NotesScreen(
    notes: List<NoteEntity>,
    currentBoardFen: String,
    onSaveNote: (
        existingId: String?,
        title: String,
        content: String,
        tags: String,
        attachCurrentBoardFen: Boolean,
        existingLinkedFen: String?,
        isPinned: Boolean
    ) -> Unit,
    onTogglePin: (NoteEntity) -> Unit,
    onDeleteNote: (String) -> Unit,
    onLoadFenOnBoard: (fen: String, title: String) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onBack)

    var searchQuery by remember { mutableStateOf("") }
    var editingNote by remember { mutableStateOf<NoteEntity?>(null) }
    var showEditorDialog by remember { mutableStateOf(false) }

    val filteredNotes = remember(notes, searchQuery) {
        if (searchQuery.isBlank()) notes
        else notes.filter {
            it.title.contains(searchQuery, ignoreCase = true) ||
                it.content.contains(searchQuery, ignoreCase = true) ||
                it.tags.contains(searchQuery, ignoreCase = true)
        }
    }

    Box(
        contentAlignment = Alignment.TopCenter,
        modifier = modifier
            .fillMaxSize()
            .testTag("notes_screen")
    ) {
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 640.dp)
        ) {
            item {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("My Study Notes", style = MaterialTheme.typography.headlineSmall)
                        Text(
                            "Write your own chess study notes and attach board positions.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Button(
                        onClick = {
                            editingNote = null
                            showEditorDialog = true
                        },
                        modifier = Modifier.height(48.dp).testTag("new_note_button")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("New Note")
                    }
                }
            }

            item {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    placeholder = { Text("Search your notes or tags...") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("search_notes_input")
                )
            }

            if (filteredNotes.isEmpty()) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("empty_notes_placeholder")
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp)
                        ) {
                            Text(
                                text = stringResource(R.string.empty_notes_title),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(Modifier.height(6.dp))
                            Text(
                                text = stringResource(R.string.empty_notes_subtitle),
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            } else {
                items(filteredNotes, key = { it.id }) { note ->
                    Card(
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                editingNote = note
                                showEditorDialog = true
                            }
                            .testTag("note_card_${note.id}")
                    ) {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.padding(14.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = note.title,
                                    style = MaterialTheme.typography.titleMedium,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f)
                                )
                                Row {
                                    IconButton(onClick = { onTogglePin(note) }, modifier = Modifier.size(40.dp)) {
                                        Icon(
                                            Icons.Default.PushPin,
                                            contentDescription = "Pin note",
                                            tint = if (note.isPinned) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                                        )
                                    }
                                    IconButton(
                                        onClick = {
                                            editingNote = note
                                            showEditorDialog = true
                                        },
                                        modifier = Modifier.size(40.dp)
                                    ) {
                                        Icon(Icons.Default.Edit, contentDescription = "Edit note")
                                    }
                                    IconButton(
                                        onClick = { onDeleteNote(note.id) },
                                        modifier = Modifier.size(40.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.Delete,
                                            contentDescription = "Delete note",
                                            tint = MaterialTheme.colorScheme.error
                                        )
                                    }
                                }
                            }

                            if (note.content.isNotBlank()) {
                                Text(
                                    text = note.content,
                                    style = MaterialTheme.typography.bodyMedium,
                                    maxLines = 5,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }

                            if (note.tags.isNotBlank()) {
                                Text(
                                    text = "Tags: ${note.tags}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }

                            if (!note.linkedFen.isNullOrBlank()) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    MiniChessboardPreview(fen = note.linkedFen, modifier = Modifier.size(56.dp))
                                    OutlinedButton(
                                        onClick = { onLoadFenOnBoard(note.linkedFen, note.title) }
                                    ) {
                                        Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(4.dp))
                                        Text("Load Position on Board", fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showEditorDialog) {
        val initial = editingNote
        var title by remember(initial) { mutableStateOf(initial?.title ?: "") }
        var content by remember(initial) { mutableStateOf(initial?.content ?: "") }
        var tags by remember(initial) { mutableStateOf(initial?.tags ?: "") }
        var attachBoard by remember(initial) { mutableStateOf(false) }

        Dialog(onDismissRequest = { showEditorDialog = false }) {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surface,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier
                        .padding(16.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            if (initial == null) "New Study Note" else "Edit Study Note",
                            style = MaterialTheme.typography.titleMedium
                        )
                        IconButton(onClick = { showEditorDialog = false }) {
                            Icon(Icons.Default.Close, contentDescription = "Close")
                        }
                    }

                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("Title") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("note_title_input")
                    )

                    OutlinedTextField(
                        value = content,
                        onValueChange = { content = it },
                        label = { Text("Your Notes") },
                        minLines = 4,
                        modifier = Modifier.fillMaxWidth().testTag("note_content_input")
                    )

                    OutlinedTextField(
                        value = tags,
                        onValueChange = { tags = it },
                        label = { Text("Tags (optional, comma-separated)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { attachBoard = !attachBoard }
                    ) {
                        Checkbox(checked = attachBoard, onCheckedChange = { attachBoard = it })
                        Spacer(Modifier.width(6.dp))
                        Text("Attach current analysis board position", style = MaterialTheme.typography.bodyMedium)
                    }

                    if (attachBoard) {
                        MiniChessboardPreview(fen = currentBoardFen, modifier = Modifier.size(72.dp))
                    }

                    Button(
                        onClick = {
                            onSaveNote(
                                initial?.id,
                                title,
                                content,
                                tags,
                                attachBoard,
                                initial?.linkedFen,
                                initial?.isPinned ?: false
                            )
                            showEditorDialog = false
                        },
                        enabled = title.isNotBlank() || content.isNotBlank(),
                        modifier = Modifier.fillMaxWidth().testTag("save_note_submit_button")
                    ) {
                        Text("Save Note")
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PrinciplesScreen(
    principles: List<PrincipleEntity>,
    currentBoardFen: String,
    onSavePrinciple: (
        existingId: String?,
        phase: PrinciplePhase,
        title: String,
        description: String,
        attachCurrentBoardFen: Boolean,
        existingLinkedFen: String?
    ) -> Unit,
    onDeletePrinciple: (String) -> Unit,
    onLoadFenOnBoard: (fen: String, title: String) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onBack)

    var selectedPhase by remember { mutableStateOf(PrinciplePhase.OPENING) }
    var searchQuery by remember { mutableStateOf("") }
    var editingPrinciple by remember { mutableStateOf<PrincipleEntity?>(null) }
    var showEditorDialog by remember { mutableStateOf(false) }

    val phasePrinciples = remember(principles, selectedPhase, searchQuery) {
        principles
            .filter { it.phase == selectedPhase.name }
            .filter {
                searchQuery.isBlank() ||
                    it.title.contains(searchQuery, ignoreCase = true) ||
                    it.description.contains(searchQuery, ignoreCase = true)
            }
    }

    Box(
        contentAlignment = Alignment.TopCenter,
        modifier = modifier
            .fillMaxSize()
            .testTag("principles_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 640.dp)
        ) {
            // Three-Part Phase Tabs: Opening | Middlegame | Endgame
            PrimaryTabRow(
                selectedTabIndex = selectedPhase.ordinal,
                modifier = Modifier.fillMaxWidth()
            ) {
                for (phase in PrinciplePhase.entries) {
                    val count = principles.count { it.phase == phase.name }
                    Tab(
                        selected = selectedPhase == phase,
                        onClick = { selectedPhase = phase },
                        text = {
                            Text(
                                text = "${phase.label} ($count)",
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        },
                        modifier = Modifier.testTag("principle_tab_${phase.name.lowercase()}")
                    )
                }
            }

            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                item {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                "${selectedPhase.label} Principles",
                                style = MaterialTheme.typography.titleLarge
                            )
                            Text(
                                "Record your personal ${selectedPhase.label.lowercase()} rules from books and games.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Button(
                            onClick = {
                                editingPrinciple = null
                                showEditorDialog = true
                            },
                            modifier = Modifier.height(48.dp).testTag("add_principle_button")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Add")
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                        placeholder = { Text("Filter ${selectedPhase.label.lowercase()} principles...") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                if (phasePrinciples.isEmpty()) {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("empty_principles_placeholder")
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(24.dp)
                            ) {
                                Text(
                                    text = stringResource(R.string.empty_principles_title, selectedPhase.label),
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(Modifier.height(6.dp))
                                Text(
                                    text = stringResource(R.string.empty_principles_subtitle, selectedPhase.label.lowercase()),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                } else {
                    items(phasePrinciples, key = { it.id }) { item ->
                        Card(
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    editingPrinciple = item
                                    showEditorDialog = true
                                }
                                .testTag("principle_card_${item.id}")
                        ) {
                            Column(
                                verticalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.padding(14.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        text = item.title,
                                        style = MaterialTheme.typography.titleMedium,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Row {
                                        IconButton(
                                            onClick = {
                                                editingPrinciple = item
                                                showEditorDialog = true
                                            },
                                            modifier = Modifier.size(40.dp)
                                        ) {
                                            Icon(Icons.Default.Edit, contentDescription = "Edit principle")
                                        }
                                        IconButton(
                                            onClick = { onDeletePrinciple(item.id) },
                                            modifier = Modifier.size(40.dp)
                                        ) {
                                            Icon(
                                                Icons.Default.Delete,
                                                contentDescription = "Delete principle",
                                                tint = MaterialTheme.colorScheme.error
                                            )
                                        }
                                    }
                                }

                                if (item.description.isNotBlank()) {
                                    Text(
                                        text = item.description,
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                }

                                if (!item.linkedFen.isNullOrBlank()) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        MiniChessboardPreview(fen = item.linkedFen, modifier = Modifier.size(56.dp))
                                        OutlinedButton(onClick = { onLoadFenOnBoard(item.linkedFen, item.title) }) {
                                            Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(Modifier.width(4.dp))
                                            Text("Show on Board", fontSize = 12.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showEditorDialog) {
        val initial = editingPrinciple
        var draftPhase by remember(initial, selectedPhase) {
            mutableStateOf(
                initial?.let { runCatching { PrinciplePhase.valueOf(it.phase) }.getOrNull() } ?: selectedPhase
            )
        }
        var title by remember(initial) { mutableStateOf(initial?.title ?: "") }
        var description by remember(initial) { mutableStateOf(initial?.description ?: "") }
        var attachBoard by remember(initial) { mutableStateOf(false) }

        Dialog(onDismissRequest = { showEditorDialog = false }) {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surface,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier
                        .padding(16.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            if (initial == null) "Add Chess Principle" else "Edit Chess Principle",
                            style = MaterialTheme.typography.titleMedium
                        )
                        IconButton(onClick = { showEditorDialog = false }) {
                            Icon(Icons.Default.Close, contentDescription = "Close")
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        for (p in PrinciplePhase.entries) {
                            FilterChip(
                                selected = draftPhase == p,
                                onClick = { draftPhase = p },
                                label = { Text(p.label, fontSize = 12.sp) }
                            )
                        }
                    }

                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("Principle Heading") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("principle_title_input")
                    )

                    OutlinedTextField(
                        value = description,
                        onValueChange = { description = it },
                        label = { Text("Details / Example") },
                        minLines = 3,
                        modifier = Modifier.fillMaxWidth().testTag("principle_desc_input")
                    )

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { attachBoard = !attachBoard }
                    ) {
                        Checkbox(checked = attachBoard, onCheckedChange = { attachBoard = it })
                        Spacer(Modifier.width(6.dp))
                        Text("Attach current analysis board position", style = MaterialTheme.typography.bodyMedium)
                    }

                    Button(
                        onClick = {
                            onSavePrinciple(
                                initial?.id,
                                draftPhase,
                                title,
                                description,
                                attachBoard,
                                initial?.linkedFen
                            )
                            selectedPhase = draftPhase
                            showEditorDialog = false
                        },
                        enabled = title.isNotBlank() || description.isNotBlank(),
                        modifier = Modifier.fillMaxWidth().testTag("save_principle_submit_button")
                    ) {
                        Text("Save Principle")
                    }
                }
            }
        }
    }
}
