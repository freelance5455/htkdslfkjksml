package com.example.ui

import androidx.compose.animation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.model.*
import com.example.data.repository.IgnisRepository
import com.example.ui.components.IgnisTopAppBar
import com.example.ui.components.LocationExplanationDialog
import com.example.ui.components.ReviewDialog
import com.example.ui.screens.*
import com.example.ui.screens.chat.ChatScreen
import com.example.ui.screens.consumer.*
import com.example.ui.screens.delivery.DeliveryPartnerDashboardScreen
import com.example.ui.screens.delivery.DeliveryWorkflowScreen
import com.example.ui.screens.seller.*
import com.example.ui.theme.*

sealed class ScreenDestination {
    object Main : ScreenDestination()
    data class ProductDetail(val product: Product) : ScreenDestination()
    data class SellerSpaceView(val space: SellerSpace) : ScreenDestination()
    object Checkout : ScreenDestination()
    object Notifications : ScreenDestination()
    object AddProduct : ScreenDestination()
    object PostInnovation : ScreenDestination()
    object SellerEarnings : ScreenDestination()
    data class DeliveryWorkflow(val order: Order) : ScreenDestination()
}

@Composable
fun IgnisApp(
    repository: IgnisRepository = remember { IgnisRepository.getInstance() }
) {
    var showSplash by remember { mutableStateOf(true) }
    val onboardingCompleted by repository.onboardingCompleted.collectAsState()
    val selectedRole by repository.selectedRole.collectAsState()
    val currentUser by repository.currentUser.collectAsState()
    val locationGranted by repository.locationGranted.collectAsState()
    val approxLocation by repository.approximateLocation.collectAsState()
    val products by repository.products.collectAsState()
    val sellerSpaces by repository.sellerSpaces.collectAsState()
    val deliveryPartners by repository.deliveryPartners.collectAsState()
    val cart by repository.cart.collectAsState()
    val orders by repository.orders.collectAsState()
    val chats by repository.chats.collectAsState()
    val notifications by repository.notifications.collectAsState()
    val commissionConfig by repository.commissionConfig.collectAsState()

    var activeTab by remember { mutableStateOf(0) }
    var selectedCategory by remember { mutableStateOf("All") }
    var selectedChatId by remember { mutableStateOf<String?>(null) }
    var currentDestination by remember { mutableStateOf<ScreenDestination>(ScreenDestination.Main) }
    var showLocationDialog by remember { mutableStateOf(false) }
    var reviewTargetOrder by remember { mutableStateOf<Order?>(null) }
    var orderToHighlightId by remember { mutableStateOf<String?>(null) }

    // Reset tab if role changes
    LaunchedEffect(selectedRole) {
        activeTab = 0
        currentDestination = ScreenDestination.Main
    }

    if (showSplash) {
        SplashScreen(onSplashComplete = { showSplash = false })
        return
    }

    if (!onboardingCompleted) {
        OnboardingScreen(
            onFinishOnboarding = { name, role, age, profession, location, granted ->
                repository.completeOnboarding(name, role, age, profession, location, granted)
            }
        )
        return
    }

    // Location Dialog handler
    if (showLocationDialog) {
        LocationExplanationDialog(
            onDismiss = { showLocationDialog = false },
            onGrant = {
                repository.setLocationPermission(true, "Downtown Innovation District (~1.8 km)")
                showLocationDialog = false
            },
            onDeny = {
                repository.setLocationPermission(false)
                showLocationDialog = false
            }
        )
    }

    // Review Dialog handler
    reviewTargetOrder?.let { order ->
        ReviewDialog(
            order = order,
            onDismiss = { reviewTargetOrder = null },
            onSubmit = { rating, feedback ->
                reviewTargetOrder = null
            }
        )
    }

    Scaffold(
        topBar = {
            if (currentDestination == ScreenDestination.Main) {
                IgnisTopAppBar(
                    currentRole = selectedRole,
                    approxLocation = approxLocation,
                    unreadNotifications = notifications.count { !it.isRead },
                    onLocationClick = { showLocationDialog = true },
                    onNotificationClick = { currentDestination = ScreenDestination.Notifications },
                    onRoleSelect = { newRole -> repository.setRole(newRole) }
                )
            }
        },
        bottomBar = {
            if (currentDestination == ScreenDestination.Main) {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 6.dp
                ) {
                    when (selectedRole) {
                        UserRole.CONSUMER -> {
                            NavigationBarItem(
                                selected = activeTab == 0,
                                onClick = { activeTab = 0 },
                                icon = { Icon(if (activeTab == 0) Icons.Filled.Home else Icons.Outlined.Home, contentDescription = "Home") },
                                label = { Text("Home") },
                                modifier = Modifier.testTag("nav_home")
                            )
                            NavigationBarItem(
                                selected = activeTab == 1,
                                onClick = { activeTab = 1 },
                                icon = { Icon(if (activeTab == 1) Icons.Filled.Search else Icons.Outlined.Search, contentDescription = "Explore") },
                                label = { Text("Explore") },
                                modifier = Modifier.testTag("nav_explore")
                            )
                            NavigationBarItem(
                                selected = activeTab == 2,
                                onClick = { activeTab = 2 },
                                icon = {
                                    BadgedBox(
                                        badge = {
                                            if (cart.isNotEmpty()) {
                                                Badge(containerColor = IgnisOrangePrimary) {
                                                    Text("${cart.sumOf { it.quantity }}")
                                                }
                                            }
                                        }
                                    ) {
                                        Icon(if (activeTab == 2) Icons.Filled.ShoppingCart else Icons.Outlined.ShoppingCart, contentDescription = "Cart")
                                    }
                                },
                                label = { Text("Cart") },
                                modifier = Modifier.testTag("nav_cart")
                            )
                            NavigationBarItem(
                                selected = activeTab == 3,
                                onClick = { activeTab = 3 },
                                icon = { Icon(if (activeTab == 3) Icons.Filled.ReceiptLong else Icons.Outlined.ReceiptLong, contentDescription = "Orders") },
                                label = { Text("Orders") },
                                modifier = Modifier.testTag("nav_orders")
                            )
                            NavigationBarItem(
                                selected = activeTab == 4,
                                onClick = { activeTab = 4 },
                                icon = { Icon(if (activeTab == 4) Icons.Filled.ChatBubble else Icons.Outlined.ChatBubbleOutline, contentDescription = "Chat") },
                                label = { Text("Chat") },
                                modifier = Modifier.testTag("nav_chat")
                            )
                            NavigationBarItem(
                                selected = activeTab == 5,
                                onClick = { activeTab = 5 },
                                icon = { Icon(if (activeTab == 5) Icons.Filled.Person else Icons.Outlined.Person, contentDescription = "Profile") },
                                label = { Text("Profile") },
                                modifier = Modifier.testTag("nav_profile")
                            )
                        }
                        UserRole.SELLER -> {
                            NavigationBarItem(
                                selected = activeTab == 0,
                                onClick = { activeTab = 0 },
                                icon = { Icon(if (activeTab == 0) Icons.Filled.Dashboard else Icons.Outlined.Dashboard, contentDescription = "Dashboard") },
                                label = { Text("Hub") },
                                modifier = Modifier.testTag("nav_seller_hub")
                            )
                            NavigationBarItem(
                                selected = activeTab == 1,
                                onClick = { activeTab = 1 },
                                icon = { Icon(if (activeTab == 1) Icons.Filled.ChatBubble else Icons.Outlined.ChatBubbleOutline, contentDescription = "Messages") },
                                label = { Text("Messages") },
                                modifier = Modifier.testTag("nav_seller_messages")
                            )
                            NavigationBarItem(
                                selected = activeTab == 2,
                                onClick = { currentDestination = ScreenDestination.SellerEarnings },
                                icon = { Icon(Icons.Outlined.AccountBalanceWallet, contentDescription = "Revenue") },
                                label = { Text("Revenue") },
                                modifier = Modifier.testTag("nav_seller_revenue")
                            )
                            NavigationBarItem(
                                selected = activeTab == 3,
                                onClick = { activeTab = 3 },
                                icon = { Icon(if (activeTab == 3) Icons.Filled.Person else Icons.Outlined.Person, contentDescription = "Settings") },
                                label = { Text("Profile") },
                                modifier = Modifier.testTag("nav_seller_profile")
                            )
                        }
                        UserRole.DELIVERY_PARTNER -> {
                            NavigationBarItem(
                                selected = activeTab == 0,
                                onClick = { activeTab = 0 },
                                icon = { Icon(if (activeTab == 0) Icons.Filled.TwoWheeler else Icons.Outlined.TwoWheeler, contentDescription = "Dispatch") },
                                label = { Text("Dispatch") },
                                modifier = Modifier.testTag("nav_delivery_dispatch")
                            )
                            NavigationBarItem(
                                selected = activeTab == 1,
                                onClick = { activeTab = 1 },
                                icon = { Icon(if (activeTab == 1) Icons.Filled.ChatBubble else Icons.Outlined.ChatBubbleOutline, contentDescription = "Comms") },
                                label = { Text("Comms") },
                                modifier = Modifier.testTag("nav_delivery_comms")
                            )
                            NavigationBarItem(
                                selected = activeTab == 2,
                                onClick = { activeTab = 2 },
                                icon = { Icon(if (activeTab == 2) Icons.Filled.Person else Icons.Outlined.Person, contentDescription = "Profile") },
                                label = { Text("Profile") },
                                modifier = Modifier.testTag("nav_delivery_profile")
                            )
                        }
                    }
                }
            }
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            when (val dest = currentDestination) {
                is ScreenDestination.ProductDetail -> {
                    ProductDetailScreen(
                        product = dest.product,
                        onBack = { currentDestination = ScreenDestination.Main },
                        onAddToCart = { prod, qty -> repository.addToCart(prod, qty) },
                        onBuyNow = { prod, qty ->
                            repository.addToCart(prod, qty)
                            currentDestination = ScreenDestination.Checkout
                        },
                        onChatWithSeller = { prod ->
                            val chatId = repository.getOrCreateChat(
                                orderId = null,
                                otherPartyId = prod.sellerId,
                                otherPartyName = prod.sellerName,
                                otherPartyRole = UserRole.SELLER
                            )
                            selectedChatId = chatId
                            currentDestination = ScreenDestination.Main
                            activeTab = if (selectedRole == UserRole.CONSUMER) 4 else 1
                        },
                        onViewSellerSpace = { sellerId ->
                            val space = sellerSpaces.find { it.sellerId == sellerId } ?: sellerSpaces.first()
                            currentDestination = ScreenDestination.SellerSpaceView(space)
                        }
                    )
                }

                is ScreenDestination.SellerSpaceView -> {
                    SellerSpaceScreen(
                        sellerSpace = dest.space,
                        products = products,
                        onBack = { currentDestination = ScreenDestination.Main },
                        onProductClick = { prod -> currentDestination = ScreenDestination.ProductDetail(prod) },
                        onAddToCart = { prod -> repository.addToCart(prod) },
                        onChatWithSeller = { space ->
                            val chatId = repository.getOrCreateChat(
                                orderId = null,
                                otherPartyId = space.sellerId,
                                otherPartyName = space.name,
                                otherPartyRole = UserRole.SELLER
                            )
                            selectedChatId = chatId
                            currentDestination = ScreenDestination.Main
                            activeTab = if (selectedRole == UserRole.CONSUMER) 4 else 1
                        }
                    )
                }

                is ScreenDestination.Checkout -> {
                    CheckoutScreen(
                        cartItems = cart,
                        onBack = { currentDestination = ScreenDestination.Main },
                        onOrderPlaced = { address, paymentMethod ->
                            repository.placeOrder(address, paymentMethod)
                        },
                        onViewOrderTracking = { orderId ->
                            orderToHighlightId = orderId
                            currentDestination = ScreenDestination.Main
                            activeTab = 3 // Switch to Orders tab
                        }
                    )
                }

                is ScreenDestination.Notifications -> {
                    NotificationsScreen(
                        notifications = notifications,
                        onNotificationClick = { notif ->
                            repository.markNotificationRead(notif.id)
                        },
                        onBack = { currentDestination = ScreenDestination.Main }
                    )
                }

                is ScreenDestination.AddProduct -> {
                    AddProductScreen(
                        onBack = { currentDestination = ScreenDestination.Main },
                        onProductCreated = { name, desc, cat, price, stock, radius, specs ->
                            repository.addProduct(name, desc, cat, price, stock, radius, specs)
                            currentDestination = ScreenDestination.Main
                        }
                    )
                }

                is ScreenDestination.PostInnovation -> {
                    PostInnovationScreen(
                        onBack = { currentDestination = ScreenDestination.Main },
                        onPostCreated = { title, content, tags ->
                            repository.addInnovationPost(title, content, tags)
                            currentDestination = ScreenDestination.Main
                        }
                    )
                }

                is ScreenDestination.SellerEarnings -> {
                    SellerEarningsScreen(
                        orders = orders,
                        commissionConfig = commissionConfig,
                        onBack = { currentDestination = ScreenDestination.Main }
                    )
                }

                is ScreenDestination.DeliveryWorkflow -> {
                    DeliveryWorkflowScreen(
                        order = dest.order,
                        onBack = { currentDestination = ScreenDestination.Main },
                        onAdvanceDeliveryStage = { orderId ->
                            repository.advanceDeliveryWorkflow(orderId)
                            // Update local reference
                            orders.find { it.id == orderId }?.let { updated ->
                                currentDestination = ScreenDestination.DeliveryWorkflow(updated)
                            }
                        },
                        onContactCustomer = { custId, custName ->
                            val chatId = repository.getOrCreateChat(
                                orderId = dest.order.id,
                                otherPartyId = custId,
                                otherPartyName = custName,
                                otherPartyRole = UserRole.CONSUMER
                            )
                            selectedChatId = chatId
                            currentDestination = ScreenDestination.Main
                            activeTab = 1
                        },
                        onContactSeller = { sId, sName ->
                            val chatId = repository.getOrCreateChat(
                                orderId = dest.order.id,
                                otherPartyId = sId,
                                otherPartyName = sName,
                                otherPartyRole = UserRole.SELLER
                            )
                            selectedChatId = chatId
                            currentDestination = ScreenDestination.Main
                            activeTab = 1
                        }
                    )
                }

                is ScreenDestination.Main -> {
                    when (selectedRole) {
                        UserRole.CONSUMER -> {
                            when (activeTab) {
                                0 -> ConsumerHomeScreen(
                                    user = currentUser,
                                    products = products,
                                    sellerSpaces = sellerSpaces,
                                    selectedCategory = selectedCategory,
                                    onCategorySelect = { selectedCategory = it },
                                    onSearchClick = { activeTab = 1 },
                                    onProductClick = { prod -> currentDestination = ScreenDestination.ProductDetail(prod) },
                                    onAddToCart = { prod -> repository.addToCart(prod) },
                                    onSellerSpaceClick = { space -> currentDestination = ScreenDestination.SellerSpaceView(space) }
                                )
                                1 -> ExploreScreen(
                                    products = products,
                                    onProductClick = { prod -> currentDestination = ScreenDestination.ProductDetail(prod) },
                                    onAddToCart = { prod -> repository.addToCart(prod) }
                                )
                                2 -> CartScreen(
                                    cartItems = cart,
                                    onUpdateQuantity = { id, qty -> repository.updateCartQuantity(id, qty) },
                                    onRemoveItem = { id -> repository.removeFromCart(id) },
                                    onContinueShopping = { activeTab = 0 },
                                    onProceedToCheckout = { currentDestination = ScreenDestination.Checkout }
                                )
                                3 -> OrdersScreen(
                                    orders = orders,
                                    onAdvanceOrderStage = { orderId -> repository.advanceDeliveryWorkflow(orderId) },
                                    onContactSeller = { sId, sName ->
                                        val cId = repository.getOrCreateChat(null, sId, sName, UserRole.SELLER)
                                        selectedChatId = cId
                                        activeTab = 4
                                    },
                                    onContactDeliveryPartner = { pId, pName ->
                                        val cId = repository.getOrCreateChat(null, pId, pName, UserRole.DELIVERY_PARTNER)
                                        selectedChatId = cId
                                        activeTab = 4
                                    },
                                    onLeaveReview = { order -> reviewTargetOrder = order },
                                    selectedOrderId = orderToHighlightId
                                )
                                4 -> ChatScreen(
                                    chats = chats,
                                    selectedChatId = selectedChatId,
                                    currentRole = selectedRole,
                                    onSendMessage = { cId, text -> repository.sendChatMessage(cId, text, selectedRole) },
                                    onSelectChat = { selectedChatId = it },
                                    onBackToList = { selectedChatId = null }
                                )
                                5 -> ProfileScreen(
                                    user = currentUser,
                                    currentRole = selectedRole,
                                    locationGranted = locationGranted,
                                    approxLocation = approxLocation,
                                    onRoleChange = { newRole -> repository.setRole(newRole) },
                                    onManageLocation = { showLocationDialog = true },
                                    onRestartOnboarding = {
                                        repository.setRole(UserRole.CONSUMER)
                                        currentDestination = ScreenDestination.Main
                                    }
                                )
                            }
                        }

                        UserRole.SELLER -> {
                            when (activeTab) {
                                0 -> SellerDashboardScreen(
                                    user = currentUser,
                                    products = products,
                                    orders = orders,
                                    deliveryPartners = deliveryPartners,
                                    onAddProductClick = { currentDestination = ScreenDestination.AddProduct },
                                    onPostInnovationClick = { currentDestination = ScreenDestination.PostInnovation },
                                    onConfirmOrder = { orderId -> repository.sellerConfirmOrder(orderId) },
                                    onRequestDeliveryPartner = { orderId, partner ->
                                        repository.sellerRequestDeliveryPartner(orderId, partner)
                                    },
                                    onToggleProductActive = { id -> repository.toggleProductActive(id) },
                                    onDeleteProduct = { id -> repository.deleteProduct(id) },
                                    onViewEarnings = { currentDestination = ScreenDestination.SellerEarnings }
                                )
                                1 -> ChatScreen(
                                    chats = chats,
                                    selectedChatId = selectedChatId,
                                    currentRole = selectedRole,
                                    onSendMessage = { cId, text -> repository.sendChatMessage(cId, text, selectedRole) },
                                    onSelectChat = { selectedChatId = it },
                                    onBackToList = { selectedChatId = null }
                                )
                                2 -> SellerEarningsScreen(
                                    orders = orders,
                                    commissionConfig = commissionConfig,
                                    onBack = { activeTab = 0 }
                                )
                                3 -> ProfileScreen(
                                    user = currentUser,
                                    currentRole = selectedRole,
                                    locationGranted = locationGranted,
                                    approxLocation = approxLocation,
                                    onRoleChange = { newRole -> repository.setRole(newRole) },
                                    onManageLocation = { showLocationDialog = true },
                                    onRestartOnboarding = {
                                        repository.setRole(UserRole.CONSUMER)
                                    }
                                )
                            }
                        }

                        UserRole.DELIVERY_PARTNER -> {
                            when (activeTab) {
                                0 -> DeliveryPartnerDashboardScreen(
                                    user = currentUser,
                                    deliveryPartner = deliveryPartners.firstOrNull(),
                                    orders = orders,
                                    onToggleAvailability = { id -> repository.toggleDeliveryPartnerAvailability(id) },
                                    onAcceptDelivery = { order ->
                                        repository.advanceDeliveryWorkflow(order.id)
                                        currentDestination = ScreenDestination.DeliveryWorkflow(order)
                                    },
                                    onAdvanceDelivery = { orderId -> repository.advanceDeliveryWorkflow(orderId) },
                                    onOpenDeliveryWorkflow = { order -> currentDestination = ScreenDestination.DeliveryWorkflow(order) },
                                    onContactCustomer = { cId, cName ->
                                        val id = repository.getOrCreateChat(null, cId, cName, UserRole.CONSUMER)
                                        selectedChatId = id
                                        activeTab = 1
                                    },
                                    onContactSeller = { sId, sName ->
                                        val id = repository.getOrCreateChat(null, sId, sName, UserRole.SELLER)
                                        selectedChatId = id
                                        activeTab = 1
                                    }
                                )
                                1 -> ChatScreen(
                                    chats = chats,
                                    selectedChatId = selectedChatId,
                                    currentRole = selectedRole,
                                    onSendMessage = { cId, text -> repository.sendChatMessage(cId, text, selectedRole) },
                                    onSelectChat = { selectedChatId = it },
                                    onBackToList = { selectedChatId = null }
                                )
                                2 -> ProfileScreen(
                                    user = currentUser,
                                    currentRole = selectedRole,
                                    locationGranted = locationGranted,
                                    approxLocation = approxLocation,
                                    onRoleChange = { newRole -> repository.setRole(newRole) },
                                    onManageLocation = { showLocationDialog = true },
                                    onRestartOnboarding = {
                                        repository.setRole(UserRole.CONSUMER)
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
