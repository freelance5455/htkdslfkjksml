package com.example.ui.components

import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.data.model.MediaSource
import com.example.data.preferences.UserPreferences
import com.example.ui.theme.YiffyPrimary
import com.example.ui.theme.YiffySecondary
import com.example.ui.theme.YiffySurface
import com.example.ui.theme.YiffySurfaceVariant
import com.example.ui.viewmodel.SettingsUiState

@Composable
fun SettingsView(
    uiState: SettingsUiState,
    userPrefs: UserPreferences,
    onBack: () -> Unit,
    onSyncGoogleDrive: (String) -> Unit,
    onViewDoc: (String) -> Unit,
    onCloseDocViewer: () -> Unit,
    onOpenCaptchaWebView: (String) -> Unit,
    onCloseCaptchaWebView: () -> Unit,
    onSaveApiKeys: (String, String, String, String, String, String, String, String) -> Unit,
    onUpdateUiScale: (Float) -> Unit,
    onUpdateDownloadFolder: (String) -> Unit,
    onToggleMalesOnly: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    var e621Login by remember { mutableStateOf(userPrefs.e621Login) }
    var e621ApiKey by remember { mutableStateOf(userPrefs.e621ApiKey) }
    var rule34ApiKey by remember { mutableStateOf(userPrefs.rule34ApiKey) }
    var redditClientId by remember { mutableStateOf(userPrefs.redditClientId) }
    var redditClientSecret by remember { mutableStateOf(userPrefs.redditClientSecret) }
    var blueskyHandle by remember { mutableStateOf(userPrefs.blueskyHandle) }
    var blueskyAppPassword by remember { mutableStateOf(userPrefs.blueskyAppPassword) }
    var twitterToken by remember { mutableStateOf(userPrefs.twitterBearerToken) }

    var downloadFolderPath by remember { mutableStateOf(userPrefs.downloadFolder) }
    var currentUiScale by remember { mutableFloatStateOf(userPrefs.uiScale) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0A0B0E))
            .statusBarsPadding()
    ) {
        // Settings Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier.testTag("settings_back_btn")
            ) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
            }
            Spacer(Modifier.width(8.dp))
            Text(
                text = "Preferences & Vault",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                color = Color.White
            )
        }

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(scrollState)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Section 1: Google Account & Drive 4-Document Sync
            Card(
                colors = CardDefaults.cardColors(containerColor = YiffySurfaceVariant),
                shape = RoundedCornerShape(14.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CloudSync, contentDescription = null, tint = YiffyPrimary)
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = "Google Account Sync",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = Color.White
                            )
                        }

                        if (userPrefs.isGoogleConnected) {
                            Surface(color = Color(0xFF4CAF50).copy(alpha = 0.2f), shape = RoundedCornerShape(12.dp)) {
                                Text(
                                    text = "Connected",
                                    color = Color(0xFF4CAF50),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                        }
                    }

                    Spacer(Modifier.height(8.dp))

                    Text(
                        text = "Synchronises 4 text documents directly to your Google account folder:",
                        color = Color.LightGray,
                        fontSize = 12.sp
                    )

                    Spacer(Modifier.height(8.dp))

                    // 4 Document Chips
                    val syncFiles = listOf(
                        "History.txt" to "100 last viewed items",
                        "Algorithm_keeping.txt" to "Scored tag affinities",
                        "Liked_posts.txt" to "All liked catalog",
                        "Favorite_posts.txt" to "Segregated by platform"
                    )

                    syncFiles.forEach { (fileName, description) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF141722))
                                .clickable { onViewDoc(fileName) }
                                .padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Description, contentDescription = null, tint = YiffySecondary, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(8.dp))
                                Column {
                                    Text(fileName, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                    Text(description, color = Color.Gray, fontSize = 10.sp)
                                }
                            }
                            Text("View", color = YiffyPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.height(4.dp))
                    }

                    Spacer(Modifier.height(10.dp))

                    Button(
                        onClick = { onSyncGoogleDrive("feltedleopard@gmail.com") },
                        enabled = !uiState.isSyncing,
                        colors = ButtonDefaults.buttonColors(containerColor = YiffyPrimary),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("sync_google_drive_btn")
                    ) {
                        if (uiState.isSyncing) {
                            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("Syncing to Google Drive...", fontSize = 13.sp)
                        } else {
                            Icon(Icons.Default.CloudDone, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("Sync Now to Google Drive Folder", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // Section 2: API Key Vault (Bluesky, Reddit, Twitter, e621, Rule34)
            Card(
                colors = CardDefaults.cardColors(containerColor = YiffySurfaceVariant),
                shape = RoundedCornerShape(14.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Key, contentDescription = null, tint = YiffyPrimary)
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = "Platform API Keylist",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = Color.White
                        )
                    }

                    Text(
                        text = "Plug your credentials so every like on Yiffy tells the website API to sync your reaction.",
                        color = Color.LightGray,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
                    )

                    // e621
                    OutlinedTextField(
                        value = e621Login,
                        onValueChange = { e621Login = it },
                        label = { Text("e621 Username / Login") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = outlinedTextFieldColors()
                    )
                    Spacer(Modifier.height(6.dp))
                    OutlinedTextField(
                        value = e621ApiKey,
                        onValueChange = { e621ApiKey = it },
                        label = { Text("e621 API Key") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = outlinedTextFieldColors()
                    )

                    Spacer(Modifier.height(10.dp))

                    // Rule34
                    OutlinedTextField(
                        value = rule34ApiKey,
                        onValueChange = { rule34ApiKey = it },
                        label = { Text("Rule34 User ID & API Key") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = outlinedTextFieldColors()
                    )

                    Spacer(Modifier.height(10.dp))

                    // Bluesky
                    OutlinedTextField(
                        value = blueskyHandle,
                        onValueChange = { blueskyHandle = it },
                        label = { Text("Bluesky Handle (e.g. user.bsky.social)") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = outlinedTextFieldColors()
                    )
                    Spacer(Modifier.height(6.dp))
                    OutlinedTextField(
                        value = blueskyAppPassword,
                        onValueChange = { blueskyAppPassword = it },
                        label = { Text("Bluesky App Password") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = outlinedTextFieldColors()
                    )

                    Spacer(Modifier.height(10.dp))

                    // Reddit
                    OutlinedTextField(
                        value = redditClientId,
                        onValueChange = { redditClientId = it },
                        label = { Text("Reddit Client ID / Script App") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = outlinedTextFieldColors()
                    )

                    Spacer(Modifier.height(10.dp))

                    // Twitter
                    OutlinedTextField(
                        value = twitterToken,
                        onValueChange = { twitterToken = it },
                        label = { Text("Twitter / X Bearer Token") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = outlinedTextFieldColors()
                    )

                    Spacer(Modifier.height(12.dp))

                    Button(
                        onClick = {
                            onSaveApiKeys(
                                e621Login, e621ApiKey, rule34ApiKey,
                                redditClientId, redditClientSecret,
                                blueskyHandle, blueskyAppPassword, twitterToken
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = YiffyPrimary),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Save & Validate Credentials", fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Section 3: In-App WebView Captcha Solver Launcher (Confirmed in prompt)
            Card(
                colors = CardDefaults.cardColors(containerColor = YiffySurfaceVariant),
                shape = RoundedCornerShape(14.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Language, contentDescription = null, tint = YiffySecondary)
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = "In-App Captcha & Cloudflare Solver",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = Color.White
                        )
                    }

                    Text(
                        text = "Launches an embedded browser session to complete Cloudflare turnstiles or website captchas and store clearance cookies.",
                        color = Color.LightGray,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { onOpenCaptchaWebView("https://e621.net") },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00549E)),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("e621 Captcha", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = { onOpenCaptchaWebView("https://e-hentai.org") },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFED3554)),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("E-Hentai Solve", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // Section 4: Content Filters & MalesOnly Modifier
            Card(
                colors = CardDefaults.cardColors(containerColor = YiffySurfaceVariant),
                shape = RoundedCornerShape(14.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "MalesOnly Modifier",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                            Text(
                                text = "Excludes any videos, pictures, or comics containing men/male tags.",
                                color = Color.LightGray,
                                fontSize = 11.sp
                            )
                        }
                        Switch(
                            checked = userPrefs.malesOnly,
                            onCheckedChange = onToggleMalesOnly,
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = YiffyPrimary,
                                checkedTrackColor = YiffyPrimary.copy(alpha = 0.5f)
                            ),
                            modifier = Modifier.testTag("settings_males_only_switch")
                        )
                    }
                }
            }

            // Section 5: UI Scaling & Download Folder
            Card(
                colors = CardDefaults.cardColors(containerColor = YiffySurfaceVariant),
                shape = RoundedCornerShape(14.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Tune, contentDescription = null, tint = YiffyPrimary)
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = "Display & Storage Config",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = Color.White
                        )
                    }

                    Spacer(Modifier.height(10.dp))

                    Text(
                        text = "UI Scaling: ${String.format("%.2f", currentUiScale)}x",
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Slider(
                        value = currentUiScale,
                        onValueChange = {
                            currentUiScale = it
                            onUpdateUiScale(it)
                        },
                        valueRange = 0.80f..1.25f,
                        steps = 8,
                        colors = SliderDefaults.colors(
                            thumbColor = YiffyPrimary,
                            activeTrackColor = YiffyPrimary
                        )
                    )

                    Spacer(Modifier.height(8.dp))

                    OutlinedTextField(
                        value = downloadFolderPath,
                        onValueChange = {
                            downloadFolderPath = it
                            onUpdateDownloadFolder(it)
                        },
                        label = { Text("Hidden Download Folder (prefix with .)") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = outlinedTextFieldColors()
                    )
                    Text(
                        text = "Hidden folders (e.g. .yiffy_media) keep downloads out of phone gallery apps.",
                        color = Color.Gray,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
        }
    }

    // Modal Document Viewer (History.txt, Algorithm_keeping.txt, etc.)
    if (uiState.isDocViewerOpen) {
        val context = LocalContext.current
        AlertDialog(
            onDismissRequest = onCloseDocViewer,
            containerColor = Color(0xFF13151D),
            title = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(uiState.selectedDocPreview, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    IconButton(onClick = onCloseDocViewer) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Close", tint = Color.LightGray)
                    }
                }
            },
            text = {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(380.dp)
                        .background(Color(0xFF0B0D12), RoundedCornerShape(8.dp))
                        .padding(12.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    Text(
                        text = uiState.activeDocContent,
                        color = Color(0xFF00FF66), // Retro terminal green font
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        lineHeight = 15.sp
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = onCloseDocViewer) {
                    Text("Close", color = YiffyPrimary, fontWeight = FontWeight.Bold)
                }
            }
        )
    }

    // Modal In-App Captcha WebView Dialog
    if (uiState.isCaptchaWebViewOpen) {
        CaptchaWebViewDialog(
            url = uiState.captchaTargetUrl,
            onClose = onCloseCaptchaWebView
        )
    }
}

@Composable
fun CaptchaWebViewDialog(
    url: String,
    onClose: () -> Unit
) {
    var webViewRef: WebView? by remember { mutableStateOf(null) }

    AlertDialog(
        onDismissRequest = onClose,
        containerColor = Color(0xFF13151D),
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Captcha Solver", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Row {
                    IconButton(onClick = { webViewRef?.reload() }) {
                        Icon(Icons.Default.Refresh, contentDescription = "Reload", tint = Color.White)
                    }
                    IconButton(onClick = onClose) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Done", tint = Color.White)
                    }
                }
            }
        },
        text = {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(420.dp)
                    .clip(RoundedCornerShape(8.dp))
            ) {
                AndroidView(
                    factory = { ctx ->
                        WebView(ctx).apply {
                            settings.javaScriptEnabled = true
                            settings.domStorageEnabled = true
                            settings.databaseEnabled = true
                            CookieManager.getInstance().setAcceptCookie(true)
                            webViewClient = WebViewClient()
                            webChromeClient = WebChromeClient()
                            loadUrl(url)
                            webViewRef = this
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                )
            }
        },
        confirmButton = {
            TextButton(onClick = onClose) {
                Text("Finish & Save Cookies", color = YiffyPrimary, fontWeight = FontWeight.Bold)
            }
        }
    )
}

@Composable
fun outlinedTextFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = YiffyPrimary,
    unfocusedBorderColor = Color(0xFF2A2E3D),
    focusedTextColor = Color.White,
    unfocusedTextColor = Color.White,
    focusedLabelColor = YiffyPrimary,
    unfocusedLabelColor = Color.Gray
)
