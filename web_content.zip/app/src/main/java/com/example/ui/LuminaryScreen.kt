package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.BrightnessAuto
import androidx.compose.material.icons.outlined.DarkMode
import androidx.compose.material.icons.outlined.LightMode
import androidx.compose.material.icons.outlined.Menu
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.VerticalDivider
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.ui.components.AiAnswerCard
import com.example.ui.components.EmptyWelcomeCanvas
import com.example.ui.components.ErrorAnswerBanner
import com.example.ui.components.FollowUpChipsRow
import com.example.ui.components.HistorySidebarContent
import com.example.ui.components.QuestionComposerBar
import com.example.ui.components.SavedAnswersView
import com.example.ui.components.StreamingAnswerCard
import com.example.ui.components.UserQuestionBubble
import com.example.ui.theme.ThemePreference
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LuminaryScreen(
    viewModel: LuminaryViewModel,
    modifier: Modifier = Modifier
) {
    val activeThreadId by viewModel.activeThreadId.collectAsStateWithLifecycle()
    val threads by viewModel.threads.collectAsStateWithLifecycle()
    val messages by viewModel.messages.collectAsStateWithLifecycle()
    val bookmarkedMessages by viewModel.bookmarkedMessages.collectAsStateWithLifecycle()
    val selectedMode by viewModel.selectedMode.collectAsStateWithLifecycle()
    val themePreference by viewModel.themePreference.collectAsStateWithLifecycle()
    val generationState by viewModel.generationState.collectAsStateWithLifecycle()
    val followUps by viewModel.followUps.collectAsStateWithLifecycle()
    val attachedImage by viewModel.attachedImage.collectAsStateWithLifecycle()
    val attachmentError by viewModel.attachmentError.collectAsStateWithLifecycle()
    val ttsSpeakingMessageId by viewModel.ttsSpeakingMessageId.collectAsStateWithLifecycle()

    var inputText by rememberSaveable { mutableStateOf("") }
    var showingSavedScreen by rememberSaveable { mutableStateOf(false) }

    val snackbarHostState = remember { SnackbarHostState() }
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            viewModel.attachImageFromUri(uri)
        }
    }

    LaunchedEffect(attachmentError) {
        val err = attachmentError
        if (err != null) {
            snackbarHostState.showSnackbar(err)
            viewModel.dismissAttachmentError()
        }
    }

    BackHandler(enabled = showingSavedScreen || drawerState.isOpen) {
        when {
            drawerState.isOpen -> scope.launch { drawerState.close() }
            showingSavedScreen -> showingSavedScreen = false
        }
    }

    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        val isExpandedLayout = maxWidth >= 840.dp

        val mainContent: @Composable () -> Unit = {
            Scaffold(
                containerColor = MaterialTheme.colorScheme.background,
                contentWindowInsets = WindowInsets(0, 0, 0, 0),
                snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
                topBar = {
                    CenterAlignedTopAppBar(
                        colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                            containerColor = MaterialTheme.colorScheme.background
                        ),
                        navigationIcon = {
                            if (!isExpandedLayout) {
                                IconButton(
                                    onClick = { scope.launch { drawerState.open() } },
                                    modifier = Modifier
                                        .minimumInteractiveComponentSize()
                                        .testTag("history_drawer_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Outlined.Menu,
                                        contentDescription = stringResource(R.string.action_history)
                                    )
                                }
                            }
                        },
                        title = {
                            Text(
                                text = stringResource(R.string.app_name),
                                style = MaterialTheme.typography.headlineSmall,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                        },
                        actions = {
                            IconButton(
                                onClick = { showingSavedScreen = !showingSavedScreen },
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("saved_answers_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.BookmarkBorder,
                                    contentDescription = stringResource(R.string.action_saved),
                                    tint = if (showingSavedScreen) {
                                        MaterialTheme.colorScheme.tertiary
                                    } else {
                                        MaterialTheme.colorScheme.onSurfaceVariant
                                    }
                                )
                            }
                            IconButton(
                                onClick = { viewModel.cycleThemePreference() },
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("theme_toggle_button")
                            ) {
                                Icon(
                                    imageVector = when (themePreference) {
                                        ThemePreference.SYSTEM -> Icons.Outlined.BrightnessAuto
                                        ThemePreference.DARK -> Icons.Outlined.DarkMode
                                        ThemePreference.LIGHT -> Icons.Outlined.LightMode
                                    },
                                    contentDescription = stringResource(R.string.action_toggle_theme),
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            IconButton(
                                onClick = {
                                    showingSavedScreen = false
                                    viewModel.startNewQuestion()
                                },
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("new_question_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.Add,
                                    contentDescription = stringResource(R.string.action_new_question)
                                )
                            }
                        }
                    )
                },
                bottomBar = {
                    if (!showingSavedScreen) {
                        val isGenerating = generationState is GenerationState.Loading ||
                            generationState is GenerationState.Streaming
                        Box(
                            modifier = Modifier.fillMaxWidth(),
                            contentAlignment = Alignment.Center
                        ) {
                            QuestionComposerBar(
                                inputText = inputText,
                                onInputChange = { inputText = it },
                                attachedImage = attachedImage,
                                isGenerating = isGenerating,
                                selectedMode = selectedMode,
                                showCompactModeRow = messages.isNotEmpty(),
                                onSelectMode = { viewModel.selectMode(it) },
                                onAttachClick = {
                                    photoPickerLauncher.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                },
                                onClearAttachment = { viewModel.clearAttachment() },
                                onSend = {
                                    val query = inputText
                                    inputText = ""
                                    viewModel.askQuestion(query)
                                },
                                onStop = { viewModel.stopGenerating() },
                                modifier = Modifier.widthIn(max = 780.dp)
                            )
                        }
                    }
                }
            ) { innerPadding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding),
                    contentAlignment = Alignment.TopCenter
                ) {
                    if (showingSavedScreen) {
                        SavedAnswersView(
                            bookmarks = bookmarkedMessages,
                            onBack = { showingSavedScreen = false },
                            onOpenThread = { threadId ->
                                showingSavedScreen = false
                                viewModel.openThread(threadId)
                            },
                            onRemoveBookmark = { viewModel.toggleBookmark(it) },
                            modifier = Modifier.widthIn(max = 780.dp)
                        )
                    } else if (messages.isEmpty() && generationState is GenerationState.Idle) {
                        EmptyWelcomeCanvas(
                            selectedMode = selectedMode,
                            onSelectMode = { viewModel.selectMode(it) },
                            onSelectStarter = { starter ->
                                viewModel.askQuestion(
                                    rawQuestion = starter.question,
                                    overrideMode = starter.mode
                                )
                            }
                        )
                    } else {
                        val listState = rememberLazyListState()
                        val lastModelIndex = messages.indexOfLast { it.role == "model" }

                        LaunchedEffect(messages.size, generationState) {
                            val totalItems = messages.size +
                                (if (generationState !is GenerationState.Idle) 1 else 0) +
                                (if (followUps.isNotEmpty()) 1 else 0)
                            if (totalItems > 0) {
                                listState.animateScrollToItem((totalItems - 1).coerceAtLeast(0))
                            }
                        }

                        LazyColumn(
                            state = listState,
                            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
                            verticalArrangement = Arrangement.spacedBy(16.dp),
                            modifier = Modifier
                                .fillMaxSize()
                                .widthIn(max = 780.dp)
                        ) {
                            itemsIndexed(
                                items = messages,
                                key = { _, item -> item.id }
                            ) { index, message ->
                                if (message.role == "user") {
                                    UserQuestionBubble(message = message)
                                } else {
                                    AiAnswerCard(
                                        message = message,
                                        isLastAnswer = index == lastModelIndex &&
                                            generationState is GenerationState.Idle,
                                        isSpeaking = ttsSpeakingMessageId == message.id,
                                        onToggleBookmark = { viewModel.toggleBookmark(message) },
                                        onToggleSpeak = { viewModel.toggleSpeak(message.id, message.text) },
                                        onRegenerate = { viewModel.regenerateLastAnswer() }
                                    )
                                }
                            }

                            when (val state = generationState) {
                                is GenerationState.Loading -> {
                                    item(key = "streaming_loading") {
                                        StreamingAnswerCard(
                                            text = null,
                                            modeLabel = selectedMode.label
                                        )
                                    }
                                }
                                is GenerationState.Streaming -> {
                                    item(key = "streaming_active") {
                                        StreamingAnswerCard(
                                            text = state.text,
                                            modeLabel = state.modeLabel
                                        )
                                    }
                                }
                                is GenerationState.Error -> {
                                    item(key = "generation_error") {
                                        ErrorAnswerBanner(
                                            message = state.message,
                                            onRetry = { viewModel.retryLastError() }
                                        )
                                    }
                                }
                                GenerationState.Idle -> Unit
                            }

                            if (followUps.isNotEmpty() && generationState is GenerationState.Idle) {
                                item(key = "followup_suggestions") {
                                    FollowUpChipsRow(
                                        followUps = followUps,
                                        onSelectFollowUp = { followUp ->
                                            viewModel.askQuestion(followUp)
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        if (isExpandedLayout) {
            Row(modifier = Modifier.fillMaxSize()) {
                HistorySidebarContent(
                    threads = threads,
                    activeThreadId = activeThreadId,
                    savedCount = bookmarkedMessages.size,
                    onNewQuestion = {
                        showingSavedScreen = false
                        viewModel.startNewQuestion()
                    },
                    onSelectThread = { id ->
                        showingSavedScreen = false
                        viewModel.openThread(id)
                    },
                    onDeleteThread = { viewModel.deleteThread(it) },
                    onOpenSaved = { showingSavedScreen = true },
                    modifier = Modifier
                        .width(296.dp)
                        .fillMaxHeight()
                        .statusBarsPadding()
                )
                VerticalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                Box(modifier = Modifier.weight(1f)) {
                    mainContent()
                }
            }
        } else {
            ModalNavigationDrawer(
                drawerState = drawerState,
                drawerContent = {
                    ModalDrawerSheet(
                        drawerContainerColor = MaterialTheme.colorScheme.surface,
                        windowInsets = WindowInsets.safeDrawing
                    ) {
                        HistorySidebarContent(
                            threads = threads,
                            activeThreadId = activeThreadId,
                            savedCount = bookmarkedMessages.size,
                            onNewQuestion = {
                                showingSavedScreen = false
                                viewModel.startNewQuestion()
                                scope.launch { drawerState.close() }
                            },
                            onSelectThread = { id ->
                                showingSavedScreen = false
                                viewModel.openThread(id)
                                scope.launch { drawerState.close() }
                            },
                            onDeleteThread = { viewModel.deleteThread(it) },
                            onOpenSaved = {
                                showingSavedScreen = true
                                scope.launch { drawerState.close() }
                            },
                            modifier = Modifier.width(300.dp)
                        )
                    }
                }
            ) {
                mainContent()
            }
        }
    }
}
