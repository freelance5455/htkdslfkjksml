package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.ChatMessage
import com.example.data.SenseiCharacter
import com.example.ui.DojoUiState
import com.example.ui.theme.ChakraCyan
import com.example.ui.theme.NarutoOrange

@Composable
fun DoubtChatScreen(
  uiState: DojoUiState,
  onSwitchSensei: (SenseiCharacter) -> Unit,
  onChatInputChanged: (String) -> Unit,
  onSendMessage: (String?) -> Unit,
  onClearChat: () -> Unit,
  modifier: Modifier = Modifier
) {
  val listState = rememberLazyListState()

  LaunchedEffect(uiState.chatMessages.size, uiState.isSenseiTyping) {
    if (uiState.chatMessages.isNotEmpty()) {
      listState.animateScrollToItem(uiState.chatMessages.size - 1)
    }
  }

  Column(
    modifier = modifier
      .fillMaxSize()
      .imePadding()
  ) {
    // Character Switcher Header
    Surface(
      modifier = Modifier.fillMaxWidth(),
      color = MaterialTheme.colorScheme.surface,
      tonalElevation = 4.dp
    ) {
      Column(modifier = Modifier.padding(12.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "Choose Your Sensei",
            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onSurface
          )
          IconButton(
            onClick = onClearChat,
            modifier = Modifier.testTag("clear_chat_button")
          ) {
            Icon(
              Icons.Default.DeleteSweep,
              contentDescription = "Clear Chat",
              tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          // Naruto Card
          SenseiSelectorCard(
            character = SenseiCharacter.NARUTO,
            isSelected = uiState.activeSensei == SenseiCharacter.NARUTO,
            avatarRes = R.drawable.img_naruto_avatar,
            onClick = { onSwitchSensei(SenseiCharacter.NARUTO) },
            accentColor = NarutoOrange,
            modifier = Modifier.weight(1f)
          )

          // Hinata Card
          SenseiSelectorCard(
            character = SenseiCharacter.HINATA,
            isSelected = uiState.activeSensei == SenseiCharacter.HINATA,
            avatarRes = R.drawable.img_hinata_avatar,
            onClick = { onSwitchSensei(SenseiCharacter.HINATA) },
            accentColor = ChakraCyan,
            modifier = Modifier.weight(1f)
          )
        }
      }
    }

    // Quick Prompt Topic Chips
    LazyRow(
      modifier = Modifier
        .fillMaxWidth()
        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
        .padding(vertical = 8.dp, horizontal = 12.dp),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      val topics = listOf(
        "Explain Pointers in C++",
        "Recursion vs Shadow Clones",
        "DDL vs DML in SQL",
        "Kirchhoff's Laws",
        "How to Invert 2x2 Matrix",
        "Nernst Equation",
        "Total Internal Reflection",
        "DHSE Exam Tips"
      )
      items(topics) { topic ->
        Surface(
          shape = RoundedCornerShape(16.dp),
          color = MaterialTheme.colorScheme.surface,
          shadowElevation = 1.dp,
          modifier = Modifier
            .clickable { onSendMessage(topic) }
            .testTag("prompt_chip_${topic.take(8).lowercase().trim()}")
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = topic,
              style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Medium),
              color = MaterialTheme.colorScheme.onSurface
            )
          }
        }
      }
    }

    // Messages List
    LazyColumn(
      state = listState,
      modifier = Modifier
        .weight(1f)
        .fillMaxWidth(),
      contentPadding = PaddingValues(16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      items(uiState.chatMessages, key = { it.id }) { msg ->
        ChatMessageBubble(message = msg)
      }

      if (uiState.isSenseiTyping) {
        item {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(start = 8.dp)
          ) {
            CircularProgressIndicator(
              modifier = Modifier.size(16.dp),
              color = if (uiState.activeSensei == SenseiCharacter.NARUTO) NarutoOrange else ChakraCyan,
              strokeWidth = 2.dp
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "${uiState.activeSensei.charName} is preparing advice...",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }
      }
    }

    // Chat Input Bar
    Surface(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 12.dp, vertical = 6.dp),
      shape = RoundedCornerShape(24.dp),
      color = MaterialTheme.colorScheme.surface,
      tonalElevation = 6.dp,
      shadowElevation = 3.dp
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        OutlinedTextField(
          value = uiState.chatInputText,
          onValueChange = onChatInputChanged,
          placeholder = {
            Text(
              text = if (uiState.activeSensei == SenseiCharacter.NARUTO)
                "Ask Naruto anything! Believe it!" else "Ask Hinata step-by-step...",
              fontSize = 13.sp
            )
          },
          modifier = Modifier
            .weight(1f)
            .testTag("chat_input_field"),
          maxLines = 3,
          colors = OutlinedTextFieldDefaults.colors(
            unfocusedBorderColor = Color.Transparent,
            focusedBorderColor = Color.Transparent
          )
        )

        IconButton(
          onClick = { onSendMessage(null) },
          enabled = uiState.chatInputText.isNotBlank() && !uiState.isSenseiTyping,
          modifier = Modifier
            .size(44.dp)
            .clip(CircleShape)
            .background(
              if (uiState.chatInputText.isNotBlank()) NarutoOrange
              else MaterialTheme.colorScheme.surfaceVariant
            )
            .testTag("chat_send_button")
        ) {
          Icon(
            imageVector = Icons.AutoMirrored.Filled.Send,
            contentDescription = "Send",
            tint = if (uiState.chatInputText.isNotBlank()) Color.White
            else MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(20.dp)
          )
        }
      }
    }

    // Spacer for bottom navigation
    Spacer(modifier = Modifier.height(80.dp))
  }
}

@Composable
fun SenseiSelectorCard(
  character: SenseiCharacter,
  isSelected: Boolean,
  avatarRes: Int,
  onClick: () -> Unit,
  accentColor: Color,
  modifier: Modifier = Modifier
) {
  Card(
    modifier = modifier
      .clip(RoundedCornerShape(16.dp))
      .border(
        width = if (isSelected) 2.dp else 1.dp,
        color = if (isSelected) accentColor else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
        shape = RoundedCornerShape(16.dp)
      )
      .clickable { onClick() }
      .testTag("sensei_card_${character.name.lowercase()}"),
    colors = CardDefaults.cardColors(
      containerColor = if (isSelected) accentColor.copy(alpha = 0.12f)
      else MaterialTheme.colorScheme.surface
    )
  ) {
    Row(
      modifier = Modifier.padding(10.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Image(
        painter = painterResource(id = avatarRes),
        contentDescription = character.charName,
        modifier = Modifier
          .size(44.dp)
          .clip(CircleShape),
        contentScale = ContentScale.Crop
      )
      Spacer(modifier = Modifier.width(10.dp))
      Column {
        Text(
          text = if (character == SenseiCharacter.NARUTO) "Naruto" else "Hinata",
          style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
          color = MaterialTheme.colorScheme.onSurface
        )
        Text(
          text = if (character == SenseiCharacter.NARUTO) "⚡ Energetic" else "🌸 Step-by-Step",
          style = MaterialTheme.typography.labelSmall,
          color = accentColor
        )
      }
    }
  }
}

@Composable
fun ChatMessageBubble(message: ChatMessage) {
  val isUser = message.isUser

  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start,
    verticalAlignment = Alignment.Top
  ) {
    if (!isUser) {
      val avatarRes = message.character?.avatarRes ?: R.drawable.img_naruto_avatar
      Image(
        painter = painterResource(id = avatarRes),
        contentDescription = message.senderName,
        modifier = Modifier
          .size(34.dp)
          .clip(CircleShape),
        contentScale = ContentScale.Crop
      )
      Spacer(modifier = Modifier.width(8.dp))
    }

    Card(
      modifier = Modifier
        .widthIn(max = 280.dp)
        .testTag("chat_bubble_${message.id}"),
      shape = RoundedCornerShape(
        topStart = 16.dp,
        topEnd = 16.dp,
        bottomStart = if (isUser) 16.dp else 4.dp,
        bottomEnd = if (isUser) 4.dp else 16.dp
      ),
      colors = CardDefaults.cardColors(
        containerColor = when {
          isUser -> NarutoOrange
          message.character == SenseiCharacter.HINATA -> MaterialTheme.colorScheme.surfaceVariant
          else -> MaterialTheme.colorScheme.surface
        }
      ),
      elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
      Column(modifier = Modifier.padding(12.dp)) {
        if (!isUser) {
          Text(
            text = message.senderName,
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
            color = if (message.character == SenseiCharacter.HINATA) ChakraCyan else NarutoOrange
          )
          Spacer(modifier = Modifier.height(4.dp))
        }

        Text(
          text = message.text,
          style = MaterialTheme.typography.bodyMedium.copy(fontSize = 14.sp),
          color = if (isUser) Color.White else MaterialTheme.colorScheme.onSurface
        )
      }
    }
  }
}
