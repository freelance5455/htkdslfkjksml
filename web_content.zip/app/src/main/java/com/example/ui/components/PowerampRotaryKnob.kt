package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonPink
import com.example.ui.theme.ObsidianBg
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Audiophile Analog Rotary Knob inspired by Poweramp DSP Knobs.
 * Supports vertical drag or circular rotational dragging, plus double-tap to reset to defaultValue.
 */
@Composable
fun PowerampRotaryKnob(
    value: Float,
    onValueChange: (Float) -> Unit,
    range: ClosedFloatingPointRange<Float> = -10f..10f,
    defaultValue: Float = 0f,
    label: String,
    unit: String = "dB",
    modifier: Modifier = Modifier,
    size: Dp = 100.dp,
    activeColor: Color = NeonCyan,
    inactiveColor: Color = Color(0xFF2A2E3D)
) {
    val totalRange = (range.endInclusive - range.start)
    val fraction = ((value - range.start) / totalRange).coerceIn(0f, 1f)

    // Poweramp knob sweep angle: from 135 deg to 405 deg (270 degrees total arc)
    val startAngle = 135f
    val sweepAngle = 270f
    val currentAngle = startAngle + fraction * sweepAngle

    var dragAccumulator by remember { mutableFloatStateOf(0f) }

    Column(
        modifier = modifier.testTag("rotary_knob_${label.lowercase()}"),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(size)
                .pointerInput(Unit) {
                    detectTapGestures(
                        onDoubleTap = {
                            onValueChange(defaultValue)
                        }
                    )
                }
                .pointerInput(range, value) {
                    detectDragGestures(
                        onDragStart = { dragAccumulator = 0f },
                        onDrag = { change, dragAmount ->
                            change.consume()
                            // Vertical dragging sensitivity
                            val deltaY = -dragAmount.y // Drag up to increase, down to decrease
                            val deltaX = dragAmount.x * 0.5f
                            val combined = deltaY + deltaX
                            val valueDelta = (combined / 180f) * totalRange
                            val newValue = (value + valueDelta).coerceIn(range.start, range.endInclusive)
                            onValueChange(newValue)
                        }
                    )
                },
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.size(size)) {
                val center = Offset(this.size.width / 2f, this.size.height / 2f)
                val outerRadius = this.size.width / 2f - 4.dp.toPx()
                val knobRadius = outerRadius * 0.72f
                val strokeWidth = 5.dp.toPx()

                // 1. Draw outer tick marks
                val totalTicks = 21
                val tickStep = sweepAngle / (totalTicks - 1)
                for (i in 0 until totalTicks) {
                    val angleDeg = startAngle + i * tickStep
                    val angleRad = Math.toRadians(angleDeg.toDouble())
                    val isCenterTick = i == (totalTicks / 2)
                    val tickLen = if (isCenterTick) 6.dp.toPx() else 4.dp.toPx()
                    val tickStart = Offset(
                        center.x + (outerRadius - tickLen) * cos(angleRad).toFloat(),
                        center.y + (outerRadius - tickLen) * sin(angleRad).toFloat()
                    )
                    val tickEnd = Offset(
                        center.x + outerRadius * cos(angleRad).toFloat(),
                        center.y + outerRadius * sin(angleRad).toFloat()
                    )
                    val isTickActive = (startAngle + i * tickStep) <= currentAngle
                    val tickColor = if (isTickActive) activeColor.copy(alpha = 0.85f) else Color.White.copy(alpha = 0.2f)
                    drawLine(
                        color = tickColor,
                        start = tickStart,
                        end = tickEnd,
                        strokeWidth = if (isCenterTick) 2.5f else 1.5f,
                        cap = StrokeCap.Round
                    )
                }

                // 2. Inactive Background Track Arc
                drawArc(
                    color = inactiveColor,
                    startAngle = startAngle,
                    sweepAngle = sweepAngle,
                    useCenter = false,
                    style = Stroke(width = strokeWidth, cap = StrokeCap.Round),
                    topLeft = Offset(center.x - knobRadius - 4.dp.toPx(), center.y - knobRadius - 4.dp.toPx()),
                    size = androidx.compose.ui.geometry.Size((knobRadius + 4.dp.toPx()) * 2, (knobRadius + 4.dp.toPx()) * 2)
                )

                // 3. Active Colored Arc
                val activeSweep = fraction * sweepAngle
                if (activeSweep > 0.5f) {
                    drawArc(
                        brush = Brush.sweepGradient(
                            listOf(activeColor.copy(alpha = 0.7f), activeColor, activeColor),
                            center = center
                        ),
                        startAngle = startAngle,
                        sweepAngle = activeSweep,
                        useCenter = false,
                        style = Stroke(width = strokeWidth, cap = StrokeCap.Round),
                        topLeft = Offset(center.x - knobRadius - 4.dp.toPx(), center.y - knobRadius - 4.dp.toPx()),
                        size = androidx.compose.ui.geometry.Size((knobRadius + 4.dp.toPx()) * 2, (knobRadius + 4.dp.toPx()) * 2)
                    )
                }

                // 4. Poweramp Brushed Metallic Knob Body
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            Color(0xFF383E4E),
                            Color(0xFF1E222B),
                            Color(0xFF11141A)
                        ),
                        center = Offset(center.x - knobRadius * 0.2f, center.y - knobRadius * 0.2f),
                        radius = knobRadius
                    ),
                    radius = knobRadius,
                    center = center
                )

                // Knob edge rim highlight
                drawCircle(
                    color = Color.White.copy(alpha = 0.15f),
                    radius = knobRadius,
                    center = center,
                    style = Stroke(width = 1.5.dp.toPx())
                )

                // 5. Indicator Notch / Needle
                val needleRad = Math.toRadians(currentAngle.toDouble())
                val needleStart = Offset(
                    center.x + (knobRadius * 0.35f) * cos(needleRad).toFloat(),
                    center.y + (knobRadius * 0.35f) * sin(needleRad).toFloat()
                )
                val needleEnd = Offset(
                    center.x + (knobRadius * 0.88f) * cos(needleRad).toFloat(),
                    center.y + (knobRadius * 0.88f) * sin(needleRad).toFloat()
                )
                drawLine(
                    color = activeColor,
                    start = needleStart,
                    end = needleEnd,
                    strokeWidth = 3.dp.toPx(),
                    cap = StrokeCap.Round
                )
                // Glowing pip at tip
                drawCircle(
                    color = activeColor,
                    radius = 2.5.dp.toPx(),
                    center = needleEnd
                )

                // 6. Center Dimple
                drawCircle(
                    color = ObsidianBg,
                    radius = knobRadius * 0.2f,
                    center = center
                )
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // Knob Label
        Text(
            text = label.uppercase(),
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White.copy(alpha = 0.85f),
            letterSpacing = 1.sp
        )

        // Readout
        val formattedVal = when {
            unit == "dB" -> "${if (value > 0) "+" else ""}${String.format("%.1f", value)} $unit"
            unit == "%" -> "${value.toInt()}%"
            unit == "x" -> "${String.format("%.2f", value)}x"
            else -> "${if (value > 0) "+" else ""}${String.format("%.1f", value)}"
        }
        Text(
            text = formattedVal,
            fontSize = 12.sp,
            fontWeight = FontWeight.ExtraBold,
            color = if (value > defaultValue) activeColor else if (value < defaultValue) NeonPink else Color.LightGray
        )
    }
}
