package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddAlert
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.localization.PanchangStrings
import com.example.model.AppLanguage
import com.example.model.DailyPanchang
import com.example.panchang.VedicPanchangCalculator
import com.example.ui.theme.BichhudaBadge
import com.example.ui.theme.PanchakBadge

@Composable
fun PanchakBichhudaScreen(
    panchang: DailyPanchang,
    language: AppLanguage,
    onSetPanchakReminder: () -> Unit,
    onSetBichhudaReminder: () -> Unit,
    modifier: Modifier = Modifier
) {
    val upcomingPanchak = remember { VedicPanchangCalculator.getUpcomingPanchakList() }
    val upcomingBichhuda = remember { VedicPanchangCalculator.getUpcomingBichhudaList() }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(Color.White)
            .padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(4.dp))
            // Current Status Live Hero
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = Color.White
                ),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE0E0E0)),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "वर्तमान स्थिति (Today's Live Status)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.Black
                    )

                    // Panchak Status Row
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (panchang.panchak.isActive) PanchakBadge.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = if (panchang.panchak.isActive) Icons.Default.Warning else Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = if (panchang.panchak.isActive) PanchakBadge else Color(0xFF4CAF50),
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = if (panchang.panchak.isActive) "पंचक सक्रिय है (${panchang.panchak.title})" else "आज पंचक नहीं है (Panchak Free)",
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = if (panchang.panchak.isActive) PanchakBadge else MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = "नक्षत्र: ${panchang.nakshatra} • ${panchang.panchak.todayStatusText}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.85f)
                                    )
                                }
                            }

                            Button(
                                onClick = onSetPanchakReminder,
                                colors = ButtonDefaults.buttonColors(containerColor = PanchakBadge),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.testTag("set_panchak_reminder_btn")
                            ) {
                                Text("अलर्ट", style = MaterialTheme.typography.labelSmall)
                            }
                        }

                        // Panchak Exact Timings Card (Zero Clipping)
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color.White.copy(alpha = 0.95f))
                                .padding(8.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Column(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(Color(0xFFF7F7F7))
                                        .padding(6.dp)
                                ) {
                                    Text(text = "🕒 कब लगेगा (शुरू):", style = MaterialTheme.typography.labelSmall, color = Color(0xFF555555))
                                    Text(text = panchang.panchak.lagneKaTime, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = Color.Black)
                                }
                                Column(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(Color(0xFFF7F7F7))
                                        .padding(6.dp)
                                ) {
                                    Text(text = "⏳ कब उतरेगा (अंत):", style = MaterialTheme.typography.labelSmall, color = Color(0xFF555555))
                                    Text(text = panchang.panchak.utarneKaTime, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = Color.Black)
                                }
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(text = "⏱️ कुल समय (अवधि):", style = MaterialTheme.typography.labelSmall, color = Color(0xFF555555))
                                Text(text = panchang.panchak.durationText, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = PanchakBadge)
                            }
                        }
                    }

                    // Bichhuda Status Row
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (panchang.bichhuda.isActive) BichhudaBadge.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(text = if (panchang.bichhuda.isActive) "🦂" else "✓", fontSize = 22.sp)
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = if (panchang.bichhuda.isActive) "बिछुड़ा सक्रिय (वृश्चिक राशि चंद्र)" else "आज बिछुड़ा नहीं है (No Bichhuda)",
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = if (panchang.bichhuda.isActive) BichhudaBadge else MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = "चंद्र राशि: ${panchang.moonSign} • ${panchang.bichhuda.todayStatusText}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.85f)
                                    )
                                }
                            }

                            Button(
                                onClick = onSetBichhudaReminder,
                                colors = ButtonDefaults.buttonColors(containerColor = BichhudaBadge),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.testTag("set_bichhuda_reminder_btn")
                            ) {
                                Text("अलर्ट", style = MaterialTheme.typography.labelSmall)
                            }
                        }

                        // Bichhuda Exact Timings Card (Zero Clipping)
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color.White.copy(alpha = 0.95f))
                                .padding(8.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Column(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(Color(0xFFF7F7F7))
                                        .padding(6.dp)
                                ) {
                                    Text(text = "🕒 कब लगेगा (शुरू):", style = MaterialTheme.typography.labelSmall, color = Color(0xFF555555))
                                    Text(text = panchang.bichhuda.lagneKaTime, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = Color.Black)
                                }
                                Column(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(Color(0xFFF7F7F7))
                                        .padding(6.dp)
                                ) {
                                    Text(text = "⏳ कब उतरेगा (अंत):", style = MaterialTheme.typography.labelSmall, color = Color(0xFF555555))
                                    Text(text = panchang.bichhuda.utarneKaTime, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = Color.Black)
                                }
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(text = "⏱️ कुल समय (अवधि):", style = MaterialTheme.typography.labelSmall, color = Color(0xFF555555))
                                Text(text = panchang.bichhuda.durationText, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = BichhudaBadge)
                            }
                        }
                    }
                }
            }
        }

        // Section: What is Panchak & 5 Types
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE0E0E0)),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "पंचक क्या है? (What is Panchak)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.Black
                    )

                    Text(
                        text = "वैदिक ज्योतिष में जब चंद्रमा कुम्भ और मीन राशि में गोचर करते हैं, तब यह 5 नक्षत्रों—धनिष्ठा (उत्तरार्ध), शतभिषा, पूर्वाभाद्रपद, उत्तराभाद्रपद और रेवती से गुजरते हैं। इस काल को 'पंचक' कहा जाता है।",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF222222),
                        lineHeight = 18.sp
                    )

                    HorizontalDivider(color = Color(0xFFEEEEEE))

                    Text(
                        text = "दिन के अनुसार पंचक के 5 प्रकार:",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = Color.Black
                    )

                    PanchakTypeExplainRow("1. रोग पंचक (रविवार)", "शारीरिक कष्ट व बीमारी का भय, स्वास्थ्य सतर्कता आवश्यक।")
                    PanchakTypeExplainRow("2. राज पंचक (सोमवार)", "शुभ एवं फलदायी! सरकारी काम, संपत्ति, पद प्राप्ति हेतु शुभ।")
                    PanchakTypeExplainRow("3. अग्नि पंचक (मंगलवार)", "अग्नि, मशीनरी व कोर्ट कचहरी विवाद में सावधानी रखें।")
                    PanchakTypeExplainRow("4. चोर पंचक (शुक्रवार)", "धन हानि, यात्रा व लेन-देन में विशेष सावधानी बरतें।")
                    PanchakTypeExplainRow("5. मृत्यु पंचक (शनिवार)", "मृत्यु तुल्य कष्ट व भारी जोखिम, नए कार्यों से पूर्णतः बचें।")

                    HorizontalDivider(color = Color(0xFFEEEEEE))

                    Text(
                        text = "पंचक में वर्जित 5 मुख्य कार्य:",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = PanchakBadge
                    )

                    Text(text = "• १. दक्षिण दिशा की यात्रा (यम की दिशा मानी जाती है)", style = MaterialTheme.typography.bodySmall, color = Color(0xFF333333))
                    Text(text = "• २. मकान की छत (लेंटर) डलवाना", style = MaterialTheme.typography.bodySmall, color = Color(0xFF333333))
                    Text(text = "• ३. चारपाई या पलंग बुनना/बनवाना", style = MaterialTheme.typography.bodySmall, color = Color(0xFF333333))
                    Text(text = "• ४. ईंधन व काष्ठ (लकड़ी) का संग्रह करना", style = MaterialTheme.typography.bodySmall, color = Color(0xFF333333))
                    Text(text = "• ५. शवदाह में विशेष आटे के पुतले बनाकर शांति विधान करना", style = MaterialTheme.typography.bodySmall, color = Color(0xFF333333))
                }
            }
        }

        // Upcoming Panchak Dates Table
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE0E0E0)),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "आगामी पंचक कैलेंडर (Upcoming Panchak)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.Black
                    )

                    upcomingPanchak.forEach { item ->
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFFF8F9FA))
                                .border(0.5.dp, Color(0xFFE0E0E0), RoundedCornerShape(8.dp))
                                .padding(10.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = item["dates"] ?: "",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.Black
                                )
                                Text(
                                    text = item["type"] ?: "",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Bold,
                                    color = PanchakBadge
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "🕒 कब लगेगा: ${item["lagneKaTime"] ?: ""}",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = Color(0xFF222222)
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "⏳ कब उतरेगा: ${item["utarneKaTime"] ?: ""}",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = Color(0xFF222222)
                                )
                                Text(
                                    text = "अवधि: ${item["duration"] ?: ""}",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontSize = 10.5.sp,
                                    color = Color(0xFF666666)
                                )
                            }

                            Text(
                                text = "प्रभाव: ${item["status"] ?: ""}",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF555555),
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }
        }

        // Section: What is Bichhuda?
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE0E0E0)),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(text = "🦂", fontSize = 24.sp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "बिछुड़ा / बिछुआ क्या है? (What is Bichhuda)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = BichhudaBadge
                        )
                    }

                    Text(
                        text = "राजस्थान, गुजरात, मालवा (मध्य प्रदेश), हरियाणा व पश्चिमी उत्तर प्रदेश में 'बिछुड़ा' या 'बिछुआ' को अत्यधिक महत्वपूर्ण माना जाता है। जब चंद्रमा वृश्चिक राशि में प्रवेश करते हैं (विशेषकर अनुराधा और ज्येष्ठा नक्षत्र में), तो यह अवधि लगभग ढाई दिन (५० से ५६ घंटे) तक 'बिछुड़ा काल' कहलाती है।",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF222222),
                        lineHeight = 18.sp
                    )

                    HorizontalDivider(color = Color(0xFFEEEEEE))

                    Text(
                        text = "बिछुड़ा काल के लोक नियम एवं मान्यताएं:",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = Color.Black
                    )

                    Text(
                        text = "• विवाह सगाई व पक्की बातचीत: लोक परंपरा में बिछुड़ा काल के दौरान शादी की तारीख पक्की करना या सगाई का नारियल देना टाला जाता है।",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF333333)
                    )
                    Text(
                        text = "• नवीन वधु का ससुराल/मायके गमन: नई दुल्हन को बिछुड़ा काल में विदा करना या गृह प्रवेश करवाना वर्जित माना जाता है।",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF333333)
                    )
                    Text(
                        text = "• आभूषण व नवीन वस्त्र क्रय: सोने-चांदी के गहनों की खरीदारी में सावधानी रखी जाती है।",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF333333)
                    )

                    HorizontalDivider(color = Color(0xFFEEEEEE))

                    Text(
                        text = "बिछुड़ा शांति व शुभ उपाय:",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF2E7D32)
                    )

                    Text(
                        text = "१. भगवान शिव का जलाभिषेक व 'ॐ नमः शिवाय' अथवा महामृत्युंजय मंत्र का जप करना सर्वोत्तम कवच है।",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF333333)
                    )
                    Text(
                        text = "२. काले तिल, गुड़ व उड़द का दान करने से वृश्चिक चंद्र के सभी दोष समाप्त हो जाते हैं।",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF333333)
                    )
                }
            }
        }

        // Upcoming Bichhuda Dates Table
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE0E0E0)),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "आगामी बिछुड़ा कैलेंडर (Upcoming Bichhuda)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.Black
                    )

                    upcomingBichhuda.forEach { item ->
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFFF8F9FA))
                                .border(0.5.dp, Color(0xFFE0E0E0), RoundedCornerShape(8.dp))
                                .padding(10.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = item["dates"] ?: "",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.Black
                                )
                                Text(
                                    text = item["sign"] ?: "",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Bold,
                                    color = BichhudaBadge
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "🕒 कब लगेगा: ${item["lagneKaTime"] ?: ""}",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = Color(0xFF222222)
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "⏳ कब उतरेगा: ${item["utarneKaTime"] ?: ""}",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = Color(0xFF222222)
                                )
                                Text(
                                    text = "अवधि: ${item["duration"] ?: ""}",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontSize = 10.5.sp,
                                    color = Color(0xFF666666)
                                )
                            }

                            Text(
                                text = "नक्षत्र: ${item["nakshatras"] ?: ""} • सुझाव: ${item["guidance"] ?: ""}",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF555555),
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
private fun PanchakTypeExplainRow(title: String, desc: String) {
    Column(modifier = Modifier.padding(vertical = 2.dp)) {
        Text(
            text = title,
            style = MaterialTheme.typography.bodySmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )
        Text(
            text = desc,
            style = MaterialTheme.typography.bodySmall,
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
        )
    }
}
