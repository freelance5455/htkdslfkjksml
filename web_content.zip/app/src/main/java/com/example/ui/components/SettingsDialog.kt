package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.SequenceStyle
import com.example.model.TrafficConfig
import com.example.ui.theme.TrafficGreen
import com.example.ui.theme.TrafficRed
import com.example.ui.theme.TrafficYellow
import kotlin.math.roundToInt

@Composable
fun SettingsDialog(
    currentConfig: TrafficConfig,
    onDismiss: () -> Unit,
    onSave: (TrafficConfig) -> Unit
) {
    var redDuration by remember { mutableFloatStateOf(currentConfig.redDuration.toFloat()) }
    var yellowDuration by remember { mutableFloatStateOf(currentConfig.yellowDuration.toFloat()) }
    var greenDuration by remember { mutableFloatStateOf(currentConfig.greenDuration.toFloat()) }
    var walkDuration by remember { mutableFloatStateOf(currentConfig.pedestrianWalkDuration.toFloat()) }
    var soundEnabled by remember { mutableStateOf(currentConfig.soundEnabled) }
    var vibrationEnabled by remember { mutableStateOf(currentConfig.vibrationEnabled) }
    var sequenceStyle by remember { mutableStateOf(currentConfig.sequenceStyle) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = Color(0xFF171E28),
            border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFF2F3B4F)),
            shadowElevation = 16.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "إعدادات الإشارة والتوقيت",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )

                    IconButton(onClick = onDismiss) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "إغلاق",
                            tint = Color.LightGray
                        )
                    }
                }

                // RED Duration Slider
                DurationSliderItem(
                    title = "مدة الإشارة الحمراء",
                    value = redDuration,
                    range = 3f..30f,
                    color = TrafficRed,
                    onValueChange = { redDuration = it }
                )

                // YELLOW Duration Slider
                DurationSliderItem(
                    title = "مدة الإشارة الصفراء",
                    value = yellowDuration,
                    range = 2f..8f,
                    color = TrafficYellow,
                    onValueChange = { yellowDuration = it }
                )

                // GREEN Duration Slider
                DurationSliderItem(
                    title = "مدة الإشارة الخضراء",
                    value = greenDuration,
                    range = 3f..30f,
                    color = TrafficGreen,
                    onValueChange = { greenDuration = it }
                )

                // PEDESTRIAN WALK Duration Slider
                DurationSliderItem(
                    title = "مدة عبور المشاة",
                    value = walkDuration,
                    range = 4f..20f,
                    color = Color(0xFF00E676),
                    onValueChange = { walkDuration = it }
                )

                // Sequence Style Radio Group
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "نمط التتابع:",
                        style = MaterialTheme.typography.labelLarge,
                        color = Color.LightGray,
                        fontWeight = FontWeight.Bold
                    )

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        RadioButton(
                            selected = sequenceStyle == SequenceStyle.STANDARD,
                            onClick = { sequenceStyle = SequenceStyle.STANDARD },
                            colors = RadioButtonDefaults.colors(selectedColor = Color(0xFF29B6F6))
                        )
                        Text(
                            text = "قياسي (أحمر -> أخضر -> أصفر)",
                            color = Color.White,
                            fontSize = 12.sp
                        )
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        RadioButton(
                            selected = sequenceStyle == SequenceStyle.EUROPEAN,
                            onClick = { sequenceStyle = SequenceStyle.EUROPEAN },
                            colors = RadioButtonDefaults.colors(selectedColor = Color(0xFF29B6F6))
                        )
                        Text(
                            text = "أوروبي (أحمر -> أحمر وأصفر -> أخضر)",
                            color = Color.White,
                            fontSize = 12.sp
                        )
                    }
                }

                // Sound & Vibrate switches
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("المؤثرات الصوتية", color = Color.White)
                    Switch(
                        checked = soundEnabled,
                        onCheckedChange = { soundEnabled = it },
                        colors = SwitchDefaults.colors(checkedThumbColor = TrafficGreen)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("الاهتزاز التفاعلي", color = Color.White)
                    Switch(
                        checked = vibrationEnabled,
                        onCheckedChange = { vibrationEnabled = it },
                        colors = SwitchDefaults.colors(checkedThumbColor = TrafficGreen)
                    )
                }

                // Actions
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = {
                            // Reset to defaults
                            redDuration = 10f
                            yellowDuration = 3f
                            greenDuration = 12f
                            walkDuration = 8f
                            soundEnabled = true
                            vibrationEnabled = true
                            sequenceStyle = SequenceStyle.STANDARD
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2A3649)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Restore, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("افتراضي", fontSize = 12.sp)
                    }

                    Button(
                        onClick = {
                            onSave(
                                TrafficConfig(
                                    redDuration = redDuration.roundToInt(),
                                    yellowDuration = yellowDuration.roundToInt(),
                                    greenDuration = greenDuration.roundToInt(),
                                    pedestrianWalkDuration = walkDuration.roundToInt(),
                                    soundEnabled = soundEnabled,
                                    vibrationEnabled = vibrationEnabled,
                                    sequenceStyle = sequenceStyle
                                )
                            )
                            onDismiss()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1976D2)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1.5f)
                            .testTag("btn_save_settings")
                    ) {
                        Text("حفظ الإعدادات", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun DurationSliderItem(
    title: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    color: Color,
    onValueChange: (Float) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(color)
                )
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.LightGray
                )
            }

            Text(
                text = "${value.roundToInt()} ثوانٍ",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }

        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = range,
            steps = (range.endInclusive - range.start).roundToInt() - 1,
            colors = SliderDefaults.colors(
                thumbColor = color,
                activeTrackColor = color,
                inactiveTrackColor = Color(0xFF283446)
            )
        )
    }
}
