package com.example.ui.screens

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.R
import com.example.data.local.DiaryEntryEntity
import com.example.data.model.AiResultType
import com.example.data.model.AiSpaceResult
import com.example.data.model.ChatMessage
import com.example.data.model.MoodType
import com.example.localization.LocalizedStrings
import com.example.ui.components.AiFirebaseNoticeBanner
import com.example.ui.components.AiGestureAction
import com.example.ui.components.AiGesturePadCard
import com.example.ui.components.toAiResultType
import com.example.ui.theme.FreshAirGreenSoft
import com.example.ui.theme.LavenderContainer
import com.example.ui.theme.SleepIndigoSoft
import com.example.ui.theme.VitalityAmberSoft
import com.example.ui.theme.WaterBlueSoft
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PillowScreen(
    strings: LocalizedStrings,
    isDataFreeMode: Boolean,
    isSubscribed: Boolean,
    selectedMood: MoodType,
    aiSpaceResults: List<AiSpaceResult>,
    chatMessages: List<ChatMessage>,
    isAiThinking: Boolean,
    diaryEntries: List<DiaryEntryEntity>,
    onSelectMood: (MoodType) -> Unit,
    onAskAiSpace: (prompt: String, resultType: AiResultType) -> Unit,
    onSendPillowMessage: (String) -> Unit,
    onSaveDiaryEntry: (title: String, content: String, mood: MoodType, energy: Int, isVoiceTyped: Boolean) -> Unit,
    onDeleteDiaryEntry: (Int) -> Unit,
    onBackupToEmail: () -> Unit,
    onOpenSubscribeSheet: () -> Unit
) {
    val context = LocalContext.current
    var selectedTab by remember { mutableIntStateOf(0) } // 0 = AI Space, 1 = Pillow Chat, 2 = Voice Diary
    var aiSpacePrompt by remember { mutableStateOf("") }
    var selectedResultType by remember { mutableStateOf(AiResultType.ACTION_PLAN) }
    var chatInput by remember { mutableStateOf("") }
    var diaryTitle by remember { mutableStateOf("") }
    var diaryContent by remember { mutableStateOf("") }
    var diaryEnergy by remember { mutableFloatStateOf(3f) }
    var usedVoiceTyping by remember { mutableStateOf(false) }
    var isListeningLive by remember { mutableStateOf(false) }
    var voiceStatusHint by remember { mutableStateOf<String?>(null) }

    val speechRecognizer = remember {
        if (SpeechRecognizer.isRecognitionAvailable(context)) {
            SpeechRecognizer.createSpeechRecognizer(context)
        } else null
    }

    DisposableEffect(speechRecognizer) {
        onDispose {
            speechRecognizer?.destroy()
        }
    }

    val voiceIntentLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spoken.isNullOrBlank()) {
                when (selectedTab) {
                    0 -> aiSpacePrompt = if (aiSpacePrompt.isBlank()) spoken else "$aiSpacePrompt $spoken"
                    1 -> chatInput = if (chatInput.isBlank()) spoken else "$chatInput $spoken"
                    else -> {
                        diaryContent = if (diaryContent.isBlank()) spoken else "$diaryContent $spoken"
                        usedVoiceTyping = true
                    }
                }
            }
        }
    }

    val launchVoiceDialogFallback: () -> Unit = {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak freely—Haven is listening...")
        }
        try {
            voiceIntentLauncher.launch(intent)
        } catch (_: Exception) {
            voiceStatusHint = "Voice keyboard unavailable on this device—type your thoughts below."
        }
    }

    val startLiveSpeechRecognition: () -> Unit = {
        if (speechRecognizer != null) {
            val recognizerIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            }
            speechRecognizer.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    isListeningLive = true
                    voiceStatusHint = "Listening... speak your thoughts & feelings."
                }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {
                    isListeningLive = false
                }
                override fun onError(error: Int) {
                    isListeningLive = false
                    voiceStatusHint = null
                    launchVoiceDialogFallback()
                }
                override fun onResults(results: Bundle?) {
                    isListeningLive = false
                    voiceStatusHint = "Voice entry transcribed!"
                    val spoken = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (!spoken.isNullOrBlank()) {
                        diaryContent = if (diaryContent.isBlank()) spoken else "$diaryContent $spoken"
                        usedVoiceTyping = true
                    }
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            speechRecognizer.startListening(recognizerIntent)
        } else {
            launchVoiceDialogFallback()
        }
    }

    val audioPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            startLiveSpeechRecognition()
        } else {
            launchVoiceDialogFallback()
        }
    }

    val triggerVoiceDiary: () -> Unit = {
        if (!isSubscribed) {
            onOpenSubscribeSheet()
        } else if (isListeningLive) {
            speechRecognizer?.stopListening()
            isListeningLive = false
        } else {
            val hasAudioPerm = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
            if (hasAudioPerm) {
                startLiveSpeechRecognition()
            } else {
                audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            }
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(shape = RoundedCornerShape(24.dp)) {
                Column {
                    Image(
                        painter = painterResource(id = R.drawable.img_pillow_strength),
                        contentDescription = "Pillow of Strength & Personal AI Space",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxWidth().height(120.dp)
                    )
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text("Personal AI Space & Pillow", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        Text(
                            text = if (isDataFreeMode) {
                                "Offline Limited Mode: Basic local AI results & Voice Diary active."
                            } else {
                                "Full Data Mode: Emotional support, Action Plans, Phone Control & Daily Verses."
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        item {
            SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                SegmentedButton(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    shape = SegmentedButtonDefaults.itemShape(0, 3),
                    modifier = Modifier.testTag("tab_ai_space"),
                    label = { Text("AI Space") }
                )
                SegmentedButton(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    shape = SegmentedButtonDefaults.itemShape(1, 3),
                    modifier = Modifier.testTag("tab_pillow_ai"),
                    label = { Text("Pillow Chat") }
                )
                SegmentedButton(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    shape = SegmentedButtonDefaults.itemShape(2, 3),
                    modifier = Modifier.testTag("tab_voice_diary"),
                    label = { Text("Diary") }
                )
            }
        }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("How are you feeling right now?", style = MaterialTheme.typography.titleSmall)
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    MoodType.entries.forEach { mood ->
                        FilterChip(
                            selected = selectedMood == mood,
                            onClick = { onSelectMood(mood) },
                            label = { Text(mood.label) }
                        )
                    }
                }
            }
        }

        if (selectedTab == 0) {
            item {
                AiGesturePadCard(
                    isSubscribed = isSubscribed,
                    onActionTriggered = { gesture ->
                        when (gesture) {
                            AiGestureAction.VOICE_OR_PHONE_CONTROL -> {
                                if (!isSubscribed) {
                                    onOpenSubscribeSheet()
                                } else {
                                    selectedResultType = AiResultType.PHONE_COMMAND
                                    onAskAiSpace("Run quick voice/phone focus check", AiResultType.PHONE_COMMAND)
                                }
                            }
                            else -> {
                                val rt = gesture.toAiResultType()
                                selectedResultType = rt
                                val prompt = when (gesture) {
                                    AiGestureAction.OPEN_AI_SPACE -> "Build my focus & wellness plan for today"
                                    AiGestureAction.EMOTIONAL_CALM -> "Help me calm my mind right now"
                                    AiGestureAction.WAKE_UP_AND_MOTIVATE -> "Give me a morning wake up boost & scripture"
                                    AiGestureAction.SLEEP_QUIET_TOGGLE -> "Prepare calm wind-down routine"
                                    AiGestureAction.VOICE_OR_PHONE_CONTROL -> "Control phone"
                                }
                                onAskAiSpace(prompt, rt)
                            }
                        }
                    }
                )
            }

            // Dedicated Personal AI Space with 4 distinct result types
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = LavenderContainer)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = "Choose AI Result Type",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        AssistChip(
                            onClick = { if (!isSubscribed) onOpenSubscribeSheet() },
                            modifier = Modifier.testTag("ai_speed_status_chip"),
                            label = {
                                Text(
                                    if (isSubscribed) "⚡ AI Fast Mode + Voice Control Unlocked"
                                    else "🐢 Slow Free AI (4.5s) • Tap to Unlock R5+"
                                )
                            }
                        )
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            AiResultType.entries.forEach { type ->
                                val lockedPhoneCmd = type == AiResultType.PHONE_COMMAND && !isSubscribed
                                FilterChip(
                                    selected = selectedResultType == type,
                                    onClick = {
                                        if (lockedPhoneCmd) onOpenSubscribeSheet()
                                        else selectedResultType = type
                                    },
                                    modifier = Modifier.testTag("ai_type_${type.name.lowercase()}"),
                                    label = {
                                        Text(
                                            if (lockedPhoneCmd) "${type.label} 🔒 (R5+)"
                                            else "${type.label} • ${type.badge}"
                                        )
                                    }
                                )
                            }
                        }

                        OutlinedTextField(
                            value = aiSpacePrompt,
                            onValueChange = { aiSpacePrompt = it },
                            label = { Text("Ask Personal AI or give a phone command...") },
                            placeholder = { Text("e.g. Help me plan study time / Set alarm 6:30 / I feel stressed") },
                            modifier = Modifier.fillMaxWidth().testTag("ai_space_prompt_input"),
                            trailingIcon = {
                                IconButton(
                                    onClick = {
                                        if (!isSubscribed) onOpenSubscribeSheet() else launchVoiceDialogFallback()
                                    }
                                ) {
                                    Icon(
                                        Icons.Filled.Mic,
                                        contentDescription = if (isSubscribed) "Speak prompt" else "Subscribe to unlock Voice Control"
                                    )
                                }
                            }
                        )

                        Button(
                            onClick = {
                                if (selectedResultType == AiResultType.PHONE_COMMAND && !isSubscribed) {
                                    onOpenSubscribeSheet()
                                } else {
                                    onAskAiSpace(aiSpacePrompt, selectedResultType)
                                    aiSpacePrompt = ""
                                }
                            },
                            enabled = !isAiThinking,
                            modifier = Modifier.fillMaxWidth().testTag("ai_space_submit_button")
                        ) {
                            if (isAiThinking) {
                                CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                                Spacer(modifier = Modifier.width(8.dp))
                            }
                            Text(if (isAiThinking && !isSubscribed) "Thinking slowly (Free AI)..." else "Generate ${selectedResultType.label}")
                        }
                    }
                }
            }

            if (aiSpaceResults.isEmpty()) {
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = WaterBlueSoft)) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("4 Distinct Personal AI Results", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                            Text(
                                text = "Pick Emotional Support, Smart Action Plan, Phone Control, or Motivation & Verse above to see tailored results inside your private AI Space.",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
            } else {
                items(aiSpaceResults, key = { it.id }) { res ->
                    val cardTint = when (res.resultType) {
                        AiResultType.EMOTIONAL_SUPPORT -> WaterBlueSoft
                        AiResultType.ACTION_PLAN -> FreshAirGreenSoft
                        AiResultType.PHONE_COMMAND -> VitalityAmberSoft
                        AiResultType.MOTIVATION_VERSE -> SleepIndigoSoft
                    }
                    Card(colors = CardDefaults.cardColors(containerColor = cardTint)) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                AssistChip(onClick = {}, label = { Text(res.resultType.label) })
                                if (res.isDataLimited) {
                                    Text("Offline Basic", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                }
                            }
                            Text(res.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text("Prompt: \"${res.prompt}\"", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(res.body, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }
        } else if (selectedTab == 1) {
            item { AiFirebaseNoticeBanner() }

            item {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(
                        "I feel overwhelmed with school",
                        "I'm sad and need comfort",
                        "I'm stressed about body changes"
                    ).forEach { prompt ->
                        AssistChip(
                            onClick = { onSendPillowMessage(prompt) },
                            label = { Text(prompt, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }
            }

            items(chatMessages, key = { it.id }) { msg ->
                val bgColor = if (msg.isFromUser) {
                    MaterialTheme.colorScheme.primaryContainer
                } else {
                    MaterialTheme.colorScheme.surfaceVariant
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = if (msg.isFromUser) Arrangement.End else Arrangement.Start
                ) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = bgColor),
                        modifier = Modifier.fillMaxWidth(0.88f)
                    ) {
                        Text(
                            text = msg.text,
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                }
            }

            if (isAiThinking) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                        Text("Listening gently...", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }

            item {
                OutlinedTextField(
                    value = chatInput,
                    onValueChange = { chatInput = it },
                    placeholder = { Text("Tell your Pillow of Strength how you feel...") },
                    modifier = Modifier.fillMaxWidth().testTag("pillow_chat_input"),
                    trailingIcon = {
                        Row {
                            IconButton(
                                onClick = {
                                    if (!isSubscribed) onOpenSubscribeSheet() else launchVoiceDialogFallback()
                                }
                            ) {
                                Icon(Icons.Filled.Mic, contentDescription = "Voice type message")
                            }
                            IconButton(
                                onClick = {
                                    onSendPillowMessage(chatInput)
                                    chatInput = ""
                                },
                                modifier = Modifier.testTag("pillow_send_button")
                            ) {
                                Icon(Icons.Filled.Send, contentDescription = "Send to Pillow")
                            }
                        }
                    }
                )
            }
        } else {
            // Voice-Activated Diary with Emotional Cue Recognition
            item {
                AiFirebaseNoticeBanner()
            }

            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(strings.voiceDiaryTitle, style = MaterialTheme.typography.titleMedium)

                        Button(
                            onClick = triggerVoiceDiary,
                            colors = if (isListeningLive) {
                                ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                            } else {
                                ButtonDefaults.buttonColors()
                            },
                            modifier = Modifier.fillMaxWidth().height(50.dp).testTag("voice_diary_mic_button")
                        ) {
                            Icon(
                                imageVector = if (isListeningLive) Icons.Filled.Stop else Icons.Filled.GraphicEq,
                                contentDescription = null
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(if (isListeningLive) "Stop Listening" else strings.tapToSpeak)
                        }

                        voiceStatusHint?.let { hint ->
                            Text(hint, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                        }

                        OutlinedTextField(
                            value = diaryTitle,
                            onValueChange = { diaryTitle = it },
                            label = { Text("Entry Title (optional)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = diaryContent,
                            onValueChange = { diaryContent = it },
                            label = { Text("Speak or write how you feel (AI detects emotional cues)") },
                            minLines = 3,
                            modifier = Modifier.fillMaxWidth().testTag("diary_content_input")
                        )

                        Text("Energy Level: ${diaryEnergy.roundToInt()} / 5", style = MaterialTheme.typography.labelLarge)
                        Slider(
                            value = diaryEnergy,
                            onValueChange = { diaryEnergy = it },
                            valueRange = 1f..5f,
                            steps = 3
                        )

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                            Button(
                                onClick = {
                                    onSaveDiaryEntry(
                                        diaryTitle,
                                        diaryContent,
                                        selectedMood,
                                        diaryEnergy.roundToInt(),
                                        usedVoiceTyping
                                    )
                                    diaryTitle = ""
                                    diaryContent = ""
                                    usedVoiceTyping = false
                                    voiceStatusHint = null
                                },
                                modifier = Modifier.weight(1f).testTag("save_diary_button")
                            ) {
                                Text("Save & Analyze")
                            }
                            OutlinedButton(
                                onClick = onBackupToEmail,
                                modifier = Modifier.weight(1f).testTag("email_backup_button")
                            ) {
                                Icon(Icons.Filled.Backup, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(strings.backupEmailAction)
                            }
                        }
                    }
                }
            }

            // Mood Trends Over Time Chart
            if (diaryEntries.isNotEmpty()) {
                item {
                    MoodTrendCard(entries = diaryEntries)
                }
            }

            if (diaryEntries.isEmpty()) {
                item {
                    Card {
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(Icons.Filled.EditNote, contentDescription = null, modifier = Modifier.size(40.dp))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Your private voice diary is empty", style = MaterialTheme.typography.titleMedium)
                            Text(
                                "Tap the mic to speak—Haven transcribes, recognizes emotional cues, and tracks mood trends over time.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            } else {
                items(diaryEntries, key = { it.id }) { entry ->
                    val dateText = SimpleDateFormat("MMM d, HH:mm", Locale.getDefault()).format(Date(entry.timestamp))
                    Card {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(entry.title, style = MaterialTheme.typography.titleMedium)
                                IconButton(onClick = { onDeleteDiaryEntry(entry.id) }) {
                                    Icon(Icons.Filled.Delete, contentDescription = "Delete entry")
                                }
                            }
                            Text(
                                text = "$dateText • Mood: ${MoodType.fromKey(entry.moodKey).label} • Energy ${entry.energyScore}/5" +
                                    if (entry.isVoiceTyped) " • Voice-typed" else "",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                            if (entry.detectedCue.isNotBlank()) {
                                AssistChip(
                                    onClick = {},
                                    leadingIcon = { Icon(Icons.Filled.Psychology, contentDescription = null, modifier = Modifier.size(16.dp)) },
                                    label = { Text("Cue: ${entry.detectedCue}", style = MaterialTheme.typography.labelSmall) }
                                )
                            }
                            Text(entry.content, style = MaterialTheme.typography.bodyMedium)
                            if (entry.aiSupportResponse.isNotBlank()) {
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                                ) {
                                    Text(
                                        text = entry.aiSupportResponse,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        modifier = Modifier.padding(10.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun MoodTrendCard(entries: List<DiaryEntryEntity>) {
    val chronological = entries.take(10).reversed()
    val lineColor = MaterialTheme.colorScheme.primary
    val dotColor = MaterialTheme.colorScheme.secondary
    val moodCounts = entries.groupingBy { MoodType.fromKey(it.moodKey).label }.eachCount()

    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.TrendingUp, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Mood & Energy Trends Over Time", style = MaterialTheme.typography.titleMedium)
            }
            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(84.dp)
                    .padding(horizontal = 8.dp, vertical = 6.dp)
            ) {
                if (chronological.size == 1) {
                    val y = size.height * (1f - (chronological[0].energyScore - 1) / 4f)
                    drawCircle(color = dotColor, radius = 10f, center = Offset(size.width / 2f, y))
                } else if (chronological.size > 1) {
                    val stepX = size.width / (chronological.size - 1).toFloat()
                    val path = Path()
                    chronological.forEachIndexed { idx, entry ->
                        val x = idx * stepX
                        val y = size.height * (1f - (entry.energyScore - 1) / 4f)
                        if (idx == 0) path.moveTo(x, y) else path.lineTo(x, y)
                    }
                    drawPath(path = path, color = lineColor, style = Stroke(width = 6f, cap = StrokeCap.Round))
                    chronological.forEachIndexed { idx, entry ->
                        val x = idx * stepX
                        val y = size.height * (1f - (entry.energyScore - 1) / 4f)
                        drawCircle(color = dotColor, radius = 9f, center = Offset(x, y))
                    }
                }
            }
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                moodCounts.entries.forEach { (label, count) ->
                    AssistChip(onClick = {}, label = { Text("$label: $count") })
                }
            }
        }
    }
}
