package com.example.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.SufiEntry
import com.example.data.SufiLanguage
import com.example.ui.theme.GoldGleam
import com.example.ui.theme.GoldLuster
import com.example.ui.theme.GoldLusterBright
import com.example.ui.theme.SufiMaroon
import com.example.ui.theme.SufiMutedText
import com.example.ui.theme.TerracottaBackground
import com.example.ui.theme.TerracottaDark
import com.example.ui.theme.TerracottaWarm

/**
 * UnrollingParchmentCard:
 * Displays Sufi quotes with an unrolling scroll transition,
 * deep warm background, golden calligraphy accents and intuitive action controls.
 */
@Composable
fun UnrollingParchmentCard(
    entry: SufiEntry,
    language: SufiLanguage,
    isCandlelitMode: Boolean,
    isSaved: Boolean,
    onToggleSave: () -> Unit,
    onCopy: () -> Unit,
    onShare: () -> Unit,
    modifier: Modifier = Modifier
) {
    val unrollProgress = remember(entry.id) { Animatable(0f) }

    LaunchedEffect(entry.id) {
        unrollProgress.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = 650, easing = FastOutSlowInEasing)
        )
    }

    val p = unrollProgress.value

    Card(
        modifier = modifier
            .fillMaxWidth()
            .graphicsLayer {
                scaleY = 0.35f + 0.65f * p
                scaleX = 0.85f + 0.15f * p
                alpha = p.coerceIn(0f, 1f)
                cameraDistance = 12f * density
            }
            .shadow(14.dp, RoundedCornerShape(28.dp))
            .testTag("wisdom_card"),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isCandlelitMode)
                TerracottaDark.copy(alpha = 0.96f)
            else
                TerracottaBackground.copy(alpha = 0.94f)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .border(
                    width = 1.5.dp,
                    color = GoldLuster.copy(alpha = if (isCandlelitMode) 0.85f else 0.65f),
                    shape = RoundedCornerShape(28.dp)
                )
                .padding(horizontal = 26.dp, vertical = 26.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Antique Parchment Top Scroll Ribbons & Wax Seal Motif
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .height(1.dp)
                        .weight(1f)
                        .background(
                            Brush.horizontalGradient(
                                listOf(Color.Transparent, GoldLuster.copy(alpha = 0.6f))
                            )
                        )
                )

                Box(
                    modifier = Modifier
                        .padding(horizontal = 10.dp)
                        .size(24.dp)
                        .clip(CircleShape)
                        .background(SufiMaroon)
                        .border(1.dp, GoldLusterBright, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "📜",
                        fontSize = 11.sp
                    )
                }

                Box(
                    modifier = Modifier
                        .height(1.dp)
                        .weight(1f)
                        .background(
                            Brush.horizontalGradient(
                                listOf(GoldLuster.copy(alpha = 0.6f), Color.Transparent)
                            )
                        )
                )
            }

            // Theme pill
            if (!entry.theme.isNullOrBlank()) {
                Box(
                    modifier = Modifier
                        .background(TerracottaDark.copy(alpha = 0.45f), RoundedCornerShape(12.dp))
                        .border(1.dp, GoldLuster.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                        .padding(horizontal = 14.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = entry.theme.uppercase(),
                        style = MaterialTheme.typography.labelSmall,
                        fontFamily = FontFamily.Serif,
                        color = GoldLusterBright,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 2.sp,
                        fontSize = 10.sp
                    )
                }
                Spacer(modifier = Modifier.height(16.dp))
            }

            // Wisdom Content based on Language
            when (language) {
                SufiLanguage.MALAYALAM -> {
                    Text(
                        text = entry.ml,
                        style = MaterialTheme.typography.bodyLarge,
                        fontFamily = FontFamily.Serif,
                        textAlign = TextAlign.Center,
                        color = GoldGleam,
                        fontSize = 20.sp,
                        lineHeight = 34.sp,
                        modifier = Modifier.testTag("wisdom_text_ml")
                    )
                }

                SufiLanguage.ENGLISH -> {
                    Text(
                        text = "“${entry.en}”",
                        style = MaterialTheme.typography.bodyLarge,
                        fontFamily = FontFamily.Serif,
                        fontStyle = FontStyle.Italic,
                        textAlign = TextAlign.Center,
                        color = GoldGleam,
                        fontSize = 19.sp,
                        lineHeight = 32.sp,
                        modifier = Modifier.testTag("wisdom_text_en")
                    )
                }

                SufiLanguage.DUAL -> {
                    Text(
                        text = entry.ml,
                        style = MaterialTheme.typography.bodyLarge,
                        fontFamily = FontFamily.Serif,
                        textAlign = TextAlign.Center,
                        color = GoldGleam,
                        fontSize = 19.sp,
                        lineHeight = 32.sp
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Box(
                        modifier = Modifier
                            .width(40.dp)
                            .height(1.dp)
                            .background(GoldLuster.copy(alpha = 0.4f))
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = "“${entry.en}”",
                        style = MaterialTheme.typography.bodyLarge,
                        fontFamily = FontFamily.Serif,
                        fontStyle = FontStyle.Italic,
                        textAlign = TextAlign.Center,
                        color = SufiMutedText,
                        fontSize = 16.sp,
                        lineHeight = 26.sp
                    )
                }
            }

            // Author Name if Quote
            if (entry.isQuote && !entry.author.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(18.dp))
                Text(
                    text = "— ${entry.author}",
                    style = MaterialTheme.typography.labelLarge,
                    fontFamily = FontFamily.Serif,
                    fontStyle = FontStyle.Italic,
                    color = GoldLusterBright,
                    fontSize = 15.sp,
                    letterSpacing = 1.sp,
                    modifier = Modifier.testTag("author_name")
                )
            }

            Spacer(modifier = Modifier.height(22.dp))

            // Action toolbar: Bookmark, Copy, Share
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onToggleSave,
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("favorite_button")
                ) {
                    Icon(
                        imageVector = if (isSaved) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                        contentDescription = if (isSaved) "Remove bookmark" else "Save line",
                        tint = if (isSaved) GoldLusterBright else SufiMutedText,
                        modifier = Modifier.size(22.dp)
                    )
                }

                Spacer(modifier = Modifier.width(16.dp))

                IconButton(
                    onClick = onCopy,
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("copy_button")
                ) {
                    Icon(
                        imageVector = Icons.Outlined.ContentCopy,
                        contentDescription = "Copy line",
                        tint = SufiMutedText,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Spacer(modifier = Modifier.width(16.dp))

                IconButton(
                    onClick = onShare,
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("share_button")
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Share,
                        contentDescription = "Share line",
                        tint = SufiMutedText,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}
