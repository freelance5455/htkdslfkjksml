package com.example.ui.screens

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.text.SpannableString
import androidx.activity.compose.BackHandler
import androidx.annotation.OptIn
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.MovieCreation
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RangeSlider
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.audio.SonicAudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.OverlaySettings
import androidx.media3.effect.SpeedChangeEffect
import androidx.media3.effect.TextOverlay
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import androidx.media3.ui.PlayerView
import com.example.data.model.FileKind
import com.example.data.model.FileNode
import com.example.data.storage.DeviceAndSafStorageAdapter
import com.example.ui.viewmodel.AiStudioViewModel
import com.example.ui.viewmodel.AiTaskState
import com.example.ui.viewmodel.VideoAiInsights
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.coroutines.resume

@OptIn(UnstableApi::class)
@kotlin.OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiVideoEditorScreen(
    node: FileNode,
    siblingVideos: List<FileNode>,
    storageAdapter: DeviceAndSafStorageAdapter,
    aiViewModel: AiStudioViewModel,
    aiState: AiTaskState<VideoAiInsights>,
    onExportSaved: (String) -> Unit,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var localSourceFile by remember { mutableStateOf<File?>(null) }
    var durationMs by remember { mutableLongStateOf(5_000L) }
    var trimRange by remember { mutableStateOf(0f..1f) }
    var playbackSpeed by remember { mutableFloatStateOf(1f) }
    var muteAudio by remember { mutableStateOf(false) }
    var overlayText by remember { mutableStateOf("") }
    var mergeSecondClip by remember { mutableStateOf<FileNode?>(null) }
    var customAiPrompt by remember { mutableStateOf("") }
    var isExporting by remember { mutableStateOf(false) }

    LaunchedEffect(node.path) {
        aiViewModel.resetVideoAiState()
        withContext(Dispatchers.IO) {
            val f = if (node.path.startsWith("file://")) {
                File(node.path.removePrefix("file://"))
            } else {
                File(context.cacheDir, "vid_edit_${node.name}").apply {
                    writeBytes(storageAdapter.read(node.path))
                }
            }
            localSourceFile = f
            val retriever = MediaMetadataRetriever()
            runCatching {
                retriever.setDataSource(f.absolutePath)
                durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 5_000L
            }
            runCatching { retriever.release() }
        }
    }

    val exoPlayer = remember(localSourceFile) {
        ExoPlayer.Builder(context).build().apply {
            localSourceFile?.let { f ->
                setMediaItem(MediaItem.fromUri(Uri.fromFile(f)))
                prepare()
            }
        }
    }

    LaunchedEffect(playbackSpeed, muteAudio) {
        exoPlayer.setPlaybackSpeed(playbackSpeed)
        exoPlayer.volume = if (muteAudio) 0f else 1f
    }

    DisposableEffect(exoPlayer) {
        onDispose { exoPlayer.release() }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("AI Video Studio", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("vid_editor_back")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Video Player Preview
            item {
                Card(
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(230.dp)
                ) {
                    if (localSourceFile == null) {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator()
                        }
                    } else {
                        AndroidView(
                            factory = { ctx -> PlayerView(ctx).apply { player = exoPlayer } },
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }
            }

            // Gemini Video AI Insights (Auto-Captions, Summary, Scene Highlights & Edit Prompt)
            item {
                Card(
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.width(8.dp))
                            Text("Gemini Video Intelligence", style = MaterialTheme.typography.titleMedium)
                        }

                        OutlinedTextField(
                            value = customAiPrompt,
                            onValueChange = { customAiPrompt = it },
                            placeholder = { Text("Optional goal (e.g. punchy social reel captions)") },
                            singleLine = true,
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.fillMaxWidth()
                        )

                        FilledTonalButton(
                            onClick = {
                                localSourceFile?.let { f ->
                                    aiViewModel.analyzeVideoWithGemini(f, customAiPrompt)
                                }
                            },
                            enabled = localSourceFile != null && aiState !is AiTaskState.Loading,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("ai_analyze_video_button")
                        ) {
                            Icon(Icons.Filled.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("Auto-Generate Captions, Summary & Highlights")
                        }

                        when (aiState) {
                            is AiTaskState.Loading -> {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                                    Spacer(Modifier.width(10.dp))
                                    Text(aiState.label, style = MaterialTheme.typography.bodySmall)
                                }
                            }
                            is AiTaskState.Error -> {
                                Text(aiState.message, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                            }
                            is AiTaskState.Success -> {
                                val insights = aiState.data
                                HorizontalDivider()
                                Text("Summary", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                                Text(insights.summary, style = MaterialTheme.typography.bodySmall)

                                if (insights.captions.isNotEmpty()) {
                                    Text("Auto-Captions (tap to apply as text overlay)", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                                    insights.captions.forEach { cap ->
                                        Surface(
                                            color = MaterialTheme.colorScheme.secondaryContainer,
                                            shape = RoundedCornerShape(10.dp),
                                            onClick = { overlayText = cap },
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Text(cap, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(8.dp))
                                        }
                                    }
                                }

                                if (insights.sceneHighlights.isNotEmpty()) {
                                    Text("Scene Highlights", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                                    insights.sceneHighlights.forEach { hl ->
                                        Text("• $hl", style = MaterialTheme.typography.bodySmall)
                                    }
                                }

                                if (insights.editSuggestions.isNotEmpty()) {
                                    Text("AI Edit Suggestions", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                                    insights.editSuggestions.forEach { sug ->
                                        Text("• $sug", style = MaterialTheme.typography.bodySmall)
                                    }
                                }
                            }
                            AiTaskState.Idle -> {}
                        }
                    }
                }
            }

            // Timeline Trim, Speed, Mute, Text Overlay & Clip Merge Controls
            item {
                Card(
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        val startSec = (trimRange.start * durationMs / 1000f)
                        val endSec = (trimRange.endInclusive * durationMs / 1000f)
                        Text(
                            "Trim / Cut: ${String.format("%.1fs", startSec)} – ${String.format("%.1fs", endSec)}",
                            style = MaterialTheme.typography.titleSmall
                        )
                        RangeSlider(
                            value = trimRange,
                            onValueChange = { range ->
                                if (range.endInclusive - range.start >= 0.08f) {
                                    trimRange = range
                                }
                            }
                        )

                        Text("Playback Speed", style = MaterialTheme.typography.titleSmall)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(0.5f, 1.0f, 1.5f, 2.0f).forEach { spd ->
                                FilterChip(
                                    selected = playbackSpeed == spd,
                                    onClick = { playbackSpeed = spd },
                                    label = { Text("${spd}x") }
                                )
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    if (muteAudio) Icons.AutoMirrored.Filled.VolumeOff else Icons.AutoMirrored.Filled.VolumeUp,
                                    contentDescription = null
                                )
                                Spacer(Modifier.width(8.dp))
                                Text("Mute Audio Track", style = MaterialTheme.typography.bodyMedium)
                            }
                            Switch(checked = muteAudio, onCheckedChange = { muteAudio = it })
                        }

                        OutlinedTextField(
                            value = overlayText,
                            onValueChange = { overlayText = it },
                            label = { Text("Burn-in Text / Caption Overlay") },
                            singleLine = true,
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.fillMaxWidth()
                        )

                        val otherClips = siblingVideos.filter { it.kind == FileKind.VIDEO && it.path != node.path }
                        if (otherClips.isNotEmpty()) {
                            Text("Merge Second Video Clip", style = MaterialTheme.typography.titleSmall)
                            otherClips.take(3).forEach { clip ->
                                val chosen = mergeSecondClip?.path == clip.path
                                FilterChip(
                                    selected = chosen,
                                    onClick = { mergeSecondClip = if (chosen) null else clip },
                                    label = { Text(if (chosen) "Merging: ${clip.name}" else "Append: ${clip.name}") },
                                    leadingIcon = { Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(16.dp)) }
                                )
                            }
                        }
                    }
                }
            }

            // Export MP4 via Jetpack Media3 Transformer
            item {
                Button(
                    onClick = {
                        val src = localSourceFile ?: return@Button
                        isExporting = true
                        exoPlayer.pause()
                        scope.launch {
                            val startMs = (trimRange.start * durationMs).toLong().coerceAtLeast(0L)
                            val endMs = (trimRange.endInclusive * durationMs).toLong().coerceAtLeast(startMs + 200L)
                            val secondFile = mergeSecondClip?.let { secondNode ->
                                if (secondNode.path.startsWith("file://")) {
                                    File(secondNode.path.removePrefix("file://"))
                                } else {
                                    File(context.cacheDir, "merge_${secondNode.name}").apply {
                                        writeBytes(storageAdapter.read(secondNode.path))
                                    }
                                }
                            }

                            val exported = exportWithMedia3Transformer(
                                context = context,
                                primaryFile = src,
                                secondMergeFile = secondFile,
                                startMs = startMs,
                                endMs = endMs,
                                speed = playbackSpeed,
                                muteAudio = muteAudio,
                                overlayCaption = overlayText
                            )
                            isExporting = false
                            if (exported != null && exported.exists()) {
                                val parent = node.parentPath ?: storageAdapter.workspaceRootPath
                                val outName = "${node.name.substringBeforeLast('.')}_edited.mp4"
                                val bytes = withContext(Dispatchers.IO) { exported.readBytes() }
                                exported.delete()
                                runCatching {
                                    storageAdapter.write(parent, outName, bytes, "video/mp4", overwrite = false)
                                }.onSuccess { saved ->
                                    onExportSaved("Exported ${saved.name}")
                                }.onFailure { e ->
                                    onExportSaved("Save failed: ${e.localizedMessage}")
                                }
                            } else {
                                onExportSaved("Video export failed on this media codec.")
                            }
                        }
                    },
                    enabled = localSourceFile != null && !isExporting,
                    shape = RoundedCornerShape(22.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .padding(bottom = 8.dp)
                        .testTag("export_video_button")
                ) {
                    if (isExporting) {
                        CircularProgressIndicator(
                            color = MaterialTheme.colorScheme.onPrimary,
                            modifier = Modifier.size(20.dp),
                            strokeWidth = 2.dp
                        )
                        Spacer(Modifier.width(10.dp))
                        Text("Exporting MP4 via Media3...")
                    } else {
                        Icon(Icons.Filled.MovieCreation, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Export Edited MP4")
                    }
                }
            }
        }
    }
}

@OptIn(UnstableApi::class)
private suspend fun exportWithMedia3Transformer(
    context: Context,
    primaryFile: File,
    secondMergeFile: File?,
    startMs: Long,
    endMs: Long,
    speed: Float,
    muteAudio: Boolean,
    overlayCaption: String
): File? {
    val outputFile = File(context.cacheDir, "transformed_${System.currentTimeMillis()}.mp4")
    if (outputFile.exists()) outputFile.delete()

    val clippedItem = MediaItem.Builder()
        .setUri(Uri.fromFile(primaryFile))
        .setClippingConfiguration(
            MediaItem.ClippingConfiguration.Builder()
                .setStartPositionMs(startMs)
                .setEndPositionMs(endMs)
                .build()
        )
        .build()

    val audioProcessors = buildList {
        if (speed != 1.0f) {
            val sonic = SonicAudioProcessor().apply {
                setSpeed(speed)
                setPitch(1.0f)
            }
            add(sonic)
        }
    }

    val videoEffects = buildList<Effect> {
        if (speed != 1.0f) {
            add(SpeedChangeEffect(speed))
        }
        if (overlayCaption.isNotBlank()) {
            val settings = OverlaySettings.Builder()
                .setBackgroundFrameAnchor(0f, -0.75f)
                .build()
            val textOverlay = TextOverlay.createStaticTextOverlay(
                SpannableString(overlayCaption),
                settings
            )
            add(OverlayEffect(listOf(textOverlay)))
        }
    }

    val effects = Effects(audioProcessors, videoEffects)
    val editedPrimary = EditedMediaItem.Builder(clippedItem)
        .setRemoveAudio(muteAudio)
        .setEffects(effects)
        .build()

    val sequenceItems = mutableListOf(editedPrimary)
    if (secondMergeFile != null && secondMergeFile.exists()) {
        val secondItem = MediaItem.fromUri(Uri.fromFile(secondMergeFile))
        sequenceItems.add(
            EditedMediaItem.Builder(secondItem)
                .setRemoveAudio(muteAudio)
                .build()
        )
    }

    val composition = Composition.Builder(
        listOf(EditedMediaItemSequence(sequenceItems))
    ).build()

    return suspendCancellableCoroutine { cont ->
        val transformer = Transformer.Builder(context)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    if (cont.isActive) cont.resume(outputFile)
                }

                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    if (cont.isActive) cont.resume(null)
                }
            })
            .build()

        transformer.start(composition, outputFile.absolutePath)
    }
}
