package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Reply
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.model.ArkChallenge
import com.example.data.model.ArkGameType
import com.example.data.model.ArkGroup
import com.example.data.model.GroupMedia
import com.example.data.model.GroupMessage
import com.example.data.model.UserProfile
import com.example.ui.components.EmptyStateGlassCard
import com.example.ui.components.GlowingPillButton
import com.example.ui.components.LiquidGlassCard
import com.example.ui.components.UserBadgeChip
import com.example.ui.theme.ArkThemeTokens
import com.example.util.ImageCompressionHelper
import com.example.util.rememberDecodedImageBitmap
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun GroupDetailScreen(
    group: ArkGroup,
    currentUser: UserProfile,
    messages: List<GroupMessage>,
    mediaItems: List<GroupMedia>,
    groupChallenges: List<ArkChallenge>,
    onBack: () -> Unit,
    onSendMessage: (text: String, imageBase64: String?, replyToId: String?, replyPreview: String?) -> Unit,
    onReactMessage: (GroupMessage, String) -> Unit,
    onDeleteMessage: (String) -> Unit,
    onUploadMedia: (albumName: String, caption: String, imageBase64: String) -> Unit,
    onUpdateSettings: (name: String, desc: String, theme: String, allowDl: Boolean) -> Unit,
    onPromoteAdmin: (String) -> Unit,
    onRemoveMember: (String) -> Unit,
    onLeaveGroup: () -> Unit,
    onDeleteGroup: () -> Unit,
    onReportContent: (type: String, id: String, reason: String) -> Unit,
    onLaunchGroupGame: (ArkGameType) -> Unit
) {
    BackHandler(onBack = onBack)

    val colors = ArkThemeTokens.colors
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val isGroupAdmin = group.adminUids.contains(currentUser.userId)
    val isOwner = group.ownerId == currentUser.userId

    var subTab by remember { mutableIntStateOf(0) }
    var messageInput by remember { mutableStateOf("") }
    var pendingImageBase64 by remember { mutableStateOf<String?>(null) }
    var replyingTo by remember { mutableStateOf<GroupMessage?>(null) }
    var showSettingsDialog by remember { mutableStateOf(false) }
    var selectedAlbum by remember { mutableStateOf("All") }
    var mediaUploadCaption by remember { mutableStateOf("") }
    var mediaUploadAlbum by remember { mutableStateOf("Memories") }
    var pendingMediaBase64 by remember { mutableStateOf<String?>(null) }

    val chatPhotoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                pendingImageBase64 = ImageCompressionHelper.compressUriToBase64(context, uri, maxDim = 240)
            }
        }
    }

    val albumPhotoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                pendingMediaBase64 = ImageCompressionHelper.compressUriToBase64(context, uri, maxDim = 320)
            }
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // Header
        Surface(color = colors.glassSurfaceElevated) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = colors.textPrimary)
                    }
                    Column {
                        Text(group.name, style = MaterialTheme.typography.titleLarge, color = colors.textPrimary)
                        Text(
                            "${group.memberCount} members • Invite: ${group.inviteCode}",
                            style = MaterialTheme.typography.labelSmall,
                            color = colors.cyan
                        )
                    }
                }
                IconButton(onClick = { showSettingsDialog = true }) {
                    Icon(Icons.Default.Settings, contentDescription = "Group settings & members", tint = colors.textPrimary)
                }
            }
        }

        TabRow(selectedTabIndex = subTab, containerColor = colors.glassSurface) {
            Tab(selected = subTab == 0, onClick = { subTab = 0 }, text = { Text("Chat") })
            Tab(selected = subTab == 1, onClick = { subTab = 1 }, text = { Text("Media (${mediaItems.size})") })
            Tab(selected = subTab == 2, onClick = { subTab = 2 }, text = { Text("Activities") })
        }

        when (subTab) {
            // A. GROUP CHAT
            0 -> {
                Column(modifier = Modifier.fillMaxSize()) {
                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        if (messages.isEmpty()) {
                            item {
                                EmptyStateGlassCard(
                                    icon = Icons.AutoMirrored.Filled.Send,
                                    title = "Start the Conversation",
                                    subtitle = "Send a message, react with emojis, or share a squad photo!"
                                )
                            }
                        } else {
                            items(messages, key = { it.id }) { msg ->
                                MessageBubble(
                                    msg = msg,
                                    isMine = msg.senderId == currentUser.userId,
                                    onReply = { replyingTo = msg },
                                    onReact = { emoji -> onReactMessage(msg, emoji) },
                                    onDelete = { onDeleteMessage(msg.id) },
                                    onReport = { onReportContent("message", msg.id, "Inappropriate chat message") }
                                )
                            }
                        }
                    }

                    // Reply / Image preview bar
                    if (replyingTo != null || pendingImageBase64 != null) {
                        Surface(color = colors.glassSurfaceElevated, modifier = Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = when {
                                        replyingTo != null -> "Replying to @${replyingTo!!.senderUsername}: ${replyingTo!!.text.take(40)}"
                                        else -> "Photo attached (ready to send)"
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = colors.cyan,
                                    modifier = Modifier.weight(1f)
                                )
                                IconButton(onClick = {
                                    replyingTo = null
                                    pendingImageBase64 = null
                                }) {
                                    Icon(Icons.Default.Close, contentDescription = "Clear attachment", tint = colors.textSecondary)
                                }
                            }
                        }
                    }

                    // Composer
                    Surface(color = colors.glassSurfaceElevated) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(
                                onClick = {
                                    chatPhotoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                                }
                            ) {
                                Icon(Icons.Default.AddPhotoAlternate, contentDescription = "Attach photo", tint = colors.cyan)
                            }
                            OutlinedTextField(
                                value = messageInput,
                                onValueChange = { messageInput = it.take(1000) },
                                placeholder = { Text("Message ${group.name}...") },
                                maxLines = 3,
                                modifier = Modifier.weight(1f).testTag("group_chat_input")
                            )
                            Spacer(Modifier.width(6.dp))
                            IconButton(
                                onClick = {
                                    if (messageInput.isNotBlank() || pendingImageBase64 != null) {
                                        onSendMessage(
                                            messageInput,
                                            pendingImageBase64,
                                            replyingTo?.id,
                                            replyingTo?.text?.take(80)
                                        )
                                        messageInput = ""
                                        pendingImageBase64 = null
                                        replyingTo = null
                                    }
                                },
                                modifier = Modifier.testTag("group_chat_send")
                            ) {
                                Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send", tint = colors.cyan)
                            }
                        }
                    }
                }
            }

            // B. GROUP MEDIA GALLERY & ALBUMS
            1 -> {
                val albums = listOf("All", "Memories", "Game Nights", "Challenges", "General")
                val filteredMedia = if (selectedAlbum == "All") mediaItems else mediaItems.filter { it.albumName == selectedAlbum }

                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        LiquidGlassCard(modifier = Modifier.fillMaxWidth()) {
                            Text("Share to Group Album", style = MaterialTheme.typography.titleSmall, color = colors.textPrimary)
                            Text(
                                if (group.allowMediaDownloads) "Media downloads enabled by group admins" else "Protected album: downloads restricted",
                                style = MaterialTheme.typography.bodySmall,
                                color = colors.textSecondary
                            )
                            Spacer(Modifier.height(8.dp))
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                items(albums.drop(1)) { alb ->
                                    FilterChip(
                                        selected = mediaUploadAlbum == alb,
                                        onClick = { mediaUploadAlbum = alb },
                                        label = { Text(alb) }
                                    )
                                }
                            }
                            Spacer(Modifier.height(8.dp))
                            OutlinedTextField(
                                value = mediaUploadCaption,
                                onValueChange = { mediaUploadCaption = it.take(160) },
                                label = { Text("Caption") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(Modifier.height(10.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                OutlinedButton(
                                    onClick = {
                                        albumPhotoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                                    }
                                ) {
                                    Icon(Icons.Default.PhotoLibrary, contentDescription = null)
                                    Spacer(Modifier.width(6.dp))
                                    Text(if (pendingMediaBase64 != null) "Photo Ready" else "Pick Photo")
                                }
                                if (pendingMediaBase64 != null) {
                                    GlowingPillButton(
                                        text = "Post to Album",
                                        onClick = {
                                            onUploadMedia(mediaUploadAlbum, mediaUploadCaption, pendingMediaBase64!!)
                                            pendingMediaBase64 = null
                                            mediaUploadCaption = ""
                                        }
                                    )
                                }
                            }
                        }
                    }

                    item {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(albums) { alb ->
                                FilterChip(
                                    selected = selectedAlbum == alb,
                                    onClick = { selectedAlbum = alb },
                                    label = { Text(alb) }
                                )
                            }
                        }
                    }

                    if (filteredMedia.isEmpty()) {
                        item {
                            EmptyStateGlassCard(
                                icon = Icons.Default.PhotoLibrary,
                                title = "No Photos in $selectedAlbum",
                                subtitle = "Pick a photo above using the zero-permission Android Photo Picker to share memories."
                            )
                        }
                    } else {
                        items(filteredMedia, key = { it.id }) { item ->
                            val bmp = rememberDecodedImageBitmap(item.imageBase64)
                            LiquidGlassCard(modifier = Modifier.fillMaxWidth()) {
                                if (bmp != null) {
                                    Image(
                                        bitmap = bmp,
                                        contentDescription = item.caption.ifBlank { "Group photo" },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(180.dp)
                                            .clip(RoundedCornerShape(16.dp)),
                                        contentScale = ContentScale.Crop
                                    )
                                    Spacer(Modifier.height(8.dp))
                                }
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(item.caption.ifBlank { "Shared memory" }, style = MaterialTheme.typography.titleSmall, color = colors.textPrimary)
                                        Text("@${item.uploaderUsername} • ${item.albumName}", style = MaterialTheme.typography.bodySmall, color = colors.cyan)
                                    }
                                    IconButton(onClick = { onReportContent("media", item.id, "Reported group photo") }) {
                                        Icon(Icons.Default.Flag, contentDescription = "Report photo", tint = colors.gold)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // C. GROUP ACTIVITIES (Games, Challenges, Leaderboard)
            2 -> {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        LiquidGlassCard(modifier = Modifier.fillMaxWidth(), accentColor = colors.violet) {
                            Text("Launch Squad Game", style = MaterialTheme.typography.titleMedium, color = colors.textPrimary)
                            Spacer(Modifier.height(4.dp))
                            Text(
                                "Create a real-time multiplayer room linked to ${group.name} and share the room code in chat.",
                                style = MaterialTheme.typography.bodySmall,
                                color = colors.textSecondary
                            )
                            Spacer(Modifier.height(10.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                GlowingPillButton(
                                    text = "Quiz Battle",
                                    icon = Icons.Default.SportsEsports,
                                    onClick = { onLaunchGroupGame(ArkGameType.QUIZ_BATTLE) },
                                    modifier = Modifier.weight(1f)
                                )
                                GlowingPillButton(
                                    text = "Mafia",
                                    icon = Icons.Default.SportsEsports,
                                    accent = colors.violet,
                                    onClick = { onLaunchGroupGame(ArkGameType.MAFIA) },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }

                    item {
                        Text("Group Real-Life Challenges", style = MaterialTheme.typography.titleMedium, color = colors.textPrimary)
                    }
                    items(groupChallenges, key = { it.id }) { ch ->
                        LiquidGlassCard(modifier = Modifier.fillMaxWidth(), accentColor = colors.emerald) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(ch.title, style = MaterialTheme.typography.titleSmall, color = colors.textPrimary)
                                    Text(ch.description, style = MaterialTheme.typography.bodySmall, color = colors.textSecondary)
                                }
                                UserBadgeChip(label = "+${ch.rewardPoints} PTS", accent = colors.gold)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showSettingsDialog) {
        GroupSettingsDialog(
            group = group,
            currentUserId = currentUser.userId,
            isAdmin = isGroupAdmin,
            isOwner = isOwner,
            onDismiss = { showSettingsDialog = false },
            onSave = { name, desc, theme, allowDl ->
                onUpdateSettings(name, desc, theme, allowDl)
                showSettingsDialog = false
            },
            onPromoteAdmin = onPromoteAdmin,
            onRemoveMember = onRemoveMember,
            onLeave = {
                showSettingsDialog = false
                onLeaveGroup()
            },
            onDelete = {
                showSettingsDialog = false
                onDeleteGroup()
            }
        )
    }
}

@Composable
private fun MessageBubble(
    msg: GroupMessage,
    isMine: Boolean,
    onReply: () -> Unit,
    onReact: (String) -> Unit,
    onDelete: () -> Unit,
    onReport: () -> Unit
) {
    val colors = ArkThemeTokens.colors
    val bmp = rememberDecodedImageBitmap(msg.imageBase64)
    val timeText = remember(msg.createdAt) {
        val ms = (msg.createdAt?.seconds ?: (System.currentTimeMillis() / 1000L)) * 1000L
        SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date(ms))
    }

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (isMine) Alignment.End else Alignment.Start
    ) {
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = if (isMine) colors.cyan.copy(alpha = 0.16f) else colors.glassSurface,
            border = BorderStroke(1.dp, if (isMine) colors.cyan.copy(alpha = 0.5f) else colors.glassBorder),
            modifier = Modifier.fillMaxWidth(0.86f)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("@${msg.senderUsername}", style = MaterialTheme.typography.labelMedium, color = colors.cyan)
                    Text(timeText, style = MaterialTheme.typography.labelSmall, color = colors.textSecondary)
                }

                if (!msg.replyToPreview.isNullOrBlank()) {
                    Spacer(Modifier.height(4.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(colors.violet.copy(alpha = 0.14f))
                            .padding(6.dp)
                    ) {
                        Text("↩ ${msg.replyToPreview}", style = MaterialTheme.typography.bodySmall, color = colors.textSecondary)
                    }
                }

                if (bmp != null && !msg.isDeleted) {
                    Spacer(Modifier.height(6.dp))
                    Image(
                        bitmap = bmp,
                        contentDescription = "Shared chat photo",
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(150.dp)
                            .clip(RoundedCornerShape(12.dp)),
                        contentScale = ContentScale.Crop
                    )
                }

                if (msg.text.isNotBlank()) {
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = msg.text,
                        style = MaterialTheme.typography.bodyMedium,
                        color = if (msg.isDeleted) colors.textSecondary else colors.textPrimary
                    )
                }

                if (!msg.isDeleted) {
                    Spacer(Modifier.height(6.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("🔥", "😂", "❤️").forEach { emoji ->
                                val count = msg.reactions[emoji] ?: 0L
                                Surface(
                                    shape = RoundedCornerShape(50),
                                    color = colors.glassSurfaceElevated,
                                    modifier = Modifier.clickable { onReact(emoji) }
                                ) {
                                    Text(
                                        text = if (count > 0) "$emoji $count" else emoji,
                                        style = MaterialTheme.typography.labelSmall,
                                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                                    )
                                }
                            }
                        }
                        Row {
                            IconButton(onClick = onReply, modifier = Modifier.size(28.dp)) {
                                Icon(Icons.AutoMirrored.Filled.Reply, contentDescription = "Reply", tint = colors.textSecondary, modifier = Modifier.size(16.dp))
                            }
                            if (isMine) {
                                IconButton(onClick = onDelete, modifier = Modifier.size(28.dp)) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = colors.coral, modifier = Modifier.size(16.dp))
                                }
                            } else {
                                IconButton(onClick = onReport, modifier = Modifier.size(28.dp)) {
                                    Icon(Icons.Default.Flag, contentDescription = "Report", tint = colors.gold, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun GroupSettingsDialog(
    group: ArkGroup,
    currentUserId: String,
    isAdmin: Boolean,
    isOwner: Boolean,
    onDismiss: () -> Unit,
    onSave: (String, String, String, Boolean) -> Unit,
    onPromoteAdmin: (String) -> Unit,
    onRemoveMember: (String) -> Unit,
    onLeave: () -> Unit,
    onDelete: () -> Unit
) {
    var name by remember { mutableStateOf(group.name) }
    var desc by remember { mutableStateOf(group.description) }
    var theme by remember { mutableStateOf(group.theme) }
    var allowDl by remember { mutableStateOf(group.allowMediaDownloads) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Manage ${group.name}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Invite Code: ${group.inviteCode}", style = MaterialTheme.typography.labelLarge)
                if (isAdmin) {
                    OutlinedTextField(value = name, onValueChange = { name = it.take(40) }, label = { Text("Name") }, singleLine = true)
                    OutlinedTextField(value = desc, onValueChange = { desc = it.take(200) }, label = { Text("Description") }, maxLines = 2)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Allow Photo Downloads")
                        Switch(checked = allowDl, onCheckedChange = { allowDl = it })
                    }
                }
                Text("Members (${group.memberUids.size})", style = MaterialTheme.typography.titleSmall)
                group.memberUids.take(6).forEach { memberUid ->
                    val memberIsAdmin = group.adminUids.contains(memberUid)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            if (memberUid == currentUserId) "You" else "User ${memberUid.take(6)}",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Row {
                            if (isAdmin && !memberIsAdmin) {
                                IconButton(onClick = { onPromoteAdmin(memberUid) }, modifier = Modifier.size(30.dp)) {
                                    Icon(Icons.Default.AdminPanelSettings, contentDescription = "Promote admin", modifier = Modifier.size(16.dp))
                                }
                            }
                            if (isAdmin && memberUid != group.ownerId && memberUid != currentUserId) {
                                IconButton(onClick = { onRemoveMember(memberUid) }, modifier = Modifier.size(30.dp)) {
                                    Icon(Icons.Default.Delete, contentDescription = "Remove member", modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
                if (!isOwner) {
                    OutlinedButton(onClick = onLeave, modifier = Modifier.fillMaxWidth()) {
                        Text("Leave Group")
                    }
                } else {
                    OutlinedButton(onClick = onDelete, modifier = Modifier.fillMaxWidth()) {
                        Text("Delete Group (Owner)")
                    }
                }
            }
        },
        confirmButton = {
            if (isAdmin) {
                TextButton(onClick = { onSave(name, desc, theme, allowDl) }) { Text("Save") }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Close") }
        }
    )
}
