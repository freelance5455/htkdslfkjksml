package com.example.ui.components

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.SpaceDashboard
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BrandPrimary
import com.example.ui.theme.BrandSecondary
import com.example.ui.viewmodel.AppScreen

@Composable
fun AppBottomNavBar(
    currentScreen: AppScreen,
    isArabic: Boolean,
    onScreenSelected: (AppScreen) -> Unit
) {
    NavigationBar(
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 8.dp,
        modifier = Modifier.testTag("app_bottom_nav_bar")
    ) {
        val items = listOf(
            Triple(
                AppScreen.DASHBOARD,
                if (isArabic) "الرئيسية" else "Dashboard",
                Icons.Default.SpaceDashboard
            ),
            Triple(
                AppScreen.PROJECTS,
                if (isArabic) "مشاريعي" else "Projects",
                Icons.Default.Folder
            ),
            Triple(
                AppScreen.NEW_PROJECT,
                if (isArabic) "مشروع جديد" else "New",
                Icons.Default.AddCircle
            ),
            Triple(
                AppScreen.KEYSTORES,
                if (isArabic) "التوقيع" else "Keys",
                Icons.Default.Key
            ),
            Triple(
                AppScreen.TOOLS,
                if (isArabic) "الأدوات والذكاء" else "Tools & AI",
                Icons.Default.AutoAwesome
            )
        )

        items.forEach { (screen, label, icon) ->
            val selected = currentScreen == screen
            NavigationBarItem(
                selected = selected,
                onClick = { onScreenSelected(screen) },
                icon = {
                    Icon(
                        imageVector = icon,
                        contentDescription = label
                    )
                },
                label = {
                    Text(
                        text = label,
                        fontSize = 11.sp,
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = Color.White,
                    selectedTextColor = BrandPrimary,
                    indicatorColor = BrandPrimary,
                    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                ),
                modifier = Modifier.testTag("nav_item_${screen.name.lowercase()}")
            )
        }
    }
}
