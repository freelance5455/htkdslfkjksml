package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.EqualizerPreset
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonPink
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceElevated

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EqualizerScreen(
    currentPreset: EqualizerPreset,
    allPresets: List<EqualizerPreset>,
    onPresetSelected: (EqualizerPreset) -> Unit,
    on10BandsChanged: (
        b31: Float, b62: Float, b125: Float, b250: Float, b500: Float,
        b1k: Float, b2k: Float, b4k: Float, b8k: Float, b16k: Float,
        preamp: Float, bassTone: Float, trebleTone: Float,
        stereoWidener: Float, balance: Float
    ) -> Unit,
    onToggleLimiter: () -> Unit,
    onToggleDvc: () -> Unit,
    onSaveCustomPreset: (String) -> Unit,
    onDeleteCustomPreset: (String) -> Unit,
    onBack: () -> Unit
) {
    // 10 Bands local state
    var b31 by remember(currentPreset) { mutableFloatStateOf(currentPreset.band31Hz) }
    var b62 by remember(currentPreset) { mutableFloatStateOf(currentPreset.band62Hz) }
    var b125 by remember(currentPreset) { mutableFloatStateOf(currentPreset.band125Hz) }
    var b250 by remember(currentPreset) { mutableFloatStateOf(currentPreset.band250Hz) }
    var b500 by remember(currentPreset) { mutableFloatStateOf(currentPreset.band500Hz) }
    var b1k by remember(currentPreset) { mutableFloatStateOf(currentPreset.band1kHz) }
    var b2k by remember(currentPreset) { mutableFloatStateOf(currentPreset.band2kHz) }
    var b4k by remember(currentPreset) { mutableFloatStateOf(currentPreset.band4kHz) }
    var b8k by remember(currentPreset) { mutableFloatStateOf(currentPreset.band8kHz) }
    var b16k by remember(currentPreset) { mutableFloatStateOf(currentPreset.band16kHz) }

    // Preamp & Tone Knobs
    var preamp by remember(currentPreset) { mutableFloatStateOf(currentPreset.preampDb) }
    var bassTone by remember(currentPreset) { mutableFloatStateOf(currentPreset.bassTone) }
    var trebleTone by remember(currentPreset) { mutableFloatStateOf(currentPreset.trebleTone) }
    var stereoWidener by remember(currentPreset) { mutableFloatStateOf(currentPreset.stereoWidener) }
    var balance by remember(currentPreset) { mutableFloatStateOf(currentPreset.balance) }

    var showSaveDialog by remember { mutableStateOf(false) }
    var customPresetNameInput by remember { mutableStateOf("") }
    var showVerticalFaders by remember { mutableStateOf(true) }

    val scrollState = rememberScrollState()

    fun emitChanges() {
        on10BandsChanged(
            b31, b62, b125, b250, b500,
            b1k, b2k, b4k, b8k, b16k,
            preamp, bassTone, trebleTone, stereoWidener, balance
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBg)
            .padding(horizontal = 16.dp)
            .verticalScroll(scrollState)
            .testTag("equalizer_screen")
    ) {
        Spacer(modifier = Modifier.height(16.dp))

        // Top App Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier.testTag("eq_back_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Back",
                        tint = NeonCyan
                    )
                }
                Spacer(modifier = Modifier.width(6.dp))
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "Poweramp DSP Equalizer",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White
                        )
                    }
                    Text(
                        text = "10-Band Graphic EQ • DVC Active",
                        style = MaterialTheme.typography.bodySmall,
                        color = NeonCyan,
                        fontSize = 11.sp
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                // Reset Button
                IconButton(
                    onClick = {
                        b31 = 0f; b62 = 0f; b125 = 0f; b250 = 0f; b500 = 0f
                        b1k = 0f; b2k = 0f; b4k = 0f; b8k = 0f; b16k = 0f
                        preamp = 0f; bassTone = 0f; trebleTone = 0f
                        stereoWidener = 0f; balance = 0f
                        emitChanges()
                    },
                    modifier = Modifier.testTag("eq_reset_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Reset EQ",
                        tint = Color.LightGray
                    )
                }

                // Save Preset
                IconButton(
                    onClick = { showSaveDialog = true },
                    modifier = Modifier.testTag("eq_save_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Bookmark,
                        contentDescription = "Save Preset",
                        tint = NeonCyan
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Poweramp 10-Band Frequency Curve Canvas Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .height(165.dp),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = SurfaceDark)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(14.dp)
            ) {
                PowerampCurveCanvas(
                    bands = floatArrayOf(b31, b62, b125, b250, b500, b1k, b2k, b4k, b8k, b16k),
                    preamp = preamp
                )

                // Current Preset Chip badge
                Row(
                    modifier = Modifier.align(Alignment.TopEnd),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(ObsidianBg.copy(alpha = 0.8f))
                            .border(1.dp, NeonCyan.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = currentPreset.name,
                            color = NeonCyan,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Poweramp Analog Rotary Tone Knobs (BASS & TREBLE)
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = SurfaceDark)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "ANALOG TONE CONTROLS",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.LightGray,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "Touch & Drag to Rotate",
                        fontSize = 10.sp,
                        color = NeonCyan
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Poweramp Bass Rotary Knob
                    PowerampRotaryKnob(
                        value = bassTone,
                        onValueChange = {
                            bassTone = it
                            emitChanges()
                        },
                        range = -10f..10f,
                        defaultValue = 0f,
                        label = "Bass",
                        size = 96.dp,
                        activeColor = NeonCyan
                    )

                    // Poweramp Treble Rotary Knob
                    PowerampRotaryKnob(
                        value = trebleTone,
                        onValueChange = {
                            trebleTone = it
                            emitChanges()
                        },
                        range = -10f..10f,
                        defaultValue = 0f,
                        label = "Treble",
                        size = 96.dp,
                        activeColor = NeonPink
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // Presets Carousel
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "PRESETS",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color.LightGray,
                letterSpacing = 1.sp
            )
            Text(
                text = "${allPresets.size} Profiles",
                fontSize = 11.sp,
                color = Color.Gray
            )
        }
        Spacer(modifier = Modifier.height(8.dp))

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(vertical = 4.dp)
        ) {
            items(allPresets) { preset ->
                val isSelected = currentPreset.id == preset.id
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (isSelected) NeonCyan else SurfaceElevated)
                        .clickable { onPresetSelected(preset) }
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                        .testTag("preset_${preset.id}")
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = preset.name,
                            color = if (isSelected) ObsidianBg else Color.White,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 12.sp
                        )
                        if (preset.isCustom) {
                            Spacer(modifier = Modifier.width(6.dp))
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = "Delete",
                                tint = if (isSelected) ObsidianBg else Color.Gray,
                                modifier = Modifier
                                    .size(14.dp)
                                    .clickable { onDeleteCustomPreset(preset.id) }
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Equalizer Strip Mode Switcher
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Bolt,
                    contentDescription = null,
                    tint = NeonPurple,
                    modifier = Modifier.size(15.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "DVC PREAMP & 10-BAND STRIP",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.LightGray,
                    letterSpacing = 1.sp
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (showVerticalFaders) NeonPurple else SurfaceElevated)
                        .clickable { showVerticalFaders = true }
                        .padding(horizontal = 9.dp, vertical = 5.dp)
                        .testTag("fader_deck_mode_btn")
                ) {
                    Text(
                        text = "Fader Strip",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (showVerticalFaders) ObsidianBg else Color.White
                    )
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (!showVerticalFaders) NeonPurple else SurfaceElevated)
                        .clickable { showVerticalFaders = false }
                        .padding(horizontal = 9.dp, vertical = 5.dp)
                        .testTag("slider_deck_mode_btn")
                ) {
                    Text(
                        text = "Sliders",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (!showVerticalFaders) ObsidianBg else Color.White
                    )
                }
            }
        }
        Spacer(modifier = Modifier.height(10.dp))

        if (showVerticalFaders) {
            // Poweramp Combined Deck: DVC Preamp Strip Next to the 10-Band EQ Strip
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("combined_eq_fader_deck"),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceDark)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Direct Volume Control (DVC) Preamp Gain Strip on the Left
                    DvcPreampVerticalStrip(
                        preampDb = preamp,
                        onPreampChange = {
                            preamp = it
                            emitChanges()
                        },
                        dvcEnabled = currentPreset.dvcEnabled
                    )

                    Spacer(modifier = Modifier.width(10.dp))

                    // 10-Band Frequency Strips in Horizontal Deck
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("eq_10_band_fader_row")
                    ) {
                        item { EqualizerVerticalBandFader("Sub", "31Hz", b31) { b31 = it; emitChanges() } }
                        item { EqualizerVerticalBandFader("Bass", "62Hz", b62) { b62 = it; emitChanges() } }
                        item { EqualizerVerticalBandFader("Warm", "125Hz", b125) { b125 = it; emitChanges() } }
                        item { EqualizerVerticalBandFader("Punch", "250Hz", b250) { b250 = it; emitChanges() } }
                        item { EqualizerVerticalBandFader("LowMid", "500Hz", b500) { b500 = it; emitChanges() } }
                        item { EqualizerVerticalBandFader("Mid", "1kHz", b1k) { b1k = it; emitChanges() } }
                        item { EqualizerVerticalBandFader("UpMid", "2kHz", b2k) { b2k = it; emitChanges() } }
                        item { EqualizerVerticalBandFader("Pres", "4kHz", b4k) { b4k = it; emitChanges() } }
                        item { EqualizerVerticalBandFader("Brill", "8kHz", b8k) { b8k = it; emitChanges() } }
                        item { EqualizerVerticalBandFader("Air", "16kHz", b16k) { b16k = it; emitChanges() } }
                    }
                }
            }
        } else {
            // Horizontal Sliders Fallback
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceDark)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    PowerampBandSlider(
                        label = "DVC Preamp Gain",
                        freq = "DVC PREAMP",
                        value = preamp,
                        onValueChange = {
                            preamp = it
                            emitChanges()
                        },
                        accentColor = NeonPurple
                    )

                    Divider(color = Color.White.copy(alpha = 0.08f), modifier = Modifier.padding(vertical = 10.dp))

                    PowerampBandSlider("Sub-Bass", "31 Hz", b31, { b31 = it; emitChanges() })
                    PowerampBandSlider("Deep Bass", "62 Hz", b62, { b62 = it; emitChanges() })
                    PowerampBandSlider("Warmth / Kick", "125 Hz", b125, { b125 = it; emitChanges() })
                    PowerampBandSlider("Punch / Body", "250 Hz", b250, { b250 = it; emitChanges() })
                    PowerampBandSlider("Low Midrange", "500 Hz", b500, { b500 = it; emitChanges() })
                    PowerampBandSlider("Mid / Vocals", "1 kHz", b1k, { b1k = it; emitChanges() })
                    PowerampBandSlider("Upper Mid", "2 kHz", b2k, { b2k = it; emitChanges() })
                    PowerampBandSlider("Presence", "4 kHz", b4k, { b4k = it; emitChanges() })
                    PowerampBandSlider("Brilliance", "8 kHz", b8k, { b8k = it; emitChanges() })
                    PowerampBandSlider("Air / Sparkle", "16 kHz", b16k, { b16k = it; emitChanges() })
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Direct Volume Control (DVC) Preamp Calibration & Fine-Tuning Stage
        DvcPreampGainDetailCard(
            preampDb = preamp,
            onPreampChange = {
                preamp = it
                emitChanges()
            },
            dvcEnabled = currentPreset.dvcEnabled,
            onToggleDvc = onToggleDvc
        )

        Spacer(modifier = Modifier.height(20.dp))

        // Poweramp Audio Engine & DSP Switches Card
        Text(
            text = "POWERAMP AUDIO ENGINE CONTROLS",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = Color.LightGray,
            letterSpacing = 1.sp
        )
        Spacer(modifier = Modifier.height(10.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = SurfaceDark)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                // Direct Volume Control (DVC)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Direct Volume Control (DVC)", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("Bypasses Android mixer for bit-perfect hi-res dynamic range", color = Color.Gray, fontSize = 11.sp)
                    }
                    Switch(
                        checked = currentPreset.dvcEnabled,
                        onCheckedChange = { onToggleDvc() },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = ObsidianBg,
                            checkedTrackColor = NeonCyan
                        ),
                        modifier = Modifier.testTag("toggle_dvc_switch")
                    )
                }

                Divider(color = Color.White.copy(alpha = 0.08f), modifier = Modifier.padding(vertical = 10.dp))

                // Limiter Protection
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("DSP Limiter", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("Prevents digital clipping and harmonic distortion", color = Color.Gray, fontSize = 11.sp)
                    }
                    Switch(
                        checked = currentPreset.limiterEnabled,
                        onCheckedChange = { onToggleLimiter() },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = ObsidianBg,
                            checkedTrackColor = NeonCyan
                        ),
                        modifier = Modifier.testTag("toggle_limiter_switch")
                    )
                }

                Divider(color = Color.White.copy(alpha = 0.08f), modifier = Modifier.padding(vertical = 10.dp))

                // Stereo Widener Slider
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Stereo Expander", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text("${stereoWidener.toInt()}%", color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
                Slider(
                    value = stereoWidener,
                    onValueChange = {
                        stereoWidener = it
                        emitChanges()
                    },
                    valueRange = 0f..100f,
                    colors = SliderDefaults.colors(
                        thumbColor = NeonCyan,
                        activeTrackColor = NeonCyan,
                        inactiveTrackColor = SurfaceElevated
                    ),
                    modifier = Modifier.testTag("stereo_widener_slider")
                )

                Spacer(modifier = Modifier.height(6.dp))

                // Balance Slider (L <-> R)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Stereo Balance", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    val balText = when {
                        balance < -0.5f -> "L ${Math.abs(balance.toInt())}"
                        balance > 0.5f -> "R ${balance.toInt()}"
                        else -> "Center"
                    }
                    Text(balText, color = NeonPurple, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
                Slider(
                    value = balance,
                    onValueChange = {
                        balance = it
                        emitChanges()
                    },
                    valueRange = -10f..10f,
                    colors = SliderDefaults.colors(
                        thumbColor = NeonPurple,
                        activeTrackColor = NeonPurple,
                        inactiveTrackColor = SurfaceElevated
                    ),
                    modifier = Modifier.testTag("balance_slider")
                )
            }
        }

        Spacer(modifier = Modifier.height(32.dp))
    }

    // Save Preset Dialog
    if (showSaveDialog) {
        AlertDialog(
            onDismissRequest = { showSaveDialog = false },
            title = { Text("Save Custom Preset", color = Color.White) },
            text = {
                Column {
                    Text("Enter a unique profile name for this 10-band mastering curve:", color = Color.LightGray, fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = customPresetNameInput,
                        onValueChange = { customPresetNameInput = it },
                        placeholder = { Text("e.g. Audiophile Stage 2") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NeonCyan,
                            unfocusedBorderColor = Color.Gray,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("preset_name_input")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (customPresetNameInput.isNotBlank()) {
                            onSaveCustomPreset(customPresetNameInput.trim())
                            showSaveDialog = false
                            customPresetNameInput = ""
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonCyan, contentColor = ObsidianBg),
                    modifier = Modifier.testTag("save_preset_confirm")
                ) {
                    Text("Save", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showSaveDialog = false }) {
                    Text("Cancel", color = Color.Gray)
                }
            },
            containerColor = SurfaceDark
        )
    }
}

@Composable
private fun PowerampBandSlider(
    label: String,
    freq: String,
    value: Float,
    onValueChange: (Float) -> Unit,
    accentColor: Color = NeonCyan
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(text = freq, fontWeight = FontWeight.Bold, color = accentColor, fontSize = 13.sp)
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = "($label)", color = Color.Gray, fontSize = 11.sp)
            }
            Text(
                text = "${if (value > 0) "+" else ""}${String.format("%.1f", value)} dB",
                color = if (value > 0) accentColor else if (value < 0) NeonPink else Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp
            )
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = -12f..12f,
            colors = SliderDefaults.colors(
                thumbColor = accentColor,
                activeTrackColor = accentColor,
                inactiveTrackColor = SurfaceElevated
            ),
            modifier = Modifier.testTag("slider_${freq.replace(" ", "_")}")
        )
    }
}

@Composable
private fun PowerampCurveCanvas(
    bands: FloatArray,
    preamp: Float
) {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        val midY = h / 2f

        // Draw horizontal grid lines
        drawLine(Color.White.copy(alpha = 0.15f), Offset(0f, midY), Offset(w, midY), strokeWidth = 1.5f)
        drawLine(Color.White.copy(alpha = 0.08f), Offset(0f, 12f), Offset(w, 12f), strokeWidth = 1f)
        drawLine(Color.White.copy(alpha = 0.08f), Offset(0f, h - 12f), Offset(w, h - 12f), strokeWidth = 1f)

        val count = bands.size
        val xs = FloatArray(count) { i ->
            (w * 0.06f) + (i.toFloat() / (count - 1)) * (w * 0.88f)
        }
        val ys = FloatArray(count) { i ->
            val totalDb = (bands[i] + preamp * 0.5f).coerceIn(-14f, 14f)
            midY - (totalDb / 14f) * (midY - 16f)
        }

        // Cubic spline
        val path = Path()
        path.moveTo(0f, ys[0])
        path.lineTo(xs[0], ys[0])

        for (i in 0 until count - 1) {
            val cx = (xs[i] + xs[i + 1]) / 2f
            path.cubicTo(cx, ys[i], cx, ys[i + 1], xs[i + 1], ys[i + 1])
        }
        path.lineTo(w, ys[count - 1])

        // Fill area under curve
        val fillPath = Path()
        fillPath.addPath(path)
        fillPath.lineTo(w, midY)
        fillPath.lineTo(0f, midY)
        fillPath.close()

        drawPath(
            fillPath,
            brush = Brush.verticalGradient(
                listOf(NeonCyan.copy(alpha = 0.35f), Color.Transparent),
                startY = 12f,
                endY = h
            )
        )

        // Stroke
        drawPath(
            path,
            brush = Brush.horizontalGradient(listOf(NeonCyan, NeonPurple, NeonPink)),
            style = Stroke(width = 3.5f, cap = StrokeCap.Round)
        )

        // Draw control nodes
        for (i in xs.indices) {
            drawCircle(NeonCyan, radius = 4.5f, center = Offset(xs[i], ys[i]))
            drawCircle(ObsidianBg, radius = 2f, center = Offset(xs[i], ys[i]))
        }
    }
}
