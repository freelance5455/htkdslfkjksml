package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.AppSettings
import com.example.data.local.PreferencesManager
import com.example.data.local.ThemeMode
import com.example.data.model.*
import com.example.data.parser.SnowtamParser
import com.example.data.repository.AirportRepository
import com.example.data.repository.WeatherRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

sealed class UiState<out T> {
  object Loading : UiState<Nothing>()
  data class Success<out T>(val data: T, val isCachedOffline: Boolean = false, val lastUpdatedUtc: String = "") : UiState<T>()
  data class Error(val message: String, val rawFallback: String? = null) : UiState<Nothing>()
}

data class BoardAirportItem(
  val airport: Airport,
  val metar: MetarData? = null,
  val isMetarCached: Boolean = false,
  val hasTaf: Boolean = false,
  val hasSigmet: Boolean = false,
  val snowtamStatus: String = "NOT CONFIGURED",
  val lastUpdateUtc: String = ""
)

class WeatherViewModel(application: Application) : AndroidViewModel(application) {

  private val database = AppDatabase.getDatabase(application)
  private val airportRepo = AirportRepository(database.airportDao(), database.favoriteDao())
  private val weatherRepo = WeatherRepository(database.weatherCacheDao(), database.snowtamDao())
  private val prefsManager = PreferencesManager(application)

  val appSettings: StateFlow<AppSettings> = prefsManager.settingsFlow.stateIn(
    viewModelScope,
    SharingStarted.WhileSubscribed(5000),
    AppSettings()
  )

  private val _selectedAirport = MutableStateFlow<Airport>(AirportRepository.INITIAL_AIRPORTS[0]) // OIIE
  val selectedAirport: StateFlow<Airport> = _selectedAirport.asStateFlow()

  private val _searchQuery = MutableStateFlow("")
  val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

  val searchResults: StateFlow<List<Airport>> = _searchQuery
    .debounce(250)
    .flatMapLatest { query ->
      if (query.isBlank()) airportRepo.allAirports
      else airportRepo.searchAirports(query)
    }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AirportRepository.INITIAL_AIRPORTS)

  val favorites: StateFlow<List<Airport>> = combine(
    airportRepo.allAirports,
    airportRepo.favorites
  ) { all, favs ->
    val favSet = favs.map { it.icao }.toSet()
    all.filter { it.icao in favSet }
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val recents: StateFlow<List<Airport>> = combine(
    airportRepo.allAirports,
    airportRepo.recents
  ) { all, rec ->
    val recMap = rec.associateBy { it.icao }
    all.filter { it.icao in recMap }
      .sortedByDescending { recMap[it.icao]?.lastViewedTimestamp ?: 0 }
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val isSelectedFavorite: StateFlow<Boolean> = _selectedAirport
    .flatMapLatest { airportRepo.isFavorite(it.icao) }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)

  private val _metarState = MutableStateFlow<UiState<MetarData>>(UiState.Loading)
  val metarState: StateFlow<UiState<MetarData>> = _metarState.asStateFlow()

  private val _tafState = MutableStateFlow<UiState<TafData>>(UiState.Loading)
  val tafState: StateFlow<UiState<TafData>> = _tafState.asStateFlow()

  private val _sigmetsState = MutableStateFlow<UiState<List<SigmetData>>>(UiState.Loading)
  val sigmetsState: StateFlow<UiState<List<SigmetData>>> = _sigmetsState.asStateFlow()

  private val _windAloftState = MutableStateFlow<UiState<WindAloftReport>>(UiState.Loading)
  val windAloftState: StateFlow<UiState<WindAloftReport>> = _windAloftState.asStateFlow()

  val snowtams: StateFlow<List<SnowtamData>> = _selectedAirport
    .flatMapLatest { weatherRepo.getStoredSnowtams(it.icao) }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  private val _boardAirports = MutableStateFlow<List<BoardAirportItem>>(emptyList())
  val boardAirports: StateFlow<List<BoardAirportItem>> = _boardAirports.asStateFlow()

  private val _dataSourcesStatus = MutableStateFlow<List<DataSourceStatus>>(emptyList())
  val dataSourcesStatus: StateFlow<List<DataSourceStatus>> = _dataSourcesStatus.asStateFlow()

  private val _isOffline = MutableStateFlow(false)
  val isOffline: StateFlow<Boolean> = _isOffline.asStateFlow()

  init {
    viewModelScope.launch {
      airportRepo.initializeAirportsIfNeeded()
      loadWeatherForSelectedAirport()
      loadSigmets()
      loadDataSourcesStatus()
      refreshBoardAirports()
    }
  }

  fun onSearchQueryChanged(q: String) {
    _searchQuery.value = q
  }

  fun selectAirport(airport: Airport) {
    _selectedAirport.value = airport
    viewModelScope.launch {
      airportRepo.recordRecentView(airport.icao)
      loadWeatherForSelectedAirport()
    }
  }

  fun selectAirportByIcao(icao: String) {
    viewModelScope.launch {
      val found = airportRepo.getAirport(icao)
      if (found != null) {
        selectAirport(found)
      } else {
        // Fallback create minimal airport
        val minimal = Airport(
          icao = icao.uppercase(),
          iata = "",
          nameEn = "$icao Airport",
          nameFa = "فرودگاه $icao",
          cityEn = icao,
          cityFa = icao,
          countryEn = "International",
          countryFa = "بین‌المللی",
          latitude = 0.0,
          longitude = 0.0,
          elevationFt = 0,
          timezone = "UTC"
        )
        selectAirport(minimal)
      }
    }
  }

  fun toggleFavorite(icao: String) {
    viewModelScope.launch {
      airportRepo.toggleFavorite(icao)
    }
  }

  fun refreshAll() {
    viewModelScope.launch {
      loadWeatherForSelectedAirport()
      loadSigmets()
      loadDataSourcesStatus()
      refreshBoardAirports()
    }
  }

  fun loadWeatherForSelectedAirport() {
    val airport = _selectedAirport.value
    val utcNow = currentUtcString()

    viewModelScope.launch {
      _metarState.value = UiState.Loading
      val metarResult = weatherRepo.getMetar(airport.icao)
      metarResult.onSuccess { (data, isCached) ->
        _isOffline.value = isCached
        _metarState.value = UiState.Success(data, isCachedOffline = isCached, lastUpdatedUtc = utcNow)
      }.onFailure { err ->
        _metarState.value = UiState.Error(err.localizedMessage ?: "NO CURRENT DATA")
      }
    }

    viewModelScope.launch {
      _tafState.value = UiState.Loading
      val tafResult = weatherRepo.getTaf(airport.icao)
      tafResult.onSuccess { (data, isCached) ->
        _tafState.value = UiState.Success(data, isCachedOffline = isCached, lastUpdatedUtc = utcNow)
      }.onFailure { err ->
        _tafState.value = UiState.Error(err.localizedMessage ?: "NO CURRENT DATA")
      }
    }

    viewModelScope.launch {
      _windAloftState.value = UiState.Loading
      val windResult = weatherRepo.getWindAloft(
        icao = airport.icao,
        airportName = airport.nameEn,
        lat = airport.latitude,
        lon = airport.longitude
      )
      windResult.onSuccess { report ->
        _windAloftState.value = UiState.Success(report, lastUpdatedUtc = utcNow)
      }.onFailure { err ->
        _windAloftState.value = UiState.Error(err.localizedMessage ?: "WIND DATA SOURCE UNAVAILABLE")
      }
    }
  }

  fun loadSigmets() {
    viewModelScope.launch {
      _sigmetsState.value = UiState.Loading
      val result = weatherRepo.getSigmets()
      result.onSuccess { list ->
        _sigmetsState.value = UiState.Success(list, lastUpdatedUtc = currentUtcString())
      }.onFailure { err ->
        _sigmetsState.value = UiState.Error(err.localizedMessage ?: "SIGMET DATA UNAVAILABLE")
      }
    }
  }

  fun loadDataSourcesStatus() {
    viewModelScope.launch {
      _dataSourcesStatus.value = weatherRepo.checkAllSources()
    }
  }

  fun refreshBoardAirports() {
    viewModelScope.launch {
      val keyAirports = AirportRepository.INITIAL_AIRPORTS.take(8) // Tehran IKA, Mehrabad, Mashhad, Shiraz, Isfahan, Tabriz, Dubai, Doha
      val items = mutableListOf<BoardAirportItem>()
      for (apt in keyAirports) {
        val metarRes = weatherRepo.getMetar(apt.icao).getOrNull()
        val tafRes = weatherRepo.getTaf(apt.icao).getOrNull()
        items.add(
          BoardAirportItem(
            airport = apt,
            metar = metarRes?.first,
            isMetarCached = metarRes?.second ?: false,
            hasTaf = tafRes != null,
            hasSigmet = false,
            snowtamStatus = if (apt.countryEn == "Iran") "SNOWTAM SOURCE NOT CONFIGURED" else "NOT REPORTED",
            lastUpdateUtc = currentUtcString()
          )
        )
      }
      _boardAirports.value = items
    }
  }

  fun ingestCustomOrSampleSnowtam(raw: String, icao: String = _selectedAirport.value.icao) {
    viewModelScope.launch {
      val parsed = SnowtamParser.parse(
        raw = raw,
        icaoFallback = icao,
        sourceName = "ICAO GRF / Ingested Operational Bulletin",
        isSample = false
      )
      weatherRepo.insertSnowtam(parsed)
    }
  }

  fun seedOfficialSampleSnowtam() {
    viewModelScope.launch {
      weatherRepo.seedOfficialSampleSnowtamIfEmpty(_selectedAirport.value.icao)
    }
  }

  // Preference updates
  fun setThemeMode(mode: ThemeMode) {
    viewModelScope.launch { prefsManager.updateThemeMode(mode) }
  }

  fun setWindUnit(unit: String) {
    viewModelScope.launch { prefsManager.updateWindUnit(unit) }
  }

  fun setTempUnit(unit: String) {
    viewModelScope.launch { prefsManager.updateTempUnit(unit) }
  }

  fun setPressureUnit(unit: String) {
    viewModelScope.launch { prefsManager.updatePressureUnit(unit) }
  }

  fun setShowLocalTime(show: Boolean) {
    viewModelScope.launch { prefsManager.updateShowLocalTime(show) }
  }

  fun setRefreshInterval(minutes: Int) {
    viewModelScope.launch { prefsManager.updateRefreshInterval(minutes) }
  }

  private fun currentUtcString(): String {
    val sdf = SimpleDateFormat("HH:mm:ss 'UTC'", Locale.US).apply {
      timeZone = TimeZone.getTimeZone("UTC")
    }
    return sdf.format(Date())
  }
}
