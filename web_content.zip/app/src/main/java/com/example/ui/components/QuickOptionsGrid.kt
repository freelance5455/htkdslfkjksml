package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage

@Composable
fun QuickOptionsGrid(
    language: AppLanguage,
    onNavigateToChoghadiya: () -> Unit,
    onNavigateToMuhurat: () -> Unit,
    onNavigateToMakanUdghatan: () -> Unit = onNavigateToMuhurat,
    onNavigateToOfficeUdghatan: () -> Unit = onNavigateToMuhurat,
    onNavigateToPanchak: () -> Unit,
    onNavigateToRashifal: () -> Unit,
    onNavigateToVratKatha: () -> Unit,
    onNavigateToReminders: () -> Unit,
    onNavigateToSmartTools: () -> Unit = {},
    onViewAllOptions: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, Color(0xFFE0E0E0)),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "पंचांग के प्रमुख विकल्प (Options)",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = Color.Black
                )

                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .clickable(onClick = onViewAllOptions)
                        .padding(horizontal = 6.dp, vertical = 3.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "सभी विकल्प ➔",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Black
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Row 1: Choghadiya & Shubh Muhurat
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                QuickOptionCard(
                    icon = Icons.Default.Schedule,
                    title = "चौघड़िया",
                    desc = "दिन व रात के 16 मुहूर्त",
                    onClick = onNavigateToChoghadiya,
                    testTag = "quick_choghadiya",
                    modifier = Modifier.weight(1f)
                )
                QuickOptionCard(
                    icon = Icons.Default.Favorite,
                    title = "विवाह मुहूर्त",
                    desc = "शुभ लग्न व नक्षत्र",
                    onClick = onNavigateToMuhurat,
                    testTag = "quick_muhurat",
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Row 2: Makan Udghatan & Office Muhurat (User Requested Options)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                QuickOptionCard(
                    icon = Icons.Default.Home,
                    title = "मकान उद्घाटन",
                    desc = "गृह प्रवेश व वास्तु",
                    onClick = onNavigateToMakanUdghatan,
                    testTag = "quick_makan_udghatan",
                    modifier = Modifier.weight(1f)
                )
                QuickOptionCard(
                    icon = Icons.Default.Storefront,
                    title = "ऑफिस मुहूर्त",
                    desc = "दुकान व व्यापार शुभारंभ",
                    onClick = onNavigateToOfficeUdghatan,
                    testTag = "quick_office_udghatan",
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Row 3: Panchak-Bichhuda & Rashifal
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                QuickOptionCard(
                    icon = Icons.Default.Warning,
                    title = "पंचक-बिछुड़ा",
                    desc = "नियम व वर्जित कार्य",
                    onClick = onNavigateToPanchak,
                    testTag = "quick_panchak",
                    modifier = Modifier.weight(1f)
                )
                QuickOptionCard(
                    icon = Icons.Default.AutoAwesome,
                    title = "दैनिक राशिफल",
                    desc = "12 राशियों का फल",
                    onClick = onNavigateToRashifal,
                    testTag = "quick_rashifal",
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Row 3
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                QuickOptionCard(
                    icon = Icons.Default.MenuBook,
                    title = "व्रत कथाएं",
                    desc = "एकादशी व पूर्णिमा",
                    onClick = onNavigateToVratKatha,
                    testTag = "quick_vrat_katha",
                    modifier = Modifier.weight(1f)
                )
                QuickOptionCard(
                    icon = Icons.Default.Notifications,
                    title = "स्मरण अलर्ट",
                    desc = "व्रत व तिथि अलार्म",
                    onClick = onNavigateToReminders,
                    testTag = "quick_reminders",
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Row 4: Smart Tools (User requested smart instruments hub)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                QuickOptionCard(
                    icon = Icons.Default.Explore,
                    title = "स्मार्ट वैदिक उपकरण",
                    desc = "कंपास, 108 माला, होरा, गुण मिलान",
                    onClick = onNavigateToSmartTools,
                    testTag = "quick_smart_tools",
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

@Composable
private fun QuickOptionCard(
    icon: ImageVector,
    title: String,
    desc: String,
    onClick: () -> Unit,
    testTag: String,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(Color(0xFFF9F9F9))
            .border(1.dp, Color(0xFFE5E5E5), RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(10.dp)
            .testTag(testTag)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color.White)
                    .border(1.dp, Color(0xFFE0E0E0), RoundedCornerShape(8.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = Color.Black,
                    modifier = Modifier.size(18.dp)
                )
            }

            Spacer(modifier = Modifier.width(10.dp))

            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.Black,
                    fontSize = 13.sp
                )
                Text(
                    text = desc,
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFF555555),
                    fontSize = 10.5.sp,
                    maxLines = 1
                )
            }
        }
    }
}
