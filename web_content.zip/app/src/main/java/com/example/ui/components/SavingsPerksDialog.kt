package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AestheticBlack
import com.example.ui.theme.BorderGrey
import com.example.ui.theme.CardGrey
import com.example.ui.theme.DeepPink
import com.example.ui.theme.KawaiiPink
import com.example.ui.theme.PastelPinkBg
import com.example.ui.theme.PastelPinkContainer
import com.example.ui.theme.PureWhite
import com.example.ui.theme.TextGrey

data class PerkItem(
    val id: String,
    val title: String,
    val description: String,
    val requiredCoins: Int,
    val monetarySaving: String,
    val badge: String
)

@Composable
fun SavingsPerksDialog(
    totalFocusMinutes: Int,
    onOpenVipPayment: () -> Unit,
    onDismiss: () -> Unit
) {
    // 10 coins per 25 min of focus + starter bonus
    val earnedCoins = 50 + (totalFocusMinutes / 25) * 10
    val estimatedMoneySaved = (totalFocusMinutes * 1.5).toInt().coerceAtLeast(120)

    val perks = listOf(
        PerkItem(
            id = "vip_pass",
            title = "60% OFF 2-Month VIP Pass",
            description = "Get full 2 months VIP for ₹199 instead of ₹499.",
            requiredCoins = 80,
            monetarySaving = "Save ₹300",
            badge = "🔥 Best Student Deal"
        ),
        PerkItem(
            id = "streak_shield",
            title = "Free Streak Shield Rest Day",
            description = "Protect your study streak on days when you are resting.",
            requiredCoins = 60,
            monetarySaving = "Priceless",
            badge = "🛡️ Popular"
        ),
        PerkItem(
            id = "holographic_sticker",
            title = "Exclusive Gold Hologram Sticker",
            description = "Unlock the ultra-rare sparkling Gold Bunny Pen.",
            requiredCoins = 100,
            monetarySaving = "Save ₹99",
            badge = "✨ Limited"
        ),
        PerkItem(
            id = "study_report",
            title = "Weekly Study PDF Report",
            description = "Export and share your productivity graphs with parents.",
            requiredCoins = 120,
            monetarySaving = "Save ₹150",
            badge = "📊 New"
        )
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = PureWhite,
        shape = RoundedCornerShape(28.dp),
        modifier = Modifier.testTag("savings_perks_dialog"),
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(text = "💰", fontSize = 24.sp)
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "Focus Savings Jar",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = AestheticBlack
                        )
                        Text(
                            text = "Turn your study time into real savings!",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextGrey
                        )
                    }
                }
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = TextGrey)
                }
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                // Bank Balance Card
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = PastelPinkContainer),
                    border = androidx.compose.foundation.BorderStroke(1.dp, KawaiiPink.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Your StudyCoin Balance", style = MaterialTheme.typography.labelSmall, color = TextGrey)
                            Text(
                                text = "🪙 $earnedCoins Coins",
                                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold),
                                color = DeepPink
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = PureWhite,
                            border = androidx.compose.foundation.BorderStroke(1.dp, BorderGrey)
                        ) {
                            Column(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                horizontalAlignment = Alignment.End
                            ) {
                                Text("Productivity Value", style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp), color = TextGrey)
                                Text("₹$estimatedMoneySaved Saved!", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold), color = AestheticBlack)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = "Redeem StudyCoins For Perks:",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                    color = AestheticBlack
                )

                Spacer(modifier = Modifier.height(8.dp))

                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(280.dp)
                ) {
                    items(perks) { perk ->
                        val canAfford = earnedCoins >= perk.requiredCoins

                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = PureWhite),
                            border = androidx.compose.foundation.BorderStroke(1.dp, if (perk.id == "vip_pass") DeepPink else BorderGrey),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    if (perk.id == "vip_pass") {
                                        onDismiss()
                                        onOpenVipPayment()
                                    }
                                }
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = PastelPinkBg
                                    ) {
                                        Text(
                                            text = perk.badge,
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold
                                            ),
                                            color = DeepPink,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                        )
                                    }

                                    Text(
                                        text = perk.monetarySaving,
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                        color = DeepPink
                                    )
                                }

                                Spacer(modifier = Modifier.height(6.dp))

                                Text(
                                    text = perk.title,
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                    color = AestheticBlack
                                )

                                Text(
                                    text = perk.description,
                                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                                    color = TextGrey
                                )

                                Spacer(modifier = Modifier.height(8.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "🪙 ${perk.requiredCoins} Coins",
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                                        color = TextGrey
                                    )

                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = if (canAfford) AestheticBlack else CardGrey,
                                        modifier = Modifier.clip(RoundedCornerShape(10.dp))
                                    ) {
                                        Text(
                                            text = if (perk.id == "vip_pass") "Redeem ₹199 Offer 🎀" else if (canAfford) "Claim Perk" else "Need ${perk.requiredCoins - earnedCoins} more",
                                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                            color = if (canAfford) PureWhite else TextGrey,
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onDismiss()
                    onOpenVipPayment()
                },
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = AestheticBlack,
                    contentColor = PureWhite
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Get VIP Deal for ₹199 (Save ₹300) ⭐", fontWeight = FontWeight.Bold)
            }
        }
    )
}
