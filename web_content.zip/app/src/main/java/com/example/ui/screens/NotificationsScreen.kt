package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Comment
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.local.NotificationEntity
import com.example.ui.theme.ZingBlack
import com.example.ui.theme.ZingBorder
import com.example.ui.theme.ZingCardSurface
import com.example.ui.theme.ZingCyan
import com.example.ui.theme.ZingDarkSurface
import com.example.ui.theme.ZingEmerald
import com.example.ui.theme.ZingGold
import com.example.ui.theme.ZingHeartRed
import com.example.ui.theme.ZingNeonPink
import com.example.ui.theme.ZingTextMuted
import com.example.ui.theme.ZingTextPrimary
import com.example.ui.theme.ZingTextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

val notificationFilters = listOf("All", "Likes", "Comments", "Follows", "Gifts & Earnings")

@Composable
fun NotificationsScreen(
    notifications: List<NotificationEntity>,
    onMarkAllRead: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedFilter by remember { mutableStateOf("All") }
    val context = LocalContext.current

    val filteredNotifications = remember(notifications, selectedFilter) {
        when (selectedFilter) {
            "Likes" -> notifications.filter { it.type == "LIKE" }
            "Comments" -> notifications.filter { it.type == "COMMENT" }
            "Follows" -> notifications.filter { it.type == "FOLLOW" }
            "Gifts & Earnings" -> notifications.filter { it.type == "GIFT" || it.type == "MONETIZATION" }
            else -> notifications
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(ZingBlack)
            .statusBarsPadding()
    ) {
        // Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Notifications",
                color = ZingTextPrimary,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )

            TextButton(onClick = onMarkAllRead) {
                Text("Mark all read", color = ZingCyan, fontSize = 13.sp)
            }
        }

        // Filter Pills
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(notificationFilters) { filter ->
                val isSelected = selectedFilter == filter
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = if (isSelected) ZingNeonPink else ZingDarkSurface,
                    border = if (isSelected) null else androidx.compose.foundation.BorderStroke(1.dp, ZingBorder),
                    modifier = Modifier.clickable { selectedFilter = filter }
                ) {
                    Text(
                        text = filter,
                        color = if (isSelected) Color.White else ZingTextSecondary,
                        fontSize = 12.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Notifications List
        if (filteredNotifications.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(text = "All caught up!", color = ZingTextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = "No new notifications in this category", color = ZingTextSecondary, fontSize = 13.sp)
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filteredNotifications, key = { it.id }) { notif ->
                    NotificationRow(notif = notif)
                }
            }
        }
    }
}

@Composable
private fun NotificationRow(notif: NotificationEntity) {
    val context = LocalContext.current
    val avatarRes = context.resources.getIdentifier(notif.actorAvatar, "drawable", context.packageName)
    val timeAgoStr = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(notif.timestamp))

    val (iconVector, iconTint, iconBg) = when (notif.type) {
        "LIKE" -> Triple(Icons.Default.Favorite, ZingHeartRed, Color(0x33FF3366))
        "COMMENT" -> Triple(Icons.Default.Comment, ZingCyan, Color(0x3300F2FE))
        "GIFT" -> Triple(Icons.Default.CardGiftcard, ZingGold, Color(0x33FFD166))
        "MONETIZATION" -> Triple(Icons.Default.MonetizationOn, ZingEmerald, Color(0x3306D6A0))
        else -> Triple(Icons.Default.PersonAdd, ZingNeonPink, Color(0x33FF2A6D))
    }

    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = if (notif.isRead) ZingDarkSurface else ZingCardSurface),
        modifier = Modifier
            .fillMaxWidth()
            .border(
                1.dp,
                if (notif.isRead) ZingBorder.copy(alpha = 0.5f) else ZingBorder,
                RoundedCornerShape(14.dp)
            )
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Actor Avatar with badge icon
            Box {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(ZingDarkSurface)
                ) {
                    if (avatarRes != 0) {
                        AsyncImage(
                            model = ImageRequest.Builder(context).data(avatarRes).crossfade(true).build(),
                            contentDescription = notif.actorName,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize().background(iconTint)) {
                            Text(text = notif.actorName.take(1), color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                // Type badge
                Box(
                    modifier = Modifier
                        .size(18.dp)
                        .clip(CircleShape)
                        .background(iconTint)
                        .align(Alignment.BottomEnd),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(imageVector = iconVector, contentDescription = null, tint = Color.White, modifier = Modifier.size(11.dp))
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Body
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = notif.title,
                    color = ZingTextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "${notif.actorName} ${notif.message}",
                    color = ZingTextSecondary,
                    fontSize = 12.sp,
                    lineHeight = 16.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(text = timeAgoStr, color = ZingTextMuted, fontSize = 10.sp)
            }
        }
    }
}
