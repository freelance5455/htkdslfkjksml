package com.example.ui.calculator

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.DeleteSweep
import androidx.compose.material.icons.outlined.History
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.local.CalculationHistoryEntity
import com.example.ui.theme.AetherTheme
import com.example.ui.theme.InterFamily
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryBottomSheet(
  history: List<CalculationHistoryEntity>,
  onDismiss: () -> Unit,
  onReuseExpression: (CalculationHistoryEntity) -> Unit,
  onCopyResult: (String) -> Unit,
  onDeleteItem: (Long) -> Unit,
  onClearAll: () -> Unit,
) {
  val colors = AetherTheme.colors
  val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
  var showClearConfirm by remember { mutableStateOf(false) }

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = sheetState,
    containerColor = colors.surface,
    contentColor = colors.textPrimary,
    shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
  ) {
    Column(
      modifier =
        Modifier
          .fillMaxWidth()
          .heightIn(min = 280.dp, max = 560.dp)
          .padding(horizontal = 16.dp)
          .padding(bottom = 24.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text = stringResource(R.string.history_title),
          style = MaterialTheme.typography.headlineSmall,
          color = colors.textPrimary,
        )
        if (history.isNotEmpty()) {
          TextButton(
            onClick = { showClearConfirm = true },
            modifier = Modifier.testTag("clear_history_button"),
          ) {
            Icon(
              imageVector = Icons.Outlined.DeleteSweep,
              contentDescription = null,
              tint = colors.error,
              modifier = Modifier.size(18.dp),
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = stringResource(R.string.history_clear_all),
              color = colors.error,
              style = MaterialTheme.typography.labelLarge,
            )
          }
        }
      }

      if (history.isEmpty()) {
        Box(
          modifier = Modifier.fillMaxWidth().weight(1f, fill = false).padding(vertical = 48.dp),
          contentAlignment = Alignment.Center,
        ) {
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
              imageVector = Icons.Outlined.History,
              contentDescription = null,
              tint = colors.textSecondary,
              modifier = Modifier.size(44.dp),
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
              text = stringResource(R.string.history_empty_title),
              style = MaterialTheme.typography.titleMedium,
              color = colors.textPrimary,
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = stringResource(R.string.history_empty_subtitle),
              style = MaterialTheme.typography.bodySmall,
              color = colors.textSecondary,
            )
          }
        }
      } else {
        LazyColumn(
          verticalArrangement = Arrangement.spacedBy(8.dp),
          contentPadding = PaddingValues(bottom = 16.dp),
        ) {
          items(items = history, key = { it.id }) { item ->
            HistoryRowCard(
              item = item,
              onReuse = {
                onReuseExpression(item)
                onDismiss()
              },
              onCopy = { onCopyResult(item.resultFormatted) },
              onDelete = { onDeleteItem(item.id) },
            )
          }
        }
      }
    }
  }

  if (showClearConfirm) {
    AlertDialog(
      onDismissRequest = { showClearConfirm = false },
      containerColor = colors.surfaceElevated,
      titleContentColor = colors.textPrimary,
      textContentColor = colors.textSecondary,
      title = { Text(stringResource(R.string.history_clear_confirm_title)) },
      text = { Text(stringResource(R.string.history_clear_confirm_body)) },
      confirmButton = {
        TextButton(
          onClick = {
            onClearAll()
            showClearConfirm = false
          }
        ) {
          Text(stringResource(R.string.clear), color = colors.error)
        }
      },
      dismissButton = {
        TextButton(onClick = { showClearConfirm = false }) {
          Text(stringResource(R.string.cancel), color = colors.lavender)
        }
      },
    )
  }
}

@Composable
private fun HistoryRowCard(
  item: CalculationHistoryEntity,
  onReuse: () -> Unit,
  onCopy: () -> Unit,
  onDelete: () -> Unit,
) {
  val colors = AetherTheme.colors
  val timeFormat = remember { SimpleDateFormat("MMM d, HH:mm", Locale.getDefault()) }
  val timeText = remember(item.timestamp) { timeFormat.format(Date(item.timestamp)) }

  Surface(
    modifier =
      Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(16.dp))
        .clickable(onClick = onReuse)
        .testTag("history_item_${item.id}"),
    shape = RoundedCornerShape(16.dp),
    color = colors.surfaceElevated,
    border = BorderStroke(1.dp, colors.borderSubtle),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = timeText,
          style = MaterialTheme.typography.labelSmall,
          color = colors.textSecondary,
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
          text = item.expression,
          style =
            TextStyle(
              fontFamily = InterFamily,
              fontSize = 14.sp,
              color = colors.textSecondary,
              fontFeatureSettings = "tnum",
            ),
          maxLines = 2,
          overflow = TextOverflow.Ellipsis,
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
          text = "= ${item.resultFormatted}",
          style =
            TextStyle(
              fontFamily = InterFamily,
              fontSize = 20.sp,
              fontWeight = FontWeight.SemiBold,
              color = colors.textPrimary,
              fontFeatureSettings = "tnum",
            ),
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
      }
      Row(verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onCopy, modifier = Modifier.size(44.dp)) {
          Icon(
            imageVector = Icons.Outlined.ContentCopy,
            contentDescription = stringResource(R.string.cd_copy_result),
            tint = colors.lavender,
            modifier = Modifier.size(18.dp),
          )
        }
        IconButton(onClick = onDelete, modifier = Modifier.size(44.dp)) {
          Icon(
            imageVector = Icons.Outlined.Delete,
            contentDescription = stringResource(R.string.cd_delete_item),
            tint = colors.textSecondary,
            modifier = Modifier.size(18.dp),
          )
        }
      }
    }
  }
}
