package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.SufiEntry
import com.example.data.SufiLanguage
import com.example.ui.theme.GoldGleam
import com.example.ui.theme.GoldLuster
import com.example.ui.theme.GoldLusterBright
import com.example.ui.theme.SufiMaroon
import com.example.ui.theme.SufiMutedText
import com.example.ui.theme.TerracottaBackground
import com.example.ui.theme.TerracottaDark

/**
 * AntiqueCardShareDialog:
 * Allows user to share the wisdom as an authentic antique card or plain text.
 */
@Composable
fun AntiqueCardShareDialog(
    entry: SufiEntry,
    language: SufiLanguage,
    onDismiss: () -> Unit,
    onShareImage: () -> Unit,
    onShareText: () -> Unit,
    modifier: Modifier = Modifier
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = modifier
                .fillMaxWidth()
                .padding(16.dp)
                .shadow(16.dp, RoundedCornerShape(24.dp))
                .testTag("share_dialog_card"),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = TerracottaDark)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.5.dp, GoldLuster.copy(alpha = 0.7f), RoundedCornerShape(24.dp))
                    .padding(22.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (language == SufiLanguage.MALAYALAM) "ജ്ഞാനം പങ്കുവെക്കാം" else "Share Sufi Wisdom",
                        style = MaterialTheme.typography.titleMedium,
                        fontFamily = FontFamily.Serif,
                        color = GoldLusterBright,
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp
                    )
                    IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Filled.Close, contentDescription = "Close", tint = SufiMutedText)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Card Preview Box
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(TerracottaBackground, RoundedCornerShape(16.dp))
                        .border(1.dp, GoldLuster.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = if (language == SufiLanguage.MALAYALAM) entry.ml else "“${entry.en}”",
                            style = MaterialTheme.typography.bodyMedium,
                            fontFamily = FontFamily.Serif,
                            textAlign = TextAlign.Center,
                            color = GoldGleam,
                            fontSize = 15.sp,
                            lineHeight = 24.sp
                        )
                        if (entry.isQuote && !entry.author.isNullOrBlank()) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "— ${entry.author}",
                                style = MaterialTheme.typography.labelSmall,
                                fontFamily = FontFamily.Serif,
                                fontStyle = FontStyle.Italic,
                                color = GoldLusterBright,
                                fontSize = 12.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Actions: Share Image & Share Text
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onShareText,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, GoldLuster.copy(alpha = 0.6f))
                    ) {
                        Icon(Icons.Filled.TextFields, contentDescription = null, tint = GoldLuster, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Text", color = GoldLuster, fontSize = 13.sp)
                    }

                    Button(
                        onClick = onShareImage,
                        modifier = Modifier.weight(1.3f),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = SufiMaroon)
                    ) {
                        Icon(Icons.Filled.Image, contentDescription = null, tint = GoldLusterBright, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Card Image", color = GoldLusterBright, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
