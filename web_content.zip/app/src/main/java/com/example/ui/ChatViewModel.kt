package com.example.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.ConversationEntity
import com.example.data.local.MemoryEntity
import com.example.data.local.MessageEntity
import com.example.data.local.RaynoxDatabase
import com.example.data.local.ReminderEntity
import com.example.data.preferences.UserPreferencesRepository
import com.example.data.preferences.UserSettings
import com.example.data.remote.GeminiClient
import com.example.device.DeviceToolsManager
import com.example.reminder.ReminderScheduler
import com.example.service.RaynoxVoiceService
import com.example.service.WakeWordServiceStatus
import com.example.util.AttachmentHelper
import com.example.util.DateTimeHelper
import com.example.util.PreparedAttachment
import com.example.voice.VoiceAssistantManager
import com.example.voice.VoiceRecognitionState
import java.util.UUID
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@OptIn(ExperimentalCoroutinesApi::class)
class ChatViewModel(application: Application) : AndroidViewModel(application) {

    private val db = RaynoxDatabase.getInstance(application)
    private val chatDao = db.chatDao()
    private val reminderDao = db.reminderDao()
    private val memoryDao = db.memoryDao()
    private val preferencesRepository = UserPreferencesRepository(application)

    init {
        // Initialize flashlight state monitor
        DeviceToolsManager.initTorchMonitor(application)
    }

    val userSettings: StateFlow<UserSettings> = preferencesRepository.settingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UserSettings())

    // --- Search & Conversations ---
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    val conversations: StateFlow<List<ConversationEntity>> = _searchQuery
        .flatMapLatest { query ->
            if (query.isBlank()) {
                chatDao.getAllConversations()
            } else {
                chatDao.searchConversations(query.trim())
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _activeConversationId = MutableStateFlow<String?>(null)
    val activeConversationId: StateFlow<String?> = _activeConversationId.asStateFlow()

    val activeMessages: StateFlow<List<MessageEntity>> = _activeConversationId
        .flatMapLatest { id ->
            if (id == null) flowOf(emptyList())
            else chatDao.getMessagesForConversation(id)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- Reminders & User Memories ---
    val reminders: StateFlow<List<ReminderEntity>> = reminderDao.getAllReminders()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val memories: StateFlow<List<MemoryEntity>> = memoryDao.getAllMemoriesFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- Live System Clock & Network Time ---
    val liveTemporalContext: StateFlow<DateTimeHelper.TemporalContext> = flow {
        while (true) {
            emit(DateTimeHelper.getLiveTemporalContext())
            delay(1000)
        }
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        DateTimeHelper.getLiveTemporalContext()
    )

    private val _networkTimeResult = MutableStateFlow<DateTimeHelper.NetworkTimeResult?>(null)
    val networkTimeResult: StateFlow<DateTimeHelper.NetworkTimeResult?> = _networkTimeResult.asStateFlow()

    private val _isCheckingNetworkTime = MutableStateFlow(false)
    val isCheckingNetworkTime: StateFlow<Boolean> = _isCheckingNetworkTime.asStateFlow()

    // --- Device Flashlight State ---
    val isTorchOn: StateFlow<Boolean> = DeviceToolsManager.isTorchOn

    // --- Composer & Generation State ---
    private val _inputText = MutableStateFlow("")
    val inputText: StateFlow<String> = _inputText.asStateFlow()

    private val _pendingAttachment = MutableStateFlow<PreparedAttachment?>(null)
    val pendingAttachment: StateFlow<PreparedAttachment?> = _pendingAttachment.asStateFlow()

    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    private val _connectionStatus = MutableStateFlow("CHECKING")
    val connectionStatus: StateFlow<String> = _connectionStatus.asStateFlow()

    private val _connectionMessage = MutableStateFlow("Checking AI connection...")
    val connectionMessage: StateFlow<String> = _connectionMessage.asStateFlow()

    private var lastSendTimestamp: Long = 0L

    private val _snackbarMessage = MutableStateFlow<String?>(null)
    val snackbarMessage: StateFlow<String?> = _snackbarMessage.asStateFlow()

    val wakeWordStatus: StateFlow<WakeWordServiceStatus> = RaynoxVoiceService.statusFlow

    private var activeGenerationJob: Job? = null
    private var activeStreamingMessageId: Long? = null

    init {
        testPingConnection(showSnackbar = false)
    }

    fun testPingConnection(showSnackbar: Boolean = true) {
        viewModelScope.launch {
            _connectionStatus.value = "CHECKING"
            _connectionMessage.value = "Checking live AI backend connection..."
            val model = userSettings.value.selectedModel
            val result = GeminiClient.pingHealthCheck(model)
            result.fold(
                onSuccess = { msg ->
                    _connectionStatus.value = "CONNECTED"
                    _connectionMessage.value = msg
                    if (showSnackbar) _snackbarMessage.value = msg
                },
                onFailure = { err ->
                    val errMsg = err.message ?: "Not Connected: Unable to reach AI service."
                    _connectionStatus.value = "NOT_CONNECTED"
                    _connectionMessage.value = errMsg
                    if (showSnackbar) _snackbarMessage.value = errMsg
                }
            )
        }
    }

    val voiceAssistantManager = VoiceAssistantManager(
        context = application,
        onFinalSpeechResult = { recognizedText ->
            val existing = _inputText.value.trim()
            _inputText.value = if (existing.isEmpty()) recognizedText else "$existing $recognizedText"
        }
    )

    val voiceState: StateFlow<VoiceRecognitionState> = voiceAssistantManager.voiceState
    val speakingMessageId: StateFlow<Long?> = voiceAssistantManager.speakingMessageId

    fun onInputTextChanged(newText: String) {
        _inputText.value = newText
    }

    fun onSearchQueryChanged(query: String) {
        _searchQuery.value = query
    }

    fun clearSnackbar() {
        _snackbarMessage.value = null
    }

    fun startNewChat() {
        stopGeneration()
        voiceAssistantManager.stopSpeaking()
        _activeConversationId.value = null
        _inputText.value = ""
        _pendingAttachment.value = null
    }

    fun selectConversation(conversationId: String) {
        if (_activeConversationId.value == conversationId) return
        stopGeneration()
        voiceAssistantManager.stopSpeaking()
        _activeConversationId.value = conversationId
    }

    fun deleteConversation(conversationId: String) {
        viewModelScope.launch {
            if (_activeConversationId.value == conversationId) {
                stopGeneration()
                _activeConversationId.value = null
            }
            chatDao.deleteConversationById(conversationId)
            _snackbarMessage.value = "Conversation deleted"
        }
    }

    fun clearAllConversations() {
        viewModelScope.launch {
            stopGeneration()
            _activeConversationId.value = null
            chatDao.deleteAllConversations()
            _snackbarMessage.value = "All conversations cleared"
        }
    }

    fun renameActiveConversation(newTitle: String) {
        val convId = _activeConversationId.value ?: return
        viewModelScope.launch {
            chatDao.updateConversationTitle(convId, newTitle.trim())
        }
    }

    fun attachFileFromUri(uri: Uri) {
        viewModelScope.launch {
            val result = AttachmentHelper.processUri(getApplication(), uri)
            result.fold(
                onSuccess = { prepared ->
                    _pendingAttachment.value = prepared
                },
                onFailure = { err ->
                    _snackbarMessage.value = err.message ?: "Failed to attach file."
                }
            )
        }
    }

    fun removePendingAttachment() {
        _pendingAttachment.value = null
    }

    fun sendPromptText(promptText: String) {
        _inputText.value = promptText
        sendMessage()
    }

    fun sendMessage() {
        val now = System.currentTimeMillis()
        if (_isGenerating.value || now - lastSendTimestamp < 450L) return
        val rawText = _inputText.value.trim()
        val attachment = _pendingAttachment.value

        if (rawText.isEmpty() && attachment == null) return

        // Lock immediately to prevent duplicate sends when tapped repeatedly
        lastSendTimestamp = now
        _isGenerating.value = true

        // Clear composer immediately for responsive UX
        _inputText.value = ""
        _pendingAttachment.value = null
        voiceAssistantManager.stopListening()
        voiceAssistantManager.stopSpeaking()

        viewModelScope.launch {
            val settings = userSettings.value
            var convId = _activeConversationId.value

            // Create a new ConversationEntity if we are on the Welcome Screen
            if (convId == null) {
                convId = UUID.randomUUID().toString()
                val initialTitle = generateSmartTitle(rawText, attachment?.displayName)
                val newConv = ConversationEntity(
                    id = convId,
                    title = initialTitle,
                    createdAt = System.currentTimeMillis(),
                    updatedAt = System.currentTimeMillis(),
                    modelId = settings.selectedModel,
                    lastMessagePreview = rawText.ifEmpty { "Attached ${attachment?.displayName ?: "file"}" }
                )
                chatDao.insertConversation(newConv)
                _activeConversationId.value = convId
            }

            // 1. Insert the User Message
            val userMsg = MessageEntity(
                conversationId = convId,
                role = "user",
                content = rawText,
                timestamp = System.currentTimeMillis(),
                attachmentPath = attachment?.localPath,
                attachmentName = attachment?.displayName,
                attachmentMimeType = attachment?.mimeType,
                attachmentType = attachment?.attachmentType,
                attachmentExtractedText = attachment?.extractedText,
                isError = false,
                isStreaming = false
            )
            chatDao.insertMessage(userMsg)
            chatDao.touchConversation(
                conversationId = convId,
                preview = rawText.ifEmpty { "Attached ${attachment?.displayName ?: "file"}" }
            )

            // 2. Check for immediate local device action command (e.g. torch on, open youtube)
            if (attachment == null) {
                val directResult = DeviceToolsManager.detectAndExecuteQuickDeviceAction(getApplication(), rawText)
                if (directResult != null && directResult.isHandled) {
                    val instantAssistantMsg = MessageEntity(
                        conversationId = convId,
                        role = "assistant",
                        content = directResult.feedbackMessage,
                        timestamp = System.currentTimeMillis(),
                        isError = false,
                        isStreaming = false
                    )
                    val insertedId = chatDao.insertMessage(instantAssistantMsg)
                    chatDao.touchConversation(convId, directResult.feedbackMessage)
                    if (settings.autoSpeakResponses) {
                        voiceAssistantManager.speakMessage(
                            messageId = insertedId,
                            rawMarkdownText = directResult.feedbackMessage,
                            preferredLanguageTag = settings.voiceLanguage
                        )
                    }
                    _isGenerating.value = false
                    return@launch
                }
            }

            // 3. Trigger full AI brain response with dynamic live temporal & memory context
            requestAiResponseForConversation(convId)
        }
    }

    private fun requestAiResponseForConversation(conversationId: String) {
        activeGenerationJob?.cancel()
        activeGenerationJob = viewModelScope.launch {
            _isGenerating.value = true
            val settings = preferencesRepository.settingsFlow.first()

            // Insert placeholder streaming Assistant Message
            val placeholderAssistant = MessageEntity(
                conversationId = conversationId,
                role = "assistant",
                content = "",
                timestamp = System.currentTimeMillis(),
                isError = false,
                isStreaming = true
            )
            val assistantMsgId = chatDao.insertMessage(placeholderAssistant)
            activeStreamingMessageId = assistantMsgId

            var latestPartialText = ""
            try {
                // Fetch conversation history excluding the placeholder
                val history = chatDao.getMessagesForConversationSync(conversationId)
                    .filter { it.id != assistantMsgId }

                // Fetch saved memories for personalization
                val storedMemories = memoryDao.getAllMemories().map {
                    "${it.keyOrTopic}: ${it.memoryContent}"
                }

                val result = GeminiClient.streamChatResponse(
                    model = settings.selectedModel,
                    history = history,
                    userName = settings.userName,
                    customInstructions = settings.customInstructions,
                    userMemories = storedMemories,
                    onPartialUpdate = { partial ->
                        latestPartialText = partial
                        chatDao.updateMessageContent(
                            messageId = assistantMsgId,
                            content = sanitizeDisplayContent(partial),
                            isStreaming = true,
                            isError = false
                        )
                    }
                )

                result.fold(
                    onSuccess = { finalResponse ->
                        val cleanedText = handleAndExecuteActionTags(finalResponse)
                        chatDao.updateMessageContent(
                            messageId = assistantMsgId,
                            content = cleanedText,
                            isStreaming = false,
                            isError = false
                        )
                        chatDao.touchConversation(
                            conversationId = conversationId,
                            preview = cleanedText.take(90)
                        )
                        if (settings.autoSpeakResponses) {
                            voiceAssistantManager.speakMessage(
                                messageId = assistantMsgId,
                                rawMarkdownText = cleanedText,
                                preferredLanguageTag = settings.voiceLanguage
                            )
                        }
                    },
                    onFailure = { error ->
                        val errorText = error.message ?: "Unable to complete request. Tap Retry to try again."
                        chatDao.updateMessageContent(
                            messageId = assistantMsgId,
                            content = errorText,
                            isStreaming = false,
                            isError = true
                        )
                    }
                )
            } catch (ce: CancellationException) {
                val stoppedContent = if (latestPartialText.isNotBlank()) {
                    "${sanitizeDisplayContent(latestPartialText)}\n\n*(Generation stopped)*"
                } else {
                    "*(Generation stopped by user)*"
                }
                chatDao.updateMessageContent(
                    messageId = assistantMsgId,
                    content = stoppedContent,
                    isStreaming = false,
                    isError = false
                )
                throw ce
            } finally {
                activeStreamingMessageId = null
                _isGenerating.value = false
            }
        }
    }

    private fun sanitizeDisplayContent(raw: String): String {
        return raw.replace(Regex("\\[ACTION:[^\\]]+\\]"), "").trim()
    }

    private suspend fun handleAndExecuteActionTags(response: String): String {
        var processed = response
        val actionRegex = Regex("\\[ACTION:\\s*([^\\]]+)\\]")
        val matches = actionRegex.findAll(response).toList()

        for (match in matches) {
            val tagContent = match.groupValues[1].trim()
            executeActionFromTag(tagContent)
        }

        return processed.replace(actionRegex, "").trim()
    }

    private suspend fun executeActionFromTag(tag: String) {
        val app = getApplication<Application>()
        val parts = tag.split(":", limit = 2).map { it.trim() }
        val verb = parts[0].uppercase()
        val arg = if (parts.size > 1) parts[1] else ""

        withContext(Dispatchers.Main) {
            when (verb) {
                "TORCH_ON" -> DeviceToolsManager.toggleTorch(app, true)
                "TORCH_OFF" -> DeviceToolsManager.toggleTorch(app, false)
                "OPEN_APP" -> DeviceToolsManager.openApp(app, arg)
                "OPEN_SETTINGS" -> DeviceToolsManager.openSettingsScreen(app, arg)
                "DIAL" -> DeviceToolsManager.openDialer(app, arg)
                "SET_REMINDER" -> {
                    val reminderParts = arg.split("|").map { it.trim() }
                    val title = reminderParts.getOrNull(0) ?: "Raynox Reminder"
                    val minutes = reminderParts.getOrNull(1)?.toIntOrNull() ?: 15
                    createReminder(title, minutes)
                }
                "SAVE_MEMORY" -> {
                    val memParts = arg.split("|").map { it.trim() }
                    val topic = memParts.getOrNull(0) ?: "Preference"
                    val content = memParts.getOrNull(1) ?: arg
                    saveMemory(topic, content)
                }
            }
        }
    }

    // --- Device Actions & Reminders API for UI & Assistant ---
    fun toggleFlashlight() {
        val ok = DeviceToolsManager.toggleTorch(getApplication())
        _snackbarMessage.value = if (ok) {
            if (isTorchOn.value) "Flashlight turned ON 🔦" else "Flashlight turned OFF 🔦"
        } else {
            "Unable to toggle flashlight on this device"
        }
    }

    fun openAppByName(appName: String) {
        val ok = DeviceToolsManager.openApp(getApplication(), appName)
        if (!ok) {
            _snackbarMessage.value = "App $appName could not be opened"
        }
    }

    fun openSettingsScreen(type: String) {
        DeviceToolsManager.openSettingsScreen(getApplication(), type)
    }

    fun setMediaVolumeLevel(level: Int) {
        DeviceToolsManager.setMediaVolume(getApplication(), level)
    }

    fun checkNetworkTime() {
        if (_isCheckingNetworkTime.value) return
        viewModelScope.launch {
            _isCheckingNetworkTime.value = true
            val result = DateTimeHelper.fetchNetworkVerifiedTime()
            _networkTimeResult.value = result
            _isCheckingNetworkTime.value = false
        }
    }

    // --- Reminders Management ---
    fun createReminder(title: String, delayMinutes: Int = 10, customEpochMs: Long? = null) {
        viewModelScope.launch {
            val scheduledTime = customEpochMs ?: (System.currentTimeMillis() + (delayMinutes * 60 * 1000L))
            val reminder = ReminderEntity(
                title = title.trim().ifEmpty { "Reminder" },
                scheduledTimeMs = scheduledTime,
                isCompleted = false
            )
            val newId = reminderDao.insertReminder(reminder)
            ReminderScheduler.scheduleReminder(
                context = getApplication(),
                reminderId = newId,
                title = reminder.title,
                timeEpochMs = scheduledTime
            )
            _snackbarMessage.value = "Reminder set for '${reminder.title}'"
        }
    }

    fun toggleReminderCompleted(id: Long, isCompleted: Boolean) {
        viewModelScope.launch {
            reminderDao.setCompleted(id, isCompleted)
            if (isCompleted) {
                ReminderScheduler.cancelReminder(getApplication(), id)
            }
        }
    }

    fun deleteReminder(id: Long) {
        viewModelScope.launch {
            ReminderScheduler.cancelReminder(getApplication(), id)
            reminderDao.deleteReminderById(id)
            _snackbarMessage.value = "Reminder deleted"
        }
    }

    fun clearCompletedReminders() {
        viewModelScope.launch {
            reminderDao.clearCompletedReminders()
        }
    }

    // --- Memories Management ---
    fun saveMemory(topic: String, content: String) {
        viewModelScope.launch {
            memoryDao.insertMemory(
                MemoryEntity(
                    keyOrTopic = topic.trim().ifEmpty { "Note" },
                    memoryContent = content.trim()
                )
            )
            _snackbarMessage.value = "Saved to Raynox memory: '$topic'"
        }
    }

    fun deleteMemory(id: Long) {
        viewModelScope.launch {
            memoryDao.deleteMemoryById(id)
            _snackbarMessage.value = "Memory removed"
        }
    }

    fun clearAllMemories() {
        viewModelScope.launch {
            memoryDao.clearAllMemories()
            _snackbarMessage.value = "All saved memories cleared"
        }
    }

    fun stopGeneration() {
        activeGenerationJob?.cancel()
        activeGenerationJob = null
        _isGenerating.value = false
    }

    fun retryOrRegenerateMessage(assistantMessage: MessageEntity) {
        if (_isGenerating.value) return
        val convId = assistantMessage.conversationId
        viewModelScope.launch {
            chatDao.deleteMessageById(assistantMessage.id)
            requestAiResponseForConversation(convId)
        }
    }

    fun toggleSpeakMessage(message: MessageEntity) {
        voiceAssistantManager.speakMessage(
            messageId = message.id,
            rawMarkdownText = message.content,
            preferredLanguageTag = userSettings.value.voiceLanguage
        )
    }

    fun startOrStopVoiceInput(hasAudioPermission: Boolean, onRequestAudioPermission: () -> Unit) {
        if (voiceState.value.isListening) {
            voiceAssistantManager.stopListening()
            return
        }
        if (!hasAudioPermission) {
            onRequestAudioPermission()
            return
        }
        voiceAssistantManager.startListening(userSettings.value.voiceLanguage)
    }

    fun cycleVoiceLanguage() {
        val current = userSettings.value.voiceLanguage
        val next = when (current) {
            "en-IN" -> "hi-IN"
            "hi-IN" -> "en-US"
            else -> "en-IN"
        }
        viewModelScope.launch {
            preferencesRepository.setVoiceLanguage(next)
        }
    }

    fun updateThemeMode(mode: String) {
        viewModelScope.launch { preferencesRepository.setThemeMode(mode) }
    }

    fun updateSelectedModel(model: String) {
        viewModelScope.launch { preferencesRepository.setSelectedModel(model) }
    }

    fun updateVoiceLanguage(language: String) {
        viewModelScope.launch { preferencesRepository.setVoiceLanguage(language) }
    }

    fun updateAutoSpeak(enabled: Boolean) {
        viewModelScope.launch { preferencesRepository.setAutoSpeak(enabled) }
    }

    fun saveUserProfile(name: String, instructions: String) {
        viewModelScope.launch {
            preferencesRepository.updateProfile(name, instructions)
            _snackbarMessage.value = "Profile preferences saved"
        }
    }

    fun toggleWakeWordGuard(
        hasAudioPermission: Boolean,
        onRequestPermissions: () -> Unit
    ) {
        val app = getApplication<Application>()
        if (wakeWordStatus.value.isRunning) {
            RaynoxVoiceService.stopService(app)
            viewModelScope.launch { preferencesRepository.setWakeWordEnabled(false) }
            _snackbarMessage.value = "\"Hey Raynox\" Voice Guard stopped"
        } else {
            if (!hasAudioPermission) {
                onRequestPermissions()
                return
            }
            RaynoxVoiceService.startService(app, userSettings.value.voiceLanguage)
            viewModelScope.launch { preferencesRepository.setWakeWordEnabled(true) }
            _snackbarMessage.value = "\"Hey Raynox\" Voice Guard active"
        }
    }

    private fun generateSmartTitle(prompt: String, attachmentName: String?): String {
        val cleaned = prompt
            .replace(Regex("\\s+"), " ")
            .trim()
        if (cleaned.isEmpty()) {
            return if (!attachmentName.isNullOrBlank()) "Analysis: ${attachmentName.take(28)}" else "New Conversation"
        }
        val words = cleaned.split(" ").take(6).joinToString(" ")
        return if (words.length > 38) words.take(38).trim() + "…" else words
    }

    override fun onCleared() {
        voiceAssistantManager.release()
        super.onCleared()
    }
}
