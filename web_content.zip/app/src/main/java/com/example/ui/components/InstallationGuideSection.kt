package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.InstallMobile
import androidx.compose.material.icons.filled.Launch
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun InstallationGuideSection(
    isArabic: Boolean,
    onOpenSettingsClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxWidth()
            .verticalScroll(scrollState)
            .padding(bottom = 24.dp)
            .testTag("installation_guide_section"),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
            )
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = if (isArabic) "📖 دليل تثبيت التطبيقات المحولة على الهاتف" else "📖 How to Install Converted APKs",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = if (isArabic)
                        "نظام أندرويد يحمي هاتفك عبر طلب تأكيدك لتثبيت التطبيقات من خارج المتجر الرسمي. اتبع الخطوات السهلة التالية لتثبيت أي تطبيق محول:"
                    else
                        "Android protects your device by asking for confirmation before installing apps outside the Play Store. Follow these simple steps:",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.85f)
                )
            }
        }

        GuideStepCard(
            stepNumber = "1",
            icon = Icons.Default.InstallMobile,
            title = if (isArabic) "الضغط على زر \'تثبيت APK على الهاتف\'" else "Tap \'Install APK on Phone\'",
            description = if (isArabic)
                "بعد تحويل ملف ZIP أو XAPK، اضغط على الزر الأخضر الكبير لبدء عملية التثبيت."
            else
                "After converting your file, tap the large green Install button to launch the installer."
        )

        GuideStepCard(
            stepNumber = "2",
            icon = Icons.Default.Security,
            title = if (isArabic) "السماح بتثبيت التطبيقات غير المعروفة" else "Allow Unknown Apps Permission",
            description = if (isArabic)
                "إذا كانت هذه أول مرة، سيطلب منك أندرويد فتح الإعدادات. قم بتفعيل زر: \'السماح بتثبيت التطبيقات من هذا المصدر\'."
            else
                "If prompted by Android, go to Settings and switch ON \'Allow from this source\' for this app."
        )

        GuideStepCard(
            stepNumber = "3",
            icon = Icons.Default.CheckCircle,
            title = if (isArabic) "تأكيد التثبيت من نافذة أندرويد" else "Confirm Android System Prompt",
            description = if (isArabic)
                "ستظهر لك نافذة مثبت حزم أندرويد الرسمية باسم التطبيق. اضغط على \'تثبيت\' وانتظر ثوانٍ معدودة."
            else
                "The official Android system package installer dialog will appear. Tap \'Install\' to proceed."
        )

        GuideStepCard(
            stepNumber = "4",
            icon = Icons.Default.Launch,
            title = if (isArabic) "فتح وتشغيل التطبيق بنجاح" else "Open and Enjoy Your App",
            description = if (isArabic)
                "تهانينا! التطبيق مثبت الآن وجاهز للاستخدام مباشرة من شاشة هاتفك الرئيسية."
            else
                "Congratulations! Your converted app is now installed on your home screen and ready to run."
        )

        Spacer(modifier = Modifier.height(10.dp))

        Button(
            onClick = onOpenSettingsClick,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
        ) {
            Icon(imageVector = Icons.Default.Settings, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = if (isArabic) "فتح إعدادات تثبيت التطبيقات" else "Open Install App Settings",
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

@Composable
fun GuideStepCard(
    stepNumber: String,
    icon: ImageVector,
    title: String,
    description: String
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.Top
        ) {
            Surface(
                shape = CircleShape,
                color = MaterialTheme.colorScheme.secondaryContainer,
                modifier = Modifier.size(42.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
